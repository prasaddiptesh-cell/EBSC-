# Easy Buys Aronium Link (one on each till PC)

It **only reads** Aronium and sends what the Easy Buys app needs to the Easy Buys cloud:
products and prices (with VAT and barcodes), stock, suppliers, cashiers, sales per product per day,
every End of day (totals, VAT, refunds, discounts, payments, cashiers, voids, float), staff credit and purchases.
It never changes, adds or deletes anything in Aronium.

## Set up (about 5 minutes per till PC)
1. Run **EasyBuysAroniumLink-Setup.exe** (signed in to Windows as an administrator, just this once). If Windows warns about the program, choose **More info › Run anyway**.
2. Choose the **shop** and the **till number** of this PC:
   - Shop 1 – Drasa Avenue: Till 1, Till 2
   - Shop 2 – Tukani Street: Till 1
3. Press **Find** (or **Choose…** and pick `pos.db`).
4. Paste the **cloud web address** (the same one the app uses).
5. Paste the **main-software key**. You'll find it in the cloud script's Execution log after running *setup*. Keep it private.
6. Press **Check**, then **Send now**. The first send can take several minutes.
7. Press **Send on its own**. It then sends soon after each change in Aronium (sales, End of day) and every 15 minutes as a safety net, even with the window closed. It starts again by itself when Windows starts.
8. Settings tab › **Link PIN**: type 4–8 numbers and press **Set the PIN**. From then on, changing the settings or stopping the sending needs the PIN.

## Updates – by themselves
The Link checks for a newer build every 2 hours (and when the PC starts) and installs it silently, then carries on
sending. It only downloads from the shop's GitHub, and only a file whose fingerprint matches – anything else is thrown
away. The Status tab shows "Updates: …". Nothing to do by hand after the first install.

## Keeping it on (tamper protection)
- If sending is stopped or the Link is uninstalled, it tells the Easy Buys app first: the owner gets an **urgent**
  warning with the time and the Windows user.
- If a till PC sends nothing for 45 minutes while the shop is open (power, internet, PC off), the app warns; after
  2 hours it is urgent.
- The update part also starts the Link again every 2 hours if it has stopped.
- Best: let the cashiers sign in to Windows as a **standard user** (not administrator). Then they cannot uninstall the
  Link or remove its update task. (Windows Settings › Accounts › Other users › the cashier's account › Change account
  type › Standard User.) Install and set up the Link in that cashier's Windows account.

## Good to know
- If the internet is down, nothing is lost: it keeps what was not sent and tries again.
- Today's sales, stock and the health check go at most once an hour. End of days go as soon as they are done.
- Settings are in `%APPDATA%\EasyBuysAroniumLink`. The key there is locked to this Windows user.
- A log of every run is in `link.log` in that same folder.
