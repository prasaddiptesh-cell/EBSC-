"""Start here: opens the window, or with --run / --check / --resend does that job without a window
(Windows Task Scheduler runs "EasyBuysAroniumLink.exe --run")."""
from __future__ import annotations

import os
import sys


def main() -> int:
    if sys.stdout is None:  # the packaged program has no console
        sys.stdout = open(os.devnull, "w")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w")
    args = sys.argv[1:]
    if any(a in args for a in ("--run", "--check", "--resend")):
        import bridge
        return bridge.main(args)
    from bridge_ui import BridgeUI
    BridgeUI().mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
