"""Start here: opens the window, or with --run / --check / --resend does that job without a window
(Windows Task Scheduler runs "EasyBuysAroniumLink.exe --run")."""
from __future__ import annotations

import os
import sys


def main() -> int:
    # The packaged program has no console; text goes nowhere, in UTF-8 (Windows' default can't write ✓ / ✗).
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001 - not every stream can be changed
            pass
    args = sys.argv[1:]
    if any(a in args for a in ("--run", "--check", "--resend")):
        import bridge
        return bridge.main(args)
    from bridge_ui import BridgeUI
    BridgeUI().mainloop()
    return 0


def safe_main() -> int:
    try:
        return main()
    except Exception:  # noqa: BLE001 - never a crash box on a till PC: the problem goes to the log
        try:
            import traceback
            import config
            (config.home() / "crash.log").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        return 2


if __name__ == "__main__":
    raise SystemExit(safe_main())
