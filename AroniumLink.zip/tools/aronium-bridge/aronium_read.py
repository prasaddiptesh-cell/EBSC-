"""Reads an Aronium POS database (pos.db, SQLite) - READ ONLY - and turns it into what the Easy Buys app uses.

Never writes to Aronium: the file is opened with mode=ro and PRAGMA query_only, and only SELECT is ever run.
Works with older and newer Aronium versions: every column is checked before it is used, and anything missing
is simply left out (and reported in the health check) instead of failing.

What it gives back (all plain Python data, ready to send):
  products   - code, name, barcodes, group, unit, price, cost, VAT, enabled, service, stock, reorder levels
  parties    - suppliers and customers (name, TIN, phone, email, address)
  sales_day  - per day: each product sold / refunded (quantity, value incl. VAT, cost)
  z          - each End of day (Z report): totals, VAT, zero rated, refunds, discounts, payments by type,
               cashiers, voids, opening float and cash in / out
  credit     - what each customer (staff) still owes on unpaid sales
  purchases  - purchase documents (supplier, number, date, total) for matching with invoices
  users      - cashiers
  meta       - document types, payment types, taxes and counts (the health check)
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Any, Iterable

# Aronium's own document type codes (Document.DocumentTypeId -> DocumentType.Code).
SALES_CODES = {"200"}
REFUND_CODES = {"220", "230"}
PURCHASE_CODES = {"100"}
MAX_RECEIPT_LINES = 200  # one receipt never sends more lines than this (a runaway document cannot fill the cloud)


def _num(v: Any) -> bool:
    if v is None or isinstance(v, bool):
        return False
    try:
        x = float(v)
    except (TypeError, ValueError):
        return False
    return x == x and abs(x) != float("inf")


def default_database_paths() -> list[Path]:
    """Where Aronium usually keeps pos.db on Windows (checked in this order)."""
    out = []
    for env in ("LOCALAPPDATA", "APPDATA", "PROGRAMDATA"):
        base = os.environ.get(env)
        if base:
            out.append(Path(base) / "Aronium" / "Data" / "pos.db")
            out.append(Path(base) / "Aronium" / "pos.db")
    out.append(Path.home() / "AppData" / "Local" / "Aronium" / "Data" / "pos.db")
    seen, unique = set(), []
    for p in out:
        if str(p).lower() not in seen:
            seen.add(str(p).lower())
            unique.append(p)
    return unique


def find_database() -> Path | None:
    for p in default_database_paths():
        if p.is_file():
            return p
    return None


def open_read_only(path: str | os.PathLike) -> sqlite3.Connection:
    p = Path(os.path.expandvars(os.path.expanduser(str(path)))).resolve()
    if not p.is_file():
        raise FileNotFoundError(f"Aronium database not found: {p}")
    conn = sqlite3.connect(p.as_uri() + "?mode=ro", uri=True, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only = ON")
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


class Schema:
    """Which tables and columns this Aronium database has (so nothing is assumed)."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.tables: dict[str, set[str]] = {}
        for r in conn.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%'"):
            name = str(r["name"])
            cols = {str(c["name"]) for c in conn.execute(f'PRAGMA table_info("{name}")')}
            self.tables[name.lower()] = cols
            self.tables.setdefault("__names__", set()).add(name)

    def real(self, table: str) -> str | None:
        for n in self.tables.get("__names__", set()):
            if n.lower() == table.lower():
                return n
        return None

    def has(self, table: str, column: str | None = None) -> bool:
        cols = self.tables.get(table.lower())
        if cols is None:
            return False
        return True if column is None else column.lower() in {c.lower() for c in cols}

    def col(self, table: str, *choices: str) -> str | None:
        """The first of these columns that exists, or None."""
        cols = {c.lower(): c for c in self.tables.get(table.lower(), set())}
        for c in choices:
            if c.lower() in cols:
                return cols[c.lower()]
        return None


def q(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def r2(x: Any) -> float:
    try:
        return round(float(x or 0) + 0.0, 2)
    except (TypeError, ValueError):
        return 0.0


def r4(x: Any) -> float:
    try:
        return round(float(x or 0) + 0.0, 4)
    except (TypeError, ValueError):
        return 0.0


def day(v: Any) -> str:
    s = str(v or "").replace("T", " ").strip()
    return s[:10] if len(s) >= 10 and s[4] == "-" and s[7] == "-" else ""


class Aronium:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.s = Schema(conn)
        self.notes: list[str] = []  # anything missing / assumed, shown in the health check

    # ------------------------------------------------------------ helpers
    def rows(self, sql: str, args: Iterable[Any] = ()) -> list[sqlite3.Row]:
        sql_l = sql.lstrip().lower()
        if not (sql_l.startswith("select") or sql_l.startswith("with")):
            raise RuntimeError("Only reading is allowed.")
        return list(self.conn.execute(sql, tuple(args)))

    def doc_types(self) -> dict[int, dict[str, Any]]:
        if not self.s.has("DocumentType"):
            self.notes.append("No DocumentType table - every document is treated as a sale.")
            return {}
        code = self.s.col("DocumentType", "Code")
        sd = self.s.col("DocumentType", "StockDirection")
        out = {}
        for r in self.rows(f'SELECT Id, Name{", " + q(code) if code else ""}{", " + q(sd) if sd else ""} FROM {q(self.s.real("DocumentType"))}'):
            c = str(r[code] if code else "").strip()
            name = str(r["Name"] or "")
            kind = "other"
            low = name.lower()
            if c in SALES_CODES or (not c and low.startswith("sale")):
                kind = "sale"
            elif c in REFUND_CODES or "refund" in low or "return" in low and "supplier" not in low:
                kind = "refund"
            elif c in PURCHASE_CODES or low.startswith("purchase"):
                kind = "purchase"
            out[int(r["Id"])] = {"name": name, "code": c, "kind": kind, "stock_direction": r[sd] if sd else None}
        return out

    def type_ids(self, kind: str) -> list[int]:
        return [i for i, t in self.types.items() if t["kind"] == kind]

    @property
    def types(self) -> dict[int, dict[str, Any]]:
        if not hasattr(self, "_types"):
            self._types = self.doc_types()
        return self._types

    def tax_rate_by_product(self) -> dict[int, float]:
        """Total VAT % on each product (0 = zero rated / exempt)."""
        out: dict[int, float] = {}
        if self.s.has("ProductTax") and self.s.has("Tax"):
            en = self.s.col("Tax", "IsEnabled")
            for r in self.rows(f'SELECT pt.ProductId AS pid, t.Rate AS rate FROM {q(self.s.real("ProductTax"))} pt JOIN {q(self.s.real("Tax"))} t ON t.Id = pt.TaxId' + (f" WHERE t.{q(en)} = 1" if en else "")):
                out[int(r["pid"])] = out.get(int(r["pid"]), 0.0) + float(r["rate"] or 0)
        else:
            self.notes.append("No ProductTax / Tax table - VAT per product unknown.")
        return out

    def tax_names_by_product(self) -> dict[int, list[str]]:
        """Each product's taxes as Aronium writes them in its CSV ("Name:rate")."""
        out: dict[int, list[str]] = {}
        try:
            if self.s.has("ProductTax") and self.s.has("Tax"):
                for r in self.rows(f'SELECT pt.ProductId AS pid, t.Name AS n, t.Rate AS rate FROM {q(self.s.real("ProductTax"))} pt JOIN {q(self.s.real("Tax"))} t ON t.Id = pt.TaxId'):
                    rate = float(r["rate"] or 0)
                    out.setdefault(int(r["pid"]), []).append(f"{str(r['n'] or '').strip()}:{rate:g}")
        except Exception:  # noqa: BLE001 - a tax list is a help, never a reason to stop
            return {}
        return out

    # ------------------------------------------------------------ products
    def products(self) -> list[dict[str, Any]]:
        if not self.s.has("Product"):
            raise RuntimeError("This file has no Product table - is it the Aronium database (pos.db)?")
        P = self.s.real("Product")
        cols = {k: self.s.col("Product", *v) for k, v in {
            "code": ("Code",), "plu": ("PLU",), "unit": ("MeasurementUnit",), "price": ("Price",), "cost": ("Cost",),
            "last": ("LastPurchasePrice",), "enabled": ("IsEnabled",), "service": ("IsService",), "group": ("ProductGroupId",),
            "taxincl": ("IsTaxInclusivePrice",), "updated": ("DateUpdated",), "desc": ("Description",),
            "markup": ("Markup",), "pchange": ("IsPriceChangeAllowed",), "defqty": ("IsUsingDefaultQuantity",),
        }.items()}
        sel = ", ".join(["Id", "Name"] + [f"{q(c)} AS {q(k)}" for k, c in cols.items() if c])
        groups = {}
        if self.s.has("ProductGroup"):
            groups = {int(r["Id"]): str(r["Name"] or "") for r in self.rows(f'SELECT Id, Name FROM {q(self.s.real("ProductGroup"))}')}
        barcodes: dict[int, list[str]] = {}
        if self.s.has("Barcode"):
            vcol = self.s.col("Barcode", "Value", "Barcode", "Code")
            if vcol:
                for r in self.rows(f'SELECT ProductId AS pid, {q(vcol)} AS v FROM {q(self.s.real("Barcode"))}'):
                    v = str(r["v"] or "").strip()
                    if v:
                        barcodes.setdefault(int(r["pid"]), []).append(v)
        stock: dict[int, float] = {}
        if self.s.has("Stock", "Quantity"):
            for r in self.rows(f'SELECT ProductId AS pid, SUM(Quantity) AS q FROM {q(self.s.real("Stock"))} GROUP BY ProductId'):
                stock[int(r["pid"])] = round(float(r["q"] or 0), 3)
        reorder: dict[int, dict[str, float]] = {}
        if self.s.has("StockControl"):
            rp = self.s.col("StockControl", "ReorderPoint")
            pq = self.s.col("StockControl", "PreferredQuantity")
            if rp or pq:
                for r in self.rows(f'SELECT ProductId AS pid{", " + q(rp) + " AS rp" if rp else ""}{", " + q(pq) + " AS pq" if pq else ""} FROM {q(self.s.real("StockControl"))}'):
                    reorder[int(r["pid"])] = {"reorder_point": float(r["rp"] or 0) if rp else 0.0, "reorder_qty": float(r["pq"] or 0) if pq else 0.0}
        rates = self.tax_rate_by_product()
        tax_names = self.tax_names_by_product()
        out = []
        for r in self.rows(f"SELECT {sel} FROM {q(P)}"):
            pid = int(r["Id"])
            keys = r.keys()
            code = str(r["code"] if "code" in keys and r["code"] not in (None, "") else (r["plu"] if "plu" in keys and r["plu"] not in (None, "") else pid)).strip()
            rate = rates.get(pid)
            out.append({
                "id": pid, "code": code, "name": str(r["Name"] or "").strip(),
                "barcodes": barcodes.get(pid, []),
                "group": groups.get(int(r["group"])) if "group" in keys and r["group"] is not None else None,
                "unit": str(r["unit"] or "") if "unit" in keys else "",
                "price": r2(r["price"]) if "price" in keys else 0.0,
                "cost": r4(r["cost"]) if "cost" in keys and r["cost"] not in (None, "") else (r4(r["last"]) if "last" in keys else 0.0),
                "last_purchase_price": r4(r["last"]) if "last" in keys and r["last"] not in (None, "") else None,
                "vat_rate": rate if rate is not None else None,
                "price_includes_vat": bool(r["taxincl"]) if "taxincl" in keys and r["taxincl"] is not None else True,
                "enabled": bool(r["enabled"]) if "enabled" in keys and r["enabled"] is not None else True,
                "service": bool(r["service"]) if "service" in keys and r["service"] is not None else False,
                "stock": stock.get(pid), **reorder.get(pid, {}),
                "updated": str(r["updated"] or "") if "updated" in keys else "",
                # for the Aronium update file the app makes: the product exactly as it is now, so nothing else changes
                "desc": str(r["desc"] or "") if "desc" in keys else "",
                "markup": r4(r["markup"]) if "markup" in keys and r["markup"] not in (None, "") else None,
                "price_change": bool(r["pchange"]) if "pchange" in keys and r["pchange"] is not None else None,
                "default_qty": bool(r["defqty"]) if "defqty" in keys and r["defqty"] is not None else None,
                "taxes": tax_names.get(pid, []),
            })
        return out

    # ------------------------------------------------------------ suppliers and customers
    def parties(self) -> list[dict[str, Any]]:
        if not self.s.has("Customer"):
            return []
        C = self.s.real("Customer")
        want = {k: self.s.col("Customer", *v) for k, v in {
            "code": ("Code",), "tin": ("TaxNumber",), "address": ("Address", "StreetName"), "city": ("City",),
            "email": ("Email",), "phone": ("PhoneNumber", "Phone"), "enabled": ("IsEnabled",), "is_customer": ("IsCustomer",),
            "is_supplier": ("IsSupplier",), "due_days": ("DueDatePeriod",), "tax_exempt": ("IsTaxExempt",),
        }.items()}
        sel = ", ".join(["Id", "Name"] + [f"{q(c)} AS {q(k)}" for k, c in want.items() if c])
        out = []
        for r in self.rows(f"SELECT {sel} FROM {q(C)}"):
            k = r.keys()
            g = lambda n: r[n] if n in k else None  # noqa: E731
            out.append({
                "id": int(r["Id"]), "name": str(r["Name"] or "").strip(), "code": str(g("code") or ""), "tin": str(g("tin") or ""),
                "address": " ".join(x for x in [str(g("address") or ""), str(g("city") or "")] if x).strip(),
                "email": str(g("email") or ""), "phone": str(g("phone") or ""),
                "enabled": bool(g("enabled")) if g("enabled") is not None else True,
                "customer": bool(g("is_customer")) if g("is_customer") is not None else True,
                "supplier": bool(g("is_supplier")) if g("is_supplier") is not None else False,
                "due_days": int(g("due_days") or 0) if g("due_days") not in (None, "") else None,
                "tax_exempt": bool(g("tax_exempt")) if g("tax_exempt") is not None else False,
            })
        return out

    def users(self) -> list[dict[str, Any]]:
        if not self.s.has("User"):
            return []
        U = self.s.real("User")
        fn = self.s.col("User", "FirstName")
        ln = self.s.col("User", "LastName")
        un = self.s.col("User", "Username")
        en = self.s.col("User", "IsEnabled")
        out = []
        for r in self.rows(f'SELECT Id{", " + q(fn) + " AS fn" if fn else ""}{", " + q(ln) + " AS ln" if ln else ""}{", " + q(un) + " AS un" if un else ""}{", " + q(en) + " AS en" if en else ""} FROM {q(U)}'):
            k = r.keys()
            name = " ".join(x for x in [str(r["fn"] or "") if "fn" in k else "", str(r["ln"] or "") if "ln" in k else ""] if x).strip()
            out.append({"id": int(r["Id"]), "name": name or (str(r["un"] or "") if "un" in k else f"User {r['Id']}"),
                        "username": str(r["un"] or "") if "un" in k else "", "enabled": bool(r["en"]) if "en" in k and r["en"] is not None else True})
        return out

    # ------------------------------------------------------------ documents
    def _doc_date_expr(self) -> str:
        d = self.s.col("Document", "Date")
        c = self.s.col("Document", "DateCreated")
        if d and c:
            return f"substr(COALESCE(d.{q(d)}, d.{q(c)}), 1, 10)"
        return f"substr(d.{q(d or c or 'Date')}, 1, 10)"

    def changed_days(self, since: str | None) -> list[str]:
        """Days with documents added or changed since the last run (or every day, the first time)."""
        if not self.s.has("Document"):
            return []
        de = self._doc_date_expr()
        up = self.s.col("Document", "DateUpdated", "DateCreated")
        if since and up:
            rows = self.rows(f"SELECT DISTINCT {de} AS dd FROM {q(self.s.real('Document'))} d WHERE d.{q(up)} > ? ORDER BY dd", [since])
        else:
            rows = self.rows(f"SELECT DISTINCT {de} AS dd FROM {q(self.s.real('Document'))} d ORDER BY dd")
        return [str(r["dd"]) for r in rows if day(r["dd"])]

    def sales_day(self, d: str) -> dict[str, Any]:
        """Each product sold and refunded on one day (quantities and values including VAT, after discounts)."""
        if not self.s.has("Document") or not self.s.has("DocumentItem"):
            return {"date": d, "lines": []}
        sale_ids = self.type_ids("sale") if self.types else []
        refund_ids = self.type_ids("refund") if self.types else []
        if self.types and not sale_ids:
            self.notes.append("No sales document type (code 200) found.")
        de = self._doc_date_expr()
        tot = self.s.col("DocumentItem", "TotalAfterDocumentDiscount", "Total")
        cost = self.s.col("DocumentItem", "ProductCost")
        ids = sale_ids + refund_ids
        where = f"{de} = ?" + (f" AND d.DocumentTypeId IN ({','.join(str(i) for i in ids)})" if ids else "")
        price = self.s.col("DocumentItem", "Price")
        # 1.0.0 an Aronium without a line total: quantity × price (or nothing) instead of failing the whole read
        val = f"di.{q(tot)}" if tot else (f"di.Quantity * di.{q(price)}" if price else "0")
        sql = (f"SELECT di.ProductId AS pid, d.DocumentTypeId AS tid, SUM(di.Quantity) AS qty, SUM({val}) AS value"
               + (f", SUM(di.{q(cost)} * di.Quantity) AS cost" if cost else "")
               + f" FROM {q(self.s.real('DocumentItem'))} di JOIN {q(self.s.real('Document'))} d ON d.Id = di.DocumentId WHERE {where} GROUP BY di.ProductId, d.DocumentTypeId")
        codes = {p["id"]: (p["code"], p["name"]) for p in self._product_codes()}
        per: dict[int, dict[str, Any]] = {}
        for r in self.rows(sql, [d]):
            pid = int(r["pid"]) if r["pid"] is not None else 0
            x = per.setdefault(pid, {"product_id": pid, "code": codes.get(pid, (str(pid), ""))[0], "name": codes.get(pid, ("", ""))[1],
                                     "sold": 0.0, "sold_value": 0.0, "refunded": 0.0, "refund_value": 0.0, "cost": 0.0})
            refund = int(r["tid"]) in refund_ids
            qn = abs(float(r["qty"] or 0))
            val = abs(float(r["value"] or 0))
            if refund:
                x["refunded"] = round(x["refunded"] + qn, 3)
                x["refund_value"] = r2(x["refund_value"] + val)
            else:
                x["sold"] = round(x["sold"] + qn, 3)
                x["sold_value"] = r2(x["sold_value"] + val)
            if cost and r["cost"] is not None:
                x["cost"] = r2(x["cost"] + (-1 if refund else 1) * abs(float(r["cost"])))
        lines = sorted(per.values(), key=lambda x: x["code"])
        for x in lines:
            x["net"] = round(x["sold"] - x["refunded"], 3)
        return {"date": d, "lines": lines}

    def day_activity(self, d: str) -> dict[str, Any]:
        """One day's pattern: sales by hour (for rosters) and, per cashier, sales, refunds, discounts and voids
        (for the cashier watch). Values include VAT, as on the receipts."""
        out: dict[str, Any] = {"date": d, "hours": {}, "cashiers": {}}
        if not self.s.has("Document"):
            return out
        D = self.s.real("Document")
        sale_ids = set(self.type_ids("sale")) if self.types else set()
        refund_ids = set(self.type_ids("refund")) if self.types else set()
        ids = sale_ids | refund_ids
        de = self._doc_date_expr()
        tcol = self.s.col("Document", "DateCreated", "Date")
        ucol = self.s.col("Document", "UserId")
        dcol = self.s.col("Document", "Discount")
        users = {u["id"]: u["name"] for u in self.users()}
        where = f"{de} = ?" + (f" AND d.DocumentTypeId IN ({','.join(str(i) for i in sorted(ids))})" if ids else "")
        docs = self.rows(f'SELECT d.Id AS id, d.Total AS total, d.DocumentTypeId AS tid, d.{q(tcol)} AS at'
                         f'{", d." + q(ucol) + " AS uid" if ucol else ""}{", d." + q(dcol) + " AS disc" if dcol else ""} FROM {q(D)} d WHERE {where}', [d])
        # discount per document from its lines: what the price list says minus what was charged (works whether
        # Aronium keeps the discount as a percentage or an amount)
        line_disc: dict[int, float] = {}
        if docs and self.s.has("DocumentItem", "Price"):
            tot = self.s.col("DocumentItem", "TotalAfterDocumentDiscount", "Total")
            for r in self.rows(f'SELECT di.DocumentId AS doc, SUM(di.Price * di.Quantity - di.{q(tot)}) AS dd FROM {q(self.s.real("DocumentItem"))} di '
                               f'JOIN {q(D)} d ON d.Id = di.DocumentId WHERE {where} GROUP BY di.DocumentId', [d]):
                v = float(r["dd"] or 0)
                if v > 0.005:
                    line_disc[int(r["doc"])] = v
        hours: dict[str, dict[str, float]] = {}
        cash: dict[str, dict[str, float]] = {}

        def who(r: Any) -> str:
            if "uid" in r.keys() and r["uid"] is not None:
                return users.get(int(r["uid"]), f"User {r['uid']}")
            return "Unknown"
        for r in docs:
            t = abs(float(r["total"] or 0))
            refund = int(r["tid"] or 0) in refund_ids
            at = str(r["at"] or "")
            hh = at[11:13] if len(at) >= 13 and at[11:13].isdigit() else ""
            c = cash.setdefault(who(r), {"sales": 0.0, "receipts": 0, "refunds": 0, "refund_value": 0.0, "discounts": 0, "discount_value": 0.0, "voids": 0, "void_value": 0.0})
            if refund:
                c["refunds"] += 1
                c["refund_value"] = r2(c["refund_value"] + t)
            else:
                c["sales"] = r2(c["sales"] + t)
                c["receipts"] += 1
            disc = line_disc.get(int(r["id"]), 0.0)
            if not refund and disc > 0.005:
                c["discounts"] += 1
                c["discount_value"] = r2(c["discount_value"] + disc)
            if hh:
                h = hours.setdefault(hh, {"value": 0.0, "receipts": 0})
                h["value"] = r2(h["value"] + (-t if refund else t))
                if not refund:
                    h["receipts"] += 1
        if self.s.has("PosVoid"):
            dv = self.s.col("PosVoid", "DateVoided", "DateCreated")
            tc = self.s.col("PosVoid", "Total")
            vu = self.s.col("PosVoid", "UserId")
            if dv:
                for r in self.rows(f'SELECT COUNT(*) AS n{", SUM(" + q(tc) + ") AS t" if tc else ""}{", " + q(vu) + " AS uid" if vu else ""} '
                                   f'FROM {q(self.s.real("PosVoid"))} WHERE substr({q(dv)}, 1, 10) = ?{" GROUP BY " + q(vu) if vu else ""}', [d]):
                    if not int(r["n"] or 0):
                        continue
                    c = cash.setdefault(who(r), {"sales": 0.0, "receipts": 0, "refunds": 0, "refund_value": 0.0, "discounts": 0, "discount_value": 0.0, "voids": 0, "void_value": 0.0})
                    c["voids"] += int(r["n"] or 0)
                    c["void_value"] = r2(c["void_value"] + (abs(float(r["t"] or 0)) if tc else 0.0))
        out["hours"] = dict(sorted(hours.items()))
        out["cashiers"] = cash
        return out

    def day_receipts(self, d: str) -> dict[str, Any]:
        """Each receipt of the day, newest last – time, number, total, how it was paid (and how much each way), who sold it,
        how many lines, refund or not, and whether it is still in the drawer (not yet in an End of day: open 1/0, -1 unknown). Values include VAT, as on the receipts. Read only, like everything else."""
        out: dict[str, Any] = {"date": d, "rows": []}
        if not self.s.has("Document"):
            return out
        D = self.s.real("Document")
        sale_ids = set(self.type_ids("sale")) if self.types else set()
        refund_ids = set(self.type_ids("refund")) if self.types else set()
        ids = sale_ids | refund_ids
        de = self._doc_date_expr()
        tcol = self.s.col("Document", "DateCreated", "Date")
        ucol = self.s.col("Document", "UserId")
        ncol = self.s.col("Document", "Number")
        users = {u["id"]: u["name"] for u in self.users()}
        where = f"{de} = ?" + (f" AND d.DocumentTypeId IN ({','.join(str(i) for i in sorted(ids))})" if ids else "")
        docs = self.rows(f'SELECT d.Id AS id, d.Total AS total, d.DocumentTypeId AS tid, d.{q(tcol)} AS at'
                         f'{", d." + q(ucol) + " AS uid" if ucol else ""}{", d." + q(ncol) + " AS no" if ncol else ""} FROM {q(D)} d WHERE {where} ORDER BY d.{q(tcol)}', [d])
        if not docs:
            return out
        pays: dict[int, list[str]] = {}
        amounts: dict[int, dict[str, float]] = {}
        open_doc: dict[int, int] = {}
        lines: dict[int, int] = {}
        doc_ids = ",".join(str(int(r["id"])) for r in docs)
        if self.s.has("Payment"):
            ptypes: dict[int, str] = {}
            if self.s.has("PaymentType"):
                ptypes = {int(r["Id"]): str(r["Name"] or "") for r in self.rows(f'SELECT Id, Name FROM {q(self.s.real("PaymentType"))}')}
            acol = self.s.col("Payment", "Amount")
            zcol = self.s.col("Payment", "ZReportId")
            sel = f'SELECT DocumentId AS doc, PaymentTypeId AS pt{", " + q(acol) + " AS amt" if acol else ""}{", " + q(zcol) + " AS z" if zcol else ""}'
            for r in self.rows(f'{sel} FROM {q(self.s.real("Payment"))} WHERE DocumentId IN ({doc_ids})'):
                if r["doc"] is None:
                    continue
                k = r.keys()
                doc = int(r["doc"])
                name = ptypes.get(int(r["pt"]), f"Type {r['pt']}") if r["pt"] is not None else "Unknown"
                lst = pays.setdefault(doc, [])
                if name not in lst:
                    lst.append(name)
                if "amt" in k:
                    a = amounts.setdefault(doc, {})
                    a[name] = r2(a.get(name, 0) + float(r["amt"] or 0))
                if "z" in k:
                    # not yet in an End of day (Z report): still in the till drawer
                    open_doc[doc] = 1 if (r["z"] is None or open_doc.get(doc) == 1) else 0
        items: dict[int, list[list[Any]]] = {}
        zof: dict[int, int] = {}
        if self.s.has("Payment") and self.s.col("Payment", "ZReportId"):
            for r in self.rows(f'SELECT DocumentId AS doc, MAX(ZReportId) AS z FROM {q(self.s.real("Payment"))} WHERE DocumentId IN ({doc_ids}) GROUP BY DocumentId'):
                if r["doc"] is not None and _num(r["z"]):
                    zof[int(r["doc"])] = int(float(r["z"]))
        if self.s.has("DocumentItem"):
            for r in self.rows(f'SELECT DocumentId AS doc, COUNT(*) AS n FROM {q(self.s.real("DocumentItem"))} WHERE DocumentId IN ({doc_ids}) GROUP BY DocumentId'):
                lines[int(r["doc"])] = int(r["n"] or 0)
            # 1.0.0 what was sold on each receipt: [code, qty, price, discount, total] per line (values incl. VAT, after
            # discounts; a refund's lines have positive quantities). The app shows the receipt and tallies items sold.
            tot = self.s.col("DocumentItem", "TotalAfterDocumentDiscount", "Total")
            pr = self.s.col("DocumentItem", "Price")
            codes = {p["id"]: p["code"] for p in self._product_codes()} if self.s.has("Product") else {}
            sel = (f'SELECT DocumentId AS doc, ProductId AS pid, Quantity AS qty{", " + q(pr) + " AS price" if pr else ""}{", " + q(tot) + " AS total" if tot else ""} '
                   f'FROM {q(self.s.real("DocumentItem"))} WHERE DocumentId IN ({doc_ids}) ORDER BY DocumentId, Id')
            for r in self.rows(sel):
                if r["doc"] is None:
                    continue
                k = r.keys()
                qty = abs(float(r["qty"])) if _num(r["qty"]) else 0.0
                price = r2(abs(float(r["price"]))) if "price" in k and _num(r["price"]) else 0.0
                total = r2(abs(float(r["total"]))) if "total" in k and _num(r["total"]) else r2(price * qty)
                disc = r2(max(0.0, price * qty - total)) if price else 0.0
                pid = int(float(r["pid"])) if _num(r["pid"]) else 0
                lst = items.setdefault(int(r["doc"]), [])
                if len(lst) < MAX_RECEIPT_LINES:
                    lst.append([codes.get(pid, str(pid)), round(qty, 3), price, disc, total])
        for r in docs:
            k = r.keys()
            at = str(r["at"] or "")
            who = users.get(int(r["uid"]), f"User {r['uid']}") if "uid" in k and r["uid"] is not None else ""
            out["rows"].append({"time": at[11:19] if len(at) >= 19 else at[11:16], "no": str(r["no"] or "") if "no" in k else "", "total": r2(abs(float(r["total"] or 0))),
                                "refund": 1 if int(r["tid"] or 0) in refund_ids else 0, "pay": "+".join(pays.get(int(r["id"]), [])), "who": who, "lines": lines.get(int(r["id"]), 0),
                                "pays": ";".join(f"{n}={abs(v):.2f}" for n, v in amounts.get(int(r["id"]), {}).items()),
                                "open": open_doc.get(int(r["id"]), -1), "z": zof.get(int(r["id"])), "items": items.get(int(r["id"]), [])})
        return out

    def _product_codes(self) -> list[dict[str, Any]]:
        if not hasattr(self, "_codes"):
            code = self.s.col("Product", "Code")
            plu = self.s.col("Product", "PLU")
            # The same code as products() gives: Code, else PLU, else Aronium's own number.
            self._codes = [{"id": int(r["Id"]), "code": str(r["c"] if r["c"] not in (None, "") else (r["p"] if r["p"] not in (None, "") else r["Id"])).strip(), "name": str(r["Name"] or "")}
                           for r in self.rows(f'SELECT Id, Name, {q(code) if code else "NULL"} AS c, {q(plu) if plu else "NULL"} AS p FROM {q(self.s.real("Product"))}')]
        return self._codes

    # ------------------------------------------------------------ End of day (Z reports)
    def z_reports(self, since_day: str | None = None) -> list[dict[str, Any]]:
        """Each End of day with its totals. Payments are linked to their Z report (Payment.ZReportId) in newer
        Aronium; without that, each day is one End of day."""
        P = self.s.real("Payment")
        if not P or not self.s.has("Document"):
            return []
        zcol = self.s.col("Payment", "ZReportId")
        Z = self.s.real("ZReport")
        users = {u["id"]: u["name"] for u in self.users()}
        ptypes = {}
        if self.s.has("PaymentType"):
            ptypes = {int(r["Id"]): str(r["Name"] or "") for r in self.rows(f'SELECT Id, Name FROM {q(self.s.real("PaymentType"))}')}
        pdate = self.s.col("Payment", "DateCreated", "Date")
        groups: list[dict[str, Any]] = []
        if zcol:
            zinfo = {}
            if Z:
                num = self.s.col("ZReport", "Number", "ZReportNumber")
                dt = self.s.col("ZReport", "DateCreated", "Date", "DateTo")
                df = self.s.col("ZReport", "DateFrom", "PeriodStart")
                for r in self.rows(f'SELECT Id{", " + q(num) + " AS num" if num else ""}{", " + q(dt) + " AS dt" if dt else ""}{", " + q(df) + " AS df" if df else ""} FROM {q(Z)}'):
                    k = r.keys()
                    zinfo[int(r["Id"])] = {"number": str(r["num"]) if "num" in k and r["num"] is not None else str(r["Id"]),
                                           "closed_at": str(r["dt"] or "") if "dt" in k else "", "opened_at": str(r["df"] or "") if "df" in k else ""}
            for r in self.rows(f'SELECT DISTINCT {q(zcol)} AS z FROM {q(P)} WHERE {q(zcol)} IS NOT NULL'):
                zid = int(r["z"])
                info = zinfo.get(zid, {"number": str(zid), "closed_at": "", "opened_at": ""})
                groups.append({"key": f"z{zid}", "z_id": zid, **info, "where": f"p.{q(zcol)} = ?", "args": [zid]})
        else:
            self.notes.append("Payments are not linked to Z reports in this Aronium version - each day is one End of day.")
            for d in self.changed_days(None):
                groups.append({"key": f"d{d}", "z_id": None, "number": "", "closed_at": d, "opened_at": d, "where": f"substr(p.{q(pdate)}, 1, 10) = ?", "args": [d]})
        out = []
        for g in groups:
            # Only End of days that may have changed (closed on / after the day asked for) are worked out again.
            if since_day and day(g.get("closed_at")) and day(g.get("closed_at")) < since_day:
                continue
            z = self._z_totals(g, ptypes, users)
            if since_day and z["date"] and z["date"] < since_day:
                continue
            out.append(z)
        return out

    def _z_totals(self, g: dict[str, Any], ptypes: dict[int, str], users: dict[int, str]) -> dict[str, Any]:
        P, D, DI = self.s.real("Payment"), self.s.real("Document"), self.s.real("DocumentItem")
        refund_ids = set(self.type_ids("refund")) if self.types else set()
        pdate = self.s.col("Payment", "DateCreated", "Date")
        puser = self.s.col("Payment", "UserId")
        pays: dict[str, float] = {}
        docs: set[int] = set()
        cashiers: dict[str, float] = {}
        first, last = "", ""
        for r in self.rows(f'SELECT p.DocumentId AS doc, p.PaymentTypeId AS pt, p.Amount AS amt{", p." + q(pdate) + " AS pd" if pdate else ""}{", p." + q(puser) + " AS pu" if puser else ""} FROM {q(P)} p WHERE {g["where"]}', g["args"]):
            k = r.keys()
            name = ptypes.get(int(r["pt"]), f"Type {r['pt']}") if r["pt"] is not None else "Unknown"
            pays[name] = r2(pays.get(name, 0) + float(r["amt"] or 0))
            if r["doc"] is not None:
                docs.add(int(r["doc"]))
            if "pd" in k and r["pd"]:
                s = str(r["pd"])
                first = s if not first or s < first else first
                last = s if not last or s > last else last
            if "pu" in k and r["pu"] is not None:
                who = users.get(int(r["pu"]), f"User {r['pu']}")
                cashiers[who] = r2(cashiers.get(who, 0) + float(r["amt"] or 0))
        total = vat = zero = refunds = discounts = 0.0
        receipts = refund_docs = 0
        if docs:
            ids = ",".join(str(i) for i in sorted(docs))
            disc = self.s.col("Document", "Discount")
            duser = self.s.col("Document", "UserId")
            for r in self.rows(f'SELECT d.Id, d.Total AS total, d.DocumentTypeId AS tid{", d." + q(disc) + " AS disc" if disc else ""}{", d." + q(duser) + " AS du" if duser else ""} FROM {q(D)} d WHERE d.Id IN ({ids})'):
                t = float(r["total"] or 0)
                if int(r["tid"] or 0) in refund_ids:
                    refunds = r2(refunds + abs(t))
                    refund_docs += 1
                else:
                    total = r2(total + t)
                    receipts += 1
                if "du" in r.keys() and r["du"] is not None and not puser:
                    who = users.get(int(r["du"]), f"User {r['du']}")
                    cashiers[who] = r2(cashiers.get(who, 0) + t)
            # VAT from the tax kept on each line; zero rated = lines with no VAT
            tot = self.s.col("DocumentItem", "TotalAfterDocumentDiscount", "Total")
            dsc = self.s.col("DocumentItem", "Discount")
            item_vat: dict[int, float] = {}
            if self.s.has("DocumentItemTax", "Amount"):
                for r in self.rows(f'SELECT dit.DocumentItemId AS iid, SUM(dit.Amount) AS a FROM {q(self.s.real("DocumentItemTax"))} dit JOIN {q(DI)} di ON di.Id = dit.DocumentItemId WHERE di.DocumentId IN ({ids}) GROUP BY dit.DocumentItemId'):
                    item_vat[int(r["iid"])] = float(r["a"] or 0)
            for r in self.rows(f'SELECT di.Id AS iid, di.DocumentId AS doc, di.{q(tot)} AS t{", di." + q(dsc) + " AS dsc" if dsc else ""}, d.DocumentTypeId AS tid FROM {q(DI)} di JOIN {q(D)} d ON d.Id = di.DocumentId WHERE di.DocumentId IN ({ids})'):
                sign = -1 if int(r["tid"] or 0) in refund_ids else 1
                v = item_vat.get(int(r["iid"]), 0.0)
                vat = r2(vat + sign * abs(v))
                if abs(v) < 0.0001:
                    zero = r2(zero + sign * abs(float(r["t"] or 0)))
                if "dsc" in r.keys() and r["dsc"]:
                    discounts = r2(discounts + abs(float(r["dsc"] or 0)))
        # 1.0.0 what each product sold in this End of day (net of refunds) – the cigarette tally per shift in the app
        items: list[list[Any]] = []
        if docs:
            try:
                codes = {p["id"]: p["code"] for p in self._product_codes()}
                per: dict[str, float] = {}
                for chunk in [sorted(docs)[i:i + 400] for i in range(0, len(docs), 400)]:
                    ids2 = ",".join(str(i) for i in chunk)
                    for r in self.rows(f'SELECT di.ProductId AS pid, d.DocumentTypeId AS tid, SUM(di.Quantity) AS qty FROM {q(DI)} di JOIN {q(D)} d ON d.Id = di.DocumentId '
                                       f'WHERE di.DocumentId IN ({ids2}) GROUP BY di.ProductId, d.DocumentTypeId'):
                        pid = int(r["pid"]) if r["pid"] is not None else 0
                        code = codes.get(pid, str(pid))
                        qn = abs(float(r["qty"] or 0)) * (-1 if int(r["tid"] or 0) in refund_ids else 1)
                        per[code] = round(per.get(code, 0.0) + qn, 3)
                items = [[c, n] for c, n in sorted(per.items()) if abs(n) > 0.0005]
            except Exception as e:  # never stops the End of day itself
                self.notes.append(f"End of day products not read: {e}")
        net = r2(total - refunds)
        date = day(g.get("closed_at")) or day(last) or day(first)
        cash = r2(sum(v for k, v in pays.items() if "cash" in k.lower()))
        card = r2(sum(v for k, v in pays.items() if any(w in k.lower() for w in ("card", "eftpos", "visa", "master", "debit", "credit card"))))
        other = r2(sum(pays.values()) - cash - card)
        return {
            "key": g["key"], "z_id": g["z_id"], "number": g["number"], "date": date, "opened_at": g.get("opened_at") or first, "closed_at": g.get("closed_at") or last,
            "total": net, "sales": total, "refunds": refunds, "vat": vat, "zero": zero, "discounts": discounts,
            "receipts": receipts, "refund_receipts": refund_docs, "payments": pays, "cash": cash, "card": card, "other": other,
            "cashiers": cashiers, "voids": self._voids(first, last), "float": self._starting_cash(g), "items": items,
        }

    def _voids(self, first: str, last: str) -> dict[str, Any]:
        if not self.s.has("PosVoid") or not first:
            return {"count": 0, "total": 0.0}
        dv = self.s.col("PosVoid", "DateVoided", "DateCreated")
        tc = self.s.col("PosVoid", "Total")
        if not dv:
            return {"count": 0, "total": 0.0}
        r = self.rows(f'SELECT COUNT(*) AS n{", SUM(" + q(tc) + ") AS t" if tc else ""} FROM {q(self.s.real("PosVoid"))} WHERE {q(dv)} >= ? AND {q(dv)} <= ?', [first, last])[0]
        return {"count": int(r["n"] or 0), "total": r2(r["t"]) if tc else 0.0}

    def _starting_cash(self, g: dict[str, Any]) -> dict[str, float]:
        """Opening float and cash put in / taken out (StartingCash), for this Z when Aronium links them."""
        if not self.s.has("StartingCash", "Amount"):
            return {}
        zn = self.s.col("StartingCash", "ZReportNumber", "ZReportId")
        ty = self.s.col("StartingCash", "StartingCashType")
        if not zn or g["z_id"] is None:
            return {}
        out: dict[str, float] = {}
        for r in self.rows(f'SELECT Amount AS a{", " + q(ty) + " AS t" if ty else ""} FROM {q(self.s.real("StartingCash"))} WHERE {q(zn)} IN (?, ?)', [g["z_id"], g["number"]]):
            t = str(r["t"]) if ty and r["t"] is not None else "0"
            name = {"0": "opening", "1": "cash_in", "2": "cash_out"}.get(t, f"type_{t}")
            out[name] = r2(out.get(name, 0) + float(r["a"] or 0))
        return out

    # ------------------------------------------------------------ staff credit (customers' unpaid sales)
    def credit(self) -> list[dict[str, Any]]:
        if not self.s.has("Document", "CustomerId") or not self.s.has("Customer"):
            return []
        sale_ids = self.type_ids("sale") + self.type_ids("refund") if self.types else []
        refund_ids = set(self.type_ids("refund")) if self.types else set()
        where = f"d.CustomerId IS NOT NULL" + (f" AND d.DocumentTypeId IN ({','.join(str(i) for i in sale_ids)})" if sale_ids else "")
        paid: dict[int, float] = {}
        if self.s.has("Payment"):
            mark = self.s.col("PaymentType", "MarkAsPaid") if self.s.has("PaymentType") else None
            # Payments of a type that only marks the sale as paid (e.g. "Account") are not money received.
            join = f' LEFT JOIN {q(self.s.real("PaymentType"))} pt ON pt.Id = p.PaymentTypeId' if mark else ""
            cond = f" WHERE COALESCE(pt.{q(mark)}, 1) <> 0 OR pt.{q(mark)} IS NULL" if mark else ""
            for r in self.rows(f'SELECT p.DocumentId AS doc, SUM(p.Amount) AS a FROM {q(self.s.real("Payment"))} p{join}{cond} GROUP BY p.DocumentId'):
                if r["doc"] is not None:
                    paid[int(r["doc"])] = float(r["a"] or 0)
        names = {p["id"]: p["name"] for p in self.parties()}
        per: dict[int, dict[str, Any]] = {}
        de = self._doc_date_expr()
        for r in self.rows(f'SELECT d.Id AS id, d.CustomerId AS cid, d.Total AS total, d.DocumentTypeId AS tid, {de} AS dd FROM {q(self.s.real("Document"))} d WHERE {where}'):
            t = abs(float(r["total"] or 0))
            sign = -1 if int(r["tid"] or 0) in refund_ids else 1
            owing = sign * t - (sign * abs(paid.get(int(r["id"]), 0.0)))
            if abs(owing) < 0.005:
                continue
            x = per.setdefault(int(r["cid"]), {"customer_id": int(r["cid"]), "name": names.get(int(r["cid"]), ""), "owing": 0.0, "documents": 0, "oldest": ""})
            x["owing"] = r2(x["owing"] + owing)
            x["documents"] += 1
            dd = day(r["dd"])
            if dd and (not x["oldest"] or dd < x["oldest"]):
                x["oldest"] = dd
        return [x for x in per.values() if abs(x["owing"]) >= 0.005]

    # ------------------------------------------------------------ credit trail (1.2)
    def credit_trail(self, since_day: str) -> list[dict[str, Any]]:
        """Every sale on a customer's account (staff credit, a business on a weekly account): the sales still owing,
        and every sale or payment since since_day - the trail behind the balance. Each sale: date, number, total,
        what was bought, the payments against it (date, how, amount, and what the app needs to tell money from
        an "on account" mark). Read only."""
        if not self.s.has("Document", "CustomerId") or not self.s.has("Customer"):
            return []
        sale_ids = self.type_ids("sale") + self.type_ids("refund") if self.types else []
        refund_ids = set(self.type_ids("refund")) if self.types else set()
        D = self.s.real("Document")
        de = self._doc_date_expr()
        num = self.s.col("Document", "Number")
        where = "d.CustomerId IS NOT NULL" + (f" AND d.DocumentTypeId IN ({','.join(str(i) for i in sale_ids)})" if sale_ids else "")
        names = {p["id"]: p["name"] for p in self.parties()}
        ptypes: dict[int, dict[str, Any]] = {}
        if self.s.has("PaymentType"):
            mark = self.s.col("PaymentType", "MarkAsPaid")
            for r in self.rows(f'SELECT Id, Name{", " + q(mark) + " AS mk" if mark else ""} FROM {q(self.s.real("PaymentType"))}'):
                ptypes[int(r["Id"])] = {"name": str(r["Name"] or ""), "money": (int(r["mk"]) != 0) if mark and r["mk"] is not None else True}
        pays: dict[int, list[dict[str, Any]]] = {}
        if self.s.has("Payment"):
            pdate = self.s.col("Payment", "DateCreated", "Date")
            for r in self.rows(f'SELECT p.DocumentId AS doc, p.PaymentTypeId AS pt, p.Amount AS amt{", p." + q(pdate) + " AS pd" if pdate else ""} FROM {q(self.s.real("Payment"))} p JOIN {q(D)} d ON d.Id = p.DocumentId WHERE {where}'):
                if r["doc"] is None:
                    continue
                t = ptypes.get(int(r["pt"])) if r["pt"] is not None else None
                pays.setdefault(int(r["doc"]), []).append({"date": day(r["pd"]) if "pd" in r.keys() else "", "type": t["name"] if t else "", "money": t["money"] if t else True, "amount": r2(r["amt"])})
        docs = []
        for r in self.rows(f'SELECT d.Id AS id, d.CustomerId AS cid, d.Total AS total, d.DocumentTypeId AS tid, {de} AS dd{", d." + q(num) + " AS num" if num else ""} FROM {q(D)} d WHERE {where} ORDER BY dd'):
            refund = int(r["tid"] or 0) in refund_ids
            total = abs(float(r["total"] or 0)) * (-1 if refund else 1)
            plist = pays.get(int(r["id"]), [])
            paid = r2(sum(abs(p["amount"]) for p in plist if p["money"]) * (-1 if refund else 1))
            owing = r2(total - paid)
            dd = day(r["dd"])
            recent = bool(dd and dd >= since_day) or any(p["date"] and p["date"] >= since_day for p in plist)
            if abs(owing) < 0.005 and not recent:
                continue
            docs.append({"id": int(r["id"]), "customer_id": int(r["cid"]), "customer": names.get(int(r["cid"]), ""), "number": str(r["num"] or "") if num else "",
                         "date": dd, "total": r2(total), "paid": paid, "owing": owing, "refund": refund, "payments": plist})
        if docs and self.s.has("DocumentItem"):
            DI = self.s.real("DocumentItem")
            tot = self.s.col("DocumentItem", "TotalAfterDocumentDiscount", "Total")
            pname = {p["id"]: p["name"] for p in self._product_codes()} if self.s.has("Product") else {}
            by_doc: dict[int, list] = {}
            ids = [d["id"] for d in docs]
            for i in range(0, len(ids), 400):
                chunk = ",".join(str(x) for x in ids[i:i + 400])
                for r in self.rows(f'SELECT DocumentId AS doc, ProductId AS pid, Quantity AS qty{", " + q(tot) + " AS t" if tot else ""} FROM {q(DI)} WHERE DocumentId IN ({chunk})'):
                    lst = by_doc.setdefault(int(r["doc"]), [])
                    if len(lst) < 25:
                        lst.append([pname.get(int(r["pid"]), "") if r["pid"] is not None else "", r4(r["qty"]), r2(r["t"]) if "t" in r.keys() else None])
            for d in docs:
                d["items"] = by_doc.get(d["id"], [])
        return docs

    # ------------------------------------------------------------ purchases
    def purchases(self, since_day: str) -> list[dict[str, Any]]:
        ids = self.type_ids("purchase") if self.types else []
        if not ids or not self.s.has("Document"):
            return []
        de = self._doc_date_expr()
        ref = self.s.col("Document", "ReferenceDocumentNumber")
        names = {p["id"]: p["name"] for p in self.parties()}
        out = []
        for r in self.rows(f'SELECT d.Id AS id, d.Number AS num, d.CustomerId AS cid, d.Total AS total, {de} AS dd{", d." + q(ref) + " AS ref" if ref else ""} FROM {q(self.s.real("Document"))} d WHERE d.DocumentTypeId IN ({",".join(str(i) for i in ids)}) AND {de} >= ? ORDER BY dd', [since_day]):
            out.append({"id": int(r["id"]), "number": str(r["num"] or ""), "supplier": names.get(int(r["cid"])) if r["cid"] is not None else "",
                        "date": day(r["dd"]), "total": r2(r["total"]), "reference": str(r["ref"] or "") if ref else ""})
        return out

    # ------------------------------------------------------------ health check
    def meta(self) -> dict[str, Any]:
        counts = {}
        for t in ("Product", "Customer", "Document", "DocumentItem", "Payment", "User", "ZReport", "PosVoid", "StartingCash", "Stock"):
            real = self.s.real(t)
            if real:
                counts[t] = int(self.rows(f"SELECT COUNT(*) AS n FROM {q(real)}")[0]["n"])
        ptypes = []
        if self.s.has("PaymentType"):
            ptypes = [{"id": int(r["Id"]), "name": str(r["Name"] or "")} for r in self.rows(f'SELECT Id, Name FROM {q(self.s.real("PaymentType"))}')]
        taxes = []
        if self.s.has("Tax"):
            taxes = [{"id": int(r["Id"]), "name": str(r["Name"] or ""), "rate": float(r["Rate"] or 0)} for r in self.rows(f'SELECT Id, Name, Rate FROM {q(self.s.real("Tax"))}')]
        per_type = {}
        if self.s.has("Document"):
            for r in self.rows(f'SELECT DocumentTypeId AS t, COUNT(*) AS n FROM {q(self.s.real("Document"))} GROUP BY DocumentTypeId'):
                per_type[str(r["t"])] = int(r["n"])
        return {
            "counts": counts, "document_types": [{"id": i, **t, "documents": per_type.get(str(i), 0)} for i, t in self.types.items()],
            "payment_types": ptypes, "taxes": taxes, "has_z_link": bool(self.s.col("Payment", "ZReportId")),
            "drawer": self.open_drawer(),
            "notes": sorted(set(self.notes)),
        }

    def open_drawer(self) -> dict[str, float]:
        """The till drawer since the last End of day: opening float and cash put in / taken out (StartingCash rows not
        yet in a Z report). Empty when this Aronium does not keep them. Read only."""
        try:
            if not self.s.has("StartingCash", "Amount"):
                return {}
            zn = self.s.col("StartingCash", "ZReportNumber", "ZReportId")
            ty = self.s.col("StartingCash", "StartingCashType")
            if not zn:
                return {}
            known: set[int] = set()
            if self.s.has("ZReport"):
                zc = self.s.col("ZReport", "Number")
                for r in self.rows(f'SELECT Id{", " + q(zc) + " AS n" if zc else ""} FROM {q(self.s.real("ZReport"))}'):
                    known.add(int(r["Id"]))
                    if zc and r["n"] is not None:
                        try:
                            known.add(int(r["n"]))
                        except (TypeError, ValueError):
                            pass
            out: dict[str, float] = {}
            for r in self.rows(f'SELECT Amount AS a, {q(zn)} AS z{", " + q(ty) + " AS t" if ty else ""} FROM {q(self.s.real("StartingCash"))}'):
                try:
                    if r["z"] is not None and int(r["z"]) in known:
                        continue
                except (TypeError, ValueError):
                    continue
                t = str(r["t"]) if ty and r["t"] is not None else "0"
                name = {"0": "opening", "1": "cash_in", "2": "cash_out"}.get(t, f"type_{t}")
                out[name] = r2(out.get(name, 0) + float(r["a"] or 0))
            return out
        except Exception:  # never let the drawer stop the rest from being sent
            return {}


def snapshot(path: str | os.PathLike, work_dir: str | os.PathLike) -> Path:
    """A private copy of the Aronium database to read from, made with SQLite's own backup (a reader, page by page,
    so the till is never held up for long). Aronium's file is only read. The copy is replaced every run."""
    src = open_read_only(path)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    dest_path = work / "aronium-copy.db"
    tmp = work / "aronium-copy.db.part"
    if tmp.exists():
        tmp.unlink()
    try:
        with closing(sqlite3.connect(tmp)) as dest:
            src.backup(dest, pages=2000, sleep=0.05)
        os.replace(tmp, dest_path)
    finally:
        src.close()
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
    return dest_path


def trail_from(since_day: str | None, oldest: str | None) -> str:
    """The credit trail goes back 120 days (or to the oldest day sent, if that is later)."""
    import datetime as _dt
    d = (_dt.date.today() - _dt.timedelta(days=120)).isoformat()
    return max(d, oldest) if oldest else d


RECEIPT_DAYS = 90  # receipts (with their lines) are only ever sent for the last 90 days; older days keep their totals


def receipts_from(days: int = RECEIPT_DAYS, today: str | None = None) -> str:
    import datetime as _dt
    t = _dt.date.fromisoformat(today) if today else _dt.date.today()
    return (t - _dt.timedelta(days=max(1, int(days)) - 1)).isoformat()


def read_live(path: str | os.PathLike, *, day: str) -> dict[str, Any]:
    """1.0.0 the quick read after a sale (about every 30 seconds while the till is busy): only this day's receipts
    (with their lines), its sales by hour / cashier, the open End of day and the drawer. Straight from Aronium's file,
    read only, no copy (a copy of a big database every 30 seconds would slow the till PC); a few small SELECTs."""
    with closing(open_read_only(path)) as conn:
        a = Aronium(conn)
        out = {"receipts": [a.day_receipts(day)], "activity": [a.day_activity(day)], "z": a.z_reports(since_day=day), "live": True}
        out["meta"] = {"drawer": a.open_drawer()}
        return out


def read_all(path: str | os.PathLike, *, since: str | None = None, since_day: str | None = None, oldest: str | None = None,
             work_dir: str | os.PathLike | None = None, receipt_from: str | None = None) -> dict[str, Any]:
    """Everything, read in one go (the database is closed afterwards).
    since      - only days with documents changed after this time (None = every day)
    since_day  - these recent days are always read again (late changes, an End of day closed after midnight)
    oldest     - nothing older than this day is read (how far back the first send goes)
    work_dir   - when given, a private copy is read instead of Aronium's own file"""
    src = snapshot(path, work_dir) if work_dir else path
    with closing(open_read_only(src)) as conn:
        a = Aronium(conn)
        days = set(a.changed_days(since))
        if since_day:
            days |= {d for d in a.changed_days(None) if d >= since_day}
        days = sorted(d for d in days if not oldest or d >= oldest)
        z_from = max(x for x in (since_day, oldest) if x) if (since_day or oldest) else None
        out = {
            "products": a.products(), "parties": a.parties(), "users": a.users(),
            "sales_days": [a.sales_day(d) for d in days],
            "activity": [a.day_activity(d) for d in days],
            "receipts": [a.day_receipts(d) for d in days if not receipt_from or d >= receipt_from],
            "z": a.z_reports(since_day=z_from), "credit": a.credit(),
            "credit_trail": a.credit_trail(trail_from(since_day, oldest)),
            "purchases": a.purchases(z_from or "0000-00-00"),
        }
        out["meta"] = a.meta()
        up = a.s.col("Document", "DateUpdated", "DateCreated") if a.s.has("Document") else None
        out["newest_update"] = str(a.rows(f'SELECT MAX({q(up)}) AS m FROM {q(a.s.real("Document"))}')[0]["m"] or "") if up else ""
        return out
