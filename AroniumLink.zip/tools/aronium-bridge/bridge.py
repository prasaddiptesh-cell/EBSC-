"""Easy Buys Aronium link - the work itself (also usable from the command line).

  EasyBuysAroniumLink.exe --watch      stay in the background: send soon after Aronium changes, and every 15 minutes
                                       (what Windows starts; a second copy sees the first one and stops at once)
  EasyBuysAroniumLink.exe --run        read Aronium and send the changes once
  EasyBuysAroniumLink.exe --check      check Aronium and the settings, send nothing
  EasyBuysAroniumLink.exe --resend     send everything again next run

Aronium is only ever read (see aronium_read.py). Nothing here can change, delete or add anything in Aronium.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Callable

import aronium_read
import config
import feed

TASK_NAME = "Easy Buys Aronium Link"


def logger() -> logging.Logger:
    log = logging.getLogger("easybuys-link")
    if not log.handlers:
        log.setLevel(logging.INFO)
        h = RotatingFileHandler(config.home() / "link.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%Y-%m-%d %H:%M:%S"))
        log.addHandler(h)
    return log


class RunLock:
    """Only one run at a time (a slow send must not overlap the next scheduled one)."""

    def __init__(self, name: str = "run.lock") -> None:
        self.path = config.home() / name
        self.fh = None

    def __enter__(self) -> "RunLock":
        self.fh = open(self.path, "a+")
        try:
            self.fh.seek(0)
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.fh.close()
            self.fh = None
            raise RuntimeError("Already sending (another run is busy) - it will finish on its own.") from None
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.fh:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    self.fh.seek(0)
                    msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.fh.close()


def state() -> feed.State:
    return feed.State(config.home() / "sent.db")


def reader(cfg: dict[str, Any]) -> Callable[..., dict[str, Any]]:
    work = config.home() / "work"

    def read(path: str, **kw: Any) -> dict[str, Any]:
        return aronium_read.read_all(path, work_dir=work, **kw)
    return read


def run(cfg: dict[str, Any] | None = None, *, say: Callable[[str], None] | None = None, post=None) -> dict[str, Any]:
    """One run: read, send. Never raises - every problem comes back as {"ok": False, "error": ...}."""
    cfg = cfg or config.load()
    log = logger()

    def out(msg: str) -> None:
        log.info(msg)
        if say:
            say(msg)
    missing = config.problems(cfg)
    if missing:
        out("Not ready: " + " ".join(missing))
        return {"ok": False, "error": " ".join(missing)}
    try:
        with RunLock():
            res = feed.run_once(cfg, state(), read=reader(cfg), post=post, log=out)
        return {"ok": not res["error"], "error": res["error"], "sent": len(res["sent"]), "waiting": res["waiting"]}
    except Exception as exc:  # noqa: BLE001 - the link must never crash; the next run tries again
        log.error("Problem: %s\n%s", exc, traceback.format_exc())
        out(f"Problem: {exc}")
        return {"ok": False, "error": str(exc)}


# ------------------------------------------------------------------ watching Aronium
def db_signature(path: str) -> tuple:
    """When Aronium saves a sale its database file (and its -wal file, if any) changes: size and time are enough."""
    sig = []
    for p in (str(path), str(path) + "-wal"):
        try:
            st = os.stat(p)
            sig.append((st.st_size, int(st.st_mtime)))
        except OSError:
            sig.append(None)
    return tuple(sig)


def stop_flag() -> Path:
    return config.home() / "stopped"


def watch_step(w: dict[str, Any], now: float, cfg: dict[str, Any]) -> str | None:
    """Decide what to do this moment: 'change' (Aronium changed and has been quiet 30 s), 'periodic', or None.
    w keeps: sig (last seen), changed_at (when a change was first seen, 0 = none waiting), last_run."""
    every = max(5.0, float(cfg.get("every_min", 15))) * 60
    gap = max(1.0, float(cfg.get("watch_gap_min", 2))) * 60
    sig = db_signature(cfg.get("database_path", ""))
    if w.get("sig") is None:
        w["sig"] = sig
    elif sig != w["sig"]:
        w["sig"] = sig
        w["changed_at"] = now if not w.get("changed_at") else w["changed_at"]
        w["quiet_from"] = now
    if not w.get("last_run") or now - w["last_run"] >= every:
        return "periodic"
    if w.get("changed_at") and now - w.get("quiet_from", now) >= 30 and now - w["last_run"] >= gap:
        return "change"
    if w.get("changed_at") and now - w["changed_at"] >= 10 * 60 and now - w["last_run"] >= gap:
        return "change"  # busy without a pause for 10 minutes: send anyway
    return None


def watch(*, post=None, sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.time,
          max_loops: int | None = None) -> int:
    """Stay in the background. Never raises; ends when 'Stop sending on its own' was pressed."""
    log = logger()
    try:
        lock = RunLock("watch.lock")
        lock.__enter__()
    except RuntimeError:
        return 0  # already watching
    except Exception:  # noqa: BLE001
        return 0
    log.info("Watching Aronium for changes.")
    w: dict[str, Any] = {}
    loops = 0
    try:
        while max_loops is None or loops < max_loops:
            loops += 1
            try:
                if stop_flag().exists():
                    log.info("Stopped (sending on its own was switched off).")
                    return 0
                cfg = config.load()
                if not config.problems(cfg):
                    what = watch_step(w, clock(), cfg)
                    if what:
                        w["last_run"] = clock()
                        w["changed_at"] = 0
                        run_cfg = dict(cfg)
                        if what == "change":
                            run_cfg["sales_every_min"] = 0  # today's sales and the open End of day go now
                        run(run_cfg, post=post)
            except Exception as exc:  # noqa: BLE001 - never stops watching; tries again next time
                try:
                    log.error("Watch problem: %s", exc)
                except Exception:  # noqa: BLE001
                    pass
            sleep(20)
    finally:
        lock.__exit__(None, None, None)
    return 0


def check(cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """Look at Aronium and the settings without sending anything. Returns {ok, lines}."""
    cfg = cfg or config.load()
    lines: list[str] = []
    ok = True
    for m in config.problems(cfg):
        lines.append("✗ " + m)
        ok = False
    db = cfg.get("database_path")
    if db and Path(str(db)).is_file():
        try:
            from contextlib import closing
            with closing(aronium_read.open_read_only(db)) as conn:
                a = aronium_read.Aronium(conn)
                meta = a.meta()
                c = meta["counts"]
                lines.append(f"✓ Aronium found: {c.get('Product', 0)} products, {c.get('Document', 0)} documents, "
                             f"{c.get('Customer', 0)} customers / suppliers, {c.get('ZReport', 0)} End of days.")
                sales = [t for t in meta["document_types"] if t["kind"] == "sale"]
                lines.append("✓ Sales documents found." if sales else "! No sales document type found - sales may not come through.")
                lines.append("✓ End of days are linked to payments." if meta["has_z_link"] else "! This Aronium does not link payments to End of day - each day is sent as one End of day.")
                for n in meta["notes"]:
                    lines.append("! " + n)
        except Exception as exc:  # noqa: BLE001
            ok = False
            lines.append(f"✗ Could not read the Aronium database: {exc}")
    st = state()
    last_ok = st.get("last_ok")
    lines.append(f"Last sent: {last_ok.replace('T', ' ')[:16]} (UTC)" if last_ok else "Nothing sent yet.")
    w = st.waiting_count()
    if w:
        lines.append(f"Waiting to send: {w}." + (f" Last problem: {st.last_error()}" if st.last_error() else ""))
    lines.append(f"This till is {cfg['source_id']} ({cfg['till_name']}).")
    return {"ok": ok, "lines": lines}


# ------------------------------------------------------------------ Windows Task Scheduler
def program_command(mode: str = "--watch") -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, mode]
    return [sys.executable.replace("python.exe", "pythonw.exe"), str(Path(__file__).with_name("app.py")), mode]


def task_xml(every_min: int) -> str:
    """Windows task: starts the watcher at logon and every N minutes (a running watcher makes the extra start stop at
    once), also on battery, with no time limit, and starts a missed run as soon as possible."""
    from xml.sax.saxutils import escape
    cmd = program_command("--watch")
    start = time.strftime("%Y-%m-%dT%H:%M:00")
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Easy Buys: sends Aronium figures to the Easy Buys app (reads Aronium only).</Description></RegistrationInfo>
  <Triggers>
    <LogonTrigger><Enabled>true</Enabled></LogonTrigger>
    <TimeTrigger><StartBoundary>{start}</StartBoundary><Enabled>true</Enabled>
      <Repetition><Interval>PT{max(5, int(every_min))}M</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition></TimeTrigger>
  </Triggers>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <AllowHardTerminate>true</AllowHardTerminate>
    <Enabled>true</Enabled>
  </Settings>
  <Actions><Exec><Command>{escape(cmd[0])}</Command><Arguments>{escape(" ".join(f'"{c}"' if " " in c else c for c in cmd[1:]))}</Arguments></Exec></Actions>
</Task>
"""


def schedule_on(every_min: int) -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Automatic sending can only be set up on Windows."
    try:
        stop_flag().unlink()
    except OSError:
        pass
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    xml = config.home() / "task.xml"
    try:
        xml.write_text(task_xml(every_min), encoding="utf-16")
        r = subprocess.run(["schtasks", "/Create", "/F", "/TN", TASK_NAME, "/XML", str(xml)], capture_output=True, text=True, creationflags=flags)
    except Exception as exc:  # noqa: BLE001
        r = None
        logger().error("Task XML: %s", exc)
    if r is None or r.returncode != 0:  # the simple way: every N minutes
        cmd = " ".join(f'"{c}"' for c in program_command("--watch"))
        r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "MINUTE", "/MO", str(max(5, int(every_min))), "/TN", TASK_NAME, "/TR", cmd],
                           capture_output=True, text=True, creationflags=flags)
    if r.returncode == 0:  # start watching straight away, without waiting for the first trigger
        subprocess.run(["schtasks", "/Run", "/TN", TASK_NAME], capture_output=True, text=True, creationflags=flags)
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_off() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Only on Windows."
    try:
        stop_flag().write_text("stopped", encoding="utf-8")  # the watcher sees this within 20 seconds and ends
    except OSError:
        pass
    r = subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_is_on() -> bool:
    if sys.platform != "win32":
        return False
    r = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--check" in args:
        res = check()
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    if "--resend" in args:
        state().forget_sent()
        print("Everything will be sent again on the next run.")
        return 0
    if "--watch" in args:
        return watch()
    if "--run" in args:
        res = run(say=None if os.environ.get("EASYBUYS_QUIET") else print)
        return 0 if res["ok"] else 1
    print(__doc__)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
