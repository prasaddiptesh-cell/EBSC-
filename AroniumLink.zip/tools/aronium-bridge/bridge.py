"""Easy Buys Aronium link - the work itself (also usable from the command line).

  EasyBuysAroniumLink.exe --watch      stay in the background: send soon after Aronium changes, and every 15 minutes
                                       (what Windows starts; a second copy sees the first one and stops at once)
  EasyBuysAroniumLink.exe --run        read Aronium and send the changes once
  EasyBuysAroniumLink.exe --check      check Aronium and the settings, send nothing
  EasyBuysAroniumLink.exe --resend     send everything again next run

Aronium is only ever read (see aronium_read.py). Nothing here can change, delete or add anything in Aronium.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import time
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Callable

import aronium_read
import build_info
import config
import feed

TASK_NAME = "Easy Buys Aronium Link"


def logger() -> logging.Logger:
    log = logging.getLogger("easybuys-link")
    if not log.handlers:
        log.setLevel(logging.INFO)
        h = RotatingFileHandler(config.home() / "link.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%Y-%m-%d %H:%M:%S"))
        log.addHandler(h)
    return log


class RunLock:
    """Only one run at a time (a slow send must not overlap the next scheduled one)."""

    def __init__(self, name: str = "run.lock") -> None:
        self.path = config.home() / name
        self.fh = None

    def __enter__(self) -> "RunLock":
        self.fh = open(self.path, "a+")
        try:
            self.fh.seek(0)
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.fh.close()
            self.fh = None
            raise RuntimeError("Already sending (another run is busy) - it will finish on its own.") from None
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.fh:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    self.fh.seek(0)
                    msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.fh.close()


def state() -> feed.State:
    return feed.State(config.home() / "sent.db")


def reader(cfg: dict[str, Any]) -> Callable[..., dict[str, Any]]:
    work = config.home() / "work"

    def read(path: str, **kw: Any) -> dict[str, Any]:
        return aronium_read.read_all(path, work_dir=work, **kw)
    return read


def run(cfg: dict[str, Any] | None = None, *, say: Callable[[str], None] | None = None, post=None) -> dict[str, Any]:
    """One run: read, send. Never raises - every problem comes back as {"ok": False, "error": ...}."""
    cfg = cfg or config.load()
    log = logger()

    def out(msg: str) -> None:
        log.info(msg)
        if say:
            say(msg)
    missing = config.problems(cfg)
    if missing:
        out("Not ready: " + " ".join(missing))
        return {"ok": False, "error": " ".join(missing)}
    try:
        with RunLock():
            res = feed.run_once(cfg, state(), read=reader(cfg), post=post, log=out)
        return {"ok": not res["error"], "error": res["error"], "sent": len(res["sent"]), "waiting": res["waiting"]}
    except Exception as exc:  # noqa: BLE001 - the link must never crash; the next run tries again
        log.error("Problem: %s\n%s", exc, traceback.format_exc())
        out(f"Problem: {exc}")
        return {"ok": False, "error": str(exc)}


# ------------------------------------------------------------------ watching Aronium
def db_signature(path: str) -> tuple:
    """When Aronium saves a sale its database file (and its -wal file, if any) changes: size and time are enough."""
    sig = []
    for p in (str(path), str(path) + "-wal"):
        try:
            st = os.stat(p)
            sig.append((st.st_size, int(st.st_mtime)))
        except OSError:
            sig.append(None)
    return tuple(sig)


KINDS = {"sales_day": ("sales day", "sales days"), "z": ("End of day", "End of days"), "activity": ("hourly / cashier day", "hourly / cashier days"), "receipts": ("receipts day", "receipts days"),
         "products": ("products list", "products list"), "stock": ("stock list", "stock list"), "parties": ("customers / suppliers list", "customers / suppliers list"),
         "users": ("cashier list", "cashier list"), "credit": ("customer credit list", "customer credit list"), "credit_trail": ("credit sales list", "credit sales list"), "purchases": ("purchases day", "purchases days"),
         "meta": ("health check", "health check")}


def local_time(iso_text: str | None) -> str:
    """'2026-10-11T09:42:10.123Z' → '11 Oct 9:42 pm' in this PC's time."""
    if not iso_text:
        return ""
    try:
        from datetime import datetime
        t = datetime.fromisoformat(str(iso_text).replace("Z", "+00:00")).astimezone()
        return f"{t.day} {t.strftime('%b')} {t.strftime('%I:%M %p').lstrip('0').lower()}"
    except Exception:  # noqa: BLE001
        return str(iso_text)[:16].replace("T", " ")


def watch_running() -> bool:
    """True when the background watcher has checked in within the last 90 seconds (it touches watch.beat every 20 s)."""
    try:
        return time.time() - os.stat(config.home() / "watch.beat").st_mtime < 90
    except OSError:
        return False


def status() -> dict[str, Any]:
    """Everything the window's Status card shows. Never raises."""
    out: dict[str, Any] = {"auto": False, "watching": False, "last_run": "", "last_result": "", "last_ok": "", "waiting": 0,
                           "waiting_text": "", "problem": "", "sent": 0}
    try:
        out["auto"] = schedule_is_on()
    except Exception:  # noqa: BLE001
        pass
    out["watching"] = watch_running()
    try:
        st = state()
        out["last_run"] = local_time(st.get("last_run"))
        res = st.get("last_result") or ""
        out["last_result"] = "" if res in ("", "ok") else res
        out["last_ok"] = local_time(st.get("last_ok"))
        out["waiting"] = st.waiting_count()
        out["sent"] = st.sent_count()
        parts = []
        for kind, periods in st.waiting_summary().items():
            one, many = KINDS.get(kind, (kind, kind))
            n = len(periods)
            dated = [p for p in periods if len(p) == 10 and p[4] == "-"]
            when = f" ({', '.join(local_day(p) for p in dated[:3])}{'…' if len(dated) > 3 else ''})" if dated else ""
            parts.append(f"{n} {one if n == 1 else many}{when}" if one != many else one)
        out["waiting_text"] = "; ".join(parts)
        out["problem"] = st.last_error()
    except Exception as exc:  # noqa: BLE001
        out["problem"] = str(exc)
    return out


def local_day(d: str) -> str:
    try:
        from datetime import date
        x = date.fromisoformat(d)
        return f"{x.day} {x.strftime('%b')}"
    except Exception:  # noqa: BLE001
        return d


def stop_flag() -> Path:
    return config.home() / "stopped"


def watch_step(w: dict[str, Any], now: float, cfg: dict[str, Any]) -> str | None:
    """Decide what to do this moment: 'change' (Aronium changed and has been quiet 30 s), 'periodic', or None.
    w keeps: sig (last seen), changed_at (when a change was first seen, 0 = none waiting), last_run."""
    every = max(5.0, float(cfg.get("every_min", 15))) * 60
    gap = max(1.0, float(cfg.get("watch_gap_min", 2))) * 60
    sig = db_signature(cfg.get("database_path", ""))
    if w.get("sig") is None:
        w["sig"] = sig
    elif sig != w["sig"]:
        w["sig"] = sig
        w["changed_at"] = now if not w.get("changed_at") else w["changed_at"]
        w["quiet_from"] = now
    if not w.get("last_run") or now - w["last_run"] >= every:
        return "periodic"
    if w.get("changed_at") and now - w.get("quiet_from", now) >= 15 and now - w["last_run"] >= gap:
        return "change"
    if w.get("changed_at") and now - w["changed_at"] >= 10 * 60 and now - w["last_run"] >= gap:
        return "change"  # busy without a pause for 10 minutes: send anyway
    return None


def watch(*, post=None, sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.time,
          max_loops: int | None = None) -> int:
    """Stay in the background. Never raises; ends when 'Stop sending on its own' was pressed."""
    log = logger()
    try:
        lock = RunLock("watch.lock")
        lock.__enter__()
    except RuntimeError:
        return 0  # already watching
    except Exception:  # noqa: BLE001
        return 0
    log.info("Watching Aronium for changes.")
    w: dict[str, Any] = {}
    loops = 0
    try:
        while max_loops is None or loops < max_loops:
            loops += 1
            try:
                try:
                    (config.home() / "watch.beat").write_text(str(int(clock())), encoding="utf-8")
                except OSError:
                    pass
                if stop_flag().exists():
                    log.info("Stopped (sending on its own was switched off).")
                    return 0
                cfg = config.load()
                if not config.problems(cfg):
                    what = watch_step(w, clock(), cfg)
                    if what:
                        w["last_run"] = clock()
                        w["changed_at"] = 0
                        run_cfg = dict(cfg)
                        if what == "change":
                            run_cfg["sales_every_min"] = 0  # today's sales and the open End of day go now
                        run(run_cfg, post=post)
            except Exception as exc:  # noqa: BLE001 - never stops watching; tries again next time
                try:
                    log.error("Watch problem: %s", exc)
                except Exception:  # noqa: BLE001
                    pass
            sleep(20)
    finally:
        lock.__exit__(None, None, None)
    return 0


# ------------------------------------------------------------------ test buttons
def _ping_record(cfg: dict[str, Any], st: feed.State) -> tuple[dict[str, Any], str]:
    import secrets
    nonce = secrets.token_hex(6)
    source = cfg["source_id"]
    u = st.stamp()
    payload = {"nonce": nonce, "sent_at": u, "version": build_info.VERSION, "build": build_info.BUILD}
    uid = f"{source}|ping|ping|0"
    row = {"uid": uid, "source": source, "shop_code": cfg["shop_code"], "till": cfg.get("till_name", ""), "kind": "ping", "period": "ping", "part": 0, "parts": 1,
           "data": json.dumps(payload, separators=(",", ":")), "hash": f"ping-{nonce}", "made_at": u, "bridge_version": build_info.VERSION,
           "updated_at": u, "updated_device": f"bridge-{source}"}
    return {"t": "aronium_feed", "k": uid, "u": u, "row": row}, nonce


def link_check(cfg: dict[str, Any], post=None) -> dict[str, Any]:
    url = str(cfg.get("cloud_url", "")).strip()
    body = json.dumps({"kind": "main_link_check", "key": str(cfg.get("main_key", "")).strip(), "source": cfg["source_id"]}).encode("utf-8")
    return (post or feed._post)(url, body)


def test_cloud(cfg: dict[str, Any] | None = None, *, post=None) -> dict[str, Any]:
    """Send a small test to the cloud and read it back. {ok, lines, nonce}. Never raises."""
    cfg = cfg or config.load()
    lines: list[str] = []
    probs = [m for m in config.problems(cfg) if "database" not in m.lower() and "aronium" not in m.lower()]
    if probs:
        return {"ok": False, "lines": ["✗ " + m for m in probs]}
    try:
        rec, nonce = _ping_record(cfg, state())
        t0 = time.monotonic()
        res = feed.push([rec], cfg, post=post, seconds=120)
        took = time.monotonic() - t0
        if res["error"]:
            return {"ok": False, "lines": [f"✗ The cloud did not take the test: {res['error']}"]}
        lines.append(f"✓ The cloud received the test ({took:.1f} seconds).")
        try:
            chk = link_check(cfg, post=post)
        except Exception as exc:  # noqa: BLE001
            chk = {"ok": False, "error": str(exc)}
        if chk.get("ok") and (chk.get("ping") or {}).get("nonce") == nonce:
            lines.append(f"✓ Read back from the cloud - it is kept safely (cloud script version {chk.get('version', '?')}).")
            return {"ok": True, "lines": lines, "nonce": nonce}
        if chk.get("ok"):
            lines.append("! The cloud answered but the test was not found when read back - press Test the cloud again.")
            return {"ok": False, "lines": lines, "nonce": nonce}
        lines.append("! The cloud took the test, but it cannot be read back: the cloud script needs updating to version 7 "
                     "(the cloud update page). Sending still works.")
        return {"ok": True, "lines": lines, "nonce": nonce, "old_cloud": True}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "lines": [f"✗ Problem: {exc}"]}


def test_app(cfg: dict[str, Any] | None = None, *, post=None, say: Callable[[str], None] | None = None,
             wait_s: float = 180, every_s: float = 10, sleep: Callable[[float], None] = time.sleep) -> dict[str, Any]:
    """Send a test and wait for the main tablet's answer (it comes back through the cloud). {ok, lines}."""
    cfg = cfg or config.load()
    out = say or (lambda m: None)
    first = test_cloud(cfg, post=post)
    for m in first["lines"]:
        out(m)
    if not first["ok"] or first.get("old_cloud"):
        return {"ok": False, "lines": first["lines"]}
    nonce = first["nonce"]
    out("Waiting for the main tablet to answer (up to 3 minutes)…")
    waited = 0.0
    last: dict[str, Any] = {}
    while waited <= wait_s:
        sleep(every_s)
        waited += every_s
        try:
            last = link_check(cfg, post=post)
        except Exception:  # noqa: BLE001 - try again
            continue
        pong = last.get("pong") or {}
        if pong.get("nonce") == nonce:
            who = pong.get("device") or "the main tablet"
            app = f", app {pong['app']}" if pong.get("app") else ""
            msg = f"✓ The Easy Buys app answered: {who}{app} received the test after about {int(waited)} seconds. The link works end to end."
            out(msg)
            return {"ok": True, "lines": first["lines"] + [msg]}
    seen = [d for d in (last.get("devices") or []) if d.get("last_seen")]
    seen.sort(key=lambda d: str(d.get("last_seen")), reverse=True)
    hint = f" Last device online: {seen[0]['name']} at {local_time(seen[0]['last_seen'])}." if seen else ""
    msg = ("✗ No answer from the main tablet in 3 minutes. The cloud works; check the Easy Buys app is open on the main tablet, "
           "is online, and has version 3.9.4 or newer." + hint)
    out(msg)
    return {"ok": False, "lines": first["lines"] + [msg]}


def check(cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """Look at Aronium and the settings without sending anything. Returns {ok, lines}."""
    cfg = cfg or config.load()
    lines: list[str] = []
    ok = True
    for m in config.problems(cfg):
        lines.append("✗ " + m)
        ok = False
    db = cfg.get("database_path")
    if db and Path(str(db)).is_file():
        try:
            from contextlib import closing
            with closing(aronium_read.open_read_only(db)) as conn:
                a = aronium_read.Aronium(conn)
                meta = a.meta()
                c = meta["counts"]
                lines.append(f"✓ Aronium found: {c.get('Product', 0)} products, {c.get('Document', 0)} documents, "
                             f"{c.get('Customer', 0)} customers / suppliers, {c.get('ZReport', 0)} End of days.")
                sales = [t for t in meta["document_types"] if t["kind"] == "sale"]
                lines.append("✓ Sales documents found." if sales else "! No sales document type found - sales may not come through.")
                lines.append("✓ End of days are linked to payments." if meta["has_z_link"] else "! This Aronium does not link payments to End of day - each day is sent as one End of day.")
                for n in meta["notes"]:
                    lines.append("! " + n)
        except Exception as exc:  # noqa: BLE001
            ok = False
            lines.append(f"✗ Could not read the Aronium database: {exc}")
    st = state()
    last_ok = st.get("last_ok")
    lines.append(f"Last sent: {last_ok.replace('T', ' ')[:16]} (UTC)" if last_ok else "Nothing sent yet.")
    w = st.waiting_count()
    if w:
        lines.append(f"Waiting to send: {w}." + (f" Last problem: {st.last_error()}" if st.last_error() else ""))
    lines.append(f"This till is {cfg['source_id']} ({cfg['till_name']}).")
    return {"ok": ok, "lines": lines}


# ------------------------------------------------------------------ Windows Task Scheduler
def program_command(mode: str = "--watch") -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, mode]
    return [sys.executable.replace("python.exe", "pythonw.exe"), str(Path(__file__).with_name("app.py")), mode]


def task_xml(every_min: int) -> str:
    """Windows task: starts the watcher at logon and every N minutes (a running watcher makes the extra start stop at
    once), also on battery, with no time limit, and starts a missed run as soon as possible."""
    from xml.sax.saxutils import escape
    cmd = program_command("--watch")
    start = time.strftime("%Y-%m-%dT%H:%M:00")
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Easy Buys: sends Aronium figures to the Easy Buys app (reads Aronium only).</Description></RegistrationInfo>
  <Triggers>
    <LogonTrigger><Enabled>true</Enabled></LogonTrigger>
    <TimeTrigger><StartBoundary>{start}</StartBoundary><Enabled>true</Enabled>
      <Repetition><Interval>PT{max(5, int(every_min))}M</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition></TimeTrigger>
  </Triggers>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <AllowHardTerminate>true</AllowHardTerminate>
    <Enabled>true</Enabled>
  </Settings>
  <Actions><Exec><Command>{escape(cmd[0])}</Command><Arguments>{escape(" ".join(f'"{c}"' if " " in c else c for c in cmd[1:]))}</Arguments></Exec></Actions>
</Task>
"""


def schedule_on(every_min: int) -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Automatic sending can only be set up on Windows."
    try:
        stop_flag().unlink()
    except OSError:
        pass
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    xml = config.home() / "task.xml"
    try:
        xml.write_text(task_xml(every_min), encoding="utf-16")
        r = subprocess.run(["schtasks", "/Create", "/F", "/TN", TASK_NAME, "/XML", str(xml)], capture_output=True, text=True, creationflags=flags)
    except Exception as exc:  # noqa: BLE001
        r = None
        logger().error("Task XML: %s", exc)
    if r is None or r.returncode != 0:  # the simple way: every N minutes
        cmd = " ".join(f'"{c}"' for c in program_command("--watch"))
        r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "MINUTE", "/MO", str(max(5, int(every_min))), "/TN", TASK_NAME, "/TR", cmd],
                           capture_output=True, text=True, creationflags=flags)
    if r.returncode == 0:  # start watching straight away, without waiting for the first trigger
        subprocess.run(["schtasks", "/Run", "/TN", TASK_NAME], capture_output=True, text=True, creationflags=flags)
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_off() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Only on Windows."
    try:
        stop_flag().write_text("stopped", encoding="utf-8")  # the watcher sees this within 20 seconds and ends
    except OSError:
        pass
    r = subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_is_on() -> bool:
    if sys.platform != "win32":
        return False
    r = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--check" in args:
        res = check()
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    if "--resend" in args:
        state().forget_sent()
        print("Everything will be sent again on the next run.")
        return 0
    if "--watch" in args:
        return watch()
    if "--uninstall" in args:  # the uninstaller: stop sending on its own (the watcher ends within 20 seconds)
        try:
            schedule_off()
        except Exception:  # noqa: BLE001
            pass
        return 0
    if "--reschedule" in args:  # after an update: point the Windows task at this copy, if it was sending on its own
        try:
            if schedule_is_on():
                schedule_on(int(config.load().get("every_min", 15)))
        except Exception:  # noqa: BLE001
            pass
        return 0
    if "--run" in args:
        res = run(say=None if os.environ.get("EASYBUYS_QUIET") else print)
        return 0 if res["ok"] else 1
    print(__doc__)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
