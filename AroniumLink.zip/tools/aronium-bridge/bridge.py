"""Easy Buys Aronium link - the work itself (also usable from the command line).

  EasyBuysAroniumLink.exe --run        read Aronium and send the changes (what Windows runs every 15 minutes)
  EasyBuysAroniumLink.exe --check      check Aronium and the settings, send nothing
  EasyBuysAroniumLink.exe --resend     send everything again next run

Aronium is only ever read (see aronium_read.py). Nothing here can change, delete or add anything in Aronium.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Callable

import aronium_read
import config
import feed

TASK_NAME = "Easy Buys Aronium Link"


def logger() -> logging.Logger:
    log = logging.getLogger("easybuys-link")
    if not log.handlers:
        log.setLevel(logging.INFO)
        h = RotatingFileHandler(config.home() / "link.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%Y-%m-%d %H:%M:%S"))
        log.addHandler(h)
    return log


class RunLock:
    """Only one run at a time (a slow send must not overlap the next scheduled one)."""

    def __init__(self) -> None:
        self.path = config.home() / "run.lock"
        self.fh = None

    def __enter__(self) -> "RunLock":
        self.fh = open(self.path, "a+")
        try:
            if sys.platform == "win32":
                import msvcrt
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.fh.close()
            self.fh = None
            raise RuntimeError("Already sending (another run is busy) - it will finish on its own.") from None
        return self

    def __exit__(self, *exc: Any) -> None:
        if self.fh:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    self.fh.seek(0)
                    msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.fh.close()


def state() -> feed.State:
    return feed.State(config.home() / "sent.db")


def reader(cfg: dict[str, Any]) -> Callable[..., dict[str, Any]]:
    work = config.home() / "work"

    def read(path: str, **kw: Any) -> dict[str, Any]:
        return aronium_read.read_all(path, work_dir=work, **kw)
    return read


def run(cfg: dict[str, Any] | None = None, *, say: Callable[[str], None] | None = None, post=None) -> dict[str, Any]:
    """One run: read, send. Never raises - every problem comes back as {"ok": False, "error": ...}."""
    cfg = cfg or config.load()
    log = logger()

    def out(msg: str) -> None:
        log.info(msg)
        if say:
            say(msg)
    missing = config.problems(cfg)
    if missing:
        out("Not ready: " + " ".join(missing))
        return {"ok": False, "error": " ".join(missing)}
    try:
        with RunLock():
            res = feed.run_once(cfg, state(), read=reader(cfg), post=post, log=out)
        return {"ok": not res["error"], "error": res["error"], "sent": len(res["sent"]), "waiting": res["waiting"]}
    except Exception as exc:  # noqa: BLE001 - the link must never crash; the next run tries again
        log.error("Problem: %s\n%s", exc, traceback.format_exc())
        out(f"Problem: {exc}")
        return {"ok": False, "error": str(exc)}


def check(cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """Look at Aronium and the settings without sending anything. Returns {ok, lines}."""
    cfg = cfg or config.load()
    lines: list[str] = []
    ok = True
    for m in config.problems(cfg):
        lines.append("✗ " + m)
        ok = False
    db = cfg.get("database_path")
    if db and Path(str(db)).is_file():
        try:
            from contextlib import closing
            with closing(aronium_read.open_read_only(db)) as conn:
                a = aronium_read.Aronium(conn)
                meta = a.meta()
                c = meta["counts"]
                lines.append(f"✓ Aronium found: {c.get('Product', 0)} products, {c.get('Document', 0)} documents, "
                             f"{c.get('Customer', 0)} customers / suppliers, {c.get('ZReport', 0)} End of days.")
                sales = [t for t in meta["document_types"] if t["kind"] == "sale"]
                lines.append("✓ Sales documents found." if sales else "! No sales document type found - sales may not come through.")
                lines.append("✓ End of days are linked to payments." if meta["has_z_link"] else "! This Aronium does not link payments to End of day - each day is sent as one End of day.")
                for n in meta["notes"]:
                    lines.append("! " + n)
        except Exception as exc:  # noqa: BLE001
            ok = False
            lines.append(f"✗ Could not read the Aronium database: {exc}")
    st = state()
    last_ok = st.get("last_ok")
    lines.append(f"Last sent: {last_ok.replace('T', ' ')[:16]} (UTC)" if last_ok else "Nothing sent yet.")
    w = st.waiting_count()
    if w:
        lines.append(f"Waiting to send: {w}." + (f" Last problem: {st.last_error()}" if st.last_error() else ""))
    lines.append(f"This till is {cfg['source_id']} ({cfg['till_name']}).")
    return {"ok": ok, "lines": lines}


# ------------------------------------------------------------------ Windows Task Scheduler
def program_command() -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--run"]
    return [sys.executable.replace("python.exe", "pythonw.exe"), str(Path(__file__).with_name("app.py")), "--run"]


def schedule_on(every_min: int) -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Automatic sending can only be set up on Windows."
    cmd = " ".join(f'"{c}"' for c in program_command())
    r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "MINUTE", "/MO", str(max(5, int(every_min))), "/TN", TASK_NAME, "/TR", cmd],
                       capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_off() -> tuple[bool, str]:
    if sys.platform != "win32":
        return False, "Only on Windows."
    r = subprocess.run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0, (r.stdout or r.stderr).strip()


def schedule_is_on() -> bool:
    if sys.platform != "win32":
        return False
    r = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--check" in args:
        res = check()
        print("\n".join(res["lines"]))
        return 0 if res["ok"] else 1
    if "--resend" in args:
        state().forget_sent()
        print("Everything will be sent again on the next run.")
        return 0
    if "--run" in args:
        res = run(say=None if os.environ.get("EASYBUYS_QUIET") else print)
        return 0 if res["ok"] else 1
    print(__doc__)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
