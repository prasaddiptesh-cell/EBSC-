"""The window of the Easy Buys Aronium link (one per till PC)."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import aronium_read
import bridge
import build_info
import config

HISTORY = {"all": "Everything Aronium has (since the till started)", "2026-01-01": "From 1 January 2026", "days": "The last 400 days"}

GUIDE = (
    "1. Choose the shop and the till number of this PC.\n"
    "2. Press Find to locate Aronium's database (pos.db), or Choose… to pick it.\n"
    "3. Paste the cloud web address and the main-software key (from the cloud script's log - keep it private).\n"
    "4. Press Check (Settings). Then on Status: Test the cloud, Test the app, and Send now.\n"
    "5. Press 'Send on its own': it then sends soon after each change in Aronium and every 15 minutes, even with "
    "this window closed.\n\n"
    "Aronium is only read - nothing in Aronium is ever changed."
)

# Easy Buys colours (the same as the app)
BG, CARD, LINE, INK, SUB = "#F4F1EC", "#FFFFFF", "#E3DDD3", "#2B1A1C", "#6B6160"
RED, RED_DARK, BLUE = "#C8242A", "#A51D22", "#2F5FC4"
OK, OK_SOFT, WARN, WARN_SOFT = "#157F3B", "#DDF4E4", "#B45309", "#FEF0C7"


def asset(name: str) -> str:
    """Pictures packed with the program (PyInstaller puts them in a temporary folder)."""
    import os
    import sys
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "assets", name)


class BridgeUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"Easy Buys Aronium Link {build_info.VERSION}")
        # sizes grow with the screen's scaling (125% / 150% laptops), so the window is sharp and not tiny
        try:
            k = max(1.0, min(3.0, float(self.winfo_fpixels("1i")) / 96.0))
        except Exception:  # noqa: BLE001
            k = 1.0
        self.k = k
        try:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        except Exception:  # noqa: BLE001
            sw, sh = 4000, 4000
        self.geometry(f"{min(int(780 * k), sw - 40)}x{min(int(640 * k), sh - 90)}+20+10")
        self.minsize(min(int(620 * k), sw - 40), min(int(520 * k), sh - 90))
        self.configure(bg=BG)
        self._images: list = []
        try:
            ic = tk.PhotoImage(file=asset("icon-64.png"))
            self.iconphoto(True, ic)
            self._images.append(ic)
        except Exception:  # noqa: BLE001 - the plain icon is fine
            pass
        try:
            self.iconbitmap(default=asset("icon.ico"))
        except Exception:  # noqa: BLE001
            pass
        self._style()
        self.cfg = config.load()
        self.msgs: "queue.Queue[str]" = queue.Queue()
        self.busy = False
        self._build()
        self._fill()
        self.after(200, self._pump)
        self.after(300, self._refresh_status)

    # -------------------------------------------------------------- look
    def _style(self) -> None:
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        base = ("Segoe UI", 10)
        st.configure(".", background=BG, foreground=INK, font=base)
        st.configure("Card.TFrame", background=CARD)
        st.configure("Card.TLabel", background=CARD, foreground=INK, font=base)
        st.configure("Field.TLabel", background=CARD, foreground=SUB, font=("Segoe UI", 10))
        st.configure("Head.TLabel", background=CARD, foreground=INK, font=("Segoe UI Semibold", 11))
        st.configure("Top.TFrame", background=CARD)
        st.configure("Title.TLabel", background=CARD, foreground=INK, font=("Segoe UI Semibold", 15))
        st.configure("Sub.TLabel", background=CARD, foreground=SUB, font=("Segoe UI", 10))
        st.configure("Card.TCheckbutton", background=CARD, foreground=SUB)
        st.map("Card.TCheckbutton", background=[("active", CARD)])
        st.configure("TEntry", fieldbackground="#FFFFFF", bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, padding=5)
        st.map("TEntry", bordercolor=[("focus", BLUE)], lightcolor=[("focus", BLUE)])
        st.configure("TCombobox", fieldbackground="#FFFFFF", background=CARD, bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, arrowcolor=INK, padding=4)
        st.map("TCombobox", fieldbackground=[("readonly", "#FFFFFF")], bordercolor=[("focus", BLUE)])
        st.configure("TButton", background=CARD, foreground=INK, bordercolor=LINE, lightcolor=CARD, darkcolor=CARD, padding=(12, 7), font=("Segoe UI Semibold", 10))
        st.map("TButton", background=[("disabled", BG), ("active", "#F7F4EF")], foreground=[("disabled", "#B5ADA3")])
        st.configure("Red.TButton", background=RED, foreground="#FFFFFF", bordercolor=RED, lightcolor=RED, darkcolor=RED)
        st.map("Red.TButton", background=[("disabled", "#E6A9AB"), ("active", RED_DARK)], foreground=[("disabled", "#FFFFFF")])
        st.configure("Blue.TButton", background=BLUE, foreground="#FFFFFF", bordercolor=BLUE, lightcolor=BLUE, darkcolor=BLUE)
        st.map("Blue.TButton", background=[("disabled", "#AFC2EA"), ("active", "#264FA6")], foreground=[("disabled", "#FFFFFF")])
        st.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(4, 0, 4, 0))
        st.configure("TNotebook.Tab", background="#EAE4DA", foreground=SUB, padding=(14, 6), font=("Segoe UI Semibold", 10), borderwidth=0)
        st.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", RED)])
        st.configure("On.TLabel", background=OK_SOFT, foreground=OK, font=("Segoe UI Semibold", 10), padding=(10, 6))
        st.configure("Off.TLabel", background=WARN_SOFT, foreground=WARN, font=("Segoe UI Semibold", 10), padding=(10, 6))

    def _card(self, parent, title: str) -> ttk.Frame:
        outer = tk.Frame(parent, bg=LINE, bd=0, highlightthickness=0)
        outer.pack(fill="x", padx=14, pady=(0, 10))
        inner = ttk.Frame(outer, style="Card.TFrame", padding=(14, 10))
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        inner.columnconfigure(1, weight=1)
        ttk.Label(inner, text=title, style="Head.TLabel").grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))
        return inner

    # -------------------------------------------------------------- layout
    def _build(self) -> None:
        pad = {"padx": 6, "pady": 4}
        # the top: logo and what this program does
        top = ttk.Frame(self, style="Top.TFrame", padding=(16, 12))
        top.pack(fill="x")
        tk.Frame(self, bg=RED, height=max(3, int(3 * self.k))).pack(fill="x")
        logo = None
        for name, at in (("logo-3x.png", 2.2), ("logo-2x.png", 1.4), ("logo-1x.png", 0)):
            if self.k >= at:
                try:
                    logo = tk.PhotoImage(file=asset(name))
                    break
                except Exception:  # noqa: BLE001
                    logo = None
        self._logo = logo
        if logo is not None:
            self._images.append(logo)
            tk.Label(top, image=logo, bg=CARD, bd=0).pack(side="left")
        words = ttk.Frame(top, style="Top.TFrame")
        words.pack(side="left", padx=(16, 0), fill="x", expand=True)
        ttk.Label(words, text="Aronium Link", style="Title.TLabel").pack(anchor="w")
        ttk.Label(words, text="Sends this till's sales and End of days to the Easy Buys app.\nReads Aronium only - never changes it.",
                  style="Sub.TLabel", justify="left").pack(anchor="w")

        # bottom line: version, build and About (always visible)
        foot = ttk.Frame(self, padding=(14, 4, 14, 8))
        foot.pack(side="bottom", fill="x")
        ttk.Label(foot, text=build_info.label(), foreground=SUB, font=("Segoe UI", 9)).pack(side="left")
        ttk.Button(foot, text="About", command=self.about).pack(side="right")

        # two tabs: Status (every day) and Settings (once), so everything fits on a small laptop screen too
        self.tabs = ttk.Notebook(self, padding=(10, 10, 10, 0))
        self.tabs.pack(fill="both", expand=True)
        stat_tab = ttk.Frame(self.tabs, padding=(0, 10, 0, 0))
        set_tab = ttk.Frame(self.tabs, padding=(0, 10, 0, 0))
        self.tabs.add(stat_tab, text="  Status  ")
        self.tabs.add(set_tab, text="  Settings  ")
        self.buttons = []

        # ---- Status tab
        c = self._card(stat_tab, "Status")
        self.stat: dict[str, ttk.Label] = {}
        for i, (key, label) in enumerate((("auto", "Sending"), ("last", "Last sent"), ("waiting", "Waiting to send"), ("problem", "Last problem"))):
            ttk.Label(c, text=label, style="Field.TLabel").grid(row=i + 1, column=0, sticky="nw", padx=6, pady=2)
            v = ttk.Label(c, text="…", style="Card.TLabel", wraplength=int(520 * self.k), justify="left")
            v.grid(row=i + 1, column=1, columnspan=2, sticky="w", padx=6, pady=2)
            self.stat[key] = v
        btns = ttk.Frame(stat_tab)
        btns.pack(fill="x", padx=14, pady=(0, 10))
        for text, cmd, style in (("Send now", self.send_now, "Blue.TButton"), ("Send on its own", self.auto_on, "Red.TButton"), ("Stop sending on its own", self.auto_off, "TButton")):
            w = ttk.Button(btns, text=text, command=cmd, style=style)
            w.pack(side="left", padx=(0, 6))
            self.buttons.append(w)
        tests = ttk.Frame(stat_tab)
        tests.pack(fill="x", padx=14, pady=(0, 10))
        for text, cmd in (("Test the cloud", self.test_cloud), ("Test the app (main tablet)", self.test_app)):
            w = ttk.Button(tests, text=text, command=cmd)
            w.pack(side="left", padx=(0, 6))
            self.buttons.append(w)
        self.auto = None
        logf = tk.Frame(stat_tab, bg=LINE)
        logf.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        self.out = tk.Text(logf, height=6, wrap="word", state="disabled", font=("Consolas", 10), bg="#FFFFFF", fg=INK,
                           relief="flat", bd=0, padx=10, pady=8, highlightthickness=0)
        sb = ttk.Scrollbar(logf, orient="vertical", command=self.out.yview)
        self.out.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True, padx=1, pady=1)
        self.out.tag_configure("ok", foreground=OK)
        self.out.tag_configure("bad", foreground=RED)
        self.out.tag_configure("warn", foreground=WARN)
        self._say(GUIDE)

        # ---- Settings tab
        c = self._card(set_tab, "This till")
        ttk.Label(c, text="Shop", style="Field.TLabel").grid(row=1, column=0, sticky="w", **pad)
        self.shop = ttk.Combobox(c, state="readonly", values=list(config.SHOPS.values()))
        self.shop.grid(row=1, column=1, columnspan=2, sticky="ew", **pad)
        ttk.Label(c, text="Till number", style="Field.TLabel").grid(row=2, column=0, sticky="w", **pad)
        self.till = ttk.Combobox(c, state="readonly", values=["1", "2", "3", "4"], width=6)
        self.till.grid(row=2, column=1, sticky="w", **pad)

        c = self._card(set_tab, "Aronium")
        ttk.Label(c, text="Database", style="Field.TLabel").grid(row=1, column=0, sticky="w", **pad)
        self.db = ttk.Entry(c)
        self.db.grid(row=1, column=1, sticky="ew", **pad)
        b = ttk.Frame(c, style="Card.TFrame")
        b.grid(row=1, column=2, sticky="e")
        ttk.Button(b, text="Find", command=self.find_db).pack(side="left", padx=(0, 4))
        ttk.Button(b, text="Choose…", command=self.choose_db).pack(side="left")
        ttk.Label(c, text="First send", style="Field.TLabel").grid(row=2, column=0, sticky="w", **pad)
        self.hist = ttk.Combobox(c, state="readonly", values=list(HISTORY.values()))
        self.hist.grid(row=2, column=1, sticky="ew", **pad)

        c = self._card(set_tab, "Easy Buys cloud")
        ttk.Label(c, text="Web address", style="Field.TLabel").grid(row=1, column=0, sticky="w", **pad)
        self.url = ttk.Entry(c)
        self.url.grid(row=1, column=1, columnspan=2, sticky="ew", **pad)
        ttk.Label(c, text="Main-software key", style="Field.TLabel").grid(row=2, column=0, sticky="w", **pad)
        self.key = ttk.Entry(c, show="•")
        self.key.grid(row=2, column=1, sticky="ew", **pad)
        self.show = tk.BooleanVar(value=False)
        ttk.Checkbutton(c, text="Show", style="Card.TCheckbutton", variable=self.show,
                        command=lambda: self.key.config(show="" if self.show.get() else "•")).grid(row=2, column=2, sticky="w", padx=6)

        btns = ttk.Frame(set_tab)
        btns.pack(fill="x", padx=14, pady=(0, 10))
        for text, cmd, style in (("Save", self.save, "Blue.TButton"), ("Check", self.check, "TButton")):
            w = ttk.Button(btns, text=text, command=cmd, style=style)
            w.pack(side="left", padx=(0, 6))
            self.buttons.append(w)
        self.set_note = ttk.Label(set_tab, text="Check shows its result on the Status tab.", foreground=SUB, wraplength=int(600 * self.k), justify="left")
        self.set_note.pack(fill="x", padx=14)
        # not set up yet: open on Settings
        if config.problems(self.cfg):
            self.tabs.select(set_tab)

    def _fill(self) -> None:
        self.shop.set(config.SHOPS.get(self.cfg.get("shop_code"), list(config.SHOPS.values())[0]))
        self.till.set(str(self.cfg.get("till_number") or 1))
        self.db.delete(0, "end")
        self.db.insert(0, self.cfg.get("database_path") or "")
        self.url.delete(0, "end")
        self.url.insert(0, self.cfg.get("cloud_url") or "")
        self.key.delete(0, "end")
        self.key.insert(0, self.cfg.get("main_key") or "")
        self.hist.set(HISTORY.get(str(self.cfg.get("history_from", "all")), HISTORY["all"]))
        self._auto_label()

    def _auto_label(self, on=None) -> None:
        if self.auto is None:
            return
        if on is None:
            on = bridge.schedule_is_on()
        if on:
            self.auto.config(style="On.TLabel", text="✓ Sending on its own: soon after each change in Aronium, and every %s minutes." % self.cfg.get("every_min", 15))
        else:
            self.auto.config(style="Off.TLabel", text="Not sending on its own yet - press 'Send on its own' when everything is filled in.")

    # -------------------------------------------------------------- status (every 15 seconds, worked out in the background)
    def _refresh_once(self) -> None:
        threading.Thread(target=lambda: self._push_status(), daemon=True).start()

    def _push_status(self) -> None:
        try:
            st = bridge.status()
            self.after(0, lambda: self._show_status(st))
        except Exception:  # noqa: BLE001
            pass

    def _refresh_status(self) -> None:
        def work() -> None:
            try:
                st = bridge.status()
            except Exception as exc:  # noqa: BLE001
                st = {"problem": str(exc)}
            try:
                self.after(0, lambda: self._show_status(st))
            except Exception:  # noqa: BLE001 - the window was closed
                pass
        threading.Thread(target=work, daemon=True).start()
        self.after(15000, self._refresh_status)

    def _show_status(self, st: dict) -> None:
        ok, bad, warn = OK, RED, WARN
        if st.get("auto"):
            if st.get("watching"):
                self.stat["auto"].config(text="✓ On its own - watching Aronium in the background", foreground=ok)
            else:
                self.stat["auto"].config(text="✓ On its own - starts in the background within 15 minutes (or when Windows starts)", foreground=ok)
        else:
            self.stat["auto"].config(text="Not on its own yet - press 'Send on its own'", foreground=warn)
        last = st.get("last_ok") or ""
        looked = st.get("last_run") or ""
        txt = f"{last}" if last else "Nothing sent yet"
        if looked and looked != last:
            txt += f"   (last looked at Aronium {looked})"
        if st.get("sent"):
            txt += f"   ·   {st['sent']} records sent so far"
        self.stat["last"].config(text=txt, foreground=INK)
        n = int(st.get("waiting") or 0)
        self.stat["waiting"].config(text=(f"{n} waiting: {st.get('waiting_text', '')}" if n else "✓ Nothing waiting - all sent"), foreground=warn if n else ok)
        prob = st.get("problem") or st.get("last_result") or ""
        self.stat["problem"].config(text=prob[:300] if prob else "None", foreground=bad if prob else SUB)
        self._auto_label(on=st.get("auto"))

    # -------------------------------------------------------------- helpers
    def _say(self, msg: str) -> None:
        self.out.config(state="normal")
        t = msg.strip()
        tag = "ok" if t.startswith("✓") else "bad" if t.startswith(("✗", "Problem")) else "warn" if t.startswith(("!", "Still needed")) else ""
        self.out.insert("end", msg.rstrip() + "\n", tag)
        self.out.see("end")
        self.out.config(state="disabled")

    def _pump(self) -> None:
        try:
            while True:
                self._say(self.msgs.get_nowait())
        except queue.Empty:
            pass
        self.after(200, self._pump)

    def _read_form(self) -> dict:
        cfg = dict(self.cfg)
        names = {v: k for k, v in config.SHOPS.items()}
        cfg["shop_code"] = names.get(self.shop.get(), "S1")
        cfg["till_number"] = int(self.till.get() or 1)
        cfg["database_path"] = self.db.get().strip().strip('"')
        cfg["cloud_url"] = self.url.get().strip()
        cfg["main_key"] = self.key.get().strip()
        cfg["history_from"] = {v: k for k, v in HISTORY.items()}.get(self.hist.get(), "all")
        cfg["source_id"] = config.source_id(cfg)
        cfg["till_name"] = config.till_name(cfg)
        return cfg

    def _in_background(self, job, done=None) -> None:
        if self.busy:
            self._say("Still busy - please wait.")
            return
        self.busy = True
        for w in self.buttons:
            w.state(["disabled"])

        def work() -> None:
            try:
                res = job()
            except Exception as exc:  # noqa: BLE001
                res = None
                self.msgs.put(f"Problem: {exc}")
            self.after(0, lambda: self._finish(res, done))
        threading.Thread(target=work, daemon=True).start()

    def _finish(self, res, done) -> None:
        self.busy = False
        for w in self.buttons:
            w.state(["!disabled"])
        if done:
            done(res)

    # -------------------------------------------------------------- actions
    def find_db(self) -> None:
        p = aronium_read.find_database()
        if p:
            self.db.delete(0, "end")
            self.db.insert(0, str(p))
            self._say(f"Found Aronium's database: {p}")
        else:
            self._say("Could not find it on its own. Press Choose… and pick pos.db (usually in AppData\\Local\\Aronium\\Data).")

    def choose_db(self) -> None:
        p = filedialog.askopenfilename(title="Aronium database (pos.db)", filetypes=[("Aronium database", "*.db"), ("All files", "*.*")])
        if p:
            self.db.delete(0, "end")
            self.db.insert(0, p)

    def save(self) -> bool:
        old = self.cfg.get("source_id")
        cfg = self._read_form()
        if old and old != cfg["source_id"] and bridge.state().get("last_ok"):
            if not messagebox.askyesno("Change the till?", f"This PC has been sending as {old}. Send as {cfg['source_id']} from now on?"):
                return False
        config.save(cfg)
        self.cfg = config.load()
        self._say(f"Saved. This PC sends as {self.cfg['source_id']} ({self.cfg['till_name']}).")
        probs = config.problems(self.cfg)
        for m in probs:
            self._say("  Still needed: " + m)
        try:
            self.set_note.config(text=("✓ Saved. Still needed:\n• " + "\n• ".join(probs)) if probs else f"✓ Saved - this PC sends as {self.cfg['till_name']}. Now press Check.",
                                 foreground=WARN if probs else OK)
        except Exception:  # noqa: BLE001
            pass
        return True

    def check(self) -> None:
        if not self.save():
            return
        self.tabs.select(0)
        self._in_background(lambda: bridge.check(self.cfg), lambda res: res and [self._say(x) for x in res["lines"]])

    def send_now(self) -> None:
        if not self.save():
            return
        self._say("Sending… (the first time can take several minutes)")
        self._in_background(lambda: bridge.run(self.cfg, say=self.msgs.put),
                            lambda res: (res and self._say("Done." if res["ok"] else "Not finished - it will try again on its own."), self._refresh_once()))

    def test_cloud(self) -> None:
        if not self.save():
            return
        self.tabs.select(0)
        self._say("Testing the cloud…")
        self._in_background(lambda: bridge.test_cloud(self.cfg), lambda res: res and [self._say(x) for x in res["lines"]])

    def test_app(self) -> None:
        if not self.save():
            return
        self.tabs.select(0)
        self._say("Testing the whole way: this PC → cloud → the Easy Buys app on the main tablet…")
        self._in_background(lambda: bridge.test_app(self.cfg, say=self.msgs.put), lambda res: None)

    def auto_on(self) -> None:
        if not self.save():
            return
        if config.problems(self.cfg):
            self._say("Fill in everything first (see above).")
            return
        ok, msg = bridge.schedule_on(int(self.cfg.get("every_min", 15)))
        self._say("✓ It will now send on its own, even with this window closed." if ok else f"Could not set it up: {msg}")
        self._auto_label()
        self.after(3000, self._refresh_once)

    def about(self) -> None:
        """Software information: what it is, which version and build, where its files are."""
        win = tk.Toplevel(self)
        win.title("About")
        win.configure(bg=CARD)
        win.transient(self)
        win.resizable(False, False)
        f = ttk.Frame(win, style="Card.TFrame", padding=(20, 16))
        f.pack(fill="both", expand=True)
        if getattr(self, "_logo", None) is not None:
            tk.Label(f, image=self._logo, bg=CARD).pack(anchor="w", pady=(0, 8))
        ttk.Label(f, text=build_info.NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(f, text=build_info.label(), style="Sub.TLabel").pack(anchor="w", pady=(0, 8))
        cfg = self.cfg
        on = bridge.schedule_is_on()
        rows = [
            ("What it does", build_info.WHAT),
            ("Aronium", "Read only - this program never changes, adds or deletes anything in Aronium."),
            ("This till", f"{cfg.get('source_id', '')} ({cfg.get('till_name', '')})"),
            ("Database", cfg.get("database_path") or "not chosen yet"),
            ("Sending", (f"On its own: soon after each change, and every {cfg.get('every_min', 15)} minutes") if on else "Not on its own yet"),
            ("Last sent", self._last_sent()),
            ("Settings and log", str(config.home())),
            ("Build", f"{build_info.BUILD}" + (f" ({build_info.COMMIT[:7]})" if build_info.COMMIT else "")),
        ]
        g = ttk.Frame(f, style="Card.TFrame")
        g.pack(fill="x")
        for i, (k, v) in enumerate(rows):
            ttk.Label(g, text=k, style="Field.TLabel").grid(row=i, column=0, sticky="nw", padx=(0, 12), pady=2)
            ttk.Label(g, text=v, style="Card.TLabel", wraplength=int(420 * self.k), justify="left").grid(row=i, column=1, sticky="w", pady=2)
        ttk.Label(f, text="What's new", style="Head.TLabel").pack(anchor="w", pady=(12, 2))
        for ver, txt in build_info.CHANGES[:3]:
            ttk.Label(f, text=f"{ver}  {txt}", style="Card.TLabel", wraplength=int(540 * self.k), justify="left").pack(anchor="w", pady=1)
        ttk.Button(f, text="Close", command=win.destroy, style="Blue.TButton").pack(anchor="e", pady=(12, 0))

    def _last_sent(self) -> str:
        try:
            v = bridge.state().get("last_ok")
            return (v.replace("T", " ")[:16] + " (UTC)") if v else "Nothing sent yet"
        except Exception:  # noqa: BLE001
            return "-"

    def auto_off(self) -> None:
        ok, msg = bridge.schedule_off()
        self._say("Stopped sending on its own." if ok else f"Could not stop it: {msg}")
        self._auto_label()
        self.after(1000, self._refresh_once)


if __name__ == "__main__":
    BridgeUI().mainloop()
