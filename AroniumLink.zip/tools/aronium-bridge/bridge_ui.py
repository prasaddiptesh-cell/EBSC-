"""The window of the Easy Buys Aronium link (one per till PC)."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import aronium_read
import bridge
import config

HISTORY = {"all": "Everything Aronium has (since the till started)", "2026-01-01": "From 1 January 2026", "days": "The last 400 days"}

GUIDE = (
    "1. Choose the shop and the till number of this PC.\n"
    "2. Press Find to locate Aronium's database (pos.db), or Choose… to pick it.\n"
    "3. Paste the cloud web address and the main-software key (from the cloud script's log - keep it private).\n"
    "4. Press Save, then Check. Then Send now.\n"
    "5. Press 'Send on its own' so it runs every 15 minutes, even when this window is closed.\n\n"
    "Aronium is only read - nothing in Aronium is ever changed."
)


class BridgeUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Easy Buys Aronium Link")
        self.geometry("720x620")
        self.minsize(600, 520)
        self.cfg = config.load()
        self.msgs: "queue.Queue[str]" = queue.Queue()
        self.busy = False
        self._build()
        self._fill()
        self.after(200, self._pump)

    # -------------------------------------------------------------- layout
    def _build(self) -> None:
        pad = {"padx": 8, "pady": 4}
        f = ttk.Frame(self, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        ttk.Label(f, text="Easy Buys Aronium Link", font=("Segoe UI", 14, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", **pad)

        ttk.Label(f, text="Shop").grid(row=1, column=0, sticky="w", **pad)
        self.shop = ttk.Combobox(f, state="readonly", values=list(config.SHOPS.values()))
        self.shop.grid(row=1, column=1, sticky="ew", **pad)

        ttk.Label(f, text="Till number").grid(row=2, column=0, sticky="w", **pad)
        self.till = ttk.Combobox(f, state="readonly", values=["1", "2", "3", "4"], width=6)
        self.till.grid(row=2, column=1, sticky="w", **pad)

        ttk.Label(f, text="Aronium database").grid(row=3, column=0, sticky="w", **pad)
        self.db = ttk.Entry(f)
        self.db.grid(row=3, column=1, sticky="ew", **pad)
        b = ttk.Frame(f)
        b.grid(row=3, column=2, sticky="e")
        ttk.Button(b, text="Find", command=self.find_db).pack(side="left")
        ttk.Button(b, text="Choose…", command=self.choose_db).pack(side="left")

        ttk.Label(f, text="Cloud web address").grid(row=4, column=0, sticky="w", **pad)
        self.url = ttk.Entry(f)
        self.url.grid(row=4, column=1, columnspan=2, sticky="ew", **pad)

        ttk.Label(f, text="Main-software key").grid(row=5, column=0, sticky="w", **pad)
        self.key = ttk.Entry(f, show="•")
        self.key.grid(row=5, column=1, sticky="ew", **pad)
        self.show = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Show", variable=self.show, command=lambda: self.key.config(show="" if self.show.get() else "•")).grid(row=5, column=2, sticky="w")

        ttk.Label(f, text="First send includes").grid(row=6, column=0, sticky="w", **pad)
        self.hist = ttk.Combobox(f, state="readonly", values=list(HISTORY.values()))
        self.hist.grid(row=6, column=1, sticky="ew", **pad)

        btns = ttk.Frame(f)
        btns.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(10, 4))
        self.buttons = []
        for text, cmd in (("Save", self.save), ("Check", self.check), ("Send now", self.send_now), ("Send on its own", self.auto_on), ("Stop sending on its own", self.auto_off)):
            w = ttk.Button(btns, text=text, command=cmd)
            w.pack(side="left", padx=3)
            self.buttons.append(w)
        self.auto = ttk.Label(f, text="")
        self.auto.grid(row=8, column=0, columnspan=3, sticky="w", **pad)

        self.out = tk.Text(f, height=16, wrap="word", state="disabled", font=("Consolas", 10))
        self.out.grid(row=9, column=0, columnspan=3, sticky="nsew", **pad)
        f.rowconfigure(9, weight=1)
        self._say(GUIDE)

    def _fill(self) -> None:
        self.shop.set(config.SHOPS.get(self.cfg.get("shop_code"), list(config.SHOPS.values())[0]))
        self.till.set(str(self.cfg.get("till_number") or 1))
        self.db.delete(0, "end")
        self.db.insert(0, self.cfg.get("database_path") or "")
        self.url.delete(0, "end")
        self.url.insert(0, self.cfg.get("cloud_url") or "")
        self.key.delete(0, "end")
        self.key.insert(0, self.cfg.get("main_key") or "")
        self.hist.set(HISTORY.get(str(self.cfg.get("history_from", "all")), HISTORY["all"]))
        self._auto_label()

    def _auto_label(self) -> None:
        on = bridge.schedule_is_on()
        self.auto.config(text=("✓ Sends on its own every %s minutes." % self.cfg.get("every_min", 15)) if on else "Not sending on its own yet.")

    # -------------------------------------------------------------- helpers
    def _say(self, msg: str) -> None:
        self.out.config(state="normal")
        self.out.insert("end", msg.rstrip() + "\n")
        self.out.see("end")
        self.out.config(state="disabled")

    def _pump(self) -> None:
        try:
            while True:
                self._say(self.msgs.get_nowait())
        except queue.Empty:
            pass
        self.after(200, self._pump)

    def _read_form(self) -> dict:
        cfg = dict(self.cfg)
        names = {v: k for k, v in config.SHOPS.items()}
        cfg["shop_code"] = names.get(self.shop.get(), "S1")
        cfg["till_number"] = int(self.till.get() or 1)
        cfg["database_path"] = self.db.get().strip().strip('"')
        cfg["cloud_url"] = self.url.get().strip()
        cfg["main_key"] = self.key.get().strip()
        cfg["history_from"] = {v: k for k, v in HISTORY.items()}.get(self.hist.get(), "all")
        cfg["source_id"] = config.source_id(cfg)
        cfg["till_name"] = config.till_name(cfg)
        return cfg

    def _in_background(self, job, done=None) -> None:
        if self.busy:
            self._say("Still busy - please wait.")
            return
        self.busy = True
        for w in self.buttons:
            w.state(["disabled"])

        def work() -> None:
            try:
                res = job()
            except Exception as exc:  # noqa: BLE001
                res = None
                self.msgs.put(f"Problem: {exc}")
            self.after(0, lambda: self._finish(res, done))
        threading.Thread(target=work, daemon=True).start()

    def _finish(self, res, done) -> None:
        self.busy = False
        for w in self.buttons:
            w.state(["!disabled"])
        if done:
            done(res)

    # -------------------------------------------------------------- actions
    def find_db(self) -> None:
        p = aronium_read.find_database()
        if p:
            self.db.delete(0, "end")
            self.db.insert(0, str(p))
            self._say(f"Found Aronium's database: {p}")
        else:
            self._say("Could not find it on its own. Press Choose… and pick pos.db (usually in AppData\\Local\\Aronium\\Data).")

    def choose_db(self) -> None:
        p = filedialog.askopenfilename(title="Aronium database (pos.db)", filetypes=[("Aronium database", "*.db"), ("All files", "*.*")])
        if p:
            self.db.delete(0, "end")
            self.db.insert(0, p)

    def save(self) -> bool:
        old = self.cfg.get("source_id")
        cfg = self._read_form()
        if old and old != cfg["source_id"] and bridge.state().get("last_ok"):
            if not messagebox.askyesno("Change the till?", f"This PC has been sending as {old}. Send as {cfg['source_id']} from now on?"):
                return False
        config.save(cfg)
        self.cfg = config.load()
        self._say(f"Saved. This PC sends as {self.cfg['source_id']} ({self.cfg['till_name']}).")
        for m in config.problems(self.cfg):
            self._say("  Still needed: " + m)
        return True

    def check(self) -> None:
        if not self.save():
            return
        self._in_background(lambda: bridge.check(self.cfg), lambda res: res and [self._say(x) for x in res["lines"]])

    def send_now(self) -> None:
        if not self.save():
            return
        self._say("Sending… (the first time can take several minutes)")
        self._in_background(lambda: bridge.run(self.cfg, say=self.msgs.put),
                            lambda res: res and self._say("Done." if res["ok"] else "Not finished - it will try again on its own."))

    def auto_on(self) -> None:
        if not self.save():
            return
        if config.problems(self.cfg):
            self._say("Fill in everything first (see above).")
            return
        ok, msg = bridge.schedule_on(int(self.cfg.get("every_min", 15)))
        self._say("✓ It will now send on its own, even with this window closed." if ok else f"Could not set it up: {msg}")
        self._auto_label()

    def auto_off(self) -> None:
        ok, msg = bridge.schedule_off()
        self._say("Stopped sending on its own." if ok else f"Could not stop it: {msg}")
        self._auto_label()


if __name__ == "__main__":
    BridgeUI().mainloop()
