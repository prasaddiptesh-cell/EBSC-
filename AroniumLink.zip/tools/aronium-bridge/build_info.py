"""Version and build of the Easy Buys Aronium Link. The build machine fills in BUILD and BUILT (see the GitHub
workflow); a copy run from the source says "dev"."""
VERSION = "1.0"
BUILD = "dev"   # the build machine's run number: only goes up – used to know a newer build (automatic updates)
BUILT = ""
COMMIT = ""
# The build shown to people restarts at 1 from the initial version (run 27 of the build machine = build 1).
BUILD_BASE = 29  # run 29 = build 2; runs 28, 30 and 31 were cancelled, so the next real build (run 32) = build 3

NAME = "Easy Buys Aronium Link"
WHAT = "Sends each till PC's Aronium figures (sales, End of days, products, stock, customer credit) to the Easy Buys app."
CHANGES = [
    ("1.0", "Initial version. Reads Aronium only – it never changes anything in Aronium. Sends products, stock, sales "
            "per day, every receipt (how it was paid, refunds), End of days, customer credit with its trail, and "
            "purchases; soon after each change in Aronium and every 15 minutes, in the background. Updates itself "
            "(checked downloads from the shop's GitHub only). A Link PIN guards the settings and stopping; if sending is "
            "stopped or the Link removed, the Easy Buys app warns the owner. Build 2: each End of day also sends the "
            "products sold in it (for the cigarette tally at every shift change). Next build: when the office presses "
            "\"Get the End of day now\" in the app, the Link sends the shop's End of day at once (it checks every 30 seconds)."),
]


def shown_build() -> str:
    b = str(BUILD).strip()
    return str(max(1, int(b) - BUILD_BASE)) if b.isdigit() else b


def label() -> str:
    return f"Version {VERSION} · Build {shown_build()}" + (f" · {BUILT}" if BUILT else "")
