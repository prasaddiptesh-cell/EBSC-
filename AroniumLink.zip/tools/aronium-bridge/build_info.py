"""Version and build of the Easy Buys Aronium Link. The build machine fills in BUILD and BUILT (see the GitHub
workflow); a copy run from the source says "dev"."""
VERSION = "1.0"
BUILD = "dev"   # the build machine's run number: only goes up – used to know a newer build (automatic updates)
BUILT = ""
COMMIT = ""
# The build shown to people restarts at 1 from the initial version (run 21 of the build machine = build 1).
BUILD_BASE = 20

NAME = "Easy Buys Aronium Link"
WHAT = "Sends each till PC's Aronium figures (sales, End of days, products, stock, customer credit) to the Easy Buys app."
CHANGES = [
    ("1.0", "Initial version. Reads Aronium only – it never changes anything in Aronium. Sends products, stock, sales "
            "per day, every receipt (how it was paid, refunds), End of days, customer credit with its trail, and "
            "purchases; soon after each change in Aronium and every 15 minutes, in the background. Updates itself "
            "(checked downloads from the shop's GitHub only). A Link PIN guards the settings and stopping; if sending is "
            "stopped or the Link removed, the Easy Buys app warns the owner."),
]


def shown_build() -> str:
    b = str(BUILD).strip()
    return str(max(1, int(b) - BUILD_BASE)) if b.isdigit() else b


def label() -> str:
    return f"Version {VERSION} · Build {shown_build()}" + (f" · {BUILT}" if BUILT else "")
