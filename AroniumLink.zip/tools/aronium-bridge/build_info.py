"""Version and build of the Easy Buys Aronium Link. The build machine fills in BUILD and BUILT (see the GitHub
workflow); a copy run from the source says "dev"."""
VERSION = "1.1"
BUILD = "dev"
BUILT = ""
COMMIT = ""

NAME = "Easy Buys Aronium Link"
WHAT = "Sends each till PC's Aronium figures (sales, End of days, products, stock, customer credit) to the Easy Buys app."
CHANGES = [
    ("1.1", "Sends soon after each change in Aronium as well as every 15 minutes; sales by hour and per cashier; "
            "Easy Buys look with the logo; Status and Settings tabs; live status of what is waiting; Test the cloud and "
            "Test the app buttons; sharp on scaled screens; version and build shown."),
    ("1.0", "First version: products, stock, sales per day, End of days, customer credit and purchases, read-only."),
]


def label() -> str:
    return f"Version {VERSION} · Build {BUILD}" + (f" · {BUILT}" if BUILT else "")
