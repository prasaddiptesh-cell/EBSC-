"""Settings for the Easy Buys Aronium link on one till PC.

Kept in %APPDATA%\\EasyBuysAroniumLink\\settings.json (only this Windows user can read that folder).
The main-software key is locked with Windows' own protection (DPAPI) so a copied settings file is useless on
another PC or another Windows user. On other systems (tests) it is kept as typed.
"""
from __future__ import annotations

import base64
import json
import os
import sys
from pathlib import Path
from typing import Any

SHOPS = {
    "S1": "Shop 1 - Drasa Avenue",
    "S2": "Shop 2 - Tukani Street",
}

DEFAULTS: dict[str, Any] = {
    "shop_code": "S1",
    "till_number": 1,
    "database_path": "",
    "cloud_url": "",
    "main_key": "",
    "every_min": 15,          # how often it runs on its own
    "sales_every_min": 10,    # today's sales and the open End of day on the 15-minute run (a change in Aronium sends sooner)
    "watch_gap_min": 1,       # after a change in Aronium: wait until it has been quiet 15 s, at most one send a minute
    "busy_every_min": 60,     # today's sales, stock and the health check: at most this often
    "resend_days": 3,         # these last days are always checked again
    "history_days": 400,      # used only when history_from is "days"
    "history_from": "all",    # the very first send: "all" (everything Aronium has), a date "2026-01-01", or "days"
}


def home() -> Path:
    base = os.environ.get("EASYBUYS_LINK_HOME") or os.environ.get("APPDATA") or str(Path.home() / ".config")
    p = Path(base) / "EasyBuysAroniumLink"
    p.mkdir(parents=True, exist_ok=True)
    return p


def source_id(cfg: dict[str, Any]) -> str:
    return f"{cfg.get('shop_code', 'S1')}-T{int(cfg.get('till_number') or 1)}"


def till_name(cfg: dict[str, Any]) -> str:
    return f"{SHOPS.get(cfg.get('shop_code', ''), cfg.get('shop_code', ''))}, Till {int(cfg.get('till_number') or 1)}"


# ------------------------------------------------------------------ Windows DPAPI (key locking)
def _dpapi(data: bytes, protect: bool) -> bytes:
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data, len(data))
    src = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    out = BLOB()
    crypt = ctypes.windll.crypt32
    fn = crypt.CryptProtectData if protect else crypt.CryptUnprotectData
    ok = fn(ctypes.byref(src), None, None, None, None, 0x01, ctypes.byref(out))  # 0x01 = no prompt
    if not ok:
        raise OSError("Windows could not lock / unlock the key")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def lock_key(key: str) -> str:
    if not key:
        return ""
    if sys.platform == "win32":
        try:
            return "dpapi:" + base64.b64encode(_dpapi(key.encode("utf-8"), True)).decode("ascii")
        except OSError:
            pass
    return "plain:" + key


def unlock_key(stored: str) -> str:
    if not stored:
        return ""
    if stored.startswith("dpapi:"):
        try:
            return _dpapi(base64.b64decode(stored[6:]), False).decode("utf-8")
        except Exception:  # noqa: BLE001 - another PC / user: the key must be typed again
            return ""
    if stored.startswith("plain:"):
        return stored[6:]
    return stored


# ------------------------------------------------------------------ load / save
def path() -> Path:
    return home() / "settings.json"


def load() -> dict[str, Any]:
    cfg = dict(DEFAULTS)
    p = path()
    if p.is_file():
        try:
            saved = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                cfg.update({k: v for k, v in saved.items() if k in DEFAULTS or k == "main_key_locked"})
        except (OSError, ValueError):
            pass  # a damaged file: start from the defaults (nothing in Aronium depends on it)
    cfg["main_key"] = unlock_key(str(cfg.pop("main_key_locked", "") or "")) or (cfg.get("main_key") or "")
    cfg["source_id"] = source_id(cfg)
    cfg["till_name"] = till_name(cfg)
    return cfg


def save(cfg: dict[str, Any]) -> None:
    out = {k: cfg.get(k, v) for k, v in DEFAULTS.items() if k != "main_key"}
    out["main_key_locked"] = lock_key(str(cfg.get("main_key") or "").strip())
    p = path()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(out, indent=2), encoding="utf-8")
    os.replace(tmp, p)


def problems(cfg: dict[str, Any]) -> list[str]:
    """What still has to be filled in, in plain words."""
    out = []
    if cfg.get("shop_code") not in SHOPS:
        out.append("Choose the shop.")
    if int(cfg.get("till_number") or 0) not in (1, 2, 3, 4):
        out.append("Choose the till number.")
    if not cfg.get("database_path") or not Path(str(cfg["database_path"])).is_file():
        out.append("Choose the Aronium database (pos.db).")
    if not str(cfg.get("cloud_url", "")).startswith("https://script.google.com/"):
        out.append("Paste the cloud web address (it starts with https://script.google.com/).")
    if len(str(cfg.get("main_key") or "")) < 20:
        out.append("Paste the main-software key.")
    return out
