"""Turns what was read from Aronium into small records for the Easy Buys cloud, remembers what was already sent
(only changes are sent again), and sends them through the cloud's "main software" door (main_push).

Each record goes into the app's table `aronium_feed`:
  uid      SOURCE|kind|period|part      e.g. S1-T1|z|z1532|0, S1-T1|sales_day|2026-10-11|0, S1-T1|products|all|3
  source   which till (S1-T1, S1-T2, S2-T1)   shop_code   S1 / S2      till   Till 1 ...
  kind     products, stock, parties, users, sales_day, receipts, z, z_items, credit, credit_trail, purchases, meta
  data     the JSON itself (kept under the cloud's size limit for one cell: big lists are cut into parts)
  hash     so the app knows when something changed

Lists of many rows are sent as a small table: {"cols": [...], "rows": [[...], ...]} (about half the size).

To keep phones and the cloud light, things that change with every sale (today's sales, stock, the health check)
are sent at most once an hour (busy_every_min); End of days, past days, products and prices go as soon as they change.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
import urllib.request
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from build_info import VERSION, BUILD, shown_build  # noqa: E402  (shown in the app under Admin › Aronium link)
MAX_CHARS = 36000   # one record as the cloud stores it (one spreadsheet cell holds 50 000)
BATCH = 12          # records per upload
RUN_SECONDS = 12 * 60  # one run stops sending after this long (the rest goes next time)

SALES_COLS = ["code", "name", "sold", "sold_value", "refunded", "refund_value", "net", "cost"]
RECEIPT_COLS = ["time", "no", "total", "refund", "pay", "who", "lines", "pays", "open"]  # each receipt of the day
STOCK_COLS = ["code", "qty", "reorder_point", "reorder_qty"]


def iso(dt: datetime | None = None) -> str:
    """The time the way the app writes it (UTC, ISO)."""
    d = (dt or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return d.strftime("%Y-%m-%dT%H:%M:%S.") + f"{d.microsecond // 1000:03d}Z"


def stored_size(item: Any) -> int:
    """How many characters an item takes once the cloud keeps it (the data is text inside the row's JSON)."""
    return len(json.dumps(json.dumps(item, separators=(",", ":"), default=str)))


def digest(data: Any) -> str:
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()[:24]


def split(items: list[Any], limit: int = MAX_CHARS - 1500) -> list[list[Any]]:
    """Cut a list into parts that each stay under the size limit (at least one part, even when empty)."""
    parts: list[list[Any]] = [[]]
    size = 4
    for it in items:
        n = stored_size(it) + 2
        if parts[-1] and size + n > limit:
            parts.append([])
            size = 4
        parts[-1].append(it)
        size += n
    return parts


def table(cols: list[str], items: list[dict[str, Any]]) -> list[list[Any]]:
    return [[it.get(c) for c in cols] for it in items]


class State:
    """What was sent before (on this PC): record hashes, how many parts each list had, and the last change seen."""

    def __init__(self, path: Path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        try:
            self._create()
            with closing(self._c()) as c:
                if c.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise sqlite3.DatabaseError("damaged")
        except sqlite3.DatabaseError:
            # This PC's memory of what was sent is damaged (power cut, disk problem): put it aside and start again.
            # Everything is sent once more; the cloud keeps the newest copy, so nothing is doubled.
            import gc
            gc.collect()  # any connection left behind is closed before the file is moved
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            for suffix in ("", "-wal", "-shm"):
                p = Path(str(path) + suffix)
                if p.exists():
                    try:
                        os.replace(p, Path(f"{path}{suffix}.damaged-{stamp}"))
                    except OSError:
                        try:
                            p.unlink()
                        except OSError:
                            pass
            self._create()

    def _create(self) -> None:
        with closing(self._c()) as c:
            c.executescript("""
              CREATE TABLE IF NOT EXISTS sent (uid TEXT PRIMARY KEY, hash TEXT NOT NULL, at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
              CREATE TABLE IF NOT EXISTS outbox (uid TEXT PRIMARY KEY, record TEXT NOT NULL, hash TEXT NOT NULL, tries INTEGER NOT NULL DEFAULT 0, last_error TEXT);
            """)
            c.commit()

    def _c(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.path, timeout=20)
        try:
            c.execute("PRAGMA journal_mode=WAL")
        except Exception:
            c.close()  # on Windows an open connection keeps the file locked, so it could not be set aside
            raise
        return c

    def get(self, key: str, default: str | None = None) -> str | None:
        with closing(self._c()) as c:
            r = c.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
            return r[0] if r else default

    def set(self, key: str, value: str) -> None:
        with closing(self._c()) as c:
            c.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
            c.commit()

    def stamp(self) -> str:
        """Now, but never earlier than a time already used (a PC clock put back must not make the cloud refuse)."""
        now = iso()
        last = self.get("last_stamp") or ""
        if now <= last:
            t = datetime.strptime(last[:23], "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=timezone.utc) + timedelta(milliseconds=1)
            now = iso(t)
        self.set("last_stamp", now)
        return now

    def sent(self, uid: str) -> tuple[str, str] | None:
        """(hash, when) of what was last sent for this record."""
        with closing(self._c()) as c:
            r = c.execute("SELECT hash, at FROM sent WHERE uid = ?", (uid,)).fetchone()
            return (r[0], r[1]) if r else None

    def queued_hash(self, uid: str) -> str | None:
        with closing(self._c()) as c:
            r = c.execute("SELECT hash FROM outbox WHERE uid = ?", (uid,)).fetchone()
            return r[0] if r else None

    def queue(self, rec: dict[str, Any]) -> None:
        with closing(self._c()) as c:
            c.execute("INSERT INTO outbox(uid,record,hash) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET record=excluded.record, hash=excluded.hash",
                      (rec["k"], json.dumps(rec, separators=(",", ":"), default=str), rec["row"]["hash"]))
            c.commit()

    def waiting(self, limit: int = 2000) -> list[dict[str, Any]]:
        with closing(self._c()) as c:
            return [json.loads(r[0]) for r in c.execute("SELECT record FROM outbox ORDER BY tries, uid LIMIT ?", (limit,))]

    def waiting_count(self) -> int:
        with closing(self._c()) as c:
            return int(c.execute("SELECT COUNT(*) FROM outbox").fetchone()[0])

    def waiting_summary(self) -> dict[str, list[str]]:
        """What is waiting to go, by kind: {kind: [periods]} (a sales day's date, an End of day's key…)."""
        out: dict[str, list[str]] = {}
        with closing(self._c()) as c:
            for (uid,) in c.execute("SELECT uid FROM outbox ORDER BY uid"):
                parts = str(uid).split("|")
                kind, period = (parts[1], parts[2]) if len(parts) >= 3 else ("other", "")
                lst = out.setdefault(kind, [])
                if period not in lst:
                    lst.append(period)
        return out

    def sent_count(self) -> int:
        with closing(self._c()) as c:
            return int(c.execute("SELECT COUNT(*) FROM sent").fetchone()[0])

    def last_error(self) -> str:
        with closing(self._c()) as c:
            r = c.execute("SELECT last_error FROM outbox WHERE last_error IS NOT NULL ORDER BY tries DESC LIMIT 1").fetchone()
            return r[0] if r else ""

    def done(self, recs: list[dict[str, Any]]) -> None:
        with closing(self._c()) as c:
            for r in recs:
                c.execute("INSERT INTO sent(uid,hash,at) VALUES(?,?,?) ON CONFLICT(uid) DO UPDATE SET hash=excluded.hash, at=excluded.at", (r["k"], r["row"]["hash"], iso()))
                c.execute("DELETE FROM outbox WHERE uid = ? AND hash = ?", (r["k"], r["row"]["hash"]))
            c.commit()

    def failed(self, recs: list[dict[str, Any]], error: str) -> None:
        with closing(self._c()) as c:
            for r in recs:
                c.execute("UPDATE outbox SET tries = tries + 1, last_error = ? WHERE uid = ?", (error[:500], r["k"]))
            c.commit()

    def forget_sent(self) -> None:
        """Send everything again next time (used by "Send everything again")."""
        with closing(self._c()) as c:
            c.execute("DELETE FROM sent")
            c.execute("DELETE FROM meta WHERE key LIKE 'parts:%' OR key = 'last_doc_update'")
            c.commit()


def make_records(data: dict[str, Any], cfg: dict[str, Any], state: State, *, today: str | None = None,
                 now: datetime | None = None) -> list[dict[str, Any]]:
    """The records to send: new or changed ones only (busy ones at most every busy_every_min minutes)."""
    source, shop, till = cfg["source_id"], cfg["shop_code"], cfg.get("till_name", "")
    busy_min = float(cfg.get("busy_every_min", 60))
    sales_min = float(cfg.get("sales_every_min", busy_min))  # today's sales and the open End of day: fresher than stock
    today = today or datetime.now().strftime("%Y-%m-%d")
    clock = now or datetime.now(timezone.utc)
    out: list[dict[str, Any]] = []

    def too_soon(uid: str, minutes: float) -> bool:
        prev = state.sent(uid)
        if not prev:
            return False
        try:
            at = datetime.strptime(prev[1][:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        except ValueError:
            return False
        return (clock - at).total_seconds() < minutes * 60

    def add(kind: str, period: str, part: int, parts: int, payload: Any, busy: bool | float = False) -> None:
        uid = f"{source}|{kind}|{period}|{part}"
        h = digest(payload)
        prev = state.sent(uid)
        if prev and prev[0] == h:
            return
        if state.queued_hash(uid) == h:
            return
        if busy and too_soon(uid, busy_min if busy is True else float(busy)):
            return
        row = {"uid": uid, "source": source, "shop_code": shop, "till": till, "kind": kind, "period": period, "part": part, "parts": parts,
               "data": json.dumps(payload, separators=(",", ":"), default=str), "hash": h, "made_at": "", "bridge_version": VERSION,
               "updated_at": "", "updated_device": f"bridge-{source}"}
        out.append({"t": "aronium_feed", "k": uid, "u": "", "row": row})

    def add_list(kind: str, period: str, items: list[Any], cols: list[str] | None = None, busy: bool | float = False) -> None:
        rows = table(cols, items) if cols else items
        parts = split(rows)
        prev = int(state.get(f"parts:{kind}:{period}", "0") or 0)
        for i, p in enumerate(parts):
            add(kind, period, i, len(parts), {"cols": cols, "rows": p} if cols else p, busy)
        for i in range(len(parts), prev):  # a list that got shorter: the extra parts are emptied
            add(kind, period, i, len(parts), {"cols": cols, "rows": []} if cols else [], False)
        state.set(f"parts:{kind}:{period}", str(max(len(parts), prev)))

    products = data.get("products", [])
    add_list("products", "all", [{k: v for k, v in p.items() if k not in ("stock", "reorder_point", "reorder_qty")} for p in products])
    add_list("stock", "all", [p for p in products if p.get("stock") is not None or p.get("reorder_point")], STOCK_COLS, busy=True)
    add_list("parties", "all", data.get("parties", []))
    add_list("users", "all", data.get("users", []))
    for d in data.get("sales_days", []):
        add_list("sales_day", d["date"], d["lines"], SALES_COLS, busy=sales_min if (sales_min > 0 and d["date"] >= today) else False)
    for d in data.get("activity", []):  # sales by hour and per cashier (busy hours, cashier watch)
        add("activity", d["date"], 0, 1, d, busy=sales_min if (sales_min > 0 and d["date"] >= today) else False)
    for d in data.get("receipts", []):  # each receipt of the day (the live sales list in the app)
        add_list("receipts", d["date"], d["rows"], RECEIPT_COLS, busy=sales_min if (sales_min > 0 and d["date"] >= today) else False)
    for z0 in data.get("z", []):
        z = {k: v for k, v in z0.items() if k != "items"}
        zbusy = sales_min if (sales_min > 0 and z.get("z_id") is None and z.get("date", "") >= today) else False
        add("z", z["key"], 0, 1, z, busy=zbusy)
        # 1.0.0 the products sold in this End of day (code, qty) – sent in parts beside it (the cigarette tally)
        if z0.get("items") is not None:
            add_list("z_items", z["key"], [{"code": c, "qty": n} for c, n in z0["items"]], ["code", "qty"], busy=zbusy)
    add_list("credit", "all", data.get("credit", []))
    # 1.2 the trail behind each account: every sale on account still owing, and sales / payments of the last 120 days
    add_list("credit_trail", "all", data.get("credit_trail", []))
    by_day: dict[str, list[Any]] = {}
    for p in data.get("purchases", []):
        by_day.setdefault(p.get("date") or "unknown", []).append(p)
    for d, items in sorted(by_day.items()):
        add_list("purchases", d, items)
    add("meta", "all", 0, 1, {**data.get("meta", {}), "bridge_version": VERSION, "build": BUILD, "shown_build": shown_build()}, busy=True)
    return out


def push(records: list[dict[str, Any]], cfg: dict[str, Any], *, post: Callable[[str, bytes], dict[str, Any]] | None = None,
         seconds: float = RUN_SECONDS) -> dict[str, Any]:
    """Send records to the cloud in small batches. Returns {sent, rejected, error}."""
    url = str(cfg.get("cloud_url", "")).strip()
    key = str(cfg.get("main_key", "")).strip()
    if not url.startswith("https://") or not key:
        return {"sent": [], "rejected": [], "error": "Type the cloud web address and the main-software key first (Settings)."}
    do = post or _post
    sent: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    start = time.monotonic()
    for i in range(0, len(records), BATCH):
        if time.monotonic() - start > seconds:
            break  # the rest goes next time
        batch = records[i:i + BATCH]
        body = json.dumps({"kind": "main_push", "key": key, "records": batch}, separators=(",", ":"), default=str).encode("utf-8")
        try:
            res = do(url, body)
        except Exception as exc:  # noqa: BLE001 - every network problem means "try again later"
            return {"sent": sent, "rejected": rejected, "error": f"Could not reach the cloud: {exc}"}
        if not isinstance(res, dict) or not res.get("ok"):
            err = str(res.get("error") or "") if isinstance(res, dict) else ""
            if err == "Not allowed":
                err = "The cloud refused the main-software key. Copy it again from the cloud script (see the guide)."
            return {"sent": sent, "rejected": rejected, "error": err or "The cloud said no."}
        bad = {str(x.get("k")) for x in res.get("rejected", []) if isinstance(x, dict)}
        rejected.extend(r for r in batch if r["k"] in bad)
        sent.extend(r for r in batch if r["k"] not in bad)
    return {"sent": sent, "rejected": rejected, "error": None}


def _post(url: str, body: bytes) -> dict[str, Any]:
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=90) as res:  # Google follows its own redirect for Apps Script
        text = res.read().decode("utf-8", "replace")
    try:
        return json.loads(text)
    except ValueError:
        raise RuntimeError("the address did not answer like the Easy Buys cloud (check the cloud address)") from None


def run_once(cfg: dict[str, Any], state: State, *, read: Callable[..., dict[str, Any]], post=None, log: Callable[[str], None] = print,
             today: str | None = None) -> dict[str, Any]:
    """Read Aronium (what changed since last time, plus the last few days again), queue the changes, send."""
    since = state.get("last_doc_update")
    first = since is None
    # 'today' (given by the tests, and by a run for a set day) also sets the window of days read again
    now = datetime.strptime(today, "%Y-%m-%d").replace(hour=23, minute=59) if today else datetime.now()
    days_back = int(cfg.get("resend_days", 3))
    since_day = None if first else (now - timedelta(days=days_back)).strftime("%Y-%m-%d")
    hf = str(cfg.get("history_from", "all") or "all").strip()
    if hf == "all":
        oldest = None
    elif len(hf) == 10 and hf[4] == "-" and hf[7] == "-":
        oldest = hf
    else:
        oldest = (now - timedelta(days=int(cfg.get("history_days", 400)))).strftime("%Y-%m-%d")
    data = read(cfg["database_path"], since=since, since_day=since_day, oldest=oldest)
    recs = make_records(data, cfg, state, today=today)
    for r in recs:
        state.queue(r)
    waiting = state.waiting()
    for r in waiting:  # stamped when sent, so the cloud always sees it as the newest
        u = state.stamp()
        r["u"] = u
        r["row"]["updated_at"] = u
        r["row"]["made_at"] = r["row"]["made_at"] or u
    log(f"Read Aronium: {len(data.get('products', []))} products, {len(data.get('sales_days', []))} day(s) of sales, "
        f"{len(data.get('z', []))} End of day(s). {len(recs)} change(s) to send, {len(waiting)} waiting in all.")
    res = push(waiting, cfg, post=post) if waiting else {"sent": [], "rejected": [], "error": None}
    # Refused ones (the cloud already has a newer copy) are finished too - they must not be sent forever.
    if res["sent"] or res["rejected"]:
        state.done(res["sent"] + res["rejected"])
    finished = {r["k"] for r in res["sent"] + res["rejected"]}
    if res["error"]:
        state.failed([r for r in waiting if r["k"] not in finished], res["error"])
        log(f"Not sent yet (kept to try again): {res['error']}")
    else:
        if len(finished) >= len(waiting):
            newest = data.get("newest_update")
            if newest:
                state.set("last_doc_update", newest)
        state.set("last_ok", iso())
        left = state.waiting_count()
        log(f"Sent {len(res['sent'])} record(s) to the cloud." + (f" {len(res['rejected'])} already there." if res["rejected"] else "")
            + (f" {left} more go next time." if left else ""))
    state.set("last_run", iso())
    state.set("last_result", "ok" if not res["error"] else res["error"])
    return {"read": data, "queued": len(recs), **res, "waiting": state.waiting_count()}
