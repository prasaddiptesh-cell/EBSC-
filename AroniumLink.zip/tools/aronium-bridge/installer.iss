; Easy Buys Aronium Link – Windows installer (built by the GitHub workflow with Inno Setup 6).
; Installs to Program Files, adds Start menu and desktop icons, shows in Settings › Apps with Uninstall.
; Updating: run the new installer over the old one – settings and what was sent are kept (they live in the user's
; AppData, not here), and sending on its own carries on.
#ifndef AppVersion
  #define AppVersion "1.1"
#endif
#ifndef Build
  #define Build "0"
#endif

[Setup]
AppId={{6E3C7B0E-2C55-4C7F-9C1B-8B5E2A9D4E11}
AppName=Easy Buys Aronium Link
AppVersion={#AppVersion}.{#Build}
AppVerName=Easy Buys Aronium Link {#AppVersion} (build {#Build})
AppPublisher=Easy Buys Shopping Centre
DefaultDirName={autopf}\Easy Buys\Aronium Link
DefaultGroupName=Easy Buys
DisableProgramGroupPage=yes
DisableDirPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=output
OutputBaseFilename=EasyBuysAroniumLink-Setup
SetupIconFile=assets\icon.ico
UninstallDisplayIcon={app}\EasyBuysAroniumLink.exe
UninstallDisplayName=Easy Buys Aronium Link
WizardStyle=modern
WizardImageFile=assets\wizard.bmp
WizardSmallImageFile=assets\wizard-small.bmp
Compression=lzma2
SolidCompression=yes
CloseApplications=force
RestartApplications=no
VersionInfoVersion={#AppVersion}.{#Build}.0
VersionInfoCompany=Easy Buys Shopping Centre
VersionInfoDescription=Easy Buys Aronium Link setup

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Messages]
WelcomeLabel2=This installs the Easy Buys Aronium Link on this till PC.%n%nIt reads Aronium (it never changes anything in Aronium) and sends this till's sales and End of days to the Easy Buys app.%n%nIf an older version is installed, it is updated and its settings are kept.

[Tasks]
Name: "desktopicon"; Description: "Put an icon on the desktop"; GroupDescription: "Icons:"

[Files]
Source: "dist\EasyBuysAroniumLink.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Easy Buys Aronium Link"; Filename: "{app}\EasyBuysAroniumLink.exe"
Name: "{group}\Uninstall Easy Buys Aronium Link"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Easy Buys Aronium Link"; Filename: "{app}\EasyBuysAroniumLink.exe"; Tasks: desktopicon

[Run]
; after an update: if it was sending on its own, point Windows at the new copy and start watching again
Filename: "{app}\EasyBuysAroniumLink.exe"; Parameters: "--reschedule"; Flags: runhidden waituntilterminated skipifsilent runasoriginaluser
Filename: "{app}\EasyBuysAroniumLink.exe"; Description: "Open the Easy Buys Aronium Link now"; Flags: nowait postinstall skipifsilent runasoriginaluser

[UninstallRun]
Filename: "{app}\EasyBuysAroniumLink.exe"; Parameters: "--uninstall"; Flags: runhidden waituntilterminated; RunOnceId: "StopSending"
Filename: "{sys}\taskkill.exe"; Parameters: "/F /IM EasyBuysAroniumLink.exe"; Flags: runhidden; RunOnceId: "StopWatcher"

[Code]
// Before copying the new program: stop the background watcher, so its file can be replaced. Windows starts it
// again afterwards (the --reschedule step above, or its next 15-minute turn).
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
begin
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/F /IM EasyBuysAroniumLink.exe', '', SW_HIDE, ewWaitUntilTerminated, Code);
  Result := '';
end;
