"""Makes the signed update manifest for the till PCs (run by the build, never on a till PC).

    python sign_manifest.py --installer output/EasyBuysAroniumLink-Setup.exe --build 57 --version 1.3 \
        --key /path/to/link-update-ed25519.pem        (or --key-env LINK_SIGNING_KEY: the PEM text in that variable)

Writes next to the installer:
    link-version.json            {"build", "version", "name", "size", "sha256"}  (the exact bytes are what is signed)
    link-version.json.sig        the Ed25519 signature of those bytes, base64
    EasyBuysAroniumLink-Setup.exe.sha256

The PRIVATE key never goes in the repository: on the build it comes from the secret LINK_SIGNING_KEY. The public half
is baked into updater.py (PUBLIC_KEY_HEX); a till PC installs nothing whose manifest it cannot verify with it.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ed25519_verify  # noqa: E402

PKCS8_PREFIX = bytes.fromhex("302e020100300506032b657004220420")


def private_from_pem(text: str) -> bytes:
    """The 32-byte Ed25519 private key from an OpenSSL PEM ("-----BEGIN PRIVATE KEY-----", PKCS#8)."""
    body = "".join(line.strip() for line in str(text).strip().splitlines() if line.strip() and not line.startswith("-----"))
    der = base64.b64decode(body)
    if len(der) != 48 or not der.startswith(PKCS8_PREFIX):
        raise ValueError("not an Ed25519 private key (PKCS#8 PEM)")
    return der[16:]


def make_manifest(installer: Path, build: int, version: str, name: str = "EasyBuysAroniumLink-Setup.exe") -> bytes:
    data = Path(installer).read_bytes()
    m = {"build": int(build), "version": str(version), "name": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    return json.dumps(m, separators=(",", ":"), sort_keys=True).encode("utf-8")


def write_all(installer: Path, build: int, version: str, secret: bytes, out_dir: Path | None = None) -> dict[str, Path]:
    out = Path(out_dir or Path(installer).parent)
    manifest = make_manifest(installer, build, version)
    sig = ed25519_verify.sign(secret, manifest)
    sha = json.loads(manifest)["sha256"]
    files = {"manifest": out / "link-version.json", "sig": out / "link-version.json.sig", "sha": out / "EasyBuysAroniumLink-Setup.exe.sha256"}
    files["manifest"].write_bytes(manifest)
    files["sig"].write_text(base64.b64encode(sig).decode("ascii") + "\n", encoding="ascii")
    files["sha"].write_text(f"{sha}  EasyBuysAroniumLink-Setup.exe\n", encoding="ascii")
    return files


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--installer", required=True)
    ap.add_argument("--build", required=True, type=int)
    ap.add_argument("--version", required=True)
    ap.add_argument("--key")
    ap.add_argument("--key-env")
    ap.add_argument("--out-dir")
    a = ap.parse_args(argv)
    pem = Path(a.key).read_text(encoding="ascii") if a.key else os.environ.get(a.key_env or "", "")
    if not pem.strip():
        print("No signing key given (--key file or --key-env VARIABLE).", file=sys.stderr)
        return 2
    secret = private_from_pem(pem)
    files = write_all(Path(a.installer), a.build, a.version, secret, Path(a.out_dir) if a.out_dir else None)
    print("Public key (must match updater.PUBLIC_KEY_HEX):", ed25519_verify.public_key(secret).hex())
    for f in files.values():
        print("wrote", f)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
