"""Test helper (not part of the program): drives the real till program against a local copy of the cloud script,
for the app's end-to-end test (tests/e2e394.test.js).

  e2e_drive.py make  DB
  e2e_drive.py sale  DB ID WHEN PRODUCT QTY PRICE
  e2e_drive.py run   HOME DB PORT SHOP TILL KEY [resend]
  e2e_drive.py testapp HOME DB PORT SHOP TILL KEY
Prints one line of JSON.
"""
import json
import os
import sys
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))


def local_post(port):
    def post(url, body):
        req = urllib.request.Request(f"http://127.0.0.1:{port}/", data=body, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    return post


def cfg_for(home, db, shop, till, key):
    os.environ["EASYBUYS_LINK_HOME"] = home
    import config
    c = config.load()
    c.update({"database_path": db, "cloud_url": "https://script.google.com/macros/s/LOCAL/exec", "main_key": key, "shop_code": shop,
              "till_number": int(till), "busy_every_min": 0, "sales_every_min": 0,
              # the test sales are dated 9–11 Oct 2026: read those days again whatever the real date is today
              "resend_days": 3650})
    c["source_id"] = config.source_id(c)
    c["till_name"] = config.till_name(c)
    return c


def main():
    cmd = sys.argv[1]
    if cmd == "make":
        import fake_aronium
        fake_aronium.make(Path(sys.argv[2]))
        print(json.dumps({"ok": True}))
    elif cmd == "sale":
        import fake_aronium
        _, _, db, i, when, prod, qty, price = sys.argv
        fake_aronium.add_sale(Path(db), int(i), when, int(prod), float(qty), float(price))
        print(json.dumps({"ok": True}))
    elif cmd == "run":
        home, db, port, shop, till, key = sys.argv[2:8]
        c = cfg_for(home, db, shop, till, key)
        import bridge
        if len(sys.argv) > 8 and sys.argv[8] == "resend":
            bridge.state().forget_sent()
        r = bridge.run(c, post=local_post(port))
        print(json.dumps({k: r.get(k) for k in ("ok", "error", "sent", "waiting")}))
    elif cmd == "testapp":
        home, db, port, shop, till, key = sys.argv[2:8]
        c = cfg_for(home, db, shop, till, key)
        import bridge
        r = bridge.test_app(c, post=local_post(port), wait_s=60, every_s=1)
        print(json.dumps(r))


if __name__ == "__main__":
    main()
