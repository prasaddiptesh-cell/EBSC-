"""A small made-up Aronium database (same tables and columns as Aronium's pos.db) for the tests."""
from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE ProductGroup (Id INTEGER PRIMARY KEY, Name TEXT);
CREATE TABLE Product (Id INTEGER PRIMARY KEY, ProductGroupId INTEGER, Name TEXT, Code TEXT, PLU INTEGER, MeasurementUnit TEXT,
  Price NUMERIC, IsTaxInclusivePrice INTEGER, IsService INTEGER, IsEnabled INTEGER, Cost NUMERIC, LastPurchasePrice NUMERIC, DateUpdated TEXT);
CREATE TABLE Barcode (Id INTEGER PRIMARY KEY, ProductId INTEGER, Value TEXT);
CREATE TABLE Tax (Id INTEGER PRIMARY KEY, Name TEXT, Rate NUMERIC, IsEnabled INTEGER);
CREATE TABLE ProductTax (Id INTEGER PRIMARY KEY, ProductId INTEGER, TaxId INTEGER);
CREATE TABLE Stock (Id INTEGER PRIMARY KEY, ProductId INTEGER, WarehouseId INTEGER, Quantity NUMERIC);
CREATE TABLE StockControl (Id INTEGER PRIMARY KEY, ProductId INTEGER, ReorderPoint NUMERIC, PreferredQuantity NUMERIC);
CREATE TABLE Customer (Id INTEGER PRIMARY KEY, Name TEXT, Code TEXT, TaxNumber TEXT, Address TEXT, City TEXT, Email TEXT, PhoneNumber TEXT,
  IsEnabled INTEGER, IsCustomer INTEGER, IsSupplier INTEGER, DueDatePeriod INTEGER, IsTaxExempt INTEGER);
CREATE TABLE User (Id INTEGER PRIMARY KEY, FirstName TEXT, LastName TEXT, Username TEXT, IsEnabled INTEGER);
CREATE TABLE DocumentType (Id INTEGER PRIMARY KEY, Name TEXT, Code TEXT, StockDirection INTEGER);
CREATE TABLE Document (Id INTEGER PRIMARY KEY, Number TEXT, UserId INTEGER, CustomerId INTEGER, Date TEXT, Total NUMERIC, DocumentTypeId INTEGER,
  Discount NUMERIC, PaidStatus INTEGER, ReferenceDocumentNumber TEXT, DateCreated TEXT, DateUpdated TEXT);
CREATE TABLE DocumentItem (Id INTEGER PRIMARY KEY, DocumentId INTEGER, ProductId INTEGER, Quantity NUMERIC, Price NUMERIC, Discount NUMERIC,
  ProductCost NUMERIC, Total NUMERIC, TotalAfterDocumentDiscount NUMERIC);
CREATE TABLE DocumentItemTax (Id INTEGER PRIMARY KEY, DocumentItemId INTEGER, TaxId INTEGER, Amount NUMERIC);
CREATE TABLE PaymentType (Id INTEGER PRIMARY KEY, Name TEXT, MarkAsPaid INTEGER);
CREATE TABLE Payment (Id INTEGER PRIMARY KEY, DocumentId INTEGER, PaymentTypeId INTEGER, Amount NUMERIC, Date TEXT, UserId INTEGER, ZReportId INTEGER, DateCreated TEXT);
CREATE TABLE ZReport (Id INTEGER PRIMARY KEY, Number INTEGER, DateCreated TEXT);
CREATE TABLE StartingCash (Id INTEGER PRIMARY KEY, UserId INTEGER, Amount NUMERIC, StartingCashType INTEGER, ZReportNumber INTEGER);
CREATE TABLE PosVoid (Id INTEGER PRIMARY KEY, ProductId INTEGER, Quantity NUMERIC, Total NUMERIC, DateVoided TEXT);
"""


def make(path: Path) -> Path:
    path = Path(path)
    if path.exists():
        path.unlink()
    c = sqlite3.connect(path)
    c.executescript(SCHEMA)
    c.executemany("INSERT INTO ProductGroup VALUES (?,?)", [(1, "Bakery"), (2, "Grocery")])
    c.executemany("INSERT INTO Product VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", [
        (1, 1, "Bread Loaf", "1001", 1, "ea", 2.50, 1, 0, 1, 1.20, 1.25, "2026-10-01 08:00:00"),
        (2, 2, "Rice 10kg", "2001", 2, "bag", 25.00, 1, 0, 1, 19.5, 19.5, "2026-10-01 08:00:00"),
        (3, 2, "Coke 1.5L", "", 3, "ea", 3.95, 1, 0, 1, None, 2.10, "2026-10-01 08:00:00"),
    ])
    c.executemany("INSERT INTO Barcode VALUES (?,?,?)", [(1, 2, "9421000000001"), (2, 3, "5449000000996"), (3, 3, "5449000000997")])
    c.executemany("INSERT INTO Tax VALUES (?,?,?,?)", [(1, "VAT 12.5%", 12.5, 1)])
    c.executemany("INSERT INTO ProductTax VALUES (?,?,?)", [(1, 3, 1)])  # only Coke has VAT; bread and rice are zero rated
    c.executemany("INSERT INTO Stock VALUES (?,?,?,?)", [(1, 1, 1, 40), (2, 2, 1, 12), (3, 3, 1, 30), (4, 3, 2, 6)])
    c.executemany("INSERT INTO StockControl VALUES (?,?,?,?)", [(1, 2, 5, 20)])
    c.executemany("INSERT INTO Customer VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", [
        (1, "Ravi (staff)", "C1", "", "", "", "", "722", 1, 1, 0, None, 0),
        (2, "Fiji Rice Ltd", "S1", "50-12345-0-1", "Lot 1", "Lautoka", "a@b.fj", "666", 1, 0, 1, 30, 0),
    ])
    c.executemany("INSERT INTO User VALUES (?,?,?,?,?)", [(1, "Asha", "K", "asha", 1), (2, "Ben", "", "ben", 1)])
    c.executemany("INSERT INTO DocumentType VALUES (?,?,?,?)", [(1, "Purchase", "100", 1), (2, "Sales", "200", -1), (3, "Refund", "220", 1)])
    c.executemany("INSERT INTO PaymentType VALUES (?,?,?)", [(1, "Cash", 1), (2, "M-PAiSA", 1), (3, "Account", 0)])
    c.executemany("INSERT INTO ZReport VALUES (?,?,?)", [(1, 101, "2026-10-09 21:00:00")])
    # Day 1 (2026-10-09, Z 101): two sales and one refund
    docs = [
        (1, "S-1", 1, None, "2026-10-09 09:00:00", 9.95, 2, 0, 2, None, "2026-10-09 09:00:00", "2026-10-09 09:00:00"),
        (2, "S-2", 2, None, "2026-10-09 10:00:00", 25.00, 2, 0, 2, None, "2026-10-09 10:00:00", "2026-10-09 10:00:00"),
        (3, "R-1", 1, None, "2026-10-09 11:00:00", -3.95, 3, 0, 2, None, "2026-10-09 11:00:00", "2026-10-09 11:00:00"),
        # Day 2 (2026-10-10, open shift - not in a Z yet): staff credit sale, unpaid
        (4, "S-3", 1, 1, "2026-10-10 08:30:00", 5.00, 2, 0, 0, None, "2026-10-10 08:30:00", "2026-10-10 08:30:00"),
        # purchase from the supplier
        (5, "P-1", 1, 2, "2026-10-10 07:00:00", 195.0, 1, 0, 2, "INV-77", "2026-10-10 07:00:00", "2026-10-10 07:00:00"),
    ]
    c.executemany("INSERT INTO Document VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", docs)
    c.executemany("INSERT INTO DocumentItem VALUES (?,?,?,?,?,?,?,?,?)", [
        (1, 1, 1, 2, 2.50, 0, 1.20, 5.00, 5.00),
        (2, 1, 3, 1, 3.95, 0, 2.10, 3.95, 3.95),
        (3, 1, 3, 1, 3.95, 2.95, 2.10, 1.00, 1.00),  # a discounted coke
        (4, 2, 2, 1, 25.0, 0, 19.5, 25.0, 25.0),
        (5, 3, 3, -1, 3.95, 0, 2.10, -3.95, -3.95),
        (6, 4, 1, 2, 2.50, 0, 1.20, 5.00, 5.00),
        (7, 5, 2, 10, 19.5, 0, 19.5, 195.0, 195.0),
    ])
    c.executemany("INSERT INTO DocumentItemTax VALUES (?,?,?,?)", [(1, 2, 1, 0.44), (2, 3, 1, 0.11), (3, 5, 1, -0.44)])
    c.executemany("INSERT INTO Payment VALUES (?,?,?,?,?,?,?,?)", [
        (1, 1, 1, 9.95, "2026-10-09 09:00:00", 1, 1, "2026-10-09 09:00:00"),
        (2, 2, 2, 25.00, "2026-10-09 10:00:00", 2, 1, "2026-10-09 10:00:00"),
        (3, 3, 1, -3.95, "2026-10-09 11:00:00", 1, 1, "2026-10-09 11:00:00"),
    ])
    c.executemany("INSERT INTO StartingCash VALUES (?,?,?,?,?)", [(1, 1, 100.0, 0, 1), (2, 1, 20.0, 2, 1)])
    c.executemany("INSERT INTO PosVoid VALUES (?,?,?,?,?)", [(1, 3, 1, 3.95, "2026-10-09 09:30:00")])
    c.commit()
    c.close()
    return path


def add_sale(path: Path, doc_id: int, when: str, product: int, qty: float, price: float) -> None:
    c = sqlite3.connect(path)
    c.execute("INSERT INTO Document VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (doc_id, f"S-{doc_id}", 1, None, when, qty * price, 2, 0, 2, None, when, when))
    c.execute("INSERT INTO DocumentItem (DocumentId, ProductId, Quantity, Price, Discount, ProductCost, Total, TotalAfterDocumentDiscount) VALUES (?,?,?,?,?,?,?,?)",
              (doc_id, product, qty, price, 0, 1.0, qty * price, qty * price))
    c.execute("INSERT INTO Payment (DocumentId, PaymentTypeId, Amount, Date, UserId, ZReportId, DateCreated) VALUES (?,?,?,?,?,?,?)",
              (doc_id, 1, qty * price, when, 1, None, when))
    c.commit()
    c.close()
