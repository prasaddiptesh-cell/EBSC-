"""Build check only (not part of the program): opens the window, fills it in and saves a picture of it."""
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
os.environ.setdefault("EASYBUYS_LINK_HOME", str(HERE.parent / "preview-home"))

import app  # noqa: E402

app.sharp_on_windows()
from bridge_ui import BridgeUI  # noqa: E402

ui = BridgeUI()
ui.db.insert(0, r"C:\Users\Till\AppData\Local\Aronium\Data\pos.db")
ui.url.insert(0, "https://script.google.com/macros/s/…/exec")
ui._say("✓ Aronium found: 357 products, 243 documents, 15 customers / suppliers, 5 End of days.")
ui._say("! Example warning line.")
ui._say("✗ Example problem line.")
ui.update()
ui.lift()
ui.attributes("-topmost", True)
for _ in range(20):
    ui.update()
    time.sleep(0.1)
x, y, w, h = ui.winfo_rootx(), ui.winfo_rooty(), ui.winfo_width(), ui.winfo_height()
from PIL import ImageGrab  # noqa: E402
ImageGrab.grab(bbox=(x - 8, y - 32, x + w + 8, y + h + 8), all_screens=True).save(sys.argv[1] if len(sys.argv) > 1 else "preview.png")
print("window", w, h)
ui.destroy()
