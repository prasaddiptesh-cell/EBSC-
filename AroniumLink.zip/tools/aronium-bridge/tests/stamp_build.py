"""Build machine only: writes the build number, date and commit into build_info.py and makes the Windows version
information (right-click the .exe › Properties › Details)."""
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent.parent
build, commit = (sys.argv[1] if len(sys.argv) > 1 else "0"), (sys.argv[2] if len(sys.argv) > 2 else "")
bi = root / "build_info.py"
s = bi.read_text(encoding="utf-8")
built = datetime.now(timezone.utc).strftime("%d %b %Y")
s = re.sub(r'^BUILD = .*$', f'BUILD = "{build}"', s, flags=re.M)
s = re.sub(r'^BUILT = .*$', f'BUILT = "{built}"', s, flags=re.M)
s = re.sub(r'^COMMIT = .*$', f'COMMIT = "{commit}"', s, flags=re.M)
bi.write_text(s, encoding="utf-8")
ver = re.search(r'^VERSION = "([^"]+)"', s, flags=re.M).group(1)
nums = [int(x) for x in (ver.split(".") + ["0", "0"])[:2]] + [int(build) if build.isdigit() else 0, 0]
t = tuple(nums)
(root / "version.txt").write_text(f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={t}, prodvers={t}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', 'Easy Buys Shopping Centre'),
      StringStruct('FileDescription', 'Easy Buys Aronium Link'),
      StringStruct('FileVersion', '{ver}.{build}'),
      StringStruct('InternalName', 'EasyBuysAroniumLink'),
      StringStruct('LegalCopyright', 'Easy Buys Shopping Centre'),
      StringStruct('OriginalFilename', 'EasyBuysAroniumLink.exe'),
      StringStruct('ProductName', 'Easy Buys Aronium Link'),
      StringStruct('ProductVersion', '{ver} (build {build})')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
""", encoding="utf-8")
print(f"Version {ver}, build {build}, {built}")
