"""Everything that can go wrong on a till PC. Each case: the program never crashes, never changes Aronium, tells
the truth about what happened, and once the problem is gone it catches up with nothing lost and nothing doubled.

Run:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import json
import os
import random
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import aronium_read  # noqa: E402
import config  # noqa: E402
import fake_aronium  # noqa: E402
import feed  # noqa: E402
from test_link import FakeCloud, file_hash  # noqa: E402

KEY = "k" * 40
URL = "https://script.google.com/macros/s/a/exec"


class Cloud(FakeCloud):
    """The fake cloud with switchable trouble: down, slow, garbage answers, an HTML page, refusing the key."""

    def __init__(self):
        super().__init__()
        self.mode = "ok"
        self.fail_after = None  # fail every call after this many good ones

    def __call__(self, url, body):
        if self.fail_after is not None:
            if self.fail_after <= 0:
                self.calls += 1
                raise OSError("connection reset")
            self.fail_after -= 1
        m = self.mode
        if m == "down":
            self.calls += 1
            raise OSError("[Errno 11001] getaddrinfo failed")
        if m == "timeout":
            self.calls += 1
            raise TimeoutError("timed out")
        if m == "html":
            self.calls += 1
            raise RuntimeError("the address did not answer like the Easy Buys cloud (check the cloud address)")
        if m == "garbage":
            self.calls += 1
            return ["not", "a", "dict"]
        if m == "busy":
            self.calls += 1
            return {"ok": False, "error": "Service invoked too many times for one day"}
        return super().__call__(url, body)

    def totals(self, source="S1-T1"):
        """What the cloud holds for one till: sales value per day (all parts) and End of day totals."""
        days: dict[str, float] = {}
        for k, row in self.rows.items():
            parts = k.split("|")
            if parts[0] != source:
                continue
            d = json.loads(row["data"])
            if parts[1] == "sales_day":
                rows = d["rows"] if isinstance(d, dict) else d
                cols = d["cols"] if isinstance(d, dict) else None
                for r in rows:
                    x = dict(zip(cols, r)) if cols else r
                    days[parts[2]] = round(days.get(parts[2], 0) + float(x["sold_value"]) - float(x["refund_value"]), 2)
        return days


def aronium_day_totals(db: Path) -> dict[str, float]:
    """The same figure worked out straight from Aronium (sales minus refunds per day, from the receipt lines)."""
    c = sqlite3.connect(db)
    out: dict[str, float] = {}
    for d, v in c.execute("""SELECT substr(COALESCE(d.Date, d.DateCreated), 1, 10), SUM(ABS(di.TotalAfterDocumentDiscount) * CASE WHEN d.DocumentTypeId = 3 THEN -1 ELSE 1 END)
                            FROM DocumentItem di JOIN Document d ON d.Id = di.DocumentId WHERE d.DocumentTypeId IN (2, 3) GROUP BY 1"""):
        out[d] = round(v, 2)
    c.close()
    return out


class Chaos(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        os.environ["EASYBUYS_LINK_HOME"] = str(self.tmp / "home")
        self.db = fake_aronium.make(self.tmp / "pos.db")
        import bridge
        self.bridge = bridge

    def tearDown(self):
        os.environ.pop("EASYBUYS_LINK_HOME", None)

    def cfg(self, **kw):
        c = config.load()
        c.update({"database_path": str(self.db), "cloud_url": URL, "main_key": KEY, "busy_every_min": 0, "sales_every_min": 0})
        c.update(kw)
        return c

    def run_ok(self, cloud, **kw):
        r = self.bridge.run(self.cfg(**kw), post=cloud)
        self.assertIsInstance(r, dict)
        return r

    # ------------------------------------------------------------ the Aronium database
    def test_database_missing(self):
        r = self.run_ok(Cloud(), database_path=str(self.tmp / "gone.db"))
        self.assertFalse(r["ok"])
        self.assertIn("Choose the Aronium database", r["error"])
        chk = self.bridge.check(self.cfg(database_path=str(self.tmp / "gone.db")))
        self.assertFalse(chk["ok"])

    def test_not_a_database(self):
        bad = self.tmp / "pos.db.txt"
        bad.write_text("hello, I am a text file")
        r = self.run_ok(Cloud(), database_path=str(bad))
        self.assertFalse(r["ok"])
        self.assertTrue(r["error"])
        chk = self.bridge.check(self.cfg(database_path=str(bad)))
        self.assertTrue(any("Could not read" in x for x in chk["lines"]), chk)

    def test_damaged_database(self):
        data = bytearray(self.db.read_bytes())
        for i in range(4096, min(len(data), 12000)):
            data[i] = random.randint(0, 255)
        bad = self.tmp / "damaged.db"
        bad.write_bytes(bytes(data))
        r = self.run_ok(Cloud(), database_path=str(bad))
        self.assertFalse(r["ok"])  # reported, not crashed

    def test_wrong_sqlite_file(self):
        other = self.tmp / "other.db"
        c = sqlite3.connect(other)
        c.execute("CREATE TABLE Something (x)")
        c.commit()
        c.close()
        r = self.run_ok(Cloud(), database_path=str(other))
        self.assertFalse(r["ok"])
        self.assertIn("Aronium database", r["error"])

    def test_empty_aronium(self):
        empty = self.tmp / "empty.db"
        c = sqlite3.connect(empty)
        c.executescript(fake_aronium.SCHEMA)
        c.close()
        cloud = Cloud()
        r = self.run_ok(cloud, database_path=str(empty))
        self.assertTrue(r["ok"], r)

    def test_older_aronium_without_optional_tables_and_columns(self):
        c = sqlite3.connect(self.db)
        for t in ("Barcode", "Stock", "StockControl", "ProductTax", "Tax", "ZReport", "PosVoid", "StartingCash", "DocumentItemTax", "DocumentType"):
            c.execute(f"DROP TABLE {t}")
        c.execute("ALTER TABLE Payment DROP COLUMN ZReportId")
        c.execute("ALTER TABLE Document DROP COLUMN DateUpdated")
        c.execute("ALTER TABLE DocumentItem DROP COLUMN ProductCost")
        c.commit()
        c.close()
        cloud = Cloud()
        r = self.run_ok(cloud)
        self.assertTrue(r["ok"], r)
        self.assertTrue(any("|z|d" in k for k in cloud.rows), "each day becomes one End of day")
        chk = self.bridge.check(self.cfg())
        self.assertTrue(chk["ok"], chk)

    def test_odd_values_in_aronium(self):
        c = sqlite3.connect(self.db)
        c.execute("UPDATE Product SET Name = ? WHERE Id = 1", ("Roti 🫓 \"Special\" – Mum's, 10% off\n(new)",))
        c.execute("UPDATE Product SET Name = ? WHERE Id = 2", ("R" * 5000,))
        c.execute("INSERT INTO Document VALUES (90, 'S-90', NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, '2026-10-10 12:00:00', NULL)")
        c.execute("INSERT INTO DocumentItem VALUES (90, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL)")
        c.execute("INSERT INTO Document VALUES (91, 'S-91', 99, 99, 'not a date', 5, 2, 0, 2, NULL, 'garbage', 'garbage')")
        c.execute("INSERT INTO DocumentItem VALUES (91, 91, 999, -3, 2, 0, 1, -6, -6)")
        c.commit()
        c.close()
        cloud = Cloud()
        r = self.run_ok(cloud)
        self.assertTrue(r["ok"], r)
        for row in cloud.rows.values():
            self.assertLess(len(json.dumps(row)), 50000)
        prods = []
        for k, row in cloud.rows.items():
            if "|products|" in k:
                prods += json.loads(row["data"])
        self.assertTrue(any("🫓" in p["name"] for p in prods))

    def test_aronium_is_never_changed_even_when_things_fail(self):
        before = file_hash(self.db)
        stamp = os.stat(self.db).st_mtime_ns
        for mode in ("ok", "down", "html", "garbage", "busy", "timeout"):
            cloud = Cloud()
            cloud.mode = mode
            self.run_ok(cloud)
        self.bridge.check(self.cfg())
        self.assertEqual(file_hash(self.db), before)
        self.assertEqual(os.stat(self.db).st_mtime_ns, stamp)

    def test_aronium_locked_by_a_long_write(self):
        """Aronium holding its database (saving a big sale): the link waits or tries again later, never crashes."""
        holder = sqlite3.connect(self.db, timeout=1, isolation_level=None)
        holder.execute("BEGIN EXCLUSIVE")
        result = {}

        def go():
            result["r"] = self.bridge.run(self.cfg(), post=Cloud())
        t = threading.Thread(target=go)
        t.start()
        time.sleep(2.5)
        holder.execute("COMMIT")
        holder.close()
        t.join(60)
        self.assertFalse(t.is_alive(), "the run finished")
        self.assertIsInstance(result["r"], dict)
        cloud = Cloud()
        self.assertTrue(self.bridge.run(self.cfg(), post=cloud)["ok"])

    def test_sales_being_saved_while_it_reads(self):
        """Aronium keeps selling during every run: nothing breaks, and the final figures match Aronium exactly."""
        cloud = Cloud()
        stop = threading.Event()
        errors = []

        # selling happens today (a past day is outside the days read again, like at a real shop)
        today = __import__('datetime').date.today().isoformat()

        def till():
            n = 1000
            while not stop.is_set():
                try:
                    fake_aronium.add_sale(self.db, n, f"{today} {9 + (n % 8):02d}:{n % 60:02d}:00", 1 + n % 3, 1 + n % 2, 2.5)
                except Exception as exc:  # noqa: BLE001
                    errors.append(exc)
                n += 1
                time.sleep(0.01)
        t = threading.Thread(target=till)
        t.start()
        try:
            for _ in range(6):
                r = self.bridge.run(self.cfg(), post=cloud)
                self.assertTrue(r["ok"], r)
        finally:
            stop.set()
            t.join()
        self.assertFalse(errors, "the till could always save its sales")
        r = self.bridge.run(self.cfg(), post=cloud)
        self.assertTrue(r["ok"], r)
        want = aronium_day_totals(self.db)
        got = cloud.totals()
        for day, v in want.items():
            self.assertAlmostEqual(got.get(day, 0), v, places=2, msg=day)

    # ------------------------------------------------------------ the internet and the cloud
    def test_internet_down_then_back_catches_up_once(self):
        cloud = Cloud()
        cloud.mode = "down"
        r = self.run_ok(cloud)
        self.assertFalse(r["ok"])
        self.assertIn("Could not reach the cloud", r["error"])
        st = self.bridge.status()
        self.assertGreater(st["waiting"], 0)
        self.assertIn("Could not reach", st["problem"])
        cloud.mode = "ok"
        r = self.run_ok(cloud)
        self.assertTrue(r["ok"], r)
        self.assertEqual(self.bridge.status()["waiting"], 0)
        self.assertEqual(cloud.totals(), aronium_day_totals(self.db) | {})

    def test_connection_drops_half_way(self):
        clean = Cloud()
        self.bridge.run(self.cfg(), post=clean)
        os.environ["EASYBUYS_LINK_HOME"] = str(self.tmp / "home2")
        cloud = Cloud()
        cloud.fail_after = 2
        old_batch = feed.BATCH
        feed.BATCH = 2  # small pieces, so the line drops with some sent and some not
        try:
            r = self.run_ok(cloud)
            self.assertFalse(r["ok"])
            self.assertGreater(len(cloud.rows), 0)
            self.assertLess(len(cloud.rows), len(clean.rows))
            cloud.fail_after = None
            for _ in range(3):
                self.run_ok(cloud)
        finally:
            feed.BATCH = old_batch
        self.assertEqual(set(cloud.rows), set(clean.rows), "everything arrived")
        for k in clean.rows:
            self.assertEqual(json.loads(cloud.rows[k]["data"]), json.loads(clean.rows[k]["data"]), k)

    def test_cloud_trouble_is_explained(self):
        for mode, words in (("html", "cloud address"), ("garbage", "The cloud said no"), ("busy", "too many times"), ("timeout", "timed out")):
            cloud = Cloud()
            cloud.mode = mode
            r = self.run_ok(cloud)
            self.assertFalse(r["ok"], mode)
            self.assertIn(words, r["error"], mode)
        r = self.run_ok(FakeCloud(key="another"))
        self.assertIn("refused the main-software key", r["error"])

    def test_cloud_has_newer_copy(self):
        """The cloud refusing a record (it already has a newer one) must not make the PC send it for ever."""
        cloud = Cloud()
        self.run_ok(cloud)
        for k in list(cloud.u):
            cloud.u[k] = "9999"
        self.bridge.state().forget_sent()
        self.run_ok(cloud)
        self.assertEqual(self.bridge.status()["waiting"], 0)

    def test_pc_clock_put_back(self):
        cloud = Cloud()
        self.run_ok(cloud)
        st = self.bridge.state()
        st.set("last_stamp", "2030-01-01T00:00:00.000Z")
        fake_aronium.add_sale(self.db, 500, "2026-10-11 10:00:00", 1, 1, 2.5)
        self.run_ok(cloud)
        self.assertTrue(all(u >= "2030-01-01" for k, u in cloud.u.items() if "2026-10-11" in k), "always newer than before")

    # ------------------------------------------------------------ this PC
    def test_damaged_settings_file(self):
        config.save(self.cfg())
        config.path().write_text("{ this is not json")
        c = config.load()
        self.assertEqual(c["source_id"], "S1-T1")
        config.path().write_text(json.dumps({"till_number": "abc", "shop_code": "S99", "every_min": "x"}))
        c = config.load()
        self.assertEqual(c["source_id"], "S1-T1")
        self.assertTrue(config.problems(c))

    def test_damaged_memory_of_what_was_sent(self):
        cloud = Cloud()
        self.run_ok(cloud)
        sent = config.home() / "sent.db"
        sent.write_bytes(b"\x00garbage" * 500)
        r = self.run_ok(cloud)
        self.assertTrue(r["ok"], r)
        self.assertTrue(any(p.name.startswith("sent.db.damaged-") for p in config.home().iterdir()), "the damaged file is kept aside")
        self.assertEqual(cloud.totals(), aronium_day_totals(self.db))

    def test_memory_file_deleted(self):
        cloud = Cloud()
        self.run_ok(cloud)
        for p in config.home().glob("sent.db*"):
            p.unlink()
        self.assertTrue(self.run_ok(cloud)["ok"])

    def test_two_runs_at_once(self):
        with self.bridge.RunLock():
            r = self.bridge.run(self.cfg(), post=Cloud())
        self.assertFalse(r["ok"])
        self.assertIn("Already sending", r["error"])
        self.assertTrue(self.bridge.run(self.cfg(), post=Cloud())["ok"])

    def test_cannot_write_its_own_files(self):
        orig = feed.State.set

        def broken(self_, k, v):
            raise OSError(28, "No space left on device")
        feed.State.set = broken
        try:
            r = self.bridge.run(self.cfg(), post=Cloud())
        finally:
            feed.State.set = orig
        self.assertFalse(r["ok"])
        self.assertIn("No space", r["error"])
        self.assertTrue(self.bridge.run(self.cfg(), post=Cloud())["ok"])

    def test_watcher_survives_every_problem_and_stops_when_asked(self):
        config.save(self.cfg())
        cloud = Cloud()
        calls = {"n": 0}
        real_run = self.bridge.run

        def flaky(cfg, post=None, **kw):
            calls["n"] += 1
            if calls["n"] % 2:
                raise RuntimeError("something odd")
            return real_run(cfg, post=post, **kw)
        self.bridge.run = flaky
        t = [0.0]

        def sleep(_s):
            t[0] += 20 * 60
            if calls["n"] >= 4:
                self.bridge.stop_flag().write_text("stopped")
        try:
            self.assertEqual(self.bridge.watch(post=cloud, sleep=sleep, clock=lambda: t[0], max_loops=50), 0)
        finally:
            self.bridge.run = real_run
        self.assertGreaterEqual(calls["n"], 4)
        self.assertTrue(cloud.rows, "the good runs sent")

    def test_database_path_with_spaces_and_unicode(self):
        p = self.tmp / "Aronium Data – Shop 1 ā" / "pos.db"
        p.parent.mkdir()
        fake_aronium.make(p)
        self.assertTrue(self.run_ok(Cloud(), database_path=str(p))["ok"])

    # ------------------------------------------------------------ size
    def test_a_big_aronium(self):
        """A busy till after a year: 3 000 products, 120 000 receipt lines. Sent in limited pieces, in reasonable time."""
        big = self.tmp / "big.db"
        fake_aronium.make(big)
        c = sqlite3.connect(big)
        c.executemany("INSERT INTO Product (Id, ProductGroupId, Name, Code, PLU, MeasurementUnit, Price, IsTaxInclusivePrice, IsService, IsEnabled, Cost, LastPurchasePrice, DateUpdated) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      [(100 + i, 2, f"Product {i} with a fairly long name", f"P{i:05d}", 100 + i, "ea", 1 + i % 50, 1, 0, 1, 0.5 + i % 40, None, "2026-01-01") for i in range(3000)])
        docs, items, pays = [], [], []
        did = 10_000
        iid = 10_000
        start = time.mktime(time.strptime("2025-10-11", "%Y-%m-%d"))
        for day in range(365):
            ds = time.strftime("%Y-%m-%d", time.localtime(start + day * 86400))
            for r in range(30):
                did += 1
                when = f"{ds} {8 + r % 12:02d}:{r % 60:02d}:00"
                docs.append((did, f"S-{did}", 1, None, when, 0, 2, 0, 2, None, when, when))
                for k in range(11):
                    iid += 1
                    pid = 100 + (did * 7 + k * 13) % 3000
                    items.append((iid, did, pid, 1, 2.0, 0, 1.0, 2.0, 2.0))
                pays.append((did, 1, 22.0, when, 1, None, when))
        c.executemany("INSERT INTO Document VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", docs)
        c.executemany("INSERT INTO DocumentItem VALUES (?,?,?,?,?,?,?,?,?)", items)
        c.executemany("INSERT INTO Payment (DocumentId, PaymentTypeId, Amount, Date, UserId, ZReportId, DateCreated) VALUES (?,?,?,?,?,?,?)", pays)
        c.commit()
        c.close()
        cloud = Cloud()
        t0 = time.monotonic()
        rounds = 0
        while True:
            rounds += 1
            r = self.bridge.run(self.cfg(database_path=str(big)), post=cloud)
            self.assertTrue(r["ok"], r)
            if not r["waiting"] or rounds > 20:
                break
        took = time.monotonic() - t0
        self.assertEqual(r["waiting"], 0)
        for row in cloud.rows.values():
            self.assertLess(len(json.dumps(row)), 50000, "every record fits one cloud cell")
        # the next quiet run (nothing changed) is quick
        t1 = time.monotonic()
        self.assertTrue(self.bridge.run(self.cfg(database_path=str(big)), post=cloud)["ok"])
        quiet = time.monotonic() - t1
        print(f"\n  big Aronium: first send {took:.1f}s in {rounds} round(s), {len(cloud.rows)} records, {cloud.calls} uploads; quiet run {quiet:.1f}s")
        self.assertLess(took, 600)
        self.assertLess(quiet, 60)


if __name__ == "__main__":
    unittest.main()
