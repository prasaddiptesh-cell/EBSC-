"""Tests for the Easy Buys Aronium link.  Run:  python -m unittest discover -s tests -v"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import aronium_read  # noqa: E402
import config  # noqa: E402
import fake_aronium  # noqa: E402
import feed  # noqa: E402

CFG = {"source_id": "S1-T1", "shop_code": "S1", "till_name": "Shop 1 - Drasa Avenue, Till 1", "cloud_url": "https://script.google.com/macros/s/x/exec",
       "main_key": "k" * 40, "busy_every_min": 60, "resend_days": 3, "history_days": 4000}


def file_hash(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


class FakeCloud:
    """Behaves like the cloud's push_: keeps the newest per key, refuses older."""

    def __init__(self, fail: int = 0, key: str = "k" * 40):
        self.rows: dict[str, dict] = {}
        self.u: dict[str, str] = {}
        self.fail = fail
        self.calls = 0
        self.key = key

    def __call__(self, url: str, body: bytes) -> dict:
        self.calls += 1
        if self.fail:
            self.fail -= 1
            raise OSError("no internet")
        b = json.loads(body)
        if b.get("key") != self.key:
            return {"ok": False, "error": "Not allowed"}
        rejected = []
        for r in b["records"]:
            assert r["t"] == "aronium_feed"
            assert len(json.dumps(r["row"])) < 50000, "one cell holds 50 000 characters"
            if self.u.get(r["k"], "") > r["u"]:
                rejected.append({"t": r["t"], "k": r["k"], "why": "newer change already in the cloud"})
                continue
            self.rows[r["k"]] = r["row"]
            self.u[r["k"]] = r["u"]
        return {"ok": True, "accepted": len(b["records"]) - len(rejected), "rejected": rejected}

    def data(self, uid: str):
        return json.loads(self.rows[uid]["data"])


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp())
        self.db = fake_aronium.make(self.tmp / "pos.db")

    def read(self, **kw):
        return aronium_read.read_all(self.db, **kw)


class ReaderTests(Base):
    def test_never_changes_aronium(self):
        before = file_hash(self.db)
        stamp = os.stat(self.db).st_mtime_ns
        self.read(work_dir=self.tmp / "work")
        self.read()
        self.assertEqual(file_hash(self.db), before)
        self.assertEqual(os.stat(self.db).st_mtime_ns, stamp)
        self.assertFalse(Path(str(self.db) + "-journal").exists())

    def test_writing_is_impossible(self):
        conn = aronium_read.open_read_only(self.db)
        with self.assertRaises(sqlite3.OperationalError):
            conn.execute("UPDATE Product SET Price = 0")
        a = aronium_read.Aronium(conn)
        with self.assertRaises(RuntimeError):
            a.rows("DELETE FROM Product")
        conn.close()

    def test_products(self):
        p = {x["name"]: x for x in self.read()["products"]}
        self.assertEqual(p["Coke 1.5L"]["vat_rate"], 12.5)
        self.assertIsNone(p["Bread Loaf"]["vat_rate"])  # no tax = zero rated
        self.assertEqual(p["Coke 1.5L"]["code"], "3")   # no code: the PLU
        self.assertEqual(p["Coke 1.5L"]["barcodes"], ["5449000000996", "5449000000997"])
        self.assertEqual(p["Coke 1.5L"]["cost"], 2.1)   # no cost: last purchase price
        self.assertEqual(p["Coke 1.5L"]["stock"], 36)   # two warehouses added up
        self.assertEqual(p["Rice 10kg"]["reorder_point"], 5)
        self.assertEqual(p["Rice 10kg"]["group"], "Grocery")

    def test_sales_day(self):
        d = {x["date"]: x for x in self.read()["sales_days"]}
        lines = {x["name"]: x for x in d["2026-10-09"]["lines"]}
        self.assertEqual(lines["Coke 1.5L"]["sold"], 2)
        self.assertEqual(lines["Coke 1.5L"]["sold_value"], 4.95)
        self.assertEqual(lines["Coke 1.5L"]["refunded"], 1)
        self.assertEqual(lines["Coke 1.5L"]["net"], 1)
        self.assertEqual(lines["Bread Loaf"]["sold_value"], 5.0)
        self.assertIn("2026-10-10", d)

    def test_day_activity(self):
        a = {x["date"]: x for x in self.read()["activity"]}["2026-10-09"]
        self.assertEqual(a["hours"]["09"], {"value": 9.95, "receipts": 1})
        self.assertEqual(a["hours"]["11"]["value"], -3.95)  # a refund takes away
        asha = a["cashiers"]["Asha K"]
        self.assertEqual((asha["receipts"], asha["refunds"], asha["refund_value"]), (1, 1, 3.95))
        self.assertEqual((asha["discounts"], asha["discount_value"]), (1, 2.95))
        self.assertEqual(a["cashiers"]["Ben"]["sales"], 25.0)
        self.assertEqual(sum(c["voids"] for c in a["cashiers"].values()), 1)

    def test_end_of_day(self):
        z = self.read()["z"]
        self.assertEqual(len(z), 1)  # the open shift (no Z yet) is not sent
        z = z[0]
        self.assertEqual(z["number"], "101")
        self.assertEqual(z["date"], "2026-10-09")
        self.assertEqual(z["sales"], 34.95)
        self.assertEqual(z["refunds"], 3.95)
        self.assertEqual(z["total"], 31.0)
        self.assertEqual(z["vat"], 0.11)
        self.assertEqual(z["zero"], 30.0)
        self.assertEqual(z["discounts"], 2.95)
        self.assertEqual(z["payments"], {"Cash": 6.0, "M-PAiSA": 25.0})
        self.assertEqual(z["cash"], 6.0)
        self.assertEqual(z["other"], 25.0)
        self.assertEqual(z["cashiers"], {"Asha K": 6.0, "Ben": 25.0})
        self.assertEqual(z["voids"], {"count": 1, "total": 3.95})
        self.assertEqual(z["float"], {"opening": 100.0, "cash_out": 20.0})

    def test_credit_purchases_parties(self):
        r = self.read()
        self.assertEqual([(c["name"], c["owing"]) for c in r["credit"]], [("Ravi (staff)", 5.0)])
        self.assertEqual(r["purchases"][0]["supplier"], "Fiji Rice Ltd")
        self.assertEqual(r["purchases"][0]["reference"], "INV-77")
        s = {p["name"]: p for p in r["parties"]}
        self.assertTrue(s["Fiji Rice Ltd"]["supplier"])
        self.assertEqual(s["Fiji Rice Ltd"]["tin"], "50-12345-0-1")

    def test_older_aronium_without_some_tables(self):
        c = sqlite3.connect(self.db)
        c.executescript("DROP TABLE ZReport; DROP TABLE StockControl; DROP TABLE PosVoid; DROP TABLE StartingCash; ALTER TABLE Payment DROP COLUMN ZReportId;")
        c.commit()
        c.close()
        r = self.read()
        self.assertEqual(len(r["products"]), 3)
        self.assertTrue(any(z["key"] == "d2026-10-09" for z in r["z"]))  # each day is one End of day
        self.assertTrue(r["meta"]["notes"])

    def test_not_an_aronium_file(self):
        other = self.tmp / "other.db"
        sqlite3.connect(other).execute("CREATE TABLE x(a)").connection.close()
        with self.assertRaises(RuntimeError):
            aronium_read.read_all(other)
        with self.assertRaises(FileNotFoundError):
            aronium_read.read_all(self.tmp / "missing.db")

    def test_oldest_and_since(self):
        r = self.read(oldest="2026-10-10")
        self.assertEqual([d["date"] for d in r["sales_days"]], ["2026-10-10"])
        self.assertEqual(r["z"], [])
        r = self.read(since="2026-10-10 08:00:00")
        self.assertEqual([d["date"] for d in r["sales_days"]], ["2026-10-10"])


class FeedTests(Base):
    def state(self):
        return feed.State(self.tmp / "sent.db")

    def run_link(self, cloud, st=None, today="2026-10-11"):
        return feed.run_once({**CFG, "database_path": str(self.db)}, st or self.state(), read=lambda p, **kw: aronium_read.read_all(self.db, **kw), post=cloud, log=lambda m: None, today=today)

    def test_first_send_and_nothing_twice(self):
        cloud = FakeCloud()
        res = self.run_link(cloud)
        self.assertIsNone(res["error"])
        self.assertIn("S1-T1|z|z1|0", cloud.rows)
        self.assertIn("S1-T1|products|all|0", cloud.rows)
        self.assertEqual(cloud.rows["S1-T1|z|z1|0"]["shop_code"], "S1")
        sales = cloud.data("S1-T1|sales_day|2026-10-09|0")
        self.assertEqual(sales["cols"], feed.SALES_COLS)
        self.assertEqual(res["waiting"], 0)
        calls = cloud.calls
        res = self.run_link(cloud)
        self.assertEqual(res["queued"], 0)
        self.assertEqual(cloud.calls, calls)

    def test_new_sale_sends_only_that_day(self):
        cloud = FakeCloud()
        st = self.state()
        self.run_link(cloud, st)
        fake_aronium.add_sale(self.db, 50, "2026-10-09 20:00:00", 1, 3, 2.5)
        res = self.run_link(cloud, st)
        kinds = {r["row"]["kind"] for r in res["sent"]}
        self.assertIn("sales_day", kinds)
        bread = [x for x in cloud.data("S1-T1|sales_day|2026-10-09|0")["rows"] if x[1] == "Bread Loaf"][0]
        self.assertEqual(bread[2], 5)  # 2 + 3

    def test_today_is_sent_at_most_hourly(self):
        cloud = FakeCloud()
        st = self.state()
        self.run_link(cloud, st, today="2026-10-10")
        fake_aronium.add_sale(self.db, 51, "2026-10-10 12:00:00", 1, 1, 2.5)
        res = self.run_link(cloud, st, today="2026-10-10")
        self.assertNotIn("sales_day", {r["row"]["kind"] for r in res["sent"]})
        # an hour later it goes
        with sqlite3.connect(st.path) as c:
            c.execute("UPDATE sent SET at = ?", ((datetime.now(timezone.utc) - timedelta(minutes=61)).strftime("%Y-%m-%dT%H:%M:%S.000Z"),))
        res = self.run_link(cloud, st, today="2026-10-10")
        self.assertIn("sales_day", {r["row"]["kind"] for r in res["sent"]})

    def test_no_internet_keeps_everything(self):
        st = self.state()
        res = self.run_link(FakeCloud(fail=1), st)
        self.assertTrue(res["error"])
        self.assertGreater(res["waiting"], 0)
        self.assertIsNone(st.get("last_doc_update"))
        cloud = FakeCloud()
        res = self.run_link(cloud, st)
        self.assertIsNone(res["error"])
        self.assertEqual(res["waiting"], 0)
        self.assertIn("S1-T1|z|z1|0", cloud.rows)

    def test_wrong_key(self):
        st = self.state()
        res = self.run_link(FakeCloud(key="other"), st)
        self.assertIn("main-software key", res["error"])
        self.assertGreater(res["waiting"], 0)

    def test_big_lists_are_cut_into_parts(self):
        items = [{"code": str(i), "name": "Product name that is quite long " * 3, "barcodes": ["123456789012"]} for i in range(3000)]
        parts = feed.split(items)
        self.assertGreater(len(parts), 3)
        for p in parts:
            self.assertLess(feed.stored_size(p), feed.MAX_CHARS)
        self.assertEqual(sum(len(p) for p in parts), 3000)

    def test_shorter_list_empties_old_parts(self):
        st = self.state()
        big = {"products": [{"code": str(i), "name": "x" * 300} for i in range(400)]}
        recs = feed.make_records(big, CFG, st, today="2026-10-11")
        n = len([r for r in recs if r["row"]["kind"] == "products"])
        self.assertGreater(n, 1)
        st.done(recs)
        recs = feed.make_records({"products": [{"code": "1", "name": "y"}]}, CFG, st, today="2026-10-11")
        prods = sorted((r["row"]["part"], r["row"]["data"]) for r in recs if r["row"]["kind"] == "products")
        self.assertEqual(len(prods), n)
        self.assertTrue(all(d == "[]" for _, d in prods[1:]))

    def test_clock_put_back_still_newest(self):
        st = self.state()
        st.set("last_stamp", "2099-01-01T00:00:00.000Z")
        self.assertGreater(st.stamp(), "2099-01-01T00:00:00.000Z")

    def test_refused_records_do_not_loop(self):
        st = self.state()
        cloud = FakeCloud()
        for k in ("S1-T1|meta|all|0",):
            cloud.u[k] = "2999-01-01T00:00:00.000Z"
        res = self.run_link(cloud, st)
        self.assertEqual(res["waiting"], 0)


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.environ["EASYBUYS_LINK_HOME"] = self.tmp

    def tearDown(self):
        os.environ.pop("EASYBUYS_LINK_HOME", None)

    def test_save_load(self):
        cfg = config.load()
        self.assertEqual(cfg["source_id"], "S1-T1")
        cfg.update({"shop_code": "S2", "till_number": 1, "main_key": "secret-key-" * 3, "cloud_url": "https://script.google.com/macros/s/a/exec"})
        config.save(cfg)
        raw = Path(config.path()).read_text()
        self.assertNotIn('"main_key"', raw)
        again = config.load()
        self.assertEqual(again["source_id"], "S2-T1")
        self.assertEqual(again["main_key"], "secret-key-" * 3)
        self.assertIn("Tukani", again["till_name"])

    def test_problems(self):
        msgs = " ".join(config.problems(config.load()))
        self.assertIn("pos.db", msgs)
        self.assertIn("main-software key", msgs)

    def test_damaged_settings(self):
        Path(config.path()).write_text("{not json")
        self.assertEqual(config.load()["shop_code"], "S1")


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        os.environ["EASYBUYS_LINK_HOME"] = str(self.tmp / "home")
        self.db = fake_aronium.make(self.tmp / "pos.db")

    def tearDown(self):
        os.environ.pop("EASYBUYS_LINK_HOME", None)

    def test_run_and_check(self):
        import bridge
        cfg = config.load()
        cfg.update({"database_path": str(self.db), "cloud_url": "https://script.google.com/macros/s/a/exec", "main_key": "k" * 40})
        cloud = FakeCloud()
        res = bridge.run(cfg, post=cloud)
        self.assertTrue(res["ok"], res)
        self.assertTrue(any(k.startswith("S1-T1|z|") for k in cloud.rows))
        chk = bridge.check(cfg)
        self.assertTrue(chk["ok"], chk)
        self.assertTrue(any("3 products" in x for x in chk["lines"]))

    def test_watch_sends_after_a_change_and_every_15_minutes(self):
        import bridge
        cfg = config.load()
        cfg.update({"database_path": str(self.db), "every_min": 15, "watch_gap_min": 2})
        w: dict = {}
        self.assertEqual(bridge.watch_step(w, 1000.0, cfg), "periodic")  # straight away the first time
        w["last_run"] = 1000.0
        self.assertIsNone(bridge.watch_step(w, 1020.0, cfg))
        fake_aronium.add_sale(self.db, 50, "2026-10-11 09:00:00", 1, 1, 2.5)
        os.utime(self.db, (2000, 2000))
        self.assertIsNone(bridge.watch_step(w, 1040.0, cfg), "just changed: waits for a quiet moment")
        self.assertIsNone(bridge.watch_step(w, 1080.0, cfg), "quiet 40 s but within 2 minutes of the last send")
        self.assertEqual(bridge.watch_step(w, 1130.0, cfg), "change")
        w.update(last_run=1130.0, changed_at=0)
        self.assertIsNone(bridge.watch_step(w, 1500.0, cfg))
        self.assertEqual(bridge.watch_step(w, 1130.0 + 15 * 60, cfg), "periodic")

    def test_watch_runs_and_stops_when_switched_off(self):
        import bridge
        cfg = config.load()
        cfg.update({"database_path": str(self.db), "cloud_url": "https://script.google.com/macros/s/a/exec", "main_key": "k" * 40})
        config.save(cfg)
        cloud = FakeCloud()
        t = [5000.0]
        def sleep(_s):
            t[0] += 20
            if len(cloud.rows):
                bridge.stop_flag().write_text("stopped")
        self.assertEqual(bridge.watch(post=cloud, sleep=sleep, clock=lambda: t[0], max_loops=10), 0)
        self.assertTrue(any(k.startswith("S1-T1|activity|") for k in cloud.rows))
        n = cloud.calls
        self.assertEqual(bridge.watch(post=cloud, sleep=sleep, clock=lambda: t[0], max_loops=3), 0)
        self.assertEqual(cloud.calls, n, "switched off: sends nothing")

    def test_task_xml(self):
        import bridge
        x = bridge.task_xml(15)
        self.assertIn("<Interval>PT15M</Interval>", x)
        self.assertIn("<MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>", x)
        self.assertIn("--watch", x)

    def test_run_never_raises(self):
        import bridge
        cfg = config.load()
        cfg.update({"database_path": str(self.tmp / "nope.db"), "cloud_url": "https://script.google.com/x", "main_key": "k" * 40})
        self.assertFalse(bridge.run(cfg)["ok"])
        cfg["database_path"] = str(self.db)
        res = bridge.run(cfg, post=lambda u, b: (_ for _ in ()).throw(ValueError("boom")))
        self.assertFalse(res["ok"])


if __name__ == "__main__":
    unittest.main()
