"""1.0.0 live sales: receipts with their lines, sent in small blocks within about 30 seconds of a sale, kept 90 days.
Aronium is still only read. Run:  python -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import aronium_read  # noqa: E402
import fake_aronium  # noqa: E402
import feed  # noqa: E402
from test_link import CFG, FakeCloud, file_hash  # noqa: E402


def rows_of(cloud: FakeCloud, prefix: str) -> list[dict]:
    """Every receipt in the cloud for one till and day, all parts joined (as the app does)."""
    out = []
    keys = sorted((k for k in cloud.rows if k.startswith(prefix)), key=lambda k: int(k.rsplit("|", 1)[1]))
    for k in keys:
        d = json.loads(cloud.rows[k]["data"])
        out.extend(dict(zip(d["cols"], r)) for r in d["rows"])
    return out


class LiveTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp())
        self.db = fake_aronium.make(self.tmp / "pos.db")
        self.st = feed.State(self.tmp / "sent.db")
        self.cfg = {**CFG, "database_path": str(self.db)}

    def full(self, cloud, today="2026-10-11"):
        return feed.run_once(self.cfg, self.st, read=lambda p, **kw: aronium_read.read_all(self.db, **kw), post=cloud, log=lambda m: None, today=today)

    def live(self, cloud, today="2026-10-11"):
        return feed.run_live(self.cfg, self.st, read_live=aronium_read.read_live, post=cloud, log=lambda m: None, today=today)

    # ------------------------------------------------------------ what each receipt says
    def test_receipt_lines_product_qty_price_discount_and_refunds(self):
        r = {x["no"]: x for x in aronium_read.read_all(self.db)["receipts"][0]["rows"]}
        self.assertEqual(r["S-1"]["items"], [["1001", 2.0, 2.5, 0.0, 5.0], ["3", 1.0, 3.95, 0.0, 3.95], ["3", 1.0, 3.95, 2.95, 1.0]], "the discounted coke shows its discount")
        self.assertEqual(r["S-1"]["z"], 1, "which End of day (shift) it went into")
        self.assertEqual(r["R-1"]["refund"], 1)
        self.assertEqual(r["R-1"]["items"], [["3", 1.0, 3.95, 0.0, 3.95]], "a refund's lines: positive quantities, the receipt says refund")
        self.assertEqual(sum(i[4] for i in r["S-1"]["items"]), r["S-1"]["total"], "the lines add up to the receipt")

    def test_odd_lines_never_break_the_send(self):
        c = sqlite3.connect(self.db)
        c.execute("INSERT INTO Document VALUES (60,'S-60',1,NULL,'2026-10-11 09:00:00',0,2,0,2,NULL,'2026-10-11 09:00:00','2026-10-11 09:00:00')")
        c.executemany("INSERT INTO DocumentItem (DocumentId, ProductId, Quantity, Price, Total, TotalAfterDocumentDiscount) VALUES (?,?,?,?,?,?)",
                      [(60, None, None, None, None, None), (60, 999, "abc", "x", "y", "z")] + [(60, 1, 1, 2.5, 2.5, 2.5)] * 250)
        c.commit(); c.close()
        r = {x["no"]: x for x in aronium_read.read_live(self.db, day="2026-10-11")["receipts"][0]["rows"]}
        self.assertEqual(len(r["S-60"]["items"]), aronium_read.MAX_RECEIPT_LINES, "a runaway receipt is cut")
        self.assertEqual(r["S-60"]["items"][0], ["0", 0.0, 0.0, 0.0, 0.0])
        self.assertIsNone(self.live(FakeCloud())["error"])

    def test_older_aronium_without_prices_or_z_link(self):
        c = sqlite3.connect(self.db)
        c.executescript("""CREATE TABLE P2 AS SELECT Id, DocumentId, PaymentTypeId, Amount, Date, UserId, DateCreated FROM Payment; DROP TABLE Payment; ALTER TABLE P2 RENAME TO Payment;
          CREATE TABLE D2 AS SELECT Id, DocumentId, ProductId, Quantity, ProductCost, Total FROM DocumentItem; DROP TABLE DocumentItem; ALTER TABLE D2 RENAME TO DocumentItem;""")
        c.commit(); c.close()
        r = {x["no"]: x for x in aronium_read.read_all(self.db)["receipts"][0]["rows"]}
        self.assertIsNone(r["S-1"]["z"], "no End of day link in this Aronium")
        self.assertEqual(r["S-1"]["items"][0], ["1001", 2.0, 0.0, 0.0, 5.0], "no price column: the line total still comes")
    # ------------------------------------------------------------ small sends, often
    def test_a_new_sale_only_changes_the_last_small_block(self):
        for i in range(45):  # a busy morning: 45 receipts
            fake_aronium.add_sale(self.db, 100 + i, f"2026-10-11 08:{i:02d}:00", 1, 1, 2.5)
        cloud = FakeCloud()
        self.assertIsNone(self.full(cloud)["error"])
        parts = sorted(k for k in cloud.rows if k.startswith("S1-T1|receipts|2026-10-11|"))
        self.assertEqual(len(parts), 3, "blocks of 20 receipts")
        before = {k: dict(cloud.rows[k]) for k in parts}
        fake_aronium.add_sale(self.db, 200, "2026-10-11 09:10:00", 3, 2, 3.95)
        cloud.calls = 0
        res = self.live(cloud)
        self.assertIsNone(res["error"])
        changed = sorted(r["k"] for r in res["sent"])
        self.assertIn("S1-T1|receipts|2026-10-11|2", changed)
        self.assertNotIn("S1-T1|receipts|2026-10-11|0", changed, "older blocks are not sent again")
        self.assertNotIn("S1-T1|receipts|2026-10-11|1", changed)
        self.assertTrue(all(k.split("|")[1] in ("receipts", "activity", "z", "z_items", "drawer") for k in changed), changed)
        self.assertEqual(cloud.calls, 1, "one upload")
        self.assertLess(sum(len(json.dumps(r["row"])) for r in res["sent"]), 12000, "a few kilobytes")
        self.assertEqual(before["S1-T1|receipts|2026-10-11|0"]["hash"], cloud.rows["S1-T1|receipts|2026-10-11|0"]["hash"])
        allr = rows_of(cloud, "S1-T1|receipts|2026-10-11|")
        self.assertEqual(len(allr), 46)
        self.assertEqual(allr[-1]["items"], [["3", 2.0, 3.95, 0.0, 7.9]])
        self.assertEqual(self.live(cloud)["queued"], 0, "nothing new: nothing sent")

    def test_live_never_sends_lists_it_did_not_read(self):
        cloud = FakeCloud()
        self.full(cloud)
        prods = cloud.rows["S1-T1|products|all|0"]["hash"]
        fake_aronium.add_sale(self.db, 300, "2026-10-11 10:00:00", 1, 1, 2.5)
        res = self.live(cloud)
        kinds = {r["k"].split("|")[1] for r in res["sent"]}
        self.assertFalse(kinds & {"products", "stock", "parties", "users", "credit", "credit_trail", "purchases", "meta", "sales_day"}, kinds)
        self.assertEqual(cloud.rows["S1-T1|products|all|0"]["hash"], prods, "the product list is never emptied by a live send")

    def test_live_reads_aronium_without_changing_or_copying_it(self):
        before = file_hash(self.db)
        stamp = os.stat(self.db).st_mtime_ns
        fake_aronium.add_sale  # noqa: B018
        self.live(FakeCloud())
        self.assertEqual(file_hash(self.db), before)
        self.assertEqual(os.stat(self.db).st_mtime_ns, stamp)
        self.assertFalse((self.tmp / "work").exists(), "no copy of the database for a live send")
        conn = aronium_read.open_read_only(self.db)
        with self.assertRaises(sqlite3.OperationalError):
            conn.execute("DELETE FROM Document")
        conn.close()

    def test_live_with_no_internet_keeps_it_and_sends_once_back(self):
        fake_aronium.add_sale(self.db, 310, "2026-10-11 10:00:00", 1, 1, 2.5)
        down = FakeCloud(fail=1)
        res = self.live(down)
        self.assertTrue(res["error"])
        self.assertGreater(self.st.waiting_count(), 0)
        res = self.live(down)
        self.assertIsNone(res["error"])
        self.assertEqual(self.st.waiting_count(), 0)
        self.assertEqual(len(rows_of(down, "S1-T1|receipts|2026-10-11|")), 1)

    def test_drawer_goes_on_its_own(self):
        c = sqlite3.connect(self.db); c.execute("INSERT INTO StartingCash VALUES (9, 1, 150.0, 0, NULL)"); c.commit(); c.close()
        cloud = FakeCloud()
        self.live(cloud)
        self.assertEqual(json.loads(cloud.rows["S1-T1|drawer|now|0"]["data"])["drawer"], {"opening": 150.0})

    # ------------------------------------------------------------ 3 years without filling up
    def test_receipts_older_than_90_days_are_not_sent_and_emptied_in_the_cloud(self):
        cloud = FakeCloud()
        self.full(cloud, today="2026-10-11")
        self.assertIn("S1-T1|receipts|2026-10-09|0", cloud.rows)
        self.assertTrue(rows_of(cloud, "S1-T1|receipts|2026-10-09|"))
        res = self.full(cloud, today="2027-01-20")  # 103 days later
        self.assertIsNone(res["error"])
        d = json.loads(cloud.rows["S1-T1|receipts|2026-10-09|0"]["data"])
        self.assertEqual((d["rows"], d.get("pruned")), ([], 1), "emptied in the cloud (the day totals stay in sales_day)")
        self.assertTrue(json.loads(cloud.rows["S1-T1|sales_day|2026-10-09|0"]["data"])["rows"], "daily product totals kept for good")
        calls = cloud.calls
        self.full(cloud, today="2027-01-21")
        self.assertEqual(cloud.calls, calls, "emptied once only")
        # the first send to a new cloud: receipts only for the last 90 days
        st2 = feed.State(self.tmp / "sent2.db")
        c2 = FakeCloud()
        feed.run_once(self.cfg, st2, read=lambda p, **kw: aronium_read.read_all(self.db, **kw), post=c2, log=lambda m: None, today="2027-01-20")
        self.assertFalse([k for k in c2.rows if "|receipts|" in k])
        self.assertTrue([k for k in c2.rows if "|sales_day|" in k])


if __name__ == "__main__":
    unittest.main()
