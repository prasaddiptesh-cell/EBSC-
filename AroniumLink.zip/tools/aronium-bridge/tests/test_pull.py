"""1.0.0 build 5 "Get the End of day now": the Link asks the cloud every ~30 s (a tiny link_check) whether someone asked
this shop's till PCs to send now; if so it does a full send straight away (End of days / Z, receipts, drawer) and says
it answered. Aronium is still only read. Run:  python -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import bridge  # noqa: E402
import config  # noqa: E402
import fake_aronium  # noqa: E402
from test_tamper import Base, TillKeyCloud  # noqa: E402


class PullCloud(TillKeyCloud):
    """A till-key cloud that answers pull: true while a request is open (until a full send or the 'pulled' answer)."""

    def __init__(self, pull=False):
        super().__init__()
        self.pull = pull
        self.checks = 0
        self.offline = False

    def __call__(self, url, body):
        if self.offline:
            raise OSError("no internet")
        b = json.loads(body)
        if b.get("kind") == "link_check" and b.get("pull_only"):
            self.bodies.append(b)
            self.checks += 1
            if b.get("pulled"):
                self.pull = False
            return {"ok": True, "version": 14, "pull": self.pull}
        res = super().__call__(url, body)
        if b.get("kind") == "link_push" and b.get("full") and isinstance(res, dict) and res.get("ok"):
            self.pull = False
        return res

    def pushes(self):
        return [b for b in self.bodies if b.get("kind") == "link_push"]


class PullTests(Base):
    def test_pull_reply_means_a_full_send_now(self):
        cfg = self.cfg()
        cloud = PullCloud()
        self.assertTrue(bridge.run(cfg, post=cloud)["ok"])  # the first send (everything)
        fake_aronium.add_sale(self.db, 77, "2026-10-11 10:00:00", 1, 1, 2.5)
        n = len(cloud.pushes())
        cloud.pull = True
        w: dict = {}
        self.assertTrue(bridge.pull_check(w, 1000.0, cfg, post=cloud), "asked: send now")
        res = bridge.answer_pull(cfg, post=cloud)
        self.assertTrue(res["ok"], res)
        sent = cloud.pushes()[n:]
        self.assertTrue(sent and all(b.get("full") is True for b in sent), "a full send, marked full")
        kinds = {r["row"]["kind"] for b in sent for r in b["records"]}
        self.assertTrue(kinds & {"sales_day", "receipts", "drawer", "z"}, kinds)
        self.assertFalse(cloud.pull, "answered")
        self.assertTrue(cloud.bodies[-1].get("pulled"), "and the cloud is told it was answered")

    def test_no_pull_nothing_extra_and_only_every_30_seconds(self):
        cfg = self.cfg()
        cloud = PullCloud()
        w: dict = {}
        self.assertFalse(bridge.pull_check(w, 1000.0, cfg, post=cloud))
        self.assertEqual(cloud.pushes(), [], "nothing asked: nothing sent")
        self.assertFalse(bridge.pull_check(w, 1010.0, cfg, post=cloud))
        self.assertEqual(cloud.checks, 1, "asks at most every 30 s")
        self.assertFalse(bridge.pull_check(w, 1031.0, cfg, post=cloud))
        self.assertEqual(cloud.checks, 2)
        self.assertFalse(bridge.pull_check({}, 1000.0, self.cfg(till_key="", main_key="m" * 40), post=cloud), "an old Link (no till key) never asks")
        self.assertEqual(cloud.checks, 2)

    def test_offline_never_crashes(self):
        cfg = self.cfg()
        cloud = PullCloud(pull=True)
        cloud.offline = True
        self.assertFalse(bridge.pull_check({}, 1000.0, cfg, post=cloud))
        self.assertFalse(bridge.pull_check({}, 1000.0, cfg, post=lambda u, b: {"ok": False, "error": "busy"}))
        self.assertFalse(bridge.pull_check({}, 1000.0, cfg, post=lambda u, b: "not json"))
        res = bridge.answer_pull(cfg, post=cloud)
        self.assertFalse(res["ok"])

    def test_the_watcher_answers_a_pull_within_a_round(self):
        cfg = self.cfg()
        config.save(cfg)
        cloud = PullCloud()
        t = [5000.0]
        loops = {"n": 0}

        def sleep(_s):
            t[0] += 5
            loops["n"] += 1
            if loops["n"] == 3:
                cloud.pull = True  # the manager pressed "Get the End of day now"
        self.assertEqual(bridge.watch(post=cloud, sleep=sleep, clock=lambda: t[0], max_loops=12), 0)
        self.assertFalse(cloud.pull, "the watcher answered it")
        full = [b for b in cloud.pushes() if b.get("full")]
        self.assertGreaterEqual(len(full), 2, "the first send, then the pulled one")
        self.assertTrue(any(b.get("pulled") for b in cloud.bodies))
        self.assertTrue(os.path.exists(self.db), "Aronium untouched")


if __name__ == "__main__":
    unittest.main()
