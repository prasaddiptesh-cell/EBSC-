"""1.0.0 security audit C3 / H7 on the Link: a key per till (never the main key), and nothing can be switched off,
pointed at another database or re-keyed quietly - each is told to the Easy Buys app. Aronium is still only read."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import bridge  # noqa: E402
import config  # noqa: E402
import fake_aronium  # noqa: E402
import feed  # noqa: E402
from test_link import FakeCloud  # noqa: E402

URL = "https://script.google.com/macros/s/a/exec"
TILL_KEY = "tk-S1-T1-" + "x" * 30


class TillKeyCloud(FakeCloud):
    """The cloud as stream F builds it: a till key may only send its own till's aronium_feed and do the link check."""

    def __init__(self, keys=None):
        super().__init__()
        self.keys = keys or {TILL_KEY: "S1-T1"}
        self.bodies = []

    def __call__(self, url, body):
        b = json.loads(body)
        self.bodies.append(b)
        if b.get("kind") in ("link_push", "link_check"):
            if self.keys.get(b.get("till_key")) != b.get("source"):
                return {"ok": False, "error": "Not allowed"}
            if b["kind"] == "link_check":
                return {"ok": True, "version": 12}
            for r in b["records"]:
                assert r["row"]["source"] == b["source"] and r["k"].startswith(b["source"] + "|"), "only its own till"
            b = {**b, "kind": "main_push", "key": self.key}
            return super().__call__(url, json.dumps(b).encode())
        if b.get("kind") == "main_push":
            return {"ok": False, "error": "Not allowed"}  # after the cut-over the main key is refused
        return super().__call__(url, body)

    def events(self):
        return [json.loads(r["data"]) for k, r in self.rows.items() if r["kind"] == "link_event"]


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        os.environ["EASYBUYS_LINK_HOME"] = str(self.tmp / "home")
        self.db = fake_aronium.make(self.tmp / "pos.db")

    def tearDown(self):
        os.environ.pop("EASYBUYS_LINK_HOME", None)

    def cfg(self, **kw):
        c = config.load()
        c.update({"database_path": str(self.db), "cloud_url": URL, "till_key": TILL_KEY, "main_key": "", "busy_every_min": 0, "sales_every_min": 0})
        c.update(kw)
        c["source_id"] = config.source_id(c)
        return c


class TillKeyTests(Base):
    def test_the_request_format(self):
        cfg = self.cfg()
        self.assertEqual(feed.request("link_check", cfg), {"kind": "link_check", "source": "S1-T1", "till_key": TILL_KEY})
        b = feed.request("link_push", cfg, records=[1])
        self.assertEqual(b, {"kind": "link_push", "source": "S1-T1", "till_key": TILL_KEY, "records": [1]})
        self.assertNotIn("key", b, "the main key is never sent with a till key")
        old = feed.request("link_push", self.cfg(till_key="", main_key="m" * 40), records=[])
        self.assertEqual(old["kind"], "main_push", "a Link set up before 1.0.0 still works until the cut-over")

    def test_sends_with_its_own_key_and_never_another_tills_records(self):
        cloud = TillKeyCloud()
        r = bridge.run(self.cfg(), post=cloud)
        self.assertTrue(r["ok"], r)
        self.assertTrue(all(b["kind"] == "link_push" and "key" not in b for b in cloud.bodies))
        self.assertIn("S1-T1|products|all|0", cloud.rows)
        other = {"t": "aronium_feed", "k": "S2-T1|z|z1|0", "u": "x", "row": {"source": "S2-T1"}}
        res = feed.push([other], self.cfg(), post=cloud)
        self.assertIn("another till", res["error"])
        self.assertTrue(bridge.link_check(self.cfg(), post=cloud)["ok"])

    def test_a_wrong_key_is_explained(self):
        r = bridge.run(self.cfg(till_key="tk-wrong-" + "y" * 30), post=TillKeyCloud())
        self.assertFalse(r["ok"])
        self.assertIn("refused this till's key", r["error"])

    def test_the_till_key_is_kept_locked_not_as_typed(self):
        config.save(self.cfg())
        raw = config.path().read_text()
        self.assertNotIn('"till_key"', raw, "kept only as till_key_locked")
        if sys.platform == "win32":  # locked to this Windows user (DPAPI); elsewhere (these tests) it is marked plain
            self.assertNotIn(TILL_KEY, raw)
        self.assertEqual(config.load()["till_key"], TILL_KEY)
        self.assertEqual([m for m in config.problems(config.load()) if "key" in m], [], "a till key alone is enough")


class TamperTests(Base):
    def test_database_changed_is_told_before_anything_is_sent_from_it(self):
        cloud = TillKeyCloud()
        self.assertTrue(bridge.run(self.cfg(), post=cloud)["ok"])
        self.assertEqual(cloud.events(), [], "the first run only remembers the settings")
        doctored = fake_aronium.make(self.tmp / "copy.db")
        n = len(cloud.bodies)
        bridge.run(self.cfg(database_path=str(doctored)), post=cloud)
        ev = cloud.events()
        self.assertEqual([e["event"] for e in ev], ["database_changed"])
        self.assertEqual(ev[0]["detail"]["old"], str(self.db))
        self.assertEqual(ev[0]["detail"]["new"], str(doctored))
        first = cloud.bodies[n]
        self.assertEqual([r["row"]["kind"] for r in first["records"]], ["link_event"], "told first, before any figures from it")

    def test_settings_edited_by_hand_are_told_without_the_keys(self):
        cloud = TillKeyCloud({TILL_KEY: "S1-T1", "tk-new-" + "z" * 30: "S1-T1"})
        bridge.run(self.cfg(), post=cloud)
        bridge.run(self.cfg(till_key="tk-new-" + "z" * 30, pin_hash=""), post=cloud)
        ev = [e for e in cloud.events() if e["event"] == "settings_changed"]
        self.assertEqual(len(ev), 1)
        self.assertIn("till_key", ev[0]["detail"]["changed"])
        self.assertNotIn("tk-new", json.dumps(cloud.rows), "never the key itself")

    def test_stop_file_made_by_hand_is_told_once(self):
        cfg = self.cfg()
        config.save(cfg)
        cloud = TillKeyCloud()
        bridge.stop_flag().write_text("anything")
        for _ in range(3):
            self.assertEqual(bridge.watch(post=cloud, sleep=lambda s: None, clock=lambda: 1000.0, max_loops=2), 0)
        self.assertEqual([e["event"] for e in cloud.events()], ["stop_file"])
        self.assertEqual(len(cloud.rows), 1, "and nothing else was sent")

    def test_task_deleted_or_disabled_is_told_and_put_back(self):
        cloud = TillKeyCloud()
        cfg = self.cfg()
        real = bridge.task_state
        states = iter(["ok", "missing", "missing", "ok", "disabled"])
        bridge.task_state = lambda: next(states)
        try:
            w: dict = {}
            got = [bridge.task_watch(w, cfg, post=cloud) for _ in range(5)]
        finally:
            bridge.task_state = real
        self.assertEqual(got, ["ok", "missing", "missing", "ok", "disabled"])
        self.assertEqual([e["event"] for e in sorted(cloud.events(), key=lambda e: e["at"])], ["task_missing", "task_back", "task_missing"])
        self.assertEqual(cloud.events()[0]["detail"]["task"] in ("missing", "disabled"), True)

    def test_an_event_with_the_internet_down_waits_and_goes_with_the_next_send(self):
        cfg = self.cfg()
        down = TillKeyCloud()

        def broken(url, body):
            raise OSError("no internet")
        self.assertFalse(bridge.notice("stopped", cfg, post=broken))
        self.assertTrue(bridge.run(cfg, post=down)["ok"])
        self.assertEqual([e["event"] for e in down.events()], ["stopped"])

    def test_old_notice_rows_still_go_for_older_apps(self):
        cloud = TillKeyCloud()
        bridge.notice("stopped", self.cfg(), post=cloud)
        self.assertIn("S1-T1|notice|stopped|0", cloud.rows)
        self.assertEqual(len([r for r in cloud.rows.values() if r["kind"] == "link_event"]), 1)


class AdminPinTests(Base):
    def test_database_and_key_need_the_admin_pin(self):
        cfg = self.cfg()
        self.assertEqual(config.admin_changes(cfg, {**cfg, "history_from": "days"}), [])
        self.assertEqual(config.admin_changes(cfg, {**cfg, "database_path": "x", "till_key": "y"}), ["database_path", "till_key"])
        cfg = config.set_pin(cfg, "1111")
        self.assertTrue(config.admin_pin_ok(cfg, "1111", now=1), "no admin PIN yet: the Link PIN stands in")
        with self.assertRaises(ValueError):
            config.set_admin_pin(cfg, "1111")
        cfg = config.set_admin_pin(cfg, "98765")
        config.save(cfg)
        cfg = config.load()
        self.assertNotIn("98765", config.path().read_text())
        self.assertFalse(config.admin_pin_ok(cfg, "1111", now=2), "the Link PIN is not enough any more")
        self.assertTrue(config.admin_pin_ok(cfg, "98765", now=3))
        for _ in range(5):
            config.admin_pin_ok(cfg, "0000", now=10)
        self.assertFalse(config.admin_pin_ok(cfg, "98765", now=20), "guessing is slowed down")

    def test_the_window_asks_for_the_admin_pin_for_those_settings(self):
        src = (HERE.parent / "bridge_ui.py").read_text(encoding="utf-8")
        self.assertIn("config.admin_changes(self.cfg, cfg)", src)
        self.assertIn('bridge.notice("database_changed"', src)
        self.assertIn('text="Till key"', src)


if __name__ == "__main__":
    unittest.main()
