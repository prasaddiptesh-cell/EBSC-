"""Automatic updates (only a newer, checked build from the shop's GitHub), the Link PIN, and the notices that tell the
Easy Buys app when sending is stopped or the Link is removed."""
from __future__ import annotations

import hashlib
import json
import re
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import bridge  # noqa: E402
import build_info  # noqa: E402
import config  # noqa: E402
import updater  # noqa: E402
from test_link import FakeCloud  # noqa: E402

SETUP = b"MZ" + b"\x00" * 3_000_000


import base64  # noqa: E402

import ed25519_verify  # noqa: E402
import sign_manifest  # noqa: E402

TEST_SECRET = hashlib.sha256(b"a test key - never the real one").digest()
TEST_PUBLIC = ed25519_verify.public_key(TEST_SECRET).hex()


def site(build: int, data: bytes = SETUP, *, sha: str | None = None, size: int | None = None, sha_file: str | None = None,
         sig: str | None = None, secret: bytes = TEST_SECRET, manifest_edit=None):
    info = {"build": build, "version": "1.2", "name": updater.SETUP_NAME, "size": len(data) if size is None else size, "sha256": sha or hashlib.sha256(data).hexdigest()}
    signed = json.dumps(info, separators=(",", ":"), sort_keys=True).encode()
    good_sig = base64.b64encode(ed25519_verify.sign(secret, signed)).decode()
    served = manifest_edit(signed) if manifest_edit else signed
    calls = []

    def get(url: str, *, limit: int, timeout: int = 60) -> bytes:
        calls.append(url)
        if url.endswith(updater.SIG_NAME):
            if sig == "missing":
                raise OSError("HTTP Error 404: Not Found")
            return (good_sig if sig is None else sig).encode()
        if url.endswith(updater.INFO_NAME):
            return served
        if url.endswith(updater.SHA_NAME):
            if sha_file == "missing":
                raise OSError("HTTP Error 404: Not Found")
            return (sha_file if sha_file is not None else f"{info['sha256']}  {updater.SETUP_NAME}\n").encode()
        if url.endswith(updater.SETUP_NAME):
            if len(data) > limit:
                raise ValueError("the download is bigger than expected")
            return data
        raise AssertionError(url)
    get.calls = calls  # type: ignore[attr-defined]
    return get


class UpdaterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        os.environ["EASYBUYS_UPDATE_HOME"] = self.tmp
        self.old_build = build_info.BUILD
        build_info.BUILD = "40"
        self.old_key = updater.PUBLIC_KEY_HEX
        updater.PUBLIC_KEY_HEX = TEST_PUBLIC  # the tests sign with their own key
        self.started = []

    def tearDown(self) -> None:
        build_info.BUILD = self.old_build
        updater.PUBLIC_KEY_HEX = self.old_key
        os.environ.pop("EASYBUYS_UPDATE_HOME", None)

    def popen(self, cmd, **kw):
        self.started.append(cmd)

    def test_newer_build_is_downloaded_checked_and_installed_silently(self):
        r = updater.update_once(get=site(41), popen=self.popen)
        self.assertTrue(r["done"], r)
        self.assertEqual(len(self.started), 1)
        cmd = self.started[0]
        self.assertTrue(cmd[0].endswith("EasyBuysAroniumLink-Setup-41.exe"))
        self.assertIn("/VERYSILENT", cmd)
        self.assertEqual(Path(cmd[0]).read_bytes(), SETUP)
        self.assertIn("installing", updater.status_text())

    def test_same_or_older_build_never_installed(self):
        for b in (40, 39, 1):
            r = updater.update_once(get=site(b), popen=self.popen)
            self.assertFalse(r["done"])
        self.assertEqual(self.started, [])
        self.assertIn("up to date", updater.status_text())

    def test_wrong_fingerprint_or_size_is_thrown_away(self):
        r = updater.update_once(get=site(41, sha="0" * 64), popen=self.popen)
        self.assertFalse(r["done"])
        self.assertIn("fingerprint", r["error"])
        r = updater.update_once(get=site(41, size=len(SETUP) - 5), popen=self.popen)
        self.assertFalse(r["done"])
        self.assertEqual(self.started, [])
        self.assertEqual(list((Path(self.tmp) / "download").glob("*.exe")) if (Path(self.tmp) / "download").exists() else [], [])

    def test_bad_version_file_or_no_internet_is_quiet(self):
        def broken(url, **kw):
            raise OSError("no internet")
        self.assertFalse(updater.update_once(get=broken, popen=self.popen)["done"])
        self.assertIn("could not reach", updater.status_text())
        self.assertFalse(updater.update_once(get=lambda url, **kw: b"not json", popen=self.popen)["done"])
        self.assertFalse(updater.check(get=site(41, sha="xyz"))["ok"])
        self.assertFalse(updater.check(get=site(41, size=10))["ok"], "a tiny file is not a real installer")

    def test_a_build_that_will_not_install_is_left_for_a_day(self):
        g = site(41)
        for _ in range(3):
            self.assertTrue(updater.update_once(get=g, popen=self.popen, now=1000)["done"])
        r = updater.update_once(get=g, popen=self.popen, now=1000)
        self.assertEqual(r["why"], "failed recently")
        self.assertEqual(updater.update_once(get=g, popen=self.popen, now=1000 + 3600)["why"], "failed recently")
        self.assertTrue(updater.update_once(get=g, popen=self.popen, now=1000 + 25 * 3600)["done"], "tried again the next day")

    def test_a_copy_run_from_the_source_is_never_replaced(self):
        build_info.BUILD = "dev"
        self.assertEqual(updater.update_once(get=site(99), popen=self.popen)["why"], "dev")
        self.assertEqual(self.started, [])

    def test_only_github_https(self):
        self.assertTrue(updater._host_ok("https://github.com/x/y/releases/download/a/b"))
        self.assertTrue(updater._host_ok("https://objects.githubusercontent.com/abc"))
        self.assertFalse(updater._host_ok("http://github.com/x"))
        self.assertFalse(updater._host_ok("https://github.com.evil.example/x"))
        self.assertFalse(updater._host_ok("https://evil.example/github.com"))
        with self.assertRaises(ValueError):
            updater.fetch("https://evil.example/x", limit=10)
        self.assertTrue(updater.BASE.startswith("https://github.com/"))

    def test_updates_come_from_the_public_release_only_repository(self):
        self.assertEqual(updater.REPO, "prasaddiptesh-cell/easybuys-updates")
        self.assertEqual(updater.BASE, "https://github.com/prasaddiptesh-cell/easybuys-updates/releases/download/link-latest/")
        self.assertNotIn("EBSC", updater.BASE)
        self.assertEqual(updater.ALLOWED_HOSTS, ("github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com", "githubusercontent.com"))
        g = site(41)
        updater.update_once(get=g, popen=self.popen)
        self.assertTrue(all(u.startswith(updater.BASE) for u in g.calls), g.calls)
        self.assertEqual([u.rsplit("/", 1)[1] for u in g.calls], [updater.INFO_NAME, updater.SIG_NAME, updater.SHA_NAME, updater.SETUP_NAME])

    def test_the_sha256_file_must_be_there_and_agree(self):
        for bad, why in (("missing", "404"), ("0" * 64 + "  EasyBuysAroniumLink-Setup.exe", "do not agree"), ("not a hash", "not right"), ("", "not right")):
            (Path(self.tmp) / "update.json").unlink(missing_ok=True)  # each case on its own (not "tried 3 times")
            r = updater.update_once(get=site(41, sha_file=bad), popen=self.popen)
            self.assertFalse(r["done"], bad)
            self.assertIn(why, r["error"])
        self.assertEqual(self.started, [])
        (Path(self.tmp) / "update.json").unlink(missing_ok=True)
        ok = updater.update_once(get=site(41, sha_file=hashlib.sha256(SETUP).hexdigest().upper()), popen=self.popen)
        self.assertTrue(ok["done"], "just the hash, any case, is fine")

    # ------------------------------------------------------------ 1.0.0 the signed manifest (audit H7)
    def test_only_a_manifest_signed_with_the_baked_in_key_is_used(self):
        evil = hashlib.sha256(b"someone else's key").digest()
        bigger = lambda m: m.replace(b'"build":41', b'"build":99')  # noqa: E731
        cases = [("missing signature", dict(sig="missing")), ("garbage signature", dict(sig="!!not base64!!")),
                 ("signed with another key", dict(secret=evil)), ("manifest changed after signing", dict(manifest_edit=bigger)),
                 ("empty signature", dict(sig=""))]
        for why, kw in cases:
            (Path(self.tmp) / "update.json").unlink(missing_ok=True)
            r = updater.update_once(get=site(41, **kw), popen=self.popen)
            self.assertFalse(r["done"], why)
            self.assertIn("not signed by Easy Buys", r.get("error", ""), why)
        self.assertEqual(self.started, [], "nothing was ever run")
        # a different installer with its own correct hash and size, but a manifest signed by someone else: refused
        other = b"MZ" + b"\x01" * 3_000_000
        self.assertFalse(updater.update_once(get=site(41, other, secret=evil), popen=self.popen)["done"])
        self.assertEqual(self.started, [])

    def test_the_real_public_key_is_baked_in_and_the_private_key_is_not_in_the_repo(self):
        self.assertEqual(self.old_key, "ca84b03369463be1d5d4d35b40939e64d0e015d3fe0ac47ac12f0a7f8d4c994f")
        self.assertIsNotNone(ed25519_verify._decompress(bytes.fromhex(self.old_key)), "a real curve point")
        repo = HERE.parents[2]
        for p in repo.rglob("*"):
            if p.is_file() and ".git" not in p.parts and "node_modules" not in p.parts and p.stat().st_size < 2_000_000:
                try:
                    text = p.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                self.assertIsNone(re.search(r"-----BEGIN [A-Z ]*PRIVATE KEY-----\s+[A-Za-z0-9+/=]{40,}", text), str(p))

    def test_sign_manifest_tool_makes_what_the_updater_accepts(self):
        installer = Path(self.tmp) / updater.SETUP_NAME
        installer.write_bytes(SETUP)
        der = sign_manifest.PKCS8_PREFIX + TEST_SECRET
        pem = "-----BEGIN PRIVATE KEY-----\n" + base64.b64encode(der).decode() + "\n-----END PRIVATE KEY-----\n"
        keyfile = Path(self.tmp) / "k.pem"
        keyfile.write_text(pem)
        out = Path(self.tmp) / "out"
        out.mkdir()
        self.assertEqual(sign_manifest.main(["--installer", str(installer), "--build", "41", "--version", "1.3", "--key", str(keyfile), "--out-dir", str(out)]), 0)
        files = {p.name: p.read_bytes() for p in out.iterdir()}
        self.assertEqual(set(files), {updater.INFO_NAME, updater.SIG_NAME, updater.SHA_NAME})

        def get(url, *, limit, timeout=60):
            name = url.rsplit("/", 1)[1]
            return SETUP if name == updater.SETUP_NAME else files[name]
        r = updater.update_once(get=get, popen=self.popen)
        self.assertTrue(r["done"], r)
        with self.assertRaises(ValueError):
            sign_manifest.private_from_pem("-----BEGIN PRIVATE KEY-----\nAAAA\n-----END PRIVATE KEY-----")

    def test_the_repository_address_is_never_shown(self):
        def broken(url, **kw):
            raise OSError("no internet")
        updater.update_once(get=broken, popen=self.popen)
        updater.update_once(get=site(41, sha_file="missing"), popen=self.popen)
        with self.assertRaises(ValueError) as e:
            updater.fetch("https://evil.example/prasaddiptesh-cell/x", limit=10)
        shown = [updater.status_text(), str(e.exception), json.dumps(updater.read_status())]
        log = Path(self.tmp) / "update.log"
        if log.exists():
            shown.append(log.read_text(encoding="utf-8"))
        for f in ("bridge_ui.py", "bridge.py", "README.md", "installer.iss"):  # the window, status and help text
            shown.append((HERE.parent / f).read_text(encoding="utf-8"))
        for text in shown:
            self.assertNotIn("prasaddiptesh", text)
            self.assertNotIn("easybuys-updates", text)
            self.assertNotIn("EBSC", text)

    def test_after_update_marks_the_new_build(self):
        updater.update_once(get=site(41), popen=self.popen)
        build_info.BUILD = "41"
        ran = []
        updater.after_update(run=lambda cmd, **kw: ran.append(cmd) or type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})())
        self.assertIn("up to date", updater.status_text())
        self.assertTrue(any("/Run" in c for c in ran))

    def test_task_runs_as_the_system_at_start_up_and_every_2_hours(self):
        x = updater.task_xml(r"C:\Program Files\Easy Buys\Aronium Link\EasyBuysAroniumLink.exe")
        self.assertIn("<UserId>S-1-5-18</UserId>", x)
        self.assertIn("<BootTrigger>", x)
        self.assertIn("PT2H", x)
        self.assertIn("<Arguments>--update</Arguments>", x)


class PinAndNoticeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.mkdtemp()
        os.environ["EASYBUYS_LINK_HOME"] = self.tmp

    def tearDown(self) -> None:
        os.environ.pop("EASYBUYS_LINK_HOME", None)

    def test_pin_is_hashed_checked_and_slows_down_guessing(self):
        cfg = config.load()
        self.assertTrue(config.pin_ok(cfg, "anything"), "no PIN set: open")
        with self.assertRaises(ValueError):
            config.set_pin(cfg, "12")
        with self.assertRaises(ValueError):
            config.set_pin(cfg, "abcd")
        cfg = config.set_pin(cfg, "4321")
        config.save(cfg)
        saved = (Path(self.tmp) / "EasyBuysAroniumLink" / "settings.json").read_text()
        self.assertNotIn("4321", saved, "never kept as typed")
        cfg = config.load()
        self.assertTrue(config.pin_is_set(cfg))
        self.assertFalse(config.pin_ok(cfg, "1111", now=100))
        self.assertTrue(config.pin_ok(cfg, "4321", now=100))
        for _ in range(5):
            self.assertFalse(config.pin_ok(cfg, "0000", now=200))
        self.assertTrue(config.pin_locked_out(now=250))
        self.assertFalse(config.pin_ok(cfg, "4321", now=250), "5 wrong: even the right PIN waits 5 minutes")
        self.assertTrue(config.pin_ok(cfg, "4321", now=600))

    def test_stopped_and_removed_are_told_to_the_app(self):
        cloud = FakeCloud()
        cfg = config.load()
        cfg.update({"shop_code": "S1", "till_number": 1, "cloud_url": "https://script.google.com/macros/s/a/exec", "main_key": cloud.key, "database_path": "x"})
        config.save(cfg)
        cfg = config.load()
        self.assertTrue(bridge.notice("stopped", cfg, post=cloud))
        row = cloud.rows["S1-T1|notice|stopped|0"]
        self.assertEqual(row["kind"], "notice")
        self.assertEqual(json.loads(row["data"])["event"], "stopped")
        self.assertTrue(bridge.notice("uninstalled", cfg, post=cloud))
        self.assertIn("S1-T1|notice|uninstalled|0", cloud.rows)

    def test_notice_never_breaks_anything(self):
        def down(url, body):
            raise OSError("no internet")
        self.assertFalse(bridge.notice("stopped", None, post=down))


if __name__ == "__main__":
    unittest.main()
