"""Automatic updates of the Easy Buys Aronium Link on the till PCs.

The installer adds a Windows task "Easy Buys Aronium Link Update" that runs as the system account when the PC starts
and every 2 hours (before anyone logs in too):
    EasyBuysAroniumLink.exe --update
It reads link-version.json from the shop's GitHub release ("link-latest"). When that build is newer than this one it
downloads EasyBuysAroniumLink-Setup.exe, checks its size and SHA-256 against the json, and runs it silently. The
installer stops the old program, puts the new one in place and starts sending again (--after-update).

Safe by design:
  * only from https://github.com/<the shop's repository> – nothing else is ever downloaded or run;
  * the file must match the fingerprint (SHA-256) and size published with it, or it is thrown away;
  * never goes backwards (only a higher build number), and a build that failed to install is left alone for a day;
  * Aronium is never touched – only this program is replaced. Settings and what was sent are kept.
Everything it does is written to update\\update.log next to the program, and the last result to update.json (shown
on the Status tab).
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Any, Callable

import build_info

REPO = "prasaddiptesh-cell/EBSC-"
BASE = f"https://github.com/{REPO}/releases/download/link-latest/"
INFO_NAME = "link-version.json"
SETUP_NAME = "EasyBuysAroniumLink-Setup.exe"
TASK_NAME = "Easy Buys Aronium Link Update"
LINK_TASK = "Easy Buys Aronium Link"
EVERY_HOURS = 2
MIN_SIZE, MAX_SIZE = 2_000_000, 300_000_000
ALLOWED_HOSTS = ("github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com", "githubusercontent.com")


def data_dir() -> Path:
    """Next to the installed program (Program Files – only administrators and the system can write there, so nobody
    can swap the downloaded installer before it runs). A copy run from the source uses a temporary folder."""
    if os.environ.get("EASYBUYS_UPDATE_HOME"):
        p = Path(os.environ["EASYBUYS_UPDATE_HOME"])
    elif getattr(sys, "frozen", False):
        p = Path(sys.executable).resolve().parent / "update"
    else:
        p = Path(os.environ.get("TEMP") or "/tmp") / "EasyBuysAroniumLink-update"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass  # the window (an ordinary user) can only read it
    return p


def log(msg: str) -> None:
    try:
        f = data_dir() / "update.log"
        if f.exists() and f.stat().st_size > 512_000:
            f.replace(f.with_suffix(".old.log"))
        with f.open("a", encoding="utf-8") as h:
            h.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except OSError:
        pass


def local_build() -> int | None:
    b = str(build_info.BUILD).strip()
    return int(b) if b.isdigit() else None


def read_status() -> dict[str, Any]:
    try:
        return json.loads((data_dir() / "update.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def write_status(**kw: Any) -> None:
    st = read_status()
    st.update(kw)
    try:
        (data_dir() / "update.json").write_text(json.dumps(st, indent=1), encoding="utf-8")
    except OSError:
        pass


def _host_ok(url: str) -> bool:
    from urllib.parse import urlparse
    u = urlparse(url)
    return u.scheme == "https" and any(u.hostname == h or (u.hostname or "").endswith("." + h) for h in ALLOWED_HOSTS)


class _OnlyGitHub(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        if not _host_ok(newurl):
            raise urllib.error.URLError(f"refused to follow a redirect to {newurl}")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url: str, *, limit: int, timeout: int = 60) -> bytes:
    """GET over https from GitHub only, at most `limit` bytes."""
    if not _host_ok(url):
        raise ValueError(f"not a GitHub address: {url}")
    opener = urllib.request.build_opener(_OnlyGitHub)
    req = urllib.request.Request(url, headers={"User-Agent": f"EasyBuysAroniumLink/{build_info.VERSION}"})
    with opener.open(req, timeout=timeout) as r:
        out = bytearray()
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            out += chunk
            if len(out) > limit:
                raise ValueError("the download is bigger than expected")
        return bytes(out)


def check(get: Callable[..., bytes] = fetch) -> dict[str, Any]:
    """{ok, newer, remote: {...}, local, error}. Never raises."""
    mine = local_build()
    try:
        info = json.loads(get(BASE + INFO_NAME, limit=64_000, timeout=30).decode("utf-8"))
        rb = int(info.get("build"))
        sha = str(info.get("sha256", "")).lower()
        size = int(info.get("size"))
        if len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha) or not (MIN_SIZE <= size <= MAX_SIZE):
            raise ValueError("the version file is not right")
        remote = {"build": rb, "version": str(info.get("version", "")), "sha256": sha, "size": size}
        return {"ok": True, "newer": mine is not None and rb > mine, "remote": remote, "local": mine}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "newer": False, "local": mine, "error": str(exc)[:200]}


def download(remote: dict[str, Any], get: Callable[..., bytes] = fetch) -> Path:
    data = get(BASE + SETUP_NAME, limit=remote["size"] + 1, timeout=600)
    if len(data) != remote["size"]:
        raise ValueError(f"the download is {len(data)} bytes, expected {remote['size']}")
    if hashlib.sha256(data).hexdigest() != remote["sha256"]:
        raise ValueError("the download does not match its fingerprint (SHA-256) – thrown away")
    folder = data_dir() / "download"
    folder.mkdir(exist_ok=True)
    for old in folder.glob("*.exe"):
        try:
            old.unlink()
        except OSError:
            pass
    path = folder / f"EasyBuysAroniumLink-Setup-{remote['build']}.exe"
    path.write_bytes(data)
    return path


def run_installer(path: Path, popen: Callable[..., Any] = subprocess.Popen) -> None:
    """Starts the installer silently and does not wait: it stops this program while it works."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
    popen([str(path), "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART", f"/LOG={data_dir() / 'install.log'}"], creationflags=flags, close_fds=True)


def update_once(*, get: Callable[..., bytes] = fetch, popen: Callable[..., Any] = subprocess.Popen, now: float | None = None) -> dict[str, Any]:
    """One look: install a newer build if there is one. Never raises."""
    now = time.time() if now is None else now
    kick_link()
    try:
        c = check(get)
        write_status(checked_at=time.strftime("%Y-%m-%d %H:%M", time.localtime(now)), local=c.get("local"),
                     remote=(c.get("remote") or {}).get("build"), error=c.get("error", ""))
        if not c["ok"]:
            log(f"check failed: {c.get('error')}")
            return {"done": False, "why": "check", **c}
        if c["local"] is None:
            return {"done": False, "why": "dev"}  # a copy run from the source is never replaced
        if not c["newer"]:
            return {"done": False, "why": "up to date"}
        rb = c["remote"]["build"]
        st = read_status()
        if st.get("failed_build") == rb and now - float(st.get("failed_at") or 0) < 24 * 3600:
            return {"done": False, "why": "failed recently"}
        tries = int(st.get("tries", 0)) + 1 if st.get("trying_build") == rb else 1
        if tries > 3:
            write_status(failed_build=rb, failed_at=now, tries=0, trying_build=None)
            log(f"build {rb} did not install 3 times – leaving it for a day")
            return {"done": False, "why": "failed recently"}
        write_status(trying_build=rb, tries=tries)
        log(f"build {rb} is out (this is {c['local']}) – downloading")
        path = download(c["remote"], get)
        log(f"downloaded and checked {path.name} – installing")
        write_status(installing=rb, installing_at=time.strftime("%Y-%m-%d %H:%M", time.localtime(now)))
        run_installer(path, popen)
        return {"done": True, "build": rb}
    except Exception as exc:  # noqa: BLE001
        log(f"update problem: {exc}")
        write_status(error=str(exc)[:200])
        return {"done": False, "why": "error", "error": str(exc)[:200]}


def kick_link(run: Callable[..., Any] = subprocess.run) -> None:
    """Starts the Link's own sending task again in case it was stopped (it ignores this when already running, and a
    stop made with the Link PIN deletes that task, so nothing starts)."""
    if sys.platform != "win32":
        return
    try:
        run(["schtasks", "/Run", "/TN", LINK_TASK], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=30)
    except Exception:  # noqa: BLE001
        pass


def after_update(run: Callable[..., Any] = subprocess.run) -> None:
    """Run by the installer (as administrator / the system): keep the update task, start sending again."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        install_task(run)
    except Exception as exc:  # noqa: BLE001
        log(f"update task: {exc}")
    try:
        run(["schtasks", "/Run", "/TN", LINK_TASK], capture_output=True, text=True, creationflags=flags)
    except Exception:  # noqa: BLE001
        pass
    mine = local_build()
    st = read_status()
    if st.get("installing") and mine is not None and mine >= int(st["installing"]):
        log(f"now on build {mine}")
        write_status(installing=None, trying_build=None, tries=0, updated_at=time.strftime("%Y-%m-%d %H:%M"), local=mine)


def task_xml(exe: str) -> str:
    from xml.sax.saxutils import escape
    start = time.strftime("%Y-%m-%dT%H:%M:00")
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Easy Buys: keeps the Aronium Link up to date (downloads only from the shop's GitHub, checked).</Description></RegistrationInfo>
  <Triggers>
    <BootTrigger><Enabled>true</Enabled><Delay>PT3M</Delay></BootTrigger>
    <TimeTrigger><StartBoundary>{start}</StartBoundary><Enabled>true</Enabled>
      <Repetition><Interval>PT{EVERY_HOURS}H</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition></TimeTrigger>
  </Triggers>
  <Principals><Principal id="Author"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>true</RunOnlyIfNetworkAvailable>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author"><Exec><Command>{escape(exe)}</Command><Arguments>--update</Arguments></Exec></Actions>
</Task>
"""


def install_task(run: Callable[..., Any] = subprocess.run) -> bool:
    if sys.platform != "win32" or not getattr(sys, "frozen", False):
        return False
    xml = data_dir() / "update-task.xml"
    xml.write_text(task_xml(sys.executable), encoding="utf-16")
    r = run(["schtasks", "/Create", "/F", "/TN", TASK_NAME, "/XML", str(xml)], capture_output=True, text=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    ok = r.returncode == 0
    log("update task " + ("set" if ok else f"not set: {(r.stdout or r.stderr).strip()[:200]}"))
    return ok


def remove_task(run: Callable[..., Any] = subprocess.run) -> None:
    if sys.platform != "win32":
        return
    run(["schtasks", "/Delete", "/F", "/TN", TASK_NAME], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def status_text() -> str:
    """One line for the Status tab."""
    st = read_status()
    if not st.get("checked_at"):
        return "Updates: automatic (checks every 2 hours)"
    if st.get("installing"):
        return f"Updates: installing build {st['installing']}…"
    if st.get("remote") and st.get("local") and int(st["remote"]) > int(st["local"]):
        return f"Updates: build {st['remote']} is out – it installs by itself (checked {st['checked_at']})"
    if st.get("error"):
        return f"Updates: automatic – last check could not reach GitHub ({st['checked_at']}), tries again"
    return f"Updates: automatic – up to date (checked {st['checked_at']})"
