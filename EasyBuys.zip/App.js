// Easy Buys – one app for the whole business, built from modules (src/modules/registry.js).
// The Bakery app is the base: its database, look, offline storage, reports and cloud link are shared.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, BackHandler, ScrollView, AppState, useWindowDimensions, Linking } from 'react-native';
import { Text, ScaleContext, ScaleSetterContext } from './src/ui/scale.js';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { openExpoDb } from './src/db/expoAdapter.js';
import { initDatabase } from './src/db/init.js';
import { AppContext, UIProvider } from './src/ui/components.js';
import { C } from './src/ui/theme.js';
import LoginScreen from './src/app/LoginScreen.js';
import DueStepPopup from './src/modules/bakery/screens/worker/DueStepPopup.js';
import ClockKiosk from './src/modules/timeclock/screens/ClockKiosk.js';
import LinkScreen from './src/modules/devices/screens/LinkScreen.js';
import { linkState } from './src/modules/devices/service.js';
import { allScreens } from './src/modules/registry.js';
import { moduleOn } from './src/modules/admin/service.js';
import { getSettings, deviceId } from './src/services/core.js';
import { bakeryRole, getUiScale, setUiScale, can } from './src/services/access.js';
import { dailyChecks } from './src/services/stock.js';
import { setupNotifications, rescheduleReminders, setKeepAwake } from './src/platform/notify.js';
import { syncNow } from './src/platform/cloud.js';

let dbError = null;
try {
  initDatabase(openExpoDb());
  deviceId();
  dailyChecks();
} catch (e) {
  dbError = e;
}

let keySeq = 0;

export default function App() {
  const { width } = useWindowDimensions();
  const [scale, setScale] = useState(() => (dbError ? 1 : getUiScale(width)));
  const changeScale = useCallback((v) => { setUiScale(v); setScale(v === null ? getUiScale(width) : v); }, [width]);
  const [user, setUser] = useState(null);
  const [kiosk, setKiosk] = useState(false);
  const [linking, setLinking] = useState(null); // null, or { code } while the "Link to Easy Buys" screen is open
  const [stack, setStack] = useState([]);
  const [homeTab, setHomeTab] = useState(null);
  const [, setTick] = useState(0);
  const lastTouch = useRef(Date.now());
  const screens = useMemo(() => (dbError ? {} : allScreens()), []);

  const logout = useCallback(() => {
    setUser(null);
    setStack([]);
    setHomeTab(null);
  }, []);

  const login = useCallback((u) => {
    lastTouch.current = Date.now();
    setKiosk(false);
    setUser(u);
    setStack([{ name: 'Home', params: {}, key: ++keySeq }]);
  }, []);

  const nav = useMemo(() => ({
    push: (name, params = {}) => setStack((s) => s.concat([{ name, params, key: ++keySeq }])),
    pop: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
    replace: (name, params = {}) => setStack((s) => s.slice(0, -1).concat([{ name, params, key: ++keySeq }])),
    home: () => setStack((s) => s.slice(0, 1).map((x) => ({ ...x, key: ++keySeq }))),
  }), []);

  // Start-up: reminders, keep-awake, background sync every minute, daily checks.
  useEffect(() => {
    if (dbError) return undefined;
    setupNotifications().then(rescheduleReminders);
    setKeepAwake(getSettings().keepAwake);
    syncNow().catch(() => {});
    const sync = setInterval(() => { syncNow().catch(() => {}); }, 60000);
    const daily = setInterval(() => { try { dailyChecks(); } catch (e) { /* ignore */ } }, 60 * 60000);
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') {
        try { dailyChecks(); } catch (e) { /* ignore */ }
        rescheduleReminders();
        syncNow().catch(() => {});
        setTick((n) => n + 1);
      }
    });
    return () => { clearInterval(sync); clearInterval(daily); sub.remove(); };
  }, []);

  // Tapping an invite link (easybuys://link?c=...) in an email or message opens the link screen.
  useEffect(() => {
    if (dbError) return undefined;
    const open = (url) => {
      if (!url || !/^easybuys:\/\/link/i.test(url)) return;
      if (linkState().linked) return; // already linked: ignore stray taps
      setUser(null);
      setStack([]);
      setKiosk(false);
      setLinking({ code: url });
    };
    Linking.getInitialURL().then(open).catch(() => {});
    const sub = Linking.addEventListener('url', (e) => open(e && e.url));
    return () => sub.remove();
  }, []);

  // Android back button: one screen back (or out of the Time Clock).
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (linking) { setLinking(null); return true; }
      if (kiosk) { setKiosk(false); return true; }
      if (stack.length > 1) { nav.pop(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [stack.length, nav, kiosk, linking]);

  // Auto log-out when the device is left unattended (Admin can change the minutes).
  useEffect(() => {
    if (!user) return undefined;
    const t = setInterval(() => {
      if (Date.now() - lastTouch.current > getSettings().idleLogoutMin * 60000) logout();
    }, 30000);
    return () => clearInterval(t);
  }, [user, logout]);

  useEffect(() => { if (!dbError) rescheduleReminders(); }, [stack]);

  if (dbError) {
    return (
      <ScrollView contentContainerStyle={{ padding: 40 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.danger }}>The database could not be opened</Text>
        <Text style={{ fontSize: 18, marginTop: 10 }}>{String(dbError && dbError.message)}</Text>
      </ScrollView>
    );
  }

  const top = stack[stack.length - 1];
  const entry = top ? screens[top.name] : null;
  const allowed = entry && user && entry.can(user);
  const ScreenComponent = allowed ? entry.component : null;
  // The Bakery screens see each person through their bakery role (e.g. Owner -> Admin).
  const viewUser = user && entry && entry.bakery && !entry.shared ? { ...user, role: bakeryRole(user), realRole: user.role } : user;

  const openClock = () => { logout(); setKiosk(true); };
  const ctx = {
    user: viewUser, realUser: user, nav, logout, homeTab, setHomeTab, openClock, can: (p) => can(user, p),
    canGoBack: stack.length > 1,
    currentScreen: top || null,
    refresh: () => setTick((n) => n + 1),
  };

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <ScaleContext.Provider value={scale}>
        <ScaleSetterContext.Provider value={changeScale}>
          <UIProvider>
            <AppContext.Provider value={ctx}>
              <View style={{ flex: 1, backgroundColor: C.bg }} onTouchStart={() => { lastTouch.current = Date.now(); }}>
                {linking && !user ? (
                  <LinkScreen initialCode={linking.code} onDone={() => setLinking(null)} onBack={() => setLinking(null)} />
                ) : kiosk && !user ? (
                  <ClockKiosk onExit={() => setKiosk(false)} />
                ) : !user ? (
                  <LoginScreen onLogin={login} onClock={moduleOn('timeclock') ? () => setKiosk(true) : null} onLink={linkState().linked ? null : () => setLinking({ code: '' })} />
                ) : ScreenComponent ? (
                  <ScreenComponent key={top.key} params={top.params || {}} />
                ) : (
                  <View style={{ padding: 40 }}>
                    <Text style={{ fontSize: 20 }}>You do not have access to this screen.</Text>
                    <Text style={{ fontSize: 20, color: C.primary, marginTop: 20 }} onPress={nav.home}>Go home</Text>
                  </View>
                )}
                {user && moduleOn('bakery') && can(user, 'bakery') ? <DueStepPopup /> : null}
              </View>
            </AppContext.Provider>
          </UIProvider>
        </ScaleSetterContext.Provider>
      </ScaleContext.Provider>
    </SafeAreaProvider>
  );
}
