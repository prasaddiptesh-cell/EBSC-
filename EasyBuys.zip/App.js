// Easy Buys – one app for the whole business, built from modules (src/modules/registry.js).
// The Bakery app is the base: its database, look, offline storage, reports and cloud link are shared.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, BackHandler, ScrollView, AppState, useWindowDimensions, Linking } from 'react-native';
import { Text, ScaleContext, ScaleSetterContext } from './src/ui/scale.js';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaInsetsContext, useSafeAreaInsets } from 'react-native-safe-area-context';
import { openExpoDb } from './src/db/expoAdapter.js';
import { startDatabases, isTraining, reopenDatabases, hasOpener } from './src/platform/training.js';
import { AppContext, UIProvider } from './src/ui/components.js';
import { C } from './src/ui/theme.js';
import LoginScreen from './src/app/LoginScreen.js';
import DueStepPopup from './src/modules/bakery/screens/worker/DueStepPopup.js';
import ClockKiosk from './src/modules/timeclock/screens/ClockKiosk.js';
import LinkScreen from './src/modules/devices/screens/LinkScreen.js';
import { linkState } from './src/modules/devices/service.js';
import { FaceEngineHost } from './src/modules/timeclock/engineHost.js';
import { faceSettings } from './src/modules/timeclock/rules.js';
import { usesMatching } from './src/modules/timeclock/face.js';
import { deviceSettings } from './src/services/access.js';
import { allScreens } from './src/modules/registry.js';
import { moduleOn } from './src/modules/admin/service.js';
import { getSettings, getSetting, deviceId } from './src/services/core.js';
import { bakeryRole, getUiScale, setUiScale, can } from './src/services/access.js';
import { dailyChecks } from './src/services/stock.js';
import { setupNotifications, rescheduleReminders, setKeepAwake } from './src/platform/notify.js';
import { syncNow } from './src/platform/cloud.js';
import { dailyLicenceCheck } from './src/modules/licences/service.js';
import { checkForUpdate } from './src/platform/updates.js';
import { notify } from './src/modules/verify/service.js';
import { ScreenGuard } from './src/ui/ErrorBoundary.js';
import { useUI } from './src/ui/components.js';
import { logError, onAppError, noteScreen, setErrorUser, markRunning, checkLastClose } from './src/services/errorLog.js';
import { Splash, DamagedScreen, AlertWatcher } from './src/ui/startup.js';
import { startQuickCheck, startFullCheck, fullCheckDue } from './src/services/health.js';
import { maybeSnapshot } from './src/services/snapshots.js';
import { freeDiskBytes } from './src/platform/device.js';
import { fileExists } from './src/platform/files.js';
import { AboutScreen } from './src/modules/admin/screens/AboutScreen.js';

let dbError = null;
let lastClose = null;
const splashProgress = new Set(); // listeners of the start-up check (the splash)
const subscribeSplash = (fn) => { splashProgress.add(fn); return () => splashProgress.delete(fn); };
try {
  startDatabases(openExpoDb);
  deviceId();
} catch (e) {
  dbError = e;
}
if (!dbError) {
  lastClose = checkLastClose();
  markRunning(true);
  try { dailyChecks(); } catch (e) { logError(e, { where: 'start-up checks' }); }
  try { if (moduleOn('licences')) dailyLicenceCheck(notify); } catch (e) { logError(e, { where: 'licence reminders' }); }
}

// Any error not caught elsewhere (for example inside a button) is written to the problem log and shown,
// instead of closing the app.
if (typeof globalThis !== 'undefined' && globalThis.ErrorUtils && globalThis.ErrorUtils.setGlobalHandler) {
  const prev = globalThis.ErrorUtils.getGlobalHandler ? globalThis.ErrorUtils.getGlobalHandler() : null;
  globalThis.ErrorUtils.setGlobalHandler((e, isFatal) => {
    try { logError(e, { where: isFatal ? 'app' : 'button', fatal: !!isFatal }); } catch (x) { /* ignore */ }
    if (typeof __DEV__ !== 'undefined' && __DEV__ && prev) prev(e, isFatal);
  });
}

// The orange training bar sits below the phone's status bar; the screens under it then need no extra top space.
function TrainingFrame({ on, user, children }) {
  const insets = useSafeAreaInsets();
  if (!on) return children;
  return (
    <>
      <View testID="training-bar" style={{ backgroundColor: '#e67e22', paddingTop: insets.top + 6, paddingBottom: 6, paddingHorizontal: 12 }}>
        <Text style={{ color: '#fff', fontSize: 15, fontWeight: '800', textAlign: 'center' }}>
          TRAINING MODE – practice figures only, nothing is real or sent anywhere.{!user ? ' Practice PINs: Owner 5001 · Manager 5002 · Cashier 5003 · Assistant 5004' : ''}
        </Text>
      </View>
      <SafeAreaInsetsContext.Provider value={{ ...insets, top: 0 }}>{children}</SafeAreaInsetsContext.Provider>
    </>
  );
}

// Screens the screen check does not open (camera / face / linking / backup screens).
const CHECK_SKIP = /Face|Kiosk|Link|Camera|Scan|Backup|Restore|Problems/i;

// Shows problems that happened outside a screen (e.g. in a button) as a message.
function ErrorAlerts() {
  const ui = useUI();
  const last = useRef(0);
  useEffect(() => onAppError((entry) => {
    if (entry.where === 'screen') return; // the screen shows its own message
    if (Date.now() - last.current < 3000) return;
    last.current = Date.now();
    ui.alert({ title: 'Something went wrong', message: `${entry.message}\n\nThe app stayed open. This was written to Admin & settings › Problem log.`, tone: 'danger' });
  }), [ui]);
  useEffect(() => {
    if (lastClose) {
      const where = lastClose.where;
      lastClose = null;
      ui.alert({ title: 'The app closed last time', message: `It closed unexpectedly${where ? ` on the screen "${where}"` : ''}. This was written to the problem log (Admin & settings › Problem log).`, tone: 'warn' });
    }
  }, [ui]);
  return null;
}

let keySeq = 0;

export default function App() {
  const { width } = useWindowDimensions();
  const [scale, setScale] = useState(() => (dbError ? 1 : getUiScale(width)));
  const changeScale = useCallback((v) => { setUiScale(v); setScale(v === null ? getUiScale(width) : v); }, [width]);
  const [user, setUser] = useState(null);
  const [kiosk, setKiosk] = useState(false);
  const [linking, setLinking] = useState(null); // null, or { code } while the "Link to Easy Buys" screen is open
  const [stack, setStack] = useState([]);
  const [homeTab, setHomeTab] = useState(null);
  const [, setTick] = useState(0);
  const lastTouch = useRef(Date.now());
  const [tour, setTour] = useState(null); // screen check: { names, i }
  const tourFail = useRef({});
  const [dbEpoch, setDbEpoch] = useState(0);
  const screens = useMemo(() => (dbError ? {} : allScreens()), [dbEpoch]);
  const [about, setAbout] = useState(false); // About opened from the login screen (ⓘ)
  // Health check on opening (at most 4 seconds on the splash; the rest carries on in the background).
  const [health, setHealth] = useState(() => (dbError ? { phase: 'damaged', problem: `The database could not be opened: ${String(dbError && dbError.message)}` } : { phase: 'checking', state: null }));
  useEffect(() => {
    if (dbError) return undefined;
    let live = true;
    // Progress goes straight to the splash (not through App, so App does not redraw for every step).
    const run = startQuickCheck({ lastClose, freeDisk: freeDiskBytes }, { onStep: (st) => { splashProgress.forEach((fn) => fn({ ...st, results: st.results.slice() })); } });
    const settle = (st) => {
      if (!live) return;
      if (st.status === 'damaged') setHealth({ phase: 'damaged', problem: (st.results.find((r) => r.status === 'damaged') || {}).text });
      else setHealth((h) => (h.phase === 'damaged' ? h : { phase: 'ready', state: st }));
    };
    run.first.then((st) => { splashProgress.forEach((fn) => fn({ ...st, results: st.results.slice(), timedOut: !st.done })); setTimeout(() => settle(st), st.done ? 120 : 0); });
    run.all.then(settle).catch(() => {});
    return () => { live = false; };
  }, [dbEpoch]);

  const logout = useCallback(() => {
    setUser(null);
    setStack([]);
    setHomeTab(null);
  }, []);

  const login = useCallback((u) => {
    lastTouch.current = Date.now();
    setKiosk(false);
    setUser(u);
    setStack([{ name: 'Home', params: {}, key: ++keySeq }]);
  }, []);

  const nav = useMemo(() => ({
    push: (name, params = {}) => setStack((s) => s.concat([{ name, params, key: ++keySeq }])),
    pop: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
    replace: (name, params = {}) => setStack((s) => s.slice(0, -1).concat([{ name, params, key: ++keySeq }])),
    home: () => setStack((s) => s.slice(0, 1).map((x) => ({ ...x, key: ++keySeq }))),
  }), []);

  // Start-up: reminders, keep-awake, background sync every minute, daily checks.
  useEffect(() => {
    if (dbError) return undefined;
    setupNotifications().then(rescheduleReminders);
    setKeepAwake(getSettings().keepAwake);
    syncNow().catch(() => {});
    checkForUpdate().catch(() => {});
    const sync = setInterval(() => { syncNow().catch(() => {}); }, 60000);
    const daily = setInterval(() => { try { dailyChecks(); } catch (e) { /* ignore */ } try { if (moduleOn('licences')) dailyLicenceCheck(notify); } catch (e) { /* ignore */ } }, 60 * 60000);
    // Safety copies every few hours while in use; the full health check once a night when the tablet is idle.
    const copies = setInterval(() => {
      maybeSnapshot().catch(() => {});
      try { if (fullCheckDue({ idleMinutes: (Date.now() - lastTouch.current) / 60000 })) startFullCheck({ freeDisk: freeDiskBytes, exists: fileExists }).all.catch(() => {}); } catch (e) { /* next time */ }
    }, 10 * 60000);
    setTimeout(() => { maybeSnapshot().catch(() => {}); }, 60000);
    const sub = AppState.addEventListener('change', (st) => {
      markRunning(st === 'active');
      if (st === 'active') {
        try { dailyChecks(); } catch (e) { /* ignore */ }
        rescheduleReminders();
        syncNow().catch(() => {});
        checkForUpdate().catch(() => {});
        setTick((n) => n + 1);
      }
    });
    return () => { clearInterval(sync); clearInterval(daily); clearInterval(copies); sub.remove(); };
  }, []);

  // Tapping an invite link (easybuys://link?c=...) in an email or message opens the link screen.
  useEffect(() => {
    if (dbError) return undefined;
    const open = (url) => {
      if (!url || !/^easybuys:\/\/link/i.test(url)) return;
      if (linkState().linked) return; // already linked: ignore stray taps
      setUser(null);
      setStack([]);
      setKiosk(false);
      setLinking({ code: url });
    };
    Linking.getInitialURL().then(open).catch(() => {});
    const sub = Linking.addEventListener('url', (e) => open(e && e.url));
    return () => sub.remove();
  }, []);

  // Android back button: one screen back (or out of the Time Clock).
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (linking) { setLinking(null); return true; }
      if (kiosk) { setKiosk(false); return true; }
      if (stack.length > 1) { nav.pop(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [stack.length, nav, kiosk, linking]);

  // Auto log-out when the device is left unattended (Admin can change the minutes).
  useEffect(() => {
    if (!user) return undefined;
    const t = setInterval(() => {
      if (Date.now() - lastTouch.current > getSettings().idleLogoutMin * 60000) logout();
    }, 30000);
    return () => clearInterval(t);
  }, [user, logout]);

  useEffect(() => { if (!dbError) rescheduleReminders(); }, [stack]);

  // Problem log: remember who is using the app and which screens were opened.
  useEffect(() => { setErrorUser(user); }, [user]);
  const topName = stack.length ? stack[stack.length - 1].name : (kiosk ? 'Time Clock' : linking ? 'Link device' : 'Login');
  const topKey = stack.length ? stack[stack.length - 1].key : 0;
  useEffect(() => { if (!dbError) noteScreen(topName); }, [topName, topKey]);

  // Screen check: opens every screen for a moment and notes which ones have a problem.
  const startScreenCheck = useCallback(() => {
    if (!user) return;
    const names = Object.keys(screens).filter((n) => n !== 'Home' && !CHECK_SKIP.test(n) && screens[n].can(user));
    if (!names.length) return;
    tourFail.current = {};
    setTour({ names, i: 0 });
    setStack((s) => [s[0], { name: names[0], params: {}, key: ++keySeq }]);
  }, [screens, user]);
  useEffect(() => {
    if (!tour) return undefined;
    const t = setTimeout(() => {
      const i = tour.i + 1;
      if (i >= tour.names.length) {
        const results = tour.names.map((n) => ({ name: n, ok: !tourFail.current[n], message: tourFail.current[n] || '' }));
        setTour(null);
        setStack((s) => [s[0], { name: 'Problems', params: { tour: results }, key: ++keySeq }]);
      } else {
        setTour({ ...tour, i });
        setStack((s) => [s[0], { name: tour.names[i], params: {}, key: ++keySeq }]);
      }
    }, 600);
    return () => clearTimeout(t);
  }, [tour]);

  const restored = () => {
    try { if (dbError && hasOpener()) reopenDatabases(); dbError = null; lastClose = null; } catch (e) { dbError = e; }
    setUser(null); setStack([]);
    setHealth({ phase: 'checking', state: null });
    setDbEpoch((n) => n + 1);
  };
  if (health.phase === 'damaged') {
    return (
      <SafeAreaProvider>
        <StatusBar style="dark" />
        <UIProvider>
          <DamagedScreen problem={health.problem} onRestored={restored} onContinue={dbError ? null : () => setHealth({ phase: 'ready', state: null })} />
        </UIProvider>
      </SafeAreaProvider>
    );
  }
  if (dbError) {
    return (
      <ScrollView contentContainerStyle={{ padding: 40 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.danger }}>The database could not be opened</Text>
        <Text style={{ fontSize: 18, marginTop: 10 }}>{String(dbError && dbError.message)}</Text>
      </ScrollView>
    );
  }

  const top = stack[stack.length - 1];
  const entry = top ? screens[top.name] : null;
  const allowed = entry && user && entry.can(user);
  const ScreenComponent = allowed ? entry.component : null;
  // The Bakery screens see each person through their bakery role (e.g. Owner -> Admin).
  const viewUser = user && entry && entry.bakery && !entry.shared ? { ...user, role: bakeryRole(user), realRole: user.role } : user;

  const openClock = () => { logout(); setKiosk(true); };
  const ctx = {
    user: viewUser, realUser: user, nav, logout, homeTab, setHomeTab, openClock, can: (p) => can(user, p),
    canGoBack: stack.length > 1,
    currentScreen: top || null,
    refresh: () => setTick((n) => n + 1),
    startScreenCheck,
    screens,
  };

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <ScaleContext.Provider value={scale}>
        <ScaleSetterContext.Provider value={changeScale}>
          <UIProvider>
            <AppContext.Provider value={ctx}>
              <View style={{ flex: 1, backgroundColor: C.bg }} onTouchStart={() => { lastTouch.current = Date.now(); }}>
                <TrainingFrame on={isTraining()} user={user}>
                <AlertWatcher user={user} tick={dbEpoch} />
                <FaceEngineHost on={moduleOn('timeclock') && usesMatching(faceSettings().mode) && (deviceSettings().clockHere || kiosk || (top && ['FaceEnrol', 'FaceTest'].includes(top.name)))} />
                {getSetting('device_blocked', '0') === '1' && !linking ? (
                  <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
                    <Text style={{ fontSize: 26, fontWeight: '800', color: C.danger, textAlign: 'center' }}>This device has been blocked</Text>
                    <Text style={{ fontSize: 18, color: C.text, textAlign: 'center', marginTop: 12 }}>The owner blocked it in Devices (for example because it was lost). Nothing can be opened until it is unblocked or linked again.</Text>
                    <Text style={{ fontSize: 18, color: C.primary, marginTop: 24 }} onPress={() => setLinking({ code: '' })}>Link this device again</Text>
                  </View>
                ) : health.phase === 'checking' ? (
                  <Splash subscribe={subscribeSplash} />
                ) : about && !user ? (
                  <AboutScreen standalone onClose={() => setAbout(false)} />
                ) : linking && !user ? (
                  <LinkScreen initialCode={linking.code} onDone={() => setLinking(null)} onBack={() => setLinking(null)} />
                ) : kiosk && !user ? (
                  <ClockKiosk onExit={() => setKiosk(false)} />
                ) : !user ? (
                  <LoginScreen onLogin={login} onClock={moduleOn('timeclock') ? () => setKiosk(true) : null} onLink={linkState().linked ? null : () => setLinking({ code: '' })} onAbout={() => setAbout(true)} />
                ) : ScreenComponent ? (
                  <ScreenGuard key={top.key} name={top.name} onBack={stack.length > 1 ? nav.pop : null} onHome={nav.home}
                    onError={(name, e) => { if (tour) tourFail.current[name] = String((e && e.message) || e); }}>
                    <ScreenComponent params={top.params || {}} />
                  </ScreenGuard>
                ) : (
                  <View style={{ padding: 40 }}>
                    <Text style={{ fontSize: 20 }}>You do not have access to this screen.</Text>
                    <Text style={{ fontSize: 20, color: C.primary, marginTop: 20 }} onPress={nav.home}>Go home</Text>
                  </View>
                )}
                {user && moduleOn('bakery') && can(user, 'bakery') ? <ScreenGuard name="Bakery reminder"><DueStepPopup /></ScreenGuard> : null}
                {tour ? (
                  <View pointerEvents="none" style={{ position: 'absolute', top: 8, left: 8, right: 8, alignItems: 'center' }}>
                    <Text testID="check-progress" style={{ backgroundColor: C.info, color: '#fff', fontSize: 16, fontWeight: '700', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20 }}>
                      Checking screens {tour.i + 1} of {tour.names.length}…
                    </Text>
                  </View>
                ) : null}
                <ErrorAlerts />
                </TrainingFrame>
              </View>
            </AppContext.Provider>
          </UIProvider>
        </ScaleSetterContext.Provider>
      </ScaleContext.Provider>
    </SafeAreaProvider>
  );
}
