// Easy Buys – one app for the whole business, built from modules (src/modules/registry.js).
// The Bakery app is the base: its database, look, offline storage, reports and cloud link are shared.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, BackHandler, ScrollView, AppState, useWindowDimensions, Linking, Platform } from 'react-native';
import { Text, ScaleContext, ScaleSetterContext } from './src/ui/scale.js';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaInsetsContext, useSafeAreaInsets } from 'react-native-safe-area-context';
import { openExpoDb } from './src/db/expoAdapter.js';
import { startDatabases, isTraining, reopenDatabases, hasOpener } from './src/platform/training.js';
import { AppContext, UIProvider } from './src/ui/components.js';
import { C } from './src/ui/theme.js';
import LoginScreen from './src/app/LoginScreen.js';
import DueStepPopup from './src/modules/bakery/screens/worker/DueStepPopup.js';
import ClockKiosk from './src/modules/timeclock/screens/ClockKiosk.js';
import LinkScreen from './src/modules/devices/screens/LinkScreen.js';
import { linkState } from './src/modules/devices/service.js';
import { FaceEngineHost } from './src/modules/timeclock/engineHost.js';
import { DocPreviewHost } from './src/ui/docPreview.js';
import { faceSettings } from './src/modules/timeclock/rules.js';
import { usesMatching } from './src/modules/timeclock/face.js';
import { deviceSettings } from './src/services/access.js';
import { allScreens } from './src/modules/registry.js';
import { moduleOn } from './src/modules/admin/service.js';
import { getSettings, getSetting, deviceId } from './src/services/core.js';
import { bakeryRole, getUiScale, setUiScale, can } from './src/services/access.js';
import { dailyChecks } from './src/services/stock.js';
import { setupNotifications, rescheduleReminders, setKeepAwake } from './src/platform/notify.js';
import { syncNow } from './src/platform/cloud.js';
import { deviceLock, LOCK_TEXT, overrideLock } from './src/modules/devices/control.js';
import { login as pinLogin, loginLockRemaining } from './src/services/catalog.js';
import { TextInput, Pressable } from 'react-native';
import { onSyncState } from './src/services/syncBus.js';
import { setWriteGuard } from './src/db/connection.js';
import { isViewOnly, viewOnlyGuard } from './src/services/access.js';
import { AppError } from './src/services/core.js';
import TutorialBar, { startTutorial, activeTutorial } from './src/ui/TutorialBar.js';
import { tourSeen } from './src/services/tutorials.js';
import { dailyLicenceCheck } from './src/modules/licences/service.js';
import { checkForUpdate } from './src/platform/updates.js';
import { notify } from './src/modules/verify/service.js';
import { ScreenGuard } from './src/ui/ErrorBoundary.js';
import { useUI } from './src/ui/components.js';
import { logError, onAppError, noteScreen, setErrorUser, markRunning, checkLastClose } from './src/services/errorLog.js';
import { Splash, DamagedScreen, AlertWatcher } from './src/ui/startup.js';
import { startQuickCheck, startFullCheck, fullCheckDue } from './src/services/health.js';
import { maybeSnapshot } from './src/services/snapshots.js';
import { freeDiskBytes } from './src/platform/device.js';
import { fileExists } from './src/platform/files.js';
import { AboutScreen } from './src/modules/admin/screens/AboutScreen.js';
import { checkFccc } from './src/modules/inventory/fccc.js';

// v3.9.3 look for a new FCCC master price list (every few hours, when online). Never stops the app.
// (Not in the web test build, which has no internet.)
function lookFccc() { if (Platform.OS === 'web' || (typeof navigator !== 'undefined' && navigator.product && navigator.product !== 'ReactNative')) return; try { checkFccc().catch(() => {}); } catch (e) { /* next time */ } }

let dbError = null;
let lastClose = null;
const splashProgress = new Set(); // listeners of the start-up check (the splash)
const subscribeSplash = (fn) => { splashProgress.add(fn); return () => splashProgress.delete(fn); };
try {
  startDatabases(openExpoDb);
  deviceId();
} catch (e) {
  dbError = e;
}
if (!dbError) {
  lastClose = checkLastClose();
  markRunning(true);
  try { dailyChecks(); } catch (e) { logError(e, { where: 'start-up checks' }); }
  try { if (moduleOn('licences')) dailyLicenceCheck(notify); } catch (e) { logError(e, { where: 'licence reminders' }); }
}

// Any error not caught elsewhere (for example inside a button) is written to the problem log and shown,
// instead of closing the app.
if (typeof globalThis !== 'undefined' && globalThis.ErrorUtils && globalThis.ErrorUtils.setGlobalHandler) {
  const prev = globalThis.ErrorUtils.getGlobalHandler ? globalThis.ErrorUtils.getGlobalHandler() : null;
  globalThis.ErrorUtils.setGlobalHandler((e, isFatal) => {
    try { logError(e, { where: isFatal ? 'app' : 'button', fatal: !!isFatal }); } catch (x) { /* ignore */ }
    if (typeof __DEV__ !== 'undefined' && __DEV__ && prev) prev(e, isFatal);
  });
}

// v3.9.3 a promise that fails with nobody waiting for it is written to the problem log too (never closes the app).
try {
  const H = globalThis.HermesInternal;
  if (H && H.enablePromiseRejectionTracker) H.enablePromiseRejectionTracker({ allRejections: true, onUnhandled: (id, e) => { try { logError(e instanceof Error ? e : new Error(String(e)), { where: 'promise' }); } catch (x) { /* ignore */ } } });
} catch (e) { /* not on this engine */ }

// The orange training bar sits below the phone's status bar; the screens under it then need no extra top space.
function TrainingFrame({ on, user, children }) {
  const insets = useSafeAreaInsets();
  if (!on) return children;
  return (
    <>
      <View testID="training-bar" style={{ backgroundColor: '#e67e22', paddingTop: insets.top + 6, paddingBottom: 6, paddingHorizontal: 12 }}>
        <Text style={{ color: '#fff', fontSize: 15, fontWeight: '800', textAlign: 'center' }}>
          TRAINING MODE – practice figures only, nothing is real or sent anywhere.{!user ? ' Practice PINs: Owner 5001 · Manager 5002 · Cashier 5003 · Assistant 5004' : ''}
        </Text>
      </View>
      <SafeAreaInsetsContext.Provider value={{ ...insets, top: 0 }}>{children}</SafeAreaInsetsContext.Provider>
    </>
  );
}

// Screens the screen check does not open (camera / face / linking / backup screens).
const CHECK_SKIP = /Face|Kiosk|Link|Camera|Scan|Backup|Restore|Problems/i;

// Shows problems that happened outside a screen (e.g. in a button) as a message.
function ErrorAlerts() {
  const ui = useUI();
  const last = useRef(0);
  useEffect(() => onAppError((entry) => {
    if (entry.where === 'screen') return; // the screen shows its own message
    if (Date.now() - last.current < 3000) return;
    last.current = Date.now();
    ui.alert({ title: 'Something went wrong', message: `${entry.message}\n\nThe app stayed open. This was written to Settings › Problem log.`, tone: 'danger' });
  }), [ui]);
  useEffect(() => {
    if (lastClose) {
      const where = lastClose.where;
      lastClose = null;
      ui.alert({ title: 'The app closed last time', message: `It closed unexpectedly${where ? ` on the screen "${where}"` : ''}. This was written to the problem log (Settings › Problem log).`, tone: 'warn' });
    }
  }, [ui]);
  return null;
}

let keySeq = 0;

export default function App() {
  const { width } = useWindowDimensions();
  const [scale, setScale] = useState(() => (dbError ? 1 : getUiScale(width)));
  const changeScale = useCallback((v) => { setUiScale(v); setScale(v === null ? getUiScale(width) : v); }, [width]);
  const [user, setUser] = useState(null);
  const [kiosk, setKiosk] = useState(false);
  const [linking, setLinking] = useState(null); // null, or { code } while the "Link to Easy Buys" screen is open
  const [stack, setStack] = useState([]);
  const [homeTab, setHomeTab] = useState(null);
  const [, setTick] = useState(0);
  const lastTouch = useRef(Date.now());
  const [tour, setTour] = useState(null); // screen check: { names, i }
  const tourFail = useRef({});
  const [dbEpoch, setDbEpoch] = useState(0);
  const screens = useMemo(() => (dbError ? {} : allScreens()), [dbEpoch]);
  const [about, setAbout] = useState(false); // About opened from the login screen (ⓘ)
  // Health check on opening (at most 4 seconds on the splash; the rest carries on in the background).
  const [health, setHealth] = useState(() => (dbError ? { phase: 'damaged', problem: `The database could not be opened: ${String(dbError && dbError.message)}` } : { phase: 'checking', state: null }));
  useEffect(() => {
    if (dbError) return undefined;
    let live = true;
    // Progress goes straight to the splash (not through App, so App does not redraw for every step).
    const run = startQuickCheck({ lastClose, freeDisk: freeDiskBytes }, { onStep: (st) => { splashProgress.forEach((fn) => fn({ ...st, results: st.results.slice() })); } });
    const settle = (st) => {
      if (!live) return;
      if (st.status === 'damaged') setHealth({ phase: 'damaged', problem: (st.results.find((r) => r.status === 'damaged') || {}).text });
      else setHealth((h) => (h.phase === 'damaged' ? h : { phase: 'ready', state: st }));
    };
    run.first.then((st) => { splashProgress.forEach((fn) => fn({ ...st, results: st.results.slice(), timedOut: !st.done })); setTimeout(() => settle(st), st.done ? 120 : 0); });
    run.all.then(settle).catch(() => {});
    return () => { live = false; };
  }, [dbEpoch]);

  const logout = useCallback(() => {
    setUser(null);
    setStack([]);
    setHomeTab(null);
  }, []);

  const login = useCallback((u) => {
    lastTouch.current = Date.now();
    setKiosk(false);
    setUser(u);
    setStack([{ name: 'Home', params: {}, key: ++keySeq }]);
  }, []);

  const nav = useMemo(() => ({
    push: (name, params = {}) => setStack((s) => s.concat([{ name, params, key: ++keySeq }])),
    pop: () => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)),
    replace: (name, params = {}) => setStack((s) => s.slice(0, -1).concat([{ name, params, key: ++keySeq }])),
    home: () => setStack((s) => s.slice(0, 1).map((x) => ({ ...x, key: ++keySeq }))),
  }), []);

  // Start-up: reminders, keep-awake, background sync every minute, daily checks.
  useEffect(() => {
    if (dbError) return undefined;
    setupNotifications().then(rescheduleReminders);
    setKeepAwake(getSettings().keepAwake);
    syncNow().catch(() => {});
    checkForUpdate().catch(() => {});
    const fcccFirst = setTimeout(lookFccc, 90000);
    const sync = setInterval(() => { syncNow().catch(() => {}); }, 60000);
    const daily = setInterval(() => { lookFccc(); try { dailyChecks(); } catch (e) { /* ignore */ } try { if (moduleOn('licences')) dailyLicenceCheck(notify); } catch (e) { /* ignore */ } }, 60 * 60000);
    // Safety copies every few hours while in use; the full health check once a night when the tablet is idle.
    const copies = setInterval(() => {
      maybeSnapshot().catch(() => {});
      try { if (fullCheckDue({ idleMinutes: (Date.now() - lastTouch.current) / 60000 })) startFullCheck({ freeDisk: freeDiskBytes, exists: fileExists }).all.catch(() => {}); } catch (e) { /* next time */ }
    }, 10 * 60000);
    setTimeout(() => { maybeSnapshot().catch(() => {}); }, 60000);
    const sub = AppState.addEventListener('change', (st) => {
      markRunning(st === 'active');
      if (st === 'active') {
        try { dailyChecks(); } catch (e) { /* ignore */ }
        rescheduleReminders();
        syncNow().catch(() => {});
        checkForUpdate().catch(() => {});
        setTick((n) => n + 1);
      }
    });
    return () => { clearTimeout(fcccFirst); clearInterval(sync); clearInterval(daily); clearInterval(copies); sub.remove(); };
  }, []);

  // Tapping an invite link (easybuys://link?c=...) in an email or message opens the link screen.
  useEffect(() => {
    if (dbError) return undefined;
    const open = (url) => {
      if (!url || !/^easybuys:\/\/link/i.test(url)) return;
      if (linkState().linked) return; // already linked: ignore stray taps
      setUser(null);
      setStack([]);
      setKiosk(false);
      setLinking({ code: url });
    };
    Linking.getInitialURL().then(open).catch(() => {});
    const sub = Linking.addEventListener('url', (e) => open(e && e.url));
    return () => sub.remove();
  }, []);

  // Android back button: one screen back (or out of the Time Clock).
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (linking) { setLinking(null); return true; }
      if (kiosk) { setKiosk(false); return true; }
      if (stack.length > 1) { nav.pop(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [stack.length, nav, kiosk, linking]);

  // Auto log-out when the device is left unattended (Admin can change the minutes).
  useEffect(() => {
    if (!user) return undefined;
    const t = setInterval(() => {
      if (Date.now() - lastTouch.current > getSettings().idleLogoutMin * 60000) logout();
    }, 30000);
    return () => clearInterval(t);
  }, [user, logout]);

  useEffect(() => { if (!dbError) rescheduleReminders(); }, [stack]);

  // Problem log: remember who is using the app and which screens were opened.
  useEffect(() => { setErrorUser(user); }, [user]);
  // The accountant login is view only: changes to business records are refused at the database.
  useEffect(() => {
    setWriteGuard(viewOnlyGuard(user));
  }, [user && user.uid, user && user.role]);
  const topName = stack.length ? stack[stack.length - 1].name : (kiosk ? 'Time Clock' : linking ? 'Link device' : 'Login');
  const topKey = stack.length ? stack[stack.length - 1].key : 0;
  useEffect(() => { if (!dbError) noteScreen(topName); }, [topName, topKey]);

  // Screen check: opens every screen for a moment and notes which ones have a problem.
  const startScreenCheck = useCallback(() => {
    if (!user) return;
    const names = Object.keys(screens).filter((n) => n !== 'Home' && !CHECK_SKIP.test(n) && screens[n].can(user));
    if (!names.length) return;
    tourFail.current = {};
    setTour({ names, i: 0 });
    setStack((s) => [s[0], { name: names[0], params: {}, key: ++keySeq }]);
  }, [screens, user]);
  useEffect(() => {
    if (!tour) return undefined;
    const t = setTimeout(() => {
      const i = tour.i + 1;
      if (i >= tour.names.length) {
        const results = tour.names.map((n) => ({ name: n, ok: !tourFail.current[n], message: tourFail.current[n] || '' }));
        setTour(null);
        setStack((s) => [s[0], { name: 'Problems', params: { tour: results }, key: ++keySeq }]);
      } else {
        setTour({ ...tour, i });
        setStack((s) => [s[0], { name: tour.names[i], params: {}, key: ++keySeq }]);
      }
    }, 600);
    return () => clearTimeout(t);
  }, [tour]);

  // Admin › Devices: "sign everyone out" from the owner, and a device locked by the owner logs out at once.
  const signedOutAt = useRef(getSetting('force_logout', ''));
  const lastLock = useRef('');
  useEffect(() => onSyncState(() => {
    let l = '';
    try { l = JSON.stringify(deviceLock()) + getSetting('force_logout', ''); } catch (e) { l = ''; }
    if (l !== lastLock.current) { lastLock.current = l; setTick((n) => n + 1); }
  }), []);
  useEffect(() => {
    if (dbError) return;
    const fl = getSetting('force_logout', '');
    if (fl && fl !== signedOutAt.current) { signedOutAt.current = fl; logout(); }
    let l = null;
    try { l = deviceLock(); } catch (e) { l = null; }
    if (l && user) logout();
  });

  // First-run tour, once per person (not during the automatic screen tests).
  useEffect(() => {
    if (dbError || !user) return;
    const testMode = typeof location !== 'undefined' && /[?&]dev=/.test(String(location.search || '')) && !/[?&]tour=1/.test(String(location.search || ''));
    if (testMode || activeTutorial()) return;
    try { if (!tourSeen(user)) setTimeout(() => startTutorial('tour'), 800); } catch (e) { /* no tour */ }
  }, [user && user.uid]);

  const restored = () => {
    try { if (dbError && hasOpener()) reopenDatabases(); dbError = null; lastClose = null; } catch (e) { dbError = e; }
    setUser(null); setStack([]);
    setHealth({ phase: 'checking', state: null });
    setDbEpoch((n) => n + 1);
  };
  if (health.phase === 'damaged') {
    return (
      <SafeAreaProvider>
        <StatusBar style="dark" />
        <UIProvider>
          <DamagedScreen problem={health.problem} onRestored={restored} onContinue={dbError ? null : () => setHealth({ phase: 'ready', state: null })} />
        </UIProvider>
      </SafeAreaProvider>
    );
  }
  if (dbError) {
    return (
      <ScrollView contentContainerStyle={{ padding: 40 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.danger }}>The database could not be opened</Text>
        <Text style={{ fontSize: 18, marginTop: 10 }}>{String(dbError && dbError.message)}</Text>
      </ScrollView>
    );
  }

  const top = stack[stack.length - 1];
  const entry = top ? screens[top.name] : null;
  const allowed = entry && user && entry.can(user);
  const ScreenComponent = allowed ? entry.component : null;
  // The Bakery screens see each person through their bakery role (e.g. Owner -> Admin).
  const viewUser = user && entry && entry.bakery && !entry.shared ? { ...user, role: bakeryRole(user), realRole: user.role } : user;

  let lock = null;
  try { lock = deviceLock(); } catch (e) { lock = null; }
  const openClock = () => { logout(); setKiosk(true); };
  const ctx = {
    user: viewUser, realUser: user, nav, logout, homeTab, setHomeTab, openClock, can: (p) => can(user, p),
    canGoBack: stack.length > 1,
    currentScreen: top || null,
    refresh: () => setTick((n) => n + 1),
    startScreenCheck,
    screens,
  };

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <ScaleContext.Provider value={scale}>
        <ScaleSetterContext.Provider value={changeScale}>
          <UIProvider>
            <AppContext.Provider value={ctx}>
              <View style={{ flex: 1, backgroundColor: C.bg }} onTouchStart={() => { lastTouch.current = Date.now(); }}>
                <TrainingFrame on={isTraining()} user={user}>
                <AlertWatcher user={user} tick={dbEpoch} />
                <FaceEngineHost on={moduleOn('timeclock') && usesMatching(faceSettings().mode) && (deviceSettings().clockHere || kiosk || (top && ['FaceEnrol', 'FaceTest'].includes(top.name)))} />
                {lock && !linking ? (
                  <View testID="device-locked" style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 }}>
                    <Text style={{ fontSize: 26, fontWeight: '800', color: C.danger, textAlign: 'center' }}>{(LOCK_TEXT[lock.kind] || LOCK_TEXT.blocked)[0]}</Text>
                    <Text style={{ fontSize: 18, color: C.text, textAlign: 'center', marginTop: 12 }}>{(LOCK_TEXT[lock.kind] || LOCK_TEXT.blocked)[1]}</Text>
                    {lock.until ? <Text style={{ fontSize: 18, color: C.text, marginTop: 8 }}>{lock.kind === 'ended' ? `Ended: ${lock.until}` : `Until: ${String(lock.until).replace('T', ' ').slice(0, 16)}`}</Text> : null}
                    {['blocked', 'suspended', 'ended'].includes(lock.kind) ? <Text style={{ fontSize: 18, color: C.primary, marginTop: 24 }} onPress={() => { syncNow().catch(() => {}).then(() => setTick((n) => n + 1)); }}>Check again</Text> : null}
                    {['removed', 'wiped', 'blocked'].includes(lock.kind) ? <Text style={{ fontSize: 18, color: C.primary, marginTop: 24 }} onPress={() => setLinking({ code: '' })}>Link this device again</Text> : null}
                    {['blocked', 'suspended', 'ended', 'removed'].includes(lock.kind) ? <OwnerUnlock onOpen={(u) => { setTick((n) => n + 1); login(u); }} /> : null}
                  </View>
                ) : health.phase === 'checking' ? (
                  <Splash subscribe={subscribeSplash} />
                ) : about && !user ? (
                  <AboutScreen standalone onClose={() => setAbout(false)} />
                ) : linking && !user ? (
                  <LinkScreen initialCode={linking.code} onDone={() => setLinking(null)} onBack={() => setLinking(null)} />
                ) : kiosk && !user ? (
                  <ClockKiosk onExit={() => setKiosk(false)} />
                ) : !user ? (
                  <LoginScreen onLogin={login} onClock={moduleOn('timeclock') ? () => setKiosk(true) : null} onLink={linkState().linked ? null : () => setLinking({ code: '' })} onAbout={() => setAbout(true)} />
                ) : ScreenComponent ? (
                  <ScreenGuard key={top.key} name={top.name} onBack={stack.length > 1 ? nav.pop : null} onHome={nav.home}
                    onError={(name, e) => { if (tour) tourFail.current[name] = String((e && e.message) || e); }}>
                    <ScreenComponent params={top.params || {}} />
                  </ScreenGuard>
                ) : (
                  <View style={{ padding: 40 }}>
                    <Text style={{ fontSize: 20 }}>You do not have access to this screen.</Text>
                    <Text style={{ fontSize: 20, color: C.primary, marginTop: 20 }} onPress={nav.home}>Go home</Text>
                  </View>
                )}
                {user && moduleOn('bakery') && can(user, 'bakery') ? <ScreenGuard name="Bakery reminder"><DueStepPopup /></ScreenGuard> : null}
                {user && !lock ? <ScreenGuard name="Tutorial"><TutorialBar user={user} nav={nav} /></ScreenGuard> : null}
                {tour ? (
                  <View pointerEvents="none" style={{ position: 'absolute', top: 8, left: 8, right: 8, alignItems: 'center' }}>
                    <Text testID="check-progress" style={{ backgroundColor: C.info, color: '#fff', fontSize: 16, fontWeight: '700', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20 }}>
                      Checking screens {tour.i + 1} of {tour.names.length}…
                    </Text>
                  </View>
                ) : null}
                <ErrorAlerts />
                <ScreenGuard name="Document preview"><DocPreviewHost /></ScreenGuard>
                </TrainingFrame>
              </View>
            </AppContext.Provider>
          </UIProvider>
        </ScaleSetterContext.Provider>
      </ScaleContext.Provider>
    </SafeAreaProvider>
  );
}

// v3.9.2 A locked device is never a dead end: the owner or an admin opens it with their own PIN. It then works on its own
// data; the cloud still refuses it (nothing syncs) until it is allowed again in Admin › Devices or the Google Sheet.
function OwnerUnlock({ onOpen }) {
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [msg, setMsg] = useState('');
  const go = () => {
    const wait = loginLockRemaining();
    if (wait) { setMsg(`Too many wrong PINs – wait ${Math.ceil(wait / 60)} minute(s).`); return; }
    let u = null;
    try { u = pinLogin(pin); } catch (e) { u = null; }
    setPin('');
    if (!u) { setMsg('Wrong PIN.'); return; }
    if (!['owner', 'admin'].includes(u.role)) { setMsg('Only the owner or an admin can open a locked device.'); return; }
    try { overrideLock(u); onOpen(u); } catch (e) { setMsg(e.message || String(e)); }
  };
  if (!open) return <Text testID="lock-owner" style={{ fontSize: 18, color: C.primary, marginTop: 24, fontWeight: '800' }} onPress={() => setOpen(true)}>Owner / admin: open it with your PIN</Text>;
  return (
    <View style={{ marginTop: 24, alignItems: 'center', gap: 10, width: '100%', maxWidth: 360 }}>
      <Text style={{ fontSize: 16, color: C.text, textAlign: 'center' }}>Owner or admin PIN. The device opens with its own data; nothing syncs until it is allowed again in Admin › Devices (on another device) or in the Google Sheet (Devices tab → active).</Text>
      <TextInput testID="lock-pin" value={pin} onChangeText={(v) => setPin(v.replace(/[^0-9]/g, ''))} keyboardType="number-pad" secureTextEntry maxLength={8} placeholder="PIN"
        style={{ fontSize: 24, borderWidth: 2, borderColor: C.border, borderRadius: 12, padding: 12, width: 200, textAlign: 'center', backgroundColor: '#fff' }} onSubmitEditing={go} />
      <Pressable testID="lock-open" onPress={go} style={{ backgroundColor: C.success, paddingVertical: 12, paddingHorizontal: 28, borderRadius: 12 }}><Text style={{ color: '#fff', fontSize: 18, fontWeight: '800' }}>Open</Text></Pressable>
      {msg ? <Text style={{ color: C.danger, fontSize: 16 }}>{msg}</Text> : null}
    </View>
  );
}
