# Easy Buys – one app for the whole business (v3.0)

Every rule, rate, list and permission is editable by the admin/owner (Admin › Roles, and each section's Rules screen).

Android app for tablets and phones, built on the Easy Buys Bakery app. Works fully offline and syncs
every linked device through the Easy Buys Google cloud. Each section is a separate module
(`src/modules/<name>`), listed in `src/modules/registry.js`, so one can be changed without touching the others.

| Module | What it does |
|---|---|
| Home | Tiles and alerts for what this person may use |
| Time Clock | Staff clock in/out on the shop tablet with PIN, photo and optional face check |
| Timesheets | Sat–Fri weeks, fixes with reasons, weeks ticked as checked |
| Leave | Requests, approvals, balances, leave types (admin-editable) |
| Staff | People, PINs, roles, shops, face enrolment |
| Payroll | Weekly pay runs (Sat–Fri, paid Saturday) from the timesheets and leave: normal, overtime, Sunday, public holiday, paid leave; PAYE (brackets + SRT), FNPF 8% / 10%; allowances, deductions, advances and staff loans; every line changeable with a reason before it is final; payslips, FNPF and PAYE reports, cash pay notes & coins |
| Invoices & cheques | Supplier invoices (photo, read by Google when online, or typed), VAT 12.5%, due soon / due / overdue flags, pay by BSP cheque, cash or transfer with a pay trail, credit notes, cheque books leaf by leaf (skipped numbers flagged), cleared cheques, balance check, regular bills and loans |
| Till & cash | End-of-shift till count note by note, Z report figures and photo, cash paid out, corrections with reasons, over/short with reason, manager approval; cash on hand at each shop; deposits (slip, cash, cheques, who banked it); petty cash |
| Bank reconciliation | Paste the BSP statement, lines match cheques / deposits / transfers by themselves, add fees and interest, finish when balanced |
| Bakery | Everything from Bakery v2 (production, stock, shifts, dashboard) |
| Admin | Roles and permissions, shops, Time Clock rules, modules on/off, change history |
| Devices | Add a tablet or phone (QR, email, WhatsApp), list devices, block a lost one |
| Sync | Sync status for every section and Force sync |

Every screen shows the sync status with a **Sync now** button, and the **Aa** button for text and button size.

## Install / update
The app updates the Bakery app in place (same app id `com.easybuys.bakerymanager`), keeping all bakery data.
Upload `EasyBuys.zip` to the GitHub repository; GitHub builds the `.apk` (Releases › Latest app).

## Cloud
One-time setup: see `CLOUD-SETUP.md`. After that, devices are added from Admin › Devices.

## Sample logins (new installs only)
Admin 1111, Sita 2222, Ravi 3333, Mere 4444. They stay on that device only and switch off on a linked
device once real staff arrive. On the shop tablet, make your own Owner login in Staff, then switch them off.

## Checks
`npm test` runs the upgrade-from-Bakery, module, device-linking and cloud checks (GitHub runs them on every build).
`tests/ui/` holds the screen tests used during development (Chromium).
