# How to work on Easy Buys v3.5 (for every builder)

Read `docs/v35-spec.md` first (the agreed features) and `README.md`. The owner is a non-programmer: all UI text is
plain, friendly English; no jargon on screen.

## Code layout
- Expo SDK 54 / React Native 0.81, offline SQLite through `db()` (`src/db/connection.js`): `db().run/get/all/exec`.
- Modules: `src/modules/<id>/index.js` exports `{ id, title, icon, switchable, screens, reports, ... }`; registered in
  `src/modules/registry.js`. Screen names are global and must be unique across modules.
- Screens get `{ nav, user, can, refresh }` from `useApp()` (`src/ui/components.js`). UI kit: `src/ui/components.js`,
  `src/ui/kit.js` (DateField, MoneyField, ListItem, Action/Actions, ReasonButton, Explain, Hint…), `src/ui/theme.js`.
- Permissions: `PERMS` and `DEFAULT_ROLE_PERMS` in `src/services/access.js`; check with `can(user, 'perm')`;
  `actsAsOwner(user)` for owner/admin power.
- Audit every change: `audit({ user, action, table, recordUid, before, after, reason })` from `src/services/core.js`.
- Settings: `getSetting/setSetting` (device) and `getShared/setShared` (synced business settings).
- New tables: put `CREATE TABLE IF NOT EXISTS …` SQL in your module (e.g. `src/modules/<id>/schema.js`) and add it to
  `src/db/moreSchemas.js` (`MORE_SQL` list + `MORE_SYNC` map). New columns on old tables: `src/db/columns.js`
  (`ensureColumns`). Synced tables need `uid`, `updated_at`, `updated_device`, `sync_status` and a SYNC entry
  (`SYNC(key, section, cols)`), see `moreSchemas.js`.
- Cloud jobs: `enqueue(kind, payload)` → handled in `src/platform/cloud.js` (`item.kind === …`) → posted to the Apps
  Script `cloud/Code.gs` (`case '…'`). Code.gs runs as the Easy Buys Google account. Never add a Google login on the
  device. Keep Code.gs backwards-compatible with v3.4 apps.
- Training mode uses a separate DB file; never sync in training mode (`trainingFlag`).
- Never write to Aronium. Aronium data arrives as imports (CSV now, Windows reader later).

## Shared helpers from wave 1 (exact — use them, don't re-invent)
- Inputs: `DateField`, `DateTimeField` (src/ui/dateField.js, re-exported from src/ui/kit.js), `TimeField`,
  `PeriodPicker`, `Select` (searchable), `Choice` (chips ≤5, drop-down >5) — see src/ui/kit.js / components.js;
  date helpers in `src/services/dates.js`. Scroll memory is automatic in `Screen`; filters/search: `useRemembered(name, initial)`
  from src/ui/components.js.
- Reasons: `reasonRequired(user)` and `needReason(user, reason, message)` in src/services/access.js. Owner/admin never
  need a reason; use these for every new reason prompt. `ReasonButton` already follows it.
- Menus: each module has `src/modules/<id>/menu.js` exporting `MENU = [{ section, items: [{ id, icon, title, note, screen,
  params, perm }] }]` (sections from `MENU_SECTIONS` in src/services/menus.js: Daily tasks, Records, Checks, Reports,
  Settings; first item id 'home' is the module's main screen), referenced as `menu: MENU` in index.js. Every new feature
  gets its own menu item. Menu item testIDs are `mi-<id>`; Home tiles open the module menu (UI flows tap
  `home-<module>` then `mi-<id>`).
- Warnings: `src/modules/<id>/alerts.js` exporting `alerts(user)` → `[{ id, level: 'urgent'|'warning'|'info', text, sub?,
  nav: { screen, params }, area, perm? }]`, referenced as `alerts` in index.js. Home/sounds/dashboard read them via
  `collectAlerts(user)` in src/services/alerts.js. Sounds are automatic for new alerts (src/services/sounds.js).
- Safety copies: `snapshotNow(reason)` from src/services/snapshots.js before risky steps (big imports, restores…).
- Cost areas: `listCostAreas()` in src/services/costAreas.js (S1, S2, OFFICE, CLOSED). Operating shops: `listShops()`.
- Health: src/services/health.js (`health_checks` table) — the watchdog reads it.
- Search: src/services/search.js (add your records' numbers/names if they should be findable from Home).
- About / version: src/services/about.js; APP_VERSION 3.5.0.

## Tests — must stay green
- Unit tests: `npm test` (runs `tests/run.mjs <file>` for each; esbuild + node:sqlite; libraries in
  `/opt/npm-tools/node_modules`). Add a test file per package `tests/<area>35.test.js` and add it to the `test`
  script in `package.json`. Follow the style of existing tests (`tests/harness.js`).
- UI flows: `node tests/ui/build.mjs && node tests/ui/flow1.mjs` … `flow7.mjs` (Playwright/Chromium, shims in
  `tests/ui/shim`). Add new flows where useful. In-app "Check every screen" tour (Admin › Problems) must pass.
- `node tests/exports-check.mjs` catches imported-but-not-exported names (the v3.3 crash cause).
- Native-only features (camera barcode scanning, on-device OCR, Bluetooth printing, SQLCipher, storage-access folder):
  put the native call behind a small `src/platform/*.js` wrapper with a safe fallback, add the dependency to
  `package.json`/`app.json` plugins if needed (versions compatible with Expo SDK 54), and test the logic with shims.

## Working rules
- Work only in your own git worktree/branch. Commit in small, clear commits. Never push. Never touch
  `/home/claude/ebsc-`.
- Don't rewrite working code unnecessarily; extend it. Keep shared-file edits small (access.js, moreSchemas.js,
  registry.js, cloud.js, Code.gs, package.json) to ease merging.
- Don't claim something is done unless it's implemented and tested. At the end report: what was built, files changed,
  shared files touched, new interfaces, test results, anything not done or only testable on a real device.

## Running tests in parallel with other builders (IMPORTANT)
Several builders work at the same time on one machine. Always give your test runs their own temp dir and port:
`export EB_TMP=/tmp/eb-<yourname> EB_PORT=<your port> RUNNER_TEMP=/tmp/eb-<yourname>; mkdir -p $EB_TMP` before
`npm test` / `node tests/ui/build.mjs` / `node tests/ui/flowN.mjs`. New UI test files must use `TMP`/`PORT` the same
way as the existing flows (first line of each flow file). Flows 1–9 use ports PORT+0…PORT+9; a new flow must use
PORT+10 or higher (e.g. `startServer({ port: PORT + 10 })`). Each builder gets its own EB_PORT range of 50.
