# Easy Buys v3.5 — agreed specification

Everything here was discussed and agreed with the owner (a non-programmer). Build all of it.
Plain-English UI text, Fiji context (FJD, VAT 12.5% standard, FRCS, FNPF, BSP bank, M-PAiSA wallets).
Pay week Sat–Fri, paid Saturday. Two operating shops: **S1 = Shop 1, 29 Drasa Avenue (includes the Bakery)**,
**S2 = Shop 2, Tukani Street (Kiran Palace)**. **Closed shop: V M Pillay** — not an operating shop; it only exists
as a whole-business cost area "Closed shop – V M Pillay" (its rent, loan, interest, power etc.).

Hard rules (never break):
- Never write to the Aronium database; the app only reads/imports Aronium data.
- Google cloud setup is one-off. Adding/linking devices never changes the cloud setup. The only allowed cloud step is
  pasting an updated `cloud/Code.gs` (same as previous releases). No Google login on tablets; the Apps Script (running
  as the dedicated Easy Buys Google account) is the only door. Devices use their own device key.
- Never delete business data; void/archive with history. Everything is audited (who, when, before/after).
- Offline first. Everything works without internet; cloud jobs go through the outbox.
- Every existing v3.4 feature keeps working. Existing tests must keep passing (update them only where behaviour was
  deliberately changed by this spec).
- **Owner/Admin never need to give a reason** anywhere: reason boxes are optional for them (still recorded if typed).
  Everyone else is still asked where a reason was required before. The change history always records who did what.
- **The admin can change everything** (rules, rates, lists, layouts, permissions). Settings live in Admin or in the
  module's Settings menu.

---------------------------------------------------------------------------------------------------
## A1 — Inputs and forms (foundation)
1. **Dates**: one `DateField` used everywhere. Pre-filled with the expected date; Today / Yesterday / Tomorrow buttons;
   calendar pop-up plus day/month/year drop-down columns, or type it; shown as "Tue 13 Oct 2026" (stored ISO
   yyyy-mm-dd as now). Validates as you go (no 31 Feb, warn if far in past/future).
2. **Times**: one `TimeField`: "Now" plus usual times (quick chips), analog clock picker (tap hour then minutes),
   or type. 12h/24h display set by admin (Admin › General). Validates as you go.
3. **Period drop-down** for reports and any date-range selection: Today, Yesterday, This week (Sat–Fri), Last week,
   This month, Last month, This year, Last year, Choose dates… (custom from/to with DateFields).
4. **Drop-downs**: any choice with more than ~5 options becomes a searchable drop-down (`Select`), 5 or fewer stay chips.
5. **Scroll position remembered** on every screen when going back (also filters and search text).
6. **Optional reasons for owner/admin** everywhere (timesheet edits, voiding pay runs, corrections, voids, overrides,
   PO edits after sending, etc.). One helper decides (`reasonRequired(user)`), used by services and `ReasonButton`.
7. **Training bar** respects the phone's safe area (sits below the status bar).

## A2 — App shell (foundation)
1. **Menus**: every feature is its own menu item inside its module, in the same section order everywhere:
   **Daily tasks, Records, Checks, Reports, Settings**. No hidden tabs. Modules declare their menu; a common
   `ModuleMenu` screen renders it. Same ordering on every module.
2. **Home**: a **search box** (finds screens, people, suppliers, invoices, POs, cheques, documents by number/name) and a
   **Scan** button (document barcodes → open that document/record if allowed; product barcodes → product info).
   Scanning respects role permissions.
3. **Home warnings**: every warning taps through to the exact place. Show the 3 most urgent plus "+x more" (opens full
   list). "Hide until tomorrow" on yellow (warning) and blue (info) ones only, never red. Modules provide warnings
   through one registry: `{ id, level: 'urgent'|'warning'|'info', text, nav: {screen, params}, perm }`.
4. **Sounds**: urgent (repeats until OK), warning (one chime), information (soft tone). Android alarm-style
   notification for urgent ones (Do Not Disturb permission requested for urgent). Admin settings per alert type,
   quiet hours (bakery alerts exempt), per-device choices.
5. **Sync now**: small sync icon on Home top bar + Admin › Sync. Pressing starts immediately and shows progress
   ("Sending 14 items…", "✓ All synced 3:45 pm", "✗ No internet – 14 items waiting", one-tap retry). Icon colour:
   green synced, amber waiting, red failing/too long. Blocked in training mode. Anyone may press it.
6. **Health check on open** (≤ 4 s hard limit, usually 1–2 s), shown as "Checking… ✓" on the splash: DB opens + SQLite
   `quick_check`; expected tables and schema version; settings and logins readable; clock sane (not earlier than last
   known time); free storage; snapshot/backup age; whether the app closed unexpectedly last time; items waiting to sync.
   If 4 s is reached the app opens and the rest continues in the background. Results: fine → silent; minor → amber
   Home note with tap-through; damaged DB → red screen offering to restore the latest good snapshot (owner/admin).
   **Full check** (integrity_check, books balance, change-history chain, every document file present, sync matches
   cloud) runs overnight / when idle & charging, and via "Run full check now" in Admin; results feed the watchdog.
7. **Local snapshots**: full DB copy every few hours while in use and before risky steps (app update, restore, year
   close, training mode on/off, big imports). Keep last 7 days + one per week for a month. Plus a daily copy to a
   folder outside the app (picked once via Android storage access, e.g. Documents/Easy Buys Backups) so an uninstall
   doesn't lose it. Admin › Backup & restore lists every copy (tablet, outside folder, Google Drive, later Windows PC)
   and restores any of them, making a safety copy first.
8. **About** (Admin › About and ⓘ on login): logo, "Easy Buys", version 3.5.0 (build 3), release date, "Built by Easy
   Buys Shopping Centre, Lautoka, Fiji", "© 2026 Easy Buys Shopping Centre. All rights reserved." (year range auto),
   business details from settings (registered name, address, TIN, phone, email), **Admin & support: Diptesh Avnil
   Prasad, +679 900 8193 (call / Viber), prasaddiptesh@gmail.com**, this device (name, ID, shop, linked, last sync,
   last backup, last health check, storage used), technical details (DB version, Android version, cloud script
   version), What's new (plain-words change list per version), Check for updates, Legal (confidential company property
   notice; open-source notices page). Login footer: "Easy Buys v3.5.0 · © 2026 Easy Buys Shopping Centre". Every
   PDF/report/printout footer: "Generated by Easy Buys app v3.5.0 · © Easy Buys Shopping Centre" (admin can turn off).
   Problem reports "Send to support" go to prasaddiptesh@gmail.com.
9. **Shops**: S2 renamed Tukani Street (was shown as "V M Pillay"). Third shop removed as operating shop (not in shop
   pickers, tills, rosters). Add **cost areas**: S1, S2, "Office / whole business", "Closed shop – V M Pillay". Closed
   shop costs show as their own line "Closed shop costs" in the combined P&L, dashboard and statements; never charged
   to S1/S2. Existing V M Pillay loan/rent recurring items move to the closed shop. Kiran Palace loan/rent belong to S2.

---------------------------------------------------------------------------------------------------
## B1 — Bank, cash and M-PAiSA
- Bank reconciliation shows **two balances**: "In the bank now" and "Expected balance" (after unpresented cheques and
  uncleared deposits).
- Unpresented cheques highlighted amber, red after the "Verification days" setting, "stale" after 6 months. Deposits
  not yet cleared highlighted the same way.
- Marking a cheque presented from the cheque module needs no second check (records who + cleared date).
- **History** tab with running balance and cleared marks; search; reconciliation report (PDF/Excel).
- **"Check against mobile banking"**: type today's balance from the BSP app → matches, or shows the difference with
  likely causes; history of checks; Home reminder after admin-set days (default 3, can be switched off) in Admin ›
  Bank rules.
- One BSP account only. Lines tagged by shop.
- **Two M-PAiSA wallets** (one per shop) as money accounts: till M-PAiSA sales go into that shop's wallet; transfers
  to BSP and fees recorded; a check against the M-PAiSA app per wallet. MyCash wallet can be added by admin later.
- EFTPOS: not used yet; an expected-settlement option for later (switched off).
- Flow: till balances record each payment method; cash on hand per shop; deposits come off cash on hand and appear in
  bank rec as "in transit" until cleared.
- **Bank statement import** (BSP CSV/OFX, PDF text, pasted text): 1 clears cheques automatically, 2 confirms deposits
  (flags slip differences), 3 confirms M-PAiSA transfers, 4 finds lines missing from the app (one-tap record; rules
  remember the payee/category), 5 matches loan repayments, 6 books fees and interest, 7 flags unknown cheques,
  8 flags duplicates, 9 flags unusual items, 10 feeds real figures into the cash forecast, 11 bank charges report,
  12 statement archive (documents). Part of **month-end closing**: full-month statement needed, balance must equal the
  statement, every line sorted, warnings reviewed, then the reconciliation report is saved. Imports allowed mid-month.
- **M-PAiSA statement import** (CSV, Excel, PDF, screenshot via OCR when online): match each shift's M-PAiSA sales to
  wallet receipts (catches fake payment messages), transfers and fees; part of month end. Format will be fine-tuned
  later with a real statement, so make the column mapping configurable.

## B2 — Cheques, invoices and supplier statements
- **Photo of invoice / cheque**: supplier drop-down (or type a new one → flagged "add properly"); PO drop-down after
  choosing supplier.
- **Cheque handed over**: supplier → cheque drop-down (cheques already written for them + next unused number) or type
  any number, with checks (already used, not in any book, typed-not-recorded → To verify); tick the supplier's unpaid
  invoices; skipped numbers still flagged. Customer cheque received stays free text.
- **"Cheque books & stubs"** own menu item: book serial, leaf range, date received, who holds it, status; each leaf
  opens its stub record (date, payee, amount, invoices, who wrote it, who received it, stub photo (optional, flagged
  missing until added), cleared date); cheque book report.
- **Supplier statement** per supplier: period drop-down; opening balance; invoices and credits; payments with cheque
  number and dates written / handed over / presented; running balance; closing balance split not due / due / overdue;
  "what we owe" vs cheques not yet presented. PDF/Excel/share; the supplier statement check sits next to it.

## B3 — Purchasing, suppliers and products
- **Purchase orders editable**: before sending fully editable; after sending editable (approvers only) with optional
  reason (required for non owner/admin) and an "Amended" PDF offered to the supplier; after receiving: dates, notes,
  new lines, and qty/cost of what hasn't arrived can change; delivered quantities are corrected from the delivery.
- **Supplier order schedules**: per supplier order days, cut-off time per day, delivery day, reminder lead time; one
  schedule with per-shop changes. Reminders: phone notification to that shop's manager and the owner; Home warning
  opening a new PO with suggested quantities; no reminder if already sent; missed cut-off in red; "Today's orders" list.
  (Viber reminders deferred.)
- **Barcode scanning into POs** (also receiving and stock take): continuous camera; after each scan ask quantity (big
  number pad); product not found → "Add it in Aronium first"; different-supplier warning; handheld (keyboard-wedge)
  scanners supported.
- **Supplier CSV import from Aronium**: match by TIN then name; Aronium details win; app-only fields kept; customers
  skipped. Products (with all barcodes, groups, units, tax, prices incl. wholesale) import the same way (CSV for now;
  later the Windows reader). Products deleted in Aronium are hidden not deleted. Inventory per shop; stock goes down only
  via Aronium sales import; freeze during stock take.
- **Invoice reading**: offline on the tablet (on-device text recognition) with cloud OCR as backup; learns each
  supplier's layout from corrections; reads item lines, matches to PO and delivery, flags cost changes.

## B4 — Till, shifts, who owes us, dashboard
- **One till balance per till per shift** (2–3 shifts a day; one cashier per till per shift). The next shift can't start
  until the previous is balanced, unless the **owner** continues it; the End of day (Z number + total) must still be
  recorded and the shift stays flagged until counted.
- **Aronium matched to each shift's Z**: differences flagged straight away (red mark, Home, To verify, notification);
  explanation required except owner/admin; unresolved at month end → VAT return uses Aronium's figure and the
  month-end checklist flags it. An Aronium End of day with no till balance → red.
- **Remove booking Aronium sales when there's no till balance** (replace with a "till balance missing" warning).
  Aronium used for VAT split, products sold, department sales; cash and banking from the till balance.
- **Two signatures on each till balance** (cashier + balancer chosen from drop-downs). Same person may do both only if
  owner/admin or has permission "May run and balance their own till".
- **Shortage agreement**: cashier agrees and signs (optionally in parts, i.e. instalments) or disagrees (goes to a
  manager). Agreed shortages are added to the pay run automatically, highlighted, and shown as a separate payslip line.
  Undecided ones show red in the pay run.
- **Who owes us**: Aronium staff credit (imported balances) + app advances, loans, charges; ageing; a page per person;
  PDF statement. Pay day: each staff credit deduction needs an Aronium settlement receipt photo; warning until done.
  Per-person credit limits set by admin with an "approaching" threshold (amber/red); warnings on Home, person page,
  notifications.
- **Dashboard**: period and shop selectors. Cards: sales, money now, profit, who owes us, what we owe, tax due, stock,
  staff, till checks, licences, compliance health, watchdog, owner's drawings, closed shop costs. Each person chooses and
  orders their cards; admin controls which roles see which cards (all for owner/admin; limited for managers).

## B5 — Payroll, pay sign-off, tax & statutory
- **Pay cycle fully flexible — admin can change everything**: pay week start, pay day, frequency, one-off extra pay
  runs (bonus, back pay), reopen and correct a finalised run (owner/admin), rates/rules/deductions. All logged; voiding
  a pay run needs no reason from owner/admin.
- **Pay sign-off**: a Home tile and Payroll daily task; roles allowed set by admin. **Employee view** locked to that
  person's payslip; leaving needs the admin's PIN. Sign, or "Something is wrong". Not signed = not released (owner/admin
  can override, recorded). After signing: automatic email (if address) and/or one-tap Viber share (Viber first);
  printing optional; Payroll setting automatic / ask / don't send. The on-screen payslip for signing is always the
  full, exact payslip.
- **FNPF / PAYE per person**: on/off with a note; partial: fixed amount per week, % of gross, or only certain pay kinds
  (overtime, bonus, allowances). Payslip shows "pay counted for FNPF/PAYE". Only owner/admin can change; hint to
  confirm with accountant/FNPF/FRCS. FNPF rates remain admin settings.
- Agreed till shortages and staff credit deductions appear as their own payslip lines (from B4).
- **Tax & statutory calendar**: admin sets due rules, reminder lead and responsible person for VAT, FNPF, PAYE / pay day
  reporting, provisional tax, advance tax, company tax. Warnings on dashboard, Home, notifications with sounds.
- **Two proofs per period: lodgement and payment**: lodged-not-paid red, paid-not-lodged red, proof missing amber,
  overdue urgent; month-end checklist blocks until both are in (owner/admin can override); history for audit.
- **Filing formats**: admin uploads official FRCS/FNPF templates (Excel/CSV) and maps columns; until then PDF/Excel/CSV
  copies with pre-filing checks; weekly pay day report combining both shops.

## B6 — Loans, rent, personal costs and drawings
- Regular payments with reminders and a required receipt (flag if missing): loans for 3 shops (V M Pillay closed) and
  2 car loans (PB 113 Credit Corp, ON 485 BSP); rent for 3 shops (V M Pillay closed) and home rent; household grocery
  shopping reminders.
- **Loan journey**: price, deposit, principal, fees, each repayment split interest/principal, arrears and missed
  payments flagged, **optional arrears fee rule per loan** (fixed / % / none, otherwise typed in), balance after every
  line, chart down to zero, payoff date. Keep it simple: payments made, balance remaining, invoice/receipt numbers.
- **Loan statement reconciliation**: upload the lender's statement, enter its balance/interest/fees, compare, one-tap
  fixes, "last reconciled" date.
- **Owner's money**: mixed expenses with a business share % (business part to expenses with VAT where allowed; personal
  part to drawings or money put in); hint to agree the % with the accountant.
- **Drawings**: "Take money out", "Business paid for me", "Put money in"; per owner or several family members (admin
  setting); totals on dashboard and statements; never through payroll.
- Closed shop costs as in A2.9. The watchdog compares loan rates/fees with normal practice (B10).

## B7 — Licences safeguard, vehicles & equipment, bakery
- **Licences as the business's safeguard**: responsible person + backup (owner default); escalating reminders
  90/60/30/14/7/1 days, owner included from 30 days, urgent sound from 7 days, expired shown daily to all managers;
  owner signs off each renewal; renewal checklist per licence type; document safe (nothing deleted, "No current copy"
  flag, kept on device and Drive); inspection pack PDF per shop; licence conditions with optional ticks; compliance
  health card; monthly compliance report. **Only owner/admin add/edit**; others view.
- **Vehicles & equipment** (sub-menu under Licences): register vehicles (rego, km) and equipment (types editable by
  admin, sensible defaults); links to loan, fixed asset, insurance; documents; due items by date or km/hours with
  reminders; service & repair history with costs linked to invoices; fault reporting with out-of-use time (merge the
  bakery's equipment faults here); **fuel log by km** with km/litre and flags; daily checks built but **off** by a
  toggle; running-cost reports. **Fuel entered once goes everywhere**: expense "Transport & fuel" for the vehicle's
  shop, input VAT when tax invoice, paid from cash or M-PAiSA, appears in bank rec if relevant. Fuel card later as a
  money account. Inspection intervals admin-set.
- **Bakery**: remove the bakery's own staff sign-on/hours (use main Time Clock). Bakery shift stays, started by the baker
  after confirming opening stock; no staff list; close with the balance. **Proofing table per product** (yeast amount →
  minutes, interpolated between rows); yeast measured per kg of flour by default, per batch as admin option.
  **Temperature adjustment**: Hot / Normal / Cool with admin-set minutes and thresholds.

## B8 — Documents, printing, barcodes, Drive and backups
- **Document designer** (every document type: payslip, PO, reports, statements, receipts, contracts covers…): toggle each
  part, reorder, rename labels, free text with placeholders, add fields, logo and look, A4/A5/80 mm, live preview,
  versions and reset.
- **80 mm thermal layout** plus PDF; Print on every report and document (system print; Bluetooth ESC/POS where
  available).
- **Barcodes on all company documents** (Code 128 of the document reference; QR available but switched off); "Scan a
  document" check that shows "✓ genuine" (matches a record in the app) or "✗ not found / changed".
- **Payslip**: on-screen signing version always full; printed/sent version follows admin toggles; gross, each deduction
  and net on by default – turning them off shows a warning, a ⚠️ marker and is logged; separate settings for 80 mm and
  PDF.
- **Preview before sending, saving or printing for every document** (zoom, pages, change options, then Send / Save PDF /
  Excel / Print / Close). Payment PDFs and Viber prompts open the preview first.
- **Drive documents**: every finished document filed to Drive in a tidy structure (Supplier invoices/Year/Month,
  Purchase orders, Delivery dockets, Sales & receipts, Bakery, Reports, Payroll – Restricted, Licences, Vehicles,
  Backups); upload verified (size + SHA-256), idempotent (unique upload id, no duplicates on retry), status per file
  (pending, uploading, verified, failed–retry, login needed) shown next to Sync now; tablet copy cleared only after
  verification and after an admin-set retention (default 90 days), fetched on demand; searchable metadata (type,
  supplier/employee, number, shop, date, amount, Drive id, size, status, who, timestamps, access class).
- **Document visibility is an admin setting**: per document type, the admin ticks which roles can see it. The cloud
  script enforces the same rule (role checked server-side before `file_get`).
- **Backups**: nightly full backup from the main tablet to Drive › Backups (daily kept 30 days, monthly kept 12 months)
  plus a file manifest; restore a new/replaced tablet (data + needed files) in a few steps; tested.
- Windows software later keeps a full mirror (prepare API: list files since X, fetch file).

## B9 — Roster and My day
- **Roster**: week grid (people × days, colour-coded) with hours and cost; paint mode, tap menu, copy last week / usual
  week / a day to other days, swap two people, long-press copy; staff needed per shift; warnings; undo; today/tomorrow
  changes highlighted and staff told; share as picture/PDF (Viber/WhatsApp); phone view one day at a time.
  **Flexible to any change, and when a change isn't possible it suggests alternatives** (swap with X, move time, Y is
  free, or "Allow anyway" for owner/admin) — clashes: leave, hour limits, rest, double shift, short-staffed.
- **My day** (owner & admin): timeline with working hours per weekday (7 days, different hours); app tasks placed
  automatically before their deadlines (orders before cut-offs, approvals, checks, pay day, tax, licences, month end,
  watchdog flags) with admin-set durations; own items (meetings, errands, repeating); fixed items never move; no
  overlaps; unfinished tasks move to next free slot; if moving would miss a deadline → red + urgent; drag to change;
  "Not today"; "Skip"; tapping a task opens its screen and it ticks itself off; reminders with sound.
  **Google Calendar: yes** — meetings come in from the Easy Buys account's calendar; app tasks go out to a separate
  "Easy Buys – My day" calendar (via the cloud script). Visibility: managers see business tasks read-only; staff see
  busy/free only; private items show as "Busy".

## B10 — Watchdog (offline, no AI service)
- Main on/off switch (owner/admin, logged) + strength: Off / Light / Normal (default) / Strict; per-check
  on/off/sensitivity under that. While off, owner sees a grey "Watchdog off" note on Home. **Tampering and
  system-health checks keep running quietly for the owner even when off.**
- Daily report. Completeness (missing till balances, deposits, invoice photos, TINs, proofs, receipts…), system health
  (books balance, integrity, sync, backups, problem log, nightly screen check, storage), tampering (edits after the
  event, back-dating, supplier bank account changes, people changing their own records, voids/overrides, odd hours,
  reopened periods, new devices, PIN attempts, clock changes, changes outside the app via check-codes, **chained
  fingerprinted change history**; tampering warnings shown to owner only), learns normal (8–12 weeks: far above/below,
  never seen, slow drift; "This is fine" teaches it), advice with every flag (likely reasons, steps to fix, buttons
  that go there, who should do it, "Fixed"/"This is fine", history), timesheet watch (missing clock-outs, not rostered,
  no-shows, late/early patterns, breaks, face check, buddy punching, paid more than clocked, overtime, hour limits and
  rest, leave/holidays, wages % of sales, edits after the event, people editing their own timesheet), compares with
  normal business practice (VAT/TIN, FNPF/PAYE/minimum wage, loan rates, depreciation lives, margins, wages/rent/power %
  of sales, shrinkage, bakery yield, cash shortages, days to pay, stock turnover, segregation of duties, cash not
  banked, drawings vs profit, personal expenses without business share; benchmarks built in and admin-editable; own
  history becomes the main comparison).

## C1 — Tablet encryption
- Encrypt the on-device database (SQLCipher via expo-sqlite) with a key kept in Android secure storage; migrate the
  existing database with a full backup/snapshot first; restore path tested; training DB too.
