import { registerRootComponent } from 'expo';
import App from './App';
// v3.9.6 background sync: the task must be known before Android can run it (also when the app is closed).
import './src/platform/background.js';

registerRootComponent(App);
