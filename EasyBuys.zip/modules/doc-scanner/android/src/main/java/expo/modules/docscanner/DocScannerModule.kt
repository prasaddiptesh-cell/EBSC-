package expo.modules.docscanner

import android.app.Activity
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import expo.modules.kotlin.Promise
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

// Google's document scanner: the camera finds the paper's edges and takes it by itself, crops it straight, and lets the
// person drag the corners, rotate it or add pages before tapping Done. Answers the pages as JPEG file uris
// (or an empty list when the person backs out). Every failure is a rejected promise – the app then takes a plain photo.
class DocScannerModule : Module() {
  private var pending: Promise? = null
  private val REQ = 7341

  override fun definition() = ModuleDefinition {
    Name("DocScanner")

    AsyncFunction("scan") { pages: Int, gallery: Boolean, promise: Promise ->
      val activity: Activity? = appContext.currentActivity
      if (activity == null) { promise.reject("E_NO_SCREEN", "The app screen is not ready", null); return@AsyncFunction }
      if (pending != null) { promise.reject("E_BUSY", "The scanner is already open", null); return@AsyncFunction }
      try {
        val options = GmsDocumentScannerOptions.Builder()
          .setGalleryImportAllowed(gallery)
          .setPageLimit(if (pages in 1..20) pages else 1)
          .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
          .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
          .build()
        pending = promise
        GmsDocumentScanning.getClient(options).getStartScanIntent(activity)
          .addOnSuccessListener { sender ->
            try {
              activity.startIntentSenderForResult(sender, REQ, null, 0, 0, 0)
            } catch (e: Throwable) {
              pending = null
              promise.reject("E_START", e.message ?: "The scanner did not open", e)
            }
          }
          .addOnFailureListener { e ->
            pending = null
            promise.reject("E_UNAVAILABLE", e.message ?: "The scanner is not available on this device", e)
          }
      } catch (e: Throwable) {
        pending = null
        promise.reject("E_UNAVAILABLE", e.message ?: "The scanner is not available on this device", e)
      }
    }

    OnActivityResult { _, payload ->
      if (payload.requestCode != REQ) return@OnActivityResult
      val p = pending ?: return@OnActivityResult
      pending = null
      try {
        if (payload.resultCode != Activity.RESULT_OK || payload.data == null) { p.resolve(emptyList<String>()); return@OnActivityResult }
        val result = GmsDocumentScanningResult.fromActivityResultIntent(payload.data)
        val uris = result?.pages?.map { it.imageUri.toString() } ?: emptyList()
        p.resolve(uris)
      } catch (e: Throwable) {
        p.reject("E_RESULT", e.message ?: "The scan could not be read", e)
      }
    }
  }
}
