// Easy Buys local native module (Android only). The app reads it through src/platform/photos.js, which works without it
// (web test build, older apps): it then takes a normal photo and offers the crop box after it.
export function nativeDocScanner() {
  try {
    const m = globalThis.expo && globalThis.expo.modules ? globalThis.expo.modules.DocScanner : null;
    return m || null;
  } catch (e) { return null; }
}
