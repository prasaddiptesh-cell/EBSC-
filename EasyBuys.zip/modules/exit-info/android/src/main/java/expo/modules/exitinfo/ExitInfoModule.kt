package expo.modules.exitinfo

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

// Why did the app close last time? Android (11 and newer) keeps the last few reasons for each app.
// Every call is safe: on older Android, or when Android says no, the answer is empty.
class ExitInfoModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("ExitInfo")

    Function("getExitReasons") { max: Int ->
      readExits(if (max in 1..16) max else 5)
    }

    Function("getMemory") {
      readMemory()
    }

    Function("getNetwork") {
      readNetwork()
    }
  }

  private fun ctx(): Context? = try { appContext.reactContext?.applicationContext } catch (e: Throwable) { null }

  private fun readExits(max: Int): List<Map<String, Any?>> {
    if (Build.VERSION.SDK_INT < 30) return emptyList()
    val c = ctx() ?: return emptyList()
    return try {
      val am = c.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return emptyList()
      am.getHistoricalProcessExitReasons(c.packageName, 0, max).map { info ->
        val m = HashMap<String, Any?>()
        m["reason"] = info.reason
        m["status"] = info.status
        m["timestamp"] = info.timestamp.toDouble()
        m["description"] = info.description ?: ""
        m["importance"] = info.importance
        m["pss"] = info.pss.toDouble()
        m["rss"] = info.rss.toDouble()
        m["processName"] = info.processName ?: ""
        m["pid"] = info.pid
        // 4 = REASON_CRASH (Java), 6 = REASON_ANR (not answering): the first 4 KB of the text traces.
        // 5 = REASON_CRASH_NATIVE gives a binary tombstone: not read.
        if (info.reason == 4 || info.reason == 6) m["trace"] = readTrace(info)
        m
      }
    } catch (e: Throwable) {
      emptyList()
    }
  }

  private fun readTrace(info: android.app.ApplicationExitInfo): String {
    return try {
      val s = info.traceInputStream ?: return ""
      s.use { input ->
        val buf = ByteArray(4096)
        var n = 0
        while (n < buf.size) {
          val r = input.read(buf, n, buf.size - n)
          if (r <= 0) break
          n += r
        }
        String(buf, 0, n, Charsets.UTF_8)
      }
    } catch (e: Throwable) {
      ""
    }
  }

  private fun readMemory(): Map<String, Any?> {
    val m = HashMap<String, Any?>()
    try {
      val c = ctx() ?: return m
      val am = c.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return m
      val mi = ActivityManager.MemoryInfo()
      am.getMemoryInfo(mi)
      m["availMem"] = mi.availMem.toDouble()
      m["totalMem"] = mi.totalMem.toDouble()
      m["lowMemory"] = mi.lowMemory
      m["memoryClassMb"] = am.memoryClass
      val rt = Runtime.getRuntime()
      m["javaUsed"] = (rt.totalMemory() - rt.freeMemory()).toDouble()
      m["javaMax"] = rt.maxMemory().toDouble()
    } catch (e: Throwable) { /* not known */ }
    return m
  }

  private fun readNetwork(): String {
    return try {
      val c = ctx() ?: return ""
      val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return ""
      if (Build.VERSION.SDK_INT < 23) return ""
      val n = cm.activeNetwork ?: return "none"
      val caps = cm.getNetworkCapabilities(n) ?: return "unknown"
      when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "cable"
        else -> "other"
      }
    } catch (e: Throwable) {
      ""
    }
  }
}
