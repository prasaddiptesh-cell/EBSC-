// Easy Buys local native module (Android only). The app reads it through src/services/exitInfo.js, which works
// without it (web test build, older apps, iPhone): it then answers null.
export function nativeExitInfo() {
  try {
    const m = globalThis.expo && globalThis.expo.modules ? globalThis.expo.modules.ExitInfo : null;
    return m || null;
  } catch (e) { return null; }
}
