// Build step: packs the offline face engine into the Android app.
// Copies face/index.html, face-api.js and the three model files it needs into
// android/app/src/main/assets/face/ when `expo prebuild` runs (GitHub does this).
const fs = require('fs');
const path = require('path');

const MODELS = [
  'tiny_face_detector_model-weights_manifest.json', 'tiny_face_detector_model.bin',
  'face_landmark_68_tiny_model-weights_manifest.json', 'face_landmark_68_tiny_model.bin',
  'face_recognition_model-weights_manifest.json', 'face_recognition_model.bin',
];

function copyFaceFiles(projectRoot, androidRoot) {
  const pkg = path.join(projectRoot, 'node_modules', '@vladmandic', 'face-api');
  const out = path.join(androidRoot, 'app', 'src', 'main', 'assets', 'face');
  fs.mkdirSync(path.join(out, 'model'), {recursive: true});
  fs.copyFileSync(path.join(projectRoot, 'face', 'index.html'), path.join(out, 'index.html'));
  fs.copyFileSync(path.join(pkg, 'dist', 'face-api.js'), path.join(out, 'face-api.js'));
  MODELS.forEach((m) => fs.copyFileSync(path.join(pkg, 'model', m), path.join(out, 'model', m)));
  return out;
}

module.exports = function withFaceAssets(config) {
  const {withDangerousMod} = require('expo/config-plugins');
  return withDangerousMod(config, ['android', async (cfg) => {
    const out = copyFaceFiles(cfg.modRequest.projectRoot, cfg.modRequest.platformProjectRoot);
    console.log('Face engine packed into ' + out);
    return cfg;
  }]);
};
module.exports.copyFaceFiles = copyFaceFiles;
module.exports.MODELS = MODELS;
