// Build step (1.0.0 hardening, audit H4): the app's database (logins, pay, bank details, the device's cloud pass) is
// never copied off the phone by Android – not to a Google account backup and not to a new phone in a device transfer.
// app.json sets android.allowBackup false (Expo writes android:allowBackup="false"); this adds, for Android 12 and up,
// data extraction rules that exclude everything from cloud backup AND device-to-device transfer, and the old
// fullBackupContent switch for Android 6–11.
const fs = require('fs');
const path = require('path');

const RULES_XML = `<?xml version="1.0" encoding="utf-8"?>
<!-- Easy Buys: nothing is backed up or transferred (the database holds logins, pay and bank details). -->
<data-extraction-rules>
  <cloud-backup>
    <exclude domain="root" path="." />
    <exclude domain="file" path="." />
    <exclude domain="database" path="." />
    <exclude domain="sharedpref" path="." />
    <exclude domain="external" path="." />
  </cloud-backup>
  <device-transfer>
    <exclude domain="root" path="." />
    <exclude domain="file" path="." />
    <exclude domain="database" path="." />
    <exclude domain="sharedpref" path="." />
    <exclude domain="external" path="." />
  </device-transfer>
</data-extraction-rules>
`;

// The <application> attributes (pure: tested in tests/noBackup-check.mjs without Expo).
function setNoBackup(manifest) {
  const root = manifest.manifest || manifest;
  root.$ = root.$ || {};
  if (!root.$['xmlns:tools']) root.$['xmlns:tools'] = 'http://schemas.android.com/tools';
  const app = (root.application || [])[0];
  if (!app) throw new Error('withNoBackup: no <application> in AndroidManifest.xml');
  app.$ = app.$ || {};
  app.$['android:allowBackup'] = 'false';
  app.$['android:fullBackupContent'] = 'false';
  app.$['android:dataExtractionRules'] = '@xml/eb_no_backup';
  const keep = String(app.$['tools:replace'] || '').split(',').map((x) => x.trim()).filter(Boolean);
  for (const a of ['android:allowBackup', 'android:fullBackupContent', 'android:dataExtractionRules']) if (!keep.includes(a)) keep.push(a);
  app.$['tools:replace'] = keep.join(',');
  return manifest;
}
function writeRules(androidRoot) {
  const dir = path.join(androidRoot, 'app', 'src', 'main', 'res', 'xml');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'eb_no_backup.xml');
  fs.writeFileSync(file, RULES_XML);
  return file;
}

module.exports = function withNoBackup(config) {
  const { withAndroidManifest, withDangerousMod } = require('expo/config-plugins');
  config = withAndroidManifest(config, (cfg) => { setNoBackup(cfg.modResults); return cfg; });
  return withDangerousMod(config, ['android', async (cfg) => { writeRules(cfg.modRequest.platformProjectRoot); return cfg; }]);
};
module.exports.setNoBackup = setNoBackup;
module.exports.writeRules = writeRules;
module.exports.RULES_XML = RULES_XML;
