import React, { useState } from 'react';
import { loginBlockedHere, noteLogin } from '../modules/devices/control.js';
import { View, ScrollView, Image, Pressable } from 'react-native';
import { Text } from '../ui/scale.js';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from '../ui/theme.js';
import { PinPad, Btn, Field, Chips, useLayout, useTick, LOGO } from '../ui/components.js';
import { login, loginWithPassword, loginLockRemaining, hasLongerPin, pinMatches } from '../services/catalog.js';
import { getSettings, clock, hhmm } from '../services/core.js';
import { deviceSettings } from '../services/access.js';
import { moduleOn } from '../modules/admin/service.js';
import { sampleLoginsActive } from '../modules/devices/service.js';
import { isTraining } from '../services/trainingFlag.js';
import { getOpenShift, getClosedShift, getShiftWorkers } from '../services/shifts.js';
import { loginFooter } from '../services/about.js';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function ShiftStatusLine() {
  const open = getOpenShift();
  const pending = getClosedShift();
  if (open) {
    const on = getShiftWorkers(open.id).filter((w) => !w.signed_off_at).map((w) => w.name);
    return <Text testID="login-shift" style={{ color: C.success, fontSize: 17, fontWeight: '800', textAlign: 'center' }}>🟢 {open.shift_name} shift open since {hhmm(open.opened_at)}{on.length ? ` · ${on.join(', ')}` : ''}</Text>;
  }
  if (pending) return <Text testID="login-shift" style={{ color: C.warn, fontSize: 17, fontWeight: '800', textAlign: 'center' }}>⚖️ {pending.shift_name} shift waiting for supervisor balance</Text>;
  return <Text testID="login-shift" style={{ color: C.sub, fontSize: 17, fontWeight: '700', textAlign: 'center' }}>No shift running</Text>;
}

export default function LoginScreen({ onLogin, onClock, onLink, onAbout }) {
  const dev = deviceSettings();
  const [mode, setMode] = useState('pin');
  const [pin, setPin] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const settings = getSettings();
  // Only the sample logins that still exist and are switched on (none once they are removed or retired).
  let demo = [];
  try { demo = settings.showDemoPins && !isTraining() ? sampleLoginsActive() : []; } catch (e) { demo = []; }
  const insets = useSafeAreaInsets();
  const { isTablet } = useLayout();
  useTick(1000);
  const now = clock.now();
  const locked = loginLockRemaining();

  // Admin › Devices can limit who logs in on this device.
  const enter = (u) => {
    const why = loginBlockedHere(u);
    if (why) { setPin(''); setError(why); return; }
    noteLogin(u);
    onLogin(u);
  };
  const fail = (msg) => {
    const l = loginLockRemaining();
    setError(l ? `Too many wrong attempts. Try again in ${l} seconds.` : msg);
  };
  const tryPin = (p, explicit) => {
    setError('');
    if (loginLockRemaining()) return fail('');
    if (p.length < 4) {
      if (explicit) setError('Enter your 4-6 digit PIN.');
      return;
    }
    const u = login(p);
    if (u) {
      setPin('');
      enter(u);
    } else if (explicit || p.length >= 6) {
      setPin('');
      fail('Wrong PIN. Please try again.');
    }
  };
  // A 4-digit PIN logs in automatically; longer PINs are checked when Log in is pressed.
  const onPinChange = (v) => {
    setPin(v);
    setError('');
    if (v.length >= 4 && !loginLockRemaining() && !hasLongerPin(v)) {
      if (pinMatches(v)) {
        const u = login(v);
        if (u) { setPin(''); enter(u); }
      } else if (v.length >= 6) tryPin(v, true);
    }
  };
  const tryPassword = () => {
    setError('');
    if (loginLockRemaining()) return fail('');
    if (!username.trim() || !password) return setError('Enter your username and password.');
    const u = loginWithPassword(username, password);
    if (u) {
      setPassword('');
      enter(u);
    } else fail('Wrong username or password.');
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 20, paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }} keyboardShouldPersistTaps="handled">
      <View style={{ height: 6, backgroundColor: C.brandRed, position: 'absolute', top: 0, left: 0, right: 0 }} />
      <View style={{ width: '100%', maxWidth: isTablet ? 980 : 460, alignSelf: 'center', flexDirection: isTablet ? 'row' : 'column', gap: 24, alignItems: isTablet ? 'center' : 'stretch' }}>
        <View style={{ flex: isTablet ? 1 : undefined, alignItems: 'center', gap: 10 }}>
          <Image testID="login-logo" source={LOGO} style={{ width: 300, height: 133 }} resizeMode="contain" />
          <Text style={{ fontSize: 24, fontWeight: '900', color: C.text, textAlign: 'center' }}>Easy Buys Shopping Centre</Text>
          {onClock && dev.clockHere ? (
            <Btn testID="open-clock" title="Time Clock – Clock in / out" icon="⏱️" variant="success" onPress={onClock} style={{ width: '100%', maxWidth: 380 }} />
          ) : null}
          <View style={{ backgroundColor: C.white, borderRadius: 16, padding: 14, width: '100%', maxWidth: 380, alignItems: 'center', borderWidth: 1, borderColor: C.border }}>
            <Text testID="login-clock" style={{ fontSize: 44, fontWeight: '900', color: C.text }}>{String(now.getHours()).padStart(2, '0')}:{String(now.getMinutes()).padStart(2, '0')}</Text>
            <Text style={{ fontSize: 17, color: C.sub, marginBottom: 8 }}>{DAYS[now.getDay()]} {now.getDate()} {MONTHS[now.getMonth()]} {now.getFullYear()}</Text>
            {moduleOn('bakery') ? <ShiftStatusLine /> : null}
          </View>
          {onLink ? (
            <Btn testID="open-link" title="Link to Easy Buys" icon="🔗" variant="info" onPress={onLink} style={{ width: '100%', maxWidth: 380 }} />
          ) : null}
          {demo.length ? (
            <View testID="demo-pins" style={{ backgroundColor: C.infoSoft, borderRadius: 14, padding: 12, width: '100%', maxWidth: 380 }}>
              <Text style={{ color: C.info, fontWeight: '800', fontSize: 15, marginBottom: 4 }}>Sample logins for testing</Text>
              <Text style={{ color: C.text, fontSize: 15, lineHeight: 22 }}>{demo.map((u) => `${u.name}: PIN ${u.pin}`).join('\n')}</Text>
            </View>
          ) : null}
        </View>
        <View style={{ flex: isTablet ? 1 : undefined, backgroundColor: C.white, borderRadius: 22, padding: 20, borderWidth: 1, borderColor: C.border, elevation: 3 }}>
          <Chips value={mode} onChange={(m) => { setMode(m); setError(''); }} testIDPrefix="login-mode"
            options={[{ value: 'pin', label: 'PIN' }, { value: 'password', label: 'Username & password' }]} />
          <View style={{ height: 14 }} />
          {locked ? <Text testID="login-locked" style={{ color: C.danger, fontSize: 17, fontWeight: '800', textAlign: 'center', marginBottom: 10 }}>Login locked for {locked} seconds after 5 wrong attempts.</Text> : null}
          {error && !locked ? <Text testID="login-error" style={{ color: C.danger, fontSize: 18, fontWeight: '700', textAlign: 'center', marginBottom: 10 }}>{error}</Text> : null}
          {mode === 'pin' ? (
            <>
              <Text style={{ fontSize: 21, fontWeight: '800', color: C.text, textAlign: 'center' }}>Enter your PIN</Text>
              <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14, marginVertical: 16 }}>
                {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
                  <View key={i} style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: i < pin.length ? C.primary : C.border }} />
                ))}
              </View>
              <PinPad value={pin} onChange={onPinChange} />
              <Btn testID="login-btn" title="Log in" icon="🔓" onPress={() => tryPin(pin, true)} style={{ marginTop: 14 }} disabled={!!locked} />
            </>
          ) : (
            <View style={{ gap: 14 }}>
              <Field testID="login-username" label="Username" value={username} onChangeText={setUsername} placeholder="e.g. sita" />
              <Field testID="login-password" label="Password" value={password} onChangeText={setPassword} secure />
              <Btn testID="login-pw-btn" title="Log in" icon="🔓" onPress={tryPassword} disabled={!!locked} />
            </View>
          )}
          <Text style={{ fontSize: 14, color: C.sub, textAlign: 'center', marginTop: 14 }}>Forgot your PIN or password? Ask the Admin.</Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 20 }}>
        <Text testID="login-footer" style={{ fontSize: 13, color: C.sub, textAlign: 'center' }}>{loginFooter()}</Text>
        {onAbout ? (
          <Pressable testID="login-about" onPress={onAbout} accessibilityLabel="About Easy Buys" style={({ pressed }) => ({ width: 34, height: 34, borderRadius: 17, borderWidth: 2, borderColor: C.info, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ fontSize: 17, fontWeight: '900', color: C.info }}>i</Text>
          </Pressable>
        ) : null}
      </View>
    </ScrollView>
  );
}
