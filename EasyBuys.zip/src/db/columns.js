// Columns added after a table was first released. Added on start-up if missing (data is never touched).
import { db } from './connection.js';
import { BANK35_COLUMNS } from '../modules/bank/schema35.js';
import { TILL35_COLUMNS } from '../modules/till/schema35.js';
import { TILL392_COUNT_COLUMNS, TILL392_SHORT_COLUMNS } from '../modules/till/schema392.js';
import { PAY35_COLUMNS } from '../modules/payroll/schema35.js';
import { DOCS35_COLUMNS } from '../services/documents.js';
import { LIC35_COLUMNS } from '../modules/licences/service.js';

export const EXTRA_COLUMNS = {
  till_counts: [['z_vat', 'REAL'], ['z_zero_rated', 'REAL'], ['z_refunds', 'REAL'], ['z_voids', 'REAL'], ['z_customers', 'INTEGER'],
    ['short_action', 'TEXT'], ['short_charge_uid', 'TEXT'], ['short_note', 'TEXT'], ['z_read', 'TEXT']].concat(TILL35_COLUMNS, TILL392_COUNT_COLUMNS),
  till_shortages: TILL392_SHORT_COLUMNS,
  ap_invoices: [['po_uid', 'TEXT'], ['pay_method', 'TEXT']],
  staff_charges: [['photo_urls', 'TEXT']],
  contracts: [['mode', 'TEXT'], ['template_doc_uid', 'TEXT'], ['doc_uid', 'TEXT']],
  bank_entries: [['gl_code', 'TEXT'], ['split', 'TEXT']],
  ap_suppliers: [['budget_monthly', 'REAL'], ['budget_weekly', 'REAL'], ['lead_days', 'INTEGER'], ['viber', 'TEXT'], ['order_days', 'TEXT'], ['withhold_pct', 'REAL'], ['needs_setup', 'INTEGER']],
  ap_payments: [['withheld', 'REAL'], ['method_name', 'TEXT']],
  // v3.5 B2: cheque books & stubs, cheque handed over, suppliers typed on the photo screen
  cheques: [['handed_date', 'TEXT'], ['handed_by_name', 'TEXT'], ['handed_to', 'TEXT'], ['photo_urls', 'TEXT'], ['stub_note', 'TEXT']],
  cheque_books: [['serial', 'TEXT'], ['holder', 'TEXT'], ['status', 'TEXT']],
  money_snaps: [['supplier_uid', 'TEXT'], ['cheque_no', 'INTEGER'], ['account_uid', 'TEXT'], ['cheque_check', 'TEXT'], ['invoice_uids', 'TEXT'], ['po_uid', 'TEXT'], ['taker_sig', 'TEXT']],
  gl_journals: [['meta', 'TEXT'], ['ref_uid', 'TEXT']],
  po_orders: [['version', 'INTEGER'], ['amended_at', 'TEXT'], ['amended_by_name', 'TEXT'], ['amend_sent_at', 'TEXT'], ['signature', 'TEXT'], ['signed_by_name', 'TEXT'], ['signed_by_uid', 'TEXT'], ['signed_at', 'TEXT']],
  // v3.9.3 a line can be ordered in cartons (pack_size singles each) or singles; qty and unit_cost stay in singles.
  po_lines: [['order_as', 'TEXT'], ['pack_size', 'REAL']],
  // v3.9.3 kind: 'initial' = the first stock take (all products, details shown and editable while counting).
  inv_counts: [['kind', 'TEXT']],
  inv_count_entries: [['kind', 'TEXT'], ['seen_reset', 'TEXT']],
  // v3.9.4 the Aronium link: which till an End of day came from (two tills in Shop 1 count their own Z numbers).
  aronium_eods: [['till_name', 'TEXT']],
  inv_items: [['wholesale_price', 'REAL'], ['removed_at', 'TEXT'], ['aronium_seen', 'TEXT'], ['fccc', 'INTEGER'], ['fccc_max', 'REAL'], ['fccc_name', 'TEXT'], ['fccc_set_at', 'TEXT'], ['fccc_key', 'TEXT'], ['fccc_list', 'TEXT'], ['aronium_vat', 'TEXT'], ['vat_set_at', 'TEXT'], ['fccc_auto', 'INTEGER'], ['fccc_reject', 'TEXT']],
  // 1.0 stock take: second count (two people), reason for a difference, expiry seen while counting
  inv_count_lines: [['second_count', 'REAL'], ['second_by_name', 'TEXT'], ['reason', 'TEXT'], ['expiry', 'TEXT'], ['expiry_qty', 'REAL']],
  // v3.5 B7: the proofing time worked out for a batch (yeast measure, Hot/Normal/Cool, minutes)
  batches: [['proof_yeast', 'REAL'], ['proof_climate', 'TEXT'], ['proof_minutes', 'REAL']],
};
// v3.5 B8: Drive documents (type, supplier / employee, number, upload status, checked fingerprint…).
EXTRA_COLUMNS.documents = (EXTRA_COLUMNS.documents || []).concat(DOCS35_COLUMNS);
// v3.5 bank, cash and M-PAiSA (shop tags, statement warnings, who marked a cheque cleared).
for (const [t, cols] of Object.entries(BANK35_COLUMNS)) EXTRA_COLUMNS[t] = (EXTRA_COLUMNS[t] || []).concat(cols);
// v3.5 payroll: pay cycles, extra runs, reopening, per-person FNPF / PAYE rules.
for (const [t, cols] of Object.entries(PAY35_COLUMNS)) EXTRA_COLUMNS[t] = (EXTRA_COLUMNS[t] || []).concat(cols);
// v3.5 B7 licences as the safeguard (responsible + backup, conditions, checklist, owner sign-off).
for (const [t, cols] of Object.entries(LIC35_COLUMNS)) EXTRA_COLUMNS[t] = (EXTRA_COLUMNS[t] || []).concat(cols);

// Small tables added later (each module's big tables live in its own schema file).
export const EXTRA_SQL = `
CREATE TABLE IF NOT EXISTS inv_count_areas (
  uid TEXT PRIMARY KEY,
  count_uid TEXT NOT NULL,
  area TEXT NOT NULL,
  counter_name TEXT, started_at TEXT, done_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS rosters (
  user_uid TEXT PRIMARY KEY,
  days TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

export function ensureColumns() {
  db().exec(EXTRA_SQL);
  for (const [table, cols] of Object.entries(EXTRA_COLUMNS)) {
    const have = db().all(`PRAGMA table_info(${table})`).map((c) => c.name);
    if (!have.length) continue;
    for (const [name, type] of cols) if (!have.includes(name)) { try { db().exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`); } catch (e) { /* v3.9.3 one column never stops the app – noted by the health check */ } }
  }
}
