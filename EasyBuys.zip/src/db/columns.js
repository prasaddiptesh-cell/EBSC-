// Columns added after a table was first released. Added on start-up if missing (data is never touched).
import { db } from './connection.js';
import { BANK35_COLUMNS } from '../modules/bank/schema35.js';
import { TILL35_COLUMNS } from '../modules/till/schema35.js';
import { PAY35_COLUMNS } from '../modules/payroll/schema35.js';

export const EXTRA_COLUMNS = {
  till_counts: [['z_vat', 'REAL'], ['z_zero_rated', 'REAL'], ['z_refunds', 'REAL'], ['z_voids', 'REAL'], ['z_customers', 'INTEGER'],
    ['short_action', 'TEXT'], ['short_charge_uid', 'TEXT'], ['short_note', 'TEXT']].concat(TILL35_COLUMNS),
  ap_invoices: [['po_uid', 'TEXT']],
  staff_charges: [['photo_urls', 'TEXT']],
  contracts: [['mode', 'TEXT'], ['template_doc_uid', 'TEXT'], ['doc_uid', 'TEXT']],
  bank_entries: [['gl_code', 'TEXT'], ['split', 'TEXT']],
  ap_suppliers: [['budget_monthly', 'REAL'], ['budget_weekly', 'REAL'], ['lead_days', 'INTEGER'], ['viber', 'TEXT'], ['order_days', 'TEXT'], ['withhold_pct', 'REAL'], ['needs_setup', 'INTEGER']],
  ap_payments: [['withheld', 'REAL']],
  // v3.5 B2: cheque books & stubs, cheque handed over, suppliers typed on the photo screen
  cheques: [['handed_date', 'TEXT'], ['handed_by_name', 'TEXT'], ['handed_to', 'TEXT'], ['photo_urls', 'TEXT'], ['stub_note', 'TEXT']],
  cheque_books: [['serial', 'TEXT'], ['holder', 'TEXT'], ['status', 'TEXT']],
  money_snaps: [['supplier_uid', 'TEXT'], ['cheque_no', 'INTEGER'], ['account_uid', 'TEXT'], ['cheque_check', 'TEXT'], ['invoice_uids', 'TEXT'], ['po_uid', 'TEXT']],
  gl_journals: [['meta', 'TEXT'], ['ref_uid', 'TEXT']],
  po_orders: [['version', 'INTEGER'], ['amended_at', 'TEXT'], ['amended_by_name', 'TEXT'], ['amend_sent_at', 'TEXT']],
  inv_items: [['wholesale_price', 'REAL'], ['removed_at', 'TEXT'], ['aronium_seen', 'TEXT']],
};
// v3.5 bank, cash and M-PAiSA (shop tags, statement warnings, who marked a cheque cleared).
for (const [t, cols] of Object.entries(BANK35_COLUMNS)) EXTRA_COLUMNS[t] = (EXTRA_COLUMNS[t] || []).concat(cols);
// v3.5 payroll: pay cycles, extra runs, reopening, per-person FNPF / PAYE rules.
for (const [t, cols] of Object.entries(PAY35_COLUMNS)) EXTRA_COLUMNS[t] = (EXTRA_COLUMNS[t] || []).concat(cols);

// Small tables added later (each module's big tables live in its own schema file).
export const EXTRA_SQL = `
CREATE TABLE IF NOT EXISTS rosters (
  user_uid TEXT PRIMARY KEY,
  days TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

export function ensureColumns() {
  db().exec(EXTRA_SQL);
  for (const [table, cols] of Object.entries(EXTRA_COLUMNS)) {
    const have = db().all(`PRAGMA table_info(${table})`).map((c) => c.name);
    if (!have.length) continue;
    for (const [name, type] of cols) if (!have.includes(name)) db().exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
  }
}
