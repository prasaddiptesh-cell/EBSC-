// Columns added after a table was first released. Added on start-up if missing (data is never touched).
import { db } from './connection.js';

export const EXTRA_COLUMNS = {
  till_counts: [['z_vat', 'REAL'], ['z_zero_rated', 'REAL'], ['z_refunds', 'REAL'], ['z_voids', 'REAL'], ['z_customers', 'INTEGER'],
    ['short_action', 'TEXT'], ['short_charge_uid', 'TEXT'], ['short_note', 'TEXT']],
  ap_invoices: [['po_uid', 'TEXT']],
  staff_charges: [['photo_urls', 'TEXT']],
  contracts: [['mode', 'TEXT'], ['template_doc_uid', 'TEXT'], ['doc_uid', 'TEXT']],
  bank_entries: [['gl_code', 'TEXT'], ['split', 'TEXT']],
  ap_suppliers: [['budget_monthly', 'REAL'], ['budget_weekly', 'REAL'], ['lead_days', 'INTEGER'], ['viber', 'TEXT'], ['order_days', 'TEXT'], ['withhold_pct', 'REAL']],
  ap_payments: [['withheld', 'REAL']],
  gl_journals: [['meta', 'TEXT'], ['ref_uid', 'TEXT']],
};

// Small tables added later (each module's big tables live in its own schema file).
export const EXTRA_SQL = `
CREATE TABLE IF NOT EXISTS rosters (
  user_uid TEXT PRIMARY KEY,
  days TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

export function ensureColumns() {
  db().exec(EXTRA_SQL);
  for (const [table, cols] of Object.entries(EXTRA_COLUMNS)) {
    const have = db().all(`PRAGMA table_info(${table})`).map((c) => c.name);
    if (!have.length) continue;
    for (const [name, type] of cols) if (!have.includes(name)) db().exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
  }
}
