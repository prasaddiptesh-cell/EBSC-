// Holds the active database adapter.
// The adapter is a tiny interface so the business logic does not depend on
// any specific database library. Today it is on-device SQLite (expo-sqlite);
// later a sync layer can wrap the same interface.
//
// Adapter shape:
//   exec(sql)                 -> run one or more statements (no params)
//   run(sql, params)          -> { changes, lastInsertRowId }
//   all(sql, params)          -> array of row objects
//   get(sql, params)          -> first row object or null
//   transaction(fn)           -> runs fn() atomically

let adapter = null;
// Goes up by one on every change to the data (so worked-out figures, like the books, can be kept until something changes).
let writes = 0;
export function writeCount() { return writes; }

// View-only logins (the accountant): a guard refuses changes to business records made from the screens. Work the app
// does by itself (sync, safety copies, warnings) runs inside withSystem(), which the guard lets through.
let guard = null;
let systemDepth = 0;
export function setWriteGuard(fn) { guard = fn || null; }
export function withSystem(fn) { systemDepth += 1; try { return fn(); } finally { systemDepth -= 1; } }
const WRITE = /^\s*(?:INSERT(?:\s+OR\s+\w+)?\s+INTO|UPDATE(?:\s+OR\s+\w+)?|DELETE\s+FROM|REPLACE\s+INTO)\s+"?(\w+)"?/i;
function check(sql) {
  if (!guard || systemDepth > 0) return;
  const m = WRITE.exec(String(sql || ''));
  if (m) guard(m[1].toLowerCase());
}

export function setDb(a) {
  // Wrap transaction() so nested calls simply join the outer transaction.
  let depth = 0;
  writes += 1;
  adapter = {
    ...a,
    run(sql, params) { check(sql); writes += 1; return a.run(sql, params); },
    exec(sql) { writes += 1; return a.exec(sql); },
    transaction(fn) {
      if (depth > 0) return fn();
      depth += 1;
      try {
        return a.transaction(fn);
      } finally {
        depth -= 1;
      }
    },
  };
}

export function db() {
  if (!adapter) throw new Error('Database not initialised');
  return adapter;
}

// Convert undefined -> null and booleans -> 0/1 so every SQLite driver accepts them.
export function cleanParams(params) {
  return (params || []).map((p) => {
    if (p === undefined) return null;
    if (p === true) return 1;
    if (p === false) return 0;
    return p;
  });
}
