// Holds the active database adapter.
// The adapter is a tiny interface so the business logic does not depend on
// any specific database library. Today it is on-device SQLite (expo-sqlite);
// later a sync layer can wrap the same interface.
//
// Adapter shape:
//   exec(sql)                 -> run one or more statements (no params)
//   run(sql, params)          -> { changes, lastInsertRowId }
//   all(sql, params)          -> array of row objects
//   get(sql, params)          -> first row object or null
//   transaction(fn)           -> runs fn() atomically

let adapter = null;
// Goes up by one on every change to the data (so worked-out figures, like the books, can be kept until something changes).
let writes = 0;
export function writeCount() { return writes; }
// v3.9.4 saves made by a person (not by sync or the app's own background work, which run inside withSystem()).
let userWrites = 0;
export function userWriteCount() { return userWrites; }

// View-only logins (the accountant): a guard refuses changes to business records made from the screens. Work the app
// does by itself (sync, safety copies, warnings) runs inside withSystem(), which the guard lets through.
let guard = null;
let systemDepth = 0;
export function setWriteGuard(fn) { guard = fn || null; }
// 1.0.0 build 1: the locked-settings guard (services/locked.js) – a second guard, kept apart from the view-only one.
let lockGuard = null;
export function setLockGuard(fn) { lockGuard = fn || null; }
export function withSystem(fn) { systemDepth += 1; try { return fn(); } finally { systemDepth -= 1; } }
export function inSystem() { return systemDepth > 0; }
const WRITE = /^\s*(?:INSERT(?:\s+OR\s+\w+)?\s+INTO|UPDATE(?:\s+OR\s+\w+)?|DELETE\s+FROM|REPLACE\s+INTO)\s+"?(\w+)"?/i;
function check(sql, params) {
  if ((!guard && !lockGuard) || systemDepth > 0) return;
  const m = WRITE.exec(String(sql || ''));
  if (!m) return;
  if (guard) guard(m[1].toLowerCase(), params || [], String(sql));
  if (lockGuard) lockGuard(m[1].toLowerCase(), params || [], String(sql));
}

// v3.9.2 the real database, kept while practice (training) mode uses its own: the device's cloud link lives there.
let realAdapter = null;
export function setRealDb(a) { realAdapter = a; }
export function realDb() { return realAdapter; }
// 1.0.0 speed: a change count per table, so a figure worked out from a few tables can be kept until one of THOSE
// tables changes (tableVersion). A statement whose table can't be told (exec, a rolled-back transaction, a switch of
// database) moves `epoch`, which counts as a change to every table.
let epoch = 0;
let changed = 0; // statements that changed rows
const tableWrites = new Map();
// tables the database itself changes when another one changes (SQLite triggers: inventory/stockMonths.js)
const ALSO = { inv_moves: ['inv_stock_months'] };
// 1.0.0 round 2: the two settings tables are written all the time (sync cursors, "last synced", a person's hidden
// warnings …). Each key has its own change count too, so a figure that read one setting is only worked out again
// when THAT setting changes ('settings#key'). A write whose key can't be told counts for every key ('settings#*').
const KEYED = new Set(['settings', 'shared_settings']);
const bump = (k) => tableWrites.set(k, (tableWrites.get(k) || 0) + 1);
function keyOfWrite(sql, params) {
  const q = String(sql);
  let m = /\(\s*key\s*,[^)]*\)\s*VALUES\s*\(\s*'([^']*)'/i.exec(q);
  if (m) return m[1];
  if (/\(\s*key\s*,[^)]*\)\s*VALUES\s*\(\s*\?/i.test(q)) return params && params.length ? params[0] : null;
  m = /WHERE\s+key\s*=\s*'([^']*)'\s*$/i.exec(q);
  if (m) return m[1];
  if (/WHERE\s+key\s*=\s*\?\s*$/i.test(q)) return params && params.length ? params[params.length - 1] : null;
  return null;
}
function noteWrite(sql, params) {
  const m = WRITE.exec(String(sql || ''));
  if (!m) { epoch += 1; return; }
  const t = m[1].toLowerCase();
  bump(t);
  if (KEYED.has(t)) { const k = keyOfWrite(sql, params); bump(k === null || k === undefined ? `${t}#*` : `${t}#${k}`); }
  for (const x of ALSO[t] || []) bump(x);
}
const verOf = (d) => {
  if (d[0] === '?') { try { const [q, p] = JSON.parse(d.slice(1)); return JSON.stringify(adapter.get(q, p)); } catch (e) { return `x${epoch}`; } }
  const i = d.indexOf('#');
  if (i < 0) return tableWrites.get(d) || 0;
  return `${tableWrites.get(d) || 0}.${tableWrites.get(`${d.slice(0, i)}#*`) || 0}`;
};
// A fingerprint of the given tables' changes: equal fingerprints = none of them changed (on this database).
// 'settings#key' / 'shared_settings#key' stand for one setting.
export function tableVersion(tables) {
  return `${epoch}\u0002${tables.map(verOf).join('\u0001')}`;
}

// ---------------------------------------------------------------- 1.0.0 round 2: what a piece of work read
// While a tracked piece of work runs, every table it reads (and every single setting) is noted; a figure kept with
// keepTracked is then worked out again only when one of THOSE changed. Kept figures used inside it pass on what
// they were made from (noteDeps), so nothing hidden in a memory is missed.
const trackers = [];
export function noteDeps(list) {
  if (!trackers.length || !list) return;
  for (const s of trackers) for (const d of list) s.add(d);
}
export function noteKeyRead(table, key) { if (trackers.length) noteDeps([`${table}#${key}`]); }
const KEY_READ = /^\s*SELECT\s+[\w\s,*]+\s+FROM\s+"?(settings|shared_settings)"?\s+WHERE\s+key\s*=\s*(\?|'([^']*)')\s*;?\s*$/i;
let untrackDepth = 0;
// Reads made inside fn are not noted (the caller notes a narrower dependency itself, e.g. a probeDep).
export function untracked(fn) { untrackDepth += 1; try { return fn(); } finally { untrackDepth -= 1; } }
// A dependency on a few rows only: its "version" is the answer of a small query (e.g. a fingerprint of one day's
// rows), worked out each time a kept figure is checked. For figures that read a narrow slice of a busy table.
export function probeDep(sql, params = []) { return `?${JSON.stringify([sql, params])}`; }
function noteRead(sql, params) {
  if (!trackers.length || untrackDepth) return;
  const m = KEY_READ.exec(String(sql));
  if (m) { noteDeps([`${m[1].toLowerCase()}#${m[3] !== undefined ? m[3] : (params || [])[0]}`]); return; }
  noteDeps(tablesOf(sql).filter((t) => t !== 'sqlite_master'));
}
// Runs fn noting what it reads: { value, deps }.
export function trackReads(fn) {
  const set = new Set();
  trackers.push(set);
  let value;
  try { value = fn(); } finally { trackers.pop(); }
  const deps = [...set];
  noteDeps(deps);
  return { value, deps };
}
// Worked out once and kept until something it READ changes (found by trackReads), it is older than maxAgeMs (for
// figures that also depend on the clock), or the database is switched. The value is shared: never change it.
const tracked = new Map();
// Stepping (stepThrough): a piece of work made of kept parts is done one part at a time with a pause between – the
// outermost kept part that has to be worked out is done, then the work stops (STOP) and is started again after the
// pause (the parts done are kept, so each start goes one part further). Parts inside parts are done with their part.
const STOP = new Error('step');
let step = null; // { budget, done: Map } while stepping
let computeDepth = 0;
export const isStop = (e) => e === STOP;
export async function stepThrough(fn, { pause = () => new Promise((r) => setTimeout(r, 0)), maxSteps = 400 } = {}) {
  const done = new Map();
  for (let i = 0; ; i += 1) {
    step = { budget: i >= maxSteps ? Infinity : 1, done };
    try { return fn(); } catch (e) { if (e !== STOP) throw e; } finally { step = null; }
    await pause();
  }
}
export function keepTracked(key, fn, { maxAgeMs = Infinity, needDeps = false } = {}) {
  if (!keepOn) return fn();
  const top = step && computeDepth === 0;
  if (top && step.done.has(key)) { const d = step.done.get(key); noteDeps(d.deps); return d.value; }
  const hit = tracked.get(key);
  if (hit && hit.db === adapter && Date.now() - hit.at < maxAgeMs && hit.ver !== null && hit.ver === tableVersion(hit.deps)) { noteDeps(hit.deps); return hit.value; }
  if (top) { if (step.budget <= 0) throw STOP; step.budget -= 1; }
  const w0 = changed + epoch;
  const t0 = Date.now();
  computeDepth += 1;
  let r;
  try { r = trackReads(fn); } finally { computeDepth -= 1; }
  const { value, deps } = r;
  if (top) step.done.set(key, { value, deps });
  if (hit) tracked.delete(key);
  if (needDeps && !deps.length) return value; // read nothing from the database: it may depend on something else – not kept
  while (tracked.size >= 800) tracked.delete(tracked.keys().next().value);
  // it saved something itself while it ran: worked out once more next time (then it is settled)
  tracked.set(key, { db: adapter, at: t0, deps, ver: changed + epoch === w0 ? tableVersion(deps) : null, value, ms: Date.now() - t0 });
  return value;
}
// How long the last working-out of a kept figure took (ms), or null.
export function trackedMs(key) { const h = tracked.get(key); return h ? h.ms : null; }
export function trackedTimes() { return [...tracked.entries()].map(([k, h]) => [k, h.ms, h.at]); }
// For checks and tests: which kept figures would be worked out again now, and what changed for them.
export function staleTracked() {
  const out = [];
  for (const [k, h] of tracked) {
    if (h.ver === null) { out.push({ key: k, why: ['saved while working out'] }); continue; }
    if (h.ver !== tableVersion(h.deps)) {
      const old = String(h.ver).split('\u0002'); const now = tableVersion(h.deps).split('\u0002');
      const why = old[0] !== now[0] ? ['everything (epoch)'] : h.deps.filter((d, i) => String(old[1]).split('\u0001')[i] !== String(now[1]).split('\u0001')[i]);
      out.push({ key: k, why });
    }
  }
  return out;
}
export function forgetTracked(prefix = '') { for (const k of [...tracked.keys()]) if (k.startsWith(prefix)) tracked.delete(k); }
// The benchmark's "fresh" mode (tests/perf, EB_PERF_FRESH=1) switches every kept figure off, to time the work itself.
let keepOn = true;
export function setKeepOn(on) { keepOn = !!on; kept.clear(); keptWeight = 0; tracked.clear(); }
// Forget every kept figure now (the benchmark's fresh mode: as if every table had just changed).
export function clearKept() { kept.clear(); keptWeight = 0; tracked.clear(); epoch += 1; }
// The tables a read statement uses (every name after FROM / JOIN, sub-queries included).
const tablesOfSql = new Map();
function tablesOf(sql) {
  let t = tablesOfSql.get(sql);
  if (!t) {
    t = Array.from(new Set([...String(sql).matchAll(/\b(?:FROM|JOIN)\s+"?([A-Za-z_]\w*)"?/gi)].map((m) => m[1].toLowerCase()))).filter((x) => x !== 'select');
    if (tablesOfSql.size > 3000) tablesOfSql.clear();
    tablesOfSql.set(sql, t);
  }
  return t;
}
// A read kept until one of the tables it reads changes. For plain SELECTs whose answer depends on nothing but the
// tables named in them and the values passed (no clock: put today's date in `params`). The rows are shared: never
// change them (copy first).
export function keptAll(sql, params = []) {
  return keepUntilChanged(`all|${sql}|${JSON.stringify(params)}`, tablesOf(sql), () => adapter.all(sql, params));
}
export function keptGet(sql, params = []) {
  return keepUntilChanged(`get|${sql}|${JSON.stringify(params)}`, tablesOf(sql), () => adapter.get(sql, params));
}
// Worked out once and kept until one of `tables` changes (or the database is switched). The value is shared: callers
// must not change it. Only for figures made from those tables alone (no clock, no settings kept in memory elsewhere).
const kept = new Map();
let keptWeight = 0;
export function keepUntilChanged(key, tables, fn) {
  if (!untrackDepth) noteDeps(tables);
  if (!keepOn) return fn();
  const ver = tableVersion(tables);
  const hit = kept.get(key);
  if (hit && hit.db === adapter && hit.ver === ver) return hit.value;
  const value = fn();
  // kept within a limit (about 300 000 rows in all): the oldest go first
  const weight = Array.isArray(value) ? value.length + 1 : 1;
  if (hit) { keptWeight -= hit.weight; kept.delete(key); }
  while (kept.size && (keptWeight + weight > 300000 || kept.size >= 600)) {
    const [k0, v0] = kept.entries().next().value; kept.delete(k0); keptWeight -= v0.weight;
  }
  // a change made while working it out (or inside a transaction later undone) is caught by the version / epoch
  kept.set(key, { db: adapter, ver: tableVersion(tables) === ver ? ver : null, value, weight });
  keptWeight += weight;
  return value;
}
const ONLY_CREATE = /^(?:\s*(?:--[^\n]*\n\s*)*CREATE\s+(?:TABLE|INDEX|UNIQUE\s+INDEX)\s+IF\s+NOT\s+EXISTS\s[^;]*;?)+\s*$/i;
const SCHEMA_Q = /^\s*(?:SELECT\s[^;]*?\sFROM\s+sqlite_master\s+WHERE\s[^;]*|PRAGMA\s+table_info\s*\(\s*"?\w+"?\s*\))\s*;?\s*$/i;
export function setDb(a) {
  // Wrap transaction() so nested calls simply join the outer transaction.
  let depth = 0;
  writes += 1;
  epoch += 1;
  // 1.0.0 speed: "is this table / column here?" (sqlite_master, PRAGMA table_info) is asked thousands of times; the
  // answer only changes with the tables themselves (exec, or a statement that is not a plain insert / update /
  // delete – both move `epoch`), so it is kept until then. Each caller gets its own copy of the rows.
  const schemaKept = new Map();
  let schemaEpoch = -1;
  const schemaRead = (kind, sql, params) => {
    if (schemaEpoch !== epoch) { schemaKept.clear(); schemaEpoch = epoch; }
    const k = `${kind}|${sql}|${JSON.stringify(params || [])}`;
    if (!schemaKept.has(k)) {
      const r = kind === 'all' ? a.all(sql, params) : a.get(sql, params);
      if (schemaEpoch !== epoch) return r;
      if (schemaKept.size > 2000) schemaKept.clear();
      schemaKept.set(k, r);
    }
    const r = schemaKept.get(k);
    return kind === 'all' ? r.map((x) => ({ ...x })) : r ? { ...r } : r;
  };
  adapter = {
    ...a,
    all(sql, params) { if (SCHEMA_Q.test(sql)) return schemaRead('all', sql, params); noteRead(sql, params); return a.all(sql, params); },
    get(sql, params) { if (SCHEMA_Q.test(sql)) return schemaRead('get', sql, params); noteRead(sql, params); return a.get(sql, params); },
    run(sql, params) {
      check(sql, params); writes += 1; if (systemDepth === 0) userWrites += 1;
      const r = a.run(sql, params);
      // 1.0.0 round 2: a statement that changed no row (INSERT OR IGNORE of what is there, an UPDATE that found
      // nothing) changes no figure; anything else counts for its table (and for anything its triggers change)
      if (!r || r.changes === undefined || r.changes === null || Number(r.changes) > 0) { changed += 1; noteWrite(sql, params); }
      return r;
    },
    // exec has no parameters; a view-only login may not use it to change records either.
    exec(sql) {
      check(sql, []); writes += 1; if (systemDepth === 0) userWrites += 1;
      // 1.0.0 round 2: "CREATE … IF NOT EXISTS" of tables that are already there changes nothing (some parts make
      // sure of their table on every use): only a real change of the tables counts as a change to everything
      if (ONLY_CREATE.test(String(sql))) {
        const n0 = a.get('SELECT COUNT(*) AS n FROM sqlite_master').n;
        const r = a.exec(sql);
        if (a.get('SELECT COUNT(*) AS n FROM sqlite_master').n !== n0) epoch += 1;
        return r;
      }
      epoch += 1; return a.exec(sql);
    },
    transaction(fn) {
      if (depth > 0) return fn();
      depth += 1;
      try {
        return a.transaction(fn);
      } catch (e) {
        writes += 1; // rolled back: anything kept while it ran is read again
        epoch += 1;
        throw e;
      } finally {
        depth -= 1;
      }
    },
  };
}

export function db() {
  if (!adapter) throw new Error('Database not initialised');
  return adapter;
}

// Convert undefined -> null and booleans -> 0/1 so every SQLite driver accepts them.
export function cleanParams(params) {
  return (params || []).map((p) => {
    if (p === undefined) return null;
    if (p === true) return 1;
    if (p === false) return 0;
    return p;
  });
}
