// Holds the active database adapter.
// The adapter is a tiny interface so the business logic does not depend on
// any specific database library. Today it is on-device SQLite (expo-sqlite);
// later a sync layer can wrap the same interface.
//
// Adapter shape:
//   exec(sql)                 -> run one or more statements (no params)
//   run(sql, params)          -> { changes, lastInsertRowId }
//   all(sql, params)          -> array of row objects
//   get(sql, params)          -> first row object or null
//   transaction(fn)           -> runs fn() atomically

let adapter = null;

export function setDb(a) {
  // Wrap transaction() so nested calls simply join the outer transaction.
  let depth = 0;
  adapter = {
    ...a,
    transaction(fn) {
      if (depth > 0) return fn();
      depth += 1;
      try {
        return a.transaction(fn);
      } finally {
        depth -= 1;
      }
    },
  };
}

export function db() {
  if (!adapter) throw new Error('Database not initialised');
  return adapter;
}

// Convert undefined -> null and booleans -> 0/1 so every SQLite driver accepts them.
export function cleanParams(params) {
  return (params || []).map((p) => {
    if (p === undefined) return null;
    if (p === true) return 1;
    if (p === false) return 0;
    return p;
  });
}
