// On-device SQLite adapter (works fully offline).
import * as SQLite from 'expo-sqlite';
import { cleanParams } from './connection.js';

export function openExpoDb(name = 'bakery.db') {
  const sqlite = SQLite.openDatabaseSync(name);
  sqlite.execSync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  return {
    exec: (sql) => sqlite.execSync(sql),
    run: (sql, params) => {
      const r = sqlite.runSync(sql, cleanParams(params));
      return { changes: r.changes, lastInsertRowId: r.lastInsertRowId };
    },
    all: (sql, params) => sqlite.getAllSync(sql, cleanParams(params)),
    get: (sql, params) => sqlite.getFirstSync(sql, cleanParams(params)) || null,
    close: () => { try { sqlite.closeSync(); } catch (e) { /* already closed */ } },
    // 1.0.0 the daily database check reads the whole file (seconds with 3 years of data): it runs on a second
    // connection, away from the screens (the app's own connection keeps answering meanwhile).
    quickCheckAsync: async () => {
      const other = await SQLite.openDatabaseAsync(name);
      try { const r = await other.getFirstAsync('PRAGMA quick_check'); return r ? Object.values(r)[0] : 'ok'; } finally { try { await other.closeAsync(); } catch (e) { /* closed */ } }
    },
    transaction: (fn) => {
      let result;
      sqlite.withTransactionSync(() => {
        result = fn();
      });
      return result;
    },
  };
}
