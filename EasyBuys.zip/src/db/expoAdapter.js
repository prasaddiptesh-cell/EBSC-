// On-device SQLite adapter (works fully offline).
import * as SQLite from 'expo-sqlite';
import { cleanParams } from './connection.js';

export function openExpoDb(name = 'bakery.db') {
  const sqlite = SQLite.openDatabaseSync(name);
  sqlite.execSync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  return {
    exec: (sql) => sqlite.execSync(sql),
    run: (sql, params) => {
      const r = sqlite.runSync(sql, cleanParams(params));
      return { changes: r.changes, lastInsertRowId: r.lastInsertRowId };
    },
    all: (sql, params) => sqlite.getAllSync(sql, cleanParams(params)),
    get: (sql, params) => sqlite.getFirstSync(sql, cleanParams(params)) || null,
    transaction: (fn) => {
      let result;
      sqlite.withTransactionSync(() => {
        result = fn();
      });
      return result;
    },
  };
}
