// On-device SQLite adapter (works fully offline).
import * as SQLite from 'expo-sqlite';
import { cleanParams } from './connection.js';

// A connection that was closed underneath us (the native object is gone: "NullPointerException" / "closed" /
// "not open") is opened again once and the statement retried – the app never stays broken until it is restarted.
export const isGoneError = (e) => /NullPointerException|has been closed|is closed|not open|database is closed|Access to closed resource/i.test(String((e && e.message) || e));
export function openExpoDb(name = 'bakery.db', { open = (n) => SQLite.openDatabaseSync(n) } = {}) {
  let sqlite = open(name);
  sqlite.execSync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  let closedOnPurpose = false;
  const reopen = () => { sqlite = open(name); sqlite.execSync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;'); };
  const safe = (fn) => { try { return fn(); } catch (e) { if (closedOnPurpose || !isGoneError(e)) throw e; reopen(); return fn(); } };
  return {
    exec: (sql) => safe(() => sqlite.execSync(sql)),
    run: (sql, params) => safe(() => {
      const r = sqlite.runSync(sql, cleanParams(params));
      return { changes: r.changes, lastInsertRowId: r.lastInsertRowId };
    }),
    all: (sql, params) => safe(() => sqlite.getAllSync(sql, cleanParams(params))),
    get: (sql, params) => safe(() => sqlite.getFirstSync(sql, cleanParams(params)) || null),
    close: () => { closedOnPurpose = true; try { sqlite.closeSync(); } catch (e) { /* already closed */ } },
    // 1.0.0 the daily database check reads the whole file (seconds with 3 years of data): it runs on a second
    // connection, away from the screens (the app's own connection keeps answering meanwhile).
    quickCheckAsync: async () => {
      // 2 Nov: a NEW connection – without it expo-sqlite hands back the app's own (cached) connection, and closing it
      // afterwards shut the app's database ("NativeDatabase.prepareSync … NullPointerException" on every screen)
      const other = await SQLite.openDatabaseAsync(name, { useNewConnection: true });
      try { const r = await other.getFirstAsync('PRAGMA quick_check'); return r ? Object.values(r)[0] : 'ok'; } finally { try { await other.closeAsync(); } catch (e) { /* closed */ } }
    },
    transaction: (fn) => {
      let result;
      safe(() => sqlite.withTransactionSync(() => {
        result = fn();
      }));
      return result;
    },
  };
}
