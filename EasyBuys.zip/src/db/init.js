// Creates tables on first launch, upgrades older versions and loads sample data.
import { db, setDb } from './connection.js';
import { getSetting, shareBusinessSettings } from '../services/core.js';
import { SCHEMA_SQL, SCHEMA_VERSION, ALL_TABLES, V3_SQL } from './schema.js';
import { seedSampleData, markSampleLogins } from './seed.js';
import { seedEasyBuys, fillMissingUids } from './seedV3.js';
import { PAYABLES_SQL, RECURRING_SQL } from '../modules/payables/schema.js';
import { TILL_SQL } from '../modules/till/schema.js';
import { BANK_SQL } from '../modules/bank/schema.js';
import { PAYROLL_SQL } from '../modules/payroll/schema.js';
import { ensureColumns } from './columns.js';
import { INVENTORY_SQL } from '../modules/inventory/schema.js';
import { MORE_SQL } from './moreSchemas.js';
import { migrateShops35 } from '../services/costAreas.js';

function currentVersion() {
  try {
    const row = db().get("SELECT value FROM settings WHERE key = 'schema_version'");
    return row ? Number(row.value) : 0;
  } catch (e) {
    return 0;
  }
}

// Table links (foreign keys) are switched off while old tables are removed,
// otherwise SQLite refuses to drop a table that other tables still point to.
function dropAll() {
  db().exec('PRAGMA foreign_keys = OFF;');
  try {
    const existing = db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").map((r) => r.name);
    for (const t of Array.from(new Set(ALL_TABLES.concat(existing)))) db().exec(`DROP TABLE IF EXISTS "${t}";`);
  } finally {
    db().exec('PRAGMA foreign_keys = ON;');
  }
}

function setVersionAndSeed(seed) {
  db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', ?)", [String(SCHEMA_VERSION)]);
  if (seed) {
    db().transaction(() => {
      seedSampleData();
      db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('seeded', '1')");
    });
  }
}

export function initDatabase(adapter, { seed = true } = {}) {
  setDb(adapter);
  const v = currentVersion();
  if (v === 1) {
    // Version 1 held test data only, so it is replaced with the new structure.
    dropAll();
  } else if (v === 2) {
    // Version 2 (Bakery app) holds REAL bakery data: upgrade it in place, never delete anything.
    upgradeFrom2();
  }
  db().exec(SCHEMA_SQL);
  db().exec(V3_SQL);
  db().exec(PAYABLES_SQL);
  db().exec(RECURRING_SQL);
  db().exec(TILL_SQL);
  db().exec(BANK_SQL);
  db().exec(PAYROLL_SQL);
  db().exec(INVENTORY_SQL);
  // v3.9.3 one part that cannot be set up never stops the app from opening: it is noted in the problem log.
  MORE_SQL.forEach((sql) => { try { db().exec(sql); } catch (e) { noteStartProblem('tables', e); } });
  try { ensureColumns(); } catch (e) { noteStartProblem('columns', e); }
  speedIndexes();
  allowNewRoles();
  // v3.9.3 after an app update, fetch everything from the cloud once more: records of tables the older version did
  // not know yet were skipped by it (newest change still wins; nothing local is lost).
  try {
    const { APP_VERSION } = require('../services/core.js');
    const seen = db().get("SELECT value FROM settings WHERE key = 'app_version_seen'");
    if (!seen || seen.value !== APP_VERSION) {
      if (seen) db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('pull_seq', '0')");
      db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('app_version_seen', ?)", [APP_VERSION]);
    }
  } catch (e) { noteStartProblem('version', e); }
  const seeded = db().get("SELECT value FROM settings WHERE key = 'seeded'");
  if (!seeded || seeded.value !== '1') setVersionAndSeed(seed);
  else db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('schema_version', ?)", [String(SCHEMA_VERSION)]);
  // Easy Buys sections: shops, leave types and default rules (only adds what is missing).
  db().transaction(() => {
    fillMissingUids();
    seedEasyBuys();
  });
  // v3.5: S2 is Tukani Street, the third shop is not an operating shop, closed-shop bills move to their cost area.
  try { db().transaction(() => { migrateShops35(); }); } catch (e) { /* tried again on the next start */ }
  // v3.6: business settings kept on one device are shared with every device (once; main tablet only).
  try { if (getSetting('business_settings_shared') !== '1') { shareBusinessSettings(); db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('business_settings_shared', '1')"); } } catch (e) { /* next start */ }
}

// Version 2 -> 3. The users table is rebuilt so it can hold the new roles
// (staff, shop manager, payroll, owner) and staff details. Every row and every id is kept,
// so shifts, batches and transactions still point to the same people.
function upgradeFrom2() {
  const cols = db().all('PRAGMA table_info(users)').map((c) => c.name);
  if (cols.includes('uid')) return; // already upgraded
  db().exec('PRAGMA foreign_keys = OFF;');
  try {
    db().transaction(() => {
      db().exec(`CREATE TABLE users_v3 (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        pin TEXT NOT NULL,
        username TEXT,
        password_hash TEXT,
        role TEXT NOT NULL CHECK (role IN ('staff','worker','supervisor','manager','payroll','admin','owner')),
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        sync_status TEXT NOT NULL DEFAULT 'pending',
        uid TEXT,
        employee_no TEXT,
        shop_code TEXT,
        phone TEXT,
        uses_clock INTEGER NOT NULL DEFAULT 1,
        face TEXT,
        face_at TEXT,
        face_by TEXT,
        updated_device TEXT
      );`);
      db().exec(`INSERT INTO users_v3 (id, name, pin, username, password_hash, role, active, created_at, updated_at, sync_status, shop_code)
                 SELECT id, name, pin, username, password_hash, role, active, created_at, updated_at, 'pending', 'BAKERY' FROM users;`);
      db().exec('DROP TABLE users;');
      db().exec('ALTER TABLE users_v3 RENAME TO users;');
      markSampleLogins(); // Admin 1111 etc. stay on this tablet only
      const bad = db().all('PRAGMA foreign_key_check');
      if (bad.length) throw new Error(`Upgrade stopped: ${bad.length} broken links found. Nothing was changed.`);
    });
  } finally {
    db().exec('PRAGMA foreign_keys = ON;');
  }
}

// Admin "Reset to sample data": wipes everything and reloads the demo data.
export function resetDatabase() {
  dropAll();
  db().exec(SCHEMA_SQL);
  db().exec(V3_SQL);
  db().exec(PAYABLES_SQL);
  db().exec(RECURRING_SQL);
  db().exec(TILL_SQL);
  db().exec(BANK_SQL);
  db().exec(PAYROLL_SQL);
  db().exec(INVENTORY_SQL);
  MORE_SQL.forEach((sql) => { try { db().exec(sql); } catch (e) { noteStartProblem('tables', e); } });
  try { ensureColumns(); } catch (e) { noteStartProblem('columns', e); }
  speedIndexes();
  allowNewRoles();
  setVersionAndSeed(true);
  db().transaction(() => {
    fillMissingUids();
    seedEasyBuys();
  });
}

// Admin "Start fresh": removes all sample activity but keeps setup if requested.
export function clearActivity() {
  db().transaction(() => {
    for (const t of ['outbox', 'alerts', 'photos', 'lot_usage', 'lots', 'checklist_entries', 'checklist_runs', 'equipment_log', 'purchase_orders',
      'production_plan', 'batch_steps', 'batch_ingredients', 'batches', 'transactions', 'shift_stock', 'shift_workers', 'shifts']) {
      db().run(`DELETE FROM ${t}`);
    }
    db().run('UPDATE materials SET reorder_alerted_at = NULL');
    db().run('UPDATE equipment SET service_alerted_at = NULL');
  });
}

// v1.0: the users table only allowed the old roles. Rebuilt once (every column and row kept) to allow "accountant".
export function allowNewRoles() {
  const t = db().get("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'");
  if (!t || !t.sql || t.sql.includes("'accountant'") || !t.sql.includes("'payroll','admin','owner'")) return false;
  const cols = db().all('PRAGMA table_info(users)').map((c) => `"${c.name}"`).join(', ');
  const create = t.sql.replace(/CREATE TABLE\s+"?users"?/i, 'CREATE TABLE users_v4').replace("'payroll','admin','owner'", "'payroll','accountant','admin','owner'");
  db().exec('PRAGMA foreign_keys = OFF;');
  try {
    db().transaction(() => {
      db().exec('DROP TABLE IF EXISTS users_v4;');
      db().exec(create);
      db().exec(`INSERT INTO users_v4 (${cols}) SELECT ${cols} FROM users;`);
      const a = db().get('SELECT COUNT(*) AS n FROM users').n;
      const b = db().get('SELECT COUNT(*) AS n FROM users_v4').n;
      if (a !== b) throw new Error('Upgrade stopped: the staff list did not copy fully. Nothing was changed.');
      db().exec('DROP TABLE users;');
      db().exec('ALTER TABLE users_v4 RENAME TO users;');
      db().exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_uid ON users(uid);');
    });
  } finally { db().exec('PRAGMA foreign_keys = ON;'); }
  return true;
}

function noteStartProblem(where, e) {
  try { require('../services/errorLog.js').logError(e, { where: `start-up ${where}` }); } catch (x) { /* the log itself is not ready */ }
}

function speedIndexes() {
  let list = [];
  try { list = require('./moreSchemas.js').SPEED_INDEXES || []; } catch (e) { list = []; }
  for (const sql of list) { try { db().exec(sql); } catch (e) { /* a table this device does not have yet */ } }
}
