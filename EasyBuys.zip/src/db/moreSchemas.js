// Tables of the modules added in version 3.2 (one place, so init and sync pick them up together).
import { VERIFY_SQL, VERIFY_SYNC } from '../modules/verify/schema.js';
import { ACCOUNTING_SQL, ACCOUNTING_SYNC } from '../modules/accounting/schema.js';
import { STAT_SQL, STAT_SYNC } from '../modules/payroll/statutory.js';
import { ROSTER_SQL, ROSTER_SYNC } from '../modules/timesheets/roster.js';
import { PEOPLE_SQL, PEOPLE_SYNC } from '../modules/people/service.js';

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });

// Safe counts (the cash kept at a shop counted against what the app says) and supplier statement checks.
const SMALL_SQL = `
CREATE TABLE IF NOT EXISTS safe_counts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  count_date TEXT NOT NULL,
  denominations TEXT,
  counted REAL NOT NULL,
  expected REAL NOT NULL,
  diff REAL NOT NULL,
  note TEXT,
  witness TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  adjust_uid TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS supplier_statements (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  statement_date TEXT NOT NULL,
  their_balance REAL NOT NULL,
  our_balance REAL NOT NULL,
  diff REAL NOT NULL,
  note TEXT,
  photo_urls TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SMALL_SYNC = {
  safe_counts: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'count_date', 'denominations', 'counted', 'expected', 'diff', 'note', 'witness', 'by_name', 'by_uid', 'created_at', 'adjust_uid']),
  supplier_statements: SYNC('uid', 'Invoices', ['uid', 'supplier_uid', 'statement_date', 'their_balance', 'our_balance', 'diff', 'note', 'photo_urls', 'by_name', 'created_at']),
};

export const MORE_SQL = [VERIFY_SQL, SMALL_SQL, ACCOUNTING_SQL, STAT_SQL, ROSTER_SQL, PEOPLE_SQL];
export const MORE_SYNC = { ...VERIFY_SYNC, ...SMALL_SYNC, ...ACCOUNTING_SYNC, ...STAT_SYNC, ...ROSTER_SYNC, ...PEOPLE_SYNC };
