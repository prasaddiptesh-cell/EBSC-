// Tables of the modules added in version 3.2 (one place, so init and sync pick them up together).
import { VERIFY_SQL, VERIFY_SYNC } from '../modules/verify/schema.js';
import { ACCOUNTING_SQL, ACCOUNTING2_SQL, ACCOUNTING_SYNC } from '../modules/accounting/schema.js';
import { STAT_SQL, STAT_SYNC } from '../modules/payroll/statutory.js';
import { ROSTER_SQL, ROSTER_SYNC } from '../modules/timesheets/roster.js';
import { PEOPLE_SQL, PEOPLE_SYNC } from '../modules/people/service.js';
import { DOCS_SQL, DOCS_SYNC } from '../services/documents.js';
import { LIC_SQL, LIC_SYNC } from '../modules/licences/service.js';
import { HEALTH_SQL } from '../services/health.js';
import { BANK35_SQL, BANK35_SYNC } from '../modules/bank/schema35.js';
import { PURCHASING35_SQL, PURCHASING35_SYNC } from '../modules/inventory/schema35.js';
import { TILL35_SQL, TILL35_SYNC } from '../modules/till/schema35.js';
import { OWED_SQL, OWED_SYNC } from '../modules/owed/schema.js';
import { LOANS_SQL, LOANS_SYNC } from '../modules/loans/schema.js';
import { DRAWINGS_SQL, DRAWINGS_SYNC } from '../modules/drawings/schema.js';

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });

// Safe counts (the cash kept at a shop counted against what the app says) and supplier statement checks.
const SMALL_SQL = `
CREATE TABLE IF NOT EXISTS safe_counts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  count_date TEXT NOT NULL,
  denominations TEXT,
  counted REAL NOT NULL,
  expected REAL NOT NULL,
  diff REAL NOT NULL,
  note TEXT,
  witness TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  adjust_uid TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS supplier_statements (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  statement_date TEXT NOT NULL,
  their_balance REAL NOT NULL,
  our_balance REAL NOT NULL,
  diff REAL NOT NULL,
  note TEXT,
  photo_urls TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SMALL_SYNC = {
  safe_counts: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'count_date', 'denominations', 'counted', 'expected', 'diff', 'note', 'witness', 'by_name', 'by_uid', 'created_at', 'adjust_uid']),
  supplier_statements: SYNC('uid', 'Invoices', ['uid', 'supplier_uid', 'statement_date', 'their_balance', 'our_balance', 'diff', 'note', 'photo_urls', 'by_name', 'created_at']),
};

export const MORE_SQL = [VERIFY_SQL, SMALL_SQL, ACCOUNTING_SQL, STAT_SQL, ROSTER_SQL, PEOPLE_SQL, DOCS_SQL, LIC_SQL, ACCOUNTING2_SQL, HEALTH_SQL, BANK35_SQL, PURCHASING35_SQL, TILL35_SQL, OWED_SQL, LOANS_SQL, DRAWINGS_SQL];
export const MORE_SYNC = { ...VERIFY_SYNC, ...SMALL_SYNC, ...ACCOUNTING_SYNC, ...STAT_SYNC, ...ROSTER_SYNC, ...PEOPLE_SYNC, ...DOCS_SYNC, ...LIC_SYNC, ...BANK35_SYNC, ...PURCHASING35_SYNC, ...TILL35_SYNC, ...OWED_SYNC, ...LOANS_SYNC, ...DRAWINGS_SYNC };
