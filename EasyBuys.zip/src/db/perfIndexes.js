// 1.0.0 speed work (3 years of data): indexes for the look-ups the app makes most, so a screen never reads a whole
// table to find a few rows. Added on every phone at start (CREATE INDEX IF NOT EXISTS – nothing else changes), then
// SQLite's statistics are brought up to date once (ANALYZE: about a second on 3 years of data), which lets it
// pick the best index for each query. PERF_INDEX_VERSION goes up whenever this list changes: the statistics are then
// worked out again once.
import { db } from './connection.js';

export const PERF_INDEX_VERSION = '1';
export const PERF_INDEXES = [
  // a credit note: how much of it was used (every invoice list, getInvoice, aged report, VAT on purchases, loans)
  'CREATE INDEX IF NOT EXISTS ix_app_credit ON ap_payments(credit_uid) WHERE credit_uid IS NOT NULL',
  'CREATE INDEX IF NOT EXISTS ix_app_cheque ON ap_payments(cheque_uid) WHERE cheque_uid IS NOT NULL',
  // photos of a record (cheque stubs, invoices, deliveries …)
  'CREATE INDEX IF NOT EXISTS ix_photos_ref ON photos(ref_type, ref_id)',
  // the deposit a bank line was matched to (bank history, reconciliation, the books)
  'CREATE INDEX IF NOT EXISTS ix_dep_bank ON deposits(bank_entry_uid) WHERE bank_entry_uid IS NOT NULL',
  // the Aronium feed by till PC (link status, tills today, End of day)
  'CREATE INDEX IF NOT EXISTS ix_arfeed_source ON aronium_feed(source, kind, updated_at)',
  // M-PAiSA lines of a wallet in date and time order
  'CREATE INDEX IF NOT EXISTS ix_wl_kind ON wallet_lines(wallet_uid, kind, line_date, line_time)',
  'CREATE INDEX IF NOT EXISTS ix_wl_status ON wallet_lines(wallet_uid, status, kind)',
  // cost changes made by a delivery / not seen yet / by date
  'CREATE INDEX IF NOT EXISTS ix_icc_ref ON inv_cost_changes(ref_uid)',
  'CREATE INDEX IF NOT EXISTS ix_icc_date ON inv_cost_changes(change_date)',
  'CREATE INDEX IF NOT EXISTS ix_icc_unseen ON inv_cost_changes(item_uid) WHERE seen_at IS NULL',
  // Aronium product changes of a product (product watch: "the price changed after the cost went up?")
  'CREATE INDEX IF NOT EXISTS ix_pc_code ON product_changes(code, kind, change_date)',
  'CREATE INDEX IF NOT EXISTS ix_pc_codeshop ON product_changes(code, shop_code, kind, at)',
  // stock: the last sale / delivery / count of a product in a shop, and its stock on hand, from the index alone
  'CREATE INDEX IF NOT EXISTS ix_invm_itype ON inv_moves(item_uid, shop_code, type, move_date, status, qty)',
  // stock moves of a period (the movements report, part of a month in the books)
  'CREATE INDEX IF NOT EXISTS ix_invm_date ON inv_moves(move_date, shop_code)',
];

// Records still to be sent to the cloud: one small index per big table, so "how many are waiting" never reads the table.
export const PENDING_INDEX_TABLES = ['inv_moves', 'wallet_lines', 'audit_log', 'inv_cost_changes', 'aronium_feed', 'photos', 'transactions', 'punches',
  'inv_count_entries', 'batch_ingredients', 'batch_steps', 'lot_usage', 'cash_moves', 'bank_lines', 'checklist_entries', 'inv_count_lines', 'ap_invoices',
  'ap_payments', 'ap_allocations', 'inv_receipts', 'shift_stock', 'till_counts', 'till_shifts', 'aronium_eods', 'cheques', 'po_lines', 'bank_entries',
  'cheque_cover', 'product_changes', 'batches', 'checklist_runs', 'inv_item_shops', 'alert_log'];

// Is there anything for perfIndexes() to do (an index missing, or the statistics not made for this list yet)?
export function perfIndexesNeeded() {
  let seen = null;
  try { const r = db().get("SELECT value FROM settings WHERE key = 'perf_index_version'"); seen = r && r.value; } catch (e) { seen = null; }
  if (seen !== PERF_INDEX_VERSION) return true;
  const list = PERF_INDEXES.concat(PENDING_INDEX_TABLES.map((t) => `CREATE INDEX IF NOT EXISTS ix_pend_${t} ON ${t}(sync_status) WHERE sync_status = 'pending'`));
  for (const sql of list) {
    const name = /INDEX IF NOT EXISTS (\w+) ON (\w+)/.exec(sql);
    try {
      if (!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [name[2]])) continue; // a table this device does not have
      if (!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'index' AND name = ?", [name[1]])) return true;
    } catch (e) { /* asked again at the next start */ }
  }
  return false;
}
export function perfIndexes() {
  const list = PERF_INDEXES.concat(PENDING_INDEX_TABLES.map((t) => `CREATE INDEX IF NOT EXISTS ix_pend_${t} ON ${t}(sync_status) WHERE sync_status = 'pending'`));
  let made = 0;
  for (const sql of list) {
    try {
      const name = /INDEX IF NOT EXISTS (\w+)/.exec(sql)[1];
      if (db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'index' AND name = ?", [name])) continue;
      db().exec(sql); made += 1;
    } catch (e) { /* a table this device does not have yet */ }
  }
  // statistics: once per version of this list (and whenever an index was added), sampled so it stays quick
  let seen = null;
  try { const r = db().get("SELECT value FROM settings WHERE key = 'perf_index_version'"); seen = r && r.value; } catch (e) { seen = null; }
  if (made || seen !== PERF_INDEX_VERSION) {
    try { db().exec('PRAGMA analysis_limit = 0; ANALYZE;'); } catch (e) { /* statistics are only a help */ }
    try { db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('perf_index_version', ?)", [PERF_INDEX_VERSION]); } catch (e) { /* next start */ }
  }
  return made;
}
