// Database structure (version 3 = Bakery v2 + Easy Buys sections).
// Every record carries a location and a sync status so the data can be sent
// to the cloud and later combined with the other Easy Buys locations.

export const SCHEMA_VERSION = 3;

export const ALL_TABLES = [
  'audit_log', 'shared_settings', 'leave_requests', 'leave_entitlements', 'leave_types', 'timesheet_checks', 'punches', 'shops',
  'outbox', 'purchase_orders', 'alerts', 'equipment_log', 'equipment', 'checklist_entries', 'checklist_runs', 'checklist_items', 'checklists', 'production_plan', 'lot_usage', 'lots', 'photos', 'batch_steps', 'batch_ingredients', 'batches', 'transactions',
  'shift_stock', 'shift_workers', 'shifts', 'product_decks', 'product_steps', 'steps', 'shift_names', 'recipes',
  'products', 'materials', 'suppliers', 'users', 'settings', 'production',
];

export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  pin TEXT NOT NULL,
  username TEXT,
  password_hash TEXT,
  role TEXT NOT NULL CHECK (role IN ('staff','worker','supervisor','manager','payroll','admin','owner')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending',
  uid TEXT,
  employee_no TEXT,
  shop_code TEXT,
  phone TEXT,
  uses_clock INTEGER NOT NULL DEFAULT 1,
  face TEXT,
  face_at TEXT,
  face_by TEXT,
  updated_device TEXT
);

CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact TEXT,
  phone TEXT,
  email TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS materials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT,
  unit TEXT NOT NULL,
  kg_per_unit REAL NOT NULL DEFAULT 1,
  track_stock INTEGER NOT NULL DEFAULT 1,
  stock REAL NOT NULL DEFAULT 0,
  tolerance_pct REAL,
  reorder_level REAL NOT NULL DEFAULT 0,
  reorder_qty REAL NOT NULL DEFAULT 0,
  supplier_id INTEGER,
  cost_per_unit REAL,
  cost_updated_at TEXT,
  reorder_alerted_at TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  location TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT,
  unit TEXT NOT NULL,
  flour_material_id INTEGER REFERENCES materials(id),
  cut_weight_g REAL NOT NULL DEFAULT 0,
  cut_tolerance_g REAL NOT NULL DEFAULT 0,
  max_flour_kg REAL NOT NULL DEFAULT 25,
  default_flour_kg REAL NOT NULL DEFAULT 0,
  flag_pct REAL,
  prep_note TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Oven temperatures for each product on each deck: top and bottom element (decks are named in Settings).
CREATE TABLE IF NOT EXISTS product_decks (
  product_id INTEGER NOT NULL REFERENCES products(id),
  deck TEXT NOT NULL,
  top_c REAL,
  bottom_c REAL,
  PRIMARY KEY (product_id, deck)
);

-- Baker's percentages: quantity of material per 1 kg of flour, expressed as % of flour weight.
CREATE TABLE IF NOT EXISTS recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id),
  material_id INTEGER NOT NULL REFERENCES materials(id),
  pct REAL NOT NULL,
  flag_pct REAL,
  updated_at TEXT NOT NULL,
  UNIQUE (product_id, material_id)
);

CREATE TABLE IF NOT EXISTS shift_names (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

-- Production steps after mixing (e.g. Cutting, Proofing, Baking). Mixing is always first.
CREATE TABLE IF NOT EXISTS steps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'normal' CHECK (kind IN ('normal','cut','bake')),
  sort INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

-- Standard minutes per product, per step and per flour band (batch size).
-- step_id 0 = mixing. band 0 = smallest batches (see Settings → flour bands).
CREATE TABLE IF NOT EXISTS product_steps (
  product_id INTEGER NOT NULL REFERENCES products(id),
  step_id INTEGER NOT NULL,
  band INTEGER NOT NULL DEFAULT 0,
  minutes REAL,
  PRIMARY KEY (product_id, step_id, band)
);

CREATE TABLE IF NOT EXISTS shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  shift_date TEXT NOT NULL,
  shift_name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('open','closed','approved')),
  location TEXT,
  opened_by INTEGER REFERENCES users(id),
  opened_at TEXT NOT NULL,
  closed_by INTEGER REFERENCES users(id),
  closed_at TEXT,
  close_notes TEXT,
  approved_by INTEGER REFERENCES users(id),
  approved_at TEXT,
  approval_notes TEXT,
  report_sent_at TEXT,
  updated_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS shift_workers (
  shift_id INTEGER NOT NULL REFERENCES shifts(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  signed_on_at TEXT NOT NULL,
  signed_on_recorded_at TEXT NOT NULL,
  signed_off_at TEXT,
  signed_off_recorded_at TEXT,
  signed_off_by INTEGER,
  PRIMARY KEY (shift_id, user_id)
);

CREATE TABLE IF NOT EXISTS shift_stock (
  shift_id INTEGER NOT NULL REFERENCES shifts(id),
  material_id INTEGER NOT NULL REFERENCES materials(id),
  system_opening REAL NOT NULL DEFAULT 0,
  opening REAL NOT NULL DEFAULT 0,
  received REAL, used REAL, wasted REAL, adjusted REAL,
  expected REAL, actual REAL, variance REAL,
  tolerance_pct REAL, over_tolerance INTEGER, reason TEXT,
  PRIMARY KEY (shift_id, material_id)
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_id TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL,
  location TEXT,
  shift_id INTEGER REFERENCES shifts(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  material_id INTEGER REFERENCES materials(id),
  product_id INTEGER REFERENCES products(id),
  batch_id INTEGER,
  qty REAL NOT NULL DEFAULT 0,
  expected_qty REAL,
  variance REAL,
  supplier TEXT,
  supplier_id INTEGER,
  invoice_no TEXT,
  unit_cost REAL,
  lot_no TEXT,
  expiry TEXT,
  check_note TEXT,
  ref TEXT,
  note TEXT,
  txn_date TEXT NOT NULL,
  txn_time TEXT NOT NULL,
  created_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  txn_id TEXT NOT NULL,
  location TEXT,
  shift_id INTEGER NOT NULL REFERENCES shifts(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  status TEXT NOT NULL CHECK (status IN ('active','finished')),
  flour_kg REAL NOT NULL,
  dough_kg REAL NOT NULL,
  cut_weight_g REAL NOT NULL,
  expected_pieces REAL NOT NULL,
  cut_pieces REAL,
  cut_counted_at TEXT,
  cut_counted_by INTEGER,
  water_temp REAL,
  deck TEXT,
  current_step INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  finished_by INTEGER,
  good REAL, damaged REAL, rejected REAL, other_waste REAL,
  comments TEXT,
  created_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS batch_ingredients (
  batch_id INTEGER NOT NULL REFERENCES batches(id),
  material_id INTEGER NOT NULL REFERENCES materials(id),
  pct REAL,
  expected REAL NOT NULL,
  actual REAL NOT NULL,
  diff_pct REAL,
  flagged INTEGER NOT NULL DEFAULT 0,
  unit_cost REAL,
  PRIMARY KEY (batch_id, material_id)
);

-- Stock lots (from deliveries) used oldest-expiry-first, for traceability and expiry alerts.
CREATE TABLE IF NOT EXISTS lots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  material_id INTEGER NOT NULL REFERENCES materials(id),
  lot_no TEXT,
  expiry TEXT,
  supplier_id INTEGER,
  invoice_no TEXT,
  txn_id TEXT,
  qty_received REAL NOT NULL,
  qty_left REAL NOT NULL,
  unit_cost REAL,
  received_at TEXT NOT NULL,
  expiry_alerted_at TEXT
);

-- Which lots went into which batch (or wastage / other use).
CREATE TABLE IF NOT EXISTS lot_usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lot_id INTEGER NOT NULL REFERENCES lots(id),
  material_id INTEGER NOT NULL,
  batch_id INTEGER,
  txn_id TEXT,
  qty REAL NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS production_plan (
  plan_date TEXT NOT NULL,
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty REAL NOT NULL,
  updated_by INTEGER,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (plan_date, product_id)
);

-- Checklists built by the Admin. when: start | end | daily.  scope: person | shift.
CREATE TABLE IF NOT EXISTS checklists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  when_due TEXT NOT NULL CHECK (when_due IN ('start','end','daily')),
  scope TEXT NOT NULL CHECK (scope IN ('person','shift')),
  sort INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS checklist_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  checklist_id INTEGER NOT NULL REFERENCES checklists(id),
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('tick','temp','photo')),
  min_value REAL,
  max_value REAL,
  sort INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
-- One run = one checklist done by one person (scope person) or for the shift/day.
CREATE TABLE IF NOT EXISTS checklist_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  checklist_id INTEGER NOT NULL REFERENCES checklists(id),
  shift_id INTEGER,
  user_id INTEGER,
  run_date TEXT NOT NULL,
  created_at TEXT NOT NULL,
  completed_at TEXT
);
CREATE TABLE IF NOT EXISTS checklist_entries (
  run_id INTEGER NOT NULL REFERENCES checklist_runs(id),
  item_id INTEGER NOT NULL REFERENCES checklist_items(id),
  status TEXT NOT NULL CHECK (status IN ('done','skipped')),
  value REAL,
  out_of_range INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  photo TEXT,
  user_id INTEGER NOT NULL,
  at TEXT NOT NULL,
  PRIMARY KEY (run_id, item_id)
);

CREATE TABLE IF NOT EXISTS equipment (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  service_days INTEGER NOT NULL DEFAULT 90,
  last_service_at TEXT,
  service_alerted_at TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS equipment_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id INTEGER NOT NULL REFERENCES equipment(id),
  type TEXT NOT NULL CHECK (type IN ('fault','repair','service')),
  note TEXT NOT NULL,
  cost REAL,
  user_id INTEGER NOT NULL,
  at TEXT NOT NULL,
  resolved_at TEXT,
  resolved_by INTEGER,
  fault_id INTEGER
);

-- One row per step of a batch, in order. idx 0 = mixing.
CREATE TABLE IF NOT EXISTS batch_steps (
  batch_id INTEGER NOT NULL REFERENCES batches(id),
  idx INTEGER NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  minutes REAL,
  planned_at TEXT,
  due_at TEXT,
  started_at TEXT,
  started_by INTEGER,
  snooze_min REAL NOT NULL DEFAULT 0,
  snooze_count INTEGER NOT NULL DEFAULT 0,
  notif_id TEXT,
  PRIMARY KEY (batch_id, idx)
);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'warn',
  shift_id INTEGER,
  batch_id INTEGER,
  user_id INTEGER,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL,
  ack_by INTEGER,
  ack_at TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref_type TEXT NOT NULL,
  ref_id TEXT NOT NULL,
  uri TEXT NOT NULL,
  created_at TEXT NOT NULL,
  cloud_url TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Purchase orders raised automatically when stock reaches the minimum level.
CREATE TABLE IF NOT EXISTS purchase_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  po_no TEXT NOT NULL UNIQUE,
  supplier_id INTEGER,
  supplier TEXT,
  supplier_email TEXT,
  items TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  created_at TEXT NOT NULL,
  created_by INTEGER,
  sent_at TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Messages waiting to be sent to the cloud (works offline; sent when online).
CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  sent_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_txn_shift ON transactions(shift_id);
CREATE INDEX IF NOT EXISTS idx_txn_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_txn_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_batch_shift ON batches(shift_id);
CREATE INDEX IF NOT EXISTS idx_alert_shift ON alerts(shift_id);
CREATE INDEX IF NOT EXISTS idx_outbox_sent ON outbox(sent_at);
`;

// ================= Version 3: Easy Buys sections (Time Clock, Timesheets, Leave) =================
// These tables are shared between the tablet and the owners' phones through the cloud.
// Every row has a text id (uid) that is the same on every device, plus updated_at / updated_device
// so the newest change wins, and sync_status ('pending' = not yet sent).
export const V3_SQL = `
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_uid ON users(uid);

CREATE TABLE IF NOT EXISTS shops (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Clock In / Out / breaks. Never deleted: a wrong punch is voided with a reason.
CREATE TABLE IF NOT EXISTS punches (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('IN','OUT','BREAK_START','BREAK_END')),
  at TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  shop_code TEXT,
  device TEXT,
  method TEXT NOT NULL DEFAULT 'pin',
  face_result TEXT,
  face_distance REAL,
  photo_uri TEXT,
  photo_url TEXT,
  reason TEXT,
  created_by_uid TEXT,
  voided INTEGER NOT NULL DEFAULT 0,
  void_reason TEXT,
  voided_by_uid TEXT,
  voided_at TEXT,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_punch_user ON punches(user_uid, at);
CREATE INDEX IF NOT EXISTS idx_punch_at ON punches(at);

-- A manager's "week checked" sign-off for one person's Saturday-Friday week.
CREATE TABLE IF NOT EXISTS timesheet_checks (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  week_start TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'checked',
  checked_by_uid TEXT,
  checked_by_name TEXT,
  checked_at TEXT,
  note TEXT,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS leave_types (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  paid INTEGER NOT NULL DEFAULT 1,
  default_days REAL NOT NULL DEFAULT 0,
  needs_photo INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Days allowed per person, type and year (overrides the leave type's default).
CREATE TABLE IF NOT EXISTS leave_entitlements (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  type TEXT NOT NULL,
  year INTEGER NOT NULL,
  days REAL NOT NULL,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS leave_requests (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  from_date TEXT NOT NULL,
  to_date TEXT NOT NULL,
  days REAL NOT NULL,
  reason TEXT,
  photo_uri TEXT,
  photo_url TEXT,
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','approved','declined','cancelled')),
  requested_by_uid TEXT,
  requested_at TEXT NOT NULL,
  decided_by_uid TEXT,
  decided_by_name TEXT,
  decided_at TEXT,
  decision_note TEXT,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_leave_user ON leave_requests(user_uid, from_date);

-- Admin settings that are the same on every device (roles, Time Clock rules, leave rules...).
CREATE TABLE IF NOT EXISTS shared_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Who changed what, when, on which device, and why. Never edited or deleted.
CREATE TABLE IF NOT EXISTS audit_log (
  uid TEXT PRIMARY KEY,
  at TEXT NOT NULL,
  user_uid TEXT,
  user_name TEXT,
  device TEXT,
  action TEXT NOT NULL,
  table_name TEXT,
  record_uid TEXT,
  before TEXT,
  after TEXT,
  reason TEXT,
  updated_at TEXT NOT NULL,
  updated_device TEXT,
  sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(at);
`;
