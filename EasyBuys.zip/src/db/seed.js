// Sample data so the app can be tested immediately.
// Sample logins:  Admin PIN 1111 (username admin / password admin123)
//                 Supervisor PIN 2222 (username sita / password sita123)
//                 Bakers PIN 3333 (Ravi) and 4444 (Mere)
import { db } from './connection.js';
import { clock, setSetting } from '../services/core.js';
import { saveUser, saveMaterial, saveProductFull, saveShiftNames, saveSteps, listSteps, saveSupplier, listMaterials } from '../services/catalog.js';
import { startShift, signOn, recordReceive, recordWastage, closeShift, approveShift, getBalanceSheet } from '../services/shifts.js';
import { startBatch, planBatch, confirmNextStep, finishBatch, recordCutCount } from '../services/batches.js';
import { ackAllAlerts } from '../services/stock.js';
import { saveChecklist, myChecklists, openRun, answerItem } from '../services/checklists.js';
import { saveEquipment, reportFault, recordWork } from '../services/equipment.js';
import { savePlan } from '../services/plan.js';
import { dateStr } from '../services/core.js';

export function seedSampleData() {
  setSetting('bakery_name', 'Easy Buys Bakery');
  setSetting('location_name', 'Bakery');
  setSetting('default_flag_pct', '2');
  setSetting('default_tolerance_pct', '2');
  setSetting('show_demo_pins', '1');
  setSetting('report_emails', '[]');
  setSetting('po_emails', '[]');
  setSetting('po_auto', '1');

  const y = new Date();
  y.setDate(y.getDate() - 1);
  const at = (h, m) => { const d = new Date(y); d.setHours(h, m, 0, 0); clock.override = d; };
  at(2, 0);

  try {
    const admin = saveUser({ name: 'Admin', pin: '1111', role: 'admin', username: 'admin', password: 'admin123' });
    const sup = saveUser({ name: 'Sita (Supervisor)', pin: '2222', role: 'supervisor', username: 'sita', password: 'sita123' });
    const ravi = saveUser({ name: 'Ravi', pin: '3333', role: 'worker' });
    const mere = saveUser({ name: 'Mere', pin: '4444', role: 'worker' });

    saveShiftNames([{ name: 'Early Bake' }, { name: 'Day' }, { name: 'Night Bake' }]);
    saveSteps([{ name: 'Cutting', kind: 'cut' }, { name: 'Moulding & trays' }, { name: 'Proofing' }, { name: 'Baking', kind: 'bake' }]);
    setSetting('oven_decks', JSON.stringify(['Deck 1', 'Deck 2', 'Deck 3']));
    setSetting('flour_bands', '[10,20]');
    setSetting('mix_reminder', 'While it mixes: get the trays ready and oil them.');
    const S = {};
    listSteps().forEach((s) => { S[s.name] = s.id; });

    // Sample suppliers (made-up names; replace with your real suppliers).
    const SUP = {
      flour: saveSupplier({ name: 'Island Flour Supplies', contact: 'Sales desk', phone: '000 0000', email: 'orders@example.com' }).id,
      grocer: saveSupplier({ name: 'Pacific Wholesale Grocers', contact: 'Accounts', phone: '000 0001', email: 'sales@example.com' }).id,
      dairy: saveSupplier({ name: 'Coral Dairy', contact: 'Depot', phone: '000 0002', email: 'depot@example.com' }).id,
    };

    const M = {};
    // name, unit, kg per unit, track stock, stock, tolerance %, min level, reorder qty, supplier
    const mats = [
      ['Flour', 'kg', 1, 1, 400, 2, 100, 250, SUP.flour],
      ['Water', 'L', 1, 0, 0, null, 0, 0, null],
      ['Sugar', 'kg', 1, 1, 80, 2, 20, 50, SUP.grocer],
      ['Yeast', 'kg', 1, 1, 12, 5, 3, 10, SUP.grocer],
      ['Salt', 'kg', 1, 1, 15, 5, 3, 10, SUP.grocer],
      ['Cooking Oil', 'L', 0.92, 1, 30, 3, 8, 20, SUP.grocer],
      ['Butter', 'kg', 1, 1, 25, 3, 5, 15, SUP.dairy],
      ['Milk', 'L', 1.03, 1, 30, 3, 8, 20, SUP.dairy],
      ['Eggs', 'pcs', 0.05, 1, 360, 2, 60, 180, SUP.grocer],
      ['Coconut (grated)', 'kg', 1, 1, 15, 3, 3, 10, SUP.grocer],
    ];
    for (const [name, unit, kg, track, stock, tol, min, rq, supplierId] of mats) {
      M[name] = saveMaterial({ name, unit, kg_per_unit: kg, track_stock: track, stock, tolerance_pct: tol, reorder_level: min, reorder_qty: rq, supplier_id: supplierId }, admin.id).id;
    }

    // Sample purchase prices (per unit) – replace with your real prices.
    const prices = { Flour: 2.1, Sugar: 2.4, Yeast: 14, Salt: 1.2, 'Cooking Oil': 4.5, Butter: 16, Milk: 3.2, Eggs: 0.55, 'Coconut (grated)': 6 };
    for (const [k, v] of Object.entries(prices)) db().run('UPDATE materials SET cost_per_unit = ?, cost_updated_at = ? WHERE id = ?', [v, '2026-01-01 00:00:00', M[k]]);

    // Checklists (edit in Admin → Checklists).
    saveChecklist({ name: 'Opening checks', when_due: 'start', scope: 'shift' }, [
      { name: 'Fridge 1 temperature', kind: 'temp', min_value: 0, max_value: 5 },
      { name: 'Freezer 1 temperature', kind: 'temp', min_value: -25, max_value: -15 },
      { name: 'Gas and ovens checked safe', kind: 'tick' },
      { name: 'Handwash station stocked (soap, towels)', kind: 'tick' },
    ]);
    saveChecklist({ name: 'End-of-shift cleaning', when_due: 'end', scope: 'person' }, [
      { name: 'Mixer bowl and hook cleaned', kind: 'tick' },
      { name: 'Dough divider cleaned', kind: 'tick' },
      { name: 'Workbench scraped and sanitised', kind: 'tick' },
      { name: 'Trays and pans washed and stacked', kind: 'tick' },
      { name: 'Ovens switched off and cleaned', kind: 'tick' },
      { name: 'Floor swept and mopped', kind: 'tick' },
      { name: 'Rubbish taken out', kind: 'tick' },
    ]);
    saveChecklist({ name: 'Daily fridge & freezer log (afternoon)', when_due: 'daily', scope: 'shift' }, [
      { name: 'Fridge 1 temperature', kind: 'temp', min_value: 0, max_value: 5 },
      { name: 'Freezer 1 temperature', kind: 'temp', min_value: -25, max_value: -15 },
    ]);

    // Equipment (edit in Admin → Equipment).
    const EQ = {};
    const ago = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return `${dateStr(d)} 09:00:00`; };
    const ahead = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return dateStr(d); };
    for (const [name, days] of [['Oven 1', 90], ['Oven 2', 90], ['Spiral mixer', 60], ['Dough divider', 60], ['Proofer', 120], ['Fridge 1', 180], ['Freezer 1', 180]]) {
      EQ[name] = saveEquipment({ name, service_days: days, last_service_at: ago(name === 'Spiral mixer' ? 62 : 40) }).id;
    }

    // Baker's percentages: each ingredient as % of the flour weight.
    const P = {};
    const product = (name, unit, cut, cutTol, maxFlour, defFlour, recipe, times, decks) => saveProductFull(
      { name, unit, flour_material_id: M.Flour, cut_weight_g: cut, cut_tolerance_g: cutTol, max_flour_kg: maxFlour, default_flour_kg: defFlour },
      recipe.map(([mat, pct]) => ({ material_id: M[mat], pct })),
      times,
      { 'Deck 1': { top: decks[0], bottom: decks[0] - 20 }, 'Deck 2': { top: decks[1], bottom: decks[1] - 15 }, 'Deck 3': { top: decks[2], bottom: decks[2] - 25 } }
    ).id;
    P.bread = product('White Bread Loaf', 'loaves', 600, 10, 25, 20,
      [['Water', 60], ['Sugar', 4], ['Yeast', 2], ['Salt', 2], ['Cooking Oil', 3]],
      { 0: [10, 13, 16], [S.Cutting]: [10, 18, 25], [S['Moulding & trays']]: [8, 15, 20], [S.Proofing]: [45, 45, 45], [S.Baking]: [30, 30, 32] }, [200, 210, 190]);
    P.rolls = product('Dinner Rolls', 'pcs', 50, 3, 15, 10,
      [['Water', 55], ['Sugar', 8], ['Yeast', 2], ['Salt', 1.8], ['Butter', 8], ['Milk', 10]],
      { 0: [10, 12, 14], [S.Cutting]: [15, 25, 35], [S['Moulding & trays']]: [10, 15, 20], [S.Proofing]: [40, 40, 40], [S.Baking]: [15, 15, 15] }, [190, 200, 185]);
    P.cream = product('Cream Buns', 'pcs', 70, 4, 15, 8,
      [['Water', 50], ['Sugar', 12], ['Yeast', 2.5], ['Salt', 1.5], ['Butter', 10], ['Eggs', 10]],
      { 0: [10, 12, 14], [S.Cutting]: [15, 20, 28], [S['Moulding & trays']]: [10, 15, 20], [S.Proofing]: [45, 45, 45], [S.Baking]: [18, 18, 18] }, [180, 190, 175]);
    P.coconut = product('Coconut Buns', 'pcs', 80, 4, 15, 8,
      [['Water', 52], ['Sugar', 15], ['Yeast', 2], ['Salt', 1.2], ['Coconut (grated)', 12], ['Cooking Oil', 5]],
      { 0: [10, 12, 14], [S.Cutting]: [15, 20, 28], [S['Moulding & trays']]: [10, 15, 20], [S.Proofing]: [45, 45, 45], [S.Baking]: [20, 20, 20] }, [185, 195, 180]);
    P.cake = product('Butter Cake', 'cakes', 900, 20, 10, 4,
      [['Sugar', 100], ['Butter', 100], ['Eggs', 100], ['Milk', 30]],
      { 0: [15, 20, 25], [S.Baking]: [45, 50, 55] }, [170, 175, 165]);

    // ---- One completed, approved sample shift (yesterday) so reports and the dashboard have data ----
    at(3, 0);
    const opening = {};
    listMaterials({ stockOnly: true }).forEach((m) => { opening[m.id] = m.stock; });
    opening[M.Eggs] = 354;
    const shift = startShift(ravi.id, 'Early Bake', opening);
    at(3, 5);
    const fill = (userId, name, values = {}) => {
      const list = myChecklists(userId).find((c) => c.name === name);
      const run = openRun(list.id, userId);
      run.items.forEach((it) => answerItem(run.run.id, it.id, userId, it.kind === 'temp' ? { value: values[it.name] } : { done: true }));
    };
    fill(ravi.id, 'Opening checks', { 'Fridge 1 temperature': 3.5, 'Freezer 1 temperature': -18 });
    at(3, 25); signOn(mere.id);

    // White bread: Ravi adds a little extra water (flagged), cuts 56, gets 54 good.
    at(3, 15);
    const plan = planBatch(P.bread, 20);
    const actual = {};
    plan.lines.forEach((l) => { actual[l.material_id] = l.expected; });
    actual[M.Water] = 12.5;
    const b1 = startBatch(ravi.id, P.bread, 20, actual, { waterTemp: 28 });
    at(3, 31); confirmNextStep(ravi.id, b1.id);
    at(3, 52); confirmNextStep(ravi.id, b1.id, { cutPieces: 56 });
    at(4, 8); confirmNextStep(ravi.id, b1.id);
    at(4, 55); confirmNextStep(ravi.id, b1.id, { deck: 'Deck 1' });
    at(5, 27); finishBatch(ravi.id, b1.id, { good: 54, damaged: 1, rejected: 1, otherWaste: 0, comments: 'Oven 2 slightly hot' });

    // Coconut buns by Mere, all to standard.
    at(3, 40);
    const plan2 = planBatch(P.coconut, 8);
    const act2 = {};
    plan2.lines.forEach((l) => { act2[l.material_id] = l.expected; });
    const b2 = startBatch(mere.id, P.coconut, 8, act2, { waterTemp: 27 });
    at(3, 53); confirmNextStep(mere.id, b2.id);
    at(4, 14); recordCutCount(mere.id, b2.id, 186); confirmNextStep(mere.id, b2.id);
    at(4, 29); confirmNextStep(mere.id, b2.id);
    at(5, 15); confirmNextStep(mere.id, b2.id, { deck: 'Deck 2' });
    at(5, 36); finishBatch(mere.id, b2.id, { good: 182, damaged: 2, rejected: 2, otherWaste: 0 });

    at(6, 0);
    recordReceive(sup.id, {
      supplierId: SUP.flour, invoiceNo: 'INV-4471', note: 'Morning delivery',
      lines: [{ material_id: M.Flour, qty: 100, unit_price: 2.15, lot_no: 'FL-2609-A', expiry: ahead(170) }],
      check: { packOk: true, useByOk: true },
    });
    recordReceive(sup.id, {
      supplierId: SUP.dairy, invoiceNo: 'CD-118', note: 'Dairy run',
      lines: [{ material_id: M.Milk, qty: 10, unit_price: 3.3, lot_no: 'MK-77', expiry: ahead(4) }, { material_id: M.Butter, qty: 5, line_total: 81, lot_no: 'BT-12', expiry: ahead(60) }],
      check: { packOk: true, useByOk: true, temp: 4 },
    });
    at(7, 10);
    reportFault(ravi.id, EQ['Oven 2'], 'Running about 15°C hotter than the dial says');
    at(6, 30);
    recordWastage(mere.id, M.Milk, 1.5, 'Spilled', 'Jug knocked over');

    at(10, 20);
    fill(mere.id, 'End-of-shift cleaning');
    at(10, 30);
    closeShift(mere.id, 'All trays cleaned. Oven 2 needs checking.');
    at(10, 45);
    // Ravi forgot to sign off; the supervisor enters it during balancing.
    db().run("UPDATE shift_workers SET signed_off_at = ?, signed_off_recorded_at = ?, signed_off_by = ? WHERE shift_id = ? AND user_id = ?",
      [`${y.getFullYear()}-${String(y.getMonth() + 1).padStart(2, '0')}-${String(y.getDate()).padStart(2, '0')} 10:15:00`,
        `${y.getFullYear()}-${String(y.getMonth() + 1).padStart(2, '0')}-${String(y.getDate()).padStart(2, '0')} 10:45:00`, sup.id, shift.id, ravi.id]);

    const counts = {};
    const reasons = {};
    getBalanceSheet(shift.id).forEach((r) => { counts[r.material_id] = r.expected; });
    counts[M.Flour] = Math.round((counts[M.Flour] - 4) * 1000) / 1000;
    reasons[M.Flour] = 'Spillage during mixing (not recorded)';
    counts[M.Sugar] = Math.round((counts[M.Sugar] - 0.2) * 1000) / 1000;
    approveShift(sup.id, shift.id, counts, reasons, 'Flour shortage discussed with team.');
    at(11, 0);
    ackAllAlerts(sup.id);
    recordWork(admin.id, EQ['Oven 2'], { type: 'repair', note: 'Thermostat recalibrated by technician', cost: 120 });
    // Production plans for yesterday and today.
    savePlan(admin.id, dateStr(y), { [P.bread]: 60, [P.coconut]: 180 });
    savePlan(admin.id, dateStr(new Date()), { [P.bread]: 120, [P.coconut]: 180, [P.rolls]: 200 });
  } finally {
    clock.override = null;
  }
  // Sample history is not sent to the cloud or emailed.
  db().run("UPDATE outbox SET sent_at = 'sample-data' WHERE sent_at IS NULL");
  markSampleLogins();
}

// The sample logins stay on this device only (never sent to other devices). Once someone edits one
// (e.g. changes the PIN) it becomes a real login and is shared like any other.
export function markSampleLogins() {
  db().run(`UPDATE users SET sync_status = 'seed' WHERE sync_status = 'pending' AND (
    (name = 'Admin' AND pin = '1111') OR (name = 'Sita (Supervisor)' AND pin = '2222') OR (name = 'Ravi' AND pin = '3333') OR (name = 'Mere' AND pin = '4444'))`);
}
