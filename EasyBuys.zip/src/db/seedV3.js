// Easy Buys defaults. Only adds what is missing, so it is safe to run on every start.
// Defaults are marked sync_status 'seed' with an old date: they are never sent, and any
// change an admin makes on another device always wins over them.
import { db } from './connection.js';
import { uuid } from '../services/core.js';

const OLD = '2000-01-01 00:00:00';

export const DEFAULT_SHOPS = [
  ['S1', 'Shop 1 - Drasa Avenue'],
  ['S2', 'Shop 2 - V M Pillay'],
  ['S3', 'Shop 3 - Kiran Palace'],
  ['BAKERY', 'Bakery'],
  ['LIQUOR', 'Liquor / Grocery'],
];

// Days are Easy Buys' starting values; the admin changes them in Leave > Setup.
export const DEFAULT_LEAVE_TYPES = [
  // code, name, paid, default days a year, needs a photo (e.g. medical certificate)
  ['ANNUAL', 'Annual leave', 1, 10, 0],
  ['SICK', 'Sick leave', 1, 10, 0],
  ['BEREAVEMENT', 'Bereavement leave', 1, 3, 0],
  ['FAMILY', 'Family care leave', 1, 5, 0],
  ['MATERNITY', 'Maternity leave', 1, 98, 0],
  ['PATERNITY', 'Paternity leave', 1, 5, 0],
  ['UNPAID', 'Unpaid leave', 0, 0, 0],
];

export function fillMissingUids() {
  for (const u of db().all('SELECT id FROM users WHERE uid IS NULL OR uid = ?', [''])) {
    db().run('UPDATE users SET uid = ? WHERE id = ?', [uuid('U'), u.id]);
  }
}

export function seedEasyBuys() {
  DEFAULT_SHOPS.forEach(([code, name], i) => {
    db().run(
      "INSERT OR IGNORE INTO shops (code, name, active, sort, updated_at, updated_device, sync_status) VALUES (?, ?, 1, ?, ?, 'default', 'seed')",
      [code, name, i, OLD]
    );
  });
  DEFAULT_LEAVE_TYPES.forEach(([code, name, paid, days, photo], i) => {
    db().run(
      `INSERT OR IGNORE INTO leave_types (code, name, paid, default_days, needs_photo, active, sort, updated_at, updated_device, sync_status)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?, 'default', 'seed')`,
      [code, name, paid, days, photo, i, OLD]
    );
    // Starting values not yet changed by the admin follow the newer Fiji defaults.
    db().run("UPDATE leave_types SET default_days = ? WHERE code = ? AND updated_device = 'default' AND sync_status = 'seed' AND default_days <> ?", [days, code, days]);
  });
}
