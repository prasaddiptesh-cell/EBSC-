// v3.9 Training mode: 3 months of practice history so every module has real-looking figures to practise on –
// daily till counts at both shops with M-PAiSA, banking, weekly purchase orders received with their invoices,
// dairy deliveries without an order, invoices paid by cheque / transfer / cash / split / part, rent and power
// bills, fuel, petty cash, weekly pay runs from clock-ins (FNPF 8% + 8%, a family member without FNPF), leave,
// an advance, bakery days with batches, month-end stock counts, and the VAT returns and FNPF schedules lodged
// and paid for the first two months (the last month is left to practise on).
// Only ever run on the practice copy (Training mode). Every day and every part is tried on its own: a part that
// cannot be made is skipped and listed, the rest is still made.
import { db } from './connection.js';
import { clock, dateStr, addDays, weekStart, setSetting, getSetting } from '../services/core.js';
import { saveUser } from '../services/catalog.js';
import * as AP from '../modules/payables/service.js';
import * as T from '../modules/till/service.js';
import * as P from '../modules/payroll/service.js';
import * as I from '../modules/inventory/service.js';
import * as L from '../modules/leave/service.js';
import * as F from '../modules/accounting/full.js';
import * as RT from '../modules/payroll/returns.js';
import * as FL from '../modules/payroll/filing.js';
import * as VE from '../modules/vehicles/service.js';
import * as VF from '../modules/verify/service.js';
import { addManualPunch } from '../modules/timeclock/service.js';
import { checkWeek } from '../modules/timesheets/service.js';

const r2 = (n) => Math.round(n * 100) / 100;
// The same "random" figures every time (so the practice data can be talked about).
function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

export function historyDone() { return !!getSetting('training_history_at', ''); }

// Runs a day at a time and lets the screen breathe between days (pause), so the app never freezes.
export async function seedHistory({ days = 84, onProgress, pause = () => new Promise((r) => setTimeout(r, 0)) } = {}) {
  if (historyDone()) return { problems: ['The practice history is already there.'], made: {} };
  const problems = [];
  const made = {};
  const count = (k) => { made[k] = (made[k] || 0) + 1; };
  const step = (what, fn) => { try { const r = fn(); return r; } catch (e) { if (problems.length < 60) problems.push(`${what}: ${e.message}`); return null; } };
  const rand = rng(20261011);
  const pick = (lo, hi) => lo + (hi - lo) * rand();
  const before = clock.override;
  const at = (d, t = '20:00') => { clock.override = new Date(`${d}T${t}:00`); };

  const today = dateStr();
  const lastWeek = addDays(weekStart(today), -7);
  const start = addDays(lastWeek, -days); // a Saturday, 12 weeks before last pay week
  const end = addDays(lastWeek, -1);
  const user = (pin) => db().get('SELECT * FROM users WHERE pin = ? AND active = 1', [pin]);
  try {
    const owner = user('5001'); const mgr = user('5002'); const mere = user('5003'); const josefa = user('5004');
    if (!owner || !mgr || !mere || !josefa) throw new Error('Switch to Training first (the practice logins are missing).');
    at(start, '07:00');
    // ---------------------------------------------------------------- the people and things it needs
    const sunil = step('cashier S1', () => user('5005') || saveUser({ name: 'Sunil – cashier S1 (practice)', pin: '5005', role: 'staff', shopCode: 'S1', employeeNo: 'TR05' }, owner));
    const kavita = step('family member', () => user('5006') || saveUser({ name: 'Kavita – family (practice)', pin: '5006', role: 'staff', shopCode: 'S1', employeeNo: 'TR06' }, owner));
    step('pay details', () => {
      if (sunil) P.saveProfile(owner, { userUid: sunil.uid, payType: 'hourly', rate: 5.5, fnpfNo: 'F-PRAC-5', tin: '555-666-777', payMethod: 'cash', startDate: start });
      if (kavita) P.saveProfile(owner, { userUid: kavita.uid, payType: 'salary', weeklySalary: 220, tin: '888-999-000', fnpfMember: false, payMethod: 'cash', startDate: start });
      P.savePayRules(owner, { ...P.payRules(), confirmed: true });
      FL.saveEmployerDetails(owner, { name: 'Easy Buys Shopping Centre (practice)', tin: '50-12345-0-1', fnpfNo: 'ER-PRACTICE', tradingName: 'Easy Buys', postal: 'P O Box 1, Lautoka', city: 'Lautoka' });
    });
    const acct = db().get("SELECT * FROM bank_accounts WHERE active = 1 ORDER BY name LIMIT 1");
    if (!acct) throw new Error('The practice bank account is missing.');
    // The bank account and its opening balance start before the history.
    // The books start the day before the history: the bank balance is the opening balance (books and bank agree).
    step('opening balances', () => { at(addDays(start, -1), '09:00'); F.saveOpeningBalances(owner, { date: addDays(start, -1), lines: [{ code: `1100:${acct.uid}`, debit: 25000 }] }); });
    const sup = (name) => db().get('SELECT * FROM ap_suppliers WHERE name = ?', [name]);
    const punjas = sup('Punjas (practice)'); const rewa = sup('Rewa Dairy (practice)'); const efl = sup('EFL Power (practice)');
    const landlord = step('landlord', () => sup('Drasa Properties (practice)') || AP.saveSupplier(owner, { name: 'Drasa Properties (practice)', tin: '50-44444-0-1', onAccount: false }));
    const kiran = step('landlord S2', () => sup('Kiran Palace Ltd (practice)') || AP.saveSupplier(owner, { name: 'Kiran Palace Ltd (practice)', tin: '50-55555-0-1', onAccount: false }));
    const tills = {};
    step('tills', () => {
      for (const s of ['S1', 'S2']) {
        const t = db().get('SELECT uid FROM tills WHERE shop_code = ? ORDER BY name LIMIT 1', [s]);
        tills[s] = t ? t.uid : T.saveTill(owner, { shopCode: s, name: 'Till 1 (practice)', floatAmount: 100 });
      }
    });
    const van = step('van', () => (db().get("SELECT uid FROM ve_items WHERE rego = 'PB 113'") || {}).uid || VE.saveItem(owner, { kind: 'vehicle', name: 'Delivery van (practice)', typeKey: 'van', rego: 'pb 113', km: 81000, tankL: 70, area: 'S1', lastServiceDate: addDays(start, -40) }));
    // Flour bags received at Shop 1 go into the Bakery stock.
    step('flour link', () => { const B = require('../modules/bakery/store.js'); if (!B.linkFor('IT-P100')) B.linkMaterial(owner, 'Flour', 'IT-P100', 10); });
    const ravi = db().get("SELECT * FROM users WHERE name = 'Ravi' AND active = 1");
    let bakeryOk = !!ravi;
    let km = 81000;
    const openPOs = [];
    const toPay = []; // [{ inv, due }]
    let chequeNo = null;
    const nextCheque = () => {
      chequeNo = AP.nextChequeNo(acct.uid);
      // A new cheque book when the last one is used up (as the office would).
      if (!chequeNo) { const top = db().get('SELECT MAX(last_no) AS n FROM cheque_books WHERE account_uid = ?', [acct.uid]).n || 499; AP.saveBook(owner, { accountUid: acct.uid, firstNo: top + 1, lastNo: top + 50 }); count('cheque books'); chequeNo = AP.nextChequeNo(acct.uid); }
      return chequeNo;
    };
    const workers = [[mere, 'S2'], [josefa, 'S1'], [sunil, 'S1']].filter(([u]) => u);
    const salesByShop = { S1: {}, S2: {} };

    // ---------------------------------------------------------------- day by day
    const total = Math.round((Date.parse(end) - Date.parse(start)) / 86400000) + 1;
    for (let i = 0, d = start; d <= end; i++, d = addDays(d, 1)) {
      // While the screen breathes the real clock is back (other parts of the app run then).
      if (pause) { const keep = clock.override; clock.override = before; try { await pause(); } finally { clock.override = keep; } }
      const dow = new Date(`${d}T12:00:00`).getDay(); // 0 Sunday … 6 Saturday
      const dayOfMonth = Number(d.slice(8, 10));
      if (onProgress && i % 3 === 0) { try { onProgress(Math.round((i / total) * 100), d); } catch (e) { /* screen gone */ } }
      at(d, '07:30');
      // Staff clock in / out (Sunday off; Friday a long day).
      if (dow !== 0) {
        at(d, '20:00'); // the punches are entered after the day (manual punches cannot be in the future)
        for (const [u] of workers) step(`clock ${d}`, () => { addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d} 08:00:00`, reason: 'Practice history' }); addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${d} ${dow === 5 ? '18:00' : '16:30'}:00`, reason: 'Practice history' }); count('clock days'); });
      }
      // Bakery: Monday to Saturday, two batches.
      if (bakeryOk && dow !== 0) {
        const ok = step(`bakery ${d}`, () => bakeryDay(ravi, d, at, rand));
        if (ok) count('bakery days'); else if (!made['bakery days']) bakeryOk = false; // could not run at all: stop trying
      }
      // Purchase orders on Monday for both shops; received on Wednesday with the invoice.
      if (dow === 1 && punjas) {
        for (const s of ['S1', 'S2']) {
          step(`order ${d} ${s}`, () => {
            at(d, '09:00');
            const lines = [{ itemUid: 'IT-P102', qty: Math.round(pick(6, 12)), unitCost: 30 }, { itemUid: 'IT-P103', qty: Math.round(pick(30, 50)), unitCost: 4.2 }, { itemUid: 'IT-P104', qty: Math.round(pick(80, 140)), unitCost: 1.8 }];
            if (s === 'S1') lines.push({ itemUid: 'IT-P100', qty: Math.round(pick(10, 16)), unitCost: 18.5 });
            const po = I.savePO(mgr, { supplierUid: punjas.uid, shopCode: s, lines });
            I.submitPO(owner, po.uid, { canApprove: true });
            openPOs.push({ uid: po.uid, shop: s, receive: addDays(d, 2) });
            count('purchase orders');
          });
        }
      }
      for (const o of openPOs.filter((x) => x.receive === d)) {
        step(`delivery ${d} ${o.shop}`, () => {
          at(d, '11:00');
          const po = I.getPO(o.uid);
          // Now and then something comes short; the rest is a full delivery.
          const lines = po.lines.map((l, k) => ({ lineUid: l.uid, qty: k === 1 && rand() < 0.25 ? Math.max(1, l.qty - 5) : l.qty }));
          const r = I.receiveDelivery(mgr, { poUid: o.uid, date: d, lines, invoice: { invoiceNo: `PJ-${d.replace(/-/g, '').slice(2)}-${o.shop}`, photos: ['training://invoice.jpg'] }, acceptReason: 'Practice: short delivery, rest next week' });
          if (r.invoice) { AP.checkInvoice(owner, r.invoice.uid); toPay.push({ inv: r.invoice.uid, due: addDays(d, 14), sup: punjas.uid, how: ['cheque', 'transfer', 'split', 'cheque', 'part'][(made.deliveries || 0) % 5] }); }
          count('deliveries');
        });
      }
      // Dairy on Tuesday and Friday at Shop 2, no order (photo of the invoice).
      if ((dow === 2 || dow === 5) && rewa) {
        step(`dairy ${d}`, () => {
          at(d, '07:45');
          const qty = Math.round(pick(40, 70));
          const r = I.receiveDelivery(mgr, { supplierUid: rewa.uid, shopCode: 'S2', date: d, extra: [{ itemUid: 'IT-P101', qty, unitCost: 2.1 }], photos: ['training://dairy.jpg'], invoice: { invoiceNo: `RW-${d.replace(/-/g, '').slice(2)}`, photos: ['training://dairy.jpg'] } });
          if (r.invoice) { AP.checkInvoice(owner, r.invoice.uid); toPay.push({ inv: r.invoice.uid, due: monthEnd(d), sup: rewa.uid, how: 'transfer-month' }); }
          count('dairy deliveries');
        });
      }
      // Rent on the 1st (receipts already paid), power bill on the 10th.
      if (dayOfMonth === 1) {
        for (const [who, shop, amt, how] of [[landlord, 'S1', 2500, 'cheque'], [kiran, 'S2', 1800, 'transfer']]) {
          if (!who) continue;
          step(`rent ${d} ${shop}`, () => {
            at(d, '10:00');
            VF.snap(owner, { kind: 'invoice', shopCode: shop, amount: amt, supplierUid: who.uid, refNo: `RENT-${d.slice(0, 7)}-${shop}`, date: d, photos: ['training://rent.jpg'], category: 'Rent',
              paid: how === 'cheque' ? { method: 'cheque', accountUid: acct.uid, chequeNo: String(nextCheque()) } : { method: 'transfer', accountUid: acct.uid, reference: `TT-RENT-${d.slice(0, 7)}` } });
            count('rent receipts');
          });
        }
      }
      if (dayOfMonth === 10 && efl) {
        step(`power ${d}`, () => {
          at(d, '10:00');
          const inv = AP.saveInvoice(owner, { supplierUid: efl.uid, invoiceNo: `EFL-${d.slice(0, 7)}`, total: r2(pick(380, 520)), invoiceDate: d, shopCode: 'S1', category: 'Power & water' }, { photos: ['training://power.jpg'], canCheck: true });
          toPay.push({ inv: inv.uid, due: addDays(d, 10), sup: efl.uid, how: 'transfer' });
          count('power bills');
        });
      }
      // Fuel on Thursday, petty cash on Wednesday.
      if (dow === 4 && van) step(`fuel ${d}`, () => { at(d, '14:00'); km += Math.round(pick(280, 420)); const l = Math.round(pick(35, 50)); VE.saveFuel(owner, { itemUid: van, date: d, km, litres: l, amount: r2(l * 2.65), via: 'cash:S1', supplier: 'Total Lautoka (practice)', receiptNo: `T-${d.slice(5)}` }); count('fuel'); });
      if (dow === 3) step(`petty ${d}`, () => { at(d, '15:00'); T.recordCash(mgr, { shopCode: rand() < 0.5 ? 'S1' : 'S2', type: 'petty_out', amount: r2(pick(8, 35)), category: ['Cleaning', 'Office', 'Food & tea'][Math.floor(rand() * 3)], note: 'Practice history', date: d }); count('petty cash'); });
      // Paying what is due (supplier invoices).
      for (const p of toPay.filter((x) => x.due === d && x.how !== 'transfer-month')) {
        step(`pay ${d}`, () => {
          at(d, '12:00');
          const inv = AP.getInvoice(p.inv);
          if (!inv || inv.owing <= 0) return;
          const base = { supplierUid: p.sup, payDate: d, accountUid: acct.uid };
          if (p.how === 'split') {
            const cash = r2(Math.min(300, inv.owing / 3));
            AP.makeSplitPayment(owner, { supplierUid: p.sup, payDate: d, allocations: [{ invoiceUid: inv.uid, amount: inv.owing }], parts: [{ method: 'cash', amount: cash, shopCode: 'S1', receivedBy: 'Punjas rep' }, { method: 'cheque', amount: r2(inv.owing - cash), accountUid: acct.uid, chequeNo: nextCheque() }] });
          } else if (p.how === 'part') {
            AP.makePayment(owner, { ...base, method: 'transfer', reference: `TT-${d.replace(/-/g, '')}`, allocations: [{ invoiceUid: inv.uid, amount: r2(inv.owing / 2) }] });
          } else if (p.how === 'cheque') {
            AP.makePayment(owner, { ...base, method: 'cheque', chequeNo: nextCheque(), allocations: [{ invoiceUid: inv.uid, amount: inv.owing }] });
          } else {
            AP.makePayment(owner, { ...base, method: 'transfer', reference: `TT-${d.replace(/-/g, '')}-${inv.invoice_no || ''}`, allocations: [{ invoiceUid: inv.uid, amount: inv.owing }] });
          }
          count('supplier payments');
        });
      }
      if (d === monthEnd(d) && rewa) {
        step(`dairy month ${d}`, () => {
          at(d, '12:00');
          const due = toPay.filter((x) => x.how === 'transfer-month').map((x) => AP.getInvoice(x.inv)).filter((x) => x && x.owing > 0);
          if (due.length) { AP.makePayment(owner, { supplierUid: rewa.uid, method: 'transfer', accountUid: acct.uid, payDate: d, reference: `TT-RW-${d.slice(0, 7)}`, allocations: due.map((x) => ({ invoiceUid: x.uid, amount: x.owing })) }); count('supplier payments'); }
        });
      }
      // The day's takings at both shops (one full-day count each, Sunday a short day).
      for (const s of ['S1', 'S2']) {
        step(`till ${d} ${s}`, () => {
          at(d, '20:30');
          const busy = dow === 6 ? 1.3 : dow === 0 ? 0.6 : 1;
          const totalSales = r2(pick(s === 'S1' ? 2100 : 1300, s === 'S1' ? 3200 : 2000) * busy);
          const zero = r2(totalSales * pick(0.1, 0.2));
          const mpaisa = r2(totalSales * pick(0.12, 0.25));
          const cash = r2(totalSales - mpaisa);
          const diff = rand() < 0.06 ? -Math.round(pick(2, 15)) : 0;
          const counted = r2(100 + cash + diff);
          let rest = counted; const n100 = Math.floor(rest / 100); rest = r2(rest - n100 * 100);
          const n50 = Math.floor(rest / 50); rest = r2(rest - n50 * 50); const n20 = Math.floor(rest / 20); rest = r2(rest - n20 * 20);
          const n5 = Math.floor(rest / 5); rest = r2(rest - n5 * 5);
          T.saveTillCount(mgr, { shopCode: s, tillUid: tills[s], shiftDate: d, shift: 'Full day', cashierUid: s === 'S2' ? mere.uid : (sunil || josefa).uid, openingFloat: 100,
            denominations: { n100, n50, n20, n5, c1: rest }, zCash: cash, zTotal: totalSales, zZeroRated: zero, zVat: r2(((totalSales - zero) * 12.5) / 112.5),
            tenders: [{ method: 'M-PAiSA', amount: mpaisa }], payouts: [], adjustments: [], floatKept: 100, reason: diff ? 'Practice: change given wrongly' : '' }, { photos: ['training://z-report.jpg'] });
          // Stock sold that day (rice, sugar, fish, milk).
          const sold = salesByShop[s];
          sold.P102 = (sold.P102 || 0) + Math.round(pick(0, 1.4)); sold.P103 = (sold.P103 || 0) + Math.round(pick(2, 5)); sold.P104 = (sold.P104 || 0) + Math.round(pick(10, 20));
          if (s === 'S2') sold.P101 = (sold.P101 || 0) + Math.round(pick(8, 14));
          count('till counts');
        });
      }
      // Banking on Monday and Thursday: the cash from the safe goes to the bank.
      if (dow === 1 || dow === 4) {
        for (const s of ['S1', 'S2']) step(`deposit ${d} ${s}`, () => { at(d, '13:00'); T.saveDeposit(mgr, { shopCode: s, accountUid: acct.uid, slipNo: `DEP-${s}-${d.replace(/-/g, '')}`, date: d, denominations: { n100: Math.round(pick(s === 'S1' ? 25 : 12, s === 'S1' ? 38 : 22)) } }); count('deposits'); });
      }
      // Saturday: the week's stock sales and the pay run for the week that just ended.
      if (dow === 6 && d > start) {
        for (const s of ['S1', 'S2']) {
          step(`sales ${d} ${s}`, () => {
            at(d, '21:00');
            const rows = Object.entries(salesByShop[s]).filter(([, q]) => q > 0).map(([c, q]) => `${c},${q}`);
            if (rows.length) I.importSalesCsv(owner, `Code,Quantity\n${rows.join('\n')}\n`, { shopCode: s, date: addDays(d, -1) });
            salesByShop[s] = {};
          });
        }
        step(`pay run ${d}`, () => {
          at(d, '09:00');
          const ws = addDays(d, -7);
          for (const [u] of workers) { try { checkWeek(owner, u.uid, ws, 'ok'); } catch (e) { /* salary */ } }
          const run = P.createRun(owner, addDays(d, -1));
          P.finaliseRun(owner, run.uid);
          count('pay runs');
        });
      }
      // People things: an advance, annual leave, a sick day.
      if (i === 10 && sunil) step('advance', () => { at(d, '10:00'); P.giveDebt(owner, { userUid: sunil.uid, kind: 'advance', amount: 80, repayPerPay: 20, reason: 'Practice: school fees', shopCode: 'S1', paidFrom: 'cash', date: d }); });
      if (i === 40) step('leave', () => { at(d, '10:00'); const lr = L.requestLeave(josefa, { userUid: josefa.uid, type: 'ANNUAL', from: addDays(d, 3), to: addDays(d, 5), reason: 'Practice: family function' }); L.decideLeave(owner, lr, true); count('leave'); });
      if (i === 55) step('sick', () => { at(d, '10:00'); const lr = L.requestLeave(mere, { userUid: mere.uid, type: 'SICK', from: d, to: d, reason: 'Practice: flu' }); L.decideLeave(mgr, lr, true); count('leave'); });
      // Month end: a short stock count of two lines at Shop 1 (a small loss with its reason).
      if (d === monthEnd(d)) step(`count ${d}`, () => { monthCount(mgr, owner, d, at); count('stock counts'); });
    }

    // ---------------------------------------------------------------- returns for the first two months
    const months = Array.from(new Set(Array.from({ length: total }, (_, k) => addDays(start, k).slice(0, 7)))).filter((ym) => monthEnd(`${ym}-01`) <= end);
    for (const ym of months.slice(0, -1)) {
      const lodge = `${ymNext(ym)}-12`;
      const pay = `${ymNext(ym)}-20`;
      if (pay > today) continue;
      step(`VAT ${ym}`, () => {
        at(lodge, '10:00'); RT.lodgeReturn(owner, 'vat', ym, { date: lodge, ref: `TPOS-PR-${ym}`, photos: ['training://tpos.jpg'], force: true, reason: 'Practice' });
        const st = RT.returnStatus('vat', ym);
        at(pay, '10:00'); if (!st.refund && st.owed > 0) RT.payReturn(owner, 'vat', ym, { date: pay, via: `bank:${acct.uid}`, method: 'cheque', chequeNo: String(nextCheque()), photos: ['training://stub.jpg'] });
        count('VAT returns');
      });
      step(`FNPF ${ym}`, () => {
        at(lodge, '11:00'); RT.lodgeReturn(owner, 'fnpf', ym, { date: lodge, ref: `FNPF-PR-${ym}`, photos: ['training://fnpf.jpg'], force: true, reason: 'Practice' });
        at(pay, '11:00'); RT.payReturn(owner, 'fnpf', ym, { date: pay, via: `bank:${acct.uid}`, method: 'transfer', ref: `TT-FNPF-${ym}`, photos: ['training://fnpf-pay.jpg'] });
        count('FNPF schedules');
      });
    }
    clock.override = before;
    setSetting('training_history_at', dateStr());
    setSetting('training_history_problems', JSON.stringify(problems));
    if (onProgress) { try { onProgress(100, end); } catch (e) { /* screen gone */ } }
  } catch (e) {
    problems.unshift(e.message);
  } finally {
    clock.override = before;
  }
  return { problems, made };
}

function monthEnd(d) { const ym = d.slice(0, 7); return addDays(`${ymNext(ym)}-01`, -1); }
function ymNext(ym) { const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; }

// One bakery day for the baker: clock in, open the day with the stock counts, checklists, two batches, close & count.
function bakeryDay(ravi, d, at, rand) {
  const { startShift } = require('../services/shifts.js');
  const { myChecklists, openRun, answerItem } = require('../services/checklists.js');
  const { punch } = require('../modules/timeclock/service.js');
  const B = require('../services/batches.js');
  const DAY = require('../modules/bakery/day.js');
  const answerAll = (when) => {
    for (const l of myChecklists(ravi.id).filter((x) => (when === 'end' ? x.when_due === 'end' : x.when_due !== 'end'))) {
      const run = openRun(l.id, ravi.id);
      run.items.forEach((it) => answerItem(run.run.id, it.id, ravi.id, it.kind === 'temp' ? { value: it.min_value } : it.kind === 'photo' ? { photo: 'training://check.jpg' } : { done: true }));
    }
  };
  at(d, '04:00');
  const { getOpenShift, recordReceive } = require('../services/shifts.js');
  // A day left open by a problem is closed first (counted as the system has it).
  if (getOpenShift()) { try { answerAll('end'); DAY.closeAndCount(ravi, Object.fromEntries(DAY.countSheet().map((r) => [r.material_id, Math.max(0, r.expected)]))); } catch (e) { /* tried */ } }
  // Ingredients that are running low are delivered (bakery's own receiving), so a day never runs out.
  const low = db().all('SELECT id, stock FROM materials WHERE track_stock = 1 AND active = 1 AND stock < 40');
  const bsup = db().get('SELECT id FROM suppliers ORDER BY id LIMIT 1');
  if (low.length && bsup) recordReceive(ravi.id, { supplierId: bsup.id, invoiceNo: `BK-${d}`, lines: low.map((m) => ({ material_id: m.id, qty: 120 })), photos: ['training://bakery-invoice.jpg'], note: 'Practice history' });
  punch({ user: ravi, type: 'IN', shopCode: 'S1', at: `${d} 04:00:00` });
  const counts = Object.fromEntries(db().all('SELECT id, stock FROM materials WHERE track_stock = 1 AND active = 1').map((m) => [m.id, Math.max(0, m.stock)]));
  const shiftName = (db().get('SELECT name FROM shift_names ORDER BY sort LIMIT 1') || {}).name || 'Early Bake';
  startShift(ravi.id, shiftName, counts);
  answerAll('start');
  const products = db().all('SELECT id, max_flour_kg FROM products WHERE active = 1 ORDER BY id LIMIT 2');
  for (const p of products) {
    at(d, '04:30');
    let b = B.startBatch(ravi.id, p.id, Math.min(p.max_flour_kg || 10, 10), {}, { climate: 'normal' });
    for (let k = 0; k < 20 && b.nextStep && b.nextStep.kind !== 'finish'; k++) {
      const pieces = B.needsCutCount(b) ? b.expected_pieces : undefined;
      b = B.confirmNextStep(ravi.id, b.id, { cutPieces: pieces });
    }
    const exp = b.cut_pieces || b.expected_pieces || 50;
    const lost = Math.round(exp * (rand() * 0.04));
    B.finishBatch(ravi.id, b.id, { good: exp - lost, damaged: lost, rejected: 0, otherWaste: 0, cutPieces: B.needsCutCount(b) ? exp : undefined });
  }
  at(d, '12:00');
  answerAll('end');
  const sheet = DAY.countSheet();
  DAY.closeAndCount(ravi, Object.fromEntries(sheet.map((r) => [r.material_id, Math.max(0, r.expected)])));
  punch({ user: ravi, type: 'OUT', shopCode: 'S1', at: `${d} 12:30:00` });
  return true;
}

// Month-end count of two lines at Shop 1.
function monthCount(mgr, owner, d, at) {
  at(d, '21:30');
  const c = I.startCount(mgr, { shopCode: 'S1', name: `Month end ${d.slice(0, 7)} (practice)`, scope: { itemUids: ['IT-P102', 'IT-P104'] }, date: d });
  const have = (uid) => Math.max(0, db().get("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = 'S1' AND status = 'active'", [uid]).q);
  I.enterCount(mgr, c.uid, 'IT-P102', Math.max(0, have('IT-P102') - 1));
  I.enterCount(mgr, c.uid, 'IT-P104', have('IT-P104'));
  for (const a of I.getCount(c.uid).areas || []) { try { I.claimArea(mgr, c.uid, a.area); } catch (e) { /* taken */ } try { I.finishArea(mgr, c.uid, a.area); } catch (e) { /* done */ } }
  let r = I.submitCount(mgr, c.uid, {});
  if (r.recount && r.recount.length) { I.enterCount(mgr, c.uid, 'IT-P102', Math.max(0, have('IT-P102') - 1)); r = I.submitCount(mgr, c.uid, {}); }
  try { I.setLineReason(owner, c.uid, 'IT-P102', 'Damaged'); } catch (e) { /* set */ }
  I.postCount(owner, c.uid, {});
}
