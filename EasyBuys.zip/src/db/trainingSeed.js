// Sample figures for Training mode: shops, staff, products, suppliers, invoices, till counts, a pay run,
// leave, a purchase order, a job opening… so every module has something to practise on.
// Each part is tried on its own: if one part cannot be made, the rest still is.
import { db } from './connection.js';
import { dateStr, addDays, weekStart, setSetting } from '../services/core.js';
import { saveUser } from '../services/catalog.js';
import * as AP from '../modules/payables/service.js';
import * as T from '../modules/till/service.js';
import * as P from '../modules/payroll/service.js';
import * as I from '../modules/inventory/service.js';
import * as L from '../modules/leave/service.js';
import * as R from '../modules/timesheets/roster.js';
import * as PP from '../modules/people/service.js';
import * as V from '../modules/verify/service.js';
import { addManualPunch } from '../modules/timeclock/service.js';
import { checkWeek } from '../modules/timesheets/service.js';
import * as LIC from '../modules/licences/service.js';
import * as F from '../modules/accounting/full.js';
import * as REC from '../modules/payables/recurring.js';

export const TRAINING_LOGINS = [
  ['Owner (practice)', '5001', 'owner', 'S1'],
  ['Anita – manager (practice)', '5002', 'manager', 'S2'],
  ['Mere – cashier (practice)', '5003', 'staff', 'S2'],
  ['Josefa – shop assistant (practice)', '5004', 'staff', 'S1'],
];

export function seedTraining() { return require('../services/guard.js').whileSeedingSync(() => seedTraining0()); }
function seedTraining0() {
  const problems = [];
  const step = (what, fn) => { try { return fn(); } catch (e) { problems.push(`${what}: ${e.message}`); return null; } };
  const today = dateStr();
  const lastWeek = addDays(weekStart(today), -7); // Saturday of last pay week
  const d = (n) => addDays(lastWeek, n);

  const people = {};
  let owner = null;
  step('logins', () => {
    for (const [name, pin, role, shop] of TRAINING_LOGINS) {
      const ex = db().get('SELECT * FROM users WHERE pin = ?', [pin]);
      const u = ex || saveUser({ name, pin, role, shopCode: shop, employeeNo: `TR${pin.slice(-2)}` }, owner || undefined);
      people[role === 'owner' ? 'owner' : pin] = u;
      if (role === 'owner') owner = u;
    }
  });
  if (!owner) return problems;
  const mgr = people['5002']; const mere = people['5003']; const josefa = people['5004'];

  // Bank account and cheque book.
  const acct = step('bank account', () => {
    const a = AP.saveAccount(owner, { name: 'BSP Business (practice)', openingBalance: 15000, openingDate: d(-30) });
    AP.saveBook(owner, { accountUid: a.uid, firstNo: 500, lastNo: 549 });
    return a;
  });

  // Suppliers and invoices.
  const sup = {};
  step('suppliers', () => {
    sup.punjas = AP.saveSupplier(owner, { name: 'Punjas (practice)', tin: '50-11111-0-1', onAccount: true });
    sup.rewa = AP.saveSupplier(owner, { name: 'Rewa Dairy (practice)', tin: '50-22222-0-1', onAccount: true });
    sup.fea = AP.saveSupplier(owner, { name: 'EFL Power (practice)', tin: '50-33333-0-1', onAccount: false });
  });
  const invs = [];
  step('invoices', () => {
    invs.push(AP.saveInvoice(owner, { supplierUid: sup.punjas.uid, invoiceNo: 'PJ-1001', total: 1125, invoiceDate: d(1), shopCode: 'S1', category: 'Stock for resale' }, { canCheck: true }));
    invs.push(AP.saveInvoice(owner, { supplierUid: sup.rewa.uid, invoiceNo: 'RW-77', total: 337.5, invoiceDate: d(2), shopCode: 'S2', category: 'Stock for resale' }, { canCheck: true }));
    invs.push(AP.saveInvoice(owner, { supplierUid: sup.fea.uid, invoiceNo: 'EFL-9', total: 420, invoiceDate: d(3), shopCode: 'S1', category: 'Power' }, { canCheck: true }));
  });
  step('payment', () => {
    if (acct && invs[0]) AP.makePayment(owner, { supplierUid: sup.punjas.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 500, payDate: d(4), allocations: [{ invoiceUid: invs[0].uid, amount: 1125 }] });
  });

  // Tills: a few days of counts at S2, one with a small shortage.
  step('tills', () => {
    const till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1 (practice)', floatAmount: 100 });
    [[0, 0], [1, 0], [2, -5]].forEach(([k, diff]) => {
      const cash = 650 + k * 40;
      const counted = 100 + cash + diff;
      const n100 = Math.floor(counted / 100); let rest = counted - n100 * 100;
      const n20 = Math.floor(rest / 20); rest -= n20 * 20;
      const n5 = Math.floor(rest / 5); rest -= n5 * 5;
      T.saveTillCount(mgr, { shopCode: 'S2', tillUid: till, shiftDate: d(k), shift: 'Full day', cashierUid: mere.uid, openingFloat: 100,
        denominations: { n100, n20, n5, c1: rest }, zCash: cash, zTotal: cash + 400, zVat: Math.round((cash + 400) / 9 * 100) / 100,
        tenders: [{ method: 'EFTPOS / card', amount: 400 }], payouts: [], adjustments: [], floatKept: 100, reason: diff ? 'Practice: change given wrongly' : '' }, { photos: ['training://z-report.jpg'] });
    });
    if (acct) T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: 'DEP-PR1', date: d(3), denominations: { n100: 12 } });
    T.recordCash(mgr, { shopCode: 'S2', type: 'petty_out', amount: 12.5, category: 'Cleaning', note: 'Practice: soap and mop', date: d(3) });
  });

  // Products and stock at two shops.
  step('products', () => {
    const csv = 'Code,Name,Group,Measurement unit,Cost,Price,Taxes,Quantity\n'
      + 'P100,Flour 10kg (practice),Flour,bag,18.50,24.95,VAT 12.5%,40\n'
      + 'P101,Milk 1L (practice),Dairy,each,2.10,3.20,VAT 12.5%,120\n'
      + 'P102,Rice 20kg (practice),Rice,bag,30.00,42.00,Zero rated,12\n'
      + 'P103,Sugar 2kg (practice),Sugar,bag,4.20,5.95,VAT 12.5%,60\n'
      + 'P104,Tinned fish (practice),Tins,each,1.80,2.80,VAT 12.5%,200\n';
    I.importProductsCsv(owner, csv, { shopCode: 'S1', openingStock: true });
    I.importProductsCsv(owner, csv.replace(/,40\n/, ',8\n').replace(/,120\n/, ',30\n'), { shopCode: 'S2', openingStock: true });
    I.importSalesCsv(owner, 'Code,Quantity\nP100,4\nP101,25\nP104,30\n', { shopCode: 'S1', date: d(2) });
    if (sup.punjas) {
      db().run('UPDATE inv_items SET supplier_uid = ? WHERE code IN (?, ?, ?)', [sup.punjas.uid, 'P100', 'P102', 'P103']);
      I.saveSupplierOrdering(owner, { supplierUid: sup.punjas.uid, budgetWeekly: 2000, budgetMonthly: 7000, leadDays: 3, viber: '+679 000 0000' });
    }
  });
  step('purchase order', () => {
    if (!sup.punjas) return;
    I.savePO(mgr, { supplierUid: sup.punjas.uid, shopCode: 'S2', lines: [{ itemUid: 'IT-P100', qty: 20, unitCost: 18.5, note: 'Practice order' }, { itemUid: 'IT-P103', qty: 30 }] });
  });

  // Staff pay details, punches and last week's pay run.
  step('pay details', () => {
    P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 5.6, fnpfNo: 'F-PRAC-1', tin: '111-222-333', payMethod: 'cash' });
    P.saveProfile(owner, { userUid: josefa.uid, payType: 'hourly', rate: 5.3, fnpfNo: 'F-PRAC-2', tin: '444-555-666', payMethod: 'bank', bankName: 'BSP', bankAccount: '0000-PRACTICE' });
    P.saveProfile(owner, { userUid: mgr.uid, payType: 'salary', weeklySalary: 450, fnpfNo: 'F-PRAC-3', tin: '777-888-999', payMethod: 'bank', bankName: 'BSP', bankAccount: '0000-PRACTICE' });
  });
  step('clock punches', () => {
    for (const u of [mere, josefa]) {
      for (let k = 0; k < 6; k++) {
        if (k === 1) continue; // Sunday off
        addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d(k)} 08:00:00`, reason: 'Practice data' });
        addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${d(k)} ${k === 4 ? '18:30' : '16:30'}:00`, reason: 'Practice data' });
      }
    }
  });
  step('staff advance', () => {
    P.giveDebt(owner, { userUid: mere.uid, kind: 'advance', amount: 50, repayPerPay: 25, reason: 'Practice: bus fare', shopCode: 'S2', paidFrom: 'cash', date: d(2) });
  });
  step('pay run', () => {
    const run = P.createRun(owner, d(2));
    [mere, josefa, mgr].forEach((u) => { try { checkWeek(owner, u.uid, lastWeek, 'ok'); } catch (e) { /* salary staff may have no timesheet */ } });
    return run;
  });

  // Roster for this week, leave, a job opening.
  step('roster', () => {
    const ws = weekStart(today);
    for (let k = 0; k < 7; k++) {
      if (k === 1) continue;
      R.setShift(owner, { userUid: mere.uid, date: addDays(ws, k), shopCode: 'S2', start: '08:00', end: '16:30', breakMin: 30 });
      R.setShift(owner, { userUid: josefa.uid, date: addDays(ws, k), shopCode: 'S1', start: '08:00', end: '16:30', breakMin: 30 });
    }
  });
  step('leave', () => {
    L.requestLeave(josefa, { userUid: josefa.uid, type: 'ANNUAL', from: addDays(today, 14), to: addDays(today, 16), reason: 'Practice: family visit' });
  });
  step('recruitment', () => {
    const job = PP.saveOpening(owner, { title: 'Cashier (practice)', shopCode: 'S1', rate: 5.6 });
    PP.saveApplicant(owner, { openingUid: job, name: 'Losana (practice)', phone: '7000000', email: '' });
  });
  step('staff photo', () => {
    V.snap(mere, { kind: 'cheque_given', shopCode: 'S2', party: 'Rewa Dairy (practice)', refNo: '000501', amount: 337.5, collectedBy: 'Driver (practice)', photos: ['training://cheque.jpg'] });
  });

  // Licences & permits: one to renew soon, one fine.
  step('licences', () => {
    LIC.saveLicence(owner, { name: 'Liquor licence (practice)', category: 'liquor', shopCode: 'S2', licenceNo: 'LL-PR-01', expiryDate: addDays(today, 40), remindDays: 90, renewMonths: 12, authority: 'Liquor Licensing Board' });
    LIC.saveLicence(owner, { name: 'Business licence (practice)', category: 'trading', shopCode: 'S1', licenceNo: 'BL-PR-02', expiryDate: addDays(today, 200), remindDays: 45, renewMonths: 12, authority: 'Lautoka City Council' });
  });
  // A loan with its repayment bills, and Aronium sales waiting to be checked.
  step('loan', () => {
    const bsp = AP.saveSupplier(owner, { name: 'BSP Loans (practice)', onAccount: true });
    REC.saveRecurring(owner, { kind: 'loan', name: 'Shop 1 loan (practice)', supplierUid: bsp.uid, amount: 1200, frequency: 'monthly', nextDate: addDays(today, 10), leadDays: 7, loanNo: 'BL-PR', openingBalance: 40000, openingDate: d(-30), interestRate: 8 });
  });
  step('aronium', () => {
    F.addAroniumBatch(mgr, { kind: 'sales', shopCode: 'S1', source: 'practice', rows: [{ date: d(0), total: 1450, vat: 140, zero: 280, cash: 1000, card: 450, other: 0 }, { date: d(1), total: 1210.5, vat: 120, zero: 250.5, cash: 900, card: 310.5, other: 0 }] });
  });
  step('typed expense', () => {
    F.saveExpense(owner, { date: d(3), shop: 'S1', account: '6030', total: 168.75, via: 'cash:S1', supplier: 'Hardware (practice)', tin: '50000000' });
  });

  setSetting('training_problems', JSON.stringify(problems));
  return problems;
}
