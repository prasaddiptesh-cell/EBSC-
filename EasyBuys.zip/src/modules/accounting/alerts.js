// Warnings for Home: Aronium sales figures waiting to be checked before they go into the books; 1.0.0 the suggestions.
import { can } from '../../services/access.js';
import { db } from '../../db/connection.js';

function alertsNow(user) {
  // 1.0.0 (build 1) suggestions (orders due, products running low, impossible till figures) as notifications
  let sug = [];
  try { sug = require('../../services/dayStart.js').suggestions(user); } catch (e) { sug = []; }
  if (!can(user, 'accounts_view')) return sug;
  let n = 0;
  try { n = db().get("SELECT COUNT(*) AS n FROM aronium_batches WHERE status = 'to_check'").n; } catch (e) { n = 0; }
  return (n ? [{ id: 'acc-aronium', level: 'info', text: `${n} Aronium sales import${n === 1 ? '' : 's'} to check`, nav: { screen: 'AroniumInbox', params: {} } }] : []).concat(sug);
}

// round 2: in parts – the stock list of each shop worked out ahead (the suggestions read them), then the warnings
const warmShop = (i) => (user) => {
  try {
    const boss = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
    if (!boss && user.role !== 'manager') return [];
    const s = db().all('SELECT code FROM shops WHERE active = 1 ORDER BY code')[i];
    if (s) require('../inventory/service.js').stockList({ shopCode: s.code });
  } catch (e) { /* the warnings say so */ }
  return [];
};
const PARTS = [warmShop(0), warmShop(1), warmShop(2), alertsNow];
export function alerts(user) { return alertsNow(user); }
alerts.parts = PARTS;
