// Warnings for Home: Aronium sales figures waiting to be checked before they go into the books.
import { can } from '../../services/access.js';
import { db } from '../../db/connection.js';

export function alerts(user) {
  if (!can(user, 'accounts_view')) return [];
  let n = 0;
  try { n = db().get("SELECT COUNT(*) AS n FROM aronium_batches WHERE status = 'to_check'").n; } catch (e) { n = 0; }
  return n ? [{ id: 'acc-aronium', level: 'info', text: `${n} Aronium sales import${n === 1 ? '' : 's'} to check`, nav: { screen: 'AroniumInbox', params: {} } }] : [];
}
