// Accounting, version 3.4: everything a full set of books needs on top of what the other modules already record.
//  - opening balances (the day the books start), year-end close
//  - sales, expenses, other income, owner's money and transfers typed straight into the books
//  - Aronium figures brought in and CHECKED by a person before they reach the books
//  - loans read from Invoices & cheques (each loan its own account in the books)
//  - repeating journals, costs paid in advance (spread over months) and costs owing at month end (accruals)
//  - provisional tax (5%) withheld from contractors, company advance tax instalments
//  - reminders for what is due
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { lockDate } from '../../services/lock.js';
import { addPhotos } from '../../services/stock.js';
import { apRules } from '../payables/service.js';
import { verifyRules } from '../verify/service.js';
import { parseCsv } from '../inventory/service.js';
import * as A from './service.js';

const { r2, $, OFFICE } = A;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const vatRate = () => Number(apRules().vatRate) || 12.5;
export const vatIn = (total, rate = vatRate()) => r2(Number(total) - Number(total) / (1 + rate / 100));
const monthEnd = (ym) => addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
export function addMonths(d, n) {
  const [y, m, day] = d.split('-').map(Number);
  const t = new Date(y, m - 1 + Number(n), 1);
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(Math.min(day, last)).padStart(2, '0')}`;
}

// ---------------------------------------------------------------- settings
export const ACCT_DEFAULTS = { goLive: '', taxYearEndMonth: 12, lastYearTax: 0, advanceTax: true, provTaxPct: 5, provTaxThreshold: 1000 };
export function acctSettings() { return { ...ACCT_DEFAULTS, ...(getShared('acct_settings', {}) || {}) }; }
export function saveAcctSettings(user, s) {
  const clean = { ...acctSettings(), ...s };
  need(!clean.goLive || DATE.test(clean.goLive), 'Start date: YYYY-MM-DD.');
  clean.taxYearEndMonth = Math.min(12, Math.max(1, Math.round(Number(clean.taxYearEndMonth) || 12)));
  clean.lastYearTax = r2(clean.lastYearTax);
  clean.provTaxPct = Math.min(20, Math.max(0, Number(clean.provTaxPct) || 0));
  clean.provTaxThreshold = Math.max(0, Number(clean.provTaxThreshold) || 0);
  clean.advanceTax = clean.advanceTax !== false;
  // Instalments due before last year's tax was first entered are not flagged as late (they may have been paid outside the app).
  if (clean.lastYearTax > 0 && !clean.advanceFrom) clean.advanceFrom = dateStr();
  setShared('acct_settings', clean);
  audit({ user, action: 'Changed the accounting settings', table: 'shared_settings', recordUid: 'acct_settings', after: clean });
  return clean;
}

// Where money came from / went to, as picked on the screens: 'cash:S1' (a shop's cash), 'bank:<uid>', 'card' (to be banked), 'owner'.
export function moneyCode(via, shop) {
  const v = txt(via);
  if (v.startsWith('bank:')) return { code: `1100:${v.slice(5)}`, shop: OFFICE };
  if (v.startsWith('cash:')) return { code: '1000', shop: v.slice(5) || shop || OFFICE };
  if (v === 'cash') return { code: '1000', shop: shop || OFFICE };
  if (v === 'card') return { code: '1110', shop: shop || OFFICE };
  if (v === 'owner') return { code: '3100', shop: OFFICE };
  if (v === 'owing') return { code: '2300', shop: OFFICE };
  throw new AppError('Choose where the money came from / went to.');
}
export function moneyOptions() {
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort, code');
  const banks = has('bank_accounts') ? db().all('SELECT uid, name FROM bank_accounts WHERE active = 1 ORDER BY name') : [];
  return shops.map((s) => ({ value: `cash:${s.code}`, label: `Cash – ${s.name}` })).concat(banks.map((b) => ({ value: `bank:${b.uid}`, label: `Bank – ${b.name}` })));
}
const D = (code, amount, shop) => ({ code, debit: r2(amount), credit: 0, shop: shop || OFFICE });
const C = (code, amount, shop) => ({ code, debit: 0, credit: r2(amount), shop: shop || OFFICE });

// ---------------------------------------------------------------- opening balances
// The balances on the day the books start (from the accountant's last balance sheet). Saving again replaces them.
// Loans are not entered here (each loan has its own opening balance in Loans); the difference goes to opening capital (3000).
export function openingBalances() {
  const j = db().get("SELECT * FROM gl_journals WHERE kind = 'opening' AND status = 'active' ORDER BY created_at DESC LIMIT 1");
  return j ? { uid: j.uid, date: j.jdate, lines: J(j.lines, []).filter((l) => l.code !== '3000' || !J(j.meta, {}).auto3000 || true) } : null;
}
export function saveOpeningBalances(user, { date, lines }) {
  need(DATE.test(txt(date)), 'Enter the date the books start (YYYY-MM-DD).');
  const clean = (lines || []).map((l) => ({ code: txt(l.code), shop: txt(l.shop) || OFFICE, debit: r2(l.debit), credit: r2(l.credit) })).filter((l) => l.code && (l.debit || l.credit));
  need(clean.length, 'Enter at least one balance.');
  need(!clean.some((l) => l.code.startsWith('2500')), 'Loans are entered in Invoices & cheques › Regular bills & loans (each with its balance at the start).');
  need(!clean.some((l) => l.code === '2000'), 'Money owed to suppliers: enter each unpaid invoice in Invoices & cheques instead (so it can be paid there).');
  need(!clean.some((l) => l.code === '1300') || !db().get("SELECT 1 AS x FROM inv_moves WHERE type = 'opening' AND status = 'active' LIMIT 1"), 'Stock is already in the books from the inventory import (opening stock) – leave it out here.');
  need(!clean.some((l) => l.code === '1500' || l.code === '1590'), 'Equipment and vehicles are entered in Equipment & vehicles (fixed assets).');
  const dr = r2(clean.reduce((s, l) => s + l.debit, 0)); const cr = r2(clean.reduce((s, l) => s + l.credit, 0));
  const diff = r2(dr - cr);
  const lines2 = clean.filter((l) => l.code !== '3000' || (l.debit || l.credit));
  if (Math.abs(diff) > 0.004) lines2.push(diff > 0 ? C('3000', diff) : D('3000', -diff));
  const old = openingBalances();
  db().transaction(() => {
    if (old) A.voidJournal(user, old.uid, 'Opening balances entered again');
    A.saveJournal(user, { date, memo: 'Opening balances', lines: lines2, kind: 'opening', meta: { balancedTo3000: diff } });
  });
  saveAcctSettings(user, { goLive: date });
  return { balancingAmount: diff };
}

// ---------------------------------------------------------------- typed straight into the books
// A sale not through the tills (e.g. a bulk order, a shop with no till count that day).
export function saveSale(user, { date, shop, total, zero = 0, vat, via, account = '4000', note, reference }) {
  const t = r2(total);
  need(t > 0, 'Enter the amount received (incl. VAT).');
  need(txt(shop), 'Choose the shop.');
  const z = Math.min(t, r2(zero));
  const v = vat === undefined || vat === '' || vat === null ? vatIn(t - z) : r2(vat);
  need(v >= 0 && v < t, 'The VAT amount is not right.');
  const to = moneyCode(via, shop);
  return A.saveJournal(user, { date, memo: `Sale${note ? `: ${txt(note)}` : ''}`, kind: 'sale', meta: { total: t, vat: v, zero: z, shop, reference: txt(reference) || null },
    lines: [D(to.code, t, to.shop), C(account, t - v, shop), C('2200', v, shop)] });
}
// An expense paid without a supplier invoice in Payables (petty receipts, a bill paid at the counter…).
export function saveExpense(user, { date, shop, account, total, vat, claimVat = true, via, supplier, tin, invoiceNo, note, photos = [], reference }) {
  const t = r2(total);
  need(t > 0, 'Enter the amount paid (incl. VAT).');
  need(txt(account), 'Choose what it was for (the account).');
  const v = !claimVat ? 0 : vat === undefined || vat === '' || vat === null ? vatIn(t) : r2(vat);
  need(v >= 0 && v < t, 'The VAT amount is not right.');
  const from = moneyCode(via, shop);
  const uid = A.saveJournal(user, { date, memo: `${txt(supplier) || 'Expense'}${note ? `: ${txt(note)}` : ''}`, kind: 'expense',
    meta: { total: t, vat: v, zero: 0, shop: shop || OFFICE, supplier: txt(supplier) || null, tin: txt(tin) || null, no: txt(invoiceNo) || null, reference: txt(reference) || null },
    lines: [D(account, t - v, shop), D('2200', v, shop), C(from.code, t, from.shop)].filter((l) => l.debit || l.credit) });
  if (photos.length) addPhotos('journal', uid, photos);
  return uid;
}
export function saveIncome(user, { date, shop, account = '4900', total, vat = 0, via, note }) {
  const t = r2(total);
  need(t > 0, 'Enter the amount.');
  need(txt(note), 'Say what the income is.');
  const v = r2(vat);
  const to = moneyCode(via, shop);
  return A.saveJournal(user, { date, memo: `Income: ${txt(note)}`, kind: v ? 'sale' : 'income', meta: v ? { total: t, vat: v, zero: 0, shop: shop || OFFICE } : { shop: shop || OFFICE },
    lines: [D(to.code, t, to.shop), C(account, t - v, shop), C('2200', v, shop)].filter((l) => l.debit || l.credit) });
}
// The owner putting money in or taking it out (drawings).
export function saveOwnerMoney(user, { date, direction, amount, via, note }) {
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(['in', 'out'].includes(direction), 'Money in or out?');
  const m = moneyCode(via);
  const lines = direction === 'in' ? [D(m.code, a, m.shop), C('3100', a)] : [D('3100', a), C(m.code, a, m.shop)];
  return A.saveJournal(user, { date, memo: `Owner's money ${direction === 'in' ? 'put in' : 'taken out'}${note ? `: ${txt(note)}` : ''}`, kind: 'owner', lines });
}
// Moving money between a shop's cash and the bank, or between banks (not a deposit slip – those are in Till & cash).
export function saveTransfer(user, { date, amount, from, to, note }) {
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(from && to && from !== to, 'Choose two different places.');
  const f = moneyCode(from); const t = moneyCode(to);
  return A.saveJournal(user, { date, memo: `Transfer${note ? `: ${txt(note)}` : ''}`, kind: 'transfer', lines: [D(t.code, a, t.shop), C(f.code, a, f.shop)] });
}
export function typedEntries({ from, to, kinds } = {}) {
  const k = kinds || ['sale', 'expense', 'income', 'owner', 'transfer'];
  return db().all(`SELECT * FROM gl_journals WHERE kind IN (${k.map(() => '?').join(',')}) AND (? IS NULL OR jdate >= ?) AND (? IS NULL OR jdate <= ?) ORDER BY jdate DESC, created_at DESC LIMIT 500`,
    [...k, from || null, from || null, to || null, to || null]).map((j) => ({ ...j, lines: J(j.lines, []), meta: J(j.meta, {}) }));
}

// ---------------------------------------------------------------- Aronium figures (checked before they reach the books)
export const ARONIUM_FIELDS = {
  sales: [
    { key: 'date', label: 'Date', need: true, guess: ['date', 'day', 'document date', 'sale date', 'z report date'] },
    { key: 'total', label: 'Total sales (incl. VAT)', need: true, guess: ['total', 'total with tax', 'total incl tax', 'gross', 'amount', 'sales', 'grand total', 'total sales'] },
    { key: 'vat', label: 'VAT / tax', guess: ['tax', 'vat', 'tax amount', 'vat amount', 'taxes'] },
    { key: 'zero', label: 'Zero-rated sales', guess: ['zero rated', 'zero-rated', 'zero', 'exempt', 'tax free'] },
    { key: 'cash', label: 'Paid in cash', guess: ['cash'] },
    { key: 'card', label: 'Paid by card / EFTPOS', guess: ['card', 'eftpos', 'credit card', 'debit card'] },
    { key: 'other', label: 'Other payments (M-PAiSA, MyCash…)', guess: ['other', 'mpaisa', 'm-paisa', 'mycash', 'mobile', 'voucher'] },
  ],
  expenses: [
    { key: 'date', label: 'Date', need: true, guess: ['date', 'day', 'document date'] },
    { key: 'description', label: 'What it was', need: true, guess: ['description', 'note', 'reason', 'comment', 'name', 'item', 'details'] },
    { key: 'amount', label: 'Amount (incl. VAT)', need: true, guess: ['amount', 'total', 'value', 'cash out', 'paid out', 'sum'] },
    { key: 'vat', label: 'VAT', guess: ['tax', 'vat', 'tax amount'] },
  ],
};
export const toNum = (v) => {
  let x = txt(v).replace(/[^0-9,.\-()]/g, '');
  if (/^\(.*\)$/.test(x)) x = `-${x.slice(1, -1)}`;
  if (/,\d{1,2}$/.test(x) && (!/\.\d/.test(x) || /\.\d{3},\d{1,2}$/.test(x))) x = x.replace(/\./g, '').replace(',', '.'); else x = x.replace(/,/g, '');
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
};
// Dates as Aronium writes them: 2026-10-09, 09/10/2026 (day first, as in Fiji), 9.10.2026 – a time after it is ignored.
export const toDate = (v) => {
  const s = txt(v).split(/[ T]/)[0];
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/.exec(s);
  if (m) { const y = m[3].length === 2 ? `20${m[3]}` : m[3]; return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
  return null;
};
const normH = (h) => txt(h).toLowerCase().replace(/[^a-z0-9 -]/g, ' ').replace(/\s+/g, ' ').trim();
export function guessAroniumMapping(headers, kind) {
  const hs = headers.map(normH); const map = {};
  for (const f of ARONIUM_FIELDS[kind]) {
    let i = hs.findIndex((h) => f.guess.includes(h));
    if (i < 0) i = hs.findIndex((h) => f.guess.some((g) => h.startsWith(g)));
    if (i >= 0 && !Object.values(map).includes(i)) map[f.key] = i;
  }
  return map;
}
// Reads the CSV into rows (sales are added up per day). Nothing reaches the books yet.
export function readAroniumCsv(text, kind, mapping) {
  need(ARONIUM_FIELDS[kind], 'Sales or expenses?');
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no rows.');
  const map = mapping || guessAroniumMapping(rows[0], kind);
  for (const f of ARONIUM_FIELDS[kind]) if (f.need) need(map[f.key] !== undefined && map[f.key] !== null && map[f.key] !== '', `Match the "${f.label}" column.`);
  const get = (r, k) => (map[k] === undefined || map[k] === null || map[k] === '' ? '' : r[Number(map[k])]);
  const errors = []; const out = [];
  rows.slice(1).forEach((r, n) => {
    if (!r.some((c) => txt(c))) return;
    const d = toDate(get(r, 'date'));
    if (!d) { errors.push(`Row ${n + 2}: date "${get(r, 'date')}" not understood`); return; }
    if (kind === 'sales') {
      out.push({ date: d, total: toNum(get(r, 'total')), vat: get(r, 'vat') === '' ? null : toNum(get(r, 'vat')), zero: toNum(get(r, 'zero')), cash: toNum(get(r, 'cash')), card: toNum(get(r, 'card')), other: toNum(get(r, 'other')) });
    } else {
      const amt = toNum(get(r, 'amount'));
      if (!amt) return;
      out.push({ date: d, description: txt(get(r, 'description')) || 'Paid out', amount: Math.abs(amt), vat: get(r, 'vat') === '' ? null : toNum(get(r, 'vat')) });
    }
  });
  if (kind === 'sales') {
    const by = {};
    for (const x of out) {
      const k = x.date; const b = (by[k] = by[k] || { date: k, total: 0, vat: 0, vatGiven: false, zero: 0, cash: 0, card: 0, other: 0 });
      b.total += x.total; b.zero += x.zero; b.cash += x.cash; b.card += x.card; b.other += x.other;
      if (x.vat !== null) { b.vat += x.vat; b.vatGiven = true; }
    }
    return { rows: Object.values(by).sort((a, b) => (a.date < b.date ? -1 : 1)).map((b) => ({ date: b.date, total: r2(b.total), vat: b.vatGiven ? r2(b.vat) : vatIn(b.total - b.zero), zero: r2(b.zero), cash: r2(b.cash), card: r2(b.card), other: r2(b.other) })), errors, map };
  }
  return { rows: out.map((x) => ({ ...x, vat: x.vat === null ? vatIn(x.amount) : Math.min(Math.max(0, r2(x.vat)), r2(x.amount)), account: '', use: 'book' })), errors, map };
}
// A batch waits on "Aronium figures to check" until someone checks it. The main software can add batches the same way.
export function addAroniumBatch(user, { kind, shopCode, rows, source = 'csv', fileName, note }) {
  need(['sales', 'expenses'].includes(kind), 'Sales or expenses?');
  need(txt(shopCode), 'Choose the shop.');
  need(rows && rows.length, 'Nothing to bring in.');
  const dates = rows.map((r) => r.date).sort();
  const total = r2(rows.reduce((s, r) => s + Number(kind === 'sales' ? r.total : r.amount), 0));
  const dup = db().get("SELECT uid FROM aronium_batches WHERE kind = ? AND shop_code = ? AND from_date = ? AND to_date = ? AND total = ? AND status IN ('to_check','approved')", [kind, shopCode, dates[0], dates[dates.length - 1], total]);
  need(!dup, 'These same figures were already brought in (they are waiting to be checked or already approved).');
  const uid = uuid('AR'); const now = stamp();
  db().run(`INSERT INTO aronium_batches (uid, kind, shop_code, from_date, to_date, data, total, source, file_name, status, note, imported_by, imported_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?, 'to_check', ?,?,?,?,?)`, [uid, kind, shopCode, dates[0], dates[dates.length - 1], JSON.stringify(rows), total, source, txt(fileName) || null, txt(note) || null, user ? user.name : 'System', now, now, deviceId()]);
  audit({ user, action: `Aronium ${kind} brought in for checking: ${shopCode} ${dates[0]}–${dates[dates.length - 1]} ${$(total)}`, table: 'aronium_batches', recordUid: uid });
  return uid;
}
export function listBatches({ status } = {}) {
  return db().all('SELECT * FROM aronium_batches WHERE (? IS NULL OR status = ?) ORDER BY imported_at DESC LIMIT 200', [status || null, status || null]).map((b) => ({ ...b, data: J(b.data, []) }));
}
// What the batch would do: for sales, days that already have a till count are compared (the till count is what is booked).
export function reviewBatch(uid) {
  const b = db().get('SELECT * FROM aronium_batches WHERE uid = ?', [uid]);
  need(b, 'Not found.');
  const rows = J(b.data, []);
  if (b.kind === 'sales') {
    const lines = rows.map((r) => {
      const tc = has('till_counts') ? db().all("SELECT * FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void'", [b.shop_code, r.date]) : [];
      const till = r2(tc.reduce((s, c) => s + (c.z_total !== null && c.z_total !== undefined ? Number(c.z_total) : Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0)), 0));
      const typed = db().get("SELECT COUNT(*) AS n FROM gl_journals WHERE kind IN ('sale','aronium_sale') AND status = 'active' AND jdate = ? AND json_extract(meta, '$.shop') = ?", [r.date, b.shop_code]).n;
      const action = tc.length ? 'compare' : typed ? 'already' : 'book';
      return { ...r, till: tc.length ? till : null, diff: tc.length ? r2(r.total - till) : null, action };
    });
    return { batch: { ...b, data: rows }, lines, toBook: r2(lines.filter((l) => l.action === 'book').reduce((s, l) => s + l.total, 0)), differences: lines.filter((l) => l.action === 'compare' && Math.abs(l.diff) > 0.009) };
  }
  const lines = rows.map((r) => {
    const tc = has('till_counts') ? db().all("SELECT payouts FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void'", [b.shop_code, r.date]) : [];
    const paidOuts = tc.flatMap((c) => J(c.payouts, []));
    const same = paidOuts.find((p) => Math.abs(r2(p.amount) - r.amount) < 0.01);
    return { ...r, inTill: !!same, use: r.use || (same ? 'skip' : 'book') };
  });
  return { batch: { ...b, data: rows }, lines, toBook: r2(lines.filter((l) => l.use === 'book').reduce((s, l) => s + l.amount, 0)), differences: [] };
}
// Approving books it. For expenses each row needs its account (what it was for) – or "skip".
export function approveBatch(user, uid, { rows: edited } = {}) {
  const b = db().get('SELECT * FROM aronium_batches WHERE uid = ?', [uid]);
  need(b && b.status === 'to_check', 'This is not waiting to be checked.');
  if (verifyRules().secondPerson) need(b.imported_by !== user.name, 'A different person must check what was brought in (Admin › Verification).');
  const rev = reviewBatch(uid);
  const journals = [];
  db().transaction(() => {
    if (b.kind === 'sales') {
      for (const l of rev.lines.filter((x) => x.action === 'book')) {
        const lines = [];
        const paidKnown = r2(l.cash + l.card + l.other);
        const cash = paidKnown > 0 ? l.cash : l.total;
        if (cash) lines.push(D('1000', cash, b.shop_code));
        if (paidKnown > 0 && r2(l.card + l.other)) lines.push(D('1110', l.card + l.other, b.shop_code));
        if (paidKnown > 0 && Math.abs(paidKnown - l.total) > 0.009) lines.push(paidKnown > l.total ? C('6900', paidKnown - l.total, b.shop_code) : D('6900', l.total - paidKnown, b.shop_code));
        lines.push(C('4000', l.total - l.vat, b.shop_code), C('2200', l.vat, b.shop_code));
        journals.push(A.saveJournal(user, { date: l.date, memo: `Aronium sales ${b.shop_code} ${l.date}`, kind: 'aronium_sale', refUid: uid, meta: { total: l.total, vat: l.vat, zero: l.zero, shop: b.shop_code, batch: uid }, lines: lines.filter((x) => x.debit || x.credit) }));
      }
    } else {
      const rows = (edited || rev.lines).map((r, i) => ({ ...rev.lines[i], ...(r || {}) }));
      for (const r of rows) {
        if (r.use === 'skip') continue;
        need(txt(r.account), `Choose what "${r.description}" (${$(r.amount)}) was for, or skip it.`);
        const v = r2(r.vat);
        journals.push(A.saveJournal(user, { date: r.date, memo: `Aronium paid out ${b.shop_code}: ${r.description}`, kind: 'aronium_expense', refUid: uid,
          meta: { total: r.amount, vat: v, zero: 0, shop: b.shop_code, supplier: r.description, batch: uid },
          lines: [D(r.account, r.amount - v, b.shop_code), D('2200', v, b.shop_code), C('1000', r.amount, b.shop_code)].filter((x) => x.debit || x.credit) }));
      }
      db().run(`UPDATE aronium_batches SET data = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(rows.map(({ inTill, ...x }) => x)), stamp(), deviceId(), uid]);
    }
    db().run(`UPDATE aronium_batches SET status = 'approved', checked_by = ?, checked_by_uid = ?, checked_at = ?, ${SYNCED} WHERE uid = ?`, [user.name, user.uid, stamp(), stamp(), deviceId(), uid]);
  });
  audit({ user, action: `Checked and approved Aronium ${b.kind} ${b.shop_code} ${b.from_date}–${b.to_date}: ${journals.length} entr${journals.length === 1 ? 'y' : 'ies'} booked`, table: 'aronium_batches', recordUid: uid });
  return { booked: journals.length, differences: rev.differences };
}
export function rejectBatch(user, uid, reason) {
  const b = db().get('SELECT * FROM aronium_batches WHERE uid = ?', [uid]);
  need(b && b.status === 'to_check', 'This is not waiting to be checked.');
  need(txt(reason), 'Say what is wrong with it.');
  db().run(`UPDATE aronium_batches SET status = 'rejected', reject_reason = ?, checked_by = ?, checked_at = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), user.name, stamp(), stamp(), deviceId(), uid]);
  audit({ user, action: `Rejected Aronium ${b.kind} ${b.shop_code} ${b.from_date}–${b.to_date}`, table: 'aronium_batches', recordUid: uid, reason: txt(reason) });
}
// Undo an approval: the entries it made are taken out again and it goes back to "to check".
export function undoBatch(user, uid, reason) {
  const b = db().get('SELECT * FROM aronium_batches WHERE uid = ?', [uid]);
  need(b && b.status === 'approved', 'Only an approved batch can be undone.');
  need(txt(reason), 'Say why.');
  db().transaction(() => {
    for (const j of db().all("SELECT uid FROM gl_journals WHERE ref_uid = ? AND status = 'active'", [uid])) A.voidJournal(user, j.uid, `Aronium batch undone: ${txt(reason)}`);
    db().run(`UPDATE aronium_batches SET status = 'to_check', checked_by = NULL, checked_by_uid = NULL, checked_at = NULL, note = ?, ${SYNCED} WHERE uid = ?`, [`Undone: ${txt(reason)}`, stamp(), deviceId(), uid]);
  });
  audit({ user, action: `Undid Aronium ${b.kind} ${b.shop_code} ${b.from_date}–${b.to_date}`, table: 'aronium_batches', recordUid: uid, reason: txt(reason) });
}

// ---------------------------------------------------------------- loans (kept in Invoices & cheques › Regular bills & loans)
// The books, statements and forecast read the same loans: balance at the start + interest / fees − repayments.
export function listLoans({ all = false, asOf = dateStr() } = {}) {
  if (!has('ap_recurring')) return [];
  return db().all(`SELECT r.*, s.name AS lender FROM ap_recurring r LEFT JOIN ap_suppliers s ON s.uid = r.supplier_uid WHERE r.kind = 'loan' ${all ? '' : 'AND r.active = 1'} ORDER BY r.name`).map((r) => loanFigures(r, asOf));
}
export function getLoan(uid, asOf = dateStr()) {
  const r = has('ap_recurring') ? db().get("SELECT r.*, s.name AS lender FROM ap_recurring r LEFT JOIN ap_suppliers s ON s.uid = r.supplier_uid WHERE r.uid = ? AND r.kind = 'loan'", [uid]) : null;
  return r ? loanFigures(r, asOf) : null;
}
// Balance as the books see it on a date (opening + interest/fees ± corrections − repayment bills), and this year's figures.
function loanFigures(r, asOf) {
  const code = `2500:${r.uid}`;
  const yr = asOf.slice(0, 4);
  let balance = 0; let paidThisYear = 0; let interestThisYear = 0; let lastPaid = null;
  for (const e of A.entries({ to: asOf })) {
    for (const l of e.lines) {
      if (l.code !== code) continue;
      balance = r2(balance - l.amount);
      if (e.date.startsWith(yr) && e.src === 'Loan repayment') paidThisYear = r2(paidThisYear + l.amount);
      if (e.src === 'Loan repayment') lastPaid = e.date;
    }
    if (e.date.startsWith(yr) && e.src === 'Loan' && e.lines.some((l) => l.code === code) && e.lines.some((l) => l.code === '6700')) interestThisYear = r2(interestThisYear + e.lines.find((l) => l.code === '6700').amount);
  }
  return { uid: r.uid, name: r.name, lender: r.lender, account_no: r.loan_no, rate: r.interest_rate, repayment: r.amount, frequency: r.frequency, status: r.active ? 'active' : 'closed',
    opening_balance: r.opening_balance, opening_date: r.opening_date, next_date: r.next_date, balance, paidThisYear, interestThisYear, lastPaid };
}
// The coming repayments until the loan is paid off (a guide from the rate and the repayment amount).
export function loanSchedule(uid, { max = 120 } = {}) {
  const l = getLoan(uid);
  if (!l || !l.repayment || l.balance <= 0) return [];
  const months = { monthly: 1, quarterly: 3, yearly: 12 }[l.frequency];
  const step = months ? (d) => addMonths(d, months) : (d) => addDays(d, l.frequency === 'weekly' ? 7 : 14);
  const f = months ? months / 12 : (l.frequency === 'weekly' ? 7 : 14) / 365;
  let bal = l.balance; let d = l.next_date || dateStr(); const out = [];
  for (let k = 0; k < max && bal > 0.004; k += 1) {
    const interest = r2(bal * (Number(l.rate || 0) / 100) * f);
    const pay = Math.min(r2(l.repayment), r2(bal + interest));
    if (pay <= interest) { out.push({ date: d, payment: pay, interest, principal: 0, balance: bal, warning: 'The repayment does not cover the interest.' }); break; }
    bal = r2(bal - (pay - interest));
    out.push({ date: d, payment: pay, interest, principal: r2(pay - interest), balance: bal });
    d = step(d);
  }
  return out;
}

// ---------------------------------------------------------------- repeating journals, prepayments, accruals
export function saveRecurring(user, { uid, memo, lines, nextDate, endDate, times, reverse = false, kind = 'repeat' }) {
  need(txt(memo), 'Say what it is for.');
  need(DATE.test(txt(nextDate)), 'Enter the first date.');
  const clean = (lines || []).map((l) => ({ code: txt(l.code), debit: r2(l.debit), credit: r2(l.credit), shop: txt(l.shop) || OFFICE })).filter((l) => l.code && (l.debit || l.credit));
  need(clean.length >= 2, 'A journal needs at least two lines.');
  need(Math.abs(clean.reduce((s, l) => s + l.debit - l.credit, 0)) < 0.005, 'Debits and credits must be equal.');
  const id = uid || uuid('RJ'); const now = stamp();
  db().run(`INSERT INTO gl_recurring (uid, memo, lines, kind, next_date, end_date, times_left, reverse, active, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,1,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET memo = excluded.memo, lines = excluded.lines, next_date = excluded.next_date, end_date = excluded.end_date, times_left = excluded.times_left, reverse = excluded.reverse, active = 1,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [id, txt(memo), JSON.stringify(clean), kind, txt(nextDate), txt(endDate) || null, txt(times) === '' || times === undefined || times === null ? null : Math.max(1, Math.round(Number(times))), reverse ? 1 : 0, user.name, now, now, deviceId()]);
  audit({ user, action: `Repeating journal: ${txt(memo)}`, table: 'gl_recurring', recordUid: id });
  return id;
}
export function listRecurring() { return db().all('SELECT * FROM gl_recurring ORDER BY active DESC, next_date').map((r) => ({ ...r, lines: J(r.lines, []) })); }
export function stopRecurring(user, uid) {
  db().run(`UPDATE gl_recurring SET active = 0, ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: 'Stopped a repeating journal', table: 'gl_recurring', recordUid: uid });
}
// Makes the journals that have come due (run when Accounting is opened). Months already closed are skipped.
export function runRecurring(user, today = dateStr()) {
  const made = [];
  const lock = lockDate();
  const who = user || { name: 'Repeating journal', uid: null };
  for (const r of db().all("SELECT * FROM gl_recurring WHERE active = 1 AND next_date <= ?", [today])) {
    let next = r.next_date; let left = r.times_left; let guard = 0;
    while (next <= today && guard < 36 && (left === null || left > 0) && (!r.end_date || next <= r.end_date)) {
      guard += 1;
      // A month already closed is never changed: its share is booked on the first open day instead (and says so).
      const late = lock && next <= lock;
      const d = late ? addDays(lock, 1) : next;
      if (d <= today) {
        const lines = J(r.lines, []);
        // Fixed ids, so two tablets running this before they sync never book it twice.
        const uid = A.saveJournal(who, { uid: `RJ-${r.uid}-${next}`, date: d, memo: `${r.memo}${late ? ` (for ${next.slice(0, 7)} – that month was already closed)` : ''}`, lines, kind: r.kind || 'repeat', refUid: r.uid });
        made.push(uid);
        if (r.reverse) {
          const rd0 = addDays(monthEnd(next.slice(0, 7)), 1);
          const rd = lock && rd0 <= lock ? addDays(lock, 1) : rd0;
          A.saveJournal(who, { uid: `RJR-${r.uid}-${next}`, date: rd < d ? d : rd, memo: `Reversal: ${r.memo}`, kind: 'reverse', refUid: r.uid, lines: lines.map((l) => ({ ...l, debit: l.credit, credit: l.debit })) });
        }
      } else break;
      next = nextMonthSameDay(next);
      if (left !== null) left -= 1;
    }
    const done = (left !== null && left <= 0) || (r.end_date && next > r.end_date);
    db().run(`UPDATE gl_recurring SET next_date = ?, times_left = ?, active = ?, ${SYNCED} WHERE uid = ?`, [next, left, done ? 0 : 1, stamp(), deviceId(), r.uid]);
  }
  return made;
}
// Same day next month; a month-end stays a month-end (31 Jan → 28 Feb → 31 Mar).
export function nextMonthSameDay(d) {
  if (d === monthEnd(d.slice(0, 7))) return monthEnd(addMonths(`${d.slice(0, 7)}-01`, 1).slice(0, 7));
  return addMonths(d, 1);
}
// Paid for several months at once (insurance, licences, rent in advance): the cost is spread over those months.
export function spreadPrepayment(user, { date, amount, account, months, memo, shop }) {
  const a = r2(amount); const n = Math.round(Number(months));
  need(a > 0, 'Enter the amount (excl. VAT).');
  need(n >= 2 && n <= 60, 'Spread over 2 to 60 months.');
  need(txt(account), 'Choose the cost account (e.g. Insurance).');
  need(DATE.test(txt(date)), 'Enter the date it was paid.');
  const what = txt(memo) || A.accountName(account);
  // 1. Take it out of this month's costs into "paid in advance"…
  A.saveJournal(user, { date, memo: `${what} – paid in advance`, kind: 'prepay', lines: [D('1400', a, shop), C(account, a, shop)] });
  // 2. …then a share comes back into costs every month.
  const per = r2(a / n); const last = r2(a - per * (n - 1));
  const first = monthEnd(txt(date).slice(0, 7));
  const id = saveRecurring(user, { memo: `${what} – share for the month`, nextDate: first, times: n - 1, kind: 'prepay', lines: [D(account, per, shop), C('1400', per, shop)] });
  const lastDate = monthEnd(addMonths(`${txt(date).slice(0, 7)}-01`, n - 1).slice(0, 7));
  A.saveJournal(user, { date: lastDate, memo: `${what} – last share`, kind: 'prepay', lines: [D(account, last, shop), C('1400', last, shop)] });
  return id;
}
// A cost that belongs to this month but is not billed yet (e.g. power used): booked now, taken back next month when the bill comes.
export function accrue(user, { date, amount, account, memo, shop }) {
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(txt(account), 'Choose the cost account.');
  need(DATE.test(txt(date)), 'Enter the date (usually the last day of the month).');
  const what = txt(memo) || A.accountName(account);
  const uid = A.saveJournal(user, { date, memo: `${what} – owing, not billed yet`, kind: 'accrual', lines: [D(account, a, shop), C('2300', a)] });
  A.saveJournal(user, { date: addDays(monthEnd(txt(date).slice(0, 7)), 1), memo: `Reversal: ${what} – owing, not billed yet`, kind: 'reverse', refUid: uid, lines: [D('2300', a), C(account, a, shop)] });
  return uid;
}

// ---------------------------------------------------------------- provisional tax (5% kept back from contractors)
export function provTaxMonths({ year } = {}) {
  if (!has('ap_payments')) return [];
  const rows = db().all(`SELECT substr(pay_date,1,7) AS ym, SUM(withheld) AS w, COUNT(*) AS n FROM ap_payments WHERE status = 'active' AND withheld > 0 AND method IN ('cheque','cash','transfer') ${year ? 'AND substr(pay_date,1,4) = ?' : ''} GROUP BY ym ORDER BY ym DESC`, year ? [String(year)] : []);
  const paid = db().all("SELECT jdate, lines, meta FROM gl_journals WHERE status = 'active' AND kind = 'tax_payment'").map((j) => ({ ...J(j.meta, {}), date: j.jdate })).filter((m) => m.tax === 'prov');
  const today = dateStr();
  return rows.map((r) => {
    const p = paid.filter((x) => x.ym === r.ym);
    const paidAmt = r2(p.reduce((s, x) => s + Number(x.amount || 0), 0));
    const due = A.lastDayOfNextMonth(r.ym);
    const owing = r2(r.w - paidAmt);
    return { ym: r.ym, withheld: r2(r.w), payments: r.n, paid: paidAmt, owing, due, state: owing <= 0.004 ? 'paid' : due < today ? 'late' : addDays(today, 10) >= due ? 'due_soon' : 'to_pay', paidOn: p.length ? p[p.length - 1].date : null };
  });
}
// Each contractor's yearly total (for their certificate).
export function provTaxBySupplier(year) {
  if (!has('ap_payments')) return [];
  return db().all(`SELECT p.supplier_uid, p.supplier_name AS name, s.tin, SUM(p.amount) AS gross, SUM(p.withheld) AS withheld, COUNT(*) AS n FROM ap_payments p LEFT JOIN ap_suppliers s ON s.uid = p.supplier_uid
    WHERE p.status = 'active' AND p.withheld > 0 AND p.method IN ('cheque','cash','transfer') AND substr(p.pay_date,1,4) = ? GROUP BY p.supplier_uid ORDER BY p.supplier_name`, [String(year)]).map((r) => ({ ...r, gross: r2(r.gross), withheld: r2(r.withheld) }));
}

// ---------------------------------------------------------------- tax payments (provisional tax, company advance tax, company tax, VAT)
export const TAX_KINDS = { prov: 'Provisional tax (5% withheld)', advance: 'Company advance tax instalment', company: 'Company income tax (final)', vat: 'VAT' };
export function recordTaxPayment(user, { tax, date, amount, via, ym, year, n, reference }) {
  need(TAX_KINDS[tax], 'Which tax?');
  const a = r2(amount);
  need(a > 0, 'Enter the amount paid.');
  const m = moneyCode(via);
  const code = { prov: '2600', advance: '1450', company: '2700', vat: '2200' }[tax];
  return A.saveJournal(user, { date, memo: `${TAX_KINDS[tax]}${ym ? ` ${ym}` : ''}${year ? ` ${year}` : ''}${n ? ` (instalment ${n})` : ''} paid to FRCS`, kind: 'tax_payment',
    meta: { tax, amount: a, ym: ym || null, year: year || null, n: n || null, reference: txt(reference) || null }, lines: [D(code, a), C(m.code, a, m.shop)] });
}
// Company advance tax: a third of last year's tax at the end of months 6, 9 and 12 of the tax year.
export function advanceTaxPlan(year = Number(dateStr().slice(0, 4)), today = dateStr()) {
  const s = acctSettings();
  if (!s.advanceTax || !(s.lastYearTax > 0)) return [];
  const endM = s.taxYearEndMonth;
  const startYm = (() => { const y = endM === 12 ? year : year - 1; const mo = endM === 12 ? 1 : endM + 1; return `${y}-${String(mo).padStart(2, '0')}`; })();
  const paid = db().all("SELECT jdate, meta FROM gl_journals WHERE status = 'active' AND kind = 'tax_payment'").map((j) => ({ ...J(j.meta, {}), date: j.jdate })).filter((m) => m.tax === 'advance' && String(m.year) === String(year));
  const third = r2(s.lastYearTax / 3);
  return [6, 9, 12].map((k, i) => {
    const due = monthEnd(addMonths(`${startYm}-01`, k - 1).slice(0, 7));
    const p = paid.filter((x) => Number(x.n) === i + 1);
    const got = r2(p.reduce((t, x) => t + Number(x.amount || 0), 0));
    const amount = i === 2 ? r2(s.lastYearTax - third * 2) : third;
    const state = got >= amount - 0.004 ? 'paid' : s.advanceFrom && due < s.advanceFrom ? 'before' : due < today ? 'late' : addDays(today, 14) >= due ? 'due_soon' : 'to_pay';
    return { n: i + 1, due, amount, paid: got, state };
  });
}

// ---------------------------------------------------------------- closing a year
export function closeYear(user, year) {
  const y = String(year);
  const end = `${y}-12-31`;
  const lock = lockDate();
  need(lock && lock >= end, `Close the books to ${end} first (Accounting › Month end › Close up to).`);
  const bal = {};
  for (const e of A.entries({ to: end })) for (const l of e.lines) { const k = `${l.code}|${l.shop}`; bal[k] = r2((bal[k] || 0) + l.amount); }
  Object.keys(bal).forEach((k) => { if (Math.abs(bal[k]) < 0.005) delete bal[k]; });
  const pl = A.profitLoss({ from: `${y}-01-01`, to: end, shops: [] });
  const now = stamp();
  db().run(`INSERT INTO gl_year_close (year, closed_to, balances, profit, by_name, closed_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?)
    ON CONFLICT(year) DO UPDATE SET closed_to = excluded.closed_to, balances = excluded.balances, profit = excluded.profit, by_name = excluded.by_name, closed_at = excluded.closed_at,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`, [y, end, JSON.stringify(bal), pl.per.total.profit, user.name, now, now, deviceId()]);
  audit({ user, action: `Year ${y} closed – profit ${$(pl.per.total.profit)} kept in the business`, table: 'gl_year_close', recordUid: y });
  return { year: y, profit: pl.per.total.profit };
}
export function closedYears() {
  const lock = lockDate();
  return db().all('SELECT year, closed_to, profit, by_name, closed_at FROM gl_year_close ORDER BY year DESC').map((r) => ({ ...r, stillLocked: r.closed_to !== REOPENED && !!lock && lock >= r.closed_to }));
}

export const REOPENED = '9999-12-31';
// ---------------------------------------------------------------- what needs doing
export function accountingAlerts(today = dateStr()) {
  const out = [];
  const lastYm = (() => { const d = new Date(`${today.slice(0, 7)}-01T00:00:00`); d.setMonth(d.getMonth() - 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; })();
  const ticks = getShared(`month_end_${lastYm}`, {}) || {};
  const vatDue = A.lastDayOfNextMonth(lastYm);
  if (!ticks.vat && addDays(today, 10) >= vatDue) out.push({ tone: vatDue < today ? 'danger' : 'warn', key: 'vat', text: `VAT return for ${lastYm} ${vatDue < today ? 'was due' : 'is due'} ${vatDue}` });
  for (const p of provTaxMonths()) if (p.state === 'late' || p.state === 'due_soon') out.push({ tone: p.state === 'late' ? 'danger' : 'warn', key: `prov-${p.ym}`, text: `Provisional tax for ${p.ym}: ${$(p.owing)} ${p.state === 'late' ? 'LATE – was due' : 'due'} ${p.due}` });
  for (const i of advanceTaxPlan(Number(today.slice(0, 4)), today)) if (i.state === 'late' || i.state === 'due_soon') out.push({ tone: i.state === 'late' ? 'danger' : 'warn', key: `adv-${i.n}`, text: `Company advance tax instalment ${i.n}: ${$(i.amount - i.paid)} ${i.state === 'late' ? 'LATE – was due' : 'due'} ${i.due}` });
  const waiting = has('aronium_batches') ? db().get("SELECT COUNT(*) AS n FROM aronium_batches WHERE status = 'to_check'").n : 0;
  if (waiting) out.push({ tone: 'info', key: 'aronium', text: `${waiting} set(s) of Aronium figures waiting to be checked` });
  return out;
}
