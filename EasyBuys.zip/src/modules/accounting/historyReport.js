// 1.0.0 build 15 (owner, 7 Nov: "what we can do for now is the VAT, since the invoices and sales are available"): the
// VAT return of a month from before the app, and all those months on one page, as a PDF or Excel (shareReport). Built
// from the cloud's answers (hist_month, hist_months – see screens/HistoryScreens.js); a worksheet for the VAT return,
// not the FRCS form itself. Pure: no database, so it is tested on its own.
import { getShared } from '../../services/core.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const r2 = (x) => Math.round((Number(x) || 0) * 100) / 100;
const n2 = (x) => (x === null || x === undefined || x === '' ? '' : r2(x).toFixed(2));
const $ = (x) => `${Number(x) < 0 ? '-' : ''}$${Math.abs(r2(x)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const ymText = (ym) => { const m = /^(\d{4})-(\d{2})$/.exec(String(ym || '')); return m ? `${MONTHS[+m[2] - 1]} ${m[1]}` : String(ym || ''); };
const lastDay = (ym) => { const [y, m] = String(ym).split('-').map(Number); return `${ym}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`; };
function biz() {
  let t = {};
  try { t = getShared('report_template', {}) || {}; } catch (e) { t = {}; }
  return { name: t.businessName || 'Easy Buys Shopping Center', tin: t.tin || '' };
}
const STATUS = { ok: 'Read', fixed: 'Checked', check: 'OPEN', dup: 'Same as another file', after: 'After the cut-off', excluded: 'Left out' };

// One month: m = the cloud's hist_month answer { ym, summary, invoices, sales, shops }.
export function histVatReturn(m) {
  const s = m.summary || {};
  const b = biz();
  const counted = (m.invoices || []).filter((x) => x.status === 'ok' || x.status === 'fixed');
  const open = (m.invoices || []).filter((x) => x.status === 'check');
  const other = (m.invoices || []).filter((x) => !['ok', 'fixed', 'check'].includes(x.status));
  const shops = (m.shops && m.shops.length ? m.shops : Object.keys(m.sales || {}));
  const net = r2(s.net);
  const sum = (list, k) => r2(list.reduce((a, x) => a + (Number(x[k]) || 0), 0));
  const status = s.closed ? `Closed by ${s.closed.by || 'the owner'} on ${String(s.closed.at || '').slice(0, 10)}` : 'NOT CLOSED – the figures may still change';
  const sections = [
    { title: 'VAT return (worksheet)', columns: [col('line', ''), col('what', 'What'), col('v', 'Amount', R)],
      rows: [
        { line: 'A', what: 'Standard-rated sales (incl. VAT)', v: n2(s.sales_std) },
        { line: 'B', what: 'Zero-rated sales', v: n2(s.sales_zero) },
        { line: 'C', what: 'Total sales (A + B)', v: n2(r2(s.sales_std) + r2(s.sales_zero)) },
        { line: 'D', what: `VAT on sales (output tax, ${s.rate}%)`, v: n2(s.output_vat) },
        { line: 'E', what: `Purchases on the invoices (incl. VAT, ${s.invoices || 0} invoices)`, v: n2(s.purchases) },
        { line: 'F', what: 'VAT on purchases (input tax)', v: n2(s.input_vat) },
        { line: 'G', what: net >= 0 ? 'VAT to pay (D − F)' : 'VAT refund (F − D)', v: n2(Math.abs(net)) },
      ] },
    { title: 'Sales by shop', columns: [col('shop', 'Shop'), col('how', 'Entered'), col('std', 'Standard-rated', R), col('zero', 'Zero-rated', R), col('vat', 'Output VAT', R)],
      rows: shops.map((sh) => { const x = (m.sales || {})[sh]; return { shop: sh, how: !x || !x.entered ? 'NOT ENTERED' : x.mode === 'day' ? 'Day by day' : 'Whole month', std: x ? n2(x.std) : '', zero: x ? n2(x.zero) : '', vat: x ? n2(x.vat) : '' }; }) },
    { title: `Invoices in this VAT (${counted.length})`, columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('tin', 'TIN'), col('no', 'Invoice no.'), col('shop', 'Shop'), col('sub', 'Before VAT', R), col('vat', 'VAT', R), col('total', 'Total', R), col('how', 'How'), col('file', 'File')],
      rows: counted.map((x) => ({ date: x.date, supplier: x.supplier, tin: x.tin, no: x.invoice_no, shop: x.shop, sub: n2(x.subtotal), vat: n2(x.vat), total: n2(x.total), how: STATUS[x.status] || x.status, file: x.url || x.file }))
        .concat(counted.length ? [{ date: 'Total', supplier: '', tin: '', no: '', shop: '', sub: n2(sum(counted, 'subtotal')), vat: n2(sum(counted, 'vat')), total: n2(sum(counted, 'total')), how: '', file: '' }] : []) },
  ];
  if (open.length) sections.push({ title: `Open items – NOT in this VAT (${open.length})`, columns: [col('date', 'Date'), col('file', 'File'), col('shop', 'Shop'), col('why', 'Why')],
    rows: open.map((x) => ({ date: x.date, file: x.url || x.file, shop: x.shop, why: x.why })) });
  if (other.length) sections.push({ title: `Not counted (${other.length})`, columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('no', 'Invoice no.'), col('vat', 'VAT', R), col('total', 'Total', R), col('why', 'Why')],
    rows: other.map((x) => ({ date: x.date, supplier: x.supplier, no: x.invoice_no, vat: n2(x.vat), total: n2(x.total), why: `${STATUS[x.status] || x.status}${x.why ? ` – ${x.why}` : ''}` })) });
  return {
    kind: 'hist_vat', title: `VAT return – ${ymText(m.ym)}`, fileName: `VAT-return-${m.ym}`,
    subtitle: `${b.name}${b.tin ? ` · TIN ${b.tin}` : ''} · ${m.ym}-01 to ${lastDay(m.ym)} · from the invoices and sales before the app`,
    info: [['Business', b.name], ['TIN', b.tin || '–'], ['Period', `${m.ym}-01 to ${lastDay(m.ym)}`], ['VAT rate', `${s.rate}%`], ['Status', status], ['Open items', String(open.length)]],
    summary: [{ label: 'VAT on sales', value: $(s.output_vat) }, { label: 'VAT on purchases', value: $(s.input_vat) }, { label: net >= 0 ? 'VAT to pay' : 'VAT refund', value: $(Math.abs(net)) }],
    sections,
  };
}

// Every month on one page: d = the cloud's hist_months answer { months: [...] } (newest first).
export function histVatMonths(d) {
  const b = biz();
  const ms = (d.months || []).slice().sort((a, x) => (a.ym < x.ym ? -1 : 1));
  const tot = (k) => r2(ms.reduce((a, x) => a + (Number(x[k]) || 0), 0));
  const rows = ms.map((x) => ({ ym: ymText(x.ym), std: n2(x.sales_std), zero: n2(x.sales_zero), out: n2(x.output_vat), purch: n2(x.purchases), inp: n2(x.input_vat), net: n2(x.net), open: x.open ? String(x.open) : '', closed: x.closed ? `Closed ${String(x.closed.at || '').slice(0, 10)}` : 'Not closed' }));
  if (ms.length) rows.push({ ym: 'Total', std: n2(tot('sales_std')), zero: n2(tot('sales_zero')), out: n2(tot('output_vat')), purch: n2(tot('purchases')), inp: n2(tot('input_vat')), net: n2(tot('net')), open: String(ms.reduce((a, x) => a + (x.open || 0), 0) || ''), closed: '' });
  const range = ms.length ? `${ymText(ms[0].ym)} to ${ymText(ms[ms.length - 1].ym)}` : '';
  return {
    kind: 'hist_vat_months', title: 'VAT by month – before the app', fileName: `VAT-by-month${ms.length ? `-${ms[0].ym}-to-${ms[ms.length - 1].ym}` : ''}`,
    subtitle: `${b.name}${b.tin ? ` · TIN ${b.tin}` : ''} · ${range}`,
    info: [['Business', b.name], ['Months', String(ms.length)], ['Closed', String(ms.filter((x) => x.closed).length)], ['Open items', String(ms.reduce((a, x) => a + (x.open || 0), 0))]],
    summary: [{ label: 'VAT on sales', value: $(tot('output_vat')) }, { label: 'VAT on purchases', value: $(tot('input_vat')) }, { label: 'Net (to pay − refunds)', value: $(tot('net')) }],
    sections: [{ title: 'Each month', columns: [col('ym', 'Month'), col('std', 'Standard-rated sales', R), col('zero', 'Zero-rated sales', R), col('out', 'Output VAT', R), col('purch', 'Purchases', R), col('inp', 'Input VAT', R), col('net', 'To pay (− refund)', R), col('open', 'Open', R), col('closed', 'Closed')], rows }],
  };
}
