// Accounting & VAT: books built from the other modules, VAT return per shop, P&L per shop, balance sheet, journals,
// fixed assets, budgets, month end and closing.
import { AccountingHomeScreen, VatReturnScreen, ProfitLossScreen, BalanceSheetScreen, TrialBalanceScreen, LedgerScreen, JournalsScreen, ChartOfAccountsScreen, AssetsScreen, BudgetsScreen, MonthEndScreen } from './screens/AccountingScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

const view = (u) => can(u, 'accounts_view');
export default {
  id: 'accounting',
  title: 'Accounting & VAT',
  icon: '📚',
  switchable: true,
  screens: {
    Accounting: { component: AccountingHomeScreen, can: view },
    VatReturn: { component: VatReturnScreen, can: view },
    ProfitLoss: { component: ProfitLossScreen, can: view },
    BalanceSheet: { component: BalanceSheetScreen, can: view },
    TrialBalance: { component: TrialBalanceScreen, can: view },
    Ledger: { component: LedgerScreen, can: view },
    Journals: { component: JournalsScreen, can: (u) => can(u, 'accounts_journal') },
    ChartOfAccounts: { component: ChartOfAccountsScreen, can: (u) => can(u, 'accounts_setup') },
    Assets: { component: AssetsScreen, can: view },
    Budgets: { component: BudgetsScreen, can: view },
    MonthEnd: { component: MonthEndScreen, can: view },
  },
  reports: REPORTS,
};
