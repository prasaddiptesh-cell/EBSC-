// Accounting & VAT: books built from the other modules, VAT return per shop, P&L per shop, balance sheet, journals,
// fixed assets, budgets, month end and closing.
import { AccountingHomeScreen, VatReturnScreen, ProfitLossScreen, BalanceSheetScreen, TrialBalanceScreen, LedgerScreen, JournalsScreen, ChartOfAccountsScreen, AssetsScreen, BudgetsScreen, MonthEndScreen } from './screens/AccountingScreens.js';
import { REPORTS } from './reports.js';
import { INSIGHT_REPORTS } from './insightReports.js';
import { MonthReportScreen, CustomerAccountsScreen } from './screens/MonthReportScreens.js';
import { MonthRecordsScreen } from './screens/MonthRecordsScreen.js';
import { STATEMENT_REPORTS } from './statements.js';
import { AcctEntryScreen, AcctEntriesScreen, AroniumInboxScreen, AroniumImportScreen, AroniumBatchScreen, RepeatJournalsScreen, TaxCentreScreen,
  OpeningBalancesScreen, YearEndAcctScreen, ForecastScreen, CashBookScreen, AcctSettingsScreen } from './screens/FullScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { V1_REPORTS } from './v1.js';
import { HistoryHomeScreen, HistoryMonthsScreen, HistoryMonthScreen } from './screens/HistoryScreens.js';
import { ReportsHomeScreen, MonthSummaryScreen, VatMonthScreen, AccountantFilesScreen, MonthCloseScreen, BooksHomeScreen, BooksJournalScreen, BooksLedgerScreen, BooksAdjustScreen } from './screens/V1Screens.js';

const view = (u) => can(u, 'accounts_view');
const boss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
export default {
  id: 'accounting',
  title: 'Accounting & VAT',
  icon: '📚',
  switchable: true,
  screens: {
    Accounting: { component: AccountingHomeScreen, can: view },
    VatReturn: { component: VatReturnScreen, can: view },
    ProfitLoss: { component: ProfitLossScreen, can: view },
    BalanceSheet: { component: BalanceSheetScreen, can: view },
    TrialBalance: { component: TrialBalanceScreen, can: view },
    Ledger: { component: LedgerScreen, can: view },
    Journals: { component: JournalsScreen, can: (u) => can(u, 'accounts_journal') },
    ChartOfAccounts: { component: ChartOfAccountsScreen, can: (u) => can(u, 'accounts_setup') },
    Assets: { component: AssetsScreen, can: view },
    Budgets: { component: BudgetsScreen, can: view },
    MonthEnd: { component: MonthEndScreen, can: view },
    MonthReport: { component: MonthReportScreen, can: view },
    MonthRecords: { component: MonthRecordsScreen, can: view },
    CustomerAccounts: { component: CustomerAccountsScreen, can: view },
    AcctEntry: { component: AcctEntryScreen, can: (u) => can(u, 'accounts_journal') },
    AcctEntries: { component: AcctEntriesScreen, can: view },
    AroniumInbox: { component: AroniumInboxScreen, can: view },
    AroniumImport: { component: AroniumImportScreen, can: (u) => can(u, 'accounts_journal') },
    AroniumBatch: { component: AroniumBatchScreen, can: view },
    RepeatJournals: { component: RepeatJournalsScreen, can: view },
    TaxCentre: { component: TaxCentreScreen, can: view },
    OpeningBalances: { component: OpeningBalancesScreen, can: (u) => can(u, 'accounts_setup') },
    YearEndAcct: { component: YearEndAcctScreen, can: view },
    Forecast: { component: ForecastScreen, can: view },
    CashBook: { component: CashBookScreen, can: view },
    AcctSettings: { component: AcctSettingsScreen, can: (u) => can(u, 'accounts_setup') },
    // 1.0.0 (build 1) Office › Reports and the books
    ReportsHome: { component: ReportsHomeScreen, can: view },
    MonthSummary: { component: MonthSummaryScreen, can: view },
    VatMonth: { component: VatMonthScreen, can: (u) => view(u) || can(u, 'statutory') },
    AccountantFiles: { component: AccountantFilesScreen, can: view },
    MonthClose: { component: MonthCloseScreen, can: view },
    BooksHome: { component: BooksHomeScreen, can: view },
    BooksJournal: { component: BooksJournalScreen, can: view },
    BooksLedger: { component: BooksLedgerScreen, can: view },
    // 1.0.0 build 14: the invoices from before the app (read from Drive by the cloud) and the VAT of those months
    HistoryHome: { component: HistoryHomeScreen, can: boss },
    HistoryMonths: { component: HistoryMonthsScreen, can: boss },
    HistoryMonth: { component: HistoryMonthScreen, can: boss },
    BooksAdjust: { component: BooksAdjustScreen, can: (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole)) },
  },
  menu: MENU,
  alerts,
  reports: REPORTS.concat(STATEMENT_REPORTS, INSIGHT_REPORTS, V1_REPORTS),
};
