// v3.9.8 Business insight reports – can be made any time from Reports (PDF / Excel / share), and the monthly one
// is also part of Month close:
//   biz_month     Monthly business report (sales, VAT / VMS, products, suppliers, staff, fuel, forecast, suggestions)
//   biz_pending   What is pending: unpaid invoices, cheques written / given / cleared (with dates), loans next due,
//                 staff credit and customer credit – what we owe and what is owed to us, on one page
//   biz_cheques   Cheque timeline: written → handed over → cleared, with the days in between
//   biz_customers Customer accounts (Aronium credit); with params.customer a full account statement
// Everything is read only and guarded – a part with no figures is just empty.
import { db } from '../../db/connection.js';
import { stamp, dateStr, addDays } from '../../services/core.js';
import { monthReportDoc } from './monthReport.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const days = (a, b) => (a && b ? Math.round((new Date(`${String(b).slice(0, 10)}T12:00:00`) - new Date(`${String(a).slice(0, 10)}T12:00:00`)) / 86400000) : null);
const head = (kind, title, period, extra) => ({ kind, title, fileName: `${title.replace(/\s+/g, '-')}-${period.replace(/\s+/g, '')}`, subtitle: `Easy Buys Shopping Centre · ${period}`,
  info: [['Period', period], ['Generated', stamp()]], ...extra });
const ageBand = (d) => (d === null ? '' : d <= 30 ? '0–30' : d <= 60 ? '31–60' : d <= 90 ? '61–90' : '90+');

// ---------------------------------------------------------------- cheques
export function chequeTimeline(from, to, today = dateStr()) {
  const ok = (d) => /^\d{4}-\d{2}-\d{2}$/.test(String(d || ''));
  if (!ok(from)) from = '2000-01-01'; if (!ok(to)) to = dateStr(); if (!ok(today)) today = dateStr();
  if (!has('cheques')) return { rows: [], totals: {} };
  const rows = safe(() => db().all(`SELECT c.*, a.name AS account_name FROM cheques c LEFT JOIN bank_accounts a ON a.uid = c.account_uid
    WHERE c.status IN ('written','presented') AND ((c.cheque_date BETWEEN ? AND ?) OR (c.status = 'written' AND c.cheque_date <= ?)) ORDER BY c.cheque_date, c.cheque_no`, [from, to, to]), null)
    || safe(() => db().all("SELECT * FROM cheques WHERE status IN ('written','presented') AND ((cheque_date BETWEEN ? AND ?) OR (status = 'written' AND cheque_date <= ?)) ORDER BY cheque_date, cheque_no", [from, to, to]), []);
  const out = rows.map((c) => {
    const cleared = c.status === 'presented' ? c.presented_date : null;
    const given = c.handed_date || null;
    const state = cleared ? 'cleared' : given ? 'given' : 'pending';
    return { uid: c.uid, no: c.cheque_no, account: c.account_name || '', payee: c.payee || '', amount: r2(c.amount), written: c.cheque_date, given, cleared, state,
      toGive: days(c.cheque_date, given), toClear: days(given || c.cheque_date, cleared), waiting: cleared ? null : days(given || c.cheque_date, today) };
  });
  const sum = (s) => r2(out.filter((x) => x.state === s).reduce((t, x) => t + x.amount, 0));
  const cl = out.filter((x) => x.toClear !== null);
  return {
    rows: out,
    totals: { pending: sum('pending'), given: sum('given'), cleared: sum('cleared'), nPending: out.filter((x) => x.state === 'pending').length, nGiven: out.filter((x) => x.state === 'given').length,
      nCleared: cl.length, avgToClear: cl.length ? Math.round(cl.reduce((t, x) => t + x.toClear, 0) / cl.length) : null,
      avgToGive: out.filter((x) => x.toGive !== null).length ? Math.round(out.filter((x) => x.toGive !== null).reduce((t, x) => t + x.toGive, 0) / out.filter((x) => x.toGive !== null).length) : null },
  };
}
const STATE = { pending: 'Written – not given yet', given: 'Given – not cleared', cleared: 'Cleared' };
export function chequeReport(from, to) {
  const t = chequeTimeline(from, to);
  return head('biz_cheques', 'Cheque Timeline', `${from} to ${to}`, {
    summary: [{ label: `Written, not given (${t.totals.nPending || 0})`, value: $(t.totals.pending), tone: t.totals.pending ? 'warn' : null }, { label: `Given, not cleared (${t.totals.nGiven || 0})`, value: $(t.totals.given) },
      { label: `Cleared (${t.totals.nCleared || 0})`, value: $(t.totals.cleared) }, { label: 'Average days to clear', value: t.totals.avgToClear === null ? '–' : String(t.totals.avgToClear) }],
    sections: ['pending', 'given', 'cleared'].map((s) => ({
      title: STATE[s], columns: [col('no', 'Cheque'), col('account', 'Account'), col('payee', 'Payee'), col('amount', 'Amount', R), col('written', 'Written'), col('given', 'Given'), col('cleared', 'Cleared'), col('days', s === 'cleared' ? 'Days to clear' : 'Days waiting', R)],
      rows: t.rows.filter((x) => x.state === s).map((x) => ({ ...x, amount: $(x.amount), given: x.given || '', cleared: x.cleared || '', days: s === 'cleared' ? x.toClear : x.waiting, _tone: s !== 'cleared' && x.waiting > 30 ? 'warn' : null })),
    })),
  });
}

// ---------------------------------------------------------------- customers (Aronium accounts)
function staffNames() { return new Set(safe(() => db().all('SELECT name FROM users'), []).map((u) => txt(u.name).toLowerCase())); }
export function customerAccounts(today = dateStr()) {
  const L = safe(() => require('../aronium/link.js'), null);
  const bal = L ? safe(() => L.aroniumCredit(), []) : [];
  const trail = L ? safe(() => L.aroniumCreditTrail(), []) : [];
  const staff = staffNames();
  const per = new Map();
  for (const c of bal) {
    const k = txt(c.name).toLowerCase();
    if (!k) continue;
    const o = per.get(k) || { name: txt(c.name), owing: 0, oldest: null, shops: new Set(), staff: staff.has(k), lastSale: null, lastPayment: null };
    o.owing = r2(o.owing + (Number(c.owing) || 0));
    if (c.oldest && (!o.oldest || c.oldest < o.oldest)) o.oldest = c.oldest;
    o.shops.add(txt(c.source).split('-')[0]);
    per.set(k, o);
  }
  for (const d of trail) {
    const o = per.get(txt(d.customer).toLowerCase());
    if (!o) continue;
    if (!d.refund && (!o.lastSale || d.date > o.lastSale)) o.lastSale = d.date;
    for (const p of d.payments || []) if (p.date && (!o.lastPayment || p.date > o.lastPayment)) o.lastPayment = p.date;
  }
  return [...per.values()].map((o) => ({ ...o, shops: [...o.shops].join(', '), age: days(o.oldest, today), band: ageBand(days(o.oldest, today)) })).filter((o) => Math.abs(o.owing) > 0.004).sort((a, b) => b.owing - a.owing);
}
// One customer's statement from the Aronium trail: sales on account (with what was bought) and payments, running balance.
export function customerStatement(name, from, to) {
  const L = safe(() => require('../aronium/link.js'), null);
  const k = txt(name).toLowerCase();
  const trail = (L ? safe(() => L.aroniumCreditTrail(), []) : []).filter((d) => txt(d.customer).toLowerCase() === k);
  const lines = [];
  for (const d of trail) {
    lines.push({ date: d.date, what: d.refund ? 'Refund' : 'Sale on account', ref: d.number, shop: d.shop, charge: d.refund ? 0 : r2(d.total), credit: d.refund ? r2(Math.abs(d.total)) : 0,
      items: (d.items || []).slice(0, 6).map((it) => `${it[1] !== undefined ? `${it[1]} × ` : ''}${it[0]}`).join(', ') });
    for (const p of d.payments || []) {
      if (!p.date) continue;
      // a payment made at the time of the sale is part of the sale, not money in later
      lines.push({ date: p.date, what: `Payment${p.type ? ` (${p.type})` : ''}`, ref: d.number, shop: d.shop, charge: 0, credit: r2(p.amount), items: '' });
    }
  }
  lines.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.charge ? -1 : 1));
  let bal = 0; let opening = 0;
  const out = [];
  for (const l of lines) {
    bal = r2(bal + l.charge - l.credit);
    if (l.date < from) { opening = bal; continue; }
    if (l.date > to) continue;
    out.push({ ...l, balance: bal });
  }
  const acc = customerAccounts().find((c) => c.name.toLowerCase() === k);
  return { name: acc ? acc.name : name, opening, closing: out.length ? out[out.length - 1].balance : opening, owingNow: acc ? acc.owing : null, lines: out,
    note: trail.length ? null : 'No sales on account sent from Aronium for this customer yet (the till PCs send the last 120 days).' };
}
export function customerReport(from, to, user, params = {}) {
  if (params && params.customer) {
    const s = customerStatement(params.customer, from, to);
    return head('biz_customers', `Customer Statement ${s.name}`, `${from} to ${to}`, {
      info: [['Customer', s.name], ['Period', `${from} to ${to}`], ['Generated', stamp()]],
      summary: [{ label: 'Opening balance', value: $(s.opening) }, { label: 'Closing balance', value: $(s.closing) }].concat(s.owingNow !== null ? [{ label: 'Owing now (Aronium)', value: $(s.owingNow) }] : []),
      sections: [{ title: 'Account', columns: [col('date', 'Date'), col('what', 'What'), col('ref', 'Receipt'), col('shop', 'Shop'), col('items', 'Items'), col('charge', 'Charged', R), col('credit', 'Paid', R), col('balance', 'Balance', R)],
        rows: [{ date: from, what: 'Opening balance', ref: '', shop: '', items: '', charge: '', credit: '', balance: $(s.opening) }].concat(s.lines.map((l) => ({ ...l, charge: l.charge ? $(l.charge) : '', credit: l.credit ? $(l.credit) : '', balance: $(l.balance) }))),
        note: s.note || undefined }],
    });
  }
  const list = customerAccounts(to);
  const cust = list.filter((c) => !c.staff); const staff = list.filter((c) => c.staff);
  const sect = (title, l) => ({ title, columns: [col('name', 'Name'), col('shops', 'Shop'), col('owing', 'Owing', R), col('oldest', 'Oldest unpaid'), col('band', 'Age (days)'), col('lastSale', 'Last sale'), col('lastPayment', 'Last payment')],
    rows: l.map((c) => ({ ...c, owing: $(c.owing), oldest: c.oldest || '', lastSale: c.lastSale || '', lastPayment: c.lastPayment || '', _tone: c.age > 60 ? 'warn' : null })) });
  return head('biz_customers', 'Customer Accounts', to, {
    summary: [{ label: `Customers (${cust.length})`, value: $(cust.reduce((s, c) => s + c.owing, 0)) }, { label: `Staff on Aronium credit (${staff.length})`, value: $(staff.reduce((s, c) => s + c.owing, 0)) },
      { label: 'Over 60 days', value: $(list.filter((c) => c.age > 60).reduce((s, c) => s + c.owing, 0)), tone: list.some((c) => c.age > 60) ? 'warn' : null }],
    sections: [sect('Customers', cust), sect('Staff (also in Who owes us)', staff)],
  });
}

// ---------------------------------------------------------------- what is pending (in and out)
export function pendingSummary(to = dateStr()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(to || ''))) to = dateStr();
  const AP = safe(() => require('../payables/service.js'), null);
  const unpaid = AP ? safe(() => AP.listInvoices({ filter: 'unpaid', to, limit: 5000 }), []) : [];
  const bySup = new Map();
  for (const i of unpaid) {
    const o = bySup.get(i.supplier_name) || { name: i.supplier_name, owing: 0, n: 0, oldest: null, nextDue: null, overdue: 0 };
    o.owing = r2(o.owing + (Number(i.owing) || 0)); o.n += 1;
    if (!o.oldest || i.invoice_date < o.oldest) o.oldest = i.invoice_date;
    if (i.due_date && (!o.nextDue || i.due_date < o.nextDue)) o.nextDue = i.due_date;
    if (i.due_date && i.due_date < to) o.overdue = r2(o.overdue + (Number(i.owing) || 0));
    bySup.set(i.supplier_name, o);
  }
  const chq = chequeTimeline('2000-01-01', to, to);
  const loans = has('ap_recurring') ? safe(() => db().all("SELECT name, next_date, amount FROM ap_recurring WHERE active = 1 AND (kind = 'loan' OR lower(name) LIKE '%rent%') ORDER BY next_date"), []) : [];
  const owed = safe(() => require('../owed/service.js'), null);
  const staff = owed ? safe(() => owed.whoOwesUs({ today: to }), []) : [];
  const cust = customerAccounts(to).filter((c) => !c.staff);
  return {
    to, suppliers: [...bySup.values()].sort((a, b) => b.owing - a.owing), supplierTotal: r2([...bySup.values()].reduce((s, x) => s + x.owing, 0)),
    overdueTotal: r2([...bySup.values()].reduce((s, x) => s + x.overdue, 0)),
    cheques: chq, loans: loans.map((l) => ({ ...l, amount: r2(l.amount) })),
    staff: staff.map((p) => ({ name: p.name, credit: p.credit, advances: p.advances, loans: p.loans, other: r2((p.tillShort || 0) + (p.charges || 0)), total: p.total, level: p.level })),
    staffTotal: r2(staff.reduce((s, p) => s + (p.total || 0), 0)), customers: cust, customerTotal: r2(cust.reduce((s, c) => s + c.owing, 0)),
  };
}
export function pendingReport(from, to) {
  const p = pendingSummary(to);
  const weOwe = r2(p.supplierTotal + p.cheques.totals.pending + p.cheques.totals.given);
  return head('biz_pending', 'Pending In And Out', to, {
    summary: [{ label: 'We owe suppliers (unpaid invoices)', value: $(p.supplierTotal) }, { label: 'Of it overdue', value: $(p.overdueTotal), tone: p.overdueTotal ? 'warn' : null },
      { label: 'Cheques written, not given', value: $(p.cheques.totals.pending) }, { label: 'Cheques given, not cleared', value: $(p.cheques.totals.given) },
      { label: 'Staff owe us', value: $(p.staffTotal) }, { label: 'Customers owe us', value: $(p.customerTotal) }, { label: 'Going out (total)', value: $(weOwe) }, { label: 'Coming in (total)', value: $(r2(p.staffTotal + p.customerTotal)) }],
    sections: [
      { title: 'Suppliers we owe', columns: [col('name', 'Supplier'), col('n', 'Invoices', R), col('owing', 'Owing', R), col('overdue', 'Overdue', R), col('oldest', 'Oldest'), col('nextDue', 'Next due')],
        rows: p.suppliers.map((s) => ({ ...s, owing: $(s.owing), overdue: s.overdue ? $(s.overdue) : '', nextDue: s.nextDue || '', _tone: s.overdue ? 'warn' : null })) },
      { title: 'Cheques not cleared', columns: [col('no', 'Cheque'), col('payee', 'Payee'), col('amount', 'Amount', R), col('written', 'Written'), col('given', 'Given'), col('state', 'Now'), col('waiting', 'Days waiting', R)],
        rows: p.cheques.rows.filter((c) => c.state !== 'cleared').map((c) => ({ ...c, amount: $(c.amount), given: c.given || '', state: STATE[c.state], _tone: c.waiting > 30 ? 'warn' : null })) },
      { title: 'Loans and rent – next payment', columns: [col('name', 'What'), col('next_date', 'Next due'), col('amount', 'Amount', R)], rows: p.loans.map((l) => ({ ...l, amount: $(l.amount), next_date: l.next_date || '' })) },
      { title: 'Staff owe us (credit, advances, loans)', columns: [col('name', 'Person'), col('credit', 'Credit', R), col('advances', 'Advances', R), col('loans', 'Loans', R), col('other', 'Other', R), col('total', 'Total', R)],
        rows: p.staff.map((s) => ({ ...s, credit: $(s.credit), advances: $(s.advances), loans: $(s.loans), other: $(s.other), total: $(s.total), _tone: s.level === 'over' ? 'warn' : null })) },
      { title: 'Customers owe us (Aronium accounts)', columns: [col('name', 'Customer'), col('owing', 'Owing', R), col('oldest', 'Oldest'), col('band', 'Age'), col('lastPayment', 'Last payment')],
        rows: p.customers.map((c) => ({ ...c, owing: $(c.owing), oldest: c.oldest || '', lastPayment: c.lastPayment || '', _tone: c.age > 60 ? 'warn' : null })) },
    ],
  });
}


// ---------------------------------------------------------------- start the day (PDF of the morning page)
export function dayStartReport(from, to, user) {
  const D = require('../../services/dayStart.js');
  const d = D.startOfDay(to || dateStr(), user);
  const b = d.money.bank;
  const g = d.goingOut;
  const row = (k, v, extra) => ({ k, v, x: extra || '' });
  return head('biz_day', 'Start The Day', `${d.day} ${d.today}`, {
    summary: [{ label: 'This week', value: d.outlook.text }].concat(b ? [{ label: 'Our cheque book', value: $(b.book) }, { label: 'Bank should show', value: $(b.inBank) }] : [])
      .concat([{ label: 'M-PAiSA', value: $(d.money.walletTotal) }, { label: 'Cash at the shops', value: $(d.money.cashTotal) }, { label: 'Sales expected today', value: $(d.comingIn.sales.total) }]),
    sections: [
      { title: 'Money now', columns: [col('k', 'Item'), col('v', 'Amount', R), col('x', 'Note')], rows: (b ? [row('Our cheque book (BSP)', $(b.book)), row('Cheques given, not in the bank', $(b.givenNotCleared.total), `${b.givenNotCleared.count} cheque(s)${b.givenNotCleared.oldest ? `, oldest ${b.givenNotCleared.oldest}` : ''}`),
        row('Cheques written, not handed over', $(b.writtenNotGiven.total), `${b.writtenNotGiven.count}`), row('Deposits on their way', $(b.inTransit)), row('Bank should show', $(b.inBank)),
        row('Last checked in the bank app', b.lastChecked ? $(b.lastChecked.typed) : '–', b.lastChecked ? `${b.lastChecked.date}` : 'not checked')] : [])
        .concat(d.money.wallets.map((w) => row(`M-PAiSA ${w.name}`, $(w.balance), w.transit ? `${$(w.transit)} on the way to the bank` : ''))).concat(d.money.cash.map((c) => row(`Cash ${c.shop}`, $(c.onHand)))) },
      { title: 'Going out', columns: [col('k', 'Item'), col('v', 'Amount', R), col('x', 'When')], rows: [row(`Invoices overdue (${g.overdue.count})`, $(g.overdue.total)), row(`Due today (${g.today.count})`, $(g.today.total)), row(`Due in 6 days (${g.week.count})`, $(g.week.total))]
        .concat(g.regular.map((r) => row(r.name, $(r.amount), r.next_date))).concat(g.wages ? [row('Wages', $(g.wages.expected), g.wages.payDay)] : []).concat(g.tax.map((t) => row(t.title, t.amount !== null ? $(t.amount) : '', t.due))) },
      { title: 'Coming in', columns: [col('k', 'Item'), col('v', 'Amount', R), col('x', 'Note')], rows: [row('Staff owe us', $(d.comingIn.staffOwe), `${d.comingIn.staffPeople} people`), row('Customers on account', $(d.comingIn.customersOwe), `${d.comingIn.customers}`)]
        .concat(d.comingIn.sales.week.map((w) => row(`Sales expected ${w.day} ${w.date}`, $(w.expected)))) },
      { title: 'Orders to place', columns: [col('k', 'Supplier / order'), col('v', 'Value', R), col('x', 'Note')], rows: d.orders.due.map((o) => row(o.text, '', o.sub || '')).concat(d.orders.fromHistory.map((o) => row(`${o.name} · ${o.shop}`, $(o.usual), `every ${o.every} days, last ${o.last}`))).concat(d.orders.low.map((o) => row(`${o.supplier} · ${o.shop}`, $(o.value), `${o.items} item(s) low`))) },
      { title: 'Away today and urgent', columns: [col('k', 'Item'), col('v', '', R), col('x', 'Note')], rows: d.people.leave.map((p) => row(`${p.name} on leave`, '', `${p.from_date} – ${p.to_date}`)).concat(d.urgent.map((a) => row(a.text, '', a.sub || ''))) },
    ],
  });
}

export const INSIGHT_REPORTS = [
  { id: 'biz_day', group: 'Business insight', icon: '🌅', title: 'Start the day', desc: 'Bank, cheques given and not cleared, M-PAiSA, cash, what is due, expected sales, orders to place (the last day)', perm: 'accounts_view', build: dayStartReport },
  { id: 'biz_month', group: 'Business insight', icon: '📊', title: 'Monthly business report', desc: 'How the month went: sales, VAT and VMS checks, products, suppliers, wages, fuel, forecast and what to improve (the month of the "from" date)', perm: 'accounts_view',
    build(from) { return monthReportDoc(String(from).slice(0, 7)); } },
  { id: 'biz_pending', group: 'Business insight', icon: '⏳', title: 'Pending in and out', desc: 'Unpaid invoices, cheques written / given / not cleared, loans due, staff and customer credit – on the last day', perm: 'accounts_view', build: pendingReport },
  { id: 'biz_cheques', group: 'Business insight', icon: '🏦', title: 'Cheque timeline', desc: 'Each cheque: written, given, cleared dates and the days in between', perm: 'accounts_view', build: chequeReport },
  { id: 'biz_customers', group: 'Business insight', icon: '🧾', title: 'Customer accounts', desc: 'Who owes on account in Aronium, how old; a full statement when a customer is chosen', perm: 'accounts_view', build: customerReport },
];
