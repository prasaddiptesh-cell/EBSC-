// Release 03 (owner, 12 Nov: "Accounts payable, accounts receivable books need to be there"): the two books of
// account people ask the accountant for, built on what the app already keeps – nothing new is stored.
//  • Accounts payable (creditors – what we owe suppliers): the supplier statement (payables/statement.js) for each
//    supplier: opening balance, every invoice, credit note and payment in date order with a running balance, the closing
//    balance; the list of all suppliers; and what is owing aged by the invoice due date (current, 1–30, 31–60, 61–90, 90+).
//    Void invoices are left out (as in the statement).
//  • Accounts receivable (debtors – who owes us): staff (Who owes us: Aronium staff credit, advances, loans, charges,
//    less what pay runs took back) and customers on account in Aronium (accounting/insightReports.js), each with a
//    ledger and a running balance, aged 0–30, 31–60, 61–90, over 90 days.
import { db } from '../../db/connection.js';
import { stamp } from '../../services/core.js';
import { supplierStatement, statementSummary } from '../payables/statement.js';
import { whoOwesUs, personOwes, aroniumNamesFor, AGE_LABEL } from '../owed/service.js';
import { listDebts, DEBT_LABEL } from '../payroll/service.js';
import { customerAccounts, customerStatement } from './insightReports.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const days = (a, b) => Math.round((new Date(`${String(b).slice(0, 10)}T12:00:00`) - new Date(`${String(a).slice(0, 10)}T12:00:00`)) / 86400000);
const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const low = (s) => String(s || '').trim().toLowerCase();

// ---------------------------------------------------------------- accounts payable
export const AP_AGE = ['current', 'd30', 'd60', 'd90', 'over90'];
export const AP_AGE_LABEL = { current: 'Current (not due)', d30: '1–30 days late', d60: '31–60 days late', d90: '61–90 days late', over90: 'Over 90 days late' };
const emptyAp = () => ({ current: 0, d30: 0, d60: 0, d90: 0, over90: 0 });
export function apBand(daysLate) {
  const n = Number(daysLate) || 0;
  return n <= 0 ? 'current' : n <= 30 ? 'd30' : n <= 60 ? 'd60' : n <= 90 ? 'd90' : 'over90';
}
// What is owing at the end of the period, by how late each invoice is (unused credit notes count as current).
function apAgeing(st) {
  const a = emptyAp();
  for (const o of st.openItems) { const b = o.kind === 'credit' ? 'current' : apBand(o.daysLate); a[b] = r2(a[b] + o.left); }
  return a;
}
const apRow = (st) => ({ supplierUid: st.supplier.uid, name: st.supplier.name, opening: st.opening, invoices: st.invoicesTotal, credits: st.creditsTotal, payments: st.paymentsTotal,
  closing: st.closing, ageing: apAgeing(st), lines: st.lines.length });

// One supplier's ledger (the supplier statement, with the ageing).
export function apLedger(supplierUid, from, to) {
  const st = supplierStatement(supplierUid, from, to);
  return { ...st, ageing: apAgeing(st) };
}
// Every supplier with something in the period or a balance, biggest balance first, with totals.
export function apSummary(from, to) {
  const rows = statementSummary(from, to).map(apRow).sort((a, b) => b.closing - a.closing || (a.name < b.name ? -1 : 1));
  const sum = (k) => r2(rows.reduce((s, r) => s + r[k], 0));
  const ageing = AP_AGE.reduce((o, k) => ({ ...o, [k]: r2(rows.reduce((s, r) => s + r.ageing[k], 0)) }), {});
  return { from, to, rows, totals: { suppliers: rows.length, opening: sum('opening'), invoices: sum('invoices'), credits: sum('credits'), payments: sum('payments'), closing: sum('closing'), ageing } };
}

// ---------------------------------------------------------------- accounts receivable
export const AR_AGE = ['d30', 'd60', 'd90', 'over90'];
export const AR_AGE_LABEL = AGE_LABEL;
const emptyAr = () => ({ d30: 0, d60: 0, d90: 0, over90: 0 });
export function arBand(age) {
  const n = Math.max(0, Number(age) || 0);
  return n <= 30 ? 'd30' : n <= 60 ? 'd60' : n <= 90 ? 'd90' : 'over90';
}
function trail() {
  const L = safe(() => require('../aronium/link.js'), null);
  return L ? safe(() => L.aroniumCreditTrail(), []) : [];
}
// A customer's balance aged by the sales still owing (the rest of the balance – older than the 120 days the till PCs
// send – by the oldest unpaid date).
function customerAgeing(c, sales, to) {
  const a = emptyAr();
  let placed = 0;
  for (const d of sales) {
    const owing = Number(d.owing) || 0;
    if (owing <= 0.004 || d.date > to) continue;
    const b = arBand(days(d.date, to));
    a[b] = r2(a[b] + owing); placed = r2(placed + owing);
  }
  const rest = r2(c.owing - placed);
  if (Math.abs(rest) > 0.004) { const b = c.oldest ? arBand(days(c.oldest, to)) : 'over90'; a[b] = r2(a[b] + rest); }
  return a;
}
// Who owes us at the end of the period: staff (Who owes us) and customers on account (Aronium). The balances are the
// latest ones the app has (Aronium sends the balance now, not at a past date).
export function arSummary(from, to) {
  const staff = safe(() => whoOwesUs({ today: to }), []).map((p) => ({ key: `staff:${p.userUid}`, type: 'staff', name: p.name, owing: r2(p.total), ageing: { ...emptyAr(), ...p.ageing },
    sub: [p.credit ? `Staff credit ${$(p.credit)}` : '', p.advances ? `Advances ${$(p.advances)}` : '', p.loans ? `Loans ${$(p.loans)}` : '', p.tillShort ? `Till short ${$(p.tillShort)}` : '', p.charges ? `Charges ${$(p.charges)}` : ''].filter(Boolean).join(' · ') }));
  const all = trail();
  const customers = safe(() => customerAccounts(to), []).filter((c) => !c.staff).map((c) => ({ key: `cust:${c.name}`, type: 'customer', name: c.name, owing: r2(c.owing),
    ageing: customerAgeing(c, all.filter((d) => low(d.customer) === low(c.name)), to), sub: `${c.shops || ''}${c.lastPayment ? ` · last paid ${c.lastPayment}` : ' · no payment seen'}` }));
  const rows = staff.concat(customers).filter((r) => Math.abs(r.owing) > 0.004).sort((a, b) => b.owing - a.owing);
  const ageing = AR_AGE.reduce((o, k) => ({ ...o, [k]: r2(rows.reduce((s, r) => s + r.ageing[k], 0)) }), {});
  const tot = (l) => r2(l.reduce((s, r) => s + r.owing, 0));
  return { from, to, rows, totals: { people: rows.length, owing: tot(rows), staff: tot(rows.filter((r) => r.type === 'staff')), customers: tot(rows.filter((r) => r.type === 'customer')), ageing } };
}

// Repayments of a person's app debts taken in final pay runs (the same deductions debtBalance counts), with the pay date.
function payRepayments(userUid, debtUids) {
  if (!has('pay_lines') || !debtUids.size) return [];
  const out = [];
  for (const l of db().all("SELECT l.deductions, r.pay_date FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1", [userUid])) {
    for (const x of J(l.deductions, [])) if (x && debtUids.has(x.debtUid)) out.push({ date: l.pay_date, amount: r2(x.amount), debtUid: x.debtUid });
  }
  return out;
}
const runBalance = (all, from, to) => {
  all.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.charge ? 0 : 1) - (b.charge ? 0 : 1)));
  let bal = 0; let opening = 0;
  const lines = [];
  for (const l of all) {
    if (l.date > to) continue;
    bal = r2(bal + l.charge - l.credit);
    if (l.date < from) { opening = bal; continue; }
    lines.push({ ...l, balance: bal });
  }
  return { opening, lines, closing: lines.length ? lines[lines.length - 1].balance : opening };
};
// A staff member's ledger: advances, loans and charges given (and the app's staff credit when Aronium has not sent their
// balance), the pay-run deductions that paid them back, and their Aronium staff credit sales and payments.
function staffLedger(userUid, from, to) {
  const p = personOwes(userUid, { today: to });
  const fromAronium = p.creditFrom === 'aronium';
  const all = [];
  const ids = new Map();
  for (const d of safe(() => listDebts({ userUid, open: false }), [])) {
    if (fromAronium && d.kind === 'staff_credit') continue; // in the Aronium account below
    ids.set(d.uid, d);
    all.push({ date: d.debt_date, what: DEBT_LABEL[d.kind] || 'Deduction', ref: d.reason || '', charge: r2(d.amount), credit: 0 });
  }
  for (const x of payRepayments(userUid, new Set(ids.keys()))) {
    const d = ids.get(x.debtUid);
    all.push({ date: x.date, what: 'Taken from pay', ref: d ? DEBT_LABEL[d.kind] || '' : '', charge: 0, credit: x.amount });
  }
  if (fromAronium) {
    for (const n of aroniumNamesFor(userUid)) {
      for (const l of customerStatement(n, '0000-01-01', to).lines) all.push({ date: l.date, what: `Aronium: ${l.what}`, ref: l.ref || '', shop: l.shop, items: l.items, charge: l.charge, credit: l.credit });
    }
  }
  const b = runBalance(all, from, to);
  return { key: `staff:${userUid}`, type: 'staff', name: p.person.name, from, to, ...b, owingNow: r2(p.total), ageing: { ...emptyAr(), ...p.ageing },
    note: fromAronium ? 'Aronium staff credit: the till PCs send the sales of the last 120 days, so an older balance shows in the opening balance only when it is in that trail.' : null };
}
function customerLedger(name, from, to) {
  const s = customerStatement(name, from, to);
  const c = safe(() => customerAccounts(to), []).find((x) => low(x.name) === low(name));
  const ageing = c ? customerAgeing(c, trail().filter((d) => low(d.customer) === low(name)), to) : emptyAr();
  return { key: `cust:${name}`, type: 'customer', name: s.name, from, to, opening: s.opening, lines: s.lines, closing: s.closing, owingNow: s.owingNow, ageing, note: s.note };
}
// key: 'staff:<user uid>' or 'cust:<Aronium customer name>' (as in arSummary rows).
export function arLedger(key, from, to) {
  const k = String(key || '');
  if (k.startsWith('staff:')) return staffLedger(k.slice(6), from, to);
  return customerLedger(k.startsWith('cust:') ? k.slice(5) : k, from, to);
}

// ---------------------------------------------------------------- reports (PDF / Excel from the report screen)
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const head = (kind, title, period, extra) => ({ kind, title, fileName: `${title.replace(/\s+/g, '-')}-${period.replace(/\s+/g, '')}`, subtitle: `Easy Buys Shopping Centre · ${period}`,
  info: [['Period', period], ['Generated', stamp()]], ...extra });
const m = (n) => (n ? $(n) : '');
const ledgerSection = (from, opening, lines, extraCols = []) => ({ title: 'Ledger',
  columns: [col('date', 'Date'), col('what', 'What'), col('ref', 'Reference')].concat(extraCols, [col('charge', 'Debit (owed)', R), col('credit', 'Credit (paid)', R), col('balance', 'Balance', R)]),
  rows: [{ date: from, what: 'Opening balance', ref: '', charge: '', credit: '', balance: $(opening) }].concat(lines.map((l) => ({ ...l, ref: l.ref || '', charge: m(l.charge), credit: m(l.credit), balance: $(l.balance) }))) });
const ageSection = (keys, labels, rows, totals) => ({ title: 'Aged balances',
  columns: [col('name', 'Name')].concat(keys.map((k) => col(k, labels[k], R)), [col('total', 'Total', R)]),
  rows: rows.map((r) => ({ name: r.name, ...keys.reduce((o, k) => ({ ...o, [k]: m(r.ageing[k]) }), {}), total: $(r.total) }))
    .concat([{ name: 'Total', ...keys.reduce((o, k) => ({ ...o, [k]: $(totals[k]) }), {}), total: $(keys.reduce((s, k) => s + totals[k], 0)), _bold: true }]) });

export function apReport(from, to, user, params = {}) {
  if (params && params.supplier) {
    const st = apLedger(params.supplier, from, to);
    return head('ledger_ap', `Creditors Ledger ${st.supplier.name}`, `${from} to ${to}`, {
      summary: [{ label: 'Opening balance', value: $(st.opening) }, { label: 'Invoices', value: $(st.invoicesTotal) }, { label: 'Credit notes', value: $(st.creditsTotal) }, { label: 'Payments', value: $(st.paymentsTotal) }, { label: 'Closing balance', value: $(st.closing) }],
      sections: [ledgerSection(from, st.opening, st.lines, [col('due', 'Due')]), ageSection(AP_AGE, AP_AGE_LABEL, [{ name: st.supplier.name, ageing: st.ageing, total: AP_AGE.reduce((s, k) => s + st.ageing[k], 0) }], st.ageing)],
    });
  }
  const s = apSummary(from, to);
  return head('ledger_ap', 'Accounts Payable', `${from} to ${to}`, {
    summary: [{ label: `Suppliers (${s.totals.suppliers})`, value: $(s.totals.closing) }, { label: 'Invoices in the period', value: $(s.totals.invoices) }, { label: 'Paid in the period', value: $(s.totals.payments) },
      { label: 'Over 30 days late', value: $(s.totals.ageing.d60 + s.totals.ageing.d90 + s.totals.ageing.over90), tone: s.totals.ageing.d60 + s.totals.ageing.d90 + s.totals.ageing.over90 > 0 ? 'warn' : null }],
    sections: [{ title: 'Suppliers', columns: [col('name', 'Supplier'), col('opening', 'Opening', R), col('invoices', 'Invoices', R), col('credits', 'Credit notes', R), col('payments', 'Payments', R), col('closing', 'Closing', R)],
      rows: s.rows.map((r) => ({ name: r.name, opening: $(r.opening), invoices: m(r.invoices), credits: m(r.credits), payments: m(r.payments), closing: $(r.closing) }))
        .concat([{ name: 'Total', opening: $(s.totals.opening), invoices: $(s.totals.invoices), credits: $(s.totals.credits), payments: $(s.totals.payments), closing: $(s.totals.closing), _bold: true }]) },
    ageSection(AP_AGE, AP_AGE_LABEL, s.rows.map((r) => ({ ...r, total: r.closing })), s.totals.ageing)],
  });
}
export function arReport(from, to, user, params = {}) {
  if (params && params.key) {
    const l = arLedger(params.key, from, to);
    return head('ledger_ar', `Debtors Ledger ${l.name}`, `${from} to ${to}`, {
      summary: [{ label: 'Opening balance', value: $(l.opening) }, { label: 'Closing balance', value: $(l.closing) }].concat(l.owingNow !== null && l.owingNow !== undefined ? [{ label: 'Owing now', value: $(l.owingNow) }] : []),
      sections: [{ ...ledgerSection(from, l.opening, l.lines, [col('shop', 'Shop')]), note: l.note || undefined }],
    });
  }
  const s = arSummary(from, to);
  return head('ledger_ar', 'Accounts Receivable', to, {
    summary: [{ label: `Who owes us (${s.totals.people})`, value: $(s.totals.owing) }, { label: 'Staff', value: $(s.totals.staff) }, { label: 'Customers on account', value: $(s.totals.customers) },
      { label: 'Over 60 days', value: $(s.totals.ageing.d90 + s.totals.ageing.over90), tone: s.totals.ageing.d90 + s.totals.ageing.over90 > 0 ? 'warn' : null }],
    sections: [{ title: 'Who owes us', columns: [col('name', 'Name'), col('type', 'Staff / customer'), col('sub', 'Detail'), col('owing', 'Owing', R)],
      rows: s.rows.map((r) => ({ name: r.name, type: r.type === 'staff' ? 'Staff' : 'Customer', sub: r.sub || '', owing: $(r.owing) })) },
    ageSection(AR_AGE, AR_AGE_LABEL, s.rows.map((r) => ({ ...r, total: r.owing })), s.totals.ageing)],
  });
}
export const LEDGER_REPORTS = [
  { id: 'ledger_ap', group: 'Accounting & VAT', icon: '📕', title: 'Accounts payable (creditors)', desc: 'What we owe each supplier: opening, invoices, credit notes, payments, closing, aged by due date', perm: 'accounts_view', build: apReport },
  { id: 'ledger_ar', group: 'Accounting & VAT', icon: '📗', title: 'Accounts receivable (debtors)', desc: 'Who owes us – staff and customers on account – with each one\'s ledger and the ageing', perm: 'accounts_view', build: arReport },
];
