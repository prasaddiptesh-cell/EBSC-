// Accounting & VAT menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '📚', title: 'Accounting overview', screen: 'Accounting' },
    { id: 'acc-entry', icon: '✍️', title: 'Type a sale, expense or other money', note: 'Choose the shop or cost area (Office, Closed shop).', screen: 'AcctEntry' },
    { id: 'acc-aronium', icon: '📥', title: 'Aronium figures to check', screen: 'AroniumInbox' },
  ] },
  { section: 'Records', items: [
    { id: 'acc-entries', icon: '🗒️', title: 'Typed entries', screen: 'AcctEntries' },
    { id: 'acc-journal', icon: '📝', title: 'Journals', screen: 'Journals' },
    { id: 'acc-recurring', icon: '🔁', title: 'Repeating journals, prepayments & accruals', screen: 'RepeatJournals' },
    { id: 'acc-assets', icon: '🚚', title: 'Equipment & vehicles (fixed assets)', screen: 'Assets' },
    { id: 'acc-gl', icon: '📒', title: 'Account history (ledger)', screen: 'Ledger' },
    { id: 'acc-cashbook', icon: '💵', title: 'Cash book', screen: 'CashBook' },
  ] },
  { section: 'Checks', items: [
    { id: 'acc-vat-frcs', icon: '🧾', title: 'VAT return (FRCS) – lodge & pay', screen: 'TaxReturns', params: { kind: 'vat' } },
    { id: 'acc-vat', icon: '📊', title: 'VAT by shop (working)', screen: 'VatReturn' },
    { id: 'acc-tax', icon: '🏛️', title: 'Tax centre', screen: 'TaxCentre' },
    { id: 'acc-tb', icon: '🧮', title: 'Trial balance', screen: 'TrialBalance' },
    { id: 'acc-month', icon: '✅', title: 'Month end & closing', screen: 'MonthEnd' },
    { id: 'acc-year', icon: '🏛️', title: 'Year end & financial statements', screen: 'YearEndAcct' },
  ] },
  { section: 'Reports', items: [
    { id: 'acc-pl', icon: '📈', title: 'Profit & loss (by shop, closed shop costs on their own line)', screen: 'ProfitLoss' },
    { id: 'acc-bs', icon: '⚖️', title: 'Balance sheet', screen: 'BalanceSheet' },
    { id: 'acc-forecast', icon: '🔮', title: 'Cash flow forecast', screen: 'Forecast' },
    { id: 'acc-budget', icon: '🎯', title: 'Budget against actual', screen: 'Budgets' },
    { id: 'acc-reports', icon: '📊', title: 'Accounting reports', screen: 'ReportsHub', params: { group: 'Accounting & VAT' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'acc-opening', icon: '🏁', title: 'Opening balances', screen: 'OpeningBalances' },
    { id: 'acc-coa', icon: '🗂️', title: 'Accounts & where things go', screen: 'ChartOfAccounts' },
    { id: 'acc-settings', icon: '⚙️', title: 'Accounting settings', screen: 'AcctSettings' },
  ] },
];
