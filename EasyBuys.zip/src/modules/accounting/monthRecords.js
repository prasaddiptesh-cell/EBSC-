// 1.0.0 build 44 (owner, 10 Nov: "I find it so hard to manoeuvre to see the records – the records for previous months
// need to be added, especially the sales; I can't do that, neither in the current month. Manual sales entry with VAT
// and non-VAT sales, since this is very important data for the VAT calculation."):
// one month, one shop, every day: what the app has for that day's sales (each Aronium End of day, till balance and
// sale typed in – the same records the VAT return counts), and a sale typed for any day as VAT sales (incl. VAT) +
// zero-rated sales. Also the month's supplier invoices and other money typed in, each opening its record.
import { db } from '../../db/connection.js';
import { dateStr, AppError, stamp, deviceId, audit } from '../../services/core.js';
import { requirePerm } from '../../services/guard.js';
import { lockDate } from '../../services/lock.js';
import * as A from './service.js';
import * as F from './full.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
const pad = (n) => String(n).padStart(2, '0');
export const monthEnd = (ym) => { const [y, m] = ym.split('-').map(Number); return `${ym}-${pad(new Date(Date.UTC(y, m, 0)).getUTCDate())}`; };
export const ymShift = (ym, n) => { const t = Number(ym.slice(0, 4)) * 12 + Number(ym.slice(5, 7)) - 1 + n; return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`; };

// The VAT in a sale: standard-rated sales incl. VAT × rate / (100 + rate).
export function saleVat(standard, ym) {
  let rate = 12.5;
  try { rate = require('../payroll/returns.js').vatRateFor(ym); } catch (e) { rate = 12.5; }
  return r2((r2(standard) * rate) / (100 + rate));
}

// → { ym, shop, locked, days: [{ date, rows, total, zero, vat, typed, kinds }], totals, invoices, other }
export function monthRecords({ ym, shop }) {
  const today = dateStr();
  const v = A.vatReturn({ ym, shop: shop || undefined });
  const rows = (v.saleRows || []).filter((r) => !shop || r.shop === shop);
  // the typed sales carry their journal uid (to remove one typed wrongly)
  const typedSales = db().all("SELECT uid, jdate, memo, meta FROM gl_journals WHERE status = 'active' AND kind = 'sale' AND substr(jdate,1,7) = ?", [ym])
    .map((j) => ({ ...j, meta: J(j.meta, {}) })).filter((j) => !shop || (j.meta.shop || '') === shop);
  const days = [];
  for (let d = `${ym}-01`; d <= monthEnd(ym); d = next(d)) {
    const rs = rows.filter((r) => r.date === d);
    const total = r2(rs.reduce((t, r) => t + (Number(r.total) || 0), 0));
    const zero = r2(rs.reduce((t, r) => t + (Number(r.zero) || 0), 0));
    const vat = r2(rs.reduce((t, r) => t + (Number(r.vat) || 0), 0));
    const kinds = [...new Set(rs.map((r) => (r.aronium ? 'End of day' : r.go && r.go[0] === 'TillCountView' ? 'Till balance' : 'Typed')))];
    days.push({ date: d, rows: rs, total, zero, standard: r2(total - zero), vat, kinds, future: d > today, typed: typedSales.filter((j) => j.jdate === d) });
    if (days.length > 31) break;
  }
  const sum = (f) => r2(days.reduce((t, x) => t + f(x), 0));
  const invoices = db().all("SELECT uid FROM ap_invoices WHERE status <> 'void' AND substr(invoice_date,1,7) = ? AND (? IS NULL OR IFNULL(shop_code,'') = ? OR shop_code IS NULL) ORDER BY invoice_date", [ym, shop || null, shop || ''])
    .map((x) => { try { return require('../payables/service.js').getInvoice(x.uid); } catch (e) { return null; } }).filter(Boolean);
  const other = db().all("SELECT uid, jdate, kind, memo, meta FROM gl_journals WHERE status = 'active' AND kind IN ('expense','income') AND substr(jdate,1,7) = ? ORDER BY jdate", [ym])
    .map((j) => ({ ...j, meta: J(j.meta, {}) })).filter((j) => !shop || (j.meta.shop || '') === shop || !j.meta.shop);
  const lock = lockDate();
  return {
    ym, shop, locked: !!(lock && `${ym}-01` <= lock), lockDate: lock,
    days, totals: { total: sum((x) => x.total), zero: sum((x) => x.zero), standard: sum((x) => x.standard), vat: sum((x) => x.vat), daysWithSales: days.filter((x) => x.total).length, daysEmpty: days.filter((x) => !x.total && !x.future).length },
    invoices, other,
  };
}
function next(d) { const t = new Date(`${d}T00:00:00Z`); t.setUTCDate(t.getUTCDate() + 1); return t.toISOString().slice(0, 10); }

// A sale typed for one day: VAT sales (incl. VAT) and zero-rated sales – saved as one typed sale (counted by the VAT
// return: lines 1 and 2). how: the money it came in as (cash at the shop by default).
export function typeDaySale(user, { date, shop, standard, zero, via, note }) {
  const st = r2(standard); const z = r2(zero);
  const total = r2(st + z);
  if (!(total > 0)) throw new AppError('Type the VAT sales and / or the zero-rated sales.');
  const vat = saleVat(st, String(date).slice(0, 7));
  return F.saveSale(user, { date, shop, total, zero: z, vat, via: via || `cash:${shop}`, note: txt(note) || `Sales typed for ${date}` });
}
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());

// ---------------------------------------------------------------- build 44: every VAT entry checked by a person
// (owner, 10 Nov: "each month's VAT return should be done automatically but each entry will need to be checked – we
// might have to pay FRCS or claim from them, so it must be calculated very very carefully").
// The entries: each shop's sales for each day (End of day / till / typed – an empty day too: "closed, no sales") and
// each supplier invoice of the month (checked = no longer 'to check'). A day's tick keeps the figures it was given for:
// if the day's sales change afterwards the tick drops off and it must be checked again.
const fp = (d) => `fp:${r2(d.total).toFixed(2)}/${r2(d.zero).toFixed(2)}/${r2(d.vat).toFixed(2)}`;
const dayUid = (shop, date) => `vat_day:${shop}|${date}`;
function tickOf(shop, date) {
  try { return db().get("SELECT * FROM verifications WHERE uid = ? AND status = 'verified'", [dayUid(shop, date)]) || null; } catch (e) { return null; }
}
// A day is checked when its tick was given for the figures it has now.
export function dayChecked(shop, d) {
  const t = tickOf(shop, d.date);
  if (!t) return null;
  const note = String(t.note || '');
  return note.startsWith(fp(d)) ? { by: t.by_name, at: t.at, closed: / shop closed\b/i.test(note) } : null;
}
const shopCodes = () => { try { return db().all("SELECT code FROM shops WHERE active = 1 ORDER BY sort, code").map((r) => r.code).filter((c) => /^S\d+$/.test(String(c))); } catch (e) { return []; } };

// Release 38 (owner, 14 Nov: "each day has its sales so it needs to be there and verified. When verifying the days the
// shop is closed it can be selected as shop closed"): closed: true ticks a day with no sales as "Shop closed" (no
// reason needed – choosing it is the reason); a day that has sales cannot be marked closed.
export function checkDay(user, { date, shop, note, closed = false }) {
  requirePerm(user, 'accounts_journal');
  if (!shop) throw new AppError('Choose the shop first.');
  const ym = String(date || '').slice(0, 7);
  const d = monthRecords({ ym, shop }).days.find((x) => x.date === date);
  if (!d) throw new AppError('That day is not in the month.');
  if (d.future) throw new AppError('This day has not happened yet.');
  // Release 02 (owner, 12 Nov): the shops are open most days, so a day with no sales needs a reason (e.g. "closed –
  // public holiday") – except from the owner, who may tick it without one.
  if (closed && d.total) throw new AppError(`This day has sales (${r2(d.total).toFixed(2)}) – it cannot be marked as shop closed. Check the sales, or have the owner or admin change them.`);
  if (closed) note = `shop closed${txt(note) ? `: ${txt(note)}` : ''}`;
  if (!d.total && !txt(note)) {
    let need = true;
    try { need = require('../../services/access.js').reasonRequired(user); } catch (e) { need = !(user && user.role === 'owner'); }
    if (need) throw new AppError('No sales on this day: type the sales, or write why the shop was closed.');
  }
  const now = stamp(); const dev = deviceId();
  const why = `${fp(d)}${txt(note) ? ` ${txt(note)}` : d.total ? '' : ' shop closed / no sales'}`;
  db().run(`INSERT INTO verifications (uid, table_name, record_uid, status, note, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET status = excluded.status, note = excluded.note, by_name = excluded.by_name, by_uid = excluded.by_uid, at = excluded.at,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [dayUid(shop, date), 'vat_day', `${shop}|${date}`, 'verified', why, user.name, user.uid, now, now, dev]);
  audit({ user, action: `VAT: sales of ${shop} on ${date} checked (${fp(d).slice(3)})`, table: 'verifications', recordUid: dayUid(shop, date) });
  return { ok: true };
}
export function uncheckDay(user, { date, shop }) {
  requirePerm(user, 'accounts_journal');
  const now = stamp();
  db().run("UPDATE verifications SET status = 'undone', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, deviceId(), dayUid(shop, date)]);
  audit({ user, action: `VAT: tick taken off ${shop} ${date}`, table: 'verifications', recordUid: dayUid(shop, date) });
  return { ok: true };
}

// Release 38 (owner, 14 Nov: "the value for the sales data can be rechecked and changed by the admin or owner"): set a
// day's sales to the right figures. Nothing is overwritten: the difference is saved as a correction (a typed sale,
// less or more), with the reason, so the End of day / till balance stay as they came and the change can be seen. The
// day is then ticked for the new figures by the person who changed it.
export function correctDaySales(user, { date, shop, standard, zero, reason }) {
  requirePerm(user, 'accounts_journal');
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can change a day\'s sales.');
  if (!shop) throw new AppError('Choose the shop first.');
  if (txt(reason).length < 3) throw new AppError('Say why the sales are changed (e.g. Z report shows 1,250.00).');
  const ym = String(date || '').slice(0, 7);
  const d = monthRecords({ ym, shop }).days.find((x) => x.date === date);
  if (!d) throw new AppError('That day is not in the month.');
  if (d.future) throw new AppError('This day has not happened yet.');
  const st = r2(standard); const z = r2(zero);
  if (!(st >= 0) || !(z >= 0)) throw new AppError('Type the right VAT sales and zero-rated sales (0 if none).');
  const vat = saleVat(st, ym);
  const dt = r2(st + z - d.total); const dz = r2(z - d.zero); const dv = r2(vat - d.vat);
  if (Math.abs(dt) < 0.005 && Math.abs(dz) < 0.005 && Math.abs(dv) < 0.005) throw new AppError('These are the figures the day already has – nothing to change.');
  const cash = F.moneyCode(`cash:${shop}`, shop);
  const net = r2(dt - dv);
  // signed lines: money in (debit) = dt; sales (credit) = net; VAT (credit) = dv – a negative amount goes on the other side
  const side = (code, amt, debitWhenPositive, sh) => (amt >= 0 === debitWhenPositive ? { code, debit: Math.abs(amt), credit: 0, shop: sh } : { code, debit: 0, credit: Math.abs(amt), shop: sh });
  const lines = [side(cash.code, dt, true, cash.shop || shop), side('4000', net, false, shop), side('2200', dv, false, shop)].filter((l) => l.debit || l.credit);
  const from = { total: d.total, zero: d.zero, vat: d.vat };
  const uid = A.saveJournal(user, { date, memo: `Sales corrected by ${user.name}: ${txt(reason)}`, kind: 'sale', lines,
    meta: { total: dt, zero: dz, vat: dv, shop, correction: { from, to: { total: r2(st + z), zero: z, vat }, reason: txt(reason) } } });
  audit({ user, action: `Sales of ${shop} on ${date} changed from ${r2(d.total).toFixed(2)} to ${r2(st + z).toFixed(2)}`, table: 'gl_journals', recordUid: uid, reason: txt(reason) });
  checkDay(user, { date, shop, note: `changed: ${txt(reason)}` });
  return { uid, from, to: { total: r2(st + z), zero: z, vat } };
}

// The whole month (every shop): how many entries there are and how many are checked.
// → { ym, days, daysDone, invoices, invoicesDone, total, done, left, all, byShop: { S1: { days, done } }, firstLeft }
export function vatChecks(ym) {
  const out = { ym, days: 0, daysDone: 0, invoices: 0, invoicesDone: 0, byShop: {}, firstLeft: null };
  for (const shop of shopCodes()) {
    const m = monthRecords({ ym, shop });
    const past = m.days.filter((x) => !x.future);
    const done = past.filter((x) => dayChecked(shop, x)).length;
    out.byShop[shop] = { days: past.length, done };
    out.days += past.length; out.daysDone += done;
    if (!out.firstLeft && done < past.length) out.firstLeft = { shop, date: past.find((x) => !dayChecked(shop, x)).date };
  }
  const inv = db().all("SELECT status FROM ap_invoices WHERE status <> 'void' AND substr(invoice_date,1,7) = ?", [ym]);
  out.invoices = inv.length; out.invoicesDone = inv.filter((i) => i.status !== 'to_check').length;
  out.total = out.days + out.invoices; out.done = out.daysDone + out.invoicesDone; out.left = out.total - out.done;
  out.all = out.total > 0 && out.left === 0;
  return out;
}
