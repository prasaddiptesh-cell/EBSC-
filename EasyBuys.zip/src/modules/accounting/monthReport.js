// v3.9.8 Monthly business report – part of Month close. One place that says how the month went:
//   sales (by shop, day, weekday, hour), VAT (ready for FRCS VMS), gross profit, products, suppliers, staff costs,
//   fuel, other costs, a forecast for next month, supplier budgets and order suggestions, and a short list of things
//   to improve. The suggestions are kept as "actions" for the month; next month's report measures the same figure
//   again and says whether it got better (the tight loop).
// Read only, except keepActions / markAction (shared settings). Every part is guarded: missing figures → empty parts,
// never an error. Nothing here is sent to Viber (private to owner / admin).
import { db } from '../../db/connection.js';
import { getShared, setShared, stamp, audit, dateStr, addDays, AppError } from '../../services/core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r1 = (n) => Math.round((Number(n) || 0) * 10) / 10;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const pct = (a, b) => (b ? r1(((a - b) / Math.abs(b)) * 100) : null);
const share = (a, b) => (b ? r1((a / b) * 100) : null);
const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dow = (d) => new Date(`${d}T12:00:00`).getDay();
const hourLabel = (h) => { const n = Number(h); return `${n % 12 || 12}${n < 12 ? 'am' : 'pm'}`; };
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole) || safe(() => require('../../services/access.js').actsAsOwner(u), false));

// ---------------------------------------------------------------- months
export function addMonths(ym, k) {
  let [y, m] = ym.split('-').map(Number);
  m += k;
  while (m > 12) { m -= 12; y += 1; }
  while (m < 1) { m += 12; y -= 1; }
  return `${y}-${String(m).padStart(2, '0')}`;
}
export function monthRange(ym) { const from = `${ym}-01`; return { from, to: addDays(`${addMonths(ym, 1)}-01`, -1) }; }
export function daysIn(ym) { const { from, to } = monthRange(ym); return Math.round((new Date(`${to}T12:00:00`) - new Date(`${from}T12:00:00`)) / 86400000) + 1; }
const shopsList = () => safe(() => db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY code'), []);

// ---------------------------------------------------------------- the figures of one month (cheap; also used for history)
// Sales come from the VAT return (Aronium End of day first, till balances where there is none), so the report and the
// VAT return always agree.
export function monthFigures(ym) {
  const { from, to } = monthRange(ym);
  const A = safe(() => require('./service.js'), null);
  const v = A ? safe(() => A.vatReturn({ ym }), null) : null;
  const byShop = {};
  const byDate = {};
  if (v) for (const s of v.saleRows || []) {
    const k = s.shop || '?';
    const o = byShop[k] || (byShop[k] = { sales: 0, vat: 0, zero: 0, days: new Set() });
    o.sales = r2(o.sales + (Number(s.total) || 0)); o.vat = r2(o.vat + (Number(s.vat) || 0)); o.zero = r2(o.zero + (Number(s.zero) || 0)); o.days.add(s.date);
    byDate[s.date] = r2((byDate[s.date] || 0) + (Number(s.total) || 0));
  }
  Object.values(byShop).forEach((o) => { o.days = o.days.size; });
  const sales = v ? v.sales.total : 0;
  const exVat = v ? v.sales.exVat : 0;
  // staff: final pay runs paid in the month (gross + employer FNPF)
  const wages = has('pay_runs') ? safe(() => db().get(`SELECT SUM(l.gross) AS g, SUM(l.fnpf_employer) AS fr, SUM(l.fnpf_employee) AS fe, SUM(l.paye) AS paye, COUNT(DISTINCT l.user_uid) AS people
    FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid AND l.include = 1 WHERE r.status = 'final' AND r.pay_date BETWEEN ? AND ?`, [from, to]), {}) : {};
  const wagesByShop = has('pay_runs') ? safe(() => db().all(`SELECT IFNULL(l.shop_code, '?') AS shop, SUM(l.gross) + SUM(l.fnpf_employer) AS cost, COUNT(DISTINCT l.user_uid) AS people
    FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid AND l.include = 1 WHERE r.status = 'final' AND r.pay_date BETWEEN ? AND ? GROUP BY IFNULL(l.shop_code, '?')`, [from, to]), []) : [];
  const fuel = has('ve_fuel') ? safe(() => db().get("SELECT SUM(amount) AS amount, SUM(litres) AS litres, COUNT(*) AS fills FROM ve_fuel WHERE status = 'active' AND fill_date BETWEEN ? AND ?", [from, to]), {}) : {};
  const buys = has('ap_invoices') ? safe(() => db().get("SELECT SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END) AS t, COUNT(*) AS n FROM ap_invoices WHERE status <> 'void' AND invoice_date BETWEEN ? AND ?", [from, to]), {}) : {};
  return {
    ym, from, to, days: daysIn(ym),
    sales: r2(sales), exVat: r2(exVat), outputVat: v ? v.sales.output : 0, zeroRated: v ? v.sales.zeroRated : 0,
    inputVat: v ? v.purchases.input : 0, vatNet: v ? v.net : 0, vatDue: v ? v.due : null, purchases: r2((buys && buys.t) || 0), invoices: (buys && buys.n) || 0,
    wages: r2(((wages && wages.g) || 0) + ((wages && wages.fr) || 0)), gross: r2((wages && wages.g) || 0), fnpfEmployer: r2((wages && wages.fr) || 0), fnpfEmployee: r2((wages && wages.fe) || 0), paye: r2((wages && wages.paye) || 0), people: (wages && wages.people) || 0,
    wagesByShop: wagesByShop.map((w) => ({ shop: w.shop, cost: r2(w.cost), people: w.people })),
    fuel: r2((fuel && fuel.amount) || 0), litres: r1((fuel && fuel.litres) || 0), fills: (fuel && fuel.fills) || 0,
    byShop, byDate, salesDays: Object.keys(byDate).length, aronium: v ? v.aronium : null,
  };
}

// ---------------------------------------------------------------- products (Aronium sales lines)
function productLines(ym) {
  const { from, to } = monthRange(ym);
  const L = safe(() => require('../aronium/link.js'), null);
  const days = L ? safe(() => L.aroniumSalesByDay({ from, withLines: true }), []) : [];
  const per = new Map();
  for (const d of days) {
    if (d.date > to) continue;
    for (const l of d.lines || []) {
      const k = txt(l.code) || txt(l.name);
      if (!k) continue;
      const o = per.get(k) || { code: txt(l.code), name: txt(l.name), qty: 0, value: 0, cost: 0, shops: new Set() };
      o.qty = r2(o.qty + (Number(l.net) || 0));
      o.value = r2(o.value + (Number(l.sold_value) || 0) - (Number(l.refund_value) || 0));
      o.cost = r2(o.cost + (Number(l.cost) || 0));
      o.shops.add(d.shop);
      per.set(k, o);
    }
  }
  return [...per.values()].map((o) => ({ ...o, shops: [...o.shops].join(', ') }));
}
// The Aronium values include VAT on standard-rated goods; the margin uses the month's ex-VAT share so it is close
// to the accounts (shown as "about").
function productPart(ym, exVatShare) {
  const lines = productLines(ym);
  const prev = new Map(productLines(addMonths(ym, -1)).map((p) => [p.code || p.name, p]));
  const rows = lines.map((p) => {
    const net = r2(p.value * exVatShare);
    const profit = r2(net - p.cost);
    const before = prev.get(p.code || p.name);
    return { ...p, net, profit, margin: net > 0 ? r1((profit / net) * 100) : null, lastMonth: before ? before.value : 0, change: before ? pct(p.value, before.value) : null };
  });
  const sold = rows.filter((r) => r.value > 0);
  const total = r2(sold.reduce((s, r) => s + r.value, 0));
  const profit = r2(sold.reduce((s, r) => s + r.profit, 0));
  const cost = r2(sold.reduce((s, r) => s + r.cost, 0));
  const byValue = [...sold].sort((a, b) => b.value - a.value);
  // the products that make 80 % of sales
  let run = 0; let core = 0;
  for (const r of byValue) { if (run >= total * 0.8) break; run += r.value; core += 1; }
  return {
    count: sold.length, total, cost, profit, margin: total ? r1((profit / r2(total * exVatShare)) * 100) : null, core,
    top: byValue.slice(0, 10),
    topProfit: [...sold].sort((a, b) => b.profit - a.profit).slice(0, 10),
    belowCost: sold.filter((r) => r.cost > 0 && r.net < r.cost).sort((a, b) => a.profit - b.profit).slice(0, 15),
    lowMargin: sold.filter((r) => r.margin !== null && r.margin >= 0 && r.margin < 10 && r.value >= 100).sort((a, b) => b.value - a.value).slice(0, 10),
    rising: sold.filter((r) => r.change !== null && r.lastMonth >= 50 && r.change >= 25).sort((a, b) => b.change - a.change).slice(0, 8),
    falling: rows.filter((r) => r.change !== null && r.lastMonth >= 100 && r.change <= -30).sort((a, b) => a.change - b.change).slice(0, 8),
    slow: safe(() => require('../aronium/insights.js').slowMovers({ days: 60 }), []).slice(0, 15),
  };
}

// ---------------------------------------------------------------- when the money comes in (Aronium activity)
function timePart(ym, fig) {
  const { from, to } = monthRange(ym);
  const rows = has('aronium_feed') ? safe(() => db().all("SELECT source, period, data FROM aronium_feed WHERE kind = 'activity' AND period BETWEEN ? AND ?", [from, to]), []) : [];
  const hours = {};
  const cashiers = {};
  for (const r of rows) {
    const a = J(r.data, {});
    for (const [hh, x] of Object.entries(a.hours || {})) {
      const h = hours[hh] || (hours[hh] = { value: 0, receipts: 0, days: new Set() });
      h.value = r2(h.value + (Number(x.value) || 0)); h.receipts += Number(x.receipts) || 0; h.days.add(r.period);
    }
    for (const [name, c] of Object.entries(a.cashiers || {})) {
      const o = cashiers[name] || (cashiers[name] = { name, sales: 0, receipts: 0, refunds: 0, refund_value: 0, discounts: 0, discount_value: 0, voids: 0, void_value: 0, shop: txt(r.source).split('-')[0] });
      for (const f of ['sales', 'receipts', 'refunds', 'refund_value', 'discounts', 'discount_value', 'voids', 'void_value']) o[f] = r2(o[f] + (Number(c[f]) || 0));
    }
  }
  const hourList = Object.keys(hours).sort().map((hh) => ({ hour: hh, label: `${hourLabel(hh)}–${hourLabel((Number(hh) + 1) % 24)}`, value: hours[hh].value, receipts: hours[hh].receipts, perDay: r2(hours[hh].value / Math.max(1, hours[hh].days.size)), avgSale: hours[hh].receipts ? r2(hours[hh].value / hours[hh].receipts) : 0 }));
  const allReceipts = hourList.reduce((s, h) => s + h.receipts, 0);
  const weekday = DAYS.map((d, i) => ({ day: d, total: 0, n: 0 }));
  for (const [date, v] of Object.entries(fig.byDate)) { const w = weekday[dow(date)]; w.total = r2(w.total + v); w.n += 1; }
  weekday.forEach((w) => { w.avg = w.n ? r2(w.total / w.n) : 0; });
  const dayList = Object.entries(fig.byDate).map(([date, value]) => ({ date, day: DAYS[dow(date)], value })).sort((a, b) => (a.date < b.date ? -1 : 1));
  const withSales = dayList.filter((d) => d.value > 0);
  const best = withSales.reduce((b, d) => (!b || d.value > b.value ? d : b), null);
  const worst = withSales.reduce((b, d) => (!b || d.value < b.value ? d : b), null);
  const peak = hourList.reduce((b, h) => (!b || h.perDay > b.perDay ? h : b), null);
  const quiet = hourList.filter((h) => peak && h.perDay < peak.perDay * 0.2 && h.receipts > 0);
  return {
    hours: hourList, weekday, days: dayList, best, worst, peak, quiet,
    receipts: allReceipts, avgSale: allReceipts ? r2(hourList.reduce((s, h) => s + h.value, 0) / allReceipts) : 0,
    cashiers: Object.values(cashiers).sort((a, b) => b.sales - a.sales),
    hasActivity: rows.length > 0,
  };
}

// ---------------------------------------------------------------- suppliers
function supplierSpend(from, to) {
  if (!has('ap_invoices')) return [];
  return safe(() => db().all(`SELECT IFNULL(supplier_uid, supplier_name) AS k, MAX(supplier_uid) AS uid, MAX(supplier_name) AS name, SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END) AS total, COUNT(*) AS n
    FROM ap_invoices WHERE status <> 'void' AND invoice_date BETWEEN ? AND ? AND IFNULL(category, '') NOT IN ('loan','rent','utilities','power','water') GROUP BY IFNULL(supplier_uid, supplier_name)`, [from, to]), []);
}
function supplierPart(ym, growth) {
  const { from, to } = monthRange(ym);
  const now = new Map(supplierSpend(from, to).map((s) => [s.k, s]));
  const hist = [1, 2, 3].map((k) => { const r = monthRange(addMonths(ym, -k)); return new Map(supplierSpend(r.from, r.to).map((s) => [s.k, s])); });
  const keys = new Set([...now.keys(), ...hist.flatMap((h) => [...h.keys()])]);
  const sup = (uid) => (uid && has('ap_suppliers') ? safe(() => db().get('SELECT uid, name, budget_monthly, budget_weekly, lead_days, order_days FROM ap_suppliers WHERE uid = ?', [uid]), null) : null);
  const rises = has('inv_cost_changes') ? safe(() => db().all('SELECT supplier_name AS name, COUNT(*) AS n, AVG((new_cost - old_cost) / old_cost) AS avgRise FROM inv_cost_changes WHERE change_date BETWEEN ? AND ? AND old_cost > 0 AND new_cost > old_cost GROUP BY supplier_name', [from, to]), []) : [];
  const riseOf = new Map(rises.map((x) => [txt(x.name).toLowerCase(), x]));
  const list = [];
  for (const k of keys) {
    const cur = now.get(k);
    const past = hist.map((h) => (h.get(k) ? Number(h.get(k).total) || 0 : 0));
    const monthsSeen = [cur ? 1 : 0].concat(past.map((p) => (p ? 1 : 0))).reduce((s, x) => s + x, 0);
    const avg3 = r2(past.reduce((s, x) => s + x, 0) / 3);
    const any = cur || hist.map((h) => h.get(k)).find(Boolean);
    const s = sup(any && any.uid);
    const spent = r2(cur ? cur.total : 0);
    // suggested budget for next month: the usual spend (this month and the 3 before, this month counted twice),
    // moved with the sales forecast, rounded up to $50.
    const base = (spent * 2 + past.reduce((a, b) => a + b, 0)) / 5;
    const suggest = base > 0 ? Math.ceil((base * growth) / 50) * 50 : 0;
    const r = riseOf.get(txt(any && any.name).toLowerCase());
    list.push({
      key: k, uid: any && any.uid, name: (any && any.name) || k, spent, invoices: cur ? cur.n : 0, lastMonth: r2(past[0]), avg3, change: pct(spent, avg3 || past[0]),
      budget: s && s.budget_monthly !== null && s.budget_monthly !== undefined ? r2(s.budget_monthly) : null, overBudget: s && s.budget_monthly ? r2(spent - s.budget_monthly) : null,
      suggestBudget: monthsSeen >= 2 ? suggest : null, priceRises: r ? r.n : 0, avgRise: r ? r1(r.avgRise * 100) : null, monthsSeen,
    });
  }
  return list.filter((x) => x.spent > 0 || x.avg3 > 0).sort((a, b) => b.spent - a.spent);
}
// When each supplier is usually ordered from and how much – from the order history (sent / received orders).
export function orderSuggestions({ today = dateStr(), days = 120 } = {}) {
  if (!has('po_orders')) return [];
  const rows = safe(() => db().all(`SELECT supplier_uid, MAX(supplier_name) AS name, shop_code, GROUP_CONCAT(order_date || '|' || total, ';') AS hist
    FROM po_orders WHERE status NOT IN ('draft','cancelled','void') AND order_date >= ? GROUP BY supplier_uid, shop_code`, [addDays(today, -days)]), []);
  const reorder = safe(() => require('../aronium/insights.js').reorderList({}), []);
  const out = [];
  for (const r of rows) {
    const h = txt(r.hist).split(';').map((x) => { const [d, t] = x.split('|'); return { d, t: Number(t) || 0 }; }).filter((x) => x.d).sort((a, b) => (a.d < b.d ? -1 : 1));
    if (!h.length) continue;
    const gaps = h.slice(1).map((x, i) => Math.round((new Date(`${x.d}T12:00:00`) - new Date(`${h[i].d}T12:00:00`)) / 86400000)).filter((g) => g > 0);
    const every = gaps.length ? Math.round(gaps.sort((a, b) => a - b)[Math.floor(gaps.length / 2)]) : null;
    const amounts = h.map((x) => x.t).filter((t) => t > 0).sort((a, b) => a - b);
    const usual = amounts.length ? r2(amounts[Math.floor(amounts.length / 2)]) : 0;
    const last = h[h.length - 1].d;
    const next = every ? addDays(last, every) : null;
    const g = reorder.find((x) => x.supplierUid === r.supplier_uid && x.shop === r.shop_code);
    out.push({ supplierUid: r.supplier_uid, name: r.name, shop: r.shop_code, orders: h.length, every, usual, last, next, due: next ? next <= addDays(today, 3) : false,
      lowItems: g ? g.items.filter((x) => x.qty > 0).length : 0, lowValue: g ? r2(g.total) : 0 });
  }
  return out.sort((a, b) => (a.next || '9999') < (b.next || '9999') ? -1 : 1);
}

// ---------------------------------------------------------------- other costs, fuel, staff
function costPart(ym) {
  const { from, to } = monthRange(ym);
  const p = monthRange(addMonths(ym, -1));
  const cat = (f, t) => (has('ap_invoices') ? safe(() => db().all(`SELECT IFNULL(NULLIF(category,''),'Other') AS cat, SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END) AS total FROM ap_invoices WHERE status <> 'void' AND invoice_date BETWEEN ? AND ? GROUP BY IFNULL(NULLIF(category,''),'Other')`, [f, t]), []) : []);
  const before = new Map(cat(p.from, p.to).map((c) => [c.cat, Number(c.total) || 0]));
  return cat(from, to).map((c) => ({ cat: c.cat, total: r2(c.total), lastMonth: r2(before.get(c.cat) || 0), change: pct(c.total, before.get(c.cat)) })).sort((a, b) => b.total - a.total);
}
function fuelPart(ym) {
  const { from, to } = monthRange(ym);
  if (!has('ve_fuel')) return [];
  return safe(() => db().all(`SELECT f.item_uid, MAX(i.name) AS name, MAX(i.area) AS area, SUM(f.amount) AS amount, SUM(f.litres) AS litres, COUNT(*) AS fills, AVG(f.km_per_l) AS kmpl, MAX(f.km) - MIN(f.km) AS km,
    SUM(CASE WHEN IFNULL(f.flags,'') NOT IN ('','[]') THEN 1 ELSE 0 END) AS flagged
    FROM ve_fuel f LEFT JOIN ve_items i ON i.uid = f.item_uid WHERE f.status = 'active' AND f.fill_date BETWEEN ? AND ? GROUP BY f.item_uid ORDER BY SUM(f.amount) DESC`, [from, to]), [])
    .map((x) => ({ ...x, amount: r2(x.amount), litres: r1(x.litres), kmpl: x.kmpl ? r1(x.kmpl) : null, km: Math.round(x.km || 0), perKm: x.km > 0 ? r2(x.amount / x.km) : null }));
}
function staffPart(ym, fig, time) {
  const { from, to } = monthRange(ym);
  const shortages = has('till_shortages') ? safe(() => db().all("SELECT name, shop_code AS shop, COUNT(*) AS n, SUM(amount) AS amount FROM till_shortages WHERE shift_date BETWEEN ? AND ? AND status <> 'void' GROUP BY name, shop_code ORDER BY SUM(amount) DESC", [from, to]), []) : [];
  const cash = safe(() => require('../aronium/insights.js').cashierWatch({ days: daysIn(ym), today: addDays(to, 1) }), []);
  const leave = has('leave_requests') ? safe(() => db().get("SELECT COUNT(*) AS n FROM leave_requests WHERE status = 'approved' AND start_date <= ? AND end_date >= ?", [to, from]), {}) : {};
  return {
    cost: fig.wages, gross: fig.gross, fnpfEmployer: fig.fnpfEmployer, paye: fig.paye, people: fig.people, byShop: fig.wagesByShop,
    ofSales: share(fig.wages, fig.exVat), perPerson: fig.people ? r2(fig.wages / fig.people) : null,
    salesPerWageDollar: fig.wages ? r2(fig.exVat / fig.wages) : null,
    shortages: shortages.map((s) => ({ ...s, amount: r2(s.amount) })), shortTotal: r2(shortages.reduce((s, x) => s + (Number(x.amount) || 0), 0)),
    cashierFlags: cash.filter((c) => c.flags && c.flags.length).map((c) => ({ name: c.name, shop: c.shop, flags: c.flags })),
    cashiers: time.cashiers.slice(0, 15), leaveRequests: (leave && leave.n) || 0,
  };
}

// ---------------------------------------------------------------- VAT and FRCS VMS readiness
function vatPart(ym, fig) {
  const A = safe(() => require('./service.js'), null);
  const v = A ? safe(() => A.vatReturn({ ym }), null) : null;
  const shops = shopsList().filter((s) => /^S/.test(s.code));
  const { from, to } = monthRange(ym);
  const today = dateStr();
  const last = to < today ? to : addDays(today, -1);
  const missing = [];
  if (has('aronium_eods')) {
    for (const s of shops) {
      const got = new Set(safe(() => db().all("SELECT DISTINCT eod_date AS d FROM aronium_eods WHERE shop_code = ? AND state <> 'void' AND eod_date BETWEEN ? AND ?", [s.code, from, last]), []).map((x) => x.d));
      let n = 0;
      for (let d = from; d <= last; d = addDays(d, 1)) if (!got.has(d) && (fig.byShop[s.code] || d >= from)) n += 1;
      if (n) missing.push({ shop: s.code, days: n });
    }
  }
  const noTax = safe(() => require('../inventory/service.js').noTaxInAronium(), []);
  const vatTyped = v ? v.saleRows.filter((r) => !r.typed).length : 0;
  return {
    output: v ? v.sales.output : 0, input: v ? v.purchases.input : 0, net: v ? v.net : 0, due: v ? v.due : null,
    sales: v ? v.sales.total : 0, zeroRated: v ? v.sales.zeroRated : 0, exVat: v ? v.sales.exVat : 0, purchases: v ? v.purchases.total : 0,
    noTin: v ? v.purchases.noTin : 0, toCheck: v ? v.purchases.toCheck : 0,
    unresolved: v && v.aronium ? v.aronium.unresolved : 0,
    vms: [
      { key: 'eod', label: 'An Aronium End of day for every day at every shop', ok: !missing.length, sub: missing.length ? missing.map((m) => `${m.shop}: ${m.days} day${m.days === 1 ? '' : 's'} missing`).join(' · ') : null },
      { key: 'diff', label: 'Till and Aronium agree (every difference explained)', ok: !(v && v.aronium && v.aronium.unresolved), sub: v && v.aronium && v.aronium.unresolved ? `${v.aronium.unresolved} not explained yet` : null },
      { key: 'tax', label: 'Every product has its tax set in Aronium (VAT or 0 %)', ok: !(noTax && noTax.length), sub: noTax && noTax.length ? `${noTax.length} product${noTax.length === 1 ? '' : 's'} with no tax set` : null },
      { key: 'vat', label: 'VAT taken from the End of day (not worked out)', ok: !vatTyped, sub: vatTyped ? `${vatTyped} day${vatTyped === 1 ? '' : 's'} worked out at the standard rate` : null },
      { key: 'tin', label: 'Every supplier invoice with VAT has the supplier\'s TIN', ok: !(v && v.purchases.noTin), sub: v && v.purchases.noTin ? `${v.purchases.noTin} invoice${v.purchases.noTin === 1 ? '' : 's'} without a TIN (input VAT at risk)` : null },
    ],
  };
}

// ---------------------------------------------------------------- forecast for next month
// Each shop's sales per day: the last 3 months weighted 3:2:1; when last year's figures exist, moved by how last
// year's next month compared with last year's this month (capped). Costs: the average of the last 3 months.
export function forecast(ym, figs) {
  const next = addMonths(ym, 1);
  const f = (k) => figs[addMonths(ym, -k)] || monthFigures(addMonths(ym, -k));
  const m = [f(0), f(1), f(2)];
  const rate = (x) => (x && x.salesDays ? x.sales / x.days : 0);
  const w = [[3, rate(m[0])], [2, rate(m[1])], [1, rate(m[2])]].filter(([, r]) => r > 0);
  const base = w.length ? w.reduce((s, [k, r]) => s + k * r, 0) / w.reduce((s, [k]) => s + k, 0) : 0;
  const ly = safe(() => monthFigures(addMonths(next, -12)), null);
  const lyNow = safe(() => monthFigures(addMonths(ym, -12)), null);
  let season = 1;
  if (ly && lyNow && rate(ly) > 0 && rate(lyNow) > 0) season = Math.min(1.5, Math.max(0.7, rate(ly) / rate(lyNow)));
  const rates = m.map(rate).filter((r) => r > 0);
  const mean = rates.length ? rates.reduce((s, x) => s + x, 0) / rates.length : 0;
  const spread = rates.length > 1 ? Math.sqrt(rates.reduce((s, x) => s + (x - mean) ** 2, 0) / (rates.length - 1)) : mean * 0.1;
  const dn = daysIn(next);
  const sales = r2(base * season * dn);
  const avg = (k) => r2(m.reduce((s, x) => s + ((x && x[k]) || 0), 0) / Math.max(1, m.filter((x) => x && x[k]).length));
  const growth = mean > 0 ? (base * season) / mean : 1;
  const byShop = {};
  for (const code of Object.keys(m[0].byShop || {})) {
    const r = m.map((x) => (x && x.byShop[code] ? x.byShop[code].sales / x.days : 0));
    const ws = [[3, r[0]], [2, r[1]], [1, r[2]]].filter(([, v]) => v > 0);
    byShop[code] = ws.length ? r2((ws.reduce((s, [k, v]) => s + k * v, 0) / ws.reduce((s, [k]) => s + k, 0)) * season * dn) : 0;
  }
  return {
    ym: next, days: dn, sales, low: r2(Math.max(0, (base * season - spread) * dn)), high: r2((base * season + spread) * dn), byShop,
    wages: avg('wages'), fuel: avg('fuel'), purchases: r2(avg('purchases') * growth), vat: r2(avg('vatNet') * growth),
    season: r2(season), usedLastYear: season !== 1, monthsUsed: rates.length, growth: r2(growth),
    note: rates.length < 2 ? 'Only one month of figures so far – the forecast gets better each month.' : null,
  };
}

// ---------------------------------------------------------------- suggestions and the loop
// Each measure: how to work it out for any month (so next month can check it again), which way is better, and the
// text when it needs attention. value(r) reads a built report.
const MEASURES = {
  wagesPct: { label: 'Wages as % of sales', better: 'down', unit: '%', value: (r) => r.staff.ofSales },
  fuel: { label: 'Fuel spend', better: 'down', unit: '$', value: (r) => r.fig.fuel },
  belowCost: { label: 'Products sold below cost', better: 'down', unit: '', value: (r) => r.products.belowCost.length },
  lowMargin: { label: 'Busy products with under 10 % margin', better: 'down', unit: '', value: (r) => r.products.lowMargin.length },
  overBudget: { label: 'Suppliers over budget', better: 'down', unit: '', value: (r) => r.suppliers.filter((s) => s.overBudget > 0).length },
  noBudget: { label: 'Big suppliers with no monthly budget', better: 'down', unit: '', value: (r) => r.suppliers.filter((s) => s.budget === null && s.spent >= 1000).length },
  costUp: { label: 'Cost went up but selling price did not', better: 'down', unit: '', value: (r) => r.costUp },
  slow: { label: 'Stock not sold for 60+ days ($)', better: 'down', unit: '$', value: (r) => r2(r.products.slow.reduce((s, x) => s + (Number(x.value) || 0), 0)) },
  shortages: { label: 'Till shortages ($)', better: 'down', unit: '$', value: (r) => r.staff.shortTotal },
  cashierFlags: { label: 'Cashiers flagged (refunds / voids / discounts)', better: 'down', unit: '', value: (r) => r.staff.cashierFlags.length },
  vms: { label: 'VAT / VMS checks not passing', better: 'down', unit: '', value: (r) => r.vat.vms.filter((x) => !x.ok).length },
  salesPerDay: { label: 'Sales per day', better: 'up', unit: '$', value: (r) => (r.fig.salesDays ? r2(r.fig.sales / r.fig.salesDays) : null) },
  avgSale: { label: 'Average sale', better: 'up', unit: '$', value: (r) => (r.time.avgSale || null) },
};
function suggestionsFor(r) {
  const out = [];
  const add = (key, text, why, target) => out.push({ key, measure: key, label: MEASURES[key].label, text, why, value: MEASURES[key].value(r), target: target === undefined ? null : target, unit: MEASURES[key].unit });
  const s = r.staff;
  const prevPct = r.prevStaffPct;
  if (s.ofSales !== null && (s.ofSales > 18 || (prevPct !== null && s.ofSales > prevPct + 2))) {
    const q = r.time.quiet.slice(0, 3).map((h) => h.label).join(', ');
    add('wagesPct', `Match the roster to the busy hours${q ? ` – the quiet hours were ${q}` : ''}${r.time.peak ? `; the busiest was ${r.time.peak.label}` : ''}.`, `Wages were ${s.ofSales}% of sales${prevPct !== null ? ` (last month ${prevPct}%)` : ''}.`, Math.min(s.ofSales - 1, 18));
  }
  if (r.fig.fuel > 0 && r.prevFuelAvg > 0 && r.fig.fuel > r.prevFuelAvg * 1.15) {
    const worst = r.fuel.filter((f) => f.flagged > 0).map((f) => f.name).slice(0, 3).join(', ');
    add('fuel', `Check the vehicle trips and fill-ups${worst ? ` (flagged: ${worst})` : ''}; combine deliveries where you can.`, `Fuel was ${$(r.fig.fuel)}, ${pct(r.fig.fuel, r.prevFuelAvg)}% above the usual ${$(r.prevFuelAvg)}.`, r2(r.prevFuelAvg));
  }
  if (r.products.belowCost.length) add('belowCost', `Fix the selling price in Aronium of: ${r.products.belowCost.slice(0, 4).map((p) => p.name).join(', ')}${r.products.belowCost.length > 4 ? ' …' : ''}.`, `${r.products.belowCost.length} product${r.products.belowCost.length === 1 ? ' was' : 's were'} sold for less than they cost.`, 0);
  if (r.products.lowMargin.length >= 3) add('lowMargin', `Review the prices (or ask the supplier for a better cost) of ${r.products.lowMargin.slice(0, 3).map((p) => p.name).join(', ')}.`, `${r.products.lowMargin.length} busy products made under 10 % margin.`, Math.max(0, r.products.lowMargin.length - 3));
  if (r.costUp > 0) add('costUp', 'Change the selling prices in Aronium where the supplier\'s cost went up (Inventory › Aronium product changes › To fix).', `${r.costUp} product${r.costUp === 1 ? '' : 's'}: the cost went up but the selling price did not.`, 0);
  const over = r.suppliers.filter((x) => x.overBudget > 0);
  if (over.length) add('overBudget', `Hold or reduce orders from ${over.slice(0, 3).map((x) => x.name).join(', ')} next month, or raise the budget if the sales need it.`, `${over.length} supplier${over.length === 1 ? ' was' : 's were'} over the monthly budget.`, 0);
  const nob = r.suppliers.filter((x) => x.budget === null && x.spent >= 1000);
  if (nob.length) add('noBudget', `Set a monthly budget for ${nob.slice(0, 3).map((x) => `${x.name} (suggested ${x.suggestBudget ? $(x.suggestBudget) : 'see below'})`).join(', ')}.`, 'Big suppliers without a budget are the easiest place for spending to creep up.', 0);
  const slowVal = MEASURES.slow.value(r);
  if (slowVal >= 500) add('slow', `Stop re-ordering and clear the slow stock (a price cut, a bundle, or return to the supplier): ${r.products.slow.slice(0, 3).map((p) => p.name).join(', ')}.`, `${$(slowVal)} of stock has not sold for 60+ days.`, r2(slowVal * 0.7));
  if (s.shortTotal >= 50) add('shortages', `Talk with ${s.shortages.slice(0, 2).map((x) => x.name).filter(Boolean).join(' and ') || 'the cashiers'} and count the till at every handover.`, `Tills were short by ${$(s.shortTotal)} this month.`, r2(s.shortTotal / 2));
  if (s.cashierFlags.length) add('cashierFlags', `Watch ${s.cashierFlags.slice(0, 2).map((c) => c.name).join(' and ')} – ${s.cashierFlags[0].flags[0]}.`, 'Refunds, voids or discounts well above the rest of the team.', 0);
  const vmsBad = r.vat.vms.filter((x) => !x.ok);
  if (vmsBad.length) add('vms', `Before the VAT is filed: ${vmsBad.map((x) => x.label.toLowerCase()).join('; ')}.`, 'From January FRCS can see the sales directly, so the app\'s figures must match Aronium and the VAT return exactly.', 0);
  if (r.salesChange !== null && r.salesChange <= -5) add('salesPerDay', `Sales per day fell ${Math.abs(r.salesChange)}%. Put specials on the top sellers at the busy time${r.time.peak ? ` (${r.time.peak.label})` : ''} and check the products that dropped: ${r.products.falling.slice(0, 3).map((p) => p.name).join(', ') || 'see Products'}.`, 'Compared with last month, per trading day.', MEASURES.salesPerDay.value(r) ? r2(MEASURES.salesPerDay.value(r) * 1.05) : null);
  if (r.time.avgSale && r.prevAvgSale && r.time.avgSale < r.prevAvgSale * 0.95) add('avgSale', 'Put add-on items by the tills (bread with spreads, drinks with snacks) to lift the average sale.', `The average sale dropped from ${$(r.prevAvgSale)} to ${$(r.time.avgSale)}.`, r2(r.prevAvgSale));
  return out.slice(0, 8);
}
// Last month's kept actions, measured again this month.
function followUp(ym, r) {
  const prev = getShared(`month_actions_${addMonths(ym, -1)}`, null);
  if (!prev || !Array.isArray(prev.items)) return [];
  return prev.items.map((a) => {
    const m = MEASURES[a.measure];
    const now = m ? safe(() => m.value(r), null) : null;
    let state = 'unknown';
    if (now !== null && a.value !== null && a.value !== undefined) {
      const hit = a.target !== null && a.target !== undefined && (m.better === 'down' ? now <= a.target : now >= a.target);
      const better = m.better === 'down' ? now < a.value : now > a.value;
      state = hit ? 'done' : better ? 'better' : now === a.value ? 'same' : 'worse';
    }
    return { ...a, now, state, mark: a.mark || null };
  });
}
export function keepActions(user, ym, items) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin can keep the month\'s actions.');
  const list = (items || []).map((a) => ({ key: a.key, measure: a.measure, label: a.label, text: a.text, why: a.why, value: a.value, target: a.target, unit: a.unit, mark: null }));
  setShared(`month_actions_${ym}`, { by: user.name, at: stamp(), items: list });
  audit({ user, action: `Kept ${list.length} action${list.length === 1 ? '' : 's'} for after ${ym}`, table: 'shared_settings', recordUid: `month_actions_${ym}` });
  return list;
}
export function markAction(user, ym, key, mark) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin can mark the actions.');
  const k = `month_actions_${ym}`;
  const cur = getShared(k, null);
  if (!cur || !Array.isArray(cur.items)) throw new AppError('No actions kept for that month.');
  setShared(k, { ...cur, items: cur.items.map((a) => (a.key === key ? { ...a, mark: mark || null, markedBy: user.name, markedAt: stamp() } : a)) });
}
export function actionsKept(ym) { const x = getShared(`month_actions_${ym}`, null); return x && Array.isArray(x.items) ? x : null; }

// ---------------------------------------------------------------- the whole report
const cache = { key: '', at: 0, val: null };
export function monthReport(ym, { fresh = false } = {}) {
  let wc = 0;
  try { wc = Number(db().get('SELECT total_changes() AS n').n) || 0; } catch (e) { wc = 0; }
  const ck = `${ym}|${wc}`;
  if (!fresh && cache.key === ck && Date.now() - cache.at < 60000) return cache.val;
  const figs = {};
  const fig = monthFigures(ym); figs[ym] = fig;
  const prev = monthFigures(addMonths(ym, -1)); figs[addMonths(ym, -1)] = prev;
  const prev2 = monthFigures(addMonths(ym, -2)); figs[addMonths(ym, -2)] = prev2;
  const lastYear = safe(() => monthFigures(addMonths(ym, -12)), null);
  const exVatShare = fig.sales > 0 ? fig.exVat / fig.sales : 0.89;
  const fc = forecast(ym, figs);
  const products = productPart(ym, exVatShare);
  const time = timePart(ym, fig);
  const prevTime = safe(() => timePart(addMonths(ym, -1), prev), { avgSale: 0 });
  const r = {
    ym, made: stamp(), fig, prev, lastYear: lastYear && lastYear.sales ? lastYear : null, forecast: fc, products, time,
    suppliers: supplierPart(ym, fc.growth || 1), orders: orderSuggestions({ today: dateStr() }), costs: costPart(ym), fuel: fuelPart(ym),
    vat: vatPart(ym, fig), shops: shopsList(),
    costUp: safe(() => require('../../services/productWatch.js').productProblems().costUp.length, 0),
  };
  r.staff = staffPart(ym, fig, time);
  const prevWages = [prev, prev2].filter((x) => x.wages && x.exVat);
  r.prevStaffPct = prevWages.length ? r1(prevWages.reduce((s, x) => s + (x.wages / x.exVat) * 100, 0) / prevWages.length) : null;
  r.prevFuelAvg = r2([prev, prev2].reduce((s, x) => s + x.fuel, 0) / Math.max(1, [prev, prev2].filter((x) => x.fuel).length));
  r.prevAvgSale = prevTime.avgSale || 0;
  const perDay = (x) => (x && x.salesDays ? x.sales / x.salesDays : 0);
  r.salesChange = perDay(prev) ? pct(perDay(fig), perDay(prev)) : null;
  r.headline = {
    sales: fig.sales, salesChange: pct(fig.sales, prev.sales), salesVsLastYear: r.lastYear ? pct(fig.sales, r.lastYear.sales) : null,
    grossProfit: products.profit, margin: products.margin, wages: fig.wages, wagesPct: r.staff.ofSales, fuel: fig.fuel, fuelChange: pct(fig.fuel, prev.fuel),
    vatNet: fig.vatNet, vatDue: fig.vatDue, purchases: fig.purchases, otherCosts: r2(r.costs.reduce((s, c) => s + c.total, 0)),
  };
  r.calm = calmList(r);
  r.suggestions = suggestionsFor(r);
  r.followUp = followUp(ym, r);
  r.kept = actionsKept(ym);
  cache.key = ck; cache.at = Date.now(); cache.val = r;
  return r;
}
// "Peace of mind": what is fine this month, said plainly, and what is not.
function calmList(r) {
  const ok = []; const watch = [];
  const put = (good, a, b) => (good ? ok : watch).push(good ? a : b);
  if (r.headline.salesChange !== null) put(r.headline.salesChange >= -3, `Sales held up (${r.headline.salesChange >= 0 ? '+' : ''}${r.headline.salesChange}% on last month)`, `Sales were ${r.headline.salesChange}% below last month`);
  if (r.staff.ofSales !== null) put(r.staff.ofSales <= 18, `Wages were ${r.staff.ofSales}% of sales`, `Wages were ${r.staff.ofSales}% of sales – above 18 %`);
  r.vat.vms.forEach((v) => put(v.ok, v.label, `${v.label}: ${v.sub}`));
  put(!r.products.belowCost.length, 'Nothing sold below cost', `${r.products.belowCost.length} product(s) sold below cost`);
  put(!r.staff.shortTotal || r.staff.shortTotal < 20, 'Tills balanced (shortages under $20)', `Tills were short ${$(r.staff.shortTotal)}`);
  const over = r.suppliers.filter((s) => s.overBudget > 0).length;
  put(!over, 'Every supplier within budget', `${over} supplier(s) over budget`);
  return { ok, watch };
}

// ---------------------------------------------------------------- Month close tick and the reports hub (PDF / Excel)
export function monthReportItem(ym) {
  const k = actionsKept(ym);
  return { key: 'report', label: 'Monthly business report read and the actions for next month kept', left: k ? 0 : 1, sub: k ? `Kept by ${k.by}` : null, go: 'MonthReport', params: { ym } };
}
const col = (key, title, align = 'left') => ({ key, title, align });
export function monthReportDoc(ym) {
  const r = monthReport(ym, { fresh: true });
  const R = 'right';
  const h = r.headline;
  const sign = (x) => (x === null || x === undefined ? '' : `${x >= 0 ? '+' : ''}${x}%`);
  return {
    kind: 'month_report', title: `Monthly Business Report ${ym}`, fileName: `Monthly-Business-Report-${ym}`, subtitle: `Easy Buys Shopping Centre · ${ym}`,
    info: [['Month', ym], ['Made', r.made]],
    summary: [{ label: 'Sales', value: $(h.sales) }, { label: 'Gross profit (about)', value: $(h.grossProfit) }, { label: 'Wages', value: $(h.wages) }, { label: 'Fuel', value: $(h.fuel) },
      { label: h.vatNet >= 0 ? 'VAT to pay' : 'VAT refund', value: $(Math.abs(h.vatNet)) }, { label: `Forecast ${r.forecast.ym}`, value: $(r.forecast.sales) }],
    sections: [
      { title: 'Things to improve next month', columns: [col('text', 'Do this'), col('why', 'Because'), col('target', 'Target', R)], rows: r.suggestions.map((s) => ({ text: s.text, why: s.why, target: s.target === null ? '' : `${s.unit === '$' ? $(s.target) : s.target}${s.unit === '%' ? '%' : ''}` })) },
      { title: 'Last month\'s actions – did they work?', columns: [col('label', 'Measure'), col('was', 'Was', R), col('now', 'Now', R), col('state', 'Result')], rows: r.followUp.map((a) => ({ label: a.label, was: a.value, now: a.now, state: a.state })) },
      { title: 'Sales by shop', columns: [col('shop', 'Shop'), col('sales', 'Sales', R), col('vat', 'VAT', R), col('days', 'Days', R), col('fc', `Forecast ${r.forecast.ym}`, R)],
        rows: Object.entries(r.fig.byShop).map(([shop, s]) => ({ shop, sales: $(s.sales), vat: $(s.vat), days: s.days, fc: $(r.forecast.byShop[shop] || 0) })) },
      { title: 'VAT and VMS checks', columns: [col('label', 'Check'), col('ok', 'OK'), col('sub', 'Detail')], rows: [{ label: 'Output VAT', ok: '', sub: $(r.vat.output) }, { label: 'Input VAT', ok: '', sub: $(r.vat.input) }, { label: r.vat.net >= 0 ? 'VAT to pay' : 'VAT refund', ok: '', sub: `${$(Math.abs(r.vat.net))} by ${r.vat.due || ''}` }].concat(r.vat.vms.map((v) => ({ label: v.label, ok: v.ok ? '✓' : '✗', sub: v.sub || '' }))) },
      { title: 'Top products', columns: [col('name', 'Product'), col('qty', 'Sold', R), col('value', 'Sales', R), col('profit', 'Profit (about)', R), col('margin', 'Margin', R), col('change', 'vs last month', R)],
        rows: r.products.top.map((p) => ({ name: p.name, qty: p.qty, value: $(p.value), profit: $(p.profit), margin: p.margin === null ? '' : `${p.margin}%`, change: sign(p.change) })) },
      { title: 'Suppliers', columns: [col('name', 'Supplier'), col('spent', 'This month', R), col('avg3', '3-month average', R), col('budget', 'Budget', R), col('suggest', 'Suggested budget', R), col('rises', 'Price rises', R)],
        rows: r.suppliers.slice(0, 25).map((s) => ({ name: s.name, spent: $(s.spent), avg3: $(s.avg3), budget: s.budget === null ? '' : $(s.budget), suggest: s.suggestBudget ? $(s.suggestBudget) : '', rises: s.priceRises || '', _tone: s.overBudget > 0 ? 'warn' : null })) },
      { title: 'Orders coming up (from the order history)', columns: [col('name', 'Supplier'), col('shop', 'Shop'), col('every', 'Every (days)', R), col('usual', 'Usual order', R), col('next', 'Next about'), col('low', 'Low items', R)],
        rows: r.orders.slice(0, 25).map((o) => ({ name: o.name, shop: o.shop, every: o.every || '', usual: $(o.usual), next: o.next || '', low: o.lowItems || '' })) },
      { title: 'Staff', columns: [col('k', 'Item'), col('v', 'Amount', R)], rows: [{ k: 'Wages + employer FNPF', v: $(r.staff.cost) }, { k: 'Wages as % of sales (ex VAT)', v: r.staff.ofSales === null ? '' : `${r.staff.ofSales}%` }, { k: 'People paid', v: r.staff.people }, { k: 'Sales per $1 of wages', v: r.staff.salesPerWageDollar === null ? '' : $(r.staff.salesPerWageDollar) }, { k: 'Till shortages', v: $(r.staff.shortTotal) }]
        .concat(r.staff.byShop.map((w) => ({ k: `Wages ${w.shop}`, v: $(w.cost) }))) },
      { title: 'Fuel', columns: [col('name', 'Vehicle'), col('amount', 'Spent', R), col('litres', 'Litres', R), col('km', 'Km', R), col('kmpl', 'Km per litre', R), col('perKm', 'Per km', R)],
        rows: r.fuel.map((f) => ({ name: f.name || f.item_uid, amount: $(f.amount), litres: f.litres, km: f.km || '', kmpl: f.kmpl || '', perKm: f.perKm === null ? '' : $(f.perKm) })) },
      { title: 'Other costs by kind', columns: [col('cat', 'Kind'), col('total', 'This month', R), col('last', 'Last month', R), col('change', 'Change', R)], rows: r.costs.map((c) => ({ cat: c.cat, total: $(c.total), last: $(c.lastMonth), change: sign(c.change) })) },
      { title: 'Busy hours', columns: [col('label', 'Hour'), col('perDay', 'Per day', R), col('receipts', 'Receipts', R), col('avgSale', 'Average sale', R)], rows: r.time.hours.map((x) => ({ label: x.label, perDay: $(x.perDay), receipts: x.receipts, avgSale: $(x.avgSale) })) },
    ],
  };
}
