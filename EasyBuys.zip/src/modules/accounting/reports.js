// Accounting & VAT reports (PDF / Excel / CSV through the reports hub).
import { stamp } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import * as A from './service.js';

const { $ } = A;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const shops = () => listShops().filter((s) => s.active).map((s) => s.code);
const head = (kind, title, period, extra) => ({ kind, title, fileName: `${title.replace(/\s+/g, '-')}-${period.replace(/\s+/g, '')}`, subtitle: `Easy Buys Shopping Centre · ${period}`,
  info: [['Period', period], ['Generated', stamp()]], ...extra });
const code = (c) => (String(c).startsWith('1100:') ? '1100' : c);

export function vatReport(ym, shop) {
  const v = A.vatReturn({ ym, shop });
  return head('vat', `VAT Return ${shop || 'All shops'}`, ym, {
    info: [['Month', ym], ['Shop', shop || 'All shops'], ['Due to FRCS by', v.due], ['Basis', 'Invoice basis'], ['Generated', stamp()]],
    summary: [{ label: 'Output VAT', value: $(v.sales.output) }, { label: 'Input VAT', value: $(v.purchases.input) }, { label: v.net >= 0 ? 'To pay' : 'Refund', value: $(Math.abs(v.net)), tone: v.net >= 0 ? 'bad' : undefined }],
    sections: [
      { title: 'Return', columns: [col('k', 'Item'), col('v', 'Amount', R)], rows: [
        { k: 'Total sales (incl. VAT)', v: $(v.sales.total) }, { k: 'Zero-rated sales', v: $(v.sales.zeroRated) }, { k: 'Sales excl. VAT', v: $(v.sales.exVat) }, { k: 'Output VAT', v: $(v.sales.output) },
        { k: 'Purchases (incl. VAT)', v: $(v.purchases.total) }, { k: 'Zero-rated purchases', v: $(v.purchases.zeroRated) }, { k: 'Input VAT', v: $(v.purchases.input) },
        { k: v.net >= 0 ? 'VAT payable' : 'VAT refundable', v: $(Math.abs(v.net)) }] },
      { title: 'Sales (from the Z reports)', columns: [col('date', 'Date'), col('shop', 'Shop'), col('ref', 'Till / Z'), col('total', 'Total', R), col('zero', 'Zero-rated', R), col('vat', 'VAT', R)],
        rows: v.saleRows.map((r) => ({ ...r, total: $(r.total), zero: $(r.zero), vat: `${$(r.vat)}${r.typed ? '' : ' *'}` })), note: '* VAT not typed from the Z report – worked out at the standard rate.' },
      { title: 'Purchases (supplier invoices and credit notes)', columns: [col('date', 'Date'), col('shop', 'Shop'), col('supplier', 'Supplier'), col('tin', 'TIN'), col('no', 'Invoice'), col('total', 'Total', R), col('vat', 'VAT', R), col('status', 'Checked')],
        rows: v.purchaseRows.map((r) => ({ ...r, shop: A.areaLabel(r.shop), total: $(r.total), vat: $(r.vat), status: r.status === 'approved' ? '✓' : r.status, _tone: !r.tin && r.vat ? 'warn' : null })) },
    ],
  });
}
export function plReport(from, to) {
  const pl = A.profitLoss({ from, to, shops: shops() });
  const cols = pl.cols.filter((c) => ![A.OFFICE, A.CLOSED].includes(c) || pl.rows.some((r) => r.by[c]));
  const rows = pl.rows.map((r) => ({ name: `${r.code} ${r.name}`, type: A.TYPES[r.type], ...Object.fromEntries(cols.map((c) => [c, r.by[c] ? $(r.by[c]) : ''])), total: $(r.total) }));
  const tot = (label, k) => ({ name: label, type: '', ...Object.fromEntries(cols.map((c) => [c, $(pl.per[c][k])])), total: $(pl.per.total[k]), _tone: k === 'profit' && pl.per.total.profit < 0 ? 'bad' : null });
  return head('pl', 'Profit And Loss', `${from} to ${to}`, {
    summary: [{ label: 'Sales', value: $(pl.per.total.income) }, { label: 'Gross profit', value: $(pl.per.total.gross) }, { label: 'Net profit', value: $(pl.per.total.profit), tone: pl.per.total.profit < 0 ? 'bad' : undefined }],
    sections: [{ title: 'By shop', columns: [col('name', 'Account'), col('type', 'Type')].concat(cols.map((c) => col(c, A.areaLabel(c), R))).concat([col('total', 'Total', R)]),
      rows: rows.concat([tot('Sales & income', 'income'), tot('Cost of goods sold', 'cogs'), tot('Gross profit', 'gross'), tot('Expenses', 'expenses'), tot('NET PROFIT', 'profit')]) }],
  });
}
export function bsReport(date) {
  const bs = A.balanceSheet(date);
  const s = (title, list) => ({ title, columns: [col('code', 'Code'), col('name', 'Account'), col('v', 'Amount', R)], rows: list.map((r) => ({ code: code(r.code), name: r.name, v: $(r.balance) })) });
  return head('bs', 'Balance Sheet', date, { summary: [{ label: 'Assets', value: $(bs.totalAssets) }, { label: 'Liabilities', value: $(bs.totalLiabilities) }, { label: 'Equity', value: $(bs.totalEquity) }],
    sections: [s('What we own (assets)', bs.assets), s('What we owe (liabilities)', bs.liabilities), s("Owner's share (equity)", bs.equity)] });
}
export function tbReport(date) {
  const tb = A.trialBalance(date);
  return head('tb', 'Trial Balance', date, { summary: [{ label: 'Debits', value: $(tb.dr) }, { label: 'Credits', value: $(tb.cr) }],
    sections: [{ title: 'Accounts', columns: [col('code', 'Code'), col('name', 'Account'), col('dr', 'Debit', R), col('cr', 'Credit', R)],
      rows: tb.rows.map((r) => ({ code: code(r.code), name: r.name, dr: r.balance > 0 ? $(r.balance) : '', cr: r.balance < 0 ? $(-r.balance) : '' })) }] });
}

export const REPORTS = [
  { id: 'acc_vat', group: 'Accounting & VAT', icon: '🧾', title: 'VAT return', desc: 'Output and input VAT for a month, with every Z report and invoice', perm: 'accounts_view',
    build(from) { return vatReport(from.slice(0, 7)); } },
  { id: 'acc_pl', group: 'Accounting & VAT', icon: '📈', title: 'Profit & loss by shop', desc: 'Sales, cost of goods, expenses and profit for each shop', perm: 'accounts_view', build: plReport },
  { id: 'acc_bs', group: 'Accounting & VAT', icon: '⚖️', title: 'Balance sheet', desc: 'Assets, liabilities and equity on the last day', perm: 'accounts_view', build(from, to) { return bsReport(to); } },
  { id: 'acc_tb', group: 'Accounting & VAT', icon: '🧮', title: 'Trial balance', desc: 'Every account balance (for the accountant)', perm: 'accounts_view', build(from, to) { return tbReport(to); } },
  { id: 'acc_gl', group: 'Accounting & VAT', icon: '📒', title: 'General ledger', desc: 'Every entry in the books for the period', perm: 'accounts_view',
    build(from, to) {
      const rows = [];
      A.entries({ from, to }).forEach((e) => e.lines.forEach((l) => rows.push({ date: e.date, src: e.src, text: e.text, code: code(l.code), name: A.accountName(l.code), shop: A.areaLabel(l.shop), dr: l.amount > 0 ? $(l.amount) : '', cr: l.amount < 0 ? $(-l.amount) : '' })));
      return head('gl', 'General Ledger', `${from} to ${to}`, { sections: [{ title: 'Entries', columns: [col('date', 'Date'), col('src', 'From'), col('text', 'What'), col('code', 'Acc'), col('name', 'Account'), col('shop', 'Shop'), col('dr', 'Debit', R), col('cr', 'Credit', R)], rows }] });
    } },
  { id: 'acc_assets', group: 'Accounting & VAT', icon: '🚚', title: 'Fixed asset register', desc: 'Equipment and vehicles: cost, depreciation, value now', perm: 'accounts_view',
    build(from, to) {
      const list = A.listAssets(to);
      return head('assets', 'Fixed Asset Register', to, { summary: [{ label: 'Cost', value: $(list.reduce((s, a) => s + a.cost, 0)) }, { label: 'Value now', value: $(list.reduce((s, a) => s + a.bookValue, 0)) }],
        sections: [{ title: 'Assets', columns: [col('name', 'Asset'), col('shop', 'Shop'), col('date', 'Bought'), col('cost', 'Cost', R), col('life', 'Years', R), col('dep', 'Depreciated', R), col('bv', 'Value now', R), col('st', 'Status')],
          rows: list.map((a) => ({ name: a.name, shop: a.shop_code || 'Office', date: a.purchase_date, cost: $(a.cost), life: a.life_years, dep: $(a.depreciated), bv: $(a.bookValue), st: a.status })) }] });
    } },
];
