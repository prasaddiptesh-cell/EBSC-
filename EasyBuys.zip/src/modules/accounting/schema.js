// Accounting: chart of accounts, manual journals, fixed assets, budgets. Everything else is worked out from the other
// modules (sales from the till counts, invoices, payments, deposits, petty cash, payroll…), so the books always match them.
export const ACCOUNTING_SQL = `
CREATE TABLE IF NOT EXISTS gl_accounts (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  grp TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  system INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS gl_journals (
  uid TEXT PRIMARY KEY,
  jdate TEXT NOT NULL,
  memo TEXT NOT NULL,
  lines TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'manual',
  status TEXT NOT NULL DEFAULT 'active',
  by_name TEXT, created_at TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS fixed_assets (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  shop_code TEXT,
  purchase_date TEXT NOT NULL,
  cost REAL NOT NULL,
  life_years REAL NOT NULL,
  salvage REAL NOT NULL DEFAULT 0,
  serial TEXT,
  disposed_date TEXT,
  disposed_amount REAL,
  photo_urls TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS gl_budgets (
  uid TEXT PRIMARY KEY,
  ym TEXT NOT NULL,
  shop_code TEXT NOT NULL,
  code TEXT NOT NULL,
  amount REAL NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const ACCOUNTING_SYNC = {
  gl_accounts: SYNC('code', 'Accounting', ['code', 'name', 'type', 'grp', 'active', 'system', 'note']),
  gl_journals: SYNC('uid', 'Accounting', ['uid', 'jdate', 'memo', 'lines', 'kind', 'status', 'by_name', 'created_at', 'void_reason']),
  fixed_assets: SYNC('uid', 'Accounting', ['uid', 'name', 'category', 'shop_code', 'purchase_date', 'cost', 'life_years', 'salvage', 'serial', 'disposed_date', 'disposed_amount', 'photo_urls', 'notes', 'status']),
  gl_budgets: SYNC('uid', 'Accounting', ['uid', 'ym', 'shop_code', 'code', 'amount']),
};
