// Accounting & VAT screens. Written for people who are not accountants: every screen says what it is for.
import React, { useState, useEffect } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, Table, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, Action, Actions, ReasonButton, ReasonField, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { periodLabel, rangeProblem } from '../../../services/dates.js';
import { dateStr, addDays, money } from '../../../services/core.js';
import { lockDate } from '../../../services/lock.js';
import { shareReport } from '../../../platform/files.js';
import { listShops } from '../../admin/service.js';
import { CLOSED_OPTION } from '../../../services/costAreas.js';
import { apRules } from '../../payables/service.js';
import { tillRules } from '../../till/service.js';
import * as A from '../service.js';
import * as F from '../full.js';
import { vatReport, plReport, bsReport, tbReport } from '../reports.js';

const { $ } = A;
const shops = () => listShops().filter((s) => s.active).map((s) => s.code);
const ymNow = () => dateStr().slice(0, 7);
const prevYm = (ym) => { const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)); return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`; };
const nextYm = (ym) => { const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; };
const monthEnd = (ym) => addDays(`${nextYm(ym)}-01`, -1);
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;

function MonthPicker({ value, onChange, testID }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <Btn testID={testID ? `${testID}-prev` : undefined} title="‹" size="sm" variant="secondary" onPress={() => onChange(prevYm(value))} />
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, minWidth: 110, textAlign: 'center' }}>{ymLabel(value)}</Text>
      <Btn testID={testID ? `${testID}-next` : undefined} title="›" size="sm" variant="secondary" onPress={() => onChange(nextYm(value))} />
    </View>
  );
}
const share = (ui, rep) => shareReport(rep, 'pdf').catch((e) => ui.error(e));
const shareX = (ui, rep) => shareReport(rep, 'xlsx').catch((e) => ui.error(e));

// ---------------------------------------------------------------- home
export function AccountingHomeScreen() {
  const { nav, can, user } = useApp();
  // Repeating journals that have come due are made when Accounting is opened.
  useEffect(() => { try { if (can('accounts_journal')) F.runRecurring(user); } catch (e) { /* tried again next time */ } }, []);
  let alerts = [];
  try { alerts = F.accountingAlerts(); } catch (e) { alerts = []; }
  const waiting = F.listBatches({ status: 'to_check' }).length;
  const ym = ymNow();
  const pl = A.profitLoss({ from: `${ym}-01`, to: dateStr(), shops: shops() });
  const v = A.vatReturn({ ym: prevYm(ym) });
  const lock = lockDate();
  return (
    <Screen title="Accounting & VAT" subtitle={`Financial year January–December · ${lock ? `closed up to ${lock}` : 'no month closed yet'}`}>
      <Explain title="How the books work here">
        You do not type anything twice. The books are built from what is already in the app: sales and VAT from the till counts (Z reports), supplier invoices and payments,
        bank deposits, petty cash, wages, FNPF and PAYE, staff advances, stock on hand, the equipment list and loans. If something is wrong in the books, fix it where it was entered
        (e.g. the invoice) and the books follow. Anything else (a receipt paid at the counter, a bulk sale, the owner's money) is typed in "Type a sale, expense or other money".
        Figures from Aronium are checked by a person before they reach the books.
      </Explain>
      <Stats items={[
        { label: `Sales this month (excl. VAT)`, value: $(pl.per.total.income) },
        { label: 'Gross profit', value: $(pl.per.total.gross), sub: pl.per.total.margin !== null ? `${pl.per.total.margin}% of sales` : '' },
        { label: 'Profit so far this month', value: $(pl.per.total.profit), color: pl.per.total.profit < 0 ? C.danger : C.success },
        { label: `VAT for ${ymLabel(prevYm(ym))}`, value: $(v.net), sub: `${v.net >= 0 ? 'to pay' : 'refund'} by ${v.due}`, onPress: () => nav.push('VatReturn', { ym: prevYm(ym) }) },
      ]} />
      {alerts.map((a) => <Banner key={a.key} tone={a.tone} message={a.text} />)}
      <Section title="Daily tasks">
        <Actions>
          {can('accounts_journal') ? <Action testID="acc-entry" icon="✍️" title="Type a sale, expense or other money" note="Anything not entered in another part of the app – a receipt paid at the counter, a bulk sale, the owner's money, moving money between cash and bank." onPress={() => nav.push('AcctEntry', {})} /> : null}
          <Action testID="acc-aronium" icon="📥" title="Aronium figures to check" badge={waiting || null} note="Sales and paid-outs brought in from Aronium wait here until someone checks and approves them." onPress={() => nav.push('AroniumInbox', {})} />
        </Actions>
      </Section>
      <Section title="Records">
        <Actions>
          <Action testID="acc-entries" icon="🗒️" title="Typed entries" note="Every sale, expense and transfer typed into the books." onPress={() => nav.push('AcctEntries', {})} />
          {can('ap_setup') || can('payments_make') ? <Action testID="acc-loans" icon="🏦" title="Loans" note="Each loan's balance, repayments (with the bill numbers), interest and fees – kept in Invoices & cheques › Regular bills & loans. Each loan has its own account in the books." onPress={() => nav.push('Recurring', {})} /> : null}
          <Action testID="acc-assets" icon="🚚" title="Equipment & vehicles (fixed assets)" note="What it cost, how much it has worn out (depreciation), what it is worth now." onPress={() => nav.push('Assets', {})} />
          <Action testID="acc-recurring" icon="🔁" title="Repeating journals, prepayments & accruals" note="Monthly entries made by themselves; costs paid in advance spread over months; costs owing at month end." onPress={() => nav.push('RepeatJournals', {})} />
          {can('accounts_journal') ? <Action testID="acc-journal" icon="📝" title="Journals" note="For the accountant: any correction between accounts." onPress={() => nav.push('Journals', {})} /> : null}
        </Actions>
      </Section>
      <Section title="Tax">
        <Actions>
          <Action testID="acc-vat" icon="🧾" title="VAT return" note="Output VAT on sales less input VAT on purchases, per shop and in total, ready for the FRCS monthly return." onPress={() => nav.push('VatReturn', {})} />
          <Action testID="acc-tax" icon="🏛️" title="Tax centre" note="VAT payments, provisional tax kept back from contractors, company advance tax – with due dates." onPress={() => nav.push('TaxCentre', {})} />
        </Actions>
      </Section>
      <Section title="Reports">
        <Actions>
          <Action testID="acc-pl" icon="📈" title="Profit & loss" note="Sales, cost of goods and expenses for any period – each shop side by side." onPress={() => nav.push('ProfitLoss', {})} />
          <Action testID="acc-bs" icon="⚖️" title="Balance sheet" note="What the business owns and owes on a date, and the owner's share." onPress={() => nav.push('BalanceSheet', {})} />
          <Action testID="acc-cashbook" icon="💵" title="Cash book" note="Money in and out of each shop's cash and each bank account, with the running balance." onPress={() => nav.push('CashBook', {})} />
          <Action testID="acc-forecast" icon="🔮" title="Cash flow forecast" note="Cash expected week by week for the next 13 weeks." onPress={() => nav.push('Forecast', {})} />
          <Action testID="acc-budget" icon="🎯" title="Budget against actual" note="Set what each shop should spend; see where it went over." onPress={() => nav.push('Budgets', {})} />
          <Action testID="acc-tb" icon="🧮" title="Trial balance" note="Every account's balance. Debits always equal credits – the accountant's check." onPress={() => nav.push('TrialBalance', {})} />
          <Action testID="acc-gl" icon="📒" title="Account history (ledger)" note="Every amount that went into one account, with where it came from." onPress={() => nav.push('Ledger', {})} />
        </Actions>
      </Section>
      <Section title="Period end">
        <Actions>
          <Action testID="acc-month" icon="✅" title="Month end & closing" note="A checklist of what must be done before a month is closed, then lock it so nothing in it can change." onPress={() => nav.push('MonthEnd', {})} />
          <Action testID="acc-year" icon="🏛️" title="Year end & financial statements" note="IFRS for SMEs statements, the accountant pack (Excel) and closing the year." onPress={() => nav.push('YearEndAcct', {})} />
        </Actions>
      </Section>
      {can('accounts_setup') ? (
        <Section title="Setup">
          <Actions>
            <Action testID="acc-opening" icon="🏁" title="Opening balances" note="The balances on the day the app's books start (from the accountant's last balance sheet)." onPress={() => nav.push('OpeningBalances', {})} />
            <Action testID="acc-coa" icon="🗂️" title="Accounts & where things go" note="The chart of accounts, and which account each invoice category, petty cash type and till payment goes to." onPress={() => nav.push('ChartOfAccounts', {})} />
            <Action testID="acc-settings" icon="⚙️" title="Accounting settings" note="Start date, tax year, advance tax, provisional tax." onPress={() => nav.push('AcctSettings', {})} />
          </Actions>
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- VAT return
export function VatReturnScreen({ params }) {
  const ui = useUI();
  const [ym, setYm] = useState(params.ym || prevYm(ymNow()));
  const [shop, setShop] = useRemembered('shop', '');
  const v = A.vatReturn({ ym, shop: shop || undefined });
  const per = shops().map((s) => ({ s, v: A.vatReturn({ ym, shop: s }) }));
  return (
    <Screen title="VAT return" subtitle={`${ymLabel(ym)} · due to FRCS by ${v.due}`}>
      <MonthPicker value={ym} onChange={setYm} testID="vat-m" />
      <Chips value={shop} onChange={setShop} testIDPrefix="vat-shop" options={[{ value: '', label: 'All shops' }].concat(shops().map((s) => ({ value: s, label: s })))} />
      <Explain>
        Output VAT is the VAT included in your sales (from the Z reports typed at the till counts). Input VAT is the VAT on supplier invoices dated in the month.
        You pay FRCS the difference. If input is bigger, FRCS owes you a refund. Easy Buys is on the invoice basis: invoices count in the month of their date, paid or not.
      </Explain>
      <Card>
        <H>Sales (output)</H>
        <Row label="Total sales incl. VAT" value={$(v.sales.total)} />
        <Row label="Zero-rated sales" value={$(v.sales.zeroRated)} />
        <Row label="Sales excl. VAT" value={$(v.sales.exVat)} />
        <Row label="Output VAT" value={$(v.sales.output)} bold />
        <H>Purchases (input)</H>
        <Row label="Purchases incl. VAT" value={$(v.purchases.total)} />
        <Row label="Zero-rated purchases" value={$(v.purchases.zeroRated)} />
        <Row label="Input VAT" value={$(v.purchases.input)} bold />
        <Row label={v.net >= 0 ? 'VAT to pay FRCS' : 'VAT refund due'} value={$(Math.abs(v.net))} bold color={v.net >= 0 ? C.danger : C.success} />
      </Card>
      {v.purchases.toCheck ? <Banner tone="warn" message={`${v.purchases.toCheck} invoice(s) in this month are not checked yet – check them before filing.`} /> : null}
      {v.purchases.noTin ? <Banner tone="warn" message={`${v.purchases.noTin} invoice(s) with VAT have no supplier TIN – FRCS may not allow that VAT.`} /> : null}
      {v.saleRows.some((r) => !r.typed) ? <Hint>Some Z reports had no VAT typed in; their VAT was worked out at {apRules().vatRate}%.</Hint> : null}
      {!shop ? (
        <Section title="Per shop">
          <Table columns={[{ key: 's', title: 'Shop', width: 90 }, { key: 'o', title: 'Output', align: 'right' }, { key: 'i', title: 'Input', align: 'right' }, { key: 'n', title: 'Net', align: 'right' }]}
            rows={per.map(({ s, v: x }) => ({ s, o: $(x.sales.output), i: $(x.purchases.input), n: $(x.net) })).concat([{ s: 'Office', o: '', i: $(A.vatReturn({ ym, shop: A.OFFICE }).purchases.input), n: '' }])} />
          <Hint>"Office" = invoices not marked for a shop.</Hint>
        </Section>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="vat-pdf" title="PDF (with every invoice)" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => share(ui, vatReport(ym, shop || undefined))} />
        <Btn title="Excel" icon="📊" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => shareX(ui, vatReport(ym, shop || undefined))} />
      </View>
    </Screen>
  );
}

// ---------------------------------------------------------------- P&L
export function ProfitLossScreen() {
  const ui = useUI();
  const [from0, to0, setRange] = usePeriod('thismonth');
  const bad = rangeProblem(from0, to0);
  const from = bad ? `${ymNow()}-01` : from0;
  const to = bad ? monthEnd(ymNow()) : to0;
  const pl = A.profitLoss({ from, to, shops: shops() });
  const cols = pl.cols.filter((c) => ![A.OFFICE, A.CLOSED].includes(c) || pl.rows.some((r) => r.by[c]));
  const line = (label, k, bold) => ({ name: label, ...Object.fromEntries(cols.map((c) => [c, $(pl.per[c][k])])), total: $(pl.per.total[k]), _bold: bold });
  const rows = [];
  for (const [type, label] of [['income', 'Sales & income'], ['cogs', 'Cost of goods sold'], ['expense', 'Expenses']]) {
    rows.push({ name: label.toUpperCase() });
    pl.rows.filter((r) => r.type === type).forEach((r) => rows.push({ name: `${r.code} ${r.name}`, ...Object.fromEntries(cols.map((c) => [c, r.by[c] ? $(r.by[c]) : ''])), total: $(r.total) }));
    if (type === 'cogs') rows.push(line('GROSS PROFIT', 'gross', true));
  }
  rows.push(line('NET PROFIT', 'profit', true));
  return (
    <Screen title="Profit & loss" subtitle={periodLabel(from, to)}>
      <PeriodPicker testID="pl-period" from={from0} to={to0} onChange={setRange} />
      <Hint>Sales are excl. VAT. "Change in stock" corrects purchases for stock still on the shelf, so the cost of goods matches what was sold.</Hint>
      <Stats items={cols.map((c) => ({ label: A.areaLabel(c), value: $(pl.per[c].profit), sub: `sales ${$(pl.per[c].income)}`, color: pl.per[c].profit < 0 ? C.danger : undefined }))} />
      <Table testID="pl-table" columns={[{ key: 'name', title: 'Account', width: 260 }].concat(cols.map((c) => ({ key: c, title: A.areaLabel(c), align: 'right' }))).concat([{ key: 'total', title: 'Total', align: 'right', bold: true }])} rows={rows} />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Btn title="PDF" icon="📄" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => share(ui, plReport(from, to))} />
        <Btn title="Excel" icon="📊" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => shareX(ui, plReport(from, to))} />
      </View>
    </Screen>
  );
}

// ---------------------------------------------------------------- balance sheet / trial balance / ledger
export function BalanceSheetScreen() {
  const ui = useUI();
  const [date, setDate] = useState(dateStr());
  const bs = A.balanceSheet(date);
  const sec = (title, list, total) => (
    <Section title={`${title} · ${$(total)}`}>
      {list.map((r) => <Row key={r.code + r.name} label={`${r.code === '—' ? '' : `${r.code.startsWith('1100:') ? '1100' : r.code} `}${r.name}`} value={$(r.balance)} />)}
    </Section>
  );
  return (
    <Screen title="Balance sheet" subtitle={`As at ${date}`}>
      <DateField farDays={false} label="As at" value={date} onChange={setDate} />
      <Hint>What the business owns (assets) = what it owes (liabilities) + the owner's share (equity).</Hint>
      {!bs.ok ? <Banner tone="danger" message="The balance sheet does not balance – tell the admin (something was booked to an account of the wrong type)." /> : null}
      {sec('What we own', bs.assets, bs.totalAssets)}
      {sec('What we owe', bs.liabilities, bs.totalLiabilities)}
      {sec('Owner\'s share', bs.equity, bs.totalEquity)}
      <Btn title="PDF" icon="📄" size="md" variant="secondary" onPress={() => share(ui, bsReport(date))} />
    </Screen>
  );
}
export function TrialBalanceScreen() {
  const ui = useUI();
  const { nav } = useApp();
  const [date, setDate] = useState(dateStr());
  const tb = A.trialBalance(date);
  return (
    <Screen title="Trial balance" subtitle={`As at ${date}`}>
      <DateField farDays={false} label="As at" value={date} onChange={setDate} />
      <Banner tone={tb.ok ? 'success' : 'danger'} message={tb.ok ? `Debits ${$(tb.dr)} = credits ${$(tb.cr)} ✓` : `Debits ${$(tb.dr)} ≠ credits ${$(tb.cr)}`} />
      {tb.rows.map((r) => <ListItem key={r.code} title={`${r.code.startsWith('1100:') ? '1100' : r.code} ${r.name}`} sub={A.TYPES[r.type]} right={r.balance > 0 ? `${$(r.balance)} Dr` : `${$(-r.balance)} Cr`}
        onPress={() => nav.push('Ledger', { code: r.code })} tone={r.code === '2900' ? 'warn' : undefined} />)}
      <Btn title="PDF" icon="📄" size="md" variant="secondary" onPress={() => share(ui, tbReport(date))} />
    </Screen>
  );
}
export function LedgerScreen({ params }) {
  const [code, setCode] = useState(params.code || '1000');
  const [from0, to0, setRange] = usePeriod('thismonth');
  const [shop, setShop] = useRemembered('shop', '');
  const okRange = !rangeProblem(from0, to0);
  const l = A.ledgerFor(code, { from: okRange ? from0 : `${ymNow()}-01`, to: okRange ? to0 : monthEnd(ymNow()), shop: shop || undefined });
  return (
    <Screen title="Account history" subtitle={A.accountName(code)}>
      <Select label="Account" value={code} onChange={setCode} options={A.listAccountsGL().map((a) => ({ value: a.code, label: `${a.code.startsWith('1100:') ? '1100' : a.code} ${a.name}` }))} />
      <PeriodPicker testID="led-period" from={from0} to={to0} onChange={setRange} />
      <Chips value={shop} onChange={setShop} options={[{ value: '', label: 'All' }].concat(shops().map((s) => ({ value: s, label: s }))).concat([{ value: A.OFFICE, label: 'Office' }])} />
      <Row label="Opening balance" value={$(l.opening)} />
      {l.lines.map((x, i) => <ListItem key={i} title={`${x.src}: ${x.text}`} sub={`${x.date} · ${A.areaLabel(x.shop)}`} right={x.debit ? `+${$(x.debit)}` : `−${$(x.credit)}`} rightSub={`bal ${$(x.balance)}`} />)}
      <Row label="Closing balance" value={$(l.closing)} bold />
    </Screen>
  );
}

// ---------------------------------------------------------------- journals
export function JournalsScreen() {
  const { user } = useApp();
  const act = useAct();
  const accts = A.listAccountsGL();
  const blank = () => ({ code: '', debit: '', credit: '', shop: A.OFFICE });
  const [f, setF] = useState(null);
  const list = A.listJournals();
  const dr = f ? f.lines.reduce((s, l) => s + (Number(l.debit) || 0), 0) : 0;
  const cr = f ? f.lines.reduce((s, l) => s + (Number(l.credit) || 0), 0) : 0;
  return (
    <Screen title="Journals" subtitle="Entries not made anywhere else">
      <Explain>
        A journal moves an amount between accounts. Every journal has debits and credits that are equal. Examples:{'\n'}
        • Opening balances on day one: debit the bank and stock, credit "Owner's capital & opening balances".{'\n'}
        • Owner takes money: debit "Owner's money in / drawings", credit the bank.{'\n'}
        • A loan received: debit the bank, credit "Loans".{'\n'}
        If unsure, ask your accountant – everything else is booked by itself.
      </Explain>
      {f ? (
        <Card>
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field testID="jn-memo" label="What is it for?" value={f.memo} onChangeText={(v) => setF({ ...f, memo: v })} />
          {f.lines.map((l, i) => (
            <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <View style={{ flexBasis: 260, flexGrow: 2 }}><Select testID={`jn-acc-${i}`} label="Account" value={l.code} onChange={(v) => setF({ ...f, lines: f.lines.map((x, k) => (k === i ? { ...x, code: v } : x)) })} options={accts.map((a) => ({ value: a.code, label: `${a.code.startsWith('1100:') ? '1100' : a.code} ${a.name}` }))} /></View>
              <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID={`jn-dr-${i}`} label="Debit" value={l.debit} onChange={(v) => setF({ ...f, lines: f.lines.map((x, k) => (k === i ? { ...x, debit: v } : x)) })} /></View>
              <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID={`jn-cr-${i}`} label="Credit" value={l.credit} onChange={(v) => setF({ ...f, lines: f.lines.map((x, k) => (k === i ? { ...x, credit: v } : x)) })} /></View>
              <View style={{ flexBasis: 120, flexGrow: 1 }}><Select label="Shop" value={l.shop} onChange={(v) => setF({ ...f, lines: f.lines.map((x, k) => (k === i ? { ...x, shop: v } : x)) })} options={[{ value: A.OFFICE, label: 'Office' }].concat(shops().map((s) => ({ value: s, label: s }))).concat([CLOSED_OPTION])} /></View>
            </View>
          ))}
          <Btn title="+ line" size="sm" variant="secondary" onPress={() => setF({ ...f, lines: f.lines.concat([blank()]) })} />
          <Row label="Debits / credits" value={`${$(dr)} / ${$(cr)}`} color={Math.abs(dr - cr) < 0.005 ? C.success : C.danger} bold />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="jn-save" title="Save journal" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => A.saveJournal(user, f), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="jn-new" title="New journal" icon="✍️" variant="info" onPress={() => setF({ date: dateStr(), memo: '', lines: [blank(), blank()] })} />}
      {list.map((j) => (
        <Card key={j.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: j.status === 'void' ? C.sub : C.text }}>{j.jdate} · {j.memo}{j.status === 'void' ? ' (VOID)' : ''}</Text>
          {j.lines.map((l, i) => <Text key={i} style={{ fontSize: 15, color: C.sub }}>{A.accountName(l.code)}: {l.debit ? `Dr ${$(l.debit)}` : `Cr ${$(l.credit)}`}{l.shop && l.shop !== A.OFFICE ? ` · ${l.shop}` : ''}</Text>)}
          <Text style={{ fontSize: 13, color: C.sub }}>by {j.by_name}</Text>
          {j.status === 'active' ? <ReasonButton title="Void" prompt="Why?" confirm="Void journal" onDo={(w) => act(() => A.voidJournal(user, j.uid, w), 'Voided')} /> : null}
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- chart of accounts and mapping
export function ChartOfAccountsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState(null);
  const [m, setM] = useState(A.glMap());
  const accts = A.listAccountsGL({ includeInactive: true });
  const opts = A.listAccountsGL().filter((a) => !a.code.startsWith('1100:')).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }));
  const mapRows = (k, names) => names.map((n) => (
    <Select key={`${k}-${n}`} label={n} value={m[k][n] || m[k].Other || m[k].default || ''} onChange={(v) => setM({ ...m, [k]: { ...m[k], [n]: v } })} options={opts} />
  ));
  return (
    <Screen title="Accounts & where things go" subtitle="Admin">
      <Section title="Where things are booked">
        <Hint>Each invoice category, petty cash type and till payment goes to an account. Change these only with your accountant.</Hint>
        <Label>Supplier invoice categories</Label>
        {mapRows('ap', Array.from(new Set(apRules().categories.concat(['Equipment', 'Loan repayment']))))}
        <Label>Petty cash</Label>
        {mapRows('petty', tillRules().pettyCategories)}
        <Label>Till: other ways customers paid</Label>
        {mapRows('tenders', tillRules().tenders)}
        <Label>Till: paid out of the till</Label>
        {mapRows('payouts', tillRules().payoutTypes)}
        <Btn testID="coa-map-save" title="Save" size="md" variant="success" onPress={() => act(() => A.saveGlMap(user, m), 'Saved')} />
      </Section>
      <Section title="Accounts">
        {f ? (
          <Card>
            <Field testID="coa-code" label="Code (numbers)" value={f.code} onChangeText={(v) => setF({ ...f, code: v })} />
            <Field testID="coa-name" label="Name" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} />
            <Choice value={f.type} onChange={(v) => setF({ ...f, type: v })} options={Object.entries(A.TYPES).map(([value, label]) => ({ value, label }))} />
            <Field label="Group (optional)" value={f.grp} onChangeText={(v) => setF({ ...f, grp: v })} />
            <Chips value={f.active ? 'y' : 'n'} onChange={(v) => setF({ ...f, active: v === 'y' })} options={[{ value: 'y', label: 'In use' }, { value: 'n', label: 'Not used' }]} />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
              <Btn testID="coa-save" title="Save" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => A.saveAccountGL(user, f), 'Saved')) setF(null); }} />
            </View>
          </Card>
        ) : <Btn testID="coa-add" title="Add an account" size="md" variant="info" onPress={() => setF({ code: '', name: '', type: 'expense', grp: '', active: true })} />}
        {accts.map((a) => <ListItem key={a.code} title={`${a.code.startsWith('1100:') ? '1100' : a.code} ${a.name}`} sub={`${A.TYPES[a.type]}${a.grp ? ` · ${a.grp}` : ''}${a.active ? '' : ' · not used'}`}
          onPress={a.code.startsWith('1100:') ? null : () => setF({ code: a.code, name: a.name, type: a.type, grp: a.grp || '', active: !!a.active })} />)}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- assets
export function AssetsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState(null);
  const list = A.listAssets();
  return (
    <Screen title="Equipment & vehicles" subtitle={`${list.length} items · worth ${$(list.filter((a) => a.status === 'active').reduce((s, a) => s + a.bookValue, 0))} now`}>
      <Explain>Things the business keeps for years (chillers, ovens, vehicles, shelving) are not an expense all at once: their cost is spread over the years they last ("depreciation"). Add each one here with what it cost and how long it will last.</Explain>
      {f ? (
        <Card>
          <Field testID="as-name" label="What is it?" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} placeholder="e.g. Chiller – S1" />
          <Select label="Shop" value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} options={[{ value: '', label: 'Office / all' }].concat(shops().map((s) => ({ value: s, label: s })))} />
          <DateField farDays={false} label="Bought on" value={f.purchaseDate} onChange={(v) => setF({ ...f, purchaseDate: v })} />
          <MoneyField testID="as-cost" label="Cost (excl. VAT)" value={f.cost} onChange={(v) => setF({ ...f, cost: v })} />
          <Field testID="as-life" label="Lasts how many years?" value={f.lifeYears} onChangeText={(v) => setF({ ...f, lifeYears: v })} keyboardType="decimal-pad" />
          <MoneyField label="Worth at the end (scrap value)" value={f.salvage} onChange={(v) => setF({ ...f, salvage: v })} />
          <Field label="Serial / registration no." value={f.serial} onChangeText={(v) => setF({ ...f, serial: v })} />
          <Chips value={f.viaInvoice ? 'y' : 'n'} onChange={(v) => setF({ ...f, viaInvoice: v === 'y' })} options={[{ value: 'y', label: 'Its invoice is in Invoices (category Equipment)' }, { value: 'n', label: 'Bought before / not entered as an invoice' }]} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="as-save" title="Save" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => A.saveAsset(user, f), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="as-add" title="Add equipment / vehicle" icon="➕" variant="info" onPress={() => setF({ name: '', shopCode: '', purchaseDate: dateStr(), cost: '', lifeYears: '5', salvage: '', serial: '', viaInvoice: false })} />}
      {list.map((a) => (
        <View key={a.uid} style={{ gap: 6 }}>
          <ListItem title={a.name} sub={`${a.shop_code || 'Office'} · bought ${a.purchase_date} for ${$(a.cost)} · ${a.life_years} years${a.status === 'disposed' ? ` · gone ${a.disposed_date}` : ''}`} right={$(a.bookValue)} rightSub={`worn ${$(a.depreciated)}`} />
          {a.status === 'active' ? <ReasonButton title="Sold / thrown out" prompt="What happened (and for how much)?" confirm="Record" variant="warn" onDo={(w) => act(() => A.disposeAsset(user, a.uid, { date: dateStr(), amount: Number((w.match(/[\d.]+/) || [0])[0]) || 0, reason: w }), 'Recorded')} /> : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- budgets
export function BudgetsScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const [ym, setYm] = useState(ymNow());
  const [shop, setShop] = useState(shops()[0] || A.OFFICE);
  const [code, setCode] = useState('6500');
  const [amt, setAmt] = useState('');
  const rows = A.budgetVsActual({ ym, shopCode: shop });
  return (
    <Screen title="Budget against actual" subtitle={`${shop === A.OFFICE ? 'Office' : shop} · ${ymLabel(ym)}`}>
      <MonthPicker value={ym} onChange={setYm} />
      <Chips value={shop} onChange={setShop} options={shops().map((s) => ({ value: s, label: s })).concat([{ value: A.OFFICE, label: 'Office' }])} />
      {can('accounts_setup') ? (
        <Card>
          <Select label="Account" value={code} onChange={setCode} options={A.listAccountsGL().filter((a) => ['income', 'cogs', 'expense'].includes(a.type)).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }))} />
          <MoneyField testID="bd-amt" label="Budget for the month" value={amt} onChange={setAmt} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="This month" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => act(() => A.saveBudget(user, { ym, shopCode: shop, code, amount: amt }), 'Saved')} />
            <Btn title={`Every month of ${ym.slice(0, 4)}`} size="md" variant="success" style={{ flex: 1 }} onPress={() => act(() => A.saveBudget(user, { ym, shopCode: shop, code, amount: amt, allYear: true }), 'Saved for the year')} />
          </View>
        </Card>
      ) : null}
      {rows.map((r) => (
        <ListItem key={r.code} title={`${r.code} ${r.name}`} sub={`budget ${$(r.budget)} · actual ${$(r.actual)}`} right={r.budget ? `${r.diff > 0 ? '+' : ''}${$(r.diff)}` : ''}
          tone={r.budget && ((r.type === 'income' && r.diff < 0) || (r.type !== 'income' && r.diff > 0)) ? 'warn' : undefined} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- month end
export function MonthEndScreen({ params = {} }) {
  const { user, can, nav } = useApp();
  const act = useAct();
  const [ym, setYm] = useState(params.ym || prevYm(ymNow()));
  const [why, setWhy] = useState('');
  const boss = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const c = A.monthEndChecklist(ym);
  const lock = lockDate();
  const closed = lock && lock >= c.to;
  return (
    <Screen title="Month end & closing" subtitle={`${ymLabel(ym)}${closed ? ' · CLOSED' : ''}`}>
      <MonthPicker value={ym} onChange={setYm} testID="me-m" />
      <Explain>Before a month is closed everything in it should be entered and checked. Closing ("locking") a month means nothing dated in it can be added, changed or voided – so the VAT return you filed and the books stay the same. Only the owner can reopen it.</Explain>
      {(() => {
        // v3.9.8 the year: one tile a month (closed / in progress), with sales, costs and profit.
        let yr = [];
        try { yr = A.closeYear(ym.slice(0, 4)); } catch (e) { yr = []; }
        return (
          <Section title={`${ym.slice(0, 4)} – month by month`}>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {yr.map((m) => (
                <Pressable key={m.ym} testID={`me-y-${m.ym}`} onPress={() => setYm(m.ym)} style={{ flexBasis: 100, flexGrow: 1, padding: 8, borderRadius: 10, borderWidth: m.ym === ym ? 2 : 1, borderColor: m.ym === ym ? C.primary : C.border, backgroundColor: m.closed ? '#E8F5EC' : C.card }}>
                  <Text style={{ fontSize: 14, fontWeight: '800', color: C.text }}>{`${m.closed ? '✅' : m.done ? '⏳' : '⬜'} ${ymLabel(m.ym)}`}</Text>
                  <Text style={{ fontSize: 12, color: C.sub }}>{m.closed ? 'Closed' : `${m.done}/${m.total}`}</Text>
                  {m.sales || m.costs ? <Text style={{ fontSize: 12, color: m.profit < 0 ? C.danger : C.text }}>{`Profit ${money(m.profit)}`}</Text> : null}
                </Pressable>
              ))}
            </View>
          </Section>
        );
      })()}
      <Section title="Checked by the app">
        {c.auto.map((a) => <ListItem key={a.key} testID={`me-a-${a.key}`} title={`${a.done ? '✅' : '⬜'} ${a.label}`} sub={a.done ? 'Done' : `${a.sub || `${a.left} still to do`}`} tone={a.done ? 'success' : 'warn'} onPress={a.go && (!a.done || a.key === 'report') ? () => nav.push(a.go, a.params || {}) : undefined} />)}
      </Section>
      <Section title="Tick when done">
        {c.manual.map((m) => <ListItem key={m.key} testID={`me-${m.key}`} title={`${m.done ? '✅' : '⬜'} ${m.label}`} sub={m.by ? `by ${m.by}` : 'tap to tick'} onPress={() => act(() => A.tickMonthEnd(user, ym, m.key, !m.done))} />)}
      </Section>
      {boss ? (
        closed ? (
          <ReasonButton testID="me-reopen" title={`Reopen ${ymLabel(ym)}`} prompt="Why reopen?" confirm="Reopen" variant="warn" onDo={(w) => act(() => A.reopenMonth(user, ym, w), 'Reopened – correct it, then close it again')} />
        ) : (
          <>
            {!c.ready ? <ReasonField testID="me-why" label="Not everything is reconciled – why close it now?" value={why} onChangeText={setWhy} /> : <Hint>Everything is reconciled. Closing locks the month: nothing dated in it can change unless it is reopened with a reason.</Hint>}
            <Btn testID="me-close" title={`Close ${ymLabel(ym)}`} icon="🔒" variant={c.ready ? 'success' : 'warn'} onPress={() => act(() => A.closeMonth(user, ym, { reason: why }), `${ymLabel(ym)} closed`)} />
          </>
        )
      ) : can('accounts_close') ? (
        closed ? (
          <ReasonButton title={`Reopen ${ymLabel(ym)} (owner)`} prompt="Why reopen?" confirm="Reopen" variant="warn" onDo={(w) => act(() => A.setLock(user, addDays(`${ym}-01`, -1), { reopen: user.role === 'owner', reason: w }), 'Reopened')} />
        ) : (
          <>
            {!c.ready ? <Hint>Not everything is done yet. You can still close, but it is better to finish the list first.</Hint> : null}
            <Btn testID="me-close" title={`Close ${ymLabel(ym)}`} icon="🔒" variant={c.ready ? 'success' : 'warn'} onPress={() => act(() => A.setLock(user, c.to), `Closed up to ${c.to}`)} />
          </>
        )
      ) : null}
    </Screen>
  );
}
