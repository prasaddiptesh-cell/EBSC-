// Accounting 3.4 screens: typed entries, Aronium figures to check, loans, repeating journals, tax centre,
// opening balances, year end, financial statements, forecast, accountant pack, cash book, settings.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, Table, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { shareReport } from '../../../platform/files.js';
import { pickTextFile } from '../../../platform/files.js';
import { listShops } from '../../admin/service.js';
import { CLOSED_OPTION } from '../../../services/costAreas.js';
import * as A from '../service.js';
import * as F from '../full.js';
import * as S from '../statements.js';
import { snapshotNow } from '../../../services/snapshots.js';

const { $, OFFICE } = A;
const shopList = () => listShops().filter((s) => s.active);
const shopOpts = () => shopList().map((s) => ({ value: s.code, label: s.name }));
const acctOpts = (types) => A.listAccountsGL().filter((a) => !types || types.includes(a.type)).filter((a) => !a.code.includes(':')).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }));
const allAcctOpts = () => A.listAccountsGL().map((a) => ({ value: a.code, label: `${a.code.includes(':') ? a.code.slice(0, 4) : a.code} ${a.name}` }));
const pdf = (ui, build, fmt = 'pdf') => Promise.resolve().then(() => shareReport(build(), fmt)).catch((e) => ui.error(e));
const yearNow = () => Number(dateStr().slice(0, 4));

// Lines editor (journals, opening balances, repeating journals).
function LinesEditor({ lines, onChange, testID = 'ln', opts }) {
  const o = opts || allAcctOpts();
  const set = (i, k, v) => onChange(lines.map((x, n) => (n === i ? { ...x, [k]: v } : x)));
  const dr = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0); const cr = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);
  return (
    <View style={{ gap: 6 }}>
      {lines.map((l, i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <View style={{ flexBasis: 240, flexGrow: 2 }}><Select testID={`${testID}-acc-${i}`} label="Account" value={l.code} onChange={(v) => set(i, 'code', v)} options={[{ value: '', label: 'Choose' }].concat(o)} /></View>
          <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField testID={`${testID}-dr-${i}`} label="Debit" value={l.debit} onChange={(v) => set(i, 'debit', v)} /></View>
          <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField testID={`${testID}-cr-${i}`} label="Credit" value={l.credit} onChange={(v) => set(i, 'credit', v)} /></View>
          <View style={{ flexBasis: 110, flexGrow: 1 }}><Select label="Shop" value={l.shop || OFFICE} onChange={(v) => set(i, 'shop', v)} options={[{ value: OFFICE, label: 'Office' }].concat(shopList().map((s) => ({ value: s.code, label: s.code }))).concat([CLOSED_OPTION])} /></View>
          <Btn title="✕" size="sm" variant="ghost" onPress={() => onChange(lines.filter((_, n) => n !== i))} />
        </View>
      ))}
      <Btn title="+ line" size="sm" variant="secondary" onPress={() => onChange(lines.concat([{ code: '', debit: '', credit: '', shop: OFFICE }]))} />
      <Row label="Debits / credits" value={`${$(dr)} / ${$(cr)}`} color={Math.abs(dr - cr) < 0.005 ? C.success : C.warn} bold />
    </View>
  );
}

// ---------------------------------------------------------------- typed entries
const ENTRY_KINDS = [['sale', 'Sale'], ['expense', 'Expense'], ['income', 'Other income'], ['owner', "Owner's money"], ['transfer', 'Move money']];
export function AcctEntryScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [kind, setKind] = useState(params.kind || 'expense');
  const money = F.moneyOptions();
  const xp = usePaper('invoice');
  const EXP_MAP = { total: 'total', vat: 'vat', date: 'date', supplierName: 'supplier', tin: 'tin', invoiceNo: 'invoiceNo' };
  const [f, setF] = useState({ date: dateStr(), shop: user.shop_code || (shopList()[0] || {}).code || '', total: '', vat: '', zero: '', account: '', via: money[0] ? money[0].value : '', to: '', supplier: '', tin: '', invoiceNo: '', note: '', claimVat: true, direction: 'out', photos: [] });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const autoVat = Number(f.total) ? F.vatIn(Number(f.total) - (Number(f.zero) || 0)) : 0;
  const save = () => {
    if (kind === 'expense' && !xp.okToSave(ui)) return;
    try {
      if (kind === 'expense') { xp.log(user, 'journals', null, f, EXP_MAP); }
      if (kind === 'sale') F.saveSale(user, { date: f.date, shop: f.shop, total: f.total, zero: f.zero, vat: f.vat, via: f.via, note: f.note, account: f.account || '4000' });
      else if (kind === 'expense') F.saveExpense(user, { date: f.date, shop: f.shop, account: f.account, total: f.total, vat: f.vat, claimVat: f.claimVat, via: f.via, supplier: f.supplier, tin: f.tin, invoiceNo: f.invoiceNo, note: f.note, photos: f.photos });
      else if (kind === 'income') F.saveIncome(user, { date: f.date, shop: f.shop, account: f.account || '4900', total: f.total, via: f.via, note: f.note });
      else if (kind === 'owner') F.saveOwnerMoney(user, { date: f.date, direction: f.direction, amount: f.total, via: f.via, note: f.note });
      else F.saveTransfer(user, { date: f.date, amount: f.total, from: f.via, to: f.to, note: f.note });
      ui.toast('Saved in the books');
      nav.replace('AcctEntries', {});
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Type an entry" subtitle="Straight into the books" footer={<Btn testID="ae-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Chips value={kind} onChange={setKind} testIDPrefix="ae-k" options={ENTRY_KINDS.map(([value, label]) => ({ value, label }))} />
      <Hint>{{
        sale: 'A sale not through the tills (e.g. a bulk order). Sales through the tills come from the till counts – do not type those here.',
        expense: 'A cost paid without a supplier invoice in "Invoices & cheques" (e.g. a receipt paid at the counter). Supplier invoices go in Invoices & cheques, not here.',
        income: 'Money in that is not a sale: interest, commission, a refund, insurance claim…',
        owner: 'The owner putting money into the business, or taking money out for personal use (drawings).',
        transfer: 'Moving money between a shop\'s cash and the bank, or between bank accounts (bank deposits from the tills are made in Till & cash).',
      }[kind]}</Hint>
      <DateField label="Date" value={f.date} onChange={set('date')} />
      {['sale', 'expense', 'income'].includes(kind) ? <Select label="Shop" value={f.shop} onChange={set('shop')} options={[{ value: OFFICE, label: 'Office / whole business' }].concat(shopOpts()).concat([CLOSED_OPTION])} /> : null}
      {kind === 'owner' ? <Chips value={f.direction} onChange={set('direction')} options={[{ value: 'in', label: 'Owner puts money in' }, { value: 'out', label: 'Owner takes money out' }]} /> : null}
      <MoneyField testID="ae-total" label={kind === 'sale' || kind === 'expense' ? 'Amount (incl. VAT)' : 'Amount'} value={f.total} onChange={set('total')} />
      {kind === 'expense' ? (
        <>
          <Select testID="ae-account" label="What was it for?" value={f.account} onChange={set('account')} options={[{ value: '', label: 'Choose' }].concat(acctOpts(['expense', 'cogs', 'asset']))} />
          <Chips value={f.claimVat} onChange={set('claimVat')} options={[{ value: true, label: 'Has VAT (tax invoice / receipt)' }, { value: false, label: 'No VAT' }]} />
          {f.claimVat ? <MoneyField label={`VAT (blank = ${$(autoVat)})`} value={f.vat} onChange={set('vat')} /> : null}
          <Field testID="ae-supplier" label="Paid to" value={f.supplier} onChangeText={set('supplier')} />
          {f.claimVat ? <Field label="Their TIN (needed to claim the VAT)" value={f.tin} onChangeText={set('tin')} keyboardType="number-pad" /> : null}
          <Field label="Receipt / invoice number" value={f.invoiceNo} onChangeText={set('invoiceNo')} />
          <PaperPhoto pr={xp} testID="ae-photo" value={f.photos} onChange={set('photos')} label="Photo of the receipt" form={f} setForm={setF} map={EXP_MAP} soft={{ date: dateStr() }}
            labels={{ total: 'Amount', vat: 'VAT', date: 'Date', supplier: 'Paid to', tin: 'Their TIN', invoiceNo: 'Receipt number' }} hint="The amount, VAT, shop, TIN and number fill in from the photo." />
        </>
      ) : null}
      {kind === 'sale' ? (
        <>
          <MoneyField label="Zero-rated part (if any)" value={f.zero} onChange={set('zero')} />
          <MoneyField label={`VAT (blank = ${$(autoVat)})`} value={f.vat} onChange={set('vat')} />
        </>
      ) : null}
      {kind === 'income' ? <Select label="Account" value={f.account || '4900'} onChange={set('account')} options={acctOpts(['income'])} /> : null}
      <Select testID="ae-via" label={kind === 'transfer' ? 'From' : kind === 'sale' || kind === 'income' || (kind === 'owner' && f.direction === 'in') ? 'Money went into' : 'Paid from'} value={f.via} onChange={set('via')}
        options={money.concat(kind === 'expense' ? [{ value: 'owner', label: 'Paid by the owner personally' }] : [])} />
      {kind === 'transfer' ? <Select label="To" value={f.to} onChange={set('to')} options={[{ value: '', label: 'Choose' }].concat(money)} /> : null}
      <Field label={kind === 'income' ? 'What is it?' : 'Note'} value={f.note} onChangeText={set('note')} />
    </Screen>
  );
}
export function AcctEntriesScreen() {
  const { user, nav, can } = useApp();
  const act = useAct();
  const list = F.typedEntries();
  return (
    <Screen title="Typed entries" subtitle="Sales, expenses, income, owner's money, transfers">
      {can('accounts_journal') ? <Btn testID="ae-new" title="Type an entry" icon="➕" variant="success" onPress={() => nav.push('AcctEntry', {})} /> : null}
      {list.map((j) => (
        <Card key={j.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: j.status === 'void' ? C.sub : C.text }}>{j.jdate} · {A.JOURNAL_SRC[j.kind]} · {j.memo}{j.status === 'void' ? ' (VOID)' : ''}</Text>
          <Text style={{ color: C.sub }}>{j.lines.map((l) => `${A.accountName(l.code)} ${l.debit ? `Dr ${$(l.debit)}` : `Cr ${$(l.credit)}`}`).join(' · ')}</Text>
          <Text style={{ fontSize: 13, color: C.sub }}>by {j.by_name}{j.void_reason ? ` · voided: ${j.void_reason}` : ''}</Text>
          {j.status === 'active' && can('accounts_journal') ? <ReasonButton title="Void" size="sm" prompt="Why?" confirm="Void" onDo={(w) => act(() => A.voidJournal(user, j.uid, w), 'Voided')} /> : null}
        </Card>
      ))}
      {!list.length ? <Hint>Nothing typed yet.</Hint> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Aronium figures to check
const BSTATE = { to_check: ['To check', C.warn], approved: ['Approved – in the books', C.success], rejected: ['Rejected', C.sub] };
export function AroniumInboxScreen() {
  const { nav, can } = useApp();
  const [st, setSt] = useState('to_check');
  const list = F.listBatches({ status: st || undefined });
  return (
    <Screen title="Aronium figures" subtitle="Checked by a person before they reach the books">
      <Explain>Sales and paid-outs from Aronium come in here first (from a CSV export now, and from the main software later). Paid-outs reach the books only when someone checks them and taps Approve. Sales are never booked from Aronium: cash and banking come from the till balance. Approved sales become Aronium End of day figures, matched to each shift's Z – a difference or a missing till balance is flagged straight away (Till & cash › Aronium End of day), and the VAT return uses Aronium's VAT split.</Explain>
      {can('accounts_journal') ? <Btn testID="ar-import" title="Bring in an Aronium CSV" icon="📥" variant="info" onPress={() => nav.push('AroniumImport', {})} /> : null}
      <Chips value={st} onChange={setSt} testIDPrefix="ar-st" options={[{ value: 'to_check', label: 'To check' }, { value: 'approved', label: 'Approved' }, { value: 'rejected', label: 'Rejected' }, { value: '', label: 'All' }]} />
      {list.map((b) => (
        <ListItem key={b.uid} testID={`ar-${b.uid}`} title={`${b.kind === 'sales' ? 'Sales' : 'Paid-outs'} · ${b.shop_code} · ${b.from_date}${b.to_date !== b.from_date ? ` – ${b.to_date}` : ''}`}
          sub={`${b.data.length} row(s) · brought in by ${b.imported_by} ${String(b.imported_at).slice(0, 16)}${b.checked_by ? ` · checked by ${b.checked_by}` : ''}`} right={$(b.total)}
          badge={BSTATE[b.status][0]} badgeColor={BSTATE[b.status][1]} onPress={() => nav.push('AroniumBatch', { uid: b.uid })} />
      ))}
      {!list.length ? <Hint>Nothing here.</Hint> : null}
    </Screen>
  );
}
export function AroniumImportScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [kind, setKind] = useState('sales');
  const [shop, setShop] = useState(user.shop_code || (shopList()[0] || {}).code || '');
  const [text, setText] = useState('');
  const [name, setName] = useState('');
  const [map, setMap] = useState(null);
  const parsed = useMemo(() => { if (!text) return null; try { return { ...F.readAroniumCsv(text, kind, map || undefined) }; } catch (e) { return { error: e.message }; } }, [text, kind, map]);
  const headers = useMemo(() => { try { return text ? (text.split(/\r?\n/)[0] || '').split(/[;,\t]/).map((h) => h.replace(/"/g, '').trim()) : []; } catch (e) { return []; } }, [text]);
  const guess = useMemo(() => (headers.length ? F.guessAroniumMapping(headers, kind) : {}), [headers, kind]);
  const m = map || guess;
  const bring = () => {
    try {
      if (!parsed || parsed.error) throw new Error(parsed ? parsed.error : 'Choose the file first.');
      const uid = F.addAroniumBatch(user, { kind, shopCode: shop, rows: parsed.rows, fileName: name });
      ui.toast('Brought in – now it must be checked');
      nav.replace('AroniumBatch', { uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Bring in Aronium figures" footer={<Btn testID="ai-bring" title="Bring in for checking" icon="📥" variant="success" onPress={bring} />}>
      <Hint>In Aronium: Reports › Sales (by day, with tax and payment types) or Cash in / out › Export to CSV. Copy the file to this tablet and choose it. Aronium itself is never changed.</Hint>
      <Chips value={kind} onChange={(v) => { setKind(v); setMap(null); }} testIDPrefix="ai-k" options={[{ value: 'sales', label: 'Daily sales' }, { value: 'expenses', label: 'Paid-outs / expenses' }]} />
      <Select label="Shop" value={shop} onChange={setShop} options={shopOpts()} />
      <Btn testID="ai-pick" title={name ? `File: ${name}` : 'Choose the CSV file'} icon="📂" variant="info" onPress={async () => { try { const f = await pickTextFile(); if (f) { setText(f.text); setName(f.name); setMap(null); } } catch (e) { ui.error(e); } }} />
      <Field testID="ai-text" label="…or paste the CSV text" value={text.length > 3000 ? `${text.slice(0, 3000)}…` : text} onChangeText={(t) => { if (!t.endsWith('…')) { setText(t); setMap(null); } }} multiline />
      {headers.length ? (
        <Section title="Which column is which">
          {F.ARONIUM_FIELDS[kind].map((f) => (
            <Select key={f.key} label={`${f.label}${f.need ? ' (needed)' : ''}`} value={m[f.key] === undefined ? '' : String(m[f.key])} onChange={(v) => setMap({ ...m, [f.key]: v === '' ? undefined : Number(v) })}
              options={[{ value: '', label: '— not in the file —' }].concat(headers.map((h, i) => ({ value: String(i), label: h || `Column ${i + 1}` })))} />
          ))}
        </Section>
      ) : null}
      {parsed && parsed.error ? <Banner tone="warn" message={parsed.error} /> : null}
      {parsed && parsed.rows ? (
        <Section title={`Preview (${parsed.rows.length} row(s))`}>
          {parsed.errors.length ? <Banner tone="warn" message={parsed.errors.slice(0, 5).join('\n')} /> : null}
          <Table columns={kind === 'sales' ? [{ key: 'date', title: 'Date' }, { key: 'z', title: 'Z no.' }, { key: 'total', title: 'Total', align: 'right' }, { key: 'vat', title: 'VAT', align: 'right' }, { key: 'cash', title: 'Cash', align: 'right' }, { key: 'card', title: 'Card', align: 'right' }]
            : [{ key: 'date', title: 'Date' }, { key: 'description', title: 'What', width: 200 }, { key: 'amount', title: 'Amount', align: 'right' }, { key: 'vat', title: 'VAT', align: 'right' }]}
          rows={parsed.rows.slice(0, 40).map((r) => ({ ...r, total: r.total !== undefined ? $(r.total) : undefined, amount: r.amount !== undefined ? $(r.amount) : undefined, vat: $(r.vat), cash: r.cash !== undefined ? $(r.cash) : undefined, card: r.card !== undefined ? $(r.card) : undefined }))} />
        </Section>
      ) : null}
    </Screen>
  );
}
export function AroniumBatchScreen({ params }) {
  const { user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  let rev = null;
  try { rev = F.reviewBatch(params.uid); } catch (e) { rev = null; }
  const [rows, setRows] = useState(() => (rev ? rev.lines.map((l) => ({ account: l.account || '', use: l.use })) : []));
  if (!rev) return <Screen title="Aronium figures"><Banner tone="warn" message="Not found." /></Screen>;
  const b = rev.batch;
  const sales = b.kind === 'sales';
  const approve = () => { const r = act(() => F.approveBatch(user, b.uid, { rows: sales ? undefined : rows })); if (r) { ui.toast(sales ? `Approved – ${r.eods} End of day figure(s) matched to the tills${r.missing ? `, ${r.missing} with the till balance missing` : ''}` : `Approved – ${r.booked} entr${r.booked === 1 ? 'y' : 'ies'} booked`); refresh(); } };
  return (
    <Screen title={`Aronium ${sales ? 'sales' : 'paid-outs'} · ${b.shop_code}`} subtitle={`${b.from_date} – ${b.to_date} · ${BSTATE[b.status][0]}`}>
      <Stats items={[{ label: 'In the file', value: $(b.total) }, sales ? { label: 'Till balance missing', value: String((rev.missing || []).length), color: (rev.missing || []).length ? C.danger : C.success } : { label: 'Will be booked', value: $(rev.toBook) }, ...(sales ? [{ label: 'Days that differ from the till', value: String(rev.differences.length), color: rev.differences.length ? C.warn : C.success }] : [])]} />
      {b.reject_reason ? <Banner tone="info" message={`Rejected: ${b.reject_reason}`} /> : null}
      {b.note ? <Hint>{b.note}</Hint> : null}
      {sales ? (
        <Table columns={[{ key: 'date', title: 'Date' }, { key: 'total', title: 'Aronium', align: 'right' }, { key: 'till', title: 'Till count', align: 'right' }, { key: 'diff', title: 'Difference', align: 'right' }, { key: 'what', title: 'What happens', width: 190 }]}
          rows={rev.lines.map((l) => ({ date: l.date, total: $(l.total), till: l.till === null ? '—' : $(l.till), diff: l.diff === null ? '' : $(l.diff), what: { compare: 'Matched to the till balance', missing: 'TILL BALANCE MISSING', book: 'Booked from Aronium', already: 'Already typed – not used' }[l.action], _tone: l.action === 'missing' ? 'bad' : l.diff && Math.abs(l.diff) > 0.009 ? 'warn' : null }))} />
      ) : rev.lines.map((l, i) => (
        <Card key={i}>
          <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{l.date} · {l.description} · {$(l.amount)}{l.vat ? ` (VAT ${$(l.vat)})` : ''}</Text>
          {l.inTill ? <Hint>The same amount is a pay-out on that day's till count – probably already booked. Skip it unless you are sure.</Hint> : null}
          {b.status === 'to_check' ? (
            <>
              <Chips value={rows[i].use} onChange={(v) => setRows(rows.map((x, n) => (n === i ? { ...x, use: v } : x)))} options={[{ value: 'book', label: 'Book it' }, { value: 'skip', label: 'Skip' }]} />
              {rows[i].use === 'book' ? <Select label="What was it for?" value={rows[i].account} onChange={(v) => setRows(rows.map((x, n) => (n === i ? { ...x, account: v } : x)))} options={[{ value: '', label: 'Choose' }].concat(acctOpts(['expense', 'cogs']))} /> : null}
            </>
          ) : <Text style={{ color: C.sub }}>{l.use === 'skip' ? 'Skipped' : A.accountName(l.account)}</Text>}
        </Card>
      ))}
      {b.status === 'to_check' && can('accounts_journal') ? (
        <View style={{ gap: 10 }}>
          <Hint>Check the figures against Aronium's Z report / cash in-out report. When they are right, approve. If something is wrong, reject with the reason and bring it in again.</Hint>
          <Btn testID="ab-approve" title={sales ? 'Checked – approve (match to the tills)' : 'Checked – approve into the books'} icon="✅" variant="success" onPress={approve} />
          <ReasonButton testID="ab-reject" title="Reject" prompt="What is wrong with it?" confirm="Reject" onDo={(w) => { if (act(() => F.rejectBatch(user, b.uid, w), 'Rejected')) refresh(); }} />
        </View>
      ) : null}
      {b.status === 'approved' && can('accounts_close') ? <ReasonButton title="Undo the approval" prompt="Why? (the entries are taken out of the books)" confirm="Undo" onDo={(w) => { if (act(() => F.undoBatch(user, b.uid, w), 'Undone')) refresh(); }} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- repeating journals, prepayments, accruals
export function RepeatJournalsScreen() {
  const { user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const [mode, setMode] = useState(null);
  const [f, setF] = useState({});
  const list = F.listRecurring();
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const start = (m) => { setMode(m); setF({ date: m === 'accrual' ? addDays(`${dateStr().slice(0, 7)}-01`, -1) : dateStr(), nextDate: dateStr(), memo: '', amount: '', account: '', months: '12', times: '', reverse: false, lines: [{ code: '', debit: '', credit: '', shop: OFFICE }, { code: '', debit: '', credit: '', shop: OFFICE }] }); };
  const save = () => {
    const ok = act(() => (mode === 'prepay' ? F.spreadPrepayment(user, f) : mode === 'accrual' ? F.accrue(user, f) : F.saveRecurring(user, f)), 'Saved');
    if (ok) { setMode(null); try { F.runRecurring(user); } catch (e) { ui.error(e); } refresh(); }
  };
  return (
    <Screen title="Repeating journals" subtitle="Monthly entries, costs paid in advance, costs owing">
      <Explain>Three helpers for month-end accounting: (1) a journal that repeats every month by itself; (2) a cost paid for several months at once (insurance, a licence) spread over those months; (3) a cost that belongs to this month but is billed later (accrual) – booked now and taken back next month.</Explain>
      {can('accounts_journal') && !mode ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="rj-new" title="Repeating journal" icon="🔁" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => start('repeat')} />
          <Btn testID="rj-prepay" title="Paid in advance" icon="📆" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => start('prepay')} />
          <Btn testID="rj-accrue" title="Cost owing (accrual)" icon="🧾" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => start('accrual')} />
        </View>
      ) : null}
      {mode ? (
        <Card>
          <Field testID="rj-memo" label="What is it?" value={f.memo} onChangeText={set('memo')} />
          {mode === 'repeat' ? (
            <>
              <DateField farDays={false} label="First date" value={f.nextDate} onChange={set('nextDate')} />
              <Field label="How many times (blank = until stopped)" value={f.times} onChangeText={set('times')} keyboardType="number-pad" />
              <Chips value={f.reverse} onChange={set('reverse')} options={[{ value: false, label: 'Normal' }, { value: true, label: 'Take back on the 1st of next month' }]} />
              <LinesEditor lines={f.lines} onChange={set('lines')} testID="rj" />
            </>
          ) : (
            <>
              <DateField label={mode === 'prepay' ? 'Date paid' : 'Date (last day of the month)'} value={f.date} onChange={set('date')} />
              <MoneyField testID="rj-amount" label="Amount (excl. VAT)" value={f.amount} onChange={set('amount')} />
              <Select testID="rj-account" label="Cost account" value={f.account} onChange={set('account')} options={[{ value: '', label: 'Choose' }].concat(acctOpts(['expense', 'cogs']))} />
              <Select label="Shop" value={f.shop || OFFICE} onChange={set('shop')} options={[{ value: OFFICE, label: 'Office' }].concat(shopOpts()).concat([CLOSED_OPTION])} />
              {mode === 'prepay' ? <Field label="Spread over how many months" value={f.months} onChangeText={set('months')} keyboardType="number-pad" /> : null}
              {mode === 'prepay' ? <Hint>Enter the bill as usual (Invoices & cheques or Type an entry) to the same cost account. This then moves it to "paid in advance" and brings one share back each month.</Hint> : null}
            </>
          )}
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setMode(null)} />
            <Btn testID="rj-save" title="Save" variant="success" style={{ flex: 1 }} onPress={save} />
          </View>
        </Card>
      ) : null}
      {list.map((r) => (
        <Card key={r.uid}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: r.active ? C.text : C.sub }}>{r.memo}{r.active ? '' : ' (finished / stopped)'}</Text>
          <Text style={{ color: C.sub }}>Next {r.next_date}{r.times_left !== null ? ` · ${r.times_left} more` : ''}{r.reverse ? ' · taken back next month' : ''}</Text>
          <Text style={{ color: C.sub }}>{r.lines.map((l) => `${A.accountName(l.code)} ${l.debit ? `Dr ${$(l.debit)}` : `Cr ${$(l.credit)}`}`).join(' · ')}</Text>
          {r.active && can('accounts_journal') ? <Btn title="Stop" size="sm" variant="ghost" onPress={() => { act(() => F.stopRecurring(user, r.uid), 'Stopped'); refresh(); }} /> : null}
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- tax centre
const TSTATE = { paid: ['Paid', C.success], late: ['LATE', C.danger], due_soon: ['Due soon', C.warn], to_pay: ['To pay', C.info], before: ['Before the app – record it if paid', C.sub] };
export function TaxCentreScreen() {
  const { user, nav, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const money = F.moneyOptions();
  const [pay, setPay] = useState(null);
  const s = F.acctSettings();
  const [lastTax, setLastTax] = useState(String(s.lastYearTax || ''));
  const year = yearNow();
  const prov = F.provTaxMonths().slice(0, 12);
  const adv = F.advanceTaxPlan(year);
  const save = () => { if (act(() => F.recordTaxPayment(user, pay), 'Payment recorded')) { setPay(null); refresh(); } };
  const startPay = (o) => setPay({ date: dateStr(), via: (money.find((m) => m.value.startsWith('bank:')) || money[0] || {}).value, reference: '', ...o });
  return (
    <Screen title="Tax" subtitle="VAT, provisional tax, company tax">
      <Explain>All the business taxes in one place, with their due dates. FNPF and PAYE for staff are in Payroll › FNPF & PAYE payments.</Explain>
      {pay ? (
        <Card>
          <H>{F.TAX_KINDS[pay.tax]} – record a payment</H>
          <DateField label="Date paid" value={pay.date} onChange={(v) => setPay({ ...pay, date: v })} />
          <MoneyField testID="tx-amount" label="Amount" value={String(pay.amount ?? '')} onChange={(v) => setPay({ ...pay, amount: v })} />
          <Select label="Paid from" value={pay.via} onChange={(v) => setPay({ ...pay, via: v })} options={money} />
          <Field label="FRCS receipt / reference" value={pay.reference} onChangeText={(v) => setPay({ ...pay, reference: v })} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setPay(null)} />
            <Btn testID="tx-save" title="Save" variant="success" style={{ flex: 1 }} onPress={save} />
          </View>
        </Card>
      ) : null}
      <Section title="VAT (monthly)">
        <Hint>The VAT return and payment for a month are due by the last day of the next month.</Hint>
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn title="VAT return" icon="🧾" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('VatReturn', {})} />
          {can('accounts_journal') ? <Btn testID="tx-vat" title="Record VAT paid" icon="💸" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { const d = new Date(); d.setMonth(d.getMonth() - 1); const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; startPay({ tax: 'vat', ym, amount: Math.max(0, A.vatReturn({ ym }).net) }); }} /> : null}
        </View>
      </Section>
      <Section title="Provisional tax – 5% kept back from contractors">
        <Hint>Mark contractors in Invoices & cheques › Suppliers. The 5% kept back each month is paid to FRCS by the end of the next month.</Hint>
        {prov.map((m) => (
          <ListItem key={m.ym} title={`${m.ym}: ${$(m.withheld)} kept back`} sub={`due ${m.due}${m.paid ? ` · paid ${$(m.paid)}` : ''}`} badge={TSTATE[m.state][0]} badgeColor={TSTATE[m.state][1]}
            onPress={m.owing > 0 && can('accounts_journal') ? () => startPay({ tax: 'prov', ym: m.ym, amount: m.owing }) : undefined} />
        ))}
        {!prov.length ? <Hint>Nothing kept back yet.</Hint> : null}
        <Btn title="Contractor certificates (PDF)" icon="📄" size="sm" variant="secondary" onPress={() => pdf(ui, () => S.provTaxReport(year))} />
      </Section>
      <Section title={`Company advance tax ${year}`}>
        <Hint>A third of last year's company tax is paid at the end of months 6, 9 and 12 of the tax year. Enter last year's tax (from the accountant) to get the reminders.</Hint>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
          <View style={{ flex: 1 }}><MoneyField testID="tx-last" label="Last year's company income tax" value={lastTax} onChange={setLastTax} /></View>
          <Btn title="Save" size="md" variant="secondary" onPress={() => { act(() => F.saveAcctSettings(user, { lastYearTax: lastTax }), 'Saved'); refresh(); }} />
        </View>
        {adv.map((i) => (
          <ListItem key={i.n} title={`Instalment ${i.n}: ${$(i.amount)}`} sub={`due ${i.due}${i.paid ? ` · paid ${$(i.paid)}` : ''}`} badge={TSTATE[i.state][0]} badgeColor={TSTATE[i.state][1]}
            onPress={i.state !== 'paid' && can('accounts_journal') ? () => startPay({ tax: 'advance', year, n: i.n, amount: r2(i.amount - i.paid) }) : undefined} />
        ))}
      </Section>
      {can('accounts_journal') ? <Btn title="Record final company tax paid" size="sm" variant="ghost" onPress={() => startPay({ tax: 'company', year: year - 1, amount: '' })} /> : null}
    </Screen>
  );
}
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// ---------------------------------------------------------------- opening balances
export function OpeningBalancesScreen() {
  const { user } = useApp();
  const ui = useUI();
  const ob = F.openingBalances();
  const [date, setDate] = useState(ob ? ob.date : (F.acctSettings().goLive || `${yearNow()}-01-01`));
  const [lines, setLines] = useState(() => (ob ? ob.lines.filter((l) => l.code !== '3000').map((l) => ({ ...l, debit: l.debit ? String(l.debit) : '', credit: l.credit ? String(l.credit) : '' })) : [{ code: '', debit: '', credit: '', shop: OFFICE }]));
  const opts = A.listAccountsGL().filter((a) => !a.code.startsWith('2500') && !['income', 'cogs', 'expense'].includes(a.type)).map((a) => ({ value: a.code, label: `${a.code.includes(':') ? a.code.slice(0, 4) : a.code} ${a.name}` }));
  const save = () => { try { const r = F.saveOpeningBalances(user, { date, lines }); ui.toast(`Saved${Math.abs(r.balancingAmount) > 0.004 ? ` – ${$(Math.abs(r.balancingAmount))} put to opening capital` : ''}`); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Opening balances" subtitle="Where the books start" footer={<Btn testID="ob-save" title="Save opening balances" icon="💾" variant="success" onPress={save} />}>
      <Explain>Copy the balances from the accountant's last balance sheet (the day before the app's books start): cash at each shop, each bank account, VAT, FNPF/PAYE owing, staff advances… Things you own are debits; things you owe are credits. The difference goes to "Owner's capital & opening balances". Entered elsewhere instead (so they are not counted twice): loans in Invoices & cheques › Regular bills & loans; equipment in Equipment & vehicles; each unpaid supplier invoice in Invoices & cheques; stock from the Aronium import (opening stock).</Explain>
      <DateField farDays={false} label="Balances on" value={date} onChange={setDate} />
      <LinesEditor lines={lines} onChange={setLines} testID="ob" opts={opts} />
    </Screen>
  );
}

// ---------------------------------------------------------------- year end, statements, forecast, pack, cash book
export function YearEndAcctScreen() {
  const { user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const [year, setYear] = useState(String(yearNow() - (dateStr().slice(5, 7) <= '03' ? 1 : 0)));
  const closed = F.closedYears();
  return (
    <Screen title="Year end" subtitle="Financial statements and closing the year">
      <Explain>At the end of the financial year (31 December): finish every month end, close the books to 31 December (Month end), check the financial statements with the accountant, then close the year. Closing keeps the year's final balances, so reports for later years stay fast. If the year is reopened, the kept balances are not used until it is closed again.</Explain>
      <Chips value={year} onChange={setYear} options={[0, 1, 2].map((k) => String(yearNow() - k)).map((y) => ({ value: y, label: y }))} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="ye-fs" title="Financial statements (PDF)" icon="🏛️" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => pdf(ui, () => S.financialStatements(year))} />
        <Btn title="Excel" icon="📊" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => pdf(ui, () => S.financialStatements(year), 'xlsx')} />
        <Btn testID="ye-pack" title="Accountant pack (Excel)" icon="📦" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => pdf(ui, () => S.accountantPack(`${year}-01-01`, `${year}-12-31`), 'xlsx')} />
      </View>
      {can('accounts_close') ? <Btn testID="ye-close" title={`Close the year ${year}`} icon="🔒" variant="success" onPress={async () => { const ok = await ui.confirm({ title: `Close ${year}?`, message: 'The books must already be closed to 31 December. The year\'s balances are kept.', confirmText: 'Close the year' }); if (!ok) return; await snapshotNow('year-close').catch(() => null); if (act(() => F.closeYear(user, year), 'Year closed')) refresh(); }} /> : null}
      <Section title="Closed years">
        {closed.map((c) => <ListItem key={c.year} title={`${c.year} · profit ${$(c.profit)}`} sub={`closed by ${c.by_name} ${String(c.closed_at).slice(0, 10)}${c.stillLocked ? '' : ' · REOPENED – close it again'}`} />)}
        {!closed.length ? <Hint>No year closed yet.</Hint> : null}
      </Section>
    </Screen>
  );
}
export function ForecastScreen() {
  const ui = useUI();
  let f = null;
  try { f = S.cashForecast({ weeks: 13 }); } catch (e) { f = null; }
  if (!f) return <Screen title="Cash flow forecast"><Banner tone="warn" message="Not enough figures yet." /></Screen>;
  return (
    <Screen title="Cash flow forecast" subtitle="The next 13 weeks">
      <Explain>Cash and bank now, plus the average week's takings, less bills by their due dates, wages, loan repayments and taxes when they fall due. A guide to see a tight week coming.</Explain>
      <Stats items={[{ label: 'Takings a week (avg)', value: $(f.weeklyTakings) }, { label: 'Wages a week (avg)', value: $(f.weeklyWages) }, { label: 'Lowest cash expected', value: $(f.lowest), color: f.lowest < 0 ? C.danger : C.success }]} />
      <Table columns={[{ key: 'to', title: 'Week to' }, { key: 'open', title: 'Start', align: 'right' }, { key: 'takings', title: 'In', align: 'right' }, { key: 'out', title: 'Out', align: 'right' }, { key: 'close', title: 'End', align: 'right' }]}
        rows={f.weeks.map((w) => ({ to: w.to, open: $(w.open), takings: $(w.takings), out: $(w.bills + w.wages + w.loans + w.tax), close: $(w.close), _tone: w.close < 0 ? 'bad' : null }))} />
      <Btn title="PDF with the details" icon="📄" size="md" variant="secondary" onPress={() => pdf(ui, () => S.forecastReport())} />
    </Screen>
  );
}
export function CashBookScreen() {
  const [acc, setAcc] = useState('');
  const [from, to, setRange] = usePeriod('thismonth');
  const opts = shopList().map((s) => ({ value: `1000|${s.code}`, label: `Cash – ${s.name}` })).concat(A.listAccountsGL().filter((a) => a.code.startsWith('1100:')).map((a) => ({ value: a.code, label: a.name })));
  const sel = acc || (opts[0] ? opts[0].value : '');
  const [code, shop] = sel.split('|');
  const ok = /^\d{4}-\d{2}-\d{2}$/.test(from) && /^\d{4}-\d{2}-\d{2}$/.test(to);
  let led = null;
  try { led = ok && code ? A.ledgerFor(code, { from, to, shop }) : null; } catch (e) { led = null; }
  return (
    <Screen title="Cash book" subtitle="Money in and out of each cash box and bank account">
      <Select label="Cash box / bank account" value={sel} onChange={setAcc} options={opts} />
      <PeriodPicker testID="cb-period" from={from} to={to} onChange={setRange} />
      {led ? (
        <>
          <Stats items={[{ label: 'At the start', value: $(led.opening) }, { label: 'In', value: $(led.lines.reduce((s, l) => s + l.debit, 0)) }, { label: 'Out', value: $(led.lines.reduce((s, l) => s + l.credit, 0)) }, { label: 'At the end', value: $(led.closing) }]} />
          <Table columns={[{ key: 'date', title: 'Date' }, { key: 'text', title: 'What', width: 220 }, { key: 'in', title: 'In', align: 'right' }, { key: 'out', title: 'Out', align: 'right' }, { key: 'bal', title: 'Balance', align: 'right' }]}
            rows={led.lines.map((l) => ({ date: l.date, text: `${l.src}: ${l.text}`, in: l.debit ? $(l.debit) : '', out: l.credit ? $(l.credit) : '', bal: $(l.balance) }))} />
        </>
      ) : <Hint>Choose the dates.</Hint>}
    </Screen>
  );
}
export function AcctSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const s0 = F.acctSettings();
  const [s, setS] = useState({ ...s0, lastYearTax: String(s0.lastYearTax || ''), provTaxPct: String(s0.provTaxPct), provTaxThreshold: String(s0.provTaxThreshold), taxYearEndMonth: String(s0.taxYearEndMonth) });
  const set = (k) => (v) => setS((o) => ({ ...o, [k]: v }));
  return (
    <Screen title="Accounting settings" footer={<Btn testID="as-save" title="Save" icon="💾" variant="success" onPress={() => act(() => F.saveAcctSettings(user, s), 'Saved')} />}>
      <DateField farDays={false} label="The books start on" value={s.goLive} onChange={set('goLive')} />
      <Field label="Tax year ends in month (12 = December)" value={s.taxYearEndMonth} onChangeText={set('taxYearEndMonth')} keyboardType="number-pad" />
      <MoneyField label="Last year's company income tax (for advance tax)" value={s.lastYearTax} onChange={set('lastYearTax')} />
      <Chips value={s.advanceTax} onChange={set('advanceTax')} options={[{ value: true, label: 'Remind about advance tax' }, { value: false, label: 'No advance tax' }]} />
      <Field label="Provisional tax % kept back from contractors" value={s.provTaxPct} onChangeText={set('provTaxPct')} keyboardType="decimal-pad" />
      <MoneyField label="…once a contractor is paid more than (a year, excl. VAT)" value={s.provTaxThreshold} onChange={set('provTaxThreshold')} />
      <Hint>Check these with your accountant. Contractors are marked in Invoices & cheques › Suppliers.</Hint>
    </Screen>
  );
}
