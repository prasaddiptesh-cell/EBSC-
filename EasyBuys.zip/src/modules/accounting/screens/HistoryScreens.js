// 1.0.0 build 14 (owner, 7 Nov): the invoices from before the app and the VAT of those months.
// The cloud reads the scanned invoices in Google Drive (EBSC Invoices Records › shop › month) in the background (cloud
// script 20, hist_*). They are history only: never in Invoices & cheques, no reminders, no To verify, no Viber. An invoice
// that could not be read is an open item of its month. The owner goes through each month: checks the open items, types
// the sales (per day or for the whole month, standard-rated and zero-rated, incl. VAT), sees the VAT and closes the
// month; a closed month changes only after the owner / an admin opens it again. Online only (it all lives in the cloud).
import React, { useEffect, useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ListItem, MoneyField, Stats, DateField, ReasonButton } from '../../../ui/kit.js';
import { getSetting } from '../../../services/core.js';
import { cloudCall } from '../../../platform/cloud.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const ymLabel = (ym) => { const m = /^(\d{4})-(\d{2})$/.exec(String(ym || '')); return m ? `${MONTHS[+m[2] - 1]} ${m[1]}` : String(ym || ''); };
export const money = (n) => (n === null || n === undefined || n === '' ? '–' : `${Number(n) < 0 ? '-' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
export const daysIn = (ym) => { const m = /^(\d{4})-(\d{2})$/.exec(String(ym || '')); return m ? new Date(+m[1], +m[2], 0).getDate() : 31; };
const STATUS = { ok: ['Counted', C.success], fixed: ['Checked', C.success], check: ['OPEN', C.danger], dup: ['Same as another', C.sub], after: ['After the cut-off', C.sub], excluded: ['Left out', C.sub] };
const CLOUD_NEEDED = 20;
const cloudOld = () => Number(getSetting('cloud_script_version', '0')) < CLOUD_NEEDED;

// Shared: a cloud request with the answer or the error on the screen.
function useCloud() {
  const ui = useUI();
  const [busy, setBusy] = useState('');
  const call = async (body, label, ms = 60000) => {
    setBusy(label || 'Working…');
    try {
      const r = await cloudCall(body, ms);
      if (r && r.ok === false) throw Object.assign(new Error(r.error || 'The cloud said no.'), { isAppError: true });
      return r;
    } catch (e) { ui.error(e); return null; } finally { setBusy(''); }
  };
  return { busy, call };
}
function OldCloud() {
  return cloudOld() ? <Banner tone="warn" title="Update the cloud program first" message="This needs cloud program 20: copy the new Code.gs into the Easy Buys cloud project and deploy a new version (Deploy › Manage deployments › Edit › New version)." /> : null;
}

// ------------------------------------------------------------------ start / progress
export function HistoryHomeScreen() {
  const { nav } = useApp();
  const { busy, call } = useCloud();
  const [st, setSt] = useState(null);
  const [folders, setFolders] = useState(null);
  const [pick, setPick] = useState({});
  const [before, setBefore] = useState('2026-11-01');
  const [setup, setSetup] = useState(false);
  const load = async () => {
    const s = await call({ kind: 'hist_status' }, 'Asking the cloud…');
    if (!s) return;
    setSt(s);
    if (!s.job) openSetup(s);
  };
  const openSetup = async (s) => {
    setSetup(true);
    if (s && s.job) { setBefore(s.job.before); }
    const f = await call({ kind: 'hist_folders' }, 'Finding the invoice folders…');
    if (!f) return;
    setFolders(f.folders);
    const chosen = {};
    const had = s && s.job ? s.job.shops.map((x) => x.id) : null;
    f.folders.forEach((x) => { chosen[x.id] = had ? had.includes(x.id) : /^shop\s*[123]\b/i.test(x.name); });
    setPick(chosen);
  };
  useEffect(() => { load(); }, []);
  const start = async () => {
    const shops = (folders || []).filter((x) => pick[x.id]).map((x) => ({ id: x.id, name: x.name }));
    const s = await call({ kind: 'hist_start', shops, before }, 'Starting…');
    if (s) { setSt(s); setSetup(false); }
  };
  const job = st && st.job;
  const doneAll = job && job.listed && !st.left;
  return (
    <Screen title="Invoices from before the app" subtitle="Read from Google Drive · VAT month by month">
      <OldCloud />
      <Explain title="How this works">
        The cloud opens each scanned invoice in Google Drive (EBSC Invoices Records › shop › month) and reads the supplier, number, date, total and VAT – a few hundred a day, by itself, until all are read. They are kept as history only: nothing goes to Invoices & cheques, no reminders, no To verify and no Viber. An invoice that could not be read, or whose figures do not add up, is an open item of its month. Then go through each month: check the open items, type the sales, look at the VAT and close the month.
      </Explain>
      {busy ? <Banner tone="info" message={busy} /> : null}
      {job && !setup ? (
        <>
          <Stats items={[
            { label: 'Files found', value: String(st.files) },
            { label: 'Read', value: String(st.read), color: C.success },
            { label: 'Still to read', value: String(st.left), color: st.left ? C.warn : C.success },
            { label: 'Open items', value: String(st.open), color: st.open ? C.danger : C.success, onPress: () => nav.push('HistoryMonths', {}) },
          ]} />
          {!job.listed ? <Banner tone="info" title="Finding the files" message="The cloud is going through the folders first; reading starts after that." /> : null}
          {st.last_error ? <Banner testID="hist-error" tone="warn" title="The reader stopped" message={st.last_error} /> : null}
          {job.paused ? <Banner tone="warn" message="Paused – nothing is read until you resume." /> : null}
          {doneAll ? <Banner tone="success" title="All read" message={`${st.invoices} invoices counted, ${st.open} open item(s). Go through the months now.`} /> : null}
          <Hint>{`Shops: ${job.shops.map((x) => x.name).join(', ')} · invoices before ${job.before}${st.last_run ? ` · last run ${String(st.last_run).slice(0, 16).replace('T', ' ')} (UTC)` : ''}`}</Hint>
          <Btn testID="hist-months" title="Months & VAT" icon="📅" variant="success" onPress={() => nav.push('HistoryMonths', {})} />
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn title="Refresh" icon="🔄" size="md" variant="secondary" onPress={load} />
            {!doneAll ? <Btn title={job.paused ? 'Resume reading' : 'Pause reading'} size="md" variant="secondary" onPress={async () => { const s = await call({ kind: job.paused ? 'hist_resume' : 'hist_pause' }); if (s) setSt(s); }} /> : null}
            <Btn title="Change the shops or the date" size="md" variant="ghost" onPress={() => openSetup(st)} />
          </View>
        </>
      ) : null}
      {setup ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>Which shop folders?</Text>
          {folders === null ? <Hint>Looking in Google Drive…</Hint> : null}
          {(folders || []).map((x) => (
            <View key={x.id} style={{ gap: 4 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{x.name}</Text>
              <Chips value={pick[x.id] ? 'y' : 'n'} onChange={(v) => setPick({ ...pick, [x.id]: v === 'y' })} testIDPrefix={`hist-f-${x.name.replace(/\W+/g, '')}`} options={[{ value: 'y', label: '✓ Read it' }, { value: 'n', label: 'Leave it' }]} />
            </View>
          ))}
          <DateField testID="hist-before" label="Read invoices dated before" value={before} onChange={setBefore} farDays={1200} quick={false} />
          <Hint>From this day on, the invoices are in the app already.</Hint>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {job ? <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setSetup(false)} /> : null}
            <Btn testID="hist-start" title={job ? 'Save' : 'Start reading'} icon="▶️" size="md" variant="success" style={{ flex: 1 }} disabled={!!busy || !Object.values(pick).some(Boolean)} onPress={start} />
          </View>
        </Card>
      ) : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ the months
export function HistoryMonthsScreen() {
  const { nav } = useApp();
  const { busy, call } = useCloud();
  const [data, setData] = useState(null);
  const load = async () => { const r = await call({ kind: 'hist_months' }, 'Asking the cloud…'); if (r) setData(r); };
  useEffect(() => { load(); }, []);
  const months = data ? data.months : [];
  return (
    <Screen title="Months & VAT" subtitle="Before the app – tap a month to work on it">
      <OldCloud />
      {busy ? <Banner tone="info" message={busy} /> : null}
      {data && !months.length ? <Hint>Nothing read yet – the cloud reads a few hundred invoices a day.</Hint> : null}
      {months.map((m) => (
        <ListItem key={m.ym} testID={`hist-m-${m.ym}`} title={ymLabel(m.ym)}
          sub={`${m.invoices} invoices · VAT in ${money(m.input_vat)} · out ${money(m.output_vat)}${m.open ? ` · ${m.open} open` : ''}${m.shops_entered ? '' : ' · no sales yet'}`}
          right={m.net >= 0 ? money(m.net) : money(-m.net)} rightSub={m.net >= 0 ? 'to pay' : 'refund'}
          badge={m.closed ? 'Closed' : m.open ? `${m.open} open` : null} badgeColor={m.closed ? C.success : C.danger}
          onPress={() => nav.push('HistoryMonth', { ym: m.ym })} />
      ))}
      <Btn title="Refresh" icon="🔄" size="md" variant="secondary" onPress={load} />
    </Screen>
  );
}

// ------------------------------------------------------------------ one month
export function HistoryMonthScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const { busy, call } = useCloud();
  const [m, setM] = useState(null);
  const [open, setOpen] = useState(null);
  const [adding, setAdding] = useState(false);
  const ym = params.ym;
  const load = async () => { const r = await call({ kind: 'hist_month', ym }, 'Asking the cloud…'); if (r) setM(r); };
  useEffect(() => { load(); }, [ym]);
  if (!m) return <Screen title={ymLabel(ym)}>{busy ? <Banner tone="info" message={busy} /> : <Btn title="Try again" onPress={load} />}</Screen>;
  const s = m.summary;
  const closed = !!s.closed;
  const boss = !!user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
  const fix = async (body, ok) => { const r = await call({ kind: 'hist_fix', ...body }, 'Saving…'); if (r) { ui.toast(ok || 'Saved'); setOpen(null); setAdding(false); load(); } return !!r; };
  const counted = m.invoices.filter((x) => x.status === 'ok' || x.status === 'fixed');
  const openItems = m.invoices.filter((x) => x.status === 'check');
  const other = m.invoices.filter((x) => !['ok', 'fixed', 'check'].includes(x.status));
  const row = (x) => (
    <View key={x.key} style={{ gap: 6 }}>
      <ListItem testID={`hist-i-${x.invoice_no || x.file}`} title={x.supplier || x.file} tone={x.status === 'check' ? 'danger' : undefined}
        sub={`${x.date || 'no date'}${x.invoice_no ? ` · ${x.invoice_no}` : ''} · ${x.shop}${x.why ? ` · ${x.why}` : ''}`}
        right={money(x.total)} rightSub={x.vat === null ? 'VAT ?' : `VAT ${money(x.vat)}`}
        badge={(STATUS[x.status] || [x.status])[0]} badgeColor={(STATUS[x.status] || [0, C.sub])[1]}
        onPress={() => setOpen(open === x.key ? null : x.key)} />
      {open === x.key ? <InvoiceCard x={x} closed={closed} fix={fix} shops={m.shops} /> : null}
    </View>
  );
  return (
    <Screen title={ymLabel(ym)} subtitle={`VAT ${s.rate}% · before the app`}>
      {busy ? <Banner tone="info" message={busy} /> : null}
      <Stats items={[
        { label: 'VAT on sales (out)', value: money(s.output_vat) },
        { label: 'VAT on invoices (in)', value: money(s.input_vat) },
        { label: s.net >= 0 ? 'VAT to pay' : 'VAT refund', value: money(Math.abs(s.net)), color: s.net >= 0 ? C.warn : C.success },
        { label: 'Open items', value: String(s.open), color: s.open ? C.danger : C.success },
      ]} />
      <Hint>{`Sales: ${money(s.sales_std)} standard-rated + ${money(s.sales_zero)} zero-rated · purchases ${money(s.purchases)} (${s.invoices} invoices)`}</Hint>
      {closed ? (
        <Card tone="success">
          <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>{`✅ Closed by ${s.closed.by || 'the owner'} on ${String(s.closed.at).slice(0, 10)}`}</Text>
          <Hint>Nothing in this month changes until it is opened again.</Hint>
          {boss ? <ReasonButton testID="hist-reopen" title="Open the month again" prompt="Why open it again?" confirm="Open it" variant="warn" onDo={(w) => { call({ kind: 'hist_reopen', ym, reason: w }, 'Opening…').then((r) => { if (r) { ui.toast('Opened again'); load(); } }); return true; }} /> : null}
        </Card>
      ) : null}

      <Section title={openItems.length ? `Open items (${openItems.length})` : 'Open items'}>
        {!openItems.length ? <Hint>None – every invoice of this month was read.</Hint> : <Hint>Open the PDF, type the figures (or say it counts as it is), or leave it out (not an invoice, a copy…). Open items are not in the VAT until then.</Hint>}
        {openItems.map(row)}
      </Section>

      <Section title="Sales (incl. VAT)">
        {(m.shops.length ? m.shops : ['Business']).map((shop) => <SalesCard key={shop} ym={ym} shop={shop} sales={m.sales[shop]} closed={closed} call={call} onSaved={load} />)}
      </Section>

      <Section title={`Invoices counted (${counted.length})`}>
        {counted.map(row)}
        {!closed ? (adding ? <InvoiceCard x={{ key: '', shop: m.shops[0] || '', date: `${ym}-01` }} adding closed={false} fix={fix} shops={m.shops} onBack={() => setAdding(false)} />
          : <Btn testID="hist-add" title="Add an invoice by hand" icon="➕" size="md" variant="secondary" onPress={() => setAdding(true)} />) : null}
      </Section>
      {other.length ? <Section title={`Not counted (${other.length})`}>{other.map(row)}</Section> : null}

      {!closed ? (
        <Btn testID="hist-close" title={s.open ? `Close the month (${s.open} open first)` : 'Close the month'} icon="✅" variant="success" disabled={!!s.open || !!busy}
          onPress={async () => {
            const ok = await ui.confirm({ title: `Close ${ymLabel(ym)}?`, message: `VAT on sales ${money(s.output_vat)}, on invoices ${money(s.input_vat)}: ${s.net >= 0 ? 'to pay' : 'refund'} ${money(Math.abs(s.net))}. It can be opened again by the owner or an admin.`, confirmText: 'Close it' });
            if (!ok) return;
            const r = await call({ kind: 'hist_close', ym }, 'Closing…');
            if (r) { ui.toast('Month closed'); load(); }
          }} />
      ) : null}
    </Screen>
  );
}

// One invoice: open the PDF, correct the figures, count it as it is, or leave it out (or a new one typed in).
function InvoiceCard({ x, closed, fix, shops, adding, onBack }) {
  const [f, setF] = useState({
    supplier: x.supplier || '', invoice_no: x.invoice_no || '', date: x.date || '', shop: x.shop || '',
    subtotal: x.subtotal === null || x.subtotal === undefined ? '' : String(x.subtotal), vat: x.vat === null || x.vat === undefined ? '' : String(x.vat),
    total: x.total === null || x.total === undefined ? '' : String(x.total),
  });
  const set = (k) => (v) => setF({ ...f, [k]: v });
  return (
    <Card>
      {x.url ? <Btn testID="hist-pdf" title="Open the PDF" icon="📄" size="md" variant="info" onPress={() => Linking.openURL(x.url).catch(() => {})} /> : null}
      {x.file && !adding ? <Hint>{`File: ${x.file}`}</Hint> : null}
      {closed ? <Hint>The month is closed – open it again to change anything.</Hint> : (
        <>
          {adding && shops.length > 1 ? <Chips value={f.shop} onChange={set('shop')} options={shops.map((s) => ({ value: s, label: s }))} /> : null}
          <Field testID="hist-f-supplier" label="Supplier" value={f.supplier} onChangeText={set('supplier')} />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 150, flexGrow: 1 }}><Field testID="hist-f-no" label="Invoice number" value={f.invoice_no} onChangeText={set('invoice_no')} /></View>
            <View style={{ flexBasis: 150, flexGrow: 1 }}><Field testID="hist-f-date" label="Date (YYYY-MM-DD)" value={f.date} onChangeText={set('date')} /></View>
          </View>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID="hist-f-sub" label="Before VAT" value={f.subtotal} onChange={set('subtotal')} /></View>
            <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID="hist-f-vat" label="VAT" value={f.vat} onChange={set('vat')} /></View>
            <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID="hist-f-total" label="Total" value={f.total} onChange={set('total')} /></View>
          </View>
          <Hint>A credit note: type the amounts with a minus.</Hint>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            {adding ? <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={onBack} /> : null}
            <Btn testID="hist-save" title={adding ? 'Add it' : 'Save these figures'} size="md" variant="success" style={{ flex: 1 }}
              onPress={() => fix(adding ? { action: 'add', fields: f } : { ikey: x.key, action: 'edit', fields: f }, adding ? 'Added' : 'Saved')} />
            {!adding && x.status === 'check' && x.total !== null && x.vat !== null ? <Btn testID="hist-ok" title="It is right as read" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => fix({ ikey: x.key, action: 'ok' }, 'Counted')} /> : null}
          </View>
          {!adding && x.status !== 'excluded' ? <ReasonButton testID="hist-exclude" title="Leave it out" prompt="Why? (not an invoice, a copy, another business…)" confirm="Leave it out" onDo={(w) => { fix({ ikey: x.key, action: 'exclude', reason: w }, 'Left out'); return true; }} /> : null}
          {!adding && ['excluded', 'dup', 'after'].includes(x.status) ? <Hint>Saving the figures counts it in this month after all.</Hint> : null}
        </>
      )}
    </Card>
  );
}

// The sales of one shop: the whole month, or day by day.
function SalesCard({ ym, shop, sales, closed, call, onSaved }) {
  const ui = useUI();
  const d = (sales && sales.detail) || {};
  const [mode, setMode] = useState(sales ? sales.mode : 'month');
  const [month, setMonth] = useState({ std: d.month && d.month.std !== undefined ? String(d.month.std) : '', zero: d.month && d.month.zero !== undefined ? String(d.month.zero) : '' });
  const [days, setDays] = useState(() => { const o = {}; Object.keys(d.days || {}).forEach((k) => { o[String(+k)] = { std: String(d.days[k].std ?? ''), zero: String(d.days[k].zero ?? '') }; }); return o; });
  const [edit, setEdit] = useState(!sales || !sales.entered);
  const n = daysIn(ym);
  const save = async () => {
    const r = await call({ kind: 'hist_sales', ym, shop, mode, month, days }, 'Saving the sales…');
    if (r) { ui.toast(`${shop}: VAT on sales ${money(r.sales.vat)}`); setEdit(false); onSaved && onSaved(); }
  };
  const setDay = (day, k, v) => setDays({ ...days, [day]: { ...(days[day] || {}), [k]: v } });
  return (
    <Card>
      <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>{shop}</Text>
      {sales && sales.entered && !edit ? (
        <>
          <Hint>{`${sales.mode === 'day' ? 'Day by day' : 'Whole month'}: ${money(sales.std)} standard-rated + ${money(sales.zero)} zero-rated → VAT ${money(sales.vat)}`}</Hint>
          {!closed ? <Btn title="Change the sales" size="sm" variant="ghost" onPress={() => setEdit(true)} /> : null}
        </>
      ) : closed ? <Hint>No sales were entered.</Hint> : (
        <>
          <Chips value={mode} onChange={setMode} testIDPrefix="hist-mode" options={[{ value: 'month', label: 'Whole month' }, { value: 'day', label: 'Day by day' }]} />
          {mode === 'month' ? (
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="hist-s-std" label="Standard-rated sales" value={month.std} onChange={(v) => setMonth({ ...month, std: v })} /></View>
              <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="hist-s-zero" label="Zero-rated sales" value={month.zero} onChange={(v) => setMonth({ ...month, zero: v })} /></View>
            </View>
          ) : (
            Array.from({ length: n }, (_, i) => String(i + 1)).map((day) => (
              <View key={day} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
                <Text style={{ width: 34, fontSize: 16, fontWeight: '800', color: C.text, paddingBottom: 14 }}>{day}</Text>
                <View style={{ flex: 1 }}><MoneyField testID={`hist-d-${day}`} label={day === '1' ? 'Standard-rated' : ''} value={(days[day] || {}).std || ''} onChange={(v) => setDay(day, 'std', v)} /></View>
                <View style={{ flex: 1 }}><MoneyField testID={`hist-dz-${day}`} label={day === '1' ? 'Zero-rated' : ''} value={(days[day] || {}).zero || ''} onChange={(v) => setDay(day, 'zero', v)} /></View>
              </View>
            ))
          )}
          <Hint>The till totals, VAT included. The VAT on sales is worked out at the rate of each day (15% until 31 July 2025, 12.5% from 1 August 2025).</Hint>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {sales && sales.entered ? <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(false)} /> : null}
            <Btn testID="hist-s-save" title="Save the sales" icon="💾" size="md" variant="success" style={{ flex: 1 }} onPress={save} />
          </View>
        </>
      )}
    </Card>
  );
}
