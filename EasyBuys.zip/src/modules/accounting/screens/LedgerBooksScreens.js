// Release 03: Accounts payable and Accounts receivable – the list (with the ageing), then one supplier's / person's
// ledger with a running balance. PDF / Excel from the shared report screen.
import React, { useMemo, useState } from 'react';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, Field, Chips, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Stats, Hint, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { can } from '../../../services/access.js';
import * as LB from '../ledgers03.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const tryIt = (f, d) => { try { return { v: f(), err: null }; } catch (e) { return { v: d, err: e && e.message ? e.message : String(e) }; } };

function Ageing({ keys, labels, ageing, testID }) {
  return <Stats items={keys.map((k) => ({ label: labels[k], value: $(ageing[k]), testID: `${testID}-${k}`, color: k !== 'current' && k !== 'd30' && ageing[k] > 0.004 ? C.warn : undefined }))} />;
}
function LedgerLines({ from, opening, lines, closing, prefix }) {
  return (
    <Section title="Ledger">
      <ListItem testID={`${prefix}-open`} title="Opening balance" sub={from} right={$(opening)} />
      {lines.map((l, i) => (
        <ListItem key={`${l.date}-${i}`} testID={`${prefix}-line-${i}`} title={`${l.date} · ${l.what}`}
          sub={[l.ref, l.due ? `due ${l.due}` : '', l.shop, l.items].filter(Boolean).join(' · ') || undefined}
          right={$(l.balance)} rightSub={l.charge ? `+ ${$(l.charge)}` : `− ${$(l.credit)}`} />
      ))}
      {!lines.length ? <Text style={{ color: C.sub }}>Nothing in this period.</Text> : null}
      <ListItem testID={`${prefix}-close`} title="Closing balance" right={$(closing)} tone={closing > 0.004 ? 'warn' : undefined} />
    </Section>
  );
}

// ---------------------------------------------------------------- accounts payable
export function AccountsPayableScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [from, to, setRange] = usePeriod('thismonth', 'ledger-period');
  const [q, setQ] = useState('');
  const sup = params.supplier || null;
  const { v: d, err } = useMemo(() => tryIt(() => (sup ? LB.apLedger(sup, from, to) : LB.apSummary(from, to)), null), [sup, from, to]);
  const report = () => nav.push('ReportView', { kind: 'ledger_ap', from, to, ...(sup ? { supplier: sup } : {}) });
  if (sup) {
    return (
      <Screen title={d ? d.supplier.name : 'Supplier ledger'} subtitle={`Accounts payable · ${from} to ${to}`}
        footer={<Btn testID="ap-pdf" title="PDF / Excel" icon="📄" variant="primary" onPress={report} />}>
        <PeriodPicker testID="ap-period" from={from} to={to} onChange={setRange} />
        {err ? <Banner tone="danger" message={err} /> : null}
        {d ? (
          <>
            <Stats items={[{ label: 'Opening', value: $(d.opening) }, { label: 'Invoices', value: $(d.invoicesTotal) }, { label: 'Credit notes', value: $(d.creditsTotal) }, { label: 'Payments', value: $(d.paymentsTotal) }, { label: 'Closing', value: $(d.closing), testID: 'ap-closing' }]} />
            <LedgerLines from={from} opening={d.opening} lines={d.lines} closing={d.closing} prefix="apl" />
            <Section title={`Owing at ${to}, by due date`}><Ageing keys={LB.AP_AGE} labels={LB.AP_AGE_LABEL} ageing={d.ageing} testID="apl-age" /></Section>
            {can(user, 'payments_make') || can(user, 'invoices_check') ? <Btn testID="ap-statement" title="Supplier statement & cheques" icon="🧾" size="md" variant="secondary" onPress={() => nav.push('ApSupplierStatement', { supplierUid: sup })} /> : null}
          </>
        ) : null}
      </Screen>
    );
  }
  const ql = q.trim().toLowerCase();
  const rows = d ? d.rows.filter((r) => !ql || r.name.toLowerCase().includes(ql)) : [];
  return (
    <Screen title="Accounts payable" subtitle={d ? `${d.totals.suppliers} suppliers · we owe ${$(d.totals.closing)}` : 'Creditors'}
      footer={<Btn testID="ap-pdf" title="All suppliers – PDF / Excel" icon="📄" variant="primary" onPress={report} />}>
      <Hint>What we owe each supplier (void invoices are left out). Tap a supplier for their ledger: every invoice, credit note and payment with the balance after each.</Hint>
      <PeriodPicker testID="ap-period" from={from} to={to} onChange={setRange} />
      {err ? <Banner tone="danger" message={err} /> : null}
      {d ? (
        <>
          <Stats items={[{ label: 'Opening', value: $(d.totals.opening) }, { label: 'Invoices', value: $(d.totals.invoices) }, { label: 'Paid', value: $(d.totals.payments) }, { label: 'We owe', value: $(d.totals.closing), testID: 'ap-total' }]} />
          <Section title={`Owing at ${to}, by due date`}><Ageing keys={LB.AP_AGE} labels={LB.AP_AGE_LABEL} ageing={d.totals.ageing} testID="ap-age" /></Section>
          <Field testID="ap-q" label="Search" value={q} onChangeText={setQ} />
          <Section title="Suppliers">
            {!rows.length ? <Banner tone="info" message="No supplier has anything in this period or a balance." /> : null}
            {rows.map((r) => (
              <ListItem key={r.supplierUid} testID={`ap-${r.supplierUid}`} title={r.name} right={$(r.closing)} rightSub={`opening ${$(r.opening)}`}
                tone={r.ageing.d60 + r.ageing.d90 + r.ageing.over90 > 0.004 ? 'warn' : undefined}
                sub={`Invoices ${$(r.invoices)} · paid ${$(r.payments)}${r.ageing.current < r.closing - 0.004 ? ` · late ${$(r2(r.closing - r.ageing.current))}` : ''}`}
                onPress={() => nav.push('AccountsPayable', { supplier: r.supplierUid })} />
            ))}
          </Section>
        </>
      ) : null}
    </Screen>
  );
}
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// ---------------------------------------------------------------- accounts receivable
export function AccountsReceivableScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [from, to, setRange] = usePeriod('thismonth', 'ledger-period');
  const [q, setQ] = useState('');
  const [type, setType] = useState('all');
  const key = params.key || null;
  const { v: d, err } = useMemo(() => tryIt(() => (key ? LB.arLedger(key, from, to) : LB.arSummary(from, to)), null), [key, from, to]);
  const report = () => nav.push('ReportView', { kind: 'ledger_ar', from, to, ...(key ? { key } : {}) });
  if (key) {
    return (
      <Screen title={d ? d.name : 'Ledger'} subtitle={`Accounts receivable · ${from} to ${to}`}
        footer={<Btn testID="ar-pdf" title="PDF / Excel" icon="📄" variant="primary" onPress={report} />}>
        <PeriodPicker testID="ar-period" from={from} to={to} onChange={setRange} />
        {err ? <Banner tone="danger" message={err} /> : null}
        {d ? (
          <>
            <Stats items={[{ label: 'Opening', value: $(d.opening) }, { label: 'Closing', value: $(d.closing), testID: 'ar-closing' }].concat(d.owingNow !== null && d.owingNow !== undefined ? [{ label: 'Owing now', value: $(d.owingNow) }] : [])} />
            {d.note ? <Hint>{d.note}</Hint> : null}
            <LedgerLines from={from} opening={d.opening} lines={d.lines} closing={d.closing} prefix="arl" />
            <Section title="How old"><Ageing keys={LB.AR_AGE} labels={LB.AR_AGE_LABEL} ageing={d.ageing} testID="arl-age" /></Section>
            {d.type === 'staff' && can(user, 'owed_view') ? <Btn testID="ar-person" title="Open in Who owes us" icon="👤" size="md" variant="secondary" onPress={() => nav.push('OwedPerson', { uid: key.slice(6) })} /> : null}
          </>
        ) : null}
      </Screen>
    );
  }
  const ql = q.trim().toLowerCase();
  const rows = d ? d.rows.filter((r) => (type === 'all' || r.type === type) && (!ql || r.name.toLowerCase().includes(ql))) : [];
  return (
    <Screen title="Accounts receivable" subtitle={d ? `${d.totals.people} owe us · ${$(d.totals.owing)}` : 'Debtors'}
      footer={<Btn testID="ar-pdf" title="Everyone – PDF / Excel" icon="📄" variant="primary" onPress={report} />}>
      <Hint>Who owes us: staff (Aronium staff credit, advances, loans, charges) and customers on account in Aronium. The balances are the latest the app has. Tap a name for their ledger in the period.</Hint>
      <PeriodPicker testID="ar-period" from={from} to={to} onChange={setRange} />
      {err ? <Banner tone="danger" message={err} /> : null}
      {d ? (
        <>
          <Stats items={[{ label: 'Owed to us', value: $(d.totals.owing), testID: 'ar-total' }, { label: 'Staff', value: $(d.totals.staff) }, { label: 'Customers', value: $(d.totals.customers) }]} />
          <Section title="How old"><Ageing keys={LB.AR_AGE} labels={LB.AR_AGE_LABEL} ageing={d.totals.ageing} testID="ar-age" /></Section>
          <Chips value={type} onChange={setType} testIDPrefix="ar-type" options={[{ value: 'all', label: 'Everyone' }, { value: 'staff', label: 'Staff' }, { value: 'customer', label: 'Customers' }]} />
          <Field testID="ar-q" label="Search" value={q} onChangeText={setQ} />
          <Card>
            {!rows.length ? <Text style={{ color: C.sub }}>Nobody owes anything.</Text> : null}
            {rows.map((r) => (
              <ListItem key={r.key} testID={`ar-${r.key}`} title={`${r.name}${r.type === 'staff' ? ' (staff)' : ''}`} right={$(r.owing)} sub={r.sub || undefined}
                tone={r.ageing.d90 + r.ageing.over90 > 0.004 ? 'warn' : undefined} onPress={() => nav.push('AccountsReceivable', { key: r.key })} />
            ))}
          </Card>
        </>
      ) : null}
    </Screen>
  );
}
