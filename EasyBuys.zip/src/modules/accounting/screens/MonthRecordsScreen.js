// 1.0.0 build 44 (owner, 10 Nov): "Month records" – the month's VAT return worked out by itself, and every entry behind
// it (each shop's sales for each day, each supplier invoice) to look at, type in if missing, and tick as checked.
// Any month – earlier months too – unless the books are closed for it.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Select, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { MoneyField, ListItem, Hint, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import * as MR from '../monthRecords.js';
import * as F from '../full.js';
import * as A from '../service.js';

const $ = (n) => `${Number(n) < 0 ? '−' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayLabel = (d) => `${DAY[new Date(`${d}T00:00:00Z`).getUTCDay()]} ${Number(d.slice(8, 10))}`;
const shopsList = () => { try { return require('../../admin/service.js').listShops().filter((s) => s.active && /^S\d+$/.test(String(s.code))); } catch (e) { return []; } };
const AP = () => require('../../payables/service.js');

function ReturnCard({ ym, nav, ui }) {
  let v = null; let tk = null;
  try { v = require('../../payroll/returns.js').vatReturnFRCS(ym); tk = v.ticks; } catch (e) { v = null; }
  if (!v) return null;
  const pay = v.lines[13] >= 0;
  return (
    <Card tone={tk && tk.all ? 'success' : 'warn'}>
      <H>{`VAT return – ${ymLabel(ym)} (all shops)`}</H>
      <Text testID="mr-return" style={{ fontSize: 22, fontWeight: '900', color: pay ? C.danger : C.success }}>{pay ? `To pay FRCS ${$(v.lines[13])}` : `To claim from FRCS ${$(-v.lines[13])}`}</Text>
      <Text style={{ fontSize: 14, color: C.text }}>{`VAT in sales ${$(v.lines[6])} − VAT on purchases ${$(v.lines[12])}`}</Text>
      {tk ? <Text testID="mr-ticks" style={{ fontSize: 16, fontWeight: '800', color: tk.all ? C.success : C.danger }}>{tk.all ? '✅ Every entry checked' : `☐ ${tk.done} of ${tk.total} entries checked – ${tk.left} still to check`}</Text> : null}
      <Hint>The app works the return out by itself. Tick each day and each invoice below once you have looked at it – only then is the figure safe to send to FRCS.</Hint>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="mr-open-return" title="Open the VAT return" icon="🧾" variant="secondary" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('TaxReturn', { kind: 'vat', period: ym })} />
        <Btn testID="mr-excel" title="Excel – all workings" icon="📗" variant="secondary" size="md" style={{ flexGrow: 1 }} onPress={() => { const { shareReport } = require('../../../platform/files.js'); shareReport(require('../../payroll/returnsReports.js').vatWorkbookReport(ym), 'xlsx').catch((e) => ui.error(e)); }} />
      </View>
    </Card>
  );
}

export function MonthRecordsScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const shops = shopsList();
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [shop, setShop] = useState(params.shop || user.shop_code || (shops[0] || {}).code || 'S1');
  const [tab, setTab] = useState(params.tab || 'sales');
  const [open, setOpen] = useState(params.date || null);
  const [typing, setTyping] = useState(false);
  const [form, setForm] = useState({ standard: '', zero: '', via: '', note: '' });
  const [n, bump] = useState(0);
  const [fixing, setFixing] = useState(false);
  const [fix, setFix] = useState({ standard: '', zero: '', reason: '' });
  const isBoss = ['owner', 'admin'].includes(user.role);
  let m = null;
  try { m = MR.monthRecords({ ym, shop }); } catch (e) { m = null; }
  const mayType = can('accounts_journal');
  const money = F.moneyOptions();
  const via = form.via || (money.find((x) => x.value === `cash:${shop}`) || money[0] || {}).value || '';
  const vatNow = MR.saleVat(Number(form.standard) || 0, ym);
  const run = (fn, msg) => { try { fn(); if (msg) ui.toast(msg); bump((x) => x + 1); return true; } catch (e) { ui.error(e); return false; } };
  const goTo = (d) => { setOpen(open === d ? null : d); setTyping(false); setFixing(false); setForm((o) => ({ standard: '', zero: '', via: o.via, note: '' })); };
  const nextLeft = (after) => { const left = m.days.filter((x) => !x.future && x.date > after && !MR.dayChecked(shop, x)); return left.length ? left[0].date : null; };
  if (!m) return <Screen title="Month records"><Banner tone="danger" message="Could not read the month." /></Screen>;
  const past = m.days.filter((d) => !d.future);
  const doneDays = past.filter((d) => MR.dayChecked(shop, d)).length;
  return (
    <Screen title="Month records" subtitle={`${ymLabel(ym)} · ${shop}`}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn testID="mr-prev" title="◀ Month before" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setYm(MR.ymShift(ym, -1)); setOpen(null); }} />
        <Btn testID="mr-next" title="Month after ▶" size="md" variant="secondary" style={{ flex: 1 }} disabled={ym >= dateStr().slice(0, 7)} onPress={() => { setYm(MR.ymShift(ym, 1)); setOpen(null); }} />
      </View>
      <ReturnCard key={`${ym}-${n}`} ym={ym} nav={nav} ui={ui} />
      {m.locked ? <Banner testID="mr-locked" tone="warn" title="This month is closed" message={`The books are closed up to ${m.lockDate}. Nothing can be added or ticked – the owner can reopen it (Reports › Close the month).`} /> : null}
      {shops.length > 1 ? <Chips testIDPrefix="mr-shop" value={shop} onChange={(v) => { setShop(v); setOpen(null); }} options={shops.map((s) => ({ value: s.code, label: s.code }))} /> : null}
      <Chips testIDPrefix="mr-tab" value={tab} onChange={setTab} options={[
        { value: 'sales', label: `Sales ${doneDays}/${past.length} ✓` },
        { value: 'invoices', label: `Invoices ${m.invoices.filter((i) => i.status !== 'to_check').length}/${m.invoices.length} ✓` },
        { value: 'other', label: `Other (${m.other.length})` }]} />
      {tab === 'sales' ? (
        <>
          <Text testID="mr-total" style={{ fontSize: 15, color: C.text }}>{`${shop} sales ${$(m.totals.total)} · zero-rated ${$(m.totals.zero)} · VAT ${$(m.totals.vat)}`}</Text>
          {past.map((d) => {
            const ok = MR.dayChecked(shop, d);
            return (
              <View key={d.date}>
                <ListItem testID={`mr-day-${d.date}`} title={`${ok ? (ok.closed ? '🔒' : '✅') : '☐'} ${dayLabel(d.date)} · ${d.total ? $(d.total) : ok && ok.closed ? 'shop closed' : 'no sales'}`}
                  sub={d.total ? `${d.kinds.join(' + ')} · zero-rated ${$(d.zero)} · VAT ${$(d.vat)}` : 'Nothing recorded'}
                  tone={ok ? undefined : d.total ? undefined : 'warn'} onPress={() => goTo(d.date)} />
                {open === d.date ? (
                  <Card testID={`mr-open-${d.date}`}>
                    {d.rows.map((r, k) => <ListItem key={k} title={r.ref || 'Sale'} sub={`zero-rated ${$(r.zero)} · VAT ${$(r.vat)} · tap to open`} right={$(r.total)} onPress={r.go ? () => nav.push(r.go[0], r.go[1]) : undefined} />)}
                    {!d.rows.length ? <Hint>No End of day, till balance or typed sale for this day. If the shop was open, type the sales below (from the paper Z report). If it was closed, press Shop closed.</Hint> : null}
                    {d.typed.map((j) => (mayType && !m.locked ? <ReasonButton key={j.uid} testID={`mr-untype-${d.date}`} title={`Remove ${j.meta.correction ? 'correction' : 'typed'} ${$(j.meta.total)}`} prompt="Why remove it? (e.g. typed twice)" confirm="Remove" variant="ghost" size="sm" onDo={(w) => run(() => A.voidJournal(user, j.uid, w), 'Removed')} /> : null))}
                    {mayType && !m.locked ? (
                      <>
                        {ok ? <Btn testID="mr-untick" title={`${ok.closed ? 'Shop closed' : 'Checked'} – ${ok.by} – take the tick off`} variant="ghost" size="sm" onPress={() => run(() => MR.uncheckDay(user, { date: d.date, shop }))} />
                          : d.total ? <Btn testID="mr-tick" title="Sales are right – tick it ✓" variant="success" size="md" onPress={() => { if (run(() => MR.checkDay(user, { date: d.date, shop }), 'Ticked')) setOpen(nextLeft(d.date)); }} />
                          : <Btn testID="mr-tick-closed" title="Shop closed – tick it ✓" icon="🔒" variant="success" size="md" onPress={() => { if (run(() => MR.checkDay(user, { date: d.date, shop, closed: true }), 'Marked as shop closed')) setOpen(nextLeft(d.date)); }} />}
                        {isBoss && !fixing ? <Btn testID="mr-change" title="Change this day's sales" icon="✏️" variant="secondary" size="md" onPress={() => { setFixing(true); setTyping(false); setFix({ standard: String(Math.round((d.total - d.zero) * 100) / 100), zero: String(d.zero || 0), reason: '' }); }} /> : null}
                        {isBoss && fixing ? (
                          <>
                            <Hint>{`Now ${$(d.total)} (zero-rated ${$(d.zero)}). Type what the day's sales really were – the difference is saved as a correction with your reason, and the day is ticked for the new figures.`}</Hint>
                            <MoneyField testID="mr-fix-std" label="VAT sales (incl. VAT)" value={fix.standard} onChange={(v) => setFix((o) => ({ ...o, standard: v }))} />
                            <MoneyField testID="mr-fix-zero" label="Zero-rated sales (no VAT)" value={fix.zero} onChange={(v) => setFix((o) => ({ ...o, zero: v }))} />
                            <Field testID="mr-fix-reason" label="Why? (e.g. paper Z report shows 1,250.00)" value={fix.reason} onChangeText={(v) => setFix((o) => ({ ...o, reason: v }))} />
                            <View style={{ flexDirection: 'row', gap: 8 }}>
                              <Btn testID="mr-fix-save" title="Save the change" icon="💾" variant="success" size="md" style={{ flex: 1 }} onPress={() => { if (run(() => MR.correctDaySales(user, { date: d.date, shop, standard: fix.standard, zero: fix.zero, reason: fix.reason }), 'Changed and ticked')) setFixing(false); }} />
                              <Btn testID="mr-fix-cancel" title="Cancel" variant="ghost" size="md" onPress={() => setFixing(false)} />
                            </View>
                          </>
                        ) : null}
                        {!typing ? <Btn testID="mr-type" title={d.total ? 'Add sales that are missing' : 'Type the sales for this day'} icon="✍️" variant="secondary" size="md" onPress={() => setTyping(true)} /> : (
                          <>
                            <MoneyField testID="mr-std" label="VAT sales (incl. VAT)" value={form.standard} onChange={(v) => setForm((o) => ({ ...o, standard: v }))} />
                            <MoneyField testID="mr-zero" label="Zero-rated sales (no VAT)" value={form.zero} onChange={(v) => setForm((o) => ({ ...o, zero: v }))} />
                            <Text testID="mr-vat-now" style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`VAT in it: ${$(vatNow)} · total ${$((Number(form.standard) || 0) + (Number(form.zero) || 0))}`}</Text>
                            {money.length > 1 ? <Select testID="mr-via" label="The money came in as" value={via} onChange={(v) => setForm((o) => ({ ...o, via: v }))} options={money} /> : null}
                            <Field testID="mr-note" label="Note (optional)" value={form.note} onChangeText={(v) => setForm((o) => ({ ...o, note: v }))} />
                            {d.total ? <Hint>{`This day already has ${$(d.total)} – only type what is not in it yet.`}</Hint> : null}
                            <Btn testID="mr-save" title="Save the sales" icon="💾" variant="success" onPress={() => { if (run(() => MR.typeDaySale(user, { date: d.date, shop, standard: form.standard, zero: form.zero, via, note: form.note }), 'Saved – now check and tick the day')) { setTyping(false); setForm((o) => ({ standard: '', zero: '', via: o.via, note: '' })); } }} />
                          </>
                        )}
                      </>
                    ) : null}
                  </Card>
                ) : null}
              </View>
            );
          })}
        </>
      ) : null}
      {tab === 'invoices' ? (
        <>
          {can('invoices_enter') || mayType ? <Btn testID="mr-new-inv" title={`Add an invoice for ${ymLabel(ym)}`} icon="🧾" variant="info" size="md" onPress={() => nav.push('ApInvoiceEdit', { date: ym === dateStr().slice(0, 7) ? dateStr() : MR.monthEnd(ym), shopCode: shop })} /> : null}
          {!m.invoices.length ? <Hint>No supplier invoices dated in this month.</Hint> : null}
          {m.invoices.map((i) => {
            let vs = null; try { vs = AP().vatStatusOf(i); } catch (e) { vs = null; }
            const ok = i.status !== 'to_check';
            return (
              <View key={i.uid}>
                <ListItem testID={`mr-inv-${i.invoice_no || i.uid}`} title={`${ok ? '✅' : '☐'} ${i.invoice_date.slice(8)} · ${i.supplier_name} ${i.invoice_no || ''}`.trim()} sub={vs ? vs.text : ''} right={$(i.total)}
                  tone={vs && vs.level === 'bad' ? 'danger' : undefined} onPress={() => nav.push('ApInvoice', { uid: i.uid })} />
                {!ok && can('invoices_check') && !m.locked ? <Btn testID={`mr-inv-tick-${i.invoice_no || i.uid}`} title={vs && vs.level === 'bad' ? 'VAT does not fit – open and fix it first' : 'VAT and total correct – tick it ✓'} variant={vs && vs.level === 'bad' ? 'warn' : 'success'} size="sm"
                  onPress={() => (vs && vs.level === 'bad' ? nav.push('ApInvoice', { uid: i.uid }) : run(() => AP().checkInvoice(user, i.uid), 'Ticked'))} /> : null}
              </View>
            );
          })}
        </>
      ) : null}
      {tab === 'other' ? (
        <>
          {mayType && !m.locked ? <Btn testID="mr-new-other" title="Type an expense, income or other money" icon="✍️" variant="info" size="md" onPress={() => nav.push('AcctEntry', { date: ym === dateStr().slice(0, 7) ? dateStr() : MR.monthEnd(ym), shop })} /> : null}
          {!m.other.length ? <Hint>Nothing else typed in this month.</Hint> : null}
          {m.other.map((j) => <ListItem key={j.uid} title={`${j.jdate.slice(8)} · ${j.memo}`} sub={`${j.kind}${j.meta.vat ? ` · VAT ${$(j.meta.vat)}` : ''}`} right={$(j.meta.total)} onPress={() => nav.push('AcctEntries', {})} />)}
        </>
      ) : null}
    </Screen>
  );
}
