// v3.9.8 Monthly business report (part of Month close) and customer accounts. Both can be made into a PDF / Excel any
// time from here or from Reports › Business insight.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, Field, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Stats, Hint, Explain } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import * as MR from '../monthReport.js';
import { customerAccounts } from '../insightReports.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const sign = (x) => (x === null || x === undefined ? '' : `${x >= 0 ? '+' : ''}${x}%`);
const STATE = { done: ['✅ Target reached', 'success'], better: ['📈 Better', 'success'], same: ['➖ No change', 'warn'], worse: ['⚠️ Worse', 'danger'], unknown: ['– Not measured yet', undefined] };

function Bar({ label, value, max, sub, testID }) {
  const w = max > 0 ? Math.max(2, Math.round((value / max) * 100)) : 0;
  return (
    <View testID={testID} style={{ gap: 2 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ fontSize: 14, color: C.text, fontWeight: '700' }}>{label}</Text>
        <Text style={{ fontSize: 14, color: C.sub }}>{sub}</Text>
      </View>
      <View style={{ height: 10, borderRadius: 5, backgroundColor: C.border }}>
        <View style={{ width: `${w}%`, height: 10, borderRadius: 5, backgroundColor: C.info }} />
      </View>
    </View>
  );
}

export function MonthReportScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const lastMonth = MR.addMonths(dateStr().slice(0, 7), -1);
  const [ym, setYm] = useState(params.ym || lastMonth);
  const [n, bump] = useState(0);
  const boss = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const r = useMemo(() => { try { return MR.monthReport(ym, { fresh: n > 0 }); } catch (e) { return { error: e.message || String(e) }; } }, [ym, n]);
  const refresh = () => bump((x) => x + 1);
  const doc = (fmt) => nav.push('ReportView', { kind: 'biz_month', from: `${ym}-01`, to: `${ym}-01`, format: fmt });
  if (r.error) return <Screen title="Monthly business report"><Banner tone="danger" message={r.error} /></Screen>;
  const h = r.headline;
  const maxHour = Math.max(0, ...r.time.hours.map((x) => x.perDay));
  const maxDay = Math.max(0, ...r.time.weekday.map((x) => x.avg));
  return (
    <Screen title="Monthly business report" subtitle={`${ymLabel(ym)} · made ${String(r.made).slice(0, 16)}`}
      footer={<Btn testID="mr-pdf" title="PDF / Excel / share" icon="📄" variant="primary" onPress={() => doc()} />}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Btn testID="mr-prev" title="‹" size="sm" variant="secondary" onPress={() => setYm(MR.addMonths(ym, -1))} />
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, minWidth: 110, textAlign: 'center' }}>{ymLabel(ym)}</Text>
        <Btn testID="mr-next" title="›" size="sm" variant="secondary" onPress={() => setYm(MR.addMonths(ym, 1))} />
        <Btn testID="mr-refresh" title="Refresh" size="sm" variant="ghost" onPress={refresh} />
      </View>
      <Explain>Everything about the month on one page: what came in and went out, the VAT and the checks FRCS's VAT monitoring needs, the products, suppliers, staff and fuel, and a forecast for next month. At the end are a few things to improve. Keep them as the month's actions: next month this page measures the same figure again and shows whether it worked. You can make this report for any month, any time (also in Reports › Business insight).</Explain>
      <Stats items={[
        { label: 'Sales', value: $(h.sales), sub: [h.salesChange !== null ? `${sign(h.salesChange)} on last month` : null, h.salesVsLastYear !== null ? `${sign(h.salesVsLastYear)} on last year` : null].filter(Boolean).join(' · ') || null },
        { label: 'Gross profit (about)', value: $(h.grossProfit), sub: h.margin !== null ? `${h.margin}% margin` : null },
        { label: 'Wages (incl. FNPF)', value: $(h.wages), sub: h.wagesPct !== null ? `${h.wagesPct}% of sales` : null, color: h.wagesPct > 18 ? C.warn : undefined },
        { label: 'Fuel', value: $(h.fuel), sub: h.fuelChange !== null ? `${sign(h.fuelChange)} on last month` : null },
        { label: h.vatNet >= 0 ? 'VAT to pay' : 'VAT refund', value: $(Math.abs(h.vatNet)), sub: h.vatDue ? `by ${h.vatDue}` : null },
        { label: `Forecast ${ymLabel(r.forecast.ym)}`, value: $(r.forecast.sales), sub: `${$(r.forecast.low)} – ${$(r.forecast.high)}` },
      ]} />

      <Section title="Peace of mind">
        {r.calm.ok.map((t, i) => <Text key={`ok${i}`} style={{ fontSize: 15, color: C.success }}>{`✓ ${t}`}</Text>)}
        {r.calm.watch.map((t, i) => <Text key={`w${i}`} testID={`mr-watch-${i}`} style={{ fontSize: 15, color: C.warn, fontWeight: '700' }}>{`! ${t}`}</Text>)}
      </Section>

      {r.followUp.length ? (
        <Section title={`Last month's actions – did they work?`}>
          {r.followUp.map((a) => {
            const st = STATE[a.state] || STATE.unknown;
            const u = (v) => (v === null || v === undefined ? '–' : a.unit === '$' ? $(v) : `${v}${a.unit === '%' ? '%' : ''}`);
            return (
              <Card key={a.key} tone={st[1]}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{a.text}</Text>
                <Text testID={`mr-fu-${a.key}`} style={{ fontSize: 15, color: C[st[1]] || C.sub, fontWeight: '700' }}>{`${st[0]} · ${a.label}: ${u(a.value)} → ${u(a.now)}${a.target !== null && a.target !== undefined ? ` (target ${u(a.target)})` : ''}`}</Text>
                {boss ? (
                  <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                    <Btn testID={`mr-fu-done-${a.key}`} title={a.mark === 'done' ? 'Done ✓' : 'We did it'} size="sm" variant={a.mark === 'done' ? 'success' : 'secondary'} onPress={() => { if (act(() => MR.markAction(user, MR.addMonths(ym, -1), a.key, a.mark === 'done' ? null : 'done'))) refresh(); }} />
                    <Btn testID={`mr-fu-skip-${a.key}`} title={a.mark === 'skip' ? 'Skipped' : 'Not doing it'} size="sm" variant="ghost" onPress={() => { if (act(() => MR.markAction(user, MR.addMonths(ym, -1), a.key, a.mark === 'skip' ? null : 'skip'))) refresh(); }} />
                  </View>
                ) : null}
              </Card>
            );
          })}
        </Section>
      ) : null}

      <Section title="What to improve next month">
        {!r.suggestions.length ? <Hint>Nothing stands out this month – keep going.</Hint> : r.suggestions.map((s, i) => (
          <Card key={s.key} tone="info">
            <Text testID={`mr-sug-${s.key}`} style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${i + 1}. ${s.text}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{s.why}</Text>
          </Card>
        ))}
        {r.kept ? <Hint>{`Kept as this month's actions by ${r.kept.by} (${String(r.kept.at).slice(0, 10)}). Next month's report checks them.`}</Hint> : null}
        {boss && r.suggestions.length ? <Btn testID="mr-keep" title={r.kept ? 'Keep them again (replace)' : 'Keep these as the actions for next month'} icon="📌" size="md" variant="success" onPress={() => { if (act(() => MR.keepActions(user, ym, r.suggestions), 'Kept – next month\'s report will check them')) refresh(); }} />
          : boss && !r.kept ? <Btn testID="mr-keep" title="Mark the report as read" icon="📌" size="md" variant="secondary" onPress={() => { if (act(() => MR.keepActions(user, ym, []), 'Noted')) refresh(); }} /> : null}
      </Section>

      <Section title="VAT and FRCS VAT monitoring (VMS) checks">
        <Text style={{ fontSize: 15, color: C.text }}>{`Output VAT ${$(r.vat.output)} · Input VAT ${$(r.vat.input)} · ${r.vat.net >= 0 ? 'to pay' : 'refund'} ${$(Math.abs(r.vat.net))}${r.vat.due ? ` by ${r.vat.due}` : ''}`}</Text>
        <Text style={{ fontSize: 14, color: C.sub }}>{`Sales ${$(r.vat.sales)} (zero-rated ${$(r.vat.zeroRated)}) · purchases ${$(r.vat.purchases)}`}</Text>
        {r.vat.vms.map((v) => <ListItem key={v.key} testID={`mr-vms-${v.key}`} title={`${v.ok ? '✅' : '⚠️'} ${v.label}`} sub={v.sub || undefined} tone={v.ok ? 'success' : 'warn'} />)}
        <Btn testID="mr-vat" title="Open the VAT return" size="sm" variant="ghost" onPress={() => nav.push('VatReturn', {})} />
      </Section>

      <Section title="Sales by shop and forecast">
        {Object.entries(r.fig.byShop).map(([shop, s]) => (
          <ListItem key={shop} testID={`mr-shop-${shop}`} title={`${shop}: ${$(s.sales)}`} sub={`${s.days} trading days · VAT ${$(s.vat)} · ${ymLabel(r.forecast.ym)} forecast ${$(r.forecast.byShop[shop] || 0)}`} />
        ))}
        {r.forecast.note ? <Hint>{r.forecast.note}</Hint> : <Hint>{`Forecast from the last ${r.forecast.monthsUsed} months${r.forecast.usedLastYear ? ', moved by how last year went' : ''}. Costs expected: wages ${$(r.forecast.wages)}, fuel ${$(r.forecast.fuel)}, supplier invoices ${$(r.forecast.purchases)}.`}</Hint>}
      </Section>

      {r.time.hours.length || r.time.days.length ? (
        <Section title="When the money comes in">
          {r.time.best ? <Text style={{ fontSize: 15, color: C.text }}>{`Best day ${r.time.best.day} ${r.time.best.date} ${$(r.time.best.value)} · quietest ${r.time.worst.day} ${r.time.worst.date} ${$(r.time.worst.value)}`}</Text> : null}
          {r.time.avgSale ? <Text style={{ fontSize: 15, color: C.text }}>{`${r.time.receipts} receipts · average sale ${$(r.time.avgSale)}`}</Text> : null}
          {r.time.weekday.filter((d) => d.n).map((d) => <Bar key={d.day} testID={`mr-dow-${d.day}`} label={d.day} value={d.avg} max={maxDay} sub={`${$(d.avg)} a day`} />)}
          {r.time.hours.map((x) => <Bar key={x.hour} label={x.label} value={x.perDay} max={maxHour} sub={`${$(x.perDay)} a day · avg sale ${$(x.avgSale)}`} />)}
          {!r.time.hasActivity ? <Hint>Hourly figures come from the till PCs (Aronium Link). They show here once the till PCs send them.</Hint> : null}
        </Section>
      ) : null}

      <Section title="Products">
        <Text style={{ fontSize: 15, color: C.text }}>{`${r.products.count} products sold · ${r.products.core} of them make 80 % of sales`}</Text>
        {r.products.top.slice(0, 10).map((p) => <ListItem key={`t${p.code}${p.name}`} title={p.name} sub={`${p.qty} sold · profit about ${$(p.profit)}${p.margin !== null ? ` (${p.margin}%)` : ''}${p.change !== null ? ` · ${sign(p.change)}` : ''}`} right={$(p.value)} />)}
        {r.products.belowCost.length ? <Banner tone="danger" title={`Sold below cost (${r.products.belowCost.length})`} message={r.products.belowCost.slice(0, 6).map((p) => `${p.name} (lost ${$(Math.abs(p.profit))})`).join(' · ')} /> : null}
        {r.products.falling.length ? <Banner tone="warn" title="Dropping" message={r.products.falling.map((p) => `${p.name} ${sign(p.change)}`).join(' · ')} /> : null}
        {r.products.rising.length ? <Banner tone="success" title="Growing" message={r.products.rising.map((p) => `${p.name} ${sign(p.change)}`).join(' · ')} /> : null}
      </Section>

      <Section title="Suppliers – spend and suggested budgets">
        <Hint>The suggested budget is the usual spend (this month counted twice, plus the 3 months before) moved with the sales forecast, rounded up to $50.</Hint>
        {r.suppliers.slice(0, 20).map((s) => (
          <Card key={s.key} tone={s.overBudget > 0 ? 'warn' : undefined}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${s.name}: ${$(s.spent)}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{`3-month average ${$(s.avg3)}${s.change !== null ? ` (${sign(s.change)})` : ''} · budget ${s.budget === null ? 'none' : $(s.budget)}${s.overBudget > 0 ? ` – over by ${$(s.overBudget)}` : ''}${s.priceRises ? ` · ${s.priceRises} price rise${s.priceRises === 1 ? '' : 's'} (avg +${s.avgRise}%)` : ''}`}</Text>
            {s.suggestBudget ? (
              <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <Text testID={`mr-sb-${s.key}`} style={{ fontSize: 15, fontWeight: '700', color: C.info }}>{`Suggested budget ${$(s.suggestBudget)} a month`}</Text>
                {boss && s.uid && s.budget !== s.suggestBudget ? <Btn testID={`mr-sb-use-${s.key}`} title="Use it" size="sm" variant="secondary" onPress={() => {
                  const I = require('../../inventory/service.js');
                  const cur = I.getSupplier ? I.getSupplier(s.uid) : null;
                  if (act(() => I.saveSupplierOrdering(user, { supplierUid: s.uid, budgetWeekly: cur ? cur.budget_weekly : null, budgetMonthly: s.suggestBudget, leadDays: cur ? cur.lead_days : null, viber: cur ? cur.viber : null, orderDays: cur ? cur.order_days : null }), 'Budget saved')) refresh();
                }} /> : null}
              </View>
            ) : null}
          </Card>
        ))}
      </Section>

      {r.orders.length ? (
        <Section title="Orders coming up (from the order history)">
          {r.orders.slice(0, 15).map((o) => (
            <ListItem key={`${o.supplierUid}${o.shop}`} testID={`mr-ord-${o.supplierUid}-${o.shop}`} tone={o.due ? 'warn' : undefined} title={`${o.name} · ${o.shop}`}
              sub={`${o.every ? `Usually every ${o.every} days` : 'One order so far'} · usual order ${$(o.usual)} · last ${o.last}${o.next ? ` · next about ${o.next}` : ''}${o.lowItems ? ` · ${o.lowItems} items low (${$(o.lowValue)})` : ''}`}
              onPress={() => nav.push('AroniumInsights', {})} />
          ))}
        </Section>
      ) : null}

      <Section title="Staff">
        <Text style={{ fontSize: 15, color: C.text }}>{`Wages ${$(r.staff.gross)} + employer FNPF ${$(r.staff.fnpfEmployer)} = ${$(r.staff.cost)} for ${r.staff.people} people${r.staff.ofSales !== null ? ` · ${r.staff.ofSales}% of sales` : ''}${r.staff.salesPerWageDollar ? ` · ${$(r.staff.salesPerWageDollar)} of sales per $1 of wages` : ''}`}</Text>
        {r.staff.byShop.map((w) => <ListItem key={w.shop} title={`${w.shop}: ${$(w.cost)}`} sub={`${w.people} people`} />)}
        {r.staff.shortTotal ? <Banner tone="warn" title={`Till shortages ${$(r.staff.shortTotal)}`} message={r.staff.shortages.slice(0, 5).map((s) => `${s.name || '?'} ${$(s.amount)} (${s.n})`).join(' · ')} /> : null}
        {r.staff.cashierFlags.map((c) => <ListItem key={`${c.shop}${c.name}`} tone="warn" title={`${c.name} (${c.shop})`} sub={c.flags.join(' · ')} />)}
      </Section>

      <Section title="Fuel">
        {!r.fuel.length ? <Hint>No fuel entered this month.</Hint> : r.fuel.map((f) => (
          <ListItem key={f.item_uid} title={`${f.name || 'Vehicle'}: ${$(f.amount)}`} sub={`${f.litres} L in ${f.fills} fill${f.fills === 1 ? '' : 's'}${f.km ? ` · ${f.km} km` : ''}${f.kmpl ? ` · ${f.kmpl} km/L` : ''}${f.perKm !== null ? ` · ${$(f.perKm)} per km` : ''}${f.flagged ? ` · ${f.flagged} flagged` : ''}`} tone={f.flagged ? 'warn' : undefined} />
        ))}
      </Section>

      {r.costs.length ? (
        <Section title="Other costs by kind">
          {r.costs.slice(0, 12).map((c) => <ListItem key={c.cat} title={`${c.cat}: ${$(c.total)}`} sub={`Last month ${$(c.lastMonth)}${c.change !== null ? ` (${sign(c.change)})` : ''}`} />)}
        </Section>
      ) : null}

      <Section title="More reports (any time)">
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="mr-pending" title="Pending in & out" size="sm" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'biz_pending', from: dateStr(), to: dateStr() })} />
          <Btn testID="mr-cheques" title="Cheque timeline" size="sm" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'biz_cheques', from: `${ym}-01`, to: MR.monthRange(ym).to })} />
          <Btn testID="mr-cust" title="Customer accounts" size="sm" variant="secondary" onPress={() => nav.push('CustomerAccounts', {})} />
          <Btn testID="mr-owed" title="Who owes us (staff)" size="sm" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'who_owes_us', from: dateStr(), to: dateStr() })} />
          <Btn testID="mr-supst" title="Supplier statements" size="sm" variant="secondary" onPress={() => nav.push('ApSupplierStatement', {})} />
        </View>
      </Section>
    </Screen>
  );
}

export function CustomerAccountsScreen() {
  const { nav } = useApp();
  const [q, setQ] = useState('');
  const [from, setFrom] = useState(addDays(dateStr(), -120));
  let list = [];
  try { list = customerAccounts(); } catch (e) { list = []; }
  const ql = q.trim().toLowerCase();
  const shown = list.filter((c) => !ql || c.name.toLowerCase().includes(ql));
  const total = shown.reduce((s, c) => s + c.owing, 0);
  return (
    <Screen title="Customer accounts" subtitle={`${shown.length} owing · ${$(total)}`}
      footer={<Btn testID="ca-all" title="All accounts – PDF / Excel" icon="📄" variant="primary" onPress={() => nav.push('ReportView', { kind: 'biz_customers', from: dateStr(), to: dateStr() })} />}>
      <Hint>From Aronium (the till PCs send each account and its sales of the last 120 days). Tap a customer for their statement. Staff accounts are marked – their pay deductions are in Who owes us.</Hint>
      <Field testID="ca-q" label="Search" value={q} onChangeText={setQ} />
      <Field testID="ca-from" label="Statement from (YYYY-MM-DD)" value={from} onChangeText={setFrom} />
      {!shown.length ? <Banner tone="info" message="No customer owes anything on account (or the till PCs have not sent the accounts yet)." /> : null}
      {shown.map((c) => (
        <ListItem key={c.name} testID={`ca-${c.name}`} tone={c.age > 60 ? 'warn' : undefined} title={`${c.name}${c.staff ? ' (staff)' : ''}`} right={$(c.owing)}
          sub={`${c.shops}${c.oldest ? ` · oldest ${c.oldest} (${c.age} days)` : ''}${c.lastPayment ? ` · last paid ${c.lastPayment}` : ' · no payment seen'}`}
          onPress={() => nav.push('ReportView', { kind: 'biz_customers', from: /^\d{4}-\d{2}-\d{2}$/.test(from) ? from : addDays(dateStr(), -120), to: dateStr(), customer: c.name })} />
      ))}
    </Screen>
  );
}
