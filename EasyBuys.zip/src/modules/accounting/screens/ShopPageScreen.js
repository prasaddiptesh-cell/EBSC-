// Release 03: one page per shop – sales (output VAT), purchases (input VAT), cheques and fixed costs, month by month.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ListItem, Stats } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shopMonth, shopNames } from '../shopPage.js';
import { ymShift } from '../monthRecords.js';
import { QuickRow } from '../../home/QuickRow.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const $ = (n) => `${Number(n) < 0 ? '-' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayLabel = (d) => { const t = new Date(`${d}T00:00:00`); return `${WD[t.getDay()]} ${t.getDate()}`; };
const FREQ = { weekly: 'a week', fortnightly: 'a fortnight', monthly: 'a month', quarterly: 'a quarter', yearly: 'a year' };

export function ShopPageScreen({ params = {} }) {
  const { nav, user, screens } = useApp();
  const shops = shopNames();
  const shop = params.shop || user.shop_code || (shops[0] || {}).code || 'S1';
  const name = (shops.find((s) => s.code === shop) || {}).name || shop;
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [tab, setTab] = useState(params.tab || 'sales');
  let p = null;
  try { p = shopMonth({ shop, ym }); } catch (e) { p = null; }
  const thisMonth = ym >= dateStr().slice(0, 7);
  return (
    <Screen title={name} subtitle={ymLabel(ym)}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Btn testID="shop-prev" title="‹" size="sm" variant="secondary" onPress={() => setYm(ymShift(ym, -1))} />
        <Text style={{ flex: 1, textAlign: 'center', fontSize: 17, fontWeight: '800', color: C.text }}>{ymLabel(ym)}</Text>
        <Btn testID="shop-next" title="›" size="sm" variant="secondary" disabled={thisMonth} onPress={() => setYm(ymShift(ym, 1))} />
      </View>
      <QuickRow who={user} screens={screens} only={['invoice', 'cheque', 'receive', 'order', 'deposit', 'balance']} />
      {!p ? <Hint>This shop's month could not be worked out.</Hint> : (
        <>
          <Stats items={[
            { label: 'Sales (incl. VAT)', value: $(p.sales.total) },
            { label: 'Output VAT', value: $(p.vat.output) },
            { label: 'Purchases', value: $(p.purchases.total) },
            { label: 'Input VAT', value: $(p.vat.input) },
            { label: p.vat.net >= 0 ? 'VAT to pay' : 'VAT to claim', value: $(Math.abs(p.vat.net)), color: C.text },
            { label: 'Still to check', value: String(p.open), color: p.open ? C.warn : C.success },
          ]} />
          <Chips value={tab} onChange={setTab} testIDPrefix="shop-tab" options={[
            { value: 'sales', label: `Sales${p.sales.toCheck ? ` (${p.sales.toCheck})` : ''}` },
            { value: 'buy', label: `Purchases${p.purchases.toCheck + p.missing.length ? ` (${p.purchases.toCheck + p.missing.length})` : ''}` },
            { value: 'cheques', label: 'Cheques' },
            { value: 'fixed', label: `Fixed costs${p.fixed.overdue ? ` (${p.fixed.overdue})` : ''}` },
          ]} />
          {tab === 'sales' ? (
            <Card>
              <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`${p.sales.checked} of ${p.sales.days.length} days checked. Tap a day to check it, type missing sales, or say why the shop was closed.`}</Text>
              {p.sales.days.slice().reverse().map((d) => (
                <ListItem key={d.date} testID={`shop-day-${d.date}`} title={`${d.checked ? '✅' : '☐'} ${dayLabel(d.date)}`} right={d.total ? $(d.total) : 'no sales'}
                  sub={d.total ? `VAT ${$(d.vat)} · zero-rated ${$(d.zero)}` : 'Nothing recorded – type the sales or say why it was closed'}
                  tone={d.checked ? undefined : 'warn'} onPress={() => nav.push('MonthRecords', { ym, shop, date: d.date })} />
              ))}
            </Card>
          ) : null}
          {tab === 'buy' ? (
            <>
              {p.missing.length ? (
                <Card tone="warn">
                  <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Weekly suppliers – no invoice this week</Text>
                  {p.missing.map((m) => <ListItem key={m.supplierKey} title={m.supplier} sub={`Usually ${m.usualDay} · last ${m.lastDate} (${$(m.lastTotal)})`} tone="warn" onPress={() => nav.push('RegularSuppliers', {})} />)}
                </Card>
              ) : null}
              <Card>
                <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`${p.purchases.count} invoices · ${p.purchases.toCheck} to check · input VAT ${$(p.purchases.vat)}`}</Text>
                {!p.purchases.list.length ? <Hint>No supplier invoices for this shop this month yet.</Hint> : p.purchases.list.map((i) => (
                  <ListItem key={i.uid} testID={`shop-inv-${i.uid}`} title={`${i.status === 'to_check' ? '☐' : '✅'} ${i.supplier_name}`} sub={`${i.invoice_date} · No. ${i.invoice_no || '–'} · VAT ${$(i.vat)}`}
                    right={$(i.total)} tone={i.status === 'to_check' ? 'warn' : undefined} onPress={() => nav.push('ApInvoice', { uid: i.uid })} />
                ))}
              </Card>
            </>
          ) : null}
          {tab === 'cheques' ? (
            <Card>
              {p.cheques.map((g) => (
                <View key={g.key} style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{`${g.title} (${g.list.length})`}</Text>
                  {g.list.slice(0, 8).map((c) => <ListItem key={c.key} title={`Cheque ${c.no || '?'} · ${c.supplierName || '?'}`} sub={c.date} right={$(c.amount)} onPress={() => nav.push('ChequeTrail', c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid })} />)}
                </View>
              ))}
              <Btn testID="shop-cheques" title="All cheques and cheque books" icon="✍️" variant="secondary" size="md" onPress={() => nav.push('ChequeHome', {})} />
            </Card>
          ) : null}
          {tab === 'fixed' ? (
            <Card>
              <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`Rent, the shop loan, power, water and other regular bills of this shop: about ${$(p.fixed.monthly)} a month.`}</Text>
              {!p.fixed.list.length ? <Hint>No regular costs set up for this shop. Add them in Money › Loans & rent.</Hint> : p.fixed.list.map((x) => (
                <ListItem key={x.uid} title={x.name} sub={`${x.kind} · ${$(x.amount)} ${FREQ[x.frequency] || ''}${x.nextDue ? ` · next ${x.nextDue}` : ''}${x.balance !== null && x.balance !== undefined ? ` · balance ${$(x.balance)}` : ''}`}
                  right={x.overdue ? `${$(x.overdueAmount)} overdue` : `${$(x.monthly)}/month`} tone={x.overdue ? 'danger' : undefined} onPress={() => nav.push('LoansRent', {})} />
              ))}
            </Card>
          ) : null}
        </>
      )}
    </Screen>
  );
}
