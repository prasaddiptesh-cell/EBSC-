// Release 03: one page per shop – sales (output VAT), purchases (input VAT), cheques and fixed costs, month by month.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ListItem, Stats } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shopMonth, shopNames, shopMonthReport } from '../shopPage.js';
import { useWide } from '../../../ui/wide.js';
import { useMonthFromCloud, CloudNote } from '../../../web/cloudPages.js';
import { WebTable, WebTabs, Pill, Panel, PanelNote, SmallBtn, MonthSwitch, OutlineBtn, Attention, DarkCard } from '../../../ui/web.js';
import { ymShift } from '../monthRecords.js';
import { QuickRow } from '../../home/QuickRow.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const $ = (n) => `${Number(n) < 0 ? '-' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayLabel = (d) => { const t = new Date(`${d}T00:00:00`); return `${WD[t.getDay()]} ${t.getDate()}`; };
const FREQ = { weekly: 'a week', fortnightly: 'a fortnight', monthly: 'a month', quarterly: 'a quarter', yearly: 'a year' };

export function ShopPageScreen({ params = {} }) {
  const { nav, user, screens } = useApp();
  const shops = shopNames();
  const shop = params.shop || user.shop_code || (shops[0] || {}).code || 'S1';
  const name = (shops.find((s) => s.code === shop) || {}).name || shop;
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [tab, setTab] = useState(params.tab || 'sales');
  const cloudMonth = useMonthFromCloud(ym); // Release 11: on the website, this month comes from the cloud first
  let p = null;
  try { p = shopMonth({ shop, ym }); } catch (e) { p = null; }
  const thisMonth = ym >= dateStr().slice(0, 7);
  const wide = useWide();
  const ui = useUI();
  if (wide) return <ShopWide {...{ nav, user, screens, shop, name, ym, setYm, tab, setTab, p, thisMonth, ui, cloudMonth }} />;
  return (
    <Screen title={name} subtitle={ymLabel(ym)}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Btn testID="shop-prev" title="‹" size="sm" variant="secondary" onPress={() => setYm(ymShift(ym, -1))} />
        <Text style={{ flex: 1, textAlign: 'center', fontSize: 17, fontWeight: '800', color: C.text }}>{ymLabel(ym)}</Text>
        <Btn testID="shop-next" title="›" size="sm" variant="secondary" disabled={thisMonth} onPress={() => setYm(ymShift(ym, 1))} />
      </View>
      <QuickRow who={user} screens={screens} only={['invoice', 'cheque', 'receive', 'order', 'deposit', 'balance']} />
      {!p ? <Hint>This shop's month could not be worked out.</Hint> : (
        <>
          <Stats items={[
            { label: 'Sales (incl. VAT)', value: $(p.sales.total) },
            { label: 'Output VAT', value: $(p.vat.output) },
            { label: 'Purchases', value: $(p.purchases.total) },
            { label: 'Input VAT', value: $(p.vat.input) },
            { label: p.vat.net >= 0 ? 'VAT to pay' : 'VAT to claim', value: $(Math.abs(p.vat.net)), color: C.text },
            { label: 'Still to check', value: String(p.open), color: p.open ? C.warn : C.success },
          ]} />
          <Chips value={tab} onChange={setTab} testIDPrefix="shop-tab" options={[
            { value: 'sales', label: `Sales${p.sales.toCheck ? ` (${p.sales.toCheck})` : ''}` },
            { value: 'buy', label: `Purchases${p.purchases.toCheck + p.missing.length ? ` (${p.purchases.toCheck + p.missing.length})` : ''}` },
            { value: 'cheques', label: 'Cheques' },
            { value: 'fixed', label: `Fixed costs${p.fixed.overdue ? ` (${p.fixed.overdue})` : ''}` },
          ]} />
          {tab === 'sales' ? (
            <Card>
              <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`${p.sales.checked} of ${p.sales.days.length} days checked. Tap a day to check it, type missing sales, or say why the shop was closed.`}</Text>
              {p.sales.days.slice().reverse().map((d) => (
                <ListItem key={d.date} testID={`shop-day-${d.date}`} title={`${d.checked ? '✅' : '☐'} ${dayLabel(d.date)}`} right={d.total ? $(d.total) : 'no sales'}
                  sub={d.total ? `VAT ${$(d.vat)} · zero-rated ${$(d.zero)}` : 'Nothing recorded – type the sales or say why it was closed'}
                  tone={d.checked ? undefined : 'warn'} onPress={() => nav.push('MonthRecords', { ym, shop, date: d.date })} />
              ))}
            </Card>
          ) : null}
          {tab === 'buy' ? (
            <>
              {p.missing.length ? (
                <Card tone="warn">
                  <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Weekly suppliers – no invoice this week</Text>
                  {p.missing.map((m) => <ListItem key={m.supplierKey} title={m.supplier} sub={`Usually ${m.usualDay} · last ${m.lastDate} (${$(m.lastTotal)})`} tone="warn" onPress={() => nav.push('RegularSuppliers', {})} />)}
                </Card>
              ) : null}
              <Card>
                <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`${p.purchases.count} invoices · ${p.purchases.toCheck} to check · input VAT ${$(p.purchases.vat)}`}</Text>
                {!p.purchases.list.length ? <Hint>No supplier invoices for this shop this month yet.</Hint> : p.purchases.list.map((i) => (
                  <ListItem key={i.uid} testID={`shop-inv-${i.uid}`} title={`${i.status === 'to_check' ? '☐' : '✅'} ${i.supplier_name}`} sub={`${i.invoice_date} · No. ${i.invoice_no || '–'} · VAT ${$(i.vat)}`}
                    right={$(i.total)} tone={i.status === 'to_check' ? 'warn' : undefined} onPress={() => nav.push('ApInvoice', { uid: i.uid })} />
                ))}
              </Card>
            </>
          ) : null}
          {tab === 'cheques' ? (
            <Card>
              {p.cheques.map((g) => (
                <View key={g.key} style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{`${g.title} (${g.list.length})`}</Text>
                  {g.list.slice(0, 8).map((c) => <ListItem key={c.key} title={`Cheque ${c.no || '?'} · ${c.supplierName || '?'}`} sub={c.date} right={$(c.amount)} onPress={() => nav.push('ChequeTrail', c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid })} />)}
                </View>
              ))}
              <Btn testID="shop-cheques" title="All cheques and cheque books" icon="✍️" variant="secondary" size="md" onPress={() => nav.push('ChequeHome', {})} />
            </Card>
          ) : null}
          {tab === 'fixed' ? (
            <Card>
              <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{`Rent, the shop loan, power, water and other regular bills of this shop: about ${$(p.fixed.monthly)} a month.`}</Text>
              {!p.fixed.list.length ? <Hint>No regular costs set up for this shop. Add them in Money › Loans & rent.</Hint> : p.fixed.list.map((x) => (
                <ListItem key={x.uid} title={x.name} sub={`${x.kind} · ${$(x.amount)} ${FREQ[x.frequency] || ''}${x.nextDue ? ` · next ${x.nextDue}` : ''}${x.balance !== null && x.balance !== undefined ? ` · balance ${$(x.balance)}` : ''}`}
                  right={x.overdue ? `${$(x.overdueAmount)} overdue` : `${$(x.monthly)}/month`} tone={x.overdue ? 'danger' : undefined} onPress={() => nav.push('LoansRent', {})} />
              ))}
            </Card>
          ) : null}
        </>
      )}
    </Screen>
  );
}

// Release 08 – the shop page on a computer, as in the approved design: name and month on top, quick buttons, number
// cards, then a panel with Sales / Purchases / Cheques / Fixed costs tables, and "Needs attention" + VAT on the right.
const CHQ_TONE = { waiting: 'warn', given: 'warn', planned: 'ok', covered: 'ok', cleared: 'good' };
const CHQ_WORD = { waiting: 'Waiting for pickup', given: 'Given – not covered', planned: 'Deposit planned', covered: 'Waiting to clear', cleared: 'Cleared' };
const shortDate = (d) => { if (!d) return '–'; const t = new Date(`${d}T00:00:00`); return `${t.getDate()} ${MONTHS[t.getMonth()].slice(0, 3)}`; };
function ShopWide({ nav, user, screens, shop, name, ym, setYm, tab, setTab, p, thisMonth, ui, cloudMonth }) {
  const excel = () => { try { require('../../../platform/files.js').shareReport(shopMonthReport({ shop, ym, name }), 'xlsx').catch((e) => ui.error(e)); } catch (e) { ui.error(e); } };
  const top = (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-end', gap: 16 }}>
      <View style={{ flexGrow: 1, flexBasis: 320, gap: 4 }}>
        <Text style={{ fontSize: 13, color: C.sub }}>Shops</Text>
        <Text accessibilityRole="header" style={{ fontSize: 28, fontWeight: '700', letterSpacing: -0.3, color: C.text }}>{name}</Text>
      </View>
      <MonthSwitch label={ymLabel(ym)} onPrev={() => setYm(ymShift(ym, -1))} onNext={() => setYm(ymShift(ym, 1))} nextDisabled={thisMonth} testIDPrefix="shop" />
      <OutlineBtn testID="shop-excel" title="Excel" icon="download" onPress={excel} />
    </View>
  );
  if (!p) return <Screen title={name} subtitle="Shops" bare>{top}<Hint>This shop's month could not be worked out.</Hint></Screen>;
  const days = p.sales.days.slice().reverse();
  const missingCount = p.missing.length;
  const chqRows = [].concat(...p.cheques.map((g) => g.list.slice(0, 40).map((c) => ({ ...c, group: g.key }))));
  const tabs = [
    { value: 'sales', label: 'Sales (output)', count: p.sales.toCheck },
    { value: 'buy', label: 'Purchases (input)', count: p.purchases.toCheck + missingCount },
    { value: 'cheques', label: 'Cheques' },
    { value: 'fixed', label: 'Fixed costs', count: p.fixed.overdue },
  ];
  const alerts = [
    ...p.missing.map((m) => ({ title: `No invoice from ${m.supplier}`, sub: `Usually ${m.usualDay} · last ${shortDate(m.lastDate)}`, onPress: () => nav.push('RegularSuppliers', {}) })),
    ...(p.sales.toCheck ? [{ title: `${p.sales.toCheck} day${p.sales.toCheck === 1 ? '' : 's'} of sales to check`, sub: days.filter((d) => !d.checked).slice(0, 4).map((d) => dayLabel(d.date)).join(', '), onPress: () => setTab('sales') }] : []),
    ...(p.purchases.toCheck ? [{ title: `${p.purchases.toCheck} invoice${p.purchases.toCheck === 1 ? '' : 's'} to check`, sub: 'Open Purchases to check them', onPress: () => setTab('buy') }] : []),
    ...(p.fixed.overdue ? [{ title: `${p.fixed.overdue} regular cost${p.fixed.overdue === 1 ? '' : 's'} overdue`, sub: 'Rent, loans or bills', onPress: () => setTab('fixed') }] : []),
  ];
  return (
    <Screen title={name} subtitle="Shops" bare>
      {top}
      <CloudNote st={cloudMonth} />
      <QuickRow who={user} screens={screens} only={['invoice', 'cheque', 'receive', 'order', 'deposit', 'balance']} />
      <Stats items={[
        { label: 'Sales (VAT incl.)', value: $(p.sales.total), sub: p.sales.days.length ? `1–${Number(p.sales.days[p.sales.days.length - 1].date.slice(8))} ${MONTHS[Number(ym.slice(5, 7)) - 1]}` : ymLabel(ym) },
        { label: 'Output VAT', value: $(p.vat.output), sub: 'Standard-rated sales only' },
        { label: 'Purchases', value: $(p.purchases.total), sub: `${p.purchases.count} invoice${p.purchases.count === 1 ? '' : 's'}` },
        { label: 'Days checked', value: `${p.sales.checked} of ${p.sales.days.length}`, sub: p.sales.toCheck ? `${p.sales.toCheck} to check` : 'All checked', color: C.brandBlue, onPress: () => setTab('sales') },
        { label: 'Invoices missing', value: String(missingCount), sub: 'Regular suppliers', color: missingCount ? C.warn : C.text, onPress: () => setTab('buy') },
      ]} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 24, alignItems: 'flex-start' }}>
        <Panel pad={false} style={{ flexGrow: 999, flexBasis: 560, minWidth: 0 }}>
          <WebTabs tabs={tabs} value={tab} onChange={setTab} testIDPrefix="shop-tab" />
          {tab === 'sales' ? (
            <>
              <WebTable testID="shop-sales" columns={[
                { key: 'day', title: 'Day', bold: true }, { key: 'sales', title: 'Sales (VAT incl.)', align: 'right' }, { key: 'zero', title: 'Zero-rated', align: 'right', muted: true },
                { key: 'vat', title: 'Output VAT', align: 'right' }, { key: 'checked', title: 'Checked' }, { key: 'act', title: ' ', align: 'right', width: 140 },
              ]} empty="No days yet this month." rows={days.map((d) => ({
                key: d.date, testID: `shop-day-${d.date}`, onPress: () => nav.push('MonthRecords', { ym, shop, date: d.date }),
                cells: {
                  day: dayLabel(d.date), sales: d.total ? $(d.total) : 'no sales', zero: d.total ? $(d.zero) : '–', vat: d.total ? $(d.vat) : '–',
                  checked: d.checked ? <Pill tone="ok" tick text={String((d.checked && d.checked.by) || 'Checked').split(' ')[0]} /> : <Pill tone="todo" text="To check" />,
                  act: <SmallBtn red={!d.checked} title={d.checked ? 'Change' : 'Check day'} onPress={() => nav.push('MonthRecords', { ym, shop, date: d.date })} />,
                },
              }))} />
              <PanelNote>Sales come in from Aronium. Changing a checked day removes its tick and keeps who, when, before and after.</PanelNote>
            </>
          ) : null}
          {tab === 'buy' ? (
            <>
              <WebTable testID="shop-buy" columns={[
                { key: 'sup', title: 'Supplier', bold: true, flex: 2 }, { key: 'date', title: 'Date' }, { key: 'no', title: 'Invoice', muted: true },
                { key: 'amt', title: 'Amount', align: 'right' }, { key: 'vat', title: 'Input VAT', align: 'right' }, { key: 'st', title: 'Status' },
              ]} empty="No supplier invoices for this shop this month yet." rows={[
                ...p.missing.map((m) => ({ key: `miss-${m.supplierKey}`, bg: '#FFFBF0', onPress: () => nav.push('RegularSuppliers', {}),
                  cells: { sup: m.supplier, date: `Usually ${m.usualDay}`, no: '–', amt: `last ${$(m.lastTotal)}`, vat: '–', st: <Pill tone="warn" text="Missing" /> } })),
                ...p.purchases.list.map((i) => ({ key: i.uid, testID: `shop-inv-${i.uid}`, onPress: () => nav.push('ApInvoice', { uid: i.uid }),
                  cells: { sup: i.supplier_name, date: shortDate(i.invoice_date), no: i.invoice_no || '–', amt: $(i.total), vat: $(i.vat), st: i.status === 'to_check' ? <Pill tone="todo" text="To check" /> : <Pill tone="ok" tick text="Checked" /> } })),
              ]} />
              <PanelNote>Regular suppliers are expected on their days. No invoice by the end of the day shows as missing here and on VAT.</PanelNote>
            </>
          ) : null}
          {tab === 'cheques' ? (
            <>
              <WebTable testID="shop-chq" columns={[
                { key: 'no', title: 'Cheque', bold: true }, { key: 'date', title: 'Written' }, { key: 'to', title: 'Paid to', flex: 2 }, { key: 'amt', title: 'Amount', align: 'right' }, { key: 'st', title: 'Status', flex: 1.4 },
              ]} empty="No cheques for this shop yet." rows={chqRows.map((c) => ({
                key: c.key, onPress: () => nav.push('ChequeTrail', c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid }),
                cells: { no: c.no || '?', date: shortDate(c.date), to: c.supplierName || '?', amt: $(c.amount), st: <Pill tone={CHQ_TONE[c.group] || 'grey'} text={CHQ_WORD[c.group] || c.group} /> },
              }))} />
              <View style={{ flexDirection: 'row', alignItems: 'center', borderTopWidth: 1, borderTopColor: C.line, paddingVertical: 10, paddingHorizontal: 24, gap: 12 }}>
                <Text style={{ flex: 1, fontSize: 13, color: C.sub }}>{`Cheques given from ${name}. All shops draw on the one BSP cheque account.`}</Text>
                <SmallBtn testID="shop-cheques" title="All cheques and cheque books" onPress={() => nav.push('ChequeHome', {})} />
              </View>
            </>
          ) : null}
          {tab === 'fixed' ? (
            <>
              <WebTable testID="shop-fixed" columns={[
                { key: 'n', title: 'Cost', bold: true, flex: 2 }, { key: 'k', title: 'Kind', muted: true }, { key: 'a', title: 'Amount', align: 'right' }, { key: 'nx', title: 'Next due' }, { key: 'st', title: 'Status' },
              ]} empty="No regular costs set up for this shop. Add them in Money › Loans & rent." rows={p.fixed.list.map((x) => ({
                key: x.uid, onPress: () => nav.push('LoansRent', {}),
                cells: { n: x.name, k: x.kind, a: `${$(x.amount)} ${FREQ[x.frequency] || ''}`, nx: x.nextDue ? shortDate(x.nextDue) : '–', st: x.overdue ? <Pill tone="bad" text={`${$(x.overdueAmount)} overdue`} /> : <Pill tone="good" text={`${$(x.monthly)}/month`} /> },
              }))} />
              <PanelNote>{`Rent, the shop loan, power, water and other regular bills of this shop: about ${$(p.fixed.monthly)} a month.`}</PanelNote>
            </>
          ) : null}
        </Panel>
        <View style={{ flexGrow: 1, flexBasis: 300, minWidth: 0, gap: 16 }}>
          <Attention items={alerts} />
          <DarkCard label="This shop's VAT so far" value={`${$(Math.abs(p.vat.net))} ${p.vat.net >= 0 ? 'to pay' : 'to claim'}`}
            note={`Output ${$(p.vat.output)} − input ${$(p.vat.input)}. Goes to the VAT page once every day and invoice is checked.`}
            button="Open VAT" testID="shop-vat" onPress={() => nav.push('VatMonth', { ym })} />
        </View>
      </View>
    </Screen>
  );
}
