// 1.0.0 (build 1) Office › Reports and the books (map screens rep-home, rep-month, rep-vat, rep-acct, rep-close, b-home,
// b-journal, b-ledger). Few screens, plain words, figures straight from the books (accounting/v1.js).
// Exported for the new shell: ReportsHomeScreen, MonthSummaryScreen, VatMonthScreen, AccountantFilesScreen,
// MonthCloseScreen, BooksHomeScreen, BooksJournalScreen, BooksLedgerScreen, BooksAdjustScreen (and MonthPicker / Bar).
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, Select, Field, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Stats, Hint, useAct, MoneyField, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { lockDate } from '../../../services/lock.js';
import { can } from '../../../services/access.js';
import * as V from '../v1.js';
import * as A from '../service.js';
import { useWide } from '../../../ui/wide.js';
import { useMonthFromCloud, CloudNote } from '../../../web/cloudPages.js';
import { WebTable, Panel, PanelNote, MonthSwitch, OutlineBtn, Pill } from '../../../ui/web.js';
import { Pressable } from 'react-native';

export const $ = (n) => `${Number(n) < 0 ? '−' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const $0 = (n) => `${Number(n) < 0 ? '−' : ''}$${Math.abs(Math.round(Number(n) || 0)).toLocaleString('en-US')}`;
const pct = (x) => (x === null || x === undefined ? '' : `${x >= 0 ? '+' : ''}${x}%`);
const boss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const tryRun = (f) => { try { return f(); } catch (e) { return { error: e.message || String(e) }; } };

// ‹ Oct 2026 › – the month every report here is for.
export function MonthPicker({ ym, onChange, testID = 'mp' }) {
  const last = dateStr().slice(0, 7);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
      <Btn testID={`${testID}-prev`} title="‹" size="sm" variant="secondary" onPress={() => onChange(V.ymAdd(ym, -1))} />
      <Text testID={`${testID}-label`} style={{ fontSize: 20, fontWeight: '800', color: C.text, minWidth: 110, textAlign: 'center' }}>{V.ymLabel(ym)}</Text>
      <Btn testID={`${testID}-next`} title="›" size="sm" variant="secondary" disabled={ym >= last} onPress={() => onChange(V.ymAdd(ym, 1))} />
    </View>
  );
}
// One horizontal bar: label, bar, amount. Negative amounts are drawn red from the left.
export function Bar({ label, value, max, strong, faint, testID }) {
  const w = max > 0 ? Math.max(2, Math.min(100, Math.round((Math.abs(value) / max) * 100))) : 0;
  return (
    <View testID={testID} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      <Text style={{ width: 70, fontSize: 14, color: strong ? C.text : C.sub, fontWeight: strong ? '800' : '600' }} numberOfLines={1}>{label}</Text>
      <View style={{ flex: 1, height: 12, borderRadius: 6, backgroundColor: '#EFEAE3' }}>
        <View style={{ width: `${w}%`, height: 12, borderRadius: 6, backgroundColor: value < 0 ? C.danger : faint ? '#B9C7E6' : C.info }} />
      </View>
      <Text style={{ width: 92, textAlign: 'right', fontSize: 15, fontWeight: strong ? '900' : '600', color: value < 0 ? C.danger : C.text }}>{$0(value)}</Text>
    </View>
  );
}
function Trail({ steps }) {
  return (
    <View style={{ gap: 6 }}>
      {steps.map((s) => (
        <View key={s.key} style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          <Text style={{ fontSize: 20, color: s.done ? C.success : C.disabled }}>{s.done ? '●' : '○'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: s.done ? C.text : C.sub }}>{s.label}</Text>
            {s.when ? <Text style={{ fontSize: 13, color: C.sub }}>{s.when}</Text> : null}
          </View>
        </View>
      ))}
    </View>
  );
}
const startYm = (params) => (params && /^\d{4}-\d{2}$/.test(params.ym || '') ? params.ym : V.lastFullMonth());

// ---------------------------------------------------------------- Reports (rep-home)
export function ReportsHomeScreen() {
  const { nav, user } = useApp();
  const ym = V.lastFullMonth();
  const close = useMemo(() => tryRun(() => V.closeList(ym)), [ym]);
  const go = (screen, params = {}) => () => nav.push(screen, params);
  return (
    <Screen title="Reports" subtitle="The ones used to make decisions">
      <ListItem testID="rep-month" title="Month – profit per shop" right={V.ymLabel(ym)} onPress={go('MonthSummary', { ym })} />
      <ListItem testID="rep-sup" title="Supplier standings" sub="What is still owed, per supplier" onPress={go('ApSuppliers')} />
      {can(user, 'payroll_view') || can(user, 'payroll_run') ? <ListItem testID="rep-pay" title="Payroll this week" sub="Check and approve" onPress={go('PayWeek')} /> : null}
      <ListItem testID="rep-vat" title="VAT return" onPress={go('VatMonth', { ym })} />
      <ListItem testID="rep-fnpf" title="FNPF" onPress={go('FnpfMonth', { ym })} />
      {can(user, 'bank_rec') ? <ListItem testID="rep-recon" title="Bank reconciliation" sub="BSP and both M-PAiSA wallets" onPress={go('ReconMonth', { ym })} /> : null}
      <ListItem testID="rep-acct" title="For the accountant" sub="All the files" onPress={go('AccountantFiles', { ym })} />
      <ListItem testID="rep-close" title="Close the month" right={close.error ? '' : close.closed ? 'closed ✓' : `${close.open} left`} tone={!close.error && !close.closed && close.open ? 'warn' : undefined} onPress={go('MonthClose', { ym })} />
      <ListItem testID="rep-books" title="The books – ledgers & financials" onPress={go('BooksHome')} />
    </Screen>
  );
}

// ---------------------------------------------------------------- Monthly summary (rep-month)
export function MonthSummaryScreen({ params = {} }) {
  const { nav } = useApp();
  const [ym, setYm] = useState(startYm(params));
  const m = useMemo(() => tryRun(() => V.monthSummary(ym)), [ym]);
  if (m.error) return <Screen title="Monthly summary"><MonthPicker ym={ym} onChange={setYm} /><Banner tone="danger" message={m.error} /></Screen>;
  const max = Math.max(1, ...m.shops.flatMap((s) => [s.profit, s.lastMonth.profit, s.lastYear ? s.lastYear.profit : 0].map(Math.abs)));
  const tmax = Math.max(1, ...m.trend.map((t) => Math.abs(t.business)));
  const prevLabel = V.ymLabel(V.ymAdd(ym, -1)).slice(0, 3);
  const lyLabel = `${V.ymLabel(ym).slice(0, 3)} ${V.ymAdd(ym, -12).slice(2, 4)}`;
  return (
    <Screen title={`${V.ymLabel(ym)} profit`} subtitle="From the books" footer={<Btn testID="ms-excel" title="Excel / PDF for the accountant" icon="📊" variant="primary" onPress={() => nav.push('ReportView', { kind: 'v1_month', from: `${ym}-01`, to: `${ym}-01` })} />}>
      <MonthPicker ym={ym} onChange={setYm} testID="ms" />
      {m.shops.map((s) => (
        <Card key={s.code}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 6 }}>{s.name}</Text>
          <View style={{ gap: 6 }}>
            <Bar testID={`ms-bar-${s.code}`} label={V.ymLabel(ym).slice(0, 3)} value={s.profit} max={max} strong />
            <Bar label={prevLabel} value={s.lastMonth.profit} max={max} faint />
            {s.lastYear ? <Bar label={lyLabel} value={s.lastYear.profit} max={max} faint /> : <Text style={{ fontSize: 13, color: C.sub }}>No figures for {lyLabel} yet</Text>}
          </View>
          <Text style={{ fontSize: 14, color: C.sub, marginTop: 6 }}>{`Income ${$(s.income)} · costs ${$(s.costs)} · supplier invoices ${$(s.invoices)}`}</Text>
        </Card>
      ))}
      <ListItem testID="ms-whole" title="Whole business costs" sub="Closed shop (V M Pillay rent and loan), office and home" right={$(m.whole.profit)} />
      {m.whole.lines.slice(0, 6).map((l) => <ListItem key={l.code} title={l.name} sub={[l.closed ? `closed shop ${$(l.closed)}` : '', l.office ? `office & home ${$(l.office)}` : ''].filter(Boolean).join(' · ')} right={$(l.type === 'income' ? l.amount : -l.amount)} />)}
      <ListItem testID="ms-business" title="Business profit" sub={[m.change.lastMonth !== null ? `${pct(m.change.lastMonth)} on last month` : null, m.change.lastYear !== null ? `${pct(m.change.lastYear)} on ${lyLabel}` : null].filter(Boolean).join(' · ') || undefined}
        right={$(m.business.profit)} tone={m.business.profit < 0 ? 'danger' : 'success'} />
      <Stats items={[{ label: 'Income', value: $0(m.business.income) }, { label: 'Costs', value: $0(m.business.costs) }, { label: 'Supplier invoices', value: $0(m.business.invoices), sub: `${m.business.invoiceCount} invoices` }]} />
      <Section title="The last 12 months – business profit">
        <View testID="ms-trend" style={{ gap: 4 }}>
          {m.trend.map((t) => <Bar key={t.ym} label={t.label} value={t.business} max={tmax} strong={t.ym === ym} faint={!t.any} />)}
        </View>
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- VAT return (rep-vat)
export function VatMonthScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [ym, setYm] = useState(startYm(params));
  const [n, bump] = useState(0);
  const cloudMonth = useMonthFromCloud(ym); // Release 11: on the website, this month comes from the cloud first
  const v = useMemo(() => tryRun(() => V.vatMonth(ym)), [ym, n, cloudMonth.tick]);
  const wide = useWide();
  if (wide && !v.error) return <VatWide {...{ nav, user, act, ym, setYm, v, bump, cloudMonth }} />;
  if (v.error) return <Screen title="VAT return"><MonthPicker ym={ym} onChange={setYm} /><Banner tone="danger" message={v.error} /></Screen>;
  const send = () => { if (act(() => V.markSent(user, 'vat', ym), 'Marked as sent to the accountant')) { bump((x) => x + 1); nav.push('ReportView', { kind: 'v1_vat', from: `${ym}-01`, to: `${ym}-01` }); } };
  return (
    <Screen title={`VAT – ${V.ymLabel(ym)}`} subtitle={`FRCS · invoice basis · due ${v.due}`}
      footer={<Btn testID="vat-send" title="Send to the accountant (Excel)" icon="📤" variant="primary" onPress={send} />}>
      <MonthPicker ym={ym} onChange={setYm} testID="vat" />
      <ListItem title="VAT on sales (from Aronium)" right={$(v.output)} />
      <ListItem title="VAT on purchases (from invoices)" right={$(-v.input)} />
      <ListItem testID="vat-topay" title={v.refund ? 'Refund due from FRCS' : 'VAT to pay FRCS'} right={$(Math.abs(v.toPay))} tone={v.refund ? 'success' : 'warn'} />
      <ListItem title="Zero-rated sales" right={$(v.zeroRated)} />
      <Section title="By shop">
        {v.shops.map((s) => <ListItem key={s.code} title={s.name} sub={`sales ${$(s.sales)} · zero-rated ${$(s.zero)}`} right={$(s.net)} rightSub="VAT net" />)}
      </Section>
      {v.noVat.length ? <Banner testID="vat-novat" tone="warn" title={`${v.noVat.length} product${v.noVat.length === 1 ? ' has' : 's have'} no VAT set in Aronium`} message={`Check before sending: ${v.noVat.slice(0, 6).map((p) => p.name || p.code).join(', ')}${v.noVat.length > 6 ? ' …' : ''}. Set the tax in Aronium (a blank is never zero-rated).`} /> : null}
      <Banner testID="vat-books" tone={v.agrees ? 'success' : 'warn'} message={v.agrees ? 'The books agree with this return ✓' : `The books differ from the return: sales VAT ${$(v.agree.output)}, purchases VAT ${$(v.agree.input)}. See the checks.`} />
      {v.checks.filter((c) => c.level !== 'ok').map((c, i) => <Hint key={i}>{`${c.level === 'bad' ? '⛔' : '⚠️'} ${c.text}`}</Hint>)}
      <Section title="Where it is up to"><Trail steps={v.trail} /></Section>
      <Btn testID="vat-excel" title="Whole month as Excel" icon="📊" size="md" variant="secondary" onPress={() => { try { require('../../../platform/files.js').shareReport(V.vatMonthReport(`${ym}-01`), 'xlsx').catch((e) => ui.error(e)); } catch (e) { ui.error(e); } }} />
      {V.isSent('vat', ym) ? <ReasonButton testID="vat-unsend" title="Undo “sent to the accountant”" icon="↩️" prompt="Why take it back?" confirm="Undo sent" variant="warn" onDo={(why) => { const ok = act(() => V.undoSent(user, 'vat', ym, why), 'Taken back – send it again when ready'); if (ok) bump((x) => x + 1); return ok; }} /> : null}
      <Btn testID="vat-file" title="Filed / paid – record it" size="md" variant="secondary" onPress={() => nav.push('TaxReturn', { kind: 'vat', period: ym })} />
    </Screen>
  );
}

// Release 08 – the VAT page on a computer, as in the approved design: a "ready / not ready" line, four number cards,
// the return line by line for each shop (tap a figure to open that shop), and "Still open" on the right.
const ymPlus = (ym, n) => { const d = new Date(Number(ym.slice(0, 4)), Number(ym.slice(5, 7)) - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const sd = (d) => { if (!d) return ''; const t = new Date(`${d}T00:00:00`); return `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][t.getDay()]} ${t.getDate()}`; };
function VatWide({ nav, user, act, ym, setYm, v, bump, cloudMonth }) {
  const ui = useUI();
  let shops = [];
  try { const SP = require('../shopPage.js'); shops = SP.shopNames().map((s) => ({ ...s, p: tryRun(() => SP.shopMonth({ shop: s.code, ym })) })).filter((s) => s.p && !s.p.error); } catch (e) { shops = []; }
  const sum = (f) => shops.reduce((t, s) => t + (Number(f(s.p)) || 0), 0);
  const days = sum((p) => p.sales.days.length); const daysDone = sum((p) => p.sales.checked);
  const invs = sum((p) => p.purchases.count); const invsTodo = sum((p) => p.purchases.toCheck); const miss = sum((p) => p.missing.length);
  const open = [];
  shops.forEach((s) => {
    const left = s.p.sales.days.filter((d) => !d.checked);
    if (left.length) open.push({ title: `${s.name} · sales ${left.slice(-3).map((d) => sd(d.date)).join(', ')}${left.length > 3 ? ' …' : ''}`, sub: left.length === 1 ? 'Day to check' : 'Days to check', tag: `${left.length} day${left.length === 1 ? '' : 's'}`, go: () => nav.push('ShopPage', { shop: s.code, ym, tab: 'sales' }) });
    s.p.missing.forEach((m) => open.push({ title: `${s.name} · ${m.supplier}`, sub: `Usually ${m.usualDay}`, tag: 'No invoice', go: () => nav.push('ShopPage', { shop: s.code, ym, tab: 'buy' }) }));
    s.p.purchases.list.filter((i) => i.status === 'to_check').forEach((i) => open.push({ title: `${s.name} · ${i.supplier_name}${i.invoice_no ? ` ${i.invoice_no}` : ''}`, sub: 'Entered, not checked', tag: 'To check', go: () => nav.push('ApInvoice', { uid: i.uid }) }));
  });
  const ready = !open.length;
  const send = () => { if (act(() => V.markSent(user, 'vat', ym), 'Marked as sent to the accountant')) { bump((x) => x + 1); nav.push('ReportView', { kind: 'v1_vat', from: `${ym}-01`, to: `${ym}-01` }); } };
  const sent = V.isSent('vat', ym);
  const excel = () => { try { require('../../../platform/files.js').shareReport(V.vatMonthReport(`${ym}-01`), 'xlsx').catch((e) => ui.error(e)); } catch (e) { ui.error(e); } };
  const unsend = (why) => { const ok = act(() => V.undoSent(user, 'vat', ym, why), 'Taken back – change what you need, then send it again'); if (ok) bump((x) => x + 1); return ok; };
  const line = (name, f, strong) => ({ name, f, strong });
  const lines = [
    line('Total sales (VAT incl.)', (p) => p.sales.total), line('Zero-rated sales', (p) => p.sales.zero), line('Standard-rated sales', (p) => p.sales.standard),
    line('Output VAT', (p) => p.vat.output, true), line('Purchases with tax invoice', (p) => p.purchases.total), line('Input VAT', (p) => p.vat.input, true), line('VAT to pay', (p) => p.vat.net, true),
  ];
  const cols = [{ key: 'name', title: 'Line', flex: 2 }].concat(shops.map((s) => ({ key: s.code, title: s.name.split(/\s[–-]\s/)[0], align: 'right' }))).concat([{ key: 't', title: 'Total', align: 'right', bold: true }]);
  const money = (n) => `${n < 0 ? '-' : ''}$${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const link = (txt, go, strong) => <Pressable onPress={go}><Text style={{ fontSize: 14, color: C.brandBlue, fontWeight: strong ? '700' : '500', fontVariant: ['tabular-nums'] }}>{txt}</Text></Pressable>;
  return (
    <Screen title={`VAT return – ${V.ymLabel(ym)}`} bare>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-end', gap: 16 }}>
        <View style={{ flexGrow: 1, flexBasis: 320, gap: 4 }}>
          <Text style={{ fontSize: 13, color: C.sub }}>Tax</Text>
          <Text accessibilityRole="header" style={{ fontSize: 28, fontWeight: '700', letterSpacing: -0.3, color: C.text }}>{`VAT return – ${V.ymLabel(ym)}`}</Text>
        </View>
        <MonthSwitch label={V.ymLabel(ym)} onPrev={() => setYm(ymPlus(ym, -1))} onNext={() => setYm(ymPlus(ym, 1))} nextDisabled={ym >= dateStr().slice(0, 7)} testIDPrefix="vat" />
        <OutlineBtn testID="vat-tools" title="All VAT tools" onPress={() => nav.push('Area', { area: 'tax' })} />
        <OutlineBtn testID="vat-excel" title="Excel" icon="download" onPress={excel} />
        {sent ? <ReasonButton testID="vat-unsend" title="Undo sent" prompt={`Sent by ${sent.by} on ${String(sent.at).slice(0, 16)} – why take it back?`} confirm="Undo sent" variant="warn" size="sm" onDo={unsend} /> : <OutlineBtn testID="vat-send" title="Send to accountant" onPress={send} />}
        <Btn testID="vat-file" title="Lodge with FRCS" size="md" variant="primary" disabled={!ready} onPress={() => nav.push('TaxReturn', { kind: 'vat', period: ym })} />
      </View>
      <CloudNote st={cloudMonth} />
      <View testID="vat-ready" style={{ flexDirection: 'row', gap: 14, alignItems: 'center', backgroundColor: ready ? '#DDF4E4' : '#FEF0C7', borderWidth: 1, borderColor: ready ? '#A6DDB7' : '#F5D68A', borderRadius: 12, paddingVertical: 14, paddingHorizontal: 18 }}>
        <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: ready ? C.success : C.warn, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: '#FFF', fontWeight: '800' }}>{ready ? '✓' : '!'}</Text></View>
        <View style={{ flex: 1, gap: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: ready ? C.successText : '#8A3B06' }}>{ready ? 'Ready to lodge' : 'Not ready to lodge yet'}</Text>
          <Text style={{ fontSize: 13, color: ready ? C.successText : '#8A3B06' }}>{ready ? `Every day and invoice is checked. Due ${v.due}.` : `${days - daysDone ? `${days - daysDone} day${days - daysDone === 1 ? '' : 's'} of sales` : ''}${days - daysDone && (invsTodo + miss) ? ' and ' : ''}${invsTodo + miss ? `${invsTodo + miss} supplier invoice${invsTodo + miss === 1 ? '' : 's'}` : ''} still need checking. The figures below change until they are done.`}</Text>
        </View>
      </View>
      <Stats items={[
        { label: 'Output VAT (on sales)', value: money(v.output), sub: 'All shops, standard-rated' },
        { label: 'Input VAT (on purchases)', value: money(v.input), sub: 'From checked tax invoices' },
        { testID: 'vat-topay', label: v.refund ? 'Refund from FRCS' : 'To pay FRCS', value: money(Math.abs(v.toPay)), sub: `Due ${v.due}`, color: v.refund ? C.success : C.primary },
        { label: 'Checked so far', value: `${daysDone} of ${days} days`, sub: `${invs - invsTodo} of ${invs} invoices`, color: C.brandBlue },
      ]} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 24, alignItems: 'flex-start' }}>
        <Panel pad={false} style={{ flexGrow: 999, flexBasis: 560, minWidth: 0 }}>
          <View style={{ paddingVertical: 18, paddingHorizontal: 24, borderBottomWidth: 1, borderBottomColor: C.border, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'baseline', gap: 12 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: C.text, flex: 1 }}>The return, line by line</Text>
            <Text style={{ fontSize: 13, color: C.sub }}>Tap a figure to see the days or invoices behind it</Text>
          </View>
          <WebTable testID="vat-lines" columns={cols} rows={lines.map((l) => {
            const cells = { name: <Text style={{ fontSize: 14, fontWeight: l.strong ? '700' : '500', color: C.text }}>{l.name}</Text> };
            let t = 0;
            shops.forEach((s) => { const n = Number(l.f(s.p)) || 0; t += n; cells[s.code] = link(money(n), () => nav.push('ShopPage', { shop: s.code, ym, tab: /Purchases|Input/.test(l.name) ? 'buy' : 'sales' }), l.strong); });
            cells.t = <Text style={{ fontSize: 14, fontWeight: '700', color: C.text, fontVariant: ['tabular-nums'] }}>{money(t)}</Text>;
            return { key: l.name, bg: l.strong ? '#FAF8F5' : undefined, cells };
          })} />
          <PanelNote>{`VAT at 12.5%, invoice basis. Every figure comes from the days and invoices of the shop pages.${v.agrees ? ' The books agree with this return ✓' : ` The books differ: sales VAT ${money(v.agree.output)}, purchases VAT ${money(v.agree.input)}.`}`}</PanelNote>
        </Panel>
        <Panel style={{ flexGrow: 1, flexBasis: 300, minWidth: 0 }}>
          <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>Still open</Text>
          {!open.length ? <Text style={{ fontSize: 14, color: C.sub }}>Nothing open – ready to lodge.</Text> : open.slice(0, 12).map((o, i) => (
            <Pressable key={i} onPress={o.go} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderTopWidth: i ? 1 : 0, borderTopColor: C.line }}>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: C.text }}>{o.title}</Text>
                <Text style={{ fontSize: 13, color: C.sub }}>{o.sub}</Text>
              </View>
              <Pill tone={o.tag === 'No invoice' ? 'bad' : 'todo'} text={o.tag} />
            </Pressable>
          ))}
          {open.length > 12 ? <Text style={{ fontSize: 13, color: C.sub }}>{`and ${open.length - 12} more`}</Text> : null}
          {v.noVat.length ? <Text style={{ fontSize: 13, color: '#8A3B06' }}>{`${v.noVat.length} product${v.noVat.length === 1 ? ' has' : 's have'} no VAT set in Aronium – set the tax there before sending.`}</Text> : null}
          <Text style={{ fontSize: 13, color: C.sub, borderTopWidth: 1, borderTopColor: C.line, paddingTop: 12 }}>Lodge opens once this list is empty. A change after lodging makes a new version and keeps the old one.</Text>
        </Panel>
      </View>
    </Screen>
  );
}

// ---------------------------------------------------------------- For the accountant (rep-acct)
export function AccountantFilesScreen({ params = {} }) {
  const { nav } = useApp();
  const [ym, setYm] = useState(startYm(params));
  const noVat = useMemo(() => tryRun(() => V.productsWithNoVat()), []);
  return (
    <Screen title="For the accountant" subtitle={V.ymLabel(ym)}>
      <MonthPicker ym={ym} onChange={setYm} testID="acct" />
      <ListItem testID="acct-books" title="The books – ledger, trial balance, financials" onPress={() => nav.push('BooksHome', {})} />
      <ListItem testID="acct-vat" title={`VAT return – ${V.ymLabel(ym)}`} onPress={() => nav.push('VatMonth', { ym })} />
      <ListItem testID="acct-fnpf" title={`FNPF – ${V.ymLabel(ym)}`} onPress={() => nav.push('FnpfMonth', { ym })} />
      <ListItem testID="acct-month" title={`Monthly summary – ${V.ymLabel(ym)}`} onPress={() => nav.push('MonthSummary', { ym })} />
      <ListItem testID="acct-recon" title={`Bank reconciliation – ${V.ymLabel(ym)}`} onPress={() => nav.push('ReconMonth', { ym })} />
      <ListItem testID="acct-year" title="Year-end pack" onPress={() => nav.push('YearEndAcct', {})} />
      {Array.isArray(noVat) && noVat.length ? <Banner tone="warn" message={`${noVat.length} product${noVat.length === 1 ? '' : 's'} with no VAT set in Aronium – fix before sending.`} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Close the month (rep-close)
export function MonthCloseScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [ym, setYm] = useState(startYm(params));
  const [n, bump] = useState(0);
  const l = useMemo(() => tryRun(() => V.closeList(ym)), [ym, n]);
  if (l.error) return <Screen title="Close the month"><MonthPicker ym={ym} onChange={setYm} /><Banner tone="danger" message={l.error} /></Screen>;
  const tick = (x) => { if (act(() => V.tickCloseItem(user, ym, x.key, !x.done))) bump((k) => k + 1); };
  const close = async () => {
    const ok = await ui.confirm({ title: `Close ${l.label}?`, message: 'Nothing dated in it can be changed afterwards (a change is then an adjustment with a reason).', confirmText: `Yes, close ${l.label}` });
    if (ok && act(() => V.closeMonthNow(user, ym), `${l.label} closed`)) bump((k) => k + 1);
  };
  return (
    <Screen title={`Close ${l.label}`} subtitle={l.closed ? 'Closed – locked' : `${l.done} of ${l.total} done`}
      footer={l.closed ? null : <Btn testID="close-month" title={l.ready ? `Close ${l.label}` : `Close ${l.label} – ${l.open} left`} icon="🔒" variant="primary" disabled={!l.ready || !boss(user)} onPress={close} />}>
      <MonthPicker ym={ym} onChange={setYm} testID="close" />
      {l.closed ? <Banner testID="close-done" tone="success" message={`${l.label} is closed. Changes to it are booked as an adjustment with a reason (The books › Book an adjustment).`} />
        : <Hint>Everything still open must be finished first – tap an item to go to it.</Hint>}
      {l.items.map((x) => (
        <ListItem key={x.key} testID={`close-item-${x.key}`} title={`${x.done ? '✓' : '○'} ${x.label}`} sub={x.sub || (x.done ? undefined : x.auto ? `${x.left} left – tap to open` : 'Tap when done')}
          tone={x.done ? undefined : 'warn'}
          onPress={l.closed ? undefined : !x.auto && boss(user) ? () => tick(x) : x.nav ? () => nav.push(x.nav.screen, x.nav.params || {}) : undefined} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- The books (b-home, b-journal, b-ledger)
export function BooksHomeScreen() {
  const { nav, user } = useApp();
  const b = useMemo(() => tryRun(() => V.booksStatus(dateStr())), []);
  const go = (screen, params = {}) => () => nav.push(screen, params);
  return (
    <Screen title="The books" subtitle={`FY ${dateStr().slice(0, 4)} · Jan–Dec`}>
      {b.error ? <Banner tone="danger" message={b.error} /> : (
        <Banner testID="books-status" tone={b.tb.ok ? 'success' : 'danger'} message={`Up to date to ${b.asOf} · ${b.tb.ok ? 'trial balance agrees ✓' : 'the trial balance does NOT agree – tell the owner'}${b.lock ? ` · closed up to ${b.lock}` : ''}`} />
      )}
      <ListItem testID="books-ledger" title="General ledger – every account" onPress={go('BooksLedger')} />
      <ListItem testID="books-journal" title="Journal – every entry, in order" onPress={go('BooksJournal')} />
      <ListItem testID="books-tb" title="Trial balance" onPress={go('TrialBalance')} />
      <ListItem testID="books-pl" title="Profit & loss" sub="month · year · per shop" onPress={go('ProfitLoss')} />
      <ListItem testID="books-bs" title="Balance sheet" onPress={go('BalanceSheet')} />
      <ListItem testID="books-cf" title="Cash flow and year-end statements" onPress={go('YearEndAcct')} />
      {can(user, 'accounts_setup') ? <ListItem testID="books-coa" title="Chart of accounts" onPress={go('ChartOfAccounts')} /> : null}
      <ListItem testID="books-year" title="Year-end pack for the accountant" onPress={go('YearEndAcct')} />
      {boss(user) ? <ListItem testID="books-adjust" title="Book an adjustment" sub="Asked by the accountant – with a reason" onPress={go('BooksAdjust')} /> : null}
      <Hint>Months already closed are locked; a change after closing is an adjustment with a reason.</Hint>
    </Screen>
  );
}
export function BooksJournalScreen({ params = {} }) {
  const { nav } = useApp();
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);
  const [more, setMore] = useState(60);
  const r = V.monthRange(ym);
  const j = useMemo(() => tryRun(() => V.journalList({ from: r.from, to: r.to, limit: more, q })), [ym, q, more]);
  return (
    <Screen title="Journal" subtitle={`${V.ymLabel(ym)} · every entry, newest first`}>
      <MonthPicker ym={ym} onChange={(x) => { setYm(x); setMore(60); }} testID="jn" />
      <Field testID="jn-search" label="Search" value={q} onChangeText={setQ} placeholder="Supplier, invoice, Z number…" />
      {j.error ? <Banner tone="danger" message={j.error} /> : null}
      {(j.rows || []).map((e, i) => {
        const k = `${e.ref}|${i}`;
        return (
          <View key={k} style={{ gap: 6 }}>
            <ListItem testID={`jn-row-${i}`} title={`${e.date.slice(8, 10)} ${V.ymLabel(e.date.slice(0, 7)).slice(0, 3)} · ${e.text}`} sub={`${e.src}${e.who ? ` · ${e.who.by} · ${e.who.at}` : ''}`} right={$(e.amount)} onPress={() => setOpen(open === k ? null : k)} />
            {open === k ? (
              <Card>
                {e.lines.map((l, x) => <Text key={x} style={{ fontSize: 15, color: C.text }}>{`${l.debit ? 'Dr' : '   Cr'} ${l.name} · ${A.areaLabel(l.shop)}  ${$(l.debit || l.credit)}`}</Text>)}
                <Btn testID={`jn-open-${i}`} title="Open the record" size="sm" variant="secondary" onPress={() => nav.push(e.nav.screen, e.nav.params || {})} />
              </Card>
            ) : null}
          </View>
        );
      })}
      {j.total > (j.rows || []).length ? <Btn testID="jn-more" title={`Show more (${j.total - j.rows.length} left)`} size="md" variant="secondary" onPress={() => setMore((x) => x + 60)} /> : null}
    </Screen>
  );
}
export function BooksLedgerScreen({ params = {} }) {
  const { nav } = useApp();
  const [code, setCode] = useState(params.code || '1000');
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [shop, setShop] = useState('');
  const r = V.monthRange(ym);
  const accts = useMemo(() => tryRun(() => A.listAccountsGL()), []);
  const l = useMemo(() => tryRun(() => V.ledgerLines(code, { from: r.from, to: r.to, shop: shop || undefined })), [code, ym, shop]);
  const shops = V.operatingShops();
  return (
    <Screen title="General ledger" subtitle={l.name || code}>
      <Select testID="led-account" label="Account" value={code} onChange={setCode} search options={(Array.isArray(accts) ? accts : []).map((a) => ({ value: a.code, label: `${a.code.startsWith('1100:') ? '1100' : a.code} ${a.name}` }))} />
      <Select testID="led-shop" label="Shop" value={shop} onChange={setShop} options={[{ value: '', label: 'Whole business' }].concat(shops.map((s) => ({ value: s.code, label: s.name })), [{ value: A.CLOSED, label: 'Closed shop' }, { value: A.OFFICE, label: 'Office' }])} />
      <MonthPicker ym={ym} onChange={setYm} testID="led" />
      {l.error ? <Banner tone="danger" message={l.error} /> : (
        <>
          <ListItem title={`${r.from.slice(8, 10)} ${V.ymLabel(ym).slice(0, 3)} opening`} right={$(l.opening)} />
          {l.lines.map((x, i) => <ListItem key={i} testID={`led-line-${i}`} title={`${x.date.slice(8, 10)} · ${x.text}`} sub={`${x.src} · ${A.areaLabel(x.shop)} · balance ${$(x.balance)}`} right={x.debit ? `+${$(x.debit)}` : `−${$(x.credit)}`} onPress={() => nav.push(x.nav.screen, x.nav.params || {})} />)}
          <ListItem testID="led-closing" title={`${r.to.slice(8, 10)} ${V.ymLabel(ym).slice(0, 3)} balance`} right={$(l.closing)} tone="success" />
          <Hint>Tap a line to open the record behind it.</Hint>
        </>
      )}
    </Screen>
  );
}
// An adjustment the accountant asked for (owner / admin): one amount from one account to another, with a reason.
export function BooksAdjustScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const lock = lockDate();
  const accts = useMemo(() => tryRun(() => A.listAccountsGL()), []);
  const months = [];
  for (let k = 1; k <= 13; k += 1) months.push(V.ymAdd(dateStr().slice(0, 7), -k));
  const [f, setF] = useState({ forYm: lock ? lock.slice(0, 7) : months[0], memo: '', reason: '', dr: '', cr: '', amount: '' });
  const opts = (Array.isArray(accts) ? accts : []).map((a) => ({ value: a.code, label: `${a.code.startsWith('1100:') ? '1100' : a.code} ${a.name}` }));
  const save = () => {
    const r = act(() => V.saveAdjustment(user, { forYm: f.forYm, memo: f.memo, reason: f.reason, lines: [{ code: f.dr, debit: Number(f.amount) }, { code: f.cr, credit: Number(f.amount) }] }), 'Adjustment booked');
    if (r) nav.pop();
  };
  return (
    <Screen title="Book an adjustment" subtitle={lock ? `Closed up to ${lock}` : 'No month closed yet'} footer={<Btn testID="adj-save" title="Book it" variant="primary" onPress={save} />}>
      <Hint>Closed months are never changed. The adjustment goes on the first open day and says which month it is for and why.</Hint>
      <Select testID="adj-month" label="For the month" value={f.forYm} onChange={(v) => setF({ ...f, forYm: v })} options={months.map((m) => ({ value: m, label: V.ymLabel(m) }))} />
      <Field testID="adj-memo" label="What it is" value={f.memo} onChangeText={(v) => setF({ ...f, memo: v })} placeholder="e.g. Depreciation – van" />
      <Field testID="adj-reason" label="Why" value={f.reason} onChangeText={(v) => setF({ ...f, reason: v })} placeholder="e.g. asked by the accountant" />
      <Select testID="adj-dr" label="Add to (debit)" value={f.dr} onChange={(v) => setF({ ...f, dr: v })} options={opts} search />
      <Select testID="adj-cr" label="Take from (credit)" value={f.cr} onChange={(v) => setF({ ...f, cr: v })} options={opts} search />
      <MoneyField testID="adj-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
    </Screen>
  );
}
