// Release 18: closing the week (Monday – Sunday, split at the month end) – each week of the month with what is still
// open, and "Close the week" (invoices still waiting can be brought forward to next week).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, useAct, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import * as WK from '../weekClose.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const shift = (ym, n) => { const d = new Date(Number(ym.slice(0, 4)), Number(ym.slice(5, 7)) - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const dm = (d) => { const t = new Date(`${d}T00:00:00`); return `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][t.getDay()]} ${t.getDate()}`; };

export function WeekCloseScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const [ym, setYm] = useState(params.ym || dateStr().slice(0, 7));
  const [open, setOpen] = useState(params.week || null);
  const [n, bump] = useState(0);
  const weeks = React.useMemo(() => { try { return WK.monthWeeks(ym); } catch (e) { return []; } }, [ym, n]);
  const w = open ? weeks.find((x) => x.key === open) : null;
  if (w) {
    const invs = [].concat(...w.shops.map((s) => s.invoicesToCheck.map((i) => ({ ...i, shop: s.name }))));
    return (
      <Screen title={`Week ${dm(w.from)} – ${dm(w.to)} ${MONTHS[Number(w.ym.slice(5, 7)) - 1]}`} subtitle={w.closed ? `Closed by ${w.info.by} on ${String(w.info.at).slice(0, 16)}` : 'Close the week'} onBack={() => setOpen(null)}>
        {w.closed ? <Banner tone="success" message={`Closed${w.info.carried && w.info.carried.length ? ` – ${w.info.carried.length} invoice(s) brought forward to next week` : ''}.`} /> : null}
        {w.shops.map((s) => (
          <Card key={s.code}>
            <H>{s.name}</H>
            {!s.daysToCheck.length && !s.invoicesToCheck.length ? <Text style={{ color: C.successText }}>✓ All checked</Text> : null}
            {s.daysToCheck.length ? <ListItem testID={`wk-days-${s.code}`} title={`${s.daysToCheck.length} day${s.daysToCheck.length === 1 ? '' : 's'} of sales to check`} sub={s.daysToCheck.map(dm).join(', ')} tone="warn" onPress={() => nav.push('ShopPage', { shop: s.code, ym: w.ym, tab: 'sales' })} /> : null}
            {s.invoicesToCheck.map((i) => <ListItem key={i.uid} testID={`wk-inv-${i.uid}`} title={`${i.supplier}${i.no ? ` ${i.no}` : ''}`} sub={`${i.date}${i.carried ? ' · brought forward from last week' : ''} · to check`} right={`$${Number(i.total).toFixed(2)}`} tone="warn" onPress={() => nav.push('ApInvoice', { uid: i.uid })} />)}
            {/* Release 37: each shop closes its own week */}
            {s.closed ? (
              <>
                <Text testID={`wk-shop-closed-${s.code}`} style={{ fontSize: 16, fontWeight: '800', color: C.successText, marginTop: 6 }}>{`✓ ${s.name}'s week closed by ${s.info.by} · ${String(s.info.at).slice(0, 16)}${s.info.carried && s.info.carried.length ? ` · ${s.info.carried.length} invoice(s) to next week` : ''}`}</Text>
                {['owner', 'admin'].includes(user.role) ? <ReasonButton testID={`wk-shop-reopen-${s.code}`} title={`Reopen ${s.name}'s week`} prompt="Why reopen it?" confirm="Reopen" variant="warn" onDo={(why) => { const ok = act(() => WK.reopenShopWeek(user, w.key, s.code, why), 'Reopened'); if (ok) bump((x) => x + 1); return ok; }} /> : null}
              </>
            ) : (
              <>
                <Btn testID={`wk-shop-close-${s.code}`} title={`Close ${s.name}'s week`} icon="✅" size="md" variant="success" disabled={!s.ready || !w.ended} onPress={() => { if (act(() => WK.closeShopWeek(user, w.key, s.code), `${s.name}: week closed`)) bump((x) => x + 1); }} />
                {s.invoicesToCheck.length && !s.daysToCheck.length && w.ended ? <Btn testID={`wk-shop-carry-${s.code}`} title={`Bring ${s.name}'s ${s.invoicesToCheck.length} invoice(s) to next week and close`} icon="➡️" size="sm" variant="secondary" onPress={() => { if (act(() => WK.closeShopWeek(user, w.key, s.code, { carry: true }), `${s.name}: week closed – invoices brought forward`)) bump((x) => x + 1); }} /> : null}
              </>
            )}
          </Card>
        ))}
        <Card testID="wk-business">
          <H>The business (all shops)</H>
          {w.business.invoicesToCheck.map((i) => <ListItem key={i.uid} testID={`wk-binv-${i.uid}`} title={`${i.supplier}${i.no ? ` ${i.no}` : ''}`} sub={`${i.date} · no shop (loans, rent, office)${i.carried ? ' · brought forward' : ''} · to check`} right={`$${Number(i.total).toFixed(2)}`} tone="warn" onPress={() => nav.push('ApInvoice', { uid: i.uid })} />)}
          {w.business.shopsOpen.length && !w.closed ? <Text style={{ fontSize: 15, color: C.warn }}>{`Close each shop's week first: ${w.business.shopsOpen.join(', ')}`}</Text> : null}
          {!w.business.invoicesToCheck.length && !w.business.shopsOpen.length && !w.closed ? <Text style={{ color: C.successText }}>✓ Every shop closed – the business's week can close</Text> : null}
        </Card>
        {!w.closed ? (
          <>
            {!w.ended ? <Hint>{`The week ends on ${dm(w.to)}. Close it then (Sunday is a good day) or after.`}</Hint> : null}
            <Btn testID="wk-close" title="Close the week for the business" icon="🏁" size="lg" variant="success" disabled={!w.ready || !w.ended || w.business.shopsOpen.length > 0} onPress={() => { if (act(() => WK.closeWeek(user, w.key), 'Week closed for the business')) bump((x) => x + 1); }} />
            {w.business.invoicesToCheck.length && !w.daysOpen && w.ended && !w.business.shopsOpen.length ? <Btn testID="wk-close-carry" title={`Bring the business's ${w.business.invoicesToCheck.length} invoice(s) to next week and close`} icon="➡️" size="md" variant="secondary" onPress={() => { if (act(() => WK.closeWeek(user, w.key, { carry: true }), 'Week closed – invoices brought forward')) bump((x) => x + 1); }} /> : null}
          </>
        ) : ['owner', 'admin'].includes(user.role) ? <ReasonButton testID="wk-reopen" title="Reopen this week" prompt="Why reopen it?" confirm="Reopen" variant="warn" onDo={(why) => { const ok = act(() => WK.reopenWeek(user, w.key, why), 'Reopened'); if (ok) bump((x) => x + 1); return ok; }} /> : null}
      </Screen>
    );
  }
  return (
    <Screen title="Close the week" subtitle={`${ymLabel(ym)} · Monday – Sunday, split at the month end`}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Month before" size="sm" variant="secondary" style={{ flex: 1 }} onPress={() => setYm(shift(ym, -1))} />
        <Btn title="Next month ›" size="sm" variant="secondary" style={{ flex: 1 }} disabled={ym >= dateStr().slice(0, 7)} onPress={() => setYm(shift(ym, 1))} />
      </View>
      <Hint>Close each week when its sales days and supplier invoices are checked – then closing the month is quick. An invoice still waiting can be brought forward to next week.</Hint>
      {weeks.map((x) => (
        <ListItem key={x.key} testID={`wk-${x.key}`} title={`Week ${x.n}: ${dm(x.from)} – ${dm(x.to)}`}
          sub={x.closed ? `Closed by ${x.info.by}` : x.from > dateStr() ? 'Not started' : x.shops.some((sh) => sh.closed) ? `${x.shops.map((sh) => `${sh.name.split(' - ')[0]} ${sh.closed ? '✓' : '…'}`).join(' · ')} · business …` : x.ready ? (x.ended ? 'Ready to close' : 'All checked so far') : `${x.daysOpen ? `${x.daysOpen} day(s) to check` : ''}${x.daysOpen && x.invOpen ? ' · ' : ''}${x.invOpen ? `${x.invOpen} invoice(s) to check` : ''}`}
          tone={x.closed ? 'success' : x.from > dateStr() ? undefined : x.ready && x.ended ? 'info' : 'warn'} badge={x.closed ? '✓' : undefined} badgeColor={C.success} onPress={x.from > dateStr() ? undefined : () => setOpen(x.key)} />
      ))}
      <Btn testID="wk-month" title={`Close ${ymLabel(ym)} (month end)`} icon="📅" size="md" variant="secondary" onPress={() => nav.push('MonthClose', { ym })} />
    </Screen>
  );
}
