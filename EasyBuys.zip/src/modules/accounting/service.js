// Accounting & VAT. Double-entry books worked out from what is already recorded in the other modules:
//   sales and VAT from the till counts (Z reports), supplier invoices and payments, deposits, petty cash and cash moved,
//   bank fees / interest / other bank lines, payroll (wages, FNPF, PAYE), staff advances and charges, stock on hand,
//   fixed assets (depreciation) and manual journals.
// Nothing is typed twice and the books always agree with the modules. Each line carries the shop it belongs to
// (or "Office" when it is not for one shop), so there is a profit & loss and a VAT return per shop.
// Financial year: January – December.
import { db, writeCount, keepUntilChanged, keepTracked } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { lockDate, assertOpen } from '../../services/lock.js';
import { apRules } from '../payables/service.js';
import { payRules } from '../payroll/service.js';
import { needReason, actsAsOwner, can } from '../../services/access.js';
import { requirePerm, requireOwner, asService } from '../../services/guard.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const hasTable = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const has = hasTable;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
export const OFFICE = 'OFFICE';
// The closed V M Pillay shop: its own cost area / column "Closed shop costs", never charged to S1 or S2.
export const CLOSED = 'CLOSED';
export const areaLabel = (c) => (!c || c === OFFICE ? 'Office' : c === CLOSED ? 'Closed shop costs' : c);

// ---------------------------------------------------------------- chart of accounts
export const TYPES = { asset: 'Asset (what we own)', liability: 'Liability (what we owe)', equity: 'Owner\'s equity', income: 'Income', cogs: 'Cost of goods sold', expense: 'Expense' };
export const DEFAULT_ACCOUNTS = [
  ['1000', 'Cash at the shops (safe / office)', 'asset', 'Cash'], ['1010', 'Till floats', 'asset', 'Cash'],
  ['1110', 'Card, M-PAiSA, MyCash & cheques to be banked', 'asset', 'Receivables'], ['1200', 'Customers owing (on account)', 'asset', 'Receivables'],
  ['1250', 'Staff advances, loans & charges', 'asset', 'Receivables'], ['1300', 'Stock on hand', 'asset', 'Stock'],
  ['1500', 'Equipment, fittings & vehicles (cost)', 'asset', 'Fixed assets'], ['1590', 'Less: depreciation to date', 'asset', 'Fixed assets'],
  ['2000', 'Suppliers owed', 'liability', 'Payables'], ['2100', 'FNPF to pay', 'liability', 'Payroll'], ['2110', 'PAYE / SRT to pay', 'liability', 'Payroll'],
  ['2190', 'Other pay deductions to pay', 'liability', 'Payroll'], ['2200', 'VAT (output less input)', 'liability', 'Tax'], ['2500', 'Loans', 'liability', 'Loans'],
  ['2900', 'Suspense – to be sorted out', 'liability', 'Suspense'],
  ['3000', 'Owner\'s capital & opening balances', 'equity', 'Equity'], ['3100', 'Owner\'s money in / drawings', 'equity', 'Equity'], ['3900', 'Profit kept from earlier years', 'equity', 'Equity'],
  ['4000', 'Sales', 'income', 'Sales'], ['4900', 'Interest & other income', 'income', 'Other income'],
  ['5000', 'Purchases – stock for resale', 'cogs', 'Cost of sales'], ['5010', 'Purchases – bakery ingredients', 'cogs', 'Cost of sales'], ['5100', 'Change in stock on hand', 'cogs', 'Cost of sales'],
  ['5200', 'Packaging', 'cogs', 'Cost of sales'],
  ['6000', 'Rent', 'expense', 'Premises'], ['6010', 'Power & water', 'expense', 'Premises'], ['6020', 'Phone & internet', 'expense', 'Office'], ['6030', 'Repairs & maintenance', 'expense', 'Premises'],
  ['6040', 'Transport & fuel', 'expense', 'Transport'], ['6050', 'Cleaning', 'expense', 'Premises'], ['6060', 'Office & stationery', 'expense', 'Office'],
  ['6100', 'Wages', 'expense', 'Staff'], ['6110', 'FNPF – employer share', 'expense', 'Staff'], ['6500', 'Petty cash & general', 'expense', 'Other'],
  ['6600', 'Bank fees', 'expense', 'Finance'], ['6700', 'Interest paid', 'expense', 'Finance'], ['6800', 'Depreciation', 'expense', 'Other'],
  ['6900', 'Cash short / over & corrections', 'expense', 'Other'], ['6990', 'Other expenses', 'expense', 'Other'],
  // Added in version 3.4
  ['1400', 'Paid in advance (prepayments)', 'asset', 'Prepayments'], ['1450', 'Company tax paid in advance', 'asset', 'Tax'],
  ['2300', 'Costs owing, not billed yet (accruals)', 'liability', 'Accruals'], ['2600', 'Provisional tax withheld (5%) to pay', 'liability', 'Tax'],
  ['2700', 'Company income tax to pay', 'liability', 'Tax'], ['4100', 'Other sales (not through the tills)', 'income', 'Sales'],
  ['6200', 'Advertising', 'expense', 'Other'], ['6210', 'Insurance', 'expense', 'Other'], ['6220', 'Licences & permits', 'expense', 'Other'],
  ['6230', 'Accounting & legal fees', 'expense', 'Office'], ['6240', 'Security', 'expense', 'Premises'], ['6120', 'Staff welfare & uniforms', 'expense', 'Staff'],
  ['8000', 'Company income tax', 'expense', 'Tax'],
  // Added in version 3.9
  ['6250', 'Tax & FNPF penalties and interest', 'expense', 'Tax'],
  // Added in version 1.0.0: the cigarette money put aside at each shift (still the shop's cash, kept apart)
  ['1020', 'Cigarette fund (cash put aside)', 'asset', 'Cash'],
  // Added in version 1.0.0 (2 Nov): the recharge machines – each shop's Vodafone and Inkk balance is its own current
  // asset (till/recharge.js walletCode); top-ups paid wait in 1030 until put on the machine; commission is income.
  ['1030', 'Recharge top-ups paid (to put on the machines)', 'asset', 'Recharge machines'],
  ['1031', 'Recharge machine – Shop 1 Vodafone', 'asset', 'Recharge machines'], ['1032', 'Recharge machine – Shop 1 Inkk', 'asset', 'Recharge machines'],
  ['1033', 'Recharge machine – Shop 2 Vodafone', 'asset', 'Recharge machines'], ['1034', 'Recharge machine – Shop 2 Inkk', 'asset', 'Recharge machines'],
  ['4300', 'Recharge commission', 'income', 'Other income'], ['5300', 'Recharge sold (face value off the machines)', 'cogs', 'Cost of sales'],
];
let accountsChecked = null;
// v3.9.7 till checks start at the go-live date (earlier End of days and shifts are history only).
function liveOr(from) {
  try { const g = require('../../services/goLive.js').freshFrom(); return g && g > from ? g : from; } catch (e) { return from; }
}
export function ensureAccounts() {
  // Accounts added in a later version are added once (an account is never deleted, only switched off).
  if (accountsChecked === db()) return;
  const have = new Set(db().all('SELECT code FROM gl_accounts').map((r) => r.code));
  accountsChecked = db();
  if (DEFAULT_ACCOUNTS.every(([c]) => have.has(c))) return;
  const { now, dev } = meta();
  for (const [code, name, type, grp] of DEFAULT_ACCOUNTS) {
    db().run('INSERT OR IGNORE INTO gl_accounts (code, name, type, grp, system, updated_at, updated_device) VALUES (?,?,?,?,1,?,?)', [code, name, type, grp, now, dev]);
  }
}
export function listAccountsGL({ includeInactive = false } = {}) {
  ensureAccounts();
  const rows = db().all(`SELECT * FROM gl_accounts ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY code`);
  // Each bank account is its own account (1100:<bank uid>).
  const banks = has('bank_accounts') ? db().all('SELECT uid, name, active FROM bank_accounts ORDER BY name') : [];
  // Each loan is its own account (2500:<loan uid>), so each loan's balance is in the books.
  // (the loans are kept in Invoices & cheques › Regular bills & loans)
  const loans = has('ap_recurring') ? db().all("SELECT uid, name, active FROM ap_recurring WHERE kind = 'loan' ORDER BY name").map((l) => ({ uid: l.uid, name: l.name, status: l.active ? 'active' : 'closed' })) : [];
  return rows.concat(banks.filter((b) => includeInactive || b.active).map((b) => ({ code: `1100:${b.uid}`, name: `Bank – ${b.name}`, type: 'asset', grp: 'Bank', system: 1, active: b.active })))
    .concat(loans.filter((l) => includeInactive || l.status === 'active').map((l) => ({ code: `2500:${l.uid}`, name: `Loan – ${l.name}`, type: 'liability', grp: 'Loans', system: 1, active: l.status === 'active' ? 1 : 0 })))
    .sort((a, b) => (a.code < b.code ? -1 : 1));
}
export function accountName(code) {
  // 1.0.0 the names of all accounts, kept until an account, bank account or loan changes (asked once per line of a
  // report – thousands of times for the accountant pack)
  ensureAccounts();
  const names = keepUntilChanged('acc|names', ['gl_accounts', 'bank_accounts', 'ap_recurring'], () => {
    const m = new Map();
    for (const x of listAccountsGL({ includeInactive: true })) if (!m.has(x.code)) m.set(x.code, x.name);
    return m;
  });
  return names.has(code) ? names.get(code) : code;
}
export function saveAccountGL(user, { code, name, type, grp, active = true, note }) {
  requirePerm(user, 'accounts_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  ensureAccounts();
  const c = txt(code);
  need(/^\d{3,6}$/.test(c), 'The account code is 3 to 6 digits, e.g. 6070.');
  need(txt(name), 'Enter the account name.');
  need(TYPES[type], 'Choose the type.');
  const before = db().get('SELECT * FROM gl_accounts WHERE code = ?', [c]);
  if (before && before.system) need(before.type === type, 'The type of a built-in account cannot be changed.');
  const { now, dev } = meta();
  db().run(`INSERT INTO gl_accounts (code, name, type, grp, active, system, note, updated_at, updated_device) VALUES (?,?,?,?,?,0,?,?,?)
    ON CONFLICT(code) DO UPDATE SET name = excluded.name, type = excluded.type, grp = excluded.grp, active = excluded.active, note = excluded.note,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`, [c, txt(name), type, txt(grp) || null, active ? 1 : 0, txt(note) || null, now, dev]);
  audit({ user, action: `${before ? 'Changed' : 'Added'} account ${c} ${txt(name)}`, table: 'gl_accounts', recordUid: c });
  });
}
const typeOf = (code, accts) => (String(code).startsWith('1100:') ? 'asset' : String(code).startsWith('2500:') ? 'liability' : (accts[code] || {}).type || 'expense');
export const isBankCode = (c) => String(c).startsWith('1100:');

// ---------------------------------------------------------------- which account things go to (admin can change)
export const MAP_DEFAULTS = {
  ap: { 'Stock for resale': '5000', 'Bakery ingredients': '5010', Liquor: '5000', Rent: '6000', 'Power & water': '6010', 'Phone & internet': '6020', Repairs: '6030', 'Transport & fuel': '6040',
    Packaging: '5200', Cleaning: '6050', Office: '6060', Equipment: '1500', 'Loan repayment': '2500', Other: '6990', 'Recharge machine top-up': '1030' },
  petty: { Cleaning: '6050', Office: '6060', Transport: '6040', 'Food & tea': '6500', Repairs: '6030', Other: '6500' },
  tenders: { 'On account (credit sales)': '1200', default: '1110' },
  payouts: { 'Supplier paid from till': '5000', Refund: '4000', 'Staff advance': '1250', 'Petty cash': '6500', Other: '6990' },
};
export function glMap() {
  const s = getShared('gl_map', {}) || {};
  return { ap: { ...MAP_DEFAULTS.ap, ...(s.ap || {}) }, petty: { ...MAP_DEFAULTS.petty, ...(s.petty || {}) }, tenders: { ...MAP_DEFAULTS.tenders, ...(s.tenders || {}) }, payouts: { ...MAP_DEFAULTS.payouts, ...(s.payouts || {}) } };
}
export function saveGlMap(user, m) {
  requirePerm(user, 'accounts_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const before = glMap();
  setShared('gl_map', m);
  audit({ user, action: 'Changed which accounts things are booked to', table: 'shared_settings', recordUid: 'gl_map', before, after: m });
  });
}
const mapAp = (cat, m) => m.ap[cat] || m.ap.Other || '6990';

// ---------------------------------------------------------------- the entries
// Each entry: { date, src, ref, text, shop, lines: [{ code, amount }] } – amount > 0 is a debit, < 0 a credit. Lines always add to 0.
const L = (code, amount, shop) => ({ code, amount: r2(amount), shop });
function entry(out, e) {
  const lines = e.lines.filter((l) => Math.abs(l.amount) > 0.0049);
  if (!lines.length) return;
  const off = r2(lines.reduce((s, l) => s + l.amount, 0));
  if (Math.abs(off) > 0.009) lines.push(L('2900', -off, e.shop)); // never lose a cent: anything that does not balance goes to suspense
  out.push({ ...e, lines: lines.map((l) => ({ ...l, shop: l.shop || e.shop || OFFICE })) });
}
const bankCode = (uid) => `1100:${uid}`;

// The books are worked out again only when something they are made from changed (or for other dates).
// 1.0.0: kept until one of ENTRY_TABLES changes (was: until anything at all was saved – a warning noted, a setting…).
// Every table workOutEntries (and eodFixes) reads must be in this list: tests/v1perf.test.js checks it.
export const ENTRY_TABLES = ['cheques', 'till_counts', 'aronium_eods', 'ap_payments', 'ap_allocations', 'cash_moves', 'staff_debts', 'deposits', 'ap_recurring', 'loan_entries', 'ap_invoices',
  'bank_entries', 'wallet_moves', 'wallets', 'pay_runs', 'pay_lines', 'staff_charges', 'stat_payments', 'inv_moves', 'inv_stock_months', 'inv_items', 'fixed_assets',
  'gl_journals', 'shared_settings', 'recharge_moves', 'recharge_sales'];
export function entries({ from = '0000-01-01', to = dateStr() } = {}) {
  // round 2: a period over more than half a year is put together from one piece per half-year (each kept on its own;
  // the same entries in the same order – every entry is dated, and each year is worked out exactly as the whole would
  // be). So a part of the app can work the years out one at a time (entryChunks), and they are shared between asks.
  const chunks = entryChunks(from, to);
  if (chunks.length === 1) return keepUntilChanged(`acc|entries|${from}|${to}`, ENTRY_TABLES, () => workOutEntries({ from, to }));
  return keepUntilChanged(`acc|entries|${from}|${to}`, ENTRY_TABLES, () => chunks.flatMap(([a, b]) => entries({ from: a, to: b })));
}
// The pieces of a period: [from, to] pairs, one per half-year.
export function entryChunks(from = '0000-01-01', to = dateStr()) {
  if (!DATE.test(String(from)) || !DATE.test(String(to)) || from > to) return [[from, to]];
  // the first piece starts at `from` and ends with the half-year of the first day really worked out (from, or for
  // 0000-01-01 the earliest record – inside it the months are counted from there, as for the whole period)
  let start = from;
  if (from < '2000-01-01') { const e = earliestDate(); if (!e || !DATE.test(e) || e > to) return [[from, to]]; start = e; }
  const halfEnd = (d) => (d.slice(5, 7) <= '06' ? `${d.slice(0, 4)}-06-30` : `${d.slice(0, 4)}-12-31`);
  const out = [];
  let a = from; let b = halfEnd(start);
  for (;;) {
    out.push([a, b < to ? b : to]);
    if (b >= to) break;
    a = addDays(b, 1); b = halfEnd(a);
  }
  return out;
}
// 1.0.0 speed: only the columns the books use are read (a till count row also holds its notes, coins and signatures).
// A column this device does not have yet is simply left out (it reads as undefined, as with SELECT *).
function colsOf(t, wanted) {
  let have = null;
  try { have = new Set(db().all(`PRAGMA table_info(${t})`).map((c) => c.name)); } catch (e) { have = null; }
  const list = have ? wanted.filter((c) => have.has(c)) : [];
  return list.length ? list.join(', ') : '*';
}
// 1.0.0 every list below has an ORDER BY: lines of the same day and kind always come in the same order, whatever
// index SQLite picks (with new indexes and statistics the order could otherwise change). Each ORDER BY is the order the
// books gave before (checked on the 3-year data: shop / supplier / account, date, then as saved).
function workOutEntries({ from, to }) {
  // the tables do not come or go while the books are worked out: each is looked up once
  const hasT = new Map();
  const has = (t) => { if (!hasT.has(t)) hasT.set(t, hasTable(t)); return hasT.get(t); };
  const m = glMap();
  const vat = Number(apRules().vatRate) || 12.5;
  const out = [];
  // Only whole dates (YYYY-MM-DD) are used, so a half-typed or odd date can never break the query.
  const okDate = (x, def) => (/^\d{4}-\d{2}-\d{2}$/.test(String(x || '')) ? String(x) : def);
  from = okDate(from, '0000-01-01'); to = okDate(to, dateStr());
  const between = (col) => `${col} BETWEEN '${from}' AND '${to}'`;
  // Sales (till counts with their Z report)
  if (has('till_counts')) {
    // 1.0.0 build 1 (stream B): an End of day difference explained "Aronium is right" – the sales and the payment types
    // follow Aronium's figures (till/eod.js eodFixes); the typed till balance itself is kept as it was.
    let fixes = new Map();
    try { fixes = require('../till/eod.js').eodFixes({ from, to }); } catch (e) { fixes = new Map(); }
    // A supplier paid in cash out of a till is booked by the payment (cash 1000 → the supplier); the same money written
    // as "Supplier paid from till" on the till count only says the cash left the drawer – not a second purchase.
    const fromTill = new Map();
    if (has('ap_payments')) {
      try {
        db().all(`SELECT cash_from, pay_date, SUM(amount - IFNULL(withheld,0)) AS s FROM ap_payments WHERE status = 'active' AND method = 'cash' AND cash_from LIKE 'till:%' AND ${between('pay_date')} GROUP BY cash_from, pay_date`)
          .forEach((r) => fromTill.set(`${String(r.cash_from).slice(5)}|${r.pay_date}`, r2(r.s)));
      } catch (e) { /* older data */ }
    }
    const tcCols = colsOf('till_counts', ['uid', 'shop_code', 'till_uid', 'till_name', 'shift_date', 'shift', 'z_number', 'z_total', 'z_cash', 'z_vat', 'z_zero_rated', 'tenders', 'payouts', 'cash_counted', 'float_kept', 'opening_float', 'drops']);
    for (const c of db().all(`SELECT ${tcCols} FROM till_counts WHERE status <> 'void' AND ${between('shift_date')} ORDER BY shop_code, shift_date, rowid`)) {
      const s = c.shop_code;
      const fx = fixes.get(c.uid) || null;
      const total = Number(c.z_total);
      const zTotal0 = Number.isFinite(total) && c.z_total !== null ? total : r2(Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0));
      const zTotal = fx ? r2(zTotal0 + fx.total) : zTotal0;
      const zero = Number(c.z_zero_rated) || 0;
      const outVat = c.z_vat !== null && c.z_vat !== undefined ? r2(Number(c.z_vat) + (fx && fx.vat !== null ? fx.vat : 0)) : r2((zTotal - zero) - (zTotal - zero) / (1 + vat / 100));
      const toSafe = r2(Number(c.cash_counted) - Number(c.float_kept) + Number(c.drops || 0));
      const lines = [L('1000', toSafe, s), L('1010', Number(c.float_kept) - Number(c.opening_float), s)];
      J(c.tenders, []).concat(fx ? fx.tenders : []).forEach((t) => lines.push(L(m.tenders[t.method] || m.tenders.default, t.amount, s)));
      J(c.payouts, []).forEach((p) => {
        const k = `${c.till_uid}|${c.shift_date}`;
        const left = p.what === 'Supplier paid from till' ? r2(fromTill.get(k) || 0) : 0;
        const viaPayment = r2(Math.min(left, r2(p.amount)));
        if (viaPayment > 0) { fromTill.set(k, r2(left - viaPayment)); lines.push(L('1000', viaPayment, s)); }
        if (r2(p.amount) - viaPayment > 0.004) lines.push(L(m.payouts[p.what] || m.payouts.Other, r2(r2(p.amount) - viaPayment), s));
      });
      lines.push(L('4000', -(zTotal - outVat), s), L('2200', -outVat, s));
      const off = r2(lines.reduce((t, l) => t + l.amount, 0));
      lines.push(L('6900', -off, s)); // cash short (debit) / over (credit) and hand corrections
      entry(out, { date: c.shift_date, src: 'Till', ref: c.uid, text: `${c.till_name || 'Till'} ${c.shift || ''} Z ${c.z_number || ''}`.trim(), shop: s, lines });
    }
  }
  // Cash at the shops (not from tills, not deposits – those are booked with the till count and the deposit)
  if (has('cash_moves')) {
    const debtUids = has('staff_debts') ? new Set(db().all('SELECT uid FROM staff_debts').map((r) => r.uid)) : new Set();
    for (const x of db().all(`SELECT ${colsOf('cash_moves', ['uid', 'shop_code', 'move_date', 'type', 'amount', 'category', 'note', 'ref_uid'])} FROM cash_moves WHERE status = 'active' AND type NOT IN ('from_till','deposit') AND ${between('move_date')} ORDER BY shop_code, move_date, rowid`)) {
      if (x.ref_uid && debtUids.has(x.ref_uid)) continue; // advances and loans are booked with the staff debt below
      if (String(x.ref_uid || '').startsWith('OM-')) continue; // owner's money: booked by its own journal (Owner's money module)
      const s = x.shop_code;
      const a = Number(x.amount);
      // 1.0.0 cigarette money put aside (or given back) only moves cash into the cigarette fund – not a cost; the
      // weekly cigarette invoice paid from the fund is then taken from the fund (below), not from the shop's cash again.
      const other = x.category === 'cig_fund' && ['adjust_in', 'adjust_out'].includes(x.type) ? '1020'
        : { opening: '3000', petty_out: m.petty[x.category] || m.petty.Other || '6500', petty_in: '3100', transfer_in: '1000', transfer_out: '1000', adjust_in: '6900', adjust_out: '6900' }[x.type] || '2900';
      const sign = ['opening', 'petty_in', 'transfer_in', 'adjust_in'].includes(x.type) ? 1 : -1;
      if (x.type === 'transfer_in' || x.type === 'transfer_out') { entry(out, { date: x.move_date, src: 'Cash', ref: x.uid, text: `Cash ${x.type === 'transfer_in' ? 'in from' : 'out to'} another shop`, shop: s, lines: [L('1000', sign * a, s), L('2900', -sign * a, OFFICE)] }); continue; }
      entry(out, { date: x.move_date, src: 'Cash', ref: x.uid, text: `${x.type.replace('_', ' ')}${x.category ? ` · ${x.category}` : ''}${x.note ? ` · ${x.note}` : ''}`, shop: s, lines: [L('1000', sign * a, s), L(other, -sign * a, s)] });
    }
    // The two halves of a cash transfer share a ref: their suspense lines cancel out.
  }
  // Deposits: cash and cheques from a shop into the bank
  if (has('deposits')) {
    for (const d of db().all(`SELECT ${colsOf('deposits', ['uid', 'deposit_date', 'slip_no', 'shop_code', 'account_uid', 'total', 'cash_amount', 'cheque_amount'])} FROM deposits WHERE status = 'active' AND ${between('deposit_date')} ORDER BY shop_code, deposit_date, rowid`)) {
      entry(out, { date: d.deposit_date, src: 'Deposit', ref: d.uid, text: `Deposit slip ${d.slip_no || ''}`, shop: d.shop_code,
        lines: [L(bankCode(d.account_uid), d.total, OFFICE), L('1000', -Number(d.cash_amount), d.shop_code), L('1110', -Number(d.cheque_amount), d.shop_code)] });
    }
  }
  // Loans (Invoices & cheques › Regular bills & loans): each loan is its own account. The balance at the start,
  // interest and fees from the lender's statement add to it; each repayment bill takes off it.
  const loanIds = has('ap_recurring') ? new Set(db().all("SELECT uid FROM ap_recurring WHERE kind = 'loan'").map((r) => r.uid)) : new Set();
  if (loanIds.size) {
    for (const l of db().all(`SELECT * FROM ap_recurring WHERE kind = 'loan' AND opening_balance > 0 AND opening_date IS NOT NULL AND ${between('opening_date')} ORDER BY rowid`)) {
      entry(out, { date: l.opening_date, src: 'Loan', ref: `LOANOPEN-${l.uid}`, text: `${l.name} – balance at the start`, shop: OFFICE, lines: [L('3000', l.opening_balance, OFFICE), L(`2500:${l.uid}`, -l.opening_balance, OFFICE)] });
    }
    if (has('loan_entries')) {
      for (const e of db().all(`SELECT e.*, r.name, r.shop_code AS loan_shop FROM loan_entries e JOIN ap_recurring r ON r.uid = e.recurring_uid WHERE e.status = 'active' AND ${between('e.entry_date')} ORDER BY e.rowid`)) {
        const acc = { interest: '6700', fee: '6600', adjust_up: '6990', adjust_down: '6990' }[e.type];
        const up = e.type !== 'adjust_down';
        const area = e.loan_shop || OFFICE; // interest and fees belong to the loan's shop / cost area (e.g. the closed shop)
        entry(out, { date: e.entry_date, src: 'Loan', ref: e.uid, text: `${e.name} – ${e.type.replace('_', ' ')}${e.note ? `: ${e.note}` : ''}`, shop: area,
          lines: [L(acc, up ? e.amount : -e.amount, area), L(`2500:${e.recurring_uid}`, up ? -e.amount : e.amount, OFFICE)] });
      }
    }
  }
  const loanOf = (invUid) => { const mm = /^RI-(.+)-\d{4}-\d{2}-\d{2}$/.exec(invUid || ''); return mm && loanIds.has(mm[1]) ? mm[1] : null; };
  // Supplier invoices and credit notes (invoice basis)
  if (has('ap_invoices')) {
    for (const i of db().all(`SELECT ${colsOf('ap_invoices', ['uid', 'invoice_date', 'kind', 'shop_code', 'vat', 'total', 'supplier_name', 'invoice_no', 'category'])} FROM ap_invoices WHERE status <> 'void' AND total > 0 AND ${between('invoice_date')} ORDER BY supplier_uid, invoice_date, rowid`)) {
      const sign = i.kind === 'credit' ? -1 : 1;
      const s = i.shop_code || OFFICE;
      const v = Number(i.vat) || 0;
      const loan = loanOf(i.uid);
      entry(out, { date: i.invoice_date, src: i.kind === 'credit' ? 'Credit note' : loan ? 'Loan repayment' : 'Invoice', ref: i.uid, text: `${i.supplier_name} ${i.invoice_no || ''}`.trim(), shop: s,
        lines: [L(loan ? `2500:${loan}` : mapAp(i.category, m), sign * (i.total - v), loan ? OFFICE : s), L('2200', sign * v, s), L('2000', -sign * i.total, OFFICE)] });
    }
  }
  // Payments to suppliers
  if (has('ap_payments')) {
    // listed as before on the 3-year data: cheques, cash, then transfers, each in the order saved (now the same on every device)
    for (const p of db().all(`SELECT ${colsOf('ap_payments', ['uid', 'pay_date', 'method', 'amount', 'withheld', 'cash_from', 'shop_code', 'account_uid', 'supplier_name', 'cheque_no'])} FROM ap_payments WHERE status = 'active' AND method IN ('cheque','cash','transfer') AND ${between('pay_date')} ORDER BY CASE method WHEN 'cheque' THEN 0 WHEN 'cash' THEN 1 ELSE 2 END, rowid`)) {
      // Provisional tax (5%) kept back from a contractor is owed to FRCS instead.
      const held = r2(p.withheld || 0);
      const paid = r2(p.amount - held);
      const from = p.method === 'cash' ? L(String(p.cash_from || '').startsWith('cig:') ? '1020' : '1000', -paid, p.shop_code) : L(bankCode(p.account_uid), -paid, OFFICE);
      entry(out, { date: p.pay_date, src: 'Payment', ref: p.uid, text: `${p.supplier_name} by ${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}`, shop: p.shop_code || OFFICE, lines: [L('2000', p.amount, OFFICE), from, L('2600', -held, OFFICE)] });
    }
  }
  // Release 05: cheques written before the app and paid by the bank after it started (found on the statement). The
  // bank's starting balance still had that money in it, so it comes off the bank against the opening balances.
  if (has('cheques')) {
    for (const c of db().all(`SELECT uid, account_uid, cheque_no, cheque_date, payee, amount FROM cheques WHERE uid LIKE 'CQ-OLD-%' AND status IN ('written','presented') AND payment_uid IS NULL AND ${between('cheque_date')} ORDER BY cheque_no`)) {
      entry(out, { date: c.cheque_date, src: 'Bank', ref: c.uid, text: `Cheque ${c.cheque_no} written before the app${c.payee && c.payee !== 'Written before the app' ? ` · ${c.payee}` : ''}`, shop: OFFICE,
        lines: [L(bankCode(c.account_uid), -r2(c.amount), OFFICE), L('3000', r2(c.amount), OFFICE)] });
    }
  }
  // Bank lines not already booked by a deposit, payment, wages or tax payment
  if (has('bank_entries')) {
    const skip = new Set(db().all('SELECT bank_entry_uid AS u FROM deposits WHERE bank_entry_uid IS NOT NULL').map((r) => r.u));
    for (const e of db().all(`SELECT ${colsOf('bank_entries', ['uid', 'entry_date', 'type', 'amount', 'account_uid', 'split', 'gl_code', 'reference', 'note'])} FROM bank_entries WHERE status = 'active' AND payment_uid IS NULL AND ${between('entry_date')} ORDER BY account_uid, entry_date, rowid`)) {
      if (skip.has(e.uid) || e.uid.startsWith('BE-WAGES-') || e.uid.startsWith('BE-STAT-') || e.uid.startsWith('BE-JN-')) continue;
      const inward = ['deposit', 'interest', 'adjust_in'].includes(e.type);
      const def = { deposit: '1110', interest: '4900', fee: '6600', adjust_in: '2900', adjust_out: '2900', transfer_out: '2900' }[e.type] || '2900';
      const splits = J(e.split, []);
      const lines = [L(bankCode(e.account_uid), inward ? e.amount : -e.amount, OFFICE)];
      if (splits.length) splits.forEach((x) => lines.push(L(x.code, inward ? -r2(x.amount) : r2(x.amount), x.shop || OFFICE)));
      else lines.push(L(e.gl_code || def, inward ? -e.amount : e.amount, OFFICE));
      entry(out, { date: e.entry_date, src: 'Bank', ref: e.uid, text: [e.reference, e.note].filter(Boolean).join(' · ') || e.type, shop: OFFICE, lines });
    }
  }
  // M-PAiSA / MyCash wallets (v3.5): fees and corrections. Sales come in through the till, transfers through the bank.
  if (has('wallet_moves')) {
    for (const m of db().all(`SELECT m.*, w.shop_code AS wshop, w.name AS wname FROM wallet_moves m JOIN wallets w ON w.uid = m.wallet_uid WHERE m.status = 'active' AND m.type IN ('fee','adjust_in','adjust_out') AND ${between('m.move_date')} ORDER BY m.wallet_uid, m.move_date, m.rowid`)) {
      const sign = m.type === 'adjust_in' ? 1 : -1;
      entry(out, { date: m.move_date, src: 'Wallet', ref: m.uid, text: `${m.wname} ${m.type === 'fee' ? 'fee' : 'correction'}${m.note ? ` · ${m.note}` : ''}`, shop: m.wshop || OFFICE,
        lines: [L('1110', sign * m.amount, m.wshop || OFFICE), L(m.type === 'fee' ? '6600' : '2900', -sign * m.amount, m.wshop || OFFICE)] });
    }
  }
  // 1.0.0 the recharge machines (till/recharge.js): a top-up puts the value on the wallet (the paid part waited in 1030
  // from the supplier invoice; the rest is commission); Aronium's recharge sales take the face value off; a difference
  // read off the machine at a shift is a correction (6900).
  if (has('recharge_moves')) {
    let codeOf = null;
    try { codeOf = require('../till/recharge.js').walletCode; } catch (e) { codeOf = null; }
    if (codeOf) {
      for (const x of db().all(`SELECT uid, wallet_uid, shop_code, provider, kind, move_date, amount, paid, commission, diff, reading, supplier_name FROM recharge_moves WHERE status = 'active' AND (kind = 'topup' OR (kind = 'reading' AND ABS(IFNULL(diff,0)) >= 0.005)) AND ${between('move_date')} ORDER BY wallet_uid, move_date, rowid`)) {
        const wc = codeOf(x.shop_code, x.provider); const s = x.shop_code;
        if (x.kind === 'topup') entry(out, { date: x.move_date, src: 'Recharge', ref: x.uid, text: `Recharge ${x.provider} top-up (${x.supplier_name || 'supplier'})`, shop: s, lines: [L(wc, x.amount, s), L('1030', -Number(x.paid || 0), s), L('4300', -Number(x.commission || 0), s)] });
        else entry(out, { date: x.move_date, src: 'Recharge', ref: x.uid, text: `Recharge ${x.provider} ${Number(x.diff) < 0 ? 'short' : 'over'} at the ${x.reading === 'open' ? 'start' : 'end'} of a shift`, shop: s, lines: [L(wc, x.diff, s), L('6900', -Number(x.diff), s)] });
      }
      if (has('recharge_sales')) {
        for (const x of db().all(`SELECT shop_code, provider, sale_date, SUM(value) AS v FROM recharge_sales WHERE ${between('sale_date')} GROUP BY shop_code, provider, sale_date ORDER BY shop_code, provider, sale_date`)) {
          entry(out, { date: x.sale_date, src: 'Recharge', ref: `RS-${x.shop_code}-${x.provider}-${x.sale_date}`, text: `Recharge ${x.provider} sold (Aronium)`, shop: x.shop_code, lines: [L('5300', x.v, x.shop_code), L(codeOf(x.shop_code, x.provider), -Number(x.v), x.shop_code)] });
        }
      }
    }
  }
  // Payroll (final pay runs)
  if (has('pay_runs')) {
    const wagesShop = payRules().wagesDefaultShop || OFFICE;
    const runs = db().all(`SELECT uid, pay_date, week_start FROM pay_runs WHERE status = 'final' AND ${between('pay_date')} ORDER BY rowid`);
    // 1.0.0 the lines of all these runs in one read (each run's lines in the order they were saved)
    const linesOf = new Map(runs.map((r) => [r.uid, []]));
    if (runs.length) {
      const plCols = colsOf('pay_lines', ['run_uid', 'shop_code', 'pay_method', 'gross', 'fnpf_employer', 'fnpf_employee', 'paye', 'deductions', 'net']);
      for (const l of db().all(`SELECT ${plCols} FROM pay_lines WHERE run_uid IN (SELECT uid FROM pay_runs WHERE status = 'final' AND ${between('pay_date')}) AND include = 1 ORDER BY rowid`)) {
        const a = linesOf.get(l.run_uid); if (a) a.push(l);
      }
    }
    const wagesLines = new Map();
    if (runs.length && has('bank_entries')) {
      for (const b of db().all("SELECT uid, amount, account_uid FROM bank_entries WHERE uid LIKE 'BE-WAGES-%' AND status = 'active'")) wagesLines.set(b.uid, b);
    }
    for (const r of runs) {
      const lines = [];
      for (const l of linesOf.get(r.uid)) {
        const s = l.shop_code || (l.pay_method !== 'bank' ? wagesShop : OFFICE);
        lines.push(L('6100', l.gross, s), L('6110', l.fnpf_employer, s), L('2100', -(Number(l.fnpf_employee) + Number(l.fnpf_employer)), OFFICE), L('2110', -l.paye, OFFICE));
        J(l.deductions, []).forEach((d) => lines.push(L(d.debtUid ? '1250' : '2190', -d.amount, OFFICE)));
        if (l.pay_method !== 'bank') lines.push(L('1000', -l.net, s));
        else lines.push(L('2900', -l.net, OFFICE)); // bank wages: cleared by the wages bank line below
      }
      const bankWages = wagesLines.get(`BE-WAGES-${r.uid}`) || null;
      if (bankWages) lines.push(L('2900', bankWages.amount, OFFICE), L(bankCode(bankWages.account_uid), -bankWages.amount, OFFICE));
      entry(out, { date: r.pay_date, src: 'Payroll', ref: r.uid, text: `Wages week ${r.week_start}`, shop: OFFICE, lines });
    }
  }
  // Advances and loans paid to staff; charges (shortages) put on staff
  if (has('staff_debts')) {
    for (const d of db().all(`SELECT * FROM staff_debts WHERE status = 'active' AND ${between('debt_date')} ORDER BY rowid`)) {
      const fromCash = !d.paid_from || String(d.paid_from).startsWith('cash');
      entry(out, { date: d.debt_date, src: 'Staff', ref: d.uid, text: `${d.kind} to ${d.name}`, shop: d.shop_code || OFFICE, lines: [L('1250', d.amount, OFFICE), fromCash ? L('1000', -d.amount, d.shop_code || OFFICE) : L('2900', -d.amount, OFFICE)] });
    }
  }
  if (has('staff_charges')) {
    for (const c of db().all(`SELECT * FROM staff_charges WHERE status = 'active' AND ${between('charge_date')} ORDER BY rowid`)) {
      entry(out, { date: c.charge_date, src: 'Staff', ref: c.uid, text: `Charge to ${c.name}: ${c.reason || c.source}`, shop: c.shop_code || OFFICE, lines: [L('1250', c.amount, OFFICE), L('6900', -c.amount, c.shop_code || OFFICE)] });
    }
  }
  // FNPF / PAYE paid
  if (has('stat_payments')) {
    for (const s of db().all(`SELECT * FROM stat_payments WHERE status = 'active' AND paid_date IS NOT NULL AND ${between('paid_date')} ORDER BY rowid`)) {
      entry(out, { date: s.paid_date, src: 'Tax', ref: s.uid, text: `${s.kind === 'fnpf' ? 'FNPF' : 'PAYE / SRT'} for ${s.period} paid`, shop: OFFICE,
        lines: [L(s.kind === 'fnpf' ? '2100' : '2110', s.paid_amount, OFFICE), s.account_uid ? L(bankCode(s.account_uid), -s.paid_amount, OFFICE) : L('1000', -s.paid_amount, OFFICE)] });
    }
  }
  // Stock: opening stock into the books, then the change in stock on hand at cost each month end (and at `to`)
  if (has('inv_moves')) {
    // 1.0.0 only the shops that have opening stock at all are read (the stock totals per month say which), by shop index
    const SMr = require('../inventory/stockMonths.js');
    const built = SMr.stockMonthsReady();
    const openShops = built && has('inv_stock_months') ? keepUntilChanged('acc|openShops', ['inv_moves', 'inv_stock_months'], () => db().all('SELECT DISTINCT shop_code AS s FROM inv_stock_months WHERE opening = 1 AND n <> 0').map((r) => r.s)) : null;
    const opening = openShops && !openShops.length ? [] : db().all(`SELECT m.move_date AS d, m.shop_code AS s, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
      WHERE ${openShops ? `m.shop_code IN (${openShops.map(() => '?').join(',')}) AND ` : ''}m.status = 'active' AND m.type = 'opening' AND ${between('m.move_date')} GROUP BY m.move_date, m.shop_code ORDER BY m.move_date, m.shop_code`, openShops || []);
    for (const o of opening) {
      entry(out, { date: o.d, src: 'Stock', ref: `OPEN-${o.d}-${o.s}`, text: 'Opening stock (import)', shop: o.s, lines: [L('1300', o.v, o.s), L('3000', -o.v, o.s)] });
    }
    const periods = monthEnds(from, to);
    // 1.0.0 every month end of every shop in one read (inventory/stockMonths.js) – the same figures as stockValueAt
    const shops = !periods.length ? [] : !built ? db().all('SELECT DISTINCT shop_code AS s FROM inv_moves ORDER BY shop_code').map((r) => r.s)
      : keepUntilChanged('acc|stockShops', ['inv_moves', 'inv_stock_months'], () => db().all('SELECT DISTINCT shop_code AS s FROM inv_stock_months ORDER BY shop_code').map((r) => r.s));
    const dates = Array.from(new Set(periods.flatMap((p) => [p.end, addDays(p.start, -1)])));
    const vals = shops.length ? require('../inventory/stockMonths.js').stockValuesUpTo(shops, dates, true) : new Map();
    const valAt = (s, d) => r2(vals.get(`${s}|${d}`) || 0);
    for (const p of periods) {
      for (const s of shops) {
        const change = r2(valAt(s, p.end) - valAt(s, addDays(p.start, -1)));
        if (Math.abs(change) > 0.004) entry(out, { date: p.end, src: 'Stock', ref: `STK-${p.end}-${s}`, text: 'Change in stock on hand (at cost)', shop: s, lines: [L('1300', change, s), L('5100', -change, s)] });
      }
    }
  }
  // Depreciation (straight line, month by month)
  if (has('fixed_assets')) {
    for (const a of db().all("SELECT * FROM fixed_assets WHERE status <> 'void'")) {
      for (const p of monthEnds(from, to)) {
        const dep = depreciationFor(a, p.start, p.end);
        if (dep > 0.004) entry(out, { date: p.end, src: 'Depreciation', ref: `DEP-${a.uid}-${p.end}`, text: a.name, shop: a.shop_code || OFFICE, lines: [L('6800', dep, a.shop_code), L('1590', -dep, a.shop_code)] });
      }
      // Sold / thrown out: cost and depreciation come off; the money received (cash) and a gain or loss are booked.
      if (a.disposed_date && a.disposed_date >= from && a.disposed_date <= to) {
        const dep = depreciationFor(a, a.purchase_date, a.disposed_date);
        const got = Number(a.disposed_amount) || 0;
        const gain = r2(got - (a.cost - dep));
        entry(out, { date: a.disposed_date, src: 'Asset', ref: `DSP-${a.uid}`, text: `${a.name} sold / disposed`, shop: a.shop_code || OFFICE,
          lines: [L('1590', dep, a.shop_code), L('1500', -a.cost, a.shop_code), L('1000', got, a.shop_code), L(gain >= 0 ? '4900' : '6990', -gain, a.shop_code)] });
      }
      if (!a.purchase_date || a.purchase_date < from || a.purchase_date > to) continue;
      // Assets typed in here (not through an invoice) are booked against opening balances.
      if ((a.notes || '').includes('[not via invoice]')) entry(out, { date: a.purchase_date, src: 'Asset', ref: `AST-${a.uid}`, text: `${a.name} (added)`, shop: a.shop_code || OFFICE, lines: [L('1500', a.cost, a.shop_code), L('3000', -a.cost, a.shop_code)] });
    }
  }
  // Manual journals (Aronium sales for a shop and day that also has a till count are not booked: the till count is)
  let tillDay = null; // only read when there are Aronium sales journals
  for (const j of db().all(`SELECT ${colsOf('gl_journals', ['uid', 'jdate', 'kind', 'meta', 'memo', 'lines'])} FROM gl_journals WHERE status = 'active' AND ${between('jdate')} ORDER BY jdate, rowid`)) {
    if (j.kind === 'aronium_sale' && (tillDay || (tillDay = tillDays())).has(`${J(j.meta, {}).shop}|${j.jdate}`)) continue;
    entry(out, { date: j.jdate, src: JOURNAL_SRC[j.kind] || 'Journal', ref: j.uid, text: j.memo, shop: OFFICE, lines: J(j.lines, []).map((l) => L(l.code, r2(l.debit) - r2(l.credit), l.shop || OFFICE)) });
  }
  return out.sort((a, b) => (a.date === b.date ? (a.src < b.src ? -1 : 1) : a.date < b.date ? -1 : 1));
}
// for tests: the books worked out in one piece (no kept parts)
export function workOutEntriesForTest(r) { return workOutEntries(r); }
export const JOURNAL_SRC = { manual: 'Journal', opening: 'Opening', sale: 'Sale (typed)', expense: 'Expense (typed)', income: 'Income (typed)', owner: 'Owner', transfer: 'Transfer',
  aronium_sale: 'Aronium sales', aronium_expense: 'Aronium expense', tax_payment: 'Tax', repeat: 'Repeating', reverse: 'Reversal', prepay: 'Prepayment', accrual: 'Accrual' };
function monthEnds(from, to) {
  const out = [];
  const start = from < '2000-01-01' ? earliestDate() : from;
  if (!start || start > to) return out;
  let y = Number(start.slice(0, 4));
  let mo = Number(start.slice(5, 7));
  for (let k = 0; k < 600; k += 1) {
    const ms = `${y}-${String(mo).padStart(2, '0')}-01`;
    const me = addDays(mo === 12 ? `${y + 1}-01-01` : `${y}-${String(mo + 1).padStart(2, '0')}-01`, -1);
    if (ms > to) break;
    out.push({ start: ms < start ? start : ms, end: me > to ? to : me });
    mo += 1; if (mo > 12) { mo = 1; y += 1; }
  }
  return out;
}
function earliestDate() {
  const c = [];
  for (const [t, col] of [['till_counts', 'shift_date'], ['ap_invoices', 'invoice_date'], ['inv_moves', 'move_date'], ['fixed_assets', 'purchase_date'], ['gl_journals', 'jdate'], ['cash_moves', 'move_date']]) {
    if (has(t)) { const r = db().get(`SELECT MIN(${col}) AS d FROM ${t}`); if (r && r.d) c.push(r.d); }
  }
  return c.sort()[0] || null;
}
// Stock at cost on a date (current cost), not counting opening stock imports when exOpening (those are booked separately).
export function stockValueAt(shopCode, date, exOpening = false) {
  // Each movement at its own cost, so a later cost change does not change a closed month.
  // 1.0.0 from the stock totals per month (inventory/stockMonths.js): the same figure, without reading every movement.
  return r2(require('../inventory/stockMonths.js').stockValueUpTo(shopCode, date, exOpening));
}
// The same, added up from the movements themselves (the check that the totals per month agree).
export function stockValueAtSlow(shopCode, date, exOpening = false) {
  const r = db().get(`SELECT COALESCE(SUM(m.qty * COALESCE(m.unit_cost, i.cost)),0) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
    WHERE m.shop_code = ? AND m.status = 'active' AND m.move_date <= ? ${exOpening ? "AND m.type <> 'opening'" : ''}`, [shopCode, date]);
  return r2(r.v);
}
export function depreciationFor(a, start, end) {
  const base = Number(a.cost) - Number(a.salvage || 0);
  if (base <= 0 || !(a.life_years > 0)) return 0;
  const perMonth = base / (a.life_years * 12);
  const months = (d) => Number(d.slice(0, 4)) * 12 + Number(d.slice(5, 7));
  const first = months(a.purchase_date);
  const lastAllowed = first + Math.round(a.life_years * 12) - 1;
  const stop = a.disposed_date ? months(a.disposed_date) - 1 : Infinity;
  let total = 0;
  for (let k = months(start); k <= months(end); k += 1) if (k >= first && k <= lastAllowed && k <= stop && monthEndIn(k, end)) total += perMonth;
  return r2(total);
}
const monthEndIn = (k, end) => { const y = Math.floor((k - 1) / 12); const mo = ((k - 1) % 12) + 1; const me = addDays(mo === 12 ? `${y + 1}-01-01` : `${y}-${String(mo + 1).padStart(2, '0')}-01`, -1); return me <= end; };

// ---------------------------------------------------------------- reports data
export function balances({ from = '0000-01-01', to = dateStr(), shop } = {}) {
  const accts = Object.fromEntries(listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const bal = {};
  // A closed year (and still locked) gives the balances up to its end, so only the later entries are worked out.
  const snap = from <= '0000-01-01' ? closedSnapshotBefore(to) : null;
  if (snap) {
    for (const [k, v] of Object.entries(snap.balances)) {
      const [code, sh] = k.split('|');
      if (shop && sh !== shop) continue;
      bal[code] = r2((bal[code] || 0) + v);
    }
    from = addDays(snap.closed_to, 1);
  }
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      if (shop && l.shop !== shop) continue;
      bal[l.code] = r2((bal[l.code] || 0) + l.amount);
    }
  }
  return Object.entries(bal).filter(([, v]) => Math.abs(v) > 0.004).map(([code, v]) => ({ code, name: (accts[code] || {}).name || accountName(code), type: typeOf(code, accts), grp: (accts[code] || {}).grp || 'Bank', balance: v }))
    .sort((a, b) => (a.code < b.code ? -1 : 1));
}
// Shop|day pairs that have a till count (their Aronium sales are only a check).
export function tillDays() {
  // 1.0.0 kept until a till count changes (the books, the VAT return of each month … ask for it). Shared: read only.
  return has('till_counts') ? keepUntilChanged('acc|tillDays', ['till_counts'], () => new Set(db().all("SELECT DISTINCT shop_code || '|' || shift_date AS k FROM till_counts WHERE status <> 'void'").map((r) => r.k))) : new Set();
}
// The newest closed year that ends before `to`, if the books are still locked to its end.
export function closedSnapshotBefore(to) {
  if (!has('gl_year_close')) return null;
  const lock = lockDate();
  const r = db().get('SELECT * FROM gl_year_close WHERE closed_to < ? AND closed_to <= ? ORDER BY closed_to DESC LIMIT 1', [to, lock || '0000-00-00']);
  return r ? { ...r, balances: J(r.balances, {}) } : null;
}
export function trialBalance(asOf = dateStr()) {
  const rows = balances({ to: asOf });
  const dr = r2(rows.filter((r) => r.balance > 0).reduce((s, r) => s + r.balance, 0));
  const cr = r2(-rows.filter((r) => r.balance < 0).reduce((s, r) => s + r.balance, 0));
  return { rows, dr, cr, ok: Math.abs(dr - cr) < 0.01 };
}
// Profit & loss for a period, per shop (columns) and total. The closed shop always has its own column (CLOSED,
// "Closed shop costs"), never part of S1 / S2; the total (whole business) includes it.
export function profitLoss({ from, to, shops }) {
  const accts = Object.fromEntries(listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const cols = (shops || []).filter((c) => c !== OFFICE && c !== CLOSED).concat([CLOSED, OFFICE]);
  const rows = {};
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      const t = typeOf(l.code, accts);
      if (!['income', 'cogs', 'expense'].includes(t)) continue;
      const r = (rows[l.code] = rows[l.code] || { code: l.code, name: (accts[l.code] || {}).name || l.code, type: t, by: {}, total: 0 });
      const col = cols.includes(l.shop) ? l.shop : l.shop === 'S3' ? CLOSED : OFFICE; // the old third shop is the closed shop
      const v = t === 'income' ? -l.amount : l.amount; // show income and costs as positive numbers
      r.by[col] = r2((r.by[col] || 0) + v);
      r.total = r2(r.total + v);
    }
  }
  const list = Object.values(rows).sort((a, b) => (a.code < b.code ? -1 : 1));
  const sum = (type, col) => r2(list.filter((r) => r.type === type).reduce((s, r) => s + (col ? r.by[col] || 0 : r.total), 0));
  const per = Object.fromEntries(cols.concat(['total']).map((c) => {
    const k = c === 'total' ? null : c;
    const income = sum('income', k); const cogs = sum('cogs', k); const exp = sum('expense', k);
    return [c, { income, cogs, gross: r2(income - cogs), expenses: exp, profit: r2(income - cogs - exp), margin: income ? r2(((income - cogs) / income) * 100) : null }];
  }));
  return { rows: list, cols, per };
}
export function balanceSheet(asOf = dateStr()) {
  const yearStart = `${asOf.slice(0, 4)}-01-01`;
  const all = balances({ to: asOf });
  const before = balances({ to: addDays(yearStart, -1) });
  const pick = (rows, types) => rows.filter((r) => types.includes(r.type));
  const earlier = r2(-pick(before, ['income', 'cogs', 'expense']).reduce((s, r) => s + r.balance, 0));
  const thisYear = r2(-pick(all, ['income', 'cogs', 'expense']).reduce((s, r) => s + r.balance, 0) - earlier);
  const assets = pick(all, ['asset']);
  const liabilities = pick(all, ['liability']).map((r) => ({ ...r, balance: -r.balance }));
  const equity = pick(all, ['equity']).map((r) => ({ ...r, balance: -r.balance })).concat([{ code: '3900', name: 'Profit kept from earlier years', balance: earlier }, { code: '—', name: `Profit this year (${asOf.slice(0, 4)})`, balance: thisYear }]);
  const tA = r2(assets.reduce((s, r) => s + r.balance, 0));
  const tL = r2(liabilities.reduce((s, r) => s + r.balance, 0));
  const tE = r2(equity.reduce((s, r) => s + r.balance, 0));
  return { assets, liabilities, equity, totalAssets: tA, totalLiabilities: tL, totalEquity: tE, ok: Math.abs(tA - tL - tE) < 0.02 };
}
export function ledgerFor(code, { from, to, shop } = {}) {
  const opening = r2(balances({ to: addDays(from, -1), shop }).filter((r) => r.code === code).reduce((s, r) => s + r.balance, 0));
  let run = opening;
  const lines = [];
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      if (l.code !== code || (shop && l.shop !== shop)) continue;
      run = r2(run + l.amount);
      lines.push({ date: e.date, src: e.src, text: e.text, shop: l.shop, debit: l.amount > 0 ? l.amount : 0, credit: l.amount < 0 ? -l.amount : 0, balance: run, ref: e.ref });
    }
  }
  return { opening, closing: run, lines };
}

// ---------------------------------------------------------------- VAT return (FRCS, monthly, invoice basis)
// 1.0.0 kept until a till count, End of day, supplier invoice, journal or setting changes (Home, the tax calendar and
// the month report ask for many months at once). The answer is shared: callers only read it.
export const VAT_TABLES = ['till_counts', 'aronium_eods', 'ap_invoices', 'gl_journals', 'shared_settings'];
export function vatReturn({ ym, shop }) {
  return keepUntilChanged(`acc|vat|${ym}|${shop || ''}`, VAT_TABLES, () => workOutVatReturn({ ym, shop }));
}
function workOutVatReturn({ ym, shop }) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const vat = Number(apRules().vatRate) || 12.5;
  const sales = has('till_counts') ? db().all(`SELECT * FROM till_counts WHERE status <> 'void' AND shift_date BETWEEN ? AND ? AND (? IS NULL OR shop_code = ?) ORDER BY shift_date`, [from, to, shop || null, shop || null]) : [];
  const s = { total: 0, zero: 0, standard: 0, output: 0 };
  // v3.5: Aronium End of day gives the VAT split. A till balance matched to an End of day is replaced by Aronium's
  // figure (unless the difference was explained as "the till is right"); an End of day with no till balance still counts.
  const eodRows = has('aronium_eods') ? db().all(`SELECT * FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ? AND (? IS NULL OR shop_code = ?) ORDER BY eod_date`, [from, to, shop || null, shop || null]) : [];
  const covered = new Set();
  const eodDays = new Set();
  const aron = { used: 0, unresolved: 0, missingTill: 0 };
  const eodSales = [];
  for (const e of eodRows) {
    eodDays.add(`${e.shop_code}|${e.eod_date}`);
    if (e.state === 'resolved' && e.use_figure === 'till') continue;
    J(e.count_uids, []).forEach((u) => covered.add(u));
    const total = r2(e.total); const zero = r2(e.zero || 0);
    const out = e.vat !== null && e.vat !== undefined ? r2(e.vat) : r2((total - zero) - (total - zero) / (1 + vat / 100));
    s.total += total; s.zero += zero; s.standard += total - zero; s.output += out;
    aron.used += 1; if (e.state === 'difference') aron.unresolved += 1; if (e.state === 'no_till') aron.missingTill += 1;
    eodSales.push({ date: e.eod_date, shop: e.shop_code, ref: `Aronium End of day ${e.z_number || '(whole day)'}${e.state === 'difference' ? ' – difference not explained' : e.state === 'no_till' ? ' – till balance missing' : ''}`,
      total, zero, vat: out, typed: e.vat !== null && e.vat !== undefined, aronium: true, state: e.state, go: ['AroniumEod', { uid: e.uid }] });
  }
  const saleRows = sales.filter((c) => !covered.has(c.uid)).map((c) => {
    const total = c.z_total !== null && c.z_total !== undefined ? Number(c.z_total) : r2(Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0));
    const zero = Number(c.z_zero_rated) || 0;
    const out = c.z_vat !== null && c.z_vat !== undefined ? Number(c.z_vat) : r2((total - zero) - (total - zero) / (1 + vat / 100));
    s.total += total; s.zero += zero; s.standard += total - zero; s.output += out;
    return { date: c.shift_date, shop: c.shop_code, ref: `${c.till_name || ''} ${c.shift || ''} Z ${c.z_number || ''}`.trim(), total: r2(total), zero: r2(zero), vat: r2(out), typed: c.z_vat !== null && c.z_vat !== undefined, go: ['TillCountView', { uid: c.uid }] };
  }).concat(eodSales).sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  const invs = has('ap_invoices') ? db().all(`SELECT * FROM ap_invoices WHERE status <> 'void' AND total > 0 AND invoice_date BETWEEN ? AND ? AND (? IS NULL OR ifnull(shop_code, ?) = ?) ORDER BY invoice_date`,
    [from, to, shop || null, OFFICE, shop || '']) : [];
  const p = { total: 0, zero: 0, input: 0, noTin: 0 };
  const purchaseRows = invs.map((i) => {
    const sign = i.kind === 'credit' ? -1 : 1;
    p.total += sign * i.total; p.zero += sign * (Number(i.zero_rated) || 0); p.input += sign * (Number(i.vat) || 0);
    if (Number(i.vat) > 0 && !i.supplier_tin) p.noTin += 1;
    return { date: i.invoice_date, shop: i.shop_code || OFFICE, supplier: i.supplier_name, tin: i.supplier_tin || '', no: i.invoice_no || '', kind: i.kind, total: r2(sign * i.total), vat: r2(sign * (Number(i.vat) || 0)), status: i.status, go: ['ApInvoice', { uid: i.uid }] };
  });
  // Sales and costs typed in the accounts or brought in from Aronium (after they were checked).
  const typed = db().all(`SELECT * FROM gl_journals WHERE status = 'active' AND kind IN ('sale','aronium_sale','expense','aronium_expense') AND jdate BETWEEN ? AND ? ORDER BY jdate`, [from, to]);
  const tillDay = tillDays();
  for (const j of typed) {
    const mt = J(j.meta, {});
    if (j.kind === 'aronium_sale' && (tillDay.has(`${mt.shop}|${j.jdate}`) || eodDays.has(`${mt.shop}|${j.jdate}`))) continue;
    if (shop && (mt.shop || OFFICE) !== shop) continue;
    const total = r2(mt.total); const v = r2(mt.vat); const zero = r2(mt.zero);
    if (j.kind === 'sale' || j.kind === 'aronium_sale') {
      s.total += total; s.zero += zero; s.standard += total - zero; s.output += v;
      saleRows.push({ date: j.jdate, shop: mt.shop || OFFICE, ref: j.memo, total, zero, vat: v, typed: true, go: ['AcctEntries', { uid: j.uid }] });
    } else {
      p.total += total; p.zero += zero; p.input += v;
      if (v > 0 && !mt.tin) p.noTin += 1;
      purchaseRows.push({ date: j.jdate, shop: mt.shop || OFFICE, supplier: mt.supplier || j.memo, tin: mt.tin || '', no: mt.no || '', kind: 'invoice', total, vat: v, status: 'checked', go: ['AcctEntries', { uid: j.uid }] });
    }
  }
  const output = r2(s.output);
  const input = r2(p.input);
  return {
    ym, from, to, shop: shop || null,
    sales: { total: r2(s.total), zeroRated: r2(s.zero), standard: r2(s.standard), exVat: r2(s.total - output), output },
    purchases: { total: r2(p.total), zeroRated: r2(p.zero), input, noTin: p.noTin, toCheck: purchaseRows.filter((r) => r.status === 'to_check').length },
    net: r2(output - input), payable: output - input >= 0, saleRows, purchaseRows, aronium: aron,
    due: lastDayOfNextMonth(ym),
  };
}

// FRCS: the monthly VAT return and payment are due by the last day of the following month.
export function lastDayOfNextMonth(ym) {
  const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7));
  const n2 = m + 2 > 12 ? `${y + 1}-${String(m + 2 - 12).padStart(2, '0')}-01` : `${y}-${String(m + 2).padStart(2, '0')}-01`;
  return addDays(n2, -1);
}

// ---------------------------------------------------------------- manual journals
// lines: [{ code, debit, credit, shop }]
// Kinds whose bank lines are real money in or out of the bank (they appear in the bank reconciliation).
const BANK_KINDS = ['sale', 'expense', 'income', 'owner', 'transfer', 'tax_payment'];
export function saveJournal(user, { date, memo, lines, kind = 'manual', meta: info, refUid, uid: fixedUid, bankEntry = true }) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  // A fixed id (repeating journals) is only ever booked once, on any device.
  if (fixedUid && db().get('SELECT 1 AS x FROM gl_journals WHERE uid = ?', [fixedUid])) return fixedUid;
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  assertOpen(d, 'This journal');
  need(txt(memo), 'Say what the journal is for.');
  const valid = new Set(listAccountsGL({ includeInactive: true }).map((a) => a.code));
  const clean = (lines || []).map((l) => ({ code: txt(l.code), debit: r2(l.debit), credit: r2(l.credit), shop: txt(l.shop) || OFFICE })).filter((l) => l.code && (l.debit || l.credit));
  need(clean.length >= 2, 'A journal needs at least two lines.');
  for (const l of clean) { need(valid.has(l.code), `Account ${l.code} does not exist.`); need(!(l.debit && l.credit), 'Each line is either a debit or a credit, not both.'); need(l.debit >= 0 && l.credit >= 0, 'No negative amounts.'); }
  const dr = r2(clean.reduce((s, l) => s + l.debit, 0));
  const cr = r2(clean.reduce((s, l) => s + l.credit, 0));
  need(Math.abs(dr - cr) < 0.005, `Debits (${$(dr)}) and credits (${$(cr)}) must be equal.`);
  const uid = fixedUid || uuid('JN');
  const { now, dev } = meta();
  db().run('INSERT INTO gl_journals (uid, jdate, memo, lines, kind, status, by_name, created_at, updated_at, updated_device, meta, ref_uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    [uid, d, txt(memo), JSON.stringify(clean), kind, 'active', user.name, now, now, dev, info ? JSON.stringify(info) : null, refUid || null]);
  // bankEntry false: paid by a cheque that is in the cheque register instead (it shows in the bank from there).
  if (BANK_KINDS.includes(kind) && bankEntry) {
    clean.filter((l) => isBankCode(l.code)).forEach((l, i) => {
      const inward = l.debit > 0;
      db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [`BE-JN-${uid}${i ? `-${i}` : ''}`, l.code.slice(5), d, inward ? 'deposit' : 'transfer_out', inward ? l.debit : l.credit, (info && info.reference) || null, txt(memo), user.name, now, dev]);
    });
  }
  audit({ user, action: `Journal ${d}: ${txt(memo)} ${$(dr)}`, table: 'gl_journals', recordUid: uid });
  return uid;
  });
}
export function listJournals({ limit = 200 } = {}) {
  return db().all('SELECT * FROM gl_journals ORDER BY jdate DESC, created_at DESC LIMIT ?', [limit]).map((j) => ({ ...j, lines: J(j.lines, []) }));
}
export function voidJournal(user, uid, reason) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const j = db().get('SELECT * FROM gl_journals WHERE uid = ?', [uid]);
  need(j && j.status === 'active', 'Not found.');
  assertOpen(j.jdate, 'This journal');
  needReason(user, reason, 'Say why.');
  const { now, dev } = meta();
  need(!db().get("SELECT 1 AS x FROM bank_entries WHERE uid LIKE ? AND status = 'active' AND cleared_date IS NOT NULL", [`BE-JN-${uid}%`]), 'This is already matched on a bank statement. Un-match it in Bank reconciliation first.');
  db().run(`UPDATE gl_journals SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid LIKE ? AND status = 'active'`, [txt(reason), now, dev, `BE-JN-${uid}%`]);
  audit({ user, action: `Voided journal ${j.memo}`, table: 'gl_journals', recordUid: uid, reason: txt(reason) });
  });
}

// ---------------------------------------------------------------- fixed assets
export function saveAsset(user, a) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(a.name), 'Name the asset, e.g. "Chiller – S1".');
  const d = txt(a.purchaseDate);
  need(DATE.test(d), 'Enter the purchase date.');
  assertOpen(d, 'This asset');
  const cost = r2(a.cost);
  need(cost > 0, 'Enter the cost (excl. VAT).');
  const life = Number(a.lifeYears);
  need(life > 0 && life <= 50, 'Enter how many years it will last (1–50).');
  const uid = a.uid || uuid('FA');
  const { now, dev } = meta();
  const notes = `${txt(a.notes)}${a.viaInvoice === false && !txt(a.notes).includes('[not via invoice]') ? ' [not via invoice]' : ''}`.trim() || null;
  db().run(`INSERT INTO fixed_assets (uid, name, category, shop_code, purchase_date, cost, life_years, salvage, serial, notes, photo_urls, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?, '[]', 'active', ?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, category=excluded.category, shop_code=excluded.shop_code, purchase_date=excluded.purchase_date, cost=excluded.cost, life_years=excluded.life_years,
    salvage=excluded.salvage, serial=excluded.serial, notes=excluded.notes, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, txt(a.name), txt(a.category) || null, txt(a.shopCode) || null, d, cost, life, r2(a.salvage), txt(a.serial) || null, notes, now, dev]);
  audit({ user, action: `Asset ${txt(a.name)} ${$(cost)} over ${life} years`, table: 'fixed_assets', recordUid: uid });
  return uid;
  });
}
export function disposeAsset(user, uid, { date, amount, reason }) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const a = db().get('SELECT * FROM fixed_assets WHERE uid = ?', [uid]);
  need(a && a.status === 'active', 'Not found.');
  need(DATE.test(txt(date)), 'Enter the date it was sold / thrown out.');
  assertOpen(txt(date), 'This disposal');
  needReason(user, reason, 'Say what happened to it.');
  const { now, dev } = meta();
  db().run(`UPDATE fixed_assets SET status = 'disposed', disposed_date = ?, disposed_amount = ?, notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [txt(date), r2(amount), `${a.notes || ''} Disposed: ${txt(reason)}`.trim(), now, dev, uid]);
  audit({ user, action: `Asset ${a.name} disposed`, table: 'fixed_assets', recordUid: uid, reason: txt(reason) });
  });
}
export function listAssets(asOf = dateStr()) {
  return db().all("SELECT * FROM fixed_assets WHERE status <> 'void' ORDER BY purchase_date").map((a) => {
    const dep = depreciationFor(a, a.purchase_date, asOf);
    return { ...a, depreciated: dep, bookValue: r2(a.cost - dep), photos: J(a.photo_urls, []) };
  });
}

// ---------------------------------------------------------------- budgets
export function saveBudget(user, { ym, shopCode, code, amount, allYear }) {
  requirePerm(user, 'accounts_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(/^\d{4}-\d{2}$/.test(txt(ym)), 'Choose the month.');
  need(txt(code), 'Choose the account.');
  const months = allYear ? Array.from({ length: 12 }, (_, i) => `${ym.slice(0, 4)}-${String(i + 1).padStart(2, '0')}`) : [ym];
  const { now, dev } = meta();
  for (const m of months) {
    db().run(`INSERT INTO gl_budgets (uid, ym, shop_code, code, amount, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)
      ON CONFLICT(uid) DO UPDATE SET amount = excluded.amount, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [`${m}|${shopCode || OFFICE}|${code}`, m, shopCode || OFFICE, code, r2(amount), now, dev]);
  }
  audit({ user, action: `Budget ${code} ${shopCode || OFFICE} ${allYear ? `every month of ${ym.slice(0, 4)}` : ym}: ${$(amount)}`, table: 'gl_budgets' });
  });
}
export function budgetVsActual({ ym, shopCode }) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const pl = profitLoss({ from, to, shops: shopCode && shopCode !== OFFICE ? [shopCode] : [] });
  const col = shopCode || null;
  const budgets = db().all('SELECT * FROM gl_budgets WHERE ym = ? AND (? IS NULL OR shop_code = ?)', [ym, col, col]);
  const codes = new Set(pl.rows.map((r) => r.code).concat(budgets.map((b) => b.code)));
  return [...codes].sort().map((code) => {
    const r = pl.rows.find((x) => x.code === code);
    const actual = r ? (col ? r.by[col] || 0 : r.total) : 0;
    const budget = r2(budgets.filter((b) => b.code === code).reduce((s, b) => s + b.amount, 0));
    return { code, name: r ? r.name : accountName(code), type: r ? r.type : 'expense', actual: r2(actual), budget, diff: r2(actual - budget) };
  });
}

// ---------------------------------------------------------------- closing a month
export function setLock(user, date, { reopen = false, reason } = {}) {
  requirePerm(user, 'accounts_close', { money: true }); // closing: owner / admin (accounts_close); moving the lock back is checked below (owner only) // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const cur = lockDate();
  need(DATE.test(txt(date)), 'Choose the last day to close.');
  const back = !!cur && date < cur;
  // Moving the lock back (reopening) is for the owner only; closing needs "Close a month" (or the owner / admin).
  if (back) need(isOwnerUser(user), `The books are closed to ${cur}. Only the owner can reopen a closed month.`);
  else need(isBoss(user) || can(user, 'accounts_close'), 'You are not allowed to close the books. Ask the owner.');
  if (back) need(reopen, `The books are closed to ${cur}. Only the owner can reopen.`);
  setShared('gl_lock', { date, by: user.name, at: stamp() });
  // Reopening a closed year: its kept balances are no longer used (the year must be closed again).
  if (has('gl_year_close') && cur && date < cur) db().run(`UPDATE gl_year_close SET closed_to = '9999-12-31', balances = '{}', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE closed_to > ? AND closed_to <> '9999-12-31'`, [stamp(), deviceId(), date]);
  audit({ user, action: date < (cur || '') ? `Reopened the books after ${date}` : `Closed the books up to ${date}`, table: 'shared_settings', recordUid: 'gl_lock', before: { date: cur }, after: { date }, reason: txt(reason) || null });
  });
}
// Month-end checklist: what still needs doing before the month can be closed. Ticks are saved per month.
export function monthEndChecklist(ym) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const q = (sql, a) => { try { return db().get(sql, a).n; } catch (e) { return 0; } };
  const ticks = getShared(`month_end_${ym}`, {}) || {};
  const auto = [
    { key: 'till', label: 'Every till count approved', left: q("SELECT COUNT(*) AS n FROM till_counts WHERE status IN ('counted','queried') AND shift_date BETWEEN ? AND ?", [from, to]) },
    { key: 'inv', label: 'Every supplier invoice checked', left: q("SELECT COUNT(*) AS n FROM ap_invoices WHERE status = 'to_check' AND invoice_date BETWEEN ? AND ?", [from, to]) },
    { key: 'bank', label: 'Bank reconciled to the month end', left: q("SELECT COUNT(*) AS n FROM bank_accounts a WHERE a.active = 1 AND NOT EXISTS (SELECT 1 FROM bank_statements s WHERE s.account_uid = a.uid AND s.status <> 'void' AND s.to_date >= ?)", [to]) },
    { key: 'pay', label: 'Every pay run final', left: q("SELECT COUNT(*) AS n FROM pay_runs WHERE status = 'draft' AND pay_date BETWEEN ? AND ?", [from, to]) },
    { key: 'cash', label: 'Cash records verified', left: q("SELECT COUNT(*) AS n FROM cash_moves m WHERE m.status = 'active' AND m.type IN ('petty_out','petty_in','adjust_in','adjust_out') AND IFNULL(m.category,'') <> 'cig_fund' AND m.move_date BETWEEN ? AND ? AND NOT EXISTS (SELECT 1 FROM verifications v WHERE v.uid = 'cash_moves:' || m.uid AND v.status = 'verified')", [from, to]) },
    { key: 'suspense', label: 'Suspense account cleared (bank lines coded)', left: closePiece('susp', ym) },
    { key: 'eod', label: "Aronium End of day differences explained (until then the VAT return uses Aronium's figure)", left: q("SELECT COUNT(*) AS n FROM aronium_eods WHERE state = 'difference' AND eod_date BETWEEN ? AND ?", [liveOr(from), to]) },
    { key: 'eodtill', label: 'A till balance for every Aronium End of day', left: q("SELECT COUNT(*) AS n FROM aronium_eods WHERE state = 'no_till' AND eod_date BETWEEN ? AND ?", [liveOr(from), to]) },
    { key: 'shifts', label: 'Every till shift balanced (none left running or continued)', left: q("SELECT COUNT(*) AS n FROM till_shifts WHERE status IN ('open','continued') AND shift_date BETWEEN ? AND ?", [liveOr(from), to]) },
    { key: 'count', label: 'Stock take done this month (each shop with stock)', left: q(`WITH RECURSIVE s(x) AS (SELECT MIN(shop_code) FROM inv_moves UNION ALL SELECT (SELECT MIN(shop_code) FROM inv_moves WHERE shop_code > s.x) FROM s WHERE s.x IS NOT NULL)
      SELECT COUNT(*) AS n FROM s WHERE s.x IS NOT NULL AND NOT EXISTS (SELECT 1 FROM inv_counts c WHERE c.shop_code = s.x AND c.status = 'posted' AND c.count_date BETWEEN ? AND ?)`, [from, to]) }, // 1.0.0 each shop found by the index, not by reading every movement
  ];
  const manual = [
    { key: 'vat', label: 'VAT return checked and filed with FRCS' }, { key: 'fnpf', label: 'FNPF paid and schedule sent' }, { key: 'paye', label: 'PAYE / SRT paid' },
    { key: 'statements', label: 'Main supplier statements checked (balances agree)' }, { key: 'credit', label: 'Staff credit agrees with Aronium' },
    { key: 'drawings', label: 'Owner\'s drawings and personal costs all entered' }, { key: 'review', label: 'Profit & loss looked at by the owner' },
  ].map((m) => ({ ...m, done: !!ticks[m.key], by: ticks[m.key] || null }));
  // v3.9.8 month close: the cash at each shop, each M-PAiSA wallet, each loan and the power / water bills.
  try {
    const shopsS = db().all("SELECT code FROM shops WHERE active = 1 AND code LIKE 'S%'").map((x) => x.code);
    if (has('safe_counts') && shopsS.length) {
      const missing = shopsS.filter((c) => !db().get('SELECT 1 AS x FROM safe_counts WHERE shop_code = ? AND count_date BETWEEN ? AND ?', [c, addDays(to, -2), addDays(to, 3)]));
      auto.push({ key: 'safecount', label: `Cash at each shop counted on the last day (${shopsS.join(', ')})`, left: missing.length, sub: missing.length ? `Not counted: ${missing.join(', ')}` : null, go: 'CashOnHand' });
    }
    if (has('wallets') && has('bank_checks')) {
      const ws = db().all('SELECT uid, name FROM wallets WHERE active = 1');
      const missingW = ws.filter((w) => !db().get("SELECT 1 AS x FROM bank_checks WHERE account_kind = 'wallet' AND account_uid = ? AND check_date BETWEEN ? AND ? AND ABS(diff) < 0.01", [w.uid, addDays(to, -2), addDays(to, 15)]));
      if (ws.length) auto.push({ key: 'wallets', label: 'Each M-PAiSA wallet agrees with its statement at the month end', left: missingW.length, sub: missingW.length ? missingW.map((w) => w.name).join(', ') : null, go: 'Wallets' });
    }
    if (has('ap_recurring') && has('loan_recons')) {
      const loans = db().all("SELECT uid, name FROM ap_recurring WHERE kind = 'loan' AND active = 1");
      const missingL = loans.filter((l) => !db().get("SELECT 1 AS x FROM loan_recons WHERE recurring_uid = ? AND status = 'agreed' AND statement_date BETWEEN ? AND ?", [l.uid, addDays(to, -35), addDays(to, 20)]));
      if (loans.length) auto.push({ key: 'loans', label: 'Each loan agrees with the lender\'s statement', left: missingL.length, sub: missingL.length ? missingL.map((l) => l.name).join(', ') : null, go: 'LoansRent' });
    }
    if (has('utility_checks')) {
      const w = db().get("SELECT COUNT(*) AS n FROM utility_checks WHERE result = 'new_bill' AND invoice_uid IS NULL AND check_date <= ?", [addDays(to, 15)]).n;
      auto.push({ key: 'bills', label: 'Power and water bills acknowledged (made in Invoices)', left: w, go: 'Bills' });
    }
  } catch (e) { /* never stops the list */ }
  try { auto.push(...closePiece('bank', ym)); } catch (e) { /* bank module not ready */ }
  try { auto.push(closePiece('report', ym)); } catch (e) { /* report not ready */ }
  try { auto.push(...closePiece('tax', ym)); } catch (e) { /* tax calendar not ready */ }
  return { ym, from, to, auto: auto.map((a) => ({ ...a, done: !a.left })), manual, ready: auto.every((a) => !a.left) && manual.every((m) => m.done) };
}
// ---------------------------------------------------------------- v3.9.8 month close
// The owner or admin closes a month once everything in it is reconciled; it is then locked (nothing dated in it can
// change unless the owner reopens it with a reason). Each month should be closed by a set day of the next.
export const CLOSE_DEFAULTS = { closeByDay: 15 };
export function closeRules() { return { ...CLOSE_DEFAULTS, ...(getShared('month_close_rules', {}) || {}) }; }
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole) || (() => { try { return require('../../services/access.js').actsAsOwner(u); } catch (e) { return false; } })());
const isOwnerUser = (u) => !!u && (u.role === 'owner' || actsAsOwner(u));
export function closeMonth(user, ym, { reason } = {}) {
  requirePerm(user, 'accounts_close', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(isBoss(user), 'Only the owner or admin can close a month.');
  const c = monthEndChecklist(ym);
  const cur = lockDate();
  need(!cur || cur < c.to, `${ym} is already closed.`);
  const prev = addDays(c.from, -1);
  need(!cur || cur >= prev, 'Close the months before it first.');
  if (!c.ready) need(txt(reason), 'Not everything is reconciled yet. Write why you are closing it anyway.');
  setLock(user, c.to);
  setShared(`month_close_${ym}`, { by: user.name, at: stamp(), ready: c.ready, reason: txt(reason) || null, left: c.auto.filter((a) => !a.done).map((a) => a.label).concat(c.manual.filter((m) => !m.done).map((m) => m.label)) });
  audit({ user, action: `Closed ${ym}${c.ready ? ' (everything reconciled)' : ' – not everything reconciled'}`, table: 'shared_settings', recordUid: `month_close_${ym}`, reason: txt(reason) || null });
  return monthCloseStatus(ym);
  });
}
export function reopenMonth(user, ym, reason) {
  requireOwner(user, 'reopen a month'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(isOwnerUser(user), 'Only the owner can reopen a closed month.');
  need(txt(reason), 'Say why the month is reopened.');
  const from = `${ym}-01`;
  setLock(user, addDays(from, -1), { reopen: true, reason });
  setShared(`month_close_${ym}`, { ...(getShared(`month_close_${ym}`, {}) || {}), reopenedBy: user.name, reopenedAt: stamp(), reopenReason: txt(reason) });
  audit({ user, action: `Reopened ${ym}`, table: 'shared_settings', recordUid: `month_close_${ym}`, reason: txt(reason) });
  });
}
export function monthCloseStatus(ym) {
  const c = monthEndChecklist(ym);
  const lock = lockDate();
  const items = c.auto.concat(c.manual);
  const done = items.filter((x) => x.done).length;
  return { ym, closed: !!lock && lock >= c.to, done, total: items.length, ready: c.ready, info: getShared(`month_close_${ym}`, null) };
}
// The year: twelve months, each closed or not, with its sales, costs and profit.
export function closeYear(year) {
  const out = [];
  for (let m = 1; m <= 12; m += 1) {
    const ym = `${year}-${String(m).padStart(2, '0')}`;
    const st = monthCloseStatus(ym);
    let sales = 0; let costs = 0;
    try {
      const pl = profitLoss({ from: `${ym}-01`, to: monthEndChecklist(ym).to, shops: [] });
      for (const r of pl.rows || []) { if (r.type === 'income') sales = r2(sales + r.total); else costs = r2(costs + r.total); }
    } catch (e) { /* no books yet */ }
    out.push({ ...st, sales, costs, profit: r2(sales - costs) });
  }
  return out;
}
// Home: the last month to close (from the 1st), louder after the close-by day.
// round 2: the slow pieces of the month-end checklist, each kept until what it read changes (at most 5 minutes);
// Home's background collection works them out ahead, one part each (warmClose). Shared: read only.
const CLOSE_PIECES = {
  susp: (ym) => { const to = monthEndOf(ym); return Math.abs(balances({ to }).filter((r) => r.code === '2900').reduce((s, r) => s + r.balance, 0)) > 0.004 ? 1 : 0; },
  bank: (ym) => require('../bank/monthEnd.js').bankMonthEndItems(ym),
  report: (ym) => require('./monthReport.js').monthReportItem(ym),
  tax: (ym) => require('../payroll/taxCalendar.js').taxMonthEndItems(ym),
};
const monthEndOf = (ym) => addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
function closePiece(name, ym) { return keepTracked(`acc|close|${name}|${ym}|${dateStr()}`, () => CLOSE_PIECES[name](ym), { maxAgeMs: 5 * 60000 }); }
const prevYm = (today) => { const d = new Date(`${today}T12:00:00`); d.setDate(1); d.setMonth(d.getMonth() - 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
export const CLOSE_PIECE_NAMES = Object.keys(CLOSE_PIECES);
export function warmClose(name, user, today = dateStr()) {
  if (!isBoss(user)) return [];
  try { closePiece(name, prevYm(today)); } catch (e) { /* the checklist says so */ }
  return [];
}
export function closeAlerts(user, today = dateStr()) {
  if (!isBoss(user)) return [];
  const d = new Date(`${today}T12:00:00`); d.setDate(1); d.setMonth(d.getMonth() - 1);
  const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  try { const g = require('../../services/goLive.js').freshFrom(); if (g && `${ym}-31` < g) return []; } catch (e) { /* no go-live date */ }
  const st = monthCloseStatus(ym);
  if (st.closed) return [];
  const late = Number(today.slice(8, 10)) > closeRules().closeByDay;
  return [{ id: `close-${ym}-${st.done}-${late ? 'late' : ''}`, level: late ? 'urgent' : 'info', text: `${ym} month close: ${st.done} of ${st.total} done${late ? ` – it was due by the ${closeRules().closeByDay}th` : ''}`, sub: 'Reconcile and close the month (Accounts › Month close).', nav: { screen: 'MonthEnd', params: { ym } } }];
}
export function tickMonthEnd(user, ym, key, on) {
  requirePerm(user, 'accounts_close', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const t = getShared(`month_end_${ym}`, {}) || {};
  if (on) t[key] = `${user.name} ${stamp().slice(0, 10)}`; else delete t[key];
  setShared(`month_end_${ym}`, t);
  });
}
