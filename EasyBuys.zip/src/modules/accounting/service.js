// Accounting & VAT. Double-entry books worked out from what is already recorded in the other modules:
//   sales and VAT from the till counts (Z reports), supplier invoices and payments, deposits, petty cash and cash moved,
//   bank fees / interest / other bank lines, payroll (wages, FNPF, PAYE), staff advances and charges, stock on hand,
//   fixed assets (depreciation) and manual journals.
// Nothing is typed twice and the books always agree with the modules. Each line carries the shop it belongs to
// (or "Office" when it is not for one shop), so there is a profit & loss and a VAT return per shop.
// Financial year: January – December.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { lockDate, assertOpen } from '../../services/lock.js';
import { apRules } from '../payables/service.js';
import { payRules } from '../payroll/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const DATE = /^\d{4}-\d{2}-\d{2}$/;
export const OFFICE = 'OFFICE';

// ---------------------------------------------------------------- chart of accounts
export const TYPES = { asset: 'Asset (what we own)', liability: 'Liability (what we owe)', equity: 'Owner\'s equity', income: 'Income', cogs: 'Cost of goods sold', expense: 'Expense' };
export const DEFAULT_ACCOUNTS = [
  ['1000', 'Cash at the shops (safe / office)', 'asset', 'Cash'], ['1010', 'Till floats', 'asset', 'Cash'],
  ['1110', 'Card, M-PAiSA, MyCash & cheques to be banked', 'asset', 'Receivables'], ['1200', 'Customers owing (on account)', 'asset', 'Receivables'],
  ['1250', 'Staff advances, loans & charges', 'asset', 'Receivables'], ['1300', 'Stock on hand', 'asset', 'Stock'],
  ['1500', 'Equipment, fittings & vehicles (cost)', 'asset', 'Fixed assets'], ['1590', 'Less: depreciation to date', 'asset', 'Fixed assets'],
  ['2000', 'Suppliers owed', 'liability', 'Payables'], ['2100', 'FNPF to pay', 'liability', 'Payroll'], ['2110', 'PAYE / SRT to pay', 'liability', 'Payroll'],
  ['2190', 'Other pay deductions to pay', 'liability', 'Payroll'], ['2200', 'VAT (output less input)', 'liability', 'Tax'], ['2500', 'Loans', 'liability', 'Loans'],
  ['2900', 'Suspense – to be sorted out', 'liability', 'Suspense'],
  ['3000', 'Owner\'s capital & opening balances', 'equity', 'Equity'], ['3100', 'Owner\'s money in / drawings', 'equity', 'Equity'], ['3900', 'Profit kept from earlier years', 'equity', 'Equity'],
  ['4000', 'Sales', 'income', 'Sales'], ['4900', 'Interest & other income', 'income', 'Other income'],
  ['5000', 'Purchases – stock for resale', 'cogs', 'Cost of sales'], ['5010', 'Purchases – bakery ingredients', 'cogs', 'Cost of sales'], ['5100', 'Change in stock on hand', 'cogs', 'Cost of sales'],
  ['5200', 'Packaging', 'cogs', 'Cost of sales'],
  ['6000', 'Rent', 'expense', 'Premises'], ['6010', 'Power & water', 'expense', 'Premises'], ['6020', 'Phone & internet', 'expense', 'Office'], ['6030', 'Repairs & maintenance', 'expense', 'Premises'],
  ['6040', 'Transport & fuel', 'expense', 'Transport'], ['6050', 'Cleaning', 'expense', 'Premises'], ['6060', 'Office & stationery', 'expense', 'Office'],
  ['6100', 'Wages', 'expense', 'Staff'], ['6110', 'FNPF – employer share', 'expense', 'Staff'], ['6500', 'Petty cash & general', 'expense', 'Other'],
  ['6600', 'Bank fees', 'expense', 'Finance'], ['6700', 'Interest paid', 'expense', 'Finance'], ['6800', 'Depreciation', 'expense', 'Other'],
  ['6900', 'Cash short / over & corrections', 'expense', 'Other'], ['6990', 'Other expenses', 'expense', 'Other'],
];
export function ensureAccounts() {
  const n = db().get('SELECT COUNT(*) AS n FROM gl_accounts').n;
  if (n) return;
  const { now, dev } = meta();
  for (const [code, name, type, grp] of DEFAULT_ACCOUNTS) {
    db().run('INSERT OR IGNORE INTO gl_accounts (code, name, type, grp, system, updated_at, updated_device) VALUES (?,?,?,?,1,?,?)', [code, name, type, grp, now, dev]);
  }
}
export function listAccountsGL({ includeInactive = false } = {}) {
  ensureAccounts();
  const rows = db().all(`SELECT * FROM gl_accounts ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY code`);
  // Each bank account is its own account (1100:<bank uid>).
  const banks = has('bank_accounts') ? db().all('SELECT uid, name, active FROM bank_accounts ORDER BY name') : [];
  return rows.concat(banks.filter((b) => includeInactive || b.active).map((b) => ({ code: `1100:${b.uid}`, name: `Bank – ${b.name}`, type: 'asset', grp: 'Bank', system: 1, active: b.active })))
    .sort((a, b) => (a.code < b.code ? -1 : 1));
}
export function accountName(code) {
  const a = listAccountsGL({ includeInactive: true }).find((x) => x.code === code);
  return a ? a.name : code;
}
export function saveAccountGL(user, { code, name, type, grp, active = true, note }) {
  ensureAccounts();
  const c = txt(code);
  need(/^\d{3,6}$/.test(c), 'The account code is 3 to 6 digits, e.g. 6070.');
  need(txt(name), 'Enter the account name.');
  need(TYPES[type], 'Choose the type.');
  const before = db().get('SELECT * FROM gl_accounts WHERE code = ?', [c]);
  if (before && before.system) need(before.type === type, 'The type of a built-in account cannot be changed.');
  const { now, dev } = meta();
  db().run(`INSERT INTO gl_accounts (code, name, type, grp, active, system, note, updated_at, updated_device) VALUES (?,?,?,?,?,0,?,?,?)
    ON CONFLICT(code) DO UPDATE SET name = excluded.name, type = excluded.type, grp = excluded.grp, active = excluded.active, note = excluded.note,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`, [c, txt(name), type, txt(grp) || null, active ? 1 : 0, txt(note) || null, now, dev]);
  audit({ user, action: `${before ? 'Changed' : 'Added'} account ${c} ${txt(name)}`, table: 'gl_accounts', recordUid: c });
}
const typeOf = (code, accts) => (String(code).startsWith('1100:') ? 'asset' : (accts[code] || {}).type || 'expense');

// ---------------------------------------------------------------- which account things go to (admin can change)
export const MAP_DEFAULTS = {
  ap: { 'Stock for resale': '5000', 'Bakery ingredients': '5010', Liquor: '5000', Rent: '6000', 'Power & water': '6010', 'Phone & internet': '6020', Repairs: '6030', 'Transport & fuel': '6040',
    Packaging: '5200', Cleaning: '6050', Office: '6060', Equipment: '1500', 'Loan repayment': '2500', Other: '6990' },
  petty: { Cleaning: '6050', Office: '6060', Transport: '6040', 'Food & tea': '6500', Repairs: '6030', Other: '6500' },
  tenders: { 'On account (credit sales)': '1200', default: '1110' },
  payouts: { 'Supplier paid from till': '5000', Refund: '4000', 'Staff advance': '1250', 'Petty cash': '6500', Other: '6990' },
};
export function glMap() {
  const s = getShared('gl_map', {}) || {};
  return { ap: { ...MAP_DEFAULTS.ap, ...(s.ap || {}) }, petty: { ...MAP_DEFAULTS.petty, ...(s.petty || {}) }, tenders: { ...MAP_DEFAULTS.tenders, ...(s.tenders || {}) }, payouts: { ...MAP_DEFAULTS.payouts, ...(s.payouts || {}) } };
}
export function saveGlMap(user, m) {
  const before = glMap();
  setShared('gl_map', m);
  audit({ user, action: 'Changed which accounts things are booked to', table: 'shared_settings', recordUid: 'gl_map', before, after: m });
}
const mapAp = (cat, m) => m.ap[cat] || m.ap.Other || '6990';

// ---------------------------------------------------------------- the entries
// Each entry: { date, src, ref, text, shop, lines: [{ code, amount }] } – amount > 0 is a debit, < 0 a credit. Lines always add to 0.
const L = (code, amount, shop) => ({ code, amount: r2(amount), shop });
function entry(out, e) {
  const lines = e.lines.filter((l) => Math.abs(l.amount) > 0.0049);
  if (!lines.length) return;
  const off = r2(lines.reduce((s, l) => s + l.amount, 0));
  if (Math.abs(off) > 0.009) lines.push(L('2900', -off, e.shop)); // never lose a cent: anything that does not balance goes to suspense
  out.push({ ...e, lines: lines.map((l) => ({ ...l, shop: l.shop || e.shop || OFFICE })) });
}
const bankCode = (uid) => `1100:${uid}`;

export function entries({ from = '0000-01-01', to = dateStr() } = {}) {
  const m = glMap();
  const vat = Number(apRules().vatRate) || 12.5;
  const out = [];
  const between = (col) => `${col} BETWEEN '${from}' AND '${to}'`;
  // Sales (till counts with their Z report)
  if (has('till_counts')) {
    for (const c of db().all(`SELECT * FROM till_counts WHERE status <> 'void' AND ${between('shift_date')}`)) {
      const s = c.shop_code;
      const total = Number(c.z_total);
      const zTotal = Number.isFinite(total) && c.z_total !== null ? total : r2(Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0));
      const zero = Number(c.z_zero_rated) || 0;
      const outVat = c.z_vat !== null && c.z_vat !== undefined ? Number(c.z_vat) : r2((zTotal - zero) - (zTotal - zero) / (1 + vat / 100));
      const toSafe = r2(Number(c.cash_counted) - Number(c.float_kept) + Number(c.drops || 0));
      const lines = [L('1000', toSafe, s), L('1010', Number(c.float_kept) - Number(c.opening_float), s)];
      J(c.tenders, []).forEach((t) => lines.push(L(m.tenders[t.method] || m.tenders.default, t.amount, s)));
      J(c.payouts, []).forEach((p) => lines.push(L(m.payouts[p.what] || m.payouts.Other, p.amount, s)));
      lines.push(L('4000', -(zTotal - outVat), s), L('2200', -outVat, s));
      const off = r2(lines.reduce((t, l) => t + l.amount, 0));
      lines.push(L('6900', -off, s)); // cash short (debit) / over (credit) and hand corrections
      entry(out, { date: c.shift_date, src: 'Till', ref: c.uid, text: `${c.till_name || 'Till'} ${c.shift || ''} Z ${c.z_number || ''}`.trim(), shop: s, lines });
    }
  }
  // Cash at the shops (not from tills, not deposits – those are booked with the till count and the deposit)
  if (has('cash_moves')) {
    const debtUids = has('staff_debts') ? new Set(db().all('SELECT uid FROM staff_debts').map((r) => r.uid)) : new Set();
    for (const x of db().all(`SELECT * FROM cash_moves WHERE status = 'active' AND type NOT IN ('from_till','deposit') AND ${between('move_date')}`)) {
      if (x.ref_uid && debtUids.has(x.ref_uid)) continue; // advances and loans are booked with the staff debt below
      const s = x.shop_code;
      const a = Number(x.amount);
      const other = { opening: '3000', petty_out: m.petty[x.category] || m.petty.Other || '6500', petty_in: '3100', transfer_in: '1000', transfer_out: '1000', adjust_in: '6900', adjust_out: '6900' }[x.type] || '2900';
      const sign = ['opening', 'petty_in', 'transfer_in', 'adjust_in'].includes(x.type) ? 1 : -1;
      if (x.type === 'transfer_in' || x.type === 'transfer_out') { entry(out, { date: x.move_date, src: 'Cash', ref: x.uid, text: `Cash ${x.type === 'transfer_in' ? 'in from' : 'out to'} another shop`, shop: s, lines: [L('1000', sign * a, s), L('2900', -sign * a, OFFICE)] }); continue; }
      entry(out, { date: x.move_date, src: 'Cash', ref: x.uid, text: `${x.type.replace('_', ' ')}${x.category ? ` · ${x.category}` : ''}${x.note ? ` · ${x.note}` : ''}`, shop: s, lines: [L('1000', sign * a, s), L(other, -sign * a, s)] });
    }
    // The two halves of a cash transfer share a ref: their suspense lines cancel out.
  }
  // Deposits: cash and cheques from a shop into the bank
  if (has('deposits')) {
    for (const d of db().all(`SELECT * FROM deposits WHERE status = 'active' AND ${between('deposit_date')}`)) {
      entry(out, { date: d.deposit_date, src: 'Deposit', ref: d.uid, text: `Deposit slip ${d.slip_no || ''}`, shop: d.shop_code,
        lines: [L(bankCode(d.account_uid), d.total, OFFICE), L('1000', -Number(d.cash_amount), d.shop_code), L('1110', -Number(d.cheque_amount), d.shop_code)] });
    }
  }
  // Supplier invoices and credit notes (invoice basis)
  if (has('ap_invoices')) {
    for (const i of db().all(`SELECT * FROM ap_invoices WHERE status <> 'void' AND total > 0 AND ${between('invoice_date')}`)) {
      const sign = i.kind === 'credit' ? -1 : 1;
      const s = i.shop_code || OFFICE;
      const v = Number(i.vat) || 0;
      entry(out, { date: i.invoice_date, src: i.kind === 'credit' ? 'Credit note' : 'Invoice', ref: i.uid, text: `${i.supplier_name} ${i.invoice_no || ''}`.trim(), shop: s,
        lines: [L(mapAp(i.category, m), sign * (i.total - v), s), L('2200', sign * v, s), L('2000', -sign * i.total, OFFICE)] });
    }
  }
  // Payments to suppliers
  if (has('ap_payments')) {
    for (const p of db().all(`SELECT * FROM ap_payments WHERE status = 'active' AND method IN ('cheque','cash','transfer') AND ${between('pay_date')}`)) {
      const from = p.method === 'cash' ? L('1000', -p.amount, p.shop_code) : L(bankCode(p.account_uid), -p.amount, OFFICE);
      entry(out, { date: p.pay_date, src: 'Payment', ref: p.uid, text: `${p.supplier_name} by ${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}`, shop: p.shop_code || OFFICE, lines: [L('2000', p.amount, OFFICE), from] });
    }
  }
  // Bank lines not already booked by a deposit, payment, wages or tax payment
  if (has('bank_entries')) {
    const skip = new Set(db().all('SELECT bank_entry_uid AS u FROM deposits WHERE bank_entry_uid IS NOT NULL').map((r) => r.u));
    for (const e of db().all(`SELECT * FROM bank_entries WHERE status = 'active' AND payment_uid IS NULL AND ${between('entry_date')}`)) {
      if (skip.has(e.uid) || e.uid.startsWith('BE-WAGES-') || e.uid.startsWith('BE-STAT-')) continue;
      const inward = ['deposit', 'interest', 'adjust_in'].includes(e.type);
      const def = { deposit: '1110', interest: '4900', fee: '6600', adjust_in: '2900', adjust_out: '2900', transfer_out: '2900' }[e.type] || '2900';
      const splits = J(e.split, []);
      const lines = [L(bankCode(e.account_uid), inward ? e.amount : -e.amount, OFFICE)];
      if (splits.length) splits.forEach((x) => lines.push(L(x.code, inward ? -r2(x.amount) : r2(x.amount), x.shop || OFFICE)));
      else lines.push(L(e.gl_code || def, inward ? -e.amount : e.amount, OFFICE));
      entry(out, { date: e.entry_date, src: 'Bank', ref: e.uid, text: [e.reference, e.note].filter(Boolean).join(' · ') || e.type, shop: OFFICE, lines });
    }
  }
  // Payroll (final pay runs)
  if (has('pay_runs')) {
    const wagesShop = payRules().wagesDefaultShop || OFFICE;
    for (const r of db().all(`SELECT * FROM pay_runs WHERE status = 'final' AND ${between('pay_date')}`)) {
      const lines = [];
      for (const l of db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1', [r.uid])) {
        const s = l.shop_code || (l.pay_method !== 'bank' ? wagesShop : OFFICE);
        lines.push(L('6100', l.gross, s), L('6110', l.fnpf_employer, s), L('2100', -(Number(l.fnpf_employee) + Number(l.fnpf_employer)), OFFICE), L('2110', -l.paye, OFFICE));
        J(l.deductions, []).forEach((d) => lines.push(L(d.debtUid ? '1250' : '2190', -d.amount, OFFICE)));
        if (l.pay_method !== 'bank') lines.push(L('1000', -l.net, s));
        else lines.push(L('2900', -l.net, OFFICE)); // bank wages: cleared by the wages bank line below
      }
      const bankWages = has('bank_entries') ? db().get("SELECT * FROM bank_entries WHERE uid = ? AND status = 'active'", [`BE-WAGES-${r.uid}`]) : null;
      if (bankWages) lines.push(L('2900', bankWages.amount, OFFICE), L(bankCode(bankWages.account_uid), -bankWages.amount, OFFICE));
      entry(out, { date: r.pay_date, src: 'Payroll', ref: r.uid, text: `Wages week ${r.week_start}`, shop: OFFICE, lines });
    }
  }
  // Advances and loans paid to staff; charges (shortages) put on staff
  if (has('staff_debts')) {
    for (const d of db().all(`SELECT * FROM staff_debts WHERE status = 'active' AND ${between('debt_date')}`)) {
      const fromCash = !d.paid_from || String(d.paid_from).startsWith('cash');
      entry(out, { date: d.debt_date, src: 'Staff', ref: d.uid, text: `${d.kind} to ${d.name}`, shop: d.shop_code || OFFICE, lines: [L('1250', d.amount, OFFICE), fromCash ? L('1000', -d.amount, d.shop_code || OFFICE) : L('2900', -d.amount, OFFICE)] });
    }
  }
  if (has('staff_charges')) {
    for (const c of db().all(`SELECT * FROM staff_charges WHERE status = 'active' AND ${between('charge_date')}`)) {
      entry(out, { date: c.charge_date, src: 'Staff', ref: c.uid, text: `Charge to ${c.name}: ${c.reason || c.source}`, shop: c.shop_code || OFFICE, lines: [L('1250', c.amount, OFFICE), L('6900', -c.amount, c.shop_code || OFFICE)] });
    }
  }
  // FNPF / PAYE paid
  if (has('stat_payments')) {
    for (const s of db().all(`SELECT * FROM stat_payments WHERE status = 'active' AND paid_date IS NOT NULL AND ${between('paid_date')}`)) {
      entry(out, { date: s.paid_date, src: 'Tax', ref: s.uid, text: `${s.kind === 'fnpf' ? 'FNPF' : 'PAYE / SRT'} for ${s.period} paid`, shop: OFFICE,
        lines: [L(s.kind === 'fnpf' ? '2100' : '2110', s.paid_amount, OFFICE), s.account_uid ? L(bankCode(s.account_uid), -s.paid_amount, OFFICE) : L('1000', -s.paid_amount, OFFICE)] });
    }
  }
  // Stock: opening stock into the books, then the change in stock on hand at cost each month end (and at `to`)
  if (has('inv_moves')) {
    for (const o of db().all(`SELECT m.move_date AS d, m.shop_code AS s, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
      WHERE m.status = 'active' AND m.type = 'opening' AND ${between('m.move_date')} GROUP BY m.move_date, m.shop_code`)) {
      entry(out, { date: o.d, src: 'Stock', ref: `OPEN-${o.d}-${o.s}`, text: 'Opening stock (import)', shop: o.s, lines: [L('1300', o.v, o.s), L('3000', -o.v, o.s)] });
    }
    for (const p of monthEnds(from, to)) {
      const shops = db().all('SELECT DISTINCT shop_code AS s FROM inv_moves').map((r) => r.s);
      for (const s of shops) {
        const change = r2(stockValueAt(s, p.end, true) - stockValueAt(s, addDays(p.start, -1), true));
        if (Math.abs(change) > 0.004) entry(out, { date: p.end, src: 'Stock', ref: `STK-${p.end}-${s}`, text: 'Change in stock on hand (at cost)', shop: s, lines: [L('1300', change, s), L('5100', -change, s)] });
      }
    }
  }
  // Depreciation (straight line, month by month)
  if (has('fixed_assets')) {
    for (const a of db().all("SELECT * FROM fixed_assets WHERE status <> 'void'")) {
      for (const p of monthEnds(from, to)) {
        const dep = depreciationFor(a, p.start, p.end);
        if (dep > 0.004) entry(out, { date: p.end, src: 'Depreciation', ref: `DEP-${a.uid}-${p.end}`, text: a.name, shop: a.shop_code || OFFICE, lines: [L('6800', dep, a.shop_code), L('1590', -dep, a.shop_code)] });
      }
      // Sold / thrown out: cost and depreciation come off; the money received (cash) and a gain or loss are booked.
      if (a.disposed_date && a.disposed_date >= from && a.disposed_date <= to) {
        const dep = depreciationFor(a, a.purchase_date, a.disposed_date);
        const got = Number(a.disposed_amount) || 0;
        const gain = r2(got - (a.cost - dep));
        entry(out, { date: a.disposed_date, src: 'Asset', ref: `DSP-${a.uid}`, text: `${a.name} sold / disposed`, shop: a.shop_code || OFFICE,
          lines: [L('1590', dep, a.shop_code), L('1500', -a.cost, a.shop_code), L('1000', got, a.shop_code), L(gain >= 0 ? '4900' : '6990', -gain, a.shop_code)] });
      }
      if (!a.purchase_date || a.purchase_date < from || a.purchase_date > to) continue;
      // Assets typed in here (not through an invoice) are booked against opening balances.
      if ((a.notes || '').includes('[not via invoice]')) entry(out, { date: a.purchase_date, src: 'Asset', ref: `AST-${a.uid}`, text: `${a.name} (added)`, shop: a.shop_code || OFFICE, lines: [L('1500', a.cost, a.shop_code), L('3000', -a.cost, a.shop_code)] });
    }
  }
  // Manual journals
  for (const j of db().all(`SELECT * FROM gl_journals WHERE status = 'active' AND ${between('jdate')}`)) {
    entry(out, { date: j.jdate, src: 'Journal', ref: j.uid, text: j.memo, shop: OFFICE, lines: J(j.lines, []).map((l) => L(l.code, r2(l.debit) - r2(l.credit), l.shop || OFFICE)) });
  }
  return out.sort((a, b) => (a.date === b.date ? (a.src < b.src ? -1 : 1) : a.date < b.date ? -1 : 1));
}
function monthEnds(from, to) {
  const out = [];
  const start = from < '2000-01-01' ? earliestDate() : from;
  if (!start || start > to) return out;
  let y = Number(start.slice(0, 4));
  let mo = Number(start.slice(5, 7));
  for (let k = 0; k < 600; k += 1) {
    const ms = `${y}-${String(mo).padStart(2, '0')}-01`;
    const me = addDays(mo === 12 ? `${y + 1}-01-01` : `${y}-${String(mo + 1).padStart(2, '0')}-01`, -1);
    if (ms > to) break;
    out.push({ start: ms < start ? start : ms, end: me > to ? to : me });
    mo += 1; if (mo > 12) { mo = 1; y += 1; }
  }
  return out;
}
function earliestDate() {
  const c = [];
  for (const [t, col] of [['till_counts', 'shift_date'], ['ap_invoices', 'invoice_date'], ['inv_moves', 'move_date'], ['fixed_assets', 'purchase_date'], ['gl_journals', 'jdate'], ['cash_moves', 'move_date']]) {
    if (has(t)) { const r = db().get(`SELECT MIN(${col}) AS d FROM ${t}`); if (r && r.d) c.push(r.d); }
  }
  return c.sort()[0] || null;
}
// Stock at cost on a date (current cost), not counting opening stock imports when exOpening (those are booked separately).
export function stockValueAt(shopCode, date, exOpening = false) {
  // Each movement at its own cost, so a later cost change does not change a closed month.
  const r = db().get(`SELECT COALESCE(SUM(m.qty * COALESCE(m.unit_cost, i.cost)),0) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
    WHERE m.shop_code = ? AND m.status = 'active' AND m.move_date <= ? ${exOpening ? "AND m.type <> 'opening'" : ''}`, [shopCode, date]);
  return r2(r.v);
}
export function depreciationFor(a, start, end) {
  const base = Number(a.cost) - Number(a.salvage || 0);
  if (base <= 0 || !(a.life_years > 0)) return 0;
  const perMonth = base / (a.life_years * 12);
  const months = (d) => Number(d.slice(0, 4)) * 12 + Number(d.slice(5, 7));
  const first = months(a.purchase_date);
  const lastAllowed = first + Math.round(a.life_years * 12) - 1;
  const stop = a.disposed_date ? months(a.disposed_date) - 1 : Infinity;
  let total = 0;
  for (let k = months(start); k <= months(end); k += 1) if (k >= first && k <= lastAllowed && k <= stop && monthEndIn(k, end)) total += perMonth;
  return r2(total);
}
const monthEndIn = (k, end) => { const y = Math.floor((k - 1) / 12); const mo = ((k - 1) % 12) + 1; const me = addDays(mo === 12 ? `${y + 1}-01-01` : `${y}-${String(mo + 1).padStart(2, '0')}-01`, -1); return me <= end; };

// ---------------------------------------------------------------- reports data
export function balances({ from = '0000-01-01', to = dateStr(), shop } = {}) {
  const accts = Object.fromEntries(listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const bal = {};
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      if (shop && l.shop !== shop) continue;
      bal[l.code] = r2((bal[l.code] || 0) + l.amount);
    }
  }
  return Object.entries(bal).filter(([, v]) => Math.abs(v) > 0.004).map(([code, v]) => ({ code, name: (accts[code] || {}).name || accountName(code), type: typeOf(code, accts), grp: (accts[code] || {}).grp || 'Bank', balance: v }))
    .sort((a, b) => (a.code < b.code ? -1 : 1));
}
export function trialBalance(asOf = dateStr()) {
  const rows = balances({ to: asOf });
  const dr = r2(rows.filter((r) => r.balance > 0).reduce((s, r) => s + r.balance, 0));
  const cr = r2(-rows.filter((r) => r.balance < 0).reduce((s, r) => s + r.balance, 0));
  return { rows, dr, cr, ok: Math.abs(dr - cr) < 0.01 };
}
// Profit & loss for a period, per shop (columns) and total.
export function profitLoss({ from, to, shops }) {
  const accts = Object.fromEntries(listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const cols = (shops || []).concat([OFFICE]);
  const rows = {};
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      const t = typeOf(l.code, accts);
      if (!['income', 'cogs', 'expense'].includes(t)) continue;
      const r = (rows[l.code] = rows[l.code] || { code: l.code, name: (accts[l.code] || {}).name || l.code, type: t, by: {}, total: 0 });
      const col = cols.includes(l.shop) ? l.shop : OFFICE;
      const v = t === 'income' ? -l.amount : l.amount; // show income and costs as positive numbers
      r.by[col] = r2((r.by[col] || 0) + v);
      r.total = r2(r.total + v);
    }
  }
  const list = Object.values(rows).sort((a, b) => (a.code < b.code ? -1 : 1));
  const sum = (type, col) => r2(list.filter((r) => r.type === type).reduce((s, r) => s + (col ? r.by[col] || 0 : r.total), 0));
  const per = Object.fromEntries(cols.concat(['total']).map((c) => {
    const k = c === 'total' ? null : c;
    const income = sum('income', k); const cogs = sum('cogs', k); const exp = sum('expense', k);
    return [c, { income, cogs, gross: r2(income - cogs), expenses: exp, profit: r2(income - cogs - exp), margin: income ? r2(((income - cogs) / income) * 100) : null }];
  }));
  return { rows: list, cols, per };
}
export function balanceSheet(asOf = dateStr()) {
  const yearStart = `${asOf.slice(0, 4)}-01-01`;
  const all = balances({ to: asOf });
  const before = balances({ to: addDays(yearStart, -1) });
  const pick = (rows, types) => rows.filter((r) => types.includes(r.type));
  const earlier = r2(-pick(before, ['income', 'cogs', 'expense']).reduce((s, r) => s + r.balance, 0));
  const thisYear = r2(-pick(all, ['income', 'cogs', 'expense']).reduce((s, r) => s + r.balance, 0) - earlier);
  const assets = pick(all, ['asset']);
  const liabilities = pick(all, ['liability']).map((r) => ({ ...r, balance: -r.balance }));
  const equity = pick(all, ['equity']).map((r) => ({ ...r, balance: -r.balance })).concat([{ code: '3900', name: 'Profit kept from earlier years', balance: earlier }, { code: '—', name: `Profit this year (${asOf.slice(0, 4)})`, balance: thisYear }]);
  const tA = r2(assets.reduce((s, r) => s + r.balance, 0));
  const tL = r2(liabilities.reduce((s, r) => s + r.balance, 0));
  const tE = r2(equity.reduce((s, r) => s + r.balance, 0));
  return { assets, liabilities, equity, totalAssets: tA, totalLiabilities: tL, totalEquity: tE, ok: Math.abs(tA - tL - tE) < 0.02 };
}
export function ledgerFor(code, { from, to, shop } = {}) {
  const opening = r2(balances({ to: addDays(from, -1), shop }).filter((r) => r.code === code).reduce((s, r) => s + r.balance, 0));
  let run = opening;
  const lines = [];
  for (const e of entries({ from, to })) {
    for (const l of e.lines) {
      if (l.code !== code || (shop && l.shop !== shop)) continue;
      run = r2(run + l.amount);
      lines.push({ date: e.date, src: e.src, text: e.text, shop: l.shop, debit: l.amount > 0 ? l.amount : 0, credit: l.amount < 0 ? -l.amount : 0, balance: run, ref: e.ref });
    }
  }
  return { opening, closing: run, lines };
}

// ---------------------------------------------------------------- VAT return (FRCS, monthly, invoice basis)
export function vatReturn({ ym, shop }) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const vat = Number(apRules().vatRate) || 12.5;
  const sales = has('till_counts') ? db().all(`SELECT * FROM till_counts WHERE status <> 'void' AND shift_date BETWEEN ? AND ? AND (? IS NULL OR shop_code = ?) ORDER BY shift_date`, [from, to, shop || null, shop || null]) : [];
  const s = { total: 0, zero: 0, standard: 0, output: 0 };
  const saleRows = sales.map((c) => {
    const total = c.z_total !== null && c.z_total !== undefined ? Number(c.z_total) : r2(Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0));
    const zero = Number(c.z_zero_rated) || 0;
    const out = c.z_vat !== null && c.z_vat !== undefined ? Number(c.z_vat) : r2((total - zero) - (total - zero) / (1 + vat / 100));
    s.total += total; s.zero += zero; s.standard += total - zero; s.output += out;
    return { date: c.shift_date, shop: c.shop_code, ref: `${c.till_name || ''} ${c.shift || ''} Z ${c.z_number || ''}`.trim(), total: r2(total), zero: r2(zero), vat: r2(out), typed: c.z_vat !== null && c.z_vat !== undefined };
  });
  const invs = has('ap_invoices') ? db().all(`SELECT * FROM ap_invoices WHERE status <> 'void' AND total > 0 AND invoice_date BETWEEN ? AND ? AND (? IS NULL OR ifnull(shop_code, ?) = ?) ORDER BY invoice_date`,
    [from, to, shop || null, OFFICE, shop || '']) : [];
  const p = { total: 0, zero: 0, input: 0, noTin: 0 };
  const purchaseRows = invs.map((i) => {
    const sign = i.kind === 'credit' ? -1 : 1;
    p.total += sign * i.total; p.zero += sign * (Number(i.zero_rated) || 0); p.input += sign * (Number(i.vat) || 0);
    if (Number(i.vat) > 0 && !i.supplier_tin) p.noTin += 1;
    return { date: i.invoice_date, shop: i.shop_code || OFFICE, supplier: i.supplier_name, tin: i.supplier_tin || '', no: i.invoice_no || '', kind: i.kind, total: r2(sign * i.total), vat: r2(sign * (Number(i.vat) || 0)), status: i.status };
  });
  const output = r2(s.output);
  const input = r2(p.input);
  return {
    ym, from, to, shop: shop || null,
    sales: { total: r2(s.total), zeroRated: r2(s.zero), standard: r2(s.standard), exVat: r2(s.total - output), output },
    purchases: { total: r2(p.total), zeroRated: r2(p.zero), input, noTin: p.noTin, toCheck: purchaseRows.filter((r) => r.status === 'to_check').length },
    net: r2(output - input), payable: output - input >= 0, saleRows, purchaseRows,
    due: lastDayOfNextMonth(ym),
  };
}

// FRCS: the monthly VAT return and payment are due by the last day of the following month.
export function lastDayOfNextMonth(ym) {
  const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7));
  const n2 = m + 2 > 12 ? `${y + 1}-${String(m + 2 - 12).padStart(2, '0')}-01` : `${y}-${String(m + 2).padStart(2, '0')}-01`;
  return addDays(n2, -1);
}

// ---------------------------------------------------------------- manual journals
// lines: [{ code, debit, credit, shop }]
export function saveJournal(user, { date, memo, lines, kind = 'manual' }) {
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  assertOpen(d, 'This journal');
  need(txt(memo), 'Say what the journal is for.');
  const valid = new Set(listAccountsGL({ includeInactive: true }).map((a) => a.code));
  const clean = (lines || []).map((l) => ({ code: txt(l.code), debit: r2(l.debit), credit: r2(l.credit), shop: txt(l.shop) || OFFICE })).filter((l) => l.code && (l.debit || l.credit));
  need(clean.length >= 2, 'A journal needs at least two lines.');
  for (const l of clean) { need(valid.has(l.code), `Account ${l.code} does not exist.`); need(!(l.debit && l.credit), 'Each line is either a debit or a credit, not both.'); need(l.debit >= 0 && l.credit >= 0, 'No negative amounts.'); }
  const dr = r2(clean.reduce((s, l) => s + l.debit, 0));
  const cr = r2(clean.reduce((s, l) => s + l.credit, 0));
  need(Math.abs(dr - cr) < 0.005, `Debits (${$(dr)}) and credits (${$(cr)}) must be equal.`);
  const uid = uuid('JN');
  const { now, dev } = meta();
  db().run('INSERT INTO gl_journals (uid, jdate, memo, lines, kind, status, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)',
    [uid, d, txt(memo), JSON.stringify(clean), kind, 'active', user.name, now, now, dev]);
  audit({ user, action: `Journal ${d}: ${txt(memo)} ${$(dr)}`, table: 'gl_journals', recordUid: uid });
  return uid;
}
export function listJournals({ limit = 200 } = {}) {
  return db().all('SELECT * FROM gl_journals ORDER BY jdate DESC, created_at DESC LIMIT ?', [limit]).map((j) => ({ ...j, lines: J(j.lines, []) }));
}
export function voidJournal(user, uid, reason) {
  const j = db().get('SELECT * FROM gl_journals WHERE uid = ?', [uid]);
  need(j && j.status === 'active', 'Not found.');
  assertOpen(j.jdate, 'This journal');
  need(txt(reason), 'Say why.');
  const { now, dev } = meta();
  db().run(`UPDATE gl_journals SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Voided journal ${j.memo}`, table: 'gl_journals', recordUid: uid, reason: txt(reason) });
}

// ---------------------------------------------------------------- fixed assets
export function saveAsset(user, a) {
  need(txt(a.name), 'Name the asset, e.g. "Chiller – S1".');
  const d = txt(a.purchaseDate);
  need(DATE.test(d), 'Enter the purchase date.');
  assertOpen(d, 'This asset');
  const cost = r2(a.cost);
  need(cost > 0, 'Enter the cost (excl. VAT).');
  const life = Number(a.lifeYears);
  need(life > 0 && life <= 50, 'Enter how many years it will last (1–50).');
  const uid = a.uid || uuid('FA');
  const { now, dev } = meta();
  const notes = `${txt(a.notes)}${a.viaInvoice === false && !txt(a.notes).includes('[not via invoice]') ? ' [not via invoice]' : ''}`.trim() || null;
  db().run(`INSERT INTO fixed_assets (uid, name, category, shop_code, purchase_date, cost, life_years, salvage, serial, notes, photo_urls, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?, '[]', 'active', ?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, category=excluded.category, shop_code=excluded.shop_code, purchase_date=excluded.purchase_date, cost=excluded.cost, life_years=excluded.life_years,
    salvage=excluded.salvage, serial=excluded.serial, notes=excluded.notes, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, txt(a.name), txt(a.category) || null, txt(a.shopCode) || null, d, cost, life, r2(a.salvage), txt(a.serial) || null, notes, now, dev]);
  audit({ user, action: `Asset ${txt(a.name)} ${$(cost)} over ${life} years`, table: 'fixed_assets', recordUid: uid });
  return uid;
}
export function disposeAsset(user, uid, { date, amount, reason }) {
  const a = db().get('SELECT * FROM fixed_assets WHERE uid = ?', [uid]);
  need(a && a.status === 'active', 'Not found.');
  need(DATE.test(txt(date)), 'Enter the date it was sold / thrown out.');
  assertOpen(txt(date), 'This disposal');
  need(txt(reason), 'Say what happened to it.');
  const { now, dev } = meta();
  db().run(`UPDATE fixed_assets SET status = 'disposed', disposed_date = ?, disposed_amount = ?, notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [txt(date), r2(amount), `${a.notes || ''} Disposed: ${txt(reason)}`.trim(), now, dev, uid]);
  audit({ user, action: `Asset ${a.name} disposed`, table: 'fixed_assets', recordUid: uid, reason: txt(reason) });
}
export function listAssets(asOf = dateStr()) {
  return db().all("SELECT * FROM fixed_assets WHERE status <> 'void' ORDER BY purchase_date").map((a) => {
    const dep = depreciationFor(a, a.purchase_date, asOf);
    return { ...a, depreciated: dep, bookValue: r2(a.cost - dep), photos: J(a.photo_urls, []) };
  });
}

// ---------------------------------------------------------------- budgets
export function saveBudget(user, { ym, shopCode, code, amount, allYear }) {
  need(/^\d{4}-\d{2}$/.test(txt(ym)), 'Choose the month.');
  need(txt(code), 'Choose the account.');
  const months = allYear ? Array.from({ length: 12 }, (_, i) => `${ym.slice(0, 4)}-${String(i + 1).padStart(2, '0')}`) : [ym];
  const { now, dev } = meta();
  for (const m of months) {
    db().run(`INSERT INTO gl_budgets (uid, ym, shop_code, code, amount, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)
      ON CONFLICT(uid) DO UPDATE SET amount = excluded.amount, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [`${m}|${shopCode || OFFICE}|${code}`, m, shopCode || OFFICE, code, r2(amount), now, dev]);
  }
  audit({ user, action: `Budget ${code} ${shopCode || OFFICE} ${allYear ? `every month of ${ym.slice(0, 4)}` : ym}: ${$(amount)}`, table: 'gl_budgets' });
}
export function budgetVsActual({ ym, shopCode }) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const pl = profitLoss({ from, to, shops: shopCode && shopCode !== OFFICE ? [shopCode] : [] });
  const col = shopCode || null;
  const budgets = db().all('SELECT * FROM gl_budgets WHERE ym = ? AND (? IS NULL OR shop_code = ?)', [ym, col, col]);
  const codes = new Set(pl.rows.map((r) => r.code).concat(budgets.map((b) => b.code)));
  return [...codes].sort().map((code) => {
    const r = pl.rows.find((x) => x.code === code);
    const actual = r ? (col ? r.by[col] || 0 : r.total) : 0;
    const budget = r2(budgets.filter((b) => b.code === code).reduce((s, b) => s + b.amount, 0));
    return { code, name: r ? r.name : accountName(code), type: r ? r.type : 'expense', actual: r2(actual), budget, diff: r2(actual - budget) };
  });
}

// ---------------------------------------------------------------- closing a month
export function setLock(user, date, { reopen = false } = {}) {
  const cur = lockDate();
  need(DATE.test(txt(date)), 'Choose the last day to close.');
  if (cur && date < cur) need(reopen, `The books are closed to ${cur}. Only the owner can reopen.`);
  setShared('gl_lock', { date, by: user.name, at: stamp() });
  audit({ user, action: date < (cur || '') ? `Reopened the books after ${date}` : `Closed the books up to ${date}`, table: 'shared_settings', recordUid: 'gl_lock', before: { date: cur }, after: { date } });
}
// Month-end checklist: what still needs doing before the month can be closed. Ticks are saved per month.
export function monthEndChecklist(ym) {
  const from = `${ym}-01`;
  const to = addDays(Number(ym.slice(5, 7)) === 12 ? `${Number(ym.slice(0, 4)) + 1}-01-01` : `${ym.slice(0, 4)}-${String(Number(ym.slice(5, 7)) + 1).padStart(2, '0')}-01`, -1);
  const q = (sql, a) => { try { return db().get(sql, a).n; } catch (e) { return 0; } };
  const ticks = getShared(`month_end_${ym}`, {}) || {};
  const auto = [
    { key: 'till', label: 'Every till count approved', left: q("SELECT COUNT(*) AS n FROM till_counts WHERE status IN ('counted','queried') AND shift_date BETWEEN ? AND ?", [from, to]) },
    { key: 'inv', label: 'Every supplier invoice checked', left: q("SELECT COUNT(*) AS n FROM ap_invoices WHERE status = 'to_check' AND invoice_date BETWEEN ? AND ?", [from, to]) },
    { key: 'bank', label: 'Bank reconciled to the month end', left: q("SELECT COUNT(*) AS n FROM bank_accounts a WHERE a.active = 1 AND NOT EXISTS (SELECT 1 FROM bank_statements s WHERE s.account_uid = a.uid AND s.status <> 'void' AND s.to_date >= ?)", [to]) },
    { key: 'pay', label: 'Every pay run final', left: q("SELECT COUNT(*) AS n FROM pay_runs WHERE status = 'draft' AND pay_date BETWEEN ? AND ?", [from, to]) },
    { key: 'cash', label: 'Cash records verified', left: q("SELECT COUNT(*) AS n FROM cash_moves m WHERE m.status = 'active' AND m.type IN ('petty_out','petty_in','adjust_in','adjust_out') AND m.move_date BETWEEN ? AND ? AND NOT EXISTS (SELECT 1 FROM verifications v WHERE v.uid = 'cash_moves:' || m.uid AND v.status = 'verified')", [from, to]) },
    { key: 'suspense', label: 'Suspense account cleared (bank lines coded)', left: Math.abs(balances({ to }).filter((r) => r.code === '2900').reduce((s, r) => s + r.balance, 0)) > 0.004 ? 1 : 0 },
    { key: 'count', label: 'Stock take done this month (each shop with stock)', left: q("SELECT COUNT(DISTINCT m.shop_code) AS n FROM inv_moves m WHERE NOT EXISTS (SELECT 1 FROM inv_counts c WHERE c.shop_code = m.shop_code AND c.status = 'posted' AND c.count_date BETWEEN ? AND ?)", [from, to]) },
  ];
  const manual = [
    { key: 'vat', label: 'VAT return checked and filed with FRCS' }, { key: 'fnpf', label: 'FNPF paid and schedule sent' }, { key: 'paye', label: 'PAYE / SRT paid' },
    { key: 'statements', label: 'Main supplier statements checked' }, { key: 'review', label: 'Profit & loss looked at by the owner' },
  ].map((m) => ({ ...m, done: !!ticks[m.key], by: ticks[m.key] || null }));
  return { ym, from, to, auto: auto.map((a) => ({ ...a, done: !a.left })), manual, ready: auto.every((a) => !a.left) && manual.every((m) => m.done) };
}
export function tickMonthEnd(user, ym, key, on) {
  const t = getShared(`month_end_${ym}`, {}) || {};
  if (on) t[key] = `${user.name} ${stamp().slice(0, 10)}`; else delete t[key];
  setShared(`month_end_${ym}`, t);
}
