// Release 03 (owner, 12 Nov: "a place where Shop input, output and cheques for each shop"; "for each month there are
// fixed or constant expenses for each shop – rent, loans, EFL bills"): one page per shop and month, worked out from the
// same records the VAT return uses (nothing typed twice):
// - Sales (output VAT): each day, checked or not (monthRecords – a day with no sales needs a reason)
// - Purchases (input VAT): the shop's supplier invoices of the month, to check or checked, and weekly suppliers with
//   no invoice this week
// - Cheques: the shop's cheques (written, waiting, handed over, cleared)
// - Fixed costs: the shop's rent, shop loan, power / water and other regular bills, and what is due or overdue.
// Costs that belong to no shop (vehicle loans, the office) are listed apart, on the Money page.
import { db } from '../../db/connection.js';
import { dateStr } from '../../services/core.js';
import * as MR from './monthRecords.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const PER_MONTH = { weekly: 52 / 12, fortnightly: 26 / 12, monthly: 1, quarterly: 1 / 3, yearly: 1 / 12 };
export const perMonth = (amount, freq) => r2((Number(amount) || 0) * (PER_MONTH[freq] || 1));

export function shopNames() {
  try { return db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort, code').filter((s) => /^S\d+$/.test(String(s.code))); } catch (e) { return []; }
}

export function shopMonth({ shop, ym = dateStr().slice(0, 7) }) {
  const m = MR.monthRecords({ ym, shop });
  const past = m.days.filter((d) => !d.future);
  const days = past.map((d) => ({ ...d, checked: MR.dayChecked(shop, d) }));
  const invoices = (m.invoices || []).filter((i) => (i.shop_code || '') === shop);
  const inv = { list: invoices, count: invoices.length, toCheck: invoices.filter((i) => i.status === 'to_check').length, total: r2(invoices.reduce((t, i) => t + (Number(i.total) || 0), 0)), vat: r2(invoices.reduce((t, i) => t + (Number(i.vat) || 0), 0)) };
  let missing = [];
  try { if (ym === dateStr().slice(0, 7)) missing = require('../payables/regulars.js').missingRegulars({ shop }); } catch (e) { missing = []; }
  let cheques = [];
  try { cheques = require('../payables/chain.js').chequeBoard({ shopCode: shop }); } catch (e) { cheques = []; }
  const fixed = fixedCosts({ shop });
  return {
    shop, ym, locked: m.locked,
    sales: { days, total: m.totals.total, zero: m.totals.zero, standard: m.totals.standard, vat: m.totals.vat, checked: days.filter((d) => d.checked).length, toCheck: days.filter((d) => !d.checked).length },
    purchases: inv, missing, cheques,
    fixed,
    vat: { output: m.totals.vat, input: inv.vat, net: r2(m.totals.vat - inv.vat) },
    open: days.filter((d) => !d.checked).length + inv.toCheck + missing.length,
  };
}

// The shop's regular costs (or, with shop = null, the ones that belong to no shop – vehicle loans, the office).
export function fixedCosts({ shop = null } = {}) {
  let rows = [];
  try { rows = require('../loans/service.js').regularOverview(); } catch (e) { rows = []; }
  const codes = shopNames().map((s) => s.code);
  const mine = rows.filter((r) => r.active && (shop ? r.area === shop : !codes.includes(r.area)));
  const list = mine.map((r) => ({ uid: r.uid, name: r.name, kind: r.purposeLabel || r.kind, lender: r.lender, amount: r.amount, frequency: r.frequency, monthly: perMonth(r.amount, r.frequency),
    nextDue: r.nextDue, dueIn: r.dueIn, owing: r.owing, overdue: r.overdue, overdueAmount: r.overdueAmount, balance: r.balance, area: r.areaLabel }));
  return { list, monthly: r2(list.reduce((t, x) => t + x.monthly, 0)), overdue: list.filter((x) => x.overdue).length };
}

// Release 08: the shop's month as an Excel / PDF (the Excel button on the shop page) – sales days, invoices, cheques.
export function shopMonthReport({ shop, ym, name }) {
  const p = shopMonth({ shop, ym });
  const $ = (n) => (Number(n) || 0).toFixed(2);
  const col = (key, title, align = 'left') => ({ key, title, align });
  const R = 'right';
  const title = `${name || shop} ${ym}`;
  return {
    kind: 'shop-month', title, fileName: `${String(name || shop).replace(/\s+/g, '-')}-${ym}`, subtitle: `Easy Buys Shopping Centre · ${ym}`,
    sections: [
      { title: 'Summary', columns: [col('k', 'Item'), col('v', 'Amount', R)], rows: [
        { k: 'Sales (incl. VAT)', v: $(p.sales.total) }, { k: 'Zero-rated sales', v: $(p.sales.zero) }, { k: 'Output VAT', v: $(p.vat.output) },
        { k: 'Purchases (incl. VAT)', v: $(p.purchases.total) }, { k: 'Input VAT', v: $(p.vat.input) }, { k: p.vat.net >= 0 ? 'VAT to pay' : 'VAT to claim', v: $(Math.abs(p.vat.net)) }] },
      { title: 'Sales by day', columns: [col('date', 'Day'), col('total', 'Sales (VAT incl.)', R), col('zero', 'Zero-rated', R), col('vat', 'Output VAT', R), col('checked', 'Checked')],
        rows: p.sales.days.map((d) => ({ date: d.date, total: $(d.total), zero: $(d.zero), vat: $(d.vat), checked: d.checked ? `✓ ${d.checked.by || ''}`.trim() : 'to check' })) },
      { title: 'Supplier invoices', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('no', 'Invoice'), col('total', 'Amount', R), col('vat', 'Input VAT', R), col('status', 'Status')],
        rows: p.purchases.list.map((i) => ({ date: i.invoice_date, supplier: i.supplier_name, no: i.invoice_no || '', total: $(i.total), vat: $(i.vat), status: i.status === 'to_check' ? 'to check' : 'checked' })) },
      { title: 'Cheques', columns: [col('no', 'Cheque'), col('date', 'Written'), col('to', 'Paid to'), col('amount', 'Amount', R), col('status', 'Status')],
        rows: [].concat(...p.cheques.map((g) => g.list.map((c) => ({ no: c.no || '', date: c.date || '', to: c.supplierName || '', amount: $(c.amount), status: g.title })))) },
    ],
  };
}
