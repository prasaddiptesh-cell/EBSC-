// Financial statements in the IFRS for SMEs layout (as used in Fiji), the cash-flow forecast,
// and the Excel pack for the accountant. Every figure comes from the same books as the other reports.
import { db } from '../../db/connection.js';
import { stamp, dateStr, addDays, getShared } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import * as A from './service.js';
import * as F from './full.js';
import { nextDate } from '../payables/recurring.js';

const { r2, $ } = A;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const n2 = (x) => r2(x).toFixed(2);
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const biz = () => { try { return (getShared('report_template', {}) || {}).businessName || 'Easy Buys Shopping Centre'; } catch (e) { return 'Easy Buys Shopping Centre'; } };

// ---------------------------------------------------------------- grouping of accounts for the statements
const sumBy = (rows, test) => r2(rows.filter((r) => test(r.code, r)).reduce((s, r) => s + r.balance, 0));
const c = (code) => String(code);
const isCash = (k) => ['1000', '1010'].includes(k) || c(k).startsWith('1100:');
const isRecv = (k) => ['1110', '1200', '1250', '1400', '1450'].includes(k);
const isPPE = (k) => ['1500', '1590'].includes(k);
const isLoan = (k) => k === '2500' || c(k).startsWith('2500:');
const isTax = (k) => ['2200', '2100', '2110', '2600', '2700'].includes(k);

function position(asOf) {
  const rows = A.balances({ to: asOf });
  const bs = A.balanceSheet(asOf);
  // Loans: the part to be repaid in the next 12 months is shown as current (from each loan's repayment plan).
  let loanCurrent = 0;
  try { for (const l of F.listLoans()) loanCurrent += F.loanSchedule(l.uid).filter((p) => p.date <= addDays(asOf, 365)).reduce((s, p) => s + p.principal, 0); } catch (e) { /* no loans */ }
  const loans = -sumBy(rows, isLoan);
  loanCurrent = Math.min(r2(loanCurrent), Math.max(0, loans));
  const v = {
    ppe: sumBy(rows, isPPE),
    stock: sumBy(rows, (k) => k === '1300'),
    receivables: sumBy(rows, isRecv),
    cash: sumBy(rows, isCash),
    otherAssets: sumBy(rows, (k, r) => r.type === 'asset' && !isCash(k) && !isRecv(k) && !isPPE(k) && k !== '1300'),
    payables: -sumBy(rows, (k) => ['2000', '2300', '2190'].includes(k)),
    taxes: -sumBy(rows, isTax),
    loansCurrent: r2(loanCurrent),
    loansLong: r2(loans - loanCurrent),
    suspense: -sumBy(rows, (k) => k === '2900'),
    otherLiab: -sumBy(rows, (k, r) => r.type === 'liability' && !isLoan(k) && !isTax(k) && !['2000', '2300', '2190', '2900'].includes(k)),
    capital: -sumBy(rows, (k) => ['3000', '3100'].includes(k)),
    retained: r2(bs.totalEquity - -sumBy(rows, (k) => ['3000', '3100'].includes(k))),
    totalAssets: bs.totalAssets, totalLiab: bs.totalLiabilities, totalEquity: bs.totalEquity, ok: bs.ok,
  };
  v.currentAssets = r2(v.stock + v.receivables + v.cash + v.otherAssets);
  v.nonCurrentAssets = v.ppe;
  v.currentLiab = r2(v.payables + v.taxes + v.loansCurrent + v.suspense + v.otherLiab);
  v.nonCurrentLiab = v.loansLong;
  return v;
}
function income(from, to) {
  const pl = A.profitLoss({ from, to, shops: [] });
  const by = (test) => r2(pl.rows.filter((r) => test(r.code, r)).reduce((s, r) => s + r.total, 0));
  const revenue = by((k) => ['4000', '4100'].includes(k));
  const otherIncome = by((k, r) => r.type === 'income' && !['4000', '4100'].includes(k));
  const cos = by((k, r) => r.type === 'cogs');
  const finance = by((k) => k === '6700');
  const tax = by((k) => k === '8000');
  const depreciation = by((k) => k === '6800');
  const staff = by((k, r) => r.type === 'expense' && (r.code >= '6100' && r.code < '6200'));
  const otherExp = r2(pl.per.total.expenses - finance - tax - depreciation - staff);
  const gross = r2(revenue - cos);
  const before = r2(gross + otherIncome - staff - depreciation - otherExp - finance);
  return { revenue, cos, gross, otherIncome, staff, depreciation, otherExp, finance, before, tax, profit: r2(before - tax), rows: pl.rows };
}

// ---------------------------------------------------------------- IFRS for SMEs financial statements for a year (with last year beside it)
export function financialStatements(year) {
  const y = String(year); const p = String(Number(year) - 1);
  const end = `${y}-12-31`; const pend = `${p}-12-31`;
  const cur = position(end); const prev = position(pend);
  const ic = income(`${y}-01-01`, end); const pic = income(`${p}-01-01`, pend);
  const line = (label, a, b, bold) => ({ item: label, cy: n2(a), py: n2(b), _tone: bold ? 'bold' : null });
  const head = (label) => ({ item: label, cy: '', py: '', _tone: 'bold' });
  const cols = [col('item', ''), col('cy', y, R), col('py', p, R)];
  // Changes in equity
  const capMoves = (from, to) => { const r = A.balances({ from, to }); return -sumBy(r, (k) => ['3000', '3100'].includes(k)); };
  const eqOpen = prev.totalEquity; const capCY = capMoves(`${y}-01-01`, end);
  // Cash flow (indirect)
  const cf = cashFlow(`${y}-01-01`, end, prev, cur, ic);
  return {
    kind: 'fs', title: `Financial Statements ${y}`, fileName: `Financial-Statements-${y}`, subtitle: `${biz()} · year ended 31 December ${y}`,
    info: [['Business', biz()], ['Year ended', end], ['Basis', 'IFRS for SMEs (as adopted in Fiji); amounts in FJD'], ['Prepared from', 'Easy Buys app records – to be reviewed by the accountant'], ['Generated', stamp()]],
    summary: [{ label: 'Revenue', value: $(ic.revenue) }, { label: 'Profit for the year', value: $(ic.profit), tone: ic.profit < 0 ? 'bad' : undefined }, { label: 'Total assets', value: $(cur.totalAssets) }, { label: 'Equity', value: $(cur.totalEquity) }],
    sections: [
      { title: 'Statement of comprehensive income', columns: cols, rows: [
        line('Revenue', ic.revenue, pic.revenue), line('Cost of sales', -ic.cos, -pic.cos), line('Gross profit', ic.gross, pic.gross, true),
        line('Other income', ic.otherIncome, pic.otherIncome), line('Employee costs', -ic.staff, -pic.staff), line('Depreciation', -ic.depreciation, -pic.depreciation),
        line('Other operating expenses', -ic.otherExp, -pic.otherExp), line('Finance costs', -ic.finance, -pic.finance), line('Profit before income tax', ic.before, pic.before, true),
        line('Income tax expense', -ic.tax, -pic.tax), line('PROFIT FOR THE YEAR (total comprehensive income)', ic.profit, pic.profit, true)] },
      { title: 'Statement of financial position', columns: cols, rows: [
        head('ASSETS'), head('Non-current assets'), line('Property, plant and equipment', cur.ppe, prev.ppe), line('Total non-current assets', cur.nonCurrentAssets, prev.nonCurrentAssets, true),
        head('Current assets'), line('Inventories', cur.stock, prev.stock), line('Trade and other receivables (incl. prepayments, tax paid in advance)', cur.receivables, prev.receivables),
        line('Cash and cash equivalents', cur.cash, prev.cash), ...(Math.abs(cur.otherAssets) + Math.abs(prev.otherAssets) > 0.004 ? [line('Other current assets', cur.otherAssets, prev.otherAssets)] : []),
        line('Total current assets', cur.currentAssets, prev.currentAssets, true), line('TOTAL ASSETS', cur.totalAssets, prev.totalAssets, true),
        head('EQUITY AND LIABILITIES'), head('Equity'), line("Owner's capital (net of drawings)", cur.capital, prev.capital), line('Retained earnings', cur.retained, prev.retained), line('Total equity', cur.totalEquity, prev.totalEquity, true),
        head('Non-current liabilities'), line('Borrowings (due after 12 months)', cur.loansLong, prev.loansLong), line('Total non-current liabilities', cur.nonCurrentLiab, prev.nonCurrentLiab, true),
        head('Current liabilities'), line('Trade and other payables (incl. accruals)', cur.payables, prev.payables), line('Taxes and FNPF payable (VAT, PAYE, FNPF, provisional / income tax)', cur.taxes, prev.taxes),
        line('Borrowings (due within 12 months)', cur.loansCurrent, prev.loansCurrent), ...(Math.abs(cur.suspense) > 0.004 ? [line('Suspense – to be cleared before finalising', cur.suspense, prev.suspense)] : []),
        ...(Math.abs(cur.otherLiab) + Math.abs(prev.otherLiab) > 0.004 ? [line('Other current liabilities', cur.otherLiab, prev.otherLiab)] : []),
        line('Total current liabilities', cur.currentLiab, prev.currentLiab, true), line('TOTAL EQUITY AND LIABILITIES', cur.totalEquity + cur.totalLiab, prev.totalEquity + prev.totalLiab, true)],
      note: cur.ok ? '' : 'WARNING: the balance sheet does not balance – check the suspense account and journals.' },
      { title: 'Statement of changes in equity', columns: [col('item', ''), col('v', y, R)], rows: [
        { item: `Equity at 1 January ${y}`, v: n2(eqOpen) }, { item: 'Profit for the year', v: n2(ic.profit) }, { item: "Owner's money put in less drawings taken out", v: n2(capCY) },
        { item: `Equity at 31 December ${y}`, v: n2(cur.totalEquity), _tone: 'bold' }] },
      { title: 'Statement of cash flows', columns: [col('item', ''), col('v', y, R)], rows: cf.rows, note: cf.note },
      { title: 'Notes – property, plant and equipment', columns: [col('name', 'Asset'), col('shop', 'Shop'), col('bought', 'Bought'), col('cost', 'Cost', R), col('dep', 'Depreciation to date', R), col('bv', 'Carrying amount', R)],
        rows: A.listAssets(end).filter((a) => a.purchase_date <= end).map((a) => ({ name: a.name, shop: a.shop_code || 'Office', bought: a.purchase_date, cost: n2(a.cost), dep: n2(a.depreciated), bv: n2(a.status === 'disposed' && a.disposed_date <= end ? 0 : a.bookValue) })),
        note: 'Depreciation: straight line over each asset\'s useful life, month by month.' },
      { title: 'Notes – borrowings', columns: [col('name', 'Loan'), col('lender', 'Lender'), col('rate', 'Rate %', R), col('bal', 'Balance', R), col('paid', `Repaid in ${y}`, R), col('int', `Interest ${y}`, R)],
        rows: F.listLoans({ all: true, asOf: end }).map((g) => ({ name: g.name, lender: g.lender || '', rate: g.rate ?? '', bal: n2(g.balance), paid: n2(g.paidThisYear), int: n2(g.interestThisYear) })) },
    ],
  };
}
// Indirect method: profit, add back depreciation, working-capital changes; investing; financing; = change in cash.
function cashFlow(from, to, prev, cur, ic) {
  const dRecv = r2(cur.receivables - prev.receivables); const dStock = r2(cur.stock - prev.stock);
  const dPay = r2(cur.payables - prev.payables); const dTax = r2(cur.taxes - prev.taxes); const dOther = r2((cur.suspense + cur.otherLiab) - (prev.suspense + prev.otherLiab) - (cur.otherAssets - prev.otherAssets));
  const operating = r2(ic.profit + ic.depreciation - dRecv - dStock + dPay + dTax + dOther);
  const investing = r2(-(cur.ppe - prev.ppe + ic.depreciation));
  const financing = r2((cur.loansCurrent + cur.loansLong) - (prev.loansCurrent + prev.loansLong) + (cur.capital - prev.capital));
  const change = r2(cur.cash - prev.cash);
  const diff = r2(operating + investing + financing - change);
  const row = (item, v, bold) => ({ item, v: n2(v), _tone: bold ? 'bold' : null });
  return {
    rows: [row('Profit for the year', ic.profit), row('Add back: depreciation', ic.depreciation), row('(Increase) / decrease in receivables', -dRecv), row('(Increase) / decrease in inventories', -dStock),
      row('Increase / (decrease) in payables', dPay), row('Increase / (decrease) in taxes payable', dTax), ...(Math.abs(dOther) > 0.004 ? [row('Other movements', dOther)] : []),
      row('Net cash from operating activities', operating, true), row('Purchase of property, plant and equipment (net of disposals)', investing), row('Net cash used in investing activities', investing, true),
      row('Loans received / (repaid)', (cur.loansCurrent + cur.loansLong) - (prev.loansCurrent + prev.loansLong)), row("Owner's money in / (drawings)", cur.capital - prev.capital), row('Net cash from financing activities', financing, true),
      row('Net increase / (decrease) in cash', operating + investing + financing, true), row('Cash at the start of the year', prev.cash), row('Cash at the end of the year', cur.cash, true)],
    note: Math.abs(diff) > 0.01 ? `Check: the cash flow differs from the change in cash by ${$(diff)} (usually a disposal gain/loss or a suspense item).` : 'Agrees to the change in cash and bank balances.',
  };
}

// ---------------------------------------------------------------- cash-flow forecast (the coming weeks)
export function cashForecast({ weeks = 8, today = dateStr() } = {}) {
  const bal = A.balances({ to: today });
  let cash = sumBy(bal, isCash);
  // Takings: the average week of the last 8 weeks (sales incl. VAT from the books).
  const salesWeeks = 8;
  const recent = A.entries({ from: addDays(today, -7 * salesWeeks), to: today }).reduce((s, e) => s + e.lines.filter((l) => ['4000', '4100', '2200'].includes(l.code) && l.amount < 0 && ['Till', 'Aronium sales', 'Sale (typed)'].includes(e.src)).reduce((t, l) => t - l.amount, 0), 0);
  const weeklyTakings = r2(recent / salesWeeks);
  // Wages: the average of the last 4 final pay runs (net + FNPF + PAYE).
  const runs = has('pay_runs') ? db().all("SELECT uid FROM pay_runs WHERE status = 'final' ORDER BY pay_date DESC LIMIT 4") : [];
  const wageTotal = runs.reduce((s, r) => s + (db().get('SELECT COALESCE(SUM(gross + fnpf_employer),0) AS v FROM pay_lines WHERE run_uid = ? AND include = 1', [r.uid]).v || 0), 0);
  const weeklyWages = runs.length ? r2(wageTotal / runs.length) : 0;
  const out = [];
  const recurring = has('ap_recurring') ? db().all('SELECT * FROM ap_recurring WHERE active = 1') : [];
  const loanIds = recurring.filter((r) => r.kind === 'loan').map((r) => r.uid);
  for (let w = 0; w < weeks; w += 1) {
    const from = addDays(today, w * 7 + 1); const to = addDays(today, w * 7 + 7);
    // Unpaid bills by their due dates (the first week also takes anything already overdue), and regular bills / loan
    // repayments that will be made into bills later (projected from Regular bills & loans).
    const unpaid = has('ap_invoices') ? db().all("SELECT i.uid, i.due_date, i.total - COALESCE((SELECT SUM(a.amount) FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = i.uid),0) AS owing FROM ap_invoices i WHERE i.status <> 'void' AND i.kind = 'invoice'")
      .filter((i) => i.owing > 0.004 && (w === 0 ? (i.due_date || '') <= to : i.due_date >= from && i.due_date <= to)) : [];
    const isLoanBill = (uid) => /^RI-/.test(uid) && loanIds.some((id) => uid.startsWith(`RI-${id}-`));
    let bills = unpaid.filter((i) => !isLoanBill(i.uid)).reduce((t, i) => t + i.owing, 0);
    let loans = unpaid.filter((i) => isLoanBill(i.uid)).reduce((t, i) => t + i.owing, 0);
    for (const r of recurring) {
      let d = r.next_date; let g = 0;
      while (d && d <= to && (!r.end_date || d <= r.end_date) && g++ < 60) {
        if (d >= from && !db().get('SELECT 1 AS x FROM ap_invoices WHERE uid = ?', [`RI-${r.uid}-${d}`])) { if (r.kind === 'loan') loans += r.amount; else bills += r.amount; }
        d = nextDate(d, r.frequency, r.anchor_day);
      }
    }
    bills = r2(bills);
    // VAT and provisional tax due this week; company advance tax instalments.
    let tax = 0;
    const vatYm = (d) => { const x = new Date(`${d.slice(0, 7)}-01T00:00:00`); x.setMonth(x.getMonth() - 1); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}`; };
    const ym = vatYm(to);
    const vatDue = A.lastDayOfNextMonth(ym);
    if (vatDue >= from && vatDue <= to) { try { tax += Math.max(0, A.vatReturn({ ym }).net); } catch (e) { /* none */ } }
    try { tax += F.provTaxMonths().filter((p) => p.owing > 0 && p.due >= from && p.due <= to).reduce((s, p) => s + p.owing, 0); } catch (e) { /* none */ }
    try { tax += F.advanceTaxPlan(Number(to.slice(0, 4))).filter((i) => i.due >= from && i.due <= to).reduce((s, i) => s + Math.max(0, i.amount - i.paid), 0); } catch (e) { /* none */ }
    const inflow = weeklyTakings;
    const outflow = r2(bills + weeklyWages + loans + tax);
    const open = cash; cash = r2(cash + inflow - outflow);
    out.push({ week: w + 1, from, to, open: r2(open), takings: inflow, bills, wages: weeklyWages, loans: r2(loans), tax: r2(tax), close: cash });
  }
  return { weeks: out, weeklyTakings, weeklyWages, lowest: out.reduce((m, x) => Math.min(m, x.close), Infinity) };
}
export function forecastReport() {
  const f = cashForecast({ weeks: 13 });
  return { kind: 'forecast', title: 'Cash Flow Forecast', fileName: `Cash-Flow-Forecast-${dateStr()}`, subtitle: `${biz()} · next 13 weeks from ${dateStr()}`,
    info: [['Takings per week (average of the last 8 weeks)', $(f.weeklyTakings)], ['Wages per week (average of the last 4 pay runs)', $(f.weeklyWages)], ['Generated', stamp()]],
    summary: [{ label: 'Lowest cash expected', value: $(f.lowest), tone: f.lowest < 0 ? 'bad' : undefined }],
    sections: [{ title: 'Week by week', columns: [col('week', 'Week'), col('to', 'Week to'), col('open', 'Cash at start', R), col('takings', 'Takings in', R), col('bills', 'Bills due', R), col('wages', 'Wages', R), col('loans', 'Loan repayments', R), col('tax', 'VAT / tax', R), col('close', 'Cash at end', R)],
      rows: f.weeks.map((w) => ({ week: w.week, to: w.to, open: n2(w.open), takings: n2(w.takings), bills: n2(w.bills), wages: n2(w.wages), loans: n2(w.loans), tax: n2(w.tax), close: n2(w.close), _tone: w.close < 0 ? 'bad' : null })),
      note: 'A guide: takings and wages are averages; bills by their due dates; loans from each loan\'s repayment plan; VAT, provisional tax and advance tax on their due dates.' }] };
}

// ---------------------------------------------------------------- the pack for the accountant (Excel)
export function accountantPack(from, to) {
  const tb = A.trialBalance(to);
  const pl = A.profitLoss({ from, to, shops: listShops().filter((s) => s.active).map((s) => s.code) });
  const bs = A.balanceSheet(to);
  const code = (k) => (c(k).startsWith('1100:') ? `1100 ${A.accountName(k).replace('Bank – ', '')}` : c(k).startsWith('2500:') ? `2500 ${A.accountName(k).replace('Loan – ', '')}` : k);
  const gl = [];
  A.entries({ from, to }).forEach((e) => e.lines.forEach((l) => gl.push({ date: e.date, src: e.src, ref: e.ref, text: e.text, code: code(l.code), name: A.accountName(l.code), shop: l.shop === A.OFFICE ? 'Office' : l.shop, dr: l.amount > 0 ? n2(l.amount) : '', cr: l.amount < 0 ? n2(-l.amount) : '' })));
  const months = []; for (let d = `${from.slice(0, 7)}-01`; d <= to; d = F.addMonths(d, 1)) months.push(d.slice(0, 7));
  const vat = months.map((ym) => { const v = A.vatReturn({ ym }); return { ym, sales: n2(v.sales.total), out: n2(v.sales.output), purch: n2(v.purchases.total), inp: n2(v.purchases.input), net: n2(v.net), due: v.due }; });
  const journals = db().all("SELECT * FROM gl_journals WHERE jdate BETWEEN ? AND ? ORDER BY jdate", [from, to]).map((j) => ({ date: j.jdate, kind: A.JOURNAL_SRC[j.kind] || j.kind, memo: j.memo, status: j.status, by: j.by_name || '', reason: j.void_reason || '' }));
  return {
    kind: 'pack', title: 'Accountant Pack', fileName: `Accountant-Pack-${from}-to-${to}`, subtitle: `${biz()} · ${from} to ${to}`,
    info: [['Period', `${from} to ${to}`], ['Trial balance', tb.ok ? 'Balances' : 'DOES NOT BALANCE'], ['Balance sheet', bs.ok ? 'Balances' : 'DOES NOT BALANCE'], ['Generated', stamp()]],
    summary: [{ label: 'Sales & income', value: $(pl.per.total.income) }, { label: 'Net profit', value: $(pl.per.total.profit) }, { label: 'Total assets', value: $(bs.totalAssets) }],
    sections: [
      { title: 'Trial balance', columns: [col('code', 'Code'), col('name', 'Account'), col('type', 'Type'), col('dr', 'Debit', R), col('cr', 'Credit', R)],
        rows: tb.rows.map((r) => ({ code: code(r.code), name: r.name, type: r.type, dr: r.balance > 0 ? n2(r.balance) : '', cr: r.balance < 0 ? n2(-r.balance) : '' })).concat([{ code: '', name: 'TOTAL', type: '', dr: n2(tb.dr), cr: n2(tb.cr) }]) },
      { title: 'Profit and loss by shop', columns: [col('code', 'Code'), col('name', 'Account'), col('type', 'Type')].concat(pl.cols.map((k) => col(k, k === A.OFFICE ? 'Office' : k, R))).concat([col('total', 'Total', R)]),
        rows: pl.rows.map((r) => ({ code: r.code, name: r.name, type: r.type, ...Object.fromEntries(pl.cols.map((k) => [k, r.by[k] ? n2(r.by[k]) : ''])), total: n2(r.total) })) },
      { title: 'Balance sheet', columns: [col('part', 'Part'), col('code', 'Code'), col('name', 'Account'), col('v', 'Amount', R)],
        rows: [].concat(bs.assets.map((r) => ({ part: 'Assets', code: code(r.code), name: r.name, v: n2(r.balance) })), bs.liabilities.map((r) => ({ part: 'Liabilities', code: code(r.code), name: r.name, v: n2(r.balance) })), bs.equity.map((r) => ({ part: 'Equity', code: code(r.code), name: r.name, v: n2(r.balance) }))) },
      { title: 'General ledger', columns: [col('date', 'Date'), col('src', 'Source'), col('ref', 'Ref'), col('text', 'Description'), col('code', 'Code'), col('name', 'Account'), col('shop', 'Shop'), col('dr', 'Debit', R), col('cr', 'Credit', R)], rows: gl },
      { title: 'VAT by month', columns: [col('ym', 'Month'), col('sales', 'Sales incl VAT', R), col('out', 'Output VAT', R), col('purch', 'Purchases incl VAT', R), col('inp', 'Input VAT', R), col('net', 'Net VAT', R), col('due', 'Due')], rows: vat },
      { title: 'Journals', columns: [col('date', 'Date'), col('kind', 'Kind'), col('memo', 'What'), col('status', 'Status'), col('by', 'By'), col('reason', 'Void reason')], rows: journals },
      { title: 'Fixed assets', columns: [col('name', 'Asset'), col('date', 'Bought'), col('cost', 'Cost', R), col('life', 'Years', R), col('dep', 'Depreciated', R), col('bv', 'Carrying amount', R), col('st', 'Status')],
        rows: A.listAssets(to).map((a) => ({ name: a.name, date: a.purchase_date, cost: n2(a.cost), life: a.life_years, dep: n2(a.depreciated), bv: n2(a.bookValue), st: a.status })) },
      { title: 'Loans', columns: [col('name', 'Loan'), col('lender', 'Lender'), col('acc', 'Account no.'), col('bal', 'Balance', R), col('int', 'Interest this year', R)],
        rows: F.listLoans({ all: true, asOf: to }).map((g) => ({ name: g.name, lender: g.lender || '', acc: g.account_no || '', bal: n2(g.balance), int: n2(g.interestThisYear) })) },
    ],
  };
}
export function loanReport(uid) {
  const l = F.getLoan(uid);
  const led = A.ledgerFor(`2500:${uid}`, { from: '0000-01-01', to: dateStr() });
  return { kind: 'loan', title: `Loan – ${l.name}`, fileName: `Loan-${l.name.replace(/\s+/g, '-')}`, subtitle: `${l.lender || ''} ${l.account_no ? `· ${l.account_no}` : ''}`,
    info: [['Balance', $(l.balance)], ['Rate', l.rate ? `${l.rate}%` : '—'], ['Repayment', l.repayment ? `${$(l.repayment)} ${l.frequency}` : '—'], ['Generated', stamp()]],
    summary: [{ label: 'Balance now', value: $(l.balance) }, { label: 'Repaid this year', value: $(l.paidThisYear) }, { label: 'Interest this year', value: $(l.interestThisYear) }],
    sections: [
      { title: 'In the books', columns: [col('date', 'Date'), col('text', 'What'), col('up', 'Added', R), col('down', 'Repaid', R), col('bal', 'Owed', R)],
        rows: led.lines.map((x) => ({ date: x.date, text: `${x.src}: ${x.text}`, up: x.credit ? n2(x.credit) : '', down: x.debit ? n2(x.debit) : '', bal: n2(-x.balance) })) },
      { title: 'Coming repayments (guide)', columns: [col('date', 'Date'), col('payment', 'Payment', R), col('interest', 'Interest', R), col('principal', 'Off the loan', R), col('balance', 'Balance after', R)],
        rows: F.loanSchedule(uid, { max: 60 }).map((p) => ({ date: p.date, payment: n2(p.payment), interest: n2(p.interest), principal: n2(p.principal), balance: n2(p.balance) })) },
    ] };
}
export function provTaxReport(year) {
  const list = F.provTaxBySupplier(year);
  return { kind: 'provtax', title: `Provisional Tax ${year}`, fileName: `Provisional-Tax-${year}`, subtitle: `${biz()} · 5% withheld from contractors`,
    info: [['Year', String(year)], ['Generated', stamp()]],
    summary: [{ label: 'Withheld', value: $(list.reduce((s, x) => s + x.withheld, 0)) }],
    sections: [
      { title: 'By contractor (certificates)', columns: [col('name', 'Contractor'), col('tin', 'TIN'), col('n', 'Payments', R), col('gross', 'Gross paid', R), col('withheld', 'Tax withheld', R)], rows: list.map((x) => ({ ...x, gross: n2(x.gross), withheld: n2(x.withheld) })) },
      { title: 'By month (to pay FRCS)', columns: [col('ym', 'Month'), col('withheld', 'Withheld', R), col('paid', 'Paid', R), col('due', 'Due'), col('state', 'State')],
        rows: F.provTaxMonths({ year }).map((m) => ({ ym: m.ym, withheld: n2(m.withheld), paid: n2(m.paid), due: m.due, state: m.state })) },
    ] };
}

export const STATEMENT_REPORTS = [
  { id: 'acc_fs', group: 'Accounting & VAT', icon: '🏛️', title: 'Financial statements (IFRS for SMEs)', desc: 'Income, financial position, changes in equity, cash flows and notes, with last year beside it', perm: 'accounts_view',
    build(from, to) { return financialStatements(to.slice(0, 4)); } },
  { id: 'acc_pack', group: 'Accounting & VAT', icon: '📦', title: 'Accountant pack (Excel)', desc: 'Trial balance, P&L by shop, balance sheet, general ledger, VAT, journals, assets and loans – one workbook', perm: 'accounts_view', build: accountantPack },
  { id: 'acc_forecast', group: 'Accounting & VAT', icon: '🔮', title: 'Cash flow forecast', desc: 'Cash expected week by week for the next 13 weeks', perm: 'accounts_view', build() { return forecastReport(); } },
  { id: 'acc_provtax', group: 'Accounting & VAT', icon: '🧾', title: 'Provisional tax (contractors)', desc: '5% withheld per contractor and per month', perm: 'accounts_view', build(from, to) { return provTaxReport(to.slice(0, 4)); } },
];
