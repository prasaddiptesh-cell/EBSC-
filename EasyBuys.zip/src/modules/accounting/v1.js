// 1.0.0 (build 1) Reports and the books for the new office (map screens rep-month, rep-vat, rep-close, b-home, b-journal,
// b-ledger). Everything here is worked out from the books the app already keeps (accounting/service.js entries) – nothing
// is typed twice, so the reports always agree with the ledger:
//   monthSummary  – income, costs, supplier invoices and profit per shop and for the business, against last month and
//                   the same month last year, with the trend over the last 12 months. The closed shop (V M Pillay rent
//                   and loan) and the office / home costs are whole-business costs, never Shop 1 or Shop 2.
//   vatMonth      – the FRCS VAT return (payroll/returns.js) with each shop's part, the products with no VAT set in
//                   Aronium, the check against the ledger's VAT account and the trail: worked out → sent to the
//                   accountant (Excel) → filed → paid.
//   closeList / closeMonthNow – the month close: a checklist where every open item links to its screen; the month
//                   cannot be closed while anything is pending (no "close anyway" here).
//   booksStatus / journalList / ledgerLines / saveAdjustment – the books, visible; a closed month is never changed:
//                   an adjustment is booked on the first open day with the reason and the month it is for.
import { db } from '../../db/connection.js';
import { dateStr, addDays, stamp, getShared, setShared, audit, AppError, money } from '../../services/core.js';
import { lockDate } from '../../services/lock.js';
import * as A from './service.js';
import { requirePerm, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const YM = /^\d{4}-\d{2}$/;
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const ymLabel = (ym) => (YM.test(String(ym || '')) ? `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}` : String(ym || ''));
export function ymAdd(ym, k) {
  const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)) - 1 + k;
  const yy = y + Math.floor(m / 12); const mm = ((m % 12) + 12) % 12;
  return `${yy}-${String(mm + 1).padStart(2, '0')}`;
}
export function monthRange(ym) { return { from: `${ym}-01`, to: addDays(`${ymAdd(ym, 1)}-01`, -1) }; }
export const lastFullMonth = (today = dateStr()) => ymAdd(today.slice(0, 7), -1);
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const isOwner = (u) => !!u && (u.role === 'owner' || u.realRole === 'owner' || safe(() => require('../../services/access.js').actsAsOwner(u), false));
export function operatingShops() { return safe(() => db().all("SELECT code, name FROM shops WHERE active = 1 AND code LIKE 'S%' AND code <> 'S3' ORDER BY sort, code"), []); }
const shopName = (code) => (code === A.CLOSED ? 'Closed shop – V M Pillay' : code === A.OFFICE ? 'Office & home' : (operatingShops().find((s) => s.code === code) || {}).name || code);

// ---------------------------------------------------------------- profit per month (the same rules as A.profitLoss)
// Income and costs per month and column (each shop, the closed shop, the office) from ONE pass over the books.
// Each account is added up on its own and rounded the same way as A.profitLoss, so the two always agree to the cent.
export function plMonths(fromYm, toYm) {
  const shops = operatingShops().map((s) => s.code);
  const cols = shops.concat([A.CLOSED, A.OFFICE]);
  const accts = Object.fromEntries(A.listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const typeOf = (code) => (String(code).startsWith('1100:') ? 'asset' : String(code).startsWith('2500:') ? 'liability' : (accts[code] || {}).type || 'expense');
  const months = [];
  for (let ym = fromYm; ym <= toYm; ym = ymAdd(ym, 1)) months.push(ym);
  const per = {}; // ym -> code -> col -> amount
  for (const e of A.entries({ from: `${fromYm}-01`, to: monthRange(toYm).to })) {
    const ym = String(e.date).slice(0, 7);
    for (const l of e.lines) {
      const t = typeOf(l.code);
      if (!['income', 'cogs', 'expense'].includes(t)) continue;
      const col = cols.includes(l.shop) ? l.shop : l.shop === 'S3' ? A.CLOSED : A.OFFICE;
      const v = t === 'income' ? -l.amount : l.amount;
      const m = (per[ym] = per[ym] || {}); const c = (m[l.code] = m[l.code] || { by: {}, total: 0 });
      c.by[col] = r2((c.by[col] || 0) + v); c.total = r2(c.total + v);
    }
  }
  const out = {};
  for (const ym of months) {
    const rows = Object.entries(per[ym] || {}).map(([code, x]) => ({ code, name: (accts[code] || {}).name || A.accountName(code), type: typeOf(code), by: x.by, total: x.total })).sort((a, b) => (a.code < b.code ? -1 : 1));
    const sum = (type, col) => r2(rows.filter((r) => r.type === type).reduce((s, r) => s + (col ? r.by[col] || 0 : r.total), 0));
    const fig = (col) => { const income = sum('income', col); const cogs = sum('cogs', col); const expenses = sum('expense', col); return { income, cogs, gross: r2(income - cogs), expenses, costs: r2(cogs + expenses), profit: r2(income - cogs - expenses) }; };
    out[ym] = { ym, rows, cols, per: Object.fromEntries(cols.map((c) => [c, fig(c)]).concat([['total', fig(null)]])), any: rows.length > 0 };
  }
  return out;
}
// Supplier invoices (incl. VAT, less credit notes) per month and shop – regular bills and loan repayments are not supplier
// invoices (they are in the costs already).
function invoiceTotals(fromYm, toYm) {
  const out = {};
  if (!has('ap_invoices')) return out;
  const { to } = monthRange(toYm);
  for (const r of db().all(`SELECT substr(invoice_date,1,7) AS ym, COALESCE(NULLIF(shop_code,''), ?) AS s, SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END) AS t, COUNT(*) AS n
    FROM ap_invoices WHERE status <> 'void' AND total > 0 AND uid NOT LIKE 'RI-%' AND invoice_date BETWEEN ? AND ? GROUP BY 1, 2`, [A.OFFICE, `${fromYm}-01`, to])) {
    const s = r.s === 'S3' ? A.CLOSED : r.s;
    const m = (out[r.ym] = out[r.ym] || {});
    m[s] = { total: r2(((m[s] || {}).total || 0) + r.t), count: ((m[s] || {}).count || 0) + r.n };
  }
  return out;
}

// The monthly summary (map screen rep-month).
export function monthSummary(ym) {
  need(YM.test(String(ym || '')), 'Choose the month.');
  const first = ymAdd(ym, -12);
  const pl = plMonths(first, ym);
  const inv = invoiceTotals(first, ym);
  const shops = operatingShops();
  const prev = ymAdd(ym, -1);
  const ly = first;
  const invOf = (m, col) => ((inv[m] || {})[col] || { total: 0, count: 0 });
  const invAll = (m) => Object.values(inv[m] || {}).reduce((s, x) => ({ total: r2(s.total + x.total), count: s.count + x.count }), { total: 0, count: 0 });
  const wholeOf = (m) => { const c = pl[m].per[A.CLOSED]; const o = pl[m].per[A.OFFICE]; const add = (k) => r2(c[k] + o[k]); return { income: add('income'), cogs: add('cogs'), expenses: add('expenses'), costs: add('costs'), profit: add('profit') }; };
  const shopRows = shops.map((s) => ({
    code: s.code, name: s.name, ...pl[ym].per[s.code], invoices: invOf(ym, s.code).total, invoiceCount: invOf(ym, s.code).count,
    lastMonth: { ym: prev, ...pl[prev].per[s.code] }, lastYear: pl[ly].any ? { ym: ly, ...pl[ly].per[s.code] } : null,
  }));
  // what the whole-business costs are made of (closed shop, office / home), biggest first
  const lines = pl[ym].rows.map((r) => ({ code: r.code, name: r.name, type: r.type, closed: r2(r.by[A.CLOSED] || 0), office: r2(r.by[A.OFFICE] || 0) }))
    .filter((r) => Math.abs(r.closed) > 0.004 || Math.abs(r.office) > 0.004)
    .map((r) => ({ ...r, amount: r2(r.closed + r.office) })).sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
  const whole = { ...wholeOf(ym), closed: pl[ym].per[A.CLOSED], office: pl[ym].per[A.OFFICE], invoices: r2(invOf(ym, A.CLOSED).total + invOf(ym, A.OFFICE).total), lines,
    lastMonth: wholeOf(prev), lastYear: pl[ly].any ? wholeOf(ly) : null };
  const business = { ...pl[ym].per.total, invoices: invAll(ym).total, invoiceCount: invAll(ym).count,
    lastMonth: { ym: prev, ...pl[prev].per.total, invoices: invAll(prev).total }, lastYear: pl[ly].any ? { ym: ly, ...pl[ly].per.total, invoices: invAll(ly).total } : null };
  const trend = [];
  for (let m = ymAdd(ym, -11); m <= ym; m = ymAdd(m, 1)) {
    const t = { ym: m, label: ymLabel(m), any: pl[m].any, business: pl[m].per.total.profit, income: pl[m].per.total.income, costs: pl[m].per.total.costs, whole: wholeOf(m).profit };
    shops.forEach((s) => { t[s.code] = pl[m].per[s.code].profit; });
    trend.push(t);
  }
  const pct = (a, b) => (b && Math.abs(b) > 0.004 ? Math.round(((a - b) / Math.abs(b)) * 1000) / 10 : null);
  return {
    ym, label: ymLabel(ym), shops: shopRows, whole, business, trend, made: stamp(),
    change: { lastMonth: pct(business.profit, business.lastMonth.profit), lastYear: business.lastYear ? pct(business.profit, business.lastYear.profit) : null },
    closed: safe(() => A.monthCloseStatus(ym).closed, false),
  };
}

// ---------------------------------------------------------------- VAT return month (FRCS, invoice basis)
const TRAIL = { worked: 'Worked out', sent: 'Sent to the accountant (Excel)', filed: 'Filed', paid: 'Paid' };
export const TRAIL_STEPS = TRAIL;
function trailOf(kind, ym, status) {
  const t = getShared(`${kind}_trail_${ym}`, {}) || {};
  const lodged = status && (status.lodged || (status.item && status.item.lodged));
  const paid = status && ((status.file && status.file.paid_date) || (status.item && status.item.paid));
  return [
    { key: 'worked', label: TRAIL.worked, done: true, when: t.worked ? `${t.worked.by} · ${String(t.worked.at).slice(0, 16)}` : 'now, from the books' },
    { key: 'sent', label: TRAIL.sent, done: !!t.sent, when: t.sent ? `${t.sent.by} · ${String(t.sent.at).slice(0, 16)}` : null },
    { key: 'filed', label: kind === 'fnpf' ? 'Filed on the FNPF employer portal' : 'Filed with FRCS', done: !!lodged, when: lodged ? safe(() => `${status.lodged ? `version ${status.lodged.version} · ${String(status.lodged.lodged_date || status.lodged.created_at || '').slice(0, 10)}` : 'lodged'}`, 'lodged') : null },
    { key: 'paid', label: kind === 'fnpf' ? 'Paid to FNPF' : 'Paid to FRCS', done: !!paid, when: paid ? safe(() => String((status.file && status.file.paid_date) || ''), '') : null },
  ];
}
// "Sent to the accountant": kept with who and when (the Excel file is made at the same time on the screen).
export function markSent(user, kind, ym) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(['vat', 'fnpf'].includes(kind), 'Which return?');
  need(YM.test(String(ym || '')), 'Choose the month.');
  need(isBoss(user) || safe(() => require('../../services/access.js').can(user, 'statutory'), false) || safe(() => require('../../services/access.js').can(user, 'accounts_view'), false), 'Only the owner, admin or payroll can send this.');
  const t = getShared(`${kind}_trail_${ym}`, {}) || {};
  const now = { by: user.name, at: stamp() };
  if (!t.worked) t.worked = now;
  t.sent = now;
  setShared(`${kind}_trail_${ym}`, t);
  audit({ user, action: `${kind === 'vat' ? 'VAT return' : 'FNPF'} ${ym} sent to the accountant`, table: 'shared_settings', recordUid: `${kind}_trail_${ym}` });
  return t;
  });
}
// The ledger's VAT account (2200) for the month, split by where it came from.
export function ledgerVat(ym) {
  const { from, to } = monthRange(ym);
  const out = { output: 0, input: 0, creditNotes: 0, paid: 0, other: 0 };
  for (const e of A.entries({ from, to })) {
    for (const l of e.lines) {
      if (l.code !== '2200') continue;
      if (['Till', 'Sale (typed)', 'Aronium sales'].includes(e.src)) out.output = r2(out.output - l.amount);
      else if (['Invoice', 'Loan repayment', 'Expense (typed)', 'Aronium expense'].includes(e.src)) out.input = r2(out.input + l.amount);
      else if (e.src === 'Credit note') out.creditNotes = r2(out.creditNotes - l.amount);
      else if (e.src === 'Tax') out.paid = r2(out.paid + l.amount);
      else out.other = r2(out.other + l.amount);
    }
  }
  return out;
}
export function productsWithNoVat() {
  const P = safe(() => require('../../services/productWatch.js'), null);
  const list = P ? safe(() => P.productProblems().noTax, []) : [];
  const seen = new Map();
  for (const r of list) { const k = r.code || r.name; if (!seen.has(k)) seen.set(k, { code: r.code, name: r.name, shops: [r.shop] }); else seen.get(k).shops.push(r.shop); }
  return [...seen.values()];
}
export function vatMonth(ym) {
  need(YM.test(String(ym || '')), 'Choose the month.');
  const R = require('../payroll/returns.js');
  const v = R.vatReturnFRCS(ym);
  const status = safe(() => R.returnStatus('vat', ym), null);
  const shops = operatingShops().map((s) => {
    const x = safe(() => A.vatReturn({ ym, shop: s.code }), null);
    return x ? { code: s.code, name: s.name, sales: x.sales.total, zero: x.sales.zeroRated, output: x.sales.output, input: x.purchases.input, net: x.net } : { code: s.code, name: s.name, sales: 0, zero: 0, output: 0, input: 0, net: 0 };
  });
  const gl = ledgerVat(ym);
  const noVat = productsWithNoVat();
  // The return against the ledger: output VAT from Aronium's End of days vs the till balances booked; input VAT on the
  // invoices with a TIN (line 7) vs everything booked from invoices (VAT with no TIN is left off the return).
  const noTinVat = r2((v.noTin || []).reduce((s, x) => s + (Number(x.vat) || 0), 0));
  const agree = { output: r2(gl.output - v.sales.output), input: r2(gl.input - noTinVat - v.lines[7]), credit: r2(gl.creditNotes - v.creditVat) };
  // Figures from a till PC that cannot be right (a negative or a 10× End of day) are in the return until fixed – say so.
  const checks = v.checks.filter((c) => c.level !== 'ok');
  const { from, to } = monthRange(ym);
  safe(() => require('../../services/dayStart.js').believableSales(from, to).flagged, []).forEach((f) => checks.unshift({ level: 'bad', text: `${f.till} sent ${f.why}${f.z ? ` (Z ${f.z})` : ''} on ${f.date} – it is in the return; fix the End of day in Aronium › End of days before sending.` }));
  if (!checks.length) checks.push({ level: 'ok', text: 'Every check passed.' });
  return {
    ym, label: ymLabel(ym), due: v.due, rate: v.rate, lines: v.lines, output: v.lines[6], input: v.lines[12], toPay: v.lines[13], refund: v.lines[13] < 0,
    zeroRated: v.lines[2], sales: v.lines[1], aroniumVat: r2(v.sales.output), shops, ledger: gl, agree, agrees: Object.values(agree).every((d) => Math.abs(d) < 0.01),
    noVat, checks, blocking: checks.filter((c) => c.level === 'bad'), schedule: v.schedule, trail: trailOf('vat', ym, status), status,
  };
}

// ---------------------------------------------------------------- month close (nothing pending)
// Where each item of the month-end list is fixed (the screen it opens).
const CLOSE_NAV = {
  till: ['Till', {}], inv: ['ApInvoices', { filter: 'to_check' }], bank: ['BankMonthEnd', {}], pay: ['Payroll', {}], cash: ['CashOnHand', {}], suspense: ['Ledger', { code: '2900' }],
  eod: ['AroniumEods', {}], eodtill: ['AroniumEods', {}], shifts: ['TillShifts', {}], count: ['StockTakes', {}], safecount: ['CashOnHand', {}], wallets: ['Wallets', {}], loans: ['LoansRent', {}], bills: ['Bills', {}],
  vat: ['VatMonth', {}], fnpf: ['FnpfMonth', {}], paye: ['TaxCalendar', {}], statements: ['ApSuppliers', {}], credit: ['Owed', {}], drawings: ['OwnerMoney', {}], review: ['MonthSummary', {}],
};
export function closeList(ym) {
  need(YM.test(String(ym || '')), 'Choose the month.');
  const c = A.monthEndChecklist(ym);
  const lock = lockDate();
  const nav = (x) => {
    if (x.go) return { screen: x.go, params: { ym } };
    const k = String(x.key || '');
    if (k.startsWith('bank35_')) return { screen: k === 'bank35_mpaisa' ? 'Wallets' : 'ReconMonth', params: { ym } };
    if (k.startsWith('tax') || /pay day report/i.test(x.label || '')) return { screen: 'TaxCalendar', params: {} };
    if (/monthly business report/i.test(x.label || '')) return { screen: 'MonthReport', params: { ym } };
    const n = CLOSE_NAV[k];
    return n ? { screen: n[0], params: { ...n[1], ym } } : null;
  };
  const items = c.auto.map((x) => ({ key: x.key, label: x.label, sub: x.sub || null, left: x.left, done: !!x.done, auto: true, nav: x.done ? null : nav(x) }))
    .concat(c.manual.map((x) => ({ key: x.key, label: x.label, sub: x.by ? `ticked by ${x.by}` : null, left: x.done ? 0 : 1, done: !!x.done, auto: false, nav: nav(x) })));
  const open = items.filter((x) => !x.done);
  const closed = !!lock && lock >= c.to;
  const prevClosed = !!lock && lock >= addDays(c.from, -1);
  return { ym, label: ymLabel(ym), from: c.from, to: c.to, items, open: open.length, done: items.length - open.length, total: items.length, ready: !open.length, closed, prevClosed: prevClosed || !lock, lock, info: getShared(`month_close_${ym}`, null) };
}
// Close the month: refused while anything is pending – the list says what and where.
export function closeMonthNow(user, ym) {
  need(isBoss(user), 'Only the owner or admin can close a month.');
  const l = closeList(ym);
  need(!l.closed, `${l.label} is already closed.`);
  need(!l.lock || l.lock >= addDays(l.from, -1), 'Close the months before it first.');
  need(l.ready, `${l.label} cannot be closed yet – ${l.open} thing${l.open === 1 ? ' is' : 's are'} still open: ${l.items.filter((x) => !x.done).map((x) => x.label).slice(0, 6).join('; ')}${l.open > 6 ? ' …' : ''}.`);
  return A.closeMonth(user, ym, {});
}
export function tickCloseItem(user, ym, key, on) {
  need(isBoss(user), 'Only the owner or admin can tick the month-end list.');
  need(!closeList(ym).closed, 'This month is closed.');
  A.tickMonthEnd(user, ym, key, on);
  audit({ user, action: `Month end ${ym}: "${key}" ${on ? 'ticked' : 'unticked'}`, table: 'shared_settings', recordUid: `month_end_${ym}` });
}

// ---------------------------------------------------------------- the books, visible
export function booksStatus(asOf = dateStr()) {
  const tb = safe(() => A.trialBalance(asOf), { ok: false, dr: 0, cr: 0, rows: [] });
  const lock = lockDate();
  return { asOf, upTo: asOf, lock, lockedLabel: lock ? `${lock}` : null, tb: { ok: tb.ok, dr: tb.dr, cr: tb.cr, accounts: tb.rows.length }, year: asOf.slice(0, 4) };
}
// Where the record behind a ledger line is opened.
export function sourceNav(src, ref) {
  const r = String(ref || '');
  switch (src) {
    case 'Till': return { screen: 'TillCountView', params: { uid: r } };
    case 'Invoice': case 'Credit note': case 'Loan repayment': return { screen: 'ApInvoice', params: { uid: r } };
    case 'Payment': return { screen: 'ApPayment', params: { uid: r } };
    case 'Payroll': return { screen: 'PayRun', params: { uid: r } };
    case 'Deposit': return { screen: 'Deposits', params: {} };
    case 'Bank': return { screen: 'BankHistory', params: {} };
    case 'Wallet': return { screen: 'Wallets', params: {} };
    case 'Cash': return { screen: 'CashOnHand', params: {} };
    case 'Staff': return { screen: 'StaffDebts', params: {} };
    case 'Tax': return { screen: 'TaxCalendar', params: {} };
    case 'Stock': return { screen: 'InvStock', params: {} };
    case 'Loan': return { screen: 'LoansRent', params: {} };
    case 'Depreciation': case 'Asset': return { screen: 'Assets', params: {} };
    default: return { screen: 'Journals', params: {} };
  }
}
// Who made the record behind an entry, and when (the first change kept in the change history).
function whoFor(ref) {
  if (!ref || !has('audit_log')) return null;
  const a = safe(() => db().get('SELECT user_name, at FROM audit_log WHERE record_uid = ? ORDER BY at LIMIT 1', [ref]), null);
  return a ? { by: a.user_name || 'System', at: String(a.at || '').slice(0, 16) } : null;
}
// The journal: every entry in date order (newest first), with its source, who and when, and its lines.
export function journalList({ from, to, limit = 60, offset = 0, q = '' } = {}) {
  const all = A.entries({ from, to }).slice().reverse();
  const ql = txt(q).toLowerCase();
  const list = ql ? all.filter((e) => `${e.src} ${e.text} ${e.ref}`.toLowerCase().includes(ql)) : all;
  const accts = Object.fromEntries(A.listAccountsGL({ includeInactive: true }).map((a) => [a.code, a.name]));
  return {
    total: list.length,
    rows: list.slice(offset, offset + limit).map((e) => {
      const lines = e.lines.filter((l) => Math.abs(l.amount) > 0.004).map((l) => ({ code: l.code, name: accts[l.code] || A.accountName(l.code), shop: l.shop, debit: l.amount > 0 ? r2(l.amount) : 0, credit: l.amount < 0 ? r2(-l.amount) : 0 }));
      return { date: e.date, src: e.src, ref: e.ref, text: e.text, shop: e.shop, amount: r2(lines.reduce((s, l) => s + l.debit, 0)), lines, who: whoFor(e.ref), nav: sourceNav(e.src, e.ref) };
    }),
  };
}
// One account's lines with the running balance; each line opens the record behind it.
export function ledgerLines(code, { from, to, shop } = {}) {
  const l = A.ledgerFor(code, { from, to, shop });
  return { ...l, code, name: A.accountName(code), lines: l.lines.map((x) => ({ ...x, nav: sourceNav(x.src, x.ref) })) };
}
// An adjustment the accountant asked for, booked by the owner with a note. A closed month is never changed: the entry
// goes on the first open day, says which month it is for and why.
export function saveAdjustment(user, { forYm, date, memo, reason, lines }) {
  requirePerm(user, 'accounts_journal', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(isOwner(user) || isBoss(user), 'Only the owner (or admin) books an adjustment.');
  need(txt(reason), 'Write why the adjustment is made (for example "asked by the accountant").');
  need(txt(memo), 'Write what the adjustment is.');
  const lock = lockDate();
  let d = txt(date) || dateStr();
  if (lock && d <= lock) d = addDays(lock, 1);
  const forText = YM.test(String(forYm || '')) ? ` (for ${ymLabel(forYm)})` : '';
  const uid = A.saveJournal(user, { date: d, memo: `Adjustment${forText}: ${txt(memo)} – ${txt(reason)}`, lines, kind: 'manual', meta: { adjustment: true, forYm: forYm || null, reason: txt(reason) } });
  audit({ user, action: `Adjustment booked${forText}: ${txt(memo)}`, table: 'gl_journals', recordUid: uid, reason: txt(reason) });
  return { uid, date: d };
  });
}

// ---------------------------------------------------------------- Excel / PDF for the accountant
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
export function monthSummaryReport(from) {
  const ym = YM.test(String(from || '').slice(0, 7)) ? String(from).slice(0, 7) : lastFullMonth();
  const m = monthSummary(ym);
  const rows = m.shops.map((s) => ({ who: s.name, income: s.income, cogs: s.cogs, expenses: s.expenses, profit: s.profit, invoices: s.invoices, last: s.lastMonth.profit, ly: s.lastYear ? s.lastYear.profit : '' }))
    .concat([{ who: 'Whole business costs (closed shop, office & home)', income: m.whole.income, cogs: m.whole.cogs, expenses: m.whole.expenses, profit: m.whole.profit, invoices: m.whole.invoices, last: m.whole.lastMonth.profit, ly: m.whole.lastYear ? m.whole.lastYear.profit : '' },
      { who: 'Business', income: m.business.income, cogs: m.business.cogs, expenses: m.business.expenses, profit: m.business.profit, invoices: m.business.invoices, last: m.business.lastMonth.profit, ly: m.business.lastYear ? m.business.lastYear.profit : '' }]);
  return {
    info: [['Month', ymLabel(ym)], ['Made', stamp()]],
    title: `Monthly summary – ${m.label}`, subtitle: 'Profit per shop from the books (income, costs, supplier invoices)',
    summary: [{ label: 'Business profit', value: $(m.business.profit) }, { label: 'Last month', value: $(m.business.lastMonth.profit) }, { label: 'Same month last year', value: m.business.lastYear ? $(m.business.lastYear.profit) : '–' }],
    sections: [
      { title: 'Per shop', columns: [col('who', 'Shop'), col('income', 'Income', R), col('cogs', 'Cost of goods', R), col('expenses', 'Expenses', R), col('profit', 'Profit', R), col('invoices', 'Supplier invoices', R), col('last', 'Profit last month', R), col('ly', 'Profit same month last year', R)], rows },
      { title: 'Whole business costs', columns: [col('name', 'Account'), col('closed', 'Closed shop', R), col('office', 'Office & home', R), col('amount', 'Total', R)], rows: m.whole.lines },
      { title: 'Trend', columns: [col('label', 'Month')].concat(m.shops.map((s) => col(s.code, `${s.code} profit`, R))).concat([col('whole', 'Whole business costs', R), col('business', 'Business profit', R)]), rows: m.trend },
    ],
  };
}
export function vatMonthReport(from) {
  const ym = YM.test(String(from || '').slice(0, 7)) ? String(from).slice(0, 7) : lastFullMonth();
  const v = vatMonth(ym);
  const R2 = require('../payroll/returns.js');
  return {
    title: `VAT return – ${v.label}`, subtitle: `FRCS, invoice basis · due ${v.due}`,
    info: [['Month', v.label], ['Due', v.due], ['Status', String(v.status && v.status.text || v.status || '')], ['Made', stamp()]],
    summary: [{ label: 'VAT on sales', value: $(v.output) }, { label: 'VAT on purchases', value: $(v.input) }, { label: v.refund ? 'Refund due from FRCS' : 'VAT to pay FRCS', value: $(Math.abs(v.toPay)) },
      { label: 'Books agree', value: v.agrees ? 'yes' : 'NO – check' }],
    sections: [
      { title: 'Return lines', columns: [col('n', 'Line', R), col('text', 'What'), col('amount', 'Amount', R)], rows: R2.VAT_LINES.map(([n, t]) => ({ n, text: t, amount: v.lines[n] })) },
      { title: 'By shop', columns: [col('name', 'Shop'), col('sales', 'Sales', R), col('zero', 'Zero-rated', R), col('output', 'VAT on sales', R), col('input', 'VAT on purchases', R), col('net', 'Net', R)], rows: v.shops },
      { title: 'Input schedule', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('tin', 'TIN'), col('no', 'Invoice'), col('total', 'Total', R), col('vat', 'VAT', R)], rows: v.schedule },
      { title: 'No VAT set in Aronium', columns: [col('code', 'Code'), col('name', 'Product'), col('shops', 'Shops')], rows: v.noVat.map((p) => ({ ...p, shops: p.shops.join(', ') })) },
      { title: 'Checks', columns: [col('level', 'Level'), col('text', 'Check')], rows: v.checks },
    ],
  };
}
export const V1_REPORTS = [
  { id: 'v1_month', group: 'Accounting & VAT', icon: '📊', title: 'Monthly summary (per shop)', desc: 'Profit per shop, whole-business costs, last month, same month last year, the trend', perm: 'accounts_view', build: monthSummaryReport },
  { id: 'v1_vat', group: 'Accounting & VAT', icon: '🧾', title: 'VAT return for the accountant', desc: 'The FRCS lines, each shop, the input schedule and products with no VAT set', perm: 'accounts_view', build: vatMonthReport },
];
