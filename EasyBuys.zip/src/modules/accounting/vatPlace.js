// Release 03 (owner, 12 Nov: "one place for VAT – transparent and correct; for each month, how many of the invoices
// from before the app are done and how many pending"). Pure helpers (no database, no cloud) used by the VAT return
// screen (payroll/screens/ReturnsScreens.js) and Invoices from before the app (screens/HistoryScreens.js):
//  - vatByShop: output VAT (sales) and input VAT (purchases) per shop and in total, from vatReturnFRCS's answer, each
//    with where to open the entries behind it;
//  - checkProgress / lodgeGate: how many sales days and invoices are checked, and whether Lodge is allowed;
//  - histMonthLine / histReadingNote: the background reading of the old invoices for one month, from the cloud's
//    hist_status answer, and what to do when the background reading is off.
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// The app keeps its own records from 1 November 2026; earlier months come from the old-invoice reading (Google Drive).
export const APP_START_YM = '2026-11';
export const beforeApp = (ym) => /^\d{4}-\d{2}$/.test(String(ym || '')) && String(ym) < APP_START_YM;

// v = RT.vatReturnFRCS(ym) → { rate, shops: [{ shop, label, sales, zero, standard, output, credits, input, invoices, net,
//   days, daysDone, goSales, goInvoices }], other: { output, input } (typed-in lines, whole business),
//   total: { sales, zero, output, input, net }, rounding }
// Output VAT of a shop = its standard-rated sales × tax fraction + VAT on the credit notes it received (line 5).
// Input VAT of a shop = VAT on its supplier tax invoices with a TIN (line 7). The total is the return itself (lines 6,
// 12, 13); a cent of rounding between the shops and the return is shown, never hidden.
export function vatByShop(v, { ym } = {}) {
  const period = ym || v.period;
  const rate = Number(v.rate) || 12.5;
  const by = {};
  const get = (s) => {
    const k = s || '';
    if (!by[k]) by[k] = { shop: k, sales: 0, zero: 0, standard: 0, output: 0, credits: 0, input: 0, invoices: 0, net: 0, days: 0, daysDone: 0 };
    return by[k];
  };
  const ticks = (v.ticks && v.ticks.byShop) || {};
  Object.keys(ticks).forEach((s) => { const x = get(s); x.days = ticks[s].days; x.daysDone = ticks[s].done; });
  for (const r of v.saleRows || []) { const x = get(r.shop); x.sales += Number(r.total) || 0; x.zero += Number(r.zero) || 0; }
  for (const r of v.schedule || []) { const x = get(r.shop); x.input += Number(r.vat) || 0; x.invoices += 1; }
  for (const r of v.credits || []) { const x = get(r.shop); x.credits += Math.abs(Number(r.vat) || 0); }
  const shops = Object.values(by).map((x) => {
    const sales = r2(x.sales); const zero = r2(x.zero); const standard = r2(sales - zero);
    const output = r2((standard * rate) / (100 + rate) + x.credits);
    const input = r2(x.input);
    const goShop = /^S\d+$/.test(x.shop) ? x.shop : undefined;
    const label = goShop ? x.shop : x.shop === 'OFFICE' ? 'Office / whole business' : x.shop || 'No shop';
    return { ...x, label, sales, zero, standard, credits: r2(x.credits), output, input, net: r2(output - input),
      goSales: ['MonthRecords', { ym: period, shop: goShop, tab: 'sales' }], goInvoices: ['MonthRecords', { ym: period, shop: goShop, tab: 'invoices' }] };
  }).sort((a, b) => { const k = (x) => (/^S\d+$/.test(x.shop) ? `0${x.shop}` : `1${x.shop}`); return k(a) < k(b) ? -1 : 1; });
  const L = v.lines || {};
  const adj = (k) => r2((v.adjust && v.adjust[k] && v.adjust[k].amount) || 0);
  const other = { output: adj('l5'), input: r2(adj('l8') + adj('l9') - adj('l11')) };
  const sumOut = r2(shops.reduce((t, x) => t + x.output, 0) + other.output);
  const sumIn = r2(shops.reduce((t, x) => t + x.input, 0) + other.input);
  const total = { sales: r2(L[1]), zero: r2(L[2]), output: r2(L[6]), input: r2(L[12]), net: r2(L[13]) };
  return { rate, shops, other, total, rounding: { output: r2(total.output - sumOut), input: r2(total.input - sumIn) } };
}

// ticks = vatReturnFRCS(ym).ticks (monthRecords.vatChecks) → the words for the screen.
export function checkProgress(ticks) {
  const t = ticks || { days: 0, daysDone: 0, invoices: 0, invoicesDone: 0 };
  const daysLeft = Math.max(0, (t.days || 0) - (t.daysDone || 0));
  const invLeft = Math.max(0, (t.invoices || 0) - (t.invoicesDone || 0));
  const all = !!ticks && (t.days || 0) + (t.invoices || 0) > 0 && daysLeft + invLeft === 0;
  return {
    days: t.days || 0, daysDone: t.daysDone || 0, daysLeft, invoices: t.invoices || 0, invoicesDone: t.invoicesDone || 0, invLeft, all,
    text: `Sales days checked: ${t.daysDone || 0} of ${t.days || 0}${daysLeft ? ` (${daysLeft} still to check)` : ''} · Invoices checked: ${t.invoicesDone || 0} of ${t.invoices || 0}${invLeft ? ` (${invLeft} still to check)` : ''}`,
  };
}

// st = RT.returnStatus('vat', ym) → may "Record the lodgement" be pressed? (Owner / admin may still force it, with a
// reason – the service asks for one.) Mirrors returns.js lodgeReturn: anything 'bad' in the checks blocks it, and
// entries not checked are always 'bad'.
export function lodgeGate(st) {
  const now = (st && st.now) || {};
  const blocking = now.blocking || [];
  const p = checkProgress(now.ticks);
  if (now.ticks && !p.all) return { ok: false, why: `Check every entry first: ${p.text}.`, blocking };
  if (blocking.length) return { ok: false, why: `Fix these first: ${blocking.map((c) => c.text).join(' ')}`, blocking };
  return { ok: true, why: '', blocking };
}

// The old-invoice reading of one month, from the cloud's hist_status answer
// { files, read, left, failed, months: [{ ym, files, read, failed, left, now }], last_error }.
// → null when that month has no files (or the cloud is too old to say), else
//   { ym, files, read, waiting, failed, done, now, text }
export function histMonthLine(status, ym) {
  const months = status && Array.isArray(status.months) ? status.months : [];
  const m = months.find((x) => x && x.ym === ym);
  if (!m) return null;
  const files = Number(m.files) || 0;
  const read = Number(m.read) || 0;
  const failed = Number(m.failed) || 0;
  const waiting = m.left !== undefined && m.left !== null ? Number(m.left) || 0 : Math.max(0, files - read - failed);
  const parts = [`${read} of ${files} invoice file${files === 1 ? '' : 's'} read`, `${waiting} waiting`, `${failed} need${failed === 1 ? 's' : ''} you (couldn't be read)`];
  return { ym, files, read, waiting, failed, done: waiting === 0, now: !!m.now, text: parts.join(' · ') };
}
// Every month the cloud knows, newest first (as the cloud sends them).
export function histMonthLines(status) {
  const months = status && Array.isArray(status.months) ? status.months : [];
  return months.map((x) => histMonthLine(status, x.ym)).filter(Boolean);
}

// last_error from hist_status → what to tell the owner. kind: 'off' (the 10-minute timer was never allowed), 'stale'
// (it has not run for 30 minutes), 'error' (anything else, e.g. no AI key) or null.
export function histReadingNote(lastError) {
  const e = String(lastError || '').trim();
  if (!e) return null;
  if (/not switched on|switch(ed)? it on|allow it/i.test(e)) {
    return { kind: 'off', tone: 'danger', title: 'The background reading is OFF',
      steps: ['On a computer, open the Easy Buys cloud project in Apps Script (script.google.com).', 'At the top, choose the function histRun.', 'Press Run once.', 'Google asks for permission: choose the Easy Buys account and press Allow.', 'Done – it then reads by itself every 10 minutes, with the app closed. Come back here and press Refresh.'],
      message: e };
  }
  if (/has not run|Triggers/i.test(e)) {
    return { kind: 'stale', tone: 'warn', title: 'The background reading has not run for a while',
      steps: ['Wait a few minutes and press Refresh – it usually carries on by itself.', 'If this stays: open Apps Script › Triggers and check that histRun is there (every 10 minutes). If not, choose histRun at the top, press Run once and allow it.'],
      message: e };
  }
  return { kind: 'error', tone: 'warn', title: 'The reader stopped', steps: [], message: e };
}
