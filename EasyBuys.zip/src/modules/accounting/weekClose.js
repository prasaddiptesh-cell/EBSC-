// Release 18 (owner, 14 Nov: "each week needs to be closed, so that its easier to close the month … sometimes some
// invoices will be brought forward to the following week … sunday being the best day for closing the week, but keep in
// mind the monthly closure"): weeks run Monday – Sunday and are split at a month end (the 1st starts a new week), so
// every week belongs to one month. A week is closed when each shop's sales days are checked and its supplier invoices
// are checked; invoices still waiting can be brought forward to the next week. The month close then asks that every
// week of the month is closed (once weekly closing is in use).
import { db } from '../../db/connection.js';
import { AppError, addDays, dateStr, getShared, setShared, audit, stamp } from '../../services/core.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const isBoss = (u) => !!u && ['owner', 'admin'].includes(u.role);
const lastDay = (ym) => { const d = new Date(Number(ym.slice(0, 4)), Number(ym.slice(5, 7)), 0); return `${ym}-${String(d.getDate()).padStart(2, '0')}`; };
const dow = (d) => new Date(`${d}T00:00:00`).getDay(); // 0 Sunday

// The weeks of a month: [{ key: 'YYYY-MM-DD' (the first day), from, to, n }]
export function weeksOf(ym) {
  need(/^\d{4}-(0[1-9]|1[0-2])$/.test(String(ym || '')), 'Choose the month.');
  const out = []; let from = `${ym}-01`; const end = lastDay(ym); let n = 1;
  while (from <= end && n <= 7) {
    let to = from; let g = 0;
    while (dow(to) !== 0 && to < end && g++ < 7) to = addDays(to, 1);
    out.push({ key: from, from, to, n: n++ });
    from = addDays(to, 1);
  }
  return out;
}
export function weekOf(date) { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || ''))) return null; const ym = String(date).slice(0, 7); return weeksOf(ym).find((w) => date >= w.from && date <= w.to) || null; }
const info = (key) => getShared(`week_close_${key}`, null);
const carries = () => getShared('week_carry', {}) || {};
export function weeklyInUse() { return !!getShared('week_close_used', null); }

// What is still open in a week (each shop): days not checked, invoices to check (and invoices brought forward to it).
export function weekCheck(key) {
  const w = weekOf(key);
  need(w, 'Which week?');
  const ym = w.from.slice(0, 7);
  const SP = require('./shopPage.js');
  const carry = carries();
  const shops = SP.shopNames().map((s) => {
    let p = null;
    try { p = SP.shopMonth({ shop: s.code, ym }); } catch (e) { p = null; }
    const days = p ? p.sales.days.filter((d) => d.date >= w.from && d.date <= w.to && d.date <= dateStr()) : [];
    const invs = p ? p.purchases.list.filter((i) => ((i.invoice_date >= w.from && i.invoice_date <= w.to && !carry[i.uid]) || carry[i.uid] === w.key) && i.status === 'to_check') : [];
    return { code: s.code, name: s.name, daysToCheck: days.filter((d) => !d.checked).map((d) => d.date), invoicesToCheck: invs.map((i) => ({ uid: i.uid, supplier: i.supplier_name, no: i.invoice_no, total: i.total, date: i.invoice_date, carried: carry[i.uid] === w.key })) };
  });
  const daysOpen = shops.reduce((t, s) => t + s.daysToCheck.length, 0);
  const invOpen = shops.reduce((t, s) => t + s.invoicesToCheck.length, 0);
  const i = info(w.key);
  const ended = w.to < dateStr() || (w.to === dateStr() && new Date().getHours() >= 12) || dow(dateStr()) === 0 && w.to === dateStr();
  return { ...w, ym, shops, daysOpen, invOpen, ready: !daysOpen && !invOpen, closed: !!(i && i.at && !i.reopened), info: i, ended, next: addDays(w.to, 1) };
}
export function monthWeeks(ym) { return weeksOf(ym).map((w) => weekCheck(w.key)); }

// Close a week. Invoices still to check may be brought forward to the next week (carry: true); days must be checked.
export function closeWeek(user, key, { carry = false } = {}) {
  need(isBoss(user) || require('../../services/access.js').can(user, 'verify_money'), 'Only the owner, admin or the person checking the money can close a week.');
  const c = weekCheck(key);
  need(!c.closed, `The week ${c.from} – ${c.to} is already closed.`);
  need(c.to <= dateStr(), 'The week has not ended yet (close it on its last day, Sunday, or after).');
  need(!c.daysOpen, `${c.daysOpen} day${c.daysOpen === 1 ? '' : 's'} of sales still to check: ${c.shops.filter((s) => s.daysToCheck.length).map((s) => `${s.name} ${s.daysToCheck.join(', ')}`).join('; ')}.`);
  const open = [].concat(...c.shops.map((s) => s.invoicesToCheck));
  need(!open.length || carry, `${open.length} supplier invoice${open.length === 1 ? '' : 's'} still to check – check them, or bring them forward to next week.`);
  let moved = [];
  if (open.length) {
    const next = weekOf(c.next);
    need(next, 'The next week is in the next month – check these invoices first: an invoice cannot be brought forward into another month (VAT).');
    const m = carries();
    open.forEach((i) => { m[i.uid] = next.key; });
    setShared('week_carry', m);
    moved = open.map((i) => i.uid);
  }
  setShared(`week_close_${c.key}`, { by: user.name, at: stamp(), carried: moved });
  if (!weeklyInUse()) setShared('week_close_used', { since: c.key, by: user.name });
  audit({ user, action: `Week ${c.from} – ${c.to} closed${moved.length ? ` (${moved.length} invoice${moved.length === 1 ? '' : 's'} brought forward to next week)` : ''}`, table: 'shared_settings', recordUid: `week_close_${c.key}` });
  return weekCheck(key);
}
export function reopenWeek(user, key, reason) {
  need(isBoss(user), 'Only the owner or admin can reopen a week.');
  need(String(reason || '').trim().length >= 3, 'Say why the week is reopened.');
  const c = weekCheck(key);
  need(c.closed, 'This week is not closed.');
  setShared(`week_close_${c.key}`, { ...c.info, reopened: { by: user.name, at: stamp(), reason: String(reason).trim() } });
  audit({ user, action: `Week ${c.from} – ${c.to} reopened`, table: 'shared_settings', recordUid: `week_close_${c.key}`, reason: String(reason).trim() });
  return weekCheck(key);
}
// For the month close list.
export function monthWeeksItem(ym) {
  if (!weeklyInUse()) return null;
  const ws = monthWeeks(ym).filter((w) => w.from <= dateStr());
  const open = ws.filter((w) => !w.closed);
  return { key: 'weeks_closed', label: 'Every week of the month closed', sub: open.length ? `Not closed: ${open.map((w) => `${w.from.slice(8)}–${w.to.slice(8)}`).join(', ')}` : null, left: open.length, done: !open.length };
}
