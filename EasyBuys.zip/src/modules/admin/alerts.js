// Warnings for Home from the app itself: a new version to install, health check problems, safety copies.
import { can } from '../../services/access.js';
import { getSetting } from '../../services/core.js';
import { healthIssues } from '../../services/health.js';
import { snapshotAgeHours } from '../../services/snapshots.js';
import { isTraining } from '../../services/trainingFlag.js';

export function alerts(user) {
  const out = [];
  const admin = can(user, 'settings');
  if (admin) {
    let upd = null;
    try { upd = require('../../platform/updates.js').updateAvailable(); } catch (e) { upd = null; }
    if (upd) out.push({ id: `update-${upd.version}`, level: 'info', text: `App version ${upd.version} is ready to install`, nav: { screen: 'Updates', params: {} } });
  }
  // Health check: the owner / admin see every problem; everyone else only the ones they can act on (sync).
  for (const h of healthIssues()) {
    if (!admin && !(h.nav && h.nav.screen === 'SyncStatus')) continue;
    out.push({ id: `health-${h.kind}-${h.id}`, level: h.status === 'damaged' ? 'urgent' : 'warning', text: `Health check: ${h.text}`, nav: h.nav || { screen: 'HealthCheck', params: {} } });
  }
  if (admin && !isTraining()) {
    const age = snapshotAgeHours();
    if (age !== null && age > 48 && !healthIssues().some((h) => h.id === 'copies')) out.push({ id: 'snapshot-old', level: 'warning', text: `The last safety copy is ${Math.floor(age / 24)} days old`, nav: { screen: 'Backup', params: {} } });
    if (!getSetting('outside_folder_uri', '')) out.push({ id: 'outside-folder', level: 'info', text: 'Choose a folder outside the app for the daily safety copy', sub: 'So the data is safe even if the app is removed.', nav: { screen: 'Backup', params: {} } });
  }
  return out;
}
