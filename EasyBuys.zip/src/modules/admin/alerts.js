// Warnings for Home from the app itself: a new version to install, health check problems, safety copies.
import { can } from '../../services/access.js';
import { getSetting } from '../../services/core.js';
import { healthIssues } from '../../services/health.js';
import { snapshotAgeHours } from '../../services/snapshots.js';
import { isTraining } from '../../services/trainingFlag.js';
import { emailAsks } from '../../services/emailPrefs.js';
import { watchdogSummary } from '../../services/watchdog.js';
import { listQueries } from '../../services/queries.js';
import { actsAsOwner } from '../../services/access.js';

const dateKey = () => new Date().toISOString().slice(0, 10);
export function alerts(user) {
  const out = [];
  const admin = can(user, 'settings');
  if (admin) {
    let upd = null;
    try { upd = require('../../platform/updates.js').updateAvailable(); } catch (e) { upd = null; }
    if (upd) out.push({ id: `update-${upd.version}`, level: 'info', text: `App version ${upd.version} is ready to install`, nav: { screen: 'Updates', params: {} } });
  }
  // Health check: the owner / admin see every problem; everyone else only the ones they can act on (sync).
  for (const h of healthIssues()) {
    if (!admin && !(h.nav && h.nav.screen === 'SyncStatus')) continue;
    out.push({ id: `health-${h.kind}-${h.id}`, level: h.status === 'damaged' ? 'urgent' : 'warning', text: `Health check: ${h.text}`, nav: h.nav || { screen: 'HealthCheck', params: {} } });
  }
  if (admin && !isTraining()) {
    const age = snapshotAgeHours();
    if (age !== null && age > 48 && !healthIssues().some((h) => h.id === 'copies')) out.push({ id: 'snapshot-old', level: 'warning', text: `The last safety copy is ${Math.floor(age / 24)} days old`, nav: { screen: 'Backup', params: {} } });
    if (!getSetting('outside_folder_uri', '')) out.push({ id: 'outside-folder', level: 'info', text: 'Choose a folder outside the app for the daily safety copy', sub: 'So the data is safe even if the app is removed.', nav: { screen: 'Backup', params: {} } });
  }
  if (admin || actsAsOwner(user) || (user && user.role === 'manager')) {
    let w = null;
    try { w = watchdogSummary(user); } catch (e) { w = null; }
    if (w && w.total) out.push({ id: `watchdog-${dateKey()}-${w.total}`, level: w.urgent ? 'urgent' : 'warning', text: `Watchdog: ${w.total} thing${w.total === 1 ? '' : 's'} to look at`, sub: w.list.slice(0, 2).map((x) => x.text).join(' · '), nav: { screen: 'Watchdog', params: {} } });
    else if (w && !w.on && actsAsOwner(user)) out.push({ id: 'watchdog-off', level: 'info', text: 'Watchdog off', sub: 'Turn it on in Admin › Watchdog settings.', nav: { screen: 'WatchdogSettings', params: {} } });
  }
  if (admin || actsAsOwner(user)) {
    const open = listQueries({ status: 'open' });
    if (open.length) out.push({ id: `queries-${open[0].uid}`, level: 'warning', text: `${open.length} question${open.length === 1 ? '' : 's'} from the accountant`, sub: open[0].text.slice(0, 80), nav: { screen: 'Queries', params: {} } });
  }
  if (admin) {
    let asks = [];
    try { asks = emailAsks(); } catch (e) { asks = []; }
    if (asks.length) out.push({ id: `email-asks-${asks[asks.length - 1].id}`, level: 'info', text: `${asks.length} email${asks.length === 1 ? '' : 's'} to send? (${asks[0].title})`, sub: 'Tap to send them or say Not now.', nav: { screen: 'Emails', params: {} } });
  }
  return out;
}
