// Warnings for Home from the app itself: a new version to install, health check problems, safety copies.
import { can } from '../../services/access.js';
import { getSetting } from '../../services/core.js';
import { healthIssues } from '../../services/health.js';
import { snapshotAgeHours } from '../../services/snapshots.js';
import { isTraining } from '../../services/trainingFlag.js';
import { emailAsks } from '../../services/emailPrefs.js';
import { watchdogSummary } from '../../services/watchdog.js';
import { listQueries } from '../../services/queries.js';
import { actsAsOwner } from '../../services/access.js';

const dateKey = () => new Date().toISOString().slice(0, 10);
export function alerts(user) {
  const out = [];
  const admin = can(user, 'settings');
  // v3.9.3 until the business has gone live: how far moving in has got, and the next step.
  if (user && ['owner', 'admin'].includes(user.role) && !isTraining()) {
    try {
      const { getShared } = require('../../services/core.js');
      const M = require('../../services/migration.js');
      // Sample logins still working once a real owner / admin exists: a way in for anyone who knows "1111".
      const { db: d2 } = require('../../db/connection.js');
      const samples = d2().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND sync_status = 'seed'").n;
      const real = d2().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin') AND COALESCE(sync_status,'') <> 'seed'").n;
      if (samples && real) out.push({ id: 'adm-samples-on', level: 'warning', text: `${samples} sample login(s) (Admin 1111…) still work on this device`, sub: 'Turn them off: Admin › Moving in & go-live › Sample logins.', nav: { screen: 'GoLive', params: {} } });
      if (!(getShared('go_live', {}) || {}).liveFrom) {
        const ms = M.migrationStatus(); const left = ms.filter((x) => !x.done);
        if (left.length) out.push({ id: `adm-movein-${left.length}`, level: 'info', text: `Moving in: ${ms.length - left.length} of ${ms.length} set-up steps done`, sub: `Next: ${left[0].title}`, nav: { screen: 'GoLive', params: {} } });
      }
    } catch (e) { /* never stops Home */ }
  }
  // v3.9.2 one forgotten PIN must never lock the business out of Admin: keep at least two owner / admin logins.
  if (user && ['owner', 'admin'].includes(user.role) && !isTraining()) {
    try {
      const { db } = require('../../db/connection.js');
      const n = db().get("SELECT COUNT(*) AS c FROM users WHERE role IN ('owner','admin') AND active = 1 AND COALESCE(sync_status, '') <> 'seed'").c;
      if (n < 2) out.push({ id: 'one-admin', level: 'warning', text: 'Only one owner / admin login – add a second one', sub: 'If that PIN is forgotten, nobody can open Admin. Staff › Users › add a trusted person as Admin (e.g. Divnesh).', nav: { screen: 'Users', params: {} } });
    } catch (e) { /* users not readable */ }
  }
  if (admin) {
    let upd = null;
    try { upd = require('../../platform/updates.js').updateAvailable(); } catch (e) { upd = null; }
    if (upd) out.push({ id: `update-${upd.version}`, level: 'info', text: `App version ${upd.version} is ready to install`, nav: { screen: 'Updates', params: {} } });
  }
  // Health check: the owner / admin see every problem; everyone else only the ones they can act on (sync).
  for (const h of healthIssues()) {
    if (!admin && !(h.nav && h.nav.screen === 'SyncStatus')) continue;
    out.push({ id: `health-${h.kind}-${h.id}`, level: h.status === 'damaged' ? 'urgent' : 'warning', text: `Health check: ${h.text}`, nav: h.nav || { screen: 'HealthCheck', params: {} } });
  }
  if (admin && !isTraining()) {
    const age = snapshotAgeHours();
    if (age !== null && age > 48 && !healthIssues().some((h) => h.id === 'copies')) out.push({ id: 'snapshot-old', level: 'warning', text: `The last safety copy is ${Math.floor(age / 24)} days old`, nav: { screen: 'Backup', params: {} } });
    if (!getSetting('outside_folder_uri', '')) out.push({ id: 'outside-folder', level: 'info', text: 'Choose a folder outside the app for the daily safety copy', sub: 'So the data is safe even if the app is removed.', nav: { screen: 'Backup', params: {} } });
  }
  if (admin || actsAsOwner(user) || (user && user.role === 'manager')) {
    let w = null;
    try { w = watchdogSummary(user); } catch (e) { w = null; }
    if (w && w.total) out.push({ id: `watchdog-${dateKey()}-${w.total}`, level: w.urgent ? 'urgent' : 'warning', text: `Watchdog: ${w.total} thing${w.total === 1 ? '' : 's'} to look at`, sub: w.list.slice(0, 2).map((x) => x.text).join(' · '), nav: { screen: 'Watchdog', params: {} } });
    else if (w && !w.on && actsAsOwner(user)) out.push({ id: 'watchdog-off', level: 'info', text: 'Watchdog off', sub: 'Turn it on in Admin › Watchdog settings.', nav: { screen: 'WatchdogSettings', params: {} } });
  }
  if (admin || actsAsOwner(user)) {
    const open = listQueries({ status: 'open' });
    if (open.length) out.push({ id: `queries-${open[0].uid}`, level: 'warning', text: `${open.length} question${open.length === 1 ? '' : 's'} from the accountant`, sub: open[0].text.slice(0, 80), nav: { screen: 'Queries', params: {} } });
  }
  if (admin) {
    let asks = [];
    try { asks = emailAsks(); } catch (e) { asks = []; }
    if (asks.length) out.push({ id: `email-asks-${asks[asks.length - 1].id}`, level: 'info', text: `${asks.length} email${asks.length === 1 ? '' : 's'} to send? (${asks[0].title})`, sub: 'Tap to send them or say Not now.', nav: { screen: 'Emails', params: {} } });
  }
  return out;
}
