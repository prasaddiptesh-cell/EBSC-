// Warnings for Home from the app itself: a new version to install, health check problems, safety copies.
import { can } from '../../services/access.js';
import { getSetting } from '../../services/core.js';
import { healthIssues } from '../../services/health.js';
import { snapshotAgeHours } from '../../services/snapshots.js';
import { isTraining } from '../../services/trainingFlag.js';
import { emailAsks } from '../../services/emailPrefs.js';
import { watchdogSummary, warmChecks, warmReturns, SLOW_CHECKS } from '../../services/watchdog.js';
import { listQueries } from '../../services/queries.js';
import { actsAsOwner } from '../../services/access.js';

const dateKey = () => new Date().toISOString().slice(0, 10);
// 1.0.0 the warnings in parts (the same list, in the same order): Home's background collection pauses between the
// parts (services/alerts.js collectAlertsAsync), so no one part holds the screen up for long.
function partSetup(user) {
  const out = [];
  const admin = can(user, 'settings');
  // v3.9.3 until the business has gone live: how far moving in has got, and the next step.
  if (user && ['owner', 'admin'].includes(user.role) && !isTraining()) {
    try {
      const { getShared } = require('../../services/core.js');
      const M = require('../../services/migration.js');
      // Sample logins still working once a real owner / admin exists: a way in for anyone who knows "1111".
      const { db: d2 } = require('../../db/connection.js');
      const samples = d2().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND sync_status = 'seed'").n;
      const real = d2().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin') AND COALESCE(sync_status,'') <> 'seed'").n;
      if (samples && real) out.push({ id: 'adm-samples-on', level: 'warning', text: `${samples} sample login(s) (Admin 1111…) still work on this device`, sub: 'Turn them off: Admin › Moving in & go-live › Sample logins.', nav: { screen: 'GoLive', params: {} } });
      // v3.9.7 the fresh start date, and the open items from before it still to go through.
      const G = require('../../services/goLive.js');
      let inSetup = false; try { inSetup = require('../../services/setupWizard.js').holdAutomatic(); } catch (e) { inSetup = false; }
      if (!G.freshFrom() && !inSetup) out.push({ id: 'adm-fresh-date', level: 'warning', text: 'Set the fresh start date (go-live)', sub: 'Anything earlier becomes history only – no old till warnings.', nav: { screen: 'GoLive', params: {} } });
      else { const b = G.beforeGoLiveSummary(); if (b.open) out.push({ id: `adm-beforelive-${b.open}`, level: 'info', text: `Before go-live: ${b.open} open item${b.open === 1 ? '' : 's'} to review`, sub: 'Unpaid invoices, cheques and other items from before the fresh start date.', nav: { screen: 'BeforeGoLive', params: {} } }); }
      if (!(getShared('go_live', {}) || {}).liveFrom) {
        const ms = M.migrationStatus(); const left = ms.filter((x) => !x.done);
        if (left.length) {
          // v3.9.8 the step-by-step set-up: Home shows the one step to do now.
          let w = null; try { w = require('../../services/setupWizard.js').wizardSummary(); } catch (e) { w = null; }
          if (w && w.current) out.push({ id: `adm-setup-${w.current.key}-${w.done}`, level: 'warning', text: `Set-up – step ${w.current.no} of ${w.total}: ${w.current.title}`, sub: `${w.done} of ${w.total} done${w.later ? ` · ${w.later} left for later` : ''}. One step at a time – tap to carry on.`, nav: { screen: 'SetupWizard', params: {} } });
          else out.push({ id: `adm-movein-${left.length}`, level: 'info', text: `Moving in: ${ms.length - left.length} of ${ms.length} set-up steps done`, sub: `Next: ${left[0].title}`, nav: { screen: 'GoLive', params: {} } });
        }
      }
    } catch (e) { /* never stops Home */ }
  }
  // v3.9.4 a till PC that has gone quiet (the Aronium link): nothing for 6 hours.
  if (user && (can(user, 'settings') || can(user, 'till_approve')) && !isTraining()) {
    try {
      const L = require('../aronium/link.js');
      for (const t of L.linkStatus().tills) {
        const at = new Date(/Z$/.test(String(t.lastSeen)) ? t.lastSeen : `${String(t.lastSeen).replace(' ', 'T').slice(0, 19)}Z`).getTime();
        const hours = (Date.now() - at) / 3600000;
        if (Number.isFinite(hours) && hours > 6) out.push({ id: `adm-link-quiet-${t.source}`, level: 'warning', text: `${t.till || t.source}: no figures from Aronium for ${hours > 48 ? `${Math.round(hours / 24)} days` : `${Math.round(hours)} hours`}`, sub: 'Check the till PC is on and online, and the Aronium Link program is set to send on its own.', nav: { screen: 'AroniumLink', params: {} } });
      }
    } catch (e) { /* never stops Home */ }
  }
  return out;
}
function partClose(user) {
  const out = [];
  const admin = can(user, 'settings');
  // v3.9.8 the month close: last month to reconcile and close (owner / admin), louder after the close-by day.
  if (user && !isTraining()) { try { out.push(...require('../accounting/service.js').closeAlerts(user)); } catch (e) { /* never stops Home */ } }
  return out;
}
function partApp(user) {
  const out = [];
  const admin = can(user, 'settings');
  // v3.9.8 power and water bills: overdue, due soon, EFL to check this month, water check not working.
  if (user && !isTraining()) { try { out.push(...require('../../services/utilityBills.js').billAlerts(user)); } catch (e) { /* never stops Home */ } }
  // v3.9.2 one forgotten PIN must never lock the business out of Admin: keep at least two owner / admin logins.
  if (user && ['owner', 'admin'].includes(user.role) && !isTraining()) {
    try {
      const { db } = require('../../db/connection.js');
      const n = db().get("SELECT COUNT(*) AS c FROM users WHERE role IN ('owner','admin') AND active = 1 AND COALESCE(sync_status, '') <> 'seed'").c;
      if (n < 2) out.push({ id: 'one-admin', level: 'warning', text: 'Only one owner / admin login – add a second one', sub: 'If that PIN is forgotten, nobody can open Admin. Staff › Users › add a trusted person as Admin (e.g. Divnesh).', nav: { screen: 'Users', params: {} } });
    } catch (e) { /* users not readable */ }
  }
  // 1.0.0 the update downloaded by itself: anyone on this device can install it (two taps); not yet downloaded: admin
  {
    let ready = null; let upd = null;
    try { const U = require('../../platform/updates.js'); ready = U.readyUpdate(); upd = ready ? null : U.updateAvailable(); } catch (e) { ready = null; upd = null; }
    if (ready) out.push({ id: `update-ready-${ready.build || ready.version}`, level: 'info', notify: true, text: 'App update ready – tap to install', sub: 'Tap Install, then Update on Android\'s screen. Everything you have entered stays.', nav: { screen: 'Updates', params: {} } });
    else if (upd && admin) out.push({ id: `update-${upd.build || upd.version}`, level: 'info', text: `A newer app (build ${upd.build || upd.version}) is out – it downloads by itself`, nav: { screen: 'Updates', params: {} } });
  }
  // Health check: the owner / admin see every problem; everyone else only the ones they can act on (sync).
  for (const h of healthIssues()) {
    if (!admin && !(h.nav && h.nav.screen === 'SyncStatus')) continue;
    out.push({ id: `health-${h.kind}-${h.id}`, level: h.status === 'damaged' ? 'urgent' : 'warning', text: `Health check: ${h.text}`, nav: h.nav || { screen: 'HealthCheck', params: {} } });
  }
  if (admin && !isTraining()) {
    const age = snapshotAgeHours();
    if (age !== null && age > 48 && !healthIssues().some((h) => h.id === 'copies')) out.push({ id: 'snapshot-old', level: 'warning', text: `The last safety copy is ${Math.floor(age / 24)} days old`, nav: { screen: 'Backup', params: {} } });
    if (!getSetting('outside_folder_uri', '')) out.push({ id: 'outside-folder', level: 'info', text: 'Choose a folder outside the app for the daily safety copy', sub: 'So the data is safe even if the app is removed.', nav: { screen: 'Backup', params: {} } });
  }
  return out;
}
function partWatchdog(user) {
  const out = [];
  const admin = can(user, 'settings');
  if (admin || actsAsOwner(user) || (user && user.role === 'manager')) {
    let w = null;
    try { w = watchdogSummary(user); } catch (e) { w = null; }
    if (w && w.total) out.push({ id: `watchdog-${dateKey()}-${w.total}`, level: w.urgent ? 'urgent' : 'warning', text: `Watchdog: ${w.total} thing${w.total === 1 ? '' : 's'} to look at`, sub: w.list.slice(0, 2).map((x) => x.text).join(' · '), nav: { screen: 'Watchdog', params: {} } });
    else if (w && !w.on && actsAsOwner(user)) out.push({ id: 'watchdog-off', level: 'info', text: 'Watchdog off', sub: 'Turn it on in Admin › Watchdog settings.', nav: { screen: 'WatchdogSettings', params: {} } });
  }
  return out;
}
function partQueries(user) {
  const out = [];
  const admin = can(user, 'settings');
  if (admin || actsAsOwner(user)) {
    const open = listQueries({ status: 'open' });
    if (open.length) out.push({ id: `queries-${open[0].uid}`, level: 'warning', text: `${open.length} question${open.length === 1 ? '' : 's'} from the accountant`, sub: open[0].text.slice(0, 80), nav: { screen: 'Queries', params: {} } });
  }
  if (admin) {
    let asks = [];
    try { asks = emailAsks(); } catch (e) { asks = []; }
    if (asks.length) out.push({ id: `email-asks-${asks[asks.length - 1].id}`, level: 'info', text: `${asks.length} email${asks.length === 1 ? '' : 's'} to send? (${asks[0].title})`, sub: 'Tap to send them or say Not now.', nav: { screen: 'Emails', params: {} } });
  }
  return out;
}
// the watchdog's slow checks worked out ahead, one part each (they give nothing themselves; partWatchdog uses them)
const warm = (ids) => { const f = (user) => ((can(user, 'settings') || actsAsOwner(user) || (user && user.role === 'manager')) ? warmChecks(ids) : []); return f; };
const warmRet = (i, n) => (user) => ((can(user, 'settings') || actsAsOwner(user) || (user && user.role === 'manager')) ? warmReturns(i, n) : []);
const warmClosePart = (name) => (user) => { if (!user || isTraining()) return []; try { return require('../accounting/service.js').warmClose(name, user); } catch (e) { return []; } };
const warmDay = (i) => (user) => ((can(user, 'settings') || actsAsOwner(user) || (user && user.role === 'manager')) && !isTraining() ? require('../till/salesWatch.js').warmAfterHours(i) : []);
const PARTS = [partSetup, ...['susp', 'bank', 'report', 'tax'].map(warmClosePart), partClose, partApp, warmRet(0, 4), warmRet(1, 4), warmRet(2, 4), warmRet(3, 4), ...[0, 1, 2, 3, 4, 5, 6].map(warmDay), ...SLOW_CHECKS.map(warm), partWatchdog, partQueries];
export function alerts(user) {
  const out = [];
  for (const p of PARTS) out.push(...p(user));
  return out;
}
alerts.parts = PARTS;
