// Admin module: roles, shops, modules on/off, this device, change history.
import { AdminHubScreen, RolesScreen, ShopsScreen, ModulesScreen, DeviceScreen, AuditScreen } from './screens/AdminScreens.js';
import { BackupScreen, HealthCheckScreen, AlertSoundsScreen } from './screens/ShellScreens.js';
import { AboutScreen } from './screens/AboutScreen.js';
import { ReportTemplatesScreen } from './screens/ReportTemplatesScreen.js';
import { ProblemsScreen } from './screens/ProblemsScreen.js';
import { TrainingScreen } from './screens/TrainingScreen.js';
import { UpdatesScreen } from './screens/UpdatesScreen.js';
import { StartFreshScreen, GoLiveScreen } from './screens/GoLiveScreens.js';
import { EmailsScreen } from './screens/EmailsScreen.js';
import { QueriesScreen } from './screens/QueriesScreen.js';
import { WatchdogScreen, WatchdogSettingsScreen } from './screens/WatchdogScreens.js';
import { DocumentsScreen, DocInfoScreen, DocCheckScreen, DocDesignerScreen, DocSettingsScreen } from './screens/DocumentScreens.js';
import { TutorialsScreen, TutorialQuizScreen, TrainingProgressScreen } from './screens/TutorialScreens.js';
import { can, actsAsOwner } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'admin',
  title: 'Admin',
  icon: '⚙️',
  screens: {
    Admin: { component: AdminHubScreen, can: (u) => can(u, 'settings') || can(u, 'staff_manage') || can(u, 'roles') },
    Roles: { component: RolesScreen, can: (u) => can(u, 'settings') },
    Shops: { component: ShopsScreen, can: (u) => can(u, 'settings') },
    Modules: { component: ModulesScreen, can: (u) => can(u, 'settings') },
    Device: { component: DeviceScreen, can: (u) => can(u, 'settings') },
    Audit: { component: AuditScreen, can: (u) => can(u, 'audit_view') },
    Backup: { component: BackupScreen, can: (u) => can(u, 'settings') },
    ReportTemplates: { component: ReportTemplatesScreen, can: (u) => can(u, 'settings') },
    Problems: { component: ProblemsScreen, can: (u) => can(u, 'settings') },
    Training: { component: TrainingScreen, can: (u) => can(u, 'settings') },
    Updates: { component: UpdatesScreen, can: (u) => can(u, 'settings') },
    About: { component: AboutScreen, can: (u) => !!u },
    HealthCheck: { component: HealthCheckScreen, can: (u) => can(u, 'settings') },
    AlertSounds: { component: AlertSoundsScreen, can: (u) => !!u },
    Tutorials: { component: TutorialsScreen, can: (u) => !!u },
    TutorialQuiz: { component: TutorialQuizScreen, can: (u) => !!u },
    TrainingProgress: { component: TrainingProgressScreen, can: (u) => can(u, 'settings') },
    Documents: { component: DocumentsScreen, can: (u) => !!u && (can(u, 'settings') || can(u, 'reports') || can(u, 'invoices_enter')) },
    DocInfo: { component: DocInfoScreen, can: (u) => !!u },
    DocCheck: { component: DocCheckScreen, can: (u) => !!u },
    DocDesigner: { component: DocDesignerScreen, can: (u) => can(u, 'settings') },
    DocSettings: { component: DocSettingsScreen, can: (u) => can(u, 'settings') },
    Watchdog: { component: WatchdogScreen, can: (u) => !!u && (can(u, 'settings') || can(u, 'reports') || ['manager', 'owner', 'admin'].includes(u.role)) },
    WatchdogSettings: { component: WatchdogSettingsScreen, can: (u) => can(u, 'settings') },
    Queries: { component: QueriesScreen, can: (u) => !!u && (u.role === 'accountant' || can(u, 'settings') || can(u, 'accounts_view')) },
    Emails: { component: EmailsScreen, can: (u) => can(u, 'settings') },
    StartFresh: { component: StartFreshScreen, can: (u) => actsAsOwner(u) },
    GoLive: { component: GoLiveScreen, can: (u) => actsAsOwner(u) || can(u, 'settings') },
  },
  menu: MENU,
  alerts,
  reports: [],
};
