// Admin module: roles, shops, modules on/off, this device, change history.
import { StorageScreen } from './screens/StorageScreen.js';
import { ShopProfilesScreen, ShopProfileScreen, ShopEditScreen, ShopAccountScreen } from './screens/ShopProfileScreens.js';
import { DeleteRecordScreen, DeletedBinScreen } from './screens/BinScreens.js';
import { canSeeShop, canEditShop } from '../../services/shopProfile.js';
import { canDelete } from '../../services/bin.js';
import { PurchasesCheckScreen } from '../aronium/PurchasesCheckScreen.js';
import { AdminHubScreen, RolesScreen, ShopsScreen, ModulesScreen, DeviceScreen, AuditScreen } from './screens/AdminScreens.js';
import { BackupScreen, HealthCheckScreen, AlertSoundsScreen } from './screens/ShellScreens.js';
import { AboutScreen } from './screens/AboutScreen.js';
import { ReportTemplatesScreen } from './screens/ReportTemplatesScreen.js';
import { ProblemsScreen } from './screens/ProblemsScreen.js';
import { TrainingScreen } from './screens/TrainingScreen.js';
import { RecordFixScreen } from './screens/RecordFixScreen.js';
import { YearArchiveScreen } from './screens/YearArchiveScreen.js';
import { UpdatesScreen } from './screens/UpdatesScreen.js';
import { StartFreshScreen, GoLiveScreen } from './screens/GoLiveScreens.js';
import { EmailsScreen } from './screens/EmailsScreen.js';
import { QueriesScreen } from './screens/QueriesScreen.js';
import { WatchdogScreen, WatchdogSettingsScreen } from './screens/WatchdogScreens.js';
import { DocumentsScreen, DocInfoScreen, DocCheckScreen, DocDesignerScreen, DocSettingsScreen } from './screens/DocumentScreens.js';
import { TutorialsScreen, TutorialQuizScreen, TrainingProgressScreen } from './screens/TutorialScreens.js';
import { can, actsAsOwner } from '../../services/access.js';
import { MENU } from './menu.js';
import { AroniumLinkScreen } from '../aronium/AroniumLinkScreen.js';
import { InsightsScreen } from '../aronium/InsightsScreen.js';
import { OnlineDashboardScreen } from './screens/OnlineDashboardScreen.js';
import { alerts } from './alerts.js';

// v3.9.5 Settings opens for anyone who may change at least one setting (e.g. a stock manager: inventory settings).
let inSettingCheck = false;
const settingMemo = new Map();
function hasSomeSetting(u) {
  if (!u || inSettingCheck) return false;
  const key = `${u.uid}|${u.role}`;
  const hit = settingMemo.get(key);
  if (hit && Date.now() - hit.at < 20000) return hit.v;
  inSettingCheck = true;
  let v = false;
  try {
    const R = require('../registry.js');
    const M = require('../../services/menus.js');
    const screens = R.allScreens();
    v = R.menuModules().some((m) => M.visibleMenu(m, u, screens).some((sec) => sec.section === 'Settings' && sec.items.some((it) => it.screen !== 'Admin')));
  } catch (e) { v = false; } finally { inSettingCheck = false; }
  settingMemo.set(key, { at: Date.now(), v });
  return v;
}

export default {
  id: 'admin',
  title: 'Admin',
  icon: '⚙️',
  screens: {
    Storage: { component: StorageScreen, can: (u) => can(u, 'settings') },
    ShopProfiles: { component: ShopProfilesScreen, can: (u) => canSeeShop(u) },
    ShopProfile: { component: ShopProfileScreen, can: (u) => canSeeShop(u) },
    ShopEdit: { component: ShopEditScreen, can: (u) => canEditShop(u) },
    ShopAccount: { component: ShopAccountScreen, can: (u) => canEditShop(u) },
    DeleteRecord: { component: DeleteRecordScreen, can: (u) => canDelete(u) },
    DeletedBin: { component: DeletedBinScreen, can: (u) => canDelete(u) },
    Admin: { component: AdminHubScreen, can: (u) => can(u, 'settings') || can(u, 'staff_manage') || can(u, 'roles') || hasSomeSetting(u) },
    Roles: { component: RolesScreen, can: (u) => can(u, 'settings') },
    Shops: { component: ShopsScreen, can: (u) => can(u, 'settings') },
    Modules: { component: ModulesScreen, can: (u) => can(u, 'settings') },
    Device: { component: DeviceScreen, can: (u) => can(u, 'settings') },
    Audit: { component: AuditScreen, can: (u) => can(u, 'audit_view') },
    Backup: { component: BackupScreen, can: (u) => can(u, 'settings') },
    ReportTemplates: { component: ReportTemplatesScreen, can: (u) => can(u, 'settings') },
    Problems: { component: ProblemsScreen, can: (u) => can(u, 'settings') },
    Training: { component: TrainingScreen, can: (u) => can(u, 'settings') },
    Updates: { component: UpdatesScreen, can: (u) => can(u, 'settings') },
    About: { component: AboutScreen, can: (u) => !!u },
    HealthCheck: { component: HealthCheckScreen, can: (u) => can(u, 'settings') },
    AlertSounds: { component: AlertSoundsScreen, can: (u) => !!u },
    Tutorials: { component: TutorialsScreen, can: (u) => !!u },
    TutorialQuiz: { component: TutorialQuizScreen, can: (u) => !!u },
    TrainingProgress: { component: TrainingProgressScreen, can: (u) => can(u, 'settings') },
    Documents: { component: DocumentsScreen, can: (u) => !!u && (can(u, 'settings') || can(u, 'reports') || can(u, 'invoices_enter')) },
    DocInfo: { component: DocInfoScreen, can: (u) => !!u },
    DocCheck: { component: DocCheckScreen, can: (u) => !!u },
    DocDesigner: { component: DocDesignerScreen, can: (u) => can(u, 'settings') },
    DocSettings: { component: DocSettingsScreen, can: (u) => can(u, 'settings') },
    YearArchive: { component: YearArchiveScreen, can: (u) => !!u && (actsAsOwner(u) || u.role === 'owner') },
    RecordFix: { component: RecordFixScreen, can: (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role)) },
    Watchdog: { component: WatchdogScreen, can: (u) => !!u && (can(u, 'settings') || can(u, 'reports') || ['manager', 'owner', 'admin'].includes(u.role)) },
    WatchdogSettings: { component: WatchdogSettingsScreen, can: (u) => can(u, 'settings') },
    Queries: { component: QueriesScreen, can: (u) => !!u && (u.role === 'accountant' || can(u, 'settings') || can(u, 'accounts_view')) },
    Emails: { component: EmailsScreen, can: (u) => can(u, 'settings') },
    StartFresh: { component: StartFreshScreen, can: (u) => actsAsOwner(u) },
    GoLive: { component: GoLiveScreen, can: (u) => actsAsOwner(u) || can(u, 'settings') },
    OnlineDashboard: { component: OnlineDashboardScreen, can: (u) => !!u && ['owner', 'admin'].includes(u.role) },
    AroniumLink: { component: AroniumLinkScreen, can: (u) => actsAsOwner(u) || can(u, 'settings') || can(u, 'till_approve') },
    ArPurchases: { component: PurchasesCheckScreen, can: (u) => actsAsOwner(u) || can(u, 'invoices_check') || can(u, 'inventory_manage') || can(u, 'ap_setup') },
    AroniumInsights: { component: InsightsScreen, can: (u) => actsAsOwner(u) || can(u, 'settings') || can(u, 'till_approve') },
  },
  menu: MENU,
  alerts,
  reports: [],
};
