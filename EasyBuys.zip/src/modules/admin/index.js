// Admin module: roles, shops, modules on/off, this device, change history.
import { AdminHubScreen, RolesScreen, ShopsScreen, ModulesScreen, DeviceScreen, AuditScreen, BackupScreen } from './screens/AdminScreens.js';
import { ReportTemplatesScreen } from './screens/ReportTemplatesScreen.js';
import { ProblemsScreen } from './screens/ProblemsScreen.js';
import { TrainingScreen } from './screens/TrainingScreen.js';
import { UpdatesScreen } from './screens/UpdatesScreen.js';
import { can } from '../../services/access.js';

export default {
  id: 'admin',
  title: 'Admin',
  icon: '⚙️',
  screens: {
    Admin: { component: AdminHubScreen, can: (u) => can(u, 'settings') || can(u, 'staff_manage') || can(u, 'roles') },
    Roles: { component: RolesScreen, can: (u) => can(u, 'settings') },
    Shops: { component: ShopsScreen, can: (u) => can(u, 'settings') },
    Modules: { component: ModulesScreen, can: (u) => can(u, 'settings') },
    Device: { component: DeviceScreen, can: (u) => can(u, 'settings') },
    Audit: { component: AuditScreen, can: (u) => can(u, 'audit_view') },
    Backup: { component: BackupScreen, can: (u) => can(u, 'settings') },
    ReportTemplates: { component: ReportTemplatesScreen, can: (u) => can(u, 'settings') },
    Problems: { component: ProblemsScreen, can: (u) => can(u, 'settings') },
    Training: { component: TrainingScreen, can: (u) => can(u, 'settings') },
    Updates: { component: UpdatesScreen, can: (u) => can(u, 'settings') },
  },
  reports: [],
};
