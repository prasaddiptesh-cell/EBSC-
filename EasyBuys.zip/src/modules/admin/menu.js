// Admin's own items (the Admin & settings hub also lists every module's settings, grouped by business area).
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '⚙️', title: 'Admin & settings', note: 'Every setting, grouped by business area.', screen: 'Admin' },
    { id: 'adm-sync', icon: '⟳', title: 'Sync', note: 'Sync now and what is waiting.', screen: 'SyncStatus' },
  ] },
  { section: 'Records', items: [
    { id: 'adm-queries', icon: '❓', title: 'Accountant queries', note: 'Questions from the accountant, and the answers.', screen: 'Queries' },
    { id: 'adm-audit', icon: '🗂️', title: 'Change history', screen: 'Audit' },
    { id: 'adm-docs', icon: '📁', title: 'Documents', note: 'Everything filed in Google Drive – find, open, upload status.', screen: 'Documents' },
    { id: 'adm-backup', icon: '💾', title: 'Backup & restore', note: 'Every copy: tablet, outside folder, Google Drive.', screen: 'Backup' },
  ] },
  { section: 'Checks', items: [
    { id: 'adm-watchdog', icon: '🐕', title: 'Watchdog', note: 'What is missing, system health, possible tampering – with what to do.', screen: 'Watchdog' },
    { id: 'adm-health', icon: '🩺', title: 'Health check', note: 'Results and "Run full check now".', screen: 'HealthCheck' },
    { id: 'adm-problems', icon: '🧯', title: 'Problem log & screen check', screen: 'Problems' },
    { id: 'adm-doccheck', icon: '🔍', title: 'Check a document', note: 'Is a printed paper genuine? Scan its barcode.', screen: 'DocCheck' },
    { id: 'adm-warnings', icon: '⚠️', title: 'All warnings', screen: 'Warnings' },
  ] },
  { section: 'Settings', items: [
    { id: 'adm-sounds', icon: '🔔', title: 'Alerts & sounds', note: 'Sounds per type, quiet hours, this device.', screen: 'AlertSounds' },
    { id: 'adm-watchdog-set', icon: '🐕', title: 'Watchdog settings', note: 'On / off, how strict, each check.', screen: 'WatchdogSettings' },
    { id: 'adm-roles', icon: '🔐', title: 'Roles & permissions', screen: 'Roles' },
    { id: 'adm-shops', icon: '🏪', title: 'Shops & cost areas', screen: 'Shops' },
    { id: 'adm-modules', icon: '🧩', title: 'Modules on / off', screen: 'Modules' },
    { id: 'adm-device', icon: '📱', title: 'This device', screen: 'Device' },
    { id: 'adm-emails', icon: '✉️', title: 'Emails', note: 'Reports and orders: Off, Ask each time or Automatic.', screen: 'Emails' },
    { id: 'adm-templates', icon: '📄', title: 'Report layout', screen: 'ReportTemplates' },
    { id: 'adm-doclayout', icon: '🖨️', title: 'Document layout & paper', note: 'Parts, order, your own text, A4 or 80 mm, per kind of document.', screen: 'DocDesigner' },
    { id: 'adm-docsettings', icon: '🗄️', title: 'Documents & backups', note: 'Drive filing, tablet copies, nightly backup, who sees what.', screen: 'DocSettings' },
    { id: 'adm-training', icon: '🎓', title: 'Training mode', screen: 'Training' },
    { id: 'adm-tutorials', icon: '🧭', title: 'Tutorials', note: 'The app tour and each job step by step.', screen: 'Tutorials' },
    { id: 'adm-progress', icon: '📋', title: 'Training progress', note: 'Who has done which tutorial.', screen: 'TrainingProgress' },
    { id: 'adm-updates', icon: '⬆️', title: 'App updates', screen: 'Updates' },
    { id: 'adm-golive', icon: '🚀', title: 'Go-live checklist', note: 'Clear the test data, opening figures, then go live.', screen: 'GoLive' },
    { id: 'adm-fresh', icon: '🧹', title: 'Start fresh (owner)', note: 'Clear test data on every device and the cloud.', screen: 'StartFresh' },
    { id: 'adm-about', icon: 'ℹ️', title: 'About Easy Buys', screen: 'About' },
  ] },
];
