// Admin's own items (the Admin & settings hub also lists every module's settings, grouped by business area).
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '⚙️', title: 'Admin & settings', note: 'Every setting, grouped by business area.', screen: 'Admin' },
    { id: 'adm-sync', icon: '⟳', title: 'Sync', note: 'Sync now and what is waiting.', screen: 'SyncStatus' },
  ] },
  { section: 'Records', items: [
    { id: 'adm-audit', icon: '🗂️', title: 'Change history', screen: 'Audit' },
    { id: 'adm-backup', icon: '💾', title: 'Backup & restore', note: 'Every copy: tablet, outside folder, Google Drive.', screen: 'Backup' },
  ] },
  { section: 'Checks', items: [
    { id: 'adm-health', icon: '🩺', title: 'Health check', note: 'Results and "Run full check now".', screen: 'HealthCheck' },
    { id: 'adm-problems', icon: '🧯', title: 'Problem log & screen check', screen: 'Problems' },
    { id: 'adm-warnings', icon: '⚠️', title: 'All warnings', screen: 'Warnings' },
  ] },
  { section: 'Settings', items: [
    { id: 'adm-sounds', icon: '🔔', title: 'Alerts & sounds', note: 'Sounds per type, quiet hours, this device.', screen: 'AlertSounds' },
    { id: 'adm-roles', icon: '🔐', title: 'Roles & permissions', screen: 'Roles' },
    { id: 'adm-shops', icon: '🏪', title: 'Shops & cost areas', screen: 'Shops' },
    { id: 'adm-modules', icon: '🧩', title: 'Modules on / off', screen: 'Modules' },
    { id: 'adm-device', icon: '📱', title: 'This device', screen: 'Device' },
    { id: 'adm-templates', icon: '📄', title: 'Report layout', screen: 'ReportTemplates' },
    { id: 'adm-training', icon: '🎓', title: 'Training mode', screen: 'Training' },
    { id: 'adm-updates', icon: '⬆️', title: 'App updates', screen: 'Updates' },
    { id: 'adm-golive', icon: '🚀', title: 'Go-live checklist', note: 'Clear the test data, opening figures, then go live.', screen: 'GoLive' },
    { id: 'adm-fresh', icon: '🧹', title: 'Start fresh (owner)', note: 'Clear test data on every device and the cloud.', screen: 'StartFresh' },
    { id: 'adm-about', icon: 'ℹ️', title: 'About Easy Buys', screen: 'About' },
  ] },
];
