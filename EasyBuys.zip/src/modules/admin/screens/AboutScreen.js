// About Easy Buys (Admin › About, and ⓘ on the login screen): version, who built it, support, this device,
// technical details, what's new, updates and legal notices.
import React, { useEffect, useState } from 'react';
import { View, Image, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Row, Section, LOGO, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { APP_VERSION } from '../../../services/core.js';
import { can } from '../../../services/access.js';
import { reportTemplate } from '../../../services/reportTemplate.js';
import { APP_BUILD, RELEASE_DATE, BUILT_BY, SUPPORT, CONFIDENTIAL, WHATS_NEW, OPEN_SOURCE, copyrightLine, deviceFacts } from '../../../services/about.js';
import { storageUsed, freeDiskBytes, androidVersion, bytesText } from '../../../platform/device.js';
import { checkForUpdate, updateAvailable } from '../../../platform/updates.js';

const dash = (v) => (v ? String(v) : '—');

export function AboutScreen({ params = {}, standalone, onClose }) {
  const app = useApp();
  const ui = useUI();
  const user = app && app.user;
  const [page, setPage] = useState(params.page || 'about');
  const [store, setStore] = useState({ used: null, free: null });
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let live = true;
    Promise.all([storageUsed(), freeDiskBytes()]).then(([used, free]) => { if (live) setStore({ used, free }); }).catch(() => {});
    return () => { live = false; };
  }, []);
  const back = page !== 'about' ? () => setPage('about') : standalone ? onClose : undefined;
  const t = (() => { try { return reportTemplate(); } catch (e) { return {}; } })();
  const d = (() => { try { return deviceFacts(); } catch (e) { return {}; } })();

  if (page === 'new') {
    return (
      <Screen title="What's new" subtitle={`Easy Buys v${APP_VERSION}`} onBack={back} hideSync={standalone} hideUser={standalone}>
        {WHATS_NEW.map((v) => (
          <Card key={v.version}>
            <H>Version {v.version}{v.date ? ` · ${v.date}` : ''}</H>
            {v.items.map((x, i) => <Text key={i} style={{ fontSize: 16, color: C.text, lineHeight: 23, marginBottom: 6 }}>• {x}</Text>)}
          </Card>
        ))}
      </Screen>
    );
  }
  if (page === 'oss') {
    return (
      <Screen title="Open-source notices" subtitle="Libraries the app is built with" onBack={back} hideSync={standalone} hideUser={standalone}>
        <Hint>Easy Buys uses these free, open-source libraries. Their licences allow use in business apps; the full licence texts come with each library.</Hint>
        {OPEN_SOURCE.map((o) => (
          <Card key={o.name}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{o.name}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>Licence: {o.licence} · {o.use}</Text>
          </Card>
        ))}
      </Screen>
    );
  }

  const checkUpdates = async () => {
    if (user && can(user, 'settings') && app.nav) { app.nav.push('Updates'); return; }
    setBusy(true);
    try {
      const r = await checkForUpdate({ force: true });
      ui.alert({ title: r.off ? 'Updates not set up' : r.newer ? `Version ${r.info.version} is ready` : 'This is the newest version',
        message: r.off ? 'The admin sets where updates come from in Admin › App updates.' : r.newer ? 'Ask the admin to install it (Admin › App updates).' : `You have v${APP_VERSION}.` });
    } catch (e) { ui.alert({ title: 'Could not check', message: e.message || String(e), tone: 'warn' }); }
    setBusy(false);
  };
  const upd = (() => { try { return updateAvailable(); } catch (e) { return null; } })();
  return (
    <Screen title="About Easy Buys" subtitle={`Version ${APP_VERSION}`} onBack={back} hideSync={standalone} hideUser={standalone}>
      <Card>
        <View style={{ alignItems: 'center', gap: 6 }}>
          <Image testID="about-logo" source={LOGO} style={{ width: 240, height: 106 }} resizeMode="contain" />
          <Text testID="about-name" style={{ fontSize: 28, fontWeight: '900', color: C.text }}>Easy Buys</Text>
          <Text testID="about-version" style={{ fontSize: 18, fontWeight: '800', color: C.primary }}>{require('../../../services/about.js').versionLabel()}</Text>
          <Text style={{ fontSize: 15, color: C.sub }}>Released {RELEASE_DATE}</Text>
          <Text style={{ fontSize: 16, color: C.text, textAlign: 'center' }}>{BUILT_BY}</Text>
          <Text testID="about-copyright" style={{ fontSize: 15, color: C.sub, textAlign: 'center' }}>{copyrightLine()}</Text>
        </View>
      </Card>
      <Section title="Business">
        <Card>
          <Row label="Registered name" value={dash(t.businessName)} />
          <Row label="Address" value={dash(t.address)} />
          <Row label="TIN" value={dash(t.tin)} />
          <Row label="Phone" value={dash(t.phone)} />
          <Row label="Email" value={dash(t.email)} />
        </Card>
      </Section>
      <Section title="Admin & support">
        <Card>
          <Text testID="about-support" style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{SUPPORT.name}</Text>
          <Text style={{ fontSize: 17, color: C.text }}>{SUPPORT.phone} ({SUPPORT.phoneNote})</Text>
          <Text style={{ fontSize: 17, color: C.text }}>{SUPPORT.email}</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', marginTop: 10 }}>
            <Btn title="Call" icon="📞" size="sm" variant="secondary" onPress={() => Linking.openURL(`tel:${SUPPORT.phone.replace(/\s/g, '')}`).catch(() => {})} />
            <Btn title="Viber" icon="💬" size="sm" variant="secondary" onPress={() => Linking.openURL(`viber://chat?number=${encodeURIComponent(SUPPORT.phone.replace(/\s/g, ''))}`).catch(() => {})} />
            <Btn title="Email" icon="✉️" size="sm" variant="secondary" onPress={() => Linking.openURL(`mailto:${SUPPORT.email}?subject=${encodeURIComponent(`Easy Buys v${APP_VERSION}`)}`).catch(() => {})} />
          </View>
        </Card>
      </Section>
      <Section title="This device">
        <Card>
          <Row label="Name" value={dash(d.name)} />
          <Row label="Device ID" value={dash(d.id)} />
          <Row label="Shop" value={dash(d.shop) === '—' ? 'All shops' : d.shop} />
          <Row label="Linked to the cloud" value={d.linked ? 'Yes' : 'No'} />
          <Row label="Last sync" value={dash(d.lastSync)} />
          <Row label="Last backup (Google Drive)" value={dash(d.lastBackup)} />
          <Row label="Last safety copy (tablet)" value={dash(d.lastSnapshot)} />
          <Row label="Last health check" value={d.lastHealth ? `${d.lastHealth}${d.lastHealthStatus ? ` · ${d.lastHealthStatus}` : ''}` : '—'} />
          <Row label="Storage used by the app" value={bytesText(store.used)} />
          <Row label="Free storage" value={bytesText(store.free)} />
        </Card>
      </Section>
      <Section title="Technical details">
        <Card>
          <Row label="Database version" value={dash(d.dbVersion)} />
          <Row label="Android" value={dash(androidVersion())} />
          <Row label="Cloud script version" value={dash(d.cloudScript)} />
        </Card>
      </Section>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="about-new" title="What's new" icon="✨" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => setPage('new')} />
        <Btn testID="about-updates" title={busy ? 'Checking…' : upd ? `Update ${upd.version} ready` : 'Check for updates'} icon="⬆️" size="md" variant="secondary" style={{ flexGrow: 1 }} disabled={busy} onPress={checkUpdates} />
      </View>
      <Section title="Legal">
        <Card>
          <Text testID="about-legal" style={{ fontSize: 15, color: C.text, lineHeight: 22 }}>{CONFIDENTIAL}</Text>
          <Btn testID="about-oss" title="Open-source notices" icon="📄" size="sm" variant="secondary" style={{ marginTop: 10, alignSelf: 'flex-start' }} onPress={() => setPage('oss')} />
        </Card>
      </Section>
    </Screen>
  );
}
