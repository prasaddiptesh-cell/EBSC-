// Admin: the hub and its setup screens. Everything here is editable by the admin.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, NumberField, Row, Section, Tile, Grid, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { can, actsAsOwner, rolePerms, saveRolePerms, PERMS, ROLES, ROLE_LABEL, deviceSettings, saveDeviceSettings } from '../../../services/access.js';
import { listShops, saveShop, moduleOn, setModuleOn, SWITCHABLE, listAudit } from '../service.js';
import { clockRules, saveClockRules, faceSettings, saveFaceSettings } from '../../timeclock/rules.js';
import { deviceId, APP_VERSION, getSetting } from '../../../services/core.js';
import { Hint, Explain, Action, Actions } from '../../../ui/kit.js';
import { backupNow, restoreBackup } from '../../../platform/cloud.js';
import { pickTextFile } from '../../../platform/files.js';
import { updateAvailable } from '../../../platform/updates.js';

const useRun = () => {
  const ui = useUI();
  const [, set] = useState(0);
  return (fn, msg) => { try { fn(); ui.toast(msg || 'Saved'); set((n) => n + 1); return true; } catch (e) { ui.error(e); return false; } };
};

export function AdminHubScreen() {
  const { nav, user } = useApp();
  const a = (id, icon, title, note, screen, perm, params) => (can(user, perm) ? <Action key={id} testID={`admin-${id}`} icon={icon} title={title} note={note} onPress={() => nav.push(screen, params || {})} /> : null);
  const on = (m) => moduleOn(m);
  const sec = (title, items) => { const list = items.filter(Boolean); return list.length ? <Section key={title} title={title}><Actions>{list}</Actions></Section> : null; };
  return (
    <Screen title="Admin & settings" subtitle="Every setting, grouped by business area">
      <Hint>Settings are grouped by business area, in the same order as the Home screen. Every change is saved in the change history with who made it and when.</Hint>
      {sec('1. Finance & Accounting', [
        on('accounting') && a('coa', '📚', 'Chart of accounts & where things go', 'The accounts (IFRS order: 1 assets, 2 liabilities, 3 equity, 4 income, 5 cost of sales, 6 expenses, 8 tax) and booking rules.', 'ChartOfAccounts', 'accounts_setup'),
        on('accounting') && a('acctsettings', '⚙️', 'Accounting settings', 'Start date, tax year, advance tax, provisional tax.', 'AcctSettings', 'accounts_setup'),
        on('accounting') && a('opening', '🏁', 'Opening balances', 'The balances on the day the books start.', 'OpeningBalances', 'accounts_setup'),
        on('payables') && a('aprules', '🧾', 'Invoice rules', 'VAT rate, days to pay, checking, categories.', 'ApRules', 'ap_setup'),
        on('payables') && a('suppliers', '🏷️', 'Suppliers', 'Names, TIN, terms, how they are paid, contractors (provisional tax).', 'ApSuppliers', 'ap_setup'),
        on('payables') && a('recurring', '🔁', 'Regular bills & loans', 'Rent, power, loan repayments, loan balances and interest.', 'Recurring', 'ap_setup'),
        on('till') && a('till', '💵', 'Tills & cash rules', 'Tills and floats, payment types, shortages, petty cash.', 'TillSetup', 'till_approve'),
        on('bank') && a('bankrules', '🏦', 'Bank rules', 'Statement lines coded by themselves.', 'BankRules', 'bank_rec'),
      ])}
      {sec('2. Procurement & Inventory', [
        on('inventory') && a('inv', '📦', 'Inventory, orders & stock take', 'Supplier budgets, approvals, cost rules, stock-take rules.', 'InventorySetup', 'inventory_setup'),
      ])}
      {sec('3. Human Resources', [
        on('recruitment') && a('recruit', '🧑‍💼', 'Recruitment & onboarding', 'The onboarding checklist and probation length.', 'RecruitSetup', 'settings'),
        on('recruitment') && a('contractpdf', '📄', 'Company contract PDF', 'Your own contract, the director\'s signature and the company stamp.', 'ContractPdfSetup', 'settings'),
        on('timeclock') && a('clock', '⏱️', 'Time Clock', 'Breaks, rounding, face check, late tolerance.', 'ClockRules', 'settings'),
        on('timesheets') && a('roster', '📅', 'Roster', 'Quick shifts, asking why late, Google Calendar.', 'RosterSettings', 'settings'),
        on('timesheets') && a('usual', '🗓️', 'Usual weeks', 'Each person\'s normal days and times.', 'Roster', 'timesheets_edit'),
        on('leave') && a('leave', '🌴', 'Leave', 'Leave types, days per year, notice, medical certificates.', 'Leave', 'leave_setup', { tab: 'setup' }),
        on('payroll') && a('payrules', '💰', 'Payroll rules', 'Overtime, PAYE, FNPF, minimum wage, public holidays.', 'PayRules', 'payroll_setup'),
        on('payroll') && a('payprofiles', '🪪', 'Pay details', 'Rates, salaries, FNPF and TIN numbers, cash or bank.', 'PayProfiles', 'payroll_setup'),
        on('payroll') && a('stat', '🏦', 'FNPF & PAYE due dates', 'When the monthly payments are due.', 'Statutory', 'payroll_setup'),
      ])}
      {sec('4. Governance, Risk & Compliance', [
        a('verify', '✅', 'Verification & Viber alerts', 'Second person rule, late bank items, Viber group or channel, PDF after saving.', 'VerifySetup', 'verify_setup'),
        on('licences') && a('licences', '📜', 'Licences & permits', 'Every licence, permit and company record, with reminders before they expire.', 'Licences', 'licences_view'),
        a('audit', '🗂️', 'Change history (audit trail)', 'Who changed what, when, on which device, and why.', 'Audit', 'audit_view'),
      ])}
      {sec('5. Administration', [
        a('staff', '👥', 'Users (staff)', 'People, PINs, roles, shops, faces.', 'Users', 'staff_manage'),
        a('roles', '🔐', 'Roles & permissions', 'What each role may see and do (owner only).', 'Roles', 'roles'),
        a('shops', '🏪', 'Shops', 'Shop names and codes.', 'Shops', 'settings'),
        a('modules', '🧩', 'Modules on / off', 'Hide sections the business does not use.', 'Modules', 'settings'),
        a('templates', '📄', 'Report layout', 'Business name, address, TIN, footer, and the columns of each report – with a sample.', 'ReportTemplates', 'settings'),
      ])}
      {sec('6. Devices, cloud & backup', [
        a('devices', '📲', 'Devices', 'Add a tablet or phone; block a lost one (it locks at once when online).', 'Devices', 'settings'),
        a('device', '📱', 'This device', 'Tablet or phone, its name and shop, Time Clock here.', 'Device', 'settings'),
        a('cloud', '☁️', 'Online & email', 'The Easy Buys cloud link and report emails.', 'Settings', 'settings'),
        a('backup', '💾', 'Backup & restore', 'Everything is backed up to Google Drive every day. Back up now or restore.', 'Backup', 'settings'),
      ])}
      {sec('7. Help & support', [
        a('updates', '⬆️', 'App updates', updateAvailable() ? `Version ${updateAvailable().version} is ready to install.` : 'Check for a newer version and install it.', 'Updates', 'settings'),
        a('problems', '🩺', 'Problem log & screen check', 'Errors the app met, where, and a check of every screen. Send a report if something is not working.', 'Problems', 'settings'),
        a('training', '🎓', 'Training mode', 'A practice copy with sample shops, staff and figures. Real data is not touched.', 'Training', 'settings'),
      ])}
      <Text style={{ fontSize: 13, color: C.sub, textAlign: 'center' }}>Easy Buys app v{APP_VERSION} · device {deviceId()}</Text>
    </Screen>
  );
}

export function BackupScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [busy, setBusy] = useState('');
  const last = getSetting('last_backup_at', '');
  const now = async () => { setBusy('Backing up…'); const r = await backupNow(); setBusy(''); ui.alert({ title: r.ok ? 'Backed up' : 'Not backed up', message: r.message, tone: r.ok ? 'primary' : 'danger' }); };
  const restore = async () => {
    if (!actsAsOwner(user)) { ui.alert({ title: 'Owner only', message: 'Only the owner can restore a backup.', tone: 'danger' }); return; }
    try {
      const f = await pickTextFile();
      if (!f) return;
      const data = JSON.parse(f.text);
      if (!data || !data._meta) throw new Error('This is not an Easy Buys backup file.');
      const ok = await ui.confirm({ title: 'Restore this backup?', message: `${f.name}\nMade ${data._meta.made}.\n\nRecords in the backup replace the same records on this device and are sent to the cloud. Nothing else is deleted. Logins are not changed.`, confirmText: 'Restore', tone: 'danger' });
      if (!ok) return;
      const n = restoreBackup(data);
      ui.alert({ title: 'Restored', message: `${n} records put back. They will sync to the other devices.` });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Backup & restore" subtitle={last ? `Last backup ${last.slice(0, 16)}` : 'No backup from this device yet'}>
      <Explain title="How backups work">
        Every record is already copied to the Easy Buys cloud (Google) when the device is online. On top of that, once a day a full backup file of everything on this device
        is saved in your Google Drive, in the Easy Buys folder › Backups. If a tablet is lost or broken, link a new one and everything comes back from the cloud; the backup
        files are an extra copy kept for safety (and can be opened by your accountant or IT person).
      </Explain>
      <Btn testID="bk-now" title={busy || 'Back up now'} icon="💾" variant="success" disabled={!!busy} onPress={now} />
      <Btn testID="bk-restore" title="Restore from a backup file (owner)" icon="♻️" variant="secondary" onPress={restore} />
      <Hint>To restore: download the backup file from Google Drive to this tablet first, then choose it here.</Hint>
    </Screen>
  );
}

export function RolesScreen() {
  const { user } = useApp();
  const run = useRun();
  const [perms, setPerms] = useState(rolePerms());
  const owner = actsAsOwner(user);
  const toggle = (role, key) => {
    const has = perms[role].includes(key);
    setPerms({ ...perms, [role]: has ? perms[role].filter((k) => k !== key) : perms[role].concat([key]) });
  };
  const groups = Array.from(new Set(PERMS.map((p) => p.module)));
  return (
    <Screen title="Roles" subtitle="What each role may do" footer={owner ? <Btn testID="roles-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveRolePerms(user, perms))} /> : null}>
      {!owner ? <Banner tone="info" message="Only an Owner can change these." /> : null}
      {ROLES.filter((r) => r !== 'owner').map((r) => (
        <Card key={r}>
          <H>{ROLE_LABEL[r]}</H>
          {groups.map((g) => (
            <View key={g} style={{ marginBottom: 6 }}>
              <Label>{g}</Label>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {PERMS.filter((p) => p.module === g && p.key !== 'roles').map((p) => {
                  const on = perms[r].includes(p.key);
                  return <Btn key={p.key} testID={`perm-${r}-${p.key}`} title={`${on ? '✓ ' : ''}${p.label}`} size="sm" variant={on ? 'success' : 'secondary'} disabled={!owner} onPress={() => toggle(r, p.key)} />;
                })}
              </View>
            </View>
          ))}
        </Card>
      ))}
      <Banner tone="info" message="Owners can always do everything." />
    </Screen>
  );
}

export function ShopsScreen() {
  const { user } = useApp();
  const run = useRun();
  const shops = listShops({ includeInactive: true });
  const [n, setN] = useState({ code: '', name: '' });
  return (
    <Screen title="Shops" subtitle="Used by staff, Time Clock and reports">
      {shops.map((s) => <ShopRow key={s.code} s={s} user={user} run={run} />)}
      <Card>
        <H>Add a shop</H>
        <View style={{ gap: 10 }}>
          <Field label="Short code (e.g. S4)" value={n.code} onChangeText={(v) => setN({ ...n, code: v })} />
          <Field label="Name" value={n.name} onChangeText={(v) => setN({ ...n, name: v })} />
          <Btn title="Add shop" size="md" onPress={() => { if (run(() => saveShop(user, n), 'Shop added')) setN({ code: '', name: '' }); }} />
        </View>
      </Card>
    </Screen>
  );
}
function ShopRow({ s, user, run }) {
  const [name, setName] = useState(s.name);
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
        <Badge text={s.code} color={s.active ? C.info : C.sub} />
        <View style={{ flex: 1, minWidth: 180 }}><Field testID={`shop-name-${s.code}`} value={name} onChangeText={setName} /></View>
        <Btn testID={`shop-save-${s.code}`} title="Save" size="md" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !!s.active }))} />
        <Btn title={s.active ? 'Close' : 'Re-open'} size="md" variant="secondary" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !s.active }))} />
      </View>
    </Card>
  );
}

export function ClockRulesScreen() {
  const { user, nav } = useApp();
  const run = useRun();
  const [r, setR] = useState(clockRules());
  const [f, setF] = useState(faceSettings());
  const set = (k) => (v) => setR({ ...r, [k]: v });
  return (
    <Screen title="Time Clock rules" subtitle="Shared by every device"
      footer={<Btn testID="rules-save" title="Save all" icon="💾" variant="success" onPress={() => run(() => { saveClockRules(user, r); saveFaceSettings(user, f); })} />}>
      <Section title="Breaks">
        <Chips value={r.breakMode} onChange={set('breakMode')} testIDPrefix="break-mode"
          options={[{ value: 'buttons', label: 'Staff tap Break start / end' }, { value: 'auto', label: 'Take a fixed break off' }, { value: 'none', label: 'No breaks' }]} />
        {r.breakMode === 'auto' ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><NumberField label="Break minutes" value={r.autoBreakMinutes} onChange={set('autoBreakMinutes')} step={5} /></View>
            <View style={{ flex: 1 }}><NumberField label="…for shifts over (hours)" value={r.autoBreakAfterHours} onChange={set('autoBreakAfterHours')} /></View>
          </View>
        ) : null}
        {r.breakMode === 'buttons' ? <NumberField label="Warn if no break on shifts over (hours)" value={r.noBreakAfterHours} onChange={set('noBreakAfterHours')} /> : null}
      </Section>
      <Section title="Times">
        <Label>Round clock times to</Label>
        <Chips value={Number(r.roundMinutes)} onChange={set('roundMinutes')} testIDPrefix="round"
          options={[{ value: 0, label: 'Exact' }, { value: 5, label: '5 min' }, { value: 10, label: '10 min' }, { value: 15, label: '15 min' }]} />
        <NumberField label="Grace period for late (minutes)" value={r.graceMinutes} onChange={set('graceMinutes')} />
        <NumberField label="Longest possible shift (hours) – after this a missing Clock OUT is flagged" value={r.maxShiftHours} onChange={set('maxShiftHours')} />
        <NumberField label="Warn on shifts longer than (hours)" value={r.longShiftHours} onChange={set('longShiftHours')} />
        <NumberField label="Ignore a second tap within (minutes)" value={r.doubleTapMinutes} onChange={set('doubleTapMinutes')} />
        <Chips value={r.showAllShops ? 'all' : 'one'} onChange={(v) => setR({ ...r, showAllShops: v === 'all' })}
          options={[{ value: 'all', label: 'Tablet shows every shop' }, { value: 'one', label: 'Only this device\'s shop' }]} />
      </Section>
      <Section title="Face check">
        <Btn testID="face-test-open" title="Test the face check on this tablet" icon="🙂" size="md" variant="info" onPress={() => nav.push('FaceTest')} />
        <Chips value={f.mode} onChange={(v) => setF({ ...f, mode: v })} testIDPrefix="face-mode"
          options={[{ value: 'off', label: 'Off' }, { value: 'photo', label: 'Photo only' }, { value: 'flag', label: 'Check and flag' }, { value: 'block', label: 'Check and block' }]} />
        <Text style={{ fontSize: 15, color: C.sub }}>
          {{ off: 'No camera at the Time Clock.', photo: 'A photo is kept with every punch. No matching.', flag: 'The face is checked; a mismatch is still recorded but flagged for the manager.', block: 'A clear mismatch cannot clock in or out (problems with the tablet never lock staff out).' }[f.mode]}
        </Text>
        <NumberField label="Strictness (0.45 strict · 0.50 normal · 0.55 relaxed)" value={f.threshold} onChange={(v) => setF({ ...f, threshold: v })} step={0.05} />
        <NumberField label="Keep punch photos (days)" value={f.keepPhotoDays} onChange={(v) => setF({ ...f, keepPhotoDays: v })} step={10} />
      </Section>
    </Screen>
  );
}

export function ModulesScreen() {
  const { user } = useApp();
  const run = useRun();
  const names = { timeclock: '⏱️ Time Clock', timesheets: '🗓️ Timesheets', leave: '🌴 Leave', bakery: '🥖 Bakery', payables: '🧾 Invoices & cheques', till: '💵 Till & cash', bank: '🏦 Bank reconciliation', payroll: '💰 Payroll', inventory: '📦 Inventory & orders', accounting: '📚 Accounting & VAT', recruitment: '🧑‍💼 Recruitment & onboarding' };
  return (
    <Screen title="Modules" subtitle="Turn sections on or off for everyone">
      {SWITCHABLE.map((id) => (
        <Card key={id}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, flex: 1 }}>{names[id]}</Text>
            <Chips value={moduleOn(id)} onChange={(v) => run(() => setModuleOn(user, id, v))} testIDPrefix={`mod-${id}`}
              options={[{ value: true, label: 'On' }, { value: false, label: 'Off' }]} />
          </View>
        </Card>
      ))}
    </Screen>
  );
}

export function DeviceScreen() {
  const { user } = useApp();
  const run = useRun();
  const [d, setD] = useState(deviceSettings());
  const shops = listShops();
  return (
    <Screen title="This device" subtitle="Only affects this tablet or phone"
      footer={<Btn testID="device-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveDeviceSettings(user, d))} />}>
      <Label>This is a…</Label>
      <Chips value={d.kind} onChange={(v) => setD({ ...d, kind: v, clockHere: v === 'tablet' })} testIDPrefix="device-kind"
        options={[{ value: 'tablet', label: '📟 Shop tablet' }, { value: 'phone', label: '📱 Phone' }]} />
      <Field testID="device-name" label="Name (shown in history and sync status)" value={d.name} onChangeText={(v) => setD({ ...d, name: v })} placeholder="e.g. Shop 2 tablet, Divnesh phone" />
      <Label>Time Clock on the login screen</Label>
      <Chips value={d.clockHere} onChange={(v) => setD({ ...d, clockHere: v })} testIDPrefix="clock-here"
        options={[{ value: true, label: 'Yes – staff clock in here' }, { value: false, label: 'No' }]} />
      <Label>Show this shop first on the Time Clock</Label>
      <Chips value={d.defaultShop} onChange={(v) => setD({ ...d, defaultShop: v })}
        options={[{ value: '', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name })))} />
      <Row label="Device id" value={deviceId()} />
    </Screen>
  );
}

export function AuditScreen() {
  const [q, setQ] = useState('');
  const rows = listAudit({ q });
  return (
    <Screen title="Change history" subtitle="Kept forever, cannot be edited">
      <Field label="Search" value={q} onChangeText={setQ} />
      {rows.map((a) => (
        <Card key={a.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{a.action}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{a.at} · {a.user_name || 'System'} · {a.device || ''}</Text>
          {a.reason ? <Text style={{ fontSize: 15, color: C.text }}>Reason: {a.reason}</Text> : null}
          {a.before ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>Before: {a.before}</Text> : null}
          {a.after ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>After: {a.after}</Text> : null}
        </Card>
      ))}
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing yet.</Text> : null}
    </Screen>
  );
}
