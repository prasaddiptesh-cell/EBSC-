// Admin: the hub and its setup screens. Everything here is editable by the admin.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, NumberField, Row, Section, Tile, Grid, Label, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { can, actsAsOwner, rolePerms, saveRolePerms, PERMS, ROLES, ROLE_LABEL, deviceSettings, saveDeviceSettings } from '../../../services/access.js';
import { listShops, saveShop, moduleOn, setModuleOn, SWITCHABLE, listAudit } from '../service.js';
import { clockRules, saveClockRules, faceSettings, saveFaceSettings } from '../../timeclock/rules.js';
import { deviceId, APP_VERSION, getSetting } from '../../../services/core.js';
import { Hint, Explain, Action, Actions } from '../../../ui/kit.js';
import { updateAvailable } from '../../../platform/updates.js';
import { loginFooter } from '../../../services/about.js';
import { listCostAreas } from '../../../services/costAreas.js';

const useRun = () => {
  const ui = useUI();
  const [, set] = useState(0);
  return (fn, msg) => { try { fn(); ui.toast(msg || 'Saved'); set((n) => n + 1); return true; } catch (e) { ui.error(e); return false; } };
};

// v3.9.5 Settings: every setting of the app in one place, grouped by the same areas as Home. Module menus only
// link here. Opened with { area } (and { module }) from an area or a module menu, it shows just that part.
// 1.0.0 grouped like the approved map (src/services/areas.js SETTINGS_GROUPS_V1); opened with { area } it still shows only
// the settings that came from that part of the business (the old area ids, or a Records hub's settingsArea).
const OLD_AREA_TITLE = { till: 'Sales & tills', inventory: 'Stock & orders', payables: 'Suppliers & paying', people: 'People & pay', money: 'Money & accounts', bakery: 'Bakery', papers: 'Papers', verify: 'Verification & alerts', dashboard: 'Dashboard', business: 'Business, staff & roles', system: 'Devices, cloud & backup', help: 'Help & support' };
export function AdminHubScreen({ params = {} }) {
  const only = params.area || null;
  const title = only ? `Settings: ${OLD_AREA_TITLE[only] || 'this part'}` : 'Settings';
  return (
    <Screen title={title} subtitle={only ? 'The settings for this part of the business' : 'Every setting in one place, grouped'}>
      <SettingsBody params={params} />
    </Screen>
  );
}

// The Settings list itself: also shown as the Settings tab of the office Home.
export function SettingsBody({ params = {} }) {
  const { nav, user, realUser, screens: ctxScreens } = useApp();
  const AR = require('../../../services/areas.js');
  let isLocked = () => false;
  try { isLocked = require('../../../services/lockedHook.js').isLocked; } catch (e) { /* no lock guard */ }
  const who = realUser || user;
  const [q, setQ] = useState('');
  const only = params.area || null;
  const on = (m) => moduleOn(m);
  const groups = {};
  const seen = new Set();
  // From a module menu ("Settings: Bank"): just that module's own settings, as its menu lists them.
  const handMade = !params.module;
  // g = the part of the business it came from (for { area }); the group shown is worked out from the screen.
  const put0 = (g, el, screen, extra, p2, mod) => {
    if (!el) return;
    if (only && g !== only) { if (screen) seen.add(screen); return; }
    const G = screen ? AR.settingsGroupOf(screen, p2, mod) : g;
    (groups[G] = groups[G] || []).push(el); if (screen) seen.add(screen); if (extra) extra.forEach((x) => seen.add(x));
  };
  const put = (g, el, screen, extra, p2) => { if (handMade) put0(g, el, screen, extra, p2); };
  const lockTitle = (key, title) => (isLocked(key) ? `🔒 ${title}` : title);
  const ql = q.trim().toLowerCase();
  const match = (title, note) => !ql || `${title} ${note || ''}`.toLowerCase().includes(ql);
  const a = (g, id, icon, title, note, screen, perm, params2, alsoCovers) => {
    if (!handMade) return;
    if (!can(user, perm) || !match(title, note)) { if (can(user, perm)) seen.add(screen); return; }
    put(g, <Action key={id} testID={`admin-${id}`} icon={icon} title={lockTitle(screen, title)} note={note} onPress={() => nav.push(screen, params2 || {})} />, screen, alsoCovers, params2);
  };
  // Sales & tills
  on('till') && a('till', 'till', '💵', 'Tills & cash rules', 'Tills and floats, payment types, shortages, petty cash.', 'TillSetup', 'till_approve');
  a('till', 'aronium', '🔗', 'Aronium link (till PCs)', 'Each till PC\'s last send, End of days and sales coming in from Aronium.', 'AroniumLink', 'settings');
  a('till', 'insights', '💡', 'Aronium insights', 'Busy hours, reorder list, cashier watch, price check, slow movers.', 'AroniumInsights', 'settings');
  // Stock & orders
  on('inventory') && a('inventory', 'inv', '📦', 'Inventory, orders & stock take', 'Supplier budgets, approvals, cost rules, stock-take rules.', 'InventorySetup', 'inventory_setup');
  // Suppliers & paying
  on('payables') && a('payables', 'aprules', '🧾', 'Invoice rules', 'VAT rate, days to pay, checking, categories.', 'ApRules', 'ap_setup');
  on('payables') && a('payables', 'suppliers', '🏷️', 'Suppliers', 'Names, TIN, terms, how they are paid, contractors (provisional tax).', 'ApSuppliers', 'ap_setup');
  on('payables') && a('payables', 'recurring', '🔁', 'Regular bills & loans', 'Rent, power, loan repayments, loan balances and interest.', 'Recurring', 'ap_setup');
  // People & pay
  on('recruitment') && a('people', 'recruit', '🧑‍💼', 'Recruitment & onboarding', 'The onboarding checklist and probation length.', 'RecruitSetup', 'settings');
  on('recruitment') && a('people', 'contractpdf', '📄', 'Company contract PDF', 'Your own contract, the director\'s signature and the company stamp.', 'ContractPdfSetup', 'settings');
  on('timeclock') && a('people', 'clock', '⏱️', 'Time Clock', 'Breaks, rounding, face check, late tolerance.', 'ClockRules', 'settings');
  on('timesheets') && a('people', 'roster', '📅', 'Roster', 'Quick shifts, asking why late, Google Calendar.', 'RosterSettings', 'settings');
  on('timesheets') && a('people', 'usual', '🗓️', 'Usual weeks', 'Each person\'s normal days and times.', 'Roster', 'timesheets_edit');
  a('people', 'duties', '✅', 'End-of-shift checklists', 'The checklist for each job (shop assistant, cashier, baker, accountant, payroll): switch on, edit the items.', 'DutyLists', 'settings');
  on('leave') && a('people', 'leave', '🌴', 'Leave', 'Leave types, days per year, notice, medical certificates.', 'Leave', 'leave_setup', { tab: 'setup' });
  on('payroll') && a('people', 'payrules', '💰', 'Payroll rules', 'Overtime, PAYE, FNPF, minimum wage, public holidays.', 'PayRules', 'payroll_setup');
  on('payroll') && a('people', 'payprofiles', '🪪', 'Pay details', 'Rates, salaries, FNPF and TIN numbers, cash or bank.', 'PayProfiles', 'payroll_setup');
  // v3.9.5 fixed: this opened the list of payments, not the due dates
  on('payroll') && a('people', 'stat', '🏦', 'FNPF & PAYE due dates', 'When the monthly FNPF, PAYE and VAT payments are due, and the reminders.', 'TaxCalendarSettings', 'payroll_setup');
  // Money & accounts
  on('accounting') && a('money', 'coa', '📚', 'Chart of accounts & where things go', 'The accounts (IFRS order: 1 assets, 2 liabilities, 3 equity, 4 income, 5 cost of sales, 6 expenses, 8 tax) and booking rules.', 'ChartOfAccounts', 'accounts_setup');
  on('accounting') && a('money', 'acctsettings', '⚙️', 'Accounting settings', 'Start date, tax year, advance tax, provisional tax.', 'AcctSettings', 'accounts_setup');
  on('accounting') && a('money', 'opening', '🏁', 'Opening balances', 'The balances on the day the books start.', 'OpeningBalances', 'accounts_setup');
  on('bank') && a('money', 'bankrules', '🏦', 'Bank rules', 'Statement lines coded by themselves.', 'BankRules', 'bank_rec');
  // Papers
  on('licences') && a('papers', 'licences', '📜', 'Licences & permits', 'Every licence, permit and company record, with reminders before they expire.', 'Licences', 'licences_view');
  // Verification
  a('verify', 'verify', '✅', 'Verification & Viber alerts', 'Second person rule, late bank items, Viber group or channel, PDF after saving.', 'VerifySetup', 'verify_setup');
  a('verify', 'audit', '🗂️', 'Change history (audit trail)', 'Who changed what, when, on which device, and why.', 'Audit', 'audit_view');
  // Business, staff & roles
  a('business', 'staff', '👥', 'Users (staff)', 'People, PINs, roles, shops, faces, job for the checklist. Each person\'s own permissions are on their profile.', 'Users', 'staff_manage');
  a('business', 'roles', '🔐', 'Roles & permissions', 'What each role may see and do (owner only).', 'Roles', 'roles');
  a('business', 'shops', '🏪', 'Shops & cost areas', 'Shop names and codes. Each shop has its own page: details, opening hours, bill accounts, papers, costs.', 'Shops', 'settings');
  a('business', 'shoppages', '🏬', 'Shop pages', 'One page per shop: details, opening hours, bill accounts (EFL, WAF, phone), papers & expiry dates, costs.', 'ShopProfiles', 'settings');
  if (require('../../../services/bin.js').canDelete(user) && match('Deleted bin', 'deleted records put back 90 days')) put('verify', <Action key="bin" testID="admin-bin" icon="🗑️" title="Deleted bin" note="Deleted records wait here 90 days: put back, or gone for good." onPress={() => nav.push('DeletedBin', {})} />, 'DeletedBin');
  if (require('../../../services/bin.js').canDelete(user) && match('Correct or delete a record', 'fix mistake delete')) put('verify', <Action key="fix" testID="admin-fix" icon="✏️" title="Correct or delete a record" note="Find any record, change a field, or delete it (to the Deleted bin)." onPress={() => nav.push('RecordFix', {})} />, 'RecordFix');
  a('business', 'modules', '🧩', 'Modules on / off', 'Hide sections the business does not use.', 'Modules', 'settings');
  a('business', 'templates', '📄', 'Report layout', 'Business name, address, TIN, footer, and the columns of each report – with a sample.', 'ReportTemplates', 'settings');
  a('business', 'quick', '⭐', 'Quick links on Home', 'Your one-tap shortcuts, and the starting ones for each role.', 'QuickLinks', 'settings');
  // Devices, cloud & backup
  a('system', 'devices', '📲', 'Devices', 'Add a tablet or phone; block a lost one (it locks at once when online).', 'Devices', 'settings');
  a('system', 'device', '📱', 'This device', 'Tablet or phone, its name and shop, Time Clock here.', 'Device', 'settings');
  // v3.9.5 fixed: opens the Online tab (it opened the bakery's General tab)
  a('system', 'cloud', '☁️', 'Online link', 'The Easy Buys cloud link.', 'Settings', 'settings', { tab: 'online' });
  if (['owner', 'admin'].includes(user.role) && getSetting('cloud_url', '') && match('Easy Buys Business Dashboard online')) put('system', <Action key="dash" testID="admin-dashboard" icon="📊" title="Easy Buys Business Dashboard" note="Opens the online dashboard in the browser (it asks for the dashboard password). Keep the link private." onPress={() => Linking.openURL(getSetting('cloud_url', '')).catch(() => {})} />);
  if (['owner', 'admin'].includes(user.role) && match('Online dashboard – what it shows')) put('system', <Action key="odash" testID="admin-odash" icon="🖥️" title="Online dashboard – what it shows" note="Sections, their order, what stays off the internet, which device sends it." onPress={() => nav.push('OnlineDashboard', {})} />, 'OnlineDashboard');
  a('system', 'emails', '✉️', 'Emails', 'Reports and orders: Off, Ask each time or Automatic.', 'Emails', 'settings');
  a('system', 'golive', '🚀', 'Moving in & go-live', 'Everything to bring into the app, step by step, then the opening figures and go live.', 'GoLive', 'settings');
  // 1.0.0 build 1: the guided set-up and Start clean (owner only)
  if (['owner', 'admin'].includes(user.role) && match('Set up step by step', 'guided setup first run')) put('system', <Action key="guided" testID="admin-guided" icon="🧭" title="Set up step by step" note="The 15 set-up steps in order, with what is done." onPress={() => nav.push('GuidedSetup', {})} />, 'GuidedSetup');
  if ((user.role === 'owner' || user.realRole === 'owner') && match('Start clean (owner)', 'empty wipe')) put('system', <Action key="clean" testID="admin-clean" icon="🔒" title="Start clean (owner)" note="Backup to Google Drive first, then the app starts empty everywhere. Your PIN again." onPress={() => nav.push('StartClean', {})} />, 'StartClean');
  if (actsAsOwner(user) && match('Start fresh (owner)')) put('system', <Action key="fresh" testID="admin-fresh" icon="🧹" title="Start fresh (owner)" note="Clear the test data on every device and in the cloud. A safety copy is made first." onPress={() => nav.push('StartFresh', {})} />, 'StartFresh');
  a('system', 'backup', '💾', 'Backup & restore', 'Safety copies on the tablet, in a folder outside the app and in Google Drive. Make a copy or put one back.', 'Backup', 'settings');
  a('system', 'storage', '🗄️', 'Storage on this device', 'How much space the app, photos and safety copies use, and what is cleaned by itself.', 'Storage', 'settings');
  a('system', 'sync', '⟳', 'Sync', 'Sync now, and what is waiting to be sent.', 'SyncStatus', 'settings');
  a('system', 'health', '🩺', 'Health check', 'The check made every time the app opens, and "Run full check now".', 'HealthCheck', 'settings');
  // Help & support
  a('help', 'updates', '⬆️', 'App updates', updateAvailable() ? `Version ${updateAvailable().version} is ready to install.` : 'Check for a newer version and install it.', 'Updates', 'settings');
  a('help', 'about', 'ℹ️', 'About Easy Buys', 'Version, support contact, what is new, legal notices.', 'About', 'settings');
  a('help', 'sounds', '🔔', 'Alerts & sounds', 'Sounds for urgent, warning and information; quiet hours; this device.', 'AlertSounds', 'settings');
  a('help', 'problems', '🧯', 'Problem log & screen check', 'Errors the app met, where, and a check of every screen. Send a report if something is not working.', 'Problems', 'settings');
  a('help', 'training', '🎓', 'Training mode', 'A practice copy with sample shops, staff and figures. Real data is not touched.', 'Training', 'settings');
  // 1.0.0 the guided set-up first; petty cash (switched off unless turned back on); each person's permissions
  try { const HK = require('../../home/shellModel.js'); const t = HK.resolveHook('SETUP_WIZARD', ctxScreens || require('../../registry.js').allScreens(), who); if (t && match('Set up step by step', 'first time guided')) put('system', <Action key="wizard" testID="admin-wizard" icon="🧭" title="Set up step by step" note="Shops, tills, Aronium, suppliers, staff, bank… one step at a time, showing what is done." onPress={() => nav.push(t.screen, t.params || {})} />, t.screen); } catch (e) { /* no set-up */ }
  a('money', 'petty', '🪙', 'Petty cash', 'Switched off. Turn it back on here if the business uses petty cash again.', 'PettyCashSetting', 'settings');
  // Admin's own pages (change history, watchdog, documents, questions…) – Settings is their home now.
  if (handMade) {
    try {
      const R = require('../../registry.js');
      const M = require('../../../services/menus.js');
      const adm = R.getModule('admin');
      for (const sec of M.visibleMenu(adm, who, ctxScreens || R.allScreens())) {
        if (sec.section === 'Settings') continue;
        for (const it of sec.items) {
          if (it.screen === 'Admin' || seen.has(it.screen) || !match(it.title, it.note)) continue;
          put0('system', <Action key={`adm-${it.id}`} testID={`mi-${it.id}`} icon={it.icon || '⚙️'} title={lockTitle(it.screen, it.title)} note={it.note} onPress={() => nav.push(it.screen, it.params || {})} />, it.screen, null, it.params, 'admin');
        }
      }
    } catch (e) { /* the rest still shows */ }
  }
  // Every other setting of every module (so nothing is only in a module menu any more).
  try {
    const R = require('../../registry.js');
    const A = require('../../../services/areas.js');
    const byArea = A.settingsByArea(who, ctxScreens || R.allScreens(), R.menuModules(), Array.from(seen));
    for (const [area, items] of Object.entries(byArea)) {
      for (const it of items) {
        if (params.module && it.module !== params.module) continue;
        if (!match(it.title, `${it.note || ''} ${it.moduleTitle}`)) continue;
        const g = area === 'system' && it.module === 'admin' ? 'system' : area;
        put0(g === 'home' ? 'system' : g, <Action key={`${it.module}-${it.id}`} testID={`mi-${it.id}`} icon={it.icon || '⚙️'} title={lockTitle(it.screen, it.title)} note={it.note} onPress={() => nav.push(it.screen, it.params || {})} />, it.screen, null, it.params, it.module);
      }
    }
  } catch (e) { /* the hand-made list above still shows */ }
  const shown = AR.SETTINGS_GROUPS_V1.filter(([g]) => (groups[g] || []).length);
  return (
    <>
      {!only ? <Hint>Every setting of the app is here, grouped. Every change is saved in the change history with who made it and when.</Hint> : null}
      <Field testID="settings-search" label="Find a setting" value={q} onChangeText={setQ} placeholder="e.g. VAT, roster, Viber, tills" />
      {shown.map(([g, label]) => <Section key={g} title={label}><Actions>{groups[g]}</Actions></Section>)}
      {!shown.length ? <Hint>No setting matches.</Hint> : null}
      {only ? <Btn testID="settings-all" title="All settings" icon="⚙️" size="md" variant="secondary" onPress={() => nav.replace('Admin', {})} /> : null}
      <Text style={{ fontSize: 13, color: C.sub, textAlign: 'center' }}>{loginFooter()} · device {deviceId()}</Text>
    </>
  );
}

export function RolesScreen() {
  const { user } = useApp();
  const run = useRun();
  const [perms, setPerms] = useState(() => JSON.parse(JSON.stringify(rolePerms()))); // its own copy to change
  const owner = actsAsOwner(user);
  const toggle = (role, key) => {
    const has = perms[role].includes(key);
    setPerms({ ...perms, [role]: has ? perms[role].filter((k) => k !== key) : perms[role].concat([key]) });
  };
  const groups = Array.from(new Set(PERMS.map((p) => p.module))).filter((g) => g !== 'My day'); // My day comes in a later build
  return (
    <Screen title="Roles" subtitle="What each role may do" footer={owner ? <Btn testID="roles-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveRolePerms(user, perms))} /> : null}>
      {!owner ? <Banner tone="info" message="Only an Owner can change these." /> : null}
      {ROLES.filter((r) => r !== 'owner').map((r) => (
        <Card key={r}>
          <H>{ROLE_LABEL[r]}</H>
          {groups.map((g) => (
            <View key={g} style={{ marginBottom: 6 }}>
              <Label>{g}</Label>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {PERMS.filter((p) => p.module === g && p.key !== 'roles').map((p) => {
                  const on = perms[r].includes(p.key);
                  return <Btn key={p.key} testID={`perm-${r}-${p.key}`} title={`${on ? '✓ ' : ''}${p.label}`} size="sm" variant={on ? 'success' : 'secondary'} disabled={!owner} onPress={() => toggle(r, p.key)} />;
                })}
              </View>
            </View>
          ))}
        </Card>
      ))}
      <Banner tone="info" message="Owners can always do everything." />
    </Screen>
  );
}

export function ShopsScreen() {
  const { user } = useApp();
  const run = useRun();
  const shops = listShops({ includeInactive: true });
  const [n, setN] = useState({ code: '', name: '' });
  return (
    <Screen title="Shops" subtitle="Used by staff, Time Clock and reports">
      <Hint>Shop 2 is Tukani Street. The V M Pillay shop is closed: it is not a shop any more (not in tills, rosters or the Time Clock), only the cost area "Closed shop – V M Pillay".</Hint>
      {shops.map((s) => <ShopRow key={s.code} s={s} user={user} run={run} />)}
      <Section title="Cost areas (where a cost or income belongs)">
        {listCostAreas().map((a) => <Row key={a.code} label={a.name} value={a.code} />)}
        <Hint>Bills, regular bills, loans and journals can be put on any cost area. Closed shop costs are shown on their own line ("Closed shop costs") and are never charged to Shop 1 or Shop 2.</Hint>
      </Section>
      <Card>
        <H>Add a shop</H>
        <View style={{ gap: 10 }}>
          <Field label="Short code (e.g. S4)" value={n.code} onChangeText={(v) => setN({ ...n, code: v })} />
          <Field label="Name" value={n.name} onChangeText={(v) => setN({ ...n, name: v })} />
          <Btn title="Add shop" size="md" onPress={() => { if (run(() => saveShop(user, n), 'Shop added')) setN({ code: '', name: '' }); }} />
        </View>
      </Card>
    </Screen>
  );
}
function ShopRow({ s, user, run }) {
  const { nav } = useApp();
  const [name, setName] = useState(s.name);
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
        <Badge text={s.code} color={s.active ? C.info : C.sub} />
        <View style={{ flex: 1, minWidth: 180 }}><Field testID={`shop-name-${s.code}`} value={name} onChangeText={setName} /></View>
        <Btn testID={`shop-save-${s.code}`} title="Save" size="md" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !!s.active }))} />
        <Btn title={s.active ? 'Close' : 'Re-open'} size="md" variant="secondary" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !s.active }))} />
        <Btn testID={`shop-page-${s.code}`} title="Shop page" icon="›" size="md" variant="ghost" onPress={() => nav.push('ShopProfile', { code: s.code })} />
      </View>
    </Card>
  );
}

export function ClockRulesScreen() {
  const { user, nav } = useApp();
  const run = useRun();
  const [r, setR] = useState(clockRules());
  const [f, setF] = useState(faceSettings());
  const set = (k) => (v) => setR({ ...r, [k]: v });
  return (
    <Screen title="Time Clock rules" subtitle="Shared by every device"
      footer={<Btn testID="rules-save" title="Save all" icon="💾" variant="success" onPress={() => run(() => { saveClockRules(user, r); saveFaceSettings(user, f); })} />}>
      <Section title="Breaks">
        <Chips value={r.breakMode} onChange={set('breakMode')} testIDPrefix="break-mode"
          options={[{ value: 'buttons', label: 'Staff tap Break start / end' }, { value: 'auto', label: 'Take a fixed break off' }, { value: 'none', label: 'No breaks' }]} />
        {r.breakMode === 'auto' ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><NumberField label="Break minutes" value={r.autoBreakMinutes} onChange={set('autoBreakMinutes')} step={5} /></View>
            <View style={{ flex: 1 }}><NumberField label="…for shifts over (hours)" value={r.autoBreakAfterHours} onChange={set('autoBreakAfterHours')} /></View>
          </View>
        ) : null}
        {r.breakMode === 'buttons' ? <NumberField label="Warn if no break on shifts over (hours)" value={r.noBreakAfterHours} onChange={set('noBreakAfterHours')} /> : null}
      </Section>
      <Section title="Times">
        <Label>Round clock times to</Label>
        <Chips value={Number(r.roundMinutes)} onChange={set('roundMinutes')} testIDPrefix="round"
          options={[{ value: 0, label: 'Exact' }, { value: 5, label: '5 min' }, { value: 10, label: '10 min' }, { value: 15, label: '15 min' }]} />
        <NumberField label="Grace period for late (minutes)" value={r.graceMinutes} onChange={set('graceMinutes')} />
        <NumberField label="Longest possible shift (hours) – after this a missing Clock OUT is flagged" value={r.maxShiftHours} onChange={set('maxShiftHours')} />
        <NumberField label="Warn on shifts longer than (hours)" value={r.longShiftHours} onChange={set('longShiftHours')} />
        <NumberField label="Ignore a second tap within (minutes)" value={r.doubleTapMinutes} onChange={set('doubleTapMinutes')} />
        <Chips value={r.showAllShops ? 'all' : 'one'} onChange={(v) => setR({ ...r, showAllShops: v === 'all' })}
          options={[{ value: 'all', label: 'Tablet shows every shop' }, { value: 'one', label: 'Only this device\'s shop' }]} />
      </Section>
      <Section title="Face check">
        <Btn testID="face-test-open" title="Test the face check on this tablet" icon="🙂" size="md" variant="info" onPress={() => nav.push('FaceTest')} />
        <Chips value={f.mode} onChange={(v) => setF({ ...f, mode: v })} testIDPrefix="face-mode"
          options={[{ value: 'off', label: 'Off' }, { value: 'photo', label: 'Photo only' }, { value: 'flag', label: 'Check and flag' }, { value: 'block', label: 'Check and block' }]} />
        <Text style={{ fontSize: 15, color: C.sub }}>
          {{ off: 'No camera at the Time Clock.', photo: 'A photo is kept with every punch. No matching.', flag: 'The face is checked; a mismatch is still recorded but flagged for the manager.', block: 'A clear mismatch cannot clock in or out (problems with the tablet never lock staff out).' }[f.mode]}
        </Text>
        <NumberField label="Strictness (0.45 strict · 0.50 normal · 0.55 relaxed)" value={f.threshold} onChange={(v) => setF({ ...f, threshold: v })} step={0.05} />
        <NumberField label="Keep punch photos (days)" value={f.keepPhotoDays} onChange={(v) => setF({ ...f, keepPhotoDays: v })} step={10} />
      </Section>
    </Screen>
  );
}

export function ModulesScreen() {
  const { user } = useApp();
  const run = useRun();
  const names = { timeclock: '⏱️ Time Clock', timesheets: '🗓️ Timesheets', leave: '🌴 Leave', bakery: '🥖 Bakery', payables: '🧾 Invoices & cheques', till: '💵 Till & cash', bank: '🏦 Bank reconciliation', payroll: '💰 Payroll', inventory: '📦 Inventory & orders', accounting: '📚 Accounting & VAT', recruitment: '🧑‍💼 Recruitment & onboarding', licences: '📜 Licences & permits', loans: '🏦 Loans & rent', drawings: "👛 Owner's money", myday: '🗓️ My day', vehicles: '🚚 Vehicles & equipment', trade: '🏪 Wholesale – customer & supplier accounts' };
  return (
    <Screen title="Modules" subtitle="Turn sections on or off for everyone">
      {SWITCHABLE.filter((id) => id !== 'myday').map((id) => (
        <Card key={id}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, flex: 1 }}>{names[id]}</Text>
            <Chips value={moduleOn(id)} onChange={(v) => run(() => setModuleOn(user, id, v))} testIDPrefix={`mod-${id}`}
              options={[{ value: true, label: 'On' }, { value: false, label: 'Off' }]} />
          </View>
        </Card>
      ))}
    </Screen>
  );
}

export function DeviceScreen() {
  const { user } = useApp();
  const run = useRun();
  const [d, setD] = useState(deviceSettings());
  const shops = listShops();
  return (
    <Screen title="This device" subtitle="Only affects this tablet or phone"
      footer={<Btn testID="device-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveDeviceSettings(user, d))} />}>
      <Label>This is a…</Label>
      <Chips value={d.kind} onChange={(v) => setD({ ...d, kind: v, clockHere: v === 'tablet' })} testIDPrefix="device-kind"
        options={[{ value: 'tablet', label: '📟 Shop tablet' }, { value: 'phone', label: '📱 Phone' }]} />
      <Field testID="device-name" label="Name (shown in history and sync status)" value={d.name} onChangeText={(v) => setD({ ...d, name: v })} placeholder="e.g. Shop 2 tablet, Divnesh phone" />
      <Label>Time Clock on the login screen</Label>
      <Chips value={d.clockHere} onChange={(v) => setD({ ...d, clockHere: v })} testIDPrefix="clock-here"
        options={[{ value: true, label: 'Yes – staff clock in here' }, { value: false, label: 'No' }]} />
      <Label>Show this shop first on the Time Clock</Label>
      <Chips value={d.defaultShop} onChange={(v) => setD({ ...d, defaultShop: v })}
        options={[{ value: '', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name })))} />
      <MainTabletSection />
      <BackgroundSection />
      <Row label="Device id" value={deviceId()} />
    </Screen>
  );
}
// v1.0.0 the main tablet, chosen here (also in Documents & backups): it turns the till PCs' Aronium figures into sales
// and stock, does the nightly backup and the automatic Viber messages. Only one device at a time.
function MainTabletSection() {
  const { user } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const D = require('../../../services/driveDocs.js');
  const isMain = D.isMainTablet();
  const other = D.mainTabletId();
  let otherName = other;
  try { const r = require('../../../db/connection.js').db().get('SELECT name FROM devices WHERE id = ? OR uid = ?', [other, other]); if (r && r.name) otherName = r.name; } catch (e) { /* the id is shown */ }
  const owner = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  return (
    <Card style={{ gap: 6 }}>
      <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>Main tablet</Text>
      <Text testID="main-state" style={{ fontSize: 15, color: isMain ? C.success : C.sub, fontWeight: '700' }}>{isMain ? 'This device is the main tablet.' : other ? `The main tablet is another device (${otherName}).` : 'No main tablet chosen yet – the first linked device acts as main.'}</Text>
      <Text style={{ fontSize: 14, color: C.sub }}>Any linked device does the shared jobs (Aronium products and staff credit, the nightly backup, the automatic Viber messages) – one device at a time, and another takes over by itself when it stops syncing. The main tablet just gets them first. Nothing waits for it to be on.</Text>
      {owner && !isMain ? <Btn testID="main-make" title="Make this device the main tablet" icon="⭐" size="md" variant="info" onPress={async () => {
        const ok = await ui.confirm({ title: 'Make this the main tablet?', message: other ? 'The other device stops being main straight away.' : 'This device will do the Aronium sales, backups and Viber messages.', confirmText: 'Make main' });
        if (!ok) return;
        try { D.setMainTablet(user, true); ui.toast('This is now the main tablet'); bump((n) => n + 1); } catch (e) { ui.error(e); }
      }} /> : null}
    </Card>
  );
}
// v3.9.6 background sync and the "New to verify" notification on this device.
function BackgroundSection() {
  const W = require('../../../services/verifyWatch.js');
  const B = require('../../../platform/background.js');
  const [on, setOn] = useState(W.verifyNotifyOn());
  const info = B.backgroundInfo();
  let who = null;
  try { const uid = getSetting('verify_notify_uid', ''); who = uid ? require('../../../db/connection.js').db().get('SELECT name FROM users WHERE uid = ?', [uid]) : null; } catch (e) { who = null; }
  return (
    <Section title="Background sync & notifications">
      <Hint>The app sends and fetches changes in the background about every 15 minutes, also when it is closed (Android picks the exact time; on Samsung set Battery for Easy Buys to "Unrestricted" so it is not stopped).</Hint>
      <Row label="Last background sync" value={info.lastOk ? String(info.lastOk).slice(0, 16) : 'Not yet'} />
      {info.lastError ? <Row label="Last problem" value={info.lastError} /> : null}
      <Label>Notify about new papers in To verify</Label>
      <Chips value={on} onChange={(v) => { W.setVerifyNotify(v); setOn(v); }} testIDPrefix="bg-verify"
        options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
      <Hint>{who ? `Notifications are for ${who.name} (the last person on this device who verifies).` : 'Notifications start once someone who verifies (owner, admin, manager) logs in on this device.'}</Hint>
    </Section>
  );
}

export function AuditScreen() {
  const [q, setQ] = useRemembered('q', '');
  const rows = listAudit({ q });
  return (
    <Screen title="Change history" subtitle="Kept forever, cannot be edited">
      <Field label="Search" value={q} onChangeText={setQ} />
      {rows.map((a) => (
        <Card key={a.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{a.action}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{a.at} · {a.user_name || 'System'} · {a.device || ''}</Text>
          {a.reason ? <Text style={{ fontSize: 15, color: C.text }}>Reason: {a.reason}</Text> : null}
          {a.before ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>Before: {a.before}</Text> : null}
          {a.after ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>After: {a.after}</Text> : null}
        </Card>
      ))}
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing yet.</Text> : null}
    </Screen>
  );
}
