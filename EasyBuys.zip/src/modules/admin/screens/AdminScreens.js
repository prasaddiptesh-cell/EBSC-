// Admin: the hub and its setup screens. Everything here is editable by the admin.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, NumberField, Row, Section, Tile, Grid, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { can, actsAsOwner, rolePerms, saveRolePerms, PERMS, ROLES, ROLE_LABEL, deviceSettings, saveDeviceSettings } from '../../../services/access.js';
import { listShops, saveShop, moduleOn, setModuleOn, SWITCHABLE, listAudit } from '../service.js';
import { clockRules, saveClockRules, faceSettings, saveFaceSettings } from '../../timeclock/rules.js';
import { deviceId, APP_VERSION } from '../../../services/core.js';

const useRun = () => {
  const ui = useUI();
  const [, set] = useState(0);
  return (fn, msg) => { try { fn(); ui.toast(msg || 'Saved'); set((n) => n + 1); return true; } catch (e) { ui.error(e); return false; } };
};

export function AdminHubScreen() {
  const { nav, user } = useApp();
  const t = (id, icon, title, sub, screen, perm, color) => (can(user, perm) ? <Tile key={id} testID={`admin-${id}`} icon={icon} title={title} subtitle={sub} color={color} onPress={() => nav.push(screen)} /> : null);
  return (
    <Screen title="Admin" subtitle="Setup for every module">
      <Grid>
        {[
          t('staff', '👥', 'Staff', 'People, PINs, roles, faces', 'Users', 'staff_manage', C.info),
          t('roles', '🔐', 'Roles', 'What each role may do', 'Roles', 'roles', C.primaryDark),
          t('shops', '🏪', 'Shops', 'Names and codes', 'Shops', 'settings', C.success),
          t('clock', '⏱️', 'Time Clock rules', 'Breaks, rounding, face check', 'ClockRules', 'settings', C.brandBlue),
          t('leave', '🌴', 'Leave setup', 'Types, days, rules', 'Leave', 'leave_setup', C.warn),
          t('modules', '🧩', 'Modules', 'Turn sections on or off', 'Modules', 'settings', C.sub),
          t('devices', '📲', 'Devices', 'Add a tablet or phone, block one', 'Devices', 'settings', C.brandBlue),
          t('device', '📱', 'This device', 'Tablet or phone, name', 'Device', 'settings', C.sub),
          t('cloud', '☁️', 'Online & email', 'Cloud link, report emails', 'Settings', 'settings', C.info),
          t('audit', '🗂️', 'Change history', 'Who changed what', 'Audit', 'audit_view', C.sub),
        ].filter(Boolean)}
      </Grid>
      <Text style={{ fontSize: 13, color: C.sub, textAlign: 'center' }}>Easy Buys app v{APP_VERSION} · device {deviceId()}</Text>
    </Screen>
  );
}

export function RolesScreen() {
  const { user } = useApp();
  const run = useRun();
  const [perms, setPerms] = useState(rolePerms());
  const owner = actsAsOwner(user);
  const toggle = (role, key) => {
    const has = perms[role].includes(key);
    setPerms({ ...perms, [role]: has ? perms[role].filter((k) => k !== key) : perms[role].concat([key]) });
  };
  const groups = Array.from(new Set(PERMS.map((p) => p.module)));
  return (
    <Screen title="Roles" subtitle="What each role may do" footer={owner ? <Btn testID="roles-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveRolePerms(user, perms))} /> : null}>
      {!owner ? <Banner tone="info" message="Only an Owner can change these." /> : null}
      {ROLES.filter((r) => r !== 'owner').map((r) => (
        <Card key={r}>
          <H>{ROLE_LABEL[r]}</H>
          {groups.map((g) => (
            <View key={g} style={{ marginBottom: 6 }}>
              <Label>{g}</Label>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {PERMS.filter((p) => p.module === g && p.key !== 'roles').map((p) => {
                  const on = perms[r].includes(p.key);
                  return <Btn key={p.key} testID={`perm-${r}-${p.key}`} title={`${on ? '✓ ' : ''}${p.label}`} size="sm" variant={on ? 'success' : 'secondary'} disabled={!owner} onPress={() => toggle(r, p.key)} />;
                })}
              </View>
            </View>
          ))}
        </Card>
      ))}
      <Banner tone="info" message="Owners can always do everything." />
    </Screen>
  );
}

export function ShopsScreen() {
  const { user } = useApp();
  const run = useRun();
  const shops = listShops({ includeInactive: true });
  const [n, setN] = useState({ code: '', name: '' });
  return (
    <Screen title="Shops" subtitle="Used by staff, Time Clock and reports">
      {shops.map((s) => <ShopRow key={s.code} s={s} user={user} run={run} />)}
      <Card>
        <H>Add a shop</H>
        <View style={{ gap: 10 }}>
          <Field label="Short code (e.g. S4)" value={n.code} onChangeText={(v) => setN({ ...n, code: v })} />
          <Field label="Name" value={n.name} onChangeText={(v) => setN({ ...n, name: v })} />
          <Btn title="Add shop" size="md" onPress={() => { if (run(() => saveShop(user, n), 'Shop added')) setN({ code: '', name: '' }); }} />
        </View>
      </Card>
    </Screen>
  );
}
function ShopRow({ s, user, run }) {
  const [name, setName] = useState(s.name);
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
        <Badge text={s.code} color={s.active ? C.info : C.sub} />
        <View style={{ flex: 1, minWidth: 180 }}><Field testID={`shop-name-${s.code}`} value={name} onChangeText={setName} /></View>
        <Btn testID={`shop-save-${s.code}`} title="Save" size="md" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !!s.active }))} />
        <Btn title={s.active ? 'Close' : 'Re-open'} size="md" variant="secondary" onPress={() => run(() => saveShop(user, { code: s.code, name, active: !s.active }))} />
      </View>
    </Card>
  );
}

export function ClockRulesScreen() {
  const { user } = useApp();
  const run = useRun();
  const [r, setR] = useState(clockRules());
  const [f, setF] = useState(faceSettings());
  const set = (k) => (v) => setR({ ...r, [k]: v });
  return (
    <Screen title="Time Clock rules" subtitle="Shared by every device"
      footer={<Btn testID="rules-save" title="Save all" icon="💾" variant="success" onPress={() => run(() => { saveClockRules(user, r); saveFaceSettings(user, f); })} />}>
      <Section title="Breaks">
        <Chips value={r.breakMode} onChange={set('breakMode')} testIDPrefix="break-mode"
          options={[{ value: 'buttons', label: 'Staff tap Break start / end' }, { value: 'auto', label: 'Take a fixed break off' }, { value: 'none', label: 'No breaks' }]} />
        {r.breakMode === 'auto' ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><NumberField label="Break minutes" value={r.autoBreakMinutes} onChange={set('autoBreakMinutes')} step={5} /></View>
            <View style={{ flex: 1 }}><NumberField label="…for shifts over (hours)" value={r.autoBreakAfterHours} onChange={set('autoBreakAfterHours')} /></View>
          </View>
        ) : null}
        {r.breakMode === 'buttons' ? <NumberField label="Warn if no break on shifts over (hours)" value={r.noBreakAfterHours} onChange={set('noBreakAfterHours')} /> : null}
      </Section>
      <Section title="Times">
        <Label>Round clock times to</Label>
        <Chips value={Number(r.roundMinutes)} onChange={set('roundMinutes')} testIDPrefix="round"
          options={[{ value: 0, label: 'Exact' }, { value: 5, label: '5 min' }, { value: 10, label: '10 min' }, { value: 15, label: '15 min' }]} />
        <NumberField label="Grace period for late (minutes)" value={r.graceMinutes} onChange={set('graceMinutes')} />
        <NumberField label="Longest possible shift (hours) – after this a missing Clock OUT is flagged" value={r.maxShiftHours} onChange={set('maxShiftHours')} />
        <NumberField label="Warn on shifts longer than (hours)" value={r.longShiftHours} onChange={set('longShiftHours')} />
        <NumberField label="Ignore a second tap within (minutes)" value={r.doubleTapMinutes} onChange={set('doubleTapMinutes')} />
        <Chips value={r.showAllShops ? 'all' : 'one'} onChange={(v) => setR({ ...r, showAllShops: v === 'all' })}
          options={[{ value: 'all', label: 'Tablet shows every shop' }, { value: 'one', label: 'Only this device\'s shop' }]} />
      </Section>
      <Section title="Face check">
        <Chips value={f.mode} onChange={(v) => setF({ ...f, mode: v })} testIDPrefix="face-mode"
          options={[{ value: 'off', label: 'Off' }, { value: 'photo', label: 'Photo only' }, { value: 'flag', label: 'Check and flag' }, { value: 'block', label: 'Check and block' }]} />
        <Text style={{ fontSize: 15, color: C.sub }}>
          {{ off: 'No camera at the Time Clock.', photo: 'A photo is kept with every punch. No matching.', flag: 'The face is checked; a mismatch is still recorded but flagged for the manager.', block: 'A clear mismatch cannot clock in or out (problems with the tablet never lock staff out).' }[f.mode]}
        </Text>
        <NumberField label="Strictness (0.45 strict · 0.50 normal · 0.55 relaxed)" value={f.threshold} onChange={(v) => setF({ ...f, threshold: v })} step={0.05} />
        <NumberField label="Keep punch photos (days)" value={f.keepPhotoDays} onChange={(v) => setF({ ...f, keepPhotoDays: v })} step={10} />
      </Section>
    </Screen>
  );
}

export function ModulesScreen() {
  const { user } = useApp();
  const run = useRun();
  const names = { timeclock: '⏱️ Time Clock', timesheets: '🗓️ Timesheets', leave: '🌴 Leave', bakery: '🥖 Bakery', payables: '🧾 Invoices & cheques', till: '💵 Till & cash', bank: '🏦 Bank reconciliation', payroll: '💰 Payroll' };
  return (
    <Screen title="Modules" subtitle="Turn sections on or off for everyone">
      {SWITCHABLE.map((id) => (
        <Card key={id}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text, flex: 1 }}>{names[id]}</Text>
            <Chips value={moduleOn(id)} onChange={(v) => run(() => setModuleOn(user, id, v))} testIDPrefix={`mod-${id}`}
              options={[{ value: true, label: 'On' }, { value: false, label: 'Off' }]} />
          </View>
        </Card>
      ))}
    </Screen>
  );
}

export function DeviceScreen() {
  const { user } = useApp();
  const run = useRun();
  const [d, setD] = useState(deviceSettings());
  const shops = listShops();
  return (
    <Screen title="This device" subtitle="Only affects this tablet or phone"
      footer={<Btn testID="device-save" title="Save" icon="💾" variant="success" onPress={() => run(() => saveDeviceSettings(user, d))} />}>
      <Label>This is a…</Label>
      <Chips value={d.kind} onChange={(v) => setD({ ...d, kind: v, clockHere: v === 'tablet' })} testIDPrefix="device-kind"
        options={[{ value: 'tablet', label: '📟 Shop tablet' }, { value: 'phone', label: '📱 Phone' }]} />
      <Field testID="device-name" label="Name (shown in history and sync status)" value={d.name} onChangeText={(v) => setD({ ...d, name: v })} placeholder="e.g. Shop 2 tablet, Divnesh phone" />
      <Label>Time Clock on the login screen</Label>
      <Chips value={d.clockHere} onChange={(v) => setD({ ...d, clockHere: v })} testIDPrefix="clock-here"
        options={[{ value: true, label: 'Yes – staff clock in here' }, { value: false, label: 'No' }]} />
      <Label>Show this shop first on the Time Clock</Label>
      <Chips value={d.defaultShop} onChange={(v) => setD({ ...d, defaultShop: v })}
        options={[{ value: '', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name })))} />
      <Row label="Device id" value={deviceId()} />
    </Screen>
  );
}

export function AuditScreen() {
  const [q, setQ] = useState('');
  const rows = listAudit({ q });
  return (
    <Screen title="Change history" subtitle="Kept forever, cannot be edited">
      <Field label="Search" value={q} onChangeText={setQ} />
      {rows.map((a) => (
        <Card key={a.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{a.action}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{a.at} · {a.user_name || 'System'} · {a.device || ''}</Text>
          {a.reason ? <Text style={{ fontSize: 15, color: C.text }}>Reason: {a.reason}</Text> : null}
          {a.before ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>Before: {a.before}</Text> : null}
          {a.after ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={3}>After: {a.after}</Text> : null}
        </Card>
      ))}
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing yet.</Text> : null}
    </Screen>
  );
}
