// v3.9.8 Power & water bills: every EFL and WAF account of every shop, its latest bill and what to do.
// Water is checked by itself every day (main tablet); EFL is checked by a person (its checker has a robot box).
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ListItem, MoneyField, useAct } from '../../../ui/kit.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { dateStr } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import * as UB from '../../../services/utilityBills.js';

const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');
const STATE = { to_confirm: ['New bill – acknowledge it', 'warn'], overdue: ['Overdue', 'danger'], due_soon: ['Due soon', 'warn'], owing: ['To pay', 'info'], paid: ['Paid / nothing owing', 'success'], not_checked: ['Not checked yet', 'warn'] };

export function BillsScreen() {
  const { nav, user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [, bump] = useState(0);
  const [busy, setBusy] = useState(false);
  let board = [];
  try { board = UB.billBoard(); } catch (e) { board = []; }
  const checkWater = async () => {
    setBusy(true);
    try {
      const r = await UB.checkWaterBills({ force: true });
      ui.toast(r.checked ? `Water checked: ${r.checked} account${r.checked === 1 ? '' : 's'}${r.problems.length ? ` (${r.problems.length} problem${r.problems.length === 1 ? '' : 's'})` : ''}` : r.problems.length ? r.problems[0] : 'No water accounts with an account number yet');
    } catch (e) { ui.error(e); }
    setBusy(false); bump((n) => n + 1);
  };
  return (
    <Screen title="Power & water bills" subtitle="Every EFL and WAF account of every shop">
      <Explain>Water bills are checked by the app every day (WAF only needs the account number). EFL's bill checker has an "I'm not a robot" box, so once a month tap "Check EFL bill", tick the box on EFL's page, take a screenshot of the result and give it to the app here. A new bill is shown here first: tap "Acknowledge" and the bill is made in Invoices for that shop, ready to pay.</Explain>
      {!board.length ? <Banner tone="warn" title="No bill accounts yet" message="Add each shop's EFL and WAF account numbers on its shop page (Shops › the shop › Bill accounts)." /> : null}
      {board.length ? <Btn testID="bills-read" title="Read a bill (photo, screenshot or PDF)" icon="📷" size="md" variant="info" onPress={() => nav.push('BillCheck', {})} /> : null}
      {board.some((b) => b.kind === 'water') ? <Btn testID="bills-check-water" title={busy ? 'Checking…' : 'Check the water bills now'} icon="💧" size="md" variant="secondary" disabled={busy} onPress={checkWater} /> : null}
      {board.map((b) => {
        const st = STATE[b.state] || STATE.not_checked;
        return (
          <Card key={b.uid} tone={st[1] === 'danger' ? 'danger' : st[1] === 'warn' ? 'warn' : undefined}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`${b.icon} ${b.shopName || b.shop} – ${b.label}`}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>{`Account ${b.accountNo} · ${b.auto ? 'checked by the app every day' : 'checked by a person once a month'}`}</Text>
            <Text testID={`bill-state-${b.uid}`} style={{ fontSize: 16, fontWeight: '700', color: C[st[1]] || C.text }}>{`${st[0]}${b.owing ? ` · ${$(b.owing)}` : b.total !== null && b.total !== undefined ? ` · ${$(b.total)}` : ''}${b.due ? ` · due ${d(b.due)}` : ''}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{b.lastChecked ? `Last checked ${String(b.lastChecked).slice(0, 16)}${b.daysSince ? ` (${b.daysSince} day${b.daysSince === 1 ? '' : 's'} ago)` : ''}` : 'Never checked'}</Text>
            {b.state === 'to_confirm' ? (
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
                <Btn testID={`bill-ack-${b.uid}`} title={`Acknowledge – make the bill ${$(b.total)}`} icon="✅" size="sm" variant="success" onPress={() => { if (act(() => UB.acknowledgeBill(user, b.checkUid), 'Bill made – it is in Invoices')) bump((n) => n + 1); }} />
                <Btn testID={`bill-aside-${b.uid}`} title="No bill needed" size="sm" variant="ghost" onPress={async () => { const ok = await ui.confirm({ title: 'No bill needed?', message: 'Put this check aside without making a bill (e.g. it was already entered).', confirmText: 'Put aside' }); if (ok && act(() => UB.putAsideBill(user, b.checkUid, 'Already entered / not needed'), 'Put aside')) bump((n) => n + 1); }} />
              </View>
            ) : null}
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
              {b.kind === 'power' ? <Btn testID={`bill-efl-${b.uid}`} title="Check EFL bill" icon="⚡" size="sm" variant="info" onPress={() => nav.push('BillCheck', { uid: b.uid })} /> : <Btn testID={`bill-enter-${b.uid}`} title="Enter it by hand" size="sm" variant="ghost" onPress={() => nav.push('BillCheck', { uid: b.uid })} />}
              {b.invoiceUid ? <Btn testID={`bill-inv-${b.uid}`} title="Open the bill" size="sm" variant="secondary" onPress={() => nav.push('ApInvoice', { uid: b.invoiceUid })} /> : null}
            </View>
          </Card>
        );
      })}
    </Screen>
  );
}

// One check: an EFL / WAF bill – a photo of the paper bill, a screenshot of EFL's checker, or the PDF – read by the AI
// in the cloud (offline: on this phone), or typed. 1.0.0 build 54: opened without an account ("Read a bill"), the
// account number on the bill picks the shop's bill account; a bill for another account is caught before saving.
export function BillCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const all = (() => { try { return UB.billAccounts(); } catch (e) { return []; } })();
  const [pick, setPick] = useState(params.uid || '');
  const chosen = all.find((a) => a.uid === pick) || null;
  const pr = usePaper('efl_bill', { billKind: chosen ? chosen.kind : 'any' });
  const [f, setF] = useState({ total: '', overdue: '', due: '', photos: [] });
  const readNo = pr.read && pr.read.fields && pr.read.fields.accountNo ? String(pr.read.fields.accountNo) : '';
  const matched = readNo ? (() => { try { return UB.matchBillAccount(readNo); } catch (e) { return null; } })() : null;
  const acc = chosen || matched;
  if (params.uid && !chosen) return <Screen title="Bill"><Banner tone="danger" message="That bill account was not found (it needs an account number on the shop page)." /></Screen>;
  if (!all.length) return <Screen title="Bill"><Banner tone="warn" title="No bill accounts yet" message="Add each shop's EFL and WAF account numbers on its shop page (Shops › the shop › Bill accounts)." /></Screen>;
  const k = acc ? UB.BILL_KIND[acc.kind] : null;
  const power = acc ? acc.kind === 'power' : false;
  const norm = (x) => String(x || '').replace(/\D/g, '');
  const other = acc && readNo && norm(readNo) !== norm(acc.account_no) ? matched : null;
  const unknownNo = readNo && !matched && (!acc || norm(readNo) !== norm(acc.account_no));
  const open = () => { Linking.openURL(power ? UB.EFL_URL : UB.WAF_URL).catch(() => ui.toast('Could not open the browser')); };
  const save = () => {
    if (!pr.okToSave(ui)) return;
    if (!acc) { ui.alert({ title: 'Which account?', message: readNo ? `No bill account has the number ${readNo}. Choose the account below, or add it on the shop page.` : 'Choose the bill account below (or give the app a photo of the bill).', tone: 'warn' }); return; }
    if (other && other.uid !== acc.uid) { ui.alert({ title: 'Different account', message: `This bill is for ${other.label} (${other.shop_name || other.shop_code}), account ${other.account_no}. Tap "Use that account" first.`, tone: 'warn' }); return; }
    const r = act(() => UB.fileBillReading(user, { accountUid: acc.uid, accountNo: matched && matched.uid === acc.uid ? readNo : '', total: f.total, overdue: f.overdue, due: f.due, source: pr.read ? (pr.engine === 'ai' ? 'bill_ai' : 'bill_photo') : 'typed' }));
    if (!r) return;
    pr.log(user, 'utility_checks', r.uid, f, { total: 'total', overdue: 'overdue', due: 'due' });
    if (r.result === 'new_bill') ui.toast(r.invoice ? `Bill made for ${acc.shop_name || acc.shop_code} – it is in Invoices${r.higher ? ' (higher than usual!)' : ''}` : 'New bill noted – the person who pays bills acknowledges it');
    else ui.toast(r.result === 'paid' ? 'Nothing owing – noted' : 'Same bill as before – noted');
    nav.pop();
  };
  return (
    <Screen title={acc ? `${k.icon} ${acc.label}` : 'Read a bill'} subtitle={acc ? `${acc.shop_name || acc.shop_code} · account ${acc.account_no}` : 'EFL or WAF – photo, screenshot or PDF'}
      footer={<Btn testID="bc-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      {!params.uid ? (
        <Section title="Bill account">
          <Hint>{matched && !chosen ? `Found from the bill: ${matched.label} (${matched.shop_name || matched.shop_code}).` : 'Give the app the bill – the account number on it finds the account. Or choose it:'}</Hint>
          <Chips value={acc ? acc.uid : ''} onChange={(v) => setPick(v)} testIDPrefix="bc-acc" options={all.map((a) => ({ value: a.uid, label: `${UB.BILL_KIND[a.kind].icon} ${a.shop_code} ${a.label}` }))} />
        </Section>
      ) : null}
      {power && params.uid ? (
        <Card>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>1. Open EFL's bill checker</Text>
          <Text selectable testID="bc-accno" style={{ fontSize: 22, fontWeight: '900', color: C.text, letterSpacing: 1 }}>{acc.account_no}</Text>
          <Hint>Type (or paste) this account number on EFL's page, tick "I'm not a robot", tap CHECK, then take a screenshot of the result. A photo or PDF of the paper bill works too.</Hint>
          <Btn testID="bc-open" title="Open EFL bill checker" icon="🌐" size="md" variant="info" onPress={open} />
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, marginTop: 8 }}>2. Give the app the screenshot or the bill</Text>
        </Card>
      ) : acc && !power && params.uid ? <Hint>Water bills are checked by the app every day. Use this when WAF's check did not work, or for a paper bill.</Hint> : null}
      <PaperPhoto pr={pr} testID="bc-photo" label={power && params.uid ? 'Screenshot of EFL\'s result, or the bill' : 'Photo, screenshot or PDF of the bill'} value={f.photos} onChange={(v) => setF((o) => ({ ...o, photos: v }))} form={f} setForm={setF}
        map={{ total: 'total', overdue: 'overdue', due: 'due' }} labels={{ total: 'Total amount due', overdue: 'Overdue amount', due: 'Bill due on' }} hint="The amount, due date and account number fill in by themselves." />
      <MoneyField testID="bc-total" label="Total amount due" value={f.total} onChange={(v) => setF({ ...f, total: v })} />
      {power || !acc ? <MoneyField testID="bc-overdue" label="Overdue amount" value={f.overdue} onChange={(v) => setF({ ...f, overdue: v })} /> : null}
      <Field testID="bc-due" label="Bill due on (e.g. 19/10/2026)" value={f.due} onChangeText={(v) => setF({ ...f, due: v })} />
      {other && other.uid !== (acc && acc.uid) ? (
        <Banner testID="bc-other" tone="danger" title="Different account number" message={`The bill shows account ${readNo} – that is ${other.label} (${other.shop_name || other.shop_code}), not ${acc.label}.`} />
      ) : null}
      {other && other.uid !== (acc && acc.uid) ? <Btn testID="bc-use-other" title={`Use that account – ${other.label}`} size="sm" variant="secondary" onPress={() => setPick(other.uid)} /> : null}
      {unknownNo ? <Banner testID="bc-unknown" tone="warn" title="Account number not known" message={`The bill shows account ${readNo}, which is not one of the shops' bill accounts${acc ? ` (this one is ${acc.account_no})` : ''}. Check you have the right bill, or add the account on the shop page.`} /> : null}
      <Hint>{`Today ${dateStr()}. ${acc ? `A new amount becomes a bill in Invoices for ${acc.shop_name || acc.shop_code}` : 'A new amount becomes a bill in Invoices for the shop of the account'} (check its VAT against the bill). $0.00 means nothing is owing.`}</Hint>
    </Screen>
  );
}
