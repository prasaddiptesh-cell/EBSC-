// v3.9.8 Power & water bills: every EFL and WAF account of every shop, its latest bill and what to do.
// Water is checked by itself every day (main tablet); EFL is checked by a person (its checker has a robot box).
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ListItem, MoneyField, useAct } from '../../../ui/kit.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { dateStr } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import * as UB from '../../../services/utilityBills.js';

const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');
const STATE = { to_confirm: ['New bill – acknowledge it', 'warn'], overdue: ['Overdue', 'danger'], due_soon: ['Due soon', 'warn'], owing: ['To pay', 'info'], paid: ['Paid / nothing owing', 'success'], not_checked: ['Not checked yet', 'warn'] };

export function BillsScreen() {
  const { nav, user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [, bump] = useState(0);
  const [busy, setBusy] = useState(false);
  let board = [];
  try { board = UB.billBoard(); } catch (e) { board = []; }
  const checkWater = async () => {
    setBusy(true);
    try {
      const r = await UB.checkWaterBills({ force: true });
      ui.toast(r.checked ? `Water checked: ${r.checked} account${r.checked === 1 ? '' : 's'}${r.problems.length ? ` (${r.problems.length} problem${r.problems.length === 1 ? '' : 's'})` : ''}` : r.problems.length ? r.problems[0] : 'No water accounts with an account number yet');
    } catch (e) { ui.error(e); }
    setBusy(false); bump((n) => n + 1);
  };
  return (
    <Screen title="Power & water bills" subtitle="Every EFL and WAF account of every shop">
      <Explain>Water bills are checked by the app every day (WAF only needs the account number). EFL's bill checker has an "I'm not a robot" box, so once a month tap "Check EFL bill", tick the box on EFL's page, take a screenshot of the result and give it to the app here. A new bill is shown here first: tap "Acknowledge" and the bill is made in Invoices for that shop, ready to pay.</Explain>
      {!board.length ? <Banner tone="warn" title="No bill accounts yet" message="Add each shop's EFL and WAF account numbers on its shop page (Shops › the shop › Bill accounts)." /> : null}
      {board.some((b) => b.kind === 'water') ? <Btn testID="bills-check-water" title={busy ? 'Checking…' : 'Check the water bills now'} icon="💧" size="md" variant="secondary" disabled={busy} onPress={checkWater} /> : null}
      {board.map((b) => {
        const st = STATE[b.state] || STATE.not_checked;
        return (
          <Card key={b.uid} tone={st[1] === 'danger' ? 'danger' : st[1] === 'warn' ? 'warn' : undefined}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`${b.icon} ${b.shopName || b.shop} – ${b.label}`}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>{`Account ${b.accountNo} · ${b.auto ? 'checked by the app every day' : 'checked by a person once a month'}`}</Text>
            <Text testID={`bill-state-${b.uid}`} style={{ fontSize: 16, fontWeight: '700', color: C[st[1]] || C.text }}>{`${st[0]}${b.owing ? ` · ${$(b.owing)}` : b.total !== null && b.total !== undefined ? ` · ${$(b.total)}` : ''}${b.due ? ` · due ${d(b.due)}` : ''}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{b.lastChecked ? `Last checked ${String(b.lastChecked).slice(0, 16)}${b.daysSince ? ` (${b.daysSince} day${b.daysSince === 1 ? '' : 's'} ago)` : ''}` : 'Never checked'}</Text>
            {b.state === 'to_confirm' ? (
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
                <Btn testID={`bill-ack-${b.uid}`} title={`Acknowledge – make the bill ${$(b.total)}`} icon="✅" size="sm" variant="success" onPress={() => { if (act(() => UB.acknowledgeBill(user, b.checkUid), 'Bill made – it is in Invoices')) bump((n) => n + 1); }} />
                <Btn testID={`bill-aside-${b.uid}`} title="No bill needed" size="sm" variant="ghost" onPress={async () => { const ok = await ui.confirm({ title: 'No bill needed?', message: 'Put this check aside without making a bill (e.g. it was already entered).', confirmText: 'Put aside' }); if (ok && act(() => UB.putAsideBill(user, b.checkUid, 'Already entered / not needed'), 'Put aside')) bump((n) => n + 1); }} />
              </View>
            ) : null}
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
              {b.kind === 'power' ? <Btn testID={`bill-efl-${b.uid}`} title="Check EFL bill" icon="⚡" size="sm" variant="info" onPress={() => nav.push('BillCheck', { uid: b.uid })} /> : <Btn testID={`bill-enter-${b.uid}`} title="Enter it by hand" size="sm" variant="ghost" onPress={() => nav.push('BillCheck', { uid: b.uid })} />}
              {b.invoiceUid ? <Btn testID={`bill-inv-${b.uid}`} title="Open the bill" size="sm" variant="secondary" onPress={() => nav.push('ApInvoice', { uid: b.invoiceUid })} /> : null}
            </View>
          </Card>
        );
      })}
    </Screen>
  );
}

// One check: EFL (screenshot or typed) or a water bill typed by hand.
export function BillCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const acc = UB.billAccounts().find((a) => a.uid === params.uid);
  const pr = usePaper('efl_bill');
  const [f, setF] = useState({ total: '', overdue: '', due: '', photos: [] });
  if (!acc) return <Screen title="Bill"><Banner tone="danger" message="That bill account was not found (it needs an account number on the shop page)." /></Screen>;
  const k = UB.BILL_KIND[acc.kind];
  const power = acc.kind === 'power';
  const open = () => { Linking.openURL(power ? UB.EFL_URL : UB.WAF_URL).catch(() => ui.toast('Could not open the browser')); };
  const save = () => {
    if (!pr.okToSave(ui)) return;
    const r = act(() => UB.recordCheck(user, acc.uid, { total: f.total, overdue: f.overdue, due: f.due, source: pr.read ? 'efl_screenshot' : 'typed' }));
    if (!r) return;
    pr.log(user, 'utility_checks', r.uid, f, { total: 'total', overdue: 'overdue', due: 'due' });
    if (r.result === 'new_bill') {
      // The person entering it acknowledges it straight away when they may pay bills; otherwise it waits for them.
      let made = false;
      try { UB.acknowledgeBill(user, r.uid); made = true; } catch (e) { made = false; }
      ui.toast(made ? `Bill made – it is in Invoices${r.higher ? ' (higher than usual!)' : ''}` : 'New bill noted – the person who pays bills acknowledges it');
    } else ui.toast(r.result === 'paid' ? 'Nothing owing – noted' : 'Same bill as before – noted');
    nav.back();
  };
  return (
    <Screen title={`${k.icon} ${acc.label}`} subtitle={`${acc.shop_name || acc.shop_code} · account ${acc.account_no}`}
      footer={<Btn testID="bc-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      {power ? (
        <Card>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>1. Open EFL's bill checker</Text>
          <Text selectable testID="bc-accno" style={{ fontSize: 22, fontWeight: '900', color: C.text, letterSpacing: 1 }}>{acc.account_no}</Text>
          <Hint>Type (or paste) this account number on EFL's page, tick "I'm not a robot", tap CHECK, then take a screenshot of the result.</Hint>
          <Btn testID="bc-open" title="Open EFL bill checker" icon="🌐" size="md" variant="info" onPress={open} />
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, marginTop: 8 }}>2. Give the app the screenshot</Text>
        </Card>
      ) : <Hint>Water bills are checked by the app every day. Use this only if WAF's check did not work.</Hint>}
      <PaperPhoto pr={pr} testID="bc-photo" label={power ? 'Screenshot of EFL\'s result' : 'Photo of the bill'} value={f.photos} onChange={(v) => setF((o) => ({ ...o, photos: v }))} form={f} setForm={setF}
        map={{ total: 'total', overdue: 'overdue', due: 'due' }} labels={{ total: 'Total amount due', overdue: 'Overdue amount', due: 'Bill due on' }} hint="The figures fill in by themselves." />
      <MoneyField testID="bc-total" label="Total amount due" value={f.total} onChange={(v) => setF({ ...f, total: v })} />
      {power ? <MoneyField testID="bc-overdue" label="Overdue amount" value={f.overdue} onChange={(v) => setF({ ...f, overdue: v })} /> : null}
      <Field testID="bc-due" label="Bill due on (e.g. 19/10/2026)" value={f.due} onChangeText={(v) => setF({ ...f, due: v })} />
      {pr.read && pr.read.fields && pr.read.fields.accountNo && String(pr.read.fields.accountNo) !== String(acc.account_no).replace(/\s/g, '') ? (
        <Banner tone="danger" title="Different account number" message={`The screenshot shows account ${pr.read.fields.accountNo}, not ${acc.account_no}. Check you have the right account.`} />
      ) : null}
      <Hint>{`Today ${dateStr()}. A new amount becomes a bill in Invoices for ${acc.shop_name || acc.shop_code} (check its VAT against the bill). $0.00 means nothing is owing.`}</Hint>
    </Screen>
  );
}
