// v3.9.6 Delete (owner / admin) and the Deleted bin: what a delete takes with it, what stops it, a second "yes" for
// a filed VAT month, then 90 days in the bin with "Put back".
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Chips, Badge, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ListItem } from '../../../ui/kit.js';
import * as BIN from '../../../services/bin.js';

const when = (s) => String(s || '').slice(0, 16).replace('T', ' ');

// A small button for record screens: the owner / admin only.
export function DeleteButton({ table, keyVal, title = 'Delete', back = 2, size = 'sm', testID = 'del-open' }) {
  const { user, nav } = useApp();
  if (!BIN.canDelete(user) || !keyVal) return null;
  return <Btn testID={testID} title={title} icon="🗑️" size={size} variant="ghost" onPress={() => nav.push('DeleteRecord', { table, keyVal: String(keyVal), back })} />;
}

export function DeleteRecordScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [reason, setReason] = useState('');
  const [sure, setSure] = useState('');
  if (!BIN.canDelete(user)) return <Screen title="Delete"><Banner tone="info" message="Only the owner or an admin can delete records." /></Screen>;
  let plan = null; let err = null;
  try { plan = BIN.deletePlan(params.table, params.keyVal); } catch (e) { err = e.message || String(e); }
  if (!plan) return <Screen title="Delete"><Banner testID="del-error" tone="warn" message={err} /></Screen>;
  const blocked = plan.blocks.length > 0;
  const go = async () => {
    if (plan.closed && sure !== 'yes') { ui.error({ isAppError: true, message: 'Tick "Yes – I will tell the accountant" first.' }); return; }
    const ok = await ui.confirm({ title: 'Move to the Deleted bin?', message: `${plan.title}${plan.alsoGoes.length ? `\n\nWith it: ${plan.alsoGoes.join(', ')}` : ''}\n\nIt goes off every device. You can put it back from the Deleted bin for ${BIN.KEEP_DAYS} days.`, confirmText: 'Delete', tone: 'danger' });
    if (!ok) return;
    try {
      BIN.deleteRecord(user, params.table, params.keyVal, { reason, confirmClosed: sure === 'yes' });
      ui.toast(`In the Deleted bin for ${BIN.KEEP_DAYS} days`);
      const n = Math.max(1, Math.min(4, Number(params.back) || 1));
      for (let k = 0; k < n; k += 1) nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Delete" subtitle={plan.title}
      footer={blocked ? null : <Btn testID="del-go" title="Move to Deleted bin" icon="🗑️" variant="danger" onPress={go} />}>
      {blocked ? (
        <Banner testID="del-blocked" tone="danger" title="It cannot be deleted yet" message={`These still use it:\n• ${plan.blocks.slice(0, 12).join('\n• ')}${plan.blocks.length > 12 ? `\n• … and ${plan.blocks.length - 12} more` : ''}\n\nDelete those first (each goes to the bin too), or void it instead.`} />
      ) : (
        <Banner testID="del-ok" tone="info" message={`It is taken off every device and waits in the Deleted bin for ${BIN.KEEP_DAYS} days. "Put back" brings it back exactly as it was.`} />
      )}
      {plan.alsoGoes.length ? (
        <Section title="Goes with it (what it did is undone)">
          {plan.alsoGoes.map((x) => <Text key={x} style={{ fontSize: 16, color: C.text }}>{`• ${x}`}</Text>)}
        </Section>
      ) : null}
      {plan.unlink.length ? (
        <Section title="Links that are cleared (those records stay)">
          {plan.unlink.slice(0, 20).map((u) => <Text key={`${u.t}-${u.k}-${u.col}`} style={{ fontSize: 15, color: C.sub }}>{`• ${BIN.labelOf(u.t)}`}</Text>)}
        </Section>
      ) : null}
      {plan.closed && !blocked ? (
        <Card tone="warn">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Filed month</Text>
          <Text style={{ fontSize: 15, color: C.text }}>{plan.closed.why}</Text>
          <Chips value={sure} onChange={setSure} testIDPrefix="del-sure" options={[{ value: 'yes', label: 'Yes – I will tell the accountant' }]} />
        </Card>
      ) : null}
      {!blocked ? <Field testID="del-reason" label="Why (optional – kept in the change history)" value={reason} onChangeText={setReason} /> : null}
    </Screen>
  );
}

export function DeletedBinScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [show, setShow] = useRemembered('bin-show', 'binned');
  const [q, setQ] = useState('');
  const [, bump] = useState(0);
  const list = BIN.listBin({ status: show, q });
  const may = BIN.canDelete(user);
  const putBack = async (b) => {
    if (b.tbl === 'devices') { nav.push('Devices', {}); return; }
    let sure = false;
    if (b.closed_period) sure = await ui.confirm({ title: 'Filed month', message: 'It is in a month whose VAT return is filed or whose books are closed. Putting it back changes that month – tell the accountant.', confirmText: 'Put back' });
    else sure = await ui.confirm({ title: 'Put it back?', message: `${b.title}${b.summary ? `\n\nWith: ${b.summary}` : ''}`, confirmText: 'Put back' });
    if (!sure) return;
    try { BIN.restoreRecord(user, b.uid, { confirmClosed: !!b.closed_period }); ui.toast('Put back'); bump((n) => n + 1); } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Deleted bin" subtitle={`Kept ${BIN.KEEP_DAYS} days, then gone for good`}>
      <Explain>Records deleted by the owner or an admin wait here for {BIN.KEEP_DAYS} days. "Put back" brings a record back exactly as it was, with everything that went with it. After {BIN.KEEP_DAYS} days it is gone for good – also from the cloud copy. Every delete and put-back is in the change history.</Explain>
      <Chips value={show} onChange={setShow} testIDPrefix="bin-show" options={[{ value: 'binned', label: 'In the bin' }, { value: 'restored', label: 'Put back' }, { value: 'gone', label: 'Gone for good' }]} />
      <Field testID="bin-q" label="Find" value={q} onChangeText={setQ} placeholder="invoice number, supplier, person…" />
      {!list.length ? <Hint testID="bin-empty">{show === 'binned' ? 'The bin is empty.' : 'Nothing here.'}</Hint> : null}
      {list.map((b) => (
        <Card key={b.uid}>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flex: 1, minWidth: 220, gap: 2 }}>
              <Text testID={`bin-item-${b.rkey}`} style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{b.title}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{`Deleted by ${b.deleted_by_name || '–'} · ${when(b.deleted_at)}${b.reason ? ` · "${b.reason}"` : ''}`}</Text>
              {b.summary ? <Text style={{ fontSize: 14, color: C.sub }}>{`With: ${b.summary}`}</Text> : null}
              {b.status === 'restored' ? <Text style={{ fontSize: 14, color: C.success }}>{`Put back by ${b.restored_by_name || '–'} · ${when(b.restored_at)}`}</Text> : null}
              {b.status === 'gone' ? <Text style={{ fontSize: 14, color: C.sub }}>{`Gone for good · ${when(b.gone_at)}`}</Text> : null}
            </View>
            <View style={{ alignItems: 'flex-end', gap: 6 }}>
              {b.status === 'binned' ? <Badge text={`${b.daysLeft} day${b.daysLeft === 1 ? '' : 's'} left`} color={b.daysLeft <= 7 ? C.danger : C.sub} /> : null}
              {b.closed_period ? <Badge text="Filed month" color={C.warn} /> : null}
              {may && b.status === 'binned' ? (
                b.tbl === 'devices'
                  ? <Btn testID={`bin-link-${b.rkey}`} title="Link again (invite)" size="sm" variant="secondary" onPress={() => putBack(b)} />
                  : b.ready ? <Btn testID={`bin-back-${b.rkey}`} title="Put back" icon="↩️" size="sm" variant="secondary" onPress={() => putBack(b)} /> : <Text style={{ fontSize: 13, color: C.sub }}>Copy still coming – sync</Text>
              ) : null}
            </View>
          </View>
        </Card>
      ))}
    </Screen>
  );
}
