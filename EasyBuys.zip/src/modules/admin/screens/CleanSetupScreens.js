// 1.0.0 build 1: the guided set-up (15 steps, in the owner's order), Start clean (owner only, PIN again, Drive backup
// first) and the first-run screen of an empty app (make the owner login, or link to Easy Buys).
// Exported for the shell: GuidedSetupScreen (screen name "GuidedSetup"), StartCleanScreen ("StartClean"),
// FirstRunScreen (shown by the login screen when the app has no logins yet).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import * as SW from '../../../services/setupWizard.js';
import * as CS from '../../../services/cleanStart.js';

// ---------------------------------------------------------------- guided set-up
export function GuidedSetupScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [pack, setPack] = useState(null);
  const [busy, setBusy] = useState('');
  const refresh = () => bump((x) => x + 1);
  let steps = [];
  try { steps = SW.guidedSteps(); } catch (e) { steps = []; }
  const cur = SW.guidedCurrent(steps);
  const done = steps.filter((s) => s.done).length;
  const pct = steps.length ? Math.round((done / steps.length) * 100) : 0;
  const fetchPack = async () => {
    setBusy('Getting the set-up pack from Google Drive…');
    try {
      const { cloudCall } = require('../../../platform/cloud.js');
      const { xlsxSheets } = require('../../../platform/statementFiles.js');
      const r = await SW.packFromCloud(user, { cloud: (b) => cloudCall(b, 120000), xlsxSheets });
      setPack(r);
    } catch (e) { ui.error(e); }
    setBusy('');
  };
  const loadPack = () => {
    try { const d = SW.loadPack(user, pack.preview); setPack(null); ui.toast(`Loaded: ${d.suppliers} suppliers, ${d.products} products matched${d.waiting ? `, ${d.waiting} waiting for their products` : ''}`); refresh(); } catch (e) { ui.error(e); }
  };
  const tick = (s, v) => { try { SW.tickGuided(user, s.key, v); refresh(); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Set up step by step" subtitle={`${done} of ${steps.length} done`}>
      <View style={{ height: 10, borderRadius: 5, backgroundColor: C.border }}><View style={{ width: `${pct}%`, height: 10, borderRadius: 5, backgroundColor: C.success }} /></View>
      {cur ? (
        <Card tone="info">
          <Text testID="gs-now" style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{`Next: step ${cur.no}`}</Text>
          <Text testID="gs-title" style={{ fontSize: 22, fontWeight: '900', color: C.text }}>{cur.title}</Text>
          <Text style={{ fontSize: 16, color: C.text, marginTop: 4 }}>{cur.why}</Text>
          {cur.progress ? <Text testID="gs-progress" style={{ fontSize: 15, color: C.sub, marginTop: 4 }}>{cur.progress}</Text> : null}
          <View style={{ gap: 8, marginTop: 10 }}>
            {cur.action === 'pack'
              ? <Btn testID="gs-pack" title={busy || 'Load the suppliers from the set-up pack'} icon="📥" variant="primary" disabled={!!busy} onPress={fetchPack} />
              : <Btn testID="gs-open" title="Open – do this step" icon="📂" variant="primary" onPress={() => nav.push(cur.screen, {})} />}
            {cur.also ? <Btn testID="gs-also" title={cur.also.title} size="md" variant="secondary" onPress={() => nav.push(cur.also.screen, {})} /> : null}
            {cur.canTick || !cur.counted ? <Btn testID="gs-tick" title="It is done" size="md" variant="ghost" onPress={() => tick(cur, 'done')} /> : null}
          </View>
        </Card>
      ) : <Banner testID="gs-finished" tone="success" title="The set-up is done" message="Every step is done. You can come back here any time from Settings › Set up step by step." />}
      {pack ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`From Google Drive: ${pack.name}`}</Text>
          <Text testID="gs-pack-preview" style={{ fontSize: 16, color: C.text }}>{`${(pack.preview.suppliers || []).length} suppliers · ${(pack.preview.products || []).length} supplier products${(pack.preview.products || []).filter((r) => r.action === 'wait').length ? ` (${(pack.preview.products || []).filter((r) => r.action === 'wait').length} wait for their Aronium product)` : ''}`}</Text>
          <Btn testID="gs-pack-load" title="Load them" icon="✅" variant="success" onPress={loadPack} />
        </Card>
      ) : null}
      <Explain>Do the steps in this order – each needs the ones before it. All products come from Aronium (the till PCs); the app never makes products. A ✅ shows when the app sees a step is done.</Explain>
      {steps.map((s) => (
        <Pressable key={s.key} testID={`gs-step-${s.key}`} onPress={() => (s.action === 'pack' ? fetchPack() : nav.push(s.screen, {}))} style={{ flexDirection: 'row', gap: 10, alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border }}>
          <Text testID={`gs-mark-${s.key}`} style={{ fontSize: 22 }}>{s.done ? '✅' : cur && cur.key === s.key ? '👉' : '⬜'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: cur && cur.key === s.key ? '800' : '600', color: C.text }}>{`${s.no}. ${s.title}`}</Text>
            {s.progress ? <Text style={{ fontSize: 14, color: C.sub }}>{s.progress}</Text> : null}
          </View>
        </Pressable>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- Start clean
export function StartCleanScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [pin, setPin] = useState('');
  const [typed, setTyped] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const owner = user && (user.role === 'owner' || user.realRole === 'owner');
  if (!owner) return <Screen title="Start clean"><Banner tone="danger" title="Owner only" message="Only the owner can start clean." /></Screen>;
  let summary = [];
  try { summary = CS.cleanSummary(); } catch (e) { summary = []; }
  const total = summary.reduce((s, x) => s + x.rows, 0);
  const go = async () => {
    const ok = await ui.confirm({ title: 'Start clean?', message: `Everything in the app is cleared on every device and in the cloud (${total} records here). A backup goes to Google Drive first. This cannot be undone in the app.`, confirmText: 'Start clean', tone: 'danger' });
    if (!ok) return;
    setBusy(true);
    try {
      const { cloudCall } = require('../../../platform/cloud.js');
      const r = await CS.startClean(user, { pin, typed }, {
        backup: async ({ fileName }) => {
          const { dumpDatabase } = require('../../../platform/cloud.js');
          return cloudCall({ kind: 'backup', tier: 'manual', fileName, data: JSON.stringify({ _cleanStart: true, ...dumpDatabase() }) }, 300000);
        },
        cloud: (b) => cloudCall(b, 300000),
      });
      setDone(r);
    } catch (e) { ui.error(e); }
    setPin(''); setBusy(false);
  };
  if (done) {
    return (
      <Screen title="Start clean">
        <Banner testID="sc-done" tone="success" title="The app is clean" message={`${done.removed} records were cleared here and ${done.cloud.cleared || 0} in the cloud. The backup is in Google Drive › Backups; the old Drive folders are in "${done.cloud.oldFolder || 'Before 1.0.0 – old and test data'}".`} />
        <Btn testID="sc-setup" title="Set up step by step" icon="🧭" variant="success" onPress={() => nav.push('GuidedSetup', {})} />
      </Screen>
    );
  }
  return (
    <Screen title="Start clean" subtitle="🔒 Owner only">
      <Banner tone="danger" title="Everything goes" message="Sales, stock, invoices, cheques, staff (except the owner logins), settings – on every device and in the cloud. Use it once, to start the new app with nothing old in it." />
      <Text testID="sc-drive" style={{ fontSize: 16, color: C.text, lineHeight: 23 }}>{CS.DRIVE_SENTENCE}</Text>
      <Text testID="sc-total" style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${total} records on this device`}</Text>
      <Field testID="sc-pin" label="Your PIN again" value={pin} secure keyboardType="number-pad" maxLength={6} onChangeText={(v) => setPin(v.replace(/\D/g, ''))} />
      <Field testID="sc-typed" label={`Type ${CS.CLEAN_WORD}`} value={typed} onChangeText={setTyped} />
      <Hint>The internet must be on: the backup goes to Google Drive before anything is cleared. If the backup does not work, nothing is cleared.</Hint>
      <Btn testID="sc-go" title={busy ? 'Working…' : 'Back up, then start clean'} icon="🧹" variant="danger" disabled={busy || pin.length < 4 || typed.trim().toUpperCase() !== CS.CLEAN_WORD} onPress={go} />
    </Screen>
  );
}

// ---------------------------------------------------------------- first run (no logins yet)
export function needsFirstRun() {
  try { return require('../../../db/connection.js').db().get("SELECT COUNT(*) AS n FROM users WHERE active = 1").n === 0; } catch (e) { return false; }
}
export function FirstRunScreen({ onLogin, onLink }) {
  const [name, setName] = useState('');
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [err, setErr] = useState('');
  const make = () => {
    setErr('');
    try {
      if (!name.trim()) throw new Error('Type your name.');
      if (!/^\d{4,6}$/.test(pin)) throw new Error('Choose a PIN of 4 to 6 numbers.');
      if (pin !== pin2) throw new Error('The two PINs are not the same.');
      const { saveUser, login } = require('../../../services/catalog.js');
      saveUser({ name: name.trim(), pin, role: 'owner' }, null);
      const u = login(pin);
      if (u && onLogin) onLogin(u, { firstRun: true });
    } catch (e) { setErr(e && e.message ? e.message : String(e)); }
  };
  return (
    <View testID="first-run" style={{ flex: 1, padding: 20, gap: 12, backgroundColor: C.bg, justifyContent: 'center', maxWidth: 560, width: '100%', alignSelf: 'center' }}>
      <Text style={{ fontSize: 28, fontWeight: '900', color: C.text, textAlign: 'center' }}>Welcome to Easy Buys</Text>
      <Text style={{ fontSize: 17, color: C.text, textAlign: 'center' }}>The app is empty. Make the owner login first – then the app takes you through the set-up step by step.</Text>
      <Field testID="fr-name" label="Owner's name" value={name} onChangeText={setName} />
      <Field testID="fr-pin" label="Choose a PIN (4–6 numbers)" value={pin} secure keyboardType="number-pad" maxLength={6} onChangeText={(v) => setPin(v.replace(/\D/g, ''))} />
      <Field testID="fr-pin2" label="The same PIN again" value={pin2} secure keyboardType="number-pad" maxLength={6} onChangeText={(v) => setPin2(v.replace(/\D/g, ''))} />
      {err ? <Text testID="fr-error" style={{ color: C.danger, fontSize: 16, fontWeight: '700' }}>{err}</Text> : null}
      <Btn testID="fr-make" title="Make the owner login" icon="👤" variant="success" onPress={make} />
      {onLink ? <Btn testID="fr-link" title="This device joins an Easy Buys that is set up already" icon="🔗" variant="secondary" onPress={onLink} /> : null}
    </View>
  );
}
