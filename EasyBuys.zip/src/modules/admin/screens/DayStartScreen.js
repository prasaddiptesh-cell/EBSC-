// v3.9.8 Start the day (owner / admin): money now, coming in, going out, the week's outlook, orders to place, who is
// away and the urgent warnings – one page to begin the day with. Also as a PDF (Reports › Business insight).
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Stats, Hint } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { startOfDay } from '../../../services/dayStart.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export function DayStartScreen() {
  const { user, nav } = useApp();
  const [n, bump] = useState(0);
  const d = useMemo(() => { try { return startOfDay(dateStr(), user); } catch (e) { return { error: e.message }; } }, [n]);
  if (d.error) return <Screen title="Start the day"><Banner tone="danger" message={d.error} /></Screen>;
  const b = d.money.bank;
  const go = d.goingOut;
  return (
    <Screen title="Start the day" subtitle={`${d.day} ${d.today}`}
      footer={<Btn testID="ds-pdf" title="PDF / share" icon="📄" variant="primary" onPress={() => nav.push('ReportView', { kind: 'biz_day', from: d.today, to: d.today })} />}>
      <Banner testID="ds-outlook" tone={d.outlook.gap < 0 ? 'warn' : 'success'} title="This week" message={d.outlook.text} />
      <Stats items={[
        b ? { label: 'Bank – our cheque book', value: $(b.book), sub: `Bank should show ${$(b.inBank)}`, onPress: () => nav.push('BankRec', {}) } : null,
        { label: 'M-PAiSA wallets', value: $(d.money.walletTotal), sub: d.money.wallets.map((w) => `${w.shop} ${$(w.balance)}`).join(' · ') || null },
        { label: 'Cash at the shops', value: $(d.money.cashTotal), sub: d.money.cash.map((c) => `${c.shop} ${$(c.onHand)}`).join(' · ') || null },
        { label: `Sales expected today`, value: $(d.comingIn.sales.total), sub: d.comingIn.sales.weeks ? `average of the last ${d.comingIn.sales.weeks} ${d.day}s` : 'not enough history yet' },
      ]} />

      {b ? (
        <Section title="Bank">
          <ListItem testID="ds-given" title={`Cheques given, not in the bank yet: ${b.givenNotCleared.count}`} right={$(b.givenNotCleared.total)} sub={b.givenNotCleared.oldest ? `oldest ${b.givenNotCleared.oldest}` : undefined} tone={b.stale ? 'warn' : undefined} onPress={() => nav.push('ReportView', { kind: 'biz_cheques', from: '2000-01-01', to: d.today })} />
          <ListItem title={`Cheques written, not handed over yet: ${b.writtenNotGiven.count}`} right={$(b.writtenNotGiven.total)} />
          {b.inTransit ? <ListItem title="Deposits on their way to the bank" right={$(b.inTransit)} /> : null}
          <ListItem title="Balance last checked in the bank app" right={b.lastChecked ? $(b.lastChecked.typed) : '–'} sub={b.lastChecked ? `${b.lastChecked.date}${b.lastChecked.diff ? ` · differs by ${$(b.lastChecked.diff)}` : ' · agreed'}` : 'Not checked yet – check it in the BSP app'} tone={b.lastChecked && Math.abs(b.lastChecked.diff) > 0.01 ? 'warn' : undefined} />
        </Section>
      ) : <Hint>Add the bank account (Money & accounts › Bank) to see the bank here.</Hint>}

      <Section title="Going out">
        <ListItem testID="ds-overdue" title={`Invoices overdue: ${go.overdue.count}`} right={$(go.overdue.total)} tone={go.overdue.count ? 'danger' : undefined} onPress={() => nav.push('ApInvoices', { filter: 'overdue' })} />
        <ListItem title={`Due today: ${go.today.count}`} right={$(go.today.total)} tone={go.today.count ? 'warn' : undefined} onPress={() => nav.push('ApInvoices', { filter: 'due' })} />
        <ListItem title={`Due in the next 6 days: ${go.week.count}`} right={$(go.week.total)} />
        {go.regular.map((r) => <ListItem key={`${r.name}${r.next_date}`} title={`${r.kind === 'loan' ? 'Loan' : 'Regular bill'}: ${r.name}`} sub={`due ${r.next_date}`} right={$(r.amount)} />)}
        {go.bills.map((x) => <ListItem key={x.uid} title={`${x.icon} ${x.shop} ${x.label}`} sub={x.state === 'to_confirm' ? 'New bill – acknowledge it' : x.due ? `due ${x.due}` : ''} right={x.total ? $(x.total) : x.owing ? $(x.owing) : ''} tone={x.state === 'overdue' ? 'danger' : 'warn'} onPress={() => nav.push('Bills', {})} />)}
        {go.wages ? <ListItem title={`Wages on pay day ${go.wages.payDay}`} sub={`about the last ${go.wages.from} pay runs`} right={$(go.wages.expected)} /> : null}
        {go.tax.map((t) => <ListItem key={t.title} title={t.title} sub={`due ${t.due}`} right={t.amount !== null ? $(t.amount) : ''} tone={t.overdue ? 'danger' : 'warn'} onPress={() => nav.push('TaxCalendar', {})} />)}
      </Section>

      <Section title="Coming in">
        <ListItem title={`Staff owe us (${d.comingIn.staffPeople})`} right={$(d.comingIn.staffOwe)} onPress={() => nav.push('Owed', {})} />
        <ListItem title={`Customers on account (${d.comingIn.customers})`} right={$(d.comingIn.customersOwe)} onPress={() => nav.push('CustomerAccounts', {})} />
        <ListItem title="Sales expected this week" right={$(d.comingIn.sales.weekTotal)} sub={d.comingIn.sales.week.map((w) => `${w.day.slice(0, 3)} ${$(w.expected)}`).join(' · ')} />
      </Section>

      <Section title="Orders to place">
        {!d.orders.due.length && !d.orders.fromHistory.length && !d.orders.low.length ? <Hint>No orders due today.</Hint> : null}
        {d.orders.due.map((o, i) => <ListItem key={`d${i}`} title={o.text} sub={o.sub || undefined} tone="warn" onPress={() => nav.push('TodaysOrders', {})} />)}
        {d.orders.fromHistory.map((o) => <ListItem key={`h${o.supplierUid}${o.shop}`} title={`${o.name} · ${o.shop}`} sub={`usually every ${o.every} days, about ${$(o.usual)} – last ${o.last}`} onPress={() => nav.push('TodaysOrders', {})} />)}
        {d.orders.low.slice(0, 8).map((o) => <ListItem key={`l${o.supplier}${o.shop}`} title={`${o.supplier} · ${o.shop}: ${o.items} item${o.items === 1 ? '' : 's'} low`} right={$(o.value)} onPress={() => nav.push('AroniumInsights', {})} />)}
      </Section>

      {d.people.leave.length ? (
        <Section title="Away today">
          {d.people.leave.map((p, i) => <ListItem key={i} title={p.name || 'Someone'} sub={`on leave ${p.from_date} – ${p.to_date}`} />)}
        </Section>
      ) : null}

      {d.urgent.length ? (
        <Section title="Urgent">
          {d.urgent.map((a, i) => <ListItem key={i} title={a.text} sub={a.sub || undefined} tone="danger" onPress={a.nav ? () => nav.push(a.nav.screen, a.nav.params || {}) : undefined} />)}
        </Section>
      ) : null}
      <Btn testID="ds-refresh" title="Refresh" size="sm" variant="ghost" onPress={() => bump((x) => x + 1)} />
    </Screen>
  );
}
