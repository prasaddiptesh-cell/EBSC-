// Release 36: Settings › Diagnostics – this device's pick-up points (services/diagnostics.js): every module's health,
// the last problems, and "Send to support now" (the report goes to the cloud; no names or figures in it).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { collectDiagnostics, sendDiagnostics } from '../../../services/diagnostics.js';

const TONE = { ok: ['✓', C.success], warn: ['!', C.warn], problem: ['✗', C.danger] };
export function DiagnosticsScreen() {
  useApp();
  const ui = useUI();
  const [n, setN] = useState(0);
  const [busy, setBusy] = useState(false);
  let r = null;
  try { r = collectDiagnostics(); } catch (e) { r = { checks: [], errors: [], summary: 'problem', error: e.message }; }
  return (
    <Screen title="Diagnostics" subtitle={`This device · ${r.summary === 'ok' ? 'all fine' : r.summary === 'warn' ? 'something to look at' : 'a problem'}`}>
      <Hint>Each part of the app checks itself here. The report also goes to the cloud about every hour so support can see it – it has counts and states only (no names, amounts or customer details).</Hint>
      <Btn testID="diag-send" title={busy ? 'Sending…' : 'Send to support now'} icon="📤" variant="primary" disabled={busy} onPress={async () => {
        setBusy(true);
        try { const x = await sendDiagnostics({ force: true }); if (x && x.ok) ui.toast('Sent to support'); else ui.error(new Error((x && x.error) || 'The cloud did not answer – it goes with the next sync.')); } catch (e) { ui.error(e); }
        setBusy(false); setN(n + 1);
      }} />
      {r.checks.map((c) => (
        <Card key={c.module} testID={`diag-${c.module}`}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ fontSize: 18, fontWeight: '900', color: TONE[c.level][1] }}>{TONE[c.level][0]}</Text>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, flex: 1 }}>{c.module}</Text>
            <Text style={{ fontSize: 12, color: C.sub }}>{`${c.ms} ms`}</Text>
          </View>
          {(c.notes || []).map((x) => <Text key={x} style={{ fontSize: 15, color: C.text }}>{`• ${x}`}</Text>)}
          {Object.keys(c.counts || {}).length ? <Text style={{ fontSize: 13, color: C.sub }}>{Object.entries(c.counts).map(([k, v]) => `${k} ${v === null ? '–' : v}`).join(' · ')}</Text> : null}
        </Card>
      ))}
      <Card>
        <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`Last problems (${r.errors.length})`}</Text>
        {!r.errors.length ? <Text style={{ fontSize: 15, color: C.success }}>None recorded.</Text> : null}
        {r.errors.slice(0, 10).map((e, i) => <Text key={i} style={{ fontSize: 14, color: e.fatal ? C.danger : C.text, marginTop: 4 }}>{`${String(e.at).slice(5, 16)} · ${e.screen || e.where || ''}: ${e.message}`}</Text>)}
      </Card>
    </Screen>
  );
}
