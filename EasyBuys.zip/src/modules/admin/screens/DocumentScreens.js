// Documents: every document filed in Google Drive (search, upload status, try again), one document's details, checking a
// printed document's barcode (genuine / changed), the layout designer per type, who may see each type, and settings.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Badge, Chips, Field, Row, Section, NumberField, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { actsAsOwner, ROLES, ROLE_LABEL } from '../../../services/access.js';
import { DOC_TYPES, PARTS, PAPERS, LOOKS, PLACEHOLDERS, getDesign, saveDesign, resetDesign, designVersions, restoreDesignVersion, movePart, togglePart, addText, removeText, docType } from '../../../services/docDesign.js';
import { docSettings, saveDocSettings, docVisibility, saveDocVisibility, listDriveDocuments, uploadCounts, retryUpload, describeDocument, canSeeDocument, mainTabletId, setMainTablet } from '../../../services/driveDocs.js';
import { verifyDocCode, listIssued } from '../../../services/issuedDocs.js';
import { deviceId } from '../../../services/core.js';
import { openDocument } from '../../../platform/docFiles.js';

const STATUS = { verified: ['In Drive ✓', C.success], pending: ['Waiting to upload', C.warn], uploading: ['Uploading…', C.info], failed: ['Upload problem', C.danger], login: ['Device not linked', C.danger], unchecked: ['In Drive (not checked)', C.warn] };

export function DocumentsScreen() {
  const { user, nav } = useApp();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [type, setType] = useState('all');
  let list = []; let counts = {};
  try { list = listDriveDocuments(user, { q, status, type, limit: 150 }); counts = uploadCounts(); } catch (e) { list = []; }
  return (
    <Screen title="Documents" subtitle="Everything filed in Google Drive">
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
        <Badge text={`${counts.verified || 0} in Drive`} color={C.success} />
        {(counts.pending || 0) + (counts.uploading || 0) ? <Badge text={`${(counts.pending || 0) + (counts.uploading || 0)} waiting`} color={C.warn} /> : null}
        {(counts.failed || 0) + (counts.login || 0) ? <Badge text={`${(counts.failed || 0) + (counts.login || 0)} problems`} color={C.danger} /> : null}
      </View>
      <Field testID="docs-q" label="Find (name, supplier / person, number, date, amount)" value={q} onChangeText={setQ} />
      <Chips value={status} onChange={setStatus} testIDPrefix="docs-status" options={[{ value: 'all', label: 'All' }, { value: 'waiting', label: 'Waiting' }, { value: 'problem', label: 'Problems' }, { value: 'verified', label: 'In Drive' }]} />
      <Chips value={type} onChange={setType} testIDPrefix="docs-type" options={[{ value: 'all', label: 'All types' }].concat(DOC_TYPES.map((t) => ({ value: t.id, label: `${t.icon} ${t.label}` })))} />
      {!list.length ? <Hint>No documents found.</Hint> : null}
      {list.map((d) => {
        const [label, color] = STATUS[d.status] || [d.status, C.sub];
        return (
          <Pressable key={d.uid} testID={`doc-${d.uid}`} onPress={() => nav.push('DocInfo', { uid: d.uid })} style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1, gap: 4 })}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }}>{docType(d.doc_type).icon} {d.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{[d.typeLabel, d.party, d.number, d.doc_date || String(d.added_at || '').slice(0, 10)].filter(Boolean).join(' · ')}</Text>
            <Text style={{ fontSize: 14, color }}>{label}</Text>
          </Pressable>
        );
      })}
    </Screen>
  );
}

export function DocInfoScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const [, setTick] = useState(0);
  let d = null;
  try { const r = db().get('SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.uid = ?', [params.uid]); d = r ? describeDocument(r) : null; } catch (e) { d = null; }
  if (!d) return <Screen title="Document"><Banner tone="warn" message="Document not found." /></Screen>;
  if (!canSeeDocument(user, d)) return <Screen title="Document"><Banner tone="warn" message="Your role may not see this type of document. Ask the owner." /></Screen>;
  const [label, color] = STATUS[d.status] || [d.status, C.sub];
  const open = async () => { try { await openDocument(d.uid); } catch (e) { ui.error(e); } };
  const retry = () => { try { retryUpload(user, d.uid); ui.toast('It will be sent on the next sync'); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title={d.name} subtitle={d.typeLabel}>
      <Card>
        <Row label="Drive" value={label} color={color} bold />
        {d.upload_error ? <Text style={{ color: C.danger }}>{d.upload_error}</Text> : null}
        <Row label="Folder" value={(d.folder || []).join(' › ')} />
        {d.party ? <Row label="Supplier / person" value={d.party} /> : null}
        {d.number ? <Row label="Number" value={d.number} /> : null}
        {d.doc_date ? <Row label="Date" value={d.doc_date} /> : null}
        {d.amount ? <Row label="Amount" value={String(d.amount)} /> : null}
        {d.verified_at ? <Row label="Checked in Drive" value={String(d.verified_at).slice(0, 16)} /> : null}
        <Row label="Kept on" value={d.file_device === deviceId() ? 'this device' : d.file_device ? 'another device' : '–'} />
      </Card>
      <Btn testID="doc-open" title="Open" icon="📄" onPress={open} />
      {['failed', 'login', 'pending'].includes(d.status) ? <Btn testID="doc-retry" title="Try the upload again" icon="⟳" variant="secondary" onPress={retry} /> : null}
    </Screen>
  );
}

export function DocCheckScreen({ params = {} }) {
  const { nav } = useApp();
  const [code, setCode] = useState(params.code || '');
  let r = null;
  try { r = code.trim() ? verifyDocCode(code) : null; } catch (e) { r = null; }
  return (
    <Screen title="Check a document" subtitle="Is this paper genuine?">
      <Hint>Scan the barcode at the bottom of an Easy Buys document (Home › Scan), or type the code under it.</Hint>
      <Field testID="dc-code" label="Code (EBD-…)" value={code} onChangeText={setCode} />
      {r ? <Banner testID="dc-result" tone={r.ok ? 'success' : 'danger'} title={r.title} message={r.message} /> : null}
      {r && r.nav ? <Btn testID="dc-open" title="Open it in the app" icon="📂" variant="secondary" onPress={() => nav.push(r.nav.screen, r.nav.params || {})} /> : null}
      <Section title="Documents made lately">
        {(() => { let l = []; try { l = listIssued({ limit: 15 }); } catch (e) { l = []; } return l.map((x) => <Text key={x.uid} style={{ color: C.sub, fontSize: 14 }}>{x.ref} · {x.title} · {String(x.last_at).slice(0, 16)}{x.copies > 1 ? ` · ${x.copies} copies` : ''}</Text>); })()}
      </Section>
    </Screen>
  );
}

export function DocDesignerScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const first = DOC_TYPES.some((t) => t.id === params.type) ? params.type : DOC_TYPES[0].id;
  const [typeId, setTypeId] = useState(first);
  const [d, setD] = useState(() => getDesign(first));
  const [, setTick] = useState(0);
  const pick = (id) => { setTypeId(id); setD(getDesign(id)); };
  const save = () => { try { saveDesign(user, typeId, d); ui.toast('Saved – every device uses it'); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  const reset = async () => { if (await ui.confirm({ title: 'Back to the standard layout?', message: 'The current layout is kept in the history.', confirmText: 'Reset' })) { try { setD(resetDesign(user, typeId)); ui.toast('Back to standard'); } catch (e) { ui.error(e); } } };
  const label = (key) => { if (key.startsWith('text:')) { const t = d.texts.find((x) => `text:${x.id}` === key); return `Your text: ${(t && t.text) || '(empty)'}`; } return (PARTS.find((p) => p.key === key) || {}).label || key; };
  const versions = designVersions(typeId);
  return (
    <Screen title="Document layout" subtitle="What each kind of document shows, in which order"
      footer={<Btn testID="dd-save" title="Save layout" icon="💾" variant="success" onPress={save} />}>
      <Chips value={typeId} onChange={pick} testIDPrefix="dd-type" options={DOC_TYPES.map((t) => ({ value: t.id, label: `${t.icon} ${t.label}` }))} />
      <Section title="Paper">
        <Chips value={d.paper} onChange={(v) => setD({ ...d, paper: v })} testIDPrefix="dd-paper" options={PAPERS.map((p) => ({ value: p.id, label: p.label }))} />
        <Chips value={d.look.theme} onChange={(v) => setD({ ...d, look: { ...d.look, theme: v } })} testIDPrefix="dd-look" options={LOOKS.map((l) => ({ value: l.id, label: l.label }))} />
        <Chips value={d.look.logo ? 'yes' : 'no'} onChange={(v) => setD({ ...d, look: { ...d.look, logo: v === 'yes' } })} testIDPrefix="dd-logo" options={[{ value: 'yes', label: 'With logo' }, { value: 'no', label: 'No logo' }]} />
      </Section>
      <Section title="Parts (tick to show, arrows to move)">
        {d.parts.map((p, i) => (
          <View key={p.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 4 }}>
            <Pressable testID={`dd-part-${p.key}`} onPress={() => setD(togglePart(d, p.key))} style={{ flex: 1, flexDirection: 'row', gap: 8, alignItems: 'center' }}>
              <Text style={{ fontSize: 22 }}>{p.on ? '☑' : '☐'}</Text>
              <Text style={{ fontSize: 16, color: p.on ? C.text : C.sub }}>{label(p.key)}</Text>
            </Pressable>
            <Btn title="↑" size="sm" variant="secondary" disabled={i === 0} onPress={() => setD(movePart(d, p.key, -1))} />
            <Btn title="↓" size="sm" variant="secondary" disabled={i === d.parts.length - 1} onPress={() => setD(movePart(d, p.key, 1))} />
            {p.key.startsWith('text:') ? <Btn title="✕" size="sm" variant="secondary" onPress={() => setD(removeText(d, p.key.slice(5)))} /> : null}
          </View>
        ))}
        {d.texts.map((t) => (
          <Field key={t.id} label="Your text" value={t.text} onChangeText={(v) => setD({ ...d, texts: d.texts.map((x) => (x.id === t.id ? { ...x, text: v } : x)) })} multiline />
        ))}
        <Btn testID="dd-add-text" title="Add a line of text" icon="➕" size="sm" variant="secondary" onPress={() => setD(addText(d, ''))} />
        <Hint>{`You can use: ${PLACEHOLDERS.map((x) => x[0]).join(' ')}`}</Hint>
      </Section>
      <Btn testID="dd-reset" title="Back to the standard layout" size="sm" variant="secondary" onPress={reset} />
      {versions.length ? (
        <Section title="Earlier layouts">
          {versions.slice(0, 6).map((v) => (
            <View key={v.at} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, color: C.sub }}>{String(v.at).slice(0, 16)} · {v.by}{v.note ? ` · ${v.note}` : ''}</Text>
              <Btn title="Put back" size="sm" variant="secondary" onPress={() => { try { setD(restoreDesignVersion(user, typeId, v.at)); ui.toast('Put back'); } catch (e) { ui.error(e); } }} />
            </View>
          ))}
        </Section>
      ) : null}
    </Screen>
  );
}

export function DocSettingsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const owner = actsAsOwner(user);
  const [s, setS] = useState(() => docSettings());
  const [vis, setVis] = useState(() => docVisibility());
  const [, setTick] = useState(0);
  const isMain = mainTabletId() === deviceId();
  const save = () => { try { setS(saveDocSettings(user, s)); ui.toast('Saved'); } catch (e) { ui.error(e); } };
  const saveVis = () => { try { setVis(saveDocVisibility(user, vis)); ui.toast('Saved – every device uses it'); } catch (e) { ui.error(e); } };
  const flip = (t, r) => setVis((v) => ({ ...v, [t]: (v[t] || []).includes(r) ? v[t].filter((x) => x !== r) : (v[t] || []).concat([r]) }));
  return (
    <Screen title="Documents & backups" subtitle="Drive filing, tablet copies, nightly backup, who sees what">
      <Card style={{ gap: 10 }}>
        <H>Filing and copies</H>
        <Chips value={s.previewFirst ? 'yes' : 'no'} onChange={(v) => setS({ ...s, previewFirst: v === 'yes' })} testIDPrefix="ds-preview" options={[{ value: 'yes', label: 'Show a preview first' }, { value: 'no', label: 'Straight to share / print' }]} />
        <Chips value={s.fileOnSend ? 'yes' : 'no'} onChange={(v) => setS({ ...s, fileOnSend: v === 'yes' })} testIDPrefix="ds-file" options={[{ value: 'yes', label: 'File every sent / printed document in Drive' }, { value: 'no', label: 'Do not file' }]} />
        <NumberField testID="ds-days" label="Keep a copy on the tablet for (days, after it is checked in Drive)" value={s.retentionDays} onChange={(v) => setS({ ...s, retentionDays: v })} step={1} unit="days" />
        <NumberField testID="ds-hour" label="Nightly backup at (hour, 0–23)" value={s.backupHour} onChange={(v) => setS({ ...s, backupHour: v })} step={1} unit="h" />
        <Btn testID="ds-save" title="Save" icon="💾" size="md" variant="success" onPress={save} />
      </Card>
      <Card style={{ gap: 8 }}>
        <H>Main tablet (does the nightly backup)</H>
        <Text style={{ color: C.sub }}>{isMain ? 'This device is the main tablet.' : mainTabletId() ? 'Another device is the main tablet.' : 'Not chosen yet.'}</Text>
        {owner && !isMain ? <Btn testID="ds-main" title="Make this device the main tablet" size="md" variant="secondary" onPress={() => { try { setMainTablet(user, true); setTick((n) => n + 1); ui.toast('Saved'); } catch (e) { ui.error(e); } }} /> : null}
      </Card>
      {owner ? (
        <Section title="Who may see each type of document">
          <Hint>The owner and admin always see everything.</Hint>
          {DOC_TYPES.map((t) => (
            <Card key={t.id}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{t.icon} {t.label}{t.access === 'restricted' ? ' (restricted)' : ''}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {ROLES.filter((r) => !['owner', 'admin'].includes(r)).map((r) => {
                  const on = (vis[t.id] || []).includes(r);
                  return <Btn key={r} testID={`dv-${t.id}-${r}`} title={`${on ? '☑' : '☐'} ${ROLE_LABEL[r] || r}`} size="sm" variant={on ? 'info' : 'secondary'} onPress={() => flip(t.id, r)} />;
                })}
              </View>
            </Card>
          ))}
          <Btn testID="ds-vis-save" title="Save who may see documents" icon="💾" variant="success" onPress={saveVis} />
        </Section>
      ) : null}
    </Screen>
  );
}
