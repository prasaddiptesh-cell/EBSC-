// Admin › Emails: reports and purchase orders are always saved in Google Drive; emailing them is optional, per kind.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, EmailList, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { EMAIL_TYPES, MODES, emailPrefs, saveEmailPref, emailAsks, answerAsk } from '../../../services/emailPrefs.js';

export function EmailsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [prefs, setPrefs] = useState(() => emailPrefs());
  const [, setTick] = useState(0);
  let asks = [];
  try { asks = emailAsks(); } catch (e) { asks = []; }
  const set = (type, patch) => setPrefs((p) => ({ ...p, [type]: { ...p[type], ...patch } }));
  const save = (type) => { try { saveEmailPref(user, type, prefs[type]); ui.toast('Saved – every device uses this'); } catch (e) { ui.error(e); } };
  const answer = (id, yes) => { try { answerAsk(user, id, yes); ui.toast(yes ? 'Will be emailed on the next sync' : 'Not emailed'); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Emails" subtitle="Reports and orders are always saved in Google Drive – emailing them is up to you">
      {asks.length ? (
        <Section title="Email these?">
          {asks.map((a) => (
            <Card key={a.id}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }}>{a.title}</Text>
              <Text style={{ color: C.sub }}>To {a.to.join(', ') || 'nobody yet'}</Text>
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>
                <Btn testID={`em-send-${a.id}`} title="Send" icon="✉️" size="md" variant="success" disabled={!a.to.length} onPress={() => answer(a.id, true)} />
                <Btn testID={`em-no-${a.id}`} title="Not now" size="md" variant="secondary" onPress={() => answer(a.id, false)} />
              </View>
            </Card>
          ))}
        </Section>
      ) : null}
      {EMAIL_TYPES.map((t) => (
        <Card key={t.type} style={{ gap: 10 }}>
          <H>{t.label}</H>
          <Text style={{ fontSize: 15, color: C.sub }}>{t.note}</Text>
          <Chips value={prefs[t.type].mode} onChange={(v) => set(t.type, { mode: v })} options={MODES} testIDPrefix={`em-${t.type}`} />
          {prefs[t.type].mode !== 'off' ? <EmailList testID={`em-to-${t.type}`} label="Send to" value={prefs[t.type].to} onChange={(v) => set(t.type, { to: v })} /> : null}
          <Btn testID={`em-save-${t.type}`} title="Save" icon="💾" size="md" variant="success" onPress={() => save(t.type)} />
        </Card>
      ))}
      <Hint>Payslips, contracts and welcome emails are only sent when you press their Send button.</Hint>
    </Screen>
  );
}
