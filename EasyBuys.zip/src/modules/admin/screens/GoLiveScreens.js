// Go-live: "Start fresh" (owner clears the test data on every device and in the cloud) and the go-live checklist
// (cloud script, every device updated and fresh, opening figures, lock earlier periods, then the go-live date).
import React, { useState, useEffect } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { getSetting, getShared, setShared, audit, stamp, dateStr, APP_VERSION } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import * as F from '../../../services/startFresh.js';
import { cloudCall } from '../../../platform/cloud.js';
import { snapshotNow } from '../../../services/snapshots.js';
import { actsAsOwner } from '../../../services/access.js';
import * as M from '../../../services/migration.js';
import { retireSampleLoginsNow } from '../../devices/service.js';

const LABEL = { activity: F.ACTIVITY_LABEL, ...Object.fromEntries(Object.entries(F.FRESH_GROUPS).map(([k, g]) => [k, g.label])) };

export function StartFreshScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [groups, setGroups] = useState(['activity']);
  const [typed, setTyped] = useState('');
  const [busy, setBusy] = useState('');
  const [done, setDone] = useState(null);
  const linked = !!getSetting('cloud_url', '');
  const isMain = !linked || !!getSetting('cloud_key', '');
  const summary = F.freshSummary(groups);
  const total = summary.reduce((s, x) => s + x.rows, 0);
  const flip = (g) => setGroups((x) => (x.includes(g) ? x.filter((y) => y !== g) : x.concat([g])));
  const go = async () => {
    const ok = await ui.confirm({ title: 'Start fresh?', message: `${total} records will be cleared on this device${linked ? ', in the cloud and on every linked device' : ''}. A safety copy is made first.`, confirmText: 'Start fresh', tone: 'danger' });
    if (!ok) return;
    setBusy('Making the safety copy and clearing…');
    try {
      const r = await F.startFresh(user, { groups, typed }, {
        linked,
        snapshot: async () => { await snapshotNow('fresh'); },
        cloud: linked ? (b) => cloudCall(b, 120000) : null,
      });
      setDone(r);
    } catch (e) { ui.error(e); }
    setBusy('');
  };
  if (!actsAsOwner(user)) return <Screen title="Start fresh"><Banner tone="warn" message="Only the owner can start fresh." /></Screen>;
  if (done) {
    return (
      <Screen title="Started fresh">
        <Banner tone="success" title={`Cleared ${done.removed} test records`} message={`${linked ? 'The cloud copy is cleared and every linked device will do the same on its next sync. Test photos and documents in Drive were moved to "Test data (before go-live)". ' : ''}The safety copy is in Admin › Backup & restore if you ever need it.`} />
        <Btn testID="fresh-golive" title="Go to the go-live checklist" icon="✅" variant="success" onPress={() => nav.replace('GoLive', {})} />
      </Screen>
    );
  }
  return (
    <Screen title="Start fresh" subtitle="Clear the test data before using the app for real">
      <Explain>Tick what to clear. Everything else stays. The change history is always kept. Only records made before now are cleared, so anything entered afterwards on any device is safe.</Explain>
      {!isMain ? <Banner tone="danger" title="Use the main tablet" message="Start fresh on the main tablet (the one holding the cloud key), so the cloud copy is cleared too." /> : null}
      {linked && Number(getSetting('cloud_script_version', '0')) < 5 ? <Banner tone="warn" title="Paste the new cloud script first" message="Start fresh needs the v3.6 cloud script (CLOUD-SETUP.md, the usual 3 steps)." /> : null}
      <Section title="What to clear">
        {F.FRESH_ORDER.map((g) => {
          const on = groups.includes(g);
          return (
            <Pressable key={g} testID={`fresh-g-${g}`} onPress={() => flip(g)} style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border }}>
              <Text style={{ fontSize: 24, color: on ? C.danger : C.sub }}>{on ? '☑' : '☐'}</Text>
              <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{LABEL[g]}</Text>
            </Pressable>
          );
        })}
      </Section>
      <Card tone="warn">
        <Text testID="fresh-total" style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{total} records will be cleared</Text>
        {summary.slice(0, 12).map((x) => <Text key={x.table} style={{ color: C.sub }}>{x.table.replace(/_/g, ' ')}: {x.rows}</Text>)}
        {summary.length > 12 ? <Text style={{ color: C.sub }}>…and {summary.length - 12} more kinds</Text> : null}
      </Card>
      <Field testID="fresh-typed" label='Type START FRESH to confirm' value={typed} onChangeText={setTyped} />
      {busy ? <Banner tone="info" message={busy} /> : null}
      <Btn testID="fresh-go" title="Start fresh" icon="🧹" variant="danger" disabled={!!busy || !isMain || !groups.length || typed.trim().toUpperCase() !== 'START FRESH'} onPress={go} />
    </Screen>
  );
}

// ---------------------------------------------------------------- go-live checklist
const OPENING = [
  { key: 'bank', title: 'BSP bank balance and cheques written but not presented yet', screen: 'OpeningBalances' },
  { key: 'cash', title: 'Cash on hand at each shop (floats and safe)', screen: 'TillSetup' },
  { key: 'wallets', title: 'Each M-PAiSA wallet balance', screen: 'WalletSetup' },
  { key: 'suppliers', title: 'What is owed to each supplier (unpaid invoices)', screen: 'ApInvoiceEdit' },
  { key: 'loans', title: 'Each loan balance (shops and cars)', screen: 'LoanSetup' },
  { key: 'stock', title: 'Opening stock at each shop (a stock take on the day)', screen: 'StockTakes' },
  { key: 'leave', title: 'Staff leave balances', screen: 'Leave', params: { tab: 'setup' } },
  { key: 'owed', title: 'Staff credit (from Aronium) and advances owed', screen: 'OwedImport' },
  { key: 'lock', title: 'Lock the time before go-live (Accounting settings)', screen: 'AcctSettings' },
];
export function goLiveState() { return getShared('go_live', {}) || {}; }
export function GoLiveScreen() {
  const { user, nav, can } = useApp();
  const ui = useUI();
  const [st, setSt] = useState(goLiveState());
  const [devices, setDevices] = useState(null);
  const linked = !!getSetting('cloud_url', '');
  const fresh = F.freshMarker();
  useEffect(() => { if (linked) cloudCall({ kind: 'devices' }, 30000).then((r) => setDevices(r.devices || [])).catch(() => setDevices([])); }, []);
  const tick = (key) => { const ticks = { ...(st.ticks || {}) }; if (ticks[key]) delete ticks[key]; else ticks[key] = { by: user.name, at: stamp() }; const n = { ...st, ticks }; setShared('go_live', n); setSt(n); };
  const scriptOk = !linked || Number(getSetting('cloud_script_version', '0')) >= 6;
  const freshTag = fresh ? ` fresh:${String(fresh.id).slice(-6)}` : '';
  const active = (devices || []).filter((d) => d.status !== 'blocked');
  const devicesFresh = active.filter((d) => fresh && String(d.app || '').includes(freshTag.trim()));
  const devicesNew = active.filter((d) => String(d.app || '').startsWith(APP_VERSION));
  const ticks = st.ticks || {};
  const steps = [
    { key: 'script', title: 'Cloud script updated (v3.7)', done: scriptOk, auto: true },
    { key: 'devices', title: `Every device on this app version (${devicesNew.length} of ${active.length})`, done: !linked || (active.length > 0 && devicesNew.length === active.length) || !!ticks.devices, sub: (devices || []).filter((d) => d.status !== 'blocked' && !String(d.app || '').startsWith(APP_VERSION)).map((d) => `${d.name}: v${d.app || '?'}`).join(' · ') },
    { key: 'fresh', title: fresh ? `Started fresh on ${fmtDate(String(fresh.at).slice(0, 10))} by ${fresh.by}` : 'Start fresh (clear the test data)', done: !!fresh, nav: 'StartFresh', auto: true },
    { key: 'devfresh', title: `Every device has started fresh (${devicesFresh.length} of ${active.length})`, done: !!fresh && (!linked || devicesFresh.length === active.length || !!ticks.devfresh), sub: fresh ? active.filter((d) => !devicesFresh.includes(d)).map((d) => `${d.name}: waiting for its next sync`).join(' · ') : '' },
  ].concat(OPENING.map((o) => ({ ...o, done: !!ticks[o.key], manual: true })));
  const allDone = steps.every((s) => s.done);
  const finish = () => {
    if (!allDone) return;
    const n = { ...st, liveFrom: dateStr(), liveBy: user.name, liveAt: stamp() };
    setShared('go_live', n); setSt(n);
    audit({ user, action: `Went live on ${dateStr()}`, table: 'shared_settings' });
    ui.toast('You are live – well done!');
  };
  return (
    <Screen title="Moving in & go-live" subtitle={st.liveFrom ? `Live since ${fmtDate(st.liveFrom)}` : 'Everything needed before using the app for real'}>
      {st.liveFrom ? <Banner tone="success" title={`Live since ${fmtDate(st.liveFrom)}`} message={`Done by ${st.liveBy}. Training mode is still there for practice.`} /> : null}
      <Explain title="Moving the business into the app">Work down the list, a few each day. Each step says where the information is now and the quickest way in (import from Aronium, a photo of the paper, or typing). Steps tick themselves as the information goes in – or tick "Done" / "Not needed". Nothing is ever written to Aronium. When everything is in, finish with the opening figures and go live.</Explain>
      {(() => {
        const ms = M.migrationStatus();
        const left = ms.filter((x) => !x.done).length;
        let phase = '';
        return (
          <>
            <Banner tone={left ? 'info' : 'success'} title={left ? `${ms.length - left} of ${ms.length} set-up steps done` : 'Everything is in'} message={left ? `Next: ${ms.find((x) => !x.done).title}` : 'Now the opening figures below.'} />
            {ms.map((m) => {
              const head = m.phase !== phase ? (phase = m.phase) : null;
              return (
                <View key={m.key}>
                  {head ? <Text style={{ fontSize: 18, fontWeight: '900', color: C.info, marginTop: 10 }}>{head}</Text> : null}
                  <Card tone={m.done ? 'success' : undefined}>
                    <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${m.done ? '✅' : '⬜'} ${m.title}`}</Text>
                    <Text style={{ fontSize: 14, color: C.sub }}>{`From: ${m.from} · ${m.how}`}</Text>
                    {m.progress ? <Text style={{ fontSize: 15, fontWeight: '700', color: m.done ? C.success : C.text }}>{m.progress}{m.tick ? ` · ${m.tick.v === 'na' ? 'not needed' : 'ticked'} by ${m.tick.by}` : ''}</Text> : null}
                    <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
                      <Btn testID={`mg-open-${m.key}`} title="Open" size="sm" variant="secondary" onPress={() => nav.push(m.screen, m.params || {})} />
                      {m.action === 'samples' && !m.done ? <Btn testID="mg-samples-off" title="Turn them off" size="sm" variant="warn" onPress={() => { try { const k = retireSampleLoginsNow(user); ui.toast(`${k} sample login(s) turned off`); setSt({ ...goLiveState() }); } catch (e) { ui.error(e); } }} /> : null}
                      {!m.auto ? <Btn testID={`mg-done-${m.key}`} title={m.tick && m.tick.v === 'done' ? 'Untick' : 'Done'} size="sm" variant="ghost" onPress={() => { M.tickMigration(user, m.key, m.tick && m.tick.v === 'done' ? null : 'done'); setSt({ ...goLiveState() }); }} /> : null}
                      {!m.auto ? <Btn testID={`mg-na-${m.key}`} title={m.tick && m.tick.v === 'na' ? 'Needed after all' : 'Not needed'} size="sm" variant="ghost" onPress={() => { M.tickMigration(user, m.key, m.tick && m.tick.v === 'na' ? null : 'na'); setSt({ ...goLiveState() }); }} /> : null}
                    </View>
                  </Card>
                </View>
              );
            })}
            <Text style={{ fontSize: 18, fontWeight: '900', color: C.info, marginTop: 10 }}>Clear the practice data, then the opening figures</Text>
          </>
        );
      })()}
      {steps.map((s, i) => (
        <Card key={s.key} tone={s.done ? 'success' : undefined}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <Pressable testID={`gl-tick-${s.key}`} disabled={!s.manual && !['devices', 'devfresh'].includes(s.key)} onPress={() => tick(s.key)}>
              <Text style={{ fontSize: 26, color: s.done ? C.success : C.sub }}>{s.done ? '✅' : '⬜'}</Text>
            </Pressable>
            <Text style={{ flex: 1, fontSize: 17, fontWeight: '700', color: C.text }}>{i + 1}. {s.title}</Text>
            {s.nav || s.screen ? <Btn testID={`gl-open-${s.key}`} title="Open" size="sm" variant="secondary" onPress={() => nav.push(s.nav || s.screen, s.params || {})} /> : null}
          </View>
          {s.sub ? <Text style={{ color: C.sub, marginTop: 4 }}>{s.sub}</Text> : null}
          {ticks[s.key] ? <Text style={{ color: C.sub, fontSize: 13 }}>Ticked by {ticks[s.key].by}</Text> : null}
        </Card>
      ))}
      <Hint>Opening figures are as at the go-live date. Tick each one when it is entered. Device steps tick themselves (or the owner can tick them).</Hint>
      {!st.liveFrom && actsAsOwner(user) ? <Btn testID="gl-finish" title={allDone ? 'We are live!' : `Finish (${steps.filter((s) => !s.done).length} left)`} icon="🚀" variant="success" disabled={!allDone} onPress={finish} /> : null}
    </Screen>
  );
}
