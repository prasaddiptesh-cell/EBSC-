// Admin › Online dashboard (v3.9.4): which sections the online dashboard shows, in what order, what is kept off the
// internet, how far back the lists go, and which device sends it. Owner / admin only.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Explain } from '../../../ui/kit.js';
import { getSetting, deviceId } from '../../../services/core.js';
import * as B from '../../../services/board.js';

export function OnlineDashboardScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [cfg, setCfg] = useState(B.boardSettings());
  const sender = B.dashboardSender();
  const save = (patch) => { try { setCfg(B.saveBoardSettings(user, patch)); ui.toast('Saved – the dashboard changes within a few minutes'); } catch (e) { ui.error(e); } };
  const move = (id, d) => {
    const o = cfg.order.slice(); const i = o.indexOf(id); const j = i + d;
    if (j < 0 || j >= o.length) return;
    [o[i], o[j]] = [o[j], o[i]];
    save({ order: o });
  };
  const flip = (id) => save({ off: cfg.off.includes(id) ? cfg.off.filter((x) => x !== id) : cfg.off.concat([id]) });
  if (!user || !['owner', 'admin'].includes(user.role)) return <Screen title="Online dashboard"><Banner tone="warn" message="Only the owner or an admin can change the online dashboard." /></Screen>;
  return (
    <Screen title="Online dashboard" subtitle="What the Easy Buys Business Dashboard shows">
      <Explain>The online dashboard shows what you choose here. Everyone with the dashboard password sees the same. It can only be looked at – nothing can be changed from it (changes are made in the app).</Explain>
      {getSetting('cloud_url', '') ? <Btn testID="od-open" title="Open the dashboard" icon="📊" variant="secondary" onPress={() => Linking.openURL(getSetting('cloud_url', '')).catch(() => {})} /> : null}
      <Section title="Sections (top to bottom = the tabs from left to right)">
        {cfg.order.map((id, i) => {
          const def = B.BOARD_SECTIONS.find((x) => x.id === id);
          const on = !cfg.off.includes(id);
          return (
            <Card key={id}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: on ? C.text : C.sub, flex: 1, minWidth: 160 }}>{def.icon} {def.title}</Text>
                <Btn testID={`od-up-${id}`} title="▲" size="sm" variant="secondary" disabled={i === 0} onPress={() => move(id, -1)} />
                <Btn testID={`od-down-${id}`} title="▼" size="sm" variant="secondary" disabled={i === cfg.order.length - 1} onPress={() => move(id, 1)} />
                <Btn testID={`od-on-${id}`} title={on ? 'Shown' : 'Hidden'} size="sm" variant={on ? 'success' : 'ghost'} onPress={() => flip(id)} />
              </View>
              <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>{def.note}</Text>
            </Card>
          );
        })}
      </Section>
      <Section title="Today page – what it shows">
        {B.TODAY_PARTS.map((t) => {
          const shown = !cfg.partsOff.includes(t.id);
          return <Btn key={t.id} testID={`od-part-${t.id}`} title={`${shown ? '☑' : '☐'} ${t.label}`} size="md" variant={shown ? 'secondary' : 'ghost'}
            onPress={() => save({ partsOff: shown ? cfg.partsOff.concat([t.id]) : cfg.partsOff.filter((x) => x !== t.id) })} />;
        })}
      </Section>
      <Section title="Keep off the internet">
        {B.BOARD_HIDE.map((h) => (
          <Btn key={h.id} testID={`od-hide-${h.id}`} title={`${cfg.hide[h.id] ? '☑ Hidden:' : '☐ Shown:'} ${h.label}`} size="md" variant={cfg.hide[h.id] ? 'warn' : 'secondary'} onPress={() => save({ hide: { [h.id]: !cfg.hide[h.id] } })} />
        ))}
      </Section>
      <Section title="Lists go back">
        <Chips testIDPrefix="od-days" value={String(cfg.days)} onChange={(v) => save({ days: Number(v) })} options={[{ value: '7', label: '7 days' }, { value: '30', label: '30 days' }, { value: '90', label: '90 days' }]} />
      </Section>
      <Section title="Which device sends it">
        <Card>
          <Text style={{ fontSize: 15, color: C.text }}>{sender ? (sender.device === deviceId() ? 'This device sends the dashboard.' : `Another device sends it (${sender.bakery ? 'the bakery tablet' : 'a linked device'}).`) : 'Not chosen yet – the first linked device that syncs takes it on.'}</Text>
          <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>Normally the bakery tablet (it alone has the live bakery figures). If it is quiet for 30 minutes, another device takes over by itself.</Text>
          {sender && sender.device === deviceId() ? null : <Btn testID="od-claim" title="Send it from this device" size="md" variant="secondary" onPress={() => { B.claimDashboard(user, { pinned: true }); ui.toast('This device sends the dashboard now'); setCfg(B.boardSettings()); }} />}
        </Card>
      </Section>
    </Screen>
  );
}
