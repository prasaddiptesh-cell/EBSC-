// Problem log & screen check: what went wrong, where, and a quick check of every screen.
import React, { useState } from 'react';
import { View, Share } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { listErrors, problemReport, screenTrail } from '../../../services/errorLog.js';
import { APP_VERSION } from '../../../services/core.js';

export function ProblemsScreen({ params = {} }) {
  const { startScreenCheck } = useApp();
  const ui = useUI();
  const [n, setN] = useState(30);
  const tour = Array.isArray(params.tour) ? params.tour : null;
  const errs = listErrors(n);
  const bad = tour ? tour.filter((t) => !t.ok) : [];
  const send = () => Promise.resolve(Share.share({ message: problemReport({ tour }) })).catch((e) => ui.error(e));
  const check = async () => {
    const ok = await ui.confirm({ title: 'Check every screen?', message: 'The app will open each screen for a moment (about a minute in all). Nothing is changed. Wait until the results show.', confirmText: 'Start check' });
    if (ok && startScreenCheck) startScreenCheck();
  };
  return (
    <Screen title="Problem log & screen check" subtitle={`Easy Buys app v${APP_VERSION}`}>
      <Explain>If the app shows "Something went wrong" or closes by itself, the details are written here: when, on which screen, and the last screens opened before it. Tap "Send problem report" and send it by Viber, WhatsApp or email to whoever looks after the app. When this device is linked to the cloud, the same log also goes to the Google sheet (change history).</Explain>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="pr-share" title="Send problem report" icon="📤" size="md" variant="info" style={{ flexGrow: 1 }} onPress={send} />
        <Btn testID="pr-check" title="Check every screen" icon="🩺" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={check} />
      </View>
      {tour ? (
        <Section title="Screen check">
          <Banner tone={bad.length ? 'warn' : 'success'} message={bad.length ? `${bad.length} of ${tour.length} screens had a problem. Send the report so they can be fixed.` : `All ${tour.length} screens opened without a problem.`} />
          {bad.map((t) => (
            <Card key={t.name}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.danger }}>{t.name}</Text>
              <Text style={{ fontSize: 15, color: C.text, marginTop: 4 }}>{t.message}</Text>
            </Card>
          ))}
        </Section>
      ) : null}
      <Section title={errs.length ? `Problems recorded (${errs.length}${errs.length >= n ? '+' : ''})` : 'Problems recorded'}>
        {errs.length ? null : <Hint>Nothing has gone wrong on this device.</Hint>}
        {errs.map((e, i) => (
          <Card key={i}>
            <Text style={{ fontSize: 14, color: C.sub }}>{e.at} · {e.who || '—'} · {e.device || ''}</Text>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text, marginTop: 2 }}>{e.screen || '—'}{e.fatal ? ' (would have closed the app)' : ''}</Text>
            <Text style={{ fontSize: 16, color: C.danger, marginTop: 2 }}>{e.message}</Text>
            {e.trail ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>Screens before: {e.trail}</Text> : null}
          </Card>
        ))}
        {errs.length >= n ? <Btn title="Show more" size="md" variant="secondary" onPress={() => setN(n + 50)} /> : null}
      </Section>
      <Hint>Screens opened this session: {screenTrail().map((t) => t.name).join(' › ') || '—'}</Hint>
    </Screen>
  );
}
