// Problem log & screen check: what went wrong, where, and a quick check of every screen.
import React, { useEffect, useState } from 'react';
import { View, Share } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { listErrors, problemReport, screenTrail, refreshDeviceFacts } from '../../../services/errorLog.js';
import { APP_VERSION, getSettings } from '../../../services/core.js';
import { enqueue } from '../../../services/stock.js';
import { isTraining } from '../../../services/trainingFlag.js';
import { SUPPORT } from '../../../services/about.js';

export function ProblemsScreen({ params = {} }) {
  const { startScreenCheck } = useApp();
  const ui = useUI();
  const [n, setN] = useState(30);
  // free storage and the database size for the report (read again each time this page opens)
  useEffect(() => { refreshDeviceFacts().catch(() => {}); }, []);
  const tour = Array.isArray(params.tour) ? params.tour : null;
  const errs = listErrors(n);
  const bad = tour ? tour.filter((t) => !t.ok) : [];
  const send = () => Promise.resolve(Share.share({ message: problemReport({ tour }) })).catch((e) => ui.error(e));
  // "Send to support": emailed to the support address by the Easy Buys cloud (with the next sync); when this device is
  // not linked (or in training mode) the share sheet opens instead.
  const toSupport = async () => {
    const text = problemReport({ tour });
    if (!getSettings().cloudUrl || isTraining()) {
      try { await Share.share({ message: `To: ${SUPPORT.email}\n\n${text}` }); } catch (e) { ui.error(e); }
      return;
    }
    try {
      enqueue('support_email', { subject: `Easy Buys problem report – v${APP_VERSION}`, text });
      ui.alert({ title: 'Sent to support', message: `The report goes to ${SUPPORT.name} (${SUPPORT.email}) with the next sync. If it is urgent, call or Viber ${SUPPORT.phone}.` });
    } catch (e) { ui.error(e); }
  };
  const sc = (() => { try { return require('../../../services/selfCheck.js').selfCheckResult(); } catch (e) { return null; } })();
  const selfNow = () => { try { const r = require('../../../services/selfCheck.js').runSelfCheck({ force: true }); ui.alert({ title: r.problems.length ? `${r.problems.length} problem(s) found` : 'Everything checked – all fine', message: r.problems.length ? r.problems.join('\n') : `${r.ok.length} checks passed.`, tone: r.problems.length ? 'danger' : 'primary' }); } catch (e) { ui.error(e); } };
  const check = async () => {
    const ok = await ui.confirm({ title: 'Check every screen?', message: 'The app will open each screen for a moment (about a minute in all). Nothing is changed. Wait until the results show.', confirmText: 'Start check' });
    if (ok && startScreenCheck) startScreenCheck();
  };
  return (
    <Screen title="Problem log & screen check" subtitle={`Easy Buys app v${APP_VERSION}`}>
      <Explain>If the app shows "Something went wrong" or closes by itself, the details are written here: when, on which screen, and the last screens opened before it. Tap "Send problem report" and send it by Viber, WhatsApp or email to whoever looks after the app. When this device is linked to the cloud, the same log also goes to the Google sheet (change history).</Explain>
      {sc ? <Banner tone={sc.problems.length ? 'warn' : 'success'} title={`Self-check ${String(sc.at).slice(0, 16)}`} message={sc.problems.length ? sc.problems.join('\n') : `All ${sc.ok.length} checks fine (database, sync, uploads, Aronium link, warnings, reports). It runs by itself every day.`} /> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="pr-support" title="Send to support" icon="🛟" size="md" variant="info" style={{ flexGrow: 1 }} onPress={toSupport} />
        <Btn testID="pr-share" title="Share problem report" icon="📤" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={send} />
        <Btn testID="pr-check" title="Check every screen" icon="🩺" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={check} />
        <Btn testID="pr-self" title="Self-check now" icon="🛡️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={selfNow} />
      </View>
      {tour ? (
        <Section title="Screen check">
          <Banner tone={bad.length ? 'warn' : 'success'} message={bad.length ? `${bad.length} of ${tour.length} screens had a problem. Send the report so they can be fixed.` : `All ${tour.length} screens opened without a problem.`} />
          {bad.map((t) => (
            <Card key={t.name}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.danger }}>{t.name}</Text>
              <Text style={{ fontSize: 15, color: C.text, marginTop: 4 }}>{t.message}</Text>
            </Card>
          ))}
        </Section>
      ) : null}
      <Section title={errs.length ? `Problems recorded (${errs.length}${errs.length >= n ? '+' : ''})` : 'Problems recorded'}>
        {errs.length ? null : <Hint>Nothing has gone wrong on this device.</Hint>}
        {errs.map((e, i) => (
          <Card key={i}>
            <Text style={{ fontSize: 14, color: C.sub }}>{e.at} · {e.who || '—'} · {e.device || ''}</Text>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text, marginTop: 2 }}>{e.screen || '—'}{e.fatal ? ' (would have closed the app)' : ''}</Text>
            <Text style={{ fontSize: 16, color: C.danger, marginTop: 2 }}>{e.message}</Text>
            {e.trail ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>Screens before: {e.trail}</Text> : null}
          </Card>
        ))}
        {errs.length >= n ? <Btn title="Show more" size="md" variant="secondary" onPress={() => setN(n + 50)} /> : null}
      </Section>
      <Hint>Screens opened this session: {screenTrail().map((t) => t.name).join(' › ') || '—'}</Hint>
    </Screen>
  );
}
