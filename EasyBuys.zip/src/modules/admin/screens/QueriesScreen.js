// Queries between the accountant (view only) and the owner.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { isViewOnly, actsAsOwner, can } from '../../../services/access.js';
import { askQuery, answerQuery, listQueries } from '../../../services/queries.js';

export function QueriesScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [text, setText] = useState('');
  const [ref, setRef] = useState(params.ref || '');
  const [answers, setAnswers] = useState({});
  const [, setTick] = useState(0);
  const mayAnswer = actsAsOwner(user) || user.role === 'admin' || can(user, 'settings');
  const list = listQueries();
  const ask = () => { try { askQuery(user, { text, ref, screen: params.screen, params: params.params }); setText(''); setRef(''); ui.toast('Sent to the owner'); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  const answer = (uid) => { try { answerQuery(user, uid, answers[uid]); ui.toast('Answered'); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Queries" subtitle="Questions from the accountant to the owner">
      {isViewOnly(user) ? <Banner tone="info" title="View only" message="You can see the records but not change them. Ask the owner here." /> : null}
      {isViewOnly(user) || !mayAnswer ? (
        <Card style={{ gap: 8 }}>
          <Field testID="q-ref" label="About (invoice no., supplier, month…)" value={ref} onChangeText={setRef} />
          <Field testID="q-text" label="Your question" value={text} onChangeText={setText} multiline />
          <Btn testID="q-send" title="Send to the owner" icon="✉️" variant="success" onPress={ask} />
        </Card>
      ) : null}
      {!list.length ? <Hint>No queries yet.</Hint> : null}
      {list.map((q) => (
        <Card key={q.uid} tone={q.status === 'open' ? 'warn' : undefined}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{q.ref ? `${q.ref}: ` : ''}{q.text}</Text>
          <Text style={{ color: C.sub, fontSize: 14 }}>{q.by_name} · {String(q.created_at).slice(0, 16)}</Text>
          {q.screen ? <Btn title="Open the record" size="sm" variant="secondary" onPress={() => nav.push(q.screen, q.params || {})} /> : null}
          {q.status === 'answered' ? <Text style={{ color: C.success, marginTop: 6 }}>Answer ({q.answered_by}, {String(q.answered_at).slice(0, 16)}): {q.answer}</Text> : null}
          {q.status === 'open' && mayAnswer && !isViewOnly(user) ? (
            <View style={{ gap: 6, marginTop: 6 }}>
              <Field testID={`q-answer-${q.uid}`} label="Answer" value={answers[q.uid] || ''} onChangeText={(v) => setAnswers({ ...answers, [q.uid]: v })} multiline />
              <Btn testID={`q-answer-send-${q.uid}`} title="Answer" size="md" variant="success" onPress={() => answer(q.uid)} />
            </View>
          ) : null}
        </Card>
      ))}
    </Screen>
  );
}
