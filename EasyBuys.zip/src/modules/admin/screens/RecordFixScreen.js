// v3.9 Admin corrections: find any record (or open it from its own screen with "Correct (admin)"), change any field,
// see what it touches, save – the change history keeps before and after, and anything now out of line is listed.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, Explain } from '../../../ui/kit.js';
import * as FX from '../../../services/recordFix.js';

const show = (v) => (v === null || v === undefined ? '' : String(v));

export function RecordFixScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState({});
  const [why, setWhy] = useState('');
  const [after, setAfter] = useState(null);
  if (!FX.canFix(user)) return <Screen title="Correct a record"><Banner tone="info" message="Only the owner or an admin can correct records." /></Screen>;
  if (!params.table || !params.keyVal) {
    const found = FX.findForFix(q);
    return (
      <Screen title="Correct a record" subtitle="Owner / admin – when someone made a mistake">
        <Explain>Find the record by its number, supplier, person, product or date (YYYY-MM-DD for till counts). You can also open it from its own screen and tap "Correct (admin)". Every correction is kept in the change history with the before and after.</Explain>
        <Field testID="fix-q" label="Find" value={q} onChangeText={setQ} placeholder="e.g. P-1043, Punjas, cheque 512, 2026-10-04" />
        {found.map((r) => <ListItem key={`${r.table}-${r.keyVal}`} testID={`fix-r-${r.keyVal}`} title={r.title} sub={`${r.kind}${r.sub ? ` · ${r.sub}` : ''}`} onPress={() => nav.push('RecordFix', { table: r.table, keyVal: r.keyVal })} />)}
        {q.trim().length >= 2 && !found.length ? <Hint>Nothing found.</Hint> : null}
      </Screen>
    );
  }
  let rec;
  try { rec = FX.getForFix(params.table, params.keyVal); } catch (e) { return <Screen title="Correct a record"><Banner tone="warn" message={e.message} /></Screen>; }
  const changed = Object.keys(edit).filter((k) => show(edit[k]) !== show(rec.row[k]));
  const save = async () => {
    if (!changed.length) { ui.toast('Nothing changed'); return; }
    const ok = await ui.confirm({ title: 'Save the correction?', message: `${changed.map((k) => `${k}: "${show(rec.row[k])}" → "${show(edit[k])}"`).join('\n')}${rec.linked.length ? `\n\nIt touches:\n• ${rec.linked.join('\n• ')}` : ''}`, confirmText: 'Save' });
    if (!ok) return;
    try {
      const r = FX.saveFix(user, params.table, params.keyVal, Object.fromEntries(changed.map((k) => [k, edit[k]])), why);
      setEdit({}); setWhy(''); setAfter(r.checks);
      ui.toast('Corrected – kept in the change history');
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={`Correct: ${rec.title}`} subtitle={show(rec.keyVal)} footer={<Btn testID="fix-save" title={changed.length ? `Save ${changed.length} change(s)` : 'Save'} icon="💾" variant="success" onPress={save} />}>
      {after ? (after.length ? <Banner testID="fix-after" tone="warn" title="Look at these now" message={after.map((x) => `• ${x}`).join('\n')} /> : <Banner testID="fix-after" tone="success" message="Saved. Everything that depends on it still agrees." />) : null}
      {rec.linked.length ? <Banner tone="info" title="This record is joined to" message={rec.linked.map((x) => `• ${x}`).join('\n')} /> : null}
      <Card>
        {rec.fields.map((f) => (
          <View key={f.name} style={{ marginBottom: 6 }}>
            <Field testID={`fix-f-${f.name}`} label={`${f.name}${f.required ? ' *' : ''}`} value={edit[f.name] !== undefined ? show(edit[f.name]) : show(rec.row[f.name])}
              onChangeText={(v) => setEdit((o) => ({ ...o, [f.name]: v }))} keyboardType={f.type === 'text' ? 'default' : 'decimal-pad'} multiline={show(rec.row[f.name]).length > 60} />
            {edit[f.name] !== undefined && show(edit[f.name]) !== show(rec.row[f.name]) ? <Text style={{ fontSize: 13, color: C.warn }}>was: {show(rec.row[f.name]) || '(empty)'}</Text> : null}
          </View>
        ))}
      </Card>
      <Field testID="fix-why" label="Why (optional for the owner / admin)" value={why} onChangeText={setWhy} />
      <Hint>To take a record out, set its status to void (it stays in the history). Pay is corrected by reopening the pay run; a journal's lines by voiding it and entering it again.</Hint>
    </Screen>
  );
}
// A small button for record screens: shown to the owner / admin only.
export function FixButton({ table, keyVal }) {
  const { user, nav } = useApp();
  if (!FX.canFix(user) || !keyVal) return null;
  return <Btn testID="fix-open" title="Correct (admin)" icon="✏️" size="sm" variant="ghost" onPress={() => nav.push('RecordFix', { table, keyVal })} />;
}
