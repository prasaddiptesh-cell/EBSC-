// Report layout: business details and footer for every report, and per report its title and columns – with a live sample.
import React, { useState } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { WebView } from 'react-native-webview';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Chips, Field, Section, Select, Label, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, Hint } from '../../../ui/kit.js';
import { dateStr, addDays, weekStart } from '../../../services/core.js';
import { reportTemplate, saveReportTemplate, applyTemplate } from '../../../services/reportTemplate.js';
import { reportToHtml } from '../../../services/export.js';
import { allReports } from '../../registry.js';

export function ReportTemplatesScreen() {
  const { user } = useApp();
  const act = useAct();
  const [t, setT] = useState(reportTemplate());
  const reports = allReports();
  const [rid, setRid] = useState(reports[0] ? reports[0].id : '');
  const set = (k) => (v) => setT({ ...t, [k]: v });
  let sample = null;
  let err = null;
  const r = reports.find((x) => x.id === rid);
  try { if (r) { const ws = weekStart(dateStr()); sample = r.build(addDays(ws, -7), addDays(ws, -1)); } } catch (e) { err = e.message; }
  const kind = sample ? sample.kind : rid;
  const per = t.reports[kind] || {};
  const setPer = (p) => setT({ ...t, reports: { ...t.reports, [kind]: { ...per, ...p } } });
  const cols = sample ? Array.from(new Map(sample.sections.flatMap((s) => s.columns).map((c) => [c.key, c])).values()) : [];
  const hidden = per.hidden || [];
  const order = per.order && per.order.length ? per.order : cols.map((c) => c.key);
  const move = (key, d) => { const o = order.slice(); const i = o.indexOf(key); const j = i + d; if (i < 0 || j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; setPer({ order: o }); };
  // The sample shows the layout as it is on this screen (before saving).
  let previewHtml = '';
  try { previewHtml = sample ? reportToHtml(applyTemplate(sample, t)) : ''; } catch (e) { previewHtml = ''; }
  return (
    <Screen title="Report layout" subtitle="Business details, footer and columns – used on every PDF, Excel and CSV"
      footer={<Btn testID="rt-save" title="Save layout" icon="💾" variant="success" onPress={() => act(() => saveReportTemplate(user, t), 'Saved')} />}>
      <Section title="On every report">
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          <View style={{ flexBasis: 260, flexGrow: 2 }}><Field testID="rt-name" label="Business name" value={t.businessName} onChangeText={set('businessName')} /></View>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="TIN" value={t.tin} onChangeText={set('tin')} /></View>
          <View style={{ flexBasis: 260, flexGrow: 2 }}><Field label="Address" value={t.address} onChangeText={set('address')} /></View>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Phone" value={t.phone} onChangeText={set('phone')} /></View>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Email" value={t.email} onChangeText={set('email')} /></View>
        </View>
        <Field testID="rt-footer" label="Footer (bottom of every page)" value={t.footer} onChangeText={set('footer')} multiline />
        <Chips value={t.showGenerated ? 'y' : 'n'} onChange={(v) => set('showGenerated')(v === 'y')} options={[{ value: 'y', label: 'Show when it was made' }, { value: 'n', label: 'Hide it' }]} />
      </Section>
      <Section title="One report">
        <Select testID="rt-report" label="Report" value={rid} onChange={setRid} options={reports.map((x) => ({ value: x.id, label: `${x.group} – ${x.title}` }))} />
        {err ? <Hint>{`The sample could not be made: ${err}`}</Hint> : null}
        <Field label="Title" value={per.title || ''} onChangeText={(v) => setPer({ title: v })} placeholder={sample ? sample.title : ''} />
        <Field label="Note printed under the report (optional)" value={per.note || ''} onChangeText={(v) => setPer({ note: v })} />
        {cols.length ? (
          <>
            <Label>Columns – tap to show / hide, arrows to move</Label>
            {order.filter((k) => cols.some((c) => c.key === k)).map((k) => {
              const c = cols.find((x) => x.key === k);
              const off = hidden.includes(k);
              return (
                <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Pressable testID={`rt-col-${k}`} onPress={() => setPer({ hidden: off ? hidden.filter((x) => x !== k) : hidden.concat([k]) })} style={{ flex: 1, padding: 10, borderRadius: 10, borderWidth: 1, borderColor: C.border, backgroundColor: off ? '#F2EEEA' : C.white }}>
                    <Text style={{ fontSize: 16, color: off ? C.sub : C.text, textDecorationLine: off ? 'line-through' : 'none' }}>{off ? '☐' : '☑'} {c.title || k}</Text>
                  </Pressable>
                  <Btn title="↑" size="sm" variant="secondary" onPress={() => move(k, -1)} />
                  <Btn title="↓" size="sm" variant="secondary" onPress={() => move(k, 1)} />
                </View>
              );
            })}
            <Btn title="Back to the standard layout for this report" size="sm" variant="ghost" onPress={() => { const x = { ...t.reports }; delete x[kind]; setT({ ...t, reports: x }); }} />
          </>
        ) : null}
      </Section>
      {previewHtml ? (
        <Section title="Sample (last pay week)">
          <View style={{ height: 520, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: C.border, backgroundColor: C.white }}>
            <WebView originWhitelist={['*']} source={{ html: previewHtml }} style={{ flex: 1 }} />
          </View>
        </Section>
      ) : null}
    </Screen>
  );
}
