// v3.9.8 Excel set-up pack: make the workbook (already filled with what the app has), fill it in Excel, bring it
// back: a preview per sheet first, then one tap saves the good rows. Owner / admin only.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { shareReport } from '../../../platform/files.js';
import { pickWorkbook } from '../../../platform/statementFiles.js';
import * as SP from '../../../services/setupPack.js';

const WHAT = { new: ['New', 'success'], change: ['Update', 'info'], check: ['Check – close name', 'warn'], wait: ['Kept – waits for the product', 'info'], problem: ['Problem', 'danger'] };
const line = (key, r) => {
  if (key === 'suppliers') return `${r.name}${r.budgetMonthly !== '' && r.budgetMonthly !== undefined ? ` · budget ${r.budgetMonthly}` : ''}`;
  if (key === 'products') return `${r.supplierName}: ${r.name || r.itemName}${r.itemName ? ` → ${r.itemName}${r.how ? ` (by ${r.how})` : ''}` : ''}${r.cost !== null && r.cost !== undefined ? ` · $${r.cost}` : ''}`;
  if (key === 'bills') return `${r.shop} ${r.kind || ''} ${r.label || ''} · ${r.accountNo}`;
  if (key === 'wallets') return `${r.name} (${r.shop}) · opening ${r.opening === null ? '–' : `$${r.opening}`} on ${r.date || '–'}`;
  return `${r.person}: ${(r.list || []).join(', ')}`;
};

export function SetupPackScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [pv, setPv] = useState(null);
  const [file, setFile] = useState('');
  const [busy, setBusy] = useState(false);
  const [checks, setChecks] = useState('skip');
  const [res, setRes] = useState(null);
  const boss = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const make = () => { try { shareReport(SP.packDoc(), 'xlsx').catch((e) => ui.error(e)); } catch (e) { ui.error(e); } };
  const bring = async () => {
    setBusy(true); setRes(null);
    try {
      const wb = await pickWorkbook();
      if (wb) { const p = SP.readPack(wb.sheets); setPv(p); setFile(wb.name); if (p.empty) ui.toast('No rows found – is it the set-up pack?'); }
    } catch (e) { ui.error(e); }
    setBusy(false);
  };
  const save = async () => {
    const ok = await ui.confirm({ title: 'Bring these in?', message: 'The rows marked New or Update are saved. Problems are skipped.', confirmText: 'Save' });
    if (!ok) return;
    try { const r = SP.applyPack(user, pv, { withChecks: checks === 'save' }); setRes(r); setPv(null); ui.toast('Set-up pack brought in'); } catch (e) { ui.error(e); }
  };
  if (!boss) return <Screen title="Set-up pack"><Banner tone="warn" message="Only the owner or admin can use the set-up pack." /></Screen>;
  return (
    <Screen title="Excel set-up pack" subtitle="Suppliers, supplier products, bill accounts, wallets, approvers">
      <Explain>One Excel file with a sheet for each part that is quicker to type on a computer. Tap "Make the pack": it already holds what is in the app. Fill it in (add rows, change cells, leave a cell empty to keep what the app has), save it, then "Bring it in". You see every row first – nothing is saved until you tap Save. Products are matched by the Aronium code, barcode, the supplier's code or the name.</Explain>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="pack-make" title="Make the pack (Excel)" icon="📗" size="md" variant="info" onPress={make} />
        <Btn testID="pack-bring" title={busy ? 'Reading…' : 'Bring it in'} icon="📥" size="md" variant="primary" disabled={busy} onPress={bring} />
      </View>
      {res && (res.toConfirm || res.waiting) ? <Btn testID="pack-to-match" title={`Supplier products (${res.toConfirm} to confirm)`} icon="🧩" size="sm" variant="info" onPress={() => nav.push('SupplierMatch', {})} /> : null}
      {res ? (
        <Banner tone={res.skipped.length ? 'warn' : 'success'} title="Saved"
          message={`${res.suppliers} suppliers · ${res.products} supplier products linked${res.toConfirm ? ` · ${res.toConfirm} to confirm` : ''}${res.waiting ? ` · ${res.waiting} waiting for their product from Aronium (they link by themselves)` : ''} · ${res.bills} bill accounts · ${res.wallets} wallets · ${res.approvers} approvers${res.skipped.length ? `\nSkipped: ${res.skipped.slice(0, 8).map((s) => `${s.sheet} row ${s.row}: ${s.why}`).join('; ')}${res.skipped.length > 8 ? ' …' : ''}` : ''}`} />
      ) : null}
      {pv ? (
        <>
          <Hint>{`From ${file}. Check each sheet, then Save.`}</Hint>
          {SP.SHEETS.map((s) => {
            const c = pv.counts[s.key];
            if (!c.rows) return null;
            return (
              <Section key={s.key} title={`${s.title} – ${c.rows} row${c.rows === 1 ? '' : 's'}`}>
                <Text testID={`pack-count-${s.key}`} style={{ fontSize: 15, color: C.text }}>{`${c.new} new · ${c.change} update${c.check ? ` · ${c.check} to check` : ''}${c.wait ? ` · ${c.wait} waiting for the product` : ''}${c.problems ? ` · ${c.problems} problem${c.problems === 1 ? '' : 's'}` : ''}`}</Text>
                {pv[s.key].slice(0, 60).map((r) => {
                  const w = WHAT[r.action] || WHAT.new;
                  return (
                    <Card key={`${s.key}${r._row}`} tone={w[1] === 'danger' ? 'danger' : w[1] === 'warn' ? 'warn' : undefined}>
                      <Text style={{ fontSize: 15, color: C.text }}>{`Row ${r._row} · ${w[0]} – ${line(s.key, r)}`}</Text>
                      {r.problems && r.problems.length ? <Text style={{ fontSize: 14, color: C.danger }}>{r.problems.join(' · ')}</Text> : null}
                    </Card>
                  );
                })}
                {pv[s.key].length > 60 ? <Hint>{`… and ${pv[s.key].length - 60} more rows`}</Hint> : null}
              </Section>
            );
          })}
          {pv.counts.products.check ? (
            <Chips testIDPrefix="pack-checks" value={checks} onChange={setChecks} options={[{ value: 'skip', label: 'Ask me about "close name" rows' }, { value: 'save', label: 'Link "close name" rows too' }]} />
          ) : null}
          <Btn testID="pack-save" title="Save" icon="💾" variant="success" onPress={save} />
        </>
      ) : null}
    </Screen>
  );
}
