// v3.9.8 First-time set-up, one step at a time: why it matters, what to have ready, open the screen, tick the checks,
// then Next. Steps can be left for later (they come back at the end). Owner / admin.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ReasonButton, useAct } from '../../../ui/kit.js';
import * as SW from '../../../services/setupWizard.js';
import * as M from '../../../services/migration.js';

export function SetupWizardScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const ui = useUI();
  const [, bump] = useState(0);
  const [list, setList] = useState(false);
  const refresh = () => bump((x) => x + 1);
  let steps = [];
  try { steps = SW.wizardSteps(); } catch (e) { steps = []; }
  const cur = SW.currentStep(steps);
  const done = steps.filter((s) => s.canNext).length;
  const st = SW.wizardState();
  if (!cur || st.finished) {
    return (
      <Screen title="Set-up" subtitle={`${done} of ${steps.length} steps done`}>
        <Banner tone="success" title="The set-up is done" message="Next: the opening figures and going live (Admin › Moving in & go-live). Take your time – check each figure against the paper." />
        <Btn testID="sw-golive" title="Opening figures & go-live" icon="🚀" variant="success" onPress={() => nav.push('GoLive', {})} />
        <Btn testID="sw-list" title="See all the steps" size="md" variant="secondary" onPress={() => { act(() => SW.goTo(user, steps[0].key)); refresh(); }} />
      </Screen>
    );
  }
  const i = steps.findIndex((s) => s.key === cur.key);
  const prev = i > 0 ? steps[i - 1] : null;
  const pct = steps.length ? Math.round((done / steps.length) * 100) : 0;
  return (
    <Screen title={`Set-up – step ${cur.no} of ${steps.length}`} subtitle={cur.phase}
      footer={<Btn testID="sw-next" title={cur.canNext ? 'Next step' : (!cur.done ? 'Finish this step first' : 'Tick the checks first')} icon="➡️" variant="success" disabled={!cur.canNext}
        onPress={() => { if (act(() => SW.nextStep(user, cur.key)) !== null) refresh(); }} />}>
      <View style={{ height: 10, borderRadius: 5, backgroundColor: C.border }}><View style={{ width: `${pct}%`, height: 10, borderRadius: 5, backgroundColor: C.success }} /></View>
      <Text style={{ fontSize: 14, color: C.sub }}>{`${done} of ${steps.length} done${steps.some((s) => s.later && !s.canNext) ? ` · ${steps.filter((s) => s.later && !s.canNext).length} left for later` : ''}. One step at a time – it can be done over several days and carries on where you stopped.`}</Text>

      <Card tone={cur.canNext ? 'success' : undefined}>
        <Text testID="sw-title" style={{ fontSize: 20, fontWeight: '900', color: C.text }}>{cur.title}</Text>
        <Text style={{ fontSize: 16, color: C.text, marginTop: 4 }}>{cur.why}</Text>
        <Text style={{ fontSize: 15, color: C.sub, marginTop: 6 }}>{`Have ready: ${cur.ready}`}</Text>
        <Text style={{ fontSize: 15, color: C.sub }}>{`How: ${cur.how}`}</Text>
        {cur.progress ? <Text testID="sw-progress" style={{ fontSize: 16, fontWeight: '800', color: cur.done ? C.success : C.text, marginTop: 6 }}>{`${cur.done ? '✅ ' : ''}${cur.progress}`}</Text> : null}
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
          <Btn testID="sw-open" title="Open – do this step" icon="📂" size="md" variant="primary" onPress={() => nav.push(cur.screen, cur.params || {})} />
          {!cur.auto ? <Btn testID="sw-done" title={cur.tick && cur.tick.v === 'done' ? 'Not done after all' : 'It is done'} size="sm" variant="secondary" onPress={() => { act(() => M.tickMigration(user, cur.key, cur.tick && cur.tick.v === 'done' ? null : 'done')); refresh(); }} /> : null}
          {!cur.auto ? <Btn testID="sw-na" title={cur.tick && cur.tick.v === 'na' ? 'Needed after all' : 'Not needed for us'} size="sm" variant="ghost" onPress={() => { act(() => M.tickMigration(user, cur.key, cur.tick && cur.tick.v === 'na' ? null : 'na')); refresh(); }} /> : null}
        </View>
      </Card>

      {cur.checks.length ? (
        <Card>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Before moving on, check:</Text>
          {cur.checks.map((c, j) => {
            const on = cur.ticked.includes(j);
            return (
              <Pressable key={j} testID={`sw-check-${j}`} onPress={() => { act(() => SW.tickCheck(user, cur.key, j, !on)); refresh(); }} style={{ flexDirection: 'row', gap: 10, alignItems: 'center', paddingVertical: 6 }}>
                <Text style={{ fontSize: 24, color: on ? C.success : C.sub }}>{on ? '☑' : '☐'}</Text>
                <Text style={{ flex: 1, fontSize: 16, color: C.text }}>{c}</Text>
              </Pressable>
            );
          })}
        </Card>
      ) : null}
      {!cur.done ? <Hint>Next unlocks when the app sees the step is done (or you tick "It is done") and every check is ticked.</Hint> : null}

      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {prev ? <Btn testID="sw-back" title={`Back: ${prev.title.slice(0, 30)}${prev.title.length > 30 ? '…' : ''}`} size="sm" variant="secondary" onPress={() => { act(() => SW.goTo(user, prev.key)); refresh(); }} /> : null}
        {!['samples', 'freshstart'].includes(cur.key) && !cur.canNext ? (
          <ReasonButton testID="sw-later" title="Leave for later" icon="⏳" size="sm" variant="warn" prompt="Why later? (e.g. waiting for the papers)" confirm="Leave for later"
            onDo={(why) => { const r = act(() => SW.leaveForLater(user, cur.key, why), 'It comes back at the end'); refresh(); return r; }} />
        ) : null}
        <Btn testID="sw-all" title={list ? 'Hide the list' : 'All steps'} size="sm" variant="ghost" onPress={() => setList(!list)} />
      </View>
      {list ? steps.map((s) => (
        <Pressable key={s.key} testID={`sw-go-${s.key}`} onPress={() => { act(() => SW.goTo(user, s.key)); setList(false); refresh(); }} style={{ paddingVertical: 4 }}>
          <Text style={{ fontSize: 15, color: s.key === cur.key ? C.info : C.text, fontWeight: s.key === cur.key ? '800' : '400' }}>{`${s.canNext ? '✅' : s.later ? '⏳' : '⬜'} ${s.no}. ${s.title}`}</Text>
        </Pressable>
      )) : null}
    </Screen>
  );
}
