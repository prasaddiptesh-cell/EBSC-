// Admin › Health check, Admin › Alerts & sounds, Admin › Backup & restore (every copy: tablet, outside folder,
// Google Drive).
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ListItem } from '../../../ui/kit.js';
import { actsAsOwner } from '../../../services/access.js';
import { getSetting, getSettings } from '../../../services/core.js';
import { isTraining } from '../../../services/trainingFlag.js';
import { latestHealth, healthHistory, startFullCheck, startQuickCheck, adminPinOk } from '../../../services/health.js';
import { soundSettings, saveSoundSettings, deviceSoundSettings, saveDeviceSoundSettings, TONES, VOLUMES, mutedList, unmuteAlert } from '../../../services/sounds.js';
import { listSnapshots, listOutsideCopies, snapshotNow, restoreSnapshot, REASONS } from '../../../services/snapshots.js';
import { outsideFolder, outsideAvailable, pickOutsideFolder } from '../../../platform/snapshotFiles.js';
import { freeDiskBytes, bytesText } from '../../../platform/device.js';
import { fileExists, pickTextFile } from '../../../platform/files.js';
import { backupNow, restoreBackup, cloudCall, fetchDriveBackup, tidyDrivePhotos } from '../../../platform/cloud.js';
import { playSound, stopUrgent } from '../../../platform/sound.js';
import { openDndSettings } from '../../../platform/notify.js';

const TONE = { ok: C.success, info: C.info, minor: C.warn, damaged: C.danger };
const MARK = { ok: '✓', info: 'ℹ', minor: '!', damaged: '✗' };
const STATUS_TEXT = { ok: 'All fine', minor: 'Something needs a look', damaged: 'Damage found', info: 'All fine' };

function Results({ h, testID }) {
  if (!h) return <Hint>Not run yet.</Hint>;
  return (
    <Card tone={h.status === 'ok' ? 'success' : h.status === 'damaged' ? 'danger' : 'warn'}>
      <Text testID={testID} style={{ fontSize: 18, fontWeight: '800', color: TONE[h.status] || C.text }}>{STATUS_TEXT[h.status] || h.status} · {String(h.at || '').slice(0, 16)}{h.timed_out ? ' · finished in the background' : ''}</Text>
      {(h.results || []).map((r) => (
        <View key={r.id} style={{ flexDirection: 'row', gap: 8, paddingVertical: 4 }}>
          <Text style={{ width: 22, fontSize: 16, fontWeight: '900', color: TONE[r.status] || C.sub }}>{MARK[r.status] || '·'}</Text>
          <Text style={{ flex: 1, fontSize: 15, color: C.text }}><Text style={{ fontWeight: '700' }}>{r.label}: </Text>{r.text}</Text>
        </View>
      ))}
    </Card>
  );
}

export function HealthCheckScreen() {
  const ui = useUI();
  const [busy, setBusy] = useState('');
  const [, setN] = useState(0);
  const quick = latestHealth('quick');
  const full = latestHealth('full');
  const run = async (kind) => {
    setBusy(kind === 'full' ? 'Running the full check…' : 'Checking…');
    try {
      const env = { freeDisk: freeDiskBytes, exists: fileExists };
      const r = kind === 'full' ? startFullCheck(env) : startQuickCheck(env, { budgetMs: 0 });
      const st = await r.all;
      ui.toast(st.status === 'ok' ? 'All fine' : 'Done – see the results', st.status === 'ok' ? 'success' : 'warn');
    } catch (e) { ui.error(e); }
    setBusy('');
    setN((n) => n + 1);
  };
  return (
    <Screen title="Health check" subtitle="Is the data on this device safe and complete?">
      <Explain>Every time the app opens it checks itself in a few seconds (the database, its tables, settings and logins, the clock, free storage, safety copies, a crash last time, items waiting to sync). Once a night, when the tablet is not being used, it runs the full check (every page of the database, the books balance, every document file, items stuck in the outbox). Problems show as warnings on Home.</Explain>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="health-full" title={busy || 'Run full check now'} icon="🩺" variant="success" disabled={!!busy} style={{ flexGrow: 1 }} onPress={() => run('full')} />
        <Btn testID="health-quick" title="Quick check" icon="⚡" size="md" variant="secondary" disabled={!!busy} style={{ flexGrow: 1 }} onPress={() => run('quick')} />
      </View>
      <Section title="Last quick check (on opening)"><Results h={quick} testID="health-quick-result" /></Section>
      <Section title="Last full check"><Results h={full} testID="health-full-result" /></Section>
      <Section title="History">
        {healthHistory(20).map((h) => <Row key={h.id} label={`${String(h.at).slice(0, 16)} · ${h.kind === 'full' ? 'Full' : 'Quick'}`} value={`${MARK[h.status] || ''} ${STATUS_TEXT[h.status] || h.status} · ${(h.ms / 1000).toFixed(1)} s`} color={TONE[h.status]} />)}
      </Section>
    </Screen>
  );
}

const LV = { urgent: 'Urgent', warning: 'Warning', info: 'Info' };
// Tone (with ▶ to hear it) and volume for one level.
function ToneChoice({ level, value, onChange, prefix, allowDefault, label }) {
  const k = LV[level];
  const tone = value[`tone${k}`] || '';
  const vol = value[`vol${k}`] || '';
  const tones = Object.entries(TONES).map(([v, l]) => ({ value: v, label: l }));
  const vols = Object.keys(VOLUMES).map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));
  return (
    <View style={{ gap: 6 }}>
      {label ? <Label>{label}</Label> : null}
      <Chips value={tone} onChange={(v) => onChange({ [`tone${k}`]: v })} testIDPrefix={prefix} options={(allowDefault ? [{ value: '', label: 'Same as every device' }] : []).concat(tones)} />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <Chips value={vol} onChange={(v) => onChange({ [`vol${k}`]: v })} testIDPrefix={`${prefix}-vol`} options={(allowDefault ? [{ value: '', label: 'Usual volume' }] : []).concat(vols)} />
        <Btn testID={`${prefix}-play`} title="▶ Hear it" size="sm" variant="secondary" onPress={() => {
          const t = tone || undefined; const v = vol ? VOLUMES[vol] : undefined;
          playSound(level, { tone: t, volume: v }); if (level === 'urgent') setTimeout(stopUrgent, 3000);
        }} />
      </View>
    </View>
  );
}
export function AlertSoundsScreen() {
  const { user, can } = useApp();
  const ui = useUI();
  const [s, setS] = useState(soundSettings());
  const [d, setD] = useState(deviceSoundSettings());
  const [muted, setMuted] = useState(() => { try { return mutedList(user); } catch (e) { return []; } });
  const admin = can('settings');
  const yn = (v) => (v ? 'y' : 'n');
  const set = (k) => (v) => setS({ ...s, [k]: v === 'y' });
  const setDev = (k) => (v) => { const n = { ...d, [k]: v === 'y' }; setD(saveDeviceSoundSettings(n)); ui.toast('Saved for this device'); };
  const opts = (on, off) => [{ value: 'y', label: on }, { value: 'n', label: off }];
  return (
    <Screen title="Alerts & sounds" subtitle="Sounds for the warnings on Home"
      footer={admin ? <Btn testID="sounds-save" title="Save for every device" icon="💾" variant="success" onPress={() => { try { setS(saveSoundSettings(user, s)); ui.toast('Saved'); } catch (e) { ui.error(e); } }} /> : null}>
      <Explain>Urgent (red) warnings ring like an alarm until someone taps OK, and also come as a phone notification. Yellow warnings chime once; blue information is a soft tone. A sound plays only when a warning is new.</Explain>
      <Section title="For every device (admin)">
        {[['urgent', 'Urgent – alarm until OK'], ['warning', 'Warning – one chime'], ['info', 'Information – soft tone']].map(([k, label]) => (
          <View key={k} style={{ gap: 6 }}>
            <Label>{label}</Label>
            <Chips value={yn(s[k])} onChange={set(k)} testIDPrefix={`snd-${k}`} options={opts('Sound on', 'Silent')} />
            <ToneChoice level={k} value={s} onChange={(n) => setS({ ...s, ...n })} prefix={`snd-tone-${k}`} />
          </View>
        ))}
        <Label>Phone notification for urgent warnings</Label>
        <Chips value={yn(s.notify)} onChange={set('notify')} testIDPrefix="snd-notify" options={opts('Yes', 'No')} />
        <Label>Quiet hours (bakery reminders still sound)</Label>
        <Chips value={yn(s.quietOn)} onChange={set('quietOn')} testIDPrefix="snd-quiet" options={opts('On', 'Off')} />
        {s.quietOn ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Field testID="snd-from" label="From (24 h, e.g. 21:00)" value={s.quietFrom} onChangeText={(v) => setS({ ...s, quietFrom: v })} /></View>
            <View style={{ flex: 1 }}><Field testID="snd-to" label="To (e.g. 06:00)" value={s.quietTo} onChangeText={(v) => setS({ ...s, quietTo: v })} /></View>
          </View>
        ) : null}
        {s.quietOn ? <Chips value={yn(s.urgentInQuiet)} onChange={set('urgentInQuiet')} testIDPrefix="snd-uq" options={opts('Urgent still rings in quiet hours', 'Silent in quiet hours too')} /> : null}
        {!admin ? <Hint>Only the admin can change these.</Hint> : null}
      </Section>
      <Section title="Muted warnings (just for you)">
        {muted.length ? muted.map((m) => (
          <View key={m.kind} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: '700' }} numberOfLines={2}>{m.text || m.kind}</Text>
              <Text style={{ fontSize: 13, color: C.sub }}>{m.until === 'always' ? 'Muted until you unmute it' : `Muted until ${new Date(m.until).toLocaleString()}`}</Text>
            </View>
            <Btn testID={`unmute-${m.kind}`} title="Unmute" size="sm" variant="secondary" onPress={() => { try { unmuteAlert(user, m.kind); setMuted(mutedList(user)); ui.toast('Unmuted'); } catch (e) { ui.error(e); } }} />
          </View>
        )) : <Hint>Nothing muted. Tap Mute on a warning (on Home or on the strip at the top) to stop its sound and phone notification.</Hint>}
      </Section>
      <Section title="This device">
        <Chips value={yn(d.notify !== false)} onChange={setDev('notify')} testIDPrefix="snd-dev-notify" options={opts('Phone notifications on this device', 'No phone notifications on this device')} />
        <Chips value={yn(d.on)} onChange={setDev('on')} testIDPrefix="snd-dev" options={opts('Sounds on this device', 'No sounds on this device')} />
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {['urgent', 'warning', 'info'].map((k) => <Btn key={k} testID={`snd-dev-${k}`} title={`${d[k] ? '✓ ' : ''}${k === 'info' ? 'Information' : k[0].toUpperCase() + k.slice(1)}`} size="sm" variant={d[k] ? 'success' : 'secondary'} onPress={() => setDev(k)(d[k] ? 'n' : 'y')} />)}
        </View>
        <Hint>This device can use its own tone and volume (empty = the choice for every device above).</Hint>
        {['urgent', 'warning', 'info'].map((k) => <ToneChoice key={k} level={k} value={d} allowDefault label={k === 'info' ? 'Information' : k[0].toUpperCase() + k.slice(1)} prefix={`snd-dtone-${k}`}
          onChange={(n) => { setD(saveDeviceSoundSettings({ ...d, ...n })); ui.toast('Saved for this device'); }} />)}
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {['urgent', 'warning', 'info'].map((k) => <Btn key={k} testID={`snd-test-${k}`} title={`▶ ${k}`} size="sm" variant="secondary" onPress={() => { playSound(k); if (k === 'urgent') setTimeout(stopUrgent, 2500); }} />)}
        </View>
        <Btn testID="snd-dnd" title="Let urgent warnings ring in Do Not Disturb" icon="🔕" size="md" variant="info" onPress={() => openDndSettings()} />
        <Hint>Android asks once: turn on "Easy Buys" in the Do Not Disturb access list.</Hint>
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- Backup & restore
function PinAsk({ onOk, onCancel, title }) {
  const [pin, setPin] = useState('');
  const [err, setErr] = useState('');
  return (
    <Card tone="danger">
      <H>{title}</H>
      <Text style={{ fontSize: 15, color: C.text, marginBottom: 8 }}>A safety copy of the data as it is now is made first, so this can be undone. Owner or admin PIN:</Text>
      <Field testID="restore-pin" label="Owner / admin PIN" value={pin} onChangeText={(v) => { setPin(v); setErr(''); }} secure keyboardType="number-pad" />
      {err ? <Text style={{ color: C.danger, fontWeight: '700' }}>{err}</Text> : null}
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
        <Btn testID="restore-cancel" title="Cancel" size="md" variant="secondary" style={{ flex: 1 }} onPress={onCancel} />
        <Btn testID="restore-ok" title="Restore" size="md" variant="danger" style={{ flex: 1 }} onPress={() => (adminPinOk(pin) ? onOk() : setErr('That is not an owner or admin PIN.'))} />
      </View>
    </Card>
  );
}

export function BackupScreen() {
  const { user, logout } = useApp();
  const ui = useUI();
  const [busy, setBusy] = useState('');
  const [tablet, setTablet] = useState([]);
  const [outside, setOutside] = useState([]);
  const [drive, setDrive] = useState(null); // null = not loaded
  const [ask, setAsk] = useState(null); // the copy waiting for the PIN
  const [n, setN] = useState(0);
  const owner = actsAsOwner(user);
  const linked = !!getSettings().cloudUrl;
  useEffect(() => {
    let live = true;
    listSnapshots().then((l) => { if (live) setTablet(l); }).catch(() => {});
    listOutsideCopies().then((l) => { if (live) setOutside(l); }).catch(() => {});
    return () => { live = false; };
  }, [n]);
  const last = getSetting('last_backup_at', '');
  const copyNow = async () => {
    setBusy('Making a copy…');
    const r = await snapshotNow('manual', { outside: 'always' });
    setBusy('');
    if (r.skipped) ui.alert({ title: 'Not copied', message: r.message, tone: 'warn' });
    else if (!r.ok) ui.alert({ title: 'Copy failed', message: r.error, tone: 'danger' });
    else ui.toast(`Copy made (${bytesText(r.size)})`);
    setN((x) => x + 1);
  };
  const boss = owner || (user && user.role === 'admin');
  const tidyNow = async () => {
    setBusy('Tidying Drive photos…');
    const r = await tidyDrivePhotos((t) => setBusy(`Tidying Drive photos… ${t.moved} moved`));
    setBusy('');
    ui.alert({
      title: r.ok ? (r.more ? 'Tidied – some left for next time' : 'Drive photos tidied') : 'Not tidied',
      message: r.ok
        ? `${r.moved} moved into Records › month folders.${r.left ? ` ${r.left} left where they were (no record found for them).` : ''}${r.more ? ' Tap the button again for the rest.' : ''}`
        : `${r.message}${/Unknown request/i.test(r.message || '') ? '\n(Paste the new cloud script 16 into Apps Script and deploy a new version first.)' : ''}`,
      tone: r.ok ? 'primary' : 'danger',
    });
  };
  const driveNow = async () => { setBusy('Backing up…'); const r = await backupNow(); setBusy(''); ui.alert({ title: r.ok ? 'Backed up' : 'Not backed up', message: r.message, tone: r.ok ? 'primary' : 'danger' }); };
  const loadDrive = async () => {
    setBusy('Asking Google Drive…');
    try { const r = await cloudCall({ kind: 'backup_list', limit: 40 }, 60000); setDrive(r.files || []); } catch (e) { ui.alert({ title: 'Could not list the Drive backups', message: `${e.message || e}\n(If it says "Unknown request", paste the new cloud script first.)`, tone: 'warn' }); }
    setBusy('');
  };
  const pickFolder = async () => {
    try { const f = await pickOutsideFolder(); if (f) { ui.toast('Folder chosen'); await snapshotNow('daily', { outside: 'always' }); setN((x) => x + 1); } } catch (e) { ui.error(e); }
  };
  const doRestore = async (c) => {
    setAsk(null);
    setBusy('Restoring…');
    try {
      if (c.where === 'drive') {
        const safety = await snapshotNow('before-restore', { outside: false });
        if (!safety.ok && !safety.skipped) throw new Error(`The safety copy could not be made (${safety.error}). Nothing was changed.`);
        const data = await fetchDriveBackup(c.id); // 1.0.0: a backup made in parts is put back together
        if (!data || !data._meta) throw Object.assign(new Error('This is not an Easy Buys backup file.'), { isAppError: true });
        const count = restoreBackup(user, data, c.name || 'Google Drive');
        ui.alert({ title: 'Restored', message: `${count} records put back from ${c.name}. A safety copy was made first (${safety.name || '—'}).` });
      } else if (c.where === 'file') {
        const safety = await snapshotNow('before-restore', { outside: false });
        const count = restoreBackup(user, c.data, c.name || 'a file');
        ui.alert({ title: 'Restored', message: `${count} records put back. A safety copy was made first (${safety.name || '—'}).` });
      } else {
        const r = await restoreSnapshot(user, c);
        ui.alert({ title: 'Restored', message: `The data is back as it was on ${c.at.slice(0, 16)}. A safety copy of what was there before was made (${r.safety.name}). Please log in again.` });
        setBusy('');
        if (logout) logout();
        return;
      }
    } catch (e) { ui.error(e); }
    setBusy('');
    setN((x) => x + 1);
  };
  const fromFile = async () => {
    try {
      const f = await pickTextFile();
      if (!f) return;
      const data = JSON.parse(f.text);
      if (!data || !data._meta) throw Object.assign(new Error('This is not an Easy Buys backup file.'), { isAppError: true });
      setAsk({ where: 'file', name: f.name, at: data._meta.made || '', data });
    } catch (e) { ui.error(e); }
  };
  const restoreBtn = (c, id) => (owner && !isTraining() ? <Btn testID={`restore-${id}`} title="Restore" size="sm" variant="secondary" onPress={() => setAsk(c)} /> : null);
  return (
    <Screen title="Backup & restore" subtitle={last ? `Last Google Drive backup ${last.slice(0, 16)}` : 'Every copy of the data'}>
      <Explain title="How the copies work">
        Three kinds of copies keep the data safe. On this tablet: a full copy every few hours and before risky steps (kept 7 days, then one a week for a month).
        In a folder outside the app: one copy a day, so it is still there if the app is removed. In Google Drive (Easy Buys › Backups): a full backup every day when online.
        Any copy can be put back; a safety copy of the data as it is now is always made first. Training (practice) data is never copied.
      </Explain>
      {isTraining() ? <Banner tone="warn" message="Training mode is on: the practice data is not copied and nothing can be restored. Leave training mode first." /> : null}
      {ask ? <PinAsk title={`Restore the copy from ${String(ask.at || '').slice(0, 16) || ask.name}?`} onCancel={() => setAsk(null)} onOk={() => doRestore(ask)} /> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="bk-snapshot" title={busy || 'Make a copy now'} icon="💾" variant="success" disabled={!!busy || isTraining()} style={{ flexGrow: 1 }} onPress={copyNow} />
        {linked ? <Btn testID="bk-now" title="Back up to Google Drive now" icon="☁️" size="md" variant="secondary" disabled={!!busy} style={{ flexGrow: 1 }} onPress={driveNow} /> : null}
      </View>
      {linked && boss ? <Btn testID="bk-tidy" title="Tidy Drive photos into month folders" icon="🗂️" size="md" variant="secondary" disabled={!!busy || isTraining()} onPress={tidyNow} /> : null}
      <Section title={`On this tablet (${tablet.length})`}>
        {!tablet.length ? <Hint testID="bk-none">No copies yet – one is made in the first hours of use, or tap "Make a copy now".</Hint> : null}
        {tablet.map((c, i) => (
          <View key={c.name} testID={`bk-tab-${i}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{ flex: 1 }}><ListItem title={`${c.at.slice(0, 16)} · ${c.label}`} sub={`${bytesText(c.size)} · ${c.name}`} /></View>
            {restoreBtn(c, `tab-${i}`)}
          </View>
        ))}
      </Section>
      <Section title="In the folder outside the app">
        {outsideFolder() ? (
          <>
            <Text testID="bk-folder" style={{ fontSize: 15, color: C.sub }}>Folder: {decodeURIComponent(outsideFolder()).split(/[:/]/).slice(-2).join('/')}</Text>
            {outside.map((c, i) => (
              <View key={c.uri} testID={`bk-out-${i}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <View style={{ flex: 1 }}><ListItem title={`${c.at.slice(0, 16)} · ${c.label}`} sub={c.name} /></View>
                {restoreBtn(c, `out-${i}`)}
              </View>
            ))}
            {!outside.length ? <Hint>No copy there yet.</Hint> : null}
            <Btn title="Choose another folder" size="sm" variant="secondary" onPress={pickFolder} />
          </>
        ) : (
          <>
            <Hint>Not chosen yet. Choose a folder such as Documents › Easy Buys Backups; Android asks once.</Hint>
            <Btn testID="bk-pick-folder" title="Choose the outside folder" icon="📁" size="md" variant="info" disabled={!outsideAvailable() || isTraining()} onPress={pickFolder} />
          </>
        )}
      </Section>
      <Section title="In Google Drive">
        {!linked ? <Hint>This device is not linked to the Easy Buys cloud.</Hint> : drive === null ? (
          <Btn testID="bk-drive-list" title="Show the Drive backups" icon="☁️" size="md" variant="secondary" disabled={!!busy} onPress={loadDrive} />
        ) : (
          <>
            {!drive.length ? <Hint>No backups in Drive yet.</Hint> : null}
            {drive.map((f, i) => (
              <View key={f.id} testID={`bk-drive-${i}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <View style={{ flex: 1 }}><ListItem title={`${String(f.at).slice(0, 16).replace('T', ' ')} · Google Drive`} sub={`${f.name} · ${bytesText(f.size)}`} /></View>
                {restoreBtn({ where: 'drive', id: f.id, name: f.name, at: String(f.at).replace('T', ' ') }, `drive-${i}`)}
              </View>
            ))}
          </>
        )}
        <Hint>Restoring a Drive backup puts its records back (newest wins on the other devices); nothing else is deleted and logins are not changed.</Hint>
      </Section>
      <Section title="Windows PC">
        <Hint>Copies on the office PC will show here once the Windows software is set up.</Hint>
      </Section>
      {owner ? <Btn testID="bk-restore" title="Restore from a backup file" icon="♻️" size="md" variant="secondary" onPress={fromFile} /> : null}
    </Screen>
  );
}
