// v3.9.6 Shop profile: one page per shop, laid out like the staff profile – details and opening hours, bill
// accounts, papers & expiry dates, the shop at a glance, and what it costs (view only).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Row, Badge, Chips, Select, Label, useApp, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ListItem, Stats, useAct } from '../../../ui/kit.js';
import { money, dateStr } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import { db } from '../../../db/connection.js';
import { listUsers } from '../../../services/catalog.js';
import { allScreens } from '../../registry.js';
import * as SP from '../../../services/shopProfile.js';
import { DeleteButton } from './BinScreens.js';

const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');
const FREQ = { weekly: 'a week', fortnightly: 'a fortnight', monthly: 'a month', quarterly: 'a quarter', yearly: 'a year' };
const STATE = { ok: ['OK', C.success], due: ['Renew soon', C.warn], renewing: ['Renewing', C.info], overdue: ['Expired', C.danger], none: ['No expiry', C.sub], cancelled: ['Cancelled', C.sub] };

function useMay() {
  const { user, screens: ctxScreens } = useApp();
  const screens = ctxScreens || allScreens();
  return (name) => { try { const s = screens[name]; return !!s && (!s.can || s.can(user)); } catch (e) { return false; } };
}

export function ShopProfilesScreen() {
  const { nav, user } = useApp();
  let cards = []; let err = null;
  try { cards = SP.shopCards(user); } catch (e) { err = e.message; }
  if (err) return <Screen title="Shops"><Banner tone="info" message={err} /></Screen>;
  return (
    <Screen title="Shops" subtitle="One page per shop – details, bills, papers, costs">
      {cards.map((s) => (
        <ListItem key={s.code} testID={`shp-${s.code}`} title={`${s.name}`} tone={s.attention ? 'warn' : undefined}
          sub={[s.code, s.address, s.active ? (s.open.open ? `Open now until ${s.open.until}` : s.open.known ? 'Closed now' : null) : 'Closed shop', `${s.accounts} bill account${s.accounts === 1 ? '' : 's'}`, `${s.papers} paper${s.papers === 1 ? '' : 's'}${s.attention ? ` (${s.attention} to renew)` : ''}`].filter(Boolean).join(' · ')}
          onPress={() => nav.push('ShopProfile', { code: s.code })} />
      ))}
      {!cards.length ? <Hint>No shops yet. Add them in Settings › Shops & cost areas.</Hint> : null}
    </Screen>
  );
}

export function ShopProfileScreen({ params = {} }) {
  const { nav, user } = useApp();
  useTick(60000);
  const may = useMay();
  const [period, setPeriod] = useState('month');
  let P = null; let err = null;
  try { P = SP.shopProfile(params.code, user); } catch (e) { err = e.message; }
  if (!P) return <Screen title="Shop"><Banner tone="danger" message={err || 'Shop not found.'} /></Screen>;
  const s = P.shop; const g = P.glance;
  const edit = SP.canEditShop(user);
  let costs = null;
  if (SP.canSeeCosts(user)) { try { costs = SP.shopCosts(s.code, user, { period }); } catch (e) { costs = null; } }
  const go = (name, p) => () => nav.push(name, p || {});
  const editBtn = (id, title, icon, onPress) => <Btn testID={`shp-${id}`} title={title} icon={icon} size="sm" variant="secondary" onPress={onPress} />;
  return (
    <Screen title={s.name} subtitle={[s.code, s.address].filter(Boolean).join(' · ') || 'Shop'}>
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
        {!s.active ? <Badge text="Closed shop" color={C.sub} /> : P.open.open ? <Badge text={`Open now · until ${P.open.until}`} color={C.success} /> : P.open.known ? <Badge text={`Closed now${P.open.next ? ` · opens ${P.open.next.day} ${P.open.next.at}` : ''}`} color={C.sub} /> : null}
        {s.tin ? <Badge text={`TIN ${s.tin}`} color={C.info} /> : null}
      </View>
      {P.warnings.length ? (
        <Card tone="warn">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`To sort out (${P.warnings.length})`}</Text>
          {P.warnings.map((w) => <Text testID={`shp-warn-${w.key}`} key={w.key} style={{ color: C.text, fontSize: 15 }}>{`• ${w.text}`}</Text>)}
        </Card>
      ) : <Banner tone="success" message="Everything is in place for this shop." />}

      <Section title="At a glance">
        <Stats items={[
          g.sales ? { label: 'Sales today', value: money(g.sales.today), sub: g.sales.usual ? `Usual ${money(g.sales.usual)} · yesterday ${money(g.sales.yesterday)}` : `Yesterday ${money(g.sales.yesterday)}`, testID: 'shp-g-sales' } : null,
          g.staff ? { label: 'Staff in now', value: String(g.staff.in), sub: g.staff.late ? `${g.staff.late} late` : `${g.staff.total} on today`, color: g.staff.late ? C.warn : undefined, testID: 'shp-g-staff', onPress: may('WhoIsOn') ? go('WhoIsOn', { shopCode: s.code }) : undefined } : null,
          g.verify !== null && g.verify !== undefined ? { label: 'To verify', value: String(g.verify), color: g.verify ? C.warn : undefined, testID: 'shp-g-verify', onPress: may('Verify') ? go('Verify', {}) : undefined } : null,
          g.orders ? { label: 'Open orders', value: String(g.orders.open), sub: [g.orders.awaiting ? `${g.orders.awaiting} to approve` : null, g.orders.late ? `${g.orders.late} late` : null].filter(Boolean).join(' · ') || undefined, color: g.orders.late ? C.warn : undefined, testID: 'shp-g-orders', onPress: may('POList') ? go('POList', { shopCode: s.code }) : undefined } : null,
          g.stock ? { label: 'Low stock', value: String(g.stock.low), sub: g.stock.out ? `${g.stock.out} out of stock` : undefined, color: g.stock.out ? C.danger : undefined, testID: 'shp-g-stock' } : null,
          { label: 'Papers to renew', value: String(g.papers.due + g.papers.overdue), sub: g.papers.overdue ? `${g.papers.overdue} expired` : undefined, color: g.papers.overdue ? C.danger : g.papers.due ? C.warn : undefined, testID: 'shp-g-papers' },
        ]} />
        {g.tills.length ? g.tills.map((t) => <Row key={t.source} label={`Till ${t.till}`} value={t.lastSeen ? `Last heard ${String(t.lastSeen).slice(0, 16)}` : 'Not heard yet'} />) : null}
        {g.sales ? <Hint>{`Sales from ${g.sales.source}.`}</Hint> : null}
      </Section>

      <Section title="Details" right={edit ? editBtn('edit', 'Edit', '✎', go('ShopEdit', { code: s.code })) : null}>
        <Row label="Address" value={s.address || '–'} />
        <Row label="Phone" value={s.phone || '–'} />
        <Row label="Email" value={s.email || '–'} />
        <Row label="TIN" value={s.tin || '–'} />
        <Row label="M-PAiSA wallet" value={s.mpaisa || '–'} />
        <Row label="Person in charge" value={P.manager ? P.manager.name : '–'} />
        <Row label="Landlord" value={s.landlord || '–'} />
        {s.notes ? <Text style={{ fontSize: 15, color: C.sub }}>{s.notes}</Text> : null}
      </Section>

      <Section title="Opening hours" right={edit ? editBtn('hours', 'Edit', '🕘', go('ShopEdit', { code: s.code })) : null}>
        {SP.DAYS.map(([k, label]) => <Row key={k} label={label} value={SP.hoursText(s.hours[k])} />)}
      </Section>

      <Section title="Bill accounts" right={edit ? editBtn('acc-add', 'Add', '➕', go('ShopAccount', { code: s.code })) : null}>
        {!P.accounts.length ? <Hint>No bill accounts yet. Add the EFL, WAF, phone and internet accounts of this shop (each with its own name, e.g. "EFL – bakery meter").</Hint> : null}
        {P.accounts.map((a) => (
          <Pressable key={a.uid} testID={`shp-acc-${a.uid}`} disabled={!edit} onPress={go('ShopAccount', { code: s.code, uid: a.uid })}
            style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.border, padding: 12, gap: 2, opacity: pressed ? 0.7 : 1 })}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${a.kindInfo.icon} ${a.label}`}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>{[a.provider, a.account_no ? `Account ${a.account_no}` : null, a.meter_no ? `Meter ${a.meter_no}` : null].filter(Boolean).join(' · ')}</Text>
            {a.last ? <Text style={{ fontSize: 15, color: a.last.owing > 0.004 ? C.warn : C.text }}>{`Last bill ${a.last.no || ''} · ${d(a.last.date)} · ${money(a.last.total)}${a.last.owing > 0.004 ? ` · ${money(a.last.owing)} owing, due ${d(a.last.due)}` : a.last.owing === 0 ? ' · paid' : ''}`}</Text> : null}
            {a.regular ? <Text style={{ fontSize: 15, color: C.text }}>{`Regular payment ${money(a.regular.amount)} ${FREQ[a.regular.frequency] || ''} · next ${d(a.regular.next)}`}</Text> : null}
          </Pressable>
        ))}
        <Hint>Bills are still entered as invoices (Receive / Invoices). Pick the supplier on the account and its latest bill shows here.</Hint>
      </Section>

      <Section title="Papers & expiry dates" right={may('LicenceEdit') ? editBtn('lic-add', 'Add', '➕', go('LicenceEdit', { shopCode: s.code })) : null}>
        {!P.papers.length ? <Hint>No papers for this shop yet: liquor and spirit licences, business licence, health licence, fire certificate, lease…</Hint> : null}
        {P.papers.map((p) => {
          const st = STATE[p.state] || STATE.none;
          return (
            <ListItem key={p.uid} testID={`shp-lic-${p.uid}`} title={p.name} badge={st[0]} badgeColor={st[1]} tone={p.state === 'overdue' ? 'danger' : p.state === 'due' ? 'warn' : undefined}
              sub={[p.licence_no, p.expiry_date ? `Expires ${d(p.expiry_date)}${p.days !== null ? (p.days < 0 ? ` (${-p.days} days ago)` : ` (${p.days} days)`) : ''}` : 'No expiry date', p.noCopy ? 'No copy attached' : `${p.docs} cop${p.docs === 1 ? 'y' : 'ies'}`].filter(Boolean).join(' · ')}
              onPress={may('Licence') ? go('Licence', { uid: p.uid }) : undefined} />
          );
        })}
        <Hint>Each paper keeps its copies (photo or PDF, filed in Google Drive) and every renewal. Reminders start before it expires and get louder at 30 and 7 days.</Hint>
      </Section>

      {costs ? (
        <Section title="What this shop costs (view only)">
          <Chips value={period} onChange={setPeriod} testIDPrefix="shp-per" options={[{ value: 'month', label: 'This month' }, { value: 'last', label: 'Last month' }, { value: 'year', label: 'This year' }, { value: '12m', label: '12 months' }]} />
          <Stats items={[
            { label: 'Invoices & bills', value: money(costs.total), sub: `${costs.count || 0} · VAT ${money(costs.vat)}`, testID: 'shp-c-total' },
            costs.wages ? { label: 'Wages (incl. employer FNPF)', value: money(costs.wages.total), sub: `${costs.wages.people} people`, testID: 'shp-c-wages' } : null,
            costs.regular ? { label: 'Regular payments', value: money(costs.regularMonthly || 0), sub: 'about a month', testID: 'shp-c-regular' } : null,
          ]} />
          {costs.groups.map((x) => <Row key={x.name} label={`${x.name} (${x.count})`} value={money(x.total)} />)}
          {costs.regular && costs.regular.length ? (
            <View style={{ gap: 4, marginTop: 6 }}>
              <Label>Rent, loans and regular bills</Label>
              {costs.regular.map((r) => <Row key={r.uid} label={`${r.kind === 'loan' ? '🏦' : '🔁'} ${r.name}`} value={`${money(r.amount)} ${FREQ[r.frequency] || ''}`} />)}
            </View>
          ) : null}
          {costs.invoices.slice(0, 10).map((i) => (
            <ListItem key={i.uid} testID={`shp-inv-${i.uid}`} title={`${i.supplier_name}${i.invoice_no ? ` · ${i.invoice_no}` : ''}`} sub={`${d(i.invoice_date)}${i.category ? ` · ${i.category}` : ''}`} right={money(i.total)}
              onPress={may('ApInvoice') ? go('ApInvoice', { uid: i.uid }) : undefined} />
          ))}
          <Hint>Costs are entered where they always are (Receive, Invoices, Regular payments, Loans & rent). This page only shows them for the shop.</Hint>
        </Section>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <DeleteButton table="shops" keyVal={s.code} title="Delete this shop" testID="shp-delete" />
      </View>
    </Screen>
  );
}

const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
// Typing "7" or "730" or "7.30" becomes 07:00 / 07:30.
export function tidyTime(v) {
  const t = String(v || '').trim().replace(/[.\sh]/gi, ':');
  if (!t) return '';
  if (HHMM.test(t)) return t;
  const m = /^(\d{1,2})(?::?(\d{2}))?$/.exec(t);
  if (m) { const h = Number(m[1]); const mm = Number(m[2] || 0); if (h <= 23 && mm <= 59) return `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}`; }
  return String(v || '').trim();
}

export function ShopEditScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const s = SP.getShop(params.code);
  const [f, setF] = useState(() => (s ? { name: s.name, address: s.address || '', phone: s.phone || '', email: s.email || '', tin: s.tin || '', mpaisa: s.mpaisa || '', landlord: s.landlord || '', notes: s.notes || '', managerUid: s.manager_uid || '', hours: s.hours } : null));
  if (!s || !f) return <Screen title="Shop"><Banner tone="danger" message="Shop not found." /></Screen>;
  if (!SP.canEditShop(user)) return <Screen title="Shop"><Banner tone="info" message="Only the owner, admin or someone with Settings can change a shop." /></Screen>;
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const setDay = (day, k, v) => setF((o) => ({ ...o, hours: { ...o.hours, [day]: { ...o.hours[day], [k]: v } } }));
  const people = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const save = () => {
    const hours = Object.fromEntries(SP.DAYS.map(([k]) => [k, { ...f.hours[k], open: tidyTime(f.hours[k].open), close: tidyTime(f.hours[k].close) }]));
    const r = act(() => SP.saveShopDetails(user, s.code, { ...f, hours }), 'Saved');
    if (r !== null) nav.pop();
  };
  return (
    <Screen title={`Edit ${s.name}`} subtitle={s.code} footer={<Btn testID="se-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Field testID="se-name" label="Shop name" value={f.name} onChangeText={set('name')} />
      <Field testID="se-address" label="Address" value={f.address} onChangeText={set('address')} />
      <Field testID="se-phone" label="Phone" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
      <Field testID="se-email" label="Email" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
      <Field testID="se-tin" label="TIN (printed on this shop's purchase orders)" value={f.tin} onChangeText={set('tin')} />
      <Field testID="se-mpaisa" label="M-PAiSA wallet number" value={f.mpaisa} onChangeText={set('mpaisa')} keyboardType="phone-pad" />
      <Select testID="se-manager" label="Person in charge" value={f.managerUid} onChange={set('managerUid')} search options={[{ value: '', label: '– nobody –' }].concat(people.map((u) => ({ value: u.uid, label: u.name })))} />
      <Field testID="se-landlord" label="Landlord" value={f.landlord} onChangeText={set('landlord')} />
      <Field testID="se-notes" label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
      <Section title="Opening hours">
        <Hint>Type the times like 07:00 and 21:00. A closing time earlier than the opening time means it closes after midnight.</Hint>
        {SP.DAYS.map(([k, label]) => (
          <View key={k} style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, flexWrap: 'wrap' }}>
            <Text style={{ width: 110, fontSize: 17, fontWeight: '700', color: C.text, paddingBottom: 14 }}>{label}</Text>
            {f.hours[k].closed ? <Text style={{ flex: 1, fontSize: 17, color: C.sub, paddingBottom: 14 }}>Closed all day</Text> : (
              <>
                <View style={{ width: 120 }}><Field testID={`se-${k}-open`} label="Opens" value={f.hours[k].open} onChangeText={(v) => setDay(k, 'open', v)} placeholder="07:00" /></View>
                <View style={{ width: 120 }}><Field testID={`se-${k}-close`} label="Closes" value={f.hours[k].close} onChangeText={(v) => setDay(k, 'close', v)} placeholder="21:00" /></View>
              </>
            )}
            <Btn testID={`se-${k}-closed`} title={f.hours[k].closed ? 'Open this day' : 'Closed'} size="sm" variant="ghost" onPress={() => setDay(k, 'closed', !f.hours[k].closed)} />
          </View>
        ))}
        <Btn testID="se-copy-mon" title="Same hours as Monday for Tue–Sat" size="sm" variant="secondary" onPress={() => setF((o) => ({ ...o, hours: { ...o.hours, ...Object.fromEntries(['tue', 'wed', 'thu', 'fri', 'sat'].map((k) => [k, { ...o.hours.mon }])) } }))} />
      </Section>
    </Screen>
  );
}

export function ShopAccountScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const before = params.uid ? SP.getAccount(params.uid) : null;
  const code = before ? before.shop_code : params.code;
  const shop = SP.getShop(code);
  const [f, setF] = useState(() => ({ uid: before ? before.uid : '', shopCode: code, kind: before ? before.kind : 'power', label: before ? before.label : '', provider: before ? before.provider || '' : '',
    accountNo: before ? before.account_no || '' : '', meterNo: before ? before.meter_no || '' : '', holder: before ? before.holder || '' : 'Easy Buys Shopping Centre', supplierUid: before ? before.supplier_uid || '' : '',
    recurringUid: before ? before.recurring_uid || '' : '', notes: before ? before.notes || '' : '' }));
  if (!shop) return <Screen title="Bill account"><Banner tone="danger" message="Shop not found." /></Screen>;
  if (!SP.canEditShop(user)) return <Screen title="Bill account"><Banner tone="info" message="Only the owner, admin or someone with Settings can change bill accounts." /></Screen>;
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const info = SP.ACCOUNT_KINDS[f.kind] || SP.ACCOUNT_KINDS.other;
  let suppliers = []; let regular = [];
  try { suppliers = db().all('SELECT uid, name FROM ap_suppliers WHERE active = 1 ORDER BY name'); } catch (e) { suppliers = []; }
  try { regular = db().all("SELECT uid, name, amount, frequency, shop_code FROM ap_recurring WHERE active = 1 AND kind = 'bill' ORDER BY (shop_code = ?) DESC, name", [code]); } catch (e) { regular = []; }
  const save = () => { const r = act(() => SP.saveAccount(user, { ...f, provider: f.provider || info.provider }), 'Saved'); if (r !== null) nav.pop(); };
  return (
    <Screen title={before ? `Change ${before.label}` : 'Add a bill account'} subtitle={shop.name} footer={<Btn testID="sa-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Label>What is it for?</Label>
      <Chips value={f.kind} onChange={set('kind')} testIDPrefix="sa-k" options={Object.entries(SP.ACCOUNT_KINDS).map(([value, k]) => ({ value, label: `${k.icon} ${k.label}` }))} />
      <Field testID="sa-label" label={`Name (e.g. "${info.label} – bakery")`} value={f.label} onChangeText={set('label')} placeholder={info.label} />
      <Field testID="sa-provider" label="Company" value={f.provider} onChangeText={set('provider')} placeholder={info.provider || 'e.g. Digicel, Vodafone, TFL'} />
      <Field testID="sa-no" label="Account number (as on the bill)" value={f.accountNo} onChangeText={set('accountNo')} />
      {info.meter ? <Field testID="sa-meter" label="Meter number" value={f.meterNo} onChangeText={set('meterNo')} /> : null}
      <Field testID="sa-holder" label="Name on the bill" value={f.holder} onChangeText={set('holder')} />
      <Select testID="sa-supplier" label="Supplier in Invoices (shows the latest bill)" value={f.supplierUid} onChange={set('supplierUid')} search options={[{ value: '', label: '– not linked –' }].concat(suppliers.map((x) => ({ value: x.uid, label: x.name })))} />
      <Select testID="sa-regular" label="Regular payment (if it is paid as a regular bill)" value={f.recurringUid} onChange={set('recurringUid')} search options={[{ value: '', label: '– none –' }].concat(regular.map((x) => ({ value: x.uid, label: `${x.name} · ${money(x.amount)} ${FREQ[x.frequency] || ''}` })))} />
      <Field testID="sa-notes" label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
      {before ? <DeleteButton table="shop_accounts" keyVal={before.uid} title="Delete this account" testID="sa-delete" /> : null}
    </Screen>
  );
}
