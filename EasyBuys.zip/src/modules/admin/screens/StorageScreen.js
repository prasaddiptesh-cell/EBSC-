// v3.9.5 Storage on this device: how much space the app, the photos and the safety copies take, and what is kept where.
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Row, Btn, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Stats } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { storageReport, bytesText } from '../../../platform/device.js';

export function StorageScreen() {
  const [r, setR] = useState(null);
  const [busy, setBusy] = useState(false);
  const load = () => { setBusy(true); storageReport().then((x) => { setR(x); setBusy(false); }).catch(() => { setR({}); setBusy(false); }); };
  useEffect(() => { load(); }, []);
  let ph = { n: 0, up: 0 };
  try { ph = db().get("SELECT COUNT(*) AS n, SUM(CASE WHEN cloud_url IS NOT NULL AND cloud_url <> '' THEN 1 ELSE 0 END) AS up FROM photos") || ph; } catch (e) { /* ignore */ }
  const used = r ? [r.db, r.photos && r.photos.bytes, r.snaps && r.snaps.bytes, r.docs && r.docs.bytes].reduce((a, b) => a + (Number(b) || 0), 0) : null;
  const low = r && r.free !== null && r.free !== undefined && r.free < 1e9;
  return (
    <Screen title="Storage on this device" subtitle="What the app keeps on this tablet or phone">
      <Stats items={[{ label: 'Free on the device', value: r ? bytesText(r.free) : '…', color: low ? C.danger : undefined }, { label: 'Used by Easy Buys', value: r ? bytesText(used) : '…' },
        { label: 'Photos', value: String(ph.n || 0), sub: `${ph.up || 0} already in Google Drive` }]} />
      {low ? <Card tone="danger"><Text style={{ fontSize: 16, color: C.danger, fontWeight: '800' }}>Less than 1 GB free. Delete old videos or apps on this device; the app's records are safe.</Text></Card> : null}
      <Card>
        <Row label="Records (database)" value={r ? bytesText(r.db) : '…'} />
        <Row label={`Photos (${r && r.photos ? r.photos.files || 0 : '…'} files)`} value={r && r.photos ? bytesText(r.photos.bytes) : '…'} />
        <Row label={`Safety copies (${r && r.snaps ? r.snaps.files || 0 : '…'})`} value={r && r.snaps ? bytesText(r.snaps.bytes) : '…'} />
        <Row label={`Documents (${r && r.docs ? r.docs.files || 0 : '…'})`} value={r && r.docs ? bytesText(r.docs.bytes) : '…'} />
      </Card>
      <Hint>Where things are kept: every record is on each device and in the Easy Buys Google sheet. Photos of invoices, cheques and receipts are made smaller when taken, then copied to Google Drive when online. Safety copies of the records are kept on this device (the oldest are removed by themselves) and in Drive › Backups. Copies made for the Viber Channel (Drive › Viber posts) go to the Drive bin after 30 days.</Hint>
      <View style={{ flexDirection: 'row' }}><Btn testID="storage-refresh" title={busy ? 'Counting…' : 'Count again'} icon="🔄" size="md" variant="secondary" disabled={busy} onPress={load} /></View>
    </Screen>
  );
}
