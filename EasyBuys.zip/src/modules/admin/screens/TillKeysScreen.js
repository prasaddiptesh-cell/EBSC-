// 1.0.0 build 1: one key per till PC for the Aronium Link (it may only send that till's own figures). Made or replaced by
// the owner / admin (logged in – the cloud checks); shown ONCE here to type into the Link on that till PC; the cloud keeps
// only its fingerprint. When every till PC has its own key: "All till PCs have their key" – the shared key stops working.
import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Select, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';

const TILLS = ['S1-T1', 'S1-T2', 'S2-T1', 'S2-T2'];
export function TillKeysScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [list, setList] = useState(null);
  const [till, setTill] = useState('S1-T1');
  const [shown, setShown] = useState(null);
  const boss = user && ['owner', 'admin'].includes(user.role);
  const call = (b) => require('../../../platform/cloud.js').cloudCall(b, 30000);
  const load = async () => { try { const r = await call({ kind: 'link_keys' }); setList(r.tills || []); } catch (e) { setList(null); } };
  useEffect(() => { load(); }, []);
  if (!boss) return <Screen title="Till keys"><Banner tone="danger" message="Only the owner or admin." /></Screen>;
  const make = async () => {
    const has = (list || []).some((t) => t.source === till);
    if (has && !(await ui.confirm({ title: `New key for ${till}?`, message: 'The old key of this till PC stops working at once. Type the new key into the Link on that till PC.', confirmText: 'Make a new key' }))) return;
    try { const r = await call({ kind: 'link_key', source: till }); setShown(r); load(); } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
  };
  const cutover = async () => {
    if (!(await ui.confirm({ title: 'Every till PC has its own key?', message: 'From now on a till PC with only the old shared key is refused (and you get an email).', confirmText: 'Yes' }))) return;
    try { await call({ kind: 'cloud_settings', linkCutover: true }); ui.toast('Done – only till keys from now on'); } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
  };
  return (
    <Screen title="🔒 Till keys" subtitle="Aronium › Till PCs">
      <Hint>Each till PC gets its own key. It can only send that till's sales – nothing else, and it can read nothing.</Hint>
      {list === null ? <Banner tone="warn" message="Needs the internet (and the owner or admin logged in)." /> : (
        <Card>
          {TILLS.map((t) => { const k = list.find((x) => x.source === t); return <Text key={t} testID={`tk-${t}`} style={{ fontSize: 16, color: C.text }}>{`${k ? '✅' : '⬜'} ${t}${k ? ` – key made ${String(k.at).slice(0, 10)}` : ' – no key yet'}`}</Text>; })}
        </Card>
      )}
      <Select testID="tk-till" label="Which till PC?" value={till} options={TILLS.map((t) => ({ value: t, label: t }))} onChange={setTill} />
      <Btn testID="tk-make" title="Make the key for this till PC" icon="🔑" variant="primary" onPress={make} />
      {shown ? (
        <Card tone="warn">
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`Key for ${shown.source} – shown only now:`}</Text>
          <Text testID="tk-key" selectable style={{ fontSize: 15, color: C.text, fontFamily: 'monospace' }}>{shown.key}</Text>
          <Hint>Type it into the Aronium Link on that till PC (Settings › Till key). It is not shown again.</Hint>
          <Btn testID="tk-hide" title="Done – hide it" size="sm" variant="secondary" onPress={() => setShown(null)} />
        </Card>
      ) : null}
      <View style={{ marginTop: 10 }}><Btn testID="tk-cutover" title="All till PCs have their key" size="md" variant="secondary" onPress={cutover} /></View>
    </Screen>
  );
}
