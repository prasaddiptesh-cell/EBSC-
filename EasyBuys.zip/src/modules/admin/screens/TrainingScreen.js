// Training mode on / off: a practice copy of the app with sample figures, for learning and trying things out.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { isTraining, enterTraining, leaveTraining, trainingProblems } from '../../../platform/training.js';
import { TRAINING_LOGINS } from '../../../db/trainingSeed.js';
import { snapshotNow } from '../../../services/snapshots.js';

export function TrainingScreen() {
  const { logout } = useApp();
  const ui = useUI();
  const [busy, setBusy] = useState(false);
  const on = isTraining();
  const go = async (fn, msg) => {
    setBusy(true);
    await new Promise((r) => setTimeout(r, 50)); // let "Please wait" show
    try { fn(); logout(); ui.toast(msg); } catch (e) { setBusy(false); ui.error(e); }
  };
  const start = async (fresh) => {
    const ok = await ui.confirm({ title: fresh ? 'Start the practice again?' : 'Switch to Training mode?',
      message: fresh ? 'All practice entries are removed and fresh sample figures are loaded. Real data is not touched.' : 'The app switches to a separate practice copy with sample shops, staff and figures. Your real data stays safe and nothing is sent to the cloud. You will be logged out; log in with a practice PIN.',
      confirmText: fresh ? 'Start again' : 'Switch to training' });
    if (!ok) return;
    if (!isTraining()) await snapshotNow('training-on'); // safety copy of the real data first
    go(() => enterTraining({ fresh }), 'Training mode is on');
  };
  const stop = async () => {
    const ok = await ui.confirm({ title: 'Leave Training mode?', message: 'The app goes back to the real data. The practice entries stay in the practice copy for next time.', confirmText: 'Back to real data' });
    if (ok) go(() => { leaveTraining(); snapshotNow('training-off').catch(() => {}); }, 'Back to real data');
  };
  const problems = on ? trainingProblems() : [];
  return (
    <Screen title="Training mode" subtitle={on ? 'ON – practice figures' : 'Off – real data'}>
      <Explain>Training mode is a separate practice copy of the app on this device. It has sample shops, staff, products, suppliers, invoices, till counts, a pay run, a roster, leave and a job opening, so new staff can try every module without any risk. Nothing done in training reaches the real books, the cloud, Viber or email. An orange bar shows at the top while it is on.</Explain>
      <Card>
        <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }}>Practice logins</Text>
        {TRAINING_LOGINS.map(([name, pin]) => <Text key={pin} style={{ fontSize: 16, color: C.text, marginTop: 4 }}>{name}: PIN {pin}</Text>)}
        <Hint>The usual sample logins (Admin 1111 etc.) also work in the practice copy.</Hint>
      </Card>
      {busy ? <Banner tone="info" message="Please wait – setting up…" /> : null}
      {problems.length ? <Banner tone="warn" message={`Some sample figures could not be made: ${problems.join('; ')}`} /> : null}
      <View style={{ gap: 10 }}>
        {on ? (
          <>
            <Btn testID="tr-off" title="Leave training – back to real data" icon="✅" variant="success" disabled={busy} onPress={stop} />
            <Btn testID="tr-fresh" title="Start the practice again (fresh sample figures)" icon="🔄" variant="secondary" disabled={busy} onPress={() => start(true)} />
          </>
        ) : (
          <Btn testID="tr-on" title="Switch to Training mode" icon="🎓" variant="warn" disabled={busy} onPress={() => start(false)} />
        )}
      </View>
    </Screen>
  );
}
