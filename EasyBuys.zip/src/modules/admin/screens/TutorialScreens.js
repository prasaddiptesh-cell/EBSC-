// Tutorials: the app tour and "Show me how" for each job, a short check at the end, and (owner) who has done what.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { isTraining } from '../../../services/trainingFlag.js';
import { TOUR, tutorialsFor, getTutorial, progressOf, progressAll, recordTutorial, scoreQuiz, TUTORIALS } from '../../../services/tutorials.js';
import { moduleOn } from '../service.js';
import { startTutorial } from '../../../ui/TutorialBar.js';

const safeOn = (m) => { try { return moduleOn(m); } catch (e) { return true; } };

export function TutorialsScreen() {
  const { user, nav, can } = useApp();
  const list = tutorialsFor(user, safeOn);
  const mine = user && user.uid ? progressOf(user.uid) : {};
  const go = (id) => { nav.home(); setTimeout(() => startTutorial(id), 300); };
  return (
    <Screen title="Tutorials" subtitle="Learn each job step by step">
      {!isTraining() ? (
        <Banner tone="info" title="Practise in Training mode" message="Training mode is a practice copy – nothing real changes. Admin › Training mode (ask the owner)." />
      ) : <Banner tone="success" message="Training mode is on – practise as much as you like." />}
      <Card>
        <H>{TOUR.title}</H>
        <Text style={{ color: C.sub }}>Where things are on Home.{mine.tour ? ' Seen ✓' : ''}</Text>
        <Btn testID="tut-start-tour" title="Show me around" icon="🧭" size="md" variant="info" onPress={() => go('tour')} />
      </Card>
      {list.map((t) => {
        const p = mine[t.id];
        return (
          <Card key={t.id} tone={p && p.passed ? 'success' : undefined}>
            <H>{t.title}</H>
            <Text style={{ color: C.sub }}>{t.steps.length} steps{t.quiz ? ` · ${t.quiz.length} question${t.quiz.length === 1 ? '' : 's'}` : ''}{p ? ` · done ${String(p.at).slice(0, 10)} (${p.score} of ${p.of} right)` : ''}</Text>
            <Btn testID={`tut-start-${t.id}`} title={p ? 'Show me again' : 'Show me how'} icon="🎓" size="md" variant={p ? 'secondary' : 'success'} onPress={() => go(t.id)} />
          </Card>
        );
      })}
      {can('settings') ? <Btn testID="tut-progress" title="Who has done which tutorial" icon="📋" variant="secondary" onPress={() => nav.push('TrainingProgress', {})} /> : null}
    </Screen>
  );
}

export function TutorialQuizScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const t = getTutorial(params.id);
  const [ans, setAns] = useState({});
  const [result, setResult] = useState(null);
  if (!t || !t.quiz) return <Screen title="Quick check"><Banner tone="info" message="Nothing to check here." /></Screen>;
  const submit = () => {
    if (Object.keys(ans).length < t.quiz.length) { ui.alert({ title: 'Answer every question', message: 'Tap one answer for each question.', tone: 'warn' }); return; }
    recordTutorial(user, t.id, t.quiz.map((q, i) => ans[i]));
    setResult(scoreQuiz(t.id, t.quiz.map((q, i) => ans[i])));
  };
  return (
    <Screen title="Quick check" subtitle={t.title}>
      {result ? <Banner testID="quiz-result" tone={result.passed ? 'success' : 'warn'} title={result.passed ? 'Well done!' : `${result.right} of ${result.of} right`} message={result.passed ? 'All correct.' : 'Have another look at the right answers below, or do the tutorial again.'} /> : null}
      {t.quiz.map((q, i) => (
        <Card key={i}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{i + 1}. {q[0]}</Text>
          {q[1].map((c, j) => {
            const on = ans[i] === j;
            const right = result && j === q[2];
            return (
              <Pressable key={j} testID={`quiz-${i}-${j}`} disabled={!!result} onPress={() => setAns({ ...ans, [i]: j })}
                style={{ flexDirection: 'row', gap: 10, alignItems: 'center', paddingVertical: 8 }}>
                <Text style={{ fontSize: 22, color: right ? C.success : on ? C.info : C.sub }}>{right ? '✅' : on ? '🔘' : '⚪'}</Text>
                <Text style={{ fontSize: 17, color: C.text, flex: 1 }}>{c}</Text>
              </Pressable>
            );
          })}
        </Card>
      ))}
      {result ? <Btn testID="quiz-done" title="Back to Tutorials" icon="🎓" onPress={() => nav.replace('Tutorials', {})} /> : <Btn testID="quiz-submit" title="Check my answers" icon="✅" variant="success" onPress={submit} />}
    </Screen>
  );
}

export function TrainingProgressScreen() {
  const all = progressAll();
  let people = [];
  try { people = db().all("SELECT uid, name, role FROM users WHERE active = 1 AND sync_status <> 'seed' ORDER BY name"); } catch (e) { people = []; }
  return (
    <Screen title="Training progress" subtitle="Who has done which tutorial">
      <Hint>Each person's tutorials and the quick check. Updated on every device.</Hint>
      {people.map((u) => {
        const p = all[u.uid] || {};
        const mine = TUTORIALS.filter((t) => t.roles.includes(u.role) || ['owner', 'admin'].includes(u.role));
        const done = mine.filter((t) => p[t.id]);
        return (
          <Card key={u.uid}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{u.name} <Text style={{ fontSize: 14, color: C.sub }}>· {done.length} of {mine.length} done{p.tour ? ' · tour seen' : ''}</Text></Text>
            {mine.map((t) => <Text key={t.id} style={{ color: p[t.id] ? (p[t.id].passed ? C.success : C.warn) : C.sub }}>{p[t.id] ? (p[t.id].passed ? '✅' : '🟠') : '⬜'} {t.title}{p[t.id] ? ` – ${p[t.id].score}/${p[t.id].of}, ${String(p[t.id].at).slice(0, 10)}` : ''}</Text>)}
          </Card>
        );
      })}
    </Screen>
  );
}
