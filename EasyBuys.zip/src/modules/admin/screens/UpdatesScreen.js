// App updates: where they come from, check now, download and install.
import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Row, Section, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { APP_VERSION } from '../../../services/core.js';
import { VERSION_CODE } from '../../../services/about.js';
import { updateRepo, saveUpdateRepo, checkForUpdate, lastUpdateInfo, releaseIsNewer, readyUpdate, fetchUpdate, installUpdate, autoDownloadOn, setAutoDownload, downloadProgress } from '../../../platform/updates.js';

export function UpdatesScreen() {
  const { user, refresh } = useApp();
  const ui = useUI();
  const [repo, setRepo] = useState(updateRepo());
  const [busy, setBusy] = useState(false);
  const info = lastUpdateInfo();
  const newer = releaseIsNewer(info); // by Android's build number (the name restarted at 1.0.0)
  const ready = readyUpdate();
  const [auto, setAuto] = useState(autoDownloadOn());
  // how far the download is (by itself or after Check) – shown while it runs
  const [prog, setProg] = useState(downloadProgress());
  useEffect(() => { const t = setInterval(() => { const p = downloadProgress(); setProg(p ? { ...p } : null); if (!p && readyUpdate() && !ready) refresh(); }, 1000); return () => clearInterval(t); }, [ready]);
  const mb = (n) => Math.round((Number(n) || 0) / 1048576);
  const progText = prog ? `Downloading… ${mb(prog.written)}${prog.total ? ` of ${mb(prog.total)}` : ''} MB` : '';
  const check = async () => {
    setBusy(true);
    try {
      const r = await checkForUpdate({ force: true });
      refresh();
      if (r.newer) { ui.toast('A newer app is out – downloading…'); await fetchUpdate(r.info); ui.toast('Update ready – tap Install'); } else ui.toast('This app is up to date');
    } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); }
  };
  const install = async () => { try { await installUpdate(); } catch (e) { ui.error(e); } };
  return (
    <Screen title="App updates" subtitle={`This device has v${APP_VERSION} (build ${VERSION_CODE})`}>
      <Explain>The app looks for a newer version by itself every few hours and downloads it in the background. Then "App update ready – tap to install" shows on Home (and as a notification). Tap Install, then Update on Android's screen – everything you have entered stays (a safety copy is made first). Android always asks you to confirm an install for apps not from Google Play. The first time, Android asks to allow installing from Easy Buys: tap Settings, turn on "Allow from this source", then go back.</Explain>
      {ready ? (
        <Card>
          <Banner tone="success" title="Update ready to install" message={`Build ${ready.build || ready.version} has downloaded${ready.size ? ` (${Math.round(ready.size / 1048576)} MB)` : ''}.`} />
          <Btn testID="up-install" title="Install the update" icon="⬆️" variant="success" onPress={install} />
        </Card>
      ) : null}
      <Section title="Where updates come from">
        <Field testID="up-repo" label="GitHub repository (owner/name)" value={repo} onChangeText={setRepo} placeholder="e.g. easybuys/easybuys-app" />
        <Hint>It is in the GitHub address: github.com/<Text style={{ fontWeight: '800' }}>owner/name</Text>. The repository must be public for the app to see the releases.</Hint>
        <Btn testID="up-save" title="Save" size="md" variant="secondary" onPress={() => { try { saveUpdateRepo(user, repo); ui.toast('Saved'); refresh(); } catch (e) { ui.error(e); } }} />
      </Section>
      <Btn testID="up-check" title={prog ? progText : busy ? 'Checking…' : 'Check for updates now'} icon="🔄" variant="info" disabled={busy || !!prog || !updateRepo()} onPress={check} />
      {prog && prog.total ? (
        <View testID="up-progress" style={{ height: 10, borderRadius: 5, backgroundColor: C.border, overflow: 'hidden' }}>
          <View style={{ height: 10, width: `${Math.min(100, Math.round((prog.written / prog.total) * 100))}%`, backgroundColor: C.success }} />
        </View>
      ) : null}
      {prog ? <Hint>Keep the app open until it says "Update ready". If the internet drops, the download carries on where it stopped.</Hint> : null}
      {info ? (
        <Card>
          <Row label="Newest on GitHub" value={info.version ? `v${info.version}${info.build ? ` (build ${info.build})` : ''}` : '—'} />
          <Row label="This device" value={`v${APP_VERSION} (build ${VERSION_CODE})`} />
          <Row label="Checked" value={String(info.checkedAt || '').slice(0, 16)} />
          {newer ? (ready ? null : <Banner tone="info" title="A newer app is out" message={prog ? progText : auto ? 'It downloads by itself (on start, every hour and when the app is opened again) – or tap Check for updates now.' : 'Tap Check for updates now to download it.'} />) : <Text style={{ color: C.success, marginTop: 6 }}>✓ Up to date</Text>}
        </Card>
      ) : null}
      <Section title="This device">
        <Chips value={auto ? 'on' : 'off'} onChange={(v) => { setAutoDownload(v === 'on'); setAuto(v === 'on'); }} testIDPrefix="up-auto" options={[{ value: 'on', label: 'Download updates by itself' }, { value: 'off', label: 'Only when I tap Check' }]} />
        <Hint>Each update is about {info && info.size ? Math.round(info.size / 1048576) : 60} MB. On a phone with expensive mobile data, choose "Only when I tap Check".</Hint>
      </Section>
      <Hint>Update one tablet first and check it (Admin › Problem log › Check every screen) before updating the rest.</Hint>
    </Screen>
  );
}
