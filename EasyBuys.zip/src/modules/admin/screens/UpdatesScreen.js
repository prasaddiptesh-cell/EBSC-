// App updates: where they come from, check now, download and install.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Row, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain } from '../../../ui/kit.js';
import { APP_VERSION } from '../../../services/core.js';
import { updateRepo, saveUpdateRepo, checkForUpdate, lastUpdateInfo, isNewer, downloadUpdate, releaseIsNewer } from '../../../platform/updates.js';
import { snapshotNow } from '../../../services/snapshots.js';

export function UpdatesScreen() {
  const { user, refresh } = useApp();
  const ui = useUI();
  const [repo, setRepo] = useState(updateRepo());
  const [busy, setBusy] = useState(false);
  const info = lastUpdateInfo();
  const newer = releaseIsNewer(info); // by Android's build number (the name restarted at 1.0.0)
  const check = async () => {
    setBusy(true);
    try { const r = await checkForUpdate({ force: true }); ui.toast(r.off ? 'Enter the repository first' : r.newer ? `Version ${r.info.version} is ready` : 'This app is up to date'); } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); }
  };
  return (
    <Screen title="App updates" subtitle={`This device has v${APP_VERSION}`}>
      <Explain>Every time a new version is built on GitHub, the app sees it (it checks once a day) and shows "New version ready" here and on the Home screen. Tap Download, then open the file: Android asks to install it over the old one – all data stays. The first time, Android may ask you to allow installing from Chrome / Files: say Allow.</Explain>
      <Section title="Where updates come from">
        <Field testID="up-repo" label="GitHub repository (owner/name)" value={repo} onChangeText={setRepo} placeholder="e.g. easybuys/easybuys-app" />
        <Hint>It is in the GitHub address: github.com/<Text style={{ fontWeight: '800' }}>owner/name</Text>. The repository must be public for the app to see the releases.</Hint>
        <Btn testID="up-save" title="Save" size="md" variant="secondary" onPress={() => { try { saveUpdateRepo(user, repo); ui.toast('Saved'); refresh(); } catch (e) { ui.error(e); } }} />
      </Section>
      <Btn testID="up-check" title={busy ? 'Checking…' : 'Check for updates now'} icon="🔄" variant="info" disabled={busy || !updateRepo()} onPress={check} />
      {info ? (
        <Card>
          <Row label="Newest on GitHub" value={info.version ? `v${info.version}${info.build ? ` (build ${info.build})` : ''}` : '—'} />
          <Row label="This device" value={`v${APP_VERSION}`} />
          <Row label="Checked" value={String(info.checkedAt || '').slice(0, 16)} />
          {newer ? <Banner tone="success" title={`Version ${info.version} is ready`} message="Tap Download. When it has downloaded, open it and tap Install (or Update)." /> : <Text style={{ color: C.success, marginTop: 6 }}>✓ Up to date</Text>}
          {newer ? <Btn testID="up-download" title={`Download v${info.version}${info.size ? ` (${Math.round(info.size / 1048576)} MB)` : ''}`} icon="⬇️" variant="success" onPress={() => snapshotNow('update').catch(() => null).then(() => downloadUpdate(info)).catch((e) => ui.error(e))} /> : null}
        </Card>
      ) : null}
      <Hint>Update one tablet first and check it (Admin › Problem log › Check every screen) before updating the rest.</Hint>
    </Screen>
  );
}
