// Watchdog: today's findings (what is missing, system health, possible tampering for the owner) with why it matters,
// what to do, a button that goes there, and "Fixed" / "This is fine". Settings: on/off, strength, each check.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { actsAsOwner } from '../../../services/access.js';
import { syncNow } from '../../../platform/cloud.js';
import { runWatchdog, ackFinding, watchdogSettings, saveWatchdogSettings, CHECKS, STRENGTHS, GROUP_LABEL } from '../../../services/watchdog.js';

const TONE = { urgent: 'danger', warning: 'warn', info: undefined };

export function WatchdogScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [, setTick] = useState(0);
  const [busy, setBusy] = useState(false);
  const s = watchdogSettings();
  let list = [];
  try { list = runWatchdog(user); } catch (e) { list = []; }
  const ack = (id, kind) => { try { ackFinding(user, id, kind); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  const sync = async () => { setBusy(true); try { await syncNow({ force: true }); ui.toast('Synced'); } catch (e) { ui.error(e); } setBusy(false); setTick((n) => n + 1); };
  const groups = ['tamper', 'health', 'complete'].map((g) => [g, list.filter((x) => x.group === g)]).filter(([, l]) => l.length);
  return (
    <Screen title="Watchdog" subtitle={s.on ? `On · ${STRENGTHS.find((x) => x.value === s.strength).label}` : 'Off – only system health and tampering are watched (owner)'}>
      {!s.on ? <Banner tone="info" message="The watchdog is off. Turn it on in Watchdog settings." /> : null}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="wd-sync" title={busy ? 'Syncing…' : 'Sync now'} icon="⟳" size="md" variant="info" disabled={busy} onPress={sync} />
        {actsAsOwner(user) || user.role === 'admin' ? <Btn testID="wd-settings" title="Watchdog settings" icon="⚙️" size="md" variant="secondary" onPress={() => nav.push('WatchdogSettings', {})} /> : null}
      </View>
      {!list.length ? <Banner tone="success" title="All clear" message="Nothing to look at right now." /> : null}
      {groups.map(([g, l]) => (
        <Section key={g} title={`${GROUP_LABEL[g]} (${l.length})`}>
          {l.map((x) => (
            <Card key={x.id} tone={TONE[x.level]}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{x.level === 'urgent' ? '🚨 ' : x.level === 'warning' ? '⚠️ ' : 'ℹ️ '}{x.text}</Text>
              <Text style={{ color: C.text, marginTop: 4 }}>Why: {x.why}</Text>
              <Text style={{ color: C.text }}>What to do: {x.todo}</Text>
              <Text style={{ color: C.sub, fontSize: 14 }}>Who: {x.who}</Text>
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
                {x.nav ? <Btn testID={`wd-go-${x.check}`} title="Go there" size="sm" variant="info" onPress={() => nav.push(x.nav.screen, x.nav.params || {})} /> : null}
                <Btn testID={`wd-fixed-${x.check}`} title="Fixed" size="sm" variant="success" onPress={() => ack(x.id, 'fixed')} />
                <Btn testID={`wd-fine-${x.check}`} title="This is fine" size="sm" variant="secondary" onPress={() => ack(x.id, 'fine')} />
              </View>
            </Card>
          ))}
        </Section>
      ))}
    </Screen>
  );
}

export function WatchdogSettingsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [s, setS] = useState(() => watchdogSettings());
  const save = () => { try { setS(saveWatchdogSettings(user, s)); ui.toast('Saved – every device uses it'); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Watchdog settings" footer={<Btn testID="wds-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 10 }}>
        <H>Watchdog</H>
        <Chips value={s.on ? 'on' : 'off'} onChange={(v) => setS({ ...s, on: v === 'on' })} testIDPrefix="wds-on" options={[{ value: 'on', label: 'On' }, { value: 'off', label: 'Off' }]} />
        <Text style={{ fontWeight: '700', color: C.text }}>How strict</Text>
        <Chips value={s.strength} onChange={(v) => setS({ ...s, strength: v })} testIDPrefix="wds-strength" options={STRENGTHS.filter((x) => x.value !== 'off')} />
        <Hint>Light: only clear problems. Strict: more things, sooner. System health and tampering keep being watched for the owner even when the watchdog is off.</Hint>
      </Card>
      {['complete', 'health', 'tamper'].map((g) => (
        <Section key={g} title={GROUP_LABEL[g]}>
          {CHECKS.filter((c) => c.group === g).map((c) => (
            <View key={c.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 2 }}>
              <Text style={{ flex: 1, color: C.text, fontSize: 16 }}>{c.label}</Text>
              <Chips value={s.checks[c.id] ? 'on' : 'off'} onChange={(v) => setS({ ...s, checks: { ...s.checks, [c.id]: v === 'on' } })} testIDPrefix={`wds-${c.id}`} options={[{ value: 'on', label: 'On' }, { value: 'off', label: 'Off' }]} />
            </View>
          ))}
        </Section>
      ))}
    </Screen>
  );
}
