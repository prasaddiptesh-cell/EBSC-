// 1.0.0 build 47: Admin › Website logins (owner only). Who may use the Easy Buys website on a computer: the website
// switched on, and each person's login email. Logging in: a code emailed to that address, then the person's own PIN
// (both checked by the cloud). The owner is emailed about every browser that logs in; a login lasts 12 hours.
// Browsers that logged in are listed in Admin › Devices (remove one there to throw it out).
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Explain } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { emailLoginsOn, setEmailLogins, setUserEmail } from '../service.js';

export const WEBSITE_URL = 'https://easybuys-web.easybuys.workers.dev';
const ROLE = { owner: 'Owner', admin: 'Admin', manager: 'Manager', supervisor: 'Supervisor' };

export function WebLoginsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [open, setOpen] = useState(null);
  const [f, setF] = useState({ email: '' });
  if (!user || user.role !== 'owner') return <Screen title="Website logins"><Banner tone="warn" message="Only the owner can choose who may use the website." /></Screen>;
  const on = emailLoginsOn();
  const people = db().all("SELECT uid, name, role, email FROM users WHERE active = 1 AND COALESCE(sync_status,'') <> 'seed' ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'manager' THEN 2 ELSE 3 END, name");
  const openP = (p) => { setOpen(open === p.uid ? null : p.uid); setF({ email: p.email || '' }); };
  const save = (p) => {
    try { setUserEmail(user, p.uid, f.email); ui.toast(f.email ? `${p.name} can log in to the website with ${f.email.trim().toLowerCase()} (goes to the cloud with the next sync)` : `${p.name}'s login email removed`); setOpen(null); bump((n) => n + 1); } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Website logins" subtitle="Who may use Easy Buys on a computer">
      <Explain>{'The website logs in with email + password. Set a person\'s login email, then press "Send website password": a temporary password is emailed to them, and at their first login the website makes them choose their own (10+ characters, letters and numbers). Forgot it? They press "Forgot password" on the login page. You get an email every time a browser logs in. A login lasts 12 hours. Each person sees only what their role allows.'}</Explain>
      <Card>
        <Text style={{ fontSize: 18, fontWeight: '800', color: on ? C.success : C.text }}>{on ? '✅ The website is on' : 'The website is off – nobody can log in'}</Text>
        <Btn testID="wl-switch" title={on ? 'Switch the website off' : 'Switch the website on'} variant={on ? 'ghost' : 'primary'} onPress={() => { try { setEmailLogins(user, !on); ui.toast(on ? 'Website off' : 'Website on – give each person a login email below'); bump((n) => n + 1); } catch (e) { ui.error(e); } }} />
        <Btn testID="wl-open" title="Open the website" icon="🌐" variant="secondary" size="sm" onPress={() => Linking.openURL(WEBSITE_URL).catch(() => {})} />
        <Text style={{ fontSize: 14, color: C.muted }}>{WEBSITE_URL}</Text>
      </Card>
      <Section title="People">
        {people.map((p) => (
          <Card key={p.uid}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${p.name} · ${ROLE[p.role] || 'Staff'}`}</Text>
            <Text style={{ fontSize: 14, color: C.muted }}>{p.email ? p.email : 'No login email yet'}</Text>
            {p.email ? <Btn testID={`wl-pw-${p.uid}`} title="Send website password" icon="✉️" size="sm" variant="primary" onPress={async () => {
              try {
                try { await require('../../../platform/cloud.js').syncNow({ force: true }); } catch (e) { /* the email may already be in the cloud */ }
                await require('../../devices/service.js').webPwSend(p.email);
                ui.toast(`A temporary website password was emailed to ${p.email}`);
              } catch (e) { ui.error(e); }
            }} /> : null}
            <Btn testID={`wl-set-${p.uid}`} title={open === p.uid ? 'Close' : (p.email ? 'Change login email' : 'Set login email')} size="sm" variant="secondary" onPress={() => openP(p)} />
            {open === p.uid ? (
              <View>
                <Field testID="wl-email" label="Login email (the website password is sent here)" value={f.email} onChangeText={(v) => setF({ email: v })} keyboardType="email-address" />
                <Btn testID="wl-save" title="Save" variant="success" onPress={() => save(p)} />
                <Text style={{ fontSize: 13, color: C.muted }}>Only this person should be able to read this email. Leave it empty and save to stop their website login.</Text>
              </View>
            ) : null}
          </Card>
        ))}
      </Section>
    </Screen>
  );
}
