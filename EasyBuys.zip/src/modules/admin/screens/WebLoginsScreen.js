// 1.0.0 build 47: Admin › Website logins (owner only). Who may use the Easy Buys website on a computer: the website
// switched on, and for each person their login email and a website password (at least 10 characters). Logging in
// also needs a code emailed to that address each time, the owner is emailed about every browser that logs in, and a
// login lasts 12 hours. Browsers that logged in are listed in Admin › Devices (remove one there to throw it out).
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Explain } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { emailLoginsOn, setEmailLogins, setLoginEmail } from '../service.js';
import { cloudCall } from '../../../platform/cloud.js';
import { pinProof } from '../../../services/pins.js';

export const WEBSITE_URL = 'https://easybuys-web.easybuys.workers.dev';
const ROLE = { owner: 'Owner', admin: 'Admin', manager: 'Manager', supervisor: 'Supervisor' };

export function WebLoginsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [open, setOpen] = useState(null);
  const [f, setF] = useState({ email: '', password: '', again: '', pin: '' });
  const [busy, setBusy] = useState(false);
  if (!user || user.role !== 'owner') return <Screen title="Website logins"><Banner tone="warn" message="Only the owner can choose who may use the website." /></Screen>;
  const on = emailLoginsOn();
  const people = db().all("SELECT uid, name, role, email FROM users WHERE active = 1 AND COALESCE(sync_status,'') <> 'seed' ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'manager' THEN 2 ELSE 3 END, name");
  const openP = (p) => { setOpen(open === p.uid ? null : p.uid); setF({ email: p.email || '', password: '', again: '', pin: '' }); };
  const save = async (p) => {
    if (f.password.length < 10) { ui.error(new Error('The website password must be at least 10 characters.')); return; }
    if (f.password !== f.again) { ui.error(new Error('The two passwords are not the same.')); return; }
    const proof = pinProof(f.pin, user.uid);
    if (!proof) { ui.error(new Error('Type your own PIN to confirm.')); return; }
    setBusy(true);
    try {
      if ((f.email || '').trim().toLowerCase() !== String(p.email || '').toLowerCase()) setLoginEmail(user, p.uid, f.email);
      await cloudCall({ kind: 'email_password_set', uid: p.uid, password: f.password, ownerProof: proof }, 60000);
      ui.toast(`${p.name} can log in to the website (the email change goes with the next sync)`);
      setOpen(null); bump((n) => n + 1);
    } catch (e) { ui.error(e); } finally { setBusy(false); }
  };
  return (
    <Screen title="Website logins" subtitle="Who may use Easy Buys on a computer">
      <Explain>{'The website is the same app in a browser. To log in a person types their email and website password, then a 6-digit code that is emailed to them (it works for 5 minutes). You get an email every time a browser logs in. A login lasts 12 hours; then everything is cleared from that computer. Each person sees only what their role allows.'}</Explain>
      <Card>
        <Text style={{ fontSize: 18, fontWeight: '800', color: on ? C.success : C.text }}>{on ? '✅ The website is on' : 'The website is off – nobody can log in'}</Text>
        <Btn testID="wl-switch" title={on ? 'Switch the website off' : 'Switch the website on'} variant={on ? 'ghost' : 'primary'} onPress={() => { try { setEmailLogins(user, !on); ui.toast(on ? 'Website off' : 'Website on – set each person\'s password below'); bump((n) => n + 1); } catch (e) { ui.error(e); } }} />
        <Btn testID="wl-open" title="Open the website" icon="🌐" variant="secondary" size="sm" onPress={() => Linking.openURL(WEBSITE_URL).catch(() => {})} />
        <Text style={{ fontSize: 14, color: C.muted }}>{WEBSITE_URL}</Text>
      </Card>
      <Section title="People">
        {people.map((p) => (
          <Card key={p.uid}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${p.name} · ${ROLE[p.role] || 'Staff'}`}</Text>
            <Text style={{ fontSize: 14, color: C.muted }}>{p.email ? p.email : 'No login email yet'}</Text>
            <Btn testID={`wl-set-${p.uid}`} title={open === p.uid ? 'Close' : 'Set email & website password'} size="sm" variant="secondary" onPress={() => openP(p)} />
            {open === p.uid ? (
              <View>
                <Field testID="wl-email" label="Login email" value={f.email} onChangeText={(v) => setF((o) => ({ ...o, email: v }))} keyboardType="email-address" />
                <Field testID="wl-pw" label="Website password (at least 10 characters)" value={f.password} secure onChangeText={(v) => setF((o) => ({ ...o, password: v }))} />
                <Field testID="wl-pw2" label="The same password again" value={f.again} secure onChangeText={(v) => setF((o) => ({ ...o, again: v }))} />
                <Field testID="wl-pin" label="Your own PIN (to confirm it is you)" value={f.pin} secure keyboardType="number-pad" lettersToo={false} onChangeText={(v) => setF((o) => ({ ...o, pin: v }))} />
                <Btn testID="wl-save" title={busy ? 'Saving…' : 'Save'} variant="success" disabled={busy || !f.email} onPress={() => save(p)} />
                <Text style={{ fontSize: 13, color: C.muted }}>Give the password to the person yourself (not by email). They cannot log in without also getting the emailed code.</Text>
              </View>
            ) : null}
          </Card>
        ))}
      </Section>
    </Screen>
  );
}
