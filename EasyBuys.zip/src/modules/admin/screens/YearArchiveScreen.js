// v3.9 Year end: is the year complete? Close the books and keep the archive copy (Google Drive + this device).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Row, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import * as YA from '../../../services/yearArchive.js';

export function YearArchiveScreen() {
  const { user } = useApp();
  const ui = useUI();
  const last = Number(dateStr().slice(0, 4)) - 1;
  const [year, setYear] = useState(last);
  const [busy, setBusy] = useState(false);
  const [tick, setTick] = useState(0);
  const checks = YA.yearChecks(year);
  const done = YA.archives();
  const bad = checks.filter((c) => !c.ok && !c.warn);
  const go = async (force) => {
    const ok = force || await ui.confirm({ title: `Close and archive ${year}?`, message: `The books are closed to 31 December ${year} (nothing in ${year} can be changed after, unless the owner reopens it), the profit is kept in the business, and a complete copy is kept in Google Drive and on this device. Everything stays in the app.`, confirmText: 'Close & archive' });
    if (!ok) return;
    setBusy(true);
    try { const r = await YA.closeAndArchive(user, year, { force }); ui.alert({ title: `${year} closed and archived`, message: `Profit kept in the business: ${r.profit}. The copy goes to Google Drive with the next sync (${r.fileName}).` }); } catch (e) { ui.error(e); }
    setBusy(false); setTick(tick + 1);
  };
  return (
    <Screen title="Year end: close & archive" subtitle="Owner – once a year, after the accountant is happy">
      <Explain>When the year is complete – every VAT and FNPF month lodged and paid, the books balanced, stock counted at the year end – close it. The books are locked to 31 December, the profit is kept in the business, and a complete copy of the business as it was is kept in Google Drive (Backups › Manual, kept for good – FRCS wants 7 years) and on this tablet. Every record stays in the app, so old invoices, payslips and reports can still be opened.</Explain>
      <Chips value={year} onChange={setYear} testIDPrefix="ya-year" options={[last - 1, last].map((y) => ({ value: y, label: String(y) }))} />
      {done[year] ? <Banner testID="ya-done" tone="success" title={`${year} is archived`} message={`${done[year].at} by ${done[year].by} · ${done[year].fileName} · ${done[year].status}`} /> : null}
      <Section title={`Is ${year} complete?`}>
        {checks.map((c) => <Banner key={c.key} testID={`ya-check-${c.key}`} tone={c.ok ? 'success' : c.warn ? 'warn' : 'danger'} message={`${c.ok ? '✓' : c.warn ? '!' : '✗'} ${c.text}`} />)}
      </Section>
      {!done[year] ? (
        <View style={{ gap: 8 }}>
          {!bad.length ? <Btn testID="ya-go" title={`Close & archive ${year}`} icon="🗄️" variant="success" disabled={busy} onPress={() => go(false)} /> : null}
          {bad.length ? <Hint>Fix the red items first. If the accountant has done them outside the app, the owner can go ahead anyway:</Hint> : null}
          {bad.length ? <ReasonButton testID="ya-force" title={`Close & archive ${year} anyway`} prompt="Why (e.g. the accountant lodged them)?" confirm="Close & archive" variant="warn" onDo={() => go(true)} /> : null}
        </View>
      ) : null}
    </Screen>
  );
}
