// Admin: shops, modules on/off, change history.
import { requireSetup } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, getShared, setShared } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

// 1.0.0 build 1: an email on a person (for email logins in the online version later). Owner / admin only; checked
// and unique; a locked item (the owner's PIN again – services/locked.js). '' removes it.
export function setUserEmail(user, uid, email) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can set a login email.');
  const e = String(email || '').trim().toLowerCase();
  if (e && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new AppError('That does not look like an email address.');
  const p = db().get('SELECT * FROM users WHERE uid = ?', [uid]);
  if (!p) throw new AppError('Person not found.');
  if (e && db().get('SELECT 1 AS x FROM users WHERE lower(email) = ? AND uid <> ?', [e, uid])) throw new AppError('That email is already used for another login.');
  db().run("UPDATE users SET email = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [e || null, stamp(), deviceId(), uid]);
  audit({ user, action: e ? 'Set a login email' : 'Removed a login email', table: 'users', recordUid: uid, before: { email: p.email || null }, after: { email: e || null } });
  return e;
  });
}
export function emailLoginsOn() { const v = getShared('email_logins', false); return v === true || !!(v && v.on); }
export function setEmailLogins(user, on) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || user.role !== 'owner') throw new AppError('Only the owner can switch email logins on or off.');
  setShared('email_logins', !!on);
  audit({ user, action: `Email logins ${on ? 'on' : 'off'}`, table: 'shared_settings', recordUid: 'email_logins' });
  return !!on;
  });
}

export function listShops({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM shops ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort, code`);
}
export function saveShop(user, { code, name, active = true }) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9_]/g, '');
  const n = String(name || '').trim();
  if (!c) throw new AppError('Enter a short shop code, e.g. S4.');
  if (!n) throw new AppError('Enter the shop name.');
  const before = db().get('SELECT * FROM shops WHERE code = ?', [c]);
  db().run(
    `INSERT INTO shops (code, name, active, sort, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, COALESCE((SELECT MAX(sort) + 1 FROM shops), 0), ?, ?, 'pending')
     ON CONFLICT(code) DO UPDATE SET name = excluded.name, active = excluded.active, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [c, n, active ? 1 : 0, stamp(), deviceId()]
  );
  audit({ user, action: before ? 'Changed shop' : 'Added shop', table: 'shops', recordUid: c, before, after: { name: n, active } });
  });
}

// Modules can be switched off by the admin (they disappear from the home screen).
export const SWITCHABLE = ['timeclock', 'timesheets', 'leave', 'bakery', 'payables', 'till', 'bank', 'payroll', 'inventory', 'accounting', 'recruitment', 'licences', 'loans', 'drawings', 'vehicles'];
export function moduleOn(id) {
  const m = getShared('modules_on', {}) || {};
  return m[id] !== false;
}
export function setModuleOn(user, id, on) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'settings');
  if (!SWITCHABLE.includes(id)) throw new AppError('This part cannot be switched off.');
  const m = { ...(getShared('modules_on', {}) || {}), [id]: !!on };
  setShared('modules_on', m);
  audit({ user, action: `${on ? 'Turned on' : 'Turned off'} ${id}`, table: 'shared_settings', recordUid: 'modules_on', after: m });
  });
}

export function listAudit({ q, limit = 300 } = {}) {
  const like = q ? `%${q}%` : null;
  return db().all(
    `SELECT * FROM audit_log ${like ? 'WHERE action LIKE ? OR user_name LIKE ? OR reason LIKE ?' : ''} ORDER BY at DESC LIMIT ?`,
    like ? [like, like, like, limit] : [limit]
  );
}
