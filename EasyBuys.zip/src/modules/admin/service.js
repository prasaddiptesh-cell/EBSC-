// Admin: shops, modules on/off, change history.
import { requireSetup } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, getShared, setShared } from '../../services/core.js';

export function listShops({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM shops ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort, code`);
}
export function saveShop(user, { code, name, active = true }) {
  const c = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9_]/g, '');
  const n = String(name || '').trim();
  if (!c) throw new AppError('Enter a short shop code, e.g. S4.');
  if (!n) throw new AppError('Enter the shop name.');
  const before = db().get('SELECT * FROM shops WHERE code = ?', [c]);
  db().run(
    `INSERT INTO shops (code, name, active, sort, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, COALESCE((SELECT MAX(sort) + 1 FROM shops), 0), ?, ?, 'pending')
     ON CONFLICT(code) DO UPDATE SET name = excluded.name, active = excluded.active, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [c, n, active ? 1 : 0, stamp(), deviceId()]
  );
  audit({ user, action: before ? 'Changed shop' : 'Added shop', table: 'shops', recordUid: c, before, after: { name: n, active } });
}

// Modules can be switched off by the admin (they disappear from the home screen).
export const SWITCHABLE = ['timeclock', 'timesheets', 'leave', 'bakery', 'payables', 'till', 'bank', 'payroll', 'inventory', 'accounting', 'recruitment', 'licences', 'loans', 'drawings', 'myday', 'vehicles'];
export function moduleOn(id) {
  const m = getShared('modules_on', {}) || {};
  return m[id] !== false;
}
export function setModuleOn(user, id, on) {
  requireSetup(user, 'settings');
  if (!SWITCHABLE.includes(id)) throw new AppError('This part cannot be switched off.');
  const m = { ...(getShared('modules_on', {}) || {}), [id]: !!on };
  setShared('modules_on', m);
  audit({ user, action: `${on ? 'Turned on' : 'Turned off'} ${id}`, table: 'shared_settings', recordUid: 'modules_on', after: m });
}

export function listAudit({ q, limit = 300 } = {}) {
  const like = q ? `%${q}%` : null;
  return db().all(
    `SELECT * FROM audit_log ${like ? 'WHERE action LIKE ? OR user_name LIKE ? OR reason LIKE ?' : ''} ORDER BY at DESC LIMIT ?`,
    like ? [like, like, like, limit] : [limit]
  );
}
