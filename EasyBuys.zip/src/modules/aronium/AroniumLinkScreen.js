// Admin › Aronium link: each till PC's last send, what the main tablet did with it, and anything waiting.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Btn, Banner, Row, Section, useUI, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Explain } from '../../ui/kit.js';
import { money } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import * as L from './link.js';

// The till PCs stamp in UTC (…Z): minutes since, worked out in UTC on both sides.
const minsSince = (iso) => {
  if (!iso) return Infinity;
  const s = String(iso);
  const t = new Date(/Z$/.test(s) ? s : `${s.replace(' ', 'T').slice(0, 19)}Z`).getTime();
  return Number.isFinite(t) ? Math.round((Date.now() - t) / 60000) : Infinity;
};
const ago = (iso) => {
  const mins = minsSince(iso);
  if (mins === Infinity) return 'never';
  if (mins < 2) return 'just now';
  if (mins < 120) return `${mins} min ago`;
  if (mins < 48 * 60) return `${Math.round(mins / 60)} hours ago`;
  return `${Math.round(mins / 1440)} days ago`;
};

export function AroniumLinkScreen() {
  const ui = useUI();
  const { nav } = useApp();
  const [, setTick] = useState(0);
  const [busy, setBusy] = useState(false);
  const st = L.linkStatus();
  const shops = Object.fromEntries(listShops({ includeInactive: true }).map((s) => [s.code, s.name]));
  const run = () => {
    setBusy(true);
    setTimeout(() => {
      try {
        const r = L.processLink({ force: true, limit: 200 });
        ui.toast ? ui.toast(r.did && r.did.length ? `Done: ${r.did.length} update(s)` : 'Everything is up to date') : null;
      } catch (e) { ui.error(e); }
      setBusy(false); setTick((n) => n + 1);
    }, 50);
  };
  const last = st.last;
  return (
    <Screen title="Aronium link" subtitle="Figures from the till PCs (Aronium is only read)">
      <Explain>
        Each till PC runs the Easy Buys Aronium Link program. It reads Aronium (never changes it) and sends products, prices,
        sales, every End of day, stock, staff credit and purchases to the cloud. The main tablet then books the sales into
        stock, records each End of day against the till balance and keeps the product list and suppliers up to date.
      </Explain>
      {!st.tills.length ? <Banner tone="info" title="No till PC has sent anything yet" message="Install the Easy Buys Aronium Link on each till PC (Shop 1: Till 1 and Till 2, Shop 2: Till 1) and press Send now." /> : null}
      {!st.isLinkDevice ? <Banner tone="info" title="Another device is doing this now" message={`${(() => { try { const i = require('../../services/jobLease.js').leaseInfo('link'); return i && i.holderName && !i.mine ? `${i.holderName} turns` : 'One linked device at a time turns'; } catch (e) { return 'One linked device at a time turns'; } })()} the tills' products, suppliers and staff credit into the app's records. Every device makes the sales and End of days. If that device stops syncing, this one takes over by itself.`} /> : null}
      {st.tills.map((t) => {
        const quiet = minsSince(t.lastSeen) > 180;
        return (
          <Card key={t.source} tone={quiet ? 'warn' : undefined}>
            <Text style={{ fontSize: 18, fontWeight: '700', color: C.text }}>{shops[t.shop] || t.shop} · {String(t.till || t.source).split(', ').pop()}</Text>
            <Row label="Last heard from" value={ago(t.lastSeen)} color={quiet ? C.danger : undefined} />
            {t.lastZ ? <Row label="Last End of day" value={`Z ${t.lastZ.number || '—'} · ${t.lastZ.date} · ${money(t.lastZ.total)}`} /> : null}
            {t.counts && t.counts.Product !== undefined ? <Row label="In Aronium" value={`${t.counts.Product || 0} products, ${t.counts.Document || 0} documents`} /> : null}
            {(() => {
              // Release 31: the products list – whole here, and what the app last did with it
              let ls = null;
              try { ls = require('./link.js').listState(t.source, 'products'); } catch (e) { ls = null; }
              if (!ls) return <Row label="Products list" value="not received yet" color={C.danger} />;
              return (
                <>
                  <Row label="Products list" value={ls.complete ? `complete · sent ${String(ls.at).slice(5, 16).replace('T', ' ')}` : `INCOMPLETE – ${ls.have} of ${ls.parts} parts`} color={ls.complete ? undefined : C.danger} />
                  {ls.note ? <Row label="Products brought in" value={ls.note} /> : null}
                  {!ls.complete ? <Text style={{ fontSize: 14, color: C.danger }}>Part of the products list is missing, so new products cannot come in. Press "Send everything again" on the Aronium page (it is also asked for by itself).</Text> : null}
                </>
              );
            })()}
            {t.version ? <Row label="Program version" value={t.version} /> : null}
            {t.notes && t.notes.length ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 6 }}>{t.notes.join(' ')}</Text> : null}
            {quiet ? <Text style={{ fontSize: 14, color: C.danger, marginTop: 6 }}>Nothing for over 3 hours – check the PC is on, online and the program is set to send on its own.</Text> : null}
          </Card>
        );
      })}
      {last ? (
        <Section title="Last round on the main tablet">
          <Card>
            <Row label="When" value={String(last.at || '').slice(0, 16)} />
            {last.left ? <Row label="Days still to bring in" value={String(last.left)} /> : null}
            {(last.did || []).map((x, i) => <Text key={i} style={{ fontSize: 14, color: C.text }}>• {x}</Text>)}
            {(last.errors || []).map((x, i) => <Text key={`e${i}`} style={{ fontSize: 14, color: C.danger }}>⚠ {x}</Text>)}
          </Card>
        </Section>
      ) : null}
      {st.waiting ? (
        <Section title="Waiting">
          <Card tone="warn">
            {st.waitingNotes.map((w) => <Text key={w.key} style={{ fontSize: 14, color: C.text, marginBottom: 4 }}>• {w.key.replace(/\|/g, ' ')}: {w.note}</Text>)}
            <Text style={{ fontSize: 13, color: C.sub, marginTop: 4 }}>Sales of products not in the app's product list wait until the product list from the till arrives, then they are booked by themselves.</Text>
          </Card>
        </Section>
      ) : null}
      <Btn testID="link-hub" title="Aronium – sales, receipts, items sold" icon="🧾" onPress={() => nav.push('AroniumHub', {})} />
      <Btn testID="link-insights" title="Aronium insights" icon="💡" variant="secondary" onPress={() => nav.push('AroniumInsights', {})} />
      <Btn testID="link-run" title={busy ? 'Working…' : 'Bring in the tills\' figures now'} icon="⟳" disabled={busy} onPress={run} />
    </Screen>
  );
}
