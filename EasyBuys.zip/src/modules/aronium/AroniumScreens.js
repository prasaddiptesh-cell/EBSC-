// 1.0.0 Aronium – everything in one place (map screens r-aron, r-items, s-refund, s-receipt, r-prod):
//   AroniumHub  – till PCs, live receipts, items sold, End of days, cash in each till now, Link events, refunds
//   ArReceipts  – find a receipt (params.pick = 'refund' for "Something happened › Customer refund")
//   ArReceipt   – one receipt with what was sold; the refund reason is noted here (the refund is done in Aronium)
//   ArItems     – items sold, by day, shift or till
//   ArProducts  – the products from Aronium: what to fix in Aronium, every change seen, the margin rule
// Aronium is only read. Every list is a drop-down; big buttons and short words.
import React, { useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Btn, Banner, Row, Section, Select, Field, useUI, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { ListItem, Stats, Hint } from '../../ui/kit.js';
import { dateStr, addDays } from '../../services/core.js';
import * as R from './receipts.js';
import { PullEodBox } from './PullEodBox.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
export const time12 = (t) => {
  const m = /^(\d{2}):(\d{2})/.exec(String(t || ''));
  if (!m) return String(t || '');
  const h = Number(m[1]);
  return `${h % 12 || 12}:${m[2]} ${h >= 12 ? 'pm' : 'am'}`;
};
const qty = (n) => (Math.abs(n - Math.round(n)) < 0.001 ? String(Math.round(n)) : String(Math.round(n * 1000) / 1000));
// The till PCs keep sending: the screens read again every 30 seconds.
function useLive(on = true, ms = 30000) {
  const [n, setN] = useState(0);
  useEffect(() => { if (!on) return undefined; const t = setInterval(() => setN((x) => x + 1), ms); return () => clearInterval(t); }, [on, ms]);
  return n;
}
const SHOPS = [{ value: '', label: 'Both shops' }, { value: 'S1', label: 'Shop 1 – Drasa Avenue' }, { value: 'S2', label: 'Shop 2 – Tukani Street' }];
const DAYS = () => [0, 1, 2, 3, 4, 5, 6].map((i) => { const d = addDays(dateStr(), -i); return { value: d, label: i === 0 ? `Today (${d})` : i === 1 ? `Yesterday (${d})` : d }; });
const tone = (s) => (s === 'ok' ? 'success' : s === 'slow' ? 'warn' : 'danger');

function ShopPick({ user, value, onChange, testID }) {
  const only = R.receiptShop(user, '');
  if (only) return null; // a shop's own staff only see their shop
  return <Select testID={testID} label="Shop" value={value} options={SHOPS} onChange={onChange} />;
}

function ReceiptRow({ r, onPress }) {
  return (
    <ListItem testID={`ar-rc-${r.no || r.time}`} title={`${r.refund ? 'REFUND ' : ''}#${r.no || '—'} · ${time12(r.time)} · ${R.tillLabel(r.source).replace(/^Shop \d /, '')}`}
      sub={r.items && r.items.length ? r.items.slice(0, 3).map((l) => `${R.productName(l.code)} × ${qty(l.qty)}`).join(', ') + (r.items.length > 3 ? ` +${r.items.length - 3} more` : '') : `${r.lines || 0} line${r.lines === 1 ? '' : 's'}${r.pay ? ` · ${r.pay}` : ''}`}
      right={`${r.refund ? '−' : ''}${$(r.total)}`} rightSub={r.pay || ''} tone={r.refund ? 'warn' : undefined} onPress={onPress} />
  );
}

// ---------------------------------------------------------------- the hub
const TABS = [{ value: 'receipts', label: 'Receipts (live)' }, { value: 'items', label: 'Items sold' }, { value: 'eod', label: 'End of days' }, { value: 'cash', label: 'Cash in each till now' },
  { value: 'refunds', label: 'Customer refunds' }, { value: 'link', label: 'Till PC events (stopped, changed…)' }, { value: 'products', label: 'Products – what to fix in Aronium' }];
export function AroniumHubScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [tab, setTab] = useState(TABS.some((t) => t.value === params.tab) ? params.tab : 'receipts');
  const [shop, setShop] = useState(R.receiptShop(user, params.shop || ''));
  const live = useLive(true);
  const h = useMemo(() => safe(() => R.hubSummary({ shop }), null), [shop, live]);
  const rc = useMemo(() => (tab === 'receipts' ? safe(() => R.receiptList({ shop, limit: 40 }), []) : []), [tab, shop, live]);
  if (!h) return <Screen title="Aronium"><Banner tone="danger" message="Could not read the Aronium figures. Try again in a moment." /></Screen>;
  return (
    <Screen title="Aronium" subtitle={shop ? (SHOPS.find((s) => s.value === shop) || {}).label : 'Both shops · from the till PCs (read only)'}>
      <ShopPick user={user} value={shop} onChange={setShop} testID="ar-shop" />
      {!h.tills.length ? <Banner tone="info" title="No till PC has sent anything yet" message="Install the Easy Buys Aronium Link on each till PC. Settings › Aronium link has the steps." /> : null}
      {h.tills.map((t) => <ListItem key={t.source} testID={`ar-till-${t.source}`} title={t.label} right={t.text} tone={tone(t.state) === 'success' ? undefined : tone(t.state)} badge={t.state === 'ok' ? '●' : t.state === 'slow' ? '◐' : '○'} badgeColor={t.state === 'ok' ? C.success : t.state === 'slow' ? C.warn : C.danger} onPress={() => nav.push('AroniumLink', {})} />)}
      {h.quiet.map((q) => <Banner key={q.shop} tone="warn" title={q.lastSale ? `No sales at ${q.name} for ${q.mins} min` : `No sales at ${q.name} yet`} message={q.lastSale ? `Last sale at ${time12(q.lastSale)}. The shop is open – is the till being used?` : `Open since ${time12(q.opened)}.`} />)}
      {h.started.slice(0, 3).map((t) => <Hint key={t.id}>{`🔔 ${R.tillLabel(t.source)} started – first sale ${t.exact ? 'at' : 'about'} ${time12(t.first)}`}</Hint>)}
      <PullEodBox testID="ar-pull" />
      <Stats items={[{ label: 'Sales today', value: $(h.sales), sub: h.last ? `last ${time12(h.last)}` : 'none yet' }, { label: 'Receipts', value: String(h.receipts), sub: h.refunds ? `${h.refunds} refund${h.refunds === 1 ? '' : 's'}` : '' }, { label: 'Items sold', value: qty(h.items) }]} />
      <Select testID="ar-tab" label="Show" value={tab} options={TABS} onChange={(v) => (v === 'products' ? nav.push('ArProducts', {}) : setTab(v))} />
      {tab === 'receipts' ? (
        <>
          {!rc.length ? <Hint>No receipts yet today. They come from each till PC within about 30 seconds of a sale.</Hint> : null}
          {rc.map((r) => <ReceiptRow key={r.key} r={r} onPress={() => nav.push('ArReceipt', { key: r.key })} />)}
          <ListItem testID="ar-items-today" title="Items sold today" right={`${qty(h.items)} items`} onPress={() => nav.push('ArItems', { shop })} />
          <Btn testID="ar-find" title="Find a receipt" icon="🔍" variant="secondary" onPress={() => nav.push('ArReceipts', { shop })} />
        </>
      ) : null}
      {tab === 'items' ? <ItemsBlock shop={shop} date={dateStr()} by="day" live={live} onMore={() => nav.push('ArItems', { shop })} /> : null}
      {tab === 'eod' ? <EodBlock shop={shop} onOpen={() => nav.push('AroniumEods', {})} /> : null}
      {tab === 'cash' ? <CashBlock drawers={h.drawers} /> : null}
      {tab === 'refunds' ? <RefundsBlock shop={shop} onOpen={(key) => nav.push('ArReceipt', { key })} /> : null}
      {tab === 'link' ? <EventsBlock /> : null}
      {/* 1.0.0 Records › Aronium opens this page: the older Aronium pages (sales history, End of day checks, product
          changes, insights, purchases vs invoices, till PCs) stay one tap away */}
      <Btn testID="ar-more" title="More Aronium pages" icon="🗂️" variant="secondary" onPress={() => nav.push('Area', { area: 'aronium' })} />
    </Screen>
  );
}

function ItemsBlock({ shop, date, by, live, onMore }) {
  const t = useMemo(() => safe(() => R.itemsSold({ date, shop, by }), null), [shop, date, by, live]);
  if (!t) return null;
  const g = t.groups[0];
  return (
    <>
      {!g ? <Hint>Nothing sold yet.</Hint> : g.items.slice(0, 12).map((i) => <ListItem key={i.code} title={i.name} right={qty(i.qty)} rightSub={$(i.value)} />)}
      <Btn testID="ar-items-more" title="Items sold – by shift and till" icon="📋" variant="secondary" onPress={onMore} />
    </>
  );
}
function EodBlock({ shop, onOpen }) {
  const list = safe(() => R.endOfDays({ shop }), []);
  return (
    <>
      {!list.length ? <Hint>No End of day from the till PCs in the last 14 days.</Hint> : null}
      {list.slice(0, 30).map((z) => <ListItem key={`${z.source}-${z.key || z.number}`} testID={`ar-eod-${z.source}-${z.number}`} title={`${z.label} · End of day ${z.number || ''}`} sub={`${z.when}${z.receipts ? ` · ${z.receipts} receipts` : ''} · cash ${$(z.cash)}`} right={$(z.total)} onPress={onOpen} />)}
      <Btn testID="ar-eod-all" title="Match End of days to till balances" icon="🧾" variant="secondary" onPress={onOpen} />
    </>
  );
}
function CashBlock({ drawers }) {
  if (!drawers.length) return <Hint>No till PC has sent today's receipts yet.</Hint>;
  return drawers.map((d) => (
    <Card key={d.source}>
      <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{R.tillLabel(d.source)}</Text>
      <Row label="Cash that should be in the till now" value={$(d.expected)} bold />
      <Row label={`Float${d.floatFrom === 'Aronium' ? ' (from Aronium)' : d.floatFrom === 'app' ? ' (the till\'s float)' : ''}`} value={$(d.float)} />
      <Row label="Cash sales" value={$(d.cashSales)} />
      {d.cashRefunds ? <Row label="Cash paid back (refunds)" value={`−${$(d.cashRefunds)}`} /> : null}
      {d.cashIn ? <Row label="Cash put in" value={$(d.cashIn)} /> : null}
      {d.cashOut ? <Row label="Cash taken out" value={`−${$(d.cashOut)}`} /> : null}
      {Object.entries(d.payments).filter(([n]) => !R.isCashName(n)).map(([n, v]) => <Row key={n} label={n} value={$(v)} />)}
      <Text style={{ fontSize: 13, color: C.sub }}>{`${d.receipts} receipts since ${d.since ? `the End of day at ${time12(d.since)}` : 'the start of the day'}${d.exact ? '' : ' (about)'}`}</Text>
    </Card>
  ));
}
function RefundsBlock({ shop, onOpen }) {
  const list = safe(() => R.listRefunds({ shop }), []);
  const chk = safe(() => R.refundsToCheck({}), { notDone: [], noReason: [] });
  return (
    <>
      {chk.notDone.length ? <Banner tone="warn" title={`${chk.notDone.length} refund${chk.notDone.length === 1 ? '' : 's'} not yet done in Aronium`} message="Do the refund in Aronium on the till, then note it again as done." /> : null}
      {chk.noReason.filter((r) => !shop || r.shop === shop).slice(0, 20).map((r) => <ListItem key={r.key} title={`Refund #${r.no || '—'} · ${r.date} ${time12(r.time)}`} sub="Done in Aronium – no reason noted yet" right={$(r.total)} tone="warn" onPress={() => onOpen(r.key)} />)}
      {!list.length ? <Hint>No customer refunds noted in the last 30 days.</Hint> : null}
      {list.map((x) => <ListItem key={x.uid} title={`#${x.receipt_no || '—'} · ${x.receipt_date} · ${x.reason}`} sub={`${x.by_name || ''} · ${x.done_in_aronium ? 'done in Aronium' : 'NOT done in Aronium yet'}${x.note ? ` · ${x.note}` : ''}`} right={$(x.total)} tone={x.done_in_aronium ? undefined : 'warn'} onPress={() => onOpen(x.receipt_key)} />)}
    </>
  );
}
function EventsBlock() {
  const ev = safe(() => R.linkEvents({ days: 30 }), []);
  if (!ev.length) return <Hint>Nothing unusual from the till PCs in the last 30 days.</Hint>;
  return ev.map((e, i) => <ListItem key={`${e.source}-${e.at}-${i}`} title={`${e.label}: ${e.text}`} sub={`${String(e.at).slice(0, 16).replace('T', ' ')} UTC${e.who ? ` · ${e.who}` : ''}${e.pc ? ` on ${e.pc}` : ''}${e.detail && e.detail.new ? ` · now ${e.detail.new}` : ''}`} tone={e.urgent ? 'danger' : undefined} />);
}

// ---------------------------------------------------------------- find a receipt (customer refund)
export function ArReceiptsScreen({ params = {} }) {
  const { nav, user } = useApp();
  const days = useMemo(DAYS, []);
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShop] = useState(R.receiptShop(user, params.shop || ''));
  const [till, setTill] = useState(params.source || '');
  const [q, setQ] = useState('');
  const live = useLive(date === dateStr());
  const refund = params.pick === 'refund';
  const tills = useMemo(() => [{ value: '', label: 'Every till' }].concat(safe(() => R.tillPcs(), []).filter((t) => !shop || t.shop === shop).map((t) => ({ value: t.source, label: t.label }))), [shop]);
  const list = useMemo(() => safe(() => R.receiptList({ date, shop, source: till, q, limit: 120 }), []), [date, shop, till, q, live]);
  return (
    <Screen title={refund ? 'Customer refund – find the receipt' : 'Receipts'} subtitle="Receipts come from Aronium as they happen">
      {refund ? <Hint>Do the refund in Aronium on the till first. Then pick the receipt here and say why.</Hint> : null}
      <Select testID="arr-day" label="Day" value={date} options={days} onChange={setDate} />
      <ShopPick user={user} value={shop} onChange={(v) => { setShop(v); setTill(''); }} testID="arr-shop" />
      <Select testID="arr-till" label="Till" value={till} options={tills} onChange={setTill} />
      <Field testID="arr-q" label="Search" value={q} onChangeText={setQ} placeholder="receipt no. or product" />
      {!list.length ? <Hint>{q ? 'No receipt matches.' : 'No receipts for this day yet.'}</Hint> : null}
      {list.map((r) => <ReceiptRow key={r.key} r={r} onPress={() => nav.push('ArReceipt', { key: r.key, refund })} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- one receipt
export function ArReceiptScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const r = safe(() => R.getReceipt(params.key), null);
  const [done, setDone] = useState('');
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  if (!r) return <Screen title="Receipt"><Banner tone="warn" title="Receipt not found" message="It may be older than 90 days, or the till PC has not sent it yet." /></Screen>;
  const only = R.receiptShop(user, r.shop);
  if (only && only !== r.shop) return <Screen title="Receipt"><Banner tone="warn" message="That receipt is from another shop." /></Screen>;
  const canNote = R.canSeeReceipts(user);
  const save = () => {
    try {
      R.saveRefund(user, r.key, { done, reason, note });
      ui.toast('Saved');
      bump((n) => n + 1);
      if (params.refund && nav.pop) nav.pop();
    } catch (e) { ui.error(e); }
  };
  const prev = r.refundNote;
  return (
    <Screen title={`Receipt #${r.no || '—'}`} subtitle={`${r.date} · ${time12(r.time)} · ${R.tillLabel(r.source)}${r.who ? ` · ${r.who}` : ''}`}>
      {r.refund ? <Banner tone="warn" title="This is a refund in Aronium" message="Money was paid back on this receipt." /> : null}
      {!r.lines.length ? <Hint>{`This till PC does not send what was sold on each receipt yet – update its Aronium Link. (${r.itemCount || 0} line${r.itemCount === 1 ? '' : 's'} on this receipt.)`}</Hint> : null}
      {r.lines.map((l, i) => (
        <ListItem key={`${l.code}-${i}`} testID={`ar-line-${i}`} title={`${l.name} × ${qty(l.qty)}`} sub={l.disc ? `${$(l.price)} each · discount ${$(l.disc)}` : `${$(l.price)} each`} right={$(l.total)} />
      ))}
      <Row label={`Total · ${r.pays.length ? r.pays.map((p) => `${p.name} ${$(p.amount)}`).join(' + ') : r.pay || 'not known'}`} value={`${r.refund ? '−' : ''}${$(r.total)}`} bold />
      {r.discount ? <Row label="Discounts on this receipt" value={$(r.discount)} /> : null}
      {r.endOfDay ? <Row label="Shift" value={r.endOfDay} /> : null}
      {prev ? <Banner tone={prev.done_in_aronium ? 'success' : 'warn'} title={`Refund noted: ${prev.reason}`} message={`${prev.by_name || ''} · ${String(prev.at).slice(0, 16)} · ${prev.done_in_aronium ? 'done in Aronium' : 'NOT done in Aronium yet'}${prev.note ? ` · ${prev.note}` : ''}`} /> : null}
      {canNote && (params.refund || prev || r.refund) ? (
        <Section title={prev ? 'Note it again' : 'Customer refund'}>
          <Select testID="ar-rf-done" label="Refund done in Aronium?" value={done} onChange={setDone} options={[{ value: 'yes', label: 'Yes – done in Aronium' }, { value: 'no', label: 'No – not yet' }]} />
          <Select testID="ar-rf-why" label="Why" value={reason} onChange={setReason} options={R.REFUND_REASONS.map((x) => ({ value: x, label: x }))} />
          {reason === 'Something else' ? <Field testID="ar-rf-note" label="What happened" value={note} onChangeText={setNote} /> : null}
          <Btn testID="ar-rf-save" title="Save" icon="✔" disabled={!done || !reason} onPress={save} />
        </Section>
      ) : canNote ? <Btn testID="ar-rf-start" title="A customer refund on this receipt" icon="↩" variant="secondary" onPress={() => nav.push('ArReceipt', { key: r.key, refund: true })} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- items sold
const BY = [{ value: 'day', label: 'The whole day' }, { value: 'shift', label: 'By shift (each End of day)' }, { value: 'till', label: 'By till' }];
export function ArItemsScreen({ params = {} }) {
  const { user } = useApp();
  const days = useMemo(DAYS, []);
  const [date, setDate] = useState(params.date || dateStr());
  const [by, setBy] = useState(params.by || 'day');
  const [shop, setShop] = useState(R.receiptShop(user, params.shop || ''));
  const live = useLive(date === dateStr());
  const t = useMemo(() => safe(() => R.itemsSold({ date, shop, by }), null), [date, shop, by, live]);
  return (
    <Screen title="Items sold" subtitle={`${date === dateStr() ? 'today' : date}${shop ? ` · ${shop === 'S1' ? 'Shop 1' : 'Shop 2'}` : ' · both shops'}`}>
      <Select testID="ari-day" label="Day" value={date} options={days} onChange={setDate} />
      <Select testID="ari-by" label="Show" value={by} options={BY} onChange={setBy} />
      <ShopPick user={user} value={shop} onChange={setShop} testID="ari-shop" />
      {t && t.note ? <Hint>{t.note}</Hint> : null}
      {t ? <Stats items={[{ label: 'Items', value: qty(t.qty) }, { label: 'Value', value: $(t.value) }]} /> : null}
      {t && !t.groups.length ? <Hint>Nothing sold on this day.</Hint> : null}
      {(t ? t.groups : []).map((g) => (
        <Section key={g.key} title={`${g.label} · ${qty(g.qty)} items`}>
          {g.items.slice(0, 200).map((i) => <ListItem key={`${g.key}-${i.code}`} testID={`ari-${i.code}`} title={i.name} right={qty(i.qty)} rightSub={$(i.value)} sub={i.refunded ? `${qty(i.refunded)} refunded` : undefined} />)}
        </Section>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- products from Aronium
const PTABS = [{ value: 'fix', label: 'What to fix in Aronium' }, { value: 'changes', label: 'Changes seen in Aronium' }, { value: 'rules', label: 'Warning settings' }];
export function ArProductsScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const W = require('../../services/productWatch.js');
  const [tab, setTab] = useState(params.tab === 'changes' ? 'changes' : params.tab === 'rules' ? 'rules' : 'fix');
  const [kind, setKind] = useState(params.kind || '');
  const [days, setDays] = useState('7');
  const [shop, setShop] = useState('');
  const [, bump] = useState(0);
  const p = safe(() => W.productProblems(), null);
  const fixes = p ? safe(() => W.fixList(p), []) : [];
  const kinds = [{ value: '', label: `Everything (${fixes.length})` }].concat(Object.entries(W.PROBLEM_TITLE).map(([k, t]) => ({ value: k, label: `${t} (${fixes.filter((f) => f.kind === k).length})` })));
  const shown = fixes.filter((f) => (!kind || f.kind === kind) && (!shop || !f.shop || f.shop === shop));
  const today = dateStr();
  const changes = tab === 'changes' ? safe(() => W.listChanges({ from: addDays(today, -Number(days)), to: today, shopCode: shop || undefined, limit: 600 }), []) : [];
  const boss = user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
  const rules = safe(() => W.watchRules(), { marginPct: 10 });
  return (
    <Screen title="Products" subtitle="From Aronium – change them in Aronium, the app never does">
      {p && p.noTax.length ? <Banner tone="danger" testID="arp-notax" title={`${p.noTax.length} product${p.noTax.length === 1 ? ' has' : 's have'} no VAT set in Aronium`} message="Fix in Aronium: VAT 12.5% or the 0% zero-rated tax. A blank tax is not zero-rated." /> : null}
      <Select testID="arp-tab" label="Show" value={tab} options={PTABS} onChange={setTab} />
      <Select testID="arp-shop" label="Shop" value={shop} options={SHOPS} onChange={setShop} />
      {tab === 'fix' ? (
        <>
          <Select testID="arp-kind" label="Which" value={kind} options={kinds} onChange={setKind} />
          {!shown.length ? <Banner tone="success" title="Nothing to fix" message="Every product from Aronium has a price, tax and barcode, priced above cost." /> : null}
          {shown.slice(0, 150).map((f) => (
            <Card key={f.id} tone={f.level === 'danger' ? 'danger' : f.level === 'warn' ? 'warn' : undefined}>
              <Text style={{ fontSize: 13, fontWeight: '800', color: f.level === 'danger' ? C.danger : f.level === 'warn' ? C.warn : C.sub }}>{W.PROBLEM_TITLE[f.kind].toUpperCase()}</Text>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{f.name}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{f.text}</Text>
              <Text testID={`arp-fix-${f.code}`} style={{ fontSize: 15, color: C.text, marginTop: 4 }}>{`➜ ${f.fix}`}</Text>
            </Card>
          ))}
        </>
      ) : null}
      {tab === 'changes' ? (
        <>
          <Select testID="arp-days" label="Since" value={days} options={[{ value: '1', label: 'Yesterday' }, { value: '7', label: '7 days' }, { value: '31', label: '31 days' }]} onChange={setDays} />
          {!changes.length ? <Hint>No changes seen in Aronium in this time. (The first list from each till PC is only remembered.)</Hint> : null}
          {changes.map((c) => <ListItem key={c.uid} title={`${W.CHANGE_LABEL[c.kind] || c.kind}: ${c.name || c.code}`} sub={`${c.shop_code} · ${String(c.at).slice(0, 16)}${c.old_value !== null || c.new_value !== null ? ` · ${c.old_value ?? ''}${c.old_value !== null && c.new_value !== null ? ' → ' : ''}${c.new_value ?? ''}` : ''}`} tone={c.kind === 'tax' || c.kind === 'removed' ? 'warn' : undefined} />)}
        </>
      ) : null}
      {tab === 'rules' ? (
        <>
          <Select testID="arp-margin" label="Warn when the margin is below" value={String(rules.marginPct)} disabled={!boss}
            options={W.MARGIN_CHOICES.map((m) => ({ value: String(m), label: m ? `${m}% of the selling price` : 'Off (no margin warning)' }))}
            onChange={(v) => { try { W.saveWatchRules(user, { marginPct: Number(v) }); ui.toast('Saved'); bump((n) => n + 1); } catch (e) { ui.error(e); } }} />
          {!boss ? <Hint>Only the owner or the admin changes this.</Hint> : null}
        </>
      ) : null}
    </Screen>
  );
}
