// Aronium insights (v3.9.4): busy hours, reorder list (draft orders in one tap), cashier watch, price check, slow movers.
// Worked out only for the open tab and shop, and only when they change, so the screen stays quick.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Table, Section, Empty, useUI, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Explain } from '../../ui/kit.js';
import { money } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import * as N from './insights.js';

const TABS = [
  { value: 'hours', label: 'Busy hours' },
  { value: 'reorder', label: 'Reorder' },
  { value: 'cashiers', label: 'Cashier watch' },
  { value: 'prices', label: 'Price check' },
  { value: 'slow', label: 'Slow movers' },
];
const safe = (fn, d) => { try { return fn(); } catch (e) { return d; } };

function HourBars({ day, hours }) {
  const max = Math.max(1, ...hours.map((h) => day.avg[h] || 0));
  return (
    <View>
      {hours.map((h) => {
        const v = day.avg[h] || 0;
        const best = day.busiest && day.busiest.hour === h;
        return (
          <View key={h} style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 3 }}>
            <Text style={{ width: 64, fontSize: 15, color: C.sub }}>{N.hourLabel(h)}</Text>
            <View style={{ flex: 1, height: 22, backgroundColor: '#F3EFE8', borderRadius: 6, overflow: 'hidden' }}>
              <View style={{ width: `${Math.round((v / max) * 100)}%`, height: 22, backgroundColor: best ? C.primary : C.brandBlue, borderRadius: 6 }} />
            </View>
            <Text style={{ width: 96, textAlign: 'right', fontSize: 15, fontWeight: best ? '800' : '400', color: C.text }}>{money(v)}</Text>
          </View>
        );
      })}
    </View>
  );
}

export function InsightsScreen({ route }) {
  const ui = useUI();
  const { user } = useApp();
  const shops = safe(() => listShops({}), []).filter((s) => s.active !== 0);
  const [tab, setTab] = useState((route && route.params && route.params.tab) || 'hours');
  const [shop, setShop] = useState((shops[0] && shops[0].code) || 'S1');
  const [dayIdx, setDayIdx] = useState(new Date().getDay());
  const [slowDays, setSlowDays] = useState(30);
  const [tick, setTick] = useState(0);
  const [busy, setBusy] = useState(false);

  const data = useMemo(() => {
    if (tab === 'hours') return safe(() => N.busyHours({ shop }), null);
    if (tab === 'reorder') return safe(() => N.reorderList({ shop }), []);
    if (tab === 'cashiers') return safe(() => N.cashierWatch({ shop }), []);
    if (tab === 'prices') return safe(() => N.priceCheck(), { differ: [], belowCost: [] });
    if (tab === 'slow') return safe(() => N.slowMovers({ shop, days: slowDays }), []);
    return null;
  }, [tab, shop, slowDays, tick]);

  const makeOrders = async () => {
    const withSup = (data || []).filter((g) => g.supplierUid);
    if (!withSup.length) { ui.alert({ title: 'Nothing to order', message: 'No product with a main supplier needs ordering for this shop.' }); return; }
    const ok = await ui.confirm({ title: `Make ${withSup.length} draft order${withSup.length === 1 ? '' : 's'}?`, message: 'One per supplier. They still need approving and sending, as usual.', confirmText: 'Make them' });
    if (!ok) return;
    setBusy(true);
    setTimeout(() => {
      try {
        const made = N.makeDraftOrders(user, { shop });
        ui.toast(`${made.length} draft order${made.length === 1 ? '' : 's'} made – approve and send them in Purchase orders`);
      } catch (e) { ui.error(e); }
      setBusy(false); setTick((n) => n + 1);
    }, 30);
  };

  const shopChips = tab !== 'prices' && shops.length > 1 ? (
    <View style={{ marginTop: 10 }}><Chips options={shops.map((s) => ({ value: s.code, label: s.name }))} value={shop} onChange={setShop} testIDPrefix="ins-shop" /></View>
  ) : null;

  let body = null;
  if (tab === 'hours') {
    const b = data;
    if (!b || !b.daysCounted) body = <Empty text="No hourly figures yet. They come from the till PCs (Aronium Link 1.1 or newer) from the next sale on." />;
    else {
      const d = b.days[dayIdx];
      body = (
        <View>
          {b.peak ? <Banner tone="info" title={`Busiest: ${b.peak.label}`} message={`About ${money(b.peak.value)} in that hour on average (last ${b.weeks} weeks, ${b.daysCounted} days).`} /> : null}
          <Chips options={N.DAYS.map((x, i) => ({ value: i, label: x }))} value={dayIdx} onChange={setDayIdx} testIDPrefix="ins-day" />
          <Card style={{ marginTop: 12 }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 6 }}>{d.day}: about {money(d.total)} a day{d.busiest ? ` · busiest ${d.busiest.label}` : ''}</Text>
            {d.samples ? <HourBars day={d} hours={b.hours} /> : <Text style={{ color: C.sub }}>No {d.day} in the figures yet.</Text>}
            <Text style={{ fontSize: 13, color: C.sub, marginTop: 8 }}>Average of {d.samples} {d.day}{d.samples === 1 ? '' : 's'}; all tills of the shop added up. Use it for rosters, opening hours and restocking before the rush.</Text>
          </Card>
        </View>
      );
    }
  } else if (tab === 'reorder') {
    const groups = data || [];
    body = !groups.length ? <Empty text="Nothing needs ordering for this shop. 👍" /> : (
      <View>
        <Btn testID="ins-make-orders" title={busy ? 'Making the orders…' : 'Make draft orders (one per supplier)'} icon="🧾" disabled={busy} onPress={makeOrders} />
        {groups.map((g) => (
          <Section key={`${g.shop}-${g.supplierUid || 'none'}`} title={`${g.supplier} · ${g.items.length} item${g.items.length === 1 ? '' : 's'}${g.total ? ` · about ${money(g.total)}` : ''}`}>
            {!g.supplierUid ? <Banner tone="warn" title="No main supplier set" message="Set the supplier on these products (Stock › product) so they go on an order." /> : null}
            <Table columns={[{ key: 'name', title: 'Product', width: 220 }, { key: 'have', title: 'In stock', align: 'right', width: 90 }, { key: 'perWeek', title: 'Sells / week', align: 'right', width: 110 },
              { key: 'daysLeft', title: 'Days left', align: 'right', width: 90 }, { key: 'qty', title: 'Order', align: 'right', width: 80, bold: true }]}
            rows={g.items.map((x) => ({ ...x, daysLeft: x.daysLeft === null || x.daysLeft === undefined ? '' : x.daysLeft }))} />
          </Section>
        ))}
      </View>
    );
  } else if (tab === 'cashiers') {
    const list = data || [];
    body = !list.length ? <Empty text="No cashier figures yet. They come from the till PCs (Aronium Link 1.1 or newer)." /> : (
      <View>
        {list.filter((c) => c.flags.length).map((c) => (
          <Card key={`f-${c.shop}-${c.name}`} tone="warn">
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>⚠️ {c.name}</Text>
            {c.flags.map((f, i) => <Text key={i} style={{ fontSize: 15, color: C.text }}>• {f}</Text>)}
            <Text style={{ fontSize: 13, color: C.sub, marginTop: 4 }}>Not proof of anything – worth a look at the receipts in Aronium and a talk.</Text>
          </Card>
        ))}
        <Table columns={[{ key: 'name', title: 'Cashier', width: 150 }, { key: 'salesT', title: 'Sales', align: 'right', width: 110 }, { key: 'receipts', title: 'Receipts', align: 'right', width: 90 },
          { key: 'refundsT', title: 'Refunds', align: 'right', width: 120 }, { key: 'voidsT', title: 'Voids', align: 'right', width: 110 }, { key: 'discT', title: 'Discounts', align: 'right', width: 120 }]}
        rows={list.map((c) => ({ ...c, salesT: money(c.sales), refundsT: `${c.refunds} · ${money(c.refund_value)}`, voidsT: `${c.voids} · ${money(c.void_value)}`, discT: `${c.discountPct}%`,
          _bg: c.flags.length ? C.warnSoft : undefined }))} testID="ins-cashiers" />
        <Text style={{ fontSize: 13, color: C.sub, marginTop: 8 }}>Last 30 days. Flagged when refunds, voids or discounts are about twice the rest of the team's, on more than a handful of sales.</Text>
      </View>
    );
  } else if (tab === 'prices') {
    const p = data || { differ: [], belowCost: [] };
    const shopName = (code) => (shops.find((s) => s.code === code) || {}).name || code;
    body = (
      <View>
        <Section title={`Sold below cost (last 30 days)${p.belowCost.length ? ` · ${p.belowCost.length}` : ''}`}>
          {!p.belowCost.length ? <Empty text="Nothing sold below cost. 👍" /> : (
            <Table columns={[{ key: 'name', title: 'Product', width: 200 }, { key: 'shopN', title: 'Shop', width: 120 }, { key: 'lowestT', title: 'Sold at', align: 'right', width: 90 },
              { key: 'costT', title: 'Cost', align: 'right', width: 90 }, { key: 'qty', title: 'Qty', align: 'right', width: 70 }, { key: 'lossT', title: 'Lost', align: 'right', width: 90, bold: true }]}
            rows={p.belowCost.map((x) => ({ ...x, shopN: shopName(x.shop), lowestT: money(x.lowest), costT: money(x.cost), lossT: money(x.loss) }))} testID="ins-below" />
          )}
        </Section>
        <Section title={`Different prices on different tills${p.differ.length ? ` · ${p.differ.length}` : ''}`}>
          {!p.differ.length ? <Empty text="Every till has the same prices. 👍" /> : (
            <Table columns={[{ key: 'name', title: 'Product', width: 200 }, { key: 'pricesT', title: 'Prices', width: 300 }]}
              rows={p.differ.map((x) => ({ ...x, pricesT: x.prices.map((y) => `${y.source}: ${money(y.price)}`).join(' · ') }))} testID="ins-differ" />
          )}
        </Section>
        <Text style={{ fontSize: 13, color: C.sub }}>Prices are changed in Aronium – this only shows them.</Text>
      </View>
    );
  } else if (tab === 'slow') {
    const list = data || [];
    const total = list.reduce((s, x) => s + (x.value || 0), 0);
    body = (
      <View>
        <Chips options={[30, 60, 90].map((d) => ({ value: d, label: `${d}+ days` }))} value={slowDays} onChange={setSlowDays} testIDPrefix="ins-slow" />
        {!list.length ? <Empty text="No stock has been sitting that long. 👍" /> : (
          <View style={{ marginTop: 10 }}>
            <Banner tone="warn" title={`${list.length} product${list.length === 1 ? '' : 's'} · ${money(total)} of stock not selling`} message="Ideas: move it to the front, a special, send it to the other shop, or stop ordering it." />
            <Table columns={[{ key: 'name', title: 'Product', width: 220 }, { key: 'have', title: 'In stock', align: 'right', width: 90 }, { key: 'valueT', title: 'Value', align: 'right', width: 100, bold: true },
              { key: 'lastT', title: 'Last sold', width: 120 }, { key: 'band', title: 'Days', width: 80 }]}
            rows={list.map((x) => ({ ...x, valueT: money(x.value), lastT: x.lastSale || 'never' }))} testID="ins-slow-list" />
          </View>
        )}
      </View>
    );
  }

  return (
    <Screen title="Aronium insights" subtitle="What the tills' figures say">
      <Explain>Worked out from the till PCs' figures and the app's own stock. Nothing here changes Aronium.</Explain>
      <Chips options={TABS} value={tab} onChange={setTab} testIDPrefix="ins-tab" />
      {shopChips}
      <View style={{ marginTop: 14 }}>{body}</View>
    </Screen>
  );
}
