// v3.9.4 On the Aronium CSV screens: the till PCs already bring this in by themselves, so a CSV is only a back-up.
import React from 'react';
import { Banner } from '../../ui/components.js';

const WHAT = { products: 'Products and prices', parties: 'Suppliers', credit: 'Staff credit (Who owes us)', sales_day: 'Sales' };
export function LinkBanner({ kind }) {
  let c = { on: false };
  try { c = require('./link.js').linkCovers(kind); } catch (e) { c = { on: false }; }
  if (!c.on) return null;
  const ago = c.mins < 2 ? 'just now' : c.mins < 120 ? `${c.mins} min ago` : c.mins < 2880 ? `${Math.round(c.mins / 60)} hours ago` : `${Math.round(c.mins / 1440)} days ago`;
  return (
    <Banner tone="success" testID={`link-banner-${kind}`} title={`✓ Automatic: ${WHAT[kind] || 'This'} come${kind === 'credit' ? 's' : ''} from the till PCs`}
      message={`Last update ${ago}. No need to upload a CSV – only use this if a till PC is not set up yet, or to correct something by hand.`} />
  );
}
