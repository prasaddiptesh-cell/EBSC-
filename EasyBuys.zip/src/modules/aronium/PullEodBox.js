// 1.0.0 build 5 (owner, 2 Nov): the "Get the End of day now" box – Balance the till (before hand entry) and the office
// Aronium page. Shop 1 / Shop 2 big buttons (the person's own shop picked; a manager / supervisor sees only theirs),
// one big button, then plain words while it waits. When the End of day is in, Balance the till opens for it.
import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Card, Btn, Banner, useApp, useUI } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import * as P from './pullEod.js';

export function PullEodBox({ onByHand, testID = 'pull', shop: pageShop = '' }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const shops = P.pullShops(user);
  const pick = () => (pageShop && shops.some((x) => x.code === pageShop) ? pageShop : P.defaultShop(user));
  const [shop, setShop] = useState(pick);
  // follow the page's shop (owner, 2 Nov: on Shop 2's Aronium page it still had Shop 1 picked)
  useEffect(() => { if (pageShop) setShop(pick()); }, [pageShop]);
  const [st, setSt] = useState(null); // { state, text }
  const timer = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; if (timer.current) clearTimeout(timer.current); }, []);
  if (!shops.length) return null;
  const name = P.shopLabel(shop);
  const open = (r) => { setSt(null); if (r.list && r.list.length > 1) nav.push('BalanceTill', {}); else nav.push('BalanceTill', { eodUid: r.eodUid }); };
  const poll = (job) => {
    timer.current = setTimeout(async () => {
      if (!alive.current) return;
      let r;
      try { r = await P.pollPull(user, job); } catch (e) { setSt({ state: 'timeout', text: (e && e.message) || String(e) }); return; }
      if (!alive.current) return;
      if (r.state === 'arrived') open(r);
      else if (r.state === 'timeout') setSt({ state: 'timeout', text: r.text });
      else { setSt({ state: 'waiting', text: `Asked ${name}'s till PCs… waiting (${r.secs} s)` }); poll(job); }
    }, P.POLL_MS);
  };
  const go = async () => {
    setSt({ state: 'working', text: 'Bringing in what is already in the cloud…' });
    let r;
    try { r = await P.startPull(user, shop); } catch (e) { setSt(null); ui.error(e); return; }
    if (!alive.current) return;
    if (r.state === 'arrived') open(r);
    else if (r.state === 'too_soon') setSt({ state: 'timeout', text: `Just asked – try again in ${r.wait} seconds.` });
    else if (r.state === 'offline') setSt({ state: 'timeout', text: `Could not ask ${name}'s till PCs – is the internet on? (${r.error})` });
    else { setSt({ state: 'waiting', text: `Asked ${name}'s till PCs… waiting` }); poll(r.job); }
  };
  const busy = st && (st.state === 'working' || st.state === 'waiting');
  return (
    <View testID={testID}><Card style={{ gap: 10 }}>
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Get the End of day now</Text>
      <Text style={{ fontSize: 16, color: C.sub }}>Asks the till PCs to send Aronium's End of day straight away – no waiting for the next send.</Text>
      {shops.length > 1 ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {shops.map((s) => (
            <Btn key={s.code} testID={`${testID}-shop-${s.code}`} title={`${s.code === shop ? '✓ ' : ''}${s.name}`} size="lg" variant={s.code === shop ? 'info' : 'secondary'} style={{ flex: 1 }}
              disabled={!!busy} onPress={() => { setShop(s.code); setSt(null); }} />
          ))}
        </View>
      ) : <Text testID={`${testID}-shop-${shop}`} style={{ fontSize: 22, fontWeight: '900', color: C.text }}>{name}</Text>}
      <Btn testID={`${testID}-go`} title={busy ? 'Waiting for the till PCs…' : `Get ${name}'s End of day now`} icon="⬇️" size="lg" disabled={!!busy} onPress={go} />
      {st ? <Banner testID={`${testID}-status`} tone={st.state === 'timeout' ? 'warn' : 'info'} message={st.text} /> : null}
      {st && st.state === 'timeout' && onByHand ? <Btn testID={`${testID}-by-hand`} title="Balance by hand" icon="✍️" size="md" variant="secondary" onPress={onByHand} /> : null}
    </Card></View>
  );
}
