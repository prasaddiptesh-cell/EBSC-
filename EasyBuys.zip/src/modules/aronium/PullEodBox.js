// 1.0.0 build 5 (owner, 2 Nov): the "Get the End of day now" box – Balance the till (before hand entry) and the office
// Aronium page. Shop 1 / Shop 2 big buttons (the person's own shop picked; a manager / supervisor sees only theirs),
// one big button, then plain words while it waits. When the End of day is in, Balance the till opens for it.
import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Card, Btn, Banner, useApp, useUI } from '../../ui/components.js';
import { DateField } from '../../ui/kit.js';
import { dateStr, addDays } from '../../services/core.js';
import { C } from '../../ui/theme.js';
import * as P from './pullEod.js';
import { missingEods, gapText } from './missingEod.js';

export function PullEodBox({ onByHand, testID = 'pull', shop: pageShop = '' }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const shops = P.pullShops(user);
  const pick = () => (pageShop && shops.some((x) => x.code === pageShop) ? pageShop : P.defaultShop(user));
  const [shop, setShop] = useState(pick);
  // follow the page's shop (owner, 2 Nov: on Shop 2's Aronium page it still had Shop 1 picked)
  useEffect(() => { if (pageShop) setShop(pick()); }, [pageShop]);
  const [st, setSt] = useState(null); // { state, text }
  const timer = useRef(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; if (timer.current) clearTimeout(timer.current); }, []);
  if (!shops.length) return null;
  const name = P.shopLabel(shop);
  const open = (r) => { setSt(null); if (r.list && r.list.length > 1) nav.push('BalanceTill', {}); else nav.push('BalanceTill', { eodUid: r.eodUid }); };
  const poll = (job) => {
    timer.current = setTimeout(async () => {
      if (!alive.current) return;
      let r;
      try { r = await P.pollPull(user, job); } catch (e) { setSt({ state: 'timeout', text: (e && e.message) || String(e) }); return; }
      if (!alive.current) return;
      if (r.state === 'arrived') open(r);
      else if (r.state === 'timeout') setSt({ state: 'timeout', text: r.text });
      else { setSt({ state: 'waiting', text: `Asked ${name}'s till PCs… waiting (${r.secs} s)` }); poll(job); }
    }, P.POLL_MS);
  };
  const go = async () => {
    setSt({ state: 'working', text: 'Bringing in what is already in the cloud…' });
    let r;
    try { r = await P.startPull(user, shop); } catch (e) { setSt(null); ui.error(e); return; }
    if (!alive.current) return;
    if (r.state === 'arrived') open(r);
    else if (r.state === 'too_soon') setSt({ state: 'timeout', text: `Just asked – try again in ${r.wait} seconds.` });
    else if (r.state === 'offline') setSt({ state: 'timeout', text: `Could not ask ${name}'s till PCs – is the internet on? (${r.error})` });
    else { setSt({ state: 'waiting', text: `Asked ${name}'s till PCs… waiting` }); poll(r.job); }
  };
  // build 30: an End of day that never came in → "Send everything again"
  let gaps = [];
  try { gaps = missingEods(shop); } catch (e) { gaps = []; }
  const pollAll = (job) => {
    timer.current = setTimeout(async () => {
      if (!alive.current) return;
      let r;
      try { r = await P.pollEverything(user, job); } catch (e) { setSt({ state: 'timeout', text: (e && e.message) || String(e) }); return; }
      if (!alive.current) return;
      if (r.state === 'done') setSt({ state: 'done', text: `All of ${name}'s End of days are in now.` });
      else if (r.state === 'timeout') setSt({ state: 'timeout', text: r.text });
      else { setSt({ state: 'waiting', text: `${name}'s till PCs are sending everything again… ${r.left} End of day${r.left === 1 ? '' : 's'} still to come (${r.secs} s)` }); pollAll(job); }
    }, P.POLL_MS);
  };
  const goAll = async () => {
    const ok = await ui.confirm({ title: 'Send everything again?', message: `${name}'s till PCs send all their Aronium records again – End of days, sales days, receipts. It can take a few minutes; nothing is doubled.`, confirmText: 'Send everything again' });
    if (!ok) return;
    setSt({ state: 'working', text: `Asking ${name}'s till PCs…` });
    let r;
    try { r = await P.askEverything(user, shop); } catch (e) { setSt(null); ui.error(e); return; }
    if (!alive.current) return;
    if (r.state !== 'asked') { setSt({ state: 'timeout', text: r.error }); return; }
    setSt({ state: 'waiting', text: `Asked ${name}'s till PCs to send everything again… waiting` });
    pollAll(r.job);
  };
  // Release 03: particular days
  const [days, setDays] = useState(null); // { from, to }
  const pollD = (job) => {
    timer.current = setTimeout(async () => {
      if (!alive.current) return;
      let r;
      try { r = await P.pollDays(user, job); } catch (e) { setSt({ state: 'timeout', text: (e && e.message) || String(e) }); return; }
      if (!alive.current) return;
      if (r.state === 'done') setSt({ state: 'done', text: `${name}'s till PCs sent ${job.from === job.to ? job.from : `${job.from} to ${job.to}`} again (${r.answered.join(', ')}).` });
      else if (r.state === 'timeout') setSt({ state: 'timeout', text: r.text });
      else { setSt({ state: 'waiting', text: `Asked for ${job.from === job.to ? job.from : `${job.from} to ${job.to}`}… ${r.answered.length} of ${r.tills.length} till PC(s) answered (${r.secs} s)` }); pollD(job); }
    }, P.POLL_MS);
  };
  const goDays = async () => {
    setSt({ state: 'working', text: `Asking ${name}'s till PCs…` });
    let r;
    try { r = await P.askDays(user, shop, days.from, days.to); } catch (e) { setSt(null); ui.error(e); return; }
    if (!alive.current) return;
    if (r.state !== 'asked') { setSt({ state: 'timeout', text: r.error }); return; }
    setDays(null);
    setSt({ state: 'waiting', text: 'Asked… waiting for the till PCs' });
    pollD(r.job);
  };
  const busy = st && (st.state === 'working' || st.state === 'waiting');
  return (
    <View testID={testID}><Card style={{ gap: 10 }}>
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Get the End of day now</Text>
      <Text style={{ fontSize: 16, color: C.sub }}>Asks the till PCs to send Aronium's End of day straight away – no waiting for the next send.</Text>
      {shops.length > 1 ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {shops.map((s) => (
            <Btn key={s.code} testID={`${testID}-shop-${s.code}`} title={`${s.code === shop ? '✓ ' : ''}${s.name}`} size="lg" variant={s.code === shop ? 'info' : 'secondary'} style={{ flex: 1 }}
              disabled={!!busy} onPress={() => { setShop(s.code); setSt(null); }} />
          ))}
        </View>
      ) : <Text testID={`${testID}-shop-${shop}`} style={{ fontSize: 22, fontWeight: '900', color: C.text }}>{name}</Text>}
      <Btn testID={`${testID}-go`} title={busy ? 'Waiting for the till PCs…' : `Get ${name}'s End of day now`} icon="⬇️" size="lg" disabled={!!busy} onPress={go} />
      {gaps.length && !busy ? <Banner testID={`${testID}-gaps`} tone="warn" title="End of days missing" message={`${gaps.map(gapText).join('; ')}. Press "Send everything again" below.`} /> : null}
      {!days ? <Btn testID={`${testID}-days`} title={`Ask for particular days (${name})`} icon="📅" size="md" variant="secondary" disabled={!!busy} onPress={() => setDays({ from: addDays(dateStr(), -1), to: addDays(dateStr(), -1) })} /> : (
        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <View style={{ flexGrow: 1, minWidth: 150 }}><DateField farDays={false} label="From" value={days.from} onChange={(v) => setDays({ ...days, from: v, to: days.to < v ? v : days.to })} /></View>
            <View style={{ flexGrow: 1, minWidth: 150 }}><DateField farDays={false} label="To" value={days.to} onChange={(v) => setDays({ ...days, to: v })} /></View>
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDays(null)} />
            <Btn testID={`${testID}-days-go`} title="Send these days again" icon="⬇️" size="md" variant="info" style={{ flex: 2 }} onPress={goDays} />
          </View>
        </View>
      )}
      <Btn testID={`${testID}-all`} title={`Send everything again (${name})`} icon="🔁" size={gaps.length ? 'lg' : 'md'} variant={gaps.length ? 'warn' : 'secondary'} disabled={!!busy} onPress={goAll} />
      {st ? <Banner testID={`${testID}-status`} tone={st.state === 'timeout' ? 'warn' : st.state === 'done' ? 'success' : 'info'} message={st.text} /> : null}
      {st && st.state === 'timeout' && onByHand ? <Btn testID={`${testID}-by-hand`} title="Balance by hand" icon="✍️" size="md" variant="secondary" onPress={onByHand} /> : null}
    </Card></View>
  );
}
