// v3.9.5 Aronium purchases against the supplier invoices in the app (one tap opens the invoice).
import React, { useState } from 'react';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Chips, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { ListItem, Hint, Stats } from '../../ui/kit.js';
import { dateStr, addDays, money } from '../../services/core.js';
import { purchasesCheck } from './purchasesCheck.js';

export function PurchasesCheckScreen() {
  const { nav, can } = useApp();
  const [range, setRange] = useState('60');
  const r = purchasesCheck({ from: addDays(dateStr(), -Number(range)) });
  return (
    <Screen title="Aronium purchases vs invoices" subtitle="Stock taken in on the till PCs, matched to the invoices in the app">
      <Hint>Every purchase typed in Aronium should have its supplier invoice in the app (Receive goods & invoice). A purchase with no invoice usually means the invoice never reached the office – find the paper and photograph it.</Hint>
      <Chips value={range} onChange={setRange} testIDPrefix="arp-r" options={[{ value: '14', label: '2 weeks' }, { value: '60', label: '2 months' }, { value: '180', label: '6 months' }]} />
      <Stats items={[{ label: 'Matched', value: String(r.matched.length), color: C.success }, { label: 'No invoice in the app', value: String(r.missing.length), color: r.missing.length ? C.danger : undefined }, { label: 'Total differs', value: String(r.differ.length), color: r.differ.length ? C.warn : undefined }, { label: 'Not in Aronium', value: String(r.notInAronium.length), color: r.notInAronium.length ? C.warn : undefined }]} />
      {r.missing.length ? (
        <Section title="No invoice in the app">
          {r.missing.map((p) => <ListItem key={`${p.shop}-${p.id}`} testID={`arp-miss-${p.id}`} title={`${p.supplier || 'Supplier ?'} · Aronium ${p.number}${p.reference ? ` (ref ${p.reference})` : ''}`} sub={`${p.date} · ${p.shop}`} right={money(p.total)} tone="danger"
            onPress={can('snap_upload') || can('po_receive') ? () => nav.push('ReceiveGoods', { shopCode: p.shop }) : null} />)}
        </Section>
      ) : null}
      {r.notInAronium.length ? (
        <Section title="Invoice in the app, not entered in Aronium">
          <Hint>{`Invoices from suppliers that are normally entered in Aronium, ${2} days or more old, with no Aronium purchase yet. Enter them in Aronium with the supplier's invoice number.`}</Hint>
          {r.notInAronium.map((i) => <ListItem key={i.uid} testID={`arp-notin-${i.uid}`} title={`${i.supplier_name} · invoice ${i.invoice_no || '(no number)'}`} sub={`${i.invoice_date}${i.shop_code ? ` · ${i.shop_code}` : ''}`} right={money(i.total)} tone="warn" onPress={() => nav.push('ApInvoice', { uid: i.uid })} />)}
        </Section>
      ) : null}
      {r.differ.length ? (
        <Section title="Total differs from the invoice">
          {r.differ.map((m) => <ListItem key={`${m.shop}-${m.id}`} title={`${m.supplier} · invoice ${m.invoice.invoice_no || '(no number)'}`} sub={`${m.date} · Aronium ${money(m.total)} · app ${money(m.invoice.total)}`} right={money(m.diff)} tone="warn" onPress={() => nav.push('ApInvoice', { uid: m.invoice.uid })} />)}
        </Section>
      ) : null}
      <Section title={`Matched (${r.matched.length})`}>
        {!r.matched.length ? <Text style={{ color: C.sub }}>None yet. Purchases come in when the till PCs send them (Aronium link).</Text> : null}
        {r.matched.slice(0, 100).map((m) => <ListItem key={`${m.shop}-${m.id}`} title={`${m.supplier} · invoice ${m.invoice.invoice_no || '(no number)'}`} sub={`${m.date} · ${m.shop} · matched by ${m.how}`} right={money(m.total)} onPress={() => nav.push('ApInvoice', { uid: m.invoice.uid })} />)}
      </Section>
    </Screen>
  );
}
