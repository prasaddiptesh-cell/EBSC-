// 1.0.0 Aronium module: the one Aronium place (till PCs, live receipts with their items, items sold, End of days,
// cash in each till now, Link events, customer refunds, products to fix in Aronium). Aronium is only read.
// Screens other streams point at:
//   AroniumHub  – the hub (Office › Records › Aronium)                       params: { tab?, shop? }
//   ArReceipts  – find a receipt; { pick: 'refund' } for Something happened › Customer refund
//   ArReceipt   – one receipt                                                  params: { key, refund? }
//   ArItems     – items sold by day / shift / till                             params: { date?, shop?, by? }
//   ArProducts  – products from Aronium: what to fix there, changes, the margin rule  params: { tab?, kind? }
// The Aronium link status (AroniumLink), insights and purchases check stay registered in the admin module.
import { AroniumHubScreen, ArReceiptsScreen, ArReceiptScreen, ArItemsScreen, ArProductsScreen } from './AroniumScreens.js';
import { canSeeAronium, canSeeReceipts, aroniumAlerts } from './receipts.js';
import { can, actsAsOwner } from '../../services/access.js';
import { PERIOD_REPORTS } from './periodReports.js'; // 1.0.0 Aronium reports for any period

const products = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || can(u, 'inventory_manage') || can(u, 'inventory_view') || canSeeAronium(u));
export default {
  id: 'aronium',
  title: 'Aronium',
  icon: '🧾',
  screens: {
    AroniumHub: { component: AroniumHubScreen, can: canSeeAronium },
    ArReceipts: { component: ArReceiptsScreen, can: canSeeReceipts },
    ArReceipt: { component: ArReceiptScreen, can: canSeeReceipts },
    ArItems: { component: ArItemsScreen, can: canSeeAronium },
    ArProducts: { component: ArProductsScreen, can: products },
  },
  menu: [
    { section: 'Records', items: [
      { id: 'ar-hub', icon: '🧾', title: 'Aronium – sales & receipts', note: 'Till PCs, live receipts with what was sold, items sold, End of days, cash in each till.', screen: 'AroniumHub' },
      { id: 'ar-products', icon: '🏷️', title: 'Products from Aronium – what to fix', note: 'Below cost, low margin, no tax, no barcode, prices that differ between the shops.', screen: 'ArProducts' },
    ] },
  ],
  alerts: (user) => aroniumAlerts(user),
  reports: PERIOD_REPORTS,
};
