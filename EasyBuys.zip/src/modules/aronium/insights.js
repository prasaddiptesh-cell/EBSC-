// v3.9.4 Aronium insights: what the till PCs' figures say beyond the daily sales.
//   1. Busy hours    – sales by hour for each weekday (for rosters, opening hours, restocking)
//   2. Reorder       – the app's own stock list (Aronium sales are booked into it) turned into draft orders per supplier
//   3. Cashier watch – refunds, voids and discounts per cashier, unusual ones flagged
//   4. Price check   – the same product at different prices on different tills, and sold below cost
//   5. Slow movers   – stock that has not sold for 30 / 60 / 90 days, with its value
// Read only (except "make the draft orders", which uses the normal purchase-order rules). Everything is guarded: no
// figures yet → empty lists, never an error.
import { db } from '../../db/connection.js';
import { dateStr, addDays } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const SHOP_OF = (source) => txt(source).split('-')[0];
export const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dow = (d) => new Date(`${d}T12:00:00`).getDay();
const hourLabel = (h) => { const n = Number(h); const ap = n < 12 ? 'am' : 'pm'; return `${n % 12 || 12}${ap}`; };
export { hourLabel };

// activity records (one per till per day): {date, hours: {"09": {value, receipts}}, cashiers: {name: {...}}}
function activity({ from, shop = '' }) {
  if (!has('aronium_feed')) return [];
  return db().all("SELECT source, period, data FROM aronium_feed WHERE kind = 'activity' AND period >= ? ORDER BY period", [from])
    .filter((r) => !shop || SHOP_OF(r.source) === shop)
    .map((r) => ({ source: r.source, shop: SHOP_OF(r.source), date: r.period, ...J(r.data, {}) }));
}

// ---------------------------------------------------------------- 1. busy hours
// Average sales per hour for each weekday over the last weeks (all tills of the shop added up per day).
export function busyHours({ shop = '', weeks = 8, today = dateStr() } = {}) {
  const from = addDays(today, -weeks * 7);
  const perDay = new Map(); // date → {hh: value}
  for (const a of activity({ from, shop })) {
    if (a.date >= today) continue; // today is not finished
    const d = perDay.get(a.date) || {};
    for (const [hh, x] of Object.entries(a.hours || {})) d[hh] = r2((d[hh] || 0) + Number(x.value || 0));
    perDay.set(a.date, d);
  }
  const hoursSeen = new Set();
  const byDow = DAYS.map(() => ({ n: 0, sum: {} }));
  for (const [date, hrs] of perDay) {
    const g = byDow[dow(date)];
    g.n += 1;
    for (const [hh, v] of Object.entries(hrs)) { g.sum[hh] = (g.sum[hh] || 0) + v; if (v > 0) hoursSeen.add(hh); }
  }
  const hours = [...hoursSeen].sort();
  let peak = null;
  const days = byDow.map((g, i) => {
    const avg = Object.fromEntries(hours.map((h) => [h, g.n ? r2((g.sum[h] || 0) / g.n) : 0]));
    for (const h of hours) if (!peak || avg[h] > peak.value) peak = { day: DAYS[i], hour: h, label: `${DAYS[i]} ${hourLabel(h)}–${hourLabel((Number(h) + 1) % 24)}`, value: avg[h] };
    const total = r2(Object.values(avg).reduce((s, v) => s + v, 0));
    const best = hours.reduce((b, h) => (avg[h] > (avg[b] ?? -1) ? h : b), hours[0]);
    return { dow: i, day: DAYS[i], samples: g.n, avg, total, busiest: best ? { hour: best, label: `${hourLabel(best)}–${hourLabel((Number(best) + 1) % 24)}`, value: avg[best] } : null };
  });
  return { shop, weeks, daysCounted: perDay.size, hours, labels: hours.map((h) => hourLabel(h)), days, peak: peak && peak.value > 0 ? peak : null };
}

// ---------------------------------------------------------------- 3. cashier watch
// Per cashier over the last days; flagged when refunds, voids or discounts are well above the rest of the team.
export function cashierWatch({ shop = '', days = 30, today = dateStr() } = {}) {
  const from = addDays(today, -days);
  const per = new Map();
  for (const a of activity({ from, shop })) {
    for (const [name, c] of Object.entries(a.cashiers || {})) {
      const k = `${a.shop}|${name}`;
      const o = per.get(k) || { name, shop: a.shop, sales: 0, receipts: 0, refunds: 0, refund_value: 0, discounts: 0, discount_value: 0, voids: 0, void_value: 0, days: new Set() };
      for (const f of ['sales', 'receipts', 'refunds', 'refund_value', 'discounts', 'discount_value', 'voids', 'void_value']) o[f] = r2(o[f] + Number(c[f] || 0));
      o.days.add(a.date);
      per.set(k, o);
    }
  }
  const list = [...per.values()].map((o) => ({ ...o, days: o.days.size }));
  const sum = (arr, f) => arr.reduce((s, x) => s + (Number(x[f]) || 0), 0);
  for (const o of list) {
    const team = list.filter((x) => x.shop === o.shop && x !== o);
    const rate = (n, d) => (d > 0 ? n / d : 0);
    const mine = { refund: rate(o.refunds, o.receipts), void: rate(o.voids, o.receipts), disc: rate(o.discount_value, o.sales) };
    const rest = { refund: rate(sum(team, 'refunds'), sum(team, 'receipts')), void: rate(sum(team, 'voids'), sum(team, 'receipts')), disc: rate(sum(team, 'discount_value'), sum(team, 'sales')) };
    o.refundPer100 = r2(mine.refund * 100);
    o.voidPer100 = r2(mine.void * 100);
    o.discountPct = r2(mine.disc * 100);
    o.flags = [];
    // well above the others (twice the team's rate, and a real number of times, not one odd day)
    if (o.refunds >= 3 && mine.refund > Math.max(2 * rest.refund, 0.01)) o.flags.push(`Refunds ${o.refundPer100} per 100 sales (others ${r2(rest.refund * 100)})`);
    if (o.voids >= 5 && mine.void > Math.max(2 * rest.void, 0.03)) o.flags.push(`Voids ${o.voidPer100} per 100 sales (others ${r2(rest.void * 100)})`);
    if (o.discounts >= 3 && mine.disc > Math.max(2 * rest.disc, 0.005)) o.flags.push(`Discounts ${o.discountPct}% of sales (others ${r2(rest.disc * 100)}%)`);
  }
  return list.sort((a, b) => b.flags.length - a.flags.length || b.sales - a.sales);
}

// ---------------------------------------------------------------- 4. price check
function productsBySource() {
  if (!has('aronium_feed')) return new Map();
  const out = new Map();
  const rows = db().all("SELECT source, part, parts, data FROM aronium_feed WHERE kind = 'products' ORDER BY source, part");
  const bySource = new Map();
  for (const r of rows) bySource.set(r.source, (bySource.get(r.source) || []).concat([r]));
  for (const [source, list] of bySource) {
    const parts = Math.max(...list.map((r) => Number(r.parts) || 1));
    if (list.length < parts) continue; // a part still on its way
    const items = list.filter((r) => Number(r.part) < parts).flatMap((r) => J(r.data, []));
    out.set(source, items);
  }
  return out;
}
export function priceCheck({ days = 30, today = dateStr() } = {}) {
  // a) different prices on different tills / shops
  const byCode = new Map();
  for (const [source, items] of productsBySource()) {
    for (const p of items) {
      if (p.enabled === false || p.service) continue;
      const k = txt(p.code).toUpperCase();
      if (!k) continue;
      const o = byCode.get(k) || { code: p.code, name: p.name, prices: [] };
      o.prices.push({ source, shop: SHOP_OF(source), price: r2(p.price), cost: Number(p.cost || 0) });
      byCode.set(k, o);
    }
  }
  const differ = [...byCode.values()].filter((o) => o.prices.length > 1 && Math.max(...o.prices.map((x) => x.price)) - Math.min(...o.prices.map((x) => x.price)) >= 0.01)
    .map((o) => ({ ...o, low: Math.min(...o.prices.map((x) => x.price)), high: Math.max(...o.prices.map((x) => x.price)) }))
    .sort((a, b) => (b.high - b.low) - (a.high - a.low));
  // b) sold below cost (selling price with VAT under the cost) in the last days
  const below = new Map();
  let L = null;
  try { L = require('./link.js'); } catch (e) { L = null; }
  const daysList = L ? L.aroniumSalesByDay({ from: addDays(today, -days), withLines: true }) : [];
  for (const d of daysList) {
    for (const l of d.lines || []) {
      const sold = Number(l.sold || 0);
      const net = Number(l.net || 0);
      if (!(sold > 0) || !(net > 0) || !(Number(l.cost) > 0)) continue;
      const unitSell = Number(l.sold_value || 0) / sold;
      const unitCost = Number(l.cost) / net;
      if (unitSell + 0.005 >= unitCost) continue;
      const k = `${d.shop}|${txt(l.code).toUpperCase()}`;
      const o = below.get(k) || { shop: d.shop, code: l.code, name: l.name, qty: 0, loss: 0, lowest: unitSell, cost: unitCost, last: '' };
      o.qty = r2(o.qty + sold);
      o.loss = r2(o.loss + (unitCost - unitSell) * sold);
      o.lowest = r2(Math.min(o.lowest, unitSell));
      o.cost = r2(unitCost);
      o.last = d.date > o.last ? d.date : o.last;
      below.set(k, o);
    }
  }
  return { differ, belowCost: [...below.values()].sort((a, b) => b.loss - a.loss) };
}

// ---------------------------------------------------------------- 2. reorder and 5. slow movers (the app's stock list)
function shopsList() {
  try { return db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY code'); } catch (e) { return []; }
}
export function reorderList({ shop } = {}) {
  let I;
  try { I = require('../inventory/service.js'); } catch (e) { return []; }
  const shops = shop ? [{ code: shop }] : shopsList();
  const out = [];
  for (const s of shops) {
    let rows = [];
    try { rows = I.stockList({ shopCode: s.code, filter: 'order', limit: 3000 }); } catch (e) { rows = []; }
    const groups = new Map();
    for (const r of rows) {
      const k = r.supplier_uid || '';
      const g = groups.get(k) || { shop: s.code, supplierUid: r.supplier_uid || null, supplier: r.supplier_name || 'No main supplier yet', items: [], total: 0 };
      g.items.push({ itemUid: r.uid, code: r.code, name: r.name, unit: r.unit, have: r.on_hand, onOrder: r.on_order, perWeek: r.perWeek, daysLeft: r.daysLeft, qty: r.suggest, unitCost: r.cost });
      g.total = r2(g.total + r.suggest * (Number(r.cost) || 0));
      groups.set(k, g);
    }
    out.push(...[...groups.values()].sort((a, b) => (a.supplierUid ? 0 : 1) - (b.supplierUid ? 0 : 1) || b.total - a.total));
  }
  return out;
}
// One draft order per supplier (still approved and sent as usual). Products without a main supplier are left out.
export function makeDraftOrders(user, { shop, supplierUids } = {}) {
  requirePerm(user, 'po_create'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const I = require('../inventory/service.js');
  const made = [];
  for (const g of reorderList({ shop })) {
    if (!g.supplierUid || (supplierUids && !supplierUids.includes(g.supplierUid))) continue;
    const lines = g.items.filter((x) => x.qty > 0).map((x) => ({ itemUid: x.itemUid, qty: x.qty, unitCost: x.unitCost }));
    if (!lines.length) continue;
    made.push(I.savePO(user, { supplierUid: g.supplierUid, shopCode: g.shop, lines, notes: 'Made from the reorder list (Aronium insights).' }));
  }
  return made;
  });
}
export function slowMovers({ shop, days = 30 } = {}) {
  let I;
  try { I = require('../inventory/service.js'); } catch (e) { return []; }
  const shops = shop ? [{ code: shop }] : shopsList();
  const out = [];
  for (const s of shops) {
    let rows = [];
    try { rows = I.stockList({ shopCode: s.code, limit: 5000 }); } catch (e) { rows = []; }
    for (const r of rows) {
      if (!(r.on_hand > 0)) continue;
      const idle = r.idleDays === null || r.idleDays === undefined ? Infinity : r.idleDays;
      if (idle < days) continue;
      out.push({ shop: s.code, itemUid: r.uid, code: r.code, name: r.name, have: r.on_hand, value: r.value, lastSale: r.last_sale || '', idleDays: idle === Infinity ? null : idle,
        band: idle >= 90 ? '90+' : idle >= 60 ? '60–89' : '30–59' });
    }
  }
  return out.sort((a, b) => b.value - a.value);
}

// ---------------------------------------------------------------- the short version (Home and the online dashboard)
export function insightSummary({ today = dateStr() } = {}) {
  const out = { cashierFlags: [], belowCost: [], priceDiffer: 0, reorderGroups: 0, slowValue: 0, peak: null };
  try { out.cashierFlags = cashierWatch({ today }).filter((c) => c.flags.length); } catch (e) { /* none */ }
  try { const p = priceCheck({ today, days: 14 }); out.belowCost = p.belowCost; out.priceDiffer = p.differ.length; } catch (e) { /* none */ }
  try { out.peak = busyHours({ today }).peak; } catch (e) { /* none */ }
  return out;
}
