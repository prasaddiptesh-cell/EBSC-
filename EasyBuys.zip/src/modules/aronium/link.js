// The Aronium link (v3.9.4): each till PC runs "Easy Buys Aronium Link", which only READS its Aronium database and
// sends records to the cloud (table aronium_feed, one row per till / kind / day / part). Every device receives them;
// the main tablet turns them into the app's own records:
//   products & prices (with VAT, barcodes)   → the product list of that shop (same as the Aronium CSV import)
//   suppliers                                 → suppliers (matched by TIN, then name)
//   sales per product per day                 → stock moves, all tills of a shop added up (one line per product per day)
//   End of day (Z) per till                   → Aronium End of day, matched to the till balance
// Staff credit becomes the "Who owes us" balances (v3.9.4). Stock, purchases and the health check stay in the feed to be looked at.
// Every step can run again without doubling anything (fixed ids; work done is remembered by its fingerprint).
import { db, withSystem } from '../../db/connection.js';
import { stamp, dateStr, deviceId, getSetting, setSetting, getShared } from '../../services/core.js';
import { importProductsCsv, findItem, findItemByName, putSale } from '../inventory/service.js';
import { importSuppliersCsv } from '../inventory/aronium.js';
import { putLinkedEod } from '../till/eod.js';

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const LINK_SQL = `
CREATE TABLE IF NOT EXISTS aronium_feed (
  uid TEXT PRIMARY KEY,
  source TEXT NOT NULL, shop_code TEXT NOT NULL, till TEXT,
  kind TEXT NOT NULL, period TEXT NOT NULL, part INTEGER NOT NULL DEFAULT 0, parts INTEGER NOT NULL DEFAULT 1,
  data TEXT, hash TEXT, made_at TEXT, bridge_version TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'synced'
);
CREATE INDEX IF NOT EXISTS idx_aronium_feed_kind ON aronium_feed (kind, shop_code, period);
CREATE TABLE IF NOT EXISTS aronium_link_done (
  key TEXT PRIMARY KEY, hash TEXT NOT NULL, done_at TEXT NOT NULL, note TEXT, waiting INTEGER NOT NULL DEFAULT 0
);
`;
export const LINK_SYNC = {
  aronium_feed: SYNC('uid', 'Aronium link', ['uid', 'source', 'shop_code', 'till', 'kind', 'period', 'part', 'parts', 'data', 'hash', 'made_at', 'bridge_version']),
};

const LINK_USER = { uid: 'aronium-link', name: 'Aronium link', role: 'system' };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'aronium_feed'"); } catch (e) { return false; } };
const csvCell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const csv = (rows) => rows.map((r) => r.map(csvCell).join(',')).join('\n');
export const SHOP_OF = (source) => txt(source).split('-')[0];

// Only one device turns the feed into records: the main tablet (or, before one is chosen, the device holding the cloud key).
export function isLinkDevice() {
  const main = getShared('main_tablet_device', '');
  return main ? main === deviceId() : !!getSetting('cloud_key', '');
}

// ---------------------------------------------------------------- reading the feed
function rowsOf(kind, where = '', args = []) {
  return db().all(`SELECT * FROM aronium_feed WHERE kind = ? ${where} ORDER BY source, period, part`, [kind].concat(args));
}
// All parts of one list from one till, or null while a part is still on its way.
function wholeList(rows) {
  if (!rows.length) return null;
  const parts = Math.max(...rows.map((r) => Number(r.parts) || 1));
  const byPart = new Map(rows.map((r) => [Number(r.part) || 0, r]));
  const out = [];
  for (let i = 0; i < parts; i += 1) {
    const r = byPart.get(i);
    if (!r) return null;
    const d = J(r.data, []);
    if (Array.isArray(d)) out.push(...d);
    else if (d && Array.isArray(d.rows)) out.push(...d.rows.map((x) => (Array.isArray(x) ? Object.fromEntries(d.cols.map((c, k) => [c, x[k]])) : x)));
  }
  return { items: out, hash: [...byPart.entries()].filter(([i]) => i < parts).map(([, r]) => r.hash).join('.') };
}
const done = (key) => db().get('SELECT * FROM aronium_link_done WHERE key = ?', [key]);
function markDone(key, hash, note = '', waiting = 0) {
  db().run(`INSERT INTO aronium_link_done (key, hash, done_at, note, waiting) VALUES (?,?,?,?,?)
    ON CONFLICT(key) DO UPDATE SET hash = excluded.hash, done_at = excluded.done_at, note = excluded.note, waiting = excluded.waiting`, [key, hash, stamp(), note || null, waiting ? 1 : 0]);
}
const sources = () => db().all('SELECT DISTINCT source FROM aronium_feed ORDER BY source').map((r) => r.source);
// The till whose product list and suppliers are used for a shop (the lowest till number that has sent them).
function primarySource(shop, kind) {
  return db().get('SELECT source FROM aronium_feed WHERE kind = ? AND shop_code = ? ORDER BY source LIMIT 1', [kind, shop])?.source || null;
}

// ---------------------------------------------------------------- products, suppliers
function doProducts(shop, out) {
  const src = primarySource(shop, 'products');
  if (!src) return false;
  const list = wholeList(rowsOf('products', 'AND source = ?', [src]));
  if (!list) return false;
  const key = `products|${shop}`;
  if (done(key)?.hash === list.hash) return false;
  const anyVat = list.items.some((p) => p.vat_rate !== null && p.vat_rate !== undefined);
  const head = ['Code', 'Name', 'Barcode', 'Group', 'Unit', 'Cost', 'Price', 'Active', 'Is service'].concat(anyVat ? ['Tax'] : []);
  const body = list.items.filter((p) => txt(p.name)).map((p) => [txt(p.code), txt(p.name), (p.barcodes || []).join(','), p.group || '', p.unit || '', p.cost ?? '', p.price ?? '',
    p.enabled === false ? 'no' : 'yes', p.service ? 'yes' : 'no'].concat(anyVat ? [Number(p.vat_rate) > 0 ? `VAT ${p.vat_rate}%` : '0%'] : []));
  if (!body.length) { markDone(key, list.hash, 'empty list'); return false; }
  const r = importProductsCsv(LINK_USER, csv([head].concat(body)), { shopCode: shop, setShopPrice: true });
  markDone(key, list.hash, `${r.added} new, ${r.changed} changed${r.errors.length ? `, ${r.errors.length} problems` : ''}`);
  out.push(`${shop} products: ${r.added} new, ${r.changed} changed`);
  return r.added + r.changed > 0;
}
function doSuppliers(shop, out) {
  const src = primarySource(shop, 'parties');
  if (!src) return;
  const list = wholeList(rowsOf('parties', 'AND source = ?', [src]));
  if (!list) return;
  const key = `parties|${shop}`;
  if (done(key)?.hash === list.hash) return;
  const sup = list.items.filter((p) => p.supplier && txt(p.name));
  if (sup.length) {
    const head = ['Name', 'Code', 'Tax number', 'Phone', 'Email', 'Address', 'Is supplier', 'Enabled'];
    const r = importSuppliersCsv(LINK_USER, csv([head].concat(sup.map((p) => [p.name, p.code, p.tin, p.phone, p.email, p.address, 'yes', p.enabled === false ? 'no' : 'yes']))));
    out.push(`${shop} suppliers: ${r.added} new, ${r.changed} changed`);
    markDone(key, list.hash, `${r.added} new, ${r.changed} changed`);
  } else markDone(key, list.hash, 'no suppliers');
}

// ---------------------------------------------------------------- sales: every till of a shop added up per product per day
function salesKeys(limit) {
  return db().all(`SELECT shop_code, period, GROUP_CONCAT(hash, '.') AS h FROM (SELECT shop_code, period, hash FROM aronium_feed WHERE kind = 'sales_day' ORDER BY source, part)
    GROUP BY shop_code, period ORDER BY period LIMIT ?`, [limit]);
}
function doSalesDay(shop, date, out) {
  const rows = rowsOf('sales_day', 'AND shop_code = ? AND period = ?', [shop, date]);
  const bySource = new Map();
  rows.forEach((r) => bySource.set(r.source, (bySource.get(r.source) || []).concat([r])));
  const total = new Map();
  const unknown = [];
  for (const list of bySource.values()) {
    const whole = wholeList(list);
    if (!whole) return { waiting: true, note: 'a part is still on its way' };
    for (const l of whole.items) {
      const k = `${txt(l.code).toUpperCase()}|${txt(l.name)}`;
      const t = total.get(k) || { code: txt(l.code), name: txt(l.name), net: 0, cost: 0 };
      t.net = q3(t.net + Number(l.net || 0));
      t.cost = r2(t.cost + Number(l.cost || 0));
      total.set(k, t);
    }
  }
  const put = new Set();
  let lines = 0;
  for (const t of total.values()) {
    const it = findItem(t.code) || findItemByName(t.name);
    if (!it) { if (unknown.length < 30) unknown.push(t.name || t.code); continue; }
    const unitCost = Math.abs(t.net) > 0.0005 && t.cost ? Math.abs(t.cost / t.net) : it.cost;
    putSale({ shopCode: shop, date, itemUid: it.uid, code: it.code, qty: t.net, unitCost, by: LINK_USER.name, signed: true, reason: 'Sales from Aronium (till PCs)' });
    put.add(`SL-${shop}-${date}-${it.code}`);
    lines += 1;
  }
  // A product sold earlier that day but now gone from Aronium's figures (a sale deleted there) goes back to 0.
  const prefix = `SL-${shop}-${date}-`;
  for (const m of db().all("SELECT uid, item_uid FROM inv_moves WHERE uid LIKE ? AND by_name = ? AND status = 'active' AND qty <> 0", [`${prefix}%`, LINK_USER.name])) {
    if (put.has(m.uid)) continue;
    putSale({ shopCode: shop, date, itemUid: m.item_uid, code: m.uid.slice(prefix.length), qty: 0, unitCost: 0, by: LINK_USER.name, signed: true, reason: 'Sales from Aronium (till PCs)' });
  }
  return { waiting: unknown.length > 0, note: `${lines} products${unknown.length ? `; not in the product list yet: ${unknown.slice(0, 5).join(', ')}${unknown.length > 5 ? '…' : ''}` : ''}` };
}

// ---------------------------------------------------------------- End of day per till
function doZ(row, out) {
  const key = `z|${row.uid}`;
  if (done(key)?.hash === row.hash) return;
  const z = J(row.data, null);
  if (!z || !z.date) { markDone(key, row.hash, 'empty'); return; }
  // An End of day worked out per day (older Aronium) is only final once the day is over.
  if (!z.z_id && z.date >= dateStr()) return;
  const r = putLinkedEod({ uid: `EOD-${row.source}-${z.key}`, shopCode: row.shop_code, tillName: row.till, date: z.date, zNumber: z.z_id ? z.number : '',
    total: z.total, vat: z.vat, zero: z.zero, cash: z.cash, card: z.card, other: z.other,
    note: `From ${row.till || row.source}: sales ${r2(z.sales)}, refunds ${r2(z.refunds)}, discounts ${r2(z.discounts)}, ${z.receipts || 0} receipts${z.voids && z.voids.count ? `, ${z.voids.count} voids ${r2(z.voids.total)}` : ''}${Object.keys(z.cashiers || {}).length ? `; cashiers: ${Object.keys(z.cashiers).join(', ')}` : ''}` });
  markDone(key, row.hash, r.added ? 'added' : r.typed ? 'already typed by hand' : 'already there');
  if (r.added) out.push(`End of day ${z.number || z.date} ${row.till || row.source}`);
}

// ---------------------------------------------------------------- one round (called after each sync on the main tablet)
// limit: how many sales days are worked per round (the very first time there can be hundreds).
export function processLink({ limit = 40, force = false } = {}) {
  if (!has() || (!force && !isLinkDevice())) return { skipped: true };
  const out = [];
  const errors = [];
  const step = (name, fn) => { try { withSystem(fn); } catch (e) { errors.push(`${name}: ${e.message || e}`); } };
  const shops = db().all('SELECT DISTINCT shop_code FROM aronium_feed').map((r) => r.shop_code);
  let productsChanged = false;
  for (const shop of shops) {
    step(`${shop} products`, () => { if (doProducts(shop, out)) productsChanged = true; });
    step(`${shop} suppliers`, () => doSuppliers(shop, out));
  }
  // New products may make earlier sales lines known: those days are worked again.
  if (productsChanged) step('recheck', () => db().run('DELETE FROM aronium_link_done WHERE waiting = 1 AND key LIKE ?', ['sales|%']));
  // New or renamed products: the app marks the ones on the FCCC list as controlled (and watches them).
  if (productsChanged) step('FCCC', () => {
    const F = require('../inventory/fccc.js');
    const r = F.autoLinkFccc();
    if (r.linked && r.linked.length) out.push(`${r.linked.length} product(s) marked FCCC-controlled – confirm in FCCC controlled prices`);
    const v = F.autoReview(); // new prices from Aronium: the FCCC list may now be fine (or not)
    if (v.ticked) out.push(`FCCC: ${v.ticked} list(s) ticked – every controlled price is within the FCCC price`);
  });
  let worked = 0;
  for (const k of salesKeys(100000)) {
    if (worked >= limit) break;
    const key = `sales|${k.shop_code}|${k.period}`;
    if (done(key)?.hash === k.h) continue;
    worked += 1;
    try {
      withSystem(() => {
        const r = doSalesDay(k.shop_code, k.period, out);
        if (r.note !== 'a part is still on its way') markDone(key, k.h, r.note, r.waiting);
      });
    } catch (e) {
      // e.g. the month is locked: noted once, not tried again until Aronium's figures for that day change.
      errors.push(`sales ${k.shop_code} ${k.period}: ${e.message || e}`);
      try { withSystem(() => markDone(key, k.h, `not booked: ${e.message || e}`)); } catch (e2) { /* next round */ }
    }
  }
  for (const row of rowsOf('z')) step(`End of day ${row.period}`, () => doZ(row, out));
  step('test answers', () => answerPings(out));
  // v3.9.4 staff credit (what staff owe on Aronium's customer accounts), all tills added up per person
  step('staff credit', () => {
    if (!db().get("SELECT 1 AS x FROM aronium_feed WHERE kind = 'credit' LIMIT 1")) return;
    const per = new Map();
    for (const c of aroniumCredit()) {
      const k = txt(c.name).toLowerCase();
      if (!k) continue;
      const o = per.get(k) || { name: txt(c.name), code: null, balance: 0, since: null };
      o.balance = r2(o.balance + Number(c.owing || 0));
      if (c.oldest && (!o.since || c.oldest < o.since)) o.since = c.oldest;
      per.set(k, o);
    }
    const r = require('../owed/service.js').syncCreditFromLink([...per.values()]);
    if (r.changed) out.push(`Staff credit from Aronium: ${r.people || 0} people`);
  });
  const left = salesKeys(100000).filter((k) => done(`sales|${k.shop_code}|${k.period}`)?.hash !== k.h).length;
  setSetting('aronium_link_last', JSON.stringify({ at: stamp(), did: out.slice(0, 20), errors: errors.slice(0, 10), left }));
  return { did: out, errors, left };
}

// The till program's "Test the app" button: it sends a test (kind 'ping'); the main tablet answers (kind 'pong') with
// the same number, which goes back up to the cloud, where the till program sees it.
function answerPings(out) {
  for (const p of rowsOf('ping')) {
    const ping = J(p.data, {});
    const uid = `${p.source}|pong|ping|0`;
    const have = db().get('SELECT data FROM aronium_feed WHERE uid = ?', [uid]);
    if (have && J(have.data, {}).nonce === ping.nonce) continue;
    let ver = '';
    try { ver = require('../../services/core.js').APP_VERSION; } catch (e) { ver = ''; }
    let name = '';
    try { name = require('../../services/core.js').deviceName(); } catch (e) { name = ''; }
    const data = JSON.stringify({ nonce: ping.nonce, at: new Date().toISOString(), device: name || 'Main tablet', app: ver, sentAt: ping.sent_at || '' });
    const now = new Date().toISOString();
    db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
      VALUES (?,?,?,?, 'pong', 'ping', 0, 1, ?, ?, ?, '', ?, ?, 'pending')
      ON CONFLICT(uid) DO UPDATE SET data = excluded.data, hash = excluded.hash, made_at = excluded.made_at, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [uid, p.source, p.shop_code, p.till, data, `pong-${ping.nonce}`, now, now, deviceId()]);
    out.push(`Answered the test from ${p.till || p.source}`);
  }
}

// What the till PCs already bring in by themselves (for the CSV screens): { on, ago, last } per kind.
export function linkCovers(kind) {
  if (!has()) return { on: false };
  const r = db().get('SELECT MAX(updated_at) AS t FROM aronium_feed WHERE kind = ?', [kind]);
  if (!r || !r.t) return { on: false };
  const s = String(r.t);
  const t = Date.parse(/Z$/.test(s) ? s : `${s.replace(' ', 'T').slice(0, 19)}Z`);
  const mins = Number.isFinite(t) ? Math.max(0, Math.round((Date.now() - t) / 60000)) : null;
  return { on: mins !== null && mins < 3 * 24 * 60, mins, last: s };
}

// ---------------------------------------------------------------- what the screens show
export function linkStatus() {
  if (!has()) return { tills: [], last: null, isLinkDevice: isLinkDevice() };
  const tills = sources().map((source) => {
    const meta = db().get("SELECT * FROM aronium_feed WHERE source = ? AND kind = 'meta' ORDER BY updated_at DESC LIMIT 1", [source]);
    const last = db().get("SELECT MAX(updated_at) AS t FROM aronium_feed WHERE source = ? AND kind <> 'pong'", [source]).t;
    const m = J(meta && meta.data, {});
    const lastZ = db().all("SELECT data FROM aronium_feed WHERE source = ? AND kind = 'z'", [source]).map((r) => J(r.data, {})).sort((a, b) => txt(b.closed_at || b.date).localeCompare(txt(a.closed_at || a.date)))[0] || null;
    return { source, shop: SHOP_OF(source), till: (meta && meta.till) || source, lastSeen: last, version: meta ? meta.bridge_version : '', counts: m.counts || {}, notes: m.notes || [],
      lastZ: lastZ ? { number: lastZ.number, date: lastZ.date, total: lastZ.total } : null };
  });
  const pending = db().get("SELECT COUNT(*) AS n FROM aronium_link_done WHERE waiting = 1").n;
  const notes = db().all("SELECT key, note FROM aronium_link_done WHERE waiting = 1 ORDER BY key DESC LIMIT 10");
  return { tills, last: J(getSetting('aronium_link_last', ''), null), isLinkDevice: isLinkDevice(), waiting: pending, waitingNotes: notes };
}
// Aronium's own stock figures for a shop (each till's database keeps its own; they are shown, never booked).
export function aroniumStock(shop) {
  if (!has()) return [];
  const out = new Map();
  for (const s of sources().filter((x) => SHOP_OF(x) === shop)) {
    const w = wholeList(rowsOf('stock', 'AND source = ?', [s]));
    if (!w) continue;
    for (const x of w.items) {
      const k = txt(x.code).toUpperCase();
      const o = out.get(k) || { code: x.code, qty: 0, tills: [] };
      o.qty = q3(o.qty + Number(x.qty || 0));
      o.tills.push(s);
      out.set(k, o);
    }
  }
  return [...out.values()];
}
// What staff owe on Aronium's books (customer accounts), per till.
export function aroniumCredit() {
  if (!has()) return [];
  return sources().flatMap((s) => (wholeList(rowsOf('credit', 'AND source = ?', [s]))?.items || []).map((c) => ({ ...c, source: s })))
    .sort((a, b) => b.owing - a.owing);
}
// Purchases typed in Aronium (to match with supplier invoices in the app).
export function aroniumPurchases({ from = '' } = {}) {
  if (!has()) return [];
  return db().all("SELECT * FROM aronium_feed WHERE kind = 'purchases' AND period >= ? ORDER BY period DESC", [from])
    .flatMap((r) => J(r.data, []).map((p) => ({ ...p, source: r.source, shop: r.shop_code })));
}
// Sales per shop and till per day (for the dashboard and reports): {date, shop, source, value, units}.
export function aroniumSalesByDay({ from = '', withLines = false } = {}) {
  if (!has()) return [];
  const out = [];
  const groups = new Map();
  for (const r of db().all("SELECT * FROM aronium_feed WHERE kind = 'sales_day' AND period >= ? ORDER BY source, period, part", [from])) {
    const k = `${r.source}|${r.period}`;
    groups.set(k, (groups.get(k) || []).concat([r]));
  }
  for (const [k, rows] of groups) {
    const w = wholeList(rows);
    if (!w) continue;
    const [source, date] = k.split('|');
    out.push({ date, shop: SHOP_OF(source), source, value: r2(w.items.reduce((s, l) => s + Number(l.sold_value || 0) - Number(l.refund_value || 0), 0)),
      units: q3(w.items.reduce((s, l) => s + Number(l.net || 0), 0)), cost: r2(w.items.reduce((s, l) => s + Number(l.cost || 0), 0)),
      ...(withLines ? { lines: w.items } : {}) });
  }
  return out;
}
// Each End of day sent by the till PCs from a day on (for the dashboard): receipts, refunds, voids, payments …
export function aroniumZByDay({ from = '' } = {}) {
  if (!has()) return [];
  let rows;
  try { rows = db().all("SELECT source, shop_code, till, data FROM aronium_feed WHERE kind = 'z' AND json_extract(data, '$.date') >= ?", [from]); } catch (e) {
    rows = db().all("SELECT source, shop_code, till, data FROM aronium_feed WHERE kind = 'z'"); // no JSON support on this device
  }
  return rows.map((r) => ({ ...J(r.data, {}), source: r.source, shop: r.shop_code, till: r.till })).filter((z) => z.date && z.date >= from);
}
