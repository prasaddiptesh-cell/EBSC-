// The Aronium link (v3.9.4): each till PC runs "Easy Buys Aronium Link", which only READS its Aronium database and
// sends records to the cloud (table aronium_feed, one row per till / kind / day / part). Every device receives them;
// the main tablet turns them into the app's own records:
//   products & prices (with VAT, barcodes)   → the product list of that shop (same as the Aronium CSV import)
//   suppliers                                 → suppliers (matched by TIN, then name)
//   sales per product per day                 → stock moves, all tills of a shop added up (one line per product per day)
//   End of day (Z) per till                   → Aronium End of day, matched to the till balance
// Staff credit becomes the "Who owes us" balances (v3.9.4). Stock, purchases and the health check stay in the feed to be looked at.
// Every step can run again without doubling anything (fixed ids; work done is remembered by its fingerprint).
import { db, withSystem, keepUntilChanged, keepTracked, noteDeps, probeDep, untracked } from '../../db/connection.js';
import { stamp, dateStr, deviceId, getSetting, setSetting, getShared } from '../../services/core.js';
import { importProductsCsv, findItem, findItemByName, putSale } from '../inventory/service.js';
import { importSuppliersCsv } from '../inventory/aronium.js';
import { putLinkedEod } from '../till/eod.js';

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const LINK_SQL = `
CREATE TABLE IF NOT EXISTS aronium_feed (
  uid TEXT PRIMARY KEY,
  source TEXT NOT NULL, shop_code TEXT NOT NULL, till TEXT,
  kind TEXT NOT NULL, period TEXT NOT NULL, part INTEGER NOT NULL DEFAULT 0, parts INTEGER NOT NULL DEFAULT 1,
  data TEXT, hash TEXT, made_at TEXT, bridge_version TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'synced'
);
CREATE INDEX IF NOT EXISTS idx_aronium_feed_kind ON aronium_feed (kind, shop_code, period);
CREATE TABLE IF NOT EXISTS aronium_link_done (
  key TEXT PRIMARY KEY, hash TEXT NOT NULL, done_at TEXT NOT NULL, note TEXT, waiting INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS aronium_refunds (
  uid TEXT PRIMARY KEY,
  receipt_key TEXT NOT NULL, source TEXT, shop_code TEXT, receipt_date TEXT, receipt_no TEXT, receipt_time TEXT, total REAL,
  done_in_aronium INTEGER NOT NULL DEFAULT 0, reason TEXT, note TEXT, items TEXT,
  by_uid TEXT, by_name TEXT, at TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_aronium_refunds_key ON aronium_refunds (receipt_key);
`;
export const LINK_SYNC = {
  aronium_feed: SYNC('uid', 'Aronium link', ['uid', 'source', 'shop_code', 'till', 'kind', 'period', 'part', 'parts', 'data', 'hash', 'made_at', 'bridge_version']),
  // 1.0.0 customer refunds noted by staff against the Aronium receipt (the refund itself is done in Aronium)
  aronium_refunds: SYNC('uid', 'Aronium link', ['uid', 'receipt_key', 'source', 'shop_code', 'receipt_date', 'receipt_no', 'receipt_time', 'total', 'done_in_aronium', 'reason', 'note', 'items', 'by_uid', 'by_name', 'at']),
};

const LINK_USER = { uid: 'aronium-link', name: 'Aronium link', role: 'system' };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'aronium_feed'"); } catch (e) { return false; } };
const csvCell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const csv = (rows) => rows.map((r) => r.map(csvCell).join(',')).join('\n');
export const SHOP_OF = (source) => txt(source).split('-')[0];

// Only one device at a time turns the feed into products, suppliers, staff credit and FCCC marks and answers the till's
// test. 1.0.0 build 10: whichever linked device holds the "link" job in the cloud (services/jobLease.js) – any device,
// the main tablet first; offline, only the device chosen as main.
export function isLinkDevice() {
  return require('../../services/jobLease.js').mayDoJob('link');
}
// This device has the whole data (bank, account and TIN fields): an admin device, the main one, or not linked at all.
export function fullCopy() {
  if (!getSetting('cloud_url', '')) return true;
  if (getSetting('device_is_admin', '') === '1') return true;
  try { return require('../../services/jobLease.js').explicitMain(); } catch (e) { return false; }
}

// ---------------------------------------------------------------- reading the feed
function rowsOf(kind, where = '', args = []) {
  return db().all(`SELECT * FROM aronium_feed WHERE kind = ? ${where} ORDER BY source, period, part`, [kind].concat(args));
}
// All parts of one list from one till, or null while a part is still on its way.
// partial: for the live receipts list, use the pieces that have come so far (a long day comes in several pieces and a
// missing one used to blank the whole list - owner, 2 Nov: Sales today $0.00 while the till had sold $1,458)
function wholeList(rows, partial = false) {
  if (!rows.length) return null;
  const parts = Math.max(...rows.map((r) => Number(r.parts) || 1));
  const byPart = new Map(rows.map((r) => [Number(r.part) || 0, r]));
  const out = [];
  for (let i = 0; i < parts; i += 1) {
    const r = byPart.get(i);
    if (!r) { if (partial) continue; return null; }
    const d = J(r.data, []);
    if (Array.isArray(d)) out.push(...d);
    else if (d && Array.isArray(d.rows)) out.push(...d.rows.map((x) => (Array.isArray(x) ? Object.fromEntries(d.cols.map((c, k) => [c, x[k]])) : x)));
  }
  return { items: out, hash: [...byPart.entries()].filter(([i]) => i < parts).map(([, r]) => r.hash).join('.') };
}
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
// Release 31: is a till's products list (or another list) whole here? → { have, parts, at, complete, note }
export function listState(source, kind = 'products') {
  const rows = safe(() => db().all("SELECT part, parts, updated_at FROM aronium_feed WHERE source = ? AND kind = ? AND period = 'all'", [source, kind]), []);
  if (!rows.length) return null;
  const parts = Math.max(...rows.map((r) => Number(r.parts) || 1));
  const have = new Set(rows.map((r) => Number(r.part) || 0).filter((p) => p < parts)).size;
  const at = rows.map((r) => String(r.updated_at || '')).sort().pop() || '';
  const shop = safe(() => db().get('SELECT shop_code FROM aronium_feed WHERE source = ? LIMIT 1', [source]).shop_code, '');
  const d = safe(() => done(`${kind}|${shop}`), null);
  return { have, parts, at, complete: have >= parts, note: d ? `${d.note || ''} (${String(d.done_at || '').slice(0, 16)})` : '' };
}
const done = (key) => db().get('SELECT * FROM aronium_link_done WHERE key = ?', [key]);
function markDone(key, hash, note = '', waiting = 0) {
  db().run(`INSERT INTO aronium_link_done (key, hash, done_at, note, waiting) VALUES (?,?,?,?,?)
    ON CONFLICT(key) DO UPDATE SET hash = excluded.hash, done_at = excluded.done_at, note = excluded.note, waiting = excluded.waiting`, [key, hash, stamp(), note || null, waiting ? 1 : 0]);
}
const sources = () => db().all('SELECT DISTINCT source FROM aronium_feed ORDER BY source').map((r) => r.source);
// The till whose product list and suppliers are used for a shop (the lowest till number that has sent them).
function primarySource(shop, kind) {
  return db().get('SELECT source FROM aronium_feed WHERE kind = ? AND shop_code = ? ORDER BY source LIMIT 1', [kind, shop])?.source || null;
}

// ---------------------------------------------------------------- products, suppliers
function doProducts(shop, out) {
  const src = primarySource(shop, 'products');
  if (!src) return false;
  const list = wholeList(rowsOf('products', 'AND source = ?', [src]));
  if (!list) return false;
  const key = `products|${shop}`;
  if (done(key)?.hash === list.hash) return false;
  // v3.9.8 every change in Aronium is kept (prices, cost, tax, names, barcodes, new / disabled / removed).
  try { require('../../services/productWatch.js').watchProducts(shop, list.items); } catch (e) { /* the import still runs */ }
  const anyVat = list.items.some((p) => p.vat_rate !== null && p.vat_rate !== undefined);
  const head = ['Code', 'Name', 'Barcode', 'Group', 'Unit', 'Cost', 'Price', 'Active', 'Is service'].concat(anyVat ? ['Tax'] : []);
  const body = list.items.filter((p) => txt(p.name)).map((p) => [txt(p.code), txt(p.name), (p.barcodes || []).join(','), p.group || '', p.unit || '', p.cost ?? '', p.price ?? '',
    p.enabled === false ? 'no' : 'yes', p.service ? 'yes' : 'no'].concat(anyVat ? [p.vat_rate === null || p.vat_rate === undefined ? 'None set' : Number(p.vat_rate) > 0 ? `VAT ${p.vat_rate}%` : '0%'] : []));
  // v3.9.7 a product with no tax at all in Aronium is "None set" (not 0%): the app flags it to be set in Aronium.
  if (!body.length) { markDone(key, list.hash, 'empty list'); return false; }
  const r = require('../../services/guard.js').asService(() => importProductsCsv(LINK_USER, csv([head].concat(body)), { shopCode: shop, setShopPrice: true })); // the link's own work
  markDone(key, list.hash, `${r.added} new, ${r.changed} changed${r.errors.length ? `, ${r.errors.length} problems` : ''}`);
  out.push(`${shop} products: ${r.added} new, ${r.changed} changed`);
  // 1.0.0 supplier products from the invoices that were waiting for their product link up now
  if (r.added + r.changed) { try { const m = require('../inventory/supplierCatalog.js').matchCatalog(); if (m.linked) out.push(`supplier products linked: ${m.linked}`); } catch (e) { /* only a convenience */ } }
  return r.added + r.changed > 0;
}
function doSuppliers(shop, out) {
  const src = primarySource(shop, 'parties');
  if (!src) return;
  const list = wholeList(rowsOf('parties', 'AND source = ?', [src]));
  if (!list) return;
  const key = `parties|${shop}`;
  if (done(key)?.hash === list.hash) return;
  const sup = list.items.filter((p) => p.supplier && txt(p.name));
  if (sup.length) {
    const head = ['Name', 'Code', 'Tax number', 'Phone', 'Email', 'Address', 'Is supplier', 'Enabled'];
    const r = require('../../services/guard.js').asService(() => importSuppliersCsv(LINK_USER, csv([head].concat(sup.map((p) => [p.name, p.code, p.tin, p.phone, p.email, p.address, 'yes', p.enabled === false ? 'no' : 'yes']))))); // the link's own work
    out.push(`${shop} suppliers: ${r.added} new, ${r.changed} changed`);
    markDone(key, list.hash, `${r.added} new, ${r.changed} changed`);
  } else markDone(key, list.hash, 'no suppliers');
}

// ---------------------------------------------------------------- sales: every till of a shop added up per product per day
function salesKeys(limit) {
  return db().all(`SELECT shop_code, period, GROUP_CONCAT(hash, '.') AS h FROM (SELECT shop_code, period, hash FROM aronium_feed WHERE kind = 'sales_day' ORDER BY source, part)
    GROUP BY shop_code, period ORDER BY period LIMIT ?`, [limit]);
}
function doSalesDay(shop, date, out) {
  const rows = rowsOf('sales_day', 'AND shop_code = ? AND period = ?', [shop, date]);
  const bySource = new Map();
  rows.forEach((r) => bySource.set(r.source, (bySource.get(r.source) || []).concat([r])));
  const total = new Map();
  const unknown = [];
  for (const list of bySource.values()) {
    const whole = wholeList(list);
    if (!whole) return { waiting: true, note: 'a part is still on its way' };
    for (const l of whole.items) {
      const k = `${txt(l.code).toUpperCase()}|${txt(l.name)}`;
      const t = total.get(k) || { code: txt(l.code), name: txt(l.name), net: 0, cost: 0 };
      t.net = q3(t.net + Number(l.net || 0));
      t.cost = r2(t.cost + Number(l.cost || 0));
      total.set(k, t);
    }
  }
  // 1.0.0 build 4: every till line that is the same app product is added up first (two tills may spell or code it
  // differently) – one sale record per product per day, never one till's figure replacing the other's.
  const byItem = new Map();
  const codes = new Set(); const names = new Set();
  for (const t of total.values()) {
    if (t.code) codes.add(t.code.toUpperCase());
    if (t.name) names.add(t.name.toLowerCase());
    const it = findItem(t.code) || findItemByName(t.name);
    if (!it) { if (unknown.length < 30) unknown.push(t.name || t.code); continue; }
    const o = byItem.get(it.uid) || { it, net: 0, cost: 0 };
    o.net = q3(o.net + t.net); o.cost = r2(o.cost + t.cost);
    byItem.set(it.uid, o);
  }
  const put = new Set();
  let lines = 0;
  for (const { it, net, cost } of byItem.values()) {
    const unitCost = Math.abs(net) > 0.0005 && cost ? Math.abs(cost / net) : it.cost;
    putSale({ shopCode: shop, date, itemUid: it.uid, code: it.code, qty: net, unitCost, by: LINK_USER.name, signed: true, reason: 'Sales from Aronium (till PCs)' });
    put.add(`SL-${shop}-${date}-${it.code}`);
    lines += 1;
  }
  // A product sold earlier that day but now gone from Aronium's figures (a sale deleted there) goes back to 0 – only
  // when its code AND name are really gone from that day's lines of every till, and every line is known on this device
  // (a device that does not know a product yet must never zero a sale another device booked).
  const prefix = `SL-${shop}-${date}-`;
  if (!unknown.length) {
    for (const m of db().all("SELECT uid, item_uid FROM inv_moves WHERE uid LIKE ? AND by_name = ? AND status = 'active' AND qty <> 0", [`${prefix}%`, LINK_USER.name])) {
      if (put.has(m.uid)) continue;
      const code = m.uid.slice(prefix.length);
      const it = findItem(code);
      if (codes.has(code.toUpperCase()) || (it && it.name && names.has(String(it.name).trim().toLowerCase()))) continue;
      putSale({ shopCode: shop, date, itemUid: it ? it.uid : m.item_uid, code, qty: 0, unitCost: 0, by: LINK_USER.name, signed: true, reason: 'Sales from Aronium (till PCs) – sale deleted in Aronium' });
    }
  }
  noteUnknown(shop, date, unknown);
  return { waiting: unknown.length > 0, note: `${lines} products${unknown.length ? `; not in the product list yet: ${unknown.slice(0, 5).join(', ')}${unknown.length > 5 ? '…' : ''}` : ''}` };
}
// 1.0.0 build 4: products sold on the tills that are not in the app, kept per shop and day until they are known
// (for the Home warning – the Aronium Link screen only shows the last round).
const UNKNOWN = 'aronium_link_unknown';
function unknownMap() { const m = J(getSetting(UNKNOWN, ''), {}); return m && typeof m === 'object' && !Array.isArray(m) ? m : {}; }
function noteUnknown(shop, date, names) {
  try {
    const m = unknownMap(); const k = `${shop}|${date}`;
    if (names.length) m[k] = names.slice(0, 30); else if (!m[k]) return; else delete m[k];
    const keys = Object.keys(m).sort();
    for (const x of keys.slice(0, Math.max(0, keys.length - 200))) delete m[x];
    setSetting(UNKNOWN, JSON.stringify(m));
  } catch (e) { /* only a warning */ }
}
// Home warnings: till products not in the app (their stock is not going down) and till sales days not booked.
export function linkAlerts() {
  const out = [];
  if (!has()) return out;
  try {
    const m = unknownMap();
    const per = new Map();
    for (const [k, list] of Object.entries(m)) {
      const [shop] = k.split('|');
      for (const n of list || []) { const key = String(n).toLowerCase(); const o = per.get(key) || { name: n, shops: new Set() }; o.shops.add(shop); per.set(key, o); }
    }
    // a product added since (by hand or the next product list) is dropped at once
    const left = [...per.values()].filter((p) => { try { return !(findItem(p.name) || findItemByName(p.name)); } catch (e) { return true; } });
    if (left.length) {
      out.push({ id: `link-unknown-${left.length}`, level: 'warning',
        text: `${left.length} product${left.length === 1 ? '' : 's'} sold on the tills ${left.length === 1 ? 'is' : 'are'} not in the app – ${left.length === 1 ? 'its' : 'their'} stock is not going down`,
        sub: `${left.slice(0, 8).map((p) => `${p.name} (${[...p.shops].sort().join(', ')})`).join(', ')}${left.length > 8 ? ` and ${left.length - 8} more` : ''}. Bring in the products from Aronium (or add them), and their sales are booked.`,
        nav: { screen: 'InvImport', params: {} } });
    }
  } catch (e) { /* never stops Home */ }
  // build 30: an End of day missing between two that came in – offer "Send everything again" (Aronium page)
  try {
    const gaps = require('./missingEod.js').missingEods();
    if (gaps.length) {
      const M = require('./missingEod.js');
      out.push({ id: `link-eod-gap-${gaps.map((g) => `${g.source}:${g.missing.join('.')}`).join('|')}`, level: 'warning',
        text: `End of day${gaps.reduce((n, g) => n + g.missing.length, 0) === 1 ? '' : 's'} missing from the till PCs`,
        sub: `${gaps.map(M.gapText).join('; ')}. Open Aronium and press "Send everything again" for that shop.`,
        nav: { screen: 'AroniumHub', params: { shop: gaps[0].shop } } });
    }
  } catch (e) { /* never stops Home */ }
  try {
    const nb = db().all("SELECT key, note FROM aronium_link_done WHERE key LIKE 'sales|%' AND note LIKE 'not booked:%' ORDER BY key");
    if (nb.length) {
      out.push({ id: `link-notbooked-${nb.length}`, level: 'warning',
        text: `${nb.length} day${nb.length === 1 ? '' : 's'} of till sales not booked into stock`,
        sub: `${nb.slice(0, 5).map((r) => { const [, s, d] = r.key.split('|'); return `${s} ${d}`; }).join(', ')}${nb.length > 5 ? '…' : ''}: ${String(nb[0].note).slice(12, 140)}`,
        nav: { screen: 'AroniumLink', params: {} } });
    }
  } catch (e) { /* never stops Home */ }
  return out;
}

// ---------------------------------------------------------------- End of day per till
function doZ(row, out) {
  const key = `z|${row.uid}`;
  if (done(key)?.hash === row.hash) return;
  const z = J(row.data, null);
  if (!z || !z.date) { markDone(key, row.hash, 'empty'); return; }
  // Release 28: an End of day with no sales in it (sent so the numbers have no gap) – nothing to balance
  if (z.empty && !(Number(z.total) || Number(z.receipts) || Object.keys(z.payments || {}).length)) { markDone(key, row.hash, 'empty End of day – no sales'); return; }
  // An End of day worked out per day (older Aronium) is only final once the day is over.
  if (!z.z_id && z.date >= dateStr()) return;
  const r = putLinkedEod({ uid: `EOD-${row.source}-${z.key}`, shopCode: row.shop_code, tillName: row.till, date: z.date, zNumber: z.z_id ? z.number : '',
    total: z.total, vat: z.vat, zero: z.zero, cash: z.cash, card: z.card, other: z.other,
    note: `From ${row.till || row.source}: sales ${r2(z.sales)}, refunds ${r2(z.refunds)}, discounts ${r2(z.discounts)}, ${z.receipts || 0} receipts${z.voids && z.voids.count ? `, ${z.voids.count} voids ${r2(z.voids.total)}` : ''}${Object.keys(z.cashiers || {}).length ? `; cashiers: ${Object.keys(z.cashiers).join(', ')}` : ''}` });
  markDone(key, row.hash, r.added ? 'added' : r.typed ? 'already typed by hand' : 'already there');
  if (r.added) out.push(`End of day ${z.number || z.date} ${row.till || row.source}`);
}

// ---------------------------------------------------------------- one round (called after each sync on the main tablet)
// limit: how many sales days are worked per round (the very first time there can be hundreds).
// v1.0.0 any device: the till's sales per day and its End of days are made on whichever device syncs (their records
// have fixed ids, so two devices making them give the same records – never doubled). The rest (products, suppliers,
// FCCC, staff credit, product-change log, answering the till's test) stays with the main tablet.
export function processLink(...a) { globalThis.__inLink = (globalThis.__inLink || 0) + 1; try { return processLink0(...a); } finally { globalThis.__inLink -= 1; } }
function processLink0({ limit = 40, force = false, salesOnly = false } = {}) {
  if (!has()) return { skipped: true };
  if (!force && !isLinkDevice()) salesOnly = true;
  const out = [];
  const errors = [];
  const step = (name, fn) => { try { withSystem(fn); } catch (e) { errors.push(`${name}: ${e.message || e}`); } };
  const shops = salesOnly ? [] : db().all('SELECT DISTINCT shop_code FROM aronium_feed').map((r) => r.shop_code);
  let productsChanged = false;
  for (const shop of shops) {
    step(`${shop} products`, () => { if (doProducts(shop, out)) productsChanged = true; });
    // 1.0.0 build 10: suppliers are matched by their TIN, which only an admin device holds (a staff phone's copy has it
    // empty) – so the supplier round waits for an admin device (or the main one); products, FCCC and credit go on here.
    if (fullCopy()) step(`${shop} suppliers`, () => doSuppliers(shop, out));
  }
  // New products may make earlier sales lines known: those days are worked again.
  if (productsChanged) step('recheck', () => db().run('DELETE FROM aronium_link_done WHERE waiting = 1 AND key LIKE ?', ['sales|%']));
  // New or renamed products: the app marks the ones on the FCCC list as controlled (and watches them).
  if (productsChanged) step('FCCC', () => {
    const F = require('../inventory/fccc.js');
    const r = F.autoLinkFccc();
    if (r.linked && r.linked.length) out.push(`${r.linked.length} product(s) marked FCCC-controlled – confirm in FCCC controlled prices`);
    const v = F.autoReview(); // new prices from Aronium: the FCCC list may now be fine (or not)
    if (v.ticked) out.push(`FCCC: ${v.ticked} list(s) ticked – every controlled price is within the FCCC price`);
  });
  let worked = 0;
  for (const k of salesKeys(100000)) {
    if (worked >= limit) break;
    const key = `sales|${k.shop_code}|${k.period}`;
    if (done(key)?.hash === k.h) continue;
    worked += 1;
    try {
      withSystem(() => {
        const r = doSalesDay(k.shop_code, k.period, out);
        if (r.note !== 'a part is still on its way') markDone(key, k.h, r.note, r.waiting);
      });
    } catch (e) {
      // e.g. the month is locked: noted once, not tried again until Aronium's figures for that day change.
      errors.push(`sales ${k.shop_code} ${k.period}: ${e.message || e}`);
      try { withSystem(() => markDone(key, k.h, `not booked: ${e.message || e}`)); } catch (e2) { /* next round */ }
    }
  }
  for (const row of rowsOf('z')) step(`End of day ${row.period}`, () => doZ(row, out));
  // 1.0.0 End of days that came in after their shift's cigarette tally was saved
  // 1.0.0 the recharge machines: Aronium's recharge sales per till PC and day (one figure each, never added twice)
  step('recharge sales', () => { const n = require('../till/recharge.js').refreshSales(); if (n) out.push(`recharge sales brought up to date: ${n}`); });
  step('cigarette tallies', () => { const n = require('../till/cigTally.js').attachLate(); if (n) out.push(`cigarette tallies brought up to date: ${n}`); });
  if (!salesOnly) step('test answers', () => answerPings(out));
  // 1.0.0 receipts (with their lines) are kept on each device for 90 days; the day totals per product (sales_day) stay
  step('old receipts', () => { const n = pruneReceipts(); if (n) out.push(`old receipts cleared: ${n}`); });
  // v3.9.4 staff credit (what staff owe on Aronium's customer accounts), all tills added up per person
  step('staff credit', () => {
    if (salesOnly || !db().get("SELECT 1 AS x FROM aronium_feed WHERE kind = 'credit' LIMIT 1")) return;
    const per = new Map();
    for (const c of aroniumCredit()) {
      const k = txt(c.name).toLowerCase();
      if (!k) continue;
      const o = per.get(k) || { name: txt(c.name), code: null, balance: 0, since: null };
      o.balance = r2(o.balance + Number(c.owing || 0));
      if (c.oldest && (!o.since || c.oldest < o.since)) o.since = c.oldest;
      per.set(k, o);
    }
    const r = require('../owed/service.js').syncCreditFromLink([...per.values()]);
    if (r.changed) out.push(`Staff credit from Aronium: ${r.people || 0} people`);
  });
  const left = salesKeys(100000).filter((k) => done(`sales|${k.shop_code}|${k.period}`)?.hash !== k.h).length;
  setSetting('aronium_link_last', JSON.stringify({ at: stamp(), did: out.slice(0, 20), errors: errors.slice(0, 10), left }));
  return { did: out, errors, left };
}

// The till program's "Test the app" button: it sends a test (kind 'ping'); the main tablet answers (kind 'pong') with
// the same number, which goes back up to the cloud, where the till program sees it.
function answerPings(out) {
  for (const p of rowsOf('ping')) {
    const ping = J(p.data, {});
    const uid = `${p.source}|pong|ping|0`;
    const have = db().get('SELECT data FROM aronium_feed WHERE uid = ?', [uid]);
    if (have && J(have.data, {}).nonce === ping.nonce) continue;
    let ver = '';
    try { ver = require('../../services/core.js').APP_VERSION; } catch (e) { ver = ''; }
    let name = '';
    try { name = require('../../services/core.js').deviceName(); } catch (e) { name = ''; }
    const data = JSON.stringify({ nonce: ping.nonce, at: new Date().toISOString(), device: name || 'Main tablet', app: ver, sentAt: ping.sent_at || '' });
    const now = new Date().toISOString();
    db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
      VALUES (?,?,?,?, 'pong', 'ping', 0, 1, ?, ?, ?, '', ?, ?, 'pending')
      ON CONFLICT(uid) DO UPDATE SET data = excluded.data, hash = excluded.hash, made_at = excluded.made_at, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [uid, p.source, p.shop_code, p.till, data, `pong-${ping.nonce}`, now, now, deviceId()]);
    out.push(`Answered the test from ${p.till || p.source}`);
  }
}

// What the till PCs already bring in by themselves (for the CSV screens): { on, ago, last } per kind.
export function linkCovers(kind) {
  if (!has()) return { on: false };
  const r = db().get('SELECT MAX(updated_at) AS t FROM aronium_feed WHERE kind = ?', [kind]);
  if (!r || !r.t) return { on: false };
  const s = String(r.t);
  const t = Date.parse(/Z$/.test(s) ? s : `${s.replace(' ', 'T').slice(0, 19)}Z`);
  const mins = Number.isFinite(t) ? Math.max(0, Math.round((Date.now() - t) / 60000)) : null;
  return { on: mins !== null && mins < 3 * 24 * 60, mins, last: s };
}

// ---------------------------------------------------------------- what the screens show
// 1.0.0 kept until the feed, the link's own notes or a setting changes (the warnings, the watchdog and the sales
// watch ask for it many times); each caller gets its own copy.
export function linkStatus() {
  const st = keepTracked('link|status', workOutLinkStatus); // round 2: until what it read changes (single settings, not all)
  return { ...st, tills: st.tills.map((t) => ({ ...t })) };
}
function workOutLinkStatus() {
  if (!has()) return { tills: [], last: null, isLinkDevice: isLinkDevice() };
  const tills = sources().map((source) => {
    const meta = db().get("SELECT * FROM aronium_feed WHERE source = ? AND kind = 'meta' ORDER BY updated_at DESC LIMIT 1", [source]);
    // 1.0.0 the newest of each kind (one index look-up each) instead of reading every row of the till PC
    const last = db().get(`WITH RECURSIVE k(x) AS (SELECT MIN(kind) FROM aronium_feed WHERE source = ?1
        UNION ALL SELECT (SELECT MIN(kind) FROM aronium_feed WHERE source = ?1 AND kind > k.x) FROM k WHERE k.x IS NOT NULL)
      SELECT MAX((SELECT MAX(updated_at) FROM aronium_feed WHERE source = ?1 AND kind = k.x)) AS t FROM k WHERE k.x IS NOT NULL AND k.x <> 'pong'`, [source]).t;
    const m = J(meta && meta.data, {});
    // 1.0.0 the drawer comes on its own (fresher than the health check) from a 1.0.0 Link
    try {
      const dr = db().get("SELECT data, updated_at FROM aronium_feed WHERE source = ? AND kind = 'drawer' ORDER BY updated_at DESC LIMIT 1", [source]);
      const d = J(dr && dr.data, null);
      if (d && d.drawer && typeof d.drawer === 'object' && (!meta || String(dr.updated_at) >= String(meta.updated_at))) m.drawer = d.drawer;
    } catch (e) { /* the health check's drawer stands */ }
    // 1.0.0 speed: the newest End of day of each till PC is kept until the feed changes (asked by many warnings)
    const lastZ = keepUntilChanged(`link|lastZ|${source}`, ['aronium_feed'], () => db().all("SELECT data FROM aronium_feed WHERE source = ? AND kind = 'z'", [source]).map((r) => J(r.data, {})).sort((a, b) => txt(b.closed_at || b.date).localeCompare(txt(a.closed_at || a.date)))[0] || null);
    return { source, shop: SHOP_OF(source), till: (meta && meta.till) || source, lastSeen: last, version: meta ? meta.bridge_version : '', counts: m.counts || {}, notes: m.notes || [], drawer: m.drawer && typeof m.drawer === 'object' ? m.drawer : null,
      lastZ: lastZ ? { number: lastZ.number, date: lastZ.date, total: lastZ.total } : null };
  });
  const pending = db().get("SELECT COUNT(*) AS n FROM aronium_link_done WHERE waiting = 1").n;
  const notes = db().all("SELECT key, note FROM aronium_link_done WHERE waiting = 1 ORDER BY key DESC LIMIT 10");
  return { tills, last: J(getSetting('aronium_link_last', ''), null), isLinkDevice: isLinkDevice(), waiting: pending, waitingNotes: notes };
}
// Aronium's own stock figures for a shop (each till's database keeps its own; they are shown, never booked).
export function aroniumStock(shop) {
  if (!has()) return [];
  const out = new Map();
  for (const s of sources().filter((x) => SHOP_OF(x) === shop)) {
    const w = wholeList(rowsOf('stock', 'AND source = ?', [s]));
    if (!w) continue;
    for (const x of w.items) {
      const k = txt(x.code).toUpperCase();
      const o = out.get(k) || { code: x.code, qty: 0, tills: [] };
      o.qty = q3(o.qty + Number(x.qty || 0));
      o.tills.push(s);
      out.set(k, o);
    }
  }
  return [...out.values()];
}
// What staff owe on Aronium's books (customer accounts), per till.
export function aroniumCredit() {
  if (!has()) return [];
  return sources().flatMap((s) => (wholeList(rowsOf('credit', 'AND source = ?', [s]))?.items || []).map((c) => ({ ...c, source: s })))
    .sort((a, b) => b.owing - a.owing);
}
// v3.9.5 (till program 1.2) the trail behind each customer account: every sale on account still owing and the sales
// and payments of the last 120 days, each with what was bought. One list from every till PC (a sale is kept once).
export function aroniumCreditTrail() {
  if (!has()) return [];
  const out = new Map();
  for (const s of sources()) {
    const w = wholeList(rowsOf('credit_trail', 'AND source = ?', [s]));
    if (!w) continue;
    for (const d of w.items || []) {
      // a till PC that sends something odd: only proper sales are kept, every figure made a number
      if (!d || typeof d !== 'object' || d.id === undefined || d.id === null) continue;
      const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
      out.set(`${s}|${d.id}`, { ...d, customer: txt(d.customer), number: txt(d.number), date: txt(d.date).slice(0, 10), total: num(d.total), paid: num(d.paid), owing: num(d.owing), refund: !!d.refund,
        items: Array.isArray(d.items) ? d.items.filter(Array.isArray) : [], payments: Array.isArray(d.payments) ? d.payments.filter((p) => p && typeof p === 'object').map((p) => ({ ...p, date: txt(p.date).slice(0, 10), type: txt(p.type), amount: num(p.amount) })) : [],
        source: s, shop: SHOP_OF(s) });
    }
  }
  return [...out.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}
// Purchases typed in Aronium (to match with supplier invoices in the app).
export function aroniumPurchases({ from = '' } = {}) {
  if (!has()) return [];
  return db().all("SELECT * FROM aronium_feed WHERE kind = 'purchases' AND period >= ? ORDER BY period DESC", [from])
    .flatMap((r) => J(r.data, []).map((p) => ({ ...p, source: r.source, shop: r.shop_code })));
}
// Sales per shop and till per day (for the dashboard and reports): {date, shop, source, value, units}.
// 1.0.0 speed: a day's totals are worked out from its (big) product list once and kept, keyed by the rows' id,
// part, fingerprint, time and size – a day sent again (anything changed) is worked out again. Only the small columns
// are read to find the days; the lists themselves only for days not worked out yet.
let dayMemo = new Map(); let dayMemoDb = null;
export function aroniumSalesByDay({ from = '', withLines = false } = {}) {
  if (!has()) return [];
  if (withLines) return salesByDayFull({ from });
  if (dayMemoDb !== db()) { dayMemo = new Map(); dayMemoDb = db(); }
  const out = [];
  const groups = new Map();
  for (const r of db().all("SELECT uid, source, period, part, parts, hash, updated_at, length(data) AS len FROM aronium_feed WHERE kind = 'sales_day' AND period >= ? ORDER BY source, period, part", [from])) {
    const k = `${r.source}|${r.period}`;
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(r);
  }
  const fresh = new Map();
  for (const [k, rows] of groups) {
    const key = `${k}#${rows.map((r) => `${r.uid}:${r.part}:${r.parts}:${r.hash}:${r.updated_at}:${r.len}`).join('|')}`;
    let sum = dayMemo.get(key);
    if (sum === undefined) {
      const full = db().all(`SELECT * FROM aronium_feed WHERE uid IN (${rows.map(() => '?').join(',')}) ORDER BY source, period, part`, rows.map((r) => r.uid));
      const w = wholeList(full);
      sum = w ? { value: r2(w.items.reduce((s, l) => s + Number(l.sold_value || 0) - Number(l.refund_value || 0), 0)),
        units: q3(w.items.reduce((s, l) => s + Number(l.net || 0), 0)), cost: r2(w.items.reduce((s, l) => s + Number(l.cost || 0), 0)) } : null;
    }
    fresh.set(key, sum);
    if (!sum) continue;
    const [source, date] = k.split('|');
    out.push({ date, shop: SHOP_OF(source), source, value: sum.value, units: sum.units, cost: sum.cost });
  }
  // only the days still asked for are kept (no growing without end)
  for (const [key, v] of fresh) dayMemo.set(key, v);
  if (dayMemo.size > 4 * Math.max(fresh.size, 2000)) dayMemo = fresh;
  return out;
}
function salesByDayFull({ from = '' } = {}) {
  const out = [];
  const groups = new Map();
  for (const r of db().all("SELECT * FROM aronium_feed WHERE kind = 'sales_day' AND period >= ? ORDER BY source, period, part", [from])) {
    const k = `${r.source}|${r.period}`;
    groups.set(k, (groups.get(k) || []).concat([r]));
  }
  for (const [k, rows] of groups) {
    const w = wholeList(rows);
    if (!w) continue;
    const [source, date] = k.split('|');
    out.push({ date, shop: SHOP_OF(source), source, value: r2(w.items.reduce((s, l) => s + Number(l.sold_value || 0) - Number(l.refund_value || 0), 0)),
      units: q3(w.items.reduce((s, l) => s + Number(l.net || 0), 0)), cost: r2(w.items.reduce((s, l) => s + Number(l.cost || 0), 0)),
      lines: w.items });
  }
  return out;
}
// 1.0.0 build 4: the sales of each shop and day from the till PCs: Map 'date|shop' → { date, shop, value, units, cost,
// tills: { source: value }, live: true }. Today, for a shop whose till PC has not sent the day's figure yet, the
// receipts sent so far (refunds taken off).
export function linkSalesMap({ from = '', to = '9999-12-31', shop = '' } = {}) {
  const out = new Map();
  if (!has()) return out;
  for (const d of aroniumSalesByDay({ from })) {
    if (d.date > to || (shop && d.shop !== shop)) continue;
    const k = `${d.date}|${d.shop}`;
    const o = out.get(k) || { date: d.date, shop: d.shop, value: 0, units: 0, cost: 0, tills: {}, live: true };
    o.value = r2(o.value + d.value); o.units = q3(o.units + d.units); o.cost = r2(o.cost + d.cost);
    o.tills[d.source] = r2((o.tills[d.source] || 0) + d.value);
    out.set(k, o);
  }
  const today = dateStr();
  if (today >= from && today <= to) {
    let rc = [];
    try { rc = aroniumReceipts({ date: today, shop }); } catch (e) { rc = []; }
    for (const r of rc) {
      const k = `${today}|${r.shop}`;
      const o = out.get(k) || { date: today, shop: r.shop, value: 0, units: 0, cost: 0, tills: {}, live: true, fromReceipts: true };
      if (!o.fromReceipts) continue; // the day's figure has come: it stands
      const v = r.refund ? -r.total : r.total;
      o.value = r2(o.value + v); o.tills[r.source] = r2((o.tills[r.source] || 0) + v);
      out.set(k, o);
    }
  }
  return out;
}
// Sales per shop and day, decided for each shop and day on its own: the till PCs' figure where there is one, else
// the rows given (till balances / End of days: [{ date, shop, value, tills }]). Each row says live: true / false.
export function salesPerShopDay({ from = '', to = '9999-12-31', shop = '', fallback = [] } = {}) {
  let link = new Map();
  try { link = linkSalesMap({ from, to, shop }); } catch (e) { link = new Map(); }
  const out = new Map(link);
  for (const f of fallback || []) {
    if (!f || f.date < from || f.date > to || (shop && f.shop !== shop)) continue;
    const k = `${f.date}|${f.shop}`;
    if (link.has(k)) continue;
    const o = out.get(k) || { date: f.date, shop: f.shop, value: 0, tills: {}, live: false };
    o.value = r2(o.value + (Number(f.value) || 0));
    for (const [t, v] of Object.entries(f.tills || {})) o.tills[t] = r2((o.tills[t] || 0) + (Number(v) || 0));
    out.set(k, o);
  }
  return [...out.values()].sort((a, b) => (a.date + a.shop < b.date + b.shop ? -1 : 1));
}
// Each End of day sent by the till PCs from a day on (for the dashboard): receipts, refunds, voids, payments …
export function aroniumZByDay({ from = '' } = {}) {
  if (!has()) return [];
  let rows;
  try { rows = db().all("SELECT source, shop_code, till, data FROM aronium_feed WHERE kind = 'z' AND json_extract(data, '$.date') >= ?", [from]); } catch (e) {
    rows = db().all("SELECT source, shop_code, till, data FROM aronium_feed WHERE kind = 'z'"); // no JSON support on this device
  }
  return rows.map((r) => ({ ...J(r.data, {}), source: r.source, shop: r.shop_code, till: r.till })).filter((z) => z.date && z.date >= from);
}

// 1.0.0 storage over the years: a till sends about 100–300 KB of receipts a day; kept 90 days that is a few tens of MB
// at most on a phone, where 3 years would be ~0.6 GB. Older receipt days are deleted here (the Link also empties
// them in the cloud); the products sold per day (sales_day), End of days and everything booked from them stay for good.
export const RECEIPT_DAYS = 90;
export function pruneReceipts({ keepDays = RECEIPT_DAYS, today = dateStr() } = {}) {
  if (!has()) return 0;
  const d = new Date(`${today}T12:00:00`);
  d.setDate(d.getDate() - Math.max(1, keepDays) + 1);
  const cut = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const n = db().get("SELECT COUNT(*) AS n FROM aronium_feed WHERE kind = 'receipts' AND period < ?", [cut]).n;
  if (n) db().run("DELETE FROM aronium_feed WHERE kind = 'receipts' AND period < ?", [cut]);
  return n;
}

// ---------------------------------------------------------------- live sales (1.0.0)
const HMS = /^\d{2}:\d{2}(:\d{2})?$/;
// Each receipt of a day from the till PCs (Aronium Link sends them as they happen), newest first:
// { time, no, total, refund, pay, who, lines, source, shop }. A till PC that sends something odd is skipped, never shown wrong.
// 1.0.0 kept until the feed changes (the sales watch reads each of the last 7 days twice); each caller its own copy
// round 2: a figure made from one day's receipts depends on that day's receipt rows only (a fingerprint of them), not
// on every row the till PCs send – so the sales watch works out only the day that changed.
const RECEIPTS_PROBE = "SELECT COUNT(*) AS n, group_concat(uid || ':' || IFNULL(hash,'') || ':' || IFNULL(updated_at,'') || ':' || IFNULL(part,'') || ':' || IFNULL(parts,'') || ':' || length(data), '|') AS f FROM aronium_feed WHERE kind = 'receipts' AND period = ?";
export function aroniumReceipts({ date = dateStr(), shop = '' } = {}) {
  noteDeps([probeDep(RECEIPTS_PROBE, [date])]);
  return untracked(() => keepUntilChanged(`link|receipts|${date}|${shop}`, ['aronium_feed'], () => workOutReceipts({ date, shop }))).map((r) => ({ ...r }));
}
function workOutReceipts({ date, shop }) {
  if (!has()) return [];
  const out = [];
  for (const s of sources().filter((x) => !shop || SHOP_OF(x) === shop)) {
    let w = null;
    try { w = wholeList(rowsOf('receipts', 'AND source = ? AND period = ?', [s, date]), true); } catch (e) { w = null; }
    for (const r of (w ? w.items : [])) {
      if (!r || typeof r !== 'object') continue;
      const time = txt(r.time).slice(0, 8);
      const total = Number(r.total);
      if (!HMS.test(time) || !Number.isFinite(total)) continue;
      const refund = !!Number(r.refund);
      // how it was paid, each way with its amount ("Cash=10.00;M-PAiSA=5.00"); an older Aronium Link sends only the names
      const pays = txt(r.pays).split(';').map((x) => x.split('=')).filter((x) => x.length === 2 && x[0].trim() && Number.isFinite(Number(x[1])))
        .map(([n, a]) => ({ name: n.trim(), amount: r2(Math.abs(Number(a))) }));
      const open = r.open === undefined || r.open === null || r.open === '' ? -1 : Number(r.open);
      // 1.0.0 what was sold on it: [code, qty, price, discount, total] per line (an older Link sends none)
      const items = (Array.isArray(r.items) ? r.items : []).filter((l) => Array.isArray(l) && txt(l[0])).slice(0, 200)
        .map((l) => ({ code: txt(l[0]), qty: q3(Math.abs(Number(l[1]) || 0)), price: r2(Math.abs(Number(l[2]) || 0)), disc: r2(Math.abs(Number(l[3]) || 0)), total: r2(Math.abs(Number(l[4]) || 0)) }));
      const z = Number.isFinite(Number(r.z)) && r.z !== null && r.z !== '' ? Number(r.z) : null;
      out.push({ time, no: txt(r.no), total: r2(Math.abs(total)), refund, pay: txt(r.pay), pays, who: txt(r.who), lines: Number(r.lines) || 0, open: [0, 1].includes(open) ? open : -1, source: s, shop: SHOP_OF(s),
        date, z, items, key: `${s}|${date}|${txt(r.no) || time}` });
    }
  }
  return out.sort((a, b) => (a.time < b.time ? 1 : a.time > b.time ? -1 : a.source.localeCompare(b.source)));
}
// Each till's day so far: when it started (first sale) and its latest sale. From the receipts when the till PC sends
// them, else from its sales by hour (to the hour). { source, shop, till, first, last, receipts, value, exact, lastSeen }
export function tillDay(date = dateStr()) {
  if (!has()) return [];
  const st = safeStatus();
  const out = [];
  const all = aroniumReceipts({ date });
  for (const t of st) {
    const rc = all.filter((r) => r.source === t.source && !r.refund);
    let first = null; let last = null; let n = 0; let value = 0; let exact = false;
    if (rc.length) {
      exact = true; n = rc.length; value = r2(rc.reduce((s, r) => s + r.total, 0));
      last = rc[0].time.slice(0, 5); first = rc[rc.length - 1].time.slice(0, 5);
    } else {
      let a = {};
      try { const row = db().get("SELECT data FROM aronium_feed WHERE kind = 'activity' AND source = ? AND period = ? ORDER BY updated_at DESC LIMIT 1", [t.source, date]); a = J(row && row.data, {}); } catch (e) { a = {}; }
      const hrs = Object.entries((a && a.hours) || {}).filter(([h, x]) => /^\d{2}$/.test(h) && x && Number(x.receipts) > 0).map(([h, x]) => ({ h, x })).sort((p, q) => (p.h < q.h ? -1 : 1));
      if (hrs.length) {
        first = `${hrs[0].h}:00`; last = `${hrs[hrs.length - 1].h}:59`;
        n = hrs.reduce((s, y) => s + (Number(y.x.receipts) || 0), 0); value = r2(hrs.reduce((s, y) => s + (Number(y.x.value) || 0), 0));
      }
    }
    out.push({ source: t.source, shop: t.shop, till: t.till, first, last, receipts: n, value, exact, lastSeen: t.lastSeen });
  }
  return out;
}
function safeStatus() { try { return linkStatus().tills || []; } catch (e) { return []; } }

// The till drawer now, worked out from the sales once synced: what should be in it since the last End of day.
//   float at the start (Aronium's opening cash, else the till's float in the app) + cash put in − cash taken out
//   + cash sales − cash paid back on refunds (receipts not yet in an End of day).
// Per till PC: { source, shop, till, float, floatFrom, cashIn, cashOut, cashSales, cashRefunds, expected, payments: {method: net}, refunds, receipts, since, exact }
export const isCash = (name) => /cash/i.test(String(name || '')) && !/cheque|card|account/i.test(String(name || ''));
export function tillDrawer({ date = dateStr(), shop = '' } = {}) {
  if (!has()) return [];
  const all = aroniumReceipts({ date, shop });
  const zs = (() => { try { return aroniumZByDay({ from: date }); } catch (e) { return []; } })();
  return safeStatus().filter((t) => !shop || t.shop === shop).map((t) => {
    const mine = all.filter((r) => r.source === t.source);
    // the last End of day of today on this till: receipts before it are already counted (when the PC cannot say)
    const lastZ = zs.filter((z) => z.source === t.source && z.date === date).map((z) => txt(z.closed_at).slice(11, 19)).filter(Boolean).sort().pop() || '';
    const inDrawer = mine.filter((r) => (r.open === -1 ? (!lastZ || r.time > lastZ) : r.open === 1));
    const payments = {}; let cashSales = 0; let cashRefunds = 0; let refunds = 0; let refundValue = 0;
    for (const r of inDrawer) {
      const ways = r.pays.length ? r.pays : (r.pay && !r.pay.includes('+') ? [{ name: r.pay, amount: r.total }] : []);
      if (r.refund) { refunds += 1; refundValue = r2(refundValue + r.total); }
      for (const p of ways) {
        const v = r.refund ? -p.amount : p.amount;
        payments[p.name] = r2((payments[p.name] || 0) + v);
        if (isCash(p.name)) { if (r.refund) cashRefunds = r2(cashRefunds + p.amount); else cashSales = r2(cashSales + p.amount); }
      }
    }
    const d = t.drawer || {};
    let float = Number(d.opening); let floatFrom = 'Aronium';
    if (!Number.isFinite(float) || !(d.opening !== undefined)) {
      floatFrom = 'app';
      float = 0;
      try {
        const T = require('../till/service.js');
        const tills = T.listTills({ shopCode: t.shop });
        const num = (txt(t.source).match(/T(\d+)$/i) || [])[1];
        const m = tills.find((x) => num && new RegExp(`\\b${num}\\b`).test(String(x.name))) || (tills.length === 1 ? tills[0] : null);
        float = m ? T.openingFloat(m.uid) : 0;
        if (!m) floatFrom = 'none';
      } catch (e) { floatFrom = 'none'; }
    }
    const cashIn = r2(Number(d.cash_in) || 0); const cashOut = r2(Number(d.cash_out) || 0);
    return { source: t.source, shop: t.shop, till: t.till, float: r2(float), floatFrom, cashIn, cashOut, cashSales, cashRefunds,
      expected: r2(float + cashIn - cashOut + cashSales - cashRefunds), payments, refunds, refundValue,
      receipts: inDrawer.filter((r) => !r.refund).length, since: lastZ || null, exact: inDrawer.every((r) => r.open !== -1), withAmounts: inDrawer.every((r) => r.pays.length > 0), lastSeen: t.lastSeen };
  });
}

// 1.0.0 For the Aronium update file: the product list as Aronium has it at a shop (the lowest till that sent it), and
// that Aronium's own tax rates ({ name, rate }).
export function aroniumProducts(shop) {
  if (!has()) return { source: null, items: [], taxes: [] };
  for (const s of sources().filter((x) => SHOP_OF(x) === shop).sort()) {
    let w = null;
    try { w = wholeList(rowsOf('products', 'AND source = ?', [s])); } catch (e) { w = null; }
    if (!w || !w.items.length) continue;
    let taxes = [];
    try {
      const meta = db().get("SELECT data FROM aronium_feed WHERE source = ? AND kind = 'meta' ORDER BY updated_at DESC LIMIT 1", [s]);
      taxes = (J(meta && meta.data, {}).taxes || []).filter((t) => t && txt(t.name)).map((t) => ({ name: txt(t.name), rate: Number(t.rate) || 0 }));
    } catch (e) { taxes = []; }
    return { source: s, items: w.items, taxes };
  }
  return { source: null, items: [], taxes: [] };
}
