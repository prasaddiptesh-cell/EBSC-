// 1.0.0 build 30 (owner, 10 Nov): "the End of day report for 2 days did not sync through – the app should prompt, and
// there should be a way for the till PCs to send all their data again". Aronium numbers each till's End of days one
// after another (z30, z31, z32…); a number missing between two that came in means an End of day that never reached
// the app. Only the latest RECENT numbers per till are looked at (old history is not nagged about).
import { db } from '../../db/connection.js';

export const RECENT = 20;

// rows: [{ source, period }] (aronium_feed, kind 'z') → [{ source, shop, missing: [31, 32] }] – tills with a gap only.
export function zGaps(rows, recent = RECENT) {
  const per = new Map();
  for (const r of rows || []) {
    const m = /^z(\d+)$/.exec(String(r && r.period || ''));
    if (!m || !r.source) continue;
    const set = per.get(r.source) || new Set();
    set.add(Number(m[1]));
    per.set(r.source, set);
  }
  const out = [];
  for (const [source, set] of per) {
    const ids = [...set].sort((a, b) => a - b).slice(-recent);
    const missing = [];
    for (let i = 1; i < ids.length; i++) for (let n = ids[i - 1] + 1; n < ids[i]; n++) missing.push(n);
    if (missing.length) out.push({ source, shop: String(source).split('-')[0], missing });
  }
  return out.sort((a, b) => (a.source < b.source ? -1 : 1));
}

export const tillName = (source) => `Shop ${String(source).split('-')[0].replace(/^S/, '')} Till ${String(source).split('-T')[1] || '?'}`;
export function gapText(g) {
  const n = g.missing.length;
  return `${tillName(g.source)}: End of day${n === 1 ? '' : 's'} ${g.missing.slice(0, 6).join(', ')}${n > 6 ? ` and ${n - 6} more` : ''} did not come in`;
}

// What this device holds now (shop: only that shop's tills).
export function missingEods(shop = '') {
  let rows = [];
  try {
    rows = db().all("SELECT DISTINCT source, period FROM aronium_feed WHERE kind = 'z'");
  } catch (e) { rows = []; }
  return zGaps(rows).filter((g) => !shop || g.shop === shop);
}
