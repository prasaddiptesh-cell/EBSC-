// 1.0.0 Aronium reports for any period (Reports hub › period picker): built by the app from what the till PCs send
// through the Aronium Link (aronium_feed: sales_day, receipts, z, activity) and the End of days (aronium_eods).
// Each shop on its own (params.shop) or all shops together. Same report shape as every other report, so PDF /
// Excel / CSV / print work. Read only – Aronium itself is never written to.
//   Sales summary by day  → the existing "Sales history" report (till/salesHistory.js) is extended here, not doubled
//   ar_items      items sold (product, quantity, amount; top sellers by amount and by quantity)
//   ar_hours      sales by hour of day
//   ar_cashiers   per cashier: sales, refunds, voids, discounts
//   ar_refunds    refunds (each refund receipt) and voids (per End of day and per cashier)
//   ar_zlist      End of day / Z list: Z number, date, till, totals, cash, agrees with the till balance or not
import { db } from '../../db/connection.js';
import { stamp, addDays } from '../../services/core.js';
import * as L from './link.js';
import { receiptShop } from './receipts.js';
import { salesHistoryReport } from '../till/salesHistory.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayOf = (d) => DAYS[new Date(`${d}T12:00:00`).getDay()];
const hourLabel = (h) => { const n = Number(h); return `${n % 12 || 12}${n < 12 ? 'am' : 'pm'}`; };
const qty = (n) => String(q3(n));

// The shop asked for ('' = all shops); someone who may only see their own shop gets their own shop.
export function periodShop(user, params = {}) {
  const wanted = txt(params && params.shop);
  if (!user) return wanted;
  return txt(safe(() => receiptShop(user, wanted), wanted));
}
const period = (from, to) => (from === to ? from : `${from} to ${to}`);
const head = (kind, title, from, to, shop, extra) => ({
  kind, title: `${title}${shop ? ` ${shop}` : ''}`, fileName: `${title.replace(/\s+/g, '-')}${shop ? `-${shop}` : ''}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${period(from, to)} · ${shop || 'All shops'}`,
  info: [['Period', period(from, to)], ['Shop', shop || 'All shops'], ['From', 'Aronium (the till PCs, through the Aronium Link)'], ['Generated', stamp()]], ...extra,
});

// ---------------------------------------------------------------- readers (all reuse the Aronium Link's own readers)
// End of days sent by the till PCs in the period: [{ source, shop, till, date, number, total, vat, zero, cash, receipts, refunds, voids… }]
export function zInPeriod({ from, to, shop = '' }) {
  return safe(() => L.aroniumZByDay({ from }), []).filter((z) => z.date <= to && (!shop || z.shop === shop));
}
// Activity per till per day: { hours: { HH: { value, receipts } }, cashiers: { name: {…} } }
export function activityInPeriod({ from, to, shop = '' }) {
  if (!has('aronium_feed')) return [];
  return safe(() => db().all("SELECT source, period, data FROM aronium_feed WHERE kind = 'activity' AND period BETWEEN ? AND ? ORDER BY period, source", [from, to]), [])
    .filter((r) => !shop || L.SHOP_OF(r.source) === shop).map((r) => ({ source: r.source, shop: L.SHOP_OF(r.source), date: r.period, ...J(r.data, {}) }));
}
// Every receipt of the period (the till PCs keep about 90 days of receipts).
export function receiptsInPeriod({ from, to, shop = '' }) {
  if (!has('aronium_feed')) return [];
  const days = safe(() => db().all("SELECT DISTINCT period AS d FROM aronium_feed WHERE kind = 'receipts' AND period BETWEEN ? AND ? ORDER BY period", [from, to]), []).map((r) => r.d);
  return days.flatMap((d) => safe(() => L.aroniumReceipts({ date: d, shop }), []));
}

// ---------------------------------------------------------------- 1. sales summary by day (extends "Sales history")
// Per day and shop: gross, VAT, zero-rated, receipts, average sale – from the End of days (Z) and the till PCs' sales.
export function salesSummary({ from, to, shop = '' }) {
  const days = new Map();
  const get = (d, s) => { const k = `${d}|${s}`; if (!days.has(k)) days.set(k, { date: d, shop: s, gross: 0, vat: 0, zero: 0, receipts: 0, refunds: 0, fromZ: false, live: false }); return days.get(k); };
  for (const x of safe(() => L.salesPerShopDay({ from, to, shop }), [])) { const o = get(x.date, x.shop); o.gross = r2(o.gross + x.value); o.live = true; }
  for (const z of zInPeriod({ from, to, shop })) {
    const o = get(z.date, z.shop);
    o.vat = r2(o.vat + (Number(z.vat) || 0)); o.zero = r2(o.zero + (Number(z.zero) || 0));
    o.receipts += Number(z.receipts) || 0; o.refunds = r2(o.refunds + (Number(z.refunds) || 0)); o.zTotal = r2((o.zTotal || 0) + (Number(z.total) || 0)); o.fromZ = true;
  }
  // a day with an End of day typed by hand only (no till PC figures)
  if (has('aronium_eods')) {
    for (const e of safe(() => db().all("SELECT eod_date AS d, shop_code AS s, SUM(total) AS t, SUM(IFNULL(vat,0)) AS v, SUM(IFNULL(zero,0)) AS z FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ? GROUP BY eod_date, shop_code", [from, to]), [])) {
      if (shop && e.s !== shop) continue;
      const o = get(e.d, e.s);
      if (!o.live) o.gross = r2(e.t);
      if (!o.fromZ) { o.vat = r2(e.v); o.zero = r2(e.z); }
    }
  }
  // today, before the day's End of day: the receipts sent so far
  for (const o of days.values()) {
    if (!o.receipts) o.receipts = safe(() => L.aroniumReceipts({ date: o.date, shop: o.shop }), []).filter((x) => !x.refund).length;
    o.avg = o.receipts ? r2(o.gross / o.receipts) : 0;
  }
  const rows = [...days.values()].sort((a, b) => (a.date + a.shop < b.date + b.shop ? -1 : 1));
  const sum = (f) => r2(rows.reduce((t, x) => t + (Number(x[f]) || 0), 0));
  const receipts = rows.reduce((t, x) => t + x.receipts, 0);
  return { rows, gross: sum('gross'), vat: sum('vat'), zero: sum('zero'), refunds: sum('refunds'), receipts, avg: receipts ? r2(sum('gross') / receipts) : 0 };
}
export function salesSummaryReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const rep = salesHistoryReport(from, to, user, { ...(params || {}), shop });
  const s = salesSummary({ from, to, shop });
  const rows = s.rows.map((o) => ({ date: o.date, day: dayOf(o.date), shop: o.shop, gross: $(o.gross), vat: $(o.vat), zero: $(o.zero), net: $(o.gross - o.vat), receipts: o.receipts || '', avg: o.receipts ? $(o.avg) : '', refunds: o.refunds ? $(o.refunds) : '' }));
  return { ...rep,
    summary: (rep.summary || []).concat([{ label: 'VAT', value: $(s.vat) }, { label: 'Zero-rated sales', value: $(s.zero) }, { label: 'Receipts', value: String(s.receipts) }, { label: 'Average sale', value: $(s.avg) }]),
    sections: (rep.sections || []).concat([{ title: 'Summary by day and shop', columns: [col('date', 'Date'), col('day', 'Day'), col('shop', 'Shop'), col('gross', 'Gross sales', R), col('vat', 'VAT', R), col('zero', 'Zero-rated', R),
      col('net', 'Sales less VAT', R), col('receipts', 'Receipts', R), col('avg', 'Average sale', R), col('refunds', 'Refunds', R)], rows,
      totals: [{ label: 'Gross sales', value: $(s.gross), strong: true }, { label: 'VAT', value: $(s.vat) }, { label: 'Zero-rated', value: $(s.zero) }],
      note: 'Gross sales from the till PCs (the End of day where a till PC sent nothing); VAT, zero-rated and receipts from the End of days (Z).' }]) };
}

// ---------------------------------------------------------------- 2. items sold
export function itemsSold({ from, to, shop = '' }) {
  const map = new Map();
  for (const x of safe(() => L.aroniumSalesByDay({ from, withLines: true }), [])) {
    if (x.date > to || (shop && x.shop !== shop)) continue;
    for (const l of x.lines || []) {
      const code = txt(l.code); const name = txt(l.name) || code;
      const k = `${shop ? '' : `${x.shop}|`}${code.toUpperCase() || name.toLowerCase()}`;
      const o = map.get(k) || { code, name, shop: x.shop, qty: 0, sold: 0, refunded: 0, value: 0, cost: 0, days: new Set() };
      o.qty = q3(o.qty + (Number(l.net) || 0)); o.sold = q3(o.sold + (Number(l.sold) || 0)); o.refunded = q3(o.refunded + (Number(l.refunded) || 0));
      o.value = r2(o.value + (Number(l.sold_value) || 0) - (Number(l.refund_value) || 0)); o.cost = r2(o.cost + (Number(l.cost) || 0)); o.days.add(x.date);
      map.set(k, o);
    }
  }
  return [...map.values()].map((o) => ({ ...o, days: o.days.size, profit: r2(o.value - o.cost) })).sort((a, b) => b.value - a.value || b.qty - a.qty);
}
function itemsReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const list = itemsSold({ from, to, shop });
  const by = txt(params && params.sort) === 'qty' ? 'qty' : 'value';
  const sorted = by === 'qty' ? list.slice().sort((a, b) => b.qty - a.qty || b.value - a.value) : list;
  const total = r2(list.reduce((t, o) => t + o.value, 0));
  const row = (o, i) => ({ rank: i + 1, code: o.code, name: o.name, shop: o.shop, qty: qty(o.qty), refunded: o.refunded ? qty(o.refunded) : '', value: $(o.value), share: total ? `${r2((o.value / total) * 100)}%` : '', cost: $(o.cost), profit: $(o.profit), _tone: o.value < 0 ? 'warn' : null });
  const cols = [col('rank', '#', R), col('code', 'Code'), col('name', 'Product')].concat(shop ? [] : [col('shop', 'Shop')])
    .concat([col('qty', 'Quantity', R), col('refunded', 'Refunded', R), col('value', 'Amount', R), col('share', '% of sales', R), col('cost', 'Cost', R), col('profit', 'Profit', R)]);
  const byQty = list.slice().sort((a, b) => b.qty - a.qty || b.value - a.value).slice(0, 20);
  return head('ar_items', 'Items Sold', from, to, shop, {
    summary: [{ label: 'Products', value: String(list.length) }, { label: 'Units', value: qty(list.reduce((t, o) => t + o.qty, 0)) }, { label: 'Amount', value: $(total) }]
      .concat(list[0] ? [{ label: 'Top seller', value: `${list[0].name} ${$(list[0].value)}` }] : []),
    sections: [
      { title: 'Top 20 by amount', columns: cols, rows: list.slice(0, 20).map(row) },
      { title: 'Top 20 by quantity', columns: cols, rows: byQty.map(row) },
      { title: `Every product (by ${by === 'qty' ? 'quantity' : 'amount'})`, columns: cols, rows: sorted.map(row), totals: [{ label: 'Total', value: $(total), strong: true }],
        note: 'Sold less refunded, from the till PCs\' sales per product per day. In Excel or CSV any column can be sorted.' },
    ],
  });
}

// ---------------------------------------------------------------- 3. sales by hour of day
export function salesByHour({ from, to, shop = '' }) {
  const hours = {};
  const days = new Set();
  for (const a of activityInPeriod({ from, to, shop })) {
    days.add(a.date);
    for (const [hh, x] of Object.entries(a.hours || {})) {
      if (!/^\d{1,2}$/.test(hh)) continue;
      const k = String(Number(hh)).padStart(2, '0');
      const h = hours[k] || (hours[k] = { hour: k, value: 0, receipts: 0, days: new Set(), shops: {} });
      h.value = r2(h.value + (Number(x.value) || 0)); h.receipts += Number(x.receipts) || 0; h.days.add(a.date);
      h.shops[a.shop] = r2((h.shops[a.shop] || 0) + (Number(x.value) || 0));
    }
  }
  const total = r2(Object.values(hours).reduce((t, h) => t + h.value, 0));
  const list = Object.keys(hours).sort().map((k) => { const h = hours[k]; return { hour: k, label: `${hourLabel(k)}–${hourLabel((Number(k) + 1) % 24)}`, value: h.value, receipts: h.receipts,
    perDay: r2(h.value / Math.max(1, days.size)), avgSale: h.receipts ? r2(h.value / h.receipts) : 0, share: total ? r2((h.value / total) * 100) : 0, shops: h.shops }; });
  return { hours: list, total, days: days.size, shops: [...new Set(list.flatMap((h) => Object.keys(h.shops)))].sort(), peak: list.reduce((b, h) => (!b || h.value > b.value ? h : b), null) };
}
function hoursReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const h = salesByHour({ from, to, shop });
  return head('ar_hours', 'Sales By Hour', from, to, shop, {
    summary: [{ label: 'Sales', value: $(h.total) }, { label: 'Trading days', value: String(h.days) }].concat(h.peak ? [{ label: 'Busiest hour', value: `${h.peak.label} ${$(h.peak.value)}` }] : []),
    sections: [{ title: 'By hour of day', columns: [col('label', 'Hour'), col('value', 'Sales', R)].concat(shop ? [] : h.shops.map((s) => col(s, s, R)))
      .concat([col('receipts', 'Receipts', R), col('perDay', 'Per day', R), col('avgSale', 'Average sale', R), col('share', '% of sales', R)]),
      rows: h.hours.map((x) => ({ label: x.label, value: $(x.value), ...Object.fromEntries(h.shops.map((s) => [s, $(x.shops[s] || 0)])), receipts: x.receipts, perDay: $(x.perDay), avgSale: $(x.avgSale), share: `${x.share}%`,
        _tone: h.peak && x.hour === h.peak.hour ? 'warn' : null })),
      note: 'From the sales by hour each till PC sends every day (all tills added up). Per day = the hour\'s sales over the trading days of the period.' }],
  });
}

// ---------------------------------------------------------------- 4. cashier totals
const CF = ['sales', 'receipts', 'refunds', 'refund_value', 'discounts', 'discount_value', 'voids', 'void_value'];
export function cashierTotals({ from, to, shop = '' }) {
  const per = new Map();
  for (const a of activityInPeriod({ from, to, shop })) {
    for (const [name, c] of Object.entries(a.cashiers || {})) {
      const k = `${a.shop}|${name}`;
      const o = per.get(k) || { name, shop: a.shop, days: new Set(), ...Object.fromEntries(CF.map((f) => [f, 0])) };
      for (const f of CF) o[f] = r2(o[f] + (Number(c && c[f]) || 0));
      o.days.add(a.date);
      per.set(k, o);
    }
  }
  return [...per.values()].map((o) => ({ ...o, days: o.days.size, avgSale: o.receipts ? r2(o.sales / o.receipts) : 0 })).sort((a, b) => b.sales - a.sales);
}
function cashiersReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const list = cashierTotals({ from, to, shop });
  const sum = (f) => r2(list.reduce((t, o) => t + o[f], 0));
  return head('ar_cashiers', 'Cashier Totals', from, to, shop, {
    summary: [{ label: 'Cashiers', value: String(list.length) }, { label: 'Sales', value: $(sum('sales')) }, { label: 'Refunds', value: `${sum('refunds')} · ${$(sum('refund_value'))}` }, { label: 'Voids', value: `${sum('voids')} · ${$(sum('void_value'))}`, tone: sum('voids') ? 'warn' : undefined }],
    sections: [{ title: 'Per cashier', columns: [col('name', 'Cashier'), col('shop', 'Shop'), col('days', 'Days', R), col('sales', 'Sales', R), col('receipts', 'Receipts', R), col('avg', 'Average sale', R),
      col('refunds', 'Refunds', R), col('refund_value', 'Refunded', R), col('voids', 'Voids', R), col('void_value', 'Voided', R), col('discounts', 'Discounts', R), col('discount_value', 'Discounted', R)],
      rows: list.map((o) => ({ name: o.name, shop: o.shop, days: o.days, sales: $(o.sales), receipts: o.receipts, avg: $(o.avgSale), refunds: o.refunds, refund_value: $(o.refund_value), voids: o.voids, void_value: $(o.void_value),
        discounts: o.discounts, discount_value: $(o.discount_value), _tone: o.voids || o.refunds ? 'warn' : null })),
      totals: [{ label: 'Sales', value: $(sum('sales')), strong: true }, { label: 'Refunded', value: $(sum('refund_value')) }, { label: 'Voided', value: $(sum('void_value')) }],
      note: 'From what each till PC sends per cashier every day. Cashier watch (Aronium insights) flags a cashier well above the rest.' }],
  });
}

// ---------------------------------------------------------------- 5. refunds and voids
export function refundsAndVoids({ from, to, shop = '' }) {
  const noted = new Map(safe(() => db().all(`SELECT * FROM aronium_refunds WHERE receipt_date BETWEEN ? AND ?${shop ? ' AND shop_code = ?' : ''} ORDER BY at`, [from, to].concat(shop ? [shop] : [])), []).map((n) => [n.receipt_key, n]));
  const refunds = receiptsInPeriod({ from, to, shop }).filter((r) => r.refund).sort((a, b) => (a.date + a.time < b.date + b.time ? -1 : 1))
    .map((r) => { const n = noted.get(r.key); return { ...r, reason: n ? txt(n.reason) : '', note: n ? txt(n.note) : '', doneInAronium: n ? !!n.done_in_aronium : null, notedBy: n ? txt(n.by_name) : '' }; });
  const voids = zInPeriod({ from, to, shop }).map((z) => ({ date: z.date, shop: z.shop, till: z.till || z.source, number: txt(z.number) || txt(z.key), count: Number(z.voids && z.voids.count) || 0, total: r2(z.voids && z.voids.total), refunds: r2(z.refunds) }))
    .filter((v) => v.count || v.total).sort((a, b) => (a.date < b.date ? -1 : 1));
  const byCashier = cashierTotals({ from, to, shop }).filter((c) => c.voids || c.refunds);
  return { refunds, voids, byCashier, refundTotal: r2(refunds.reduce((t, r) => t + r.total, 0)), voidCount: voids.reduce((t, v) => t + v.count, 0), voidTotal: r2(voids.reduce((t, v) => t + v.total, 0)) };
}
function refundsReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const x = refundsAndVoids({ from, to, shop });
  return head('ar_refunds', 'Refunds And Voids', from, to, shop, {
    summary: [{ label: 'Refunds', value: `${x.refunds.length} · ${$(x.refundTotal)}`, tone: x.refunds.length ? 'warn' : undefined }, { label: 'Voids', value: `${x.voidCount} · ${$(x.voidTotal)}`, tone: x.voidCount ? 'warn' : undefined }],
    sections: [
      { title: 'Refunds (each receipt)', columns: [col('date', 'Date'), col('time', 'Time'), col('shop', 'Shop'), col('till', 'Till'), col('no', 'Receipt'), col('who', 'Cashier'), col('pay', 'Paid back by'), col('total', 'Amount', R), col('reason', 'Reason noted'), col('done', 'Done in Aronium')],
        rows: x.refunds.map((r) => ({ date: r.date, time: r.time.slice(0, 5), shop: r.shop, till: r.source, no: r.no, who: r.who, pay: r.pays.length ? r.pays.map((p) => `${p.name} ${$(p.amount)}`).join(', ') : r.pay, total: $(r.total),
          reason: [r.reason, r.note].filter(Boolean).join(' – '), done: r.doneInAronium === null ? '' : r.doneInAronium ? 'yes' : 'not yet', _tone: r.reason ? null : 'warn' })),
        totals: [{ label: 'Refunded', value: $(x.refundTotal), strong: true }],
        note: `Refund receipts sent by the till PCs (receipts are kept ${L.RECEIPT_DAYS} days). A refund with no reason noted is shaded.` },
      { title: 'Voids (each End of day)', columns: [col('date', 'Date'), col('shop', 'Shop'), col('till', 'Till'), col('number', 'Z no'), col('count', 'Voids', R), col('total', 'Voided', R), col('refunds', 'Refunds on the Z', R)],
        rows: x.voids.map((v) => ({ ...v, total: $(v.total), refunds: $(v.refunds) })), totals: [{ label: 'Voided', value: $(x.voidTotal), strong: true }] },
      { title: 'By cashier', columns: [col('name', 'Cashier'), col('shop', 'Shop'), col('refunds', 'Refunds', R), col('refund_value', 'Refunded', R), col('voids', 'Voids', R), col('void_value', 'Voided', R)],
        rows: x.byCashier.map((c) => ({ name: c.name, shop: c.shop, refunds: c.refunds, refund_value: $(c.refund_value), voids: c.voids, void_value: $(c.void_value) })) },
    ],
  });
}

// ---------------------------------------------------------------- 6. End of day / Z list
const STATE = { matched: 'Agrees', difference: 'Difference', resolved: 'Explained', no_till: 'No till balance' };
export function zList({ from, to, shop = '' }) {
  const feed = new Map(zInPeriod({ from: addDays(from, -1), to: addDays(to, 1), shop }).map((z) => [`EOD-${z.source}-${z.key}`, z]));
  const out = [];
  const seen = new Set();
  if (has('aronium_eods')) {
    for (const e of safe(() => db().all(`SELECT * FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ?${shop ? ' AND shop_code = ?' : ''} ORDER BY eod_date, shop_code, till_name, z_number`, [from, to].concat(shop ? [shop] : [])), [])) {
      const z = feed.get(e.uid) || null;
      seen.add(e.uid);
      out.push({ uid: e.uid, date: e.eod_date, shop: e.shop_code, till: txt(e.till_name) || (z && (z.till || z.source)) || '', number: txt(e.z_number), total: r2(e.total), vat: r2(e.vat), zero: r2(e.zero), cash: r2(e.cash), card: r2(e.card), other: r2(e.other),
        receipts: z ? Number(z.receipts) || 0 : null, refunds: z ? r2(z.refunds) : null, tillTotal: e.till_total === null || e.till_total === undefined ? null : r2(e.till_total), diff: e.diff === null || e.diff === undefined ? null : r2(e.diff),
        state: e.state, matched: e.state === 'matched' || e.state === 'resolved', fromLink: e.source === 'link' || !!z });
    }
  }
  // sent by a till PC but not booked as an End of day yet (e.g. the day is still open on this device)
  for (const [uid, z] of feed) {
    if (seen.has(uid) || z.date < from || z.date > to) continue;
    out.push({ uid, date: z.date, shop: z.shop, till: z.till || z.source, number: txt(z.number), total: r2(z.total), vat: r2(z.vat), zero: r2(z.zero), cash: r2(z.cash), card: r2(z.card), other: r2(z.other),
      receipts: Number(z.receipts) || 0, refunds: r2(z.refunds), tillTotal: null, diff: null, state: 'not_booked', matched: false, fromLink: true });
  }
  return out.sort((a, b) => (`${a.date}${a.shop}${a.till}${a.number.padStart(8, '0')}` < `${b.date}${b.shop}${b.till}${b.number.padStart(8, '0')}` ? -1 : 1));
}
function zReport(from, to, user, params = {}) {
  const shop = periodShop(user, params);
  const list = zList({ from, to, shop });
  const sum = (f) => r2(list.reduce((t, z) => t + (Number(z[f]) || 0), 0));
  const off = list.filter((z) => !z.matched);
  return head('ar_zlist', 'End Of Day List', from, to, shop, {
    summary: [{ label: 'End of days', value: String(list.length) }, { label: 'Total', value: $(sum('total')) }, { label: 'Cash', value: $(sum('cash')) }, { label: 'Not agreeing', value: String(off.length), tone: off.length ? 'bad' : undefined }],
    sections: [{ title: 'End of days (Z)', columns: [col('date', 'Date'), col('shop', 'Shop'), col('till', 'Till'), col('number', 'Z no'), col('total', 'Total', R), col('vat', 'VAT', R), col('zero', 'Zero-rated', R), col('cash', 'Cash', R), col('other', 'M-PAiSA / other', R),
      col('receipts', 'Receipts', R), col('tillTotal', 'Till balance', R), col('diff', 'Difference', R), col('state', 'Matched')],
      rows: list.map((z) => ({ date: z.date, shop: z.shop, till: z.till, number: z.number || '(whole day)', total: $(z.total), vat: $(z.vat), zero: $(z.zero), cash: $(z.cash), other: $(z.card + z.other), receipts: z.receipts === null ? '' : z.receipts,
        tillTotal: z.tillTotal === null ? '' : $(z.tillTotal), diff: z.diff === null ? '' : $(z.diff), state: z.state === 'not_booked' ? 'Not booked yet' : z.matched ? `✓ ${STATE[z.state]}` : `✗ ${STATE[z.state] || z.state}`, _tone: z.matched ? null : z.state === 'difference' ? 'bad' : 'warn' })),
      totals: [{ label: 'Total', value: $(sum('total')), strong: true }, { label: 'VAT', value: $(sum('vat')) }, { label: 'Cash', value: $(sum('cash')) }],
      note: 'Each Aronium End of day, matched to the till balance of that shift (Till & cash › End of days to explain a difference).' }],
  });
}

// Registered in the Aronium module (Reports hub, group "Till & cash"). Sales by day is the Sales history report.
export const PERIOD_REPORTS = [
  { id: 'ar_items', group: 'Till & cash', icon: '🧮', title: 'Items sold (Aronium)', desc: 'Every product sold in the period: quantity, amount, cost; top sellers by amount and by quantity', perm: 'reports', build: itemsReport },
  { id: 'ar_hours', group: 'Till & cash', icon: '🕘', title: 'Sales by hour (Aronium)', desc: 'Sales and receipts for each hour of the day over the period, per shop', perm: 'reports', build: hoursReport },
  { id: 'ar_cashiers', group: 'Till & cash', icon: '🧑‍💼', title: 'Cashier totals (Aronium)', desc: 'Per cashier: sales, receipts, refunds, voids and discounts', perm: 'till_approve', build: cashiersReport },
  { id: 'ar_refunds', group: 'Till & cash', icon: '↩️', title: 'Refunds and voids (Aronium)', desc: 'Each refund receipt with the reason noted, voids on each End of day and per cashier', perm: 'till_approve', build: refundsReport },
  { id: 'ar_zlist', group: 'Till & cash', icon: '📋', title: 'End of day / Z list (Aronium)', desc: 'Each End of day: Z number, till, totals, VAT, cash, agrees with the till balance or not', perm: 'till_approve', build: zReport },
];
// The Sales history report, with VAT, zero-rated, receipts and average sale per day and shop added (one report, not two).
export const withSalesSummary = (r) => (r.id === 'till_sales_history' ? { ...r, desc: 'Sales day by day for each shop and both together: gross, VAT, zero-rated, receipts, average sale (from the till PCs and End of days)', build: salesSummaryReport } : r);
