// 1.0.0 build 5 (owner, 2 Nov): "Get the End of day now" – the owner / admin (any shop) or a manager / supervisor (own
// shop) pulls a shop's Aronium End of day instead of waiting for the till PCs' next send.
//   1. sync now (send + fetch) and bring in the tills' figures: anything already in the cloud comes in at once;
//   2. ask the cloud (link_pull_request) – that shop's till PCs see pull: true on their next 30-second check and send
//      everything (End of days / Z, receipts, the drawer) straight away;
//   3. sync again every 10 seconds for up to 2 minutes until a new End of day for that shop is in.
// The check is HERE (the guard.js way), not only on the screens. Aronium is only read.
import { AppError } from '../../services/core.js';
import { db } from '../../db/connection.js';
import { requireLogin } from '../../services/guard.js';
import * as B from '../till/balanceTill.js';
import { processLink } from './link.js';

export const PULL_ROLES = ['owner', 'admin', 'manager', 'supervisor'];
export const PULL_GAP_MS = 30000; // one ask per shop every 30 s (the cloud says the same)
export const POLL_MS = 10000;
export const WAIT_MS = 120000;
const TOP = ['owner', 'admin'];
const last = {}; // shop → when this device last asked

const shopsAll = () => {
  let rows = [];
  try { rows = require('../admin/service.js').listShops(); } catch (e) { rows = []; }
  rows = rows.filter((s) => /^S\d+$/.test(String(s.code))); // the shops with till PCs (not Bakery / Liquor cost areas)
  if (!rows.length) rows = [{ code: 'S1', name: 'Shop 1' }, { code: 'S2', name: 'Shop 2' }];
  return rows.map((s) => ({ code: s.code, name: `Shop ${String(s.code).replace(/^S/, '')}`, full: s.name || s.code }));
};
export const shopLabel = (code) => `Shop ${String(code || '').replace(/^S/, '')}`;
export const tillLabel = (source) => `Till ${String(source || '').split('-T')[1] || '?'}`;

// The shops this person may pull (Shop 1 / Shop 2 for the owner and admin; their own shop for a manager / supervisor).
export function pullShops(user) {
  if (!user || !PULL_ROLES.includes(user.role)) return [];
  const all = shopsAll();
  if (TOP.includes(user.role)) return all;
  return user.shop_code ? all.filter((s) => s.code === user.shop_code) : [];
}
export const mayPull = (user) => pullShops(user).length > 0;
export function defaultShop(user) {
  const list = pullShops(user);
  return (list.find((s) => user && s.code === user.shop_code) || list[0] || {}).code || '';
}
export function requirePull(user, shop) {
  const u = requireLogin(user) || user; // the person as this device knows them now (null only inside the app's own work)
  if (!u || !PULL_ROLES.includes(u.role)) throw new AppError('Only the owner, an admin, a manager or a supervisor can get the End of day now.');
  if (!/^S\d+$/.test(String(shop || ''))) throw new AppError('Pick the shop first.');
  if (!TOP.includes(u.role) && String(u.shop_code || '') !== String(shop)) throw new AppError('You can only get your own shop\'s End of day.');
  return u;
}

const waitingFor = (user, shop) => {
  let list = [];
  try { list = B.waitingBalances(user); } catch (e) { list = []; }
  return list.filter((w) => w.link && String(w.uid).startsWith(`EOD-${shop}-`));
};
const defaults = (deps = {}) => ({
  sync: deps.sync || (async () => require('../../platform/cloud.js').syncNow({ force: true })),
  call: deps.call || ((body) => require('../../platform/cloud.js').cloudCall(body, 30000)),
  now: deps.now || (() => Date.now()),
});
async function bringIn(d) {
  try { await d.sync(); } catch (e) { /* no internet: what is on this device is still worked */ }
  try { processLink({ limit: 200 }); } catch (e) { /* the next round */ }
}
function arrived(user, job) {
  const fresh = waitingFor(user, job.shop).filter((w) => !job.before.includes(w.uid));
  return fresh.length ? { state: 'arrived', shop: job.shop, eodUid: fresh[0].uid, list: fresh } : null;
}

// Press: → { state: 'arrived', eodUid, list } | { state: 'asked', job } | { state: 'offline', job, error } | { state: 'too_soon', wait }
export async function startPull(user, shop, deps = {}) {
  requirePull(user, shop);
  const d = defaults(deps);
  const t = d.now();
  if (last[shop] && t - last[shop] < PULL_GAP_MS) return { state: 'too_soon', shop, wait: Math.ceil((PULL_GAP_MS - (t - last[shop])) / 1000) };
  const job = { shop, at: t, before: waitingFor(user, shop).map((w) => w.uid), tills: [] };
  await bringIn(d);
  const got = arrived(user, job);
  if (got) return got;
  let r;
  try { r = await d.call({ kind: 'link_pull_request', shopCode: shop }); } catch (e) {
    return { state: 'offline', shop, job, error: String((e && e.message) || e) };
  }
  if (!r || r.ok === false) return { state: 'offline', shop, job, error: (r && r.error) || 'The cloud did not answer.' };
  last[shop] = t;
  job.tills = r.tills || [];
  return { state: 'asked', shop, job, already: !!r.already };
}

// Every POLL_MS while waiting: → arrived | { state: 'waiting', secs } | { state: 'timeout', missing: ['Till 1'], text }
export async function pollPull(user, job, deps = {}) {
  requirePull(user, job.shop);
  const d = defaults(deps);
  await bringIn(d);
  const got = arrived(user, job);
  if (got) return got;
  const secs = Math.round((d.now() - job.at) / 1000);
  if (d.now() - job.at < WAIT_MS) return { state: 'waiting', shop: job.shop, secs };
  let tills = job.tills || [];
  let answered = [];
  try { const s = await d.call({ kind: 'link_pull_request', shopCode: job.shop, check: true }); tills = (s && s.tills) || tills; answered = (s && s.answered) || []; } catch (e) { /* not known */ }
  const missing = tills.filter((x) => !answered.includes(x)).map(tillLabel);
  return { state: 'timeout', shop: job.shop, missing, text: timeoutText(job.shop, missing, tills.length) };
}
export function timeoutText(shop, missing, known = missing.length) {
  if (!known) return `No till PC of ${shopLabel(shop)} has answered – is the till PC on and the Link running?`;
  if (!missing.length) return `${shopLabel(shop)}'s till PCs answered, but no new End of day came in. Has the End of day been done in Aronium?`;
  return missing.length === 1 ? `${missing[0]} has not answered – is the till PC on?` : `${missing.slice(0, -1).join(', ')} and ${missing[missing.length - 1]} have not answered – are the till PCs on?`;
}
// build 30 (owner, 10 Nov): "Send everything again" – the shop's till PCs forget what they sent and send every record
// again (the cloud keeps one copy of each, so nothing is doubled). For an End of day that never came in (missingEod.js).
export const EVERYTHING_WAIT_MS = 300000;
export async function askEverything(user, shop, deps = {}) {
  requirePull(user, shop);
  const d = defaults(deps);
  let r;
  try { r = await d.call({ kind: 'link_pull_request', shopCode: shop, all: true }); } catch (e) {
    return { state: 'offline', shop, error: String((e && e.message) || e) };
  }
  if (!r || r.ok === false) return { state: 'offline', shop, error: (r && r.error) || 'The cloud did not answer.' };
  if (!r.all) return { state: 'old_cloud', shop, error: 'The cloud program needs updating (script 31) for "Send everything again".' };
  last[shop] = d.now();
  return { state: 'asked', shop, job: { shop, at: d.now(), tills: r.tills || [], all: true } };
}
// Every POLL_MS after askEverything: → { state: 'done' } (no End of day missing any more) | { state: 'waiting', secs, left }
// | { state: 'timeout', left, text }
export async function pollEverything(user, job, deps = {}) {
  requirePull(user, job.shop);
  const d = defaults(deps);
  await bringIn(d);
  const gaps = (deps.gaps || (() => require('./missingEod.js').missingEods(job.shop)))();
  const left = gaps.reduce((n, g) => n + g.missing.length, 0);
  if (!left) return { state: 'done', shop: job.shop };
  const secs = Math.round((d.now() - job.at) / 1000);
  if (d.now() - job.at < EVERYTHING_WAIT_MS) return { state: 'waiting', shop: job.shop, secs, left };
  return { state: 'timeout', shop: job.shop, left, text: `${left} End of day${left === 1 ? ' is' : 's are'} still missing after 5 minutes. Is the till PC on, with the Link running and the latest Link? It carries on by itself – check again later.` };
}

// Release 03 (owner, 12 Nov): particular days – the shop's till PCs read those days again from Aronium and send their
// End of days and sales again (cloud script 38, Link with pull_days). from / to: 'YYYY-MM-DD', at most 62 days.
export async function askDays(user, shop, from, to, deps = {}) {
  requirePull(user, shop);
  const ok = (x) => /^\d{4}-\d{2}-\d{2}$/.test(String(x || ''));
  if (!ok(from)) throw new Error('Choose the first day.');
  const last2 = ok(to) && to >= from ? to : from;
  const d = defaults(deps);
  let r;
  try { r = await d.call({ kind: 'link_pull_request', shopCode: shop, from, to: last2 }); } catch (e) {
    return { state: 'offline', shop, error: String((e && e.message) || e) };
  }
  if (!r || r.ok === false) return { state: 'offline', shop, error: (r && r.error) || 'The cloud did not answer.' };
  if (!r.from) return { state: 'old_cloud', shop, error: 'The cloud program needs updating (script 38) to ask for particular days.' };
  last[shop] = d.now();
  return { state: 'asked', shop, job: { shop, at: d.now(), tills: r.tills || [], from, to: last2 } };
}
// After askDays: which till PCs have answered. → { state: 'done' | 'waiting' | 'timeout', answered, tills, secs }
export async function pollDays(user, job, deps = {}) {
  requirePull(user, job.shop);
  const d = defaults(deps);
  await bringIn(d);
  let s = null;
  try { s = await d.call({ kind: 'link_pull_request', shopCode: job.shop, check: true }); } catch (e) { s = null; }
  const tills = (s && s.tills) || job.tills || [];
  const answered = (s && s.answered) || [];
  const secs = Math.round((d.now() - job.at) / 1000);
  if (tills.length && tills.every((t) => answered.includes(t))) return { state: 'done', shop: job.shop, answered, tills, secs };
  if (d.now() - job.at < EVERYTHING_WAIT_MS) return { state: 'waiting', shop: job.shop, answered, tills, secs };
  return { state: 'timeout', shop: job.shop, answered, tills, secs, text: `${tills.filter((t) => !answered.includes(t)).join(', ') || 'A till PC'} has not answered after 5 minutes – is it on, with the latest Link?` };
}

// (tests) forget when this device last asked
export function _resetPull() { Object.keys(last).forEach((k) => { delete last[k]; }); }

// Release 29 (owner, 14 Nov: "can the linker or the app keep checking for the End of day and, if not synced, sync it by
// itself"): the Link already checks every hour that the cloud holds each End of day it sent and sends any missing one
// again (verify_cloud). On top of that, when this device still sees an End of day missing (a gap in the Z numbers) and
// someone who may ask the till PCs is logged in here, the app asks that shop's till PCs to send everything again by
// itself – at most once every 3 hours per shop. Nothing is shown unless it is still missing afterwards.
const AUTO_EVERY_MS = 3 * 3600000;
export async function autoHeal(deps = {}) {
  const P = require('../../services/pins.js');
  const C2 = require('../../services/core.js');
  let uid = '';
  try { uid = deps.uid || P.cloudSessionUid() || ''; } catch (e) { uid = ''; }
  const u = deps.user || (uid ? db().get('SELECT uid, role, shop_code FROM users WHERE uid = ? AND active = 1', [uid]) : null);
  if (!u || !PULL_ROLES.includes(u.role)) return { skipped: 'no one who may ask' };
  const gaps = (deps.gaps || (() => require('./missingEod.js').missingEods()))();
  const shops = [...new Set(gaps.map((g) => g.shop))].filter((sh) => TOP.includes(u.role) || String(u.shop_code || '') === sh);
  const d = defaults(deps);
  const asked = [];
  for (const sh of shops) {
    const k = `auto_eod_ask_${sh}`;
    const lastAt = Number(C2.getSetting(k, '0')) || 0;
    if (lastAt && d.now() - lastAt < AUTO_EVERY_MS) continue;
    C2.setSetting(k, String(d.now()));
    try { const r = await d.call({ kind: 'link_pull_request', shopCode: sh, all: true }); if (r && r.ok !== false) asked.push(sh); } catch (e) { /* the next round */ }
  }
  return { asked };
}
