// v3.9.5 Aronium purchases against the supplier invoices in the app. Purchases typed in Aronium (stock received at
// the till PC) come in through the Aronium link; each is matched to an invoice in the app by supplier, number and total.
// A purchase with no invoice in the app = an invoice that was never given to the office (or not photographed).
// Read only – nothing is written back to Aronium.
import { db } from '../../db/connection.js';
import { dateStr, addDays } from '../../services/core.js';
import { aroniumPurchases } from './link.js';

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const days = (a, b) => Math.abs((Date.parse(`${a}T00:00:00Z`) - Date.parse(`${b}T00:00:00Z`)) / 86400000);

// 1.0.0 build 24 (wholesale): a purchase whose Aronium supplier code is a supplier account number matches only that
// supplier's invoices. And the other way round: an invoice in the app (from a supplier that is in Aronium purchases)
// with no Aronium purchase after a couple of days = "not entered in Aronium".
function supplierByCode() {
  const out = new Map();
  try {
    for (const r of db().all("SELECT number, aronium_code, ap_supplier_uid FROM trade_accounts WHERE kind = 'supplier' AND ap_supplier_uid IS NOT NULL")) {
      if (r.aronium_code) out.set(norm(r.aronium_code), r.ap_supplier_uid);
      out.set(norm(r.number), r.ap_supplier_uid);
    }
  } catch (e) { /* no trade accounts on this device */ }
  return out;
}
export const NOT_IN_ARONIUM_AFTER_DAYS = 2;
export function purchasesCheck({ from = addDays(dateStr(), -60), to = dateStr() } = {}) {
  let list = [];
  try { list = aroniumPurchases({ from }).filter((p) => p && typeof p === 'object' && p.date >= from && p.date <= to); } catch (e) { list = []; }
  // The same purchase can come from two tills of one shop: keep it once.
  const seen = new Set();
  list = list.filter((p) => { const k = `${p.shop}|${p.id}`; if (seen.has(k)) return false; seen.add(k); return true; });
  let invoices = [];
  try {
    invoices = db().all("SELECT uid, supplier_uid, supplier_name, invoice_no, invoice_date, total, shop_code, status FROM ap_invoices WHERE IFNULL(status,'') <> 'void' AND IFNULL(kind,'invoice') <> 'credit' AND invoice_date BETWEEN ? AND ?",
      [addDays(from, -10), addDays(to, 10)]);
  } catch (e) { invoices = []; }
  const used = new Set();
  const codes = supplierByCode();
  const out = { matched: [], missing: [], notInAronium: [], from, to };
  for (const p of list) {
    const ps = norm(p.supplier);
    const byCode = p.supplier_code ? codes.get(norm(p.supplier_code)) : null;
    const nums = [norm(p.reference), norm(p.number)].filter((x) => x.length >= 3);
    const cands = invoices.filter((i) => !used.has(i.uid) && (byCode ? i.supplier_uid === byCode : ps.length < 3 || (() => { const s = norm(i.supplier_name); return s && (s === ps || (s.length >= 4 && (s.includes(ps) || ps.includes(s)))); })()));
    let best = cands.find((i) => nums.length && nums.includes(norm(i.invoice_no)));
    let how = 'number';
    if (!best) { best = cands.find((i) => Math.abs(r2(i.total) - r2(p.total)) <= 0.05 && days(i.invoice_date, p.date) <= 7); how = 'total'; }
    if (best) { used.add(best.uid); out.matched.push({ ...p, invoice: best, how, diff: r2(r2(p.total) - r2(best.total)) }); }
    else out.missing.push(p);
  }
  out.differ = out.matched.filter((m) => Math.abs(m.diff) > 0.05);
  // Not entered in Aronium: only suppliers that do show up in Aronium purchases (bills like power or rent never do),
  // only invoices a couple of days old (the office has time to type them), only while purchases are coming in at all.
  if (list.length) {
    const inAronium = new Set(list.map((p) => norm(p.supplier)).filter(Boolean));
    const codeSuppliers = new Set(list.map((p) => (p.supplier_code ? codes.get(norm(p.supplier_code)) : null)).filter(Boolean));
    const firstDay = list.reduce((m, p) => (p.date < m ? p.date : m), to);
    const lastDay = addDays(to, -NOT_IN_ARONIUM_AFTER_DAYS);
    for (const i of invoices) {
      if (used.has(i.uid) || i.status === 'void' || i.invoice_date < firstDay || i.invoice_date > lastDay || i.invoice_date < from) continue;
      if (!codeSuppliers.has(i.supplier_uid) && !inAronium.has(norm(i.supplier_name))) continue;
      out.notInAronium.push(i);
    }
  }
  return out;
}
