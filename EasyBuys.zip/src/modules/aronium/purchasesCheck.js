// v3.9.5 Aronium purchases against the supplier invoices in the app. Purchases typed in Aronium (stock received at
// the till PC) come in through the Aronium link; each is matched to an invoice in the app by supplier, number and total.
// A purchase with no invoice in the app = an invoice that was never given to the office (or not photographed).
// Read only – nothing is written back to Aronium.
import { db } from '../../db/connection.js';
import { dateStr, addDays } from '../../services/core.js';
import { aroniumPurchases } from './link.js';

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const days = (a, b) => Math.abs((Date.parse(`${a}T00:00:00Z`) - Date.parse(`${b}T00:00:00Z`)) / 86400000);

export function purchasesCheck({ from = addDays(dateStr(), -60), to = dateStr() } = {}) {
  let list = [];
  try { list = aroniumPurchases({ from }).filter((p) => p && typeof p === 'object' && p.date >= from && p.date <= to); } catch (e) { list = []; }
  // The same purchase can come from two tills of one shop: keep it once.
  const seen = new Set();
  list = list.filter((p) => { const k = `${p.shop}|${p.id}`; if (seen.has(k)) return false; seen.add(k); return true; });
  let invoices = [];
  try {
    invoices = db().all("SELECT uid, supplier_uid, supplier_name, invoice_no, invoice_date, total, shop_code, status FROM ap_invoices WHERE IFNULL(status,'') <> 'void' AND IFNULL(kind,'invoice') <> 'credit' AND invoice_date BETWEEN ? AND ?",
      [addDays(from, -10), addDays(to, 10)]);
  } catch (e) { invoices = []; }
  const used = new Set();
  const out = { matched: [], missing: [], from, to };
  for (const p of list) {
    const ps = norm(p.supplier);
    const nums = [norm(p.reference), norm(p.number)].filter((x) => x.length >= 3);
    const cands = invoices.filter((i) => !used.has(i.uid) && (ps.length < 3 || (() => { const s = norm(i.supplier_name); return s && (s === ps || (s.length >= 4 && (s.includes(ps) || ps.includes(s)))); })()));
    let best = cands.find((i) => nums.length && nums.includes(norm(i.invoice_no)));
    let how = 'number';
    if (!best) { best = cands.find((i) => Math.abs(r2(i.total) - r2(p.total)) <= 0.05 && days(i.invoice_date, p.date) <= 7); how = 'total'; }
    if (best) { used.add(best.uid); out.matched.push({ ...p, invoice: best, how, diff: r2(r2(p.total) - r2(best.total)) }); }
    else out.missing.push(p);
  }
  out.differ = out.matched.filter((m) => Math.abs(m.diff) > 0.05);
  return out;
}
