// 1.0.0 The one Aronium place: the till PCs, each receipt with what was sold on it, the items sold (by day, shift and
// till), End of days, the cash that should be in each till now, the Link's own events (stopped, database changed…) and
// customer refunds noted against the receipt. Everything comes from the Aronium Link and is only READ – the app never
// writes to Aronium (a refund is done in Aronium; here it is only noted, with the reason).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, dateStr, addDays, audit, clock, realFromWall, wallFromReal } from '../../services/core.js';
import { can, actsAsOwner } from '../../services/access.js';
import * as L from './link.js';
import { requirePerm, asService } from '../../services/guard.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };
const ok = (d) => /^\d{4}-\d{2}-\d{2}$/.test(String(d || ''));
const parseUtc = (s) => { const x = String(s || ''); const t = Date.parse(/Z$/.test(x) ? x : `${x.replace(' ', 'T').slice(0, 19)}Z`); return Number.isFinite(t) ? t : null; };

// ---------------------------------------------------------------- who sees what
const boss = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
// The whole Aronium place (tills, items sold, End of days, product changes): owner / admin / managers / till approvers.
export function canSeeAronium(u) { return !!u && (boss(u) || u.role === 'manager' || can(u, 'till_approve') || can(u, 'settings') || can(u, 'reports')); }
// Receipts (for a customer refund): anyone working a shop, for their own shop; the office for both.
export function canSeeReceipts(u) { return !!u && u.role !== 'accountant' && !['worker', 'bakery'].includes(u.role); }
// The shops a person may see receipts of ('' = all).
export function receiptShop(u, wanted = '') {
  if (!u) return null;
  if (boss(u) || can(u, 'till_approve') || can(u, 'reports')) return wanted || '';
  return u.shop_code || u.shopCode || wanted || '';
}

// ---------------------------------------------------------------- product names for the receipt lines
let names = null;
function nameMap() {
  if (names && Date.now() - names.at < 60000) return names.m;
  const m = new Map();
  safe(() => db().all('SELECT code, name FROM inv_items WHERE code IS NOT NULL').forEach((x) => { if (txt(x.code)) m.set(txt(x.code).toUpperCase(), x.name); }), null);
  for (const shop of ['S1', 'S2']) {
    for (const p of safe(() => L.aroniumProducts(shop).items, []) || []) {
      const k = txt(p.code).toUpperCase();
      if (k && !m.has(k) && txt(p.name)) m.set(k, txt(p.name));
    }
  }
  names = { at: Date.now(), m };
  return m;
}
export function productName(code) { return nameMap().get(txt(code).toUpperCase()) || `Product ${txt(code)}`; }
export function forgetNames() { names = null; }

// ---------------------------------------------------------------- receipts
// The receipts of a day (newest first), each with its lines named. { date, shop, source, q, refunds }
export function receiptList({ date = dateStr(), shop = '', source = '', q = '', refunds = false, limit = 300 } = {}) {
  if (!ok(date)) date = dateStr();
  let list = safe(() => L.aroniumReceipts({ date, shop }), []);
  if (source) list = list.filter((r) => r.source === source);
  if (refunds) list = list.filter((r) => r.refund);
  const words = txt(q).toLowerCase().split(/\s+/).filter(Boolean);
  const named = list.map((r) => ({ ...r, lineNames: r.items.map((l) => productName(l.code)) }));
  const hit = words.length ? named.filter((r) => words.every((w) => `${r.no} ${r.time} ${r.who} ${r.total.toFixed(2)} ${r.lineNames.join(' ')}`.toLowerCase().includes(w))) : named;
  return hit.slice(0, limit);
}
// One receipt by its key ('S1-T1|2026-11-01|S-1042'), with the lines named, the End of day it went into and any
// refund noted against it.
export function getReceipt(key) {
  const [source, date] = txt(key).split('|');
  if (!source || !ok(date)) return null;
  const r = safe(() => L.aroniumReceipts({ date, shop: L.SHOP_OF(source) }), []).find((x) => x.key === key);
  if (!r) return null;
  const lines = r.items.map((l) => ({ ...l, name: productName(l.code) }));
  const zs = safe(() => L.aroniumZByDay({ from: addDays(date, -1) }), []).filter((z) => z.source === source);
  const z = r.z !== null ? zs.find((x) => Number(x.z_id) === r.z) : null;
  return { ...r, itemCount: r.lines, lines, linesTotal: r2(lines.reduce((t, l) => t + l.total, 0)), discount: r2(lines.reduce((t, l) => t + l.disc, 0)),
    endOfDay: r.z !== null ? (z ? `End of day ${z.number || r.z}` : `End of day ${r.z}`) : r.open === 1 ? 'Still in the till (no End of day yet)' : '',
    refundNote: refundFor(key) };
}

// ---------------------------------------------------------------- customer refunds (noted; done in Aronium)
export const REFUND_REASONS = ['Damaged or torn', 'Expired / off', 'Wrong item', 'Charged twice / wrong price', 'Customer changed their mind', 'Something else'];
export function refundFor(key) { return safe(() => db().get('SELECT * FROM aronium_refunds WHERE receipt_key = ? ORDER BY at DESC LIMIT 1', [key]), null); }
export function listRefunds({ from = addDays(dateStr(), -30), to = dateStr(), shop = '' } = {}) {
  return safe(() => db().all(`SELECT * FROM aronium_refunds WHERE receipt_date BETWEEN ? AND ?${shop ? ' AND shop_code = ?' : ''} ORDER BY at DESC`, [from, to].concat(shop ? [shop] : [])), []);
}
// done: 'yes' (the refund was done in Aronium) or 'no' (not yet – the office follows it up); reason from REFUND_REASONS.
export function saveRefund(user, key, { done, reason, note = '', lines = null } = {}) {
  requirePerm(user, ['till_count', 'till_approve', 'shop_staff'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && canSeeReceipts(user), 'You cannot note refunds.');
  const r = getReceipt(key);
  need(r, 'That receipt is not here (it comes from Aronium).');
  const only = receiptShop(user, r.shop);
  need(!only || only === r.shop, 'That receipt is from another shop.');
  need(['yes', 'no'].includes(done), 'Say if the refund was done in Aronium.');
  need(REFUND_REASONS.includes(reason), 'Choose why.');
  need(reason !== 'Something else' || txt(note).length >= 3, 'Say what happened.');
  const now = stamp();
  const uid = uuid('RF');
  const items = Array.isArray(lines) && lines.length ? lines.filter((l) => r.lines.some((x) => x.code === l.code)).map((l) => ({ code: l.code, qty: q3(l.qty) })) : null;
  db().run(`INSERT INTO aronium_refunds (uid, receipt_key, source, shop_code, receipt_date, receipt_no, receipt_time, total, done_in_aronium, reason, note, items, by_uid, by_name, at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [uid, key, r.source, r.shop, r.date, r.no || null, r.time, r.total, done === 'yes' ? 1 : 0, reason, txt(note) || null,
    items ? JSON.stringify(items) : null, user.uid || null, user.name || null, now, now, deviceId()]);
  audit({ user, action: `Customer refund noted on receipt ${r.no || r.time} (${r.shop}, $${r.total.toFixed(2)}): ${reason}${done === 'yes' ? ' – done in Aronium' : ' – NOT yet done in Aronium'}`, table: 'aronium_refunds', recordUid: uid });
  return uid;
  });
}
// Refunds noted as "not done in Aronium yet", and Aronium refunds with no reason noted (for the office).
export function refundsToCheck({ days = 7, today = dateStr() } = {}) {
  const from = addDays(today, -days + 1);
  const notDone = listRefunds({ from, to: today }).filter((x) => !x.done_in_aronium);
  const noted = new Set(listRefunds({ from, to: today }).map((x) => x.receipt_key));
  const noReason = [];
  for (let i = 0; i < days; i += 1) {
    const d = addDays(today, -i);
    for (const r of safe(() => L.aroniumReceipts({ date: d }), [])) if (r.refund && !noted.has(r.key)) noReason.push(r);
  }
  return { notDone, noReason };
}

// ---------------------------------------------------------------- items sold
// by: 'day' (one list), 'till' (a list per till PC) or 'shift' (a list per End of day – each shift change has one).
// From the receipts (to the item) while they are kept (90 days); older days from the day totals the till PCs send.
export function itemsSold({ date = dateStr(), shop = '', by = 'day' } = {}) {
  if (!ok(date)) date = dateStr();
  const rc = safe(() => L.aroniumReceipts({ date, shop }), []);
  const withLines = rc.filter((r) => r.items.length);
  const groups = new Map();
  const zs = safe(() => L.aroniumZByDay({ from: addDays(date, -1) }), []);
  const label = (r) => {
    if (by === 'till') return { key: r.source, label: tillLabel(r.source) };
    if (by === 'shift') {
      if (r.z === null) return { key: `${r.source}|open`, label: `${tillLabel(r.source)} · now (no End of day yet)` };
      const z = zs.find((x) => x.source === r.source && Number(x.z_id) === r.z);
      return { key: `${r.source}|${r.z}`, label: `${tillLabel(r.source)} · End of day ${z ? z.number || r.z : r.z}${z && z.closed_at ? ` (${String(z.closed_at).slice(11, 16)})` : ''}` };
    }
    return { key: 'all', label: shop ? `${shop} – all tills` : 'Both shops' };
  };
  let fromReceipts = withLines.length > 0;
  if (fromReceipts) {
    for (const r of withLines) {
      const g0 = label(r);
      const g = groups.get(g0.key) || { ...g0, items: new Map(), receipts: 0 };
      g.receipts += r.refund ? 0 : 1;
      for (const l of r.items) {
        const k = l.code.toUpperCase();
        const it = g.items.get(k) || { code: l.code, name: productName(l.code), qty: 0, value: 0, refunded: 0 };
        if (r.refund) { it.refunded = q3(it.refunded + l.qty); it.qty = q3(it.qty - l.qty); it.value = r2(it.value - l.total); } else { it.qty = q3(it.qty + l.qty); it.value = r2(it.value + l.total); }
        g.items.set(k, it);
      }
      groups.set(g0.key, g);
    }
  } else if (by !== 'shift') {
    // older days (or an older Link): the day totals per product per till
    for (const d of safe(() => L.aroniumSalesByDay({ from: date, withLines: true }), [])) {
      if (d.date !== date || (shop && d.shop !== shop)) continue;
      const g0 = by === 'till' ? { key: d.source, label: tillLabel(d.source) } : { key: 'all', label: shop ? `${shop} – all tills` : 'Both shops' };
      const g = groups.get(g0.key) || { ...g0, items: new Map(), receipts: 0 };
      for (const l of d.lines || []) {
        const k = txt(l.code || l.name).toUpperCase();
        const it = g.items.get(k) || { code: txt(l.code), name: txt(l.name) || productName(l.code), qty: 0, value: 0, refunded: 0 };
        it.qty = q3(it.qty + (Number(l.net) || 0)); it.value = r2(it.value + (Number(l.sold_value) || 0) - (Number(l.refund_value) || 0)); it.refunded = q3(it.refunded + (Number(l.refunded) || 0));
        g.items.set(k, it);
      }
      groups.set(g0.key, g);
    }
  }
  const out = [...groups.values()].map((g) => {
    const items = [...g.items.values()].filter((i) => Math.abs(i.qty) > 0.0005 || i.refunded).sort((a, b) => b.qty - a.qty || a.name.localeCompare(b.name));
    return { key: g.key, label: g.label, receipts: g.receipts, items, qty: q3(items.reduce((t, i) => t + i.qty, 0)), value: r2(items.reduce((t, i) => t + i.value, 0)) };
  }).sort((a, b) => a.label.localeCompare(b.label));
  if (!out.length) fromReceipts = false;
  return { date, shop: shop || null, by, groups: out, qty: q3(out.reduce((t, g) => t + g.qty, 0)), value: r2(out.reduce((t, g) => t + g.value, 0)), fromReceipts,
    note: !fromReceipts && by === 'shift' ? 'By shift needs the receipts from the till PCs (kept for 90 days).' : '' };
}

// ---------------------------------------------------------------- till PCs, End of days, Link events
export const isCashName = (n) => L.isCash(n);
export function tillLabel(source) {
  const [shop, t] = txt(source).split('-');
  const n = (t || '').replace(/^T/i, '');
  return `${shop === 'S1' ? 'Shop 1' : shop === 'S2' ? 'Shop 2' : shop} Till ${n || '?'}`;
}
const hm12 = (ms) => { const d = wallFromReal(ms); /* Fiji time of a real instant */ let h = d.getHours(); const m = String(d.getMinutes()).padStart(2, '0'); const ap = h >= 12 ? 'pm' : 'am'; h = h % 12 || 12; return `${h}:${m} ${ap}`; };
export function agoText(ms, now = realFromWall(clock.now())) {
  if (ms === null || ms === undefined) return 'never';
  const s = Math.max(0, Math.round((now - ms) / 1000));
  if (s < 60) return `${s} s ago`;
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} days ago`;
}
// Each till PC now: { source, label, shop, lastSeen, ago, state: 'ok' | 'slow' | 'off', text, version, drawer }
export function tillPcs({ now = clock.now() } = {}) {
  const st = safe(() => L.linkStatus().tills, []) || [];
  return st.map((t) => {
    const seen = parseUtc(t.lastSeen);
    const realNow = realFromWall(now); // the till PC's time is a real (UTC) instant; now is a Fiji wall-time Date
    const mins = seen === null ? Infinity : (realNow - seen) / 60000;
    const state = mins <= 20 ? 'ok' : mins <= 45 ? 'slow' : 'off';
    return { source: t.source, label: tillLabel(t.source), shop: t.shop, lastSeen: t.lastSeen, version: t.version, state,
      text: seen === null ? 'nothing sent yet' : state === 'off' ? `off since ${hm12(seen)}${mins > 24 * 60 ? ` (${agoText(seen, realNow)})` : ''}` : `sent ${agoText(seen, realNow)}`, lastZ: t.lastZ };
  });
}
export function endOfDays({ days = 14, shop = '', today = dateStr() } = {}) {
  return safe(() => L.aroniumZByDay({ from: addDays(today, -days + 1) }), [])
    .filter((z) => !shop || z.shop === shop)
    .map((z) => ({ ...z, label: tillLabel(z.source), when: txt(z.closed_at).slice(0, 16).replace('T', ' ') || z.date, total: r2(z.total), cash: r2(z.cash) }))
    .sort((a, b) => (a.when < b.when ? 1 : -1));
}
export const EVENT_TEXT = {
  stopped: 'Sending was switched off (with the Link PIN)', started: 'Sending switched on again', uninstalled: 'The Aronium Link was REMOVED',
  stop_file: 'Sending was stopped (stop file – not with the Link PIN)', task_missing: 'The Link\'s start-up task was deleted or switched off (put back)',
  task_back: 'The start-up task is back', database_changed: 'The Aronium database was CHANGED', cloud_key_changed: 'The cloud address or till key was changed',
  settings_changed: 'Settings were changed', wrong_pin: 'A wrong Link PIN was typed', wrong_admin_pin: 'A wrong admin PIN was typed', admin_pin_set: 'The admin PIN was set or changed',
};
export const URGENT_EVENTS = ['uninstalled', 'stop_file', 'task_missing', 'database_changed', 'cloud_key_changed', 'wrong_admin_pin'];
// The Link's own events from every till PC (newest first): { source, label, event, text, at, who, pc, detail, urgent }
export function linkEvents({ days = 30, now = clock.now() } = {}) {
  const since = now.getTime() - days * 86400000;
  const rows = safe(() => db().all("SELECT source, data FROM aronium_feed WHERE kind IN ('link_event', 'notice')"), []);
  const seen = new Set();
  const out = [];
  for (const r of rows) {
    const d = J(r.data, {});
    const at = parseUtc(d.at);
    if (!d.event || at === null || at < since) continue;
    const k = `${r.source}|${d.event}|${d.at}`;
    if (seen.has(k)) continue; // the old 'notice' copy of the same event
    seen.add(k);
    out.push({ source: r.source, label: tillLabel(r.source), event: d.event, text: EVENT_TEXT[d.event] || `Link: ${d.event}`, at: d.at, atMs: at, who: txt(d.who), pc: txt(d.pc),
      detail: d.detail && typeof d.detail === 'object' ? d.detail : null, urgent: URGENT_EVENTS.includes(d.event) });
  }
  return out.sort((a, b) => b.atMs - a.atMs);
}

// ---------------------------------------------------------------- warnings (Home and phone notifications)
// • URGENT "Till PC silent while the shop is open" (45 minutes; the till PCs send at least every 15 minutes);
// • URGENT Link events: removed, stopped without the PIN, task deleted, database or key changed, wrong admin PIN;
// • customer refunds noted as not yet done in Aronium.
export function aroniumAlerts(user, { now = clock.now() } = {}) {
  if (!canSeeAronium(user)) return [];
  const out = [];
  const W = safe(() => require('../till/salesWatch.js'), null);
  for (const q of (W ? safe(() => W.linkWatch({ now }).quiet, []) : [])) {
    out.push({ id: `link-silent-${q.source}-${dateStr(now)}`, level: 'urgent', notify: true,
      text: `Till PC silent while the shop is open: ${tillLabel(q.source)} – nothing for ${q.mins >= 120 ? `${Math.floor(q.mins / 60)} h ${q.mins % 60} min` : `${q.mins} min`}`,
      sub: 'Is the till PC on and online, and is the Aronium Link running? Sales on it are not being seen.', nav: { screen: 'AroniumHub', params: {} } });
  }
  const evs = linkEvents({ days: 14, now });
  for (const e of evs) {
    // a stop followed by a start, or a missing task put back, is no longer urgent
    if (!e.urgent) continue;
    const later = evs.filter((x) => x.source === e.source && x.atMs > e.atMs);
    if ((e.event === 'stop_file' || e.event === 'task_missing') && later.some((x) => ['started', 'task_back'].includes(x.event))) continue;
    // stopped with the Link PIN a moment before (the window writes the stop file after telling the app): shown, not urgent
    if (e.event === 'stop_file' && evs.some((x) => x.source === e.source && x.event === 'stopped' && x.atMs <= e.atMs && e.atMs - x.atMs < 30 * 60000)) continue;
    out.push({ id: `link-event-${e.source}-${e.event}-${e.at}`, level: 'urgent', notify: true, text: `${e.label}: ${e.text}`,
      sub: `${String(e.at).slice(0, 16).replace('T', ' ')} UTC${e.who ? ` · Windows user ${e.who}` : ''}${e.pc ? ` on ${e.pc}` : ''}${e.detail && e.detail.new ? ` · now: ${e.detail.new}` : ''}. If it was not you, check the till PC.`,
      nav: { screen: 'AroniumHub', params: { tab: 'link' } } });
  }
  const rf = safe(() => refundsToCheck({ today: dateStr(now) }), { notDone: [], noReason: [] });
  if (rf.notDone.length) out.push({ id: `refund-notdone-${rf.notDone.length}`, level: 'warning', text: `${rf.notDone.length} customer refund${rf.notDone.length === 1 ? '' : 's'} noted but not yet done in Aronium`, nav: { screen: 'AroniumHub', params: { tab: 'refunds' } } });
  return out;
}

// ---------------------------------------------------------------- the hub, at a glance
export function hubSummary({ shop = '', now = clock.now() } = {}) {
  const today = dateStr(now);
  const rc = safe(() => L.aroniumReceipts({ date: today, shop }), []);
  const sold = rc.filter((r) => !r.refund);
  const refunds = rc.filter((r) => r.refund);
  const items = sold.reduce((t, r) => t + r.items.reduce((s, l) => s + l.qty, 0), 0) - refunds.reduce((t, r) => t + r.items.reduce((s, l) => s + l.qty, 0), 0);
  const W = safe(() => require('../till/salesWatch.js'), null);
  const watch = W ? safe(() => W.salesWatch({ now }), null) : null;
  // 2 Nov: when a till PC sends its day total but not (yet) its receipts, show the day total rather than $0.00
  const fromReceipts = r2(sold.reduce((t, r) => t + r.total, 0) - refunds.reduce((t, r) => t + r.total, 0));
  const dayTotal = rc.length ? 0 : r2(safe(() => L.aroniumSalesByDay({ from: today }), []).filter((x) => x.date === today && (!shop || x.shop === shop)).reduce((t, x) => t + (Number(x.value) || 0), 0));
  return { today, tills: tillPcs({ now }).filter((t) => !shop || t.shop === shop), receipts: sold.length, sales: rc.length ? fromReceipts : dayTotal, noReceipts: !rc.length && dayTotal > 0,
    refunds: refunds.length, items: q3(items), last: rc.length ? rc[0].time.slice(0, 5) : null,
    drawers: safe(() => L.tillDrawer({ date: today, shop }), []),
    started: watch ? (watch.started || []).filter((t) => !shop || t.shop === shop) : [], quiet: watch ? (watch.quiet || []).filter((q) => !shop || q.shop === shop) : [],
    events: linkEvents({ days: 7, now }).filter((e) => !shop || L.SHOP_OF(e.source) === shop).slice(0, 10) };
}
