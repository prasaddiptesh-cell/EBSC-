// Bakery warnings for Home: the bakery day left open after the baker clocked out; deliveries not in the Bakery stock.
import { can } from '../../services/access.js';
import { dayNotClosedWarnings } from './day.js';
import { bakeryHere, unmatchedBakeryLines } from './store.js';

export function alerts(user) {
  if (!can(user, 'bakery')) return [];
  const out = [];
  try {
    const names = dayNotClosedWarnings();
    if (names.length) out.push({ id: 'bk-day-open', level: 'warning', text: 'Bakery day not closed', sub: `${names.join(', ')} clocked out but the bakery day is still open. Close & count it.`, nav: { screen: 'BakeryToday', params: {} } });
  } catch (e) { /* no bakery data on this device */ }
  try {
    if (bakeryHere()) {
      const u = unmatchedBakeryLines();
      if (u.length) out.push({ id: 'bk-unmatched', level: 'warning', text: 'Bakery delivery not in the Bakery stock', sub: `${u.map((x) => x.material).join(', ')} – check the ingredient names.`, nav: { screen: 'Materials', params: {} } });
    }
  } catch (e) { /* ignore */ }
  return out;
}
