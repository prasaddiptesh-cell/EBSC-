// The baker's day, one step after the other:
//   1 Clock in (the main Time Clock – one timesheet, no separate bakery hours)
//   2 Opening stock (count what is there; this opens the bakery day)
//   3 Opening checklists
//   4 Baking (new batches only after 1–3; owner / admin can always)
//   5 Closing checklists
//   6 Close & count (close, count and balance the stock in one step)
//   7 Clock out (the main Time Clock)
import { db } from '../../db/connection.js';
import { AppError, dateStr } from '../../services/core.js';
import { reasonRequired } from '../../services/access.js';
import { getOpenShift, getClosedShift, closeShift, approveShift, getBalanceSheet, checkVariance, signOff } from '../../services/shifts.js';
import { myChecklists } from '../../services/checklists.js';
import { listActiveBatches } from '../../services/batches.js';
import { stateOf } from '../timeclock/service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };

function todaysShift() {
  return getOpenShift() || db().get("SELECT * FROM shifts WHERE shift_date = ? ORDER BY id DESC LIMIT 1", [dateStr()]) || null;
}
function lists(user, when) {
  let all = [];
  try { all = myChecklists(user.id); } catch (e) { all = []; }
  return all.filter((l) => (when === 'start' ? ['start', 'daily'].includes(l.when_due) : l.when_due === 'end'));
}

export function bakerDay(user) {
  const open = getOpenShift();
  const waiting = open ? null : getClosedShift();
  const today = todaysShift();
  const closedToday = !open && today && ['closed', 'approved'].includes(today.status);
  let clockState = 'out';
  try { clockState = user.uid ? stateOf(user.uid).state : 'out'; } catch (e) { clockState = 'out'; }
  const clockedIn = clockState !== 'out';
  const startLists = open ? lists(user, 'start') : [];
  const endLists = open ? lists(user, 'end') : [];
  const startLeft = startLists.reduce((a, l) => a + l.left, 0);
  const endLeft = endLists.reduce((a, l) => a + l.left, 0);
  let batches = [];
  try { batches = open ? listActiveBatches() : []; } catch (e) { batches = []; }
  const steps = [
    { key: 'clock-in', title: 'Clock in', done: clockedIn || closedToday, note: clockedIn ? 'Clocked in' : 'Time Clock – the same as every shift' },
    { key: 'opening', title: 'Opening stock', done: !!open || !!closedToday, note: open ? `Day opened (${open.shift_name})` : 'Count what is in the bakery store' },
    { key: 'start-lists', title: 'Opening checklists', done: (!!open && startLeft === 0) || !!closedToday, note: open ? (startLeft ? `${startLeft} left` : 'Done') : '' },
    { key: 'baking', title: 'Baking', done: !!closedToday, note: open ? `${batches.length} batch${batches.length === 1 ? '' : 'es'} in progress` : '' },
    { key: 'end-lists', title: 'Closing checklists', done: (!!open && endLeft === 0 && !!endLists.length) || !!closedToday, note: open ? (endLeft ? `${endLeft} left` : endLists.length ? 'Done' : 'None set up') : '' },
    { key: 'close', title: 'Close & count', done: !!closedToday, note: closedToday ? (today.status === 'approved' ? 'Counted and balanced' : 'Waiting for the count') : 'Close, count and balance the stock' },
    { key: 'clock-out', title: 'Clock out', done: !!closedToday && !clockedIn, note: 'Time Clock' },
  ];
  // The first step not done is the one to do now (closing checklists count as done when there are none).
  if (open && !endLists.length) steps[4].done = true;
  const now = steps.find((s) => !s.done) || null;
  const bakingOpen = !!open && clockedIn && startLeft === 0;
  return { open, waiting, today, closedToday, clockedIn, clockState, startLists, endLists, batches, steps, now: now ? now.key : null, bakingOpen,
    mayOverride: !reasonRequired(user) };
}

// New batches only when the day is open, the baker is clocked in and the opening checklists are done.
export function bakingLocked(user) {
  const d = bakerDay(user);
  if (d.bakingOpen || d.mayOverride) return null;
  if (!d.open) return 'Open the bakery day first (Opening stock).';
  if (!d.clockedIn) return 'Clock in first.';
  return 'Finish the opening checklists first.';
}

// Close the day, count and balance in one go (the person closing does the count). Everything is checked first, so a
// mistake never leaves the day half closed.
export function closeAndCount(user, counts = {}, reasons = {}, notes = '') {
  const open = getOpenShift();
  need(open, 'The bakery day is not open.');
  const sheet = getBalanceSheet(open.id);
  const missing = sheet.filter((r) => counts[r.material_id] === undefined || counts[r.material_id] === null || counts[r.material_id] === '' || !Number.isFinite(Number(counts[r.material_id])));
  need(!missing.length, `Count these: ${missing.map((m) => m.name).join(', ')}.`);
  need(!sheet.some((r) => Number(counts[r.material_id]) < 0), 'Counts cannot be negative.');
  if (reasonRequired(user)) {
    const why = sheet.filter((r) => checkVariance(r.expected, Number(counts[r.material_id]), r.tolerance_pct).over && !String(reasons[r.material_id] || '').trim());
    need(!why.length, `More or less than expected – say why for: ${why.map((m) => m.name).join(', ')}.`);
  }
  let active = [];
  try { active = listActiveBatches(); } catch (e) { active = []; }
  need(!active.length, `Finish these batches first: ${active.map((b) => `${b.product_name} (${b.code})`).join(', ')}.`);
  closeShift(user.id, notes);
  // Everyone still on the bakery day is signed off with it (their hours are the Time Clock's).
  db().all('SELECT user_id FROM shift_workers WHERE shift_id = ? AND signed_off_at IS NULL', [open.id]).forEach((w) => { try { signOff(w.user_id, null, user.id, open.id); } catch (e) { /* shown on the balance */ } });
  return approveShift(user.id, open.id, counts, reasons, notes);
}
// The rows to count (what the app expects now).
export function countSheet() {
  const open = getOpenShift();
  if (!open) return [];
  return getBalanceSheet(open.id);
}

// Warning: someone on the bakery day clocked out while the day is still open.
export function dayNotClosedWarnings() {
  const open = getOpenShift();
  if (!open) return [];
  const rows = db().all('SELECT u.uid, u.name FROM shift_workers sw JOIN users u ON u.id = sw.user_id WHERE sw.shift_id = ? AND sw.signed_off_at IS NULL', [open.id]);
  return rows.filter((r) => {
    try { const s = stateOf(r.uid); return s.state === 'out' && s.since && s.since > open.opened_at; } catch (e) { return false; }
  }).map((r) => r.name);
}
