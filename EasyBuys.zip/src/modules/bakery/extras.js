// Bakery extras: recipe costing (cost per piece from today's ingredient prices, margin against the Aronium price)
// and a production plan for each day of the week from what was made in the last weeks.
import { db } from '../../db/connection.js';
import { stamp, dateStr, addDays, money } from '../../services/core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const $ = (n) => money(r2(n));
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);

export function recipeCosting() {
  const prods = db().all('SELECT * FROM products WHERE active = 1 ORDER BY name');
  return prods.map((p) => {
    const lines = db().all('SELECT r.pct, m.id, m.name, m.unit, m.kg_per_unit, m.cost_per_unit FROM recipes r JOIN materials m ON m.id = r.material_id WHERE r.product_id = ?', [p.id]);
    const flour = p.flour_material_id ? db().get('SELECT * FROM materials WHERE id = ?', [p.flour_material_id]) : null;
    const flourInRecipe = lines.some((l) => flour && l.id === flour.id);
    const per1kg = lines.map((l) => {
      const kg = l.pct / 100;
      const units = kg / (Number(l.kg_per_unit) || 1);
      return { name: l.name, kg, cost: units * (Number(l.cost_per_unit) || 0), priced: l.cost_per_unit !== null && l.cost_per_unit !== undefined };
    });
    if (flour && !flourInRecipe) per1kg.unshift({ name: flour.name, kg: 1, cost: (1 / (Number(flour.kg_per_unit) || 1)) * (Number(flour.cost_per_unit) || 0), priced: flour.cost_per_unit !== null });
    const doughKg = per1kg.reduce((s, x) => s + x.kg, 0);
    const costPerKgFlour = per1kg.reduce((s, x) => s + x.cost, 0);
    const pieces = p.cut_weight_g > 0 ? (doughKg * 1000) / p.cut_weight_g : 0;
    const perPiece = pieces ? costPerKgFlour / pieces : 0;
    let price = null;
    if (has('inv_items') && p.code) { const it = db().get('SELECT price FROM inv_items WHERE upper(code) = upper(?)', [p.code]); price = it ? it.price : null; }
    return { id: p.id, name: p.name, code: p.code || '', unit: p.unit, cutG: p.cut_weight_g, piecesPerKgFlour: r3(pieces), costPerKgFlour: r2(costPerKgFlour), perPiece: Math.round(perPiece * 1000) / 1000,
      price, margin: price ? r2(((price / 1.125 - perPiece) / (price / 1.125)) * 100) : null, missingPrices: per1kg.filter((x) => !x.priced).map((x) => x.name), lines: per1kg };
  });
}

const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export function weekdayPlan({ weeks = 8, today = dateStr() } = {}) {
  const from = addDays(today, -weeks * 7);
  const rows = db().all(`SELECT b.product_id, p.name, substr(b.created_at,1,10) AS d, SUM(COALESCE(b.cut_pieces, b.expected_pieces)) AS pcs, SUM(b.flour_kg) AS flour FROM batches b JOIN products p ON p.id = b.product_id
    WHERE b.status = 'finished' AND substr(b.created_at,1,10) BETWEEN ? AND ? GROUP BY b.product_id, d`, [from, addDays(today, -1)]);
  const by = {};
  rows.forEach((r) => {
    const k = r.product_id;
    const wd = new Date(`${r.d}T00:00:00`).getDay();
    const x = (by[k] = by[k] || { name: r.name, days: Array.from({ length: 7 }, () => ({ pcs: 0, flour: 0, n: 0 })) });
    x.days[wd].pcs += r.pcs; x.days[wd].flour += r.flour; x.days[wd].n += 1;
  });
  return Object.values(by).map((x) => ({ name: x.name, days: x.days.map((d, i) => ({ day: WD[i], pieces: d.n ? Math.round(d.pcs / d.n) : 0, flourKg: d.n ? r2(d.flour / d.n) : 0, times: d.n })) }));
}

export const BAKERY_EXTRA_REPORTS = [
  { id: 'bk_recipe_cost', group: 'Bakery', icon: '🧾', title: 'Recipe costing', desc: 'Cost per piece from today\'s ingredient prices, margin against the selling price', perm: 'bakery', costsOnly: true,
    build() {
      const list = recipeCosting();
      return { kind: 'bk_recipe_cost', title: 'Recipe Costing', fileName: `Recipe-costing-${dateStr()}`, subtitle: 'Easy Buys Bakery', info: [['Prices as at', dateStr()], ['Generated', stamp()]],
        sections: [{ title: 'Products', columns: [col('name', 'Product'), col('cut', 'Cut (g)', R), col('pcs', 'Pieces / kg flour', R), col('kg', 'Cost / kg flour', R), col('pp', 'Cost / piece', R), col('price', 'Price', R), col('m', 'Margin %', R), col('miss', 'No price for')],
          rows: list.map((p) => ({ name: p.name, cut: p.cutG, pcs: p.piecesPerKgFlour, kg: $(p.costPerKgFlour), pp: `$${p.perPiece.toFixed(3)}`, price: p.price ? $(p.price) : '', m: p.margin === null ? '' : p.margin, miss: p.missingPrices.join(', '), _tone: p.margin !== null && p.margin < 30 ? 'warn' : null })),
          note: 'Selling price comes from the Aronium product list (same product code). Margin is worked out on the price excluding VAT.' }] };
    } },
  { id: 'bk_weekday_plan', group: 'Bakery', icon: '📆', title: 'Production plan by weekday', desc: 'What is usually made each day of the week (last 8 weeks) – a starting plan', perm: 'bakery',
    build() {
      const list = weekdayPlan();
      return { kind: 'bk_weekday_plan', title: 'Production By Weekday', fileName: `Production-by-weekday-${dateStr()}`, subtitle: 'Easy Buys Bakery – average of the last 8 weeks', info: [['Generated', stamp()]],
        sections: [{ title: 'Average pieces made', columns: [col('name', 'Product')].concat(WD.map((d) => col(d, d, R))), rows: list.map((p) => ({ name: p.name, ...Object.fromEntries(p.days.map((d) => [d.day, d.pieces || ''])) })) },
          { title: 'Average flour (kg)', columns: [col('name', 'Product')].concat(WD.map((d) => col(d, d, R))), rows: list.map((p) => ({ name: p.name, ...Object.fromEntries(p.days.map((d) => [d.day, d.flourKg || ''])) })) }] };
    } },
];
