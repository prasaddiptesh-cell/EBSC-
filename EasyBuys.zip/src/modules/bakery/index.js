// Bakery module: the Easy Buys Bakery app (production, batches, stock, shifts, checklists, equipment).
// Its screens were written for three roles (Baker, Supervisor, Admin); everyone else is shown to them
// through bakeryRole() - e.g. an Owner works as Bakery Admin, a Shop manager as Supervisor.
import { SCREENS as BAKERY_SCREENS, HOME_FOR_ROLE } from './screens/index.js';
import { can, bakeryRole } from '../../services/access.js';
import { RANGE_REPORTS, rangeReport } from '../../services/reports.js';
import { BAKERY_EXTRA_REPORTS } from './extras.js';
import { MENU } from './menu.js';
import { BakeryTodayScreen, BakeryCloseScreen } from './screens/BakeryTodayScreens.js';
import ProofingScreen from './screens/admin/ProofingScreen.js';
import { alerts } from './alerts.js';

const screens = {};
for (const [name, [component, roles]] of Object.entries(BAKERY_SCREENS)) {
  if (name === 'Users' || name === 'UserEdit') continue;          // replaced by the Staff module
  if (name === 'WorkerHome' || name === 'SupervisorHome' || name === 'AdminHome') {
    screens[name] = { component, bakery: true, can: (u) => can(u, 'bakery') };
    continue;
  }
  if (name === 'ReportView') {
    // The shared report screen (PDF / Excel / CSV / print) is used by every module's reports.
    screens[name] = { component, bakery: true, shared: true, can: (u) => can(u, 'reports') || (can(u, 'bakery') && roles.includes(bakeryRole(u))) };
    continue;
  }
  if (name === 'Settings') {
    screens[name] = { component, bakery: true, shared: true, can: (u) => can(u, 'settings') };
    continue;
  }
  screens[name] = { component, bakery: true, can: (u) => can(u, 'bakery') && roles.includes(bakeryRole(u)) };
}

// One home for everyone in the bakery, and close & count in one step.
screens.BakeryToday = { component: BakeryTodayScreen, bakery: true, can: (u) => can(u, 'bakery') };
screens.BakeryProofing = { component: ProofingScreen, bakery: true, can: (u) => can(u, 'bakery') && bakeryRole(u) === 'admin' };
screens.BakeryClose = { component: BakeryCloseScreen, bakery: true, can: (u) => can(u, 'bakery') };

export default {
  id: 'bakery',
  title: 'Bakery',
  icon: '🥖',
  switchable: true,
  homeScreen: () => 'BakeryToday',
  alerts,
  screens,
  menu: MENU,
  reports: RANGE_REPORTS.map((r) => ({ ...r, id: r.id, group: 'Bakery', perm: 'bakery', costsOnly: !!r.costs, build: (from, to) => rangeReport(r.id, from, to) })).concat(BAKERY_EXTRA_REPORTS),
};
