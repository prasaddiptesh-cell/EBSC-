// Bakery module: the Easy Buys Bakery app (production, batches, stock, shifts, checklists, equipment).
// Its screens were written for three roles (Baker, Supervisor, Admin); everyone else is shown to them
// through bakeryRole() - e.g. an Owner works as Bakery Admin, a Shop manager as Supervisor.
import { SCREENS as BAKERY_SCREENS, HOME_FOR_ROLE } from './screens/index.js';
import { can, bakeryRole } from '../../services/access.js';
import { RANGE_REPORTS, rangeReport } from '../../services/reports.js';

const screens = {};
for (const [name, [component, roles]] of Object.entries(BAKERY_SCREENS)) {
  if (name === 'Users' || name === 'UserEdit') continue;          // replaced by the Staff module
  if (name === 'WorkerHome' || name === 'SupervisorHome' || name === 'AdminHome') {
    screens[name] = { component, bakery: true, can: (u) => can(u, 'bakery') };
    continue;
  }
  if (name === 'ReportView') {
    // The shared report screen (PDF / Excel / CSV / print) is used by every module's reports.
    screens[name] = { component, bakery: true, shared: true, can: (u) => can(u, 'reports') || (can(u, 'bakery') && roles.includes(bakeryRole(u))) };
    continue;
  }
  if (name === 'Settings') {
    screens[name] = { component, bakery: true, shared: true, can: (u) => can(u, 'settings') };
    continue;
  }
  screens[name] = { component, bakery: true, can: (u) => can(u, 'bakery') && roles.includes(bakeryRole(u)) };
}

export default {
  id: 'bakery',
  title: 'Bakery',
  icon: '🥖',
  switchable: true,
  homeScreen: (u) => HOME_FOR_ROLE[bakeryRole(u)],
  screens,
  reports: RANGE_REPORTS.map((r) => ({ ...r, id: r.id, group: 'Bakery', perm: 'bakery', costsOnly: !!r.costs, build: (from, to) => rangeReport(r.id, from, to) })),
};
