// Bakery menu. The bakery home depends on the person's bakery role (baker, supervisor, admin).
import { bakeryRole } from '../../services/access.js';

const HOME = { worker: 'WorkerHome', supervisor: 'SupervisorHome', admin: 'AdminHome' };
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🥖', title: 'Bakery today', note: 'The shift, batches and reminders.', screen: (u) => HOME[bakeryRole(u)] || 'WorkerHome' },
    { id: 'bk-start', icon: '▶️', title: 'Start the shift', screen: 'StartShift' },
    { id: 'bk-batch', icon: '🍞', title: 'New batch', screen: 'NewBatch' },
    { id: 'bk-checklists', icon: '✅', title: 'Checklists', screen: 'Checklists' },
    { id: 'bk-wastage', icon: '🗑️', title: 'Wastage', screen: 'Wastage' },
    { id: 'bk-extra', icon: '➕', title: 'Extra use of ingredients', screen: 'ExtraUse' },
    { id: 'bk-receive', icon: '🚚', title: 'Receive ingredients', screen: 'Receive' },
    { id: 'bk-close', icon: '⏹️', title: 'Close the shift', screen: 'CloseShift' },
    { id: 'bk-balance', icon: '⚖️', title: 'Balance the shift', screen: 'Balance' },
  ] },
  { section: 'Records', items: [
    { id: 'bk-stock', icon: '📦', title: 'Bakery stock', screen: 'Stock' },
    { id: 'bk-mine', icon: '🗒️', title: 'My entries', screen: 'MyEntries' },
    { id: 'bk-history', icon: '🗂️', title: 'All transactions', screen: 'Activity', params: { history: true } },
    { id: 'bk-plan', icon: '📅', title: 'Production plan', screen: 'Plan' },
    { id: 'bk-po', icon: '📝', title: 'Bakery purchase orders', screen: 'PurchaseOrders' },
    { id: 'bk-equipment', icon: '🔧', title: 'Equipment', screen: 'Equipment' },
    { id: 'bk-trace', icon: '🔎', title: 'Lots & trace', screen: 'Trace' },
  ] },
  { section: 'Checks', items: [
    { id: 'bk-dashboard', icon: '📈', title: 'Bakery dashboard', screen: 'Dashboard' },
    { id: 'bk-alerts', icon: '🔔', title: 'Bakery alerts', screen: 'Alerts' },
    { id: 'bk-adjust', icon: '⚖️', title: 'Stock adjustment', screen: 'Adjust' },
  ] },
  { section: 'Reports', items: [
    { id: 'bk-reports', icon: '📊', title: 'Bakery reports', screen: 'Reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'bk-products', icon: '🍞', title: 'Products & recipes', screen: 'Products' },
    { id: 'bk-materials', icon: '🌾', title: 'Ingredients (materials)', screen: 'Materials' },
    { id: 'bk-suppliers', icon: '🏪', title: 'Bakery suppliers', screen: 'Suppliers' },
    { id: 'bk-shifts', icon: '🕒', title: 'Shifts & steps', screen: 'ShiftsSteps' },
    { id: 'bk-checklists-setup', icon: '✅', title: 'Checklist setup', screen: 'ChecklistsSetup' },
    { id: 'bk-settings', icon: '⚙️', title: 'Bakery settings', screen: 'Settings', params: { tab: 'general' } },
  ] },
];
