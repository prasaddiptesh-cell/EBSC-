// Bakery menu: one "Bakery today" home for everyone. Ordering and receiving ingredients use the normal Inventory
// purchase orders and receiving; staff, suppliers, warnings, cloud and email settings are the main app's.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🥖', title: 'Bakery today', note: "The baker's day step by step, batches and today's plan.", screen: 'BakeryToday' },
    { id: 'bk-checklists', icon: '✅', title: 'Checklists', screen: 'Checklists' },
    { id: 'bk-wastage', icon: '🗑️', title: 'Wastage', screen: 'Wastage' },
    { id: 'bk-extra', icon: '➕', title: 'Other use of ingredients', screen: 'ExtraUse' },
    { id: 'bk-order', icon: '📝', title: 'Order ingredients', note: 'A normal purchase order (Inventory).', screen: 'POEdit' },
    { id: 'bk-receive', icon: '📥', title: 'Receive ingredients', note: 'Photo of the invoice, then count it in – linked ingredients go into the Bakery stock.', screen: 'ReceiveGoods' },
  ] },
  { section: 'Records', items: [
    { id: 'bk-mine', icon: '🗒️', title: 'Batches & history', screen: 'MyEntries' },
    { id: 'bk-stock', icon: '📦', title: 'Bakery stock', screen: 'Stock' },
    { id: 'bk-history', icon: '🗂️', title: 'All bakery transactions', screen: 'Activity', params: { history: true } },
    { id: 'bk-plan', icon: '📅', title: 'Production plan', screen: 'Plan' },
    { id: 'bk-equipment', icon: '🔧', title: 'Equipment', screen: 'Equipment' },
    { id: 'bk-trace', icon: '🔎', title: 'Lots & trace', screen: 'Trace' },
  ] },
  { section: 'Checks', items: [
    { id: 'bk-adjust', icon: '⚖️', title: 'Stock adjustment', screen: 'Adjust' },
  ] },
  { section: 'Reports', items: [
    { id: 'bk-dashboard', icon: '📈', title: 'Bakery dashboard', screen: 'Dashboard' },
    { id: 'bk-reports', icon: '📊', title: 'Bakery reports', screen: 'Reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'bk-products', icon: '🍞', title: 'Products & recipes', screen: 'Products' },
    { id: 'bk-materials', icon: '🌾', title: 'Ingredients', note: 'And which Inventory product each one is received as.', screen: 'Materials' },
    { id: 'bk-shifts', icon: '🕒', title: 'Shifts & steps', screen: 'ShiftsSteps' },
    { id: 'bk-proofing', icon: '🌡️', title: 'Proofing', note: 'Proofing time by yeast, and hot / normal / cool days.', screen: 'BakeryProofing' },
    { id: 'bk-checklists-setup', icon: '✅', title: 'Checklist setup', screen: 'ChecklistsSetup' },
    { id: 'bk-settings', icon: '⚙️', title: 'Bakery rules', screen: 'Settings', params: { tab: 'general' } },
  ] },
];
