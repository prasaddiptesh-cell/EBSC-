// "Bakery today": one home for everyone in the bakery – the baker's day step by step, batches in progress, today's plan.
// "Close & count": close the day, count the bakery store and balance it, in one step.
import React, { useState, useEffect } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Tile, Grid, NumberField, Chips, useApp, useUI, useTick, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { fmt, signed, hhmm } from '../../../services/core.js';
import { stepFor } from '../../../services/catalog.js';
import { checkVariance } from '../../../services/shifts.js';
import { planProgress } from '../../../services/plan.js';
import { bakerDay, countSheet, closeAndCount } from '../day.js';
import { postBakeryReceipts, unmatchedBakeryLines } from '../store.js';
import { ActiveBatchCard } from './worker/BakingPanel.js';

function StepRow({ s, i, current, onPress, action }) {
  const tone = s.done ? C.success : current ? C.primary : C.sub;
  return (
    <Pressable testID={`bd-step-${s.key}`} disabled={!onPress} onPress={onPress}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 14, borderWidth: current ? 2 : 1, borderColor: current ? C.primary : C.border, backgroundColor: current ? C.card : 'transparent', opacity: pressed ? 0.7 : 1 })}>
      <Text style={{ fontSize: 24, width: 32, textAlign: 'center', color: tone }}>{s.done ? '✅' : current ? '👉' : `${i + 1}`}</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 18, fontWeight: current ? '800' : '700', color: C.text }}>{s.title}</Text>
        {s.note ? <Text style={{ fontSize: 14, color: C.sub }}>{s.note}</Text> : null}
      </View>
      {current && action ? <Text style={{ fontSize: 16, fontWeight: '800', color: C.primary }}>{action} ›</Text> : null}
    </Pressable>
  );
}

export function BakeryTodayScreen() {
  const { user, nav, openClock } = useApp();
  const ui = useUI();
  useTick(5000);
  const [posted, setPosted] = useState(0);
  useEffect(() => { try { setPosted(postBakeryReceipts()); } catch (e) { /* tried again next time */ } }, []);
  let d = null; let err = null;
  try { d = bakerDay(user); } catch (e) { err = e.message; }
  if (!d) return <Screen title="Bakery today"><Banner tone="danger" message={err || 'Something went wrong.'} /></Screen>;
  let plan = [];
  try { plan = planProgress(); } catch (e) { plan = []; }
  let unmatched = [];
  try { unmatched = unmatchedBakeryLines(); } catch (e) { unmatched = []; }
  const clock = () => (openClock ? openClock() : ui.alert({ title: 'Time Clock', message: 'Use the Time Clock on the shop tablet to clock in or out.', tone: 'info' }));
  const ACTION = {
    'clock-in': ['Clock in', clock],
    opening: ['Count & open', () => nav.push('StartShift', {})],
    'start-lists': ['Open', () => nav.push('Checklists', {})],
    baking: ['New batch', () => nav.push('NewBatch', {})],
    'end-lists': ['Open', () => nav.push('Checklists', {})],
    close: ['Close & count', () => nav.push('BakeryClose', {})],
    'clock-out': ['Clock out', clock],
  };
  return (
    <Screen title="Bakery today" subtitle={d.open ? `${d.open.shift_name} · opened ${hhmm(d.open.opened_at)} by ${d.open.opened_by_name}` : d.closedToday ? 'Today is closed' : 'Not open yet'}>
      {posted ? <Banner tone="success" message={`${posted} ingredient delivery line${posted === 1 ? '' : 's'} added to the Bakery stock.`} /> : null}
      {unmatched.length ? <Banner tone="warn" title="Received but not in the Bakery stock" message={`${unmatched.map((u) => `${u.material} ${u.qty}`).join(', ')} – the ingredient name is not set up here. Check Bakery › Ingredients.`} /> : null}
      {d.waiting ? (
        <Banner tone="warn" title="An earlier day is waiting for its count" message={`${d.waiting.shift_name} (${d.waiting.shift_date}) was closed but not counted.`} />
      ) : null}
      {d.waiting && d.mayOverride ? <Btn testID="bd-balance" title="Count & balance it" icon="⚖️" variant="warn" onPress={() => nav.push('Balance', { shiftId: d.waiting.id })} /> : null}
      <Section title="The baker's day">
        <View style={{ gap: 8 }}>
          {d.steps.map((s, i) => {
            const current = d.now === s.key && !d.waiting;
            const [label, go] = ACTION[s.key] || [];
            const may = current || (d.mayOverride && !s.done) || (['start-lists', 'end-lists'].includes(s.key) && d.open);
            return <StepRow key={s.key} s={s} i={i} current={current} action={label} onPress={may && go ? go : null} />;
          })}
        </View>
        {!d.now ? <Banner tone="success" message="All done for today – thank you!" /> : null}
      </Section>

      {d.open ? (
        <Grid>
          <Tile testID="tile-new-batch" icon="🥣" title="New batch" subtitle={d.bakingOpen || d.mayOverride ? 'Enter flour, start mixing' : 'After the opening checklists'} color={C.primary} disabled={!(d.bakingOpen || d.mayOverride)} onPress={() => nav.push('NewBatch', {})} />
          <Tile testID="tile-wastage" icon="🗑️" title="Wastage" subtitle="Spilled, expired" color={C.danger} onPress={() => nav.push('Wastage', {})} />
          <Tile testID="tile-extra" icon="🧂" title="Other use" subtitle="Used outside a batch" color={C.warn} onPress={() => nav.push('ExtraUse', {})} />
          <Tile testID="tile-fault" icon="🔧" title="Report a fault" subtitle="Oven, mixer, fridge" color={C.sub} onPress={() => nav.push('Equipment', {})} />
        </Grid>
      ) : null}

      {d.batches.length ? (
        <Section title={`Batches in progress (${d.batches.length})`}>
          {d.batches.map((b) => <ActiveBatchCard key={b.id} b={b} onPress={() => nav.push('Batch', { batchId: b.id })} />)}
        </Section>
      ) : null}

      {plan.length ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 6 }}>🎯 Today's plan</Text>
          {plan.map((p) => (
            <View key={p.product_id} style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 }}>
              <Text style={{ fontSize: 16, color: C.text }}>{p.name}{p.unplanned ? ' (extra)' : ''}</Text>
              <Text style={{ fontSize: 16, fontWeight: '800', color: p.remaining ? C.warn : C.success }}>{fmt(p.good)}{p.target ? ` of ${fmt(p.target)}` : ''}{p.inProgress ? ` (+${p.inProgress} in oven)` : ''}</Text>
            </View>
          ))}
        </Card>
      ) : null}
      <Grid>
        <Tile testID="tile-history" icon="🗂️" title="Batches & history" subtitle="Everything recorded" color={C.info} onPress={() => nav.push('MyEntries', {})} />
        <Tile testID="tile-stock" icon="📦" title="Bakery stock" subtitle="What is in the store" color={C.success} onPress={() => nav.push('Stock', {})} />
      </Grid>
    </Screen>
  );
}

const REASONS = ['Counting error', 'Spillage', 'Not recorded', 'Recipe different', 'Delivery short', 'Other'];

export function BakeryCloseScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const { width } = useLayout();
  const [sheet] = useState(() => { try { return countSheet(); } catch (e) { return []; } });
  const [counts, setCounts] = useState({});
  const [why, setWhy] = useState({});
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  if (!sheet.length) return <Screen title="Close & count"><Banner tone="info" message="The bakery day is not open." /></Screen>;
  const rows = sheet.map((r) => {
    const a = counts[r.material_id];
    const has = a !== null && a !== undefined && a !== '';
    const v = has ? checkVariance(r.expected, Number(a), r.tolerance_pct) : null;
    return { ...r, has, v };
  });
  const left = rows.filter((r) => !r.has).length;
  const go = async () => {
    const over = rows.filter((r) => r.v && r.v.over);
    const ok = await ui.confirm({ title: 'Close the bakery day?', message: over.length ? `${over.length} item(s) are more or less than expected. They will be shown to the owner.` : 'Everything matches. The day will be closed and balanced.', confirmText: 'Close & balance', tone: over.length ? 'warn' : 'success' });
    if (!ok) return;
    setBusy(true);
    try {
      closeAndCount(user, Object.fromEntries(rows.filter((r) => r.has).map((r) => [r.material_id, Number(counts[r.material_id])])), why, notes);
      ui.toast('Bakery day closed and balanced');
      nav.pop();
    } catch (e) { ui.error(e); }
    setBusy(false);
  };
  return (
    <Screen title="Close & count" subtitle="Count what is left in the bakery store"
      footer={<Btn testID="bc-go" title={left ? `Count ${left} more` : 'Close & balance'} icon="🏁" variant="success" disabled={!!left || busy} onPress={go} />}>
      <Hint>Count each ingredient. If it is different from what the app expects, say why.</Hint>
      <Btn testID="bc-same" title="Fill in what the app expects (then change what is different)" size="sm" variant="secondary"
        onPress={() => setCounts(Object.fromEntries(sheet.map((r) => [r.material_id, r.expected])))} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {rows.map((r) => (
          <Card key={r.material_id} tone={r.v && r.v.over ? 'warn' : undefined} style={{ flexBasis: width >= 900 ? '48%' : '100%', flexGrow: 1 }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>Expected {fmt(r.expected, r.unit)} (opening {fmt(r.opening)}, in {fmt(r.received)}, used {fmt(r.used)}{r.wasted ? `, wasted ${fmt(r.wasted)}` : ''})</Text>
            <NumberField testID={`bc-count-${r.name}`} value={counts[r.material_id] ?? null} onChange={(v) => setCounts((c) => ({ ...c, [r.material_id]: v }))} step={stepFor(r.unit)} unit={r.unit} compact />
            {r.v && r.v.variance ? <Text style={{ color: r.v.over ? C.danger : C.sub, fontWeight: '700' }}>{signed(r.v.variance, r.unit)} {r.v.over ? '– more than allowed' : ''}</Text> : null}
            {r.v && r.v.over ? (
              <>
                <Chips value={why[r.material_id] || ''} onChange={(v) => setWhy((w) => ({ ...w, [r.material_id]: v }))} options={REASONS.map((x) => ({ value: x, label: x }))} testIDPrefix={`bc-why-${r.name}`} />
              </>
            ) : null}
          </Card>
        ))}
      </View>
      <Field testID="bc-notes" label="Notes (optional)" value={notes} onChangeText={setNotes} multiline />
    </Screen>
  );
}
