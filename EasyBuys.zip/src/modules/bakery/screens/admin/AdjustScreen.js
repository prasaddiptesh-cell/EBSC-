import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Label, PickGrid, NumberField, Field, Chips, Btn, Banner, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, stepFor } from '../../../../services/catalog.js';
import { recordAdjustment } from '../../../../services/shifts.js';
import { fmt, signed, r3 } from '../../../../services/core.js';

const REASONS = ['Count correction', 'Damaged', 'Expired', 'Found stock', 'Returned to supplier', 'Other'];

export default function AdjustScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [mat, setMat] = useState(null);
  const [mode, setMode] = useState('set');
  const [qty, setQty] = useState(null);
  const [reason, setReason] = useState(null);
  const [note, setNote] = useState('');
  const materials = listMaterials({ stockOnly: true });

  let delta = null;
  if (mat && qty !== null) delta = mode === 'add' ? qty : mode === 'remove' ? -qty : r3(qty - mat.stock);

  const save = async () => {
    const why = reason === 'Other' ? note.trim() : [reason, note.trim()].filter(Boolean).join(' - ');
    if (qty === null) return ui.alert({ title: 'Enter quantity', message: 'Enter the quantity for the adjustment.', tone: 'warn' });
    if (!why) return ui.alert({ title: 'Reason required', message: 'Choose a reason (and type it if you chose Other).', tone: 'warn' });
    const ok = await ui.confirm({
      title: 'Confirm stock adjustment',
      message: `${mat.name}: ${fmt(mat.stock, mat.unit)} → ${fmt(r3(mat.stock + delta), mat.unit)} (${signed(delta, mat.unit)})\nReason: ${why}`,
      confirmText: 'Adjust stock', tone: 'warn',
    });
    if (!ok) return;
    try {
      const res = recordAdjustment(user.id, mat.id, mode, qty, why);
      ui.toast(`${mat.name} adjusted ${signed(res.delta, mat.unit)} · ${res.txnId}`);
      setMat(null); setQty(null); setReason(null); setNote('');
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Stock Adjustment" subtitle="Every adjustment is logged with your name and reason"
      footer={mat ? <Btn testID="save-adjust" title="Save adjustment" icon="⚖️" variant="warn" onPress={save} /> : null}>
      {!mat ? (
        <>
          <H>Choose a material</H>
          <PickGrid items={materials} onPick={(m) => { setMat(m); setQty(null); }} testIDPrefix="mat"
            render={(m) => (<View><Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{m.name}</Text><Text style={{ fontSize: 15, color: C.sub }}>{fmt(m.stock, m.unit)}</Text></View>)} />
        </>
      ) : (
        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <H>{mat.name} · now {fmt(mat.stock, mat.unit)}</H>
            <Btn title="Change" size="sm" variant="secondary" onPress={() => setMat(null)} />
          </View>
          <Label>Type of adjustment</Label>
          <Chips value={mode} onChange={(m) => { setMode(m); setQty(null); }} testIDPrefix="mode"
            options={[{ value: 'set', label: 'Set to counted amount' }, { value: 'add', label: 'Add' }, { value: 'remove', label: 'Remove' }]} />
          <View style={{ height: 14 }} />
          <NumberField testID="qty" label={mode === 'set' ? `Counted amount (${mat.unit})` : `Quantity to ${mode} (${mat.unit})`} value={qty} onChange={setQty} step={stepFor(mat.unit)} unit={mat.unit} />
          {delta !== null ? (
            <View style={{ marginTop: 12 }}>
              <Banner tone={delta === 0 ? 'info' : 'warn'} title={delta === 0 ? 'No change' : `Change: ${signed(delta, mat.unit)}`} message={`New stock: ${fmt(r3(mat.stock + delta), mat.unit)}`} />
            </View>
          ) : null}
          <View style={{ height: 14 }} />
          <Label>Reason</Label>
          <Chips options={REASONS} value={reason} onChange={setReason} testIDPrefix="reason" />
          <View style={{ height: 10 }} />
          <Field label={reason === 'Other' ? 'Type the reason' : 'Extra detail (optional)'} value={note} onChangeText={setNote} />
        </Card>
      )}
    </Screen>
  );
}
