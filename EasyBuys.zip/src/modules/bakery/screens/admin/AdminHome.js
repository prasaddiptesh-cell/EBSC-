import React from 'react';
import { Screen, Tile, Grid, Section, Chips, useApp, useTick } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { ShiftStatus, ManagementTiles } from '../supervisor/SupervisorHome.js';
import BakingPanel from '../worker/BakingPanel.js';
import { getSettings } from '../../../../services/core.js';

export default function AdminHome() {
  const { nav, user, homeTab, setHomeTab } = useApp();
  useTick(15000);
  const tab = homeTab || 'manage';
  return (
    <Screen title={getSettings().bakeryName} subtitle={`Admin · ${user.name}`}>
      <Chips value={tab} onChange={setHomeTab} testIDPrefix="admin-tab"
        options={[{ value: 'manage', label: '📈 Manage' }, { value: 'bake', label: '🥖 Bake' }, { value: 'setup', label: '⚙️ Setup' }]} />
      {tab === 'bake' ? <BakingPanel /> : null}
      {tab === 'manage' ? (
        <>
          <ShiftStatus />
          <ManagementTiles />
          <Grid>
            <Tile testID="tile-adjust" icon="⚖️" title="Stock Adjustment" subtitle="Correct stock levels" color={C.warn} onPress={() => nav.push('Adjust')} />
            <Tile testID="tile-trace" icon="🔎" title="Lots & Trace" subtitle="Recalls, expiry" color={C.info} onPress={() => nav.push('Trace')} />
            <Tile testID="tile-history" icon="🗂️" title="All Transactions" subtitle="Full history" color={C.sub} onPress={() => nav.push('Activity', { history: true })} />
          </Grid>
        </>
      ) : null}
      {tab === 'setup' ? (
        <Section title="Setup">
          <Grid>
            <Tile testID="tile-users" icon="👥" title="Users" subtitle="PINs, logins, roles" color={C.info} onPress={() => nav.push('Users')} />
            <Tile testID="tile-suppliers" icon="🏪" title="Suppliers" subtitle="Names, contacts, email" color={C.success} onPress={() => nav.push('Suppliers')} />
            <Tile testID="tile-materials" icon="🌾" title="Materials" subtitle="Ingredients, minimums, prices" onPress={() => nav.push('Materials')} />
            <Tile testID="tile-products" icon="🍞" title="Products & Recipes" subtitle="Flour %, cut weight, times" color={C.warn} onPress={() => nav.push('Products')} />
            <Tile testID="tile-shifts-steps" icon="🕒" title="Shifts & Steps" subtitle="Shift names, bake steps" color={C.brandBlue} onPress={() => nav.push('ShiftsSteps')} />
            <Tile testID="tile-checklists-setup" icon="✅" title="Checklists" subtitle="Cleaning, temperatures" color={C.success} onPress={() => nav.push('ChecklistsSetup')} />
            <Tile testID="tile-equipment-setup" icon="🔧" title="Equipment" subtitle="Ovens, mixers, service" color={C.sub} onPress={() => nav.push('Equipment')} />
            <Tile testID="tile-settings" icon="⚙️" title="Settings" subtitle="Email, online, rules" color={C.primaryDark} onPress={() => nav.push('Settings')} />
          </Grid>
        </Section>
      ) : null}
    </Screen>
  );
}
