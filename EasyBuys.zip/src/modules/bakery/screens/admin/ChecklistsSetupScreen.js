import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, Field, Chips, Btn, Label, NumberField, Badge, Empty, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listChecklists, getChecklist, saveChecklist, WHEN_LABEL, SCOPE_LABEL, KIND_LABEL } from '../../../../services/checklists.js';

export function ChecklistsSetupScreen() {
  const { nav } = useApp();
  const lists = listChecklists({ includeInactive: true });
  return (
    <Screen title="Checklists" subtitle="Cleaning, opening checks, temperature logs"
      footer={<Btn testID="add-checklist" title="New checklist" icon="➕" onPress={() => nav.push('ChecklistEdit', {})} />}>
      {!lists.length ? <Empty text="No checklists yet." /> : null}
      {lists.map((l) => (
        <Pressable key={l.id} testID={`cl-${l.name}`} onPress={() => nav.push('ChecklistEdit', { id: l.id })}
          style={({ pressed }) => ({ backgroundColor: l.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1, gap: 6 })}>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>✅ {l.name}{l.active ? '' : ' (off)'}</Text>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Badge text={WHEN_LABEL[l.when_due]} color={l.when_due === 'end' ? C.warn : C.info} />
            <Badge text={l.scope === 'person' ? 'Each baker' : 'Once per shift'} color={C.sub} />
            <Badge text={`${l.item_count} items`} color={C.success} />
          </View>
        </Pressable>
      ))}
    </Screen>
  );
}

export function ChecklistEditScreen({ params }) {
  const { nav } = useApp();
  const ui = useUI();
  const [c] = useState(() => (params.id ? getChecklist(params.id) : null));
  const [name, setName] = useState(c ? c.name : '');
  const [when, setWhen] = useState(c ? c.when_due : 'end');
  const [scope, setScope] = useState(c ? c.scope : 'person');
  const [active, setActive] = useState(c ? !!c.active : true);
  const [items, setItems] = useState(() => (c ? c.items.map((i) => ({ id: i.id, name: i.name, kind: i.kind, min_value: i.min_value, max_value: i.max_value })) : [{ name: '', kind: 'tick' }]));
  const setItem = (i, patch) => setItems((x) => x.map((y, k) => (k === i ? { ...y, ...patch } : y)));
  const save = () => {
    try {
      saveChecklist({ id: c ? c.id : undefined, name, when_due: when, scope, active }, items);
      ui.toast('Checklist saved');
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={c ? `Edit ${c.name}` : 'New checklist'} footer={<Btn testID="save-checklist" title="Save checklist" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        <Field testID="cl-name" label="Checklist name" value={name} onChangeText={setName} placeholder="e.g. End-of-shift cleaning" />
        <View><Label>When</Label><Chips value={when} onChange={setWhen} testIDPrefix="cl-when" options={Object.entries(WHEN_LABEL).map(([v, l]) => ({ value: v, label: l }))} /></View>
        <View><Label>Who</Label><Chips value={scope} onChange={setScope} testIDPrefix="cl-scope" options={Object.entries(SCOPE_LABEL).map(([v, l]) => ({ value: v, label: l }))} /></View>
        {when === 'end' ? <Text style={{ fontSize: 15, color: C.warn, fontWeight: '700' }}>{scope === 'person' ? 'Each baker must finish this before they can sign off.' : 'Must be finished before the shift can be closed.'}</Text> : null}
        <View><Label>Status</Label><Chips value={active} onChange={setActive} options={[{ value: true, label: 'On' }, { value: false, label: 'Off' }]} /></View>
      </Card>
      {items.map((it, i) => (
        <Card key={it.id || `n${i}`} style={{ gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.sub }}>{i + 1}.</Text>
            <View style={{ flex: 1 }}><Field testID={`cl-item-${i}`} value={it.name} onChangeText={(t) => setItem(i, { name: t })} placeholder="e.g. Clean mixer bowl" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setItems((x) => x.filter((_, k) => k !== i))} />
          </View>
          <Chips value={it.kind} onChange={(v) => setItem(i, { kind: v })} testIDPrefix={`cl-kind-${i}`} options={Object.entries(KIND_LABEL).map(([v, l]) => ({ value: v, label: l }))} />
          {it.kind === 'temp' ? (
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}><NumberField label="Lowest °C" value={it.min_value} onChange={(v) => setItem(i, { min_value: v })} step={1} unit="°C" min={-60} compact /></View>
              <View style={{ flex: 1 }}><NumberField label="Highest °C" value={it.max_value} onChange={(v) => setItem(i, { max_value: v })} step={1} unit="°C" min={-60} compact /></View>
            </View>
          ) : null}
        </Card>
      ))}
      <Btn testID="cl-add-item" title="Add item" icon="➕" size="md" variant="secondary" onPress={() => setItems((x) => x.concat([{ name: '', kind: 'tick' }]))} />
    </Screen>
  );
}
