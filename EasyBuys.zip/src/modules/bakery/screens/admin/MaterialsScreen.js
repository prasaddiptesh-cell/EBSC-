import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, Field, Chips, Btn, Label, Banner, NumberField, Select, Section, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, getMaterial, saveMaterial, listSuppliers, UNITS, stepFor, defaultKgPerUnit } from '../../../../services/catalog.js';
import { fmt, money, getSettings } from '../../../../services/core.js';

export function MaterialsScreen() {
  const { nav } = useApp();
  const items = listMaterials({ includeInactive: true });
  const s = getSettings();
  return (
    <Screen title="Materials" subtitle="Ingredients, minimum levels, suppliers and prices"
      footer={<Btn testID="add-material" title="Add material" icon="➕" onPress={() => nav.push('MaterialEdit', {})} />}>
      {items.map((m) => (
        <Pressable key={m.id} testID={`material-${m.name}`} onPress={() => nav.push('MaterialEdit', { id: m.id })}
          style={({ pressed }) => ({ backgroundColor: m.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1 })}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{m.name}{m.code ? ` · ${m.code}` : ''}{!m.active ? ' (inactive)' : ''}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>
              {m.track_stock ? `Stock ${fmt(m.stock, m.unit)} · minimum ${m.reorder_level ? fmt(m.reorder_level, m.unit) : 'not set'} · tolerance ±${m.tolerance_pct === null ? `${s.defaultTolerance}% (default)` : `${fmt(m.tolerance_pct)}%`}` : 'Not stock-counted (e.g. tap water)'}
              {m.cost_per_unit ? ` · ${money(m.cost_per_unit, s.currency)}/${m.unit}` : ''}{m.supplier_name ? ` · ${m.supplier_name}` : ''}
            </Text>
          </View>
          <Text style={{ fontSize: 28, color: C.sub }}>›</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

export function MaterialEditScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const s = getSettings();
  const [m] = useState(() => (params.id ? getMaterial(params.id) : null));
  const [f, setF] = useState({
    name: m ? m.name : '', code: m ? m.code || '' : '', unit: m ? m.unit : 'kg', kg_per_unit: m ? m.kg_per_unit : 1, track_stock: m ? !!m.track_stock : true,
    stock: m ? m.stock : 0, tolerance_pct: m ? m.tolerance_pct : null, reorder_level: m ? m.reorder_level : 0, reorder_qty: m ? m.reorder_qty : 0,
    supplier_id: m ? m.supplier_id : null, cost_per_unit: m ? m.cost_per_unit : null, active: m ? !!m.active : true,
  });
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const suppliers = listSuppliers();
  const save = () => {
    try {
      saveMaterial({ id: m ? m.id : undefined, ...f }, user.id);
      ui.toast(m ? `${f.name} updated` : `${f.name} added`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={m ? `Edit ${m.name}` : 'New material'} footer={<Btn testID="save-material" title="Save material" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        <Field testID="material-name" label="Name" value={f.name} onChangeText={set('name')} placeholder="e.g. Flour" />
        <Field testID="material-code" label="Item code (optional – same as Aronium SKU/barcode)" value={f.code} onChangeText={set('code')} />
        <View>
          <Label>Unit</Label>
          <Chips options={UNITS.includes(f.unit) ? UNITS : UNITS.concat([f.unit])} value={f.unit} onChange={(u) => setF((x) => ({ ...x, unit: u, kg_per_unit: defaultKgPerUnit(u) || x.kg_per_unit }))} testIDPrefix="unit" />
        </View>
        <NumberField testID="material-kg" label={`Weight of 1 ${f.unit} in kg (used for dough weight)`} value={f.kg_per_unit} onChange={set('kg_per_unit')} step={0.01} unit="kg"
          hint={f.unit === 'pcs' ? 'e.g. one egg ≈ 0.05 kg' : f.unit === 'L' ? 'e.g. water 1, milk 1.03, oil 0.92' : ''} />
        <View>
          <Label>Count this item in stock?</Label>
          <Chips value={f.track_stock} onChange={set('track_stock')} testIDPrefix="track" options={[{ value: true, label: 'Yes – counted in stock' }, { value: false, label: 'No (e.g. tap water)' }]} />
        </View>
      </Card>
      {f.track_stock ? (
        <Section title="Stock & reordering">
          <Card style={{ gap: 14 }}>
            {m ? <Banner tone="info" message={`Current stock: ${fmt(m.stock, m.unit)}. To change it, use Stock Adjustment (so the change is logged).`} />
              : <NumberField testID="material-stock" label="Starting stock" value={f.stock} onChange={set('stock')} step={stepFor(f.unit) * 10} unit={f.unit} />}
            <NumberField testID="material-min" label="Minimum level (purchase order is raised at this level)" value={f.reorder_level} onChange={set('reorder_level')} step={stepFor(f.unit) * 10} unit={f.unit} />
            <NumberField testID="material-reorder" label="Quantity to order" value={f.reorder_qty} onChange={set('reorder_qty')} step={stepFor(f.unit) * 10} unit={f.unit} />
            <Select testID="material-supplier" label="Usual supplier" value={f.supplier_id} onChange={set('supplier_id')} options={[{ value: null, label: 'No usual supplier' }].concat(suppliers.map((x) => ({ value: x.id, label: x.name })))} />
            <NumberField testID="material-tol" label="Stock count tolerance (%)" value={f.tolerance_pct} onChange={set('tolerance_pct')} step={0.5} unit="%" hint={`Leave empty to use the default (${s.defaultTolerance}%). Bigger differences need a reason when balancing.`} />
          </Card>
        </Section>
      ) : null}
      <Section title="Price">
        <Card style={{ gap: 10 }}>
          <NumberField testID="material-cost" label={`Price per ${f.unit} (${s.currency})`} value={f.cost_per_unit} onChange={set('cost_per_unit')} step={0.1} unit={s.currency}
            hint={m && m.cost_updated_at ? `Updated automatically from deliveries · last ${m.cost_updated_at.slice(0, 10)}` : 'Updated automatically when a supervisor enters prices at receiving.'} />
        </Card>
      </Section>
      <Card>
        <Label>Status</Label>
        <Chips value={f.active} onChange={set('active')} testIDPrefix="active" options={[{ value: true, label: 'Active' }, { value: false, label: 'Inactive (hidden)' }]} />
      </Card>
    </Screen>
  );
}
