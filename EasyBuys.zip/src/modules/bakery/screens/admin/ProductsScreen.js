import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Field, Chips, Btn, Label, Badge, Banner, NumberField, PickGrid, Select, Section, Row, NumCell, useApp, useUI, Choice } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listProducts, getProduct, getRecipe, listMaterials, saveProductFull, listSteps, getProductStepTimes, getProductDecks } from '../../../../services/catalog.js';
import { doughKg, expectedPieces } from '../../../../services/batches.js';
import { fmt, money, getSettings, r3, bandLabels } from '../../../../services/core.js';

export function ProductsScreen() {
  const { nav } = useApp();
  const items = listProducts({ includeInactive: true });
  return (
    <Screen title="Products & Recipes" subtitle="Recipes are % of flour; the app calculates every batch"
      footer={<Btn testID="add-product" title="Add product" icon="➕" onPress={() => nav.push('ProductEdit', {})} />}>
      {items.map((p) => (
        <Pressable key={p.id} testID={`product-${p.name}`} onPress={() => nav.push('ProductEdit', { id: p.id })}
          style={({ pressed }) => ({ backgroundColor: p.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1 })}>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🍞 {p.name}{!p.active ? ' (inactive)' : ''}</Text>
            <Text style={{ fontSize: 15, color: C.sub }}>Cut {fmt(p.cut_weight_g)} g · max {fmt(p.max_flour_kg)} kg flour{p.flour_name ? ` · ${p.flour_name}` : ''}</Text>
            {p.flour_material_id ? <Badge text={`${p.recipe_count + 1} ingredients`} color={C.success} /> : <Badge text="Recipe not set" color={C.danger} />}
          </View>
          <Text style={{ fontSize: 28, color: C.sub }}>›</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

const PRODUCT_UNITS = ['loaves', 'pcs', 'dozen', 'trays', 'cakes', 'packs'];

export function ProductEditScreen({ params }) {
  const { nav } = useApp();
  const ui = useUI();
  const s = getSettings();
  const [p] = useState(() => (params.id ? getProduct(params.id) : null));
  const [materials] = useState(() => listMaterials());
  const steps = listSteps();
  const flourGuess = materials.find((m) => /flour/i.test(m.name));
  const [f, setF] = useState({
    name: p ? p.name : '', code: p ? p.code || '' : '', unit: p ? p.unit : 'pcs', flour_material_id: p ? p.flour_material_id : flourGuess ? flourGuess.id : null,
    cut_weight_g: p ? p.cut_weight_g : null, cut_tolerance_g: p ? p.cut_tolerance_g : 0, max_flour_kg: p ? p.max_flour_kg : 25, default_flour_kg: p ? p.default_flour_kg : 0,
    flag_pct: p ? p.flag_pct : null, active: p ? !!p.active : true, prep_note: p ? p.prep_note || '' : '',
  });
  const bands = bandLabels(s.flourBands);
  const [recipe, setRecipe] = useState(() => (p ? getRecipe(p.id).map((r) => ({ material_id: r.material_id, pct: r.pct, flag_pct: r.flag_pct })) : []));
  const [times, setTimes] = useState(() => (p ? getProductStepTimes(p.id) : { 0: bands.map(() => 15) }));
  const [decks, setDecks] = useState(() => {
    const o = {};
    (p ? getProductDecks(p.id) : s.decks.map((d) => ({ deck: d, top: null, bottom: null }))).forEach((d) => { o[d.deck] = { top: d.top, bottom: d.bottom }; });
    return o;
  });
  const deckVal = (d, k) => (decks[d] && decks[d][k] !== undefined ? decks[d][k] : null);
  const setDeckVal = (d, k) => (v) => setDecks((x) => ({ ...x, [d]: { ...(x[d] || {}), [k]: v } }));
  const setTime = (stepId, band) => (v) => setTimes((t) => {
    const list = (t[stepId] ? t[stepId].slice() : bands.map(() => null));
    while (list.length < bands.length) list.push(null);
    list[band] = v;
    return { ...t, [stepId]: list };
  });
  const timeAt = (stepId, band) => (times[stepId] && times[stepId][band] !== undefined ? times[stepId][band] : null);
  const [adding, setAdding] = useState(false);
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const matById = Object.fromEntries(materials.map((m) => [m.id, m]));
  const available = materials.filter((m) => m.id !== f.flour_material_id && !recipe.some((r) => r.material_id === m.id));

  // Live preview for 10 kg flour using the current (unsaved) recipe.
  const previewFlour = f.default_flour_kg || 10;
  const lines = [{ material_id: f.flour_material_id, name: matById[f.flour_material_id] ? matById[f.flour_material_id].name : 'Flour', unit: 'kg', kg_per_unit: 1, expected: previewFlour, cost: matById[f.flour_material_id] ? matById[f.flour_material_id].cost_per_unit : null }]
    .concat(recipe.filter((r) => matById[r.material_id] && r.pct).map((r) => {
      const m = matById[r.material_id];
      const kg = (previewFlour * r.pct) / 100;
      return { material_id: m.id, name: m.name, unit: m.unit, kg_per_unit: m.kg_per_unit, expected: r3(m.kg_per_unit ? kg / m.kg_per_unit : kg), cost: m.cost_per_unit };
    }));
  const dough = doughKg(lines, null);
  const pieces = expectedPieces(dough, f.cut_weight_g);
  const cost = lines.reduce((a, l) => a + (l.cost ? l.cost * l.expected : 0), 0);

  const save = () => {
    try {
      saveProductFull({ id: p ? p.id : undefined, ...f }, recipe, times, decks);
      ui.toast(p ? `${f.name} updated` : `${f.name} added`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title={p ? `Edit ${p.name}` : 'New product'} footer={<Btn testID="save-product" title="Save product & recipe" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        <Field testID="product-name" label="Product name" value={f.name} onChangeText={set('name')} placeholder="e.g. Coconut Buns" />
        <Field testID="product-code" label="Item code (optional – same as Aronium SKU/barcode)" value={f.code} onChangeText={set('code')} />
        <View>
          <Label>Unit</Label>
          <Choice options={PRODUCT_UNITS.includes(f.unit) ? PRODUCT_UNITS : PRODUCT_UNITS.concat([f.unit])} value={f.unit} onChange={set('unit')} testIDPrefix="punit" />
        </View>
        <View>
          <Label>Status</Label>
          <Chips value={f.active} onChange={set('active')} testIDPrefix="active" options={[{ value: true, label: 'Active' }, { value: false, label: 'Inactive (hidden)' }]} />
        </View>
      </Card>

      <Section title="Cutting, limits & alerts">
        <Card style={{ gap: 14 }}>
          <NumberField testID="product-cut" label="Cutting weight per piece (g)" value={f.cut_weight_g} onChange={set('cut_weight_g')} step={5} unit="g" />
          <NumberField testID="product-cut-tol" label="Cutting allowance ± (g)" value={f.cut_tolerance_g} onChange={set('cut_tolerance_g')} step={1} unit="g" />
          <NumberField testID="product-max" label="Maximum flour per batch (machine capacity)" value={f.max_flour_kg} onChange={set('max_flour_kg')} step={1} unit="kg" />
          <NumberField testID="product-default" label="Usual flour per batch (filled in for the baker)" value={f.default_flour_kg} onChange={set('default_flour_kg')} step={1} unit="kg" />
          <NumberField testID="product-flag" label="Flag ingredient changes above (%)" value={f.flag_pct} onChange={set('flag_pct')} step={0.5} unit="%" hint={`Leave empty to use the default (${s.defaultFlagPct}%).`} />
        </Card>
      </Section>

      <Section title="Recipe – % of flour weight">
        <Card style={{ gap: 12 }}>
          <Select testID="product-flour" label="Flour used (100%)" value={f.flour_material_id} onChange={set('flour_material_id')} options={materials.map((m) => ({ value: m.id, label: m.name }))} />
          <Text style={{ fontSize: 15, color: C.sub }}>Enter every other ingredient as a % of the flour weight. Example: 60% water means 6 kg water for 10 kg flour.</Text>
          {recipe.map((r, i) => {
            const m = matById[r.material_id];
            if (!m) return null;
            return (
              <View key={r.material_id} style={{ borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, gap: 8 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{m.name}</Text>
                  <Btn title="Remove" size="sm" variant="ghost" onPress={() => setRecipe((x) => x.filter((_, k) => k !== i))} />
                </View>
                <NumberField testID={`pct-${m.name}`} value={r.pct} onChange={(v) => setRecipe((x) => x.map((y, k) => (k === i ? { ...y, pct: v } : y)))} step={0.5} unit="% of flour" compact />
                {r.pct ? <Text style={{ fontSize: 14, color: C.sub }}>For {fmt(previewFlour)} kg flour: {fmt(lines.find((l) => l.material_id === m.id)?.expected, m.unit)}</Text> : null}
              </View>
            );
          })}
          {adding ? (
            <View style={{ gap: 10 }}>
              <Label>Tap an ingredient to add</Label>
              {available.length ? <PickGrid items={available} testIDPrefix="add-ing" onPick={(m) => { setRecipe((x) => x.concat([{ material_id: m.id, pct: null }])); setAdding(false); }} />
                : <Text style={{ fontSize: 16, color: C.sub }}>All materials are already in this recipe.</Text>}
              <Btn title="Cancel" size="md" variant="secondary" onPress={() => setAdding(false)} />
            </View>
          ) : <Btn testID="add-ingredient" title="Add ingredient" icon="➕" size="md" variant="secondary" onPress={() => setAdding(true)} />}
        </Card>
        <Card tone="info">
          <H>Preview for {fmt(previewFlour)} kg flour</H>
          <Row label="Dough weight" value={`${fmt(dough)} kg`} />
          <Row label="Expected pieces" value={f.cut_weight_g ? `about ${pieces} ${f.unit}` : 'set the cutting weight'} bold />
          <Row label="Ingredient cost" value={`${money(cost, s.currency)}${pieces ? ` · ${money(cost / pieces, s.currency)} each` : ''}`} />
        </Card>
      </Section>

      <Section title="Step times by batch size (minutes)">
        <Card style={{ gap: 14 }}>
          <Text style={{ fontSize: 15, color: C.sub }}>How long each step lasts before the alarm for the next step. Bigger batches can take longer, so set the minutes for each flour amount. Leave a whole row empty if this product skips that step. Flour amounts are changed in Settings → Rules.</Text>
          {[{ id: 0, name: 'Mixing', kind: 'mix' }].concat(steps).map((st) => (
            <View key={st.id} style={{ gap: 6, borderBottomWidth: 1, borderBottomColor: '#F0EBE3', paddingBottom: 10 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>
                {st.name}{st.kind === 'cut' ? '  ✂️ asks for piece count' : st.kind === 'bake' ? '  🔥 shows deck temperatures' : st.kind === 'mix' ? '  (alarm: check the mix)' : ''}
              </Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {bands.map((bl, bi) => (
                  <NumCell key={bi} testID={`time-${st.name}-${bi}`} label={bl} value={timeAt(st.id, bi)} onChange={setTime(st.id, bi)} unit="min" />
                ))}
              </View>
            </View>
          ))}
          {!steps.length ? <Banner tone="info" message="Add steps (e.g. Cutting, Moulding, Proofing, Baking) in Setup → Shifts & Steps." /> : null}
        </Card>
      </Section>

      <Section title="Oven temperatures – top & bottom element (°C)">
        <Card style={{ gap: 12 }}>
          <Text style={{ fontSize: 15, color: C.sub }}>Each deck heats differently, so set the top and bottom element temperature for this product on every deck. The baker sees these when the batch is ready to bake. Deck names are set in Settings → Rules.</Text>
          {s.decks.map((d) => (
            <View key={d} style={{ gap: 6, borderBottomWidth: 1, borderBottomColor: '#F0EBE3', paddingBottom: 10 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>🔥 {d}</Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <NumCell testID={`deck-${d}-top`} label="Top element" value={deckVal(d, 'top')} onChange={setDeckVal(d, 'top')} unit="°C" />
                <NumCell testID={`deck-${d}-bottom`} label="Bottom element" value={deckVal(d, 'bottom')} onChange={setDeckVal(d, 'bottom')} unit="°C" />
              </View>
            </View>
          ))}
        </Card>
      </Section>

      <Section title="Reminder when mixing starts">
        <Card style={{ gap: 10 }}>
          <Field testID="product-prep" label="Shown to the baker as soon as mixing starts" value={f.prep_note} onChangeText={set('prep_note')} placeholder={s.mixReminder} multiline />
          <Text style={{ fontSize: 14, color: C.sub }}>Leave empty to use the general reminder from Settings.</Text>
        </Card>
      </Section>
    </Screen>
  );
}
