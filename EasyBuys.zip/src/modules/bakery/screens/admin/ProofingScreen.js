// Bakery › Proofing & shift settings (v3.5 B7): the proofing table per product (yeast amount → minutes, worked out in
// proportion between rows), how the yeast is measured, Hot / Normal / Cool minutes and thresholds, and whether the
// bakery still has its own sign-on (off: hours come from the main Time Clock).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Btn, Chips, Field, Section, Select, Label, useApp } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { useAct, Hint } from '../../../../ui/kit.js';
import { listProducts, listMaterials } from '../../../../services/catalog.js';
import * as P from '../../../../services/proofing.js';

const half = (el, key) => <View key={key} style={{ flexBasis: 150, flexGrow: 1 }}>{el}</View>;

export default function ProofingScreen() {
  const { user, refresh } = useApp();
  const act = useAct();
  const products = listProducts();
  const [s, setS] = useState(() => { const x = P.proofSettings(); return { ...x, yeastMaterialId: x.yeastMaterialId ? String(x.yeastMaterialId) : '', hotFrom: String(x.hotFrom), coolBelow: String(x.coolBelow), hotMinutes: String(x.hotMinutes), coolMinutes: String(x.coolMinutes) }; });
  const [pid, setPid] = useState(products.length ? String(products[0].id) : '');
  const [rows, setRows] = useState(() => (products.length ? P.proofTable(products[0].id).map((r) => ({ yeast: String(r.yeast), minutes: String(r.minutes) })) : []));
  const [testYeast, setTestYeast] = useState('');
  const set = (k) => (v) => setS((o) => ({ ...o, [k]: v }));
  const pick = (v) => { setPid(v); setRows(P.proofTable(Number(v)).map((r) => ({ yeast: String(r.yeast), minutes: String(r.minutes) }))); };
  const upd = (n, k, v) => setRows((l) => l.map((r, j) => (j === n ? { ...r, [k]: v } : r)));
  const unit = s.yeastMode === 'per_batch' ? 'g yeast in the batch' : 'g yeast per kg flour';
  const preview = P.interpolate(rows.filter((r) => Number(r.yeast) > 0 && Number(r.minutes) > 0).map((r) => ({ yeast: Number(r.yeast), minutes: Number(r.minutes) })), testYeast === '' ? null : Number(testYeast));
  return (
    <Screen title="Proofing" subtitle="Proofing time by yeast and how warm the bakery is">
      <Section title="How the yeast is measured">
        <Chips value={s.yeastMode} onChange={set('yeastMode')} testIDPrefix="pf-mode" options={Object.entries(P.YEAST_MODES).map(([value, label]) => ({ value, label }))} />
        <Select label="Yeast ingredient" value={s.yeastMaterialId} onChange={set('yeastMaterialId')} options={[{ value: '', label: 'Find it by name ("yeast")' }].concat(listMaterials().map((m) => ({ value: String(m.id), label: `${m.name} (${m.unit})` })))} />
        <Field label='Proofing step (a step whose name contains this word)' value={s.stepWord} onChangeText={set('stepWord')} />
      </Section>
      <Section title="Temperature adjustment">
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          {half(<Field testID="pf-hot" label="Hot from (°C)" value={s.hotFrom} onChangeText={set('hotFrom')} keyboardType="decimal-pad" />, 'a')}
          {half(<Field label="Hot: minutes (− = shorter)" value={s.hotMinutes} onChangeText={set('hotMinutes')} keyboardType="numbers-and-punctuation" />, 'b')}
          {half(<Field label="Cool below (°C)" value={s.coolBelow} onChangeText={set('coolBelow')} keyboardType="decimal-pad" />, 'c')}
          {half(<Field label="Cool: minutes (+ = longer)" value={s.coolMinutes} onChangeText={set('coolMinutes')} keyboardType="numbers-and-punctuation" />, 'd')}
        </View>
        <Btn testID="pf-save" title="Save these settings" icon="💾" size="md" variant="success" onPress={() => act(() => P.saveProofSettings(user, s), 'Saved')} />
      </Section>
      <Section title="Proofing table per product">
        {products.length ? <Select testID="pf-product" label="Product" value={pid} onChange={pick} options={products.map((p) => ({ value: String(p.id), label: p.name }))} /> : <Hint>Add the products first.</Hint>}
        <Hint>{`One row per yeast amount (${unit}) with its proofing minutes. Between two rows the minutes are worked out in proportion. A product without a table keeps its usual proofing time.`}</Hint>
        {rows.map((r, n) => (
          <View key={n} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            {half(<Field testID={`pf-y-${n}`} label={`Yeast (${unit})`} value={r.yeast} onChangeText={(v) => upd(n, 'yeast', v)} keyboardType="decimal-pad" />, 'y')}
            {half(<Field testID={`pf-m-${n}`} label="Minutes" value={r.minutes} onChangeText={(v) => upd(n, 'minutes', v)} keyboardType="number-pad" />, 'm')}
            <Btn title="✕" size="sm" variant="secondary" onPress={() => setRows((l) => l.filter((_, j) => j !== n))} />
          </View>
        ))}
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="pf-row" title="Add a row" icon="➕" size="sm" variant="secondary" onPress={() => setRows((l) => l.concat([{ yeast: '', minutes: '' }]))} />
          {pid ? <Btn testID="pf-table-save" title="Save the table" icon="💾" size="sm" variant="success" onPress={() => act(() => P.saveProofTable(user, Number(pid), rows), 'Table saved')} /> : null}
        </View>
        <Card>
          <H>Try it</H>
          <Field testID="pf-test" label={`Yeast (${unit})`} value={testYeast} onChangeText={setTestYeast} keyboardType="decimal-pad" />
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.info }}>{preview === null ? '—' : `${preview} min (Normal) · ${preview + Number(s.hotMinutes || 0)} min Hot · ${preview + Number(s.coolMinutes || 0)} min Cool`}</Text>
        </Card>
      </Section>
    </Screen>
  );
}
