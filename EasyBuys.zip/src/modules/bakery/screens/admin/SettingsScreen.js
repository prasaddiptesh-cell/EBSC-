import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Field, Chips, Btn, Label, NumberField, NumCell, Banner, EmailList, Row, Section, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { Hint } from '../../../../ui/kit.js';
import { getSettings, saveSettings, randomKey, bandLabels, getShared, setShared, audit, getSetting } from '../../../../services/core.js';
import { resetDatabase, clearActivity } from '../../../../db/init.js';
import { testConnection, syncNow, syncStatus } from '../../../../platform/cloud.js';
import { countPendingOutbox } from '../../../../services/stock.js';
import { setKeepAwake } from '../../../../platform/notify.js';

export default function SettingsScreen({ params = {} }) {
  const { logout, user, nav } = useApp();
  const [timeFmt, setTimeFmt] = useState(() => getShared('time_format', '24h'));
  const ui = useUI();
  const [tab, setTab] = useState(params.tab || 'general');
  const [s, setS] = useState(() => getSettings());
  const [busy, setBusy] = useState(false);
  const set = (k) => (v) => setS((x) => ({ ...x, [k]: v }));
  const st = syncStatus();

  const save = () => {
    try {
      saveSettings(s);
      setKeepAwake(s.keepAwake);
      if (timeFmt !== getShared('time_format', '24h')) { setShared('time_format', timeFmt); audit({ user, action: `Times shown as ${timeFmt === '12h' ? '12-hour (8:30 pm)' : '24-hour (20:30)'}`, table: 'shared_settings', recordUid: 'time_format' }); }
      ui.toast('Settings saved');
    } catch (e) { ui.error(e); }
  };
  const test = async () => {
    try {
      saveSettings(s);
      setBusy(true);
      const r = await testConnection();
      ui.alert({ title: '✅ Connected', message: `The cloud is working.\nGoogle account: ${r.account || '—'}\nFiles are saved in the Drive folder "Easy Buys Bakery Cloud".`, tone: 'success' });
    } catch (e) {
      ui.alert({ title: 'Could not connect', message: e.message || String(e), tone: 'danger' });
    } finally { setBusy(false); }
  };
  const sendNow = async () => {
    setBusy(true);
    const r = await syncNow({ force: true });
    setBusy(false);
    if (r.error) ui.alert({ title: 'Not sent yet', message: `${r.error}\n\nNothing is lost – it will be sent automatically when the tablet is online.`, tone: 'warn' });
    else ui.toast(`Sent ${r.sent || 0} item(s)`);
  };
  const reset = async () => {
    const a = await ui.confirm({ title: 'Reset ALL data?', message: 'This deletes every shift, batch, user, material and product on this tablet and reloads the sample data.', confirmText: 'Continue', tone: 'danger' });
    if (!a) return;
    const b = await ui.confirm({ title: 'Are you absolutely sure?', message: 'This cannot be undone.', confirmText: 'Yes, delete everything', tone: 'danger' });
    if (!b) return;
    try {
      resetDatabase();
      await ui.alert({ title: 'Data reset', message: 'Sample data has been loaded. Please log in again.', tone: 'success' });
      logout();
    } catch (e) { ui.error(e); }
  };
  const fresh = async () => {
    const a = await ui.confirm({ title: 'Remove sample activity?', message: 'Deletes all shifts, batches, deliveries, alerts and history, but KEEPS your users, suppliers, materials, products, checklists and settings. Use this before going live.', confirmText: 'Remove activity', tone: 'danger' });
    if (!a) return;
    try {
      clearActivity();
      ui.toast('Activity cleared – ready for real use');
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Settings" footer={<Btn testID="save-settings" title="Save settings" icon="💾" variant="success" onPress={save} />}>
      <Chips value={tab} onChange={setTab} testIDPrefix="settings-tab"
        options={[{ value: 'general', label: 'General' }, { value: 'rules', label: 'Rules & alerts' }, { value: 'online', label: 'Online & email' }, { value: 'data', label: 'Data' }]} />

      {tab === 'general' ? (
        <Card style={{ gap: 16 }}>
          <Hint>Settings here are shared with every linked tablet and phone (they arrive with the next sync), except the ones marked "this device only".</Hint>
          <Field testID="bakery-name" label="Bakery name" value={s.bakeryName} onChangeText={set('bakeryName')} />
          <Field testID="location-name" label="Location name (used when combining with the shops later)" value={s.locationName} onChangeText={set('locationName')} />
          <Field label="Currency symbol" value={s.currency} onChangeText={set('currency')} />
          <NumberField testID="idle-min" label="Log out automatically after (minutes without use)" value={s.idleLogoutMin} onChange={set('idleLogoutMin')} step={5} unit="min" />
          <View><Label>Show times as (every device)</Label><Chips value={timeFmt} onChange={setTimeFmt} testIDPrefix="time-format" options={[{ value: '24h', label: '24-hour (20:30)' }, { value: '12h', label: '12-hour (8:30 pm)' }]} /></View>
          <View><Label>Keep the screen on during shifts (this device only)</Label><Chips value={s.keepAwake} onChange={set('keepAwake')} testIDPrefix="awake" options={[{ value: true, label: 'Yes (recommended)' }, { value: false, label: 'No' }]} /></View>
          <View><Label>Show sample logins on the login screen</Label><Chips value={s.showDemoPins} onChange={set('showDemoPins')} testIDPrefix="demo" options={[{ value: true, label: 'Show' }, { value: false, label: 'Hide' }]} /></View>
          <Text style={{ fontSize: 14, color: C.sub }}>Hide the sample logins and change the sample PINs and passwords (Users) before real use.</Text>
        </Card>
      ) : null}

      {tab === 'rules' ? (
        <Card style={{ gap: 16 }}>
          <NumberField testID="default-flag" label="Flag ingredient changes above (%) – default for all products" value={s.defaultFlagPct} onChange={set('defaultFlagPct')} step={0.5} unit="%" />
          <NumberField testID="default-tol" label="Stock count tolerance (%) – default for all materials" value={s.defaultTolerance} onChange={set('defaultTolerance')} step={0.5} unit="%" />
          <NumberField label="Warn this many days before stock expires" value={s.expiryAlertDays} onChange={set('expiryAlertDays')} step={1} unit="days" />
          <View><Label>Lot number and expiry date when receiving</Label><Chips value={s.requireLotExpiry} onChange={set('requireLotExpiry')} options={[{ value: false, label: 'Optional' }, { value: true, label: 'Required' }]} /></View>
          <View><Label>Photo of the invoice when receiving</Label><Chips value={s.invoicePhotoRequired} onChange={set('invoicePhotoRequired')} testIDPrefix="photo-req" options={[{ value: false, label: 'Optional' }, { value: true, label: 'Required' }]} /></View>
          <View><Label>Ask bakers for the water temperature</Label><Chips value={s.recordWaterTemp} onChange={set('recordWaterTemp')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} /></View>
          <View><Label>Purchase orders when stock reaches its minimum</Label><Chips value={s.poAuto} onChange={set('poAuto')} testIDPrefix="po-auto" options={[{ value: true, label: 'Create & email automatically' }, { value: false, label: 'Only alert me' }]} /></View>
        </Card>
      ) : null}

      {tab === 'rules' ? (
        <Section title="Batch sizes, ovens & reminders">
          <Card style={{ gap: 12 }}>
            <H>Flour amounts for step times</H>
            <Text style={{ fontSize: 15, color: C.sub }}>Bigger batches take longer. Set where each size ends; every product then has its own minutes for each size (Products → Step times).</Text>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              {s.flourBands.map((b, i) => (
                <NumCell key={i} testID={`band-${i}`} label={`Limit ${i + 1}`} value={b} unit="kg" onChange={(v) => setS((x) => ({ ...x, flourBands: x.flourBands.map((y, k) => (k === i ? v : y)) }))} />
              ))}
            </View>
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              {s.flourBands.length < 4 ? <Btn testID="band-add" title="Add size" icon="➕" size="sm" variant="secondary" onPress={() => setS((x) => ({ ...x, flourBands: x.flourBands.concat([(Number(x.flourBands[x.flourBands.length - 1]) || 0) + 10]) }))} /> : null}
              {s.flourBands.length ? <Btn testID="band-remove" title="Remove last" icon="➖" size="sm" variant="ghost" onPress={() => setS((x) => ({ ...x, flourBands: x.flourBands.slice(0, -1) }))} /> : null}
            </View>
            <Text style={{ fontSize: 15, color: C.text, fontWeight: '700' }}>Sizes: {bandLabels(s.flourBands.filter((b) => b !== null)).join('  ·  ')}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>If you add or remove a size, check the step times of each product afterwards.</Text>
          </Card>
          <Card style={{ gap: 12 }}>
            <H>Oven decks</H>
            <Text style={{ fontSize: 15, color: C.sub }}>Each product has its own temperature for every deck (Products → Oven temperature).</Text>
            {s.decks.map((d, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
                <View style={{ flex: 1 }}><Field testID={`deck-name-${i}`} value={d} onChangeText={(v) => setS((x) => ({ ...x, decks: x.decks.map((y, k) => (k === i ? v : y)) }))} /></View>
                {s.decks.length > 1 ? <Btn title="Remove" size="sm" variant="ghost" onPress={() => setS((x) => ({ ...x, decks: x.decks.filter((_, k) => k !== i) }))} /> : null}
              </View>
            ))}
            <Btn testID="deck-add" title="Add deck" icon="➕" size="sm" variant="secondary" onPress={() => setS((x) => ({ ...x, decks: x.decks.concat([`Deck ${x.decks.length + 1}`]) }))} />
          </Card>
          <Card style={{ gap: 12 }}>
            <Field testID="mix-reminder" label="Reminder shown as soon as mixing starts" value={s.mixReminder} onChangeText={set('mixReminder')} multiline />
            <Text style={{ fontSize: 14, color: C.sub }}>A product can have its own reminder instead (Products).</Text>
          </Card>
        </Section>
      ) : null}

      {tab === 'online' ? (
        <>
          <Card style={{ gap: 16 }}>
            <H>Email addresses</H>
            <EmailList testID="report-email" label="Send the shift report to (after the supervisor approves the balance)" value={s.reportEmails} onChange={set('reportEmails')} />
            <EmailList testID="po-email" label="Send purchase orders (reorders) to" value={s.poEmails} onChange={set('poEmails')} />
            {!s.poEmails.length ? <Text style={{ fontSize: 14, color: C.sub }}>If empty, purchase orders go to the shift report addresses.</Text> : null}
          </Card>
          <Card style={{ gap: 14 }}>
            <H>Online link (this device only)</H>
            <Text style={{ fontSize: 15, color: C.sub }}>Saves reports, photos and daily backups to the bakery Google Drive, sends the emails and feeds the online dashboard. Follow the setup guide to get the web address.</Text>
            <Field testID="cloud-url" label="Cloud web address" value={s.cloudUrl} onChangeText={set('cloudUrl')} placeholder="https://script.google.com/macros/s/…/exec" />
            <Field testID="cloud-key" label="Cloud key (copy this into the cloud program)" value={s.cloudKey} onChangeText={set('cloudKey')} />
            <Btn testID="gen-key" title={s.cloudKey ? 'Make a new key' : 'Create a key'} icon="🔑" size="md" variant="secondary" onPress={() => set('cloudKey')(randomKey(24))} />
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              <Btn testID="test-cloud" title={busy ? 'Please wait…' : 'Test connection'} icon="🌐" variant="info" size="md" style={{ flexGrow: 1 }} onPress={test} disabled={busy || !s.cloudUrl} />
              <Btn title="Send now" icon="📤" variant="secondary" size="md" style={{ flexGrow: 1 }} onPress={sendNow} disabled={busy || !st.configured} />
            </View>
            <Row label="Last successful send" value={st.lastOk || 'never'} />
            <Row label="Waiting to send" value={String(countPendingOutbox())} />
            {st.error ? <Banner tone="warn" message={`Last problem: ${st.error}`} /> : null}
          </Card>
        </>
      ) : null}

      {tab === 'data' ? (
        <Card tone="danger" style={{ gap: 12 }}>
          <H style={{ color: C.danger }}>Data</H>
          <Banner tone="info" message="Data is stored on this tablet. With the online link set up, a full backup is also saved to Google Drive every day." />
          {getSetting('cloud_url', '') ? (
            <>
              <Banner tone="warn" message="This tablet is linked. To clear test data, use Admin › Start fresh – it makes a safety copy and clears every device and the cloud together." />
              <Btn testID="bk-start-fresh" title="Open Start fresh" icon="🧹" variant="warn" size="md" onPress={() => nav.push('StartFresh', {})} />
            </>
          ) : (
            <>
              <Btn testID="clear-activity" title="Remove sample activity (keep setup)" icon="🧹" variant="warn" size="md" onPress={fresh} />
              <Btn testID="reset-data" title="Reset everything to sample data" icon="♻️" variant="danger" size="md" onPress={reset} />
            </>
          )}
        </Card>
      ) : null}
    </Screen>
  );
}
