import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, Field, Chips, Btn, Section, Banner, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listShiftNames, saveShiftNames, listSteps, saveSteps } from '../../../../services/catalog.js';

function move(list, i, d) {
  const j = i + d;
  if (j < 0 || j >= list.length) return list;
  const c = list.slice();
  [c[i], c[j]] = [c[j], c[i]];
  return c;
}

export default function ShiftsStepsScreen() {
  const ui = useUI();
  const { nav } = useApp();
  const [names, setNames] = useState(() => listShiftNames().map((n) => ({ id: n.id, name: n.name })));
  const [steps, setSteps] = useState(() => listSteps().map((s) => ({ id: s.id, name: s.name, kind: s.kind })));
  const save = () => {
    try {
      saveShiftNames(names);
      saveSteps(steps);
      ui.toast('Shifts and steps saved');
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Shifts & Steps" footer={<Btn testID="save-shifts-steps" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Section title="Shift names">
        <Text style={{ fontSize: 15, color: C.sub }}>Bakers choose one of these when starting a shift. Times come from when each baker signs on.</Text>
        {names.map((n, i) => (
          <Card key={n.id || `new${i}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{ flex: 1 }}><Field testID={`shiftname-${i}`} value={n.name} onChangeText={(t) => setNames((x) => x.map((y, k) => (k === i ? { ...y, name: t } : y)))} /></View>
            <Btn title="↑" size="sm" variant="secondary" onPress={() => setNames((x) => move(x, i, -1))} />
            <Btn title="↓" size="sm" variant="secondary" onPress={() => setNames((x) => move(x, i, 1))} />
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setNames((x) => x.filter((_, k) => k !== i))} />
          </Card>
        ))}
        <Btn testID="add-shiftname" title="Add shift name" icon="➕" size="md" variant="secondary" onPress={() => setNames((x) => x.concat([{ name: '' }]))} />
      </Section>
      <Section title="Production steps (after mixing)">
        <Text style={{ fontSize: 15, color: C.sub }}>Mixing is always the first step and Finished the last. Times for each product and batch size, and the oven temperatures, are set in Products & Recipes.</Text>
        {steps.map((s, i) => (
          <Card key={s.id || `new${i}`} style={{ gap: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}><Field testID={`step-${i}`} value={s.name} onChangeText={(t) => setSteps((x) => x.map((y, k) => (k === i ? { ...y, name: t } : y)))} /></View>
              <Btn title="↑" size="sm" variant="secondary" onPress={() => setSteps((x) => move(x, i, -1))} />
              <Btn title="↓" size="sm" variant="secondary" onPress={() => setSteps((x) => move(x, i, 1))} />
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setSteps((x) => x.filter((_, k) => k !== i))} />
            </View>
            <Chips value={s.kind} onChange={(v) => setSteps((x) => x.map((y, k) => (k === i ? { ...y, kind: v } : y)))}
              options={[{ value: 'normal', label: 'Normal step' }, { value: 'cut', label: 'Cutting (asks how many pieces)' }, { value: 'bake', label: 'Baking (shows oven deck temperatures)' }]} />
          </Card>
        ))}
        <Btn testID="add-step" title="Add step" icon="➕" size="md" variant="secondary" onPress={() => setSteps((x) => x.concat([{ name: '', kind: 'normal' }]))} />
        <Banner tone="info" message="Changes apply to new batches. Batches already in progress keep their steps." />
      </Section>
    </Screen>
  );
}
