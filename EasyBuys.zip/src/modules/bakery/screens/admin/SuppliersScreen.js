import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, Field, Chips, Label, Btn, Empty, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listSuppliers, getSupplier, saveSupplier } from '../../../../services/catalog.js';

export function SuppliersScreen() {
  const { nav } = useApp();
  const items = listSuppliers({ includeInactive: true });
  return (
    <Screen title="Suppliers" subtitle="Bakers and supervisors choose from this list when receiving stock"
      footer={<Btn testID="add-supplier" title="Add supplier" icon="➕" onPress={() => nav.push('SupplierEdit', {})} />}>
      {!items.length ? <Empty text="No suppliers yet." /> : null}
      {items.map((s) => (
        <Pressable key={s.id} testID={`supplier-${s.name}`} onPress={() => nav.push('SupplierEdit', { id: s.id })}
          style={({ pressed }) => ({ backgroundColor: s.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🏪 {s.name}{s.active ? '' : ' (inactive)'}</Text>
          <Text style={{ fontSize: 15, color: C.sub }}>{[s.contact, s.phone, s.email].filter(Boolean).join(' · ') || 'No contact details'}</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

export function SupplierEditScreen({ params }) {
  const { nav } = useApp();
  const ui = useUI();
  const [s] = useState(() => (params.id ? getSupplier(params.id) : null));
  const [f, setF] = useState({ name: s ? s.name : '', contact: s ? s.contact || '' : '', phone: s ? s.phone || '' : '', email: s ? s.email || '' : '', active: s ? !!s.active : true });
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const save = () => {
    try {
      saveSupplier({ id: s ? s.id : undefined, ...f });
      ui.toast(s ? 'Supplier updated' : 'Supplier added');
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={s ? `Edit ${s.name}` : 'New supplier'} footer={<Btn testID="save-supplier" title="Save supplier" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        <Field testID="supplier-name" label="Supplier name" value={f.name} onChangeText={set('name')} />
        <Field label="Contact person (optional)" value={f.contact} onChangeText={set('contact')} />
        <Field label="Phone (optional)" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
        <Field testID="supplier-email" label="Email (optional – shown on purchase orders)" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
        <View><Label>Status</Label><Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'Active' }, { value: false, label: 'Inactive (hidden)' }]} /></View>
      </Card>
    </Screen>
  );
}
