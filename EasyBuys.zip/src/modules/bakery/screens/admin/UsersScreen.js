import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, Field, Chips, Btn, Label, RoleBadge, Badge, Banner, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listUsers, getUser, saveUser, ROLES, ROLE_LABEL } from '../../../../services/catalog.js';

export function UsersScreen() {
  const { nav } = useApp();
  const users = listUsers();
  return (
    <Screen title="Users" subtitle={`${users.filter((u) => u.active).length} active`}
      footer={<Btn testID="add-user" title="Add user" icon="➕" onPress={() => nav.push('UserEdit', {})} />}>
      {users.map((u) => (
        <Pressable key={u.id} testID={`user-${u.name}`} onPress={() => nav.push('UserEdit', { id: u.id })}
          style={({ pressed }) => ({ backgroundColor: u.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 30, marginRight: 12 }}>{u.role === 'admin' ? '🛡️' : u.role === 'supervisor' ? '🧑‍💼' : '👷'}</Text>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{u.name}</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <RoleBadge role={u.role} />
              {!u.active ? <Badge text="Inactive" color={C.sub} /> : null}
            </View>
          </View>
          <Text style={{ fontSize: 16, color: C.sub }}>{u.username ? `${u.username} · ` : ''}PIN ••••  ›</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

export function UserEditScreen({ params }) {
  const { nav, user: me } = useApp();
  const ui = useUI();
  const [u] = useState(() => (params.id ? getUser(params.id) : null));
  const [name, setName] = useState(u ? u.name : '');
  const [pin, setPin] = useState(''); // an existing PIN is never shown (blank = keep it)
  const [role, setRole] = useState(u ? u.role : 'worker');
  const [active, setActive] = useState(u ? !!u.active : true);
  const [username, setUsername] = useState(u && u.username ? u.username : '');
  const [password, setPassword] = useState('');

  const save = () => {
    try {
      saveUser({ id: u ? u.id : undefined, name, pin, role, active, username, password }, me);
      ui.toast(u ? `${name} updated` : `${name} added`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title={u ? `Edit ${u.name}` : 'New user'} footer={<Btn testID="save-user" title="Save user" icon="💾" variant="success" onPress={save} />}>
      {u && u.id === me.id ? <Banner tone="info" message="You are editing your own account." /> : null}
      <Card style={{ gap: 16 }}>
        <Field testID="user-name" label="Name" value={name} onChangeText={setName} placeholder="e.g. Ravi" />
        <Field testID="user-pin" label={u ? 'Set a new PIN (4-6 digits) – leave blank to keep the PIN' : 'PIN (4-6 digits, must be unique)'} value={pin} onChangeText={(t) => setPin(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" maxLength={6} />
        <Field testID="user-username" label="Username (optional – for logging in with a password)" value={username} onChangeText={(t) => setUsername(t.replace(/\s/g, '').toLowerCase())} placeholder="e.g. ravi" />
        {username ? <Field testID="user-password" label={u && u.password_hash && u.username === username ? 'New password (leave empty to keep the current one)' : 'Password (at least 6 characters)'} value={password} onChangeText={setPassword} secure /> : null}
        <View>
          <Label>Role</Label>
          <Chips value={role} onChange={setRole} testIDPrefix="role" options={ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] }))} />
          <Text style={{ fontSize: 15, color: C.sub, marginTop: 8 }}>
            {role === 'worker' ? 'Bakers sign on and off, run batches, record wastage, do checklists and receive stock (without prices).'
              : role === 'supervisor' ? 'Supervisors see the dashboard and alerts, receive stock with prices, set the plan, balance stock and approve shifts.'
                : 'Admins can do everything, including baking, setup, settings and stock adjustments.'}
          </Text>
        </View>
        <View>
          <Label>Status</Label>
          <Chips value={active} onChange={setActive} testIDPrefix="active" options={[{ value: true, label: 'Active' }, { value: false, label: 'Inactive (cannot log in)' }]} />
        </View>
      </Card>
    </Screen>
  );
}
