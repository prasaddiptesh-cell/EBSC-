import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Screen, Card, Chips, Label, P, Choice, useRemembered } from '../../../../ui/components.js';
import TxnList from './TxnList.js';
import { listTransactions, listShifts } from '../../../../services/shifts.js';
import { listUsers } from '../../../../services/catalog.js';
import { TYPE_META } from '../../../../ui/theme.js';

// Supervisor: all worker activity. Admin: complete history.
export default function ActivityScreen({ params = {} }) {
  const shifts = useMemo(() => listShifts({ limit: 30 }), []);
  const users = useMemo(() => listUsers(), []);
  const current = shifts.find((s) => s.status !== 'approved');
  const [shiftId, setShiftId] = useRemembered('shiftId', params.shiftId || (params.history ? 'all' : current ? current.id : 'all'));
  const [type, setType] = useRemembered('type', 'all');
  const [userId, setUserId] = useRemembered('userId', 'all');

  const items = listTransactions({
    shiftId: shiftId === 'all' ? undefined : shiftId,
    type: type === 'all' ? undefined : type,
    userId: userId === 'all' ? undefined : userId,
    limit: 500,
  });

  const shiftOptions = [{ value: 'all', label: 'All shifts' }].concat(
    shifts.slice(0, 8).map((s) => ({ value: s.id, label: `${s.shift_date.slice(5)} ${s.shift_name}${s.status === 'open' ? ' (open)' : s.status === 'closed' ? ' (to balance)' : ''}` }))
  );
  const typeOptions = [{ value: 'all', label: 'All types' }].concat(Object.entries(TYPE_META).map(([k, v]) => ({ value: k, label: v.label })));
  const userOptions = [{ value: 'all', label: 'Everyone' }].concat(users.map((u) => ({ value: u.id, label: u.name })));

  return (
    <Screen title={params.history ? 'All Transactions' : 'Worker Activity'} subtitle={`${items.length} entries`}>
      <Card>
        <Label>Shift</Label>
        <Choice options={shiftOptions} value={shiftId} onChange={setShiftId} testIDPrefix="f-shift" />
        <View style={{ height: 12 }} />
        <Label>Type</Label>
        <Choice options={typeOptions} value={type} onChange={setType} testIDPrefix="f-type" />
        <View style={{ height: 12 }} />
        <Label>Person</Label>
        <Choice options={userOptions} value={userId} onChange={setUserId} testIDPrefix="f-user" />
      </Card>
      {items.length >= 500 ? <P>Showing the latest 500 entries. Use the filters to narrow down.</P> : null}
      <TxnList items={items} emptyText="No entries match these filters." />
    </Screen>
  );
}
