import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Chips, Btn, Empty, Badge, useApp, useUI, useRemembered } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listAlerts, ackAlert, ackAllAlerts, ALERT_LABEL } from '../../../../services/stock.js';

const SEV = { bad: C.danger, warn: C.warn, info: C.info };

export default function AlertsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [scope, setScope] = useRemembered('scope', 'open');
  const [, refresh] = useState(0);
  const items = listAlerts({ openOnly: scope === 'open', limit: 300 });
  const ackAll = async () => {
    const ok = await ui.confirm({ title: 'Mark all as seen?', message: `${items.length} alert(s) will be marked as seen by you.`, confirmText: 'Mark all seen' });
    if (!ok) return;
    ackAllAlerts(user.id);
    refresh((n) => n + 1);
  };
  return (
    <Screen title="Alerts" subtitle={`${listAlerts({ openOnly: true }).length} open`}
      footer={scope === 'open' && items.length ? <Btn testID="ack-all" title="Mark all as seen" icon="✔️" variant="secondary" onPress={ackAll} /> : null}>
      <Chips value={scope} onChange={setScope} testIDPrefix="alerts" options={[{ value: 'open', label: 'Open' }, { value: 'all', label: 'All alerts' }]} />
      {!items.length ? <Empty text={scope === 'open' ? 'No open alerts. All good!' : 'No alerts yet.'} /> : null}
      {items.map((a) => (
        <View key={a.id} testID={`alert-${a.id}`} style={{ backgroundColor: C.card, borderRadius: 14, padding: 14, borderLeftWidth: 6, borderLeftColor: SEV[a.severity] || C.warn, borderWidth: 1, borderColor: C.border, gap: 6 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
            <Badge text={ALERT_LABEL[a.type] || a.type} color={SEV[a.severity] || C.warn} />
            <Text style={{ fontSize: 14, color: C.sub }}>{a.created_at.slice(0, 16)}{a.user_name ? ` · ${a.user_name}` : ''}{a.shift_code ? ` · ${a.shift_code}` : ''}</Text>
          </View>
          <Text style={{ fontSize: 17, color: C.text, lineHeight: 24 }}>{a.message}</Text>
          {a.ack_at ? <Text style={{ fontSize: 14, color: C.success }}>✔ Seen by {a.ack_name} at {a.ack_at.slice(11, 16)}</Text>
            : user.role !== 'worker' ? <Btn testID={`ack-${a.id}`} title="Mark as seen" size="sm" variant="secondary" onPress={() => { ackAlert(a.id, user.id); refresh((n) => n + 1); }} /> : null}
        </View>
      ))}
    </Screen>
  );
}
