import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Row, Btn, Banner, Grid, Section, Table, Badge, useApp, useUI, useTick } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { buildSnapshot } from '../../../../services/dashboard.js';
import { syncNow, syncStatus } from '../../../../platform/cloud.js';
import { hoursMinutes } from '../../../../services/core.js';
import { ActiveBatchCard } from '../worker/BakingPanel.js';
import { listActiveBatches } from '../../../../services/batches.js';

function Kpi({ label, value, color }) {
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, borderLeftWidth: 5, borderLeftColor: C.brandRed, minHeight: 86 }}>
      <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{label.toUpperCase()}</Text>
      <Text style={{ fontSize: 28, fontWeight: '900', color: color || C.text }}>{value}</Text>
    </View>
  );
}

export default function DashboardScreen() {
  const { nav } = useApp();
  const ui = useUI();
  useTick(5000);
  const [syncing, setSyncing] = useState(false);
  const s = buildSnapshot();
  const st = syncStatus();
  const t = s.today;
  const sync = async () => {
    setSyncing(true);
    const r = await syncNow({ force: true });
    setSyncing(false);
    if (r.skipped) ui.alert({ title: 'Online link not set up', message: 'Set up the online link in Admin → Settings → Online & email.', tone: 'warn' });
    else if (r.error) ui.alert({ title: 'Could not reach the cloud', message: `${r.error}\n\nEverything is kept on the tablet and will be sent automatically when online.`, tone: 'warn' });
    else ui.toast(`Online dashboard updated${r.sent ? ` · ${r.sent} item(s) sent` : ''}`);
  };
  return (
    <Screen title="Dashboard" subtitle={`${s.bakery} · live`}>
      <Card tone={st.configured ? (st.error ? 'warn' : 'success') : undefined}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
          <View style={{ flex: 1, minWidth: 220 }}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>🌐 Online dashboard & email</Text>
            <Text style={{ fontSize: 15, color: st.error ? C.warn : C.sub }}>
              {!st.configured ? 'Not set up yet' : st.error ? `Last attempt failed: ${st.error}` : `Last update sent ${st.lastOk ? st.lastOk.slice(11, 16) : '—'}`}
              {s.outboxPending ? ` · ${s.outboxPending} waiting to send` : ''}
            </Text>
          </View>
          <Btn testID="sync-now" title={syncing ? 'Sending…' : 'Send now'} size="md" variant="info" onPress={sync} disabled={syncing} />
        </View>
      </Card>
      {s.shift ? (
        <Banner tone={s.shift.statusKey === 'open' ? 'success' : 'warn'} title={`${s.shift.name} shift · ${s.shift.code} · ${s.shift.status}`} message={`Opened ${s.shift.openedAt.slice(11, 16)} by ${s.shift.openedBy} · running ${hoursMinutes(s.minutesSinceShiftOpened)}`} />
      ) : <Banner tone="info" message="No shift running." />}
      <Grid>
        <Kpi label="Batches today" value={t.batches} />
        <Kpi label="Good production" value={t.good} color={C.success} />
        <Kpi label="Yield" value={t.yieldPct === null ? '—' : `${t.yieldPct}%`} color={t.yieldPct !== null && t.yieldPct < 95 ? C.warn : C.success} />
        <Kpi label="Damaged / rejected" value={t.lost} color={t.lost ? C.warn : C.text} />
        <Kpi label="Open alerts" value={s.alerts.length} color={s.alerts.length ? C.danger : C.success} />
        <Kpi label="Low stock" value={s.lowStock.length} color={s.lowStock.length ? C.danger : C.success} />
      </Grid>
      <Section title="In progress" right={s.alerts.length ? <Btn title="View alerts" size="sm" variant="ghost" onPress={() => nav.push('Alerts')} /> : null}>
        {listActiveBatches().length ? listActiveBatches().map((b) => <ActiveBatchCard key={b.id} b={b} onPress={() => nav.push('Batch', { batchId: b.id })} />) : <Text style={{ fontSize: 16, color: C.sub }}>No batches in progress.</Text>}
      </Section>
      <Grid cols={undefined}>
        <Card>
          <H>On shift</H>
          {s.workers.length ? s.workers.map((w) => <Row key={w.name} label={w.name} value={`${w.signedOn} – ${w.signedOff || 'on shift'} · ${hoursMinutes(w.minutes)}`} color={w.signedOff ? C.text : C.success} />) : <Text style={{ color: C.sub }}>Nobody</Text>}
        </Card>
        <Card>
          <H>Today by product</H>
          {t.byProduct.length ? t.byProduct.map((p) => <Row key={p.product} label={p.product} value={`${p.good} good · ${p.yieldPct === null ? '—' : `${p.yieldPct}%`}`} />) : <Text style={{ color: C.sub }}>Nothing finished yet</Text>}
        </Card>
      </Grid>
      <Card>
        <H>Open alerts</H>
        {s.alerts.length ? s.alerts.slice(0, 8).map((a, i) => <Row key={i} label={`${a.time} ${a.type}`} value={a.message} />) : <Text style={{ color: C.sub }}>No open alerts</Text>}
      </Card>
      <Card>
        <H>Stock</H>
        <Table columns={[{ key: 'n', title: 'Item', width: 170 }, { key: 's', title: 'In stock', width: 120, align: 'right' }, { key: 'm', title: 'Minimum', width: 100, align: 'right' }, { key: 'l', title: '', width: 70 }]}
          rows={s.stock.map((m) => ({ n: m.name, s: `${m.stock} ${m.unit}`, m: m.min || '—', l: m.low ? 'LOW' : '', _bg: m.low ? C.dangerSoft : undefined }))} />
      </Card>
      {s.purchaseOrders.length ? (
        <Card>
          <H>Recent purchase orders</H>
          {s.purchaseOrders.map((p) => <Row key={p.no} label={`${p.no} · ${p.supplier}`} value={`${p.date} · ${p.status}`} />)}
        </Card>
      ) : null}
      <Badge text={`Updated ${s.generatedAt.slice(11, 19)}`} color={C.sub} />
    </Screen>
  );
}
