import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Row, Field, NumberField, Chips, Label, Btn, Banner, Badge, PhotoPicker, Empty, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listEquipment, getEquipment, equipmentLog, reportFault, recordWork, saveEquipment } from '../../../../services/equipment.js';
import { money, getSettings } from '../../../../services/core.js';

export default function EquipmentScreen() {
  const { nav, user } = useApp();
  const list = listEquipment();
  return (
    <Screen title="Equipment" subtitle="Report a fault, see repairs and service dates"
      footer={user.role === 'admin' ? <Btn testID="add-equipment" title="Add equipment" icon="➕" onPress={() => nav.push('EquipmentEdit', {})} /> : null}>
      {!list.length ? <Empty text="No equipment set up yet." /> : null}
      {list.map((e) => (
        <Pressable key={e.id} testID={`eq-${e.name}`} onPress={() => nav.push('EquipmentDetail', { id: e.id })}
          style={({ pressed }) => ({ backgroundColor: e.openFaults.length ? C.dangerSoft : C.card, borderRadius: 16, padding: 16, borderWidth: 2, borderColor: e.openFaults.length ? C.danger : e.serviceOverdue ? C.warn : C.border, opacity: pressed ? 0.7 : 1, gap: 4 })}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🔧 {e.name}</Text>
            <Badge text={e.openFaults.length ? 'FAULT' : e.serviceOverdue ? 'SERVICE DUE' : 'OK'} color={e.openFaults.length ? C.danger : e.serviceOverdue ? C.warn : C.success} />
          </View>
          {e.openFaults.map((f) => <Text key={f.id} style={{ fontSize: 15, color: C.danger }}>⚠️ {f.note} ({f.user_name}, {f.at.slice(5, 16)})</Text>)}
          <Text style={{ fontSize: 14, color: C.sub }}>{e.service_days ? `Service every ${e.service_days} days · next due ${e.serviceDue}` : 'No service reminders'}</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

export function EquipmentDetailScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [mode, setMode] = useState(null);
  const [note, setNote] = useState('');
  const [cost, setCost] = useState(null);
  const [photos, setPhotos] = useState([]);
  const [, refresh] = useState(0);
  const e = getEquipment(params.id);
  if (!e) return <Screen title="Equipment"><Banner tone="warn" message="Not found." /></Screen>;
  const log = equipmentLog(e.id);
  const canFix = user.role !== 'worker';
  const cur = getSettings().currency;
  const save = () => {
    try {
      if (mode === 'fault') {
        reportFault(user.id, e.id, note, photos);
        ui.toast('Fault reported – the supervisor has been alerted', 'warn');
      } else {
        recordWork(user.id, e.id, { type: mode, note, cost });
        ui.toast(mode === 'service' ? 'Service recorded' : 'Repair recorded');
      }
      setMode(null); setNote(''); setCost(null); setPhotos([]);
      refresh((n) => n + 1);
    } catch (err) { ui.error(err); }
  };
  return (
    <Screen title={e.name} subtitle={e.openFaults.length ? `${e.openFaults.length} open fault(s)` : 'No open faults'}
      right={user.role === 'admin' ? <Btn title="Edit" size="sm" variant="secondary" onPress={() => nav.push('EquipmentEdit', { id: e.id })} /> : null}>
      {!mode ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="report-fault" title="Report a fault" icon="⚠️" variant="danger" style={{ flexGrow: 1 }} onPress={() => setMode('fault')} />
          {canFix ? <Btn testID="record-repair" title="Record repair" icon="🛠️" variant="success" style={{ flexGrow: 1 }} onPress={() => setMode('repair')} /> : null}
          {canFix ? <Btn testID="record-service" title="Record service" icon="🧰" variant="info" style={{ flexGrow: 1 }} onPress={() => setMode('service')} /> : null}
        </View>
      ) : (
        <Card style={{ gap: 12 }}>
          <H>{mode === 'fault' ? 'Report a fault' : mode === 'repair' ? 'Record a repair' : 'Record a service'}</H>
          <Field testID="eq-note" label={mode === 'fault' ? 'What is wrong?' : 'What was done?'} value={note} onChangeText={setNote} multiline />
          {mode !== 'fault' ? <NumberField label={`Cost (${cur}, optional)`} value={cost} onChange={setCost} step={10} unit={cur} /> : null}
          {mode === 'fault' ? <PhotoPicker label="Photo" value={photos} onChange={setPhotos} /> : null}
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Cancel" variant="secondary" size="md" style={{ flex: 1 }} onPress={() => setMode(null)} />
            <Btn testID="save-eq" title="Save" variant="success" size="md" style={{ flex: 1 }} onPress={save} />
          </View>
        </Card>
      )}
      <Card>
        <Row label="Service every" value={e.service_days ? `${e.service_days} days` : '—'} />
        <Row label="Last service" value={(e.last_service_at || '—').slice(0, 10)} />
        <Row label="Next service due" value={e.serviceDue || '—'} color={e.serviceOverdue ? C.danger : C.text} bold={e.serviceOverdue} />
      </Card>
      <H>History</H>
      {!log.length ? <Empty text="Nothing recorded yet." /> : null}
      {log.map((l) => (
        <View key={l.id} style={{ backgroundColor: C.card, borderRadius: 12, padding: 12, borderLeftWidth: 5, borderLeftColor: l.type === 'fault' ? (l.resolved_at ? C.sub : C.danger) : l.type === 'repair' ? C.success : C.info, borderWidth: 1, borderColor: C.border }}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.type === 'fault' ? '⚠️ Fault' : l.type === 'repair' ? '🛠️ Repair' : '🧰 Service'}{l.cost !== null ? ` · ${money(l.cost, cur)}` : ''}{l.type === 'fault' ? (l.resolved_at ? ` · fixed ${l.resolved_at.slice(0, 10)}` : ' · OPEN') : ''}</Text>
          <Text style={{ fontSize: 16, color: C.text }}>{l.note}</Text>
          <Text style={{ fontSize: 13, color: C.sub }}>{l.user_name} · {l.at.slice(0, 16)}</Text>
        </View>
      ))}
    </Screen>
  );
}

export function EquipmentEditScreen({ params }) {
  const { nav } = useApp();
  const ui = useUI();
  const [e] = useState(() => (params.id ? getEquipment(params.id) : null));
  const [name, setName] = useState(e ? e.name : '');
  const [days, setDays] = useState(e ? e.service_days : 90);
  const [active, setActive] = useState(e ? !!e.active : true);
  const save = () => {
    try {
      saveEquipment({ id: e ? e.id : undefined, name, service_days: days, active });
      ui.toast(e ? 'Equipment updated' : 'Equipment added');
      nav.pop();
    } catch (err) { ui.error(err); }
  };
  return (
    <Screen title={e ? `Edit ${e.name}` : 'New equipment'} footer={<Btn testID="save-equipment" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        <Field testID="equipment-name" label="Name" value={name} onChangeText={setName} placeholder="e.g. Oven 3" />
        <NumberField testID="equipment-days" label="Service every (days, 0 = no reminders)" value={days} onChange={setDays} step={30} unit="days" />
        <View><Label>Status</Label><Chips value={active} onChange={setActive} options={[{ value: true, label: 'In use' }, { value: false, label: 'Removed' }]} /></View>
      </Card>
    </Screen>
  );
}
