// v3.5: the bakery's equipment lives in Vehicles & equipment (one register for the whole business). These screens keep
// the bakery's old names (Equipment, EquipmentDetail, EquipmentEdit) and show the bakery's part of that register:
// bakers report faults (and whether the oven/mixer is out of use); supervisors record repairs and services.
import React from 'react';
import { db } from '../../../../db/connection.js';
import { VeListScreen, VeItemScreen, VeEditScreen } from '../../../vehicles/screens/VeScreens.js';
import { ensureVe } from '../../../vehicles/service.js';

export default function EquipmentScreen({ params = {} }) {
  return <VeListScreen params={{ ...params, bakery: true }} />;
}
// Old links carry the old equipment id; find the same equipment in the register.
export function EquipmentDetailScreen({ params = {} }) {
  ensureVe();
  const row = params.uid ? { uid: params.uid } : db().get("SELECT uid FROM ve_items WHERE legacy_id LIKE ? ORDER BY created_at LIMIT 1", [`%:${params.id}`]);
  return <VeItemScreen params={{ uid: row ? row.uid : '' }} />;
}
export function EquipmentEditScreen({ params = {} }) {
  return <VeEditScreen params={{ ...params, bakery: true }} />;
}
