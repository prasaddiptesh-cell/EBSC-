import React, { useState } from 'react';
import { Screen, Card, Chips, NumberField, Btn, Banner, Row, H, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listProducts } from '../../../../services/catalog.js';
import { getPlan, savePlan, copyPlan, planProgress } from '../../../../services/plan.js';
import { dateStr, clock, fmt, getSettings } from '../../../../services/core.js';

const DAYNAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function PlanScreen() {
  const { user } = useApp();
  const ui = useUI();
  const days = Array.from({ length: 8 }).map((_, i) => { const d = new Date(clock.now()); d.setDate(d.getDate() + i - 1); return d; });
  const [date, setDate] = useState(dateStr(days[1]));
  const load = (d) => Object.fromEntries(getPlan(d).map((p) => [p.product_id, p.qty]));
  const [qty, setQty] = useState(() => load(dateStr(days[1])));
  const products = listProducts();
  const pick = (d) => { setDate(d); setQty(load(d)); };
  const prev = (() => { const d = new Date(`${date}T12:00:00`); d.setDate(d.getDate() - 1); return dateStr(d); })();
  const save = () => {
    try {
      savePlan(user.id, date, qty);
      ui.toast(`Plan for ${date} saved`);
    } catch (e) { ui.error(e); }
  };
  const copy = () => {
    try {
      copyPlan(user.id, prev, date);
      setQty(load(date));
      ui.toast(`Copied plan from ${prev}`);
    } catch (e) { ui.error(e); }
  };
  const progress = date === dateStr() ? planProgress(date) : null;
  return (
    <Screen title="Production Plan" subtitle="How many of each product to make"
      footer={<Btn testID="save-plan" title={`Save plan for ${date}`} icon="💾" variant="success" onPress={save} />}>
      <Chips value={date} onChange={pick} testIDPrefix="plan-day"
        options={days.map((d, i) => ({ value: dateStr(d), label: i === 0 ? 'Yesterday' : i === 1 ? 'Today' : i === 2 ? 'Tomorrow' : `${DAYNAMES[d.getDay()]} ${d.getDate()}` }))} />
      <Btn testID="copy-plan" title={`Copy from ${prev}`} icon="📋" variant="secondary" size="md" onPress={copy} />
      {getSettings().cloudUrl ? <Banner tone="info" message="The plan can also be changed from the online dashboard at home. Changes arrive here within about a minute (the supervisor gets an alert). The newest change wins." /> : null}
      {progress && progress.length ? (
        <Card>
          <H>Progress today</H>
          {progress.map((p) => <Row key={p.product_id} label={p.name} value={`${fmt(p.good)}${p.target ? ` of ${fmt(p.target)}` : ''}${p.inProgress ? ` (+${p.inProgress} in oven)` : ''}`} color={p.remaining ? C.warn : C.success} />)}
        </Card>
      ) : null}
      {products.map((p) => (
        <Card key={p.id}>
          <NumberField testID={`plan-${p.name}`} label={`${p.name} (${p.unit})`} value={qty[p.id] === undefined ? null : qty[p.id]} onChange={(v) => setQty((q) => ({ ...q, [p.id]: v }))} step={10} unit={p.unit} compact />
        </Card>
      ))}
      {!products.length ? <Banner tone="warn" message="No products set up." /> : null}
    </Screen>
  );
}
