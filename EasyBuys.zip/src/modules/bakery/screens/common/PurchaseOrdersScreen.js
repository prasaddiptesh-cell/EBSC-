import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Badge, Empty, Btn, Banner, useApp } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listPurchaseOrders } from '../../../../services/stock.js';
import { getSettings } from '../../../../services/core.js';

export default function PurchaseOrdersScreen() {
  const { nav } = useApp();
  const pos = listPurchaseOrders(100);
  const s = getSettings();
  return (
    <Screen title="Purchase Orders" subtitle="Raised automatically when stock reaches its minimum">
      <Banner tone="info" message="Order ingredients with a normal purchase order (Inventory). These older bakery orders are saved in Google Drive; emailing them is set in Admin › Emails." />
      {!pos.length ? <Empty text="No purchase orders yet." /> : null}
      {pos.map((p) => (
        <Pressable key={p.id} testID={`po-${p.po_no}`} onPress={() => nav.push('ReportView', { kind: 'po', poId: p.id })}
          style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1, gap: 4 })}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{p.po_no} · {p.supplier}</Text>
            <Badge text={p.status === 'sent' ? 'Emailed' : 'Waiting to send'} color={p.status === 'sent' ? C.success : C.warn} />
          </View>
          <Text style={{ fontSize: 15, color: C.sub }}>{p.created_at.slice(0, 16)} · {p.items.map((i) => `${i.name} ${i.qty} ${i.unit}`).join(', ')}</Text>
        </Pressable>
      ))}
      <Btn title="Back to stock" variant="secondary" size="md" onPress={() => nav.pop()} />
    </Screen>
  );
}
