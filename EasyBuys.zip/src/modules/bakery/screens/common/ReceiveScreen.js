import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Label, Select, NumberField, Field, Chips, Btn, Banner, PhotoPicker, Row, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, listSuppliers, stepFor } from '../../../../services/catalog.js';
import { recordReceive, getOpenShift, getClosedShift } from '../../../../services/shifts.js';
import { fmt, money, getSettings } from '../../../../services/core.js';

const blankLine = () => ({ key: Math.random(), material_id: null, qty: null, unit_price: null, lot_no: '', expiry: '' });

export default function ReceiveScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const settings = getSettings();
  const canPrice = user.role !== 'worker';
  const suppliers = listSuppliers();
  const materials = listMaterials();
  const [supplierId, setSupplierId] = useState(null);
  const [invoice, setInvoice] = useState('');
  const [lines, setLines] = useState([blankLine()]);
  const [packOk, setPackOk] = useState(null);
  const [useByOk, setUseByOk] = useState(null);
  const [temp, setTemp] = useState(null);
  const [checkNote, setCheckNote] = useState('');
  const [photos, setPhotos] = useState([]);
  const shift = getOpenShift() || getClosedShift();
  const matById = Object.fromEntries(materials.map((m) => [m.id, m]));
  const setLine = (i, patch) => setLines((ls) => ls.map((l, k) => (k === i ? { ...l, ...patch } : l)));
  const total = lines.reduce((a, l) => a + (l.unit_price && l.qty ? l.unit_price * l.qty : 0), 0);

  const save = async () => {
    if (!supplierId) return ui.alert({ title: 'Choose the supplier', message: 'Pick the supplier from the list.', tone: 'warn' });
    if (!invoice.trim()) return ui.alert({ title: 'Invoice number', message: 'Enter the invoice number.', tone: 'warn' });
    const filled = lines.filter((l) => l.material_id);
    if (!filled.length) return ui.alert({ title: 'Add an item', message: 'Add at least one item that was delivered.', tone: 'warn' });
    if (packOk === null || useByOk === null) return ui.alert({ title: 'Delivery check', message: 'Answer the two delivery check questions.', tone: 'warn' });
    const sup = suppliers.find((s) => s.id === supplierId);
    const ok = await ui.confirm({
      title: 'Save delivery?',
      message: `${sup.name} · invoice ${invoice.trim()}\n${filled.map((l) => `• ${matById[l.material_id].name}: ${fmt(l.qty, matById[l.material_id].unit)}${l.lot_no ? ` (lot ${l.lot_no})` : ''}`).join('\n')}${canPrice && total ? `\nTotal ${money(total, settings.currency)}` : ''}${packOk === false || useByOk === false ? '\n\n⚠️ The delivery problem will be reported to the supervisor.' : ''}`,
      confirmText: 'Save delivery', tone: 'success',
    });
    if (!ok) return;
    try {
      recordReceive(user.id, {
        supplierId, invoiceNo: invoice, photos,
        lines: filled.map((l) => ({ material_id: l.material_id, qty: l.qty, unit_price: l.unit_price, lot_no: l.lot_no, expiry: l.expiry })),
        check: { packOk, useByOk, temp, note: checkNote },
      });
      ui.toast(`Delivery ${invoice.trim()} saved`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Receive Stock" subtitle={shift ? `Recorded on shift ${shift.code}` : 'No shift open – recorded without a shift'}
      footer={<Btn testID="save-receive" title="Save delivery" icon="💾" variant="success" onPress={save} />}>
      <Card style={{ gap: 14 }}>
        {suppliers.length ? (
          <Select testID="supplier" label="Supplier" value={supplierId} onChange={setSupplierId} options={suppliers.map((s) => ({ value: s.id, label: s.name, hint: s.phone || s.email || '' }))} />
        ) : <Banner tone="warn" message="No suppliers yet. Ask the Admin to add suppliers." />}
        <Field testID="invoice-no" label="Invoice number" value={invoice} onChangeText={setInvoice} placeholder="e.g. INV-1234" />
      </Card>

      <H>Items delivered</H>
      {lines.map((l, i) => {
        const m = l.material_id ? matById[l.material_id] : null;
        return (
          <Card key={l.key} style={{ gap: 12 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.sub }}>Item {i + 1}</Text>
              {lines.length > 1 ? <Btn title="Remove" size="sm" variant="ghost" onPress={() => setLines((ls) => ls.filter((_, k) => k !== i))} /> : null}
            </View>
            <Select testID={`line-${i}-material`} label="Material" value={l.material_id} onChange={(v) => setLine(i, { material_id: v })}
              options={materials.map((x) => ({ value: x.id, label: x.name, hint: `In stock ${fmt(x.stock, x.unit)}` }))} />
            {m ? (
              <>
                <NumberField testID={`line-${i}-qty`} label={`Quantity (${m.unit})`} value={l.qty} onChange={(v) => setLine(i, { qty: v })} step={stepFor(m.unit) * 10} unit={m.unit} />
                {canPrice ? <NumberField testID={`line-${i}-price`} label={`Price per ${m.unit} (${settings.currency})${m.cost_per_unit ? ` · last ${money(m.cost_per_unit, settings.currency)}` : ''}`} value={l.unit_price} onChange={(v) => setLine(i, { unit_price: v })} step={0.1} unit={settings.currency} /> : null}
                {m.track_stock ? (
                  <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
                    <View style={{ flex: 1, minWidth: 180 }}><Field testID={`line-${i}-lot`} label={`Lot / batch no.${settings.requireLotExpiry ? '' : ' (optional)'}`} value={l.lot_no} onChangeText={(t) => setLine(i, { lot_no: t })} /></View>
                    <View style={{ flex: 1, minWidth: 180 }}><Field testID={`line-${i}-expiry`} label={`Expiry date YYYY-MM-DD${settings.requireLotExpiry ? '' : ' (optional)'}`} value={l.expiry} onChangeText={(t) => setLine(i, { expiry: t })} placeholder="2026-12-31" /></View>
                  </View>
                ) : null}
              </>
            ) : null}
          </Card>
        );
      })}
      <Btn testID="add-line" title="Add another item" icon="➕" variant="secondary" size="md" onPress={() => setLines((ls) => ls.concat([blankLine()]))} />
      {canPrice && total ? <Card><Row label="Invoice total (priced items)" value={money(total, settings.currency)} bold /></Card> : null}

      <Card style={{ gap: 12 }}>
        <H>Delivery check</H>
        <Label>Packaging in good condition?</Label>
        <Chips value={packOk} onChange={setPackOk} testIDPrefix="pack" options={[{ value: true, label: 'Yes' }, { value: false, label: 'No – damaged' }]} />
        <Label>Use-by / expiry dates checked and OK?</Label>
        <Chips value={useByOk} onChange={setUseByOk} testIDPrefix="useby" options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
        <NumberField label="Temperature of chilled items (optional, should be 5°C or below)" value={temp} onChange={setTemp} step={1} unit="°C" min={-30} />
        <Field label="Notes (optional)" value={checkNote} onChangeText={setCheckNote} placeholder="e.g. 1 bag torn, driver informed" />
      </Card>
      <Card>
        <PhotoPicker testID="invoice-photo" label="Photo of the invoice" value={photos} onChange={setPhotos} required={settings.invoicePhotoRequired} />
      </Card>
    </Screen>
  );
}
