import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Row, Btn, Banner, Table, Badge, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { shiftReport, rangeReport, purchaseOrderDoc } from '../../../../services/reports.js';
import { shareReport, printReport } from '../../../../platform/files.js';
import { PeriodPicker } from '../../../../ui/dateField.js';
import { rangeProblem } from '../../../../services/dates.js';
import { useRemembered } from '../../../../ui/components.js';

const TONE = { good: C.success, warn: C.warn, bad: C.danger };
const ROWBG = { warn: '#FEF6E0', bad: '#FDE7E5' };

export function buildReport(params, user) {
  const costs = user.role !== 'worker';
  if (params.kind === 'shift') return shiftReport(params.shiftId, { costs });
  if (params.kind === 'po') return purchaseOrderDoc(params.poId);
  // Reports from the other modules (Timesheets, Leave, ...) are found through the module registry.
  const { findReport } = require('../../../registry.js');
  const mod = findReport(params.kind);
  if (mod && mod.group !== 'Bakery') return mod.build(params.from, params.to, user, params);
  return rangeReport(params.kind, params.from, params.to);
}

export default function ReportViewScreen({ params }) {
  const { user } = useApp();
  const ui = useUI();
  const [busy, setBusy] = useState(null);
  const [range, setRange] = useRemembered('range', params.from && params.to ? [params.from, params.to] : null);
  const rep = buildReport(range && !rangeProblem(range[0], range[1]) ? { ...params, from: range[0], to: range[1] } : params, user);
  if (!rep) return <Screen title="Report"><Banner tone="warn" message="Report not found." /></Screen>;

  const doExport = async (fmt) => {
    setBusy(fmt);
    try {
      if (fmt === 'print') await printReport(rep);
      else await shareReport(rep, fmt);
    } catch (e) {
      ui.error(e);
    } finally {
      setBusy(null);
    }
  };

  return (
    <Screen title={rep.title} subtitle={rep.subtitle}
      footer={(
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="export-pdf" title={busy === 'pdf' ? 'Making PDF…' : 'PDF'} icon="📄" variant="primary" size="md" style={{ flexGrow: 1 }} onPress={() => doExport('pdf')} disabled={!!busy} />
          <Btn testID="export-xlsx" title={busy === 'xlsx' ? 'Making Excel…' : 'Excel'} icon="📊" variant="success" size="md" style={{ flexGrow: 1 }} onPress={() => doExport('xlsx')} disabled={!!busy} />
          <Btn testID="export-csv" title="CSV" icon="🧾" variant="info" size="md" style={{ flexGrow: 1 }} onPress={() => doExport('csv')} disabled={!!busy} />
          <Btn testID="export-print" title="Print" icon="🖨️" variant="secondary" size="md" style={{ flexGrow: 1 }} onPress={() => doExport('print')} disabled={!!busy} />
        </View>
      )}>
      {range ? <PeriodPicker testID="rv-period" from={range[0]} to={range[1]} onChange={(f, t) => setRange([f, t])} /> : null}
      {rep.approved !== undefined ? (
        rep.approved ? <Banner testID="report-approved" tone="success" title="Approved" message={((rep.info || []).find((i) => i[0] === 'Approved') || [])[1]} />
          : <Banner tone="warn" title="Not yet approved" message="Closing stock and variances are final only after the supervisor approves this shift." />
      ) : null}
      <Card>
        {(rep.info || []).map(([k, v]) => <Row key={k} label={k} value={String(v)} />)}
      </Card>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {(rep.summary || []).map((s) => (
          <View key={s.label} style={{ flexGrow: 1, minWidth: 140, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, borderLeftWidth: 5, borderLeftColor: C.brandRed }}>
            <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{s.label.toUpperCase()}</Text>
            <Text style={{ fontSize: 24, fontWeight: '900', color: TONE[s.tone] || C.text }}>{s.value}</Text>
          </View>
        ))}
      </View>
      {(rep.sections || []).map((sec) => (
        <Card key={sec.title}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <H style={{ marginBottom: 0, color: C.info }}>{sec.title}</H>
            <Badge text={String(sec.rows.length)} color={C.sub} />
          </View>
          {sec.rows.length ? (
            <Table columns={sec.columns.map((c) => ({ key: c.key, title: c.title, align: c.align, width: Math.min(260, Math.max(80, c.title.length * 9 + 24, ...sec.rows.slice(0, 30).map((r) => String(r[c.key] === undefined ? '' : r[c.key]).length * 8 + 16))) }))}
              rows={sec.rows.map((r) => ({ ...r, _bg: ROWBG[r._tone] }))} />
          ) : <Text style={{ fontSize: 15, color: C.sub, fontStyle: 'italic' }}>None</Text>}
          {(sec.totals || []).map((t) => (
            <View key={t.label} style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 16, marginTop: 4, borderTopWidth: t.strong ? 2 : 0, borderColor: C.text, paddingTop: t.strong ? 4 : 0 }}>
              <Text style={{ fontSize: t.strong ? 17 : 15, fontWeight: t.strong ? '900' : '600', color: C.sub }}>{t.label}</Text>
              <Text style={{ fontSize: t.strong ? 17 : 15, fontWeight: t.strong ? '900' : '700', color: C.text, minWidth: 110, textAlign: 'right' }}>{t.value}</Text>
            </View>
          ))}
          {sec.note ? <Text style={{ fontSize: 13, color: C.sub, marginTop: 6 }}>{sec.note}</Text> : null}
        </Card>
      ))}
    </Screen>
  );
}
