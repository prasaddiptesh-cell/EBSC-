import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Chips, Badge, Empty, Grid, Section, useApp, useRemembered } from '../../../../ui/components.js';
import { PeriodPicker, usePeriod } from '../../../../ui/dateField.js';
import { periodRange } from '../../../../services/dates.js';
import { C } from '../../../../ui/theme.js';
import { listShifts, STATUS_LABEL } from '../../../../services/shifts.js';
import { RANGE_REPORTS } from '../../../../services/reports.js';

const STATUS_COLOR = { open: C.info, closed: C.warn, approved: C.success };

// Kept for older callers: the from/to of a named period.
export function rangeFor(preset) {
  const r = periodRange(preset === 'week' ? 'thisweek' : preset);
  return r ? [r.from, r.to] : null;
}

export default function ReportsScreen() {
  const { nav, user } = useApp();
  const [from, to, setRange] = usePeriod('thisweek');
  const [status, setStatus] = useRemembered('status', 'all');
  const shifts = listShifts({ status: status === 'all' ? undefined : status, limit: 60 });
  const reports = RANGE_REPORTS.filter((r) => !r.costs || user.role !== 'worker');
  return (
    <Screen title="Reports" subtitle="View, print, or export as PDF, Excel or CSV">
      <Section title="Reports for a period">
        <PeriodPicker testID="range" from={from} to={to} onChange={setRange} />
        <Grid>
          {reports.map((r) => (
            <Pressable key={r.id} testID={`rr-${r.id}`} onPress={() => nav.push('ReportView', { kind: r.id, from, to })}
              style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 14, borderWidth: 2, borderColor: C.border, minHeight: 110, opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 30 }}>{r.icon}</Text>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.title}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{r.desc}</Text>
            </Pressable>
          ))}
        </Grid>
      </Section>
      <Section title="Shift reports">
        <Chips value={status} onChange={setStatus} testIDPrefix="f-status"
          options={[{ value: 'all', label: 'All' }, { value: 'open', label: 'Open' }, { value: 'closed', label: 'Waiting for balance' }, { value: 'approved', label: 'Approved' }]} />
        {!shifts.length ? <Empty text="No shifts found." /> : null}
        {shifts.map((s) => (
          <Pressable key={s.id} testID={`report-${s.code}`} onPress={() => nav.push('ReportView', { kind: 'shift', shiftId: s.id })}
            style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1, flexDirection: 'row', alignItems: 'center' })}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{s.shift_date} · {s.shift_name}</Text>
              <Text style={{ fontSize: 15, color: C.sub, marginTop: 2 }}>{s.code} · {s.batch_count} batches{s.approved_by_name ? ` · approved by ${s.approved_by_name}` : ''}{s.report_sent_at ? ' · emailed ✓' : ''}</Text>
            </View>
            <Badge text={STATUS_LABEL[s.status]} color={STATUS_COLOR[s.status]} />
            <Text style={{ fontSize: 28, color: C.sub, marginLeft: 10 }}>›</Text>
          </Pressable>
        ))}
      </Section>
    </Screen>
  );
}
