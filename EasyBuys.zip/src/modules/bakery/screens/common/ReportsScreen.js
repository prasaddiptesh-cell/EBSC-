import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Chips, Badge, Empty, Grid, Field, Section, useApp } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listShifts, STATUS_LABEL } from '../../../../services/shifts.js';
import { RANGE_REPORTS } from '../../../../services/reports.js';
import { dateStr, clock } from '../../../../services/core.js';

const STATUS_COLOR = { open: C.info, closed: C.warn, approved: C.success };

export function rangeFor(preset) {
  const now = clock.now();
  const d = (x) => dateStr(x);
  const back = (n) => { const x = new Date(now); x.setDate(x.getDate() - n); return x; };
  if (preset === 'today') return [d(now), d(now)];
  if (preset === 'yesterday') return [d(back(1)), d(back(1))];
  if (preset === 'week') return [d(back(6)), d(now)];
  if (preset === 'month') return [`${d(now).slice(0, 8)}01`, d(now)];
  if (preset === 'lastmonth') {
    const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const last = new Date(now.getFullYear(), now.getMonth(), 0);
    return [d(first), d(last)];
  }
  return null;
}

export default function ReportsScreen() {
  const { nav, user } = useApp();
  const [preset, setPreset] = useState('week');
  const [from, setFrom] = useState(rangeFor('week')[0]);
  const [to, setTo] = useState(rangeFor('week')[1]);
  const [status, setStatus] = useState('all');
  const shifts = listShifts({ status: status === 'all' ? undefined : status, limit: 60 });
  const choose = (p) => {
    setPreset(p);
    const r = rangeFor(p);
    if (r) { setFrom(r[0]); setTo(r[1]); }
  };
  const reports = RANGE_REPORTS.filter((r) => !r.costs || user.role !== 'worker');
  return (
    <Screen title="Reports" subtitle="View, print, or export as PDF, Excel or CSV">
      <Section title="Reports for a period">
        <Chips value={preset} onChange={choose} testIDPrefix="range"
          options={[{ value: 'today', label: 'Today' }, { value: 'yesterday', label: 'Yesterday' }, { value: 'week', label: 'Last 7 days' }, { value: 'month', label: 'This month' }, { value: 'lastmonth', label: 'Last month' }, { value: 'custom', label: 'Custom' }]} />
        {preset === 'custom' ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Field testID="range-from" label="From (YYYY-MM-DD)" value={from} onChangeText={setFrom} /></View>
            <View style={{ flex: 1 }}><Field testID="range-to" label="To (YYYY-MM-DD)" value={to} onChangeText={setTo} /></View>
          </View>
        ) : <Text style={{ fontSize: 16, color: C.sub }}>{from === to ? from : `${from} to ${to}`}</Text>}
        <Grid>
          {reports.map((r) => (
            <Pressable key={r.id} testID={`rr-${r.id}`} onPress={() => nav.push('ReportView', { kind: r.id, from, to })}
              style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 14, borderWidth: 2, borderColor: C.border, minHeight: 110, opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 30 }}>{r.icon}</Text>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.title}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{r.desc}</Text>
            </Pressable>
          ))}
        </Grid>
      </Section>
      <Section title="Shift reports">
        <Chips value={status} onChange={setStatus} testIDPrefix="f-status"
          options={[{ value: 'all', label: 'All' }, { value: 'open', label: 'Open' }, { value: 'closed', label: 'Waiting for balance' }, { value: 'approved', label: 'Approved' }]} />
        {!shifts.length ? <Empty text="No shifts found." /> : null}
        {shifts.map((s) => (
          <Pressable key={s.id} testID={`report-${s.code}`} onPress={() => nav.push('ReportView', { kind: 'shift', shiftId: s.id })}
            style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1, flexDirection: 'row', alignItems: 'center' })}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{s.shift_date} · {s.shift_name}</Text>
              <Text style={{ fontSize: 15, color: C.sub, marginTop: 2 }}>{s.code} · {s.batch_count} batches{s.approved_by_name ? ` · approved by ${s.approved_by_name}` : ''}{s.report_sent_at ? ' · emailed ✓' : ''}</Text>
            </View>
            <Badge text={STATUS_LABEL[s.status]} color={STATUS_COLOR[s.status]} />
            <Text style={{ fontSize: 28, color: C.sub, marginLeft: 10 }}>›</Text>
          </Pressable>
        ))}
      </Section>
    </Screen>
  );
}
