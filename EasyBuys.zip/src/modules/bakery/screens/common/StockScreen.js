import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Grid, Badge, Btn, Banner, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials } from '../../../../services/catalog.js';
import { lowStockItems, listLots, createPurchaseOrders } from '../../../../services/stock.js';
import { fmt, money, getSettings, stamp } from '../../../../services/core.js';

export default function StockScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const [, refresh] = useState(0);
  const items = listMaterials({ stockOnly: true });
  const low = lowStockItems().map((m) => m.id);
  const lots = listLots({ openOnly: true });
  const today = stamp().slice(0, 10);
  const cur = getSettings().currency;
  const canCost = user.role !== 'worker';
  const makePo = async () => {
    const ok = await ui.confirm({ title: 'Create purchase orders?', message: `For ${low.length} item(s) at or below their minimum. One purchase order per supplier will be emailed (when online).`, confirmText: 'Create & send' });
    if (!ok) return;
    try {
      const pos = createPurchaseOrders(user.id, null);
      ui.toast(pos.length ? `Created ${pos.join(', ')}` : 'Nothing to order');
      refresh((n) => n + 1);
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Current Stock" subtitle={low.length ? `${low.length} item(s) at or below minimum` : 'All items above minimum'}
      footer={user.role !== 'worker' ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn title="Receive" icon="📦" variant="success" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('Receive')} />
          {user.role === 'admin' ? <Btn title="Adjust" icon="⚖️" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('Adjust')} /> : null}
          <Btn testID="po-now" title="Purchase orders" icon="🧾" variant="warn" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('PurchaseOrders')} />
          <Btn title="Lots & trace" icon="🔎" variant="info" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('Trace')} />
        </View>
      ) : null}>
      {low.length && user.role !== 'worker' ? (
        <View style={{ gap: 8 }}>
          <Banner tone="danger" title="Low stock" message="These items have reached their minimum level." />
          <Btn testID="create-po" title="Create purchase orders for low items" icon="🧾" variant="warn" size="md" onPress={makePo} />
        </View>
      ) : null}
      <Grid>
        {items.map((m) => {
          const isLow = low.includes(m.id);
          const myLots = lots.filter((l) => l.material_id === m.id && l.expiry);
          const soon = myLots[0];
          const expired = soon && soon.expiry < today;
          return (
            <View key={m.id} testID={`stock-${m.name}`} style={{ backgroundColor: isLow ? C.dangerSoft : C.card, borderRadius: 16, padding: 16, borderWidth: 2, borderColor: isLow ? C.danger : C.border, minHeight: 130 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{m.name}</Text>
              <Text style={{ fontSize: 30, fontWeight: '900', color: isLow ? C.danger : C.text, marginVertical: 4 }}>{fmt(m.stock, m.unit)}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>Minimum {m.reorder_level ? fmt(m.reorder_level, m.unit) : 'not set'}{m.supplier_name ? ` · ${m.supplier_name}` : ''}</Text>
              {canCost && m.cost_per_unit ? <Text style={{ fontSize: 14, color: C.sub }}>{money(m.cost_per_unit, cur)}/{m.unit} · value {money(m.cost_per_unit * m.stock, cur)}</Text> : null}
              {soon ? <Text style={{ fontSize: 14, fontWeight: '700', color: expired ? C.danger : C.warn }}>{expired ? 'EXPIRED' : 'Next expiry'}: {soon.expiry} ({fmt(soon.qty_left, m.unit)}{soon.lot_no ? `, lot ${soon.lot_no}` : ''})</Text> : null}
              {isLow ? <View style={{ marginTop: 6 }}><Badge text={m.reorder_alerted_at ? 'LOW · PO raised' : 'LOW STOCK'} color={C.danger} /></View> : null}
            </View>
          );
        })}
      </Grid>
    </Screen>
  );
}
