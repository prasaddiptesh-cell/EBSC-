import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Row, Field, Empty, Badge, Banner, useApp } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listLots, lotTrace } from '../../../../services/stock.js';
import { fmt, stamp } from '../../../../services/core.js';

// Search a lot number (e.g. after a supplier recall) and see every batch it went into.
export default function TraceScreen() {
  const { nav } = useApp();
  const [q, setQ] = useState('');
  const [openOnly, setOpenOnly] = useState(false);
  const [sel, setSel] = useState(null);
  const lots = listLots({ openOnly, search: q.trim() || undefined });
  const today = stamp().slice(0, 10);
  const t = sel ? lotTrace(sel) : null;
  return (
    <Screen title="Lots & Traceability" subtitle="Search by lot number, invoice or ingredient" onBack={sel ? () => setSel(null) : undefined}>
      {!t ? (
        <>
          <Field testID="trace-search" label="Search" value={q} onChangeText={setQ} placeholder="e.g. FL-2609 or Flour" />
          <Pressable onPress={() => setOpenOnly(!openOnly)}><Text style={{ fontSize: 16, color: C.info, fontWeight: '700' }}>{openOnly ? '☑' : '☐'} Only lots with stock left</Text></Pressable>
          {!lots.length ? <Empty text="No lots found." /> : null}
          {lots.map((l) => (
            <Pressable key={l.id} testID={`lot-${l.lot_no || l.id}`} onPress={() => setSel(l.id)} style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6 }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{l.name} · lot {l.lot_no || '—'}</Text>
                {l.expiry ? <Badge text={`${l.expiry < today ? 'EXPIRED' : 'exp'} ${l.expiry}`} color={l.expiry < today ? C.danger : C.sub} /> : null}
              </View>
              <Text style={{ fontSize: 15, color: C.sub }}>{fmt(l.qty_left, l.unit)} left of {fmt(l.qty_received, l.unit)} · {l.supplier_name || '—'} · inv {l.invoice_no || '—'} · received {l.received_at.slice(0, 10)}</Text>
            </Pressable>
          ))}
        </>
      ) : (
        <>
          <Card>
            <H>{t.lot.name} · lot {t.lot.lot_no || '—'}</H>
            <Row label="Supplier" value={t.lot.supplier_name || '—'} />
            <Row label="Invoice" value={t.lot.invoice_no || '—'} />
            <Row label="Received" value={t.lot.received_at.slice(0, 16)} />
            <Row label="Expiry" value={t.lot.expiry || '—'} />
            <Row label="Quantity" value={`${fmt(t.lot.qty_received, t.lot.unit)} received · ${fmt(t.lot.qty_left, t.lot.unit)} left`} bold />
          </Card>
          <H>Where it went ({t.uses.length})</H>
          {!t.uses.length ? <Banner tone="info" message="This lot has not been used yet." /> : null}
          {t.uses.map((u) => (
            <Pressable key={u.id} onPress={() => u.batch_id && nav.push('Batch', { batchId: u.batch_id })} style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{u.batch_code ? `🍞 ${u.product_name} · ${u.batch_code}` : `${u.txn_type || 'Stock change'}: ${u.txn_note || ''}`}</Text>
              <Text style={{ fontSize: 15, color: C.sub }}>{fmt(u.qty, t.lot.unit)} · {u.created_at.slice(0, 16)}</Text>
            </Pressable>
          ))}
        </>
      )}
    </Screen>
  );
}
