import React from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { C, TYPE_META } from '../../../../ui/theme.js';
import { Empty } from '../../../../ui/components.js';
import { fmt, signed } from '../../../../services/core.js';

// List of stock/production transactions. Every entry shows its ID, user, date, time and shift.
export default function TxnList({ items, emptyText = 'No entries yet.' }) {
  if (!items.length) return <Empty text={emptyText} />;
  return (
    <View style={{ gap: 10 }}>
      {items.map((t) => {
        const meta = TYPE_META[t.type] || { label: t.type, color: C.sub, icon: '•' };
        const item = t.material_name || t.product_name || '';
        const unit = t.material_unit || t.product_unit || '';
        const isSigned = t.type === 'ADJUST' || t.type === 'BALANCE';
        const showVar = t.type === 'USAGE' && t.expected_qty !== null && t.variance !== null && t.variance !== 0;
        const showOpenVar = t.type === 'OPENING' && t.variance;
        return (
          <View key={t.txn_id} testID={`txn-${t.txn_id}`} style={{ backgroundColor: C.card, borderRadius: 14, borderLeftWidth: 6, borderLeftColor: meta.color, padding: 12, borderWidth: 1, borderColor: C.border }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: meta.color }}>{meta.icon} {meta.label}</Text>
              <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{t.txn_id}</Text>
            </View>
            <Text style={{ fontSize: 18, color: C.text, marginTop: 4 }}>
              <Text style={{ fontWeight: '800' }}>{item}</Text>
              {'  '}{t.type === 'PRODUCTION' ? `${fmt(t.qty, unit)} good` : isSigned ? signed(t.qty, unit) : fmt(t.qty, unit)}
            </Text>
            {showVar ? (
              <Text style={{ fontSize: 15, color: C.warn, fontWeight: '700', marginTop: 2 }}>
                ⚠️ Expected {fmt(t.expected_qty, unit)} · variance {signed(t.variance, unit)}
              </Text>
            ) : null}
            {showOpenVar ? (
              <Text style={{ fontSize: 15, color: C.warn, fontWeight: '700', marginTop: 2 }}>
                ⚠️ System had {fmt(t.expected_qty, unit)} · counted {signed(t.variance, unit)}
              </Text>
            ) : null}
            {t.note ? <Text style={{ fontSize: 15, color: C.sub, marginTop: 2 }}>{t.note}</Text> : null}
            <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>
              👤 {t.user_name} · 📅 {t.txn_date} {t.txn_time} · {t.shift_code ? `Shift ${t.shift_code} (${t.shift_name})` : 'No shift'}
            </Text>
          </View>
        );
      })}
    </View>
  );
}
