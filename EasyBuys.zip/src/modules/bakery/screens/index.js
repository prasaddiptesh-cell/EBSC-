import WorkerHome from './worker/WorkerHome.js';
import StartShiftScreen from './worker/StartShiftScreen.js';
import SignScreen from './worker/SignScreen.js';
import NewBatchScreen from './worker/NewBatchScreen.js';
import BatchScreen from './worker/BatchScreen.js';
import { ChecklistsScreen, ChecklistRunScreen } from './worker/ChecklistScreens.js';
import WastageScreen from './worker/WastageScreen.js';
import ExtraUseScreen from './worker/ExtraUseScreen.js';
import MyEntriesScreen from './worker/MyEntriesScreen.js';
import CloseShiftScreen from './worker/CloseShiftScreen.js';
import SupervisorHome from './supervisor/SupervisorHome.js';
import BalanceScreen from './supervisor/BalanceScreen.js';
import AdminHome from './admin/AdminHome.js';
import AdjustScreen from './admin/AdjustScreen.js';
import SettingsScreen from './admin/SettingsScreen.js';
import { UsersScreen, UserEditScreen } from './admin/UsersScreen.js';
import { SuppliersScreen, SupplierEditScreen } from './admin/SuppliersScreen.js';
import { MaterialsScreen, MaterialEditScreen } from './admin/MaterialsScreen.js';
import { ProductsScreen, ProductEditScreen } from './admin/ProductsScreen.js';
import ShiftsStepsScreen from './admin/ShiftsStepsScreen.js';
import { ChecklistsSetupScreen, ChecklistEditScreen } from './admin/ChecklistsSetupScreen.js';
import ActivityScreen from './common/ActivityScreen.js';
import ReportsScreen from './common/ReportsScreen.js';
import ReportViewScreen from './common/ReportViewScreen.js';
import StockScreen from './common/StockScreen.js';
import ReceiveScreen from './common/ReceiveScreen.js';
import AlertsScreen from './common/AlertsScreen.js';
import DashboardScreen from './common/DashboardScreen.js';
import PurchaseOrdersScreen from './common/PurchaseOrdersScreen.js';
import TraceScreen from './common/TraceScreen.js';
import PlanScreen from './common/PlanScreen.js';
import EquipmentScreen, { EquipmentDetailScreen, EquipmentEditScreen } from './common/EquipmentScreen.js';

// Screen name -> component, plus which roles may open it.
const W = ['worker'];
const BAKE = ['worker', 'admin'];
const S = ['supervisor', 'admin'];
const A = ['admin'];
const ALL = ['worker', 'supervisor', 'admin'];

export const SCREENS = {
  WorkerHome: [WorkerHome, W],
  SupervisorHome: [SupervisorHome, ['supervisor']],
  AdminHome: [AdminHome, A],
  StartShift: [StartShiftScreen, BAKE],
  Sign: [SignScreen, BAKE],
  NewBatch: [NewBatchScreen, BAKE],
  Batch: [BatchScreen, ALL],
  Checklists: [ChecklistsScreen, BAKE],
  ChecklistRun: [ChecklistRunScreen, BAKE],
  Wastage: [WastageScreen, BAKE],
  ExtraUse: [ExtraUseScreen, BAKE],
  CloseShift: [CloseShiftScreen, BAKE],
  MyEntries: [MyEntriesScreen, ALL],
  Receive: [ReceiveScreen, ALL],
  Stock: [StockScreen, ALL],
  Equipment: [EquipmentScreen, ALL],
  EquipmentDetail: [EquipmentDetailScreen, ALL],
  EquipmentEdit: [EquipmentEditScreen, A],
  Balance: [BalanceScreen, S],
  Activity: [ActivityScreen, S],
  Reports: [ReportsScreen, S],
  ReportView: [ReportViewScreen, S],
  Dashboard: [DashboardScreen, S],
  Alerts: [AlertsScreen, S],
  Plan: [PlanScreen, S],
  PurchaseOrders: [PurchaseOrdersScreen, S],
  Trace: [TraceScreen, S],
  Adjust: [AdjustScreen, A],
  Settings: [SettingsScreen, A],
  Users: [UsersScreen, A],
  UserEdit: [UserEditScreen, A],
  Suppliers: [SuppliersScreen, A],
  SupplierEdit: [SupplierEditScreen, A],
  Materials: [MaterialsScreen, A],
  MaterialEdit: [MaterialEditScreen, A],
  Products: [ProductsScreen, A],
  ProductEdit: [ProductEditScreen, A],
  ShiftsSteps: [ShiftsStepsScreen, A],
  ChecklistsSetup: [ChecklistsSetupScreen, A],
  ChecklistEdit: [ChecklistEditScreen, A],
};

export const HOME_FOR_ROLE = { worker: 'WorkerHome', supervisor: 'SupervisorHome', admin: 'AdminHome' };
