import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Label, NumberField, Field, Chips, Btn, Banner, Grid, VarianceBox, P, TimeEntry, Row, useApp, useUI, useLayout } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { stepFor } from '../../../../services/catalog.js';
import { getShift, getBalanceSheet, checkVariance, approveShift, getShiftWorkers, signOff } from '../../../../services/shifts.js';
import { shiftChecklistRows } from '../../../../services/checklists.js';
import { stampFromTime, hhmm } from '../../../../services/core.js';
import { fmt, signed } from '../../../../services/core.js';

const REASONS = ['Spillage', 'Counting error', 'Unrecorded usage', 'Recipe deviation', 'Theft / loss', 'Delivery short', 'Other'];

export default function BalanceScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const { width } = useLayout();
  const cols = width >= 1000 ? 2 : 1;
  const [shift] = useState(() => getShift(params.shiftId));
  const [sheet] = useState(() => getBalanceSheet(params.shiftId));
  const [counts, setCounts] = useState({});
  const [reasonChoice, setReasonChoice] = useState({});
  const [reasonText, setReasonText] = useState({});
  const [notes, setNotes] = useState('');
  const [offTimes, setOffTimes] = useState({});
  const [, bump] = useState(0);

  if (!shift) return <Screen title="Balance Stock"><P>Shift not found.</P></Screen>;
  if (shift.status !== 'closed') {
    return (
      <Screen title="Balance Stock">
        <Banner tone="info" message={shift.status === 'open' ? 'This shift is still open. A worker must close it first.' : 'This shift has already been approved.'} />
      </Screen>
    );
  }

  const reasonFor = (id) => {
    const c = reasonChoice[id];
    const t = (reasonText[id] || '').trim();
    if (!c) return t;
    if (c === 'Other') return t;
    return t ? `${c} - ${t}` : c;
  };

  const stillOn = getShiftWorkers(shift.id).filter((w) => !w.signed_off_at);
  const checkProblems = shiftChecklistRows(shift.id).filter((r) => !r.status || r.out_of_range || r.status === 'skipped');
  const rows = sheet.map((r) => {
    const a = counts[r.material_id];
    const has = a !== null && a !== undefined;
    const v = has ? checkVariance(r.expected, a, r.tolerance_pct) : null;
    return { ...r, has, v, needsReason: !!(v && v.over && !reasonFor(r.material_id)) };
  });
  const counted = rows.filter((r) => r.has).length;
  const overList = rows.filter((r) => r.v && r.v.over);
  const needReason = rows.filter((r) => r.needsReason);

  const approve = async () => {
    if (stillOn.length) {
      return ui.alert({ title: 'Sign-off times missing', message: `Enter the sign-off time for: ${stillOn.map((w) => w.name).join(', ')} (at the top of this screen).`, tone: 'warn' });
    }
    if (counted < rows.length) {
      return ui.alert({ title: 'Counts missing', message: `Enter the physical count for: ${rows.filter((r) => !r.has).map((r) => r.name).join(', ')}`, tone: 'warn' });
    }
    if (needReason.length) {
      return ui.alert({ title: 'Reason required', message: `These items are over the allowed tolerance. Choose a reason for: ${needReason.map((r) => r.name).join(', ')}`, tone: 'danger' });
    }
    const ok = await ui.confirm({
      title: `Approve ${shift.shift_name} shift?`,
      message: `${overList.length ? `${overList.length} item(s) over tolerance (reasons given).\n` : 'All items within tolerance.\n'}Stock levels will be set to your physical counts. This cannot be undone.`,
      confirmText: 'Approve & finalise', tone: 'success',
    });
    if (!ok) return;
    try {
      const reasons = {};
      rows.forEach((r) => { const t = reasonFor(r.material_id); if (t) reasons[r.material_id] = t; });
      approveShift(user.id, shift.id, counts, reasons, notes);
      ui.toast('Shift approved · report will be emailed when online');
      nav.replace('ReportView', { kind: 'shift', shiftId: shift.id });
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Balance Stock" subtitle={`${shift.shift_date} ${shift.shift_name} · ${shift.code}`}
      footer={(
        <View style={{ gap: 8 }}>
          <Text testID="balance-progress" style={{ fontSize: 16, fontWeight: '700', color: needReason.length ? C.danger : C.sub, textAlign: 'center' }}>
            Counted {counted} of {rows.length}{overList.length ? ` · ${overList.length} over tolerance` : ''}{needReason.length ? ` · ${needReason.length} need a reason` : ''}
          </Text>
          <Btn testID="approve-shift" title="Approve & finalise shift" icon="✅" variant="success" onPress={approve} />
        </View>
      )}>
      {stillOn.length ? (
        <Card tone="warn">
          <H>Sign-off times missing</H>
          <P>These bakers did not sign off. Enter the time they finished.</P>
          {stillOn.map((w) => (
            <View key={w.id} style={{ gap: 8, marginTop: 10 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{w.name} · signed on {hhmm(w.signed_on_at)}</Text>
              <TimeEntry testID={`off-${w.name}`} value={offTimes[w.id] || null} onChange={(v) => setOffTimes((o) => ({ ...o, [w.id]: v }))} />
              <Btn testID={`sign-off-${w.name}`} title={`Sign off ${w.name}`} size="md" variant="warn" onPress={() => {
                try {
                  const t = offTimes[w.id];
                  signOff(w.id, t ? stampFromTime(t.h, t.m) : null, user.id, shift.id);
                  ui.toast(`${w.name} signed off`);
                  bump((n) => n + 1);
                } catch (e) { ui.error(e); }
              }} />
            </View>
          ))}
        </Card>
      ) : null}
      {checkProblems.length ? (
        <Card tone="warn">
          <H>Checklist problems this shift</H>
          {checkProblems.map((r, i) => <Row key={i} label={`${r.list}${r.run_user ? ` (${r.run_user})` : ''}: ${r.item}`} value={!r.status ? 'NOT DONE' : r.out_of_range ? `${r.value}°C OUT OF RANGE` : `Skipped: ${r.note}`} color={!r.status || r.out_of_range ? C.danger : C.warn} />)}
        </Card>
      ) : null}
      <Banner tone="info" title="How to balance" message="Count each item physically and enter the amount. The app compares it with the expected stock. If the difference is bigger than the allowed tolerance, choose a reason." />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn title="Fill all with expected" size="sm" variant="secondary" onPress={() => setCounts(Object.fromEntries(sheet.map((r) => [r.material_id, r.expected])))} />
        <Btn title="Clear all counts" size="sm" variant="secondary" onPress={() => setCounts({})} />
      </View>
      <Grid cols={cols}>
        {rows.map((r) => (
          <Card key={r.material_id} tone={r.v ? (r.v.over ? 'danger' : r.v.variance ? 'warn' : 'success') : undefined}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ fontSize: 21, fontWeight: '800', color: C.text }}>{r.name}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>Tolerance ±{fmt(r.tolerance_pct)}%</Text>
            </View>
            <Text style={{ fontSize: 15, color: C.sub, marginVertical: 6 }}>
              Opening {fmt(r.opening)} + received {fmt(r.received)} − used {fmt(r.used)} − wasted {fmt(r.wasted)} {r.adjusted ? `${r.adjusted > 0 ? '+' : '−'} adjusted ${fmt(Math.abs(r.adjusted))} ` : ''}= expected <Text style={{ fontWeight: '800', color: C.text }}>{fmt(r.expected, r.unit)}</Text>
            </Text>
            <NumberField testID={`count-${r.name}`} label="Physical count" value={counts[r.material_id] === undefined ? null : counts[r.material_id]} onChange={(v) => setCounts((c) => ({ ...c, [r.material_id]: v }))} step={stepFor(r.unit)} unit={r.unit} compact />
            <View style={{ height: 10 }} />
            <VarianceBox expected={r.expected} actual={r.has ? counts[r.material_id] : null} unit={r.unit} tolerancePct={r.tolerance_pct} />
            {r.v && r.v.over ? (
              <View style={{ marginTop: 12, gap: 10 }}>
                <Banner tone="danger" title={`Over tolerance (allowed ±${fmt(r.v.limit, r.unit)})`} message={`Variance ${signed(r.v.variance, r.unit)}. A reason is required.`} />
                <Label>Variance reason</Label>
                <Chips options={REASONS} value={reasonChoice[r.material_id] || null} onChange={(v) => setReasonChoice((x) => ({ ...x, [r.material_id]: v }))} testIDPrefix={`reason-${r.name}`} />
                <Field value={reasonText[r.material_id] || ''} onChangeText={(t) => setReasonText((x) => ({ ...x, [r.material_id]: t }))} placeholder={reasonChoice[r.material_id] === 'Other' ? 'Type the reason (required)' : 'Extra detail (optional)'} />
              </View>
            ) : r.v && r.v.variance ? (
              <View style={{ marginTop: 10 }}>
                <Field value={reasonText[r.material_id] || ''} onChangeText={(t) => setReasonText((x) => ({ ...x, [r.material_id]: t }))} placeholder="Within tolerance – note (optional)" />
              </View>
            ) : null}
          </Card>
        ))}
      </Grid>
      <Card>
        <Field label="Supervisor notes (optional)" value={notes} onChangeText={setNotes} multiline />
      </Card>
    </Screen>
  );
}
