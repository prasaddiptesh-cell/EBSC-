import React from 'react';
import { View } from 'react-native';
import { Screen, Tile, Grid, Banner, Btn, Card, Row, Section, useApp, useTick } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { getOpenShift, getClosedShift, getShiftWorkers } from '../../../../services/shifts.js';
import { listActiveBatches } from '../../../../services/batches.js';
import { countOpenAlerts, lowStockItems } from '../../../../services/stock.js';
import { listItems as listVe } from '../../../vehicles/service.js';
import { getSettings, hhmm } from '../../../../services/core.js';

// Shift status block shared by Supervisor and Admin home screens.
export function ShiftStatus() {
  const { nav } = useApp();
  const open = getOpenShift();
  const pending = getClosedShift();
  const alerts = countOpenAlerts();
  return (
    <>
      {alerts ? <Banner testID="alerts-banner" tone="warn" title={`${alerts} open alert(s)`} message="Ingredient changes, short yields, temperatures, faults and more. Tap Alerts to review." /> : null}
      {pending ? (
        <Card tone="warn">
          <Banner tone="warn" title="Stock balance needed" message={`${pending.shift_name} shift ${pending.code} was closed at ${hhmm(pending.closed_at)} by ${pending.closed_by_name}. Count the stock and approve it.`} />
          <View style={{ marginTop: 12 }}>
            <Btn testID="balance-now" title="Balance stock now" icon="⚖️" variant="warn" onPress={() => nav.push('Balance', { shiftId: pending.id })} />
          </View>
        </Card>
      ) : null}
      {open ? (
        <Card tone="success">
          <Row label="Open shift" value={`${open.shift_name} · ${open.code}`} bold />
          <Row label="Started" value={`${hhmm(open.opened_at)} by ${open.opened_by_name}`} />
          <Row label="On shift" value={getShiftWorkers(open.id).filter((w) => !w.signed_off_at).map((w) => w.name).join(', ') || '—'} />
          <Row label="Batches in progress" value={String(listActiveBatches().length)} />
        </Card>
      ) : null}
      {!open && !pending ? <Banner tone="info" title="No shift running" message="All shifts are balanced and approved. A baker can start the next shift." /> : null}
    </>
  );
}

export function ManagementTiles() {
  const { nav } = useApp();
  const pending = getClosedShift();
  const alerts = countOpenAlerts();
  const low = lowStockItems().length;
  const faults = listVe({ bakery: true }).filter((e) => e.openFaults.length || e.dueState !== 'ok').length;
  return (
    <Grid>
      <Tile testID="tile-dashboard" icon="📈" title="Dashboard" subtitle="Live view" color={C.info} onPress={() => nav.push('Dashboard')} />
      <Tile testID="tile-alerts" icon="⚠️" title="Alerts" subtitle="Needs attention" badge={alerts || null} color={C.danger} onPress={() => nav.push('Alerts')} />
      <Tile testID="tile-balance" icon="⚖️" title="Balance Stock" subtitle={pending ? 'Shift waiting for count' : 'Nothing to balance'} disabled={!pending} badge={pending ? '1' : null} color={C.warn} onPress={() => nav.push('Balance', { shiftId: pending.id })} />
      <Tile testID="tile-reports" icon="📊" title="Reports" subtitle="PDF · Excel · CSV" onPress={() => nav.push('Reports')} />
      <Tile testID="tile-plan" icon="🎯" title="Production Plan" subtitle="Daily targets" color={C.success} onPress={() => nav.push('Plan')} />
      <Tile testID="tile-stock" icon="🏷️" title="Stock" subtitle={low ? `${low} low` : 'Levels, lots, orders'} badge={low || null} color={C.primaryDark} onPress={() => nav.push('Stock')} />
      <Tile testID="tile-receive" icon="📦" title="Receive Stock" subtitle="Deliveries in" color={C.success} onPress={() => nav.push('Receive')} />
      <Tile testID="tile-activity" icon="👀" title="Activity" subtitle="Every entry" color={C.info} onPress={() => nav.push('Activity')} />
      <Tile testID="tile-equipment" icon="🔧" title="Equipment" subtitle={faults ? `${faults} need attention` : 'Faults & service'} badge={faults || null} color={C.sub} onPress={() => nav.push('Equipment')} />
      <Tile testID="tile-po" icon="🧾" title="Purchase Orders" subtitle="Reorders" color={C.warn} onPress={() => nav.push('PurchaseOrders')} />
    </Grid>
  );
}

export default function SupervisorHome() {
  const { user } = useApp();
  useTick(15000);
  return (
    <Screen title={getSettings().bakeryName} subtitle={`Supervisor · ${user.name}`}>
      <ShiftStatus />
      <Section title="Manage">
        <ManagementTiles />
      </Section>
    </Screen>
  );
}
