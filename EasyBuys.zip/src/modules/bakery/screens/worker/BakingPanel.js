import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Tile, Grid, Banner, Btn, Card, Row, Section, StepTimeline, useApp, useTick, countdown } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { stepTitle, prepReminder, decksText } from './batchUi.js';
import { getOpenShift, getClosedShift, getShiftWorkers, getMyShiftRow } from '../../../../services/shifts.js';
import { listActiveBatches, needsCutCount } from '../../../../services/batches.js';
import { myChecklists } from '../../../../services/checklists.js';
import { planProgress } from '../../../../services/plan.js';
import { hhmm, hoursMinutes, minutesBetween, stamp, fmt } from '../../../../services/core.js';

export function ActiveBatchCard({ b, onPress }) {
  const over = b.secondsToDue !== null && b.secondsToDue < 0;
  return (
    <Pressable testID={`batch-${b.code}`} onPress={onPress} style={({ pressed }) => ({
      backgroundColor: over ? C.dangerSoft : C.card, borderRadius: 16, padding: 14, borderWidth: 2, borderColor: over ? C.danger : C.info, opacity: pressed ? 0.75 : 1, gap: 8,
    })}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🍞 {b.product_name}</Text>
        <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{b.code} · {b.user_name}</Text>
      </View>
      <StepTimeline steps={b.steps} currentIdx={b.current_step} />
      <Text style={{ fontSize: 18, fontWeight: '800', color: over ? C.danger : C.info }}>
        {b.currentStep && b.nextStep ? (over ? `⏰ ${stepTitle(b)}` : `${b.currentStep.name} (${hoursMinutes(b.inStepMinutes)}) · done ${countdown(b.secondsToDue)}`) : ''}
      </Text>
      {b.currentStep && b.currentStep.kind === 'mix' ? <Text style={{ fontSize: 16, fontWeight: '700', color: C.warn }}>🧈 {prepReminder(b)}</Text> : null}
      {b.currentStep && b.currentStep.kind === 'bake' && b.deck ? <Text style={{ fontSize: 17, fontWeight: '800', color: C.danger }}>🔥 {decksText(b)}</Text> : null}
      {needsCutCount(b) ? <Text style={{ fontSize: 17, fontWeight: '800', color: C.warn }}>✂️ Tap to enter the pieces cut when cutting is finished</Text> : null}
      <Text style={{ fontSize: 15, color: C.sub }}>{fmt(b.flour_kg)} kg flour · cut {fmt(b.cut_weight_g)} g · expect ~{b.expected_pieces}{b.cut_pieces !== null ? ` · cut ${b.cut_pieces}` : ''}</Text>
    </Pressable>
  );
}

// Everything a baker needs: shift, sign on/off, plan, open batches and actions.
export default function BakingPanel() {
  const { user, nav } = useApp();
  useTick(1000);
  const open = getOpenShift();
  const pending = getClosedShift();
  const me = open ? getMyShiftRow(open.id, user.id) : null;
  const onShift = !!(me && !me.signed_off_at);
  const batches = open ? listActiveBatches() : [];
  const lists = onShift ? myChecklists(user.id) : [];
  const listsLeft = lists.filter((l) => l.left > 0);
  const plan = planProgress();

  return (
    <View style={{ gap: 14 }}>
      {!open && pending ? <Banner tone="warn" title="Waiting for supervisor" message={`The ${pending.shift_name} shift (${pending.shift_date}) is closed and waiting for the stock balance. A new shift can start after it is approved.`} /> : null}
      {!open && !pending ? <Banner tone="info" title="No shift is open" message="Tap Start Shift. You will choose the shift, confirm the opening stock and be signed on." /> : null}

      {open ? (
        <Card tone={onShift ? 'success' : 'warn'}>
          <Row label="Shift" value={`${open.shift_name} · ${open.code}`} bold />
          <Row label="Started" value={`${hhmm(open.opened_at)} by ${open.opened_by_name}`} />
          <Row label="On shift" value={getShiftWorkers(open.id).filter((w) => !w.signed_off_at).map((w) => w.name).join(', ') || '—'} />
          {onShift ? <Row label="You signed on" value={`${hhmm(me.signed_on_at)} · ${hoursMinutes(minutesBetween(me.signed_on_at, stamp()))}`} color={C.success} bold /> : null}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 12, flexWrap: 'wrap' }}>
            {onShift
              ? <Btn testID="sign-off" title="Sign off" icon="👋" variant="secondary" size="md" style={{ flex: 1 }} onPress={() => nav.push('Sign', { mode: 'off' })} />
              : <Btn testID="sign-on" title={me ? 'Sign on again' : 'Sign on to this shift'} icon="✋" variant="success" style={{ flex: 1 }} onPress={() => nav.push('Sign', { mode: 'on' })} />}
          </View>
        </Card>
      ) : null}

      {onShift && listsLeft.length ? (
        <Banner tone="warn" title="Checklists to do" message={listsLeft.map((l) => `${l.name} (${l.left} left)`).join(' · ')} />
      ) : null}

      {plan.length ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 6 }}>🎯 Today's plan</Text>
          {plan.map((p) => (
            <View key={p.product_id} style={{ marginBottom: 8 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{p.name}{p.unplanned ? ' (extra)' : ''}</Text>
                <Text style={{ fontSize: 16, fontWeight: '800', color: p.remaining ? C.warn : C.success }}>{fmt(p.good)}{p.target ? ` of ${fmt(p.target)}` : ''}{p.inProgress ? ` (+${p.inProgress} in oven)` : ''}</Text>
              </View>
              {p.target ? (
                <View style={{ height: 10, backgroundColor: '#EEE8E1', borderRadius: 5, marginTop: 4 }}>
                  <View style={{ height: 10, borderRadius: 5, width: `${Math.min(100, p.pct || 0)}%`, backgroundColor: p.remaining ? C.warn : C.success }} />
                </View>
              ) : null}
            </View>
          ))}
        </Card>
      ) : null}

      {batches.length ? (
        <Section title={`Batches in progress (${batches.length})`}>
          {batches.map((b) => <ActiveBatchCard key={b.id} b={b} onPress={() => nav.push('Batch', { batchId: b.id })} />)}
        </Section>
      ) : null}

      {!open ? (
        <Grid cols={1}>
          <Tile testID="tile-start" icon="▶️" title="Start Shift" subtitle={pending ? 'Waiting for supervisor approval' : 'Choose shift, confirm opening stock'} color={C.success} disabled={!!pending} onPress={() => nav.push('StartShift')} />
        </Grid>
      ) : null}

      {onShift ? (
        <Grid>
          <Tile testID="tile-new-batch" icon="🥣" title="New Batch" subtitle="Enter flour, start mixing" onPress={() => nav.push('NewBatch')} color={C.primary} />
          <Tile testID="tile-checklists" icon="✅" title="Checklists" subtitle="Cleaning & checks" onPress={() => nav.push('Checklists')} color={C.success} badge={listsLeft.length ? String(listsLeft.reduce((a, l) => a + l.left, 0)) : null} />
          <Tile testID="tile-wastage" icon="🗑️" title="Wastage" subtitle="Spilled, expired" onPress={() => nav.push('Wastage')} color={C.danger} />
          <Tile testID="tile-extra" icon="🧂" title="Other Use" subtitle="Used outside a batch" onPress={() => nav.push('ExtraUse')} color={C.warn} />
          <Tile testID="tile-receive" icon="📦" title="Receive Stock" subtitle="Delivery arrived" onPress={() => nav.push('Receive')} color={C.success} />
          <Tile testID="tile-fault" icon="🔧" title="Report Fault" subtitle="Oven, mixer, fridge" onPress={() => nav.push('Equipment')} color={C.sub} />
          <Tile testID="tile-entries" icon="📋" title="My Entries" subtitle="What I recorded" onPress={() => nav.push('MyEntries')} color={C.info} />
          <Tile testID="tile-close" icon="🏁" title="Close Shift" subtitle="End of shift summary" onPress={() => nav.push('CloseShift')} color={C.primaryDark} />
        </Grid>
      ) : (
        <Grid>
          <Tile testID="tile-entries" icon="📋" title="My Entries" subtitle="Everything I recorded" onPress={() => nav.push('MyEntries')} color={C.info} />
          <Tile testID="tile-fault" icon="🔧" title="Report Fault" subtitle="Equipment problem" onPress={() => nav.push('Equipment')} color={C.sub} />
        </Grid>
      )}
    </View>
  );
}
