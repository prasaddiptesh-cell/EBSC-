import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import {
  Screen, Card, H, Row, NumberField, Field, Btn, Banner, Table, StepTimeline, PhotoPicker, useApp, useUI, useTick, countdown,
} from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { getBatch, confirmNextStep, snoozeNextStep, finishBatch, batchStats, needsCutCount, recordCutCount } from '../../../../services/batches.js';
import { batchLots } from '../../../../services/stock.js';
import { fmt, signed, hhmm, hoursMinutes, money, getSettings } from '../../../../services/core.js';
import { rescheduleReminders } from '../../../../platform/notify.js';
import { stepTitle, confirmLabel, DeckPicker, BakingInfo, PrepInfo } from './batchUi.js';

export function SnoozeButtons({ onSnooze, testIDPrefix = 'snooze' }) {
  const [custom, setCustom] = useState(null);
  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {[5, 10, 15, 30].map((m) => <Btn key={m} testID={`${testIDPrefix}-${m}`} title={`Snooze ${m} min`} size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => onSnooze(m)} />)}
      </View>
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}><NumberField testID={`${testIDPrefix}-custom`} label="Or snooze for (minutes)" value={custom} onChange={setCustom} step={5} unit="min" compact /></View>
        <Btn title="Snooze" size="md" variant="warn" onPress={() => custom && onSnooze(custom)} />
      </View>
    </View>
  );
}

export default function BatchScreen({ params }) {
  const { user } = useApp();
  const ui = useUI();
  useTick(1000);
  const [, refresh] = useState(0);
  const [pieces, setPieces] = useState(null);
  const [deck, setDeck] = useState([]);
  const [fin, setFin] = useState({ good: null, damaged: 0, rejected: 0, other: 0, comments: '', photos: [] });
  const b = getBatch(params.batchId);
  if (!b) return <Screen title="Batch"><Banner tone="warn" message="Batch not found." /></Screen>;
  const canCost = user.role !== 'worker';
  const cur = getSettings().currency;
  const next = b.nextStep;
  const done = () => { refresh((n) => n + 1); rescheduleReminders(); };

  const mustCount = needsCutCount(b);
  const shortWarn = async (n) => {
    if (n < b.expected_pieces) {
      await ui.alert({ title: 'Fewer pieces than expected', message: `You cut ${n}, the dough should give about ${b.expected_pieces} at ${fmt(b.cut_weight_g)} g. Check the cutting weight. The supervisor is told if it is a big difference.`, tone: 'warn' });
    }
  };
  const saveCount = async () => {
    if (pieces === null || pieces === undefined) return ui.alert({ title: 'How many pieces?', message: 'Count the pieces you cut and enter the number.', tone: 'warn' });
    try {
      recordCutCount(user.id, b.id, pieces);
      ui.toast(`Cut count saved: ${pieces} pieces`);
      await shortWarn(pieces);
      done();
    } catch (e) { ui.error(e); }
  };
  const confirm = async () => {
    try {
      if (mustCount && (pieces === null || pieces === undefined)) return ui.alert({ title: 'How many pieces were cut?', message: 'Cutting is finished – enter the number of pieces cut before starting the next step.', tone: 'warn' });
      const needDeck = next.kind === 'bake' && b.decks.length;
      if (needDeck && !deck.length) return ui.alert({ title: 'Which oven deck?', message: 'Tap every deck you are putting the trays in (one mix can use several). Each button shows the temperature for this product.', tone: 'warn' });
      const r = confirmNextStep(user.id, b.id, { cutPieces: mustCount ? pieces : undefined, deck: needDeck ? deck : undefined });
      ui.toast(`${next.name} started at ${hhmm(r.steps[next.idx].started_at)}${needDeck ? ` · ${deck.join(', ')}` : ''}`);
      if (mustCount) await shortWarn(pieces);
      done();
    } catch (e) { ui.error(e); }
  };
  const countField = mustCount ? (
    <View style={{ gap: 8, marginBottom: 10 }}>
      <Banner tone="warn" title="✂️ Cutting finished? Enter the pieces cut" message={`Cut at ${fmt(b.cut_weight_g)} g · about ${b.expected_pieces} expected from ${fmt(b.dough_kg)} kg dough.`} />
      <NumberField testID="cut-pieces" label="Pieces cut" value={pieces} onChange={setPieces} step={1} unit="pcs" />
    </View>
  ) : null;
  const snooze = (m) => {
    try {
      snoozeNextStep(user.id, b.id, m);
      ui.toast(`${next.name} snoozed ${m} min – later steps moved back too`, 'warn');
      done();
    } catch (e) { ui.error(e); }
  };
  const finish = async () => {
    const total = (fin.good || 0) + (fin.damaged || 0) + (fin.rejected || 0) + (fin.other || 0);
    const base = b.cut_pieces || b.expected_pieces;
    const ok = await ui.confirm({
      title: `Finish ${b.product_name}?`,
      message: `Good ${fmt(fin.good)} · damaged ${fmt(fin.damaged)} · rejected ${fmt(fin.rejected)} · other ${fmt(fin.other)}\nTotal ${fmt(total)}${base ? ` (${b.cut_pieces ? 'cut' : 'expected'} ${base})` : ''}`,
      confirmText: 'Finish batch', tone: base && total < base ? 'warn' : 'success',
    });
    if (!ok) return;
    try {
      if (mustCount && (pieces === null || pieces === undefined)) return ui.alert({ title: 'How many pieces were cut?', message: 'Enter the number of pieces cut first.', tone: 'warn' });
      finishBatch(user.id, b.id, { good: fin.good, damaged: fin.damaged, rejected: fin.rejected, otherWaste: fin.other, comments: fin.comments, photos: fin.photos, cutPieces: mustCount ? pieces : undefined });
      ui.toast(`${b.product_name} finished · ${fmt(fin.good)} good`);
      done();
    } catch (e) { ui.error(e); }
  };

  const stats = batchStats(b);
  const over = b.secondsToDue !== null && b.secondsToDue < 0;
  return (
    <Screen title={`${b.product_name} · ${b.code}`} subtitle={`Started ${hhmm(b.started_at)} by ${b.user_name} · ${fmt(b.flour_kg)} kg flour`}>
      <Card>
        <StepTimeline steps={b.steps} currentIdx={b.current_step} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 18, marginTop: 12 }}>
          <View><Text style={{ color: C.sub, fontWeight: '700' }}>CUTTING WEIGHT</Text><Text style={{ fontSize: 26, fontWeight: '900', color: C.info }}>{fmt(b.cut_weight_g)} g</Text></View>
          <View><Text style={{ color: C.sub, fontWeight: '700' }}>EXPECTED</Text><Text style={{ fontSize: 26, fontWeight: '900', color: C.text }}>~{b.expected_pieces}</Text></View>
          {b.cut_pieces !== null ? <View><Text style={{ color: C.sub, fontWeight: '700' }}>CUT</Text><Text style={{ fontSize: 26, fontWeight: '900', color: b.cut_pieces < b.expected_pieces ? C.warn : C.success }}>{b.cut_pieces}</Text></View> : null}
          <View><Text style={{ color: C.sub, fontWeight: '700' }}>DOUGH</Text><Text style={{ fontSize: 26, fontWeight: '900', color: C.text }}>{fmt(b.dough_kg)} kg</Text></View>
        </View>
      </Card>

      {b.status === 'finished' ? (
        <Card tone="success">
          <H>✅ Finished at {hhmm(b.finished_at)}</H>
          <Row label="Good" value={fmt(b.good)} bold color={C.success} />
          <Row label="Damaged / rejected / other" value={`${fmt(b.damaged)} / ${fmt(b.rejected)} / ${fmt(b.other_waste)}`} />
          <Row label="Yield" value={stats.yieldPct === null ? '—' : `${stats.yieldPct}% of expected`} />
          <Row label="Total time" value={hoursMinutes(stats.totalMinutes)} />
          {canCost ? <Row label="Ingredient cost" value={`${money(stats.cost, cur)}${stats.costPerGood !== null ? ` · ${money(stats.costPerGood, cur)} per good piece` : ''}`} /> : null}
          {b.comments ? <Row label="Comments" value={b.comments} /> : null}
        </Card>
      ) : next && next.kind !== 'finish' ? (
        <Card tone={over ? 'danger' : 'info'}>
          <Text style={{ fontSize: 15, color: C.sub, fontWeight: '700' }}>NOW: {b.currentStep.name.toUpperCase()} since {hhmm(b.currentStep.started_at)} ({hoursMinutes(b.inStepMinutes)})</Text>
          <Text testID="next-step" style={{ fontSize: 28, fontWeight: '900', color: over ? C.danger : C.text, marginVertical: 6 }}>
            {over ? `⏰ ${stepTitle(b)}` : `${b.currentStep.name} should be done ${countdown(b.secondsToDue)}`}
          </Text>
          <Text style={{ fontSize: 16, color: C.sub, marginBottom: 8 }}>Then: {next.name}</Text>
          <PrepInfo b={b} />
          <BakingInfo b={b} />
          {next.kind === 'cut' ? (
            <View style={{ marginBottom: 10 }}>
              <Banner tone="info" title={`Cut at ${fmt(b.cut_weight_g)} g per piece`} message={`The dough (${fmt(b.dough_kg)} kg) should give about ${b.expected_pieces} pieces. Enter the count when cutting is finished.`} />
            </View>
          ) : null}
          {countField}
          {mustCount ? <Btn testID="save-cut-count" title="Save cut count (cutting finished)" icon="✂️" variant="info" style={{ marginBottom: 10 }} onPress={saveCount} /> : null}
          {next.kind === 'bake' && b.decks.length ? <View style={{ marginBottom: 10 }}><DeckPicker decks={b.decks} value={deck} onChange={setDeck} /></View> : null}
          <Btn testID="confirm-step" title={confirmLabel(b)} icon="✅" variant="success" onPress={confirm} />
          <View style={{ height: 12 }} />
          <SnoozeButtons onSnooze={snooze} />
        </Card>
      ) : next ? (
        <Card tone={over ? 'danger' : 'success'}>
          <H>🏁 {over ? `${b.currentStep.name} should be done – enter production` : `${b.currentStep.name} – done ${countdown(b.secondsToDue)}`}</H>
          <BakingInfo b={b} />
          <Banner tone="info" message={`Enter how many were produced. ${b.cut_pieces !== null ? `${b.cut_pieces} were cut.` : `About ${b.expected_pieces} expected.`}`} />
          <View style={{ gap: 12, marginTop: 12 }}>
            {countField}
            <NumberField testID="fin-good" label="✅ Good" value={fin.good} onChange={(v) => setFin({ ...fin, good: v })} unit={b.product_unit} />
            <NumberField testID="fin-damaged" label="Damaged" value={fin.damaged} onChange={(v) => setFin({ ...fin, damaged: v })} unit={b.product_unit} />
            <NumberField testID="fin-rejected" label="Rejected" value={fin.rejected} onChange={(v) => setFin({ ...fin, rejected: v })} unit={b.product_unit} />
            <NumberField testID="fin-other" label="Other wastage" value={fin.other} onChange={(v) => setFin({ ...fin, other: v })} unit={b.product_unit} />
            <Field label="Comments (optional)" value={fin.comments} onChangeText={(t) => setFin({ ...fin, comments: t })} placeholder="e.g. oven too hot" multiline />
            {(fin.damaged || fin.rejected || fin.other) ? <PhotoPicker label="Photo of damaged/rejected items" value={fin.photos} onChange={(p) => setFin({ ...fin, photos: p })} /> : null}
            <Btn testID="finish-batch" title="Finish batch" icon="🏁" variant="success" onPress={finish} disabled={fin.good === null} />
          </View>
          <View style={{ height: 12 }} />
          <SnoozeButtons onSnooze={snooze} testIDPrefix="snooze-finish" />
        </Card>
      ) : null}

      <Card>
        <H>Ingredients</H>
        <Table columns={[{ key: 'n', title: 'Ingredient', width: 170 }, { key: 'e', title: 'Recipe', width: 100, align: 'right' }, { key: 'a', title: 'Used', width: 100, align: 'right' }, { key: 'd', title: 'Diff', width: 120, align: 'right' }]}
          rows={b.ingredients.map((i) => ({ n: i.name, e: fmt(i.expected, i.unit), a: fmt(i.actual, i.unit), d: `${signed(i.actual - i.expected)} (${i.diff_pct || 0}%)`, _bg: i.flagged ? C.warnSoft : undefined }))} />
      </Card>
      <Card>
        <H>Step times</H>
        {b.steps.map((s) => (
          <Row key={s.idx} label={`${s.name}${s.snooze_count ? ` (snoozed ${s.snooze_count}× ${s.snooze_min} min)` : ''}`}
            value={s.started_at ? `${hhmm(s.started_at)}${s.planned_at && s.idx > 0 ? ` (planned ${hhmm(s.planned_at)})` : ''}${s.started_by_name ? ` · ${s.started_by_name}` : ''}` : s.due_at ? `due ${hhmm(s.due_at)}` : '—'} />
        ))}
      </Card>
      {batchLots(b.id).length ? (
        <Card>
          <H>Lots used</H>
          {batchLots(b.id).map((l, i) => <Row key={i} label={`${l.name} · lot ${l.lot_no || '—'}${l.expiry ? ` · exp ${l.expiry}` : ''}`} value={fmt(l.qty, l.unit)} />)}
        </Card>
      ) : null}
    </Screen>
  );
}
