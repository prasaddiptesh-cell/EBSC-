import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, NumberField, Field, Btn, Banner, Badge, PhotoPicker, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { myChecklists, openRun, answerItem, WHEN_LABEL } from '../../../../services/checklists.js';
import { hhmm } from '../../../../services/core.js';
import { ReasonField } from '../../../../ui/kit.js';

export function ChecklistsScreen() {
  const { user, nav } = useApp();
  const lists = myChecklists(user.id);
  return (
    <Screen title="Checklists" subtitle="Cleaning, opening checks and temperature logs">
      {!lists.length ? <Banner tone="info" message="No checklists right now (a shift must be open)." /> : null}
      {lists.map((l) => (
        <Pressable key={l.id} testID={`checklist-${l.name}`} onPress={() => nav.push('ChecklistRun', { checklistId: l.id })}
          style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: 2, borderColor: l.left ? (l.when_due === 'end' ? C.warn : C.border) : C.success, opacity: pressed ? 0.7 : 1, gap: 6 })}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 6 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{l.left ? '☐' : '✅'} {l.name}</Text>
            <Badge text={l.left ? `${l.left} of ${l.total} left` : 'Complete'} color={l.left ? C.warn : C.success} />
          </View>
          <Text style={{ fontSize: 15, color: C.sub }}>{WHEN_LABEL[l.when_due]} · {l.scope === 'person' ? 'your own list' : 'shared for the shift'}</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

function ItemRow({ item, runId }) {
  const { user } = useApp();
  const ui = useUI();
  const [temp, setTemp] = useState(item.entry && item.entry.value !== null ? item.entry.value : null);
  const [photos, setPhotos] = useState([]);
  const [skipping, setSkipping] = useState(false);
  const [reason, setReason] = useState('');
  const e = item.entry;
  const save = (answer) => {
    try {
      const r = answerItem(runId, item.id, user.id, answer);
      if (r.out_of_range) ui.alert({ title: '⚠️ Temperature out of range', message: `${item.name} should be between ${item.min_value} and ${item.max_value}°C. The supervisor has been alerted. Tell your supervisor now.`, tone: 'danger' });
      else ui.toast(answer.skipped ? 'Marked as not done' : 'Saved');
      item.onSaved();
    } catch (err) { ui.error(err); }
  };
  const doneColor = e ? (e.status === 'skipped' ? C.warn : e.out_of_range ? C.danger : C.success) : C.border;
  return (
    <Card style={{ borderColor: doneColor, borderWidth: 2 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.text, flex: 1 }}>{item.name}</Text>
        {e ? <Text style={{ fontSize: 15, fontWeight: '800', color: doneColor }}>
          {e.status === 'skipped' ? `Not done: ${e.note}` : item.kind === 'temp' ? `${e.value}°C${e.out_of_range ? ' OUT OF RANGE' : ' ✓'}` : '✓ Done'} · {e.user_name} {hhmm(e.at)}
        </Text> : null}
      </View>
      {item.kind === 'temp' ? <Text style={{ fontSize: 14, color: C.sub }}>Safe range {item.min_value} to {item.max_value}°C</Text> : null}
      {!skipping ? (
        <View style={{ gap: 10, marginTop: 10 }}>
          {item.kind === 'tick' ? <Btn testID={`tick-${item.name}`} title={e && e.status === 'done' ? 'Done ✓' : 'Mark as done'} icon="✅" variant={e && e.status === 'done' ? 'secondary' : 'success'} size="md" onPress={() => save({ done: true })} /> : null}
          {item.kind === 'temp' ? (
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
              <View style={{ flex: 1 }}><NumberField testID={`temp-${item.name}`} value={temp} onChange={setTemp} step={0.5} unit="°C" compact min={-60} /></View>
              <Btn testID={`save-temp-${item.name}`} title="Save" size="md" variant="success" onPress={() => save({ value: temp })} />
            </View>
          ) : null}
          {item.kind === 'photo' ? (
            <View style={{ gap: 8 }}>
              <PhotoPicker label="Photo" value={photos} onChange={setPhotos} required />
              <Btn title="Save photo" size="md" variant="success" disabled={!photos.length} onPress={() => save({ photo: photos[0] })} />
            </View>
          ) : null}
          <Btn testID={`skip-${item.name}`} title="Can't do this" size="sm" variant="ghost" onPress={() => setSkipping(true)} />
        </View>
      ) : (
        <View style={{ gap: 8, marginTop: 10 }}>
          <ReasonField testID={`reason-${item.name}`} label="Why can't it be done? (the supervisor will see this)" value={reason} onChangeText={setReason} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn title="Cancel" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setSkipping(false)} />
            <Btn testID={`save-skip-${item.name}`} title="Save reason" size="md" variant="warn" style={{ flex: 1 }} onPress={() => { save({ skipped: true, note: reason }); setSkipping(false); }} />
          </View>
        </View>
      )}
    </Card>
  );
}

export function ChecklistRunScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [, refresh] = useState(0);
  let data;
  try {
    data = openRun(params.checklistId, user.id);
  } catch (e) {
    return <Screen title="Checklist"><Banner tone="warn" message={e.message} /></Screen>;
  }
  const left = data.items.filter((i) => !i.entry).length;
  return (
    <Screen title={data.list.name} subtitle={`${WHEN_LABEL[data.list.when_due]} · ${left ? `${left} left` : 'complete'}`}
      footer={<Btn testID="checklist-done" title={left ? `${left} item(s) left` : 'All done – back'} icon={left ? '☐' : '✅'} variant={left ? 'secondary' : 'success'} onPress={() => { if (!left) { ui.toast(`${data.list.name} complete`); nav.pop(); } }} />}>
      {data.items.map((it) => <ItemRow key={`${it.id}-${it.entry ? it.entry.at : 'x'}`} runId={data.run.id} item={{ ...it, onSaved: () => refresh((n) => n + 1) }} />)}
    </Screen>
  );
}
