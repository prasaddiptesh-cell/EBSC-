import React, { useState } from 'react';
import { Screen, Card, H, Row, Field, Btn, Banner, Table, P, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { getOpenShift, getShiftWorkers, closeShift } from '../../../../services/shifts.js';
import { listBatches } from '../../../../services/batches.js';
import { signOffBlockers, shiftCloseBlockers } from '../../../../services/checklists.js';
import { planProgress } from '../../../../services/plan.js';
import { fmt, hhmm, hoursMinutes } from '../../../../services/core.js';

export default function CloseShiftScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [notes, setNotes] = useState('');
  const shift = getOpenShift();
  if (!shift) return <Screen title="Close Shift"><Banner tone="info" message="There is no open shift." /></Screen>;
  const batches = listBatches({ shiftId: shift.id }).reverse();
  const active = batches.filter((b) => b.status === 'active');
  const done = batches.filter((b) => b.status === 'finished');
  const workers = getShiftWorkers(shift.id);
  const stillOn = workers.filter((w) => !w.signed_off_at && w.id !== user.id);
  const myBlock = signOffBlockers(shift.id, user.id);
  const shiftBlock = shiftCloseBlockers(shift.id);
  const blocked = active.length || myBlock.length || shiftBlock.length;
  const good = done.reduce((a, b) => a + (b.good || 0), 0);
  const lost = done.reduce((a, b) => a + (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0), 0);

  const close = async () => {
    const ok = await ui.confirm({
      title: 'Close this shift?',
      message: `This ends the ${shift.shift_name} shift and signs you off. No more entries can be added.${stillOn.length ? `\n\n⚠️ Still signed on: ${stillOn.map((w) => w.name).join(', ')}. The supervisor will need to enter their sign-off times.` : ''}\n\nThe supervisor will then count the stock and approve the shift.`,
      confirmText: 'Close shift', tone: stillOn.length ? 'warn' : 'danger',
    });
    if (!ok) return;
    try {
      closeShift(user.id, notes);
      await ui.alert({ title: '✅ Shift closed', message: 'Thank you. The supervisor will now do the physical stock count and approve the shift.', tone: 'success' });
      nav.home();
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Close Shift" subtitle={`${shift.shift_name} · ${shift.code}`}
      footer={<Btn testID="close-shift" title="Close shift" icon="🏁" variant="danger" onPress={close} disabled={!!blocked} />}>
      {active.length ? <Banner tone="danger" title="Batches still in progress" message={`Finish these first: ${active.map((b) => `${b.product_name} (${b.code})`).join(', ')}.`} /> : null}
      {myBlock.length ? <Banner tone="warn" title="Your end-of-shift checklist" message={`${myBlock.map((b) => `${b.name}: ${b.left} left`).join(' · ')}`} /> : null}
      {shiftBlock.length ? <Banner tone="warn" title="Shift checklists not finished" message={`${shiftBlock.map((b) => `${b.name}: ${b.left} left`).join(' · ')}`} /> : null}
      {myBlock.length || shiftBlock.length ? <Btn title="Open checklists" icon="✅" variant="success" onPress={() => nav.push('Checklists')} /> : null}
      <Card>
        <H>Shift summary</H>
        <Row label="Started" value={`${shift.opened_at.slice(0, 16)} by ${shift.opened_by_name}`} />
        <Row label="Batches" value={`${batches.length} (${done.length} finished)`} />
        <Row label="Good production" value={fmt(good)} color={C.success} bold />
        <Row label="Damaged / rejected / other" value={fmt(lost)} color={lost ? C.danger : C.text} />
      </Card>
      <Card>
        <H>Bakers</H>
        {workers.map((w) => <Row key={w.id} label={w.name} value={`${hhmm(w.signed_on_at)} – ${w.signed_off_at ? hhmm(w.signed_off_at) : 'still on'} · ${hoursMinutes(w.minutes)}`} color={w.signed_off_at ? C.text : C.warn} />)}
      </Card>
      {planProgress().length ? (
        <Card>
          <H>Plan vs actual (today)</H>
          {planProgress().map((p) => <Row key={p.product_id} label={p.name} value={`${fmt(p.good)}${p.target ? ` of ${fmt(p.target)}` : ''}`} color={p.remaining ? C.warn : C.success} />)}
        </Card>
      ) : null}
      <Card>
        <H>Batches</H>
        {done.length ? (
          <Table columns={[{ key: 'p', title: 'Product', width: 170 }, { key: 'c', title: 'Batch', width: 130 }, { key: 'e', title: 'Expected', width: 85, align: 'right' }, { key: 'g', title: 'Good', width: 75, align: 'right' }, { key: 'w', title: 'Lost', width: 70, align: 'right' }, { key: 'by', title: 'Baker', width: 100 }]}
            rows={done.map((b) => ({ p: b.product_name, c: b.code, e: fmt(b.expected_pieces), g: fmt(b.good), w: fmt(b.damaged + b.rejected + b.other_waste), by: b.user_name }))} />
        ) : <P>No finished batches.</P>}
      </Card>
      <Card>
        <Field label="Closing notes (optional)" value={notes} onChangeText={setNotes} placeholder="e.g. oven 2 needs repair" multiline />
      </Card>
    </Screen>
  );
}
