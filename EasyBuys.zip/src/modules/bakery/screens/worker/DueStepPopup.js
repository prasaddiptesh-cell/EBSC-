import React, { useState } from 'react';
import { View, Modal, ScrollView } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Btn, NumberField, useApp, useUI, useTick, countdown } from '../../../../ui/components.js';
import { SnoozeButtons } from './BatchScreen.js';
import { C } from '../../../../ui/theme.js';
import { dueBatches, confirmNextStep, snoozeNextStep, needsCutCount } from '../../../../services/batches.js';
import { getOpenShift, isOnShift } from '../../../../services/shifts.js';
import { fmt } from '../../../../services/core.js';
import { rescheduleReminders } from '../../../../platform/notify.js';
import { stepTitle, confirmLabel, DeckPicker, PrepInfo } from './batchUi.js';

// Pops up over any screen when a batch step is due, for anyone signed on to the shift.
export default function DueStepPopup() {
  const { user, nav, currentScreen } = useApp();
  const ui = useUI();
  useTick(2000);
  const [pieces, setPieces] = useState(null);
  const [deck, setDeck] = useState([]);
  const [, refresh] = useState(0);
  if (!user) return null;
  const s = getOpenShift();
  if (!s || !isOnShift(s.id, user.id)) return null;
  const due = dueBatches();
  if (!due.length) return null;
  const b = due[0];
  if (currentScreen && currentScreen.name === 'Batch' && currentScreen.params.batchId === b.id) return null;
  const next = b.nextStep;
  const done = () => { setPieces(null); setDeck([]); refresh((n) => n + 1); rescheduleReminders(); };

  const mustCount = needsCutCount(b);
  const confirm = () => {
    if (next.kind === 'finish') { nav.push('Batch', { batchId: b.id }); return; }
    if (mustCount && (pieces === null || pieces === undefined)) { ui.alert({ title: 'How many pieces were cut?', message: 'Cutting is finished – enter how many pieces you cut.', tone: 'warn' }); return; }
    try {
      const needDeck = next.kind === 'bake' && b.decks.length;
      if (needDeck && !deck.length) { ui.alert({ title: 'Which oven deck?', message: 'Tap every deck you are putting the trays in (one mix can use several).', tone: 'warn' }); return; }
      confirmNextStep(user.id, b.id, { cutPieces: mustCount ? pieces : undefined, deck: needDeck ? deck : undefined });
      ui.toast(`${b.product_name}: ${next.name} started${needDeck ? ` · ${deck.join(', ')}` : ''}`);
      done();
    } catch (e) { ui.error(e); }
  };
  const snooze = (m) => {
    try {
      snoozeNextStep(user.id, b.id, m);
      ui.toast(`Snoozed ${m} min`, 'warn');
      done();
    } catch (e) { ui.error(e); }
  };

  return (
    <Modal visible transparent animationType="fade" onRequestClose={() => snooze(5)}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
        <ScrollView style={{ width: '100%', maxWidth: 620 }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}>
          <View testID="due-popup" style={{ backgroundColor: C.card, borderRadius: 20, padding: 22, borderWidth: 4, borderColor: C.brandRed, gap: 10 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.danger }}>⏰ TIME TO ACT {due.length > 1 ? `(${due.length} batches due)` : ''}</Text>
            <Text testID="popup-title" style={{ fontSize: 30, fontWeight: '900', color: C.text }}>{stepTitle(b)}</Text>
            <Text style={{ fontSize: 21, fontWeight: '800', color: C.text }}>{b.product_name} · {b.code}</Text>
            <Text style={{ fontSize: 17, color: C.sub }}>Due {countdown(b.secondsToDue)} · baker {b.user_name}{next.kind !== 'finish' ? ` · next: ${next.name}` : ''}</Text>
            <PrepInfo b={b} />
            {next.kind === 'cut' ? (
              <View style={{ backgroundColor: C.infoSoft, borderRadius: 12, padding: 12 }}>
                <Text style={{ fontSize: 15, color: C.info, fontWeight: '800' }}>CUTTING WEIGHT</Text>
                <Text style={{ fontSize: 34, fontWeight: '900', color: C.info }}>{fmt(b.cut_weight_g)} g</Text>
                <Text style={{ fontSize: 16, color: C.text }}>Expect about {b.expected_pieces} pieces. You will enter the count when cutting is finished.</Text>
              </View>
            ) : null}
            {mustCount ? (
              <View style={{ gap: 8 }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.warn }}>✂️ Cutting finished – how many pieces were cut? (about {b.expected_pieces} expected)</Text>
                <NumberField testID="popup-pieces" label="Pieces cut" value={pieces} onChange={setPieces} unit="pcs" />
              </View>
            ) : null}
            {next.kind === 'bake' && b.decks.length ? <DeckPicker decks={b.decks} value={deck} onChange={setDeck} testIDPrefix="popup-deck" /> : null}
            <Btn testID="popup-confirm" title={confirmLabel(b)} icon="✅" variant="success" onPress={confirm} />
            <SnoozeButtons onSnooze={snooze} testIDPrefix="popup-snooze" />
            <Btn title="Open batch details" variant="ghost" size="md" onPress={() => nav.push('Batch', { batchId: b.id })} />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}
