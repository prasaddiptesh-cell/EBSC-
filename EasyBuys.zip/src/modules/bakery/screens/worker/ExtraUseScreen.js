import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, PickGrid, NumberField, Field, Chips, Label, Btn, Banner, useApp, useUI, Choice } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, stepFor } from '../../../../services/catalog.js';
import { recordExtraUsage, getOpenShift } from '../../../../services/shifts.js';
import { fmt } from '../../../../services/core.js';

const USES = ['Greasing trays', 'Dusting / bench flour', 'Glaze / topping', 'Staff test bake', 'Other'];

// Ingredients used outside a batch (so stock stays correct).
export default function ExtraUseScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [mat, setMat] = useState(null);
  const [qty, setQty] = useState(null);
  const [use, setUse] = useState(null);
  const [note, setNote] = useState('');
  if (!getOpenShift()) return <Screen title="Other Use"><Banner tone="warn" message="Start or sign on to a shift first." /></Screen>;
  const materials = listMaterials({ stockOnly: true });
  const save = async () => {
    const why = use === 'Other' ? note.trim() : [use, note.trim()].filter(Boolean).join(' - ');
    if (!qty) return ui.alert({ title: 'Enter quantity', message: 'How much did you use?', tone: 'warn' });
    if (!why) return ui.alert({ title: 'What was it used for?', message: 'Choose what it was used for.', tone: 'warn' });
    const ok = await ui.confirm({ title: 'Save?', message: `${fmt(qty, mat.unit)} of ${mat.name}\nUsed for: ${why}`, confirmText: 'Save', tone: 'success' });
    if (!ok) return;
    try {
      const txn = recordExtraUsage(user.id, mat.id, qty, why);
      ui.toast(`Recorded · ${txn}`);
      setMat(null); setQty(null); setUse(null); setNote('');
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Other Ingredient Use" subtitle="Ingredients used outside a batch" onBack={mat ? () => setMat(null) : undefined}
      footer={mat ? <Btn testID="save-extra" title="Save" icon="💾" variant="success" onPress={save} /> : null}>
      {!mat ? (
        <>
          <H>Which ingredient?</H>
          <PickGrid items={materials} onPick={setMat} testIDPrefix="mat"
            render={(m) => (<View><Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{m.name}</Text><Text style={{ fontSize: 15, color: C.sub }}>{fmt(m.stock, m.unit)} in stock</Text></View>)} />
        </>
      ) : (
        <Card>
          <H>{mat.name}</H>
          <NumberField testID="extra-qty" label={`Quantity used (${mat.unit})`} value={qty} onChange={setQty} step={stepFor(mat.unit)} unit={mat.unit} />
          <View style={{ height: 12 }} />
          <Label>Used for</Label>
          <Choice options={USES} value={use} onChange={setUse} testIDPrefix="use" />
          <View style={{ height: 10 }} />
          <Field label={use === 'Other' ? 'Describe (required)' : 'Note (optional)'} value={note} onChangeText={setNote} />
        </Card>
      )}
    </Screen>
  );
}
