import React, { useState } from 'react';
import { Screen, Chips, useApp } from '../../../../ui/components.js';
import TxnList from '../common/TxnList.js';
import { listTransactions, getOpenShift } from '../../../../services/shifts.js';

export default function MyEntriesScreen() {
  const { user } = useApp();
  const open = getOpenShift();
  const [scope, setScope] = useState(open ? 'shift' : 'all');
  const items = listTransactions({ userId: user.id, shiftId: scope === 'shift' && open ? open.id : undefined, limit: 300 });
  return (
    <Screen title="My Entries" subtitle={`${items.length} entries`}>
      <Chips value={scope} onChange={setScope} testIDPrefix="scope"
        options={(open ? [{ value: 'shift', label: 'This shift' }] : []).concat([{ value: 'all', label: 'All my entries' }])} />
      <TxnList items={items} emptyText="You have not recorded anything yet." />
    </Screen>
  );
}
