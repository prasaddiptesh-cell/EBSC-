import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, PickGrid, NumberField, Btn, Banner, Grid, Row, useApp, useUI, useLayout } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listProducts, stepFor } from '../../../../services/catalog.js';
import { planBatch, doughKg, expectedPieces, ingredientFlag, startBatch } from '../../../../services/batches.js';
import { planProgress } from '../../../../services/plan.js';
import { getSettings, fmt, signed, bandIndex, bandLabels, hoursMinutes } from '../../../../services/core.js';

export default function NewBatchScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const { width } = useLayout();
  const cols = width >= 1000 ? 3 : width >= 620 ? 2 : 1;
  const settings = getSettings();
  const products = listProducts().filter((p) => p.flour_material_id);
  const plan = planProgress();
  const [product, setProduct] = useState(null);
  const [flour, setFlour] = useState(null);
  const [actual, setActual] = useState({});
  const [edited, setEdited] = useState({});
  const [waterTemp, setWaterTemp] = useState(null);

  const plan0 = useMemo(() => (product && flour ? planBatch(product.id, flour) : null), [product, flour]);
  const lines = plan0 ? plan0.lines : [];
  // Lines the baker has not changed follow the calculated amount.
  const used = {};
  lines.forEach((l) => { used[l.material_id] = edited[l.material_id] ? actual[l.material_id] : l.expected; });
  const overMax = product && flour > product.max_flour_kg + 1e-9;
  const dough = plan0 ? doughKg(lines, used) : 0;
  const pieces = product ? expectedPieces(dough, product.cut_weight_g) : 0;
  const flags = lines.map((l) => ({ l, f: ingredientFlag(l, used[l.material_id]) })).filter((x) => x.f.flagged);
  const missing = lines.filter((l) => used[l.material_id] === null || used[l.material_id] === undefined);

  const pick = (p) => {
    setProduct(p);
    setFlour(p.default_flour_kg || null);
    setActual({});
    setEdited({});
  };

  const start = async () => {
    if (!flour) return ui.alert({ title: 'Enter the flour', message: 'How many kg of flour are you using?', tone: 'warn' });
    if (overMax) return ui.alert({ title: 'Too much flour', message: `The maximum for one batch of ${product.name} is ${product.max_flour_kg} kg (machine capacity).`, tone: 'danger' });
    if (missing.length) return ui.alert({ title: 'Amount missing', message: `Enter the amount used for: ${missing.map((m) => m.name).join(', ')} (0 if none).`, tone: 'warn' });
    const msg = `${fmt(flour)} kg flour · dough ${fmt(dough)} kg\nCut at ${fmt(product.cut_weight_g)} g → about ${pieces} ${product.unit}`
      + (flags.length ? `\n\n⚠️ Different from the recipe:\n${flags.map((x) => `• ${x.l.name}: ${fmt(used[x.l.material_id], x.l.unit)} instead of ${fmt(x.l.expected, x.l.unit)} (${x.f.pct > 0 ? '+' : ''}${x.f.pct}%)`).join('\n')}\n\nThe supervisor will be alerted.` : '');
    const ok = await ui.confirm({ title: `Start mixing ${product.name}?`, message: msg, confirmText: 'Start mixing now', tone: flags.length ? 'warn' : 'success' });
    if (!ok) return;
    try {
      const b = startBatch(user.id, product.id, flour, used, { waterTemp });
      ui.toast(`Mixing started · ${b.code}`);
      nav.replace('Batch', { batchId: b.id });
      ui.alert({ title: '🥣 Mixing started – get the trays ready', message: `${(product.prep_note && product.prep_note.trim()) || settings.mixReminder}\n\nThe alarm will go off when the mix should be done${plan0.route[0].minutes ? ` (in ${plan0.route[0].minutes} min)` : ''}.`, tone: 'info' });
    } catch (e) { ui.error(e); }
  };

  if (!product) {
    return (
      <Screen title="New Batch" subtitle="Tap the product you are making">
        {!products.length ? <Banner tone="warn" message="No products have a recipe yet. Ask the Admin to set them up." /> : null}
        <PickGrid items={products} onPick={pick} testIDPrefix="prod" render={(p) => {
          const pp = plan.find((x) => x.product_id === p.id);
          return (
            <View>
              <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🍞 {p.name}</Text>
              <Text style={{ fontSize: 15, color: C.sub }}>Cut {fmt(p.cut_weight_g)} g · max {fmt(p.max_flour_kg)} kg flour</Text>
              {pp && pp.target ? <Text style={{ fontSize: 15, color: pp.remaining ? C.warn : C.success, fontWeight: '700' }}>Plan: {fmt(pp.good)} of {fmt(pp.target)} done</Text> : null}
            </View>
          );
        }} />
      </Screen>
    );
  }

  return (
    <Screen title={`New batch · ${product.name}`} subtitle={`Cutting weight ${fmt(product.cut_weight_g)} g`} onBack={() => setProduct(null)}
      footer={<Btn testID="start-mixing" title="Start mixing" icon="🥣" variant="success" onPress={start} disabled={!!overMax} />}>
      <Card tone="info">
        <Text style={{ fontSize: 16, color: C.sub, fontWeight: '700' }}>✂️ CUTTING WEIGHT</Text>
        <Text testID="cut-weight" style={{ fontSize: 34, fontWeight: '900', color: C.info }}>{fmt(product.cut_weight_g)} g per piece{product.cut_tolerance_g ? `  (±${fmt(product.cut_tolerance_g)} g)` : ''}</Text>
      </Card>
      <Card>
        <H>1. Flour</H>
        <NumberField testID="flour" label={`Flour (kg) · machine maximum ${fmt(product.max_flour_kg)} kg`} value={flour} onChange={(v) => { setFlour(v); }} step={1} unit="kg" />
        {overMax ? <View style={{ marginTop: 10 }}><Banner testID="over-max" tone="danger" title="Above machine capacity" message={`The maximum for one batch is ${fmt(product.max_flour_kg)} kg. Reduce the flour or split into two batches.`} /></View> : null}
      </Card>
      {plan0 && !overMax ? (
        <>
          <H>2. Ingredients (calculated from {fmt(flour)} kg flour)</H>
          {flags.length ? <Banner testID="ingredient-warning" tone="warn" title={`${flags.length} ingredient(s) differ from the recipe`} message="This is allowed, but the supervisor will be alerted. Check the amounts." />
            : <Banner tone="success" message="All amounts follow the recipe. Change any you actually used differently." />}
          <Grid cols={cols}>
            {lines.map((l) => {
              const f = ingredientFlag(l, used[l.material_id]);
              return (
                <Card key={l.material_id} tone={f.flagged ? 'warn' : undefined}>
                  <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{l.name}{l.is_flour ? ' (flour)' : ''}</Text>
                  <Text style={{ fontSize: 14, color: C.sub, marginBottom: 6 }}>{fmt(l.pct)}% of flour · recipe {fmt(l.expected, l.unit)}</Text>
                  <NumberField testID={`ing-${l.name}`} value={used[l.material_id]} step={stepFor(l.unit)} unit={l.unit} compact
                    onChange={(v) => { setEdited((e) => ({ ...e, [l.material_id]: true })); setActual((a) => ({ ...a, [l.material_id]: v })); }} />
                  {f.diff !== null && f.diff !== 0 ? (
                    <Text style={{ fontSize: 15, fontWeight: '800', marginTop: 6, color: f.flagged ? C.danger : C.warn }}>
                      {f.flagged ? '⚠️ ' : ''}{signed(f.diff, l.unit)} ({f.pct > 0 ? '+' : ''}{f.pct}%){f.flagged ? ` – over the ${l.flag_pct}% limit` : ''}
                    </Text>
                  ) : null}
                </Card>
              );
            })}
          </Grid>
          {settings.recordWaterTemp ? (
            <Card><NumberField testID="water-temp" label="Water temperature (optional)" value={waterTemp} onChange={setWaterTemp} step={1} unit="°C" /></Card>
          ) : null}
          <Card>
            <H>3. What to expect</H>
            <Row label="Dough weight" value={`${fmt(dough)} kg`} />
            <Row label="Cutting weight" value={`${fmt(product.cut_weight_g)} g`} />
            <Row label="Expected pieces" value={`about ${pieces} ${product.unit}`} bold color={C.success} />
          </Card>
          <Card>
            <H>4. Step times for this batch size</H>
            <Text style={{ fontSize: 15, color: C.sub, marginBottom: 6 }}>Batch size: {bandLabels(settings.flourBands)[bandIndex(flour, settings.flourBands)]} · an alarm goes off at the end of each step.</Text>
            {plan0.route.map((r, i) => (
              <Row key={i} label={`${i + 1}. ${r.name}${r.kind === 'cut' ? ' ✂️' : r.kind === 'bake' ? ' 🔥' : ''}`} value={r.minutes ? `${fmt(r.minutes)} min` : '—'} />
            ))}
            <Row label="Total until finished" value={hoursMinutes(plan0.route.reduce((a, r) => a + (Number(r.minutes) || 0), 0))} bold />
          </Card>
        </>
      ) : null}
    </Screen>
  );
}
