import React, { useState } from 'react';
import { Screen, Card, Btn, Banner, TimeEntry, P, useApp, useUI } from '../../../../ui/components.js';
import { signOn, signOff, getOpenShift, getMyShiftRow } from '../../../../services/shifts.js';
import { signOffBlockers } from '../../../../services/checklists.js';
import { stampFromTime, hhmm, hoursMinutes, minutesBetween, stamp } from '../../../../services/core.js';

// Sign on / sign off with the option of entering a different time.
export default function SignScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [time, setTime] = useState(null);
  const off = params.mode === 'off';
  const shift = getOpenShift();
  if (!shift) return <Screen title={off ? 'Sign off' : 'Sign on'}><Banner tone="info" message="There is no open shift." /></Screen>;
  const me = getMyShiftRow(shift.id, user.id);
  const blockers = off ? signOffBlockers(shift.id, user.id) : [];
  const at = time ? stampFromTime(time.h, time.m) : null;

  const save = async () => {
    try {
      if (off) {
        const mins = signOff(user.id, at, user.id);
        await ui.alert({ title: '👋 Signed off', message: `Thank you, ${user.name}. You worked ${hoursMinutes(mins)} this shift.`, tone: 'success' });
        nav.home();
      } else {
        signOn(user.id, at);
        ui.toast(`Signed on at ${hhmm(at || stamp())}`);
        nav.pop();
      }
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title={off ? 'Sign off' : 'Sign on'} subtitle={`${shift.shift_name} shift · ${shift.code}`}
      footer={<Btn testID="confirm-sign" title={off ? 'Sign off now' : 'Sign on'} icon={off ? '👋' : '✋'} variant={off ? 'primary' : 'success'} onPress={save} disabled={off && blockers.length > 0} />}>
      {off && blockers.length ? (
        <Card tone="warn">
          <Banner tone="warn" title="Finish your checklist first" message={`Before you sign off: ${blockers.map((b) => `${b.name} (${b.left} left)`).join(', ')}. If you cannot do an item, open it and choose "Can't do" with a reason.`} />
          <Btn testID="open-checklists" title="Open checklists" icon="✅" variant="success" style={{ marginTop: 12 }} onPress={() => nav.replace('Checklists')} />
        </Card>
      ) : null}
      {off && me ? <P>You signed on at {hhmm(me.signed_on_at)} ({hoursMinutes(minutesBetween(me.signed_on_at, stamp()))} ago).</P> : null}
      <Card>
        <TimeEntry testID="sign-time" label={off ? 'Sign-off time' : 'Sign-on time'} value={time} onChange={setTime} />
      </Card>
    </Screen>
  );
}
