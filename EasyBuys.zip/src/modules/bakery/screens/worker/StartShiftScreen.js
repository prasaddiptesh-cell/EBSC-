import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Chips, NumberField, Btn, Banner, Grid, TimeEntry, useApp, useUI, useLayout } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, listShiftNames, stepFor } from '../../../../services/catalog.js';
import { startShift } from '../../../../services/shifts.js';
import { fmt, signed, r3, stampFromTime } from '../../../../services/core.js';

export default function StartShiftScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const { width } = useLayout();
  const formCols = width >= 1000 ? 3 : width >= 600 ? 2 : 1;
  const [materials] = useState(() => listMaterials({ stockOnly: true }));
  const names = listShiftNames();
  const [shiftName, setShiftName] = useState(names.length === 1 ? names[0].name : null);
  const [time, setTime] = useState(null);
  const [counts, setCounts] = useState(() => Object.fromEntries(materials.map((m) => [m.id, m.stock])));

  const diffs = materials.filter((m) => counts[m.id] !== null && r3(counts[m.id]) !== r3(m.stock));
  const missing = materials.filter((m) => counts[m.id] === null || counts[m.id] === undefined);

  const start = async () => {
    if (!shiftName) return ui.alert({ title: 'Choose the shift', message: 'Tap which shift you are starting.', tone: 'warn' });
    if (missing.length) return ui.alert({ title: 'Opening stock missing', message: `Enter the count for: ${missing.map((m) => m.name).join(', ')}`, tone: 'warn' });
    const msg = diffs.length
      ? `You changed ${diffs.length} item(s) from the system stock:\n${diffs.map((m) => `• ${m.name}: ${fmt(m.stock, m.unit)} → ${fmt(counts[m.id], m.unit)}`).join('\n')}\n\nThe differences will be recorded under your name.`
      : 'All opening quantities match the system stock.';
    const ok = await ui.confirm({ title: `Start ${shiftName} shift?`, message: msg, confirmText: 'Confirm & start', tone: diffs.length ? 'warn' : 'success' });
    if (!ok) return;
    try {
      const s = startShift(user.id, shiftName, counts, time ? stampFromTime(time.h, time.m) : null);
      ui.toast(`${shiftName} shift started (${s.code}). You are signed on.`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };

  return (
    <Screen title="Start Shift" subtitle="1. Shift  ·  2. Your sign-on time  ·  3. Opening stock"
      footer={<Btn testID="confirm-start" title="Confirm opening stock & start shift" icon="✅" variant="success" onPress={start} />}>
      <Card>
        <H>1. Which shift?</H>
        {names.length ? <Chips options={names.map((n) => n.name)} value={shiftName} onChange={setShiftName} testIDPrefix="shift" />
          : <Banner tone="warn" message="No shift names are set up. Ask the Admin to add them in Settings → Shifts & steps." />}
      </Card>
      <Card>
        <H>2. Sign-on time</H>
        <TimeEntry testID="start-time" value={time} onChange={setTime} />
      </Card>
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <H style={{ marginBottom: 0 }}>3. Confirm opening stock</H>
          <Btn title="Reset all to system" size="sm" variant="secondary" onPress={() => setCounts(Object.fromEntries(materials.map((m) => [m.id, m.stock])))} />
        </View>
        <Text style={{ fontSize: 16, color: C.sub, marginVertical: 8 }}>Check each item. If what you see is different, change the number.</Text>
        {diffs.length ? <Banner tone="warn" title={`${diffs.length} item(s) differ from system stock`} message="Please double-check these before starting." /> : <Banner tone="success" message="All items match the system stock." />}
      </Card>
      <Grid cols={formCols}>
        {materials.map((m) => {
          const changed = counts[m.id] !== null && r3(counts[m.id]) !== r3(m.stock);
          return (
            <Card key={m.id} tone={changed ? 'warn' : undefined}>
              <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{m.name}</Text>
              <Text style={{ fontSize: 15, color: C.sub, marginBottom: 8 }}>System: {fmt(m.stock, m.unit)}</Text>
              <NumberField testID={`open-${m.name}`} value={counts[m.id]} onChange={(v) => setCounts((c) => ({ ...c, [m.id]: v }))} step={stepFor(m.unit)} unit={m.unit} compact />
              {changed ? <Text style={{ color: C.warn, fontWeight: '800', fontSize: 15, marginTop: 6 }}>⚠️ Differs by {signed(counts[m.id] - m.stock, m.unit)}</Text> : null}
            </Card>
          );
        })}
      </Grid>
    </Screen>
  );
}
