import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { Screen, Card, H, Label, PickGrid, NumberField, Field, Chips, Btn, Banner, PhotoPicker, useApp, useUI } from '../../../../ui/components.js';
import { C } from '../../../../ui/theme.js';
import { listMaterials, stepFor } from '../../../../services/catalog.js';
import { recordWastage, getOpenShift } from '../../../../services/shifts.js';
import { fmt } from '../../../../services/core.js';

const REASONS = ['Spilled', 'Expired', 'Spoiled / mouldy', 'Contaminated', 'Burnt', 'Damaged packaging', 'Other'];

export default function WastageScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [mat, setMat] = useState(null);
  const [qty, setQty] = useState(null);
  const [reason, setReason] = useState(null);
  const [note, setNote] = useState('');
  const [photos, setPhotos] = useState([]);
  const shift = getOpenShift();
  const materials = listMaterials({ stockOnly: true });

  const save = async () => {
    if (!qty || qty <= 0) return ui.alert({ title: 'Enter quantity', message: 'How much was wasted?', tone: 'warn' });
    if (!reason) return ui.alert({ title: 'Choose a reason', message: 'Tap the reason for the wastage.', tone: 'warn' });
    if (reason === 'Other' && !note.trim()) return ui.alert({ title: 'Describe the reason', message: 'Type what happened.', tone: 'warn' });
    const ok = await ui.confirm({ title: 'Record wastage?', message: `${fmt(qty, mat.unit)} of ${mat.name}\nReason: ${reason}${note ? ` - ${note}` : ''}`, confirmText: 'Record wastage', tone: 'danger' });
    if (!ok) return;
    try {
      const txn = recordWastage(user.id, mat.id, qty, reason, note.trim(), photos);
      ui.toast(`Wastage recorded · ${txn}`);
      setMat(null); setQty(null); setReason(null); setNote(''); setPhotos([]);
    } catch (e) { ui.error(e); }
  };

  if (!shift) return <Screen title="Record Wastage"><Banner tone="warn" title="No open shift" message="Start or join a shift first." /></Screen>;

  return (
    <Screen title="Record Wastage" subtitle="Ingredients lost or spoiled (bread losses are entered when finishing a batch)" onBack={mat ? () => setMat(null) : undefined}
      footer={mat ? <Btn testID="save-wastage" title="Record wastage" icon="🗑️" variant="danger" onPress={save} /> : null}>
      {!mat ? (
        <>
          <H>Which ingredient was wasted?</H>
          <PickGrid items={materials} onPick={setMat} testIDPrefix="mat"
            render={(m) => (<View><Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{m.name}</Text><Text style={{ fontSize: 15, color: C.sub }}>{fmt(m.stock, m.unit)} in stock</Text></View>)} />
        </>
      ) : (
        <Card>
          <H>{mat.name}</H>
          <NumberField testID="waste-qty" label={`Quantity wasted (${mat.unit})`} value={qty} onChange={setQty} step={stepFor(mat.unit)} unit={mat.unit} />
          <View style={{ height: 14 }} />
          <Label>Reason</Label>
          <Chips options={REASONS} value={reason} onChange={setReason} testIDPrefix="reason" />
          <View style={{ height: 12 }} />
          <Field label={reason === 'Other' ? 'What happened? (required)' : 'Note (optional)'} value={note} onChangeText={setNote} />
          <View style={{ height: 12 }} />
          <PhotoPicker label="Photo of the wastage" value={photos} onChange={setPhotos} testID="waste-photo" />
        </Card>
      )}
    </Screen>
  );
}
