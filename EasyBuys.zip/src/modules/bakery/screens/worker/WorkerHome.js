import React from 'react';
import { Screen, useApp } from '../../../../ui/components.js';
import { getSettings } from '../../../../services/core.js';
import BakingPanel from './BakingPanel.js';

export default function WorkerHome() {
  const { user } = useApp();
  return (
    <Screen title={getSettings().bakeryName} subtitle={`Welcome, ${user.name}`}>
      <BakingPanel />
    </Screen>
  );
}
