// Shared wording and pieces for the batch screen and the "time to act" pop-up,
// following the bakery flow: "Mixing should be done – check the mix" → "Mix done – start Cutting".
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../../ui/scale.js';
import { C } from '../../../../ui/theme.js';
import { fmt, getSettings } from '../../../../services/core.js';

export function stepTitle(b) {
  const cur = b.currentStep;
  if (!cur) return '';
  if (cur.kind === 'mix') return 'Mixing should be done – check the mix';
  if (b.nextStep && b.nextStep.kind === 'finish') return `${cur.name} should be done – enter production`;
  return `${cur.name} should be done`;
}

export function confirmLabel(b) {
  const cur = b.currentStep;
  const next = b.nextStep;
  if (!cur || !next) return 'Confirm';
  if (next.kind === 'finish') return `${cur.name} done – enter production`;
  if (cur.kind === 'mix') return `Mix done – start ${next.name}`;
  return `${cur.name} done – start ${next.name}`;
}

export function prepReminder(b) {
  return (b.prep_note && String(b.prep_note).trim()) || getSettings().mixReminder;
}

export function deckList(b) {
  return b.deck ? String(b.deck).split(',').map((d) => d.trim()).filter(Boolean) : [];
}
const deg = (t) => (t === null || t === undefined ? '–' : `${fmt(t)}°`);
// "top 220° / bottom 200°"
export function tempText(d) {
  return d ? `top ${deg(d.top)} / bottom ${deg(d.bottom)}` : '';
}
// "Deck 1 · top 220° / bottom 200°,  Deck 3 · top 210° / bottom 185°"
export function decksText(b) {
  return deckList(b).map((name) => { const d = deckTemps(b, name); return `${name}${d ? ` · ${tempText(d)}` : ''}`; }).join(',  ');
}

export function deckTemps(b, deck) {
  return (b.decks || []).find((x) => x.deck === deck) || null;
}

// Big buttons, one per oven deck, each showing this product's temperature for that deck.
// value is a list: one mix can be split over several decks.
export function DeckPicker({ decks, value = [], onChange, testIDPrefix = 'deck' }) {
  const toggle = (d) => onChange(value.includes(d) ? value.filter((x) => x !== d) : value.concat([d]));
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>🔥 Oven temperatures (top / bottom element) – tap every deck you are using</Text>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {decks.map((d) => {
          const on = value.includes(d.deck);
          return (
            <Pressable key={d.deck} testID={`${testIDPrefix}-${d.deck}`} onPress={() => toggle(d.deck)}
              style={({ pressed }) => ({
                flexGrow: 1, minWidth: 110, minHeight: 150, borderRadius: 14, padding: 10, alignItems: 'center', justifyContent: 'center',
                backgroundColor: on ? C.brandRed : C.white, borderWidth: 3, borderColor: on ? C.brandRed : C.border, opacity: pressed ? 0.7 : 1,
              })}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: on ? C.white : C.sub }}>{d.deck}</Text>
              <Text style={{ fontSize: 14, fontWeight: '800', color: on ? C.white : C.sub, marginTop: 4 }}>TOP</Text>
              <Text style={{ fontSize: 30, fontWeight: '900', color: on ? C.white : C.text }}>{deg(d.top)}C</Text>
              <Text style={{ fontSize: 14, fontWeight: '800', color: on ? C.white : C.sub }}>BOTTOM</Text>
              <Text style={{ fontSize: 30, fontWeight: '900', color: on ? C.white : C.text }}>{deg(d.bottom)}C</Text>
              <Text style={{ fontSize: 14, fontWeight: '800', color: on ? C.white : C.sub }}>{on ? '✓ Using' : 'Tap to use'}</Text>
            </Pressable>
          );
        })}
      </View>
      {value.length > 1 ? <Text style={{ fontSize: 15, color: C.sub }}>This mix is going into {value.length} decks.</Text> : null}
    </View>
  );
}

// Shown while a batch is in the oven.
export function BakingInfo({ b }) {
  if (!b.currentStep || b.currentStep.kind !== 'bake') return null;
  return (
    <View style={{ backgroundColor: C.dangerSoft, borderRadius: 12, padding: 12, marginBottom: 10 }}>
      <Text style={{ fontSize: 15, color: C.danger, fontWeight: '800' }}>IN THE OVEN</Text>
      <Text style={{ fontSize: 28, fontWeight: '900', color: C.text }}>{b.deck ? decksText(b) : 'Deck not recorded'}</Text>
    </View>
  );
}

// Shown while mixing: get the trays ready.
export function PrepInfo({ b }) {
  if (!b.currentStep || b.currentStep.kind !== 'mix') return null;
  return (
    <View style={{ backgroundColor: C.warnSoft, borderRadius: 12, padding: 12, marginBottom: 10 }}>
      <Text style={{ fontSize: 15, color: C.warn, fontWeight: '800' }}>WHILE IT MIXES</Text>
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>🧈 {prepReminder(b)}</Text>
    </View>
  );
}
