// Bakery store: bakery ingredients are ordered and received through the normal Inventory purchase orders and receiving.
// An Inventory product linked to a bakery ingredient ("Flour 25 kg bag" → Flour, 25 kg each) goes into the Bakery stock
// when it is received at the bakery's shop (Shop 1): it does not stay in the shop's stock. Batches, wastage and the
// closing count take it out of the Bakery stock as before.
//
// The links are shared (every device). The Bakery stock itself lives on the bakery tablet, so the bakery tablet adds the
// received ingredients itself (once per delivery, wherever the delivery was entered) – see postBakeryReceipts().
import { db } from '../../db/connection.js';
import { AppError, getShared, setShared, getSetting, setSetting, audit, stamp, dateStr, addDays } from '../../services/core.js';
import { writeTxn, changeStock, addLot, checkReorder } from '../../services/stock.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const r3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };

export const POSTED_SQL = `
CREATE TABLE IF NOT EXISTS bakery_posted (
  receipt_uid TEXT PRIMARY KEY,
  posted_at TEXT NOT NULL,
  lines INTEGER
);
`;
function ensurePosted() { db().exec(POSTED_SQL); }

export function bakeryShop() { return String(getShared('bakery_shop', 'S1') || 'S1'); }
export function bakeryLinks() { return getShared('bakery_links', {}) || {}; }
export function linkFor(itemUid) { const l = bakeryLinks()[itemUid]; return l && l.material ? { material: l.material, factor: Number(l.factor) > 0 ? Number(l.factor) : 1 } : null; }
export function linkForMaterial(name) {
  const e = Object.entries(bakeryLinks()).find(([, l]) => l && String(l.material).toLowerCase() === String(name || '').toLowerCase());
  return e ? { itemUid: e[0], factor: Number(e[1].factor) > 0 ? Number(e[1].factor) : 1 } : null;
}

// Link (or unlink with itemUid = null) a bakery ingredient to an Inventory product. factor = ingredient units in one
// product unit (e.g. 25 when the product is a 25 kg bag and the ingredient is counted in kg).
export function linkMaterial(user, materialName, itemUid, factor = 1) {
  requirePerm(user, 'bakery'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(String(materialName || '').trim(), 'Choose the ingredient.');
  const links = { ...bakeryLinks() };
  Object.keys(links).forEach((k) => { if (String(links[k].material).toLowerCase() === String(materialName).toLowerCase()) delete links[k]; });
  if (itemUid) {
    const it = db().get('SELECT uid, name FROM inv_items WHERE uid = ?', [itemUid]);
    need(it, 'That product was not found.');
    const f = Number(factor);
    need(f > 0 && f < 100000, 'How many of the ingredient are in one product? (e.g. 25 for a 25 kg bag)');
    const other = links[itemUid];
    need(!other, `${it.name} is already linked to ${other && other.material}.`);
    links[itemUid] = { material: String(materialName).trim(), factor: f };
  }
  setShared('bakery_links', links);
  audit({ user, action: itemUid ? `Bakery: ${materialName} is received as Inventory product ${itemUid} (× ${factor})` : `Bakery: ${materialName} no longer linked to an Inventory product`, table: 'shared_settings', recordUid: 'bakery_links' });
  return links;
  });
}

// Called by Inventory receiving for each received line: what part goes to the Bakery store.
export function bakeryPart(itemUid, shopCode, qty) {
  if (shopCode !== bakeryShop()) return null;
  const l = linkFor(itemUid);
  return l ? { material: l.material, qty: r3(qty * l.factor), factor: l.factor } : null;
}

// Is the bakery's stock kept on this device? (Yes once a bakery shift has been started here, or when set.)
export function bakeryHere() {
  const v = getSetting('bakery_stock_here', '');
  if (v === '1') return true;
  if (v === '0') return false;
  try { return !!db().get('SELECT 1 AS x FROM shifts LIMIT 1'); } catch (e) { return false; }
}
export function setBakeryHere(user, on) {
  requirePerm(user, 'bakery'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  setSetting('bakery_stock_here', on ? '1' : '0');
  audit({ user, action: `Bakery stock is ${on ? '' : 'not '}kept on this device`, table: 'settings' });
  });
}

// Deliveries with bakery ingredients not yet added to this device's Bakery stock (newest 90 days).
export function bakeryReceiptsWaiting({ since = addDays(dateStr(), -90) } = {}) {
  ensurePosted();
  let rows = [];
  try {
    rows = db().all(`SELECT r.* FROM inv_receipts r LEFT JOIN bakery_posted p ON p.receipt_uid = r.uid
      WHERE r.status = 'active' AND r.kind = 'receive' AND r.receive_date >= ? AND p.receipt_uid IS NULL AND r.lines LIKE '%"bakery"%' ORDER BY r.created_at`, [since]);
  } catch (e) { rows = []; }
  return rows.map((r) => ({ ...r, lines: J(r.lines, []).filter((l) => l.bakery && l.bakery.material) })).filter((r) => r.lines.length);
}

function localUserId(name) {
  const u = (name && db().get('SELECT id FROM users WHERE name = ? AND active = 1', [name]))
    || db().get("SELECT id FROM users WHERE role IN ('owner','admin') AND active = 1 ORDER BY id")
    || db().get('SELECT id FROM users ORDER BY id');
  return u ? u.id : null;
}

// Adds received ingredients to the Bakery stock (bakery device only; each delivery once). Returns how many lines.
export function postBakeryReceipts({ force = false } = {}) {
  if (!force && !bakeryHere()) return 0;
  let n = 0;
  for (const r of bakeryReceiptsWaiting()) {
    const userId = localUserId(r.by_name);
    if (!userId) break;
    db().transaction(() => {
      let done = 0;
      for (const l of r.lines) {
        const m = db().get('SELECT * FROM materials WHERE lower(name) = lower(?) AND active = 1', [l.bakery.material]);
        if (!m) continue; // ingredient not on this device – shown as a warning in Bakery stock
        const txnId = writeTxn({ type: 'RECEIVE', shiftId: null, userId, materialId: m.id, qty: l.bakery.qty, supplier: r.supplier_name, invoiceNo: r.invoice_no || r.uid, ref: r.uid,
          note: `Received through Inventory${r.po_uid ? ' (purchase order)' : ''} by ${r.by_name || 'someone'}` });
        const unitCost = l.unitCost !== undefined && l.unitCost !== null && l.bakery.factor ? r3(l.unitCost / l.bakery.factor) : null;
        if (unitCost !== null) db().run('UPDATE transactions SET unit_cost = ? WHERE txn_id = ?', [unitCost, txnId]);
        changeStock(m.id, l.bakery.qty);
        if (m.track_stock) addLot({ materialId: m.id, lotNo: null, expiry: null, supplierId: null, invoiceNo: r.invoice_no || r.uid, txnId, qty: l.bakery.qty, unitCost });
        if (unitCost !== null) db().run('UPDATE materials SET cost_per_unit = ?, cost_updated_at = ? WHERE id = ?', [unitCost, stamp(), m.id]);
        done += 1;
      }
      db().run('INSERT OR IGNORE INTO bakery_posted (receipt_uid, posted_at, lines) VALUES (?,?,?)', [r.uid, stamp(), done]);
      n += done;
    });
  }
  if (n) { try { checkReorder(localUserId(null)); } catch (e) { /* reminders only */ } }
  return n;
}

// Ingredients received through Inventory that this device could not match to a bakery ingredient.
export function unmatchedBakeryLines() {
  ensurePosted();
  let rows = [];
  try { rows = db().all("SELECT r.uid, r.receive_date, r.supplier_name, r.lines FROM inv_receipts r JOIN bakery_posted p ON p.receipt_uid = r.uid WHERE r.status = 'active' ORDER BY r.receive_date DESC LIMIT 60"); } catch (e) { rows = []; }
  const out = [];
  rows.forEach((r) => J(r.lines, []).forEach((l) => {
    if (l.bakery && l.bakery.material && !db().get('SELECT 1 AS x FROM materials WHERE lower(name) = lower(?) AND active = 1', [l.bakery.material])) out.push({ receiptUid: r.uid, date: r.receive_date, supplier: r.supplier_name, material: l.bakery.material, qty: l.bakery.qty });
  }));
  return out;
}
