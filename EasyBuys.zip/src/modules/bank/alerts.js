// Warnings for Home: balance check against mobile banking due, cheques / deposits waiting too long, statement
// warnings, M-PAiSA shifts where the wallet got less than the till says (possible fake payment message).
import { can } from '../../services/access.js';
import { dateStr } from '../../services/core.js';
import { bankAlerts } from './extras.js';
import { mainAccount, moneyPosition, checkDue, $ } from './position.js';
import { flaggedLines } from './importer.js';
import { listWallets, walletProblems, ensureDefaultWallets } from './wallets.js';

export function alerts(user) {
  const out = [];
  const bank = can(user, 'bank_rec');
  const wal = can(user, 'wallets') || bank;
  const acc = mainAccount();
  if (bank && acc) {
    const due = checkDue('bank', acc.uid);
    if (due.due) out.push({ id: 'bank-mobile-check', level: 'warning', text: due.last ? `Check the bank balance against BSP mobile banking (last ${due.since} days ago)` : 'Check the bank balance against BSP mobile banking', sub: 'Type the balance from the BSP app – it takes a minute.', nav: { screen: 'BankCheck', params: {} } });
    const p = moneyPosition(acc.uid);
    if (p.stale) out.push({ id: 'bank-stale', level: 'warning', text: `${p.stale} cheque(s) or deposit(s) older than 6 months (stale)`, nav: { screen: 'BankRec', params: {} } });
    if (p.red) out.push({ id: 'bank-red', level: 'warning', text: `${p.red} cheque(s) or deposit(s) waiting longer than the verification days`, sub: 'Not yet on the bank statement – check them.', nav: { screen: 'BankRec', params: {} } });
    const fl = flaggedLines({ accountUid: acc.uid });
    const urgent = fl.filter((l) => l.flagList.some((f) => f.level === 'urgent'));
    if (urgent.length) out.push({ id: 'bank-flags-urgent', level: 'urgent', text: `${urgent.length} bank statement line(s) need checking (unknown cheque or wrong amount)`, nav: { screen: 'Statement', params: { uid: urgent[0].statement_uid } } });
    else if (fl.length) out.push({ id: 'bank-flags', level: 'info', text: `${fl.length} bank statement warning(s) to review`, nav: { screen: 'BankMonthEnd', params: {} } });
    const a = bankAlerts();
    if (a.oldUnmatched) out.push({ id: 'bank-old-unmatched', level: 'warning', text: `${a.oldUnmatched} bank statement line(s) not matched for over 10 days`, nav: { screen: 'BankRec', params: {} } });
  }
  if (wal) {
    try { ensureDefaultWallets(); } catch (e) { /* tables not ready */ }
    for (const w of listWallets()) {
      const due = checkDue('wallet', w.uid);
      if (due.due && due.last) out.push({ id: `wallet-check-${w.uid}`, level: 'info', text: `Check ${w.name} against the ${w.provider} app (last ${due.since} days ago)`, nav: { screen: 'BankCheck', params: { kind: 'wallet', walletUid: w.uid } } });
    }
    for (const p of walletProblems(dateStr())) {
      if (p.short.length) out.push({ id: `wallet-short-${p.wallet.uid}`, level: 'urgent', text: `${p.wallet.name}: the wallet got less than the till recorded on ${p.short.length} day(s) – possible fake payment message`, sub: p.short.slice(0, 3).map((d) => `${d.date} ${$(d.dayDiff)}`).join(', '), nav: { screen: 'MpaisaMatch', params: { walletUid: p.wallet.uid } } });
      if (p.unsorted) out.push({ id: `wallet-unsorted-${p.wallet.uid}`, level: 'info', text: `${p.wallet.name}: ${p.unsorted} statement line(s) to sort`, nav: { screen: 'MpaisaMatch', params: { walletUid: p.wallet.uid } } });
    }
  }
  return out;
}
