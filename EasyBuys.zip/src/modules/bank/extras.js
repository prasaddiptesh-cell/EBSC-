// Bank extras: rules that code repeat lines by themselves (EFTPOS settlements, fees, loan repayments), one bank line
// matched to several records (e.g. one deposit line for two deposit slips), splitting a line over several accounts,
// and lines left unmatched too long.
import { requireSetup } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { markPresented, setEntryCleared, addBankEntry, $, r2 } from '../payables/service.js';
import { candidates, createFromLine } from './service.js';
import { assertOpen } from '../../services/lock.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

// ---------------------------------------------------------------- rules
// { contains: 'EFTPOS', direction: 'in'|'out', type: 'deposit'|'interest'|'adjust_in'|'fee'|'transfer_out'|'adjust_out', glCode: '1110', note }
export function bankRules() { return getShared('bank_rules', []) || []; }
export function saveBankRules(user, rules) {
  requireSetup(user, 'bank_rec');
  const clean = (rules || []).map((r) => ({ contains: txt(r.contains), direction: r.direction === 'in' ? 'in' : 'out', type: txt(r.type), glCode: txt(r.glCode) || null, note: txt(r.note) || null }))
    .filter((r) => r.contains && r.type);
  for (const r of clean) need(r.direction === 'in' ? ['deposit', 'interest', 'adjust_in'].includes(r.type) : ['fee', 'transfer_out', 'adjust_out'].includes(r.type), `Rule "${r.contains}": the type does not fit money ${r.direction}.`);
  setShared('bank_rules', clean);
  audit({ user, action: `Bank rules saved (${clean.length})`, table: 'shared_settings', recordUid: 'bank_rules', after: clean });
  return clean;
}
export function ruleFor(line, rules = bankRules()) {
  const d = `${line.description || ''} ${line.reference || ''}`.toUpperCase();
  return rules.find((r) => (r.direction === 'in') === (line.amount > 0) && d.includes(r.contains.toUpperCase())) || null;
}
// After the sure matches: lines with no match that fit a rule are recorded and coded by themselves.
export function applyRules(user, statementUid) {
  let n = 0;
  for (const l of db().all("SELECT * FROM bank_lines WHERE statement_uid = ? AND status = 'unmatched' ORDER BY line_date", [statementUid])) {
    if (candidates(l).length) continue;
    const r = ruleFor(l);
    if (!r) continue;
    createFromLine(user, l.uid, r.type, r.note || `Rule: ${r.contains}`);
    if (r.glCode) {
      const m = db().get('SELECT match_uid FROM bank_lines WHERE uid = ?', [l.uid]);
      db().run(`UPDATE bank_entries SET gl_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.glCode, stamp(), deviceId(), m.match_uid]);
    }
    n += 1;
  }
  return n;
}

// ---------------------------------------------------------------- one line, several records
// Records not yet cleared whose amounts may add up to the line (same direction, within 45 days).
export function openItems(line) {
  const out = [];
  const from = addDays(line.line_date, -45);
  if (line.amount < 0) {
    db().all(`SELECT * FROM cheques WHERE account_uid = ? AND status = 'written' AND cheque_date BETWEEN ? AND ?`, [line.account_uid, addDays(line.line_date, -400), line.line_date])
      .forEach((c) => out.push({ type: 'cheque', uid: c.uid, label: `Cheque ${c.cheque_no} · ${c.payee} · ${c.cheque_date}`, amount: -c.amount }));
  }
  db().all(`SELECT * FROM bank_entries WHERE account_uid = ? AND status = 'active' AND cleared_date IS NULL AND entry_date BETWEEN ? AND ?`, [line.account_uid, from, line.line_date]).forEach((e) => {
    const signed = ['deposit', 'interest', 'adjust_in'].includes(e.type) ? e.amount : -e.amount;
    if ((signed > 0) === (line.amount > 0)) out.push({ type: 'entry', uid: e.uid, label: `${e.type.replace('_', ' ')} ${e.reference || ''} · ${e.entry_date}`, amount: signed });
  });
  return out;
}
// A combination of open items that adds up exactly (small search: up to 4 items).
export function suggestCombination(line) {
  const items = openItems(line).filter((x) => Math.abs(x.amount) <= Math.abs(line.amount) + 0.005).slice(0, 25);
  const target = Math.round(line.amount * 100);
  const cents = items.map((x) => Math.round(x.amount * 100));
  const n = items.length;
  for (let k = 2; k <= Math.min(4, n); k += 1) {
    const idx = Array.from({ length: k }, (_, i) => i);
    while (true) {
      if (idx.reduce((s, i) => s + cents[i], 0) === target) return idx.map((i) => items[i]);
      let p = k - 1;
      while (p >= 0 && idx[p] === n - k + p) p -= 1;
      if (p < 0) break;
      idx[p] += 1;
      for (let q = p + 1; q < k; q += 1) idx[q] = idx[q - 1] + 1;
    }
  }
  return null;
}
export function matchMany(user, lineUid, items) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  need((items || []).length >= 2, 'Choose two or more records.');
  // Amounts, account and status come from the records themselves.
  items = items.map((x) => {
    if (x.type === 'cheque') {
      const c = db().get('SELECT * FROM cheques WHERE uid = ?', [x.uid]);
      need(c && c.status === 'written' && c.account_uid === l.account_uid, 'A cheque on the list is not open on this account.');
      return { type: 'cheque', uid: c.uid, amount: -c.amount };
    }
    const e = db().get('SELECT * FROM bank_entries WHERE uid = ?', [x.uid]);
    need(e && e.status === 'active' && !e.cleared_date && e.account_uid === l.account_uid, 'A record on the list is not open on this account.');
    return { type: 'entry', uid: e.uid, amount: ['deposit', 'interest', 'adjust_in'].includes(e.type) ? e.amount : -e.amount };
  });
  need(new Set(items.map((x) => x.uid)).size === items.length, 'The same record is on the list twice.');
  const sum = r2(items.reduce((s, x) => s + x.amount, 0));
  need(Math.abs(sum - l.amount) < 0.005, `The records add up to ${$(sum)} but the bank line is ${$(l.amount)}.`);
  for (const x of items) { if (x.type === 'cheque') markPresented(user, x.uid, l.line_date); else setEntryCleared(user, x.uid, l.line_date); }
  db().run(`UPDATE bank_lines SET status = 'matched', match_type = 'many', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [JSON.stringify(items.map((x) => ({ type: x.type, uid: x.uid }))), stamp(), deviceId(), lineUid]);
  audit({ user, action: `Bank line ${$(l.amount)} matched to ${items.length} records`, table: 'bank_lines', recordUid: lineUid });
}

// ---------------------------------------------------------------- split a line over several accounts
// parts: [{ code, amount, shop }] adding up to the line (positive amounts).
export function createSplit(user, lineUid, type, parts, note) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const clean = (parts || []).map((p) => ({ code: txt(p.code), amount: r2(p.amount), shop: txt(p.shop) || null })).filter((p) => p.code && p.amount > 0);
  need(clean.length >= 2, 'A split needs at least two parts.');
  const sum = r2(clean.reduce((s, p) => s + p.amount, 0));
  need(Math.abs(sum - Math.abs(l.amount)) < 0.005, `The parts add up to ${$(sum)} but the line is ${$(Math.abs(l.amount))}.`);
  createFromLine(user, lineUid, type, note);
  const m = db().get('SELECT match_uid FROM bank_lines WHERE uid = ?', [lineUid]);
  db().run(`UPDATE bank_entries SET split = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(clean), stamp(), deviceId(), m.match_uid]);
}
// Code a bank entry the app made (fee, transfer, correction) to an account, so the books know what it was.
export function codeEntry(user, entryUid, glCode) {
  { const x = db().get('SELECT entry_date FROM bank_entries WHERE uid = ?', [entryUid]); if (x) assertOpen(x.entry_date, 'This bank line'); }
  const e = db().get('SELECT * FROM bank_entries WHERE uid = ?', [entryUid]);
  need(e, 'Not found.');
  db().run(`UPDATE bank_entries SET gl_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(glCode) || null, stamp(), deviceId(), entryUid]);
  audit({ user, action: `Bank line ${e.reference || ''} ${$(e.amount)} booked to ${glCode}`, table: 'bank_entries', recordUid: entryUid });
}
// Bank entries made by hand or from statement lines that still go to "suspense" (not coded).
export function uncodedEntries() {
  return db().all(`SELECT * FROM bank_entries WHERE status = 'active' AND payment_uid IS NULL AND gl_code IS NULL AND split IS NULL AND type IN ('adjust_in','adjust_out','transfer_out')
    AND uid NOT LIKE 'BE-WAGES-%' AND uid NOT LIKE 'BE-STAT-%' ORDER BY entry_date DESC LIMIT 200`);
}

// ---------------------------------------------------------------- alerts
export function bankAlerts({ days = 10, today = dateStr() } = {}) {
  const old = db().get("SELECT COUNT(*) AS n FROM bank_lines WHERE status = 'unmatched' AND line_date < ?", [addDays(today, -days)]).n;
  const lastRec = db().get("SELECT MAX(to_date) AS d FROM bank_statements WHERE status <> 'void'").d;
  return { oldUnmatched: old, lastReconciled: lastRec, uncoded: uncodedEntries().length };
}
