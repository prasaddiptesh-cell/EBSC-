// Bank statement import (BSP CSV, OFX, PDF text, pasted text). Imports are allowed mid-month: lines already in the app
// from an earlier import are skipped. After the import the app:
//  1 clears cheques by itself          2 confirms deposits (flags slip differences)   3 confirms M-PAiSA transfers
//  4 finds lines missing from the app (one-tap record; rules remember the payee / account)
//  5 matches loan repayments           6 books fees and interest                       7 flags unknown cheques
//  8 flags duplicates                  9 flags unusual items
// (10 real figures for the cash forecast, 11 bank charges report and 12 statement archive are in position.js,
//  reports35.js and the import screen.)
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, money } from '../../services/core.js';
import { autoMatch, candidates, matchLine, createFromLine, parseStatementText } from './service.js';
import { applyRules, bankRules, saveBankRules, ruleFor, codeEntry } from './extras.js';
import { bankSettings, hasWord, chequeShop, entryShop } from './position.js';
import { addBankEntry, setEntryCleared, makePayment } from '../payables/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const IN_TYPES = ['deposit', 'interest', 'adjust_in'];

// ---------------------------------------------------------------- reading
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const pad = (n) => String(n).padStart(2, '0');
const okDate = (y, m, d) => (m >= 1 && m <= 12 && d >= 1 && d <= 31 ? `${y}-${pad(m)}-${pad(d)}` : null);
// 08/10/2026, 8-10-26, 2026-10-08, 8 Oct 2026, 08-OCT-26, 20261008 (OFX). order: 'dmy' (Fiji, default), 'mdy', 'ymd'.
export function readDate(s, order = 'dmy') {
  const t = txt(s);
  let m = /^(\d{1,4})[/.-](\d{1,2})[/.-](\d{1,4})$/.exec(t);
  if (m) {
    if (m[1].length === 4) return okDate(Number(m[1]), Number(m[2]), Number(m[3]));
    const y = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]);
    return order === 'mdy' ? okDate(y, Number(m[1]), Number(m[2])) : okDate(y, Number(m[2]), Number(m[1]));
  }
  m = /^(\d{4})(\d{2})(\d{2})/.exec(t);
  if (m && t.length >= 8 && /^\d{8}/.test(t)) return okDate(Number(m[1]), Number(m[2]), Number(m[3]));
  m = /^(\d{1,2})[\s-]([A-Za-z]{3})[a-z]*[\s-,]*(\d{2,4})$/.exec(t);
  if (m && MONTHS[m[2].toLowerCase()]) return okDate(Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]), MONTHS[m[2].toLowerCase()], Number(m[1]));
  m = /^([A-Za-z]{3})[a-z]*\s+(\d{1,2}),?\s+(\d{4})$/.exec(t);
  if (m && MONTHS[m[1].toLowerCase()]) return okDate(Number(m[3]), MONTHS[m[1].toLowerCase()], Number(m[2]));
  return null;
}
// One CSV line (commas or tabs or semicolons, "quoted, values") into cells.
export function splitCsv(line) {
  const sep = line.includes('\t') ? '\t' : (line.split(';').length > line.split(',').length ? ';' : ',');
  const out = []; let cur = ''; let q = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"') { if (q && line[i + 1] === '"') { cur += '"'; i += 1; } else q = !q; } else if (ch === sep && !q) { out.push(cur.trim()); cur = ''; } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}
export const amountOf = (s) => {
  const t = String(s === null || s === undefined ? '' : s).replace(/[$,\s]|FJD/gi, '');
  if (!t || !/^[(+-]?(\d+(\.\d+)?|\.\d+)\)?(CR|DR)?$/i.test(t)) return null; // ".90" (BSP writes 90c fees like that)
  let n = Number(t.replace(/[()+]/g, '').replace(/CR|DR/i, ''));
  if (/^\(.*\)$/.test(t) || /DR$/i.test(t) || /^-/.test(t)) n = -Math.abs(n);
  return r2(n);
};
// 3-digit numbers too: the owner's 600-series cheque book ("PRESENTED CHQ #636").
const chequeRef = (d) => (/(?:CHQ|CHEQUE|CHK|CHECK)\s*(?:NO\.?)?\s*#?\s*(\d{3,10})/i.exec(d || '') || [])[1] || '';
const OUT_WORDS = /\b(CHQ|CHEQUE|CHK|FEE|FEES|CHARGE|CHARGES|WITHDRAW|WITHDRAWAL|DEBIT|DR|PAYMENT TO|TRANSFER TO|TFR TO|PURCHASE|DIRECT DEBIT|LOAN REPAYMENT|DUTY)\b/i;

export function parseOfx(text) {
  const t = String(text || '');
  const tag = (block, name) => { const m = new RegExp(`<${name}>([^<\\r\\n]*)`, 'i').exec(block); return m ? m[1].trim() : ''; };
  const lines = [];
  const re = /<STMTTRN>([\s\S]*?)(?:<\/STMTTRN>|(?=<STMTTRN>)|(?=<\/BANKTRANLIST>))/gi;
  let m;
  while ((m = re.exec(t))) {
    const b = m[1];
    const date = readDate(tag(b, 'DTPOSTED').slice(0, 8));
    const amount = amountOf(tag(b, 'TRNAMT'));
    if (!date || !amount) continue;
    const desc = [tag(b, 'NAME'), tag(b, 'MEMO')].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    const ref = tag(b, 'CHECKNUM') || chequeRef(desc) || '';
    lines.push({ date, description: desc || tag(b, 'TRNTYPE'), reference: ref, amount, fitid: tag(b, 'FITID') });
  }
  const closing = amountOf(tag((/<LEDGERBAL>([\s\S]*?)<\/LEDGERBAL>/i.exec(t) || [])[1] || '', 'BALAMT'));
  const fromDate = readDate(tag(t, 'DTSTART').slice(0, 8));
  const toDate = readDate(tag(t, 'DTEND').slice(0, 8));
  return { lines, fromDate, toDate, closing, opening: null, skipped: [] };
}

// CSV with a heading row (Date, Description, Debit, Credit, Balance …); falls back to the v3.4 reader.
export function parseBankCsv(text) {
  const rows = String(text || '').split(/\r?\n/).filter((x) => x.trim()).map(splitCsv);
  const find = (h, re) => h.findIndex((x) => re.test(String(x).toLowerCase()));
  let head = -1; let c = null;
  for (let i = 0; i < Math.min(rows.length, 20); i += 1) {
    const h = rows[i];
    const date = find(h, /date/);
    if (date < 0) continue;
    c = { date, desc: find(h, /desc|detail|narrat|particular|transaction/), ref: find(h, /ref|cheque|chq/), debit: find(h, /debit|withdraw|money out/), credit: find(h, /credit|deposit|money in/), amount: find(h, /^amount$|amount/), balance: find(h, /balance/) };
    if (c.debit >= 0 || c.credit >= 0 || c.amount >= 0) { head = i; break; }
  }
  if (head < 0) return null;
  const lines = []; const skipped = []; const bals = [];
  for (const r of rows.slice(head + 1)) {
    const date = readDate(r[c.date]);
    let amount = null;
    if (c.debit >= 0 || c.credit >= 0) {
      const d = c.debit >= 0 ? amountOf(r[c.debit]) : null; const cr = c.credit >= 0 ? amountOf(r[c.credit]) : null;
      if (d) amount = -Math.abs(d); else if (cr) amount = Math.abs(cr);
    }
    if ((amount === null || amount === 0) && c.amount >= 0 && c.amount !== c.debit && c.amount !== c.credit) amount = amountOf(r[c.amount]);
    if (!date || !amount) { if (r.join('').trim()) skipped.push(r.join(' ')); continue; }
    const d0 = c.desc >= 0 ? txt(r[c.desc]) : '';
    const rf = c.ref >= 0 && c.ref !== c.desc ? txt(r[c.ref]) : '';
    const desc = (rf && !d0.includes(rf) ? `${d0} ${rf}` : d0).trim();
    lines.push({ date, description: desc, reference: (c.ref >= 0 ? (/(\d{3,10})/.exec(r[c.ref] || '') || [])[1] : '') || chequeRef(desc), amount });
    if (c.balance >= 0) bals.push(amountOf(r[c.balance]));
  }
  // With a balance column the opening and closing balances are known (newest-first files are turned round).
  let opening = null; let closing = null;
  if (bals.length === lines.length && bals.length && bals.every((b) => b !== null)) {
    const fwd = Math.abs(r2(bals[0] - lines[0].amount + lines.slice(1).reduce((s, l) => s + l.amount, 0)) - bals[bals.length - 1]) < 0.01;
    if (!fwd && lines.length > 1 && lines[0].date > lines[lines.length - 1].date) { lines.reverse(); bals.reverse(); }
    opening = r2(bals[0] - lines[0].amount); closing = bals[bals.length - 1];
  }
  return { lines, skipped, opening, closing };
}

// Text copied from the PDF statement (or read by Google): date … description … amount … balance.
// With a balance on each line the change in balance tells money in from money out.
export function parsePdfText(text) {
  const lines = []; const skipped = [];
  let prevBal = null; let opening = null;
  const DATE_RE = /^(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}[\s-][A-Za-z]{3,9}[\s-]\d{2,4})\s+(.*)$/;
  const NUM = /\(?-?\$?\d{1,3}(?:,\d{3})*(?:\.\d{2})\)?(?:\s?(?:CR|DR))?/gi;
  String(text || '').split(/\r?\n/).forEach((raw) => {
    const line = raw.trim().replace(/\s+/g, ' ');
    if (!line) return;
    if (/(opening|brought forward|balance b\/f|previous balance)/i.test(line)) {
      const nums = (line.match(NUM) || []).map(amountOf).filter((n) => n !== null);
      if (nums.length) { prevBal = nums[nums.length - 1]; opening = prevBal; }
      skipped.push(line); return;
    }
    const m = DATE_RE.exec(line);
    const date = m ? readDate(m[1]) : null;
    if (!date) { skipped.push(line); return; }
    const rest = m[2];
    const nums = (rest.match(NUM) || []).map(amountOf).filter((n) => n !== null);
    if (!nums.length) { skipped.push(line); return; }
    const desc = rest.replace(NUM, ' ').replace(/\s+/g, ' ').trim();
    let amount = nums[0];
    let bal = nums.length >= 2 ? nums[nums.length - 1] : null;
    if (bal !== null && prevBal !== null && Math.abs(Math.abs(r2(bal - prevBal)) - Math.abs(amount)) < 0.005) amount = r2(bal - prevBal);
    else if (amount > 0 && OUT_WORDS.test(desc) && !/\b(DEPOSIT|CREDIT|CR)\b/i.test(desc)) amount = -amount;
    if (bal !== null) { if (opening === null) opening = r2(bal - amount); prevBal = bal; }
    if (!amount) { skipped.push(line); return; }
    lines.push({ date, description: desc, reference: chequeRef(desc), amount, balance: bal });
  });
  const closing = prevBal;
  return { lines, skipped, opening: lines.length && lines.every((l) => l.balance !== null) ? opening : null, closing: lines.length && lines[lines.length - 1].balance !== null ? closing : null };
}

export function detectFormat(text) {
  const t = String(text || '');
  if (/<OFX>|<STMTTRN>|OFXHEADER/i.test(t)) return 'ofx';
  const first = t.split(/\r?\n/).filter((x) => x.trim()).slice(0, 15);
  if (first.some((l) => /date/i.test(l) && (l.includes(',') || l.includes('\t') || l.includes(';')))) return 'csv';
  return 'text';
}
// Reads any of the formats into { format, lines, fromDate, toDate, opening, closing, skipped }.
export function readBankStatement(text, format) {
  const f = format && format !== 'auto' ? format : detectFormat(text);
  let r = null;
  if (f === 'ofx') r = parseOfx(text);
  else if (f === 'csv') r = parseBankCsv(text);
  if (!r || !r.lines.length) {
    if (f === 'csv' || f === 'paste') {
      const p = parseStatementText(text);
      r = { lines: p.lines, skipped: p.skipped, opening: null, closing: null };
    }
    if ((!r || !r.lines.length) && f !== 'ofx') r = parsePdfText(text);
  }
  const dates = r.lines.map((l) => l.date).sort();
  return { format: f, lines: r.lines, skipped: r.skipped || [], opening: r.opening === undefined ? null : r.opening, closing: r.closing === undefined ? null : r.closing,
    fromDate: r.fromDate || dates[0] || null, toDate: r.toDate || dates[dates.length - 1] || null };
}

// ---------------------------------------------------------------- import
const lineKey = (accountUid, l) => `${l.date}|${r2(l.amount).toFixed(2)}|${txt(l.description).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 40)}`;
export function importBankStatement(user, { accountUid, text, format, parsed, fromDate, toDate, opening, closing, fileName, docUid, notes }) {
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid || '']);
  need(acc, 'Choose the bank account.');
  const p = parsed || readBankStatement(text, format);
  need(p.lines.length, 'No statement lines could be read. Check it is the statement (CSV, OFX or the statement text).');
  const from = txt(fromDate) || p.fromDate; const to = txt(toDate) || p.toDate;
  need(DATE.test(from || '') && DATE.test(to || '') && from <= to, 'Enter the statement dates (from – to).');
  for (const l of p.lines) need(l.date >= from && l.date <= to, `The line "${l.description || l.date}" (${l.date}) is outside the statement dates.`);
  const open0 = txt(opening) !== '' && opening !== null && opening !== undefined ? r2(opening) : p.opening;
  const close0 = txt(closing) !== '' && closing !== null && closing !== undefined ? r2(closing) : p.closing;
  need(close0 !== null && close0 !== undefined && Number.isFinite(Number(close0)), 'Enter the closing balance on the statement.');
  if (open0 !== null && open0 !== undefined) {
    const sum = r2(open0 + p.lines.reduce((s, l) => s + r2(l.amount), 0));
    need(Math.abs(sum - close0) < 0.005, `Opening ${$(open0)} plus the lines is ${$(sum)}, but the closing balance is ${$(close0)}. A line is missing or wrong.`);
  }
  // Lines already in the app from an earlier (mid-month) import are skipped; the same line twice in this file is flagged.
  const have = new Set(db().all('SELECT line_date AS date, amount, description FROM bank_lines WHERE account_uid = ? AND line_date BETWEEN ? AND ?', [acc.uid, from, to]).map((l) => lineKey(acc.uid, l)));
  const inFile = {};
  p.lines.forEach((l) => { const k = lineKey(acc.uid, l); inFile[k] = (inFile[k] || 0) + 1; });
  const { now, dev } = meta();
  const uid = uuid('ST');
  let added = 0; let already = 0;
  const seenHave = {};
  db().transaction(() => {
    db().run(`INSERT INTO bank_statements (uid, account_uid, from_date, to_date, opening, closing, by_name, created_at, notes, source, doc_uid, skipped, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, acc.uid, from, to, open0 === null || open0 === undefined ? null : r2(open0), r2(close0), user.name, now, txt(notes) || (fileName ? `File ${fileName}` : null), p.format || format || 'paste', docUid || null, 0, now, dev]);
    for (const l of p.lines) {
      const k = lineKey(acc.uid, l);
      if (have.has(k) && !(seenHave[k])) { seenHave[k] = true; already += 1; continue; }
      const flags = inFile[k] > 1 ? [{ code: 'duplicate', level: 'warning', text: `This line appears ${inFile[k]} times on the statement – check the bank has not charged / paid it twice.` }] : [];
      db().run(`INSERT INTO bank_lines (uid, statement_uid, account_uid, line_date, description, reference, amount, flags, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [uuid('BL'), uid, acc.uid, l.date, txt(l.description) || null, txt(l.reference) || null, r2(l.amount), flags.length ? JSON.stringify(flags) : null, now, dev]);
      added += 1;
    }
    db().run('UPDATE bank_statements SET skipped = ? WHERE uid = ?', [already, uid]);
  });
  audit({ user, action: `Bank statement imported ${from} to ${to} (${added} lines${already ? `, ${already} already in` : ''})`, table: 'bank_statements', recordUid: uid });
  const summary = analyseStatement(user, uid);
  return { uid, added, already, summary };
}

// ---------------------------------------------------------------- the checks after an import
const addFlag = (lineUid, flag) => {
  const l = db().get('SELECT flags FROM bank_lines WHERE uid = ?', [lineUid]);
  const list = J(l && l.flags, []).filter((f) => f.code !== flag.code);
  list.push(flag);
  db().run(`UPDATE bank_lines SET flags = ?, flags_ok_by = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), lineUid]);
};
export const lineFlags = (l) => J(l.flags, []);
export function payeeKey(desc) {
  return txt(desc).toUpperCase().replace(/[0-9]+/g, ' ').replace(/[^A-Z ]/g, ' ').split(/\s+/).filter((w) => w.length > 1 && !['TO', 'FROM', 'THE', 'AND', 'REF', 'PAYMENT', 'TFR'].includes(w)).slice(0, 3).join(' ');
}
const getLines = (statementUid, status) => db().all(`SELECT * FROM bank_lines WHERE statement_uid = ? AND (? IS NULL OR status = ?) ORDER BY line_date, amount`, [statementUid, status || null, status || null]);
// Loans (Regular bills & loans) a money-out line may be a repayment of: lender name, loan number or the amount.
export function loanFor(line) {
  if (line.amount >= 0) return null;
  let loans = [];
  try { loans = db().all(`SELECT r.*, s.name AS supplier FROM ap_recurring r LEFT JOIN ap_suppliers s ON s.uid = r.supplier_uid WHERE r.kind = 'loan' AND r.active = 1`); } catch (e) { return null; }
  const d = `${line.description || ''} ${line.reference || ''}`.toUpperCase();
  const amt = Math.abs(line.amount);
  const score = (r) => (r.loan_no && d.includes(String(r.loan_no).toUpperCase()) ? 3 : 0) + (Math.abs(r.amount - amt) < 0.005 ? 2 : 0)
    + (payeeKey(r.supplier || r.name).split(' ').filter((w) => w.length > 2 && d.includes(w)).length ? 1 : 0) + (/\bLOAN\b/.test(d) ? 1 : 0);
  const best = loans.map((r) => ({ r, s: score(r) })).filter((x) => x.s >= 2).sort((a, b) => b.s - a.s)[0];
  if (!best) return null;
  const inv = db().get(`SELECT i.uid, i.total - IFNULL((SELECT SUM(a.amount) FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = i.uid), 0) AS owing
    FROM ap_invoices i WHERE i.uid LIKE ? AND i.status <> 'void' ORDER BY ABS(julianday(i.due_date) - julianday(?)) LIMIT 5`, [`RI-${best.r.uid}-%`, line.line_date]);
  return { recurringUid: best.r.uid, name: best.r.name, invoiceUid: inv && Math.abs(inv.owing - amt) < 0.005 ? inv.uid : null, supplierUid: best.r.supplier_uid };
}
// Runs after every import (and again on demand). Returns what was done, by feature number.
export function analyseStatement(user, statementUid) {
  const s = bankSettings();
  const out = { cheques: 0, deposits: 0, slipDiffs: 0, mpaisa: 0, missing: 0, loans: 0, fees: 0, unknownCheques: 0, duplicates: 0, unusual: 0, rules: 0 };
  const before = new Set(getLines(statementUid, 'matched').map((l) => l.uid));
  autoMatch(user, statementUid);
  // Release 05: the owner's links – lines from before the app, moves to our own accounts (Visa debit), owner's money,
  // M-PAiSA money in from the shop written on the line, and the shop of every line.
  try { out.links = require('./links05.js').applyLinks(user, statementUid); } catch (e) { out.links = null; }
  // 6 fees and interest
  if (s.autoFees) {
    for (const l of getLines(statementUid, 'unmatched')) {
      if (candidates(l).length) continue;
      const d = `${l.description || ''} ${l.reference || ''}`;
      const type = l.amount < 0 && hasWord(d, s.feeWords) ? 'fee' : l.amount > 0 && hasWord(d, s.interestWords) ? 'interest' : null;
      if (!type || ruleFor(l)) continue;
      createFromLine(user, l.uid, type, l.description || (type === 'fee' ? 'Bank fee' : 'Interest'));
      const m = db().get('SELECT match_uid FROM bank_lines WHERE uid = ?', [l.uid]);
      codeEntry(user, m.match_uid, type === 'fee' ? s.feeGl : s.interestGl);
      out.fees += 1;
    }
  }
  out.rules = applyRules(user, statementUid);
  // count what the sure matches confirmed (1 cheques, 2 deposits, 3 M-PAiSA transfers) and tag the shop
  for (const l of getLines(statementUid, 'matched')) {
    let shop = l.shop_code;
    if (l.match_type === 'cheque') {
      const c = db().get('SELECT * FROM cheques WHERE uid = ?', [l.match_uid]);
      if (!before.has(l.uid)) out.cheques += 1;
      if (c) {
        shop = shop || chequeShop(c);
        if (Math.abs(c.amount + l.amount) > 0.005) addFlag(l.uid, { code: 'cheque_amount', level: 'warning', text: `Cheque ${c.cheque_no} was written for ${$(c.amount)} but the bank paid ${$(-l.amount)}.` });
      }
    } else if (l.match_type === 'entry') {
      const e = db().get('SELECT * FROM bank_entries WHERE uid = ?', [l.match_uid]);
      if (e && !before.has(l.uid)) { if (e.uid.startsWith('BE-WT-')) out.mpaisa += 1; else if (e.type === 'deposit') out.deposits += 1; }
      if (e) shop = shop || entryShop(e);
    }
    if (shop && shop !== l.shop_code) db().run('UPDATE bank_lines SET shop_code = ? WHERE uid = ?', [shop, l.uid]);
  }
  const mp = s.mpaisaWords;
  for (const l of getLines(statementUid, 'unmatched')) {
    const d = `${l.description || ''} ${l.reference || ''}`;
    if (l.amount > 0) {
      // 2 deposit with a different amount than its slip (slip number on the line, or a close amount within a week)
      const slip = (/(?:SLIP|DEP(?:OSIT)?)\s*#?\s*(\w{3,})/i.exec(d) || [])[1];
      const open = db().all(`SELECT e.*, d.slip_no FROM bank_entries e LEFT JOIN deposits d ON d.bank_entry_uid = e.uid WHERE e.account_uid = ? AND e.status = 'active' AND e.cleared_date IS NULL AND e.type = 'deposit' AND e.entry_date BETWEEN ? AND ?`,
        [l.account_uid, addDays(l.line_date, -10), l.line_date]);
      const bySlip = slip ? open.find((e) => e.slip_no && String(e.slip_no).toUpperCase() === String(slip).toUpperCase()) : null;
      const near = bySlip || open.filter((e) => Math.abs(e.amount - l.amount) <= s.slipTolerance).sort((a, b) => Math.abs(a.amount - l.amount) - Math.abs(b.amount - l.amount))[0];
      if (near) {
        addFlag(l.uid, { code: 'slip_diff', level: 'warning', entryUid: near.uid, diff: r2(l.amount - near.amount), text: `${near.slip_no ? `Deposit slip ${near.slip_no}` : near.reference || 'A deposit'} was ${$(near.amount)} but the bank shows ${$(l.amount)} (${l.amount > near.amount ? '+' : '−'}${$(Math.abs(l.amount - near.amount))}).` });
        out.slipDiffs += 1; continue;
      }
      if (hasWord(d, mp) || (() => { try { return require('./links05.js').wordsFor(d).some((w) => w.mpaisa); } catch (e) { return false; } })()) { addFlag(l.uid, { code: 'mpaisa_missing', level: 'info', text: 'Looks like an M-PAiSA transfer that is not recorded – record it from the right wallet.' }); out.missing += 1; continue; }
    }
    if (l.amount < 0) {
      // 7 unknown cheques
      const no = l.reference || chequeRef(d);
      if (no && /^\d{3,10}$/.test(no)) {
        const c = db().get('SELECT * FROM cheques WHERE account_uid = ? AND cheque_no = ?', [l.account_uid, Number(no)]);
        if (!c) {
          const book = db().get('SELECT * FROM cheque_books WHERE account_uid = ? AND ? BETWEEN first_no AND last_no', [l.account_uid, Number(no)]);
          addFlag(l.uid, { code: 'unknown_cheque', level: 'urgent', text: `Cheque ${no} (${$(-l.amount)}) is not recorded in the app${book ? ' – it is from one of our cheque books' : ' and is not in any of our cheque books'}. Find the stub.` });
          out.unknownCheques += 1; continue;
        }
        // Release 06: entered in the app after the bank had already paid it (the app's date is later than the bank's):
        // same number, same amount – it is this cheque. Its date (and its payment's) move back to the bank's date.
        if (c.status === 'written' && Math.abs(c.amount + l.amount) <= 0.005 && c.cheque_date > l.line_date) {
          try {
            const { now: n0, dev: d0 } = meta();
            db().run(`UPDATE cheques SET cheque_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [l.line_date, n0, d0, c.uid]);
            if (c.payment_uid) db().run(`UPDATE ap_payments SET pay_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND pay_date > ?`, [l.line_date, n0, d0, c.payment_uid, l.line_date]);
            audit({ user, action: `Cheque ${no}: date moved from ${c.cheque_date} to ${l.line_date} – the bank paid it on ${l.line_date} (it was entered in the app later)`, table: 'cheques', recordUid: c.uid, before: { cheque_date: c.cheque_date }, after: { cheque_date: l.line_date } });
            matchLine(user, l.uid, { type: 'cheque', uid: c.uid });
            addFlag(l.uid, { code: 'cheque_date', level: 'info', text: `Cheque ${no} was entered with the date ${c.cheque_date}; the bank paid it on ${l.line_date}, so its date was moved back.` });
            out.cheques += 1; continue;
          } catch (e) { /* left for the person below */ }
        }
        if (c.status !== 'written') { addFlag(l.uid, { code: 'unknown_cheque', level: 'urgent', text: `Cheque ${no} is recorded as ${c.status === 'presented' ? `already cleared on ${c.presented_date}` : c.status} – the bank paid it again?` }); out.unknownCheques += 1; continue; }
        if (Math.abs(c.amount + l.amount) > 0.005) { addFlag(l.uid, { code: 'cheque_amount', level: 'urgent', text: `Cheque ${no} was written for ${$(c.amount)} but the bank paid ${$(-l.amount)}.` }); out.unknownCheques += 1; continue; }
      }
      // 5 loan repayments
      const loan = loanFor(l);
      if (loan) { addFlag(l.uid, { code: 'loan', level: 'info', recurringUid: loan.recurringUid, invoiceUid: loan.invoiceUid, text: `Loan repayment – ${loan.name}${loan.invoiceUid ? ' (its bill is waiting)' : ''}.` }); out.loans += 1; continue; }
    }
    // 4 missing from the app
    addFlag(l.uid, { code: 'missing', level: 'info', text: 'Not in the app yet – record it with one tap.' });
    out.missing += 1;
  }
  // 8 duplicates (already flagged at import) and 9 unusual items
  for (const l of getLines(statementUid)) {
    const f = lineFlags(l);
    if (f.some((x) => x.code === 'duplicate')) out.duplicates += 1;
    const key = payeeKey(l.description);
    const a = Math.abs(l.amount);
    let unusual = null;
    if (s.unusualAmount > 0 && a >= s.unusualAmount) unusual = `${$(a)} is a large amount (over ${$(s.unusualAmount)}).`;
    else if (key) {
      const past = db().all('SELECT ABS(amount) AS a, description FROM bank_lines WHERE account_uid = ? AND statement_uid <> ? AND (amount > 0) = ? ORDER BY line_date DESC LIMIT 400', [l.account_uid, statementUid, l.amount > 0 ? 1 : 0])
        .filter((x) => payeeKey(x.description) === key).map((x) => x.a);
      if (past.length >= 3) { const avg = past.reduce((t, x) => t + x, 0) / past.length; if (a > avg * s.unusualTimes) unusual = `${$(a)} is much more than usual for "${key}" (usually about ${$(avg)}).`; }
    }
    if (unusual && !f.some((x) => x.code === 'unusual')) { addFlag(l.uid, { code: 'unusual', level: 'warning', text: unusual }); out.unusual += 1; }
  }
  return out;
}

// ---------------------------------------------------------------- one-tap actions on a statement line
export function reviewFlags(user, lineUid) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l, 'Not found.');
  db().run(`UPDATE bank_lines SET flags_ok_by = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`${user.name} ${stamp().slice(0, 16)}`, stamp(), deviceId(), lineUid]);
  audit({ user, action: 'Bank statement warning reviewed', table: 'bank_lines', recordUid: lineUid, after: lineFlags(l) });
}
// 2: the slip was for a different amount: match it and record the difference as a correction.
export function acceptSlipDifference(user, lineUid, note) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const f = lineFlags(l).find((x) => x.code === 'slip_diff');
  need(f, 'No deposit slip found for this line.');
  const e = db().get('SELECT * FROM bank_entries WHERE uid = ?', [f.entryUid]);
  need(e && e.status === 'active' && !e.cleared_date, 'That deposit is no longer open.');
  const diff = r2(l.amount - e.amount);
  const adj = addBankEntry(user, { accountUid: l.account_uid, type: diff > 0 ? 'adjust_in' : 'adjust_out', amount: Math.abs(diff), date: l.line_date, reference: `Slip difference ${e.reference || ''}`.trim(), note: txt(note) || `Bank counted ${$(l.amount)}, slip said ${$(e.amount)}`, clearedDate: l.line_date });
  setEntryCleared(user, e.uid, l.line_date);
  const { now, dev } = meta();
  db().run(`UPDATE bank_lines SET status = 'matched', match_type = 'many', match_uid = ?, shop_code = COALESCE(shop_code, ?), flags_ok_by = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [JSON.stringify([{ type: 'entry', uid: e.uid }, { type: 'entry', uid: adj }]), entryShop(e), user.name, now, dev, lineUid]);
  audit({ user, action: `Deposit ${e.reference || ''} matched with a difference of ${$(diff)}`, table: 'bank_lines', recordUid: lineUid, reason: note });
}
// 4: a line not in the app: record it, book it, tag the shop, and optionally remember the payee as a rule.
export function recordMissing(user, lineUid, { type, glCode, shop, remember, note } = {}) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const t = type || (l.amount > 0 ? 'deposit' : 'transfer_out');
  createFromLine(user, lineUid, t, note || l.description);
  const m = db().get('SELECT match_uid FROM bank_lines WHERE uid = ?', [lineUid]);
  if (txt(glCode)) codeEntry(user, m.match_uid, glCode);
  if (txt(shop)) {
    db().run('UPDATE bank_entries SET shop_code = ? WHERE uid = ?', [txt(shop), m.match_uid]);
    db().run('UPDATE bank_lines SET shop_code = ? WHERE uid = ?', [txt(shop), lineUid]);
  }
  if (remember) {
    const key = payeeKey(l.description);
    if (key) {
      const rules = bankRules().filter((r) => !(r.contains.toUpperCase() === key && (r.direction === 'in') === (l.amount > 0)));
      saveBankRules(user, rules.concat([{ contains: key, direction: l.amount > 0 ? 'in' : 'out', type: t, glCode: txt(glCode) || null, note: txt(note) || null }]));
    }
  }
  return m.match_uid;
}
// 5: a loan repayment: pay the loan's bill by transfer (so the loan balance goes down) and match it.
export function matchLoanLine(user, lineUid) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const f = lineFlags(l).find((x) => x.code === 'loan') || {};
  const loan = loanFor(l) || {};
  const invUid = f.invoiceUid || loan.invoiceUid;
  if (invUid) {
    const inv = db().get('SELECT * FROM ap_invoices WHERE uid = ?', [invUid]);
    const pay = makePayment(user, { supplierUid: inv.supplier_uid, method: 'transfer', accountUid: l.account_uid, payDate: l.line_date, reference: l.reference || l.description || 'Loan repayment', allocations: [{ invoiceUid: invUid, amount: Math.abs(l.amount) }], notes: 'Loan repayment from the bank statement' });
    const e = db().get("SELECT uid FROM bank_entries WHERE payment_uid = ? AND status = 'active'", [pay.uid]);
    matchLine(user, lineUid, { type: 'entry', uid: e.uid });
    return pay.uid;
  }
  // No bill waiting: record it as a transfer out booked to the loan (owing account) so nothing is lost.
  const name = f.text || loan.name || 'Loan repayment';
  return recordMissing(user, lineUid, { type: 'transfer_out', note: `Loan repayment ${loan.name || ''}`.trim() || name });
}
// 3: an M-PAiSA transfer not recorded: record it from the wallet and match it.
export function mpaisaFromLine(user, lineUid, walletUid) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched' && l.amount > 0, 'Line already dealt with.');
  const { recordWalletTransfer } = require('./wallets.js');
  const mUid = recordWalletTransfer(user, { walletUid, date: l.line_date, amount: l.amount, reference: l.reference || l.description, accountUid: l.account_uid, note: 'Found on the bank statement' });
  matchLine(user, lineUid, { type: 'entry', uid: `BE-WT-${mUid}` });
  db().run('UPDATE wallet_moves SET cleared_date = ? WHERE uid = ?', [l.line_date, mUid]);
  return mUid;
}
// Statement lines with warnings not reviewed yet (Home and month end).
export function flaggedLines({ accountUid, from = '0000', to = '9999', open = true } = {}) {
  return db().all(`SELECT * FROM bank_lines WHERE flags IS NOT NULL AND flags <> '[]' AND (? IS NULL OR account_uid = ?) AND line_date BETWEEN ? AND ? ${open ? 'AND flags_ok_by IS NULL' : ''} ORDER BY line_date DESC`,
    [accountUid || null, accountUid || null, from, to]).map((l) => ({ ...l, flagList: lineFlags(l) }))
    .filter((l) => !open || l.flagList.some((f) => f.level !== 'info' || l.status === 'unmatched'));
}
