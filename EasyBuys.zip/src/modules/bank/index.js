// Bank reconciliation module.
import { BankRecScreen, StatementNewScreen, StatementScreen, BankRulesScreen } from './screens/BankScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { V1_BANK_REPORTS } from './v1Recon.js';
import { ReconMonthScreen, BankMatchScreen } from './screens/V1BankScreens.js';
import { BankLinksScreen, MoveMoneyScreen } from './screens/Links05Screens.js';
import { BankCheckScreen, BankChecksScreen, BankImportScreen, BankHistoryScreen, BankArchiveScreen, BankMonthEndScreen, WalletsScreen, WalletScreen, WalletSetupScreen,
  MpaisaImportScreen, MpaisaMatchScreen, MpaisaColumnsScreen } from './screens/Bank35Screens.js';

export default {
  id: 'bank',
  title: 'Bank reconciliation',
  icon: '🏦',
  switchable: true,
  screens: {
    BankRec: { component: BankRecScreen, can: (u) => can(u, 'bank_rec') },
    StatementNew: { component: StatementNewScreen, can: (u) => can(u, 'bank_rec') },
    Statement: { component: StatementScreen, can: (u) => can(u, 'bank_rec') },
    BankRules: { component: BankRulesScreen, can: (u) => can(u, 'bank_rec') },
    BankCheck: { component: BankCheckScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    BankChecks: { component: BankChecksScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    BankImport: { component: BankImportScreen, can: (u) => can(u, 'bank_rec') },
    BankHistory: { component: BankHistoryScreen, can: (u) => can(u, 'bank_rec') },
    BankArchive: { component: BankArchiveScreen, can: (u) => can(u, 'bank_rec') },
    BankMonthEnd: { component: BankMonthEndScreen, can: (u) => can(u, 'bank_rec') },
    Wallets: { component: WalletsScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    Wallet: { component: WalletScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    WalletSetup: { component: WalletSetupScreen, can: (u) => can(u, 'bank_rec') },
    MpaisaImport: { component: MpaisaImportScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    MpaisaMatch: { component: MpaisaMatchScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    MpaisaColumns: { component: MpaisaColumnsScreen, can: (u) => can(u, 'bank_rec') },
    // 1.0.0 (build 1) reconciliation for the month (BSP and the wallets) and line-by-line matching
    ReconMonth: { component: ReconMonthScreen, can: (u) => can(u, 'bank_rec') || can(u, 'accounts_view') },
    BankMatch: { component: BankMatchScreen, can: (u) => can(u, 'bank_rec') },
    // Release 05: how the accounts connect (owner / admin change it; others with bank permission see it); move money
    BankLinks: { component: BankLinksScreen, can: (u) => can(u, 'bank_rec') || can(u, 'cheques_manage') },
    MoveMoney: { component: MoveMoneyScreen, can: (u) => can(u, 'cheques_manage') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS.concat(V1_BANK_REPORTS),
};
