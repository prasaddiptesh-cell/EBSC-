// Bank reconciliation module.
import { BankRecScreen, StatementNewScreen, StatementScreen, BankRulesScreen } from './screens/BankScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { BankCheckScreen, BankChecksScreen, BankImportScreen, BankHistoryScreen, BankArchiveScreen, BankMonthEndScreen, WalletsScreen, WalletScreen, WalletSetupScreen,
  MpaisaImportScreen, MpaisaMatchScreen, MpaisaColumnsScreen } from './screens/Bank35Screens.js';

export default {
  id: 'bank',
  title: 'Bank reconciliation',
  icon: '🏦',
  switchable: true,
  screens: {
    BankRec: { component: BankRecScreen, can: (u) => can(u, 'bank_rec') },
    StatementNew: { component: StatementNewScreen, can: (u) => can(u, 'bank_rec') },
    Statement: { component: StatementScreen, can: (u) => can(u, 'bank_rec') },
    BankRules: { component: BankRulesScreen, can: (u) => can(u, 'bank_rec') },
    BankCheck: { component: BankCheckScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    BankChecks: { component: BankChecksScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    BankImport: { component: BankImportScreen, can: (u) => can(u, 'bank_rec') },
    BankHistory: { component: BankHistoryScreen, can: (u) => can(u, 'bank_rec') },
    BankArchive: { component: BankArchiveScreen, can: (u) => can(u, 'bank_rec') },
    BankMonthEnd: { component: BankMonthEndScreen, can: (u) => can(u, 'bank_rec') },
    Wallets: { component: WalletsScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    Wallet: { component: WalletScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    WalletSetup: { component: WalletSetupScreen, can: (u) => can(u, 'bank_rec') },
    MpaisaImport: { component: MpaisaImportScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    MpaisaMatch: { component: MpaisaMatchScreen, can: (u) => can(u, 'bank_rec') || can(u, 'wallets') },
    MpaisaColumns: { component: MpaisaColumnsScreen, can: (u) => can(u, 'bank_rec') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
