// Bank reconciliation module.
import { BankRecScreen, StatementNewScreen, StatementScreen, BankRulesScreen } from './screens/BankScreens.js';
import { stamp } from '../../services/core.js';
import { db } from '../../db/connection.js';
import { reconcileSummary, $ } from './service.js';
import { can } from '../../services/access.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const REPORTS = [
  { id: 'bank_rec', group: 'Bank', icon: '🏦', title: 'Bank reconciliations', desc: 'Statements in the period: balanced or not, and what was left', perm: 'bank_rec',
    build(from, to) {
      const sts = db().all("SELECT uid FROM bank_statements WHERE status <> 'void' AND to_date BETWEEN ? AND ? ORDER BY to_date", [from, to]).map((x) => reconcileSummary(x.uid));
      const rows = sts.map((r) => ({ acct: r.statement.account_name, period: `${r.statement.from_date} – ${r.statement.to_date}`, closing: $(r.statement.closing), book: $(r.check.balance),
        chq: $(r.check.chequesOut), dep: $(r.check.depositsInTransit), diff: $(r.check.difference), status: r.statement.status === 'reconciled' ? `done ${r.statement.reconciled_by_name}` : `${r.unmatched.length} to match`,
        _tone: r.check.balanced && r.statement.status === 'reconciled' ? 'good' : 'bad' }));
      const items = [];
      sts.forEach((r) => r.check.notCleared.forEach((c) => items.push({ acct: r.statement.account_name, what: `Cheque ${c.cheque_no} ${c.payee}`, date: c.cheque_date, amount: $(c.amount) })));
      return { kind: 'bank_rec', title: 'Bank Reconciliations', fileName: `Bank-Reconciliations-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`,
        info: [['Period', `${from} to ${to}`], ['Generated', stamp()]], summary: [{ label: 'Statements', value: String(sts.length) }, { label: 'Balanced', value: String(sts.filter((r) => r.check.balanced).length), tone: 'good' }],
        sections: [{ title: 'Statements', columns: [col('acct', 'Account'), col('period', 'Period'), col('closing', 'Statement', 'right'), col('book', 'Cheque book', 'right'), col('chq', 'Cheques out', 'right'), col('dep', 'Deposits in transit', 'right'), col('diff', 'Difference', 'right'), col('status', 'Status')], rows },
          { title: 'Cheques not cleared at the statement dates', columns: [col('acct', 'Account'), col('what', 'Cheque'), col('date', 'Date'), col('amount', 'Amount', 'right')], rows: items }] };
    } },
];

export default {
  id: 'bank',
  title: 'Bank reconciliation',
  icon: '🏦',
  switchable: true,
  screens: {
    BankRec: { component: BankRecScreen, can: (u) => can(u, 'bank_rec') },
    StatementNew: { component: StatementNewScreen, can: (u) => can(u, 'bank_rec') },
    Statement: { component: StatementScreen, can: (u) => can(u, 'bank_rec') },
    BankRules: { component: BankRulesScreen, can: (u) => can(u, 'bank_rec') },
  },
  reports: REPORTS,
};
