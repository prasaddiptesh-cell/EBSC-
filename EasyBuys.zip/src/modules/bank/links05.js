// Release 05 – Money & bank connections (set by the owner or an admin, used by everyone with permission).
// What each bank account is (cheque, Visa debit / card, savings), which account pays each loan and whether the bank
// takes it by itself, and the statement words: which shop a line belongs to, which lines are M-PAiSA money moved in,
// which are transfers to one of our own accounts and which are the owner's own money (drawings).
// Nothing here is fixed in the code: the owner can change every link at any time (each change is in the history).
import { db } from '../../db/connection.js';
import { AppError, audit, dateStr, addDays, getShared, setShared, money, stamp, deviceId } from '../../services/core.js';
import { actsAsOwner } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';
import { addBankEntry, getInvoicesWhere } from '../payables/service.js';
import { matchLine, createFromLine, ignoreLine } from './service.js';
import { codeEntry } from './extras.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const digits = (v) => txt(v).replace(/\D/g, '');
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const ACCOUNT_KINDS = { cheque: 'Cheque account', card: 'Visa debit / card account', savings: 'Savings account', other: 'Other account' };
export const DRAWINGS_GL = '3100';   // Owner's money in / drawings
export const MOVING_GL = '1110';     // money on the way (a move between our own accounts nets to nothing)

// Only the owner or an admin changes the links (staff with permission use them).
export function mayLink(user) { return !!user && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role)); }
function requireLinker(user) {
  requirePerm(user, ['bank_rec', 'cheques_manage'], { money: true });
  need(mayLink(user), 'Only the owner or an admin can change how the bank accounts are connected.');
}

export function bankLinks() {
  const x = getShared('bank_links', {}) || {};
  return { accounts: x.accounts || {}, loans: x.loans || {}, words: Array.isArray(x.words) ? x.words : [] };
}
function saveLinks(user, next, action) {
  const before = bankLinks();
  setShared('bank_links', next);
  audit({ user, action, table: 'shared_settings', recordUid: 'bank_links', before, after: next });
  return next;
}

// ---------------------------------------------------------------- accounts
export function listAccountsWithKind({ includeInactive = false } = {}) {
  if (!has('bank_accounts')) return [];
  const L = bankLinks().accounts;
  return db().all(`SELECT * FROM bank_accounts WHERE (? = 1 OR active = 1) ORDER BY sort, name`, [includeInactive ? 1 : 0])
    .map((a) => ({ ...a, kind: (L[a.uid] && L[a.uid].kind) || 'cheque', kindLabel: ACCOUNT_KINDS[(L[a.uid] && L[a.uid].kind) || 'cheque'] }));
}
export function accountKind(uid) { const l = bankLinks().accounts[uid]; return (l && l.kind) || 'cheque'; }
export function saveAccountKind(user, uid, kind) {
  requireLinker(user);
  return asService(() => {
    need(db().get('SELECT 1 AS x FROM bank_accounts WHERE uid = ?', [uid || '']), 'Choose the bank account.');
    need(ACCOUNT_KINDS[kind], 'Choose what kind of account it is.');
    const L = bankLinks();
    L.accounts = { ...L.accounts, [uid]: { ...(L.accounts[uid] || {}), kind } };
    return saveLinks(user, L, `Bank account set as ${ACCOUNT_KINDS[kind]}`);
  });
}
// Another of our accounts named on a statement line ("IB FUNDS TRANSFER TO 88163418 …"): by its number (whole or
// the last 4 digits).
export function ownAccountIn(desc, exceptUid) {
  const nums = String(desc || '').match(/\d{4,}/g) || [];
  if (!nums.length) return null;
  for (const a of listAccountsWithKind()) {
    if (a.uid === exceptUid) continue;
    const no = digits(a.account_no);
    if (no.length < 4) continue;
    if (nums.some((n) => n === no || n.slice(-4) === no.slice(-4))) return a;
  }
  return null;
}

// ---------------------------------------------------------------- loans: which account pays them
export function loanLink(loanUid) { return { payFromUid: '', auto: false, ...(bankLinks().loans[loanUid] || {}) }; }
export function saveLoanLink(user, loanUid, { payFromUid, auto }) {
  requireLinker(user);
  return asService(() => {
    need(db().get("SELECT 1 AS x FROM ap_recurring WHERE uid = ? AND kind = 'loan'", [loanUid || '']), 'Loan not found.');
    if (txt(payFromUid)) need(db().get('SELECT 1 AS x FROM bank_accounts WHERE uid = ?', [payFromUid]), 'Choose the account that pays it.');
    const L = bankLinks();
    L.loans = { ...L.loans, [loanUid]: { payFromUid: txt(payFromUid), auto: !!auto } };
    return saveLinks(user, L, auto ? 'Loan set as taken by the bank automatically' : 'Loan set as paid by us (cheque / cash)');
  });
}
// Loan repayments the bank will take by itself from an account in the next few days (they need covering like cheques).
export function loanDeductionsDue({ accountUid, today = dateStr(), days = 10 } = {}) {
  if (!has('ap_recurring') || !has('ap_invoices')) return [];
  const L = bankLinks().loans;
  const out = [];
  for (const r of db().all("SELECT uid, name FROM ap_recurring WHERE kind = 'loan' AND active = 1")) {
    const l = L[r.uid];
    if (!l || !l.auto || (accountUid && l.payFromUid !== accountUid)) continue;
    let bills = [];
    try { bills = getInvoicesWhere('i.uid LIKE ? AND i.status <> \'void\' AND i.due_date <= ?', [`RI-${r.uid}-%`, addDays(today, days)]); } catch (e) { bills = []; }
    for (const b of bills) {
      const owing = r2(b.owing !== undefined ? b.owing : b.total);
      if (owing > 0.004) out.push({ loanUid: r.uid, name: r.name, accountUid: l.payFromUid, invoiceUid: b.uid, due: b.due_date, amount: owing, overdue: b.due_date < today });
    }
  }
  return out.sort((a, b) => a.due.localeCompare(b.due));
}

// ---------------------------------------------------------------- statement words
// { contains, shop, mpaisa, drawings, toAccountUid, note }
export function statementWords() { return bankLinks().words; }
export function saveStatementWords(user, words) {
  requireLinker(user);
  return asService(() => {
    const accs = new Set(listAccountsWithKind({ includeInactive: true }).map((a) => a.uid));
    const clean = (words || []).map((w) => ({ contains: txt(w.contains).toUpperCase(), shop: txt(w.shop) || '', mpaisa: !!w.mpaisa, drawings: !!w.drawings,
      toAccountUid: accs.has(txt(w.toAccountUid)) ? txt(w.toAccountUid) : '', note: txt(w.note) || '' }))
      .filter((w) => w.contains && (w.shop || w.mpaisa || w.drawings || w.toAccountUid));
    const seen = new Set();
    for (const w of clean) { need(!seen.has(w.contains), `"${w.contains}" is there twice.`); seen.add(w.contains); }
    const L = bankLinks();
    L.words = clean;
    return saveLinks(user, L, `Bank statement words saved (${clean.length})`);
  });
}
// The usual BSP words for Easy Buys, offered with one tap (the owner can change them before saving).
export function suggestedWords() {
  let shops = [];
  try { shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort, code'); } catch (e) { shops = []; }
  const code = (n) => (shops.find((s) => s.code === `S${n}`) || {}).code || `S${n}`;
  return [
    { contains: 'SHOP 1', shop: code(1), note: 'Drasa Avenue' },
    { contains: 'S1', shop: code(1), note: 'Drasa Avenue (short)' },
    { contains: 'SHOP 3', shop: code(2), note: 'Kiran Palace – the old "Shop 3" on the bank' },
    { contains: 'SHOP 2', shop: 'CLOSED', note: 'V M Pillay (closed) – the old "Shop 2" on the bank' },
    { contains: 'CREDIT ADJUSTMENT', mpaisa: true, note: 'M-PAiSA money moved into the bank' },
  ];
}
const wordList = () => statementWords().slice().sort((a, b) => b.contains.length - a.contains.length);
const hasWordIn = (desc, w) => {
  const d = ` ${String(desc || '').toUpperCase().replace(/[^A-Z0-9]+/g, ' ')} `;
  const k = w.contains.replace(/[^A-Z0-9]+/g, ' ').trim();
  return k && d.includes(` ${k} `);
};
export function wordsFor(desc) { return wordList().filter((w) => hasWordIn(desc, w)); }
export function shopFromWords(desc) { const w = wordsFor(desc).find((x) => x.shop); return w ? w.shop : ''; }

// ---------------------------------------------------------------- moving money between our own accounts
// One move: out of one account and into the other (two bank lines, booked through "money on the way" so the books
// show it as a move, not a cost).
export function moveMoney(user, { fromUid, toUid, amount, date, reference, note, fromCleared, toCleared } = {}) {
  requirePerm(user, 'cheques_manage', { money: true });
  return asService(() => {
    need(fromUid && toUid && fromUid !== toUid, 'Choose two different accounts.');
    const from = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [fromUid]);
    const to = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [toUid]);
    need(from && to, 'Choose the accounts.');
    const a = r2(amount);
    need(a > 0, 'Enter the amount.');
    const d = txt(date) || dateStr();
    const ref = txt(reference) || `Move ${from.name} → ${to.name}`;
    const outUid = addBankEntry(user, { accountUid: fromUid, type: 'transfer_out', amount: a, date: d, reference: ref, note: txt(note) || `To ${to.name}`, clearedDate: fromCleared || null });
    const inUid = addBankEntry(user, { accountUid: toUid, type: 'deposit', amount: a, date: d, reference: ref, note: txt(note) || `From ${from.name}`, clearedDate: toCleared || null });
    db().run(`UPDATE bank_entries SET gl_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid IN (?, ?)`, [MOVING_GL, stamp(), deviceId(), outUid, inUid]);
    audit({ user, action: `Moved ${$(a)} from ${from.name} to ${to.name}`, table: 'bank_entries', recordUid: outUid });
    return { outUid, inUid };
  });
}

// ---------------------------------------------------------------- after a statement import
// Uses the links on the lines still open: moves to our own accounts, owner's money, M-PAiSA money in (from the shop
// named on the line), lines from before the app started, and the shop of every line.
export function applyLinks(user, statementUid) {
  requirePerm(user, 'bank_rec', { money: true });
  const out = { moves: 0, drawings: 0, mpaisa: 0, beforeApp: 0, shops: 0 };
  const st = db().get('SELECT * FROM bank_statements WHERE uid = ?', [statementUid]);
  if (!st) return out;
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [st.account_uid]);
  const lines = () => db().all('SELECT * FROM bank_lines WHERE statement_uid = ? ORDER BY line_date, amount', [statementUid]);
  let wallets = [];
  try { wallets = db().all('SELECT * FROM wallets WHERE active = 1'); } catch (e) { wallets = []; }
  for (const l of lines()) {
    // the shop written on the line
    const shop = shopFromWords(l.description);
    if (shop && !l.shop_code) { db().run('UPDATE bank_lines SET shop_code = ? WHERE uid = ?', [shop, l.uid]); out.shops += 1; }
    if (l.status !== 'unmatched') continue;
    // before the app started: already inside the opening balance
    if (acc && acc.opening_date && l.line_date < acc.opening_date) {
      try { ignoreLine(user, l.uid, `Before the app started (${acc.opening_date}) – inside the opening balance`); out.beforeApp += 1; } catch (e) { /* left open */ }
      continue;
    }
    const ws = wordsFor(l.description);
    const own = ownAccountIn(`${l.description || ''} ${l.reference || ''}`, l.account_uid) || (ws.find((w) => w.toAccountUid) ? db().get('SELECT * FROM bank_accounts WHERE uid = ?', [ws.find((w) => w.toAccountUid).toAccountUid]) : null);
    try {
      if (own) {
        if (l.amount < 0) {
          // money out to our own account: the move is recorded on both accounts (the other side waits for its statement)
          const m = moveMoney(user, { fromUid: l.account_uid, toUid: own.uid, amount: -l.amount, date: l.line_date, reference: l.description, fromCleared: l.line_date });
          matchLine(user, l.uid, { type: 'entry', uid: m.outUid });
          out.moves += 1; continue;
        }
        // money in from our own account: the move is matched when it was recorded on the other account first
        const e = db().get(`SELECT uid FROM bank_entries WHERE account_uid = ? AND status = 'active' AND type = 'deposit' AND cleared_date IS NULL AND ABS(amount - ?) < 0.005 AND gl_code = ? AND entry_date BETWEEN ? AND ? ORDER BY entry_date LIMIT 1`,
          [l.account_uid, l.amount, MOVING_GL, addDays(l.line_date, -7), l.line_date]);
        if (e) { matchLine(user, l.uid, { type: 'entry', uid: e.uid }); out.moves += 1; continue; }
        const m = moveMoney(user, { fromUid: own.uid, toUid: l.account_uid, amount: l.amount, date: l.line_date, reference: l.description, toCleared: l.line_date });
        matchLine(user, l.uid, { type: 'entry', uid: m.inUid });
        out.moves += 1; continue;
      }
      if (l.amount < 0 && ws.some((w) => w.drawings)) {
        createFromLine(user, l.uid, 'transfer_out', `Owner's money (drawings) – ${l.description || ''}`.trim());
        const m = db().get('SELECT match_uid FROM bank_lines WHERE uid = ?', [l.uid]);
        codeEntry(user, m.match_uid, DRAWINGS_GL);
        out.drawings += 1; continue;
      }
      if (l.amount > 0 && ws.some((w) => w.mpaisa)) {
        const s = shop || l.shop_code;
        const w = s ? wallets.filter((x) => x.shop_code === s) : [];
        if (w.length === 1) {
          const { mpaisaFromLine } = require('./importer.js');
          mpaisaFromLine(user, l.uid, w[0].uid);
          out.mpaisa += 1; continue;
        }
      }
    } catch (e) { /* left for the person to sort with one tap */ }
  }
  return out;
}

// A cheque the bank paid that was written before the app (not in the app, not in a book the app knows): recorded as
// written on the app's start date and cleared on the bank's date, so the books agree with the bank. Lines from before
// the start date are simply inside the opening balance.
export function chequeBeforeApp(user, lineUid, { payee } = {}) {
  requirePerm(user, ['payments_make', 'bank_rec'], { money: true });
  return asService(() => {
    const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid || '']);
    need(l && l.status === 'unmatched' && l.amount < 0, 'Line already dealt with.');
    const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [l.account_uid]);
    const no = Number((/(?:CHQ|CHEQUE|CHK)\s*#?\s*(\d{3,10})/i.exec(`${l.description || ''} ${l.reference || ''}`) || [])[1] || l.reference || 0);
    need(no > 0, 'This line has no cheque number.');
    need(!db().get('SELECT 1 AS x FROM cheques WHERE account_uid = ? AND cheque_no = ?', [l.account_uid, no]), `Cheque ${no} is already in the app.`);
    if (acc.opening_date && l.line_date < acc.opening_date) { ignoreLine(user, l.uid, `Cheque ${no} – before the app started`); return null; }
    const d = acc.opening_date && acc.opening_date <= l.line_date ? acc.opening_date : l.line_date;
    const uid = `CQ-OLD-${l.account_uid}-${no}`;
    const now = stamp(); const dev = deviceId();
    db().run(`INSERT INTO cheques (uid, account_uid, cheque_no, cheque_date, payee, amount, status, memo, written_by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,'written',?,?,?,?)`,
      [uid, l.account_uid, no, d, txt(payee) || 'Written before the app', r2(-l.amount), 'Written before the app – found on the bank statement', user.name, now, dev]);
    audit({ user, action: `Cheque ${no} (${$(-l.amount)}) added – written before the app`, table: 'cheques', recordUid: uid });
    matchLine(user, l.uid, { type: 'cheque', uid });
    return uid;
  });
}
// Every unknown cheque on a statement in one go (each needs the same answer: written before the app).
export function allChequesBeforeApp(user, statementUid) {
  requirePerm(user, ['payments_make', 'bank_rec'], { money: true });
  let n = 0;
  for (const l of db().all("SELECT * FROM bank_lines WHERE statement_uid = ? AND status = 'unmatched' AND amount < 0", [statementUid])) {
    if (!/unknown_cheque/.test(l.flags || '')) continue;
    if (/already cleared|recorded as/i.test(l.flags || '')) continue;
    try { if (chequeBeforeApp(user, l.uid, {})) n += 1; } catch (e) { /* left open */ }
  }
  return n;
}

// The starting balance from a statement: what the bank had at the start of the app's first day.
export function bankBalanceAt(statementUid, date) {
  const st = db().get('SELECT * FROM bank_statements WHERE uid = ?', [statementUid || '']);
  need(st, 'Statement not found.');
  need(st.opening !== null && st.opening !== undefined, 'This statement has no opening balance.');
  need(date >= st.from_date && date <= addDays(st.to_date, 1), `The statement covers ${st.from_date} to ${st.to_date}.`);
  const before = db().get('SELECT IFNULL(SUM(amount),0) AS s FROM bank_lines WHERE statement_uid = ? AND line_date < ?', [statementUid, date]).s;
  return r2(Number(st.opening) + before);
}
export function setOpeningFromStatement(user, statementUid, date) {
  requireLinker(user);
  return asService(() => {
    const st = db().get('SELECT * FROM bank_statements WHERE uid = ?', [statementUid || '']);
    need(st, 'Statement not found.');
    const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [st.account_uid]);
    const d = txt(date) || acc.opening_date;
    const bal = bankBalanceAt(statementUid, d);
    db().run(`UPDATE bank_accounts SET opening_balance = ?, opening_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [bal, d, stamp(), deviceId(), acc.uid]);
    audit({ user, action: `${acc.name}: starting balance ${$(bal)} on ${d} (from the bank statement)`, table: 'bank_accounts', recordUid: acc.uid, before: { opening_balance: acc.opening_balance, opening_date: acc.opening_date }, after: { opening_balance: bal, opening_date: d } });
    return { balance: bal, date: d };
  });
}

// Release 05: records on this device the cloud does not have (e.g. cheque books added on a phone that never reached
// the website). The owner sends this device's bank accounts, cheque books and cheques again: each one is stamped now
// so the cloud takes it (the cloud refuses records older than a fresh start). Only the owner / an admin.
export const RESEND_TABLES = ['bank_accounts', 'cheque_books', 'cheques'];
export function resendBankRecords(user) {
  requireLinker(user);
  return asService(() => {
    const now = stamp(); const dev = deviceId();
    const out = {};
    for (const t of RESEND_TABLES) {
      if (!has(t)) { out[t] = 0; continue; }
      const n = db().get(`SELECT COUNT(*) AS c FROM ${t}`).c;
      db().run(`UPDATE ${t} SET updated_at = ?, updated_device = ?, sync_status = 'pending'`, [now, dev]);
      out[t] = n;
    }
    audit({ user, action: `Sent this device's bank accounts (${out.bank_accounts}), cheque books (${out.cheque_books}) and cheques (${out.cheques}) to the cloud again`, table: 'bank_accounts', recordUid: 'resend' });
    return out;
  });
}
