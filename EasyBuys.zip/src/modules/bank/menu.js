// Bank, cash and M-PAiSA menu.
const W = ['wallets', 'bank_rec'];
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🏦', title: 'Bank reconciliation', note: 'In the bank now, expected balance, cheques and deposits waiting.', screen: 'BankRec' },
    { id: 'bank-check', icon: '📱', title: 'Check against mobile banking', note: 'Type the balance from the BSP app.', screen: 'BankCheck' },
    { id: 'bank-import', icon: '📥', title: 'Import a bank statement', note: 'BSP CSV, OFX, PDF or pasted text – mid-month too.', screen: 'BankImport' },
    { id: 'bank-wallets', icon: '📲', title: 'M-PAiSA wallets', note: 'Sales in, transfers to BSP, fees, check against the app.', screen: 'Wallets', perm: W },
    { id: 'bank-move', icon: '🔁', title: 'Move money between accounts', note: 'Cheque account → Visa debit, and back.', screen: 'MoveMoney', perm: 'cheques_manage' },
    { id: 'bank-new', icon: '➕', title: 'Type a bank statement', note: 'Type or paste the lines by hand.', screen: 'StatementNew' },
  ] },
  { section: 'Records', items: [
    { id: 'bank-history', icon: '📜', title: 'Bank history', note: 'Every line with the running balance; search.', screen: 'BankHistory' },
    { id: 'bank-checks', icon: '🗒️', title: 'Balance checks', note: 'Every check against mobile banking and the M-PAiSA app.', screen: 'BankChecks', perm: W },
    { id: 'bank-archive', icon: '🗄️', title: 'Statement archive', note: 'Bank and M-PAiSA statements, reconciliation reports.', screen: 'BankArchive' },
  ] },
  { section: 'Checks', items: [
    { id: 'mpaisa-import', icon: '📄', title: 'Import an M-PAiSA statement', note: 'CSV, Excel, PDF or a screenshot.', screen: 'MpaisaImport', perm: W },
    { id: 'mpaisa-match', icon: '🔎', title: 'M-PAiSA sales against the wallet', note: 'Each shift\'s M-PAiSA sales against what was received.', screen: 'MpaisaMatch', perm: W },
    { id: 'bank-month', icon: '✅', title: 'Bank month end', note: 'Full statement, balance agrees, every line sorted, report saved.', screen: 'BankMonthEnd' },
  ] },
  { section: 'Reports', items: [
    { id: 'bank-reports', icon: '📊', title: 'Bank reports', note: 'Reconciliation, bank charges, balance checks, wallets, history.', screen: 'ReportsHub', params: { group: 'Bank' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    // Release 05 (owner: "under Settings › Bank I don't see a place to add a bank account")
    { id: 'bank-accounts', icon: '🏦', title: 'Bank accounts & cheque books', note: 'Add a bank account, its cheque books, opening balance.', screen: 'Cheques', params: { tab: 'accounts' }, perm: 'cheques_manage' },
    { id: 'bank-links', icon: '🔗', title: 'How the accounts connect', note: 'Cheque, Visa debit, loans paid from which account, the words on the statement (owner / admin).', screen: 'BankLinks' },
    { id: 'bank-rules', icon: '⚙️', title: 'Bank rules', note: 'Verification days, mobile banking reminder, EFTPOS, lines coded by themselves.', screen: 'BankRules' },
    { id: 'wallet-setup', icon: '👛', title: 'Wallets (money accounts)', note: 'The M-PAiSA wallets; add MyCash later.', screen: 'WalletSetup' },
    { id: 'mpaisa-columns', icon: '🧩', title: 'M-PAiSA statement columns', note: 'Which column is the date, amount…', screen: 'MpaisaColumns' },
  ] },
];
