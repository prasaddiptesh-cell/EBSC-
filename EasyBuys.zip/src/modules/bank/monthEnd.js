// Month-end bank closing: full-month statement, balance equals the statement, every line sorted, warnings reviewed,
// M-PAiSA statements in and every shift matched, then the reconciliation report is saved as a document.
// Also the bank reports: reconciliation report, bank charges, balance checks, wallets.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, money } from '../../services/core.js';
import { balanceCheck } from '../payables/service.js';
import { moneyPosition, mainAccount, TONE_LABEL, listChecks, bankHistory } from './position.js';
import { flaggedLines, lineFlags } from './importer.js';
import { listWallets, shiftMatch, walletPosition, walletHistory, MATCH_LABEL } from './wallets.js';
import { requirePerm, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
export const monthRange = (ym) => {
  const from = `${ym}-01`;
  const [y, m] = ym.split('-').map(Number);
  const to = addDays(m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`, -1);
  return { from, to };
};
export const lastMonth = (today = dateStr()) => { const [y, m] = today.split('-').map(Number); return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`; };

// Statement balance at a date: the closing of the statement ending that day, or worked back from a later one.
export function statementBalanceAt(accountUid, date) {
  const st = db().get("SELECT * FROM bank_statements WHERE account_uid = ? AND status <> 'void' AND from_date <= ? AND to_date >= ? ORDER BY to_date ASC, created_at DESC LIMIT 1", [accountUid, date, date]);
  if (!st) return null;
  const after = db().get('SELECT IFNULL(SUM(amount),0) AS s FROM bank_lines WHERE account_uid = ? AND line_date > ? AND line_date <= ? AND statement_uid IN (SELECT uid FROM bank_statements WHERE account_uid = ? AND status <> \'void\')', [accountUid, date, st.to_date, accountUid]).s;
  return { statement: st, balance: r2(st.closing - after) };
}
// Every day of the month is on an imported statement (mid-month imports add up).
export function coverage(accountUid, from, to) {
  const sts = db().all("SELECT from_date, to_date FROM bank_statements WHERE account_uid = ? AND status <> 'void' AND NOT (to_date < ? OR from_date > ?) ORDER BY from_date", [accountUid, from, to]);
  let next = from;
  for (const s of sts) { if (s.from_date > next) break; if (s.to_date >= next) next = addDays(s.to_date, 1); }
  return { complete: next > to, missingFrom: next > to ? null : next };
}

export function bankMonthEnd(ym, accountUid = (mainAccount() || {}).uid) {
  const { from, to } = monthRange(ym);
  const acc = accountUid ? db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid]) : null;
  if (!acc) return { ym, from, to, items: [], ready: false, closed: null, account: null };
  const cov = coverage(acc.uid, from, to);
  const sb = statementBalanceAt(acc.uid, to);
  let check = null;
  if (sb) { try { check = balanceCheck(acc.uid, to, sb.balance); } catch (e) { check = null; } }
  const unsorted = db().get("SELECT COUNT(*) AS n FROM bank_lines WHERE account_uid = ? AND status = 'unmatched' AND line_date BETWEEN ? AND ?", [acc.uid, from, to]).n;
  const flagged = flaggedLines({ accountUid: acc.uid, from, to }).length;
  const wallets = listWallets().map((w) => {
    const days = shiftMatch(w.uid, from, to);
    const imp = db().get("SELECT 1 AS x FROM wallet_imports WHERE wallet_uid = ? AND status = 'active' AND from_date <= ? AND to_date >= ?", [w.uid, from, to])
      || (() => { const list = db().all("SELECT from_date, to_date FROM wallet_imports WHERE wallet_uid = ? AND status = 'active' AND NOT (to_date < ? OR from_date > ?) ORDER BY from_date", [w.uid, from, to]); let n = from; for (const s of list) { if (s.from_date > n) break; if (s.to_date >= n) n = addDays(s.to_date, 1); } return n > to; })();
    const hasSales = days.some((d) => d.dayTill > 0);
    return { wallet: w, statement: !!imp || !hasSales, problems: days.filter((d) => ['short', 'over'].includes(d.status)).length,
      unsorted: db().get("SELECT COUNT(*) AS n FROM wallet_lines WHERE wallet_uid = ? AND status = 'unmatched' AND line_date BETWEEN ? AND ?", [w.uid, from, to]).n };
  });
  const closed = db().get("SELECT * FROM bank_closings WHERE ym = ? AND account_uid = ? AND status = 'active' ORDER BY closed_at DESC LIMIT 1", [ym, acc.uid]);
  const items = [
    { key: 'statement', label: 'Full-month BSP statement imported', ok: cov.complete, note: cov.complete ? '' : `Days from ${cov.missingFrom} are not on an imported statement.` },
    { key: 'balance', label: 'App balance equals the statement at the month end', ok: !!(check && check.balanced), note: !sb ? 'No statement for the last day yet.' : check && !check.balanced ? `Out by ${$(check.difference)}.` : '' },
    { key: 'sorted', label: 'Every statement line sorted', ok: unsorted === 0, note: unsorted ? `${unsorted} line(s) still to match.` : '' },
    { key: 'warnings', label: 'Every warning reviewed', ok: flagged === 0, note: flagged ? `${flagged} warning(s) to look at.` : '' },
    { key: 'mpaisa', label: 'M-PAiSA statements in, every shift matched, every line sorted', ok: wallets.every((w) => w.statement && !w.problems && !w.unsorted),
      note: wallets.filter((w) => !w.statement || w.problems || w.unsorted).map((w) => `${w.wallet.name}: ${!w.statement ? 'statement missing' : ''}${w.problems ? ` ${w.problems} day(s) not matching` : ''}${w.unsorted ? ` ${w.unsorted} line(s) to sort` : ''}`.trim()).join('; ') },
  ];
  const ready = items.every((i) => i.ok);
  items.push({ key: 'report', label: 'Reconciliation report saved', ok: !!closed, note: closed ? `Saved by ${closed.by_name} ${String(closed.closed_at).slice(0, 10)}` : ready ? 'Ready – save the report.' : 'After the steps above.' });
  return { ym, from, to, account: acc, items, ready, closed, statementBalance: sb ? sb.balance : null, check, wallets };
}
// Saving the report closes the bank for the month (the PDF is kept in the documents as docUid).
export function closeBankMonth(user, ym, accountUid, docUid) {
  requirePerm(user, 'accounts_close', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const m = bankMonthEnd(ym, accountUid);
  need(m.account, 'Choose the bank account.');
  need(m.ready, `Not ready yet: ${m.items.filter((i) => !i.ok && i.key !== 'report').map((i) => i.label).join(', ')}.`);
  const now = stamp();
  const uid = uuid('BK');
  db().run(`INSERT INTO bank_closings (uid, ym, account_uid, statement_uid, closing, expected, difference, doc_uid, by_name, closed_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, ym, m.account.uid, m.check ? null : null, m.statementBalance, m.check ? m.check.expected : null, m.check ? m.check.difference : null, docUid || null, user.name, now, now, deviceId()]);
  audit({ user, action: `Bank closed for ${ym} – reconciliation report saved`, table: 'bank_closings', recordUid: uid });
  return uid;
  });
}
// Lines for the accounting month-end checklist ({ key, label, left }).
export function bankMonthEndItems(ym) {
  const m = bankMonthEnd(ym);
  if (!m.account) return [];
  return m.items.map((i) => ({ key: `bank35_${i.key}`, label: `Bank: ${i.label}`, left: i.ok ? 0 : 1 }));
}

// ---------------------------------------------------------------- reports
export function reconciliationReport(from, to, accountUid = (mainAccount() || {}).uid) {
  const acc = accountUid ? db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid]) : null;
  if (!acc) return { kind: 'bank_rec35', title: 'Bank Reconciliation', fileName: `Bank-Reconciliation-${to}`, subtitle: 'No bank account yet', info: [], summary: [], sections: [] };
  const p = moneyPosition(acc.uid, to);
  const sb = statementBalanceAt(acc.uid, to);
  const diff = sb ? r2(sb.balance - p.inBank) : null;
  const item = (x, sign) => ({ date: x.date, what: x.label, shop: x.shop || 'Whole business', age: `${x.age} days`, state: TONE_LABEL[x.tone], amount: `${sign}${$(x.amount)}`, _tone: x.tone === 'amber' ? 'warn' : 'bad' });
  const lines = db().all('SELECT * FROM bank_lines WHERE account_uid = ? AND line_date BETWEEN ? AND ? ORDER BY line_date, amount', [acc.uid, from, to]);
  const flags = lines.filter((l) => lineFlags(l).length);
  const ym = to.slice(0, 7);
  const me = bankMonthEnd(ym, acc.uid);
  const wallets = listWallets().map((w) => { const wp = walletPosition(w.uid, to); return { name: w.name, shop: w.shop_code, sales: $(wp.sales), out: $(wp.outs), balance: $(wp.balance), transit: $(wp.transitTotal) }; });
  return {
    kind: 'bank_rec35', title: 'Bank Reconciliation', fileName: `Bank-Reconciliation-${acc.name.replace(/\W+/g, '-')}-${to}`, subtitle: `${acc.name} · ${from} to ${to}`,
    info: [['Account', `${acc.name}${acc.account_no ? ` (${acc.account_no})` : ''}`], ['Period', `${from} to ${to}`], ['Statement balance at the end', sb ? $(sb.balance) : 'no statement yet'], ['Generated', stamp()]],
    summary: [
      { label: 'In the bank now', value: $(p.inBank) }, { label: 'Expected balance', value: $(p.expected) },
      { label: 'Statement shows', value: sb ? $(sb.balance) : '—' }, { label: 'Difference', value: diff === null ? '—' : $(diff), tone: diff === null ? undefined : Math.abs(diff) < 0.005 ? 'good' : 'bad' },
    ],
    sections: [
      { title: 'How the balances agree', columns: [col('what', 'Item'), col('amount', 'Amount', R)], rows: [
        { what: 'Cheque-book balance (everything recorded)', amount: $(p.book) }, { what: '+ Cheques not yet presented', amount: $(p.chequesOut) },
        { what: '− Deposits / transfers not yet cleared', amount: $(p.insTotal) }, { what: '+ Fees / debits not yet on the statement', amount: $(p.outsTotal) },
        { what: '= In the bank now', amount: $(p.inBank) }, { what: 'Expected balance (after the items above clear)', amount: $(p.expected) }] },
      { title: 'Cheques not yet presented', columns: [col('date', 'Date'), col('what', 'Cheque'), col('shop', 'Shop'), col('age', 'Age'), col('state', 'State'), col('amount', 'Amount', R)], rows: p.cheques.map((c) => item(c, '−')) },
      { title: 'Deposits and transfers not yet cleared (in transit)', columns: [col('date', 'Date'), col('what', 'Deposit'), col('shop', 'Shop'), col('age', 'Age'), col('state', 'State'), col('amount', 'Amount', R)], rows: p.ins.map((c) => item(c, '+')) },
      { title: 'Other items not yet on the statement', columns: [col('date', 'Date'), col('what', 'Item'), col('shop', 'Shop'), col('age', 'Age'), col('state', 'State'), col('amount', 'Amount', R)], rows: p.outs.map((c) => item(c, '−')) },
      { title: 'Statement lines in the period', columns: [col('date', 'Date'), col('what', 'Description'), col('shop', 'Shop'), col('state', 'Sorted'), col('amount', 'Amount', R)],
        rows: lines.map((l) => ({ date: l.line_date, what: l.description || '', shop: l.shop_code || '', state: l.status === 'matched' ? `matched (${l.match_type})` : l.status === 'ignored' ? `put aside: ${l.note || ''}` : 'NOT SORTED', amount: $(l.amount), _tone: l.status === 'unmatched' ? 'bad' : null })) },
      { title: 'Warnings on the statement', columns: [col('date', 'Date'), col('what', 'Warning'), col('state', 'Reviewed')], rows: flags.map((l) => ({ date: l.line_date, what: lineFlags(l).map((f) => f.text).join(' '), state: l.flags_ok_by || (l.status === 'matched' ? 'sorted' : 'not yet') })) },
      { title: 'M-PAiSA wallets', columns: [col('name', 'Wallet'), col('shop', 'Shop'), col('sales', 'Till M-PAiSA sales', R), col('out', 'Transfers & fees', R), col('balance', 'Balance', R), col('transit', 'On the way to BSP', R)], rows: wallets },
      { title: 'Month-end checklist', columns: [col('what', 'Step'), col('state', 'Done'), col('note', 'Note')], rows: me.items.map((i) => ({ what: i.label, state: i.ok ? 'Yes' : 'No', note: i.note || '', _tone: i.ok ? 'good' : 'warn' })) },
    ],
  };
}
// 11: bank charges (bank fees and M-PAiSA fees) by month and by kind.
export function bankChargesReport(from, to) {
  const fees = db().all("SELECT e.entry_date AS d, e.amount, COALESCE(e.reference, e.note, 'Bank fee') AS what, b.name AS acct FROM bank_entries e JOIN bank_accounts b ON b.uid = e.account_uid WHERE e.status = 'active' AND e.type = 'fee' AND e.entry_date BETWEEN ? AND ? ORDER BY e.entry_date", [from, to]);
  let wfees = [];
  try { wfees = db().all("SELECT m.move_date AS d, m.amount, COALESCE(m.note, m.reference, 'Fee') AS what, w.name AS acct FROM wallet_moves m JOIN wallets w ON w.uid = m.wallet_uid WHERE m.status = 'active' AND m.type = 'fee' AND m.move_date BETWEEN ? AND ? ORDER BY m.move_date", [from, to]); } catch (e) { wfees = []; }
  const all = fees.concat(wfees).sort((a, b) => (a.d < b.d ? -1 : 1));
  const byMonth = {};
  all.forEach((f) => { const k = `${f.d.slice(0, 7)}|${f.acct}`; byMonth[k] = r2((byMonth[k] || 0) + f.amount); });
  const total = r2(all.reduce((s, f) => s + f.amount, 0));
  return { kind: 'bank_charges', title: 'Bank Charges', fileName: `Bank-Charges-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`,
    info: [['Period', `${from} to ${to}`], ['Generated', stamp()]], summary: [{ label: 'Total charges', value: $(total), tone: total > 0 ? 'bad' : undefined }, { label: 'Charges', value: String(all.length) }],
    sections: [{ title: 'By month', columns: [col('month', 'Month'), col('acct', 'Account'), col('amount', 'Charges', R)], rows: Object.entries(byMonth).map(([k, v]) => ({ month: k.split('|')[0], acct: k.split('|')[1], amount: $(v) })) },
      { title: 'Every charge', columns: [col('d', 'Date'), col('acct', 'Account'), col('what', 'What'), col('amount', 'Amount', R)], rows: all.map((f) => ({ ...f, amount: $(f.amount) })) }] };
}
export function balanceChecksReport(from, to) {
  const rows = db().all('SELECT * FROM bank_checks WHERE check_date BETWEEN ? AND ? ORDER BY check_date DESC, checked_at DESC', [from, to]).map((c) => {
    const name = c.account_kind === 'bank' ? (db().get('SELECT name FROM bank_accounts WHERE uid = ?', [c.account_uid]) || {}).name : (db().get('SELECT name FROM wallets WHERE uid = ?', [c.account_uid]) || {}).name;
    return { date: c.check_date, acct: name || '', typed: $(c.typed_balance), app: $(c.app_balance), diff: $(c.diff), by: c.by_name, note: c.note || '', _tone: c.result === 'match' ? 'good' : 'bad' };
  });
  return { kind: 'bank_checks', title: 'Balance Checks', fileName: `Balance-Checks-${from}-to-${to}`, subtitle: `Mobile banking and M-PAiSA app checks · ${from} to ${to}`,
    info: [['Period', `${from} to ${to}`], ['Generated', stamp()]], summary: [{ label: 'Checks', value: String(rows.length) }, { label: 'Matched', value: String(rows.filter((r) => r._tone === 'good').length), tone: 'good' }],
    sections: [{ title: 'Checks', columns: [col('date', 'Date'), col('acct', 'Account'), col('typed', 'App showed', R), col('app', 'Easy Buys said', R), col('diff', 'Difference', R), col('by', 'By'), col('note', 'Note')], rows }] };
}
export function walletsReport(from, to) {
  const sections = [];
  for (const w of listWallets()) {
    const days = shiftMatch(w.uid, from, to);
    sections.push({ title: `${w.name} – shifts against receipts`, columns: [col('date', 'Date'), col('shift', 'Shift / till'), col('till', 'Till says', R), col('wallet', 'Wallet got', R), col('diff', 'Difference', R), col('state', 'Result')],
      rows: days.flatMap((d) => (d.perShift && d.shifts.length ? d.shifts.map((s) => ({ date: d.date, shift: `${s.till} ${s.shift}`, till: $(s.tillAmount), wallet: $(s.walletAmount), diff: $(s.diff), state: MATCH_LABEL[s.status], _tone: ['short', 'over'].includes(s.status) ? 'bad' : null }))
        : [{ date: d.date, shift: 'Whole day', till: $(d.dayTill), wallet: $(d.dayWallet), diff: $(d.dayDiff), state: MATCH_LABEL[d.status], _tone: ['short', 'over'].includes(d.status) ? 'bad' : null }])) });
    sections.push({ title: `${w.name} – history`, columns: [col('date', 'Date'), col('what', 'What'), col('sub', 'Details'), col('amount', 'Amount', R), col('balance', 'Balance', R)],
      rows: walletHistory(w.uid, { from, to }).rows.map((r) => ({ date: r.date, what: r.what, sub: r.sub || '', amount: $(r.amount), balance: $(r.balance) })) });
  }
  return { kind: 'wallets', title: 'M-PAiSA Wallets', fileName: `M-PAiSA-Wallets-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`, info: [['Period', `${from} to ${to}`], ['Generated', stamp()]],
    summary: listWallets().map((w) => ({ label: w.name, value: $(walletPosition(w.uid, to).balance) })), sections };
}
export function bankHistoryReport(from, to) {
  const acc = mainAccount();
  const h = acc ? bankHistory(acc.uid, { from, to }) : { rows: [], opening: 0 };
  return { kind: 'bank_history', title: 'Bank History', fileName: `Bank-History-${from}-to-${to}`, subtitle: `${acc ? acc.name : ''} · ${from} to ${to}`, info: [['Period', `${from} to ${to}`], ['Opening balance', $(h.opening)], ['Generated', stamp()]],
    summary: [{ label: 'Lines', value: String(h.rows.length) }],
    sections: [{ title: 'History', columns: [col('date', 'Date'), col('what', 'What'), col('party', 'Payee / note'), col('shop', 'Shop'), col('cleared', 'Cleared'), col('amount', 'Amount', R), col('balance', 'Balance', R)],
      rows: h.rows.slice().reverse().map((r) => ({ date: r.date, what: `${r.what}${r.ref && !r.what.includes(r.ref) ? ` ${r.ref}` : ''}`, party: r.party, shop: r.shop || '', cleared: r.cleared ? `✓ ${r.cleared}${r.clearedBy ? ` ${r.clearedBy}` : ''}` : '', amount: $(r.amount), balance: $(r.balance) })) }] };
}
export { listChecks };
