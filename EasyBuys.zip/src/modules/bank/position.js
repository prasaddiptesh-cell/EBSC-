// v3.5 bank position: the bank rules (admin), the two balances ("In the bank now" and "Expected balance"),
// cheques not yet presented and deposits not yet cleared with their age colour, the bank history with a running
// balance, lines tagged by shop, and "Check against mobile banking" with its history and reminder.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { bookBalance, apRules } from '../payables/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const IN_TYPES = ['deposit', 'interest', 'adjust_in'];

// ---------------------------------------------------------------- bank rules (Admin › Bank rules)
export const BANK35_DEFAULTS = {
  verifyDays: 7,            // cheques not presented / deposits not cleared: amber, then red after this many days
  mobileCheckOn: true,      // Home reminder to check the balance against BSP mobile banking
  mobileCheckDays: 3,       // … after this many days without a check
  walletCheckOn: true,      // the same for each M-PAiSA wallet against the M-PAiSA app
  walletCheckDays: 3,
  eftposOn: false,          // EFTPOS is not used yet: expected settlements switched off
  eftposDays: 2,            // days until the bank pays the card takings
  eftposFeePct: 0,          // % the bank keeps
  autoFees: true,           // statement import books bank fees and interest by itself
  feeWords: 'FEE, FEES, CHARGE, CHARGES, SERVICE FEE, GOVT DUTY, STAMP DUTY, COMMISSION, LEDGER FEE',
  interestWords: 'INTEREST, INT PAID, CREDIT INT',
  feeGl: '6600',
  interestGl: '4900',
  unusualAmount: 5000,      // a statement line this big is flagged as unusual
  unusualTimes: 3,          // … or this many times the usual amount for the same payee
  slipTolerance: 50,        // a deposit this close to a slip is shown as a "slip difference"
  mpaisaWords: 'MPAISA, M-PAISA, M PAISA, VODAFONE, MYCASH',
};
export function bankSettings() {
  return { ...BANK35_DEFAULTS, ...(getShared('bank_settings', {}) || {}) };
}
export function saveBankSettings(user, s) {
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const clean = {
    verifyDays: Math.round(n(s.verifyDays, 1, 90, 'Verification days')),
    mobileCheckOn: !!s.mobileCheckOn, mobileCheckDays: Math.round(n(s.mobileCheckDays, 1, 60, 'Reminder days')),
    walletCheckOn: !!s.walletCheckOn, walletCheckDays: Math.round(n(s.walletCheckDays, 1, 60, 'Wallet reminder days')),
    eftposOn: !!s.eftposOn, eftposDays: Math.round(n(s.eftposDays, 0, 14, 'EFTPOS days')), eftposFeePct: n(s.eftposFeePct, 0, 10, 'EFTPOS fee %'),
    autoFees: !!s.autoFees, feeWords: txt(s.feeWords) || BANK35_DEFAULTS.feeWords, interestWords: txt(s.interestWords) || BANK35_DEFAULTS.interestWords,
    feeGl: txt(s.feeGl) || BANK35_DEFAULTS.feeGl, interestGl: txt(s.interestGl) || BANK35_DEFAULTS.interestGl,
    unusualAmount: n(s.unusualAmount, 0, 10000000, 'Unusual amount'), unusualTimes: n(s.unusualTimes, 1, 100, 'Unusual times'),
    slipTolerance: n(s.slipTolerance, 0, 100000, 'Slip difference'), mpaisaWords: txt(s.mpaisaWords) || BANK35_DEFAULTS.mpaisaWords,
  };
  const before = bankSettings();
  setShared('bank_settings', clean);
  audit({ user, action: 'Changed bank rules', table: 'shared_settings', recordUid: 'bank_settings', before, after: clean });
  return clean;
}
export const words = (list) => String(list || '').split(',').map((w) => w.trim().toUpperCase()).filter(Boolean);
export const hasWord = (text, list) => { const t = ` ${String(text || '').toUpperCase().replace(/[^A-Z0-9 -]/g, ' ')} `; return words(list).some((w) => t.includes(` ${w} `) || (w.length > 4 && t.includes(w))); };

// ---------------------------------------------------------------- the one BSP account
export function mainAccount() {
  return db().get('SELECT * FROM bank_accounts WHERE active = 1 ORDER BY sort, name LIMIT 1') || null;
}

// ---------------------------------------------------------------- age colour
export function daysBetween(a, b) {
  const t = (d) => { const [y, m, x] = String(d).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, x); };
  return Math.round((t(b) - t(a)) / 86400000);
}
const minusMonths = (d, m) => { const [y, mo, x] = d.split('-').map(Number); const z = new Date(Date.UTC(y, mo - 1 - m, x)); return z.toISOString().slice(0, 10); };
// 'amber' (waiting, normal) → 'red' (older than the Verification days) → 'stale' (older than 6 months, Invoice rules).
export function ageTone(date, today = dateStr(), s = bankSettings()) {
  if (date <= minusMonths(today, apRules().staleMonths || 6)) return 'stale';
  return daysBetween(date, today) > s.verifyDays ? 'red' : 'amber';
}
export const TONE_LABEL = { amber: 'waiting', red: 'overdue – check', stale: 'STALE (over 6 months)' };

// ---------------------------------------------------------------- shop tags
export function chequeShop(c) {
  if (c.shop_code) return c.shop_code;
  if (!c.payment_uid) return null;
  const s = db().all(`SELECT DISTINCT i.shop_code AS s FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = ? AND i.shop_code IS NOT NULL AND i.shop_code <> ''`, [c.payment_uid]);
  return s.length === 1 ? s[0].s : null;
}
export function entryShop(e) {
  if (e.shop_code) return e.shop_code;
  const d = db().get('SELECT shop_code FROM deposits WHERE bank_entry_uid = ?', [e.uid]);
  if (d) return d.shop_code;
  if (has('wallet_moves')) {
    const w = db().get('SELECT w.shop_code FROM wallet_moves m JOIN wallets w ON w.uid = m.wallet_uid WHERE m.bank_entry_uid = ?', [e.uid]);
    if (w) return w.shop_code;
  }
  return null;
}
// Tag a bank history line (cheque or entry) or a statement line with the shop it belongs to ('' = whole business).
export function tagShop(user, kind, uid, shop) {
  const table = kind === 'cheque' ? 'cheques' : kind === 'line' ? 'bank_lines' : 'bank_entries';
  const row = db().get(`SELECT * FROM ${table} WHERE uid = ?`, [uid]);
  need(row, 'Not found.');
  db().run(`UPDATE ${table} SET shop_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(shop) || null, stamp(), deviceId(), uid]);
  audit({ user, action: `Bank line tagged ${txt(shop) || 'whole business'}`, table, recordUid: uid, before: { shop: row.shop_code }, after: { shop: txt(shop) || null } });
}

// ---------------------------------------------------------------- EFTPOS expected settlements (switched off for now)
export function eftposExpected(accountUid, asOf = dateStr(), s = bankSettings()) {
  if (!s.eftposOn || !has('till_counts')) return [];
  const out = [];
  for (const c of db().all("SELECT uid, shop_code, shift_date, shift, till_name, tenders FROM till_counts WHERE status <> 'void' AND shift_date <= ? AND shift_date >= ?", [asOf, addDays(asOf, -60)])) {
    const amt = r2(J(c.tenders, []).filter((t) => /eftpos|card/i.test(t.method || '')).reduce((t, x) => t + r2(x.amount), 0));
    if (amt <= 0) continue;
    if (db().get("SELECT 1 AS x FROM bank_entries WHERE uid = ? AND status = 'active'", [`BE-EFT-${c.uid}`])) continue;
    out.push({ kind: 'eftpos', uid: c.uid, date: addDays(c.shift_date, s.eftposDays), label: `EFTPOS ${c.shop_code} ${c.till_name || ''} ${c.shift || ''} ${c.shift_date}`, amount: r2(amt * (1 - s.eftposFeePct / 100)), shop: c.shop_code });
  }
  return out;
}

// ---------------------------------------------------------------- the two balances
// In the bank now = what the bank holds (cleared items only). Expected balance = after every cheque not yet
// presented and every deposit not yet cleared (the cheque-book balance), plus EFTPOS settlements when switched on.
export function moneyPosition(accountUid, asOf = dateStr()) {
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid || '']);
  if (!acc) return null;
  const s = bankSettings();
  const book = bookBalance(accountUid, asOf);
  const chq = db().all(`SELECT * FROM cheques WHERE account_uid = ? AND cheque_date <= ? AND cheque_date >= ? AND (status = 'written' OR (status = 'presented' AND presented_date > ?)) ORDER BY cheque_date, cheque_no`, [accountUid, asOf, acc.opening_date, asOf]);
  const ents = db().all(`SELECT * FROM bank_entries WHERE account_uid = ? AND status = 'active' AND entry_date <= ? AND entry_date >= ? AND (cleared_date IS NULL OR cleared_date > ?) ORDER BY entry_date`, [accountUid, asOf, acc.opening_date, asOf]);
  const deco = (x) => ({ ...x, tone: ageTone(x.date, asOf, s), age: daysBetween(x.date, asOf) });
  const cheques = chq.map((c) => deco({ kind: 'cheque', uid: c.uid, date: c.cheque_date, no: c.cheque_no, label: `Cheque ${c.cheque_no}${c.payee ? ` · ${c.payee}` : ''}`, amount: r2(c.amount), shop: chequeShop(c) }));
  const ins = []; const outs = [];
  for (const e of ents) {
    const dep = db().get('SELECT slip_no, shop_code FROM deposits WHERE bank_entry_uid = ?', [e.uid]);
    const x = deco({ kind: 'entry', uid: e.uid, type: e.type, date: e.entry_date, label: `${dep ? `Deposit slip ${dep.slip_no}` : `${{ deposit: 'Deposit', interest: 'Interest', adjust_in: 'Correction +', fee: 'Bank fee', transfer_out: 'Transfer out', adjust_out: 'Correction −' }[e.type] || e.type}${e.reference ? ` · ${e.reference}` : ''}`}`, note: e.note, amount: r2(e.amount), shop: entryShop(e), transit: !!dep || e.uid.startsWith('BE-WT-') });
    (IN_TYPES.includes(e.type) ? ins : outs).push(x);
  }
  const eft = eftposExpected(accountUid, asOf, s).map(deco);
  const sum = (l) => r2(l.reduce((t, x) => t + x.amount, 0));
  const chequesOut = sum(cheques); const insTotal = sum(ins); const outsTotal = sum(outs); const eftTotal = sum(eft);
  const inBank = r2(book.balance + chequesOut - insTotal + outsTotal);
  const expected = r2(book.balance + eftTotal);
  const last = db().get("SELECT * FROM bank_statements WHERE account_uid = ? AND status <> 'void' AND to_date <= ? ORDER BY to_date DESC, created_at DESC LIMIT 1", [accountUid, asOf]);
  const lastCheck = latestCheck('bank', accountUid);
  const count = (tone) => cheques.concat(ins, outs).filter((x) => x.tone === tone).length;
  return { account: acc, asOf, book: book.balance, inBank, expected, cheques, ins, outs, eftpos: eft, chequesOut, insTotal, outsTotal, eftTotal,
    lastStatement: last ? { uid: last.uid, date: last.to_date, closing: r2(last.closing), status: last.status } : null, lastCheck,
    red: count('red'), stale: count('stale') };
}

// Cash on hand at each shop, for the overview (read from Till & cash).
export function cashOnHandAll() {
  try {
    const { cashOnHand } = require('../till/service.js');
    const { operatingShops } = require('../../services/costAreas.js');
    return operatingShops().map((s) => ({ shop: s.code, name: s.name, ...cashOnHand(s.code) }));
  } catch (e) { return []; }
}

// ---------------------------------------------------------------- history with running balance
// Every cheque and bank entry in date order with the running cheque-book balance, the cleared mark and the shop tag.
export function bankHistory(accountUid, { from, to, q = '', shop = '' } = {}) {
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid || '']);
  if (!acc) return { rows: [], opening: 0, closing: 0 };
  to = to || dateStr();
  const rows = [];
  for (const c of db().all("SELECT * FROM cheques WHERE account_uid = ? AND status IN ('written','presented') AND cheque_date >= ? AND cheque_date <= ?", [accountUid, acc.opening_date, to])) {
    rows.push({ kind: 'cheque', uid: c.uid, date: c.cheque_date, sort: `${c.cheque_date} ${String(c.cheque_no).padStart(10, '0')}`, what: `Cheque ${c.cheque_no}`, ref: String(c.cheque_no), party: c.payee || '', amount: -r2(c.amount),
      cleared: c.status === 'presented' ? c.presented_date : null, clearedBy: c.presented_by_name || null, shop: chequeShop(c) });
  }
  for (const e of db().all("SELECT * FROM bank_entries WHERE account_uid = ? AND status = 'active' AND entry_date >= ? AND entry_date <= ?", [accountUid, acc.opening_date, to])) {
    const inward = IN_TYPES.includes(e.type);
    const dep = db().get('SELECT slip_no FROM deposits WHERE bank_entry_uid = ?', [e.uid]);
    rows.push({ kind: 'entry', uid: e.uid, date: e.entry_date, sort: `${e.entry_date} ${e.updated_at || ''}`, what: dep ? `Deposit slip ${dep.slip_no}` : ({ deposit: 'Deposit', interest: 'Interest', adjust_in: 'Correction +', fee: 'Bank fee', transfer_out: 'Transfer / debit', adjust_out: 'Correction −' }[e.type] || e.type),
      ref: e.reference || '', party: e.note || '', amount: inward ? r2(e.amount) : -r2(e.amount), cleared: e.cleared_date || null, clearedBy: null, shop: entryShop(e) });
  }
  rows.sort((a, b) => (a.sort < b.sort ? -1 : a.sort > b.sort ? 1 : 0));
  let bal = r2(acc.opening_balance);
  for (const r of rows) { bal = r2(bal + r.amount); r.balance = bal; }
  const before = from ? rows.filter((r) => r.date < from) : [];
  const opening = before.length ? before[before.length - 1].balance : r2(acc.opening_balance);
  const ql = txt(q).toLowerCase();
  const shown = rows.filter((r) => (!from || r.date >= from) && (!shop || (shop === 'OFFICE' ? !r.shop || r.shop === 'OFFICE' : r.shop === shop))
    && (!ql || `${r.what} ${r.ref} ${r.party} ${Math.abs(r.amount).toFixed(2)} ${r.date}`.toLowerCase().includes(ql)));
  return { account: acc, rows: shown.reverse(), opening, closing: bal };
}

// ---------------------------------------------------------------- check against mobile banking / the M-PAiSA app
export function latestCheck(kind, accountUid) {
  if (!has('bank_checks')) return null;
  const c = db().get('SELECT * FROM bank_checks WHERE account_kind = ? AND account_uid = ? ORDER BY check_date DESC, checked_at DESC LIMIT 1', [kind, accountUid]);
  return c ? { ...c, causes: J(c.causes, []) } : null;
}
export function listChecks(kind, accountUid, limit = 60) {
  return db().all('SELECT * FROM bank_checks WHERE account_kind = ? AND (? IS NULL OR account_uid = ?) ORDER BY check_date DESC, checked_at DESC LIMIT ?', [kind, accountUid || null, accountUid || null, limit])
    .map((c) => ({ ...c, causes: J(c.causes, []) }));
}
// Items that may explain a difference: one item, or two or three together, with exactly that amount.
function combos(items, target) {
  const cents = Math.round(target * 100);
  const list = items.filter((x) => Math.abs(x.amount) > 0).slice(0, 30);
  const one = list.filter((x) => Math.round(x.amount * 100) === cents);
  if (one.length) return one.map((x) => [x]);
  for (let i = 0; i < list.length; i += 1) for (let j = i + 1; j < list.length; j += 1) {
    if (Math.round((list[i].amount + list[j].amount) * 100) === cents) return [[list[i], list[j]]];
    for (let k = j + 1; k < list.length; k += 1) if (Math.round((list[i].amount + list[j].amount + list[k].amount) * 100) === cents) return [[list[i], list[j], list[k]]];
  }
  return [];
}
// diff = what the bank / wallet app shows − what the app says is there now.
export function likelyCauses(kind, accountUid, diff) {
  const out = [];
  if (Math.abs(diff) < 0.005) return out;
  let pending = [];
  if (kind === 'bank') {
    const p = moneyPosition(accountUid);
    // a cheque presented lowers the bank (−); a deposit or transfer cleared raises it (+); a fee taken lowers it.
    pending = p.cheques.map((c) => ({ ...c, amount: -c.amount, why: `${c.label} (${$(c.amount)}) has probably been presented – mark it cleared.` }))
      .concat(p.ins.map((e) => ({ ...e, why: `${e.label} (${$(e.amount)}) has probably cleared – mark it on the statement.` })))
      .concat(p.outs.map((e) => ({ ...e, amount: -e.amount, why: `${e.label} (${$(e.amount)}) has probably gone through.` })))
      .concat(p.eftpos.map((e) => ({ ...e, why: `${e.label} (${$(e.amount)}) has probably been paid in by the bank.` })));
  } else {
    try {
      const W = require('./wallets.js');
      pending = W.walletPending(accountUid).map((x) => ({ ...x }));
    } catch (e) { pending = []; }
  }
  for (const set of combos(pending, diff)) {
    if (set.length === 1) out.push(set[0].why);
    else out.push(`These ${set.length} together make the difference: ${set.map((x) => x.label).join(' + ')}.`);
  }
  const a = Math.abs(diff);
  if (kind === 'bank') {
    if (diff < 0 && a <= 50) out.push('Probably bank fees or charges not recorded in the app yet (import the statement or add them in Deposits & bank fees).');
    if (diff < 0) out.push('A direct debit, loan repayment, fee or a cheque that is not recorded in the app.');
    if (diff > 0) out.push('A deposit, M-PAiSA transfer, interest or a direct credit that is not recorded in the app.');
  } else {
    if (diff < 0) out.push('A transfer to BSP or an M-PAiSA fee not recorded yet, or a till balance with more M-PAiSA than was really received (check for fake payment messages).');
    if (diff > 0) out.push('M-PAiSA sales of a shift not yet in a till balance, or a payment received that the till did not record.');
  }
  const cents = Math.round(a * 100);
  if (cents % 900 === 0 && cents >= 900) out.push('The difference divides by 9 – two digits may have been swapped when typing a figure.');
  out.push('Check the figure typed from the app is right.');
  return out;
}
export function checkBalance(user, { kind = 'bank', accountUid, typed, date, note }) {
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  need(txt(typed) !== '' && Number.isFinite(Number(typed)), kind === 'bank' ? 'Type the balance shown in the BSP app.' : 'Type the balance shown in the M-PAiSA app.');
  let app;
  if (kind === 'bank') {
    const p = moneyPosition(accountUid, d);
    need(p, 'Choose the bank account.');
    app = p.inBank;
  } else {
    const W = require('./wallets.js');
    const w = W.walletPosition(accountUid, d);
    need(w, 'Choose the wallet.');
    app = w.balance;
  }
  const diff = r2(Number(typed) - app);
  const result = Math.abs(diff) < 0.005 ? 'match' : 'diff';
  const causes = likelyCauses(kind, accountUid, diff);
  const now = stamp();
  const uid = uuid('BC');
  db().run(`INSERT INTO bank_checks (uid, account_kind, account_uid, check_date, checked_at, typed_balance, app_balance, diff, result, causes, note, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, kind, accountUid, d, now, r2(typed), app, diff, result, JSON.stringify(causes), txt(note) || null, user.name, user.uid, now, deviceId()]);
  audit({ user, action: `${kind === 'bank' ? 'Bank' : 'Wallet'} balance checked: ${result === 'match' ? 'matches' : `difference ${$(diff)}`}`, table: 'bank_checks', recordUid: uid });
  return { uid, app, typed: r2(typed), diff, result, causes };
}
// Days since the last check, and whether the Home reminder is due.
export function checkDue(kind, accountUid, today = dateStr(), s = bankSettings()) {
  const on = kind === 'bank' ? s.mobileCheckOn : s.walletCheckOn;
  const days = kind === 'bank' ? s.mobileCheckDays : s.walletCheckDays;
  const last = latestCheck(kind, accountUid);
  const since = last ? daysBetween(last.check_date, today) : null;
  return { on, days, last, since, due: !!on && (since === null || since >= days) };
}

// ---------------------------------------------------------------- feature 10: real figures for the cash forecast
export function bankForecastFigures(today = dateStr()) {
  const acc = mainAccount();
  if (!acc) return null;
  const from = addDays(today, -91);
  const fees = db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM bank_entries WHERE account_uid = ? AND status = 'active' AND type = 'fee' AND entry_date > ? AND entry_date <= ?`, [acc.uid, from, today]).s;
  let walletFees = 0;
  if (has('wallet_moves')) walletFees = db().get("SELECT IFNULL(SUM(amount),0) AS s FROM wallet_moves WHERE status = 'active' AND type = 'fee' AND move_date > ? AND move_date <= ?", [from, today]).s;
  const p = moneyPosition(acc.uid, today);
  return { account: acc.name, weeklyFees: r2((fees + walletFees) / 13), inBank: p.inBank, expected: p.expected, lastStatement: p.lastStatement, chequesOut: p.chequesOut, inTransit: p.insTotal };
}
