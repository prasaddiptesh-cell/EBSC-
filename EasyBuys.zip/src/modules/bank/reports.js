// Bank reports: reconciliations, the v3.5 reconciliation report, bank charges, balance checks, wallets, history.
import { stamp } from '../../services/core.js';
import { db } from '../../db/connection.js';
import { reconcileSummary, $ } from './service.js';
import * as M from './monthEnd.js';

const col = (key, title, align = 'left') => ({ key, title, align });
export const REPORTS = [
  { id: 'bank_rec', group: 'Bank', icon: '🏦', title: 'Bank reconciliations', desc: 'Statements in the period: balanced or not, and what was left', perm: 'bank_rec',
    build(from, to) {
      const sts = db().all("SELECT uid FROM bank_statements WHERE status <> 'void' AND to_date BETWEEN ? AND ? ORDER BY to_date", [from, to]).map((x) => reconcileSummary(x.uid));
      const rows = sts.map((r) => ({ acct: r.statement.account_name, period: `${r.statement.from_date} – ${r.statement.to_date}`, closing: $(r.statement.closing), book: $(r.check.balance),
        chq: $(r.check.chequesOut), dep: $(r.check.depositsInTransit), diff: $(r.check.difference), status: r.statement.status === 'reconciled' ? `done ${r.statement.reconciled_by_name}` : `${r.unmatched.length} to match`,
        _tone: r.check.balanced && r.statement.status === 'reconciled' ? 'good' : 'bad' }));
      const items = [];
      sts.forEach((r) => r.check.notCleared.forEach((c) => items.push({ acct: r.statement.account_name, what: `Cheque ${c.cheque_no} ${c.payee}`, date: c.cheque_date, amount: $(c.amount) })));
      return { kind: 'bank_rec', title: 'Bank Reconciliations', fileName: `Bank-Reconciliations-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`,
        info: [['Period', `${from} to ${to}`], ['Generated', stamp()]], summary: [{ label: 'Statements', value: String(sts.length) }, { label: 'Balanced', value: String(sts.filter((r) => r.check.balanced).length), tone: 'good' }],
        sections: [{ title: 'Statements', columns: [col('acct', 'Account'), col('period', 'Period'), col('closing', 'Statement', 'right'), col('book', 'Cheque book', 'right'), col('chq', 'Cheques out', 'right'), col('dep', 'Deposits in transit', 'right'), col('diff', 'Difference', 'right'), col('status', 'Status')], rows },
          { title: 'Cheques not cleared at the statement dates', columns: [col('acct', 'Account'), col('what', 'Cheque'), col('date', 'Date'), col('amount', 'Amount', 'right')], rows: items }] };
    } },
  { id: 'bank_rec35', group: 'Bank', icon: '⚖️', title: 'Bank reconciliation report', desc: 'In the bank now, expected balance, cheques and deposits waiting, statement lines, warnings, month-end steps', perm: 'bank_rec', build: (from, to) => M.reconciliationReport(from, to) },
  { id: 'bank_charges', group: 'Bank', icon: '💸', title: 'Bank charges', desc: 'Bank fees and M-PAiSA fees by month', perm: 'bank_rec', build: (from, to) => M.bankChargesReport(from, to) },
  { id: 'bank_checks', group: 'Bank', icon: '📱', title: 'Balance checks', desc: 'Checks against mobile banking and the M-PAiSA app', perm: 'bank_rec', build: (from, to) => M.balanceChecksReport(from, to) },
  { id: 'bank_wallets', group: 'Bank', icon: '📲', title: 'M-PAiSA wallets', desc: 'Shift sales against receipts, transfers, fees and balances', perm: 'bank_rec', build: (from, to) => M.walletsReport(from, to) },
  { id: 'bank_history', group: 'Bank', icon: '📜', title: 'Bank history', desc: 'Every line with the running balance, cleared marks and shop', perm: 'bank_rec', build: (from, to) => M.bankHistoryReport(from, to) },
];
