// Bank statements and their lines (for reconciliation).
export const BANK_SQL = `
CREATE TABLE IF NOT EXISTS bank_statements (
  uid TEXT PRIMARY KEY,
  account_uid TEXT NOT NULL,
  from_date TEXT NOT NULL,
  to_date TEXT NOT NULL,
  opening REAL,
  closing REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','reconciled','void')),
  reconciled_by_name TEXT, reconciled_at TEXT, difference REAL,
  by_name TEXT, created_at TEXT, notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS bank_lines (
  uid TEXT PRIMARY KEY,
  statement_uid TEXT NOT NULL,
  account_uid TEXT NOT NULL,
  line_date TEXT NOT NULL,
  description TEXT,
  reference TEXT,
  amount REAL NOT NULL,
  match_type TEXT,
  match_uid TEXT,
  status TEXT NOT NULL DEFAULT 'unmatched' CHECK (status IN ('unmatched','matched','ignored')),
  note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_bl_stmt ON bank_lines(statement_uid);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const BANK_SYNC = {
  bank_statements: SYNC('uid', 'Cheques & bank', ['uid', 'account_uid', 'from_date', 'to_date', 'opening', 'closing', 'status', 'reconciled_by_name', 'reconciled_at', 'difference', 'by_name', 'created_at', 'notes']),
  bank_lines: SYNC('uid', 'Cheques & bank', ['uid', 'statement_uid', 'account_uid', 'line_date', 'description', 'reference', 'amount', 'match_type', 'match_uid', 'status', 'note']),
};

