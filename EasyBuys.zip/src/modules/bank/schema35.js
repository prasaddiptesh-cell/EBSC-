// v3.5 bank, cash and M-PAiSA tables: balance checks against the BSP / M-PAiSA apps, the M-PAiSA (and later MyCash)
// wallets as money accounts, their statements, and the month-end bank closing. Nothing is ever deleted.
export const BANK35_SQL = `
CREATE TABLE IF NOT EXISTS bank_checks (
  uid TEXT PRIMARY KEY,
  account_kind TEXT NOT NULL DEFAULT 'bank',
  account_uid TEXT NOT NULL,
  check_date TEXT NOT NULL,
  checked_at TEXT,
  typed_balance REAL NOT NULL,
  app_balance REAL NOT NULL,
  diff REAL NOT NULL,
  result TEXT NOT NULL,
  causes TEXT,
  note TEXT,
  by_name TEXT, by_uid TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_bchk_acct ON bank_checks(account_uid, check_date);
CREATE TABLE IF NOT EXISTS wallets (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'M-PAiSA',
  shop_code TEXT,
  phone_no TEXT,
  opening_balance REAL NOT NULL DEFAULT 0,
  opening_date TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS wallet_moves (
  uid TEXT PRIMARY KEY,
  wallet_uid TEXT NOT NULL,
  move_date TEXT NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  bank_entry_uid TEXT,
  reference TEXT,
  note TEXT,
  cleared_date TEXT,
  by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_wm_wallet ON wallet_moves(wallet_uid, move_date);
CREATE TABLE IF NOT EXISTS wallet_imports (
  uid TEXT PRIMARY KEY,
  wallet_uid TEXT NOT NULL,
  from_date TEXT NOT NULL,
  to_date TEXT NOT NULL,
  opening REAL, closing REAL,
  source TEXT,
  file_name TEXT,
  doc_uid TEXT,
  line_count INTEGER NOT NULL DEFAULT 0,
  by_name TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS wallet_lines (
  uid TEXT PRIMARY KEY,
  import_uid TEXT NOT NULL,
  wallet_uid TEXT NOT NULL,
  line_date TEXT NOT NULL,
  line_time TEXT,
  description TEXT,
  reference TEXT,
  party TEXT,
  amount REAL NOT NULL,
  balance REAL,
  kind TEXT NOT NULL DEFAULT 'receipt',
  status TEXT NOT NULL DEFAULT 'unmatched',
  match_type TEXT, match_uid TEXT,
  note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_wl_wallet ON wallet_lines(wallet_uid, line_date);
CREATE TABLE IF NOT EXISTS wallet_shift_notes (
  uid TEXT PRIMARY KEY,
  wallet_uid TEXT,
  note TEXT,
  by_name TEXT, at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS bank_closings (
  uid TEXT PRIMARY KEY,
  ym TEXT NOT NULL,
  account_uid TEXT NOT NULL,
  statement_uid TEXT,
  closing REAL,
  expected REAL,
  difference REAL,
  doc_uid TEXT,
  by_name TEXT, closed_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const BANK35_SYNC = {
  bank_checks: SYNC('uid', 'Cheques & bank', ['uid', 'account_kind', 'account_uid', 'check_date', 'checked_at', 'typed_balance', 'app_balance', 'diff', 'result', 'causes', 'note', 'by_name', 'by_uid']),
  wallets: SYNC('uid', 'Cheques & bank', ['uid', 'name', 'provider', 'shop_code', 'phone_no', 'opening_balance', 'opening_date', 'active', 'sort']),
  wallet_moves: SYNC('uid', 'Cheques & bank', ['uid', 'wallet_uid', 'move_date', 'type', 'amount', 'bank_entry_uid', 'reference', 'note', 'cleared_date', 'by_name', 'status', 'void_reason']),
  wallet_imports: SYNC('uid', 'Cheques & bank', ['uid', 'wallet_uid', 'from_date', 'to_date', 'opening', 'closing', 'source', 'file_name', 'doc_uid', 'line_count', 'by_name', 'created_at', 'status']),
  wallet_lines: SYNC('uid', 'Cheques & bank', ['uid', 'import_uid', 'wallet_uid', 'line_date', 'line_time', 'description', 'reference', 'party', 'amount', 'balance', 'kind', 'status', 'match_type', 'match_uid', 'note']),
  wallet_shift_notes: SYNC('uid', 'Cheques & bank', ['uid', 'wallet_uid', 'note', 'by_name', 'at']),
  bank_closings: SYNC('uid', 'Cheques & bank', ['uid', 'ym', 'account_uid', 'statement_uid', 'closing', 'expected', 'difference', 'doc_uid', 'by_name', 'closed_at', 'status']),
};
// Columns added to older tables (src/db/columns.js reads this list).
export const BANK35_COLUMNS = {
  bank_lines: [['shop_code', 'TEXT'], ['flags', 'TEXT'], ['flags_ok_by', 'TEXT']],
  bank_statements: [['source', 'TEXT'], ['doc_uid', 'TEXT'], ['skipped', 'INTEGER']],
  bank_entries: [['shop_code', 'TEXT']],
  cheques: [['presented_by_name', 'TEXT'], ['shop_code', 'TEXT']],
};
