// v3.5 bank, cash and M-PAiSA screens: the two balances, check against mobile banking, statement import with its
// checks, bank history, statement archive, month end, the M-PAiSA wallets, their statements and shift matching.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI, Choice, Select, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain, Stats, PeriodPicker, usePeriod, ReasonButton } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { dateStr, addDays } from '../../../services/core.js';
import { listCostAreas } from '../../../services/costAreas.js';
import { renameDocument } from '../../../services/documents.js';
import { listAccounts, apRules } from '../../payables/service.js';
import { pickStatementFile, archiveStatement, saveReportDocument } from '../../../platform/statementFiles.js';
import * as P from '../position.js';
import * as I from '../importer.js';
import * as W from '../wallets.js';
import * as M from '../monthEnd.js';

const { $ } = P;
const TONE_COLOR = { amber: C.warn, red: C.danger, stale: C.danger };
const shopOpts = () => listCostAreas().filter((a) => a.kind !== 'closed').map((a) => ({ value: a.code === 'OFFICE' ? '' : a.code, label: a.code === 'OFFICE' ? 'Whole business' : a.code }));
const shopLabel = (s) => (!s || s === 'OFFICE' ? 'Whole business' : s);
const signed = (n) => `${n < 0 ? '−' : '+'}${$(Math.abs(n))}`;
const rowsToCsv = (rows) => rows.map((r) => r.map((c) => (/[",\n]/.test(String(c)) ? `"${String(c).replace(/"/g, '""')}"` : String(c))).join(',')).join('\n');
function useAccount(params = {}) {
  const accounts = listAccounts();
  const [acc, setAcc] = useState(params.accountUid || (P.mainAccount() || {}).uid || '');
  return [acc, setAcc, accounts];
}
function AccountPick({ acc, setAcc, accounts }) {
  if (!accounts.length) return <Banner tone="warn" message="Add the BSP account first: Invoices & cheques › Bank accounts." />;
  return accounts.length > 1 ? <Choice value={acc} onChange={setAcc} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null;
}

// ---------------------------------------------------------------- the two balances (top of Bank reconciliation)
function ItemRow({ x, sign, onPress, testID }) {
  return (
    <ListItem testID={testID} title={x.label} sub={`${x.date} · ${x.age} days · ${shopLabel(x.shop)}`} right={`${sign}${$(x.amount)}`}
      badge={P.TONE_LABEL[x.tone]} badgeColor={TONE_COLOR[x.tone]} tone={x.tone === 'amber' ? 'warn' : 'danger'} onPress={onPress} />
  );
}
export function MoneyNowCard({ accountUid, compact = false }) {
  const { nav } = useApp();
  const p = accountUid ? P.moneyPosition(accountUid) : null;
  if (!p) return null;
  const cash = P.cashOnHandAll();
  return (
    <Card>
      <Stats items={[
        { label: 'In the bank now', value: $(p.inBank), sub: 'what BSP holds (cleared items)', color: C.info, testID: 'bal-now' },
        { label: 'Expected balance', value: $(p.expected), sub: 'after cheques and deposits waiting clear', color: C.success, testID: 'bal-expected' },
      ]} />
      <Row label={`Cheques not yet presented (${p.cheques.length})`} value={`−${$(p.chequesOut)}`} color={p.cheques.some((c) => c.tone !== 'amber') ? C.danger : C.warn} />
      <Row label={`Deposits / transfers not yet cleared (${p.ins.length})`} value={`+${$(p.insTotal)}`} color={p.ins.some((c) => c.tone !== 'amber') ? C.danger : C.warn} />
      {p.outs.length ? <Row label={`Fees / debits not yet on the statement (${p.outs.length})`} value={`−${$(p.outsTotal)}`} /> : null}
      {p.eftpos.length ? <Row label={`EFTPOS settlements expected (${p.eftpos.length})`} value={`+${$(p.eftTotal)}`} /> : null}
      <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>
        {p.lastStatement ? `Latest statement ${p.lastStatement.date}: ${$(p.lastStatement.closing)}. ` : 'No statement imported yet. '}
        {p.lastCheck ? `Checked against mobile banking ${p.lastCheck.check_date} (${p.lastCheck.result === 'match' ? 'matched' : `out ${$(p.lastCheck.diff)}`}).` : 'Not checked against mobile banking yet.'}
      </Text>
      {!compact && cash.length ? <Text style={{ fontSize: 14, color: C.sub }}>Cash on hand: {cash.map((c) => `${c.shop} ${$(c.onHand)}`).join(' · ')}</Text> : null}
      {!compact ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
          <Btn testID="go-check" title="Check against mobile banking" icon="📱" size="sm" variant="info" onPress={() => nav.push('BankCheck', { accountUid })} />
          <Btn testID="go-import" title="Import statement" icon="📥" size="sm" variant="secondary" onPress={() => nav.push('BankImport', { accountUid })} />
          <Btn testID="go-history" title="History" icon="📜" size="sm" variant="secondary" onPress={() => nav.push('BankHistory', { accountUid })} />
          <Btn testID="go-month" title="Month end" icon="✅" size="sm" variant="secondary" onPress={() => nav.push('BankMonthEnd', { accountUid })} />
        </View>
      ) : null}
    </Card>
  );
}
// Cheques and deposits waiting, coloured by age (used on the Bank reconciliation screen).
export function WaitingItems({ accountUid, onTick }) {
  const p = accountUid ? P.moneyPosition(accountUid) : null;
  if (!p) return null;
  return (
    <View style={{ gap: 6 }}>
      <Hint>{`Amber = waiting, red = older than the verification days (${P.bankSettings().verifyDays}), STALE = over 6 months. Tap one when it is on the statement.`}</Hint>
      {p.ins.map((x) => <ItemRow key={x.uid} testID={`wait-${x.uid}`} x={x} sign="+" onPress={onTick ? () => onTick({ kind: 'entry', uid: x.uid }) : null} />)}
      {p.cheques.map((x) => <ItemRow key={x.uid} testID={`wait-chq-${x.no}`} x={x} sign="−" onPress={onTick ? () => onTick({ kind: 'cheque', uid: x.uid }) : null} />)}
      {p.outs.map((x) => <ItemRow key={x.uid} testID={`wait-${x.uid}`} x={x} sign="−" onPress={onTick ? () => onTick({ kind: 'entry', uid: x.uid }) : null} />)}
    </View>
  );
}

// ---------------------------------------------------------------- check against mobile banking / the M-PAiSA app
export function BankCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const accounts = listAccounts();
  const wallets = W.listWallets();
  const first = params.kind === 'wallet' && params.walletUid ? `w:${params.walletUid}` : accounts[0] ? `b:${params.accountUid || accounts[0].uid}` : wallets[0] ? `w:${wallets[0].uid}` : '';
  const [which, setWhich] = useState(first);
  const [typed, setTyped] = useState('');
  const [date, setDate] = useState(dateStr());
  const [note, setNote] = useState('');
  const [res, setRes] = useState(null);
  const kind = which.startsWith('w:') ? 'wallet' : 'bank';
  const uid = which.slice(2);
  const opts = accounts.map((a) => ({ value: `b:${a.uid}`, label: `${a.name} (BSP app)` })).concat(wallets.map((w) => ({ value: `w:${w.uid}`, label: `${w.name} (${w.provider} app)` })));
  let app = null;
  try { app = kind === 'bank' ? (P.moneyPosition(uid, date) || {}).inBank : (W.walletPosition(uid, date) || {}).balance; } catch (e) { app = null; }
  const history = uid ? P.listChecks(kind, uid, 20) : [];
  const run = () => { try { setRes(P.checkBalance(user, { kind, accountUid: uid, typed, date, note })); ui.toast('Check saved'); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Check against mobile banking" subtitle="Type the balance the app shows right now">
      <Explain>Open the BSP mobile banking app (or the M-PAiSA app for a wallet), look at the balance, and type it here. Easy Buys compares it with what it knows. A difference usually means a cheque was presented, a deposit cleared, or a fee was taken – the likely causes are listed.</Explain>
      {!opts.length ? <Banner tone="warn" message="Add the BSP account first: Invoices & cheques › Bank accounts." /> : <Choice label="Which account" value={which} onChange={(v) => { setWhich(v); setRes(null); }} options={opts} testIDPrefix="chk-acct" />}
      {uid ? (
        <Card>
          <Row label={kind === 'bank' ? 'Easy Buys says: in the bank now' : 'Easy Buys says: in the wallet'} value={app === null || app === undefined ? '—' : $(app)} bold />
          <DateField testID="chk-date" label="Date" value={date} onChange={setDate} />
          <MoneyField testID="chk-typed" label={kind === 'bank' ? 'Balance in the BSP app' : 'Balance in the M-PAiSA app'} value={typed} onChange={setTyped} />
          <Field testID="chk-note" label="Note (optional)" value={note} onChangeText={setNote} />
          <Btn testID="chk-go" title="Check" icon="✔️" variant="success" onPress={run} />
        </Card>
      ) : null}
      {res ? (
        <Card tone={res.result === 'match' ? 'success' : 'danger'}>
          <H>{res.result === 'match' ? 'Matches ✓' : `Difference ${signed(res.diff)}`}</H>
          {res.result !== 'match' ? <Label>Likely causes</Label> : null}
          {res.causes.map((c, i) => <Text key={i} testID={`cause-${i}`} style={{ fontSize: 15, color: C.text, marginBottom: 4 }}>• {c}</Text>)}
          {res.result !== 'match' && kind === 'bank' ? <Btn title="Tick cheques / deposits that have cleared" size="sm" variant="secondary" onPress={() => nav.push('BankRec', { accountUid: uid })} /> : null}
        </Card>
      ) : null}
      <Section title={`Earlier checks (${history.length})`}>
        {history.map((h) => (
          <ListItem key={h.uid} title={`${h.check_date} · ${$(h.typed_balance)}`} sub={`by ${h.by_name}${h.note ? ` · ${h.note}` : ''}${h.result !== 'match' && h.causes[0] ? ` · ${h.causes[0]}` : ''}`}
            right={h.result === 'match' ? '✓' : signed(h.diff)} badge={h.result === 'match' ? 'matched' : 'difference'} badgeColor={h.result === 'match' ? C.success : C.danger} />
        ))}
      </Section>
    </Screen>
  );
}
export function BankChecksScreen() {
  const [kind, setKind] = useRemembered('kind', 'bank');
  const list = P.listChecks(kind, null, 200);
  const name = (c) => (kind === 'bank' ? (listAccounts().find((a) => a.uid === c.account_uid) || {}).name : (W.getWallet(c.account_uid) || {}).name) || '';
  return (
    <Screen title="Balance checks" subtitle="Against mobile banking and the M-PAiSA app">
      <Chips value={kind} onChange={setKind} testIDPrefix="chks" options={[{ value: 'bank', label: 'BSP' }, { value: 'wallet', label: 'Wallets' }]} />
      {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No checks yet.</Text> : null}
      {list.map((h) => (
        <ListItem key={h.uid} title={`${h.check_date} · ${name(h)}`} sub={`App ${$(h.typed_balance)} · Easy Buys ${$(h.app_balance)} · by ${h.by_name}`} right={h.result === 'match' ? '✓' : signed(h.diff)}
          badgeColor={h.result === 'match' ? C.success : C.danger} badge={h.result === 'match' ? 'matched' : 'difference'} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- import a bank statement
const FEATURES = [
  ['cheques', 'Cheques cleared by themselves'], ['deposits', 'Deposits confirmed'], ['slipDiffs', 'Deposits that differ from the slip'], ['mpaisa', 'M-PAiSA transfers confirmed'],
  ['missing', 'Lines not in the app yet'], ['loans', 'Loan repayments found'], ['fees', 'Bank fees and interest booked'], ['unknownCheques', 'Unknown cheques / wrong amounts'],
  ['duplicates', 'Lines that appear twice'], ['unusual', 'Unusual items'], ['rules', 'Lines coded by your bank rules'],
];
export function BankImportScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [acc, setAcc, accounts] = useAccount(params);
  const [text, setText] = useState('');
  const [file, setFile] = useState(null);
  const [format, setFormat] = useState('auto');
  const [over, setOver] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  let parsed = null;
  try { parsed = text ? I.readBankStatement(text, format) : null; } catch (e) { parsed = null; }
  const f = { fromDate: over.fromDate || (parsed && parsed.fromDate) || '', toDate: over.toDate || (parsed && parsed.toDate) || '',
    opening: over.opening !== undefined ? over.opening : parsed && parsed.opening !== null && parsed.opening !== undefined ? String(parsed.opening) : '',
    closing: over.closing !== undefined ? over.closing : parsed && parsed.closing !== null && parsed.closing !== undefined ? String(parsed.closing) : '' };
  const choose = async () => {
    try {
      const x = await pickStatementFile();
      if (!x) return;
      setFile(x); setOver({}); setDone(null);
      if (x.needsOnline) { ui.error(new Error(x.needsOnline)); return; }
      if (x.rows) { setText(rowsToCsv(x.rows)); setFormat('csv'); } else { setText(x.text || ''); setFormat(x.kind === 'ofx' ? 'ofx' : 'auto'); }
    } catch (e) { ui.error(e); }
  };
  const go = async () => {
    setBusy(true);
    try {
      const name = `BSP statement ${f.fromDate} to ${f.toDate}`;
      let docUid = null;
      try { docUid = await archiveStatement(user, { refType: 'bank_statement', kind: 'bank_statement', name, docDate: f.toDate }, file, file ? null : text); } catch (e) { docUid = null; }
      const r = I.importBankStatement(user, { accountUid: acc, text, format, fromDate: f.fromDate, toDate: f.toDate, opening: f.opening, closing: f.closing, fileName: file && file.name, docUid });
      if (docUid && file) { try { renameDocument(user, docUid, { name: `${name} (${file.name})`, docDate: f.toDate }); } catch (e) { /* keep the name */ } }
      setDone(r); setText(''); setFile(null);
      ui.toast(`Imported ${r.added} line(s)`);
    } catch (e) { ui.error(e); } finally { setBusy(false); }
  };
  const ins = parsed ? parsed.lines.filter((l) => l.amount > 0).reduce((s, l) => s + l.amount, 0) : 0;
  const outs = parsed ? -parsed.lines.filter((l) => l.amount < 0).reduce((s, l) => s + l.amount, 0) : 0;
  return (
    <Screen title="Import a bank statement" subtitle="BSP CSV, OFX, Excel, PDF or pasted text">
      <AccountPick acc={acc} setAcc={setAcc} accounts={accounts} />
      <Explain>Download the statement from BSP internet banking (CSV or OFX is best) or copy the lines from the PDF and paste them. You can import in the middle of the month; lines already in the app are skipped next time. At month end import the whole month.</Explain>
      {done ? (
        <Card tone="success">
          <H>{`Imported ${done.added} line(s)${done.already ? ` · ${done.already} already in` : ''}`}</H>
          {FEATURES.map(([k, label]) => (done.summary[k] ? <Row key={k} label={label} value={String(done.summary[k])} color={['slipDiffs', 'unknownCheques', 'duplicates', 'unusual'].includes(k) ? C.danger : undefined} /> : null))}
          <Btn testID="imp-open" title="Open the statement" icon="📋" variant="primary" size="md" onPress={() => nav.push('Statement', { uid: done.uid })} />
        </Card>
      ) : null}
      <Card>
        <Btn testID="imp-file" title={file ? `File: ${file.name}` : 'Choose the statement file'} icon="📂" variant="info" size="md" onPress={choose} />
        <Field testID="imp-text" label="…or paste the statement lines" value={text} onChangeText={(v) => { setText(v); setFile(null); setDone(null); }} multiline />
        <Chips value={format} onChange={setFormat} testIDPrefix="imp-fmt" options={[{ value: 'auto', label: 'Find out' }, { value: 'csv', label: 'CSV' }, { value: 'ofx', label: 'OFX' }, { value: 'text', label: 'PDF / text' }]} />
      </Card>
      {parsed ? (
        <Card tone={parsed.lines.length ? 'info' : 'warn'}>
          <Text testID="imp-read" style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Read {parsed.lines.length} line(s) ({parsed.format}){parsed.skipped.length ? `, skipped ${parsed.skipped.length} heading / other line(s)` : ''}</Text>
          <Row label="Money in" value={$(ins)} /><Row label="Money out" value={$(outs)} />
          <DateField testID="imp-from" label="Statement from" value={f.fromDate} onChange={(v) => setOver((o) => ({ ...o, fromDate: v }))} />
          <DateField testID="imp-to" label="Statement to" value={f.toDate} onChange={(v) => setOver((o) => ({ ...o, toDate: v }))} />
          <MoneyField testID="imp-open-bal" label="Opening balance (optional, used to check)" value={f.opening} onChange={(v) => setOver((o) => ({ ...o, opening: v }))} />
          <MoneyField testID="imp-close" label="Closing balance" value={f.closing} onChange={(v) => setOver((o) => ({ ...o, closing: v }))} />
          {parsed.lines.slice(0, 8).map((l, i) => <Text key={i} style={{ fontSize: 14, color: C.sub }}>{l.date} · {l.description} · {signed(l.amount)}</Text>)}
          {parsed.lines.length > 8 ? <Text style={{ fontSize: 14, color: C.sub }}>… and {parsed.lines.length - 8} more</Text> : null}
          <Btn testID="imp-go" title={busy ? 'Importing…' : `Import ${parsed.lines.length} line(s)`} icon="💾" variant="success" disabled={busy || !parsed.lines.length || !acc} onPress={go} />
        </Card>
      ) : null}
    </Screen>
  );
}

// Warnings and one-tap actions for a statement line (shown on the Statement screen and at month end).
export function LineFlags({ line, onDone }) {
  const { user } = useApp();
  const act = useAct();
  const [type, setType] = useState(line.amount > 0 ? 'deposit' : 'transfer_out');
  const [shop, setShop] = useState('');
  const [remember, setRemember] = useState(true);
  const flags = I.lineFlags(line);
  const wallets = W.listWallets();
  const did = (r) => { if (r && onDone) onDone(); };
  if (!flags.length) return null;
  const open = line.status === 'unmatched';
  return (
    <View style={{ gap: 6 }}>
      {flags.map((f, i) => <Banner key={i} testID={`flag-${f.code}`} tone={f.level === 'urgent' ? 'danger' : f.level === 'warning' ? 'warn' : 'info'} message={f.text} />)}
      {open && flags.some((f) => f.code === 'slip_diff') ? <Btn testID="flag-slip-ok" title="Match it and record the difference" size="sm" variant="success" onPress={() => did(act(() => I.acceptSlipDifference(user, line.uid, ''), 'Matched'))} /> : null}
      {open && flags.some((f) => f.code === 'loan') ? <Btn testID="flag-loan" title="Record as the loan repayment" size="sm" variant="success" onPress={() => did(act(() => I.matchLoanLine(user, line.uid), 'Loan repayment recorded'))} /> : null}
      {open && line.amount > 0 && flags.some((f) => f.code === 'mpaisa_missing') ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
          {wallets.map((w) => <Btn key={w.uid} testID={`flag-mp-${w.shop_code}`} title={`Transfer from ${w.name}`} size="sm" variant="info" onPress={() => did(act(() => I.mpaisaFromLine(user, line.uid, w.uid), 'Recorded and matched'))} />)}
        </View>
      ) : null}
      {open && flags.some((f) => ['missing', 'unusual', 'duplicate'].includes(f.code)) ? (
        <Card>
          <Label>Record it in the app</Label>
          <Chips value={type} onChange={setType} testIDPrefix="miss-type" options={(line.amount > 0 ? [['deposit', 'Money in'], ['interest', 'Interest'], ['adjust_in', 'Correction +']] : [['transfer_out', 'Direct debit / transfer'], ['fee', 'Bank fee'], ['adjust_out', 'Correction −']]).map(([value, label]) => ({ value, label }))} />
          <Choice label="Shop" value={shop} onChange={setShop} options={shopOpts()} testIDPrefix="miss-shop" />
          <Chips value={remember ? 'y' : 'n'} onChange={(v) => setRemember(v === 'y')} options={[{ value: 'y', label: 'Remember this payee' }, { value: 'n', label: 'Just this once' }]} />
          <Btn testID="miss-go" title="Record and match" size="sm" variant="success" onPress={() => did(act(() => I.recordMissing(user, line.uid, { type, shop, remember, note: line.description }), 'Recorded'))} />
        </Card>
      ) : null}
      {flags.some((f) => f.level !== 'info') && !line.flags_ok_by ? <Btn testID="flag-ok" title="I have looked at this – OK" size="sm" variant="secondary" onPress={() => did(act(() => I.reviewFlags(user, line.uid), 'Reviewed'))} /> : null}
      {line.flags_ok_by ? <Text style={{ fontSize: 13, color: C.success }}>Reviewed by {line.flags_ok_by}</Text> : null}
    </View>
  );
}

// ---------------------------------------------------------------- bank history
export function BankHistoryScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [acc, setAcc, accounts] = useAccount(params);
  const [from, to, setRange] = usePeriod('thismonth');
  const [q, setQ] = useRemembered('q', '');
  const [shop, setShop] = useRemembered('shop', 'ALL');
  const [open, setOpen] = useState(null);
  const h = acc ? P.bankHistory(acc, { from: q.trim() ? null : from, to: q.trim() ? null : to, q, shop: shop === 'ALL' ? '' : shop === 'WB' ? 'OFFICE' : shop }) : { rows: [], opening: 0 };
  return (
    <Screen title="Bank history" subtitle="Every line with the running balance">
      <AccountPick acc={acc} setAcc={setAcc} accounts={accounts} />
      {acc ? <MoneyNowCard accountUid={acc} compact /> : null}
      <PeriodPicker testID="hist-period" from={from} to={to} onChange={setRange} />
      <Field testID="hist-q" label="Search (cheque no., slip, payee, amount)" value={q} onChangeText={setQ} />
      <Chips value={shop} onChange={setShop} testIDPrefix="hist-shop" options={[{ value: 'ALL', label: 'All' }, { value: 'S1', label: 'S1' }, { value: 'S2', label: 'S2' }, { value: 'WB', label: 'Whole business' }]} />
      <Text style={{ fontSize: 15, color: C.sub }}>{q.trim() ? 'Searching every date. ' : ''}Balance at the start: {$(h.opening)} · {h.rows.length} line(s) · ✓ = on a bank statement</Text>
      {h.rows.map((r) => (
        <View key={r.uid} style={{ gap: 4 }}>
          <ListItem testID={`hist-${r.ref || r.uid}`} title={`${r.what}${r.ref && !r.what.includes(r.ref) ? ` ${r.ref}` : ''}`} sub={`${r.date} · ${r.party ? `${r.party} · ` : ''}${shopLabel(r.shop)} · ${r.cleared ? `✓ ${r.cleared}${r.clearedBy ? ` by ${r.clearedBy}` : ''}` : 'not on a statement yet'}`}
            right={signed(r.amount)} rightSub={`bal ${$(r.balance)}`} tone={r.cleared ? undefined : 'warn'} onPress={() => setOpen(open === r.uid ? null : r.uid)} />
          {open === r.uid ? (
            <Card>
              <Choice label="Which shop is this for?" value={r.shop || ''} onChange={(v) => { act(() => P.tagShop(user, r.kind, r.uid, v), 'Tagged'); setOpen(null); }} options={shopOpts()} testIDPrefix="tag" />
            </Card>
          ) : null}
        </View>
      ))}
      <Btn testID="hist-report" title="Reconciliation report (PDF / Excel)" icon="📄" size="md" variant="info" onPress={() => nav.push('ReportView', { kind: 'bank_rec35', from, to })} />
      <Btn title="History report" icon="📜" size="md" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'bank_history', from, to })} />
    </Screen>
  );
}

// ---------------------------------------------------------------- statement archive
export function BankArchiveScreen() {
  return (
    <Screen title="Statement archive" subtitle="Kept on the tablet and in Google Drive">
      <Hint>Every imported statement is kept here, with the reconciliation report saved at each month end.</Hint>
      <Section title="BSP statements"><DocumentsPanel testID="arc-bank" refType="bank_statement" kinds={{ bank_statement: 'Bank statement' }} /></Section>
      <Section title="M-PAiSA statements"><DocumentsPanel testID="arc-wallet" refType="wallet_statement" kinds={{ wallet_statement: 'M-PAiSA statement' }} /></Section>
      <Section title="Reconciliation reports"><DocumentsPanel testID="arc-rec" refType="bank_rec" kinds={{ bank_rec: 'Bank reconciliation' }} canAdd={false} /></Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- month end
const months = (n = 12) => { const out = []; let ym = dateStr().slice(0, 7); for (let i = 0; i < n; i += 1) { out.push(ym); ym = M.lastMonth(`${ym}-15`); } return out; };
const NAV = { statement: 'BankImport', balance: 'BankRec', sorted: 'BankRec', warnings: 'BankMonthEnd', mpaisa: 'MpaisaMatch' };
export function BankMonthEndScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [acc, setAcc, accounts] = useAccount(params);
  const [ym, setYm] = useRemembered('ym', params.ym || M.lastMonth());
  const [busy, setBusy] = useState(false);
  const [, bump] = useState(0);
  const m = acc ? M.bankMonthEnd(ym, acc) : null;
  const flagged = acc && m ? I.flaggedLines({ accountUid: acc, from: m.from, to: m.to }) : [];
  const save = async () => {
    setBusy(true);
    try {
      const rep = M.reconciliationReport(m.from, m.to, acc);
      let docUid = null;
      try { docUid = await saveReportDocument(user, { refType: 'bank_rec', refUid: ym, kind: 'bank_rec', name: `Bank reconciliation ${ym}`, docDate: m.to }, rep); } catch (e) { docUid = null; }
      M.closeBankMonth(user, ym, acc, docUid);
      ui.toast('Reconciliation report saved'); bump((n) => n + 1);
    } catch (e) { ui.error(e); } finally { setBusy(false); }
  };
  return (
    <Screen title="Bank month end" subtitle="Before the month is closed">
      <AccountPick acc={acc} setAcc={setAcc} accounts={accounts} />
      <Select testID="me-month" label="Month" value={ym} onChange={setYm} options={months().map((x) => ({ value: x, label: x }))} />
      {m ? (
        <>
          <Banner testID="me-state" tone={m.closed ? 'success' : m.ready ? 'info' : 'warn'} title={m.closed ? 'Closed ✓' : m.ready ? 'Ready – save the report' : 'Not ready yet'} message={`${m.from} to ${m.to}${m.statementBalance !== null ? ` · statement ${$(m.statementBalance)}` : ''}`} />
          {m.items.map((i) => (
            <ListItem key={i.key} testID={`me-${i.key}`} title={`${i.ok ? '✓' : '✗'} ${i.label}`} sub={i.note || undefined} tone={i.ok ? 'success' : 'warn'}
              onPress={!i.ok && NAV[i.key] && NAV[i.key] !== 'BankMonthEnd' ? () => nav.push(NAV[i.key], { accountUid: acc }) : null} />
          ))}
          {flagged.length ? (
            <Section title={`Warnings to review (${flagged.length})`}>
              {flagged.map((l) => (
                <Card key={l.uid}>
                  <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.line_date} · {l.description} · {signed(l.amount)}</Text>
                  <LineFlags line={l} onDone={() => bump((n) => n + 1)} />
                </Card>
              ))}
            </Section>
          ) : null}
          <Btn testID="me-report" title="See the reconciliation report" icon="📄" size="md" variant="info" onPress={() => nav.push('ReportView', { kind: 'bank_rec35', from: m.from, to: m.to })} />
          {!m.closed ? <Btn testID="me-save" title={busy ? 'Saving…' : 'Save the reconciliation report'} icon="💾" variant="success" disabled={!m.ready || busy} onPress={save} /> : null}
        </>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- wallets
export function WalletsScreen() {
  const { nav } = useApp();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const list = W.listWallets();
  return (
    <Screen title="M-PAiSA wallets" subtitle="One wallet per shop">
      <Explain>The M-PAiSA figure in each till balance goes into that shop's wallet. Transfers to BSP and fees come out; a transfer shows in the bank as "on the way" until the bank statement shows it.</Explain>
      {list.map((w) => {
        const p = W.walletPosition(w.uid);
        const due = P.checkDue('wallet', w.uid);
        return (
          <Card key={w.uid}>
            <H>{w.name}</H>
            <Stats items={[{ label: 'In the wallet', value: $(p.balance), color: C.info }, { label: 'On the way to BSP', value: $(p.transitTotal), color: p.transitTotal ? C.warn : undefined }]} />
            <Text style={{ fontSize: 14, color: C.sub }}>{due.last ? `Checked against the app ${due.last.check_date} (${due.last.result === 'match' ? 'matched' : `out ${$(due.last.diff)}`})` : 'Not checked against the app yet'}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
              <Btn testID={`wal-open-${w.shop_code}`} title="Open" size="sm" variant="primary" onPress={() => nav.push('Wallet', { uid: w.uid })} />
              <Btn testID={`wal-check-${w.shop_code}`} title="Check against the app" size="sm" variant="info" onPress={() => nav.push('BankCheck', { kind: 'wallet', walletUid: w.uid })} />
              <Btn title="Sales against receipts" size="sm" variant="secondary" onPress={() => nav.push('MpaisaMatch', { walletUid: w.uid })} />
            </View>
          </Card>
        );
      })}
      <Btn title="Import an M-PAiSA statement" icon="📄" size="md" variant="secondary" onPress={() => nav.push('MpaisaImport', {})} />
    </Screen>
  );
}
export function WalletScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const w = W.getWallet(params.uid) || W.listWallets()[0];
  const [mode, setMode] = useState('transfer');
  const [f, setF] = useState({ date: dateStr(), amount: '', fee: '', reference: '', note: '', type: 'adjust_out' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const [, bump] = useState(0);
  if (!w) return <Screen title="Wallet"><Banner tone="warn" message="No wallet yet." /></Screen>;
  const p = W.walletPosition(w.uid);
  const h = W.walletHistory(w.uid, { from: addDays(dateStr(), -45) });
  const doIt = () => {
    const r = act(() => (mode === 'transfer' ? W.recordWalletTransfer(user, { walletUid: w.uid, date: f.date, amount: f.amount, fee: f.fee, reference: f.reference, note: f.note })
      : W.recordWalletMove(user, { walletUid: w.uid, type: mode === 'fee' ? 'fee' : f.type, date: f.date, amount: f.amount, reference: f.reference, note: f.note })), 'Saved');
    if (r) { setF((o) => ({ ...o, amount: '', fee: '', reference: '', note: '' })); bump((n) => n + 1); }
  };
  return (
    <Screen title={w.name} subtitle={`${w.provider} · ${w.shop_code}`}>
      <Stats items={[{ label: 'In the wallet', value: $(p.balance), color: C.info, testID: 'wal-bal' }, { label: 'Till M-PAiSA sales (all)', value: $(p.sales) }, { label: 'On the way to BSP', value: $(p.transitTotal), color: p.transitTotal ? C.warn : undefined }]} />
      <Card>
        <Chips value={mode} onChange={setMode} testIDPrefix="wal-mode" options={[{ value: 'transfer', label: 'Transfer to BSP' }, { value: 'fee', label: 'Fee' }, { value: 'adjust', label: 'Correction' }]} />
        {mode === 'adjust' ? <Chips value={f.type} onChange={set('type')} options={[{ value: 'adjust_in', label: 'More in the wallet (+)' }, { value: 'adjust_out', label: 'Less in the wallet (−)' }]} /> : null}
        <DateField testID="wal-date" label="Date" value={f.date} onChange={set('date')} />
        <MoneyField testID="wal-amount" label="Amount" value={f.amount} onChange={set('amount')} />
        {mode === 'transfer' ? <MoneyField testID="wal-fee" label="Fee taken by M-PAiSA (if any)" value={f.fee} onChange={set('fee')} /> : null}
        <Field testID="wal-ref" label="Reference / transaction ID" value={f.reference} onChangeText={set('reference')} />
        <Field testID="wal-note" label={mode === 'adjust' ? 'Reason' : 'Note (optional)'} value={f.note} onChangeText={set('note')} />
        <Btn testID="wal-save" title="Save" icon="💾" variant="success" onPress={doIt} />
      </Card>
      <Section title="Last 45 days">
        {h.rows.map((r) => (
          <View key={r.uid} style={{ gap: 4 }}>
            <ListItem title={r.what} sub={`${r.date}${r.sub ? ` · ${r.sub}` : ''}`} right={signed(r.amount)} rightSub={`bal ${$(r.balance)}`} tone={r.type === 'transfer_bank' && !r.cleared ? 'warn' : undefined} />
            {r.kind === 'move' ? <ReasonButton title="Void" size="sm" prompt="Why is it wrong?" onDo={(why) => { const x = act(() => W.voidWalletMove(user, r.uid, why), 'Voided'); bump((n) => n + 1); return x; }} /> : null}
          </View>
        ))}
      </Section>
    </Screen>
  );
}
export function WalletSetupScreen() {
  const { user } = useApp();
  const act = useAct();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const [edit, setEdit] = useState(null);
  const list = W.listWallets({ includeInactive: true });
  const set = (k) => (v) => setEdit((o) => ({ ...o, [k]: v }));
  const shops = listCostAreas().filter((a) => a.kind === 'shop').map((a) => ({ value: a.code, label: a.name }));
  return (
    <Screen title="Wallets (money accounts)" subtitle="M-PAiSA now, MyCash later">
      {list.map((w) => (
        <ListItem key={w.uid} testID={`ws-${w.uid}`} title={w.name} sub={`${w.provider} · ${w.shop_code}${w.phone_no ? ` · ${w.phone_no}` : ''} · opening ${$(w.opening_balance)} on ${w.opening_date}`} badge={w.active ? null : 'off'} badgeColor={C.sub}
          onPress={() => setEdit({ uid: w.uid, name: w.name, provider: w.provider, shopCode: w.shop_code, phoneNo: w.phone_no || '', openingBalance: String(w.opening_balance), openingDate: w.opening_date, active: !!w.active })} />
      ))}
      <Btn testID="ws-add" title="+ Add a wallet (e.g. MyCash)" size="md" variant="secondary" onPress={() => setEdit({ name: '', provider: 'MyCash', shopCode: 'S1', phoneNo: '', openingBalance: '0', openingDate: dateStr(), active: true })} />
      {edit ? (
        <Card>
          <Field testID="ws-name" label="Name" value={edit.name} onChangeText={set('name')} />
          <Choice label="Kind" value={edit.provider} onChange={set('provider')} options={W.PROVIDERS.map((p) => ({ value: p, label: p }))} />
          <Choice label="Shop (whose till takes it)" value={edit.shopCode} onChange={set('shopCode')} options={shops} />
          <Field label="Wallet phone number" value={edit.phoneNo} onChangeText={set('phoneNo')} />
          <MoneyField label="Balance on the start date" value={edit.openingBalance} onChange={set('openingBalance')} />
          <DateField label="Start date" value={edit.openingDate} onChange={set('openingDate')} />
          <Chips value={edit.active ? 'y' : 'n'} onChange={(v) => set('active')(v === 'y')} options={[{ value: 'y', label: 'In use' }, { value: 'n', label: 'Not used' }]} />
          <Btn testID="ws-save" title="Save" variant="success" size="md" onPress={() => { if (act(() => W.saveWallet(user, edit), 'Saved')) setEdit(null); }} />
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- M-PAiSA statement import
export function MpaisaImportScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const wallets = W.listWallets();
  const [wid, setWid] = useState(params.walletUid || (wallets[0] && wallets[0].uid) || '');
  const w = W.getWallet(wid);
  const [text, setText] = useState('');
  const [rows, setRows] = useState(null);
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const cols = W.walletColumns(w ? w.provider : 'M-PAiSA');
  let parsed = null;
  if (rows) parsed = W.walletRowsToLines(rows, cols);
  else if (text) parsed = I.detectFormat(text) === 'csv' ? W.parseWalletCsv(text, cols) : W.parseWalletText(text, cols);
  const choose = async () => {
    try {
      const x = await pickStatementFile();
      if (!x) return;
      setFile(x); setDone(null);
      if (x.needsOnline) { ui.error(new Error(x.needsOnline)); return; }
      if (x.rows) { setRows(x.rows); setText(''); } else { setRows(null); setText(x.text || ''); }
    } catch (e) { ui.error(e); }
  };
  const go = async () => {
    setBusy(true);
    try {
      const dates = parsed.lines.map((l) => l.date).sort();
      let docUid = null;
      try { docUid = await archiveStatement(user, { refType: 'wallet_statement', refUid: wid, kind: 'wallet_statement', name: `${w.name} statement ${dates[0]} to ${dates[dates.length - 1]}`, docDate: dates[dates.length - 1] }, file, file ? null : text); } catch (e) { docUid = null; }
      const r = W.importWalletStatement(user, { walletUid: wid, lines: parsed.lines, source: file ? file.kind : 'paste', fileName: file && file.name, docUid });
      setDone(r); setText(''); setRows(null); setFile(null);
      ui.toast(`Imported ${r.added} line(s)`);
    } catch (e) { ui.error(e); } finally { setBusy(false); }
  };
  return (
    <Screen title="Import an M-PAiSA statement" subtitle="CSV, Excel, PDF or a screenshot">
      <Choice label="Wallet" value={wid} onChange={setWid} options={wallets.map((x) => ({ value: x.uid, label: x.name }))} testIDPrefix="mpi-wal" />
      <Hint>A PDF or a screenshot is read by Google, so it needs internet. CSV / Excel and pasted text work offline. If the columns are not found, set them in Settings › M-PAiSA statement columns.</Hint>
      {done ? (
        <Card tone={done.shiftsProblem ? 'danger' : 'success'}>
          <H>{`Imported ${done.added} line(s)${done.duplicates ? ` · ${done.duplicates} already in` : ''}`}</H>
          <Row label="Transfers to BSP matched" value={String(done.transfers)} />
          <Row label="Fees booked" value={String(done.fees)} />
          <Row label="Days where the shifts' M-PAiSA sales match" value={String(done.shiftsOk)} />
          <Row label="Days that do not match" value={String(done.shiftsProblem)} color={done.shiftsProblem ? C.danger : undefined} />
          <Btn testID="mpi-open" title="See sales against receipts" size="md" variant="primary" onPress={() => nav.push('MpaisaMatch', { walletUid: wid })} />
        </Card>
      ) : null}
      <Card>
        <Btn testID="mpi-file" title={file ? `File: ${file.name}` : 'Choose the statement file or screenshot'} icon="📂" variant="info" size="md" onPress={choose} />
        <Field testID="mpi-text" label="…or paste the statement" value={text} onChangeText={(v) => { setText(v); setRows(null); setFile(null); setDone(null); }} multiline />
      </Card>
      {parsed ? (
        <Card tone={parsed.lines.length ? 'info' : 'warn'}>
          <Text testID="mpi-read" style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Read {parsed.lines.length} line(s){parsed.skipped.length ? `, skipped ${parsed.skipped.length}` : ''}</Text>
          {!parsed.lines.length && parsed.headers ? <Text style={{ fontSize: 14, color: C.danger }}>Columns found: {(parsed.headers || []).join(' | ')} – set which is which in M-PAiSA statement columns.</Text> : null}
          {parsed.lines.slice(0, 10).map((l, i) => <Text key={i} style={{ fontSize: 14, color: C.sub }}>{l.date} {l.time} · {l.kind} · {l.description} · {signed(l.amount)}</Text>)}
          <Btn testID="mpi-go" title={busy ? 'Importing…' : `Import ${parsed.lines.length} line(s)`} icon="💾" variant="success" disabled={busy || !parsed.lines.length || !wid} onPress={go} />
        </Card>
      ) : null}
      <Btn title="M-PAiSA statement columns" icon="🧩" size="sm" variant="ghost" onPress={() => nav.push('MpaisaColumns', {})} />
    </Screen>
  );
}
const MATCH_COLOR = { ok: C.success, explained: C.success, short: C.danger, over: C.warn, no_statement: C.sub, day: C.info };
export function MpaisaMatchScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  try { W.ensureDefaultWallets(); } catch (e) { /* not ready */ }
  const wallets = W.listWallets();
  const [wid, setWid] = useState(params.walletUid || (wallets[0] && wallets[0].uid) || '');
  const [from, to, setRange] = usePeriod('thismonth');
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const [, bump] = useState(0);
  const days = wid ? W.shiftMatch(wid, from, to).slice().reverse() : [];
  const lines = wid ? W.walletLines(wid, { from, to, status: 'unmatched' }).filter((l) => l.kind !== 'receipt') : [];
  const explain = (key) => { if (act(() => W.explainShift(user, key, note, wid), 'Saved')) { setOpen(null); setNote(''); act(() => W.confirmShiftMatches(user, wid, from, to)); bump((n) => n + 1); } };
  return (
    <Screen title="M-PAiSA sales against the wallet" subtitle="Catches fake payment messages">
      <Choice label="Wallet" value={wid} onChange={setWid} options={wallets.map((x) => ({ value: x.uid, label: x.name }))} testIDPrefix="mpm-wal" />
      <PeriodPicker testID="mpm-period" from={from} to={to} onChange={setRange} />
      <Hint>Each shift's M-PAiSA figure (from its till balance) against the money that really arrived in the wallet. Red = the wallet got less than the till recorded: a customer may have shown a fake payment message.</Hint>
      {!days.length ? <Text style={{ fontSize: 16, color: C.sub }}>No M-PAiSA sales or receipts in this period.</Text> : null}
      {days.map((d) => (
        <Card key={d.date} tone={d.status === 'short' ? 'danger' : d.status === 'over' ? 'warn' : undefined}>
          <ListItem testID={`mpm-${d.date}`} title={`${d.date} · ${W.MATCH_LABEL[d.status]}`} sub={`Till ${$(d.dayTill)} · wallet ${$(d.dayWallet)}${d.note ? ` · ${d.note}` : ''}`} right={signed(d.dayDiff)} badge={d.status === 'short' ? 'CHECK' : null} badgeColor={MATCH_COLOR[d.status]}
            onPress={() => setOpen(open === d.date ? null : d.date)} />
          {open === d.date ? (
            <View style={{ gap: 6, marginTop: 6 }}>
              {d.shifts.map((s) => (
                <View key={s.countUid} style={{ gap: 4 }}>
                  <Row label={`${s.till} ${s.shift} (${s.cashier})`} value={`till ${$(s.tillAmount)} · wallet ${d.perShift ? $(s.walletAmount) : '—'}`} color={MATCH_COLOR[s.status]} />
                  {['short', 'over'].includes(s.status) ? <Btn testID={`mpm-explain-${s.countUid}`} title="Explain this shift" size="sm" variant="secondary" onPress={() => setOpen(`${d.date}|${s.countUid}`)} /> : null}
                </View>
              ))}
              {['short', 'over'].includes(d.status) ? <Btn testID="mpm-explain-day" title="Explain the day" size="sm" variant="secondary" onPress={() => setOpen(`${d.date}|${wid}:${d.date}`)} /> : null}
            </View>
          ) : null}
          {open && open.startsWith(`${d.date}|`) ? (
            <View style={{ gap: 6 }}>
              <Field testID="mpm-note" label="What happened?" value={note} onChangeText={setNote} multiline />
              <Btn testID="mpm-save" title="Save" size="sm" variant="success" onPress={() => explain(open.split('|')[1])} />
            </View>
          ) : null}
        </Card>
      ))}
      <Section title={`Statement lines to sort (${lines.length})`}>
        {lines.map((l) => (
          <Card key={l.uid}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.line_date} {l.line_time || ''} · {l.description} · {signed(l.amount)}</Text>
            {l.amount < 0 ? <Btn testID={`mpm-tr-${l.uid}`} title="It was a transfer to BSP – record it" size="sm" variant="success" onPress={() => { act(() => W.transferFromLine(user, l.uid), 'Recorded'); bump((n) => n + 1); }} /> : null}
            <ReasonButton title="Put aside" size="sm" prompt="Why?" onDo={(why) => { const x = act(() => W.ignoreWalletLine(user, l.uid, why), 'Put aside'); bump((n) => n + 1); return x; }} />
          </Card>
        ))}
      </Section>
    </Screen>
  );
}
export function MpaisaColumnsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [provider, setProvider] = useState('M-PAiSA');
  const [cols, setCols] = useState(W.walletColumns('M-PAiSA'));
  const [sample, setSample] = useState('');
  const pick = (p) => { setProvider(p); setCols(W.walletColumns(p)); };
  const headers = sample ? I.splitCsv(sample.split(/\r?\n/)[0]) : [];
  const map = headers.length ? W.mapHeaders(headers, cols) : null;
  return (
    <Screen title="M-PAiSA statement columns" subtitle="Which column is which">
      <Explain>Write the heading words of each column as they appear on the statement (several words separated by | ). This can be fine-tuned when a real statement arrives.</Explain>
      <Chips value={provider} onChange={pick} options={W.PROVIDERS.map((p) => ({ value: p, label: p }))} />
      <Card>
        {W.COLUMN_FIELDS.map(([k, label]) => <Field key={k} testID={`col-${k}`} label={label} value={cols[k] || ''} onChangeText={(v) => setCols((o) => ({ ...o, [k]: v }))} />)}
        <Label>Dates are written</Label>
        <Chips value={cols.dateOrder || 'dmy'} onChange={(v) => setCols((o) => ({ ...o, dateOrder: v }))} options={[{ value: 'dmy', label: 'day/month/year' }, { value: 'mdy', label: 'month/day/year' }, { value: 'ymd', label: 'year-month-day' }]} />
        <Btn testID="col-save" title="Save" variant="success" size="md" onPress={() => act(() => W.saveWalletColumns(user, provider, cols), 'Saved')} />
      </Card>
      <Card>
        <Field testID="col-sample" label="Try it: paste the heading line of a statement" value={sample} onChangeText={setSample} />
        {map ? W.COLUMN_FIELDS.map(([k, label]) => <Row key={k} label={label} value={map[k] === undefined ? '— not found' : headers[map[k]]} color={map[k] === undefined ? C.sub : C.success} />) : null}
      </Card>
    </Screen>
  );
}

// ---------------------------------------------------------------- bank rules: settings card (Bank rules screen)
export function BankSettingsCard() {
  const { user } = useApp();
  const act = useAct();
  const [s, setS] = useState(P.bankSettings());
  const set = (k) => (v) => setS((o) => ({ ...o, [k]: v }));
  const yes = (k, label) => <Chips value={s[k] ? 'y' : 'n'} onChange={(v) => set(k)(v === 'y')} testIDPrefix={`bs-${k}`} options={[{ value: 'y', label: `${label}: on` }, { value: 'n', label: 'off' }]} />;
  return (
    <Card>
      <H>Reminders and limits</H>
      <Field testID="bs-verify" label="Verification days (a cheque or deposit waiting longer turns red)" value={String(s.verifyDays)} onChangeText={set('verifyDays')} keyboardType="number-pad" />
      {yes('mobileCheckOn', 'Home reminder to check against BSP mobile banking')}
      <Field testID="bs-mobile-days" label="Remind after this many days without a check" value={String(s.mobileCheckDays)} onChangeText={set('mobileCheckDays')} keyboardType="number-pad" />
      {yes('walletCheckOn', 'Reminder to check each wallet against the M-PAiSA app')}
      <Field label="Wallet reminder after days" value={String(s.walletCheckDays)} onChangeText={set('walletCheckDays')} keyboardType="number-pad" />
      {yes('autoFees', 'Statement import books bank fees and interest by itself')}
      <Field label="Words for bank fees" value={s.feeWords} onChangeText={set('feeWords')} />
      <Field label="Words for interest" value={s.interestWords} onChangeText={set('interestWords')} />
      <Field label="Words for M-PAiSA transfers" value={s.mpaisaWords} onChangeText={set('mpaisaWords')} />
      <MoneyField label="A line this big is unusual" value={String(s.unusualAmount)} onChange={set('unusualAmount')} />
      <Field label="…or this many times the usual for that payee" value={String(s.unusualTimes)} onChangeText={set('unusualTimes')} keyboardType="number-pad" />
      <MoneyField label="Deposit within this of a slip = slip difference" value={String(s.slipTolerance)} onChange={set('slipTolerance')} />
      <Label>EFTPOS (not used yet)</Label>
      {yes('eftposOn', 'Expect EFTPOS settlements in the bank')}
      <Field label="Days until the bank pays card takings" value={String(s.eftposDays)} onChangeText={set('eftposDays')} keyboardType="number-pad" />
      <Field label="% the bank keeps" value={String(s.eftposFeePct)} onChangeText={set('eftposFeePct')} keyboardType="decimal-pad" />
      <Hint>{`Cheques are "stale" after ${apRules().staleMonths} months (Invoice rules).`}</Hint>
      <Btn testID="bs-save" title="Save reminders and limits" size="md" variant="success" onPress={() => act(() => setS(P.saveBankSettings(user, s)), 'Saved')} />
    </Card>
  );
}
