// Bank reconciliation screens: statements per account, adding one (paste or type), matching its lines.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain } from '../../../ui/kit.js';
import { Select } from '../../../ui/components.js';
import { pickTextFile } from '../../../platform/files.js';
import * as BX from '../extras.js';
import { listAccountsGL } from '../../accounting/service.js';
import { dateStr, addDays } from '../../../services/core.js';
import { listAccounts } from '../../payables/service.js';
import * as B from '../service.js';

const { $ } = B;

export function BankRecScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const accounts = listAccounts();
  const [acc, setAcc] = useState(params.accountUid || (accounts[0] && accounts[0].uid) || '');
  const [date, setDate] = useState(dateStr());
  const [closing, setClosing] = useState('');
  const [, bump] = useState(0);
  const list = acc ? B.listStatements(acc) : [];
  const u = acc ? B.uncleared(acc, date) : null;
  let check = null;
  try { check = acc && closing !== '' ? B.balanceCheckFor(acc, date, closing) : null; } catch (e) { check = null; }
  const tick = (item) => { act(() => B.tickCleared(user, item, date)); bump((n) => n + 1); };
  const row = (item, title, sub, amount, sign) => (
    <ListItem key={item.uid} testID={`unc-${item.kind}-${item.cheque_no || item.reference || item.uid}`} title={title} sub={sub} right={`${sign}${$(amount)}`}
      badge="tap when on statement" badgeColor={C.info} onPress={() => tick(item)} />
  );
  return (
    <Screen title="Bank reconciliation" subtitle="Tick what is on the BSP statement">
      {!accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices & cheques › Cheques & bank › Accounts." /> : null}
      {(() => { const a = BX.bankAlerts(); return a.oldUnmatched || a.uncoded ? <Banner tone="warn" message={`${a.oldUnmatched ? `${a.oldUnmatched} statement line(s) unmatched for over 10 days. ` : ''}${a.uncoded ? `${a.uncoded} bank line(s) not booked to an account (Bank rules).` : ''}`} /> : null; })()}
      <Hint>Reconciling = checking every deposit, cheque and payment in the app also shows on the bank statement, and the balances agree. It is step 2 for money that goes through the bank.</Hint>
      {accounts.length > 1 ? <Chips value={acc} onChange={setAcc} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
      {acc ? (
        <>
          <Card>
            <H>1. The statement</H>
            <DateField testID="rec-date" label="Statement date (last day on it)" value={date} onChange={setDate} />
            <MoneyField testID="rec-closing" label="Closing balance on the statement" value={closing} onChange={setClosing} />
          </Card>
          <Section title={`2. Waiting to show on the statement (${u.cheques.length + u.ins.length + u.outs.length})`}>
            <Text style={{ fontSize: 15, color: C.sub }}>Deposits, cheques, transfers and fees recorded in the app up to {date}. Tap each one you can see on the statement.</Text>
            {u.ins.map((e) => row(e, `${e.type === 'deposit' ? 'Deposit' : e.type === 'interest' ? 'Interest' : 'Correction +'}${e.reference ? ` · ${e.reference}` : ''}`, `${e.entry_date}${e.note ? ` · ${e.note}` : ''}`, e.amount, '+'))}
            {u.cheques.map((c) => row(c, `Cheque ${c.cheque_no} · ${c.payee || ''}`, c.cheque_date, c.amount, '−'))}
            {u.outs.map((e) => row(e, `${e.type === 'transfer_out' ? 'Transfer' : e.type === 'fee' ? 'Bank fee' : 'Correction −'}${e.reference ? ` · ${e.reference}` : ''}`, `${e.entry_date}${e.note ? ` · ${e.note}` : ''}`, e.amount, '−'))}
            {!(u.cheques.length + u.ins.length + u.outs.length) ? <Text style={{ fontSize: 16, color: C.success }}>Everything recorded is already on a statement.</Text> : null}
          </Section>
          {check ? (
            <Card tone={check.balanced ? 'success' : 'danger'}>
              <H>3. Result</H>
              <Row label="Cheque book balance" value={$(check.balance)} />
              <Row label="+ Cheques not ticked" value={$(check.chequesOut)} />
              <Row label="− Deposits not ticked" value={$(check.depositsInTransit)} />
              <Row label="+ Transfers / fees not ticked" value={$(check.otherOut)} />
              <Row label="= Statement should show" value={$(check.expected)} bold />
              <Row label="Statement shows" value={$(closing)} bold />
              <Row label="Difference" value={$(check.difference)} bold color={check.balanced ? C.success : C.danger} />
              {!check.balanced ? <Text style={{ fontSize: 15, color: C.text, marginTop: 6 }}>Something on the statement is not in the app (a bank fee, interest, a direct deposit or debit)? Add it in Invoices & cheques › Cheques & bank › Deposits & fees, or paste the statement below.</Text> : null}
              <Btn testID="rec-save" title={check.balanced ? 'Save – balanced' : 'Save with the difference'} variant={check.balanced ? 'success' : 'warn'} style={{ marginTop: 10 }}
                onPress={() => act(() => B.recordReconciliation(user, { accountUid: acc, date, closing }), 'Reconciliation saved')} />
            </Card>
          ) : null}
          <Btn testID="st-new" title="Or add the statement (CSV file / paste / type)" icon="📋" variant="secondary" size="md" onPress={() => nav.push('StatementNew', { accountUid: acc })} />
          <Btn testID="bank-rules" title="Bank rules & lines to book" icon="⚙️" variant="ghost" size="sm" onPress={() => nav.push('BankRules')} />
          <Section title="Saved reconciliations">
            {list.map((s) => (
              <ListItem key={s.uid} testID={`st-${s.to_date}`} onPress={s.lines ? () => nav.push('Statement', { uid: s.uid }) : null} title={`${s.from_date} to ${s.to_date}`}
                sub={`${s.lines ? `${s.lines} lines · ` : 'ticked · '}by ${s.by_name}${s.status === 'reconciled' ? ` · done by ${s.reconciled_by_name}` : ''}`} right={$(s.closing)} rightSub="closing"
                badge={s.status === 'reconciled' ? (Math.abs(s.difference || 0) < 0.005 ? 'Balanced' : `Out ${$(s.difference)}`) : `${s.unmatched} to match`}
                badgeColor={s.status === 'reconciled' ? (Math.abs(s.difference || 0) < 0.005 ? C.success : C.danger) : C.warn} />
            ))}
          </Section>
        </>
      ) : null}
    </Screen>
  );
}

export function StatementNewScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [f, setF] = useState({ fromDate: addDays(dateStr(), -30), toDate: dateStr(), opening: '', closing: '', text: '', notes: '' });
  const [typed, setTyped] = useState([]);
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const parsed = B.parseStatementText(f.text);
  const lines = parsed.lines.concat(typed.filter((l) => l.date && Number(l.amount)).map((l) => ({ date: l.date, description: l.description, reference: (/(\d{4,10})/.exec(l.description || '') || [])[1] || '', amount: Number(l.amount) })));
  const sum = lines.reduce((s, l) => s + l.amount, 0);
  const save = () => {
    try {
      const uid = B.addStatement(user, { accountUid: params.accountUid, ...f, lines });
      ui.toast('Statement added – matching done');
      nav.replace('Statement', { uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Add a bank statement" footer={<Btn testID="st-save" title={`Add ${lines.length} line(s)`} icon="💾" variant="success" onPress={save} />}>
      <Card>
        <DateField testID="st-from" label="Statement from" value={f.fromDate} onChange={set('fromDate')} />
        <DateField testID="st-to" label="Statement to" value={f.toDate} onChange={set('toDate')} />
        <MoneyField testID="st-open" label="Opening balance (optional, used to check)" value={f.opening} onChange={set('opening')} />
        <MoneyField testID="st-close" label="Closing balance" value={f.closing} onChange={set('closing')} />
      </Card>
      <Card>
        <H>Paste from internet banking</H>
        <Text style={{ fontSize: 15, color: C.sub }}>Copy the lines (date, description, amount) from the BSP statement or CSV and paste them here. Money out as minus, or in separate debit / credit columns.</Text>
        <Btn testID="st-file" title="Choose the CSV file from internet banking" icon="📂" size="md" variant="info" onPress={async () => { try { const x = await pickTextFile(); if (x) set('text')(x.text); } catch (e) { ui.error(e); } }} />
        <Field testID="st-text" label="Statement lines" value={f.text} onChangeText={set('text')} multiline />
        {f.text ? <Text style={{ fontSize: 15, color: parsed.skipped.length ? C.warn : C.success }}>Read {parsed.lines.length} line(s){parsed.skipped.length ? `, skipped ${parsed.skipped.length} (headings or unreadable)` : ''}.</Text> : null}
      </Card>
      <Card>
        <H>…or type the lines</H>
        {typed.map((l, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field label="Date" value={l.date} onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, date: v } : x)))} placeholder="YYYY-MM-DD" /></View>
            <View style={{ flexBasis: 200, flexGrow: 2 }}><Field label="Description" value={l.description} onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, description: v } : x)))} /></View>
            <View style={{ flexBasis: 120, flexGrow: 1 }}><Field label="Amount (− out)" value={l.amount} keyboardType="numbers-and-punctuation" onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setTyped(typed.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Line" size="sm" variant="secondary" onPress={() => setTyped(typed.concat([{ date: f.toDate, description: '', amount: '' }]))} />
      </Card>
      <Card>
        <Row label="Lines" value={String(lines.length)} />
        <Row label="Money in" value={$(lines.filter((l) => l.amount > 0).reduce((s, l) => s + l.amount, 0))} />
        <Row label="Money out" value={$(-lines.filter((l) => l.amount < 0).reduce((s, l) => s + l.amount, 0))} />
        {f.opening !== '' ? <Row label="Opening + lines" value={$(Number(f.opening) + sum)} bold color={f.closing !== '' && Math.abs(Number(f.opening) + sum - Number(f.closing)) < 0.005 ? C.success : C.danger} /> : null}
      </Card>
    </Screen>
  );
}

// One bank line that is several things (e.g. loan repayment + interest): split it over accounts.
function SplitBox({ line, onDo }) {
  const [open, setOpen] = useState(false);
  const [parts, setParts] = useState([{ code: '', amount: '' }, { code: '', amount: '' }]);
  const accts = listAccountsGL().filter((a) => !a.code.startsWith('1100:')).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }));
  if (!open) return <Btn title="Split over several accounts" size="sm" variant="ghost" onPress={() => setOpen(true)} />;
  const sum = parts.reduce((s, p) => s + (Number(p.amount) || 0), 0);
  return (
    <Card>
      <Hint>{`Split ${$(Math.abs(line.amount))} – e.g. loan repayment to "Loans" and the interest to "Interest paid".`}</Hint>
      {parts.map((p, i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <View style={{ flexBasis: 240, flexGrow: 2 }}><Select label="Account" value={p.code} onChange={(v) => setParts(parts.map((x, k) => (k === i ? { ...x, code: v } : x)))} options={accts} /></View>
          <View style={{ flexBasis: 120, flexGrow: 1 }}><MoneyField label="Amount" value={p.amount} onChange={(v) => setParts(parts.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
        </View>
      ))}
      <Btn title="+ part" size="sm" variant="secondary" onPress={() => setParts(parts.concat([{ code: '', amount: '' }]))} />
      <Row label="Parts add up to" value={$(sum)} color={Math.abs(sum - Math.abs(line.amount)) < 0.005 ? C.success : C.danger} />
      <Btn title="Split and match" size="sm" variant="success" onPress={() => onDo(line.amount > 0 ? 'adjust_in' : 'transfer_out', parts)} />
    </Card>
  );
}

// Bank rules and coding bank lines to accounts.
export function BankRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const [rules, setRules] = useState(BX.bankRules());
  const accts = listAccountsGL().filter((a) => !a.code.startsWith('1100:')).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }));
  const unc = BX.uncodedEntries();
  const TYPES_IN = [['deposit', 'Money in (e.g. card settlement)'], ['interest', 'Interest'], ['adjust_in', 'Other money in']];
  const TYPES_OUT = [['fee', 'Bank fee'], ['transfer_out', 'Direct debit / transfer'], ['adjust_out', 'Other money out']];
  return (
    <Screen title="Bank rules" subtitle="Lines the app codes by itself">
      <Explain>Some lines come every month (EFTPOS settlements, bank fees, loan direct debits). Tell the app the words that appear on the statement and what they are; when a statement is added those lines are recorded and matched by themselves.</Explain>
      {rules.map((r, i) => (
        <Card key={i}>
          <Field label="When the description contains" value={r.contains} onChangeText={(v) => setRules(rules.map((x, k) => (k === i ? { ...x, contains: v } : x)))} placeholder="e.g. EFTPOS SETTLEMENT" />
          <Chips value={r.direction} onChange={(v) => setRules(rules.map((x, k) => (k === i ? { ...x, direction: v, type: v === 'in' ? 'deposit' : 'fee' } : x)))} options={[{ value: 'in', label: 'Money in' }, { value: 'out', label: 'Money out' }]} />
          <Chips value={r.type} onChange={(v) => setRules(rules.map((x, k) => (k === i ? { ...x, type: v } : x)))} options={(r.direction === 'in' ? TYPES_IN : TYPES_OUT).map(([value, label]) => ({ value, label }))} />
          <Select label="Book it to" value={r.glCode || ''} onChange={(v) => setRules(rules.map((x, k) => (k === i ? { ...x, glCode: v } : x)))} options={[{ value: '', label: 'Usual account for the type' }].concat(accts)} />
          <Btn title="Remove rule" size="sm" variant="ghost" onPress={() => setRules(rules.filter((_, k) => k !== i))} />
        </Card>
      ))}
      <Btn title="+ Rule" size="md" variant="secondary" onPress={() => setRules(rules.concat([{ contains: '', direction: 'out', type: 'fee', glCode: '' }]))} />
      <Btn testID="br-save" title="Save rules" size="md" variant="success" onPress={() => act(() => BX.saveBankRules(user, rules), 'Saved')} />
      <Section title={`Bank lines not booked to an account (${unc.length})`}>
        <Hint>These sit in "Suspense" in the books until you say what they were.</Hint>
        {unc.map((e) => (
          <Card key={e.uid}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{e.entry_date} · {e.reference || e.note || e.type} · {$(e.amount)}</Text>
            <Select label="It was" value="" onChange={(v) => act(() => BX.codeEntry(user, e.uid, v), 'Booked')} options={accts} />
          </Card>
        ))}
      </Section>
    </Screen>
  );
}

export function StatementScreen({ params }) {
  const { user } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const r = B.reconcileSummary(params.uid);
  const s = r.statement;
  const done = s.status === 'reconciled';
  return (
    <Screen title={`Statement to ${s.to_date}`} subtitle={`${s.account_name} · closing ${$(s.closing)}`}>
      <Banner testID="st-state" tone={r.unmatched.length ? 'warn' : r.check.balanced ? 'success' : 'danger'}
        title={r.unmatched.length ? `${r.unmatched.length} line(s) to match` : r.check.balanced ? 'Balanced ✓' : `Out by ${$(r.check.difference)}`}
        message={`${r.matched} matched${r.ignored ? `, ${r.ignored} ignored` : ''}. ${done ? `Reconciled by ${s.reconciled_by_name}.` : ''}`} />
      {!done ? <Btn title="Match again automatically" size="md" variant="secondary" onPress={() => act(() => B.autoMatch(user, s.uid), 'Done')} /> : null}
      <Section title="To match">
        {!r.unmatched.length ? <Text style={{ fontSize: 16, color: C.sub }}>Every line is matched.</Text> : null}
        {r.unmatched.map((l) => {
          const cands = open === l.uid ? B.candidates(l) : [];
          return (
            <View key={l.uid} style={{ gap: 6 }}>
              <ListItem testID={`line-${l.amount}`} onPress={() => { setOpen(open === l.uid ? null : l.uid); setNote(''); }} title={l.description || '(no description)'} sub={`${l.line_date}${l.reference ? ` · ref ${l.reference}` : ''}`}
                right={`${l.amount > 0 ? '+' : '−'}${$(Math.abs(l.amount))}`} tone="warn" />
              {open === l.uid ? (
                <Card>
                  {cands.length ? <Label>Is it one of these?</Label> : <Text style={{ fontSize: 15, color: C.sub }}>Nothing in the app has this amount. Add it below, or find what is missing.</Text>}
                  {cands.map((c) => <Btn key={c.uid} testID={`cand-${c.uid}`} title={`${c.label} (${$(c.amount)})`} size="sm" variant="info" style={{ marginBottom: 6 }} onPress={() => act(() => B.matchLine(user, l.uid, c), 'Matched')} />)}
                  {(() => { const combo = BX.suggestCombination(l); return combo ? (
                    <Card tone="success">
                      <Text style={{ fontSize: 15, color: C.text }}>These {combo.length} add up to this line: {combo.map((c) => `${c.label} (${$(c.amount)})`).join(' + ')}</Text>
                      <Btn testID="combo-ok" title="Match all of them" size="sm" variant="success" onPress={() => act(() => BX.matchMany(user, l.uid, combo), 'Matched')} />
                    </Card>) : null; })()}
                  <Label>New in the app</Label>
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                    {(l.amount > 0 ? [['deposit', 'Deposit'], ['interest', 'Interest'], ['adjust_in', 'Correction +']] : [['fee', 'Bank fee'], ['transfer_out', 'Transfer / direct debit'], ['adjust_out', 'Correction −']]).map(([t, label]) => (
                      <Btn key={t} testID={`new-${t}`} title={label} size="sm" variant="secondary" onPress={() => act(() => B.createFromLine(user, l.uid, t, note), 'Added and matched')} />
                    ))}
                  </View>
                  <Field label="Note (needed for a correction or to ignore)" value={note} onChangeText={setNote} />
                  <SplitBox line={l} onDo={(type, parts) => act(() => BX.createSplit(user, l.uid, type, parts, note), 'Split and matched')} />
                  <Btn title="Ignore this line" size="sm" variant="ghost" onPress={() => act(() => B.ignoreLine(user, l.uid, note), 'Ignored')} />
                </Card>
              ) : null}
            </View>
          );
        })}
      </Section>
      <Card>
        <Row label="Cheque book balance" value={$(r.check.balance)} />
        <Row label="+ Cheques not cleared" value={$(r.check.chequesOut)} />
        <Row label="− Deposits not on the statement" value={$(r.check.depositsInTransit)} />
        <Row label="+ Other money out not on the statement" value={$(r.check.otherOut)} />
        <Row label="= Statement should show" value={$(r.check.expected)} bold />
        <Row label="Statement shows" value={$(s.closing)} bold />
        <Row label="Difference" value={$(r.check.difference)} bold color={r.check.balanced ? C.success : C.danger} />
      </Card>
      <Section title="Matched">
        {s.lines.filter((l) => l.status !== 'unmatched').map((l) => (
          <ListItem key={l.uid} title={l.description || '(no description)'} sub={`${l.line_date} · ${l.status === 'ignored' ? `ignored: ${l.note}` : `matched to ${l.match_type}`}`} right={$(l.amount)}
            onPress={done ? null : () => act(() => B.unmatchLine(user, l.uid), 'Un-matched')} />
        ))}
      </Section>
      {!done ? <Btn testID="st-finish" title="Finish reconciliation" icon="✅" variant="success" onPress={() => act(() => B.finishStatement(user, s.uid), 'Reconciliation saved')} /> : null}
    </Screen>
  );
}
