// Bank reconciliation screens: statements per account, adding one (paste or type), matching its lines.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { listAccounts } from '../../payables/service.js';
import * as B from '../service.js';

const { $ } = B;

export function BankRecScreen({ params }) {
  const { nav } = useApp();
  const accounts = listAccounts();
  const [acc, setAcc] = useState(params.accountUid || (accounts[0] && accounts[0].uid) || '');
  const list = acc ? B.listStatements(acc) : [];
  return (
    <Screen title="Bank reconciliation" subtitle="Match the BSP statement to the cheque book"
      footer={acc ? <Btn testID="st-new" title="Add a bank statement" icon="➕" variant="success" onPress={() => nav.push('StatementNew', { accountUid: acc })} /> : null}>
      {!accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices & cheques › Cheques & bank › Accounts." /> : null}
      {accounts.length > 1 ? <Chips value={acc} onChange={setAcc} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
      {list.map((s) => (
        <ListItem key={s.uid} testID={`st-${s.to_date}`} onPress={() => nav.push('Statement', { uid: s.uid })} title={`${s.from_date} to ${s.to_date}`}
          sub={`${s.lines} lines · by ${s.by_name}${s.status === 'reconciled' ? ` · done by ${s.reconciled_by_name}` : ''}`} right={$(s.closing)} rightSub="closing"
          badge={s.status === 'reconciled' ? (Math.abs(s.difference) < 0.005 ? 'Balanced' : `Out ${$(s.difference)}`) : `${s.unmatched} to match`}
          badgeColor={s.status === 'reconciled' ? (Math.abs(s.difference) < 0.005 ? C.success : C.danger) : C.warn} />
      ))}
      {acc && !list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No statements yet. Download the statement from BSP internet banking (CSV) and paste it in, or type the lines.</Text> : null}
    </Screen>
  );
}

export function StatementNewScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [f, setF] = useState({ fromDate: addDays(dateStr(), -30), toDate: dateStr(), opening: '', closing: '', text: '', notes: '' });
  const [typed, setTyped] = useState([]);
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const parsed = B.parseStatementText(f.text);
  const lines = parsed.lines.concat(typed.filter((l) => l.date && Number(l.amount)).map((l) => ({ date: l.date, description: l.description, reference: (/(\d{4,10})/.exec(l.description || '') || [])[1] || '', amount: Number(l.amount) })));
  const sum = lines.reduce((s, l) => s + l.amount, 0);
  const save = () => {
    try {
      const uid = B.addStatement(user, { accountUid: params.accountUid, ...f, lines });
      ui.toast('Statement added – matching done');
      nav.replace('Statement', { uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Add a bank statement" footer={<Btn testID="st-save" title={`Add ${lines.length} line(s)`} icon="💾" variant="success" onPress={save} />}>
      <Card>
        <DateField testID="st-from" label="Statement from" value={f.fromDate} onChange={set('fromDate')} />
        <DateField testID="st-to" label="Statement to" value={f.toDate} onChange={set('toDate')} />
        <MoneyField testID="st-open" label="Opening balance (optional, used to check)" value={f.opening} onChange={set('opening')} />
        <MoneyField testID="st-close" label="Closing balance" value={f.closing} onChange={set('closing')} />
      </Card>
      <Card>
        <H>Paste from internet banking</H>
        <Text style={{ fontSize: 15, color: C.sub }}>Copy the lines (date, description, amount) from the BSP statement or CSV and paste them here. Money out as minus, or in separate debit / credit columns.</Text>
        <Field testID="st-text" label="Statement lines" value={f.text} onChangeText={set('text')} multiline />
        {f.text ? <Text style={{ fontSize: 15, color: parsed.skipped.length ? C.warn : C.success }}>Read {parsed.lines.length} line(s){parsed.skipped.length ? `, skipped ${parsed.skipped.length} (headings or unreadable)` : ''}.</Text> : null}
      </Card>
      <Card>
        <H>…or type the lines</H>
        {typed.map((l, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field label="Date" value={l.date} onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, date: v } : x)))} placeholder="YYYY-MM-DD" /></View>
            <View style={{ flexBasis: 200, flexGrow: 2 }}><Field label="Description" value={l.description} onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, description: v } : x)))} /></View>
            <View style={{ flexBasis: 120, flexGrow: 1 }}><Field label="Amount (− out)" value={l.amount} keyboardType="numbers-and-punctuation" onChangeText={(v) => setTyped(typed.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setTyped(typed.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Line" size="sm" variant="secondary" onPress={() => setTyped(typed.concat([{ date: f.toDate, description: '', amount: '' }]))} />
      </Card>
      <Card>
        <Row label="Lines" value={String(lines.length)} />
        <Row label="Money in" value={$(lines.filter((l) => l.amount > 0).reduce((s, l) => s + l.amount, 0))} />
        <Row label="Money out" value={$(-lines.filter((l) => l.amount < 0).reduce((s, l) => s + l.amount, 0))} />
        {f.opening !== '' ? <Row label="Opening + lines" value={$(Number(f.opening) + sum)} bold color={f.closing !== '' && Math.abs(Number(f.opening) + sum - Number(f.closing)) < 0.005 ? C.success : C.danger} /> : null}
      </Card>
    </Screen>
  );
}

export function StatementScreen({ params }) {
  const { user } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const r = B.reconcileSummary(params.uid);
  const s = r.statement;
  const done = s.status === 'reconciled';
  return (
    <Screen title={`Statement to ${s.to_date}`} subtitle={`${s.account_name} · closing ${$(s.closing)}`}>
      <Banner testID="st-state" tone={r.unmatched.length ? 'warn' : r.check.balanced ? 'success' : 'danger'}
        title={r.unmatched.length ? `${r.unmatched.length} line(s) to match` : r.check.balanced ? 'Balanced ✓' : `Out by ${$(r.check.difference)}`}
        message={`${r.matched} matched${r.ignored ? `, ${r.ignored} ignored` : ''}. ${done ? `Reconciled by ${s.reconciled_by_name}.` : ''}`} />
      {!done ? <Btn title="Match again automatically" size="md" variant="secondary" onPress={() => act(() => B.autoMatch(user, s.uid), 'Done')} /> : null}
      <Section title="To match">
        {!r.unmatched.length ? <Text style={{ fontSize: 16, color: C.sub }}>Every line is matched.</Text> : null}
        {r.unmatched.map((l) => {
          const cands = open === l.uid ? B.candidates(l) : [];
          return (
            <View key={l.uid} style={{ gap: 6 }}>
              <ListItem testID={`line-${l.amount}`} onPress={() => { setOpen(open === l.uid ? null : l.uid); setNote(''); }} title={l.description || '(no description)'} sub={`${l.line_date}${l.reference ? ` · ref ${l.reference}` : ''}`}
                right={`${l.amount > 0 ? '+' : '−'}${$(Math.abs(l.amount))}`} tone="warn" />
              {open === l.uid ? (
                <Card>
                  {cands.length ? <Label>Is it one of these?</Label> : <Text style={{ fontSize: 15, color: C.sub }}>Nothing in the app has this amount. Add it below, or find what is missing.</Text>}
                  {cands.map((c) => <Btn key={c.uid} testID={`cand-${c.uid}`} title={`${c.label} (${$(c.amount)})`} size="sm" variant="info" style={{ marginBottom: 6 }} onPress={() => act(() => B.matchLine(user, l.uid, c), 'Matched')} />)}
                  <Label>New in the app</Label>
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                    {(l.amount > 0 ? [['deposit', 'Deposit'], ['interest', 'Interest'], ['adjust_in', 'Correction +']] : [['fee', 'Bank fee'], ['transfer_out', 'Transfer / direct debit'], ['adjust_out', 'Correction −']]).map(([t, label]) => (
                      <Btn key={t} testID={`new-${t}`} title={label} size="sm" variant="secondary" onPress={() => act(() => B.createFromLine(user, l.uid, t, note), 'Added and matched')} />
                    ))}
                  </View>
                  <Field label="Note (needed for a correction or to ignore)" value={note} onChangeText={setNote} />
                  <Btn title="Ignore this line" size="sm" variant="ghost" onPress={() => act(() => B.ignoreLine(user, l.uid, note), 'Ignored')} />
                </Card>
              ) : null}
            </View>
          );
        })}
      </Section>
      <Card>
        <Row label="Cheque book balance" value={$(r.check.balance)} />
        <Row label="+ Cheques not cleared" value={$(r.check.chequesOut)} />
        <Row label="− Deposits not on the statement" value={$(r.check.depositsInTransit)} />
        <Row label="+ Other money out not on the statement" value={$(r.check.otherOut)} />
        <Row label="= Statement should show" value={$(r.check.expected)} bold />
        <Row label="Statement shows" value={$(s.closing)} bold />
        <Row label="Difference" value={$(r.check.difference)} bold color={r.check.balanced ? C.success : C.danger} />
      </Card>
      <Section title="Matched">
        {s.lines.filter((l) => l.status !== 'unmatched').map((l) => (
          <ListItem key={l.uid} title={l.description || '(no description)'} sub={`${l.line_date} · ${l.status === 'ignored' ? `ignored: ${l.note}` : `matched to ${l.match_type}`}`} right={$(l.amount)}
            onPress={done ? null : () => act(() => B.unmatchLine(user, l.uid), 'Un-matched')} />
        ))}
      </Section>
      {!done ? <Btn testID="st-finish" title="Finish reconciliation" icon="✅" variant="success" onPress={() => act(() => B.finishStatement(user, s.uid), 'Reconciliation saved')} /> : null}
    </Screen>
  );
}
