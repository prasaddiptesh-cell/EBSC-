// Release 05 – Money & bank › Settings › How the accounts connect (owner / admin), and Move money between accounts.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Select, Label, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, Hint, Explain } from '../../../ui/kit.js';
import { dateStr, money } from '../../../services/core.js';
import { listCostAreas } from '../../../services/costAreas.js';
import * as LK from '../links05.js';

const KIND_OPTS = Object.entries(LK.ACCOUNT_KINDS).map(([value, label]) => ({ value, label }));
const shopOptions = () => [{ value: '', label: '(no shop)' }].concat(listCostAreas().filter((a) => a.code !== 'OFFICE').map((a) => ({ value: a.code, label: a.label || a.name || a.code })));

export function BankLinksScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const [, setTick] = useState(0);
  const refresh = () => setTick((t) => t + 1);
  const may = LK.mayLink(user);
  const links = LK.bankLinks();
  const accounts = LK.listAccountsWithKind({ includeInactive: true });
  let loans = [];
  try { loans = require('../../payables/recurring.js').listRecurring({ kind: 'loan' }).filter((l) => l.active); } catch (e) { loans = []; }
  const [words, setWords] = useState(() => links.words.map((w) => ({ ...w })));
  const accOpts = [{ value: '', label: '(not set)' }].concat(accounts.map((a) => ({ value: a.uid, label: `${a.name}${a.account_no ? ` · …${String(a.account_no).slice(-4)}` : ''}` })));
  const setW = (i, k) => (v) => setWords((o) => o.map((x, j) => (j === i ? { ...x, [k]: v } : x)));
  return (
    <Screen title="How the accounts connect" subtitle="Bank accounts, loans and the words on the statement">
      {!may ? <Banner tone="info" message="Only the owner or an admin can change these. You can see them." /> : null}
      <Explain>
        Set these once. The statement import then sorts the lines by itself: moves to your own accounts, your own money, M-PAiSA money moved in, and which shop each line belongs to.
      </Explain>

      <Card>
        <H>1. Bank accounts</H>
        {!accounts.length ? <Hint>No bank accounts yet.</Hint> : null}
        {accounts.map((a) => (
          <View key={a.uid} style={{ gap: 6, marginBottom: 10 }}>
            <Text style={{ fontSize: 16, color: C.text, fontWeight: '700' }}>{a.name}{a.account_no ? ` · …${String(a.account_no).slice(-4)}` : ' · (no account number – add it so transfers are found)'}</Text>
            <Chips testIDPrefix={`lk-kind-${a.uid}`} value={a.kind} options={KIND_OPTS} onChange={(v) => { if (may && act(() => LK.saveAccountKind(user, a.uid, v), 'Saved')) refresh(); }} />
          </View>
        ))}
        <Btn testID="lk-add-account" title="Add or change a bank account" icon="🏦" size="md" variant="secondary" onPress={() => nav.push('Cheques', { tab: 'accounts' })} />
      </Card>

      <Card>
        <H>2. Loans – which account pays them</H>
        {!loans.length ? <Hint>No loans set up yet (Money & bank › Loans).</Hint> : null}
        {loans.map((l) => {
          const k = LK.loanLink(l.uid);
          return (
            <View key={l.uid} style={{ gap: 6, marginBottom: 10 }}>
              <Text style={{ fontSize: 16, color: C.text, fontWeight: '700' }}>{l.name}</Text>
              <Select testID={`lk-loan-from-${l.uid}`} label="Paid from" value={k.payFromUid} options={accOpts} disabled={!may}
                onChange={(v) => { if (act(() => LK.saveLoanLink(user, l.uid, { payFromUid: v, auto: k.auto }), 'Saved')) refresh(); }} />
              <Chips testIDPrefix={`lk-loan-auto-${l.uid}`} value={k.auto ? 'auto' : 'us'} options={[{ value: 'auto', label: 'The bank takes it by itself' }, { value: 'us', label: 'We pay it (cheque / cash)' }]}
                onChange={(v) => { if (may && act(() => LK.saveLoanLink(user, l.uid, { payFromUid: k.payFromUid, auto: v === 'auto' }), 'Saved')) refresh(); }} />
            </View>
          );
        })}
      </Card>

      <Card>
        <H>3. Words on the statement</H>
        <Text style={{ fontSize: 14, color: C.sub }}>When a line has these words: which shop it belongs to, M-PAiSA money moved in, your own money (drawings), or a move to another of your accounts.</Text>
        {words.map((w, i) => (
          <Card key={i}>
            <Field testID={`lk-w-${i}`} label="Words on the line" value={w.contains} onChangeText={setW(i, 'contains')} />
            <Select testID={`lk-w-shop-${i}`} label="Shop" value={w.shop || ''} options={shopOptions()} onChange={setW(i, 'shop')} disabled={!may} />
            <Chips testIDPrefix={`lk-w-what-${i}`} value={w.drawings ? 'own' : w.mpaisa ? 'mpaisa' : (w._move || w.toAccountUid) ? 'move' : 'shop'}
              options={[{ value: 'shop', label: 'Just the shop' }, { value: 'mpaisa', label: 'M-PAiSA money in' }, { value: 'own', label: 'My own money (drawings)' }, { value: 'move', label: 'Move to our account' }]}
              onChange={(v) => setWords((o) => o.map((x, j) => (j === i ? { ...x, mpaisa: v === 'mpaisa', drawings: v === 'own', _move: v === 'move', toAccountUid: v === 'move' ? (x.toAccountUid || '') : '' } : x)))} />
            {!w.drawings && !w.mpaisa && (w._move || w.toAccountUid) ? (
              <Select testID={`lk-w-to-${i}`} label="To which account" value={w.toAccountUid || ''} options={accOpts} onChange={setW(i, 'toAccountUid')} disabled={!may} />
            ) : null}
            {w.note ? <Text style={{ fontSize: 13, color: C.sub }}>{w.note}</Text> : null}
            {may ? <Btn testID={`lk-w-del-${i}`} title="Remove" size="sm" variant="secondary" onPress={() => setWords((o) => o.filter((x, j) => j !== i))} /> : null}
          </Card>
        ))}
        {may ? (
          <View style={{ gap: 8 }}>
            <Btn testID="lk-w-add" title="Add words" icon="➕" size="md" variant="secondary" onPress={() => setWords((o) => o.concat([{ contains: '', shop: '', mpaisa: false, drawings: false, toAccountUid: '' }]))} />
            {!words.length ? <Btn testID="lk-w-usual" title="Add the usual BSP words (Shop 1, Shop 3 = Kiran Palace, Shop 2 = V M Pillay, CREDIT ADJUSTMENT = M-PAiSA)" icon="✨" size="md" variant="info" onPress={() => setWords(LK.suggestedWords())} /> : null}
            <Btn testID="lk-w-save" title="Save the words" icon="💾" variant="success" onPress={() => { if (act(() => LK.saveStatementWords(user, words), 'Saved')) refresh(); }} />
          </View>
        ) : null}
        <Hint>Transfers to one of your own accounts are found by its account number by themselves – no words needed.</Hint>
      </Card>
    </Screen>
  );
}

export function MoveMoneyScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const accounts = LK.listAccountsWithKind();
  const opts = accounts.map((a) => ({ value: a.uid, label: `${a.name} (${a.kindLabel})` }));
  const [f, setF] = useState({ fromUid: (accounts.find((a) => a.kind === 'cheque') || accounts[0] || {}).uid || '', toUid: (accounts.find((a) => a.kind === 'card') || {}).uid || '', amount: '', date: dateStr(), note: '' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  return (
    <Screen title="Move money between accounts" subtitle="e.g. from the cheque account to the Visa debit account"
      footer={<Btn testID="mm-save" title={`Move ${f.amount ? money(Number(f.amount) || 0) : ''}`} icon="🔁" variant="success" onPress={() => { if (act(() => LK.moveMoney(user, { ...f, amount: Number(f.amount) }), 'Moved')) nav.pop(); }} />}>
      {accounts.length < 2 ? <Banner tone="warn" message="Add the second account first (Money & bank › Settings › Bank accounts)." /> : null}
      <Card>
        <Select testID="mm-from" label="From" value={f.fromUid} options={opts} onChange={set('fromUid')} />
        <Select testID="mm-to" label="To" value={f.toUid} options={opts} onChange={set('toUid')} />
        <MoneyField testID="mm-amount" label="Amount" value={f.amount} onChangeText={set('amount')} />
        <DateField testID="mm-date" label="Date" value={f.date} onChange={set('date')} />
        <Field testID="mm-note" label="Note (optional)" value={f.note} onChangeText={set('note')} />
      </Card>
      <Hint>It goes out of one account and into the other – not a cost. Both statements match it by themselves.</Hint>
    </Screen>
  );
}
