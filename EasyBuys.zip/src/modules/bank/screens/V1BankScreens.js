// 1.0.0 (build 1) the bank for the new office (map screens rep-recon and r-bank).
//   ReconMonthScreen – BSP and both M-PAiSA wallets: statement against the books, cheques not cleared, the difference.
//   BankMatchScreen  – every statement line of the month, the ones still to match first. Each line has a drop-down of
//                      what it can be (the cheque or deposit with the same amount, a fee, interest, a transfer …) and a
//                      one-tap "Match" for the sure ones; Undo on matched lines; the difference updates after each tap.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Select, Field, Chips, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, useAct } from '../../../ui/kit.js';
import * as BR from '../v1Recon.js';
import { MonthPicker, $ } from '../../accounting/screens/V1Screens.js';
import * as V from '../../accounting/v1.js';

const tryRun = (f) => { try { return f(); } catch (e) { return { error: e.message || String(e) }; } };
const startYm = (params) => (params && /^\d{4}-\d{2}$/.test(params.ym || '') ? params.ym : V.lastFullMonth());
const money = (v) => (v === null || v === undefined ? '–' : $(v));

export function ReconMonthScreen({ params = {} }) {
  const { nav } = useApp();
  const [ym, setYm] = useState(startYm(params));
  const r = useMemo(() => tryRun(() => BR.reconMonth(ym)), [ym]);
  if (r.error) return <Screen title="Bank reconciliation"><MonthPicker ym={ym} onChange={setYm} /><Banner tone="danger" message={r.error} /></Screen>;
  const b = r.bsp;
  return (
    <Screen title={`Reconciliation – ${V.ymLabel(ym)}`} subtitle="Statement against the books"
      footer={<Btn testID="rc-match" title="Match the remaining lines" icon="🔗" variant="primary" onPress={() => nav.push('BankMatch', { ym, kind: b && !b.ok ? 'bank' : 'wallet', uid: b && !b.ok ? b.uid : ((r.wallets.find((w) => !w.ok) || r.wallets[0] || {}).uid) })} />}>
      <MonthPicker ym={ym} onChange={setYm} testID="rc" />
      {r.ok ? <Banner testID="rc-ok" tone="success" message="Everything agrees ✓ – ready for the month close." /> : <Banner tone="warn" message={`${r.open} account${r.open === 1 ? '' : 's'} still to finish.`} />}
      {b ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 6 }}>{b.name}</Text>
          {b.statement === null ? <Hint>No statement for the last day of the month yet – load this month's statement.</Hint> : null}
          <ListItem testID="rc-bsp-statement" title="Statement balance" right={money(b.statement)} />
          <ListItem testID="rc-bsp-books" title="Books balance (cheque book)" right={money(b.books)} />
          <ListItem title={`Cheques not yet cleared (${b.chequesCount})`} right={b.chequesNotCleared === null ? '–' : `+${$(b.chequesNotCleared)}`} />
          {b.depositsOnWay ? <ListItem title="Deposits on their way" right={`−${$(b.depositsOnWay)}`} /> : null}
          {b.otherOut ? <ListItem title="Other money out not on the statement yet" right={`+${$(b.otherOut)}`} /> : null}
          <ListItem testID="rc-bsp-diff" title="Difference" right={b.difference === null ? '–' : `${$(b.difference)}${Math.abs(b.difference) < 0.005 ? ' ✓' : ''}`} tone={b.difference === null ? undefined : Math.abs(b.difference) < 0.005 ? 'success' : 'danger'} />
          {b.toMatch ? <ListItem testID="rc-bsp-tomatch" title={`${b.toMatch} line${b.toMatch === 1 ? '' : 's'} to match`} tone="warn" onPress={() => nav.push('BankMatch', { ym, kind: 'bank', uid: b.uid })} /> : null}
          {!b.complete ? <Hint>{`The statement does not cover the whole month yet (from ${b.missingFrom}).`}</Hint> : null}
          <Btn testID="rc-load" title="Load this month's statement" size="sm" variant="secondary" onPress={() => nav.push('BankImport', {})} />
        </Card>
      ) : <Hint>Add the BSP account first (Settings › Bank, cheques & safe).</Hint>}
      {r.wallets.map((w) => (
        <ListItem key={w.uid} testID={`rc-wallet-${w.shop}`} title={w.name}
          sub={`${w.noStatement ? 'No M-PAiSA statement for this month yet' : w.statement === null ? 'No sales – nothing to check' : `statement ${$(w.statement)} · app ${$(w.books)}${w.problems ? ` · ${w.problems} day(s) not matching the till` : ''}`}${w.shifts ? ` · phone at the last shift end (${w.lastShiftDate}) ${$(w.lastShiftClose)}${w.shiftDiffs ? `, ${w.shiftDiffs} shift(s) short/over` : ''}` : ''}`}
          right={w.ok ? 'matched ✓' : w.toMatch ? `${w.toMatch} to match` : w.difference ? $(w.difference) : 'to do'} tone={w.ok ? 'success' : 'warn'}
          onPress={() => (w.noStatement ? nav.push('MpaisaImport', { walletUid: w.uid }) : nav.push('BankMatch', { ym, kind: 'wallet', uid: w.uid }))} />
      ))}
      <Btn testID="rc-excel" title="Excel / PDF" size="md" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'v1_recon', from: `${ym}-01`, to: `${ym}-01` })} />
    </Screen>
  );
}

function LineCard({ l, i, onPick, onUndo }) {
  const [choice, setChoice] = useState(l.best || null);
  const [note, setNote] = useState('');
  const open = l.status === 'unmatched';
  const needNote = choice === 'ignore';
  return (
    <Card tone={open ? 'warn' : undefined}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }} numberOfLines={2}>{`${Number(l.date.slice(8, 10))} ${V.MONTHS[Number(l.date.slice(5, 7)) - 1]} · ${l.text || '—'}`}</Text>
          {!open ? <Text style={{ fontSize: 14, color: C.success }}>{`✓ ${l.matched}`}</Text> : null}
        </View>
        <Text style={{ fontSize: 19, fontWeight: '900', color: l.amount < 0 ? C.danger : C.success }}>{l.amount < 0 ? `−${$(-l.amount)}` : `+${$(l.amount)}`}</Text>
      </View>
      {open ? (
        <View style={{ gap: 8, marginTop: 8 }}>
          <Select testID={`bm-pick-${i}`} label="This line is" value={choice} onChange={setChoice} options={l.options} search={l.options.length > 6} />
          {needNote || (choice && /^(new:adjust|adjust_in)/.test(choice)) ? <Field testID={`bm-note-${i}`} label="Why" value={note} onChangeText={setNote} placeholder="Write what it is / what to ask the bank" /> : null}
          <Btn testID={`bm-do-${i}`} title={choice === 'ignore' ? 'Put aside' : l.best && choice === l.best ? 'Match ✓' : 'Save'} size="md" variant="primary" disabled={!choice} onPress={() => onPick(l, choice, note)} />
        </View>
      ) : <Btn testID={`bm-undo-${i}`} title="Undo" size="sm" variant="ghost" onPress={() => onUndo(l)} />}
    </Card>
  );
}
export function BankMatchScreen({ params = {} }) {
  const act = useAct();
  const { user } = useApp();
  const [ym, setYm] = useState(startYm(params));
  const [show, setShow] = useState('open');
  const [n, bump] = useState(0);
  const r = useMemo(() => tryRun(() => BR.reconMonth(ym)), [ym, n]);
  const accounts = r.error ? [] : (r.bsp ? [{ value: `bank|${r.bsp.uid}`, label: r.bsp.name }] : []).concat(r.wallets.map((w) => ({ value: `wallet|${w.uid}`, label: w.name })));
  const [acc, setAcc] = useState(params.kind && params.uid ? `${params.kind}|${params.uid}` : null);
  const cur = acc || (accounts[0] && accounts[0].value) || '';
  const [kind, uid] = cur.split('|');
  const lines = useMemo(() => (uid ? tryRun(() => BR.matchLines(kind, uid, ym, { show })) : []), [cur, ym, show, n]);
  const state = r.error ? null : kind === 'bank' ? r.bsp : r.wallets.find((w) => w.uid === uid);
  const pick = (l, value, note) => { if (act(() => BR.applyMatch(user, kind, l.uid, value, note), 'Saved')) bump((x) => x + 1); };
  const undo = (l) => { if (act(() => BR.undoMatch(user, kind, l.uid), 'Undone')) bump((x) => x + 1); };
  const sure = Array.isArray(lines) ? lines.filter((l) => l.status === 'unmatched' && l.best).length : 0;
  return (
    <Screen title="Match the statement" subtitle={V.ymLabel(ym)}>
      {accounts.length ? <Select testID="bm-account" label="Account" value={cur} onChange={setAcc} options={accounts} /> : <Hint>No bank account or wallet yet.</Hint>}
      <MonthPicker ym={ym} onChange={setYm} testID="bm" />
      {state ? (
        <Banner testID="bm-state" tone={state.ok ? 'success' : 'warn'} message={`${state.toMatch} to match · difference ${state.difference === null || state.difference === undefined ? '–' : $(state.difference)}${state.ok ? ' ✓' : ''}`} />
      ) : null}
      <Chips value={show} onChange={setShow} options={[{ value: 'open', label: 'To match' }, { value: 'all', label: 'All lines' }]} testIDPrefix="bm-show" />
      {sure ? <Btn testID="bm-sure" title={`Match the ${sure} sure one${sure === 1 ? '' : 's'}`} size="md" variant="success" onPress={() => { if (act(() => BR.matchAllSure(user, kind, uid, ym), 'Matched')) bump((x) => x + 1); }} /> : null}
      {lines.error ? <Banner tone="danger" message={lines.error} /> : null}
      {Array.isArray(lines) && !lines.length ? <Hint>{show === 'open' ? 'Nothing left to match ✓' : 'No statement lines for this month yet.'}</Hint> : null}
      {Array.isArray(lines) ? lines.map((l, i) => <LineCard key={`${l.uid}|${l.status}|${n}`} l={l} i={i} onPick={pick} onUndo={undo} />) : null}
    </Screen>
  );
}
