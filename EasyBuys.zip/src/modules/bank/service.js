// Bank reconciliation: bring in the BSP statement (paste from internet banking, or type the lines),
// match every line to a cheque, transfer, deposit or fee already in the app, and deal with the rest.
// Matching marks the cheque as cleared / the entry as on the statement, so the cheque book balances.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, money } from '../../services/core.js';
import { addBankEntry, balanceCheck, markPresented, setEntryCleared } from '../payables/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });

export { BANK_SQL, BANK_SYNC } from './schema.js';

// ---------------------------------------------------------------- reading pasted statement text
// Accepts lines like (comma, tab or spaces between):  08/10/2026, CHQ 100205, -300.00
// or with separate debit / credit columns:              08/10/2026  Cheque 100205  300.00  (blank)
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function readDate(s) {
  let m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/.exec(s);
  if (m) { const y = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]); return `${y}-${String(m[2]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`; }
  m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (m) return s;
  m = /^(\d{1,2})[\s-]([A-Za-z]{3})[a-z]*[\s-](\d{2,4})$/.exec(s);
  if (m && MONTHS[m[2].toLowerCase()]) { const y = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]); return `${y}-${String(MONTHS[m[2].toLowerCase()]).padStart(2, '0')}-${String(m[1]).padStart(2, '0')}`; }
  return null;
}
const amountOf = (s) => {
  const t = String(s).replace(/[$,\s]/g, '');
  if (!/^\(?-?\d+(\.\d{1,2})?\)?(CR|DR)?$/i.test(t)) return null;
  let n = Number(t.replace(/[()]/g, '').replace(/CR|DR/i, ''));
  if (/^\(.*\)$/.test(t) || /DR$/i.test(t)) n = -Math.abs(n);
  return r2(n);
};
// Split one line into columns: tabs, or commas (respecting "quoted, values"), or 2+ spaces.
function splitLine(line) {
  if (line.includes('\t')) return line.split('\t').map((p) => p.trim());
  if (line.includes(',')) {
    const out = [];
    let cur = '';
    let q = false;
    for (const ch of line) {
      if (ch === '"') q = !q;
      else if (ch === ',' && !q) { out.push(cur.trim()); cur = ''; } else cur += ch;
    }
    out.push(cur.trim());
    return out;
  }
  return line.split(/\s{2,}/).map((p) => p.trim());
}
const OUT_WORDS = /\b(CHQ|CHEQUE|CHK|FEE|FEES|CHARGE|CHARGES|WITHDRAW|WITHDRAWAL|DEBIT|DR|PAYMENT TO|TRANSFER TO|TFR TO|EFTPOS PURCHASE|PURCHASE|DIRECT DEBIT|LOAN REPAYMENT)\b/i;
export function parseStatementText(text) {
  const out = [];
  const skipped = [];
  let cols = null; // from a heading line: { debit, credit, amount } column positions
  String(text || '').split(/\r?\n/).forEach((raw) => {
    const line = raw.trim();
    if (!line) return;
    const parts = splitLine(line).map((p) => p.replace(/^"|"$/g, ''));
    const date = readDate(parts[0]);
    if (!date) {
      const low = parts.map((p) => p.toLowerCase());
      if (low.some((p) => /debit|withdraw|money out/.test(p)) || low.some((p) => /credit|deposit|money in/.test(p)) || low.some((p) => p === 'amount')) {
        cols = { debit: low.findIndex((p) => /debit|withdraw|money out/.test(p)), credit: low.findIndex((p) => /credit|deposit|money in/.test(p)), amount: low.findIndex((p) => p === 'amount') };
      }
      skipped.push(line);
      return;
    }
    let amount = null;
    let usedCols = [];
    if (cols && (cols.debit > 0 || cols.credit > 0)) {
      const d = cols.debit > 0 && parts[cols.debit] ? amountOf(parts[cols.debit]) : null;
      const c = cols.credit > 0 && parts[cols.credit] ? amountOf(parts[cols.credit]) : null;
      if (d) amount = -Math.abs(d); else if (c) amount = Math.abs(c);
      usedCols = [cols.debit, cols.credit];
    } else if (cols && cols.amount > 0) {
      amount = amountOf(parts[cols.amount] || '');
      usedCols = [cols.amount];
    }
    const nums = parts.map((p, i) => ({ i, v: i === 0 || p === '' ? null : amountOf(p) }));
    if (amount === null) {
      const found = nums.filter((n) => n.v !== null);
      if (!found.length) { skipped.push(line); return; }
      // With columns date, description, debit, credit, balance: a blank column tells which side it is.
      const first = found[0];
      if (parts.length >= 4 && parts[first.i + 1] === '' && found.length >= 1) amount = -Math.abs(first.v);
      else if (parts.length >= 4 && parts[first.i - 1] === '' && first.i - 1 > 1) amount = Math.abs(first.v);
      else amount = first.v;
      usedCols = [first.i];
      // A single amount with no sign: decide by the words (cheque, fee, withdrawal = money out).
      if (amount > 0 && !/^[+]/.test(parts[first.i]) && !/CR$/i.test(parts[first.i])) {
        const words = parts.filter((p, i) => i > 0 && nums[i].v === null).join(' ');
        if (OUT_WORDS.test(words)) amount = -amount;
      }
    }
    if (amount === null || amount === 0) { skipped.push(line); return; }
    const desc = parts.filter((p, i) => i > 0 && !usedCols.includes(i) && nums[i].v === null).join(' ').replace(/\s+/g, ' ').trim();
    const ref = (/(?:CHQ|CHEQUE|CHK)\s*#?\s*(\d{4,10})/i.exec(desc) || [])[1] || '';
    out.push({ date, description: desc, reference: ref, amount });
  });
  return { lines: out, skipped };
}

// ---------------------------------------------------------------- statements
export function addStatement(user, { accountUid, fromDate, toDate, opening, closing, lines, notes }) {
  need(db().get('SELECT 1 AS x FROM bank_accounts WHERE uid = ?', [accountUid || '']), 'Choose the bank account.');
  need(DATE.test(txt(fromDate)) && DATE.test(txt(toDate)) && fromDate <= toDate, 'Enter the statement dates (from – to).');
  need(Number.isFinite(Number(closing)) && txt(closing) !== '', 'Enter the closing balance.');
  need(Array.isArray(lines) && lines.length, 'Add the statement lines (paste them or type them).');
  const overlap = db().get(`SELECT from_date, to_date FROM bank_statements WHERE account_uid = ? AND status <> 'void' AND NOT (to_date < ? OR from_date > ?)`, [accountUid, fromDate, toDate]);
  need(!overlap, `A statement for ${overlap && overlap.from_date} to ${overlap && overlap.to_date} is already in. Each day should be on one statement only.`);
  for (const l of lines) need(DATE.test(l.date) && l.date >= fromDate && l.date <= toDate && r2(l.amount) !== 0, `Line "${l.description || l.date}" is outside the dates or has no amount.`);
  if (txt(opening) !== '') {
    const sum = r2(Number(opening) + lines.reduce((s, l) => s + r2(l.amount), 0));
    need(Math.abs(sum - r2(closing)) < 0.005, `Opening ${$(opening)} plus the lines is ${$(sum)}, but the closing balance is ${$(closing)}. A line is missing or wrong.`);
  }
  const { now, dev } = meta();
  const uid = uuid('ST');
  db().transaction(() => {
    db().run(`INSERT INTO bank_statements (uid, account_uid, from_date, to_date, opening, closing, by_name, created_at, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, accountUid, fromDate, toDate, txt(opening) === '' ? null : r2(opening), r2(closing), user.name, now, txt(notes) || null, now, dev]);
    lines.forEach((l) => db().run(`INSERT INTO bank_lines (uid, statement_uid, account_uid, line_date, description, reference, amount, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)`,
      [uuid('BL'), uid, accountUid, l.date, txt(l.description) || null, txt(l.reference) || null, r2(l.amount), now, dev]));
  });
  audit({ user, action: `Bank statement ${fromDate} to ${toDate} (${lines.length} lines)`, table: 'bank_statements', recordUid: uid });
  autoMatch(user, uid);
  return uid;
}

export function listStatements(accountUid) {
  return db().all(`SELECT s.*, (SELECT COUNT(*) FROM bank_lines l WHERE l.statement_uid = s.uid AND l.status = 'unmatched') AS unmatched,
    (SELECT COUNT(*) FROM bank_lines l WHERE l.statement_uid = s.uid) AS lines FROM bank_statements s WHERE s.account_uid = ? AND s.status <> 'void' ORDER BY s.to_date DESC`, [accountUid]);
}
export function getStatement(uid) {
  const s = db().get('SELECT s.*, b.name AS account_name FROM bank_statements s JOIN bank_accounts b ON b.uid = s.account_uid WHERE s.uid = ?', [uid]);
  if (!s) return null;
  s.lines = db().all('SELECT * FROM bank_lines WHERE statement_uid = ? ORDER BY line_date, amount', [uid]);
  return s;
}

// What a statement line could be: cheques not cleared (money out) or entries not on a statement yet.
export function candidates(line) {
  const out = [];
  const from = addDays(line.line_date, -45);
  if (line.amount < 0) {
    db().all(`SELECT * FROM cheques WHERE account_uid = ? AND status = 'written' AND cheque_date <= ? AND cheque_date >= ?`, [line.account_uid, line.line_date, addDays(line.line_date, -400)]).forEach((c) => {
      if (Math.abs(c.amount + line.amount) < 0.005) out.push({ type: 'cheque', uid: c.uid, label: `Cheque ${c.cheque_no} · ${c.payee} · ${c.cheque_date}`, amount: -c.amount, score: (line.reference && String(c.cheque_no) === line.reference) ? 3 : 1 });
    });
  }
  db().all(`SELECT * FROM bank_entries WHERE account_uid = ? AND status = 'active' AND cleared_date IS NULL AND entry_date <= ? AND entry_date >= ?`, [line.account_uid, line.line_date, from]).forEach((e) => {
    const signed = ['deposit', 'interest', 'adjust_in'].includes(e.type) ? e.amount : -e.amount;
    if (Math.abs(signed - line.amount) < 0.005) out.push({ type: 'entry', uid: e.uid, label: `${e.type.replace('_', ' ')} ${e.reference || ''} · ${e.entry_date}`, amount: signed, score: e.reference && line.description && line.description.includes(e.reference) ? 3 : 1 });
  });
  return out.sort((a, b) => b.score - a.score);
}

export function matchLine(user, lineUid, cand) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const { now, dev } = meta();
  if (cand.type === 'cheque') markPresented(user, cand.uid, l.line_date);
  else setEntryCleared(user, cand.uid, l.line_date);
  db().run(`UPDATE bank_lines SET status = 'matched', match_type = ?, match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [cand.type, cand.uid, now, dev, lineUid]);
}
export function unmatchLine(user, lineUid) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status !== 'unmatched', 'Not matched.');
  const { now, dev } = meta();
  if (l.match_type === 'cheque') { try { markPresented(user, l.match_uid, null); } catch (e) { /* already changed */ } }
  if (l.match_type === 'entry') setEntryCleared(user, l.match_uid, null);
  if (l.match_type === 'created') db().run(`UPDATE bank_entries SET status = 'void', void_reason = 'Un-matched from the bank statement', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, l.match_uid]);
  db().run(`UPDATE bank_lines SET status = 'unmatched', match_type = NULL, match_uid = NULL, note = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, lineUid]);
}
// Match everything that has exactly one sure match (cheque number, or a single same-amount item).
export function autoMatch(user, statementUid) {
  let n = 0;
  for (const l of db().all("SELECT * FROM bank_lines WHERE statement_uid = ? AND status = 'unmatched' ORDER BY line_date", [statementUid])) {
    const c = candidates(l);
    const best = c.filter((x) => x.score === 3);
    const pick = best.length === 1 ? best[0] : c.length === 1 ? c[0] : null;
    if (pick) { matchLine(user, l.uid, pick); n += 1; }
  }
  return n;
}
// A line the app did not know about (bank fee, interest, direct deposit, transfer): record it and match it.
export function createFromLine(user, lineUid, type, note) {
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched', 'Line already dealt with.');
  const isIn = l.amount > 0;
  need(isIn ? ['deposit', 'interest', 'adjust_in'].includes(type) : ['fee', 'transfer_out', 'adjust_out'].includes(type), isIn ? 'Money in: choose deposit, interest or correction (+).' : 'Money out: choose fee, transfer or correction (−).');
  const eUid = addBankEntry(user, { accountUid: l.account_uid, type, amount: Math.abs(l.amount), date: l.line_date, reference: l.reference || l.description, note: txt(note) || l.description || 'From bank statement', clearedDate: l.line_date });
  const { now, dev } = meta();
  db().run(`UPDATE bank_lines SET status = 'matched', match_type = 'created', match_uid = ?, note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [eUid, txt(note) || null, now, dev, lineUid]);
}
export function ignoreLine(user, lineUid, note) {
  need(txt(note), 'Say why this line is ignored.');
  const { now, dev } = meta();
  db().run(`UPDATE bank_lines SET status = 'ignored', note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'unmatched'`, [txt(note), now, dev, lineUid]);
  audit({ user, action: 'Ignored a bank statement line', table: 'bank_lines', recordUid: lineUid, reason: note });
}

export function reconcileSummary(statementUid) {
  const s = getStatement(statementUid);
  need(s, 'Statement not found.');
  const check = balanceCheck(s.account_uid, s.to_date, s.closing);
  return { statement: s, check, unmatched: s.lines.filter((l) => l.status === 'unmatched'), matched: s.lines.filter((l) => l.status === 'matched').length, ignored: s.lines.filter((l) => l.status === 'ignored').length };
}
export function finishStatement(user, statementUid) {
  const r = reconcileSummary(statementUid);
  need(!r.unmatched.length, `${r.unmatched.length} line(s) are not matched yet.`);
  const { now, dev } = meta();
  db().run(`UPDATE bank_statements SET status = 'reconciled', reconciled_by_name = ?, reconciled_at = ?, difference = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [user.name, now, r.check.difference, now, dev, statementUid]);
  audit({ user, action: `Bank reconciliation ${r.statement.to_date}: ${r.check.balanced ? 'balanced' : `difference ${$(r.check.difference)}`}`, table: 'bank_statements', recordUid: statementUid });
  return r;
}
