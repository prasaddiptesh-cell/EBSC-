// 1.0.0 (build 1) Bank reconciliation for the month (map screen rep-recon) and line-by-line matching (r-bank).
//   reconMonth  – the BSP cheque account and both M-PAiSA wallets: the statement against the books. BSP: statement
//                 balance = books + cheques not cleared − deposits on their way + other money out not on the
//                 statement; what is left is the difference. Each wallet: statement balance against the app's wallet.
//   matchLines  – every statement line of the month with what it can be matched to (drop-down), one tap to match,
//                 undo, put aside with a reason; the reconciliation is worked out again after each tap.
// Built on the existing matching (service.js, wallets.js) – nothing is matched a different way.
import { db } from '../../db/connection.js';
import { addDays, money, AppError, stamp, deviceId, audit } from '../../services/core.js';
import { bookBalance, balanceCheck } from '../payables/service.js';
import { mainAccount } from './position.js';
import { statementBalanceAt, coverage } from './monthEnd.js';
import * as B from './service.js';
import * as W from './wallets.js';
import { requirePerm, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const YM = /^\d{4}-\d{2}$/;
export function monthRangeOf(ym) {
  const [y, m] = ym.split('-').map(Number);
  return { from: `${ym}-01`, to: addDays(m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`, -1) };
}

// The wallet statement's balance at a date: the import's closing when it ends that day, else the last line's balance.
export function walletStatementAt(walletUid, date) {
  const imp = db().get("SELECT * FROM wallet_imports WHERE wallet_uid = ? AND status = 'active' AND from_date <= ? AND to_date >= ? ORDER BY to_date ASC, created_at DESC LIMIT 1", [walletUid, date, date]);
  if (!imp) return null;
  if (imp.to_date === date && imp.closing !== null && imp.closing !== undefined) return r2(imp.closing);
  const l = db().get('SELECT balance FROM wallet_lines WHERE wallet_uid = ? AND line_date <= ? AND balance IS NOT NULL ORDER BY line_date DESC, line_time DESC LIMIT 1', [walletUid, date]);
  if (l) return r2(l.balance);
  if (imp.closing !== null && imp.closing !== undefined) {
    const after = db().get('SELECT IFNULL(SUM(amount),0) AS s FROM wallet_lines WHERE import_uid = ? AND line_date > ?', [imp.uid, date]).s;
    return r2(imp.closing - after);
  }
  return null;
}

export function reconMonth(ym) {
  need(YM.test(String(ym || '')), 'Choose the month.');
  const { from, to } = monthRangeOf(ym);
  const acc = safe(() => mainAccount(), null);
  let bsp = null;
  if (acc) {
    const sb = safe(() => statementBalanceAt(acc.uid, to), null);
    const book = safe(() => bookBalance(acc.uid, to), null);
    const chk = sb ? safe(() => balanceCheck(acc.uid, to, sb.balance), null) : null;
    const toMatch = db().get("SELECT COUNT(*) AS n FROM bank_lines WHERE account_uid = ? AND status = 'unmatched' AND line_date BETWEEN ? AND ?", [acc.uid, from, to]).n;
    const cov = safe(() => coverage(acc.uid, from, to), { complete: false, missingFrom: from });
    bsp = {
      kind: 'bank', uid: acc.uid, name: acc.name || 'BSP', statement: sb ? sb.balance : null, books: book ? book.balance : null,
      chequesNotCleared: chk ? chk.chequesOut : null, chequesCount: chk ? chk.notCleared.length : 0, depositsOnWay: chk ? chk.depositsInTransit : null, otherOut: chk ? chk.otherOut : null,
      shouldShow: chk ? chk.expected : null, difference: chk ? chk.difference : null, toMatch, complete: cov.complete, missingFrom: cov.missingFrom,
      ok: !!chk && chk.balanced && !toMatch && cov.complete,
    };
  }
  const wallets = safe(() => W.listWallets(), []).map((w) => {
    const st = walletStatementAt(w.uid, to);
    const pos = safe(() => W.walletPosition(w.uid, to), null);
    const books = pos ? pos.balance : null;
    const toMatch = db().get("SELECT COUNT(*) AS n FROM wallet_lines WHERE wallet_uid = ? AND status = 'unmatched' AND line_date BETWEEN ? AND ?", [w.uid, from, to]).n;
    const days = safe(() => W.shiftMatch(w.uid, from, to), []);
    const problems = days.filter((d) => ['short', 'over'].includes(d.status)).length;
    const sales = days.some((d) => d.dayTill > 0);
    const difference = st !== null && books !== null ? r2(st - books) : null;
    // 1.0.0 build 2: the balances read off the M-PAiSA phone at each shift's end (till/mpaisaShift.js)
    const shifts = safe(() => require('../till/mpaisaShift.js').shiftBalances(w.uid, from, to), []);
    const lastShift = shifts.length ? shifts[shifts.length - 1] : null;
    const shiftDiffs = shifts.filter((x) => Math.abs(Number(x.diff) || 0) >= 0.005).length;
    return { kind: 'wallet', uid: w.uid, name: w.name, shop: w.shop_code, statement: st, books, difference, toMatch, problems, noStatement: st === null && sales, shifts: shifts.length, shiftDiffs, lastShiftClose: lastShift ? lastShift.close : null, lastShiftDate: lastShift ? lastShift.date : null,
      ok: (st === null ? !sales : Math.abs(difference) < 0.005) && !toMatch && !problems };
  });
  const all = (bsp ? [bsp] : []).concat(wallets);
  return { ym, from, to, bsp, wallets, open: all.filter((x) => !x.ok).length, ok: all.length > 0 && all.every((x) => x.ok) };
}

// ---------------------------------------------------------------- line by line
const BANK_CREATE_IN = [['deposit', 'Money in (deposit we did not record)'], ['interest', 'Interest from the bank'], ['adjust_in', 'Bank correction (+)']];
const BANK_CREATE_OUT = [['fee', 'Bank fee'], ['transfer_out', 'Transfer / direct debit we did not record'], ['adjust_out', 'Bank correction (−)']];
function matchedLabel(l) {
  if (l.status === 'ignored') return `Put aside – ${l.note || 'no reason'}`;
  if (l.status !== 'matched') return null;
  if (l.match_type === 'cheque') { const c = db().get('SELECT cheque_no, payee FROM cheques WHERE uid = ?', [l.match_uid]); return c ? `Cheque ${c.cheque_no}${c.payee ? ` · ${c.payee}` : ''}` : 'Cheque'; }
  if (l.match_type === 'entry' || l.match_type === 'created') { const e = db().get('SELECT type, reference, entry_date FROM bank_entries WHERE uid = ?', [l.match_uid]); return e ? `${e.type.replace('_', ' ')}${e.reference ? ` ${e.reference}` : ''} · ${e.entry_date}` : 'Recorded'; }
  if (l.match_type === 'move') { const m = db().get('SELECT type, move_date FROM wallet_moves WHERE uid = ?', [l.match_uid]); return m ? `${W.MOVE_LABEL[m.type] || m.type} · ${m.move_date}` : 'Recorded'; }
  if (l.match_type === 'day') return 'M-PAiSA sales of the day (till)';
  return 'Matched';
}
// Every line of the month: { uid, date, text, amount, status, matched, options: [{ value, label, hint }] }.
export function matchLines(kind, accountUid, ym, { show = 'open' } = {}) {
  need(YM.test(String(ym || '')), 'Choose the month.');
  const { from, to } = monthRangeOf(ym);
  if (kind === 'wallet') {
    const lines = db().all(`SELECT * FROM wallet_lines WHERE wallet_uid = ? AND line_date BETWEEN ? AND ? ${show === 'open' ? "AND status = 'unmatched'" : ''} ORDER BY status = 'unmatched' DESC, line_date, line_time`, [accountUid, from, to]);
    return lines.map((l) => {
      const opts = [];
      if (l.status === 'unmatched') {
        if (l.amount < 0) {
          for (const m of db().all(`SELECT * FROM wallet_moves WHERE wallet_uid = ? AND status = 'active' AND type IN ('transfer_bank','fee','payment','adjust_out') AND ABS(amount - ?) < 0.005 AND move_date BETWEEN ? AND ?
            AND uid NOT IN (SELECT match_uid FROM wallet_lines WHERE match_uid IS NOT NULL AND status = 'matched')`, [accountUid, Math.abs(l.amount), addDays(l.line_date, -7), addDays(l.line_date, 7)])) {
            opts.push({ value: `m:${m.uid}`, label: `${W.MOVE_LABEL[m.type] || m.type} ${m.move_date}${m.reference ? ` · ${m.reference}` : ''}`, hint: 'Same amount – already in the app' });
          }
          opts.push({ value: 'transfer', label: 'Transfer to BSP (record it now)' }, { value: 'fee', label: 'M-PAiSA fee' });
        } else {
          opts.push({ value: 'adjust_in', label: 'Money in – correction (+)' });
        }
      }
      opts.push({ value: 'ignore', label: 'Put aside – ask about it (write why)' });
      return { uid: l.uid, date: l.line_date, time: l.line_time || '', text: [l.description, l.party, l.reference].filter(Boolean).join(' · ') || l.kind, amount: r2(l.amount), status: l.status, matched: matchedLabel(l), kind: l.kind,
        options: l.status === 'unmatched' ? opts : [], best: opts.length && opts[0].value.startsWith('m:') ? opts[0].value : null };
    });
  }
  const lines = db().all(`SELECT * FROM bank_lines WHERE account_uid = ? AND line_date BETWEEN ? AND ? ${show === 'open' ? "AND status = 'unmatched'" : ''} ORDER BY status = 'unmatched' DESC, line_date, amount`, [accountUid, from, to]);
  return lines.map((l) => {
    const opts = [];
    if (l.status === 'unmatched') {
      for (const c of safe(() => B.candidates(l), [])) opts.push({ value: `c:${c.type}:${c.uid}`, label: c.label, hint: c.score === 3 ? 'Sure – the number / reference matches' : 'Same amount' });
      for (const [t, label] of l.amount > 0 ? BANK_CREATE_IN : BANK_CREATE_OUT) opts.push({ value: `new:${t}`, label });
      opts.push({ value: 'ignore', label: 'Put aside – ask about it (write why)' });
    }
    const sure = opts.filter((o) => o.value.startsWith('c:') && /^Sure/.test(o.hint || ''));
    return { uid: l.uid, date: l.line_date, text: [l.description, l.reference].filter(Boolean).join(' · '), amount: r2(l.amount), status: l.status, matched: matchedLabel(l),
      options: opts, best: sure.length === 1 ? sure[0].value : opts.filter((o) => o.value.startsWith('c:')).length === 1 ? opts.find((o) => o.value.startsWith('c:')).value : null };
  });
}
// One tap: match, record or put aside. value comes from the line's options.
export function applyMatch(user, kind, lineUid, value, note) {
  requirePerm(user, 'bank_rec', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(value), 'Choose what this line is.');
  if (kind === 'wallet') {
    const l = db().get('SELECT * FROM wallet_lines WHERE uid = ?', [lineUid]);
    need(l && l.status === 'unmatched', 'This line is already dealt with.');
    if (value === 'ignore') return W.ignoreWalletLine(user, lineUid, note);
    if (value === 'transfer') { const acc = mainAccount(); need(acc, 'Add the BSP account first.'); return W.transferFromLine(user, lineUid, acc.uid); }
    let moveUid = null;
    if (value.startsWith('m:')) moveUid = value.slice(2);
    else if (value === 'fee' || value === 'adjust_in') moveUid = W.recordWalletMove(user, { walletUid: l.wallet_uid, type: value, date: l.line_date, amount: Math.abs(l.amount), reference: l.reference, note: txt(note) || l.description || 'From the wallet statement', clearedDate: l.line_date });
    need(moveUid, 'Choose what this line is.');
    db().run(`UPDATE wallet_lines SET status = 'matched', match_type = 'move', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [moveUid, stamp(), deviceId(), lineUid]);
    audit({ user, action: 'Wallet statement line matched', table: 'wallet_lines', recordUid: lineUid });
    db().run("UPDATE wallet_moves SET cleared_date = COALESCE(cleared_date, ?), updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [l.line_date, stamp(), deviceId(), moveUid]);
    return moveUid;
  }
  const l0 = db().get('SELECT status FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l0 && l0.status === 'unmatched', 'This line is already dealt with.');
  if (value === 'ignore') return B.ignoreLine(user, lineUid, note);
  if (value.startsWith('new:')) return B.createFromLine(user, lineUid, value.slice(4), note);
  const m = /^c:(cheque|entry):(.+)$/.exec(value);
  need(m, 'Choose what this line is.');
  const l = db().get('SELECT * FROM bank_lines WHERE uid = ?', [lineUid]);
  need(l, 'Line not found.');
  const cand = safe(() => B.candidates(l), []).find((c) => c.type === m[1] && c.uid === m[2]);
  need(cand, 'That cheque or entry is no longer waiting – choose again.');
  return B.matchLine(user, lineUid, cand);
  });
}
export function undoMatch(user, kind, lineUid) {
  requirePerm(user, 'bank_rec', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (kind === 'wallet') {
    const l = db().get('SELECT * FROM wallet_lines WHERE uid = ?', [lineUid]);
    need(l && l.status !== 'unmatched', 'Not matched.');
    if (l.match_type === 'move' && l.match_uid) db().run("UPDATE wallet_moves SET cleared_date = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [stamp(), deviceId(), l.match_uid]);
    db().run(`UPDATE wallet_lines SET status = 'unmatched', match_type = NULL, match_uid = NULL, note = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [stamp(), deviceId(), lineUid]);
    audit({ user, action: 'Wallet statement line un-matched', table: 'wallet_lines', recordUid: lineUid });
    return;
  }
  B.unmatchLine(user, lineUid);
  });
}
// Match every line that has exactly one sure match (the same rule as the statement screen).
export function matchAllSure(user, kind, accountUid, ym) {
  let n = 0;
  for (const l of matchLines(kind, accountUid, ym)) {
    if (l.status !== 'unmatched' || !l.best) continue;
    try { applyMatch(user, kind, l.uid, l.best); n += 1; } catch (e) { /* left for a person */ }
  }
  return n;
}

const col = (key, title, align = 'left') => ({ key, title, align });
export function reconMonthReport(from) {
  const ym = YM.test(String(from || '').slice(0, 7)) ? String(from).slice(0, 7) : null;
  const r = reconMonth(ym || require('../accounting/v1.js').lastFullMonth());
  const v = (x) => (x === null || x === undefined ? '–' : x);
  const rows = (r.bsp ? [{ what: r.bsp.name, statement: v(r.bsp.statement), books: v(r.bsp.books), cheques: v(r.bsp.chequesNotCleared), deposits: v(r.bsp.depositsOnWay), difference: v(r.bsp.difference), toMatch: r.bsp.toMatch }] : [])
    .concat(r.wallets.map((w) => ({ what: w.name, statement: v(w.statement), books: v(w.books), cheques: '', deposits: '', difference: v(w.difference), toMatch: w.toMatch })));
  return {
    title: `Bank reconciliation – ${r.ym}`, subtitle: 'BSP and the M-PAiSA wallets: statement against the books',
    summary: [{ label: 'All agree', value: r.ok ? 'yes' : `no – ${r.open} to finish` }],
    sections: [{ title: 'Accounts', columns: [col('what', 'Account'), col('statement', 'Statement', 'right'), col('books', 'Books', 'right'), col('cheques', 'Cheques not cleared', 'right'),
      col('deposits', 'Deposits on their way', 'right'), col('difference', 'Difference', 'right'), col('toMatch', 'Lines to match', 'right')], rows }],
  };
}
export const V1_BANK_REPORTS = [
  { id: 'v1_recon', group: 'Bank reconciliation', icon: '🏦', title: 'Bank reconciliation – month (BSP and M-PAiSA)', desc: 'Statement against the books, cheques not cleared, the difference', perm: 'bank_rec', build: reconMonthReport },
];
