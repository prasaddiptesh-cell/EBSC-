// M-PAiSA wallets (one per shop) as money accounts. The till balance's M-PAiSA figure goes into that shop's wallet;
// transfers to BSP and fees come out. The admin can add another wallet later (e.g. MyCash).
// Statement import: CSV, Excel, PDF text or a screenshot read by Google (when online), with the columns set by the admin.
// Each shift's M-PAiSA sales are matched to the receipts in the wallet (this catches fake payment messages).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { needReason } from '../../services/access.js';
import { assertOpen } from '../../services/lock.js';
import { readDate, splitCsv } from './importer.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

export const PROVIDERS = ['M-PAiSA', 'MyCash'];
export const MOVE_LABEL = { transfer_bank: 'Transfer to BSP', fee: 'Fee', adjust_in: 'Correction (+)', adjust_out: 'Correction (−)', sale: 'Till M-PAiSA sales', payment: 'Paid from the wallet' };
// 'payment': something paid straight from the wallet (e.g. fuel, v3.5 B7) – its expense is booked by its own journal.
const OUT = ['transfer_bank', 'fee', 'adjust_out', 'payment'];

// ---------------------------------------------------------------- wallets
// The two M-PAiSA wallets exist from the start (same ids on every device, so syncing never makes copies).
export function ensureDefaultWallets() {
  const { now, dev } = meta();
  const shops = [['S1', 'M-PAiSA Shop 1'], ['S2', 'M-PAiSA Shop 2']];
  shops.forEach(([code, name], i) => db().run(`INSERT OR IGNORE INTO wallets (uid, name, provider, shop_code, opening_balance, opening_date, active, sort, updated_at, updated_device) VALUES (?,?,'M-PAiSA',?,0,?,1,?,?,?)`,
    [`WAL-MPAISA-${code}`, name, code, '2026-01-01', i, now, dev]));
}
export function listWallets({ includeInactive = false } = {}) {
  return db().all('SELECT * FROM wallets WHERE (? = 1 OR active = 1) ORDER BY sort, name', [includeInactive ? 1 : 0]);
}
export function getWallet(uid) { return db().get('SELECT * FROM wallets WHERE uid = ?', [uid || '']) || null; }
export function saveWallet(user, w) {
  const name = txt(w.name);
  need(name, 'Name the wallet, e.g. "MyCash Shop 1".');
  const provider = txt(w.provider) || 'M-PAiSA';
  need(txt(w.shopCode), 'Choose the shop whose till takes this wallet\'s payments.');
  const od = txt(w.openingDate) || dateStr();
  need(DATE.test(od), 'Enter the opening date.');
  const uid = w.uid || uuid('WAL');
  const before = getWallet(uid);
  const { now, dev } = meta();
  db().run(`INSERT INTO wallets (uid, name, provider, shop_code, phone_no, opening_balance, opening_date, active, sort, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,COALESCE((SELECT MAX(sort)+1 FROM wallets),0),?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, provider=excluded.provider, shop_code=excluded.shop_code, phone_no=excluded.phone_no, opening_balance=excluded.opening_balance,
    opening_date=excluded.opening_date, active=excluded.active, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, name, provider, txt(w.shopCode), txt(w.phoneNo) || null, r2(w.openingBalance), od, w.active === false ? 0 : 1, now, dev]);
  audit({ user, action: before ? `Changed wallet ${name}` : `Added wallet ${name}`, table: 'wallets', recordUid: uid, before, after: { name, provider, shop: w.shopCode, opening: r2(w.openingBalance), od } });
  return getWallet(uid);
}

// ---------------------------------------------------------------- money in: the till balances' M-PAiSA figures
const tenderMatches = (method, provider) => { const m = norm(method); const p = norm(provider); return !!m && (m.includes(p) || (p === 'mpaisa' && m.includes('paisa'))); };
export function walletSales(walletUid, from, to) {
  const w = getWallet(walletUid);
  if (!w) return [];
  const out = [];
  for (const c of db().all("SELECT uid, shop_code, shift_date, shift, till_name, cashier_name, counted_at, tenders FROM till_counts WHERE status <> 'void' AND shop_code = ? AND shift_date >= ? AND shift_date <= ? ORDER BY shift_date, counted_at",
    [w.shop_code, from || w.opening_date, to || '9999-12-31'])) {
    const amt = r2(J(c.tenders, []).filter((t) => tenderMatches(t.method, w.provider)).reduce((s, t) => s + r2(t.amount), 0));
    if (amt > 0) out.push({ countUid: c.uid, date: c.shift_date, shift: c.shift || '', till: c.till_name || 'Till', cashier: c.cashier_name || '', countedAt: c.counted_at || '', amount: amt });
  }
  return out;
}
export function walletPosition(walletUid, asOf = dateStr()) {
  const w = getWallet(walletUid);
  if (!w) return null;
  const sales = r2(walletSales(walletUid, w.opening_date, asOf).reduce((s, x) => s + x.amount, 0));
  const by = Object.fromEntries(db().all("SELECT type, SUM(amount) AS s FROM wallet_moves WHERE wallet_uid = ? AND status = 'active' AND move_date >= ? AND move_date <= ? GROUP BY type", [walletUid, w.opening_date, asOf]).map((x) => [x.type, r2(x.s)]));
  const ins = r2(by.adjust_in || 0);
  const outs = r2(OUT.reduce((s, t) => s + (by[t] || 0), 0));
  const balance = r2(w.opening_balance + sales + ins - outs);
  const transit = db().all(`SELECT m.* FROM wallet_moves m LEFT JOIN bank_entries e ON e.uid = m.bank_entry_uid WHERE m.wallet_uid = ? AND m.status = 'active' AND m.type = 'transfer_bank' AND (e.cleared_date IS NULL) ORDER BY m.move_date`, [walletUid]);
  return { wallet: w, asOf, opening: r2(w.opening_balance), sales, by, ins, outs, balance, transfersInTransit: transit, transitTotal: r2(transit.reduce((s, m) => s + m.amount, 0)) };
}
// What may explain a difference against the M-PAiSA app (used by "Check against the app").
export function walletPending(walletUid, today = dateStr()) {
  const out = [];
  walletSales(walletUid, addDays(today, -3), today).forEach((s) => out.push({ label: `${s.till} ${s.shift} ${s.date} M-PAiSA sales`, amount: -s.amount, why: `${s.till} ${s.shift} ${s.date}: the till recorded ${$(s.amount)} M-PAiSA – check it was really received.` }));
  return out;
}

// ---------------------------------------------------------------- transfers to BSP, fees, corrections
// A transfer to BSP leaves the wallet and appears in the bank as money in transit until the statement shows it.
export function recordWalletTransfer(user, { walletUid, date, amount, fee, reference, accountUid, note }) {
  const w = getWallet(walletUid);
  need(w, 'Choose the wallet.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'Enter the transfer date (not in the future).');
  assertOpen(d, 'This transfer');
  const amt = r2(amount);
  need(amt > 0, 'Enter the amount transferred.');
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ? AND active = 1', [accountUid || '']) || db().get('SELECT * FROM bank_accounts WHERE active = 1 ORDER BY sort, name LIMIT 1');
  need(acc, 'Add the BSP account first (Invoices & cheques › Bank accounts).');
  const pos = walletPosition(walletUid, d);
  if (amt + r2(fee) > pos.balance + 0.004) needReason(user, note, `Only ${$(pos.balance)} is recorded in ${w.name}. Say why (e.g. till balance not done yet).`);
  const { now, dev } = meta();
  const uid = uuid('WM');
  const beUid = `BE-WT-${uid}`;
  db().transaction(() => {
    db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, shop_code, updated_at, updated_device) VALUES (?,?,?,'deposit',?,?,?,?,?,?,?)`,
      [beUid, acc.uid, d, amt, txt(reference) || `${w.provider} transfer`, `From ${w.name}`, user.name, w.shop_code, now, dev]);
    db().run(`INSERT INTO wallet_moves (uid, wallet_uid, move_date, type, amount, bank_entry_uid, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'transfer_bank',?,?,?,?,?,?,?)`,
      [uid, walletUid, d, amt, beUid, txt(reference) || null, txt(note) || null, user.name, now, dev]);
    if (r2(fee) > 0) db().run(`INSERT INTO wallet_moves (uid, wallet_uid, move_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'fee',?,?,?,?,?,?)`,
      [uuid('WM'), walletUid, d, r2(fee), txt(reference) || null, 'Transfer fee', user.name, now, dev]);
  });
  audit({ user, action: `${w.name}: ${$(amt)} transferred to ${acc.name}${r2(fee) > 0 ? ` (fee ${$(fee)})` : ''}`, table: 'wallet_moves', recordUid: uid });
  return uid;
}
export function recordWalletMove(user, { walletUid, type, date, amount, reference, note, clearedDate }) {
  const w = getWallet(walletUid);
  need(w, 'Choose the wallet.');
  need(['fee', 'adjust_in', 'adjust_out'].includes(type), 'Choose fee or correction.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  assertOpen(d, 'This wallet record');
  const amt = r2(amount);
  need(amt > 0, 'Enter the amount.');
  if (type.startsWith('adjust')) needReason(user, note, 'A correction needs a reason.');
  const { now, dev } = meta();
  const uid = uuid('WM');
  db().run(`INSERT INTO wallet_moves (uid, wallet_uid, move_date, type, amount, reference, note, cleared_date, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, walletUid, d, type, amt, txt(reference) || null, txt(note) || null, txt(clearedDate) || null, user.name, now, dev]);
  audit({ user, action: `${w.name}: ${MOVE_LABEL[type]} ${$(amt)}`, table: 'wallet_moves', recordUid: uid, reason: note });
  return uid;
}
export function voidWalletMove(user, uid, reason) {
  const m = db().get('SELECT * FROM wallet_moves WHERE uid = ?', [uid]);
  need(m && m.status === 'active', 'Not found.');
  assertOpen(m.move_date, 'This wallet record');
  needReason(user, reason, 'Give a reason.');
  if (m.bank_entry_uid) need(!db().get('SELECT 1 AS x FROM bank_entries WHERE uid = ? AND cleared_date IS NOT NULL', [m.bank_entry_uid]), 'This transfer is already on the bank statement. Un-match it in Bank reconciliation first.');
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`UPDATE wallet_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
    if (m.bank_entry_uid) db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, m.bank_entry_uid]);
    db().run(`UPDATE wallet_lines SET status = 'unmatched', match_type = NULL, match_uid = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE match_uid = ?`, [now, dev, uid]);
  });
  audit({ user, action: `Voided wallet ${MOVE_LABEL[m.type]} ${$(m.amount)}`, table: 'wallet_moves', recordUid: uid, reason });
}
// Sales from the tills and the wallet's own records, newest first, with a running balance.
export function walletHistory(walletUid, { from, to } = {}) {
  const w = getWallet(walletUid);
  if (!w) return { rows: [] };
  to = to || dateStr();
  const rows = walletSales(walletUid, w.opening_date, to).map((s) => ({ kind: 'sale', uid: s.countUid, date: s.date, sort: `${s.date} ${s.countedAt}`, what: `${s.till} ${s.shift} – M-PAiSA sales`, sub: s.cashier, amount: s.amount }));
  db().all("SELECT * FROM wallet_moves WHERE wallet_uid = ? AND status = 'active' AND move_date >= ? AND move_date <= ?", [walletUid, w.opening_date, to]).forEach((m) => {
    const cleared = m.bank_entry_uid ? (db().get('SELECT cleared_date FROM bank_entries WHERE uid = ?', [m.bank_entry_uid]) || {}).cleared_date : m.cleared_date;
    rows.push({ kind: 'move', uid: m.uid, type: m.type, date: m.move_date, sort: `${m.move_date} ${m.updated_at}`, what: MOVE_LABEL[m.type] || m.type, sub: [m.reference, m.note, m.type === 'transfer_bank' ? (cleared ? `in BSP ${cleared}` : 'on the way to BSP') : null].filter(Boolean).join(' · '),
      amount: OUT.includes(m.type) ? -m.amount : m.amount, cleared });
  });
  rows.sort((a, b) => (a.sort < b.sort ? -1 : a.sort > b.sort ? 1 : 0));
  let bal = r2(w.opening_balance);
  rows.forEach((r) => { bal = r2(bal + r.amount); r.balance = bal; });
  return { wallet: w, rows: rows.filter((r) => !from || r.date >= from).reverse(), balance: bal };
}

// ---------------------------------------------------------------- statement columns (admin, fine-tuned later)
export const COLUMN_FIELDS = [
  ['date', 'Date'], ['time', 'Time'], ['description', 'Description / details'], ['reference', 'Transaction ID'], ['party', 'From / to (name or number)'],
  ['amountIn', 'Money in'], ['amountOut', 'Money out'], ['amount', 'Amount (one column, − for out)'], ['balance', 'Balance'],
];
export const COLUMN_DEFAULTS = {
  date: 'date', time: 'time', description: 'details|description|transaction type|type', reference: 'transaction id|receipt|reference|ref', party: 'name|from|sender|party|msisdn|mobile',
  amountIn: 'credit|money in|received|paid in|in', amountOut: 'debit|money out|sent|paid out|withdrawn|out', amount: 'amount', balance: 'balance', dateOrder: 'dmy',
};
export function walletColumns(provider = 'M-PAiSA') {
  return { ...COLUMN_DEFAULTS, ...(getShared(`wallet_columns_${norm(provider)}`, {}) || {}) };
}
export function saveWalletColumns(user, provider, cols) {
  const clean = {};
  COLUMN_FIELDS.forEach(([k]) => { clean[k] = txt(cols[k]).toLowerCase(); });
  clean.dateOrder = cols.dateOrder === 'mdy' ? 'mdy' : cols.dateOrder === 'ymd' ? 'ymd' : 'dmy';
  need(clean.date && (clean.amount || clean.amountIn || clean.amountOut), 'At least the date and an amount column are needed.');
  const before = walletColumns(provider);
  setShared(`wallet_columns_${norm(provider)}`, clean);
  audit({ user, action: `${provider} statement columns changed`, table: 'shared_settings', recordUid: `wallet_columns_${norm(provider)}`, before, after: clean });
  return clean;
}
// Which column holds each field: a heading matching one of the words (separated by |), exact first.
export function mapHeaders(headers, cols) {
  const h = headers.map((x) => txt(x).toLowerCase());
  const out = {};
  const used = new Set();
  for (const [k] of COLUMN_FIELDS) {
    const alts = String(cols[k] || '').split('|').map((x) => x.trim()).filter(Boolean);
    let i = -1;
    for (const a of alts) { i = h.findIndex((x, j) => !used.has(j) && x === a); if (i >= 0) break; }
    if (i < 0) for (const a of alts) { i = h.findIndex((x, j) => !used.has(j) && a.length > 2 && x.includes(a)); if (i >= 0) break; }
    if (i >= 0) { out[k] = i; used.add(i); }
  }
  return out;
}
const amountOf = (s) => {
  const t = String(s === null || s === undefined ? '' : s).replace(/[$,\s]|FJD/gi, '');
  if (!t || !/^[(+-]?\d+(\.\d+)?\)?(CR|DR)?$/i.test(t)) return null;
  let n = Number(t.replace(/[()+]/g, '').replace(/CR|DR/i, ''));
  if (/^\(.*\)$/.test(t) || /DR$/i.test(t) || /^-/.test(t)) n = -Math.abs(n);
  return r2(n);
};
const timeOf = (s) => { const m = /(\d{1,2}):(\d{2})(?::\d{2})?\s*([ap]m)?/i.exec(String(s || '')); if (!m) return ''; let h = Number(m[1]); if (m[3] && /pm/i.test(m[3]) && h < 12) h += 12; if (m[3] && /am/i.test(m[3]) && h === 12) h = 0; return `${String(h).padStart(2, '0')}:${m[2]}`; };
export function classifyWalletLine(l) {
  const d = `${l.description || ''} ${l.party || ''}`.toUpperCase();
  if (/\bFEE|CHARGE|COMMISSION\b/.test(d) && l.amount < 0) return 'fee';
  if (l.amount < 0 && /TRANSFER|BANK|BSP|WITHDRAW|CASH ?OUT/.test(d)) return 'transfer';
  if (l.amount > 0) return 'receipt';
  return 'other';
}
// Rows (arrays of cells, e.g. from CSV or Excel) → statement lines, using the admin's column words.
export function walletRowsToLines(rows, cols = walletColumns()) {
  let head = -1; let map = null;
  for (let i = 0; i < Math.min(rows.length, 30); i += 1) {
    const m = mapHeaders(rows[i], cols);
    if (m.date !== undefined && (m.amount !== undefined || m.amountIn !== undefined || m.amountOut !== undefined)) { head = i; map = m; break; }
  }
  const lines = []; const skipped = [];
  if (!map) return { lines, skipped: rows.map((r) => r.join(' ')), headers: rows[0] || [], map: null };
  for (const r of rows.slice(head + 1)) {
    const cell = (k) => (map[k] === undefined ? '' : txt(r[map[k]]));
    const date = readDate(cell('date').split(/[ T]/)[0], cols.dateOrder) || readDate(cell('date'), cols.dateOrder);
    let amount = null;
    if (map.amount !== undefined) amount = amountOf(cell('amount'));
    if (amount === null || amount === 0) {
      const a = amountOf(cell('amountIn')); const b = amountOf(cell('amountOut'));
      if (a) amount = Math.abs(a); else if (b) amount = -Math.abs(b);
    }
    if (!date || !amount) { if (r.some((x) => txt(x))) skipped.push(r.join(' ')); continue; }
    const l = { date, time: timeOf(cell('time') || cell('date')), description: cell('description'), reference: cell('reference'), party: cell('party'), amount, balance: amountOf(cell('balance')) };
    l.kind = classifyWalletLine(l);
    lines.push(l);
  }
  return { lines, skipped, headers: rows[head], map };
}
export function parseWalletCsv(text, cols = walletColumns()) {
  const rows = String(text || '').split(/\r?\n/).filter((x) => x.trim()).map(splitCsv);
  return walletRowsToLines(rows, cols);
}
// Text from a PDF or a screenshot (read by Google): each line with a date and an amount; money out when the
// line says sent / paid / transfer / fee / withdraw or has a minus sign.
export function parseWalletText(text, cols = walletColumns()) {
  const lines = []; const skipped = [];
  String(text || '').split(/\r?\n/).forEach((raw) => {
    const line = raw.trim();
    if (!line) return;
    const dm = /(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}[\s-][A-Za-z]{3,9}[\s-]\d{2,4})/.exec(line);
    const date = dm ? readDate(dm[1], cols.dateOrder) : null;
    const rest = dm ? line.replace(dm[1], ' ') : line;
    const nums = (rest.match(/[-+]?\(?\$?\d[\d,]*\.\d{2}\)?/g) || []).map(amountOf).filter((n) => n !== null);
    if (!date || !nums.length) { skipped.push(line); return; }
    let amount = nums[0];
    const desc = rest.replace(/[-+]?\(?\$?\d[\d,]*\.\d{2}\)?/g, ' ').replace(/\d{1,2}:\d{2}(:\d{2})?\s*([ap]m)?/i, ' ').replace(/\s+/g, ' ').trim();
    if (amount > 0 && /\b(SENT|PAID|PAYMENT TO|TRANSFER|FEE|CHARGE|WITHDRAW|CASH OUT|DEBIT)\b/i.test(desc) && !/\b(RECEIVED|FROM)\b/i.test(desc)) amount = -amount;
    const l = { date, time: timeOf(line), description: desc, reference: (/\b([A-Z0-9]{8,})\b/.exec(desc) || [])[1] || '', party: '', amount, balance: nums.length > 1 ? nums[nums.length - 1] : null };
    l.kind = classifyWalletLine(l);
    lines.push(l);
  });
  return { lines, skipped };
}

// ---------------------------------------------------------------- statement import
export function importWalletStatement(user, { walletUid, lines, fromDate, toDate, opening, closing, source, fileName, docUid }) {
  const w = getWallet(walletUid);
  need(w, 'Choose the wallet.');
  need(Array.isArray(lines) && lines.length, 'No statement lines were read. Check the columns (Settings › M-PAiSA statement columns).');
  const dates = lines.map((l) => l.date).sort();
  const from = txt(fromDate) || dates[0];
  const to = txt(toDate) || dates[dates.length - 1];
  need(DATE.test(from) && DATE.test(to) && from <= to, 'Enter the statement dates.');
  for (const l of lines) need(DATE.test(l.date) && r2(l.amount) !== 0, `A line has no date or amount (${l.description || ''}).`);
  const { now, dev } = meta();
  const uid = uuid('WI');
  let added = 0; let dup = 0;
  const key = (l) => `${l.date}|${l.time || ''}|${r2(l.amount)}|${txt(l.reference)}`;
  const seen = new Set(db().all('SELECT line_date, line_time, amount, reference FROM wallet_lines WHERE wallet_uid = ? AND line_date BETWEEN ? AND ?', [walletUid, from, to])
    .map((x) => key({ date: x.line_date, time: x.line_time, amount: x.amount, reference: x.reference })));
  db().transaction(() => {
    db().run(`INSERT INTO wallet_imports (uid, wallet_uid, from_date, to_date, opening, closing, source, file_name, doc_uid, line_count, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, walletUid, from, to, txt(opening) === '' || opening === undefined || opening === null ? null : r2(opening), txt(closing) === '' || closing === undefined || closing === null ? null : r2(closing), txt(source) || 'csv', txt(fileName) || null, docUid || null, 0, user.name, now, now, dev]);
    for (const l of lines) {
      if (seen.has(key(l))) { dup += 1; continue; }
      seen.add(key(l));
      db().run(`INSERT INTO wallet_lines (uid, import_uid, wallet_uid, line_date, line_time, description, reference, party, amount, balance, kind, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [uuid('WL'), uid, walletUid, l.date, txt(l.time) || null, txt(l.description) || null, txt(l.reference) || null, txt(l.party) || null, r2(l.amount), l.balance === null || l.balance === undefined ? null : r2(l.balance), l.kind || classifyWalletLine(l), now, dev]);
      added += 1;
    }
    db().run('UPDATE wallet_imports SET line_count = ? WHERE uid = ?', [added, uid]);
  });
  audit({ user, action: `${w.name} statement ${from} to ${to}: ${added} lines${dup ? `, ${dup} already in` : ''}`, table: 'wallet_imports', recordUid: uid });
  const m = autoMatchWallet(user, walletUid, from, to);
  return { uid, added, duplicates: dup, ...m };
}
export function listWalletImports(walletUid) {
  return db().all("SELECT * FROM wallet_imports WHERE (? IS NULL OR wallet_uid = ?) AND status = 'active' ORDER BY to_date DESC, created_at DESC", [walletUid || null, walletUid || null]);
}
export function walletLines(walletUid, { from, to, status } = {}) {
  return db().all(`SELECT * FROM wallet_lines WHERE wallet_uid = ? AND line_date >= ? AND line_date <= ? AND (? IS NULL OR status = ?) ORDER BY line_date, line_time`, [walletUid, from || '0000', to || '9999', status || null, status || null]);
}
// Transfers matched to the transfers recorded (± 3 days), fees booked, receipts matched to the shifts.
export function autoMatchWallet(user, walletUid, from, to) {
  const { now, dev } = meta();
  let transfers = 0; let fees = 0;
  for (const l of walletLines(walletUid, { from, to, status: 'unmatched' })) {
    if (l.kind === 'transfer') {
      const m = db().get(`SELECT * FROM wallet_moves WHERE wallet_uid = ? AND type = 'transfer_bank' AND status = 'active' AND ABS(amount - ?) < 0.005 AND move_date BETWEEN ? AND ?
        AND uid NOT IN (SELECT match_uid FROM wallet_lines WHERE match_uid IS NOT NULL AND status = 'matched') ORDER BY ABS(julianday(move_date) - julianday(?)) LIMIT 1`, [walletUid, Math.abs(l.amount), addDays(l.line_date, -3), addDays(l.line_date, 3), l.line_date]);
      if (m) {
        db().run(`UPDATE wallet_lines SET status = 'matched', match_type = 'move', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [m.uid, now, dev, l.uid]);
        db().run(`UPDATE wallet_moves SET cleared_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [l.line_date, now, dev, m.uid]);
        transfers += 1;
      }
    } else if (l.kind === 'fee') {
      let m = db().get(`SELECT * FROM wallet_moves WHERE wallet_uid = ? AND type = 'fee' AND status = 'active' AND ABS(amount - ?) < 0.005 AND move_date = ?
        AND uid NOT IN (SELECT match_uid FROM wallet_lines WHERE match_uid IS NOT NULL AND status = 'matched') LIMIT 1`, [walletUid, Math.abs(l.amount), l.line_date]);
      const uid = m ? m.uid : recordWalletMove(user, { walletUid, type: 'fee', date: l.line_date, amount: Math.abs(l.amount), reference: l.reference, note: l.description || 'From the wallet statement', clearedDate: l.line_date });
      db().run(`UPDATE wallet_lines SET status = 'matched', match_type = 'move', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [uid, now, dev, l.uid]);
      fees += 1;
    }
  }
  const shifts = confirmShiftMatches(user, walletUid, from, to);
  return { transfers, fees, shiftsOk: shifts.ok, shiftsProblem: shifts.problems };
}
// A transfer line with nothing recorded: record the transfer to BSP from the line (one tap).
export function transferFromLine(user, lineUid, accountUid) {
  const l = db().get('SELECT * FROM wallet_lines WHERE uid = ?', [lineUid]);
  need(l && l.status === 'unmatched' && l.amount < 0, 'Line already dealt with.');
  const mUid = recordWalletTransfer(user, { walletUid: l.wallet_uid, date: l.line_date, amount: Math.abs(l.amount), reference: l.reference || l.description, accountUid, note: 'From the wallet statement' });
  const { now, dev } = meta();
  db().run(`UPDATE wallet_lines SET status = 'matched', match_type = 'move', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [mUid, now, dev, lineUid]);
  db().run('UPDATE wallet_moves SET cleared_date = ? WHERE uid = ?', [l.line_date, mUid]);
  return mUid;
}
export function ignoreWalletLine(user, lineUid, note) {
  needReason(user, note, 'Say why this line is put aside.');
  const { now, dev } = meta();
  db().run(`UPDATE wallet_lines SET status = 'ignored', note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'unmatched'`, [txt(note) || null, now, dev, lineUid]);
  audit({ user, action: 'Wallet statement line put aside', table: 'wallet_lines', recordUid: lineUid, reason: note });
}

// ---------------------------------------------------------------- shifts' M-PAiSA sales against the receipts
// Receipts are given to the shift whose till balance was done next after the receipt (by time); without times,
// the day's receipts are compared with the day's shifts together.
export function shiftMatch(walletUid, from, to) {
  const w = getWallet(walletUid);
  if (!w) return [];
  const covered = (d) => !!db().get("SELECT 1 AS x FROM wallet_imports WHERE wallet_uid = ? AND status = 'active' AND from_date <= ? AND to_date >= ?", [walletUid, d, d]);
  const sales = walletSales(walletUid, from, to);
  const receipts = db().all("SELECT * FROM wallet_lines WHERE wallet_uid = ? AND kind = 'receipt' AND status <> 'ignored' AND line_date BETWEEN ? AND ? ORDER BY line_date, line_time", [walletUid, from, to]);
  const dates = Array.from(new Set(sales.map((s) => s.date).concat(receipts.map((x) => x.line_date)))).sort();
  const out = [];
  for (const d of dates) {
    const sh = sales.filter((s) => s.date === d).map((s) => ({ ...s, wallet: 0, receipts: [] }));
    const rc = receipts.filter((x) => x.line_date === d);
    const timed = sh.length > 1 && rc.every((x) => x.line_time) && sh.every((s) => /\d{2}:\d{2}/.test(s.countedAt || ''));
    let unassigned = 0;
    for (const x of rc) {
      let target = null;
      if (timed) target = sh.find((s) => s.countedAt.slice(11, 16) >= x.line_time) || sh[sh.length - 1];
      else if (sh.length === 1) target = sh[0];
      if (target) { target.wallet = r2(target.wallet + x.amount); target.receipts.push(x.uid); } else unassigned = r2(unassigned + x.amount);
    }
    const dayTill = r2(sh.reduce((t, s) => t + s.amount, 0));
    const dayWallet = r2(rc.reduce((t, x) => t + x.amount, 0));
    const hasStatement = covered(d);
    const note = (uid) => db().get('SELECT * FROM wallet_shift_notes WHERE uid = ?', [uid]);
    const shifts = sh.map((s) => {
      const diff = r2(s.wallet - s.amount);
      const n = note(s.countUid);
      const one = timed || sh.length === 1;
      const status = !hasStatement ? 'no_statement' : !one ? 'day' : Math.abs(diff) < 0.005 ? 'ok' : n ? 'explained' : diff < 0 ? 'short' : 'over';
      return { countUid: s.countUid, shift: s.shift, till: s.till, cashier: s.cashier, tillAmount: s.amount, walletAmount: s.wallet, diff, status, note: n ? n.note : null, receipts: s.receipts };
    });
    const dayDiff = r2(dayWallet - dayTill);
    const dn = note(`${walletUid}:${d}`);
    const dayStatus = !hasStatement ? 'no_statement' : Math.abs(dayDiff) < 0.005 ? 'ok' : dn ? 'explained' : dayDiff < 0 ? 'short' : 'over';
    const perShift = timed || sh.length <= 1;
    let status = dayStatus;
    if (hasStatement && perShift && dayStatus !== 'explained') {
      const bad = shifts.filter((s) => ['short', 'over'].includes(s.status));
      if (bad.length) status = bad.some((s) => s.status === 'short') ? 'short' : 'over';
      else if (unassigned > 0.004) status = 'over';
      else status = shifts.some((s) => s.status === 'explained') ? 'explained' : 'ok';
    }
    out.push({ date: d, shifts, dayTill, dayWallet, dayDiff, unassigned, status, note: dn ? dn.note : null, perShift });
  }
  return out;
}
export const MATCH_LABEL = { ok: 'Matches', short: 'Wallet got LESS than the till says – possible fake payment message', over: 'Wallet got more than the till recorded', explained: 'Explained', no_statement: 'No statement yet', day: 'Checked for the whole day' };
// Receipts of shifts (or days) that agree are marked matched; returns how many agree and how many do not.
export function confirmShiftMatches(user, walletUid, from, to) {
  const { now, dev } = meta();
  let ok = 0; let problems = 0;
  for (const day of shiftMatch(walletUid, from, to)) {
    if (day.status === 'no_statement') continue;
    if (day.status === 'ok' || day.status === 'explained') {
      ok += 1;
      db().run(`UPDATE wallet_lines SET status = 'matched', match_type = 'day', match_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE wallet_uid = ? AND kind = 'receipt' AND status = 'unmatched' AND line_date = ?`,
        [`${walletUid}:${day.date}`, now, dev, walletUid, day.date]);
    } else problems += 1;
  }
  return { ok, problems };
}
// The manager / owner explains a difference (e.g. "customer paid twice, refunded in cash"). Owner/admin need no words.
export function explainShift(user, key, note, walletUid = null) {
  needReason(user, note, 'Write what happened.');
  const { now, dev } = meta();
  db().run(`INSERT INTO wallet_shift_notes (uid, wallet_uid, note, by_name, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET note = excluded.note, by_name = excluded.by_name, at = excluded.at, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [key, walletUid, txt(note) || 'Checked', user.name, now, now, dev]);
  audit({ user, action: `M-PAiSA difference explained (${key})`, table: 'wallet_shift_notes', recordUid: key, reason: note });
}
// Problems for Home: shifts where the wallet got less than the till recorded (urgent), unsorted lines.
export function walletProblems(today = dateStr()) {
  const out = [];
  for (const w of listWallets()) {
    const days = shiftMatch(w.uid, addDays(today, -62), today);
    out.push({ wallet: w, short: days.filter((d) => d.status === 'short'), over: days.filter((d) => d.status === 'over'),
      unsorted: db().get("SELECT COUNT(*) AS n FROM wallet_lines WHERE wallet_uid = ? AND status = 'unmatched' AND kind <> 'receipt'", [w.uid]).n });
  }
  return out;
}
