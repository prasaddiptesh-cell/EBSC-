// Reading the cells of an Excel (.xlsx) sheet from its XML (the zip is opened in src/platform/statementFiles.js).
const unxml = (s) => String(s || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
export function sharedStrings(xml) {
  const out = [];
  const re = /<si>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = re.exec(String(xml || '')))) out.push(unxml((m[1].match(/<t[^>]*>([\s\S]*?)<\/t>/g) || []).map((t) => t.replace(/<t[^>]*>|<\/t>/g, '')).join('')));
  return out;
}
const colIndex = (ref) => { const l = (/^[A-Z]+/.exec(ref) || ['A'])[0]; let n = 0; for (const ch of l) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; };
// Excel keeps dates as day numbers (1 = 1900-01-01, with the 1900 leap-year quirk).
export function excelDate(n) {
  const d = new Date(Date.UTC(1899, 11, 30) + Math.round(Number(n)) * 86400000);
  return `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}/${d.getUTCFullYear()}`;
}
export function sheetRows(sheetXml, sharedXml, { dateCols = null } = {}) {
  const ss = sharedStrings(sharedXml);
  const rows = [];
  const rre = /<row[^>]*>([\s\S]*?)<\/row>/g;
  let r;
  while ((r = rre.exec(String(sheetXml || '')))) {
    const cells = [];
    const cre = /<c ([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let c;
    while ((c = cre.exec(r[1]))) {
      const attrs = c[1];
      const ref = (/r="([A-Z]+\d+)"/.exec(attrs) || [])[1] || '';
      const type = (/t="(\w+)"/.exec(attrs) || [])[1] || '';
      const style = (/s="(\d+)"/.exec(attrs) || [])[1];
      const inner = c[2] || '';
      let v = (/<v>([\s\S]*?)<\/v>/.exec(inner) || [])[1];
      if (type === 's') v = ss[Number(v)];
      else if (type === 'inlineStr') v = unxml(((/<t[^>]*>([\s\S]*?)<\/t>/.exec(inner) || [])[1]) || '');
      else v = v === undefined ? '' : unxml(v);
      const i = ref ? colIndex(ref) : cells.length;
      // Whole numbers between 30000 and 60000 in a styled cell are taken as dates (1982–2064).
      if (type === '' && style && /^\d{5}(\.\d+)?$/.test(v) && Number(v) > 30000 && Number(v) < 60000 && (!dateCols || dateCols.includes(i))) v = excelDate(v);
      cells[i] = v;
    }
    rows.push(Array.from(cells, (x) => (x === undefined ? '' : x)));
  }
  return rows;
}
