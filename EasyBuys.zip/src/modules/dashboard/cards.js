// The built-in dashboard cards. Other packages add or replace cards with registerCard (same id replaces).
import { db } from '../../db/connection.js';
import { money, dateStr } from '../../services/core.js';
import { registerCard } from '../../services/dashboardCards.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const any = (t, where = '1=1') => { try { return has(t) && !!db().get(`SELECT 1 AS x FROM ${t} WHERE ${where} LIMIT 1`); } catch (e) { return false; } };
const shops = (shop) => (shop && shop !== 'ALL' ? [shop] : ['S1', 'S2']);
const NOT = (text) => ({ notSetUp: true, text: text || 'Not set up yet' });
const MANAGERS = ['manager', 'supervisor'];

// Accounting is loaded only when a card needs it.
const A = () => require('../accounting/service.js');
const T = () => require('../till/service.js');

registerCard({ id: 'sales', title: 'Sales', icon: '🛒', order: 10, roles: MANAGERS, build(p, shop) {
  if (!any('till_counts') && !any('aronium_eods')) return NOT('Not set up yet – sales show once tills are counted or Aronium End of day figures come in.');
  const days = T().dailySales({ from: p.from, to: p.to, shopCode: shop === 'ALL' ? undefined : shop });
  const total = r2(days.reduce((s, d) => s + d.total, 0));
  let missing = 0;
  try { missing = r2(require('../till/eod.js').listEods({ from: p.from, to: p.to, shopCode: shop === 'ALL' ? undefined : shop, state: 'no_till' }).reduce((s, e) => s + e.total, 0)); } catch (e) { missing = 0; }
  const by = {};
  days.forEach((d) => { by[d.shop] = r2((by[d.shop] || 0) + d.total); });
  return { value: $(total + missing), sub: `${days.length} shop-day(s) from the till balances`, tone: missing ? 'warn' : undefined,
    lines: Object.entries(by).map(([k, v]) => [k, $(v)]).concat(missing ? [['Aronium, till balance missing', $(missing), 'bad']] : []), nav: { screen: 'ReportsHub', params: { group: 'Till & cash' } } };
} });

registerCard({ id: 'money', title: 'Money now', icon: '💰', order: 20, roles: ['manager'], build(p, shop) {
  const lines = [];
  let total = 0;
  if (any('tills') || any('cash_moves')) {
    for (const s of shops(shop)) { const c = T().cashOnHand(s, p.to); lines.push([`Cash at ${s} (with floats)`, $(c.total)]); total += c.total; }
  }
  if (shop === 'ALL' && any('bank_accounts', 'active = 1')) {
    const bank = A().balances({ to: p.to }).filter((b) => b.code.startsWith('1100'));
    bank.forEach((b) => { lines.push([b.name, $(b.balance)]); total += b.balance; });
    if (!bank.length) lines.push(['Bank', $(0)]);
  }
  if (!lines.length) return NOT();
  return { value: $(total), sub: `at ${p.to}`, lines, nav: { screen: 'Till', params: {} } };
} });

registerCard({ id: 'profit', title: 'Profit', icon: '📈', order: 30, roles: [], build(p, shop) {
  const pl = A().profitLoss({ from: p.from, to: p.to, shops: ['S1', 'S2'] });
  const x = pl.per[shop === 'ALL' ? 'total' : shop];
  if (!x || (!x.income && !x.expenses && !x.cogs)) return NOT('Not set up yet – nothing in the books for this period.');
  return { value: $(x.profit), tone: x.profit < 0 ? 'bad' : 'good', sub: x.margin === null ? '' : `Gross margin ${x.margin}%`,
    lines: [['Sales (ex VAT)', $(x.income)], ['Cost of sales', $(x.cogs)], ['Expenses', $(x.expenses)]].concat(shop === 'ALL' && pl.per.CLOSED ? [['of which closed shop costs', $(pl.per.CLOSED.expenses)]] : []),
    nav: { screen: 'ProfitLoss', params: {} } };
} });

registerCard({ id: 'owed', title: 'Who owes us', icon: '🧾', order: 40, roles: ['manager', 'payroll'], build() {
  const O = require('../owed/service.js');
  const t = O.owedTotals();
  if (!t.people && !O.latestCredit().asOf) return NOT('Not set up yet – nobody owes anything and no Aronium staff credit brought in.');
  return { value: $(t.total), sub: `${t.people} people`, tone: t.over ? 'bad' : t.approaching ? 'warn' : undefined,
    lines: [['Staff credit', $(t.credit)], ['Advances & loans', $(t.advances + t.loans)], ['Till shortages & charges', $(t.tillShort + t.charges)], ['Over 90 days', $(t.ageing.over90), t.ageing.over90 > 0 ? 'bad' : undefined]]
      .concat(t.over ? [['Over the credit limit', String(t.over), 'bad']] : []), nav: { screen: 'Owed', params: {} } };
} });

registerCard({ id: 'weowe', title: 'What we owe', icon: '📤', order: 50, roles: [], build(p) {
  if (!any('ap_invoices') && !any('ap_recurring', "kind = 'loan'")) return NOT();
  const b = A().balances({ to: p.to });
  const sum = (f) => r2(-b.filter(f).reduce((s, x) => s + x.balance, 0));
  const suppliers = sum((x) => x.code === '2000');
  const loans = sum((x) => x.code.startsWith('2500'));
  const other = sum((x) => x.type === 'liability' && !['2000', '2100', '2110', '2200', '2600'].includes(x.code) && !x.code.startsWith('2500') && x.code !== '2900');
  return { value: $(suppliers + loans + other), sub: `at ${p.to}`, lines: [['Suppliers', $(suppliers)], ['Loans', $(loans)]].concat(other ? [['Other', $(other)]] : []), nav: { screen: 'Payables', params: {} } };
} });

registerCard({ id: 'tax', title: 'Tax due', icon: '🏛️', order: 60, roles: ['payroll'], build(p) {
  const b = A().balances({ to: p.to });
  if (!b.length) return NOT();
  const owe = (code) => r2(-b.filter((x) => x.code === code).reduce((s, x) => s + x.balance, 0));
  const vat = owe('2200'); const fnpf = owe('2100'); const paye = owe('2110'); const prov = owe('2600');
  const ym = p.to.slice(0, 7);
  let due = '';
  try { due = A().lastDayOfNextMonth(ym); } catch (e) { due = ''; }
  return { value: $(Math.max(0, vat) + fnpf + paye + prov), sub: due ? `VAT for ${ym} due ${due}` : '', tone: vat + fnpf + paye > 0 ? 'warn' : undefined,
    lines: [[vat >= 0 ? 'VAT to pay' : 'VAT refund due', $(Math.abs(vat))], ['FNPF', $(fnpf)], ['PAYE / SRT', $(paye)]].concat(prov ? [['Provisional tax kept back', $(prov)]] : []), nav: { screen: 'TaxCentre', params: {} } };
} });

registerCard({ id: 'stock', title: 'Stock', icon: '📦', order: 70, roles: MANAGERS, build(p, shop) {
  if (!any('inv_moves')) return NOT('Not set up yet – no stock brought in.');
  const lines = shops(shop).map((s) => [s, $(A().stockValueAt(s, p.to))]);
  const total = r2(shops(shop).reduce((s, x) => s + A().stockValueAt(x, p.to), 0));
  return { value: $(total), sub: 'stock on hand at cost', lines, nav: { screen: 'Inventory', params: {} } };
} });

registerCard({ id: 'staff', title: 'Staff', icon: '👥', order: 80, roles: ['manager', 'payroll', 'supervisor'], build(p, shop) {
  const users = db().all("SELECT uid, shop_code FROM users WHERE active = 1 AND IFNULL(sync_status,'') <> 'seed'").filter((u) => shop === 'ALL' || !u.shop_code || u.shop_code === shop);
  if (!users.length) return NOT();
  let inNow = []; let off = [];
  try { inNow = require('../timeclock/service.js').whoIsIn().filter((x) => shop === 'ALL' || !x.shop_code || x.shop_code === shop); } catch (e) { inNow = []; }
  try { off = require('../leave/service.js').whoIsOff(dateStr()); } catch (e) { off = []; }
  return { value: `${inNow.length} at work`, sub: `${users.length} staff`, lines: [['On leave today', String(off.length)]].concat(inNow.slice(0, 6).map((x) => [x.name, x.state === 'break' ? 'on break' : 'in'])), nav: { screen: 'Home', params: {} } };
} });

registerCard({ id: 'till', title: 'Till checks', icon: '🧮', order: 90, roles: MANAGERS, build() {
  if (!any('tills')) return NOT('Not set up yet – add the tills (Till & cash › Tills & rules).');
  const t = T().tillAlerts();
  const bad = (t.eodDiff || []).length + (t.eodNoTill || []).length + (t.continued || []).length;
  return { value: bad ? `${bad} to sort out` : 'All good', tone: bad ? 'bad' : (t.waiting || (t.shortages || []).length) ? 'warn' : 'good',
    lines: [['To approve', String(t.waiting)], ['Not signed', String(t.unsigned || 0)], ['Aronium differs', String((t.eodDiff || []).length), (t.eodDiff || []).length ? 'bad' : undefined],
      ['Till balance missing', String((t.eodNoTill || []).length), (t.eodNoTill || []).length ? 'bad' : undefined], ['Shifts not balanced', String((t.shifts || []).length)],
      ['Shortages not agreed', String((t.shortages || []).length), (t.shortages || []).length ? 'warn' : undefined]], nav: { screen: 'Till', params: {} } };
} });

registerCard({ id: 'licences', title: 'Licences', icon: '📜', order: 100, roles: ['manager'], build() {
  if (!any('licences')) return NOT('Not set up yet – add the licences and permits.');
  return require('../licences/cards.js').licencesCard(); // v3.5 B7
} });

registerCard({ id: 'compliance', title: 'Compliance health', icon: '✅', order: 110, roles: [], build(p) {
  const ym = (() => { const d = new Date(`${p.to.slice(0, 7)}-01T12:00:00`); d.setMonth(d.getMonth() - 1); return dateStr(d).slice(0, 7); })();
  const m = A().monthEndChecklist(ym);
  const open = m.auto.filter((x) => !x.done).concat(m.manual.filter((x) => !x.done));
  return { value: open.length ? `${open.length} open for ${ym}` : `${ym} all done`, tone: open.length ? 'warn' : 'good', lines: open.slice(0, 6).map((x) => [x.label, x.left ? String(x.left) : 'to tick', 'warn']), nav: { screen: 'MonthEnd', params: {} } };
} });

registerCard({ id: 'watchdog', title: 'Watchdog', icon: '🐕', order: 120, roles: [], build() {
  const h = require('../../services/health.js');
  const issues = h.healthIssues();
  const last = h.latestHealth('full') || h.latestHealth('quick');
  if (!last) return NOT();
  return { value: issues.length ? `${issues.length} problem(s)` : 'No problems found', tone: issues.length ? 'warn' : 'good', sub: `Last check ${String(last.at || '').slice(0, 16)}`,
    lines: issues.slice(0, 5).map((x) => [x.label || x.step || 'Check', x.message || x.status, 'warn']) };
} });

registerCard({ id: 'drawings', title: "Owner's drawings", icon: '👤', order: 130, roles: [], build(p) {
  const list = A().entries({ from: p.from, to: p.to }).filter((e) => e.src !== 'Opening');
  let out = 0; let inn = 0;
  list.forEach((e) => e.lines.forEach((l) => { if (l.code === '3100') { if (l.amount > 0) out += l.amount; else inn -= l.amount; } }));
  if (!out && !inn) return NOT("Not set up yet – no owner's money in or out in this period.");
  return { value: $(out), sub: 'taken out by the owner', lines: [['Put in by the owner', $(inn)]], nav: { screen: 'ProfitLoss', params: {} } };
} });

registerCard({ id: 'closed', title: 'Closed shop costs', icon: '🏚️', order: 140, roles: [], build(p) {
  const pl = A().profitLoss({ from: p.from, to: p.to, shops: ['S1', 'S2'] });
  const x = pl.per.CLOSED;
  if (!x || (!x.expenses && !x.income)) return NOT('Nothing for the closed shop (V M Pillay) in this period.');
  return { value: $(x.expenses - x.income), sub: 'Closed shop – V M Pillay (whole business)', tone: 'warn', nav: { screen: 'ProfitLoss', params: {} } };
} });
