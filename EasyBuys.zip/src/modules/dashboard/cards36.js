// v3.6 dashboard cards: "today" at each shop (sales so far, deliveries in and due, cheques, invoices, events…) and the
// admin's own cards from the card builder. "Today" cards always show today, whatever period is chosen above.
import { db } from '../../db/connection.js';
import { money, dateStr, addDays, getShared, setShared, audit, stamp } from '../../services/core.js';
import { registerCard, unregisterCard, listCards } from '../../services/dashboardCards.js';
import { fmtDate } from '../../services/dates.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const q = (sql, a = []) => { try { return db().all(sql, a); } catch (e) { return []; } };
const one = (sql, a = []) => { try { return db().get(sql, a) || {}; } catch (e) { return {}; } };
const NOT = (text) => ({ notSetUp: true, text: text || 'Nothing yet' });
const shopWhere = (shop, col = 'shop_code') => (shop && shop !== 'ALL' ? [` AND ${col} = ?`, [shop]] : ['', []]);
const MANAGERS = ['manager', 'supervisor'];
const today = () => dateStr();

// ---------------------------------------------------------------- live sales (today so far)
export function salesOn(date, shop) {
  const [w, a] = shopWhere(shop);
  const till = one(`SELECT COALESCE(SUM(z_total),0) AS t, COUNT(*) AS n FROM till_counts WHERE status <> 'void' AND shift_date = ?${w}`, [date].concat(a));
  let eod = { t: 0, n: 0 };
  if (has('aronium_eods')) eod = one(`SELECT COALESCE(SUM(total),0) AS t, COUNT(*) AS n FROM aronium_eods WHERE state = 'no_till' AND eod_date = ?${w}`, [date].concat(a));
  return { total: r2((till.t || 0) + (eod.t || 0)), counts: (till.n || 0) + (eod.n || 0) };
}
registerCard({ id: 'live_sales', title: 'Sales today', icon: '🛒', order: 1, roles: MANAGERS, build(p, shop) {
  const d = today();
  const shops = shop === 'ALL' ? ['S1', 'S2'] : [shop];
  const lines = shops.map((s) => { const x = salesOn(d, s); const lw = salesOn(addDays(d, -7), s); return [`${s} (${x.counts} shift${x.counts === 1 ? '' : 's'} counted)`, `${$(x.total)}${lw.total ? ` · last week ${$(lw.total)}` : ''}`]; });
  const total = r2(shops.reduce((t, s) => t + salesOn(d, s).total, 0));
  const lw = r2(shops.reduce((t, s) => t + salesOn(addDays(d, -7), s).total, 0));
  return { value: $(total), sub: 'From till balances and Aronium End of day so far. Live sales start when the Aronium reader software is running.',
    tone: lw && total < lw * 0.8 ? 'warn' : undefined, lines: lines.concat(lw ? [['Same day last week', $(lw)]] : []), nav: { screen: 'Till', params: {} } };
} });

// ---------------------------------------------------------------- deliveries in today / due today
registerCard({ id: 'deliveries_today', title: 'Deliveries received today', icon: '🚚', order: 2, roles: MANAGERS, build(p, shop) {
  if (!has('inv_receipts')) return NOT();
  const [w, a] = shopWhere(shop);
  const rows = q(`SELECT * FROM inv_receipts WHERE status = 'active' AND kind = 'receive' AND receive_date = ?${w} ORDER BY created_at`, [today()].concat(a));
  if (!rows.length) return { value: 'None yet', sub: 'today', nav: { screen: 'POList', params: { status: 'to_receive' } } };
  return { value: $(rows.reduce((t, r) => t + (r.total || 0), 0)), sub: `${rows.length} deliver${rows.length === 1 ? 'y' : 'ies'} today`,
    tone: rows.some((r) => r.match_note) ? 'warn' : undefined,
    lines: rows.slice(0, 6).map((r) => [`${r.shop_code} · ${r.supplier_name || ''}${r.invoice_no ? ` · ${r.invoice_no}` : ''}`, `${$(r.total)}${r.match_note ? ' ⚠' : ''}`, r.match_note ? 'warn' : undefined]),
    nav: { screen: 'POList', params: {} } };
} });
export function posDue(date, shop) {
  if (!has('po_orders')) return [];
  const [w, a] = shopWhere(shop);
  return q(`SELECT * FROM po_orders WHERE status IN ('approved','sent','part') AND expected_date IS NOT NULL AND expected_date <= ?${w} ORDER BY expected_date, supplier_name`, [date].concat(a));
}
registerCard({ id: 'deliveries_due', title: 'Deliveries expected', icon: '📦', order: 3, roles: MANAGERS, build(p, shop) {
  if (!has('po_orders')) return NOT();
  const d = today();
  const rows = posDue(d, shop);
  if (!rows.length) return { value: 'Nothing due', sub: 'today', tone: 'good', nav: { screen: 'POList', params: {} } };
  const late = rows.filter((r) => r.expected_date < d);
  return { value: `${rows.length} order${rows.length === 1 ? '' : 's'}`, sub: late.length ? `${late.length} overdue` : 'due today', tone: late.length ? 'bad' : 'warn',
    lines: rows.slice(0, 6).map((r) => [`${r.shop_code} · ${r.supplier_name} · ${r.po_no}`, r.expected_date < d ? `late since ${fmtDate(r.expected_date, { year: false })}` : $(r.total), r.expected_date < d ? 'bad' : undefined]),
    nav: { screen: 'POList', params: { status: 'to_receive' } } };
} });

// ---------------------------------------------------------------- cheques written / invoices received / payments due
registerCard({ id: 'cheques_issued', title: 'Cheques written', icon: '✍️', order: 4, roles: [], build(p) {
  if (!has('cheques')) return NOT();
  const from = addDays(today(), -6);
  const rows = q("SELECT * FROM cheques WHERE status IN ('written','presented') AND cheque_date BETWEEN ? AND ? ORDER BY cheque_date DESC, cheque_no DESC", [from, today()]);
  const notPresented = one("SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS t FROM cheques WHERE status = 'written'");
  if (!rows.length && !notPresented.n) return NOT('No cheques written yet.');
  return { value: $(rows.reduce((t, r) => t + r.amount, 0)), sub: `${rows.length} in the last 7 days · ${notPresented.n || 0} not presented yet (${$(notPresented.t)})`,
    lines: rows.slice(0, 6).map((r) => [`#${r.cheque_no} ${r.payee || ''}`, `${$(r.amount)}${r.status === 'presented' ? ' ✓' : r.handed_date ? '' : ' (not handed over)'}`]),
    nav: { screen: 'Cheques', params: { tab: 'register' } } };
} });
registerCard({ id: 'invoices_today', title: 'Invoices received', icon: '🧾', order: 5, roles: MANAGERS, build(p, shop) {
  if (!has('ap_invoices')) return NOT();
  const [w, a] = shopWhere(shop);
  const rows = q(`SELECT * FROM ap_invoices WHERE status <> 'void' AND COALESCE(received_date, substr(entered_at,1,10), invoice_date) = ?${w} ORDER BY entered_at`, [today()].concat(a));
  if (!rows.length) return { value: 'None today', nav: { screen: 'ApInvoices', params: {} } };
  const noPhoto = rows.filter((r) => !r.photo_urls || r.photo_urls === '[]');
  const noTin = rows.filter((r) => !r.supplier_tin);
  return { value: $(rows.reduce((t, r) => t + (r.kind === 'credit' ? -r.total : r.total), 0)), sub: `${rows.length} today`, tone: noPhoto.length || noTin.length ? 'warn' : undefined,
    lines: rows.slice(0, 5).map((r) => [`${r.supplier_name}${r.invoice_no ? ` · ${r.invoice_no}` : ''}`, $(r.total)])
      .concat(noPhoto.length ? [['No photo', String(noPhoto.length), 'warn']] : []).concat(noTin.length ? [['No TIN', String(noTin.length), 'warn']] : []),
    nav: { screen: 'ApInvoices', params: {} } };
} });
registerCard({ id: 'payments_due', title: 'Payments due', icon: '📅', order: 6, roles: [], build() {
  if (!has('ap_invoices')) return NOT();
  const d = today();
  const rows = q("SELECT i.*, i.total - COALESCE((SELECT SUM(a.amount) FROM ap_allocations a WHERE a.invoice_uid = i.uid),0) AS left FROM ap_invoices i WHERE i.status <> 'void' AND i.kind = 'invoice' AND i.due_date <= ? ORDER BY i.due_date", [addDays(d, 7)])
    .filter((r) => r.left > 0.004);
  if (!rows.length) return { value: 'Nothing due', sub: 'this week', tone: 'good', nav: { screen: 'Payables', params: {} } };
  const over = rows.filter((r) => r.due_date < d);
  return { value: $(rows.reduce((t, r) => t + r.left, 0)), sub: `${rows.length} bill(s) due this week${over.length ? ` · ${over.length} overdue` : ''}`, tone: over.length ? 'bad' : 'warn',
    lines: rows.slice(0, 6).map((r) => [`${r.supplier_name} · due ${fmtDate(r.due_date, { year: false })}`, $(r.left), r.due_date < d ? 'bad' : undefined]), nav: { screen: 'Payables', params: {} } };
} });

// ---------------------------------------------------------------- deposits, write-offs, low stock, orders to send
registerCard({ id: 'deposits', title: 'Deposits', icon: '🏦', order: 7, roles: MANAGERS, build(p, shop) {
  if (!has('deposits')) return NOT();
  const [w, a] = shopWhere(shop);
  const rows = q(`SELECT * FROM deposits WHERE status = 'active' AND deposit_date BETWEEN ? AND ?${w} ORDER BY deposit_date DESC`, [p.from, p.to].concat(a));
  if (!rows.length) return { value: 'None', sub: 'in this period', nav: { screen: 'Till', params: {} } };
  return { value: $(rows.reduce((t, r) => t + r.total, 0)), sub: `${rows.length} deposit(s) in this period`,
    lines: rows.slice(0, 5).map((r) => [`${r.deposit_date} · ${r.shop_code}${r.slip_no ? ` · slip ${r.slip_no}` : ''}`, $(r.total)]), nav: { screen: 'Till', params: {} } };
} });
registerCard({ id: 'write_offs', title: 'Stock written off', icon: '🗑️', order: 8, roles: MANAGERS, build(p, shop) {
  if (!has('inv_moves')) return NOT();
  const [w, a] = shopWhere(shop, 'm.shop_code');
  const rows = q(`SELECT m.*, i.name FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.status = 'active' AND m.type = 'adjust' AND m.qty < 0 AND m.move_date BETWEEN ? AND ?${w} ORDER BY m.move_date DESC`, [p.from, p.to].concat(a));
  if (!rows.length) return { value: 'None', sub: 'in this period', tone: 'good' };
  return { value: $(rows.reduce((t, m) => t + -m.qty * (m.unit_cost || 0), 0)), sub: `${rows.length} write-off(s)`, tone: 'warn',
    lines: rows.slice(0, 5).map((m) => [`${m.shop_code} · ${m.name}`, $(-m.qty * (m.unit_cost || 0))]), nav: { screen: 'InvStock', params: {} } };
} });
registerCard({ id: 'low_stock', title: 'Low stock', icon: '⚠️', order: 9, roles: MANAGERS, build(p, shop) {
  let I;
  try { I = require('../inventory/service.js'); } catch (e) { return NOT(); }
  const shops = shop === 'ALL' ? ['S1', 'S2'] : [shop];
  const rows = [];
  shops.forEach((s) => { try { I.stockList({ shopCode: s, filter: 'low', limit: 50 }).forEach((r) => rows.push({ ...r, shop: s })); } catch (e) { /* none */ } });
  if (!rows.length) return { value: 'None', tone: 'good', nav: { screen: 'InvStock', params: { filter: 'low' } } };
  return { value: `${rows.length} product(s)`, tone: 'warn', lines: rows.slice(0, 6).map((r) => [`${r.shop} · ${r.name}`, String(r.on_hand)]), nav: { screen: 'InvStock', params: { filter: 'low' } } };
} });
registerCard({ id: 'orders_today', title: 'Orders to send today', icon: '📝', order: 10, roles: MANAGERS, build(p, shop) {
  let S;
  try { S = require('../inventory/schedules.js'); } catch (e) { return NOT(); }
  const rows = S.ordersForDay(today(), { shopCodes: shop === 'ALL' ? undefined : [shop] });
  if (!rows.length) return NOT('No supplier order days set up (Inventory › Supplier order days).');
  const open = rows.filter((r) => r.state !== 'sent' && r.state !== 'skipped');
  return { value: open.length ? `${open.length} to send` : 'All sent', tone: rows.some((r) => r.state === 'missed') ? 'bad' : open.length ? 'warn' : 'good',
    lines: rows.slice(0, 6).map((r) => [`${r.shopCode} · ${r.supplierName}${r.cutoff ? ` by ${r.cutoff}` : ''}`, r.state === 'missed' ? 'MISSED' : r.state, r.state === 'missed' ? 'bad' : r.state === 'sent' ? 'good' : undefined]),
    nav: { screen: 'TodaysOrders', params: {} } };
} });
registerCard({ id: 'bakery_today', title: 'Bakery today', icon: '🥖', order: 11, roles: MANAGERS, build() {
  if (!has('batches')) return NOT();
  const rows = q("SELECT b.*, p.name AS product FROM batches b LEFT JOIN products p ON p.id = b.product_id WHERE substr(b.started_at,1,10) = ?", [today()]);
  if (!rows.length) return { value: 'No batches yet', sub: 'today' };
  const good = rows.reduce((t, b) => t + (b.good || 0), 0);
  return { value: `${rows.length} batch${rows.length === 1 ? '' : 'es'}`, sub: `${rows.filter((b) => b.status === 'active').length} in progress · ${good} good pieces so far`,
    lines: rows.slice(0, 6).map((b) => [b.product || b.code, b.status === 'active' ? 'in progress' : `${b.good || 0} good`]) };
} });
registerCard({ id: 'warnings', title: 'Warnings', icon: '🔔', order: 12, roles: MANAGERS, build(p, shop, user) {
  let list = [];
  try { list = require('../../services/alerts.js').collectAlerts(user, { includeHidden: true }); } catch (e) { list = []; }
  const n = (l) => list.filter((a) => a.level === l).length;
  return { value: list.length ? `${list.length}` : 'None', tone: n('urgent') ? 'bad' : n('warning') ? 'warn' : 'good',
    lines: [['Urgent', String(n('urgent')), n('urgent') ? 'bad' : undefined], ['Warning', String(n('warning')), n('warning') ? 'warn' : undefined], ['Information', String(n('info'))]],
    nav: { screen: 'Warnings', params: {} } };
} });

// ---------------------------------------------------------------- today's events per shop
export function eventsToday(shop, user, date = today()) {
  const out = [];
  const shops = shop === 'ALL' ? ['S1', 'S2'] : [shop];
  try {
    require('../inventory/schedules.js').ordersForDay(date, { shopCodes: shops }).forEach((r) => {
      if (r.state !== 'sent' && r.state !== 'skipped') out.push({ time: r.cutoff || '', shop: r.shopCode, text: `Order cut-off: ${r.supplierName}`, tone: r.state === 'missed' ? 'bad' : 'warn' });
    });
  } catch (e) { /* not set up */ }
  posDue(date, shop).forEach((r) => out.push({ time: '', shop: r.shop_code, text: `Delivery due: ${r.supplier_name} (${r.po_no})`, tone: r.expected_date < date ? 'bad' : undefined }));
  try { require('../leave/service.js').whoIsOff(date).forEach((x) => out.push({ time: '', shop: x.shop_code || '', text: `On leave: ${x.name}` })); } catch (e) { /* none */ }
  if (new Date(`${date}T12:00:00`).getDay() === 6) out.push({ time: '', shop: '', text: 'Pay day (Saturday)', tone: 'warn' });
  if (has('licences')) q("SELECT * FROM licences WHERE status = 'active' AND expiry_date BETWEEN ? AND ?", [date, addDays(date, 7)]).forEach((l) => out.push({ time: '', shop: l.shop_code || '', text: `Licence expires ${fmtDate(l.expiry_date, { year: false })}: ${l.name}`, tone: 'warn' }));
  try {
    require('../../services/alerts.js').collectAlerts(user).filter((a) => a.level === 'urgent').slice(0, 5).forEach((a) => out.push({ time: '', shop: '', text: a.text, tone: 'bad' }));
  } catch (e) { /* none */ }
  return out.filter((e) => !e.shop || shops.includes(e.shop) || shop === 'ALL').sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
}
registerCard({ id: 'events_today', title: "Today's events", icon: '🗓️', order: 0, roles: MANAGERS, build(p, shop, user) {
  const ev = eventsToday(shop, user);
  if (!ev.length) return { value: 'Nothing special', sub: fmtDate(today()), tone: 'good' };
  return { value: `${ev.length} thing${ev.length === 1 ? '' : 's'}`, sub: fmtDate(today()), tone: ev.some((e) => e.tone === 'bad') ? 'bad' : 'warn',
    lines: ev.slice(0, 8).map((e) => [`${e.time ? `${e.time} ` : ''}${e.shop ? `${e.shop} · ` : ''}${e.text}`, '', e.tone]) };
} });

// ---------------------------------------------------------------- the admin's own cards (card builder)
// A figure from this list, for one shop or the whole business, over the chosen period (or always today), with
// optional colours: above "good from" green, below "warn below" amber.
export const METRICS = {
  sales: { label: 'Sales (till balances)', fmt: $, fn: (p, shop) => { let t = 0; for (let d = p.from; d <= p.to; d = addDays(d, 1)) t += salesOn(d, shop).total; return t; } },
  purchases: { label: 'Supplier invoices received', fmt: $, fn: (p, shop) => { const [w, a] = shopWhere(shop); return one(`SELECT COALESCE(SUM(CASE WHEN kind='credit' THEN -total ELSE total END),0) AS t FROM ap_invoices WHERE status <> 'void' AND invoice_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).t || 0; } },
  deposits: { label: 'Deposits banked', fmt: $, fn: (p, shop) => { const [w, a] = shopWhere(shop); return one(`SELECT COALESCE(SUM(total),0) AS t FROM deposits WHERE status = 'active' AND deposit_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).t || 0; } },
  shortages: { label: 'Till shortages', fmt: $, fn: (p, shop) => { const [w, a] = shopWhere(shop); return -(one(`SELECT COALESCE(SUM(over_short),0) AS t FROM till_counts WHERE status <> 'void' AND over_short < 0 AND shift_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).t || 0); } },
  write_offs: { label: 'Stock written off', fmt: $, fn: (p, shop) => { const [w, a] = shopWhere(shop); return one(`SELECT COALESCE(SUM(-qty * COALESCE(unit_cost,0)),0) AS t FROM inv_moves WHERE status = 'active' AND type = 'adjust' AND qty < 0 AND move_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).t || 0; } },
  received: { label: 'Deliveries received (value)', fmt: $, fn: (p, shop) => { const [w, a] = shopWhere(shop); return one(`SELECT COALESCE(SUM(total),0) AS t FROM inv_receipts WHERE status = 'active' AND kind = 'receive' AND receive_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).t || 0; } },
  cheques: { label: 'Cheques written (value)', fmt: $, fn: (p) => one("SELECT COALESCE(SUM(amount),0) AS t FROM cheques WHERE status IN ('written','presented') AND cheque_date BETWEEN ? AND ?", [p.from, p.to]).t || 0 },
  unpresented: { label: 'Cheques not presented yet', fmt: $, fn: () => one("SELECT COALESCE(SUM(amount),0) AS t FROM cheques WHERE status = 'written'").t || 0 },
  invoices_count: { label: 'Number of invoices received', fmt: (n) => String(n), fn: (p, shop) => { const [w, a] = shopWhere(shop); return one(`SELECT COUNT(*) AS n FROM ap_invoices WHERE status <> 'void' AND invoice_date BETWEEN ? AND ?${w}`, [p.from, p.to].concat(a)).n || 0; } },
  staff_in: { label: 'Staff at work now', fmt: (n) => String(n), fn: () => { try { return require('../timeclock/service.js').whoIsIn().length; } catch (e) { return 0; } } },
};
export function customCards() { const l = getShared('dashboard_custom_cards', []) || []; return Array.isArray(l) ? l : []; }
function registerCustom(c) {
  const m = METRICS[c.metric];
  if (!m) return;
  registerCard({ id: c.id, title: c.title || m.label, icon: c.icon || '⭐', order: 200 + (Number(c.n) || 0), roles: c.roles || [], custom: true, build(p, shop) {
    const s = c.shop && c.shop !== 'ANY' ? c.shop : shop;
    const period = c.today ? { from: today(), to: today() } : p;
    const v = r2(m.fn(period, s));
    const good = c.goodFrom === '' || c.goodFrom === undefined || c.goodFrom === null ? null : Number(c.goodFrom);
    const warn = c.warnBelow === '' || c.warnBelow === undefined || c.warnBelow === null ? null : Number(c.warnBelow);
    const tone = good !== null && v >= good ? 'good' : warn !== null && v < warn ? 'warn' : undefined;
    return { value: m.fmt(v), sub: `${m.label}${c.today ? ' · today' : ''}${s && s !== 'ALL' ? ` · ${s}` : ''}`, tone };
  } });
}
customCards().forEach(registerCustom);
export function saveCustomCard(user, c) {
  if (!user || !['owner', 'admin'].includes(user.role)) throw Object.assign(new Error('Only the owner or admin can make dashboard cards.'), { isAppError: true });
  if (!METRICS[c.metric]) throw Object.assign(new Error('Choose what the card shows.'), { isAppError: true });
  const list = customCards();
  const n = c.id ? Number(String(c.id).replace('custom_', '')) : list.reduce((m, x) => Math.max(m, Number(x.n) || 0), 0) + 1;
  const card = { id: `custom_${n}`, n, title: String(c.title || '').trim() || METRICS[c.metric].label, metric: c.metric, shop: c.shop || 'ANY', today: !!c.today,
    goodFrom: c.goodFrom ?? '', warnBelow: c.warnBelow ?? '', roles: c.roles || [], made: stamp() };
  const next = list.filter((x) => x.id !== card.id).concat([card]);
  setShared('dashboard_custom_cards', next);
  registerCustom(card);
  audit({ user, action: `Dashboard card "${card.title}" saved`, table: 'shared_settings' });
  return card;
}
export function deleteCustomCard(user, id) {
  if (!user || !['owner', 'admin'].includes(user.role)) throw Object.assign(new Error('Only the owner or admin can remove dashboard cards.'), { isAppError: true });
  setShared('dashboard_custom_cards', customCards().filter((x) => x.id !== id));
  unregisterCard(id);
  audit({ user, action: `Dashboard card ${id} removed`, table: 'shared_settings' });
}
export const knownCardIds = () => listCards().map((c) => c.id);
