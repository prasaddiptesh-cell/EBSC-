// Dashboard (v3.5): cards from a registry (src/services/dashboardCards.js); the built-in cards are in cards.js.
import './cards.js';
import './cards36.js';
import { DashboardScreen, DashboardCardsScreen, DashboardRolesScreen, DashboardBuilderScreen } from './screens/DashboardScreens.js';
import { can } from '../../services/access.js';
import { BusinessTodayScreen } from './screens/BusinessTodayScreen.js';
import { MENU } from './menu.js';

export default {
  id: 'dashboard',
  title: 'Dashboard',
  icon: '📊',
  screens: {
    BizDashboard: { component: DashboardScreen, can: (u) => can(u, 'dashboard') },
    DashboardCards: { component: DashboardCardsScreen, can: (u) => can(u, 'dashboard') },
    DashboardRoles: { component: DashboardRolesScreen, can: (u) => can(u, 'dashboard_setup') },
    DashboardBuilder: { component: DashboardBuilderScreen, can: (u) => !!u && ['owner', 'admin'].includes(u.role) },
    // 1.0.0 (build 1) the business at a glance (Office › Today)
    BusinessToday: { component: BusinessTodayScreen, can: (u) => can(u, 'dashboard') || require('../../services/dayStart.js').mayStartDay(u) },
  },
  menu: MENU,
};
