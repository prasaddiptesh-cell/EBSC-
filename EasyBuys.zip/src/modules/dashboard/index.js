// Dashboard (v3.5): cards from a registry (src/services/dashboardCards.js); the built-in cards are in cards.js.
import './cards.js';
import { DashboardScreen, DashboardCardsScreen, DashboardRolesScreen } from './screens/DashboardScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';

export default {
  id: 'dashboard',
  title: 'Dashboard',
  icon: '📊',
  screens: {
    BizDashboard: { component: DashboardScreen, can: (u) => can(u, 'dashboard') },
    DashboardCards: { component: DashboardCardsScreen, can: (u) => can(u, 'dashboard') },
    DashboardRoles: { component: DashboardRolesScreen, can: (u) => can(u, 'dashboard_setup') },
  },
  menu: MENU,
};
