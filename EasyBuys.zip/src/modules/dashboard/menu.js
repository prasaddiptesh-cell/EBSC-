// Dashboard menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '📊', title: 'Dashboard', note: 'Sales, money, profit, who owes us, tax, stock, staff, tills…', screen: 'BizDashboard' },
    { id: 'dash-today', icon: '🌅', title: 'Business today', note: 'Sales yesterday, cash, bank, M-PAiSA, owed and due – believable figures only.', screen: 'BusinessToday' },
  ] },
  { section: 'Settings', items: [
    { id: 'dash-cards', icon: '🧩', title: 'Choose my cards', note: 'Show, hide and order your cards.', screen: 'DashboardCards' },
    { id: 'dash-builder', icon: '⭐', title: 'Make a card', note: 'Pick a figure, a shop and colours (owner / admin).', screen: 'DashboardBuilder' },
    { id: 'dash-roles', icon: '⚙️', title: 'Cards for each role', note: 'Which roles see which cards (admin).', screen: 'DashboardRoles', perm: 'dashboard_setup' },
  ] },
];
