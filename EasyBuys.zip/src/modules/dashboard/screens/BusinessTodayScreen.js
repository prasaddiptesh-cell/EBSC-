// 1.0.0 (build 1) "Business today" – the business at a glance (map screen o-daystart, opened from Office › Today).
// Believable figures only: an End of day, cash or wallet figure that cannot be right is listed under "Checked, not
// counted" instead of being added in (services/dayStart.js businessGlance).
import React, { useMemo, useState } from 'react';
import { Screen, Btn, Banner, Section, useApp } from '../../../ui/components.js';
import { ListItem, Hint } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { businessGlance } from '../../../services/dayStart.js';

const $ = (n) => `${Number(n) < 0 ? '−' : ''}$${Math.abs(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export function BusinessTodayScreen() {
  const { nav } = useApp();
  const [n, bump] = useState(0);
  const g = useMemo(() => { try { return businessGlance(dateStr()); } catch (e) { return { error: e.message }; } }, [n]);
  if (g.error) return <Screen title="Business today"><Banner tone="danger" message={g.error} /></Screen>;
  return (
    <Screen title="Business today" subtitle="both shops">
      {g.sales.map((s) => <ListItem key={s.shop} testID={`bt-sales-${s.shop}`} title={`Sales yesterday – ${s.name || s.shop}`} sub={s.from === 'nothing sent' ? 'Nothing from the tills yet' : `from ${s.from}`} right={$(s.value)} onPress={() => nav.push('SalesHistory', {})} />)}
      <ListItem testID="bt-cash" title="Cash in safe" sub={g.cash.map((c) => `${c.shop} ${$(c.onHand)}`).join(' · ') || undefined} right={$(g.cashInSafe)} onPress={() => nav.push('CashOnHand', {})} />
      {g.bank ? <ListItem testID="bt-bank" title={g.bank.name || 'BSP bank'} sub={`the bank should show ${$(g.bank.inBank)}`} right={$(g.bank.book)} onPress={() => nav.push('ReconMonth', {})} /> : <Hint>Add the BSP account to see the bank here.</Hint>}
      <ListItem testID="bt-wallets" title="M-PAiSA wallets" sub={g.wallets.map((w) => `${w.shop} ${$(w.balance)}`).join(' · ') || undefined} right={$(g.walletTotal)} onPress={() => nav.push('Wallets', {})} />
      <ListItem testID="bt-owed" title="Owed to suppliers" right={$(g.owedSuppliers)} onPress={() => nav.push('ApInvoices', { filter: 'unpaid' })} />
      <ListItem testID="bt-due" title={`Due this week (${g.dueWeekCount})`} right={$(g.dueWeek)} tone={g.dueWeek ? 'warn' : undefined} onPress={() => nav.push('ApInvoices', { filter: 'due' })} />
      {g.flags.length ? (
        <Section title="Checked, not counted">
          {g.flags.map((f, i) => <ListItem key={i} testID={`bt-flag-${i}`} title={f} tone="warn" onPress={() => nav.push('AroniumEods', {})} />)}
        </Section>
      ) : null}
      <Btn testID="bt-more" title="The whole day start" size="md" variant="secondary" onPress={() => nav.push('DayStart', {})} />
      <Btn testID="bt-refresh" title="Refresh" size="sm" variant="ghost" onPress={() => bump((x) => x + 1)} />
    </Screen>
  );
}
