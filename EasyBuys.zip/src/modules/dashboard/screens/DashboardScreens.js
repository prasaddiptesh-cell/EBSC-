// Dashboard: period and shop selectors, the cards this person chose (in their order); choosing cards; admin: which
// roles see which cards.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Section, Chips, useApp, useUI, useLayout, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { ROLES, ROLE_LABEL } from '../../../services/access.js';
import { listShops } from '../../admin/service.js';
import { dateStr } from '../../../services/core.js';
import * as D from '../../../services/dashboardCards.js';
import * as B from '../cards36.js';
import { Field, Select } from '../../../ui/components.js';

const TONE = { good: C.success, warn: C.warn, bad: C.danger };
const shopOpts = () => [{ value: 'ALL', label: 'Whole business' }].concat(listShops().filter((s) => s.active && /^S\d/.test(s.code)).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })));

function DashCard({ c, nav, width }) {
  const tone = TONE[c.tone];
  return (
    <Pressable testID={`dash-${c.id}`} disabled={!c.nav} onPress={() => c.nav && nav.push(c.nav.screen, c.nav.params || {})}
      style={({ pressed }) => ({ width, minHeight: 130, backgroundColor: C.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: C.border, borderLeftWidth: 6, borderLeftColor: c.notSetUp ? C.border : (tone || C.info), opacity: pressed ? 0.75 : 1, gap: 4 })}>
      <Text style={{ fontSize: 15, fontWeight: '800', color: C.sub }}>{c.icon} {String(c.title).toUpperCase()}</Text>
      {c.notSetUp ? <Text testID={`dash-${c.id}-notset`} style={{ fontSize: 16, color: C.sub }}>{c.text || 'Not set up yet'}</Text> : (
        <>
          <Text style={{ fontSize: 26, fontWeight: '900', color: tone || C.text }}>{c.value}</Text>
          {c.sub ? <Text style={{ fontSize: 14, color: C.sub }}>{c.sub}</Text> : null}
          {(c.lines || []).map(([k, v, t], i) => (
            <View key={i} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}>
              <Text style={{ fontSize: 14, color: C.text, flex: 1 }} numberOfLines={1}>{k}</Text>
              <Text style={{ fontSize: 14, fontWeight: '700', color: TONE[t] || C.text }}>{v}</Text>
            </View>
          ))}
        </>
      )}
    </Pressable>
  );
}

export function DashboardScreen() {
  const { user, nav, can } = useApp();
  const { isPhone } = useLayout();
  const [from, to, setRange] = usePeriod('thismonth');
  const [shop, setShop] = useRemembered('shop', 'ALL');
  const today = dateStr();
  const cards = D.buildDashboard(user, { from, to: to > today ? today : to }, shop);
  return (
    <Screen title="Dashboard" subtitle="The business at a glance">
      <PeriodPicker testID="dash-period" from={from} to={to} onChange={setRange} />
      <Chips value={shop} onChange={setShop} testIDPrefix="dash-shop" options={shopOpts()} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        {cards.map((c) => <DashCard key={c.id} c={c} nav={nav} width={isPhone ? '100%' : 300} />)}
      </View>
      {!cards.length ? <Hint>No cards chosen. Tap "Choose my cards".</Hint> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="dash-choose" title="Choose my cards" icon="🧩" size="md" variant="secondary" onPress={() => nav.push('DashboardCards', {})} />
        {can('dashboard_setup') ? <Btn testID="dash-roles" title="Cards for each role" icon="⚙️" size="md" variant="secondary" onPress={() => nav.push('DashboardRoles', {})} /> : null}
        {['owner', 'admin'].includes(user.role) ? <Btn testID="dash-builder" title="Make a card" icon="⭐" size="md" variant="secondary" onPress={() => nav.push('DashboardBuilder', {})} /> : null}
      </View>
    </Screen>
  );
}

export function DashboardCardsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [l, setL] = useState(() => D.userLayout(user));
  const run = (fn) => { try { setL(fn()); } catch (e) { ui.error(e); } };
  return (
    <Screen title="My dashboard cards" subtitle="Show, hide and order your cards">
      <Hint>Only the cards your role may see are listed (the admin decides). Your choice follows you to every device.</Hint>
      {l.order.map((id, i) => {
        const c = D.getCard(id);
        const on = !l.hidden.includes(id);
        return (
          <Card key={id}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <Text style={{ flex: 1, fontSize: 18, fontWeight: '800', color: on ? C.text : C.sub }}>{c.icon} {c.title}</Text>
              <Btn testID={`dc-up-${id}`} title="▲" size="sm" variant="secondary" disabled={i === 0} onPress={() => run(() => D.moveCard(user, id, -1))} />
              <Btn testID={`dc-down-${id}`} title="▼" size="sm" variant="secondary" disabled={i === l.order.length - 1} onPress={() => run(() => D.moveCard(user, id, 1))} />
              <Btn testID={`dc-show-${id}`} title={on ? 'Shown' : 'Hidden'} size="sm" variant={on ? 'success' : 'ghost'} onPress={() => run(() => D.toggleCard(user, id, !on))} />
            </View>
          </Card>
        );
      })}
    </Screen>
  );
}

export function DashboardRolesScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [m, setM] = useState(() => D.cardRoles());
  const roles = ROLES.filter((r) => r !== 'owner' && r !== 'admin');
  const flip = (id, r) => setM({ ...m, [id]: (m[id] || []).includes(r) ? m[id].filter((x) => x !== r) : (m[id] || []).concat([r]) });
  return (
    <Screen title="Dashboard cards for each role" footer={<Btn testID="dr-save" title="Save" icon="💾" variant="success" onPress={() => { try { D.saveCardRoles(user, m); ui.toast('Saved'); } catch (e) { ui.error(e); } }} />}>
      <Hint>The owner and admin always see every card. Tick the roles that may see each card.</Hint>
      {D.listCards().map((c) => (
        <Section key={c.id} title={`${c.icon} ${c.title}`}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {roles.map((r) => {
              const on = (m[c.id] || []).includes(r);
              return <Btn key={r} testID={`dr-${c.id}-${r}`} title={`${on ? '☑' : '☐'} ${ROLE_LABEL[r] || r}`} size="sm" variant={on ? 'success' : 'secondary'} onPress={() => flip(c.id, r)} />;
            })}
          </View>
        </Section>
      ))}
    </Screen>
  );
}

// Owner / admin: make their own cards from a list of figures (card builder).
export function DashboardBuilderScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [, setTick] = useState(0);
  const blank = { id: '', title: '', metric: 'sales', shop: 'ANY', today: false, goodFrom: '', warnBelow: '' };
  const [f, setF] = useState(blank);
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const list = B.customCards();
  const save = () => { try { B.saveCustomCard(user, f); ui.toast('Card saved – it is now in "Choose my cards"'); setF(blank); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Make a dashboard card" subtitle="Pick a figure, a shop and colours">
      <Hint>New cards appear for the owner and admin straight away (add them in "Choose my cards"); tick roles in "Cards for each role" to show them to others.</Hint>
      {list.map((c) => (
        <Card key={c.id}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: C.text }}>⭐ {c.title} <Text style={{ color: C.sub, fontSize: 14 }}>· {(B.METRICS[c.metric] || {}).label}{c.today ? ' · today' : ''}{c.shop !== 'ANY' ? ` · ${c.shop}` : ''}</Text></Text>
            <Btn testID={`db-edit-${c.id}`} title="Change" size="sm" variant="secondary" onPress={() => setF({ ...blank, ...c })} />
            <Btn testID={`db-del-${c.id}`} title="Remove" size="sm" variant="ghost" onPress={() => { try { B.deleteCustomCard(user, c.id); setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
          </View>
        </Card>
      ))}
      <Section title={f.id ? 'Change the card' : 'New card'}>
        <Field testID="db-title" label="Card name" value={f.title} onChangeText={set('title')} placeholder={(B.METRICS[f.metric] || {}).label} />
        <Select testID="db-metric" label="What it shows" value={f.metric} onChange={set('metric')} options={Object.entries(B.METRICS).map(([k, m]) => ({ value: k, label: m.label }))} />
        <Chips value={f.shop} onChange={set('shop')} testIDPrefix="db-shop" options={[{ value: 'ANY', label: 'Shop chosen on the dashboard' }, { value: 'ALL', label: 'Whole business' }, { value: 'S1', label: 'Shop 1' }, { value: 'S2', label: 'Shop 2' }]} />
        <Chips value={f.today ? 'y' : 'n'} onChange={(v) => set('today')(v === 'y')} testIDPrefix="db-today" options={[{ value: 'n', label: 'Period chosen on the dashboard' }, { value: 'y', label: 'Always today' }]} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="db-good" label="Green from (optional)" value={String(f.goodFrom ?? '')} onChangeText={set('goodFrom')} keyboardType="decimal-pad" /></View>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="db-warn" label="Amber below (optional)" value={String(f.warnBelow ?? '')} onChangeText={set('warnBelow')} keyboardType="decimal-pad" /></View>
        </View>
        <Btn testID="db-save" title="Save card" icon="💾" variant="success" onPress={save} />
      </Section>
    </Screen>
  );
}
