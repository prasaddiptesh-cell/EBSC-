// Back camera that reads a QR code once and hands back the text.
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Text } from '../../ui/scale.js';

export default function QRScanner({ onScan, size = 300 }) {
  const [perm, requestPerm] = useCameraPermissions();
  const done = useRef(false);
  useEffect(() => { if (perm && !perm.granted && perm.canAskAgain) requestPerm(); }, [perm, requestPerm]);
  const box = { width: size, height: size, backgroundColor: '#111', borderRadius: 16, overflow: 'hidden', alignSelf: 'center' };
  if (!perm) return <View style={box} />;
  if (!perm.granted) {
    return (
      <View style={[box, { alignItems: 'center', justifyContent: 'center', padding: 12 }]}>
        <Text style={{ color: '#fff', textAlign: 'center', fontSize: 15 }}>Camera not allowed.{'\n'}Allow it in Android Settings › Apps › Easy Buys, or paste the code instead.</Text>
      </View>
    );
  }
  return (
    <View testID="qr-scanner" style={box}>
      <CameraView facing="back" style={{ flex: 1 }} barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
        onBarcodeScanned={(r) => {
          if (done.current || !r || !r.data) return;
          done.current = true;
          onScan(String(r.data));
        }} />
    </View>
  );
}
