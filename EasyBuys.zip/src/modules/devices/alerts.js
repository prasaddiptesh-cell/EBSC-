// Device warnings for the owner/admin (from the last device list, so they show offline too): a device that has not
// synced for a long time, a newly linked device, a blocked / paused / removed device that tried to connect.
import { actsAsOwner, can } from '../../services/access.js';
import { getShared } from '../../services/core.js';
import { cachedDevices } from './service.js';

export function deviceWarnings(list, { now = Date.now(), staleHours = Number((getShared('device_rules', {}) || {}).staleHours) || 24 } = {}) {
  const out = [];
  for (const d of list || []) {
    if (['removed', 'waiting'].includes(d.status) && !(d.attempts || []).length) continue;
    const seen = d.last_seen ? new Date(String(d.last_seen)).getTime() : 0;
    const first = d.first_seen ? new Date(String(d.first_seen)).getTime() : 0;
    if (d.status === 'active' && seen && now - seen > staleHours * 3600000) {
      out.push({ id: `dev-stale-${d.id}`, level: 'warning', text: `${d.name} has not synced for ${Math.round((now - seen) / 3600000)} hours`, sub: 'Is it switched on and online? Its new records are not in the cloud yet.', nav: { screen: 'DeviceDetail', params: { id: d.id, device: d } } });
    }
    if (first && now - first < 24 * 3600000 && d.status !== 'removed') {
      out.push({ id: `dev-new-${d.id}`, level: 'info', text: `New device linked: ${d.name}`, sub: `Invited by ${String(d.invited_by || 'someone').split(' @ ')[0]}. Block it if you do not know it.`, nav: { screen: 'DeviceDetail', params: { id: d.id, device: d } } });
    }
    const a = (d.attempts || [])[0];
    if (a && now - new Date(String(a.at)).getTime() < 3 * 24 * 3600000) {
      out.push({ id: `dev-try-${d.id}-${a.at}`, level: 'urgent', notify: true, text: `${d.name} tried to connect (${a.why})`, sub: 'A blocked, paused or removed device tried to use Easy Buys.', nav: { screen: 'DeviceDetail', params: { id: d.id, device: d } } });
    }
  }
  return out;
}

export function alerts(user) {
  if (!(actsAsOwner(user) || (user && user.role === 'admin') || can(user, 'settings'))) return [];
  const c = cachedDevices();
  return c ? deviceWarnings(c.list) : [];
}
