// This device's side of Admin › Devices: what it reports to the cloud, what the owner told it (roles allowed, shop, name,
// commands), the lock screen (paused, blocked, removed, access ended, wiped) and the remote wipe.
import { db } from '../../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, audit } from '../../services/core.js';
import { latestHealth } from '../../services/health.js';
import { problemReport } from '../../services/errorLog.js';
import { clearTables, tablesFor, FRESH_ORDER } from '../../services/startFresh.js';

const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };

// Reported on each pull: items waiting to send, last health check, last safety copy, last login.
export function deviceStat(pending = 0) {
  const h = latestHealth('quick');
  return { pending, health: h ? `${h.status} ${String(h.at).slice(0, 16)}` : null, backup: getSetting('last_snapshot_at', '') || null, login: J(getSetting('last_login', ''), null) };
}
export function noteLogin(u) { try { setSetting('last_login', JSON.stringify({ name: u.name, role: u.role, at: stamp() })); } catch (e) { /* ignore */ } }

// What the owner set for this device in Admin › Devices.
export function applyControl(control) {
  if (!control) return;
  setSetting('device_roles', JSON.stringify(control.roles || []));
  setSetting('device_end_date', control.endDate || '');
  if (control.shop) setSetting('device_shop', control.shop);
  if (control.name) setSetting('device_name', control.name);
}
export function rolesAllowedHere() { return J(getSetting('device_roles', ''), []) || []; }
// Why this person may not log in on this device (null = they may). The owner always may.
export function loginBlockedHere(u) {
  if (!u || u.role === 'owner') return null;
  const roles = rolesAllowedHere();
  if (roles.length && !roles.includes(u.role)) return 'This device is only for some people. Ask the owner (Admin › Devices).';
  const end = getSetting('device_end_date', '');
  if (end && end < dateStr()) return `Access on this device ended on ${end}.`;
  return null;
}

// Commands from the owner, run once each. send(body) posts to the cloud.
export async function runCommands(cmds, { send } = {}) {
  const done = [];
  for (const c of cmds || []) {
    try {
      if (c.kind === 'signout') setSetting('force_logout', stamp());
      if (c.kind === 'log' && send) await send({ kind: 'problem_log', text: problemReport({}) });
      done.push(c.kind);
    } catch (e) { /* tried again when asked again */ }
  }
  if (done.length) audit({ user: null, action: `Did what the owner asked: ${done.join(', ')}`, table: 'settings' });
  return done;
}

// The lock screen. kind: blocked | suspended | ended | removed | wiped.
export function deviceLock() {
  if (getSetting('device_blocked', '0') === '1') return { kind: 'blocked' };
  const l = J(getSetting('device_lock', ''), null);
  if (!l || !l.kind) return null;
  if (l.kind === 'suspended' && l.until && l.until < stamp().slice(0, 16).replace(' ', 'T')) return null; // the pause ran out
  return l;
}
export function setDeviceLock(lock) { setSetting('device_lock', lock ? JSON.stringify(lock) : ''); }
export const LOCK_TEXT = {
  blocked: ['This device has been blocked', 'The owner blocked it in Devices (for example because it was lost). Nothing can be opened until it is allowed again.'],
  suspended: ['Access paused by the owner', 'This device can be used again after the time below, or when the owner allows it.'],
  ended: ['Access on this device has ended', 'The owner set an end date for this device. Ask the owner if you still need it.'],
  removed: ['This device was removed', 'The owner removed it from Easy Buys. To use it again, link it with a new invite.'],
  wiped: ['This device was wiped', 'The owner wiped the Easy Buys data on this device. Everything is still safe in the cloud. Link it again with a new invite.'],
};

// Remote wipe: clear every business record on this device (the cloud copy is kept) and forget the cloud link.
export function wipeThisDevice() {
  const tables = tablesFor(FRESH_ORDER);
  clearTables(tables, '9999-12-31');
  ['users', 'audit_log', 'photos', 'outbox', 'doc_local'].forEach((t) => { try { db().run(`DELETE FROM ${t}`); } catch (e) { /* not on this device */ } });
  ['cloud_url', 'cloud_token', 'cloud_key', 'linked_at', 'link_waiting', 'last_login', 'audit_chain', 'audit_chain_bad'].forEach((k) => setSetting(k, ''));
  setDeviceLock({ kind: 'wiped', at: stamp() });
}
