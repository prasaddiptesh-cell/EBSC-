// This device's side of Admin › Devices: what it reports to the cloud, what the owner told it (roles allowed, shop, name,
// commands), the lock screen (paused, blocked, removed, access ended, wiped) and the remote wipe.
import { db } from '../../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, audit } from '../../services/core.js';
import { latestHealth } from '../../services/health.js';
import { problemReport } from '../../services/errorLog.js';
import { clearTables, tablesFor, FRESH_ORDER } from '../../services/startFresh.js';
import { requireOwner, asService } from '../../services/guard.js';

const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };

// Reported on each pull: items waiting to send, last health check, last safety copy, last login.
export function deviceStat(pending = 0) {
  const h = latestHealth('quick');
  // 1.0.0 build 1: the clock difference to Google's time and the time zone go too (the owner is told of tampering).
  let tz = null;
  try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || null; } catch (e) { tz = null; }
  if (!tz) { const o = -new Date().getTimezoneOffset(); tz = `${o >= 0 ? '+' : '-'}${String(Math.floor(Math.abs(o) / 60)).padStart(2, '0')}`; }
  return { pending, health: h ? `${h.status} ${String(h.at).slice(0, 16)}` : null, backup: getSetting('last_snapshot_at', '') || null, login: J(getSetting('last_login', ''), null),
    clockSkewMin: Number(getSetting('clock_skew_min', '0')) || 0, tz };
}
export function noteLogin(u) { require('../../services/guard.js').requireLogin(u); try { setSetting('last_login', JSON.stringify({ name: u.name, role: u.role, at: stamp() })); } catch (e) { /* ignore */ } }

// What the owner set for this device in Admin › Devices.
export function applyControl(control) {
  if (!control) return;
  setSetting('device_roles', JSON.stringify(control.roles || []));
  setSetting('device_end_date', control.endDate || '');
  if (control.shop) setSetting('device_shop', control.shop);
  if (control.name) setSetting('device_name', control.name);
}
export function rolesAllowedHere() { return J(getSetting('device_roles', ''), []) || []; }
// Why this person may not log in on this device (null = they may). The owner always may.
export function loginBlockedHere(u) {
  if (!u || u.role === 'owner' || u.role === 'admin') return null; // v3.9.2 the owner and admin always get in
  const roles = rolesAllowedHere();
  if (roles.length && !roles.includes(u.role)) return 'This device is only for some people. Ask the owner (Admin › Devices).';
  const end = getSetting('device_end_date', '');
  if (end && end < dateStr()) return `Access on this device ended on ${end}.`;
  return null;
}

// Commands from the owner, run once each. send(body) posts to the cloud.
export async function runCommands(cmds, { send } = {}) {
  const done = [];
  for (const c of cmds || []) {
    try {
      if (c.kind === 'signout') setSetting('force_logout', stamp());
      if (c.kind === 'log' && send) await send({ kind: 'problem_log', text: problemReport({}) });
      done.push(c.kind);
    } catch (e) { /* tried again when asked again */ }
  }
  if (done.length) audit({ user: null, action: `Did what the owner asked: ${done.join(', ')}`, table: 'settings' });
  return done;
}

// The lock screen. kind: blocked | suspended | ended | removed | wiped.
export function deviceLock() {
  // v3.9.2 practice (training) mode is never locked – it is local practice data only, nothing reaches the cloud.
  try { if (require('../../platform/training.js').isTraining()) return null; } catch (e) { /* not in the app */ }
  const over = J(getSetting('lock_override', ''), null);
  if (getSetting('device_blocked', '0') === '1') return over ? null : { kind: 'blocked' };
  const l = J(getSetting('device_lock', ''), null);
  if (!l || !l.kind) return null;
  if (l.kind === 'suspended' && l.until && l.until < stamp().slice(0, 16).replace(' ', 'T')) return null; // the pause ran out
  if (over && ['blocked', 'suspended', 'ended', 'removed'].includes(l.kind)) return null;
  return l;
}
// v3.9.2 The owner or an admin can open a locked device on the spot with their own PIN (the cloud still refuses it
// until it is allowed again in Devices, so nothing syncs – the device works on its own data meanwhile).
export function overrideLock(user) {
  requireOwner(user, 'open a locked device'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !['owner', 'admin'].includes(user.role)) throw Object.assign(new Error('Only the owner or an admin can open a locked device.'), { isAppError: true });
  setSetting('lock_override', JSON.stringify({ by: user.name, uid: user.uid, at: stamp() }));
  try { require('../../services/core.js').audit({ user, action: `Device lock overridden on this device by ${user.name} (still blocked in the cloud until allowed again)`, table: 'settings', recordUid: 'device_lock' }); } catch (e) { /* history is best effort */ }
  });
}
export function lockOverride() { return J(getSetting('lock_override', ''), null); }
export function clearLockOverride() { setSetting('lock_override', ''); }
export function setDeviceLock(lock) { setSetting('device_lock', lock ? JSON.stringify(lock) : ''); }
export const LOCK_TEXT = {
  blocked: ['This device has been blocked', 'The owner blocked it in Devices (for example because it was lost). Nothing can be opened until it is allowed again.'],
  suspended: ['Access paused by the owner', 'This device can be used again after the time below, or when the owner allows it.'],
  ended: ['Access on this device has ended', 'The owner set an end date for this device. Ask the owner if you still need it.'],
  removed: ['This device was removed', 'The owner removed it from Easy Buys. To use it again, link it with a new invite.'],
  wiped: ['This device was wiped', 'The owner wiped the Easy Buys data on this device. Everything is still safe in the cloud. Link it again with a new invite.'],
};

// Remote wipe: clear every business record on this device (the cloud copy is kept) and forget the cloud link.
export function wipeThisDevice() {
  const tables = tablesFor(FRESH_ORDER);
  clearTables(tables, '9999-12-31');
  ['users', 'audit_log', 'photos', 'outbox', 'doc_local'].forEach((t) => { try { db().run(`DELETE FROM ${t}`); } catch (e) { /* not on this device */ } });
  ['cloud_url', 'cloud_token', 'cloud_key', 'linked_at', 'link_waiting', 'last_login', 'audit_chain', 'audit_chain_bad'].forEach((k) => setSetting(k, ''));
  setDeviceLock({ kind: 'wiped', at: stamp() });
}
