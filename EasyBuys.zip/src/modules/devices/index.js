// Devices module: link new tablets and phones with an invite (QR, email, message), list and block devices.
import DevicesScreen from './screens/DevicesScreen.js';
import { can } from '../../services/access.js';

export default {
  id: 'devices',
  title: 'Devices',
  icon: '📲',
  screens: {
    Devices: { component: DevicesScreen, can: (u) => can(u, 'settings') },
  },
  reports: [],
};
