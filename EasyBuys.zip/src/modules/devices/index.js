// Devices module: link new tablets and phones with an invite (QR, email, message), list and block devices.
import DevicesScreen from './screens/DevicesScreen.js';
import DeviceDetailScreen from './screens/DeviceDetailScreen.js';
import AddPhoneScreen from './screens/AddPhoneScreen.js';
import { alerts } from './alerts.js';
import { can } from '../../services/access.js';

export default {
  id: 'devices',
  title: 'Devices',
  icon: '📲',
  screens: {
    Devices: { component: DevicesScreen, can: (u) => can(u, 'settings') },
    DeviceDetail: { component: DeviceDetailScreen, can: (u) => can(u, 'settings') },
    // 1.0.0 build 10: Home › Add a phone (one big QR code for up to 5 phones, 1 hour)
    AddPhone: { component: AddPhoneScreen, can: (u) => can(u, 'settings') },
  },
  reports: [],
  alerts,
};
