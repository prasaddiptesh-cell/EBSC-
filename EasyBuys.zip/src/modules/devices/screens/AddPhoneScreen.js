// 1.0.0 build 10 (owner, 2 Nov: "the linking of devices is a mess"): Home › Add a phone opens straight to ONE big QR
// code – for shop devices, valid for 1 hour and for up to 5 phones (several staff phones in one go). "Share code" sends
// it by Viber / WhatsApp; the owner can cancel it. A busy cloud is tried again by itself. New phones waiting for the
// owner's OK are listed here with Allow / Block. (The owner's own phone: Admin › Devices › Add a device.)
import React, { useEffect, useRef, useState } from 'react';
import { View, Share } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, Chips, Card, useApp, useUI, useLayout } from '../../../ui/components.js';
import { listShops } from '../../admin/service.js';
import { C } from '../../../ui/theme.js';
import { QRCodeView } from '../../../ui/qr.js';
import { getSetting, setSetting } from '../../../services/core.js';
import { cloudCallRetry, cloudCall } from '../../../platform/cloud.js';
import { linkState, inviteMessage, waitingDevices, fijiClockText } from '../service.js';

export const ADD_PHONE = { uses: 5, hours: 1, pollMs: 20000 };
// 1.0.0 build 16 (owner, 7 Nov: "getting a new device hooked on is a hassle … sync by the role I give while giving
// access"): the role is chosen first; the QR code carries it and the device is allowed at once (cloud script 21) – no
// "Allow?" afterwards. 30 minutes; one device for the owner's own, up to 5 for the others.
export const DEVICE_ROLES = [
  { value: 'staff', label: 'Shop / staff', icon: '🛒', note: 'Daily shop work: time clock, tills & cash, stock, deliveries, photos of invoices, checklists. No wages, accounts, bank statements or loans.', shop: true, uses: 5 },
  { value: 'bakery', label: 'Bakery', icon: '🥖', note: 'The bakery tablet: bakery work, stock, time clock. Like a shop device.', shop: true, uses: 2 },
  { value: 'manager', label: 'Manager / office', icon: '🗂️', note: 'Everything except wages & payroll, the books and the owner\'s own money.', shop: true, uses: 3 },
  { value: 'owner', label: 'Owner / admin', icon: '🔒', note: 'Everything, with the owner and admin PINs. Only for a device that stays with you or an admin.', shop: false, uses: 1 },
];
export const ROLE_HOURS = 0.5;
export const roleLabel = (r) => { const x = DEVICE_ROLES.find((d) => d.value === r); return x ? `${x.icon} ${x.label}` : 'Everything (no role)'; };

export default function AddPhoneScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const { isPhone, width } = useLayout();
  const link = linkState();
  const [inv, setInv] = useState(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [waiting, setWaiting] = useState(() => waitingDevices());
  const shops = (() => { try { return listShops().filter((x) => x.active); } catch (e) { return []; } })();
  const [role, setRole] = useState('staff');
  const [shop, setShop] = useState((user && user.shop_code) || (shops[0] && shops[0].code) || '');
  const roleInfo = DEVICE_ROLES.find((x) => x.value === role) || DEVICE_ROLES[0];
  const roleCloud = Number(getSetting('cloud_script_version', '0')) >= 21;
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  const make = async () => {
    setError(''); setBusy('Making the QR code…');
    try {
      const body = roleCloud
        ? { kind: 'invite_create', url: link.url, by: user.name, role, shop: roleInfo.shop ? shop : '', uses: roleInfo.uses, hours: ROLE_HOURS }
        : { kind: 'invite_create', url: link.url, by: user.name, uses: ADD_PHONE.uses, hours: ADD_PHONE.hours };
      const r = await cloudCallRetry(body, 45000,
        { onRetry: () => { if (alive.current) setBusy('Making the QR code… the cloud is busy, trying again'); } });
      if (alive.current) setInv({ ...r, role: roleCloud ? role : null, shop: roleCloud && roleInfo.shop ? shop : '' });
    } catch (e) { if (alive.current) setError(e.message || String(e)); }
    if (alive.current) setBusy('');
  };
  // 1.0.0 build 16: the role first (an older cloud has no roles: straight to the QR code, as before)
  useEffect(() => { if (link.linked && !roleCloud) make(); }, []);
  // the waiting list: from the last sync, and asked again every 20 seconds while this screen is open.
  // review (3 Nov): never two at once – a slow answer (up to 45 s, tried twice) used to pile up requests every 20 s.
  const asking = useRef(false);
  useEffect(() => {
    if (!link.linked) return undefined;
    const h = setInterval(async () => {
      if (asking.current || !alive.current) return;
      asking.current = true;
      try { const r = await cloudCallRetry({ kind: 'devices' }, 45000, { tries: 2 }); const w = (r.devices || []).filter((d) => d.status === 'waiting').map((d) => ({ id: String(d.id), name: d.name, kind: d.kind })); setSetting('devices_waiting', JSON.stringify(w)); if (alive.current) setWaiting(w); } catch (e) { /* next time */ }
      finally { asking.current = false; }
    }, ADD_PHONE.pollMs);
    return () => clearInterval(h);
  }, []);

  const cancel = async () => {
    if (!inv) return;
    const ok = await ui.confirm({ title: 'Cancel this QR code?', message: 'Phones can no longer join with it. Phones already linked stay linked.', confirmText: 'Cancel the code', cancelText: 'Keep it', tone: 'danger' });
    if (!ok) return;
    try { await cloudCallRetry({ kind: 'invite_cancel', code: inv.code, by: user.name }, 45000); setInv(null); ui.toast('Cancelled'); } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
  };
  // 1.0.0 build 13: "Allow – my phone" = the owner's / an admin's own phone (the owner / admin PINs come with its first sync)
  const decide = async (d, status, admin = false) => {
    if (admin) {
      const ok = await ui.confirm({ title: 'Your own phone?', message: ADMIN_PHONE_TEXT, confirmText: 'Yes – my phone', cancelText: 'No' });
      if (!ok) return;
    }
    try { await cloudCall({ kind: 'device_status', id: d.id, status, admin: admin || undefined }, 45000); const w = waiting.filter((x) => x.id !== d.id); setSetting('devices_waiting', JSON.stringify(w)); setWaiting(w); ui.toast(status === 'active' ? `${d.name} allowed` : `${d.name} blocked`); } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
  };

  if (!link.linked) {
    return (
      <Screen title="Add a phone">
        <Banner tone="info" title="This device is not linked yet" message="Link this device to the Easy Buys cloud first (Admin › Online & email)." />
      </Screen>
    );
  }
  const qrSize = Math.min(isPhone ? width - 48 : 380, 380);
  return (
    <Screen title="Add a phone" subtitle="Staff and family phones join by scanning this">
      {waiting.map((d) => (
        <View key={d.id} testID={`addphone-waiting-${d.id}`} style={{ backgroundColor: '#FEF0C7', borderRadius: 14, padding: 12, gap: 8, borderWidth: 2, borderColor: C.warn }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${d.kind === 'tablet' ? '📟' : '📱'} ${d.name} wants to join`}</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID={`addphone-allow-${d.id}`} title="Allow – staff phone" size="md" variant="success" style={{ flex: 1 }} onPress={() => decide(d, 'active')} />
            <Btn testID={`addphone-block-${d.id}`} title="Block" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => decide(d, 'blocked')} />
          </View>
          <Btn testID={`addphone-allow-admin-${d.id}`} title="Allow – my own phone (owner / admin)" icon="🔒" size="md" variant="secondary" onPress={() => decide(d, 'active', true)} />
        </View>
      ))}
      {busy ? <Banner testID="addphone-busy" tone="info" title={busy} message="Keep this screen open." /> : null}
      {error ? <Banner testID="addphone-error" tone="danger" title="No QR code yet" message={error} /> : null}
      {error ? <Btn testID="addphone-again" title="Try again" icon="🔄" onPress={make} /> : null}
      {!inv && roleCloud && link.linked ? (
        <Card>
          <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>What is the new device for?</Text>
          <Chips value={role} onChange={setRole} testIDPrefix="addphone-role" options={DEVICE_ROLES.map((x) => ({ value: x.value, label: `${x.icon} ${x.label}` }))} />
          <Text style={{ fontSize: 15, color: C.sub }}>{roleInfo.note}</Text>
          {roleInfo.shop && shops.length > 1 ? (
            <>
              <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Which shop?</Text>
              <Chips value={shop} onChange={setShop} testIDPrefix="addphone-shop" options={shops.map((x) => ({ value: x.code, label: x.name || x.code }))} />
            </>
          ) : null}
          <Btn testID="addphone-make" title="Make the QR code" icon="🔳" variant="success" disabled={!!busy} onPress={make} />
          <Text style={{ fontSize: 14, color: C.sub }}>{`The device that scans it is allowed straight away – no "Allow?" afterwards. It works for ${roleInfo.uses === 1 ? 'one device' : `up to ${roleInfo.uses} devices`} for 30 minutes.`}</Text>
        </Card>
      ) : null}
      {inv ? (
        <View testID="addphone-ready" style={{ alignItems: 'center', gap: 12 }}>
          <Text style={{ fontSize: 19, fontWeight: '800', color: C.text, textAlign: 'center' }}>On the new phone: open Easy Buys › Scan to join Easy Buys</Text>
          {inv.role ? <Text testID="addphone-role-chosen" style={{ fontSize: 17, fontWeight: '800', color: C.success, textAlign: 'center' }}>{`${roleLabel(inv.role)}${inv.shop ? ` · ${inv.shop}` : ''} · allowed straight away`}</Text> : null}
          <QRCodeView testID="addphone-qr" value={inv.linkCode} size={qrSize} />
          <Text testID="addphone-expires" style={{ fontSize: 15, color: C.sub, textAlign: 'center' }}>{`Works for ${(inv.uses || ADD_PHONE.uses) === 1 ? 'one device' : `up to ${inv.uses || ADD_PHONE.uses} devices`} until ${fijiClockText(inv.expires)}`}</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
            <Btn testID="addphone-share" title="Share code" icon="💬" size="md" variant="info" onPress={() => Share.share({ message: inviteMessage(inv, user.name).replace('It works once and expires in 48 hours.', `It works for up to ${inv.uses || ADD_PHONE.uses} phones for 1 hour.`) })} />
            <Btn testID="addphone-cancel" title="Cancel this code" size="md" variant="secondary" onPress={cancel} />
          </View>
        </View>
      ) : null}
      {!inv && !busy && !error && !roleCloud ? <Btn testID="addphone-new" title="Make a new QR code" icon="➕" onPress={make} /> : null}
      {inv && roleCloud ? <Btn testID="addphone-another" title="Another device (choose its role)" icon="➕" size="md" variant="secondary" onPress={() => setInv(null)} /> : null}
      <Btn testID="addphone-devices" title="All devices" size="sm" variant="ghost" onPress={() => nav.push('Devices', {})} />
    </Screen>
  );
}

export const ADMIN_PHONE_TEXT = 'Only for a phone that stays with you or an admin. It gets the owner and admin PINs, so you can log in on it. A phone the shop staff use should be allowed as a staff phone.';

// The "Allow …?" pop-up on the owner's / an admin's device when a new phone waits (from the last sync). Asked once
// per phone; "Later" leaves it in Add a phone and Devices.
export function ApprovalPrompt() {
  const { user } = useApp();
  const ui = useUI();
  const asking = useRef(false);
  // looked at again after every sync (the waiting list comes with the owner's / an admin's sync)
  const [, setTick] = useState(0);
  useEffect(() => { try { return require('../../../services/syncBus.js').onSyncState((st) => { if (!st.running) setTick((n) => n + 1); }); } catch (e) { return undefined; } }, []);
  const owner = user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
  const w = owner ? waitingDevices() : [];
  const key = w.map((d) => d.id).join(',');
  useEffect(() => {
    if (!owner || !w.length || asking.current) return;
    let asked = [];
    try { asked = JSON.parse(getSetting('devices_asked', '[]') || '[]') || []; } catch (e) { asked = []; }
    const d = w.find((x) => !asked.includes(x.id));
    if (!d) return;
    asking.current = true;
    ui.choose({ title: `Allow ${d.name}?`, message: 'A new phone wants to join Easy Buys. Allow it only if you know it. A shop or staff phone gets the staff logins; your own phone (owner / admin) also gets the owner and admin logins.', options: [
      { text: 'Later', value: 'later', testID: 'approve-later' },
      { text: 'Block', value: 'blocked', testID: 'approve-block' },
      { text: 'Allow – my own phone (owner / admin)', value: 'admin', testID: 'approve-allow-admin' },
      { text: 'Allow – staff phone', value: 'active', variant: 'success', testID: 'approve-allow' },
    ] }).then(async (v0) => {
      const admin = v0 === 'admin';
      const v = admin ? 'active' : v0;
      // noted once answered (an app closed with the question open asks again)
      try { const was = JSON.parse(getSetting('devices_asked', '[]') || '[]') || []; setSetting('devices_asked', JSON.stringify(was.concat([d.id]).slice(-50))); } catch (e) { /* asked again */ }
      if (v === 'active' || v === 'blocked') {
        try {
          await cloudCall({ kind: 'device_status', id: d.id, status: v, admin: admin || undefined }, 45000);
          setSetting('devices_waiting', JSON.stringify(waitingDevices().filter((x) => x.id !== d.id)));
          ui.toast(v === 'active' ? `${d.name} allowed${admin ? ' as your phone' : ''}` : `${d.name} blocked`);
        } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
      }
    }).finally(() => { asking.current = false; });
  }, [key, owner]);
  return null;
}
