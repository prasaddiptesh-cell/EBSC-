// Admin › Devices › one device: how it is (last synced, app version, waiting items, last health check, backup, login)
// and what the owner can do (pause, block, allow, remove, rename, shop, who may log in, end date, ask it to sync / send
// its problem log / sign everyone out, wipe). The cloud enforces it; the device is told on its next contact.
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, Row, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { DateField } from '../../../ui/dateField.js';
import { actsAsOwner, ROLES, ROLE_LABEL } from '../../../services/access.js';
import { deviceId, dateStr, addDays, audit, getSetting } from '../../../services/core.js';
import { adminPinOk } from '../../../services/health.js';
import { db } from '../../../db/connection.js';
import { cloudCall } from '../../../platform/cloud.js';
import { ago, DEVICE_STATUS_LABEL } from '../service.js';

export function lightFor(d) {
  const t = d && d.last_seen ? new Date(String(d.last_seen)).getTime() : 0;
  const mins = t ? (Date.now() - t) / 60000 : Infinity;
  if (d && ['blocked', 'removed'].includes(d.status)) return { color: C.danger, text: DEVICE_STATUS_LABEL[d.status] || d.status };
  if (d && d.until && d.until > new Date().toISOString()) return { color: C.warn, text: 'Paused' };
  if (mins < 5) return { color: C.success, text: 'Online' };
  if (mins < 24 * 60) return { color: C.warn, text: `Last synced ${ago(d.last_seen)}` };
  return { color: C.danger, text: `Not synced for ${ago(d.last_seen).replace(' ago', '')}` };
}

export default function DeviceDetailScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const owner = actsAsOwner(user);
  const [d, setD] = useState(params.device || null);
  const [busy, setBusy] = useState('');
  const [untilDate, setUntilDate] = useState(addDays(dateStr(), 1));
  const [untilTime, setUntilTime] = useState('08:00');
  const [name, setName] = useState((params.device && params.device.name) || '');
  const [endDate, setEndDate] = useState((params.device && params.device.endDate) || '');
  const [roles, setRoles] = useState((params.device && params.device.roles) || []);
  const [pin, setPin] = useState('');
  const [log, setLog] = useState(null);
  const shops = (() => { try { return db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort'); } catch (e) { return []; } })();
  const me = d && String(d.id) === deviceId();

  const refresh = async () => {
    try { const r = await cloudCall({ kind: 'devices' }, 30000); const x = (r.devices || []).find((y) => String(y.id) === String(params.id || (d && d.id))); if (x) setD(x); } catch (e) { /* offline: keep what we have */ }
  };
  useEffect(() => { refresh(); }, []);
  if (!d) return <Screen title="Device"><Banner tone="warn" message="Device not found. Go back and refresh the list." /></Screen>;

  const act = async (action, extra = {}, { confirm, done } = {}) => {
    if (confirm) { const ok = await ui.confirm(confirm); if (!ok) return; }
    setBusy('Telling the cloud…');
    try {
      const r = await cloudCall({ kind: 'device_control', id: d.id, action, by: user.name, ...extra }, 30000);
      const x = (r.devices || []).find((y) => String(y.id) === String(d.id));
      if (x) setD(x);
      audit({ user, action: `Device ${d.name}: ${action}`, table: 'device', recordUid: String(d.id), after: extra });
      ui.toast(done || 'Done – the device is told on its next contact');
    } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
    setBusy('');
  };
  const wipe = async () => {
    if (!adminPinOk(pin)) { ui.error({ isAppError: true, message: 'Enter the owner or admin PIN to wipe a device.' }); return; }
    setPin('');
    await act('wipe', {}, { confirm: { title: `Wipe ${d.name}?`, message: 'On its next contact the device deletes all Easy Buys data and is unlinked. Everything stays safe in the cloud. This cannot be undone on the device.', confirmText: 'Wipe it', tone: 'danger' }, done: 'Wipe asked – it happens when the device next connects' });
  };
  const getLog = async () => {
    try { const r = await cloudCall({ kind: 'problem_log_get', id: d.id }, 30000); setLog(r); } catch (e) { ui.error({ isAppError: true, message: e.message || String(e) }); }
  };
  const light = lightFor(d);
  const st = d.stat || {};
  const oldScript = Number(getSetting('cloud_script_version', '0')) < 6;
  return (
    <Screen title={d.name} subtitle={`${d.kind === 'phone' ? 'Phone' : 'Tablet'}${me ? ' · this device' : ''}`}>
      {oldScript ? <Banner tone="warn" title="Paste the new cloud script first" message="Pausing, removing, wiping and asking a device need the v3.7 cloud script (CLOUD-SETUP.md, the usual 3 steps)." /> : null}
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <Badge text={light.text} color={light.color} />
          {d.endDate ? <Badge text={`Access ends ${d.endDate}`} color={C.warn} /> : null}
          {(d.roles || []).length ? <Badge text={`Only: ${d.roles.map((r) => ROLE_LABEL[r] || r).join(', ')}`} color={C.sub} /> : null}
          {d.wipe === 'pending' ? <Badge text="Wipe waiting" color={C.danger} /> : null}
        </View>
        <Row label="Last synced" value={ago(d.last_seen)} />
        <Row label="App version" value={String(d.app || '?').split(' ')[0]} />
        <Row label="Waiting to send" value={st.pending === undefined || st.pending === null ? '–' : `${st.pending} item(s)`} />
        <Row label="Last health check" value={st.health || '–'} />
        <Row label="Last safety copy" value={st.backup ? String(st.backup).slice(0, 16) : '–'} />
        <Row label="Last login" value={st.login ? `${st.login.name} · ${String(st.login.at || '').slice(0, 16)}` : '–'} />
        <Row label="Linked" value={`${String(d.first_seen || '').slice(0, 10)}${d.invited_by ? ` · invited by ${String(d.invited_by).split(' @ ')[0]}` : ''}`} />
        {d.waitingCmds ? <Hint>{d.waitingCmds} request(s) waiting for its next contact.</Hint> : null}
      </Card>
      {(d.attempts || []).length ? <Banner tone="warn" title="Tried to connect while not allowed" message={d.attempts.slice(0, 3).map((a) => `${String(a.at).slice(0, 16).replace('T', ' ')} (${a.why})`).join(' · ')} /> : null}
      {busy ? <Banner tone="info" message={busy} /> : null}

      <Section title="Ask the device">
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="dv-sync" title="Sync now" icon="⟳" size="md" variant="secondary" onPress={() => act('sync')} />
          <Btn testID="dv-log" title="Send its problem log" icon="🧯" size="md" variant="secondary" onPress={() => act('log')} />
          <Btn testID="dv-signout" title="Sign everyone out" icon="🚪" size="md" variant="secondary" onPress={() => act('signout')} />
          {d.lastLog ? <Btn testID="dv-showlog" title="Show the log" icon="📄" size="md" variant="secondary" onPress={getLog} /> : null}
        </View>
        {log ? <Card><Text style={{ fontSize: 13, color: C.text }}>{log.at ? `Sent ${String(log.at).slice(0, 16)}\n` : ''}{String(log.text || 'Empty').slice(0, 4000)}</Text></Card> : null}
      </Section>

      {!me ? (
        <Section title="Access">
          {d.status === 'blocked' || d.status === 'waiting' || (d.until && d.until > new Date().toISOString()) ? (
            <Btn testID="dv-allow" title={d.status === 'waiting' ? 'Allow this device' : 'Allow again'} icon="✅" variant="success" onPress={() => act('allow', {}, { done: 'Allowed' })} />
          ) : null}
          <H>Pause (for a while)</H>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 220, flexGrow: 1 }}><DateField testID="dv-until" label="Until" value={untilDate} onChange={setUntilDate} quick={false} /></View>
            <View style={{ flexBasis: 120 }}><Field testID="dv-until-time" label="Time" value={untilTime} onChangeText={setUntilTime} placeholder="08:00" /></View>
          </View>
          <Btn testID="dv-suspend" title="Pause access" icon="⏸️" variant="warn" onPress={() => act('suspend', { until: `${untilDate}T${/^\d{1,2}:\d{2}$/.test(untilTime) ? untilTime.padStart(5, '0') : '08:00'}` }, { done: 'Paused' })} />
          {d.status !== 'blocked' ? <Btn testID="dv-block" title="Block (until allowed again)" icon="⛔" variant="danger" onPress={() => act('block', {}, { confirm: { title: `Block ${d.name}?`, message: 'It is locked as soon as it connects. Its data stays on it.', confirmText: 'Block', tone: 'danger' }, done: 'Blocked' })} /> : null}
          <DateField testID="dv-end" label="Access ends after (optional – e.g. an accountant's phone)" value={endDate} onChange={setEndDate} optional quick={false} farDays={800} />
          <Btn testID="dv-end-save" title={endDate ? 'Set the end date' : 'No end date'} size="md" variant="secondary" onPress={() => act('end', { endDate: endDate || '' })} />
        </Section>
      ) : null}

      <Section title="This device's settings">
        <Field testID="dv-name" label="Name" value={name} onChangeText={setName} />
        <Btn testID="dv-rename" title="Rename" size="md" variant="secondary" onPress={() => act('rename', { name })} />
        <Chips value={d.shop || ''} onChange={(v) => act('shop', { shop: v })} testIDPrefix="dv-shop" options={[{ value: '', label: 'No shop' }].concat(shops.map((s) => ({ value: s.code, label: s.name })))} />
        <Text style={{ fontSize: 16, fontWeight: '700', color: C.text, marginTop: 8 }}>Who may log in on it (none ticked = everyone)</Text>
        <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
          {ROLES.filter((r) => r !== 'owner').map((r) => {
            const on = roles.includes(r);
            return <Btn key={r} testID={`dv-role-${r}`} title={`${on ? '☑' : '☐'} ${ROLE_LABEL[r] || r}`} size="sm" variant={on ? 'info' : 'secondary'} onPress={() => setRoles(on ? roles.filter((x) => x !== r) : roles.concat([r]))} />;
          })}
        </View>
        <Btn testID="dv-roles-save" title="Save who may log in" size="md" variant="secondary" onPress={() => act('roles', { roles })} />
        <Hint>The owner can always log in.</Hint>
      </Section>

      {!me && owner ? (
        <Section title="Remove or wipe">
          <Btn testID="dv-remove" title="Remove this device" icon="🗑️" variant="danger" onPress={() => act('remove', {}, { confirm: { title: `Remove ${d.name}?`, message: `It must be linked again with a new invite to be used.${(d.stat && d.stat.pending) ? ` It still had ${d.stat.pending} item(s) not sent – they stay on the device.` : ''}`, confirmText: 'Remove', tone: 'danger' }, done: 'Removed' })} />
          <Field testID="dv-pin" label="Owner or admin PIN (to wipe)" value={pin} onChangeText={setPin} secure keyboardType="number-pad" />
          <Btn testID="dv-wipe" title="Wipe the Easy Buys data on it" icon="🧨" variant="danger" onPress={wipe} />
        </Section>
      ) : null}

      {(d.hist || []).length ? (
        <Section title="History">
          {d.hist.map((h, i) => <Text key={i} style={{ fontSize: 14, color: C.sub }}>{String(h.at).slice(0, 16).replace('T', ' ')} · {h.text}{h.by ? ` · ${String(h.by).split(' @ ')[0]}` : ''}</Text>)}
        </Section>
      ) : null}
    </Screen>
  );
}
