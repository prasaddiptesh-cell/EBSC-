// Admin › Devices: add a tablet or phone (QR, email, or a code by message), see every linked device,
// block a lost one, and (owner) choose whether new devices need approval.
// Nothing here needs the Google cloud to be opened: it was set up once.
import React, { useEffect, useState } from 'react';
import { View, Share } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, Row, Section, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { QRCodeView } from '../../../ui/qr.js';
import { actsAsOwner } from '../../../services/access.js';
import { deviceId, deviceName, isEmail } from '../../../services/core.js';
import { cloudCall } from '../../../platform/cloud.js';
import { linkState, inviteMessage, unlinkThisDevice, sampleLoginsActive, DEVICE_STATUS_LABEL, ago, cacheDevices } from '../service.js';
import { lightFor } from './DeviceDetailScreen.js';

const STATUS_COLOR = { active: C.success, blocked: C.danger, waiting: C.warn };

export default function DevicesScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const { isPhone, width } = useLayout();
  const owner = actsAsOwner(user);
  const link = linkState();
  const [devices, setDevices] = useState(null);
  const [approval, setApproval] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [mode, setMode] = useState('qr');
  const [email, setEmail] = useState('');
  const [invite, setInvite] = useState(null);
  const [busy, setBusy] = useState('');
  const samples = sampleLoginsActive();

  const load = async () => {
    if (!link.linked) return;
    setLoadError('');
    try {
      const r = await cloudCall({ kind: 'devices' }, 30000);
      setDevices(r.devices || []);
      cacheDevices(r.devices || []);
      const s = await cloudCall({ kind: 'cloud_settings' }, 30000);
      setApproval(!!s.requireApproval);
    } catch (e) {
      setLoadError(e.message || String(e));
    }
  };
  useEffect(() => { load(); }, []);

  const makeInvite = async () => {
    if (mode === 'email' && !isEmail(email)) { ui.error({ isAppError: true, message: 'Enter the email address of the person who will use the new device.' }); return; }
    setBusy('Making the invite…');
    try {
      const r = await cloudCall({ kind: 'invite_create', url: link.url, by: user.name, email: mode === 'email' ? email.trim() : '' }, 45000);
      setInvite({ ...r, mode, email: mode === 'email' ? email.trim() : '' });
      if (mode === 'share') await Share.share({ message: inviteMessage(r, user.name) });
    } catch (e) {
      ui.error({ isAppError: true, message: e.message || String(e) });
    } finally {
      setBusy('');
    }
  };

  const setStatus = async (d, status) => {
    if (status === 'blocked') {
      const ok = await ui.confirm({ title: `Block ${d.name}?`, message: 'It stops syncing straight away. Its data stays on it, but nothing new comes or goes. You can unblock it later.', confirmText: 'Block', tone: 'danger' });
      if (!ok) return;
    }
    try {
      const r = await cloudCall({ kind: 'device_status', id: d.id, status }, 30000);
      setDevices(r.devices || []);
      ui.toast(status === 'blocked' ? 'Blocked' : 'Allowed');
    } catch (e) {
      ui.error({ isAppError: true, message: e.message || String(e) });
    }
  };

  const toggleApproval = async (v) => {
    try {
      const r = await cloudCall({ kind: 'cloud_settings', requireApproval: v }, 30000);
      setApproval(!!r.requireApproval);
      ui.toast(r.requireApproval ? 'New devices now need your approval' : 'New devices link straight away');
    } catch (e) {
      ui.error({ isAppError: true, message: e.message || String(e) });
    }
  };

  const unlink = async () => {
    const ok = await ui.confirm({ title: 'Unlink this device?', message: 'It stops syncing. Everything already on it stays. Use an invite to link it again.', confirmText: 'Unlink', tone: 'danger' });
    if (!ok) return;
    unlinkThisDevice(user);
    ui.toast('Unlinked');
    nav.pop();
  };

  if (!link.linked) {
    return (
      <Screen title="Devices" subtitle="Tablets and phones that sync together">
        <Banner tone="info" title="This device is not linked yet"
          message="The first tablet is linked once with the cloud web address and key (Admin › Online & email). Every other device is then added from here with an invite." />
        <Btn title="Open Online & email" icon="☁️" onPress={() => nav.push('Settings')} />
      </Screen>
    );
  }

  const waiting = (devices || []).filter((d) => d.status === 'waiting');
  const qrSize = Math.min(isPhone ? width - 80 : 340, 340);
  return (
    <Screen title="Devices" subtitle="Tablets and phones that sync together">
      {samples.length ? (
        <Banner testID="samples-on" tone="warn" title="Sample logins are still on this device"
          message={`${samples.map((s) => `${s.name} (PIN ${s.pin})`).join(', ')}. Make your own Owner login in Staff, then switch these off there.`} />
      ) : null}
      <Card>
        <H>This device</H>
        <Row label="Name" value={deviceName()} />
        <Row label="Linked" value={link.method === 'invite' ? `with an invite${link.linkedAt ? ` on ${link.linkedAt.slice(0, 10)}` : ''}` : 'with the cloud key (first device)'} />
        {link.waiting ? <Banner tone="warn" message="Waiting for the owner to approve this device." /> : null}
      </Card>

      <Card>
        <H>Add a device</H>
        <Text style={{ fontSize: 16, color: C.sub, marginBottom: 8 }}>Install the Easy Buys app on the new tablet or phone, then choose how to send the invite. Each invite works once and expires in 48 hours.</Text>
        <Chips value={mode} onChange={(v) => { setMode(v); setInvite(null); }} testIDPrefix="invite-mode"
          options={[{ value: 'qr', label: '📷 QR code' }, { value: 'email', label: '✉️ Email' }, { value: 'share', label: '💬 WhatsApp / message' }]} />
        {mode === 'email' ? <Field testID="invite-email" label="Their email address" value={email} onChangeText={setEmail} keyboardType="email-address" placeholder="e.g. brother@gmail.com" /> : null}
        {busy ? <Banner tone="info" message={busy} /> : (
          <Btn testID="invite-make" title={mode === 'qr' ? 'Show the QR code' : mode === 'email' ? 'Send the email invite' : 'Make the invite and share it'} icon="➕" variant="success" style={{ marginTop: 10 }} onPress={makeInvite} />
        )}
        {invite ? (
          <View testID="invite-ready" style={{ gap: 10, marginTop: 12, alignItems: 'center' }}>
            {invite.mode === 'qr' ? (
              <>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, textAlign: 'center' }}>On the new device: open Easy Buys › Link to Easy Buys › Scan the QR code</Text>
                <QRCodeView testID="invite-qr" value={invite.linkCode} size={qrSize} />
              </>
            ) : invite.mode === 'email' ? (
              <Banner tone="success" title={`Invite sent to ${invite.email}`} message="Open the email on the new device and tap the link. The email also has the code to paste if the link does not open the app." />
            ) : (
              <Banner tone="success" title="Invite made" message="Send the message to the person with the new device." />
            )}
            <Text style={{ fontSize: 15, color: C.sub }}>Expires {String(invite.expires).slice(0, 16).replace('T', ' ')} · works once</Text>
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
              <Btn testID="invite-share" title="Share the code" icon="💬" size="md" variant="secondary" onPress={() => Share.share({ message: inviteMessage(invite, user.name) })} />
              <Btn title="Done" size="md" variant="secondary" onPress={() => { setInvite(null); load(); }} />
            </View>
          </View>
        ) : null}
      </Card>

      <Section title="Linked devices" right={<Btn title="Refresh" size="sm" variant="secondary" onPress={load} />}>
        {loadError ? <Banner tone="warn" title="Could not get the list" message={`${loadError}. The list needs internet; everything else works offline.`} /> : null}
        {!devices && !loadError ? <Text style={{ fontSize: 16, color: C.sub }}>Loading…</Text> : null}
        {waiting.length ? <Banner tone="warn" title={`${waiting.length} new device(s) waiting for approval`} message="Tap Allow if you know the device." /> : null}
        {(devices || []).map((d) => {
          const me = String(d.id) === deviceId();
          return (
            <View key={d.id} testID={`device-${d.id}`} style={{ borderBottomWidth: 1, borderBottomColor: '#F0EBE3', paddingVertical: 10, gap: 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{d.kind === 'phone' ? '📱' : '📟'} {d.name}{me ? ' (this device)' : ''}</Text>
                <Badge text={DEVICE_STATUS_LABEL[d.status] || d.status} color={STATUS_COLOR[d.status] || C.sub} />
                <View style={{ flex: 1 }} />
                {!me && d.status !== 'blocked' && d.status !== 'waiting' ? <Btn testID={`block-${d.id}`} title="Block" size="sm" variant="ghost" onPress={() => setStatus(d, 'blocked')} /> : null}
                {!me && (d.status === 'blocked' || d.status === 'waiting') ? <Btn testID={`allow-${d.id}`} title={d.status === 'waiting' ? 'Allow' : 'Unblock'} size="sm" variant="success" onPress={() => setStatus(d, 'active')} /> : null}
              </View>
              <Text style={{ fontSize: 14, color: lightFor(d).color }}>● {lightFor(d).text} · app v{String(d.app || '?').split(' ')[0]}{d.first_seen ? ` · linked ${String(d.first_seen).slice(0, 10)}` : ''}</Text>
              <Btn testID={`device-open-${d.id}`} title="Status & actions" size="sm" variant="secondary" onPress={() => nav.push('DeviceDetail', { id: d.id, device: d })} />
            </View>
          );
        })}
      </Section>

      {owner ? (
        <Card>
          <H>New devices need my approval</H>
          <Text style={{ fontSize: 15, color: C.sub, marginBottom: 8 }}>Off: a device with a valid invite links straight away. On: it waits here until you tap Allow.</Text>
          {approval === null ? <Text style={{ fontSize: 15, color: C.sub }}>Needs internet to change.</Text> : (
            <Chips value={approval} onChange={toggleApproval} testIDPrefix="approval"
              options={[{ value: false, label: 'Off' }, { value: true, label: 'On' }]} />
          )}
        </Card>
      ) : null}
      {owner ? <Btn testID="unlink" title="Unlink this device" variant="ghost" onPress={unlink} /> : null}
    </Screen>
  );
}
