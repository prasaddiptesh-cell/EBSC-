// 1.0.0 build 10 (review, 3 Nov): a phone that is linked but has no logins yet (its first sync was cut short – a slow
// line, the app closed) used to land on the "brand-new business" form with no way back. It now shows "Getting the
// business…" and keeps syncing by itself (every 20 seconds, with the count on screen) until the staff logins are in,
// with a "Try again now" button. The login screen comes by itself as soon as the logins have arrived.
// A device linked with the cloud key (the very first tablet of a brand-new business, where the cloud may really have
// nobody yet) may, after a complete sync that brought nobody, make the owner login instead.
import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Btn, Banner } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { getSetting } from '../../../services/core.js';
import { onSyncState } from '../../../services/syncBus.js';
import { firstSyncText, linkState } from '../service.js';

export const GETTING_EVERY_MS = 20000;
const noUsers = () => { try { return require('../../../db/connection.js').db().get('SELECT COUNT(*) AS n FROM users WHERE active = 1').n === 0; } catch (e) { return false; } };

export default function GettingBusinessScreen({ onNewBusiness, onReady, every = GETTING_EVERY_MS }) {
  const [step, setStep] = useState('Getting the business…');
  const [last, setLast] = useState(null); // { error, received, at }
  const [running, setRunning] = useState(false);
  const alive = useRef(true);
  const busy = useRef(false);
  const timer = useRef(null);
  useEffect(() => () => { alive.current = false; if (timer.current) clearTimeout(timer.current); }, []);
  useEffect(() => onSyncState((st) => { if (alive.current && st.running) setStep(firstSyncText(st.progress)); }), []);

  const round = async () => {
    if (busy.current || !alive.current) return;
    busy.current = true;
    if (timer.current) { clearTimeout(timer.current); timer.current = null; }
    setRunning(true);
    let s = {};
    try { s = (await require('../../../platform/cloud.js').syncNow({ force: true })) || {}; } catch (e) { s = { error: e.message || String(e) }; }
    busy.current = false;
    if (!alive.current) return;
    setRunning(false);
    setStep('Getting the business…');
    setLast({ error: s.skipped ? '' : s.error || '', received: s.received || 0, done: !s.skipped && !s.error });
    if (noUsers()) timer.current = setTimeout(round, getSetting('link_waiting', '') === '1' ? Math.min(every, 8000) : every); // 1.0.0 build 12: waiting for the owner – checked every 8 s // the login screen takes over once the logins are in
    else if (onReady) onReady();
  };
  useEffect(() => { round(); }, []);

  const waiting = getSetting('link_waiting', '') === '1';
  const byKey = linkState().method === 'key';
  return (
    <View testID="getting-business" style={{ flex: 1, padding: 20, gap: 14, backgroundColor: C.bg, justifyContent: 'center', maxWidth: 560, width: '100%', alignSelf: 'center' }}>
      <Text style={{ fontSize: 26, fontWeight: '900', color: C.text, textAlign: 'center' }}>{waiting ? 'Waiting for the owner' : 'Getting the business…'}</Text>
      {waiting
        ? <Banner testID="getting-waiting" tone="warn" title="The owner must allow this phone" message="The owner's phone asks them to allow it. This phone checks by itself – keep the app open." />
        : <Banner testID="getting-progress" tone="info" title={running ? step : 'Not everything has come in yet'} message="This phone is linked to Easy Buys. The staff logins come with the business – keep the app open, it carries on by itself." />}
      {last && last.error ? <Text testID="getting-error" style={{ fontSize: 16, color: C.sub, textAlign: 'center' }}>{`Last try: ${last.error}`}</Text> : null}
      {last && !running ? <Text testID="getting-next" style={{ fontSize: 15, color: C.sub, textAlign: 'center' }}>{`Trying again in ${Math.round(every / 1000)} seconds.`}</Text> : null}
      <Btn testID="getting-retry" title={running ? 'Working…' : 'Try again now'} icon="🔄" variant="primary" disabled={running} onPress={round} />
      {byKey && onNewBusiness && last && last.done && !waiting ? (
        <Btn testID="getting-new" title="Nobody in the cloud yet – make the owner login" size="sm" variant="ghost" onPress={onNewBusiness} />
      ) : null}
    </View>
  );
}
