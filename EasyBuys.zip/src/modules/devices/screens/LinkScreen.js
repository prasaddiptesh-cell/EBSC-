// "Link to Easy Buys" on a new tablet or phone (before anyone logs in).
// 1.0.0 build 10 (owner, 2 Nov: "the linking of devices is a mess"): ONE thing first – a big "Scan to join Easy Buys"
// (the camera opens), then only the phone's name (a suggestion is filled in). A busy cloud is tried again by itself
// ("Linking… the cloud is busy, trying again"). After linking the phone gets the whole business with a visible count
// ("Getting the business… 1,200 of 2,850") and only then goes to the login screen with the real people. If the owner
// must allow new phones first, it says so plainly and keeps checking by itself.
// A tapped link (WhatsApp / email) opens this screen with the code already in: only the name is asked.
import React, { useEffect, useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { getSetting } from '../../../services/core.js';
import { joinWithCode, parseLinkCode, linkState, sampleLoginsActive, suggestDeviceName, firstSyncText } from '../service.js';
import { syncNow } from '../../../platform/cloud.js';
import { onSyncState } from '../../../services/syncBus.js';
import QRScanner from '../QRScanner.js';
import GettingBusinessScreen from './GettingBusinessScreen.js';

const noUsersYet = () => { try { return require('../../../db/connection.js').db().get('SELECT COUNT(*) AS n FROM users WHERE active = 1').n === 0; } catch (e) { return false; } };

const num = (n) => Number(n || 0).toLocaleString('en-US');

export default function LinkScreen({ initialCode = '', autoScan = false, onDone, onBack }) {
  const { isPhone, width } = useLayout();
  const kind = getSetting('device_kind', '') || (isPhone ? 'phone' : 'tablet');
  const [name, setName] = useState(() => getSetting('device_name', '') || suggestDeviceName(kind));
  const [code, setCode] = useState(() => { try { return initialCode ? parseLinkCode(initialCode).code : ''; } catch (e) { return initialCode; } });
  const [typing, setTyping] = useState(false);
  const [scan, setScan] = useState(autoScan && !initialCode ? 1 : 0); // "Scan to join" on the first screen opens the camera at once
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);

  let preview = null;
  try { preview = code.trim() ? parseLinkCode(code) : null; } catch (e) { preview = null; }

  // the first full sync, with the count on screen
  const firstSync = async () => {
    setBusy('Getting the business…');
    const off = onSyncState((st) => { if (alive.current && st.running) setBusy(firstSyncText(st.progress)); });
    let s = {};
    try {
      s = await syncNow({ force: true });
      // a page cut short (busy cloud): more rounds straight away, up to 5
      for (let i = 0; i < 5 && s && s.error && /busy/i.test(s.error); i++) s = await syncNow({ force: true });
    } finally { off(); }
    return s || {};
  };

  const link = async (text = code) => {
    setError('');
    if (!String(name || '').trim()) { setError('Give this phone a name first.'); return; }
    setBusy('Linking…');
    try {
      const r = await joinWithCode(text, { name, kind, onStep: (t) => { if (alive.current) setBusy(t); } });
      if (!r.approved) { setResult({ approved: false, received: 0, error: '' }); return; }
      const s = await firstSync();
      setResult({ approved: true, received: s.received || 0, error: s.error || '' });
    } catch (e) {
      setError(e.message || String(e));
    } finally {
      if (alive.current) setBusy('');
    }
  };

  // Waiting for the owner: check every 15 seconds; once allowed, get the business.
  useEffect(() => {
    if (!result || result.approved) return undefined;
    let stop = false;
    const tick = async () => {
      if (stop) return;
      try { await syncNow({ force: true }); } catch (e) { /* next try */ }
      if (stop || !alive.current) return;
      if (getSetting('link_waiting', '') !== '1') {
        const s = await firstSync();
        if (alive.current) { setBusy(''); setResult({ approved: true, received: s.received || 0, error: s.error || '' }); }
        return;
      }
      setTimeout(tick, 15000);
    };
    const h = setTimeout(tick, 15000);
    return () => { stop = true; clearTimeout(h); };
  }, [result && result.approved]);

  // review (3 Nov): linked, but the first sync was cut short before any login came: keep getting the business here
  // (never the brand-new-business form); the "linked" screen follows once the logins are in.
  if (result && result.approved && !busy && noUsersYet()) return <GettingBusinessScreen onReady={() => { if (alive.current) setResult({ ...result, error: '' }); }} />;
  if (result) {
    const samples = sampleLoginsActive();
    return (
      <Screen title="Linked to Easy Buys" hideUser onBack={onDone}>
        {result.approved ? (
          <Banner testID="link-ok" tone="success" title="This device is linked"
            message={`It now syncs with every other Easy Buys device. ${num(result.received)} records received.`} />
        ) : (
          <Banner testID="link-waiting" tone="warn" title="Waiting for the owner to allow this phone"
            message="The owner's phone asks them to allow it. This phone checks by itself every 15 seconds – keep the app open." />
        )}
        {busy ? <Banner testID="link-progress" tone="info" title={busy} message="Keep the app open." /> : null}
        {result.error && result.approved ? <Banner tone="warn" message={`Not everything has come in yet (${result.error}). The rest comes by itself in the next minutes.`} /> : null}
        {result.approved ? (samples.length ? (
          <Banner tone="info" title="Sample logins still on"
            message="They switch off by themselves once your staff have arrived from the other devices." />
        ) : <Text style={{ fontSize: 17, color: C.text }}>Log in with your own PIN.</Text>) : null}
        {result.approved ? <Btn testID="link-finish" title="Go to the login screen" icon="🔓" onPress={onDone} /> : null}
      </Screen>
    );
  }

  const already = linkState().linked;
  // 1. no invite yet: scan (or type a code)
  if (!preview) {
    return (
      <Screen title="Join Easy Buys" subtitle="Link this phone to the shop's other phones and tablets" hideUser onBack={onBack}>
        {already ? <Banner tone="info" message="This device is already linked. Linking again replaces the old link." /> : null}
        {scan ? (
          <View style={{ gap: 10, alignItems: 'center' }}>
            <QRScanner key={scan} size={Math.min(340, width - 60)} onScan={(t) => { setScan(0); try { const p = parseLinkCode(t); setCode(p.code); setError(''); } catch (e) { setError(e.message); } }} />
            <Btn title="Stop scanning" variant="secondary" size="md" onPress={() => setScan(0)} />
          </View>
        ) : (
          <>
            <Btn testID="link-scan" title="Scan to join Easy Buys" icon="📷" variant="success" onPress={() => { setError(''); setScan((n) => n + 1); }} disabled={!!busy} />
            <Text style={{ fontSize: 16, color: C.sub, textAlign: 'center' }}>The owner shows the QR code: Home › Add a phone.</Text>
          </>
        )}
        {error ? <Banner testID="link-error" tone="danger" title="That code did not work" message={error} /> : null}
        {typing ? (
          <Card>
            <Field testID="link-code" label="The code (starts with EB1-)" value={code} onChangeText={(v) => { setCode(v); setError(''); }} multiline />
            {code.trim() ? <Text style={{ fontSize: 15, color: C.danger }}>That does not look like a full Easy Buys code yet.</Text> : null}
          </Card>
        ) : <Btn testID="link-type" title="Type or paste a code instead" size="sm" variant="ghost" onPress={() => setTyping(true)} />}
      </Screen>
    );
  }
  // 2. the invite is in: only the name
  return (
    <Screen title="Join Easy Buys" subtitle="Last step: this phone's name" hideUser onBack={busy ? undefined : () => { setCode(''); setTyping(false); }}>
      <Banner testID="link-found" tone="success" title="Invite found" message="Give this phone a name the owner will know, then tap Link." />
      <Field testID="link-name" label="This phone's name" value={name} onChangeText={setName} placeholder='e.g. "Ravi phone", "Bakers tablet"' />
      {error ? <Banner testID="link-error" tone="danger" title="Could not link" message={error} /> : null}
      {busy ? <Banner testID="link-progress" tone="info" title={busy} message="Keep the app open. This needs internet." /> : null}
      <Btn testID="link-go" title="Link this phone" icon="🔗" variant="success" onPress={() => link()} disabled={!!busy || !String(name || '').trim()} />
      {typing || initialCode ? <Field testID="link-code" label="The code" value={code} onChangeText={(v) => { setCode(v); setError(''); }} multiline /> : null}
    </Screen>
  );
}
