// "Link to Easy Buys" on a new tablet or phone (before anyone logs in).
// Scan the QR code shown on a linked device, tap the email/message link, or paste the code.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Label, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { getSetting } from '../../../services/core.js';
import { joinWithCode, parseLinkCode, linkState, sampleLoginsActive } from '../service.js';
import { syncNow } from '../../../platform/cloud.js';
import QRScanner from '../QRScanner.js';

export default function LinkScreen({ initialCode = '', onDone, onBack }) {
  const { isPhone, width } = useLayout();
  const [name, setName] = useState(getSetting('device_name', ''));
  const [kind, setKind] = useState(getSetting('device_kind', '') || (isPhone ? 'phone' : 'tablet'));
  const [code, setCode] = useState(() => { try { return initialCode ? parseLinkCode(initialCode).code : ''; } catch (e) { return initialCode; } });
  const [scan, setScan] = useState(0);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  let preview = null;
  try { preview = code.trim() ? parseLinkCode(code) : null; } catch (e) { preview = null; }

  const link = async (text = code) => {
    setError('');
    setBusy('Linking…');
    try {
      const r = await joinWithCode(text, { name, kind });
      setBusy('Getting staff and settings…');
      const s = await syncNow({ force: true });
      setResult({ approved: r.approved, received: s.received || 0, error: s.error || '' });
    } catch (e) {
      setError(e.message || String(e));
    } finally {
      setBusy('');
    }
  };

  if (result) {
    const samples = sampleLoginsActive();
    return (
      <Screen title="Linked to Easy Buys" hideUser onBack={onDone}>
        {result.approved ? (
          <Banner testID="link-ok" tone="success" title="This device is linked"
            message={`It now syncs with every other Easy Buys device. ${result.received} records received so far; the rest keep coming in the background.`} />
        ) : (
          <Banner testID="link-waiting" tone="warn" title="Waiting for the owner to approve"
            message="The owner approves new devices in Admin › Devices. Syncing starts by itself once approved." />
        )}
        {result.error && result.approved ? <Banner tone="warn" message={`First sync not finished: ${result.error}. It will try again every minute.`} /> : null}
        {samples.length ? (
          <Banner tone="info" title="Sample logins still on"
            message="They switch off by themselves once your staff have arrived from the other devices." />
        ) : <Text style={{ fontSize: 17, color: C.text }}>Log in with your own PIN.</Text>}
        <Btn testID="link-finish" title="Go to the login screen" icon="🔓" onPress={onDone} />
      </Screen>
    );
  }

  const ready = !!name.trim() && !!preview && !busy;
  return (
    <Screen title="Link to Easy Buys" subtitle="Join this device to the shop's other tablets and phones" hideUser onBack={onBack}>
      {linkState().linked ? <Banner tone="info" message="This device is already linked. Linking again replaces the old link." /> : null}
      <Card>
        <H>1. This device</H>
        <Field testID="link-name" label="Name" value={name} onChangeText={setName} placeholder='e.g. "Divnesh phone", "Bakers tablet"' />
        <Label>It is a…</Label>
        <Chips value={kind} onChange={setKind} testIDPrefix="link-kind" options={[{ value: 'tablet', label: '📟 Tablet' }, { value: 'phone', label: '📱 Phone' }]} />
      </Card>
      <Card>
        <H>2. The invite</H>
        <Text style={{ fontSize: 16, color: C.sub, marginBottom: 8 }}>On a device that is already linked, the owner or admin opens Admin › Devices › Add a device. Then scan its QR code here, tap the link they sent you, or paste the code.</Text>
        {scan ? (
          <View style={{ gap: 10 }}>
            <QRScanner key={scan} size={Math.min(320, width - 80)} onScan={(t) => { setScan(0); setCode(t); try { parseLinkCode(t); link(t); } catch (e) { setError(e.message); } }} />
            <Btn title="Stop scanning" variant="secondary" size="md" onPress={() => setScan(0)} />
          </View>
        ) : (
          <Btn testID="link-scan" title="Scan the QR code" icon="📷" variant="info" onPress={() => { setError(''); setScan((n) => n + 1); }} disabled={!!busy} />
        )}
        <Field testID="link-code" label="…or paste the code (starts with EB1-)" value={code} onChangeText={(v) => { setCode(v); setError(''); }} multiline />
        {code.trim() && !preview ? <Text style={{ fontSize: 15, color: C.danger }}>That does not look like a full Easy Buys code yet.</Text> : null}
      </Card>
      {error ? <Banner testID="link-error" tone="danger" title="Could not link" message={error} /> : null}
      {busy ? <Banner tone="info" title={busy} message="Keep the app open. This needs internet." /> : null}
      <Btn testID="link-go" title="Link this device" icon="🔗" variant="success" onPress={() => link()} disabled={!ready} />
      {!name.trim() ? <Text style={{ fontSize: 14, color: C.sub, textAlign: 'center' }}>Give the device a name first.</Text> : null}
    </Screen>
  );
}
