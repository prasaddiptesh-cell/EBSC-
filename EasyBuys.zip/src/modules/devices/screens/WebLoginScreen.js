// 1.0.0 build 47: the website's front door (owner, 11 Nov: "sign in via email then a PIN is the way to go").
// The person types their login email, gets a 6-digit code by email (5 minutes), and types it with their own PIN –
// the cloud checks both before anything comes to this browser. Then it fetches the business for that person's role
// and they are in (no linking, no invite).
import React, { useState } from 'react';
import { View, Platform } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Card, Btn, Banner, Field } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { webSendCode, webLogin } from '../service.js';
import { syncNow } from '../../../platform/cloud.js';
import GettingBusinessScreen from './GettingBusinessScreen.js';

const browserName = () => {
  try {
    const ua = String((typeof navigator !== 'undefined' && navigator.userAgent) || '');
    const b = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
    const os = /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'Mac' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone/iPad' : /Linux/.test(ua) ? 'Linux' : '';
    return `${b}${os ? ` on ${os}` : ''}`;
  } catch (e) { return 'Browser'; }
};

export default function WebLoginScreen({ onInvite, onDone, expired = false }) {
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState('email'); // email → code → getting
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const send = async () => {
    setBusy(true); setErr('');
    try { setMsg(await webSendCode(email)); setStep('code'); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  const login = async () => {
    setBusy(true); setErr('');
    try { await webLogin({ email, code, pin, browser: browserName() }); setStep('getting'); syncNow({ force: true }).catch(() => {}); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  if (step === 'getting') return <GettingBusinessScreen onReady={() => { if (onDone) onDone(pin); }} />;
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: C.bg }}>
      <View style={{ width: '100%', maxWidth: 460 }}>
        <Text style={{ fontSize: 30, fontWeight: '900', color: C.primary, textAlign: 'center' }}>Easy Buys</Text>
        <Text style={{ fontSize: 16, color: C.muted, textAlign: 'center', marginBottom: 18 }}>Website login</Text>
        {expired ? <Banner tone="warn" message="Your website login ran out (12 hours) and this browser was cleared. Log in again." /> : null}
        <Card>
          {step === 'email' ? (
            <>
              <Field testID="web-email" label="Your email" value={email} onChangeText={setEmail} keyboardType="email-address" lettersToo />
              <Btn testID="web-send" title={busy ? 'Sending…' : 'Email me a login code'} icon="✉️" variant="primary" disabled={busy || !email} onPress={send} />
            </>
          ) : (
            <>
              <Text style={{ fontSize: 15, color: C.text, marginBottom: 8 }}>{msg || 'A code is on its way to your email.'}</Text>
              <Field testID="web-code" label="The 6-digit code from the email" value={code} onChangeText={(v) => setCode(String(v).replace(/\D/g, '').slice(0, 6))} keyboardType="number-pad" lettersToo={false} />
              <Field testID="web-pin" label="Your PIN (the same as on the phones and tablets)" value={pin} secure onChangeText={(v) => setPin(String(v).replace(/\D/g, '').slice(0, 8))} keyboardType="number-pad" lettersToo={false} />
              <Btn testID="web-login" title={busy ? 'Checking…' : 'Log in'} icon="🔐" variant="success" disabled={busy || code.length !== 6 || pin.length < 4} onPress={login} />
              <Btn testID="web-back" title="Use a different email / send a new code" variant="ghost" size="sm" onPress={() => { setStep('email'); setCode(''); setErr(''); }} />
            </>
          )}
          {err ? <Banner tone="danger" message={err} /> : null}
        </Card>
        <Text style={{ fontSize: 13, color: C.muted, marginTop: 14, textAlign: 'center' }}>
          The owner chooses who may use the website and their login email (Admin › Website logins). Every login is emailed to the owner.
          A login lasts 12 hours; then everything is cleared from this computer.
        </Text>
      </View>
    </View>
  );
}
export const isWeb = Platform.OS === 'web';
