// 1.0.0 build 47/49: the front door of the website AND of a new phone or tablet (owner, 11 Nov: "sign in via email
// then a PIN is the way to go"; "the linking of devices and computers needs a better way").
// The person types their login email, gets a 6-digit code by email (5 minutes), and types it with their own PIN –
// the cloud checks both before anything comes to this device. On a phone or tablet the owner / an admin is asked whose
// device it is: their own, a shop's tablet or the bakery tablet (staff then use their PINs on it).
import React, { useState } from 'react';
import { View, Platform } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Card, Btn, Banner, Field, Chips, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { webSendCode, webCheckCode, webFinish, suggestDeviceName } from '../service.js';
import { syncNow } from '../../../platform/cloud.js';
import GettingBusinessScreen from './GettingBusinessScreen.js';

const browserName = () => {
  try {
    const ua = String((typeof navigator !== 'undefined' && navigator.userAgent) || '');
    const b = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
    const os = /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'Mac' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone/iPad' : /Linux/.test(ua) ? 'Linux' : '';
    return `${b}${os ? ` on ${os}` : ''}`;
  } catch (e) { return 'Browser'; }
};
const OWNERISH = ['owner', 'admin'];

export default function WebLoginScreen({ onInvite, onClassic, onDone, expired = false }) {
  const web = Platform.OS === 'web';
  const { isPhone } = useLayout();
  const kind = isPhone ? 'phone' : 'tablet';
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [code, setCode] = useState('');
  const [name, setName] = useState(() => { try { return suggestDeviceName(kind); } catch (e) { return ''; } });
  const [shared, setShared] = useState('own');
  const [checked, setChecked] = useState(null); // the cloud's answer to the code (owner on a phone/tablet: whose device?)
  const [step, setStep] = useState('email'); // email → code → (whose) → getting
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const send = async () => {
    setBusy(true); setErr('');
    try { setMsg(await webSendCode(email)); setStep('code'); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  const finish = async (c) => {
    await webFinish(c, { pin, browser: browserName(), kind, name, shared: shared === 'own' ? '' : shared });
    setStep('getting'); syncNow({ force: true }).catch(() => {});
  };
  const login = async () => {
    setBusy(true); setErr('');
    try {
      const c = await webCheckCode({ email, code });
      if (!web && OWNERISH.includes(c.role)) { setChecked(c); setStep('whose'); } else await finish(c);
    } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  const whose = async () => { setBusy(true); setErr(''); try { await finish(checked); } catch (e) { setErr(e.message); if (/took too long|start again/i.test(e.message)) { setStep('email'); setCode(''); } } finally { setBusy(false); } };
  if (step === 'getting') return <GettingBusinessScreen onReady={() => { if (onDone) onDone(pin); }} />;
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: C.bg }}>
      <View style={{ width: '100%', maxWidth: 460 }}>
        <Text style={{ fontSize: 30, fontWeight: '900', color: C.primary, textAlign: 'center' }}>Easy Buys</Text>
        <Text style={{ fontSize: 16, color: C.muted, textAlign: 'center', marginBottom: 18 }}>{web ? 'Website login' : `Log in to set up this ${kind}`}</Text>
        {expired ? <Banner tone="warn" message="Your website login ran out (12 hours) and this browser was cleared. Log in again." /> : null}
        <Card>
          {step === 'email' ? (
            <>
              <Field testID="web-email" label="Your login email" value={email} onChangeText={setEmail} keyboardType="email-address" lettersToo />
              <Btn testID="web-send" title={busy ? 'Sending…' : 'Email me a login code'} icon="✉️" variant="primary" disabled={busy || !email} onPress={send} />
            </>
          ) : step === 'code' ? (
            <>
              <Text style={{ fontSize: 15, color: C.text, marginBottom: 8 }}>{msg || 'A code is on its way to your email.'}</Text>
              <Field testID="web-code" label="The 6-digit code from the email" value={code} onChangeText={(v) => setCode(String(v).replace(/\D/g, '').slice(0, 6))} keyboardType="number-pad" lettersToo={false} />
              <Field testID="web-pin" label="Your PIN (the same as on the phones and tablets)" value={pin} secure onChangeText={(v) => setPin(String(v).replace(/\D/g, '').slice(0, 8))} keyboardType="number-pad" lettersToo={false} />
              {!web ? <Field testID="web-name" label={`This ${kind}'s name`} value={name} onChangeText={setName} /> : null}
              <Btn testID="web-login" title={busy ? 'Checking…' : 'Log in'} icon="🔐" variant="success" disabled={busy || code.length !== 6 || pin.length < 4} onPress={login} />
              <Btn testID="web-back" title="Use a different email / send a new code" variant="ghost" size="sm" onPress={() => { setStep('email'); setCode(''); setErr(''); }} />
            </>
          ) : (
            <>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`Whose ${kind} is this?`}</Text>
              <Chips testIDPrefix="web-whose" value={shared} onChange={setShared} options={[
                { value: 'own', label: `My own (${checked && checked.name ? checked.name : 'owner'})` },
                { value: 'S1', label: 'Shop 1 tablet' }, { value: 'S2', label: 'Shop 2 tablet' }, { value: 'bakery', label: 'Bakery tablet' }]} />
              <Text style={{ fontSize: 14, color: C.muted }}>{shared === 'own' ? 'Everything you may see and do, on this device.' : 'A shared device: each person logs in with their own PIN and sees only what their job needs.'}</Text>
              <Btn testID="web-whose-ok" title={busy ? 'Setting up…' : 'Set it up'} variant="success" disabled={busy} onPress={whose} />
            </>
          )}
          {err ? <Banner tone="danger" message={err} /> : null}
          {err && web ? <Btn testID="web-fresh" title="Clear this browser and try again" variant="secondary" size="sm" onPress={() => { try { require('../../../db/expoAdapter.js').freshBrowserCopy(); } catch (e) { /* not a browser */ } }} /> : null}
        </Card>
        <Text style={{ fontSize: 13, color: C.muted, marginTop: 14, textAlign: 'center' }}>
          {web ? 'The owner chooses who may use the website and their login email (Admin › Website logins). Every login is emailed to the owner. A login lasts 12 hours; then everything is cleared from this computer.'
            : 'Your login email is set by the owner (Admin › Website logins). The owner is emailed about every new device.'}
        </Text>
        {onInvite ? <Btn testID="web-invite" title="No email? Use a code from the owner's phone" variant="ghost" size="sm" onPress={onInvite} /> : null}
        {onClassic ? <Btn testID="web-classic" title="Other options (a new business, help)" variant="ghost" size="sm" onPress={onClassic} /> : null}
      </View>
    </View>
  );
}
