// Linking devices. The Google cloud is set up once; after that every new tablet or phone is added
// from inside the app with a single-use invite (QR code, email link or a code sent by message).
// The cloud key never leaves the first device: each linked device gets its own access token,
// so a lost phone can be blocked on its own.
import { db } from '../../db/connection.js';
import { AppError, getSetting, setSetting, stamp, deviceId, deviceName, APP_VERSION, audit, wallFromReal } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function utf8Decode(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += '%' + bytes[i].toString(16).padStart(2, '0');
  return decodeURIComponent(s);
}
function utf8Encode(str) {
  const out = [];
  const esc = encodeURIComponent(str);
  for (let i = 0; i < esc.length; i++) {
    if (esc[i] === '%') { out.push(parseInt(esc.substr(i + 1, 2), 16)); i += 2; } else out.push(esc.charCodeAt(i));
  }
  return out;
}
export function b64WebSafeDecode(s) {
  const clean = String(s).replace(/-/g, '+').replace(/_/g, '/').replace(/=+$/, '');
  const bytes = [];
  let buf = 0;
  let bits = 0;
  for (const ch of clean) {
    const v = B64.indexOf(ch);
    if (v < 0) throw new AppError('That code has a typing mistake in it.');
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) { bits -= 8; bytes.push((buf >> bits) & 0xff); }
  }
  return utf8Decode(bytes);
}
export function b64WebSafeEncode(str) {
  const bytes = utf8Encode(str);
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | ((bytes[i + 1] || 0) << 8) | (bytes[i + 2] || 0);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + (i + 1 < bytes.length ? B64[(n >> 6) & 63] : '=') + (i + 2 < bytes.length ? B64[n & 63] : '=');
  }
  return out.replace(/\+/g, '-').replace(/\//g, '_');
}

// Accepts the code on its own, the easybuys:// tap link, or a whole message with the code inside.
export function parseLinkCode(text) {
  let t = String(text || '').trim();
  const tap = t.match(/easybuys:\/\/link\?c=([^\s"'<>]+)/) || t.match(/[?&]link=([^\s&"'<>]+)/);
  if (tap) { try { t = decodeURIComponent(tap[1]); } catch (e) { t = tap[1]; } }
  const m = t.match(/EB1-[A-Za-z0-9_\-=]+/);
  if (!m) throw new AppError('That is not an Easy Buys link code. It starts with EB1-');
  let o;
  try {
    o = JSON.parse(b64WebSafeDecode(m[0].slice(4)));
  } catch (e) {
    throw new AppError('The code is not complete. Copy all of it, or scan the QR code instead.');
  }
  // 1.0.0 build 47: since the move, invites point to the new cloud (Easy Buys' own Cloudflare address) – both allowed
  if (!o || typeof o.u !== 'string' || !(/^https:\/\/script\.google(usercontent)?\.com\//.test(o.u) || /^https:\/\/[a-z0-9-]+\.easybuys\.workers\.dev(\/[A-Za-z0-9._~\/-]*)?$/i.test(o.u))) throw new AppError('The code does not point to the Easy Buys cloud.');
  if (!/^[A-Z0-9]{6,12}$/.test(String(o.i || ''))) throw new AppError('The invite in this code is not valid.');
  return { url: o.u, invite: o.i, code: m[0] };
}

export function linkState() {
  const url = getSetting('cloud_url', '');
  const token = getSetting('cloud_token', '');
  const key = getSetting('cloud_key', '');
  return {
    linked: !!url && !!(token || key),
    url,
    method: token ? 'invite' : key ? 'key' : null,
    linkedAt: getSetting('linked_at', ''),
    waiting: getSetting('link_waiting', '') === '1',
  };
}

// The message sent by WhatsApp / Viber / SMS / email.
export function inviteMessage(inv, byName) {
  return `${byName || 'Easy Buys'} invited you to the Easy Buys app.\n\n`
    + `1) Install the Easy Buys app.\n2) On the phone or tablet, tap this link, then "Open in the Easy Buys app":\n${inv.linkUrl || `easybuys://link?c=${encodeURIComponent(inv.linkCode)}`}\n`
    + `3) If the link does not open the app: open the app, tap "Link to Easy Buys" and paste this code:\n${inv.linkCode}\n\n`
    + 'It works once and expires in 48 hours.';
}

// 1.0.0 build 10 (owner, 2 Nov: "the linking of devices is a mess"): a busy cloud (it answered "busy", or did not
// answer within the time limit) is not "no internet" – the phone tries again by itself.
const busyErr = (retryMs) => Object.assign(new AppError('The cloud is busy – trying again'), { busy: true, retryMs: Number(retryMs) || 0 });
async function postTo(url, body, timeoutMs = 60000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    let res; let text;
    try {
      res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body), signal: ctrl ? ctrl.signal : undefined });
      text = await res.text();
    } catch (e) {
      if ((ctrl && ctrl.signal && ctrl.signal.aborted) || (e && e.name === 'AbortError')) throw busyErr(0);
      throw new AppError('No internet connection. Connect to Wi-Fi or mobile data and try again.');
    }
    let json;
    try { json = JSON.parse(text); } catch (e) { throw new AppError('The cloud did not reply correctly. Try again in a minute.'); }
    if (!json.ok && json.busy) throw busyErr(json.retryMs);
    // Release 07: the reason is always shown as words (an answer whose reason was not text showed "[object Object]")
    if (!json.ok) {
      const er = json.error;
      const why = typeof er === 'string' ? er : er && typeof er.message === 'string' ? er.message : er ? (() => { try { return JSON.stringify(er).slice(0, 200); } catch (x) { return ''; } })() : '';
      throw new AppError(why || 'The cloud refused the request.');
    }
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}
const numText = (n) => Number(n || 0).toLocaleString('en-US');
// "Receiving 1200 of 2850…" (the sync's own words) → "Getting the business… 1,200 of 2,850"
export function firstSyncText(progress) {
  const m = String(progress || '').match(/Receiving ([\d,]+) of ([\d,]+)/);
  if (m) return `Getting the business… ${numText(m[1].replace(/,/g, ''))} of ${numText(m[2].replace(/,/g, ''))}`;
  if (/slow or no connection/i.test(String(progress || ''))) return 'Getting the business… slow or no connection, trying again';
  if (/busy/i.test(String(progress || ''))) return 'Getting the business… the cloud is busy, trying again';
  return 'Getting the business…';
}

export const JOIN_WAITS = [2000, 4000, 8000, 12000, 20000];
// A name to start with: "<model> phone" (e.g. "Galaxy A15 phone").
export function suggestDeviceName(kind = 'phone') {
  let model = '';
  try { const D = require('expo-device'); model = String((D && (D.modelName || D.deviceName)) || '').trim(); } catch (e) { model = ''; }
  if (!model) { try { const P = require('react-native').Platform; model = String((P && P.constants && (P.constants.Model || P.constants.model)) || '').trim(); } catch (e) { model = ''; } }
  model = model.replace(/\s*(phone|tablet)$/i, '').slice(0, 28);
  return model ? `${model} ${kind}` : '';
}

// review (3 Nov): "until 07:45" on Add a phone was the cloud's UTC time – shown in Fiji time now ("7:45 pm").
export function fijiClockText(iso) {
  const ms = Date.parse(String(iso || ''));
  if (!Number.isFinite(ms)) return '';
  const w = wallFromReal(ms);
  const h = w.getHours();
  return `${h % 12 || 12}:${String(w.getMinutes()).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`;
}
// The join's own number for this invite: made once, kept in the settings until the device is linked.
export function joinNonceFor(invite) {
  const code = String(invite || '').trim().toUpperCase();
  let kept = null;
  try { kept = JSON.parse(getSetting('join_nonce', '') || 'null'); } catch (e) { kept = null; }
  if (kept && kept.code === code && kept.nonce && kept.device === deviceId()) return String(kept.nonce);
  const nonce = `${deviceId()}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
  setSetting('join_nonce', JSON.stringify({ code, nonce, device: deviceId(), at: stamp() }));
  return nonce;
}
// New device: swap the invite for this device's own access token.
// onStep(text): what to show while it works ("Linking… the cloud is busy, trying again"). A busy cloud is asked again
// with a growing wait (about 45 seconds in all) before it gives up.
export async function joinWithCode(text, { name, kind = 'phone', onStep = null, wait = (ms) => new Promise((r) => setTimeout(r, ms)), waits = JOIN_WAITS } = {}) {
  const { url, invite } = parseLinkCode(text);
  const n = String(name || '').trim();
  if (!n) throw new AppError('Give this device a name, e.g. "Divnesh phone" or "Bakers tablet".');
  if (!['tablet', 'phone'].includes(kind)) throw new AppError('Choose tablet or phone.');
  setSetting('device_name', n.slice(0, 40));
  setSetting('device_kind', kind);
  if (getSetting('clock_here', '') === '') setSetting('clock_here', kind === 'phone' ? '0' : '1');
  let r = null;
  // the same join on every try (the cloud gives a fresh pass if an earlier try went through but its answer was lost).
  // review (3 Nov): kept with the invite code until this device is linked, so tapping Link again after a lost answer
  // sends the SAME join (it used to make a new one: the cloud said "already linked" and an invite use was spent).
  const nonce = joinNonceFor(invite);
  for (let n2 = 0; ; n2 += 1) {
    try {
      if (onStep) onStep(n2 ? 'Linking… the cloud is busy, trying again' : 'Linking…');
      r = await postTo(url, { kind: 'join', invite, nonce, app: APP_VERSION, device: { id: deviceId(), name: deviceName(), kind } });
      break;
    } catch (e) {
      if (!e || !e.busy || n2 >= waits.length) {
        if (e && e.busy) throw new AppError('The cloud is very busy right now. Wait a minute and tap Link again – the QR code still works.');
        throw e;
      }
      await wait(Math.max(waits[n2], Math.min(15000, e.retryMs || 0)));
    }
  }
  setSetting('cloud_url', url);
  setSetting('cloud_token', r.token);
  setSetting('join_nonce', '');
  setSetting('cloud_key', '');
  setSetting('linked_at', stamp());
  setSetting('link_waiting', r.approved ? '0' : '1');
  setSetting('retire_samples', '1');
  setSetting('pull_seq', '0');
  audit({ user: null, action: 'Linked this device to Easy Buys', table: 'device', after: { name: n, kind } });
  // 1.0.0 build 16: joined with a role (allowed at once) – kept until the first pull says it again
  if (r.role) setSetting('device_role', String(r.role));
  return { approved: !!r.approved, role: r.role || null };
}

// A newly linked device drops the sample logins (Admin 1111 etc.) once the real staff have arrived.
export function retireSampleLogins() {
  if (getSetting('retire_samples', '') !== '1') return 0;
  // 1.0.0 build 1: a real login has its PIN as a hash (pin_hash); on a shop tablet the owner's hash is not there at all,
  // so any real staff login that arrived also counts.
  const real = db().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND (pin <> '' OR pin_hash LIKE 'p2:%' OR role IN ('owner','admin')) AND sync_status <> 'seed'");
  if (!real || !real.n) return 0;
  const r = db().run("UPDATE users SET active = 0 WHERE sync_status = 'seed' AND active = 1");
  setSetting('show_demo_pins', '0');
  setSetting('retire_samples', '');
  return r.changes;
}

// v3.9.3 the owner / admin turns the sample logins off on this device now (Moving in & go-live, or the Home warning).
// Only once a real owner / admin login exists, so nobody is ever locked out. Kept (inactive), never deleted.
export function retireSampleLoginsNow(user) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can do this.');
  const real = db().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin') AND (pin <> '' OR pin_hash LIKE 'p2:%') AND COALESCE(sync_status, '') <> 'seed'");
  if (!real || !real.n) throw new AppError('First add your own owner / admin login (Staff › Users) – then the sample logins can go.');
  const r = db().run("UPDATE users SET active = 0 WHERE sync_status = 'seed' AND active = 1");
  setSetting('show_demo_pins', '0');
  audit({ user, action: `Turned off ${r.changes} sample login(s) on this device`, table: 'users' });
  return r.changes;
  });
}
export function sampleLoginsActive() {
  return db().all("SELECT name, pin FROM users WHERE sync_status = 'seed' AND active = 1 ORDER BY id");
}

export function unlinkThisDevice(user) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  ['cloud_url', 'cloud_token', 'cloud_key', 'linked_at', 'link_waiting'].forEach((k) => setSetting(k, ''));
  audit({ user, action: 'Unlinked this device from Easy Buys', table: 'device' });
  });
}

export const DEVICE_STATUS_LABEL = { active: 'Linked', blocked: 'Blocked', waiting: 'Waiting for approval', removed: 'Removed' };
// The last list of devices from the cloud (for warnings while offline).
export function cacheDevices(list) { try { setSetting('devices_cache', JSON.stringify({ at: stamp(), list: list || [] })); } catch (e) { /* ignore */ } }
// 1.0.0 build 10: new phones waiting for the owner's OK (from the last sync of the owner's / an admin's device)
export function waitingDevices() { try { return JSON.parse(getSetting('devices_waiting', '') || '[]') || []; } catch (e) { return []; } }
export function cachedDevices() { try { return JSON.parse(getSetting('devices_cache', '') || 'null'); } catch (e) { return null; } }

export function ago(iso) {
  if (!iso) return 'never';
  const t = new Date(String(iso)).getTime();
  if (!Number.isFinite(t)) return String(iso);
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 2) return 'just now';
  if (m < 60) return `${m} min ago`;
  if (m < 48 * 60) return `${Math.round(m / 60)} h ago`;
  return `${Math.round(m / 1440)} days ago`;
}

// ---------------------------------------------------------------- 1.0.0 build 47: the website
// A browser on a computer logs in with the person's own email login: their website password AND a 6-digit code the
// cloud emails to them (5 minutes). It then works as a device of that person's role for 12 hours; after that (or on
// "Log out of the website") everything it downloaded is cleared from the browser.
export const WEB_CLOUD_URL = 'https://easybuys-cloud.easybuys.workers.dev';
export function webDeviceId() {
  const id = getSetting('device_id', '');
  if (/^web-/.test(id)) return id;
  const fresh = `web-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 10)}`;
  setSetting('device_id', fresh);
  return fresh;
}
export async function webSendCode(email, { url = WEB_CLOUD_URL } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) throw new AppError('Type your email address.');
  const r = await postTo(url, { kind: 'email_login_start', web: true, email: e, app: APP_VERSION, device: { id: webDeviceId(), kind: 'web' } });
  return (r && r.message) || 'If this email may log in, a code is on its way. It works for 5 minutes.';
}
// The emailed code, then the person's own PIN (checked by the cloud before anything comes to this device).
// 1.0.0 build 49: phones and tablets log in the same way (onWeb false: this device's own id, kind phone / tablet).
const onWeb = () => { try { return require('react-native').Platform.OS === 'web'; } catch (e) { return false; } };
export async function webCheckCode({ email, code }, { url = WEB_CLOUD_URL } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!e || !/^\d{6}$/.test(String(code || '').trim())) throw new AppError('Type the 6-digit code from the email.');
  const id = onWeb() ? webDeviceId() : deviceId();
  const c = await postTo(url, { kind: 'web_code', web: true, email: e, code: String(code).trim(), app: APP_VERSION, device: { id, kind: onWeb() ? 'web' : getSetting('device_kind', 'phone') } });
  if (c.salt) setSetting('pin_salt', c.salt);
  return { ...c, email: e };
}
// Release 25 (cloud script 46; owner, 14 Nov: "all log in will be via the email and password. The initial password is
// sent to the email on the staff profile; after the first login the website asks for a change of password, where the
// password strength matters"). The website logs in with email + password – no emailed code each time.
export const PW_RULES = ['At least 10 characters', 'Letters and numbers', 'Not your name or email', 'Not an easy word (password, easybuys, 1234…)'];
export function pwProblem(pw, { name = '', email = '' } = {}) {
  const p = String(pw || '');
  if (p.length < 10) return 'At least 10 characters.';
  if (!/[A-Za-z]/.test(p) || !/[0-9]/.test(p)) return 'Use letters and numbers.';
  const low = p.toLowerCase();
  const local = String(email || '').split('@')[0].toLowerCase();
  if (local.length >= 4 && low.includes(local)) return 'It must not contain your email.';
  const first = String(name || '').split(/\s+/)[0].toLowerCase();
  if (first.length >= 3 && low.includes(first)) return 'It must not contain your name.';
  if (['password', 'easybuys', 'qwerty', '123456', 'letmein', 'welcome', 'admin', 'fiji', 'lautoka', 'drasa', 'tukani'].some((w) => low.includes(w)) || /^(.)\1+$/.test(p) || /(0123|1234|2345|3456|4567|5678|6789|abcd)/i.test(p)) return 'Too easy to guess.';
  return null;
}
export function pwStrength(pw) {
  const p = String(pw || '');
  let n = 0;
  if (p.length >= 10) n += 1; if (p.length >= 14) n += 1;
  if (/[a-z]/.test(p) && /[A-Z]/.test(p)) n += 1;
  if (/[0-9]/.test(p)) n += 1; if (/[^A-Za-z0-9]/.test(p)) n += 1;
  return n <= 2 ? 'weak' : n <= 3 ? 'ok' : 'strong';
}
export async function webPwSend(email, { url = WEB_CLOUD_URL } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) throw new AppError('Type the email address.');
  const r = await postTo(url, { kind: 'web_pw_send', email: e, app: APP_VERSION, device: { id: onWeb() ? webDeviceId() : deviceId(), kind: onWeb() ? 'web' : 'phone' } });
  return (r && r.message) || 'If this email may log in, a password has been sent to it.';
}
export async function webPwLogin({ email, password, browser = '' }, { url = WEB_CLOUD_URL } = {}) {
  const e = String(email || '').trim().toLowerCase();
  if (!e || !password) throw new AppError('Type your email and password.');
  const id = webDeviceId();
  const r = await postTo(url, { kind: 'web_pw_login', email: e, password: String(password), where: String(browser).slice(0, 80), app: APP_VERSION, device: { id, name: String(browser).slice(0, 40), kind: 'web' } });
  if (r.salt) setSetting('pin_salt', r.salt);
  setSetting('device_name', `Website – ${e}`.slice(0, 40));
  setSetting('device_kind', 'web');
  setSetting('cloud_url', url);
  setSetting('cloud_token', r.token);
  setSetting('cloud_key', '');
  setSetting('linked_at', stamp());
  setSetting('link_waiting', '0');
  setSetting('retire_samples', '1');
  setSetting('pull_seq', '0');
  setSetting('web_until', r.until || '');
  setSetting('device_lock', '');
  setSetting('device_blocked', '0');
  setSetting('web_email', e);
  setSetting('web_uid', r.uid || '');
  setSetting('web_session', r.session || '');
  setSetting('web_session_until', r.sessionUntil || '');
  try { require('../../services/pins.js').setCloudSession(r.uid, r.session, r.sessionUntil); } catch (x) { /* a PIN login later */ }
  audit({ user: null, action: `Website login (${e})`, table: 'device' });
  return { uid: r.uid, role: r.role, name: r.name || '', mustChange: !!r.mustChange, email: e };
}
// The person's own new password (the website, logged in): checked here and again by the cloud.
export async function webPwChange({ password, newPassword }, { url = WEB_CLOUD_URL } = {}) {
  const r = await postTo(getSetting('cloud_url', '') || url, { kind: 'web_pw_change', password: String(password || ''), newPassword: String(newPassword || ''), token: getSetting('cloud_token', ''), session: getSetting('web_session', ''), app: APP_VERSION, device: { id: webDeviceId(), kind: 'web' } });
  return r;
}
// After a refresh: the person who logged in with their password comes back without a PIN (the cloud session is kept for
// the tab, or for the 12 hours with "Remember this computer").
export function webPasswordUser() {
  if (!onWeb()) return null;
  const uid = getSetting('web_uid', '');
  const until = getSetting('web_session_until', '');
  if (!uid || !getSetting('web_session', '') || (until && Date.parse(until) <= Date.now())) return null;
  const u = db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [uid]);
  if (!u) return null;
  try { require('../../services/pins.js').setCloudSession(uid, getSetting('web_session', ''), until); } catch (e) { /* none */ }
  return u;
}
export async function webFinish(c, { pin, browser = '', kind = 'phone', name = '', shared = '' }, { url = WEB_CLOUD_URL } = {}) {
  if (!/^\d{4,8}$/.test(String(pin || '').trim())) throw new AppError('Type your PIN.');
  const P = require('../../services/pins.js');
  const proof = P.pinProof(String(pin).trim(), c.uid, c.salt);
  if (!proof) throw new AppError('Type your PIN.');
  const web = onWeb();
  const id = web ? webDeviceId() : deviceId();
  const k = web ? 'web' : (kind === 'tablet' ? 'tablet' : 'phone');
  const nm = web ? String(browser).slice(0, 40) : String(name || '').trim().slice(0, 40);
  const r = await postTo(url, { kind: 'web_join', ticket: c.ticket, proof, shared: web ? '' : shared, where: String(browser).slice(0, 80), app: APP_VERSION, device: { id, name: nm, kind: k } });
  setSetting('device_name', (web ? `Website – ${c.email}` : nm || `${c.name || ''} ${k}`).slice(0, 40));
  setSetting('device_kind', k);
  if (!web && getSetting('clock_here', '') === '') setSetting('clock_here', k === 'phone' ? '0' : '1');
  setSetting('cloud_url', url);
  setSetting('cloud_token', r.token);
  setSetting('cloud_key', '');
  setSetting('linked_at', stamp());
  setSetting('link_waiting', '0');
  setSetting('retire_samples', '1');
  setSetting('pull_seq', '0');
  setSetting('web_until', r.until || '');
  setSetting('device_lock', '');
  setSetting('device_blocked', '0');
  setSetting('web_email', c.email);
  audit({ user: null, action: `${web ? 'Website' : 'Device'} login (${c.email})${shared ? ` – set up as ${shared}` : ''}`, table: 'device' });
  return { until: r.until, role: r.role, uid: c.uid };
}
export async function webLogin({ email, code, pin, browser = '' }, opts = {}) {
  const c = await webCheckCode({ email, code }, opts);
  return webFinish(c, { pin, browser }, opts);
}
