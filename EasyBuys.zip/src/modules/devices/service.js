// Linking devices. The Google cloud is set up once; after that every new tablet or phone is added
// from inside the app with a single-use invite (QR code, email link or a code sent by message).
// The cloud key never leaves the first device: each linked device gets its own access token,
// so a lost phone can be blocked on its own.
import { db } from '../../db/connection.js';
import { AppError, getSetting, setSetting, stamp, deviceId, deviceName, APP_VERSION, audit } from '../../services/core.js';

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function utf8Decode(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += '%' + bytes[i].toString(16).padStart(2, '0');
  return decodeURIComponent(s);
}
function utf8Encode(str) {
  const out = [];
  const esc = encodeURIComponent(str);
  for (let i = 0; i < esc.length; i++) {
    if (esc[i] === '%') { out.push(parseInt(esc.substr(i + 1, 2), 16)); i += 2; } else out.push(esc.charCodeAt(i));
  }
  return out;
}
export function b64WebSafeDecode(s) {
  const clean = String(s).replace(/-/g, '+').replace(/_/g, '/').replace(/=+$/, '');
  const bytes = [];
  let buf = 0;
  let bits = 0;
  for (const ch of clean) {
    const v = B64.indexOf(ch);
    if (v < 0) throw new AppError('That code has a typing mistake in it.');
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) { bits -= 8; bytes.push((buf >> bits) & 0xff); }
  }
  return utf8Decode(bytes);
}
export function b64WebSafeEncode(str) {
  const bytes = utf8Encode(str);
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | ((bytes[i + 1] || 0) << 8) | (bytes[i + 2] || 0);
    out += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + (i + 1 < bytes.length ? B64[(n >> 6) & 63] : '=') + (i + 2 < bytes.length ? B64[n & 63] : '=');
  }
  return out.replace(/\+/g, '-').replace(/\//g, '_');
}

// Accepts the code on its own, the easybuys:// tap link, or a whole message with the code inside.
export function parseLinkCode(text) {
  let t = String(text || '').trim();
  const tap = t.match(/easybuys:\/\/link\?c=([^\s"'<>]+)/) || t.match(/[?&]link=([^\s&"'<>]+)/);
  if (tap) { try { t = decodeURIComponent(tap[1]); } catch (e) { t = tap[1]; } }
  const m = t.match(/EB1-[A-Za-z0-9_\-=]+/);
  if (!m) throw new AppError('That is not an Easy Buys link code. It starts with EB1-');
  let o;
  try {
    o = JSON.parse(b64WebSafeDecode(m[0].slice(4)));
  } catch (e) {
    throw new AppError('The code is not complete. Copy all of it, or scan the QR code instead.');
  }
  if (!o || typeof o.u !== 'string' || !/^https:\/\/script\.google(usercontent)?\.com\//.test(o.u)) throw new AppError('The code does not point to the Easy Buys cloud.');
  if (!/^[A-Z0-9]{6,12}$/.test(String(o.i || ''))) throw new AppError('The invite in this code is not valid.');
  return { url: o.u, invite: o.i, code: m[0] };
}

export function linkState() {
  const url = getSetting('cloud_url', '');
  const token = getSetting('cloud_token', '');
  const key = getSetting('cloud_key', '');
  return {
    linked: !!url && !!(token || key),
    url,
    method: token ? 'invite' : key ? 'key' : null,
    linkedAt: getSetting('linked_at', ''),
    waiting: getSetting('link_waiting', '') === '1',
  };
}

// The message sent by WhatsApp / Viber / SMS / email.
export function inviteMessage(inv, byName) {
  return `${byName || 'Easy Buys'} invited you to the Easy Buys app.\n\n`
    + `1) Install the Easy Buys app.\n2) On the phone or tablet, tap this link, then "Open in the Easy Buys app":\n${inv.linkUrl || `easybuys://link?c=${encodeURIComponent(inv.linkCode)}`}\n`
    + `3) If the link does not open the app: open the app, tap "Link to Easy Buys" and paste this code:\n${inv.linkCode}\n\n`
    + 'It works once and expires in 48 hours.';
}

async function postTo(url, body, timeoutMs = 60000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    let res;
    try {
      res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body), signal: ctrl ? ctrl.signal : undefined });
    } catch (e) {
      throw new AppError('No internet connection. Connect to Wi-Fi or mobile data and try again.');
    }
    let json;
    try { json = JSON.parse(await res.text()); } catch (e) { throw new AppError('The cloud did not reply correctly. Try again in a minute.'); }
    if (!json.ok) throw new AppError(json.error || 'The cloud refused the request.');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

// New device: swap the invite for this device's own access token.
export async function joinWithCode(text, { name, kind }) {
  const { url, invite } = parseLinkCode(text);
  const n = String(name || '').trim();
  if (!n) throw new AppError('Give this device a name, e.g. "Divnesh phone" or "Bakers tablet".');
  if (!['tablet', 'phone'].includes(kind)) throw new AppError('Choose tablet or phone.');
  setSetting('device_name', n.slice(0, 40));
  setSetting('device_kind', kind);
  if (getSetting('clock_here', '') === '') setSetting('clock_here', kind === 'phone' ? '0' : '1');
  const r = await postTo(url, { kind: 'join', invite, app: APP_VERSION, device: { id: deviceId(), name: deviceName(), kind } });
  setSetting('cloud_url', url);
  setSetting('cloud_token', r.token);
  setSetting('cloud_key', '');
  setSetting('linked_at', stamp());
  setSetting('link_waiting', r.approved ? '0' : '1');
  setSetting('retire_samples', '1');
  setSetting('pull_seq', '0');
  audit({ user: null, action: 'Linked this device to Easy Buys', table: 'device', after: { name: n, kind } });
  return { approved: !!r.approved };
}

// A newly linked device drops the sample logins (Admin 1111 etc.) once the real staff have arrived.
export function retireSampleLogins() {
  if (getSetting('retire_samples', '') !== '1') return 0;
  const real = db().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin') AND pin <> '' AND sync_status <> 'seed'");
  if (!real || !real.n) return 0;
  const r = db().run("UPDATE users SET active = 0 WHERE sync_status = 'seed' AND active = 1");
  setSetting('show_demo_pins', '0');
  setSetting('retire_samples', '');
  return r.changes;
}

// v3.9.3 the owner / admin turns the sample logins off on this device now (Moving in & go-live, or the Home warning).
// Only once a real owner / admin login exists, so nobody is ever locked out. Kept (inactive), never deleted.
export function retireSampleLoginsNow(user) {
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can do this.');
  const real = db().get("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin') AND pin <> '' AND COALESCE(sync_status, '') <> 'seed'");
  if (!real || !real.n) throw new AppError('First add your own owner / admin login (Staff › Users) – then the sample logins can go.');
  const r = db().run("UPDATE users SET active = 0 WHERE sync_status = 'seed' AND active = 1");
  setSetting('show_demo_pins', '0');
  audit({ user, action: `Turned off ${r.changes} sample login(s) on this device`, table: 'users' });
  return r.changes;
}
export function sampleLoginsActive() {
  return db().all("SELECT name, pin FROM users WHERE sync_status = 'seed' AND active = 1 ORDER BY id");
}

export function unlinkThisDevice(user) {
  ['cloud_url', 'cloud_token', 'cloud_key', 'linked_at', 'link_waiting'].forEach((k) => setSetting(k, ''));
  audit({ user, action: 'Unlinked this device from Easy Buys', table: 'device' });
}

export const DEVICE_STATUS_LABEL = { active: 'Linked', blocked: 'Blocked', waiting: 'Waiting for approval', removed: 'Removed' };
// The last list of devices from the cloud (for warnings while offline).
export function cacheDevices(list) { try { setSetting('devices_cache', JSON.stringify({ at: stamp(), list: list || [] })); } catch (e) { /* ignore */ } }
export function cachedDevices() { try { return JSON.parse(getSetting('devices_cache', '') || 'null'); } catch (e) { return null; } }

export function ago(iso) {
  if (!iso) return 'never';
  const t = new Date(String(iso)).getTime();
  if (!Number.isFinite(t)) return String(iso);
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 2) return 'just now';
  if (m < 60) return `${m} min ago`;
  if (m < 48 * 60) return `${Math.round(m / 60)} h ago`;
  return `${Math.round(m / 1440)} days ago`;
}
