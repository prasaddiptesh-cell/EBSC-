// Warnings for Home: personal reminders (home rent, household groceries) and personal costs paid by the business
// without a receipt photo.
import { can } from '../../services/access.js';
import { dateStr } from '../../services/core.js';
import { personalDue, movesWithoutPhoto, $ } from './service.js';

export function alerts(user) {
  if (!can(user, 'drawings')) return [];
  const today = dateStr();
  const out = personalDue(today).map((p) => ({
    id: `own-due-${p.uid}-${p.next_date}`, level: p.late ? 'warning' : 'info',
    text: `${p.name}${p.amount ? ` (${$(p.amount)})` : ''} – ${p.late ? `was due ${p.next_date}` : p.next_date === today ? 'today' : `due ${p.next_date}`}`,
    sub: p.paid_by === 'business' ? 'Personal – paid by the business it counts as drawings.' : 'Personal reminder.',
    nav: { screen: 'PersonalReminders', params: {} },
  }));
  const noPhoto = movesWithoutPhoto({ today });
  if (noPhoto.length) out.push({ id: 'own-photos', level: 'info', text: `${noPhoto.length} personal cost${noPhoto.length === 1 ? '' : 's'} paid by the business without a receipt photo`, nav: { screen: 'OwnerMoves', params: {} } });
  return out;
}
