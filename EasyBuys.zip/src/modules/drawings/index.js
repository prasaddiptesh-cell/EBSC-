// Owner's money (v3.5): take money out, business paid for me, put money in, mixed costs with a business share,
// personal reminders (home rent, groceries). Never through payroll.
import { OwnerMoneyScreen, OwnerMoveEditScreen, OwnerMoveScreen, OwnerMovesScreen, PersonalRemindersScreen, DrawingsSettingsScreen } from './screens/DrawingsScreens.js';
import { can } from '../../services/access.js';
import { alerts } from './alerts.js';
import { REPORTS } from './reports.js';

const own = (u) => can(u, 'drawings');
export default {
  id: 'drawings',
  title: "Owner's money",
  icon: '👛',
  switchable: true,
  screens: {
    OwnerMoney: { component: OwnerMoneyScreen, can: own },
    OwnerMoveEdit: { component: OwnerMoveEditScreen, can: own },
    OwnerMove: { component: OwnerMoveScreen, can: own },
    OwnerMoves: { component: OwnerMovesScreen, can: own },
    PersonalReminders: { component: PersonalRemindersScreen, can: own },
    DrawingsSettings: { component: DrawingsSettingsScreen, can: (u) => can(u, 'drawings_setup') },
  },
  // Its menu items are shown in the Loans & rent menu (one place for loans, rent and the owners' money).
  alerts,
  reports: REPORTS,
};
