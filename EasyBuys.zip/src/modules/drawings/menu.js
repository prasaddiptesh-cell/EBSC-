// Owner's money menu (see src/services/menus.js).
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '👛', title: "Owner's money", note: 'Totals taken out, paid for you and put in.', screen: 'OwnerMoney' },
    { id: 'own-out', icon: '💸', title: 'Take money out', note: 'Cash from a shop or money from the bank for yourself.', screen: 'OwnerMoveEdit', params: { kind: 'take_out' } },
    { id: 'own-paid', icon: '🛒', title: 'Business paid for me', note: 'Personal or mixed costs the business paid (home rent, groceries, phone…).', screen: 'OwnerMoveEdit', params: { kind: 'paid_for_me' } },
    { id: 'own-in', icon: '💰', title: 'Put money in', note: 'Money into the business, or a business cost you paid yourself.', screen: 'OwnerMoveEdit', params: { kind: 'put_in' } },
    { id: 'own-reminders', icon: '🏠', title: 'Home rent & groceries reminders', note: 'Personal regular payments.', screen: 'PersonalReminders' },
  ] },
  { section: 'Records', items: [
    { id: 'own-list', icon: '📒', title: "All owner's money records", screen: 'OwnerMoves' },
  ] },
  { section: 'Reports', items: [
    { id: 'own-reports', icon: '📊', title: "Owner's money statement", screen: 'ReportsHub', params: { group: "Owner's money" }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'own-settings', icon: '⚙️', title: "Owner's money settings", note: 'One owner, or several family members.', screen: 'DrawingsSettings', perm: 'drawings_setup' },
  ] },
];
