// Owner's money statement (PDF / Excel / CSV / print / share through the shared report screen).
import { stamp } from '../../services/core.js';
import { drawingsSummary, listMoves, KINDS, viaLabel, costAreaLabel, $ } from './service.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
export const REPORTS = [
  { id: 'owner_money', group: "Owner's money", icon: '👛', title: "Owner's money statement", desc: 'Taken out, paid for the owner / family, put in – per person, with the business share of mixed costs', perm: 'drawings',
    build(from, to) {
      const s = drawingsSummary({ from, to });
      const rows = listMoves({ from, to, limit: 100000 }).reverse().map((m) => ({
        date: m.move_date, who: m.member_name, kind: KINDS[m.kind], what: m.what || '', via: viaLabel(m.via), total: $(m.amount), business: m.business_amount ? `${$(m.business_amount)} (${m.business_pct}% · ${costAreaLabel(m.cost_area)})` : '',
        vat: m.vat ? $(m.vat) : '', personal: m.personal_amount ? $(m.personal_amount) : '', receipt: m.photos.length ? 'photo' : m.kind === 'paid_for_me' ? 'MISSING' : '' }));
      return {
        kind: 'owner_money', title: "Owner's Money Statement", fileName: `Owners-Money-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`,
        info: [['Period', `${from} to ${to}`], ['Generated', stamp()], ['Note', 'Drawings are not wages: they never go through payroll and have no PAYE or FNPF.']],
        summary: [{ label: 'Taken out', value: $(s.takenOut) }, { label: 'Personal costs paid by the business', value: $(s.paidForMe) }, { label: 'Put in', value: $(s.putIn) }, { label: 'Net drawings', value: $(s.net) }],
        sections: [{ title: 'Per person', columns: [col('name', 'Who'), col('takenOut', 'Taken out', R), col('paidForMe', 'Paid for them', R), col('putIn', 'Put in', R), col('net', 'Net drawings', R), col('businessShare', 'Business share of mixed costs', R)],
          rows: s.byMember.map((p) => ({ name: p.name, takenOut: $(p.takenOut), paidForMe: $(p.paidForMe), putIn: $(p.putIn), net: $(p.net), businessShare: $(p.businessShare) })) },
        { title: 'Records', columns: [col('date', 'Date'), col('who', 'Who'), col('kind', 'What happened'), col('what', 'For'), col('via', 'From / to'), col('total', 'Total', R), col('business', 'Business part'), col('vat', 'VAT claimed', R), col('personal', 'Drawings', R), col('receipt', 'Receipt')], rows }],
      };
    } },
];
