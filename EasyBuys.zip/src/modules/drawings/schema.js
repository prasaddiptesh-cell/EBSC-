// Owner's money (v3.5): money the owner / family takes out, personal costs the business paid, money put in, and
// mixed costs with a business share. Each one is booked through the accounts as a journal (never through payroll).
// Personal regular payments (home rent, household groceries) are reminders here; they are never a business cost
// unless a business share is set.
export const DRAWINGS_SQL = `
CREATE TABLE IF NOT EXISTS owner_moves (
  uid TEXT PRIMARY KEY,
  move_date TEXT NOT NULL,
  kind TEXT NOT NULL,
  member_id TEXT,
  member_name TEXT,
  amount REAL NOT NULL,
  business_pct REAL NOT NULL DEFAULT 0,
  business_amount REAL NOT NULL DEFAULT 0,
  vat REAL NOT NULL DEFAULT 0,
  personal_amount REAL NOT NULL DEFAULT 0,
  via TEXT,
  cost_area TEXT,
  gl_code TEXT,
  what TEXT,
  supplier TEXT,
  tin TEXT,
  invoice_no TEXT,
  photo_urls TEXT,
  journal_uid TEXT,
  cash_uid TEXT,
  reminder_uid TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT, voided_by_name TEXT, voided_at TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_om_date ON owner_moves(move_date);
CREATE TABLE IF NOT EXISTS personal_regulars (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'other',
  amount REAL,
  frequency TEXT NOT NULL DEFAULT 'weekly',
  next_date TEXT NOT NULL,
  lead_days INTEGER NOT NULL DEFAULT 2,
  anchor_day INTEGER,
  member_id TEXT,
  business_pct REAL NOT NULL DEFAULT 0,
  gl_code TEXT,
  cost_area TEXT,
  paid_by TEXT NOT NULL DEFAULT 'business',
  via TEXT,
  receipt_required INTEGER NOT NULL DEFAULT 1,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const DRAWINGS_SYNC = {
  owner_moves: SYNC('uid', "Owner's money", ['uid', 'move_date', 'kind', 'member_id', 'member_name', 'amount', 'business_pct', 'business_amount', 'vat', 'personal_amount', 'via', 'cost_area', 'gl_code',
    'what', 'supplier', 'tin', 'invoice_no', 'photo_urls', 'journal_uid', 'cash_uid', 'reminder_uid', 'status', 'void_reason', 'voided_by_name', 'voided_at', 'by_name', 'created_at']),
  personal_regulars: SYNC('uid', "Owner's money", ['uid', 'name', 'kind', 'amount', 'frequency', 'next_date', 'lead_days', 'anchor_day', 'member_id', 'business_pct', 'gl_code', 'cost_area', 'paid_by', 'via',
    'receipt_required', 'notes', 'active']),
};
