// Owner's money screens: totals, take money out / business paid for me / put money in (with a business share for
// mixed costs), the list, personal reminders (home rent, groceries) and the settings (one owner or several family members).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, PhotoPicker, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain, Stats, ReasonButton, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { costAreaOptions, OFFICE } from '../../../services/costAreas.js';
import * as D from '../service.js';

const { $ } = D;
const two = { flexDirection: 'row', gap: 10, flexWrap: 'wrap' };
const half = { flexBasis: 170, flexGrow: 1 };
const ICON = { take_out: '💸', paid_for_me: '🛒', put_in: '💰' };

export function OwnerMoneyScreen() {
  const { nav, can } = useApp();
  const [from, to, setRange] = usePeriod('thismonth', 'own-period');
  const s = D.drawingsSummary({ from, to });
  const recent = D.listMoves({ limit: 8 });
  return (
    <Screen title="Owner's money" subtitle="Drawings and money put in – never through payroll">
      <Explain>Money the owner or family takes from the business is "drawings": it is not wages, so it never goes through payroll (no PAYE, no FNPF). Personal costs the business pays (home rent, groceries) are drawings too. A cost used for both home and business can have a business share % – only that part is a business cost.</Explain>
      <PeriodPicker from={from} to={to} onChange={(a, b) => setRange(a, b)} testID="own-period" />
      <Stats items={[
        { label: 'Taken out', value: $(s.takenOut), color: C.warn },
        { label: 'Business paid for me', value: $(s.paidForMe), color: C.warn },
        { label: 'Put in', value: $(s.putIn), color: C.success },
        { label: 'Net drawings', value: $(s.net), testID: 'own-net' },
      ]} />
      <View style={two}>
        <Btn testID="own-take" title="Take money out" icon="💸" size="md" variant="warn" style={{ flexGrow: 1 }} onPress={() => nav.push('OwnerMoveEdit', { kind: 'take_out' })} />
        <Btn testID="own-paid" title="Business paid for me" icon="🛒" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('OwnerMoveEdit', { kind: 'paid_for_me' })} />
        <Btn testID="own-in" title="Put money in" icon="💰" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('OwnerMoveEdit', { kind: 'put_in' })} />
      </View>
      {s.byMember.length > 1 ? (
        <Section title="Per person">
          {s.byMember.map((p) => <ListItem key={p.id} title={p.name} sub={`Out ${$(p.takenOut)} · paid for ${$(p.paidForMe)} · in ${$(p.putIn)}`} right={$(p.net)} rightSub="net drawings" onPress={() => nav.push('OwnerMoves', { memberId: p.id })} />)}
        </Section>
      ) : null}
      <Section title="Latest">
        {!recent.length ? <Hint>Nothing recorded yet.</Hint> : null}
        {recent.map((m) => <ListItem key={m.uid} title={`${ICON[m.kind]} ${D.KINDS[m.kind]}`} sub={`${m.move_date} · ${m.member_name}${m.what ? ` · ${m.what}` : ''}`} right={$(m.amount)} onPress={() => nav.push('OwnerMove', { uid: m.uid })} />)}
        <Btn title="All records" size="md" variant="ghost" onPress={() => nav.push('OwnerMoves', {})} />
      </Section>
      <Btn testID="own-reminders" title="Home rent & groceries reminders" icon="🏠" size="md" variant="secondary" onPress={() => nav.push('PersonalReminders', {})} />
      {can('drawings_setup') ? <Btn title="Settings (one owner or family members)" icon="⚙️" size="md" variant="ghost" onPress={() => nav.push('DrawingsSettings', {})} /> : null}
    </Screen>
  );
}

// The business share part of a form (mixed costs).
function ShareFields({ f, set, s }) {
  return (
    <Card>
      <H>Business share</H>
      <Field testID="om-pct" label="Business share % (0 = all personal)" value={f.businessPct} onChangeText={set('businessPct')} keyboardType="decimal-pad" />
      <Hint>{D.SHARE_HINT}</Hint>
      {Number(f.businessPct) > 0 ? (
        <>
          <Select testID="om-account" label="Business part was for" value={f.glCode} onChange={set('glCode')} options={D.costAccounts()} search />
          <Label>Cost area</Label>
          <Chips value={f.costArea} onChange={set('costArea')} testIDPrefix="om-area" options={costAreaOptions()} />
          <Chips value={f.claimVat} onChange={set('claimVat')} testIDPrefix="om-vat" options={[{ value: false, label: 'No VAT to claim' }, { value: true, label: 'Claim VAT (tax invoice)' }]} />
          {f.claimVat ? (
            <View style={two}>
              <View style={half}><Field testID="om-tin" label="Supplier TIN" value={f.tin} onChangeText={set('tin')} keyboardType="number-pad" /></View>
              <View style={half}><Field label="Invoice number" value={f.invoiceNo} onChangeText={set('invoiceNo')} /></View>
            </View>
          ) : null}
        </>
      ) : null}
      {s ? <Text testID="om-split" style={{ fontSize: 15, color: C.text }}>Business part {$(s.business)}{s.vat ? ` (VAT ${$(s.vat)} claimed)` : ''} · personal part {$(s.personal)}</Text> : null}
    </Card>
  );
}

export function OwnerMoveEditScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const members = D.memberOptions();
  const vias = D.viaOptions();
  const [f, setF] = useState(() => ({
    kind: D.KINDS[params.kind] ? params.kind : 'take_out', how: 'money', date: dateStr(), amount: '', memberId: members.length === 1 ? members[0].value : '', via: vias.length ? vias[0].value : '', what: params.what || '',
    businessPct: params.kind === 'put_in' ? '100' : '0', glCode: D.drawingsRules().costAccount, costArea: OFFICE, claimVat: false, tin: '', supplier: '', invoiceNo: '', photos: [],
  }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const mixed = f.kind === 'paid_for_me' || (f.kind === 'put_in' && f.how === 'paid_bill');
  const s = mixed && Number(f.amount) > 0 ? D.split({ total: f.amount, businessPct: f.businessPct, claimVat: f.claimVat && !!f.tin }) : null;
  const save = () => { const m = act(() => D.saveMove(user, f), 'Saved'); if (m) nav.replace('OwnerMove', { uid: m.uid }); };
  return (
    <Screen title={D.KINDS[f.kind]} subtitle="Owner's money – not payroll" footer={<Btn testID="om-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Chips value={f.kind} onChange={set('kind')} testIDPrefix="om-kind" options={Object.entries(D.KINDS).map(([value, label]) => ({ value, label }))} />
      {f.kind === 'put_in' ? <Chips value={f.how} onChange={set('how')} testIDPrefix="om-how" options={Object.entries(D.PUT_IN_HOW).map(([value, label]) => ({ value, label }))} /> : null}
      <Card>
        {members.length > 1 ? <Choice label="For whom" value={f.memberId} onChange={set('memberId')} testIDPrefix="om-who" options={members} /> : <Row label="For" value={members.length ? members[0].label : 'Set up the owners in the settings'} />}
        <DateField testID="om-date" label="Date" value={f.date} onChange={set('date')} />
        <MoneyField testID="om-amount" label={mixed ? 'Total paid (incl. VAT)' : 'Amount'} value={f.amount} onChange={set('amount')} />
        {f.kind === 'paid_for_me' || f.how === 'paid_bill' ? <Field testID="om-what" label="What for" value={f.what} onChangeText={set('what')} placeholder="e.g. Home rent, groceries, phone bill" /> : <Field label="Note (optional)" value={f.what} onChangeText={set('what')} />}
        {!(f.kind === 'put_in' && f.how === 'paid_bill') ? (
          <Select testID="om-via" label={f.kind === 'put_in' ? 'Money went into' : 'Paid from'} value={f.via} onChange={set('via')} options={vias} />
        ) : <Hint>You paid it from your own pocket: the business part is money you put in.</Hint>}
        {mixed ? <Field label="Shop / supplier (optional)" value={f.supplier} onChangeText={set('supplier')} /> : null}
      </Card>
      {mixed ? <ShareFields f={f} set={set} s={s} /> : null}
      <PhotoPicker testID="om-photo" label="Receipt" value={f.photos} onChange={set('photos')} required={f.kind === 'paid_for_me'} />
    </Screen>
  );
}

export function OwnerMoveScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [photos, setPhotos] = useState([]);
  const m = params.uid ? D.getMove(params.uid) : null;
  if (!m) return <Screen title="Owner's money"><Banner tone="warn" message="Not found." /><Btn title="All records" onPress={() => nav.replace('OwnerMoves', {})} /></Screen>;
  return (
    <Screen title={`${ICON[m.kind]} ${D.KINDS[m.kind]}`} subtitle={`${m.move_date} · ${m.member_name}`}>
      {m.status === 'void' ? <Banner tone="warn" message={`Put aside by ${m.voided_by_name || ''}: ${m.void_reason || ''}`} /> : null}
      <Card>
        <Row label="Amount" value={$(m.amount)} bold />
        {m.what ? <Row label="For" value={m.what} /> : null}
        <Row label="From / to" value={D.viaLabel(m.via)} />
        {m.business_amount ? <Row label="Business part" value={`${$(m.business_amount)} (${m.business_pct}%) · ${D.costAreaLabel(m.cost_area)}${m.vat ? ` · VAT ${$(m.vat)}` : ''}`} /> : null}
        {m.personal_amount ? <Row label="Drawings (personal part)" value={$(m.personal_amount)} /> : null}
        <Row label="Receipt photos" value={String(m.photos.length)} color={m.photos.length || m.kind !== 'paid_for_me' ? undefined : C.danger} />
        <Row label="Recorded by" value={m.by_name} />
      </Card>
      {m.status === 'active' ? (
        <>
          <PhotoPicker testID="omv-photo" label="Add a receipt photo" value={photos} onChange={setPhotos} />
          {photos.length ? <Btn testID="omv-photo-save" title="Save the photo" variant="success" size="md" onPress={() => { if (act(() => D.addMovePhotos(user, m.uid, photos), 'Saved')) setPhotos([]); }} /> : null}
          <ReasonButton testID="omv-void" title="Put aside (wrong)" prompt="Why is it wrong? (it is kept, and taken out of the books)" confirm="Put aside" onDo={(w) => act(() => D.voidMove(user, m.uid, w), 'Put aside')} />
        </>
      ) : null}
    </Screen>
  );
}

export function OwnerMovesScreen({ params = {} }) {
  const { nav } = useApp();
  const [from, to, setRange] = usePeriod('thisyear', 'own-list-period');
  const [who, setWho] = useRemembered('who', params.memberId || '');
  const [kind, setKind] = useRemembered('kind', '');
  const list = D.listMoves({ from, to, memberId: who || undefined, kind: kind || undefined, includeVoid: true });
  const members = D.memberOptions({ all: true });
  return (
    <Screen title="Owner's money records" subtitle={`${list.length}`}>
      <PeriodPicker from={from} to={to} onChange={(a, b) => setRange(a, b)} />
      {members.length > 1 ? <Choice label="Who" value={who} onChange={setWho} options={[{ value: '', label: 'Everyone' }].concat(members)} /> : null}
      <Chips value={kind} onChange={setKind} options={[{ value: '', label: 'All' }].concat(Object.entries(D.KINDS).map(([value, label]) => ({ value, label })))} />
      {list.map((m) => (
        <ListItem key={m.uid} testID={`om-${m.uid}`} title={`${ICON[m.kind]} ${D.KINDS[m.kind]}`} sub={`${m.move_date} · ${m.member_name}${m.what ? ` · ${m.what}` : ''}${m.business_amount ? ` · business ${$(m.business_amount)}` : ''}${m.status === 'void' ? ' · put aside' : ''}`}
          right={$(m.amount)} badge={m.kind === 'paid_for_me' && !m.photos.length && m.status === 'active' ? 'NO RECEIPT' : null} badgeColor={C.warn} onPress={() => nav.push('OwnerMove', { uid: m.uid })} />
      ))}
      {!list.length ? <Hint>Nothing in this period.</Hint> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- personal reminders
export function PersonalRemindersScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const [edit, setEdit] = useState(null);
  const [done, setDone] = useState(null);
  const list = D.listPersonal({ includeInactive: true });
  const due = new Set(D.personalDue().map((p) => p.uid));
  const members = D.memberOptions();
  const vias = D.viaOptions();
  const startEdit = (p, kind) => setEdit(p ? {
    uid: p.uid, name: p.name, kind: p.kind, amount: p.amount == null ? '' : String(p.amount), frequency: p.frequency, nextDate: p.next_date, leadDays: String(p.lead_days), memberId: p.member_id, businessPct: String(p.business_pct || 0),
    glCode: p.gl_code || D.drawingsRules().costAccount, costArea: p.cost_area || OFFICE, paidBy: p.paid_by, via: p.via || '', receiptRequired: !!p.receipt_required, notes: p.notes || '', active: !!p.active,
  } : { name: D.PERSONAL_KINDS[kind] || '', kind: kind || 'other', amount: '', frequency: kind === 'groceries' ? 'weekly' : 'monthly', nextDate: dateStr(), leadDays: kind === 'groceries' ? '1' : '3', memberId: members.length ? members[0].value : '',
    businessPct: '0', glCode: D.drawingsRules().costAccount, costArea: OFFICE, paidBy: 'business', via: vias.length ? vias[0].value : '', receiptRequired: true, notes: '', active: true });
  const se = (k) => (v) => setEdit((o) => ({ ...o, [k]: v }));
  const sd = (k) => (v) => setDone((o) => ({ ...o, [k]: v }));
  return (
    <Screen title="Home rent & groceries" subtitle="Personal reminders – not business costs">
      <Hint>These are personal. When the business pays them they count as drawings ("Business paid for me"), never as business costs – unless you set a business share % agreed with your accountant.</Hint>
      {!list.length ? (
        <View style={two}>
          <Btn testID="pr-add-rent" title="Add home rent" icon="🏠" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => startEdit(null, 'home_rent')} />
          <Btn testID="pr-add-groc" title="Add grocery shopping" icon="🛒" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => startEdit(null, 'groceries')} />
        </View>
      ) : <Btn testID="pr-add" title="Add a reminder" icon="➕" size="md" variant="secondary" onPress={() => startEdit(null, 'other')} />}
      {edit ? (
        <Card>
          <Choice label="Kind" value={edit.kind} onChange={se('kind')} options={Object.entries(D.PERSONAL_KINDS).map(([value, label]) => ({ value, label }))} testIDPrefix="pr-kind" />
          <Field testID="pr-name" label="Name" value={edit.name} onChangeText={se('name')} />
          <MoneyField testID="pr-amount" label="Usual amount (optional)" value={edit.amount} onChange={se('amount')} />
          <Choice label="How often" value={edit.frequency} onChange={se('frequency')} options={Object.entries(D.FREQ_LABEL).map(([value, label]) => ({ value, label }))} testIDPrefix="pr-freq" />
          <DateField testID="pr-next" label="Next date" value={edit.nextDate} onChange={se('nextDate')} />
          <Field label="Remind … days before" value={edit.leadDays} onChangeText={se('leadDays')} keyboardType="number-pad" />
          {members.length > 1 ? <Choice label="For whom" value={edit.memberId} onChange={se('memberId')} options={members} /> : null}
          <Label>Usually paid by</Label>
          <Chips value={edit.paidBy} onChange={se('paidBy')} testIDPrefix="pr-by" options={[{ value: 'business', label: 'The business (drawings)' }, { value: 'own', label: 'Our own money' }]} />
          {edit.paidBy === 'business' ? <Select label="Paid from" value={edit.via} onChange={se('via')} options={vias} /> : null}
          <Field testID="pr-pct" label="Business share % (usually 0)" value={edit.businessPct} onChangeText={se('businessPct')} keyboardType="decimal-pad" />
          {Number(edit.businessPct) > 0 ? <Hint>{D.SHARE_HINT}</Hint> : null}
          <Chips value={edit.active} onChange={se('active')} options={[{ value: true, label: 'Active' }, { value: false, label: 'Stopped' }]} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(null)} />
            <Btn testID="pr-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => D.savePersonal(user, edit), 'Saved')) setEdit(null); }} />
          </View>
        </Card>
      ) : null}
      {list.map((p) => (
        <View key={p.uid} style={{ gap: 6 }}>
          <ListItem testID={`pr-${p.kind}`} title={p.name} tone={due.has(p.uid) ? 'warn' : undefined}
            sub={`${(D.FREQ_LABEL[p.frequency] || '').toLowerCase()} · next ${p.next_date} · ${p.paid_by === 'business' ? 'paid by the business' : 'own money'}${Number(p.business_pct) ? ` · ${p.business_pct}% business` : ''}${p.active ? '' : ' · stopped'}`}
            right={p.amount ? $(p.amount) : ''} badge={due.has(p.uid) ? 'DUE' : null} badgeColor={C.warn} onPress={can('drawings') ? () => startEdit(p) : undefined} />
          {p.active ? (
            <View style={two}>
              <Btn testID={`pr-done-${p.kind}`} title="Done / paid" size="sm" variant="success" style={{ flexGrow: 1 }} onPress={() => setDone({ uid: p.uid, date: dateStr(), amount: p.amount == null ? '' : String(p.amount), paidBy: p.paid_by, via: p.via || (vias[0] || {}).value || '', photos: [], receipt: !!p.receipt_required })} />
              <Btn title="Skip this time" size="sm" variant="ghost" style={{ flexGrow: 1 }} onPress={() => act(() => D.skipPersonal(user, p.uid), 'Skipped')} />
            </View>
          ) : null}
          {done && done.uid === p.uid ? (
            <Card>
              <DateField label="Date" value={done.date} onChange={sd('date')} />
              <MoneyField testID="prd-amount" label="Amount paid" value={done.amount} onChange={sd('amount')} />
              <Chips value={done.paidBy} onChange={sd('paidBy')} testIDPrefix="prd-by" options={[{ value: 'business', label: 'Paid by the business' }, { value: 'own', label: 'Paid with our own money' }]} />
              {done.paidBy === 'business' ? <Select label="Paid from" value={done.via} onChange={sd('via')} options={vias} /> : null}
              {done.paidBy === 'business' || Number(p.business_pct) > 0 ? <PhotoPicker testID="prd-photo" label="Receipt" value={done.photos} onChange={sd('photos')} required={done.receipt && done.paidBy === 'business'} /> : null}
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setDone(null)} />
                <Btn testID="prd-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => D.markPersonalDone(user, p.uid, done), 'Done')) setDone(null); }} />
              </View>
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings
export function DrawingsSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = D.drawingsRules();
  const [f, setF] = useState({ perMember: r0.perMember, ownerLabel: r0.ownerLabel, costAccount: r0.costAccount, members: r0.members.map((m) => ({ ...m })) });
  const [name, setName] = useState('');
  return (
    <Screen title="Owner's money settings" footer={<Btn testID="ds-save" title="Save" icon="💾" variant="success" onPress={() => act(() => D.saveDrawingsRules(user, f), 'Saved')} />}>
      <Label>Keep owner's money</Label>
      <Chips value={f.perMember} onChange={(v) => setF({ ...f, perMember: v })} testIDPrefix="ds-per" options={[{ value: false, label: 'For the owner(s) together' }, { value: true, label: 'Per family member' }]} />
      {!f.perMember ? <Field label="Name shown" value={f.ownerLabel} onChangeText={(v) => setF({ ...f, ownerLabel: v })} /> : (
        <Card>
          <H>Owners and family members</H>
          {f.members.map((m, i) => (
            <View key={m.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 16, color: m.active ? C.text : C.sub }}>{m.name}{m.active ? '' : ' (not used)'}</Text>
              <Btn title={m.active ? 'Stop using' : 'Use again'} size="sm" variant="ghost" onPress={() => setF({ ...f, members: f.members.map((x, k) => (k === i ? { ...x, active: !x.active } : x)) })} />
            </View>
          ))}
          <View style={two}>
            <View style={{ flexGrow: 1, flexBasis: 200 }}><Field testID="ds-name" label="Add a person" value={name} onChangeText={setName} /></View>
            <Btn testID="ds-add" title="Add" size="md" variant="info" onPress={() => { if (name.trim()) { setF({ ...f, members: f.members.concat([{ id: `M${Date.now().toString(36)}`, name: name.trim(), active: true }]) }); setName(''); } }} />
          </View>
          <Hint>People are never removed (their records stay); stop using them instead.</Hint>
        </Card>
      )}
      <Select label="Usual account for the business part of mixed costs" value={f.costAccount} onChange={(v) => setF({ ...f, costAccount: v })} options={D.costAccounts()} search />
      <Hint>Owners and family who work in the business but take no wages are not in payroll; their money is recorded here.</Hint>
    </Screen>
  );
}
