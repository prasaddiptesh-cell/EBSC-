// Owner's money (v3.5): "Take money out", "Business paid for me", "Put money in", per owner or per family member
// (admin setting). Mixed costs have a business share %: the business part is a business cost (with VAT claimed where
// allowed); the personal part is drawings (paid by the business) or simply not the business's (paid privately).
// Never through payroll. Each record is booked in the accounts as a journal; cash taken from / put into a shop is also
// a cash record at that shop so the cash on hand stays right. Personal regular payments (home rent, household
// groceries) are reminders; they never become a business cost unless a business share is set.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { r2, $, apRules, standardVat } from '../payables/service.js';
import { nextDate, FREQ_LABEL } from '../payables/recurring.js';
import { OFFICE, CLOSED, costAreaLabel } from '../../services/costAreas.js';
import { periodRange } from '../../services/dates.js';
import { addPhotos } from '../../services/stock.js';
import { needReason, requireSetup } from '../../services/access.js';
import { assertOpen } from '../../services/lock.js';
import * as A from '../accounting/service.js';

export { $, r2, FREQ_LABEL };
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const D = (code, amount, shop) => ({ code, debit: r2(amount), credit: 0, shop: shop || OFFICE });
const C = (code, amount, shop) => ({ code, debit: 0, credit: r2(amount), shop: shop || OFFICE });

export const KINDS = { take_out: 'Take money out', paid_for_me: 'Business paid for me', put_in: 'Put money in' };
export const PUT_IN_HOW = { money: 'Money into the business (cash or bank)', paid_bill: 'I paid a business cost myself' };
export const PERSONAL_KINDS = { home_rent: 'Home rent', groceries: 'Household grocery shopping', other: 'Other personal payment' };
export const SHARE_HINT = 'Agree the business share % with your accountant (e.g. a phone or car used for both). Only the business part is a business cost and only its VAT can be claimed.';

// ---------------------------------------------------------------- settings: one owner, or several family members
export const OWNER_ID = 'owner';
export const DRAWINGS_DEFAULTS = { perMember: false, members: [], ownerLabel: 'Owner', costAccount: '6990' };
export function drawingsRules() {
  const s = { ...DRAWINGS_DEFAULTS, ...(getShared('drawings_rules', {}) || {}) };
  s.members = Array.isArray(s.members) ? s.members : [];
  return s;
}
export function saveDrawingsRules(user, r) {
  requireSetup(user, 'drawings_setup');
  const members = (Array.isArray(r.members) ? r.members : []).map((m, i) => ({ id: txt(m.id) || `M${Date.now().toString(36)}${i}`, name: txt(m.name), active: m.active !== false })).filter((m) => m.name);
  const names = members.map((m) => m.name.toLowerCase());
  need(new Set(names).size === names.length, 'Two people have the same name.');
  if (r.perMember) need(members.some((m) => m.active), 'Add at least one owner or family member.');
  const clean = { perMember: !!r.perMember, members, ownerLabel: txt(r.ownerLabel) || 'Owner', costAccount: txt(r.costAccount) || '6990' };
  const before = drawingsRules();
  setShared('drawings_rules', clean);
  audit({ user, action: "Changed the owner's money settings", table: 'shared_settings', recordUid: 'drawings_rules', before, after: clean });
  return clean;
}
// Who money can be for: every active family member (when set per member), otherwise the owner(s) as one.
export function memberOptions({ all = false } = {}) {
  const s = drawingsRules();
  if (!s.perMember) return [{ value: OWNER_ID, label: s.ownerLabel }];
  return s.members.filter((m) => all || m.active).map((m) => ({ value: m.id, label: m.name }));
}
function memberName(id) {
  const s = drawingsRules();
  if (!id || id === OWNER_ID) return s.ownerLabel;
  const m = s.members.find((x) => x.id === id);
  return m ? m.name : id;
}

// Where the money came from / went to: a shop's cash ('cash:S1'), a bank account ('bank:<uid>').
export function viaOptions() {
  const shops = db().all("SELECT code, name FROM shops WHERE active = 1 AND code LIKE 'S%' ORDER BY sort, code");
  const banks = has('bank_accounts') ? db().all('SELECT uid, name FROM bank_accounts WHERE active = 1 ORDER BY name') : [];
  return shops.map((s) => ({ value: `cash:${s.code}`, label: `Cash – ${s.name}` })).concat(banks.map((b) => ({ value: `bank:${b.uid}`, label: `Bank – ${b.name}` })));
}
function viaCode(via) {
  const v = txt(via);
  if (v.startsWith('cash:') && v.length > 5) return { code: '1000', shop: v.slice(5), cash: v.slice(5) };
  if (v.startsWith('bank:') && v.length > 5) return { code: `1100:${v.slice(5)}`, shop: OFFICE };
  throw new AppError('Choose where the money came from or went to (a shop\'s cash or the bank).');
}
export function viaLabel(via) { const o = viaOptions().find((x) => x.value === via); return o ? o.label : via === 'personal' ? 'Own pocket' : via || ''; }
// Business cost accounts for the business part of a mixed cost.
export function costAccounts() {
  return A.listAccountsGL().filter((a) => ['expense', 'cogs'].includes(a.type)).map((a) => ({ value: a.code, label: `${a.code} ${a.name}` }));
}

// ---------------------------------------------------------------- work out the split
// total incl. VAT, the business share %, and whether the VAT on the business part may be claimed
// (the supplier is VAT-registered and the invoice is a tax invoice).
export function split({ total, businessPct = 0, claimVat = false, vat }) {
  const t = r2(total);
  const pct = Math.min(100, Math.max(0, Number(businessPct) || 0));
  const business = r2((t * pct) / 100);
  const rate = Number(apRules().vatRate) || 12.5;
  let v = 0;
  if (claimVat && business > 0) v = vat === undefined || vat === '' || vat === null ? standardVat(business, rate) : r2((Number(vat) * pct) / 100);
  return { total: t, pct, business, vat: r2(v), businessExVat: r2(business - v), personal: r2(t - business) };
}

// ---------------------------------------------------------------- record one
export function saveMove(user, f) {
  const kind = f.kind;
  need(KINDS[kind], 'Choose: take money out, business paid for me, or put money in.');
  const date = txt(f.date) || dateStr();
  need(DATE.test(date), 'Enter the date.');
  assertOpen(date, "This owner's money record");
  const total = r2(f.amount);
  need(total > 0, 'Enter the amount.');
  const memberId = txt(f.memberId) || (drawingsRules().perMember ? '' : OWNER_ID);
  need(memberOptions({ all: true }).some((m) => m.value === memberId), 'Choose who it is for.');
  const how = kind === 'put_in' ? (f.how === 'paid_bill' ? 'paid_bill' : 'money') : null;
  const mixed = kind === 'paid_for_me' || how === 'paid_bill';
  const s = mixed ? split({ total, businessPct: kind === 'put_in' ? (f.businessPct === undefined || f.businessPct === '' ? 100 : f.businessPct) : f.businessPct, claimVat: !!f.claimVat && !!txt(f.tin), vat: f.vat })
    : { total, pct: 0, business: 0, vat: 0, businessExVat: 0, personal: total };
  if (mixed && f.claimVat) need(txt(f.tin), 'VAT can only be claimed with the supplier\'s TIN (a tax invoice). Type the TIN, or untick "claim VAT".');
  if (how === 'paid_bill') need(s.business > 0, 'Enter the business share % of the cost you paid.');
  const area = txt(f.costArea) || OFFICE;
  const gl = txt(f.glCode) || drawingsRules().costAccount;
  if (s.business > 0) need(A.listAccountsGL({ includeInactive: true }).some((a) => a.code === gl), 'Choose what the business part was for (the account).');
  const what = txt(f.what);
  if (kind === 'paid_for_me') need(what, 'Say what the business paid for (e.g. home rent, groceries).');
  const via = how === 'paid_bill' ? 'personal' : txt(f.via);
  const src = how === 'paid_bill' ? null : viaCode(via);
  const uid = uuid('OM');
  const who = memberName(memberId);
  // The journal: drawings (3100) for the personal part; the business part to its cost account (and VAT).
  let lines; let jkind = 'owner'; let jmeta = null;
  if (kind === 'take_out') lines = [D('3100', total), C(src.code, total, src.shop)];
  else if (kind === 'put_in' && how === 'money') lines = [D(src.code, total, src.shop), C('3100', total)];
  else {
    const credit = how === 'paid_bill' ? C('3100', s.business) : C(src.code, total, src.shop);
    lines = [D(gl, s.businessExVat, area), D('2200', s.vat, area), D('3100', how === 'paid_bill' ? 0 : s.personal), credit].filter((l) => l.debit || l.credit);
    if (s.business > 0) { jkind = 'expense'; jmeta = { total: s.business, vat: s.vat, zero: 0, shop: area, supplier: txt(f.supplier) || what || null, tin: txt(f.tin) || null, no: txt(f.invoiceNo) || null, owner: uid }; }
  }
  const memo = `${KINDS[kind]}${how === 'paid_bill' ? ' (paid a business cost)' : ''} – ${who}${what ? `: ${what}` : ''}`;
  const photos = f.photos || [];
  const now = stamp();
  db().transaction(() => {
    const jUid = A.saveJournal(user, { date, memo, lines, kind: jkind, meta: jmeta || { owner: uid, member: who }, refUid: uid });
    let cashUid = null;
    if (src && src.cash && has('cash_moves')) {
      // The shop's cash on hand changes too (booked in the accounts by the journal above, not again).
      cashUid = uuid('CM');
      const out = kind !== 'put_in';
      db().run(`INSERT INTO cash_moves (uid, shop_code, move_date, type, amount, ref_uid, category, note, photo_urls, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,'[]',?,?,?,?)`,
        [cashUid, src.cash, date, out ? 'adjust_out' : 'adjust_in', total, uid, "Owner's money", `${memo}`, user.name, user.uid || null, now, deviceId()]);
    }
    db().run(`INSERT INTO owner_moves (uid, move_date, kind, member_id, member_name, amount, business_pct, business_amount, vat, personal_amount, via, cost_area, gl_code, what, supplier, tin, invoice_no, photo_urls,
      journal_uid, cash_uid, reminder_uid, status, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?,?)`,
    [uid, date, kind, memberId, who, total, s.pct, s.business, s.vat, how === 'paid_bill' ? 0 : s.personal, via, s.business > 0 ? area : null, s.business > 0 ? gl : null, what || (how === 'paid_bill' ? 'Business cost paid privately' : null),
      txt(f.supplier) || null, txt(f.tin) || null, txt(f.invoiceNo) || null, JSON.stringify(photos), jUid, cashUid, txt(f.reminderUid) || null, user.name, now, now, deviceId()]);
  });
  if (photos.length) addPhotos('owner', uid, photos);
  audit({ user, action: `${memo} ${$(total)}${s.business > 0 ? ` (business part ${$(s.business)})` : ''}`, table: 'owner_moves', recordUid: uid, after: { kind, total, split: s, via } });
  return getMove(uid);
}
export function getMove(uid) {
  const m = db().get('SELECT * FROM owner_moves WHERE uid = ?', [uid]);
  return m ? { ...m, photos: J(m.photo_urls, []) } : null;
}
export function listMoves({ from, to, memberId, kind, includeVoid = false, limit = 500 } = {}) {
  return db().all(`SELECT * FROM owner_moves WHERE (? IS NULL OR move_date >= ?) AND (? IS NULL OR move_date <= ?) AND (? IS NULL OR member_id = ?) AND (? IS NULL OR kind = ?) ${includeVoid ? '' : "AND status = 'active'"}
    ORDER BY move_date DESC, created_at DESC LIMIT ?`, [from || null, from || null, to || null, to || null, memberId || null, memberId || null, kind || null, kind || null, limit]).map((m) => ({ ...m, photos: J(m.photo_urls, []) }));
}
export function addMovePhotos(user, uid, photos) {
  const m = getMove(uid);
  need(m, 'Not found.');
  need((photos || []).length, 'Take a photo first.');
  db().run(`UPDATE owner_moves SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(m.photos.concat(photos)), stamp(), deviceId(), uid]);
  addPhotos('owner', uid, photos);
  audit({ user, action: 'Added a receipt photo to an owner\'s money record', table: 'owner_moves', recordUid: uid });
}
// Wrong? Put it aside: the journal and the shop cash record are put aside too. Nothing is deleted.
export function voidMove(user, uid, reason) {
  const m = getMove(uid);
  need(m && m.status === 'active', 'Not found.');
  assertOpen(m.move_date, "This owner's money record");
  needReason(user, reason, 'Say why it is wrong.');
  const now = stamp();
  db().transaction(() => {
    if (m.journal_uid) {
      const j = db().get('SELECT status FROM gl_journals WHERE uid = ?', [m.journal_uid]);
      if (j && j.status === 'active') A.voidJournal(user, m.journal_uid, txt(reason) || "Owner's money record put aside");
    }
    if (m.cash_uid) db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'active'`, [txt(reason) || 'Put aside', now, deviceId(), m.cash_uid]);
    db().run(`UPDATE owner_moves SET status = 'void', void_reason = ?, voided_by_name = ?, voided_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || null, user.name, now, now, deviceId(), uid]);
  });
  audit({ user, action: `Put aside: ${KINDS[m.kind]} ${$(m.amount)} – ${m.member_name}`, table: 'owner_moves', recordUid: uid, before: m, reason });
}

// ---------------------------------------------------------------- totals (dashboard card, statements)
// period: a period name ('thismonth', 'thisyear' …) or { from, to }.
export function drawingsSummary(period = 'thismonth') {
  const r = typeof period === 'string' ? periodRange(period) || periodRange('thismonth') : period || {};
  const from = r.from || '0000-01-01'; const to = r.to || dateStr();
  const list = listMoves({ from, to, limit: 100000 });
  const per = {};
  const add = (m) => {
    const p = (per[m.member_id || OWNER_ID] = per[m.member_id || OWNER_ID] || { id: m.member_id || OWNER_ID, name: m.member_name || memberName(m.member_id), takenOut: 0, paidForMe: 0, putIn: 0, businessShare: 0, net: 0 });
    if (m.kind === 'take_out') p.takenOut = r2(p.takenOut + m.amount);
    if (m.kind === 'paid_for_me') { p.paidForMe = r2(p.paidForMe + m.personal_amount); p.businessShare = r2(p.businessShare + m.business_amount); }
    if (m.kind === 'put_in') { p.putIn = r2(p.putIn + (m.via === 'personal' ? m.business_amount : m.amount)); p.businessShare = r2(p.businessShare + (m.via === 'personal' ? m.business_amount : 0)); }
    p.net = r2(p.takenOut + p.paidForMe - p.putIn);
  };
  list.forEach(add);
  const byMember = Object.values(per).sort((a, b) => (a.name < b.name ? -1 : 1));
  const sum = (k) => r2(byMember.reduce((s, p) => s + p[k], 0));
  return { from, to, takenOut: sum('takenOut'), paidForMe: sum('paidForMe'), putIn: sum('putIn'), businessShare: sum('businessShare'), drawings: r2(sum('takenOut') + sum('paidForMe')), net: sum('net'), count: list.length, byMember };
}

// ---------------------------------------------------------------- personal regular payments (reminders)
export function listPersonal({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM personal_regulars WHERE (? = 1 OR active = 1) ORDER BY active DESC, next_date`, [includeInactive ? 1 : 0]);
}
export function getPersonal(uid) { return uid ? db().get('SELECT * FROM personal_regulars WHERE uid = ?', [uid]) : null; }
export function savePersonal(user, f) {
  const name = txt(f.name);
  need(name, 'Name it, e.g. "Home rent".');
  const kind = PERSONAL_KINDS[f.kind] ? f.kind : 'other';
  need(FREQ_LABEL[f.frequency], 'Choose how often.');
  need(DATE.test(txt(f.nextDate)), 'Enter the next date.');
  const amount = f.amount === '' || f.amount === undefined || f.amount === null ? null : r2(f.amount);
  need(amount === null || amount >= 0, 'The amount cannot be below zero.');
  const lead = Math.round(Number(f.leadDays === undefined || f.leadDays === '' ? 2 : f.leadDays));
  need(lead >= 0 && lead <= 30, 'Remind between 0 and 30 days before.');
  const pct = Math.min(100, Math.max(0, Number(f.businessPct) || 0));
  const paidBy = f.paidBy === 'own' ? 'own' : 'business';
  const memberId = txt(f.memberId) || (drawingsRules().perMember ? (memberOptions()[0] || {}).value : OWNER_ID) || OWNER_ID;
  const uid = f.uid || uuid('PR');
  const before = getPersonal(uid);
  const anchor = before && before.next_date === f.nextDate && before.anchor_day ? before.anchor_day : Number(String(f.nextDate).slice(8, 10));
  db().run(`INSERT INTO personal_regulars (name, kind, amount, frequency, next_date, lead_days, anchor_day, member_id, business_pct, gl_code, cost_area, paid_by, via, receipt_required, notes, active, updated_at, updated_device, uid)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET name=excluded.name, kind=excluded.kind, amount=excluded.amount, frequency=excluded.frequency, next_date=excluded.next_date,
    lead_days=excluded.lead_days, anchor_day=excluded.anchor_day, member_id=excluded.member_id, business_pct=excluded.business_pct, gl_code=excluded.gl_code, cost_area=excluded.cost_area, paid_by=excluded.paid_by,
    via=excluded.via, receipt_required=excluded.receipt_required, notes=excluded.notes, active=excluded.active, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [name, kind, amount, f.frequency, f.nextDate, lead, anchor, memberId, pct, txt(f.glCode) || null, txt(f.costArea) || null, paidBy, txt(f.via) || null, f.receiptRequired === false ? 0 : 1, txt(f.notes) || null,
    f.active === false ? 0 : 1, stamp(), deviceId(), uid]);
  audit({ user, action: `${before ? 'Changed' : 'Added'} personal reminder ${name}`, table: 'personal_regulars', recordUid: uid, before, after: { amount, freq: f.frequency, next: f.nextDate, pct, paidBy } });
  return getPersonal(uid);
}
// Done: how it was paid. Paid by the business → "Business paid for me" (business share to costs);
// paid privately → nothing in the books, unless there is a business share (then that part is money put in).
export function markPersonalDone(user, uid, { date = dateStr(), amount, paidBy, via, photos = [], tin, supplier, invoiceNo, claimVat } = {}) {
  const p = getPersonal(uid);
  need(p && p.active, 'Not found.');
  const by = paidBy || p.paid_by;
  let move = null;
  const amt = amount === undefined || amount === '' ? p.amount : amount;
  if (by === 'business') {
    need(Number(amt) > 0, 'Enter the amount paid.');
    if (p.receipt_required) need((photos || []).length, 'Take a photo of the receipt (it is required).');
    move = saveMove(user, { kind: 'paid_for_me', date, amount: amt, memberId: p.member_id, businessPct: p.business_pct, glCode: p.gl_code, costArea: p.cost_area, via: via || p.via, what: p.name, photos, tin, supplier, invoiceNo, claimVat, reminderUid: uid });
  } else if (Number(p.business_pct) > 0 && Number(amt) > 0) {
    move = saveMove(user, { kind: 'put_in', how: 'paid_bill', date, amount: amt, memberId: p.member_id, businessPct: p.business_pct, glCode: p.gl_code, costArea: p.cost_area, what: p.name, photos, tin, supplier, invoiceNo, claimVat, reminderUid: uid });
  }
  const next = nextDate(p.next_date, p.frequency, p.anchor_day);
  db().run(`UPDATE personal_regulars SET next_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [next, stamp(), deviceId(), uid]);
  audit({ user, action: `${p.name} done (${by === 'business' ? 'paid by the business' : 'paid privately'}) – next ${next}`, table: 'personal_regulars', recordUid: uid });
  return { next, move };
}
export function skipPersonal(user, uid) {
  const p = getPersonal(uid);
  need(p, 'Not found.');
  const next = nextDate(p.next_date, p.frequency, p.anchor_day);
  db().run(`UPDATE personal_regulars SET next_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [next, stamp(), deviceId(), uid]);
  audit({ user, action: `${p.name} skipped this time – next ${next}`, table: 'personal_regulars', recordUid: uid });
  return next;
}
export function personalDue(today = dateStr()) {
  return listPersonal().filter((p) => addDays(p.next_date, -p.lead_days) <= today).map((p) => ({ ...p, late: p.next_date < today }));
}
// Records paid by the business (not via a reminder or a mixed cost) that still need a receipt photo.
export function movesWithoutPhoto({ days = 90, today = dateStr() } = {}) {
  return listMoves({ from: addDays(today, -days), to: today }).filter((m) => m.kind === 'paid_for_me' && !m.photos.length);
}
export { OFFICE, CLOSED, costAreaLabel };
