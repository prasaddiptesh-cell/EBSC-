// v3.9.5 one area of the business (Sales & tills, Stock & orders, People & pay…).
// v3.9.7 a tidy list of drop-downs: each part of the area (Timesheets, Leave, Payroll… or Daily jobs / Records &
// checks) opens and closes with one tap; every option is listed once (nothing that Home already shows); Reports and
// Settings for the area at the bottom.
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Btn, useApp, useRemembered } from '../../ui/components.js';
import { tutorialsForModule } from '../../services/tutorials.js';
import { startTutorial } from '../../ui/TutorialBar.js';
import { C } from '../../ui/theme.js';
import { Hint } from '../../ui/kit.js';
import { getArea, areaView, homeDailyScreens } from '../../services/areas.js';
import { getModule, allScreens } from '../registry.js';
import { can } from '../../services/access.js';

// One option in a drop-down (all the same size; title and a short line under it).
function Option({ it, onPress, last }) {
  return (
    <Pressable testID={it.testID} onPress={onPress}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11, paddingHorizontal: 14, backgroundColor: pressed ? '#F6F2EC' : C.card, borderBottomWidth: last ? 0 : 1, borderBottomColor: '#EFE9E1' })}>
      <Text style={{ fontSize: 20, width: 28, textAlign: 'center' }}>{it.icon || '•'}</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }} numberOfLines={1}>{it.title}</Text>
        {it.note ? <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={1}>{it.note}</Text> : null}
      </View>
      <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
    </Pressable>
  );
}

// A drop-down: the header row opens / closes it.
function DropDown({ id, icon, title, count, open, onToggle, children }) {
  return (
    <View style={{ borderRadius: 14, borderWidth: 1, borderColor: open ? C.primary : C.border, backgroundColor: C.card, overflow: 'hidden' }}>
      <Pressable testID={`${id}${open ? '-open' : ''}`} onPress={onToggle} accessibilityRole="button" accessibilityState={{ expanded: open }}
        style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, paddingHorizontal: 14, backgroundColor: open ? '#FBF4EE' : pressed ? '#F6F2EC' : C.card })}>
        <Text style={{ fontSize: 22, width: 28, textAlign: 'center' }}>{icon}</Text>
        <Text style={{ flex: 1, fontSize: 18, fontWeight: '800', color: C.text }}>{title}</Text>
        <View style={{ minWidth: 28, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10, backgroundColor: '#EFE9E1', alignItems: 'center' }}>
          <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub }}>{String(count)}</Text>
        </View>
        <Text style={{ fontSize: 18, color: open ? C.primary : C.sub, width: 18, textAlign: 'center' }}>{open ? '▴' : '▾'}</Text>
      </Pressable>
      {open ? <View style={{ borderTopWidth: 1, borderTopColor: C.border }}>{children}</View> : null}
    </View>
  );
}

export default function AreaScreen({ params = {} }) {
  const { nav, realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const area = getArea(params.area);
  const [openList, setOpenList] = useRemembered(`open-${params.area}`, []);
  if (!area) return <Screen title="Not found"><Hint>This area is not in this version of the app.</Hint></Screen>;
  let hide = [];
  try { hide = homeDailyScreens(who, screens); } catch (e) { hide = []; }
  const v = areaView(area, who, screens, getModule, { hide });
  const go = (it) => () => nav.push(it.screen, it.params || {});
  const canReports = can(who, 'reports') && screens.ReportsHub && screens.ReportsHub.can(who);
  const canSettings = v.settings.length > 0 && screens.Admin && screens.Admin.can(who);
  const isOpen = (k) => Array.isArray(openList) && openList.includes(k);
  const toggle = (k) => () => setOpenList((o) => { const l = Array.isArray(o) ? o : []; return l.includes(k) ? l.filter((x) => x !== k) : l.concat([k]); });
  // One part of the business in the area: its jobs, then its records & checks. An area with one part shows its
  // jobs and its records & checks as the two drop-downs.
  const sections = [];
  const blocks = v.blocks.filter((b) => b.daily.length + b.more.length > 0);
  if (blocks.length === 1) {
    const b = blocks[0];
    if (b.daily.length) sections.push({ key: 'daily', id: 'areasec-daily', icon: '⭐', title: 'Daily jobs', items: b.daily });
    if (b.more.length) sections.push({ key: b.module, id: `areamod-${b.module}`, icon: '🗂️', title: 'Records & checks', items: b.more });
  } else {
    for (const b of blocks) sections.push({ key: b.module, id: `areamod-${b.module}`, icon: b.icon, title: b.title, items: b.daily.concat(b.more) });
  }
  // nothing opened yet: the first one is open
  const opened = (k, i) => (Array.isArray(openList) && openList.length ? isOpen(k) : i === 0 && sections.length <= 2);
  return (
    <Screen title={area.title} subtitle={area.note}>
      {v.empty ? <Hint>There is nothing here for your login. Ask the owner if you need it.</Hint> : null}
      {(() => {
        // v3.9.8 "Show me how" for the parts of this area (they were on the old module menus)
        let tuts = [];
        try { tuts = area.modules.flatMap((m) => tutorialsForModule(who, m)); } catch (e) { tuts = []; }
        const seen = new Set();
        tuts = tuts.filter((t) => (seen.has(t.id) ? false : seen.add(t.id)));
        return tuts.length ? <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>{tuts.map((t) => <Btn key={t.id} testID={`show-me-${t.id}`} title={`Show me how: ${t.title}`} icon="🎓" size="sm" variant="secondary" onPress={() => startTutorial(t.id)} />)}</View> : null;
      })()}
      <View style={{ gap: 10 }}>
        {sections.map((s, i) => {
          const open = opened(s.key, i);
          return (
            <DropDown key={s.key} id={s.id} icon={s.icon} title={s.title} count={s.items.length} open={open}
              onToggle={() => setOpenList(() => { const cur = sections.filter((x, j) => opened(x.key, j)).map((x) => x.key); return cur.includes(s.key) ? cur.filter((x) => x !== s.key) : cur.concat([s.key]); })}>
              {s.items.map((it, j) => <Option key={it.testID} it={it} onPress={go(it)} last={j === s.items.length - 1} />)}
            </DropDown>
          );
        })}
      </View>
      {/* Someone without the Reports list still reaches this area's report screens here. */}
      {!canReports && v.reportScreens.length ? (
        <DropDown id="areasec-reports" icon="📊" title="Reports" count={v.reportScreens.length} open={isOpen('reports')} onToggle={toggle('reports')}>
          {v.reportScreens.map((it, j) => <Option key={it.testID} it={it} onPress={go(it)} last={j === v.reportScreens.length - 1} />)}
        </DropDown>
      ) : null}
      {canReports || canSettings ? (
        <View style={{ borderRadius: 14, borderWidth: 1, borderColor: C.border, backgroundColor: C.card, overflow: 'hidden', marginTop: 4 }}>
          {canReports ? <Option it={{ testID: 'area-reports', icon: '📊', title: `Reports: ${area.title}`, note: 'Every report for this area – PDF, Excel, print.' }} onPress={() => nav.push('ReportsHub', { area: area.id })} last={!canSettings} /> : null}
          {canSettings ? <Option it={{ testID: 'area-settings', icon: '⚙️', title: `Settings: ${area.title}`, note: `${v.settings.length} setting${v.settings.length === 1 ? '' : 's'} for this area.` }} onPress={() => nav.push('Admin', { area: area.id })} last /> : null}
        </View>
      ) : null}
    </Screen>
  );
}
