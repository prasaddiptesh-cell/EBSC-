// v3.9.5 one area of the business (Sales & tills, Stock & orders, People & pay…): the daily jobs of its modules first,
// then their records and checks. Reports and settings are one tap away (they live only in Reports and Settings).
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Action, Actions, Hint } from '../../ui/kit.js';
import { getArea, areaView } from '../../services/areas.js';
import { getModule, allScreens } from '../registry.js';
import { can } from '../../services/access.js';

function Small({ it, onPress }) {
  return (
    <Pressable testID={it.testID} onPress={onPress}
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: 230, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, paddingVertical: 10, paddingHorizontal: 12, opacity: pressed ? 0.7 : 1 })}>
      <Text style={{ fontSize: 20 }}>{it.icon || '›'}</Text>
      <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: C.text }} numberOfLines={2}>{it.title}</Text>
      <Text style={{ fontSize: 18, color: C.sub }}>›</Text>
    </Pressable>
  );
}

export default function AreaScreen({ params = {} }) {
  const { nav, realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const area = getArea(params.area);
  if (!area) return <Screen title="Not found"><Hint>This area is not in this version of the app.</Hint></Screen>;
  const v = areaView(area, who, screens, getModule);
  const go = (it) => () => nav.push(it.screen, it.params || {});
  const canReports = can(who, 'reports') && screens.ReportsHub && screens.ReportsHub.can(who);
  const canSettings = v.settings.length > 0 && screens.Admin && screens.Admin.can(who);
  return (
    <Screen title={area.title} subtitle={area.note}>
      {v.empty ? <Hint>There is nothing here for your login. Ask the owner if you need it.</Hint> : null}
      {v.blocks.map((b) => (
        <Section key={b.module} title={v.blocks.length > 1 ? `${b.icon} ${b.title}` : 'Daily jobs'}
          right={getModule(b.module) && getModule(b.module).menu ? (
            <Pressable testID={`areamod-${b.module}`} onPress={() => nav.push('ModuleMenu', { module: b.module })} style={({ pressed }) => ({ paddingVertical: 4, paddingHorizontal: 8, opacity: pressed ? 0.6 : 1 })}>
              <Text style={{ fontSize: 15, fontWeight: '700', color: C.info }}>{`All of ${b.title} ›`}</Text>
            </Pressable>
          ) : null}>
          {b.daily.length ? <Actions>{b.daily.map((it) => <Action key={it.testID} testID={it.testID} icon={it.icon || '›'} title={it.title} note={it.note} onPress={go(it)} />)}</Actions> : null}
          {b.more.length ? (
            <View style={{ gap: 6, marginTop: b.daily.length ? 10 : 0 }}>
              <Text style={{ fontSize: 13, fontWeight: '800', letterSpacing: 0.6, color: C.sub }}>RECORDS & CHECKS</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{b.more.map((it) => <Small key={it.testID} it={it} onPress={go(it)} />)}</View>
            </View>
          ) : null}
        </Section>
      ))}
      {/* Someone without the Reports list still reaches this area's report screens here. */}
      {!canReports && v.reportScreens.length ? (
        <Section title="Reports">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{v.reportScreens.map((it) => <Small key={it.testID} it={it} onPress={go(it)} />)}</View>
        </Section>
      ) : null}
      {canReports || canSettings ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4 }}>
          {canReports ? <Action testID="area-reports" icon="📊" title={`Reports: ${area.title}`} note="Every report for this area – PDF, Excel, print." onPress={() => nav.push('ReportsHub', { area: area.id })} /> : null}
          {canSettings ? <Action testID="area-settings" icon="⚙️" title={`Settings: ${area.title}`} note={`${v.settings.length} setting${v.settings.length === 1 ? '' : 's'} for this area.`} onPress={() => nav.push('Admin', { area: area.id })} /> : null}
        </View>
      ) : null}
    </Screen>
  );
}
