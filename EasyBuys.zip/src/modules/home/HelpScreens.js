// v3.9.2 Help: every job step by step (search, by area), a guide page with "Open the screen" and "Show me how".
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, H, Btn, Field, Section, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { ListItem, Hint } from '../../ui/kit.js';
import * as G from '../../services/guides.js';

export function HelpScreen({ params = {} }) {
  const { nav, screens } = useApp();
  const [q, setQ] = useState(params.q || '');
  const found = q.trim() ? G.searchGuides(q) : null;
  const here = params.screen ? G.guidesForScreen(params.screen) : [];
  const row = (g) => <ListItem key={g.id} testID={`help-${g.id}`} title={g.title} sub={g.when} onPress={() => nav.push('HelpGuide', { id: g.id })} />;
  return (
    <Screen title="Help" subtitle="How to do each job – step by step">
      <Field testID="help-q" label="What do you want to do?" value={q} onChangeText={setQ} placeholder="e.g. deposit, till short, post-dated cheque, VAT" />
      {here.length && !found ? <Section title="For the screen you were on">{here.map(row)}</Section> : null}
      {found ? (
        <Section title={`Found (${found.length})`}>{found.length ? found.map(row) : <Text style={{ fontSize: 16, color: C.sub }}>Nothing found – try other words.</Text>}</Section>
      ) : G.AREAS.map((a) => <Section key={a} title={a}>{G.GUIDES.filter((g) => g.area === a).map(row)}</Section>)}
      {screens && screens.Tutorials ? <Btn testID="help-tutorials" title="Tutorials – practise each job, with a short check" icon="🎓" size="md" variant="secondary" onPress={() => nav.push('Tutorials')} /> : null}
      <Hint>On most screens, the ❓ button at the top opens the guide for that screen.</Hint>
    </Screen>
  );
}

export function HelpGuideScreen({ params = {} }) {
  const { nav, screens, user } = useApp();
  const g = G.getGuide(params.id);
  if (!g) return <Screen title="Help"><Text style={{ fontSize: 16 }}>Guide not found.</Text></Screen>;
  const open = (g.screens || []).filter((s) => screens && screens[s] && (() => { try { return !screens[s].can || screens[s].can(user); } catch (e) { return false; } })());
  return (
    <Screen title={g.title} subtitle={g.area}>
      <Card tone="info"><Text style={{ fontSize: 16, color: C.text }}>When: {g.when}</Text></Card>
      <Card>
        <H>Step by step</H>
        {g.steps.map((s, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 10, marginBottom: 10 }}>
            <Text style={{ fontSize: 18, fontWeight: '900', color: C.primary, width: 26 }}>{i + 1}.</Text>
            <Text testID={`guide-step-${i}`} style={{ fontSize: 17, color: C.text, flex: 1, lineHeight: 24 }}>{s}</Text>
          </View>
        ))}
      </Card>
      {(g.tips || []).length ? <Card><H>Good to know</H>{g.tips.map((t, i) => <Text key={i} style={{ fontSize: 16, color: C.text, marginBottom: 6, lineHeight: 22 }}>💡 {t}</Text>)}</Card> : null}
      {open.length ? open.slice(0, 2).map((s) => <Btn key={s} testID={`guide-open-${s}`} title={`Open: ${s.replace(/([a-z])([A-Z])/g, '$1 $2')}`} icon="➡️" size="md" variant="info" onPress={() => nav.push(s, {})} />) : null}
      {g.tutorial && screens && screens.Tutorials ? <Btn testID="guide-tutorial" title="Show me how (tutorial)" icon="🎓" size="md" variant="secondary" onPress={() => { try { require('../../ui/TutorialBar.js').startTutorial(g.tutorial); } catch (e) { nav.push('Tutorials'); } }} /> : null}
      <Btn title="All guides" size="md" variant="ghost" onPress={() => nav.push('Help', {})} />
    </Screen>
  );
}
