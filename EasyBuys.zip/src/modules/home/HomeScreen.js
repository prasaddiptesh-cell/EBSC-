// 1.0.0 Home – the new simple shell (the map "Try the new app" the owner approved):
//   staff and bakers: 5 big buttons (StaffHome.js) · office: Today / Records / Reports / Settings ·
//   accountant: Books / Downloads / Questions (view only).
// Every old menu item is still reached from here (Records hubs, Reports, Settings) – nothing was removed.
// Speed: everything on Home is worked out at most once a minute or when something is saved (memoMinute).
import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Field, Btn, useApp, useTick, useRemembered, useLayout } from '../../ui/components.js';
import { SyncIcon } from '../../ui/chrome.js';
import { AlertCard } from '../../ui/alertsUI.js';
import { homeAlertsAsync, peekHomeAlerts } from '../../services/alerts.js';
import { writeCount } from '../../db/connection.js';
import { searchAll } from '../../services/search.js';
import { allScreens, menuModules, getModule } from '../registry.js';
import { QuickLinksBar } from './QuickLinksScreen.js';
import StaffHome from './StaffHome.js';
import { C } from '../../ui/theme.js';
import { ROLE_LABEL } from '../../services/access.js';
import { dateStr, getSetting, setSetting, getShared, stamp } from '../../services/core.js';
import { runRecurring } from '../payables/recurring.js';
import { moduleOn } from '../admin/service.js';
import { SettingsBody } from '../admin/screens/AdminScreens.js';
import { OFFICE_TABS, shellFor, recordsRows, reportRows, moreReports, todayJobs, memoMinute, resolveHook } from './shellModel.js';
import { QuickRow } from './QuickRow.js';
import { ApprovalPrompt } from '../devices/screens/AddPhoneScreen.js';
import { areaView, getHub } from '../../services/areas.js';
import { useIsTourTarget, TOUR_OUTLINE } from '../../ui/tourTarget.js';

// Search results under the search box (screens, people, suppliers, invoices, orders, cheques, documents…).
function SearchResults({ q, user, screens, nav }) {
  if (q.trim().length < 2) return null;
  let list = [];
  try { list = searchAll(user, q, { modules: menuModules(), screens, limit: 30 }); } catch (e) { list = []; }
  return (
    <View testID="search-results" style={{ backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: C.border, overflow: 'hidden' }}>
      {list.length ? list.map((r, i) => (
        <Pressable key={`${r.kind}-${i}`} testID={`sr-${i}`} onPress={() => nav.push(r.nav.screen, r.nav.params || {})}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderTopWidth: i ? 1 : 0, borderTopColor: '#F0EBE3', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 22 }}>{r.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.title}</Text>
            {r.sub ? <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={1}>{r.sub}</Text> : null}
          </View>
          <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
        </Pressable>
      )) : <Text testID="search-none" style={{ fontSize: 16, color: C.sub, padding: 12 }}>Nothing found for "{q.trim()}".</Text>}
    </View>
  );
}

export default function HomeScreen() {
  const { user, realUser } = useApp();
  const who = realUser || user;
  const s = shellFor(who);
  // the owner can still switch the staff Home off (Settings): staff then get the office Home with what they may open
  const staffOn = getShared('staff_home', '1') !== '0';
  if (s.kind === 'accountant') return <AccountantHome />;
  if ((s.kind === 'staff' || s.kind === 'bakery') && staffOn) return <StaffHome />;
  return <OfficeHome />;
}

// One row of a list (Records hubs, Reports, Today jobs): big, plain words, one tap.
export function Row({ it, onPress }) {
  const tourOn = useIsTourTarget(it.testID);
  return (
    <Pressable testID={it.testID} onPress={onPress}
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: 300, flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 64, paddingVertical: 12, paddingHorizontal: 14, borderRadius: 14, backgroundColor: pressed ? '#F6F2EC' : C.card, borderWidth: 1, borderColor: C.border, ...(tourOn ? TOUR_OUTLINE : {}) })}>
      <Text style={{ fontSize: 24, width: 32, textAlign: 'center' }}>{it.icon || '•'}</Text>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }} numberOfLines={2}>{it.title}</Text>
        {it.note ? <Text style={{ fontSize: 14, color: it.warn ? C.danger : C.sub, fontWeight: it.warn ? '700' : '400' }} numberOfLines={2}>{it.note}</Text> : null}
      </View>
      <Text style={{ fontSize: 22, color: C.sub }}>›</Text>
    </Pressable>
  );
}
const Rows = ({ children }) => <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>{children}</View>;

function Tab({ t, on, isPhone, onChange }) {
  const tourOn = useIsTourTarget(t.testID);
  return (
    <Pressable testID={t.testID} accessibilityRole="tab" accessibilityState={{ selected: on }} onPress={() => onChange(t.key)}
      style={({ pressed }) => ({ flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 48, borderRadius: 12, backgroundColor: on ? C.primary : pressed ? '#F6F2EC' : 'transparent', ...(tourOn ? TOUR_OUTLINE : {}) })}>
      <Text style={{ fontSize: isPhone ? 15 : 18, fontWeight: '800', color: on ? '#FFFFFF' : C.text }} numberOfLines={1}>{t.title}</Text>
    </Pressable>
  );
}
export function TabBar({ tabs, value, onChange }) {
  const { isPhone } = useLayout();
  return (
    <View testID="tab-bar" style={{ flexDirection: 'row', backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.border, padding: 4, gap: 4 }}>
      {tabs.map((t) => <Tab key={t.key} t={t} on={t.key === value} isPhone={isPhone} onChange={onChange} />)}
    </View>
  );
}

// ---------------------------------------------------------------- Office: Today / Records / Reports / Settings
export function OfficeHome() {
  const { user, realUser, nav, screens: ctxScreens } = useApp();
  const who = realUser || user;
  useTick(60000);
  const [q, setQ] = useState('');
  const [tab, setTab] = useRemembered('office-tab', 'today');
  const screens = ctxScreens || allScreens();
  const s = shellFor(who);
  const go = (t) => { if (t && t.screen) nav.push(t.screen, t.params || {}); };
  // Regular bills and loan repayments: make the coming invoices once a day on this device.
  useEffect(() => {
    if (!moduleOn('payables') || getSetting('recurring_ran', '') === dateStr()) return;
    try { runRecurring(null); setSetting('recurring_ran', dateStr()); } catch (e) { /* try tomorrow */ }
  }, []);
  return (
    <Screen title="Easy Buys" subtitle={`${user.name} · ${ROLE_LABEL[user.role] || user.role}`} right={<SyncIcon />}>
      <ApprovalPrompt />
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}><Field testID="home-search" label="Search" value={q} onChangeText={setQ} placeholder="Screen, person, supplier, invoice, PO, cheque…" /></View>
        <Btn testID="home-scan" title="Scan" icon="📷" size="md" variant="info" onPress={() => nav.push('ScanCode', {})} />
      </View>
      <SearchResults q={q} user={who} screens={screens} nav={nav} />
      {s.myShift ? (
        <Pressable testID="home-myshift" onPress={() => nav.push('MyShift', {})} style={({ pressed }) => ({ backgroundColor: '#E1EAFB', borderRadius: 14, padding: 14, borderWidth: 2, borderColor: C.info, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>⏱️ Working a shift today? Tap for My shift – the same buttons as staff</Text>
        </Pressable>
      ) : null}
      <TabBar tabs={OFFICE_TABS} value={tab} onChange={setTab} />
      {tab === 'today' ? <TodayTab who={who} screens={screens} go={go} /> : null}
      {tab === 'records' ? (
        <Rows>{memoMinute('records', who, () => recordsRows(who, screens, getModule)).map((r) => <Row key={r.id} it={r} onPress={() => go(r.target)} />)}</Rows>
      ) : null}
      {tab === 'reports' ? <ReportsTab who={who} screens={screens} go={go} /> : null}
      {tab === 'settings' ? <SettingsBody params={{}} /> : null}
    </Screen>
  );
}

// Today: stream C's list of everything to check goes on top (hook TODAY); until then the daily jobs, questions,
// warnings and who is at work.


function TodayTab({ who, screens, go }) {
  const { nav } = useApp();
  const [, setHid] = useState(0);
  const jobs = memoMinute('today-jobs', who, () => todayJobs(who, screens)) || [];
  const qs = memoMinute('today-q', who, () => require('../verify/queries395.js').openQueriesFor(who.uid)) || [];
  // 1.0.0 speed: Home paints first; the warnings (every part of the business) are worked out just after, so the
  // screen never waits for them. Shown at once when they were worked out a moment ago.
  const [warnState, setWarnState] = useState(() => { try { return peekHomeAlerts(who); } catch (e) { return null; } });
  let changeKey = '';
  try { changeKey = `${writeCount()}|${stamp().slice(0, 16)}`; } catch (e) { changeKey = ''; }
  useEffect(() => {
    let alive = true;
    // one part of the business at a time, with a pause after each: the screen keeps answering taps meanwhile
    const h = setTimeout(() => {
      homeAlertsAsync(who).then((w) => { if (alive) setWarnState(w || { top: [], more: 0 }); }, () => { if (alive) setWarnState({ top: [], more: 0 }); });
    }, 20);
    return () => { alive = false; clearTimeout(h); };
  }, [who.uid, changeKey]);
  const warn = warnState || { top: [], more: 0 };
  const atWork = memoMinute('today-in', who, () => {
    if (!moduleOn('timeclock') || !require('../../services/access.js').can(who, 'timesheets_view')) return null;
    const inNow = require('../timeclock/service.js').whoIsIn();
    let off = [];
    try { off = moduleOn('leave') ? require('../leave/service.js').whoIsOff() : []; } catch (e) { off = []; }
    return { inNow, off };
  });
  return (
    <View style={{ gap: 12 }}>
      <QuickRow who={who} screens={screens} />
      {qs.length ? (
        <Pressable testID="home-questions" onPress={() => nav.push('MyQueries', {})} style={{ backgroundColor: '#FEF0C7', borderRadius: 14, padding: 12, borderWidth: 2, borderColor: C.warn }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`❓ ${qs.length} question${qs.length === 1 ? '' : 's'} for you`}</Text>
          <Text style={{ fontSize: 15, color: C.text }} numberOfLines={2}>{`${qs[0].asked_by_name}: ${qs[0].question}`}</Text>
        </Pressable>
      ) : null}
      {!warnState ? <Text testID="home-warnings-wait" style={{ fontSize: 15, color: C.sub }}>Checking for warnings…</Text> : null}
      {warn.top.length ? (
        <View testID="home-warnings" style={{ gap: 8 }}>
          {warn.top.map((a) => <AlertCard key={a.id} a={a} onHidden={() => setHid((n) => n + 1)} />)}
          {warn.more ? <Btn testID="alerts-more" title={`+ ${warn.more} more warning${warn.more === 1 ? '' : 's'}`} size="sm" variant="secondary" onPress={() => nav.push('Warnings', {})} /> : null}
        </View>
      ) : null}
      <Rows>{jobs.map((r) => <Row key={r.id} it={r} onPress={() => go(r.target)} />)}</Rows>
      <QuickLinksBar />
      <Row it={{ testID: 'home-help', icon: '🧭', title: 'Help & how-to', note: 'Every job step by step, and tutorials' }} onPress={() => nav.push('Help')} />
      {atWork ? (
        <Section title={`At work now: ${atWork.inNow.length}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{atWork.inNow.length ? atWork.inNow.map((p) => `${p.name}${p.state === 'break' ? ' (break)' : ''}`).join(', ') : 'Nobody is clocked in.'}</Text>
          {atWork.off.length ? <Text style={{ fontSize: 15, color: C.sub }}>On leave today: {atWork.off.map((r) => r.name).join(', ')}</Text> : null}
        </Section>
      ) : null}
    </View>
  );
}

function ReportsTab({ who, screens, go }) {
  const { nav } = useApp();
  const rows = memoMinute('reports-rows', who, () => reportRows(who, screens, getModule)) || [];
  const more = memoMinute('reports-more', who, () => moreReports(who, screens, menuModules())) || [];
  const canAll = !!screens.ReportsHub && screens.ReportsHub.can(who);
  return (
    <View style={{ gap: 12 }}>
      <Rows>{rows.map((r) => <Row key={r.key} it={r} onPress={() => go(r.target)} />)}</Rows>
      {canAll ? <Row it={{ testID: 'home-reports', icon: '📊', title: 'All reports', note: 'Every report – PDF · Excel · CSV' }} onPress={() => nav.push('ReportsHub', {})} /> : null}
      {more.length ? (
        <Section title="Reports by part of the business">
          <Rows>{more.map((it) => <Row key={`${it.module}-${it.id}`} it={{ ...it, note: it.moduleTitle }} onPress={() => nav.push(it.screen, it.params || {})} />)}</Rows>
        </Section>
      ) : null}
    </View>
  );
}

// ---------------------------------------------------------------- Accountant: Books / Downloads / Questions (view only)
function AccountantHome() {
  const { user, realUser, nav, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const s = shellFor(who);
  const [tab, setTab] = useRemembered('acct-tab', 'books');
  const ok = (n) => !!screens[n] && screens[n].can(who);
  const books = memoMinute('acct-books', who, () => { const v = areaView(getHub('books'), who, screens, getModule); return v.top.concat(...v.blocks.map((b) => b.daily.concat(b.more))); }) || [];
  const booksHome = resolveHook('BOOKS_HOME', screens, who); // stream E's books page, when it is in
  const downloads = [
    ok('ReportsHub') && { testID: 'acct-reports', icon: '📊', title: 'All reports', note: 'PDF · Excel · CSV', target: { screen: 'ReportsHub', params: {} } },
    resolveHook('FOR_ACCOUNTANT', screens, who) && { testID: 'acct-files', icon: '📤', title: 'For the accountant', note: 'VAT, FNPF and the books for the month', target: resolveHook('FOR_ACCOUNTANT', screens, who) },
    resolveHook('VAT', screens, who) && { testID: 'acct-vat', icon: '🧾', title: 'VAT return', target: resolveHook('VAT', screens, who) },
    resolveHook('FNPF', screens, who) && { testID: 'acct-fnpf', icon: '🏦', title: 'FNPF', target: resolveHook('FNPF', screens, who) },
    ok('YearEndAcct') && { testID: 'acct-year', icon: '🏛️', title: 'Year-end pack', note: 'Financial statements for the year', target: { screen: 'YearEndAcct', params: {} } },
  ].filter(Boolean);
  return (
    <Screen title="Easy Buys – the books" subtitle={`${user.name} · view only`} right={<SyncIcon />}>
      <TabBar tabs={s.tabs} value={tab} onChange={setTab} />
      {tab === 'books' && booksHome ? <Row it={{ testID: 'acct-bookshome', icon: '📚', title: 'The books', note: 'Overview, journal, ledger' }} onPress={() => nav.push(booksHome.screen, booksHome.params || {})} /> : null}
      {tab === 'books' ? <Rows>{books.filter((it) => !booksHome || it.screen !== booksHome.screen).map((it) => <Row key={it.testID} it={it} onPress={() => nav.push(it.screen, it.params || {})} />)}</Rows> : null}
      {tab === 'downloads' ? <Rows>{downloads.map((it) => <Row key={it.testID} it={it} onPress={() => nav.push(it.target.screen, it.target.params || {})} />)}</Rows> : null}
      {tab === 'questions' ? (
        <View style={{ gap: 10 }}>
          <Text style={{ fontSize: 16, color: C.text }}>Ask about any entry. The owner answers, and any fix is booked by the owner with a note.</Text>
          {ok('Queries') ? <Row it={{ testID: 'home-queries', icon: '❓', title: 'My questions to the owner', note: 'Ask, and see the answers' }} onPress={() => nav.push('Queries', {})} /> : null}
        </View>
      ) : null}
    </Screen>
  );
}
