// Home: the tiles each person may use, plus what needs attention today.
import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Tile, Grid, Section, Field, Btn, useApp, useTick } from '../../ui/components.js';
import { SyncIcon } from '../../ui/chrome.js';
import { AlertCard } from '../../ui/alertsUI.js';
import { homeAlerts } from '../../services/alerts.js';
import { searchAll } from '../../services/search.js';
import { allScreens, menuModules } from '../registry.js';
import { QuickLinksBar } from './QuickLinksScreen.js';
import { C } from '../../ui/theme.js';
import { can, deviceSettings, ROLE_LABEL } from '../../services/access.js';
import { dateStr, getSetting, setSetting } from '../../services/core.js';
import { apAlerts, $ } from '../payables/service.js';
import { runRecurring } from '../payables/recurring.js';
import { tillAlerts } from '../till/service.js';
import { payrollAlerts } from '../payroll/service.js';
import { invAlerts } from '../inventory/service.js';
import { queueSummary } from '../verify/service.js';
import { moduleOn } from '../admin/service.js';
import { whoIsIn, stateOf } from '../timeclock/service.js';
import { weekTimesheet } from '../timesheets/service.js';
import { listLeave, whoIsOff } from '../leave/service.js';
import { licenceAlerts } from '../licences/service.js';
import { db } from '../../db/connection.js';

// Search results under the search box (screens, people, suppliers, invoices, orders, cheques, documents…).
function SearchResults({ q, user, screens, nav }) {
  let list = [];
  try { list = searchAll(user, q, { modules: menuModules(), screens, limit: 30 }); } catch (e) { list = []; }
  if (q.trim().length < 2) return null;
  return (
    <View testID="search-results" style={{ backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: C.border, overflow: 'hidden' }}>
      {list.length ? list.map((r, i) => (
        <Pressable key={`${r.kind}-${i}`} testID={`sr-${i}`} onPress={() => nav.push(r.nav.screen, r.nav.params || {})}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderTopWidth: i ? 1 : 0, borderTopColor: '#F0EBE3', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 22 }}>{r.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.title}</Text>
            {r.sub ? <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={1}>{r.sub}</Text> : null}
          </View>
          <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
        </Pressable>
      )) : <Text testID="search-none" style={{ fontSize: 16, color: C.sub, padding: 12 }}>Nothing found for "{q.trim()}".</Text>}
    </View>
  );
}

export default function HomeScreen() {
  const { user, realUser, nav, openClock, screens: ctxScreens } = useApp();
  useTick(30000);
  const [q, setQ] = useState('');
  const [, setHid] = useState(0);
  const screens = ctxScreens || allScreens();
  const menu = (id) => () => nav.push('ModuleMenu', { module: id });
  const dev = deviceSettings();
  const tiles = [];
  const add = (id, cond, icon, title, subtitle, onPress, color, badge) => { if (cond) tiles.push({ id, el: <Tile key={id} testID={`home-${id}`} icon={icon} title={title} subtitle={subtitle} color={color} onPress={onPress} badge={badge} /> }); };
  // Tiles are grouped so each person finds things in the same place every day.
  const GROUPS = [
    ['Daily tasks', ['myday', 'dashboard', 'clock', 'snap', 'myhours', 'payslips', 'paysign', 'verify']],
    ['Money', ['till', 'payables', 'bank', 'accounting', 'loans', 'owed']],
    ['Stock & bakery', ['inventory', 'bakery']],
    ['People', ['payroll', 'timesheets', 'leave', 'staff', 'recruit']],
    ['Business', ['queries', 'licences', 'reports', 'admin', 'help']],
  ];
  const leaveWaiting = can(user, 'leave_approve') && moduleOn('leave') ? listLeave({ status: 'requested' }).length : 0;
  let toFix = 0;
  if (can(user, 'timesheets_view') && moduleOn('timesheets')) toFix = weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0);
  const inNow = moduleOn('timeclock') ? whoIsIn() : [];
  const off = moduleOn('leave') ? whoIsOff() : [];
  const me = stateOf(user.uid);
  const apOn = moduleOn('payables') && ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(user, p));
  const tillOn = moduleOn('till') && ['till_count', 'till_approve', 'deposits'].some((p) => can(user, p));
  const payOn = moduleOn('payroll') && ['payroll_view', 'payroll_run', 'payroll_setup'].some((p) => can(user, p));
  // Regular bills and loan repayments: make the coming invoices once a day on this device.
  useEffect(() => {
    if (!moduleOn('payables') || getSetting('recurring_ran', '') === dateStr()) return;
    try { runRecurring(null); setSetting('recurring_ran', dateStr()); } catch (e) { /* try tomorrow */ }
  }, []);
  const ap = apOn ? apAlerts() : null;
  const till = tillOn && can(user, 'till_approve') ? tillAlerts() : null;
  const pay = payOn ? payrollAlerts() : null;
  const invOn = moduleOn('inventory') && ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'].some((p) => can(user, p));
  let inv = [];
  try { inv = invOn ? invAlerts([]) : []; } catch (e) { inv = []; }

  add('myday', false && moduleOn('myday') && (can(user, 'myday') || can(user, 'myday_view')), '🗓️', 'My day', can(user, 'myday') ? 'Tasks, meetings, errands in order' : "The owner's day (read-only)", can(user, 'myday') ? () => nav.push('MyDay', {}) : () => nav.push('TheirDay', {}), C.primary);
  add('clock', moduleOn('timeclock') && dev.clockHere, '⏱️', 'Time Clock', 'Staff clock in / out', openClock, C.success);
  add('myhours', can(user, 'my_hours') && moduleOn('timesheets'), '🙋', 'My hours', me.state === 'in' ? 'You are clocked in' : 'Hours and leave left', () => nav.push('MyHours'), C.info);
  add('timesheets', can(user, 'timesheets_view') && moduleOn('timesheets'), '🗓️', 'Timesheets', 'Sat–Fri weeks, fix, check', menu('timesheets'), C.brandBlue, toFix || null);
  add('leave', (can(user, 'my_hours') || can(user, 'leave_approve')) && moduleOn('leave'), '🌴', 'Leave', leaveWaiting ? `${leaveWaiting} to approve` : 'Ask, approve, balances', menu('leave'), C.warn, leaveWaiting || null);
  add('payroll', payOn, '💰', 'Payroll', pay && pay.draft ? `${pay.draft} pay run to finish` : 'Pay runs, payslips, advances', menu('payroll'), C.success, pay && pay.draft ? pay.draft : null);
  add('payables', apOn, '🧾', 'Invoices & cheques', ap && ap.overdue.n ? `${ap.overdue.n} overdue · ${$(ap.overdue.amount)}` : 'Invoices, paying, cheque book', menu('payables'), C.primary, ap ? (ap.overdue.n + ap.dueToday.n) || null : null);
  add('loans', (moduleOn('loans') && ['loans_manage', 'ap_setup', 'payments_make'].some((p) => can(user, p))) || (moduleOn('drawings') && can(user, 'drawings')), '🏦', "Loans, rent & owner's money", 'Repayments, rent, receipts, balances', menu('loans'), C.brandBlue);
  add('till', tillOn, '💵', 'Till & cash', till && till.waiting ? `${till.waiting} count(s) to approve` : 'Till counts, deposits, cash', menu('till'), C.warn, till && till.waiting ? till.waiting : null);
  add('inventory', invOn, '📦', 'Inventory & orders', inv.length ? inv[0].text : 'Stock, orders, deliveries, stock take', menu('inventory'), C.brandBlue, inv.filter((a) => a.tone === 'warn').length || null);
  let vq = null;
  if (can(user, 'verify_money')) { try { vq = queueSummary(); } catch (e) { vq = null; } }
  add('verify', !!vq, '✅', 'To verify', vq && vq.waiting ? `${vq.waiting} waiting${vq.late ? ` · ${vq.late} late` : ''}` : 'Everything verified', () => nav.push('Verify', {}), vq && vq.late ? C.danger : C.success, vq && vq.waiting ? vq.waiting : null);
  add('snap', can(user, 'snap_upload') || can(user, 'po_receive'), '📥', 'Receive goods & papers', 'Deliveries, invoices, receipts, cheques', () => nav.push('Snap', {}), C.info);
  add('recruit', moduleOn('recruitment') && can(user, 'recruit_manage'), '🧑‍💼', 'Recruitment & onboarding', 'Vacancies, new staff, contracts', menu('recruitment'), C.brandBlue);
  let arWaiting = 0;
  if (moduleOn('accounting') && can(user, 'accounts_view')) { try { arWaiting = db().get("SELECT COUNT(*) AS n FROM aronium_batches WHERE status = 'to_check'").n; } catch (e) { arWaiting = 0; } }
  add('accounting', moduleOn('accounting') && can(user, 'accounts_view'), '📚', 'Accounting & VAT', 'VAT return, profit & loss, books', menu('accounting'), C.primaryDark);
  add('bank', moduleOn('bank') && can(user, 'bank_rec'), '🏦', 'Bank reconciliation', 'Match the BSP statement', menu('bank'), C.brandBlue);
  // v3.5 pay sign-off: staff sign their payslips on this device (roles chosen by the admin).
  let ps = null;
  try { const SO = require('../payroll/signoff.js'); if (moduleOn('payroll') && SO.canRunSignoff(user)) ps = SO.signoffSummary(); } catch (e) { ps = null; }
  add('paysign', !!ps, '✍️', 'Pay sign-off', ps && ps.waiting ? `${ps.waiting} payslip(s) to sign` : 'Staff sign their payslips', () => nav.push('PaySignOff', {}), ps && ps.queries ? C.danger : C.success, ps && ps.waiting ? ps.waiting : null);
  add('payslips', moduleOn('payroll') && can(user, 'my_hours') && !payOn, '🧾', 'My payslips', 'Your pay each week', () => nav.push('MyPayslips'), C.success);
  add('bakery', can(user, 'bakery') && moduleOn('bakery'), '🥖', 'Bakery', 'Production, stock, shifts', menu('bakery'), C.primary);
  add('staff', can(user, 'staff_manage') || can(user, 'face_enrol'), '👥', 'Staff', 'People, PINs, faces', menu('staff'), C.info);
  let lic = null;
  const licOn = moduleOn('licences') && (can(user, 'licences_view') || can(user, 'licences_manage'));
  if (licOn) { try { lic = licenceAlerts(); } catch (e) { lic = null; } }
  add('licences', licOn, '📜', 'Licences & permits', lic && lic.overdue.length ? `${lic.overdue.length} expired!` : lic && lic.due.length ? `${lic.due.length} to renew soon` : 'Copies, applications, renewals', menu('licences'), lic && lic.overdue.length ? C.danger : C.primaryDark, lic ? (lic.overdue.length + lic.due.length) || null : null);
  add('dashboard', can(user, 'dashboard'), '📊', 'Dashboard', 'The business at a glance', menu('dashboard'), C.brandBlue);
  add('owed', can(user, 'owed_view'), '🧾', 'Who owes us', 'Staff credit, advances, loans', menu('owed'), C.warn);
  add('reports', can(user, 'reports'), '📊', 'Reports', 'PDF · Excel · CSV', () => nav.push('ReportsHub', {}), C.success);
  add('admin', can(user, 'settings') || can(user, 'roles'), '⚙️', 'Admin & settings', 'Every module\'s settings, devices, backup', () => nav.push('Admin'), C.primaryDark);
  add('queries', user.role === 'accountant', '❓', 'Ask the owner', 'View only – send a question about a record', () => nav.push('Queries'), C.warn);
  add('help', true, '🧭', 'Tutorials', 'Learn each job step by step', () => nav.push('Tutorials'), C.info);

  // Warnings from every module (src/services/alerts.js): the 3 most urgent, then "+ x more".
  let warn = { top: [], more: 0, all: [] };
  try { warn = homeAlerts(realUser || user); } catch (e) { warn = { top: [], more: 0, all: [] }; }

  return (
    <Screen title="Easy Buys" subtitle={`${user.name} · ${ROLE_LABEL[user.role] || user.role}`} right={<SyncIcon />}>
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}><Field testID="home-search" label="Search" value={q} onChangeText={setQ} placeholder="Screen, person, supplier, invoice, PO, cheque…" /></View>
        <Btn testID="home-scan" title="Scan" icon="📷" size="md" variant="info" onPress={() => nav.push('ScanCode', {})} />
      </View>
      <SearchResults q={q} user={realUser || user} screens={screens} nav={nav} />
      {!q ? <QuickLinksBar /> : null}
      {warn.top.length ? (
        <View testID="home-warnings" style={{ gap: 8 }}>
          {warn.top.map((a) => <AlertCard key={a.id} a={a} onHidden={() => setHid((n) => n + 1)} />)}
          {warn.more ? (
            <Pressable testID="alerts-more" onPress={() => nav.push('Warnings', {})} style={({ pressed }) => ({ alignSelf: 'flex-start', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 12, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.6 : 1 })}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: C.info }}>+ {warn.more} more warning{warn.more === 1 ? '' : 's'}</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
      {GROUPS.map(([g, ids]) => {
        const els = tiles.filter((t) => ids.includes(t.id)).map((t) => t.el);
        return els.length ? <Section key={g} title={g}><Grid>{els}</Grid></Section> : null;
      })}
      {tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).length ? <Grid>{tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).map((t) => t.el)}</Grid> : null}
      {can(user, 'timesheets_view') && moduleOn('timeclock') ? (
        <Section title={`At work now: ${inNow.length}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{inNow.length ? inNow.map((p) => `${p.name}${p.state === 'break' ? ' (break)' : ''}`).join(', ') : 'Nobody is clocked in.'}</Text>
          {off.length ? <Text style={{ fontSize: 15, color: C.sub }}>On leave today: {off.map((r) => r.name).join(', ')}</Text> : null}
        </Section>
      ) : null}
    </Screen>
  );
}
