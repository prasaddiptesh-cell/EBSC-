// Home: the tiles each person may use, plus what needs attention today.
import React, { useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Tile, Grid, Banner, Section, useApp, useTick } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { can, deviceSettings, ROLE_LABEL } from '../../services/access.js';
import { dateStr, getSetting, setSetting } from '../../services/core.js';
import { apAlerts, $ } from '../payables/service.js';
import { runRecurring } from '../payables/recurring.js';
import { tillAlerts } from '../till/service.js';
import { payrollAlerts } from '../payroll/service.js';
import { invAlerts } from '../inventory/service.js';
import { queueSummary } from '../verify/service.js';
import { statAlerts } from '../payroll/statutory.js';
import { stillIn } from '../timesheets/roster.js';
import { moduleOn } from '../admin/service.js';
import { whoIsIn, stateOf } from '../timeclock/service.js';
import { weekTimesheet } from '../timesheets/service.js';
import { listLeave, whoIsOff } from '../leave/service.js';
import bakery from '../bakery/index.js';

export default function HomeScreen() {
  const { user, nav, openClock } = useApp();
  useTick(30000);
  const dev = deviceSettings();
  const tiles = [];
  const add = (id, cond, icon, title, subtitle, onPress, color, badge) => { if (cond) tiles.push({ id, el: <Tile key={id} testID={`home-${id}`} icon={icon} title={title} subtitle={subtitle} color={color} onPress={onPress} badge={badge} /> }); };
  // Tiles are grouped so each person finds things in the same place every day.
  const GROUPS = [
    ['Every day', ['clock', 'snap', 'myhours', 'payslips', 'till', 'verify']],
    ['Money', ['payables', 'bank', 'payroll', 'accounting']],
    ['Stock', ['inventory', 'bakery']],
    ['Staff', ['timesheets', 'roster', 'leave', 'staff', 'recruit']],
    ['Office', ['reports', 'admin', 'sync']],
  ];
  const leaveWaiting = can(user, 'leave_approve') && moduleOn('leave') ? listLeave({ status: 'requested' }).length : 0;
  let toFix = 0;
  if (can(user, 'timesheets_view') && moduleOn('timesheets')) toFix = weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0);
  const inNow = moduleOn('timeclock') ? whoIsIn() : [];
  const off = moduleOn('leave') ? whoIsOff() : [];
  const me = stateOf(user.uid);
  const apOn = moduleOn('payables') && ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(user, p));
  const tillOn = moduleOn('till') && ['till_count', 'till_approve', 'deposits'].some((p) => can(user, p));
  const payOn = moduleOn('payroll') && ['payroll_view', 'payroll_run', 'payroll_setup'].some((p) => can(user, p));
  // Regular bills and loan repayments: make the coming invoices once a day on this device.
  useEffect(() => {
    if (!moduleOn('payables') || getSetting('recurring_ran', '') === dateStr()) return;
    try { runRecurring(null); setSetting('recurring_ran', dateStr()); } catch (e) { /* try tomorrow */ }
  }, []);
  const ap = apOn ? apAlerts() : null;
  const till = tillOn && can(user, 'till_approve') ? tillAlerts() : null;
  const pay = payOn ? payrollAlerts() : null;
  const invOn = moduleOn('inventory') && ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'].some((p) => can(user, p));
  let inv = [];
  try { inv = invOn ? invAlerts([]) : []; } catch (e) { inv = []; }

  add('clock', moduleOn('timeclock') && dev.clockHere, '⏱️', 'Time Clock', 'Staff clock in / out', openClock, C.success);
  add('myhours', can(user, 'my_hours') && moduleOn('timesheets'), '🙋', 'My hours', me.state === 'in' ? 'You are clocked in' : 'Hours and leave left', () => nav.push('MyHours'), C.info);
  add('timesheets', can(user, 'timesheets_view') && moduleOn('timesheets'), '🗓️', 'Timesheets', 'Sat–Fri weeks, fix, check', () => nav.push('Timesheets', {}), C.brandBlue, toFix || null);
  add('roster', can(user, 'timesheets_view') && moduleOn('timesheets'), '📅', 'Roster & who is on', 'Plan shifts, see who is late', () => nav.push('RosterPlanner', {}), C.info);
  add('leave', (can(user, 'my_hours') || can(user, 'leave_approve')) && moduleOn('leave'), '🌴', 'Leave', leaveWaiting ? `${leaveWaiting} to approve` : 'Ask, approve, balances', () => nav.push('Leave', {}), C.warn, leaveWaiting || null);
  add('payroll', payOn, '💰', 'Payroll', pay && pay.draft ? `${pay.draft} pay run to finish` : 'Pay runs, payslips, advances', () => nav.push('Payroll'), C.success, pay && pay.draft ? pay.draft : null);
  add('payables', apOn, '🧾', 'Invoices & cheques', ap && ap.overdue.n ? `${ap.overdue.n} overdue · ${$(ap.overdue.amount)}` : 'Invoices, paying, cheque book', () => nav.push('Payables'), C.primary, ap ? (ap.overdue.n + ap.dueToday.n) || null : null);
  add('till', tillOn, '💵', 'Till & cash', till && till.waiting ? `${till.waiting} count(s) to approve` : 'Till counts, deposits, cash', () => nav.push('Till'), C.warn, till && till.waiting ? till.waiting : null);
  add('inventory', invOn, '📦', 'Inventory & orders', inv.length ? inv[0].text : 'Stock, orders, deliveries, stock take', () => nav.push('Inventory'), C.brandBlue, inv.filter((a) => a.tone === 'warn').length || null);
  let still = [];
  if (can(user, 'timesheets_view') && moduleOn('timesheets')) { try { still = stillIn(12); } catch (e) { still = []; } }
  let stat = null;
  if (moduleOn('payroll') && can(user, 'statutory')) { try { stat = statAlerts(); } catch (e) { stat = null; } }
  let vq = null;
  if (can(user, 'verify_money')) { try { vq = queueSummary(); } catch (e) { vq = null; } }
  add('verify', !!vq, '✅', 'To verify', vq && vq.waiting ? `${vq.waiting} waiting${vq.late ? ` · ${vq.late} late` : ''}` : 'Everything verified', () => nav.push('Verify', {}), vq && vq.late ? C.danger : C.success, vq && vq.waiting ? vq.waiting : null);
  add('snap', can(user, 'snap_upload'), '📷', 'Photo of invoice / cheque', 'Received or handed over', () => nav.push('Snap', {}), C.info);
  add('recruit', moduleOn('recruitment') && can(user, 'recruit_manage'), '🧑‍💼', 'Recruitment & onboarding', 'Vacancies, new staff, contracts', () => nav.push('Recruitment'), C.brandBlue);
  add('accounting', moduleOn('accounting') && can(user, 'accounts_view'), '📚', 'Accounting & VAT', 'VAT return, profit & loss, books', () => nav.push('Accounting'), C.primaryDark);
  add('bank', moduleOn('bank') && can(user, 'bank_rec'), '🏦', 'Bank reconciliation', 'Match the BSP statement', () => nav.push('BankRec', {}), C.brandBlue);
  add('payslips', moduleOn('payroll') && can(user, 'my_hours') && !payOn, '🧾', 'My payslips', 'Your pay each week', () => nav.push('MyPayslips'), C.success);
  add('bakery', can(user, 'bakery') && moduleOn('bakery'), '🥖', 'Bakery', 'Production, stock, shifts', () => nav.push(bakery.homeScreen(user)), C.primary);
  add('staff', can(user, 'staff_manage') || can(user, 'face_enrol'), '👥', 'Staff', 'People, PINs, faces', () => nav.push('Users'), C.info);
  add('reports', can(user, 'reports'), '📊', 'Reports', 'PDF · Excel · CSV', () => nav.push('ReportsHub', {}), C.success);
  add('admin', can(user, 'settings') || can(user, 'roles'), '⚙️', 'Admin & settings', 'Every module\'s settings, devices, backup', () => nav.push('Admin'), C.primaryDark);
  add('sync', true, '⟳', 'Sync status', 'Every section, Force sync', () => nav.push('SyncStatus'), C.sub);

  return (
    <Screen title="Easy Buys" subtitle={`${user.name} · ${ROLE_LABEL[user.role] || user.role}`}>
      {toFix ? <Banner tone="warn" title={`${toFix} timesheet problem(s) this week`} message="Missing Clock OUT, long shifts or no breaks. Open Timesheets to fix." /> : null}
      {ap && ap.overdue.n ? <Banner tone="danger" title={`${ap.overdue.n} supplier invoice(s) overdue – ${$(ap.overdue.amount)}`} message={ap.dueToday.n ? `${ap.dueToday.n} more due today.` : 'Open Invoices & cheques to pay them.'} /> : null}
      {ap && !ap.overdue.n && ap.dueToday.n ? <Banner tone="warn" title={`${ap.dueToday.n} invoice(s) due today – ${$(ap.dueToday.amount)}`} message="Open Invoices & cheques." /> : null}
      {ap && ap.skipped ? <Banner tone="danger" title="Cheque numbers skipped" message="A cheque leaf is not recorded. Open Invoices & cheques › Cheques & bank › Books." /> : null}
      {till && till.waiting ? <Banner tone="info" title={`${till.waiting} till count(s) to approve`} message="Open Till & cash." /> : null}
      {pay && !pay.confirmed && can(user, 'payroll_setup') ? <Banner tone="warn" title="Payroll: check the tax and FNPF figures" message="Payroll › Rules – tick Checked when done." /> : null}
      {stat && stat.late.length ? <Banner tone="danger" title="FNPF / PAYE payment late" message={stat.late.map((x) => `${x.kind.toUpperCase()} for ${x.period}: ${$(x.amount)} was due ${x.due_date}`).join('\n')} /> : null}
      {vq && vq.late ? <Banner tone="danger" title={`${vq.late} money record(s) not seen in the bank yet`} message="Deposits or cheques older than expected. Open To verify." /> : null}
      {still.length ? <Banner tone="warn" title="Still clocked in after 12 hours" message={`${still.map((x) => x.name).join(', ')} – probably forgot to clock out. Fix it in Timesheets.`} /> : null}
      {leaveWaiting ? <Banner tone="info" title={`${leaveWaiting} leave request(s) waiting`} message="Open Leave to approve or decline." /> : null}
      {GROUPS.map(([g, ids]) => {
        const els = tiles.filter((t) => ids.includes(t.id)).map((t) => t.el);
        return els.length ? <Section key={g} title={g}><Grid>{els}</Grid></Section> : null;
      })}
      {tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).length ? <Grid>{tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).map((t) => t.el)}</Grid> : null}
      {can(user, 'timesheets_view') && moduleOn('timeclock') ? (
        <Section title={`At work now: ${inNow.length}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{inNow.length ? inNow.map((p) => `${p.name}${p.state === 'break' ? ' (break)' : ''}`).join(', ') : 'Nobody is clocked in.'}</Text>
          {off.length ? <Text style={{ fontSize: 15, color: C.sub }}>On leave today: {off.map((r) => r.name).join(', ')}</Text> : null}
        </Section>
      ) : null}
    </Screen>
  );
}
