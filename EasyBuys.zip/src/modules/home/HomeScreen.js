// Home: the tiles each person may use, plus what needs attention today.
import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Tile, Grid, Section, Field, Btn, useApp, useTick } from '../../ui/components.js';
import { SyncIcon } from '../../ui/chrome.js';
import { AlertCard } from '../../ui/alertsUI.js';
import { homeAlerts } from '../../services/alerts.js';
import { searchAll } from '../../services/search.js';
import { allScreens, menuModules, getModule } from '../registry.js';
import { getArea, areaView } from '../../services/areas.js';
import { QuickLinksBar } from './QuickLinksScreen.js';
import StaffHome, { staffHomeOn } from './StaffHome.js';
import { C } from '../../ui/theme.js';
import { can, deviceSettings, ROLE_LABEL } from '../../services/access.js';
import { dateStr, getSetting, setSetting, stamp } from '../../services/core.js';
import { apAlerts, $ } from '../payables/service.js';
import { runRecurring } from '../payables/recurring.js';
import { tillAlerts } from '../till/service.js';
import { payrollAlerts } from '../payroll/service.js';
import { invAlerts } from '../inventory/service.js';
import { queueSummary } from '../verify/service.js';
import { moduleOn } from '../admin/service.js';
import { whoIsIn, stateOf } from '../timeclock/service.js';
import { weekTimesheet } from '../timesheets/service.js';
import { listLeave, whoIsOff } from '../leave/service.js';
import { licenceAlerts } from '../licences/service.js';
import { db, writeCount } from '../../db/connection.js';

// Search results under the search box (screens, people, suppliers, invoices, orders, cheques, documents…).
function SearchResults({ q, user, screens, nav }) {
  if (q.trim().length < 2) return null;
  let list = [];
  try { list = searchAll(user, q, { modules: menuModules(), screens, limit: 30 }); } catch (e) { list = []; }
  return (
    <View testID="search-results" style={{ backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: C.border, overflow: 'hidden' }}>
      {list.length ? list.map((r, i) => (
        <Pressable key={`${r.kind}-${i}`} testID={`sr-${i}`} onPress={() => nav.push(r.nav.screen, r.nav.params || {})}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderTopWidth: i ? 1 : 0, borderTopColor: '#F0EBE3', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 22 }}>{r.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.title}</Text>
            {r.sub ? <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={1}>{r.sub}</Text> : null}
          </View>
          <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
        </Pressable>
      )) : <Text testID="search-none" style={{ fontSize: 16, color: C.sub, padding: 12 }}>Nothing found for "{q.trim()}".</Text>}
    </View>
  );
}

// v3.9.4 speed: Home's figures are worked out once and reused on every redraw (typing in Search, the 30-second tick)
// until something is saved or the minute changes.
const memoStore = new Map();
function memo(name, user, fn) {
  const key = `${name}|${user ? user.uid : ''}|${writeCount()}|${stamp().slice(0, 16)}`;
  const hit = memoStore.get(name);
  if (hit && hit.key === key) return hit.v;
  const v = fn();
  memoStore.set(name, { key, v });
  return v;
}

// v3.9.5 shop staff and bakers get their own simple Home (big buttons for the daily jobs).
export default function HomeScreen() {
  const { user } = useApp();
  return staffHomeOn(user) ? <StaffHome /> : <ManagerHome />;
}

function ManagerHome() {
  const { user, realUser, nav, openClock, screens: ctxScreens } = useApp();
  useTick(30000);
  const [q, setQ] = useState('');
  const [, setHid] = useState(0);
  const screens = ctxScreens || allScreens();
  const menu = (id) => () => nav.push('ModuleMenu', { module: id });
  const dev = deviceSettings();
  const tiles = [];
  const add = (id, cond, icon, title, subtitle, onPress, color, badge) => { if (cond) tiles.push({ id, el: <Tile key={id} testID={`home-${id}`} icon={icon} title={title} subtitle={subtitle} color={color} onPress={onPress} badge={badge} /> }); };
  // v3.9.5 Home: the daily jobs, then the areas of the business (each gathers its modules), then Reports and Settings.
  const GROUPS = [
    ['Daily jobs', ['daystart', 'dashboard', 'verify', 'snap', 'cheque', 'clock', 'handover', 'checklist', 'fccc', 'myhours', 'payslips', 'paysign']],
    ['The business', ['till', 'inventory', 'payables', 'people', 'money', 'bakery', 'papers']],
    ['Reports & settings', ['queries', 'reports', 'admin', 'help']],
  ];
  const area = (id) => () => nav.push('Area', { area: id });
  const areaOk = (id) => memo(`area-${id}`, realUser || user, () => { const A = getArea(id); try { return !!A && !areaView(A, realUser || user, screens, getModule).empty; } catch (e) { return false; } });
  const leaveWaiting = can(user, 'leave_approve') && moduleOn('leave') ? memo('leave', user, () => listLeave({ status: 'requested' }).length) : 0;
  let toFix = 0;
  if (can(user, 'timesheets_view') && moduleOn('timesheets')) toFix = memo('toFix', user, () => weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0));
  const inNow = moduleOn('timeclock') ? memo('inNow', user, () => whoIsIn()) : [];
  const off = moduleOn('leave') ? memo('off', user, () => whoIsOff()) : [];
  const me = memo('me', user, () => stateOf(user.uid));
  const apOn = moduleOn('payables') && ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(user, p));
  const tillOn = moduleOn('till') && ['till_count', 'till_approve', 'deposits'].some((p) => can(user, p));
  const payOn = moduleOn('payroll') && ['payroll_view', 'payroll_run', 'payroll_setup'].some((p) => can(user, p));
  // Regular bills and loan repayments: make the coming invoices once a day on this device.
  useEffect(() => {
    if (!moduleOn('payables') || getSetting('recurring_ran', '') === dateStr()) return;
    try { runRecurring(null); setSetting('recurring_ran', dateStr()); } catch (e) { /* try tomorrow */ }
  }, []);
  const ap = apOn ? memo('ap', user, () => apAlerts()) : null;
  const till = tillOn && can(user, 'till_approve') ? memo('till', user, () => tillAlerts()) : null;
  const pay = payOn ? memo('pay', user, () => payrollAlerts()) : null;
  const invOn = moduleOn('inventory') && ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'].some((p) => can(user, p));
  let inv = [];
  try { inv = invOn ? memo('inv', user, () => invAlerts([])) : []; } catch (e) { inv = []; }

  // Daily jobs
  // v3.9.8 Start the day: money, what is due, orders to place – for the owner and admin
  add('daystart', !!screens.DayStart && screens.DayStart.can(user), '🌅', 'Start the day', 'Bank, M-PAiSA, what is due, orders to place', () => nav.push('DayStart', {}), C.brandBlue);
  add('dashboard', can(user, 'dashboard'), '📊', 'Dashboard', 'The business at a glance', menu('dashboard'), C.brandBlue);
  let vq = null;
  if (can(user, 'verify_money')) { try { vq = memo('vq', user, () => queueSummary()); } catch (e) { vq = null; } }
  add('verify', !!vq, '✅', 'To verify', vq && vq.waiting ? `${vq.waiting} waiting${vq.late ? ` · ${vq.late} late` : ''}` : 'Everything verified', () => nav.push('Verify', {}), vq && vq.late ? C.danger : C.success, vq && vq.waiting ? vq.waiting : null);
  add('snap', can(user, 'snap_upload') || can(user, 'po_receive'), '📦', 'Receive goods & invoice', 'Delivery, invoice photo and the order – together', () => nav.push('ReceiveGoods', {}), C.primary);
  add('cheque', can(user, 'snap_upload') && !!screens.HandCheque, '✍️', 'Hand over a cheque', 'Photo, who took it, which invoices it pays', () => nav.push('HandCheque', {}), C.info);
  add('clock', moduleOn('timeclock') && dev.clockHere, '⏱️', 'Time Clock', 'Staff clock in / out', openClock, C.success);
  add('handover', tillOn && !!screens.Handover && screens.Handover.can(user), '🔁', 'Handover & takeover', 'Count the till, check the team, sign over', () => nav.push('Handover', {}), C.success);
  let duty = null;
  try { if (screens.MyChecklist) duty = memo('duty', user, () => require('../../services/duties.js').myDutyToday(user)); } catch (e) { duty = null; }
  add('checklist', !!duty, '☑️', 'My checklist', duty ? (duty.done ? 'All done for today' : `${duty.ticked} of ${duty.total} done before you finish`) : '', () => nav.push('MyChecklist', {}), duty && !duty.done ? C.warn : C.success, duty && !duty.done ? duty.total - duty.ticked : null);
  add('fccc', moduleOn('inventory') && !!screens.Fccc && screens.Fccc.can(user) && !can(user, 'inventory_manage'), '🏷️', 'FCCC prices', 'Controlled prices – check the shelf', () => nav.push('Fccc', {}), C.warn);
  add('myhours', can(user, 'my_hours') && moduleOn('timesheets'), '🙋', 'My hours', me.state === 'in' ? 'You are clocked in' : 'Hours and leave left', () => nav.push('MyHours'), C.info);
  let ps = null;
  try { const SO = require('../payroll/signoff.js'); if (moduleOn('payroll') && SO.canRunSignoff(user)) ps = memo('ps', user, () => SO.signoffSummary()); } catch (e) { ps = null; }
  add('paysign', !!ps, '✍️', 'Pay sign-off', ps && ps.waiting ? `${ps.waiting} payslip(s) to sign` : 'Staff sign their payslips', () => nav.push('PaySignOff', {}), ps && ps.queries ? C.danger : C.success, ps && ps.waiting ? ps.waiting : null);
  add('payslips', moduleOn('payroll') && can(user, 'my_hours') && !payOn, '🧾', 'My payslips', 'Your pay each week', () => nav.push('MyPayslips'), C.success);

  // The areas
  add('till', areaOk('till'), '💵', 'Sales & tills', till && till.waiting ? `${till.waiting} count(s) to approve` : 'Till counts, End of day, cash, deposits', area('till'), C.warn, till && till.waiting ? till.waiting : null);
  add('inventory', areaOk('inventory'), '📦', 'Stock & orders', inv.length ? inv[0].text : 'Products, orders, stock take, FCCC', area('inventory'), C.brandBlue, inv.filter((a) => a.tone === 'warn').length || null);
  add('payables', areaOk('payables'), '🧾', 'Suppliers & paying', ap && ap.overdue.n ? `${ap.overdue.n} overdue · ${$(ap.overdue.amount)}` : 'Invoices, paying, cheques', area('payables'), C.primary, ap ? (ap.overdue.n + ap.dueToday.n) || null : null);
  const peopleBadge = (toFix || 0) + (leaveWaiting || 0) + (pay && pay.draft ? pay.draft : 0);
  add('people', areaOk('people'), '👥', 'People & pay', [leaveWaiting ? `${leaveWaiting} leave to approve` : '', toFix ? `${toFix} timesheet fix${toFix === 1 ? '' : 'es'}` : '', pay && pay.draft ? 'pay run to finish' : ''].filter(Boolean).join(' · ') || 'Roster, timesheets, leave, payroll', area('people'), C.success, peopleBadge || null);
  add('money', areaOk('money'), '💰', 'Money & accounts', 'Bank, M-PAiSA, loans & rent, VAT, books', area('money'), C.primaryDark);
  add('bakery', areaOk('bakery'), '🥖', 'Bakery', 'Production, stock, wastage', area('bakery'), C.primary);
  let lic = null;
  const licOn = moduleOn('licences') && (can(user, 'licences_view') || can(user, 'licences_manage'));
  if (licOn) { try { lic = memo('lic', user, () => licenceAlerts()); } catch (e) { lic = null; } }
  add('papers', areaOk('papers'), '📁', 'Papers', lic && lic.overdue.length ? `${lic.overdue.length} licence(s) expired!` : lic && lic.due.length ? `${lic.due.length} to renew soon` : 'Licences, documents, vehicles', area('papers'), lic && lic.overdue.length ? C.danger : C.brandBlue, lic ? (lic.overdue.length + lic.due.length) || null : null);

  // Reports & settings
  add('reports', can(user, 'reports'), '📊', 'Reports', 'Every report – PDF · Excel · CSV', () => nav.push('ReportsHub', {}), C.success);
  add('admin', !!screens.Admin && screens.Admin.can(user), '⚙️', 'Settings', 'Every setting in one place, devices, backup', () => nav.push('Admin'), C.primaryDark);
  add('queries', user.role === 'accountant', '❓', 'Ask the owner', 'View only – send a question about a record', () => nav.push('Queries'), C.warn);
  add('help', true, '🧭', 'Help & how-to', 'Every job step by step, and tutorials', () => nav.push('Help'), C.info);

  // Warnings from every module (src/services/alerts.js): the 3 most urgent, then "+ x more".
  let warn = { top: [], more: 0, all: [] };
  try { warn = homeAlerts(realUser || user); } catch (e) { warn = { top: [], more: 0, all: [] }; }

  return (
    <Screen title="Easy Buys" subtitle={`${user.name} · ${ROLE_LABEL[user.role] || user.role}`} right={<SyncIcon />}>
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}><Field testID="home-search" label="Search" value={q} onChangeText={setQ} placeholder="Screen, person, supplier, invoice, PO, cheque…" /></View>
        <Btn testID="home-scan" title="Scan" icon="📷" size="md" variant="info" onPress={() => nav.push('ScanCode', {})} />
      </View>
      <SearchResults q={q} user={realUser || user} screens={screens} nav={nav} />
      {!q ? <QuickLinksBar /> : null}
      {(() => {
        let qs = [];
        try { qs = memo('myq', user, () => require('../verify/queries395.js').openQueriesFor(user.uid)); } catch (e) { qs = []; }
        return qs.length ? (
          <Pressable testID="home-questions" onPress={() => nav.push('MyQueries', {})} style={{ backgroundColor: '#FEF0C7', borderRadius: 14, padding: 12, borderWidth: 2, borderColor: C.warn }}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`❓ ${qs.length} question${qs.length === 1 ? '' : 's'} for you`}</Text>
            <Text style={{ fontSize: 15, color: C.text }} numberOfLines={2}>{`${qs[0].asked_by_name}: ${qs[0].question}`}</Text>
          </Pressable>
        ) : null;
      })()}
      {warn.top.length ? (
        <View testID="home-warnings" style={{ gap: 8 }}>
          {warn.top.map((a) => <AlertCard key={a.id} a={a} onHidden={() => setHid((n) => n + 1)} />)}
          {warn.more ? (
            <Pressable testID="alerts-more" onPress={() => nav.push('Warnings', {})} style={({ pressed }) => ({ alignSelf: 'flex-start', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 12, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.6 : 1 })}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: C.info }}>+ {warn.more} more warning{warn.more === 1 ? '' : 's'}</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
      {GROUPS.map(([g, ids]) => {
        const els = tiles.filter((t) => ids.includes(t.id)).map((t) => t.el);
        return els.length ? <Section key={g} title={g}><Grid>{els}</Grid></Section> : null;
      })}
      {tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).length ? <Grid>{tiles.filter((t) => !GROUPS.some(([, ids]) => ids.includes(t.id))).map((t) => t.el)}</Grid> : null}
      {can(user, 'timesheets_view') && moduleOn('timeclock') ? (
        <Section title={`At work now: ${inNow.length}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{inNow.length ? inNow.map((p) => `${p.name}${p.state === 'break' ? ' (break)' : ''}`).join(', ') : 'Nobody is clocked in.'}</Text>
          {off.length ? <Text style={{ fontSize: 15, color: C.sub }}>On leave today: {off.map((r) => r.name).join(', ')}</Text> : null}
        </Section>
      ) : null}
    </Screen>
  );
}
