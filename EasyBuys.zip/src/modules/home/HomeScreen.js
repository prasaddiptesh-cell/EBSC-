// Home: the tiles each person may use, plus what needs attention today.
import React, { useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Tile, Grid, Banner, Section, useApp, useTick } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { can, deviceSettings, ROLE_LABEL } from '../../services/access.js';
import { dateStr, getSetting, setSetting } from '../../services/core.js';
import { apAlerts, $ } from '../payables/service.js';
import { runRecurring } from '../payables/recurring.js';
import { tillAlerts } from '../till/service.js';
import { payrollAlerts } from '../payroll/service.js';
import { moduleOn } from '../admin/service.js';
import { whoIsIn, stateOf } from '../timeclock/service.js';
import { weekTimesheet } from '../timesheets/service.js';
import { listLeave, whoIsOff } from '../leave/service.js';
import bakery from '../bakery/index.js';

export default function HomeScreen() {
  const { user, nav, openClock } = useApp();
  useTick(30000);
  const dev = deviceSettings();
  const tiles = [];
  const add = (id, cond, icon, title, subtitle, onPress, color, badge) => { if (cond) tiles.push(<Tile key={id} testID={`home-${id}`} icon={icon} title={title} subtitle={subtitle} color={color} onPress={onPress} badge={badge} />); };
  const leaveWaiting = can(user, 'leave_approve') && moduleOn('leave') ? listLeave({ status: 'requested' }).length : 0;
  let toFix = 0;
  if (can(user, 'timesheets_view') && moduleOn('timesheets')) toFix = weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0);
  const inNow = moduleOn('timeclock') ? whoIsIn() : [];
  const off = moduleOn('leave') ? whoIsOff() : [];
  const me = stateOf(user.uid);
  const apOn = moduleOn('payables') && ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(user, p));
  const tillOn = moduleOn('till') && ['till_count', 'till_approve', 'deposits'].some((p) => can(user, p));
  const payOn = moduleOn('payroll') && ['payroll_view', 'payroll_run', 'payroll_setup'].some((p) => can(user, p));
  // Regular bills and loan repayments: make the coming invoices once a day on this device.
  useEffect(() => {
    if (!moduleOn('payables') || getSetting('recurring_ran', '') === dateStr()) return;
    try { runRecurring(null); setSetting('recurring_ran', dateStr()); } catch (e) { /* try tomorrow */ }
  }, []);
  const ap = apOn ? apAlerts() : null;
  const till = tillOn && can(user, 'till_approve') ? tillAlerts() : null;
  const pay = payOn ? payrollAlerts() : null;

  add('clock', moduleOn('timeclock') && dev.clockHere, '⏱️', 'Time Clock', 'Staff clock in / out', openClock, C.success);
  add('myhours', can(user, 'my_hours') && moduleOn('timesheets'), '🙋', 'My hours', me.state === 'in' ? 'You are clocked in' : 'Hours and leave left', () => nav.push('MyHours'), C.info);
  add('timesheets', can(user, 'timesheets_view') && moduleOn('timesheets'), '🗓️', 'Timesheets', 'Sat–Fri weeks, fix, check', () => nav.push('Timesheets', {}), C.brandBlue, toFix || null);
  add('leave', (can(user, 'my_hours') || can(user, 'leave_approve')) && moduleOn('leave'), '🌴', 'Leave', leaveWaiting ? `${leaveWaiting} to approve` : 'Ask, approve, balances', () => nav.push('Leave', {}), C.warn, leaveWaiting || null);
  add('payroll', payOn, '💰', 'Payroll', pay && pay.draft ? `${pay.draft} pay run to finish` : 'Pay runs, payslips, advances', () => nav.push('Payroll'), C.success, pay && pay.draft ? pay.draft : null);
  add('payables', apOn, '🧾', 'Invoices & cheques', ap && ap.overdue.n ? `${ap.overdue.n} overdue · ${$(ap.overdue.amount)}` : 'Invoices, paying, cheque book', () => nav.push('Payables'), C.primary, ap ? (ap.overdue.n + ap.dueToday.n) || null : null);
  add('till', tillOn, '💵', 'Till & cash', till && till.waiting ? `${till.waiting} count(s) to approve` : 'Till counts, deposits, cash', () => nav.push('Till'), C.warn, till && till.waiting ? till.waiting : null);
  add('bank', moduleOn('bank') && can(user, 'bank_rec'), '🏦', 'Bank reconciliation', 'Match the BSP statement', () => nav.push('BankRec', {}), C.brandBlue);
  add('payslips', moduleOn('payroll') && can(user, 'my_hours') && !payOn, '🧾', 'My payslips', 'Your pay each week', () => nav.push('MyPayslips'), C.success);
  add('bakery', can(user, 'bakery') && moduleOn('bakery'), '🥖', 'Bakery', 'Production, stock, shifts', () => nav.push(bakery.homeScreen(user)), C.primary);
  add('staff', can(user, 'staff_manage') || can(user, 'face_enrol'), '👥', 'Staff', 'People, PINs, faces', () => nav.push('Users'), C.info);
  add('reports', can(user, 'reports'), '📊', 'Reports', 'PDF · Excel · CSV', () => nav.push('ReportsHub', {}), C.success);
  add('admin', can(user, 'settings') || can(user, 'roles'), '⚙️', 'Admin', 'Rules, roles, shops, modules', () => nav.push('Admin'), C.primaryDark);
  add('sync', true, '⟳', 'Sync status', 'Every section, Force sync', () => nav.push('SyncStatus'), C.sub);

  return (
    <Screen title="Easy Buys" subtitle={`${user.name} · ${ROLE_LABEL[user.role] || user.role}`}>
      {toFix ? <Banner tone="warn" title={`${toFix} timesheet problem(s) this week`} message="Missing Clock OUT, long shifts or no breaks. Open Timesheets to fix." /> : null}
      {ap && ap.overdue.n ? <Banner tone="danger" title={`${ap.overdue.n} supplier invoice(s) overdue – ${$(ap.overdue.amount)}`} message={ap.dueToday.n ? `${ap.dueToday.n} more due today.` : 'Open Invoices & cheques to pay them.'} /> : null}
      {ap && !ap.overdue.n && ap.dueToday.n ? <Banner tone="warn" title={`${ap.dueToday.n} invoice(s) due today – ${$(ap.dueToday.amount)}`} message="Open Invoices & cheques." /> : null}
      {ap && ap.skipped ? <Banner tone="danger" title="Cheque numbers skipped" message="A cheque leaf is not recorded. Open Invoices & cheques › Cheques & bank › Books." /> : null}
      {till && till.waiting ? <Banner tone="info" title={`${till.waiting} till count(s) to approve`} message="Open Till & cash." /> : null}
      {pay && !pay.confirmed && can(user, 'payroll_setup') ? <Banner tone="warn" title="Payroll: check the tax and FNPF figures" message="Payroll › Rules – tick Checked when done." /> : null}
      {leaveWaiting ? <Banner tone="info" title={`${leaveWaiting} leave request(s) waiting`} message="Open Leave to approve or decline." /> : null}
      <Grid>{tiles}</Grid>
      {can(user, 'timesheets_view') && moduleOn('timeclock') ? (
        <Section title={`At work now: ${inNow.length}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{inNow.length ? inNow.map((p) => `${p.name}${p.state === 'break' ? ' (break)' : ''}`).join(', ') : 'Nobody is clocked in.'}</Text>
          {off.length ? <Text style={{ fontSize: 15, color: C.sub }}>On leave today: {off.map((r) => r.name).join(', ')}</Text> : null}
        </Section>
      ) : null}
    </Screen>
  );
}
