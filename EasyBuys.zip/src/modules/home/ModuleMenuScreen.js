// The menu of one module, always in the same section order: Daily tasks, Records, Checks, Reports, Settings.
// Every feature is its own item (no hidden tabs). Without a module it lists the modules.
import React from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Action, Actions, Hint } from '../../ui/kit.js';
import { visibleMenu, SECTION_HINT } from '../../services/menus.js';
import { getModule, menuModules, allScreens } from '../registry.js';
import { Btn } from '../../ui/components.js';
import { tutorialsForModule } from '../../services/tutorials.js';
import { startTutorial } from '../../ui/TutorialBar.js';
import { can } from '../../services/access.js';
import { AREA_OF_MODULE, getArea } from '../../services/areas.js';

export default function ModuleMenuScreen({ params = {} }) {
  const { nav, realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const mod = params.module ? getModule(params.module) : null;
  if (!mod) {
    const mods = menuModules().filter((m) => visibleMenu(m, who, screens).length);
    return (
      <Screen title="All sections" subtitle="Every part of the app you can use">
        <Actions>
          {mods.map((m) => <Action key={m.id} testID={`mm-${m.id}`} icon={m.icon} title={m.title} onPress={() => nav.push('ModuleMenu', { module: m.id })} />)}
        </Actions>
      </Screen>
    );
  }
  const secs = visibleMenu(mod, who, screens);
  return (
    <Screen title={mod.title} subtitle="Daily tasks · Records · Checks · Reports · Settings">
      {!secs.length ? <Hint>There is nothing here for your login. Ask the owner if you need it.</Hint> : null}
      {(() => {
        let tuts = [];
        try { tuts = tutorialsForModule(who, mod.id); } catch (e) { tuts = []; }
        return tuts.map((t) => <Btn key={t.id} testID={`show-me-${t.id}`} title={`Show me how: ${t.title}`} icon="🎓" size="sm" variant="secondary" onPress={() => startTutorial(t.id)} />);
      })()}
      {secs.map((sec) => {
        // v3.9.5 reports live in Reports and settings in Settings: here they are one link each
        // (shown in full only for someone who cannot open Reports / Settings).
        const areaId = AREA_OF_MODULE[mod.id];
        if (sec.section === 'Reports' && can(who, 'reports') && screens.ReportsHub && screens.ReportsHub.can(who)) {
          const own = sec.items.filter((it) => it.screen !== 'ReportsHub');
          return (
            <Section key={sec.section} title="Reports">
              <Actions>
                <Action testID="mi-reports-link" icon="📊" title={`Reports: ${(getArea(areaId) || mod).title}`} note="Every report in one list – PDF, Excel, print." onPress={() => nav.push('ReportsHub', getArea(areaId) ? { area: areaId } : {})} />
                {own.map((it) => <Action key={it.id} testID={`mi-${it.id}`} icon={it.icon || '›'} title={it.title} note={it.note} onPress={() => nav.push(it.screen, it.params || {})} />)}
              </Actions>
            </Section>
          );
        }
        if (sec.section === 'Settings' && screens.Admin && screens.Admin.can(who)) {
          return (
            <Section key={sec.section} title="Settings">
              <Actions>
                <Action testID="mi-settings-link" icon="⚙️" title={`Settings: ${mod.title}`} note={sec.items.map((it) => it.title).slice(0, 4).join(' · ') + (sec.items.length > 4 ? ' …' : '')} onPress={() => nav.push('Admin', { area: areaId || 'system', module: mod.id })} />
              </Actions>
            </Section>
          );
        }
        return (
        <Section key={sec.section} title={sec.section}>
          <Text style={{ fontSize: 14, color: C.sub, marginTop: -6, marginBottom: 6 }}>{SECTION_HINT[sec.section]}</Text>
          <Actions>
            {sec.items.map((it) => (
              <Action key={it.id} testID={`mi-${it.id}`} icon={it.icon || '›'} title={it.title} note={it.note} onPress={() => nav.push(it.screen, it.params || {})} />
            ))}
          </Actions>
        </Section>
        );
      })}
      <View style={{ height: 8 }} />
    </Screen>
  );
}
