// "My quick links" on Home, and the screen to choose them (★ add / remove, ↑ ↓ order). The owner or admin can make the
// current links the starting links for a role.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Btn, Chips, Field, useApp, useUI } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Hint } from '../../ui/kit.js';
import { allMenuItems } from '../../services/menus.js';
import { ROLES, ROLE_LABEL, actsAsOwner } from '../../services/access.js';
import { quickLinkKeys, resolveQuickLinks, toggleQuickLink, moveQuickLink, resetQuickLinks, setRoleDefaults, MAX_LINKS } from '../../services/quickLinks.js';
import { menuModules, allScreens } from '../registry.js';

export function QuickLinksBar() {
  const { nav, realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  let links = [];
  try { links = resolveQuickLinks(who, allMenuItems(menuModules(), who, ctxScreens || allScreens())); } catch (e) { links = []; }
  return (
    <View testID="quick-links" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {links.map((it) => (
        <Pressable key={it.key} testID={`ql-${it.key}`} onPress={() => nav.push(it.screen, it.params || {})}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 14, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 18 }}>{it.icon || '›'}</Text>
          <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{it.title}</Text>
        </Pressable>
      ))}
      <Pressable testID="ql-edit" onPress={() => nav.push('QuickLinks', {})}
        style={({ pressed }) => ({ paddingVertical: 10, paddingHorizontal: 14, borderRadius: 14, borderWidth: 1, borderStyle: 'dashed', borderColor: C.border, opacity: pressed ? 0.6 : 1 })}>
        <Text style={{ fontSize: 16, color: C.info, fontWeight: '700' }}>{links.length ? '✎ Quick links' : '☆ Add quick links'}</Text>
      </Pressable>
    </View>
  );
}

export default function QuickLinksScreen() {
  const { realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const ui = useUI();
  const [, setTick] = useState(0);
  const [q, setQ] = useState('');
  const [role, setRole] = useState(who.role);
  const items = allMenuItems(menuModules(), who, ctxScreens || allScreens());
  const keys = quickLinkKeys(who);
  const mine = resolveQuickLinks(who, items);
  const redo = (f) => { try { f(); setTick((n) => n + 1); } catch (e) { ui.error(e); } };
  const shown = items.filter((it) => !q || `${it.title} ${it.moduleTitle}`.toLowerCase().includes(q.toLowerCase()));
  const byModule = {};
  shown.forEach((it) => { (byModule[it.moduleTitle] = byModule[it.moduleTitle] || []).push(it); });
  return (
    <Screen title="My quick links" subtitle={`Up to ${MAX_LINKS}, shown at the top of Home on every device you use`}>
      <Section title={`My links (${mine.length}/${MAX_LINKS})`}>
        {!mine.length ? <Hint>None yet – tap ☆ below to add.</Hint> : null}
        {mine.map((it, i) => (
          <View key={it.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
            <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{it.icon} {it.title} <Text style={{ color: C.sub, fontSize: 14 }}>· {it.moduleTitle}</Text></Text>
            <Btn testID={`qlm-up-${it.key}`} title="↑" size="sm" variant="secondary" disabled={i === 0} onPress={() => redo(() => moveQuickLink(who, it.key, -1))} />
            <Btn testID={`qlm-down-${it.key}`} title="↓" size="sm" variant="secondary" disabled={i === mine.length - 1} onPress={() => redo(() => moveQuickLink(who, it.key, 1))} />
            <Btn testID={`qlm-x-${it.key}`} title="✕" size="sm" variant="secondary" onPress={() => redo(() => toggleQuickLink(who, it.key))} />
          </View>
        ))}
        <Btn testID="ql-reset" title="Back to the starting links for my role" size="sm" variant="secondary" onPress={() => redo(() => resetQuickLinks(who))} />
      </Section>
      <Field testID="ql-q" label="Find" value={q} onChangeText={setQ} placeholder="e.g. till, invoice, payslip" />
      {Object.entries(byModule).map(([mod, list]) => (
        <Section key={mod} title={mod}>
          {list.map((it) => {
            const on = keys.includes(it.key);
            return (
              <Pressable key={it.key} testID={`qla-${it.key}`} onPress={() => redo(() => toggleQuickLink(who, it.key))} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8 }}>
                <Text style={{ fontSize: 22, color: on ? C.warn : C.sub }}>{on ? '★' : '☆'}</Text>
                <Text style={{ fontSize: 17, color: C.text }}>{it.icon} {it.title}</Text>
              </Pressable>
            );
          })}
        </Section>
      ))}
      {actsAsOwner(who) || who.role === 'admin' ? (
        <Section title="Starting links for a role (owner / admin)">
          <Hint>New people with this role start with these links; each person can change their own.</Hint>
          <Chips value={role} onChange={setRole} options={ROLES.map((r) => ({ value: r, label: ROLE_LABEL[r] || r }))} testIDPrefix="ql-role" />
          <Btn testID="ql-set-role" title={`Use my links as the starting links for ${ROLE_LABEL[role] || role}`} size="md" variant="info" onPress={() => redo(() => { setRoleDefaults(who, role, keys); ui.toast('Saved'); })} />
        </Section>
      ) : null}
    </Screen>
  );
}
