import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { quickActions, memoMinute } from './shellModel.js';

// 1.0.0 the everyday jobs as big buttons: sign in / out, make a deposit, balance the till (highlighted when an End of
// day from Aronium is waiting). Used on the office Today tab and on a supervisor's staff Home.
export function QuickRow({ who, screens, only }) {
  const { nav, openClock } = useApp();
  const list = (memoMinute('quick', who, () => quickActions(who, screens)) || []).filter((q) => !only || only.includes(q.key));
  if (!list.length) return null;
  return (
    <View testID="quick-row" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {list.map((q) => (
        <Pressable key={q.key} testID={q.testID}
          onPress={() => { if (q.target.action === 'clock') { if (openClock) openClock(); return; } nav.push(q.target.screen, q.target.params || {}); }}
          style={({ pressed }) => ({ flexGrow: 1, flexBasis: 160, minHeight: 92, borderRadius: 16, padding: 14, gap: 4, opacity: pressed ? 0.8 : 1,
            backgroundColor: q.urgent ? C.warn : C.card, borderWidth: q.urgent ? 0 : 1, borderColor: C.border })}>
          <Text style={{ fontSize: 22 }}>{q.icon}</Text>
          <Text style={{ fontSize: 18, fontWeight: '800', color: q.urgent ? '#FFFFFF' : C.text }}>{q.title}</Text>
          <Text style={{ fontSize: 13, color: q.urgent ? '#FFFFFF' : C.sub }} numberOfLines={2}>{q.note}</Text>
        </Pressable>
      ))}
    </View>
  );
}
