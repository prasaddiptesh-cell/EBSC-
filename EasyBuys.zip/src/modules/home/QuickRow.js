import Icon from '../../ui/Icon.js';
import { useSidebar } from '../../ui/WebSidebar.js';
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { quickActions, memoMinute } from './shellModel.js';
import { applyButtonPrefs } from '../../services/quickLinks.js';

// 1.0.0 the everyday jobs as big buttons: sign in / out, make a deposit, balance the till (highlighted when an End of
// day from Aronium is waiting). Used on the office Today tab and on a supervisor's staff Home.
export function QuickRow({ who, screens, only }) {
  const { nav, openClock } = useApp();
  const side = useSidebar();
  // build 22: hidden ones left out and in the person's own order (My quick links › Big buttons)
  const list = applyButtonPrefs(who, (memoMinute('quick', who, () => quickActions(who, screens)) || []).filter((q) => !only || only.includes(q.key)));
  if (!list.length) return null;
  // Release 07 (the new look, as in the approved design): on a computer the big buttons are one row of compact buttons
  // with line icons – the everyday ones (invoice, cheque, delivery) in red, the rest white.
  if (side) {
    const ICON = { invoice: 'invoice', cheque: 'cheque', receive: 'truck', order: 'order', deposit: 'bank', balance: 'till', recharge: 'till', clock: 'today', phone: 'link', addphone: 'link' };
    const RED = ['invoice', 'cheque', 'receive'];
    return (
      <View testID="quick-row" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {list.map((q) => {
          const red = RED.includes(q.key) && !q.urgent;
          const bg = q.urgent ? C.warn : red ? C.brandRed : C.white;
          const fg = q.urgent || red ? C.white : C.text;
          return (
            <Pressable key={q.key} testID={q.testID} accessibilityRole="button" accessibilityHint={q.note}
              onPress={() => { if (q.target.action === 'clock') { if (openClock) openClock(); return; } nav.push(q.target.screen, q.target.params || {}); }}
              style={({ pressed, hovered }) => ({ height: 48, paddingHorizontal: 18, borderRadius: 10, borderWidth: 1, borderColor: q.urgent ? C.warn : red ? C.brandRed : '#D9CFC4',
                backgroundColor: bg, flexDirection: 'row', alignItems: 'center', gap: 8, opacity: pressed ? 0.8 : hovered ? 0.92 : 1 })}>
              <Icon name={ICON[q.key] || 'order'} emoji={q.icon} size={18} color={fg} strokeWidth={1.9} />
              <Text style={{ fontSize: 14, fontWeight: '600', color: fg }}>{q.title}</Text>
            </Pressable>
          );
        })}
      </View>
    );
  }
  // Release 18 (the new look on phones and tablets, as in the approved design): tiles three across – the everyday ones
  // (invoice, cheque, delivery) red, the rest white – each with its icon and a short name.
  const RED2 = ['invoice', 'cheque', 'receive'];
  return (
    <View testID="quick-row" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {list.map((q) => {
        const red = RED2.includes(q.key) && !q.urgent;
        const fg = q.urgent || red ? '#FFFFFF' : C.text;
        return (
          <Pressable key={q.key} testID={q.testID} accessibilityRole="button" accessibilityHint={q.note}
            onPress={() => { if (q.target.action === 'clock') { if (openClock) openClock(); return; } nav.push(q.target.screen, q.target.params || {}); }}
            style={({ pressed }) => ({ flexGrow: 1, flexBasis: '30%', minWidth: 96, minHeight: 88, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 6, gap: 6, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.8 : 1,
              backgroundColor: q.urgent ? C.warn : red ? C.brandRed : C.card, borderWidth: q.urgent || red ? 0 : 1, borderColor: '#E3DDD3' })}>
            <Text style={{ fontSize: 22 }}>{q.icon}</Text>
            <Text style={{ fontSize: 13, fontWeight: '700', color: fg, textAlign: 'center' }} numberOfLines={2}>{q.title}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}
