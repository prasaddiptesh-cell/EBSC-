// Reports from every module, for a period. Opens in the shared report screen (PDF / Excel / CSV / print).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Chips, Field, Grid, Section, Btn, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { can, bakeryRole } from '../../services/access.js';
import { dateStr, clock, weekStart, addDays, getSetting, setSetting } from '../../services/core.js';
import { Hint } from '../../ui/kit.js';
import { allReports } from '../registry.js';

function rangeFor(preset) {
  const now = clock.now();
  const d = dateStr(now);
  if (preset === 'today') return [d, d];
  if (preset === 'thisweek') { const ws = weekStart(d); return [ws, addDays(ws, 6)]; }
  if (preset === 'lastweek') { const ws = addDays(weekStart(d), -7); return [ws, addDays(ws, 6)]; }
  if (preset === 'month') return [`${d.slice(0, 8)}01`, d];
  if (preset === 'lastmonth') {
    const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const last = new Date(now.getFullYear(), now.getMonth(), 0);
    return [dateStr(first), dateStr(last)];
  }
  return null;
}

const favKey = (u) => `fav_reports_${u.uid}`;
export default function ReportsHubScreen({ params }) {
  const { nav, user } = useApp();
  const [preset, setPreset] = useState('thisweek');
  const [[from, to], setRange] = useState(rangeFor('thisweek'));
  const [group, setGroup] = useState(params.group || 'ALL');
  const [q, setQ] = useState('');
  const [favs, setFavs] = useState(() => { try { return JSON.parse(getSetting(favKey(user), '[]')) || []; } catch (e) { return []; } });
  const toggleFav = (id) => { const f = favs.includes(id) ? favs.filter((x) => x !== id) : favs.concat([id]); setFavs(f); setSetting(favKey(user), JSON.stringify(f)); };
  const list = allReports().filter((r) => can(user, r.perm || 'reports') && (!r.costsOnly || bakeryRole(user) !== 'worker'));
  const groups = Array.from(new Set(list.map((r) => r.group)));
  const ql = q.trim().toLowerCase();
  const shown = list.filter((r) => (group === 'ALL' || r.group === group || (group === 'FAV' && favs.includes(r.id))) && (!ql || `${r.title} ${r.desc} ${r.group}`.toLowerCase().includes(ql)));
  const row = (r) => (
    <View key={r.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Pressable testID={`hub-${r.id}`} onPress={() => nav.push('ReportView', { kind: r.id, from, to })}
        style={({ pressed }) => ({ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ fontSize: 26 }}>{r.icon}</Text>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{r.title}</Text>
          <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={2}>{r.desc}</Text>
        </View>
        <Text style={{ fontSize: 22, color: C.sub }}>›</Text>
      </Pressable>
      <Pressable testID={`fav-${r.id}`} onPress={() => toggleFav(r.id)} style={{ padding: 10 }}><Text style={{ fontSize: 24, color: favs.includes(r.id) ? C.warn : C.border }}>★</Text></Pressable>
    </View>
  );
  const sections = group === 'FAV' ? [['★ Favourites', shown]] : (group === 'ALL' ? groups : [group]).map((g) => [g, shown.filter((r) => r.group === g)]);
  return (
    <Screen title="Reports" subtitle="View, print, or export as PDF, Excel or CSV">
      <Hint>Choose the period, then a report. Tap ★ to keep a report at the top under Favourites. The layout (business details, footer, columns) is set in Admin › Report layout.</Hint>
      <Chips value={preset} onChange={(p) => { setPreset(p); const r = rangeFor(p); if (r) setRange(r); }} testIDPrefix="hub-range"
        options={[{ value: 'today', label: 'Today' }, { value: 'thisweek', label: 'This pay week' }, { value: 'lastweek', label: 'Last pay week' }, { value: 'month', label: 'This month' }, { value: 'lastmonth', label: 'Last month' }, { value: 'custom', label: 'Custom' }]} />
      {preset === 'custom' ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <View style={{ flex: 1 }}><Field label="From (YYYY-MM-DD)" value={from} onChangeText={(v) => setRange([v, to])} /></View>
          <View style={{ flex: 1 }}><Field label="To" value={to} onChangeText={(v) => setRange([from, v])} /></View>
        </View>
      ) : <Text style={{ fontSize: 16, color: C.sub }}>{from === to ? from : `${from} to ${to}`}</Text>}
      <Field testID="hub-search" label="Search reports" value={q} onChangeText={setQ} placeholder="e.g. VAT, stock, payslip" />
      <Chips value={group} onChange={setGroup} testIDPrefix="hub-group" options={[{ value: 'ALL', label: 'All' }].concat(favs.length ? [{ value: 'FAV', label: `★ Favourites (${favs.length})` }] : []).concat(groups.map((g) => ({ value: g, label: g })))} />
      {group === 'ALL' && favs.length && !ql ? <Section title="★ Favourites"><View style={{ gap: 8 }}>{list.filter((r) => favs.includes(r.id)).map(row)}</View></Section> : null}
      {sections.filter(([, rs]) => rs.length).map(([g, rs]) => (
        <Section key={g} title={g}><View style={{ gap: 8 }}>{rs.map(row)}</View></Section>
      ))}
      {!shown.length ? <Text style={{ color: C.sub }}>No report matches.</Text> : null}
      {groups.includes('Bakery') ? <Btn title="Bakery shift reports" icon="🥖" size="md" variant="secondary" onPress={() => nav.push('Reports')} /> : null}
    </Screen>
  );
}
