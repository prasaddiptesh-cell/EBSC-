// Reports from every module, for a period. Opens in the shared report screen (PDF / Excel / CSV / print).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Chips, Field, Grid, Section, Btn, useApp, useRemembered } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { can, bakeryRole, pettyCashOn } from '../../services/access.js';
import { getSetting, setSetting } from '../../services/core.js';
import { Hint, PeriodPicker, usePeriod } from '../../ui/kit.js';
import { allReports, menuModules, allScreens } from '../registry.js';
import { getArea, reportScreens, AREA_OF_MODULE } from '../../services/areas.js';
import { rangeProblem } from '../../services/dates.js';

const favKey = (u) => `fav_reports_${u.uid}`;
export default function ReportsHubScreen({ params }) {
  const { nav, user, screens: ctxScreens } = useApp();
  const area = getArea(params && params.area);
  const [from, to, setRange] = usePeriod('thisweek');
  const [group, setGroup] = useRemembered(area ? `group-${area.id}` : 'group', params.group || 'ALL');
  const [q, setQ] = useRemembered('q', '');
  const [favs, setFavs] = useState(() => { try { return JSON.parse(getSetting(favKey(user), '[]')) || []; } catch (e) { return []; } });
  const toggleFav = (id) => { const f = favs.includes(id) ? favs.filter((x) => x !== id) : favs.concat([id]); setFavs(f); setSetting(favKey(user), JSON.stringify(f)); };
  const pettyOn = pettyCashOn(); // 1.0.0 the petty cash report is hidden while petty cash is switched off
  const list = allReports().filter((r) => (pettyOn || r.id !== 'petty_cash') && can(user, r.perm || 'reports') && (!r.costsOnly || bakeryRole(user) !== 'worker') && (!area || area.reportGroups.includes(r.group)));
  // v3.9.5 report screens of the module menus (profit & loss, balance sheet, forecasts, bakery dashboard…) are here too.
  let more = [];
  try { more = reportScreens(user, ctxScreens || allScreens(), menuModules()).filter((it) => !area || it.area === area.id || (area.modules || []).includes(it.module)); } catch (e) { more = []; }
  const groups = Array.from(new Set(list.map((r) => r.group)));
  const ql = q.trim().toLowerCase();
  const shown = list.filter((r) => (group === 'ALL' || r.group === group || (group === 'FAV' && favs.includes(r.id))) && (!ql || `${r.title} ${r.desc} ${r.group}`.toLowerCase().includes(ql)));
  const row = (r) => (
    <View key={r.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Pressable testID={`hub-${r.id}`} onPress={() => nav.push('ReportView', { kind: r.id, from, to })} disabled={!!rangeProblem(from, to)}
        style={({ pressed }) => ({ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ fontSize: 26 }}>{r.icon}</Text>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{r.title}</Text>
          <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={2}>{r.desc}</Text>
        </View>
        <Text style={{ fontSize: 22, color: C.sub }}>›</Text>
      </Pressable>
      <Pressable testID={`fav-${r.id}`} onPress={() => toggleFav(r.id)} style={{ padding: 10 }}><Text style={{ fontSize: 24, color: favs.includes(r.id) ? C.warn : C.border }}>★</Text></Pressable>
    </View>
  );
  const sections = group === 'FAV' ? [['★ Favourites', shown]] : (group === 'ALL' ? groups : [group]).map((g) => [g, shown.filter((r) => r.group === g)]);
  return (
    <Screen title={area ? `Reports: ${area.title}` : 'Reports'} subtitle="View, print, or export as PDF, Excel or CSV">
      <Hint>Choose the period, then a report. Tap ★ to keep a report at the top under Favourites. The layout (business details, footer, columns) is set in Admin › Report layout.</Hint>
      <PeriodPicker testID="hub-period" from={from} to={to} onChange={setRange} />
      <Field testID="hub-search" label="Search reports" value={q} onChangeText={setQ} placeholder="e.g. VAT, stock, payslip" />
      <Chips value={group} onChange={setGroup} testIDPrefix="hub-group" options={[{ value: 'ALL', label: 'All' }].concat(favs.length ? [{ value: 'FAV', label: `★ Favourites (${favs.length})` }] : []).concat(groups.map((g) => ({ value: g, label: g })))} />
      {group === 'ALL' && favs.length && !ql ? <Section title="★ Favourites"><View style={{ gap: 8 }}>{list.filter((r) => favs.includes(r.id)).map(row)}</View></Section> : null}
      {more.length && !ql && group === 'ALL' ? (
        <Section title="Statements & dashboards">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {more.map((it) => (
              <Pressable key={`${it.module}-${it.id}`} testID={`hubs-${it.id}`} onPress={() => nav.push(it.screen, it.params || {})}
                style={({ pressed }) => ({ flexGrow: 1, flexBasis: 240, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 24 }}>{it.icon}</Text>
                <Text style={{ flex: 1, fontSize: 16, fontWeight: '800', color: C.text }} numberOfLines={2}>{it.title}</Text>
                <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
              </Pressable>
            ))}
          </View>
        </Section>
      ) : null}
      {area ? <Btn testID="hub-all" title="All reports" icon="📊" size="md" variant="secondary" onPress={() => nav.replace('ReportsHub', {})} /> : null}
      {sections.filter(([, rs]) => rs.length).map(([g, rs]) => (
        <Section key={g} title={g}><View style={{ gap: 8 }}>{rs.map(row)}</View></Section>
      ))}
      {!shown.length ? <Text style={{ color: C.sub }}>No report matches.</Text> : null}
      {groups.includes('Bakery') ? <Btn title="Bakery shift reports" icon="🥖" size="md" variant="secondary" onPress={() => nav.push('Reports')} /> : null}
    </Screen>
  );
}
