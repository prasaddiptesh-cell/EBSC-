// Reports from every module, for a period. Opens in the shared report screen (PDF / Excel / CSV / print).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Chips, Field, Grid, Section, Btn, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { can, bakeryRole } from '../../services/access.js';
import { dateStr, clock, weekStart, addDays } from '../../services/core.js';
import { allReports } from '../registry.js';

function rangeFor(preset) {
  const now = clock.now();
  const d = dateStr(now);
  if (preset === 'today') return [d, d];
  if (preset === 'thisweek') { const ws = weekStart(d); return [ws, addDays(ws, 6)]; }
  if (preset === 'lastweek') { const ws = addDays(weekStart(d), -7); return [ws, addDays(ws, 6)]; }
  if (preset === 'month') return [`${d.slice(0, 8)}01`, d];
  if (preset === 'lastmonth') {
    const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const last = new Date(now.getFullYear(), now.getMonth(), 0);
    return [dateStr(first), dateStr(last)];
  }
  return null;
}

export default function ReportsHubScreen({ params }) {
  const { nav, user } = useApp();
  const [preset, setPreset] = useState('thisweek');
  const [[from, to], setRange] = useState(rangeFor('thisweek'));
  const [group, setGroup] = useState(params.group || 'ALL');
  const list = allReports().filter((r) => can(user, r.perm || 'reports') && (!r.costsOnly || bakeryRole(user) !== 'worker'));
  const groups = Array.from(new Set(list.map((r) => r.group)));
  const shown = list.filter((r) => group === 'ALL' || r.group === group);
  return (
    <Screen title="Reports" subtitle="View, print, or export as PDF, Excel or CSV">
      <Chips value={preset} onChange={(p) => { setPreset(p); const r = rangeFor(p); if (r) setRange(r); }} testIDPrefix="hub-range"
        options={[{ value: 'today', label: 'Today' }, { value: 'thisweek', label: 'This pay week' }, { value: 'lastweek', label: 'Last pay week' }, { value: 'month', label: 'This month' }, { value: 'lastmonth', label: 'Last month' }, { value: 'custom', label: 'Custom' }]} />
      {preset === 'custom' ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <View style={{ flex: 1 }}><Field label="From (YYYY-MM-DD)" value={from} onChangeText={(v) => setRange([v, to])} /></View>
          <View style={{ flex: 1 }}><Field label="To" value={to} onChangeText={(v) => setRange([from, v])} /></View>
        </View>
      ) : <Text style={{ fontSize: 16, color: C.sub }}>{from === to ? from : `${from} to ${to}`}</Text>}
      <Chips value={group} onChange={setGroup} testIDPrefix="hub-group" options={[{ value: 'ALL', label: 'All' }].concat(groups.map((g) => ({ value: g, label: g })))} />
      {(group === 'ALL' ? groups : [group]).map((g) => (
        <Section key={g} title={g}>
          <Grid>
            {shown.filter((r) => r.group === g).map((r) => (
              <Pressable key={r.id} testID={`hub-${r.id}`} onPress={() => nav.push('ReportView', { kind: r.id, from, to })}
                style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 16, padding: 14, borderWidth: 2, borderColor: C.border, minHeight: 110, opacity: pressed ? 0.7 : 1 })}>
                <Text style={{ fontSize: 30 }}>{r.icon}</Text>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.title}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{r.desc}</Text>
              </Pressable>
            ))}
          </Grid>
        </Section>
      ))}
      {groups.includes('Bakery') ? <Btn title="Bakery shift reports" icon="🥖" size="md" variant="secondary" onPress={() => nav.push('Reports')} /> : null}
    </Screen>
  );
}
