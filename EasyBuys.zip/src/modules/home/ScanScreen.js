// Scan: a document barcode opens that document (if this login may see it); a product barcode shows the product.
// The camera is used on the tablet; a handheld scanner or typing the code works too.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Field, Btn, Banner, Row, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Hint } from '../../ui/kit.js';
import { CodeScanner } from '../../platform/scanner.js';
import { resolveCode } from '../../services/search.js';
import { allScreens } from '../registry.js';

export default function ScanScreen() {
  const { nav, realUser, user, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const [code, setCode] = useState('');
  const [res, setRes] = useState(null);
  const [cam, setCam] = useState(true);
  const look = (c) => {
    const r = resolveCode(who, c, { screens });
    setRes({ ...r, code: c });
    if (r.found && r.allowed && r.kind !== 'product') nav.push(r.nav.screen, r.nav.params || {});
  };
  return (
    <Screen title="Scan" subtitle="Document or product barcode">
      {cam ? <CodeScanner onScan={(c) => { setCode(c); look(c); setCam(false); }} /> : (
        <Btn testID="scan-again" title="Scan another" icon="📷" size="md" variant="info" onPress={() => { setRes(null); setCam(true); }} />
      )}
      <Hint>No camera? Type the number under the barcode, or use a handheld scanner in the box below.</Hint>
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
        <View style={{ flex: 1 }}><Field testID="scan-code" label="Code or number" value={code} onChangeText={setCode} /></View>
        <Btn testID="scan-go" title="Look up" icon="🔎" size="md" onPress={() => look(code)} />
      </View>
      {res && !res.found ? <Banner testID="scan-notfound" tone="warn" title="✗ Not found" message={res.message} /> : null}
      {res && res.found && !res.allowed ? <Banner testID="scan-denied" tone="warn" title={res.title} message="Found, but your login may not open it. Ask the owner or a manager." /> : null}
      {res && res.found && res.kind === 'product' ? (
        <Card>
          <Text testID="scan-product" style={{ fontSize: 20, fontWeight: '800', color: C.text }}>📦 {res.product.name}</Text>
          <Row label="Code" value={res.product.code || '—'} />
          <Row label="Barcode" value={res.product.barcode || '—'} />
          <Row label="Price" value={Number(res.product.price || 0).toFixed(2)} />
          {res.allowed ? <Btn testID="scan-open" title="Open the product" size="md" variant="secondary" onPress={() => nav.push(res.nav.screen, res.nav.params)} /> : null}
        </Card>
      ) : null}
      {res && res.found && res.allowed && res.kind !== 'product' ? <Banner tone="success" title={`✓ ${res.title}`} message="Opened. Tap Back to scan another." /> : null}
    </Screen>
  );
}
