// 1.0.0 staff Home – the only screen shop staff and bakers need: 5 big buttons, a bar on top with the one thing still
// to do, and My week · Home · Messages · My pay at the bottom. Bakers get the bakery buttons: no till money and no
// shop items anywhere. Each button opens the screen that does the job (src/modules/home/shellModel.js HOOKS).
// Also opened as "My shift" by an admin, manager or payroll person who works shifts (with "Office ›" to go back).
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, useApp, useTick, useUI, useLayout } from '../../ui/components.js';
import { SyncIcon } from '../../ui/chrome.js';
import { C } from '../../ui/theme.js';
import { ROLE_LABEL, isBakeryPerson } from '../../services/access.js';
import { moduleOn } from '../admin/service.js';
import { allScreens } from '../registry.js';
import { staffButtons, staffBar, staffTopLine, shellFor } from './shellModel.js';

const COLORS = { start: '#1F7A4D', goods: C.primary, baked: C.primary, happen: '#B25E09', notes: '#2F5DA8', end: '#7A2E8C' };

function Big({ b, onPress }) {
  const { isPhone } = useLayout();
  const off = !b.target;
  return (
    <Pressable testID={b.testID} onPress={onPress} accessibilityRole="button"
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: isPhone ? 150 : 260, minHeight: isPhone ? 118 : 150, backgroundColor: off ? '#EEE9E1' : COLORS[b.key] || C.primary, borderRadius: 20, padding: isPhone ? 14 : 20, gap: 6, justifyContent: 'center', opacity: pressed ? 0.85 : 1 })}>
      <Text style={{ fontSize: isPhone ? 30 : 38 }}>{b.icon}</Text>
      <Text style={{ fontSize: isPhone ? 21 : 25, fontWeight: '900', color: off ? C.sub : '#FFFFFF', lineHeight: isPhone ? 25 : 30 }}>{b.title}</Text>
      <Text style={{ fontSize: isPhone ? 14 : 16, color: off ? C.sub : '#FFFFFF', opacity: 0.92 }}>{off ? 'Ask your supervisor' : b.note}</Text>
    </Pressable>
  );
}

export function StaffBar({ current = 'home' }) {
  const { realUser, user, nav, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const items = staffBar(who, ctxScreens || allScreens());
  return (
    <View testID="staff-bar" style={{ flexDirection: 'row', gap: 6 }}>
      {items.map((it) => {
        const on = it.key === current;
        return (
          <Pressable key={it.key} testID={it.testID} disabled={!it.target} onPress={() => { if (!it.target) return; if (it.target.home) nav.home(); else nav.push(it.target.screen, it.target.params || {}); }}
            style={({ pressed }) => ({ flex: 1, alignItems: 'center', paddingVertical: 6, borderRadius: 12, backgroundColor: on ? C.primarySoft : pressed ? '#F6F2EC' : 'transparent', opacity: it.target ? 1 : 0.4 })}>
            <Text style={{ fontSize: 22 }}>{it.icon}</Text>
            <Text style={{ fontSize: 13, fontWeight: '800', color: on ? C.primary : C.text }} numberOfLines={1}>{it.title}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export default function StaffHome({ asShift = false }) {
  const { user, realUser, nav, openClock, screens: ctxScreens } = useApp();
  const ui = useUI();
  const who = realUser || user;
  useTick(60000);
  const screens = ctxScreens || allScreens();
  const clockOn = moduleOn('timeclock');
  const top = staffTopLine(who, { clockOn });
  const bakery = isBakeryPerson(who);
  const buttons = staffButtons(who, screens, { clockedIn: top.clockedIn !== false, clockOn, bakery });
  const s = shellFor(who);
  const press = (b) => {
    if (!b.target) { ui.alert({ title: b.title, message: 'This is not set up for your login yet. Ask your supervisor or the office.', tone: 'warn' }); return; }
    if (b.target.action === 'clock') { if (asShift) nav.home(); openClock(); return; }
    nav.push(b.target.screen, b.target.params || {});
  };
  const place = bakery ? 'Bakery' : (user.shop_code || '');
  return (
    <Screen title={`Hi ${String(user.name || '').split(' ')[0]}`} subtitle={`${ROLE_LABEL[who.role] || who.role}${place ? ` · ${place}` : ''}`} right={<SyncIcon />} footer={<StaffBar current="home" />}>
      <Pressable testID={top.questions ? 'staff-questions' : 'staff-clock'} onPress={() => { if (top.questions) nav.push('MyQueries', {}); else if (top.clockedIn === false) press(buttons[0]); }}
        style={{ backgroundColor: top.tone === 'warn' ? '#FEF0C7' : '#DDF4E4', borderRadius: 16, padding: 14, borderWidth: 2, borderColor: top.tone === 'warn' ? C.warn : C.success }}>
        <Text testID="staff-todo" style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{top.text}</Text>
      </Pressable>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        {buttons.map((b) => <Big key={b.key} b={b} onPress={() => press(b)} />)}
      </View>
      {asShift ? <Pressable testID="staff-office" onPress={() => nav.home()} style={({ pressed }) => ({ alignSelf: 'stretch', alignItems: 'center', padding: 14, borderRadius: 14, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}><Text style={{ fontSize: 18, fontWeight: '800', color: C.primary }}>Office ›</Text></Pressable> : null}
      {!asShift && s.officeButton ? <Pressable testID="staff-office" onPress={() => nav.push('Office', {})} style={({ pressed }) => ({ alignSelf: 'stretch', alignItems: 'center', padding: 14, borderRadius: 14, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, opacity: pressed ? 0.7 : 1 })}><Text style={{ fontSize: 18, fontWeight: '800', color: C.primary }}>Office ›</Text></Pressable> : null}
    </Screen>
  );
}
