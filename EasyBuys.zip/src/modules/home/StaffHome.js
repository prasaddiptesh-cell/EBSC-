// v3.9.5 Home for shop staff and bakers on the shop tablet: only the daily jobs, big buttons. Each button opens the
// same screen the managers use – there is no separate staff copy. Staff use the shop tablets only (own PIN).
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Btn, useApp, useTick } from '../../ui/components.js';
import { SyncIcon } from '../../ui/chrome.js';
import { AlertCard } from '../../ui/alertsUI.js';
import { homeAlerts } from '../../services/alerts.js';
import { C } from '../../ui/theme.js';
import { can, ROLE_LABEL } from '../../services/access.js';
import { stateOf } from '../timeclock/service.js';
import { moduleOn } from '../admin/service.js';
import { getShared } from '../../services/core.js';
import { getArea, areaView, AREAS } from '../../services/areas.js';
import { getModule, allScreens } from '../registry.js';

export const staffHomeOn = (user) => !!user && ['staff', 'worker'].includes(user.role) && getShared('staff_home', '1') !== '0';

function Big({ testID, icon, title, note, color, ink = '#FFFFFF', onPress, badge }) {
  return (
    <Pressable testID={testID} onPress={onPress}
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: 280, minHeight: 170, backgroundColor: color, borderRadius: 20, padding: 22, gap: 12, borderWidth: color === C.card ? 1 : 0, borderColor: C.border, opacity: pressed ? 0.85 : 1 })}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Text style={{ fontSize: 38 }}>{icon}</Text>
        {badge ? <View style={{ backgroundColor: C.warn, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 2 }}><Text style={{ color: '#fff', fontWeight: '900', fontSize: 15 }}>{badge}</Text></View> : null}
      </View>
      <Text style={{ fontSize: 25, fontWeight: '800', color: ink, lineHeight: 30 }}>{title}</Text>
      {note ? <Text style={{ fontSize: 16, color: ink, opacity: color === C.card ? 1 : 0.9 }}>{note}</Text> : null}
    </Pressable>
  );
}
function Small({ testID, icon, title, onPress, tint, fg }) {
  return (
    <Pressable testID={testID} onPress={onPress}
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: 200, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.border, padding: 14, opacity: pressed ? 0.7 : 1 })}>
      <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: tint, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 20, color: fg }}>{icon}</Text></View>
      <Text style={{ flex: 1, fontSize: 17, fontWeight: '700', color: C.text }}>{title}</Text>
    </Pressable>
  );
}

export default function StaffHome() {
  const { user, realUser, nav, openClock, screens: ctxScreens } = useApp();
  useTick(30000);
  const screens = ctxScreens || allScreens();
  const ok = (name) => { try { return !!screens[name] && screens[name].can(user); } catch (e) { return false; } };
  let me = { state: 'out' };
  try { me = stateOf(user.uid); } catch (e) { me = { state: 'out' }; }
  let duty = null;
  try { duty = require('../../services/duties.js').myDutyToday(user); } catch (e) { duty = null; }
  let questions = [];
  try { questions = require('../verify/queries395.js').openQueriesFor(user.uid); } catch (e) { questions = []; }
  let team = [];
  try { const D = require('../../services/duties.js'); if (D.dutyOf(user) === 'cashier' || can(user, 'till_count')) team = D.teamDuties({ shopCode: user.shop_code, date: require('../../services/core.js').dateStr() }); } catch (e) { team = []; }
  let warn = { top: [] };
  try { warn = homeAlerts(realUser || user); } catch (e) { warn = { top: [] }; }
  const job = (() => { try { const D = require('../../services/duties.js'); return D.DUTIES[D.dutyOf(user)] || ROLE_LABEL[user.role]; } catch (e) { return ROLE_LABEL[user.role]; } })();
  const since = me.state !== 'out' && me.since ? String(me.since).slice(11, 16) : null;
  const bakeryOn = user.role === 'worker' && moduleOn('bakery') && can(user, 'bakery');
  // Other areas only when the person has something there beyond the jobs already on this screen.
  const ON_HOME = ['ReceiveGoods', 'HandCheque', 'MyHours', 'MyRoster', 'Fccc', 'ScanCode', 'MyChecklist', 'MyPayslips', 'Snap', 'MySnaps', 'Handover', 'Leave'];
  const extraAreas = AREAS.filter((a) => a.id !== 'bakery' || !bakeryOn).filter((a) => {
    try { const v = areaView(getArea(a.id), user, screens, getModule); return v.blocks.some((b) => b.daily.concat(b.more).some((it) => !ON_HOME.includes(it.screen))); } catch (e) { return false; }
  });
  return (
    <Screen title={`Hi ${String(user.name || '').split(' ')[0]}`} subtitle={`${job}${user.shop_code ? ` · ${user.shop_code}` : ''}`} right={<SyncIcon />}>
      <View testID="staff-clock" style={{ backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
        <View style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: me.state === 'out' ? '#FEF0C7' : '#DDF4E4', alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 26 }}>⏱️</Text></View>
        <View style={{ flex: 1, minWidth: 180 }}>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{me.state === 'out' ? 'Not clocked in' : me.state === 'break' ? `On a break` : `Clocked in at ${since}`}</Text>
          <Text style={{ fontSize: 15, color: C.sub }}>{me.state === 'out' ? 'Clock in on the Time Clock' : 'Clock out on the Time Clock when you finish'}</Text>
        </View>
        {moduleOn('timeclock') ? <Btn testID="staff-clock-btn" title={me.state === 'out' ? 'Clock in' : 'Clock out'} size="md" variant={me.state === 'out' ? 'success' : 'primary'} onPress={openClock} /> : null}
      </View>
      {questions.length ? (
        <Pressable testID="staff-questions" onPress={() => nav.push('MyQueries', {})} style={{ backgroundColor: '#FEF0C7', borderRadius: 16, padding: 14, borderWidth: 2, borderColor: C.warn }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`❓ ${questions.length} question${questions.length === 1 ? '' : 's'} for you`}</Text>
          <Text style={{ fontSize: 15, color: C.text }}>{`${questions[0].asked_by_name}: ${questions[0].question}`}</Text>
        </Pressable>
      ) : null}
      {warn.top.length ? <View style={{ gap: 8 }}>{warn.top.map((a) => <AlertCard key={a.id} a={a} />)}</View> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14 }}>
        {ok('ReceiveGoods') ? <Big testID="staff-receive" icon="📦" title="Receive goods & invoice" note="Delivery, invoice photo and the order – together" color={C.primary} onPress={() => nav.push('ReceiveGoods', {})} /> : null}
        {ok('HandCheque') ? <Big testID="staff-cheque" icon="✍️" title="Hand over a cheque" note="Photo, who took it, which invoices it pays" color={C.brandBlue || C.info} onPress={() => nav.push('HandCheque', {})} /> : null}
        {bakeryOn ? <Big testID="home-bakery" icon="🥖" title="Bakery" note="Today's batches, wastage, stock" color={C.primary} onPress={() => nav.push('Area', { area: 'bakery' })} /> : null}
        {ok('Handover') && moduleOn('till') ? <Big testID="staff-handover" icon="🔁" title="Handover & takeover" note="Count the till, check the team, sign over" color={C.card} ink={C.text} onPress={() => nav.push('Handover', {})} /> : null}
        {duty ? <Big testID="staff-checklist" icon="☑️" title="My checklist" note={duty.done ? 'All done for today – thank you' : `${duty.ticked} of ${duty.total} done before you finish`} color={C.card} ink={C.text} badge={duty.done ? null : duty.total - duty.ticked} onPress={() => nav.push('MyChecklist', {})} /> : null}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        {ok('Fccc') && moduleOn('inventory') ? <Small testID="staff-fccc" icon="$" title="FCCC prices" tint="#FEF0C7" fg={C.warn} onPress={() => nav.push('Fccc', {})} /> : null}
        {ok('MyHours') ? <Small testID="staff-hours" icon="🕑" title="My hours" tint="#E1EAFB" fg={C.info} onPress={() => nav.push('MyHours', {})} /> : null}
        {ok('ScanCode') ? <Small testID="staff-scan" icon="🔎" title="Scan a price" tint="#DDF4E4" fg={C.success} onPress={() => nav.push('ScanCode', {})} /> : null}
        {ok('MyPayslips') ? <Small testID="staff-payslips" icon="🧾" title="My payslips" tint="#EDE7E3" fg={C.text} onPress={() => nav.push('MyPayslips', {})} /> : null}
        {ok('TeamChecklist') && team.length ? <Small testID="staff-team" icon="👥" title="Shop assistants' checklists" tint="#E1EAFB" fg={C.info} onPress={() => nav.push('TeamChecklist', { shopCode: user.shop_code })} /> : null}
        <Small testID="home-help" icon="🧭" title="Help & how-to" tint="#EDE7E3" fg={C.text} onPress={() => nav.push('Help')} />
      </View>
      {team.length ? (
        <Section title="On this shift with you">
          {team.map((p) => (
            <View key={p.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: p.done ? C.success : C.warn }} />
              <Text style={{ flex: 1, fontSize: 17, fontWeight: '700', color: C.text }}>{p.name}</Text>
              <Text style={{ fontSize: 16, fontWeight: '700', color: p.done ? C.success : C.warn }}>{`Checklist ${p.ticked} of ${p.total}`}</Text>
            </View>
          ))}
        </Section>
      ) : null}
      {extraAreas.length ? (
        <Section title="More">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {extraAreas.map((a) => <Small key={a.id} testID={`home-${a.id}`} icon={a.icon} title={a.title} tint="#F4F1EC" fg={C.text} onPress={() => nav.push('Area', { area: a.id })} />)}
          </View>
        </Section>
      ) : null}
    </Screen>
  );
}
