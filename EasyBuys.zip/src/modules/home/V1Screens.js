// 1.0.0 the small screens of the new shell: Something happened, My week, My shift, Office (for a supervisor),
// a person's permissions (on the staff profile) and the petty cash switch.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Btn, Badge, useApp, useUI } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Hint } from '../../ui/kit.js';
import { allScreens } from '../registry.js';
import { isBakeryPerson, personPermsOf, personPermView, savePersonPerms, mayEditPersonPerms, worksShifts, canBalanceOwnTill, ROLE_LABEL,
  pettyCashOn, setPettyCashOn, can } from '../../services/access.js';
import { getUserByUid } from '../../services/catalog.js';
import * as FL from '../staff/flags.js';
import { happenItems, MY_WEEK_ITEMS } from './shellModel.js';
import StaffHome, { StaffBar } from './StaffHome.js';
import { OfficeHome, Row } from './HomeScreen.js';

const list = { flexDirection: 'row', flexWrap: 'wrap', gap: 10 };

// "Something happened": all the small events of the day in one list (bakers get the bakery list).
export function SomethingHappenedScreen() {
  const { user, realUser, nav, screens: ctxScreens } = useApp();
  const ui = useUI();
  const who = realUser || user;
  const bakery = isBakeryPerson(who);
  const items = happenItems(who, ctxScreens || allScreens(), { bakery });
  return (
    <Screen title="What happened?" subtitle={bakery ? 'Bakery' : 'Pick one'} footer={<StaffBar current="" />}>
      <View style={list}>
        {items.map((it) => (
          <Row key={it.key} it={{ ...it, note: it.target ? it.note : 'Ask your supervisor' }}
            onPress={() => { if (it.target) nav.push(it.target.screen, it.target.params || {}); else ui.alert({ title: it.title, message: 'This is not set up for your login. Tell your supervisor or the office.', tone: 'warn' }); }} />
        ))}
      </View>
    </Screen>
  );
}

// My week: my roster and asking for leave – nothing else (also my hours and payslips).
export function MyWeekScreen() {
  const { user, realUser, nav, screens: ctxScreens } = useApp();
  const who = realUser || user;
  const screens = ctxScreens || allScreens();
  const ok = (n) => !!screens[n] && screens[n].can(who);
  const items = MY_WEEK_ITEMS.filter((it) => ok(it.screen));
  return (
    <Screen title="My week" subtitle="Roster, hours and leave" footer={<StaffBar current="week" />}>
      {!items.length ? <Hint>Nothing here for your login yet.</Hint> : null}
      <View style={list}>{items.map((it) => <Row key={it.id} it={{ ...it, testID: `week-${it.id}` }} onPress={() => nav.push(it.screen, it.params || {})} />)}</View>
    </Screen>
  );
}

// My shift: the staff buttons for an admin, manager or payroll person who works shifts; "Office ›" goes back.
export function MyShiftScreen() { return <StaffHome asShift />; }
// The office Home opened from a supervisor's staff Home ("Office ›").
export function OfficeScreen() { return <OfficeHome />; }

// One person's permissions: works shifts, balance own till, and every permission (role default or changed for them).
export function PersonPermsScreen({ params = {} }) {
  const { user, realUser } = useApp();
  const ui = useUI();
  const who = realUser || user;
  const person = params.uid ? getUserByUid(params.uid) : null;
  const [, bump] = useState(0);
  if (!person) return <Screen title="Permissions"><Hint>Open a person from Staff to see what they may do.</Hint></Screen>;
  const mayEdit = mayEditPersonPerms(who, person.uid);
  const own = personPermsOf(person.uid) || {};
  const view = personPermView(person);
  const state = { grant: (own.grant || []).slice(), deny: (own.deny || []).slice() };
  const save = (next) => {
    try { savePersonPerms(who, person.uid, next); ui.toast('Saved'); bump((n) => n + 1); } catch (e) { ui.error(e); }
  };
  const flip = (key, on, fromRole) => {
    const g = state.grant.filter((k) => k !== key);
    const d = state.deny.filter((k) => k !== key);
    if (on !== fromRole) (on ? g : d).push(key);
    save({ grant: g, deny: d });
  };
  const groups = [];
  view.forEach((p) => { let g = groups.find((x) => x.module === p.module); if (!g) { g = { module: p.module, items: [] }; groups.push(g); } g.items.push(p); });
  const Tick = ({ testID, on, label, sub, onPress, disabled }) => (
    <Pressable testID={testID} disabled={disabled} onPress={onPress} accessibilityRole="checkbox" accessibilityState={{ checked: on, disabled }}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, opacity: pressed ? 0.6 : 1 })}>
      <View style={{ width: 30, height: 30, borderRadius: 8, borderWidth: 2, borderColor: on ? C.success : C.border, backgroundColor: on ? C.success : '#FFFFFF', alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '900' }}>{on ? '✓' : ''}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 16, fontWeight: '700', color: disabled ? C.sub : C.text }}>{label}</Text>
        {sub ? <Text style={{ fontSize: 13, color: C.sub }}>{sub}</Text> : null}
      </View>
    </Pressable>
  );
  return (
    <Screen title={`${person.name} – permissions`} subtitle={ROLE_LABEL[person.role] || person.role}>
      {!mayEdit ? <Hint>Only the owner or an admin changes these (an admin cannot change their own).</Hint> : <Hint>A tick changed here is for this one person only. "role" means it comes with their role; "changed" means it was changed for them.</Hint>}
      {/* Stream B's two switches (src/modules/staff/flags.js) – the same setting B shows on the profile ("Shifts & till") */}
      <Section title="Shifts and till">
        {Object.entries(FL.STAFF_FLAGS).map(([k, f]) => {
          const on = k === 'worksShifts' ? worksShifts(person) : canBalanceOwnTill(person);
          const always = k === 'worksShifts' ? ['staff', 'worker'].includes(person.role) : ['owner', 'admin'].includes(person.role);
          return <Tick key={k} testID={`pp-flag-${k}`} on={on} disabled={!mayEdit || always} label={f.label} sub={always ? 'Always on for this role' : f.help}
            onPress={() => { try { FL.setStaffFlag(who, person.uid, k, !FL.staffFlags(person.uid)[k]); ui.toast('Saved'); bump((n) => n + 1); } catch (e) { ui.error(e); } }} />;
        })}
      </Section>
      {groups.map((g) => (
        <Section key={g.module} title={g.module}>
          {g.items.filter((p) => p.key !== 'till_self_balance').map((p) => (
            <Tick key={p.key} testID={`pp-${p.key}`} on={p.on} disabled={!mayEdit || person.role === 'owner' || (person.role === 'accountant' && !p.on)} label={p.label}
              sub={p.changed ? 'changed for this person' : 'role'} onPress={() => flip(p.key, !p.on, p.fromRole)} />
          ))}
        </Section>
      ))}
    </Screen>
  );
}

// On the staff profile: what this person may do, in one line, and the button to change it.
export function PermissionsSummary({ person }) {
  const { user, realUser, nav } = useApp();
  const who = realUser || user;
  if (!person || !person.uid) return null;
  if (!(can(who, 'staff_manage') || ['owner', 'admin'].includes(who.role))) return null;
  let view = [];
  try { view = personPermView(person); } catch (e) { view = []; }
  const changed = view.filter((p) => p.changed).length;
  const ownTill = canBalanceOwnTill(person);
  return (
    <Section title="Permissions" right={<Btn testID="sp-perms" title={mayEditPersonPerms(who, person.uid) ? 'Change' : 'See'} icon="🔐" size="sm" variant="secondary" onPress={() => nav.push('PersonPerms', { uid: person.uid })} />}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        <Badge text={worksShifts(person) ? 'Works shifts' : 'No shifts'} color={worksShifts(person) ? C.success : C.sub} />
        <Badge text={ownTill ? 'Balances own till' : 'Not own till'} color={ownTill ? C.success : C.sub} />
        <Badge text={changed ? `${changed} changed for this person` : 'As the role'} color={changed ? C.warn : C.sub} />
      </View>
    </Section>
  );
}

// Petty cash: switched off and hidden; the owner / admin can turn it back on here.
export function PettyCashSettingScreen() {
  const { user, realUser } = useApp();
  const ui = useUI();
  const who = realUser || user;
  const [on, setOn] = useState(pettyCashOn());
  const flip = (v) => { try { setPettyCashOn(who, v); setOn(v); ui.toast(v ? 'Petty cash is on' : 'Petty cash is off'); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Petty cash" subtitle={on ? 'On' : 'Off'}>
      <Hint>Petty cash is switched off: small spending is recorded under "Something happened" (paid a supplier in cash) instead. Nothing already recorded is removed.</Hint>
      <Text testID="petty-state" style={{ fontSize: 20, fontWeight: '800', color: on ? C.success : C.sub }}>{on ? 'Petty cash is ON' : 'Petty cash is OFF'}</Text>
      {on ? <Btn testID="petty-off" title="Switch petty cash off" variant="secondary" onPress={() => flip(false)} /> : <Btn testID="petty-on" title="Switch petty cash back on" variant="primary" onPress={() => flip(true)} />}
    </Screen>
  );
}
