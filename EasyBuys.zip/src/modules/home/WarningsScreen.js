// Every warning for this login, most urgent first. Yellow and blue ones can be hidden until tomorrow.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Section, Btn, useApp, useTick } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { Hint } from '../../ui/kit.js';
import { AlertCard } from '../../ui/alertsUI.js';
import { collectAlerts, unhideAll, LEVEL_LABEL, countByLevel } from '../../services/alerts.js';

export default function WarningsScreen() {
  const { realUser, user } = useApp();
  const who = realUser || user;
  useTick(30000);
  const [, setN] = useState(0);
  const shown = collectAlerts(who);
  const all = collectAlerts(who, { includeHidden: true });
  const hidden = all.length - shown.length;
  const c = countByLevel(shown);
  return (
    <Screen title="Warnings" subtitle={`${c.urgent} urgent · ${c.warning} warning${c.warning === 1 ? '' : 's'} · ${c.info} information`}>
      <Hint>Tap a warning to go straight to the place to fix it. Red (urgent) ones stay until they are fixed; yellow and blue ones can be hidden until tomorrow.</Hint>
      {!shown.length ? <Text testID="warnings-none" style={{ fontSize: 17, color: C.success, fontWeight: '700' }}>✓ Nothing needs attention right now.</Text> : null}
      {['urgent', 'warning', 'info'].map((lv) => {
        const list = shown.filter((a) => a.level === lv);
        return list.length ? (
          <Section key={lv} title={LEVEL_LABEL[lv]}>
            <View style={{ gap: 8 }}>{list.map((a) => <AlertCard key={a.id} a={a} onHidden={() => setN((n) => n + 1)} />)}</View>
          </Section>
        ) : null;
      })}
      {hidden ? <Btn testID="warnings-unhide" title={`Show the ${hidden} hidden today`} size="md" variant="secondary" onPress={() => { unhideAll(who); setN((n) => n + 1); }} /> : null}
    </Screen>
  );
}
