// Home module: the launcher and the reports hub.
import HomeScreen from './HomeScreen.js';
import ReportsHubScreen from './ReportsHubScreen.js';
import ModuleMenuScreen from './ModuleMenuScreen.js';
import WarningsScreen from './WarningsScreen.js';
import ScanScreen from './ScanScreen.js';
import QuickLinksScreen from './QuickLinksScreen.js';
import AreaScreen from './AreaScreen.js';
import { HelpScreen, HelpGuideScreen } from './HelpScreens.js';
import { can, actsAsOwner, worksShifts, homeKind } from '../../services/access.js';
import { SomethingHappenedScreen, MyWeekScreen, MyShiftScreen, OfficeScreen, PersonPermsScreen, PettyCashSettingScreen } from './V1Screens.js';
import { OVERVIEW_REPORTS } from './overview.js';

export default {
  id: 'home',
  title: 'Home',
  icon: '🏠',
  screens: {
    Home: { component: HomeScreen, can: (u) => !!u },
    Help: { component: HelpScreen, can: (u) => !!u },
    HelpGuide: { component: HelpGuideScreen, can: (u) => !!u },
    ReportsHub: { component: ReportsHubScreen, can: (u) => can(u, 'reports') },
    ModuleMenu: { component: ModuleMenuScreen, can: (u) => !!u },
    Warnings: { component: WarningsScreen, can: (u) => !!u },
    ScanCode: { component: ScanScreen, can: (u) => !!u },
    QuickLinks: { component: QuickLinksScreen, can: (u) => !!u },
    Area: { component: AreaScreen, can: (u) => !!u },
    // 1.0.0 the new shell
    SomethingHappened: { component: SomethingHappenedScreen, can: (u) => !!u && homeKind(u) !== 'accountant' },
    MyWeek: { component: MyWeekScreen, can: (u) => !!u && homeKind(u) !== 'accountant' },
    MyShift: { component: MyShiftScreen, can: (u) => !!u && homeKind(u) !== 'accountant' && (worksShifts(u) || actsAsOwner(u)) },
    Office: { component: OfficeScreen, can: (u) => !!u && ['supervisor', 'manager', 'payroll', 'admin', 'owner'].includes(u.realRole || u.role) },
    PersonPerms: { component: PersonPermsScreen, can: (u) => !!u && (can(u, 'staff_manage') || ['owner', 'admin'].includes(u.role)) },
    PettyCashSetting: { component: PettyCashSettingScreen, can: (u) => can(u, 'settings') },
  },
  reports: OVERVIEW_REPORTS,
};
