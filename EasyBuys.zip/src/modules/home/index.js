// Home module: the launcher and the reports hub.
import HomeScreen from './HomeScreen.js';
import ReportsHubScreen from './ReportsHubScreen.js';
import ModuleMenuScreen from './ModuleMenuScreen.js';
import WarningsScreen from './WarningsScreen.js';
import ScanScreen from './ScanScreen.js';
import QuickLinksScreen from './QuickLinksScreen.js';
import { can } from '../../services/access.js';
import { OVERVIEW_REPORTS } from './overview.js';

export default {
  id: 'home',
  title: 'Home',
  icon: '🏠',
  screens: {
    Home: { component: HomeScreen, can: (u) => !!u },
    ReportsHub: { component: ReportsHubScreen, can: (u) => can(u, 'reports') },
    ModuleMenu: { component: ModuleMenuScreen, can: (u) => !!u },
    Warnings: { component: WarningsScreen, can: (u) => !!u },
    ScanCode: { component: ScanScreen, can: (u) => !!u },
    QuickLinks: { component: QuickLinksScreen, can: (u) => !!u },
  },
  reports: OVERVIEW_REPORTS,
};
