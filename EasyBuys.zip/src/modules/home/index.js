// Home module: the launcher and the reports hub.
import HomeScreen from './HomeScreen.js';
import ReportsHubScreen from './ReportsHubScreen.js';
import { can } from '../../services/access.js';
import { OVERVIEW_REPORTS } from './overview.js';

export default {
  id: 'home',
  title: 'Home',
  icon: '🏠',
  screens: {
    Home: { component: HomeScreen, can: (u) => !!u },
    ReportsHub: { component: ReportsHubScreen, can: (u) => can(u, 'reports') },
  },
  reports: OVERVIEW_REPORTS,
};
