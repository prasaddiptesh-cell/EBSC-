// Owner's daily summary per shop and the exceptions report (everything unusual, in one place).
import { db } from '../../db/connection.js';
import { stamp, addDays, money } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import { wagesVsSales } from '../timesheets/roster.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const q = (sql, a = []) => { try { return db().all(sql, a); } catch (e) { return []; } };
const one = (sql, a = []) => { try { return db().get(sql, a) || {}; } catch (e) { return {}; } };

export function dailySummary(from, to) {
  const shops = listShops().filter((s) => s.active).map((s) => s.code);
  const rows = shops.map((s) => {
    const till = one(`SELECT COALESCE(SUM(z_total),0) AS sales, COALESCE(SUM(over_short),0) AS os, COUNT(*) AS n, SUM(CASE WHEN status IN ('counted','queried') THEN 1 ELSE 0 END) AS open FROM till_counts WHERE status <> 'void' AND shop_code = ? AND shift_date BETWEEN ? AND ?`, [s, from, to]);
    const inv = one(`SELECT COALESCE(SUM(total),0) AS t, COUNT(*) AS n FROM ap_invoices WHERE status <> 'void' AND kind = 'invoice' AND shop_code = ? AND invoice_date BETWEEN ? AND ?`, [s, from, to]);
    const petty = one(`SELECT COALESCE(SUM(amount),0) AS t FROM cash_moves WHERE status = 'active' AND type = 'petty_out' AND shop_code = ? AND move_date BETWEEN ? AND ?`, [s, from, to]);
    const wo = has('inv_moves') ? one(`SELECT COALESCE(SUM(-qty * COALESCE(unit_cost,0)),0) AS t FROM inv_moves WHERE status = 'active' AND type = 'adjust' AND qty < 0 AND shop_code = ? AND move_date BETWEEN ? AND ?`, [s, from, to]) : {};
    const dep = one(`SELECT COALESCE(SUM(total),0) AS t FROM deposits WHERE status = 'active' AND shop_code = ? AND deposit_date BETWEEN ? AND ?`, [s, from, to]);
    let wages = 0;
    try {
      wages = wagesVsSales({ from, to, shopCode: s }).reduce((a, x) => a + x.cost, 0);
    } catch (e) { wages = 0; }
    return { shop: s, sales: r2(till.sales), overShort: r2(till.os), counts: till.n || 0, open: till.open || 0, purchases: r2(inv.t), petty: r2(petty.t), writeOffs: r2(wo.t), deposited: r2(dep.t), wages: r2(wages),
      wagesPct: till.sales ? r2((wages / till.sales) * 100) : null };
  });
  return rows;
}

export function exceptions(from, to) {
  const out = [];
  const add = (date, area, what, who, amount, why) => out.push({ date, area, what, who: who || '', amount: amount === null || amount === undefined ? '' : $(amount), why: why || '' });
  q(`SELECT * FROM till_counts WHERE status <> 'void' AND over_short < -0.004 AND shift_date BETWEEN ? AND ?`, [from, to]).forEach((c) => add(c.shift_date, 'Till', `${c.shop_code} ${c.till_name || ''} short`, c.cashier_name, c.over_short, c.reason));
  q(`SELECT * FROM till_counts WHERE short_action = 'write_off' AND shift_date BETWEEN ? AND ?`, [from, to]).forEach((c) => add(c.shift_date, 'Till', `Shortage written off ${c.shop_code}`, c.approved_by_name, c.over_short, c.short_note));
  q(`SELECT * FROM audit_log WHERE at BETWEEN ? AND ? AND (action LIKE 'Voided%' OR action LIKE 'Cancelled%' OR action LIKE '%void%' OR action LIKE 'Reopened%' OR action LIKE 'Undid%') ORDER BY at`, [from, `${to} 99`])
    .forEach((a) => add(a.at.slice(0, 10), a.table_name || '', a.action, a.user_name, null, a.reason));
  q(`SELECT p.*, u.name AS staff FROM punches p LEFT JOIN users u ON u.uid = p.user_uid WHERE p.method = 'manual' AND substr(p.at,1,10) BETWEEN ? AND ?`, [from, to])
    .forEach((p) => add(p.at.slice(0, 10), 'Time Clock', `Time added by hand: ${p.type} ${p.at.slice(11, 16)} for ${p.staff || p.name}`, '', null, p.reason));
  q(`SELECT * FROM punches WHERE face_result IN ('no_match','no_face') AND substr(at,1,10) BETWEEN ? AND ?`, [from, to]).forEach((p) => add(p.at.slice(0, 10), 'Time Clock', `Face did not match: ${p.name}`, '', null, ''));
  if (has('inv_moves')) q(`SELECT m.*, i.name FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.status = 'active' AND m.type = 'adjust' AND m.move_date BETWEEN ? AND ?`, [from, to])
    .forEach((m) => add(m.move_date, 'Stock', `Write-off ${m.qty} × ${m.name} (${m.shop_code})`, m.by_name, m.qty * (m.unit_cost || 0), [m.reason, m.note].filter(Boolean).join(' – ')));
  if (has('inv_receipts')) q(`SELECT * FROM inv_receipts WHERE match_note IS NOT NULL AND receive_date BETWEEN ? AND ?`, [from, to]).forEach((r) => add(r.receive_date, 'Deliveries', `Accepted with differences: ${r.supplier_name}`, r.by_name, r.total, r.match_note));
  if (has('po_orders')) q(`SELECT * FROM po_orders WHERE budget_note LIKE 'Over%' AND order_date BETWEEN ? AND ?`, [from, to]).forEach((o) => add(o.order_date, 'Orders', `${o.po_no} ${o.supplier_name} over budget`, o.approved_by_name, o.total, o.budget_note));
  if (has('verifications')) q(`SELECT * FROM verifications WHERE status = 'problem' AND substr(at,1,10) BETWEEN ? AND ?`, [from, to]).forEach((v) => add(v.at.slice(0, 10), 'Verify', `Problem found (${v.table_name})`, v.by_name, null, v.note));
  if (has('safe_counts')) q(`SELECT * FROM safe_counts WHERE ABS(diff) > 0.004 AND count_date BETWEEN ? AND ?`, [from, to]).forEach((s) => add(s.count_date, 'Safe', `Safe count ${s.shop_code} off`, s.by_name, s.diff, s.note));
  if (has('pay_signoffs')) q(`SELECT * FROM pay_signoffs WHERE status = 'query' AND substr(signed_at,1,10) BETWEEN ? AND ?`, [from, to]).forEach((s) => add(s.signed_at.slice(0, 10), 'Payroll', `Pay query: ${s.name}`, '', s.net, s.note));
  if (has('inv_cost_changes')) q(`SELECT c.*, i.name FROM inv_cost_changes c LEFT JOIN inv_items i ON i.uid = c.item_uid WHERE c.new_cost > c.old_cost * 1.1 AND c.change_date BETWEEN ? AND ?`, [from, to])
    .forEach((c) => add(c.change_date, 'Costs', `Cost up over 10%: ${c.name}`, c.supplier_name, c.new_cost - c.old_cost, `${$(c.old_cost)} → ${$(c.new_cost)}`));
  return out.sort((a, b) => (a.date < b.date ? -1 : 1));
}

export const OVERVIEW_REPORTS = [
  { id: 'ov_daily', group: 'Owner overview', icon: '📊', title: 'Daily summary per shop', desc: 'Sales, over/short, wages %, purchases, petty cash, write-offs, deposits', perm: 'reports',
    build(from, to) {
      const rows = dailySummary(from, to);
      const t = (k) => r2(rows.reduce((s, r) => s + r[k], 0));
      return { kind: 'ov_daily', title: 'Daily Summary', fileName: `Daily-summary-${from}${from === to ? '' : `-to-${to}`}`, subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
        info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]],
        summary: [{ label: 'Sales', value: $(t('sales')) }, { label: 'Over / short', value: $(t('overShort')), tone: t('overShort') < 0 ? 'bad' : undefined }, { label: 'Wages', value: $(t('wages')) }, { label: 'Write-offs', value: $(t('writeOffs')), tone: t('writeOffs') ? 'bad' : undefined }],
        sections: [{ title: 'Shops', columns: [col('shop', 'Shop'), col('sales', 'Sales', R), col('os', 'Over/short', R), col('counts', 'Till counts', R), col('open', 'Not approved', R), col('wages', 'Wages', R), col('pct', 'Wages %', R), col('purch', 'Invoices', R), col('petty', 'Petty cash', R), col('wo', 'Write-offs', R), col('dep', 'Deposited', R)],
          rows: rows.map((r) => ({ shop: r.shop, sales: $(r.sales), os: $(r.overShort), counts: r.counts, open: r.open, wages: $(r.wages), pct: r.wagesPct === null ? '' : `${r.wagesPct}%`, purch: $(r.purchases), petty: $(r.petty), wo: $(r.writeOffs), dep: $(r.deposited), _tone: r.overShort < -0.004 ? 'bad' : null })) }] };
    } },
  { id: 'ov_exceptions', group: 'Owner overview', icon: '🚩', title: 'Exceptions', desc: 'Shortages, write-offs, voids, hand-made punches, face mismatches, over-budget orders, problems found', perm: 'audit_view',
    build(from, to) {
      const rows = exceptions(from, to);
      return { kind: 'ov_exceptions', title: 'Exceptions', fileName: `Exceptions-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`, info: [['Period', `${from} to ${to}`], ['Generated', stamp()]],
        summary: [{ label: 'Items', value: String(rows.length), tone: rows.length ? 'bad' : undefined }],
        sections: [{ title: 'Everything unusual', columns: [col('date', 'Date'), col('area', 'Area'), col('what', 'What'), col('who', 'Who'), col('amount', 'Amount', R), col('why', 'Reason given')], rows }] };
    } },
];
