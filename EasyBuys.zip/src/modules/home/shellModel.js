// 1.0.0 the new shell (the map "Try the new app" the owner approved): what each person's Home shows and where each
// button goes. Plain logic, no screens – the Home screens draw it and tests/v1a.test.js checks it.
//
// HOOK POINTS. Other parts of 1.0.0 build some of the pages these buttons open (End shift, Today, Aronium, VAT…).
// Until they exist each button opens the screen that does that job today. To point a button at a new screen, put the
// new screen's name FIRST in its list below – the first one this person may open wins. Nothing else needs to change.
import { can, worksShifts, homeKind, isBakeryPerson } from '../../services/access.js';
import { HUBS, areaView, hubVisible, settingsByArea, reportScreens } from '../../services/areas.js';
import { visibleMenu } from '../../services/menus.js';
import { writeCount } from '../../db/connection.js';
import { stamp } from '../../services/core.js';

const T = (screen, params) => ({ screen, params: params || {} });
export const HOOKS = {
  // ---- staff (shop) – stream B builds Start shift / Handover notes / End shift, stream C "Goods came in"
  START_SHIFT: [T('StartMyShift'), T('MyChecklist')],                    // + clock in first (the Time Clock) when not clocked in
  GOODS_IN: [T('GoodsCameIn'), T('ReceiveGoods')],
  HANDOVER_NOTES: [T('HandoverNotes'), T('Handover')],
  END_SHIFT: [T('EndMyShift'), T('Handover'), T('MyChecklist')],
  // ---- staff (bakery) – stream B
  START_SHIFT_BAKERY: [T('BakeryStartMyShift'), T('StartShift'), T('BakeryToday')], // the bakery's own sign-on (bakery module "StartShift")
  WHAT_WE_BAKED: [T('BakeryToday')],
  HANDOVER_NOTES_BAKERY: [T('HandoverNotes'), T('BakeryToday')],
  END_SHIFT_BAKERY: [T('BakeryEndMyShift'), T('BakeryClose'), T('CloseShift')],
  // ---- "Something happened" (shop) – each opens the existing screen for the job; stream D adds the receipt picker
  DAMAGED: [T('DamagedGoods'), T('ReportDamaged')],
  REFUND: [T('ArReceipts', { pick: 'refund' }), T('Snap', { kind: 'receipt' })], // D: pick the Aronium receipt
  CHEQUE_WRITTEN: [T('ChequeWritten'), T('HandCheque')],
  CASH_PAID: [T('PaidCash'), T('Snap', { kind: 'receipt' })],
  BILL_IN: [T('Bills'), T('Snap', { kind: 'invoice' })],
  VEHICLE: [T('VeFuel'), T('VeFault'), T('VeList')],
  SOMETHING_ELSE: [T('Snap', { kind: 'receipt' })],
  // ---- "Something happened" (bakery) – bakery screens only
  BAKERY_WASTAGE: [T('Wastage')],
  BAKERY_DELIVERED: [T('GoodsCameIn', { what: 'bakery' }), T('Receive')],
  BAKERY_LOW: [T('Stock')],
  BAKERY_MACHINE: [T('Equipment')],
  BAKERY_ELSE: [T('BakeryToday')],
  // ---- bottom bar
  MY_WEEK: [T('MyWeek')],
  MY_PAY: [T('MyPay'), T('MyPayslips')],
  MESSAGES: [T('Warnings')],
  // ---- office – stream C builds Today, D the Aronium place, E the reports, F the guided set-up
  TODAY: [T('OfficeToday')],                           // C: the one list of everything to check (Today tab, first row)
  DAMAGED_WAITING: [T('DamagedWaiting')],             // C: damaged goods waiting for replacement
  DEPOSIT_PLANS: [T('DepositPlans')],                 // C: deposit plans
  STOCK_TAKE: [T('StockTakeJoin'), T('StockTakes')],  // C: everyone joins the one stock take
  DAY_START: [T('DayStart')],
  BUSINESS_TODAY: [T('BusinessToday')],               // E: the "business at a glance" strip on Today
  BOOKS_HOME: [T('BooksHome')],                       // E: the books (Records › The books and the accountant's Books tab)
  BANK_MATCH: [T('BankMatch')],                       // E: line-by-line statement matching
  TILL_CHECK: [T('TillCheck')],                       // B: office check of a till balance (till_approve)
  ARONIUM_HUB: [T('AroniumHub')],                      // D: one "Aronium" page; until then Records › Aronium
  AR_ITEMS: [T('ArItems')],                            // D: items sold by day / shift / till
  AR_PRODUCTS: [T('ArProducts')],                      // D: products from Aronium
  CIGARETTES: [T('CigStatus')],                                      // B: cigarette status page; until then Records › Cigarettes
  MONTH_SUMMARY: [T('MonthSummary'), T('MonthReport')],
  SUPPLIER_STANDINGS: [T('SupplierStandings'), T('Payables')],
  PAYROLL: [T('PayWeek'), T('Payroll')],
  VAT: [T('VatMonth'), T('TaxReturns'), T('VatReturn')],
  FNPF: [T('FnpfMonth'), T('Statutory'), T('Filing')],
  BANK_RECON: [T('ReconMonth'), T('BankMonthEnd'), T('BankRec')],
  FOR_ACCOUNTANT: [T('AccountantFiles'), T('TaxCentre'), T('ReportsHub')],
  MONTH_CLOSE: [T('MonthClose'), T('MonthEnd')],
  DASHBOARD: [T('BizDashboard')],
  SETUP_WIZARD: [T('SetupWizard')],
};

const canOpen = (screens, user, name) => { try { return !!screens && !!screens[name] && screens[name].can(user); } catch (e) { return false; } };
// The first screen of a hook this person may open ({ screen, params }), or null.
export function resolveHook(hook, screens, user) {
  for (const t of HOOKS[hook] || []) if (canOpen(screens, user, t.screen)) return t;
  return null;
}

// ---- worked out at most once a minute (or when something is saved) – Home must never be slow
const memoStore = new Map();
export function memoMinute(name, user, fn) {
  let w = 0;
  try { w = writeCount(); } catch (e) { w = 0; }
  const key = `${user ? user.uid : ''}|${w}|${stamp().slice(0, 16)}`;
  const hit = memoStore.get(name);
  if (hit && hit.key === key) return hit.v;
  let v;
  try { v = fn(); } catch (e) { v = null; }
  memoStore.set(name, { key, v });
  return v;
}
export function clearShellMemo() { memoStore.clear(); }

// ---------------------------------------------------------------- staff Home (the 5 big buttons)
// Each: { key, testID, icon, title, note, target: { screen, params } | { action: 'clock' } | null }
export function staffButtons(user, screens, { clockedIn = true, clockOn = false, bakery = isBakeryPerson(user) } = {}) {
  const t = (h) => resolveHook(h, screens, user);
  if (bakery) {
    return [
      { key: 'start', testID: 'staff-start', icon: '🌅', title: 'Start shift', note: 'Clock in + checklist', target: !clockedIn && clockOn ? { action: 'clock' } : t('START_SHIFT_BAKERY') },
      { key: 'baked', testID: 'home-bakery', icon: '🥖', title: 'What we baked', note: 'Loaves, buns, cakes', target: t('WHAT_WE_BAKED') },
      { key: 'happen', testID: 'staff-happen', icon: '⚠️', title: 'Something happened', note: 'Wastage, ran low, oven problem…', target: { screen: 'SomethingHappened', params: {} } },
      { key: 'notes', testID: 'staff-notes', icon: '📝', title: 'Handover notes', note: 'For the next shift', target: t('HANDOVER_NOTES_BAKERY') },
      { key: 'end', testID: 'staff-end', icon: '✅', title: 'End shift', note: 'Checklist + sign', target: t('END_SHIFT_BAKERY') },
    ];
  }
  return [
    { key: 'start', testID: 'staff-start', icon: '🌅', title: 'Start shift', note: 'Clock in + checklist', target: !clockedIn && clockOn ? { action: 'clock' } : t('START_SHIFT') },
    { key: 'goods', testID: 'staff-receive', icon: '📦', title: 'Goods came in', note: 'Photo of the invoice', target: t('GOODS_IN') },
    { key: 'happen', testID: 'staff-happen', icon: '⚠️', title: 'Something happened', note: 'Damaged, refund, cheque, bill…', target: { screen: 'SomethingHappened', params: {} } },
    { key: 'notes', testID: 'staff-notes', icon: '📝', title: 'Handover notes', note: 'For the next shift', target: t('HANDOVER_NOTES') },
    { key: 'end', testID: 'staff-end', icon: '✅', title: 'End shift', note: 'Count the cash, cigarettes, sign', target: t('END_SHIFT') },
  ];
}

// 1.0.0 (owner, 1 Nov): the everyday jobs of the supervisor / admin as big buttons on top – sign in and out, make a
// deposit, and balance the till as soon as Aronium's End of day is in the app (it says how many are waiting).
export function quickActions(user, screens) {
  const out = [];
  if (!user) return out;
  const open = (n) => canOpen(screens, user, n);
  try { if (require('../admin/service.js').moduleOn('timeclock')) out.push({ key: 'clock', testID: 'quick-clock', icon: '🕑', title: 'Sign in / out', note: 'The Time Clock', target: { action: 'clock' } }); } catch (e) { /* no clock */ }
  let plan = false;
  try { plan = require('../payables/depositPlan.js').mayPlan(user) && open('DepositPlan'); } catch (e) { plan = false; }
  if (plan) out.push({ key: 'deposit', testID: 'quick-deposit', icon: '🏦', title: 'Make a deposit', note: 'Takings, cheques or both', target: { screen: 'DepositPlan', params: {} } });
  if (open('BalanceTill') || open('TillCount')) {
    // 1.0.0 build 2: the simple Balance the till page, for the End of day that came in from a till PC. The button
    // names the shop and the till ("Balance Shop 1 Till 1 – End of day Z 1043 is in"); more than one waiting: a short list.
    let waiting = [];
    try { waiting = require('../till/balanceTill.js').waitingBalances(user); } catch (e) { waiting = []; }
    const e = waiting[0];
    const go = (w) => (w.link && open('BalanceTill') ? w.target : { screen: 'TillCount', params: w.target.params || {} });
    out.push(e
      ? { key: 'balance', testID: 'quick-balance', icon: '💵', urgent: true,
        title: waiting.length > 1 ? `Balance the till (${waiting.length} waiting)` : `Balance ${e.text}`,
        note: waiting.length > 1 ? waiting.map((w) => `${w.shopName.replace(/\s+-\s+.*$/, '')} ${w.tillName}${w.z ? ` Z ${w.z}` : ''}`).join(' · ') : `${e.label}${e.time ? ` · ${e.time}` : ''} · ${e.date}`,
        target: waiting.length > 1 && open('BalanceTill') ? { screen: 'BalanceTill', params: { pick: true } } : go(e) }
      : { key: 'balance', testID: 'quick-balance', icon: '💵', title: 'End of day balancing', note: 'Nothing waiting – it shows here when Aronium\'s End of day comes in', target: { screen: open('BalanceTill') ? 'BalanceTill' : 'TillCount', params: open('BalanceTill') ? { pick: true } : {} } });
  }
  return out;
}
// The bottom bar: My week · Home · Messages · My pay
export function staffBar(user, screens) {
  const t = (h) => resolveHook(h, screens, user);
  return [
    { key: 'week', testID: 'bar-week', icon: '📅', title: 'My week', target: t('MY_WEEK') },
    { key: 'home', testID: 'bar-home', icon: '🏠', title: 'Home', target: { home: true } },
    { key: 'msg', testID: 'bar-messages', icon: '💬', title: 'Messages', target: t('MESSAGES') },
    { key: 'pay', testID: 'bar-pay', icon: '🧾', title: 'My pay', target: t('MY_PAY') },
  ];
}
// "Something happened": shop list, or the bakery-only list.
export function happenItems(user, screens, { bakery = isBakeryPerson(user) } = {}) {
  const t = (h) => resolveHook(h, screens, user);
  const list = bakery ? [
    ['bk-waste', '🗑️', 'Wastage – burnt, spoiled, dropped', 'What and how many', 'BAKERY_WASTAGE'],
    ['bk-delivered', '📥', 'Ingredients delivered', 'Count it into the bakery stock', 'BAKERY_DELIVERED'],
    ['bk-low', '📉', 'Running low / ran out', 'Flour, yeast, margarine…', 'BAKERY_LOW'],
    ['bk-machine', '🔧', 'Oven or machine problem', 'Which one, what is wrong', 'BAKERY_MACHINE'],
    ['bk-else', '✏️', 'Something else', 'Write it for the next shift', 'BAKERY_ELSE'],
  ] : [
    ['damaged', '⚠️', 'Damaged or expired goods', 'Photo + which invoice it came on', 'DAMAGED'],
    ['refund', '↩️', 'Customer refund', 'The receipt from Aronium', 'REFUND'],
    ['cheque', '✍️', 'Cheque written for a supplier', 'Which invoice it pays', 'CHEQUE_WRITTEN'],
    ['cashpaid', '💵', 'Paid a supplier in cash', 'Photo of their receipt', 'CASH_PAID'],
    ['bill', '💡', 'Bill came in (EFL, water, phone)', 'Photo, screenshot or PDF', 'BILL_IN'],
    ['vehicle', '🚚', 'Vehicle – fuel or a fault', 'Drivers only', 'VEHICLE'],
    ['else', '✏️', 'Something else', 'Write it, add a photo', 'SOMETHING_ELSE'],
  ];
  return list.map(([key, icon, title, note, hook]) => ({ key, testID: `happen-${key}`, icon, title, note, hook, target: t(hook) }));
}

// The one thing still to do, on the bar at the top of the staff Home. Worked out at most once a minute.
export function staffTopLine(user, { clockOn = false } = {}) {
  return memoMinute(`top-${user && user.uid}`, user, () => {
    let me = { state: 'out' };
    try { me = require('../timeclock/service.js').stateOf(user.uid); } catch (e) { me = { state: 'in' }; }
    if (clockOn && me.state === 'out') return { tone: 'warn', text: 'Not clocked in yet – tap Start shift', clockedIn: false };
    let duty = null;
    try { duty = require('../../services/duties.js').myDutyToday(user); } catch (e) { duty = null; }
    let qs = [];
    try { qs = require('../verify/queries395.js').openQueriesFor(user.uid); } catch (e) { qs = []; }
    const since = me.state !== 'out' && me.since ? String(me.since).slice(11, 16) : '';
    if (qs.length) return { tone: 'warn', text: `${qs.length} question${qs.length === 1 ? '' : 's'} for you from the office`, clockedIn: me.state !== 'out', since, questions: qs.length };
    if (duty && !duty.done) return { tone: 'warn', text: `Checklist ${duty.ticked} of ${duty.total} – finish it before you go`, clockedIn: me.state !== 'out', since };
    let open = null;
    try { open = require('../till/endShift.js').myOpenShift(user); } catch (e) { open = null; }
    if (open) return { tone: 'ok', text: `Shift started ${String(open.started_at || '').slice(11, 16)} – tap End shift when you finish`, clockedIn: me.state !== 'out', since, openShift: open.uid };
    return { tone: 'ok', text: me.state === 'out' ? 'Nothing waiting for you' : `In since ${since} · nothing waiting – thank you`, clockedIn: me.state !== 'out', since };
  }) || { tone: 'ok', text: '', clockedIn: true };
}

// ---------------------------------------------------------------- Office
export const OFFICE_TABS = [
  { key: 'today', testID: 'office-tab-today', title: 'Today' },
  { key: 'records', testID: 'office-tab-records', title: 'Records' },
  { key: 'reports', testID: 'office-tab-reports', title: 'Reports' },
  { key: 'settings', testID: 'home-admin', title: 'Settings' }, // testID kept from the old Home's Settings tile
];
export const ACCOUNTANT_TABS = [
  { key: 'books', testID: 'acct-tab-books', title: 'Books' },
  { key: 'downloads', testID: 'acct-tab-downloads', title: 'Downloads' },
  { key: 'questions', testID: 'acct-tab-questions', title: 'Questions' },
];
// Who sees what kind of Home, and whether they get "My shift" / "Office ›".
export function shellFor(user) {
  const kind = homeKind(user);
  return {
    kind,
    myShift: kind === 'office' && worksShifts(user),
    officeButton: kind === 'staff' && (user.realRole || user.role) === 'supervisor',
    tabs: kind === 'accountant' ? ACCOUNTANT_TABS : kind === 'office' ? OFFICE_TABS : [],
  };
}

// Records: the hubs this person can use; a hub with its own page (hook) opens that page instead.
export function recordsRows(user, screens, getModule) {
  return HUBS.map((h) => {
    const hooked = h.hook ? resolveHook(h.hook, screens, user) : null;
    let vis = false;
    try { vis = !!hooked || hubVisible(h, user, screens, getModule); } catch (e) { vis = false; }
    if (!vis) return null;
    let note = h.note;
    let warn = false;
    // the old Home "Papers" tile said how many licences are expired / to renew soon – kept on this row
    if (h.id === 'assets') {
      try {
        const A = require('../../services/access.js');
        const on = require('../admin/service.js').moduleOn('licences');
        if (on && (A.can(user, 'licences_view') || A.can(user, 'licences_manage'))) {
          const lic = require('../licences/service.js').licenceAlerts();
          if (lic && lic.overdue.length) { note = `${lic.overdue.length} licence(s) expired!`; warn = true; } else if (lic && lic.due.length) { note = `${lic.due.length} to renew soon · ${h.note}`; warn = true; }
        }
      } catch (e) { /* the usual note */ }
    }
    return { id: h.id, testID: `rec-${h.id}`, icon: h.icon, title: h.title, note, warn, target: hooked || { screen: 'Area', params: { area: h.id } } };
  }).filter(Boolean);
}

// Reports: the few used to make decisions (the map), then every report screen by part of the business.
const REPORT_ROWS = [
  ['month', '📈', 'Month – profit per shop', 'This month against last month and last year', 'MONTH_SUMMARY'],
  ['standings', '🏷️', 'Supplier standings', 'What is still owed to each supplier', 'SUPPLIER_STANDINGS'],
  ['payroll', '💰', 'Payroll', 'This week\'s pay run', 'PAYROLL'],
  ['vat', '🧾', 'VAT return', 'Worked out for FRCS, monthly', 'VAT'],
  ['fnpf', '🏦', 'FNPF', 'Per person per week, and the month', 'FNPF'],
  ['recon', '⚖️', 'Bank reconciliation', 'BSP and both M-PAiSA wallets, month by month', 'BANK_RECON'],
  ['acct', '📤', 'For the accountant', 'Every file she needs', 'FOR_ACCOUNTANT'],
  ['close', '✅', 'Close the month', 'Only when nothing is left open', 'MONTH_CLOSE'],
  ['dash', '📊', 'Dashboard – the business at a glance', 'Sales, money, profit, stock, staff', 'DASHBOARD'],
];
export function reportRows(user, screens, getModule) {
  const out = REPORT_ROWS.map(([key, icon, title, note, hook]) => ({ key, testID: `rep-${key}`, icon, title, note, target: resolveHook(hook, screens, user) })).filter((r) => r.target);
  if (canOpen(screens, user, 'Area')) {
    let v = false;
    try { v = !!getModule && hubVisible(HUBS.find((h) => h.id === 'books'), user, screens, getModule); } catch (e) { v = false; }
    if (v) out.push({ key: 'books', testID: 'rep-books', icon: '📚', title: 'The books – ledgers & financials', note: 'Ledger, journal, trial balance, profit & loss, balance sheet', target: { screen: 'Area', params: { area: 'books' } } });
  }
  return out;
}
// Every report screen and report list of every module (Reports section of the menus), each once.
export function moreReports(user, screens, modules) {
  const out = [];
  const seen = new Set();
  for (const mod of modules) {
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    for (const sec of secs) {
      if (sec.section !== 'Reports') continue;
      for (const it of sec.items) {
        const k = `${it.screen}|${JSON.stringify(it.params || {})}`;
        if (seen.has(k)) continue;
        seen.add(k);
        out.push({ ...it, module: mod.id, moduleTitle: mod.title, testID: it.screen === 'ReportsHub' ? `rep-mi-${it.id}` : `hubs-${it.id}` });
      }
    }
  }
  return out;
}

// The office Today tab until stream C's Today list is in (the daily jobs the old Home had).
export function todayJobs(user, screens) {
  const ok = (n) => canOpen(screens, user, n);
  const rows = [];
  const add = (cond, id, icon, title, note, screen, params) => { if (cond) rows.push({ id, testID: `home-${id}`, icon, title, note, target: { screen, params: params || {} } }); };
  const today = resolveHook('TODAY', screens, user);
  if (today) rows.push({ id: 'today', testID: 'home-today', icon: '✅', title: 'Everything to check today', note: '', target: today });
  { const bt = resolveHook('BUSINESS_TODAY', screens, user); if (bt) rows.push({ id: 'glance', testID: 'home-glance', icon: '📈', title: 'The business at a glance', note: 'Sales, cash, bank, what is owed', target: bt }); }
  { const tc = resolveHook('TILL_CHECK', screens, user); if (tc) {
    let w = [];
    try { w = require('../till/balanceTill.js').waitingBalances(user); } catch (e) { w = []; }
    rows.push({ id: 'tillcheck', testID: 'home-tillcheck', icon: '💵', title: 'Till balances to check', note: w.length ? `Waiting: ${w.slice(0, 3).map((x) => `${x.shopName.replace(/\s+-\s+.*$/, '')} ${x.tillName}${x.z ? ` Z ${x.z}` : ''}`).join(' · ')}` : 'Each shift\'s count against Aronium', target: tc });
  } }
  add(ok('DayStart'), 'daystart', '🌅', 'Start the day', 'Bank, M-PAiSA, what is due, orders to place', 'DayStart');
  add(can(user, 'verify_money') && ok('Verify'), 'verify', '✅', 'To verify', 'Invoices, till balances, cheques, papers', 'Verify');
  add(ok('ReceiveGoods'), 'snap', '📦', 'Receive goods & invoice', 'Delivery, invoice photo and the order', 'ReceiveGoods');
  add(ok('HandCheque'), 'cheque', '✍️', 'Hand over a cheque', 'Photo, who took it, which invoices it pays', 'HandCheque');
  add(ok('Handover') && ['till_count', 'till_approve', 'deposits'].some((p) => can(user, p)), 'handover', '🔁', 'Handover & takeover', 'The day at a shop, signed over', 'Handover');
  add(ok('MyChecklist'), 'checklist', '☑️', 'My checklist', 'Today\'s checklist', 'MyChecklist');
  let signoff = false;
  try { signoff = require('../payroll/signoff.js').canRunSignoff(user) && ok('PaySignOff'); } catch (e) { signoff = false; }
  add(signoff, 'paysign', '✍️', 'Pay sign-off', 'Staff sign their payslips', 'PaySignOff');
  add(ok('Warnings'), 'warnings', '⚠️', 'All warnings', 'Everything that needs attention', 'Warnings');
  return rows;
}

// ---------------------------------------------------------------- everything the new shell reaches
// Every place (screen + params) an owner can get to from the new Home in one or two taps: the Records hubs (main pages
// and drop-downs), the Reports tab, the Settings tab, the Today jobs and the staff pages (My shift / My week).
// tests/v1a.test.js walks every old menu item against this.
export const keyOf = (screen, params) => { const p = { ...(params || {}) }; delete p.shopCode; return `${screen}|${JSON.stringify(p)}`; };
export const MY_WEEK_ITEMS = [
  { id: 'roster', icon: '📅', title: 'My roster', screen: 'MyRoster', params: {} },
  { id: 'hours', icon: '🕑', title: 'My hours', screen: 'MyHours', params: {} },
  { id: 'leave', icon: '🌴', title: 'Ask for leave / I\'m sick', screen: 'Leave', params: { tab: 'mine' } },
  { id: 'payslips', icon: '🧾', title: 'My payslips', screen: 'MyPayslips', params: {} },
];
export function shellDestinations(user, screens, getModule, modules) {
  const out = new Map();
  const put = (screen, params, where) => { if (screen) { const k = keyOf(screen, params); if (!out.has(k)) out.set(k, where); } };
  for (const h of HUBS) {
    let v = null;
    try { v = areaView(h, user, screens, getModule); } catch (e) { v = null; }
    if (!v) continue;
    v.top.forEach((it) => put(it.screen, it.params, `Records › ${h.title}`));
    v.blocks.forEach((b) => b.daily.concat(b.more).forEach((it) => put(it.screen, it.params, `Records › ${h.title} › ${b.title}`)));
    // a link to another module's own menu: everything in it is listed in that module's hub
    v.blocks.forEach((b) => b.daily.concat(b.more).forEach((it) => { if (it.screen === 'ModuleMenu') put('ModuleMenu', it.params, `Records › ${h.title}`); }));
  }
  reportRows(user, screens, getModule).forEach((r) => put(r.target.screen, r.target.params, 'Reports'));
  moreReports(user, screens, modules).forEach((it) => put(it.screen, it.params, 'Reports › by part'));
  try { reportScreens(user, screens, modules).forEach((it) => put(it.screen, it.params, 'Reports › by part')); } catch (e) { /* none */ }
  // Settings tab: every Settings item of every module, and Admin's own pages
  const byArea = settingsByArea(user, screens, modules, []);
  Object.values(byArea).forEach((items) => items.forEach((it) => put(it.screen, it.params, 'Settings')));
  const adm = modules.find((m) => m.id === 'admin');
  if (adm) visibleMenu(adm, user, screens).forEach((sec) => sec.items.forEach((it) => put(it.screen, it.params, 'Settings')));
  put('Admin', {}, 'Settings tab');
  todayJobs(user, screens).forEach((r) => put(r.target.screen, r.target.params, 'Today'));
  MY_WEEK_ITEMS.forEach((it) => put(it.screen, it.params, 'My own pages'));
  return out;
}
