// Warnings for Home: cost changes, orders to approve or late, transfers, stock takes, low stock,
// supplier order reminders (order now / cut-off missed) and changed orders not yet sent to the supplier.
import { can } from '../../services/access.js';
import { invAlerts } from './service.js';
import { orderAlerts } from './schedules.js';
import { amendedNotSent } from './poAmend.js';

const ANY = ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'];
const slug = (t) => String(t).replace(/\d+/g, '').toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
export function alerts(user) {
  if (!ANY.some((p) => can(user, p))) return [];
  const out = invAlerts([]).map((a) => ({ id: `inv-${a.go}-${slug(a.text)}`, level: a.tone === 'warn' ? 'warning' : 'info', text: a.text, nav: { screen: a.go, params: a.params || {} } }));
  out.push(...orderAlerts(user));
  if (can(user, 'po_approve')) {
    for (const o of amendedNotSent()) {
      out.push({ id: `inv-amended-${o.uid}-${o.version}`, level: 'warning', text: `Order ${o.po_no} to ${o.supplier_name} was changed – send the amended order`, nav: { screen: 'POView', params: { uid: o.uid } } });
    }
  }
  return out;
}
