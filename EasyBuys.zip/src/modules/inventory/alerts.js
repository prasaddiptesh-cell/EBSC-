// Warnings for Home: cost changes, orders to approve or late, transfers, stock takes, low stock,
// supplier order reminders (order now / cut-off missed) and changed orders not yet sent to the supplier.
import { can } from '../../services/access.js';
import { invAlerts, highValueDue, expiringSoon, repeatLosers } from './service.js';
import { listShops } from '../admin/service.js';
import { dateStr } from '../../services/core.js';
import { orderAlerts } from './schedules.js';
import { amendedNotSent } from './poAmend.js';

const ANY = ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'];
const slug = (t) => String(t).replace(/\d+/g, '').toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
export function alerts(user) {
  if (!ANY.some((p) => can(user, p))) return [];
  const out = invAlerts([]).map((a) => ({ id: `inv-${a.go}-${slug(a.text)}`, level: a.tone === 'warn' ? 'warning' : 'info', text: a.text, nav: { screen: a.go, params: a.params || {} } }));
  out.push(...orderAlerts(user));
  if (can(user, 'po_approve')) {
    for (const o of amendedNotSent()) {
      out.push({ id: `inv-amended-${o.uid}-${o.version}`, level: 'warning', text: `Order ${o.po_no} to ${o.supplier_name} was changed – send the amended order`, nav: { screen: 'POView', params: { uid: o.uid } } });
    }
  }
  // 1.0 stock take: high-value products due for their weekly count, stock about to expire, products short again and again.
  const shops = (() => { try { return listShops().map((s) => s.code); } catch (e) { return []; } })();
  const mine = user && user.shop_code && !['owner', 'admin'].includes(user.role) ? [user.shop_code] : shops;
  if (can(user, 'stocktake_count') || can(user, 'stocktake_approve')) {
    for (const sc of mine) {
      let due = [];
      try { due = highValueDue(sc); } catch (e) { due = []; }
      if (due.length) out.push({ id: `inv-hv-${sc}-${dateStr().slice(0, 8)}${Math.ceil(Number(dateStr().slice(8, 10)) / 7)}`, level: 'info', text: `${sc}: ${due.length} high-value product${due.length === 1 ? '' : 's'} due for a count`, sub: due.slice(0, 4).map((r) => r.name).join(', '), nav: { screen: 'StockTakes', params: { shopCode: sc, highValue: true } } });
    }
  }
  if (ANY.some((p) => can(user, p))) {
    let exp = [];
    try { exp = expiringSoon({ days: 14 }).filter((e) => mine.includes(e.shop_code)); } catch (e) { exp = []; }
    if (exp.length) out.push({ id: `inv-expiry-${exp[0].expiry}-${exp.length}`, level: 'warning', text: `${exp.length} product${exp.length === 1 ? '' : 's'} expiring within 2 weeks`, sub: exp.slice(0, 3).map((e) => `${e.name} ${e.expiry_qty || ''} (${e.expiry})`).join(', '), nav: { screen: 'StockExpiry', params: {} } });
  }
  if (can(user, 'stocktake_approve')) {
    let rl = [];
    try { rl = repeatLosers({}).filter((r) => mine.includes(r.shopCode)); } catch (e) { rl = []; }
    if (rl.length) out.push({ id: `inv-repeat-${rl.length}-${rl[0].itemUid}`, level: 'warning', text: `${rl.length} product${rl.length === 1 ? ' keeps' : 's keep'} coming up short in stock takes`, sub: rl.slice(0, 3).map((r) => `${r.name} (${r.shopCode})`).join(', '), nav: { screen: 'Shrinkage', params: {} } });
  }
  return out;
}
