// Warnings for Home: cost changes, orders to approve or late, transfers, stock takes, low stock,
// supplier order reminders (order now / cut-off missed) and changed orders not yet sent to the supplier.
import { can } from '../../services/access.js';
import { invAlerts, highValueDue, expiringSoon, repeatLosers, openInitialCounts, vatMismatches, VAT_LABEL } from './service.js';
import { listShops } from '../admin/service.js';
import { dateStr } from '../../services/core.js';
import { orderAlerts } from './schedules.js';
import { amendedNotSent } from './poAmend.js';
import { fcccAlerts } from './fccc.js';

const ANY = ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve'];
const slug = (t) => String(t).replace(/\d+/g, '').toLowerCase().replace(/[^a-z]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
export function alerts(user) {
  // v3.9.3 the first stock take: everyone is asked to help count.
  const help = [];
  try {
    for (const c of openInitialCounts()) help.push({ id: `inv-initial-${c.uid}`, level: 'info', text: `First stock take at ${c.shop_code} – help count`, sub: 'Open it, pick an area, scan and count.', nav: { screen: 'StockCount', params: { uid: c.uid } } });
  } catch (e) { /* none */ }
  if (!ANY.some((p) => can(user, p))) return help;
  const out = invAlerts([]).map((a) => ({ id: `inv-${a.go}-${slug(a.text)}`, level: a.tone === 'warn' ? 'warning' : 'info', text: a.text, nav: { screen: a.go, params: a.params || {} } }));
  out.push(...orderAlerts(user));
  out.push(...fcccAlerts());
  out.push(...help);
  // 1.0.0 owed by suppliers: damaged goods just reported, not told to the supplier, open for over a week
  try { out.push(...require('./supplierOwed.js').owedAlerts()); } catch (e) { /* never stops Home */ }
  try { out.push(...require('./repack.js').repackAlerts()); } catch (e) { /* never stops Home */ }
  // 1.0.0 product cross-checks from the invoices: VAT, selling at / below cost, barcodes to add in Aronium
  if (can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role)) { try { out.push(...require('./productChecks.js').productCheckAlerts(user)); } catch (e) { /* never stops Home */ } }
  // v3.9.8 the FCCC sweep: products that may be controlled, still to answer (Likely / Possible).
  if (can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role)) {
    try { const F2 = require('./fccc.js'); const left = F2.sweepLinks({ limit: 2000 }).filter((x) => x.grade !== 'unlikely'); if (left.length) out.push({ id: `fccc-sweep-${left.length}`, level: left.some((x) => x.over.length) ? 'warning' : 'info', text: `${left.length} product${left.length === 1 ? '' : 's'} may be FCCC-controlled – answer Yes or No`, nav: { screen: 'FcccSweep', params: {} } }); } catch (e) { /* never stops Home */ }
  }
  // v3.9.8 FCCC gas (LPG) prices: new month's prices, priced above the maximum, cylinders not zero-rated.
  try { out.push(...require('./lpg.js').lpgAlerts(user)); } catch (e) { /* never stops Home */ }
  // v3.9.8 Aronium product watch: changes since yesterday, below cost, cost up but price not, no price, shops differ.
  try { out.push(...require('../../services/productWatch.js').watchAlerts(user)); } catch (e) { /* never stops Home */ }
  // v3.9.3 Aronium charges VAT on a product and the app says none (or the other way round).
  try {
    const all = vatMismatches();
    const none = all.filter((x) => x.aronium_vat === 'none');
    const vm = all.filter((x) => x.aronium_vat !== 'none');
    if (none.length) out.push({ id: `inv-notax-${none.length}`, level: 'urgent', text: `${none.length} product${none.length === 1 ? ' has' : 's have'} no tax set in Aronium – set it in Aronium`,
      sub: `${none.slice(0, 5).map((x) => x.name).join(', ')}${none.length > 5 ? '…' : ''}. Sales of these go through Aronium with no VAT worked out.`, nav: { screen: 'VatCheck', params: {} } });
    if (vm.length) out.push({ id: `inv-vat-${vm.length}-${vm.map((x) => x.code).join('').length}`, level: 'warning', text: `${vm.length} product${vm.length === 1 ? '' : 's'}: VAT in Aronium is not the same as in the app`,
      sub: vm.slice(0, 5).map((x) => `${x.name}: Aronium ${VAT_LABEL[x.aronium_vat]}, app ${VAT_LABEL[x.vat_type]}`).join('\n'), nav: { screen: 'VatCheck', params: {} } });
  } catch (e) { /* never stops Home */ }
  if (can(user, 'po_approve')) {
    for (const o of amendedNotSent()) {
      out.push({ id: `inv-amended-${o.uid}-${o.version}`, level: 'warning', text: `Order ${o.po_no} to ${o.supplier_name} was changed – send the amended order`, nav: { screen: 'POView', params: { uid: o.uid } } });
    }
  }
  // 1.0 stock take: high-value products due for their weekly count, stock about to expire, products short again and again.
  const shops = (() => { try { return listShops().map((s) => s.code); } catch (e) { return []; } })();
  const mine = user && user.shop_code && !['owner', 'admin'].includes(user.role) ? [user.shop_code] : shops;
  if (can(user, 'stocktake_count') || can(user, 'stocktake_approve')) {
    for (const sc of mine) {
      let due = [];
      try { due = highValueDue(sc); } catch (e) { due = []; }
      if (due.length) out.push({ id: `inv-hv-${sc}-${dateStr().slice(0, 8)}${Math.ceil(Number(dateStr().slice(8, 10)) / 7)}`, level: 'info', text: `${sc}: ${due.length} high-value product${due.length === 1 ? '' : 's'} due for a count`, sub: due.slice(0, 4).map((r) => r.name).join(', '), nav: { screen: 'StockTakes', params: { shopCode: sc, highValue: true } } });
    }
  }
  if (ANY.some((p) => can(user, p))) {
    let exp = [];
    try { exp = expiringSoon({ days: 14 }).filter((e) => mine.includes(e.shop_code)); } catch (e) { exp = []; }
    if (exp.length) out.push({ id: `inv-expiry-${exp[0].expiry}-${exp.length}`, level: 'warning', text: `${exp.length} product${exp.length === 1 ? '' : 's'} expiring within 2 weeks`, sub: exp.slice(0, 3).map((e) => `${e.name} ${e.expiry_qty || ''} (${e.expiry})`).join(', '), nav: { screen: 'StockExpiry', params: {} } });
  }
  if (can(user, 'stocktake_approve')) {
    let rl = [];
    try { rl = repeatLosers({}).filter((r) => mine.includes(r.shopCode)); } catch (e) { rl = []; }
    if (rl.length) out.push({ id: `inv-repeat-${rl.length}-${rl[0].itemUid}`, level: 'warning', text: `${rl.length} product${rl.length === 1 ? ' keeps' : 's keep'} coming up short in stock takes`, sub: rl.slice(0, 3).map((r) => `${r.name} (${r.shopCode})`).join(', '), nav: { screen: 'Shrinkage', params: {} } });
  }
  return out;
}
