// Suppliers from an Aronium CSV export ("Customers & suppliers"). Matched to the app's suppliers by TIN first, then name.
// Aronium's details win (name, TIN, phone, email); what only the app knows (payment terms, bank, budgets, order schedule…)
// is kept. Customers are skipped. Aronium itself is never written to.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from '../../services/core.js';
import { parseCsv, guessMapping } from './service.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const normName = (s) => txt(s).toLowerCase().replace(/&/g, 'and').replace(/\b(ltd|limited|pte|co|company|the)\b/g, '').replace(/[^a-z0-9]+/g, '');
export const normTin = (s) => txt(s).replace(/[^0-9]/g, '');
const yes = (v) => /^(1|true|yes|y|x|✓)$/i.test(txt(v));

export const SUPPLIER_FIELDS = [
  { key: 'name', label: 'Name', need: true, guess: ['name', 'customer name', 'supplier name', 'company', 'company name', 'business name'] },
  { key: 'code', label: 'Code', guess: ['code', 'customer code', 'id', 'number'] },
  { key: 'tin', label: 'TIN / tax number', guess: ['tax number', 'tin', 'vat number', 'tax no', 'vat no', 'tax id', 'taxnumber'] },
  { key: 'phone', label: 'Phone', guess: ['phone', 'phone number', 'telephone', 'mobile', 'tel'] },
  { key: 'email', label: 'Email', guess: ['email', 'e mail', 'email address'] },
  { key: 'address', label: 'Address', guess: ['address', 'street', 'street name', 'city'] },
  { key: 'contact', label: 'Contact person', guess: ['contact', 'contact person', 'contact name'] },
  { key: 'isSupplier', label: 'Is supplier', guess: ['is supplier', 'supplier', 'issupplier'] },
  { key: 'isCustomer', label: 'Is customer', guess: ['is customer', 'customer', 'iscustomer'] },
  { key: 'type', label: 'Type (customer / supplier)', guess: ['type', 'kind', 'customer type', 'partner type'] },
  { key: 'active', label: 'Enabled', guess: ['enabled', 'active', 'is enabled', 'status'] },
];

function findMatch(tin, name) {
  if (tin) {
    const all = db().all("SELECT * FROM ap_suppliers WHERE tin IS NOT NULL AND tin <> ''");
    const hit = all.find((s) => normTin(s.tin) === tin);
    if (hit) return { s: hit, by: 'TIN' };
  }
  const n = normName(name);
  if (n) {
    const hit = db().all('SELECT * FROM ap_suppliers').find((s) => normName(s.name) === n);
    if (hit) return { s: hit, by: 'name' };
  }
  return null;
}

// Run with dryRun first to show what will change.
export function importSuppliersCsv(user, text, { mapping, dryRun = false } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no rows. In Aronium export the customers & suppliers as CSV and try again.');
  const map = mapping || guessMapping(rows[0], SUPPLIER_FIELDS);
  need(map.name !== undefined, 'Match the "Name" column first.');
  const get = (r, k) => (map[k] === undefined ? '' : txt(r[map[k]]));
  const out = { headers: rows[0], mapping: map, total: rows.length - 1, added: 0, changed: 0, same: 0, customers: 0, errors: [], sample: [] };
  const seen = new Set();
  const now = stamp();
  const dev = deviceId();
  for (let n = 1; n < rows.length; n += 1) {
    const r = rows[n];
    const name = get(r, 'name');
    if (!name) { out.errors.push(`Row ${n + 1}: no name`); continue; }
    // Customers are skipped: a row marked customer and not supplier, or a type column saying customer.
    const type = get(r, 'type').toLowerCase();
    const isSup = map.isSupplier !== undefined ? yes(get(r, 'isSupplier')) : null;
    const isCus = map.isCustomer !== undefined ? yes(get(r, 'isCustomer')) : null;
    if ((type && /customer|client/.test(type) && !/supplier|vendor/.test(type)) || isSup === false || (isCus === true && isSup !== true)) { out.customers += 1; continue; }
    const tin = normTin(get(r, 'tin'));
    const key = tin || normName(name);
    if (seen.has(key)) { out.errors.push(`Row ${n + 1}: ${name} is in the file twice (first one used)`); continue; }
    seen.add(key);
    if (tin && !/^\d{6,15}$/.test(tin)) { out.errors.push(`Row ${n + 1}: ${name} – TIN "${get(r, 'tin')}" looks wrong, not used`); }
    const goodTin = /^\d{6,15}$/.test(tin) ? tin : '';
    const m = findMatch(goodTin, name);
    const fresh = { name, tin: goodTin || null, phone: get(r, 'phone') || null, email: get(r, 'email') || null, contact: get(r, 'contact') || null };
    const activeTxt = get(r, 'active');
    const active = !activeTxt || !/^(0|false|no|inactive|disabled)$/i.test(activeTxt);
    // Another supplier already has this name (different TIN): cannot rename onto it.
    const clash = db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?) AND uid <> ?', [name, m ? m.s.uid : '']);
    if (clash) { out.errors.push(`Row ${n + 1}: another supplier is already called ${name} – check the TIN in Aronium`); continue; }
    let changedFields = [];
    if (m) {
      const b = m.s;
      // Aronium wins where it has a value; empty cells keep what the app has.
      changedFields = ['name', 'tin', 'phone', 'email', 'contact'].filter((k) => fresh[k] && txt(fresh[k]) !== txt(b[k]));
      if (!active && b.active) changedFields.push('active');
      if (changedFields.length) out.changed += 1; else out.same += 1;
    } else out.added += 1;
    if (out.sample.length < 8) out.sample.push({ name, tin: goodTin, match: m ? `${m.s.name} (by ${m.by})` : 'new', changes: changedFields });
    if (dryRun) continue;
    let uid;
    if (m) {
      uid = m.s.uid;
      if (changedFields.length) {
        const v = { ...m.s };
        for (const k of changedFields) v[k] = k === 'active' ? 0 : fresh[k];
        db().run(`UPDATE ap_suppliers SET name = ?, tin = ?, phone = ?, email = ?, contact = ?, active = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
          [v.name, v.tin, v.phone, v.email, v.contact, v.active, now, dev, uid]);
        if (v.name !== m.s.name) db().run("UPDATE ap_invoices SET supplier_name = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE supplier_uid = ?", [v.name, now, dev, uid]);
        audit({ user, action: `Supplier ${m.s.name} updated from Aronium: ${changedFields.join(', ')}`, table: 'ap_suppliers', recordUid: uid,
          before: Object.fromEntries(changedFields.map((k) => [k, m.s[k]])), after: Object.fromEntries(changedFields.map((k) => [k, v[k]])) });
      }
    } else {
      uid = uuid('S');
      db().run(`INSERT INTO ap_suppliers (uid, name, tin, vat_registered, on_account, terms_days, pay_method, contact, phone, email, active, notes, updated_at, updated_device)
        VALUES (?,?,?,?,0,7,'cheque',?,?,?,?,?,?,?)`, [uid, name, fresh.tin, 1, fresh.contact, fresh.phone, fresh.email, active ? 1 : 0, 'Added from Aronium', now, dev]);
      audit({ user, action: `Supplier ${name} added from Aronium${fresh.tin ? ` (TIN ${fresh.tin})` : ''}`, table: 'ap_suppliers', recordUid: uid });
    }
    const link = `AS-${uid}`;
    db().run(`INSERT INTO aronium_suppliers (uid, supplier_uid, code, name, tin, address, phone, email, imported_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(uid) DO UPDATE SET code = excluded.code, name = excluded.name, tin = excluded.tin, address = excluded.address, phone = excluded.phone, email = excluded.email,
      imported_at = excluded.imported_at, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [link, uid, get(r, 'code') || null, name, goodTin || null, get(r, 'address') || null, fresh.phone, fresh.email, now, now, dev]);
  }
  if (!dryRun) audit({ user, action: `Imported suppliers from Aronium: ${out.added} new, ${out.changed} changed, ${out.customers} customers skipped`, table: 'ap_suppliers' });
  return out;
  });
}
export function aroniumSupplier(supplierUid) {
  return db().get('SELECT * FROM aronium_suppliers WHERE supplier_uid = ?', [supplierUid]) || null;
}
