// 1.0.0 App vs Aronium, per shop, and the Aronium update file.
// After a shop's opening stock take the app keeps that shop's selling prices, the cost prices (from the invoices),
// VAT and suppliers. Each shop's Aronium (its till PC) is compared with the app; the differences are either taken
// into the app ("Aronium is right") or put in a CSV for Aronium's own product import:
//   Aronium › Management › Products › Import › choose the file › Merge duplicates › Preview › Import.
// The file follows Aronium's documented import columns (help.aronium.com "Import products using CSV"):
//   comma separated, a header row, decimals with a point, several barcodes joined with "|", taxes as "Name:rate".
//   Every row is the product exactly as that Aronium has it now (name, code, group, unit, barcodes, flags) with only
//   the app's price / cost / tax (and new barcodes, added to Aronium's) put in – so nothing else changes. There is NO Quantity column: Aronium's import ADDS a
//   quantity to the stock, and the stock is kept in the app.
// Supplier is not a column in Aronium's product import, so suppliers stay in the app (the orders use them).
import { db } from '../../db/connection.js';
import { AppError, stamp, dateStr, audit, getShared, setShared } from '../../services/core.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
const need = (c, m) => { if (!c) throw new AppError(m); };
const I = () => require('./service.js');
const L = () => require('../aronium/link.js');
const VAT_RATE = 12.5;
const appRate = (vt) => (vt === 'standard' ? VAT_RATE : 0);

export const COLUMNS = ['Name', 'Product group', 'SKU', 'Barcode', 'Measurement Unit', 'Cost', 'Markup', 'Price', 'Tax', 'Tax Inclusive Price', 'Price Change Allowed', 'Using Default Quantity', 'Service', 'Enabled', 'Description'];

// Every product of a shop: the app's values next to that shop's Aronium.
export function compareShop(shopCode) {
  const ar = L().aroniumProducts(shopCode);
  const out = [];
  for (const p of ar.items || []) {
    if (!p || !txt(p.code) || p.service) continue;
    const it = I().findItem(txt(p.code));
    if (!it) continue;
    const a = I().itemAtShop(it.uid, shopCode) || {};
    const arRate = p.vat_rate === null || p.vat_rate === undefined ? null : Number(p.vat_rate) || 0;
    const diffs = [];
    if (a.shopPrice !== null && a.shopPrice !== undefined && Number(a.shopPrice) > 0 && Math.abs(Number(a.shopPrice) - Number(p.price || 0)) > 0.004) diffs.push('price');
    if (Number(a.cost) > 0 && Math.abs(Number(a.cost) - Number(p.cost || 0)) > 0.00005) diffs.push('cost');
    if (arRate === null || Math.abs(appRate(a.vat_type || 'standard') - arRate) > 0.001) diffs.push('vat');
    // barcodes put on the product in the app (found at the stock take, or a shop barcode made for it) that Aronium lacks
    const arCodes = new Set((p.barcodes || []).map((x) => txt(x)));
    const extra = txt(a.barcode).split(',').map((x) => x.trim()).filter((x) => x && !arCodes.has(x));
    if (extra.length) diffs.push('barcode');
    if (diffs.length) out.push({ itemUid: it.uid, code: txt(p.code), name: p.name, diffs, app: { price: r2(a.shopPrice), cost: r4(a.cost), vat: a.vat_type || 'standard', barcodes: extra }, aronium: { price: r2(p.price), cost: r4(p.cost), rate: arRate }, p });
  }
  return { shop: shopCode, source: ar.source, taxes: ar.taxes || [], rows: out.sort((x, y) => x.name.localeCompare(y.name)), products: (ar.items || []).length, master: I().appIsMaster(shopCode) };
}
// "Aronium is right": take Aronium's value into the app for this shop (price) / product (cost, VAT).
export function takeAronium(user, shopCode, itemUid, what) {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner decides which price is right.');
  const row = compareShop(shopCode).rows.find((r) => r.itemUid === itemUid);
  need(row, 'The app and Aronium already agree.');
  const { deviceId } = require('../../services/core.js');
  if (what === 'price') {
    const s = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
    if (s) db().run("UPDATE inv_item_shops SET price = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE item_uid = ? AND shop_code = ?", [row.aronium.price, stamp(), deviceId(), itemUid, shopCode]);
    else I().saveItemShop(null, { itemUid, shopCode, active: true, price: row.aronium.price });
  } else if (what === 'cost') {
    db().run("UPDATE inv_items SET cost = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [row.aronium.cost, stamp(), deviceId(), itemUid]);
  } else if (what === 'vat') {
    need(row.aronium.rate !== null, 'No tax is set in Aronium – set it there.');
    I().useAroniumVat(user, itemUid);
  } else throw new AppError('Choose price, cost or VAT.');
  audit({ user, action: `${shopCode} ${row.name}: Aronium's ${what} taken into the app`, table: 'inv_items', recordUid: itemUid });
  return compareShop(shopCode);
}

// The tax as Aronium writes it: "Name:rate" from that shop's own taxes (matched by rate; zero rated / exempt by name).
function taxFor(vt, taxes) {
  const rate = appRate(vt);
  const same = (taxes || []).filter((t) => Math.abs(Number(t.rate) - rate) < 0.001);
  const pick = vt === 'exempt' ? same.find((t) => /exempt|free|non/i.test(t.name)) : vt === 'zero' ? same.find((t) => /zero|0\s*%/i.test(t.name)) : null;
  const t = pick || same[0];
  return t ? { text: `${t.name}:${fmt(rate)}`, known: true } : { text: `${vt === 'standard' ? 'VAT 12.5%' : vt === 'exempt' ? 'VAT Exempt' : 'Zero Rated'}:${fmt(rate)}`, known: false };
}
function fmt(n) { const x = Math.round(Number(n) * 10000) / 10000; return String(x); } // always a point, never a comma
const cell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
const b = (v, d) => (v === null || v === undefined ? d : v ? 1 : 0);

// The update file for one shop. only: 'all' differences, or a list of item uids; test: just the first product.
export function updateFile(shopCode, { only = null, test = false } = {}) {
  const cmp = compareShop(shopCode);
  need(cmp.source, `No product list from ${shopCode}'s till PC yet – it comes with the Aronium Link.`);
  let rows = cmp.rows.filter((r) => !only || only.includes(r.itemUid));
  if (test) rows = rows.slice(0, 1);
  const warnings = [];
  const lines = [COLUMNS.join(',')];
  for (const r of rows) {
    const p = r.p;
    const price = r.diffs.includes('price') ? r.app.price : r2(p.price);
    const cost = r.diffs.includes('cost') ? r.app.cost : r4(p.cost);
    const vt = r.diffs.includes('vat') ? r.app.vat : null;
    const tax = vt ? taxFor(vt, cmp.taxes) : null;
    if (tax && !tax.known) warnings.push(`${cmp.shop}'s Aronium has no ${vt === 'standard' ? '12.5%' : '0%'} tax yet – Aronium makes "${tax.text}" by itself, or add it in Aronium first (Settings › Taxes).`);
    const taxText = tax ? tax.text : (Array.isArray(p.taxes) && p.taxes.length ? p.taxes.join('|') : '');
    const incl = p.price_includes_vat === false ? 0 : 1;
    // the markup that goes with the new price and cost, so Aronium does not work the price out again from the old one
    const rate = vt ? appRate(vt) : (p.vat_rate || 0);
    const net = incl ? price / (1 + rate / 100) : price;
    const markup = cost > 0 ? r2(((net - cost) / cost) * 100) : (p.markup === null || p.markup === undefined ? '' : p.markup);
    lines.push([p.name, p.group || '', r.code, (p.barcodes || []).concat(r.diffs.includes('barcode') ? r.app.barcodes : []).join('|'), p.unit || '', fmt(cost), markup === '' ? '' : fmt(markup), fmt(price), taxText, incl,
      b(p.price_change, 0), b(p.default_qty, 1), b(p.service, 0), b(p.enabled, 1), p.desc || ''].map(cell).join(','));
  }
  const name = `Aronium-update-${shopCode}-${dateStr()}${test ? '-TEST' : ''}.csv`;
  return { name, text: `${lines.join('\r\n')}\r\n`, rows: rows.length, warnings: [...new Set(warnings)], shop: shopCode,
    counts: { price: rows.filter((r) => r.diffs.includes('price')).length, cost: rows.filter((r) => r.diffs.includes('cost')).length, vat: rows.filter((r) => r.diffs.includes('vat')).length, barcode: rows.filter((r) => r.diffs.includes('barcode')).length } };
}
export function noteMade(user, f) {
  const log = (getShared('aronium_update_files', null) || {}).list || [];
  log.push({ shop: f.shop, name: f.name, rows: f.rows, by: user ? user.name : null, at: stamp() });
  setShared('aronium_update_files', { list: log.slice(-50) });
  if (user) audit({ user, action: `Aronium update file for ${f.shop}: ${f.rows} product(s) (${f.counts.price} price, ${f.counts.cost} cost, ${f.counts.vat} VAT)`, table: 'shared_settings', recordUid: 'aronium_update_files' });
}
export function filesMade() { return (getShared('aronium_update_files', null) || {}).list || []; }
