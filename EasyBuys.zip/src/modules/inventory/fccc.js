// v3.9.3 FCCC price-controlled products.
// The Fijian Competition & Consumer Commission (FCCC) sets the highest price some products may be sold at. It publishes
// the "Master Price List" as PDFs on its website, each named "… Master Price List as at DD.MM.YYYY.pdf".
//  • Each device (when online) looks at the FCCC pages a few times a day. A list with a new date → a warning on Home and
//    a phone notification, with the PDF to open. Nothing is written anywhere but this app.
//  • Products are marked "FCCC controlled" with the FCCC price. Any shop selling one above that price (the price comes from
//    the Aronium product import) is a red warning: change it in Aronium.
//  • Someone goes through the new list and ticks it as checked (name and time kept).
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, getShared, setShared, getSetting, setSetting } from '../../services/core.js';
import { can } from '../../services/access.js';
import { pdfTextItems, pdfLines } from '../../services/pdfText.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = (t) => { try { return !!db().get("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const FCCC_SQL = `
CREATE TABLE IF NOT EXISTS fccc_lists (
  uid TEXT PRIMARY KEY,
  list_name TEXT NOT NULL,
  as_at TEXT NOT NULL,
  url TEXT NOT NULL,
  found_at TEXT,
  checked_by_name TEXT,
  checked_at TEXT,
  check_note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_fccc_asat ON fccc_lists(as_at);
-- The lines read from each list's PDF (on this device only; every device reads the list itself).
CREATE TABLE IF NOT EXISTS fccc_lines (
  list_uid TEXT NOT NULL,
  row_key TEXT NOT NULL,
  section TEXT, description TEXT, qty TEXT,
  w TEXT, r TEXT, page INTEGER, sort INTEGER,
  PRIMARY KEY (list_uid, row_key)
);
`;
export const FCCC_SYNC = {
  fccc_lists: { key: 'uid', section: 'Inventory', cols: ['uid', 'list_name', 'as_at', 'url', 'found_at', 'checked_by_name', 'checked_at', 'check_note', 'updated_at', 'updated_device'] },
};
// Product columns (added by columns.js): fccc (1 = controlled), fccc_max (highest price incl. VAT), fccc_name, fccc_set_at,
// fccc_key (the line on the FCCC list: description|size) and fccc_list (which list, e.g. Basic Food Items).

export const FCCC_DEFAULT_PAGES = [
  'https://fccc.gov.fj/master-price-list/basic-food-items/',
  'https://fccc.gov.fj/master-price-list/hardware/',
];
export function fcccStatus() { return { lastOk: getSetting('fccc_last_ok', null), problem: getSetting('fccc_last_problem', null) }; }
export function fcccRules() {
  const r = getShared('fccc_rules', {}) || {};
  return { on: r.on !== false, pages: Array.isArray(r.pages) && r.pages.length ? r.pages : FCCC_DEFAULT_PAGES, everyHours: Number(r.everyHours) > 0 ? Number(r.everyHours) : 6, column: Number.isInteger(r.column) && r.column >= 0 && r.column < 5 ? r.column : 0 };
}
export function saveFcccRules(user, r) {
  need(['owner', 'admin'].includes(user.role) || can(user, 'inventory_setup'), 'Only the owner or admin can change this.');
  const pages = (r.pages || []).map(txt).filter((p) => /^https:\/\//.test(p));
  setShared('fccc_rules', { on: r.on !== false, pages: pages.length ? pages : FCCC_DEFAULT_PAGES, everyHours: Math.max(1, Number(r.everyHours) || 6), column: Math.min(4, Math.max(0, Number(r.column) || 0)) });
  audit({ user, action: 'Changed the FCCC price list check', table: 'settings' });
}

// The PDF links on an FCCC page: [{ name: 'Basic Food Items', asAt: '2026-10-09', url }]
export function parseFcccPage(html, base = 'https://fccc.gov.fj/') {
  const out = [];
  const re = /href\s*=\s*["']([^"']+?\.pdf)["']/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    let url = m[1].replace(/&amp;/g, '&');
    if (!/^https?:/i.test(url)) url = `${String(base).replace(/^(https?:\/\/[^/]+).*$/i, '$1')}/${url.replace(/^\/+/, '')}`;
    const file = decodeURIComponent(url.split('/').pop() || '');
    const d = file.match(/(.+?)[-_\s]*(?:Master[-_\s]*Price[-_\s]*List|Master[-_\s]*Pricelist|Pricelist|Price[-_\s]*List)[-_\s]*(?:as[-_\s]*at|as[-_\s]*of)?[-_\s]*(\d{1,2})[.\-_](\d{1,2})[.\-_](\d{2,4})/i);
    if (!d) continue;
    const yr = d[4].length === 2 ? `20${d[4]}` : d[4];
    const asAt = `${yr}-${d[3].padStart(2, '0')}-${d[2].padStart(2, '0')}`;
    if (!/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(asAt)) continue;
    const name = d[1].replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (!out.some((x) => x.url === url)) out.push({ name, asAt, url });
  }
  return out;
}
const listUid = (x) => `FCCC-${x.asAt}-${x.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40)}`;

// Record what was found; returns the lists that are new to this app.
export function recordLists(found) {
  if (!has('fccc_lists')) return [];
  const fresh = [];
  const { now, dev } = meta();
  for (const x of found) {
    const uid = listUid(x);
    if (db().get('SELECT uid FROM fccc_lists WHERE uid = ?', [uid])) continue;
    // Only newer than what we already have for this list counts as a change (an old PDF still linked is ignored).
    const latest = db().get('SELECT MAX(as_at) AS d FROM fccc_lists WHERE lower(list_name) = lower(?)', [x.name]).d;
    if (latest && x.asAt <= latest) continue;
    db().run(`INSERT INTO fccc_lists (uid, list_name, as_at, url, found_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)`, [uid, x.name, x.asAt, x.url, now, now, dev]);
    fresh.push({ uid, ...x });
  }
  return fresh;
}

// Look at the FCCC pages (when due). fetchText(url) → html. Never throws: a failed look is tried again later.
export async function checkFccc({ fetchText, fetchBytes, force = false } = {}) {
  const rules = fcccRules();
  if (!rules.on && !force) return { skipped: 'off' };
  const last = Number(getSetting('fccc_last_look', 0)) || 0; // this device only
  if (!force && Date.now() - last < rules.everyHours * 3600000) return { skipped: 'not due' };
  const get = fetchText || defaultFetch;
  const found = [];
  const problems = [];
  for (const page of rules.pages) {
    try { found.push(...parseFcccPage(await get(page), page)); } catch (e) { problems.push(`${page}: ${e.message || e}`); }
  }
  if (found.length || !problems.length) { try { setSetting('fccc_last_look', Date.now()); setSetting('fccc_last_ok', stamp()); } catch (e) { /* next time */ } }
  if (problems.length) { try { setSetting('fccc_last_problem', `${stamp()} ${problems.join('; ')}`.slice(0, 400)); } catch (e) { /* ignore */ } }
  const fresh = recordLists(found);
  // Read the newest list of each kind that this device has not read yet (a few tries, then it waits for a new list).
  const read = [];
  for (const l of latestLists()) {
    const st = readState(l.uid);
    if (st.lines > 0 || (st.tries >= 3 && !force)) continue;
    try { read.push({ uid: l.uid, ...(await readList(l, { fetchBytes })) }); } catch (e) { read.push({ uid: l.uid, error: String(e && e.message || e) }); }
  }
  return { found: found.length, fresh, problems, read };
}
export const readState = (uid) => { try { return JSON.parse(getSetting(`fccc_read:${uid}`, '{}') || '{}') || {}; } catch (e) { return {}; } };
// The newest list of each kind (Basic Food Items, Produce Summary, Hardware…).
export function latestLists() {
  if (!has('fccc_lists')) return [];
  return db().all('SELECT l.* FROM fccc_lists l WHERE l.as_at = (SELECT MAX(as_at) FROM fccc_lists x WHERE lower(x.list_name) = lower(l.list_name)) ORDER BY l.list_name');
}
// Download the PDF and keep its lines here. Returns { lines }.
export async function readList(list, { fetchBytes } = {}) {
  const st = readState(list.uid);
  const save = (x) => { try { setSetting(`fccc_read:${list.uid}`, JSON.stringify({ ...st, ...x, at: stamp() })); } catch (e) { /* ignore */ } };
  let bytes;
  try { bytes = await (fetchBytes || defaultFetchBytes)(list.url); } catch (e) {
    // No internet / website down: not the list's fault – tried again next time (does not use up a try).
    save({ problem: `Could not download it: ${String(e && e.message || e).slice(0, 150)}` });
    throw e;
  }
  try {
    const recs = parseFcccTable(pdfLines(await pdfTextItems(bytes)));
    db().transaction(() => {
      db().run('DELETE FROM fccc_lines WHERE list_uid = ?', [list.uid]);
      recs.forEach((r, i) => db().run('INSERT OR REPLACE INTO fccc_lines (list_uid, row_key, section, description, qty, w, r, page, sort) VALUES (?,?,?,?,?,?,?,?,?)',
        [list.uid, r.key, r.section || null, r.description, r.qty || null, JSON.stringify(r.w), JSON.stringify(r.r), r.page || null, i]));
    });
    save({ lines: recs.length, tries: (st.tries || 0) + 1, problem: recs.length ? null : 'No price lines found in the PDF – open it and check by hand.' });
    return { lines: recs.length };
  } catch (e) {
    save({ lines: 0, tries: (st.tries || 0) + 1, problem: String(e && e.message || e).slice(0, 200) });
    throw e;
  }
}
async function defaultFetchBytes(url) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const t = ctrl ? setTimeout(() => ctrl.abort(), 60000) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return new Uint8Array(await res.arrayBuffer());
  } finally { if (t) clearTimeout(t); }
}
const lineRow = (x) => (x ? { ...x, key: x.row_key, w: JSON.parse(x.w || '[]'), r: JSON.parse(x.r || '[]') } : null);
export function listLines(listUid, { q = '', limit = 60 } = {}) {
  const w = ['list_uid = ?']; const a = [listUid];
  if (txt(q)) { for (const word of normKey(q).split(' ').filter(Boolean).slice(0, 5)) { w.push("(lower(description) || ' ' || lower(COALESCE(qty,'')) || ' ' || lower(COALESCE(section,''))) LIKE ?"); a.push(`%${word}%`); } }
  return db().all(`SELECT * FROM fccc_lines WHERE ${w.join(' AND ')} ORDER BY sort LIMIT ?`, a.concat([limit])).map(lineRow);
}
// The price we must not go above, from a list line: retail in the chosen area (Viti Levu urban for Lautoka); a line with
// only a wholesale price uses that.
export function lineMax(line, column = fcccRules().column) {
  if (!line) return null;
  const v = line.r && line.r[column] !== null && line.r[column] !== undefined ? line.r[column] : line.w && line.w[column] !== null && line.w[column] !== undefined ? line.w[column] : null;
  return v === null ? null : Number(v);
}
async function defaultFetch(url) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const t = ctrl ? setTimeout(() => ctrl.abort(), 20000) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined, headers: { Accept: 'text/html' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally { if (t) clearTimeout(t); }
}

export function listFcccLists({ limit = 50 } = {}) {
  return has('fccc_lists') ? db().all('SELECT * FROM fccc_lists ORDER BY as_at DESC, list_name LIMIT ?', [limit]) : [];
}
export function uncheckedLists() {
  return has('fccc_lists') ? db().all('SELECT * FROM fccc_lists WHERE checked_at IS NULL ORDER BY as_at DESC') : [];
}
// "I went through the new list and changed the prices in Aronium (and here)."
export function markListChecked(user, uid, note) {
  need(can(user, 'inventory_manage') || can(user, 'inventory_view') || ['owner', 'admin'].includes(user.role), 'Only someone who looks after stock can tick the FCCC list.');
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [uid]);
  need(l, 'List not found.');
  need(!l.checked_at, `Already checked by ${l.checked_by_name}.`);
  const { now, dev } = meta();
  db().run(`UPDATE fccc_lists SET checked_by_name = ?, checked_at = ?, check_note = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, txt(note) || null, now, dev, uid]);
  // Older unchecked editions of the same list are covered by this one.
  db().run(`UPDATE fccc_lists SET checked_by_name = ?, checked_at = ?, check_note = 'Covered by the newer list', ${SYNCED} WHERE checked_at IS NULL AND lower(list_name) = lower(?) AND as_at < ?`, [user.name, now, now, dev, l.list_name, l.as_at]);
  audit({ user, action: `Checked the FCCC ${l.list_name} list as at ${l.as_at}`, table: 'fccc_lists', recordUid: uid, reason: txt(note) || null });
}

// Mark a product controlled (or not) and its FCCC price (the highest price allowed, VAT included).
export function setFcccPrice(user, itemUid, { controlled = true, max, name, key, list } = {}) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = db().get('SELECT * FROM inv_items WHERE uid = ?', [itemUid]);
  need(it, 'Product not found.');
  const m = max === undefined || max === null || txt(max) === '' ? null : r2(max);
  if (controlled) need(m !== null && m > 0, 'Enter the FCCC price (the highest price allowed, VAT included).');
  const { now, dev } = meta();
  const k = controlled ? (key === undefined ? it.fccc_key : txt(key) || null) : null;
  const ls = controlled ? (list === undefined ? it.fccc_list : txt(list) || null) : null;
  db().run(`UPDATE inv_items SET fccc = ?, fccc_max = ?, fccc_name = ?, fccc_set_at = ?, fccc_key = ?, fccc_list = ?, ${SYNCED} WHERE uid = ?`, [controlled ? 1 : 0, controlled ? m : null, controlled ? txt(name) || null : null, now, k, ls, now, dev, itemUid]);
  audit({ user, action: controlled ? `FCCC price for ${it.name}: ${m}${it.fccc_max && Math.abs(it.fccc_max - m) > 0.004 ? ` (was ${it.fccc_max})` : ''}` : `${it.name} is no longer FCCC controlled`, table: 'inv_items', recordUid: itemUid });
}

// Controlled products with their price at each shop. over: selling above the FCCC price somewhere.
export function controlledProducts({ q = '' } = {}) {
  if (!hasCol('inv_items', 'fccc')) return [];
  const w = ['i.fccc = 1', 'i.active = 1'];
  const a = [];
  if (txt(q)) { w.push('(lower(i.name) LIKE ? OR lower(i.code) LIKE ? OR lower(COALESCE(i.fccc_name, \'\')) LIKE ?)'); const k = `%${txt(q).toLowerCase()}%`; a.push(k, k, k); }
  const items = db().all(`SELECT * FROM inv_items i WHERE ${w.join(' AND ')} ORDER BY i.name`, a);
  const newMax = new Map(); try { pendingChanges().filter((c) => !c.missing).forEach((c) => newMax.set(c.item.uid, c.now)); } catch (e) { /* none */ }
  return items.map((it) => {
    const shops = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1 ORDER BY shop_code', [it.uid])
      .map((s) => ({ shop: s.shop_code, price: s.price === null || s.price === undefined ? Number(it.price) || 0 : Number(s.price) }));
    if (!shops.length) shops.push({ shop: 'All', price: Number(it.price) || 0 });
    const over = shops.filter((s) => it.fccc_max > 0 && s.price > it.fccc_max + 0.004);
    return { ...it, shops, over, newMax: newMax.has(it.uid) ? newMax.get(it.uid) : null, overNew: newMax.has(it.uid) ? shops.filter((s) => s.price > newMax.get(it.uid) + 0.004) : [] };
  });
}
export function overPriced() { return controlledProducts().filter((p) => p.over.length); }
function hasCol(t, c) { try { return db().all(`PRAGMA table_info(${t})`).some((x) => x.name === c); } catch (e) { return false; } }

// Warnings for Home (inventory alerts).
export function fcccAlerts() {
  const out = [];
  try {
    const changes = pendingChanges();
    for (const l of uncheckedLists()) {
      const mine = changes.filter((c) => c.list.uid === l.uid);
      const st = readState(l.uid);
      const sub = mine.length ? mine.slice(0, 5).map((c) => c.text).join('\n') + (mine.length > 5 ? `\n…and ${mine.length - 5} more` : '')
        : st.lines > 0 ? 'None of our linked products changed price. Open it to tick it checked.' : 'Open the list, check the controlled prices, change them in Aronium, then tick it as checked.';
      out.push({ id: `fccc-list-${l.uid}-${mine.length}`, level: 'warning', text: `New FCCC price list: ${l.list_name} as at ${ddmmyyyy(l.as_at)}${mine.length ? ` – ${mine.length} of our products changed price` : ''}`, sub, nav: { screen: 'Fccc', params: {} } });
    }
    // A changed price on an already-checked list (e.g. a product linked later): still worth a look.
    const loose = changes.filter((c) => c.list.checked_at);
    if (loose.length) out.push({ id: `fccc-loose-${loose.length}`, level: 'warning', text: `${loose.length} FCCC price${loose.length === 1 ? '' : 's'} to update`, sub: loose.slice(0, 5).map((c) => c.text).join('\n'), nav: { screen: 'Fccc', params: {} } });
    const over = overPriced();
    const overNew = controlledProducts().filter((p) => !p.over.length && p.overNew.length);
    if (overNew.length) {
      out.push({ id: `fccc-overnew-${overNew.length}`, level: 'warning', text: `${overNew.length} product${overNew.length === 1 ? '' : 's'} will be above the NEW FCCC price – lower ${overNew.length === 1 ? 'it' : 'them'} in Aronium`,
        sub: overNew.slice(0, 4).map((p) => `${p.name}: ${p.overNew.map((x) => `${x.shop} $${x.price.toFixed(2)}`).join(', ')} – new FCCC $${Number(p.newMax).toFixed(2)}`).join('\n'), nav: { screen: 'Fccc', params: {} } });
    }
    if (over.length) {
      out.push({ id: `fccc-over-${over.map((p) => `${p.uid}${p.fccc_max}`).join('').length}-${over.length}`, level: 'urgent', text: `${over.length} FCCC price-controlled product${over.length === 1 ? ' is' : 's are'} priced above the FCCC price`,
        sub: over.slice(0, 4).map((p) => `${p.name}: ${p.over.map((s) => `${s.shop} $${s.price.toFixed(2)}`).join(', ')} – FCCC $${Number(p.fccc_max).toFixed(2)}`).join('\n'), nav: { screen: 'Fccc', params: { filter: 'over' } } });
    }
  } catch (e) { /* never stop Home */ }
  return out;
}

// ---------------------------------------------------------------- reading the list itself (the PDF)
// The FCCC table: Item Description | Qty | Maximum Wholesale Price (5 columns) | Maximum Retail Price (5 columns),
// the 5 being Viti Levu urban / rural, Vanua Levu urban / rural, Outer Island. A row shows wholesale or retail prices;
// a size row with no description belongs to the item above; long descriptions may wrap onto 2 lines.
export const FCCC_COLUMNS = ['Viti Levu urban', 'Viti Levu rural', 'Vanua Levu urban', 'Vanua Levu rural', 'Outer Island'];
const PRICE = /^\$?\d{1,5}(,\d{3})*\.\d{2}$/;
const HEADER = /item description|maximum (retail|wholesale)|^urban|^rural|^outer island|^island$|^areas$|viti levu|vanua levu|master price ?list|prices will change|^qty$|^page \d/i;
export const normKey = (s) => String(s || '').toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9.]+/g, ' ').replace(/\s+/g, ' ').trim();
const normQty = (s) => String(s || '').toLowerCase().replace(/\s+/g, '').replace(/kgs$/, 'kg').replace(/gms?$/, 'g').replace(/ltrs?$|litres?$|lt$/, 'l');

function cluster(values, tol) {
  const cs = [];
  values.slice().sort((a, b) => a - b).forEach((v) => { const c = cs[cs.length - 1]; if (c && v - c.max <= tol) { c.max = v; c.n += 1; c.sum += v; } else cs.push({ min: v, max: v, n: 1, sum: v }); });
  return cs.map((c) => ({ x: c.sum / c.n, min: c.min, max: c.max, n: c.n }));
}

// lines: pdfLines(...) (per page: [{ y, items: [{ x, end, size, str }] }]) → [{ key, description, qty, section, w: [5], r: [5] }]
export function parseFcccTable(pagesLines) {
  const all = pagesLines.flatMap((ls) => ls.flatMap((l) => l.items));
  const nums = all.filter((it) => PRICE.test(it.str));
  if (!nums.length) return [];
  const size = nums.reduce((t, it) => t + it.size, 0) / nums.length;
  const right = (it) => (it.end !== undefined ? it.end : it.x + it.str.length * it.size * 0.5);
  let cols = cluster(nums.map(right), Math.max(3, size * 0.6)).sort((a, b) => b.n - a.n).slice(0, 10).sort((a, b) => a.x - b.x);
  cols = cols.filter((c) => c.n >= Math.max(1, Math.floor(nums.length / 60)));
  // Which columns are retail: right of the line between the two "Maximum … Price" headings (else: 10 → last 5; fewer → retail).
  const hW = all.find((it) => /maximum wholesale/i.test(it.str));
  const hR = all.find((it) => /maximum retail/i.test(it.str));
  const mid = (it) => (it.x + (it.end !== undefined ? it.end : it.x + it.str.length * it.size * 0.5)) / 2;
  let isRetail;
  if (hW && hR) { const b = (mid(hW) + mid(hR)) / 2; isRetail = (c) => (mid(hR) > mid(hW) ? c.x > b : c.x < b); } else if (cols.length >= 10) { const b = cols[4].x; isRetail = (c) => c.x > b; } else isRetail = () => true;
  const wCols = cols.filter((c) => !isRetail(c));
  const rCols = cols.filter((c) => isRetail(c));
  const colOf = (it) => { const r = right(it); let best = null; for (const c of cols) { const d = Math.abs(c.x - r); if (d <= Math.max(4, size * 0.9) && (!best || d < best.d)) best = { c, d }; } return best ? best.c : null; };
  const firstPriceX = Math.min(...cols.map((c) => c.min)) - size * 4;
  const qtyHead = all.find((it) => /^qty$|^quantity$|^size$|^unit$/i.test(it.str));
  const QTY = /^\d+(\.\d+)?\s*(x\s*\d+\s*)?(kg|kgs|g|gm|gms|ml|l|lt|ltr|litre|litres|pkt|pk|pcs|pc|tin|can|each|ea|dozen|doz|loaf|roll|rolls|bundle|bag|ctn|carton|m|mm|cm|tray|btl|bottle|sachet)s?\.?$/i;
  // The Qty column: its heading, else where most sizes ("2kg", "500g") start.
  let qtyX = qtyHead ? qtyHead.x : null;
  if (qtyX === null) { const qs = cluster(all.filter((it) => QTY.test(it.str) && it.x < firstPriceX).map((it) => it.x), size).sort((a, b) => b.n - a.n); qtyX = qs.length ? qs[0].x : null; }
  const isQty = (it) => !PRICE.test(it.str) && it.x < firstPriceX + size * 2 && (qtyX !== null ? it.x >= qtyX - size * 2.5 && Math.abs(it.x - qtyX) < size * 6 : QTY.test(it.str));
  // 1) read each line
  const rows = [];
  pagesLines.forEach((ls, page) => ls.forEach((l) => {
    if (l.items.some((it) => HEADER.test(it.str))) return;
    const prices = []; const text = []; let qty = '';
    for (const it of l.items) {
      const c = PRICE.test(it.str) ? colOf(it) : null;
      if (c) prices.push({ c, v: Number(it.str.replace(/[$,]/g, '')) });
      else if (!qty && isQty(it)) qty = it.str;
      else text.push(it.str);
    }
    rows.push({ page, y: l.y, size: l.items[0] ? l.items[0].size : size, desc: text.join(' ').trim(), qty, prices });
  }));
  // 2) descriptions on lines of their own: wrapped parts of a priced row next to them, or a section heading.
  const priced = rows.filter((r) => r.prices.length);
  const textOnly = rows.filter((r) => !r.prices.length && !r.qty && r.desc);
  const extra = new Map(); // priced row → [{y, text}]
  let section = '';
  const sectionAt = new Map();
  // A heading is in capitals (RICE, SUGAR, CANNED FISH); anything else on a line of its own is part of a description.
  const isHeading = (t) => /[A-Z]/.test(t) && t === t.toUpperCase() && t.split(/\s+/).length <= 6;
  rows.forEach((r) => { if (r.prices.length) sectionAt.set(r, section); else if (!r.qty && r.desc && isHeading(r.desc)) section = r.desc; });
  for (const t of textOnly) {
    if (isHeading(t.desc)) continue;
    const near = priced.filter((p) => p.page === t.page && Math.abs(p.y - t.y) <= p.size * 1.3).sort((a, b) => (a.desc ? 1 : 0) - (b.desc ? 1 : 0) || Math.abs(a.y - t.y) - Math.abs(b.y - t.y))[0];
    if (!near) continue;
    if (!extra.has(near)) extra.set(near, []);
    extra.get(near).push({ y: t.y, text: t.desc });
  }
  // 3) records
  const out = new Map();
  let lastDesc = '';
  for (const r of priced) {
    const parts = (extra.get(r) || []).concat(r.desc ? [{ y: r.y, text: r.desc }] : []).sort((a, b) => b.y - a.y).map((x) => x.text);
    const desc = parts.length ? parts.join(' ').replace(/\s+/g, ' ').trim() : lastDesc;
    if (!desc) continue;
    lastDesc = desc;
    const key = `${normKey(desc)}|${normQty(r.qty)}`;
    const rec = out.get(key) || { key, description: desc, qty: r.qty, section: sectionAt.get(r) || '', w: [null, null, null, null, null], r: [null, null, null, null, null], page: r.page + 1 };
    for (const p of r.prices) {
      const wi = wCols.indexOf(p.c); const ri = rCols.indexOf(p.c);
      if (ri >= 0 && ri < 5) rec.r[ri] = p.v; else if (wi >= 0 && wi < 5) rec.w[wi] = p.v;
    }
    out.set(key, rec);
  }
  return Array.from(out.values());
}

// Link one of our products to a line of the FCCC list: it becomes controlled at that line's price.
export function linkProduct(user, itemUid, listUid, rowKey) {
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [listUid]);
  need(l, 'List not found.');
  const line = lineRow(db().get('SELECT * FROM fccc_lines WHERE list_uid = ? AND row_key = ?', [listUid, rowKey]));
  need(line, 'That line is not on the list.');
  const max = lineMax(line);
  need(max !== null && max > 0, 'That line has no price for our area.');
  setFcccPrice(user, itemUid, { controlled: true, max, name: `${line.description}${line.qty ? ` ${line.qty}` : ''}`, key: rowKey, list: l.list_name });
}

// What the newest lists say for our linked products: price changes, and products no longer found on the list.
export function pendingChanges() {
  if (!hasCol('inv_items', 'fccc_key') || !has('fccc_lines')) return [];
  const latest = latestLists();
  const out = [];
  for (const it of db().all("SELECT * FROM inv_items WHERE fccc = 1 AND active = 1 AND fccc_key IS NOT NULL AND fccc_key <> ''")) {
    const l = latest.find((x) => normKey(x.list_name) === normKey(it.fccc_list || '')) || null;
    if (!l || !(readState(l.uid).lines > 0)) continue;
    const line = lineRow(db().get('SELECT * FROM fccc_lines WHERE list_uid = ? AND row_key = ?', [l.uid, it.fccc_key]));
    if (!line) { out.push({ item: it, list: l, missing: true, old: it.fccc_max, text: `${it.name}: not found on the ${l.list_name} list as at ${ddmmyyyy(l.as_at)} – check it by hand` }); continue; }
    const now = lineMax(line);
    if (now !== null && Math.abs(now - Number(it.fccc_max || 0)) > 0.004) out.push({ item: it, list: l, line, old: Number(it.fccc_max || 0), now, text: `${it.name}: FCCC price $${Number(it.fccc_max || 0).toFixed(2)} → $${now.toFixed(2)}` });
  }
  return out;
}
const ddmmyyyy = (d) => String(d || '').split('-').reverse().join('.');

// Take the new FCCC prices for our products (and tick the list checked). Returns how many changed.
export function acceptChanges(user, listUid) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [listUid]);
  need(l, 'List not found.');
  const ch = pendingChanges().filter((c) => c.list.uid === listUid && !c.missing);
  for (const c of ch) setFcccPrice(user, c.item.uid, { controlled: true, max: c.now, name: c.item.fccc_name });
  if (!l.checked_at) markListChecked(user, listUid, ch.length ? `New FCCC prices taken for ${ch.length} product(s)` : 'No price changes for our products');
  return ch.length;
}

// Our products that look like they are on the FCCC list (same size, most words in common) – to link with one tap.
export function suggestLinks({ limit = 40 } = {}) {
  if (!has('fccc_lines')) return [];
  const lines = [];
  for (const l of latestLists()) if (readState(l.uid).lines > 0) lines.push(...db().all('SELECT * FROM fccc_lines WHERE list_uid = ?', [l.uid]).map((x) => ({ ...lineRow(x), list: l })));
  if (!lines.length) return [];
  const SIZE = /(\d+(?:\.\d+)?)\s*(kg|g|gm|ml|l|ltr|lt)\b/i;
  const sizeOf = (t) => { const m = SIZE.exec(String(t || '')); if (!m) return null; let v = Number(m[1]); const u = m[2].toLowerCase(); if (u === 'g' || u === 'gm' || u === 'ml') v /= 1000; return Math.round(v * 1000) / 1000; };
  const STOP = new Set(['the', 'of', 'in', 'and', 'if', 'on', 'its', 'own', 'to', 'for', 'a', 'with', 'retails', 'wholesales', 'another', 'party', 'pack', 'x']);
  const words = (t) => new Set(normKey(t).replace(/\d+(\.\d+)?\s*(kg|g|gm|ml|l|ltr|lt)\b/g, ' ').split(' ').filter((w) => w.length > 1 && !STOP.has(w) && !/^\d/.test(w)));
  const prepared = lines.map((ln) => ({ ln, size: sizeOf(ln.qty) || sizeOf(ln.description), words: words(ln.description) }));
  const out = [];
  for (const it of db().all('SELECT uid, code, name, price FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (fccc IS NULL OR fccc = 0)')) {
    const size = sizeOf(it.name);
    const ws = words(it.name);
    if (!ws.size) continue;
    let best = null;
    for (const p of prepared) {
      if (size !== null && p.size !== null && Math.abs(size - p.size) > 0.0001) continue;
      if (size === null || p.size === null) continue;
      let common = 0; ws.forEach((w) => { if (p.words.has(w)) common += 1; });
      if (common < 2 && !(common === 1 && ws.size === 1)) continue;
      const score = common / Math.max(ws.size, 1) + common / Math.max(p.words.size, 1) * 0.5;
      if (!best || score > best.score) best = { score, p };
    }
    if (best && best.score >= 0.6) out.push({ item: it, line: best.p.ln, list: best.p.ln.list, max: lineMax(best.p.ln), score: Math.round(best.score * 100) / 100 });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
