// v3.9.3 FCCC price-controlled products.
// The Fijian Competition & Consumer Commission (FCCC) sets the highest price some products may be sold at. It publishes
// the "Master Price List" as PDFs on its website, each named "… Master Price List as at DD.MM.YYYY.pdf".
//  • Each device (when online) looks at the FCCC pages a few times a day. A list with a new date → a warning on Home and
//    a phone notification, with the PDF to open. Nothing is written anywhere but this app.
//  • Products are marked "FCCC controlled" with the FCCC price. Any shop selling one above that price (the price comes from
//    the Aronium product import) is a red warning: change it in Aronium.
//  • Someone goes through the new list and ticks it as checked (name and time kept).
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, getShared, setShared, getSetting, setSetting } from '../../services/core.js';
import { can } from '../../services/access.js';
import { pdfTextItems, pdfLines } from '../../services/pdfText.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = (t) => { try { return !!db().get("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const FCCC_SQL = `
CREATE TABLE IF NOT EXISTS fccc_lists (
  uid TEXT PRIMARY KEY,
  list_name TEXT NOT NULL,
  as_at TEXT NOT NULL,
  url TEXT NOT NULL,
  found_at TEXT,
  checked_by_name TEXT,
  checked_at TEXT,
  check_note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_fccc_asat ON fccc_lists(as_at);
-- The lines read from each list's PDF (on this device only; every device reads the list itself).
CREATE TABLE IF NOT EXISTS fccc_lines (
  list_uid TEXT NOT NULL,
  row_key TEXT NOT NULL,
  section TEXT, description TEXT, qty TEXT,
  w TEXT, r TEXT, page INTEGER, sort INTEGER,
  PRIMARY KEY (list_uid, row_key)
);
`;
export const FCCC_SYNC = {
  fccc_lists: { key: 'uid', section: 'Inventory', cols: ['uid', 'list_name', 'as_at', 'url', 'found_at', 'checked_by_name', 'checked_at', 'check_note', 'updated_at', 'updated_device'] },
};
// Product columns (added by columns.js): fccc (1 = controlled), fccc_max (highest price incl. VAT), fccc_name, fccc_set_at,
// fccc_key (the line on the FCCC list: description|size) and fccc_list (which list, e.g. Basic Food Items).

export const FCCC_DEFAULT_PAGES = [
  'https://fccc.gov.fj/master-price-list/basic-food-items/',
  'https://fccc.gov.fj/master-price-list/hardware/',
];
export function fcccStatus() { return { lastOk: getSetting('fccc_last_ok', null), problem: getSetting('fccc_last_problem', null) }; }
export function fcccRules() {
  const r = getShared('fccc_rules', {}) || {};
  return { on: r.on !== false, pages: Array.isArray(r.pages) && r.pages.length ? r.pages : FCCC_DEFAULT_PAGES, everyHours: Number(r.everyHours) > 0 ? Number(r.everyHours) : 6, column: Number.isInteger(r.column) && r.column >= 0 && r.column < 5 ? r.column : 0 };
}
export function saveFcccRules(user, r) {
  need(['owner', 'admin'].includes(user.role) || can(user, 'inventory_setup'), 'Only the owner or admin can change this.');
  const pages = (r.pages || []).map(txt).filter((p) => /^https:\/\//.test(p));
  setShared('fccc_rules', { on: r.on !== false, pages: pages.length ? pages : FCCC_DEFAULT_PAGES, everyHours: Math.max(1, Number(r.everyHours) || 6), column: Math.min(4, Math.max(0, Number(r.column) || 0)) });
  audit({ user, action: 'Changed the FCCC price list check', table: 'settings' });
}

// The PDF links on an FCCC page: [{ name: 'Basic Food Items', asAt: '2026-10-09', url }]
export function parseFcccPage(html, base = 'https://fccc.gov.fj/') {
  const out = [];
  const re = /href\s*=\s*["']([^"']+?\.pdf)["']/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    let url = m[1].replace(/&amp;/g, '&');
    if (!/^https?:/i.test(url)) url = `${String(base).replace(/^(https?:\/\/[^/]+).*$/i, '$1')}/${url.replace(/^\/+/, '')}`;
    const file = decodeURIComponent(url.split('/').pop() || '');
    const d = file.match(/(.+?)[-_\s]*(?:Master[-_\s]*Price[-_\s]*List|Master[-_\s]*Pricelist|Pricelist|Price[-_\s]*List)[-_\s]*(?:as[-_\s]*at|as[-_\s]*of)?[-_\s]*(\d{1,2})[.\-_](\d{1,2})[.\-_](\d{2,4})/i);
    if (!d) continue;
    const yr = d[4].length === 2 ? `20${d[4]}` : d[4];
    const asAt = `${yr}-${d[3].padStart(2, '0')}-${d[2].padStart(2, '0')}`;
    if (!/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(asAt)) continue;
    const name = d[1].replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (!out.some((x) => x.url === url)) out.push({ name, asAt, url });
  }
  return out;
}
const listUid = (x) => `FCCC-${x.asAt}-${x.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40)}`;

// Record what was found; returns the lists that are new to this app.
export function recordLists(found) {
  if (!has('fccc_lists')) return [];
  const fresh = [];
  const { now, dev } = meta();
  for (const x of found) {
    const uid = listUid(x);
    if (db().get('SELECT uid FROM fccc_lists WHERE uid = ?', [uid])) continue;
    // Only newer than what we already have for this list counts as a change (an old PDF still linked is ignored).
    const latest = db().get('SELECT MAX(as_at) AS d FROM fccc_lists WHERE lower(list_name) = lower(?)', [x.name]).d;
    if (latest && x.asAt <= latest) continue;
    db().run(`INSERT INTO fccc_lists (uid, list_name, as_at, url, found_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)`, [uid, x.name, x.asAt, x.url, now, now, dev]);
    fresh.push({ uid, ...x });
  }
  return fresh;
}

// Look at the FCCC pages (when due). fetchText(url) → html. Never throws: a failed look is tried again later.
export async function checkFccc({ fetchText, fetchBytes, force = false } = {}) {
  const rules = fcccRules();
  if (!rules.on && !force) return { skipped: 'off' };
  const last = Number(getSetting('fccc_last_look', 0)) || 0; // this device only
  if (!force && Date.now() - last < rules.everyHours * 3600000) return { skipped: 'not due' };
  const get = fetchText || defaultFetch;
  const found = [];
  const problems = [];
  for (const page of rules.pages) {
    try { found.push(...parseFcccPage(await get(page), page)); } catch (e) { problems.push(`${page}: ${e.message || e}`); }
  }
  if (found.length || !problems.length) { try { setSetting('fccc_last_look', Date.now()); setSetting('fccc_last_ok', stamp()); } catch (e) { /* next time */ } }
  if (problems.length) { try { setSetting('fccc_last_problem', `${stamp()} ${problems.join('; ')}`.slice(0, 400)); } catch (e) { /* ignore */ } }
  const fresh = recordLists(found);
  // Read the newest list of each kind that this device has not read yet (a few tries, then it waits for a new list).
  const read = [];
  for (const l of latestLists()) {
    const st = readState(l.uid);
    if (st.lines > 0 || (st.tries >= 3 && !force)) continue;
    try { read.push({ uid: l.uid, ...(await readList(l, { fetchBytes })) }); } catch (e) { read.push({ uid: l.uid, error: String(e && e.message || e) }); }
  }
  let auto = null;
  try { auto = autoLinkFccc(); auto.review = autoReview(); } catch (e) { auto = { error: String(e && e.message || e) }; }
  return { found: found.length, fresh, problems, read, auto };
}
export const readState = (uid) => { try { return JSON.parse(getSetting(`fccc_read:${uid}`, '{}') || '{}') || {}; } catch (e) { return {}; } };
// The newest list of each kind (Basic Food Items, Produce Summary, Hardware…).
export function latestLists() {
  if (!has('fccc_lists')) return [];
  return db().all('SELECT l.* FROM fccc_lists l WHERE l.as_at = (SELECT MAX(as_at) FROM fccc_lists x WHERE lower(x.list_name) = lower(l.list_name)) ORDER BY l.list_name');
}
// Download the PDF and keep its lines here. Returns { lines }.
export async function readList(list, { fetchBytes } = {}) {
  const st = readState(list.uid);
  const save = (x) => { try { setSetting(`fccc_read:${list.uid}`, JSON.stringify({ ...st, ...x, at: stamp() })); } catch (e) { /* ignore */ } };
  let bytes;
  try { bytes = await (fetchBytes || defaultFetchBytes)(list.url); } catch (e) {
    // No internet / website down: not the list's fault – tried again next time (does not use up a try).
    save({ problem: `Could not download it: ${String(e && e.message || e).slice(0, 150)}` });
    throw e;
  }
  try {
    const recs = parseFcccTable(pdfLines(await pdfTextItems(bytes)));
    db().transaction(() => {
      db().run('DELETE FROM fccc_lines WHERE list_uid = ?', [list.uid]);
      recs.forEach((r, i) => db().run('INSERT OR REPLACE INTO fccc_lines (list_uid, row_key, section, description, qty, w, r, page, sort) VALUES (?,?,?,?,?,?,?,?,?)',
        [list.uid, r.key, r.section || null, r.description, r.qty || null, JSON.stringify(r.w), JSON.stringify(r.r), r.page || null, i]));
    });
    save({ lines: recs.length, tries: (st.tries || 0) + 1, problem: recs.length ? null : 'No price lines found in the PDF – open it and check by hand.' });
    return { lines: recs.length };
  } catch (e) {
    save({ lines: 0, tries: (st.tries || 0) + 1, problem: String(e && e.message || e).slice(0, 200) });
    throw e;
  }
}
async function defaultFetchBytes(url) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const t = ctrl ? setTimeout(() => ctrl.abort(), 60000) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return new Uint8Array(await res.arrayBuffer());
  } finally { if (t) clearTimeout(t); }
}
const lineRow = (x) => (x ? { ...x, key: x.row_key, w: JSON.parse(x.w || '[]'), r: JSON.parse(x.r || '[]') } : null);
export function listLines(listUid, { q = '', limit = 60 } = {}) {
  const w = ['list_uid = ?']; const a = [listUid];
  if (txt(q)) { for (const word of normKey(q).split(' ').filter(Boolean).slice(0, 5)) { w.push("(lower(description) || ' ' || lower(COALESCE(qty,'')) || ' ' || lower(COALESCE(section,''))) LIKE ?"); a.push(`%${word}%`); } }
  return db().all(`SELECT * FROM fccc_lines WHERE ${w.join(' AND ')} ORDER BY sort LIMIT ?`, a.concat([limit])).map(lineRow);
}
// The price we must not go above, from a list line: retail in the chosen area (Viti Levu urban for Lautoka); a line with
// only a wholesale price uses that.
export function lineMax(line, column = fcccRules().column) {
  if (!line) return null;
  const v = line.r && line.r[column] !== null && line.r[column] !== undefined ? line.r[column] : line.w && line.w[column] !== null && line.w[column] !== undefined ? line.w[column] : null;
  return v === null ? null : Number(v);
}
async function defaultFetch(url) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const t = ctrl ? setTimeout(() => ctrl.abort(), 20000) : null;
  try {
    const res = await fetch(url, { signal: ctrl ? ctrl.signal : undefined, headers: { Accept: 'text/html' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally { if (t) clearTimeout(t); }
}

// Undo a tick (ticked by mistake): the list is open again and its warning comes back. Owner / admin / stock manager.
export function uncheckList(user, uid) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'Only the owner, an admin or the stock manager can undo this.');
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [uid]);
  need(l, 'List not found.');
  need(l.checked_at, 'This list is not ticked.');
  const { now, dev } = meta();
  db().run(`UPDATE fccc_lists SET checked_by_name = NULL, checked_at = NULL, check_note = NULL, ${SYNCED} WHERE uid = ?`, [now, dev, uid]);
  audit({ user, action: `Undid the tick on the FCCC ${l.list_name} list as at ${l.as_at} (was ticked by ${l.checked_by_name} ${String(l.checked_at).slice(0, 16)})`, table: 'fccc_lists', recordUid: uid });
}

export function listFcccLists({ limit = 50 } = {}) {
  return has('fccc_lists') ? db().all('SELECT * FROM fccc_lists ORDER BY as_at DESC, list_name LIMIT ?', [limit]) : [];
}
export function uncheckedLists() {
  return has('fccc_lists') ? db().all('SELECT * FROM fccc_lists WHERE checked_at IS NULL ORDER BY as_at DESC') : [];
}
// "I went through the new list and changed the prices in Aronium (and here)."
export function markListChecked(user, uid, note) {
  need(can(user, 'inventory_manage') || can(user, 'inventory_view') || ['owner', 'admin'].includes(user.role), 'Only someone who looks after stock can tick the FCCC list.');
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [uid]);
  need(l, 'List not found.');
  need(!l.checked_at, `Already checked by ${l.checked_by_name}.`);
  const { now, dev } = meta();
  db().run(`UPDATE fccc_lists SET checked_by_name = ?, checked_at = ?, check_note = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, txt(note) || null, now, dev, uid]);
  // Older unchecked editions of the same list are covered by this one.
  db().run(`UPDATE fccc_lists SET checked_by_name = ?, checked_at = ?, check_note = 'Covered by the newer list', ${SYNCED} WHERE checked_at IS NULL AND lower(list_name) = lower(?) AND as_at < ?`, [user.name, now, now, dev, l.list_name, l.as_at]);
  audit({ user, action: `Checked the FCCC ${l.list_name} list as at ${l.as_at}`, table: 'fccc_lists', recordUid: uid, reason: txt(note) || null });
}

// Mark a product controlled (or not) and its FCCC price (the highest price allowed, VAT included).
export function setFcccPrice(user, itemUid, { controlled = true, max, name, key, list } = {}) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = db().get('SELECT * FROM inv_items WHERE uid = ?', [itemUid]);
  need(it, 'Product not found.');
  const m = max === undefined || max === null || txt(max) === '' ? null : r2(max);
  if (controlled) need(m !== null && m > 0, 'Enter the FCCC price (the highest price allowed, VAT included).');
  const { now, dev } = meta();
  const k = controlled ? (key === undefined ? it.fccc_key : txt(key) || null) : null;
  const ls = controlled ? (list === undefined ? it.fccc_list : txt(list) || null) : null;
  db().run(`UPDATE inv_items SET fccc = ?, fccc_max = ?, fccc_name = ?, fccc_set_at = ?, fccc_key = ?, fccc_list = ?, ${SYNCED} WHERE uid = ?`, [controlled ? 1 : 0, controlled ? m : null, controlled ? txt(name) || null : null, now, k, ls, now, dev, itemUid]);
  if (user && user.uid !== 'fccc-auto' && hasCol('inv_items', 'fccc_auto')) db().run('UPDATE inv_items SET fccc_auto = 0 WHERE uid = ?', [itemUid]); // a person set it
  audit({ user, action: controlled ? `FCCC price for ${it.name}: ${m}${it.fccc_max && Math.abs(it.fccc_max - m) > 0.004 ? ` (was ${it.fccc_max})` : ''}` : `${it.name} is no longer FCCC controlled`, table: 'inv_items', recordUid: itemUid });
}

// Controlled products with their price at each shop. over: selling above the FCCC price somewhere.
export function controlledProducts({ q = '' } = {}) {
  if (!hasCol('inv_items', 'fccc')) return [];
  const w = ['i.fccc = 1', 'i.active = 1'];
  const a = [];
  if (txt(q)) { w.push('(lower(i.name) LIKE ? OR lower(i.code) LIKE ? OR lower(COALESCE(i.fccc_name, \'\')) LIKE ?)'); const k = `%${txt(q).toLowerCase()}%`; a.push(k, k, k); }
  const items = db().all(`SELECT * FROM inv_items i WHERE ${w.join(' AND ')} ORDER BY i.name`, a);
  const newMax = new Map(); try { pendingChanges().filter((c) => !c.missing).forEach((c) => newMax.set(c.item.uid, c.now)); } catch (e) { /* none */ }
  return items.map((it) => {
    const shops = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1 ORDER BY shop_code', [it.uid])
      .map((s) => ({ shop: s.shop_code, price: s.price === null || s.price === undefined ? Number(it.price) || 0 : Number(s.price) }));
    if (!shops.length) shops.push({ shop: 'All', price: Number(it.price) || 0 });
    const over = shops.filter((s) => it.fccc_max > 0 && s.price > it.fccc_max + 0.004);
    return { ...it, shops, over, newMax: newMax.has(it.uid) ? newMax.get(it.uid) : null, overNew: newMax.has(it.uid) ? shops.filter((s) => s.price > newMax.get(it.uid) + 0.004) : [] };
  });
}
export function overPriced() { return controlledProducts().filter((p) => p.over.length); }
function hasCol(t, c) { try { return db().all(`PRAGMA table_info(${t})`).some((x) => x.name === c); } catch (e) { return false; } }

// Warnings for Home (inventory alerts).
export function fcccAlerts() {
  const out = [];
  try {
    const changes = pendingChanges();
    for (const l of uncheckedLists()) {
      const mine = changes.filter((c) => c.list.uid === l.uid);
      const st = readState(l.uid);
      const sub = mine.length ? mine.slice(0, 5).map((c) => c.text).join('\n') + (mine.length > 5 ? `\n…and ${mine.length - 5} more` : '')
        : st.lines > 0 ? 'None of our linked products changed price. Open it to tick it checked.' : 'Open the list, check the controlled prices, change them in Aronium, then tick it as checked.';
      out.push({ id: `fccc-list-${l.uid}-${mine.length}`, level: 'warning', text: `New FCCC price list: ${l.list_name} as at ${ddmmyyyy(l.as_at)}${mine.length ? ` – ${mine.length} of our products changed price` : ''}`, sub, nav: { screen: 'Fccc', params: {} } });
    }
    // A changed price on an already-checked list (e.g. a product linked later): still worth a look.
    const loose = changes.filter((c) => c.list.checked_at);
    if (loose.length) out.push({ id: `fccc-loose-${loose.length}`, level: 'warning', text: `${loose.length} FCCC price${loose.length === 1 ? '' : 's'} to update`, sub: loose.slice(0, 5).map((c) => c.text).join('\n'), nav: { screen: 'Fccc', params: {} } });
    const auto = autoLinked();
    if (auto.length) out.push({ id: `fccc-auto-${auto.length}`, level: 'warning', text: `${auto.length} product${auto.length === 1 ? ' was' : 's were'} marked FCCC-controlled by the app – confirm ${auto.length === 1 ? 'it' : 'them'}`, sub: `Watched already. ${auto.slice(0, 4).map((x) => `${x.name} → ${x.fccc_name || 'FCCC'} $${Number(x.fccc_max).toFixed(2)}`).join('\n')}`, nav: { screen: 'Fccc', params: { filter: 'auto' } } });
    const maybe = possiblyOver();
    if (maybe.length) out.push({ id: `fccc-maybe-${maybe.length}`, level: 'warning', text: `${maybe.length} product${maybe.length === 1 ? ' looks' : 's look'} FCCC-controlled and priced above that FCCC price – check`, sub: maybe.slice(0, 4).map((g) => `${g.item.name}: ${g.over.map((x) => `${x.shop} $${x.price.toFixed(2)}`).join(', ')} – FCCC ${g.line.description}${g.line.qty ? ` ${g.line.qty}` : ''} $${Number(g.max).toFixed(2)}`).join('\n'), nav: { screen: 'Fccc', params: { filter: 'maybe' } } });
    const over = overPriced();
    const overNew = controlledProducts().filter((p) => !p.over.length && p.overNew.length);
    if (overNew.length) {
      out.push({ id: `fccc-overnew-${overNew.length}`, level: 'warning', text: `${overNew.length} product${overNew.length === 1 ? '' : 's'} will be above the NEW FCCC price – lower ${overNew.length === 1 ? 'it' : 'them'} in Aronium`,
        sub: overNew.slice(0, 4).map((p) => `${p.name}: ${p.overNew.map((x) => `${x.shop} $${x.price.toFixed(2)}`).join(', ')} – new FCCC $${Number(p.newMax).toFixed(2)}`).join('\n'), nav: { screen: 'Fccc', params: {} } });
    }
    if (over.length) {
      out.push({ id: `fccc-over-${over.map((p) => `${p.uid}${p.fccc_max}`).join('').length}-${over.length}`, level: 'urgent', text: `${over.length} FCCC price-controlled product${over.length === 1 ? ' is' : 's are'} priced above the FCCC price`,
        sub: over.slice(0, 4).map((p) => `${p.name}: ${p.over.map((s) => `${s.shop} $${s.price.toFixed(2)}`).join(', ')} – FCCC $${Number(p.fccc_max).toFixed(2)}`).join('\n'), nav: { screen: 'Fccc', params: { filter: 'over' } } });
    }
  } catch (e) { /* never stop Home */ }
  return out;
}

// ---------------------------------------------------------------- reading the list itself (the PDF)
// The FCCC table: Item Description | Qty | Maximum Wholesale Price (5 columns) | Maximum Retail Price (5 columns),
// the 5 being Viti Levu urban / rural, Vanua Levu urban / rural, Outer Island. A row shows wholesale or retail prices;
// a size row with no description belongs to the item above; long descriptions may wrap onto 2 lines.
export const FCCC_COLUMNS = ['Viti Levu urban', 'Viti Levu rural', 'Vanua Levu urban', 'Vanua Levu rural', 'Outer Island'];
const PRICE = /^\$?\d{1,5}(,\d{3})*\.\d{2}$/;
const HEADER = /item description|maximum (retail|wholesale)|^urban|^rural|^outer island|^island$|^areas$|viti levu|vanua levu|master price ?list|prices will change|^qty$|^page \d|^traders$|^outer$|^prices of |competition and consumer commission|price control|can be obtained from/i;
export const normKey = (s) => String(s || '').toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9.]+/g, ' ').replace(/\s+/g, ' ').trim();
const normQty = (s) => String(s || '').toLowerCase().replace(/\s+/g, '').replace(/kgs$/, 'kg').replace(/gms?$/, 'g').replace(/ltrs?$|litres?$|lt$/, 'l');

function cluster(values, tol) {
  const cs = [];
  values.slice().sort((a, b) => a - b).forEach((v) => { const c = cs[cs.length - 1]; if (c && v - c.max <= tol) { c.max = v; c.n += 1; c.sum += v; } else cs.push({ min: v, max: v, n: 1, sum: v }); });
  return cs.map((c) => ({ x: c.sum / c.n, min: c.min, max: c.max, n: c.n }));
}

// lines: pdfLines(...) (per page: [{ y, items: [{ x, end, size, str }] }]) → [{ key, description, qty, section, w: [5], r: [5] }]
// (The simple layout: one Qty column, a description on the first row of its sizes.)
function parseSimpleTable(pagesLines) {
  const all = pagesLines.flatMap((ls) => ls.flatMap((l) => l.items));
  const nums = all.filter((it) => PRICE.test(it.str));
  if (!nums.length) return [];
  const size = nums.reduce((t, it) => t + it.size, 0) / nums.length;
  const right = (it) => (it.end !== undefined ? it.end : it.x + it.str.length * it.size * 0.5);
  let cols = cluster(nums.map(right), Math.max(3, size * 0.6)).sort((a, b) => b.n - a.n).slice(0, 10).sort((a, b) => a.x - b.x);
  cols = cols.filter((c) => c.n >= Math.max(1, Math.floor(nums.length / 60)));
  // Which columns are retail: right of the line between the two "Maximum … Price" headings (else: 10 → last 5; fewer → retail).
  const hW = all.find((it) => /maximum wholesale/i.test(it.str));
  const hR = all.find((it) => /maximum retail/i.test(it.str));
  const mid = (it) => (it.x + (it.end !== undefined ? it.end : it.x + it.str.length * it.size * 0.5)) / 2;
  let isRetail;
  if (hW && hR) { const b = (mid(hW) + mid(hR)) / 2; isRetail = (c) => (mid(hR) > mid(hW) ? c.x > b : c.x < b); } else if (cols.length >= 10) { const b = cols[4].x; isRetail = (c) => c.x > b; } else isRetail = () => true;
  const wCols = cols.filter((c) => !isRetail(c));
  const rCols = cols.filter((c) => isRetail(c));
  const colOf = (it) => { const r = right(it); let best = null; for (const c of cols) { const d = Math.abs(c.x - r); if (d <= Math.max(4, size * 0.9) && (!best || d < best.d)) best = { c, d }; } return best ? best.c : null; };
  const firstPriceX = Math.min(...cols.map((c) => c.min)) - size * 4;
  const qtyHead = all.find((it) => /^qty$|^quantity$|^size$|^unit$/i.test(it.str));
  const QTY = /^\d+(\.\d+)?\s*(x\s*\d+\s*)?(kg|kgs|g|gm|gms|ml|l|lt|ltr|litre|litres|pkt|pk|pcs|pc|tin|can|each|ea|dozen|doz|loaf|roll|rolls|bundle|bag|ctn|carton|m|mm|cm|tray|btl|bottle|sachet)s?\.?$/i;
  // The Qty column: its heading, else where most sizes ("2kg", "500g") start.
  let qtyX = qtyHead ? qtyHead.x : null;
  if (qtyX === null) { const qs = cluster(all.filter((it) => QTY.test(it.str) && it.x < firstPriceX).map((it) => it.x), size).sort((a, b) => b.n - a.n); qtyX = qs.length ? qs[0].x : null; }
  const isQty = (it) => !PRICE.test(it.str) && it.x < firstPriceX + size * 2 && (qtyX !== null ? it.x >= qtyX - size * 2.5 && Math.abs(it.x - qtyX) < size * 6 : QTY.test(it.str));
  // 1) read each line
  const rows = [];
  pagesLines.forEach((ls, page) => ls.forEach((l) => {
    if (l.items.some((it) => HEADER.test(it.str))) return;
    const prices = []; const text = []; let qty = '';
    for (const it of l.items) {
      const c = PRICE.test(it.str) ? colOf(it) : null;
      if (c) prices.push({ c, v: Number(it.str.replace(/[$,]/g, '')) });
      else if (!qty && isQty(it)) qty = it.str;
      else text.push(it.str);
    }
    rows.push({ page, y: l.y, size: l.items[0] ? l.items[0].size : size, desc: text.join(' ').trim(), qty, prices });
  }));
  // 2) descriptions on lines of their own: wrapped parts of a priced row next to them, or a section heading.
  const priced = rows.filter((r) => r.prices.length);
  const textOnly = rows.filter((r) => !r.prices.length && !r.qty && r.desc);
  const extra = new Map(); // priced row → [{y, text}]
  let section = '';
  const sectionAt = new Map();
  // A heading is in capitals (RICE, SUGAR, CANNED FISH); anything else on a line of its own is part of a description.
  const isHeading = (t) => /[A-Z]/.test(t) && t === t.toUpperCase() && t.split(/\s+/).length <= 6;
  rows.forEach((r) => { if (r.prices.length) sectionAt.set(r, section); else if (!r.qty && r.desc && isHeading(r.desc)) section = r.desc; });
  for (const t of textOnly) {
    if (isHeading(t.desc)) continue;
    const near = priced.filter((p) => p.page === t.page && Math.abs(p.y - t.y) <= p.size * 1.3).sort((a, b) => (a.desc ? 1 : 0) - (b.desc ? 1 : 0) || Math.abs(a.y - t.y) - Math.abs(b.y - t.y))[0];
    if (!near) continue;
    if (!extra.has(near)) extra.set(near, []);
    extra.get(near).push({ y: t.y, text: t.desc });
  }
  // 3) records
  const out = new Map();
  let lastDesc = '';
  for (const r of priced) {
    const parts = (extra.get(r) || []).concat(r.desc ? [{ y: r.y, text: r.desc }] : []).sort((a, b) => b.y - a.y).map((x) => x.text);
    const desc = parts.length ? parts.join(' ').replace(/\s+/g, ' ').trim() : lastDesc;
    if (!desc) continue;
    lastDesc = desc;
    const key = `${normKey(desc)}|${normQty(r.qty)}`;
    const rec = out.get(key) || { key, description: desc, qty: r.qty, section: sectionAt.get(r) || '', w: [null, null, null, null, null], r: [null, null, null, null, null], page: r.page + 1 };
    for (const p of r.prices) {
      const wi = wCols.indexOf(p.c); const ri = rCols.indexOf(p.c);
      if (ri >= 0 && ri < 5) rec.r[ri] = p.v; else if (wi >= 0 && wi < 5) rec.w[wi] = p.v;
    }
    out.set(key, rec);
  }
  return Array.from(out.values());
}

// Link one of our products to a line of the FCCC list: it becomes controlled at that line's price.
export function linkProduct(user, itemUid, listUid, rowKey) {
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [listUid]);
  need(l, 'List not found.');
  const line = lineRow(db().get('SELECT * FROM fccc_lines WHERE list_uid = ? AND row_key = ?', [listUid, rowKey]));
  need(line, 'That line is not on the list.');
  const max = lineMax(line);
  need(max !== null && max > 0, 'That line has no price for our area.');
  setFcccPrice(user, itemUid, { controlled: true, max, name: `${line.description}${line.qty ? ` ${line.qty}` : ''}`, key: rowKey, list: l.list_name });
}

// What the newest lists say for our linked products: price changes, and products no longer found on the list.
export function pendingChanges() {
  if (!hasCol('inv_items', 'fccc_key') || !has('fccc_lines')) return [];
  const latest = latestLists();
  const out = [];
  for (const it of db().all("SELECT * FROM inv_items WHERE fccc = 1 AND active = 1 AND fccc_key IS NOT NULL AND fccc_key <> ''")) {
    const l = latest.find((x) => normKey(x.list_name) === normKey(it.fccc_list || '')) || null;
    if (!l || !(readState(l.uid).lines > 0)) continue;
    const line = lineRow(db().get('SELECT * FROM fccc_lines WHERE list_uid = ? AND row_key = ?', [l.uid, it.fccc_key]));
    if (!line) { out.push({ item: it, list: l, missing: true, old: it.fccc_max, text: `${it.name}: not found on the ${l.list_name} list as at ${ddmmyyyy(l.as_at)} – check it by hand` }); continue; }
    const now = lineMax(line);
    if (now !== null && Math.abs(now - Number(it.fccc_max || 0)) > 0.004) out.push({ item: it, list: l, line, old: Number(it.fccc_max || 0), now, text: `${it.name}: FCCC price $${Number(it.fccc_max || 0).toFixed(2)} → $${now.toFixed(2)}` });
  }
  return out;
}
const ddmmyyyy = (d) => String(d || '').split('-').reverse().join('.');

// Take the new FCCC prices for our products (and tick the list checked). Returns how many changed.
export function acceptChanges(user, listUid) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const l = db().get('SELECT * FROM fccc_lists WHERE uid = ?', [listUid]);
  need(l, 'List not found.');
  const ch = pendingChanges().filter((c) => c.list.uid === listUid && !c.missing);
  for (const c of ch) setFcccPrice(user, c.item.uid, { controlled: true, max: c.now, name: c.item.fccc_name });
  if (!l.checked_at) markListChecked(user, listUid, ch.length ? `New FCCC prices taken for ${ch.length} product(s)` : 'No price changes for our products');
  return ch.length;
}

// Our products that look like they are on the FCCC list (same size, most words in common) – to link with one tap.
export function suggestLinks({ limit = 40 } = {}) {
  if (!has('fccc_lines')) return [];
  const lines = [];
  for (const l of latestLists()) if (readState(l.uid).lines > 0) lines.push(...db().all('SELECT * FROM fccc_lines WHERE list_uid = ?', [l.uid]).map((x) => ({ ...lineRow(x), list: l })));
  if (!lines.length) return [];
  const SIZE = /(\d+(?:\.\d+)?)\s*(kg|g|gm|ml|l|ltr|lt)\b/i;
  const sizeOf = (t) => { const m = SIZE.exec(String(t || '')); if (!m) return null; let v = Number(m[1]); const u = m[2].toLowerCase(); if (u === 'g' || u === 'gm' || u === 'ml') v /= 1000; return Math.round(v * 1000) / 1000; };
  const STOP = new Set(['the', 'of', 'in', 'and', 'if', 'on', 'its', 'own', 'to', 'for', 'a', 'with', 'retails', 'wholesales', 'another', 'party', 'pack', 'x']);
  const words = (t) => new Set(normKey(t).replace(/\d+(\.\d+)?\s*(kg|g|gm|ml|l|ltr|lt)\b/g, ' ').split(' ').filter((w) => w.length > 1 && !STOP.has(w) && !/^\d/.test(w)));
  const prepared = lines.map((ln) => ({ ln, size: sizeOf(ln.qty) || sizeOf(ln.description), words: words(ln.description) }));
  const out = [];
  const rej = hasCol('inv_items', 'fccc_reject') ? " AND (fccc_reject IS NULL OR fccc_reject = '')" : '';
  for (const it of db().all(`SELECT uid, code, name, price FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (fccc IS NULL OR fccc = 0)${rej}`)) {
    const size = sizeOf(it.name);
    const ws = words(it.name);
    if (!ws.size) continue;
    let best = null;
    for (const p of prepared) {
      if (size !== null && p.size !== null && Math.abs(size - p.size) > 0.0001) continue;
      if (size === null || p.size === null) continue;
      let common = 0; ws.forEach((w) => { if (p.words.has(w)) common += 1; });
      if (common < 2 && !(common === 1 && ws.size === 1)) continue;
      if (/\bx\b/i.test(String(p.ln.qty || ''))) continue; // a wholesale pack ("12 x 2kg"), not what a shop sells
      // Shops buying from a distributor: the "wholesales to another party" / "Others" line usually applies to them.
      const desc = String(p.ln.description || '');
      const fit = (/wholesales to (another party|others)|\(others\)/i.test(desc) ? 0.08 : 0) - (/retails on its own|\(own\)/i.test(desc) ? 0.08 : 0) + (p.ln.r && p.ln.r.some((v) => v !== null) ? 0.05 : 0);
      const score = common / Math.max(ws.size, 1) + common / Math.max(p.words.size, 1) * 0.5 + fit;
      if (!best || score > best.score) best = { score, p };
    }
    if (best && best.score >= 0.6) out.push({ item: it, line: best.p.ln, list: best.p.ln.list, max: lineMax(best.p.ln), score: Math.round(best.score * 100) / 100 });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}

// ---------------------------------------------------------------- v3.9.4 the app marks controlled products itself
// A product whose name and size clearly match a line of the newest FCCC list is marked controlled straight away (and
// watched from then on) – "marked by the app, please confirm". Weaker matches are not marked, but are still watched:
// priced above the possible FCCC price → a warning. Watching too much costs a look; missing one can cost a fine.
// Only the main tablet marks (one device, so the devices never argue). A person's "not controlled" is never undone.
export const AUTO_SCORE = 1.2;
const APP_USER = { uid: 'fccc-auto', name: 'Easy Buys app (automatic)', role: 'owner' };
function marksHere() {
  const main = getShared('main_tablet_device', '');
  return main ? main === deviceId() : !!getSetting('cloud_key', '');
}
export function autoLinkFccc({ force = false } = {}) {
  if (!hasCol('inv_items', 'fccc_auto') || (!force && !marksHere())) return { linked: [] };
  const linked = [];
  for (const g of suggestLinks({ limit: 100000 })) {
    if (g.score < AUTO_SCORE || !(g.max > 0)) continue;
    try {
      linkProduct(APP_USER, g.item.uid, g.line.list_uid, g.line.key);
      db().run('UPDATE inv_items SET fccc_auto = 1 WHERE uid = ?', [g.item.uid]);
      linked.push({ uid: g.item.uid, name: g.item.name, fccc: `${g.line.description}${g.line.qty ? ` ${g.line.qty}` : ''}`, max: g.max });
    } catch (e) { /* that line has no price for our area – left for a person */ }
  }
  if (linked.length) { try { setSetting('fccc_auto_last', JSON.stringify({ at: stamp(), n: linked.length, names: linked.slice(0, 10).map((x) => x.name) })); } catch (e) { /* ignore */ } }
  return { linked };
}
// v3.9.4 the whole check runs by itself on the main tablet, with the shop prices the till PCs send from Aronium:
//  1. a new list → the new FCCC prices are taken for our linked products (copying the FCCC's own figures);
//  2. when every controlled product is within the FCCC price at every shop (prices from Aronium, sent in the last
//     day), the new list is ticked "checked by the app". Anything above stays an urgent warning – the selling price is
//     lowered in Aronium (by a person), the till PC sends it, and the list ticks itself.
function aroniumPricesFresh(hours = 26) {
  try {
    const rows = db().all("SELECT shop_code, MAX(updated_at) AS t FROM aronium_feed WHERE kind = 'products' GROUP BY shop_code");
    if (!rows.length) return false;
    return rows.every((r) => { const s = String(r.t || ''); const t = Date.parse(/Z$/.test(s) ? s : `${s.replace(' ', 'T').slice(0, 19)}Z`); return Number.isFinite(t) && Date.now() - t < hours * 3600000; });
  } catch (e) { return false; }
}
export function autoReview({ force = false } = {}) {
  if (!force && !marksHere()) return { taken: 0, ticked: 0 };
  let taken = 0;
  let ticked = 0;
  for (const c of pendingChanges().filter((x) => !x.missing && x.now > 0)) {
    try { setFcccPrice(APP_USER, c.item.uid, { controlled: true, max: c.now, name: c.item.fccc_name }); taken += 1; } catch (e) { /* left for a person */ }
  }
  if (aroniumPricesFresh() && !overPriced().length && !pendingChanges().length) {
    for (const l of uncheckedLists()) {
      if (!(readState(l.uid).lines > 0)) continue;
      try { markListChecked(APP_USER, l.uid, 'Checked by the app: every controlled product is within the FCCC price at each shop (prices from Aronium).'); ticked += 1; } catch (e) { /* already ticked */ }
    }
  }
  return { taken, ticked };
}

// Marked by the app and not yet confirmed by a person.
export function autoLinked() {
  if (!hasCol('inv_items', 'fccc_auto')) return [];
  return db().all('SELECT uid, code, name, fccc_name, fccc_max FROM inv_items WHERE fccc = 1 AND fccc_auto = 1 AND active = 1 ORDER BY name');
}
export function confirmFccc(user, itemUid) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = db().get('SELECT name FROM inv_items WHERE uid = ?', [itemUid]);
  need(it, 'Product not found.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_items SET fccc_auto = 0, ${SYNCED} WHERE uid = ?`, [now, dev, itemUid]);
  audit({ user, action: `Confirmed ${it.name} is FCCC controlled`, table: 'inv_items', recordUid: itemUid });
}
// "Not controlled" by a person: unmarked, and never marked by the app again.
export function rejectFccc(user, itemUid) {
  setFcccPrice(user, itemUid, { controlled: false });
  const { now, dev } = meta();
  db().run(`UPDATE inv_items SET fccc_auto = 0, fccc_reject = '*', ${SYNCED} WHERE uid = ?`, [now, dev, itemUid]);
}
// Possible matches (not marked) that are priced above the possible FCCC price at a shop.
export function possiblyOver() {
  const out = [];
  for (const g of suggestLinks({ limit: 100000 })) {
    if (g.score >= AUTO_SCORE || !(g.max > 0)) continue;
    const shops = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1', [g.item.uid])
      .map((x) => ({ shop: x.shop_code, price: x.price === null || x.price === undefined ? Number(g.item.price) || 0 : Number(x.price) }));
    if (!shops.length) shops.push({ shop: 'All', price: Number(g.item.price) || 0 });
    const over = shops.filter((x) => x.price > g.max + 0.004);
    if (over.length) out.push({ ...g, over });
  }
  return out;
}

// ---------------------------------------------------------------- the FCCC layout (v3.9.3, read from the real list)
// Item Description | Qty | 5 wholesale prices | Qty | 5 retail prices. Each row has a wholesale pack (e.g. 45kg) and,
// independently, a retail size (e.g. 1Kg) with their prices. The description sits in the middle of its group of rows
// (it can wrap over 2–3 lines, above, beside and below the rows). A heading line in the middle ("Rice") starts a section,
// often with "(VAT = 0%)". The produce list has an extra column (Own / Others) after the trader's name.
export function parseFcccTable(pagesLines) {
  const all = pagesLines.flatMap((ls) => ls.flatMap((l) => l.items));
  const qtyHeads = cluster(all.filter((it) => /^qty$/i.test(it.str)).map((it) => it.x), 12).sort((a, b) => a.x - b.x);
  if (qtyHeads.length < 2) return parseSimpleTable(pagesLines);
  const nums = all.filter((it) => PRICE.test(it.str));
  if (!nums.length) return [];
  const size = nums.reduce((t, it) => t + it.size, 0) / nums.length;
  const right = (it) => (it.end !== undefined ? it.end : it.x + it.str.length * it.size * 0.5);
  const qW = qtyHeads[0].x; const qR = qtyHeads[1].x;
  const cols = cluster(nums.map(right), Math.max(3, size * 0.6)).sort((a, b) => b.n - a.n).slice(0, 10).sort((a, b) => a.x - b.x);
  const wCols = cols.filter((c) => c.x > qW && c.x < qR).slice(0, 5);
  const rCols = cols.filter((c) => c.x > qR).slice(0, 5);
  const colOf = (it) => { const r = right(it); let best = null; for (const c of wCols.concat(rCols)) { const d = Math.abs(c.x - r); if (d <= Math.max(4, size * 0.9) && (!best || d < best.d)) best = { c, d }; } return best ? best.c : null; };
  const firstW = wCols.length ? Math.min(...wCols.map((c) => c.min)) - size * 3 : qR;
  const firstR = rCols.length ? Math.min(...rCols.map((c) => c.min)) - size * 3 : Infinity;
  const descEnd = qW - size * 1.2; // text left of the wholesale Qty column
  // A column of short labels between the description and Qty on most priced lines (Own / Others) is a variant.
  const pricedLines = pagesLines.flatMap((ls) => ls.filter((l) => l.items.some((it) => PRICE.test(it.str))));
  const mid = pricedLines.flatMap((l) => l.items.filter((it) => !PRICE.test(it.str) && it.x > 120 && it.x < descEnd && it.str.length <= 12));
  const vcl = cluster(mid.map((it) => it.x), 4).sort((a, b) => b.n - a.n)[0];
  const variantX = vcl && vcl.n >= Math.max(4, pricedLines.length * 0.5) ? vcl.x : null;
  const isVariant = (it) => variantX !== null && Math.abs(it.x - variantX) < 4 && it.str.length <= 12;
  const out = new Map();
  let section = ''; let vatNote = ''; let lastDesc = '';
  const add = (desc, variant, qty, prices, which, page) => {
    if (!prices.length) return;
    const name = `${desc}${variant ? ` (${variant})` : ''}`.replace(/\s+/g, ' ').trim();
    let key = `${normKey(`${section} ${name}`)}|${normQty(qty)}`;
    // The same size twice in one item with other prices (a slip in the list): kept as a second line, never overwritten.
    for (let n = 2; out.has(key) && prices.some((p) => { const arr = which === 'w' ? out.get(key).w : out.get(key).r; const i = (which === 'w' ? wCols : rCols).indexOf(p.c); return i >= 0 && arr[i] !== null && arr[i] !== p.v; }); n++) key = `${normKey(`${section} ${name}`)}|${normQty(qty)}#${n}`;
    const rec = out.get(key) || { key, description: name, qty: qty || '', section, vat: vatNote, w: [null, null, null, null, null], r: [null, null, null, null, null], page: page + 1 };
    for (const p of prices) { const arr = which === 'w' ? rec.w : rec.r; const i = (which === 'w' ? wCols : rCols).indexOf(p.c); if (i >= 0 && i < 5) arr[i] = p.v; }
    out.set(key, rec);
  };
  pagesLines.forEach((ls, page) => {
    // 1) each line: description text, variant, the two sizes and the two sets of prices
    const rows = []; const descs = [];
    for (const l of ls) {
      if (l.items.some((it) => HEADER.test(it.str))) continue;
      const pw = []; const pr = []; let qw = ''; let qr = ''; let variant = ''; const text = [];
      for (const it of l.items) {
        const c = PRICE.test(it.str) ? colOf(it) : null;
        if (c) { (wCols.includes(c) ? pw : pr).push({ c, v: Number(it.str.replace(/[$,]/g, '')) }); continue; }
        if (isVariant(it)) { variant = it.str; continue; }
        // The pack size sits under "Qty" (centred, so it can start a little to its left): "12 x 2kg".
        const centre = (it.x + (it.end !== undefined ? it.end : it.x + it.str.length * size * 0.5)) / 2;
        if (!qw && /^\d/.test(it.str) && centre > qW - size * 2.5 && it.x < firstW) { qw = it.str; continue; }
        if (it.x < descEnd) { text.push(it.str); continue; }
        if (it.x < firstW && !qw) { qw = it.str; continue; }
        if (it.x >= firstW && it.x < firstR && !qr && Math.abs(it.x - qR) < size * 6) { qr = it.str; continue; }
        text.push(it.str);
      }
      const priced = pw.length || pr.length;
      const leftText = text.filter((t) => l.items.some((it) => it.str === t && it.x < descEnd)).join(' ').trim();
      if (!priced) {
        if (!leftText) {
          // a heading in the middle of the page: "Rice", maybe with "(VAT = 0%)"
          const h = l.items.map((it) => it.str).filter((x) => !/^\(?vat\b/i.test(x)).join(' ').trim();
          const v = l.items.map((it) => it.str).find((x) => /^\(?vat\b/i.test(x));
          if (h && !/^\d+$/.test(h)) rows.push({ heading: true, y: l.y, section: h, vat: v ? v.replace(/[()]/g, '').trim() : '' });
          continue;
        }
      }
      if (leftText) descs.push({ y: l.y, text: leftText });
      if (priced) rows.push({ y: l.y, qw, qr, pw, pr, variant });
    }
    // 2) descriptions: lines close together form one description; its middle is the middle of its rows.
    const blocks = [];
    descs.sort((a, b) => b.y - a.y).forEach((d) => {
      const b = blocks[blocks.length - 1];
      if (b && b.bottom - d.y <= size * 1.9) { b.parts.push(d.text); b.bottom = d.y; } else blocks.push({ top: d.y, bottom: d.y, parts: [d.text] });
    });
    blocks.forEach((b) => { b.c = (b.top + b.bottom) / 2; b.text = b.parts.join(' '); });
    // 3) give each description its rows (the rows whose middle is the description's middle); headings split groups
    let i = 0;
    const segs = []; // [{ rows, heading }]
    let cur = [];
    rows.forEach((r) => { if (r.heading) { if (cur.length) segs.push(cur); segs.push([r]); cur = []; } else cur.push(r); });
    if (cur.length) segs.push(cur);
    let bi = 0;
    for (const seg of segs) {
      if (seg.length === 1 && seg[0].heading) { section = seg[0].section; vatNote = seg[0].vat; continue; }
      const segTop = seg[0].y; const segBottom = seg[seg.length - 1].y;
      const mine = blocks.filter((b, k) => k >= bi && b.c <= segTop + size * 1.2 && b.c >= segBottom - size * 1.2);
      bi += mine.length;
      i = 0;
      for (let k = 0; k < mine.length; k++) {
        const b = mine[k];
        let best = null;
        for (let s0 = i; s0 < seg.length && seg[s0].y >= b.c - size * 0.6; s0++) {
          for (let e = s0; e < seg.length; e++) {
            const err = Math.abs((seg[s0].y + seg[e].y) / 2 - b.c) + (s0 - i) * size * 0.25;
            if (!best || err < best.err) best = { s0, e, err };
            if (seg[e].y < b.c - (seg[s0].y - b.c) - size) break;
          }
        }
        if (!best) continue;
        // rows before the group: still the previous description (carried over from the page before)
        for (let j = i; j < best.s0; j++) { add(lastDesc, seg[j].variant, seg[j].qw, seg[j].pw, 'w', page); add(lastDesc, seg[j].variant, seg[j].qr, seg[j].pr, 'r', page); }
        const end = k === mine.length - 1 ? Math.max(best.e, best.e) : best.e;
        for (let j = best.s0; j <= end; j++) { add(b.text, seg[j].variant, seg[j].qw, seg[j].pw, 'w', page); add(b.text, seg[j].variant, seg[j].qr, seg[j].pr, 'r', page); }
        lastDesc = b.text;
        i = end + 1;
      }
      // rows after the last description of the group: the last description (it may go on to the next page)
      for (let j = i; j < seg.length; j++) { add(lastDesc, seg[j].variant, seg[j].qw, seg[j].pw, 'w', page); add(lastDesc, seg[j].variant, seg[j].qr, seg[j].pr, 'r', page); }
    }
  });
  return Array.from(out.values()).filter((r) => r.description);
}

// ---------------------------------------------------------------- v3.9.8 the full sweep
// Every active product is looked at against every line of the newest FCCC lists, with all the hints: the words of the
// name (short forms and plurals understood, brand words count less), the size (a name without a size is not skipped –
// it just counts less), and how close the shop price is to the FCCC price. Each possible match is graded Likely /
// Possible / Unlikely and goes into a Yes / No / Different line round. "No" is never asked again.
const SHORT = { flr: 'flour', fl: 'flour', brwn: 'brown', brn: 'brown', sug: 'sugar', sgr: 'sugar', wht: 'white', rce: 'rice', mlk: 'milk', pwd: 'powder', pdr: 'powder', bisc: 'biscuit', bisct: 'biscuit', vege: 'vegetable', veg: 'vegetable', oil: 'oil', tea: 'tea', crm: 'cream', crkr: 'cracker', ckr: 'cracker', snd: 'sandwich', sml: 'small', lg: 'large', choc: 'chocolate', bread: 'bread', bf: 'butter', bttr: 'butter', ghe: 'ghee', dhl: 'dhal', dal: 'dhal', lent: 'lentil', tin: 'tinned', tinned: 'tinned', fsh: 'fish', mack: 'mackerel', sard: 'sardine' };
const SWEEP_STOP = new Set(['the', 'of', 'in', 'and', 'if', 'on', 'its', 'own', 'to', 'for', 'a', 'with', 'retails', 'wholesales', 'another', 'party', 'pack', 'x', 'pkt', 'packet', 'each', 'ea', 'pc', 'pcs', 'bag', 'btl', 'bottle', 'tin', 'can']);
const stem = (w) => { const s = SHORT[w] || w; return s.length > 4 && s.endsWith('es') ? s.slice(0, -2) : s.length > 3 && s.endsWith('s') ? s.slice(0, -1) : s; };
const sweepWords = (t) => new Set(normKey(t).replace(/\d+(\.\d+)?\s*(kg|g|gm|ml|l|ltr|lt)\b/g, ' ').split(' ').filter((w) => w.length > 1 && !SWEEP_STOP.has(w) && !/^\d/.test(w)).map(stem));
export const GRADE = { likely: 'Likely', possible: 'Possible', unlikely: 'Unlikely' };
// Worked out at most every 10 minutes (and after each answer): it looks at every product.
let sweepCache = null;
export function sweepLinks({ limit = 500 } = {}) {
  let d = null;
  try { d = require('../../db/connection.js').db(); } catch (e) { d = null; }
  if (sweepCache && sweepCache.d === d && Date.now() - sweepCache.t < 600000) return sweepCache.v.slice(0, limit);
  const v = sweepAll();
  sweepCache = { d, t: Date.now(), v };
  return v.slice(0, limit);
}
function sweepAll() {
  const limit = 5000;
  if (!has('fccc_lines')) return [];
  const lines = [];
  for (const l of latestLists()) if (readState(l.uid).lines > 0) lines.push(...db().all('SELECT * FROM fccc_lines WHERE list_uid = ?', [l.uid]).map((x) => ({ ...lineRow(x), list: l })));
  if (!lines.length) return [];
  const SIZE = /(\d+(?:\.\d+)?)\s*(kg|g|gm|ml|l|ltr|lt)\b/i;
  const sizeOf = (t) => { const m = SIZE.exec(String(t || '')); if (!m) return null; let v = Number(m[1]); const u = m[2].toLowerCase(); if (u === 'g' || u === 'gm' || u === 'ml') v /= 1000; return Math.round(v * 1000) / 1000; };
  const prepared = lines.filter((ln) => !/\bx\b/i.test(String(ln.qty || ''))).map((ln) => ({ ln, size: sizeOf(ln.qty) || sizeOf(ln.description), words: sweepWords(ln.description), max: lineMax(ln) })).filter((p) => p.words.size);
  const rej = hasCol('inv_items', 'fccc_reject') ? " AND (fccc_reject IS NULL OR fccc_reject = '')" : '';
  const out = [];
  for (const it of db().all(`SELECT uid, code, name, price, group_name FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (fccc IS NULL OR fccc = 0)${rej}`)) {
    const ws = sweepWords(it.name);
    if (!ws.size) continue;
    const size = sizeOf(it.name);
    let shopPrices = [];
    try { shopPrices = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1', [it.uid]).map((x) => ({ shop: x.shop_code, price: x.price === null || x.price === undefined ? Number(it.price) || 0 : Number(x.price) })); } catch (e) { shopPrices = []; }
    if (!shopPrices.length) shopPrices = [{ shop: 'All', price: Number(it.price) || 0 }];
    const price = Math.max(...shopPrices.map((s) => s.price));
    let best = null;
    for (const p of prepared) {
      let common = 0; ws.forEach((w) => { if (p.words.has(w)) common += 1; });
      if (!common) continue;
      let score = common / Math.max(ws.size, 1) + (common / Math.max(p.words.size, 1)) * 0.5;
      const why = [];
      if (size !== null && p.size !== null) { if (Math.abs(size - p.size) > 0.0001) continue; score += 0.25; why.push('same size'); }
      else { score -= 0.1; why.push('no size to compare'); }
      if (p.max > 0 && price > 0) {
        const ratio = price / p.max;
        if (ratio >= 0.7 && ratio <= 1.3) { score += 0.25; why.push('price close to the FCCC price'); } else if (ratio > 2.5 || ratio < 0.35) { score -= 0.3; why.push('price far from the FCCC price'); }
      }
      if (it.group_name && p.words.has(stem(normKey(it.group_name).split(' ')[0] || ''))) score += 0.05;
      if (!best || score > best.score) best = { score, p, why };
    }
    if (!best || best.score < 0.55) continue;
    const grade = best.score >= 1.2 ? 'likely' : best.score >= 0.85 ? 'possible' : 'unlikely';
    out.push({ item: it, line: best.p.ln, list: best.p.ln.list, max: best.p.max, score: Math.round(best.score * 100) / 100, grade, why: best.why, shops: shopPrices, over: best.p.max > 0 ? shopPrices.filter((s) => s.price > best.p.max + 0.004) : [] });
  }
  return out.sort((a, b) => b.score - a.score).slice(0, limit);
}
// The round: what is left to answer, and how many were answered since the sweep started.
export function sweepRound() {
  const left = sweepLinks({ limit: 2000 });
  const st = getShared('fccc_sweep', null) || { at: null, answered: 0 };
  return { left, answered: st.answered || 0, total: left.length + (st.answered || 0), startedAt: st.at };
}
function noteAnswer() {
  const st = getShared('fccc_sweep', null) || { at: stamp(), answered: 0 };
  setShared('fccc_sweep', { at: st.at || stamp(), answered: (st.answered || 0) + 1 });
}
export function startSweep(user) {
  sweepCache = null;
  setShared('fccc_sweep', { at: stamp(), answered: 0, by: user ? user.name : null });
  return sweepRound();
}
export function answerSweep(user, itemUid, answer, { listUid, rowKey } = {}) {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  if (answer === 'yes') { linkProduct(user, itemUid, listUid, rowKey); try { db().run('UPDATE inv_items SET fccc_auto = 0 WHERE uid = ?', [itemUid]); } catch (e) { /* older database */ } }
  else if (answer === 'no') rejectFccc(user, itemUid);
  else throw new AppError('Answer Yes or No.');
  sweepCache = null;
  noteAnswer();
}
