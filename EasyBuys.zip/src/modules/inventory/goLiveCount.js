// v3.9.8 / 1.0.0 the first (go-live) stock take. 1.0.0: the stock lives in the app only (sales from the till PCs take it
// off); Aronium's stock is not kept up to date, so the Aronium count sheet below is no longer offered on the screens
// (kept for a later decision).
// Aronium has no file import for a stock count: its product CSV import ADDS the Quantity column to the stock and can
// create or change products – used for a count it would double the stock or spoil products. So the app never makes a
// file for Aronium. Instead it makes the "Aronium count sheet": every product with its counted quantity, in Aronium's
// own order (group, then name), to type into Aronium's own stock count document
//   Management › Documents › Add › Inventory › "300 – Inventory count" (date = when the count was done),
// which sets each product to the counted quantity (Aronium works out the change itself). Ticks show what is typed in.
// Also: things to count that are not products (empty gas cylinders), and the checklist for the night of the count.
import { db } from '../../db/connection.js';
import { getShared, setShared, stamp, audit, AppError } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const r3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };

// ---------------------------------------------------------------- things that are not products
export const EXTRA_DEFAULTS = [
  { key: 'gas_empty_4_5', label: 'Empty gas cylinders – 4.5 kg' },
  { key: 'gas_empty_12', label: 'Empty gas cylinders – 12 kg' },
  { key: 'gas_empty_40', label: 'Empty gas cylinders – 40 kg' },
  { key: 'gas_empty_50', label: 'Empty gas cylinders – 50 kg' },
];
const XKEY = (countUid) => `count_extras_${countUid}`;
export function countExtras(countUid) {
  const saved = (getShared(XKEY(countUid), null) || {}).lines || [];
  const keys = new Set(saved.map((l) => l.key));
  return saved.concat(EXTRA_DEFAULTS.filter((d) => !keys.has(d.key)).map((d) => ({ ...d, qty: null })));
}
export function saveExtra(user, countUid, { key, label, qty }) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const c = db().get('SELECT uid, status FROM inv_counts WHERE uid = ?', [countUid]);
  need(c, 'Stock take not found.');
  const n = qty === '' || qty === null || qty === undefined ? null : Number(String(qty).replace(/[,\s]/g, ''));
  need(n === null || (Number.isFinite(n) && n >= 0 && n < 100000), 'Type how many (0 or more).');
  const k = txt(key) || `x_${txt(label).toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 30)}`;
  const lab = txt(label) || (EXTRA_DEFAULTS.find((d) => d.key === k) || {}).label;
  need(lab, 'Write what is counted (e.g. "Empty crates").');
  const cur = (getShared(XKEY(countUid), null) || {}).lines || [];
  const lines = cur.filter((l) => l.key !== k).concat([{ key: k, label: lab.slice(0, 80), qty: n === null ? null : r3(n), by: user.name, at: stamp() }]);
  setShared(XKEY(countUid), { lines });
  audit({ user, action: `Stock take: ${lab} = ${n === null ? '–' : n}`, table: 'inv_counts', recordUid: countUid });
  return countExtras(countUid);
  });
}

// ---------------------------------------------------------------- the Aronium count sheet
const EKEY = (countUid) => `aronium_entered_${countUid}`;
export function aroniumSheet(countUid, { all = false } = {}) {
  const I = require('./service.js');
  const c = I.getCount(countUid);
  need(c, 'Stock take not found.');
  let ar = new Map();
  try { ar = new Map(require('../aronium/link.js').aroniumStock(c.shop_code).map((x) => [txt(x.code).toUpperCase(), Number(x.qty) || 0])); } catch (e) { ar = new Map(); }
  const entered = new Set((getShared(EKEY(countUid), null) || {}).codes || []);
  const rows = (c.lines || []).filter((l) => l.counted !== null && l.counted !== undefined).map((l) => {
    const key = txt(l.code).toUpperCase();
    const inAronium = ar.has(key) ? r3(ar.get(key)) : null;
    const counted = r3(l.counted);
    return { code: l.code, barcode: txt(l.barcode).split(',')[0] || '', name: l.name, group: l.group_name || '', unit: l.unit || '', counted, inAronium, diff: inAronium === null ? null : r3(counted - inAronium), entered: entered.has(l.code) };
  });
  const list = rows.filter((r) => all || r.diff === null || Math.abs(r.diff) > 1e-9)
    .sort((a, b) => (a.group || '~').localeCompare(b.group || '~') || a.name.localeCompare(b.name));
  return {
    count: { uid: c.uid, shop: c.shop_code, name: c.name, status: c.status, date: c.count_date || c.date || null, timing: c.timing || null },
    rows: list, total: rows.length, toType: list.length, entered: list.filter((r) => r.entered).length,
    same: rows.filter((r) => r.diff !== null && Math.abs(r.diff) <= 1e-9).length, notInAronium: rows.filter((r) => r.inAronium === null).length,
    aroniumKnown: ar.size > 0,
  };
}
export function markEntered(user, countUid, code, on = true) {
  requirePerm(user, 'stocktake_count'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || safe(() => require('../../services/access.js').can(user, 'inventory_manage'), false)), 'Only a manager, the admin or the owner ticks what is typed into Aronium.');
  const cur = new Set((getShared(EKEY(countUid), null) || {}).codes || []);
  if (on) cur.add(code); else cur.delete(code);
  setShared(EKEY(countUid), { codes: [...cur], by: user.name, at: stamp() });
  });
}
// The sheet as a document (PDF / Excel / print) – to type from at the till PC.
export function aroniumSheetDoc(countUid, { all = false } = {}) {
  const s = aroniumSheet(countUid, { all });
  const col = (key, title, align = 'left') => ({ key, title, align });
  return {
    kind: 'aronium_count_sheet', title: `Aronium Count Sheet ${s.count.shop}`, fileName: `Aronium-count-sheet-${s.count.shop}-${s.count.uid.slice(-6)}`,
    subtitle: `Type into Aronium: Management › Documents › Add › Inventory › 300 – Inventory count`,
    info: [['Shop', s.count.shop], ['Stock take', s.count.name || ''], ['Count date', s.count.date || ''], ['Made', stamp()],
      ['How', 'In Aronium make ONE "300 – Inventory count" document dated when the counting was done. For each line: find the product, type the Counted quantity, then Save the document. Aronium sets the stock to the counted quantity itself. Do NOT use Import products for this – it adds to the stock and can change products.']],
    summary: [{ label: 'Lines to type', value: String(s.toType) }, { label: 'Already the same in Aronium', value: String(s.same) }, { label: 'Not found in Aronium', value: String(s.notInAronium) }],
    sections: [{ title: all ? 'Every counted product' : 'Products to type into Aronium',
      columns: [col('group', 'Group'), col('code', 'Code (SKU)'), col('barcode', 'Barcode'), col('name', 'Product'), col('counted', 'COUNTED – type this', 'right'), col('inAronium', 'Aronium had', 'right'), col('diff', 'Change', 'right'), col('tick', 'Typed ✓')],
      rows: s.rows.map((r) => ({ ...r, inAronium: r.inAronium === null ? 'not found' : r.inAronium, diff: r.diff === null ? '' : `${r.diff > 0 ? '+' : ''}${r.diff}`, tick: r.entered ? '✓' : '' })) }],
  };
}

// ---------------------------------------------------------------- the night of the first stock take
export function goLiveCountChecklist(shopCode) {
  const I = require('./service.js');
  const rules = safe(() => I.invRules(), {});
  const groups = (rules.doubleCountGroups || []).map((g) => String(g).toLowerCase()).filter(Boolean);
  const doubleProducts = groups.length ? safe(() => db().all('SELECT group_name FROM inv_items WHERE IFNULL(active,1) = 1').filter((r) => groups.some((g) => String(r.group_name || '').toLowerCase().includes(g))).length, 0) : 0;
  let link = null;
  try { const st = require('../aronium/link.js').linkStatus(); const t = (st.tills || []).filter((x) => !shopCode || x.shop === shopCode); link = t.length ? t.map((x) => ({ till: x.till, lastSeen: x.lastSeen })) : []; } catch (e) { link = null; }
  return {
    doubleGroups: rules.doubleCountGroups || [], doubleProducts, link,
    steps: [
      'After the last sale: do the End of day on every till in Aronium and balance the tills in the app.',
      'Check the till PCs are on and the Aronium Link has sent in the last hour (so all of today\'s sales are in the app before counting).',
      'Start one stock take for this shop: "First stock take – every product", counted after closing.',
      'Share out the areas (shelves, storeroom, fridge, bakery store): each counter takes an area and marks it done.',
      'Count cartons and singles; scan barcodes where you can. A product not on the list can be added by scanning it.',
      `Cigarettes and liquor (${(rules.doubleCountGroups || []).join(', ') || 'the double-count groups'}) are counted again by a second person – both must agree.`,
      'Gas: full cylinders are products; count the EMPTY cylinders under "Other things to count".',
      `Not counted (sales only): ${(rules.noStockGroups || []).join(', ') || '—'} – they are sold and recorded but have no stock in the app.`,
      'Packs also sold loose (e.g. Maggi 5 pack and one Maggi): link them first (Stock & orders › Packs sold loose); then count the packs, and the open loose ones in the pack\'s "loose" box.',
      'Products packed in the shop (e.g. rice from a 25 kg bag into 1 kg packets): count the full bulk bags AND the packs made – both are stock. From then on record each pack-up in Stock & orders › Pack for sale.',
      'Bakery ingredients: Bakery › Close & count (flour, sugar, yeast…).',
      'Selling prices of THIS shop: check each product\'s price on its line (Edit cost / price / VAT) – each shop has its own prices.',
      'Hand in. The manager looks at the differences and asks for a recount where needed, then Approve – this is the opening stock.',
      'After approval the app keeps this shop\'s prices, the costs (from invoices) and VAT: Stock & orders › App vs Aronium shows what differs and makes the file to import into Aronium (never a quantity).',
      'From then on the stock is kept in the Easy Buys app only: every sale from the till PCs takes it off, deliveries add to it. Aronium\'s own stock numbers are not used and do not need changing.',
    ],
  };
}
