// 1.0.0 Staff screens' services (the new simple app):
//  • Goods came in – one compact save. REQUIRED: the supplier, the invoice no., the amount, and at least one product
//    line (or "no products – just a bill"). Products come from the AI reading or are added by hand. With products it is
//    a delivery (stock in, supplier products linked by themselves, cost per item); without, it is a bill (an invoice).
//  • Damaged goods – a product, how many, what is wrong, the invoice it came on, and whether the supplier replaces it.
//    "Yes": kept aside and owed by the supplier (flags on Today until replaced or credited). "No": written off.
//  • Products with no supplier – give many Aronium products a supplier at once.
import { db } from '../../db/connection.js';
import { AppError, dateStr } from '../../services/core.js';
import { can, reasonRequired } from '../../services/access.js';
import * as I from './service.js';
import { requirePerm, requireShop, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;

export const WHAT_CAME = { stock: 'Stock for the shop', bakery: 'Bakery ingredients', bill: 'A bill (no goods)' };
export const DAMAGE_WHY = { expired: 'Expired', broken: 'Broken / torn', leaking: 'Leaking', crushed: 'Crushed', wrong: 'Wrong product', other: 'Something else' };

// What is missing before Goods came in can be saved (the screen shows it; the save checks it again).
export function goodsMissing(f = {}) {
  const out = [];
  if (!txt(f.supplierUid)) out.push('the supplier');
  if (!txt(f.invoiceNo)) out.push('the invoice no.');
  if (!(r2(f.amount) > 0)) out.push('the amount');
  const lines = (f.lines || []).filter((l) => l && l.itemUid && q3(l.qty) > 0);
  if (!lines.length && !f.noProducts) out.push('at least one product (or tick "no products – just a bill")');
  return out;
}
// f: { supplierUid, shopCode, invoiceNo, amount, vat, date, what, poUid, lines: [{ itemUid, qty, unitCost }], noProducts,
//      photos, readUid, acceptReason, category }
export function goodsCameIn(user, f = {}) {
  requirePerm(user, ['po_receive', 'invoices_enter'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, f && (f.shopCode || f.shop)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(user, 'Log in first.');
  const miss = goodsMissing(f);
  need(!miss.length, `Fill in ${miss.join(', ')}.`);
  const shop = txt(f.shopCode) || user.shop_code;
  need(shop, 'Choose the shop.');
  const d = txt(f.date) || dateStr();
  const photos = f.photos || [];
  need(photos.length || !reasonRequired(user), 'Take a photo of the invoice first.');
  const AP = require('../payables/service.js');
  if (f.noProducts || f.what === 'bill') {
    const inv = AP.saveInvoice(user, { supplierUid: f.supplierUid, invoiceNo: f.invoiceNo, total: r2(f.amount), vat: txt(f.vat) === '' ? undefined : r2(f.vat), invoiceDate: d, shopCode: shop,
      category: txt(f.category) || undefined, notes: `Goods came in – no products (just a bill). Saved by ${user.name}` }, { photos, allowDuplicate: !!f.allowDuplicate, askSimilar: true });
    return { kind: 'bill', invoice: inv };
  }
  const lines = (f.lines || []).filter((l) => l && l.itemUid && q3(l.qty) > 0);
  // Against an order: its lines are matched by product; anything else is extra.
  let o = null;
  if (txt(f.poUid)) { o = I.getPO(f.poUid); need(o && o.supplier_uid === f.supplierUid, 'That order is for another supplier.'); }
  const poLines = []; const extra = [];
  for (const l of lines) {
    const pl = o ? o.lines.find((x) => x.item_uid === l.itemUid && !poLines.some((p) => p.lineUid === x.uid)) : null;
    if (pl) poLines.push({ lineUid: pl.uid, qty: l.qty, unitCost: l.unitCost });
    else extra.push({ itemUid: l.itemUid, qty: l.qty, unitCost: l.unitCost });
  }
  if (o && !['approved', 'sent', 'part'].includes(o.status)) { o = null; extra.push(...poLines.map((p) => ({ itemUid: (I.getPO(f.poUid).lines.find((x) => x.uid === p.lineUid) || {}).item_uid, qty: p.qty, unitCost: p.unitCost }))); poLines.length = 0; }
  const r = I.receiveDelivery(user, { poUid: o ? o.uid : undefined, supplierUid: f.supplierUid, shopCode: shop, date: d, lines: poLines, extra,
    invoice: { invoiceNo: txt(f.invoiceNo), total: r2(f.amount), date: d, photos, allowDuplicate: !!f.allowDuplicate }, photos, readUid: f.readUid || undefined, acceptReason: f.acceptReason, notes: f.what === 'bakery' ? 'Bakery ingredients' : undefined });
  return { kind: 'delivery', ...r };
  });
}

// ---------------------------------------------------------------- damaged goods (staff)
// The invoices a product could have come on (newest first): deliveries from the last 90 days with that product.
export function invoicesForProduct(itemUid, shopCode, { days = 90 } = {}) {
  if (!itemUid) return [];
  const from = new Date(Date.parse(`${dateStr()}T00:00:00`) - days * 86400000).toISOString().slice(0, 10);
  const rows = db().all("SELECT uid, supplier_uid, supplier_name, invoice_uid, invoice_no, receive_date, lines FROM inv_receipts WHERE kind = 'receive' AND IFNULL(status,'active') <> 'void' AND receive_date >= ? AND (? IS NULL OR shop_code = ?) ORDER BY receive_date DESC LIMIT 400", [from, shopCode || null, shopCode || null]);
  return rows.filter((r) => { try { return JSON.parse(r.lines || '[]').some((l) => l.itemUid === itemUid); } catch (e) { return false; } })
    .map((r) => ({ receiptUid: r.uid, invoiceUid: r.invoice_uid, invoiceNo: r.invoice_no, supplierUid: r.supplier_uid, supplierName: r.supplier_name, date: r.receive_date, label: `${r.invoice_no || 'no invoice no.'} (${r.receive_date.slice(8)}/${r.receive_date.slice(5, 7)}) – ${r.supplier_name}` }));
}
// f: { itemUid, qty, why, receiptUid, replaces: true | false, photos, note, shopCode }
export function damagedGoods(user, f = {}) {
  requirePerm(user, ['snap_upload', 'po_receive', 'inventory_manage'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const it = I.getItem(f.itemUid);
  need(it, 'Choose the product.');
  const q = q3(f.qty);
  need(q > 0, 'How many?');
  need(DAMAGE_WHY[f.why], 'Say what is wrong.');
  need(typeof f.replaces === 'boolean', 'Say if the supplier replaces it.');
  const note = `${DAMAGE_WHY[f.why]}${txt(f.note) ? ` – ${txt(f.note)}` : ''}`;
  if (f.replaces) {
    need(txt(f.receiptUid), 'Choose the invoice it came on.');
    return { owed: require('./supplierOwed.js').reportDamaged(user, { receiptUid: f.receiptUid, itemUid: it.uid, qty: q, note, photos: f.photos || [] }) };
  }
  // not replaced: off the stock as damaged (the photo is kept with it)
  const shop = txt(f.shopCode) || user.shop_code;
  need(shop, 'Choose the shop.');
  need((f.photos || []).length || !reasonRequired(user), 'Take a photo of the damaged goods.');
  const move = I.addMove({ itemUid: it.uid, shopCode: shop, date: dateStr(), type: 'adjust', qty: -q, unitCost: it.cost, refType: 'damaged', refUid: f.receiptUid || null, reason: `Damaged – ${note}`, note: f.receiptUid ? 'Supplier does not replace it' : null, user });
  try { require('../../services/stock.js').addPhotos('damaged', typeof move === 'string' ? move : it.uid, f.photos || []); } catch (e) { /* the write-off stands */ }
  return { writtenOff: true };
  });
}

// ---------------------------------------------------------------- products with no supplier: many at once
export function assignSupplier(user, itemUids = [], supplierUid) {
  need(user && (can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role)), 'You cannot change products.');
  need(supplierUid, 'Choose the supplier.');
  const list = [...new Set((itemUids || []).filter(Boolean))];
  need(list.length, 'Tick the products first.');
  db().transaction(() => { for (const u of list) I.addItemSupplier(user, u, supplierUid, { main: !(I.getItem(u) || {}).supplier_uid }); });
  return list.length;
}
// The Aronium groups of products with no supplier (to tick a whole group at once), with how many in each.
export function noSupplierGroups() {
  const m = new Map();
  for (const p of I.productsWithoutSupplier({ limit: 100000 })) m.set(p.group_name || '(no group)', (m.get(p.group_name || '(no group)') || 0) + 1);
  return [...m.entries()].map(([group, n]) => ({ group, n })).sort((a, b) => b.n - a.n);
}
