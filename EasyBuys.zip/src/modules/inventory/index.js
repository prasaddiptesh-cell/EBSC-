// Inventory, purchase orders and stock take (each shop separately).
import { InventoryHomeScreen, StockScreen, ProductScreen, StockAdjustScreen, TransfersScreen, InvImportScreen, CostChangesScreen, InventorySetupScreen } from './screens/InventoryScreens.js';
import { POListScreen, POEditScreen, POViewScreen, POReceiveScreen, ReceiptScreen, SupplierReturnScreen } from './screens/POScreens.js';
import { StockTakesScreen, StockCountScreen } from './screens/StockTakeScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

const any = (u) => ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve', 'inventory_setup'].some((p) => can(u, p));
const po = (u) => ['po_create', 'po_approve', 'po_receive'].some((p) => can(u, p));
export default {
  id: 'inventory',
  title: 'Inventory & orders',
  icon: '📦',
  switchable: true,
  screens: {
    Inventory: { component: InventoryHomeScreen, can: any },
    InvStock: { component: StockScreen, can: (u) => can(u, 'inventory_view') || can(u, 'inventory_manage') },
    InvProduct: { component: ProductScreen, can: any },
    StockAdjust: { component: StockAdjustScreen, can: (u) => can(u, 'inventory_manage') },
    Transfers: { component: TransfersScreen, can: (u) => can(u, 'inventory_manage') || can(u, 'inventory_view') },
    InvImport: { component: InvImportScreen, can: (u) => can(u, 'inventory_manage') },
    CostChanges: { component: CostChangesScreen, can: (u) => can(u, 'inventory_view') || can(u, 'inventory_manage') },
    InventorySetup: { component: InventorySetupScreen, can: (u) => can(u, 'inventory_setup') },
    POList: { component: POListScreen, can: po },
    POEdit: { component: POEditScreen, can: (u) => can(u, 'po_create') },
    POView: { component: POViewScreen, can: po },
    POReceive: { component: POReceiveScreen, can: (u) => can(u, 'po_receive') },
    Receipt: { component: ReceiptScreen, can: any },
    SupplierReturn: { component: SupplierReturnScreen, can: (u) => can(u, 'inventory_manage') },
    StockTakes: { component: StockTakesScreen, can: (u) => can(u, 'stocktake_count') || can(u, 'stocktake_approve') },
    StockCount: { component: StockCountScreen, can: (u) => can(u, 'stocktake_count') || can(u, 'stocktake_approve') },
  },
  reports: REPORTS,
};
