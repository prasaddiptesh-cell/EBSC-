// Inventory, purchase orders and stock take (each shop separately).
import { InventoryHomeScreen, StockScreen, ProductScreen, StockAdjustScreen, TransfersScreen, InvImportScreen, CostChangesScreen, InventorySetupScreen } from './screens/InventoryScreens.js';
import { ShrinkageScreen, StockExpiryScreen } from './screens/LossScreens.js';
import { SupplierOwedScreen, ReportDamagedScreen } from './screens/OwedScreens.js';
import { ProductChecksScreen } from './screens/ProductCheckScreens.js';
import { AroniumUpdateScreen } from './screens/AroniumUpdateScreens.js';
import { LooseLinksScreen } from './screens/LooseScreens.js';
import { SupplierMatchScreen, SupplierPricesScreen } from './screens/SupplierMatchScreens.js';
import { RepackScreen } from './screens/RepackScreens.js';
import { PriceTicketsScreen } from './screens/TicketScreens.js';
import { POListScreen, POEditScreen, POViewScreen, POReceiveScreen, ReceiptScreen, SupplierReturnScreen, InvoiceQuestionsScreen } from './screens/POScreens.js';
import { StockTakesScreen, StockCountScreen, AroniumCountSheetScreen } from './screens/StockTakeScreens.js';
import { TodaysOrdersScreen, SupplierSchedulesScreen, SupplierImportScreen, POHistoryScreen, DeliveryFixScreen, InvoiceReadScreen } from './screens/OrderScreens35.js';
import { ProductsScreen, ProductNewScreen } from './screens/ProductsScreens.js';
import { FcccScreen, VatCheckScreen, ProductChangesScreen, LpgScreen, FcccSweepScreen } from './screens/FcccScreens.js';
import { REPORTS } from './reports.js';
import { GoodsCameInScreen, DamagedGoodsScreen, DamagedWaitingScreen, StockTakeJoinScreen } from './screens/GoodsInScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { openInitialCounts } from './service.js';

const any = (u) => ['inventory_view', 'inventory_manage', 'po_create', 'po_approve', 'po_receive', 'stocktake_count', 'stocktake_approve', 'inventory_setup'].some((p) => can(u, p));
const po = (u) => ['po_create', 'po_approve', 'po_receive'].some((p) => can(u, p));
export default {
  id: 'inventory',
  title: 'Inventory & orders',
  icon: '📦',
  switchable: true,
  screens: {
    Inventory: { component: InventoryHomeScreen, can: any },
    InvStock: { component: StockScreen, can: (u) => can(u, 'inventory_view') || can(u, 'inventory_manage') },
    InvProduct: { component: ProductScreen, can: any },
    InvProducts: { component: ProductsScreen, can: any },
    ProductNew: { component: ProductNewScreen, can: (u) => can(u, 'inventory_manage') },
    StockAdjust: { component: StockAdjustScreen, can: (u) => can(u, 'inventory_manage') },
    Transfers: { component: TransfersScreen, can: (u) => can(u, 'inventory_manage') || can(u, 'inventory_view') },
    InvImport: { component: InvImportScreen, can: (u) => can(u, 'inventory_manage') },
    Fccc: { component: FcccScreen, can: (u) => !!u }, // v3.9.5 everyone may look at the FCCC prices; only stock managers change them
    VatCheck: { component: VatCheckScreen, can: any },
    ProductChanges: { component: ProductChangesScreen, can: any },
    Lpg: { component: LpgScreen, can: any },
    FcccSweep: { component: FcccSweepScreen, can: any },
    CostChanges: { component: CostChangesScreen, can: (u) => can(u, 'inventory_view') || can(u, 'inventory_manage') },
    InventorySetup: { component: InventorySetupScreen, can: (u) => can(u, 'inventory_setup') },
    POList: { component: POListScreen, can: po },
    POEdit: { component: POEditScreen, can: (u) => can(u, 'po_create') },
    POView: { component: POViewScreen, can: po },
    POReceive: { component: POReceiveScreen, can: (u) => can(u, 'po_receive') },
    Receipt: { component: ReceiptScreen, can: any },
    InvoiceQuestions: { component: InvoiceQuestionsScreen, can: any },
    SupplierOwed: { component: SupplierOwedScreen, can: any },
    ProductChecks: { component: ProductChecksScreen, can: any },
    AroniumUpdate: { component: AroniumUpdateScreen, can: any },
    LooseLinks: { component: LooseLinksScreen, can: any },
    SupplierMatch: { component: SupplierMatchScreen, can: any },
    SupplierPrices: { component: SupplierPricesScreen, can: any },
    Repack: { component: RepackScreen, can: any },
    PriceTickets: { component: PriceTicketsScreen, can: any },
    ReportDamaged: { component: ReportDamagedScreen, can: any },
    SupplierReturn: { component: SupplierReturnScreen, can: (u) => can(u, 'inventory_manage') },
    Shrinkage: { component: ShrinkageScreen, can: (u) => can(u, 'inventory_view') },
    StockExpiry: { component: StockExpiryScreen, can: (u) => can(u, 'inventory_view') || can(u, 'stocktake_count') },
    StockTakes: { component: StockTakesScreen, can: (u) => can(u, 'stocktake_count') || can(u, 'stocktake_approve') },
    // Anyone may help with the first (initial) stock take.
    AroniumCountSheet: { component: AroniumCountSheetScreen, can: (u) => can(u, 'stocktake_approve') || can(u, 'inventory_manage') || can(u, 'stocktake_count') },
    StockCount: { component: StockCountScreen, can: (u) => can(u, 'stocktake_count') || can(u, 'stocktake_approve') || openInitialCounts().length > 0 },
    TodaysOrders: { component: TodaysOrdersScreen, can: po },
    SupplierSchedules: { component: SupplierSchedulesScreen, can: (u) => can(u, 'inventory_setup') || can(u, 'po_approve') },
    SupplierImport: { component: SupplierImportScreen, can: (u) => can(u, 'inventory_manage') },
    POHistory: { component: POHistoryScreen, can: po },
    DeliveryFix: { component: DeliveryFixScreen, can: (u) => can(u, 'po_receive') || can(u, 'inventory_manage') },
    // 1.0.0 staff: Goods came in, Damaged goods, the shared stock take; office: damaged waiting for replacement
    GoodsCameIn: { component: GoodsCameInScreen, can: (u) => ['snap_upload', 'po_receive', 'invoices_enter', 'bakery'].some((p) => can(u, p)) },
    DamagedGoods: { component: DamagedGoodsScreen, can: (u) => !!u && u.role !== 'accountant' },
    DamagedWaiting: { component: DamagedWaitingScreen, can: (u) => any(u) || can(u, 'verify_money') },
    StockTakeJoin: { component: StockTakeJoinScreen, can: (u) => !!u && u.role !== 'accountant' },
    InvoiceRead: { component: InvoiceReadScreen, can: (u) => ['po_receive', 'po_create', 'inventory_manage', 'invoices_enter'].some((p) => can(u, p)) },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
