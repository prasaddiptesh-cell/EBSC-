// 1.0.0 Invoices: learn each supplier's format by itself, and ask when something is not clear – at the right level.
//   • The RECEIVER (who counts the goods) is asked about prices and how many: "the invoice says 10, you counted 8 –
//     which is right?", "the invoice price is $12.50, the order said $11.00 – new price, or a mistake to claim back?".
//     The answers become the reason saved with the delivery (no typing needed) and any claim to chase.
//   • The VERIFIER (To verify) is asked the rest: a supplier not recognised, no invoice number or date read, a total
//     that does not add up, lines not matched to a product, the first invoice in a new format. Each answer teaches
//     the app (the supplier's layout, its names for our products), so the next invoice is read right.
//   • Every delivery that was read from a photo also teaches the app by itself: what the receiver kept (invoice number,
//     total, which product each line is) is compared with what was read, and the differences are learnt.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit } from '../../services/core.js';
import * as I from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const n = (v) => (v === '' || v === null || v === undefined || !Number.isFinite(Number(v)) ? null : Number(v));
const $ = (v) => `$${(Number(v) || 0).toFixed(2)}`;
const fq = (v) => String(Math.round((Number(v) || 0) * 1000) / 1000);
const IR = () => require('./invoiceRead.js');

// ---------------------------------------------------------------- the receiver: prices and how many
// read: the invoice reading ({ lines: [{ itemUid, qty, unitCost, description }] }); lines: what is on the receiving
// screen now: [{ key, itemUid, name, counted, cost, orderCost }] (cost = the price per single being entered).
// ctx: { supplierUid, missing: [{ itemUid, name }] – ordered, not on the invoice and not counted }.
const OW = () => require('./supplierOwed.js');
export function receiverQuestions(read, lines = [], ctx = {}) {
  const rules = (() => { try { return I.invRules(); } catch (e) { return { priceTolerancePct: 2 }; } })();
  const tol = Math.max(0.5, Number(rules.priceTolerancePct) || 2);
  const out = [];
  const byItem = new Map();
  for (const l of (read && read.lines) || []) if (l.itemUid) byItem.set(l.itemUid, (byItem.get(l.itemUid) || []).concat([l]));
  const onForm = new Map(lines.filter((l) => l && l.itemUid).map((l) => [l.itemUid, l]));
  for (const l of lines) {
    if (!l || !l.itemUid) continue;
    const inv = byItem.get(l.itemUid);
    const counted = n(l.counted);
    if (inv && counted !== null) {
      const invQty = inv.reduce((s, x) => s + (Number(x.qty) || 0), 0);
      if (Math.abs(invQty - counted) > 1e-9) {
        const less = counted < invQty;
        const miss = fq(invQty - counted);
        out.push({ id: `qty:${l.itemUid}`, kind: 'qty', key: l.key, itemUid: l.itemUid, name: l.name, invoiced: invQty, counted, cost: n(l.cost) || 0,
          text: `${l.name}: the invoice says ${fq(invQty)}, you counted ${fq(counted)}. Which is right?`,
          options: (less ? [
            { value: 'counted', label: `Only ${fq(counted)} came – the supplier owes ${miss}` },
            { value: 'damaged', label: `${miss} came damaged – to replace or credit` }] : [
            { value: 'counted', label: `${fq(counted)} came – more than invoiced` }]).concat([
            { value: 'invoice', label: `The invoice is right – ${fq(invQty)} came` },
            { value: 'recount', label: 'I will count again' }]) });
      }
    }
    const cost = n(l.cost);
    const ref = n(l.orderCost) !== null && n(l.orderCost) > 0 ? { v: n(l.orderCost), what: 'the order' } : (() => { const it = I.getItem(l.itemUid); return it && it.cost > 0 ? { v: it.cost, what: 'the last price' } : null; })();
    if (cost !== null && ref && Math.abs(cost - ref.v) / ref.v * 100 > tol + 1e-9) {
      out.push({ id: `price:${l.itemUid}`, kind: 'price', key: l.key, itemUid: l.itemUid, name: l.name, price: cost, was: ref.v, against: ref.what, qty: counted || 0,
        text: `${l.name}: ${$(cost)} each on the invoice, ${ref.what} was ${$(ref.v)} (${cost > ref.v ? '+' : ''}${Math.round(((cost - ref.v) / ref.v) * 1000) / 10}%). Is the new price right?`,
        options: [
          { value: 'accept', label: `Yes – the new price is ${$(cost)}` },
          { value: 'claim', label: `No – supplier charged wrong, claim back the difference` },
          { value: 'old', label: `Use ${ref.what} price ${$(ref.v)}` }] });
    }
    // the supplier owes this product from before (not delivered / short / damaged): are some of these them?
    if (ctx.supplierUid && counted > 0) {
      let owed = [];
      try { owed = OW().owedFor(ctx.supplierUid, l.itemUid); } catch (e) { owed = []; }
      if (owed.length) {
        const left = owed.reduce((t, o) => t + o.left, 0);
        out.push({ id: `owed:${l.itemUid}`, kind: 'owed', key: l.key, itemUid: l.itemUid, name: l.name, counted, owed: owed.map((o) => ({ uid: o.uid, left: o.left, invoiceNo: o.invoice_no, reason: o.reason })),
          text: `${ctx.supplierName || 'This supplier'} owes ${fq(left)} ${l.name} from before (${owed.map((o) => `${o.invoice_no ? `invoice ${o.invoice_no}` : o.owed_date}: ${OW().OWED_REASON[o.reason].toLowerCase()}`).join('; ')}). Are some of these them?`,
          options: [
            { value: 'owed', label: `Yes – ${fq(Math.min(left, counted))} of these are the owed ones (already invoiced)` },
            { value: 'new', label: 'No – these are new goods' }] });
      }
    }
  }
  // on the invoice, but not in this delivery
  for (const [itemUid, inv] of byItem) {
    const f = onForm.get(itemUid);
    if (f && n(f.counted) > 0) continue;
    const it = I.getItem(itemUid);
    const qty = inv.reduce((t, x) => t + (Number(x.qty) || 0), 0);
    const cost = Number(inv[0].unitCost) || (it ? it.cost : 0);
    const name = it ? it.name : inv[0].description || 'Product';
    out.push({ id: `extra:${itemUid}`, kind: 'extra', itemUid, name, qty, cost, unit: it ? it.unit : '',
      text: `${name} × ${fq(qty)} (${$(cost)} each) is on the invoice${f ? '' : ', not on the order,'} but not in this delivery. What happened?`,
      options: [{ value: 'came', label: `It came – add ${fq(qty)} to this delivery` }]
        .concat((ctx.missing || []).filter((m) => m.itemUid !== itemUid).slice(0, 3).map((m) => ({ value: `instead:${m.itemUid}`, label: `It came instead of ${m.name} (ordered)` })))
        .concat([
          { value: 'owed', label: 'Not delivered – the supplier owes it' },
          { value: 'damaged', label: 'It came damaged – to replace or credit' },
          { value: 'wrong', label: 'Not ours – the invoice is wrong, claim it' }]) });
  }
  return out;
}
// The answers → what changes on the screen (set / add), the reason saved with the delivery, what the supplier now
// owes (owed), what came that was owed before (settle), and text claims.
export function receiverAnswers(questions = [], answers = {}) {
  const set = {}; const add = []; const owed = []; const settle = []; const notes = []; const claims = []; const open = [];
  for (const q of questions) {
    const a = answers[q.id];
    if (!a) { open.push(q); continue; }
    if (q.kind === 'qty') {
      if (a === 'recount') { open.push(q); continue; }
      if (a === 'invoice') { set[q.key] = { ...(set[q.key] || {}), counted: q.invoiced }; notes.push(`${q.name}: invoice qty ${fq(q.invoiced)} confirmed`); continue; }
      notes.push(`${q.name}: ${fq(q.counted)} came, invoice says ${fq(q.invoiced)}${a === 'damaged' ? ' (the rest damaged)' : ''}`);
      if (q.counted < q.invoiced) {
        const miss = q.invoiced - q.counted;
        owed.push({ itemUid: q.itemUid, name: q.name, qty: miss, unitCost: q.cost, reason: a === 'damaged' ? 'damaged' : 'short' });
        claims.push({ itemUid: q.itemUid, name: q.name, kind: a === 'damaged' ? 'damaged' : 'short', qty: miss, text: `${q.name}: ${fq(miss)} ${a === 'damaged' ? 'damaged' : 'short'}` });
      }
    } else if (q.kind === 'price') {
      if (a === 'accept') notes.push(`${q.name}: new price ${$(q.price)} accepted (was ${$(q.was)})`);
      else if (a === 'old') { set[q.key] = { ...(set[q.key] || {}), cost: q.was }; notes.push(`${q.name}: ${q.against} price ${$(q.was)} used (invoice ${$(q.price)})`); }
      else {
        notes.push(`${q.name}: invoiced ${$(q.price)}, should be ${$(q.was)} – claim`);
        if (q.qty > 0) owed.push({ itemUid: q.itemUid, name: q.name, qty: q.qty, unitCost: Math.round((q.price - q.was) * 10000) / 10000, reason: 'price' });
        claims.push({ itemUid: q.itemUid, name: q.name, kind: 'price', price: q.price, was: q.was, text: `${q.name}: charged ${$(q.price)} instead of ${$(q.was)}` });
      }
    } else if (q.kind === 'owed') {
      if (a === 'owed') {
        let left = q.counted;
        for (const o of q.owed) { if (left <= 0) break; const k = Math.min(left, o.left); settle.push({ owedUid: o.uid, qty: k }); left -= k; }
        notes.push(`${q.name}: ${fq(q.counted - Math.max(0, left))} were owed from before`);
      } else notes.push(`${q.name}: new goods (not the owed ones)`);
    } else if (q.kind === 'extra') {
      if (a === 'came' || a.startsWith('instead:')) {
        add.push({ itemUid: q.itemUid, name: q.name, unit: q.unit, qty: q.qty, cost: q.cost });
        if (a.startsWith('instead:')) { const it = I.getItem(a.slice(8)); notes.push(`${q.name} came instead of ${it ? it.name : 'the ordered product'}`); }
        else notes.push(`${q.name}: on the invoice, came`);
      } else if (a === 'wrong') {
        notes.push(`${q.name} × ${fq(q.qty)}: on the invoice but not ours – claim`);
        owed.push({ itemUid: q.itemUid, name: q.name, qty: q.qty, unitCost: q.cost, reason: 'other', note: 'On the invoice but not ordered or delivered – the invoice is wrong' });
        claims.push({ itemUid: q.itemUid, name: q.name, kind: 'wrong', text: `${q.name} × ${fq(q.qty)} invoiced, not ours` });
      } else {
        notes.push(`${q.name} × ${fq(q.qty)}: invoiced, ${a === 'damaged' ? 'came damaged' : 'not delivered'}`);
        owed.push({ itemUid: q.itemUid, name: q.name, qty: q.qty, unitCost: q.cost, reason: a === 'damaged' ? 'damaged' : 'not_delivered' });
        claims.push({ itemUid: q.itemUid, name: q.name, kind: a, text: `${q.name} × ${fq(q.qty)} ${a === 'damaged' ? 'damaged' : 'not delivered'}` });
      }
    }
  }
  return { set, add, owed, settle, open, reason: notes.length ? `Receiver checked: ${notes.join('; ')}` : '', claims };
}

// ---------------------------------------------------------------- the verifier: everything else
export function verifierQuestions(read, { receipt = null } = {}) {
  const out = [];
  if (!read) return out;
  const layout = read.supplierUid ? (() => { try { return IR().getLayout(read.supplierUid); } catch (e) { return null; } })() : null;
  if (!read.supplierUid) out.push({ id: 'supplier', kind: 'supplier', text: `The supplier on the invoice was not recognised${read.supplierName ? ` ("${read.supplierName}")` : ''}. Is it ${receipt ? receipt.supplier_name : 'the supplier of this delivery'}?`, options: [{ value: 'yes', label: 'Yes, that supplier' }, { value: 'no', label: 'No – it is wrong (problem)' }] });
  if (!txt(read.invoiceNo)) out.push({ id: 'invoice_no', kind: 'invoice_no', text: 'No invoice number could be read. Type it from the paper.', input: 'text' });
  if (!txt(read.invoiceDate)) out.push({ id: 'date', kind: 'date', text: 'No invoice date could be read. Type it from the paper (YYYY-MM-DD).', input: 'date' });
  if (read.total === null || read.total === undefined) out.push({ id: 'total', kind: 'total', text: 'The invoice total could not be read. Type it from the paper.', input: 'money' });
  else if (read.linesTotal !== undefined && Math.abs(read.linesTotal - read.total) > Math.max(1, read.total * 0.02)) out.push({ id: 'total', kind: 'total', text: `The lines add up to ${$(read.linesTotal)} but the invoice total reads ${$(read.total)}. What is the total on the paper?`, input: 'money', value: read.total });
  (read.lines || []).forEach((l, i) => {
    if (!l.itemUid) out.push({ id: `line:${i}`, kind: 'line', raw: l.raw, description: l.description, text: `Which product is "${txt(l.description || l.raw).slice(0, 60)}"${l.qty ? ` (${fq(l.qty)} × ${$(l.unitCost)})` : ''}?`, input: 'product' });
  });
  if (!layout || !layout.samples) out.push({ id: 'layout', kind: 'layout', text: `First invoice read from this supplier${read.supplierName ? ` (${read.supplierName})` : ''}: are the invoice number ${txt(read.invoiceNo) || '—'} and total ${read.total !== null && read.total !== undefined ? $(read.total) : '—'} right?`, options: [{ value: 'yes', label: 'Yes, both right' }, { value: 'no', label: 'No – I will correct them above' }] });
  return out;
}

// The reading kept for a delivery (the newest one), with its questions and answers.
function readFor(receiptUid) {
  try { return db().get('SELECT * FROM invoice_reads WHERE receipt_uid = ? ORDER BY created_at DESC LIMIT 1', [receiptUid]); } catch (e) { return null; }
}
export function linkRead(readUid, { receiptUid, invoiceUid } = {}) {
  if (!readUid) return;
  try { db().run("UPDATE invoice_reads SET receipt_uid = COALESCE(?, receipt_uid), invoice_uid = COALESCE(?, invoice_uid), updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [receiptUid || null, invoiceUid || null, stamp(), deviceId(), readUid]); } catch (e) { /* older database */ }
}
export function clarifications(receiptUid) {
  const r = readFor(receiptUid);
  if (!r) return { questions: [], open: 0, readUid: null };
  const res = J(r.result, {}) || {};
  let receipt = null;
  try { receipt = I.getReceipt(receiptUid); } catch (e) { receipt = null; }
  const answers = res.answers || {};
  const questions = verifierQuestions(res, { receipt }).map((q) => ({ ...q, answer: answers[q.id] || null }));
  return { questions, open: questions.filter((q) => !q.answer).length, readUid: r.uid, supplierUid: res.supplierUid || (receipt && receipt.supplier_uid) || null };
}
// A verifier's answer: kept with the reading, and taught to the app where it can learn from it.
export function answerClarification(user, receiptUid, qid, value) {
  need(user, 'Log in first.');
  const r = readFor(receiptUid);
  need(r, 'No invoice reading for this delivery.');
  const res = J(r.result, {}) || {};
  let receipt = null;
  try { receipt = I.getReceipt(receiptUid); } catch (e) { receipt = null; }
  const q = verifierQuestions(res, { receipt }).find((x) => x.id === qid);
  need(q, 'That question was already answered or is not there.');
  const v = txt(value);
  need(v, 'Choose or type the answer.');
  if (q.input === 'money') need(Number.isFinite(Number(v.replace(/[$,\s]/g, ''))) && Number(v.replace(/[$,\s]/g, '')) >= 0, 'Type the total as a number.');
  if (q.input === 'date') need(/^\d{4}-\d{2}-\d{2}$/.test(v), 'Type the date as YYYY-MM-DD.');
  if (q.input === 'product') need(I.getItem(v), 'Choose the product.');
  const answers = { ...(res.answers || {}), [qid]: { value: v, by: user.name, at: stamp() } };
  db().run("UPDATE invoice_reads SET result = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [JSON.stringify({ ...res, answers }), stamp(), deviceId(), r.uid]);
  // learn from it
  const sup = res.supplierUid || (receipt && receipt.supplier_uid);
  let learned = [];
  if (sup && ['invoice_no', 'total', 'line'].includes(q.kind)) {
    const corrected = {};
    if (q.kind === 'invoice_no') corrected.invoiceNo = v;
    if (q.kind === 'total') corrected.total = Number(v.replace(/[$,\s]/g, ''));
    if (q.kind === 'line') { const l = (res.lines || [])[Number(qid.split(':')[1])]; if (l) corrected.lines = [{ raw: l.raw, itemUid: v, qty: l.qty, unitCost: l.unitCost }]; }
    try { learned = IR().learnFromCorrection(user, sup, r.text, corrected).learned; } catch (e) { learned = []; }
  }
  if (sup && q.kind === 'layout' && v === 'yes') {
    try { learned = IR().learnFromCorrection(user, sup, r.text, { invoiceNo: res.invoiceNo, total: res.total }).learned; } catch (e) { learned = []; }
  }
  audit({ user, action: `Invoice question answered: ${q.text.slice(0, 80)} → ${q.input === 'product' ? (I.getItem(v) || {}).name : v}${learned.length ? ` (learnt: ${learned.join('; ')})` : ''}`, table: 'invoice_reads', recordUid: r.uid });
  return { ...clarifications(receiptUid), learned };
}

// ---------------------------------------------------------------- learning by itself after a delivery
// What the receiver kept (invoice number, total, the product of each line) against what was read: learn the differences.
export function autoLearn(user, readUid, { invoiceNo, total, lines = [] } = {}) {
  try {
    const r = db().get('SELECT * FROM invoice_reads WHERE uid = ?', [readUid]);
    if (!r) return [];
    const res = J(r.result, {}) || {};
    const sup = res.supplierUid;
    if (!sup) return [];
    const corrected = {};
    if (txt(invoiceNo) && txt(invoiceNo) !== txt(res.invoiceNo)) corrected.invoiceNo = txt(invoiceNo);
    if (n(total) !== null && (res.total === null || res.total === undefined || Math.abs(n(total) - res.total) > 0.004)) corrected.total = n(total);
    const fixed = [];
    for (const l of lines) {
      const read = (res.lines || []).find((x) => x.raw === l.raw);
      if (read && l.itemUid && read.itemUid !== l.itemUid) fixed.push({ raw: read.raw, itemUid: l.itemUid, qty: read.qty, unitCost: read.unitCost });
    }
    if (fixed.length) corrected.lines = fixed;
    if (!Object.keys(corrected).length) {
      // read right: one more invoice in this format (the layout is trusted a little more)
      return [];
    }
    return IR().learnFromCorrection(user, sup, r.text, corrected).learned;
  } catch (e) { return []; }
}
