// Reading supplier invoices: the text (read on the tablet, or by Google as a backup) → header figures, item lines,
// each line matched to our product, to the purchase order and to the delivery, and cost price changes flagged.
// Each supplier's layout is learned from the corrections people make (where the invoice number and total are,
// which numbers on an item line are the quantity and the price, and the supplier's own names for our products).
// Pure functions on text: the camera / text recognition lives in src/platform/invoiceReader.js.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from '../../services/core.js';
import { parseInvoiceText, ebAmountsIn } from '../payables/parser.js';
import { apRules, matchSupplier, listSuppliers, getSupplier } from '../payables/service.js';
import * as I from './service.js';
import { findByBarcode } from './scan.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const { r2, r4, q3 } = I;
const near = (a, b, tol = 0.05) => Math.abs(a - b) <= Math.max(tol, Math.abs(b) * 0.01);
export const normDesc = (s) => txt(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
const normLabel = (s) => txt(s).toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
const SKIP = /\b(sub\s*-?\s*total|total|vat|v\.a\.t|tin|invoice|inv\s*no|date|phone|tel|fax|balance|amount due|due date|page|account|bank|cheque|thank|terms)\b/i;
const NUM = /^\(?-?\$?\d{1,3}(?:,\d{3})*(?:\.\d+)?\)?$|^\(?-?\$?\d+(?:\.\d+)?\)?$/;
const numVal = (t) => Number(String(t).replace(/[$,()]/g, ''));

// ---------------------------------------------------------------- layouts
export function getLayout(supplierUid) {
  if (!supplierUid) return null;
  const r = db().get('SELECT * FROM supplier_layouts WHERE supplier_uid = ?', [supplierUid]);
  return r ? { ...J(r.layout, {}), samples: r.samples } : null;
}
function saveLayout(user, supplierUid, layout, samples) {
  const now = stamp();
  const dev = deviceId();
  db().run(`INSERT INTO supplier_layouts (uid, supplier_uid, layout, samples, updated_by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET layout = excluded.layout, samples = excluded.samples, updated_by_name = excluded.updated_by_name, updated_at = excluded.updated_at,
    updated_device = excluded.updated_device, sync_status = 'pending'`, [`SL-${supplierUid}`, supplierUid, JSON.stringify(layout), samples, user ? user.name : null, now, dev]);
}

// ---------------------------------------------------------------- item lines
// One invoice line → { raw, code, description, qty, unitCost, total, nums }. cols: learned positions (from the end of the line).
export function parseItemLine(raw, cols) {
  const line = txt(raw).replace(/\s+/g, ' ');
  if (!line || SKIP.test(line) || !/[a-z]{3,}/i.test(line)) return null;
  const toks = line.split(' ');
  // Numbers at the end of the line (quantity, unit price, line total…); a code at the start may be numeric too.
  const tail = [];
  for (let i = toks.length - 1; i >= 0 && NUM.test(toks[i]); i -= 1) tail.unshift(i);
  if (tail.length < 2) return null;
  const nums = tail.map((i) => numVal(toks[i]));
  if (!nums.some((n, k) => /\.\d{2}$/.test(toks[tail[k]]))) return null;
  let code = null;
  let descFrom = 0;
  if (/^[A-Z0-9][A-Z0-9-]{2,}$/i.test(toks[0]) && /\d/.test(toks[0]) && !/\.\d/.test(toks[0]) && tail[0] > 1) { code = toks[0]; descFrom = 1; }
  const description = toks.slice(descFrom, tail[0]).filter((t) => !/^(ea|each|pc|pcs|ctn|kg|bag|pkt|x)$/i.test(t)).join(' ');
  if (!/[a-z]{3,}/i.test(description)) return null;
  let qty = null; let unitCost = null; let total = null;
  if (cols && Number.isInteger(cols.qty) && Number.isInteger(cols.cost) && nums.length >= Math.max(cols.qty, cols.cost)) {
    qty = nums[nums.length - cols.qty];
    unitCost = nums[nums.length - cols.cost];
    total = cols.total ? nums[nums.length - cols.total] : r2(qty * unitCost);
  } else {
    total = nums[nums.length - 1];
    const before = nums.slice(0, -1);
    // Two numbers before the total that multiply to it: quantity × price.
    outer: for (let a = before.length - 1; a >= 0; a -= 1) {
      for (let b = before.length - 1; b >= 0; b -= 1) {
        if (a === b) continue;
        if (near(before[a] * before[b], total)) {
          const [x, y] = Number.isInteger(before[a]) && !Number.isInteger(before[b]) ? [a, b] : Number.isInteger(before[b]) && !Number.isInteger(before[a]) ? [b, a] : a < b ? [a, b] : [b, a];
          qty = before[x]; unitCost = before[y];
          break outer;
        }
      }
    }
    if (qty === null) {
      if (before.length === 1 && before[0] > 0) { qty = before[0]; unitCost = r4(total / before[0]); } else if (before.length >= 2) { qty = before[0]; unitCost = before[before.length - 1]; total = r2(qty * unitCost); } else return null;
    }
  }
  if (!(qty > 0) || !(unitCost >= 0)) return null;
  return { raw: line, code, description, qty: q3(qty), unitCost: r4(unitCost), total: r2(total), nums };
}
export function parseItemLines(text, layout) {
  return String(text || '').split(/\r?\n/).map((l) => parseItemLine(l, layout && layout.cols)).filter(Boolean);
}

// Our product for an invoice line: learned name for this supplier, then code / barcode, then the closest name.
export function matchItem(line, { supplierUid, layout } = {}) {
  const map = (layout && layout.itemMap) || {};
  const k = normDesc(line.description);
  if (map[k] && I.getItem(map[k])) return { item: I.getItem(map[k]), by: 'learned' };
  if (line.code && map[`#${line.code.toUpperCase()}`] && I.getItem(map[`#${line.code.toUpperCase()}`])) return { item: I.getItem(map[`#${line.code.toUpperCase()}`]), by: 'learned' };
  if (line.code) { const it = findByBarcode(line.code); if (it) return { item: it, by: 'code' }; }
  const words = new Set(k.split(' ').filter((w) => w.length >= 2));
  if (!words.size) return null;
  const pool = db().all('SELECT * FROM inv_items WHERE active = 1');
  let best = null;
  for (const it of pool) {
    const w2 = new Set(normDesc(it.name).split(' ').filter((w) => w.length >= 2));
    let hit = 0;
    words.forEach((w) => { if (w2.has(w)) hit += 1; });
    // The supplier's own products win a tie.
    const score = hit / Math.max(words.size, w2.size) + (supplierUid && it.supplier_uid === supplierUid ? 0.01 : 0);
    if (score > 0.5 && (!best || score > best.score)) best = { item: it, by: 'name', score };
  }
  return best;
}

// ---------------------------------------------------------------- learned labels
function findAfterLabel(lines, label, kind) {
  const L = normLabel(label);
  if (!L) return null;
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    const n = normLabel(lines[i]);
    if (n.indexOf(L) < 0) continue;
    const rest = lines[i].slice(Math.max(0, lines[i].toLowerCase().indexOf(label.toLowerCase().slice(0, 3)) + label.length));
    if (kind === 'amount') { const a = ebAmountsIn(lines[i]); const b = a.length ? a : ebAmountsIn(lines[i + 1] || ''); if (b.length) return b[b.length - 1]; }
    if (kind === 'code') { const m = /([A-Z0-9][A-Z0-9\-/]{1,24})/i.exec(rest.replace(/^[\s:#.\-]+/, '')) || /([A-Z0-9][A-Z0-9\-/]{1,24})/i.exec(lines[i + 1] || ''); if (m) return m[1].toUpperCase(); }
  }
  return null;
}
function labelBefore(lines, value) {
  const v = txt(value);
  if (!v) return null;
  for (let i = 0; i < lines.length; i += 1) {
    const at = lines[i].toUpperCase().indexOf(v.toUpperCase());
    if (at < 0) continue;
    const lab = lines[i].slice(0, at).replace(/[\s:#.\-$]+$/, '').trim();
    if (lab && /[a-z]/i.test(lab) && lab.length <= 30) return lab;
    if (!lab && i > 0 && lines[i - 1].length <= 30 && /[a-z]/i.test(lines[i - 1])) return lines[i - 1].replace(/[\s:#.\-]+$/, '');
  }
  return null;
}
const amountLabel = (lines, total) => {
  const f = Number(total).toFixed(2);
  const withComma = Number(total).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    const at = Math.max(lines[i].lastIndexOf(f), lines[i].lastIndexOf(withComma));
    if (at < 0) continue;
    const lab = lines[i].slice(0, at).replace(/[\s:$FJD]+$/i, '').trim();
    if (lab && /[a-z]/i.test(lab) && lab.length <= 30 && !/\d{2,}/.test(lab)) return lab;
  }
  return null;
};

// ---------------------------------------------------------------- reading
// text → header, item lines with our products, PO / delivery match and cost changes.
export function readInvoiceText(text, { supplierUid, poUid, receiptUid } = {}) {
  const rules = apRules();
  const vat = (Number(rules.vatRate) || 12.5) / 100;
  const base = parseInvoiceText(text || '', listSuppliers().map((s) => ({ name: s.name, tin: s.tin })), vat);
  const po = poUid ? I.getPO(poUid) : null;
  const receipt = receiptUid ? I.getReceipt(receiptUid) : null;
  const sup = getSupplier(supplierUid || (po && po.supplier_uid) || (receipt && receipt.supplier_uid)) || matchSupplier(base.supplier, base.supplier_tin);
  const layout = sup ? getLayout(sup.uid) : null;
  const lines = String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const head = { supplierUid: sup ? sup.uid : null, supplierName: sup ? sup.name : base.supplier, tin: base.supplier_tin, invoiceNo: base.invoice_no, invoiceDate: base.invoice_date,
    total: base.total, vat: base.vat, notes: base.notes.slice(), layoutUsed: false };
  if (layout && layout.labels) {
    const no = layout.labels.invoiceNo ? findAfterLabel(lines, layout.labels.invoiceNo, 'code') : null;
    const tot = layout.labels.total ? findAfterLabel(lines, layout.labels.total, 'amount') : null;
    if (no) { head.invoiceNo = no; head.layoutUsed = true; }
    if (tot !== null) { head.total = tot; head.layoutUsed = true; }
  }
  const items = parseItemLines(text, layout).map((l) => {
    const m = matchItem(l, { supplierUid: sup && sup.uid, layout });
    const it = m ? m.item : null;
    let unitCost = l.unitCost;
    if (layout && layout.pricesIncVat && it && it.vat_type === 'standard') unitCost = r4(unitCost / (1 + vat));
    return { ...l, unitCost, itemUid: it ? it.uid : null, itemName: it ? it.name : null, matchedBy: m ? m.by : null, flags: [] };
  });
  const out = { ...head, lines: items, missing: [], costChanges: [], flags: [] };
  matchToOrder(out, po);
  matchToDelivery(out, receipt);
  flagCostChanges(out);
  if (out.total !== null && items.length) {
    const sum = r2(items.reduce((s, l) => s + I.incVat(l.qty * l.unitCost, (I.getItem(l.itemUid) || {}).vat_type || 'standard'), 0));
    out.linesTotal = sum;
    if (Math.abs(sum - out.total) > Math.max(1, out.total * 0.02)) out.flags.push(`The item lines add up to ${I.$(sum)} but the invoice total is ${I.$(out.total)} – some lines may not have been read.`);
  }
  if (!items.length) out.flags.push('No item lines could be read. Type them, or teach the app this supplier\'s layout by correcting one invoice.');
  if (items.some((l) => !l.itemUid)) out.flags.push(`${items.filter((l) => !l.itemUid).length} line(s) not matched to a product – choose the product once and the app remembers it for this supplier.`);
  return out;
}

export function matchToOrder(res, po) {
  if (!po) return res;
  const rules = I.invRules();
  const used = new Set();
  for (const l of res.lines) {
    const pl = po.lines.find((x) => x.qty > 0 && !used.has(x.uid) && x.item_uid && x.item_uid === l.itemUid);
    if (!pl) { if (l.itemUid) { l.flags.push('not on the order'); res.flags.push(`${l.itemName || l.description}: not on order ${po.po_no}`); } continue; }
    used.add(pl.uid);
    l.lineUid = pl.uid;
    l.ordered = pl.qty;
    l.orderCost = pl.unit_cost;
    l.left = q3(pl.qty - pl.qty_received);
    if (pl.unit_cost > 0 && Math.abs(l.unitCost - pl.unit_cost) / pl.unit_cost * 100 > rules.priceTolerancePct + 1e-9) {
      l.flags.push('price differs from the order');
      res.flags.push(`${pl.name}: ordered at ${I.$(pl.unit_cost)}, invoiced at ${I.$(l.unitCost)}`);
    }
    if (l.qty > pl.qty + 1e-9) { l.flags.push('more than ordered'); res.flags.push(`${pl.name}: invoiced ${I.fmtQ(l.qty)}, ordered ${I.fmtQ(pl.qty)}`); }
  }
  res.missing = po.lines.filter((x) => x.qty > x.qty_received + 1e-9 && !used.has(x.uid)).map((x) => ({ lineUid: x.uid, name: x.name, left: q3(x.qty - x.qty_received) }));
  if (res.missing.length) res.flags.push(`On the order but not on the invoice: ${res.missing.map((m) => m.name).join(', ')}`);
  return res;
}
export function matchToDelivery(res, receipt) {
  if (!receipt) return res;
  for (const l of res.lines) {
    const rl = receipt.lines.find((x) => x.itemUid === l.itemUid);
    if (!rl) { if (l.itemUid) { l.flags.push('not delivered'); res.flags.push(`${l.itemName || l.description}: on the invoice but not on the delivery of ${receipt.receive_date}`); } continue; }
    l.delivered = rl.qty;
    if (Math.abs(rl.qty - l.qty) > 1e-9) { l.flags.push('quantity differs from the delivery'); res.flags.push(`${rl.name}: invoiced ${I.fmtQ(l.qty)}, delivered ${I.fmtQ(rl.qty)}`); }
  }
  return res;
}
export function flagCostChanges(res) {
  const rules = I.invRules();
  for (const l of res.lines) {
    const it = l.itemUid ? I.getItem(l.itemUid) : null;
    if (!it) continue;
    if (Math.abs(l.unitCost - it.cost) <= 0.00005) continue;
    const pct = it.cost > 0 ? r2(((l.unitCost - it.cost) / it.cost) * 100) : null;
    if (pct !== null && Math.abs(pct) <= rules.costFlagPct + 1e-9) continue;
    l.costChange = { oldCost: it.cost, newCost: l.unitCost, pct };
    res.costChanges.push({ itemUid: it.uid, name: it.name, oldCost: it.cost, newCost: l.unitCost, pct });
  }
  return res;
}

// ---------------------------------------------------------------- learning from corrections
// corrected: { invoiceNo, total, pricesIncVat?, lines: [{ raw, itemUid, qty, unitCost }] } – what the person fixed it to.
export function learnFromCorrection(user, supplierUid, text, corrected = {}) {
  const s = getSupplier(supplierUid);
  need(s, 'Choose the supplier first.');
  const lines = String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const old = getLayout(supplierUid) || {};
  const layout = { labels: { ...(old.labels || {}) }, itemMap: { ...(old.itemMap || {}) }, cols: old.cols || null, pricesIncVat: !!old.pricesIncVat, votes: { ...(old.votes || {}) } };
  const learned = [];
  if (txt(corrected.invoiceNo)) { const lab = labelBefore(lines, corrected.invoiceNo); if (lab) { layout.labels.invoiceNo = lab; learned.push(`invoice number after "${lab}"`); } }
  if (corrected.total !== undefined && corrected.total !== null && corrected.total !== '') { const lab = amountLabel(lines, Number(corrected.total)); if (lab) { layout.labels.total = lab; learned.push(`total after "${lab}"`); } }
  const vat = (Number(apRules().vatRate) || 12.5) / 100;
  for (const c of corrected.lines || []) {
    if (!c.itemUid || !txt(c.raw)) continue;
    const p = parseItemLine(c.raw, null) || { description: c.raw, nums: [], code: null };
    const key = normDesc(p.description);
    if (key) { layout.itemMap[key] = c.itemUid; learned.push(`"${p.description}" = ${(I.getItem(c.itemUid) || {}).name}`); }
    if (p.code) layout.itemMap[`#${p.code.toUpperCase()}`] = c.itemUid;
    // Which numbers on the line are the quantity and the price (counted from the end of the line).
    const nums = p.nums || [];
    const qi = nums.findIndex((n) => near(n, Number(c.qty), 0.0005));
    let ci = nums.findIndex((n, i) => i !== qi && near(n, Number(c.unitCost), 0.005));
    let inc = false;
    if (ci < 0) { ci = nums.findIndex((n, i) => i !== qi && near(n, Number(c.unitCost) * (1 + vat), 0.01)); inc = ci >= 0; }
    if (qi >= 0 && ci >= 0) {
      const sig = `${nums.length - qi}|${nums.length - ci}|${inc ? 1 : 0}`;
      layout.votes[sig] = (layout.votes[sig] || 0) + 1;
    }
  }
  const top = Object.entries(layout.votes).sort((a, b) => b[1] - a[1])[0];
  if (top) {
    const [q, c, inc] = top[0].split('|').map(Number);
    layout.cols = { qty: q, cost: c };
    layout.pricesIncVat = inc === 1;
    learned.push(`quantity is number ${q} and price number ${c} from the end of the line${inc ? ' (prices include VAT)' : ''}`);
  }
  if (corrected.pricesIncVat !== undefined) layout.pricesIncVat = !!corrected.pricesIncVat;
  need(learned.length, 'Nothing to learn – correct the invoice number, total or a line first.');
  saveLayout(user, supplierUid, layout, (old.samples || 0) + 1);
  audit({ user, action: `Learned ${s.name}'s invoice layout: ${learned.join('; ')}`, table: 'supplier_layouts', recordUid: `SL-${supplierUid}` });
  return { layout: getLayout(supplierUid), learned };
}
export function forgetLayout(user, supplierUid) {
  const s = getSupplier(supplierUid);
  need(s && getLayout(supplierUid), 'Nothing learned for this supplier yet.');
  saveLayout(user, supplierUid, {}, 0);
  audit({ user, action: `Forgot what was learned about ${s.name}'s invoices`, table: 'supplier_layouts', recordUid: `SL-${supplierUid}` });
}

// Keep a reading (the text and what was found) so it can be checked and learned from later.
export function saveRead(user, { invoiceUid, supplierUid, poUid, receiptUid, engine, text, result }) {
  const uid = uuid('IR');
  // 1.0.0 how each line is taxed (zero rated, exempt, 12.5%) – kept to cross-check the products in the app and Aronium
  try { require('./productChecks.js').recordVatEvidence(result); } catch (e) { /* a check only */ }
  const now = stamp();
  db().run(`INSERT INTO invoice_reads (uid, invoice_uid, supplier_uid, po_uid, receipt_uid, engine, text, result, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, invoiceUid || null, supplierUid || null, poUid || null, receiptUid || null, engine || null, txt(text).slice(0, 20000), JSON.stringify(result || null), user ? user.name : null, now, now, deviceId()]);
  return uid;
}
export function listReads({ invoiceUid, supplierUid, limit = 20 } = {}) {
  return db().all('SELECT * FROM invoice_reads WHERE (? IS NULL OR invoice_uid = ?) AND (? IS NULL OR supplier_uid = ?) ORDER BY created_at DESC LIMIT ?',
    [invoiceUid || null, invoiceUid || null, supplierUid || null, supplierUid || null, limit]).map((r) => ({ ...r, result: J(r.result, null) }));
}
