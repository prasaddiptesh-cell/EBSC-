// 1.0.0 build 10 (review, 3 Nov): the same product made under two record ids on two devices.
// Products from the till PCs get a record id from their code (IT-<code>), so two devices bringing in the same list make
// the same records. Only a product first matched by its NAME to one added by hand keeps the hand-made id – a device
// that did not have that hand-made product made IT-<code> instead. The code is unique on every device, so the second
// one used to fail on every other device ("synced record could not be saved", UNIQUE constraint failed: inv_items.code).
// Now a product that arrives with a code already used here by another record is MERGED, the same way on every device:
// - the record kept is IT-<code> if one of the two is that, otherwise the smaller id;
// - the other one is retired (its code gets "~<its id>" added, it is switched off, its note says "merged into <id>"),
//   and that goes to the cloud, so every device ends up with the same picture;
// - its stock moves, shop settings, cost changes, counts and order lines on this device now point to the one kept, and
//   any that arrive later for it are pointed there too (the merged ids are remembered in the setting item_alias).
import { db } from '../../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, deviceId } from '../../services/core.js';

export const ITEM_REF_TABLES = ['inv_item_shops', 'inv_moves', 'inv_cost_changes', 'inv_count_lines', 'po_lines'];
const up = (v) => String(v === null || v === undefined ? '' : v).trim().toUpperCase();
export function keptOf(code, a, b) {
  const want = `IT-${up(code)}`;
  if (a === want) return a;
  if (b === want) return b;
  return String(a) < String(b) ? a : b;
}
function aliases() { try { return JSON.parse(getSetting('item_alias', '') || '{}') || {}; } catch (e) { return {}; } }
export function itemAlias(uid) { const m = aliases(); let u = uid; for (let i = 0; i < 5 && m[u]; i++) u = m[u]; return u === uid ? null : u; }
function addAlias(from, to) {
  if (!from || !to || from === to) return;
  const m = aliases();
  if (m[from] === to) return;
  m[from] = to;
  const keys = Object.keys(m);
  if (keys.length > 500) keys.slice(0, keys.length - 500).forEach((k) => { delete m[k]; });
  setSetting('item_alias', JSON.stringify(m));
}
const hasTable = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

// The duplicate here is retired and what pointed to it points to the one kept (this device only; nothing re-sent).
function retire(dup, into) {
  const now = stamp();
  db().run(`UPDATE inv_items SET code = substr(code, 1, 40) || '~' || uid, active = 0, removed_at = COALESCE(removed_at, ?), notes = ?,
    updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [dateStr(), `merged into ${into}`, now, deviceId(), dup]);
  for (const t of ITEM_REF_TABLES) {
    if (!hasTable(t)) continue;
    if (t === 'inv_item_shops') {
      for (const s of db().all('SELECT uid, shop_code FROM inv_item_shops WHERE item_uid = ?', [dup])) {
        if (!db().get('SELECT 1 AS x FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [into, s.shop_code])) db().run('UPDATE inv_item_shops SET item_uid = ? WHERE uid = ?', [into, s.uid]);
      }
    } else db().run(`UPDATE ${t} SET item_uid = ? WHERE item_uid = ?`, [into, dup]);
  }
  addAlias(dup, into);
}

// Called for each record pulled from the cloud before it is saved. Returns false when the record is not to be saved
// (it is a duplicate merged into a product here). May change row (item_uid → the product kept).
export function beforePulled(table, row) {
  if (!row) return true;
  if (table === 'inv_items') {
    const m = /^merged into (\S+)/.exec(String(row.notes || ''));
    if (m && m[1] !== row.uid) addAlias(row.uid, m[1]);
    const code = up(row.code);
    if (!code) return true;
    const other = db().get('SELECT uid, code FROM inv_items WHERE upper(code) = ? AND uid <> ?', [code, row.uid]);
    if (!other) return true;
    const kept = keptOf(code, other.uid, row.uid);
    if (kept === other.uid) {
      // the incoming one is the duplicate: if this device has it too, it is retired here as well
      if (db().get('SELECT 1 AS x FROM inv_items WHERE uid = ?', [row.uid])) retire(row.uid, other.uid);
      else addAlias(row.uid, other.uid);
      return false;
    }
    retire(other.uid, row.uid);
    return true;
  }
  if (ITEM_REF_TABLES.includes(table) && row.item_uid) {
    const to = itemAlias(row.item_uid);
    if (to) {
      row.item_uid = to;
      // one shop setting per product and shop: the one already here stays
      if (table === 'inv_item_shops' && db().get('SELECT 1 AS x FROM inv_item_shops WHERE item_uid = ? AND shop_code = ? AND uid <> ?', [to, row.shop_code, row.uid])) return false;
    }
  }
  return true;
}
