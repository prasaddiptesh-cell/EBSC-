// 1.0.0 Products sold both as a pack and loose (Maggi 5 pack, and one Maggi on its own). In Aronium they are two
// products; in the app ONE of them holds the stock (usually the pack – that is what comes from the supplier):
//   • a sale of the loose one takes its share off the pack's stock (3 loose Maggi = 0.6 of a 5 pack);
//   • the loose one is never counted on its own and never warned about as low / negative;
//   • at the stock take the pack's line has a "loose" box: 2 packs + 3 loose = 2.6.
// Kept in a shared setting (synced): { childUid: { parent, per } } – per = how many loose make one pack.
import { db } from '../../db/connection.js';
import { getShared, setShared, audit, AppError } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const q4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
const KEY = 'loose_links';
function map() { const m = getShared(KEY, null); return m && typeof m === 'object' ? m : {}; }
const item = (uid) => { try { return db().get('SELECT uid, code, name, group_name FROM inv_items WHERE uid = ?', [uid]); } catch (e) { return null; } };

// The loose product's link: { parent, per, factor } (factor = pack per loose one, e.g. 0.2), or null.
export function looseOf(itemUid) {
  const l = map()[itemUid];
  return l && l.parent && Number(l.per) > 0 ? { parent: l.parent, per: Number(l.per), factor: q4(1 / Number(l.per)) } : null;
}
// The loose products of a pack: [{ uid, name, per }].
export function looseFor(parentUid) {
  return Object.entries(map()).filter(([, l]) => l && l.parent === parentUid).map(([uid, l]) => ({ uid, name: (item(uid) || {}).name || uid, per: Number(l.per) }));
}
export function linkLoose(user, looseUid, parentUid, per) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner links products.');
  const a = item(looseUid); const b = item(parentUid);
  need(a && b, 'Choose both products.');
  need(a.uid !== b.uid, 'Choose two different products.');
  need(!looseOf(parentUid), `${b.name} is itself sold loose from another product – link to that one.`);
  need(!looseFor(looseUid).length, `${a.name} already has loose products of its own.`);
  const n = Number(String(per).replace(/[,\s]/g, ''));
  need(Number.isFinite(n) && n >= 2 && n <= 1000 && Math.round(n) === n, 'How many loose ones make one pack? (a whole number, 2 or more)');
  setShared(KEY, { ...map(), [a.uid]: { parent: b.uid, per: n } });
  audit({ user, action: `${a.name} is sold loose from ${b.name} (${n} in one) – its sales come off ${b.name}'s stock`, table: 'inv_items', recordUid: a.uid });
  return looseOf(a.uid);
  });
}
export function unlinkLoose(user, looseUid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner links products.');
  const m = map(); const was = m[looseUid];
  delete m[looseUid];
  setShared(KEY, m);
  if (was) audit({ user, action: 'Loose link removed – its sales come off its own stock again', table: 'inv_items', recordUid: looseUid });
  });
}
export function allLoose() {
  return Object.entries(map()).map(([uid, l]) => ({ loose: item(uid), pack: item(l.parent), per: Number(l.per) })).filter((x) => x.loose && x.pack);
}
