// v3.9.8 FCCC LPG (gas) prices. The FCCC publishes a "Final Authorisation of Prices for the Supply of LPG Products"
// every month (fccc.gov.fj/master-price-list/gas/ › Price Authorizations), effective the 1st. Schedule 1 is Viti Levu
// and Vanua Levu (our zone): maximum wholesale and retail price per kg, 4.5 / 12 / 40 / 50 kg cylinder, bulk, autogas.
// Cooking gas cylinders are zero-rated (no VAT) since 1 August 2025; bulk and autogas carry 12.5% VAT.
// The app reads the newest authorisation, the gas products we sell are linked once to their line, and anything priced
// above the maximum (or a cylinder not zero-rated in Aronium) is a warning – change it in Aronium.
import { db } from '../../db/connection.js';
import { AppError, stamp, audit, getShared, setShared, getSetting, setSetting, dateStr } from '../../services/core.js';
import { can, actsAsOwner } from '../../services/access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const GAS_PAGE = 'https://fccc.gov.fj/master-price-list/gas/';
export const LPG_LINES = { kg: 'Per kg (refill by weight)', c4_5: '4.5 kg cylinder', c12: '12 kg cylinder', c40: '40 kg cylinder', c50: '50 kg cylinder', auto: 'Autogas (per litre)' };
const KG_OF = { c4_5: 4.5, c12: 12, c40: 40, c50: 50 };

// The page → the authorisations listed, newest first: [{ url, effective: 'YYYY-MM-DD' }]
export function parseGasPage(html, base = GAS_PAGE) {
  const out = [];
  const re = /<a[^>]+href="([^"]+\.pdf)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    const label = m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    const d = /LPG Authori[sz]ation\s*\(Effective\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\)/i.exec(label);
    if (!d) continue;
    let url = m[1];
    if (!/^https?:/i.test(url)) url = new URL(url, base).href;
    out.push({ url, effective: `${d[3]}-${String(Number(d[2])).padStart(2, '0')}-${String(Number(d[1])).padStart(2, '0')}` });
  }
  return out.sort((a, b) => (a.effective < b.effective ? 1 : -1));
}
// The PDF's text lines → Schedule 1 prices { kg: { w, r }, c4_5: {…}, …, auto: {…} } (digits split by the PDF are joined).
export function parseLpgText(lines) {
  const all = (Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/)).map((l) => String(l).replace(/\s+/g, ' ').trim());
  const start = all.findIndex((l) => /^Schedule\s*1\b/i.test(l));
  const end = all.findIndex((l, i) => i > start && /^Schedule\s*2\b/i.test(l));
  const part = all.slice(start >= 0 ? start : 0, end > start ? end : all.length);
  const money = (s) => (String(s).replace(/\$\s*/g, '$').replace(/(\d)\s+(?=[\d.])/g, '$1').replace(/\.\s+(?=\d)/g, '.').match(/\$\d+(?:\.\d{1,2})?/g) || []).map((x) => r2(x.slice(1)));
  const out = {};
  const put = (key, vals) => { if (!out[key] && vals.length) out[key] = { w: vals[0], r: vals.length > 1 ? vals[1] : null }; };
  let pending = null;
  for (let i = 0; i < part.length; i += 1) {
    const l = part[i];
    let key = null;
    if (/^Per\s*KG\b/i.test(l)) key = out.kg ? 'bulk' : 'kg';
    else if (/4\s*\.\s*5\s*KG\s*Cylinder/i.test(l)) key = 'c4_5';
    else if (/\b12\s*KG\s*Cylinder/i.test(l)) key = 'c12';
    else if (/\b40\s*KG\s*Cylinder/i.test(l)) key = 'c40';
    else if (/\b50\s*KG\s*Cylinder/i.test(l)) key = 'c50';
    else if (/^Per\s*Litre/i.test(l)) key = 'auto';
    const vals = money(l);
    if (key) {
      if (vals.length >= 2 || (key === 'bulk' && vals.length)) { put(key, vals); pending = null; } else pending = key;
    } else if (pending && vals.length) { put(pending, vals); pending = null; }
  }
  delete out.bulk;
  return out;
}

// ---------------------------------------------------------------- the newest authorisation
export function lpgPrices() { return getShared('lpg_prices', null); }
export function lpgHistory() { return getShared('lpg_history', []) || []; }
// Sensible LPG retail prices: about $2–$8 a kg (any cylinder), and within 40 % of last month's.
const LPG_KG = { c4_5: 4.5, c12: 12, c40: 40, c50: 50 };
export function lpgOdd(prices, cur) {
  for (const [k, kg] of Object.entries(LPG_KG)) {
    const v = prices && prices[k] && Number(prices[k].r);
    if (!v) continue;
    if (v / kg < 2 || v / kg > 8) return `${k.replace('c', '').replace('_', '.')} kg $${v}`;
    const old = cur && cur.prices && cur.prices[k] && Number(cur.prices[k].r);
    if (old && Math.abs(v - old) / old > 0.4) return `${k.replace('c', '').replace('_', '.')} kg $${old} → $${v}`;
  }
  return null;
}
function keepPrices(p) {
  const cur = lpgPrices();
  if (cur && cur.effective === p.effective && JSON.stringify(cur.prices) === JSON.stringify(p.prices)) return false;
  setShared('lpg_prices', p);
  const h = lpgHistory().filter((x) => x.effective !== p.effective).concat([{ effective: p.effective, prices: p.prices }]).sort((a, b) => (a.effective < b.effective ? -1 : 1)).slice(-36);
  setShared('lpg_history', h);
  return true;
}
// Look at the gas page (a few times a day on each device; cheap). fetchText(url) → html, fetchBytes(url) → Uint8Array.
export async function checkLpg({ fetchText, fetchBytes, force = false } = {}) {
  const last = Number(getSetting('lpg_last_look', 0)) || 0;
  if (!force && Date.now() - last < 6 * 3600000) return { skipped: 'not due' };
  const getText = fetchText || (async (u) => { const r = await fetch(u, { headers: { Accept: 'text/html' } }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); });
  const getBytes = fetchBytes || (async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}`); return new Uint8Array(await r.arrayBuffer()); });
  try {
    const list = parseGasPage(await getText(GAS_PAGE));
    setSetting('lpg_last_look', Date.now());
    if (!list.length) return { found: 0 };
    const newest = list[0];
    const cur = lpgPrices();
    if (cur && cur.effective === newest.effective && !force) return { found: list.length, same: true };
    const { pdfTextItems, pdfLines } = require('../../services/pdfText.js');
    const lines = pdfLines(await pdfTextItems(await getBytes(newest.url))).flatMap((p) => (p.lines || p).map((l) => (typeof l === 'string' ? l : l.text || '')));
    const prices = parseLpgText(lines);
    if (!prices.c12 && !prices.c4_5) { setSetting('lpg_problem', `Could not read the prices in the ${newest.effective} authorisation – open it and check by hand.`); return { found: list.length, read: false }; }
    // v3.9.8 a misread PDF must never become the FCCC maximum: prices outside a sensible range, or more than 40 %
    // away from last month's, wait for a person to check them.
    const odd = lpgOdd(prices, cur);
    if (odd) { setSetting('lpg_problem', `The ${newest.effective} gas prices look wrong (${odd}) – open the authorisation and type them by hand.`); return { found: list.length, read: false, odd }; }
    setSetting('lpg_problem', '');
    const changed = keepPrices({ effective: newest.effective, url: newest.url, prices, readAt: stamp() });
    return { found: list.length, read: true, changed, effective: newest.effective, prices };
  } catch (e) {
    setSetting('lpg_problem', `Could not look at the FCCC gas page: ${String(e && e.message || e).slice(0, 120)}`);
    return { error: String(e && e.message || e) };
  }
}
// Typed by hand (if the PDF cannot be read): { effective, prices: { c12: { w, r }, … } }.
export function saveLpgPrices(user, { effective, prices }) {
  need(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage'), 'You cannot change the gas prices.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(txt(effective)), 'Enter the date the prices start.');
  const clean = {};
  for (const k of Object.keys(LPG_LINES)) { const v = prices && prices[k]; if (v && Number(v.r) > 0) clean[k] = { w: Number(v.w) > 0 ? r2(v.w) : null, r: r2(v.r) }; }
  need(Object.keys(clean).length, 'Enter at least one retail price.');
  keepPrices({ effective: txt(effective), url: null, prices: clean, readAt: stamp(), by: user.name });
  audit({ user, action: `LPG prices from ${effective} typed by hand`, table: 'shared_settings' });
}

// ---------------------------------------------------------------- our gas products
export function lpgLinks() { return getShared('lpg_links', {}) || {}; }
export function linkGasProduct(user, itemUid, line) {
  need(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage'), 'You cannot change products.');
  need(!line || LPG_LINES[line], 'Choose the FCCC gas line.');
  const m = { ...lpgLinks() };
  if (line) m[itemUid] = line; else delete m[itemUid];
  setShared('lpg_links', m);
  const it = db().get('SELECT name FROM inv_items WHERE uid = ?', [itemUid]) || {};
  audit({ user, action: line ? `${it.name}: FCCC gas price – ${LPG_LINES[line]}` : `${it.name}: not an FCCC gas product`, table: 'inv_items', recordUid: itemUid });
}
// Products that look like gas, with the line they look like (for the Yes / No round).
export function gasCandidates() {
  const links = lpgLinks();
  const rejected = getShared('lpg_not_gas', {}) || {};
  return db().all("SELECT uid, code, name, price FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (lower(name) LIKE '%gas%' OR lower(name) LIKE '%lpg%' OR lower(name) LIKE '%cylinder%')")
    .filter((x) => !links[x.uid] && !rejected[x.uid])
    .map((x) => {
      const n = x.name.toLowerCase();
      const m = /(\d+(?:\.\d+)?)\s*kg/.exec(n);
      const kg = m ? Number(m[1]) : null;
      const line = kg === 4.5 ? 'c4_5' : kg === 12 ? 'c12' : kg === 40 ? 'c40' : kg === 50 ? 'c50' : /auto/.test(n) ? 'auto' : null;
      return { ...x, line };
    });
}
export function notGas(user, itemUid) {
  const m = { ...(getShared('lpg_not_gas', {}) || {}) };
  m[itemUid] = user.name;
  setShared('lpg_not_gas', m);
}
// The maximum retail price for a line (a size not listed: in proportion to the per-kg price).
export function maxFor(line, prices = (lpgPrices() || {}).prices || {}) {
  if (prices[line] && prices[line].r) return prices[line].r;
  if (KG_OF[line] && prices.kg && prices.kg.r) return r2(prices.kg.r * KG_OF[line]);
  return null;
}
// Our linked gas products at each shop against the maximum, and their VAT in Aronium.
export function gasCheck() {
  const links = lpgLinks();
  const p = lpgPrices();
  const out = [];
  for (const [itemUid, line] of Object.entries(links)) {
    const it = db().get('SELECT uid, code, name, price, aronium_vat FROM inv_items WHERE uid = ?', [itemUid]);
    if (!it) continue;
    const max = p ? maxFor(line, p.prices) : null;
    let shops = [];
    try { shops = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1', [itemUid]).map((x) => ({ shop: x.shop_code, price: x.price === null || x.price === undefined ? Number(it.price) || 0 : Number(x.price) })); } catch (e) { shops = []; }
    if (!shops.length) shops = [{ shop: 'All', price: Number(it.price) || 0 }];
    const over = max ? shops.filter((s) => s.price > max + 0.004) : [];
    const vatWrong = line !== 'auto' && it.aronium_vat && it.aronium_vat !== 'zero' && it.aronium_vat !== 'exempt';
    out.push({ ...it, line, max, shops, over, vatWrong });
  }
  return out;
}
export function lpgAlerts(user, today = dateStr()) {
  if (!user || !(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage') || can(user, 'inventory_view'))) return [];
  const out = [];
  const p = lpgPrices();
  const h = lpgHistory();
  if (p && h.length > 1 && p.effective >= today.slice(0, 8) + '01' && (today <= p.effective || today.slice(0, 7) === p.effective.slice(0, 7))) {
    const prev = h[h.length - 2];
    const changes = Object.keys(LPG_LINES).filter((k) => p.prices[k] && prev.prices[k] && p.prices[k].r !== prev.prices[k].r);
    if (changes.length) out.push({ id: `lpg-new-${p.effective}`, level: 'warning', text: `New LPG prices from ${p.effective} – change them in Aronium`, sub: changes.map((k) => `${LPG_LINES[k]} $${prev.prices[k].r.toFixed(2)} → $${p.prices[k].r.toFixed(2)}`).join(' · '), nav: { screen: 'Lpg', params: {} } });
  }
  let chk = [];
  try { chk = gasCheck(); } catch (e) { chk = []; }
  const over = chk.filter((x) => x.over.length);
  if (over.length) out.push({ id: `lpg-over-${over.length}-${p ? p.effective : ''}`, level: 'urgent', text: `${over.length} gas product${over.length === 1 ? ' is' : 's are'} priced above the FCCC maximum`, sub: over.map((x) => `${x.name}: ${x.over.map((s) => `${s.shop} $${s.price.toFixed(2)}`).join(', ')} – max $${x.max.toFixed(2)}`).join(' · '), nav: { screen: 'Lpg', params: {} } });
  const vat = chk.filter((x) => x.vatWrong);
  if (vat.length) out.push({ id: `lpg-vat-${vat.length}`, level: 'warning', text: `${vat.length} gas cylinder${vat.length === 1 ? ' has' : 's have'} VAT set in Aronium – cooking gas cylinders are zero-rated`, sub: vat.map((x) => x.name).join(', '), nav: { screen: 'Lpg', params: {} } });
  const cand = (() => { try { return gasCandidates(); } catch (e) { return []; } })();
  if (cand.length) out.push({ id: `lpg-cand-${cand.length}`, level: 'info', text: `${cand.length} product${cand.length === 1 ? ' looks' : 's look'} like gas – confirm the FCCC gas line`, nav: { screen: 'Lpg', params: {} } });
  const prob = getSetting('lpg_problem', '');
  if (prob) out.push({ id: `lpg-prob-${today}`, level: 'info', text: 'FCCC gas prices', sub: prob, nav: { screen: 'Lpg', params: {} } });
  return out;
}

// ---------------------------------------------------------------- v3.9.8 petrol and diesel (FCCC Petroleum Prices Order)
// fccc.gov.fj/master-price-list/petroleum/ lists "Petroleum Prices (No. N) Order YYYY" (monthly, from the 1st).
// Schedule 1 = Viti Levu within 3 km of a public road: motor spirit (unleaded), gasoil (diesel), kerosene, premix –
// retail per litre (VIP, VAT included). Used to check our vehicles' fuel receipts.
export const FUEL_PAGE = 'https://fccc.gov.fj/master-price-list/petroleum/';
export const FUEL_LABEL = { petrol: 'Petrol (motor spirit, unleaded)', diesel: 'Diesel (gasoil)', kerosene: 'Kerosene', premix: 'Premix' };
const MONTH_NO = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
export function parsePetroleumPage(html, base = FUEL_PAGE) {
  const out = [];
  const re = /<a[^>]+href="([^"]+\.pdf)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    const label = m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    const d = /Petroleum Prices\s*\(No\.?\s*(\d+)\)\s*Order\s*(\d{4})/i.exec(label);
    if (!d) continue;
    let url = m[1];
    if (!/^https?:/i.test(url)) url = new URL(url, base).href;
    out.push({ url, no: Number(d[1]), year: Number(d[2]) });
  }
  return out.sort((a, b) => (b.year - a.year) || (b.no - a.no));
}
export function parsePetroleumText(lines) {
  const all = (Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/)).map((l) => String(l).replace(/\s+/g, ' ').trim());
  const text = all.join('\n');
  const eff = /comes into force on\s*(\d{1,2})\s*([A-Za-z]+)\s*(\d{4})/i.exec(text);
  const effective = eff && MONTH_NO[eff[2].toLowerCase()] ? `${eff[3]}-${String(MONTH_NO[eff[2].toLowerCase()]).padStart(2, '0')}-${String(Number(eff[1])).padStart(2, '0')}` : null;
  const start = all.findIndex((l) => /^SCHEDULE\s*1\b/.test(l));
  const end = all.findIndex((l, i) => i > start && /^SCHEDULE\s*2\b/.test(l));
  const part = all.slice(start >= 0 ? start : 0, end > start ? end : all.length);
  const out = {};
  const price = (l) => { const m2 = /\$\s*(\d+(?:\.\d{1,2})?)\s*\(?VIP/i.exec(l.replace(/(\d)\s+(?=[\d.])/g, '$1')); return m2 ? r2(m2[1]) : null; };
  for (const l of part) {
    let k = null;
    if (/motor spirit|unleaded/i.test(l)) k = 'petrol';
    else if (/gasoil|diesel/i.test(l)) k = 'diesel';
    else if (/kerosene/i.test(l)) k = 'kerosene';
    else if (/premix/i.test(l)) k = 'premix';
    if (k && !out[k]) { const v = price(l); if (v) out[k] = v; }
  }
  return { effective, prices: out };
}
export function fuelPrices() { return getShared('fuel_prices', null); }
export async function checkFuel({ fetchText, fetchBytes, force = false } = {}) {
  const last = Number(getSetting('fuel_last_look', 0)) || 0;
  if (!force && Date.now() - last < 12 * 3600000) return { skipped: 'not due' };
  const getText = fetchText || (async (u) => { const r = await fetch(u, { headers: { Accept: 'text/html' } }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); });
  const getBytes = fetchBytes || (async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}`); return new Uint8Array(await r.arrayBuffer()); });
  try {
    const list = parsePetroleumPage(await getText(FUEL_PAGE));
    setSetting('fuel_last_look', Date.now());
    if (!list.length) return { found: 0 };
    const n = list[0];
    const cur = fuelPrices();
    if (cur && cur.url === n.url && !force) return { same: true };
    const { pdfTextItems, pdfLines } = require('../../services/pdfText.js');
    const lines = pdfLines(await pdfTextItems(await getBytes(n.url))).flatMap((p) => (p.lines || p).map((l) => (typeof l === 'string' ? l : l.text || '')));
    const r = parsePetroleumText(lines);
    if (!r.prices.petrol && !r.prices.diesel) return { read: false };
    // a misread number (e.g. 31.5 for 3.15) is never kept: petrol / diesel between $1 and $8 a litre, within 40 % of before
    for (const k of ['petrol', 'diesel']) {
      const v = Number(r.prices[k]); const o = cur && cur.prices ? Number(cur.prices[k]) : 0;
      if (v && (v < 1 || v > 8 || (o && Math.abs(v - o) / o > 0.4))) { setSetting('fuel_problem', `The fuel prices look wrong (${k} $${v}) – check them by hand.`); return { read: false, odd: k }; }
    }
    setSetting('fuel_problem', '');
    setShared('fuel_prices', { ...r, url: n.url, order: `No. ${n.no} of ${n.year}`, readAt: stamp() });
    return { read: true, ...r };
  } catch (e) { return { error: String(e && e.message || e) }; }
}
