// v3.9.8 FCCC LPG (gas) prices. The FCCC publishes a "Final Authorisation of Prices for the Supply of LPG Products"
// every month (fccc.gov.fj/master-price-list/gas/ › Price Authorizations), effective the 1st. Schedule 1 is Viti Levu
// and Vanua Levu (our zone): maximum wholesale and retail price per kg, 4.5 / 12 / 40 / 50 kg cylinder, bulk, autogas.
// Cooking gas cylinders are zero-rated (no VAT) since 1 August 2025; bulk and autogas carry 12.5% VAT.
// The app reads the newest authorisation, the gas products we sell are linked once to their line, and anything priced
// above the maximum (or a cylinder not zero-rated in Aronium) is a warning – change it in Aronium.
import { db } from '../../db/connection.js';
import { AppError, stamp, audit, getShared, setShared, getSetting, setSetting, dateStr } from '../../services/core.js';
import { can, actsAsOwner } from '../../services/access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const GAS_PAGE = 'https://fccc.gov.fj/master-price-list/gas/';
export const LPG_LINES = { kg: 'Per kg (refill by weight)', c4_5: '4.5 kg cylinder', c12: '12 kg cylinder', c40: '40 kg cylinder', c50: '50 kg cylinder', auto: 'Autogas (per litre)' };
const KG_OF = { c4_5: 4.5, c12: 12, c40: 40, c50: 50 };

// A link on the FCCC page → a full web address (relative links, &amp; in the address). No URL() – it is limited on phones.
export function fullUrl(href, base = GAS_PAGE) {
  const u = String(href || '').replace(/&amp;/g, '&').trim();
  if (/^https?:\/\//i.test(u)) return u;
  const origin = (/^(https?:\/\/[^/]+)/i.exec(base) || [])[1] || 'https://fccc.gov.fj';
  if (u.startsWith('//')) return `https:${u}`;
  if (u.startsWith('/')) return origin + u;
  return base.replace(/[^/]*$/, '') + u;
}
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const iso3 = (y, m, d) => `${y}-${String(Number(m)).padStart(2, '0')}-${String(Number(d)).padStart(2, '0')}`;
// The page → the authorisations listed, newest first: [{ url, effective: 'YYYY-MM-DD' }]
// The link reads "PDF LPG Authorization (Effective 01/11/2026) November 2026"; when the words change, the date in the
// PDF's name ("…_Effective-1-November-2026.pdf") is used.
export function parseGasPage(html, base = GAS_PAGE) {
  const out = [];
  const re = /<a\b[^>]*?href\s*=\s*["']([^"']+?\.pdf(?:[?#][^"']*)?)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    const label = m[2].replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ');
    const url = fullUrl(m[1], base);
    if (!/LPG/i.test(label) && !/LPG/i.test(url)) continue;
    let effective = null;
    const d = /Authori[sz]ation\s*\(?\s*Effective\s*:?\s*(\d{1,2})\/(\d{1,2})\/(\d{4})/i.exec(label);
    if (d) effective = iso3(d[3], d[2], d[1]);
    else if (/Authori[sz]ation/i.test(label + url)) {
      let file = url.split('/').pop() || '';
      try { file = decodeURIComponent(file); } catch (e) { /* as it is */ }
      const f = /Effective[-_ ]+(\d{1,2})[-_ ]+([A-Za-z]{3,9})[-_ ]+(\d{2,4})/i.exec(file);
      const mo = f && MONTHS[f[2].slice(0, 3).toLowerCase()];
      if (mo) effective = iso3(f[3].length === 2 ? `20${f[3]}` : f[3], mo, f[1]);
    }
    if (!effective || out.some((x) => x.url === url)) continue;
    out.push({ url, effective });
  }
  return out.sort((a, b) => (a.effective < b.effective ? 1 : -1));
}
// The PDF's pages (services/pdfText.js pdfLines: per page [{ y, items: [{ str }] }]) → plain text lines, top to bottom.
// (Build 53 read l.text, which pdfLines never gives: every line came out empty, so no price was ever found.)
export function pdfPagesToLines(pages) {
  const out = [];
  for (const p of Array.isArray(pages) ? pages : []) {
    const lines = Array.isArray(p) ? p : (p && p.lines) || [];
    for (const l of lines) {
      if (typeof l === 'string') out.push(l);
      else if (l && Array.isArray(l.items)) out.push(l.items.map((it) => String((it && it.str) || '')).join(' ').replace(/\s+/g, ' ').trim());
      else out.push(String((l && (l.text || l.str)) || ''));
    }
  }
  return out.filter(Boolean);
}
// The PDF's text lines → Schedule 1 prices { kg: { w, r }, c4_5: {…}, …, auto: {…} } (digits split by the PDF are joined).
export function parseLpgText(lines) {
  const all = (Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/)).map((l) => String(l).replace(/\s+/g, ' ').trim());
  const start = all.findIndex((l) => /^Schedule\s*1\b/i.test(l));
  const end = all.findIndex((l, i) => i > start && /^Schedule\s*2\b/i.test(l));
  const part = all.slice(start >= 0 ? start : 0, end > start ? end : all.length);
  const money = (s) => (String(s).replace(/\$\s*/g, '$').replace(/(\d)\s+(?=[\d.])/g, '$1').replace(/\.\s+(?=\d)/g, '.').match(/\$\d+(?:\.\d{1,2})?/g) || []).map((x) => r2(x.slice(1)));
  const out = {};
  const put = (key, vals) => { if (!out[key] && vals.length) out[key] = { w: vals[0], r: vals.length > 1 ? vals[1] : null }; };
  // A label alone on its line: its prices are on the next line(s) (Google's text reading of a PDF puts cells apart).
  let pending = null; let got = [];
  const flush = () => { if (pending && got.length) put(pending, got); pending = null; got = []; };
  for (let i = 0; i < part.length; i += 1) {
    const l = part[i];
    let key = null;
    if (/^Per\s*KG\b/i.test(l)) key = out.kg ? 'bulk' : 'kg';
    else if (/4\s*\.\s*5\s*KG\s*Cylinder/i.test(l)) key = 'c4_5';
    else if (/\b12\s*KG\s*Cylinder/i.test(l)) key = 'c12';
    else if (/\b40\s*KG\s*Cylinder/i.test(l)) key = 'c40';
    else if (/\b50\s*KG\s*Cylinder/i.test(l)) key = 'c50';
    else if (/^Per\s*Litre/i.test(l)) key = 'auto';
    const vals = money(l);
    const na = /\bN\/?A\b/.test(l);
    if (key) {
      flush();
      if (vals.length >= 2 || ((key === 'bulk' || na) && vals.length)) put(key, vals); else { pending = key; got = vals; }
    } else if (pending && (vals.length || na)) {
      got = got.concat(vals);
      if (got.length >= 2 || na || pending === 'bulk') flush();
    }
  }
  flush();
  delete out.bulk;
  return out;
}

// ---------------------------------------------------------------- the newest authorisation
export function lpgPrices() { return getShared('lpg_prices', null); }
export function lpgHistory() { return getShared('lpg_history', []) || []; }
// Sensible LPG retail prices: about $2–$8 a kg (any cylinder), and within 40 % of last month's.
const LPG_KG = { c4_5: 4.5, c12: 12, c40: 40, c50: 50 };
export function lpgOdd(prices, cur) {
  for (const [k, kg] of Object.entries(LPG_KG)) {
    const v = prices && prices[k] && Number(prices[k].r);
    if (!v) continue;
    if (v / kg < 2 || v / kg > 8) return `${k.replace('c', '').replace('_', '.')} kg $${v}`;
    const old = cur && cur.prices && cur.prices[k] && Number(cur.prices[k].r);
    if (old && Math.abs(v - old) / old > 0.4) return `${k.replace('c', '').replace('_', '.')} kg $${old} → $${v}`;
  }
  return null;
}
function keepPrices(p) {
  const cur = lpgPrices();
  if (cur && cur.effective === p.effective && JSON.stringify(cur.prices) === JSON.stringify(p.prices)) return false;
  setShared('lpg_prices', p);
  const h = lpgHistory().filter((x) => x.effective !== p.effective).concat([{ effective: p.effective, prices: p.prices }]).sort((a, b) => (a.effective < b.effective ? -1 : 1)).slice(-36);
  setShared('lpg_history', h);
  return true;
}
// Look at the gas page (a few times a day on each device; cheap). fetchText(url) → html, fetchBytes(url) → Uint8Array.
// 1.0.0 build 54: (1) this phone reads the page and the PDF; (2) when that fails (no PDF text, the web test build's
// CORS block, the website refusing a phone) the owner's cloud script reads them (cloud/Code.gs fccc_lpg: Apps Script
// fetches the page and PDF, Gemini or Google's text reading reads Schedule 1). Every failure leaves a plain message
// (lpg_problem, shown on the Gas screen) and "Type the prices" always works.
// cloud(body, ms) → the cloud's answer (throws on an error); undefined = the linked cloud, null = no cloud.
const NET_RE = /network|failed to fetch|fetch failed|abort|timed?\s*out|timeout|offline|internet|ENOTFOUND|EAI_AGAIN|getaddrinfo|ECONNREFUSED|ECONNRESET|socket/i;
export function plainWebError(e, site = 'the FCCC website') {
  const m = String((e && e.message) || e || '');
  if (NET_RE.test(m)) return `no internet, or ${site} did not answer`;
  const h = /HTTP\s*(\d{3})/i.exec(m);
  if (h) return `${site} answered with an error (${h[1]})`;
  if (/pdf|parse|invalid|header|xref|trailer|object/i.test(m)) return 'the PDF could not be opened on this phone';
  return m.replace(/^Error:\s*/, '').slice(0, 120) || 'something went wrong';
}
function linkedCloud() {
  try {
    if (!(require('../../services/core.js').getSettings() || {}).cloudUrl) return null;
    const C = require('../../platform/cloud.js');
    return (body, ms) => C.cloudCall(body, ms);
  } catch (e) { return null; }
}
// The cloud's prices ({ kg: { w, r }, … } from the AI, or the PDF's text) → the same shape as parseLpgText.
export function cleanLpgPrices(p) {
  const num = (v) => { if (v === null || v === undefined || v === '') return null; const n = Number(String(v).replace(/[$,\s]/g, '')); return Number.isFinite(n) && n > 0 && n < 10000 ? r2(n) : null; };
  const out = {};
  for (const k of Object.keys(LPG_LINES)) {
    const v = p && p[k];
    if (!v || typeof v !== 'object') continue;
    const w = num(v.w !== undefined ? v.w : v.wholesale); const r = num(v.r !== undefined ? v.r : v.retail);
    if (w !== null || r !== null) out[k] = { w, r };
  }
  return out;
}
export async function checkLpg({ fetchText, fetchBytes, cloud, force = false } = {}) {
  const last = Number(getSetting('lpg_last_look', 0)) || 0;
  if (!force && Date.now() - last < 6 * 3600000) return { skipped: 'not due' };
  const getText = fetchText || (async (u) => { const r = await fetch(u, { headers: { Accept: 'text/html' } }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); });
  const getBytes = fetchBytes || (async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}`); return new Uint8Array(await r.arrayBuffer()); });
  const cur = lpgPrices();
  let list = null; let phoneWhy = ''; let cloudWhy = '';
  // v3.9.8 a misread PDF must never become the FCCC maximum: prices outside a sensible range, or more than 40 %
  // away from last month's, wait for a person to check them.
  const finish = (effective, url, prices, via) => {
    setSetting('lpg_last_look', Date.now());
    const found = list ? list.length : 1;
    const odd = lpgOdd(prices, cur);
    if (odd) {
      const message = `The ${effective} gas prices look wrong (${odd}) – open the authorisation and type them by hand.`;
      setSetting('lpg_problem', message);
      return { found, read: false, odd, via, message };
    }
    setSetting('lpg_problem', '');
    const changed = keepPrices({ effective, url, prices, readAt: stamp(), via });
    return { found, read: true, changed, effective, prices, via, message: `Gas prices from ${effective} read${via === 'cloud' ? ' (by the cloud)' : ''}${changed ? '' : ' – no change'}.` };
  };
  // 1. this phone
  try {
    list = parseGasPage(await getText(GAS_PAGE));
    if (!list.length) phoneWhy = 'the FCCC gas page has changed (no list of authorisations found)';
    else {
      const newest = list[0];
      if (cur && cur.effective === newest.effective && !force) {
        setSetting('lpg_last_look', Date.now());
        if (getSetting('lpg_problem', '')) setSetting('lpg_problem', '');
        return { found: list.length, same: true, message: `No new authorisation – the prices from ${cur.effective} are the newest.` };
      }
      try {
        const { pdfTextItems, pdfLines } = require('../../services/pdfText.js');
        const prices = parseLpgText(pdfPagesToLines(pdfLines(await pdfTextItems(await getBytes(newest.url)))));
        if (prices.c12 || prices.c4_5) return finish(newest.effective, newest.url, prices, 'phone');
        phoneWhy = `the prices could not be found in the ${newest.effective} authorisation PDF`;
      } catch (e) { phoneWhy = `the ${newest.effective} authorisation could not be read on this phone (${plainWebError(e)})`; }
    }
  } catch (e) { phoneWhy = plainWebError(e); }
  // 2. the cloud
  const ask = cloud === undefined ? linkedCloud() : cloud;
  if (ask) {
    try {
      const r = await ask({ kind: 'fccc_lpg' }, 150000);
      let prices = cleanLpgPrices(r && r.prices);
      if (!prices.c12 && !prices.c4_5 && r && r.text) prices = parseLpgText(String(r.text));
      const eff = r && /^\d{4}-\d{2}-\d{2}$/.test(String(r.effective || '')) ? r.effective : null;
      if (eff && (prices.c12 || prices.c4_5)) {
        if (cur && cur.effective === eff && !force) { setSetting('lpg_last_look', Date.now()); setSetting('lpg_problem', ''); return { found: 1, same: true, via: 'cloud', message: `No new authorisation – the prices from ${eff} are the newest.` }; }
        return finish(eff, r.url || null, prices, 'cloud');
      }
      cloudWhy = 'the cloud could not find the prices in the authorisation';
    } catch (e) {
      const m = String((e && e.message) || e || '');
      if (/Unknown request/i.test(m)) cloudWhy = 'the cloud script is older than this app – paste the new cloud script (cloud/Code.gs) and deploy a new version';
      else if (/NO_LIST/.test(m)) cloudWhy = 'the cloud found no authorisation on the FCCC gas page';
      else if (/FETCH/.test(m)) cloudWhy = 'the cloud could not open the FCCC website either';
      else if (/NOT_READ|AI_ERROR|NO_AI_KEY/.test(m)) cloudWhy = 'the cloud could not read the PDF';
      else cloudWhy = `the cloud did not answer (${plainWebError(e, 'the cloud')})`;
    }
  }
  if (list && list.length) setSetting('lpg_last_look', Date.now());
  const message = `Could not look up the FCCC gas prices: ${[phoneWhy, cloudWhy].filter(Boolean).join('; ')}. Tap "Type the prices" and copy them from the FCCC authorisation.`;
  setSetting('lpg_problem', message);
  return { error: message, message, found: list ? list.length : 0, read: false };
}
// Typed by hand (if the PDF cannot be read): { effective, prices: { c12: { w, r }, … } }.
export function saveLpgPrices(user, { effective, prices }) {
  need(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage'), 'You cannot change the gas prices.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(txt(effective)), 'Enter the date the prices start.');
  const clean = {};
  for (const k of Object.keys(LPG_LINES)) { const v = prices && prices[k]; if (v && Number(v.r) > 0) clean[k] = { w: Number(v.w) > 0 ? r2(v.w) : null, r: r2(v.r) }; }
  need(Object.keys(clean).length, 'Enter at least one retail price.');
  keepPrices({ effective: txt(effective), url: null, prices: clean, readAt: stamp(), by: user.name });
  setSetting('lpg_problem', '');
  audit({ user, action: `LPG prices from ${effective} typed by hand`, table: 'shared_settings' });
}

// ---------------------------------------------------------------- our gas products
export function lpgLinks() { return getShared('lpg_links', {}) || {}; }
export function linkGasProduct(user, itemUid, line) {
  need(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage'), 'You cannot change products.');
  need(!line || LPG_LINES[line], 'Choose the FCCC gas line.');
  const m = { ...lpgLinks() };
  if (line) m[itemUid] = line; else delete m[itemUid];
  setShared('lpg_links', m);
  const it = db().get('SELECT name FROM inv_items WHERE uid = ?', [itemUid]) || {};
  audit({ user, action: line ? `${it.name}: FCCC gas price – ${LPG_LINES[line]}` : `${it.name}: not an FCCC gas product`, table: 'inv_items', recordUid: itemUid });
}
// Products that look like gas, with the line they look like (for the Yes / No round).
export function gasCandidates() {
  const links = lpgLinks();
  const rejected = getShared('lpg_not_gas', {}) || {};
  return db().all("SELECT uid, code, name, price FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (lower(name) LIKE '%gas%' OR lower(name) LIKE '%lpg%' OR lower(name) LIKE '%cylinder%')")
    .filter((x) => !links[x.uid] && !rejected[x.uid])
    .map((x) => {
      const n = x.name.toLowerCase();
      const m = /(\d+(?:\.\d+)?)\s*kg/.exec(n);
      const kg = m ? Number(m[1]) : null;
      const line = kg === 4.5 ? 'c4_5' : kg === 12 ? 'c12' : kg === 40 ? 'c40' : kg === 50 ? 'c50' : /auto/.test(n) ? 'auto' : null;
      return { ...x, line };
    });
}
export function notGas(user, itemUid) {
  const m = { ...(getShared('lpg_not_gas', {}) || {}) };
  m[itemUid] = user.name;
  setShared('lpg_not_gas', m);
}
// The maximum retail price for a line (a size not listed: in proportion to the per-kg price).
export function maxFor(line, prices = (lpgPrices() || {}).prices || {}) {
  if (prices[line] && prices[line].r) return prices[line].r;
  if (KG_OF[line] && prices.kg && prices.kg.r) return r2(prices.kg.r * KG_OF[line]);
  return null;
}
// Our linked gas products at each shop against the maximum, and their VAT in Aronium.
export function gasCheck() {
  const links = lpgLinks();
  const p = lpgPrices();
  const out = [];
  for (const [itemUid, line] of Object.entries(links)) {
    const it = db().get('SELECT uid, code, name, price, aronium_vat FROM inv_items WHERE uid = ?', [itemUid]);
    if (!it) continue;
    const max = p ? maxFor(line, p.prices) : null;
    let shops = [];
    try { shops = db().all('SELECT shop_code, price FROM inv_item_shops WHERE item_uid = ? AND active = 1', [itemUid]).map((x) => ({ shop: x.shop_code, price: x.price === null || x.price === undefined ? Number(it.price) || 0 : Number(x.price) })); } catch (e) { shops = []; }
    if (!shops.length) shops = [{ shop: 'All', price: Number(it.price) || 0 }];
    const over = max ? shops.filter((s) => s.price > max + 0.004) : [];
    const vatWrong = line !== 'auto' && it.aronium_vat && it.aronium_vat !== 'zero' && it.aronium_vat !== 'exempt';
    out.push({ ...it, line, max, shops, over, vatWrong });
  }
  return out;
}
export function lpgAlerts(user, today = dateStr()) {
  if (!user || !(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'inventory_manage') || can(user, 'inventory_view'))) return [];
  const out = [];
  const p = lpgPrices();
  const h = lpgHistory();
  if (p && h.length > 1 && p.effective >= today.slice(0, 8) + '01' && (today <= p.effective || today.slice(0, 7) === p.effective.slice(0, 7))) {
    const prev = h[h.length - 2];
    const changes = Object.keys(LPG_LINES).filter((k) => p.prices[k] && prev.prices[k] && p.prices[k].r !== prev.prices[k].r);
    if (changes.length) out.push({ id: `lpg-new-${p.effective}`, level: 'warning', text: `New LPG prices from ${p.effective} – change them in Aronium`, sub: changes.map((k) => `${LPG_LINES[k]} $${prev.prices[k].r.toFixed(2)} → $${p.prices[k].r.toFixed(2)}`).join(' · '), nav: { screen: 'Lpg', params: {} } });
  }
  let chk = [];
  try { chk = gasCheck(); } catch (e) { chk = []; }
  const over = chk.filter((x) => x.over.length);
  if (over.length) out.push({ id: `lpg-over-${over.length}-${p ? p.effective : ''}`, level: 'urgent', text: `${over.length} gas product${over.length === 1 ? ' is' : 's are'} priced above the FCCC maximum`, sub: over.map((x) => `${x.name}: ${x.over.map((s) => `${s.shop} $${s.price.toFixed(2)}`).join(', ')} – max $${x.max.toFixed(2)}`).join(' · '), nav: { screen: 'Lpg', params: {} } });
  const vat = chk.filter((x) => x.vatWrong);
  if (vat.length) out.push({ id: `lpg-vat-${vat.length}`, level: 'warning', text: `${vat.length} gas cylinder${vat.length === 1 ? ' has' : 's have'} VAT set in Aronium – cooking gas cylinders are zero-rated`, sub: vat.map((x) => x.name).join(', '), nav: { screen: 'Lpg', params: {} } });
  const cand = (() => { try { return gasCandidates(); } catch (e) { return []; } })();
  if (cand.length) out.push({ id: `lpg-cand-${cand.length}`, level: 'info', text: `${cand.length} product${cand.length === 1 ? ' looks' : 's look'} like gas – confirm the FCCC gas line`, nav: { screen: 'Lpg', params: {} } });
  const prob = getSetting('lpg_problem', '');
  if (prob) out.push({ id: `lpg-prob-${today}`, level: 'info', text: 'FCCC gas prices', sub: prob, nav: { screen: 'Lpg', params: {} } });
  const fp = getSetting('fuel_problem', '');
  if (fp) out.push({ id: `fuel-prob-${today}`, level: 'info', text: 'FCCC petrol and diesel prices', sub: fp, nav: { screen: 'Lpg', params: {} } });
  return out;
}

// ---------------------------------------------------------------- v3.9.8 petrol and diesel (FCCC Petroleum Prices Order)
// fccc.gov.fj/master-price-list/petroleum/ lists "Petroleum Prices (No. N) Order YYYY" (monthly, from the 1st).
// Schedule 1 = Viti Levu within 3 km of a public road: motor spirit (unleaded), gasoil (diesel), kerosene, premix –
// retail per litre (VIP, VAT included). Used to check our vehicles' fuel receipts.
export const FUEL_PAGE = 'https://fccc.gov.fj/master-price-list/petroleum/';
export const FUEL_LABEL = { petrol: 'Petrol (motor spirit, unleaded)', diesel: 'Diesel (gasoil)', kerosene: 'Kerosene', premix: 'Premix' };
const MONTH_NO = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
export function parsePetroleumPage(html, base = FUEL_PAGE) {
  const out = [];
  const re = /<a[^>]+href="([^"]+\.pdf)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || '')))) {
    const label = m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
    const d = /Petroleum Prices\s*\(No\.?\s*(\d+)\)\s*Order\s*(\d{4})/i.exec(label);
    if (!d) continue;
    let url = m[1];
    if (!/^https?:/i.test(url)) url = new URL(url, base).href;
    out.push({ url, no: Number(d[1]), year: Number(d[2]) });
  }
  return out.sort((a, b) => (b.year - a.year) || (b.no - a.no));
}
export function parsePetroleumText(lines) {
  const all = (Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/)).map((l) => String(l).replace(/\s+/g, ' ').trim());
  const text = all.join('\n');
  const eff = /comes into force on\s*(\d{1,2})\s*([A-Za-z]+)\s*(\d{4})/i.exec(text);
  const effective = eff && MONTH_NO[eff[2].toLowerCase()] ? `${eff[3]}-${String(MONTH_NO[eff[2].toLowerCase()]).padStart(2, '0')}-${String(Number(eff[1])).padStart(2, '0')}` : null;
  const start = all.findIndex((l) => /^SCHEDULE\s*1\b/.test(l));
  const end = all.findIndex((l, i) => i > start && /^SCHEDULE\s*2\b/.test(l));
  const part = all.slice(start >= 0 ? start : 0, end > start ? end : all.length);
  const out = {};
  const price = (l) => { const m2 = /\$\s*(\d+(?:\.\d{1,2})?)\s*\(?VIP/i.exec(l.replace(/(\d)\s+(?=[\d.])/g, '$1')); return m2 ? r2(m2[1]) : null; };
  for (const l of part) {
    let k = null;
    if (/motor spirit|unleaded/i.test(l)) k = 'petrol';
    else if (/gasoil|diesel/i.test(l)) k = 'diesel';
    else if (/kerosene/i.test(l)) k = 'kerosene';
    else if (/premix/i.test(l)) k = 'premix';
    if (k && !out[k]) { const v = price(l); if (v) out[k] = v; }
  }
  return { effective, prices: out };
}
export function fuelPrices() { return getShared('fuel_prices', null); }
export async function checkFuel({ fetchText, fetchBytes, force = false } = {}) {
  const last = Number(getSetting('fuel_last_look', 0)) || 0;
  if (!force && Date.now() - last < 12 * 3600000) return { skipped: 'not due' };
  const getText = fetchText || (async (u) => { const r = await fetch(u, { headers: { Accept: 'text/html' } }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.text(); });
  const getBytes = fetchBytes || (async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`HTTP ${r.status}`); return new Uint8Array(await r.arrayBuffer()); });
  try {
    const list = parsePetroleumPage(await getText(FUEL_PAGE));
    setSetting('fuel_last_look', Date.now());
    if (!list.length) return { found: 0 };
    const n = list[0];
    const cur = fuelPrices();
    if (cur && cur.url === n.url && !force) return { same: true };
    const { pdfTextItems, pdfLines } = require('../../services/pdfText.js');
    const lines = pdfPagesToLines(pdfLines(await pdfTextItems(await getBytes(n.url))));
    const r = parsePetroleumText(lines);
    if (!r.prices.petrol && !r.prices.diesel) { setSetting('fuel_problem', `Could not find the petrol and diesel prices in the FCCC order No. ${n.no} of ${n.year} – open it and check by hand.`); return { read: false }; }
    // a misread number (e.g. 31.5 for 3.15) is never kept: petrol / diesel between $1 and $8 a litre, within 40 % of before
    for (const k of ['petrol', 'diesel']) {
      const v = Number(r.prices[k]); const o = cur && cur.prices ? Number(cur.prices[k]) : 0;
      if (v && (v < 1 || v > 8 || (o && Math.abs(v - o) / o > 0.4))) { setSetting('fuel_problem', `The fuel prices look wrong (${k} $${v}) – check them by hand.`); return { read: false, odd: k }; }
    }
    setSetting('fuel_problem', '');
    setShared('fuel_prices', { ...r, url: n.url, order: `No. ${n.no} of ${n.year}`, readAt: stamp() });
    return { read: true, ...r };
  } catch (e) {
    const message = `Could not look up the FCCC petrol and diesel prices: ${plainWebError(e)}. Fuel receipts are checked against the last prices kept.`;
    setSetting('fuel_problem', message);
    return { error: message };
  }
}
