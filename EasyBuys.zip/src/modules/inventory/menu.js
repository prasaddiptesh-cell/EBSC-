// Inventory & orders menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '📦', title: 'Inventory today', note: 'Stock, low stock, orders on the way.', screen: 'Inventory' },
    { id: 'inv-today-orders', icon: '🗓️', title: "Today's orders", note: 'Which suppliers to order from today, before their cut-off.', screen: 'TodaysOrders' },
    { id: 'inv-receive', icon: '🚚', title: 'Receive a delivery', screen: 'POList', params: { status: 'to_receive' } },
    { id: 'inv-po-new', icon: '📝', title: 'New purchase order', screen: 'POEdit' },
    { id: 'inv-scan-po', icon: '📷', title: 'Scan products into an order', note: 'Camera or handheld scanner.', screen: 'POEdit', params: { scan: true } },
    { id: 'inv-adjust', icon: '🗑️', title: 'Write off / adjust', screen: 'StockAdjust' },
    { id: 'inv-transfers', icon: '🔁', title: 'Move stock between shops', screen: 'Transfers' },
  ] },
  { section: 'Records', items: [
    { id: 'inv-products', icon: '🏷️', title: 'Products', note: 'Every product; add one by hand.', screen: 'InvProducts' },
    { id: 'inv-stock', icon: '📦', title: 'Stock on hand', screen: 'InvStock' },
    { id: 'inv-po', icon: '🗂️', title: 'Purchase orders', screen: 'POList' },
    { id: 'inv-return', icon: '↩️', title: 'Return to supplier', screen: 'SupplierReturn' },
  ] },
  { section: 'Checks', items: [
    { id: 'inv-count', icon: '📋', title: 'Stock take', screen: 'StockTakes' },
    { id: 'inv-costs', icon: '💲', title: 'Cost price changes', screen: 'CostChanges' },
    { id: 'inv-read-invoice', icon: '🔎', title: 'Read a supplier invoice', note: 'Lines matched to the order and delivery; price changes flagged.', screen: 'InvoiceRead' },
    { id: 'inv-low', icon: '⚠️', title: 'Low stock', screen: 'InvStock', params: { filter: 'low' } },
  ] },
  { section: 'Reports', items: [
    { id: 'inv-reports', icon: '📊', title: 'Inventory reports', screen: 'ReportsHub', params: { group: 'Inventory' }, perm: 'reports' },
    { id: 'inv-po-reports', icon: '📊', title: 'Purchase order reports', screen: 'ReportsHub', params: { group: 'Purchase orders' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'inv-import', icon: '📥', title: 'Import from Aronium', screen: 'InvImport' },
    { id: 'inv-sup-import', icon: '📥', title: 'Import suppliers from Aronium', screen: 'SupplierImport' },
    { id: 'inv-schedules', icon: '📅', title: 'Supplier order days', note: 'Order days, cut-off times, delivery days and reminders.', screen: 'SupplierSchedules' },
    { id: 'inv-setup', icon: '⚙️', title: 'Inventory settings', screen: 'InventorySetup' },
  ] },
];
