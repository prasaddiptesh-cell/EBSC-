// 1.0.0 The shop's own words for packs, learnt as people use them: "sleeve" for BH 10 is 10 packets, a "carton" of
// Pall Mall is 50, a "crate" of Coke is 24, a "tray" of eggs is 30 … Stock is always kept in singles (what the till
// sells); a word only says how many singles it holds.
//   • taught for one product, or for a whole group at once ("every Cigarettes product: sleeve = 10");
//   • a product's own word wins over its group's; "carton" also comes from the product's pack size;
//   • short forms are understood (slv, ctn, cs, dz, pkt …), and a new word is learnt the first time it is taught;
//   • "2 sleeves 3", "1 ctn + 2 slv + 4", "3slv" are read into singles; an unknown word asks to be taught – never guessed.
import { db } from '../../db/connection.js';
import { getShared, setShared, audit, AppError } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const KEY = 'pack_terms';
const need = (c, m) => { if (!c) throw new AppError(m); };
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const low = (v) => String(v === null || v === undefined ? '' : v).trim().toLowerCase();

// The words every shop uses, with their short forms. "single" means one of what the till sells.
export const WORDS = {
  single: ['single', 'singles', 'each', 'ea', 'pkt', 'pkts', 'packet', 'packets', 'pc', 'pcs', 'piece', 'pieces', 'unit', 'units', 'btl', 'bottle', 'bottles', 'can', 'cans'],
  loose: ['loose', 'loos', 'lse', 'open'],
  sleeve: ['sleeve', 'sleeves', 'slv', 'slvs', 'sl'],
  carton: ['carton', 'cartons', 'ctn', 'ctns', 'cart', 'ct'],
  case: ['case', 'cases', 'cs'],
  crate: ['crate', 'crates', 'cr'],
  box: ['box', 'boxes', 'bx'],
  tray: ['tray', 'trays', 'tr'],
  bundle: ['bundle', 'bundles', 'bdl', 'bdls'],
  outer: ['outer', 'outers'],
  bale: ['bale', 'bales'],
  bag: ['bag', 'bags', 'sack', 'sacks'],
  dozen: ['dozen', 'dozens', 'dz', 'doz'],
  pack: ['pack', 'packs', 'multipack'],
};
const FIXED = { single: 1, dozen: 12 };

function store() {
  const s = getShared(KEY, null) || {};
  return { items: s.items && typeof s.items === 'object' ? s.items : {}, groups: s.groups && typeof s.groups === 'object' ? s.groups : {}, words: s.words && typeof s.words === 'object' ? s.words : {} };
}
// A typed word → the shop's word for it ("Slvs" → "sleeve"), or null.
export function wordOf(w) {
  const x = low(w).replace(/\.$/, '');
  if (!x) return null;
  for (const [k, list] of Object.entries(WORDS)) if (k === x || list.includes(x)) return k;
  const learnt = store().words;
  if (learnt[x]) return learnt[x];
  const one = x.endsWith('es') && learnt[x.slice(0, -2)] ? x.slice(0, -2) : x.endsWith('s') && learnt[x.slice(0, -1)] ? x.slice(0, -1) : null;
  return one ? learnt[one] : null;
}
const canonNew = (w) => { const x = low(w).replace(/[^a-z ]/g, '').trim(); return x.length > 3 && x.endsWith('s') && !x.endsWith('ss') ? x.slice(0, -1) : x; };

function item(itemUid) {
  try { return db().get('SELECT uid, code, name, group_name, unit, pack_size FROM inv_items WHERE uid = ?', [itemUid]); } catch (e) { return null; }
}
// Every word this product knows: [{ word, qty, from: 'product'|'group'|'pack size'|'fixed' }], biggest first.
export function termsFor(itemOrUid) {
  const it = typeof itemOrUid === 'object' && itemOrUid ? itemOrUid : item(itemOrUid);
  if (!it) return [];
  const s = store();
  const out = new Map();
  if (Number(it.pack_size) > 1) out.set('carton', { word: 'carton', qty: q3(it.pack_size), from: 'pack size' });
  for (const [w, n] of Object.entries(s.groups[low(it.group_name)] || {})) if (Number(n) > 1) out.set(w, { word: w, qty: q3(n), from: 'group' });
  for (const [w, n] of Object.entries(s.items[it.uid] || {})) if (Number(n) > 1) out.set(w, { word: w, qty: q3(n), from: 'product' });
  // 1.0.0 sold loose from this pack (e.g. one Maggi from the 5 pack): a loose one is a part of a pack
  try { for (const l of require('./looseLinks.js').looseFor(it.uid)) out.set('loose', { word: 'loose', qty: Math.round((1 / l.per) * 10000) / 10000, from: 'loose', label: `loose (${l.per} = 1)`, per: l.per }); } catch (e) { /* no links */ }
  return [...out.values()].sort((a, b) => b.qty - a.qty);
}
function qtyOf(it, word) {
  if (FIXED[word]) return FIXED[word];
  const t = termsFor(it).find((x) => x.word === word);
  return t ? t.qty : null;
}

// Teach a word: "sleeve = 10" for this product, or for its whole group (forGroup). A new word is learnt too.
export function teachTerm(user, itemUid, { word, qty, forGroup = false } = {}) {
  requirePerm(user, ['inventory_manage', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const it = item(itemUid);
  need(it, 'Product not found.');
  const n = Number(String(qty === undefined || qty === null ? '' : qty).replace(/[,\s]/g, ''));
  need(Number.isFinite(n) && n >= 2 && n <= 10000 && Math.abs(n - Math.round(n * 1000) / 1000) < 1e-9, 'How many singles are in it? (2 or more)');
  const raw = low(word);
  need(/^[a-z][a-z .'-]{0,24}$/.test(raw), 'Write the word in letters, e.g. sleeve, carton, crate.');
  const known = wordOf(raw);
  need(!FIXED[known], known === 'dozen' ? 'A dozen is always 12.' : 'One single is always 1 – choose another word.');
  const w = known || canonNew(raw);
  const s = store();
  if (!known) s.words[w] = w; // a new word the shop uses
  if (forGroup) {
    need(it.group_name, 'This product has no group – teach it for the product only.');
    const g = low(it.group_name);
    s.groups[g] = { ...(s.groups[g] || {}), [w]: q3(n) };
  } else {
    s.items[it.uid] = { ...(s.items[it.uid] || {}), [w]: q3(n) };
  }
  setShared(KEY, s);
  audit({ user, action: `Pack word: 1 ${w} = ${q3(n)} ${forGroup ? `for every ${it.group_name} product` : `for ${it.name}`}`, table: 'inv_items', recordUid: it.uid });
  return termsFor(it.uid);
  });
}
export function forgetTerm(user, itemUid, word, { forGroup = false } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const it = item(itemUid);
  need(it, 'Product not found.');
  const w = wordOf(word) || low(word);
  const s = store();
  if (forGroup) { const g = low(it.group_name); if (s.groups[g]) delete s.groups[g][w]; } else if (s.items[it.uid]) delete s.items[it.uid][w];
  setShared(KEY, s);
  audit({ user, action: `Pack word "${w}" removed ${forGroup ? `for ${it.group_name}` : `for ${it.name}`}`, table: 'inv_items', recordUid: it.uid });
  return termsFor(it.uid);
  });
}

// "2 sleeves 3", "1 ctn + 2 slv + 4", "3slv", "2 dz" → singles. A number with no word is singles.
// An unknown word (or one this product has not been taught) throws an AppError with .teach = { word } – never a guess.
export function readQty(itemOrUid, text) {
  const it = typeof itemOrUid === 'object' && itemOrUid ? itemOrUid : item(itemOrUid);
  need(it, 'Product not found.');
  const s = low(text).replace(/[+,&]/g, ' ').replace(/\band\b/g, ' ').replace(/(\d)([a-z])/g, '$1 $2').replace(/\s+/g, ' ').trim();
  need(s, 'Type how many.');
  const toks = s.split(' ');
  let total = 0; let i = 0; const parts = [];
  while (i < toks.length) {
    const n = Number(toks[i]);
    need(Number.isFinite(n) && n >= 0 && /^\d+(\.\d+)?$/.test(toks[i]), `"${toks[i]}" is not a number. Write it like "2 sleeves 3".`);
    const next = toks[i + 1];
    if (next !== undefined && !/^\d/.test(next)) {
      const w = wordOf(next);
      const per = w ? qtyOf(it, w) : null;
      if (!per) throw Object.assign(new AppError(`How many singles of ${it.name} are in one "${next}"? Teach it once and the app remembers.`), { teach: { word: w || next, itemUid: it.uid } });
      total += n * per; parts.push({ n, word: w, per }); i += 2;
    } else { total += n; parts.push({ n, word: 'single', per: 1 }); i += 1; }
  }
  return { qty: q3(total), parts };
}
// Singles → the shop's words: 34 BH 10 → "3 sleeves + 4" (biggest words first; only when it helps).
export function describeQty(itemOrUid, singles) {
  const it = typeof itemOrUid === 'object' && itemOrUid ? itemOrUid : item(itemOrUid);
  let left = q3(singles);
  if (!it || !(left > 0)) return String(left);
  const out = [];
  for (const t of termsFor(it)) {
    if (t.qty < 1) continue; // loose parts are shown as the number left over
    const k = Math.floor(left / t.qty + 1e-9);
    if (k > 0) { out.push(`${k} ${t.word}${k === 1 ? '' : t.word.endsWith('x') ? 'es' : 's'}`); left = q3(left - k * t.qty); }
  }
  if (!out.length) return String(q3(singles));
  if (left > 0) out.push(String(left));
  return out.join(' + ');
}
// Every word taught so far (for the settings screen).
export function allTerms() {
  const s = store();
  const names = new Map(safeAll('SELECT uid, name FROM inv_items').map((r) => [r.uid, r.name]));
  return {
    groups: Object.entries(s.groups).flatMap(([g, m]) => Object.entries(m).map(([w, n]) => ({ group: g, word: w, qty: n }))),
    items: Object.entries(s.items).flatMap(([u, m]) => Object.entries(m).map(([w, n]) => ({ itemUid: u, name: names.get(u) || u, word: w, qty: n }))),
    words: Object.keys(s.words),
  };
}
function safeAll(sql) { try { return db().all(sql); } catch (e) { return []; } }
