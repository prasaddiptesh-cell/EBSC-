// Changing a purchase order after it was sent to the supplier, and correcting a delivery.
//  • Draft / waiting / approved: fully editable with savePO (service.js).
//  • Sent: only people who may approve orders can change it. Owner/admin need no reason, others must give one.
//    Every change is kept as a new version, and an "Amended" PDF is offered to send to the supplier.
//  • Part received / received / closed: dates, notes, new lines, and the quantity / price of what has not arrived yet.
//    What was delivered is never changed here: it is corrected on the delivery itself (correctDelivery).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from '../../services/core.js';
import { can, needReason } from '../../services/access.js';
import * as I from './service.js';

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const { r2, r4, q3, $, fmtQ } = I;

export const EDIT_MODE_LABEL = {
  full: 'Not sent yet – everything can be changed.',
  sent: 'Already sent – the supplier gets an "Amended" order.',
  received: 'Goods have arrived – only dates, notes, new products and what has not arrived yet can change.',
  dates: 'Closed – only the dates and notes can change.',
  none: '',
};

// What this person may change on this order now.
export function poEditMode(user, o) {
  if (!o) return { mode: 'none', why: 'Order not found.' };
  if (['draft', 'awaiting', 'approved'].includes(o.status)) {
    return can(user, 'po_create') ? { mode: 'full' } : { mode: 'none', why: 'Your login may not make or change orders.' };
  }
  if (o.status === 'cancelled') return { mode: 'none', why: 'A cancelled order cannot be changed.' };
  if (!can(user, 'po_approve')) return { mode: 'none', why: 'Only someone who may approve orders can change an order after it has been sent.' };
  if (o.status === 'sent') return { mode: 'sent' };
  return { mode: 'received' };
}

function snapshot(o) {
  return {
    order_date: o.order_date, expected_date: o.expected_date || null, notes: o.notes || null, total: o.total,
    lines: o.lines.filter((l) => l.qty > 0 || l.qty_received > 0).map((l) => ({ uid: l.uid, item_uid: l.item_uid, code: l.code, name: l.name, unit: l.unit, qty: l.qty, unit_cost: l.unit_cost, note: l.note || null, qty_received: l.qty_received })),
  };
}

function addVersion(o, { kind, user, reason, changes, before, after }) {
  const { now, dev } = meta();
  const v = (Number(o.version) || 1) + 1;
  db().run(`INSERT INTO po_versions (uid, po_uid, version, kind, at, by_name, reason, changes, before, after, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uuid('PV'), o.uid, v, kind, now, user ? user.name : null, txt(reason) || null, JSON.stringify(changes), JSON.stringify(before), JSON.stringify(after), now, dev]);
  if (kind === 'delivery_fix') db().run(`UPDATE po_orders SET version = ?, ${SYNCED} WHERE uid = ?`, [v, now, dev, o.uid]);
  else db().run(`UPDATE po_orders SET version = ?, amended_at = ?, amended_by_name = ?, amend_sent_at = NULL, ${SYNCED} WHERE uid = ?`, [v, now, user ? user.name : null, now, dev, o.uid]);
  return v;
}

// Change a sent (or received) order. f: { orderDate, expectedDate, notes, lines: [{ lineUid?, itemUid?, name?, code?, unit?, qty, unitCost, note }] }
// Lines left out: removed (sent), or "nothing more to come" (received: quantity set to what arrived).
export function amendPO(user, uid, f = {}, { reason } = {}) {
  const o = I.getPO(uid);
  const m = poEditMode(user, o);
  need(m.mode !== 'none', m.why || 'This order cannot be changed.');
  need(m.mode !== 'full', 'This order has not been sent yet – change it normally.');
  needReason(user, reason, 'Say why the order is being changed after it was sent.');
  const before = snapshot(o);
  const changes = [];
  const orderDate = f.orderDate === undefined ? o.order_date : txt(f.orderDate);
  need(DATE.test(orderDate), 'Enter the order date.');
  const expected = f.expectedDate === undefined ? o.expected_date : txt(f.expectedDate) || null;
  need(!expected || DATE.test(expected), 'Check the delivery date.');
  need(!expected || expected >= orderDate, 'Delivery cannot be before the order date.');
  const notes = f.notes === undefined ? o.notes : txt(f.notes) || null;
  if (orderDate !== o.order_date) changes.push(`Order date ${o.order_date} → ${orderDate}`);
  if ((expected || '') !== (o.expected_date || '')) changes.push(`Deliver by ${o.expected_date || '—'} → ${expected || '—'}`);
  if ((notes || '') !== (o.notes || '')) changes.push(`Note changed`);

  const want = Array.isArray(f.lines) ? f.lines : null;
  const plan = []; // { line?, itemUid, name, code, unit, qty, unitCost, note }
  if (want) {
    const seen = new Set();
    for (const w of want) {
      const line = w.lineUid ? o.lines.find((l) => l.uid === w.lineUid) : null;
      need(!w.lineUid || line, 'A line is not on this order.');
      if (line) seen.add(line.uid);
      const it = !line && w.itemUid ? I.getItem(w.itemUid) : null;
      need(line || it || txt(w.name), 'A new line needs a product.');
      const qty = q3(w.qty);
      const cost = r4(w.unitCost === undefined || w.unitCost === '' ? (line ? line.unit_cost : it ? it.cost : 0) : w.unitCost);
      need(qty >= 0 && cost >= 0, 'Quantities and costs cannot be negative.');
      if (line) {
        if (w.itemUid && w.itemUid !== line.item_uid) need(!line.qty_received, `"${line.name}" has already arrived – add the other product as a new line instead.`);
        need(qty + 1e-9 >= line.qty_received, `${fmtQ(line.qty_received)} × ${line.name} already arrived – the order cannot be less than that. If the delivery count was wrong, correct the delivery instead.`);
        const leftNow = line.qty - line.qty_received;
        if (Math.abs(cost - line.unit_cost) > 0.00005) {
          need(!(line.qty_received > 0 && leftNow <= 1e-9 && qty <= line.qty_received + 1e-9),
            `All of "${line.name}" has arrived – its price is corrected on the delivery, not the order.`);
        }
        plan.push({ line, itemUid: w.itemUid || line.item_uid, qty, unitCost: cost, note: w.note === undefined ? line.note : txt(w.note) || null });
      } else if (qty > 0) {
        plan.push({ line: null, itemUid: it ? it.uid : null, name: it ? it.name : txt(w.name), code: it ? it.code : txt(w.code) || null, unit: it ? it.unit : txt(w.unit) || 'each', qty, unitCost: cost, note: txt(w.note) || null });
      }
    }
    for (const l of o.lines.filter((x) => x.qty > 0 && !seen.has(x.uid))) plan.push({ line: l, itemUid: l.item_uid, qty: l.qty_received, unitCost: l.unit_cost, note: l.note, removed: true });
  }
  for (const p of plan) {
    if (!p.line) { changes.push(`Added ${p.name} × ${fmtQ(p.qty)}${p.unitCost ? ` at ${$(p.unitCost)}` : ''}`); continue; }
    const l = p.line;
    if (Math.abs(p.qty - l.qty) > 1e-9) changes.push(p.removed || p.qty === 0 ? (l.qty_received ? `${l.name}: rest not needed (${fmtQ(l.qty)} → ${fmtQ(p.qty)})` : `Removed ${l.name}`) : `${l.name}: ${fmtQ(l.qty)} → ${fmtQ(p.qty)}`);
    if (Math.abs(p.unitCost - l.unit_cost) > 0.00005) changes.push(`${l.name}: price ${$(l.unit_cost)} → ${$(p.unitCost)}`);
    if ((p.note || '') !== (l.note || '')) changes.push(`${l.name}: comment changed`);
  }
  need(changes.length, 'Nothing was changed.');
  const liveAfter = plan.length ? plan.filter((p) => p.qty > 0) : o.lines.filter((l) => l.qty > 0);
  need(liveAfter.length, 'The order would have no products left. Cancel the order instead.');

  const { now, dev } = meta();
  let sort = o.lines.reduce((mx, l) => Math.max(mx, l.sort || 0), 0);
  for (const p of plan) {
    if (p.line) {
      const it = p.itemUid ? I.getItem(p.itemUid) : null;
      db().run(`UPDATE po_lines SET item_uid = ?, code = ?, name = ?, unit = ?, qty = ?, unit_cost = ?, note = ?, ${SYNCED} WHERE uid = ?`,
        [p.itemUid, it ? it.code : p.line.code, it ? it.name : p.line.name, it ? it.unit : p.line.unit, p.qty, p.unitCost, p.note, now, dev, p.line.uid]);
    } else {
      sort += 1;
      db().run(`INSERT INTO po_lines (uid, po_uid, item_uid, code, name, unit, qty, unit_cost, qty_received, note, sort, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?)`,
        [uuid('PL'), uid, p.itemUid, p.code, p.name, p.unit, p.qty, p.unitCost, p.note, sort, now, dev]);
    }
  }
  const sup = db().get('SELECT vat_registered FROM ap_suppliers WHERE uid = ?', [o.supplier_uid]) || {};
  const lines = db().all('SELECT * FROM po_lines WHERE po_uid = ?', [uid]);
  const total = r2(lines.reduce((t, l) => t + I.incVat(l.qty * l.unit_cost, l.item_uid ? (I.getItem(l.item_uid) || {}).vat_type : (sup.vat_registered === 0 ? 'zero' : 'standard')), 0));
  db().run(`UPDATE po_orders SET order_date = ?, expected_date = ?, notes = ?, total = ?, ${SYNCED} WHERE uid = ?`, [orderDate, expected, notes, total, now, dev, uid]);
  if (o.status === 'closed' && lines.some((l) => l.qty > l.qty_received + 1e-9)) db().run(`UPDATE po_orders SET status = 'part', cancel_reason = NULL, ${SYNCED} WHERE uid = ?`, [now, dev, uid]);
  I.refreshPOStatus(uid);
  const after = snapshot(I.getPO(uid));
  const version = addVersion(o, { kind: m.mode === 'sent' ? 'amend' : 'after_receive', user, reason, changes, before, after });
  audit({ user, action: `Changed order ${o.po_no} after ${m.mode === 'sent' ? 'sending' : 'delivery'} (version ${version}): ${changes.join('; ')}`, table: 'po_orders', recordUid: uid,
    before: { total: o.total }, after: { total }, reason: txt(reason) || null });
  const po = I.getPO(uid);
  const stillToCome = po.lines.some((l) => l.qty > l.qty_received + 1e-9);
  return { po, version, changes, offerAmended: stillToCome, budget: I.budgetCheck(o.supplier_uid, total, orderDate, uid) };
}

// The amended order was sent to the supplier (PDF / Viber / phoned).
export function markAmendedSent(user, uid, via = 'pdf') {
  const o = I.getPO(uid);
  need(o && o.version > 1, 'This order has not been changed.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET amend_sent_at = ?, ${SYNCED} WHERE uid = ?`, [now, now, dev, uid]);
  audit({ user, action: `Sent the amended order ${o.po_no} (version ${o.version}) by ${via}`, table: 'po_orders', recordUid: uid });
}

export function poVersions(uid) {
  return db().all('SELECT * FROM po_versions WHERE po_uid = ? ORDER BY version DESC, at DESC', [uid])
    .map((v) => ({ ...v, changes: J(v.changes, []), before: J(v.before, null), after: J(v.after, null) }));
}

// ---------------------------------------------------------------- correcting a delivery
// The count on a delivery was wrong (or the invoice price): fix the delivery. Stock, the order's "received" numbers
// and (if it is the latest price) the product's cost follow. lines: [{ itemUid, qty, unitCost }] – only changed ones needed.
export function correctDelivery(user, receiptUid, { lines = [], reason } = {}) {
  const r = I.getReceipt(receiptUid);
  need(r && r.status === 'active', 'Delivery not found or voided.');
  need(r.kind === 'receive', 'Only deliveries can be corrected here.');
  needReason(user, reason, 'Say what was wrong on the delivery.');
  const rules = I.invRules();
  const fixes = [];
  for (const w of lines) {
    const l = r.lines.find((x) => x.itemUid === w.itemUid && (!w.lineUid || x.lineUid === w.lineUid));
    need(l, 'A product is not on this delivery.');
    const qty = w.qty === undefined || w.qty === '' ? l.qty : q3(w.qty);
    const cost = w.unitCost === undefined || w.unitCost === '' ? l.unitCost : r4(w.unitCost);
    need(qty >= 0 && cost >= 0, 'Quantities and prices cannot be negative.');
    if (Math.abs(qty - l.qty) < 1e-9 && Math.abs(cost - l.unitCost) < 0.00005) continue;
    fixes.push({ l, qty, cost, delta: q3(qty - l.qty) });
  }
  need(fixes.length, 'Nothing was changed.');
  for (const f of fixes) I.notFrozen(f.l.itemUid, r.shop_code);
  const { now, dev } = meta();
  const changes = [];
  for (const f of fixes) {
    const { l } = f;
    if (Math.abs(f.delta) > 1e-9) {
      I.addMove({ itemUid: l.itemUid, shopCode: r.shop_code, date: r.receive_date, type: 'receive', qty: f.delta, unitCost: f.cost, refType: 'receipt_fix', refUid: receiptUid,
        reason: `Delivery corrected: ${fmtQ(l.qty)} → ${fmtQ(f.qty)}`, user });
      if (l.lineUid) db().run(`UPDATE po_lines SET qty_received = MAX(0, qty_received + ?), ${SYNCED} WHERE uid = ?`, [f.delta, now, dev, l.lineUid]);
      changes.push(`${l.name}: delivered ${fmtQ(l.qty)} → ${fmtQ(f.qty)}`);
    }
    if (Math.abs(f.cost - l.unitCost) > 0.00005) {
      db().run(`UPDATE inv_moves SET unit_cost = ?, ${SYNCED} WHERE ref_uid = ? AND item_uid = ? AND status = 'active'`, [f.cost, now, dev, receiptUid, l.itemUid]);
      changes.push(`${l.name}: price ${$(l.unitCost)} → ${$(f.cost)}`);
      // The product's cost follows when this is its latest delivery (cost = last price paid).
      const latest = db().get("SELECT ref_uid FROM inv_moves WHERE item_uid = ? AND type = 'receive' AND status = 'active' AND ref_type = 'receipt' ORDER BY move_date DESC, created_at DESC LIMIT 1", [l.itemUid]);
      const it = I.getItem(l.itemUid);
      if (rules.costMethod === 'last' && latest && latest.ref_uid === receiptUid && it && Math.abs(it.cost - f.cost) > 0.00005) {
        db().run(`UPDATE inv_items SET cost = ?, ${SYNCED} WHERE uid = ?`, [f.cost, now, dev, it.uid]);
        I.logCostChange({ itemUid: it.uid, oldCost: it.cost, newCost: f.cost, source: 'delivery_fix', supplierName: r.supplier_name, refUid: receiptUid, shopCode: r.shop_code });
      }
    }
  }
  const newLines = r.lines.map((l) => {
    const f = fixes.find((x) => x.l === l);
    return f ? { ...l, qty: f.qty, unitCost: f.cost, corrected: { qty: l.qty, unitCost: l.unitCost, by: user.name, at: now } } : l;
  });
  const total = r2(newLines.reduce((t, l) => t + I.incVat(l.qty * l.unitCost, (I.getItem(l.itemUid) || {}).vat_type), 0));
  const note = [r.match_note, `Corrected by ${user.name} ${now.slice(0, 16)}: ${changes.join('; ')}${txt(reason) ? ` (${txt(reason)})` : ''}`].filter(Boolean).join(' | ');
  db().run(`UPDATE inv_receipts SET lines = ?, total = ?, match_note = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(newLines), total, note, now, dev, receiptUid]);
  if (r.po_uid) {
    const o = I.getPO(r.po_uid);
    if (o) {
      if (o.status === 'received' || o.status === 'part') I.refreshPOStatus(o.uid);
      addVersion(o, { kind: 'delivery_fix', user, reason, changes: [`Delivery of ${r.receive_date}: ${changes.join('; ')}`], before: snapshot(o), after: snapshot(I.getPO(o.uid)) });
    }
  }
  audit({ user, action: `Corrected delivery from ${r.supplier_name} ${r.receive_date}: ${changes.join('; ')}`, table: 'inv_receipts', recordUid: receiptUid,
    before: { total: r.total }, after: { total }, reason: txt(reason) || null });
  return I.getReceipt(receiptUid);
}

// Orders changed after sending whose amended version has not been sent to the supplier yet.
export function amendedNotSent() {
  return db().all("SELECT * FROM po_orders WHERE version > 1 AND amended_at IS NOT NULL AND amend_sent_at IS NULL AND status IN ('sent','part') ORDER BY amended_at DESC");
}
