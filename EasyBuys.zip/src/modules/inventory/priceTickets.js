// 1.0.0 Price tickets: many products on an A4 sheet, or one under another on an 80 mm roll – the price big, the name,
// unit, shop / date and a small barcode small. Sizes and what shows are set before printing; cut along the dotted lines.
import { db } from '../../db/connection.js';
import { AppError, dateStr, getSetting, setSetting } from '../../services/core.js';
import { barcodeSvg } from '../../services/barcodeSvg.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const esc = (t) => String(t === null || t === undefined ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const I = () => require('./service.js');

// The ticket design: the ticket size and paper, the space between lines and around the edge, and the items on it –
// each can be added or removed, moved up or down, made bigger or smaller, bold, or put on the same line as the one
// above. Kept on this device; "Use on every device" shares it as the shop's design.
// A4: as many tickets as fit; 80 mm: a roll for the receipt printer, one under another.
export const ITEM_KINDS = {
  name: { label: 'Product name', text: true },
  price: { label: 'Price', text: true },
  unit: { label: 'Unit (per kg, each…)', text: true },
  shop: { label: 'Shop', text: true },
  date: { label: 'Date', text: true },
  code: { label: 'Product code', text: true },
  barcode: { label: 'Barcode', text: false },
  barnum: { label: 'Barcode number', text: true },
  text: { label: 'My own words (e.g. SPECIAL)', text: true },
};
export const DEFAULT_ITEMS = [
  { key: 'name', on: true, size: 7, bold: true },
  { key: 'price', on: true, size: 20, bold: true },
  { key: 'unit', on: true, size: 5.5 },
  { key: 'shop', on: true, size: 5.5, inline: true },
  { key: 'date', on: true, size: 5.5, inline: true },
  { key: 'barcode', on: true, height: 5 },
  { key: 'barnum', on: true, size: 5 },
  { key: 'code', on: false, size: 5 },
  { key: 'text', on: false, size: 7, bold: true, text: 'SPECIAL' },
];
export const PRESETS = {
  small: { label: 'Small', w: 38, h: 23, price: 16, name: 6.5, small: 5, barH: 4.5 },
  medium: { label: 'Medium', w: 48, h: 28, price: 20, name: 7, small: 5.5, barH: 5 },
  large: { label: 'Large', w: 64, h: 35, price: 28, name: 8.5, small: 6, barH: 6 },
};
export const PAPERS = { A4: { label: 'A4 sheet', width: 210, height: 297, margin: 8 }, '80mm': { label: '80 mm roll', width: 80, height: null, margin: 4 } };
const LKEY = 'ticket_layout';
const clamp = (v, lo, hi, d) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
// a preset's sizes put onto the items
export function sizedItems(items, p) {
  return items.map((it) => (it.key === 'price' ? { ...it, size: p.price } : it.key === 'name' ? { ...it, size: p.name } : it.key === 'barcode' ? { ...it, height: p.barH } : ITEM_KINDS[it.key] && ITEM_KINDS[it.key].text && it.key !== 'text' ? { ...it, size: it.key === 'barnum' ? Math.max(4, p.small - 0.5) : p.small } : it));
}
export function defaultLayout() {
  return { paper: 'A4', preset: 'medium', w: PRESETS.medium.w, h: PRESETS.medium.h, gap: 0.4, pad: 1, border: true, items: sizedItems(DEFAULT_ITEMS, PRESETS.medium) };
}
export function cleanLayout(l = {}) {
  const d = defaultLayout();
  const x = { ...d, ...(l || {}) };
  // older saved layouts (price / name / small / bar / showUnit …) become items
  let items = Array.isArray(x.items) && x.items.length ? x.items : DEFAULT_ITEMS.map((it) => ({ ...it }));
  if (!(Array.isArray(l && l.items) && l.items.length) && l && (l.price || l.name || l.small || l.barH || l.bar !== undefined || l.showUnit !== undefined || l.showShop !== undefined || l.showDate !== undefined)) {
    items = sizedItems(DEFAULT_ITEMS, { price: l.price || PRESETS.medium.price, name: l.name || PRESETS.medium.name, small: l.small || PRESETS.medium.small, barH: l.barH || PRESETS.medium.barH })
      .map((it) => ({ ...it, on: it.key === 'unit' ? l.showUnit !== false : it.key === 'shop' ? l.showShop !== false : it.key === 'date' ? l.showDate !== false : (it.key === 'barcode' || it.key === 'barnum') ? l.bar !== false : it.on }));
  }
  const seen = new Set();
  items = items.filter((it) => it && ITEM_KINDS[it.key] && !seen.has(it.key) && seen.add(it.key)).map((it) => ({
    key: it.key, on: it.on !== false,
    ...(ITEM_KINDS[it.key].text ? { size: clamp(it.size, 4, 60, 6), bold: !!it.bold, inline: !!it.inline } : { height: clamp(it.height, 3, 25, 5) }),
    ...(it.key === 'text' ? { text: String(it.text || '').slice(0, 30) } : {}),
  }));
  for (const k of Object.keys(ITEM_KINDS)) if (!seen.has(k)) items.push({ ...DEFAULT_ITEMS.find((i) => i.key === k), on: false });
  return { paper: PAPERS[x.paper] ? x.paper : 'A4', preset: PRESETS[x.preset] ? x.preset : 'custom', w: clamp(x.w, 20, 72, d.w), h: clamp(x.h, 12, 100, d.h),
    gap: clamp(x.gap, 0, 5, d.gap), pad: clamp(x.pad, 0, 6, d.pad), border: x.border !== false, items };
}
export function applyPreset(layout, key) {
  const p = PRESETS[key]; const L = cleanLayout(layout);
  return p ? cleanLayout({ ...L, preset: key, w: p.w, h: p.h, items: sizedItems(L.items, p) }) : L;
}
export function moveItem(layout, key, dir) {
  const L = cleanLayout(layout); const i = L.items.findIndex((x) => x.key === key); const j = i + (dir < 0 ? -1 : 1);
  if (i < 0 || j < 0 || j >= L.items.length) return L;
  const items = L.items.slice(); [items[i], items[j]] = [items[j], items[i]];
  return { ...L, items, preset: 'custom' };
}
export function setItem(layout, key, change) {
  const L = cleanLayout(layout);
  return cleanLayout({ ...L, preset: 'custom', items: L.items.map((x) => (x.key === key ? { ...x, ...change } : x)) });
}
export function savedLayout() {
  try {
    const mine = JSON.parse(getSetting(LKEY, 'null'));
    if (mine) return cleanLayout(mine);
    const shop = require('../../services/core.js').getShared('ticket_layout_shared', null);
    return shop ? cleanLayout(shop) : defaultLayout();
  } catch (e) { return defaultLayout(); }
}
export function saveLayout(l) { const c = cleanLayout(l); setSetting(LKEY, JSON.stringify(c)); return c; }
export function shareLayout(user, l) {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner sets the design for every device.');
  const c = cleanLayout(l); require('../../services/core.js').setShared('ticket_layout_shared', c); return c;
}
// how many fit: columns across the paper, rows down an A4 page
export function fit(layout) {
  const L = cleanLayout(layout); const P = PAPERS[L.paper];
  const cols = Math.max(1, Math.floor((P.width - P.margin * 2 + 0.01) / L.w));
  const rows = P.height ? Math.max(1, Math.floor((P.height - P.margin * 2 + 0.01) / L.h)) : null;
  return { cols, rows, perPage: rows ? cols * rows : null };
}
// kept for older callers: the old sizes map onto the presets
export const SIZES = Object.fromEntries(Object.entries(PRESETS).map(([k, v]) => { const f = fit({ paper: 'A4', w: v.w, h: v.h }); return [k, { label: `${v.label} – ${f.perPage} a page`, cols: f.cols, rows: f.rows }]; }));
const UNIT = { each: 'each', kg: 'per kg', g: 'per g', litre: 'per litre', pack: 'per pack', carton: 'per carton', bottle: 'per bottle', dozen: 'per dozen', bag: 'per bag', tray: 'per tray' };
export const unitText = (u) => UNIT[String(u || 'each').toLowerCase()] || (u ? `per ${u}` : 'each');

// The tickets for a shop: [{ itemUid, copies }] → the ticket details (price of THAT shop).
export function ticketRows(shopCode, list = []) {
  const out = [];
  for (const x of list) {
    const it = I().itemAtShop(x.itemUid, shopCode);
    if (!it) continue;
    const n = Math.max(1, Math.min(200, Math.round(Number(x.copies) || 1)));
    const barcode = String(it.barcode || '').split(',').map((b) => b.trim()).filter(Boolean)[0] || '';
    for (let i = 0; i < n; i += 1) out.push({ itemUid: it.uid, name: it.name, price: Number(it.shopPrice) || 0, unit: unitText(it.unit), barcode, code: it.code });
  }
  return out;
}
// The page(s) to print: { html, size: { width, height } in points, pages, perPage }.
export function ticketsDoc(shopCode, list, layout0) {
  const raw = typeof layout0 === 'string' ? applyPreset(defaultLayout(), layout0) : layout0 || savedLayout();
  const L = raw && raw.preset && PRESETS[raw.preset] && !(Array.isArray(raw.items) && raw.items.length) && !raw.price ? applyPreset({ ...defaultLayout(), paper: raw.paper || 'A4' }, raw.preset) : cleanLayout(raw);
  const P = PAPERS[L.paper];
  const rows = ticketRows(shopCode, list);
  need(rows.length, 'Add the products first.');
  need(rows.every((r) => r.price > 0), `No selling price at ${shopCode} for: ${[...new Set(rows.filter((r) => !(r.price > 0)).map((r) => r.name))].slice(0, 5).join(', ')}. Set it first.`);
  const f = fit(L);
  const date = dateStr().slice(5).split('-').reverse().join('/');
  const barW = Math.min(L.w - 2 * L.pad - 1, Math.max(16, L.w * 0.72));
  const CLS = { name: 'n', price: 'p', unit: 'u', shop: 'u', date: 'u', code: 'u', barnum: 'bn', text: 'x' };
  const valueOf = (it, r) => ({ name: r.name, price: `$${r.price.toFixed(2)}`, unit: r.unit, shop: shopCode, date, code: r.code, barnum: r.barcode || r.code, text: it.text || '' }[it.key]);
  const cell = (r) => {
    const lines = [];
    for (const it of L.items) {
      if (!it.on) continue;
      if (it.key === 'barcode') { if (r.barcode) lines.push({ html: `<div class="b">${barcodeSvg(r.barcode, { width: barW, height: it.height, text: false })}</div>` }); continue; }
      const v = valueOf(it, r);
      if (!v) continue;
      const span = `<span style="font-size:${it.size}pt;${it.bold ? 'font-weight:800;' : ''}">${esc(v)}</span>`;
      const last = lines[lines.length - 1];
      if (it.inline && last && last.text) { last.parts.push(span); continue; }
      lines.push({ text: true, cls: CLS[it.key] || 'u', parts: [span] });
    }
    return `<div class="t">${lines.map((l) => (l.text ? `<div class="${l.cls}">${l.parts.join(' · ')}</div>` : l.html)).join('')}</div>`;
  };
  const per = f.perPage || rows.length;
  const pages = [];
  for (let i = 0; i < rows.length; i += per) pages.push(`<div class="pg">${rows.slice(i, i + per).map(cell).join('')}</div>`);
  const roll = !P.height;
  const pageH = roll ? Math.ceil(rows.length / f.cols) * L.h + P.margin * 2 : P.height;
  const mm = 72 / 25.4;
  const sz = (k) => (L.items.find((x) => x.key === k) || {}).size || 6;
  const html = `<!doctype html><html><head><meta charset="utf-8"><style>
    @page { size: ${P.width}mm ${pageH}mm; margin: ${P.margin}mm; }
    * { box-sizing: border-box; } body { margin: 0; font-family: Arial, Helvetica, sans-serif; color: #000; }
    .pg { display: grid; grid-template-columns: repeat(${f.cols}, ${L.w}mm); grid-auto-rows: ${L.h}mm; ${roll ? 'justify-content: center;' : 'page-break-after: always;'} }
    .pg:last-child { page-break-after: auto; }
    .t { ${L.border ? 'border: 0.2mm dashed #bbb;' : ''} padding: ${L.pad}mm; overflow: hidden; display: flex; flex-direction: column; justify-content: center; align-items: center; gap: ${L.gap}mm; text-align: center; }
    .t > div { flex-shrink: 0; line-height: 1.05; }
    .n { font-size: ${sz('name')}pt; width: 100%; max-height: 2.3em; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
    .p { font-size: ${sz('price')}pt; line-height: 0.95; }
    .u { font-size: ${sz('unit')}pt; color: #333; }
    .b svg { display: block; margin: 0 auto; } .bn { font-size: ${sz('barnum')}pt; letter-spacing: 0.3pt; }
  </style></head><body>${pages.join('')}</body></html>`;
  return { html, size: { width: Math.round(P.width * mm), height: Math.round(pageH * mm) }, pages: pages.length, perPage: f.perPage, cols: f.cols, layout: L };
}
export function ticketsHtml(shopCode, list, opts = {}) {
  const preset = opts.size || 'medium';
  return ticketsDoc(shopCode, list, opts.layout || setItem(applyPreset(defaultLayout(), preset), 'date', { on: opts.showDate !== false })).html;
}
// The list being built (kept per device so it survives closing the screen) and the products whose price changed.
export function savedList() { try { return JSON.parse(getSetting('ticket_list', '[]')) || []; } catch (e) { return []; } }
export function saveList(list) { setSetting('ticket_list', JSON.stringify((list || []).slice(0, 500))); }
export function changedPrices(shopCode, { days = 7 } = {}) {
  const since = (() => { const t = new Date(`${dateStr()}T12:00:00`); t.setDate(t.getDate() - days); return t.toISOString().slice(0, 10); })();
  let codes = [];
  try { codes = db().all("SELECT DISTINCT code FROM product_changes WHERE shop_code = ? AND kind = 'price' AND change_date >= ?", [shopCode, since]).map((r) => r.code); } catch (e) { codes = []; }
  const uids = new Set(codes.map((c) => I().findItem(c)).filter(Boolean).map((it) => it.uid));
  // prices changed in the app for this shop (the app keeps the prices after go-live)
  try { db().all('SELECT item_uid FROM inv_item_shops WHERE shop_code = ? AND price IS NOT NULL AND substr(updated_at, 1, 10) >= ?', [shopCode, since]).forEach((r) => uids.add(r.item_uid)); } catch (e) { /* none */ }
  return [...uids].map((u) => ({ itemUid: u, copies: 1 }));
}
