// 1.0.0 Cross-checks of each product from what the invoices say – another way of checking the products in Aronium:
//   • VAT: each invoice line that shows how it is taxed (zero rated, exempt / VAT free, 12.5%) is kept as evidence;
//     a product whose invoices disagree with the app or with Aronium is flagged.
//   • Suppliers: who the product really comes from (the invoices) against its main supplier; products with none.
//   • Prices: Aronium's selling price against the cost on the latest invoice (with VAT): the same as cost, or lower.
//   • Barcodes: scanned at the stock take but missing in Aronium (to add there – the app never changes Aronium).
import { db } from '../../db/connection.js';
import { getShared, setShared, stamp, dateStr, addDays, audit, AppError } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const need = (c, m) => { if (!c) throw new AppError(m); };
const I = () => require('./service.js');
export const VAT_WORD = { standard: 'VAT 12.5%', zero: 'Zero rated', exempt: 'VAT exempt / non-VAT' };
const charged = (v) => v === 'standard';

// ---------------------------------------------------------------- VAT from the invoices
// How one invoice line says it is taxed: 'zero' | 'exempt' | 'standard' | null (not shown).
export function lineVat(raw) {
  const s = ` ${txt(raw).toLowerCase()} `;
  if (/\b(zero[\s-]*rated|zero|z\/r|zr)\b|\s0(\.0+)?\s?%/.test(s)) return 'zero';
  if (/\b(exempt|vat[\s-]*free|non[\s-]*vat|no[\s-]*vat|ex[\s-]*vat)\b/.test(s)) return 'exempt';
  if (/\b12\.5\s?%|\bvat\s*12\.5\b|\bvat\s*incl/.test(s)) return 'standard';
  return null;
}
// Kept from every invoice read: { itemUid: { vat, invoiceNo, supplier, date, raw, seen } } (the newest per product).
export function recordVatEvidence(result) {
  if (!result || !Array.isArray(result.lines)) return 0;
  const ev = getShared('vat_evidence', null) || {};
  let n = 0;
  // the invoice shows no VAT at all from a VAT-registered supplier: every line is zero rated or exempt
  const noVat = result.vat !== null && result.vat !== undefined && Number(result.vat) === 0 && result.total > 0;
  for (const l of result.lines) {
    if (!l || !l.itemUid) continue;
    const v = lineVat(l.raw) || (noVat ? 'nonvat' : null);
    if (!v) continue;
    ev[l.itemUid] = { vat: v, invoiceNo: txt(result.invoiceNo) || null, supplier: txt(result.supplierName) || null, date: txt(result.invoiceDate) || dateStr(), raw: txt(l.raw).slice(0, 80), seen: ((ev[l.itemUid] && ev[l.itemUid].vat === v ? ev[l.itemUid].seen : 0) || 0) + 1 };
    n += 1;
  }
  if (n) setShared('vat_evidence', ev);
  return n;
}
// Products where the invoices say one thing and the app or Aronium another.
export function invoiceVatMismatches() {
  const ev = getShared('vat_evidence', null) || {};
  const out = [];
  // 1.0.0 every active product in one read (was one read per product with invoice VAT evidence)
  const entries = Object.entries(ev);
  const byUid = entries.length > 20 ? new Map(safe(() => db().all('SELECT uid, code, name, vat_type, aronium_vat FROM inv_items WHERE active = 1'), []).map((x) => [x.uid, x])) : null;
  for (const [uid, e] of entries) {
    const it = byUid ? byUid.get(uid) || null : safe(() => db().get('SELECT uid, code, name, vat_type, aronium_vat FROM inv_items WHERE uid = ? AND active = 1', [uid]), null);
    if (!it) continue;
    const invCharged = e.vat === 'standard';
    const appOff = e.vat === 'nonvat' ? charged(it.vat_type) : e.vat === 'standard' ? !charged(it.vat_type) : it.vat_type !== e.vat && !(e.vat === 'exempt' && it.vat_type === 'exempt');
    const arOff = it.aronium_vat && it.aronium_vat !== 'none' ? charged(it.aronium_vat) !== invCharged : false;
    if (appOff || arOff) out.push({ ...it, invoice: e, appOff, aroniumOff: arOff, text: `Invoice ${e.invoiceNo || ''} (${e.supplier || 'supplier'}) says ${e.vat === 'nonvat' ? 'no VAT' : VAT_WORD[e.vat]}; app: ${VAT_WORD[it.vat_type] || it.vat_type}${it.aronium_vat ? `; Aronium: ${VAT_WORD[it.aronium_vat] || it.aronium_vat}` : ''}` });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

// ---------------------------------------------------------------- suppliers
export function supplierCrossCheck({ days = 180 } = {}) {
  if (!has('inv_item_suppliers')) return { differs: [], none: [] };
  const since = addDays(dateStr(), -days);
  const seen = new Map();
  for (const r of safe(() => db().all("SELECT x.item_uid, x.supplier_uid, s.name FROM inv_item_suppliers x JOIN ap_suppliers s ON s.uid = x.supplier_uid WHERE x.active = 1 AND x.last_date >= ?", [since]), [])) {
    seen.set(r.item_uid, (seen.get(r.item_uid) || []).concat([{ uid: r.supplier_uid, name: r.name }]));
  }
  const items = safe(() => db().all('SELECT i.uid, i.code, i.name, i.supplier_uid, s.name AS main FROM inv_items i LEFT JOIN ap_suppliers s ON s.uid = i.supplier_uid WHERE i.active = 1 AND i.removed_at IS NULL'), []);
  const differs = items.filter((i) => i.supplier_uid && seen.has(i.uid) && !seen.get(i.uid).some((x) => x.uid === i.supplier_uid))
    .map((i) => ({ ...i, invoices: seen.get(i.uid).map((x) => x.name), text: `Main supplier ${i.main}, but invoices come from ${seen.get(i.uid).map((x) => x.name).join(', ')}` }));
  const none = items.filter((i) => !i.supplier_uid && !seen.has(i.uid));
  return { differs, none };
}
export function useInvoiceSupplier(user, itemUid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner changes the main supplier.');
  const r = safe(() => db().get('SELECT supplier_uid FROM inv_item_suppliers WHERE item_uid = ? AND active = 1 ORDER BY last_date DESC LIMIT 1', [itemUid]), null);
  need(r, 'No invoice from a supplier for this product yet.');
  db().run("UPDATE inv_items SET supplier_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [r.supplier_uid, stamp(), require('../../services/core.js').deviceId(), itemUid]);
  audit({ user, action: 'Main supplier set from the invoices', table: 'inv_items', recordUid: itemUid });
  });
}

// ---------------------------------------------------------------- selling price vs the invoice cost
// Aronium's selling price at each shop against the latest invoice cost in the app (with VAT when the product has it).
export function priceVsCost() {
  if (!has('product_watch')) return { same: [], below: [] };
  const rows = safe(() => require('../../services/productWatch.js').watchRows(), []).filter((r) => r.on && !r.removed && !r.service && r.price > 0);
  const same = []; const below = [];
  // 1.0.0 every active product in one read (was one read per product and shop)
  const byCode = new Map();
  safe(() => db().all('SELECT uid, name, cost, vat_type, code FROM inv_items WHERE active = 1 ORDER BY rowid'), []).forEach((x) => { const k = String(x.code); if (!byCode.has(k)) byCode.set(k, { uid: x.uid, name: x.name, cost: x.cost, vat_type: x.vat_type }); });
  // round 2: the VAT rate read once (it was read and unpacked from the settings for every product), the same sum as incVat
  const rate = I().vatRate();
  const incVat = (cost, vatType) => r2(Number(cost || 0) * (vatType === 'zero' || vatType === 'exempt' ? 1 : 1 + rate / 100));
  for (const r of rows) {
    const it = r.code === null || r.code === undefined ? null : byCode.get(String(r.code)) || null;
    if (!it || !(it.cost > 0)) continue;
    const costInc = r2(incVat(it.cost, it.vat_type || 'standard'));
    const row = { itemUid: it.uid, code: r.code, name: it.name || r.name, shop: r.shop, price: r2(r.price), cost: costInc };
    if (Math.abs(r.price - costInc) < 0.005) same.push(row);
    else if (r.price < costInc) below.push(row);
  }
  return { same, below };
}

// ---------------------------------------------------------------- barcodes to add in Aronium
// A barcode scanned at the stock take that is not in the app / Aronium, put on an existing product: kept in the app
// (so the next scan finds it) and listed to add in Aronium.
export function barcodeFixes() { return (getShared('barcode_fixes', null) || {}).list || []; }
export function attachBarcode(user, itemUid, code) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const c = txt(code).replace(/\s+/g, '');
  need(/^[0-9A-Za-z-]{4,40}$/.test(c), 'That barcode does not look right.');
  const it = I().getItem(itemUid);
  need(it, 'Choose the product.');
  const other = safe(() => require('./scan.js').findByBarcode(c), null);
  need(!other || other.uid === it.uid, `That barcode is already on ${other && other.name}.`);
  const list = (it.barcode ? String(it.barcode).split(',') : []).map((x) => x.trim()).filter(Boolean);
  if (!list.includes(c)) db().run("UPDATE inv_items SET barcode = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [list.concat([c]).join(','), stamp(), require('../../services/core.js').deviceId(), it.uid]);
  const fx = barcodeFixes().filter((x) => !(x.code === c));
  fx.push({ code: c, itemUid: it.uid, itemCode: it.code, name: it.name, by: user.name, at: stamp(), done: false });
  setShared('barcode_fixes', { list: fx.slice(-500) });
  audit({ user, action: `Barcode ${c} added to ${it.name} (add it in Aronium too)`, table: 'inv_items', recordUid: it.uid });
  return I().getItem(it.uid);
  });
}
// Products with no barcode at all (counted and found by name). A shop barcode can be made for them: EAN-13 in the
// in-store range (starting 21), unique, put on the product here and listed to add in Aronium (the update file carries
// it too) – then Aronium can print the shelf / product labels.
export function noBarcode() {
  return safe(() => db().all("SELECT uid, code, name, group_name FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (barcode IS NULL OR trim(barcode) = '') ORDER BY group_name, name"), []);
}
export function ean13Check(d12) {
  const s = String(d12).split('').reduce((t, c, i) => t + Number(c) * (i % 2 ? 3 : 1), 0);
  return String((10 - (s % 10)) % 10);
}
export function makeShopBarcode(user, itemUid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const it = I().getItem(itemUid);
  need(it, 'Choose the product.');
  let n = Number((getShared('shop_barcode_seq', null) || {}).n) || 0;
  for (let tries = 0; tries < 50; tries += 1) {
    n += 1;
    const d12 = `21${String(n).padStart(10, '0')}`;
    const code = d12 + ean13Check(d12);
    if (safe(() => require('./scan.js').findByBarcode(code), null)) continue;
    setShared('shop_barcode_seq', { n });
    return attachBarcode(user, itemUid, code);
  }
  throw new AppError('Could not make a free barcode – try again.');
  });
}
export function barcodeFixDone(user, code) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  setShared('barcode_fixes', { list: barcodeFixes().map((x) => (x.code === code ? { ...x, done: true, doneBy: user ? user.name : null } : x)) });
  });
}

// ---------------------------------------------------------------- Home warnings (the people who look after products)
export function productCheckAlerts(user) {
  const out = [];
  const vat = invoiceVatMismatches();
  if (vat.length) out.push({ id: `pc-vat-${vat.length}`, level: 'warning', text: `${vat.length} product${vat.length === 1 ? ':' : 's:'} the invoice VAT differs from the app or Aronium`, sub: vat.slice(0, 3).map((x) => `${x.name} – ${x.text}`).join('\n'), nav: { screen: 'ProductChecks', params: { tab: 'vat' } } });
  const p = priceVsCost();
  if (p.below.length) out.push({ id: `pc-below-${p.below.length}`, level: 'warning', notify: true, text: `${p.below.length} product${p.below.length === 1 ? ' sells' : 's sell'} in Aronium below the invoice cost`, sub: p.below.slice(0, 3).map((x) => `${x.shop} ${x.name} $${x.price.toFixed(2)} (cost $${x.cost.toFixed(2)})`).join(' · '), nav: { screen: 'ProductChecks', params: { tab: 'price' } } });
  if (p.same.length) out.push({ id: `pc-same-${p.same.length}`, level: 'warning', text: `${p.same.length} product${p.same.length === 1 ? ' sells' : 's sell'} in Aronium at the cost price (no profit)`, sub: p.same.slice(0, 3).map((x) => `${x.shop} ${x.name} $${x.price.toFixed(2)}`).join(' · '), nav: { screen: 'ProductChecks', params: { tab: 'price' } } });
  const bf = barcodeFixes().filter((x) => !x.done);
  if (bf.length) out.push({ id: `pc-bc-${bf.length}`, level: 'info', text: `${bf.length} barcode${bf.length === 1 ? '' : 's'} to add in Aronium (found at the stock take)`, nav: { screen: 'ProductChecks', params: { tab: 'barcodes' } } });
  return out;
}
