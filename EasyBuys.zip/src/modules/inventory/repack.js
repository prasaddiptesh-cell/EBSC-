// 1.0.0 Repacking: bought in bulk, packed in the shop and sold in packs (a 25 kg bag of rice into 1 kg packets,
// a carton of sweets into small bags …). One record moves the stock: the bulk product goes down by what was used,
// the packed product goes up by how many packs were made, and the packs' cost is worked out from the bulk's cost
// (+ the bag / label cost per pack). What one bulk usually makes is learnt per pair, and a pack-up that makes clearly
// fewer than usual (spilt, short weight, taken) is flagged to the managers.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
const I = () => require('./service.js');
const PAIRS = 'repack_pairs';

// The pairs set up (and learnt): { 'fromUid>toUid': { per, made, used, packCost } } – per = packs from one bulk.
export function pairs() { const p = getShared(PAIRS, null); return p && typeof p === 'object' ? p : {}; }
export function pairOf(fromUid, toUid) { return pairs()[`${fromUid}>${toUid}`] || null; }
export function savePair(user, { fromUid, toUid, per, packCost }) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner sets up repacking.');
  const a = I().getItem(fromUid); const b = I().getItem(toUid);
  need(a && b && a.uid !== b.uid, 'Choose the bulk product and the packed product (two different ones).');
  const n = Number(String(per).replace(/[,\s]/g, ''));
  need(Number.isFinite(n) && n > 0 && n <= 100000, 'How many packs does one bulk make?');
  const pc = packCost === '' || packCost === undefined || packCost === null ? 0 : Number(packCost);
  need(Number.isFinite(pc) && pc >= 0 && pc < 1000, 'The bag / label cost per pack is not a number.');
  setShared(PAIRS, { ...pairs(), [`${a.uid}>${b.uid}`]: { ...(pairOf(a.uid, b.uid) || {}), per: q3(n), packCost: r4(pc) } });
  audit({ user, action: `Repacking: 1 ${a.name} makes ${q3(n)} × ${b.name}${pc ? ` (+ $${pc.toFixed(2)} per pack for bags / labels)` : ''}`, table: 'inv_items', recordUid: a.uid });
  return pairOf(a.uid, b.uid);
  });
}
export function listPairs() {
  return Object.entries(pairs()).map(([k, v]) => { const [f, t] = k.split('>'); return { from: I().getItem(f), to: I().getItem(t), ...v }; }).filter((x) => x.from && x.to);
}

// One pack-up: used (of the bulk, in its own unit – 1 bag, or 0.5 bag) → made (packs).
export function repack(user, { shopCode, fromUid, toUid, used, made, date, note } = {}) {
  requirePerm(user, ['inventory_manage', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  need(txt(shopCode), 'Choose the shop.');
  const a = I().getItem(fromUid); const b = I().getItem(toUid);
  need(a && b && a.uid !== b.uid, 'Choose the bulk product and the packed product.');
  const u = q3(used); const m = q3(made);
  need(u > 0 && u < 100000, 'How much of the bulk was used?');
  need(m > 0 && m < 1000000, 'How many packs were made?');
  const d = txt(date) || dateStr();
  I().notFrozen(a.uid, shopCode); I().notFrozen(b.uid, shopCode);
  const have = I().stockOf(a.uid, shopCode);
  need(have + 1e-9 >= u || ['owner', 'admin'].includes(user.role), `Only ${have} ${a.unit || ''} of ${a.name} in stock at ${shopCode}. Receive it first, or ask the admin.`);
  const p = pairOf(a.uid, b.uid) || {};
  const packCost = Number(p.packCost) || 0;
  const unitCost = r4((u * (Number(a.cost) || 0)) / m + packCost);
  const id = uuid('RP');
  I().addMove({ itemUid: a.uid, shopCode, date: d, type: 'repack_out', qty: -u, unitCost: a.cost, refType: 'repack', refUid: id, reason: `Packed into ${m} × ${b.name}`, note: txt(note) || null, user });
  I().addMove({ itemUid: b.uid, shopCode, date: d, type: 'repack_in', qty: m, unitCost, refType: 'repack', refUid: id, reason: `Packed from ${u} × ${a.name}`, note: txt(note) || null, user });
  // the packs' cost price follows the bulk (+ bags / labels)
  if (Math.abs((Number(b.cost) || 0) - unitCost) > 0.00005) db().run("UPDATE inv_items SET cost = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [unitCost, stamp(), deviceId(), b.uid]);
  // what one bulk makes: learnt (running totals); a pack-up clearly short of it is flagged
  const expected = p.per ? q3(u * p.per) : (p.used > 0 ? q3(u * (p.made / p.used)) : null);
  const short = expected !== null && m < expected * 0.97 - 1e-9 ? q3(expected - m) : 0;
  setShared(PAIRS, { ...pairs(), [`${a.uid}>${b.uid}`]: { ...p, used: q3((p.used || 0) + u), made: q3((p.made || 0) + m), last: d } });
  const log = (getShared('repack_short', null) || {}).list || [];
  if (short) { log.push({ id, shop: shopCode, date: d, from: a.name, to: b.name, used: u, made: m, expected, short, cost: unitCost, by: user.name }); setShared('repack_short', { list: log.slice(-100) }); }
  // 1.0.0 build 4: with no "packs per bulk" figure set, a pack-up cannot be checked – it is flagged, never let through quietly
  if (!(Number(p.per) > 0)) {
    const un = (getShared('repack_unchecked', null) || {}).list || [];
    un.push({ id, shop: shopCode, date: d, from: a.name, to: b.name, fromUid: a.uid, toUid: b.uid, used: u, made: m, by: user.name });
    setShared('repack_unchecked', { list: un.slice(-100) });
  }
  audit({ user, action: `Repacked ${u} × ${a.name} into ${m} × ${b.name} at ${shopCode} (cost $${unitCost.toFixed(4)} each)${short ? ` – ${short} fewer than usual (${expected})` : ''}`, table: 'inv_moves', recordUid: id });
  return { id, unitCost, expected, short };
  });
}
// Pack-ups that made fewer than usual (the last 14 days), for the managers.
export function repackAlerts() {
  const since = (() => { const t = new Date(`${dateStr()}T12:00:00`); t.setDate(t.getDate() - 14); return t.toISOString().slice(0, 10); })();
  const list = ((getShared('repack_short', null) || {}).list || []).filter((x) => x.date >= since);
  const out = list.length ? [{ id: `repack-short-${list.length}`, level: 'warning', text: `${list.length} pack-up${list.length === 1 ? '' : 's'} made fewer packs than usual`, sub: list.slice(-3).map((x) => `${x.shop} ${x.date}: ${x.used} × ${x.from} → ${x.made} (usually ${x.expected}) by ${x.by}`).join('\n'), nav: { screen: 'Repack', params: {} } }] : [];
  // pack-ups of a pair with no "packs per bulk" figure (until a manager sets it)
  const un = ((getShared('repack_unchecked', null) || {}).list || []).filter((x) => x.date >= since && !(Number((pairOf(x.fromUid, x.toUid) || {}).per) > 0));
  if (un.length) out.push({ id: `repack-unchecked-${un.length}`, level: 'warning', text: `${un.length} pack-up${un.length === 1 ? '' : 's'} could not be checked – set how many packs one bulk makes`, sub: un.slice(-3).map((x) => `${x.shop} ${x.date}: ${x.used} × ${x.from} → ${x.made} × ${x.to} by ${x.by}`).join('\n'), nav: { screen: 'Repack', params: {} } });
  return out;
}
// Pack-ups that made fewer packs than usual in a period, at the packs' cost (for the shrinkage report).
export function repackShortfall({ shopCode, from, to }) {
  const list = ((getShared('repack_short', null) || {}).list || []).filter((x) => x.shop === shopCode && x.date >= from && x.date <= to);
  return { times: list.length, qty: q3(list.reduce((s, x) => s + (Number(x.short) || 0), 0)), value: Math.round(list.reduce((s, x) => s + (Number(x.short) || 0) * (Number(x.cost) || 0), 0) * 100) / 100 };
}
