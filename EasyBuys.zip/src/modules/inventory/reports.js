// Inventory, purchase order and stock take reports (every shop separately, plus totals).
import { stamp } from '../../services/core.js';
import { db } from '../../db/connection.js';
import { listShops } from '../admin/service.js';
import * as I from './service.js';
import { poVersions } from './poAmend.js';

const { $, r2 } = I;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const fq = (q) => { const n = Number(q) || 0; return Number.isInteger(n) ? String(n) : String(Math.round(n * 1000) / 1000); };
const shops = () => listShops().filter((s) => s.active);
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});

// The purchase order as a document (PDF to share by Viber / email, or print). v3.9.3 laid out like an invoice: quantity and
// unit as ordered (cartons or singles), unit price, VAT per line, amount; then number of items, subtotal, VAT and total.
// prices: false leaves the prices off (a plain list for the supplier to pick from).
// v3.9.5 laid out like the suppliers' own tax invoices (Punjas, FMF, Ram Sami…): their code next to ours, quantity and
// unit, unit price, amount before VAT, VAT and amount with VAT on every line; a VAT summary by rate (12.5% and zero
// rated), then subtotal, VAT and total. Bill to (with our TIN), deliver to, the supplier's TIN and the payment terms
// at the top; "goods received by" at the bottom.
export function poReport(uid, { prices = true } = {}) {
  const o = I.getPO(uid);
  const shop = listShops().find((s) => s.code === o.shop_code);
  const lines = o.lines.filter((l) => l.qty > 0);
  const sup = db().get('SELECT vat_registered, tin, on_account, terms_days, pay_method, phone, email FROM ap_suppliers WHERE uid = ?', [o.supplier_uid]) || {};
  const rate = I.vatRate();
  const vatOf = (l) => { const it = l.item_uid ? I.getItem(l.item_uid) : null; return it ? it.vat_type : sup.vat_registered === 0 ? 'zero' : 'standard'; };
  const VAT_LABEL = { standard: `${fq(rate)}%`, zero: 'Zero rated', exempt: 'VAT free' };
  const theirCode = (l) => { try { const r = l.item_uid ? db().get('SELECT supplier_code FROM inv_item_suppliers WHERE item_uid = ? AND supplier_uid = ?', [l.item_uid, o.supplier_uid]) : null; return (r && r.supplier_code) || ''; } catch (e) { return ''; } };
  const rows = lines.map((l, i) => {
    const v = I.orderView(l);
    const vt = vatOf(l);
    const amount = r2(l.qty * l.unit_cost);
    const inc = I.incVat(amount, vt);
    // On a carton line the price of one item is shown too (cost prices are per item).
    return { n: i + 1, code: l.code || '', their: theirCode(l), name: `${l.name}${l.note ? ` – ${l.note}` : ''}`, qty: fq(v.qty), unit: v.unit, cost: v.carton ? `${$(v.cost)} (${$(l.unit_cost)} each)` : $(v.cost),
      amount: $(amount), vatAmt: vt === 'standard' ? $(r2(inc - amount)) : VAT_LABEL[vt] || '0.00', total: $(inc), _amount: amount, _inc: inc, _vt: vt, _v: v };
  });
  const sub = r2(rows.reduce((t, r) => t + r._amount, 0));
  // VAT worked out line by line from each product's VAT now (the same way the order total is made).
  const total = r2(rows.reduce((t, r) => t + r._inc, 0));
  const vat = r2(total - sub);
  const noVat = r2(rows.filter((r) => r._vt !== 'standard').reduce((t, r) => t + r._amount, 0));
  const std = r2(sub - noVat);
  const ctn = rows.filter((r) => r._v.carton).reduce((t, r) => t + r._v.qty, 0);
  const singles = rows.filter((r) => !r._v.carton).reduce((t, r) => t + r._v.qty, 0);
  const count = `${lines.length} item${lines.length === 1 ? '' : 's'}${ctn ? ` · ${fq(ctn)} carton${ctn === 1 ? '' : 's'}` : ''}${singles ? ` · ${fq(singles)} single${singles === 1 ? '' : 's'}` : ''}`;
  const anyTheir = rows.some((r) => r.their);
  const cols = [col('n', '#'), col('code', 'Our code')].concat(anyTheir ? [col('their', 'Your code')] : [], [col('name', 'Description'), col('qty', 'Qty', R), col('unit', 'Unit')])
    .concat(prices ? [col('cost', 'Unit price (excl. VAT)', R), col('amount', 'Amount (excl. VAT)', R), col('vatAmt', 'VAT', R), col('total', 'Amount (incl. VAT)', R)] : []);
  const totals = [{ label: 'Number of items', value: count }].concat(prices ? [
    { label: `VAT summary: ${fq(rate)}% on ${$(std)}`, value: $(vat) },
  ].concat(noVat > 0.004 ? [{ label: `VAT summary: zero rated / VAT free on ${$(noVat)}`, value: $(0) }] : []).concat([
    { label: 'Subtotal (excl. VAT)', value: $(sub) },
    { label: 'Total VAT', value: $(vat) },
    { label: 'TOTAL (incl. VAT)', value: $(total), strong: true },
  ]) : []);
  let tpl = {};
  try { tpl = require('../../services/reportTemplate.js').reportTemplate() || {}; } catch (e) { tpl = {}; }
  const terms = sup.on_account ? `On account – ${sup.terms_days || 7} days` : 'Cash / cheque on delivery';
  const how = { cheque: 'cheque', cash: 'cash', transfer: 'bank transfer', mpaisa: 'M-PAiSA' }[sup.pay_method] || sup.pay_method || '';
  return {
    kind: 'po', title: `Purchase Order ${o.po_no}`, fileName: `PO-${o.po_no}-${o.supplier_name.replace(/\s+/g, '-')}`,
    subtitle: `Easy Buys Shopping Centre · ${shop ? shop.name : o.shop_code}`,
    info: [['To (supplier)', `${o.supplier_name}${sup.tin ? ` · TIN ${sup.tin}` : ''}`], ['PO number', o.po_no], ['Order date', o.order_date], ['Deliver by', o.expected_date || ''],
      ['Bill to', `Easy Buys Shopping Centre${tpl.tin ? ` · TIN ${tpl.tin}` : ''}`], ['Deliver to', shop ? `${shop.name}${shop.address ? `, ${shop.address}` : ''}` : o.shop_code],
      ['Payment terms', `${terms}${how ? ` · paid by ${how}` : ''}`],
      ['Raised by', `${o.created_by_name || ''}${o.created_at ? ` · ${String(o.created_at).slice(0, 16)}` : ''}`],
      ['Authorised by', o.approved_by_name ? `${o.approved_by_name}${o.approved_at ? ` · ${String(o.approved_at).slice(0, 16)}` : ''} (approved in the Easy Buys app)` : 'Waiting for approval – not to be supplied yet']]
      .concat(o.signed_by_name ? [['Signed by', `${o.signed_by_name} · ${String(o.signed_at).slice(0, 16)}`]] : [])
      .concat(o.notes ? [['Note', o.notes]] : []),
    signatures: o.signature ? [{ label: `For Easy Buys: ${o.signed_by_name || ''}`, data: o.signature, at: o.signed_at || '' }] : undefined,
    approved: !['draft', 'awaiting'].includes(o.status),
    summary: [{ label: 'Items', value: String(lines.length) }].concat(prices ? [{ label: 'Total incl. VAT', value: $(total) }] : []),
    sections: [{ title: 'Please supply', columns: cols, rows: rows.map(({ _amount, _inc, _vt, _v, ...r }) => r), totals,
      note: `Please quote our order number ${o.po_no} as "Your Order No." on your tax invoice and delivery note, show subtotal, VAT and total, and give us a fiscal (VMS) tax invoice. Prices are before VAT.${rows.some((r) => r._v.carton) ? ' "ctn of 24" = one carton of 24.' : ''}` }],
  };
}

// The order after it was changed: marked AMENDED with the version and what changed, to send to the supplier again.
export function amendedPoReport(uid, { prices = false } = {}) {
  const rep = poReport(uid, { prices });
  const o = I.getPO(uid);
  const v = poVersions(uid).find((x) => x.kind !== 'delivery_fix');
  if (!v) return rep;
  return {
    ...rep, kind: 'po_amended', title: `AMENDED Purchase Order ${o.po_no}`, fileName: `${rep.fileName}-AMENDED-v${o.version}`,
    info: rep.info.concat([['Amended', `${String(v.at).slice(0, 16)} by ${v.by_name || ''} (version ${v.version})`]]),
    sections: [{ title: 'What changed', columns: [col('c', 'Change')], rows: v.changes.map((c) => ({ c })), note: 'This replaces the earlier order with the same number.' }]
      .concat(rep.sections.map((sec) => ({ ...sec, title: 'Please supply (amended)' }))),
  };
}

// A stock take as a count sheet (blind: no expected numbers) or as the result.
export function countReport(uid, { sheet = false } = {}) {
  const c = I.getCount(uid);
  const lines = c.lines;
  const s = c.summary;
  if (sheet) {
    return {
      kind: 'count_sheet', title: `Count sheet – ${c.name}`, fileName: `Count-sheet-${c.shop_code}-${c.count_date}`, subtitle: `Easy Buys Shopping Centre · ${c.shop_code} · ${c.count_date}`,
      info: [['Counted by', ''], ['Checked by', '']],
      sections: [{ title: 'Write the number counted', columns: [col('loc', 'Location'), col('code', 'Code'), col('name', 'Product'), col('unit', 'Unit'), col('count', 'Counted', R)],
        rows: lines.map((l) => ({ loc: l.location || '', code: l.code, name: l.name, unit: l.unit || '', count: '' })) }],
    };
  }
  const off = lines.filter((l) => Math.abs(l.variance) > 1e-9).sort((a, b) => a.value - b.value);
  return {
    kind: 'count', title: `Stock take – ${c.name}`, fileName: `Stock-take-${c.shop_code}-${c.count_date}`, subtitle: `Easy Buys Shopping Centre · ${c.shop_code} · ${c.count_date}`,
    approved: c.status === 'posted',
    info: [['Shop', c.shop_code], ['Count date', `${c.count_date} (${c.timing === 'before_open' ? 'before opening' : 'after closing'})`], ['Started by', c.started_by_name || ''],
      ['Counted / handed in by', c.submitted_by_name || ''], ['Approved and posted by', c.posted_by_name || '—'], ['Status', I.COUNT_STATUS[c.status]]],
    summary: [{ label: 'Products counted', value: `${s.counted} of ${s.products}` }, { label: 'Accuracy', value: s.accuracy === null ? '—' : `${s.accuracy}%` },
      { label: 'Short (loss)', value: $(s.loss), tone: 'bad' }, { label: 'Over (gain)', value: $(s.gain) }, { label: 'Net', value: $(s.net), tone: s.net < 0 ? 'bad' : undefined },
      { label: 'Stock value expected', value: $(s.expectedValue) }],
    sections: [
      { title: 'Differences (largest loss first)', columns: [col('code', 'Code'), col('name', 'Product'), col('exp', 'Expected', R), col('cnt', 'Counted', R), col('first', '1st count', R), col('var', 'Difference', R), col('val', 'Value', R)],
        rows: off.map((l) => ({ code: l.code, name: l.name, exp: fq(l.expected), cnt: l.counted === null ? 'not counted' : fq(l.counted), first: l.first_count === null ? '' : fq(l.first_count), var: `${l.variance > 0 ? '+' : ''}${fq(l.variance)}`, val: $(l.value), _tone: l.value < 0 ? 'bad' : 'warn' })) },
      { title: 'Not counted', columns: [col('code', 'Code'), col('name', 'Product'), col('exp', 'Expected', R)], rows: lines.filter((l) => l.counted === null).map((l) => ({ code: l.code, name: l.name, exp: fq(l.expected) })),
        note: c.uncounted === 'zero' ? 'Products not counted are set to 0.' : 'Products not counted are left as they are.' },
    ].concat((() => {
      // v1.0.0 other things counted (empty gas cylinders…)
      let x = [];
      try { x = require('./goLiveCount.js').countExtras(c.uid).filter((e) => e.qty !== null && e.qty !== undefined); } catch (e) { x = []; }
      return x.length ? [{ title: 'Other things counted (not products)', columns: [col('label', 'What'), col('qty', 'Counted', R), col('by', 'By')], rows: x.map((e) => ({ label: e.label, qty: fq(e.qty), by: e.by || '' })) }] : [];
    })()),
  };
}

export const REPORTS = [
  { id: 'inv_valuation', group: 'Inventory', icon: '📦', title: 'Stock valuation', desc: 'Stock on hand and its value at cost, per shop and group', perm: 'inventory_view',
    build(from, to) {
      const per = shops().map((s) => ({ s, rows: I.stockList({ shopCode: s.code, today: to, limit: 100000 }) }));
      const groups = {};
      per.forEach(({ s, rows }) => rows.forEach((r) => { const g = (groups[`${s.code}|${r.group_name || '—'}`] = groups[`${s.code}|${r.group_name || '—'}`] || { shop: s.code, group: r.group_name || '—', n: 0, value: 0, retail: 0 }); g.n += 1; g.value += r.value; g.retail += Math.max(0, r.on_hand) * r.shop_price; }));
      return base('inv_valuation', 'Stock Valuation', to, to, {
        summary: per.map(({ s, rows }) => ({ label: s.code, value: $(rows.reduce((t, r) => t + r.value, 0)) })).concat([{ label: 'All shops', value: $(per.reduce((t, p) => t + p.rows.reduce((u, r) => u + r.value, 0), 0)) }]),
        sections: [{ title: 'By shop and group', columns: [col('shop', 'Shop'), col('group', 'Group'), col('n', 'Products', R), col('value', 'Value at cost', R), col('retail', 'Value at selling price', R)],
          rows: Object.values(groups).sort((a, b) => (a.shop + a.group < b.shop + b.group ? -1 : 1)).map((g) => ({ ...g, value: $(g.value), retail: $(g.retail) })) }]
          .concat(per.map(({ s, rows }) => ({ title: `${s.name} – every product`, columns: [col('code', 'Code'), col('name', 'Product'), col('qty', 'On hand', R), col('cost', 'Cost', R), col('value', 'Value', R), col('price', 'Price', R), col('margin', 'Margin %', R)],
            rows: rows.map((r) => ({ code: r.code, name: r.name, qty: fq(r.on_hand), cost: $(r.cost), value: $(r.value), price: $(r.shop_price), margin: r.margin === null ? '' : r.margin, _tone: r.on_hand < 0 || r.belowCost ? 'bad' : null })) }))),
      });
    } },
  { id: 'inv_movements', group: 'Inventory', icon: '🔀', title: 'Stock movements', desc: 'Everything that came in or went out, by type and shop', perm: 'inventory_view',
    build(from, to) {
      const moves = I.movesFor({ from, to, limit: 100000 });
      const sum = {};
      moves.forEach((m) => { const k = `${m.shop_code}|${m.type}`; const x = (sum[k] = sum[k] || { shop: m.shop_code, type: I.MOVE_LABEL[m.type] || m.type, n: 0, qty: 0, value: 0 }); x.n += 1; x.qty += m.qty; x.value += m.qty * (m.unit_cost || 0); });
      return base('inv_movements', 'Stock Movements', from, to, {
        sections: [{ title: 'Summary', columns: [col('shop', 'Shop'), col('type', 'Type'), col('n', 'Lines', R), col('qty', 'Units', R), col('value', 'Value at cost', R)], rows: Object.values(sum).map((x) => ({ ...x, qty: fq(x.qty), value: $(x.value) })) },
          { title: 'Every movement (not sales)', columns: [col('date', 'Date'), col('shop', 'Shop'), col('type', 'Type'), col('code', 'Code'), col('name', 'Product'), col('qty', 'Qty', R), col('value', 'Value', R), col('why', 'Reason'), col('by', 'By')],
            rows: moves.filter((m) => m.type !== 'sale').reverse().map((m) => ({ date: m.move_date, shop: m.shop_code, type: I.MOVE_LABEL[m.type] || m.type, code: m.code, name: m.name, qty: fq(m.qty), value: $(m.qty * (m.unit_cost || 0)), why: [m.reason, m.note].filter(Boolean).join(' – '), by: m.by_name || '' })) }],
      });
    } },
  { id: 'inv_shrinkage', group: 'Inventory', icon: '🕳️', title: 'Stock losses (shrinkage)', desc: 'Write-offs, stock-take differences and transfer shortages, per shop', perm: 'inventory_view',
    build(from, to) {
      const per = shops().map((s) => ({ s, x: I.shrinkage({ shopCode: s.code, from, to }) }));
      const w = I.writeOffWatch({ from, to });
      return base('inv_shrinkage', 'Stock Losses', from, to, {
        summary: per.map(({ s, x }) => ({ label: s.code, value: $(x.total), tone: x.total < 0 ? 'bad' : undefined })),
        sections: [{ title: 'By shop and reason', columns: [col('shop', 'Shop'), col('reason', 'Reason'), col('times', 'Times', R), col('qty', 'Units', R), col('value', 'Value at cost', R)],
          rows: per.flatMap(({ s, x }) => x.byReason.map((r) => ({ shop: s.code, reason: r.reason, times: r.times, qty: fq(r.qty), value: $(r.value), _tone: r.value < 0 ? 'bad' : null }))
            .concat(x.transitShort ? [{ shop: s.code, reason: 'Lost between shops', times: '', qty: '', value: $(-x.transitShort), _tone: 'bad' }] : [])) },
        { title: 'Write-offs by person', columns: [col('key', 'Person'), col('times', 'Times', R), col('value', 'Value', R)], rows: w.byPerson.map((p) => ({ ...p, value: $(p.value) })) },
        { title: 'Write-offs by product', columns: [col('key', 'Product'), col('times', 'Times', R), col('value', 'Value', R)], rows: w.byProduct.slice(0, 50).map((p) => ({ ...p, value: $(p.value) })) },
        { title: `Large write-offs (over ${$(I.invRules().writeOffApproveOver)})`, columns: [col('date', 'Date'), col('shop', 'Shop'), col('name', 'Product'), col('qty', 'Qty', R), col('value', 'Value', R), col('why', 'Reason'), col('by', 'By')],
          rows: w.big.map((m) => ({ date: m.move_date, shop: m.shop_code, name: m.name, qty: fq(m.qty), value: $(m.qty * (m.unit_cost || 0)), why: [m.reason, m.note].filter(Boolean).join(' – '), by: m.by_name || '', _tone: 'bad' })) }],
      });
    } },
  { id: 'inv_reorder', group: 'Inventory', icon: '🛒', title: 'Reorder list', desc: 'What to order, per shop and supplier', perm: 'inventory_view',
    build(from, to) {
      const rows = shops().flatMap((s) => I.stockList({ shopCode: s.code, filter: 'order', today: to, limit: 100000 }).map((r) => ({ shop: s.code, sup: r.supplier_name || '—', code: r.code, name: r.name, have: fq(r.on_hand), onorder: fq(r.on_order), week: r.perWeek, order: fq(r.suggest), cost: $(r.suggest * r.cost) })));
      return base('inv_reorder', 'Reorder List', to, to, { sections: [{ title: 'Suggested orders', columns: [col('shop', 'Shop'), col('sup', 'Supplier'), col('code', 'Code'), col('name', 'Product'), col('have', 'On hand', R), col('onorder', 'On order', R), col('week', 'Sells/week', R), col('order', 'Order', R), col('cost', 'Cost', R)],
        rows: rows.sort((a, b) => (a.shop + a.sup < b.shop + b.sup ? -1 : 1)) }] });
    } },
  { id: 'inv_slow', group: 'Inventory', icon: '🐌', title: 'Best and slow sellers', desc: 'Top sellers, products not selling, stock turnover', perm: 'inventory_view',
    build(from, to) {
      const sections = [];
      shops().forEach((s) => {
        const rows = I.stockList({ shopCode: s.code, today: to, limit: 100000 });
        const top = rows.filter((r) => r.sold > 0).sort((a, b) => b.sold * b.shop_price - a.sold * a.shop_price).slice(0, 30);
        sections.push({ title: `${s.name} – top sellers (last ${I.invRules().salesDays} days)`, columns: [col('code', 'Code'), col('name', 'Product'), col('sold', 'Sold', R), col('sales', 'Sales (approx.)', R), col('margin', 'Margin %', R)],
          rows: top.map((r) => ({ code: r.code, name: r.name, sold: fq(r.sold), sales: $(r.sold * r.shop_price), margin: r.margin === null ? '' : r.margin })) });
        sections.push({ title: `${s.name} – not selling`, columns: [col('code', 'Code'), col('name', 'Product'), col('have', 'On hand', R), col('value', 'Value', R), col('idle', 'Days since sale / delivery', R)],
          rows: rows.filter((r) => r.dead).sort((a, b) => b.value - a.value).map((r) => ({ code: r.code, name: r.name, have: fq(r.on_hand), value: $(r.value), idle: r.idleDays === null ? 'never' : r.idleDays, _tone: 'warn' })) });
      });
      return base('inv_slow', 'Best And Slow Sellers', to, to, { sections });
    } },
  { id: 'inv_cost_changes', group: 'Inventory', icon: '💲', title: 'Cost price changes', desc: 'Every change of cost price, with the margin after it', perm: 'inventory_view',
    build(from, to) {
      const list = I.costChanges({ from, to, limit: 100000 });
      return base('inv_cost_changes', 'Cost Price Changes', from, to, {
        summary: [{ label: 'Changes', value: String(list.length) }, { label: 'Up', value: String(list.filter((c) => c.diff > 0).length), tone: 'bad' }, { label: 'Not checked', value: String(list.filter((c) => !c.seen_at).length) }],
        sections: [{ title: 'Changes', columns: [col('date', 'Date'), col('code', 'Code'), col('name', 'Product'), col('from', 'Supplier / source'), col('old', 'Old cost', R), col('new', 'New cost', R), col('pct', '%', R), col('price', 'Price', R), col('margin', 'Margin %', R), col('seen', 'Checked by')],
          rows: list.map((c) => ({ date: c.change_date, code: c.code, name: c.name, from: c.supplier_name || c.source || '', old: $(c.old_cost), new: $(c.new_cost), pct: c.pct === null ? '' : c.pct, price: $(c.price), margin: c.margin === null ? '' : c.margin, seen: c.seen_by_name || '', _tone: c.belowCost ? 'bad' : c.diff > 0 ? 'warn' : null })) }],
      });
    } },
  { id: 'po_list', group: 'Purchase orders', icon: '📝', title: 'Purchase orders & budgets', desc: 'Orders by supplier and shop, budget used, deliveries still to come', perm: 'po_create',
    build(from, to) {
      const list = I.listPOs({ from, to, limit: 100000 }).filter((o) => o.status !== 'cancelled');
      const per = {};
      list.forEach((o) => { const p = (per[o.supplier_uid] = per[o.supplier_uid] || { sup: o.supplier_name, uid: o.supplier_uid, n: 0, total: 0 }); p.n += 1; p.total += o.total; });
      return base('po_list', 'Purchase Orders', from, to, {
        summary: [{ label: 'Orders', value: String(list.length) }, { label: 'Value', value: $(list.reduce((s, o) => s + o.total, 0)) }, { label: 'Still to come', value: String(list.filter((o) => ['approved', 'sent', 'part'].includes(o.status)).length) }],
        sections: [{ title: 'By supplier (budget as at the end of the period)', columns: [col('sup', 'Supplier'), col('n', 'Orders', R), col('total', 'Ordered', R), col('wb', 'Week budget', R), col('wu', 'Week used', R), col('mb', 'Month budget', R), col('mu', 'Month used', R)],
          rows: Object.values(per).map((p) => { const b = I.budgetUse(p.uid, to); return { sup: p.sup, n: p.n, total: $(p.total), wb: b.weekBudget === null ? '' : $(b.weekBudget), wu: $(b.week), mb: b.monthBudget === null ? '' : $(b.monthBudget), mu: $(b.month), _tone: (b.weekLeft !== null && b.weekLeft < 0) || (b.monthLeft !== null && b.monthLeft < 0) ? 'bad' : null }; }) },
        { title: 'Orders', columns: [col('no', 'PO'), col('date', 'Date'), col('shop', 'Shop'), col('sup', 'Supplier'), col('total', 'Total', R), col('status', 'Status'), col('by', 'Made by'), col('ok', 'Approved by'), col('note', 'Budget note')],
          rows: list.map((o) => ({ no: o.po_no, date: o.order_date, shop: o.shop_code, sup: o.supplier_name, total: $(o.total), status: I.PO_STATUS[o.status], by: o.created_by_name || '', ok: o.approved_by_name || '', note: o.budget_note || '' })) }],
      });
    } },
  { id: 'po_unmatched', group: 'Purchase orders', icon: '🧾', title: 'Received, not invoiced', desc: 'Deliveries with no supplier invoice, returns with no credit note, invoice differences', perm: 'po_receive',
    build(from, to) {
      const list = I.listReceipts({ from, to, limit: 100000 }).filter((r) => r.status === 'active');
      const missing = list.filter((r) => !r.invoice_uid);
      const diff = list.filter((r) => r.invoice_uid && r.invoice_total !== null && Math.abs(Math.abs(r.invoice_total) - Math.abs(r.total)) > 0.004);
      const row = (r) => ({ date: r.receive_date, shop: r.shop_code, sup: r.supplier_name, kind: r.kind === 'return' ? 'Return' : 'Delivery', value: $(r.total), inv: r.invoice_no || '', invt: r.invoice_total === null ? '' : $(r.invoice_total), note: r.match_note || r.notes || '' });
      const cols = [col('date', 'Date'), col('shop', 'Shop'), col('sup', 'Supplier'), col('kind', 'Type'), col('value', 'Goods value', R), col('inv', 'Invoice / credit'), col('invt', 'Invoice total', R), col('note', 'Note')];
      return base('po_unmatched', 'Received Not Invoiced', from, to, {
        summary: [{ label: 'No invoice yet', value: $(missing.filter((r) => r.kind !== 'return').reduce((s, r) => s + r.total, 0)), tone: 'bad' }, { label: 'Credit still due', value: $(-missing.filter((r) => r.kind === 'return').reduce((s, r) => s + r.total, 0)) }],
        sections: [{ title: 'Waiting for an invoice / credit note', columns: cols, rows: missing.map(row) }, { title: 'Invoice differs from goods received', columns: cols, rows: diff.map((r) => ({ ...row(r), _tone: 'warn' })) }],
      });
    } },
  { id: 'stocktakes', group: 'Stock take', icon: '📋', title: 'Stock take results', desc: 'Every stock take: accuracy, short and over in dollars', perm: 'inventory_view',
    build(from, to) {
      const list = I.listCounts({ limit: 1000 }).filter((c) => c.count_date >= from && c.count_date <= to && c.status === 'posted');
      return base('stocktakes', 'Stock Take Results', from, to, {
        summary: [{ label: 'Stock takes', value: String(list.length) }, { label: 'Net', value: $(list.reduce((s, c) => s + ((c.result && c.result.net) || 0), 0)) }],
        sections: [{ title: 'Stock takes', columns: [col('date', 'Date'), col('shop', 'Shop'), col('name', 'Name'), col('n', 'Counted', R), col('acc', 'Accuracy %', R), col('loss', 'Short', R), col('gain', 'Over', R), col('net', 'Net', R), col('by', 'Approved by')],
          rows: list.map((c) => ({ date: c.count_date, shop: c.shop_code, name: c.name, n: c.result ? c.result.counted : '', acc: c.result && c.result.accuracy !== null ? c.result.accuracy : '', loss: c.result ? $(c.result.loss) : '', gain: c.result ? $(c.result.gain) : '', net: c.result ? $(c.result.net) : '', by: c.posted_by_name || '', _tone: c.result && c.result.net < 0 ? 'bad' : null })) }],
      });
    } },
];

// v3.9.5 Goods received note (or goods returned note) for a delivery, laid out like the suppliers' tax invoices:
// each line with the amount before VAT, VAT and amount with VAT; VAT summary, subtotal, VAT and total; the order and
// invoice it belongs to; who counted it in. Returns carry "Date of return" and the supplier's return number lines.
export function receiptReport(uid) {
  const r = I.getReceipt(uid);
  if (!r) return null;
  const shop = listShops().find((s) => s.code === r.shop_code);
  const rate = I.vatRate();
  const VAT_LABEL = { standard: `${fq(rate)}%`, zero: 'Zero rated', exempt: 'VAT free' };
  const po = r.po_uid ? db().get('SELECT po_no FROM po_orders WHERE uid = ?', [r.po_uid]) : null;
  const sup = r.supplier_uid ? db().get('SELECT tin FROM ap_suppliers WHERE uid = ?', [r.supplier_uid]) || {} : {};
  const rows = (r.lines || []).map((l, i) => {
    const it = l.itemUid ? I.getItem(l.itemUid) : null;
    const vt = it ? it.vat_type : 'standard';
    const amount = r2((Number(l.qty) || 0) * (Number(l.unitCost) || 0));
    const inc = I.incVat(amount, vt);
    return { n: i + 1, code: l.code || '', name: l.name, ordered: l.ordered ? fq(l.ordered) : '', qty: fq(l.qty), cost: $(l.unitCost), amount: $(amount), vatAmt: vt === 'standard' ? $(r2(inc - amount)) : VAT_LABEL[vt], total: $(inc), _amount: amount, _inc: inc, _vt: vt };
  });
  const split = I.vatSplit(rows.map((x) => ({ amount: x._amount, vatType: x._vt })));
  const ret = r.kind === 'return';
  const totals = [{ label: `VAT summary: ${fq(rate)}% on ${$(r2(split.sub - split.zero))}`, value: $(split.vat) }]
    .concat(split.zero > 0.004 ? [{ label: `VAT summary: zero rated / VAT free on ${$(split.zero)}`, value: $(0) }] : [])
    .concat([{ label: 'Subtotal (excl. VAT)', value: $(split.sub) }, { label: 'Total VAT', value: $(split.vat) }, { label: 'TOTAL (incl. VAT)', value: $(split.total), strong: true }]);
  return {
    kind: ret ? 'goods_return' : 'grn', title: ret ? 'Goods Returned Note' : 'Goods Received Note', fileName: `${ret ? 'Return' : 'GRN'}-${r.receive_date}-${String(r.supplier_name || '').replace(/\s+/g, '-')}`,
    subtitle: `Easy Buys Shopping Centre · ${shop ? shop.name : r.shop_code}`,
    info: [['Supplier', `${r.supplier_name || ''}${sup.tin ? ` · TIN ${sup.tin}` : ''}`], [ret ? 'Date of return' : 'Date received', r.receive_date], ['Shop', shop ? shop.name : r.shop_code],
      ['Our order no.', po ? po.po_no : 'No order'], [ret ? 'Credit note' : 'Supplier tax invoice', r.invoice_no ? `${r.invoice_no}${r.invoice_total !== null && r.invoice_total !== undefined ? ` · ${$(r.invoice_total)}` : ''}` : 'not yet'],
      [ret ? 'Returned by' : 'Counted in by', r.by_name || '']].concat(r.match_note ? [['Checked', r.match_note]] : []).concat(r.notes ? [['Note', r.notes]] : []),
    approved: undefined,
    summary: [{ label: 'Products', value: String(rows.length) }, { label: 'Total incl. VAT', value: $(split.total) }],
    sections: [{ title: ret ? 'Goods returned' : 'Goods received', columns: [col('n', '#'), col('code', 'Code'), col('name', 'Description')].concat(ret ? [] : [col('ordered', 'Ordered', R)], [col('qty', ret ? 'Qty' : 'Received', R), col('cost', 'Unit price (excl. VAT)', R), col('amount', 'Amount (excl. VAT)', R), col('vatAmt', 'VAT', R), col('total', 'Amount (incl. VAT)', R)]),
      rows: rows.map(({ _amount, _inc, _vt, ...x }) => x), totals,
      note: ret ? 'Please issue a credit note for these goods quoting this return.' : 'Quantities are in singles (cartons counted as their items).' }],
  };
}
