// Barcode scanning into purchase orders, deliveries and stock takes (camera or a handheld "keyboard" scanner).
// Products come from Aronium: a barcode the app does not know must be added in Aronium first, then imported.
import { db } from '../../db/connection.js';
import * as I from './service.js';
import { getSupplier } from '../payables/service.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
export const NOT_FOUND = 'This product is not in the product list. Add it in Aronium first, then import the products again (Inventory › Import from Aronium).';

// The same product can be printed as UPC-A (12 digits) or EAN-13 (a 0 in front), and scanners sometimes drop or add it.
export function barcodeVariants(code) {
  const c = txt(code).replace(/\s+/g, '');
  const out = new Set([c]);
  if (/^\d{12}$/.test(c)) out.add(`0${c}`);
  if (/^0\d{12}$/.test(c)) out.add(c.slice(1));
  return [...out].filter(Boolean);
}
// Barcodes of a product: Aronium allows several (stored comma-separated).
export const barcodesOf = (item) => String((item && item.barcode) || '').split(/[,;|\s]+/).map(txt).filter(Boolean);

// Find a product by any of its barcodes, or by its code. Hidden products (deleted in Aronium) are found but marked.
export function findByBarcode(code) {
  const c = txt(code);
  if (!c) return null;
  for (const v of barcodeVariants(c)) {
    const it = db().get(`SELECT * FROM inv_items WHERE barcode = ? OR (',' || replace(replace(ifnull(barcode,''),' ',''),';',',') || ',') LIKE ? ORDER BY active DESC LIMIT 1`, [v, `%,${v},%`]);
    if (it) return it;
  }
  return db().get('SELECT * FROM inv_items WHERE upper(code) = upper(?) ORDER BY active DESC LIMIT 1', [c]) || null;
}

// What happens when a code is scanned. Returns
//   { ok: true, item, warning?, otherSupplier? }  – ask for the quantity next (show the warning first, if any)
//   { ok: false, code, message }                   – not found / hidden / not sold at this shop
export function lookupScan(code, { supplierUid, shopCode } = {}) {
  const c = txt(code);
  if (!c) return { ok: false, code: c, message: 'Nothing was scanned.' };
  const it = findByBarcode(c);
  if (!it) return { ok: false, code: c, notFound: true, message: NOT_FOUND };
  if (!it.active) return { ok: false, code: c, hidden: true, item: it, message: `${it.name} is switched off or was deleted in Aronium. Switch it back on in Aronium and import the products again.` };
  const out = { ok: true, code: c, item: it };
  if (shopCode) out.onHand = I.stockOf(it.uid, shopCode);
  if (supplierUid && it.supplier_uid && it.supplier_uid !== supplierUid) {
    const other = getSupplier(it.supplier_uid);
    out.otherSupplier = other ? other.name : 'another supplier';
    out.warning = `${it.name} usually comes from ${out.otherSupplier}, not from this supplier. Add it anyway?`;
  }
  return out;
}

// Add a scanned quantity to a list of lines ({ itemUid, qty, … }): adds to the same product, or a new line at the end.
export function addScanned(lines, item, qty, make = (it) => ({ itemUid: it.uid, name: it.name, code: it.code, unit: it.unit, unitCost: String(it.cost), note: '' })) {
  const n = Number(qty) || 0;
  const i = lines.findIndex((l) => l.itemUid === item.uid);
  if (i >= 0) return lines.map((l, k) => (k === i ? { ...l, qty: String(Math.round(((Number(l.qty) || 0) + n) * 1000) / 1000) } : l));
  return lines.concat([{ ...make(item), qty: String(n) }]);
}
