// Supplier order schedules: which days a supplier takes orders, the cut-off time on each day, the delivery day,
// and how long before the cut-off to remind. One schedule for all shops, with optional changes for one shop.
// Reminders go to that shop's manager and the owner (Home warning + phone notification); none once the order is sent;
// a missed cut-off shows red. "Today's orders" lists them all.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays, addMinutes, getShared, setShared } from '../../services/core.js';
import { can, reasonRequired } from '../../services/access.js';
import { listShops } from '../admin/service.js';
import { operatingShops } from '../../services/costAreas.js';
import { getSupplier } from '../payables/service.js';
import { requirePerm, asService } from '../../services/guard.js';

export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const DEFAULT_REMINDER_MINS = 60;
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const schedUid = (supplierUid, shopCode) => `SS-${supplierUid}-${shopCode === '*' ? 'ALL' : shopCode}`;
export const weekday = (date) => { const [y, m, d] = String(date).split('-').map(Number); return new Date(y, m - 1, d).getDay(); };

function cleanTime(v) {
  const s = txt(v);
  if (!s) return '';
  const m = /^(\d{1,2})[:.](\d{2})\s*(am|pm)?$/i.exec(s);
  need(m, `Check the cut-off time "${s}" (e.g. 10:00).`);
  let h = Number(m[1]);
  if (m[3]) { const pm = m[3].toLowerCase() === 'pm'; if (h === 12) h = pm ? 12 : 0; else if (pm) h += 12; }
  const t = `${String(h).padStart(2, '0')}:${m[2]}`;
  need(TIME.test(t), `Check the cut-off time "${s}".`);
  return t;
}
export function cleanDays(days) {
  const out = [];
  for (const d of days || []) {
    const day = Number(d.day);
    need(Number.isInteger(day) && day >= 0 && day <= 6, 'Choose the order day.');
    need(!out.some((x) => x.day === day), `${DAY_NAMES[day]} is in the list twice.`);
    const dd = d.deliveryDay === '' || d.deliveryDay === null || d.deliveryDay === undefined ? null : Number(d.deliveryDay);
    need(dd === null || (Number.isInteger(dd) && dd >= 0 && dd <= 6), 'Choose the delivery day.');
    out.push({ day, cutoff: cleanTime(d.cutoff), deliveryDay: dd });
  }
  return out.sort((a, b) => ((a.day + 1) % 7) - ((b.day + 1) % 7)); // Saturday first (pay week order)
}

// Save the schedule for all shops (shopCode '*') or one shop's changes (days / reminder null = same as all shops; skip = this
// shop does not order from them).
export function saveSchedule(user, { supplierUid, shopCode = '*', days, reminderMins, skip = false, active = true, notes } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const s = getSupplier(supplierUid);
  need(s, 'Choose the supplier.');
  const shop = txt(shopCode) || '*';
  need(shop === '*' || listShops({ includeInactive: true }).some((x) => x.code === shop), 'Choose the shop.');
  const d = days === null || days === undefined ? null : cleanDays(days);
  if (shop === '*' && active) need(d && d.length, 'Add at least one order day.');
  const rm = reminderMins === '' || reminderMins === null || reminderMins === undefined ? (shop === '*' ? DEFAULT_REMINDER_MINS : null) : Math.round(Number(reminderMins));
  need(rm === null || (Number.isFinite(rm) && rm >= 0 && rm <= 7 * 24 * 60), 'The reminder must be between 0 minutes and 7 days before the cut-off.');
  const uid = schedUid(supplierUid, shop);
  const before = db().get('SELECT * FROM supplier_schedules WHERE uid = ?', [uid]);
  const now = stamp();
  const dev = deviceId();
  db().run(`INSERT INTO supplier_schedules (uid, supplier_uid, shop_code, days, reminder_mins, skip, active, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET days = excluded.days, reminder_mins = excluded.reminder_mins, skip = excluded.skip, active = excluded.active, notes = excluded.notes,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, supplierUid, shop, d === null ? null : JSON.stringify(d), rm, skip ? 1 : 0, active ? 1 : 0, txt(notes) || null, now, dev]);
  audit({ user, action: `Order schedule for ${s.name}${shop === '*' ? '' : ` at ${shop}`}: ${skip ? 'not ordered by this shop' : d ? describeDays(d) : 'same days as all shops'}${rm !== null ? `, remind ${rm} min before` : ''}${active ? '' : ' (switched off)'}`,
    table: 'supplier_schedules', recordUid: uid, before: before && { days: J(before.days, null), reminder: before.reminder_mins }, after: { days: d, reminder: rm } });
  return getSchedules(supplierUid);
  });
}
// A shop's changes are switched off (never deleted): the shop follows the all-shops schedule again.
export function clearShopChange(user, supplierUid, shopCode) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const uid = schedUid(supplierUid, shopCode);
  const row = db().get('SELECT * FROM supplier_schedules WHERE uid = ?', [uid]);
  need(row && row.active, 'This shop has no changes.');
  db().run(`UPDATE supplier_schedules SET active = 0, ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: `Order schedule: ${shopCode} follows the all-shops schedule again`, table: 'supplier_schedules', recordUid: uid });
  });
}
export function describeDays(days) {
  return (days || []).map((d) => `${DAY_SHORT[d.day]}${d.cutoff ? ` by ${d.cutoff}` : ''}${d.deliveryDay !== null && d.deliveryDay !== undefined ? ` → ${DAY_SHORT[d.deliveryDay]}` : ''}`).join(', ') || 'no days';
}

const rowOut = (r) => r && { ...r, days: J(r.days, null), skip: !!r.skip, active: !!r.active };
export function getSchedules(supplierUid) {
  const rows = db().all('SELECT * FROM supplier_schedules WHERE supplier_uid = ?', [supplierUid]).map(rowOut);
  const base = rows.find((r) => r.shop_code === '*') || null;
  const shops = Object.fromEntries(rows.filter((r) => r.shop_code !== '*' && r.active).map((r) => [r.shop_code, r]));
  return { base, shops };
}
// Old "order days" typed on the supplier (before v3.5): "Mon,Thu" or "1,4".
function legacyDays(s) {
  const v = txt(s && s.order_days);
  if (!v) return null;
  const out = [];
  for (const p of v.split(/[,;\s]+/).filter(Boolean)) {
    const n = /^\d$/.test(p) ? Number(p) : DAY_SHORT.findIndex((d) => d.toLowerCase() === p.slice(0, 3).toLowerCase());
    if (n >= 0 && n <= 6 && !out.some((x) => x.day === n)) out.push({ day: n, cutoff: '', deliveryDay: null });
  }
  return out.length ? out : null;
}
// The schedule that applies to one shop: its own changes over the all-shops schedule.
export function effectiveSchedule(supplierUid, shopCode) {
  const { base, shops } = getSchedules(supplierUid);
  const own = shops[shopCode];
  if (own && own.skip) return null;
  if (!base || !base.active) {
    if (own && own.days && own.days.length) return { days: own.days, reminderMins: own.reminder_mins ?? DEFAULT_REMINDER_MINS, from: 'shop' };
    if (base) return null; // switched off
    const legacy = legacyDays(getSupplier(supplierUid));
    return legacy ? { days: legacy, reminderMins: DEFAULT_REMINDER_MINS, from: 'legacy' } : null;
  }
  return {
    days: own && own.days ? own.days : base.days || [],
    reminderMins: own && own.reminder_mins !== null && own.reminder_mins !== undefined ? own.reminder_mins : base.reminder_mins ?? DEFAULT_REMINDER_MINS,
    from: own ? 'shop' : 'all',
  };
}
export function scheduledSuppliers() {
  const ids = new Set(db().all('SELECT DISTINCT supplier_uid FROM supplier_schedules WHERE active = 1').map((r) => r.supplier_uid));
  db().all("SELECT uid FROM ap_suppliers WHERE active = 1 AND order_days IS NOT NULL AND order_days <> ''").forEach((r) => ids.add(r.uid));
  return db().all('SELECT * FROM ap_suppliers WHERE active = 1 ORDER BY name').filter((s) => ids.has(s.uid));
}

// "Not ordering today" (kept in the shared settings so every device knows).
const skipKey = (supplierUid, shopCode, date) => `${date}|${supplierUid}|${shopCode}`;
export function skipOrder(user, { supplierUid, shopCode, date = dateStr(), reason } = {}) {
  if (reasonRequired(user)) need(txt(reason), 'Say why no order is needed today.');
  const all = getShared('order_skips', {}) || {};
  const keep = Object.fromEntries(Object.entries(all).filter(([k]) => k.slice(0, 10) >= addDays(dateStr(), -14)));
  keep[skipKey(supplierUid, shopCode, date)] = { by: user.name, reason: txt(reason) || null, at: stamp() };
  setShared('order_skips', keep);
  const s = getSupplier(supplierUid);
  audit({ user, action: `No order from ${s ? s.name : supplierUid} for ${shopCode} on ${date}`, table: 'supplier_schedules', recordUid: schedUid(supplierUid, '*'), reason: txt(reason) || null });
}
const skipped = (supplierUid, shopCode, date) => (getShared('order_skips', {}) || {})[skipKey(supplierUid, shopCode, date)] || null;

// The order for this slot: made since the previous order day (inclusive of today). Cancelled ones don't count.
function orderFor(supplierUid, shopCode, date, days) {
  let prev = addDays(date, -7);
  for (let k = 1; k <= 7; k += 1) { const d = addDays(date, -k); if (days.some((x) => x.day === weekday(d))) { prev = d; break; } }
  return db().get(`SELECT * FROM po_orders WHERE supplier_uid = ? AND shop_code = ? AND status <> 'cancelled' AND order_date > ? AND order_date <= ?
    ORDER BY CASE WHEN status IN ('sent','part','received','closed') THEN 0 ELSE 1 END, created_at DESC LIMIT 1`, [supplierUid, shopCode, prev, date]);
}
const isSent = (o) => !!o && (['sent', 'part', 'received', 'closed'].includes(o.status) || !!o.sent_at);
export const ORDER_STATE = { sent: 'Sent', due: 'Order now', missed: 'Cut-off missed', later: 'Later today', skipped: 'Not ordering', started: 'Started – not sent' };

// Every order slot on one day for the operating shops. now: 'YYYY-MM-DD HH:MM:SS'.
export function ordersForDay(date = dateStr(), { now = stamp(), shopCodes } = {}) {
  const shops = operatingShops().map((s) => s.code).filter((c) => !shopCodes || shopCodes.includes(c));
  const wd = weekday(date);
  const out = [];
  for (const s of scheduledSuppliers()) {
    for (const shop of shops) {
      const sch = effectiveSchedule(s.uid, shop);
      if (!sch) continue;
      const slot = sch.days.find((d) => d.day === wd);
      if (!slot) continue;
      const cutoffAt = slot.cutoff ? `${date} ${slot.cutoff}:00` : null;
      const remindAt = cutoffAt ? addMinutes(cutoffAt, -sch.reminderMins) : `${date} 00:00:00`;
      let deliveryDate = null;
      if (slot.deliveryDay !== null && slot.deliveryDay !== undefined) {
        for (let k = 0; k <= 7; k += 1) { const d = addDays(date, k); if (weekday(d) === slot.deliveryDay && (k > 0 || slot.deliveryDay === wd)) { deliveryDate = d; break; } }
      }
      const po = orderFor(s.uid, shop, date, sch.days);
      const skip = skipped(s.uid, shop, date);
      let state;
      if (isSent(po)) state = 'sent';
      else if (skip) state = 'skipped';
      else if (cutoffAt && now > cutoffAt) state = 'missed';
      else if (now >= remindAt) state = po ? 'started' : 'due';
      else state = 'later';
      out.push({ date, supplierUid: s.uid, supplierName: s.name, shopCode: shop, cutoff: slot.cutoff || null, cutoffAt, remindAt, deliveryDate,
        reminderMins: sch.reminderMins, po: po || null, state, skip, from: sch.from });
    }
  }
  return out.sort((a, b) => (a.cutoff || '99').localeCompare(b.cutoff || '99') || a.supplierName.localeCompare(b.supplierName) || a.shopCode.localeCompare(b.shopCode));
}

// Which shops' orders this person is reminded about: the owner/admin all shops; a manager (anyone who makes orders) their shop.
export function reminderShops(user) {
  if (!user) return [];
  if (!reasonRequired(user)) return null; // owner / admin: every shop
  if (!can(user, 'po_create')) return [];
  return user.shop_code ? [user.shop_code] : null;
}

// Home warnings: "order now" (with a phone notification) and missed cut-offs (red). Tomorrow's early cut-offs are included
// when their reminder time has already come.
export function orderAlerts(user, { now = stamp() } = {}) {
  const shops = reminderShops(user);
  if (Array.isArray(shops) && !shops.length) return [];
  const today = now.slice(0, 10);
  const rows = ordersForDay(today, { now, shopCodes: shops || undefined }).concat(ordersForDay(addDays(today, 1), { now, shopCodes: shops || undefined }).filter((r) => r.state === 'due' || r.state === 'started'));
  const out = [];
  for (const r of rows) {
    const key = `${r.date}-${r.supplierUid}-${r.shopCode}`;
    const when = r.cutoff ? `${r.date === today ? 'today' : 'tomorrow'} by ${r.cutoff}` : 'today';
    if (r.state === 'due') {
      out.push({ id: `ord-due-${key}`, level: 'warning', notify: true, area: 'inventory', text: `Order from ${r.supplierName} for ${r.shopCode} ${when}`,
        sub: 'Tap to make the order with suggested quantities.', nav: { screen: 'POEdit', params: { shopCode: r.shopCode, supplierUid: r.supplierUid, suggest: true } } });
    } else if (r.state === 'started') {
      out.push({ id: `ord-started-${key}`, level: 'warning', notify: true, area: 'inventory', text: `Order ${r.po.po_no} to ${r.supplierName} (${r.shopCode}) is not sent yet – ${when}`,
        nav: { screen: 'POView', params: { uid: r.po.uid } } });
    } else if (r.state === 'missed') {
      out.push({ id: `ord-missed-${key}`, level: 'urgent', area: 'inventory', text: `Missed the ${r.cutoff} order cut-off for ${r.supplierName} (${r.shopCode})`,
        sub: r.po ? `Order ${r.po.po_no} was not sent.` : 'No order was sent. Phone the supplier, or mark "Not ordering today".', nav: { screen: 'TodaysOrders', params: {} } });
    }
  }
  return out;
}
