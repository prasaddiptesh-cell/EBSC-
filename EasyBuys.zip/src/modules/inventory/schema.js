// Inventory, purchase orders and stock takes. Each shop has its own stock, product list, reorder levels and prices.
// Stock is never stored as a number to overwrite: it is the sum of movements (received, sold, moved, counted…),
// so every unit can be traced. Sales come from Aronium through the main software (read-only on Aronium).
export const INVENTORY_SQL = `
CREATE TABLE IF NOT EXISTS inv_items (
  uid TEXT PRIMARY KEY,
  code TEXT NOT NULL,
  barcode TEXT,
  name TEXT NOT NULL,
  group_name TEXT,
  unit TEXT,
  cost REAL NOT NULL DEFAULT 0,
  price REAL NOT NULL DEFAULT 0,
  vat_type TEXT NOT NULL DEFAULT 'standard',
  supplier_uid TEXT,
  pack_size REAL NOT NULL DEFAULT 1,
  active INTEGER NOT NULL DEFAULT 1,
  notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_inv_code ON inv_items(code);
CREATE INDEX IF NOT EXISTS idx_inv_barcode ON inv_items(barcode);

-- The product at one shop: sold there or not, reorder level, its own price.
CREATE TABLE IF NOT EXISTS inv_item_shops (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  shop_code TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  reorder_level REAL NOT NULL DEFAULT 0,
  reorder_qty REAL NOT NULL DEFAULT 0,
  price REAL,
  location TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_invs_shop ON inv_item_shops(shop_code, item_uid);

CREATE TABLE IF NOT EXISTS inv_moves (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  shop_code TEXT NOT NULL,
  move_date TEXT NOT NULL,
  type TEXT NOT NULL,
  qty REAL NOT NULL,
  unit_cost REAL,
  ref_type TEXT,
  ref_uid TEXT,
  reason TEXT,
  note TEXT,
  by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_invm_shop ON inv_moves(shop_code, type, move_date);
CREATE INDEX IF NOT EXISTS idx_invm_item ON inv_moves(item_uid, shop_code, move_date);
CREATE INDEX IF NOT EXISTS idx_invm_ref ON inv_moves(ref_uid);

-- Cost price changes seen when receiving: flagged until someone looks at them.
CREATE TABLE IF NOT EXISTS inv_cost_changes (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  change_date TEXT NOT NULL,
  old_cost REAL,
  new_cost REAL NOT NULL,
  supplier_name TEXT,
  ref_uid TEXT,
  shop_code TEXT,
  source TEXT,
  seen_by_name TEXT, seen_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS po_orders (
  uid TEXT PRIMARY KEY,
  po_no TEXT NOT NULL,
  supplier_uid TEXT NOT NULL,
  supplier_name TEXT,
  shop_code TEXT NOT NULL,
  order_date TEXT NOT NULL,
  expected_date TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  total REAL NOT NULL DEFAULT 0,
  notes TEXT,
  created_by_name TEXT, created_at TEXT,
  approved_by_name TEXT, approved_at TEXT,
  sent_at TEXT, sent_via TEXT,
  budget_note TEXT,
  cancel_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS po_lines (
  uid TEXT PRIMARY KEY,
  po_uid TEXT NOT NULL,
  item_uid TEXT,
  code TEXT,
  name TEXT NOT NULL,
  unit TEXT,
  qty REAL NOT NULL,
  unit_cost REAL NOT NULL DEFAULT 0,
  qty_received REAL NOT NULL DEFAULT 0,
  note TEXT,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pol_po ON po_lines(po_uid);

-- A delivery received (against a purchase order or not).
CREATE TABLE IF NOT EXISTS inv_receipts (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'receive',
  po_uid TEXT,
  supplier_uid TEXT,
  supplier_name TEXT,
  shop_code TEXT NOT NULL,
  receive_date TEXT NOT NULL,
  invoice_uid TEXT,
  invoice_no TEXT,
  invoice_total REAL,
  total REAL NOT NULL DEFAULT 0,
  match_note TEXT,
  lines TEXT,
  photo_urls TEXT,
  notes TEXT,
  by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS inv_counts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  name TEXT,
  scope TEXT,
  count_date TEXT,
  timing TEXT NOT NULL DEFAULT 'after_close',
  blind INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'counting',
  submitted_at TEXT, submitted_by_name TEXT,
  started_at TEXT, started_by_name TEXT,
  posted_at TEXT, posted_by_name TEXT,
  uncounted TEXT NOT NULL DEFAULT 'leave',
  notes TEXT,
  result TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS inv_count_lines (
  uid TEXT PRIMARY KEY,
  count_uid TEXT NOT NULL,
  item_uid TEXT NOT NULL,
  expected REAL NOT NULL DEFAULT 0,
  counted REAL,
  first_count REAL,
  recount INTEGER NOT NULL DEFAULT 0,
  cost REAL,
  counted_by_name TEXT, counted_at TEXT,
  note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_icl_count ON inv_count_lines(count_uid);

-- Stock sent from one shop to another: sent (step 1), then received and checked at the other shop (step 2).
CREATE TABLE IF NOT EXISTS inv_transfers (
  uid TEXT PRIMARY KEY,
  transfer_no TEXT NOT NULL,
  from_shop TEXT NOT NULL,
  to_shop TEXT NOT NULL,
  send_date TEXT NOT NULL,
  lines TEXT NOT NULL,
  value REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'sent',
  sent_by_name TEXT, sent_at TEXT,
  received_by_name TEXT, received_at TEXT, receive_date TEXT,
  short_value REAL NOT NULL DEFAULT 0,
  notes TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const INVENTORY_SYNC = {
  inv_items: SYNC('uid', 'Inventory', ['uid', 'code', 'barcode', 'name', 'group_name', 'unit', 'cost', 'price', 'vat_type', 'supplier_uid', 'pack_size', 'active', 'notes']),
  inv_item_shops: SYNC('uid', 'Inventory', ['uid', 'item_uid', 'shop_code', 'active', 'reorder_level', 'reorder_qty', 'price', 'location']),
  inv_moves: SYNC('uid', 'Inventory', ['uid', 'item_uid', 'shop_code', 'move_date', 'type', 'qty', 'unit_cost', 'ref_type', 'ref_uid', 'reason', 'note', 'by_name', 'status', 'void_reason', 'created_at']),
  inv_cost_changes: SYNC('uid', 'Inventory', ['uid', 'item_uid', 'change_date', 'old_cost', 'new_cost', 'supplier_name', 'ref_uid', 'shop_code', 'source', 'seen_by_name', 'seen_at']),
  po_orders: SYNC('uid', 'Purchase orders', ['uid', 'po_no', 'supplier_uid', 'supplier_name', 'shop_code', 'order_date', 'expected_date', 'status', 'total', 'notes', 'created_by_name', 'created_at',
    'approved_by_name', 'approved_at', 'sent_at', 'sent_via', 'budget_note', 'cancel_reason']),
  po_lines: SYNC('uid', 'Purchase orders', ['uid', 'po_uid', 'item_uid', 'code', 'name', 'unit', 'qty', 'unit_cost', 'qty_received', 'note', 'sort']),
  inv_receipts: SYNC('uid', 'Inventory', ['uid', 'kind', 'po_uid', 'supplier_uid', 'supplier_name', 'shop_code', 'receive_date', 'invoice_uid', 'invoice_no', 'invoice_total', 'total', 'match_note', 'lines', 'photo_urls', 'notes', 'by_name', 'status', 'void_reason', 'created_at']),
  inv_counts: SYNC('uid', 'Stock take', ['uid', 'shop_code', 'name', 'scope', 'count_date', 'timing', 'blind', 'status', 'submitted_at', 'submitted_by_name', 'started_at', 'started_by_name', 'posted_at', 'posted_by_name', 'uncounted', 'notes', 'result']),
  inv_transfers: SYNC('uid', 'Inventory', ['uid', 'transfer_no', 'from_shop', 'to_shop', 'send_date', 'lines', 'value', 'status', 'sent_by_name', 'sent_at', 'received_by_name', 'received_at',
    'receive_date', 'short_value', 'notes', 'void_reason']),
  inv_count_lines: SYNC('uid', 'Stock take', ['uid', 'count_uid', 'item_uid', 'expected', 'counted', 'first_count', 'recount', 'cost', 'counted_by_name', 'counted_at', 'note']),
};
