// v3.5 purchasing tables: order change history, supplier order schedules, Aronium supplier details,
// what the app has learned about each supplier's invoice layout, and invoice readings.
export const PURCHASING35_SQL = `
-- Every change to an order after it was sent (and delivery corrections): who, when, why, before and after.
CREATE TABLE IF NOT EXISTS po_versions (
  uid TEXT PRIMARY KEY,
  po_uid TEXT NOT NULL,
  version INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'amend',
  at TEXT NOT NULL,
  by_name TEXT,
  reason TEXT,
  changes TEXT,
  before TEXT,
  after TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pov_po ON po_versions(po_uid, version);

-- When each supplier takes orders. One row for all shops (shop_code '*') and optional rows that change it for one shop.
-- days: [{ day: 0-6 (Sunday = 0), cutoff: 'HH:MM', deliveryDay: 0-6 }]
CREATE TABLE IF NOT EXISTS supplier_schedules (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  shop_code TEXT NOT NULL DEFAULT '*',
  days TEXT,
  reminder_mins INTEGER,
  skip INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_ssch_sup ON supplier_schedules(supplier_uid, shop_code);

-- The supplier as Aronium has it (from the CSV import), linked to the app's supplier.
CREATE TABLE IF NOT EXISTS aronium_suppliers (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  code TEXT,
  name TEXT,
  tin TEXT,
  address TEXT,
  phone TEXT,
  email TEXT,
  imported_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_arsup_sup ON aronium_suppliers(supplier_uid);

-- What was learned from corrections to each supplier's invoices (labels, item line layout, their names for our products).
CREATE TABLE IF NOT EXISTS supplier_layouts (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  layout TEXT NOT NULL,
  samples INTEGER NOT NULL DEFAULT 0,
  updated_by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- One reading of an invoice photo (on the tablet or by Google), with the item lines found.
CREATE TABLE IF NOT EXISTS invoice_reads (
  uid TEXT PRIMARY KEY,
  invoice_uid TEXT,
  supplier_uid TEXT,
  po_uid TEXT,
  receipt_uid TEXT,
  engine TEXT,
  text TEXT,
  result TEXT,
  by_name TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_invread_inv ON invoice_reads(invoice_uid);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const PURCHASING35_SYNC = {
  po_versions: SYNC('uid', 'Purchase orders', ['uid', 'po_uid', 'version', 'kind', 'at', 'by_name', 'reason', 'changes', 'before', 'after']),
  supplier_schedules: SYNC('uid', 'Purchase orders', ['uid', 'supplier_uid', 'shop_code', 'days', 'reminder_mins', 'skip', 'active', 'notes']),
  aronium_suppliers: SYNC('uid', 'Purchase orders', ['uid', 'supplier_uid', 'code', 'name', 'tin', 'address', 'phone', 'email', 'imported_at']),
  supplier_layouts: SYNC('uid', 'Invoices', ['uid', 'supplier_uid', 'layout', 'samples', 'updated_by_name']),
  invoice_reads: SYNC('uid', 'Invoices', ['uid', 'invoice_uid', 'supplier_uid', 'po_uid', 'receipt_uid', 'engine', 'text', 'result', 'by_name', 'created_at']),
};
