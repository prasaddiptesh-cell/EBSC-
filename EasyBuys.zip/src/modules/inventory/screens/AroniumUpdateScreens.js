// 1.0.0 App vs Aronium for each shop, and the Aronium update file (prices, costs, VAT) – made in Aronium's own import
// format, without a Quantity column (Aronium's import would ADD it to the stock).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint, Stats } from '../../../ui/kit.js';
import { shareTextFile } from '../../../platform/files.js';
import * as AU from '../aroniumUpdate.js';
import * as I from '../service.js';
import { shopName, shopChips } from './common.js';

const $ = (n) => (n === null || n === undefined ? '—' : `$${(Number(n) || 0).toFixed(2)}`);
const VAT = { standard: '12.5%', zero: 'zero rated', exempt: 'exempt' };
export function AroniumUpdateScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const act = useAct();
  const [shop, setShop] = useState(params.shop || 'S1');
  const [, bump] = useState(0);
  let cmp = null; let err = null;
  try { cmp = AU.compareShop(shop); } catch (e) { err = e.message; }
  const boss = ['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const make = async (test) => {
    try {
      const f = AU.updateFile(shop, { test });
      if (!f.rows) { ui.toast('Nothing to update – the app and Aronium agree'); return; }
      if (f.warnings.length) await ui.alert({ title: 'Before importing', message: f.warnings.join('\n'), tone: 'warn' });
      await shareTextFile(f.name, f.text);
      AU.noteMade(user, f);
    } catch (e) { ui.error(e); }
  };
  const made = AU.filesMade().filter((x) => x.shop === shop).slice(-3).reverse();
  return (
    <Screen title="App vs Aronium" subtitle={`${shopName(shop)} – prices, costs and VAT`}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="au-shop" />
      {err ? <Banner tone="danger" message={err} /> : null}
      {cmp && !cmp.source ? <Banner tone="warn" message={`No product list from ${shopName(shop)}'s till PC yet – it comes with the Aronium Link.`} /> : null}
      {cmp && cmp.source ? (
        <>
          <Stats items={[{ label: 'Products in Aronium', value: String(cmp.products) }, { label: 'Differ from the app', value: String(cmp.rows.length) },
            { label: 'Price / cost / VAT', value: `${cmp.rows.filter((r) => r.diffs.includes('price')).length} / ${cmp.rows.filter((r) => r.diffs.includes('cost')).length} / ${cmp.rows.filter((r) => r.diffs.includes('vat')).length}` }]} />
          {!cmp.master ? <Banner tone="info" message="Until this shop's opening stock take is approved, the app takes Aronium's prices and costs. After it, the app keeps them, and Aronium is updated from here." /> : null}
          {cmp.rows.length ? (
            <Card tone="info">
              <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>Update Aronium from the app</Text>
              <Text style={{ fontSize: 15, color: C.text }}>{`1. Make the TEST file (one product) first. On ${shopName(shop)}'s till PC: Aronium › Management › Products › Import › choose the file.\n2. Match each column to the field with the same name (Name, SKU, Price, Cost, Tax …). Choose "Merge duplicates".\n3. Press Preview: it must say the product is UPDATED, not created. Import, then open the product in Aronium and check the price, cost and tax.\n4. All good? Make the full file and import it the same way – on every till PC of this shop (each has its own Aronium).`}</Text>
              <Hint>There is no Quantity column, so Aronium's stock is never touched. Suppliers are not in Aronium's import – they stay in the app.</Hint>
              <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
                <Btn testID="au-test" title="Test file (1 product)" icon="🧪" size="md" variant="secondary" onPress={() => make(true)} />
                <Btn testID="au-full" title={`Full file (${cmp.rows.length})`} icon="📤" size="md" variant="success" onPress={() => make(false)} />
              </View>
              {made.length ? <Hint>{`Made: ${made.map((m) => `${m.at.slice(0, 16)} (${m.rows}) by ${m.by}`).join(' · ')}`}</Hint> : null}
            </Card>
          ) : <Banner tone="success" message="The app and Aronium agree for this shop." />}
          <Section title="Differences">
            {cmp.rows.slice(0, 300).map((r) => (
              <View key={r.itemUid} style={{ gap: 4 }}>
                <ListItem testID={`au-${r.code}`} tone="warn" title={r.name}
                  sub={[r.diffs.includes('price') ? `Price: app ${$(r.app.price)}, Aronium ${$(r.aronium.price)}` : null, r.diffs.includes('cost') ? `Cost: app ${$(r.app.cost)}, Aronium ${$(r.aronium.cost)}` : null,
                    r.diffs.includes('vat') ? `VAT: app ${VAT[r.app.vat]}, Aronium ${r.aronium.rate === null ? 'none set' : `${r.aronium.rate}%`}` : null,
                    r.diffs.includes('barcode') ? `New barcode${r.app.barcodes.length === 1 ? '' : 's'} for Aronium: ${r.app.barcodes.join(', ')}` : null].filter(Boolean).join(' · ')} right={r.code} />
                {boss ? (
                  <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
                    {r.diffs.filter((d) => d !== 'barcode').map((d) => <Btn key={d} testID={`au-take-${d}-${r.code}`} title={`Aronium's ${d === 'vat' ? 'VAT' : d} is right`} size="sm" variant="ghost" onPress={() => { if (act(() => AU.takeAronium(user, shop, r.itemUid, d), 'Taken into the app') !== null) bump((n) => n + 1); }} />)}
                  </View>
                ) : null}
              </View>
            ))}
          </Section>
          {boss ? <Btn testID="au-master" title={cmp.master ? 'The app keeps prices and costs (tap to take Aronium\'s again)' : 'From now on the app keeps prices and costs'} size="sm" variant="ghost" onPress={() => { I.setAppMaster(user, shop, !cmp.master); bump((n) => n + 1); }} /> : null}
        </>
      ) : null}
    </Screen>
  );
}
