// v3.9.3 FCCC price-controlled products: new FCCC master price lists (found on the FCCC website by the app), the
// controlled products with their FCCC price, and any shop selling above it.
import React, { useState, useMemo } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, Explain, MoneyField } from '../../../ui/kit.js';
import * as F from '../fccc.js';
import { listProducts } from '../service.js';
import * as I from '../service.js';

const ddmm = (d) => String(d || '').split('-').reverse().join('.');
const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;

export function FcccScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [filter, setFilter] = useState(params.filter || 'all');
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState(null); // { uid, max, name }
  const [find, setFind] = useState('');
  const [busy, setBusy] = useState(false);
  const [, bump] = useState(0);
  const manage = can('inventory_manage');
  const lists = F.listFcccLists({ limit: 30 });
  const fresh = lists.filter((l) => !l.checked_at);
  const all = F.controlledProducts({ q });
  const rows = filter === 'over' ? all.filter((p) => p.over.length) : filter === 'auto' ? all.filter((p) => p.fccc_auto) : all;
  const st = F.fcccStatus();
  const changes = F.pendingChanges();
  const latest = F.latestLists().filter((l) => F.readState(l.uid).lines > 0);
  const [lineQ, setLineQ] = useState('');
  const lineHits = edit && lineQ.trim().length >= 2 ? latest.flatMap((l) => F.listLines(l.uid, { q: lineQ, limit: 15 }).map((x) => ({ ...x, list: l }))).slice(0, 20) : [];
  const [tick, setTick] = useState(0);
  const sugg = useMemo(() => (manage ? F.suggestLinks({ limit: 15 }) : []), [manage, tick, latest.length]); // worked out once, not on every key press
  const maybe = useMemo(() => { try { return F.possiblyOver(); } catch (e) { return []; } }, [tick, latest.length]); // eslint-disable-line
  const loose = changes.filter((c) => c.list.checked_at);
  const lookNow = async () => {
    setBusy(true);
    try {
      const r = await F.checkFccc({ force: true });
      ui.toast(r.fresh && r.fresh.length ? `${r.fresh.length} new FCCC list(s) found` : r.problems && r.problems.length && !r.found ? 'Could not reach the FCCC website – it is tried again later' : 'No new FCCC list');
    } catch (e) { ui.error(e); }
    setBusy(false); bump((x) => x + 1);
  };
  const save = () => {
    try { F.setFcccPrice(user, edit.uid, { controlled: true, max: edit.max, name: edit.name }); ui.toast('FCCC price saved'); setEdit(null); setFind(''); bump((x) => x + 1); setTick((n) => n + 1); } catch (e) { ui.error(e); }
  };
  const matches = find.trim().length >= 2 ? listProducts({ q: find, limit: 8 }) : [];
  return (
    <Screen title="FCCC controlled prices" subtitle={`${all.length} controlled product(s)`}>
      <Explain>The FCCC sets the highest price some products may be sold at, in its Master Price List. The app looks at the FCCC website a few times a day and does the check by itself: it marks our products that are on the list (🤖 – confirm them), takes the new FCCC prices when a new list comes out, and compares them with each shop's selling price that the till PCs send from Aronium. When every controlled product is within its FCCC price, the new list is ticked by the app. A product above its FCCC price at any shop is an urgent warning until the selling price is lowered in Aronium – the till PC sends the new price within minutes and the warning clears itself.</Explain>
      {fresh.map((l) => (
        <Card key={l.uid} tone="warn">
          <H>{`New list: ${l.list_name} – as at ${ddmm(l.as_at)}`}</H>
          <Text style={{ fontSize: 14, color: C.sub }}>{`Found ${String(l.found_at || '').slice(0, 16)}${F.readState(l.uid).lines ? ` · read: ${F.readState(l.uid).lines} price lines` : F.readState(l.uid).problem ? ` · could not read it: ${F.readState(l.uid).problem}` : ' · not read yet'}`}</Text>
          {changes.filter((c) => c.list.uid === l.uid).map((c) => <Text key={c.item.uid} style={{ fontSize: 15, color: c.missing ? C.warn : C.text, fontWeight: '700' }}>{`• ${c.text}`}</Text>)}
          {F.readState(l.uid).lines && !changes.some((c) => c.list.uid === l.uid) ? <Text style={{ fontSize: 15, color: C.success }}>None of our linked products changed price.</Text> : null}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', marginTop: 6 }}>
            <Btn testID={`fc-open-${l.as_at}`} title="Open the list (PDF)" icon="📄" size="md" variant="info" onPress={() => Linking.openURL(l.url).catch((e) => ui.error(e))} />
            {manage && changes.some((c) => c.list.uid === l.uid && !c.missing) ? (
              <Btn testID={`fc-accept-${l.as_at}`} title="Take the new FCCC prices (then change them in Aronium)" icon="✅" size="md" variant="success"
                onPress={() => { try { const n = F.acceptChanges(user, l.uid); ui.toast(`${n} FCCC price(s) updated – now change the selling prices in Aronium`); bump((x) => x + 1); } catch (e) { ui.error(e); } }} />
            ) : manage ? (
              <Btn testID={`fc-done-${l.as_at}`} title="Checked – prices changed in Aronium" icon="✅" size="md" variant="success"
                onPress={() => { try { F.markListChecked(user, l.uid); ui.toast('Ticked as checked'); bump((x) => x + 1); } catch (e) { ui.error(e); } }} />
            ) : null}
          </View>
        </Card>
      ))}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="fc-look" title={busy ? 'Looking…' : 'Look for a new list now'} icon="🔄" size="md" variant="secondary" disabled={busy} onPress={lookNow} />
      </View>
      <Hint>{`Last look: ${st.lastOk ? String(st.lastOk).slice(0, 16) : 'not yet'}${st.problem ? ` · last problem: ${st.problem}` : ''}`}</Hint>
      {loose.length ? (
        <Card tone="warn">
          <H>FCCC prices to update</H>
          {loose.map((c) => <Text key={c.item.uid} style={{ fontSize: 15 }}>{`• ${c.text}`}</Text>)}
          {manage ? <Btn testID="fc-accept-loose" title="Take the new FCCC prices" icon="✅" size="md" variant="success" onPress={() => { try { let n = 0; Array.from(new Set(loose.map((c) => c.list.uid))).forEach((u) => { n += F.acceptChanges(user, u); }); ui.toast(`${n} FCCC price(s) updated`); bump((x) => x + 1); } catch (e) { ui.error(e); } }} /> : null}
        </Card>
      ) : null}
      <Chips value={filter} onChange={setFilter} testIDPrefix="fc-f" options={[{ value: 'all', label: 'All controlled' }, { value: 'over', label: `Above the FCCC price (${all.filter((p) => p.over.length).length})` },
        { value: 'auto', label: `Marked by the app – confirm (${all.filter((p) => p.fccc_auto).length})` }, { value: 'maybe', label: `Possibly controlled, priced above (${maybe.length})` }]} />
      {filter === 'auto' ? <Hint>The app found these on the newest FCCC list (same size, same name) and is already watching them. Tap ✓ if it is right, or "Not controlled" if it is a different product – the app then never marks it again.</Hint> : null}
      {filter === 'maybe' ? (
        <>
          <Hint>These look like FCCC items but the match is not certain, so they are not marked. Each one is priced above the price of the FCCC line it looks like. Tap one to link it to the right line, or mark it not controlled.</Hint>
          {!maybe.length ? <Text style={{ fontSize: 15, color: C.success }}>Nothing to check. 👍</Text> : null}
          {maybe.map((g) => (
            <ListItem key={`m-${g.item.uid}`} testID={`fc-maybe-${g.item.code}`} tone="warn" title={g.item.name}
              sub={`Looks like FCCC: ${g.line.description}${g.line.qty ? ` · ${g.line.qty}` : ''} · ${g.over.map((x) => `${x.shop} ${$(x.price)}`).join(' · ')}`} right={`FCCC ${$(g.max)}`}
              onPress={manage ? () => setEdit({ uid: g.item.uid, name: '', max: '', title: g.item.name }) : null} />
          ))}
        </>
      ) : null}
      <Field testID="fc-q" label="Search" value={q} onChangeText={setQ} placeholder="Name or code" />
      {!rows.length ? <Text style={{ fontSize: 15, color: C.sub }}>{filter === 'over' ? 'Nothing is priced above the FCCC price.' : 'No products marked as FCCC controlled yet – add them below.'}</Text> : null}
      {filter === 'maybe' ? null : rows.map((p) => (
        <View key={p.uid}>
        <ListItem testID={`fc-p-${p.code}`} title={`${p.fccc_auto ? '🤖 ' : ''}${p.name}${p.fccc_name ? ` (FCCC: ${p.fccc_name})` : ''}`} tone={p.over.length ? 'danger' : undefined}
          sub={`${p.shops.map((s) => `${s.shop} ${$(s.price)}${p.over.includes(s) ? ' ▲ TOO HIGH' : ''}`).join(' · ')}${p.newMax !== null ? ` · NEW FCCC ${$(p.newMax)}` : ''}${p.fccc_key ? '' : ' · not linked to the list'}`} right={`FCCC ${$(p.fccc_max)}`}
          onPress={manage ? () => setEdit({ uid: p.uid, name: p.fccc_name || '', max: String(p.fccc_max || ''), title: p.name }) : null} />
        {p.fccc_auto && manage ? (
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
            <Btn testID={`fc-ok-${p.code}`} title="✓ Right – it is controlled" size="sm" variant="success" onPress={() => { try { F.confirmFccc(user, p.uid); bump((x) => x + 1); } catch (e) { ui.error(e); } }} />
            <Btn testID={`fc-no-${p.code}`} title="Not controlled" size="sm" variant="ghost" onPress={() => { try { F.rejectFccc(user, p.uid); bump((x) => x + 1); setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
          </View>
        ) : null}
        </View>
      ))}
      {manage ? (
        <Section title={edit ? `FCCC price – ${edit.title}` : 'Add a controlled product'}>
          {!edit ? (
            <>
              <Field testID="fc-find" label="Find the product" value={find} onChangeText={setFind} placeholder="Type 2 letters or more" />
              {!edit && sugg.length ? <Text style={{ fontSize: 16, fontWeight: '800', color: C.text, marginTop: 6 }}>Products we sell that look like they are on the FCCC list</Text> : null}
              {(edit ? [] : sugg).map((g) => (
                <ListItem key={g.item.uid} testID={`fc-sug-${g.item.code}`} title={g.item.name} sub={`FCCC: ${g.line.description}${g.line.qty ? ` · ${g.line.qty}` : ''} – tap to link`} right={g.max !== null ? $(g.max) : '—'}
                  onPress={() => { try { F.linkProduct(user, g.item.uid, g.line.list_uid, g.line.key); ui.toast(`${g.item.name} linked`); bump((n) => n + 1); setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
              ))}
              {matches.map((m) => <ListItem key={m.uid} testID={`fc-pick-${m.code}`} title={m.name} sub={`${m.code} · selling ${$(m.price)}${m.fccc ? ' · already controlled' : ''}`} onPress={() => setEdit({ uid: m.uid, name: m.fccc_name || '', max: m.fccc_max ? String(m.fccc_max) : '', title: m.name })} />)}
            </>
          ) : (
            <Card>
              {latest.length ? (
                <>
                  <Field testID="fc-line-q" label="Find it on the FCCC list (then its price follows the list by itself)" value={lineQ} onChangeText={setLineQ} placeholder="e.g. brown sugar 2kg" />
                  {lineHits.map((x) => (
                    <ListItem key={`${x.list_uid}${x.key}`} testID={`fc-line-${x.key}`} title={`${x.description}${x.qty ? ` · ${x.qty}` : ''}`} sub={`${x.list.list_name}${x.section ? ` · ${x.section}` : ''}`} right={F.lineMax(x) !== null ? $(F.lineMax(x)) : '—'}
                      onPress={() => { try { F.linkProduct(user, edit.uid, x.list_uid, x.key); ui.toast('Linked to the FCCC list'); setEdit(null); setLineQ(''); bump((n) => n + 1); setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
                  ))}
                  <Hint>Pick the line for the size you sell. Where the list has two lines ("…retails on its own" and "…wholesales to another party", or "Own" and "Others"), a shop buying from that supplier usually uses "wholesales to another party" / "Others" – check with the FCCC if unsure. Or type the FCCC price by hand below (it is then not checked against new lists).</Hint>
                </>
              ) : null}
              <MoneyField testID="fc-max" label="FCCC price – the highest price allowed (VAT included)" value={edit.max} onChange={(v) => setEdit({ ...edit, max: v })} />
              <Field testID="fc-name" label="Name on the FCCC list (optional)" value={edit.name} onChangeText={(v) => setEdit({ ...edit, name: v })} />
              <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
                <Btn testID="fc-save" title="Save" icon="💾" size="md" variant="success" onPress={save} />
                <Btn testID="fc-remove" title="Not controlled" size="md" variant="ghost" onPress={() => { try { F.rejectFccc(user, edit.uid); setEdit(null); bump((x) => x + 1); setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
                <Btn title="Cancel" size="md" variant="ghost" onPress={() => setEdit(null)} />
              </View>
            </Card>
          )}
        </Section>
      ) : null}
      {lists.filter((l) => l.checked_at).length ? (
        <Section title="Lists already checked">
          {lists.filter((l) => l.checked_at).map((l) => (
            <View key={l.uid}>
              <ListItem title={`${l.list_name} – as at ${ddmm(l.as_at)}`} sub={`Checked by ${l.checked_by_name} · ${String(l.checked_at).slice(0, 16)}${l.check_note ? ` · ${l.check_note}` : ''}`} onPress={() => Linking.openURL(l.url).catch(() => {})} />
              {manage ? <Btn testID={`fc-undo-${l.as_at}`} title="Undo the tick (not checked yet)" icon="↩️" size="sm" variant="ghost"
                onPress={async () => { const ok = await ui.confirm({ title: 'Undo the tick?', message: `${l.list_name} – as at ${ddmm(l.as_at)} goes back to "not checked" and its warning comes back.`, confirmText: 'Undo' }); if (!ok) return; try { F.uncheckList(user, l.uid); ui.toast('Tick undone'); bump((x) => x + 1); } catch (e) { ui.error(e); } }} /> : null}
            </View>
          ))}
        </Section>
      ) : null}
    </Screen>
  );
}

// v3.9.3 Products where Aronium and the app disagree about VAT (seen at the last Aronium product import).
export function VatCheckScreen() {
  const { user, can, nav } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const manage = can('inventory_manage') || ['owner', 'admin'].includes(user.role);
  const list = I.vatMismatches();
  return (
    <Screen title="VAT: Aronium vs the app" subtitle={`${list.length} product(s) different`}>
      <Explain>Aronium works out the VAT on every sale, so it must be set the same as here. For each product: if Aronium is right, tap "Aronium is right". If the app is right, change the tax on that product in Aronium – this warning goes away at the next Aronium product import.</Explain>
      {!list.length ? <Text style={{ fontSize: 16, color: C.success }}>Aronium and the app agree on VAT for every product.</Text> : null}
      {list.map((x) => (
        <Card key={x.uid} tone="warn">
          <H>{x.name}</H>
          <Text style={{ fontSize: 15 }}>{`Aronium: ${I.VAT_LABEL[x.aronium_vat]} · App: ${I.VAT_LABEL[x.vat_type]}${x.vat_set_at ? ` (set in the app ${String(x.vat_set_at).slice(0, 10)})` : ''}`}</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', marginTop: 6 }}>
            {manage ? <Btn testID={`vat-ar-${x.code}`} title="Aronium is right" size="sm" variant="secondary" onPress={() => { try { I.useAroniumVat(user, x.uid); ui.toast('Changed here'); bump((n) => n + 1); } catch (e) { ui.error(e); } }} /> : null}
            <Btn testID={`vat-open-${x.code}`} title="Open the product" size="sm" variant="ghost" onPress={() => nav.push('InvProduct', { uid: x.uid })} />
          </View>
        </Card>
      ))}
    </Screen>
  );
}
