// 1.0.0 staff screens (map s-goods / s-goods2 / s-goods3, s-dmg, o-dmg, s-stock) and products with no supplier:
//  • Goods came in – photo (read by the AI), then one compact page, all drop-downs; invoice no., amount and at least
//    one product (or "no products – just a bill") are required; products from the AI or added by hand.
//  • Damaged goods – which invoice it came on, does the supplier replace it.
//  • Damaged – waiting for replacement (office): mark replaced / credited.
//  • Stock take – join the shop's one stock take; "Ravi counted 12 in aisle 3 – add yours?".
import React, { useState, useRef } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Select, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { MoneyField, Hint } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { listSuppliers } from '../../payables/service.js';
import * as I from '../service.js';
import * as GI from '../goodsIn.js';
import * as OW from '../supplierOwed.js';
import * as SCN from '../sharedCount.js';
import { ItemPicker, fq, shops } from './common.js';
import { Row } from '../../verify/screens/TodayScreens.js';
import { Papers } from '../../verify/screens/Papers.js';
import { papersFor } from '../../verify/papers.js';

const $ = (n) => `$${(Math.round((Number(n) || 0) * 100) / 100).toFixed(2)}`;
const supOptions = () => [{ value: '', label: 'Choose the supplier' }].concat(listSuppliers().map((s) => ({ value: s.uid, label: s.name })));
const shopOptions = () => shops().map((s) => ({ value: s.code, label: s.name || s.code }));

// ---------------------------------------------------------------- Goods came in
export function GoodsCameInScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const bakery = user.role === 'worker' || params.what === 'bakery';
  const [f, setF] = useState({ what: bakery ? 'bakery' : 'stock', supplierUid: params.supplierUid || '', invoiceNo: '', date: dateStr(), amount: '', vat: '', shopCode: user.shop_code || (shops()[0] || {}).code || 'S1' });
  const [photos, setPhotos] = useState([]);
  const [lines, setLines] = useState([]);
  const [unmatched, setUnmatched] = useState([]);
  const [reading, setReading] = useState(false);
  const [readInfo, setReadInfo] = useState('');
  const [why, setWhy] = useState(null); // shown when the figures do not agree
  const readUid = useRef(null);
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const bill = f.what === 'bill';
  const read = async (list) => {
    setReading(true);
    try {
      const { readInvoicePhotos } = require('../../../platform/invoiceReader.js');
      const r = await readInvoicePhotos(user, list, { supplierUid: f.supplierUid || undefined });
      if (!r.ok) setReadInfo('Could not read the photo – type the invoice no. and amount yourself.');
      else {
        const x = r.result; readUid.current = r.readUid || null;
        setF((o) => ({ ...o, supplierUid: o.supplierUid || x.supplierUid || '', invoiceNo: o.invoiceNo || x.invoiceNo || '', amount: o.amount || (x.total ? String(x.total) : ''), vat: o.vat || (x.vat ? String(x.vat) : ''), date: x.invoiceDate && /^\d{4}-\d{2}-\d{2}$/.test(x.invoiceDate) && x.invoiceDate <= dateStr() ? x.invoiceDate : o.date }));
        const ok = (x.lines || []).filter((l) => l.itemUid);
        setLines((cur) => cur.concat(ok.filter((l) => !cur.some((c) => c.itemUid === l.itemUid)).map((l) => ({ itemUid: l.itemUid, name: l.itemName || l.name, qty: String(l.qty || 1), unitCost: l.unitCost !== undefined && l.unitCost !== null ? String(l.unitCost) : '' }))));
        setUnmatched((x.lines || []).filter((l) => !l.itemUid).map((l, i) => ({ key: `u${i}`, text: l.name || l.description || l.text || 'a line', qty: String(l.qty || 1), unitCost: l.unitCost })));
        setReadInfo(r.message || 'Read – check the figures.');
      }
    } catch (e) { setReadInfo(`Could not read the photo: ${e.message || e}`); }
    setReading(false);
  };
  const onPhotos = (list) => { setPhotos(list); if (list.length > photos.length) read(list); };
  const missing = GI.goodsMissing({ ...f, lines: lines.map((l) => ({ itemUid: l.itemUid, qty: l.qty })), noProducts: bill });
  const save = () => {
    if (reading) { ui.toast('Still reading the photo – one moment'); return; }
    try {
      GI.goodsCameIn(user, { ...f, noProducts: bill, photos, readUid: readUid.current, acceptReason: why || undefined, lines: lines.map((l) => ({ itemUid: l.itemUid, qty: l.qty, unitCost: l.unitCost === '' ? undefined : l.unitCost })) });
      nav.replace('SavedDone', { text: 'Sent to the office to check. You can still fix it until it is checked.' });
    } catch (e) {
      if (/Please check:/.test(e.message || '') && why === null) { setWhy(''); ui.alert({ title: 'The figures do not agree', message: `${e.message.replace(/ Fix it, or say why it is OK\.?$/, '')}\n\nFix them, or write why it is OK and Save again.`, tone: 'warn' }); return; }
      ui.error(e);
    }
  };
  return (
    <Screen title={bakery ? 'Ingredients delivered' : 'Goods came in'} subtitle={reading ? 'reading the photo…' : f.shopCode}
      footer={<Btn testID="gi-save" title={missing.length ? `Save – fill in ${missing.length === 1 ? missing[0].replace(/ \(.*\)$/, '') : `${missing.length} things`}` : 'Save'} icon="💾" variant={missing.length ? 'secondary' : 'success'} onPress={save} />}>
      <PhotoPicker testID="gi-photo" label="Photo of the invoice (or the PDF)" value={photos} onChange={onPhotos} required pages pdf />
      {reading ? <Banner testID="gi-reading" tone="info" message="Reading the invoice… the boxes fill in by themselves." /> : readInfo ? <Hint testID="gi-read">{readInfo}</Hint> : null}
      <Select testID="gi-what" label="What came in" value={f.what} onChange={set('what')} options={Object.entries(GI.WHAT_CAME).filter(([k]) => !(bakery && k === 'stock')).map(([value, label]) => ({ value, label }))} />
      <Select testID="gi-sup" label="Supplier *" value={f.supplierUid} onChange={set('supplierUid')} options={supOptions()} />
      {shops().length > 1 && !['staff', 'worker'].includes(user.role) ? <Select testID="gi-shop" label="Shop" value={f.shopCode} onChange={set('shopCode')} options={shopOptions()} /> : null}
      <Field testID="gi-no" label="Invoice no. *" value={f.invoiceNo} onChangeText={set('invoiceNo')} />
      <MoneyField testID="gi-amount" label="Amount * (the invoice total)" value={f.amount} onChange={set('amount')} />
      <MoneyField testID="gi-vat" label="VAT (if on the invoice)" value={f.vat} onChange={set('vat')} />
      {!bill ? (
        <Card>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`Products * (${lines.length})`}</Text>
          {lines.map((l, i) => (
            <View key={`${l.itemUid}-${i}`} style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, flexWrap: 'wrap' }}>
              <Text style={{ flexBasis: 160, flexGrow: 1, fontSize: 16, fontWeight: '700', color: C.text }}>{l.name}</Text>
              <View style={{ width: 90 }}><Field testID={`gi-qty-${i}`} label="How many" value={l.qty} onChangeText={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} keyboardType="decimal-pad" /></View>
              <View style={{ width: 120 }}><MoneyField testID={`gi-cost-${i}`} label="Cost each" value={l.unitCost} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, unitCost: v } : x)))} /></View>
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
            </View>
          ))}
          {unmatched.map((u) => (
            <View key={u.key} style={{ gap: 4 }}>
              <Text style={{ fontSize: 15, color: C.warn, fontWeight: '700' }}>{`${u.text} × ${u.qty} – not matched: which product is it?`}</Text>
              <ItemPicker testID={`gi-match-${u.key}`} shopCode={f.shopCode} supplierUid={f.supplierUid || undefined} label="Pick the product" onPick={(it) => { setLines(lines.concat([{ itemUid: it.uid, name: it.name, qty: u.qty, unitCost: u.unitCost !== undefined && u.unitCost !== null ? String(u.unitCost) : String(it.cost || '') }])); setUnmatched(unmatched.filter((x) => x.key !== u.key)); }} />
            </View>
          ))}
          <ItemPicker testID="gi-add" shopCode={f.shopCode} supplierUid={f.supplierUid || undefined} label="+ Add a product" exclude={lines.map((l) => l.itemUid)} onPick={(it) => setLines(lines.concat([{ itemUid: it.uid, name: it.name, qty: '1', unitCost: String(it.lastCost ?? it.cost ?? '') }]))} />
        </Card>
      ) : <Hint>No products – just a bill (power, repairs, a service…). It goes to the office as a bill.</Hint>}
      {why !== null ? <Field testID="gi-why" label="Why is it OK? (the figures do not agree)" value={why} onChangeText={setWhy} multiline /> : null}
      {missing.length ? <Text testID="gi-missing" style={{ fontSize: 15, color: C.danger, fontWeight: '700' }}>{`Still needed: ${missing.join(', ')}.`}</Text> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Damaged goods (staff)
export function DamagedGoodsScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const shop = user.shop_code || (shops()[0] || {}).code || 'S1';
  const [item, setItem] = useState(null);
  const [qty, setQty] = useState('');
  const [why, setWhy] = useState('');
  const [rc, setRc] = useState('');
  const [rep, setRep] = useState('');
  const [photos, setPhotos] = useState([]);
  const choices = item ? GI.invoicesForProduct(item.uid, shop) : [];
  const save = () => {
    try {
      GI.damagedGoods(user, { itemUid: item && item.uid, qty, why, receiptUid: rc || undefined, replaces: rep === '' ? undefined : rep === 'yes', photos, shopCode: shop });
      nav.replace('SavedDone', { text: rep === 'yes' ? 'Kept aside – it stays on the office list until the supplier replaces it.' : 'Taken off the stock as damaged.' });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Damaged goods" footer={<Btn testID="dg-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      {item ? <Row title={item.name} sub="tap to change" onPress={() => { setItem(null); setRc(''); }} /> : <ItemPicker testID="dg-item" shopCode={shop} label="Product" onPick={(it) => setItem(it)} />}
      <Field testID="dg-qty" label="How many" value={qty} onChangeText={setQty} keyboardType="decimal-pad" />
      <Select testID="dg-why" label="What's wrong" value={why} onChange={setWhy} options={[{ value: '', label: 'Choose' }].concat(Object.entries(GI.DAMAGE_WHY).map(([value, label]) => ({ value, label })))} />
      <Select testID="dg-inv" label="Came on invoice" value={rc} onChange={setRc} options={[{ value: '', label: item ? (choices.length ? 'Choose the invoice' : 'No delivery of it in the last 90 days') : 'Choose the product first' }].concat(choices.map((c) => ({ value: c.receiptUid, label: c.label })))} />
      <Select testID="dg-rep" label="Supplier replaces?" value={rep} onChange={setRep} options={[{ value: '', label: 'Choose' }, { value: 'yes', label: 'Yes – keep aside until replaced' }, { value: 'no', label: 'No – write it off' }]} />
      <PhotoPicker testID="dg-photo" label="Photo" value={photos} onChange={setPhotos} required />
    </Screen>
  );
}

// ---------------------------------------------------------------- Damaged – waiting for replacement (office, o-dmg)
export function DamagedWaitingScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [how, setHow] = useState('received');
  const [note, setNote] = useState('');
  const shop = ['manager', 'supervisor'].includes(user.role) ? user.shop_code : undefined;
  const list = OW.listOwed({ shopCode: shop });
  const shown = params.uid && list.some((o) => o.uid === params.uid) ? list.filter((o) => o.uid === params.uid) : list;
  const done = (o) => { try { OW.settleOwed(user, o.uid, { how, note }); ui.toast(how === 'received' ? 'Replaced' : how === 'credited' ? 'Credited' : 'Written off'); setNote(''); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Damaged goods" subtitle={`${list.length} waiting`}>
      {!shown.length ? <Banner tone="success" message="Nothing waiting – everything is replaced or credited." /> : null}
      {shown.filter(Boolean).map((o) => (
        <Card key={o.uid}>
          <Row testID={`dw-${o.uid}`} title={`${o.left} × ${o.name}${o.invoice_no ? ` – ${o.invoice_no}` : ''}`} sub={`${o.supplier_name} · ${o.reason} · ${o.days ? `${o.days} days` : 'today'}${o.told_at ? ' · supplier told' : ''}`} right={$(o.leftValue)} level={o.days >= 7 ? 'bad' : 'warn'} />
          <Papers groups={papersFor({ table: 'supplier_owed', uid: o.uid })} testID={`dw-papers-${o.uid}`} size={90} />
          <Select testID={`dw-how-${o.uid}`} label="What happened" value={how} onChange={setHow} options={Object.entries(OW.OWED_DONE).map(([value, label]) => ({ value, label }))} />
          {how === 'written_off' ? <Field testID={`dw-note-${o.uid}`} label="Why is it written off?" value={note} onChangeText={setNote} /> : null}
          <Btn testID={`dw-done-${o.uid}`} title={how === 'received' ? 'Mark replaced' : how === 'credited' ? 'Credit note came' : 'Write it off'} variant="success" size="md" onPress={() => done(o)} />
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- Stock take – join (s-stock)
export function StockTakeJoinScreen({ params = {} }) {
  const { user, nav, can } = useApp();
  // 1.0.0 the stock take row opens this page: the full stock take pages (first stock take, part counts, sheets,
  // check & finish) stay one tap away for those who run stock takes
  const all = can && (can('stocktake_count') || can('stocktake_approve'))
    ? <Btn testID="sj-all" title="All stock takes – start, check & finish" icon="🗂️" size="md" variant="secondary" onPress={() => nav.push('StockTakes', {})} /> : null;
  const ui = useUI();
  const [shop, setShop] = useState(params.shopCode || user.shop_code || (shops()[0] || {}).code || 'S1');
  const [, bump] = useState(0);
  const [item, setItem] = useState(null);
  const [qty, setQty] = useState('');
  const [spot, setSpot] = useState('');
  const tap = useRef(SCN.newTapId());
  const j = SCN.join(user, shop);
  const c = j.count;
  const start = () => { try { SCN.join(user, shop, { start: true }); ui.toast('Stock take started – every phone joins it'); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  if (!c) {
    return (
      <Screen title="Stock take" subtitle={shop}>
        {shops().length > 1 && !['staff', 'worker'].includes(user.role) ? <Select testID="sj-shop" label="Shop" value={shop} onChange={setShop} options={shopOptions()} /> : null}
        <Banner testID="sj-none" tone="info" message="No stock take is on at this shop." />
        {SCN.mayStart(user) ? <Btn testID="sj-start" title="Start the stock take" icon="📋" variant="success" onPress={start} /> : <Hint>A supervisor or manager starts it; then every phone joins it here.</Hint>}
        {all}
      </Screen>
    );
  }
  const pr = SCN.progress(c.uid);
  const seen = item ? SCN.countedSoFar(c.uid, item.uid, user) : null;
  const add = () => {
    try {
      const r = SCN.addMine(user, c.uid, item.uid, qty, { spot, tapId: tap.current });
      tap.current = SCN.newTapId();
      ui.toast(`${item.name}: total ${fq(r.total)}`); setQty(''); bump((n) => n + 1);
    } catch (e) { ui.error(e); }
  };
  const total = seen ? seen.total + (Number(qty) || 0) : 0;
  return (
    <Screen title="Stock take" subtitle={`${c.shop_code} · started ${String(c.started_at || '').slice(11, 16)}`}>
      <View testID="sj-strip" style={{ backgroundColor: C.infoSoft || '#E1EAFB', borderRadius: 12, padding: 12 }}>
        <Text style={{ fontSize: 16, color: C.text }}>{`${pr.phones || 1} phone${pr.phones === 1 ? '' : 's'} counting · ${pr.done} of ${pr.lines} products done`}</Text>
      </View>
      {item ? <Row testID="sj-item" title={item.name} sub={seen.text} right={seen.total ? fq(seen.total) : ''} onPress={() => { setItem(null); setQty(''); }} />
        : <ItemPicker testID="sj-find" shopCode={c.shop_code} label="Product (scan or search)" onPick={(it) => { setItem(it); tap.current = SCN.newTapId(); }} />}
      {item ? (
        <>
          <Field testID="sj-qty" label="How many here" value={qty} onChangeText={setQty} keyboardType="decimal-pad" />
          <Select testID="sj-where" label="Where" value={spot} onChange={setSpot} options={[{ value: '', label: 'Choose' }].concat(SCN.PLACES.map((p) => ({ value: p, label: p })))} />
          <Btn testID="sj-add" title={`Add – total ${fq(total)}`} icon="➕" variant="success" onPress={add} />
        </>
      ) : null}
      {pr.people.length ? <Hint>{`Counting: ${pr.people.join(', ')}`}</Hint> : null}
      {all}
    </Screen>
  );
}

// ---------------------------------------------------------------- products with no supplier: many at once
export function NoSupplierQuickScreen() {
  const { user, can } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [sup, setSup] = useState('');
  const [group, setGroup] = useState('');
  const [q, setQ] = useState('');
  const [ticked, setTicked] = useState([]);
  const manage = can('inventory_manage') || ['owner', 'admin'].includes(user.role);
  const all = I.productsWithoutSupplier({ limit: 100000 });
  const list = all.filter((p) => (!group || (p.group_name || '(no group)') === group) && (!q.trim() || `${p.name} ${p.code}`.toLowerCase().includes(q.trim().toLowerCase())));
  const give = () => { try { const n = GI.assignSupplier(user, ticked, sup); ui.toast(`${n} product${n === 1 ? '' : 's'} given the supplier`); setTicked([]); bump((x) => x + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Products with no supplier" subtitle={`${all.length} left to sort`} footer={manage ? <Btn testID="nq-give" title={`Give ${ticked.length} product${ticked.length === 1 ? '' : 's'} this supplier`} icon="✓" variant={ticked.length && sup ? 'success' : 'secondary'} onPress={give} /> : null}>
      <Hint>Pick the supplier, tick their products (or a whole Aronium group), then tap the green button. Products also get their supplier by themselves when a delivery or invoice comes in.</Hint>
      {manage ? <Select testID="nq-sup" label="Supplier" value={sup} onChange={setSup} options={supOptions()} /> : null}
      <Select testID="nq-group" label="Aronium group" value={group} onChange={(v) => { setGroup(v); setTicked([]); }} options={[{ value: '', label: 'All groups' }].concat(GI.noSupplierGroups().map((g) => ({ value: g.group, label: `${g.group} (${g.n})` })))} />
      <Field testID="nq-q" label="Find" value={q} onChangeText={setQ} />
      {manage && list.length ? <Btn testID="nq-all" title={ticked.length === Math.min(list.length, 300) ? 'Untick all' : `Tick all ${Math.min(list.length, 300)} shown`} size="sm" variant="secondary" onPress={() => setTicked(ticked.length === Math.min(list.length, 300) ? [] : list.slice(0, 300).map((p) => p.uid))} /> : null}
      {list.slice(0, 300).map((p) => {
        const on = ticked.includes(p.uid);
        return <Row key={p.uid} testID={`nq-${p.code}`} title={`${on ? '☑' : '☐'} ${p.name}`} sub={[p.code, p.group_name].filter(Boolean).join(' · ')} onPress={manage ? () => setTicked(on ? ticked.filter((x) => x !== p.uid) : ticked.concat([p.uid])) : undefined} />;
      })}
    </Screen>
  );
}
