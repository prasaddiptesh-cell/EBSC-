// Inventory screens: overview, stock list, one product, write-offs, transfers between shops, Aronium import,
// cost price changes, and the inventory settings.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, Table, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, Action, Actions, ReasonButton } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { pickTextFile } from '../../../platform/files.js';
import { listSuppliers } from '../../payables/service.js';
import * as I from '../service.js';
import { shops, shopName, shopChips, useShop, ShopPicker, ItemPicker, QtyBox, fq } from './common.js';

const { $ } = I;

// ---------------------------------------------------------------- overview
export function InventoryHomeScreen() {
  const { nav, can } = useApp();
  const [shop, setShop] = useShop();
  const v = I.stockValue(shop);
  const low = I.stockList({ shopCode: shop, filter: 'low' }).length;
  const alerts = I.invAlerts([shop]);
  const toReceive = I.listPOs({ shopCode: shop, status: 'to_receive' }).length;
  const incoming = I.listTransfers({ shopCode: shop, status: 'sent' }).filter((t) => t.to_shop === shop).length;
  const counting = I.openCounts(shop).length;
  return (
    <Screen title="Inventory" subtitle="Stock, orders and stock takes – each shop separately">
      <ShopPicker value={shop} onChange={setShop} testIDPrefix="inv-shop" />
      <Stats items={[
        { label: 'Stock value (at cost)', value: $(v.value), sub: `${v.products} products with movements`, testID: 'inv-value', onPress: () => nav.push('InvStock', { shopCode: shop }) },
        { label: 'Low / to reorder', value: String(low), color: low ? C.warn : undefined, onPress: () => nav.push('InvStock', { shopCode: shop, filter: 'low' }) },
        v.negative ? { label: 'Below zero', value: String(v.negative), color: C.danger, sub: 'sold more than received – check', onPress: () => nav.push('InvStock', { shopCode: shop, filter: 'negative' }) } : null,
      ]} />
      {alerts.map((a, i) => <Banner key={i} tone={a.tone} message={a.text} />)}
      <Section title="Every day">
        <Actions>
          {can('inventory_view') ? <Action testID="inv-stock" icon="📦" title="Stock on hand" note="What this shop has, what is running low, what is not selling. Tap a product for its full history." onPress={() => nav.push('InvStock', { shopCode: shop })} /> : null}
          {can('po_receive') ? <Action testID="inv-receive" icon="🚚" title="Receive a delivery" badge={toReceive ? `${toReceive} expected` : null} note="Tick off a delivery against its purchase order. Stock and cost prices update; price changes are flagged." onPress={() => nav.push('POList', { shopCode: shop, status: 'to_receive' })} /> : null}
          {can('po_create') ? <Action testID="inv-po" icon="📝" title="Purchase orders" note="Make an order (the app suggests what to order), check the supplier budget, send it by Viber." onPress={() => nav.push('POList', { shopCode: shop })} /> : null}
          {can('inventory_manage') ? <Action testID="inv-adjust" icon="🗑️" title="Write off / adjust" note="Damaged, expired, stolen or used stock. Always with a reason – every unit is accounted for." onPress={() => nav.push('StockAdjust', { shopCode: shop })} /> : null}
          {can('inventory_manage') || can('inventory_view') ? <Action testID="inv-transfers" icon="🔁" title="Move stock between shops" badge={incoming ? `${incoming} to receive` : null} note="Step 1: the sending shop sends it. Step 2: the other shop checks what arrived." onPress={() => nav.push('Transfers', { shopCode: shop })} /> : null}
          {can('stocktake_count') || can('stocktake_approve') ? <Action testID="inv-count" icon="📋" title="Stock take" badge={counting ? 'under way' : null} note="Count the shelves. Stock is frozen while counting; results (short / over in $) show at the end." onPress={() => nav.push('StockTakes', { shopCode: shop })} /> : null}
        </Actions>
      </Section>
      <Section title="Office">
        <Actions>
          {can('inventory_manage') ? <Action testID="inv-return" icon="↩️" title="Return to supplier" note="Goods sent back. Shows as 'waiting for credit' until the supplier's credit note is linked." onPress={() => nav.push('SupplierReturn', { shopCode: shop })} /> : null}
          {can('inventory_view') ? <Action testID="inv-costs" icon="💲" title="Cost price changes" badge={alerts.some((a) => a.go === 'CostChanges') ? 'new' : null} note="Every time a supplier charges a different price. Check the margin and change the selling price." onPress={() => nav.push('CostChanges')} /> : null}
          {can('inventory_manage') ? <Action testID="inv-import" icon="📥" title="Import from Aronium" note="Products (with prices and stock) or the day's sales, from a CSV file exported from Aronium." onPress={() => nav.push('InvImport', { shopCode: shop })} /> : null}
          {can('inventory_setup') ? <Action testID="inv-setup" icon="⚙️" title="Inventory settings" note="Supplier budgets and delivery days, approval limits, cost rules, stock-take rules, write-off reasons." onPress={() => nav.push('InventorySetup')} /> : null}
        </Actions>
      </Section>
      <Explain title="How is stock worked out?">
        Stock is never typed in over the top. Each shop's stock is the total of everything that happened to it: what came in (deliveries, transfers in, stock
        found), what went out (sales from Aronium, transfers out, write-offs, returns to suppliers) and the corrections from stock takes. That way every unit can
        be traced to a date, a person and a reason. Sales are read from Aronium – nothing is ever written back to Aronium.
      </Explain>
    </Screen>
  );
}

// ---------------------------------------------------------------- stock list
const FILTERS = [
  { value: 'all', label: 'All' }, { value: 'low', label: 'Low' }, { value: 'order', label: 'To order' }, { value: 'out', label: 'Out' },
  { value: 'dead', label: 'Not selling' }, { value: 'negative', label: 'Below 0' },
];
export function StockScreen({ params }) {
  const { nav } = useApp();
  const [shop, setShop] = useShop(params.shopCode);
  const [filter, setFilter] = useState(params.filter || 'all');
  const [q, setQ] = useState('');
  const [group, setGroup] = useState('');
  const rows = I.stockList({ shopCode: shop, q, filter, group: group || undefined, limit: 400 });
  const total = rows.reduce((s, r) => s + r.value, 0);
  return (
    <Screen title="Stock on hand" subtitle={`${shopName(shop)} · ${rows.length} products · ${$(total)} at cost`}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="st-shop" />
      <Field testID="st-q" label="Search" value={q} onChangeText={setQ} placeholder="Name, code or barcode" />
      <Chips value={filter} onChange={setFilter} options={FILTERS} testIDPrefix="st-f" />
      {I.listGroups().length ? <Select label="Group" value={group} onChange={setGroup} options={[{ value: '', label: 'All groups' }].concat(I.listGroups().map((g) => ({ value: g, label: g })))} /> : null}
      <Hint>{{
        all: 'Every product stocked at this shop.', low: 'At or below the reorder level set for this shop.', order: 'Suggested to order: based on the last weeks of sales, the supplier\'s delivery days and what is already on order.',
        out: 'None left.', dead: 'Has stock but has not sold for a long time – money sitting on the shelf.', negative: 'More sold than received: a delivery was probably not entered, or the product is under another code.',
      }[filter]}</Hint>
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing here.</Text> : null}
      {rows.map((r) => (
        <ListItem key={r.uid} testID={`st-${r.code}`} onPress={() => nav.push('InvProduct', { uid: r.uid, shopCode: shop })}
          title={r.name} sub={`${r.code}${r.location ? ` · ${r.location}` : ''} · sells ${r.perWeek}/week${r.daysLeft !== null ? ` · ~${r.daysLeft} days left` : ''}${r.on_order ? ` · ${fq(r.on_order)} on order` : ''}${r.suggest ? ` · order ${fq(r.suggest)}` : ''}`}
          right={`${fq(r.on_hand)} ${r.unit || ''}`} rightSub={$(r.value)}
          badge={r.on_hand < 0 ? 'BELOW 0' : r.on_hand <= 0 ? 'OUT' : r.low ? 'LOW' : r.dead ? 'NOT SELLING' : r.belowCost ? 'BELOW COST' : null}
          badgeColor={r.on_hand <= 0 || r.belowCost ? C.danger : C.warn} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- one product
export function ProductScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [shop, setShop] = useShop(params.shopCode);
  const it = I.itemAtShop(params.uid, shop);
  const [f, setF] = useState(() => (it ? { code: it.code, name: it.name, barcode: it.barcode || '', groupName: it.group_name || '', unit: it.unit || 'each', cost: String(it.cost), price: String(it.price),
    vatType: it.vat_type, supplierUid: it.supplier_uid || '', packSize: String(it.pack_size || 1), notes: it.notes || '' } : null));
  const [s, setS] = useState(null);
  if (!it) return <Screen title="Product"><Text>Not found.</Text></Screen>;
  const sh = s || { reorderLevel: String(it.shop ? it.shop.reorder_level : 0), reorderQty: String(it.shop ? it.shop.reorder_qty : 0), price: it.shop && it.shop.price !== null ? String(it.shop.price) : '', location: (it.shop && it.shop.location) || '', active: it.shop ? !!it.shop.active : true };
  const setSh = (k) => (v) => setS({ ...sh, [k]: v });
  const row = I.stockList({ shopCode: shop, q: it.code }).find((r) => r.uid === it.uid);
  const moves = I.movesFor({ itemUid: it.uid, shopCode: shop, limit: 60 });
  const manage = can('inventory_manage');
  const sups = listSuppliers();
  return (
    <Screen title={it.name} subtitle={`${it.code}${it.barcode ? ` · ${it.barcode}` : ''} · ${shopName(shop)}`}>
      <Chips value={shop} onChange={(v) => { setShop(v); setS(null); }} options={shopChips()} testIDPrefix="pr-shop" />
      <Stats items={[
        { label: 'On hand here', value: `${fq(row ? row.on_hand : I.stockOf(it.uid, shop))} ${it.unit || ''}`, color: row && row.on_hand < 0 ? C.danger : undefined },
        { label: 'Sells', value: `${row ? row.perWeek : 0}/week`, sub: row && row.daysLeft !== null ? `about ${row.daysLeft} days left` : 'no recent sales' },
        { label: 'Cost / price here', value: `${$(it.cost)} / ${$(it.shopPrice)}`, sub: row && row.margin !== null ? `margin ${row.margin}% (price incl. VAT)` : '', color: row && row.belowCost ? C.danger : undefined },
        row && row.on_order ? { label: 'On order', value: fq(row.on_order) } : null,
      ]} />
      <Section title="Every shop">
        <Table columns={[{ key: 'shop', title: 'Shop', width: 80 }, { key: 'qty', title: 'On hand', align: 'right' }, { key: 'price', title: 'Price', align: 'right' }, { key: 'lvl', title: 'Reorder at', align: 'right' }]}
          rows={shops().map((x) => { const a = I.itemAtShop(it.uid, x.code); return { shop: x.code, qty: fq(I.stockOf(it.uid, x.code)), price: $(a.shopPrice), lvl: a.shop ? fq(a.shop.reorder_level) : '—' }; })} />
      </Section>
      {manage ? (
        <Section title={`At ${shopName(shop)}`}>
          <Hint>Reorder level: when stock falls to this, the product shows as low. Order quantity: how many to order at a time. Leave the price empty to use the normal price.</Hint>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field testID="pr-lvl" label="Reorder level" value={sh.reorderLevel} onChangeText={setSh('reorderLevel')} keyboardType="decimal-pad" /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field testID="pr-rq" label="Order quantity" value={sh.reorderQty} onChangeText={setSh('reorderQty')} keyboardType="decimal-pad" /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField testID="pr-sprice" label="Price at this shop" value={sh.price} onChange={setSh('price')} placeholder={String(it.price)} /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field label="Shelf / location" value={sh.location} onChangeText={setSh('location')} placeholder="e.g. Aisle 3" /></View>
          </View>
          <Chips value={sh.active ? 'y' : 'n'} onChange={(v) => setSh('active')(v === 'y')} options={[{ value: 'y', label: 'Sold at this shop' }, { value: 'n', label: 'Not sold here' }]} />
          <Btn testID="pr-save-shop" title="Save for this shop" size="md" variant="success" onPress={() => act(() => I.saveItemShop(user, { itemUid: it.uid, shopCode: shop, ...sh }), 'Saved') && setS(null)} />
        </Section>
      ) : null}
      {manage && f ? (
        <Section title="Product details (all shops)">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            <View style={{ flexBasis: 220, flexGrow: 2 }}><Field label="Name" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} /></View>
            <View style={{ flexBasis: 120, flexGrow: 1 }}><Field label="Code" value={f.code} onChangeText={(v) => setF({ ...f, code: v })} /></View>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Barcode" value={f.barcode} onChangeText={(v) => setF({ ...f, barcode: v })} /></View>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Group" value={f.groupName} onChangeText={(v) => setF({ ...f, groupName: v })} /></View>
            <View style={{ flexBasis: 120, flexGrow: 1 }}><Select label="Unit" value={f.unit} onChange={(v) => setF({ ...f, unit: v })} options={Array.from(new Set(I.invRules().units.concat([f.unit]))).map((u) => ({ value: u, label: u }))} /></View>
            <View style={{ flexBasis: 120, flexGrow: 1 }}><Field label="Pack size" value={f.packSize} onChangeText={(v) => setF({ ...f, packSize: v })} keyboardType="decimal-pad" /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField label="Cost (excl. VAT)" value={f.cost} onChange={(v) => setF({ ...f, cost: v })} /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField label="Normal selling price" value={f.price} onChange={(v) => setF({ ...f, price: v })} /></View>
          </View>
          <Hint>Pack size: orders are rounded up to whole packs (e.g. 12 for a carton of 12). Cost is updated by itself when deliveries are received.</Hint>
          <Chips value={f.vatType} onChange={(v) => setF({ ...f, vatType: v })} options={[{ value: 'standard', label: 'VAT 12.5%' }, { value: 'zero', label: 'Zero rated' }, { value: 'exempt', label: 'Exempt' }]} />
          <Select label="Main supplier" value={f.supplierUid} onChange={(v) => setF({ ...f, supplierUid: v })} options={[{ value: '', label: '—' }].concat(sups.map((x) => ({ value: x.uid, label: x.name })))} />
          <Btn testID="pr-save" title="Save product" size="md" variant="success" onPress={() => act(() => I.saveItem(user, { uid: it.uid, ...f, active: !!it.active }), 'Product saved')} />
        </Section>
      ) : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {manage ? <Btn title="Write off / adjust" icon="🗑️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('StockAdjust', { shopCode: shop, itemUid: it.uid })} /> : null}
        <Btn title="Cost history" icon="💲" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('CostChanges', { itemUid: it.uid })} />
      </View>
      <Section title="History at this shop">
        <Hint>Every movement, newest first. Sold = from Aronium, one line per day.</Hint>
        {!moves.length ? <Text style={{ color: C.sub }}>No movements yet.</Text> : null}
        {moves.map((m) => (
          <ListItem key={m.uid} title={`${I.MOVE_LABEL[m.type] || m.type}${m.reason && m.type !== 'sale' ? ` – ${m.reason}` : ''}`} sub={`${m.move_date}${m.by_name ? ` · ${m.by_name}` : ''}${m.note ? ` · ${m.note}` : ''}`}
            right={`${m.qty > 0 ? '+' : ''}${fq(m.qty)}`} rightSub={m.unit_cost !== null ? $(Math.abs(m.qty) * m.unit_cost) : ''} tone={m.qty < 0 && m.type === 'adjust' ? 'warn' : undefined} />
        ))}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- write-off / adjust
export function StockAdjustScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const rules = I.invRules();
  const [shop, setShop] = useShop(params.shopCode);
  const [item, setItem] = useState(params.itemUid ? I.getItem(params.itemUid) : null);
  const [dir, setDir] = useState('off');
  const [qty, setQty] = useState('');
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(dateStr());
  const [photos, setPhotos] = useState([]);
  const have = item ? I.stockOf(item.uid, shop) : 0;
  const n = Number(qty) || 0;
  const save = () => {
    const ok = act(() => I.adjustStock(user, { itemUid: item && item.uid, shopCode: shop, qty: dir === 'off' ? -n : n, reason, note, date, photos }), 'Recorded');
    if (ok) { setItem(null); setQty(''); setNote(''); setPhotos([]); }
  };
  return (
    <Screen title="Write off / adjust stock" subtitle={shopName(shop)}
      footer={<Btn testID="adj-save" title={item && n ? `${dir === 'off' ? 'Take off' : 'Add'} ${fq(n)} · ${$(n * item.cost)}` : 'Save'} icon="💾" variant={dir === 'off' ? 'danger' : 'success'} onPress={save} />}>
      <Hint>Use this for stock that is damaged, expired, stolen, used by staff, or found. Deliveries, sales, transfers and stock takes have their own screens.</Hint>
      <ShopPicker value={shop} onChange={setShop} testIDPrefix="adj-shop" />
      {item ? (
        <Card>
          <Row label="Product" value={`${item.name} (${item.code})`} bold />
          <Row label="On hand now" value={`${fq(have)} ${item.unit || ''}`} />
          <Btn title="Choose another product" size="sm" variant="secondary" onPress={() => setItem(null)} />
        </Card>
      ) : <ItemPicker shopCode={shop} onPick={(r) => setItem(I.getItem(r.uid))} testID="adj-find" />}
      <Chips value={dir} onChange={setDir} options={[{ value: 'off', label: '− Take off' }, { value: 'on', label: '+ Add (found)' }]} testIDPrefix="adj-dir" />
      <Label>How many</Label>
      <QtyBox value={qty} onChange={setQty} testID="adj-qty" />
      <Label>Reason</Label>
      <Chips value={reason} onChange={setReason} options={rules.adjustReasons} testIDPrefix="adj-r" />
      <Field testID="adj-note" label={reason === 'Other' ? 'What happened? (required)' : 'Note (optional)'} value={note} onChangeText={setNote} multiline />
      <DateField label="Date" value={date} onChange={setDate} />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo (optional – e.g. the damaged goods)" />
      {item && n * item.cost > rules.writeOffApproveOver ? <Banner tone="warn" message={`Over ${$(rules.writeOffApproveOver)}: this will show on the owner's write-off check list.`} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- transfers
export function TransfersScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [shop, setShop] = useShop(params.shopCode);
  const [mode, setMode] = useState('list');
  const [to, setTo] = useState('');
  const [lines, setLines] = useState([]);
  const [notes, setNotes] = useState('');
  const [open, setOpen] = useState(null);
  const [got, setGot] = useState({});
  const [note, setNote] = useState('');
  const list = I.listTransfers({ shopCode: shop, limit: 60 });
  const others = shops().filter((s) => s.code !== shop);
  if (mode === 'new') {
    const value = lines.reduce((s, l) => s + (Number(l.qty) || 0) * l.cost, 0);
    return (
      <Screen title="Send stock to another shop" subtitle={`From ${shopName(shop)}`} onBack={() => setMode('list')}
        footer={<Btn testID="tr-send" title={`Send · ${$(value)}`} icon="📤" variant="success" onPress={() => {
          const r = act(() => I.sendTransfer(user, { fromShop: shop, toShop: to, lines: lines.map((l) => ({ itemUid: l.uid, qty: l.qty })), notes }), 'Sent – the other shop now checks it in');
          if (r) { setMode('list'); setLines([]); setNotes(''); }
        }} />}>
        <Hint>Step 1 of 2. The stock leaves this shop now. It is added to the other shop when they tick it in (step 2), so anything lost on the way shows up.</Hint>
        <Label>Send to</Label>
        <Chips value={to} onChange={setTo} options={others.map((s) => ({ value: s.code, label: s.code }))} testIDPrefix="tr-to" />
        <ItemPicker shopCode={shop} exclude={lines.map((l) => l.uid)} onPick={(r) => setLines(lines.concat([{ uid: r.uid, name: r.name, unit: r.unit, cost: r.cost, have: r.on_hand, qty: '1' }]))} testID="tr-find" />
        {lines.map((l, i) => (
          <Card key={l.uid}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{fq(l.have)} {l.unit} here · {$(l.cost)} each</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <QtyBox value={l.qty} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} testID={`tr-qty-${i}`} />
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
            </View>
          </Card>
        ))}
        <Field label="Note (optional)" value={notes} onChangeText={setNotes} />
      </Screen>
    );
  }
  return (
    <Screen title="Stock between shops" subtitle={shopName(shop)}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="tr-shop" />
      {can('inventory_manage') ? <Btn testID="tr-new" title="Send stock to another shop" icon="📤" variant="info" onPress={() => setMode('new')} /> : null}
      <Hint>Transfers are two steps: the sending shop records what it sent, the receiving shop counts what arrived. Any difference is reported as lost in transit.</Hint>
      {!list.length ? <Text style={{ color: C.sub }}>No transfers yet.</Text> : null}
      {list.map((t) => {
        const incoming = t.to_shop === shop && t.status === 'sent';
        return (
          <View key={t.uid} style={{ gap: 8 }}>
            <ListItem testID={`tr-${t.transfer_no}`} onPress={() => { setOpen(open === t.uid ? null : t.uid); setGot({}); setNote(''); }}
              title={`${t.transfer_no} · ${t.from_shop} → ${t.to_shop}`} sub={`${t.send_date} · ${t.lines.length} products · sent by ${t.sent_by_name}${t.received_by_name ? ` · received by ${t.received_by_name}` : ''}`}
              right={$(t.value)} badge={t.status === 'sent' ? (incoming ? 'TO RECEIVE' : 'ON THE WAY') : t.status === 'void' ? 'CANCELLED' : t.short_value > 0.004 ? `SHORT ${$(t.short_value)}` : 'RECEIVED'}
              badgeColor={t.status === 'sent' ? C.warn : t.short_value > 0.004 ? C.danger : t.status === 'void' ? C.sub : C.success} />
            {open === t.uid ? (
              <Card>
                {t.lines.map((l) => (
                  <View key={l.itemUid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <Text style={{ flex: 1, fontSize: 16, color: C.text }}>{l.name} – sent {fq(l.qty)}{l.qtyReceived !== null && l.qtyReceived !== undefined ? `, arrived ${fq(l.qtyReceived)}` : ''}</Text>
                    {incoming ? <QtyBox value={got[l.itemUid] === undefined ? String(l.qty) : got[l.itemUid]} onChange={(v) => setGot({ ...got, [l.itemUid]: v })} testID={`tr-got-${l.itemUid}`} /> : null}
                  </View>
                ))}
                {t.notes ? <Text style={{ color: C.sub }}>Note: {t.notes}</Text> : null}
                {incoming ? (
                  <>
                    <Hint>Count what actually arrived. If anything is missing or broken, change the number and say what happened.</Hint>
                    <Field label="Note (needed if anything is missing)" value={note} onChangeText={setNote} />
                    <Btn testID="tr-receive" title="Received – add to this shop" icon="✅" variant="success" onPress={() => act(() => I.receiveTransfer(user, t.uid, { received: got, note }), 'Received') && setOpen(null)} />
                  </>
                ) : null}
                {t.status === 'sent' && t.from_shop === shop && can('inventory_manage') ? (
                  <ReasonButton title="Cancel this transfer" prompt="Why is it cancelled?" confirm="Cancel transfer" onDo={(why) => act(() => I.voidTransfer(user, t.uid, why), 'Cancelled – stock back')} />
                ) : null}
              </Card>
            ) : null}
          </View>
        );
      })}
    </Screen>
  );
}

// ---------------------------------------------------------------- Aronium import
export function InvImportScreen({ params }) {
  const { user } = useApp();
  const ui = useUI();
  const [shop, setShop] = useShop(params.shopCode);
  const [kind, setKind] = useState('products');
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState('');
  const [mapping, setMapping] = useState(null);
  const [opening, setOpening] = useState(false);
  const [date, setDate] = useState(addDays(dateStr(), -1));
  const [preview, setPreview] = useState(null);
  const fields = kind === 'products' ? I.PRODUCT_FIELDS : I.SALES_FIELDS;
  const rows = text ? I.parseCsv(text) : [];
  const headers = rows[0] || [];
  const map = mapping || (headers.length ? I.guessMapping(headers, fields) : {});
  const run = (dryRun) => {
    try {
      const r = kind === 'products'
        ? I.importProductsCsv(user, text, { shopCode: shop, mapping: map, openingStock: opening, dryRun })
        : I.importSalesCsv(user, text, { shopCode: shop, date, mapping: map, dryRun });
      setPreview({ ...r, dryRun });
      if (!dryRun) ui.toast('Imported');
    } catch (e) { ui.error(e); }
  };
  const pick = async () => {
    try { const f = await pickTextFile(); if (f) { setText(f.text); setFileName(f.name); setMapping(null); setPreview(null); } } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Import from Aronium" subtitle={shopName(shop)}>
      <Hint>In Aronium: Management › Products › Export (CSV), or Reports › Products sold › Export. Copy the file to this tablet (email, Google Drive or USB), then choose it here. Aronium itself is never changed.</Hint>
      <ShopPicker value={shop} onChange={(v) => { setShop(v); setPreview(null); }} testIDPrefix="imp-shop" />
      <Chips value={kind} onChange={(v) => { setKind(v); setMapping(null); setPreview(null); }} options={[{ value: 'products', label: 'Products & prices' }, { value: 'sales', label: 'Sales (products sold)' }]} testIDPrefix="imp-kind" />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="imp-pick" title={fileName ? `File: ${fileName}` : 'Choose the CSV file'} icon="📂" variant="info" style={{ flexGrow: 1 }} onPress={pick} />
      </View>
      <Field testID="imp-text" label="…or paste the CSV text here" value={text.length > 4000 ? `${text.slice(0, 4000)}…` : text} onChangeText={(t) => { setText(t); setMapping(null); setPreview(null); }} multiline />
      {headers.length ? (
        <Section title={`Match the columns (${rows.length - 1} rows)`}>
          <Hint>The app has guessed which column is which. Check them – especially Code, Cost and Price.</Hint>
          {fields.map((f) => (
            <Select key={f.key} label={`${f.label}${f.need ? ' *' : ''}`} value={map[f.key] === undefined ? '' : String(map[f.key])}
              onChange={(v) => { const m = { ...map }; if (v === '') delete m[f.key]; else m[f.key] = Number(v); setMapping(m); setPreview(null); }}
              options={[{ value: '', label: '— not in the file —' }].concat(headers.map((h, i) => ({ value: String(i), label: `${h || `(column ${i + 1})`} – e.g. ${(rows[1] || [])[i] || ''}` })))} />
          ))}
          {kind === 'products' ? (
            <>
              <Chips value={opening ? 'y' : 'n'} onChange={(v) => setOpening(v === 'y')} options={[{ value: 'n', label: 'Products and prices only' }, { value: 'y', label: 'Also set the stock from the Quantity column' }]} testIDPrefix="imp-open" />
              <Hint>Set the stock only when starting out (or after a full stock take in Aronium). The difference is recorded as "Opening / import".</Hint>
            </>
          ) : (
            <>
              {map.date === undefined ? <DateField label="These sales are for" value={date} onChange={setDate} /> : null}
              <Hint>Sales for a day can be imported again (e.g. after a late sale): the day is replaced, never counted twice.</Hint>
            </>
          )}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Btn testID="imp-check" title="Check first" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => run(true)} />
            <Btn testID="imp-go" title="Import" size="md" variant="success" style={{ flexGrow: 1 }} disabled={!preview || !preview.dryRun} onPress={() => run(false)} />
          </View>
        </Section>
      ) : null}
      {preview ? (
        <Card tone={preview.dryRun ? undefined : 'success'}>
          <H>{preview.dryRun ? 'What will happen' : 'Done'}</H>
          {kind === 'products' ? (
            <>
              <Row label="New products" value={String(preview.added)} />
              <Row label="Changed" value={String(preview.changed)} />
              <Row label="No change" value={String(preview.same)} />
              <Row label="Cost price different" value={String(preview.costChanged)} />
              {opening ? <Row label="Stock set" value={String(preview.stockSet)} /> : null}
              {preview.errors.slice(0, 10).map((e) => <Text key={e} style={{ color: C.warn }}>{e}</Text>)}
            </>
          ) : (
            <>
              <Row label="Days" value={preview.days.join(', ') || '—'} />
              <Row label="Products" value={String(preview.lines)} />
              <Row label="Units sold" value={fq(preview.units)} />
              {preview.unknown.length ? <Text style={{ color: C.warn }}>Not in the product list (import products first): {preview.unknown.slice(0, 20).join(', ')}</Text> : null}
            </>
          )}
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- cost price changes
export function CostChangesScreen({ params }) {
  const { user, can } = useApp();
  const act = useAct();
  const [show, setShow] = useState(params.itemUid ? 'all' : 'new');
  const [price, setPrice] = useState({});
  const [shop, setShop] = useState('');
  const list = I.costChanges({ unseenOnly: show === 'new', itemUid: params.itemUid, limit: 200 });
  return (
    <Screen title="Cost price changes" subtitle={params.itemUid ? (I.getItem(params.itemUid) || {}).name : 'Flagged when a delivery costs more or less than before'}>
      <Chips value={show} onChange={setShow} options={[{ value: 'new', label: 'To look at' }, { value: 'all', label: 'All' }]} testIDPrefix="cc-show" />
      <Hint>When a supplier charges a different price, the product's cost changes and it is listed here. Check the margin and, if needed, change the selling price – then change it in Aronium too.</Hint>
      {!list.length ? <Text style={{ color: C.sub }}>Nothing to look at.</Text> : null}
      {list.map((c) => (
        <Card key={c.uid} tone={c.belowCost ? 'danger' : undefined}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{c.name} ({c.code})</Text>
          <Row label="Cost" value={`${$(c.old_cost)} → ${$(c.new_cost)}${c.pct !== null ? ` (${c.pct > 0 ? '+' : ''}${c.pct}%)` : ''}`} bold color={c.diff > 0 ? C.danger : C.success} />
          <Row label="When / from" value={`${c.change_date} · ${c.supplier_name || c.source || ''}${c.shop_code ? ` · ${c.shop_code}` : ''}`} />
          <Row label="Selling price / margin" value={`${$(c.price)}${c.margin !== null ? ` · ${c.margin}%` : ''}`} color={c.belowCost ? C.danger : undefined} />
          {c.seen_at ? <Text style={{ color: C.sub }}>Checked by {c.seen_by_name}</Text> : can('inventory_manage') ? (
            <View style={{ gap: 8 }}>
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID={`cc-price-${c.code}`} label="New selling price (optional)" value={price[c.uid] || ''} onChange={(v) => setPrice({ ...price, [c.uid]: v })} /></View>
                <View style={{ flexBasis: 200, flexGrow: 1 }}><Select label="For" value={shop} onChange={setShop} options={[{ value: '', label: 'All shops' }].concat(shopChips())} /></View>
              </View>
              <Btn testID={`cc-ok-${c.code}`} title={price[c.uid] ? 'Save price and mark checked' : 'Mark checked'} size="md" variant="success" onPress={() => act(() => I.reviewCostChange(user, c.uid, { newPrice: price[c.uid], shopCode: shop || undefined }), 'Checked')} />
            </View>
          ) : null}
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings (admin)
export function InventorySetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const [r, setR] = useState(() => { const x = I.invRules(); return { ...x, adjustReasons: x.adjustReasons.join('\n'), units: x.units.join('\n') }; });
  const [sup, setSup] = useState('');
  const s = sup ? listSuppliers({ includeInactive: true }).find((x) => x.uid === sup) : null;
  const [b, setB] = useState(null);
  const bb = b || (s ? { budgetWeekly: s.budget_weekly == null ? '' : String(s.budget_weekly), budgetMonthly: s.budget_monthly == null ? '' : String(s.budget_monthly), leadDays: s.lead_days == null ? '' : String(s.lead_days), viber: s.viber || s.phone || '' } : {});
  const set = (k) => (v) => setR({ ...r, [k]: v });
  const num = (k, label, hint) => (
    <View style={{ flexBasis: 220, flexGrow: 1, gap: 4 }}>
      <Field testID={`set-${k}`} label={label} value={String(r[k])} onChangeText={set(k)} keyboardType="decimal-pad" />
      {hint ? <Hint>{hint}</Hint> : null}
    </View>
  );
  const use = s ? I.budgetUse(s.uid) : null;
  return (
    <Screen title="Inventory settings" subtitle="Admin: budgets, approvals, cost and stock-take rules">
      <Section title="Supplier budgets & ordering">
        <Hint>Set how much may be ordered from a supplier per week (Saturday–Friday) and/or per month. Orders, and invoices that did not come through an order, count against it.</Hint>
        <Select testID="set-sup" label="Supplier" value={sup} onChange={(v) => { setSup(v); setB(null); }} options={[{ value: '', label: 'Choose a supplier' }].concat(listSuppliers().map((x) => ({ value: x.uid, label: x.name })))} />
        {s ? (
          <>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="set-bw" label="Weekly budget" value={bb.budgetWeekly} onChange={(v) => setB({ ...bb, budgetWeekly: v })} placeholder="none" /></View>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="set-bm" label="Monthly budget" value={bb.budgetMonthly} onChange={(v) => setB({ ...bb, budgetMonthly: v })} placeholder="none" /></View>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Delivery takes (days)" value={bb.leadDays} onChangeText={(v) => setB({ ...bb, leadDays: v })} keyboardType="number-pad" /></View>
              <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Viber number" value={bb.viber} onChangeText={(v) => setB({ ...bb, viber: v })} placeholder="+679 …" /></View>
            </View>
            {use ? <Hint>{`This week: ${$(use.week)} used${use.weekBudget !== null ? ` of ${$(use.weekBudget)}` : ''}. This month: ${$(use.month)}${use.monthBudget !== null ? ` of ${$(use.monthBudget)}` : ''}.`}</Hint> : null}
            <Btn testID="set-sup-save" title="Save supplier ordering" size="md" variant="success" onPress={() => act(() => I.saveSupplierOrdering(user, { supplierUid: s.uid, ...bb }), 'Saved') && setB(null)} />
          </>
        ) : null}
      </Section>
      <Section title="Purchase orders">
        <Label>When an order is over the supplier budget</Label>
        <Chips value={r.budgetMode} onChange={set('budgetMode')} testIDPrefix="set-bmode" options={[{ value: 'warn', label: 'Just warn' }, { value: 'approve', label: 'Needs approval' }, { value: 'block', label: 'Not allowed' }]} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {num('approveOver', 'Any order over this needs approval ($)', '0 = no limit.')}
          {num('invoiceTolerance', 'Invoice may differ by ($)', 'Supplier invoice against what was received.')}
          {num('priceTolerancePct', 'Unit price may differ by (%)', 'Delivered price against the order.')}
          {num('defaultLeadDays', 'Delivery days (default)', 'Used when a supplier has none set.')}
        </View>
      </Section>
      <Section title="Cost prices & reordering">
        <Chips value={r.costMethod} onChange={set('costMethod')} options={[{ value: 'last', label: 'Cost = last price paid' }, { value: 'average', label: 'Cost = average' }]} />
        <Explain>"Last price paid" keeps the cost the same as the latest invoice – simple and what Aronium shows. "Average" mixes the new price with the stock already on the shelf, which spreads out price changes.</Explain>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {num('costFlagPct', 'Flag cost changes over (%)', '0 = flag every change.')}
          {num('salesDays', 'Reorder: look at sales of the last (days)')}
          {num('coverDays', 'Reorder: order enough for (days)', 'After the delivery arrives.')}
          {num('deadDays', '"Not selling" after (days)')}
          {num('writeOffApproveOver', 'Write-offs over this go on the check list ($)')}
        </View>
        <Field label="Write-off reasons (one per line)" value={r.adjustReasons} onChangeText={set('adjustReasons')} multiline />
        <Field label="Units (one per line)" value={r.units} onChangeText={set('units')} multiline />
      </Section>
      <Section title="Stock take">
        <Chips value={r.blindCount ? 'y' : 'n'} onChange={(v) => set('blindCount')(v === 'y')} options={[{ value: 'y', label: 'Blind count (counters do not see the expected number)' }, { value: 'n', label: 'Show the expected number' }]} />
        <Chips value={r.uncounted} onChange={set('uncounted')} options={[{ value: 'leave', label: 'Products not counted: leave as they are' }, { value: 'zero', label: 'Products not counted: set to 0' }]} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {num('countTolerance', 'Recount if off by more than (units)')}
          {num('countValueTolerance', '…and more than ($)', 'Both must be exceeded to ask for a recount.')}
          {num('cycleDays', 'Rolling count: suggest products not counted for (days)')}
        </View>
      </Section>
      <Btn testID="set-save" title="Save settings" icon="💾" variant="success" onPress={() => act(() => I.saveInvRules(user, r), 'Settings saved')} />
    </Screen>
  );
}
