// 1.0.0 Packs that are also sold loose (Maggi 5 pack and one Maggi): link them so the loose sales come off the pack.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint } from '../../../ui/kit.js';
import * as LL from '../looseLinks.js';
import * as I from '../service.js';
import { ItemPicker } from './common.js';

export function LooseLinksScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  const [loose, setLoose] = useState(params.looseUid ? I.getItem(params.looseUid) : null);
  const [pack, setPack] = useState(params.packUid ? I.getItem(params.packUid) : null);
  const [per, setPer] = useState('');
  const [, bump] = useState(0);
  const list = LL.allLoose();
  const save = () => { if (act(() => LL.linkLoose(user, loose.uid, pack.uid, per), 'Linked – loose sales now come off the pack') !== null) { setLoose(null); setPack(null); setPer(''); bump((n) => n + 1); } };
  return (
    <Screen title="Packs sold loose" subtitle="One product holds the stock – the pack">
      <Hint>In Aronium a pack and its loose one are two products (e.g. "Maggi 5 pack" and "Maggi single"). Link them here: each loose sale takes its share off the pack's stock (3 loose = 0.6 of a 5 pack), the loose one is not counted on its own, and at the stock take the pack has a "loose" box.</Hint>
      <Card>
        <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Link a loose product to its pack</Text>
        {loose ? <ListItem title={`Loose: ${loose.name}`} sub={loose.code} onPress={() => setLoose(null)} rightSub="change" right="" /> : <ItemPicker testID="ll-loose" label="1. The LOOSE product (sold one at a time)" onPick={setLoose} />}
        {pack ? <ListItem title={`Pack: ${pack.name}`} sub={pack.code} onPress={() => setPack(null)} rightSub="change" right="" /> : <ItemPicker testID="ll-pack" label="2. The PACK it comes out of" onPick={setPack} />}
        <Field testID="ll-per" label="3. How many loose ones in one pack" value={per} onChangeText={setPer} keyboardType="numeric" />
        <Btn testID="ll-save" title="Link them" variant="success" disabled={!loose || !pack} onPress={save} />
      </Card>
      {!list.length ? <Banner tone="info" message="No packs linked yet." /> : null}
      {list.map((x) => (
        <View key={x.loose.uid} style={{ gap: 4 }}>
          <ListItem testID={`ll-${x.loose.code}`} title={`${x.loose.name} → ${x.pack.name}`} sub={`${x.per} loose = 1 pack · each loose sale takes ${Math.round((1 / x.per) * 1000) / 1000} of a pack`} />
          <Btn testID={`ll-un-${x.loose.code}`} title="Unlink" size="sm" variant="ghost" onPress={() => { if (act(() => LL.unlinkLoose(user, x.loose.uid), 'Unlinked') !== null) bump((n) => n + 1); }} />
        </View>
      ))}
    </Screen>
  );
}
