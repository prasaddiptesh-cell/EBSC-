// Stock losses (shrinkage) by product and reason, products short again and again, and stock about to expire.
import React, { useState } from 'react';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Chips, Row, Section, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { DateField, Hint } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import * as I from '../service.js';
import { shopChips, useShop, fq } from './common.js';

export function ShrinkageScreen() {
  const [shop, setShop] = useShop();
  const [from, setFrom] = useState(addDays(dateStr(), -90));
  const [to, setTo] = useState(dateStr());
  let sh = { byReason: [], total: 0, transitShort: 0 }; let prods = []; let rl = [];
  try { sh = I.shrinkage({ shopCode: shop, from, to }); prods = I.shrinkageByProduct({ shopCode: shop, from, to, limit: 30 }); rl = I.repeatLosers({ shopCode: shop }); } catch (e) { /* shown empty */ }
  return (
    <Screen title="Stock losses" subtitle="What went missing, why, and which products keep going missing">
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="sk-shop" />
      <DateField label="From" value={from} onChange={setFrom} />
      <DateField label="To" value={to} onChange={setTo} />
      <Card tone={sh.total < 0 ? 'danger' : 'success'}><Row label="Total lost (at cost)" value={I.$(sh.total)} bold /></Card>
      <Section title="By reason">
        {sh.byReason.map((r, i) => <Row key={i} label={r.reason || r.type} value={`${I.$(r.value)} · ${r.times}×`} />)}
        {sh.transitShort ? <Row label="Short on transfers between shops" value={I.$(-sh.transitShort)} /> : null}
      </Section>
      <Section title="Products that keep coming up short">
        {!rl.length ? <Hint>None – good.</Hint> : rl.map((r) => <Text key={`${r.itemUid}${r.shopCode}`} style={{ color: C.danger }}>• {r.name} ({r.shopCode}): short in {r.short} of the last {r.counts} counts · {I.$(r.lost)}</Text>)}
      </Section>
      <Section title="Biggest losses by product">
        {prods.map((p) => <Row key={`${p.item_uid}${p.shop_code}`} label={`${p.name} (${p.shop_code})`} value={`${fq(p.q)} · ${I.$(p.v)}${p.reasons.length ? ` · ${p.reasons.slice(0, 2).join(', ')}` : ''}`} />)}
      </Section>
    </Screen>
  );
}

export function StockExpiryScreen() {
  const [days, setDays] = useState(30);
  let list = [];
  try { list = I.expiringSoon({ days }); } catch (e) { list = []; }
  return (
    <Screen title="Expiring soon" subtitle="Seen while counting – sell first, mark down or return">
      <Chips value={days} onChange={setDays} testIDPrefix="ex-days" options={[{ value: 14, label: '2 weeks' }, { value: 30, label: '1 month' }, { value: 90, label: '3 months' }]} />
      {!list.length ? <Hint>Nothing noted as expiring. Note expiry dates while counting (📅 Expiry).</Hint> : null}
      {list.map((e, i) => (
        <Card key={i} tone={e.expiry <= dateStr() ? 'danger' : 'warn'}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{e.name}</Text>
          <Text style={{ color: C.sub }}>{e.shop_code} · expires {e.expiry}{e.expiry_qty ? ` · ${fq(e.expiry_qty)}` : ''} · seen {e.count_date}</Text>
        </Card>
      ))}
    </Screen>
  );
}
