// v3.5 purchasing screens: today's orders, supplier order days, suppliers from Aronium, an order's change history,
// correcting a delivery, and reading a supplier invoice (item lines matched to the order / delivery, layout learning).
import React, { useState, useMemo } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, Choice, TimeField } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, ListItem, Stats, Hint, Explain, ReasonButton, ReasonField } from '../../../ui/kit.js';
import { dateStr, addDays, stamp } from '../../../services/core.js';
import { pickTextFile } from '../../../platform/files.js';
import { snapshotNow } from '../../../services/snapshots.js';
import { listSuppliers, getSupplier } from '../../payables/service.js';
import { readInvoicePhotos } from '../../../platform/invoiceReader.js';
import * as I from '../service.js';
import * as SC from '../schedules.js';
import * as PA from '../poAmend.js';
import * as AR from '../aronium.js';
import * as IR from '../invoiceRead.js';
import { shops, shopName, useShop, QtyBox, fq } from './common.js';

const { $ } = I;
const supOptions = () => listSuppliers().map((s) => ({ value: s.uid, label: s.name }));
const STATE_TONE = { sent: 'success', due: 'warn', started: 'warn', missed: 'danger', later: undefined, skipped: undefined };
const STATE_COLOR = { sent: C.success, due: C.warn, started: C.warn, missed: C.danger, later: C.sub, skipped: C.sub };

// ---------------------------------------------------------------- today's orders
export function TodaysOrdersScreen() {
  const { nav, user, can } = useApp();
  const act = useAct();
  const now = stamp();
  const today = dateStr();
  const mine = SC.reminderShops(user);
  const [scope, setScope] = useState(Array.isArray(mine) && mine.length ? 'mine' : 'all');
  const shopCodes = scope === 'mine' && Array.isArray(mine) ? mine : undefined;
  const rows = SC.ordersForDay(today, { now, shopCodes });
  const tomorrow = SC.ordersForDay(addDays(today, 1), { now, shopCodes });
  const counts = rows.reduce((o, r) => ({ ...o, [r.state]: (o[r.state] || 0) + 1 }), {});
  const card = (r, i, prefix) => (
    <Card key={`${prefix}${i}`} tone={STATE_TONE[r.state]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        <Text style={{ flex: 1, fontSize: 18, fontWeight: '800', color: C.text }}>{r.supplierName} · {r.shopCode}</Text>
        <Text testID={`to-state-${prefix}${i}`} style={{ fontSize: 15, fontWeight: '900', color: STATE_COLOR[r.state] }}>{SC.ORDER_STATE[r.state]}</Text>
      </View>
      <Text style={{ fontSize: 14, color: C.sub }}>
        {r.cutoff ? `Cut-off ${r.cutoff}` : 'No cut-off time'}{r.state !== 'sent' && r.cutoff ? ` · reminder from ${r.remindAt.slice(11, 16)}` : ''}{r.deliveryDate ? ` · delivery ${r.deliveryDate}` : ''}
        {r.po ? ` · ${r.po.po_no} (${I.PO_STATUS[r.po.status]})` : ''}{r.skip ? ` · not ordering: ${r.skip.reason || ''} (${r.skip.by})` : ''}
      </Text>
      {r.state !== 'sent' && r.state !== 'skipped' ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {r.po ? <Btn testID={`to-open-${prefix}${i}`} title={`Open ${r.po.po_no}`} size="sm" variant="info" onPress={() => nav.push('POView', { uid: r.po.uid })} />
            : can('po_create') ? <Btn testID={`to-make-${prefix}${i}`} title="Make the order" icon="📝" size="sm" variant="success" onPress={() => nav.push('POEdit', { shopCode: r.shopCode, supplierUid: r.supplierUid, suggest: true })} /> : null}
          {can('po_create') ? <ReasonButton testID={`to-skip-${prefix}${i}`} title="Not ordering today" prompt="Why is no order needed?" confirm="Not ordering" variant="secondary" size="sm"
            onDo={(w) => act(() => SC.skipOrder(user, { supplierUid: r.supplierUid, shopCode: r.shopCode, date: r.date, reason: w }), 'Noted – no reminder today')} /> : null}
        </View>
      ) : r.po ? <Btn title={`Open ${r.po.po_no}`} size="sm" variant="ghost" onPress={() => nav.push('POView', { uid: r.po.uid })} /> : null}
    </Card>
  );
  return (
    <Screen title="Today's orders" subtitle={`${today} · from the supplier order days`}>
      {Array.isArray(mine) && mine.length ? <Chips value={scope} onChange={setScope} testIDPrefix="to-scope" options={[{ value: 'mine', label: `My shop (${mine.join(', ')})` }, { value: 'all', label: 'All shops' }]} /> : null}
      <Stats items={[
        { label: 'To order now', value: String((counts.due || 0) + (counts.started || 0)), color: counts.due || counts.started ? C.warn : undefined },
        { label: 'Cut-off missed', value: String(counts.missed || 0), color: counts.missed ? C.danger : undefined },
        { label: 'Sent', value: String(counts.sent || 0), color: C.success },
        { label: 'Later today', value: String(counts.later || 0) },
      ]} />
      <Hint>The shop's manager and the owner get a reminder before each cut-off (Home and a phone notification). Once the order is sent there is no reminder. A missed cut-off shows red.</Hint>
      {!rows.length ? <Text testID="to-none" style={{ color: C.sub }}>No supplier takes orders today. Set the order days in Inventory › Settings › Supplier order days.</Text> : null}
      {rows.map((r, i) => card(r, i, ''))}
      {tomorrow.length ? (
        <Section title={`Tomorrow (${addDays(today, 1)})`}>
          {tomorrow.map((r, i) => card(r, i, 't'))}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- supplier order days
const REMIND = [{ value: '30', label: '30 min' }, { value: '60', label: '1 hour' }, { value: '120', label: '2 hours' }, { value: '240', label: '4 hours' }, { value: '720', label: 'Night before (12 h)' }, { value: '1440', label: 'A day before' }];
const DAY_ORDER = [6, 0, 1, 2, 3, 4, 5]; // Saturday first
export function SupplierSchedulesScreen({ params }) {
  const { user } = useApp();
  const act = useAct();
  const [sup, setSup] = useState(params.supplierUid || '');
  const [shop, setShop] = useState('*');
  const [draft, setDraft] = useState(null);
  const all = sup ? SC.getSchedules(sup) : null;
  const row = all ? (shop === '*' ? all.base : all.shops[shop]) : null;
  const eff = sup && shop !== '*' ? SC.effectiveSchedule(sup, shop) : null;
  const start = () => {
    const base = row && row.days ? row.days : shop !== '*' && eff ? eff.days : [];
    return { days: Object.fromEntries(base.map((d) => [d.day, { cutoff: d.cutoff || '', deliveryDay: d.deliveryDay === null || d.deliveryDay === undefined ? '' : String(d.deliveryDay) }])),
      reminder: String(row && row.reminder_mins !== null && row.reminder_mins !== undefined ? row.reminder_mins : eff ? eff.reminderMins : SC.DEFAULT_REMINDER_MINS), skip: !!(row && row.skip), sameDays: shop !== '*' && !(row && row.days) };
  };
  const d = draft || (sup ? start() : null);
  const set = (x) => setDraft({ ...d, ...x });
  const toggle = (day) => { const days = { ...d.days }; if (days[day]) delete days[day]; else days[day] = { cutoff: '', deliveryDay: '' }; set({ days }); };
  const save = () => act(() => SC.saveSchedule(user, {
    supplierUid: sup, shopCode: shop, skip: d.skip, reminderMins: d.reminder,
    days: shop !== '*' && d.sameDays ? null : Object.entries(d.days).map(([day, v]) => ({ day: Number(day), cutoff: v.cutoff, deliveryDay: v.deliveryDay })),
  }), 'Order days saved') && setDraft(null);
  const list = SC.scheduledSuppliers();
  return (
    <Screen title="Supplier order days" subtitle="When each supplier takes orders">
      <Explain title="How reminders work">For each supplier: the days they take orders, the cut-off time on each day, the day it is delivered, and how long before the cut-off to remind. One schedule for all shops; a shop can have its own days or not order from them at all. The shop's manager and the owner are reminded (Home warning and phone notification) until the order is sent.</Explain>
      <Select testID="ss-sup" label="Supplier" value={sup} onChange={(v) => { setSup(v); setDraft(null); setShop('*'); }} options={[{ value: '', label: 'Choose a supplier' }].concat(supOptions())} />
      {sup ? (
        <>
          <Label>For</Label>
          <Chips value={shop} onChange={(v) => { setShop(v); setDraft(null); }} testIDPrefix="ss-shop" options={[{ value: '*', label: 'All shops' }].concat(shops().filter((s) => /^S/.test(s.code)).map((s) => ({ value: s.code, label: `${s.code} only${all.shops[s.code] ? ' ✎' : ''}` })))} />
          {shop !== '*' ? (
            <>
              <Chips value={d.skip ? 'skip' : d.sameDays ? 'same' : 'own'} onChange={(v) => set({ skip: v === 'skip', sameDays: v === 'same' })} testIDPrefix="ss-mode"
                options={[{ value: 'same', label: 'Same days as all shops' }, { value: 'own', label: 'Its own days' }, { value: 'skip', label: 'Does not order from them' }]} />
              {all.shops[shop] ? <Btn testID="ss-clear" title={`${shop} follows all shops again`} size="sm" variant="ghost" onPress={() => act(() => SC.clearShopChange(user, sup, shop), 'Done') && setDraft(null)} /> : null}
            </>
          ) : null}
          {!d.skip && !(shop !== '*' && d.sameDays) ? (
            <Section title="Order days">
              <Chips value={null} onChange={(v) => toggle(Number(v))} testIDPrefix="ss-day" options={DAY_ORDER.map((n) => ({ value: String(n), label: `${d.days[n] ? '☑' : '☐'} ${SC.DAY_SHORT[n]}` }))} />
              {DAY_ORDER.filter((n) => d.days[n]).map((n) => (
                <Card key={n}>
                  <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{SC.DAY_NAMES[n]}</Text>
                  <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                    <View style={{ flexBasis: 200, flexGrow: 1 }}><TimeField testID={`ss-cut-${n}`} label="Order by (cut-off)" value={d.days[n].cutoff} optional showNow={false} usual={['08:00', '09:00', '10:00', '12:00', '14:00', '16:00']}
                      onChange={(v) => set({ days: { ...d.days, [n]: { ...d.days[n], cutoff: v } } })} /></View>
                    <View style={{ flexBasis: 200, flexGrow: 1 }}><Choice label="Delivered on" value={d.days[n].deliveryDay} testIDPrefix={`ss-del-${n}`}
                      onChange={(v) => set({ days: { ...d.days, [n]: { ...d.days[n], deliveryDay: v } } })} options={[{ value: '', label: 'Not set' }].concat(DAY_ORDER.map((k) => ({ value: String(k), label: SC.DAY_NAMES[k] })))} /></View>
                  </View>
                </Card>
              ))}
            </Section>
          ) : null}
          {!d.skip ? <Choice label="Remind before the cut-off" value={d.reminder} onChange={(v) => set({ reminder: v })} options={REMIND.some((r) => r.value === d.reminder) ? REMIND : REMIND.concat([{ value: d.reminder, label: `${d.reminder} min` }])} testIDPrefix="ss-rem" /> : null}
          <Btn testID="ss-save" title="Save order days" icon="💾" variant="success" onPress={save} />
          {all.base ? <Hint>{`All shops: ${SC.describeDays(all.base.days)}${all.base.active ? '' : ' (switched off)'}. ${Object.values(all.shops).map((s) => `${s.shop_code}: ${s.skip ? 'does not order' : s.days ? SC.describeDays(s.days) : 'same days'}`).join(' · ')}`}</Hint> : null}
        </>
      ) : null}
      <Section title="Suppliers with order days">
        {!list.length ? <Text style={{ color: C.sub }}>None yet.</Text> : null}
        {list.map((s) => {
          const g = SC.getSchedules(s.uid);
          return <ListItem key={s.uid} testID={`ss-list-${s.uid}`} title={s.name} sub={g.base ? SC.describeDays(g.base.days) : `Old order days: ${s.order_days}`} rightSub={Object.keys(g.shops).length ? `${Object.keys(g.shops).join(', ')} changed` : ''}
            onPress={() => { setSup(s.uid); setShop('*'); setDraft(null); }} />;
        })}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- suppliers from Aronium
export function SupplierImportScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState('');
  const [mapping, setMapping] = useState(null);
  const [preview, setPreview] = useState(null);
  const rows = useMemo(() => (text ? I.parseCsv(text) : []), [text]);
  const headers = rows[0] || [];
  const map = mapping || (headers.length ? I.guessMapping(headers, AR.SUPPLIER_FIELDS) : {});
  const run = async (dryRun) => {
    if (!dryRun) await snapshotNow('import').catch(() => null); // safety copy before a big import
    try { const r = AR.importSuppliersCsv(user, text, { mapping: map, dryRun }); setPreview({ ...r, dryRun }); if (!dryRun) ui.toast('Suppliers imported'); } catch (e) { ui.error(e); }
  };
  const pick = async () => { try { const f = await pickTextFile(); if (f) { setText(f.text); setFileName(f.name); setMapping(null); setPreview(null); } } catch (e) { ui.error(e); } };
  return (
    <Screen title="Suppliers from Aronium" subtitle="Import the customers & suppliers list">
      <Hint>In Aronium: Management › Customers & suppliers › Export (CSV). Suppliers are matched by TIN first, then by name. Aronium's name, TIN, phone and email are used; what only this app knows (payment terms, bank details, budgets, order days) is kept. Customers are skipped. Aronium itself is never changed.</Hint>
      <Btn testID="si-pick" title={fileName ? `File: ${fileName}` : 'Choose the CSV file'} icon="📂" variant="info" onPress={pick} />
      <Field testID="si-text" label="…or paste the CSV text here" value={text.length > 4000 ? `(${rows.length - 1} rows loaded)` : text} onChangeText={(t) => { setText(t); setMapping(null); setPreview(null); }} multiline />
      {headers.length ? (
        <Section title={`Match the columns (${rows.length - 1} rows)`}>
          {AR.SUPPLIER_FIELDS.map((f) => (
            <Select key={f.key} label={`${f.label}${f.need ? ' *' : ''}`} value={map[f.key] === undefined ? '' : String(map[f.key])}
              onChange={(v) => { const m = { ...map }; if (v === '') delete m[f.key]; else m[f.key] = Number(v); setMapping(m); setPreview(null); }}
              options={[{ value: '', label: '— not in the file —' }].concat(headers.map((h, i) => ({ value: String(i), label: `${h || `(column ${i + 1})`} – e.g. ${(rows[1] || [])[i] || ''}` })))} />
          ))}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Btn testID="si-check" title="Check first" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => run(true)} />
            <Btn testID="si-go" title="Import" size="md" variant="success" style={{ flexGrow: 1 }} disabled={!preview || !preview.dryRun} onPress={() => run(false)} />
          </View>
        </Section>
      ) : null}
      {preview ? (
        <Card tone={preview.dryRun ? undefined : 'success'}>
          <H>{preview.dryRun ? 'What will happen' : 'Done'}</H>
          <Row label="New suppliers" value={String(preview.added)} />
          <Row label="Changed (Aronium details)" value={String(preview.changed)} />
          <Row label="No change" value={String(preview.same)} />
          <Row label="Customers skipped" value={String(preview.customers)} />
          {preview.sample.map((s) => <Text key={s.name} style={{ fontSize: 14, color: C.sub }}>{s.name}{s.tin ? ` (TIN ${s.tin})` : ''} → {s.match}{s.changes.length ? ` – ${s.changes.join(', ')}` : ''}</Text>)}
          {preview.errors.slice(0, 10).map((e) => <Text key={e} style={{ color: C.warn }}>{e}</Text>)}
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- an order's change history
export function POHistoryScreen({ params }) {
  const o = I.getPO(params.uid);
  if (!o) return <Screen title="Changes"><Text>Not found.</Text></Screen>;
  const list = PA.poVersions(o.uid);
  const KIND = { amend: 'Changed after sending', after_receive: 'Changed after delivery', delivery_fix: 'Delivery corrected' };
  return (
    <Screen title={`${o.po_no} · changes`} subtitle={`${o.supplier_name} · version ${o.version || 1}`}>
      <Hint>Every change after the order was sent: who, when, why, and what changed. Version 1 is the order as first sent.</Hint>
      {!list.length ? <Text testID="ph-none" style={{ color: C.sub }}>No changes since it was sent.</Text> : null}
      {list.map((v) => (
        <Card key={v.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Version {v.version} · {KIND[v.kind] || v.kind}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{String(v.at).slice(0, 16)} by {v.by_name}{v.reason ? ` · why: ${v.reason}` : ''}</Text>
          {v.changes.map((c) => <Text key={c} style={{ fontSize: 15, color: C.text }}>• {c}</Text>)}
        </Card>
      ))}
      <Card>
        <Row label="First sent" value={o.sent_at ? `${String(o.sent_at).slice(0, 16)} by ${o.sent_via}` : '—'} />
        {o.amended_at ? <Row label="Amended order sent" value={o.amend_sent_at ? String(o.amend_sent_at).slice(0, 16) : 'not yet'} color={o.amend_sent_at ? undefined : C.warn} /> : null}
      </Card>
    </Screen>
  );
}

// ---------------------------------------------------------------- correct a delivery
export function DeliveryFixScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const r = I.getReceipt(params.uid);
  const [vals, setVals] = useState(() => Object.fromEntries((r ? r.lines : []).map((l) => [l.itemUid, { qty: String(l.qty), cost: String(l.unitCost) }])));
  const [why, setWhy] = useState('');
  if (!r) return <Screen title="Correct a delivery"><Text>Not found.</Text></Screen>;
  const save = () => {
    const res = act(() => PA.correctDelivery(user, r.uid, { reason: why, lines: r.lines.map((l) => ({ itemUid: l.itemUid, lineUid: l.lineUid, qty: vals[l.itemUid].qty, unitCost: vals[l.itemUid].cost })) }), 'Delivery corrected – stock and order updated');
    if (res) nav.pop();
  };
  return (
    <Screen title="Correct a delivery" subtitle={`${r.supplier_name} · ${shopName(r.shop_code)} · ${r.receive_date}`}
      footer={<Btn testID="df-save" title="Save the correction" icon="✅" variant="success" onPress={save} />}>
      <Hint>Change the number that really arrived (or the invoice price). The stock, the order's "received" numbers and – if it is the latest delivery – the product's cost price follow. The change is recorded with your name and reason.</Hint>
      {r.lines.map((l) => {
        const v = vals[l.itemUid];
        const changed = Number(v.qty) !== l.qty || Number(v.cost) !== l.unitCost;
        return (
          <Card key={l.itemUid} tone={changed ? 'warn' : undefined}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>Entered {fq(l.qty)} at {$(l.unitCost)}{l.ordered ? ` · ordered ${fq(l.ordered)}` : ''}{l.corrected ? ` · corrected before by ${l.corrected.by}` : ''}</Text>
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end', flexWrap: 'wrap' }}>
              <QtyBox value={v.qty} onChange={(x) => setVals({ ...vals, [l.itemUid]: { ...v, qty: x } })} testID={`df-qty-${l.code}`} />
              <View style={{ width: 150 }}><MoneyField testID={`df-cost-${l.code}`} label="Price (excl. VAT)" value={v.cost} onChange={(x) => setVals({ ...vals, [l.itemUid]: { ...v, cost: x } })} /></View>
            </View>
          </Card>
        );
      })}
      <ReasonField testID="df-why" label="What was wrong?" value={why} onChangeText={setWhy} placeholder="e.g. one bag was counted twice" />
    </Screen>
  );
}

// ---------------------------------------------------------------- read a supplier invoice
export function InvoiceReadScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const act = useAct();
  const [sup, setSup] = useState(params.supplierUid || '');
  const [poUid, setPoUid] = useState(params.poUid || '');
  const [rcUid, setRcUid] = useState(params.receiptUid || '');
  const [photos, setPhotos] = useState([]);
  const [text, setText] = useState('');
  const [res, setRes] = useState(null);
  const [fix, setFix] = useState({ invoiceNo: '', total: '', lines: [] });
  const [busy, setBusy] = useState(false);
  const pos = sup ? I.listPOs({ supplierUid: sup, status: 'open', limit: 30 }).concat(I.listPOs({ supplierUid: sup, status: 'received', limit: 10 })) : [];
  const rcs = sup ? I.listReceipts({ supplierUid: sup, kind: 'receive', limit: 20 }).filter((r) => r.status === 'active') : [];
  const show = (r, t) => {
    setRes(r); if (t !== undefined) setText(t);
    if (r.supplierUid && !sup) setSup(r.supplierUid);
    setFix({ invoiceNo: r.invoiceNo || '', total: r.total === null || r.total === undefined ? '' : String(r.total), lines: r.lines.map((l) => ({ raw: l.raw, itemUid: l.itemUid || '', qty: String(l.qty), unitCost: String(l.unitCost) })) });
  };
  const readPhoto = async (list) => {
    setBusy(true);
    try {
      const r = await readInvoicePhotos(user, list || photos, { supplierUid: sup || undefined, poUid: poUid || undefined, receiptUid: rcUid || undefined });
      if (!r.ok) ui.alert({ title: 'Could not read it', message: r.message, tone: 'warn' }); else { show(r.result, r.text); ui.toast(r.message); }
    } catch (e) { ui.error(e); }
    setBusy(false);
  };
  const readText = () => { try { show(IR.readInvoiceText(text, { supplierUid: sup || undefined, poUid: poUid || undefined, receiptUid: rcUid || undefined })); } catch (e) { ui.error(e); } };
  const teach = () => {
    const r = act(() => IR.learnFromCorrection(user, sup || res.supplierUid, text, { invoiceNo: fix.invoiceNo, total: fix.total, lines: fix.lines.filter((l) => l.itemUid) }), 'Learned');
    if (r) { ui.alert({ title: 'Learned for next time', message: r.learned.map((x) => `• ${x}`).join('\n') }); readText(); }
  };
  const itemOptions = useMemo(() => [{ value: '', label: '— not matched —' }].concat(I.stockList({ shopCode: (I.getPO(poUid) || {}).shop_code || 'S1', limit: 3000 }).map((it) => ({ value: it.uid, label: `${it.name} (${it.code})` }))), [poUid, res]);
  return (
    <Screen title="Read a supplier invoice" subtitle="Item lines, order match and cost changes">
      <Hint>Take a photo of the invoice: it is read on this tablet (no internet needed); if that fails, Google reads it when online. The lines are matched to our products, the order and the delivery, and price changes are flagged. Correct anything wrong and tap "Learn this supplier's layout" – the next invoice from them is read better.</Hint>
      <Select testID="ir-sup" label="Supplier (found by itself if left empty)" value={sup} onChange={(v) => { setSup(v); setPoUid(''); setRcUid(''); }} options={[{ value: '', label: 'Find from the invoice' }].concat(supOptions())} />
      {sup ? <Select testID="ir-po" label="Purchase order (optional)" value={poUid} onChange={setPoUid} options={[{ value: '', label: 'None' }].concat(pos.map((o) => ({ value: o.uid, label: `${o.po_no} · ${o.order_date} · ${I.PO_STATUS[o.status]}` })))} /> : null}
      {sup ? <Select testID="ir-rc" label="Delivery (optional)" value={rcUid} onChange={setRcUid} options={[{ value: '', label: 'None' }].concat(rcs.map((r) => ({ value: r.uid, label: `${r.receive_date} · ${r.shop_code} · ${$(r.total)}` })))} /> : null}
      <PhotoPicker value={photos} onChange={(p) => { const more = p.length > photos.length; setPhotos(p); if (more) readPhoto(p); }} label="Photo of the invoice" testID="ir-photo" />
      <Btn testID="ir-read" title={busy ? 'Reading…' : 'Read the photo again'} icon="🔎" variant="secondary" disabled={!photos.length || busy} onPress={() => readPhoto()} />
      <Field testID="ir-text" label="Text of the invoice (filled in by reading – or paste / type it)" value={text} onChangeText={setText} multiline />
      {text ? <Btn testID="ir-again" title="Read this text" size="md" variant="secondary" onPress={readText} /> : null}
      {res ? (
        <>
          <Card>
            <Row label="Supplier" value={res.supplierName || 'not found'} color={res.supplierUid ? undefined : C.warn} />
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="ir-no" label="Invoice number" value={fix.invoiceNo} onChangeText={(v) => setFix({ ...fix, invoiceNo: v })} /></View>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="ir-total" label="Total (incl. VAT)" value={fix.total} onChange={(v) => setFix({ ...fix, total: v })} /></View>
            </View>
            {res.invoiceDate ? <Row label="Date" value={res.invoiceDate} /> : null}
            {res.layoutUsed ? <Text style={{ color: C.success }}>✓ Read with what was learned about this supplier</Text> : null}
          </Card>
          {res.flags.length ? <Banner testID="ir-flags" tone="warn" title="Please check" message={res.flags.map((f) => `• ${f}`).join('\n')} /> : <Banner tone="success" message="Everything matches." />}
          {res.costChanges.length ? (
            <Card tone="warn">
              <H>Cost price changes</H>
              {res.costChanges.map((c) => <Text testID={`ir-cost-${c.itemUid}`} key={c.itemUid} style={{ fontSize: 15, color: C.text }}>{c.name}: {$(c.oldCost)} → {$(c.newCost)}{c.pct !== null ? ` (${c.pct > 0 ? '+' : ''}${c.pct}%)` : ''}</Text>)}
              <Hint>The cost price changes when the delivery is received. Check the selling price in Aronium.</Hint>
            </Card>
          ) : null}
          <Section title={`Item lines (${res.lines.length})`}>
            {res.lines.map((l, i) => {
              const f = fix.lines[i] || {};
              return (
                <Card key={`${l.raw}-${i}`} tone={l.flags.length || !l.itemUid ? 'warn' : undefined}>
                  <Text style={{ fontSize: 13, color: C.sub }}>{l.raw}</Text>
                  <Select testID={`ir-item-${i}`} label="Our product" value={f.itemUid} onChange={(v) => setFix({ ...fix, lines: fix.lines.map((x, k) => (k === i ? { ...x, itemUid: v } : x)) })} options={itemOptions} />
                  <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                    <View style={{ width: 110 }}><Field testID={`ir-qty-${i}`} label="Qty" value={f.qty} onChangeText={(v) => setFix({ ...fix, lines: fix.lines.map((x, k) => (k === i ? { ...x, qty: v } : x)) })} keyboardType="decimal-pad" /></View>
                    <View style={{ width: 150 }}><MoneyField testID={`ir-price-${i}`} label="Price (excl. VAT)" value={f.unitCost} onChange={(v) => setFix({ ...fix, lines: fix.lines.map((x, k) => (k === i ? { ...x, unitCost: v } : x)) })} /></View>
                    {l.ordered !== undefined ? <Text style={{ color: C.sub }}>ordered {fq(l.ordered)} at {$(l.orderCost)}</Text> : null}
                    {l.delivered !== undefined ? <Text style={{ color: C.sub }}>delivered {fq(l.delivered)}</Text> : null}
                  </View>
                  {l.flags.length ? <Text style={{ color: C.warn, fontWeight: '700' }}>{l.flags.join(' · ')}</Text> : null}
                </Card>
              );
            })}
            {res.missing.length ? <Text style={{ color: C.warn }}>On the order but not on the invoice: {res.missing.map((m) => `${m.name} (${fq(m.left)})`).join(', ')}</Text> : null}
          </Section>
          {(sup || res.supplierUid) ? <Btn testID="ir-learn" title="Learn this supplier's layout" icon="🧠" variant="secondary" onPress={teach} /> : null}
          {poUid && can('po_receive') && ['approved', 'sent', 'part'].includes((I.getPO(poUid) || {}).status) ? (
            <Btn testID="ir-receive" title="Receive the delivery with these numbers" icon="🚚" variant="success"
              onPress={() => nav.push('POReceive', { poUid, prefill: { invoiceNo: fix.invoiceNo, total: fix.total, photos, lines: fix.lines.filter((l) => l.itemUid).map((l) => ({ itemUid: l.itemUid, qty: l.qty, unitCost: l.unitCost })) } })} />
          ) : null}
        </>
      ) : null}
    </Screen>
  );
}
