// 1.0.0 Owed by suppliers (invoiced but not delivered, short, damaged, overcharged) and "Damaged goods found" after a
// delivery (opening the cartons): kept until the goods come, a credit note, or written off; the supplier is told.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Section, Select, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Stats, Hint, ReasonField } from '../../../ui/kit.js';
import { listSuppliers, getSupplier } from '../../payables/service.js';
import * as I from '../service.js';
import * as OW from '../supplierOwed.js';
import { shopName, fq } from './common.js';

const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
const supOptions = () => listSuppliers().map((s) => ({ value: s.uid, label: s.name }));

async function tellSupplier(ui, user, supplierUid, uids) {
  const m = OW.supplierMessage(supplierUid, uids);
  if (!m) return;
  const sup = getSupplier(supplierUid) || {};
  if (sup.viber_group) ui.toast(`In Viber, pick the group "${sup.viber_group}"`);
  try { await Linking.openURL(I.viberLink(m.text, sup.viber_group ? null : sup.viber || sup.phone)); } catch (e) { /* no Viber: the text can be copied */ }
  OW.markTold(user, m.uids);
}

export function SupplierOwedScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const [sup, setSup] = useState(params.supplierUid || '');
  const [show, setShow] = useState('open');
  const [open, setOpen] = useState(null); // { uid, how, qty, note }
  const [, bump] = useState(0);
  const per = OW.owedBySupplier();
  const list = OW.listOwed({ supplierUid: sup || undefined, status: show === 'open' ? 'open' : 'all' });
  const total = per.reduce((t, s) => t + s.value, 0);
  const settle = () => { if (act(() => OW.settleOwed(user, open.uid, { how: open.how, qty: open.qty, note: open.note }), 'Saved') !== null) { setOpen(null); bump((x) => x + 1); } };
  return (
    <Screen title="Owed by suppliers" subtitle={`${$(total)} of goods owed`}
      footer={<Btn testID="ow-damaged" title="Report damaged goods" icon="📦" variant="warn" onPress={() => nav.push('ReportDamaged', {})} />}>
      <Hint>Goods on an invoice that did not come, came short, came damaged, or were charged too much. The invoice can be paid in full – these stay here until the goods come, a credit note comes, or they are written off.</Hint>
      <Stats items={per.slice(0, 3).map((s) => ({ label: s.name, value: $(s.value), sub: `${s.items} item${s.items === 1 ? '' : 's'} · since ${s.oldest}` }))} />
      <Select testID="ow-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'All suppliers' }].concat(supOptions())} />
      <Chips value={show} onChange={setShow} testIDPrefix="ow-show" options={[{ value: 'open', label: 'Still owed' }, { value: 'all', label: 'All (also settled)' }]} />
      {sup && list.some((o) => o.status === 'open') ? <Btn testID="ow-tell" title="Tell the supplier (Viber)" icon="💬" variant="info" onPress={() => tellSupplier(ui, user, sup, null).then(() => bump((x) => x + 1))} /> : null}
      {!list.length ? <Banner tone="success" message="Nothing owed." /> : null}
      {list.map((o) => (
        <View key={o.uid} style={{ gap: 6 }}>
          <ListItem testID={`ow-${o.uid}`} tone={o.status !== 'open' ? 'success' : o.days >= 7 ? 'danger' : 'warn'} title={`${o.name} × ${fq(o.left > 0 ? o.left : o.qty)}`} right={$(o.status === 'open' ? o.leftValue : o.value)}
            rightSub={o.status === 'open' ? `${o.days} day${o.days === 1 ? '' : 's'}` : OW.OWED_DONE[o.status]}
            sub={`${o.supplier_name} · ${OW.OWED_REASON[o.reason]}${o.invoice_no ? ` · invoice ${o.invoice_no}` : ''} · ${o.owed_date}${o.shop_code ? ` · ${shopName(o.shop_code)}` : ''}${o.told_at ? ' · supplier told' : ' · not told yet'}${o.qty_done ? ` · ${fq(o.qty_done)} settled` : ''}`}
            onPress={o.status === 'open' ? () => setOpen(open && open.uid === o.uid ? null : { uid: o.uid, how: 'received', qty: String(o.left), note: '' }) : undefined} />
          {open && open.uid === o.uid ? (
            <Card>
              <Chips value={open.how} onChange={(v) => setOpen({ ...open, how: v })} testIDPrefix="ow-how" options={[{ value: 'received', label: 'The goods came' }, { value: 'credited', label: 'Credit note' }, { value: 'written_off', label: 'Write off' }]} />
              <Field testID="ow-qty" label="How many" value={open.qty} onChangeText={(v) => setOpen({ ...open, qty: v })} keyboardType="numeric" />
              <ReasonField testID="ow-note" label={open.how === 'written_off' ? 'Why written off' : 'Note (e.g. credit note number)'} value={open.note} onChangeText={(v) => setOpen({ ...open, note: v })} />
              {open.how === 'received' ? <Hint>Replacement goods that come on a delivery are added to the stock there – this only marks them as no longer owed.</Hint> : null}
              <Btn testID="ow-save" title="Save" variant="success" onPress={settle} />
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// Found damaged when opening the cartons: choose the delivery, the product, how many, a photo.
export function ReportDamagedScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const pre = params.receiptUid ? I.getReceipt(params.receiptUid) : null;
  const [sup, setSup] = useState(pre ? pre.supplier_uid : '');
  const [rc, setRc] = useState(pre ? pre.uid : '');
  const [item, setItem] = useState('');
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [photos, setPhotos] = useState([]);
  const [done, setDone] = useState(null);
  const receipts = sup ? I.listReceipts({ supplierUid: sup, kind: 'receive', limit: 30 }).filter((r) => r.status === 'active') : [];
  const r = rc ? I.getReceipt(rc) : null;
  const line = r && item ? (r.lines || []).find((l) => l.itemUid === item) : null;
  const save = () => {
    const o = act(() => OW.reportDamaged(user, { receiptUid: rc, itemUid: item, qty, note, photos }), 'Reported – the shop and managers are told');
    if (o) setDone(o);
  };
  if (done) {
    return (
      <Screen title="Damaged goods reported">
        <Banner tone="success" title={`${done.name} × ${fq(done.qty)} – kept aside`} message={`Taken off the stock and put back on ${done.invoice_no ? `invoice ${done.invoice_no}` : 'the delivery'} as owed by ${done.supplier_name} until the replacement comes. The shop and the managers have been told.`} />
        <Btn testID="rd-tell" title="Tell the supplier now (Viber, with the photo next)" icon="💬" variant="info" onPress={() => tellSupplier(ui, user, done.supplier_uid, [done.uid]).then(() => ui.toast('Send the photo in the same chat too'))} />
        <Btn testID="rd-list" title="Owed by suppliers" icon="📋" variant="secondary" onPress={() => nav.replace('SupplierOwed', { supplierUid: done.supplier_uid })} />
        <Btn testID="rd-more" title="Report another" variant="ghost" onPress={() => { setDone(null); setItem(''); setQty(''); setNote(''); setPhotos([]); }} />
      </Screen>
    );
  }
  return (
    <Screen title="Damaged goods found" subtitle="After a delivery – e.g. when opening the cartons"
      footer={<Btn testID="rd-save" title="Report damaged" icon="⚠️" variant="warn" disabled={!rc || !item} onPress={save} />}>
      <Hint>Choose the delivery the goods came in. They come off the stock (keep them aside), go back on that invoice as owed by the supplier until replaced, and the shop and managers get a notification.</Hint>
      <Select testID="rd-sup" label="Supplier" value={sup} onChange={(v) => { setSup(v); setRc(''); setItem(''); }} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />
      {sup ? <Select testID="rd-rc" label="Delivery" value={rc} onChange={(v) => { setRc(v); setItem(''); }} options={[{ value: '', label: receipts.length ? 'Choose the delivery' : 'No deliveries from this supplier' }].concat(receipts.map((x) => ({ value: x.uid, label: `${x.receive_date} · ${shopName(x.shop_code)}${x.invoice_no ? ` · invoice ${x.invoice_no}` : ''} · ${$(x.total)}` })))} /> : null}
      {r ? <Select testID="rd-item" label="Product" value={item} onChange={setItem} options={[{ value: '', label: 'Choose the product' }].concat((r.lines || []).map((l) => ({ value: l.itemUid, label: `${l.name} (${fq(l.qty)} came${OW.damagedSoFar(r.uid, l.itemUid) ? `, ${fq(OW.damagedSoFar(r.uid, l.itemUid))} damaged already` : ''})` })))} /> : null}
      {line ? (
        <>
          <Field testID="rd-qty" label={`How many are damaged (singles${(I.getItem(item) || {}).unit ? `, ${(I.getItem(item) || {}).unit}` : ''})`} value={qty} onChangeText={setQty} keyboardType="numeric" />
          <Field testID="rd-note" label="What is wrong (optional)" value={note} onChangeText={setNote} placeholder="crushed carton, leaking, expired…" />
          <PhotoPicker testID="rd-photo" value={photos} onChange={setPhotos} label="Photo of the damaged goods (needed)" />
        </>
      ) : null}
    </Screen>
  );
}
