// Purchase orders: list, make / change, one order (approve, send by Viber, receive), receive a delivery, return to supplier.
import React, { useState, useEffect, useRef } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton, ReasonField } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shareReport, printReport } from '../../../platform/files.js';
import { listSuppliers, getSupplier, listInvoices } from '../../payables/service.js';
import * as I from '../service.js';
import { poReport, amendedPoReport } from '../reports.js';
import * as PA from '../poAmend.js';
import { addScanned } from '../scan.js';
import { ScanBar } from './scanUi.js';
import { readInvoicePhotos } from '../../../platform/invoiceReader.js';
import { shopName, shopChips, useShop, ItemPicker, QtyBox, fq } from './common.js';
import { offerPdf } from '../../../ui/shareDoc.js';

// The order as a PDF to send to the Viber group (with prices, for the office).
const poDoc = (uid) => { const o = I.getPO(uid); return o ? { rep: poReport(uid, { prices: true }), photos: [], text: `Easy Buys – purchase order ${o.po_no} to ${o.supplier_name}, ${o.lines.filter((l) => l.qty > 0).length} item(s), ${I.$(o.total)}.` } : null; };

const { $ } = I;
const STATUS_COLOR = { draft: C.sub, awaiting: C.warn, approved: C.info, sent: C.info, part: C.warn, received: C.success, closed: C.sub, cancelled: C.sub };
const supOptions = () => listSuppliers().map((s) => ({ value: s.uid, label: s.name }));

function BudgetBar({ supplierUid, total, date, exceptPo }) {
  if (!supplierUid) return null;
  const b = I.budgetCheck(supplierUid, total, date, exceptPo);
  if (b.weekBudget === null && b.monthBudget === null) return <Hint>No budget set for this supplier (Inventory settings › Supplier budgets).</Hint>;
  const line = (label, budget, used) => {
    if (budget === null) return null;
    const after = used + total;
    const pct = budget > 0 ? Math.min(100, (after / budget) * 100) : 100;
    const over = after > budget + 0.004;
    return (
      <View key={label} style={{ gap: 4 }}>
        <Text style={{ fontSize: 15, color: over ? C.danger : C.text, fontWeight: '700' }}>{label}: {$(used)} used + this order {$(total)} = {$(after)} of {$(budget)}{over ? ` – OVER by ${$(after - budget)}` : ` – ${$(budget - after)} left`}</Text>
        <View style={{ height: 10, borderRadius: 5, backgroundColor: '#EEE7DD' }}><View style={{ height: 10, borderRadius: 5, width: `${pct}%`, backgroundColor: over ? C.danger : pct > 85 ? C.warn : C.success }} /></View>
      </View>
    );
  };
  return (
    <Card tone={b.isOver ? 'danger' : undefined}>
      {line(`Week ${b.weekStart} – ${b.weekEnd}`, b.weekBudget, b.week)}
      {line(`Month`, b.monthBudget, b.month)}
      {b.isOver ? <Hint>{{ warn: 'Over budget: you can still send it.', approve: 'Over budget: a manager with approval rights must approve it before it can be sent.', block: 'Over budget: the admin does not allow this. Make the order smaller.' }[I.invRules().budgetMode]}</Hint> : null}
    </Card>
  );
}

// ---------------------------------------------------------------- list
export function POListScreen({ params }) {
  const { nav, can } = useApp();
  const [shop, setShop] = useShop(params.shopCode);
  const [status, setStatus] = useRemembered('status', params.status || 'open');
  const list = I.listPOs({ shopCode: shop, status: status === 'all' ? undefined : status, limit: 200 });
  const awaiting = I.listPOs({ status: 'awaiting' });
  return (
    <Screen title="Purchase orders" subtitle={shopName(shop)}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="po-shop" />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {can('po_create') ? <Btn testID="po-new" title="New order" icon="📝" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { shopCode: shop })} /> : null}
        {can('po_receive') ? <Btn testID="po-receive-free" title="Delivery with no order" icon="🚚" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POReceive', { shopCode: shop })} /> : null}
      </View>
      <Hint>An order goes: Draft → Approved (or "Waiting for approval" if over the budget or limit) → Sent to the supplier → Received. Receive deliveries from the order so stock and cost prices update by themselves.</Hint>
      {can('po_approve') && awaiting.length ? <Banner tone="warn" title={`${awaiting.length} order(s) waiting for your approval`} message={awaiting.map((o) => `${o.po_no} ${o.supplier_name} ${$(o.total)}`).join('\n')} /> : null}
      <Chips value={status} onChange={setStatus} testIDPrefix="po-st" options={[{ value: 'open', label: 'Open' }, { value: 'to_receive', label: 'To receive' }, { value: 'awaiting', label: 'To approve' }, { value: 'all', label: 'All' }]} />
      {!list.length ? <Text style={{ color: C.sub }}>No orders here.</Text> : null}
      {list.map((o) => (
        <ListItem key={o.uid} testID={`po-${o.po_no}`} onPress={() => nav.push('POView', { uid: o.uid })} title={`${o.po_no} · ${o.supplier_name}`}
          sub={`${o.order_date}${o.expected_date ? ` · due ${o.expected_date}` : ''} · by ${o.created_by_name || ''}${o.sent_via ? ` · sent by ${o.sent_via}` : ''}`}
          right={$(o.total)} badge={I.PO_STATUS[o.status]} badgeColor={STATUS_COLOR[o.status]}
          tone={['sent', 'approved'].includes(o.status) && o.expected_date && o.expected_date < dateStr() ? 'warn' : undefined} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- make / change
export function POEditScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const before = params.uid ? I.getPO(params.uid) : null;
  // Sent / received orders are changed as an amendment (approvers only), keeping what has arrived.
  const mode = before ? PA.poEditMode(user, before).mode : 'full';
  const amend = mode === 'sent' || mode === 'received';
  const [why, setWhy] = useState('');
  const [orderDate, setOrderDate] = useState(before ? before.order_date : dateStr());
  const [shop, setShop] = useShop(before ? before.shop_code : params.shopCode);
  const [sup, setSup] = useState(before ? before.supplier_uid : params.supplierUid || '');
  const [lines, setLines] = useState(() => (before ? before.lines.filter((l) => l.qty > 0).map((l) => ({ lineUid: amend ? l.uid : undefined, received: amend ? l.qty_received : 0, itemUid: l.item_uid, name: l.name, code: l.code, unit: l.unit, qty: String(l.qty), unitCost: String(l.unit_cost), note: l.note || '' })) : []));
  const [notes, setNotes] = useState(before ? before.notes || '' : '');
  const [expected, setExpected] = useState(before ? before.expected_date || '' : '');
  const total = lines.reduce((s, l) => s + I.incVat((Number(l.qty) || 0) * (Number(l.unitCost) || 0), l.itemUid ? (I.getItem(l.itemUid) || {}).vat_type : 'standard'), 0);
  const addSuggested = (quiet) => {
    const sug = I.suggestFor(shop, sup).filter((x) => !lines.some((l) => l.itemUid === x.itemUid));
    if (!sug.length) { if (!quiet) ui.toast('Nothing from this supplier needs ordering right now', 'info'); return; }
    setLines(lines.concat(sug.map((x) => ({ itemUid: x.itemUid, name: x.name, code: x.code, unit: x.unit, qty: String(x.qty), unitCost: String(x.unitCost), why: x.why }))));
  };
  // Opened from an order reminder: start with the suggested quantities.
  const suggested = useRef(false);
  useEffect(() => { if (params.suggest && !before && sup && !suggested.current) { suggested.current = true; addSuggested(true); } }, [sup]);
  if (before && mode === 'none') return <Screen title={`Change ${before.po_no}`}><Banner tone="warn" message={PA.poEditMode(user, before).why} /></Screen>;
  const saveAmend = () => {
    try {
      const r = PA.amendPO(user, before.uid, { orderDate, expectedDate: expected, notes, lines: lines.map((l) => ({ lineUid: l.lineUid, itemUid: l.itemUid, name: l.name, code: l.code, unit: l.unit, qty: l.qty, unitCost: l.unitCost, note: l.note })) }, { reason: why });
      ui.toast(`Changed – version ${r.version}`);
      nav.replace('POView', { uid: before.uid });
      if (r.offerAmended) {
        offerPdf(ui, () => ({ rep: amendedPoReport(before.uid), photos: [], text: `AMENDED purchase order ${before.po_no} to ${before.supplier_name}: ${r.changes.join('; ')}` }), { title: 'Send the AMENDED order to the supplier?', force: true })
          .then((sent) => { if (sent) PA.markAmendedSent(user, before.uid, 'pdf'); });
      }
    } catch (e) { ui.error(e); }
  };
  const save = (submit) => {
    if (amend) { saveAmend(); return; }
    try {
      const o = I.savePO(user, { uid: before && before.uid, supplierUid: sup, shopCode: shop, lines, notes, expectedDate: expected });
      if (submit) {
        const r = I.submitPO(user, o.uid, { canApprove: false });
        ui.toast(r.status === 'awaiting' ? 'Saved – waiting for approval' : 'Approved – ready to send');
        nav.replace('POView', { uid: o.uid });
        offerPdf(ui, () => poDoc(o.uid), { title: r.status === 'awaiting' ? 'Send the order to the Viber group for approval?' : 'Send the order PDF to Viber?' });
        return;
      } else ui.toast('Draft saved');
      nav.replace('POView', { uid: o.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={before ? `Change ${before.po_no}` : 'New purchase order'} subtitle={shopName(shop)}
      footer={amend ? <Btn testID="po-amend" title={`Save the change · ${$(total)}`} icon="✏️" size="md" variant="success" onPress={() => save(false)} /> : <View style={{ flexDirection: 'row', gap: 10 }}>
        <Btn testID="po-save" title="Save draft" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => save(false)} />
        <Btn testID="po-submit" title={`Finish · ${$(total)}`} size="md" variant="success" style={{ flex: 1 }} onPress={() => save(true)} />
      </View>}>
      {amend ? <Banner testID="pe-amend" tone="warn" title={mode === 'sent' ? 'This order was already sent' : 'Goods have already arrived'} message={PA.EDIT_MODE_LABEL[mode]} /> : null}
      {amend ? null : <Label>For shop</Label>}
      {amend ? null : <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="pe-shop" />}
      {amend ? null : <Select testID="pe-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />}
      {sup ? <BudgetBar supplierUid={sup} total={total} date={dateStr()} exceptPo={before && before.uid} /> : null}
      {sup ? <Btn testID="pe-suggest" title="Add what needs ordering" icon="✨" size="md" variant="info" onPress={() => addSuggested(false)} /> : null}
      {sup ? <ScanBar testID="pe-scan" supplierUid={sup} shopCode={shop} startOpen={!!params.scan} onItem={(it, n) => setLines((cur) => addScanned(cur, it, n))} /> : null}
      <Hint>"Add what needs ordering" looks at this shop's stock, its sales over the last weeks, what is already on order and the supplier's delivery days.</Hint>
      <ItemPicker shopCode={shop} exclude={lines.map((l) => l.itemUid)} onPick={(r) => setLines(lines.concat([{ itemUid: r.uid, name: r.name, code: r.code, unit: r.unit, qty: String(r.suggest || r.reorder_qty || 1), unitCost: String(r.cost), note: '' }]))} testID="pe-find" />
      {lines.length ? <Hint>The cost price comes from the product (the last price paid). Change the quantity, the price if the supplier quoted a different one, and add a comment for the supplier if needed. You can change the order until it is sent.</Hint> : null}
      {lines.map((l, i) => (
        <Card key={`${l.itemUid}-${i}`}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name} <Text style={{ fontSize: 14, color: C.sub }}>{l.code}</Text></Text>
          {l.received ? <Text style={{ fontSize: 13, color: C.success }}>{fq(l.received)} already arrived – the order cannot go below that</Text> : null}
          {l.why ? <Text style={{ fontSize: 13, color: C.sub }}>{l.why}</Text> : null}
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
            <QtyBox value={l.qty} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} testID={`pe-qty-${i}`} />
            <Text style={{ fontSize: 15, color: C.sub }}>{l.unit}</Text>
            <View style={{ width: 130 }}><MoneyField label="Unit cost (excl. VAT)" value={l.unitCost} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, unitCost: v } : x)))} /></View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{$((Number(l.qty) || 0) * (Number(l.unitCost) || 0))}</Text>
            <View style={{ flexBasis: 220, flexGrow: 1 }}><Field testID={`pe-note-${i}`} label="Comment (goes to the supplier)" value={l.note || ''} onChangeText={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, note: v } : x)))} placeholder="e.g. same brand as last time" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
          </View>
        </Card>
      ))}
      {amend ? <DateField label="Order date" value={orderDate} onChange={setOrderDate} /> : null}
      <DateField label="Deliver by (optional)" value={expected} onChange={setExpected} />
      <Field label="Note to the supplier (optional)" value={notes} onChangeText={setNotes} multiline />
      {amend ? <ReasonField testID="pe-why" label="Why is it changed?" value={why} onChangeText={setWhy} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- one order
export function POViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const [reason, setReason] = useState('');
  const o = I.getPO(params.uid);
  if (!o) return <Screen title="Order"><Text>Not found.</Text></Screen>;
  const sup = getSupplier(o.supplier_uid) || {};
  const text = I.poText(o.uid);
  const viber = async () => {
    const l = I.viberLink(text, sup.viber || sup.phone);
    try {
      await Linking.openURL(l.forward);
      act(() => I.markSent(user, o.uid, 'viber'), 'Marked as sent by Viber');
    } catch (e) { ui.alert({ title: 'Viber did not open', message: 'Is Viber installed on this device? You can also share the PDF instead.' }); }
  };
  const pdf = async () => {
    try { await shareReport(poReport(o.uid), 'pdf'); act(() => I.markSent(user, o.uid, 'pdf'), 'Marked as sent'); } catch (e) { ui.error(e); }
  };
  const canSend = ['approved', 'sent', 'part'].includes(o.status);
  return (
    <Screen title={`${o.po_no} · ${o.supplier_name}`} subtitle={`${shopName(o.shop_code)} · ${I.PO_STATUS[o.status]}`}>
      <Stats items={[
        { label: 'Order total (incl. VAT)', value: $(o.total) },
        { label: 'Received', value: `${o.receivedPct}%`, sub: $(o.receivedValue), color: o.receivedPct >= 100 ? C.success : undefined },
        { label: 'Invoiced', value: $(o.invoiced), sub: `${o.invoices.length} invoice(s)` },
      ]} />
      {o.budget_note ? <Banner tone={o.status === 'awaiting' || o.status === 'draft' ? 'warn' : 'info'} message={o.budget_note} /> : null}
      <Card>
        <Row label="Ordered" value={`${o.order_date} by ${o.created_by_name || ''}`} />
        {o.expected_date ? <Row label="Deliver by" value={o.expected_date} color={canSend && o.expected_date < dateStr() && o.status !== 'part' ? C.danger : undefined} /> : null}
        {o.approved_by_name ? <Row label="Approved" value={`${o.approved_by_name} · ${String(o.approved_at || '').slice(0, 16)}`} /> : null}
        {o.sent_at ? <Row label="Sent" value={`${String(o.sent_at).slice(0, 16)} by ${o.sent_via}`} /> : null}
        {o.cancel_reason ? <Row label={o.status === 'closed' ? 'Closed short' : 'Cancelled'} value={o.cancel_reason} /> : null}
        {o.notes ? <Row label="Note" value={o.notes} /> : null}
      </Card>
      <Section title="Products">
        {o.lines.filter((l) => l.qty > 0).map((l) => (
          <ListItem key={l.uid} title={l.name} sub={`${l.code || ''} · ${$(l.unit_cost)} each`} right={`${fq(l.qty_received)} / ${fq(l.qty)} ${l.unit || ''}`}
            rightSub={l.qty_received >= l.qty ? 'all here' : l.qty_received ? `${fq(l.qty - l.qty_received)} to come` : ''} tone={l.qty_received >= l.qty ? 'success' : undefined} />
        ))}
      </Section>
      {(() => { const m = PA.poEditMode(user, o).mode; return m === 'sent' || m === 'received' ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="pv-amend" title={m === 'sent' ? 'Change the order (amend)' : 'Change what has not arrived'} icon="✏️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { uid: o.uid })} />
        </View>
      ) : null; })()}
      {o.version > 1 ? (
        <Card tone={o.amended_at && !o.amend_sent_at && ['sent', 'part'].includes(o.status) ? 'warn' : undefined}>
          <Row label="Version" value={`${o.version}${o.amended_at ? ` · changed ${String(o.amended_at).slice(0, 16)} by ${o.amended_by_name}` : ''}`} />
          {o.amended_at ? <Row label="Amended order sent" value={o.amend_sent_at ? String(o.amend_sent_at).slice(0, 16) : 'not yet'} color={o.amend_sent_at ? undefined : C.warn} /> : null}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            {o.amended_at ? <Btn testID="pv-amended-pdf" title="Send the AMENDED order" icon="📄" size="sm" variant="info" onPress={async () => { try { await shareReport(amendedPoReport(o.uid), 'pdf'); act(() => PA.markAmendedSent(user, o.uid, 'pdf'), 'Marked as sent'); } catch (e) { ui.error(e); } }} /> : null}
            {o.amended_at && !o.amend_sent_at ? <Btn testID="pv-amended-sent" title="Told the supplier another way" size="sm" variant="ghost" onPress={() => act(() => PA.markAmendedSent(user, o.uid, 'other'), 'Marked as sent')} /> : null}
            <Btn testID="pv-history" title="Change history" icon="🕘" size="sm" variant="secondary" onPress={() => nav.push('POHistory', { uid: o.uid })} />
          </View>
        </Card>
      ) : null}
      {['draft', 'awaiting', 'approved'].includes(o.status) && can('po_create') ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="pv-edit" title="Change" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { uid: o.uid })} />
          {o.status === 'draft' ? <Btn testID="pv-submit" title="Finish (approve / ask for approval)" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => I.submitPO(user, o.uid, { canApprove: false }), 'Done')} /> : null}
        </View>
      ) : null}
      {o.status === 'awaiting' && can('po_approve') ? (
        <Card tone="warn">
          <H>Approve this order?</H>
          <BudgetBar supplierUid={o.supplier_uid} total={o.total} date={o.order_date} exceptPo={o.uid} />
          <ReasonField testID="pv-reason" label="Why it is OK to go over the budget" value={reason} onChangeText={setReason} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID="pv-approve" title="Approve" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => I.submitPO(user, o.uid, { canApprove: true, reason }), 'Approved')) offerPdf(ui, () => poDoc(o.uid), { title: 'Send the approved order PDF to Viber?' }); }} />
            <Btn testID="pv-reject" title="Send back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => act(() => I.rejectPO(user, o.uid, reason || 'Not approved'), 'Sent back to draft')} />
          </View>
        </Card>
      ) : null}
      {canSend ? (
        <Section title="Send to the supplier">
          <Hint>Viber opens with the order typed out – pick the supplier's chat and press send. Or share the PDF (Viber, email, WhatsApp…). Prices are not shown to the supplier.</Hint>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Btn testID="pv-viber" title="Send by Viber" icon="💬" variant="info" style={{ flexGrow: 1 }} onPress={viber} />
            <Btn testID="pv-pdf" title="Share PDF" icon="📄" variant="secondary" style={{ flexGrow: 1 }} onPress={pdf} />
            <Btn title="Print" icon="🖨️" variant="secondary" style={{ flexGrow: 1 }} onPress={() => printReport(poReport(o.uid)).catch((e) => ui.error(e))} />
          </View>
          {!o.sent_at ? <Btn testID="pv-sent" title="Mark as sent (phoned / sent another way)" size="sm" variant="ghost" onPress={() => act(() => I.markSent(user, o.uid, 'other'), 'Marked as sent')} /> : null}
        </Section>
      ) : null}
      {canSend && can('po_receive') ? <Btn testID="pv-receive" title="Receive the delivery" icon="🚚" variant="success" onPress={() => nav.push('POReceive', { poUid: o.uid })} /> : null}
      {o.receipts.length ? (
        <Section title="Deliveries">
          {o.receipts.map((r) => (
            <ListItem key={r.uid} title={`${r.receive_date} · ${r.by_name}`} sub={`${r.lines.length} products${r.invoice_no ? ` · invoice ${r.invoice_no}` : ' · no invoice yet'}${r.match_note ? ` · ${r.match_note}` : ''}`}
              right={$(r.total)} badge={r.status === 'void' ? 'VOID' : null} badgeColor={C.sub} onPress={() => nav.push('Receipt', { uid: r.uid })} />
          ))}
        </Section>
      ) : null}
      <View style={{ gap: 10 }}>
        {o.status === 'part' && can('po_create') ? <ReasonButton testID="pv-close" title="Close short (the rest is not coming)" prompt="Why is the rest not coming?" confirm="Close order" variant="warn" onDo={(w) => act(() => I.closeShort(user, o.uid, w), 'Closed')} /> : null}
        {['draft', 'awaiting', 'approved', 'sent'].includes(o.status) && can('po_create') ? <ReasonButton testID="pv-cancel" title="Cancel order" prompt="Why is it cancelled?" confirm="Cancel order" onDo={(w) => act(() => I.cancelPO(user, o.uid, w), 'Cancelled')} /> : null}
      </View>
    </Screen>
  );
}

// ---------------------------------------------------------------- receive a delivery
export function POReceiveScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const o = params.poUid ? I.getPO(params.poUid) : null;
  const [shop, setShop] = useShop(o ? o.shop_code : params.shopCode);
  const [sup, setSup] = useState(o ? o.supplier_uid : '');
  const [got, setGot] = useState(() => Object.fromEntries((o ? o.lines : []).filter((l) => l.qty > l.qty_received).map((l) => [l.uid, { qty: String(Math.max(0, l.qty - l.qty_received)), cost: String(l.unit_cost) }])));
  const [extra, setExtra] = useState([]);
  const [invMode, setInvMode] = useState('now');
  const [inv, setInv] = useState({ invoiceNo: '', total: '', photos: [] });
  const [linkUid, setLinkUid] = useState('');
  const [date, setDate] = useState(dateStr());
  const [notes, setNotes] = useState('');
  const [why, setWhy] = useState('');
  const [needWhy, setNeedWhy] = useState('');
  const [photos, setPhotos] = useState([]);
  const [readRes, setReadRes] = useState(null);
  const [reading, setReading] = useState(false);
  const scanned = useRef(new Set());
  const lines = o ? o.lines.filter((l) => l.qty > 0) : [];
  // Numbers from a read invoice (Read a supplier invoice › Receive with these numbers, or "Read the invoice photo" here).
  const applyRead = (pre) => {
    if (!pre) return;
    setInv((cur) => ({ ...cur, invoiceNo: pre.invoiceNo || cur.invoiceNo, total: pre.total !== undefined && pre.total !== null && pre.total !== '' ? String(pre.total) : cur.total, photos: pre.photos && pre.photos.length ? pre.photos : cur.photos }));
    const g = { ...got };
    const ex = [...extra];
    for (const l of pre.lines || []) {
      const pl = lines.find((x) => x.item_uid === l.itemUid && x.qty > x.qty_received);
      if (pl) g[pl.uid] = { qty: String(l.qty), cost: String(l.unitCost) };
      else if (l.itemUid && !ex.some((x) => x.itemUid === l.itemUid)) { const it = I.getItem(l.itemUid); if (it) ex.push({ itemUid: it.uid, name: it.name, unit: it.unit, qty: String(l.qty), cost: String(l.unitCost) }); }
    }
    setGot(g); setExtra(ex);
  };
  const prefilled = useRef(false);
  useEffect(() => { if (params.prefill && !prefilled.current) { prefilled.current = true; applyRead(params.prefill); } }, []);
  const readPhoto = async () => {
    setReading(true);
    try {
      const r = await readInvoicePhotos(user, inv.photos, { supplierUid: sup || undefined, poUid: o ? o.uid : undefined });
      if (!r.ok) ui.alert({ title: 'Could not read it', message: r.message, tone: 'warn' });
      else { setReadRes(r.result); applyRead({ invoiceNo: r.result.invoiceNo, total: r.result.total, lines: r.result.lines.filter((l) => l.itemUid) }); ui.toast(r.message); }
    } catch (e) { ui.error(e); }
    setReading(false);
  };
  const onScan = (it, n) => {
    const pl = lines.find((x) => x.item_uid === it.uid && x.qty > x.qty_received);
    if (pl) {
      const first = !scanned.current.has(pl.uid);
      scanned.current.add(pl.uid);
      const cur = got[pl.uid] || { qty: '0', cost: String(pl.unit_cost) };
      setGot({ ...got, [pl.uid]: { ...cur, qty: String(first ? n : Math.round(((Number(cur.qty) || 0) + n) * 1000) / 1000) } });
    } else {
      const i = extra.findIndex((x) => x.itemUid === it.uid);
      if (i >= 0) setExtra(extra.map((x, k) => (k === i ? { ...x, qty: String((Number(x.qty) || 0) + n) } : x)));
      else setExtra(extra.concat([{ itemUid: it.uid, name: it.name, unit: it.unit, qty: String(n), cost: String(it.cost) }]));
    }
  };
  const value = lines.reduce((s, l) => s + (got[l.uid] ? I.incVat((Number(got[l.uid].qty) || 0) * (Number(got[l.uid].cost) || 0), (I.getItem(l.item_uid) || {}).vat_type) : 0), 0)
    + extra.reduce((s, x) => s + I.incVat((Number(x.qty) || 0) * (Number(x.cost) || 0), (I.getItem(x.itemUid) || {}).vat_type), 0);
  const openInvoices = sup ? listInvoices({ filter: 'all', supplierUid: sup, limit: 30 }).filter((i) => i.kind === 'invoice' && !i.po_uid && i.status !== 'void') : [];
  const save = () => {
    try {
      const r = I.receiveDelivery(user, {
        poUid: o && o.uid, supplierUid: sup, shopCode: shop, date, notes, photos, acceptReason: why,
        lines: Object.entries(got).map(([lineUid, g]) => ({ lineUid, qty: g.qty, unitCost: g.cost })),
        extra: extra.map((x) => ({ itemUid: x.itemUid, qty: x.qty, unitCost: x.cost })),
        invoice: invMode === 'link' && linkUid ? { uid: linkUid } : invMode === 'now' ? { invoiceNo: inv.invoiceNo, total: inv.total, photos: inv.photos, date } : null,
      });
      ui.toast(r.costFlags.length ? `Received – ${r.costFlags.length} cost price change(s) flagged` : 'Received – stock updated');
      nav.replace('Receipt', { uid: r.uid });
    } catch (e) {
      if (/^Please check/.test(e.message)) setNeedWhy(e.message); else ui.error(e);
    }
  };
  return (
    <Screen title={o ? `Receive ${o.po_no}` : 'Receive a delivery (no order)'} subtitle={`${o ? o.supplier_name : ''} · ${shopName(shop)}`}
      footer={<Btn testID="rc-save" title={`Received · ${$(value)}`} icon="✅" variant="success" onPress={save} />}>
      <Hint>Count what actually came off the truck. Change the number if less (or more) arrived, and the price if the invoice price is different – the product's cost price is updated and the change is flagged for checking.</Hint>
      {!o ? (
        <>
          <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="rc-shop" />
          <Select testID="rc-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />
          {(() => {
            let open = [];
            try { open = sup ? I.listPOs({ supplierUid: sup, shopCode: shop, status: 'to_receive', limit: 10 }) : []; } catch (e) { open = []; }
            return open.length ? (
              <Card tone="info">
                <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Is this delivery for one of these orders?</Text>
                {open.map((x) => <Btn key={x.uid} testID={`rc-po-${x.po_no}`} title={`${x.po_no} · ordered ${x.order_date} · ${I.$(x.total)}`} icon="📝" size="md" variant="secondary" onPress={() => nav.replace('POReceive', { poUid: x.uid })} />)}
              </Card>
            ) : null;
          })()}
          <Banner tone="warn" message="No purchase order: take a photo of the invoice (or the goods) below – it is kept with the invoice." />
        </>
      ) : null}
      <ScanBar testID="rc-scan" supplierUid={sup} shopCode={shop} onItem={onScan} hint="Scan each product as it comes off the truck and type how many. The first scan of an ordered product replaces the expected number; more scans add to it." />
      {lines.map((l) => {
        const g = got[l.uid] || { qty: '0', cost: String(l.unit_cost) };
        const left = l.qty - l.qty_received;
        const priceDiff = Math.abs((Number(g.cost) || 0) - l.unit_cost) > 0.00005;
        return (
          <Card key={l.uid} tone={left <= 0 ? 'success' : priceDiff ? 'warn' : undefined}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>Ordered {fq(l.qty)} {l.unit}{l.qty_received ? ` · already received ${fq(l.qty_received)}` : ''} · order price {$(l.unit_cost)}</Text>
            {left > 0 ? (
              <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
                <QtyBox value={g.qty} onChange={(v) => setGot({ ...got, [l.uid]: { ...g, qty: v } })} testID={`rc-qty-${l.code}`} />
                <View style={{ width: 150 }}><MoneyField testID={`rc-cost-${l.code}`} label="Invoice price (excl. VAT)" value={g.cost} onChange={(v) => setGot({ ...got, [l.uid]: { ...g, cost: v } })} /></View>
                {priceDiff ? <Text style={{ color: C.warn, fontWeight: '700' }}>Price changed</Text> : null}
              </View>
            ) : <Text style={{ color: C.success, fontWeight: '700' }}>All received</Text>}
          </Card>
        );
      })}
      <Section title={o ? 'Also came (not on the order)' : 'Products received'}>
        <ItemPicker shopCode={shop} exclude={extra.map((x) => x.itemUid)} onPick={(r) => setExtra(extra.concat([{ itemUid: r.uid, name: r.name, unit: r.unit, qty: '1', cost: String(r.cost) }]))} testID="rc-find" />
        {extra.map((x, i) => (
          <Card key={x.itemUid}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{x.name}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
              <QtyBox value={x.qty} onChange={(v) => setExtra(extra.map((y, k) => (k === i ? { ...y, qty: v } : y)))} testID={`rc-xqty-${i}`} />
              <View style={{ width: 150 }}><MoneyField label="Price (excl. VAT)" value={x.cost} onChange={(v) => setExtra(extra.map((y, k) => (k === i ? { ...y, cost: v } : y)))} /></View>
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setExtra(extra.filter((_, k) => k !== i))} />
            </View>
          </Card>
        ))}
      </Section>
      <Section title="Supplier invoice">
        <Chips value={invMode} onChange={setInvMode} testIDPrefix="rc-inv" options={[{ value: 'now', label: 'Enter it now' }, { value: 'link', label: 'Already entered' }, { value: 'later', label: 'Comes later' }]} />
        <Hint>The invoice total is checked against what was received. It also goes into Invoices & cheques to be paid, so it is only entered once.</Hint>
        {invMode === 'now' ? (
          <>
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="rc-invno" label="Invoice number" value={inv.invoiceNo} onChangeText={(v) => setInv({ ...inv, invoiceNo: v })} /></View>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="rc-invtotal" label="Invoice total (incl. VAT)" value={inv.total} onChange={(v) => setInv({ ...inv, total: v })} placeholder={value.toFixed(2)} /></View>
            </View>
            <PhotoPicker value={inv.photos} onChange={(p) => setInv({ ...inv, photos: p })} label="Photo of the invoice" />
            {inv.photos.length ? <Btn testID="rc-read" title={reading ? 'Reading…' : 'Read the invoice photo'} icon="🔎" size="md" variant="info" disabled={reading} onPress={readPhoto} /> : null}
            {readRes && (readRes.flags.length || readRes.costChanges.length) ? (
              <Banner testID="rc-read-flags" tone="warn" title="From the invoice – please check" message={readRes.flags.concat(readRes.costChanges.map((c) => `${c.name}: cost ${$(c.oldCost)} → ${$(c.newCost)}`)).map((f) => `• ${f}`).join('\n')} />
            ) : null}
          </>
        ) : invMode === 'link' ? (
          <Select label="Invoice" value={linkUid} onChange={setLinkUid} options={[{ value: '', label: openInvoices.length ? 'Choose' : 'No unlinked invoices from this supplier' }].concat(openInvoices.map((i) => ({ value: i.uid, label: `${i.invoice_no || 'no number'} · ${i.invoice_date} · ${$(i.total)}` })))} />
        ) : <Hint>It will show on "Received, not invoiced" until the invoice is linked.</Hint>}
      </Section>
      <DateField label="Delivery date" value={date} onChange={setDate} />
      <Field label="Note (optional)" value={notes} onChangeText={setNotes} />
      <PhotoPicker value={photos} onChange={setPhotos} label={o ? 'Photo of the delivery / damage (optional)' : 'Photo of the invoice or the goods (needed – no purchase order)'} />
      {needWhy ? (
        <Card tone="warn">
          <Text style={{ fontSize: 16, color: C.text }}>{needWhy}</Text>
          <ReasonField testID="rc-why" label="Why is it OK?" value={why} onChangeText={setWhy} multiline />
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- one delivery / return
export function ReceiptScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [inv, setInv] = useState('');
  const r = I.getReceipt(params.uid);
  if (!r) return <Screen title="Delivery"><Text>Not found.</Text></Screen>;
  const cands = !r.invoice_uid ? listInvoices({ filter: 'all', supplierUid: r.supplier_uid, limit: 40 }).filter((i) => i.status !== 'void' && (r.kind === 'return' ? i.kind === 'credit' : i.kind === 'invoice')) : [];
  return (
    <Screen title={r.kind === 'return' ? 'Return to supplier' : 'Delivery received'} subtitle={`${r.supplier_name} · ${shopName(r.shop_code)} · ${r.receive_date}`}>
      {r.status === 'void' ? <Banner tone="danger" message={`Voided: ${r.void_reason}`} /> : null}
      <Card>
        <Row label="Goods value (incl. VAT)" value={$(r.total)} bold />
        <Row label={r.kind === 'return' ? 'Credit note' : 'Invoice'} value={r.invoice_no ? `${r.invoice_no} · ${$(r.invoice_total)}` : 'not yet'} color={r.invoice_uid ? undefined : C.warn} />
        <Row label="By" value={r.by_name} />
        {r.match_note ? <Row label="Checked" value={r.match_note} /> : null}
        {r.notes ? <Row label="Note" value={r.notes} /> : null}
      </Card>
      {r.lines.map((l) => <ListItem key={l.itemUid} title={l.name} sub={`${l.code} · ${$(l.unitCost)} each${l.ordered ? ` · ordered ${fq(l.ordered)}` : ''}`} right={fq(l.qty)} />)}
      {!r.invoice_uid && r.status === 'active' && cands.length ? (
        <Section title={`Link the ${r.kind === 'return' ? 'credit note' : 'invoice'}`}>
          <Select label="Choose" value={inv} onChange={setInv} options={[{ value: '', label: 'Choose' }].concat(cands.map((i) => ({ value: i.uid, label: `${i.invoice_no || 'no number'} · ${i.invoice_date} · ${$(i.total)}` })))} />
          <Btn title="Link" size="md" variant="success" disabled={!inv} onPress={() => act(() => I.linkInvoice(user, r.uid, inv), 'Linked')} />
        </Section>
      ) : null}
      {r.status === 'active' && r.kind === 'receive' && (can('po_receive') || can('inventory_manage')) ? <Btn testID="rcv-fix" title="Correct quantities or prices" icon="✏️" size="md" variant="secondary" onPress={() => nav.push('DeliveryFix', { uid: r.uid })} /> : null}
      {r.status === 'active' && can('inventory_manage') ? <ReasonButton testID="rcv-void" title="Void (entered by mistake)" prompt="Why is it voided?" confirm="Void" onDo={(w) => act(() => I.voidReceipt(user, r.uid, w), 'Voided – stock taken back off')} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- return to supplier
export function SupplierReturnScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const [shop, setShop] = useShop(params.shopCode);
  const [sup, setSup] = useState('');
  const [lines, setLines] = useState([]);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState([]);
  const value = lines.reduce((s, l) => s + I.incVat((Number(l.qty) || 0) * l.cost, l.vat), 0);
  return (
    <Screen title="Return goods to a supplier" subtitle={shopName(shop)}
      footer={<Btn testID="ret-save" title={`Send back · ${$(value)}`} icon="↩️" variant="warn" onPress={() => {
        const uid = act(() => I.returnToSupplier(user, { supplierUid: sup, shopCode: shop, lines: lines.map((l) => ({ itemUid: l.uid, qty: l.qty })), reason, notes, photos }), 'Recorded – waiting for the credit note');
        if (uid) nav.replace('Receipt', { uid });
      }} />}>
      <Hint>The stock comes off now. The return stays on the "waiting for credit" list until the supplier's credit note is entered and linked – so no credit is forgotten.</Hint>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="ret-shop" />
      <Select testID="ret-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />
      <ItemPicker shopCode={shop} exclude={lines.map((l) => l.uid)} onPick={(r) => setLines(lines.concat([{ uid: r.uid, name: r.name, unit: r.unit, cost: r.cost, vat: r.vat_type, qty: '1' }]))} testID="ret-find" />
      {lines.map((l, i) => (
        <Card key={l.uid}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.name}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <QtyBox value={l.qty} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} testID={`ret-qty-${i}`} />
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
          </View>
        </Card>
      ))}
      <ReasonField testID="ret-reason" label="Why are they going back?" value={reason} onChangeText={setReason} placeholder="e.g. damaged, expired, wrong product" />
      <Field label="Note (optional)" value={notes} onChangeText={setNotes} />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo (optional)" />
    </Screen>
  );
}
