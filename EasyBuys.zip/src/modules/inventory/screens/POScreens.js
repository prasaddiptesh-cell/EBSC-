// Purchase orders: list, make / change, one order (approve, send by Viber, receive), receive a delivery, return to supplier.
import { db } from '../../../db/connection.js';
import { FixButton } from '../../admin/screens/RecordFixScreen.js';
import React, { useState, useEffect, useRef } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton, ReasonField } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shareReport, printReport } from '../../../platform/files.js';
import { listSuppliers, getSupplier, listInvoices } from '../../payables/service.js';
import * as I from '../service.js';
import { poReport, amendedPoReport, receiptReport } from '../reports.js';
import * as PA from '../poAmend.js';
import { addScanned } from '../scan.js';
import { ScanBar } from './scanUi.js';
import { readInvoicePhotos } from '../../../platform/invoiceReader.js';
import * as CL from '../invoiceClarify.js';
import { shopName, shopChips, useShop, ItemPicker, QtyBox, fq, VatTotals } from './common.js';
import { offerPdf } from '../../../ui/shareDoc.js';
import { PaidNowCard, BuyTypeChips, NOT_PAID, paidNowValue, paidNowProblem } from '../../../ui/paidNow.js';

// The order as a PDF to send to the Viber group (with prices, for the office).
const poDoc = (uid) => { const o = I.getPO(uid); return o ? { rep: poReport(uid, { prices: true }), photos: [], text: `Easy Buys – purchase order ${o.po_no} to ${o.supplier_name}, ${o.lines.filter((l) => l.qty > 0).length} item(s), ${I.$(o.total)}.` } : null; };

const { $ } = I;
const STATUS_COLOR = { draft: C.sub, awaiting: C.warn, approved: C.info, sent: C.info, part: C.warn, received: C.success, closed: C.sub, cancelled: C.sub };
const supOptions = () => listSuppliers().map((s) => ({ value: s.uid, label: s.name }));
// v3.9.3 cartons and singles. A product with a pack size above 1 is ordered in cartons by default (when the quantity is
// whole cartons); the line can be switched to singles. Quantities and prices on the line are in what is ordered.
const r3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
function newLine(it, qtySingles, costSingle) {
  const pack = Math.max(1, Number(it.pack_size) || 1);
  const q = Number(qtySingles) || 0;
  const carton = pack > 1 && (q === 0 || Math.abs(q / pack - Math.round(q / pack)) < 1e-9);
  return { itemUid: it.uid, name: it.name, code: it.code, unit: it.unit, itemPack: pack, orderAs: carton ? 'carton' : 'single', packSize: String(pack),
    qty: String(carton ? Math.max(1, r3(q / pack)) : q || 1), unitCost: String(carton ? Math.round((Number(costSingle) || 0) * pack * 10000) / 10000 : Number(costSingle) || 0), note: '' };
}
const r4c = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
// Receiving: cartons × pack + loose singles; the carton price ÷ pack is the price of a single.
const singlesOf = (g) => r3((Number(g.qty) || 0) * (g.pack || 1) + ((g.pack || 1) > 1 ? Number(g.loose) || 0 : 0));
const costOf = (g) => ((g.pack || 1) > 1 ? Math.round(((Number(g.cost) || 0) / g.pack) * 1000000) / 1000000 : Number(g.cost) || 0);
const xSingles = (x) => r3((Number(x.qty) || 0) + ((x.pack || 1) > 1 ? (Number(x.ctn) || 0) * x.pack : 0));
// "Singles in a carton" typed on a line that was singles: its quantity and price become cartons (never multiplied).
function packTyped(l0, v) {
  const l = { ...l0, each: undefined };
  const pack = Number(v);
  if (l.baseQty === undefined || !(pack > 1)) return { ...l, packSize: v };
  return { ...l, packSize: v, qty: String(Math.max(1, r3(l.baseQty / pack))), unitCost: String(Math.round(l.baseCost * pack * 10000) / 10000) };
}
// The cost of one item on a carton line (what was typed, else the carton price ÷ pack).
function eachOf(l) {
  if (l.each !== undefined) return l.each;
  const pack = Number(l.packSize) || 1;
  return l.unitCost === '' || l.unitCost === undefined ? '' : String(Math.round(((Number(l.unitCost) || 0) / pack) * 10000) / 10000);
}
function switchUnit(l0, to) {
  const l = { ...l0, each: undefined };
  if ((l.orderAs || 'single') === to) return l0;
  const pack = Math.max(1, Number(l.packSize) > 1 ? Number(l.packSize) : Number(l.itemPack) || 1);
  if (to === 'carton') {
    // No pack size known yet: keep the singles aside; once "Singles in a carton" is typed they are turned into cartons.
    if (pack <= 1) return { ...l, orderAs: 'carton', packSize: '', baseQty: Number(l.qty) || 0, baseCost: Number(l.unitCost) || 0, qty: '', unitCost: '' };
    return { ...l, orderAs: 'carton', packSize: String(pack), qty: String(Math.max(1, r3((Number(l.qty) || 0) / pack))), unitCost: String(Math.round((Number(l.unitCost) || 0) * pack * 10000) / 10000) };
  }
  if (!(Number(l.packSize) > 1) && l.baseQty !== undefined) { const { baseQty, baseCost, ...rest } = l; return { ...rest, orderAs: 'single', qty: String(baseQty), unitCost: String(baseCost) }; }
  return { ...l, orderAs: 'single', qty: String(r3((Number(l.qty) || 0) * pack)), unitCost: String(Math.round(((Number(l.unitCost) || 0) / pack) * 10000) / 10000) };
}

function BudgetBar({ supplierUid, total, date, exceptPo }) {
  if (!supplierUid) return null;
  const b = I.budgetCheck(supplierUid, total, date, exceptPo);
  if (b.weekBudget === null && b.monthBudget === null) return <Hint>No budget set for this supplier (Inventory settings › Supplier budgets).</Hint>;
  const line = (label, budget, used) => {
    if (budget === null) return null;
    const after = used + total;
    const pct = budget > 0 ? Math.min(100, (after / budget) * 100) : 100;
    const over = after > budget + 0.004;
    return (
      <View key={label} style={{ gap: 4 }}>
        <Text style={{ fontSize: 15, color: over ? C.danger : C.text, fontWeight: '700' }}>{label}: {$(used)} used + this order {$(total)} = {$(after)} of {$(budget)}{over ? ` – OVER by ${$(after - budget)}` : ` – ${$(budget - after)} left`}</Text>
        <View style={{ height: 10, borderRadius: 5, backgroundColor: '#EEE7DD' }}><View style={{ height: 10, borderRadius: 5, width: `${pct}%`, backgroundColor: over ? C.danger : pct > 85 ? C.warn : C.success }} /></View>
      </View>
    );
  };
  return (
    <Card tone={b.isOver ? 'danger' : undefined}>
      {line(`Week ${b.weekStart} – ${b.weekEnd}`, b.weekBudget, b.week)}
      {line(`Month`, b.monthBudget, b.month)}
      {b.isOver ? <Hint>{{ warn: 'Over budget: you can still send it.', approve: 'Over budget: a manager with approval rights must approve it before it can be sent.', block: 'Over budget: the admin does not allow this. Make the order smaller.' }[I.invRules().budgetMode]}</Hint> : null}
    </Card>
  );
}

// ---------------------------------------------------------------- list
export function POListScreen({ params }) {
  const { nav, can } = useApp();
  const [shop, setShop] = useShop(params.shopCode);
  const [status, setStatus] = useRemembered('status', params.status || 'open');
  const list = I.listPOs({ shopCode: shop, status: status === 'all' ? undefined : status, limit: 200 });
  const awaiting = I.listPOs({ status: 'awaiting' });
  return (
    <Screen title="Purchase orders" subtitle={shopName(shop)}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="po-shop" />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {can('po_create') ? <Btn testID="po-new" title="New order" icon="📝" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { shopCode: shop })} /> : null}
        {can('po_receive') ? <Btn testID="po-receive-free" title="Delivery with no order" icon="🚚" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POReceive', { shopCode: shop })} /> : null}
      </View>
      <Hint>An order goes: Draft → Approved (or "Waiting for approval" if over the budget or limit) → Sent to the supplier → Received. Receive deliveries from the order so stock and cost prices update by themselves.</Hint>
      {can('po_approve') && awaiting.length ? <Banner tone="warn" title={`${awaiting.length} order(s) waiting for your approval`} message={awaiting.map((o) => `${o.po_no} ${o.supplier_name} ${$(o.total)}`).join('\n')} /> : null}
      <Chips value={status} onChange={setStatus} testIDPrefix="po-st" options={[{ value: 'open', label: 'Open' }, { value: 'to_receive', label: 'To receive' }, { value: 'awaiting', label: 'To approve' }, { value: 'all', label: 'All' }]} />
      {!list.length ? <Text style={{ color: C.sub }}>No orders here.</Text> : null}
      {list.map((o) => (
        <ListItem key={o.uid} testID={`po-${o.po_no}`} onPress={() => nav.push('POView', { uid: o.uid })} title={`${o.po_no} · ${o.supplier_name}`}
          sub={`${o.order_date}${o.expected_date ? ` · due ${o.expected_date}` : ''} · by ${o.created_by_name || ''}${o.sent_via ? ` · sent by ${o.sent_via}` : ''}`}
          right={$(o.total)} badge={I.PO_STATUS[o.status]} badgeColor={STATUS_COLOR[o.status]}
          tone={['sent', 'approved'].includes(o.status) && o.expected_date && o.expected_date < dateStr() ? 'warn' : undefined} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- make / change
export function POEditScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const before = params.uid ? I.getPO(params.uid) : null;
  // Sent / received orders are changed as an amendment (approvers only), keeping what has arrived.
  const mode = before ? PA.poEditMode(user, before).mode : 'full';
  const amend = mode === 'sent' || mode === 'received';
  const [why, setWhy] = useState('');
  const [orderDate, setOrderDate] = useState(before ? before.order_date : dateStr());
  const [shop, setShop] = useShop(before ? before.shop_code : params.shopCode);
  const [sup, setSup] = useState(before ? before.supplier_uid : params.supplierUid || '');
  const [lines, setLines] = useState(() => (before ? before.lines.filter((l) => l.qty > 0).map((l) => { const v = I.orderView(l); return { lineUid: amend ? l.uid : undefined, received: amend ? l.qty_received : 0, itemUid: l.item_uid, name: l.name, code: l.code, unit: l.unit, qty: String(v.qty), unitCost: String(v.cost), note: l.note || '', orderAs: v.carton ? 'carton' : 'single', packSize: String(v.pack), itemPack: l.item_uid ? Number((I.getItem(l.item_uid) || {}).pack_size) || 1 : 1 }; }) : []));
  const [notes, setNotes] = useState(before ? before.notes || '' : '');
  const [expected, setExpected] = useState(before ? before.expected_date || '' : '');
  const total = lines.reduce((s, l) => s + I.incVat((Number(l.qty) || 0) * (Number(l.unitCost) || 0), l.itemUid ? (I.getItem(l.itemUid) || {}).vat_type : 'standard'), 0);
  const addSuggested = (quiet) => {
    const sug = I.suggestFor(shop, sup).filter((x) => !lines.some((l) => l.itemUid === x.itemUid));
    if (!sug.length) { if (!quiet) ui.toast('Nothing from this supplier needs ordering right now', 'info'); return; }
    setLines(lines.concat(sug.map((x) => ({ ...newLine(I.getItem(x.itemUid) || {}, x.qty, x.unitCost), why: x.why }))));
  };
  // Opened from an order reminder: start with the suggested quantities.
  const suggested = useRef(false);
  useEffect(() => { if (params.suggest && !before && sup && !suggested.current) { suggested.current = true; addSuggested(true); } }, [sup]);
  if (before && mode === 'none') return <Screen title={`Change ${before.po_no}`}><Banner tone="warn" message={PA.poEditMode(user, before).why} /></Screen>;
  const saveAmend = () => {
    try {
      const r = PA.amendPO(user, before.uid, { orderDate, expectedDate: expected, notes, lines: lines.map((l) => ({ lineUid: l.lineUid, itemUid: l.itemUid, name: l.name, code: l.code, unit: l.unit, qty: l.qty, unitCost: l.unitCost, note: l.note, orderAs: l.orderAs || 'single', packSize: l.packSize })) }, { reason: why });
      ui.toast(`Changed – version ${r.version}`);
      nav.replace('POView', { uid: before.uid });
      if (r.offerAmended) {
        offerPdf(ui, () => ({ rep: amendedPoReport(before.uid), photos: [], text: `AMENDED purchase order ${before.po_no} to ${before.supplier_name}: ${r.changes.join('; ')}` }), { title: 'Send the AMENDED order to the supplier?', force: true })
          .then((sent) => { if (sent) PA.markAmendedSent(user, before.uid, 'pdf'); });
      }
    } catch (e) { ui.error(e); }
  };
  const save = (submit) => {
    // A line switched to cartons needs "Singles in a carton" – otherwise it would be dropped from the order.
    const noPack = lines.find((l) => l.orderAs === 'carton' && !(Number(l.packSize) > 1));
    if (noPack) { ui.alert({ title: 'How many in a carton?', message: `Type "Singles in a carton" for ${noPack.name}, or switch it back to Singles.`, tone: 'warn' }); return; }
    if (amend) { saveAmend(); return; }
    try {
      const o = I.savePO(user, { uid: before && before.uid, supplierUid: sup, shopCode: shop, lines, notes, expectedDate: expected });
      if (submit) {
        const r = I.submitPO(user, o.uid, { canApprove: false });
        ui.toast(r.status === 'awaiting' ? 'Saved – waiting for approval' : 'Approved – ready to send');
        nav.replace('POView', { uid: o.uid });
        offerPdf(ui, () => poDoc(o.uid), { title: r.status === 'awaiting' ? 'Send the order to the Viber group for approval?' : 'Send the order PDF to Viber?' });
        return;
      } else ui.toast('Draft saved');
      nav.replace('POView', { uid: o.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={before ? `Change ${before.po_no}` : 'New purchase order'} subtitle={shopName(shop)}
      footer={amend ? <Btn testID="po-amend" title={`Save the change · ${$(total)}`} icon="✏️" size="md" variant="success" onPress={() => save(false)} /> : <View style={{ flexDirection: 'row', gap: 10 }}>
        <Btn testID="po-save" title="Save draft" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => save(false)} />
        <Btn testID="po-submit" title={`Finish · ${$(total)}`} size="md" variant="success" style={{ flex: 1 }} onPress={() => save(true)} />
      </View>}>
      {amend ? <Banner testID="pe-amend" tone="warn" title={mode === 'sent' ? 'This order was already sent' : 'Goods have already arrived'} message={PA.EDIT_MODE_LABEL[mode]} /> : null}
      {amend ? null : <Label>For shop</Label>}
      {amend ? null : <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="pe-shop" />}
      {amend ? null : <Select testID="pe-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />}
      {sup ? <BudgetBar supplierUid={sup} total={total} date={dateStr()} exceptPo={before && before.uid} /> : null}
      {sup ? <Btn testID="pe-suggest" title="Add what needs ordering" icon="✨" size="md" variant="info" onPress={() => addSuggested(false)} /> : null}
      {sup ? <ScanBar testID="pe-scan" supplierUid={sup} shopCode={shop} startOpen={!!params.scan} onItem={(it, n) => { setLines((cur) => addScanned(cur, it, n)); const l = lines.find((x) => x.itemUid === it.uid); if (l && l.orderAs === 'carton') ui.toast(`${it.name}: ${n} more carton(s) of ${l.packSize}`, 'info'); }} hint="Scan each product and type how many to order – in the line's unit (cartons on a carton line)." /> : null}
      <Hint>"Add what needs ordering" looks at this shop's stock, its sales over the last weeks, what is already on order and the supplier's delivery days.</Hint>
      <ItemPicker shopCode={shop} supplierUid={sup || undefined} exclude={lines.map((l) => l.itemUid)} onPick={(r) => setLines(lines.concat([newLine(I.getItem(r.uid) || r, r.suggest || r.reorder_qty || 0, r.lastCost ?? r.cost)]))} testID="pe-find" />
      {lines.length ? <Hint>The cost price comes from the product (the last price paid). Change the quantity, the price if the supplier quoted a different one, and add a comment for the supplier if needed. You can change the order until it is sent.</Hint> : null}
      {lines.map((l, i) => (
        <Card key={`${l.itemUid}-${i}`}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name} <Text style={{ fontSize: 14, color: C.sub }}>{l.code}</Text></Text>
          {l.received ? <Text style={{ fontSize: 13, color: C.success }}>{fq(l.received)} already arrived – the order cannot go below that</Text> : null}
          {l.why ? <Text style={{ fontSize: 13, color: C.sub }}>{l.why}</Text> : null}
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
            <Chips value={l.orderAs || 'single'} onChange={(to) => setLines(lines.map((x, k) => (k === i ? switchUnit(x, to) : x)))} testIDPrefix={`pe-as-${i}`}
              options={[{ value: 'carton', label: 'Cartons' }, { value: 'single', label: 'Singles' }]} />
            {l.orderAs === 'carton' ? <View style={{ width: 120 }}><Field testID={`pe-pack-${i}`} label="Singles in a carton" value={String(l.packSize || '')} onChangeText={(v) => setLines(lines.map((x, k) => (k === i ? packTyped(x, v) : x)))} keyboardType="number-pad" /></View> : null}
            {l.orderAs === 'carton' && Number(l.packSize) > 1 && Number(l.qty) > 0 ? <Text style={{ fontSize: 14, color: C.sub }}>= {fq((Number(l.qty) || 0) * (Number(l.packSize) || 1))} {l.unit || 'singles'} into stock</Text> : null}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
            <QtyBox value={l.qty} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} testID={`pe-qty-${i}`} />
            <Text style={{ fontSize: 15, color: C.sub }}>{l.orderAs === 'carton' ? `carton(s) of ${l.packSize}` : l.unit}</Text>
            {/* v3.9.3 cost is per item; on a carton line type either the cost of each item or the carton price – the other follows */}
            {l.orderAs === 'carton' && Number(l.packSize) > 1 ? <View style={{ width: 130 }}><MoneyField testID={`pe-each-${i}`} label="Cost each (excl. VAT)" value={eachOf(l)} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, unitCost: v === '' ? '' : String(Math.round((Number(v) || 0) * Number(x.packSize) * 10000) / 10000), each: v } : x)))} /></View> : null}
            <View style={{ width: 130 }}><MoneyField testID={`pe-cost-${i}`} label={l.orderAs === 'carton' ? 'Carton price (excl. VAT)' : 'Unit cost (excl. VAT)'} value={l.unitCost} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, unitCost: v, each: undefined } : x)))} /></View>
            <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{$((Number(l.qty) || 0) * (Number(l.unitCost) || 0))}</Text>
            <View style={{ flexBasis: 220, flexGrow: 1 }}><Field testID={`pe-note-${i}`} label="Comment (goes to the supplier)" value={l.note || ''} onChangeText={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, note: v } : x)))} placeholder="e.g. same brand as last time" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
          </View>
        </Card>
      ))}
      {lines.length ? <VatTotals testID="pe-totals" split={I.vatSplit(lines.map((l) => ({ amount: (Number(l.qty) || 0) * (Number(l.unitCost) || 0), vatType: l.itemUid ? (I.getItem(l.itemUid) || {}).vat_type : 'standard' })))} /> : null}
      {amend ? <DateField label="Order date" value={orderDate} onChange={setOrderDate} /> : null}
      <DateField label="Deliver by (optional)" value={expected} onChange={setExpected} />
      <Field label="Note to the supplier (optional)" value={notes} onChangeText={setNotes} multiline />
      {amend ? <ReasonField testID="pe-why" label="Why is it changed?" value={why} onChangeText={setWhy} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- one order
export function POViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const [reason, setReason] = useState('');
  const o = I.getPO(params.uid);
  if (!o) return <Screen title="Order"><Text>Not found.</Text></Screen>;
  const sup = getSupplier(o.supplier_uid) || {};
  const text = I.poText(o.uid);
  const viber = async () => {
    if (sup.viber_group) ui.toast(`In Viber, pick the group "${sup.viber_group}"`);
    const l = I.viberLink(text, sup.viber_group ? null : sup.viber || sup.phone);
    try {
      await Linking.openURL(l.forward);
      act(() => I.markSent(user, o.uid, 'viber'), 'Marked as sent by Viber');
    } catch (e) { ui.alert({ title: 'Viber did not open', message: 'Is Viber installed on this device? You can also share the PDF instead.' }); }
  };
  const pdf = async () => {
    try { await shareReport(poReport(o.uid), 'pdf'); act(() => I.markSent(user, o.uid, 'pdf'), 'Marked as sent'); } catch (e) { ui.error(e); }
  };
  const canSend = ['approved', 'sent', 'part'].includes(o.status);
  return (
    <Screen title={`${o.po_no} · ${o.supplier_name}`} subtitle={`${shopName(o.shop_code)} · ${I.PO_STATUS[o.status]}`}>
      <FixButton table="po_orders" keyVal={o.uid} />
      <Stats items={[
        { label: 'Order total (incl. VAT)', value: $(o.total) },
        { label: 'Received', value: `${o.receivedPct}%`, sub: $(o.receivedValue), color: o.receivedPct >= 100 ? C.success : undefined },
        { label: 'Invoiced', value: $(o.invoiced), sub: `${o.invoices.length} invoice(s)` },
      ]} />
      {o.budget_note ? <Banner tone={o.status === 'awaiting' || o.status === 'draft' ? 'warn' : 'info'} message={o.budget_note} /> : null}
      <Card>
        <Row label="Ordered" value={`${o.order_date} by ${o.created_by_name || ''}`} />
        {o.expected_date ? <Row label="Deliver by" value={o.expected_date} color={canSend && o.expected_date < dateStr() && o.status !== 'part' ? C.danger : undefined} /> : null}
        {o.approved_by_name ? <Row label="Approved" value={`${o.approved_by_name} · ${String(o.approved_at || '').slice(0, 16)}`} /> : null}
        {o.sent_at ? <Row label="Sent" value={`${String(o.sent_at).slice(0, 16)} by ${o.sent_via}`} /> : null}
        {o.cancel_reason ? <Row label={o.status === 'closed' ? 'Closed short' : 'Cancelled'} value={o.cancel_reason} /> : null}
        {o.notes ? <Row label="Note" value={o.notes} /> : null}
      </Card>
      <VatTotals testID="pv-totals" title="THIS ORDER" split={I.vatSplit(o.lines.filter((l) => l.qty > 0).map((l) => ({ amount: (Number(l.qty) || 0) * (Number(l.unit_cost) || 0), vatType: l.item_uid ? (I.getItem(l.item_uid) || {}).vat_type : 'standard' })))} />
      <Section title="Products">
        {o.lines.filter((l) => l.qty > 0).map((l) => (
          <ListItem key={l.uid} title={l.name} sub={`${l.code || ''} · ${$(l.unit_cost)} each`} right={`${fq(l.qty_received)} / ${fq(l.qty)} ${l.unit || ''}`}
            rightSub={l.qty_received >= l.qty ? 'all here' : l.qty_received ? `${fq(l.qty - l.qty_received)} to come` : ''} tone={l.qty_received >= l.qty ? 'success' : undefined} />
        ))}
      </Section>
      {(() => { const m = PA.poEditMode(user, o).mode; return m === 'sent' || m === 'received' ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="pv-amend" title={m === 'sent' ? 'Change the order (amend)' : 'Change what has not arrived'} icon="✏️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { uid: o.uid })} />
        </View>
      ) : null; })()}
      {o.version > 1 ? (
        <Card tone={o.amended_at && !o.amend_sent_at && ['sent', 'part'].includes(o.status) ? 'warn' : undefined}>
          <Row label="Version" value={`${o.version}${o.amended_at ? ` · changed ${String(o.amended_at).slice(0, 16)} by ${o.amended_by_name}` : ''}`} />
          {o.amended_at ? <Row label="Amended order sent" value={o.amend_sent_at ? String(o.amend_sent_at).slice(0, 16) : 'not yet'} color={o.amend_sent_at ? undefined : C.warn} /> : null}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            {o.amended_at ? <Btn testID="pv-amended-pdf" title="Send the AMENDED order" icon="📄" size="sm" variant="info" onPress={async () => { try { await shareReport(amendedPoReport(o.uid), 'pdf'); act(() => PA.markAmendedSent(user, o.uid, 'pdf'), 'Marked as sent'); } catch (e) { ui.error(e); } }} /> : null}
            {o.amended_at && !o.amend_sent_at ? <Btn testID="pv-amended-sent" title="Told the supplier another way" size="sm" variant="ghost" onPress={() => act(() => PA.markAmendedSent(user, o.uid, 'other'), 'Marked as sent')} /> : null}
            <Btn testID="pv-history" title="Change history" icon="🕘" size="sm" variant="secondary" onPress={() => nav.push('POHistory', { uid: o.uid })} />
          </View>
        </Card>
      ) : null}
      {['draft', 'awaiting', 'approved'].includes(o.status) && can('po_create') ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="pv-edit" title="Change" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('POEdit', { uid: o.uid })} />
          {o.status === 'draft' ? <Btn testID="pv-submit" title="Finish (approve / ask for approval)" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => I.submitPO(user, o.uid, { canApprove: false }), 'Done')} /> : null}
        </View>
      ) : null}
      {o.status === 'awaiting' && I.mayApprovePO(user, o.shop_code) ? (
        <Card tone="warn">
          <H>Approve this order?</H>
          <BudgetBar supplierUid={o.supplier_uid} total={o.total} date={o.order_date} exceptPo={o.uid} />
          <ReasonField testID="pv-reason" label="Why it is OK to go over the budget" value={reason} onChangeText={setReason} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID="pv-approve" title="Approve" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => I.submitPO(user, o.uid, { canApprove: true, reason }), 'Approved')) offerPdf(ui, () => poDoc(o.uid), { title: 'Send the approved order PDF to Viber?' }); }} />
            <Btn testID="pv-reject" title="Send back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => act(() => I.rejectPO(user, o.uid, reason || 'Not approved'), 'Sent back to draft')} />
          </View>
        </Card>
      ) : null}
      {canSend ? (
        <Section title="Send to the supplier">
          <Hint>{o.sent_at ? 'This order has been sent – it goes to the supplier once. A changed order is sent again as "amended".' : sup.viber_group ? `Viber opens with the order typed out – pick the group "${sup.viber_group}" and press send. Or share the PDF. Prices are not shown to the supplier.` : 'Viber opens with the order typed out – pick the supplier\'s chat and press send. Or share the PDF (Viber, email, WhatsApp…). Prices are not shown to the supplier.'}</Hint>
          {o.status === 'approved' && !o.sent_at && o.approved_by_name ? <Banner testID="pv-approved-send" tone="success" title={`Approved by ${o.approved_by_name} – send it`} message="It has not gone to the supplier yet." /> : null}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            {!o.sent_at ? <Btn testID="pv-viber" title="Send by Viber" icon="💬" variant="info" style={{ flexGrow: 1 }} onPress={viber} /> : null}
            {!o.sent_at ? <Btn testID="pv-pdf" title="Share PDF" icon="📄" variant="secondary" style={{ flexGrow: 1 }} onPress={pdf} /> : null}
            <Btn title="Print" icon="🖨️" variant="secondary" style={{ flexGrow: 1 }} onPress={() => printReport(poReport(o.uid)).catch((e) => ui.error(e))} />
          </View>
          {!o.sent_at ? <Btn testID="pv-sent" title="Mark as sent (phoned / sent another way)" size="sm" variant="ghost" onPress={() => act(() => I.markSent(user, o.uid, 'other'), 'Marked as sent')} /> : null}
        </Section>
      ) : null}
      {canSend && can('po_receive') ? <Btn testID="pv-receive" title="Receive the delivery" icon="🚚" variant="success" onPress={() => nav.push('POReceive', { poUid: o.uid })} /> : null}
      {(() => {
        // v3.9: the supplier invoices joined to this order (tap to open).
        let invs = [];
        try { invs = db().all("SELECT uid, invoice_no, invoice_date, total, status FROM ap_invoices WHERE po_uid = ? AND status <> 'void' ORDER BY invoice_date", [o.uid]); } catch (e) { invs = []; }
        return (
          <Section title="Supplier invoices">
            {invs.map((x) => <ListItem key={x.uid} testID={`pv-inv-${x.invoice_no || x.uid}`} title={`Invoice ${x.invoice_no || '(no number)'} · ${x.invoice_date}`} right={$(x.total)} badge={x.status === 'to_check' ? 'TO CHECK' : null} badgeColor={C.warn} onPress={() => nav.push('ApInvoice', { uid: x.uid })} />)}
            {!invs.length ? <Hint>No invoice joined to this order yet – it is joined when the delivery is received with its invoice.</Hint> : null}
          </Section>
        );
      })()}
      {o.receipts.length ? (
        <Section title="Deliveries">
          {o.receipts.map((r) => (
            <ListItem key={r.uid} title={`${r.receive_date} · ${r.by_name}`} sub={`${r.lines.length} products${r.invoice_no ? ` · invoice ${r.invoice_no}` : ' · no invoice yet'}${r.match_note ? ` · ${r.match_note}` : ''}`}
              right={$(r.total)} badge={r.status === 'void' ? 'VOID' : null} badgeColor={C.sub} onPress={() => nav.push('Receipt', { uid: r.uid })} />
          ))}
        </Section>
      ) : null}
      <View style={{ gap: 10 }}>
        {o.status === 'part' && can('po_create') ? <ReasonButton testID="pv-close" title="Close short (the rest is not coming)" prompt="Why is the rest not coming?" confirm="Close order" variant="warn" onDo={(w) => act(() => I.closeShort(user, o.uid, w), 'Closed')} /> : null}
        {['draft', 'awaiting', 'approved', 'sent'].includes(o.status) && can('po_create') ? <ReasonButton testID="pv-cancel" title="Cancel order" prompt="Why is it cancelled?" confirm="Cancel order" onDo={(w) => act(() => I.cancelPO(user, o.uid, w), 'Cancelled')} /> : null}
      </View>
    </Screen>
  );
}

// ---------------------------------------------------------------- receive a delivery
export function POReceiveScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const o = params.poUid ? I.getPO(params.poUid) : null;
  const [shop, setShop] = useShop(o ? o.shop_code : params.shopCode);
  const [sup, setSup] = useState(o ? o.supplier_uid : params.supplierUid || '');
  // v3.9.3 a line ordered in cartons is received in cartons + loose singles, at the carton price.
  const [got, setGot] = useState(() => Object.fromEntries((o ? o.lines : []).filter((l) => l.qty > l.qty_received).map((l) => {
    const v = I.orderView(l);
    const left = Math.max(0, l.qty - l.qty_received);
    if (!v.carton) return [l.uid, { qty: String(left), cost: String(l.unit_cost), pack: 1 }];
    const ctn = Math.floor(left / v.pack + 1e-9);
    return [l.uid, { qty: String(ctn), loose: String(r3(left - ctn * v.pack)), cost: String(v.cost), pack: v.pack }];
  })));
  const [extra, setExtra] = useState([]);
  const [invMode, setInvMode] = useState('now');
  const [inv, setInv] = useState({ invoiceNo: '', total: '', photos: [] });
  const [linkUid, setLinkUid] = useState('');
  const [date, setDate] = useState(dateStr());
  const [notes, setNotes] = useState('');
  const [buyType, setBuyType] = useState(params.buyType || 'supplier_came');
  const [paidNow, setPaidNow] = useState(NOT_PAID);
  const [why, setWhy] = useState('');
  const [needWhy, setNeedWhy] = useState('');
  const [photos, setPhotos] = useState([]);
  const [readRes, setReadRes] = useState(null);
  const [reading, setReading] = useState(false);
  const [readOk, setReadOk] = useState(false);
  const [readUid, setReadUid] = useState(null);
  const [answers, setAnswers] = useState({}); // 1.0.0 the receiver's answers about prices and quantities
  const scanned = useRef(new Set());
  const lines = o ? o.lines.filter((l) => l.qty > 0) : [];
  // Numbers from a read invoice (Read a supplier invoice › Receive with these numbers, or "Read the invoice photo" here).
  const applyRead = (pre) => {
    if (!pre) return;
    setInv((cur) => ({ ...cur, invoiceNo: pre.invoiceNo || cur.invoiceNo, total: pre.total !== undefined && pre.total !== null && pre.total !== '' ? String(pre.total) : cur.total, photos: pre.photos && pre.photos.length ? pre.photos : cur.photos }));
    const g = { ...got };
    const ex = [...extra];
    for (const l of pre.lines || []) {
      const pl = lines.find((x) => x.item_uid === l.itemUid && x.qty > x.qty_received);
      if (pl) {
        const v = I.orderView(pl);
        // Ordered in cartons: the invoice is read as cartons, unless its price looks like a single's price.
        const single = v.carton && Number(l.unitCost) > 0 && Number(l.unitCost) < (v.cost / v.pack) * 1.5;
        g[pl.uid] = !v.carton ? { qty: String(l.qty), cost: String(l.unitCost), pack: 1 }
          : single ? { qty: '0', loose: String(l.qty), cost: String(r4c(Number(l.unitCost) * v.pack)), pack: v.pack }
            : { qty: String(l.qty), loose: '0', cost: String(l.unitCost), pack: v.pack };
      }
      else if (l.itemUid && !ex.some((x) => x.itemUid === l.itemUid)) { const it = I.getItem(l.itemUid); if (it) ex.push({ itemUid: it.uid, name: it.name, unit: it.unit, qty: String(l.qty), cost: String(l.unitCost) }); }
    }
    setGot(g); setExtra(ex);
  };
  const prefilled = useRef(false);
  useEffect(() => { if (params.prefill && !prefilled.current) { prefilled.current = true; applyRead(params.prefill); } }, []);
  const readPhoto = async (list) => {
    setReading(true);
    try {
      const r = await readInvoicePhotos(user, list || inv.photos, { supplierUid: sup || undefined, poUid: o ? o.uid : undefined });
      if (!r.ok) ui.toast(`Could not read the photo – type the invoice number and total yourself`);
      else { setReadRes(r.result); setReadUid(r.readUid || null); setAnswers({}); setReadOk(false); applyRead({ invoiceNo: r.result.invoiceNo, total: r.result.total, lines: r.result.lines.filter((l) => l.itemUid) }); ui.toast(r.message || 'Read – check the figures'); }
    } catch (e) { ui.error(e); }
    setReading(false);
  };
  const onScan = (it, n) => {
    const pl = lines.find((x) => x.item_uid === it.uid && x.qty > x.qty_received);
    if (pl) {
      const first = !scanned.current.has(pl.uid);
      scanned.current.add(pl.uid);
      const cur = got[pl.uid] || { qty: '0', cost: String(I.orderView(pl).cost), pack: I.orderView(pl).pack };
      // A scan counts singles. On a carton line it goes into the loose singles (the first scan starts the count afresh).
      if ((cur.pack || 1) > 1) setGot({ ...got, [pl.uid]: { ...cur, qty: first ? '0' : cur.qty, loose: String(first ? n : Math.round(((Number(cur.loose) || 0) + n) * 1000) / 1000) } });
      else setGot({ ...got, [pl.uid]: { ...cur, qty: String(first ? n : Math.round(((Number(cur.qty) || 0) + n) * 1000) / 1000) } });
    } else {
      const i = extra.findIndex((x) => x.itemUid === it.uid);
      if (i >= 0) setExtra(extra.map((x, k) => (k === i ? { ...x, qty: String((Number(x.qty) || 0) + n) } : x)));
      else setExtra(extra.concat([{ itemUid: it.uid, name: it.name, unit: it.unit, qty: String(n), cost: String(it.cost) }]));
    }
  };
  const split = I.vatSplit(lines.filter((l) => got[l.uid]).map((l) => ({ amount: singlesOf(got[l.uid]) * costOf(got[l.uid]), vatType: (I.getItem(l.item_uid) || {}).vat_type }))
    .concat(extra.map((x) => ({ amount: xSingles(x) * (Number(x.cost) || 0), vatType: (I.getItem(x.itemUid) || {}).vat_type }))));
  const value = lines.reduce((s, l) => s + (got[l.uid] ? I.incVat(singlesOf(got[l.uid]) * costOf(got[l.uid]), (I.getItem(l.item_uid) || {}).vat_type) : 0), 0)
    + extra.reduce((s, x) => s + I.incVat(xSingles(x) * (Number(x.cost) || 0), (I.getItem(x.itemUid) || {}).vat_type), 0);
  // 1.0.0 questions for the receiver: what was counted / the price entered against the invoice and the order
  const questions = (() => {
    if (!readRes) return [];
    try {
      const view = (l) => I.orderView(l);
      // the invoice lines in singles (an order in cartons is read in cartons unless the price is a single's)
      const readLines = (readRes.lines || []).map((x) => {
        const pl = lines.find((y) => y.item_uid === x.itemUid);
        if (!pl) return x;
        const v = view(pl);
        const single = !v.carton || (Number(x.unitCost) > 0 && Number(x.unitCost) < (v.cost / v.pack) * 1.5);
        return single ? x : { ...x, qty: (Number(x.qty) || 0) * v.pack, unitCost: (Number(x.unitCost) || 0) / v.pack };
      });
      const rows = lines.filter((l) => got[l.uid]).map((l) => ({ key: l.uid, itemUid: l.item_uid, name: l.name, counted: singlesOf(got[l.uid]), cost: costOf(got[l.uid]), orderCost: l.unit_cost }))
        .concat(extra.map((x, i) => ({ key: `x${i}`, itemUid: x.itemUid, name: x.name, counted: xSingles(x), cost: Number(x.cost) || 0, orderCost: null })));
      const onInv = new Set(readLines.map((x) => x.itemUid).filter(Boolean));
      const missing = lines.filter((l) => l.item_uid && !onInv.has(l.item_uid) && !(got[l.uid] && singlesOf(got[l.uid]) > 0)).map((l) => ({ itemUid: l.item_uid, name: l.name }));
      return CL.receiverQuestions({ ...readRes, lines: readLines }, rows, { supplierUid: sup || (o && o.supplier_uid), supplierName: o ? o.supplier_name : (getSupplier(sup) || {}).name, missing });
    } catch (e) { return []; }
  })();
  const answered = CL.receiverAnswers(questions, answers);
  const answer = (q, value) => {
    const next = { ...answers, [q.id]: value };
    setAnswers(next);
    const a = CL.receiverAnswers([q], { [q.id]: value });
    // it came after all: add it to this delivery
    if (a.add.length) {
      setExtra(extra.concat(a.add.filter((x) => !extra.some((e) => e.itemUid === x.itemUid)).map((x) => ({ itemUid: x.itemUid, name: x.name, unit: x.unit, qty: String(x.qty), cost: String(x.cost) }))));
      return;
    }
    const ch = a.set[q.key];
    if (!ch) return;
    if (String(q.key).startsWith('x')) {
      const i = Number(String(q.key).slice(1));
      setExtra(extra.map((x, k) => (k === i ? { ...x, ...(ch.counted !== undefined ? { qty: String(ch.counted), ctn: '0' } : {}), ...(ch.cost !== undefined ? { cost: String(ch.cost) } : {}) } : x)));
    } else {
      const g = got[q.key] || {};
      const pack = g.pack || 1;
      setGot({ ...got, [q.key]: { ...g, ...(ch.counted !== undefined ? (pack > 1 ? { qty: '0', loose: String(ch.counted) } : { qty: String(ch.counted) }) : {}), ...(ch.cost !== undefined ? { cost: String(Math.round(ch.cost * pack * 1000000) / 1000000) } : {}) } });
    }
  };
  const openInvoices = sup ? listInvoices({ filter: 'all', supplierUid: sup, limit: 30 }).filter((i) => i.kind === 'invoice' && !i.po_uid && i.status !== 'void') : [];
  const save = async (allowDuplicate = false) => {
    if (answered.open.length) { ui.alert({ title: 'Answer the questions first', message: answered.open.map((q) => `• ${q.text}`).join('\n'), tone: 'warn' }); return; }
    if (readRes && !readOk) { ui.alert({ title: 'Check first', message: 'The invoice number, total and quantities were filled in from the invoice photo. Count the goods, change any quantity that is different, then tick "I counted the goods and checked the invoice figures".', tone: 'warn' }); return; }
    if (!o) { const pp = paidNowProblem(paidNow); if (pp) { ui.alert({ title: 'Paid now', message: pp, tone: 'warn' }); return; } }
    try {
      const r = I.receiveDelivery(user, {
        poUid: o && o.uid, supplierUid: sup, shopCode: shop, date, notes, photos, acceptReason: [answered.reason, why].filter(Boolean).join('. '), readUid, claims: answered.claims, owed: answered.owed, settle: answered.settle,
        lines: Object.entries(got).map(([lineUid, g]) => ({ lineUid, qty: singlesOf(g), unitCost: (g.pack || 1) > 1 ? costOf(g) : g.cost })),
        extra: extra.map((x) => ({ itemUid: x.itemUid, qty: xSingles(x), unitCost: x.cost })),
        invoice: invMode === 'link' && linkUid ? { uid: linkUid } : invMode === 'now' ? { invoiceNo: inv.invoiceNo, total: inv.total, photos: inv.photos, date, allowDuplicate } : null,
        buyType: o ? undefined : buyType, paidNow: o ? undefined : paidNowValue(paidNow),
      });
      ui.toast(r.costFlags.length ? `Received – ${r.costFlags.length} cost price change(s) flagged` : 'Received – stock updated');
      nav.replace('Receipt', { uid: r.uid });
    } catch (e) {
      if (e.duplicate) { // build 30: the same invoice entered already
        const go = await ui.confirm({ title: 'Already entered?', message: `${e.message}\n\nOnly save it if it is a different invoice.`, confirmText: 'It is different – save', cancelText: 'Don\'t save', tone: 'warn' });
        if (go) save(true);
        return;
      }
      if (/^Please check/.test(e.message)) setNeedWhy(e.message); else ui.error(e);
    }
  };
  return (
    <Screen title={o ? `Receive ${o.po_no}` : 'Receive a delivery (no order)'} subtitle={`${o ? o.supplier_name : ''} · ${shopName(shop)}`}
      footer={<Btn testID="rc-save" title={`Received · ${$(value)}`} icon="✅" variant="success" onPress={() => save()} />}>
      <Hint>Count what actually came off the truck. Change the number if less (or more) arrived, and the price if the invoice price is different – the product's cost price is updated and the change is flagged for checking.</Hint>
      {!o ? (
        <>
          <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="rc-shop" />
          <Select testID="rc-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />
          {(() => {
            let open = [];
            try { open = sup ? I.listPOs({ supplierUid: sup, shopCode: shop, status: 'to_receive', limit: 10 }) : []; } catch (e) { open = []; }
            return open.length ? (
              <Card tone="info">
                <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Is this delivery for one of these orders?</Text>
                {open.map((x) => <Btn key={x.uid} testID={`rc-po-${x.po_no}`} title={`${x.po_no} · ordered ${x.order_date} · ${I.$(x.total)}`} icon="📝" size="md" variant="secondary" onPress={() => nav.replace('POReceive', { poUid: x.uid })} />)}
              </Card>
            ) : null;
          })()}
          <Banner tone="warn" message="No purchase order: take a photo of the invoice (or the goods) below – it is kept with the invoice." />
          <BuyTypeChips value={buyType} onChange={setBuyType} testID="rc-buy" />
          <PaidNowCard value={paidNow} onChange={setPaidNow} shopCode={shop} testID="rc-paid" />
        </>
      ) : null}
      <ScanBar testID="rc-scan" supplierUid={sup} shopCode={shop} onItem={onScan} hint="Scan each product as it comes off the truck and type how many. The first scan of an ordered product replaces the expected number; more scans add to it." />
      {lines.map((l) => {
        const v = I.orderView(l);
        const g = got[l.uid] || { qty: '0', loose: '0', cost: String(v.cost), pack: v.pack };
        const left = l.qty - l.qty_received;
        const priceDiff = Math.abs((Number(g.cost) || 0) - v.cost) > 0.00005;
        return (
          <Card key={l.uid} tone={left <= 0 ? 'success' : priceDiff ? 'warn' : undefined}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>Ordered {fq(v.qty)} {v.unit}{v.carton ? ` (${fq(l.qty)} ${l.unit || 'singles'})` : ''}{l.qty_received ? ` · already received ${v.carton ? `${fq(l.qty_received)} singles` : fq(l.qty_received)}` : ''} · order price {$(v.cost)}{v.carton ? ' a carton' : ''}</Text>
            {left > 0 ? (
              <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
                <QtyBox value={g.qty} onChange={(x) => setGot({ ...got, [l.uid]: { ...g, qty: x } })} testID={`rc-qty-${l.code}`} />
                {v.carton ? <Text style={{ fontSize: 15, color: C.sub }}>cartons +</Text> : null}
                {v.carton ? <QtyBox value={g.loose || '0'} onChange={(x) => setGot({ ...got, [l.uid]: { ...g, loose: x } })} testID={`rc-loose-${l.code}`} /> : null}
                {v.carton ? <Text style={{ fontSize: 15, color: C.sub }}>singles = {fq(singlesOf(g))}</Text> : null}
                {v.carton ? <View style={{ width: 150 }}><MoneyField testID={`rc-each-${l.code}`} label="Invoice cost each (excl. VAT)" value={g.each !== undefined ? g.each : String(Math.round(((Number(g.cost) || 0) / v.pack) * 10000) / 10000)} onChange={(x) => setGot({ ...got, [l.uid]: { ...g, each: x, cost: x === '' ? '' : String(Math.round((Number(x) || 0) * v.pack * 10000) / 10000) } })} /></View> : null}
                <View style={{ width: 150 }}><MoneyField testID={`rc-cost-${l.code}`} label={v.carton ? 'Invoice price a carton (excl. VAT)' : 'Invoice price (excl. VAT)'} value={g.cost} onChange={(x) => setGot({ ...got, [l.uid]: { ...g, cost: x, each: undefined } })} /></View>
                {priceDiff ? <Text testID={`rc-was-${l.code}`} style={{ color: C.danger, fontWeight: '700' }}>{`Price changed – was ${$(v.cost)}${v.carton ? ' a carton' : ''}. The product cost updates too.`}</Text> : null}
              </View>
            ) : <Text style={{ color: C.success, fontWeight: '700' }}>All received</Text>}
          </Card>
        );
      })}
      <Section title={o ? 'Also came (not on the order)' : 'Products received'}>
        <ItemPicker shopCode={shop} exclude={extra.map((x) => x.itemUid)} onPick={(r) => setExtra(extra.concat([{ itemUid: r.uid, name: r.name, unit: r.unit, qty: '1', cost: String(r.cost), pack: Number((I.getItem(r.uid) || {}).pack_size) || 1, ctn: '0' }]))} testID="rc-find" />
        {extra.map((x, i) => (
          <Card key={x.itemUid}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{x.name}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
              {(x.pack || 1) > 1 ? <QtyBox value={x.ctn || '0'} onChange={(v) => setExtra(extra.map((y, k) => (k === i ? { ...y, ctn: v } : y)))} testID={`rc-xctn-${i}`} /> : null}
              {(x.pack || 1) > 1 ? <Text style={{ fontSize: 15, color: C.sub }}>cartons of {fq(x.pack)} +</Text> : null}
              <QtyBox value={x.qty} onChange={(v) => setExtra(extra.map((y, k) => (k === i ? { ...y, qty: v } : y)))} testID={`rc-xqty-${i}`} />
              {(x.pack || 1) > 1 ? <Text style={{ fontSize: 15, color: C.sub }}>singles = {fq(xSingles(x))}</Text> : null}
              <View style={{ width: 150 }}><MoneyField label={(x.pack || 1) > 1 ? 'Price a single (excl. VAT)' : 'Price (excl. VAT)'} value={x.cost} onChange={(v) => setExtra(extra.map((y, k) => (k === i ? { ...y, cost: v } : y)))} /></View>
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setExtra(extra.filter((_, k) => k !== i))} />
            </View>
          </Card>
        ))}
      </Section>
      <VatTotals testID="rc-totals" title="GOODS COUNTED" split={split} />
      <Section title="Supplier invoice">
        <Chips value={invMode} onChange={setInvMode} testIDPrefix="rc-inv" options={[{ value: 'now', label: 'Enter it now' }, { value: 'link', label: 'Already entered' }, { value: 'later', label: 'Comes later' }]} />
        <Hint>The invoice total is checked against what was received. It also goes into Invoices & cheques to be paid, so it is only entered once.</Hint>
        {invMode === 'now' ? (
          <>
            <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="rc-invno" label="Invoice number" value={inv.invoiceNo} onChangeText={(v) => setInv({ ...inv, invoiceNo: v })} /></View>
              <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="rc-invtotal" label="Invoice total (incl. VAT)" value={inv.total} onChange={(v) => setInv({ ...inv, total: v })} placeholder={value.toFixed(2)} /></View>
            </View>
            <PhotoPicker testID="rc-invphoto" pdf value={inv.photos} onChange={(p) => { const more = p.length > inv.photos.length; setInv((x) => ({ ...x, photos: p })); if (more) readPhoto(p); }} label="Photo of the invoice" />
            {!inv.photos.length ? <Hint>📷 Take the invoice photo – the number, total and quantities fill in by themselves. Then count the goods and change anything that is different.</Hint> : null}
            {inv.photos.length ? <Btn testID="rc-read" title={reading ? 'Reading…' : 'Read the invoice photo again'} icon="🔎" size="md" variant="ghost" disabled={reading} onPress={() => readPhoto()} /> : null}
            {readRes ? <Banner testID="rc-read-filled" tone="info" title="Filled in from the invoice photo" message={`Invoice ${readRes.invoiceNo || '?'} · total ${readRes.total !== null && readRes.total !== undefined ? $(readRes.total) : '?'} · ${readRes.lines.filter((l) => l.itemUid).length} product line(s). Count the goods – the quantities must be what actually arrived.`} /> : null}
            {readRes && readRes.engineLabel ? <Text testID="rc-read-engine" style={{ fontSize: 14, fontWeight: '800', color: readRes.engine === 'ai' ? C.success : C.warn }}>{readRes.engine === 'ai' ? '🤖 ' : '📱 '}{readRes.engineLabel}{readRes.aiPending ? ' · AI re-read when online (tap "Read the invoice photo again")' : ''}</Text> : null}
            {readRes ? <Btn testID="rc-read-checked" title={readOk ? '☑️ Counted and checked' : '⬜ I counted the goods and checked the invoice figures'} size="md" variant={readOk ? 'success' : 'warn'} onPress={() => setReadOk(!readOk)} /> : null}
            {questions.length ? (
              <Card tone="warn" testID="rc-questions">
                <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>{`Questions for you (${answered.open.length} left)`}</Text>
                {questions.map((q) => (
                  <View key={q.id} style={{ gap: 6, marginTop: 6 }}>
                    <Text style={{ fontSize: 16, color: C.text }}>{q.text}</Text>
                    <Chips value={answers[q.id] || ''} onChange={(v) => answer(q, v)} testIDPrefix={`rc-q-${q.id.replace(/[^\w]/g, '_')}`} options={q.options} />
                    {answers[q.id] === 'recount' ? <Hint>Count it again and change the number above – the question goes when it matches the invoice, or answer it again.</Hint> : null}
                  </View>
                ))}
                {answered.claims.length ? <Hint>{`The supplier owes: ${answered.claims.map((c) => c.text).join('; ')}. It is kept on "Owed by suppliers" until the goods come or a credit note – the invoice can still be paid in full.`}</Hint> : null}
              </Card>
            ) : null}
            {readRes && (readRes.flags.length || readRes.costChanges.length) ? (
              <Banner testID="rc-read-flags" tone="warn" title="From the invoice – please check" message={readRes.flags.concat(readRes.costChanges.map((c) => `${c.name}: cost ${$(c.oldCost)} → ${$(c.newCost)}`)).map((f) => `• ${f}`).join('\n')} />
            ) : null}
          </>
        ) : invMode === 'link' ? (
          <Select label="Invoice" value={linkUid} onChange={setLinkUid} options={[{ value: '', label: openInvoices.length ? 'Choose' : 'No unlinked invoices from this supplier' }].concat(openInvoices.map((i) => ({ value: i.uid, label: `${i.invoice_no || 'no number'} · ${i.invoice_date} · ${$(i.total)}` })))} />
        ) : <Hint>It will show on "Received, not invoiced" until the invoice is linked.</Hint>}
      </Section>
      <DateField label="Delivery date" value={date} onChange={setDate} />
      <Field label="Note (optional)" value={notes} onChangeText={setNotes} />
      <PhotoPicker value={photos} onChange={setPhotos} label={o ? 'Photo of the delivery / damage (optional)' : 'Photo of the invoice or the goods (needed – no purchase order)'} />
      {needWhy ? (
        <Card tone="warn">
          <Text style={{ fontSize: 16, color: C.text }}>{needWhy}</Text>
          <ReasonField testID="rc-why" label="Why is it OK?" value={why} onChangeText={setWhy} multiline />
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- one delivery / return
export function ReceiptScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [inv, setInv] = useState('');
  const r = I.getReceipt(params.uid);
  if (!r) return <Screen title="Delivery"><Text>Not found.</Text></Screen>;
  const cands = !r.invoice_uid ? listInvoices({ filter: 'all', supplierUid: r.supplier_uid, limit: 40 }).filter((i) => i.status !== 'void' && (r.kind === 'return' ? i.kind === 'credit' : i.kind === 'invoice')) : [];
  return (
    <Screen title={r.kind === 'return' ? 'Return to supplier' : 'Delivery received'} subtitle={`${r.supplier_name} · ${shopName(r.shop_code)} · ${r.receive_date}`}>
      {r.status === 'void' ? <Banner tone="danger" message={`Voided: ${r.void_reason}`} /> : null}
      {(() => { let q = 0; try { q = CL.clarifications(r.uid).open; } catch (e) { q = 0; } return q ? <Btn testID="rv-questions" title={`❓ ${q} question${q === 1 ? '' : 's'} about the invoice`} variant="warn" onPress={() => nav.push('InvoiceQuestions', { receiptUid: r.uid })} /> : null; })()}
      <FixButton table="inv_receipts" keyVal={r.uid} />
      {r.kind === 'receive' && r.status === 'active' ? <Btn testID="rv-damaged" title="Found damaged goods from this delivery" icon="⚠️" size="md" variant="secondary" onPress={() => nav.push('ReportDamaged', { receiptUid: r.uid })} /> : null}
      <Card>
        <VatTotals testID="rv-totals" title="GOODS RECEIVED" split={I.vatSplit((r.lines || []).map((l) => ({ amount: (Number(l.qty) || 0) * (Number(l.unitCost) || 0), vatType: l.itemUid ? (I.getItem(l.itemUid) || {}).vat_type : 'standard' })))} />
        <Row label={r.kind === 'return' ? 'Credit note' : 'Invoice'} value={r.invoice_no ? `${r.invoice_no} · ${$(r.invoice_total)}` : 'not yet'} color={r.invoice_uid ? undefined : C.warn} />
        <Row label="By" value={r.by_name} />
        {r.match_note ? <Row label="Checked" value={r.match_note} /> : null}
        {r.notes ? <Row label="Note" value={r.notes} /> : null}
      </Card>
      {r.lines.map((l) => <ListItem key={l.itemUid} title={l.name} sub={`${l.code} · ${$(l.unitCost)} each${l.ordered ? ` · ordered ${fq(l.ordered)}` : ''}`} right={fq(l.qty)} />)}
      {!r.invoice_uid && r.status === 'active' && cands.length ? (
        <Section title={`Link the ${r.kind === 'return' ? 'credit note' : 'invoice'}`}>
          <Select label="Choose" value={inv} onChange={setInv} options={[{ value: '', label: 'Choose' }].concat(cands.map((i) => ({ value: i.uid, label: `${i.invoice_no || 'no number'} · ${i.invoice_date} · ${$(i.total)}` })))} />
          <Btn title="Link" size="md" variant="success" disabled={!inv} onPress={() => act(() => I.linkInvoice(user, r.uid, inv), 'Linked')} />
        </Section>
      ) : null}
      <Btn testID="rcv-pdf" title={r.kind === 'return' ? 'Goods returned note (PDF)' : 'Goods received note (PDF)'} icon="📄" size="md" variant="secondary" onPress={() => shareReport(receiptReport(r.uid), 'pdf').catch(() => {})} />
      {r.status === 'active' && r.kind === 'receive' && (can('po_receive') || can('inventory_manage')) ? <Btn testID="rcv-fix" title="Correct quantities or prices" icon="✏️" size="md" variant="secondary" onPress={() => nav.push('DeliveryFix', { uid: r.uid })} /> : null}
      {r.status === 'active' && can('inventory_manage') ? <ReasonButton testID="rcv-void" title="Void (entered by mistake)" prompt="Why is it voided?" confirm="Void" onDo={(w) => act(() => I.voidReceipt(user, r.uid, w), 'Voided – stock taken back off')} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- return to supplier
export function SupplierReturnScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const [shop, setShop] = useShop(params.shopCode);
  const [sup, setSup] = useState('');
  const [lines, setLines] = useState([]);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState([]);
  const value = lines.reduce((s, l) => s + I.incVat((Number(l.qty) || 0) * l.cost, l.vat), 0);
  return (
    <Screen title="Return goods to a supplier" subtitle={shopName(shop)}
      footer={<Btn testID="ret-save" title={`Send back · ${$(value)}`} icon="↩️" variant="warn" onPress={() => {
        const uid = act(() => I.returnToSupplier(user, { supplierUid: sup, shopCode: shop, lines: lines.map((l) => ({ itemUid: l.uid, qty: l.qty })), reason, notes, photos }), 'Recorded – waiting for the credit note');
        if (uid) nav.replace('Receipt', { uid });
      }} />}>
      <Hint>The stock comes off now. The return stays on the "waiting for credit" list until the supplier's credit note is entered and linked – so no credit is forgotten.</Hint>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="ret-shop" />
      <Select testID="ret-sup" label="Supplier" value={sup} onChange={setSup} options={[{ value: '', label: 'Choose the supplier' }].concat(supOptions())} />
      <ItemPicker shopCode={shop} exclude={lines.map((l) => l.uid)} onPick={(r) => setLines(lines.concat([{ uid: r.uid, name: r.name, unit: r.unit, cost: r.cost, vat: r.vat_type, qty: '1' }]))} testID="ret-find" />
      {lines.map((l, i) => (
        <Card key={l.uid}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.name}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <QtyBox value={l.qty} onChange={(v) => setLines(lines.map((x, k) => (k === i ? { ...x, qty: v } : x)))} testID={`ret-qty-${i}`} />
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines(lines.filter((_, k) => k !== i))} />
          </View>
        </Card>
      ))}
      <ReasonField testID="ret-reason" label="Why are they going back?" value={reason} onChangeText={setReason} placeholder="e.g. damaged, expired, wrong product" />
      <Field label="Note (optional)" value={notes} onChangeText={setNotes} />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo (optional)" />
    </Screen>
  );
}

// 1.0.0 To verify: the questions about a delivery's invoice (supplier, number, date, total, lines not matched, a
// supplier's first invoice). Each answer is kept and teaches the app the supplier's format.
export function InvoiceQuestionsScreen({ params = {} }) {
  const { user, refresh } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const [typed, setTyped] = useState({});
  const r = I.getReceipt(params.receiptUid);
  let c = { questions: [], open: 0 };
  try { c = CL.clarifications(params.receiptUid); } catch (e) { c = { questions: [], open: 0 }; }
  if (!r) return <Screen title="Invoice questions"><Text>Not found.</Text></Screen>;
  const send = (q, v) => {
    try {
      const res = CL.answerClarification(user, params.receiptUid, q.id, v);
      ui.toast(res.learned && res.learned.length ? `Saved – learnt: ${res.learned[0]}` : 'Saved');
      bump((x) => x + 1); if (refresh) refresh();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Invoice questions" subtitle={`${r.supplier_name} · ${r.receive_date} · ${c.open} to answer`}>
      <Hint>Look at the invoice paper (or its photo on the delivery). Each answer is remembered, so the next invoice from this supplier is read right.</Hint>
      {!c.questions.length ? <Banner tone="success" message="No questions – the invoice was read cleanly." /> : null}
      {c.questions.map((q) => (
        <Card key={q.id} tone={q.answer ? 'success' : 'warn'} testID={`iq-${q.id.replace(/[^\w]/g, '_')}`}>
          <Text style={{ fontSize: 16, color: C.text }}>{q.text}</Text>
          {q.answer ? <Text style={{ color: C.success, fontWeight: '800' }}>{`✓ ${q.input === 'product' ? ((I.getItem(q.answer.value) || {}).name || q.answer.value) : (q.options || []).find((o) => o.value === q.answer.value)?.label || q.answer.value} – ${q.answer.by}`}</Text>
            : q.options ? <Chips value="" onChange={(v) => send(q, v)} testIDPrefix={`iq-o-${q.id.replace(/[^\w]/g, '_')}`} options={q.options} />
              : q.input === 'product' ? <ItemPicker shopCode={r.shop_code} supplierUid={r.supplier_uid} testID={`iq-p-${q.id.replace(/[^\w]/g, '_')}`} onPick={(it) => send(q, it.uid)} />
                : (
                  <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
                    <View style={{ flexBasis: 180, flexGrow: 1 }}><Field testID={`iq-t-${q.id.replace(/[^\w]/g, '_')}`} label={q.input === 'money' ? 'Total on the paper' : q.input === 'date' ? 'Date (YYYY-MM-DD)' : 'Invoice number'} value={typed[q.id] !== undefined ? typed[q.id] : (q.value !== undefined ? String(q.value) : '')} onChangeText={(v) => setTyped({ ...typed, [q.id]: v })} keyboardType={q.input === 'money' ? 'decimal-pad' : undefined} /></View>
                    <Btn testID={`iq-s-${q.id.replace(/[^\w]/g, '_')}`} title="Save" size="sm" variant="success" onPress={() => send(q, typed[q.id] !== undefined ? typed[q.id] : (q.value !== undefined ? String(q.value) : ''))} />
                  </View>
                )}
        </Card>
      ))}
    </Screen>
  );
}
