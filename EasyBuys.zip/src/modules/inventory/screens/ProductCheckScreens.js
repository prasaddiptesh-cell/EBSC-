// 1.0.0 Product checks from the invoices: VAT (invoice vs app vs Aronium), selling at / below the invoice cost,
// suppliers (invoices vs the main supplier), and barcodes found at the stock take to add in Aronium.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, Chips, Section, useApp, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint } from '../../../ui/kit.js';
import * as PC from '../productChecks.js';
import * as I from '../service.js';
import { shopName } from './common.js';

const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
export function ProductChecksScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [tab, setTab] = useRemembered('pc-tab', params.tab || 'vat');
  const [, bump] = useState(0);
  const vat = tab === 'vat' ? PC.invoiceVatMismatches() : [];
  const price = tab === 'price' ? PC.priceVsCost() : { same: [], below: [] };
  const sup = tab === 'supplier' ? PC.supplierCrossCheck() : { differs: [], none: [] };
  const bc = tab === 'barcodes' ? PC.barcodeFixes() : [];
  const nob = tab === 'barcodes' ? PC.noBarcode() : [];
  const boss = ['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  return (
    <Screen title="Product checks" subtitle="From the invoices – checks the products in Aronium too">
      <Chips value={tab} onChange={setTab} testIDPrefix="pc-tab" options={[{ value: 'vat', label: 'VAT' }, { value: 'price', label: 'Price vs cost' }, { value: 'supplier', label: 'Suppliers' }, { value: 'barcodes', label: 'Barcodes' }]} />
      {tab === 'vat' ? (
        <>
          <Hint>Each invoice line that says how it is taxed (zero rated, exempt / VAT free, 12.5%) is kept. Here: products where the invoice says something different from the app or from Aronium. Fix Aronium's tax in Aronium; the app's on the product (or "Aronium is right" on VAT: Aronium vs the app).</Hint>
          {!vat.length ? <Banner tone="success" message="No differences found on the invoices read so far." /> : null}
          {vat.map((x) => (
            <ListItem key={x.uid} testID={`pc-vat-${x.code}`} tone="warn" title={x.name} sub={x.text} right={x.invoice.vat === 'nonvat' ? 'No VAT' : PC.VAT_WORD[x.invoice.vat]} rightSub={x.aroniumOff ? 'fix in Aronium' : 'fix in the app'}
              onPress={() => nav.push('InvProduct', { uid: x.uid })} />
          ))}
        </>
      ) : null}
      {tab === 'price' ? (
        <>
          <Hint>Aronium's selling price at each shop against the latest invoice cost (with VAT for VAT products). Change the selling price in Aronium.</Hint>
          {!price.below.length && !price.same.length ? <Banner tone="success" message="Every product sells above its invoice cost." /> : null}
          {price.below.length ? <Section title={`Selling below cost (${price.below.length})`}>{price.below.map((x) => <ListItem key={`${x.shop}${x.code}`} testID={`pc-below-${x.code}`} tone="danger" title={x.name} sub={`${shopName(x.shop)} · ${x.code}`} right={$(x.price)} rightSub={`cost ${$(x.cost)}`} />)}</Section> : null}
          {price.same.length ? <Section title={`Selling at cost – no profit (${price.same.length})`}>{price.same.map((x) => <ListItem key={`${x.shop}${x.code}`} testID={`pc-same-${x.code}`} tone="warn" title={x.name} sub={`${shopName(x.shop)} · ${x.code}`} right={$(x.price)} rightSub="= cost" />)}</Section> : null}
        </>
      ) : null}
      {tab === 'supplier' ? (
        <>
          <Hint>Who each product really comes from (the invoices of the last 6 months) against its main supplier – used for orders.</Hint>
          {sup.differs.map((x) => (
            <View key={x.uid} style={{ gap: 4 }}>
              <ListItem testID={`pc-sup-${x.code}`} tone="warn" title={x.name} sub={x.text} />
              {boss ? <Btn testID={`pc-sup-use-${x.code}`} title={`Make ${x.invoices[0]} the main supplier`} size="sm" variant="secondary" onPress={() => { if (act(() => PC.useInvoiceSupplier(user, x.uid), 'Main supplier changed') !== null) bump((n) => n + 1); }} /> : null}
            </View>
          ))}
          {sup.none.length ? <Section title={`No supplier yet (${sup.none.length})`}><Hint>They get one by themselves when a delivery or invoice from a supplier comes in.</Hint>{sup.none.slice(0, 100).map((x) => <ListItem key={x.uid} title={x.name} sub={x.code} onPress={() => nav.push('InvProduct', { uid: x.uid })} />)}</Section> : null}
          {!sup.differs.length && !sup.none.length ? <Banner tone="success" message="Every product has a supplier that matches its invoices." /> : null}
        </>
      ) : null}
      {tab === 'barcodes' ? (
        <>
          <Hint>Barcodes scanned at the stock take that were not on the product: the app knows them now. Add them in Aronium too (Management › Products › the product › Barcodes), then tick.</Hint>
          {!bc.length ? <Banner tone="success" message="Nothing to add." /> : null}
          {bc.map((x) => <ListItem key={x.code} testID={`pc-bc-${x.code}`} tone={x.done ? 'success' : 'warn'} title={`${x.code} → ${x.name}`} sub={`${x.itemCode || ''} · by ${x.by}${x.done ? ' · added in Aronium ✓' : ''}`}
            onPress={x.done ? undefined : () => { PC.barcodeFixDone(user, x.code); bump((n) => n + 1); }} rightSub={x.done ? '' : 'tap when added'} right={x.done ? '✓' : ''} />)}
          <Section title={`Products with no barcode (${nob.length})`}>
            <Hint>Find them by name when counting or receiving. Or make a shop barcode (starts with 21): it goes into the Aronium update file, and Aronium can then print its label for the shelf or the product.</Hint>
            {nob.slice(0, 200).map((x) => (
              <ListItem key={x.uid} testID={`pc-nob-${x.code}`} title={x.name} sub={`${x.code}${x.group_name ? ` · ${x.group_name}` : ''}`} right="" rightSub={boss ? 'tap: make a barcode' : ''}
                onPress={boss ? () => { if (act(() => PC.makeShopBarcode(user, x.uid), 'Shop barcode made') !== null) bump((n) => n + 1); } : undefined} />
            ))}
          </Section>
        </>
      ) : null}
    </Screen>
  );
}
