// Products: the whole product list (search, groups, "added in the app – not in Aronium yet", hidden) and adding a
// product by hand. Aronium stays the master: a product added here is linked by itself the next time it comes in from
// Aronium, and from then on Aronium's name, price, barcode and tax win. The app never writes to Aronium.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Section, Select, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { MoneyField, ListItem, Hint } from '../../../ui/kit.js';
import { listSuppliers } from '../../payables/service.js';
import { CodeScanner } from '../../../platform/scanner.js';
import * as I from '../service.js';
import { shops } from './common.js';

const { $ } = I;
const FILTERS = [{ value: 'all', label: 'All products' }, { value: 'app', label: 'Not in Aronium yet' }, { value: 'hidden', label: 'Hidden' }];

export function ProductsScreen() {
  const { nav, can } = useApp();
  const [q, setQ] = useRemembered('q', '');
  const [filter, setFilter] = useRemembered('filter', 'all');
  const [group, setGroup] = useRemembered('group', '');
  const groups = I.listGroups();
  const rows = I.listProducts({ q, filter, group: group || undefined });
  const waiting = I.notInAroniumCount();
  return (
    <Screen title="Products" subtitle={`${rows.length} shown`}>
      {can('inventory_manage') ? <Btn testID="prod-add" title="Add a product" icon="➕" variant="success" onPress={() => nav.push('ProductNew', {})} /> : null}
      {waiting ? <Banner tone="warn" testID="prod-waiting" title={`${waiting} product(s) added in the app are not in Aronium yet`} message="Add them in Aronium too, so they can be sold at the till. They link up by themselves on the next Aronium import." /> : null}
      <Field testID="prod-q" label="Search" value={q} onChangeText={setQ} placeholder="Name, code or barcode" />
      <Chips value={filter} onChange={setFilter} options={FILTERS} testIDPrefix="prod-f" />
      {groups.length ? <Select label="Group" value={group} onChange={setGroup} options={[{ value: '', label: 'All groups' }].concat(groups.map((g) => ({ value: g, label: g })))} /> : null}
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>No products here.</Text> : null}
      {rows.map((r) => (
        <ListItem key={r.uid} testID={`prod-${r.code}`} onPress={() => nav.push('InvProduct', { uid: r.uid })}
          title={r.name} sub={`${r.code}${r.barcode ? ` · ${r.barcode}` : ''}${r.group_name ? ` · ${r.group_name}` : ''}`}
          right={$(r.price)} rightSub={`cost ${$(r.cost)}`}
          badge={r.aronium_seen === null && !r.removed_at ? 'NOT IN ARONIUM' : r.removed_at ? 'DELETED IN ARONIUM' : !r.active ? 'HIDDEN' : null}
          badgeColor={r.aronium_seen === null ? C.warn : C.sub} />
      ))}
    </Screen>
  );
}

export function ProductNewScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [scan, setScan] = useState(false);
  const [f, setF] = useState({ name: '', code: '', barcode: params.barcode || '', groupName: '', unit: 'each', packSize: '1', cost: '', price: '', wholesale: '', vatType: 'standard', supplierUid: '', notes: '' });
  const [shopOn, setShopOn] = useState(() => Object.fromEntries(shops().map((s) => [s.code, true])));
  const [shopPrice, setShopPrice] = useState({});
  const [reorder, setReorder] = useState({});
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const groups = I.listGroups();
  const units = Array.from(new Set(I.invRules().units.concat([f.unit])));
  const dupe = f.barcode ? I.barcodeOwner(f.barcode) : null;
  const warnings = f.name ? I.productWarnings(f) : [];
  const save = async () => {
    try {
      if (warnings.length) {
        const ok = await ui.confirm({ title: 'Save anyway?', message: warnings.join('\n'), confirm: 'Save' });
        if (!ok) return;
      }
      const it = I.saveItem(user, { ...f });
      if (f.wholesale !== '') I.setWholesalePrice(user, it.uid, f.wholesale);
      for (const s of shops()) {
        I.saveItemShop(user, { itemUid: it.uid, shopCode: s.code, active: !!shopOn[s.code], reorderLevel: reorder[s.code] || 0, reorderQty: 0, price: shopPrice[s.code] === undefined || shopPrice[s.code] === '' ? null : shopPrice[s.code], location: null });
      }
      ui.toast('Product added – remember to add it in Aronium too');
      nav.replace('InvProduct', { uid: it.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Add a product" subtitle="Added in the app – add it in Aronium too">
      <Hint>Aronium stays the master list. When this product next comes in from Aronium it is linked by itself (by barcode, code or name), and from then on Aronium's name, price, barcode and VAT are used.</Hint>
      <Field testID="pn-name" label="Name *" value={f.name} onChangeText={set('name')} placeholder="e.g. Punjas Flour 10kg" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        <View style={{ flexBasis: 200, flexGrow: 2 }}><Field testID="pn-barcode" label="Barcode(s)" value={f.barcode} onChangeText={set('barcode')} placeholder="Scan or type; several with commas" /></View>
        <View style={{ flexBasis: 140, flexGrow: 1, justifyContent: 'flex-end' }}><Btn testID="pn-scan" title={scan ? 'Close camera' : 'Scan'} icon="📷" size="md" variant="info" onPress={() => setScan(!scan)} /></View>
      </View>
      {scan ? <CodeScanner onScan={(code) => { setScan(false); setF((x) => ({ ...x, barcode: x.barcode ? `${x.barcode},${code}` : code })); }} /> : null}
      {dupe ? <Text testID="pn-dupe" style={{ color: C.danger, fontWeight: '700' }}>Barcode {dupe.barcode} is already on "{dupe.name}".</Text> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="pn-code" label="Product code" value={f.code} onChangeText={set('code')} placeholder="Made for you if empty" /></View>
        <View style={{ flexBasis: 200, flexGrow: 1 }}>
          <Select label="Group" value={f.groupName} onChange={set('groupName')} options={[{ value: '', label: '—' }].concat(groups.map((g) => ({ value: g, label: g })))} />
        </View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="pn-group-new" label="…or a new group" value={groups.includes(f.groupName) ? '' : f.groupName} onChangeText={set('groupName')} /></View>
        <View style={{ flexBasis: 120, flexGrow: 1 }}><Select label="Unit" value={f.unit} onChange={set('unit')} options={units.map((u) => ({ value: u, label: u }))} /></View>
        <View style={{ flexBasis: 120, flexGrow: 1 }}><Field label="Pack size" value={f.packSize} onChangeText={set('packSize')} keyboardType="decimal-pad" /></View>
        <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField testID="pn-cost" label="Cost (excl. VAT)" value={f.cost} onChange={set('cost')} /></View>
        <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField testID="pn-price" label="Selling price" value={f.price} onChange={set('price')} /></View>
        <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField label="Wholesale price" value={f.wholesale} onChange={set('wholesale')} /></View>
      </View>
      <Chips value={f.vatType} onChange={set('vatType')} options={[{ value: 'standard', label: 'VAT 12.5%' }, { value: 'zero', label: 'Zero rated' }, { value: 'exempt', label: 'VAT free (exempt)' }]} testIDPrefix="pn-vat" />
      <Select label="Main supplier" value={f.supplierUid} onChange={set('supplierUid')} options={[{ value: '', label: '—' }].concat(listSuppliers().map((x) => ({ value: x.uid, label: x.name })))} />
      <Section title="Shops">
        {shops().map((s) => (
          <Card key={s.code}>
            <Chips value={shopOn[s.code] ? 'y' : 'n'} onChange={(v) => setShopOn((x) => ({ ...x, [s.code]: v === 'y' }))} options={[{ value: 'y', label: `Sold at ${s.name}` }, { value: 'n', label: 'Not sold there' }]} testIDPrefix={`pn-shop-${s.code}`} />
            {shopOn[s.code] ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField label="Price here (if different)" value={shopPrice[s.code] || ''} onChange={(v) => setShopPrice((x) => ({ ...x, [s.code]: v }))} placeholder={f.price || ''} /></View>
                <View style={{ flexBasis: 140, flexGrow: 1 }}><Field label="Reorder level" value={reorder[s.code] || ''} onChangeText={(v) => setReorder((x) => ({ ...x, [s.code]: v }))} keyboardType="decimal-pad" /></View>
              </View>
            ) : null}
          </Card>
        ))}
      </Section>
      {warnings.length ? <Card tone="warn">{warnings.map((w) => <Text key={w} style={{ color: C.warn }}>{w}</Text>)}</Card> : null}
      <Btn testID="pn-save" title="Save product" variant="success" disabled={!f.name || !!dupe} onPress={save} />
    </Screen>
  );
}
