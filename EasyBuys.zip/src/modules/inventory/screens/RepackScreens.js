// 1.0.0 Repacking: bulk bought, packed in the shop, sold in packs. Pick the pair, say how much was used and how many
// packs were made – the stock and the packs' cost follow.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint, MoneyField } from '../../../ui/kit.js';
import * as RP from '../repack.js';
import * as I from '../service.js';
import { ItemPicker, shopChips, useShop, shopName } from './common.js';

export function RepackScreen() {
  const { user } = useApp();
  const ui = useUI();
  const act = useAct();
  const [shop, setShop] = useShop();
  const [from, setFrom] = useState(null);
  const [to, setTo] = useState(null);
  const [used, setUsed] = useState('1');
  const [made, setMade] = useState('');
  const [per, setPer] = useState('');
  const [packCost, setPackCost] = useState('');
  const [, bump] = useState(0);
  const pair = from && to ? RP.pairOf(from.uid, to.uid) : null;
  const expect = pair && pair.per ? Math.round(Number(used || 0) * pair.per * 1000) / 1000 : null;
  const boss = ['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const go = () => {
    const r = act(() => RP.repack(user, { shopCode: shop, fromUid: from.uid, toUid: to.uid, used, made }), null);
    if (r) { ui.toast(r.short ? `Saved – ${r.short} fewer than usual, the managers will see it` : `Saved – ${made} × ${to.name} in stock`); setMade(''); bump((n) => n + 1); }
  };
  return (
    <Screen title="Pack for sale" subtitle={shopName(shop)}
      footer={<Btn testID="rp-save" title="Packed – update the stock" icon="📦" variant="success" disabled={!from || !to || !made} onPress={go} />}>
      <Hint>For things bought in bulk and packed in the shop (a 25 kg bag of rice into 1 kg packets). The bulk goes down by what was used, the packs go up, and the packs' cost price comes from the bulk's (+ bags / labels). Both are counted at the stock take.</Hint>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="rp-shop" />
      {RP.listPairs().length && !from ? (
        <Section title="Usual pack-ups">
          {RP.listPairs().map((x) => <ListItem key={`${x.from.uid}${x.to.uid}`} testID={`rp-pair-${x.to.code}`} title={`${x.from.name} → ${x.to.name}`} sub={`1 makes ${x.per || '?'}${x.packCost ? ` · bags/labels $${Number(x.packCost).toFixed(2)} each` : ''} · in stock: ${I.stockOf(x.from.uid, shop)}`} onPress={() => { setFrom(x.from); setTo(x.to); }} />)}
        </Section>
      ) : null}
      <Card>
        {from ? <ListItem title={`Bulk: ${from.name}`} sub={`${I.stockOf(from.uid, shop)} ${from.unit || ''} in stock · cost $${Number(from.cost || 0).toFixed(2)}`} rightSub="change" right="" onPress={() => setFrom(null)} /> : <ItemPicker shopCode={shop} testID="rp-from" label="1. The BULK product used (e.g. Rice 25kg bag)" onPick={setFrom} />}
        {to ? <ListItem title={`Packs: ${to.name}`} sub={`${I.stockOf(to.uid, shop)} in stock`} rightSub="change" right="" onPress={() => setTo(null)} /> : <ItemPicker shopCode={shop} testID="rp-to" label="2. The PACKED product made (e.g. Rice 1kg packet)" onPick={setTo} />}
        {from && to ? (
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field testID="rp-used" label={`How much ${from.name} used`} value={used} onChangeText={setUsed} keyboardType="numeric" /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field testID="rp-made" label="How many packs made" value={made} onChangeText={setMade} keyboardType="numeric" /></View>
          </View>
        ) : null}
        {expect !== null ? <Text style={{ color: C.sub }}>{`Usually makes ${expect}.`}</Text> : null}
      </Card>
      {from && to && boss ? (
        <Card>
          <Text style={{ fontWeight: '800', color: C.text }}>Set up this pack-up (once)</Text>
          <Field testID="rp-per" label={`Packs from one ${from.name}`} value={per} onChangeText={setPer} keyboardType="numeric" placeholder={pair && pair.per ? String(pair.per) : 'e.g. 25'} />
          <MoneyField testID="rp-pcost" label="Bag / label cost per pack (optional)" value={packCost} onChange={setPackCost} />
          <Btn testID="rp-pair-save" title="Save" size="sm" variant="secondary" onPress={() => { if (act(() => RP.savePair(user, { fromUid: from.uid, toUid: to.uid, per: per || (pair && pair.per), packCost }), 'Saved') !== null) bump((n) => n + 1); }} />
        </Card>
      ) : null}
      {!RP.listPairs().length && !from ? <Banner tone="info" message="Pick the bulk product and the packed product to start." /> : null}
    </Screen>
  );
}
