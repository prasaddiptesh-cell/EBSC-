// Stock take: start (whole shop, groups, shelves or a rolling count), count (stock frozen), hand in, approve and post, results.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shareReport, printReport } from '../../../platform/files.js';
import { db } from '../../../db/connection.js';
import * as I from '../service.js';
import { countReport } from '../reports.js';
import { shopName, shopChips, useShop, QtyBox, fq } from './common.js';
import { ScanBar } from './scanUi.js';
import { findByBarcode, NOT_FOUND } from '../scan.js';

const { $ } = I;
const ST_COLOR = { counting: C.info, review: C.warn, posted: C.success, cancelled: C.sub };
const locationsAt = (shop) => db().all("SELECT DISTINCT location AS l FROM inv_item_shops WHERE shop_code = ? AND location IS NOT NULL AND location <> '' ORDER BY location", [shop]).map((r) => r.l);

export function StockTakesScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = I.invRules();
  const [shop, setShop] = useShop(params.shopCode);
  const [mode, setMode] = useState(params.highValue ? 'new' : 'list');
  const [scopeKind, setScopeKind] = useState(params.highValue ? 'high' : 'all');
  const [groups, setGroups] = useState([]);
  const [locs, setLocs] = useState([]);
  const [date, setDate] = useState(dateStr());
  const [timing, setTiming] = useState('after_close');
  const [blind, setBlind] = useState(rules.blindCount);
  const list = I.listCounts({ shopCode: shop, limit: 50 });
  const toggle = (arr, set, v) => set(arr.includes(v) ? arr.filter((x) => x !== v) : arr.concat([v]));
  const cycle = scopeKind === 'cycle' ? I.cycleSuggestions(shop) : scopeKind === 'high' ? I.highValueDue(shop) : [];
  const start = () => {
    try {
      const scope = scopeKind === 'groups' ? { groups } : scopeKind === 'locations' ? { locations: locs } : ['cycle', 'high'].includes(scopeKind) ? { itemUids: cycle.map((r) => r.uid) } : {};
      if (['cycle', 'high'].includes(scopeKind) && !cycle.length) throw new Error('Every product has been counted recently.');
      const c = I.startCount(user, { shopCode: shop, scope, date, timing, blind, name: scopeKind === 'cycle' ? `${shop} rolling count ${date}` : scopeKind === 'high' ? `${shop} high-value count ${date}` : undefined });
      ui.toast(`Started – ${c.lines.length} products to count`);
      nav.push('StockCount', { uid: c.uid });
      setMode('list');
    } catch (e) { ui.error(e); }
  };
  if (mode === 'new') {
    return (
      <Screen title="Start a stock take" subtitle={shopName(shop)} onBack={() => setMode('list')}
        footer={<Btn testID="sc-start" title="Start – freeze the stock" icon="❄️" variant="success" onPress={start} />}>
        <Explain title="How a stock take works">
          1. Start it: the products being counted are frozen – no write-offs, transfers or deliveries can be entered for them until it is finished (sales from Aronium still come in and are allowed for).{'\n'}
          2. Count: walk the shelves and enter what you see. Several people can count at once on different devices.{'\n'}
          3. Hand in: anything far off is sent back to be counted again.{'\n'}
          4. A manager checks the results (short and over, in dollars) and approves. Only then does the stock change.
        </Explain>
        <Label>What to count</Label>
        <Chips value={scopeKind} onChange={setScopeKind} testIDPrefix="sc-scope" options={[{ value: 'all', label: 'Whole shop' }, { value: 'groups', label: 'Some groups' }, { value: 'locations', label: 'Some shelves' }, { value: 'cycle', label: 'Rolling count' }, { value: 'high', label: 'High-value (weekly)' }]} />
        {scopeKind === 'groups' ? <Chips value={null} onChange={(v) => toggle(groups, setGroups, v)} options={I.listGroups().map((g) => ({ value: g, label: `${groups.includes(g) ? '☑' : '☐'} ${g}` }))} testIDPrefix="sc-g" /> : null}
        {scopeKind === 'locations' ? (locationsAt(shop).length ? <Chips value={null} onChange={(v) => toggle(locs, setLocs, v)} options={locationsAt(shop).map((g) => ({ value: g, label: `${locs.includes(g) ? '☑' : '☐'} ${g}` }))} /> : <Hint>No shelf locations set yet. Set them on each product (Stock on hand › product › Shelf / location).</Hint>) : null}
        {scopeKind === 'high' ? <Hint>{`${cycle.length} high-value products (counted twice, by two people) not counted in the last ${rules.cycleHighValueDays} days.`}</Hint> : null}
        {scopeKind === 'cycle' ? <Hint>{`${cycle.length} products not counted in the last ${rules.cycleDays} days, most valuable first. Counting a few every week keeps stock right without closing the shop.`}</Hint> : null}
        <DateField label="Count date" value={date} onChange={setDate} />
        <Label>When is the count done?</Label>
        <Chips value={timing} onChange={setTiming} testIDPrefix="sc-time" options={[{ value: 'after_close', label: 'After closing' }, { value: 'before_open', label: 'Before opening' }]} />
        <Hint>So the app knows whether that day's sales happened before or after the count.</Hint>
        <Chips value={blind ? 'y' : 'n'} onChange={(v) => setBlind(v === 'y')} testIDPrefix="sc-blind" options={[{ value: 'y', label: 'Blind count' }, { value: 'n', label: 'Show expected numbers' }]} />
        <Hint>Blind count: counters do not see how many the system expects, so they count what is really there.</Hint>
      </Screen>
    );
  }
  return (
    <Screen title="Stock takes" subtitle={shopName(shop)}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="sc-shop" />
      {can('stocktake_count') ? <Btn testID="sc-new" title="Start a stock take" icon="📋" variant="success" onPress={() => setMode('new')} /> : null}
      {!list.length ? <Text style={{ color: C.sub }}>No stock takes yet.</Text> : null}
      {list.map((c) => (
        <ListItem key={c.uid} testID={`sc-${c.uid}`} onPress={() => nav.push('StockCount', { uid: c.uid })} title={c.name}
          sub={`${c.count_date} · started by ${c.started_by_name}${c.posted_by_name ? ` · approved by ${c.posted_by_name}` : ''}`}
          right={c.result ? $(c.result.net) : ''} rightSub={c.result && c.result.accuracy !== null ? `${c.result.accuracy}% right` : ''} badge={I.COUNT_STATUS[c.status]} badgeColor={ST_COLOR[c.status]} />
      ))}
    </Screen>
  );
}

export function StockCountScreen({ params }) {
  const { nav, user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const [q, setQ] = useRemembered('q', '');
  const [show, setShow] = useRemembered('show', 'todo');
  const [entry, setEntry] = useState({});
  const [pick, setPick] = useState([]);
  const [packs, setPacks] = useState({});
  const [quick, setQuick] = useState(false);
  const [area, setArea] = useState(null);
  const [expiry, setExpiry] = useState({});
  const c = I.getCount(params.uid);
  if (!c) return <Screen title="Stock take"><Text>Not found.</Text></Screen>;
  const s = c.summary;
  const counting = c.status === 'counting';
  const showExpected = !c.blind || c.status !== 'counting';
  const filtered = c.lines.filter((l) => (!area || l.area === area) && (!q.trim() || `${l.name} ${l.code} ${l.barcode || ''}`.toLowerCase().includes(q.trim().toLowerCase()))
    && (show === 'all' || (show === 'todo' ? l.counted === null : show === 'done' ? l.counted !== null : Math.abs(l.variance) > 1e-9)));
  const exact = q.trim().length >= 3 ? c.lines.find((l) => l.barcode === q.trim() || l.code.toUpperCase() === q.trim().toUpperCase()) : null;
  const enter = (l, add) => {
    const v = entry[l.item_uid];
    const pk = packs[l.item_uid];
    if ((v === undefined || v === '') && (pk === undefined || pk === '')) return;
    if (act(() => I.enterCount(user, c.uid, l.item_uid, v === undefined || v === '' ? 0 : v, { add, packs: pk }), add ? `Added – ${l.name}` : `Counted – ${l.name}`) !== null) { setEntry({ ...entry, [l.item_uid]: '' }); setPacks({ ...packs, [l.item_uid]: '' }); if (exact) setQ(''); }
  };
  const handIn = async () => {
    let restZero;
    if (s.notCounted) {
      const z = await ui.confirm({ title: `${s.notCounted} not counted`, message: 'Is this a full count? Then the products not counted are set to 0. Otherwise they stay as they are.', confirmText: 'Set them to 0', cancelText: 'Leave them', tone: 'warn' });
      restZero = !!z;
    }
    try {
      const r = I.submitCount(user, c.uid, { restZero });
      if (refresh) refresh();
      if (r.recount.length) { ui.alert({ title: 'Count these again', message: `These are well off what was expected. Please count them once more:\n\n${r.recount.map((x) => `• ${x.name}`).join('\n')}`, tone: 'warn' }); setShow('todo'); }
      else ui.toast('Handed in – waiting for approval');
    } catch (e) { ui.error(e); }
  };
  const sheet = () => printReport(countReport(c.uid, { sheet: true })).catch((e) => ui.error(e));
  return (
    <Screen title={c.name} subtitle={`${I.COUNT_STATUS[c.status]} · ${c.count_date} · ${c.timing === 'before_open' ? 'before opening' : 'after closing'}`}
      footer={counting && can('stocktake_count') ? <Btn testID="scc-handin" title={`Hand in (${s.counted} of ${s.products} counted)`} icon="📤" variant="success" onPress={handIn} /> : null}>
      <Stats items={[
        { label: 'Counted', value: `${s.counted} / ${s.products}`, color: s.notCounted ? undefined : C.success },
        showExpected ? { label: 'Short (loss)', value: $(s.loss), color: s.loss < 0 ? C.danger : undefined } : null,
        showExpected ? { label: 'Over', value: $(s.gain) } : null,
        showExpected && s.accuracy !== null ? { label: 'Accuracy', value: `${s.accuracy}%`, sub: 'products exactly right' } : null,
      ]} />
      {counting ? <Banner tone="info" message="Stock for these products is frozen until this stock take is approved or cancelled." /> : null}
      {counting ? <Hint>{c.blind ? 'Blind count: just count what is on the shelf. ' : ''}Type or scan the product, enter the number, tap "Set". Found more somewhere else? Enter it and tap "+ Add" to add to what was already counted. Products marked "count again" were well off.</Hint> : null}
      {c.status === 'review' ? <Hint>Check the differences below. If something looks wrong, tick it and ask for a recount. When happy, approve: the stock of every counted product becomes what was counted, and the losses / gains are recorded.</Hint> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn title="Print count sheet" icon="🖨️" size="sm" variant="secondary" onPress={sheet} />
        {!counting ? <Btn testID="scc-report" title="Results PDF" icon="📄" size="sm" variant="secondary" onPress={() => Promise.resolve().then(() => shareReport(countReport(c.uid), 'pdf')).catch((e) => ui.error(e))} /> : null}
      </View>
      {counting && can('stocktake_count') ? (
        <ScanBar testID="scc-scan" quick={quick} hint={quick ? 'Each beep adds 1 to that product.' : 'Scan each product and type how many you see. Scanning a product already counted adds to it (counted in two places).'}
          lookup={(code) => {
            const it = findByBarcode(code);
            if (!it) return { ok: false, notFound: true, message: NOT_FOUND };
            const l = c.lines.find((x) => x.item_uid === it.uid);
            if (!l) return { ok: false, message: `${it.name} is not part of this stock take.` };
            return { ok: true, item: it, note: l.counted !== null ? `already counted ${fq(l.counted)} – this adds to it` : null };
          }}
          onItem={(it, n) => { const l = c.lines.find((x) => x.item_uid === it.uid); act(() => I.enterCount(user, c.uid, it.uid, n, { add: quick || (l && l.counted !== null) }), null); if (refresh) refresh(); }} />
      ) : null}
      {c.areas && c.areas.length > 1 ? (
        <Section title="Areas">
          {c.areas.map((a) => (
            <View key={a.area} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 3 }}>
              <Pressable testID={`scc-area-${a.area}`} onPress={() => setArea(area === a.area ? null : a.area)} style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, color: area === a.area ? C.primary : C.text, fontWeight: area === a.area ? '800' : '600' }}>{a.done ? '✅' : a.counted ? '🟠' : '⬜'} {a.area} · {a.counted}/{a.total}{a.counter ? ` · ${a.counter}` : ''}</Text>
              </Pressable>
              {counting && can('stocktake_count') && !a.done ? (a.counter === user.name
                ? <Btn testID={`scc-area-done-${a.area}`} title="Done" size="sm" variant="success" onPress={() => act(() => I.finishArea(user, c.uid, a.area), `${a.area} done`)} />
                : <Btn testID={`scc-area-take-${a.area}`} title="I'll count it" size="sm" variant="secondary" onPress={() => { if (act(() => I.claimArea(user, c.uid, a.area), `You are counting ${a.area}`) !== null) setArea(a.area); }} />) : null}
            </View>
          ))}
        </Section>
      ) : null}
      {counting && can('stocktake_count') ? <Chips value={quick ? 'q' : 'n'} onChange={(v) => setQuick(v === 'q')} testIDPrefix="scc-mode" options={[{ value: 'n', label: 'Scan, then type how many' }, { value: 'q', label: 'Each scan counts 1' }]} /> : null}
      <Field testID="scc-q" label="Find (name, code or scan barcode)" value={q} onChangeText={setQ} />
      <Chips value={show} onChange={setShow} testIDPrefix="scc-show" options={[{ value: 'todo', label: `To count (${s.notCounted})` }, { value: 'done', label: 'Counted' }].concat(showExpected ? [{ value: 'diff', label: 'Differences' }] : []).concat([{ value: 'all', label: 'All' }])} />
      {(exact ? [exact] : filtered).slice(0, 150).map((l) => {
        const off = showExpected && l.counted !== null && Math.abs(l.variance) > 1e-9;
        return (
          <Card key={l.uid} tone={l.recount && l.counted === null ? 'warn' : off ? (l.variance < 0 ? 'danger' : 'warn') : l.counted !== null ? 'success' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              {c.status === 'review' && can('stocktake_approve') ? (
                <Pressable onPress={() => setPick(pick.includes(l.item_uid) ? pick.filter((x) => x !== l.item_uid) : pick.concat([l.item_uid]))}><Text style={{ fontSize: 24 }}>{pick.includes(l.item_uid) ? '☑' : '☐'}</Text></Pressable>
              ) : null}
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}{l.recount && l.counted === null ? '  – COUNT AGAIN' : ''}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{l.code}{l.location ? ` · ${l.location}` : ''}{l.counted !== null ? ` · counted ${fq(l.counted)} by ${l.counted_by_name}` : ''}{showExpected ? ` · expected ${fq(l.expected)}` : ''}{l.first_count !== null ? ` · 1st count ${fq(l.first_count)}` : ''}</Text>
                {off ? <Text style={{ fontSize: 15, fontWeight: '800', color: l.variance < 0 ? C.danger : C.warn }}>{l.variance > 0 ? '+' : ''}{fq(l.variance)} {l.unit} · {$(l.value)}{l.reason ? ` · ${l.reason}` : ''}</Text> : null}
                {l.double ? <Text style={{ fontSize: 14, color: l.mismatch ? C.danger : l.needsSecond ? C.warn : C.success }}>{l.needsSecond ? '👥 Needs a second count by another person' : l.mismatch ? `👥 The two counts differ (${fq(l.counted)} and ${fq(l.second_count)})` : l.second_count !== null && l.second_count !== undefined ? `👥 Counted twice ✓ (${l.second_by_name})` : '👥 Counted twice (high value)'}</Text> : null}
                {l.expiry ? <Text style={{ fontSize: 14, color: C.warn }}>Expires {l.expiry}{l.expiry_qty ? ` · ${fq(l.expiry_qty)}` : ''}</Text> : null}
              </View>
            </View>
            {counting && can('stocktake_count') ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                {Number(l.pack_size) > 1 ? <><QtyBox value={packs[l.item_uid] === undefined ? '' : packs[l.item_uid]} onChange={(v) => setPacks({ ...packs, [l.item_uid]: v })} testID={`scc-p-${l.code}`} /><Text style={{ color: C.sub }}>× {fq(l.pack_size)} +</Text></> : null}
                <QtyBox value={entry[l.item_uid] === undefined ? '' : entry[l.item_uid]} onChange={(v) => setEntry({ ...entry, [l.item_uid]: v })} testID={`scc-n-${l.code}`} />
                <Btn testID={`scc-set-${l.code}`} title="Set" size="sm" variant="success" onPress={() => enter(l, false)} />
                {l.counted !== null ? <Btn testID={`scc-add-${l.code}`} title="+ Add" size="sm" variant="info" onPress={() => enter(l, true)} /> : null}
                <Btn testID={`scc-exp-${l.code}`} title={expiry[l.item_uid] ? 'Save expiry' : '📅 Expiry'} size="sm" variant="secondary" onPress={() => {
                  const e = expiry[l.item_uid];
                  if (!e) { setExpiry({ ...expiry, [l.item_uid]: { date: '', qty: '' } }); return; }
                  if (act(() => I.setLineExpiry(user, c.uid, l.item_uid, { expiry: e.date, qty: e.qty }), 'Expiry saved') !== null) setExpiry({ ...expiry, [l.item_uid]: null });
                }} />
              </View>
            ) : null}
            {expiry[l.item_uid] ? (
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                <View style={{ flexBasis: 200, flexGrow: 1 }}><DateField label="Expires" value={expiry[l.item_uid].date} onChange={(v) => setExpiry({ ...expiry, [l.item_uid]: { ...expiry[l.item_uid], date: v } })} quick={false} /></View>
                <View style={{ flexBasis: 120 }}><Field label="How many" value={expiry[l.item_uid].qty} onChangeText={(v) => setExpiry({ ...expiry, [l.item_uid]: { ...expiry[l.item_uid], qty: v } })} keyboardType="numeric" /></View>
              </View>
            ) : null}
            {off && (c.status === 'review' || !c.blind) && (can('stocktake_count') || can('stocktake_approve')) ? (
              <Chips value={l.reason || null} onChange={(v) => act(() => I.setLineReason(user, c.uid, l.item_uid, v), null)} testIDPrefix={`scc-why-${l.code}`} options={I.invRules().countReasons.map((r) => ({ value: r, label: r }))} />
            ) : null}
          </Card>
        );
      })}
      {c.status === 'review' && can('stocktake_approve') ? (
        <Section title="Approve">
          {pick.length ? <Btn testID="scc-recount" title={`Count ${pick.length} again`} size="md" variant="warn" onPress={() => act(() => I.requestRecount(user, c.uid, pick, 'Asked by approver'), 'Sent back for counting') && setPick([])} /> : null}
          <Card tone={s.net < 0 ? 'danger' : 'success'}>
            <Row label="Products counted" value={`${s.counted} of ${s.products}${s.notCounted ? (c.uncounted === 'zero' ? ' – the rest will be set to 0' : ' – the rest stay as they are') : ''}`} />
            <Row label="Short" value={`${s.short} products · ${$(s.loss)}`} color={C.danger} />
            <Row label="Over" value={`${s.over} products · ${$(s.gain)}`} />
            <Row label="Net change in stock value" value={$(s.net)} bold />
            {s.noReason ? <Text style={{ color: C.warn }}>{s.noReason} difference(s) have no reason yet.</Text> : null}
            {-s.loss > I.invRules().countApproveOver ? <Text style={{ color: C.danger }}>{`The loss is over ${$(I.invRules().countApproveOver)} – the owner or admin approves it.`}</Text> : null}
          </Card>
          <Btn testID="scc-post" title="Approve and update the stock" icon="✅" variant="success" onPress={() => act(() => I.postCount(user, c.uid), 'Posted – stock updated and unfrozen')} />
        </Section>
      ) : null}
      {['counting', 'review'].includes(c.status) && can('stocktake_approve') ? (
        <ReasonButton testID="scc-cancel" title="Cancel this stock take (nothing changes)" prompt="Why is it cancelled?" confirm="Cancel stock take" onDo={(w) => act(() => I.cancelCount(user, c.uid, w), 'Cancelled – stock unfrozen') && nav.pop()} />
      ) : null}
    </Screen>
  );
}
