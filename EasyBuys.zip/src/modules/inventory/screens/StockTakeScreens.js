// Stock take: start (whole shop, groups, shelves or a rolling count), count (stock frozen), hand in, approve and post, results.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, Select, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, ListItem, Stats, Hint, Explain, ReasonButton, MoneyField } from '../../../ui/kit.js';
import { listSuppliers } from '../../payables/service.js';
import { setFcccPrice } from '../fccc.js';
import { dateStr } from '../../../services/core.js';
import { shareReport, printReport } from '../../../platform/files.js';
import { db } from '../../../db/connection.js';
import * as I from '../service.js';
import { countReport } from '../reports.js';
import { shopName, shopChips, useShop, QtyBox, fq } from './common.js';
import { ScanBar } from './scanUi.js';
import * as GL from '../goLiveCount.js';
import * as PT from '../packTerms.js';
import { findByBarcode, NOT_FOUND } from '../scan.js';

const { $ } = I;
const ST_COLOR = { counting: C.info, review: C.warn, posted: C.success, cancelled: C.sub };
const locationsAt = (shop) => db().all("SELECT DISTINCT location AS l FROM inv_item_shops WHERE shop_code = ? AND location IS NOT NULL AND location <> '' ORDER BY location", [shop]).map((r) => r.l);

export function StockTakesScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = I.invRules();
  const [shop, setShop] = useShop(params.shopCode);
  const [mode, setMode] = useState(params.highValue ? 'new' : 'list');
  const [scopeKind, setScopeKind] = useState(params.highValue ? 'high' : 'all');
  const [groups, setGroups] = useState([]);
  const [locs, setLocs] = useState([]);
  const [date, setDate] = useState(dateStr());
  const [timing, setTiming] = useState('after_close');
  const [blind, setBlind] = useState(rules.blindCount);
  const list = I.listCounts({ shopCode: shop, limit: 50 });
  const toggle = (arr, set, v) => set(arr.includes(v) ? arr.filter((x) => x !== v) : arr.concat([v]));
  const cycle = scopeKind === 'cycle' ? I.cycleSuggestions(shop) : scopeKind === 'high' ? I.highValueDue(shop) : [];
  const start = () => {
    try {
      const scope = scopeKind === 'groups' ? { groups } : scopeKind === 'locations' ? { locations: locs } : ['cycle', 'high'].includes(scopeKind) ? { itemUids: cycle.map((r) => r.uid) } : {};
      if (['cycle', 'high'].includes(scopeKind) && !cycle.length) throw Object.assign(new Error('Every product has been counted recently.'), { isAppError: true });
      const c = I.startCount(user, { shopCode: shop, scope, date, timing, blind, kind: scopeKind === 'initial' ? 'initial' : 'normal', name: scopeKind === 'cycle' ? `${shop} rolling count ${date}` : scopeKind === 'high' ? `${shop} high-value count ${date}` : undefined });
      ui.toast(`Started – ${c.lines.length} products to count`);
      nav.push('StockCount', { uid: c.uid });
      setMode('list');
    } catch (e) { ui.error(e); }
  };
  if (mode === 'new') {
    return (
      <Screen title="Start a stock take" subtitle={shopName(shop)} onBack={() => setMode('list')}
        footer={<Btn testID="sc-start" title="Start – freeze the stock" icon="❄️" variant="success" onPress={start} />}>
        <Explain title="How a stock take works">
          1. Start it: the products being counted are frozen – no write-offs, transfers or deliveries can be entered for them until it is finished (sales from Aronium still come in and are allowed for).{'\n'}
          2. Count: walk the shelves and enter what you see. Several people can count at once on different devices.{'\n'}
          3. Hand in: anything far off is sent back to be counted again.{'\n'}
          4. A manager checks the results (short and over, in dollars) and approves. Only then does the stock change.
        </Explain>
        <Label>What to count</Label>
        <Chips value={scopeKind} onChange={setScopeKind} testIDPrefix="sc-scope" options={(['owner', 'admin'].includes(user.role) ? [{ value: 'initial', label: 'First stock take (opening)' }] : []).concat([{ value: 'all', label: 'Whole shop' }, { value: 'groups', label: 'Some groups' }, { value: 'locations', label: 'Some shelves' }, { value: 'cycle', label: 'Rolling count' }, { value: 'high', label: 'High-value (weekly)' }])} />
        {scopeKind === 'groups' ? <Chips value={null} onChange={(v) => toggle(groups, setGroups, v)} options={I.listGroups().map((g) => ({ value: g, label: `${groups.includes(g) ? '☑' : '☐'} ${g}` }))} testIDPrefix="sc-g" /> : null}
        {scopeKind === 'locations' ? (locationsAt(shop).length ? <Chips value={null} onChange={(v) => toggle(locs, setLocs, v)} options={locationsAt(shop).map((g) => ({ value: g, label: `${locs.includes(g) ? '☑' : '☐'} ${g}` }))} /> : <Hint>No shelf locations set yet. Set them on each product (Stock on hand › product › Shelf / location).</Hint>) : null}
        {scopeKind === 'initial' ? <Hint>Every product on the list, whether this shop has it yet or not. Everyone can help on their own phone: each count is kept separately and added up through the cloud. The cost, selling price, barcode and suppliers show on each product (managers can fix them there). A product scanned that is not on the list can be added on the spot. When it is approved, the counted numbers become the opening stock.</Hint> : null}
        {scopeKind === 'high' ? <Hint>{`${cycle.length} high-value products (counted twice, by two people) not counted in the last ${rules.cycleHighValueDays} days.`}</Hint> : null}
        {scopeKind === 'cycle' ? <Hint>{`${cycle.length} products not counted in the last ${rules.cycleDays} days, most valuable first. Counting a few every week keeps stock right without closing the shop.`}</Hint> : null}
        <DateField label="Count date" value={date} onChange={setDate} />
        <Label>When is the count done?</Label>
        <Chips value={timing} onChange={setTiming} testIDPrefix="sc-time" options={[{ value: 'after_close', label: 'After closing' }, { value: 'before_open', label: 'Before opening' }]} />
        <Hint>So the app knows whether that day's sales happened before or after the count.</Hint>
        <Chips value={blind ? 'y' : 'n'} onChange={(v) => setBlind(v === 'y')} testIDPrefix="sc-blind" options={[{ value: 'y', label: 'Blind count' }, { value: 'n', label: 'Show expected numbers' }]} />
        <Hint>Blind count: counters do not see how many the system expects, so they count what is really there.</Hint>
      </Screen>
    );
  }
  return (
    <Screen title="Stock takes" subtitle={shopName(shop)}>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="sc-shop" />
      {can('stocktake_count') ? <Btn testID="sc-new" title="Start a stock take" icon="📋" variant="success" onPress={() => setMode('new')} /> : null}
      {!list.some((c) => c.status === 'posted') ? (() => {
        // v1.0.0 the first stock take of this shop (go-live): the night's checklist. Each shop has its own count and stock.
        let g = null;
        try { g = GL.goLiveCountChecklist(shop); } catch (e) { g = null; }
        return g ? (
          <Card tone="info">
            <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>{`First stock take – ${shopName(shop)}`}</Text>
            {g.steps.map((t, i) => <Text key={i} testID={`sc-step-${i}`} style={{ fontSize: 15, color: C.text, marginTop: 3 }}>{`${i + 1}. ${t}`}</Text>)}
            {g.link && !g.link.length ? <Text style={{ fontSize: 14, color: C.warn, marginTop: 6 }}>No till PC of this shop has sent anything yet – without it, sales will not come off the stock in the app.</Text> : null}
            {g.doubleGroups.length && !g.doubleProducts ? <Text style={{ fontSize: 14, color: C.warn, marginTop: 6 }}>{`No product is in the groups ${g.doubleGroups.join(', ')} – check the group names of cigarettes and liquor in Inventory settings (double count).`}</Text> : null}
          </Card>
        ) : null;
      })() : null}
      {!list.length ? <Text style={{ color: C.sub }}>No stock takes yet.</Text> : null}
      {list.map((c) => (
        <ListItem key={c.uid} testID={`sc-${c.uid}`} onPress={() => nav.push('StockCount', { uid: c.uid })} title={c.name}
          sub={`${c.count_date} · started by ${c.started_by_name}${c.posted_by_name ? ` · approved by ${c.posted_by_name}` : ''}`}
          right={c.result ? $(c.result.net) : ''} rightSub={c.result && c.result.accuracy !== null ? `${c.result.accuracy}% right` : ''} badge={I.COUNT_STATUS[c.status]} badgeColor={ST_COLOR[c.status]} />
      ))}
    </Screen>
  );
}

export function StockCountScreen({ params }) {
  const { nav, user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const [q, setQ] = useRemembered('q', '');
  const [show, setShow] = useRemembered('show', 'todo');
  const [entry, setEntry] = useState({});
  const [pick, setPick] = useState([]);
  const [packs, setPacks] = useState({}); // { item_uid: { word: n } } – the product's pack words (sleeve, carton …)
  const [teach, setTeach] = useState(null); // { itemUid, word, qty, group }
  const [quick, setQuick] = useState(false);
  const [area, setArea] = useState(null);
  const [expiry, setExpiry] = useState({});
  const [spot, setSpot] = useRemembered('spot', '');
  const [open, setOpen] = useState(null); // item_uid whose details / entries are open
  const [edit, setEdit] = useState(null); // { itemUid, cost, price, barcode, sup }
  const [total, setTotal] = useState({});
  const [newItem, setNewItem] = useState(null); // { barcode, name, cost, price }
  const [, bump] = useState(0);
  const c = I.getCount(params.uid);
  if (!c) return <Screen title="Stock take"><Text>Not found.</Text></Screen>;
  const s = c.summary;
  const counting = c.status === 'counting';
  const initial = c.kind === 'initial';
  // v3.9.3 anyone may help with the first stock take; the admin / a manager can change any total.
  const canCount = can('stocktake_count') || initial;
  const boss = ['owner', 'admin'].includes(user.role) || can('stocktake_approve');
  const manage = can('inventory_manage') || ['owner', 'admin'].includes(user.role);
  const showExpected = initial ? c.status !== 'counting' : !c.blind || c.status !== 'counting';
  if (!initial && !can('stocktake_count') && !can('stocktake_approve')) return <Screen title="Stock take"><Text>Only the first (opening) stock take is open to everyone.</Text></Screen>;
  const sups = manage && edit ? listSuppliers() : [];
  const again = () => { bump((x) => x + 1); if (refresh) refresh(); };
  const filtered = c.lines.filter((l) => (!area || l.area === area) && (!q.trim() || `${l.name} ${l.code} ${l.barcode || ''}`.toLowerCase().includes(q.trim().toLowerCase()))
    && (show === 'all' || (show === 'todo' ? l.counted === null : show === 'done' ? l.counted !== null : Math.abs(l.variance) > 1e-9)));
  const exact = q.trim().length >= 3 ? c.lines.find((l) => l.barcode === q.trim() || l.code.toUpperCase() === q.trim().toUpperCase()) : null;
  const enter = async (l, add) => {
    const v = entry[l.item_uid];
    const pw = packs[l.item_uid] || {};
    const terms = PT.termsFor({ uid: l.item_uid, group_name: l.group_name, pack_size: l.pack_size, name: l.name });
    const fromPacks = terms.reduce((t, x) => t + (Number(pw[x.word]) || 0) * x.qty, 0);
    const anyPack = Object.values(pw).some((x) => x !== '' && x !== undefined && Number(x) > 0);
    if ((v === undefined || v === '') && !anyPack) return;
    const pk = undefined;
    // Already counted by someone else: "Set" adds yours to theirs (found in another place) – say so first.
    const others = !add && l.counted !== null && I.countEntries(c.uid, l.item_uid).some((e) => e.by_uid !== user.uid);
    if (others) {
      const ok = await ui.confirm({ title: `Already counted: ${fq(l.counted)}`, message: `${l.counted_by_name} already counted ${l.name}. Is yours another lot (another shelf, the storeroom)? It is added to theirs.${boss ? ' To put the right total instead, use "Change total".' : ' If their number is wrong, ask the admin to change the total.'}`, confirmText: 'Add mine', cancelText: 'Cancel' });
      if (!ok) return;
    }
    if (act(() => I.enterCount(user, c.uid, l.item_uid, Math.round(((Number(v) || 0) + fromPacks) * 1000) / 1000, { add, packs: pk, spot }), add ? `Added – ${l.name}` : `Counted – ${l.name}`) !== null) { setEntry({ ...entry, [l.item_uid]: '' }); setPacks({ ...packs, [l.item_uid]: {} }); if (exact) setQ(''); }
  };
  const handIn = async () => {
    let restZero;
    if (s.notCounted) {
      const z = await ui.confirm({ title: `${s.notCounted} not counted`, message: 'Is this a full count? Then the products not counted are set to 0. Otherwise they stay as they are.', confirmText: 'Set them to 0', cancelText: 'Leave them', tone: 'warn' });
      restZero = !!z;
    }
    try {
      const r = I.submitCount(user, c.uid, { restZero });
      if (refresh) refresh();
      if (r.recount.length) { ui.alert({ title: 'Count these again', message: `These are well off what was expected. Please count them once more:\n\n${r.recount.map((x) => `• ${x.name}`).join('\n')}`, tone: 'warn' }); setShow('todo'); }
      else ui.toast('Handed in – waiting for approval');
    } catch (e) { ui.error(e); }
  };
  const sheet = () => printReport(countReport(c.uid, { sheet: true })).catch((e) => ui.error(e));
  return (
    <Screen title={c.name} subtitle={`${I.COUNT_STATUS[c.status]} · ${c.count_date} · ${c.timing === 'before_open' ? 'before opening' : 'after closing'}`}
      footer={counting && canCount ? <Btn testID="scc-handin" title={`Hand in (${s.counted} of ${s.products} counted)`} icon="📤" variant="success" onPress={handIn} /> : null}>
      <Stats items={[
        { label: 'Counted', value: `${s.counted} / ${s.products}`, color: s.notCounted ? undefined : C.success },
        showExpected ? { label: 'Short (loss)', value: $(s.loss), color: s.loss < 0 ? C.danger : undefined } : null,
        showExpected ? { label: 'Over', value: $(s.gain) } : null,
        showExpected && s.accuracy !== null && !initial ? { label: 'Accuracy', value: `${s.accuracy}%`, sub: 'products exactly right' } : null,
        initial ? { label: 'Counted stock at cost', value: $(s.countedCost) } : null,
        initial ? { label: 'At selling price', value: $(s.countedRetail) } : null,
      ]} />
      {c.people && c.people.length ? <Text style={{ fontSize: 14, color: C.sub }}>{`Counted so far: ${c.people.map((p) => `${p.name} ${p.products}`).join(' · ')} (other phones show up after they sync – about a minute)`}</Text> : null}
      {counting ? <Banner tone="info" message="Stock for these products is frozen until this stock take is approved or cancelled." /> : null}
      {(() => { const late = c.status === 'posted' ? I.lateCounts().find((x) => x.uid === c.uid) : null; return late ? (
        <Card tone="warn">
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${late.n} count(s) arrived after this was approved (a phone that was offline). They are NOT in the stock.`}</Text>
          <Hint>Check those products and use Write off / adjust if the stock needs changing. Then tap "Seen".</Hint>
          {boss ? <Btn testID="scc-late-seen" title="Seen" size="sm" variant="secondary" onPress={() => act(() => I.ackLateCounts(user, c.uid), 'Noted')} /> : null}
        </Card>
      ) : null; })()}
      {counting ? <Hint>{c.blind ? 'Blind count: just count what is on the shelf. ' : ''}Type or scan the product, enter the number, tap "Set". Each person's count is kept separately and added up – phones never overwrite each other. "Set" again replaces only YOUR count; found more somewhere else? "+ Add". Tap "✅ Counted" to see who counted what.{initial ? ' First stock take: anyone can help, and products not on the list are added when scanned.' : ''}</Hint> : null}
      {c.status === 'review' ? <Hint>Check the differences below. If something looks wrong, tick it and ask for a recount. When happy, approve: the stock of every counted product becomes what was counted, and the losses / gains are recorded.</Hint> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="scc-sheet" title="Print count sheet" icon="🖨️" size="sm" variant="secondary" onPress={sheet} />
        {!counting ? <Btn testID="scc-report" title="Results PDF" icon="📄" size="sm" variant="secondary" onPress={() => Promise.resolve().then(() => shareReport(countReport(c.uid), 'pdf')).catch((e) => ui.error(e))} /> : null}
      </View>
      {counting && canCount ? (
        <ScanBar testID="scc-scan" quick={quick} hint={quick ? 'Each beep adds 1 to that product.' : 'Scan each product and type how many you see. Scanning a product already counted adds to it (counted in two places).'}
          lookup={(code) => {
            const it = findByBarcode(code);
            if (!it) { if (initial && manage) setNewItem({ barcode: code, name: '', cost: '', price: '' }); return { ok: false, notFound: true, message: initial && manage ? 'Not on the product list – add it below.' : NOT_FOUND }; }
            let l = c.lines.find((x) => x.item_uid === it.uid);
            if (!l && initial) { try { I.addToCount(user, c.uid, it.uid); l = { item_uid: it.uid, counted: null }; } catch (e) { return { ok: false, message: e.message }; } }
            if (!l) return { ok: false, message: `${it.name} is not part of this stock take.` };
            return { ok: true, item: it, note: l.counted !== null ? `already counted ${fq(l.counted)} – this adds to it` : null };
          }}
          onItem={(it, n) => { const l = c.lines.find((x) => x.item_uid === it.uid); act(() => I.enterCount(user, c.uid, it.uid, n, { add: quick || (l && l.counted !== null) }), null); if (refresh) refresh(); }} />
      ) : null}
      {counting && canCount ? <Field testID="scc-spot" label="Where are you counting? (optional – e.g. Aisle 3, Storeroom)" value={spot} onChangeText={setSpot} /> : null}
      {newItem ? (
        <Card tone="warn">
          <H>{`New product – barcode ${newItem.barcode}`}</H>
          <Field testID="scc-new-name" label="Name" value={newItem.name} onChangeText={(v) => setNewItem({ ...newItem, name: v })} />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField testID="scc-new-cost" label="Cost (excl. VAT)" value={newItem.cost} onChange={(v) => setNewItem({ ...newItem, cost: v })} /></View>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><MoneyField testID="scc-new-price" label="Selling price" value={newItem.price} onChange={(v) => setNewItem({ ...newItem, price: v })} /></View>
          </View>
          <Chips value={newItem.vat || 'standard'} onChange={(v) => setNewItem({ ...newItem, vat: v })} testIDPrefix="scc-new-vat" options={[{ value: 'standard', label: 'VAT 12.5%' }, { value: 'zero', label: 'Zero rated' }, { value: 'exempt', label: 'VAT free' }]} />
          <Hint>Add it to Aronium too, with the same barcode, so its sales come through. If a product with this name is already in the app, the barcode is added to it instead.</Hint>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID="scc-new-save" title="Add and count it" icon="➕" size="md" variant="success" onPress={() => { try { const r = I.addScannedProduct(user, c.uid, { barcode: newItem.barcode, name: newItem.name, cost: newItem.cost, price: newItem.price, vatType: newItem.vat || 'standard' }); setQ(newItem.barcode); setNewItem(null); ui.toast(r.added ? 'Added – now type how many' : `The barcode was added to ${r.name} – now type how many`); again(); } catch (e) { ui.error(e); } }} />
            <Btn title="Cancel" size="md" variant="ghost" onPress={() => setNewItem(null)} />
          </View>
        </Card>
      ) : null}
      {c.areas && c.areas.length > 1 ? (
        <Section title="Areas">
          {c.areas.map((a) => (
            <View key={a.area} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 3 }}>
              <Pressable testID={`scc-area-${a.area}`} onPress={() => setArea(area === a.area ? null : a.area)} style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, color: area === a.area ? C.primary : C.text, fontWeight: area === a.area ? '800' : '600' }}>{a.done ? '✅' : a.counted ? '🟠' : '⬜'} {a.area} · {a.counted}/{a.total}{a.counter ? ` · ${a.counter}` : ''}</Text>
              </Pressable>
              {counting && canCount && !a.done ? (a.counter === user.name
                ? <Btn testID={`scc-area-done-${a.area}`} title="Done" size="sm" variant="success" onPress={() => act(() => I.finishArea(user, c.uid, a.area), `${a.area} done`)} />
                : <Btn testID={`scc-area-take-${a.area}`} title="I'll count it" size="sm" variant="secondary" onPress={() => { if (act(() => I.claimArea(user, c.uid, a.area), `You are counting ${a.area}`) !== null) setArea(a.area); }} />) : null}
            </View>
          ))}
        </Section>
      ) : null}
      {counting && canCount ? <Chips value={quick ? 'q' : 'n'} onChange={(v) => setQuick(v === 'q')} testIDPrefix="scc-mode" options={[{ value: 'n', label: 'Scan, then type how many' }, { value: 'q', label: 'Each scan counts 1' }]} /> : null}
      <Field testID="scc-q" label="Find (name, code or scan barcode)" value={q} onChangeText={setQ} />
      <Chips value={show} onChange={setShow} testIDPrefix="scc-show" options={[{ value: 'todo', label: `To count (${s.notCounted})` }, { value: 'done', label: 'Counted' }].concat(showExpected ? [{ value: 'diff', label: 'Differences' }] : []).concat([{ value: 'all', label: 'All' }])} />
      {(exact ? [exact] : filtered).slice(0, 150).map((l) => {
        const off = showExpected && l.counted !== null && Math.abs(l.variance) > 1e-9;
        return (
          <Card key={l.uid} tone={l.recount && l.counted === null ? 'warn' : off ? (l.variance < 0 ? 'danger' : 'warn') : l.counted !== null ? 'success' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              {c.status === 'review' && can('stocktake_approve') ? (
                <Pressable onPress={() => setPick(pick.includes(l.item_uid) ? pick.filter((x) => x !== l.item_uid) : pick.concat([l.item_uid]))}><Text style={{ fontSize: 24 }}>{pick.includes(l.item_uid) ? '☑' : '☐'}</Text></Pressable>
              ) : null}
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{l.name}{l.recount && l.counted === null ? '  – COUNT AGAIN' : ''}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{l.code}{l.location ? ` · ${l.location}` : ''}{showExpected ? ` · expected ${fq(l.expected)}` : ''}{l.first_count !== null ? ` · 1st count ${fq(l.first_count)}` : ''}</Text>
                {l.counted !== null ? <Pressable testID={`scc-who-${l.code}`} onPress={() => setOpen(open === l.item_uid ? null : l.item_uid)}><Text style={{ fontSize: 16, fontWeight: '800', color: C.success }}>{`✅ Counted ${fq(l.counted)}${(() => { const d = PT.describeQty({ uid: l.item_uid, group_name: l.group_name, pack_size: l.pack_size }, l.counted); return d !== String(l.counted) && d !== fq(l.counted) ? ` (${d})` : ''; })()} – ${l.counted_by_name || ''}${l.entries > 1 ? ` (${l.entries} counts)` : ''}  ›`}</Text></Pressable> : null}
                {initial ? (() => {
                  const it = I.itemAtShop(l.item_uid, c.shop_code) || {};
                  const sp = I.itemSuppliers(l.item_uid);
                  const VAT = { standard: 'VAT 12.5%', zero: 'Zero rated', exempt: 'VAT free' };
                  return <Text style={{ fontSize: 14, color: C.text }}>{`Cost ${$(it.cost)} · Selling ${$(it.shopPrice)} · ${VAT[it.vat_type] || 'VAT 12.5%'}${it.aronium_vat && ((it.aronium_vat === 'standard') !== ((it.vat_type || 'standard') === 'standard')) ? ` (⚠ Aronium: ${VAT[it.aronium_vat]})` : ''}${it.fccc ? ` · FCCC ${$(it.fccc_max)}` : ''} · Barcode ${it.barcode || '—'} · ${sp.length ? sp.map((x) => `${x.supplier_name}${x.main ? ' (main)' : ''}`).join(', ') : 'no supplier'}`}</Text>;
                })() : null}
                {off ? <Text style={{ fontSize: 15, fontWeight: '800', color: l.variance < 0 ? C.danger : C.warn }}>{l.variance > 0 ? '+' : ''}{fq(l.variance)} {l.unit} · {$(l.value)}{l.reason ? ` · ${l.reason}` : ''}</Text> : null}
                {l.double ? <Text style={{ fontSize: 14, color: l.mismatch ? C.danger : l.needsSecond ? C.warn : C.success }}>{l.needsSecond ? '👥 Needs a second count by another person' : l.mismatch ? `👥 The two counts differ (${fq(l.counted)} and ${fq(l.second_count)})` : l.second_count !== null && l.second_count !== undefined ? `👥 Counted twice ✓ (${l.second_by_name})` : '👥 Counted twice (high value)'}</Text> : null}
                {l.expiry ? <Text style={{ fontSize: 14, color: C.warn }}>Expires {l.expiry}{l.expiry_qty ? ` · ${fq(l.expiry_qty)}` : ''}</Text> : null}
              </View>
            </View>
            {counting && canCount ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                {PT.termsFor({ uid: l.item_uid, group_name: l.group_name, pack_size: l.pack_size, name: l.name }).slice(0, 3).map((t) => (
                  <View key={t.word} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <QtyBox value={(packs[l.item_uid] || {})[t.word] === undefined ? '' : packs[l.item_uid][t.word]} onChange={(v) => setPacks({ ...packs, [l.item_uid]: { ...(packs[l.item_uid] || {}), [t.word]: v } })} testID={t.word === 'carton' && t.from === 'pack size' ? `scc-p-${l.code}` : `scc-t-${t.word}-${l.code}`} />
                    <Text style={{ color: C.sub }}>{`${t.word}s (×${fq(t.qty)}) +`}</Text>
                  </View>
                ))}
                <QtyBox value={entry[l.item_uid] === undefined ? '' : entry[l.item_uid]} onChange={(v) => setEntry({ ...entry, [l.item_uid]: v })} testID={`scc-n-${l.code}`} />
                <Btn testID={`scc-set-${l.code}`} title="Set" size="sm" variant="success" onPress={() => enter(l, false)} />
                <Btn testID={`scc-teach-${l.code}`} title="🔤 Pack word" size="sm" variant="ghost" onPress={() => setTeach(teach && teach.itemUid === l.item_uid ? null : { itemUid: l.item_uid, word: '', qty: '', group: false, groupName: l.group_name || '' })} />
                {l.counted !== null ? <Btn testID={`scc-add-${l.code}`} title="+ Add" size="sm" variant="info" onPress={() => enter(l, true)} /> : null}
                <Btn testID={`scc-exp-${l.code}`} title={expiry[l.item_uid] ? 'Save expiry' : '📅 Expiry'} size="sm" variant="secondary" onPress={() => {
                  const e = expiry[l.item_uid];
                  if (!e) { setExpiry({ ...expiry, [l.item_uid]: { date: '', qty: '' } }); return; }
                  if (act(() => I.setLineExpiry(user, c.uid, l.item_uid, { expiry: e.date, qty: e.qty }), 'Expiry saved') !== null) setExpiry({ ...expiry, [l.item_uid]: null });
                }} />
              </View>
            ) : null}
            {teach && teach.itemUid === l.item_uid ? (
              <View style={{ gap: 6 }}>
                <Hint>{`Teach the shop's word for a pack of ${l.name} – e.g. "sleeve" = 10 packets. The app remembers it for counting, and shows stock in these words.`}</Hint>
                <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                  <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID={`scc-tw-${l.code}`} label="Word" value={teach.word} onChangeText={(v) => setTeach({ ...teach, word: v })} placeholder="sleeve, carton, crate…" /></View>
                  <View style={{ flexBasis: 120 }}><Field testID={`scc-tq-${l.code}`} label="Singles in one" value={teach.qty} onChangeText={(v) => setTeach({ ...teach, qty: v })} keyboardType="numeric" /></View>
                </View>
                {teach.groupName ? <Chips value={teach.group ? 'g' : 'p'} onChange={(v) => setTeach({ ...teach, group: v === 'g' })} testIDPrefix={`scc-tg-${l.code}`} options={[{ value: 'p', label: 'Only this product' }, { value: 'g', label: `Every ${teach.groupName} product` }]} /> : null}
                <Btn testID={`scc-tsave-${l.code}`} title="Remember this word" size="sm" variant="success" onPress={() => { if (act(() => PT.teachTerm(user, l.item_uid, { word: teach.word, qty: teach.qty, forGroup: teach.group }), `Learnt: 1 ${teach.word} = ${teach.qty}`) !== null) setTeach(null); }} />
              </View>
            ) : null}
            {expiry[l.item_uid] ? (
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                <View style={{ flexBasis: 200, flexGrow: 1 }}><DateField label="Expires" value={expiry[l.item_uid].date} onChange={(v) => setExpiry({ ...expiry, [l.item_uid]: { ...expiry[l.item_uid], date: v } })} quick={false} /></View>
                <View style={{ flexBasis: 120 }}><Field label="How many" value={expiry[l.item_uid].qty} onChangeText={(v) => setExpiry({ ...expiry, [l.item_uid]: { ...expiry[l.item_uid], qty: v } })} keyboardType="numeric" /></View>
              </View>
            ) : null}
            {open === l.item_uid ? (
              <View style={{ gap: 4 }}>
                {I.countEntries(c.uid, l.item_uid).map((e) => (
                  <View key={e.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={{ flex: 1, fontSize: 15 }}>{`${fq(e.qty)} – ${e.by_name}${e.spot ? ` · ${e.spot}` : ''} · ${String(e.at).slice(11, 16)}`}</Text>
                    {counting && (e.by_uid === user.uid || boss) ? <Btn testID={`scc-void-${e.uid}`} title="✕" size="sm" variant="ghost" onPress={() => act(() => I.voidEntry(user, e.uid, 'typed wrong'), 'Taken out')} /> : null}
                  </View>
                ))}
                {counting && boss ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <QtyBox value={total[l.item_uid] === undefined ? '' : total[l.item_uid]} onChange={(v) => setTotal({ ...total, [l.item_uid]: v })} testID={`scc-total-${l.code}`} />
                    <Btn testID={`scc-settotal-${l.code}`} title="Change total" size="sm" variant="warn" onPress={() => { if (act(() => I.setCountTotal(user, c.uid, l.item_uid, total[l.item_uid], 'checked by the admin'), 'Total changed') !== null) setTotal({ ...total, [l.item_uid]: '' }); }} />
                  </View>
                ) : null}
              </View>
            ) : null}
            {initial && manage && counting ? (edit && edit.itemUid === l.item_uid ? (
              <View style={{ gap: 6 }}>
                <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                  <View style={{ flexBasis: 120, flexGrow: 1 }}><MoneyField testID={`scc-ecost-${l.code}`} label="Cost (excl. VAT)" value={edit.cost} onChange={(v) => setEdit({ ...edit, cost: v })} /></View>
                  <View style={{ flexBasis: 120, flexGrow: 1 }}><MoneyField testID={`scc-eprice-${l.code}`} label={`Selling price ${c.shop_code}`} value={edit.price} onChange={(v) => setEdit({ ...edit, price: v })} /></View>
                  <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID={`scc-ebar-${l.code}`} label="Barcode" value={edit.barcode} onChangeText={(v) => setEdit({ ...edit, barcode: v })} /></View>
                </View>
                <Chips value={edit.vat} onChange={(v) => setEdit({ ...edit, vat: v })} testIDPrefix={`scc-evat-${l.code}`} options={[{ value: 'standard', label: 'VAT 12.5%' }, { value: 'zero', label: 'Zero rated' }, { value: 'exempt', label: 'VAT free' }]} />
                <Chips value={edit.fccc ? 'y' : 'n'} onChange={(v) => setEdit({ ...edit, fccc: v === 'y' })} testIDPrefix={`scc-efccc-${l.code}`} options={[{ value: 'n', label: 'Not price controlled' }, { value: 'y', label: '⚖️ FCCC price controlled' }]} />
                {edit.fccc ? <MoneyField testID={`scc-efmax-${l.code}`} label="FCCC price – highest allowed (VAT incl.)" value={edit.fmax} onChange={(v) => setEdit({ ...edit, fmax: v })} /> : null}
                {I.itemSuppliers(l.item_uid).map((x) => (
                  <View key={x.supplier_uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={{ flex: 1, fontSize: 15 }}>{`${x.supplier_name}${x.main ? ' (main)' : ''}${x.last_cost ? ` · last ${$(x.last_cost)}` : ''}`}</Text>
                    {!x.main ? <Btn title="Make main" size="sm" variant="secondary" onPress={() => act(() => I.addItemSupplier(user, l.item_uid, x.supplier_uid, { main: true }), 'Main supplier set')} /> : null}
                    <Btn title="✕" size="sm" variant="ghost" onPress={() => act(() => I.removeItemSupplier(user, l.item_uid, x.supplier_uid), 'Removed')} />
                  </View>
                ))}
                <Select testID={`scc-esup-${l.code}`} label="Add a supplier" value={edit.sup || ''} onChange={(v) => { if (v) act(() => I.addItemSupplier(user, l.item_uid, v, { main: !I.itemSuppliers(l.item_uid).length }), 'Supplier added'); setEdit({ ...edit, sup: '' }); }}
                  options={[{ value: '', label: 'Choose' }].concat(sups.map((x) => ({ value: x.uid, label: x.name })))} />
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <Btn testID={`scc-esave-${l.code}`} title="Save details" size="sm" variant="success" onPress={() => { if (act(() => { const it0 = I.getItem(l.item_uid); if (edit.fccc && !(Number(edit.fmax) > 0)) throw new Error('Type the FCCC price, or choose "Not price controlled".'); I.quickEditItem(user, l.item_uid, { shopCode: c.shop_code, cost: edit.cost, price: edit.price, barcode: edit.barcode, vatType: edit.vat }); if (edit.fccc !== !!it0.fccc || (edit.fccc && Math.abs(Number(edit.fmax) - Number(it0.fccc_max || 0)) > 0.004)) setFcccPrice(user, l.item_uid, { controlled: !!edit.fccc, max: edit.fmax, name: it0.fccc_name }); }, 'Saved') !== null) setEdit(null); }} />
                  <Btn title="Close" size="sm" variant="ghost" onPress={() => setEdit(null)} />
                </View>
              </View>
            ) : <Btn testID={`scc-edit-${l.code}`} title="Edit cost / price / VAT / FCCC / barcode / suppliers" size="sm" variant="ghost" onPress={() => { const it = I.itemAtShop(l.item_uid, c.shop_code) || {}; setEdit({ itemUid: l.item_uid, cost: String(it.cost ?? ''), price: String(it.shopPrice ?? ''), barcode: it.barcode || '', sup: '', vat: it.vat_type || 'standard', fccc: !!it.fccc, fmax: it.fccc_max ? String(it.fccc_max) : '' }); }} />) : null}
            {off && (c.status === 'review' || !c.blind) && (canCount || can('stocktake_approve')) ? (
              <Chips value={l.reason || null} onChange={(v) => act(() => I.setLineReason(user, c.uid, l.item_uid, v), null)} testIDPrefix={`scc-why-${l.code}`} options={I.invRules().countReasons.map((r) => ({ value: r, label: r }))} />
            ) : null}
          </Card>
        );
      })}
      {['counting', 'review', 'posted'].includes(c.status) ? (
        <Section title="Other things to count (not products)">
          <Hint>Empty gas cylinders and anything else that is not a product in Aronium. Kept with this stock take and on its results.</Hint>
          {GL.countExtras(c.uid).map((x) => (
            <View key={x.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <Text style={{ flex: 1, minWidth: 180, fontSize: 16, color: C.text }}>{`${x.label}${x.qty !== null && x.qty !== undefined ? ` – ${x.qty}${x.by ? ` (${x.by})` : ''}` : ''}`}</Text>
              {counting && canCount ? <Field testID={`scc-x-${x.key}`} label="How many" value={entry[`x:${x.key}`] !== undefined ? entry[`x:${x.key}`] : (x.qty === null || x.qty === undefined ? '' : String(x.qty))} onChangeText={(v) => setEntry({ ...entry, [`x:${x.key}`]: v })} keyboardType="decimal-pad" /> : null}
              {counting && canCount ? <Btn testID={`scc-x-save-${x.key}`} title="Save" size="sm" variant="success" onPress={() => act(() => GL.saveExtra(user, c.uid, { key: x.key, label: x.label, qty: entry[`x:${x.key}`] }), 'Saved')} /> : null}
            </View>
          ))}
        </Section>
      ) : null}
      {c.status === 'review' && can('stocktake_approve') ? (
        <Section title="Approve">
          {pick.length ? <Btn testID="scc-recount" title={`Count ${pick.length} again`} size="md" variant="warn" onPress={() => act(() => I.requestRecount(user, c.uid, pick, 'Asked by approver'), 'Sent back for counting') && setPick([])} /> : null}
          <Card tone={s.net < 0 ? 'danger' : 'success'}>
            <Row label="Products counted" value={`${s.counted} of ${s.products}${s.notCounted ? (c.uncounted === 'zero' ? ' – the rest will be set to 0' : ' – the rest stay as they are') : ''}`} />
            <Row label="Short" value={`${s.short} products · ${$(s.loss)}`} color={C.danger} />
            <Row label="Over" value={`${s.over} products · ${$(s.gain)}`} />
            <Row label="Net change in stock value" value={$(s.net)} bold />
            {s.noReason ? <Text style={{ color: C.warn }}>{s.noReason} difference(s) have no reason yet.</Text> : null}
            {-s.loss > I.invRules().countApproveOver ? <Text style={{ color: C.danger }}>{`The loss is over ${$(I.invRules().countApproveOver)} – the owner or admin approves it.`}</Text> : null}
          </Card>
          <Btn testID="scc-post" title="Approve and update the stock" icon="✅" variant="success" onPress={() => act(() => I.postCount(user, c.uid), 'Posted – stock updated and unfrozen')} />
        </Section>
      ) : null}
      {['counting', 'review'].includes(c.status) && can('stocktake_approve') ? (
        <ReasonButton testID="scc-cancel" title="Cancel this stock take (nothing changes)" prompt="Why is it cancelled?" confirm="Cancel stock take" onDo={(w) => act(() => I.cancelCount(user, c.uid, w), 'Cancelled – stock unfrozen') && nav.pop()} />
      ) : null}
    </Screen>
  );
}

// v1.0.0 Aronium count sheet: what to type into Aronium's own "300 – Inventory count" document after a stock take.
// No file is made for Aronium on purpose (its product import adds to the stock and can change products).
export function AroniumCountSheetScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [all, setAll] = useState(false);
  const [n, bump] = useState(0);
  let s = null; let err = null;
  try { s = GL.aroniumSheet(params.uid, { all }); } catch (e) { err = e.message; }
  if (!s) return <Screen title="Aronium count sheet"><Banner tone="danger" message={err || 'Stock take not found.'} /></Screen>;
  const share = (fmt) => Promise.resolve().then(() => shareReport(GL.aroniumSheetDoc(params.uid, { all }), fmt)).catch((e) => ui.error(e));
  return (
    <Screen title="Aronium count sheet" subtitle={`${shopName(s.count.shop)} · ${s.entered} of ${s.toType} typed in`}
      footer={<Btn testID="acs-pdf" title="PDF / print to type from" icon="🖨️" variant="primary" onPress={() => share('pdf')} />}>
      <Card tone="info">
        <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>How to put the count into Aronium</Text>
        <Text style={{ fontSize: 15, color: C.text, marginTop: 4 }}>1. On the till PC of this shop: Management › Documents › Add.</Text>
        <Text style={{ fontSize: 15, color: C.text }}>2. Choose Inventory › "300 – Inventory count". Date and time: when the counting was done (after closing).</Text>
        <Text style={{ fontSize: 15, color: C.text }}>3. For each line below: find the product (code or barcode) and type the COUNTED number. Tick it here.</Text>
        <Text style={{ fontSize: 15, color: C.text }}>4. Save the document. Aronium sets the stock to the counted numbers by itself.</Text>
        <Text style={{ fontSize: 15, color: C.danger, fontWeight: '800', marginTop: 6 }}>Do NOT use "Import products" for the count – it adds to the stock (doubling it) and can change products.</Text>
      </Card>
      {!s.aroniumKnown ? <Banner tone="warn" message="The app has no stock figures from this shop's till PCs yet, so every counted product is listed (type them all)." /> : null}
      <Chips value={all ? 'all' : 'diff'} onChange={(v) => setAll(v === 'all')} testIDPrefix="acs-all" options={[{ value: 'diff', label: `Only what differs (${s.toType})` }, { value: 'all', label: `Every counted product (${s.total})` }]} />
      <Text style={{ fontSize: 14, color: C.sub }}>{`${s.same} product(s) already the same in Aronium · ${s.notInAronium} not found in Aronium (add them in Aronium first)`}</Text>
      {s.rows.map((r) => (
        <ListItem key={r.code} testID={`acs-${r.code}`} tone={r.entered ? 'success' : r.inAronium === null ? 'warn' : undefined}
          title={`${r.entered ? '✅ ' : ''}${r.name}`} sub={`${r.group ? `${r.group} · ` : ''}${r.code}${r.barcode ? ` · ${r.barcode}` : ''} · Aronium had ${r.inAronium === null ? 'not found' : r.inAronium}`}
          right={`${r.counted}`} rightSub={r.diff === null ? '' : `${r.diff > 0 ? '+' : ''}${r.diff}`}
          onPress={() => { act(() => GL.markEntered(user, params.uid, r.code, !r.entered)); bump((x) => x + 1); }} />
      ))}
      {!s.rows.length ? <Banner tone="success" message="Nothing to type – Aronium already has the counted numbers." /> : null}
      <Btn testID="acs-xlsx" title="Excel copy" size="sm" variant="ghost" onPress={() => share('xlsx')} />
    </Screen>
  );
}
