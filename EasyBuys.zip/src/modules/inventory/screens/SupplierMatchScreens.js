// 1.0.0 Supplier products to match: each line from the supplier invoices (set-up pack from the Drive invoices) that is
// not linked to its product yet – "Yes, it is this one" / pick another / not a product we sell. Lines waiting for
// their product (Aronium not sent yet) link by themselves when it arrives.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, Hint } from '../../../ui/kit.js';
import * as SC from '../supplierCatalog.js';
import { ItemPicker } from './common.js';

const $ = (n) => (n === null || n === undefined ? '–' : `$${Number(n).toFixed(2)}`);

function Line({ r, user, act, onDone }) {
  const [pick, setPick] = useState(false);
  const facts = [r.code ? `code ${r.code}` : '', r.unit, r.pack ? `pack ${r.pack}` : '', `cost ${$(r.cost)} excl. VAT`, r.vat !== null && r.vat !== undefined ? `VAT ${r.vat}%` : '', r.last_date ? `last ${r.last_date}` : ''].filter(Boolean).join(' · ');
  const tid = `sm-${String(r.code || r.uid).replace(/[^A-Za-z0-9]/g, '')}`;
  return (
    <Card testID={tid} tone={r.status === 'check' ? 'warn' : undefined}>
      <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{r.supplier_name}</Text>
      <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{r.name || r.code}</Text>
      <Text style={{ fontSize: 14, color: C.sub }}>{facts}</Text>
      {r.status === 'check' && r.guess_name ? <Text style={{ fontSize: 15, color: C.text }}>{`Looks like: ${r.guess_name}${r.guess_code ? ` (${r.guess_code})` : ''} – ${r.guess_how || ''}`}</Text> : null}
      {r.status === 'linked' ? <Text style={{ fontSize: 15, color: C.success }}>{`✓ ${r.item_name_now || '?'}${r.decided_by_name ? ` · ${r.decided_by_name}` : ''}`}</Text> : null}
      {r.status === 'waiting' ? <Text style={{ fontSize: 14, color: C.sub }}>No product like it in the app yet – it links by itself when Aronium sends it, or pick it.</Text> : null}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {r.status === 'check' && r.guess_item_uid ? <Btn testID={`${tid}-yes`} title="Yes, this one" icon="✓" size="sm" variant="success" onPress={() => { if (act(() => SC.confirmLine(user, r.uid), 'Linked') !== null) onDone(); }} /> : null}
        {['check', 'waiting'].includes(r.status) ? <Btn testID={`${tid}-pick`} title={pick ? 'Close' : r.status === 'check' ? 'No – pick the product' : 'Pick the product'} size="sm" variant="secondary" onPress={() => setPick(!pick)} /> : null}
        {['check', 'waiting'].includes(r.status) ? <Btn testID={`${tid}-not`} title="Not a product we sell" size="sm" variant="ghost" onPress={() => { if (act(() => SC.notOurs(user, r.uid), 'Will not be asked again') !== null) onDone(); }} /> : null}
        {['linked', 'not_ours'].includes(r.status) ? <Btn testID={`${tid}-undo`} title="Change" size="sm" variant="ghost" onPress={() => { if (act(() => SC.reopenLine(user, r.uid), 'Back to match') !== null) onDone(); }} /> : null}
      </View>
      {pick ? <ItemPicker testID={`${tid}-find`} supplierUid={r.supplier_uid} label="Which product is it?" onPick={(it) => { if (act(() => SC.confirmLine(user, r.uid, it.uid), `Linked to ${it.name}`) !== null) { setPick(false); onDone(); } }} /> : null}
    </Card>
  );
}

export function SupplierMatchScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  const [, bump] = useState(0);
  const c = SC.counts();
  const [tab, setTab] = useState(params.tab || (c.check ? 'check' : c.waiting ? 'waiting' : 'linked'));
  const [q, setQ] = useState('');
  const list = SC.listLines({ status: tab, q, limit: 150 });
  const decided = c.linked + c.not_ours;
  const again = () => { const m = act(() => SC.matchCatalog()); if (m) { act(() => null, `${m.linked} linked · ${m.check} to confirm · ${m.waiting} waiting`); bump((n) => n + 1); } };
  return (
    <Screen title="Supplier products" subtitle={c.all ? `${decided} of ${c.all} sorted` : 'From the supplier invoices'}>
      <Hint>What each supplier sells, from their invoices (their code, the name they print, carton, last cost). Sure matches link by themselves – the barcode, the code, the same name and size. Here you say which product the others are. Once linked, the product shows under that supplier when making an order, with their code and last price.</Hint>
      {!c.all ? <Banner tone="info" message="Nothing here yet. Bring in the set-up pack with the supplier products (Admin › Set-up pack)." /> : null}
      {c.all ? (
        <Chips testIDPrefix="sm-tab" value={tab} onChange={setTab} options={[
          { value: 'check', label: `To confirm (${c.check})` }, { value: 'waiting', label: `Waiting for the product (${c.waiting})` },
          { value: 'linked', label: `Linked (${c.linked})` }, { value: 'not_ours', label: `Not ours (${c.not_ours})` }]} />
      ) : null}
      {c.all ? <Field testID="sm-q" label="Find (supplier, name or code)" value={q} onChangeText={setQ} /> : null}
      {c.check + c.waiting ? <Btn testID="sm-again" title="Match again" icon="🔄" size="sm" variant="info" onPress={again} /> : null}
      {tab === 'waiting' && c.waiting ? <Hint>These wait for their product from Aronium (the till PC's Aronium Link sends the products). Nothing to do unless it is something we no longer sell.</Hint> : null}
      {c.all && !list.length ? <Banner tone="success" message={tab === 'check' ? 'Nothing to confirm.' : 'None.'} /> : null}
      {list.map((r) => <Line key={r.uid} r={r} user={user} act={act} onDone={() => bump((n) => n + 1)} />)}
      {list.length >= 150 ? <Hint>Showing the first 150 – use Find for the rest.</Hint> : null}
    </Screen>
  );
}
