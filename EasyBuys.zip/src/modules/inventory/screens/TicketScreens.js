// 1.0.0 Price tickets: pick (or scan) products, how many of each, a size – print on A4 or share the PDF.
import React, { useState } from 'react';
import { View } from 'react-native';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint } from '../../../ui/kit.js';
import { printHtml } from '../../../platform/printer.js';
import * as PT from '../priceTickets.js';
import * as I from '../service.js';
import { ItemPicker, QtyBox, shopChips, useShop, shopName } from './common.js';
import { ScanBar } from './scanUi.js';
import { findByBarcode, NOT_FOUND } from '../scan.js';

export function PriceTicketsScreen() {
  const ui = useUI();
  const [shop, setShop] = useShop();
  const [L, setL0] = useState(() => PT.savedLayout());
  const [open, setOpen] = useState(false);
  const keep = (c) => { setL0(c); try { PT.saveLayout(c); } catch (e) { /* convenience */ } };
  const setL = (x) => keep(PT.cleanLayout({ ...L, ...x }));
  const [typed, setTyped] = useState({}); // numbers being typed (applied when they make sense)
  const numField = (id, label, value, apply) => (
    <View key={id} style={{ flexBasis: 110, flexGrow: 1 }}><Field testID={`pt-${id}`} label={label} value={typed[id] !== undefined ? typed[id] : String(value)} keyboardType="decimal-pad"
      onChangeText={(v) => { setTyped({ ...typed, [id]: v }); if (v !== '' && Number.isFinite(Number(v))) apply(Number(v)); }} /></View>
  );
  const user = useApp().user;
  const f = PT.fit(L);
  const [list, setList0] = useState(() => PT.savedList());
  const setList = (l) => { setList0(l); try { PT.saveList(l); } catch (e) { /* convenience only */ } };
  const add = (it, n = 1) => {
    const i = list.findIndex((x) => x.itemUid === it.uid);
    setList(i >= 0 ? list.map((x, k) => (k === i ? { ...x, copies: (Number(x.copies) || 1) + n } : x)) : list.concat([{ itemUid: it.uid, copies: n }]));
  };
  const total = list.reduce((t, x) => t + (Number(x.copies) || 1), 0);
  const doc = () => PT.ticketsDoc(shop, list, PT.cleanLayout(L));
  const pages = f.perPage ? Math.max(1, Math.ceil(total / f.perPage)) : 1;
  const print = async () => { try { const d = doc(); await printHtml(d.html, d.size); } catch (e) { ui.error(e); } };
  const pdf = async () => {
    try {
      const d = doc();
      const r = await Print.printToFileAsync({ html: d.html, width: d.size.width, height: d.size.height });
      await Sharing.shareAsync(r.uri, { mimeType: 'application/pdf', dialogTitle: 'Price tickets' });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Price tickets" subtitle={`${shopName(shop)} · ${total} ticket${total === 1 ? '' : 's'} · ${L.paper === 'A4' ? `${pages} A4 page${pages > 1 ? 's' : ''} (${f.perPage} a page)` : `80 mm roll, ${f.cols} across`}`}
      footer={<View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}><Btn testID="pt-print" title="Print" icon="🖨️" variant="success" disabled={!list.length} onPress={print} /></View>
        <View style={{ flex: 1 }}><Btn testID="pt-pdf" title="PDF" icon="📄" variant="secondary" disabled={!list.length} onPress={pdf} /></View>
      </View>}>
      <Hint>Each ticket: this shop's price (big), the name, unit, shop / date and a small barcode – change what is on it, the sizes and the spacing under "Design the ticket". On A4 or the 80 mm receipt printer.</Hint>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="pt-shop" />
      <Chips value={L.paper} onChange={(v) => setL({ paper: v })} testIDPrefix="pt-paper" options={Object.entries(PT.PAPERS).map(([v, x]) => ({ value: v, label: x.label }))} />
      <Chips value={L.preset} onChange={(v) => (PT.PRESETS[v] ? (setTyped({}), keep(PT.applyPreset(L, v))) : null)} testIDPrefix="pt-size" options={Object.entries(PT.PRESETS).map(([v, x]) => ({ value: v, label: x.label })).concat(L.preset === 'custom' ? [{ value: 'custom', label: 'My own' }] : [])} />
      <Btn testID="pt-layout" title={open ? 'Done' : `Design the ticket (${L.w}×${L.h} mm, ${L.items.filter((x) => x.on).length} items)`} icon="📐" size="sm" variant="ghost" onPress={() => { setTyped({}); setOpen(!open); }} />
      {open ? (
        <Card>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>Size and spacing</Text>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            {numField('w', 'Width (mm)', L.w, (v) => setL({ w: v, preset: 'custom' }))}
            {numField('h', 'Height (mm)', L.h, (v) => setL({ h: v, preset: 'custom' }))}
            {numField('gap', 'Space between lines (mm)', L.gap, (v) => setL({ gap: v, preset: 'custom' }))}
            {numField('pad', 'Space at the edge (mm)', L.pad, (v) => setL({ pad: v, preset: 'custom' }))}
          </View>
          <Btn testID="pt-t-border" title={`${L.border ? '☑' : '☐'} Cut lines`} size="sm" variant={L.border ? 'info' : 'secondary'} onPress={() => setL({ border: !L.border })} />
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text, marginTop: 8 }}>On the ticket (top to bottom)</Text>
          {L.items.map((it, i) => {
            const K = PT.ITEM_KINDS[it.key];
            return (
              <View key={it.key} testID={`pt-item-${it.key}`} style={{ borderTopWidth: 1, borderColor: C.border, paddingVertical: 6, gap: 4, opacity: it.on ? 1 : 0.6 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                  <Btn testID={`pt-on-${it.key}`} title={`${it.on ? '☑' : '☐'} ${K.label}`} size="sm" variant={it.on ? 'info' : 'secondary'} onPress={() => keep(PT.setItem(L, it.key, { on: !it.on }))} />
                  <Btn testID={`pt-up-${it.key}`} title="▲" size="sm" variant="ghost" disabled={i === 0} onPress={() => keep(PT.moveItem(L, it.key, -1))} />
                  <Btn testID={`pt-dn-${it.key}`} title="▼" size="sm" variant="ghost" disabled={i === L.items.length - 1} onPress={() => keep(PT.moveItem(L, it.key, 1))} />
                </View>
                {it.on ? (
                  <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 6, flexWrap: 'wrap' }}>
                    {K.text ? numField(`size-${it.key}`, 'Size (pt)', it.size, (v) => keep(PT.setItem(L, it.key, { size: v })))
                      : numField(`height-${it.key}`, 'Height (mm)', it.height, (v) => keep(PT.setItem(L, it.key, { height: v })))}
                    {K.text ? <Btn testID={`pt-bold-${it.key}`} title={it.bold ? 'B bold ✓' : 'B bold'} size="sm" variant={it.bold ? 'info' : 'secondary'} onPress={() => keep(PT.setItem(L, it.key, { bold: !it.bold }))} /> : null}
                    {K.text && i > 0 ? <Btn testID={`pt-inline-${it.key}`} title={it.inline ? '↰ same line ✓' : '↰ same line as above'} size="sm" variant={it.inline ? 'info' : 'secondary'} onPress={() => keep(PT.setItem(L, it.key, { inline: !it.inline }))} /> : null}
                  </View>
                ) : null}
                {it.on && it.key === 'text' ? <Field testID="pt-owntext" label="The words" value={it.text || ''} onChangeText={(v) => keep(PT.setItem(L, 'text', { text: v }))} placeholder="SPECIAL, NEW, 2 FOR $5…" /> : null}
              </View>
            );
          })}
          <Hint>{L.paper === 'A4' ? `${f.cols} across × ${f.rows} down = ${f.perPage} on each A4 page.` : `${f.cols} across the 80 mm roll (72 mm printable), one row under another.`} Print shows a preview first.</Hint>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn testID="pt-reset" title="Back to the standard ticket" size="sm" variant="ghost" onPress={() => { setTyped({}); keep({ ...PT.defaultLayout(), paper: L.paper }); }} />
            {['owner', 'admin', 'manager'].includes(user.role) ? <Btn testID="pt-share" title="Use this design on every device" size="sm" variant="secondary" onPress={() => { try { PT.shareLayout(user, L); ui.toast('Every device now uses this design'); } catch (e) { ui.error(e); } }} /> : null}
          </View>
        </Card>
      ) : null}
      <ScanBar testID="pt-scan" hint="Scan a product to add its ticket (each scan adds one more)."
        lookup={(code) => { const it = findByBarcode(code); return it ? { ok: true, item: it } : { ok: false, notFound: true, message: NOT_FOUND }; }}
        onItem={(it) => add(it, 1)} />
      <ItemPicker shopCode={shop} testID="pt-find" label="Or find a product (name or code)" onPick={(it) => add(it, 1)} />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="pt-changed" title="Prices changed this week" icon="🔄" size="sm" variant="info" onPress={() => { const ch = PT.changedPrices(shop); if (!ch.length) ui.toast('No price changes this week'); else { const have = new Set(list.map((x) => x.itemUid)); setList(list.concat(ch.filter((x) => !have.has(x.itemUid)))); ui.toast(`${ch.length} added`); } }} />
        {list.length ? <Btn testID="pt-clear" title="Clear the list" size="sm" variant="ghost" onPress={() => setList([])} /> : null}
      </View>
      {!list.length ? <Banner tone="info" message="No products yet – scan or find them above." /> : null}
      <Section title={list.length ? `On the sheet (${list.length})` : ''}>
        {list.map((x) => {
          const it = I.itemAtShop(x.itemUid, shop) || {};
          return (
            <View key={x.itemUid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}><ListItem testID={`pt-${it.code}`} tone={Number(it.shopPrice) > 0 ? undefined : 'danger'} title={it.name || '?'} sub={`${Number(it.shopPrice) > 0 ? `$${Number(it.shopPrice).toFixed(2)}` : 'NO PRICE at this shop'} · ${PT.unitText(it.unit)}${it.barcode ? '' : ' · no barcode (code printed)'}`} /></View>
              <QtyBox value={String(x.copies)} onChange={(v) => setList(Number(v) > 0 ? list.map((y) => (y.itemUid === x.itemUid ? { ...y, copies: v } : y)) : list.filter((y) => y.itemUid !== x.itemUid))} testID={`pt-n-${it.code}`} width={70} />
            </View>
          );
        })}
      </Section>
    </Screen>
  );
}
