// Shared pieces for the inventory, purchase order and stock take screens.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Field, Chips, Label, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { listShops } from '../../admin/service.js';
import * as I from '../service.js';

export const shops = () => listShops().filter((s) => s.active);
export const shopName = (code) => { const s = listShops().find((x) => x.code === code); return s ? s.name : code; };
export const shopChips = () => shops().map((s) => ({ value: s.code, label: s.code }));
export const fq = (q) => { const n = Number(q) || 0; return Number.isInteger(n) ? String(n) : String(Math.round(n * 1000) / 1000); };

// The shop being worked on: remembered for the session, starts at the user's own shop.
let lastShop = null;
export function useShop(initial) {
  const { user } = useApp();
  const [shop, setShopState] = useState(initial || lastShop || user.shop_code || (shops()[0] && shops()[0].code) || 'S1');
  const setShop = (v) => { lastShop = v; setShopState(v); };
  return [shop, setShop];
}
export function ShopPicker({ value, onChange, label = 'Shop', testIDPrefix = 'shop' }) {
  return (
    <View style={{ gap: 4 }}>
      <Label>{label}</Label>
      <Chips value={value} onChange={onChange} options={shopChips()} testIDPrefix={testIDPrefix} />
      <Text style={{ fontSize: 13, color: C.sub }}>{shopName(value)} – each shop has its own stock.</Text>
    </View>
  );
}

// Find a product by name, code or barcode (type or scan with a keyboard scanner).
export function ItemPicker({ shopCode, onPick, label = 'Find a product (name, code or barcode)', testID = 'item-find', exclude = [] }) {
  const [q, setQ] = useState('');
  const exact = q.trim().length >= 3 ? I.findItem(q.trim()) : null;
  const list = q.trim().length >= 2 ? I.stockList({ shopCode, q: q.trim(), limit: 8 }) : [];
  const rows = exact && !list.some((r) => r.uid === exact.uid) ? [{ ...exact, on_hand: I.stockOf(exact.uid, shopCode) }].concat(list) : list;
  return (
    <View style={{ gap: 6 }}>
      <Field testID={testID} label={label} value={q} onChangeText={setQ} placeholder="e.g. flour, 1001, 9300001" />
      {rows.filter((r) => !exclude.includes(r.uid)).slice(0, 8).map((r) => (
        <Pressable key={r.uid} testID={`${testID}-${r.code}`} onPress={() => { onPick(r); setQ(''); }}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 10, borderWidth: 1, borderColor: C.border, backgroundColor: pressed ? C.infoSoft : C.white })}>
          <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.name}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{r.code} · {fq(r.on_hand)} {r.unit || ''} here</Text>
        </Pressable>
      ))}
      {q.trim().length >= 2 && !rows.length ? <Text style={{ fontSize: 14, color: C.sub }}>No product found at {shopCode}. Products come from the Aronium import (Inventory › Import).</Text> : null}
    </View>
  );
}

// A small quantity box with − / + buttons.
export function QtyBox({ value, onChange, testID, step = 1, width = 90 }) {
  const n = Number(value) || 0;
  const btn = (t, d) => (
    <Pressable onPress={() => onChange(String(Math.max(0, Math.round((n + d) * 1000) / 1000)))} style={{ width: 40, height: 44, borderRadius: 10, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', backgroundColor: C.white }}>
      <Text style={{ fontSize: 22, fontWeight: '900', color: C.text }}>{t}</Text>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      {btn('−', -step)}
      <View style={{ width }}>
        <Field testID={testID} value={value === null || value === undefined ? '' : String(value)} onChangeText={(t) => onChange(t.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" placeholder="0" />
      </View>
      {btn('+', step)}
    </View>
  );
}
