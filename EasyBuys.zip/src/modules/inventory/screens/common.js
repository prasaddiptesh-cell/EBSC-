// Shared pieces for the inventory, purchase order and stock take screens.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Field, Chips, Label, Btn, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { listShops } from '../../admin/service.js';
import * as I from '../service.js';

export const shops = () => listShops().filter((s) => s.active);
export const shopName = (code) => { const s = listShops().find((x) => x.code === code); return s ? s.name : code; };
export const shopChips = () => shops().map((s) => ({ value: s.code, label: s.code }));
export const fq = (q) => { const n = Number(q) || 0; return Number.isInteger(n) ? String(n) : String(Math.round(n * 1000) / 1000); };

// The shop being worked on: remembered for the session, starts at the user's own shop.
let lastShop = null;
export function useShop(initial) {
  const { user } = useApp();
  const [shop, setShopState] = useState(initial || lastShop || user.shop_code || (shops()[0] && shops()[0].code) || 'S1');
  const setShop = (v) => { lastShop = v; setShopState(v); };
  return [shop, setShop];
}
export function ShopPicker({ value, onChange, label = 'Shop', testIDPrefix = 'shop' }) {
  return (
    <View style={{ gap: 4 }}>
      <Label>{label}</Label>
      <Chips value={value} onChange={onChange} options={shopChips()} testIDPrefix={testIDPrefix} />
      <Text style={{ fontSize: 13, color: C.sub }}>{shopName(value)} – each shop has its own stock.</Text>
    </View>
  );
}

// Find a product by name, code or barcode (type or scan with a keyboard scanner).
// v3.9.8 with a supplier: "This supplier" shows that supplier's products (their last price); "All products" finds any
// product, and picking one not linked yet asks to add it to the supplier's products.
export function ItemPicker({ shopCode, onPick, label = 'Find a product (name, code or barcode)', testID = 'item-find', exclude = [], supplierUid }) {
  const { user } = useApp();
  const ui = useUI();
  const [q, setQ] = useState('');
  const [offer, setOffer] = useState(null);
  const [scope, setScope] = useState(() => { try { return supplierUid && I.supplierProducts(supplierUid, { limit: 1 }).length ? 'sup' : 'all'; } catch (e) { return 'all'; } });
  // 1.0.0 the supplier chosen (or changed) after the picker was shown: back to that supplier's own products
  const lastSup = React.useRef(supplierUid);
  React.useEffect(() => {
    if (lastSup.current === supplierUid) return;
    lastSup.current = supplierUid;
    try { setScope(supplierUid && I.supplierProducts(supplierUid, { limit: 1 }).length ? 'sup' : 'all'); } catch (e) { setScope('all'); }
  }, [supplierUid]);
  if (supplierUid && scope === 'sup') {
    const rows0 = I.supplierProducts(supplierUid, { shopCode, q: q.trim(), limit: 30 }).filter((r) => !exclude.includes(r.uid));
    return (
      <View style={{ gap: 6 }}>
        <Chips value={scope} onChange={setScope} testIDPrefix={`${testID}-scope`} options={[{ value: 'sup', label: 'This supplier' }, { value: 'all', label: 'All products' }]} />
        <Field testID={testID} label="Find one of this supplier's products" value={q} onChangeText={setQ} placeholder="name, code or barcode" />
        {rows0.slice(0, q.trim() ? 12 : 20).map((r) => (
          <Pressable key={r.uid} testID={`${testID}-${r.code}`} onPress={() => { onPick(r); setQ(''); }}
            style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 10, borderWidth: 1, borderColor: C.border, backgroundColor: pressed ? C.infoSoft : C.card })}>
            <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.name}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{`${r.supplierCode || r.code}${r.lastCost !== null && r.lastCost !== undefined ? ` · last $${Number(r.lastCost).toFixed(2)}` : ''} · ${fq(r.on_hand || 0)} here`}</Text>
          </Pressable>
        ))}
        {!rows0.length ? <Text style={{ fontSize: 14, color: C.sub }}>{q.trim() ? 'Not one of this supplier\'s products – try "All products".' : 'No products linked to this supplier yet. They are linked by themselves as deliveries and invoices come in, or pick from "All products".'}</Text> : null}
      </View>
    );
  }
  const exact = q.trim().length >= 3 ? I.findItem(q.trim()) : null;
  const list = q.trim().length >= 2 ? I.stockList({ shopCode, q: q.trim(), limit: 8 }) : [];
  const rows = exact && !list.some((r) => r.uid === exact.uid) ? [{ ...exact, on_hand: I.stockOf(exact.uid, shopCode) }].concat(list) : list;
  return (
    <View style={{ gap: 6 }}>
      {supplierUid ? <Chips value={scope} onChange={setScope} testIDPrefix={`${testID}-scope`} options={[{ value: 'sup', label: 'This supplier' }, { value: 'all', label: 'All products' }]} /> : null}
      <Field testID={testID} label={label} value={q} onChangeText={setQ} placeholder="e.g. flour, 1001, 9300001" />
      {offer ? (
        <View testID={`${testID}-offer`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap', padding: 8, borderRadius: 10, backgroundColor: C.infoSoft }}>
          <Text style={{ flex: 1, minWidth: 160, fontSize: 14, color: C.text }}>{`${offer.name} is not on this supplier's list yet.`}</Text>
          <Btn testID={`${testID}-offer-add`} title="Add to this supplier" size="sm" variant="secondary" onPress={() => { try { I.addItemSupplier(user, offer.uid, supplierUid, {}); ui.toast('Added – it shows under "This supplier" next time'); } catch (e) { ui.error(e); } setOffer(null); }} />
          <Btn testID={`${testID}-offer-no`} title="No" size="sm" variant="ghost" onPress={() => setOffer(null)} />
        </View>
      ) : null}
      {rows.filter((r) => !exclude.includes(r.uid)).slice(0, 8).map((r) => (
        <Pressable key={r.uid} testID={`${testID}-${r.code}`} onPress={async () => {
          onPick(r); setQ('');
          // v3.9.8 a product not on this supplier's list: offered below, without stopping the order (no pop-up)
          setOffer(supplierUid && !I.itemSuppliers(r.uid).some((x) => x.supplier_uid === supplierUid) ? { uid: r.uid, name: r.name } : null);
        }}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 10, borderWidth: 1, borderColor: C.border, backgroundColor: pressed ? C.infoSoft : C.white })}>
          <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: C.text }} numberOfLines={1}>{r.name}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{r.code} · {fq(r.on_hand)} {r.unit || ''} here</Text>
        </Pressable>
      ))}
      {q.trim().length >= 2 && !rows.length ? <Text style={{ fontSize: 14, color: C.sub }}>No product found at {shopCode}. Products come from the Aronium import (Inventory › Import).</Text> : null}
    </View>
  );
}

// A small quantity box with − / + buttons.
export function QtyBox({ value, onChange, testID, step = 1, width = 90 }) {
  const n = Number(value) || 0;
  const btn = (t, d) => (
    <Pressable onPress={() => onChange(String(Math.max(0, Math.round((n + d) * 1000) / 1000)))} style={{ width: 40, height: 44, borderRadius: 10, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', backgroundColor: C.white }}>
      <Text style={{ fontSize: 22, fontWeight: '900', color: C.text }}>{t}</Text>
    </Pressable>
  );
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      {btn('−', -step)}
      <View style={{ width }}>
        <Field testID={testID} value={value === null || value === undefined ? '' : String(value)} onChangeText={(t) => onChange(t.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" placeholder="0" />
      </View>
      {btn('+', step)}
    </View>
  );
}

// v3.9.5 Subtotal (excl. VAT), VAT and Total – the same three lines on every order, delivery and invoice.
export function VatTotals({ split, testID, title }) {
  const m = (n) => I.$(n);
  const row = (label, value, strong, tid) => (
    <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 3 }}>
      <Text style={{ fontSize: strong ? 18 : 16, fontWeight: strong ? '900' : '600', color: strong ? C.text : C.sub }}>{label}</Text>
      <Text testID={tid} style={{ fontSize: strong ? 18 : 16, fontWeight: strong ? '900' : '700', color: C.text, fontVariant: ['tabular-nums'] }}>{value}</Text>
    </View>
  );
  return (
    <View testID={testID} style={{ backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.border, paddingHorizontal: 14, paddingVertical: 8 }}>
      {title ? <Text style={{ fontSize: 13, fontWeight: '800', letterSpacing: 0.6, color: C.sub }}>{title}</Text> : null}
      {row('Subtotal (excl. VAT)', m(split.sub), false, testID ? `${testID}-sub` : undefined)}
      {split.zero > 0.004 ? row('  of which zero rated / VAT free', m(split.zero)) : null}
      {row('VAT', m(split.vat), false, testID ? `${testID}-vat` : undefined)}
      <View style={{ height: 1, backgroundColor: C.border, marginVertical: 2 }} />
      {row('Total (incl. VAT)', m(split.total), true, testID ? `${testID}-total` : undefined)}
    </View>
  );
}
