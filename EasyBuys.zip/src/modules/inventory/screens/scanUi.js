// Scanning products into an order, a delivery or a stock take: camera (continuous) or a handheld scanner
// (it "types" the code and presses Enter into the box), then a big number pad for the quantity.
import React, { useState, useRef } from 'react';
import { View, Pressable, Modal, TextInput } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Btn, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { ContinuousScanner } from '../../../platform/barcodeScan.js';
import { lookupScan } from '../scan.js';
import { fq } from './common.js';

// Big number pad for the quantity after a scan.
export function QtyPad({ visible, title, sub, initial = '', onOk, onCancel }) {
  const [v, setV] = useState(String(initial || ''));
  const key = (k) => {
    if (k === 'back') setV(v.slice(0, -1));
    else if (k === '.') { if (!v.includes('.')) setV(`${v || '0'}.`); } else setV(`${v === '0' ? '' : v}${k}`.slice(0, 8));
  };
  const btn = (k, label) => (
    <Pressable key={k} testID={`qp-${k === '.' ? 'dot' : k}`} onPress={() => key(k)}
      style={({ pressed }) => ({ flexBasis: '30%', flexGrow: 1, height: 64, borderRadius: 14, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', backgroundColor: pressed ? C.infoSoft : C.white })}>
      <Text style={{ fontSize: 30, fontWeight: '900', color: C.text }}>{label || k}</Text>
    </Pressable>
  );
  return (
    <Modal visible={!!visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
        <View testID="qty-pad" style={{ width: '100%', maxWidth: 420, backgroundColor: C.bg || '#F4F1EC', borderRadius: 20, padding: 16, gap: 10 }}>
          <Text style={{ fontSize: 20, fontWeight: '900', color: C.text }} numberOfLines={2}>{title}</Text>
          {sub ? <Text style={{ fontSize: 14, color: C.sub }}>{sub}</Text> : null}
          <View style={{ backgroundColor: C.white, borderRadius: 14, borderWidth: 2, borderColor: C.primary, padding: 10 }}>
            <Text testID="qp-value" style={{ fontSize: 40, fontWeight: '900', color: C.text, textAlign: 'right' }}>{v || '0'}</Text>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {['7', '8', '9', '4', '5', '6', '1', '2', '3', '.', '0'].map((k) => btn(k))}
            {btn('back', '⌫')}
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID="qp-cancel" title="Cancel" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setV(''); onCancel(); }} />
            <Btn testID="qp-ok" title="OK" size="md" variant="success" style={{ flex: 2 }} disabled={!(Number(v) > 0)} onPress={() => { const n = Number(v); setV(''); onOk(n); }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

// lookup(code) → { ok, item, warning?, message } (default: products, with the different-supplier warning).
// onItem(item, qty) is called after the quantity is entered.
export function ScanBar({ supplierUid, shopCode, onItem, lookup, testID = 'scan', hint, startOpen = false, quick = false }) {
  const ui = useUI();
  const [cam, setCam] = useState(startOpen);
  const [code, setCode] = useState('');
  const [pad, setPad] = useState(null);
  const busy = useRef(false);
  const handle = async (raw) => {
    const c = String(raw || '').trim();
    if (!c || busy.current) return;
    busy.current = true;
    setCode('');
    try {
      const r = lookup ? lookup(c) : lookupScan(c, { supplierUid, shopCode });
      if (!r.ok) { await ui.alert({ title: r.notFound ? 'Add it in Aronium first' : 'Cannot add this', message: `${c}\n\n${r.message}`, tone: 'warn' }); return; }
      if (r.warning && !(await ui.confirm({ title: 'Different supplier', message: r.warning, confirmText: 'Add anyway', cancelText: 'Skip it', tone: 'warn' }))) return;
      if (quick) { onItem(r.item, 1); ui.toast(`+1 ${r.item.name}`); return; }
      setPad({ item: r.item, sub: `${r.item.code}${r.onHand !== undefined ? ` · ${fq(r.onHand)} ${r.item.unit || ''} in stock` : ''}${r.note ? ` · ${r.note}` : ''}` });
    } finally { busy.current = false; }
  };
  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
        <Btn testID={`${testID}-cam`} title={cam ? 'Stop the camera' : 'Scan barcodes'} icon="📷" size="md" variant={cam ? 'secondary' : 'info'} style={{ flexGrow: 1 }} onPress={() => setCam(!cam)} />
        <View style={{ flexBasis: 220, flexGrow: 2 }}>
          <TextInput testID={`${testID}-wedge`} value={code} onChangeText={setCode} onSubmitEditing={() => handle(code)} blurOnSubmit={false} autoCorrect={false} autoCapitalize="none"
            placeholder="Handheld scanner or type a barcode, then Enter" placeholderTextColor="#A39886"
            style={{ backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 18, color: C.text, minHeight: 56 }} />
        </View>
        <Btn testID={`${testID}-go`} title="Add" size="md" variant="secondary" onPress={() => handle(code)} />
      </View>
      {cam ? <ContinuousScanner paused={!!pad} onScan={handle} /> : null}
      {hint !== false ? <Hint>{hint || 'Scan one product after another: after each scan type how many. A handheld scanner works too – tap the box first.'}</Hint> : null}
      <QtyPad visible={!!pad} title={pad ? pad.item.name : ''} sub={pad ? pad.sub : ''} onCancel={() => setPad(null)}
        onOk={(n) => { const it = pad.item; setPad(null); onItem(it, n); ui.toast(`${fq(n)} × ${it.name}`); }} />
    </View>
  );
}
