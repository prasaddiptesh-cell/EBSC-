// Inventory, purchase orders and stock takes.
// Every shop has its own stock. Stock is never typed over: it is the total of its movements
// (opening, received, sold, sent to / received from another shop, returned to supplier, written off, counted),
// so every unit can be traced to a person, a date and a reason.
// Sales come from Aronium through the main software (Aronium itself is only read, never written to).
// The main software sends one "sale" movement per product, per shop, per day with the id
//   SL-<shop>-<yyyy-mm-dd>-<product code>   (sending it again replaces it, it never doubles up)
// and products have the id IT-<product code>, so it does not need to know anything else about this app.
import { db, keptAll } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, getShared, setShared, money, weekStart } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { getSupplier, saveInvoice, apRules, getInvoice } from '../payables/service.js';
import { notify } from '../verify/service.js';
import { assertOpen } from '../../services/lock.js';
import { needReason, reasonRequired, requireSetup, can, actsAsOwner } from '../../services/access.js';
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
import { bakeryPart, postBakeryReceipts } from '../bakery/store.js';
import { requirePerm, requireShop, shopOf, asService } from '../../services/guard.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
export const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
export const r6 = (n) => Math.round((Number(n) || 0) * 1000000) / 1000000;
// v3.9.3 Cartons and singles. Stock is always counted in singles (what Aronium sells). An order line can be in cartons:
// qty / unitCost typed per carton, kept per single (qty × pack, cost ÷ pack) so stock, receiving and costs stay in singles.
export const packOf = (l) => ((l && (l.order_as || l.orderAs)) === 'carton' ? Math.max(1, Number(l.pack_size !== undefined && l.pack_size !== null ? l.pack_size : l.packSize) || 1) : 1);
export function cartonLabel(pack, unit) { return pack > 1 ? `ctn of ${q3(pack)}` : unit || 'each'; }
// An order line as the supplier sees it: quantity, unit and price in what was ordered (cartons or singles).
export function orderView(l) {
  const pack = packOf(l);
  return { pack, carton: pack > 1, qty: q3(l.qty / pack), unit: cartonLabel(pack, l.unit), cost: r4(l.unit_cost * pack), received: q3((l.qty_received || 0) / pack) };
}
// Typed line → singles. orderAs 'carton' (with packSize, or the product's pack size) or 'single'.
export function lineToSingles(l, it) {
  const asCarton = (l.orderAs || l.order_as) === 'carton';
  const pack = asCarton ? Math.max(1, Number(l.packSize || l.pack_size) || (it ? Number(it.pack_size) || 1 : 1)) : 1;
  const typedCost = l.unitCost === undefined || l.unitCost === '' || l.unitCost === null ? null : Number(l.unitCost);
  return { orderAs: asCarton && pack > 1 ? 'carton' : 'single', packSize: asCarton && pack > 1 ? pack : 1, qty: q3((Number(l.qty) || 0) * pack),
    unitCost: typedCost === null ? null : pack > 1 ? r6(typedCost / pack) : r4(typedCost) };
}
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";

// ---------------------------------------------------------------- rules (admin)
export const INV_DEFAULTS = {
  costMethod: 'last',          // 'last': cost = the latest price paid; 'average': weighted average of stock on hand and the delivery
  costFlagPct: 0,              // flag a cost change bigger than this % (0 = any change)
  salesDays: 28,               // reorder suggestions look at this many days of sales
  coverDays: 7,                // …and order enough for this many days after the delivery arrives
  defaultLeadDays: 2,          // days from ordering to delivery when the supplier has none set
  deadDays: 60,                // no sale for this many days = dead stock
  budgetMode: 'approve',       // over the supplier budget: 'warn' | 'approve' (needs po_approve) | 'block'
  approveOver: 0,              // any order over this total needs approval (0 = not needed)
  invoiceTolerance: 1,         // $ the supplier invoice may differ from what was received before it is flagged
  priceTolerancePct: 2,        // % a delivered unit cost may differ from the order before it is flagged
  countTolerance: 0,           // stock take: differences up to this many units are accepted without a recount
  countValueTolerance: 5,      // …or up to this many dollars
  blindCount: true,            // counters do not see how many the system expects
  uncounted: 'leave',          // products not counted in a stock take: 'leave' (no change) or 'zero'
  cycleDays: 90,               // rolling counts: suggest products not counted for this many days
  countApproveOver: 200,       // a stock-take loss bigger than this ($) is approved by the owner / admin only
  doubleCountGroups: ['Cigarettes', 'Tobacco', 'Liquor', 'Spirits', 'Beer', 'Wine'], // counted twice, by two people
  // v1.0.0 sales only: these groups are sold and recorded (sales, VAT, reports) but never counted, re-ordered by
  // the app or warned about (no stock kept). Matched on the Aronium group name (part of it is enough).
  noStockGroups: ['Lollies', 'Lolly', 'Sweets', 'Candy'],
  doubleCountCost: 0,          // …and any product costing at least this (0 = off)
  countReasons: ['Counting error', 'Damaged', 'Expired', 'Theft / missing', 'Delivery short', 'Aronium error', 'Found', 'Other'],
  cycleHighValueDays: 7,       // high-value products (counted twice) are due for a count after this many days
  writeOffApproveOver: 50,     // write-offs worth more than this show on the "to check" list
  adjustReasons: ['Damaged', 'Expired', 'Theft / missing', 'Own use / staff', 'Given away / sample', 'Found', 'Counting error', 'Other'],
  units: ['each', 'pack', 'carton', 'kg', 'g', 'litre', 'bottle', 'dozen', 'bag', 'tray'],
};
export function invRules() { return { ...INV_DEFAULTS, ...(getShared('inv_rules', {}) || {}) }; }
export function saveInvRules(user, r) {
  requirePerm(user, 'inventory_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'inventory_setup');
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const clean = {
    costMethod: r.costMethod === 'average' ? 'average' : 'last',
    costFlagPct: n(r.costFlagPct, 0, 100, 'Cost change flag %'),
    salesDays: Math.round(n(r.salesDays, 7, 365, 'Days of sales')),
    coverDays: Math.round(n(r.coverDays, 1, 120, 'Days to cover')),
    defaultLeadDays: Math.round(n(r.defaultLeadDays, 0, 60, 'Delivery days')),
    deadDays: Math.round(n(r.deadDays, 7, 720, 'Dead stock days')),
    budgetMode: ['warn', 'approve', 'block'].includes(r.budgetMode) ? r.budgetMode : 'approve',
    approveOver: r2(n(r.approveOver || 0, 0, 10000000, 'Approve orders over')),
    invoiceTolerance: r2(n(r.invoiceTolerance, 0, 10000, 'Invoice tolerance')),
    priceTolerancePct: n(r.priceTolerancePct, 0, 100, 'Price tolerance %'),
    countTolerance: n(r.countTolerance, 0, 10000, 'Count tolerance'),
    countValueTolerance: r2(n(r.countValueTolerance, 0, 100000, 'Count value tolerance')),
    blindCount: !!r.blindCount,
    uncounted: r.uncounted === 'zero' ? 'zero' : 'leave',
    cycleDays: Math.round(n(r.cycleDays, 7, 720, 'Rolling count days')),
    countApproveOver: r2(n(r.countApproveOver === undefined ? 200 : r.countApproveOver, 0, 10000000, 'Owner approves stock-take losses over')),
    doubleCountGroups: list(r.doubleCountGroups === undefined ? INV_DEFAULTS.doubleCountGroups : r.doubleCountGroups),
    doubleCountCost: r2(n(r.doubleCountCost || 0, 0, 1000000, 'Count twice when the cost is at least')),
    noStockGroups: list(r.noStockGroups === undefined ? INV_DEFAULTS.noStockGroups : r.noStockGroups),
    countReasons: list(r.countReasons === undefined ? INV_DEFAULTS.countReasons : r.countReasons),
    cycleHighValueDays: Math.round(n(r.cycleHighValueDays === undefined ? 7 : r.cycleHighValueDays, 1, 365, 'High-value count days')),
    writeOffApproveOver: r2(n(r.writeOffApproveOver, 0, 1000000, 'Write-off check amount')),
    adjustReasons: list(r.adjustReasons),
    units: list(r.units),
  };
  need(clean.adjustReasons.length, 'Add at least one write-off reason.');
  const before = invRules();
  setShared('inv_rules', clean);
  audit({ user, action: 'Changed inventory rules', table: 'shared_settings', recordUid: 'inv_rules', before, after: clean });
  return clean;
  });
}

export const vatRate = () => Number(apRules().vatRate) || 12.5;
export const incVat = (cost, vatType) => r2(Number(cost || 0) * (vatType === 'zero' || vatType === 'exempt' ? 1 : 1 + vatRate() / 100));
// v3.9.5 subtotal (excl. VAT), VAT and total of a list of lines [{ amount (excl. VAT), vatType }] – the same rounding
// as the order total (VAT line by line). zero = the part that is zero rated / VAT free.
export function vatSplit(lines) {
  let sub = 0; let total = 0; let zero = 0;
  for (const l of lines || []) {
    const a = Number(l.amount) || 0;
    sub += a; total += incVat(a, l.vatType);
    if (l.vatType === 'zero' || l.vatType === 'exempt') zero += a;
  }
  return { sub: r2(sub), vat: r2(total - sub), total: r2(total), zero: r2(zero) };
}
export const itemUidFor = (code) => `IT-${String(code).trim().toUpperCase()}`;
const itemShopUid = (shop, itemUid) => `IS-${shop}-${itemUid}`;

// ---------------------------------------------------------------- products
export function getItem(uid) { return db().get('SELECT * FROM inv_items WHERE uid = ?', [uid]); }
export function findItem(codeOrBarcode) {
  const v = txt(codeOrBarcode);
  if (!v) return null;
  // v3.9.8 any of the product's barcodes (first, middle or last of the list; spaces ignored). A scan with spaces or a
  // scanner's stray characters around it is cleaned first.
  const b = v.replace(/[\s\u0000-\u001f]/g, '');
  if (/[,;]/.test(b)) return null; // two codes at once (a double scan) is not one product
  return db().get(`SELECT * FROM inv_items WHERE upper(code) = upper(?) OR (barcode IS NOT NULL AND ? <> '' AND instr(',' || REPLACE(barcode, ' ', '') || ',', ',' || ? || ',') > 0) ORDER BY active DESC LIMIT 1`,
    [v, b, b]);
}
export function findItemByName(name) {
  const v = txt(name);
  return v ? db().get('SELECT * FROM inv_items WHERE lower(trim(name)) = lower(?) ORDER BY active DESC LIMIT 1', [v]) : null;
}
// A product code for a product that has none in Aronium (SKU empty): the same name always gives the same code.
export function codeFromName(name) {
  const t = txt(name).toLowerCase().replace(/\s+/g, ' ');
  let h = 2166136261;
  for (let i = 0; i < t.length; i += 1) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return `N${h.toString(36).toUpperCase().padStart(7, '0')}`;
}
// Barcodes that Excel has rounded (13-digit numbers turned into e.g. 9416470000000): kept out and listed.
export function damagedBarcodes(rows) {
  const seen = {};
  rows.forEach((r) => (r.barcodes || []).forEach((b) => { (seen[b] = seen[b] || new Set()).add(r.name.toLowerCase()); }));
  const bad = new Set();
  for (const [b, names] of Object.entries(seen)) {
    const rounded = /^\d{11,14}$/.test(b) && /0{5,}$/.test(b);
    if (rounded || (names.size > 1 && /^\d{8,}$/.test(b))) bad.add(b);
  }
  return bad;
}
export function itemAtShop(itemUid, shopCode) {
  const it = getItem(itemUid);
  if (!it) return null;
  const s = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
  return { ...it, shop: s || null, shopPrice: s && s.price !== null && s.price !== undefined ? s.price : it.price, stocked: !!(s && s.active) };
}
export function listGroups() {
  return db().all("SELECT DISTINCT group_name AS g FROM inv_items WHERE group_name IS NOT NULL AND group_name <> '' ORDER BY group_name").map((r) => r.g);
}

// Things worth a second look before saving a product by hand (none of them stop the save).
export function productWarnings(f, uid = null) {
  const out = [];
  const name = txt(f.name);
  const other = name ? db().get('SELECT uid, code FROM inv_items WHERE lower(trim(name)) = lower(?) AND uid <> ?', [name, uid || '']) : null;
  if (other) out.push(`A product called "${name}" already exists (code ${other.code}).`);
  const cost = Number(f.cost) || 0;
  const price = Number(f.price) || 0;
  if (!price) out.push('No selling price yet.');
  else if (cost && price < cost) out.push(`The price (${price}) is below the cost (${cost}).`);
  if (!['standard', 'zero', 'exempt'].includes(f.vatType)) out.push('Choose the VAT type.');
  return out;
}
export function barcodeOwner(barcode, uid = null) {
  for (const b of String(barcode || '').split(/[,;|\s]+/).map((x) => x.trim()).filter(Boolean)) {
    const it = db().get('SELECT uid, name FROM inv_items WHERE uid <> ? AND (barcode = ? OR barcode LIKE ? OR barcode LIKE ? OR barcode LIKE ?)', [uid || '', b, `${b},%`, `%,${b}`, `%,${b},%`]);
    if (it) return { barcode: b, name: it.name, uid: it.uid };
  }
  return null;
}
// Products list for the Products screen. filter: all | app (added in the app, not in Aronium yet) | hidden.
export function listProducts({ q = '', group, filter = 'all', limit = 500 } = {}) {
  const where = [];
  const a = [];
  if (filter === 'app') where.push('aronium_seen IS NULL AND removed_at IS NULL');
  else if (filter === 'hidden') where.push('(active = 0 OR removed_at IS NOT NULL)');
  else where.push('active = 1 AND removed_at IS NULL');
  if (group) { where.push('group_name = ?'); a.push(group); }
  const t = txt(q);
  if (t) { where.push('(name LIKE ? OR code LIKE ? OR barcode LIKE ?)'); a.push(`%${t}%`, `%${t}%`, `%${t}%`); }
  return db().all(`SELECT * FROM inv_items WHERE ${where.join(' AND ')} ORDER BY name COLLATE NOCASE LIMIT ${Number(limit) || 500}`, a);
}
export function setWholesalePrice(user, uid, value) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const v = value === '' || value === null || value === undefined ? null : Math.round(Number(value) * 100) / 100;
  need(v === null || (Number.isFinite(v) && v >= 0), 'Wholesale price must be a number.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_items SET wholesale_price = ?, ${SYNCED} WHERE uid = ?`, [v, now, dev, uid]);
  });
}
export function notInAroniumCount() {
  try { return db().get('SELECT COUNT(*) AS n FROM inv_items WHERE aronium_seen IS NULL AND removed_at IS NULL AND active = 1').n; } catch (e) { return 0; }
}

export function saveItem(user, f) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, f && (f.shopCode || f.shop)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(txt(f.name), 'Enter the product name.');
  // No code typed: one is made from the name (it changes to Aronium's code when the product is imported from Aronium).
  const code = (txt(f.code) || codeFromName(f.name)).toUpperCase();
  const uid = f.uid || itemUidFor(code);
  const dupe = barcodeOwner(f.barcode, uid);
  need(!dupe, `Barcode ${dupe && dupe.barcode} is already on "${dupe && dupe.name}". Each barcode can be on one product only.`);
  const clash = db().get('SELECT uid FROM inv_items WHERE upper(code) = ? AND uid <> ?', [code, uid]);
  need(!clash, `Product code ${code} is already used.`);
  const before = getItem(uid);
  const cost = r4(f.cost);
  const price = r2(f.price);
  need(cost >= 0 && price >= 0, 'Cost and price cannot be negative.');
  const { now, dev } = meta();
  const v = { code, barcode: txt(f.barcode) || null, name: txt(f.name), group_name: txt(f.groupName) || null, unit: txt(f.unit) || 'each', cost, price,
    vat_type: ['standard', 'zero', 'exempt'].includes(f.vatType) ? f.vatType : 'standard', supplier_uid: f.supplierUid || null,
    pack_size: Math.max(1, Number(f.packSize) || 1), active: f.active === false ? 0 : 1, notes: txt(f.notes) || null };
  // v3.9.3 a person chose the VAT here: the Aronium import no longer changes it (a difference is flagged instead).
  if (before && before.vat_type !== v.vat_type && hasVatCols()) db().run(`UPDATE inv_items SET vat_set_at = ?, ${SYNCED} WHERE uid = ?`, [now, now, dev, uid]);
  if (before) {
    db().run(`UPDATE inv_items SET code=?, barcode=?, name=?, group_name=?, unit=?, cost=?, price=?, vat_type=?, supplier_uid=?, pack_size=?, active=?, notes=?, ${SYNCED} WHERE uid = ?`,
      [v.code, v.barcode, v.name, v.group_name, v.unit, v.cost, v.price, v.vat_type, v.supplier_uid, v.pack_size, v.active, v.notes, now, dev, uid]);
    if (Math.abs(before.cost - cost) > 0.00005) logCostChange({ itemUid: uid, oldCost: before.cost, newCost: cost, source: 'edit', supplierName: null, refUid: null, shopCode: null, user });
  } else {
    db().run(`INSERT INTO inv_items (uid, code, barcode, name, group_name, unit, cost, price, vat_type, supplier_uid, pack_size, active, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, v.code, v.barcode, v.name, v.group_name, v.unit, v.cost, v.price, v.vat_type, v.supplier_uid, v.pack_size, v.active, v.notes, now, dev]);
  }
  audit({ user, action: `${before ? 'Changed' : 'Added'} product ${code} ${v.name}`, table: 'inv_items', recordUid: uid,
    before: before && { cost: before.cost, price: before.price, name: before.name }, after: { cost, price, name: v.name } });
  return getItem(uid);
  });
}

// The product at one shop: sold there, reorder level / quantity, the shop's own price, shelf location.
export function saveItemShop(user, { itemUid, shopCode, active = true, reorderLevel, reorderQty, price, location }) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(getItem(itemUid), 'Product not found.');
  need(txt(shopCode), 'Choose the shop.');
  const lvl = Math.max(0, Number(reorderLevel) || 0);
  const qty = Math.max(0, Number(reorderQty) || 0);
  const p = price === '' || price === null || price === undefined ? null : r2(price);
  const { now, dev } = meta();
  const uid = itemShopUid(shopCode, itemUid);
  db().run(`INSERT INTO inv_item_shops (uid, item_uid, shop_code, active, reorder_level, reorder_qty, price, location, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET active=excluded.active, reorder_level=excluded.reorder_level, reorder_qty=excluded.reorder_qty, price=excluded.price, location=excluded.location,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, itemUid, shopCode, active ? 1 : 0, lvl, qty, p, txt(location) || null, now, dev]);
  if (user) audit({ user, action: `Product ${getItem(itemUid).code} at ${shopCode}: reorder at ${lvl}, order ${qty}${p !== null ? `, price ${$(p)}` : ''}`, table: 'inv_item_shops', recordUid: uid });
  return uid;
  });
}
function ensureItemShop(itemUid, shopCode) {
  if (!db().get('SELECT 1 AS x FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode])) asService(() => saveItemShop(null, { itemUid, shopCode })); // the app's own housekeeping
}

// ---------------------------------------------------------------- CSV (Aronium export)
export function parseCsv(text) {
  const src = String(text || '').replace(/^﻿/, '');
  const firstLine = src.split(/\r?\n/)[0] || '';
  const delim = [',', ';', '\t'].map((d) => [d, firstLine.split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i];
    if (q) {
      if (c === '"' && src[i + 1] === '"') { cell += '"'; i += 1; } else if (c === '"') q = false; else cell += c;
    } else if (c === '"') q = true;
    else if (c === delim) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i += 1;
      row.push(cell); cell = '';
      if (row.some((x) => txt(x))) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some((x) => txt(x))) rows.push(row);
  return rows.map((r) => r.map((x) => x.trim()));
}
const num = (v) => {
  const s = txt(v).replace(/[$\s]/g, '');
  if (!s) return null;
  const neg = /^\(.*\)$/.test(s) || /-$/.test(s);
  // "1.234,50" (comma decimals) or "1,234.50"
  // A comma followed by 1-2 digits at the end is a decimal comma ("18,50", "1.234,50"); otherwise commas are thousands.
  const t = /,\d{1,2}$/.test(s) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  const n = Number(t.replace(/[()-]/g, ''));
  return Number.isFinite(n) ? (neg ? -n : n) : null;
};
// "ProductGroup" / "IsEnabled" (Aronium's joined-up names) read as "product group" / "is enabled".
const norm = (h) => txt(h).replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

export const PRODUCT_FIELDS = [
  { key: 'code', label: 'Product code (SKU) – made for you if empty', guess: ['code', 'product code', 'item code', 'sku', 'plu', 'id', 'article', 'article code'] },
  { key: 'name', label: 'Name', need: true, guess: ['name', 'product', 'product name', 'item', 'item name', 'description', 'title'] },
  { key: 'barcode', label: 'Barcode', guess: ['barcode', 'barcodes', 'ean', 'upc', 'bar code'] },
  { key: 'group', label: 'Group', guess: ['group', 'product group', 'category', 'department', 'group name'] },
  { key: 'unit', label: 'Unit', guess: ['unit', 'measurement unit', 'unit of measure', 'uom', 'measure', 'measurement'] },
  { key: 'cost', label: 'Cost price', guess: ['cost', 'cost price', 'purchase price', 'last purchase price', 'buy price', 'unit cost', 'cost price excl tax'] },
  { key: 'price', label: 'Selling price', guess: ['price', 'sale price', 'selling price', 'retail price', 'price incl tax', 'sales price', 'price with tax'] },
  { key: 'wholesale', label: 'Wholesale price', guess: ['wholesale price', 'wholesale', 'price 2', 'price2', 'wholesale price incl tax', 'trade price'] },
  { key: 'tax', label: 'Tax / VAT', guess: ['tax', 'taxes', 'vat', 'tax rate', 'vat rate', 'tax name'] },
  { key: 'qty', label: 'Quantity in stock', guess: ['quantity', 'qty', 'stock', 'in stock', 'stock quantity', 'on hand', 'quantity in stock'] },
  { key: 'supplier', label: 'Supplier', guess: ['supplier', 'vendor', 'default supplier'] },
  { key: 'active', label: 'Active', guess: ['active', 'enabled', 'is enabled', 'status'] },
  { key: 'service', label: 'Service (not stock)', guess: ['is service', 'service'] },
];
export function guessMapping(headers, fields = PRODUCT_FIELDS) {
  const hs = headers.map(norm);
  const map = {};
  for (const f of fields) {
    let i = hs.findIndex((h) => f.guess.includes(h));
    if (i < 0) i = hs.findIndex((h) => f.guess.some((g) => h.startsWith(g)));
    if (i >= 0 && !Object.values(map).includes(i)) map[f.key] = i;
  }
  return map;
}
const vatTypeOf = (v) => {
  const s = txt(v).toLowerCase();
  if (!s) return 'standard';
  if (/none set|no tax set/.test(s)) return 'standard'; // v3.9.7 unknown in Aronium: the app keeps standard VAT and flags it
  if (/zero|^0(\.0+)?%?$|exempt|none|no tax/.test(s)) return /exempt/.test(s) ? 'exempt' : 'zero';
  return 'standard';
};

// Products from an Aronium CSV export into one shop. Run with dryRun first to show what will change.
// openingStock: use the quantity column as this shop's stock (the difference is booked as "opening / import").
// fullList: the file is Aronium's whole product list – products imported before but missing now were deleted in Aronium
// and are hidden (never deleted; they come back if they reappear).
export const splitBarcodes = (v) => [...new Set(String(v || '').split(/[,;|\s]+/).map((x) => x.trim()).filter(Boolean))].join(',');
// 1.0.0 once a shop's opening stock take is approved the app is the master: its selling prices (per shop) and the
// cost prices (from the invoices) are no longer overwritten by Aronium's; differences are shown on "App vs Aronium"
// and go to Aronium through the update file.
export function appIsMaster(shopCode) { const m = getShared('app_master', null) || {}; return !!(shopCode ? m[shopCode] : Object.values(m).some(Boolean)); }
export function setAppMaster(user, shopCode, on = true) {
  requirePerm(user, 'inventory_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const m = { ...(getShared('app_master', null) || {}), [shopCode]: on ? dateStr() : null };
  setShared('app_master', m);
  if (user) audit({ user, action: `${shopCode}: ${on ? 'the app now keeps the selling prices and costs (Aronium is updated from the app)' : 'Aronium\'s prices and costs are taken again'}`, table: 'shared_settings', recordUid: 'app_master' });
  });
}
export function importProductsCsv(user, text, { shopCode, mapping, openingStock = false, setShopPrice: setShopPrice0 = true, dryRun = false, fullList = false } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(shopCode), 'Choose the shop these products are for.');
  const master = appIsMaster(shopCode);
  const costMaster = appIsMaster();
  const setShopPrice = setShopPrice0 && !master;
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no product rows. Export the products from Aronium as CSV and try again.');
  const headers = rows[0];
  const map = mapping || guessMapping(headers);
  need(map.name !== undefined, 'Match the "Name" column first.');
  const get = (r, k) => (map[k] === undefined ? '' : txt(r[map[k]]));
  const out = { headers, mapping: map, total: rows.length - 1, added: 0, changed: 0, same: 0, costChanged: 0, stockSet: 0, errors: [], sample: [], hidden: 0, hiddenNames: [], frozen: [], back: 0,
    blank: 0, services: 0, servicesNames: [], damaged: [], oddCosts: [], madeCodes: 0 };
  const seen = new Set();
  const today = dateStr();
  // Barcodes rounded by Excel (shared by several products or ending in many zeros) are kept out and listed.
  const bad = damagedBarcodes(rows.slice(1).map((r) => ({ name: get(r, 'name'), barcodes: splitBarcodes(get(r, 'barcode')).split(',').filter(Boolean) })));
  for (let n = 1; n < rows.length; n += 1) {
    const r = rows[n];
    const name = get(r, 'name');
    if (!name) { out.blank += 1; continue; }
    if (map.service !== undefined && /^(1|true|yes)$/i.test(get(r, 'service'))) { out.services += 1; if (out.servicesNames.length < 20) out.servicesNames.push(name); continue; }
    const allBarcodes = splitBarcodes(get(r, 'barcode')).split(',').filter(Boolean);
    const goodBarcodes = allBarcodes.filter((b) => !bad.has(b));
    allBarcodes.filter((b) => bad.has(b)).forEach((b) => out.damaged.length < 200 && out.damaged.push({ name, barcode: b }));
    let code = get(r, 'code').toUpperCase();
    let byName = null;
    if (!code) {
      // No SKU in Aronium: a product already here with this name keeps its code; otherwise the first good barcode, or a code made from the name.
      byName = findItemByName(name);
      code = byName ? byName.code.toUpperCase() : (goodBarcodes[0] || codeFromName(name)).toUpperCase();
      out.madeCodes += 1;
    }
    if (seen.has(code)) { out.errors.push(`Row ${n + 1}: code ${code} is in the file twice (first one used)`); continue; }
    seen.add(code);
    const cost = num(get(r, 'cost'));
    const price = num(get(r, 'price'));
    const qty = num(get(r, 'qty'));
    const activeTxt = get(r, 'active').toLowerCase();
    const active = !activeTxt || !/^(0|false|no|inactive|disabled)$/.test(activeTxt);
    const uid = itemUidFor(code);
    // A product added by hand in the app (not from Aronium yet) is linked by its name the first time Aronium has it.
    const before = byName || getItem(uid) || findItem(code) || ((n2) => (n2 && n2.aronium_seen === null ? n2 : null))(findItemByName(name));
    if (price !== null && cost !== null && price > 0 && cost > price * 3) out.oddCosts.push(`${name}: cost ${cost} vs price ${price}`);
    const f = {
      uid: before ? before.uid : uid, code, name, barcode: goodBarcodes.join(',') || (before && before.barcode) || '', groupName: get(r, 'group') || (before && before.group_name) || '',
      unit: get(r, 'unit') || (before && before.unit) || 'each', cost: cost === null || (costMaster && before && before.cost > 0) ? (before ? before.cost : 0) : cost,
      price: price === null || (master && before) ? (before ? before.price : 0) : price, vatType: map.tax !== undefined && !(before && before.vat_set_at) ? vatTypeOf(get(r, 'tax')) : (before ? before.vat_type : map.tax !== undefined ? vatTypeOf(get(r, 'tax')) : 'standard'),
      supplierUid: before ? before.supplier_uid : null, packSize: before ? before.pack_size : 1, active, notes: before ? before.notes : '',
    };
    const wholesale = map.wholesale !== undefined ? num(get(r, 'wholesale')) : before ? before.wholesale_price ?? null : null;
    const changed = !before || (map.wholesale !== undefined && (before.wholesale_price ?? null) !== wholesale) || !!before.removed_at || ['name', 'barcode', 'group_name', 'unit', 'vat_type'].some((k, i) => txt(before[k]) !== txt([f.name, f.barcode, f.groupName, f.unit, f.vatType][i]))
      || Math.abs(before.cost - f.cost) > 0.00005 || Math.abs(before.price - f.price) > 0.004 || !!before.active !== active;
    if (!before) out.added += 1; else if (changed) out.changed += 1; else out.same += 1;
    if (before && before.removed_at) out.back += 1;
    if (before && Math.abs(before.cost - f.cost) > 0.00005) out.costChanged += 1;
    if (out.sample.length < 8) out.sample.push({ code, name, cost: f.cost, price: f.price, qty, isNew: !before });
    if (openingStock && qty !== null) out.stockSet += 1;
    if (dryRun) continue;
    if (changed) saveItemQuiet(f, before);
    db().run('UPDATE inv_items SET wholesale_price = ?, aronium_seen = ?, removed_at = NULL WHERE uid = ?', [wholesale === null ? null : r2(wholesale), today, f.uid]);
    if (map.tax !== undefined && hasVatCols()) { const av = /none set|no tax set/i.test(txt(get(r, 'tax'))) ? 'none' : vatTypeOf(get(r, 'tax')); if ((getItem(f.uid) || {}).aronium_vat !== av) { const m2 = meta(); db().run(`UPDATE inv_items SET aronium_vat = ?, ${SYNCED} WHERE uid = ?`, [av, m2.now, m2.dev, f.uid]); } }
    const itemUid = f.uid;
    const shopRow = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
    if (!shopRow || (setShopPrice && price !== null && Math.abs((shopRow.price ?? -1) - price) > 0.004) || !!shopRow.active !== active) {
      saveItemShop(null, { itemUid, shopCode, active, reorderLevel: shopRow ? shopRow.reorder_level : 0, reorderQty: shopRow ? shopRow.reorder_qty : 0,
        price: setShopPrice && price !== null ? price : shopRow ? shopRow.price : null, location: shopRow ? shopRow.location : null });
    }
    if (openingStock && qty !== null && frozenBy(itemUid, shopCode)) { out.frozen.push(name); continue; }
    // 1.0.0 build 4: a product sold loose from a pack has no stock of its own (the pack's stock is brought in instead)
    let loose = false;
    try { loose = !!require('./looseLinks.js').looseOf(itemUid); } catch (e) { loose = false; }
    if (openingStock && qty !== null && !loose) {
      const have = stockOf(itemUid, shopCode);
      const diff = q3(qty - have);
      if (Math.abs(diff) > 0.0005) addMove({ itemUid, shopCode, date: today, type: 'opening', qty: diff, unitCost: f.cost, refType: 'import', reason: 'Stock from Aronium CSV', user });
    }
  }
  if (fullList) {
    // Imported from Aronium before, not in this full list → deleted in Aronium → hidden here.
    const gone = db().all("SELECT uid, name FROM inv_items WHERE aronium_seen IS NOT NULL AND removed_at IS NULL AND active = 1").filter((it) => !seen.has(getItem(it.uid).code.toUpperCase()));
    out.hidden = gone.length;
    out.hiddenNames = gone.slice(0, 30).map((g) => g.name);
    if (!dryRun) {
      const { now, dev } = meta();
      for (const g of gone) db().run(`UPDATE inv_items SET active = 0, removed_at = ?, ${SYNCED} WHERE uid = ?`, [today, now, dev, g.uid]);
    }
  }
  if (!dryRun) {
    audit({ user, action: `Imported ${out.total} products into ${shopCode}${out.hidden ? ` (${out.hidden} hidden – deleted in Aronium)` : ''} (${out.added} new, ${out.changed} changed${openingStock ? `, stock set for ${out.stockSet}` : ''})`, table: 'inv_items' });
    // v3.9.4 products on the FCCC list are marked controlled by the app (and watched) – a person confirms later
    if (user && user.uid !== 'aronium-link') { try { out.fcccMarked = require('./fccc.js').autoLinkFccc({ force: true }).linked.length; } catch (e) { out.fcccMarked = 0; } }
    // 1.0.0 supplier products from the invoices that were waiting for their product link up now
    if (user && user.uid !== 'aronium-link' && out.added + out.changed) { try { out.supplierLinked = require('./supplierCatalog.js').matchCatalog().linked; } catch (e) { out.supplierLinked = 0; } }
  }
  return out;
  });
}
function saveItemQuiet(f, before) {
  const { now, dev } = meta();
  const v = [f.code, txt(f.barcode) || null, f.name, txt(f.groupName) || null, f.unit, r4(f.cost), r2(f.price), f.vatType, f.supplierUid || null, f.packSize || 1, f.active ? 1 : 0, txt(f.notes) || null];
  if (before) db().run(`UPDATE inv_items SET code=?, barcode=?, name=?, group_name=?, unit=?, cost=?, price=?, vat_type=?, supplier_uid=?, pack_size=?, active=?, notes=?, ${SYNCED} WHERE uid = ?`, v.concat([now, dev, f.uid]));
  else db().run('INSERT INTO inv_items (code, barcode, name, group_name, unit, cost, price, vat_type, supplier_uid, pack_size, active, notes, uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', v.concat([f.uid, now, dev]));
}

export const SALES_FIELDS = [
  { key: 'code', label: 'Product code', need: true, guess: ['code', 'product code', 'item code', 'sku', 'plu', 'id'] },
  { key: 'qty', label: 'Quantity sold', need: true, guess: ['quantity', 'qty', 'sold', 'quantity sold', 'units', 'units sold'] },
  { key: 'date', label: 'Date (if each row has one)', guess: ['date', 'day', 'sale date', 'document date'] },
  { key: 'amount', label: 'Sales amount', guess: ['total', 'amount', 'sales', 'total with tax', 'value', 'total incl tax'] },
];
// Until the main software sends sales by itself: an Aronium "products sold" CSV for one shop and one day.
// Sending the same day again replaces it (it never doubles up).
export function importSalesCsv(user, text, { shopCode, date, mapping, dryRun = false } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no rows.');
  const map = mapping || guessMapping(rows[0], SALES_FIELDS);
  need(map.code !== undefined && map.qty !== undefined, 'Match the "Product code" and "Quantity sold" columns first.');
  need(map.date !== undefined || DATE.test(txt(date)), 'Choose the day these sales are for.');
  const byKey = new Map();
  const out = { headers: rows[0], mapping: map, lines: 0, units: 0, unknown: [], days: new Set() };
  for (let n = 1; n < rows.length; n += 1) {
    const r = rows[n];
    const code = txt(r[map.code]).toUpperCase();
    const qty = num(r[map.qty]);
    if (!code || qty === null) continue;
    const d = map.date !== undefined ? toIsoDate(r[map.date]) || txt(date) : txt(date);
    if (!DATE.test(d)) continue;
    const it = getItem(itemUidFor(code)) || findItem(code);
    if (!it) { if (out.unknown.length < 50) out.unknown.push(code); continue; }
    const k = `${d}|${it.uid}`;
    byKey.set(k, { d, it, qty: q3((byKey.get(k)?.qty || 0) + qty) });
  }
  for (const { d, it, qty } of byKey.values()) {
    out.lines += 1; out.units = q3(out.units + qty); out.days.add(d);
    if (!dryRun) putSale({ shopCode, date: d, itemUid: it.uid, code: it.code, qty, unitCost: it.cost, by: user ? user.name : 'Import' });
  }
  out.days = [...out.days].sort();
  if (!dryRun) audit({ user, action: `Imported sales for ${shopCode} ${out.days.join(', ')}: ${out.lines} products, ${out.units} units`, table: 'inv_moves' });
  return out;
}
function toIsoDate(v) {
  const s = txt(v);
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
}
// One sale line per product, shop and day (the same id as the main software uses).
// signed: qty is sold minus refunded (a negative day puts stock back) – used by the Aronium link.
export function putSale({ shopCode, date, itemUid: itemUid0, code, qty: qty0, unitCost: unitCost0, by, signed = false, reason: reason0 = 'Sales from Aronium' }) {
  assertOpen(date, 'These sales');
  // 1.0.0 sold loose from a pack (Maggi single from the 5 pack): the sale comes off the pack's stock, as its share
  let itemUid = itemUid0; let qty = qty0; let unitCost = unitCost0; let reason = reason0;
  try {
    const lk = require('./looseLinks.js').looseOf(itemUid0);
    if (lk && getItem(lk.parent)) { itemUid = lk.parent; qty = q3(Number(qty0) * lk.factor); unitCost = Number(unitCost0) * lk.per; reason = `${reason0} – sold loose (${code}: ${q3(qty0)} = ${q3(Number(qty0) * lk.factor)} of a pack)`; }
  } catch (e) { /* no links */ }
  const uid = `SL-${shopCode}-${date}-${code}`;
  const { now, dev } = meta();
  const moveQty = signed ? q3(-q3(qty)) : -Math.abs(q3(qty));
  // Sales for a day already covered by a posted stock take arrive late: the count is the truth for that moment,
  // so the change is balanced with a stock-take correction (otherwise it would be taken off twice).
  const old = db().get("SELECT qty FROM inv_moves WHERE uid = ? AND status = 'active'", [uid]);
  const delta = q3(moveQty - (old ? old.qty : 0));
  if (old && Math.abs(delta) < 1e-9) return uid;
  if (Math.abs(delta) > 1e-9) {
    // 1.0.0 build 4: a product nobody counted but set to 0 by the stock take ("not counted = 0") counts too.
    const c = db().get(`SELECT c.uid, c.count_date FROM inv_counts c JOIN inv_count_lines l ON l.count_uid = c.uid AND l.item_uid = ?
        AND (l.counted IS NOT NULL OR c.uncounted = 'zero' OR EXISTS (SELECT 1 FROM inv_moves cm WHERE cm.ref_uid = c.uid AND cm.ref_type = 'count' AND cm.item_uid = l.item_uid AND cm.status = 'active'))
      WHERE c.shop_code = ? AND c.status = 'posted' AND (c.count_date > ? OR (c.count_date = ? AND c.timing = 'after_close')) ORDER BY c.count_date DESC LIMIT 1`, [itemUid, shopCode, date, date]);
    if (c) {
      // 1.0.0 one correction per stock take, product and sales day (the same on every device – several shop phones
      // turn the till's sales into records at the same time, and must never correct twice). It remembers the sales
      // figure the stock take saw ("base") and always equals the change since then.
      const cu = `CL-${c.uid}-${itemUid}-${date}`.slice(0, 120);
      const prev = db().get('SELECT qty, note FROM inv_moves WHERE uid = ?', [cu]);
      const base = prev && prev.note && /^base:/.test(prev.note) ? Number(prev.note.slice(5)) : (old ? old.qty : 0);
      const fix = q3(-(moveQty - base));
      if (prev) {
        db().run(`UPDATE inv_moves SET qty = ?, status = 'active', ${SYNCED} WHERE uid = ?`, [fix, now, dev, cu]);
      } else {
        addMove({ uid: cu, itemUid, shopCode, date: c.count_date, type: 'count', qty: fix, unitCost, refType: 'count_late_sale', refUid: c.uid, reason: `Sales of ${date} came in after the stock take of ${c.count_date}`, note: `base:${base}`, user: null });
      }
    }
  }
  db().run(`INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, ref_type, reason, by_name, status, created_at, updated_at, updated_device)
    VALUES (?,?,?,?, 'sale', ?, ?, 'aronium', ?, ?, 'active', ?, ?, ?)
    ON CONFLICT(uid) DO UPDATE SET item_uid = excluded.item_uid, qty = excluded.qty, unit_cost = excluded.unit_cost, reason = excluded.reason, by_name = excluded.by_name, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, itemUid, shopCode, date, moveQty, r4(unitCost), reason, by || null, now, now, dev]);
  ensureItemShop(itemUid, shopCode);
  return uid;
}

// Numbers that never clash between devices working offline: PO-261008-3K7 (date, number that day, device tag).
export function docNo(prefix, table, col) {
  const d = dateStr().replace(/-/g, '').slice(2);
  const tag = deviceId().replace(/[^A-Za-z0-9]/g, '').slice(-2).toUpperCase();
  const head = `${prefix}-${d}-`;
  const n = db().get(`SELECT COUNT(*) AS n FROM ${table} WHERE ${col} LIKE ?`, [`${head}%`]).n + 1;
  let no = `${head}${n}${tag}`;
  for (let k = n + 1; db().get(`SELECT 1 AS x FROM ${table} WHERE ${col} = ?`, [no]); k += 1) no = `${head}${k}${tag}`;
  return no;
}

// ---------------------------------------------------------------- movements & stock
export const MOVE_LABEL = {
  opening: 'Opening / import', receive: 'Received', sale: 'Sold', adjust: 'Write-off / adjustment', transfer_out: 'Sent to another shop',
  transfer_in: 'Received from another shop', return: 'Returned to supplier', count: 'Stock take', receive_void: 'Delivery voided',
  to_bakery: 'Into the Bakery stock', repack_out: 'Used for packing', repack_in: 'Packed in the shop',
};
const MANUAL = ['adjust', 'transfer_out', 'transfer_in', 'return', 'receive', 'opening'];

export function addMove({ itemUid: itemUid0, shopCode, date, type, qty: qty0, unitCost: unitCost0, refType, refUid, reason: reason0, note, user, uid }) {
  assertOpen(date, 'This stock movement');
  // 1.0.0 build 4: a product sold loose from a pack holds no stock of its own – a delivery, opening stock, write-off,
  // transfer … of it goes onto the pack's stock as its share (never hidden on the loose product, counted in stock value).
  let itemUid = itemUid0; let qty = qty0; let unitCost = unitCost0; let reason = reason0;
  try {
    const lk = require('./looseLinks.js').looseOf(itemUid0);
    const child = lk ? getItem(itemUid0) : null;
    if (lk && getItem(lk.parent)) {
      itemUid = lk.parent; qty = q3(Number(qty0) * lk.factor);
      unitCost = unitCost0 === null || unitCost0 === undefined ? unitCost0 : Number(unitCost0) * lk.per;
      reason = `${reason0 ? `${reason0} – ` : ''}loose ${(child && child.name) || ''}: ${q3(qty0)} = ${q3(Number(qty0) * lk.factor)} of a pack`.replace(/\s+/g, ' ');
    }
  } catch (e) { /* no links */ }
  const { now, dev } = meta();
  const id = uid || uuid('MV');
  db().run(`INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, ref_type, ref_uid, reason, note, by_name, status, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [id, itemUid, shopCode, date, type, q3(qty), unitCost === null || unitCost === undefined ? null : r4(unitCost), refType || null, refUid || null, reason || null, note || null,
    user ? user.name : null, now, now, dev]);
  ensureItemShop(itemUid, shopCode);
  return id;
}
function voidMovesFor(refUid, reason) {
  db().all("SELECT move_date FROM inv_moves WHERE ref_uid = ? AND status = 'active'", [refUid]).forEach((m) => assertOpen(m.move_date, 'This stock movement'));
  const { now, dev } = meta();
  db().run(`UPDATE inv_moves SET status = 'void', void_reason = ?, ${SYNCED} WHERE ref_uid = ? AND status = 'active'`, [reason, now, dev, refUid]);
}

export function stockOf(itemUid, shopCode, asOf) {
  const r = db().get(`SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = ? AND status = 'active' AND (? IS NULL OR move_date <= ?)`,
    [itemUid, shopCode, asOf || null, asOf || null]);
  return q3(r.q);
}
export function onOrder(itemUid, shopCode) {
  const r = db().get(`SELECT COALESCE(SUM(MAX(l.qty - l.qty_received, 0)),0) AS q FROM po_lines l JOIN po_orders o ON o.uid = l.po_uid
    WHERE l.item_uid = ? AND o.shop_code = ? AND o.status IN ('approved','sent','part')`, [itemUid, shopCode]);
  return q3(r.q);
}

// The stock list for one shop. filter: 'all' | 'low' | 'out' | 'negative' | 'dead' | 'order' (needs ordering)
export function stockList({ shopCode, q = '', group, location, supplierUid, filter = 'all', limit = 2000, today = dateStr() } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const rules = invRules();
  const since = addDays(today, -rules.salesDays);
  const w = ['i.active = 1'];
  const a = [];
  if (txt(q)) { const t = `%${txt(q).toLowerCase()}%`; w.push("(lower(i.name) LIKE ? OR lower(i.code) LIKE ? OR ifnull(i.barcode,'') LIKE ?)"); a.push(t, t, t); }
  if (group) { w.push('i.group_name = ?'); a.push(group); }
  if (location) { w.push('s.location = ?'); a.push(location); }
  if (supplierUid) { w.push('i.supplier_uid = ?'); a.push(supplierUid); }
  // 1.0.0 speed: each product's stock, sales and last dates are looked up in the index of its own movements
  // (ix_invm_itype) instead of adding up every movement of the shop (3 years: 370 000 rows) for every list.
  // "(s.active = 1 OR st.q <> 0)" and the LIMIT are applied below, after the same ORDER BY.
  // the same list is asked for by many parts of Home (low stock, order suggestions, the board …): kept until one of
  // its tables changes (db/connection.js keptAll)
  const rows0 = keptAll(`
    SELECT i.*, s.reorder_level, s.reorder_qty, s.location, COALESCE(s.price, i.price) AS shop_price, s.active AS shop_active,
      COALESCE((SELECT SUM(m.qty) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.status = 'active'), 0) AS on_hand,
      COALESCE((SELECT -SUM(m.qty) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.type = 'sale' AND m.move_date > ? AND m.move_date <= ? AND m.status = 'active'), 0) AS sold,
      (SELECT MAX(m.move_date) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.type = 'sale' AND m.status = 'active' AND m.qty < 0) AS last_sale,
      (SELECT MAX(m.move_date) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.type IN ('receive','transfer_in','opening') AND m.status = 'active') AS last_received,
      COALESCE(oo.q,0) AS on_order, lc.d AS last_counted,
      sup.name AS supplier_name, COALESCE(sup.lead_days, ?) AS lead_days
    FROM inv_items i
    JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ?
    LEFT JOIN (SELECT l.item_uid, SUM(MAX(l.qty - l.qty_received, 0)) AS q FROM po_lines l JOIN po_orders o ON o.uid = l.po_uid WHERE o.shop_code = ? AND o.status IN ('approved','sent','part') GROUP BY l.item_uid) oo ON oo.item_uid = i.uid
    LEFT JOIN (SELECT cl.item_uid, MAX(c.count_date) AS d FROM inv_count_lines cl JOIN inv_counts c ON c.uid = cl.count_uid WHERE c.shop_code = ? AND c.status = 'posted' AND cl.counted IS NOT NULL GROUP BY cl.item_uid) lc ON lc.item_uid = i.uid
    LEFT JOIN ap_suppliers sup ON sup.uid = i.supplier_uid
    WHERE ${w.join(' AND ')}
    ORDER BY i.name`,
  [shopCode, shopCode, since, today, shopCode, shopCode, rules.defaultLeadDays, shopCode, shopCode, shopCode].concat(a));
  const rows = rows0.filter((r) => r.shop_active === 1 || r.on_hand !== 0).slice(0, limit);
  const out = rows.map((r) => decorateStock(r, rules, today)).map((r) => (salesOnly(r, rules) ? { ...r, salesOnly: true, low: false, dead: false, suggest: 0 } : r));
  if (filter === 'low') return out.filter((r) => r.low);
  if (filter === 'out') return out.filter((r) => r.on_hand <= 0 && !r.salesOnly);
  if (filter === 'negative') return out.filter((r) => r.on_hand < 0 && !r.salesOnly);
  if (filter === 'dead') return out.filter((r) => r.dead);
  if (filter === 'order') return out.filter((r) => r.suggest > 0);
  return out;
}
function decorateStock(r, rules, today) {
  const perDay = r.sold > 0 ? r.sold / rules.salesDays : 0;
  const lead = Number(r.lead_days) || 0;
  const want = perDay * (lead + rules.coverDays);
  const have = r.on_hand + r.on_order;
  let suggest = 0;
  if (have <= r.reorder_level || have < want) {
    suggest = Math.max(r.reorder_qty || 0, want + r.reorder_level - have);
    const pack = Math.max(1, Number(r.pack_size) || 1);
    suggest = suggest > 0 ? Math.ceil(suggest / pack - 1e-9) * pack : 0;
  }
  const daysLeft = perDay > 0 ? Math.floor(Math.max(0, r.on_hand) / perDay) : null;
  const refDate = r.last_sale || r.last_received;
  const idle = refDate ? Math.round((new Date(`${today}T00:00:00`) - new Date(`${refDate}T00:00:00`)) / 86400000) : null;
  const margin = r.shop_price > 0 ? r2(((r.shop_price - incVat(r.cost, r.vat_type)) / r.shop_price) * 100) : null;
  return {
    ...r, on_hand: q3(r.on_hand), on_order: q3(r.on_order), sold: q3(r.sold), perWeek: r2(perDay * 7), daysLeft, value: r2(Math.max(0, r.on_hand) * r.cost),
    low: r.on_hand <= r.reorder_level && (r.reorder_level > 0 || r.on_hand <= 0), suggest: q3(suggest), margin, belowCost: r.shop_price > 0 && incVat(r.cost, r.vat_type) >= r.shop_price,
    dead: r.on_hand > 0 && !r.sold && (idle === null || idle >= rules.deadDays), idleDays: idle,
  };
}

export function movesFor({ itemUid, shopCode, from, to, types, includeVoid = false, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (itemUid) { w.push('m.item_uid = ?'); a.push(itemUid); }
  if (shopCode) { w.push('m.shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('m.move_date >= ?'); a.push(from); }
  if (to) { w.push('m.move_date <= ?'); a.push(to); }
  if (types && types.length) { w.push(`m.type IN (${types.map(() => '?').join(',')})`); a.push(...types); }
  if (!includeVoid) w.push("m.status = 'active'");
  // 1.0.0 movements of the same day and time always in the same order (as before on the 3-year data, whatever index
  // SQLite picks now): one product in a shop newest saved first; otherwise by shop, kind, then as saved
  const ties = itemUid && shopCode ? 'm.rowid DESC' : itemUid ? 'm.shop_code, m.rowid' : shopCode ? 'm.type, m.rowid' : from || to ? 'm.shop_code, m.type, m.rowid' : 'm.rowid';
  return db().all(`SELECT m.*, i.code, i.name, i.unit FROM inv_moves m LEFT JOIN inv_items i ON i.uid = m.item_uid WHERE ${w.join(' AND ')}
    ORDER BY m.move_date DESC, m.created_at DESC, ${ties} LIMIT ?`, a.concat([limit]));
}

// ---------------------------------------------------------------- frozen during a stock take
export function openCounts(shopCode) {
  return db().all("SELECT * FROM inv_counts WHERE shop_code = ? AND status IN ('counting','review')", [shopCode]);
}
function inScope(count, item, location) {
  const s = J(count.scope, {});
  if (s.groups && s.groups.length && !s.groups.includes(item.group_name)) return false;
  if (s.locations && s.locations.length && !s.locations.includes(location)) return false;
  if (s.itemUids && s.itemUids.length && !s.itemUids.includes(item.uid)) return false;
  return true;
}
export function frozenBy(itemUid, shopCode) {
  const counts = openCounts(shopCode);
  if (!counts.length) return null;
  const it = getItem(itemUid);
  const loc = db().get('SELECT location FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
  return counts.find((c) => {
    if (db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [c.uid, itemUid])) return true;
    return it && inScope(c, it, loc && loc.location);
  }) || null;
}
export function notFrozen(itemUid, shopCode) {
  const c = frozenBy(itemUid, shopCode);
  if (c) {
    const it = getItem(itemUid);
    throw new AppError(`${it ? it.name : 'This product'} is frozen at ${shopCode}: stock take "${c.name || c.count_date}" is under way. Post or cancel the stock take first.`);
  }
}

// ---------------------------------------------------------------- write-offs / adjustments
// qty is the change: negative takes stock off (damaged, expired…), positive adds (found).
export function adjustStock(user, { itemUid, shopCode, qty, reason, note, date, photos = [] }) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const it = getItem(itemUid);
  need(it, 'Choose the product.');
  need(txt(shopCode), 'Choose the shop.');
  const q = q3(qty);
  need(q !== 0, 'Enter how many (minus to take off, plus to add).');
  need(txt(reason), 'Choose the reason.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'The date cannot be in the future.');
  if (txt(reason) === 'Other') needReason(user, note, 'Say what happened.');
  notFrozen(itemUid, shopCode);
  const uid = addMove({ itemUid, shopCode, date: d, type: 'adjust', qty: q, unitCost: it.cost, refType: 'adjust', reason: txt(reason), note: txt(note), user });
  if (photos.length) addPhotos('inv_move', uid, photos);
  if (q < 0 && Math.abs(q) * it.cost > invRules().writeOffApproveOver) notify('big_writeoff', `Write-off: ${fmtQ(-q)} × ${it.name} = ${$(Math.abs(q) * it.cost)} (${txt(reason)}${txt(note) ? ` – ${txt(note)}` : ''}) by ${user.name}.`, { shopCode });
  audit({ user, action: `Stock ${q > 0 ? '+' : ''}${q} ${it.unit || ''} ${it.code} ${it.name} at ${shopCode} (${txt(reason)}) ${$(Math.abs(q) * it.cost)}`.replace(/\s+/g, ' '),
    table: 'inv_moves', recordUid: uid, reason: txt(note) || txt(reason) });
  return uid;
  });
}
export function voidMove(user, uid, reason) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const m = db().get('SELECT * FROM inv_moves WHERE uid = ?', [uid]);
  need(m && m.status === 'active', 'Movement not found or already voided.');
  need(m.type === 'adjust' || m.type === 'opening', 'Only write-offs and opening stock can be voided here. Deliveries, transfers and stock takes are voided from their own screen.');
  needReason(user, reason, 'Say why it is being voided.');
  notFrozen(m.item_uid, m.shop_code);
  const { now, dev } = meta();
  assertOpen(m.move_date, 'This stock movement');
  db().run(`UPDATE inv_moves SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Voided stock movement ${m.type} ${m.qty}`, table: 'inv_moves', recordUid: uid, reason: txt(reason) });
  });
}

// ---------------------------------------------------------------- transfers between shops (2 steps)
export function sendTransfer(user, { fromShop, toShop, date, lines, notes }) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(fromShop) && txt(toShop), 'Choose both shops.');
  need(fromShop !== toShop, 'Choose two different shops.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  const clean = (lines || []).map((l) => ({ itemUid: l.itemUid, qty: q3(l.qty) })).filter((l) => l.qty > 0);
  need(clean.length, 'Add at least one product.');
  const uid = uuid('TR');
  const no = docNo('TR', 'inv_transfers', 'transfer_no');
  let value = 0;
  const out = clean.map((l) => {
    const it = getItem(l.itemUid);
    need(it, 'A product on the list was not found.');
    notFrozen(l.itemUid, fromShop);
    notFrozen(l.itemUid, toShop);
    value += l.qty * it.cost;
    return { itemUid: it.uid, code: it.code, name: it.name, unit: it.unit, qty: l.qty, unitCost: it.cost, qtyReceived: null };
  });
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_transfers (uid, transfer_no, from_shop, to_shop, send_date, lines, value, status, sent_by_name, sent_at, notes, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?, 'sent', ?,?,?,?,?)`, [uid, no, fromShop, toShop, d, JSON.stringify(out), r2(value), user.name, now, txt(notes) || null, now, dev]);
  for (const l of out) addMove({ itemUid: l.itemUid, shopCode: fromShop, date: d, type: 'transfer_out', qty: -l.qty, unitCost: l.unitCost, refType: 'transfer', refUid: uid, reason: `${no} to ${toShop}`, user });
  audit({ user, action: `Sent ${no} ${fromShop} → ${toShop}: ${out.length} products ${$(value)}`, table: 'inv_transfers', recordUid: uid });
  return getTransfer(uid);
  });
}
export function getTransfer(uid) {
  const t = db().get('SELECT * FROM inv_transfers WHERE uid = ?', [uid]);
  return t && { ...t, lines: J(t.lines, []) };
}
export function listTransfers({ shopCode, status, limit = 200 } = {}) {
  return db().all(`SELECT * FROM inv_transfers WHERE (? IS NULL OR from_shop = ? OR to_shop = ?) AND (? IS NULL OR status = ?) ORDER BY send_date DESC, sent_at DESC LIMIT ?`,
    [shopCode || null, shopCode || null, shopCode || null, status || null, status || null, limit]).map((t) => ({ ...t, lines: J(t.lines, []) }));
}
// Step 2: the other shop checks what actually arrived. received: { itemUid: qty } (missing = all arrived)
export function receiveTransfer(user, uid, { received = {}, date, note } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const t = getTransfer(uid);
  need(t && t.status === 'sent', 'This transfer is not waiting to be received.');
  const d = txt(date) || dateStr();
  need(d >= t.send_date, 'It cannot arrive before it was sent.');
  let short = 0;
  const lines = t.lines.map((l) => {
    const got = received[l.itemUid] === undefined || received[l.itemUid] === '' ? l.qty : q3(received[l.itemUid]);
    need(got >= 0, 'Quantities cannot be negative.');
    if (got < l.qty) short += (l.qty - got) * l.unitCost;
    return { ...l, qtyReceived: got };
  });
  if (short > 0.004) needReason(user, note, 'Some products did not arrive. Say what happened.');
  for (const l of lines) notFrozen(l.itemUid, t.to_shop);
  const { now, dev } = meta();
  for (const l of lines) if (l.qtyReceived > 0) addMove({ itemUid: l.itemUid, shopCode: t.to_shop, date: d, type: 'transfer_in', qty: l.qtyReceived, unitCost: l.unitCost, refType: 'transfer', refUid: uid, reason: `${t.transfer_no} from ${t.from_shop}`, user });
  db().run(`UPDATE inv_transfers SET status = 'received', lines = ?, received_by_name = ?, received_at = ?, receive_date = ?, short_value = ?, notes = ?, ${SYNCED} WHERE uid = ?`,
    [JSON.stringify(lines), user.name, now, d, r2(short), [t.notes, txt(note)].filter(Boolean).join(' / ') || null, now, dev, uid]);
  audit({ user, action: `Received ${t.transfer_no} at ${t.to_shop}${short > 0.004 ? `, short ${$(short)}` : ''}`, table: 'inv_transfers', recordUid: uid, reason: txt(note) || null });
  return getTransfer(uid);
  });
}
export function voidTransfer(user, uid, reason) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const t = getTransfer(uid);
  need(t && t.status === 'sent', 'Only a transfer that has not been received can be cancelled.');
  needReason(user, reason, 'Say why.');
  for (const l of t.lines) notFrozen(l.itemUid, t.from_shop);
  voidMovesFor(uid, txt(reason));
  const { now, dev } = meta();
  db().run(`UPDATE inv_transfers SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled transfer ${t.transfer_no}`, table: 'inv_transfers', recordUid: uid, reason: txt(reason) });
  });
}

// ---------------------------------------------------------------- supplier budgets
export function saveSupplierOrdering(user, { supplierUid, budgetWeekly, budgetMonthly, leadDays, viber, orderDays, viberGroup }) {
  requirePerm(user, 'po_create'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const s = getSupplier(supplierUid);
  need(s, 'Supplier not found.');
  const bw = budgetWeekly === '' || budgetWeekly === null || budgetWeekly === undefined ? null : r2(budgetWeekly);
  const bm = budgetMonthly === '' || budgetMonthly === null || budgetMonthly === undefined ? null : r2(budgetMonthly);
  need((bw === null || bw >= 0) && (bm === null || bm >= 0), 'Budgets cannot be negative.');
  const ld = leadDays === '' || leadDays === null || leadDays === undefined ? null : Math.max(0, Math.round(Number(leadDays) || 0));
  const days = Array.isArray(orderDays) ? orderDays.join(',') : txt(orderDays) || null;
  const { now, dev } = meta();
  db().run(`UPDATE ap_suppliers SET budget_weekly = ?, budget_monthly = ?, lead_days = ?, viber = ?, order_days = ?, ${SYNCED} WHERE uid = ?`,
    [bw, bm, ld, txt(viber) || null, days, now, dev, supplierUid]);
  // v3.9.8 the supplier's own Viber group (orders are sent there).
  if (viberGroup !== undefined) { try { db().run('UPDATE ap_suppliers SET viber_group = ? WHERE uid = ?', [txt(viberGroup) || null, supplierUid]); } catch (e) { /* older database */ } }
  audit({ user, action: `Ordering for ${s.name}: weekly budget ${bw === null ? '—' : $(bw)}, monthly ${bm === null ? '—' : $(bm)}, delivery ${ld === null ? '—' : `${ld} days`}`,
    table: 'ap_suppliers', recordUid: supplierUid, before: { bw: s.budget_weekly, bm: s.budget_monthly }, after: { bw, bm } });
  return getSupplier(supplierUid);
  });
}
const monthStart = (d) => `${d.slice(0, 7)}-01`;
const monthEnd = (d) => addDays(`${addMonth(d.slice(0, 7))}-01`, -1);
function addMonth(ym) { const [y, m] = ym.split('-').map(Number); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; }

// Spent / committed with a supplier in the week (Sat–Fri) and month of `date`:
// approved orders (received or not) + their invoices that did not come through an order. Draft and cancelled orders do not count.
export function budgetUse(supplierUid, date = dateStr(), { exceptPo } = {}) {
  const s = getSupplier(supplierUid);
  const ws = weekStart(date);
  const we = addDays(ws, 6);
  const ms = monthStart(date);
  const me = monthEnd(date);
  const spent = (from, to) => {
    const po = db().get(`SELECT COALESCE(SUM(total),0) AS t FROM po_orders WHERE supplier_uid = ? AND status IN ('approved','sent','part','received','closed') AND order_date BETWEEN ? AND ? AND uid <> ?`,
      [supplierUid, from, to, exceptPo || '']).t;
    const inv = db().get(`SELECT COALESCE(SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END),0) AS t FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND po_uid IS NULL AND invoice_date BETWEEN ? AND ?`,
      [supplierUid, from, to]).t;
    return r2(po + inv);
  };
  const week = spent(ws, we);
  const month = spent(ms, me);
  return {
    supplier: s, weekStart: ws, weekEnd: we, monthStart: ms, monthEnd: me, week, month,
    weekBudget: s && s.budget_weekly !== null && s.budget_weekly !== undefined ? s.budget_weekly : null,
    monthBudget: s && s.budget_monthly !== null && s.budget_monthly !== undefined ? s.budget_monthly : null,
    weekLeft: s && s.budget_weekly !== null && s.budget_weekly !== undefined ? r2(s.budget_weekly - week) : null,
    monthLeft: s && s.budget_monthly !== null && s.budget_monthly !== undefined ? r2(s.budget_monthly - month) : null,
  };
}
export function budgetCheck(supplierUid, total, date = dateStr(), exceptPo) {
  const b = budgetUse(supplierUid, date, { exceptPo });
  const over = [];
  if (b.weekLeft !== null && total > b.weekLeft + 0.004) over.push(`week: ${$(b.weekBudget)} budget, ${$(b.week)} already, this order ${$(total)} → over by ${$(total - b.weekLeft)}`);
  if (b.monthLeft !== null && total > b.monthLeft + 0.004) over.push(`month: ${$(b.monthBudget)} budget, ${$(b.month)} already, this order ${$(total)} → over by ${$(total - b.monthLeft)}`);
  return { ...b, over, isOver: over.length > 0 };
}

// ---------------------------------------------------------------- purchase orders
export const PO_STATUS = { draft: 'Draft', awaiting: 'Waiting for approval', approved: 'Approved – not sent', sent: 'Sent to supplier', part: 'Part received', received: 'Received', closed: 'Closed (short)', cancelled: 'Cancelled' };

export function getPO(uid) {
  const o = db().get('SELECT * FROM po_orders WHERE uid = ?', [uid]);
  if (!o) return null;
  const lines = db().all('SELECT * FROM po_lines WHERE po_uid = ? ORDER BY sort, name', [uid]);
  const receipts = db().all("SELECT * FROM inv_receipts WHERE po_uid = ? ORDER BY receive_date, created_at", [uid]).map((r) => ({ ...r, lines: J(r.lines, []) }));
  const invoices = db().all("SELECT uid, invoice_no, invoice_date, total, status FROM ap_invoices WHERE po_uid = ? AND status <> 'void'", [uid]);
  const ordered = lines.reduce((s, l) => s + l.qty, 0);
  const got = lines.reduce((s, l) => s + Math.min(l.qty, l.qty_received), 0);
  return { ...o, lines, receipts, invoices, receivedPct: ordered > 0 ? Math.round((got / ordered) * 100) : 0,
    receivedValue: r2(receipts.filter((r) => r.status === 'active').reduce((s, r) => s + r.total, 0)), invoiced: r2(invoices.reduce((s, i) => s + i.total, 0)) };
}
export function listPOs({ shopCode, supplierUid, status, from, to, q = '', limit = 300 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (supplierUid) { w.push('supplier_uid = ?'); a.push(supplierUid); }
  if (status === 'open') w.push("status IN ('draft','awaiting','approved','sent','part')");
  else if (status === 'to_receive') w.push("status IN ('approved','sent','part')");
  else if (status) { w.push('status = ?'); a.push(status); }
  if (from) { w.push('order_date >= ?'); a.push(from); }
  if (to) { w.push('order_date <= ?'); a.push(to); }
  if (txt(q)) { w.push('(lower(po_no) LIKE ? OR lower(supplier_name) LIKE ?)'); a.push(`%${txt(q).toLowerCase()}%`, `%${txt(q).toLowerCase()}%`); }
  return db().all(`SELECT * FROM po_orders WHERE ${w.join(' AND ')} ORDER BY order_date DESC, created_at DESC LIMIT ?`, a.concat([limit]));
}

// Save a draft order (new or changed). lines: [{itemUid?, code?, name?, unit?, qty, unitCost}]
export function savePO(user, f) {
  requirePerm(user, ['po_create', 'role:supervisor']); // 1.0.0 hardening (H1): checked inside the service
  if (!approverShops(user).includes(f && (f.shopCode || f.shop))) requireShop(user, f && (f.shopCode || f.shop)); // 1.0.0 hardening (H1): own shop (or one the owner gave them)
  return asService(() => {
  const before = f.uid ? getPO(f.uid) : null;
  // Fully editable until it is sent to the supplier. A changed order goes back to draft and is approved again.
  need(!before || ['draft', 'awaiting', 'approved'].includes(before.status), 'This order has already been sent to the supplier. Cancel it and make a new one, or phone the supplier.');
  const s = getSupplier(f.supplierUid);
  need(s, 'Choose the supplier.');
  need(txt(f.shopCode), 'Choose the shop the order is for.');
  const date = txt(f.orderDate) || dateStr();
  need(DATE.test(date), 'Enter the order date.');
  const lines = (f.lines || []).map((l, i) => {
    const it = l.itemUid ? getItem(l.itemUid) : null;
    const name = it ? it.name : txt(l.name);
    const sg = lineToSingles(l, it);
    const qty = sg.qty;
    const cost = sg.unitCost === null ? r4(it ? it.cost : 0) : sg.unitCost;
    return { itemUid: it ? it.uid : null, code: it ? it.code : txt(l.code) || null, name, unit: it ? it.unit : txt(l.unit) || 'each', qty, unitCost: cost, note: txt(l.note) || null, sort: i, orderAs: sg.orderAs, packSize: sg.packSize };
  }).filter((l) => l.name && l.qty > 0);
  need(lines.length, 'Add at least one product with a quantity.');
  need(lines.every((l) => l.unitCost >= 0), 'Costs cannot be negative.');
  const total = r2(lines.reduce((t, l) => t + incVat(l.qty * l.unitCost, l.itemUid ? getItem(l.itemUid).vat_type : (s.vat_registered ? 'standard' : 'zero')), 0));
  const { now, dev } = meta();
  const uid = before ? before.uid : uuid('PO');
  const poNo = before ? before.po_no : docNo('PO', 'po_orders', 'po_no');
  if (before) {
    db().run(`UPDATE po_orders SET supplier_uid=?, supplier_name=?, shop_code=?, order_date=?, expected_date=?, status='draft', total=?, notes=?, budget_note=NULL, approved_by_name=NULL, approved_at=NULL, signature=NULL, signed_by_name=NULL, signed_by_uid=NULL, signed_at=NULL, ${SYNCED} WHERE uid = ?`,
      [s.uid, s.name, f.shopCode, date, txt(f.expectedDate) || null, total, txt(f.notes) || null, now, dev, uid]);
    // Lines of a draft are replaced (a draft has nothing received against it).
    const old = db().all('SELECT uid FROM po_lines WHERE po_uid = ?', [uid]);
    old.forEach((l, i) => {
      const n = lines[i];
      if (n) db().run(`UPDATE po_lines SET item_uid=?, code=?, name=?, unit=?, qty=?, unit_cost=?, note=?, sort=?, order_as=?, pack_size=?, ${SYNCED} WHERE uid = ?`, [n.itemUid, n.code, n.name, n.unit, n.qty, n.unitCost, n.note, n.sort, n.orderAs || 'single', n.packSize || 1, now, dev, l.uid]);
      else db().run(`UPDATE po_lines SET qty = 0, ${SYNCED} WHERE uid = ?`, [now, dev, l.uid]);
    });
    lines.slice(old.length).forEach((n) => insertLine(uid, n, now, dev));
  } else {
    db().run(`INSERT INTO po_orders (uid, po_no, supplier_uid, supplier_name, shop_code, order_date, expected_date, status, total, notes, created_by_name, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?, 'draft', ?,?,?,?,?,?)`,
    [uid, poNo, s.uid, s.name, f.shopCode, date, txt(f.expectedDate) || addDays(date, s.lead_days === null || s.lead_days === undefined ? invRules().defaultLeadDays : s.lead_days),
      total, txt(f.notes) || null, user.name, now, now, dev]);
    lines.forEach((n) => insertLine(uid, n, now, dev));
  }
  audit({ user, action: `${before ? 'Changed' : 'Made'} order ${poNo} ${s.name} ${f.shopCode} ${$(total)}`, table: 'po_orders', recordUid: uid });
  return getPO(uid);
  });
}
function insertLine(poUid, n, now, dev) {
  db().run(`INSERT INTO po_lines (uid, po_uid, item_uid, code, name, unit, qty, unit_cost, qty_received, note, sort, order_as, pack_size, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?,?,?)`,
    [uuid('PL'), poUid, n.itemUid, n.code, n.name, n.unit, n.qty, n.unitCost, n.note, n.sort, n.orderAs || 'single', n.packSize || 1, now, dev]);
}

// Draft → approved (or waiting for approval when over budget / over the limit).
// canApprove: the user has po_approve. reason: why it is OK to go over the budget.
// v3.9.8 who may approve an order: the owner / admin; a manager (or anyone with "approve orders") for their own shop
// only, unless the owner gave them more shops (Orders › Who approves).
export function approverShops(user) {
  if (!user) return [];
  const m = (getShared('po_approver_shops', {}) || {})[user.uid];
  return Array.from(new Set([user.shop_code].concat(Array.isArray(m) ? m : []).filter(Boolean)));
}
export function mayApprovePO(user, shopCode) {
  if (!user) return false;
  if (actsAsOwner(user) || ['owner', 'admin'].includes(user.role)) return true;
  if (!(can(user, 'po_approve') || user.role === 'manager')) return false;
  return approverShops(user).includes(shopCode);
}
export function setApproverShops(user, userUid, shops) {
  requirePerm(user, 'inventory_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(actsAsOwner(user) || ['owner', 'admin'].includes(user.role), 'Only the owner or admin can say who approves orders for which shop.');
  const u = db().get('SELECT uid, name FROM users WHERE uid = ?', [userUid]);
  need(u, 'Person not found.');
  const valid = new Set(db().all('SELECT code FROM shops').map((s) => s.code));
  const list = Array.from(new Set((shops || []).map((x) => txt(x).toUpperCase()).filter((x) => valid.has(x))));
  const m = { ...(getShared('po_approver_shops', {}) || {}) };
  if (list.length) m[userUid] = list; else delete m[userUid];
  setShared('po_approver_shops', m);
  audit({ user, action: `${u.name} approves orders for: ${list.length ? list.join(', ') : 'own shop only'}`, table: 'shared_settings' });
  return list;
  });
}
export function submitPO(user, uid, { canApprove = false, reason } = {}) {
  requirePerm(user, ['po_create', 'role:supervisor']); // 1.0.0 hardening (H1): checked inside the service
  if (!approverShops(user).includes(shopOf('po_orders', uid))) requireShop(user, shopOf('po_orders', uid)); // 1.0.0 hardening (H1): own shop (or one the owner gave them)
  return asService(() => {
  const o = getPO(uid);
  need(o && ['draft', 'awaiting'].includes(o.status), 'This order is not a draft.');
  // v3.9.8 approving needs the right for that shop; without it the order waits for an approver.
  if (canApprove && !mayApprovePO(user, o.shop_code)) {
    need(o.status !== 'awaiting', `Only the admin or a manager for ${o.shop_code} can approve this order.`);
    canApprove = false;
  }
  need(o.lines.some((l) => l.qty > 0), 'The order has no products.');
  const rules = invRules();
  const b = budgetCheck(o.supplier_uid, o.total, o.order_date, uid);
  const overLimit = rules.approveOver > 0 && o.total > rules.approveOver;
  const notes = [];
  if (b.isOver) notes.push(`Over budget (${b.over.join('; ')})`);
  if (overLimit) notes.push(`Over the ${$(rules.approveOver)} limit`);
  if (b.isOver && rules.budgetMode === 'block') throw new AppError(`This order is over the ${o.supplier_name} budget: ${b.over.join('; ')}. Make it smaller or ask the admin to raise the budget.`);
  // v3.9.5 an order raised by a supervisor or manager (not the owner / admin, and without "approve orders") always
  // waits for the owner or admin to authorise it; the order then shows who raised it and who authorised it.
  const ownerAdmin = mayApprovePO(user, o.shop_code);
  const raisedByStaff = !ownerAdmin && rules.staffOrdersNeedApproval !== false;
  if (raisedByStaff && !notes.length) notes.push(`Raised by ${user.name} – to be authorised by the owner or admin`);
  const needsApproval = (b.isOver && rules.budgetMode === 'approve') || overLimit || raisedByStaff;
  const { now, dev } = meta();
  if (needsApproval && !canApprove) {
    db().run(`UPDATE po_orders SET status = 'awaiting', budget_note = ?, ${SYNCED} WHERE uid = ?`, [notes.join('. '), now, dev, uid]);
    audit({ user, action: `Order ${o.po_no} needs approval: ${notes.join('. ')}`, table: 'po_orders', recordUid: uid });
    notify('po_approval', `Purchase order ${o.po_no} to ${o.supplier_name} (${$(o.total)}) needs approval. ${notes.join('. ')}. Made by ${user.name}.`, { shopCode: o.shop_code });
    return getPO(uid);
  }
  if (needsApproval && b.isOver) needReason(user, reason, 'This order is over budget. Say why it is OK.');
  const note = notes.length ? `${notes.join('. ')}${txt(reason) ? ` – OK because: ${txt(reason)}` : ''}` : null;
  db().run(`UPDATE po_orders SET status = 'approved', approved_by_name = ?, approved_at = ?, budget_note = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, note, now, dev, uid]);
  audit({ user, action: `Approved order ${o.po_no} ${$(o.total)}`, table: 'po_orders', recordUid: uid, reason: note });
  return getPO(uid);
  });
}
export function rejectPO(user, uid, reason) {
  requirePerm(user, 'po_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = getPO(uid);
  need(o && o.status === 'awaiting', 'This order is not waiting for approval.');
  needReason(user, reason, 'Say why it is sent back.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'draft', budget_note = ?, ${SYNCED} WHERE uid = ?`, [`Sent back by ${user.name}: ${txt(reason)}`, now, dev, uid]);
  audit({ user, action: `Sent back order ${o.po_no}`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
  });
}
// v3.9.3 the purchase order is signed (name, date and time) before it goes to the supplier.
export function signPO(user, uid, signature) {
  requirePerm(user, 'po_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = getPO(uid);
  need(o && ['approved', 'sent', 'part'].includes(o.status), o && ['draft', 'awaiting'].includes(o.status) ? 'Approve the order before signing it.' : 'This order cannot be signed.');
  need(can(user, 'po_create') || can(user, 'po_approve'), 'Only someone who orders or approves orders can sign it.');
  need(txt(signature), 'Sign the order first.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET signature = ?, signed_by_name = ?, signed_by_uid = ?, signed_at = ?, ${SYNCED} WHERE uid = ?`, [signature, user.name, user.uid, now, now, dev, uid]);
  audit({ user, action: `Signed order ${o.po_no}`, table: 'po_orders', recordUid: uid });
  return getPO(uid);
  });
}
export function markSent(user, uid, via = 'viber') {
  requirePerm(user, 'po_create'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = getPO(uid);
  need(o && ['approved', 'sent', 'part'].includes(o.status), o && ['draft', 'awaiting'].includes(o.status) ? 'Approve the order before sending it.' : 'This order cannot be sent.');
  // v3.9.8 an order goes to the supplier once (a changed order is sent again as "amended").
  need(!o.sent_at, `This order was already sent (${String(o.sent_at).slice(0, 16)}, ${o.sent_via || ''}).`);
  need(can(user, 'po_create') || can(user, 'po_approve') || mayApprovePO(user, o.shop_code), 'Only the person who made the order or an approver can send it.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = CASE WHEN status = 'approved' THEN 'sent' ELSE status END, sent_at = ?, sent_via = ?, ${SYNCED} WHERE uid = ?`, [now, via, now, dev, uid]);
  audit({ user, action: `Sent order ${o.po_no} by ${via}`, table: 'po_orders', recordUid: uid });
  // v3.9.4 the Viber Channel gets the order with its PDF (once – the first time it is sent).
  if (o.status === 'approved') {
    try {
      const n = (o.lines || []).length;
      require('../verify/service.js').notify('po_sent', `🧾 ${o.po_no} sent to ${o.supplier_name}: ${n} item${n === 1 ? '' : 's'}, ${$(o.total)}${o.expected_date ? `, deliver by ${o.expected_date}` : ''}. Made by ${o.created_by_name || user.name}, sent by ${user.name}.`,
        { shopCode: o.shop_code, attach: { poUid: uid } });
    } catch (e) { /* the alert never stops the order */ }
  }
  });
}
export function cancelPO(user, uid, reason) {
  requirePerm(user, 'po_create'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = getPO(uid);
  need(o && ['draft', 'awaiting', 'approved', 'sent'].includes(o.status), o && o.status === 'part' ? 'Part of this order has arrived: use "Close short" instead.' : 'This order cannot be cancelled.');
  needReason(user, reason, 'Say why it is cancelled.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'cancelled', cancel_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled order ${o.po_no}`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
  });
}
export function closeShort(user, uid, reason) {
  requirePerm(user, 'po_receive', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = getPO(uid);
  need(o && o.status === 'part', 'Only a part-received order can be closed short.');
  needReason(user, reason, 'Say why the rest is not coming.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'closed', cancel_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Closed order ${o.po_no} short`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
  });
}

// A ready-to-send message for Viber (or SMS / WhatsApp).
export function poText(uid, { business } = {}) {
  const o = getPO(uid);
  need(o, 'Order not found.');
  const shop = db().get('SELECT name FROM shops WHERE code = ?', [o.shop_code]);
  const lines = o.lines.filter((l) => l.qty > 0).map((l, i) => { const v = orderView(l); return `${i + 1}. ${l.name}${l.code ? ` (${l.code})` : ''} – ${fmtQ(v.qty)} ${v.unit}${l.note ? ` (${l.note})` : ''}`.trim(); });
  return [
    `PURCHASE ORDER ${o.po_no}`,
    `${business || 'Easy Buys Shopping Centre'} – ${shop ? shop.name : o.shop_code}`,
    `To: ${o.supplier_name}`,
    `Date: ${o.order_date}${o.expected_date ? `   Deliver by: ${o.expected_date}` : ''}`,
    '',
    ...lines,
    '',
    `${lines.length} item${lines.length === 1 ? '' : 's'}`,
    o.notes ? `Note: ${o.notes}` : null,
    'Please quote the order number on your invoice. Thank you.',
  ].filter((x) => x !== null).join('\n');
}
export const fmtQ = (q) => (Number.isInteger(q) ? String(q) : String(q3(q)));
export function viberLink(text, phone) {
  // Viber opens its "forward" screen with the text, where the supplier is picked. With a number we also offer a chat link.
  return { forward: `viber://forward?text=${encodeURIComponent(text)}`, chat: phone ? `viber://chat?number=${encodeURIComponent(String(phone).replace(/[^\d+]/g, ''))}` : null };
}

// What can be ordered from a supplier for a shop (reorder suggestions), to start an order quickly.
// Products with no main supplier yet are offered too (they get this supplier when received).
export function suggestFor(shopCode, supplierUid) {
  const alsoFrom = new Set(supplierUid && has('inv_item_suppliers') ? db().all('SELECT item_uid FROM inv_item_suppliers WHERE supplier_uid = ? AND active = 1', [supplierUid]).map((x) => x.item_uid) : []);
  // v3.9.8 only this supplier's products once any are linked to it (before that, also products with no supplier yet).
  const linkedAny = alsoFrom.size > 0 || (supplierUid ? !!db().get('SELECT 1 AS x FROM inv_items WHERE supplier_uid = ? LIMIT 1', [supplierUid]) : false);
  return stockList({ shopCode, filter: 'order' }).filter((r) => !supplierUid || r.supplier_uid === supplierUid || alsoFrom.has(r.uid) || (!linkedAny && !r.supplier_uid)).map((r) => ({ itemUid: r.uid, code: r.code, name: r.name, unit: r.unit, qty: r.suggest, unitCost: r.cost,
    why: `${r.supplier_uid ? '' : 'No main supplier set · '}${fmtQ(r.on_hand)} on hand${r.on_order ? `, ${fmtQ(r.on_order)} on order` : ''}, sells ${r.perWeek}/week${r.reorder_level ? `, reorder at ${fmtQ(r.reorder_level)}` : ''}` }));
}

// ---------------------------------------------------------------- receiving
// Receive a delivery against an order (poUid) or without one (supplierUid + extra lines).
// lines: [{lineUid, qty, unitCost}] for order lines; extra: [{itemUid, qty, unitCost}] for products not on the order.
// invoice: { uid } to link one already entered, or { invoiceNo, total, date, photos } to enter it now (optional: it can come later).
export function receiveDelivery(user, { poUid, supplierUid, shopCode, date, lines = [], extra = [], invoice, notes, photos = [], acceptReason, buyType, paidNow, readUid, claims = [], owed = [], settle = [] } = {}) {
  requirePerm(user, 'po_receive', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const rules = invRules();
  const o = poUid ? getPO(poUid) : null;
  if (poUid) need(o && ['approved', 'sent', 'part'].includes(o.status), o && ['draft', 'awaiting'].includes(o.status) ? 'This order has not been approved yet.' : 'This order is not open for receiving.');
  const sup = getSupplier(o ? o.supplier_uid : supplierUid);
  need(sup, 'Choose the supplier.');
  const shop = o ? o.shop_code : txt(shopCode);
  need(shop, 'Choose the shop.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'The delivery date cannot be in the future.');
  const got = [];
  const flags = [];
  for (const l of lines) {
    const pl = o && o.lines.find((x) => x.uid === l.lineUid);
    need(pl, 'A line is not on this order.');
    const qty = q3(l.qty);
    if (!(qty > 0)) continue;
    need(pl.item_uid, `"${pl.name}" is not linked to a product. Link it first.`);
    const cost = l.unitCost === undefined || l.unitCost === '' ? pl.unit_cost : r6(l.unitCost); // r6: a carton price ÷ pack stays exact
    if (pl.unit_cost > 0 && Math.abs(cost - pl.unit_cost) / pl.unit_cost * 100 > rules.priceTolerancePct + 1e-9) flags.push(`${pl.name}: ordered at ${$(pl.unit_cost)}, invoiced at ${$(cost)}`);
    if (pl.qty_received + qty > pl.qty + 1e-9) flags.push(`${pl.name}: ${fmtQ(pl.qty_received + qty)} received, only ${fmtQ(pl.qty)} ordered`);
    got.push({ lineUid: pl.uid, itemUid: pl.item_uid, qty, unitCost: cost, ordered: pl.qty });
  }
  for (const l of extra) {
    const it = getItem(l.itemUid);
    need(it, 'A product was not found.');
    const qty = q3(l.qty);
    if (!(qty > 0)) continue;
    const cost = l.unitCost === undefined || l.unitCost === '' ? it.cost : r4(l.unitCost);
    if (o) flags.push(`${it.name}: not on the order`);
    got.push({ lineUid: null, itemUid: it.uid, qty, unitCost: cost, ordered: 0 });
  }
  need(got.length, 'Enter how many of each product arrived.');
  // No purchase order: a photo of the invoice (or the goods) is kept with it. Owner / admin may skip it.
  const anyPhoto = (photos || []).length || (invoice && (invoice.photos || []).length);
  if (!o) need(anyPhoto || !reasonRequired(user), 'No purchase order for this delivery – take a photo of the invoice (or the goods) first.');
  if (!o && invoice && !invoice.uid && !(invoice.photos || []).length && (photos || []).length) invoice = { ...invoice, photos };
  need(got.every((g) => g.unitCost >= 0), 'Costs cannot be negative.');
  for (const g of got) notFrozen(g.itemUid, shop);
  const value = r2(got.reduce((t, g) => t + incVat(g.qty * g.unitCost, getItem(g.itemUid).vat_type), 0));
  // Invoice: link or enter.
  let inv = null;
  if (invoice && invoice.uid) {
    inv = getInvoice(invoice.uid);
    need(inv && inv.status !== 'void', 'That invoice was not found.');
    need(inv.supplier_uid === sup.uid, 'That invoice is from another supplier.');
  }
  const invTotal = inv ? inv.total : invoice && txt(invoice.total) !== '' && invoice.total !== undefined ? r2(invoice.total) : null;
  // goods on the invoice that the supplier now owes (not delivered, short, damaged, overcharged) are part of its total
  const owedVal = r2((owed || []).reduce((t, x) => { const it = x.itemUid ? getItem(x.itemUid) : null; return t + incVat((Number(x.qty) || 0) * (Number(x.unitCost) || 0), it ? it.vat_type : 'standard'); }, 0));
  if (invTotal !== null && Math.abs(invTotal - value - owedVal) > rules.invoiceTolerance + 0.004) {
    flags.push(`Invoice ${$(invTotal)} but goods received come to ${$(value)}${owedVal ? ` + ${$(owedVal)} owed by the supplier` : ''} (difference ${$(invTotal - value - owedVal)})`);
  }
  if (flags.length) needReason(user, acceptReason, `Please check: ${flags.join('; ')}. Fix it, or say why it is OK.`);
  if (!inv && invoice && (invTotal !== null || (invoice.photos || []).length)) {
    // No total typed: the invoice is for what was received (the office checks it against the paper).
    // 1.0.0 build 3 (year simulation): the invoice's VAT comes from the products – zero-rated goods (rice, flour,
    // sugar…) carry no VAT, so the VAT return never claims VAT that was not charged.
    const vlines = got.map((g) => ({ amount: g.qty * g.unitCost, vatType: getItem(g.itemUid).vat_type }))
      .concat((owed || []).map((x) => { const it = x.itemUid ? getItem(x.itemUid) : null; return { amount: (Number(x.qty) || 0) * (Number(x.unitCost) || 0), vatType: it ? it.vat_type : 'standard' }; }));
    const vs = vatSplit(vlines);
    const invT = invTotal !== null ? invTotal : value;
    const zeroPart = r2(Math.min(invT, vs.zero));
    const vatFields = !vs.zero ? { vatType: 'standard' } : !vs.vat ? { vatType: 'zero' }
      : { vatType: 'mixed', zeroRated: zeroPart, vat: Math.abs(invT - vs.total) <= 0.05 ? vs.vat : r2(((invT - zeroPart) * vatRate()) / (100 + vatRate())) };
    inv = saveInvoice(user, { supplierUid: sup.uid, invoiceNo: invoice.invoiceNo, invoiceDate: txt(invoice.date) || d, total: invT, shopCode: shop, ...vatFields,
      category: 'Stock for resale', description: o ? `Order ${o.po_no}` : 'Delivery received', notes: txt(notes) }, { photos: invoice.photos || [], allowDuplicate: !!invoice.allowDuplicate, askSimilar: true });
  }
  // v3.9.8 paid on the spot (cash buy, or the supplier was paid when they came): the payment is recorded straight away
  // so the invoice is not paid twice. Cash must say where it came from (the safe or which till).
  const bt = o ? 'order' : ['supplier_came', 'cash_buy'].includes(txt(buyType)) ? txt(buyType) : 'supplier_came';
  if (paidNow && paidNow.method) {
    need(inv, 'Enter the invoice (photo and total) to record it as paid.');
    if (paidNow.method === 'cash') need(txt(paidNow.cashFrom), 'Say where the cash came from: the shop\'s safe, or which till.');
    const AP = require('../payables/service.js');
    const cur = AP.getInvoice(inv.uid);
    if (cur.status === 'to_check' && (can(user, 'invoices_check') || can(user, 'settings') || can(user, 'payments_make'))) { try { AP.checkInvoice(user, inv.uid); } catch (e) { /* left to check */ } }
    AP.makePayment(user, { supplierUid: sup.uid, method: paidNow.method, payDate: d, shopCode: shop, cashFrom: paidNow.method === 'cash' ? txt(paidNow.cashFrom) : undefined, walletUid: paidNow.walletUid,
      accountUid: paidNow.accountUid, chequeNo: paidNow.chequeNo, reference: paidNow.method === 'mpaisa' ? txt(paidNow.reference) : txt(paidNow.reference) || inv.invoice_no || 'paid on delivery', receivedBy: sup.name,
      notes: `${bt === 'cash_buy' ? 'Cash buy' : 'Paid when the goods came'} – no purchase order`, allocations: [{ invoiceUid: inv.uid, amount: AP.getInvoice(inv.uid).owing }] });
    inv = getInvoice(inv.uid);
  }
  const { now, dev } = meta();
  const uid = uuid('RC');
  // Movements, order lines and cost prices.
  const costFlags = [];
  for (const g of got) {
    const it = getItem(g.itemUid);
    const c = newCost(it, g, shop, rules); // before the delivery is added to the stock
    try { noteItemSupplier(g.itemUid, sup.uid, { cost: g.unitCost, date: d }); } catch (e) { /* never stops a delivery */ }
    addMove({ itemUid: g.itemUid, shopCode: shop, date: d, type: 'receive', qty: g.qty, unitCost: g.unitCost, refType: 'receipt', refUid: uid, reason: o ? o.po_no : sup.name, user });
    // Bakery ingredients go straight into the Bakery stock (not the shop's stock).
    const bk = bakeryPart(g.itemUid, shop, g.qty);
    if (bk) { addMove({ itemUid: g.itemUid, shopCode: shop, date: d, type: 'to_bakery', qty: -g.qty, unitCost: g.unitCost, refType: 'receipt', refUid: uid, reason: `${bk.material} ${bk.qty}`, user }); g.bakery = bk; }
    if (g.lineUid) db().run(`UPDATE po_lines SET qty_received = qty_received + ?, ${SYNCED} WHERE uid = ?`, [g.qty, now, dev, g.lineUid]);
    if (Math.abs(c - it.cost) > 0.00005) {
      const pct = it.cost > 0 ? Math.abs(c - it.cost) / it.cost * 100 : 100;
      db().run(`UPDATE inv_items SET cost = ?, ${SYNCED} WHERE uid = ?`, [c, now, dev, it.uid]);
      if (pct > rules.costFlagPct + 1e-9 || !it.cost) {
        logCostChange({ itemUid: it.uid, oldCost: it.cost, newCost: c, source: 'receive', supplierName: sup.name, refUid: uid, shopCode: shop, user });
        costFlags.push({ itemUid: it.uid, name: it.name, oldCost: it.cost, newCost: c });
      }
    }
    if (!it.supplier_uid) db().run(`UPDATE inv_items SET supplier_uid = ?, ${SYNCED} WHERE uid = ?`, [sup.uid, now, dev, it.uid]);
  }
  if (inv && o) db().run(`UPDATE ap_invoices SET po_uid = ?, ${SYNCED} WHERE uid = ?`, [o.uid, now, dev, inv.uid]);
  const recLines = got.map((g) => { const it = getItem(g.itemUid); return { lineUid: g.lineUid, itemUid: g.itemUid, code: it.code, name: it.name, qty: g.qty, unitCost: g.unitCost, ordered: g.ordered, ...(g.bakery ? { bakery: g.bakery } : {}) }; });
  db().run(`INSERT INTO inv_receipts (uid, kind, po_uid, supplier_uid, supplier_name, shop_code, receive_date, invoice_uid, invoice_no, invoice_total, total, match_note, lines, notes, by_name, status, created_at, updated_at, updated_device)
    VALUES (?, 'receive', ?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [uid, o ? o.uid : null, sup.uid, sup.name, shop, d, inv ? inv.uid : null, inv ? inv.invoice_no : (invoice && txt(invoice.invoiceNo)) || null, invTotal, value,
    [flags.length ? `${flags.join('; ')} – accepted: ${txt(acceptReason)}` : null, (claims || []).length ? `To claim from ${sup.name}: ${claims.map((c) => txt(c.text)).filter(Boolean).join('; ')}` : null].filter(Boolean).join(' · ') || null,
    JSON.stringify(recLines), txt(notes) || null, user.name, now, now, dev]);
  try { db().run('UPDATE inv_receipts SET buy_type = ? WHERE uid = ?', [bt, uid]); } catch (e) { /* older database */ }
  if (photos.length) addPhotos('receipt', uid, photos);
  // 1.0.0 what the supplier now owes (invoiced, not delivered / short / damaged / overcharged), and owed goods that came
  if ((owed || []).length || (settle || []).length) {
    const OW = require('./supplierOwed.js');
    for (const x of owed || []) {
      try { OW.addOwed(user, { supplierUid: sup.uid, shopCode: shop, itemUid: x.itemUid, name: x.name, qty: x.qty, unitCost: x.unitCost, reason: x.reason, invoiceUid: inv ? inv.uid : null, invoiceNo: inv ? inv.invoice_no : invoice && invoice.invoiceNo, receiptUid: uid, poUid: o ? o.uid : null, note: x.note, date: d }); } catch (e) { /* the delivery is saved either way */ }
    }
    for (const x of settle || []) { try { OW.settleOwed(user, x.owedUid, { how: 'received', qty: x.qty, receiptUid: uid, note: `Came with the delivery of ${d}` }); } catch (e) { /* already settled on another phone */ } }
  }
  // 1.0.0 the invoice reading goes with the delivery (questions for To verify), and what the receiver kept teaches the app
  if (readUid) {
    try {
      const CL = require('./invoiceClarify.js');
      CL.linkRead(readUid, { receiptUid: uid, invoiceUid: inv ? inv.uid : null });
      CL.autoLearn(user, readUid, { invoiceNo: inv ? inv.invoice_no : invoice && invoice.invoiceNo, total: invTotal });
    } catch (e) { /* the delivery is saved either way */ }
  }
  if (o) refreshPOStatus(o.uid);
  if (recLines.some((l) => l.bakery)) { try { postBakeryReceipts(); } catch (e) { /* the bakery tablet adds it on its next sync */ } }
  audit({ user, action: `Received ${got.length} products from ${sup.name} at ${shop} ${$(value)}${o ? ` (${o.po_no})` : ''}`, table: 'inv_receipts', recordUid: uid, reason: txt(acceptReason) || null });
  // v3.9.5 the delivery goes to To verify by itself; Viber says what came and anything that did not match.
  try {
    const bits = [];
    if (flags.length) bits.push(flags.join('; '));
    if (costFlags.length) bits.push(`cost changed: ${costFlags.slice(0, 4).map((c) => `${c.name} ${$(c.oldCost)} → ${$(c.newCost)}`).join(', ')}${costFlags.length > 4 ? ' …' : ''}`);
    notify('delivery', `📦 Delivery from ${sup.name}${o ? ` (${o.po_no})` : ' (no order)'}: ${got.length} product${got.length === 1 ? '' : 's'}, ${$(value)}${inv ? `, invoice ${inv.invoice_no || ''}` : ', no invoice yet'}. Counted by ${user.name}.${bits.length ? ` ⚠️ ${bits.join(' · ')}` : ''}`, { shopCode: shop, attach: photos && photos.length ? { photos: photos.slice(0, 2) } : null });
  } catch (e) { /* Viber is optional */ }
  return { uid, value, invoice: inv, costFlags, flags, po: o ? getPO(o.uid) : null };
  });
}
function newCost(it, g, shop, rules) {
  if (rules.costMethod !== 'average') return r4(g.unitCost);
  const have = db().get("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND status = 'active'", [it.uid]).q; // all shops, before this delivery
  const h = Math.max(0, have);
  return h + g.qty > 0 ? r4((h * it.cost + g.qty * g.unitCost) / (h + g.qty)) : r4(g.unitCost);
}
// v3.9: what each order line has received, worked out again from the deliveries themselves (two devices receiving the
// same order offline would otherwise each overwrite the other's count).
export function recountReceived(poUid) {
  const o = getPO(poUid);
  if (!o) return;
  const got = {};
  db().all("SELECT lines FROM inv_receipts WHERE po_uid = ? AND status = 'active' AND kind = 'receive'", [poUid]).forEach((r) => J(r.lines, []).forEach((l) => { if (l.lineUid) got[l.lineUid] = (got[l.lineUid] || 0) + (Number(l.qty) || 0); }));
  const { now, dev } = meta();
  for (const l of o.lines) {
    const q = Math.round((got[l.uid] || 0) * 1000) / 1000;
    if (Math.abs(q - (Number(l.qty_received) || 0)) > 1e-9) db().run(`UPDATE po_lines SET qty_received = ?, ${SYNCED} WHERE uid = ?`, [q, now, dev, l.uid]);
  }
  refreshPOStatus(poUid);
}
export function refreshPOStatus(poUid) {
  const o = getPO(poUid);
  if (!o || !['approved', 'sent', 'part', 'received'].includes(o.status)) return;
  const live = o.lines.filter((l) => l.qty > 0);
  const all = live.every((l) => l.qty_received + 1e-9 >= l.qty);
  const any = o.lines.some((l) => l.qty_received > 0);
  const status = all && any ? 'received' : any ? 'part' : (o.sent_at ? 'sent' : 'approved');
  if (status !== o.status) {
    const { now, dev } = meta();
    db().run(`UPDATE po_orders SET status = ?, ${SYNCED} WHERE uid = ?`, [status, now, dev, poUid]);
  }
}
export function getReceipt(uid) {
  const r = db().get('SELECT * FROM inv_receipts WHERE uid = ?', [uid]);
  return r && { ...r, lines: J(r.lines, []) };
}
export function listReceipts({ shopCode, supplierUid, from, to, kind, limit = 300 } = {}) {
  return db().all(`SELECT * FROM inv_receipts WHERE (? IS NULL OR shop_code = ?) AND (? IS NULL OR supplier_uid = ?) AND (? IS NULL OR receive_date >= ?) AND (? IS NULL OR receive_date <= ?)
    AND (? IS NULL OR kind = ?) ORDER BY receive_date DESC, created_at DESC LIMIT ?`,
  [shopCode || null, shopCode || null, supplierUid || null, supplierUid || null, from || null, from || null, to || null, to || null, kind || null, kind || null, limit]).map((r) => ({ ...r, lines: J(r.lines, []) }));
}
// Goods received with no supplier invoice yet (or returns with no credit note yet).
export function receivedNotInvoiced({ shopCode } = {}) {
  return listReceipts({ shopCode, limit: 2000 }).filter((r) => r.status === 'active' && !r.invoice_uid);
}
export function linkInvoice(user, receiptUid, invoiceUid) {
  requirePerm(user, 'po_receive', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const r = getReceipt(receiptUid);
  need(r && r.status === 'active', 'Delivery not found.');
  const inv = getInvoice(invoiceUid);
  need(inv && inv.status !== 'void', 'Invoice not found.');
  need(inv.supplier_uid === r.supplier_uid, 'That invoice is from another supplier.');
  if (r.kind === 'return') need(inv.kind === 'credit', 'Link a credit note to a return.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_receipts SET invoice_uid = ?, invoice_no = ?, invoice_total = ?, ${SYNCED} WHERE uid = ?`, [inv.uid, inv.invoice_no, inv.total, now, dev, receiptUid]);
  if (r.po_uid && !inv.po_uid) db().run(`UPDATE ap_invoices SET po_uid = ?, ${SYNCED} WHERE uid = ?`, [r.po_uid, now, dev, inv.uid]);
  const diff = r2(inv.total - Math.abs(r.total));
  audit({ user, action: `Linked ${inv.kind === 'credit' ? 'credit note' : 'invoice'} ${inv.invoice_no || ''} ${$(inv.total)} to delivery ${r.receive_date}${Math.abs(diff) > 0.004 ? ` (differs by ${$(diff)})` : ''}`, table: 'inv_receipts', recordUid: receiptUid });
  return { diff };
  });
}
export function voidReceipt(user, uid, reason) {
  requirePerm(user, 'po_receive', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopOf('inv_receipts', uid)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const r = getReceipt(uid);
  need(r && r.status === 'active', 'Delivery not found or already voided.');
  needReason(user, reason, 'Say why it is being voided.');
  for (const l of r.lines) notFrozen(l.itemUid, r.shop_code);
  const { now, dev } = meta();
  voidMovesFor(uid, txt(reason));
  for (const l of r.lines) if (l.lineUid) db().run(`UPDATE po_lines SET qty_received = MAX(0, qty_received - ?), ${SYNCED} WHERE uid = ?`, [l.qty, now, dev, l.lineUid]);
  db().run(`UPDATE inv_receipts SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  if (r.po_uid) {
    const o = getPO(r.po_uid);
    if (o && ['received', 'part'].includes(o.status)) {
      const any = o.lines.some((l) => l.qty_received > 0);
      db().run(`UPDATE po_orders SET status = ?, ${SYNCED} WHERE uid = ?`, [any ? 'part' : (o.sent_at ? 'sent' : 'approved'), now, dev, o.uid]);
      refreshPOStatus(o.uid);
    }
  }
  audit({ user, action: `Voided delivery from ${r.supplier_name} ${r.receive_date} ${$(r.total)} (cost prices are not changed back)`, table: 'inv_receipts', recordUid: uid, reason: txt(reason) });
  });
}

// Goods sent back to a supplier (damaged, expired, wrong). A credit note is expected: it shows as "waiting for credit" until linked.
export function returnToSupplier(user, { supplierUid, shopCode, date, lines = [], reason, notes, photos = [] }) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const sup = getSupplier(supplierUid);
  need(sup, 'Choose the supplier.');
  need(txt(shopCode), 'Choose the shop.');
  needReason(user, reason, 'Say why the goods are going back.');
  const d = txt(date) || dateStr();
  const clean = lines.map((l) => ({ it: getItem(l.itemUid), qty: q3(l.qty), unitCost: l.unitCost })).filter((l) => l.it && l.qty > 0);
  need(clean.length, 'Add at least one product.');
  for (const l of clean) notFrozen(l.it.uid, shopCode);
  const uid = uuid('RT');
  let value = 0;
  const recLines = clean.map((l) => {
    const cost = l.unitCost === undefined || l.unitCost === '' ? l.it.cost : r4(l.unitCost);
    value += incVat(l.qty * cost, l.it.vat_type);
    addMove({ itemUid: l.it.uid, shopCode, date: d, type: 'return', qty: -l.qty, unitCost: cost, refType: 'return', refUid: uid, reason: `${sup.name}: ${txt(reason)}`, user });
    return { itemUid: l.it.uid, code: l.it.code, name: l.it.name, qty: l.qty, unitCost: cost };
  });
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_receipts (uid, kind, supplier_uid, supplier_name, shop_code, receive_date, total, lines, notes, by_name, status, created_at, updated_at, updated_device)
    VALUES (?, 'return', ?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [uid, sup.uid, sup.name, shopCode, d, -r2(value), JSON.stringify(recLines), [txt(reason), txt(notes)].filter(Boolean).join(' – '), user.name, now, now, dev]);
  if (photos.length) addPhotos('receipt', uid, photos);
  audit({ user, action: `Returned ${recLines.length} products to ${sup.name} from ${shopCode} ${$(value)} – credit note expected`, table: 'inv_receipts', recordUid: uid, reason: txt(reason) });
  return uid;
  });
}

// ---------------------------------------------------------------- cost price changes
export function logCostChange({ itemUid, oldCost, newCost, source, supplierName, refUid, shopCode }) {
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_cost_changes (uid, item_uid, change_date, old_cost, new_cost, supplier_name, ref_uid, shop_code, source, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [uuid('CC'), itemUid, dateStr(), r4(oldCost), r4(newCost), supplierName || null, refUid || null, shopCode || null, source || null, now, dev]);
}
export function costChanges({ unseenOnly = false, itemUid, from, to, limit = 500 } = {}) {
  return db().all(`SELECT c.*, i.code, i.name, i.price, i.vat_type FROM inv_cost_changes c LEFT JOIN inv_items i ON i.uid = c.item_uid
    WHERE (? = 0 OR c.seen_at IS NULL) AND (? IS NULL OR c.item_uid = ?) AND (? IS NULL OR c.change_date >= ?) AND (? IS NULL OR c.change_date <= ?)
    ORDER BY c.change_date DESC, c.updated_at DESC, c.rowid LIMIT ?`,
  [unseenOnly ? 1 : 0, itemUid || null, itemUid || null, from || null, from || null, to || null, to || null, limit]).map((c) => ({
    ...c, diff: r4(c.new_cost - (c.old_cost || 0)), pct: c.old_cost ? r2(((c.new_cost - c.old_cost) / c.old_cost) * 100) : null,
    belowCost: c.price > 0 && incVat(c.new_cost, c.vat_type) >= c.price,
    margin: c.price > 0 ? r2(((c.price - incVat(c.new_cost, c.vat_type)) / c.price) * 100) : null,
  }));
}
// Seen, and optionally a new selling price (all shops, or one shop).
export function reviewCostChange(user, uid, { newPrice, shopCode } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode || shopOf('inv_cost_changes', uid)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const c = db().get('SELECT * FROM inv_cost_changes WHERE uid = ?', [uid]);
  need(c, 'Not found.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_cost_changes SET seen_by_name = ?, seen_at = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, now, dev, uid]);
  if (newPrice !== undefined && newPrice !== '' && newPrice !== null) {
    const p = r2(newPrice);
    need(p > 0, 'Enter the new selling price.');
    const it = getItem(c.item_uid);
    if (shopCode) {
      const s = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [c.item_uid, shopCode]);
      saveItemShop(user, { itemUid: c.item_uid, shopCode, active: s ? !!s.active : true, reorderLevel: s ? s.reorder_level : 0, reorderQty: s ? s.reorder_qty : 0, price: p, location: s ? s.location : null });
    } else {
      db().run(`UPDATE inv_items SET price = ?, ${SYNCED} WHERE uid = ?`, [p, now, dev, c.item_uid]);
      db().run(`UPDATE inv_item_shops SET price = NULL, ${SYNCED} WHERE item_uid = ? AND price IS NOT NULL`, [now, dev, c.item_uid]);
    }
    audit({ user, action: `New price for ${it.code} ${it.name}: ${$(p)}${shopCode ? ` at ${shopCode}` : ' (all shops)'} – remember to change it in Aronium too`, table: 'inv_items', recordUid: c.item_uid });
  }
  });
}

// ---------------------------------------------------------------- stock take (frozen while counting; counted, then approved)
export const COUNT_STATUS = { counting: 'Counting', review: 'Waiting for approval', posted: 'Posted', cancelled: 'Cancelled' };
// scope: { groups?: [], locations?: [], itemUids?: [] } – empty = the whole shop.
// timing: 'before_open' (sales of the count day come after it) | 'after_close' (the count day's sales came before it)
export function startCount(user, { shopCode, name, scope = {}, date, timing = 'after_close', blind, kind, uid: fixedUid } = {}) {
  requirePerm(user, 'stocktake_count'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const initial = kind === 'initial';
  // The first (opening) stock take skips the loss limit and reasons, so only the owner / admin may start one.
  need(!initial || ['owner', 'admin'].includes(user.role), 'Only the owner or admin can start the first (opening) stock take.');
  need(txt(shopCode), 'Choose the shop.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the count date.');
  const clean = { groups: (scope.groups || []).filter(Boolean), locations: (scope.locations || []).filter(Boolean), itemUids: (scope.itemUids || []).filter(Boolean) };
  // Two counts in the same shop may not cover the same products.
  // The first (initial) stock take: every product on the list, whether or not this shop has had it yet.
  const items = (initial
    ? db().all(`SELECT i.*, s.location FROM inv_items i LEFT JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ? WHERE i.active = 1 AND i.removed_at IS NULL ORDER BY s.location, i.group_name, i.name`, [shopCode])
    : db().all(`SELECT i.*, s.location FROM inv_items i JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ? WHERE i.active = 1 AND (s.active = 1 OR
    (SELECT COALESCE(SUM(qty),0) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.status = 'active') <> 0) ORDER BY s.location, i.group_name, i.name`, [shopCode, shopCode]))
    .filter((it) => inScope({ scope: JSON.stringify(clean) }, it, it.location))
    .filter((it) => !salesOnly(it, invRules())); // sales-only groups (lollies…) are never counted
  need(items.length, 'No products match. Import or add products for this shop first.');
  for (const c of openCounts(shopCode)) {
    const clash = items.find((it) => inScope(c, it, it.location));
    need(!clash, `"${c.name || c.count_date}" is still open for some of the same products (e.g. ${clash && clash.name}). Post or cancel it first.`);
  }
  const rules = invRules();
  // 1.0.0 the shared stock take: its id is made from the shop and the day, so two phones starting it offline start the SAME one
  const uid = fixedUid || uuid('SC');
  const { now, dev } = meta();
  const label = txt(name) || `${shopCode} ${initial ? 'initial stock take' : clean.groups.length ? clean.groups.join(', ') : clean.locations.length ? clean.locations.join(', ') : 'full count'} ${d}`;
  db().run(`INSERT INTO inv_counts (uid, shop_code, name, scope, count_date, timing, blind, status, started_at, started_by_name, uncounted, kind, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?, 'counting', ?,?,?,?,?,?)`,
  [uid, shopCode, label, JSON.stringify(clean), d, timing === 'before_open' ? 'before_open' : 'after_close', initial ? 0 : (blind === undefined ? rules.blindCount : blind) ? 1 : 0, now, user.name, initial ? 'leave' : rules.uncounted, initial ? 'initial' : 'normal', now, dev]);
  for (const it of items) {
    // The line's id is made from the count and the product, so two phones adding the same product make the same line.
    db().run(`INSERT OR IGNORE INTO inv_count_lines (uid, count_uid, item_uid, expected, cost, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)`,
      [countLineUid(uid, it.uid), uid, it.uid, expectedAt(it.uid, shopCode, d, timing, uid), it.cost, now, dev]);
  }
  audit({ user, action: `Started stock take "${label}" (${items.length} products) – stock frozen`, table: 'inv_counts', recordUid: uid });
  return getCount(uid);
  });
}
const countLineUid = (countUid, itemUid) => `CL-${countUid}-${itemUid}`;
// v3.9.3 add a product to an open stock take (found on the shelf but not on the list, or a new product made from a scan).
export function addToCount(user, countUid, itemUid) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting.');
  const it = getItem(itemUid);
  need(it, 'Product not found.');
  if (db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [countUid, itemUid])) return false;
  for (const o of openCounts(c.shop_code).filter((x) => x.uid !== countUid)) need(!db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [o.uid, itemUid]), `${it.name} is being counted in "${o.name}".`);
  const { now, dev } = meta();
  db().run('INSERT OR IGNORE INTO inv_count_lines (uid, count_uid, item_uid, expected, cost, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)',
    [countLineUid(countUid, itemUid), countUid, itemUid, expectedAt(itemUid, c.shop_code, c.count_date, c.timing, countUid), it.cost, now, dev]);
  audit({ user, action: `Added ${it.name} to stock take "${c.name}"`, table: 'inv_counts', recordUid: countUid });
  return true;
  });
}
// Each count typed or scanned (for one product in a stock take), newest first.
export function countEntries(countUid, itemUid, { all = false } = {}) {
  if (!has('inv_count_entries')) return [];
  return db().all(`SELECT e.* FROM inv_count_entries e WHERE e.count_uid = ? AND e.item_uid = ? AND COALESCE(e.kind, '') <> 'reset'${all ? '' : ` AND ${LIVE}`} ORDER BY e.at DESC`, [countUid, itemUid]);
}
// Take out one entry (typed wrong). The person who typed it, or a manager who approves stock takes.
export function voidEntry(user, entryUid, reason) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const e = db().get('SELECT * FROM inv_count_entries WHERE uid = ?', [entryUid]);
  need(e && !e.void_at, 'That count was not found.');
  const c = getCount(e.count_uid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting.');
  need(e.by_uid === user.uid || can(user, 'stocktake_approve') || ['owner', 'admin'].includes(user.role), 'Only the person who counted it, or a manager, can take it out.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_entries SET void_at = ?, void_by_name = ?, void_reason = ?, ${SYNCED} WHERE uid = ?`, [now, user.name, txt(reason) || null, now, dev, entryUid]);
  refreshLine(e.count_uid, e.item_uid);
  });
}
// Entries that count: not taken out, and made at or after the line's last reset (recount / "Change total") – so a
// count arriving late from a phone that was offline during the reset is not added on top.
// The last reset of the product (an entry of kind 'reset', never overwritten): a count counts when its phone had seen
// that reset, or was made after it.
const LAST_RESET = "(SELECT r.uid FROM inv_count_entries r WHERE r.count_uid = e.count_uid AND r.item_uid = e.item_uid AND r.kind = 'reset' ORDER BY r.at DESC, r.uid DESC LIMIT 1)";
// Only the phone's own knowledge decides (never its clock): a count made on a phone that had not yet seen the last
// recount does not count – that phone's person counts again once it has synced (the safe way round).
const LIVE = `e.void_at IS NULL AND COALESCE(e.kind, '') <> 'reset' AND (${LAST_RESET} IS NULL OR e.seen_reset = ${LAST_RESET})`;
const lastReset = (countUid, itemUid) => { try { const r = db().get("SELECT uid FROM inv_count_entries WHERE count_uid = ? AND item_uid = ? AND kind = 'reset' ORDER BY at DESC, uid DESC LIMIT 1", [countUid, itemUid]); return r ? r.uid : null; } catch (e) { return null; } };
function entrySum(countUid, itemUid) {
  if (!has('inv_count_entries')) return null;
  const r = db().get(`SELECT COUNT(*) AS n, COALESCE(SUM(qty),0) AS q FROM inv_count_entries e WHERE e.count_uid = ? AND e.item_uid = ? AND ${LIVE}`, [countUid, itemUid]);
  return r.n ? { n: r.n, q: q3(r.q) } : null;
}
function resetLine(countUid, itemUid, user, why) {
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, spot, by_name, by_uid, device, at, kind, seen_reset, updated_at, updated_device) VALUES (?,?,?,0,?,?,?,?,?,'reset',?,?,?)`,
    [uuid('CR'), countUid, itemUid, why || null, user ? user.name : null, user ? user.uid : null, dev, now, lastReset(countUid, itemUid), now, dev]);
}
// The line's own "counted" follows its entries (kept for reports and older devices).
function refreshLine(countUid, itemUid) {
  // With entries, the count comes from the entries; the line is NOT rewritten (an old copy of the line from one phone
  // must never wipe a recount, reason or second count made on another). The total is written once, when posted.
  if (has('inv_count_entries')) return;
  const sum = entrySum(countUid, itemUid);
  const names = has('inv_count_entries') ? db().all('SELECT DISTINCT by_name FROM inv_count_entries WHERE count_uid = ? AND item_uid = ? AND void_at IS NULL', [countUid, itemUid]).map((x) => x.by_name).filter(Boolean) : [];
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_lines SET counted = ?, counted_by_name = ?, counted_at = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`,
    [sum ? sum.q : null, names.join(', ') || null, sum ? now : null, now, dev, countUid, itemUid]);
}
function voidEntriesFor(user, countUid, itemUid, why) {
  if (!has('inv_count_entries')) return;
  resetLine(countUid, itemUid, user, why);
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_entries SET void_at = ?, void_by_name = ?, void_reason = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ? AND void_at IS NULL AND COALESCE(kind, '') <> 'reset'`, [now, user ? user.name : null, why, now, dev, countUid, itemUid]);
}

// What the system expects at the moment of the count: every movement up to the count (sales of the count day
// only if the count is after closing), not counting this stock take's own adjustment.
function expectedAt(itemUid, shopCode, date, timing, countUid) {
  const r = db().get(`SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = ? AND status = 'active' AND ifnull(ref_uid,'') <> ? AND
    (move_date < ? OR (move_date = ? AND (? = 'after_close' OR type <> 'sale')))`, [itemUid, shopCode, countUid || '', date, date, timing]);
  return q3(r.q);
}
export function getCount(uid, { withLines = true } = {}) {
  const c = db().get('SELECT * FROM inv_counts WHERE uid = ?', [uid]);
  if (!c) return null;
  const out = { ...c, scope: J(c.scope, {}), result: J(c.result, null) };
  if (!withLines) return out;
  const rules = invRules();
  let lines = db().all(`SELECT l.*, i.code, i.name, i.unit, i.barcode, i.group_name, i.pack_size, s.location FROM inv_count_lines l JOIN inv_items i ON i.uid = l.item_uid
    LEFT JOIN inv_item_shops s ON s.item_uid = l.item_uid AND s.shop_code = ? WHERE l.count_uid = ? ORDER BY s.location, i.group_name, i.name`, [c.shop_code, uid]);
  const sums = new Map();
  if (has('inv_count_entries')) {
    // Posted / cancelled: the totals saved at posting stand (an entry arriving late changes nothing).
    if (!['posted', 'cancelled'].includes(c.status)) {
      db().all(`SELECT e.item_uid, COUNT(*) AS n, SUM(e.qty) AS q, GROUP_CONCAT(DISTINCT e.by_name) AS by FROM inv_count_entries e WHERE e.count_uid = ? AND ${LIVE} GROUP BY e.item_uid`, [uid])
        .forEach((r) => sums.set(r.item_uid, { n: r.n, q: q3(r.q), by: String(r.by || '').split(',').join(', ') }));
    }
  }
  // 1.0.0 a product sold loose from a pack is counted in the pack's "loose" box, not on its own line (open counts)
  if (!['posted', 'cancelled'].includes(c.status)) { try { const LL = require('./looseLinks.js'); lines = lines.filter((l) => !LL.looseOf(l.item_uid)); } catch (e) { /* no links */ } }
  out.lines = lines.map((l) => {
    // While open, "expected" is worked out again so sales that arrive late (from Aronium) are allowed for.
    const exp = c.status === 'posted' || c.status === 'cancelled' ? l.expected : expectedAt(l.item_uid, c.shop_code, c.count_date, c.timing, uid);
    // v3.9.3 the count is the sum of every phone's entries (when there are any).
    const es = sums.get(l.item_uid);
    const counted = es ? es.q : l.counted === null || l.counted === undefined ? null : l.counted;
    const finalQty = counted === null ? (c.uncounted === 'zero' ? 0 : null) : counted;
    const variance = finalQty === null ? 0 : q3(finalQty - exp);
    const value = r2(variance * (l.cost || 0));
    // The first stock take has nothing to compare with, so nothing is "well off".
    const needsRecount = c.kind !== 'initial' && counted !== null && !l.recount && (Math.abs(variance) > rules.countTolerance + 1e-9 && Math.abs(value) > rules.countValueTolerance + 0.004);
    const dbl = needsDouble(l, rules);
    const needsSecond = dbl && counted !== null && (l.second_count === null || l.second_count === undefined);
    const mismatch = dbl && counted !== null && l.second_count !== null && l.second_count !== undefined && Math.abs(l.second_count - counted) > 1e-9;
    return { ...l, expected: exp, variance, value, needsRecount, counted, double: dbl, needsSecond, mismatch, area: l.location || 'No area', entries: es ? es.n : 0, counted_by_name: es ? es.by : l.counted_by_name };
  });
  const counted = out.lines.filter((l) => l.counted !== null);
  const off = counted.filter((l) => Math.abs(l.variance) > 1e-9);
  out.summary = {
    products: out.lines.length, counted: counted.length, notCounted: out.lines.length - counted.length,
    matched: counted.length - off.length, over: off.filter((l) => l.variance > 0).length, short: off.filter((l) => l.variance < 0).length,
    gain: r2(off.filter((l) => l.value > 0).reduce((s, l) => s + l.value, 0)), loss: r2(off.filter((l) => l.value < 0).reduce((s, l) => s + l.value, 0)),
    net: r2(out.lines.reduce((s, l) => s + l.value, 0)), expectedValue: r2(out.lines.reduce((s, l) => s + Math.max(0, l.expected) * (l.cost || 0), 0)),
    accuracy: counted.length ? Math.round(((counted.length - off.length) / counted.length) * 1000) / 10 : null,
    toRecount: out.lines.filter((l) => l.needsRecount).length,
    toSecond: out.lines.filter((l) => l.needsSecond).length,
    mismatches: out.lines.filter((l) => l.mismatch).length,
    noReason: off.filter((l) => !l.reason).length,
  };
  // v3.9.3 who has counted how many products, and what the counted stock is worth (cost and selling price).
  out.people = has('inv_count_entries') ? db().all(`SELECT e.by_name AS name, COUNT(DISTINCT e.item_uid) AS products, MAX(e.at) AS last FROM inv_count_entries e WHERE e.count_uid = ? AND ${LIVE} GROUP BY e.by_name ORDER BY products DESC`, [uid]) : [];
  if (c.kind === 'initial') {
    const priceOf = new Map(db().all('SELECT i.uid, COALESCE(s.price, i.price) AS p FROM inv_items i LEFT JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ?', [c.shop_code]).map((r) => [r.uid, Number(r.p) || 0]));
    out.summary.countedCost = r2(counted.reduce((t, l) => t + (l.counted || 0) * (l.cost || 0), 0));
    out.summary.countedRetail = r2(counted.reduce((t, l) => t + (l.counted || 0) * (priceOf.get(l.item_uid) || 0), 0));
  }
  // Areas (shelves / locations): how far each one is, and who is counting it.
  const claims = has('inv_count_areas') ? db().all('SELECT * FROM inv_count_areas WHERE count_uid = ?', [uid]) : [];
  const areas = {};
  out.lines.forEach((l) => { const a = (areas[l.area] = areas[l.area] || { area: l.area, total: 0, counted: 0 }); a.total += 1; if (l.counted !== null) a.counted += 1; });
  out.areas = Object.values(areas).map((a) => { const cl = claims.find((x) => x.area === a.area); return { ...a, counter: cl ? cl.counter_name : null, done: !!(cl && cl.done_at) }; });
  return out;
}
export function listCounts({ shopCode, status, limit = 100 } = {}) {
  return db().all(`SELECT * FROM inv_counts WHERE (? IS NULL OR shop_code = ?) AND (? IS NULL OR status = ?) ORDER BY count_date DESC, started_at DESC LIMIT ?`,
    [shopCode || null, shopCode || null, status || null, status || null, limit]).map((c) => ({ ...c, scope: J(c.scope, {}), result: J(c.result, null) }));
}
// High-value products are counted twice, by two different people.
export function salesOnly(item, rules = invRules()) {
  // 1.0.0 a product sold loose from a pack: its stock is the pack's
  try { if (item && (item.uid || item.item_uid) && require('./looseLinks.js').looseOf(item.uid || item.item_uid)) return true; } catch (e) { /* no links */ }
  const g = String((item && (item.group_name || item.group)) || '').toLowerCase();
  return !!g && (rules.noStockGroups || []).some((x) => x && g.includes(String(x).toLowerCase()));
}
export function needsDouble(line, rules = invRules()) {
  const g = String(line.group_name || '').toLowerCase();
  if ((rules.doubleCountGroups || []).some((x) => x && g.includes(String(x).toLowerCase()))) return true;
  return rules.doubleCountCost > 0 && Number(line.cost || 0) >= rules.doubleCountCost;
}
// Several counters at once: each takes an area (shelf / location) and marks it done.
export function claimArea(user, countUid, area) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting.');
  const { now, dev } = meta();
  const uid = `${countUid}|${area}`;
  const have = db().get('SELECT * FROM inv_count_areas WHERE uid = ?', [uid]);
  if (have && have.counter_name && have.counter_name !== user.name && !have.done_at) need(false, `${have.counter_name} is counting ${area}. Choose another area.`);
  db().run(`INSERT INTO inv_count_areas (uid, count_uid, area, counter_name, started_at, done_at, updated_at, updated_device) VALUES (?,?,?,?,?,NULL,?,?)
    ON CONFLICT(uid) DO UPDATE SET counter_name = excluded.counter_name, started_at = excluded.started_at, done_at = NULL, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, countUid, area, user.name, now, now, dev]);
  return getCount(countUid).areas.find((a) => a.area === area);
  });
}
export function finishArea(user, countUid, area) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid);
  const a = c && c.areas.find((x) => x.area === area);
  need(a, 'Area not found.');
  need(a.counted === a.total, `${a.total - a.counted} product(s) in ${area} are not counted yet.`);
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_areas SET done_at = ?, ${SYNCED} WHERE uid = ?`, [now, now, dev, `${countUid}|${area}`]);
  audit({ user, action: `Stock take "${c.name}": ${area} counted`, table: 'inv_counts', recordUid: countUid });
  });
}
// Why a product is more or less than expected (shown on reports and the write-off).
export function setLineReason(user, countUid, itemUid, reason) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const rules = invRules();
  need(rules.countReasons.includes(reason), 'Choose a reason.');
  const { now, dev } = meta();
  const r = db().run(`UPDATE inv_count_lines SET reason = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [reason, now, dev, countUid, itemUid]);
  need(r.changes, 'This product is not part of this stock take.');
  });
}
// Expiry seen while counting (e.g. 6 packets expire on 2026-11-02).
export function setLineExpiry(user, countUid, itemUid, { expiry, qty }) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(!expiry || DATE.test(expiry), 'Choose the expiry date.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_lines SET expiry = ?, expiry_qty = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [expiry || null, expiry ? q3(qty || 0) : null, now, dev, countUid, itemUid]);
  });
}
export function expiringSoon({ shopCode, days = 30, today = dateStr() } = {}) {
  if (!has('inv_count_lines')) return [];
  return keptAll(`SELECT l.item_uid, l.expiry, l.expiry_qty, i.name, i.code, c.shop_code, c.count_date FROM inv_count_lines l JOIN inv_counts c ON c.uid = l.count_uid JOIN inv_items i ON i.uid = l.item_uid
    WHERE l.expiry IS NOT NULL AND l.expiry <= ? AND l.expiry >= ? AND c.status <> 'cancelled' AND (? IS NULL OR c.shop_code = ?) ORDER BY l.expiry`, [addDays(today, days), addDays(today, -7), shopCode || null, shopCode || null]).slice();
}
// Enter (or change) a count. add: true adds to what is already counted (counting the same product in two places).
export function enterCount(user, countUid, itemUid, qty, { add = false, note, packs, spot, entryUid } = {}) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  // 1.0.0 a count sent twice (double tap, a retry) with the same entry id is kept once
  if (entryUid && has('inv_count_entries') && db().get('SELECT 1 AS x FROM inv_count_entries WHERE uid = ?', [entryUid])) { const s0 = entrySum(countUid, itemUid); return s0 ? s0.q : null; }
  const c = getCount(countUid, { withLines: false });
  // Cartons + singles: "3 cartons + 5" with the product's pack size.
  if (packs !== undefined && packs !== null && packs !== '') {
    const it = getItem(itemUid);
    const ps = Number(it && it.pack_size) || 1;
    qty = q3(Number(packs) * ps + (Number(qty) || 0));
  }
  need(c && c.status === 'counting', c && c.status === 'review' ? 'This stock take is waiting for approval. Ask for a recount to change it.' : 'This stock take is closed.');
  const l = db().get('SELECT * FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [countUid, itemUid]);
  need(l, 'This product is not part of this stock take.');
  const n = qty === '' || qty === null || qty === undefined ? null : q3(qty);
  need(n === null || n >= 0 || add, 'The count cannot be negative.');
  const base = entrySum(countUid, itemUid);
  const value = n === null ? null : add ? q3((base ? base.q : l.counted || 0) + n) : n;
  need(value === null || value >= 0, 'The count cannot go below 0.');
  const { now, dev } = meta();
  // High-value products: a different person's count is the second count (both must agree).
  const it0 = db().get('SELECT group_name, cost FROM inv_items WHERE uid = ?', [itemUid]);
  // Who has counted it so far (from the entries when there are any).
  const curCounted = base ? base.q : l.counted;
  const curBy = has('inv_count_entries') && base ? countEntries(countUid, itemUid).map((e) => e.by_name) : l.counted_by_name ? [l.counted_by_name] : [];
  if (!add && value !== null && curCounted !== null && curCounted !== undefined && curBy.length && !curBy.includes(user.name) && needsDouble({ ...it0, cost: l.cost }, invRules())) {
    db().run(`UPDATE inv_count_lines SET second_count = ?, second_by_name = ?, ${SYNCED} WHERE uid = ?`, [value, user.name, now, dev, l.uid]);
    return value;
  }
  if (has('inv_count_entries')) {
    // v3.9.3 every count is its own entry. "Set" replaces what THIS person counted for the product; "+ Add" adds another
    // entry (another shelf, the storeroom). Other people's counts are added on top – so phones never overwrite each other.
    if (!add) voidOwnEntries(user, countUid, itemUid);
    // A 0 is kept only when nobody else has counted it ("none here" is a count too); "+ Add 0" adds nothing.
    if (n !== null && !(add && n === 0) && !(n === 0 && entrySum(countUid, itemUid))) {
      db().run(`INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, spot, by_name, by_uid, device, at, seen_reset, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [entryUid || uuid('CE'), countUid, itemUid, n, txt(spot) || null, user.name, user.uid, dev, now, lastReset(countUid, itemUid), now, dev]);
    }
    refreshLine(countUid, itemUid);
    if (txt(note)) db().run(`UPDATE inv_count_lines SET note = ?, ${SYNCED} WHERE uid = ?`, [txt(note), now, dev, l.uid]);
    const sum = entrySum(countUid, itemUid);
    need(!sum || sum.q >= 0, 'The count cannot go below 0.');
    return sum ? sum.q : null;
  }
  db().run(`UPDATE inv_count_lines SET counted = ?, counted_by_name = ?, counted_at = ?, note = COALESCE(?, note), ${SYNCED} WHERE uid = ?`,
    [value, user.name, now, txt(note) || null, now, dev, l.uid]);
  return value;
  });
}
// The owner / admin (or a manager who approves stock takes) puts the right total: every count so far is taken out
// (kept in the history) and replaced by this one.
export function setCountTotal(user, countUid, itemUid, qty, reason) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(['owner', 'admin'].includes(user.role) || can(user, 'stocktake_approve'), 'Only the admin or a manager can change the total.');
  const c = getCount(countUid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting.');
  need(db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [countUid, itemUid]), 'This product is not part of this stock take.');
  const n = q3(qty);
  need(txt(qty) !== '' && n >= 0, 'Type the right total (0 or more).');
  const before = entrySum(countUid, itemUid);
  voidEntriesFor(user, countUid, itemUid, `total changed by ${user.name}${txt(reason) ? `: ${txt(reason)}` : ''}`);
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, spot, by_name, by_uid, device, at, seen_reset, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uuid('CE'), countUid, itemUid, n, 'Total set by the admin', user.name, user.uid, dev, now, lastReset(countUid, itemUid), now, dev]);
  refreshLine(countUid, itemUid);
  const it = getItem(itemUid);
  audit({ user, action: `Stock take "${c.name}": ${it ? it.name : itemUid} total set to ${fmtQ(n)} (was ${before ? fmtQ(before.q) : 'not counted'})`, table: 'inv_counts', recordUid: countUid, reason: txt(reason) || null });
  return n;
  });
}
function voidOwnEntries(user, countUid, itemUid) {
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_entries SET void_at = ?, void_by_name = ?, void_reason = 'counted again', ${SYNCED} WHERE count_uid = ? AND item_uid = ? AND by_uid = ? AND void_at IS NULL`, [now, user.name, now, dev, countUid, itemUid, user.uid]);
}
// Step 1 done: the counters hand it over. Lines over the tolerance are recounted first (once).
export function submitCount(user, countUid, { restZero } = {}) {
  requirePerm(user, ['stocktake_count', 'shop_staff']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c0 = getCount(countUid);
  need(c0 && c0.status === 'counting', 'This stock take is not open for counting.');
  need(c0.summary.counted > 0, 'Nothing has been counted yet.');
  const { now, dev } = meta();
  if (restZero !== undefined) db().run(`UPDATE inv_counts SET uncounted = ?, ${SYNCED} WHERE uid = ?`, [restZero ? 'zero' : 'leave', now, dev, countUid]);
  const c = getCount(countUid);
  const second = c.lines.filter((l) => l.needsSecond);
  need(!second.length, `These must be counted a second time by another person: ${second.slice(0, 8).map((l) => l.name).join(', ')}${second.length > 8 ? '…' : ''}.`);
  const mism = c.lines.filter((l) => l.mismatch);
  if (mism.length) {
    for (const l of mism) { db().run(`UPDATE inv_count_lines SET first_count = ?, counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE uid = ?`, [l.counted, now, dev, l.uid]); voidEntriesFor(user, countUid, l.item_uid, 'count again'); }
    audit({ user, action: `Stock take "${c.name}": the two counts differ for ${mism.length} products – count them again`, table: 'inv_counts', recordUid: countUid });
    return { recount: mism.map((l) => ({ itemUid: l.item_uid, name: `${l.name} (the two counts differ)` })), count: getCount(countUid) };
  }
  const recount = c.lines.filter((l) => l.needsRecount);
  if (recount.length) {
    for (const l of recount) { db().run(`UPDATE inv_count_lines SET first_count = ?, counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE uid = ?`, [l.counted, now, dev, l.uid]); voidEntriesFor(user, countUid, l.item_uid, 'count again'); }
    audit({ user, action: `Stock take "${c.name}": ${recount.length} products are well off – count them again`, table: 'inv_counts', recordUid: countUid });
    return { recount: recount.map((l) => ({ itemUid: l.item_uid, name: l.name })), count: getCount(countUid) };
  }
  db().run(`UPDATE inv_counts SET status = 'review', submitted_at = ?, submitted_by_name = ?, ${SYNCED} WHERE uid = ?`, [now, user.name, now, dev, countUid]);
  audit({ user, action: `Stock take "${c.name}" counted (${c.summary.counted} of ${c.summary.products}), waiting for approval`, table: 'inv_counts', recordUid: countUid });
  return { recount: [], count: getCount(countUid) };
  });
}
// The approver sends some products back for counting again.
export function requestRecount(user, countUid, itemUids, reason) {
  requirePerm(user, 'stocktake_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid, { withLines: false });
  need(c && ['review', 'counting'].includes(c.status), 'This stock take is closed.');
  need((itemUids || []).length, 'Choose the products to count again.');
  const { now, dev } = meta();
  const cur = getCount(countUid);
  for (const id of itemUids) {
    const ln = cur.lines.find((x) => x.item_uid === id);
    db().run(`UPDATE inv_count_lines SET first_count = COALESCE(?, first_count), counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [ln ? ln.counted : null, now, dev, countUid, id]);
    voidEntriesFor(user, countUid, id, 'count again');
  }
  db().run(`UPDATE inv_counts SET status = 'counting', ${SYNCED} WHERE uid = ?`, [now, dev, countUid]);
  audit({ user, action: `Asked for a recount of ${itemUids.length} products in "${c.name}"`, table: 'inv_counts', recordUid: countUid, reason: txt(reason) || null });
  });
}
// Step 2: approve and post. The stock of each counted product becomes what was counted; the stock is unfrozen.
export function postCount(user, countUid, { note } = {}) {
  requirePerm(user, 'stocktake_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid);
  need(c && c.status === 'review', c && c.status === 'counting' ? 'The counters have not finished yet.' : 'This stock take is not waiting for approval.');
  const rules = invRules();
  const boss = !reasonRequired(user);
  const first = c.kind === 'initial'; // the opening stock: no loss limit or reasons (nothing to compare with)
  need(first || boss || -c.summary.loss <= rules.countApproveOver + 0.004, `The loss is ${$(-c.summary.loss)} – over ${$(rules.countApproveOver)}, so the owner or admin approves it.`);
  const noWhy = c.lines.filter((l) => Math.abs(l.variance) > 1e-9 && !l.reason && (Math.abs(l.variance) > rules.countTolerance + 1e-9 && Math.abs(l.value) > rules.countValueTolerance + 0.004));
  need(first || boss || !noWhy.length, `Give a reason for: ${noWhy.slice(0, 8).map((l) => l.name).join(', ')}${noWhy.length > 8 ? '…' : ''}.`);
  const { now, dev } = meta();
  for (const l of c.lines) {
    // The totals at this moment are kept on the lines (the stock take's results never change after posting).
    db().run(`UPDATE inv_count_lines SET expected = ?, counted = ?, counted_by_name = ?, ${SYNCED} WHERE uid = ?`, [l.expected, l.counted, l.counted_by_name || null, now, dev, l.uid]);
    if (c.kind === 'initial' && l.counted !== null && l.counted > 0) ensureItemShop(l.item_uid, c.shop_code);
    if (Math.abs(l.variance) > 1e-9) {
      addMove({ itemUid: l.item_uid, shopCode: c.shop_code, date: c.count_date, type: 'count', qty: l.variance, unitCost: l.cost, refType: 'count', refUid: countUid,
        reason: `${l.reason ? `${l.reason} – ` : ''}stock take: counted ${fmtQ(l.counted === null ? 0 : l.counted)}, expected ${fmtQ(l.expected)}`, note: l.reason || null, user });
    }
  }
  // How many counts went in – a count arriving later (a phone that was offline) is then flagged, never silently lost.
  const inNow = has('inv_count_entries') ? db().get(`SELECT COUNT(*) AS n, COALESCE(SUM(e.qty),0) AS q FROM inv_count_entries e WHERE e.count_uid = ? AND ${LIVE}`, [countUid]) : { n: 0, q: 0 };
  const result = { ...c.summary, postedBy: user.name, entriesIn: inNow.n, qtyIn: q3(inNow.q) };
  db().run(`UPDATE inv_counts SET status = 'posted', posted_at = ?, posted_by_name = ?, result = ?, notes = ?, ${SYNCED} WHERE uid = ?`,
    [now, user.name, JSON.stringify(result), txt(note) || null, now, dev, countUid]);
  if (c.kind === 'initial') { try { setAppMaster(user, c.shop_code, true); } catch (e) { /* a setting only */ } }
  audit({ user, action: `Posted stock take "${c.name}": ${c.summary.short} short, ${c.summary.over} over, net ${$(c.summary.net)}, accuracy ${c.summary.accuracy}%`, table: 'inv_counts', recordUid: countUid, reason: txt(note) || null });
  return getCount(countUid);
  });
}
export function cancelCount(user, countUid, reason) {
  requirePerm(user, 'stocktake_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getCount(countUid, { withLines: false });
  need(c && ['counting', 'review'].includes(c.status), 'This stock take is already closed.');
  needReason(user, reason, 'Say why it is cancelled.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_counts SET status = 'cancelled', notes = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, countUid]);
  audit({ user, action: `Cancelled stock take "${c.name}" – stock unfrozen, nothing changed`, table: 'inv_counts', recordUid: countUid, reason: txt(reason) });
  });
}
// Rolling (cycle) counts: products not counted for a while, the most valuable / fastest first.
export function cycleSuggestions(shopCode, { max = 40, today = dateStr() } = {}) {
  const rules = invRules();
  const cutoff = addDays(today, -rules.cycleDays);
  return stockList({ shopCode, today }).filter((r) => !r.last_counted || r.last_counted < cutoff)
    .sort((a, b) => (b.value + b.sold * b.cost) - (a.value + a.sold * a.cost)).slice(0, max);
}

// ---------------------------------------------------------------- summaries
export function stockValue(shopCode) {
  // 1.0.0 each product's stock from the index of its own movements (ix_invm_itype), not the whole shop's history
  const r = db().get(`SELECT COALESCE(SUM(CASE WHEN q > 0 THEN q * cost ELSE 0 END),0) AS v, COUNT(*) AS n, SUM(CASE WHEN q < 0 THEN 1 ELSE 0 END) AS neg FROM
    (SELECT i.cost, (SELECT SUM(m.qty) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.status = 'active') AS q FROM inv_items i) WHERE q IS NOT NULL`, [shopCode]);
  return { value: r2(r.v), products: r.n, negative: r.neg || 0 };
}
// Loss per shop in a period: write-offs, stock-take differences and transfer shortages (at cost).
export function shrinkage({ shopCode, from, to }) {
  const rows = db().all(`SELECT m.type, CASE WHEN m.type = 'count' THEN COALESCE(m.note, '') ELSE m.reason END AS reason, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v, SUM(m.qty) AS q, COUNT(*) AS n
    FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
    WHERE m.shop_code = ? AND m.status = 'active' AND m.type IN ('adjust','count') AND m.move_date BETWEEN ? AND ? GROUP BY m.type, 2 ORDER BY v`, [shopCode, from, to]);
  const transit = db().get("SELECT COALESCE(SUM(short_value),0) AS v FROM inv_transfers WHERE to_shop = ? AND status = 'received' AND receive_date BETWEEN ? AND ?", [shopCode, from, to]).v;
  const byReason = rows.map((r) => ({ type: r.type, reason: r.type === 'count' ? (r.reason ? `Stock take – ${r.reason}` : 'Stock take differences') : r.reason, value: r2(r.v), qty: q3(r.q), times: r.n }));
  // 1.0.0 build 4: pack-ups that made fewer packs than usual (spilt, short weight, taken), at the packs' cost
  try { const rp = require('./repack.js').repackShortfall({ shopCode, from, to }); if (rp.times) byReason.push({ type: 'repack', reason: 'Repacking – fewer packs than usual', value: r2(-rp.value), qty: q3(-rp.qty), times: rp.times }); } catch (e) { /* no repacking */ }
  const total = r2(byReason.reduce((s, r) => s + r.value, 0) - transit);
  return { byReason, transitShort: r2(transit), total };
}
// Losses per product (write-offs and stock-take differences), biggest first, with the reasons given.
export function shrinkageByProduct({ shopCode, from, to, limit = 50 } = {}) {
  return db().all(`SELECT m.item_uid, i.code, i.name, i.group_name, m.shop_code, SUM(m.qty) AS q, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v, COUNT(*) AS n,
    GROUP_CONCAT(DISTINCT CASE WHEN m.type = 'count' THEN m.note ELSE m.reason END) AS reasons
    FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.status = 'active' AND m.type IN ('adjust','count') AND m.qty < 0 AND m.move_date BETWEEN ? AND ?
    AND (? IS NULL OR m.shop_code = ?) GROUP BY m.item_uid, m.shop_code ORDER BY v LIMIT ?`, [from, to, shopCode || null, shopCode || null, limit])
    .map((r) => ({ ...r, q: q3(r.q), v: r2(r.v), reasons: String(r.reasons || '').split(',').filter(Boolean) }));
}
// Products short again and again: short in at least `min` of their last `last` posted stock takes.
export function repeatLosers({ shopCode, last = 5, min = 3 } = {}) {
  // 1.0.0 every stock take ever (3 years): kept until a stock take or product changes
  const rows = keptAll(`SELECT l.item_uid, i.name, i.code, c.shop_code, c.count_date, (COALESCE(l.counted, 0) - l.expected) AS diff, l.cost FROM inv_count_lines l JOIN inv_counts c ON c.uid = l.count_uid
    JOIN inv_items i ON i.uid = l.item_uid WHERE c.status = 'posted' AND l.counted IS NOT NULL AND (? IS NULL OR c.shop_code = ?) ORDER BY c.count_date DESC`, [shopCode || null, shopCode || null]);
  const by = {};
  rows.forEach((r) => { const k = `${r.item_uid}|${r.shop_code}`; (by[k] = by[k] || []).push(r); });
  return Object.values(by).map((list) => {
    const recent = list.slice(0, last);
    const short = recent.filter((r) => r.diff < -1e-9);
    return { itemUid: recent[0].item_uid, name: recent[0].name, code: recent[0].code, shopCode: recent[0].shop_code, counts: recent.length, short: short.length,
      lost: r2(short.reduce((s, r) => s + r.diff * (r.cost || 0), 0)) };
  }).filter((x) => x.short >= min).sort((a, b) => a.lost - b.lost);
}
// High-value products (counted twice) not counted for a while – a short count every week keeps them honest.
export function highValueDue(shopCode, { today = dateStr() } = {}) {
  const rules = invRules();
  const cutoff = addDays(today, -rules.cycleHighValueDays);
  return stockList({ shopCode, today }).filter((r) => needsDouble(r, rules) && (r.on_hand || 0) > 0 && (!r.last_counted || r.last_counted < cutoff));
}
// Write-offs worth checking: big ones, and people / products with many of them.
export function writeOffWatch({ from, to, shopCode } = {}) {
  const rules = invRules();
  const rows = db().all(`SELECT m.*, i.code, i.name FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.type = 'adjust' AND m.status = 'active' AND m.qty < 0
    AND m.move_date BETWEEN ? AND ? AND (? IS NULL OR m.shop_code = ?) ORDER BY m.move_date DESC`, [from, to, shopCode || null, shopCode || null]);
  const big = rows.filter((m) => Math.abs(m.qty * (m.unit_cost || 0)) > rules.writeOffApproveOver);
  const group = (key) => Object.values(rows.reduce((acc, m) => {
    const k = m[key] || '—';
    acc[k] = acc[k] || { key: k, times: 0, value: 0 };
    acc[k].times += 1; acc[k].value = r2(acc[k].value + Math.abs(m.qty * (m.unit_cost || 0)));
    return acc;
  }, {})).sort((a, b) => b.value - a.value);
  return { big, byPerson: group('by_name'), byProduct: group('name'), total: r2(rows.reduce((s, m) => s + Math.abs(m.qty * (m.unit_cost || 0)), 0)) };
}
export function invAlerts(shopCodes = []) {
  const out = [];
  const unseen = db().get('SELECT COUNT(*) AS n FROM inv_cost_changes WHERE seen_at IS NULL').n;
  if (unseen) out.push({ tone: 'warn', text: `${unseen} cost price change${unseen === 1 ? '' : 's'} to look at`, go: 'CostChanges' });
  const awaiting = db().get("SELECT COUNT(*) AS n FROM po_orders WHERE status = 'awaiting'").n;
  if (awaiting) out.push({ tone: 'warn', text: `${awaiting} purchase order${awaiting === 1 ? '' : 's'} waiting for approval`, go: 'POList' });
  const transfers = db().get("SELECT COUNT(*) AS n FROM inv_transfers WHERE status = 'sent'").n;
  if (transfers) out.push({ tone: 'info', text: `${transfers} transfer${transfers === 1 ? '' : 's'} between shops not yet received`, go: 'Transfers' });
  const review = db().get("SELECT COUNT(*) AS n FROM inv_counts WHERE status = 'review'").n;
  if (review) out.push({ tone: 'warn', text: `${review} stock take${review === 1 ? '' : 's'} waiting for approval`, go: 'StockTakes' });
  const counting = db().get("SELECT COUNT(*) AS n FROM inv_counts WHERE status = 'counting'").n;
  if (counting) out.push({ tone: 'info', text: `Stock take under way – that stock is frozen`, go: 'StockTakes' });
  // Counts that reached this device after their stock take was approved (a phone that was offline): not in the stock.
  try { out.push(...lateCounts().map((x) => ({ tone: 'warn', text: `${x.name}: ${x.n} count${x.n === 1 ? '' : 's'} arrived after it was approved – not in the stock. Check and adjust if needed.`, go: 'StockCount', params: { uid: x.uid } }))); } catch (e) { /* none */ }
  const late = db().get("SELECT COUNT(*) AS n FROM po_orders WHERE status IN ('sent','approved') AND expected_date < ?", [dateStr()]).n;
  if (late) out.push({ tone: 'warn', text: `${late} order${late === 1 ? '' : 's'} past the delivery date`, go: 'POList' });
  for (const s of shopCodes) {
    const low = db().get(`SELECT COUNT(*) AS n FROM inv_item_shops s JOIN inv_items i ON i.uid = s.item_uid AND i.active = 1
      WHERE s.shop_code = ? AND s.active = 1 AND s.reorder_level > 0 AND (SELECT COALESCE(SUM(qty),0) FROM inv_moves m WHERE m.item_uid = s.item_uid AND m.shop_code = s.shop_code AND m.status = 'active') <= s.reorder_level`, [s]).n;
    if (low) out.push({ tone: 'info', text: `${s}: ${low} product${low === 1 ? '' : 's'} at or below the reorder level`, go: 'InvStock', params: { shopCode: s, filter: 'low' } });
    // v3.9: stock below zero means a delivery was not entered, sales were counted twice, or a miscount.
    const neg = db().get("SELECT COUNT(*) AS n FROM (SELECT item_uid FROM inv_moves WHERE shop_code = ? AND status = 'active' GROUP BY item_uid HAVING SUM(qty) < -0.001)", [s]).n;
    if (neg) out.push({ tone: 'warn', text: `${s}: ${neg} product${neg === 1 ? ' shows' : 's show'} less than nothing in stock – a delivery not entered, or a miscount`, go: 'InvStock', params: { shopCode: s, filter: 'negative' } });
  }
  return out;
}

// ---------------------------------------------------------------- v3.9.3 several suppliers per product
const itemSupUid = (itemUid, supplierUid) => `ISUP-${itemUid}-${supplierUid}`;
// v3.9.8 a supplier's products (linked by deliveries and invoices received, the Drive invoices, or by hand), with
// their code, last price and date – for the order screen and the supplier's page.
export function supplierProducts(supplierUid, { shopCode, q = '', limit = 500 } = {}) {
  if (!supplierUid) return [];
  const linked = has('inv_item_suppliers') ? db().all('SELECT item_uid, supplier_code, last_cost, last_date FROM inv_item_suppliers WHERE supplier_uid = ? AND active = 1', [supplierUid]) : [];
  const by = new Map(linked.map((x) => [x.item_uid, x]));
  db().all('SELECT uid FROM inv_items WHERE supplier_uid = ? AND active = 1 AND removed_at IS NULL', [supplierUid]).forEach((x) => { if (!by.has(x.uid)) by.set(x.uid, { item_uid: x.uid }); });
  const qq = txt(q).toLowerCase();
  const out = [];
  for (const [uid, x] of by) {
    const it = getItem(uid);
    if (!it || !it.active || it.removed_at) continue;
    if (qq && !(`${it.name} ${it.code} ${it.barcode || ''} ${x.supplier_code || ''}`.toLowerCase().includes(qq))) continue;
    out.push({ ...it, supplierCode: x.supplier_code || null, lastCost: x.last_cost ?? null, lastDate: x.last_date || null, on_hand: shopCode ? stockOf(uid, shopCode) : null });
  }
  return out.sort((a, b) => String(a.name).localeCompare(String(b.name))).slice(0, limit);
}
// Products no supplier has been linked to yet (what is left to sort).
export function productsWithoutSupplier({ limit = 2000 } = {}) {
  const linked = new Set(has('inv_item_suppliers') ? db().all('SELECT DISTINCT item_uid FROM inv_item_suppliers WHERE active = 1').map((x) => x.item_uid) : []);
  return db().all('SELECT uid, code, name, group_name, cost, price FROM inv_items WHERE active = 1 AND removed_at IS NULL AND (supplier_uid IS NULL OR supplier_uid = \'\') ORDER BY name')
    .filter((x) => !linked.has(x.uid)).slice(0, limit);
}
export function itemSuppliers(itemUid) {
  const it = getItem(itemUid);
  const rows = has('inv_item_suppliers') ? db().all('SELECT x.*, s.name AS supplier_name FROM inv_item_suppliers x LEFT JOIN ap_suppliers s ON s.uid = x.supplier_uid WHERE x.item_uid = ? AND x.active = 1 ORDER BY s.name', [itemUid]) : [];
  const out = rows.map((r) => ({ ...r, main: !!(it && it.supplier_uid === r.supplier_uid) }));
  if (it && it.supplier_uid && !out.some((r) => r.supplier_uid === it.supplier_uid)) {
    const sp = getSupplier(it.supplier_uid);
    if (sp) out.unshift({ uid: null, item_uid: itemUid, supplier_uid: sp.uid, supplier_name: sp.name, main: true, last_cost: null, last_date: null, supplier_code: null });
  }
  return out.sort((a, b) => (b.main ? 1 : 0) - (a.main ? 1 : 0));
}
// Remember that a product comes from a supplier (with their price and date). Called when a delivery is received.
export function noteItemSupplier(itemUid, supplierUid, { cost, date, code } = {}) {
  if (!has('inv_item_suppliers') || !itemUid || !supplierUid) return;
  const { now, dev } = meta();
  const uid = itemSupUid(itemUid, supplierUid);
  db().run(`INSERT INTO inv_item_suppliers (uid, item_uid, supplier_uid, supplier_code, last_cost, last_date, active, updated_at, updated_device) VALUES (?,?,?,?,?,?,1,?,?)
    ON CONFLICT(uid) DO UPDATE SET active = 1, supplier_code = COALESCE(excluded.supplier_code, supplier_code), last_cost = COALESCE(excluded.last_cost, last_cost),
    last_date = COALESCE(excluded.last_date, last_date), updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, itemUid, supplierUid, txt(code) || null, cost === undefined || cost === null || cost === '' ? null : r4(cost), txt(date) || null, now, dev]);
  const it = getItem(itemUid);
  if (it && !it.supplier_uid) db().run(`UPDATE inv_items SET supplier_uid = ?, ${SYNCED} WHERE uid = ?`, [supplierUid, now, dev, itemUid]);
}
export function addItemSupplier(user, itemUid, supplierUid, { main = false, code, cost } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = getItem(itemUid); const sp = getSupplier(supplierUid);
  need(it, 'Product not found.'); need(sp, 'Choose the supplier.');
  noteItemSupplier(itemUid, supplierUid, { code, cost });
  if (main) { const { now, dev } = meta(); db().run(`UPDATE inv_items SET supplier_uid = ?, ${SYNCED} WHERE uid = ?`, [supplierUid, now, dev, itemUid]); }
  audit({ user, action: `${it.name}: ${main ? 'main supplier' : 'also from'} ${sp.name}`, table: 'inv_items', recordUid: itemUid });
  });
}
export function removeItemSupplier(user, itemUid, supplierUid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = getItem(itemUid);
  need(it, 'Product not found.');
  const { now, dev } = meta();
  if (has('inv_item_suppliers')) db().run(`UPDATE inv_item_suppliers SET active = 0, ${SYNCED} WHERE uid = ?`, [now, dev, itemSupUid(itemUid, supplierUid)]);
  if (it.supplier_uid === supplierUid) {
    const next = has('inv_item_suppliers') ? db().get('SELECT supplier_uid FROM inv_item_suppliers WHERE item_uid = ? AND active = 1 AND supplier_uid <> ? ORDER BY last_date DESC', [itemUid, supplierUid]) : null;
    db().run(`UPDATE inv_items SET supplier_uid = ?, ${SYNCED} WHERE uid = ?`, [next ? next.supplier_uid : null, now, dev, itemUid]);
  }
  audit({ user, action: `${it.name}: no longer from ${(getSupplier(supplierUid) || {}).name || supplierUid}`, table: 'inv_items', recordUid: itemUid });
  });
}

// Change a product's cost, this shop's selling price and the barcode in one go (e.g. during the first stock take).
export function quickEditItem(user, itemUid, { shopCode, cost, price, barcode, vatType } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = getItem(itemUid);
  need(it, 'Product not found.');
  const { now, dev } = meta();
  const changes = [];
  if (cost !== undefined && txt(cost) !== '' && Math.abs(r4(cost) - (Number(it.cost) || 0)) > 0.00005) {
    need(r4(cost) >= 0, 'The cost cannot be negative.');
    db().run(`UPDATE inv_items SET cost = ?, ${SYNCED} WHERE uid = ?`, [r4(cost), now, dev, itemUid]);
    logCostChange({ itemUid, oldCost: it.cost, newCost: r4(cost), source: 'stock take', supplierName: null, refUid: null, shopCode });
    changes.push(`cost ${$(it.cost)} → ${$(r4(cost))}`);
  }
  if (barcode !== undefined && txt(barcode) !== txt(it.barcode)) {
    const owner = txt(barcode) ? barcodeOwner(txt(barcode), itemUid) : null;
    need(!owner, `That barcode belongs to ${owner && owner.name}.`);
    db().run(`UPDATE inv_items SET barcode = ?, ${SYNCED} WHERE uid = ?`, [txt(barcode) || null, now, dev, itemUid]);
    changes.push(`barcode ${txt(it.barcode) || '—'} → ${txt(barcode) || '—'}`);
  }
  if (price !== undefined && txt(price) !== '' && shopCode) {
    const at = itemAtShop(itemUid, shopCode) || {};
    const cur = at.shopPrice !== undefined && at.shopPrice !== null ? at.shopPrice : it.price;
    if (Math.abs(r2(price) - (Number(cur) || 0)) > 0.004) {
      const row = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
      saveItemShop(null, { itemUid, shopCode, active: row ? !!row.active : true, reorderLevel: row ? row.reorder_level : 0, reorderQty: row ? row.reorder_qty : 0, price: r2(price), location: row ? row.location : null });
      changes.push(`${shopCode} price ${$(cur)} → ${$(r2(price))}`);
    }
  }
  if (vatType !== undefined && vatType !== it.vat_type) {
    need(['standard', 'zero', 'exempt'].includes(vatType), 'Choose VAT 12.5%, Zero rated or VAT free.');
    db().run(`UPDATE inv_items SET vat_type = ?, ${SYNCED} WHERE uid = ?`, [vatType, now, dev, itemUid]);
    if (hasVatCols()) db().run(`UPDATE inv_items SET vat_set_at = ?, ${SYNCED} WHERE uid = ?`, [now, now, dev, itemUid]);
    const L = { standard: 'VAT', zero: 'zero rated', exempt: 'VAT free' };
    changes.push(`${L[it.vat_type] || it.vat_type} → ${L[vatType]}`);
  }
  if (changes.length) audit({ user, action: `${it.name}: ${changes.join(', ')}`, table: 'inv_items', recordUid: itemUid });
  return changes;
  });
}
// Open first (initial) stock takes – any staff member may help count them.
export function openInitialCounts() {
  try { return db().all("SELECT * FROM inv_counts WHERE status = 'counting' AND kind = 'initial' ORDER BY count_date"); } catch (e) { return []; }
}

// ---------------------------------------------------------------- v3.9.3 VAT: the app and Aronium must agree
let vatCols = null;
function hasVatCols() { if (vatCols !== true) { try { vatCols = db().all('PRAGMA table_info(inv_items)').some((c) => c.name === 'aronium_vat'); } catch (e) { vatCols = false; } } return vatCols; }
const charged = (t) => (t === 'zero' || t === 'exempt' ? 'no' : 'yes');
export const VAT_LABEL = { standard: 'VAT 12.5%', zero: 'Zero rated', exempt: 'VAT free', none: 'No tax set' };
// Products where Aronium charges VAT and the app says none, or the other way round (from the last Aronium product import).
export function vatMismatches() {
  if (!hasVatCols()) return [];
  return db().all("SELECT uid, code, name, vat_type, aronium_vat, vat_set_at FROM inv_items WHERE active = 1 AND removed_at IS NULL AND aronium_vat IS NOT NULL ORDER BY name")
    .filter((r) => r.aronium_vat === 'none' || charged(r.vat_type) !== charged(r.aronium_vat));
}
// v3.9.7 products with no tax set at all in Aronium (each sale of them goes through with no VAT worked out).
export function noTaxInAronium() {
  return vatMismatches().filter((r) => r.aronium_vat === 'none');
}
// "Aronium is right": the app takes Aronium's VAT for this product.
export function useAroniumVat(user, itemUid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot change products.');
  const it = getItem(itemUid);
  need(it && it.aronium_vat, 'Aronium\'s VAT for this product is not known yet – import the products from Aronium.');
  need(it.aronium_vat !== 'none', 'This product has no tax set in Aronium. Set its tax in Aronium (Products › the product › Taxes) – the app picks it up at the next sync.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_items SET vat_type = ?, vat_set_at = NULL, ${SYNCED} WHERE uid = ?`, [it.aronium_vat, now, dev, itemUid]);
  audit({ user, action: `${it.name}: VAT taken from Aronium (${VAT_LABEL[it.aronium_vat]})`, table: 'inv_items', recordUid: itemUid });
  });
}

// v3.9.3 a product scanned during the first stock take that is not on the list: made new – or, when a product with
// that name is already there, the barcode is added to it (nothing about the existing product is overwritten).
export function addScannedProduct(user, countUid, { barcode, name, cost, price, vatType = 'standard' } = {}) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'inventory_manage') || ['owner', 'admin'].includes(user.role), 'You cannot add products.');
  need(txt(name), 'Type the product name.');
  need(txt(barcode), 'Scan the barcode.');
  const owner = barcodeOwner(txt(barcode));
  need(!owner, `That barcode is already on ${owner && owner.name}.`);
  const same = findItemByName(txt(name)) || getItem(itemUidFor(codeFromName(txt(name)).toUpperCase()));
  let uid;
  let added = false;
  if (same) {
    const { now, dev } = meta();
    db().run(`UPDATE inv_items SET barcode = ?, ${SYNCED} WHERE uid = ?`, [same.barcode ? `${same.barcode},${txt(barcode)}` : txt(barcode), now, dev, same.uid]);
    audit({ user, action: `${same.name}: barcode ${txt(barcode)} added (scanned in the stock take)`, table: 'inv_items', recordUid: same.uid });
    uid = same.uid;
  } else {
    const it = saveItem(user, { name: txt(name), barcode: txt(barcode), cost: cost || 0, price: price || 0, unit: 'each', vatType: ['standard', 'zero', 'exempt'].includes(vatType) ? vatType : 'standard' });
    uid = typeof it === 'string' ? it : it.uid;
    added = true;
  }
  addToCount(user, countUid, uid);
  return { uid, added, name: same ? same.name : txt(name) };
  });
}

// Posted stock takes (last 60 days) with more counts now than went in when approved.
// (Worked out again only when the counts or stock takes change – Home stays quick.)
let lateCache = { key: null, out: [] };
export function lateCounts() {
  if (!has('inv_count_entries')) return [];
  const since = addDays(dateStr(), -60);
  const key = JSON.stringify([db().get('SELECT COUNT(*) AS n, MAX(updated_at) AS m, COUNT(void_at) AS v FROM inv_count_entries'), db().get("SELECT COUNT(*) AS n, MAX(updated_at) AS m, SUM(LENGTH(result)) AS r FROM inv_counts WHERE status = 'posted'"), since]);
  if (lateCache.key === key) return lateCache.out;
  const out = [];
  for (const c of db().all("SELECT uid, name, result FROM inv_counts WHERE status = 'posted' AND count_date >= ?", [since])) {
    const r = J(c.result, {});
    if (r.entriesIn === undefined || r.entriesIn === null) continue;
    const now = db().get(`SELECT COUNT(*) AS n, COALESCE(SUM(e.qty),0) AS q FROM inv_count_entries e WHERE e.count_uid = ? AND ${LIVE}`, [c.uid]);
    // more counts, or the same number with a different total (a phone replaced its count after approval)
    const moreN = now.n - r.entriesIn;
    const qtyDiff = r.qtyIn === undefined ? 0 : q3(now.q - r.qtyIn);
    if (moreN > 0 || Math.abs(qtyDiff) > 1e-9) out.push({ uid: c.uid, name: c.name, n: Math.max(1, moreN), qtyDiff });
  }
  lateCache = { key, out };
  return out;
}
// "Seen – adjusted by hand (or not needed)": the late counts are noted and the warning goes.
export function ackLateCounts(user, countUid) {
  requirePerm(user, 'stocktake_approve'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'stocktake_approve') || ['owner', 'admin'].includes(user.role), 'Only a manager who approves stock takes can do this.');
  const c = db().get('SELECT * FROM inv_counts WHERE uid = ?', [countUid]);
  need(c && c.status === 'posted', 'Stock take not found.');
  const r = J(c.result, {});
  const x = db().get(`SELECT COUNT(*) AS n, COALESCE(SUM(e.qty),0) AS q FROM inv_count_entries e WHERE e.count_uid = ? AND ${LIVE}`, [countUid]);
  const { now, dev } = meta();
  db().run(`UPDATE inv_counts SET result = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify({ ...r, entriesIn: x.n, qtyIn: q3(x.q), lateSeenBy: user.name, lateSeenAt: now }), now, dev, countUid]);
  lateCache = { key: null, out: [] };
  audit({ user, action: `Stock take "${c.name}": late count(s) seen (${x.n} counts, ${fmtQ(q3(x.q))} in all now)`, table: 'inv_counts', recordUid: countUid });
  });
}
