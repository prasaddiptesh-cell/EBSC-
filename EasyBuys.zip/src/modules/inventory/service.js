// Inventory, purchase orders and stock takes.
// Every shop has its own stock. Stock is never typed over: it is the total of its movements
// (opening, received, sold, sent to / received from another shop, returned to supplier, written off, counted),
// so every unit can be traced to a person, a date and a reason.
// Sales come from Aronium through the main software (Aronium itself is only read, never written to).
// The main software sends one "sale" movement per product, per shop, per day with the id
//   SL-<shop>-<yyyy-mm-dd>-<product code>   (sending it again replaces it, it never doubles up)
// and products have the id IT-<product code>, so it does not need to know anything else about this app.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, getShared, setShared, money, weekStart } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { getSupplier, saveInvoice, apRules, getInvoice } from '../payables/service.js';
import { notify } from '../verify/service.js';
import { assertOpen } from '../../services/lock.js';
import { needReason, reasonRequired } from '../../services/access.js';
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
import { bakeryPart, postBakeryReceipts } from '../bakery/store.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
export const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";

// ---------------------------------------------------------------- rules (admin)
export const INV_DEFAULTS = {
  costMethod: 'last',          // 'last': cost = the latest price paid; 'average': weighted average of stock on hand and the delivery
  costFlagPct: 0,              // flag a cost change bigger than this % (0 = any change)
  salesDays: 28,               // reorder suggestions look at this many days of sales
  coverDays: 7,                // …and order enough for this many days after the delivery arrives
  defaultLeadDays: 2,          // days from ordering to delivery when the supplier has none set
  deadDays: 60,                // no sale for this many days = dead stock
  budgetMode: 'approve',       // over the supplier budget: 'warn' | 'approve' (needs po_approve) | 'block'
  approveOver: 0,              // any order over this total needs approval (0 = not needed)
  invoiceTolerance: 1,         // $ the supplier invoice may differ from what was received before it is flagged
  priceTolerancePct: 2,        // % a delivered unit cost may differ from the order before it is flagged
  countTolerance: 0,           // stock take: differences up to this many units are accepted without a recount
  countValueTolerance: 5,      // …or up to this many dollars
  blindCount: true,            // counters do not see how many the system expects
  uncounted: 'leave',          // products not counted in a stock take: 'leave' (no change) or 'zero'
  cycleDays: 90,               // rolling counts: suggest products not counted for this many days
  countApproveOver: 200,       // a stock-take loss bigger than this ($) is approved by the owner / admin only
  doubleCountGroups: ['Cigarettes', 'Tobacco', 'Liquor', 'Spirits', 'Beer', 'Wine'], // counted twice, by two people
  doubleCountCost: 0,          // …and any product costing at least this (0 = off)
  countReasons: ['Counting error', 'Damaged', 'Expired', 'Theft / missing', 'Delivery short', 'Aronium error', 'Found', 'Other'],
  cycleHighValueDays: 7,       // high-value products (counted twice) are due for a count after this many days
  writeOffApproveOver: 50,     // write-offs worth more than this show on the "to check" list
  adjustReasons: ['Damaged', 'Expired', 'Theft / missing', 'Own use / staff', 'Given away / sample', 'Found', 'Counting error', 'Other'],
  units: ['each', 'pack', 'carton', 'kg', 'g', 'litre', 'bottle', 'dozen', 'bag', 'tray'],
};
export function invRules() { return { ...INV_DEFAULTS, ...(getShared('inv_rules', {}) || {}) }; }
export function saveInvRules(user, r) {
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const clean = {
    costMethod: r.costMethod === 'average' ? 'average' : 'last',
    costFlagPct: n(r.costFlagPct, 0, 100, 'Cost change flag %'),
    salesDays: Math.round(n(r.salesDays, 7, 365, 'Days of sales')),
    coverDays: Math.round(n(r.coverDays, 1, 120, 'Days to cover')),
    defaultLeadDays: Math.round(n(r.defaultLeadDays, 0, 60, 'Delivery days')),
    deadDays: Math.round(n(r.deadDays, 7, 720, 'Dead stock days')),
    budgetMode: ['warn', 'approve', 'block'].includes(r.budgetMode) ? r.budgetMode : 'approve',
    approveOver: r2(n(r.approveOver || 0, 0, 10000000, 'Approve orders over')),
    invoiceTolerance: r2(n(r.invoiceTolerance, 0, 10000, 'Invoice tolerance')),
    priceTolerancePct: n(r.priceTolerancePct, 0, 100, 'Price tolerance %'),
    countTolerance: n(r.countTolerance, 0, 10000, 'Count tolerance'),
    countValueTolerance: r2(n(r.countValueTolerance, 0, 100000, 'Count value tolerance')),
    blindCount: !!r.blindCount,
    uncounted: r.uncounted === 'zero' ? 'zero' : 'leave',
    cycleDays: Math.round(n(r.cycleDays, 7, 720, 'Rolling count days')),
    countApproveOver: r2(n(r.countApproveOver === undefined ? 200 : r.countApproveOver, 0, 10000000, 'Owner approves stock-take losses over')),
    doubleCountGroups: list(r.doubleCountGroups === undefined ? INV_DEFAULTS.doubleCountGroups : r.doubleCountGroups),
    doubleCountCost: r2(n(r.doubleCountCost || 0, 0, 1000000, 'Count twice when the cost is at least')),
    countReasons: list(r.countReasons === undefined ? INV_DEFAULTS.countReasons : r.countReasons),
    cycleHighValueDays: Math.round(n(r.cycleHighValueDays === undefined ? 7 : r.cycleHighValueDays, 1, 365, 'High-value count days')),
    writeOffApproveOver: r2(n(r.writeOffApproveOver, 0, 1000000, 'Write-off check amount')),
    adjustReasons: list(r.adjustReasons),
    units: list(r.units),
  };
  need(clean.adjustReasons.length, 'Add at least one write-off reason.');
  const before = invRules();
  setShared('inv_rules', clean);
  audit({ user, action: 'Changed inventory rules', table: 'shared_settings', recordUid: 'inv_rules', before, after: clean });
  return clean;
}

const vatRate = () => Number(apRules().vatRate) || 12.5;
export const incVat = (cost, vatType) => r2(Number(cost || 0) * (vatType === 'zero' || vatType === 'exempt' ? 1 : 1 + vatRate() / 100));
export const itemUidFor = (code) => `IT-${String(code).trim().toUpperCase()}`;
const itemShopUid = (shop, itemUid) => `IS-${shop}-${itemUid}`;

// ---------------------------------------------------------------- products
export function getItem(uid) { return db().get('SELECT * FROM inv_items WHERE uid = ?', [uid]); }
export function findItem(codeOrBarcode) {
  const v = txt(codeOrBarcode);
  if (!v) return null;
  return db().get('SELECT * FROM inv_items WHERE upper(code) = upper(?) OR barcode = ? OR (barcode IS NOT NULL AND (barcode LIKE ? OR barcode LIKE ?)) ORDER BY active DESC LIMIT 1',
    [v, v, `${v},%`, `%,${v}`]);
}
export function findItemByName(name) {
  const v = txt(name);
  return v ? db().get('SELECT * FROM inv_items WHERE lower(trim(name)) = lower(?) ORDER BY active DESC LIMIT 1', [v]) : null;
}
// A product code for a product that has none in Aronium (SKU empty): the same name always gives the same code.
export function codeFromName(name) {
  const t = txt(name).toLowerCase().replace(/\s+/g, ' ');
  let h = 2166136261;
  for (let i = 0; i < t.length; i += 1) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return `N${h.toString(36).toUpperCase().padStart(7, '0')}`;
}
// Barcodes that Excel has rounded (13-digit numbers turned into e.g. 9416470000000): kept out and listed.
export function damagedBarcodes(rows) {
  const seen = {};
  rows.forEach((r) => (r.barcodes || []).forEach((b) => { (seen[b] = seen[b] || new Set()).add(r.name.toLowerCase()); }));
  const bad = new Set();
  for (const [b, names] of Object.entries(seen)) {
    const rounded = /^\d{11,14}$/.test(b) && /0{5,}$/.test(b);
    if (rounded || (names.size > 1 && /^\d{8,}$/.test(b))) bad.add(b);
  }
  return bad;
}
export function itemAtShop(itemUid, shopCode) {
  const it = getItem(itemUid);
  if (!it) return null;
  const s = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
  return { ...it, shop: s || null, shopPrice: s && s.price !== null && s.price !== undefined ? s.price : it.price, stocked: !!(s && s.active) };
}
export function listGroups() {
  return db().all("SELECT DISTINCT group_name AS g FROM inv_items WHERE group_name IS NOT NULL AND group_name <> '' ORDER BY group_name").map((r) => r.g);
}

// Things worth a second look before saving a product by hand (none of them stop the save).
export function productWarnings(f, uid = null) {
  const out = [];
  const name = txt(f.name);
  const other = name ? db().get('SELECT uid, code FROM inv_items WHERE lower(trim(name)) = lower(?) AND uid <> ?', [name, uid || '']) : null;
  if (other) out.push(`A product called "${name}" already exists (code ${other.code}).`);
  const cost = Number(f.cost) || 0;
  const price = Number(f.price) || 0;
  if (!price) out.push('No selling price yet.');
  else if (cost && price < cost) out.push(`The price (${price}) is below the cost (${cost}).`);
  if (!['standard', 'zero', 'exempt'].includes(f.vatType)) out.push('Choose the VAT type.');
  return out;
}
export function barcodeOwner(barcode, uid = null) {
  for (const b of String(barcode || '').split(/[,;|\s]+/).map((x) => x.trim()).filter(Boolean)) {
    const it = db().get('SELECT uid, name FROM inv_items WHERE uid <> ? AND (barcode = ? OR barcode LIKE ? OR barcode LIKE ? OR barcode LIKE ?)', [uid || '', b, `${b},%`, `%,${b}`, `%,${b},%`]);
    if (it) return { barcode: b, name: it.name, uid: it.uid };
  }
  return null;
}
// Products list for the Products screen. filter: all | app (added in the app, not in Aronium yet) | hidden.
export function listProducts({ q = '', group, filter = 'all', limit = 500 } = {}) {
  const where = [];
  const a = [];
  if (filter === 'app') where.push('aronium_seen IS NULL AND removed_at IS NULL');
  else if (filter === 'hidden') where.push('(active = 0 OR removed_at IS NOT NULL)');
  else where.push('active = 1 AND removed_at IS NULL');
  if (group) { where.push('group_name = ?'); a.push(group); }
  const t = txt(q);
  if (t) { where.push('(name LIKE ? OR code LIKE ? OR barcode LIKE ?)'); a.push(`%${t}%`, `%${t}%`, `%${t}%`); }
  return db().all(`SELECT * FROM inv_items WHERE ${where.join(' AND ')} ORDER BY name COLLATE NOCASE LIMIT ${Number(limit) || 500}`, a);
}
export function setWholesalePrice(user, uid, value) {
  const v = value === '' || value === null || value === undefined ? null : Math.round(Number(value) * 100) / 100;
  need(v === null || (Number.isFinite(v) && v >= 0), 'Wholesale price must be a number.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_items SET wholesale_price = ?, ${SYNCED} WHERE uid = ?`, [v, now, dev, uid]);
}
export function notInAroniumCount() {
  try { return db().get('SELECT COUNT(*) AS n FROM inv_items WHERE aronium_seen IS NULL AND removed_at IS NULL AND active = 1').n; } catch (e) { return 0; }
}

export function saveItem(user, f) {
  need(txt(f.name), 'Enter the product name.');
  // No code typed: one is made from the name (it changes to Aronium's code when the product is imported from Aronium).
  const code = (txt(f.code) || codeFromName(f.name)).toUpperCase();
  const uid = f.uid || itemUidFor(code);
  const dupe = barcodeOwner(f.barcode, uid);
  need(!dupe, `Barcode ${dupe && dupe.barcode} is already on "${dupe && dupe.name}". Each barcode can be on one product only.`);
  const clash = db().get('SELECT uid FROM inv_items WHERE upper(code) = ? AND uid <> ?', [code, uid]);
  need(!clash, `Product code ${code} is already used.`);
  const before = getItem(uid);
  const cost = r4(f.cost);
  const price = r2(f.price);
  need(cost >= 0 && price >= 0, 'Cost and price cannot be negative.');
  const { now, dev } = meta();
  const v = { code, barcode: txt(f.barcode) || null, name: txt(f.name), group_name: txt(f.groupName) || null, unit: txt(f.unit) || 'each', cost, price,
    vat_type: ['standard', 'zero', 'exempt'].includes(f.vatType) ? f.vatType : 'standard', supplier_uid: f.supplierUid || null,
    pack_size: Math.max(1, Number(f.packSize) || 1), active: f.active === false ? 0 : 1, notes: txt(f.notes) || null };
  if (before) {
    db().run(`UPDATE inv_items SET code=?, barcode=?, name=?, group_name=?, unit=?, cost=?, price=?, vat_type=?, supplier_uid=?, pack_size=?, active=?, notes=?, ${SYNCED} WHERE uid = ?`,
      [v.code, v.barcode, v.name, v.group_name, v.unit, v.cost, v.price, v.vat_type, v.supplier_uid, v.pack_size, v.active, v.notes, now, dev, uid]);
    if (Math.abs(before.cost - cost) > 0.00005) logCostChange({ itemUid: uid, oldCost: before.cost, newCost: cost, source: 'edit', supplierName: null, refUid: null, shopCode: null, user });
  } else {
    db().run(`INSERT INTO inv_items (uid, code, barcode, name, group_name, unit, cost, price, vat_type, supplier_uid, pack_size, active, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, v.code, v.barcode, v.name, v.group_name, v.unit, v.cost, v.price, v.vat_type, v.supplier_uid, v.pack_size, v.active, v.notes, now, dev]);
  }
  audit({ user, action: `${before ? 'Changed' : 'Added'} product ${code} ${v.name}`, table: 'inv_items', recordUid: uid,
    before: before && { cost: before.cost, price: before.price, name: before.name }, after: { cost, price, name: v.name } });
  return getItem(uid);
}

// The product at one shop: sold there, reorder level / quantity, the shop's own price, shelf location.
export function saveItemShop(user, { itemUid, shopCode, active = true, reorderLevel, reorderQty, price, location }) {
  need(getItem(itemUid), 'Product not found.');
  need(txt(shopCode), 'Choose the shop.');
  const lvl = Math.max(0, Number(reorderLevel) || 0);
  const qty = Math.max(0, Number(reorderQty) || 0);
  const p = price === '' || price === null || price === undefined ? null : r2(price);
  const { now, dev } = meta();
  const uid = itemShopUid(shopCode, itemUid);
  db().run(`INSERT INTO inv_item_shops (uid, item_uid, shop_code, active, reorder_level, reorder_qty, price, location, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET active=excluded.active, reorder_level=excluded.reorder_level, reorder_qty=excluded.reorder_qty, price=excluded.price, location=excluded.location,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, itemUid, shopCode, active ? 1 : 0, lvl, qty, p, txt(location) || null, now, dev]);
  if (user) audit({ user, action: `Product ${getItem(itemUid).code} at ${shopCode}: reorder at ${lvl}, order ${qty}${p !== null ? `, price ${$(p)}` : ''}`, table: 'inv_item_shops', recordUid: uid });
  return uid;
}
function ensureItemShop(itemUid, shopCode) {
  if (!db().get('SELECT 1 AS x FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode])) saveItemShop(null, { itemUid, shopCode });
}

// ---------------------------------------------------------------- CSV (Aronium export)
export function parseCsv(text) {
  const src = String(text || '').replace(/^﻿/, '');
  const firstLine = src.split(/\r?\n/)[0] || '';
  const delim = [',', ';', '\t'].map((d) => [d, firstLine.split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i];
    if (q) {
      if (c === '"' && src[i + 1] === '"') { cell += '"'; i += 1; } else if (c === '"') q = false; else cell += c;
    } else if (c === '"') q = true;
    else if (c === delim) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i += 1;
      row.push(cell); cell = '';
      if (row.some((x) => txt(x))) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some((x) => txt(x))) rows.push(row);
  return rows.map((r) => r.map((x) => x.trim()));
}
const num = (v) => {
  const s = txt(v).replace(/[$\s]/g, '');
  if (!s) return null;
  const neg = /^\(.*\)$/.test(s) || /-$/.test(s);
  // "1.234,50" (comma decimals) or "1,234.50"
  // A comma followed by 1-2 digits at the end is a decimal comma ("18,50", "1.234,50"); otherwise commas are thousands.
  const t = /,\d{1,2}$/.test(s) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
  const n = Number(t.replace(/[()-]/g, ''));
  return Number.isFinite(n) ? (neg ? -n : n) : null;
};
// "ProductGroup" / "IsEnabled" (Aronium's joined-up names) read as "product group" / "is enabled".
const norm = (h) => txt(h).replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

export const PRODUCT_FIELDS = [
  { key: 'code', label: 'Product code (SKU) – made for you if empty', guess: ['code', 'product code', 'item code', 'sku', 'plu', 'id', 'article', 'article code'] },
  { key: 'name', label: 'Name', need: true, guess: ['name', 'product', 'product name', 'item', 'item name', 'description', 'title'] },
  { key: 'barcode', label: 'Barcode', guess: ['barcode', 'barcodes', 'ean', 'upc', 'bar code'] },
  { key: 'group', label: 'Group', guess: ['group', 'product group', 'category', 'department', 'group name'] },
  { key: 'unit', label: 'Unit', guess: ['unit', 'measurement unit', 'unit of measure', 'uom', 'measure', 'measurement'] },
  { key: 'cost', label: 'Cost price', guess: ['cost', 'cost price', 'purchase price', 'last purchase price', 'buy price', 'unit cost', 'cost price excl tax'] },
  { key: 'price', label: 'Selling price', guess: ['price', 'sale price', 'selling price', 'retail price', 'price incl tax', 'sales price', 'price with tax'] },
  { key: 'wholesale', label: 'Wholesale price', guess: ['wholesale price', 'wholesale', 'price 2', 'price2', 'wholesale price incl tax', 'trade price'] },
  { key: 'tax', label: 'Tax / VAT', guess: ['tax', 'taxes', 'vat', 'tax rate', 'vat rate', 'tax name'] },
  { key: 'qty', label: 'Quantity in stock', guess: ['quantity', 'qty', 'stock', 'in stock', 'stock quantity', 'on hand', 'quantity in stock'] },
  { key: 'supplier', label: 'Supplier', guess: ['supplier', 'vendor', 'default supplier'] },
  { key: 'active', label: 'Active', guess: ['active', 'enabled', 'is enabled', 'status'] },
  { key: 'service', label: 'Service (not stock)', guess: ['is service', 'service'] },
];
export function guessMapping(headers, fields = PRODUCT_FIELDS) {
  const hs = headers.map(norm);
  const map = {};
  for (const f of fields) {
    let i = hs.findIndex((h) => f.guess.includes(h));
    if (i < 0) i = hs.findIndex((h) => f.guess.some((g) => h.startsWith(g)));
    if (i >= 0 && !Object.values(map).includes(i)) map[f.key] = i;
  }
  return map;
}
const vatTypeOf = (v) => {
  const s = txt(v).toLowerCase();
  if (!s) return 'standard';
  if (/zero|^0(\.0+)?%?$|exempt|none|no tax/.test(s)) return /exempt/.test(s) ? 'exempt' : 'zero';
  return 'standard';
};

// Products from an Aronium CSV export into one shop. Run with dryRun first to show what will change.
// openingStock: use the quantity column as this shop's stock (the difference is booked as "opening / import").
// fullList: the file is Aronium's whole product list – products imported before but missing now were deleted in Aronium
// and are hidden (never deleted; they come back if they reappear).
export const splitBarcodes = (v) => [...new Set(String(v || '').split(/[,;|\s]+/).map((x) => x.trim()).filter(Boolean))].join(',');
export function importProductsCsv(user, text, { shopCode, mapping, openingStock = false, setShopPrice = true, dryRun = false, fullList = false } = {}) {
  need(txt(shopCode), 'Choose the shop these products are for.');
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no product rows. Export the products from Aronium as CSV and try again.');
  const headers = rows[0];
  const map = mapping || guessMapping(headers);
  need(map.name !== undefined, 'Match the "Name" column first.');
  const get = (r, k) => (map[k] === undefined ? '' : txt(r[map[k]]));
  const out = { headers, mapping: map, total: rows.length - 1, added: 0, changed: 0, same: 0, costChanged: 0, stockSet: 0, errors: [], sample: [], hidden: 0, hiddenNames: [], frozen: [], back: 0,
    blank: 0, services: 0, servicesNames: [], damaged: [], oddCosts: [], madeCodes: 0 };
  const seen = new Set();
  const today = dateStr();
  // Barcodes rounded by Excel (shared by several products or ending in many zeros) are kept out and listed.
  const bad = damagedBarcodes(rows.slice(1).map((r) => ({ name: get(r, 'name'), barcodes: splitBarcodes(get(r, 'barcode')).split(',').filter(Boolean) })));
  for (let n = 1; n < rows.length; n += 1) {
    const r = rows[n];
    const name = get(r, 'name');
    if (!name) { out.blank += 1; continue; }
    if (map.service !== undefined && /^(1|true|yes)$/i.test(get(r, 'service'))) { out.services += 1; if (out.servicesNames.length < 20) out.servicesNames.push(name); continue; }
    const allBarcodes = splitBarcodes(get(r, 'barcode')).split(',').filter(Boolean);
    const goodBarcodes = allBarcodes.filter((b) => !bad.has(b));
    allBarcodes.filter((b) => bad.has(b)).forEach((b) => out.damaged.length < 200 && out.damaged.push({ name, barcode: b }));
    let code = get(r, 'code').toUpperCase();
    let byName = null;
    if (!code) {
      // No SKU in Aronium: a product already here with this name keeps its code; otherwise the first good barcode, or a code made from the name.
      byName = findItemByName(name);
      code = byName ? byName.code.toUpperCase() : (goodBarcodes[0] || codeFromName(name)).toUpperCase();
      out.madeCodes += 1;
    }
    if (seen.has(code)) { out.errors.push(`Row ${n + 1}: code ${code} is in the file twice (first one used)`); continue; }
    seen.add(code);
    const cost = num(get(r, 'cost'));
    const price = num(get(r, 'price'));
    const qty = num(get(r, 'qty'));
    const activeTxt = get(r, 'active').toLowerCase();
    const active = !activeTxt || !/^(0|false|no|inactive|disabled)$/.test(activeTxt);
    const uid = itemUidFor(code);
    // A product added by hand in the app (not from Aronium yet) is linked by its name the first time Aronium has it.
    const before = byName || getItem(uid) || findItem(code) || ((n2) => (n2 && n2.aronium_seen === null ? n2 : null))(findItemByName(name));
    if (price !== null && cost !== null && price > 0 && cost > price * 3) out.oddCosts.push(`${name}: cost ${cost} vs price ${price}`);
    const f = {
      uid: before ? before.uid : uid, code, name, barcode: goodBarcodes.join(',') || (before && before.barcode) || '', groupName: get(r, 'group') || (before && before.group_name) || '',
      unit: get(r, 'unit') || (before && before.unit) || 'each', cost: cost === null ? (before ? before.cost : 0) : cost,
      price: price === null ? (before ? before.price : 0) : price, vatType: map.tax !== undefined ? vatTypeOf(get(r, 'tax')) : (before ? before.vat_type : 'standard'),
      supplierUid: before ? before.supplier_uid : null, packSize: before ? before.pack_size : 1, active, notes: before ? before.notes : '',
    };
    const wholesale = map.wholesale !== undefined ? num(get(r, 'wholesale')) : before ? before.wholesale_price ?? null : null;
    const changed = !before || (map.wholesale !== undefined && (before.wholesale_price ?? null) !== wholesale) || !!before.removed_at || ['name', 'barcode', 'group_name', 'unit', 'vat_type'].some((k, i) => txt(before[k]) !== txt([f.name, f.barcode, f.groupName, f.unit, f.vatType][i]))
      || Math.abs(before.cost - f.cost) > 0.00005 || Math.abs(before.price - f.price) > 0.004 || !!before.active !== active;
    if (!before) out.added += 1; else if (changed) out.changed += 1; else out.same += 1;
    if (before && before.removed_at) out.back += 1;
    if (before && Math.abs(before.cost - f.cost) > 0.00005) out.costChanged += 1;
    if (out.sample.length < 8) out.sample.push({ code, name, cost: f.cost, price: f.price, qty, isNew: !before });
    if (openingStock && qty !== null) out.stockSet += 1;
    if (dryRun) continue;
    if (changed) saveItemQuiet(f, before);
    db().run('UPDATE inv_items SET wholesale_price = ?, aronium_seen = ?, removed_at = NULL WHERE uid = ?', [wholesale === null ? null : r2(wholesale), today, f.uid]);
    const itemUid = f.uid;
    const shopRow = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
    if (!shopRow || (setShopPrice && price !== null && Math.abs((shopRow.price ?? -1) - price) > 0.004) || !!shopRow.active !== active) {
      saveItemShop(null, { itemUid, shopCode, active, reorderLevel: shopRow ? shopRow.reorder_level : 0, reorderQty: shopRow ? shopRow.reorder_qty : 0,
        price: setShopPrice && price !== null ? price : shopRow ? shopRow.price : null, location: shopRow ? shopRow.location : null });
    }
    if (openingStock && qty !== null && frozenBy(itemUid, shopCode)) { out.frozen.push(name); continue; }
    if (openingStock && qty !== null) {
      const have = stockOf(itemUid, shopCode);
      const diff = q3(qty - have);
      if (Math.abs(diff) > 0.0005) addMove({ itemUid, shopCode, date: today, type: 'opening', qty: diff, unitCost: f.cost, refType: 'import', reason: 'Stock from Aronium CSV', user });
    }
  }
  if (fullList) {
    // Imported from Aronium before, not in this full list → deleted in Aronium → hidden here.
    const gone = db().all("SELECT uid, name FROM inv_items WHERE aronium_seen IS NOT NULL AND removed_at IS NULL AND active = 1").filter((it) => !seen.has(getItem(it.uid).code.toUpperCase()));
    out.hidden = gone.length;
    out.hiddenNames = gone.slice(0, 30).map((g) => g.name);
    if (!dryRun) {
      const { now, dev } = meta();
      for (const g of gone) db().run(`UPDATE inv_items SET active = 0, removed_at = ?, ${SYNCED} WHERE uid = ?`, [today, now, dev, g.uid]);
    }
  }
  if (!dryRun) {
    audit({ user, action: `Imported ${out.total} products into ${shopCode}${out.hidden ? ` (${out.hidden} hidden – deleted in Aronium)` : ''} (${out.added} new, ${out.changed} changed${openingStock ? `, stock set for ${out.stockSet}` : ''})`, table: 'inv_items' });
  }
  return out;
}
function saveItemQuiet(f, before) {
  const { now, dev } = meta();
  const v = [f.code, txt(f.barcode) || null, f.name, txt(f.groupName) || null, f.unit, r4(f.cost), r2(f.price), f.vatType, f.supplierUid || null, f.packSize || 1, f.active ? 1 : 0, txt(f.notes) || null];
  if (before) db().run(`UPDATE inv_items SET code=?, barcode=?, name=?, group_name=?, unit=?, cost=?, price=?, vat_type=?, supplier_uid=?, pack_size=?, active=?, notes=?, ${SYNCED} WHERE uid = ?`, v.concat([now, dev, f.uid]));
  else db().run('INSERT INTO inv_items (code, barcode, name, group_name, unit, cost, price, vat_type, supplier_uid, pack_size, active, notes, uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', v.concat([f.uid, now, dev]));
}

export const SALES_FIELDS = [
  { key: 'code', label: 'Product code', need: true, guess: ['code', 'product code', 'item code', 'sku', 'plu', 'id'] },
  { key: 'qty', label: 'Quantity sold', need: true, guess: ['quantity', 'qty', 'sold', 'quantity sold', 'units', 'units sold'] },
  { key: 'date', label: 'Date (if each row has one)', guess: ['date', 'day', 'sale date', 'document date'] },
  { key: 'amount', label: 'Sales amount', guess: ['total', 'amount', 'sales', 'total with tax', 'value', 'total incl tax'] },
];
// Until the main software sends sales by itself: an Aronium "products sold" CSV for one shop and one day.
// Sending the same day again replaces it (it never doubles up).
export function importSalesCsv(user, text, { shopCode, date, mapping, dryRun = false } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no rows.');
  const map = mapping || guessMapping(rows[0], SALES_FIELDS);
  need(map.code !== undefined && map.qty !== undefined, 'Match the "Product code" and "Quantity sold" columns first.');
  need(map.date !== undefined || DATE.test(txt(date)), 'Choose the day these sales are for.');
  const byKey = new Map();
  const out = { headers: rows[0], mapping: map, lines: 0, units: 0, unknown: [], days: new Set() };
  for (let n = 1; n < rows.length; n += 1) {
    const r = rows[n];
    const code = txt(r[map.code]).toUpperCase();
    const qty = num(r[map.qty]);
    if (!code || qty === null) continue;
    const d = map.date !== undefined ? toIsoDate(r[map.date]) || txt(date) : txt(date);
    if (!DATE.test(d)) continue;
    const it = getItem(itemUidFor(code)) || findItem(code);
    if (!it) { if (out.unknown.length < 50) out.unknown.push(code); continue; }
    const k = `${d}|${it.uid}`;
    byKey.set(k, { d, it, qty: q3((byKey.get(k)?.qty || 0) + qty) });
  }
  for (const { d, it, qty } of byKey.values()) {
    out.lines += 1; out.units = q3(out.units + qty); out.days.add(d);
    if (!dryRun) putSale({ shopCode, date: d, itemUid: it.uid, code: it.code, qty, unitCost: it.cost, by: user ? user.name : 'Import' });
  }
  out.days = [...out.days].sort();
  if (!dryRun) audit({ user, action: `Imported sales for ${shopCode} ${out.days.join(', ')}: ${out.lines} products, ${out.units} units`, table: 'inv_moves' });
  return out;
}
function toIsoDate(v) {
  const s = txt(v);
  let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = /^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/.exec(s);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
}
// One sale line per product, shop and day (the same id as the main software uses).
export function putSale({ shopCode, date, itemUid, code, qty, unitCost, by }) {
  assertOpen(date, 'These sales');
  const uid = `SL-${shopCode}-${date}-${code}`;
  const { now, dev } = meta();
  // Sales for a day already covered by a posted stock take arrive late: the count is the truth for that moment,
  // so the change is balanced with a stock-take correction (otherwise it would be taken off twice).
  const old = db().get("SELECT qty FROM inv_moves WHERE uid = ? AND status = 'active'", [uid]);
  const delta = q3(-Math.abs(q3(qty)) - (old ? old.qty : 0));
  if (Math.abs(delta) > 1e-9) {
    const c = db().get(`SELECT c.uid, c.count_date FROM inv_counts c JOIN inv_count_lines l ON l.count_uid = c.uid AND l.item_uid = ? AND l.counted IS NOT NULL
      WHERE c.shop_code = ? AND c.status = 'posted' AND (c.count_date > ? OR (c.count_date = ? AND c.timing = 'after_close')) ORDER BY c.count_date DESC LIMIT 1`, [itemUid, shopCode, date, date]);
    if (c) addMove({ itemUid, shopCode, date: c.count_date, type: 'count', qty: -delta, unitCost, refType: 'count_late_sale', refUid: c.uid, reason: `Sales of ${date} came in after the stock take of ${c.count_date}`, user: null });
  }
  db().run(`INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, ref_type, reason, by_name, status, created_at, updated_at, updated_device)
    VALUES (?,?,?,?, 'sale', ?, ?, 'aronium', 'Sales from Aronium', ?, 'active', ?, ?, ?)
    ON CONFLICT(uid) DO UPDATE SET qty = excluded.qty, unit_cost = excluded.unit_cost, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, itemUid, shopCode, date, -Math.abs(q3(qty)), r4(unitCost), by || null, now, now, dev]);
  ensureItemShop(itemUid, shopCode);
  return uid;
}

// Numbers that never clash between devices working offline: PO-261008-3K7 (date, number that day, device tag).
export function docNo(prefix, table, col) {
  const d = dateStr().replace(/-/g, '').slice(2);
  const tag = deviceId().replace(/[^A-Za-z0-9]/g, '').slice(-2).toUpperCase();
  const head = `${prefix}-${d}-`;
  const n = db().get(`SELECT COUNT(*) AS n FROM ${table} WHERE ${col} LIKE ?`, [`${head}%`]).n + 1;
  let no = `${head}${n}${tag}`;
  for (let k = n + 1; db().get(`SELECT 1 AS x FROM ${table} WHERE ${col} = ?`, [no]); k += 1) no = `${head}${k}${tag}`;
  return no;
}

// ---------------------------------------------------------------- movements & stock
export const MOVE_LABEL = {
  opening: 'Opening / import', receive: 'Received', sale: 'Sold', adjust: 'Write-off / adjustment', transfer_out: 'Sent to another shop',
  transfer_in: 'Received from another shop', return: 'Returned to supplier', count: 'Stock take', receive_void: 'Delivery voided',
  to_bakery: 'Into the Bakery stock',
};
const MANUAL = ['adjust', 'transfer_out', 'transfer_in', 'return', 'receive', 'opening'];

export function addMove({ itemUid, shopCode, date, type, qty, unitCost, refType, refUid, reason, note, user, uid }) {
  assertOpen(date, 'This stock movement');
  const { now, dev } = meta();
  const id = uid || uuid('MV');
  db().run(`INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, ref_type, ref_uid, reason, note, by_name, status, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [id, itemUid, shopCode, date, type, q3(qty), unitCost === null || unitCost === undefined ? null : r4(unitCost), refType || null, refUid || null, reason || null, note || null,
    user ? user.name : null, now, now, dev]);
  ensureItemShop(itemUid, shopCode);
  return id;
}
function voidMovesFor(refUid, reason) {
  db().all("SELECT move_date FROM inv_moves WHERE ref_uid = ? AND status = 'active'", [refUid]).forEach((m) => assertOpen(m.move_date, 'This stock movement'));
  const { now, dev } = meta();
  db().run(`UPDATE inv_moves SET status = 'void', void_reason = ?, ${SYNCED} WHERE ref_uid = ? AND status = 'active'`, [reason, now, dev, refUid]);
}

export function stockOf(itemUid, shopCode, asOf) {
  const r = db().get(`SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = ? AND status = 'active' AND (? IS NULL OR move_date <= ?)`,
    [itemUid, shopCode, asOf || null, asOf || null]);
  return q3(r.q);
}
export function onOrder(itemUid, shopCode) {
  const r = db().get(`SELECT COALESCE(SUM(MAX(l.qty - l.qty_received, 0)),0) AS q FROM po_lines l JOIN po_orders o ON o.uid = l.po_uid
    WHERE l.item_uid = ? AND o.shop_code = ? AND o.status IN ('approved','sent','part')`, [itemUid, shopCode]);
  return q3(r.q);
}

// The stock list for one shop. filter: 'all' | 'low' | 'out' | 'negative' | 'dead' | 'order' (needs ordering)
export function stockList({ shopCode, q = '', group, location, supplierUid, filter = 'all', limit = 2000, today = dateStr() } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const rules = invRules();
  const since = addDays(today, -rules.salesDays);
  const w = ["(s.active = 1 OR st.q <> 0)", 'i.active = 1'];
  const a = [];
  if (txt(q)) { const t = `%${txt(q).toLowerCase()}%`; w.push("(lower(i.name) LIKE ? OR lower(i.code) LIKE ? OR ifnull(i.barcode,'') LIKE ?)"); a.push(t, t, t); }
  if (group) { w.push('i.group_name = ?'); a.push(group); }
  if (location) { w.push('s.location = ?'); a.push(location); }
  if (supplierUid) { w.push('i.supplier_uid = ?'); a.push(supplierUid); }
  const rows = db().all(`
    SELECT i.*, s.reorder_level, s.reorder_qty, s.location, COALESCE(s.price, i.price) AS shop_price, s.active AS shop_active,
      COALESCE(st.q,0) AS on_hand, COALESCE(sl.q,0) AS sold, ls.d AS last_sale, lr.d AS last_received, COALESCE(oo.q,0) AS on_order, lc.d AS last_counted,
      sup.name AS supplier_name, COALESCE(sup.lead_days, ?) AS lead_days
    FROM inv_items i
    JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ?
    LEFT JOIN (SELECT item_uid, SUM(qty) AS q FROM inv_moves WHERE shop_code = ? AND status = 'active' GROUP BY item_uid) st ON st.item_uid = i.uid
    LEFT JOIN (SELECT item_uid, -SUM(qty) AS q FROM inv_moves WHERE shop_code = ? AND status = 'active' AND type = 'sale' AND move_date > ? AND move_date <= ? GROUP BY item_uid) sl ON sl.item_uid = i.uid
    LEFT JOIN (SELECT item_uid, MAX(move_date) AS d FROM inv_moves WHERE shop_code = ? AND status = 'active' AND type = 'sale' AND qty < 0 GROUP BY item_uid) ls ON ls.item_uid = i.uid
    LEFT JOIN (SELECT item_uid, MAX(move_date) AS d FROM inv_moves WHERE shop_code = ? AND status = 'active' AND type IN ('receive','transfer_in','opening') GROUP BY item_uid) lr ON lr.item_uid = i.uid
    LEFT JOIN (SELECT l.item_uid, SUM(MAX(l.qty - l.qty_received, 0)) AS q FROM po_lines l JOIN po_orders o ON o.uid = l.po_uid WHERE o.shop_code = ? AND o.status IN ('approved','sent','part') GROUP BY l.item_uid) oo ON oo.item_uid = i.uid
    LEFT JOIN (SELECT cl.item_uid, MAX(c.count_date) AS d FROM inv_count_lines cl JOIN inv_counts c ON c.uid = cl.count_uid WHERE c.shop_code = ? AND c.status = 'posted' AND cl.counted IS NOT NULL GROUP BY cl.item_uid) lc ON lc.item_uid = i.uid
    LEFT JOIN ap_suppliers sup ON sup.uid = i.supplier_uid
    WHERE ${w.join(' AND ')}
    ORDER BY i.name LIMIT ?`,
  [rules.defaultLeadDays, shopCode, shopCode, shopCode, since, today, shopCode, shopCode, shopCode, shopCode].concat(a, [limit]));
  const out = rows.map((r) => decorateStock(r, rules, today));
  if (filter === 'low') return out.filter((r) => r.low);
  if (filter === 'out') return out.filter((r) => r.on_hand <= 0);
  if (filter === 'negative') return out.filter((r) => r.on_hand < 0);
  if (filter === 'dead') return out.filter((r) => r.dead);
  if (filter === 'order') return out.filter((r) => r.suggest > 0);
  return out;
}
function decorateStock(r, rules, today) {
  const perDay = r.sold > 0 ? r.sold / rules.salesDays : 0;
  const lead = Number(r.lead_days) || 0;
  const want = perDay * (lead + rules.coverDays);
  const have = r.on_hand + r.on_order;
  let suggest = 0;
  if (have <= r.reorder_level || have < want) {
    suggest = Math.max(r.reorder_qty || 0, want + r.reorder_level - have);
    const pack = Math.max(1, Number(r.pack_size) || 1);
    suggest = suggest > 0 ? Math.ceil(suggest / pack - 1e-9) * pack : 0;
  }
  const daysLeft = perDay > 0 ? Math.floor(Math.max(0, r.on_hand) / perDay) : null;
  const refDate = r.last_sale || r.last_received;
  const idle = refDate ? Math.round((new Date(`${today}T00:00:00`) - new Date(`${refDate}T00:00:00`)) / 86400000) : null;
  const margin = r.shop_price > 0 ? r2(((r.shop_price - incVat(r.cost, r.vat_type)) / r.shop_price) * 100) : null;
  return {
    ...r, on_hand: q3(r.on_hand), on_order: q3(r.on_order), sold: q3(r.sold), perWeek: r2(perDay * 7), daysLeft, value: r2(Math.max(0, r.on_hand) * r.cost),
    low: r.on_hand <= r.reorder_level && (r.reorder_level > 0 || r.on_hand <= 0), suggest: q3(suggest), margin, belowCost: r.shop_price > 0 && incVat(r.cost, r.vat_type) >= r.shop_price,
    dead: r.on_hand > 0 && !r.sold && (idle === null || idle >= rules.deadDays), idleDays: idle,
  };
}

export function movesFor({ itemUid, shopCode, from, to, types, includeVoid = false, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (itemUid) { w.push('m.item_uid = ?'); a.push(itemUid); }
  if (shopCode) { w.push('m.shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('m.move_date >= ?'); a.push(from); }
  if (to) { w.push('m.move_date <= ?'); a.push(to); }
  if (types && types.length) { w.push(`m.type IN (${types.map(() => '?').join(',')})`); a.push(...types); }
  if (!includeVoid) w.push("m.status = 'active'");
  return db().all(`SELECT m.*, i.code, i.name, i.unit FROM inv_moves m LEFT JOIN inv_items i ON i.uid = m.item_uid WHERE ${w.join(' AND ')}
    ORDER BY m.move_date DESC, m.created_at DESC LIMIT ?`, a.concat([limit]));
}

// ---------------------------------------------------------------- frozen during a stock take
export function openCounts(shopCode) {
  return db().all("SELECT * FROM inv_counts WHERE shop_code = ? AND status IN ('counting','review')", [shopCode]);
}
function inScope(count, item, location) {
  const s = J(count.scope, {});
  if (s.groups && s.groups.length && !s.groups.includes(item.group_name)) return false;
  if (s.locations && s.locations.length && !s.locations.includes(location)) return false;
  if (s.itemUids && s.itemUids.length && !s.itemUids.includes(item.uid)) return false;
  return true;
}
export function frozenBy(itemUid, shopCode) {
  const counts = openCounts(shopCode);
  if (!counts.length) return null;
  const it = getItem(itemUid);
  const loc = db().get('SELECT location FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [itemUid, shopCode]);
  return counts.find((c) => {
    if (db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [c.uid, itemUid])) return true;
    return it && inScope(c, it, loc && loc.location);
  }) || null;
}
export function notFrozen(itemUid, shopCode) {
  const c = frozenBy(itemUid, shopCode);
  if (c) {
    const it = getItem(itemUid);
    throw new AppError(`${it ? it.name : 'This product'} is frozen at ${shopCode}: stock take "${c.name || c.count_date}" is under way. Post or cancel the stock take first.`);
  }
}

// ---------------------------------------------------------------- write-offs / adjustments
// qty is the change: negative takes stock off (damaged, expired…), positive adds (found).
export function adjustStock(user, { itemUid, shopCode, qty, reason, note, date, photos = [] }) {
  const it = getItem(itemUid);
  need(it, 'Choose the product.');
  need(txt(shopCode), 'Choose the shop.');
  const q = q3(qty);
  need(q !== 0, 'Enter how many (minus to take off, plus to add).');
  need(txt(reason), 'Choose the reason.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'The date cannot be in the future.');
  if (txt(reason) === 'Other') needReason(user, note, 'Say what happened.');
  notFrozen(itemUid, shopCode);
  const uid = addMove({ itemUid, shopCode, date: d, type: 'adjust', qty: q, unitCost: it.cost, refType: 'adjust', reason: txt(reason), note: txt(note), user });
  if (photos.length) addPhotos('inv_move', uid, photos);
  if (q < 0 && Math.abs(q) * it.cost > invRules().writeOffApproveOver) notify('big_writeoff', `Write-off: ${fmtQ(-q)} × ${it.name} = ${$(Math.abs(q) * it.cost)} (${txt(reason)}${txt(note) ? ` – ${txt(note)}` : ''}) by ${user.name}.`, { shopCode });
  audit({ user, action: `Stock ${q > 0 ? '+' : ''}${q} ${it.unit || ''} ${it.code} ${it.name} at ${shopCode} (${txt(reason)}) ${$(Math.abs(q) * it.cost)}`.replace(/\s+/g, ' '),
    table: 'inv_moves', recordUid: uid, reason: txt(note) || txt(reason) });
  return uid;
}
export function voidMove(user, uid, reason) {
  const m = db().get('SELECT * FROM inv_moves WHERE uid = ?', [uid]);
  need(m && m.status === 'active', 'Movement not found or already voided.');
  need(m.type === 'adjust' || m.type === 'opening', 'Only write-offs and opening stock can be voided here. Deliveries, transfers and stock takes are voided from their own screen.');
  needReason(user, reason, 'Say why it is being voided.');
  notFrozen(m.item_uid, m.shop_code);
  const { now, dev } = meta();
  assertOpen(m.move_date, 'This stock movement');
  db().run(`UPDATE inv_moves SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Voided stock movement ${m.type} ${m.qty}`, table: 'inv_moves', recordUid: uid, reason: txt(reason) });
}

// ---------------------------------------------------------------- transfers between shops (2 steps)
export function sendTransfer(user, { fromShop, toShop, date, lines, notes }) {
  need(txt(fromShop) && txt(toShop), 'Choose both shops.');
  need(fromShop !== toShop, 'Choose two different shops.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  const clean = (lines || []).map((l) => ({ itemUid: l.itemUid, qty: q3(l.qty) })).filter((l) => l.qty > 0);
  need(clean.length, 'Add at least one product.');
  const uid = uuid('TR');
  const no = docNo('TR', 'inv_transfers', 'transfer_no');
  let value = 0;
  const out = clean.map((l) => {
    const it = getItem(l.itemUid);
    need(it, 'A product on the list was not found.');
    notFrozen(l.itemUid, fromShop);
    notFrozen(l.itemUid, toShop);
    value += l.qty * it.cost;
    return { itemUid: it.uid, code: it.code, name: it.name, unit: it.unit, qty: l.qty, unitCost: it.cost, qtyReceived: null };
  });
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_transfers (uid, transfer_no, from_shop, to_shop, send_date, lines, value, status, sent_by_name, sent_at, notes, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?, 'sent', ?,?,?,?,?)`, [uid, no, fromShop, toShop, d, JSON.stringify(out), r2(value), user.name, now, txt(notes) || null, now, dev]);
  for (const l of out) addMove({ itemUid: l.itemUid, shopCode: fromShop, date: d, type: 'transfer_out', qty: -l.qty, unitCost: l.unitCost, refType: 'transfer', refUid: uid, reason: `${no} to ${toShop}`, user });
  audit({ user, action: `Sent ${no} ${fromShop} → ${toShop}: ${out.length} products ${$(value)}`, table: 'inv_transfers', recordUid: uid });
  return getTransfer(uid);
}
export function getTransfer(uid) {
  const t = db().get('SELECT * FROM inv_transfers WHERE uid = ?', [uid]);
  return t && { ...t, lines: J(t.lines, []) };
}
export function listTransfers({ shopCode, status, limit = 200 } = {}) {
  return db().all(`SELECT * FROM inv_transfers WHERE (? IS NULL OR from_shop = ? OR to_shop = ?) AND (? IS NULL OR status = ?) ORDER BY send_date DESC, sent_at DESC LIMIT ?`,
    [shopCode || null, shopCode || null, shopCode || null, status || null, status || null, limit]).map((t) => ({ ...t, lines: J(t.lines, []) }));
}
// Step 2: the other shop checks what actually arrived. received: { itemUid: qty } (missing = all arrived)
export function receiveTransfer(user, uid, { received = {}, date, note } = {}) {
  const t = getTransfer(uid);
  need(t && t.status === 'sent', 'This transfer is not waiting to be received.');
  const d = txt(date) || dateStr();
  need(d >= t.send_date, 'It cannot arrive before it was sent.');
  let short = 0;
  const lines = t.lines.map((l) => {
    const got = received[l.itemUid] === undefined || received[l.itemUid] === '' ? l.qty : q3(received[l.itemUid]);
    need(got >= 0, 'Quantities cannot be negative.');
    if (got < l.qty) short += (l.qty - got) * l.unitCost;
    return { ...l, qtyReceived: got };
  });
  if (short > 0.004) needReason(user, note, 'Some products did not arrive. Say what happened.');
  for (const l of lines) notFrozen(l.itemUid, t.to_shop);
  const { now, dev } = meta();
  for (const l of lines) if (l.qtyReceived > 0) addMove({ itemUid: l.itemUid, shopCode: t.to_shop, date: d, type: 'transfer_in', qty: l.qtyReceived, unitCost: l.unitCost, refType: 'transfer', refUid: uid, reason: `${t.transfer_no} from ${t.from_shop}`, user });
  db().run(`UPDATE inv_transfers SET status = 'received', lines = ?, received_by_name = ?, received_at = ?, receive_date = ?, short_value = ?, notes = ?, ${SYNCED} WHERE uid = ?`,
    [JSON.stringify(lines), user.name, now, d, r2(short), [t.notes, txt(note)].filter(Boolean).join(' / ') || null, now, dev, uid]);
  audit({ user, action: `Received ${t.transfer_no} at ${t.to_shop}${short > 0.004 ? `, short ${$(short)}` : ''}`, table: 'inv_transfers', recordUid: uid, reason: txt(note) || null });
  return getTransfer(uid);
}
export function voidTransfer(user, uid, reason) {
  const t = getTransfer(uid);
  need(t && t.status === 'sent', 'Only a transfer that has not been received can be cancelled.');
  needReason(user, reason, 'Say why.');
  for (const l of t.lines) notFrozen(l.itemUid, t.from_shop);
  voidMovesFor(uid, txt(reason));
  const { now, dev } = meta();
  db().run(`UPDATE inv_transfers SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled transfer ${t.transfer_no}`, table: 'inv_transfers', recordUid: uid, reason: txt(reason) });
}

// ---------------------------------------------------------------- supplier budgets
export function saveSupplierOrdering(user, { supplierUid, budgetWeekly, budgetMonthly, leadDays, viber, orderDays }) {
  const s = getSupplier(supplierUid);
  need(s, 'Supplier not found.');
  const bw = budgetWeekly === '' || budgetWeekly === null || budgetWeekly === undefined ? null : r2(budgetWeekly);
  const bm = budgetMonthly === '' || budgetMonthly === null || budgetMonthly === undefined ? null : r2(budgetMonthly);
  need((bw === null || bw >= 0) && (bm === null || bm >= 0), 'Budgets cannot be negative.');
  const ld = leadDays === '' || leadDays === null || leadDays === undefined ? null : Math.max(0, Math.round(Number(leadDays) || 0));
  const days = Array.isArray(orderDays) ? orderDays.join(',') : txt(orderDays) || null;
  const { now, dev } = meta();
  db().run(`UPDATE ap_suppliers SET budget_weekly = ?, budget_monthly = ?, lead_days = ?, viber = ?, order_days = ?, ${SYNCED} WHERE uid = ?`,
    [bw, bm, ld, txt(viber) || null, days, now, dev, supplierUid]);
  audit({ user, action: `Ordering for ${s.name}: weekly budget ${bw === null ? '—' : $(bw)}, monthly ${bm === null ? '—' : $(bm)}, delivery ${ld === null ? '—' : `${ld} days`}`,
    table: 'ap_suppliers', recordUid: supplierUid, before: { bw: s.budget_weekly, bm: s.budget_monthly }, after: { bw, bm } });
  return getSupplier(supplierUid);
}
const monthStart = (d) => `${d.slice(0, 7)}-01`;
const monthEnd = (d) => addDays(`${addMonth(d.slice(0, 7))}-01`, -1);
function addMonth(ym) { const [y, m] = ym.split('-').map(Number); return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; }

// Spent / committed with a supplier in the week (Sat–Fri) and month of `date`:
// approved orders (received or not) + their invoices that did not come through an order. Draft and cancelled orders do not count.
export function budgetUse(supplierUid, date = dateStr(), { exceptPo } = {}) {
  const s = getSupplier(supplierUid);
  const ws = weekStart(date);
  const we = addDays(ws, 6);
  const ms = monthStart(date);
  const me = monthEnd(date);
  const spent = (from, to) => {
    const po = db().get(`SELECT COALESCE(SUM(total),0) AS t FROM po_orders WHERE supplier_uid = ? AND status IN ('approved','sent','part','received','closed') AND order_date BETWEEN ? AND ? AND uid <> ?`,
      [supplierUid, from, to, exceptPo || '']).t;
    const inv = db().get(`SELECT COALESCE(SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END),0) AS t FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND po_uid IS NULL AND invoice_date BETWEEN ? AND ?`,
      [supplierUid, from, to]).t;
    return r2(po + inv);
  };
  const week = spent(ws, we);
  const month = spent(ms, me);
  return {
    supplier: s, weekStart: ws, weekEnd: we, monthStart: ms, monthEnd: me, week, month,
    weekBudget: s && s.budget_weekly !== null && s.budget_weekly !== undefined ? s.budget_weekly : null,
    monthBudget: s && s.budget_monthly !== null && s.budget_monthly !== undefined ? s.budget_monthly : null,
    weekLeft: s && s.budget_weekly !== null && s.budget_weekly !== undefined ? r2(s.budget_weekly - week) : null,
    monthLeft: s && s.budget_monthly !== null && s.budget_monthly !== undefined ? r2(s.budget_monthly - month) : null,
  };
}
export function budgetCheck(supplierUid, total, date = dateStr(), exceptPo) {
  const b = budgetUse(supplierUid, date, { exceptPo });
  const over = [];
  if (b.weekLeft !== null && total > b.weekLeft + 0.004) over.push(`week: ${$(b.weekBudget)} budget, ${$(b.week)} already, this order ${$(total)} → over by ${$(total - b.weekLeft)}`);
  if (b.monthLeft !== null && total > b.monthLeft + 0.004) over.push(`month: ${$(b.monthBudget)} budget, ${$(b.month)} already, this order ${$(total)} → over by ${$(total - b.monthLeft)}`);
  return { ...b, over, isOver: over.length > 0 };
}

// ---------------------------------------------------------------- purchase orders
export const PO_STATUS = { draft: 'Draft', awaiting: 'Waiting for approval', approved: 'Approved – not sent', sent: 'Sent to supplier', part: 'Part received', received: 'Received', closed: 'Closed (short)', cancelled: 'Cancelled' };

export function getPO(uid) {
  const o = db().get('SELECT * FROM po_orders WHERE uid = ?', [uid]);
  if (!o) return null;
  const lines = db().all('SELECT * FROM po_lines WHERE po_uid = ? ORDER BY sort, name', [uid]);
  const receipts = db().all("SELECT * FROM inv_receipts WHERE po_uid = ? ORDER BY receive_date, created_at", [uid]).map((r) => ({ ...r, lines: J(r.lines, []) }));
  const invoices = db().all("SELECT uid, invoice_no, invoice_date, total, status FROM ap_invoices WHERE po_uid = ? AND status <> 'void'", [uid]);
  const ordered = lines.reduce((s, l) => s + l.qty, 0);
  const got = lines.reduce((s, l) => s + Math.min(l.qty, l.qty_received), 0);
  return { ...o, lines, receipts, invoices, receivedPct: ordered > 0 ? Math.round((got / ordered) * 100) : 0,
    receivedValue: r2(receipts.filter((r) => r.status === 'active').reduce((s, r) => s + r.total, 0)), invoiced: r2(invoices.reduce((s, i) => s + i.total, 0)) };
}
export function listPOs({ shopCode, supplierUid, status, from, to, q = '', limit = 300 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (supplierUid) { w.push('supplier_uid = ?'); a.push(supplierUid); }
  if (status === 'open') w.push("status IN ('draft','awaiting','approved','sent','part')");
  else if (status === 'to_receive') w.push("status IN ('approved','sent','part')");
  else if (status) { w.push('status = ?'); a.push(status); }
  if (from) { w.push('order_date >= ?'); a.push(from); }
  if (to) { w.push('order_date <= ?'); a.push(to); }
  if (txt(q)) { w.push('(lower(po_no) LIKE ? OR lower(supplier_name) LIKE ?)'); a.push(`%${txt(q).toLowerCase()}%`, `%${txt(q).toLowerCase()}%`); }
  return db().all(`SELECT * FROM po_orders WHERE ${w.join(' AND ')} ORDER BY order_date DESC, created_at DESC LIMIT ?`, a.concat([limit]));
}

// Save a draft order (new or changed). lines: [{itemUid?, code?, name?, unit?, qty, unitCost}]
export function savePO(user, f) {
  const before = f.uid ? getPO(f.uid) : null;
  // Fully editable until it is sent to the supplier. A changed order goes back to draft and is approved again.
  need(!before || ['draft', 'awaiting', 'approved'].includes(before.status), 'This order has already been sent to the supplier. Cancel it and make a new one, or phone the supplier.');
  const s = getSupplier(f.supplierUid);
  need(s, 'Choose the supplier.');
  need(txt(f.shopCode), 'Choose the shop the order is for.');
  const date = txt(f.orderDate) || dateStr();
  need(DATE.test(date), 'Enter the order date.');
  const lines = (f.lines || []).map((l, i) => {
    const it = l.itemUid ? getItem(l.itemUid) : null;
    const name = it ? it.name : txt(l.name);
    const qty = q3(l.qty);
    const cost = r4(l.unitCost === undefined || l.unitCost === '' ? (it ? it.cost : 0) : l.unitCost);
    return { itemUid: it ? it.uid : null, code: it ? it.code : txt(l.code) || null, name, unit: it ? it.unit : txt(l.unit) || 'each', qty, unitCost: cost, note: txt(l.note) || null, sort: i };
  }).filter((l) => l.name && l.qty > 0);
  need(lines.length, 'Add at least one product with a quantity.');
  need(lines.every((l) => l.unitCost >= 0), 'Costs cannot be negative.');
  const total = r2(lines.reduce((t, l) => t + incVat(l.qty * l.unitCost, l.itemUid ? getItem(l.itemUid).vat_type : (s.vat_registered ? 'standard' : 'zero')), 0));
  const { now, dev } = meta();
  const uid = before ? before.uid : uuid('PO');
  const poNo = before ? before.po_no : docNo('PO', 'po_orders', 'po_no');
  if (before) {
    db().run(`UPDATE po_orders SET supplier_uid=?, supplier_name=?, shop_code=?, order_date=?, expected_date=?, status='draft', total=?, notes=?, budget_note=NULL, approved_by_name=NULL, approved_at=NULL, ${SYNCED} WHERE uid = ?`,
      [s.uid, s.name, f.shopCode, date, txt(f.expectedDate) || null, total, txt(f.notes) || null, now, dev, uid]);
    // Lines of a draft are replaced (a draft has nothing received against it).
    const old = db().all('SELECT uid FROM po_lines WHERE po_uid = ?', [uid]);
    old.forEach((l, i) => {
      const n = lines[i];
      if (n) db().run(`UPDATE po_lines SET item_uid=?, code=?, name=?, unit=?, qty=?, unit_cost=?, note=?, sort=?, ${SYNCED} WHERE uid = ?`, [n.itemUid, n.code, n.name, n.unit, n.qty, n.unitCost, n.note, n.sort, now, dev, l.uid]);
      else db().run(`UPDATE po_lines SET qty = 0, ${SYNCED} WHERE uid = ?`, [now, dev, l.uid]);
    });
    lines.slice(old.length).forEach((n) => insertLine(uid, n, now, dev));
  } else {
    db().run(`INSERT INTO po_orders (uid, po_no, supplier_uid, supplier_name, shop_code, order_date, expected_date, status, total, notes, created_by_name, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?, 'draft', ?,?,?,?,?,?)`,
    [uid, poNo, s.uid, s.name, f.shopCode, date, txt(f.expectedDate) || addDays(date, s.lead_days === null || s.lead_days === undefined ? invRules().defaultLeadDays : s.lead_days),
      total, txt(f.notes) || null, user.name, now, now, dev]);
    lines.forEach((n) => insertLine(uid, n, now, dev));
  }
  audit({ user, action: `${before ? 'Changed' : 'Made'} order ${poNo} ${s.name} ${f.shopCode} ${$(total)}`, table: 'po_orders', recordUid: uid });
  return getPO(uid);
}
function insertLine(poUid, n, now, dev) {
  db().run(`INSERT INTO po_lines (uid, po_uid, item_uid, code, name, unit, qty, unit_cost, qty_received, note, sort, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?)`,
    [uuid('PL'), poUid, n.itemUid, n.code, n.name, n.unit, n.qty, n.unitCost, n.note, n.sort, now, dev]);
}

// Draft → approved (or waiting for approval when over budget / over the limit).
// canApprove: the user has po_approve. reason: why it is OK to go over the budget.
export function submitPO(user, uid, { canApprove = false, reason } = {}) {
  const o = getPO(uid);
  need(o && ['draft', 'awaiting'].includes(o.status), 'This order is not a draft.');
  need(o.lines.some((l) => l.qty > 0), 'The order has no products.');
  const rules = invRules();
  const b = budgetCheck(o.supplier_uid, o.total, o.order_date, uid);
  const overLimit = rules.approveOver > 0 && o.total > rules.approveOver;
  const notes = [];
  if (b.isOver) notes.push(`Over budget (${b.over.join('; ')})`);
  if (overLimit) notes.push(`Over the ${$(rules.approveOver)} limit`);
  if (b.isOver && rules.budgetMode === 'block') throw new AppError(`This order is over the ${o.supplier_name} budget: ${b.over.join('; ')}. Make it smaller or ask the admin to raise the budget.`);
  const needsApproval = (b.isOver && rules.budgetMode === 'approve') || overLimit;
  const { now, dev } = meta();
  if (needsApproval && !canApprove) {
    db().run(`UPDATE po_orders SET status = 'awaiting', budget_note = ?, ${SYNCED} WHERE uid = ?`, [notes.join('. '), now, dev, uid]);
    audit({ user, action: `Order ${o.po_no} needs approval: ${notes.join('. ')}`, table: 'po_orders', recordUid: uid });
    notify('po_approval', `Purchase order ${o.po_no} to ${o.supplier_name} (${$(o.total)}) needs approval. ${notes.join('. ')}. Made by ${user.name}.`, { shopCode: o.shop_code });
    return getPO(uid);
  }
  if (needsApproval && b.isOver) needReason(user, reason, 'This order is over budget. Say why it is OK.');
  const note = notes.length ? `${notes.join('. ')}${txt(reason) ? ` – OK because: ${txt(reason)}` : ''}` : null;
  db().run(`UPDATE po_orders SET status = 'approved', approved_by_name = ?, approved_at = ?, budget_note = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, note, now, dev, uid]);
  audit({ user, action: `Approved order ${o.po_no} ${$(o.total)}`, table: 'po_orders', recordUid: uid, reason: note });
  return getPO(uid);
}
export function rejectPO(user, uid, reason) {
  const o = getPO(uid);
  need(o && o.status === 'awaiting', 'This order is not waiting for approval.');
  needReason(user, reason, 'Say why it is sent back.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'draft', budget_note = ?, ${SYNCED} WHERE uid = ?`, [`Sent back by ${user.name}: ${txt(reason)}`, now, dev, uid]);
  audit({ user, action: `Sent back order ${o.po_no}`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
}
export function markSent(user, uid, via = 'viber') {
  const o = getPO(uid);
  need(o && ['approved', 'sent', 'part'].includes(o.status), o && ['draft', 'awaiting'].includes(o.status) ? 'Approve the order before sending it.' : 'This order cannot be sent.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = CASE WHEN status = 'approved' THEN 'sent' ELSE status END, sent_at = ?, sent_via = ?, ${SYNCED} WHERE uid = ?`, [now, via, now, dev, uid]);
  audit({ user, action: `Sent order ${o.po_no} by ${via}`, table: 'po_orders', recordUid: uid });
}
export function cancelPO(user, uid, reason) {
  const o = getPO(uid);
  need(o && ['draft', 'awaiting', 'approved', 'sent'].includes(o.status), o && o.status === 'part' ? 'Part of this order has arrived: use "Close short" instead.' : 'This order cannot be cancelled.');
  needReason(user, reason, 'Say why it is cancelled.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'cancelled', cancel_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled order ${o.po_no}`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
}
export function closeShort(user, uid, reason) {
  const o = getPO(uid);
  need(o && o.status === 'part', 'Only a part-received order can be closed short.');
  needReason(user, reason, 'Say why the rest is not coming.');
  const { now, dev } = meta();
  db().run(`UPDATE po_orders SET status = 'closed', cancel_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Closed order ${o.po_no} short`, table: 'po_orders', recordUid: uid, reason: txt(reason) });
}

// A ready-to-send message for Viber (or SMS / WhatsApp).
export function poText(uid, { business } = {}) {
  const o = getPO(uid);
  need(o, 'Order not found.');
  const shop = db().get('SELECT name FROM shops WHERE code = ?', [o.shop_code]);
  const lines = o.lines.filter((l) => l.qty > 0).map((l, i) => `${i + 1}. ${l.name}${l.code ? ` (${l.code})` : ''} – ${fmtQ(l.qty)} ${l.unit || ''}${l.note ? ` (${l.note})` : ''}`.trim());
  return [
    `PURCHASE ORDER ${o.po_no}`,
    `${business || 'Easy Buys Shopping Centre'} – ${shop ? shop.name : o.shop_code}`,
    `To: ${o.supplier_name}`,
    `Date: ${o.order_date}${o.expected_date ? `   Deliver by: ${o.expected_date}` : ''}`,
    '',
    ...lines,
    '',
    `${lines.length} item${lines.length === 1 ? '' : 's'}`,
    o.notes ? `Note: ${o.notes}` : null,
    'Please quote the order number on your invoice. Thank you.',
  ].filter((x) => x !== null).join('\n');
}
export const fmtQ = (q) => (Number.isInteger(q) ? String(q) : String(q3(q)));
export function viberLink(text, phone) {
  // Viber opens its "forward" screen with the text, where the supplier is picked. With a number we also offer a chat link.
  return { forward: `viber://forward?text=${encodeURIComponent(text)}`, chat: phone ? `viber://chat?number=${encodeURIComponent(String(phone).replace(/[^\d+]/g, ''))}` : null };
}

// What can be ordered from a supplier for a shop (reorder suggestions), to start an order quickly.
// Products with no main supplier yet are offered too (they get this supplier when received).
export function suggestFor(shopCode, supplierUid) {
  return stockList({ shopCode, filter: 'order' }).filter((r) => !supplierUid || !r.supplier_uid || r.supplier_uid === supplierUid).map((r) => ({ itemUid: r.uid, code: r.code, name: r.name, unit: r.unit, qty: r.suggest, unitCost: r.cost,
    why: `${r.supplier_uid ? '' : 'No main supplier set · '}${fmtQ(r.on_hand)} on hand${r.on_order ? `, ${fmtQ(r.on_order)} on order` : ''}, sells ${r.perWeek}/week${r.reorder_level ? `, reorder at ${fmtQ(r.reorder_level)}` : ''}` }));
}

// ---------------------------------------------------------------- receiving
// Receive a delivery against an order (poUid) or without one (supplierUid + extra lines).
// lines: [{lineUid, qty, unitCost}] for order lines; extra: [{itemUid, qty, unitCost}] for products not on the order.
// invoice: { uid } to link one already entered, or { invoiceNo, total, date, photos } to enter it now (optional: it can come later).
export function receiveDelivery(user, { poUid, supplierUid, shopCode, date, lines = [], extra = [], invoice, notes, photos = [], acceptReason } = {}) {
  const rules = invRules();
  const o = poUid ? getPO(poUid) : null;
  if (poUid) need(o && ['approved', 'sent', 'part'].includes(o.status), o && ['draft', 'awaiting'].includes(o.status) ? 'This order has not been approved yet.' : 'This order is not open for receiving.');
  const sup = getSupplier(o ? o.supplier_uid : supplierUid);
  need(sup, 'Choose the supplier.');
  const shop = o ? o.shop_code : txt(shopCode);
  need(shop, 'Choose the shop.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'The delivery date cannot be in the future.');
  const got = [];
  const flags = [];
  for (const l of lines) {
    const pl = o && o.lines.find((x) => x.uid === l.lineUid);
    need(pl, 'A line is not on this order.');
    const qty = q3(l.qty);
    if (!(qty > 0)) continue;
    need(pl.item_uid, `"${pl.name}" is not linked to a product. Link it first.`);
    const cost = l.unitCost === undefined || l.unitCost === '' ? pl.unit_cost : r4(l.unitCost);
    if (pl.unit_cost > 0 && Math.abs(cost - pl.unit_cost) / pl.unit_cost * 100 > rules.priceTolerancePct + 1e-9) flags.push(`${pl.name}: ordered at ${$(pl.unit_cost)}, invoiced at ${$(cost)}`);
    if (pl.qty_received + qty > pl.qty + 1e-9) flags.push(`${pl.name}: ${fmtQ(pl.qty_received + qty)} received, only ${fmtQ(pl.qty)} ordered`);
    got.push({ lineUid: pl.uid, itemUid: pl.item_uid, qty, unitCost: cost, ordered: pl.qty });
  }
  for (const l of extra) {
    const it = getItem(l.itemUid);
    need(it, 'A product was not found.');
    const qty = q3(l.qty);
    if (!(qty > 0)) continue;
    const cost = l.unitCost === undefined || l.unitCost === '' ? it.cost : r4(l.unitCost);
    if (o) flags.push(`${it.name}: not on the order`);
    got.push({ lineUid: null, itemUid: it.uid, qty, unitCost: cost, ordered: 0 });
  }
  need(got.length, 'Enter how many of each product arrived.');
  // No purchase order: a photo of the invoice (or the goods) is kept with it. Owner / admin may skip it.
  const anyPhoto = (photos || []).length || (invoice && (invoice.photos || []).length);
  if (!o) need(anyPhoto || !reasonRequired(user), 'No purchase order for this delivery – take a photo of the invoice (or the goods) first.');
  if (!o && invoice && !invoice.uid && !(invoice.photos || []).length && (photos || []).length) invoice = { ...invoice, photos };
  need(got.every((g) => g.unitCost >= 0), 'Costs cannot be negative.');
  for (const g of got) notFrozen(g.itemUid, shop);
  const value = r2(got.reduce((t, g) => t + incVat(g.qty * g.unitCost, getItem(g.itemUid).vat_type), 0));
  // Invoice: link or enter.
  let inv = null;
  if (invoice && invoice.uid) {
    inv = getInvoice(invoice.uid);
    need(inv && inv.status !== 'void', 'That invoice was not found.');
    need(inv.supplier_uid === sup.uid, 'That invoice is from another supplier.');
  }
  const invTotal = inv ? inv.total : invoice && txt(invoice.total) !== '' && invoice.total !== undefined ? r2(invoice.total) : null;
  if (invTotal !== null && Math.abs(invTotal - value) > rules.invoiceTolerance + 0.004) {
    flags.push(`Invoice ${$(invTotal)} but goods received come to ${$(value)} (difference ${$(invTotal - value)})`);
  }
  if (flags.length) needReason(user, acceptReason, `Please check: ${flags.join('; ')}. Fix it, or say why it is OK.`);
  if (!inv && invoice && (invTotal !== null || (invoice.photos || []).length)) {
    // No total typed: the invoice is for what was received (the office checks it against the paper).
    inv = saveInvoice(user, { supplierUid: sup.uid, invoiceNo: invoice.invoiceNo, invoiceDate: txt(invoice.date) || d, total: invTotal !== null ? invTotal : value, shopCode: shop,
      category: 'Stock for resale', description: o ? `Order ${o.po_no}` : 'Delivery received', notes: txt(notes) }, { photos: invoice.photos || [], allowDuplicate: !!invoice.allowDuplicate });
  }
  const { now, dev } = meta();
  const uid = uuid('RC');
  // Movements, order lines and cost prices.
  const costFlags = [];
  for (const g of got) {
    const it = getItem(g.itemUid);
    const c = newCost(it, g, shop, rules); // before the delivery is added to the stock
    addMove({ itemUid: g.itemUid, shopCode: shop, date: d, type: 'receive', qty: g.qty, unitCost: g.unitCost, refType: 'receipt', refUid: uid, reason: o ? o.po_no : sup.name, user });
    // Bakery ingredients go straight into the Bakery stock (not the shop's stock).
    const bk = bakeryPart(g.itemUid, shop, g.qty);
    if (bk) { addMove({ itemUid: g.itemUid, shopCode: shop, date: d, type: 'to_bakery', qty: -g.qty, unitCost: g.unitCost, refType: 'receipt', refUid: uid, reason: `${bk.material} ${bk.qty}`, user }); g.bakery = bk; }
    if (g.lineUid) db().run(`UPDATE po_lines SET qty_received = qty_received + ?, ${SYNCED} WHERE uid = ?`, [g.qty, now, dev, g.lineUid]);
    if (Math.abs(c - it.cost) > 0.00005) {
      const pct = it.cost > 0 ? Math.abs(c - it.cost) / it.cost * 100 : 100;
      db().run(`UPDATE inv_items SET cost = ?, ${SYNCED} WHERE uid = ?`, [c, now, dev, it.uid]);
      if (pct > rules.costFlagPct + 1e-9 || !it.cost) {
        logCostChange({ itemUid: it.uid, oldCost: it.cost, newCost: c, source: 'receive', supplierName: sup.name, refUid: uid, shopCode: shop, user });
        costFlags.push({ itemUid: it.uid, name: it.name, oldCost: it.cost, newCost: c });
      }
    }
    if (!it.supplier_uid) db().run(`UPDATE inv_items SET supplier_uid = ?, ${SYNCED} WHERE uid = ?`, [sup.uid, now, dev, it.uid]);
  }
  if (inv && o) db().run(`UPDATE ap_invoices SET po_uid = ?, ${SYNCED} WHERE uid = ?`, [o.uid, now, dev, inv.uid]);
  const recLines = got.map((g) => { const it = getItem(g.itemUid); return { lineUid: g.lineUid, itemUid: g.itemUid, code: it.code, name: it.name, qty: g.qty, unitCost: g.unitCost, ordered: g.ordered, ...(g.bakery ? { bakery: g.bakery } : {}) }; });
  db().run(`INSERT INTO inv_receipts (uid, kind, po_uid, supplier_uid, supplier_name, shop_code, receive_date, invoice_uid, invoice_no, invoice_total, total, match_note, lines, notes, by_name, status, created_at, updated_at, updated_device)
    VALUES (?, 'receive', ?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [uid, o ? o.uid : null, sup.uid, sup.name, shop, d, inv ? inv.uid : null, inv ? inv.invoice_no : (invoice && txt(invoice.invoiceNo)) || null, invTotal, value,
    flags.length ? `${flags.join('; ')} – accepted: ${txt(acceptReason)}` : null, JSON.stringify(recLines), txt(notes) || null, user.name, now, now, dev]);
  if (photos.length) addPhotos('receipt', uid, photos);
  if (o) refreshPOStatus(o.uid);
  if (recLines.some((l) => l.bakery)) { try { postBakeryReceipts(); } catch (e) { /* the bakery tablet adds it on its next sync */ } }
  audit({ user, action: `Received ${got.length} products from ${sup.name} at ${shop} ${$(value)}${o ? ` (${o.po_no})` : ''}`, table: 'inv_receipts', recordUid: uid, reason: txt(acceptReason) || null });
  return { uid, value, invoice: inv, costFlags, flags, po: o ? getPO(o.uid) : null };
}
function newCost(it, g, shop, rules) {
  if (rules.costMethod !== 'average') return r4(g.unitCost);
  const have = db().get("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND status = 'active'", [it.uid]).q; // all shops, before this delivery
  const h = Math.max(0, have);
  return h + g.qty > 0 ? r4((h * it.cost + g.qty * g.unitCost) / (h + g.qty)) : r4(g.unitCost);
}
export function refreshPOStatus(poUid) {
  const o = getPO(poUid);
  if (!o || !['approved', 'sent', 'part', 'received'].includes(o.status)) return;
  const live = o.lines.filter((l) => l.qty > 0);
  const all = live.every((l) => l.qty_received + 1e-9 >= l.qty);
  const any = o.lines.some((l) => l.qty_received > 0);
  const status = all && any ? 'received' : any ? 'part' : (o.sent_at ? 'sent' : 'approved');
  if (status !== o.status) {
    const { now, dev } = meta();
    db().run(`UPDATE po_orders SET status = ?, ${SYNCED} WHERE uid = ?`, [status, now, dev, poUid]);
  }
}
export function getReceipt(uid) {
  const r = db().get('SELECT * FROM inv_receipts WHERE uid = ?', [uid]);
  return r && { ...r, lines: J(r.lines, []) };
}
export function listReceipts({ shopCode, supplierUid, from, to, kind, limit = 300 } = {}) {
  return db().all(`SELECT * FROM inv_receipts WHERE (? IS NULL OR shop_code = ?) AND (? IS NULL OR supplier_uid = ?) AND (? IS NULL OR receive_date >= ?) AND (? IS NULL OR receive_date <= ?)
    AND (? IS NULL OR kind = ?) ORDER BY receive_date DESC, created_at DESC LIMIT ?`,
  [shopCode || null, shopCode || null, supplierUid || null, supplierUid || null, from || null, from || null, to || null, to || null, kind || null, kind || null, limit]).map((r) => ({ ...r, lines: J(r.lines, []) }));
}
// Goods received with no supplier invoice yet (or returns with no credit note yet).
export function receivedNotInvoiced({ shopCode } = {}) {
  return listReceipts({ shopCode, limit: 2000 }).filter((r) => r.status === 'active' && !r.invoice_uid);
}
export function linkInvoice(user, receiptUid, invoiceUid) {
  const r = getReceipt(receiptUid);
  need(r && r.status === 'active', 'Delivery not found.');
  const inv = getInvoice(invoiceUid);
  need(inv && inv.status !== 'void', 'Invoice not found.');
  need(inv.supplier_uid === r.supplier_uid, 'That invoice is from another supplier.');
  if (r.kind === 'return') need(inv.kind === 'credit', 'Link a credit note to a return.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_receipts SET invoice_uid = ?, invoice_no = ?, invoice_total = ?, ${SYNCED} WHERE uid = ?`, [inv.uid, inv.invoice_no, inv.total, now, dev, receiptUid]);
  if (r.po_uid && !inv.po_uid) db().run(`UPDATE ap_invoices SET po_uid = ?, ${SYNCED} WHERE uid = ?`, [r.po_uid, now, dev, inv.uid]);
  const diff = r2(inv.total - Math.abs(r.total));
  audit({ user, action: `Linked ${inv.kind === 'credit' ? 'credit note' : 'invoice'} ${inv.invoice_no || ''} ${$(inv.total)} to delivery ${r.receive_date}${Math.abs(diff) > 0.004 ? ` (differs by ${$(diff)})` : ''}`, table: 'inv_receipts', recordUid: receiptUid });
  return { diff };
}
export function voidReceipt(user, uid, reason) {
  const r = getReceipt(uid);
  need(r && r.status === 'active', 'Delivery not found or already voided.');
  needReason(user, reason, 'Say why it is being voided.');
  for (const l of r.lines) notFrozen(l.itemUid, r.shop_code);
  const { now, dev } = meta();
  voidMovesFor(uid, txt(reason));
  for (const l of r.lines) if (l.lineUid) db().run(`UPDATE po_lines SET qty_received = MAX(0, qty_received - ?), ${SYNCED} WHERE uid = ?`, [l.qty, now, dev, l.lineUid]);
  db().run(`UPDATE inv_receipts SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  if (r.po_uid) {
    const o = getPO(r.po_uid);
    if (o && ['received', 'part'].includes(o.status)) {
      const any = o.lines.some((l) => l.qty_received > 0);
      db().run(`UPDATE po_orders SET status = ?, ${SYNCED} WHERE uid = ?`, [any ? 'part' : (o.sent_at ? 'sent' : 'approved'), now, dev, o.uid]);
      refreshPOStatus(o.uid);
    }
  }
  audit({ user, action: `Voided delivery from ${r.supplier_name} ${r.receive_date} ${$(r.total)} (cost prices are not changed back)`, table: 'inv_receipts', recordUid: uid, reason: txt(reason) });
}

// Goods sent back to a supplier (damaged, expired, wrong). A credit note is expected: it shows as "waiting for credit" until linked.
export function returnToSupplier(user, { supplierUid, shopCode, date, lines = [], reason, notes, photos = [] }) {
  const sup = getSupplier(supplierUid);
  need(sup, 'Choose the supplier.');
  need(txt(shopCode), 'Choose the shop.');
  needReason(user, reason, 'Say why the goods are going back.');
  const d = txt(date) || dateStr();
  const clean = lines.map((l) => ({ it: getItem(l.itemUid), qty: q3(l.qty), unitCost: l.unitCost })).filter((l) => l.it && l.qty > 0);
  need(clean.length, 'Add at least one product.');
  for (const l of clean) notFrozen(l.it.uid, shopCode);
  const uid = uuid('RT');
  let value = 0;
  const recLines = clean.map((l) => {
    const cost = l.unitCost === undefined || l.unitCost === '' ? l.it.cost : r4(l.unitCost);
    value += incVat(l.qty * cost, l.it.vat_type);
    addMove({ itemUid: l.it.uid, shopCode, date: d, type: 'return', qty: -l.qty, unitCost: cost, refType: 'return', refUid: uid, reason: `${sup.name}: ${txt(reason)}`, user });
    return { itemUid: l.it.uid, code: l.it.code, name: l.it.name, qty: l.qty, unitCost: cost };
  });
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_receipts (uid, kind, supplier_uid, supplier_name, shop_code, receive_date, total, lines, notes, by_name, status, created_at, updated_at, updated_device)
    VALUES (?, 'return', ?,?,?,?,?,?,?,?, 'active', ?,?,?)`,
  [uid, sup.uid, sup.name, shopCode, d, -r2(value), JSON.stringify(recLines), [txt(reason), txt(notes)].filter(Boolean).join(' – '), user.name, now, now, dev]);
  if (photos.length) addPhotos('receipt', uid, photos);
  audit({ user, action: `Returned ${recLines.length} products to ${sup.name} from ${shopCode} ${$(value)} – credit note expected`, table: 'inv_receipts', recordUid: uid, reason: txt(reason) });
  return uid;
}

// ---------------------------------------------------------------- cost price changes
export function logCostChange({ itemUid, oldCost, newCost, source, supplierName, refUid, shopCode }) {
  const { now, dev } = meta();
  db().run(`INSERT INTO inv_cost_changes (uid, item_uid, change_date, old_cost, new_cost, supplier_name, ref_uid, shop_code, source, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [uuid('CC'), itemUid, dateStr(), r4(oldCost), r4(newCost), supplierName || null, refUid || null, shopCode || null, source || null, now, dev]);
}
export function costChanges({ unseenOnly = false, itemUid, from, to, limit = 500 } = {}) {
  return db().all(`SELECT c.*, i.code, i.name, i.price, i.vat_type FROM inv_cost_changes c LEFT JOIN inv_items i ON i.uid = c.item_uid
    WHERE (? = 0 OR c.seen_at IS NULL) AND (? IS NULL OR c.item_uid = ?) AND (? IS NULL OR c.change_date >= ?) AND (? IS NULL OR c.change_date <= ?)
    ORDER BY c.change_date DESC, c.updated_at DESC LIMIT ?`,
  [unseenOnly ? 1 : 0, itemUid || null, itemUid || null, from || null, from || null, to || null, to || null, limit]).map((c) => ({
    ...c, diff: r4(c.new_cost - (c.old_cost || 0)), pct: c.old_cost ? r2(((c.new_cost - c.old_cost) / c.old_cost) * 100) : null,
    belowCost: c.price > 0 && incVat(c.new_cost, c.vat_type) >= c.price,
    margin: c.price > 0 ? r2(((c.price - incVat(c.new_cost, c.vat_type)) / c.price) * 100) : null,
  }));
}
// Seen, and optionally a new selling price (all shops, or one shop).
export function reviewCostChange(user, uid, { newPrice, shopCode } = {}) {
  const c = db().get('SELECT * FROM inv_cost_changes WHERE uid = ?', [uid]);
  need(c, 'Not found.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_cost_changes SET seen_by_name = ?, seen_at = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, now, dev, uid]);
  if (newPrice !== undefined && newPrice !== '' && newPrice !== null) {
    const p = r2(newPrice);
    need(p > 0, 'Enter the new selling price.');
    const it = getItem(c.item_uid);
    if (shopCode) {
      const s = db().get('SELECT * FROM inv_item_shops WHERE item_uid = ? AND shop_code = ?', [c.item_uid, shopCode]);
      saveItemShop(user, { itemUid: c.item_uid, shopCode, active: s ? !!s.active : true, reorderLevel: s ? s.reorder_level : 0, reorderQty: s ? s.reorder_qty : 0, price: p, location: s ? s.location : null });
    } else {
      db().run(`UPDATE inv_items SET price = ?, ${SYNCED} WHERE uid = ?`, [p, now, dev, c.item_uid]);
      db().run(`UPDATE inv_item_shops SET price = NULL, ${SYNCED} WHERE item_uid = ? AND price IS NOT NULL`, [now, dev, c.item_uid]);
    }
    audit({ user, action: `New price for ${it.code} ${it.name}: ${$(p)}${shopCode ? ` at ${shopCode}` : ' (all shops)'} – remember to change it in Aronium too`, table: 'inv_items', recordUid: c.item_uid });
  }
}

// ---------------------------------------------------------------- stock take (frozen while counting; counted, then approved)
export const COUNT_STATUS = { counting: 'Counting', review: 'Waiting for approval', posted: 'Posted', cancelled: 'Cancelled' };
// scope: { groups?: [], locations?: [], itemUids?: [] } – empty = the whole shop.
// timing: 'before_open' (sales of the count day come after it) | 'after_close' (the count day's sales came before it)
export function startCount(user, { shopCode, name, scope = {}, date, timing = 'after_close', blind } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the count date.');
  const clean = { groups: (scope.groups || []).filter(Boolean), locations: (scope.locations || []).filter(Boolean), itemUids: (scope.itemUids || []).filter(Boolean) };
  // Two counts in the same shop may not cover the same products.
  const items = db().all(`SELECT i.*, s.location FROM inv_items i JOIN inv_item_shops s ON s.item_uid = i.uid AND s.shop_code = ? WHERE i.active = 1 AND (s.active = 1 OR
    (SELECT COALESCE(SUM(qty),0) FROM inv_moves m WHERE m.item_uid = i.uid AND m.shop_code = ? AND m.status = 'active') <> 0) ORDER BY s.location, i.group_name, i.name`, [shopCode, shopCode])
    .filter((it) => inScope({ scope: JSON.stringify(clean) }, it, it.location));
  need(items.length, 'No products match. Import or add products for this shop first.');
  for (const c of openCounts(shopCode)) {
    const clash = items.find((it) => inScope(c, it, it.location));
    need(!clash, `"${c.name || c.count_date}" is still open for some of the same products (e.g. ${clash && clash.name}). Post or cancel it first.`);
  }
  const rules = invRules();
  const uid = uuid('SC');
  const { now, dev } = meta();
  const label = txt(name) || `${shopCode} ${clean.groups.length ? clean.groups.join(', ') : clean.locations.length ? clean.locations.join(', ') : 'full count'} ${d}`;
  db().run(`INSERT INTO inv_counts (uid, shop_code, name, scope, count_date, timing, blind, status, started_at, started_by_name, uncounted, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?, 'counting', ?,?,?,?,?)`,
  [uid, shopCode, label, JSON.stringify(clean), d, timing === 'before_open' ? 'before_open' : 'after_close', (blind === undefined ? rules.blindCount : blind) ? 1 : 0, now, user.name, rules.uncounted, now, dev]);
  for (const it of items) {
    db().run(`INSERT INTO inv_count_lines (uid, count_uid, item_uid, expected, cost, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)`,
      [uuid('CL'), uid, it.uid, expectedAt(it.uid, shopCode, d, timing, uid), it.cost, now, dev]);
  }
  audit({ user, action: `Started stock take "${label}" (${items.length} products) – stock frozen`, table: 'inv_counts', recordUid: uid });
  return getCount(uid);
}
// What the system expects at the moment of the count: every movement up to the count (sales of the count day
// only if the count is after closing), not counting this stock take's own adjustment.
function expectedAt(itemUid, shopCode, date, timing, countUid) {
  const r = db().get(`SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = ? AND status = 'active' AND ifnull(ref_uid,'') <> ? AND
    (move_date < ? OR (move_date = ? AND (? = 'after_close' OR type <> 'sale')))`, [itemUid, shopCode, countUid || '', date, date, timing]);
  return q3(r.q);
}
export function getCount(uid, { withLines = true } = {}) {
  const c = db().get('SELECT * FROM inv_counts WHERE uid = ?', [uid]);
  if (!c) return null;
  const out = { ...c, scope: J(c.scope, {}), result: J(c.result, null) };
  if (!withLines) return out;
  const rules = invRules();
  const lines = db().all(`SELECT l.*, i.code, i.name, i.unit, i.barcode, i.group_name, i.pack_size, s.location FROM inv_count_lines l JOIN inv_items i ON i.uid = l.item_uid
    LEFT JOIN inv_item_shops s ON s.item_uid = l.item_uid AND s.shop_code = ? WHERE l.count_uid = ? ORDER BY s.location, i.group_name, i.name`, [c.shop_code, uid]);
  out.lines = lines.map((l) => {
    // While open, "expected" is worked out again so sales that arrive late (from Aronium) are allowed for.
    const exp = c.status === 'posted' || c.status === 'cancelled' ? l.expected : expectedAt(l.item_uid, c.shop_code, c.count_date, c.timing, uid);
    const counted = l.counted === null || l.counted === undefined ? null : l.counted;
    const finalQty = counted === null ? (c.uncounted === 'zero' ? 0 : null) : counted;
    const variance = finalQty === null ? 0 : q3(finalQty - exp);
    const value = r2(variance * (l.cost || 0));
    const needsRecount = counted !== null && !l.recount && (Math.abs(variance) > rules.countTolerance + 1e-9 && Math.abs(value) > rules.countValueTolerance + 0.004);
    const dbl = needsDouble(l, rules);
    const needsSecond = dbl && counted !== null && (l.second_count === null || l.second_count === undefined);
    const mismatch = dbl && counted !== null && l.second_count !== null && l.second_count !== undefined && Math.abs(l.second_count - counted) > 1e-9;
    return { ...l, expected: exp, variance, value, needsRecount, counted, double: dbl, needsSecond, mismatch, area: l.location || 'No area' };
  });
  const counted = out.lines.filter((l) => l.counted !== null);
  const off = counted.filter((l) => Math.abs(l.variance) > 1e-9);
  out.summary = {
    products: out.lines.length, counted: counted.length, notCounted: out.lines.length - counted.length,
    matched: counted.length - off.length, over: off.filter((l) => l.variance > 0).length, short: off.filter((l) => l.variance < 0).length,
    gain: r2(off.filter((l) => l.value > 0).reduce((s, l) => s + l.value, 0)), loss: r2(off.filter((l) => l.value < 0).reduce((s, l) => s + l.value, 0)),
    net: r2(out.lines.reduce((s, l) => s + l.value, 0)), expectedValue: r2(out.lines.reduce((s, l) => s + Math.max(0, l.expected) * (l.cost || 0), 0)),
    accuracy: counted.length ? Math.round(((counted.length - off.length) / counted.length) * 1000) / 10 : null,
    toRecount: out.lines.filter((l) => l.needsRecount).length,
    toSecond: out.lines.filter((l) => l.needsSecond).length,
    mismatches: out.lines.filter((l) => l.mismatch).length,
    noReason: off.filter((l) => !l.reason).length,
  };
  // Areas (shelves / locations): how far each one is, and who is counting it.
  const claims = has('inv_count_areas') ? db().all('SELECT * FROM inv_count_areas WHERE count_uid = ?', [uid]) : [];
  const areas = {};
  out.lines.forEach((l) => { const a = (areas[l.area] = areas[l.area] || { area: l.area, total: 0, counted: 0 }); a.total += 1; if (l.counted !== null) a.counted += 1; });
  out.areas = Object.values(areas).map((a) => { const cl = claims.find((x) => x.area === a.area); return { ...a, counter: cl ? cl.counter_name : null, done: !!(cl && cl.done_at) }; });
  return out;
}
export function listCounts({ shopCode, status, limit = 100 } = {}) {
  return db().all(`SELECT * FROM inv_counts WHERE (? IS NULL OR shop_code = ?) AND (? IS NULL OR status = ?) ORDER BY count_date DESC, started_at DESC LIMIT ?`,
    [shopCode || null, shopCode || null, status || null, status || null, limit]).map((c) => ({ ...c, scope: J(c.scope, {}), result: J(c.result, null) }));
}
// High-value products are counted twice, by two different people.
export function needsDouble(line, rules = invRules()) {
  const g = String(line.group_name || '').toLowerCase();
  if ((rules.doubleCountGroups || []).some((x) => x && g.includes(String(x).toLowerCase()))) return true;
  return rules.doubleCountCost > 0 && Number(line.cost || 0) >= rules.doubleCountCost;
}
// Several counters at once: each takes an area (shelf / location) and marks it done.
export function claimArea(user, countUid, area) {
  const c = getCount(countUid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting.');
  const { now, dev } = meta();
  const uid = `${countUid}|${area}`;
  const have = db().get('SELECT * FROM inv_count_areas WHERE uid = ?', [uid]);
  if (have && have.counter_name && have.counter_name !== user.name && !have.done_at) need(false, `${have.counter_name} is counting ${area}. Choose another area.`);
  db().run(`INSERT INTO inv_count_areas (uid, count_uid, area, counter_name, started_at, done_at, updated_at, updated_device) VALUES (?,?,?,?,?,NULL,?,?)
    ON CONFLICT(uid) DO UPDATE SET counter_name = excluded.counter_name, started_at = excluded.started_at, done_at = NULL, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, countUid, area, user.name, now, now, dev]);
  return getCount(countUid).areas.find((a) => a.area === area);
}
export function finishArea(user, countUid, area) {
  const c = getCount(countUid);
  const a = c && c.areas.find((x) => x.area === area);
  need(a, 'Area not found.');
  need(a.counted === a.total, `${a.total - a.counted} product(s) in ${area} are not counted yet.`);
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_areas SET done_at = ?, ${SYNCED} WHERE uid = ?`, [now, now, dev, `${countUid}|${area}`]);
  audit({ user, action: `Stock take "${c.name}": ${area} counted`, table: 'inv_counts', recordUid: countUid });
}
// Why a product is more or less than expected (shown on reports and the write-off).
export function setLineReason(user, countUid, itemUid, reason) {
  const rules = invRules();
  need(rules.countReasons.includes(reason), 'Choose a reason.');
  const { now, dev } = meta();
  const r = db().run(`UPDATE inv_count_lines SET reason = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [reason, now, dev, countUid, itemUid]);
  need(r.changes, 'This product is not part of this stock take.');
}
// Expiry seen while counting (e.g. 6 packets expire on 2026-11-02).
export function setLineExpiry(user, countUid, itemUid, { expiry, qty }) {
  need(!expiry || DATE.test(expiry), 'Choose the expiry date.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_count_lines SET expiry = ?, expiry_qty = ?, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [expiry || null, expiry ? q3(qty || 0) : null, now, dev, countUid, itemUid]);
}
export function expiringSoon({ shopCode, days = 30, today = dateStr() } = {}) {
  if (!has('inv_count_lines')) return [];
  return db().all(`SELECT l.item_uid, l.expiry, l.expiry_qty, i.name, i.code, c.shop_code, c.count_date FROM inv_count_lines l JOIN inv_counts c ON c.uid = l.count_uid JOIN inv_items i ON i.uid = l.item_uid
    WHERE l.expiry IS NOT NULL AND l.expiry <= ? AND l.expiry >= ? AND c.status <> 'cancelled' AND (? IS NULL OR c.shop_code = ?) ORDER BY l.expiry`, [addDays(today, days), addDays(today, -7), shopCode || null, shopCode || null]);
}
// Enter (or change) a count. add: true adds to what is already counted (counting the same product in two places).
export function enterCount(user, countUid, itemUid, qty, { add = false, note, packs } = {}) {
  const c = getCount(countUid, { withLines: false });
  // Cartons + singles: "3 cartons + 5" with the product's pack size.
  if (packs !== undefined && packs !== null && packs !== '') {
    const it = getItem(itemUid);
    const ps = Number(it && it.pack_size) || 1;
    qty = q3(Number(packs) * ps + (Number(qty) || 0));
  }
  need(c && c.status === 'counting', c && c.status === 'review' ? 'This stock take is waiting for approval. Ask for a recount to change it.' : 'This stock take is closed.');
  const l = db().get('SELECT * FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [countUid, itemUid]);
  need(l, 'This product is not part of this stock take.');
  const n = qty === '' || qty === null || qty === undefined ? null : q3(qty);
  need(n === null || n >= 0 || add, 'The count cannot be negative.');
  const value = n === null ? null : add ? q3((l.counted || 0) + n) : n;
  need(value === null || value >= 0, 'The count cannot go below 0.');
  const { now, dev } = meta();
  // High-value products: a different person's count is the second count (both must agree).
  const it0 = db().get('SELECT group_name, cost FROM inv_items WHERE uid = ?', [itemUid]);
  if (!add && value !== null && l.counted !== null && l.counted_by_name && l.counted_by_name !== user.name && needsDouble({ ...it0, cost: l.cost }, invRules())) {
    db().run(`UPDATE inv_count_lines SET second_count = ?, second_by_name = ?, ${SYNCED} WHERE uid = ?`, [value, user.name, now, dev, l.uid]);
    return value;
  }
  db().run(`UPDATE inv_count_lines SET counted = ?, counted_by_name = ?, counted_at = ?, note = COALESCE(?, note), ${SYNCED} WHERE uid = ?`,
    [value, user.name, now, txt(note) || null, now, dev, l.uid]);
  return value;
}
// Step 1 done: the counters hand it over. Lines over the tolerance are recounted first (once).
export function submitCount(user, countUid, { restZero } = {}) {
  const c0 = getCount(countUid);
  need(c0 && c0.status === 'counting', 'This stock take is not open for counting.');
  need(c0.summary.counted > 0, 'Nothing has been counted yet.');
  const { now, dev } = meta();
  if (restZero !== undefined) db().run(`UPDATE inv_counts SET uncounted = ?, ${SYNCED} WHERE uid = ?`, [restZero ? 'zero' : 'leave', now, dev, countUid]);
  const c = getCount(countUid);
  const second = c.lines.filter((l) => l.needsSecond);
  need(!second.length, `These must be counted a second time by another person: ${second.slice(0, 8).map((l) => l.name).join(', ')}${second.length > 8 ? '…' : ''}.`);
  const mism = c.lines.filter((l) => l.mismatch);
  if (mism.length) {
    for (const l of mism) db().run(`UPDATE inv_count_lines SET first_count = counted, counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE uid = ?`, [now, dev, l.uid]);
    audit({ user, action: `Stock take "${c.name}": the two counts differ for ${mism.length} products – count them again`, table: 'inv_counts', recordUid: countUid });
    return { recount: mism.map((l) => ({ itemUid: l.item_uid, name: `${l.name} (the two counts differ)` })), count: getCount(countUid) };
  }
  const recount = c.lines.filter((l) => l.needsRecount);
  if (recount.length) {
    for (const l of recount) db().run(`UPDATE inv_count_lines SET first_count = counted, counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE uid = ?`, [now, dev, l.uid]);
    audit({ user, action: `Stock take "${c.name}": ${recount.length} products are well off – count them again`, table: 'inv_counts', recordUid: countUid });
    return { recount: recount.map((l) => ({ itemUid: l.item_uid, name: l.name })), count: getCount(countUid) };
  }
  db().run(`UPDATE inv_counts SET status = 'review', submitted_at = ?, submitted_by_name = ?, ${SYNCED} WHERE uid = ?`, [now, user.name, now, dev, countUid]);
  audit({ user, action: `Stock take "${c.name}" counted (${c.summary.counted} of ${c.summary.products}), waiting for approval`, table: 'inv_counts', recordUid: countUid });
  return { recount: [], count: getCount(countUid) };
}
// The approver sends some products back for counting again.
export function requestRecount(user, countUid, itemUids, reason) {
  const c = getCount(countUid, { withLines: false });
  need(c && ['review', 'counting'].includes(c.status), 'This stock take is closed.');
  need((itemUids || []).length, 'Choose the products to count again.');
  const { now, dev } = meta();
  for (const id of itemUids) db().run(`UPDATE inv_count_lines SET first_count = COALESCE(counted, first_count), counted = NULL, second_count = NULL, second_by_name = NULL, recount = 1, ${SYNCED} WHERE count_uid = ? AND item_uid = ?`, [now, dev, countUid, id]);
  db().run(`UPDATE inv_counts SET status = 'counting', ${SYNCED} WHERE uid = ?`, [now, dev, countUid]);
  audit({ user, action: `Asked for a recount of ${itemUids.length} products in "${c.name}"`, table: 'inv_counts', recordUid: countUid, reason: txt(reason) || null });
}
// Step 2: approve and post. The stock of each counted product becomes what was counted; the stock is unfrozen.
export function postCount(user, countUid, { note } = {}) {
  const c = getCount(countUid);
  need(c && c.status === 'review', c && c.status === 'counting' ? 'The counters have not finished yet.' : 'This stock take is not waiting for approval.');
  const rules = invRules();
  const boss = !reasonRequired(user);
  need(boss || -c.summary.loss <= rules.countApproveOver + 0.004, `The loss is ${$(-c.summary.loss)} – over ${$(rules.countApproveOver)}, so the owner or admin approves it.`);
  const noWhy = c.lines.filter((l) => Math.abs(l.variance) > 1e-9 && !l.reason && (Math.abs(l.variance) > rules.countTolerance + 1e-9 && Math.abs(l.value) > rules.countValueTolerance + 0.004));
  need(boss || !noWhy.length, `Give a reason for: ${noWhy.slice(0, 8).map((l) => l.name).join(', ')}${noWhy.length > 8 ? '…' : ''}.`);
  const { now, dev } = meta();
  for (const l of c.lines) {
    db().run(`UPDATE inv_count_lines SET expected = ?, ${SYNCED} WHERE uid = ?`, [l.expected, now, dev, l.uid]);
    if (Math.abs(l.variance) > 1e-9) {
      addMove({ itemUid: l.item_uid, shopCode: c.shop_code, date: c.count_date, type: 'count', qty: l.variance, unitCost: l.cost, refType: 'count', refUid: countUid,
        reason: `${l.reason ? `${l.reason} – ` : ''}stock take: counted ${fmtQ(l.counted === null ? 0 : l.counted)}, expected ${fmtQ(l.expected)}`, note: l.reason || null, user });
    }
  }
  const result = { ...c.summary, postedBy: user.name };
  db().run(`UPDATE inv_counts SET status = 'posted', posted_at = ?, posted_by_name = ?, result = ?, notes = ?, ${SYNCED} WHERE uid = ?`,
    [now, user.name, JSON.stringify(result), txt(note) || null, now, dev, countUid]);
  audit({ user, action: `Posted stock take "${c.name}": ${c.summary.short} short, ${c.summary.over} over, net ${$(c.summary.net)}, accuracy ${c.summary.accuracy}%`, table: 'inv_counts', recordUid: countUid, reason: txt(note) || null });
  return getCount(countUid);
}
export function cancelCount(user, countUid, reason) {
  const c = getCount(countUid, { withLines: false });
  need(c && ['counting', 'review'].includes(c.status), 'This stock take is already closed.');
  needReason(user, reason, 'Say why it is cancelled.');
  const { now, dev } = meta();
  db().run(`UPDATE inv_counts SET status = 'cancelled', notes = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, countUid]);
  audit({ user, action: `Cancelled stock take "${c.name}" – stock unfrozen, nothing changed`, table: 'inv_counts', recordUid: countUid, reason: txt(reason) });
}
// Rolling (cycle) counts: products not counted for a while, the most valuable / fastest first.
export function cycleSuggestions(shopCode, { max = 40, today = dateStr() } = {}) {
  const rules = invRules();
  const cutoff = addDays(today, -rules.cycleDays);
  return stockList({ shopCode, today }).filter((r) => !r.last_counted || r.last_counted < cutoff)
    .sort((a, b) => (b.value + b.sold * b.cost) - (a.value + a.sold * a.cost)).slice(0, max);
}

// ---------------------------------------------------------------- summaries
export function stockValue(shopCode) {
  const r = db().get(`SELECT COALESCE(SUM(CASE WHEN q > 0 THEN q * cost ELSE 0 END),0) AS v, COUNT(*) AS n, SUM(CASE WHEN q < 0 THEN 1 ELSE 0 END) AS neg FROM
    (SELECT i.cost, SUM(m.qty) AS q FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.shop_code = ? AND m.status = 'active' GROUP BY m.item_uid)`, [shopCode]);
  return { value: r2(r.v), products: r.n, negative: r.neg || 0 };
}
// Loss per shop in a period: write-offs, stock-take differences and transfer shortages (at cost).
export function shrinkage({ shopCode, from, to }) {
  const rows = db().all(`SELECT m.type, CASE WHEN m.type = 'count' THEN COALESCE(m.note, '') ELSE m.reason END AS reason, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v, SUM(m.qty) AS q, COUNT(*) AS n
    FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
    WHERE m.shop_code = ? AND m.status = 'active' AND m.type IN ('adjust','count') AND m.move_date BETWEEN ? AND ? GROUP BY m.type, 2 ORDER BY v`, [shopCode, from, to]);
  const transit = db().get("SELECT COALESCE(SUM(short_value),0) AS v FROM inv_transfers WHERE to_shop = ? AND status = 'received' AND receive_date BETWEEN ? AND ?", [shopCode, from, to]).v;
  const byReason = rows.map((r) => ({ type: r.type, reason: r.type === 'count' ? (r.reason ? `Stock take – ${r.reason}` : 'Stock take differences') : r.reason, value: r2(r.v), qty: q3(r.q), times: r.n }));
  const total = r2(byReason.reduce((s, r) => s + r.value, 0) - transit);
  return { byReason, transitShort: r2(transit), total };
}
// Losses per product (write-offs and stock-take differences), biggest first, with the reasons given.
export function shrinkageByProduct({ shopCode, from, to, limit = 50 } = {}) {
  return db().all(`SELECT m.item_uid, i.code, i.name, i.group_name, m.shop_code, SUM(m.qty) AS q, SUM(m.qty * COALESCE(m.unit_cost, i.cost)) AS v, COUNT(*) AS n,
    GROUP_CONCAT(DISTINCT CASE WHEN m.type = 'count' THEN m.note ELSE m.reason END) AS reasons
    FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.status = 'active' AND m.type IN ('adjust','count') AND m.qty < 0 AND m.move_date BETWEEN ? AND ?
    AND (? IS NULL OR m.shop_code = ?) GROUP BY m.item_uid, m.shop_code ORDER BY v LIMIT ?`, [from, to, shopCode || null, shopCode || null, limit])
    .map((r) => ({ ...r, q: q3(r.q), v: r2(r.v), reasons: String(r.reasons || '').split(',').filter(Boolean) }));
}
// Products short again and again: short in at least `min` of their last `last` posted stock takes.
export function repeatLosers({ shopCode, last = 5, min = 3 } = {}) {
  const rows = db().all(`SELECT l.item_uid, i.name, i.code, c.shop_code, c.count_date, (COALESCE(l.counted, 0) - l.expected) AS diff, l.cost FROM inv_count_lines l JOIN inv_counts c ON c.uid = l.count_uid
    JOIN inv_items i ON i.uid = l.item_uid WHERE c.status = 'posted' AND l.counted IS NOT NULL AND (? IS NULL OR c.shop_code = ?) ORDER BY c.count_date DESC`, [shopCode || null, shopCode || null]);
  const by = {};
  rows.forEach((r) => { const k = `${r.item_uid}|${r.shop_code}`; (by[k] = by[k] || []).push(r); });
  return Object.values(by).map((list) => {
    const recent = list.slice(0, last);
    const short = recent.filter((r) => r.diff < -1e-9);
    return { itemUid: recent[0].item_uid, name: recent[0].name, code: recent[0].code, shopCode: recent[0].shop_code, counts: recent.length, short: short.length,
      lost: r2(short.reduce((s, r) => s + r.diff * (r.cost || 0), 0)) };
  }).filter((x) => x.short >= min).sort((a, b) => a.lost - b.lost);
}
// High-value products (counted twice) not counted for a while – a short count every week keeps them honest.
export function highValueDue(shopCode, { today = dateStr() } = {}) {
  const rules = invRules();
  const cutoff = addDays(today, -rules.cycleHighValueDays);
  return stockList({ shopCode, today }).filter((r) => needsDouble(r, rules) && (r.on_hand || 0) > 0 && (!r.last_counted || r.last_counted < cutoff));
}
// Write-offs worth checking: big ones, and people / products with many of them.
export function writeOffWatch({ from, to, shopCode } = {}) {
  const rules = invRules();
  const rows = db().all(`SELECT m.*, i.code, i.name FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid WHERE m.type = 'adjust' AND m.status = 'active' AND m.qty < 0
    AND m.move_date BETWEEN ? AND ? AND (? IS NULL OR m.shop_code = ?) ORDER BY m.move_date DESC`, [from, to, shopCode || null, shopCode || null]);
  const big = rows.filter((m) => Math.abs(m.qty * (m.unit_cost || 0)) > rules.writeOffApproveOver);
  const group = (key) => Object.values(rows.reduce((acc, m) => {
    const k = m[key] || '—';
    acc[k] = acc[k] || { key: k, times: 0, value: 0 };
    acc[k].times += 1; acc[k].value = r2(acc[k].value + Math.abs(m.qty * (m.unit_cost || 0)));
    return acc;
  }, {})).sort((a, b) => b.value - a.value);
  return { big, byPerson: group('by_name'), byProduct: group('name'), total: r2(rows.reduce((s, m) => s + Math.abs(m.qty * (m.unit_cost || 0)), 0)) };
}
export function invAlerts(shopCodes = []) {
  const out = [];
  const unseen = db().get('SELECT COUNT(*) AS n FROM inv_cost_changes WHERE seen_at IS NULL').n;
  if (unseen) out.push({ tone: 'warn', text: `${unseen} cost price change${unseen === 1 ? '' : 's'} to look at`, go: 'CostChanges' });
  const awaiting = db().get("SELECT COUNT(*) AS n FROM po_orders WHERE status = 'awaiting'").n;
  if (awaiting) out.push({ tone: 'warn', text: `${awaiting} purchase order${awaiting === 1 ? '' : 's'} waiting for approval`, go: 'POList' });
  const transfers = db().get("SELECT COUNT(*) AS n FROM inv_transfers WHERE status = 'sent'").n;
  if (transfers) out.push({ tone: 'info', text: `${transfers} transfer${transfers === 1 ? '' : 's'} between shops not yet received`, go: 'Transfers' });
  const review = db().get("SELECT COUNT(*) AS n FROM inv_counts WHERE status = 'review'").n;
  if (review) out.push({ tone: 'warn', text: `${review} stock take${review === 1 ? '' : 's'} waiting for approval`, go: 'StockTakes' });
  const counting = db().get("SELECT COUNT(*) AS n FROM inv_counts WHERE status = 'counting'").n;
  if (counting) out.push({ tone: 'info', text: `Stock take under way – that stock is frozen`, go: 'StockTakes' });
  const late = db().get("SELECT COUNT(*) AS n FROM po_orders WHERE status IN ('sent','approved') AND expected_date < ?", [dateStr()]).n;
  if (late) out.push({ tone: 'warn', text: `${late} order${late === 1 ? '' : 's'} past the delivery date`, go: 'POList' });
  for (const s of shopCodes) {
    const low = db().get(`SELECT COUNT(*) AS n FROM inv_item_shops s JOIN inv_items i ON i.uid = s.item_uid AND i.active = 1
      WHERE s.shop_code = ? AND s.active = 1 AND s.reorder_level > 0 AND (SELECT COALESCE(SUM(qty),0) FROM inv_moves m WHERE m.item_uid = s.item_uid AND m.shop_code = s.shop_code AND m.status = 'active') <= s.reorder_level`, [s]).n;
    if (low) out.push({ tone: 'info', text: `${s}: ${low} product${low === 1 ? '' : 's'} at or below the reorder level`, go: 'InvStock', params: { shopCode: s, filter: 'low' } });
  }
  return out;
}
