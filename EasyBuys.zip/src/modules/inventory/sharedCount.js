// 1.0.0 One shared stock take per shop. When a stock take is started for a shop, every phone that opens "Stock take"
// joins THAT one. Counts from all phones add up per product and place (each count is its own entry, kept once – a
// double tap or a retry with the same entry id is not counted twice), and before adding, the phone shows what others
// counted already: "Ravi counted 12 in aisle 3 – add yours?".
// The stock take's id is made from the shop and the day (ST-S1-2026-11-01), so two phones that start it while offline
// start the same one, and their counts meet after syncing. Each shop has its own.
import { db } from '../../db/connection.js';
import { AppError, dateStr, stamp, uuid } from '../../services/core.js';
import { can } from '../../services/access.js';
import * as I from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const fq = (q) => (Number.isInteger(q) ? String(q) : String(q3(q)));

export const sharedUid = (shopCode, date) => `ST-${txt(shopCode).toUpperCase()}-${date}`;
// everyone at the shop helps count once a stock take is on (the accountant only looks)
export const mayCount = (u) => !!u && u.role !== 'accountant';
export const mayStart = (u) => !!u && (can(u, 'stocktake_count') || can(u, 'stocktake_approve') || ['owner', 'admin'].includes(u.role));

// The stock take open for counting at this shop (the shared one first, else the newest).
export function openFor(shopCode) {
  const list = db().all("SELECT uid FROM inv_counts WHERE shop_code = ? AND status = 'counting' ORDER BY CASE WHEN uid LIKE 'ST-%' THEN 0 ELSE 1 END, started_at DESC", [txt(shopCode)]);
  return list.length ? I.getCount(list[0].uid, { withLines: false }) : null;
}
// Join the open stock take; start = true starts today's shared one when there is none (those who may start one).
export function join(user, shopCode, { start = false, date = dateStr(), name } = {}) {
  need(user, 'Log in first.');
  const shop = txt(shopCode) || user.shop_code;
  need(shop, 'Choose the shop.');
  const open = openFor(shop);
  if (open) return { count: open, joined: true };
  if (!start) return { count: null, joined: false };
  need(mayStart(user), 'Ask a supervisor or manager to start the stock take – then join it here.');
  // a stock take of today that was finished or cancelled: the next one gets -2, -3…
  let uid = sharedUid(shop, date); let n = 1;
  while (db().get('SELECT 1 AS x FROM inv_counts WHERE uid = ?', [uid])) { n += 1; uid = `${sharedUid(shop, date)}-${n}`; }
  const c = I.startCount(user, { shopCode: shop, date, name: txt(name) || `${shop} stock take ${date}`, uid });
  return { count: c, joined: false, started: true };
}
// What the others counted of a product (and what I counted), with the words for the screen.
export function countedSoFar(countUid, itemUid, user) {
  const entries = I.countEntries(countUid, itemUid);
  const mine = entries.filter((e) => user && e.by_uid === user.uid);
  const others = entries.filter((e) => !user || e.by_uid !== user.uid);
  const total = q3(entries.reduce((t, e) => t + (Number(e.qty) || 0), 0));
  const text = others.length ? `${others.map((e) => `${e.by_name} counted ${fq(e.qty)}${e.spot ? ` in ${e.spot}` : ''}`).join(', ')} – add yours?` : mine.length ? `You counted ${fq(q3(mine.reduce((t, e) => t + e.qty, 0)))} so far.` : 'Nobody has counted it yet.';
  return { total, entries, mine, others, text };
}
// Add what I counted here (another shelf or the store room adds on top). tapId: an id made by the screen for this tap.
export function addMine(user, countUid, itemUid, qty, { spot, tapId } = {}) {
  need(mayCount(user), 'You cannot count in this stock take.');
  const n = q3(qty);
  need(txt(qty) !== '' && n >= 0, 'How many here?');
  need(txt(spot), 'Say where you counted it (aisle, shelf, store room).');
  const c = I.getCount(countUid, { withLines: false });
  need(c && c.status === 'counting', 'This stock take is not open for counting any more.');
  if (!db().get('SELECT 1 AS x FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [countUid, itemUid])) I.addToCount(user, countUid, itemUid);
  const entryUid = tapId ? `CE-${String(tapId).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 60)}` : undefined;
  const total = I.enterCount(user, countUid, itemUid, n, { add: true, spot: txt(spot), entryUid });
  return { total, ...countedSoFar(countUid, itemUid, user) };
}
export const newTapId = () => uuid('TAP').replace(/^TAP-/, '');
// "4 phones counting · 312 of 1,140 products done" (phones that counted in the last 30 minutes).
export function progress(countUid) {
  const lines = db().get('SELECT COUNT(*) AS n FROM inv_count_lines WHERE count_uid = ?', [countUid]).n;
  const done = db().get("SELECT COUNT(DISTINCT item_uid) AS n FROM inv_count_entries WHERE count_uid = ? AND void_at IS NULL AND COALESCE(kind,'') <> 'reset'", [countUid]).n;
  const since = stamp(new Date(Date.parse(stamp().replace(' ', 'T')) - 30 * 60000));
  const phones = db().get("SELECT COUNT(DISTINCT device) AS n FROM inv_count_entries WHERE count_uid = ? AND at >= ? AND COALESCE(kind,'') <> 'reset'", [countUid, since]).n;
  const people = db().all("SELECT DISTINCT by_name FROM inv_count_entries WHERE count_uid = ? AND void_at IS NULL AND COALESCE(kind,'') <> 'reset'", [countUid]).map((x) => x.by_name).filter(Boolean);
  return { lines, done, phones, people };
}
export const PLACES = ['Shop floor', 'Aisle 1', 'Aisle 2', 'Aisle 3', 'Aisle 4', 'Aisle 5', 'Fridge', 'Freezer', 'Front counter', 'Cigarette cabinet', 'Back store', 'Store room', 'Bakery'];
