// 1.0.0 speed work: stock totals per product, shop and month, kept up to date by the database itself.
//
// Working out the stock value at each month end from 3 years of stock movements (700 000 rows) took about a second
// per month and shop – the books, the month close, the dashboard and the accountant pack did it dozens of times.
// This table holds, for each product, shop, month and "opening stock or not":
//   qty     the movements added up                     val     qty × the movement's own cost (where it has one)
//   qty_nc  the movements that have no cost of their own (they are valued at the product's cost of today, as before)
//   n       how many movements
// Only movements that count (status 'active') are in it. SQLite triggers on inv_moves change it on EVERY insert,
// change and delete – from any screen, the Aronium link, the cloud pull, a backup put back, the Deleted bin – so it
// can never fall behind. A movement whose date is not a plain calendar date (YYYY-MM-DD) is kept apart under its own
// date ('~' + the date), so a figure "up to a date" is always exactly what adding up the movements would give.
//
// It is built from the movements once (first start after the update; and again whenever the triggers had gone, e.g.
// the table was set up again) and checked by the self-check, which builds it again if it ever disagrees.
import { db, keepUntilChanged } from '../../db/connection.js';

export const STOCK_MONTHS_VERSION = '1';
// The month bucket of a movement date: 'YYYY-MM' for a real calendar date, otherwise '~' + the date as written.
const BUCKET = (d) => `CASE WHEN length(${d}) = 10 AND date(${d}) = ${d} THEN substr(${d}, 1, 7) ELSE '~' || COALESCE(${d}, '') END`;
const ROW = (r, sign) => `COALESCE(${r}.item_uid, ''), COALESCE(${r}.shop_code, ''), ${BUCKET(`${r}.move_date`)}, CASE WHEN ${r}.type = 'opening' THEN 1 ELSE 0 END,
  ${sign} COALESCE(${r}.qty, 0), ${sign} CASE WHEN ${r}.unit_cost IS NOT NULL THEN COALESCE(${r}.qty, 0) * ${r}.unit_cost ELSE 0 END,
  ${sign} CASE WHEN ${r}.unit_cost IS NULL THEN COALESCE(${r}.qty, 0) ELSE 0 END, ${sign} 1`;
const UPSERT = 'ON CONFLICT (shop_code, ym, opening, item_uid) DO UPDATE SET qty = qty + excluded.qty, val = val + excluded.val, qty_nc = qty_nc + excluded.qty_nc, n = n + excluded.n';
const INS = 'INSERT INTO inv_stock_months (item_uid, shop_code, ym, opening, qty, val, qty_nc, n)';

export const STOCK_MONTHS_TABLE = `CREATE TABLE IF NOT EXISTS inv_stock_months (
  shop_code TEXT NOT NULL, ym TEXT NOT NULL, opening INTEGER NOT NULL, item_uid TEXT NOT NULL,
  qty REAL NOT NULL DEFAULT 0, val REAL NOT NULL DEFAULT 0, qty_nc REAL NOT NULL DEFAULT 0, n INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (shop_code, ym, opening, item_uid)
) WITHOUT ROWID`;
export const STOCK_MONTHS_TRIGGERS = {
  trg_ism_ins: `CREATE TRIGGER IF NOT EXISTS trg_ism_ins AFTER INSERT ON inv_moves WHEN NEW.status = 'active' BEGIN
    ${INS} SELECT ${ROW('NEW', '')} WHERE 1 ${UPSERT}; END`,
  trg_ism_del: `CREATE TRIGGER IF NOT EXISTS trg_ism_del AFTER DELETE ON inv_moves WHEN OLD.status = 'active' BEGIN
    ${INS} SELECT ${ROW('OLD', '-')} WHERE 1 ${UPSERT}; END`,
  trg_ism_upd: `CREATE TRIGGER IF NOT EXISTS trg_ism_upd AFTER UPDATE OF status, qty, unit_cost, item_uid, shop_code, move_date, type ON inv_moves
    WHEN OLD.status = 'active' OR NEW.status = 'active' BEGIN
    ${INS} SELECT ${ROW('OLD', '-')} WHERE OLD.status = 'active' ${UPSERT};
    ${INS} SELECT ${ROW('NEW', '')} WHERE NEW.status = 'active' ${UPSERT}; END`,
};

const one = (q, p = []) => { try { return db().get(q, p); } catch (e) { return null; } };
const hasTable = (t) => !!one("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);

// At start (and after the tables were set up again): the table and its triggers; built from the movements when new.
// build: false – the table and triggers only; returns true when the totals still have to be built (then the stock
// values are added up from the movements until ensureStockMonths() has built them).
let notBuilt = false;
export function stockMonthsReady() { return !notBuilt; }
export function ensureStockMonths({ build = true } = {}) {
  if (!hasTable('inv_moves')) return false;
  // a REPLACE (backup put back) deletes the old row first: with this switched on the delete trigger sees it too
  try { db().exec('PRAGMA recursive_triggers = ON;'); } catch (e) { /* older SQLite: REPLACE is not used on stock moves */ }
  const fresh = !hasTable('inv_stock_months');
  db().exec(`${STOCK_MONTHS_TABLE};`);
  let missing = false;
  for (const [name, sql] of Object.entries(STOCK_MONTHS_TRIGGERS)) {
    if (!one("SELECT 1 AS x FROM sqlite_master WHERE type = 'trigger' AND name = ?", [name])) { missing = true; db().exec(`${sql};`); }
  }
  const v = one("SELECT value FROM settings WHERE key = 'stock_months_version'");
  if (fresh || missing || !v || v.value !== STOCK_MONTHS_VERSION) {
    if (!build) { notBuilt = true; return true; }
    rebuildStockMonths(); notBuilt = false; return true;
  }
  notBuilt = false;
  return false;
}

// Built again from the movements (in one transaction: never half-built).
export function rebuildStockMonths() {
  db().transaction(() => {
    db().run('DELETE FROM inv_stock_months');
    // every date a plain calendar date (the usual case): the month is simply the first 7 characters (quicker)
    const odd = db().get("SELECT COUNT(*) AS n FROM inv_moves WHERE status = 'active' AND NOT (length(move_date) = 10 AND date(move_date) = move_date)").n;
    db().run(`${INS}
      SELECT COALESCE(item_uid, ''), COALESCE(shop_code, ''), ${odd ? BUCKET('move_date') : "COALESCE(substr(move_date, 1, 7), '~')"}, CASE WHEN type = 'opening' THEN 1 ELSE 0 END,
        SUM(COALESCE(qty, 0)), SUM(CASE WHEN unit_cost IS NOT NULL THEN COALESCE(qty, 0) * unit_cost ELSE 0 END), SUM(CASE WHEN unit_cost IS NULL THEN COALESCE(qty, 0) ELSE 0 END), COUNT(*)
      FROM inv_moves WHERE status = 'active' GROUP BY 1, 2, 3, 4`);
    db().run("INSERT OR REPLACE INTO settings (key, value) VALUES ('stock_months_version', ?)", [STOCK_MONTHS_VERSION]);
  });
}

// The self-check: one month (by default the newest) of the table against the movements themselves. Built again if
// they disagree. Returns { ok, rebuilt, month }.
export function checkStockMonths({ ym } = {}) {
  if (notBuilt || !hasTable('inv_stock_months')) return { ok: true, rebuilt: false, month: null };
  const month = ym || (one("SELECT MAX(ym) AS m FROM inv_stock_months WHERE ym NOT LIKE '~%'") || {}).m;
  if (!month) return { ok: true, rebuilt: false, month: null };
  const a = one('SELECT COALESCE(SUM(qty), 0) AS q, COALESCE(SUM(val), 0) AS v, COALESCE(SUM(qty_nc), 0) AS c, COALESCE(SUM(n), 0) AS n FROM inv_stock_months WHERE ym = ?', [month]) || {};
  const b = one(`SELECT COALESCE(SUM(qty), 0) AS q, COALESCE(SUM(CASE WHEN unit_cost IS NOT NULL THEN qty * unit_cost ELSE 0 END), 0) AS v,
      COALESCE(SUM(CASE WHEN unit_cost IS NULL THEN qty ELSE 0 END), 0) AS c, COUNT(*) AS n
    FROM inv_moves WHERE move_date >= ? AND move_date <= ? AND status = 'active' AND length(move_date) = 10 AND date(move_date) = move_date`, [`${month}-01`, `${month}-31`]) || {};
  const ok = Number(a.n) === Number(b.n) && Math.abs(a.q - b.q) < 0.0005 && Math.abs(a.v - b.v) < 0.005 && Math.abs(a.c - b.c) < 0.0005;
  if (!ok) rebuildStockMonths();
  return { ok, rebuilt: !ok, month };
}

const DEPS = ['inv_moves', 'inv_stock_months', 'inv_items'];
const lastDayOf = (ym) => { const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)); const d = new Date(Date.UTC(y, m, 0)).getUTCDate(); return `${ym}-${String(d).padStart(2, '0')}`; };

// Stock at cost on a date for one shop: exactly SUM(qty × COALESCE(unit_cost, product cost)) of the counting movements
// up to and including the date (without opening stock imports when exOpening).
export function stockValueUpTo(shopCode, date, exOpening = false) {
  return stockValuesUpTo([shopCode], [date], exOpening).get(`${shopCode}|${date}`) || 0;
}
// Many shops and dates at once (the books: every month end of every shop) – one read of the table, plus one small
// read of the movements for a date that is not a month end. Returns Map 'shop|date' → value (not rounded).
export function stockValuesUpTo(shops, dates, exOpening = false) {
  const out = new Map();
  if (!shops.length || !dates.length) return out;
  // the totals are still being built (first start after the update): straight from the movements, as before
  if (notBuilt) {
    for (const shop of shops) for (const d of dates) {
      const r = db().get(`SELECT COALESCE(SUM(m.qty * COALESCE(m.unit_cost, i.cost)),0) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
        WHERE m.shop_code = ? AND m.status = 'active' AND m.move_date <= ? ${exOpening ? "AND m.type <> 'opening'" : ''}`, [shop, d]);
      out.set(`${shop}|${d}`, Number(r.v) || 0);
    }
    return out;
  }
  const op = exOpening ? 'AND s.opening = 0' : '';
  const ph = shops.map(() => '?').join(',');
  // per shop and month bucket, valued now (the product's cost for movements without their own)
  // kept until a stock movement or a product (its cost) changes
  const rows = keepUntilChanged(`ism|${shops.join(',')}|${exOpening ? 1 : 0}`, DEPS, () => db().all(`SELECT s.shop_code AS shop, s.ym AS ym, SUM(s.val + s.qty_nc * i.cost) AS v
    FROM inv_stock_months s JOIN inv_items i ON i.uid = s.item_uid WHERE s.shop_code IN (${ph}) ${op} GROUP BY s.shop_code, s.ym`, shops));
  const by = new Map(shops.map((s) => [s, []]));
  for (const r of rows) by.get(r.shop).push(r);
  const partCache = new Map();
  for (const shop of shops) {
    const list = by.get(shop).filter((r) => !r.ym.startsWith('~')).sort((x, y) => (x.ym < y.ym ? -1 : 1));
    const odd = by.get(shop).filter((r) => r.ym.startsWith('~'));
    for (const d of dates) {
      const ym = String(d).slice(0, 7);
      // everything in months before ym …
      let v = 0;
      for (const r of list) { if (r.ym < ym) v += r.v; else break; }
      // … the month of the date: whole when the date is its last day (or later), otherwise the movements up to the date
      const cur = list.find((r) => r.ym === ym);
      if (cur) {
        if (String(d) >= lastDayOf(ym)) v += cur.v;
        else {
          const k = `${shop}|${d}`;
          // the shorter side of the month is read: the days up to the date, or (later in the month) the whole month
          // less the days after the date
          if (!partCache.has(k)) {
            const late = Number(String(d).slice(8, 10)) > 15;
            const range = late ? [`${String(d)}~`, lastDayOf(ym)] : [`${ym}-01`, String(d)];
            const p = keepUntilChanged(`ismp|${k}|${exOpening ? 1 : 0}|${late ? 1 : 0}`, DEPS, () => db().get(`SELECT COALESCE(SUM(m.qty * COALESCE(m.unit_cost, i.cost)), 0) AS v FROM inv_moves m JOIN inv_items i ON i.uid = m.item_uid
              WHERE m.move_date ${late ? '>' : '>='} ? AND m.move_date <= ? AND m.shop_code = ? AND m.status = 'active' ${exOpening ? "AND m.type <> 'opening'" : ''}
                AND length(m.move_date) = 10 AND date(m.move_date) = m.move_date`, [late ? String(d) : range[0], range[1], shop]));
            partCache.set(k, late ? cur.v - (Number(p.v) || 0) : Number(p.v) || 0);
          }
          v += partCache.get(k);
        }
      }
      // movements with an odd date: counted when their date (as written) is not after the date
      for (const r of odd) if (r.ym.slice(1) <= String(d)) v += r.v;
      out.set(`${shop}|${d}`, v);
    }
  }
  return out;
}

// On hand per product for a shop (only products with counting movements). Map item_uid → qty.
export function onHandByItem(shopCode) {
  const m = new Map();
  for (const r of db().all('SELECT item_uid, SUM(qty) AS q FROM inv_stock_months WHERE shop_code = ? GROUP BY item_uid HAVING SUM(n) > 0', [shopCode])) m.set(r.item_uid, r.q);
  return m;
}
