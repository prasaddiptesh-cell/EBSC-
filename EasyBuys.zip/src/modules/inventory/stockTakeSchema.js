// v3.9.3 Stock take on many phones at once, and several suppliers per product.
//  • inv_count_entries: every count typed or scanned is its own record (who, which phone, where, how many). The count of a
//    product is the sum of its entries, so phones counting at the same time never overwrite each other through the cloud.
//    A recount / "Change total" is itself an entry (kind 'reset'): counts made before it no longer count. Each count
//    remembers the last reset its phone had seen (seen_reset), so a phone with a slow clock is still right.
//  • inv_item_suppliers: the suppliers a product comes from (their code, last price), one of them the main one.
export const STOCKTAKE393_SQL = `
CREATE TABLE IF NOT EXISTS inv_count_entries (
  uid TEXT PRIMARY KEY,
  count_uid TEXT NOT NULL,
  item_uid TEXT NOT NULL,
  qty REAL NOT NULL,
  spot TEXT,
  by_name TEXT, by_uid TEXT, device TEXT, at TEXT,
  void_at TEXT, void_by_name TEXT, void_reason TEXT,
  kind TEXT, seen_reset TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_ice_count ON inv_count_entries(count_uid, item_uid);
CREATE TABLE IF NOT EXISTS inv_item_suppliers (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  supplier_uid TEXT NOT NULL,
  supplier_code TEXT,
  last_cost REAL, last_date TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_iis_item ON inv_item_suppliers(item_uid);
CREATE INDEX IF NOT EXISTS idx_iis_sup ON inv_item_suppliers(supplier_uid);
`;
export const STOCKTAKE393_SYNC = {
  inv_count_entries: { key: 'uid', section: 'Stock take', cols: ['uid', 'count_uid', 'item_uid', 'qty', 'spot', 'by_name', 'by_uid', 'device', 'at', 'void_at', 'void_by_name', 'void_reason', 'kind', 'seen_reset', 'updated_at', 'updated_device'] },
  inv_item_suppliers: { key: 'uid', section: 'Inventory', cols: ['uid', 'item_uid', 'supplier_uid', 'supplier_code', 'last_cost', 'last_date', 'active', 'updated_at', 'updated_device'] },
};
