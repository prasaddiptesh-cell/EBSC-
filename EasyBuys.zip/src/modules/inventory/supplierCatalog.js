// 1.0.0 What each supplier sells, as it is on their invoices (their code, the name they print, unit, carton, last
// cost excl. VAT, VAT %, last bought) – e.g. brought in with the set-up pack from the old invoices in Google Drive.
// A line is kept even when its product is not in the app yet (before the Aronium Link has sent the products): it
// waits, and links itself as soon as the product arrives.
//   • sure matches link by themselves: the barcode, the Aronium code, the exact name, the supplier's code already
//     linked, or a very close name with the same size (e.g. both "2kg");
//   • anything less sure is a "please confirm" with the closest product: Yes / pick another / not a product we sell;
//   • a confirmed line becomes the normal supplier link (inv_item_suppliers: their code, last cost and date), and the
//     carton size is set on the product when it has none.
// Never touches Aronium.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit } from '../../services/core.js';
import { can } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';

export const CATALOG_SQL = `
CREATE TABLE IF NOT EXISTS inv_supplier_catalog (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  supplier_name TEXT,
  code TEXT, name TEXT, unit TEXT, pack TEXT, pack_qty REAL,
  cost REAL, vat REAL, last_date TEXT, barcode TEXT, item_code TEXT, item_name TEXT, main INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'waiting',
  item_uid TEXT, guess_item_uid TEXT, guess_how TEXT, guess_score REAL,
  source TEXT, decided_by_name TEXT, decided_at TEXT,
  created_at TEXT, updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_isc_sup ON inv_supplier_catalog(supplier_uid);
CREATE INDEX IF NOT EXISTS idx_isc_status ON inv_supplier_catalog(status);
`;
export const CATALOG_SYNC = {
  inv_supplier_catalog: { key: 'uid', section: 'Inventory', cols: ['uid', 'supplier_uid', 'supplier_name', 'code', 'name', 'unit', 'pack', 'pack_qty', 'cost', 'vat', 'last_date', 'barcode', 'item_code', 'item_name', 'main',
    'status', 'item_uid', 'guess_item_uid', 'guess_how', 'guess_score', 'source', 'decided_by_name', 'decided_at', 'created_at', 'updated_at', 'updated_device'] },
};
export const STATUS = { check: 'Please confirm', waiting: 'Waiting for the product', linked: 'Linked', not_ours: 'Not a product we sell' };

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const low = (v) => txt(v).toLowerCase();
const need = (c, m) => { if (!c) throw new AppError(m); };
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'inv_supplier_catalog'"); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const numOr = (v) => { if (v === null || v === undefined || v === '') return null; const n = Number(String(v).replace(/[$,\s%]/g, '')); return Number.isFinite(n) ? n : null; };
const I = () => require('./service.js');
const okUser = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole) || safe(() => can(u, 'inventory_manage'), false));

// The same line always gets the same record (loading the pack twice, or on two devices, never makes doubles).
function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i += 1) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
export const lineKey = (supplierUid, code, name) => `SC-${hash(`${supplierUid}|${low(code) || low(name).replace(/[^a-z0-9]+/g, ' ').trim()}`)}`;

// How many singles in the supplier's carton / pack: "24x500ml" → 24, "12 X 1L" → 12, "CTN/24" → 24, "48'S" → 48.
// A weight or volume alone ("50KG", "2L") is the size of one, not a count.
export function packQty(pack, unit) {
  const p = low(pack);
  if (!p) return null;
  let m = /(\d+)\s*[x×*]\s*\d/.exec(p);
  if (m) return Number(m[1]);
  m = /(?:ctn|carton|box|case|pkt|bale|outer)\s*[/:\-]?\s*(\d+)\b(?!\s*(?:kg|g|gm|gms|l|lt|ltr|ml|mls)\b)/.exec(p);
  if (m) return Number(m[1]);
  m = /^\s*(\d+)\s*(?:'s|s|pcs|pc|pkts|pks|pk|units|ea|each|x)\s*$/.exec(p);
  if (m) return Number(m[1]);
  if (/^(ctn|carton|box|case|bale|outer)/.test(low(unit))) { m = /^\s*(\d+)\s*$/.exec(p); if (m) return Number(m[1]); }
  return null;
}
// The size of one, in grams or millilitres ("2kg" → 2000, "500ml" → 500), to tell "Flour 2kg" from "Flour 10kg".
export function sizeOf(s) {
  const m = /(\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gms|gram|grams|l|lt|ltr|litre|liter|ml|mls)\b/.exec(low(s));
  if (!m) return null;
  const n = Number(m[1]); const u = m[2];
  return Math.round(['kg', 'kgs', 'l', 'lt', 'ltr', 'litre', 'liter'].includes(u) ? n * 1000 : n);
}
const STOP = new Set(['the', 'and', 'with', 'for', 'pkt', 'pkts', 'pack', 'packs', 'pk', 'ctn', 'ctns', 'carton', 'cartons', 'each', 'ea', 'pcs', 'pc', 'x', 'of', 'in', 'sleeve', 'sleeves', 'outer', 'outers',
  'bottle', 'bottles', 'card', 'cards', 'box', 'bag', 'bags', 'tin', 'tins', 'tub', 'tubs', 'doz', 'dozen', 'bale', 'handwritten', 'kg', 'kgs', 'g', 'gm', 'gms', 'ml', 'mls', 'l', 'lt', 'ltr', 's']);
const SHORT = { flr: 'flour', brwn: 'brown', sug: 'sugar', choc: 'chocolate', bisc: 'biscuit', biscuits: 'biscuit', noodle: 'noodles', ckn: 'chicken', chkn: 'chicken', tom: 'tomato', tomatoe: 'tomato', veg: 'vegetable', crm: 'cream', mlk: 'milk', wht: 'white', maggie: 'maggi', primium: 'premium' };
// The words that name the product: no quantity bought in front ("10 sleeve", "1ctn", "24pcs", "2x"), no carton
// ("12x", "24 x"), no size (compared on its own), no packing words. A number left on its own stays ("BH 10").
const SIZE_RE = /\d+(?:\.\d+)?\s*(?:kg|kgs|g|gm|gms|gram|grams|l|lt|ltr|litre|liter|ml|mls)\b/g;
const words = (s) => low(s)
  .replace(/^\s*\d+\s*(?:x|pcs?|pkts?|ctns?|sleeves?|outers?|bottles?|cards?|box(?:es)?|bags?|tins?|doz(?:en)?)?\s+(?=[a-z])/, '')
  .replace(/^\s*\d+\s*(?:pcs?|pkts?|ctns?|sleeves?|outers?)(?=[\sa-z\d])/, '')
  .replace(/\b\d+\s*[x×]\s*(?=\d)/g, ' ').replace(/[x×]\s*\d+\b/g, ' ').replace(SIZE_RE, ' ').replace(/\(\s*[\d-]+\s*\)/g, ' ')
  .replace(/'s\b/g, ' ').replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/)
  .map((w) => SHORT[w] || w).map((w) => (w.length > 4 && w.endsWith('s') ? w.slice(0, -1) : w)).filter((w) => w && !STOP.has(w) && (w.length > 1 || /\d/.test(w)));
// Words that say which kind (colour, flavour, plain packing words) – on their own they never make two products alike.
const KIND = new Set(['black', 'red', 'green', 'blue', 'white', 'gold', 'silver', 'yellow', 'pink', 'purple', 'brown', 'orange', 'strawberry', 'vanilla', 'chocolate', 'banana', 'lemon', 'lime', 'mango', 'pineapple',
  'apple', 'grape', 'chicken', 'curry', 'beef', 'tomato', 'cheese', 'original', 'classic', 'extra', 'super', 'premium', 'regular', 'large', 'small', 'medium', 'big', 'mini', 'family', 'new', 'plain', 'mild', 'hot',
  'sauce', 'oil', 'powder', 'spray', 'flavour', 'flavor', 'mens', 'men', 'ladies', 'kids', 'fresh', 'light', 'cool', 'ice']);
const flat = (s) => words(s).join(' ') + (sizeOf(s) ? ` ${sizeOf(s)}` : '');
const prep = (s) => ({ w: [...new Set(words(s))], size: sizeOf(s) });
function score(P, Q) {
  if (!P.w.length || !Q.w.length) return 0;
  const B = new Set(Q.w);
  // "noodle" ~ "noodles", "chick" ~ "chicken" – but never "milk" ~ "milkycool"
  const near = (a, b) => { const [x, y] = a.length <= b.length ? [a, b] : [b, a]; return x.length >= 4 && y.startsWith(x) && y.length - x.length <= 3; };
  let same = 0; let real = 0;
  for (const w of P.w) if (B.has(w) || (!/^\d+$/.test(w) && Q.w.some((x) => near(w, x)))) { same += 1; if (!KIND.has(w) && !/^\d+$/.test(w)) real += 1; }
  if (!real) return 0;
  let s = same / Math.max(P.w.length, Q.w.length);
  if (P.size && Q.size) s = P.size === Q.size ? Math.min(1, s + 0.15) : s * 0.4; // a different size is a different product
  return Math.round(s * 100) / 100;
}
export function nameScore(a, b) { return score(prep(a), prep(b)); }

// The products of the app, ready to match against (built once per run).
export function itemIndex() {
  const items = safe(() => db().all('SELECT uid, code, name, barcode FROM inv_items WHERE IFNULL(active,1) = 1 AND removed_at IS NULL'), null)
    || safe(() => db().all('SELECT uid, code, name, barcode FROM inv_items WHERE IFNULL(active,1) = 1'), []);
  const byCode = new Map(); const byName = new Map(); const byBar = new Map(); const byFlat = new Map();
  for (const i of items) {
    if (txt(i.code)) byCode.set(low(i.code), i);
    byName.set(low(i.name).replace(/\s+/g, ' '), i);
    i.p = prep(i.name);
    const f = flat(i.name); if (f && !byFlat.has(f)) byFlat.set(f, i); else if (f) byFlat.set(f, null); // two alike: not sure

    for (const b of txt(i.barcode).split(/[|,;\s]+/)) if (b) byBar.set(b, i);
  }
  const links = safe(() => db().all('SELECT item_uid, supplier_uid, supplier_code FROM inv_item_suppliers WHERE active = 1 AND supplier_code IS NOT NULL'), []);
  return { items, byCode, byName, byBar, byFlat, links, byUid: new Map(items.map((i) => [i.uid, i])) };
}
// → { item, how, sure } or { guess, how, score } or {}
export function matchLine(r, supplierUid, ix = itemIndex()) {
  const bar = txt(r.barcode);
  if (bar) {
    const x = ix.byBar.get(bar) || safe(() => I().findItem(bar), null);
    if (x) return { item: x, how: 'barcode', sure: true };
  }
  if (txt(r.itemCode) && ix.byCode.get(low(r.itemCode))) return { item: ix.byCode.get(low(r.itemCode)), how: 'Aronium code', sure: true };
  if (supplierUid && txt(r.code)) {
    const l = ix.links.find((x) => x.supplier_uid === supplierUid && low(x.supplier_code) === low(r.code));
    if (l && ix.byUid.get(l.item_uid)) return { item: ix.byUid.get(l.item_uid), how: 'their code', sure: true };
  }
  for (const n of [r.itemName, r.name]) { const x = txt(n) && ix.byName.get(low(n).replace(/\s+/g, ' ')); if (x) return { item: x, how: 'same name', sure: true }; }
  for (const n of [r.itemName, r.name]) { const f = txt(n) && flat(n); const x = f && f.includes(' ') && ix.byFlat.get(f); if (x) return { item: x, how: 'same name', sure: true }; }
  let best = null;
  const P = prep(r.itemName || r.name); const P2 = txt(r.itemName) && txt(r.name) ? prep(r.name) : null;
  for (const i of ix.items) {
    const s = Math.max(score(P, i.p), P2 ? score(P2, i.p) : 0);
    if (!best || s > best.s) best = { s, i };
  }
  if (best && best.s >= 0.95 && P.size && P.size === best.i.p.size) return { item: best.i, how: `name and size (${Math.round(best.s * 100)}%)`, sure: true };
  if (best && best.s >= 0.5) return { guess: best.i, how: `close name (${Math.round(best.s * 100)}%)`, score: best.s };
  return {};
}

const getRow = (uid) => (has() ? db().get('SELECT * FROM inv_supplier_catalog WHERE uid = ?', [uid]) : null);
const SET = "updated_at = ?, updated_device = ?, sync_status = 'pending'";

// Link one line to a product: the normal supplier link with their code, cost and date; the carton size if none.
function linkNow(row, itemUid, byName) {
  const S = I();
  S.noteItemSupplier(itemUid, row.supplier_uid, { code: row.code || undefined, cost: row.cost === null ? undefined : row.cost, date: row.last_date || undefined });
  const now = stamp(); const dev = deviceId();
  if (row.main) safe(() => db().run(`UPDATE inv_items SET supplier_uid = ?, ${SET} WHERE uid = ?`, [row.supplier_uid, now, dev, itemUid]));
  if (Number(row.pack_qty) > 1) {
    const it = S.getItem(itemUid);
    if (it && !(Number(it.pack_size) > 1)) safe(() => db().run(`UPDATE inv_items SET pack_size = ?, ${SET} WHERE uid = ?`, [Number(row.pack_qty), now, dev, itemUid]));
  }
  db().run(`UPDATE inv_supplier_catalog SET status = 'linked', item_uid = ?, guess_item_uid = NULL, decided_by_name = ?, decided_at = ?, ${SET} WHERE uid = ?`, [itemUid, byName || null, now, now, dev, row.uid]);
}

// Keep lines (from the set-up pack). rows: [{ supplierUid, supplierName, code, name, unit, pack, cost, vat, date, barcode, itemCode, itemName, main,
// itemUid (when already known) }]. Returns { added, updated, linked, check, waiting }.
export function keepLines(user, rows, { source = 'set-up pack' } = {}) {
  need(has(), 'The app needs updating.');
  const out = { added: 0, updated: 0, linked: 0, check: 0, waiting: 0, errors: [] };
  const ix = itemIndex();
  for (const r of rows || []) {
    if (!r || !r.supplierUid || !(txt(r.name) || txt(r.code))) continue;
    try { keepOne(user, r, ix, source, out); } catch (e) { out.errors.push({ row: r._row, name: txt(r.name) || txt(r.code), why: e && e.message ? e.message : String(e) }); }
  }
  if (out.added + out.updated) safe(() => audit({ user, action: `Supplier products kept (${source}): ${out.added} new, ${out.updated} updated – ${out.linked} linked, ${out.check} to confirm, ${out.waiting} waiting for the product`, table: 'inv_supplier_catalog', recordUid: stamp() }));
  return out;
}
function keepOne(user, r, ix, source, out) {
  {
    const uid = lineKey(r.supplierUid, r.code, r.name);
    const before = getRow(uid);
    const now = stamp(); const dev = deviceId();
    const cost = numOr(r.cost); const vat = numOr(r.vat);
    const date = /^\d{4}-\d{2}-\d{2}/.test(txt(r.date)) ? txt(r.date).slice(0, 10) : null;
    // an older invoice never replaces a newer cost
    const newer = !before || !before.last_date || !date || date >= before.last_date;
    const vals = {
      supplier_name: txt(r.supplierName) || (before && before.supplier_name) || null, code: txt(r.code) || (before && before.code) || null, name: txt(r.name) || (before && before.name) || null,
      unit: txt(r.unit) || (before && before.unit) || null, pack: txt(r.pack) || (before && before.pack) || null,
      cost: newer && cost !== null ? cost : before ? before.cost : cost, vat: vat !== null ? vat : before ? before.vat : null, last_date: newer ? date || (before && before.last_date) || null : before.last_date,
      barcode: txt(r.barcode) || (before && before.barcode) || null, item_code: txt(r.itemCode) || (before && before.item_code) || null, item_name: txt(r.itemName) || (before && before.item_name) || null,
      main: /^y/i.test(txt(r.main)) || r.main === true || (before && before.main) ? 1 : 0,
    };
    vals.pack_qty = packQty(vals.pack, vals.unit);
    if (before) {
      db().run(`UPDATE inv_supplier_catalog SET supplier_name=?, code=?, name=?, unit=?, pack=?, pack_qty=?, cost=?, vat=?, last_date=?, barcode=?, item_code=?, item_name=?, main=?, ${SET} WHERE uid = ?`,
        [vals.supplier_name, vals.code, vals.name, vals.unit, vals.pack, vals.pack_qty, vals.cost, vals.vat, vals.last_date, vals.barcode, vals.item_code, vals.item_name, vals.main, now, dev, uid]);
      out.updated += 1;
    } else {
      db().run(`INSERT INTO inv_supplier_catalog (uid, supplier_uid, supplier_name, code, name, unit, pack, pack_qty, cost, vat, last_date, barcode, item_code, item_name, main, status, source, created_at, updated_at, updated_device)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'waiting',?,?,?,?)`,
      [uid, r.supplierUid, vals.supplier_name, vals.code, vals.name, vals.unit, vals.pack, vals.pack_qty, vals.cost, vals.vat, vals.last_date, vals.barcode, vals.item_code, vals.item_name, vals.main, source, now, now, dev]);
      out.added += 1;
    }
    const row = getRow(uid);
    if (row.status === 'not_ours') return;
    if (row.status === 'linked' && row.item_uid) { if (newer) linkNow(row, row.item_uid, row.decided_by_name); out.linked += 1; return; }
    const m = r.itemUid ? { item: { uid: r.itemUid }, sure: true } : matchLine(r, r.supplierUid, ix);
    if (m.item && m.sure) { linkNow(row, m.item.uid, user && user.name); out.linked += 1; } else if (m.item || m.guess) { setGuess(row, m.item || m.guess, m.how, m.score); out.check += 1; } else out.waiting += 1;
  }
}
function setGuess(row, item, how, score) {
  db().run(`UPDATE inv_supplier_catalog SET status = 'check', guess_item_uid = ?, guess_how = ?, guess_score = ?, ${SET} WHERE uid = ?`, [item.uid, how || null, score === undefined ? null : score, stamp(), deviceId(), row.uid]);
}

// Try again for every line not decided yet (after new products came from Aronium). Quick; safe to call often.
export function matchCatalog() {
  if (!has()) return { linked: 0, check: 0, waiting: 0 };
  const rows = db().all("SELECT * FROM inv_supplier_catalog WHERE status IN ('waiting', 'check')");
  const out = { linked: 0, check: 0, waiting: 0 };
  if (!rows.length) return out;
  const ix = itemIndex();
  if (!ix.items.length) return { ...out, waiting: rows.length };
  for (const row of rows) {
    try {
      const m = matchLine({ code: row.code, name: row.name, barcode: row.barcode, itemCode: row.item_code, itemName: row.item_name }, row.supplier_uid, ix);
      if (m.item && m.sure) { linkNow(row, m.item.uid, 'the app (sure match)'); out.linked += 1; } else if (m.item || m.guess) {
        const g = m.item || m.guess;
        if (row.status !== 'check' || row.guess_item_uid !== g.uid) setGuess(row, g, m.how, m.score);
        out.check += 1;
      } else out.waiting += 1;
    } catch (e) { /* one line never stops the rest */ }
  }
  return out;
}

// The person decides: this product (the suggestion or another one picked), or not a product we sell.
export function confirmLine(user, uid, itemUid) {
  need(okUser(user), 'Only the owner, admin or the inventory manager can link supplier products.');
  const row = getRow(uid);
  need(row, 'Not found.');
  const it = I().getItem(itemUid || row.guess_item_uid);
  need(it, 'Choose the product.');
  linkNow(row, it.uid, user.name);
  audit({ user, action: `${row.supplier_name}: "${row.name || row.code}" is ${it.name}`, table: 'inv_supplier_catalog', recordUid: uid });
  return getRow(uid);
}
export function notOurs(user, uid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(okUser(user), 'Only the owner, admin or the inventory manager can do this.');
  const row = getRow(uid);
  need(row, 'Not found.');
  db().run(`UPDATE inv_supplier_catalog SET status = 'not_ours', guess_item_uid = NULL, decided_by_name = ?, decided_at = ?, ${SET} WHERE uid = ?`, [user.name, stamp(), stamp(), deviceId(), uid]);
  audit({ user, action: `${row.supplier_name}: "${row.name || row.code}" is not a product we sell`, table: 'inv_supplier_catalog', recordUid: uid });
  });
}
// Undo a decision: the line goes back to be matched again (the supplier link it made stays until removed on the product).
export function reopenLine(user, uid) {
  requirePerm(user, 'inventory_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(okUser(user), 'Only the owner, admin or the inventory manager can do this.');
  need(getRow(uid), 'Not found.');
  db().run(`UPDATE inv_supplier_catalog SET status = 'waiting', item_uid = NULL, decided_by_name = NULL, decided_at = NULL, ${SET} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  matchCatalog();
  });
}

export function listLines({ status = 'check', supplierUid = null, q = '', limit = 300 } = {}) {
  if (!has()) return [];
  const like = `%${low(q)}%`;
  const rows = db().all(`SELECT c.*, g.name AS guess_name, g.code AS guess_code, i.name AS item_name_now, i.code AS item_code_now FROM inv_supplier_catalog c
    LEFT JOIN inv_items g ON g.uid = c.guess_item_uid LEFT JOIN inv_items i ON i.uid = c.item_uid
    WHERE (? = 'all' OR c.status = ?) AND (? IS NULL OR c.supplier_uid = ?) AND (? = '%%' OR lower(IFNULL(c.name,'')) LIKE ? OR lower(IFNULL(c.code,'')) LIKE ? OR lower(IFNULL(c.supplier_name,'')) LIKE ?)
    ORDER BY c.supplier_name, c.name LIMIT ?`, [status, status, supplierUid, supplierUid, like, like, like, like, limit]);
  return rows;
}
export function counts() {
  const z = { check: 0, waiting: 0, linked: 0, not_ours: 0, all: 0 };
  if (!has()) return z;
  for (const r of db().all('SELECT status, COUNT(*) AS n FROM inv_supplier_catalog GROUP BY status')) { z[r.status] = r.n; z.all += r.n; }
  return z;
}
// What a supplier's invoices say about a product (for the supplier page / ordering): name on the invoice, carton.
export function linesForItem(itemUid) {
  return has() && itemUid ? db().all("SELECT * FROM inv_supplier_catalog WHERE item_uid = ? AND status = 'linked'", [itemUid]) : [];
}

export function catalogAlerts(user) {
  if (!okUser(user)) return [];
  const c = counts();
  return c.check ? [{ id: `sc-check-${c.check}`, level: 'info', text: `${c.check} supplier product${c.check === 1 ? '' : 's'} to confirm`, sub: 'From the supplier invoices – tap to say which product each one is.', nav: { screen: 'SupplierMatch' } }] : [];
}
