// 1.0.0 Owed by suppliers: goods on an invoice (often already paid by cheque) that did not come, came short, came
// damaged, or were charged at the wrong price. Each stays open – with its value – until the goods arrive (a later
// delivery), a credit note comes, or the owner writes it off. Nothing is lost between the invoice, the cheque and the
// goods.
//   reasons: not_delivered (on the invoice, not delivered) · short (fewer came) · damaged (came damaged – to replace
//   or credit) · price (charged more than agreed) · other
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

export const OWED_SUP_SQL = `
CREATE TABLE IF NOT EXISTS supplier_owed (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT NOT NULL,
  supplier_name TEXT,
  shop_code TEXT,
  item_uid TEXT,
  name TEXT NOT NULL,
  qty REAL NOT NULL DEFAULT 0,
  qty_done REAL NOT NULL DEFAULT 0,
  unit_cost REAL NOT NULL DEFAULT 0,
  value REAL NOT NULL DEFAULT 0,
  reason TEXT NOT NULL,
  invoice_uid TEXT, invoice_no TEXT, receipt_uid TEXT, po_uid TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  note TEXT, photo_urls TEXT,
  owed_date TEXT,
  told_at TEXT, told_by_name TEXT,
  done_how TEXT, done_note TEXT, done_receipt_uid TEXT, done_by_name TEXT, done_at TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_supowed_sup ON supplier_owed(supplier_uid, status);
`;
export const OWED_SUP_SYNC = {
  supplier_owed: { key: 'uid', section: 'Invoices', cols: ['uid', 'supplier_uid', 'supplier_name', 'shop_code', 'item_uid', 'name', 'qty', 'qty_done', 'unit_cost', 'value', 'reason', 'invoice_uid', 'invoice_no', 'receipt_uid', 'po_uid',
    'status', 'note', 'photo_urls', 'owed_date', 'told_at', 'told_by_name', 'done_how', 'done_note', 'done_receipt_uid', 'done_by_name', 'done_at', 'by_name', 'created_at', 'updated_at', 'updated_device'] },
};
export const OWED_REASON = { not_delivered: 'Invoiced, not delivered', short: 'Came short', damaged: 'Came damaged', price: 'Charged too much', other: 'Other' };
export const OWED_DONE = { received: 'Goods came', credited: 'Credit note', written_off: 'Written off' };

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'supplier_owed'"); } catch (e) { return false; } };
const SY = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const boss = (u) => u && (['owner', 'admin', 'manager'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

// One thing owed. price: qty = how many were overcharged, unitCost = the overcharge per single.
export function addOwed(user, { supplierUid, shopCode, itemUid, name, qty, unitCost, reason, invoiceUid, invoiceNo, receiptUid, poUid, note, photos = [], date } = {}) {
  requirePerm(user, 'invoices_check', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  need(has(), 'Update the app first.');
  const sup = db().get('SELECT uid, name FROM ap_suppliers WHERE uid = ?', [supplierUid]);
  need(sup, 'Choose the supplier.');
  const it = itemUid ? db().get('SELECT uid, name, cost FROM inv_items WHERE uid = ?', [itemUid]) : null;
  const nm = txt(name) || (it && it.name);
  need(nm, 'Choose the product (or write what it is).');
  const q = q3(qty);
  need(q > 0 && q < 100000, 'How many?');
  const c = unitCost === undefined || unitCost === null || unitCost === '' ? (it ? Number(it.cost) || 0 : 0) : Number(unitCost);
  need(Number.isFinite(c) && c >= 0, 'The price is not a number.');
  need(OWED_REASON[reason], 'Say why it is owed.');
  let inv = null;
  try { inv = invoiceUid ? db().get('SELECT uid, invoice_no FROM ap_invoices WHERE uid = ?', [invoiceUid]) : null; } catch (e) { inv = null; }
  const uid = uuid('OW');
  const now = stamp();
  db().run(`INSERT INTO supplier_owed (uid, supplier_uid, supplier_name, shop_code, item_uid, name, qty, unit_cost, value, reason, invoice_uid, invoice_no, receipt_uid, po_uid, status, note, photo_urls, owed_date, by_name, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'open', ?,?,?,?,?,?,?)`,
  [uid, sup.uid, sup.name, txt(shopCode) || null, it ? it.uid : null, nm.slice(0, 120), q, r2(c * 10000) / 10000, r2(q * c), reason, inv ? inv.uid : null, txt(invoiceNo) || (inv && inv.invoice_no) || null,
    txt(receiptUid) || null, txt(poUid) || null, txt(note) || null, JSON.stringify(photos || []), txt(date) || dateStr(), user.name, now, now, deviceId()]);
  audit({ user, action: `${sup.name} owes: ${OWED_REASON[reason]} – ${nm} × ${q} (${r2(q * c).toFixed(2)})${inv || invoiceNo ? ` on invoice ${txt(invoiceNo) || inv.invoice_no}` : ''}`, table: 'supplier_owed', recordUid: uid });
  return getOwed(uid);
  });
}
export function getOwed(uid) {
  if (!has()) return null;
  const r = db().get('SELECT * FROM supplier_owed WHERE uid = ?', [uid]);
  return r ? { ...r, left: q3(r.qty - r.qty_done), leftValue: r2((r.qty - r.qty_done) * r.unit_cost) } : null;
}
export function listOwed({ supplierUid, status = 'open', shopCode, itemUid } = {}) {
  if (!has()) return [];
  return db().all(`SELECT * FROM supplier_owed WHERE (? IS NULL OR supplier_uid = ?) AND (? = 'all' OR status = ?) AND (? IS NULL OR shop_code = ? OR shop_code IS NULL) AND (? IS NULL OR item_uid = ?)
    ORDER BY owed_date, created_at`, [supplierUid || null, supplierUid || null, status, status, shopCode || null, shopCode || null, itemUid || null, itemUid || null])
    .map((r) => ({ ...r, left: q3(r.qty - r.qty_done), leftValue: r2((r.qty - r.qty_done) * r.unit_cost), days: Math.max(0, Math.round((Date.parse(`${dateStr()}T00:00:00`) - Date.parse(`${r.owed_date}T00:00:00`)) / 86400000)) }));
}
// Per supplier: how much is owed (open), oldest first.
export function owedBySupplier() {
  const m = new Map();
  for (const o of listOwed({})) {
    const s = m.get(o.supplier_uid) || { supplierUid: o.supplier_uid, name: o.supplier_name, value: 0, items: 0, oldest: o.owed_date };
    s.value = r2(s.value + o.leftValue); s.items += 1; if (o.owed_date < s.oldest) s.oldest = o.owed_date;
    m.set(o.supplier_uid, s);
  }
  return [...m.values()].sort((a, b) => b.value - a.value);
}
// Settle (all or part): the goods came, a credit note came, or written off (owner / admin / manager).
export function settleOwed(user, uid, { how, qty, note, receiptUid } = {}) {
  requirePerm(user, ['invoices_check', 'shop_staff'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const o = getOwed(uid);
  need(o && o.status === 'open', 'This is already settled.');
  need(OWED_DONE[how], 'Say how it was settled.');
  if (how === 'written_off') { need(boss(user), 'Only a manager, the admin or the owner writes it off.'); need(txt(note).length >= 3, 'Say why it is written off.'); }
  const q = qty === undefined || qty === null || qty === '' ? o.left : q3(qty);
  need(q > 0 && q <= o.left + 1e-9, `How many (up to ${o.left})?`);
  const done = q3(o.qty_done + q);
  const closed = done >= o.qty - 1e-9;
  const now = stamp();
  db().run(`UPDATE supplier_owed SET qty_done = ?, status = ?, done_how = ?, done_note = ?, done_receipt_uid = COALESCE(?, done_receipt_uid), done_by_name = ?, done_at = ?, ${SY} WHERE uid = ?`,
    [done, closed ? how : 'open', how, txt(note) || null, txt(receiptUid) || null, user.name, now, now, deviceId(), uid]);
  audit({ user, action: `${o.supplier_name}: ${o.name} × ${q} ${how === 'received' ? 'came' : how === 'credited' ? 'credited' : 'written off'}${closed ? '' : ` (${q3(o.qty - done)} still owed)`}`, table: 'supplier_owed', recordUid: uid, reason: txt(note) || null });
  return getOwed(uid);
  });
}
// When a delivery comes from a supplier that owes this product: the owed ones that could be these.
export function owedFor(supplierUid, itemUid) {
  return listOwed({ supplierUid, itemUid }).filter((o) => ['not_delivered', 'short', 'damaged'].includes(o.reason) && o.left > 0);
}
// ---------------------------------------------------------------- damaged found later (opening the cartons)
// Goods from a delivery found damaged when shelving: taken off the stock (kept aside as damaged), put back against
// that delivery's invoice as owed by the supplier until the replacement comes; the shop and the managers are told.
export function damagedSoFar(receiptUid, itemUid) {
  if (!has()) return 0;
  return q3(db().get("SELECT COALESCE(SUM(qty),0) AS q FROM supplier_owed WHERE receipt_uid = ? AND item_uid = ? AND reason = 'damaged'", [receiptUid, itemUid]).q);
}
export function reportDamaged(user, { receiptUid, itemUid, qty, note, photos = [] } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const I = require('./service.js');
  const r = I.getReceipt(receiptUid);
  need(r && r.status === 'active' && r.kind === 'receive', 'Choose the delivery the goods came in.');
  const line = (r.lines || []).find((l) => l.itemUid === itemUid);
  need(line, 'That product is not on this delivery.');
  const q = q3(qty);
  const before = damagedSoFar(receiptUid, itemUid);
  need(q > 0, 'How many are damaged?');
  need(q <= q3(line.qty - before) + 1e-9, `Only ${q3(line.qty - before)} of ${line.name} came on this delivery${before ? ` (${before} already reported damaged)` : ''}.`);
  need((photos || []).length || ['owner', 'admin'].includes(user.role), 'Take a photo of the damaged goods (the supplier will ask for it).');
  I.addMove({ itemUid, shopCode: r.shop_code, date: dateStr(), type: 'adjust', qty: -q, unitCost: line.unitCost, refType: 'damaged_owed', refUid: receiptUid,
    reason: `Damaged – from the delivery of ${r.receive_date} (${r.supplier_name}), kept aside until replaced`, note: txt(note) || null, user });
  const o = addOwed(user, { supplierUid: r.supplier_uid, shopCode: r.shop_code, itemUid, name: line.name, qty: q, unitCost: line.unitCost, reason: 'damaged',
    invoiceUid: r.invoice_uid, invoiceNo: r.invoice_no, receiptUid, poUid: r.po_uid, note: `Found damaged after the delivery of ${r.receive_date}${txt(note) ? ` – ${txt(note)}` : ''}`, photos });
  try {
    require('../verify/service.js').notify('delivery', `⚠️ Damaged goods: ${line.name} × ${q} from ${r.supplier_name} (delivery ${r.receive_date}${r.invoice_no ? `, invoice ${r.invoice_no}` : ''}), found by ${user.name}. Kept aside until the supplier replaces them.`, { shopCode: r.shop_code, attach: (photos || []).length ? { photos: photos.slice(0, 2) } : null });
  } catch (e) { /* Viber is optional */ }
  return o;
  });
}
// The message for the supplier (their Viber chat / group): what is owed from which invoice. Marks them as told.
export function supplierMessage(supplierUid, uids = null) {
  const list = listOwed({ supplierUid }).filter((o) => !uids || uids.includes(o.uid));
  if (!list.length) return null;
  const lines = list.map((o) => `• ${o.name} × ${o.left}${o.reason === 'price' ? ` – charged ${(o.unit_cost).toFixed(2)} too much each` : ` – ${OWED_REASON[o.reason].toLowerCase()}`}${o.invoice_no ? ` (invoice ${o.invoice_no})` : ''}`);
  return { text: `Easy Buys Shopping Centre – please replace / credit:\n${lines.join('\n')}\nThank you.`, uids: list.map((o) => o.uid) };
}
export function markTold(user, uids = []) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const now = stamp();
  for (const u of uids) db().run(`UPDATE supplier_owed SET told_at = ?, told_by_name = ?, ${SY} WHERE uid = ? AND told_at IS NULL`, [now, user ? user.name : null, now, deviceId(), u]);
  });
}

// The warnings: open for over a week (the supplier may forget), and before paying a supplier that owes.
export function owedAlerts() {
  const out = [];
  // just reported damaged (today / yesterday): a notification; not told to the supplier yet: a reminder
  const fresh = listOwed({}).filter((o) => o.reason === 'damaged' && o.days <= 1);
  for (const o of fresh) out.push({ id: `owed-damaged-${o.uid}`, level: 'warning', notify: true, text: `Damaged: ${o.name} × ${o.left} from ${o.supplier_name} – waiting for a replacement`, sub: `${o.note || ''}${o.told_at ? ' · supplier told' : ' · tell the supplier'}`, nav: { screen: 'SupplierOwed', params: { supplierUid: o.supplier_uid } } });
  const untold = listOwed({}).filter((o) => !o.told_at && o.days >= 1);
  if (untold.length) out.push({ id: `owed-untold-${untold.length}`, level: 'info', text: `${untold.length} thing${untold.length === 1 ? '' : 's'} owed by suppliers not sent to them yet`, sub: [...new Set(untold.map((o) => o.supplier_name))].slice(0, 3).join(', '), nav: { screen: 'SupplierOwed', params: {} } });
  const old = listOwed({}).filter((o) => o.days >= 7);
  if (old.length) {
    const v = r2(old.reduce((t, o) => t + o.leftValue, 0));
    out.push({ id: `owed-old-${old.length}-${v}`, level: 'warning', text: `Suppliers owe $${v.toFixed(2)} of goods for over a week (${old.length} item${old.length === 1 ? '' : 's'})`,
      sub: old.slice(0, 3).map((o) => `${o.supplier_name}: ${o.name} × ${o.left}`).join(' · '), nav: { screen: 'SupplierOwed', params: {} } });
  }
  return out;
}
