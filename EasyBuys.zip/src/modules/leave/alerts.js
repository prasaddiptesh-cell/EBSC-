// Warnings for Home: leave requests waiting for a decision.
import { can } from '../../services/access.js';
import { listLeave } from './service.js';

export function alerts(user) {
  if (!can(user, 'leave_approve')) return [];
  const n = listLeave({ status: 'requested' }).length;
  return n ? [{ id: 'leave-waiting', level: 'info', text: `${n} leave request${n === 1 ? '' : 's'} waiting`, sub: 'Approve or decline.', nav: { screen: 'Leave', params: { tab: 'approve' } } }] : [];
}
