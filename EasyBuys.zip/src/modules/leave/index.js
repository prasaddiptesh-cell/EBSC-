// Leave module: types and days allowed, requests, approval, balances.
import LeaveScreen from './screens/LeaveScreen.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'leave',
  title: 'Leave',
  icon: '🌴',
  switchable: true,
  screens: {
    Leave: { component: LeaveScreen, can: (u) => can(u, 'my_hours') || can(u, 'leave_approve') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
