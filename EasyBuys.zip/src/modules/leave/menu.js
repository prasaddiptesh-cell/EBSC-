// Leave menu: every tab of the Leave screen is its own item.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🌴', title: 'Leave', note: 'Requests to approve first (managers), otherwise your own leave.', screen: 'Leave' },
    { id: 'leave-mine', icon: '🙋', title: 'My leave', note: 'Ask for leave, see what is left.', screen: 'Leave', params: { tab: 'mine' }, perm: 'my_hours' },
    { id: 'leave-approve', icon: '✅', title: 'Leave to approve', screen: 'Leave', params: { tab: 'approve' }, perm: 'leave_approve' },
    { id: 'leave-ask', icon: '➕', title: 'Leave for a staff member', screen: 'Leave', params: { tab: 'ask' }, perm: 'leave_approve' },
  ] },
  { section: 'Records', items: [
    { id: 'leave-all', icon: '📅', title: 'Everyone\'s leave', screen: 'Leave', params: { tab: 'all' }, perm: 'leave_approve' },
    { id: 'leave-calendar', icon: '🗓️', title: 'Leave calendar', screen: 'Leave', params: { tab: 'calendar' }, perm: 'leave_approve' },
  ] },
  { section: 'Reports', items: [
    { id: 'leave-reports', icon: '📊', title: 'Leave reports', screen: 'ReportsHub', params: { group: 'Leave' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'leave-setup', icon: '⚙️', title: 'Leave types and days', screen: 'Leave', params: { tab: 'setup' }, perm: 'leave_setup' },
  ] },
];
