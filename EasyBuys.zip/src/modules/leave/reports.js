// Leave reports.
import { db } from '../../db/connection.js';
import { stamp } from '../../services/core.js';
import { balances, listLeave, STATUS_LABEL } from './service.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`,
  info: [['Period', `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});

export const REPORTS = [
  { id: 'leave_taken', group: 'Leave', icon: '🌴', title: 'Leave taken & booked', desc: 'Every leave request in the period', perm: 'leave_approve',
    build(from, to) {
      const rows = listLeave({ from, to, limit: 5000 }).map((r) => ({ name: r.name, type: r.type_name || r.type, from: r.from_date, to: r.to_date, days: r.days, status: STATUS_LABEL[r.status], by: r.decided_by_name || '', reason: r.reason || '', _tone: r.status === 'requested' ? 'warn' : r.status === 'declined' ? 'bad' : null }));
      return base('leave_taken', 'Leave Report', from, to, {
        summary: [{ label: 'Approved days', value: String(rows.filter((r) => r.status === 'Approved').reduce((a, r) => a + r.days, 0)), tone: 'good' }, { label: 'Waiting', value: String(rows.filter((r) => r.status === 'Waiting').length), tone: 'warn' }],
        sections: [{ title: 'Leave', columns: [col('name', 'Name'), col('type', 'Type'), col('from', 'From'), col('to', 'To'), col('days', 'Days', 'right'), col('status', 'Status'), col('by', 'Decided by'), col('reason', 'Reason')], rows }],
      });
    } },
  { id: 'leave_balances', group: 'Leave', icon: '⚖️', title: 'Leave balances', desc: 'Days allowed, taken and left per person', perm: 'leave_approve',
    build(from, to) {
      const year = Number(to.slice(0, 4));
      const rows = [];
      db().all('SELECT uid, name, employee_no FROM users WHERE active = 1 ORDER BY name').forEach((u) => balances(u.uid, year).filter((b) => b.limited || b.taken).forEach((b) => rows.push({
        name: u.name, emp: u.employee_no || '', type: b.name, allowed: b.allowed, taken: b.taken, waiting: b.waiting, left: b.left, _tone: b.limited && b.left < 0 ? 'bad' : null,
      })));
      return base('leave_balances', `Leave Balances ${year}`, `${year}-01-01`, `${year}-12-31`, { sections: [{ title: `Balances ${year}`, columns: [col('name', 'Name'), col('emp', 'Emp no'), col('type', 'Type'), col('allowed', 'Allowed', 'right'), col('taken', 'Taken', 'right'), col('waiting', 'Waiting', 'right'), col('left', 'Left', 'right')], rows }] });
    } },
];
