// Leave: my leave (ask, see balances), to approve, everyone's leave, and setup.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import {
  Screen, Card, H, Btn, Badge, Banner, Chips, Field, Row, Section, Select, NumberField, PhotoPicker, useApp, useUI,
} from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { db } from '../../../db/connection.js';
import { can } from '../../../services/access.js';
import { dateStr, addDays } from '../../../services/core.js';
import { addPhotos } from '../../../services/stock.js';
import {
  listLeaveTypes, saveLeaveType, balances, requestLeave, decideLeave, cancelLeave, listLeave, STATUS_LABEL, countLeaveDays,
  leaveRules, saveLeaveRules, setEntitlement, entitlement, whoIsOff, leaveCalendar, clashesFor,
} from '../service.js';
import { listShops } from '../../admin/service.js';
import { Hint } from '../../../ui/kit.js';

const STATUS_COLOR = { requested: C.warn, approved: C.success, declined: C.danger, cancelled: C.sub };

function LeaveCard({ r, children }) {
  return (
    <Card tone={r.status === 'requested' ? 'warn' : undefined}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, flex: 1 }}>{r.name} · {r.type_name || r.type}</Text>
        <Badge text={STATUS_LABEL[r.status]} color={STATUS_COLOR[r.status]} />
      </View>
      <Text style={{ fontSize: 16, color: C.text }}>{r.from_date === r.to_date ? r.from_date : `${r.from_date} to ${r.to_date}`} · {r.days} day(s)</Text>
      {r.reason ? <Text style={{ fontSize: 15, color: C.sub }}>Reason: {r.reason}</Text> : null}
      {r.decided_by_name ? <Text style={{ fontSize: 14, color: C.sub }}>{STATUS_LABEL[r.status]} by {r.decided_by_name} {r.decided_at ? r.decided_at.slice(0, 16) : ''}{r.decision_note ? ` – ${r.decision_note}` : ''}</Text> : null}
      {children}
    </Card>
  );
}

export default function LeaveScreen({ params }) {
  const { user } = useApp();
  const ui = useUI();
  const approver = can(user, 'leave_approve');
  const setup = can(user, 'leave_setup');
  const [tab, setTab] = useState(params.tab || (approver ? 'approve' : 'mine'));
  const [, refresh] = useState(0);
  const run = (fn, msg) => { try { fn(); ui.toast(msg); refresh((n) => n + 1); return true; } catch (e) { ui.error(e); return false; } };
  const waiting = approver ? listLeave({ status: 'requested' }) : [];
  const tabs = [{ value: 'mine', label: '🌴 My leave' }];
  if (approver) tabs.push({ value: 'approve', label: `✅ To approve${waiting.length ? ` (${waiting.length})` : ''}` }, { value: 'all', label: '📅 Everyone' }, { value: 'calendar', label: '🗓️ Calendar' }, { value: 'ask', label: '➕ For staff' });
  if (setup) tabs.push({ value: 'setup', label: '⚙️ Setup' });
  return (
    <Screen title="Leave" subtitle="Annual, sick and other leave">
      <Chips value={tab} onChange={setTab} testIDPrefix="leave-tab" options={tabs} />
      {tab === 'mine' ? <AskLeave forUid={user.uid} user={user} run={run} showMine /> : null}
      {tab === 'ask' ? <AskLeave user={user} run={run} chooseStaff /> : null}
      {tab === 'approve' ? (
        <Section title="Waiting for approval">
          {!waiting.length ? <Banner tone="success" message="Nothing waiting." /> : null}
          {waiting.map((r) => <ApproveCard key={r.uid} r={r} user={user} run={run} />)}
        </Section>
      ) : null}
      {tab === 'all' ? <Everyone /> : null}
      {tab === 'calendar' ? <LeaveCalendar /> : null}
      {tab === 'setup' ? <LeaveSetup user={user} run={run} /> : null}
    </Screen>
  );
}

function ApproveCard({ r, user, run }) {
  const [note, setNote] = useState('');
  const bal = balances(r.user_uid, Number(r.from_date.slice(0, 4))).find((b) => b.type === r.type);
  return (
    <LeaveCard r={r}>
      {bal && bal.limited ? <Text style={{ fontSize: 15, color: C.sub }}>{r.name} has {bal.left + r.days} day(s) of {bal.name} before this request.</Text> : null}
      {r.photo_url || r.photo_uri ? <Text style={{ fontSize: 14, color: C.info }}>📎 Photo attached</Text> : null}
      {(() => { const c = clashesFor(r.uid); return c.length ? <Banner tone="warn" title="Others from the same shop are off then" message={c.map((x) => `${x.name}: ${x.from_date} to ${x.to_date} (${STATUS_LABEL[x.status]})`).join('\n')} /> : null; })()}
      <Field testID={`leave-note-${r.uid}`} label="Note (needed to decline)" value={note} onChangeText={setNote} />
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
        <Btn testID={`leave-decline-${r.uid}`} title="Decline" variant="danger" size="md" style={{ flex: 1 }} onPress={() => run(() => decideLeave(user, r.uid, false, note), 'Declined')} />
        <Btn testID={`leave-approve-${r.uid}`} title="Approve" variant="success" size="md" style={{ flex: 1 }} onPress={() => run(() => decideLeave(user, r.uid, true, note), 'Approved')} />
      </View>
    </LeaveCard>
  );
}

function AskLeave({ user, run, forUid, showMine, chooseStaff }) {
  const types = listLeaveTypes();
  const staff = chooseStaff ? db().all('SELECT uid, name FROM users WHERE active = 1 ORDER BY name') : [];
  const [who, setWho] = useState(forUid || null);
  const [type, setType] = useState('ANNUAL');
  const [from, setFrom] = useState(addDays(dateStr(), 1));
  const [to, setTo] = useState(addDays(dateStr(), 1));
  const [half, setHalf] = useState(false);
  const [reason, setReason] = useState('');
  const [photos, setPhotos] = useState([]);
  const [cancelReason, setCancelReason] = useState('');
  let days = null;
  try { days = half ? 0.5 : countLeaveDays(from, to); } catch (e) { days = null; }
  const bal = who ? balances(who) : [];
  const mine = showMine && who ? listLeave({ userUid: who, limit: 50 }) : [];
  const t = types.find((x) => x.code === type);
  const submit = () => {
    const ok = run(() => {
      const uid = requestLeave(user, { userUid: who, type, from, to: half ? from : to, halfDay: half, reason, photoUri: photos[0] });
      if (photos.length) addPhotos('leave', uid, photos);
    }, 'Leave asked for');
    if (ok) { setReason(''); setPhotos([]); }
  };
  return (
    <>
      {showMine && who ? (
        <Section title="Leave left this year">
          {bal.filter((b) => b.limited || b.taken || b.waiting).map((b) => (
            <Row key={b.type} label={b.name} value={b.limited ? `${b.left} left of ${b.allowed}${b.waiting ? ` · ${b.waiting} waiting` : ''}` : `${b.taken} taken`} bold color={b.limited && b.left <= 0 ? C.danger : undefined} />
          ))}
        </Section>
      ) : null}
      <Card>
        <View style={{ gap: 12 }}>
          <H>{chooseStaff ? 'Ask for leave for a staff member' : 'Ask for leave'}</H>
          {chooseStaff ? <Select testID="leave-who" label="Staff member" value={who} onChange={setWho} options={staff.map((s) => ({ value: s.uid, label: s.name }))} /> : null}
          <Select testID="leave-type" label="Type" value={type} onChange={setType} options={types.map((x) => ({ value: x.code, label: x.name, hint: x.paid ? 'Paid' : 'Unpaid' }))} />
          <Chips value={half ? 'half' : 'full'} onChange={(v) => setHalf(v === 'half')} options={[{ value: 'full', label: 'Full days' }, { value: 'half', label: 'Half day' }]} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Field testID="leave-from" label="First day (YYYY-MM-DD)" value={from} onChangeText={(v) => { setFrom(v); if (to < v) setTo(v); }} /></View>
            {!half ? <View style={{ flex: 1 }}><Field testID="leave-to" label="Last day" value={to} onChangeText={setTo} /></View> : null}
          </View>
          <Text style={{ fontSize: 16, color: C.sub }}>{days === null ? 'Check the dates.' : `${days} day(s) of leave (${leaveRules().countDays === 'mon_sat' ? 'Monday to Saturday count' : leaveRules().countDays === 'mon_fri' ? 'Monday to Friday count' : 'every day counts'})`}</Text>
          <Field testID="leave-reason" label="Reason (optional)" value={reason} onChangeText={setReason} />
          <PhotoPicker label={t && t.needs_photo ? 'Medical certificate / proof' : 'Photo (e.g. medical certificate)'} required={!!(t && t.needs_photo)} value={photos} onChange={setPhotos} />
          <Btn testID="leave-submit" title="Send request" icon="📨" onPress={submit} disabled={!who} />
        </View>
      </Card>
      {showMine ? (
        <Section title="My requests">
          {!mine.length ? <Text style={{ fontSize: 16, color: C.sub }}>No leave yet.</Text> : null}
          {mine.map((r) => (
            <LeaveCard key={r.uid} r={r}>
              {['requested', 'approved'].includes(r.status) && r.from_date > dateStr() ? (
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, alignItems: 'flex-end' }}>
                  <View style={{ flex: 1 }}><Field label="Reason to cancel" value={cancelReason} onChangeText={setCancelReason} /></View>
                  <Btn title="Cancel" size="md" variant="secondary" onPress={() => run(() => cancelLeave(user, r.uid, cancelReason), 'Cancelled')} />
                </View>
              ) : null}
            </LeaveCard>
          ))}
        </Section>
      ) : null}
    </>
  );
}

function Everyone() {
  const [from, setFrom] = useState(dateStr());
  const list = listLeave({ from, to: addDays(from, 60), limit: 300 }).filter((r) => r.status !== 'cancelled');
  const off = whoIsOff(dateStr());
  return (
    <>
      <Banner tone="info" title={`Off today: ${off.length}`} message={off.length ? off.map((r) => `${r.name} (${r.type_name})`).join(', ') : 'Nobody is on leave today.'} />
      <Field label="Show leave from (YYYY-MM-DD), next 60 days" value={from} onChangeText={setFrom} />
      {list.map((r) => <LeaveCard key={r.uid} r={r} />)}
      {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No leave in this period.</Text> : null}
    </>
  );
}

function LeaveSetup({ user, run }) {
  const types = listLeaveTypes({ includeInactive: true });
  const rules = leaveRules();
  const [r, setR] = useState(rules);
  const [nt, setNt] = useState({ code: '', name: '', paid: true, defaultDays: 0, needsPhoto: false });
  const staff = db().all('SELECT uid, name FROM users WHERE active = 1 ORDER BY name');
  const [who, setWho] = useState(null);
  const year = Number(dateStr().slice(0, 4));
  return (
    <>
      <Section title="Rules">
        <Chips value={r.countDays} onChange={(v) => setR({ ...r, countDays: v })} testIDPrefix="leave-count"
          options={[{ value: 'mon_sat', label: 'Mon–Sat count' }, { value: 'mon_fri', label: 'Mon–Fri count' }, { value: 'all', label: 'Every day counts' }]} />
        <Chips value={r.allowOverBalance ? 'yes' : 'no'} onChange={(v) => setR({ ...r, allowOverBalance: v === 'yes' })}
          options={[{ value: 'no', label: 'Stop at 0 days left' }, { value: 'yes', label: 'Allow going over' }]} />
        <NumberField label="Annual leave must be asked this many days ahead (0 = no rule)" value={r.noticeDays} onChange={(v) => setR({ ...r, noticeDays: v || 0 })} />
        <NumberField label="Sick leave longer than this many days needs a medical certificate photo (0 = never)" value={r.sickPhotoAfterDays} onChange={(v) => setR({ ...r, sickPhotoAfterDays: v || 0 })} />
        <NumberField label="Warn when more than this many people of one shop are off at once (0 = no warning)" value={r.maxOffPerShop} onChange={(v) => setR({ ...r, maxOffPerShop: v || 0 })} />
        <Btn testID="leave-rules-save" title="Save rules" size="md" onPress={() => run(() => saveLeaveRules(user, r), 'Saved')} />
      </Section>
      <Section title="Leave types (days a year for everyone)">
        {types.map((t) => <TypeRow key={t.code} t={t} user={user} run={run} />)}
        <Card>
          <H>Add a leave type</H>
          <View style={{ gap: 10 }}>
            <Field label="Short code (e.g. FAMILY)" value={nt.code} onChangeText={(v) => setNt({ ...nt, code: v })} />
            <Field label="Name" value={nt.name} onChangeText={(v) => setNt({ ...nt, name: v })} />
            <NumberField label="Days a year" value={nt.defaultDays} onChange={(v) => setNt({ ...nt, defaultDays: v || 0 })} />
            <Chips value={nt.paid ? 'paid' : 'unpaid'} onChange={(v) => setNt({ ...nt, paid: v === 'paid' })} options={[{ value: 'paid', label: 'Paid' }, { value: 'unpaid', label: 'Unpaid' }]} />
            <Btn title="Add" size="md" onPress={() => run(() => saveLeaveType(user, nt), 'Added')} />
          </View>
        </Card>
      </Section>
      <Section title={`Days allowed for one person (${year})`}>
        <Select label="Staff member" value={who} onChange={setWho} options={staff.map((s) => ({ value: s.uid, label: s.name }))} />
        {who ? types.filter((t) => t.active).map((t) => <EntRow key={who + t.code} who={who} t={t} year={year} user={user} run={run} />) : null}
      </Section>
    </>
  );
}

function TypeRow({ t, user, run }) {
  const [days, setDays] = useState(t.default_days);
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, flex: 1, minWidth: 140 }}>{t.name}{t.active ? '' : ' (off)'}</Text>
        <Badge text={t.paid ? 'Paid' : 'Unpaid'} color={t.paid ? C.success : C.sub} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, marginTop: 8 }}>
        <View style={{ flex: 1 }}><NumberField testID={`lt-days-${t.code}`} compact label="Days a year" value={days} onChange={(v) => setDays(v || 0)} /></View>
        <Btn testID={`lt-save-${t.code}`} title="Save" size="md" onPress={() => run(() => saveLeaveType(user, { code: t.code, name: t.name, paid: !!t.paid, defaultDays: days, needsPhoto: !!t.needs_photo, active: !!t.active }), 'Saved')} />
        <Btn title={t.active ? 'Turn off' : 'Turn on'} size="md" variant="secondary" onPress={() => run(() => saveLeaveType(user, { code: t.code, name: t.name, paid: !!t.paid, defaultDays: t.default_days, needsPhoto: !!t.needs_photo, active: !t.active }), 'Saved')} />
      </View>
    </Card>
  );
}

function EntRow({ who, t, year, user, run }) {
  const [days, setDays] = useState(entitlement(who, t.code, year));
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10 }}>
      <View style={{ flex: 1 }}><NumberField compact label={t.name} value={days} onChange={(v) => setDays(v || 0)} /></View>
      <Btn title="Save" size="md" onPress={() => run(() => setEntitlement(user, who, t.code, year, days), 'Saved')} />
    </View>
  );
}

const WDL = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function LeaveCalendar() {
  const [ym, setYm] = useState(dateStr().slice(0, 7));
  const [shop, setShop] = useState('');
  const days = leaveCalendar(ym, { shopCode: shop || undefined });
  const move = (n) => { const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7)) + n; setYm(m < 1 ? `${y - 1}-12` : m > 12 ? `${y + 1}-01` : `${y}-${String(m).padStart(2, '0')}`); };
  return (
    <Section title={`Who is off – ${ym}`}>
      <Hint>Approved leave and leave waiting for approval. Days in orange have more people of one shop off than the limit set in Setup.</Hint>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹" size="sm" variant="secondary" onPress={() => move(-1)} />
        <Btn title="›" size="sm" variant="secondary" onPress={() => move(1)} />
      </View>
      <Chips value={shop} onChange={setShop} options={[{ value: '', label: 'All shops' }].concat(listShops().filter((x) => x.active).map((x) => ({ value: x.code, label: x.code })))} />
      {days.filter((d) => d.off.length).map((d) => (
        <Card key={d.date} tone={d.tooMany ? 'warn' : undefined}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{WDL[new Date(`${d.date}T00:00:00`).getDay()]} {d.date}{d.tooMany ? ' – too many off' : ''}</Text>
          <Text style={{ fontSize: 15, color: C.sub }}>{d.off.map((o) => `${o.name}${o.shop ? ` (${o.shop})` : ''} – ${o.type}${o.status === 'requested' ? ' (asked)' : ''}`).join(', ')}</Text>
        </Card>
      ))}
      {!days.some((d) => d.off.length) ? <Text style={{ color: C.sub }}>Nobody is off this month.</Text> : null}
    </Section>
  );
}
