// Leave: types and days allowed (admin), requests (staff), approval (manager), balances.
// Works offline; requests and decisions are shared through the cloud.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, getShared, setShared, dateStr } from '../../services/core.js';

export const STATUS_LABEL = { requested: 'Waiting', approved: 'Approved', declined: 'Declined', cancelled: 'Cancelled' };

export const LEAVE_RULE_DEFAULTS = {
  countDays: 'mon_sat',        // which days count as leave days: 'all' | 'mon_sat' | 'mon_fri'
  allowOverBalance: false,     // allow asking for more days than are left
  noticeDays: 0,               // annual leave must be asked this many days ahead (0 = no rule)
};
export function leaveRules() {
  return { ...LEAVE_RULE_DEFAULTS, ...(getShared('leave_rules', {}) || {}) };
}
export function saveLeaveRules(user, r) {
  if (!['all', 'mon_sat', 'mon_fri'].includes(r.countDays)) throw new AppError('Choose which days count.');
  const n = Number(r.noticeDays);
  if (!Number.isFinite(n) || n < 0 || n > 90) throw new AppError('Notice days must be between 0 and 90.');
  const clean = { countDays: r.countDays, allowOverBalance: !!r.allowOverBalance, noticeDays: Math.round(n) };
  const before = leaveRules();
  setShared('leave_rules', clean);
  audit({ user, action: 'Changed leave rules', table: 'shared_settings', recordUid: 'leave_rules', before, after: clean });
}

// ---------- types ----------
export function listLeaveTypes({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM leave_types ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort, name`);
}
export function saveLeaveType(user, { code, name, paid, defaultDays, needsPhoto, active = true }) {
  const c = String(code || '').trim().toUpperCase().replace(/[^A-Z0-9_]/g, '');
  const n = String(name || '').trim();
  if (!c) throw new AppError('Enter a short code, e.g. FAMILY.');
  if (!n) throw new AppError('Enter a name.');
  const d = Number(defaultDays);
  if (!Number.isFinite(d) || d < 0 || d > 365) throw new AppError('Days a year must be between 0 and 365.');
  const before = db().get('SELECT * FROM leave_types WHERE code = ?', [c]);
  const now = stamp();
  db().run(
    `INSERT INTO leave_types (code, name, paid, default_days, needs_photo, active, sort, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, ?, ?, ?, COALESCE((SELECT MAX(sort) + 1 FROM leave_types), 0), ?, ?, 'pending')
     ON CONFLICT(code) DO UPDATE SET name = excluded.name, paid = excluded.paid, default_days = excluded.default_days,
       needs_photo = excluded.needs_photo, active = excluded.active, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [c, n, paid ? 1 : 0, d, needsPhoto ? 1 : 0, active ? 1 : 0, now, deviceId()]
  );
  audit({ user, action: before ? 'Changed leave type' : 'Added leave type', table: 'leave_types', recordUid: c, before, after: { name: n, paid, defaultDays: d, needsPhoto, active } });
}

// ---------- days allowed ----------
export function entitlement(userUid, type, year) {
  const own = db().get('SELECT days FROM leave_entitlements WHERE uid = ?', [`${userUid}|${type}|${year}`]);
  if (own) return own.days;
  const t = db().get('SELECT default_days FROM leave_types WHERE code = ?', [type]);
  return t ? t.default_days : 0;
}
export function setEntitlement(user, userUid, type, year, days) {
  const d = Number(days);
  if (!Number.isFinite(d) || d < 0 || d > 365) throw new AppError('Days must be between 0 and 365.');
  const uid = `${userUid}|${type}|${year}`;
  const before = entitlement(userUid, type, year);
  const now = stamp();
  db().run(
    `INSERT INTO leave_entitlements (uid, user_uid, type, year, days, updated_at, updated_device, sync_status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
     ON CONFLICT(uid) DO UPDATE SET days = excluded.days, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [uid, userUid, type, Number(year), d, now, deviceId()]
  );
  audit({ user, action: 'Changed days allowed', table: 'leave_entitlements', recordUid: uid, before: { days: before }, after: { days: d } });
}

// ---------- counting days ----------
export function countLeaveDays(from, to, rule = leaveRules().countDays) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) throw new AppError('Enter dates as YYYY-MM-DD.');
  if (to < from) throw new AppError('The last day is before the first day.');
  let n = 0;
  for (let d = from; d <= to; d = addDays(d, 1)) {
    const [y, m, dd] = d.split('-').map(Number);
    const wd = new Date(y, m - 1, dd).getDay();
    if (rule === 'all' || (rule === 'mon_sat' && wd !== 0) || (rule === 'mon_fri' && wd !== 0 && wd !== 6)) n += 1;
    if (n > 400) break;
  }
  return n;
}

// ---------- balances ----------
export function balances(userUid, year = Number(dateStr().slice(0, 4))) {
  return listLeaveTypes().map((t) => {
    const allowed = entitlement(userUid, t.code, year);
    const rows = db().all(
      "SELECT status, days FROM leave_requests WHERE user_uid = ? AND type = ? AND substr(from_date, 1, 4) = ? AND status IN ('approved','requested')",
      [userUid, t.code, String(year)]
    );
    const taken = rows.filter((r) => r.status === 'approved').reduce((a, r) => a + r.days, 0);
    const waiting = rows.filter((r) => r.status === 'requested').reduce((a, r) => a + r.days, 0);
    return { type: t.code, name: t.name, paid: !!t.paid, allowed, taken, waiting, left: allowed - taken - waiting, limited: allowed > 0 };
  });
}

// ---------- requests ----------
export function requestLeave(byUser, { userUid, type, from, to, halfDay = false, reason, photoUri }) {
  const person = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  if (!person) throw new AppError('Staff member not found.');
  const t = db().get('SELECT * FROM leave_types WHERE code = ? AND active = 1', [type]);
  if (!t) throw new AppError('Choose the type of leave.');
  const rules = leaveRules();
  let days = countLeaveDays(from, to, rules.countDays);
  if (halfDay) {
    if (from !== to) throw new AppError('A half day must start and end on the same date.');
    days = 0.5;
  }
  if (!days) throw new AppError('Those dates have no working days.');
  if (t.needs_photo && !photoUri) throw new AppError(`${t.name} needs a photo (e.g. a medical certificate).`);
  if (type === 'ANNUAL' && rules.noticeDays && from < addDays(dateStr(), rules.noticeDays)) {
    throw new AppError(`Annual leave must be asked for at least ${rules.noticeDays} days ahead.`);
  }
  const clash = db().get(
    "SELECT from_date, to_date, status FROM leave_requests WHERE user_uid = ? AND status IN ('requested','approved') AND from_date <= ? AND to_date >= ?",
    [userUid, to, from]
  );
  if (clash) throw new AppError(`There is already leave from ${clash.from_date} to ${clash.to_date} (${STATUS_LABEL[clash.status]}).`);
  const bal = balances(userUid, Number(from.slice(0, 4))).find((b) => b.type === type);
  if (bal && bal.limited && days > bal.left && !rules.allowOverBalance) {
    throw new AppError(`Only ${bal.left} day(s) of ${t.name} left this year.`);
  }
  const uid = uuid('L');
  const now = stamp();
  db().run(
    `INSERT INTO leave_requests (uid, user_uid, name, type, from_date, to_date, days, reason, photo_uri, status, requested_by_uid, requested_at, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'requested', ?, ?, ?, ?, 'pending')`,
    [uid, userUid, person.name, type, from, to, days, String(reason || '').trim() || null, photoUri || null, byUser ? byUser.uid : null, now, now, deviceId()]
  );
  audit({ user: byUser, action: `Asked for ${t.name} for ${person.name}`, table: 'leave_requests', recordUid: uid, after: { from, to, days } });
  return uid;
}

export function decideLeave(byUser, uid, approve, note = '') {
  const r = db().get('SELECT * FROM leave_requests WHERE uid = ?', [uid]);
  if (!r) throw new AppError('Request not found.');
  if (r.status !== 'requested') throw new AppError(`Already ${STATUS_LABEL[r.status].toLowerCase()}.`);
  if (byUser && r.user_uid === byUser.uid) throw new AppError('You cannot approve your own leave. Ask another manager or the owner.');
  if (!approve && !String(note || '').trim()) throw new AppError('Please give a reason for declining.');
  const now = stamp();
  db().run(
    `UPDATE leave_requests SET status = ?, decided_by_uid = ?, decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [approve ? 'approved' : 'declined', byUser ? byUser.uid : null, byUser ? byUser.name : null, now, String(note || '').trim() || null, now, deviceId(), uid]
  );
  audit({ user: byUser, action: `${approve ? 'Approved' : 'Declined'} leave for ${r.name}`, table: 'leave_requests', recordUid: uid, reason: note });
}

export function cancelLeave(byUser, uid, reason) {
  const r = db().get('SELECT * FROM leave_requests WHERE uid = ?', [uid]);
  if (!r) throw new AppError('Request not found.');
  if (!['requested', 'approved'].includes(r.status)) throw new AppError('This leave cannot be cancelled.');
  if (!String(reason || '').trim()) throw new AppError('Please give a reason.');
  const now = stamp();
  db().run(`UPDATE leave_requests SET status = 'cancelled', decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [String(reason).trim(), now, deviceId(), uid]);
  audit({ user: byUser, action: `Cancelled leave for ${r.name}`, table: 'leave_requests', recordUid: uid, reason });
}

export function listLeave({ status, userUid, from, to, limit = 500 } = {}) {
  const w = [];
  const a = [];
  if (status) { w.push('status = ?'); a.push(status); }
  if (userUid) { w.push('user_uid = ?'); a.push(userUid); }
  if (from) { w.push('to_date >= ?'); a.push(from); }
  if (to) { w.push('from_date <= ?'); a.push(to); }
  return db().all(`SELECT r.*, t.name AS type_name, t.paid FROM leave_requests r LEFT JOIN leave_types t ON t.code = r.type
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY from_date DESC LIMIT ?`, a.concat([limit]));
}

// Who is off on a given day (approved leave).
export function whoIsOff(date = dateStr()) {
  return listLeave({ status: 'approved', from: date, to: date });
}
