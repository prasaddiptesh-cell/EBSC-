// Warnings for Home: licences and permits expired (urgent) or to renew soon.
import { can } from '../../services/access.js';
import { licenceAlerts, alertText } from './service.js';

export function alerts(user) {
  if (!(can(user, 'licences_view') || can(user, 'licences_manage'))) return [];
  const a = licenceAlerts();
  return a.list.map((l) => ({
    id: `lic-${l.uid}-${l.state}`,
    level: l.state === 'overdue' ? 'urgent' : l.state === 'renewing' ? 'info' : 'warning',
    text: alertText(l),
    nav: { screen: 'Licence', params: { uid: l.uid } },
  }));
}
