// Warnings for Home (v3.5 B7, escalating): the responsible person and the backup from the first reminder step
// (90 days), the owner from 30 days, urgent (with the alarm sound) from 7 days, and once expired every day to every
// manager and the owner. Also: renewals waiting for the owner's sign-off and licences with no current copy.
import { licenceAlertsFor } from './service.js';

export function alerts(user) {
  return licenceAlertsFor(user).map((a) => ({ ...a, area: 'licences' }));
}
