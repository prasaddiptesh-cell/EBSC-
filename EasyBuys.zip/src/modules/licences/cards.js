// Dashboard cards for licences (v3.5 B7): "Compliance health" (score with reasons) and "Licences" (what is due).
import { registerCard } from '../../services/dashboardCards.js';
import { complianceHealth, licenceAlerts } from './service.js';

export function complianceCard() {
  const h = complianceHealth();
  if (!h.setUp) return { notSetUp: true, text: 'Not set up yet – add the licences and permits.' };
  return { value: `${h.score} / 100`, tone: h.tone, sub: h.problems.length ? `${h.problems.length} thing(s) to fix` : 'Every licence current, with its copy',
    lines: [['Expired', String(h.counts.expired), h.counts.expired ? 'bad' : undefined], ['Due within 30 days', String(h.problems.filter((p) => /left/.test(p.text)).length)],
      ['No current copy', String(h.counts.noCopy), h.counts.noCopy ? 'warn' : undefined], ['Waiting for sign-off', String(h.counts.unsigned), h.counts.unsigned ? 'warn' : undefined]]
      .concat(h.problems.slice(0, 3).map((p) => [p.name, p.text, p.tone])),
    nav: { screen: 'Licences', params: {} } };
}
export function licencesCard() {
  const l = licenceAlerts();
  const h = complianceHealth();
  if (!h.setUp) return { notSetUp: true, text: 'Not set up yet – add the licences and permits.' };
  return { value: l.overdue.length ? `${l.overdue.length} expired` : l.due.length ? `${l.due.length} to renew` : 'All current', tone: l.overdue.length ? 'bad' : l.due.length ? 'warn' : 'good',
    lines: l.list.slice(0, 5).map((x) => [`${x.name}${x.shop_name ? ` (${x.shop_name})` : ''}`, x.expiry_date || '', x.state === 'overdue' ? 'bad' : 'warn']), nav: { screen: 'Licences', params: {} } };
}
registerCard({ id: 'compliance_health', title: 'Compliance health (licences)', icon: '🛡️', order: 105, roles: ['manager'], build: complianceCard });
registerCard({ id: 'licences', title: 'Licences', icon: '📜', order: 100, roles: ['manager'], build: licencesCard });
