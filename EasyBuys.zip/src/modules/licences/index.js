// Licences, permits & company records: copies, applications, renewals and reminders.
import { LicencesScreen, LicenceQuickScreen, LicenceEditScreen, LicenceScreen } from './screens/LicenceScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

const v = (u) => can(u, 'licences_view') || can(u, 'licences_manage');
export default {
  id: 'licences',
  title: 'Licences & permits',
  icon: '📜',
  switchable: true,
  screens: {
    Licences: { component: LicencesScreen, can: v },
    Licence: { component: LicenceScreen, can: v },
    LicenceQuick: { component: LicenceQuickScreen, can: (u) => can(u, 'licences_manage') },
    LicenceEdit: { component: LicenceEditScreen, can: (u) => can(u, 'licences_manage') },
  },
  menu: MENU,
  alerts,
  reports: [],
};
