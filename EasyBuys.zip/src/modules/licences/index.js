// Licences, permits & company records: copies, applications, renewals and reminders – the business's safeguard (v3.5:
// responsible person + backup, escalating reminders, owner sign-off, renewal checklists, document safe, inspection pack,
// conditions, compliance health). Vehicles & equipment is its sub-menu (src/modules/vehicles).
import { LicencesScreen, LicenceQuickScreen, LicenceEditScreen, LicenceScreen, LicenceSettingsScreen } from './screens/LicenceScreens.js';
import { can } from '../../services/access.js';
import { canEditLicences } from './service.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { REPORTS } from './reports.js';
import './cards.js';

const v = (u) => can(u, 'licences_view') || can(u, 'licences_manage') || canEditLicences(u);
export default {
  id: 'licences',
  title: 'Licences & permits',
  icon: '📜',
  switchable: true,
  screens: {
    Licences: { component: LicencesScreen, can: v },
    Licence: { component: LicenceScreen, can: v },
    LicenceQuick: { component: LicenceQuickScreen, can: canEditLicences },
    LicenceEdit: { component: LicenceEditScreen, can: canEditLicences },
    LicenceSettings: { component: LicenceSettingsScreen, can: canEditLicences },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
