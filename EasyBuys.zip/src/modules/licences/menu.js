// Licences & permits menu (Vehicles & equipment is a sub-menu here).
export const MENU = [
  { section: 'Records', items: [
    { id: 'home', icon: '📜', title: 'Licences & permits', note: 'Copies, applications, renewals.', screen: 'Licences' },
    { id: 'lic-vehicles', icon: '🚚', title: 'Vehicles & equipment', note: 'Register, what is due, faults, fuel, running costs.', screen: 'ModuleMenu', params: { module: 'vehicles' } },
  ] },
  { section: 'Reports', items: [
    { id: 'lic-reports', icon: '🛡️', title: 'Inspection pack & compliance report', note: 'Per shop, and the monthly compliance report.', screen: 'ReportsHub', params: { group: 'Licences & compliance' }, perm: ['licences_view', 'licences_manage'] },
  ] },
  { section: 'Settings', items: [
    { id: 'lic-add', icon: '➕', title: 'Add a licence or permit', screen: 'LicenceEdit' },
    { id: 'lic-quick', icon: '⚡', title: 'Quick add the usual ones', screen: 'LicenceQuick' },
    { id: 'lic-settings', icon: '⚙️', title: 'Reminders & renewal checklists', screen: 'LicenceSettings' },
  ] },
];
