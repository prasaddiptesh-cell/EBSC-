// Licences & permits menu.
export const MENU = [
  { section: 'Records', items: [
    { id: 'home', icon: '📜', title: 'Licences & permits', note: 'Copies, applications, renewals.', screen: 'Licences' },
  ] },
  { section: 'Settings', items: [
    { id: 'lic-add', icon: '➕', title: 'Add a licence or permit', screen: 'LicenceEdit' },
    { id: 'lic-quick', icon: '⚡', title: 'Quick add the usual ones', screen: 'LicenceQuick' },
  ] },
];
