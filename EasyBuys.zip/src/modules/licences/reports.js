// Licence reports (PDF / Excel / CSV / print / share through the shared report screen):
// the inspection pack per shop (what an inspector asks to see) and the monthly compliance report.
import { db } from '../../db/connection.js';
import { stamp, dateStr } from '../../services/core.js';
import { inspectionPack, complianceHealth, listLicences, CATEGORIES, EVENT_KINDS, checklistFor } from './service.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const G = 'Licences & compliance';
const STATE = { overdue: 'EXPIRED', due: 'Renew soon', renewing: 'Renewing', ok: 'Current', none: 'No expiry', cancelled: 'No longer held' };
const shopName = (code) => { if (!code || code === 'ALL') return 'Every shop'; const s = db().get('SELECT name FROM shops WHERE code = ?', [code]); return s ? s.name : code; };
const base = (id, title, sub, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/[^A-Za-z0-9]+/g, '-')}-${to}`, subtitle: `Easy Buys Shopping Centre · ${sub}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});

export const REPORTS = [
  { id: 'lic_inspection_pack', group: G, icon: '🗂️', title: 'Inspection pack (per shop)', desc: 'Every licence and permit for the shop: number, dates, conditions, who looks after it and the current copy', perm: 'licences_view',
    build(from, to, user, params = {}) {
      const shop = params.shop || 'ALL';
      const today = dateStr();
      const list = inspectionPack(shop, today);
      const rows = list.map((l) => ({ name: l.name, cat: CATEGORIES[l.category] || l.category, for: l.shop_name || 'Whole business', no: l.licence_no || '', by: l.authority || '', issued: l.issued_date || '', expires: l.expiry_date || 'no expiry',
        state: STATE[l.state] || l.state, who: `${l.people.responsible ? l.people.responsible.name : ''}${l.people.backup ? ` / ${l.people.backup.name}` : ''}`, copy: l.current ? `Yes – ${l.copies[0] ? l.copies[0].name : ''}` : 'NO CURRENT COPY',
        _tone: l.state === 'overdue' || !l.current ? 'bad' : null }));
      const conds = [];
      list.forEach((l) => { if (l.conditions) conds.push({ name: l.name, cond: l.conditions, check: '' }); }); // the free-text conditions
      list.forEach((l) => l.condItems.forEach((c) => conds.push({ name: l.name, cond: c.text, check: c.tick ? (c.ticked_at ? `☑ ${c.ticked_at.slice(0, 10)} ${c.ticked_by || ''}` : '☐ not checked') : '', _tone: c.tick && !c.ticked_at ? 'bad' : null })));
      return base('lic_inspection_pack', `Inspection Pack – ${shopName(shop)}`, `${shopName(shop)} · as at ${today}`, today, today, {
        summary: [{ label: 'Licences & permits', value: String(rows.length) }, { label: 'Expired', value: String(list.filter((l) => l.state === 'overdue').length) }, { label: 'Without a current copy', value: String(list.filter((l) => !l.current).length) }],
        sections: [{ title: 'Licences and permits', columns: [col('name', 'Licence / permit'), col('for', 'For'), col('no', 'Number'), col('by', 'Issued by'), col('issued', 'Issued'), col('expires', 'Expires'), col('state', 'State'), col('who', 'Looked after by / backup'), col('copy', 'Current copy')], rows },
          { title: 'Conditions', columns: [col('name', 'Licence'), col('cond', 'Condition'), col('check', 'Checked')], rows: conds }],
      });
    } },
  { id: 'lic_compliance_month', group: G, icon: '🛡️', title: 'Compliance report (monthly)', desc: 'Health score, renewals done and signed off, what expires in the next 90 days, copies missing, conditions', perm: 'licences_view',
    build(from, to) {
      const h = complianceHealth(to);
      const evs = db().all(`SELECT e.*, l.name, l.shop_code FROM licence_events e JOIN licences l ON l.uid = e.licence_uid WHERE e.event_date BETWEEN ? AND ? ORDER BY e.event_date`, [from, to])
        .map((e) => ({ date: e.event_date, name: e.name, what: EVENT_KINDS[e.kind] || e.kind, note: e.note || '', signed: e.kind === 'renewed' ? (e.signed_at ? `${e.signed_by} ${e.signed_at.slice(0, 10)}` : 'NOT SIGNED OFF') : '', _tone: e.kind === 'renewed' && !e.signed_at ? 'bad' : null }));
      const next = listLicences({ today: to }).filter((l) => l.days !== null && l.days <= 90).map((l) => {
        const c = checklistFor(l);
        return { name: `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''}`, expires: l.expiry_date, days: String(l.days), state: STATE[l.state], checklist: c ? `${c.items.filter((x) => x.done_at).length} of ${c.items.length} done` : 'not started', _tone: l.days < 0 ? 'bad' : null };
      });
      return base('lic_compliance_month', 'Compliance Report', `${from} to ${to}`, from, to, {
        summary: [{ label: 'Health score', value: `${h.score} / 100` }, { label: 'Licences', value: String(h.counts.total) }, { label: 'Expired', value: String(h.counts.expired) }, { label: 'No current copy', value: String(h.counts.noCopy) },
          { label: 'Waiting for sign-off', value: String(h.counts.unsigned) }],
        sections: [{ title: 'To fix', columns: [col('name', 'Licence'), col('shop', 'For'), col('text', 'Problem')], rows: h.problems.map((p) => ({ ...p, _tone: p.tone === 'bad' ? 'bad' : null })) },
          { title: 'Expiring within 90 days', columns: [col('name', 'Licence'), col('expires', 'Expires'), col('days', 'Days left', 'right'), col('state', 'State'), col('checklist', 'Renewal checklist')], rows: next },
          { title: 'What happened this month', columns: [col('date', 'Date'), col('name', 'Licence'), col('what', 'What'), col('note', 'Note'), col('signed', 'Owner sign-off')], rows: evs }],
      });
    } },
];
