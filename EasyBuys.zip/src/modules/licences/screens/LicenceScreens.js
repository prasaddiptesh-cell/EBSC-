// Licences, permits & company records: list with reminders, each one with its copies, applications and history.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, MoneyField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { listShops } from '../../admin/service.js';
import { dateStr } from '../../../services/core.js';
import * as L from '../service.js';

const STATE = {
  overdue: ['EXPIRED', C.danger], due: ['Renew soon', C.warn], renewing: ['Renewal in progress', C.info], ok: ['OK', C.success], none: ['No expiry', C.sub], cancelled: ['No longer held', C.sub],
};
const shopOpts = () => [{ value: '', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name })));
const when = (l) => (l.expiry_date ? (l.days < 0 ? `expired ${-l.days} day(s) ago (${l.expiry_date})` : `expires ${l.expiry_date} · ${l.days} day(s) left`) : 'does not expire');

export function LicencesScreen() {
  const { nav, can } = useApp();
  const [filter, setFilter] = useRemembered('filter', 'all');
  const [shop, setShop] = useRemembered('shop', '');
  const [q, setQ] = useRemembered('q', '');
  const a = L.licenceAlerts();
  const list = L.listLicences({ filter, shopCode: shop || undefined, q });
  const byCat = Object.entries(L.CATEGORIES).map(([k, label]) => [label, list.filter((l) => l.category === k)]).filter(([, x]) => x.length);
  return (
    <Screen title="Licences & permits" subtitle="Copies, applications and renewal reminders">
      <Explain>Every licence, permit, certificate and company record in one place: the current copy, every application ever made (kept for reference), receipts and letters. Reminders start before anything expires – on the Home screen, as a phone notification and (if set up) in the Viber group.</Explain>
      <Stats items={[{ label: 'Expired', value: String(a.overdue.length), color: a.overdue.length ? C.danger : C.success }, { label: 'Renew soon', value: String(a.due.length), color: a.due.length ? C.warn : C.success }, { label: 'Renewing', value: String(a.renewing.length) }]} />
      {a.overdue.map((l) => <Banner key={l.uid} tone="danger" message={L.alertText(l)} />)}
      {can('licences_manage') ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="lic-add" title="Add one" icon="➕" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceEdit', {})} />
          <Btn testID="lic-quick" title="Quick add the usual ones" icon="⚡" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceQuick', {})} />
        </View>
      ) : null}
      <Chips value={filter} onChange={setFilter} testIDPrefix="lic-f" options={[{ value: 'all', label: 'All' }, { value: 'attention', label: `Needs attention (${a.list.length})` }, { value: 'cancelled', label: 'No longer held' }]} />
      <Chips value={shop} onChange={setShop} options={[{ value: '', label: 'Every shop' }, { value: 'ALL', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code })))} />
      <Field label="Search" value={q} onChangeText={setQ} placeholder="name, number, authority" />
      {byCat.map(([label, items]) => (
        <Section key={label} title={label}>
          {items.map((l) => (
            <ListItem key={l.uid} testID={`lic-${l.uid}`} title={`${l.name}${l.shop_name ? ` – ${l.shop_name}` : ''}`} sub={`${l.licence_no ? `No. ${l.licence_no} · ` : ''}${when(l)} · ${l.docs} document(s)`}
              badge={STATE[l.state][0]} badgeColor={STATE[l.state][1]} onPress={() => nav.push('Licence', { uid: l.uid })} />
          ))}
        </Section>
      ))}
      {!list.length ? <Hint>Nothing here yet. Tap "Quick add the usual ones" to start with the common Fiji licences, then fill in the numbers and dates.</Hint> : null}
    </Screen>
  );
}

export function LicenceQuickScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [pick, setPick] = useState({});
  const [shops, setShops] = useState(listShops().filter((s) => s.active).map((s) => s.code));
  const add = () => {
    try {
      let n = 0;
      L.QUICK_ADD.forEach((t, i) => {
        if (!pick[i]) return;
        const targets = t.perShop ? shops : [''];
        targets.forEach((code) => {
          L.saveLicence(user, { name: t.name, category: t.category, authority: t.authority, renewMonths: t.renewMonths, remindDays: t.remindDays, shopCode: code });
          n += 1;
        });
      });
      ui.toast(`${n} added – now open each one to put in the number, the expiry date and the copy`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Quick add" subtitle="The usual licences for a Fiji shop" footer={<Btn testID="lq-add" title="Add the ticked ones" icon="➕" variant="success" onPress={add} />}>
      <Hint>Tick what the business holds. Those marked "each shop" are added once for every shop ticked below. Everything can be changed afterwards.</Hint>
      <Label>Shops</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {listShops().filter((s) => s.active).map((s) => (
          <Btn key={s.code} title={`${shops.includes(s.code) ? '☑' : '☐'} ${s.name}`} size="sm" variant={shops.includes(s.code) ? 'info' : 'secondary'}
            onPress={() => setShops(shops.includes(s.code) ? shops.filter((x) => x !== s.code) : shops.concat([s.code]))} />
        ))}
      </View>
      {L.QUICK_ADD.map((t, i) => (
        <ListItem key={i} testID={`lq-${i}`} title={`${pick[i] ? '☑' : '☐'} ${t.name}${t.perShop ? ' (each shop)' : ''}`} sub={`${t.authority || ''}${t.renewMonths ? ` · renew every ${t.renewMonths} months · reminder ${t.remindDays} days before` : ' · no expiry'}`}
          onPress={() => setPick({ ...pick, [i]: !pick[i] })} />
      ))}
    </Screen>
  );
}

export function LicenceEditScreen({ params }) {
  const { user, nav } = useApp();
  const act = useAct();
  const before = params.uid ? L.getLicence(params.uid) : null;
  const [f, setF] = useState(() => (before ? {
    uid: before.uid, name: before.name, category: before.category, authority: before.authority || '', licenceNo: before.licence_no || '', shopCode: before.shop_code || '', holder: before.holder || '',
    issuedDate: before.issued_date || '', expiryDate: before.expiry_date || '', renewMonths: before.renew_months === null ? '' : String(before.renew_months), remindDays: String(before.remind_days),
    fee: before.fee === null ? '' : String(before.fee), responsible: before.responsible || '', conditions: before.conditions || '', notes: before.notes || '',
  } : { name: '', category: 'trading', authority: '', licenceNo: '', shopCode: '', holder: 'Easy Buys Shopping Centre', issuedDate: '', expiryDate: '', renewMonths: '12', remindDays: '60', fee: '', responsible: '', conditions: '', notes: '' }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const save = () => { const uid = act(() => L.saveLicence(user, f), 'Saved'); if (uid) nav.replace('Licence', { uid }); };
  return (
    <Screen title={before ? `Change ${before.name}` : 'Add a licence / permit'} footer={<Btn testID="le-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Field testID="le-name" label="What is it?" value={f.name} onChangeText={set('name')} placeholder="e.g. Liquor licence" />
      <Label>Type</Label>
      <Choice value={f.category} onChange={set('category')} options={Object.entries(L.CATEGORIES).map(([value, label]) => ({ value, label }))} />
      <Select label="For" value={f.shopCode} onChange={set('shopCode')} options={shopOpts()} />
      <Field label="Issued by (authority)" value={f.authority} onChangeText={set('authority')} />
      <Field testID="le-no" label="Licence / permit / policy number" value={f.licenceNo} onChangeText={set('licenceNo')} />
      <Field label="In the name of (holder)" value={f.holder} onChangeText={set('holder')} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><DateField farDays={false} label="Issued" value={f.issuedDate} onChange={set('issuedDate')} /></View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><DateField farDays={false} testID="le-exp" label="Expires (blank = never)" value={f.expiryDate} onChange={set('expiryDate')} /></View>
      </View>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Renew every … months" value={f.renewMonths} onChangeText={set('renewMonths')} keyboardType="number-pad" /></View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="le-remind" label="Start reminding … days before" value={f.remindDays} onChangeText={set('remindDays')} keyboardType="number-pad" /></View>
      </View>
      <Hint>Liquor licences: the application is due up to 3 months before expiry – 90 days of reminders is a good start.</Hint>
      <MoneyField label="Fee" value={f.fee} onChange={set('fee')} />
      <Field label="Who looks after it" value={f.responsible} onChangeText={set('responsible')} />
      <Field label="Conditions (e.g. trading hours, display rules)" value={f.conditions} onChangeText={set('conditions')} multiline />
      <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
    </Screen>
  );
}

export function LicenceScreen({ params }) {
  const { user, nav, can, refresh } = useApp();
  const act = useAct();
  const [mode, setMode] = useState(null); // 'start' | 'finish' | 'note'
  const [r, setR] = useState({});
  const l = params.uid ? L.getLicence(params.uid) : null;
  if (!l) return <Screen title="Licence"><Banner tone="warn" message="Not found." /></Screen>;
  const days = L.daysLeft(l);
  const manage = can('licences_manage');
  const go = (fn, msg) => { if (act(fn, msg)) { setMode(null); setR({}); refresh(); } };
  return (
    <Screen title={l.name} subtitle={`${l.shop_name || 'Whole business'}${l.licence_no ? ` · No. ${l.licence_no}` : ''}`}>
      <Banner testID="lic-state" tone={{ overdue: 'danger', due: 'warn', renewing: 'info', ok: 'success', none: 'info', cancelled: 'info' }[l.state]}
        title={STATE[l.state][0]} message={l.expiry_date ? (days < 0 ? `Expired on ${l.expiry_date}.` : `Expires on ${l.expiry_date} – ${days} day(s) left. Reminders start ${l.remind_days} days before.`) : 'Does not expire.'} />
      <Card>
        <Row label="Issued by" value={l.authority || '—'} />
        <Row label="Holder" value={l.holder || '—'} />
        <Row label="Issued" value={l.issued_date || '—'} />
        <Row label="Renew every" value={l.renew_months ? `${l.renew_months} months` : '—'} />
        {l.fee !== null ? <Row label="Fee" value={`$${Number(l.fee).toFixed(2)}`} /> : null}
        {l.responsible ? <Row label="Looked after by" value={l.responsible} /> : null}
        {l.conditions ? <Text style={{ color: C.text, marginTop: 6 }}>Conditions: {l.conditions}</Text> : null}
        {l.notes ? <Text style={{ color: C.sub, marginTop: 6 }}>{l.notes}</Text> : null}
      </Card>
      {manage && l.state !== 'cancelled' ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          {l.status !== 'renewing' ? <Btn testID="lic-start" title="Renewal applied for" icon="📨" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => setMode('start')} /> : null}
          <Btn testID="lic-finish" title="Renewed – new expiry" icon="✅" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => setMode('finish')} />
          <Btn title="Add a note" icon="📝" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setMode('note')} />
          <Btn title="Change details" icon="✏️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceEdit', { uid: l.uid })} />
        </View>
      ) : null}
      {mode === 'start' ? (
        <Card>
          <H>Renewal application made</H>
          <Hint>Add the application form and receipt below as documents – they are kept for reference.</Hint>
          <DateField farDays={false} label="Date applied" value={r.date || dateStr()} onChange={(v) => setR({ ...r, date: v })} />
          <Field label="Reference / receipt number" value={r.refNo || ''} onChangeText={(v) => setR({ ...r, refNo: v })} />
          <MoneyField label="Fee paid" value={r.amount || ''} onChange={(v) => setR({ ...r, amount: v })} />
          <Field label="Note" value={r.note || ''} onChangeText={(v) => setR({ ...r, note: v })} />
          <Btn testID="lic-start-save" title="Save" variant="success" onPress={() => go(() => L.startRenewal(user, l.uid, r), 'Saved – reminders now say "renewal in progress"')} />
        </Card>
      ) : null}
      {mode === 'finish' ? (
        <Card>
          <H>Renewed</H>
          <DateField farDays={false} testID="lic-new-exp" label="New expiry date" value={r.newExpiry || ''} onChange={(v) => setR({ ...r, newExpiry: v })} />
          <Hint>{l.renew_months && l.expiry_date ? `Leave blank for ${l.renew_months} months after the old expiry.` : 'Enter the date on the new licence.'}</Hint>
          <DateField farDays={false} label="Issued on" value={r.issuedDate || dateStr()} onChange={(v) => setR({ ...r, issuedDate: v })} />
          <Field label="New number (if it changed)" value={r.licenceNo || ''} onChangeText={(v) => setR({ ...r, licenceNo: v })} />
          <MoneyField label="Fee" value={r.fee || ''} onChange={(v) => setR({ ...r, fee: v })} />
          <Btn testID="lic-finish-save" title="Save – then add the new copy below" variant="success" onPress={() => go(() => L.finishRenewal(user, l.uid, r), 'Renewed')} />
        </Card>
      ) : null}
      {mode === 'note' ? (
        <Card>
          <Select label="What happened" value={r.kind || 'note'} onChange={(v) => setR({ ...r, kind: v })} options={Object.entries(L.EVENT_KINDS).filter(([k]) => !['renewed', 'cancelled', 'reopened'].includes(k)).map(([value, label]) => ({ value, label }))} />
          <DateField label="Date" value={r.date || dateStr()} onChange={(v) => setR({ ...r, date: v })} />
          <Field label="Note" value={r.note || ''} onChangeText={(v) => setR({ ...r, note: v })} multiline />
          <Btn title="Save" variant="success" onPress={() => go(() => L.addEvent(user, l.uid, { kind: r.kind || 'note', date: r.date, note: r.note }), 'Saved')} />
        </Card>
      ) : null}
      <Section title="Documents">
        <DocumentsPanel refType="licence" refUid={l.uid} kinds={L.DOC_KINDS} canAdd={manage} testID="ld" defaultKind="licence_copy" />
      </Section>
      <Section title="History">
        {L.eventsFor(l.uid).map((e) => (
          <ListItem key={e.uid} title={`${L.EVENT_KINDS[e.kind] || e.kind} · ${e.event_date}`} sub={`${e.note || ''}${e.ref_no ? ` · ref ${e.ref_no}` : ''}${e.amount !== null ? ` · $${Number(e.amount).toFixed(2)}` : ''} · ${e.by_name || ''}`} />
        ))}
        {!L.eventsFor(l.uid).length ? <Hint>Nothing recorded yet.</Hint> : null}
      </Section>
      {manage ? (l.state === 'cancelled'
        ? <Btn title="Put back in use" size="md" variant="secondary" onPress={() => go(() => L.reopenLicence(user, l.uid), 'Done')} />
        : <ReasonButton title="No longer held" prompt="Why? (e.g. shop closed)" confirm="Save" onDo={(w) => go(() => L.cancelLicence(user, l.uid, w), 'Saved')} />) : null}
    </Screen>
  );
}
