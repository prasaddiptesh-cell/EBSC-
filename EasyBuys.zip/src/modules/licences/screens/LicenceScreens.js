// Licences, permits & company records: list with reminders, each one with its copies, applications and history.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, MoneyField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import { actsAsOwner } from '../../../services/access.js';
import { dateStr } from '../../../services/core.js';
import * as L from '../service.js';

const STATE = {
  overdue: ['EXPIRED', C.danger], due: ['Renew soon', C.warn], renewing: ['Renewal in progress', C.info], ok: ['OK', C.success], none: ['No expiry', C.sub], cancelled: ['No longer held', C.sub],
};
const shopOpts = () => [{ value: '', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name })));
const userOpts = () => listUsers({ includeInactive: false }).filter((u) => u.uid && u.role !== 'staff' && u.role !== 'worker').map((u) => ({ value: u.uid, label: `${u.name} (${u.role})` }));
const when = (l) => (l.expiry_date ? (l.days < 0 ? `expired ${-l.days} day(s) ago (${l.expiry_date})` : `expires ${l.expiry_date} · ${l.days} day(s) left`) : 'does not expire');

export function LicencesScreen() {
  const { nav, user } = useApp();
  const edit = L.canEditLicences(user);
  const h = L.complianceHealth();
  const [filter, setFilter] = useRemembered('filter', 'all');
  const [shop, setShop] = useRemembered('shop', '');
  const [q, setQ] = useRemembered('q', '');
  const a = L.licenceAlerts();
  const list = L.listLicences({ filter, shopCode: shop || undefined, q });
  const byCat = Object.entries(L.CATEGORIES).map(([k, label]) => [label, list.filter((l) => l.category === k)]).filter(([, x]) => x.length);
  return (
    <Screen title="Licences & permits" subtitle="Copies, applications and renewal reminders">
      <Explain>Every licence, permit, certificate and company record in one place: the current copy, every application ever made (kept for reference), receipts and letters. Reminders start before anything expires – on the Home screen, as a phone notification and (if set up) in the Viber group.</Explain>
      <Stats items={[{ label: 'Expired', value: String(a.overdue.length), color: a.overdue.length ? C.danger : C.success }, { label: 'Renew soon', value: String(a.due.length), color: a.due.length ? C.warn : C.success }, { label: 'Renewing', value: String(a.renewing.length) }]} />
      {h.setUp ? <Banner testID="lic-health" tone={{ good: 'success', warn: 'warn', bad: 'danger' }[h.tone]} title={`Compliance health ${h.score} / 100`}
        message={h.problems.length ? h.problems.slice(0, 4).map((p) => `${p.name}${p.shop ? ` (${p.shop})` : ''}: ${p.text}`).join('\n') : 'Every licence is current, with its copy in the document safe.'} /> : null}
      {a.overdue.map((l) => <Banner key={l.uid} tone="danger" message={L.alertText(l)} />)}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {[{ code: 'ALL', name: 'Every shop' }].concat(listShops().filter((x) => x.active && /^S\d/.test(x.code))).map((x) => (
          <Btn key={x.code} testID={`lic-pack-${x.code}`} title={`Inspection pack – ${x.name}`} icon="🗂️" size="sm" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('ReportView', { kind: 'lic_inspection_pack', from: dateStr(), to: dateStr(), shop: x.code })} />
        ))}
      </View>
      {edit ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="lic-add" title="Add one" icon="➕" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceEdit', {})} />
          <Btn testID="lic-quick" title="Quick add the usual ones" icon="⚡" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceQuick', {})} />
        </View>
      ) : null}
      <Chips value={filter} onChange={setFilter} testIDPrefix="lic-f" options={[{ value: 'all', label: 'All' }, { value: 'attention', label: `Needs attention (${a.list.length})` }, { value: 'cancelled', label: 'No longer held' }]} />
      <Chips value={shop} onChange={setShop} options={[{ value: '', label: 'Every shop' }, { value: 'ALL', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code })))} />
      <Field label="Search" value={q} onChangeText={setQ} placeholder="name, number, authority" />
      {byCat.map(([label, items]) => (
        <Section key={label} title={label}>
          {items.map((l) => (
            <ListItem key={l.uid} testID={`lic-${l.uid}`} title={`${l.name}${l.shop_name ? ` – ${l.shop_name}` : ''}`} sub={`${l.licence_no ? `No. ${l.licence_no} · ` : ''}${when(l)} · ${l.docs} document(s)${l.noCopy && l.state !== 'none' ? ' · ⚠️ No current copy' : ''}${l.signoff_pending ? ' · waiting for owner sign-off' : ''}`}
              badge={STATE[l.state][0]} badgeColor={STATE[l.state][1]} onPress={() => nav.push('Licence', { uid: l.uid })} />
          ))}
        </Section>
      ))}
      {!list.length ? <Hint>Nothing here yet. Tap "Quick add the usual ones" to start with the common Fiji licences, then fill in the numbers and dates.</Hint> : null}
    </Screen>
  );
}

export function LicenceQuickScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [pick, setPick] = useState({});
  const [shops, setShops] = useState(listShops().filter((s) => s.active).map((s) => s.code));
  const add = () => {
    try {
      let n = 0;
      L.QUICK_ADD.forEach((t, i) => {
        if (!pick[i]) return;
        const targets = t.perShop ? shops : [''];
        targets.forEach((code) => {
          L.saveLicence(user, { name: t.name, category: t.category, authority: t.authority, renewMonths: t.renewMonths, remindDays: t.remindDays, shopCode: code });
          n += 1;
        });
      });
      ui.toast(`${n} added – now open each one to put in the number, the expiry date and the copy`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Quick add" subtitle="The usual licences for a Fiji shop" footer={<Btn testID="lq-add" title="Add the ticked ones" icon="➕" variant="success" onPress={add} />}>
      <Hint>Tick what the business holds. Those marked "each shop" are added once for every shop ticked below. Everything can be changed afterwards.</Hint>
      <Label>Shops</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {listShops().filter((s) => s.active).map((s) => (
          <Btn key={s.code} title={`${shops.includes(s.code) ? '☑' : '☐'} ${s.name}`} size="sm" variant={shops.includes(s.code) ? 'info' : 'secondary'}
            onPress={() => setShops(shops.includes(s.code) ? shops.filter((x) => x !== s.code) : shops.concat([s.code]))} />
        ))}
      </View>
      {L.QUICK_ADD.map((t, i) => (
        <ListItem key={i} testID={`lq-${i}`} title={`${pick[i] ? '☑' : '☐'} ${t.name}${t.perShop ? ' (each shop)' : ''}`} sub={`${t.authority || ''}${t.renewMonths ? ` · renew every ${t.renewMonths} months · reminder ${t.remindDays} days before` : ' · no expiry'}`}
          onPress={() => setPick({ ...pick, [i]: !pick[i] })} />
      ))}
    </Screen>
  );
}

export function LicenceEditScreen({ params }) {
  const { user, nav } = useApp();
  const act = useAct();
  const before = params.uid ? L.getLicence(params.uid) : null;
  const [f, setF] = useState(() => (before ? {
    uid: before.uid, name: before.name, category: before.category, authority: before.authority || '', licenceNo: before.licence_no || '', shopCode: before.shop_code || '', holder: before.holder || '',
    issuedDate: before.issued_date || '', expiryDate: before.expiry_date || '', renewMonths: before.renew_months === null ? '' : String(before.renew_months), remindDays: String(before.remind_days),
    fee: before.fee === null ? '' : String(before.fee), responsible: before.responsible || '', conditions: before.conditions || '', notes: before.notes || '',
    responsibleUid: before.responsible_uid || '', backupUid: before.backup_uid || '', conditionItems: L.conditionsFor(before),
  } : { name: '', category: 'trading', authority: '', licenceNo: '', shopCode: '', holder: 'Easy Buys Shopping Centre', issuedDate: '', expiryDate: '', renewMonths: '12', remindDays: '90', fee: '', responsible: '', conditions: '', notes: '', responsibleUid: '', backupUid: '', conditionItems: [] }));
  const setCond = (n, k, v) => setF((o) => ({ ...o, conditionItems: o.conditionItems.map((c, j) => (j === n ? { ...c, [k]: v } : c)) }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const save = () => { const uid = act(() => L.saveLicence(user, f), 'Saved'); if (uid) nav.replace('Licence', { uid }); };
  return (
    <Screen title={before ? `Change ${before.name}` : 'Add a licence / permit'} footer={<Btn testID="le-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Field testID="le-name" label="What is it?" value={f.name} onChangeText={set('name')} placeholder="e.g. Liquor licence" />
      <Label>Type</Label>
      <Choice value={f.category} onChange={set('category')} options={Object.entries(L.CATEGORIES).map(([value, label]) => ({ value, label }))} />
      <Select label="For" value={f.shopCode} onChange={set('shopCode')} options={shopOpts()} />
      <Field label="Issued by (authority)" value={f.authority} onChangeText={set('authority')} />
      <Field testID="le-no" label="Licence / permit / policy number" value={f.licenceNo} onChangeText={set('licenceNo')} />
      <Field label="In the name of (holder)" value={f.holder} onChangeText={set('holder')} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><DateField farDays={false} label="Issued" value={f.issuedDate} onChange={set('issuedDate')} /></View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><DateField farDays={false} testID="le-exp" label="Expires (blank = never)" value={f.expiryDate} onChange={set('expiryDate')} /></View>
      </View>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Renew every … months" value={f.renewMonths} onChangeText={set('renewMonths')} keyboardType="number-pad" /></View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="le-remind" label="Start reminding … days before" value={f.remindDays} onChangeText={set('remindDays')} keyboardType="number-pad" /></View>
      </View>
      <Hint>Liquor licences: the application is due up to 3 months before expiry – 90 days of reminders is a good start.</Hint>
      <MoneyField label="Fee" value={f.fee} onChange={set('fee')} />
      <Select testID="le-resp" label="Who looks after it (blank = the owner)" value={f.responsibleUid} onChange={set('responsibleUid')} options={[{ value: '', label: 'The owner' }].concat(userOpts())} />
      <Select testID="le-backup" label="Backup person" value={f.backupUid} onChange={set('backupUid')} options={[{ value: '', label: 'None' }].concat(userOpts())} />
      <Hint>They are reminded from 90 days before expiry; the owner from 30 days; it becomes urgent (with the alarm sound) from 7 days.</Hint>
      <Label>Conditions</Label>
      {f.conditionItems.map((c, n) => (
        <View key={c.id || n} style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <View style={{ flexBasis: 220, flexGrow: 3 }}><Field testID={`le-cond-${n}`} label={`Condition ${n + 1}`} value={c.text} onChangeText={(v) => setCond(n, 'text', v)} /></View>
          <Chips value={c.tick ? 'y' : 'n'} onChange={(v) => setCond(n, 'tick', v === 'y')} options={[{ value: 'n', label: 'No tick' }, { value: 'y', label: 'Tick box' }]} />
          <Btn title="✕" size="sm" variant="secondary" onPress={() => setF((o) => ({ ...o, conditionItems: o.conditionItems.filter((_, j) => j !== n) }))} />
        </View>
      ))}
      <Btn testID="le-cond-add" title="Add a condition (e.g. trading hours, licence displayed)" icon="➕" size="sm" variant="secondary" onPress={() => setF((o) => ({ ...o, conditionItems: o.conditionItems.concat([{ text: '', tick: true }]) }))} />
      <Field label="Other conditions (free text)" value={f.conditions} onChangeText={set('conditions')} multiline />
      <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
    </Screen>
  );
}

export function LicenceScreen({ params }) {
  const { user, nav, can, refresh } = useApp();
  const act = useAct();
  const [mode, setMode] = useState(null); // 'start' | 'finish' | 'note'
  const [r, setR] = useState({});
  const l = params.uid ? L.getLicence(params.uid) : null;
  if (!l) return <Screen title="Licence"><Banner tone="warn" message="Not found." /></Screen>;
  const days = L.daysLeft(l);
  const manage = L.canEditLicences(user);
  const people = L.peopleFor(l);
  const list = L.checklistFor(l);
  const conds = L.conditionsFor(l);
  const noCopy = !L.hasCurrentCopy(l) && l.state !== 'cancelled';
  const isOwner = !!user && (actsAsOwner(user) || user.role === 'owner' || user.realRole === 'owner');
  const go = (fn, msg) => { if (act(fn, msg)) { setMode(null); setR({}); refresh(); } };
  return (
    <Screen title={l.name} subtitle={`${l.shop_name || 'Whole business'}${l.licence_no ? ` · No. ${l.licence_no}` : ''}`}>
      <Banner testID="lic-state" tone={{ overdue: 'danger', due: 'warn', renewing: 'info', ok: 'success', none: 'info', cancelled: 'info' }[l.state]}
        title={STATE[l.state][0]} message={l.expiry_date ? (days < 0 ? `Expired on ${l.expiry_date}.` : `Expires on ${l.expiry_date} – ${days} day(s) left. Reminders start ${l.remind_days} days before.`) : 'Does not expire.'} />
      {noCopy ? <Banner testID="lic-nocopy" tone="warn" title="No current copy" message="Add a photo or PDF of the current licence below – it is kept on this tablet and on Google Drive, and nothing is ever deleted." /> : null}
      {l.signoff_pending ? (
        <Card tone="warn">
          <H>Renewal waiting for the owner's sign-off</H>
          <Text style={{ color: C.text }}>Check the new copy, the dates and the checklist, then sign it off.</Text>
          {isOwner ? <Btn testID="lic-signoff" title="Sign off this renewal" icon="✍️" size="md" variant="success" onPress={() => go(() => L.signOffRenewal(user, l.uid), 'Signed off')} /> : null}
        </Card>
      ) : null}
      <Card>
        <Row label="Looked after by" value={`${people.responsible ? people.responsible.name : '—'}${people.isDefault ? ' (owner)' : ''}`} />
        <Row label="Backup" value={people.backup ? people.backup.name : '—'} />
        <Row label="Issued by" value={l.authority || '—'} />
        <Row label="Holder" value={l.holder || '—'} />
        <Row label="Issued" value={l.issued_date || '—'} />
        <Row label="Renew every" value={l.renew_months ? `${l.renew_months} months` : '—'} />
        {l.fee !== null ? <Row label="Fee" value={`$${Number(l.fee).toFixed(2)}`} /> : null}
        {l.conditions ? <Text style={{ color: C.text, marginTop: 6 }}>Conditions: {l.conditions}</Text> : null}
        {l.notes ? <Text style={{ color: C.sub, marginTop: 6 }}>{l.notes}</Text> : null}
      </Card>
      {manage && l.state !== 'cancelled' ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          {l.status !== 'renewing' ? <Btn testID="lic-start" title="Renewal applied for" icon="📨" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => setMode('start')} /> : null}
          <Btn testID="lic-finish" title="Renewed – new expiry" icon="✅" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => setMode('finish')} />
          <Btn title="Add a note" icon="📝" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setMode('note')} />
          <Btn title="Change details" icon="✏️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('LicenceEdit', { uid: l.uid })} />
        </View>
      ) : null}
      {list ? (
        <Section title="Renewal checklist">
          {list.items.map((it, n) => (
            <ListItem key={n} testID={`lic-ck-${n}`} title={`${it.done_at ? '☑' : '☐'} ${it.text}`} sub={it.done_at ? `${it.by || ''} · ${it.done_at.slice(0, 16)}` : 'Tap when done'}
              onPress={() => go(() => L.tickChecklist(user, l.uid, n, !it.done_at), it.done_at ? 'Unticked' : 'Ticked')} />
          ))}
          <Hint>{`${list.items.filter((x) => x.done_at).length} of ${list.items.length} done.`}</Hint>
        </Section>
      ) : null}
      {conds.length ? (
        <Section title="Conditions">
          {conds.map((c) => (
            <ListItem key={c.id} testID={`lic-cond-${c.id}`} title={`${c.tick ? (c.ticked_at ? '☑ ' : '☐ ') : '• '}${c.text}`} sub={c.tick ? (c.ticked_at ? `Checked ${c.ticked_at.slice(0, 16)} by ${c.ticked_by || ''}` : 'Tap to tick when checked') : ''}
              onPress={c.tick ? () => go(() => L.tickCondition(user, l.uid, c.id, !c.ticked_at), 'Saved') : undefined} />
          ))}
        </Section>
      ) : null}
      {mode === 'start' ? (
        <Card>
          <H>Renewal application made</H>
          <Hint>Add the application form and receipt below as documents – they are kept for reference.</Hint>
          <DateField farDays={false} label="Date applied" value={r.date || dateStr()} onChange={(v) => setR({ ...r, date: v })} />
          <Field label="Reference / receipt number" value={r.refNo || ''} onChangeText={(v) => setR({ ...r, refNo: v })} />
          <MoneyField label="Fee paid" value={r.amount || ''} onChange={(v) => setR({ ...r, amount: v })} />
          <Field label="Note" value={r.note || ''} onChangeText={(v) => setR({ ...r, note: v })} />
          <Btn testID="lic-start-save" title="Save" variant="success" onPress={() => go(() => L.startRenewal(user, l.uid, r), 'Saved – reminders now say "renewal in progress"')} />
        </Card>
      ) : null}
      {mode === 'finish' ? (
        <Card>
          <H>Renewed</H>
          <DateField farDays={false} testID="lic-new-exp" label="New expiry date" value={r.newExpiry || ''} onChange={(v) => setR({ ...r, newExpiry: v })} />
          <Hint>{l.renew_months && l.expiry_date ? `Leave blank for ${l.renew_months} months after the old expiry.` : 'Enter the date on the new licence.'}</Hint>
          <DateField farDays={false} label="Issued on" value={r.issuedDate || dateStr()} onChange={(v) => setR({ ...r, issuedDate: v })} />
          <Field label="New number (if it changed)" value={r.licenceNo || ''} onChangeText={(v) => setR({ ...r, licenceNo: v })} />
          <MoneyField label="Fee" value={r.fee || ''} onChange={(v) => setR({ ...r, fee: v })} />
          <Btn testID="lic-finish-save" title="Save – then add the new copy below" variant="success" onPress={() => go(() => L.finishRenewal(user, l.uid, r), 'Renewed')} />
        </Card>
      ) : null}
      {mode === 'note' ? (
        <Card>
          <Select label="What happened" value={r.kind || 'note'} onChange={(v) => setR({ ...r, kind: v })} options={Object.entries(L.EVENT_KINDS).filter(([k]) => !['renewed', 'cancelled', 'reopened', 'signed', 'checklist', 'condition'].includes(k)).map(([value, label]) => ({ value, label }))} />
          <DateField label="Date" value={r.date || dateStr()} onChange={(v) => setR({ ...r, date: v })} />
          <Field label="Note" value={r.note || ''} onChangeText={(v) => setR({ ...r, note: v })} multiline />
          <Btn title="Save" variant="success" onPress={() => go(() => L.recordNote(user, l.uid, { kind: r.kind || 'note', date: r.date, note: r.note }), 'Saved')} />
        </Card>
      ) : null}
      <Section title="Documents">
        <DocumentsPanel refType="licence" refUid={l.uid} kinds={L.DOC_KINDS} canAdd={manage} testID="ld" defaultKind="licence_copy" />
      </Section>
      <Section title="History">
        {L.eventsFor(l.uid).map((e) => (
          <ListItem key={e.uid} title={`${L.EVENT_KINDS[e.kind] || e.kind} · ${e.event_date}`} sub={`${e.note || ''}${e.kind === 'renewed' ? (e.signed_at ? ` · signed off by ${e.signed_by}` : ' · not signed off yet') : ''}${e.ref_no ? ` · ref ${e.ref_no}` : ''}${e.amount !== null ? ` · $${Number(e.amount).toFixed(2)}` : ''} · ${e.by_name || ''}`} />
        ))}
        {!L.eventsFor(l.uid).length ? <Hint>Nothing recorded yet.</Hint> : null}
      </Section>
      {manage ? (l.state === 'cancelled'
        ? <Btn title="Put back in use" size="md" variant="secondary" onPress={() => go(() => L.reopenLicence(user, l.uid), 'Done')} />
        : <ReasonButton title="No longer held" prompt="Why? (e.g. shop closed)" confirm="Save" onDo={(w) => go(() => L.cancelLicence(user, l.uid, w), 'Saved')} />) : null}
    </Screen>
  );
}

// Settings: reminder steps (owner told from, urgent from) and the renewal checklist for each licence type.
export function LicenceSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [r, setR] = useState(() => { const x = L.licRules(); return { steps: x.steps.join(', '), ownerFromDays: String(x.ownerFromDays), urgentFromDays: String(x.urgentFromDays) }; });
  const [lists, setLists] = useState(() => Object.fromEntries(Object.entries(L.licenceChecklists()).map(([k, v]) => [k, v.join('\n')])));
  const [cat, setCat] = useState('liquor');
  const save = () => act(() => { L.saveLicRules(user, r); L.saveLicenceChecklists(user, lists); }, 'Saved');
  return (
    <Screen title="Licence settings" subtitle="Reminders and renewal checklists" footer={<Btn testID="ls-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Section title="Reminders">
        <Field testID="ls-steps" label="Remind on these days before expiry" value={r.steps} onChangeText={(v) => setR({ ...r, steps: v })} placeholder="90, 60, 30, 14, 7, 1" />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Owner told from … days" value={r.ownerFromDays} onChangeText={(v) => setR({ ...r, ownerFromDays: v })} keyboardType="number-pad" /></View>
          <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="Urgent (alarm sound) from … days" value={r.urgentFromDays} onChangeText={(v) => setR({ ...r, urgentFromDays: v })} keyboardType="number-pad" /></View>
        </View>
        <Hint>Expired licences are shown every day to every manager and the owner.</Hint>
      </Section>
      <Section title="Renewal checklist per licence type">
        <Choice value={cat} onChange={setCat} testIDPrefix="ls-cat" options={Object.entries(L.CATEGORIES).map(([value, label]) => ({ value, label }))} />
        <Field testID="ls-list" label="Steps (one per line)" value={lists[cat] || ''} onChangeText={(v) => setLists({ ...lists, [cat]: v })} multiline />
      </Section>
    </Screen>
  );
}
