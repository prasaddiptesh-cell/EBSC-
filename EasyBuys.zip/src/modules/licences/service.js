// Licences, permits and company records: what the business holds, when each expires, the copies, and every
// application kept for reference. Reminders start before anything is due for renewal.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getSetting, setSetting, getShared, setShared } from '../../services/core.js';
import { listDocuments } from '../../services/documents.js';
import { needReason, actsAsOwner } from '../../services/access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

// Only the owner and the admin add or change licences (everyone else with access can look, and tick conditions).
export function canEditLicences(user) {
  return !!user && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
}
const mustEdit = (user) => need(!user || canEditLicences(user), 'Only the owner or admin can add or change licences.');

export const LIC_SQL = `
CREATE TABLE IF NOT EXISTS licences (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  authority TEXT,
  licence_no TEXT,
  shop_code TEXT,
  holder TEXT,
  issued_date TEXT,
  expiry_date TEXT,
  renew_months INTEGER,
  remind_days INTEGER NOT NULL DEFAULT 60,
  fee REAL,
  status TEXT NOT NULL DEFAULT 'active',
  responsible TEXT,
  conditions TEXT,
  notes TEXT,
  created_by TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS licence_events (
  uid TEXT PRIMARY KEY,
  licence_uid TEXT NOT NULL,
  kind TEXT NOT NULL,
  event_date TEXT NOT NULL,
  note TEXT,
  amount REAL,
  ref_no TEXT,
  old_expiry TEXT,
  new_expiry TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_lic_events ON licence_events(licence_uid, event_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const LIC_SYNC = {
  licences: SYNC('uid', 'Licences', ['uid', 'name', 'category', 'authority', 'licence_no', 'shop_code', 'holder', 'issued_date', 'expiry_date', 'renew_months', 'remind_days', 'fee', 'status', 'responsible', 'conditions', 'notes', 'created_by', 'created_at',
    'responsible_uid', 'backup_uid', 'condition_items', 'checklist', 'signoff_pending']),
  licence_events: SYNC('uid', 'Licences', ['uid', 'licence_uid', 'kind', 'event_date', 'note', 'amount', 'ref_no', 'old_expiry', 'new_expiry', 'by_name', 'created_at', 'signed_by', 'signed_at']),
};
// v3.5 B7 (added by src/db/columns.js): responsible person + backup, conditions with optional ticks, the renewal
// checklist in progress, and the owner's sign-off of each renewal.
export const LIC35_COLUMNS = {
  licences: [['responsible_uid', 'TEXT'], ['backup_uid', 'TEXT'], ['condition_items', 'TEXT'], ['checklist', 'TEXT'], ['signoff_pending', 'INTEGER']],
  licence_events: [['signed_by', 'TEXT'], ['signed_at', 'TEXT']],
};

export const CATEGORIES = {
  liquor: 'Liquor & spirit licences', trading: 'Business / trading licences', health: 'Health & food', fire: 'Fire & safety', company: 'Company records',
  tax: 'Tax & FRCS', vehicle: 'Vehicles', staff: 'Staff certificates', insurance: 'Insurance', premises: 'Premises & leases', other: 'Other',
};
// Quick add: the usual ones for a Fiji shop (all can be changed).
export const QUICK_ADD = [
  { name: 'Liquor licence', category: 'liquor', authority: 'Liquor Licensing Board (Ministry of Justice)', renewMonths: 12, remindDays: 90, perShop: true },
  { name: 'Spirit licence', category: 'liquor', authority: 'Liquor Licensing Board (Ministry of Justice)', renewMonths: 12, remindDays: 90, perShop: true },
  { name: 'Business licence', category: 'trading', authority: 'Lautoka City Council', renewMonths: 12, remindDays: 45, perShop: true },
  { name: 'Health licence (food premises)', category: 'health', authority: 'Lautoka City Council – Health', renewMonths: 12, remindDays: 60, perShop: true },
  { name: 'Fire safety certificate', category: 'fire', authority: 'National Fire Authority', renewMonths: 12, remindDays: 60, perShop: true },
  { name: 'Scales verification (weights & measures)', category: 'trading', authority: 'Dept. of National Trade Measurement & Standards', renewMonths: 12, remindDays: 30, perShop: true },
  { name: 'Company annual return', category: 'company', authority: 'Registrar of Companies', renewMonths: 12, remindDays: 30 },
  { name: 'VAT registration', category: 'tax', authority: 'FRCS', renewMonths: null, remindDays: 0 },
  { name: 'POS / VMS accreditation', category: 'tax', authority: 'FRCS', renewMonths: null, remindDays: 60 },
  { name: 'Vehicle registration', category: 'vehicle', authority: 'Land Transport Authority', renewMonths: 12, remindDays: 30 },
  { name: 'Vehicle insurance', category: 'insurance', authority: '', renewMonths: 12, remindDays: 30 },
  { name: 'Shop insurance (fire / burglary)', category: 'insurance', authority: '', renewMonths: 12, remindDays: 45 },
  { name: 'Food handler certificate', category: 'staff', authority: 'Health inspector / approved trainer', renewMonths: 12, remindDays: 30 },
  { name: 'Lease agreement', category: 'premises', authority: 'Landlord', renewMonths: null, remindDays: 120 },
];
export const DOC_KINDS = { licence_copy: 'Licence / permit copy', application: 'Application', receipt: 'Payment receipt', letter: 'Letter / correspondence', inspection: 'Inspection report', other: 'Other' };
export const EVENT_KINDS = { applied: 'Application made', paid: 'Fee paid', inspection: 'Inspection', issued: 'Issued', renewed: 'Renewed', note: 'Note', cancelled: 'Cancelled', reopened: 'Put back in use', signed: 'Signed off by the owner', checklist: 'Checklist', condition: 'Condition checked' };

// Saved in one go: a wrong responsible / backup person leaves nothing half-saved.
export function saveLicence(user, l) {
  mustEdit(user);
  return db().transaction(() => saveLicenceNow(user, l));
}
function saveLicenceNow(user, l) {
  need(txt(l.name), 'Enter what it is, e.g. "Liquor licence".');
  need(CATEGORIES[l.category], 'Choose the type.');
  for (const [k, label] of [['issuedDate', 'Issued'], ['expiryDate', 'Expires']]) need(!txt(l[k]) || DATE.test(txt(l[k])), `${label}: enter the date as YYYY-MM-DD.`);
  const remind = Math.max(0, Math.min(365, Math.round(Number(l.remindDays ?? 60))));
  const renew = txt(l.renewMonths) === '' || l.renewMonths === null ? null : Math.max(1, Math.round(Number(l.renewMonths) || 12));
  const now = stamp(); const dev = deviceId();
  const vals = [txt(l.name), l.category, txt(l.authority) || null, txt(l.licenceNo) || null, txt(l.shopCode) || null, txt(l.holder) || null, txt(l.issuedDate) || null, txt(l.expiryDate) || null,
    renew, remind, txt(l.fee) === '' ? null : Number(l.fee), txt(l.responsible) || null, txt(l.conditions) || null, txt(l.notes) || null];
  if (l.uid) {
    const before = getLicence(l.uid);
    need(before, 'Not found.');
    db().run(`UPDATE licences SET name=?, category=?, authority=?, licence_no=?, shop_code=?, holder=?, issued_date=?, expiry_date=?, renew_months=?, remind_days=?, fee=?, responsible=?, conditions=?, notes=?, ${SYNCED} WHERE uid = ?`, [...vals, now, dev, l.uid]);
    if (before.expiry_date !== (txt(l.expiryDate) || null)) addEvent(user, l.uid, { kind: 'note', note: `Expiry date changed from ${before.expiry_date || 'none'} to ${txt(l.expiryDate) || 'none'}`, oldExpiry: before.expiry_date, newExpiry: txt(l.expiryDate) || null });
    savePeople(l.uid, l, before);
    audit({ user, action: `Changed ${txt(l.name)}`, table: 'licences', recordUid: l.uid, before });
    return l.uid;
  }
  const uid = uuid('LIC');
  db().run(`INSERT INTO licences (name, category, authority, licence_no, shop_code, holder, issued_date, expiry_date, renew_months, remind_days, fee, responsible, conditions, notes, uid, status, created_by, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?,?)`, [...vals, uid, user ? user.name : 'System', now, now, dev]);
  savePeople(uid, l, null);
  audit({ user, action: `Added ${txt(l.name)}`, table: 'licences', recordUid: uid });
  return uid;
}
// Responsible person + backup (the owner when nobody is chosen) and the conditions list (each with an optional tick).
function savePeople(uid, l, before) {
  const users = Object.fromEntries(db().all('SELECT uid, name FROM users').map((u) => [u.uid, u.name]));
  const resp = l.responsibleUid === undefined ? (before ? before.responsible_uid : null) : (txt(l.responsibleUid) || null);
  const backup = l.backupUid === undefined ? (before ? before.backup_uid : null) : (txt(l.backupUid) || null);
  need(!resp || users[resp], 'Choose the responsible person from the list.');
  need(!backup || users[backup], 'Choose the backup person from the list.');
  need(!resp || resp !== backup, 'The backup must be someone else.');
  let items = before ? J(before.condition_items, []) : [];
  if (Array.isArray(l.conditionItems)) {
    const old = Object.fromEntries(items.map((c) => [c.id, c]));
    items = l.conditionItems.filter((c) => txt(c.text)).map((c) => {
      const id = txt(c.id) || uuid('LC');
      const o = old[id] || {};
      return { id, text: txt(c.text), tick: !!c.tick, ticked_at: c.tick ? o.ticked_at || null : null, ticked_by: c.tick ? o.ticked_by || null : null };
    });
  }
  db().run(`UPDATE licences SET responsible_uid = ?, backup_uid = ?, responsible = COALESCE(?, responsible), condition_items = ? WHERE uid = ?`,
    [resp, backup, resp ? users[resp] : null, items.length ? JSON.stringify(items) : null, uid]);
}
export function getLicence(uid) {
  const l = db().get('SELECT l.*, s.name AS shop_name FROM licences l LEFT JOIN shops s ON s.code = l.shop_code WHERE l.uid = ?', [uid]);
  return l ? { ...l, state: stateOf(l) } : null;
}
export function eventsFor(uid) { return db().all('SELECT * FROM licence_events WHERE licence_uid = ? ORDER BY event_date DESC, created_at DESC', [uid]); }
export function addEvent(user, licenceUid, { kind, date, note, amount, refNo, oldExpiry, newExpiry }) {
  need(EVENT_KINDS[kind], 'Choose what happened.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date as YYYY-MM-DD.');
  const uid = uuid('LE'); const now = stamp();
  db().run(`INSERT INTO licence_events (uid, licence_uid, kind, event_date, note, amount, ref_no, old_expiry, new_expiry, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, licenceUid, kind, d, txt(note) || null, txt(amount) === '' || amount === undefined ? null : Number(amount), txt(refNo) || null, oldExpiry || null, newExpiry || null, user ? user.name : 'System', now, now, deviceId()]);
  return uid;
}

// 'none' (does not expire) | 'ok' | 'due' (inside the reminder time) | 'overdue' (expired) | 'renewing' | 'cancelled'
export function stateOf(l, today = dateStr()) {
  if (l.status === 'cancelled') return 'cancelled';
  if (!l.expiry_date) return l.status === 'renewing' ? 'renewing' : 'none';
  if (l.expiry_date < today) return 'overdue';
  if (l.status === 'renewing') return 'renewing';
  if (l.expiry_date <= addDays(today, Number(l.remind_days) || 0)) return 'due';
  return 'ok';
}
export function daysLeft(l, today = dateStr()) {
  if (!l.expiry_date) return null;
  const a = new Date(`${today}T00:00:00`); const b = new Date(`${l.expiry_date}T00:00:00`);
  return Math.round((b - a) / 86400000);
}
export function listLicences({ shopCode, category, filter = 'all', q, today = dateStr() } = {}) {
  return db().all('SELECT l.*, s.name AS shop_name FROM licences l LEFT JOIN shops s ON s.code = l.shop_code ORDER BY (l.expiry_date IS NULL), l.expiry_date, l.name')
    .map((l) => ({ ...l, state: stateOf(l, today), days: daysLeft(l, today), docs: docCount(l.uid), noCopy: l.status !== 'cancelled' && !hasCurrentCopy(l) }))
    .filter((l) => (!shopCode || l.shop_code === shopCode || (shopCode === 'ALL' && !l.shop_code)) && (!category || l.category === category)
      && (filter === 'all' ? l.state !== 'cancelled' : filter === 'attention' ? ['due', 'overdue', 'renewing'].includes(l.state) : filter === 'cancelled' ? l.state === 'cancelled' : true)
      && (!txt(q) || `${l.name} ${l.licence_no || ''} ${l.authority || ''} ${l.shop_name || ''}`.toLowerCase().includes(txt(q).toLowerCase())));
}
function docCount(uid) { try { return db().get("SELECT COUNT(*) AS n FROM documents WHERE ref_type = 'licence' AND ref_uid = ? AND status = 'active'", [uid]).n; } catch (e) { return 0; } }
export function licenceDocuments(uid) { return listDocuments('licence', uid); }

// Renewal: started (application made) → finished (new expiry date, new copy uploaded). Everything is kept.
export function startRenewal(user, uid, { date, note, amount, refNo } = {}) {
  mustEdit(user);
  const l = getLicence(uid);
  need(l && l.status !== 'cancelled', 'Not found.');
  // A fresh renewal checklist for this licence type (kept on the licence until the renewal is signed off).
  const list = { started: txt(date) || dateStr(), items: checklistTemplate(l.category).map((text) => ({ text, done_at: null, by: null })) };
  db().run(`UPDATE licences SET status = 'renewing', checklist = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'applied', date, note: txt(note) || 'Renewal application made', amount, refNo });
  audit({ user, action: `Renewal started: ${l.name}`, table: 'licences', recordUid: uid });
}
export function finishRenewal(user, uid, { newExpiry, issuedDate, licenceNo, fee, refNo, note } = {}) {
  mustEdit(user);
  const l = getLicence(uid);
  need(l && l.status !== 'cancelled', 'Not found.');
  const expiry = txt(newExpiry) || (l.expiry_date && l.renew_months ? addMonths(l.expiry_date, l.renew_months) : '');
  need(DATE.test(expiry), 'Enter the new expiry date (YYYY-MM-DD).');
  need(!l.expiry_date || expiry > l.expiry_date, 'The new expiry date must be after the old one.');
  const issued = txt(issuedDate) || dateStr();
  need(DATE.test(issued), 'Issued: enter the date as YYYY-MM-DD.');
  // Every renewal waits for the owner's sign-off (the owner checks the new copy, the checklist and the dates).
  db().run(`UPDATE licences SET status = 'active', expiry_date = ?, issued_date = ?, licence_no = COALESCE(?, licence_no), fee = COALESCE(?, fee), signoff_pending = 1, ${SYNCED} WHERE uid = ?`,
    [expiry, issued, txt(licenceNo) || null, txt(fee) === '' || fee === undefined ? null : Number(fee), stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'renewed', date: issued, note: txt(note) || `Renewed until ${expiry}`, amount: fee, refNo, oldExpiry: l.expiry_date, newExpiry: expiry });
  audit({ user, action: `Renewed: ${l.name} until ${expiry}`, table: 'licences', recordUid: uid });
  return expiry;
}
// The owner signs off the renewal: the latest "renewed" entry gets the owner's name and time.
export function signOffRenewal(user, uid, note) {
  need(user && (actsAsOwner(user) || user.role === 'owner' || user.realRole === 'owner'), 'Only the owner signs off a renewal.');
  const l = getLicence(uid);
  need(l, 'Not found.');
  need(l.signoff_pending, 'Nothing is waiting for sign-off.');
  const ev = db().get("SELECT uid FROM licence_events WHERE licence_uid = ? AND kind = 'renewed' ORDER BY event_date DESC, created_at DESC LIMIT 1", [uid]);
  const now = stamp();
  db().transaction(() => {
    if (ev) db().run(`UPDATE licence_events SET signed_by = ?, signed_at = ?, ${SYNCED} WHERE uid = ?`, [user.name, now, now, deviceId(), ev.uid]);
    db().run(`UPDATE licences SET signoff_pending = 0, ${SYNCED} WHERE uid = ?`, [now, deviceId(), uid]);
    addEvent(user, uid, { kind: 'signed', note: txt(note) || `Renewal signed off by ${user.name}` });
  });
  audit({ user, action: `Renewal signed off: ${l.name}`, table: 'licences', recordUid: uid });
}
export function cancelLicence(user, uid, reason) {
  mustEdit(user);
  const l = getLicence(uid);
  need(l, 'Not found.');
  needReason(user, reason, 'Say why (e.g. "shop closed", "replaced by new licence").');
  db().run(`UPDATE licences SET status = 'cancelled', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'cancelled', note: txt(reason) });
  audit({ user, action: `No longer held: ${l.name}`, table: 'licences', recordUid: uid, reason: txt(reason) });
}
export function reopenLicence(user, uid) {
  mustEdit(user);
  db().run(`UPDATE licences SET status = 'active', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'reopened', note: 'Put back in use' });
}
function addMonths(d, n) {
  const [y, m, day] = d.split('-').map(Number);
  const t = new Date(y, m - 1 + Number(n), 1);
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(Math.min(day, last)).padStart(2, '0')}`;
}

// What needs attention now (Home banner, reminders).
export function licenceAlerts(today = dateStr()) {
  const list = listLicences({ filter: 'attention', today });
  return { overdue: list.filter((l) => l.state === 'overdue'), due: list.filter((l) => l.state === 'due'), renewing: list.filter((l) => l.state === 'renewing'), list };
}
export const alertText = (l) => (l.state === 'overdue' ? `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''} EXPIRED on ${l.expiry_date}`
  : `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''} expires on ${l.expiry_date} – ${l.days} day${l.days === 1 ? '' : 's'} left${l.state === 'renewing' ? ' (renewal in progress)' : ''}`);

// ================================================================ v3.5 B7: licences as the business's safeguard
// Escalating reminders: the responsible person and the backup from the first step (90 days), the owner from 30 days,
// an urgent (sounding) warning from 7 days, and once expired it is shown every day to every manager and the owner.
export const LIC_RULE_DEFAULTS = { steps: [90, 60, 30, 14, 7, 1], ownerFromDays: 30, urgentFromDays: 7 };
export function licRules() {
  const r = { ...LIC_RULE_DEFAULTS, ...(getShared('lic_rules', {}) || {}) };
  return { ...r, steps: (Array.isArray(r.steps) ? r.steps : LIC_RULE_DEFAULTS.steps).map(Number).filter((n) => n > 0).sort((a, b) => b - a) };
}
export function saveLicRules(user, r) {
  mustEdit(user);
  const c = { ...licRules(), ...r };
  const steps = (Array.isArray(c.steps) ? c.steps : String(c.steps || '').split(/[ ,/]+/)).map((x) => Math.round(Number(x))).filter((n) => Number.isFinite(n) && n > 0 && n <= 365);
  need(steps.length, 'Enter at least one reminder day, e.g. 90, 60, 30, 14, 7, 1.');
  const int = (v, label) => { const n = Math.round(Number(v)); need(Number.isFinite(n) && n >= 0 && n <= 365, `${label}: 0 to 365 days.`); return n; };
  const clean = { steps: Array.from(new Set(steps)).sort((a, b) => b - a), ownerFromDays: int(c.ownerFromDays, 'Owner told from'), urgentFromDays: int(c.urgentFromDays, 'Urgent from') };
  const before = licRules();
  setShared('lic_rules', clean);
  audit({ user, action: 'Changed the licence reminder rules', table: 'shared_settings', recordUid: 'lic_rules', before, after: clean });
  return clean;
}
// The reminder step a licence is at: null (not yet), a number of days (the step reached) or 'expired'.
export function reminderStep(l, today = dateStr(), rules = licRules()) {
  if (!l.expiry_date || l.status === 'cancelled') return null;
  const d = daysLeft(l, today);
  if (d < 0) return 'expired';
  const first = Math.max(rules.steps[0] || 0, Number(l.remind_days) || 0);
  if (d > first) return null;
  const reached = rules.steps.filter((s) => d <= s);
  return reached.length ? reached[reached.length - 1] : first;
}
export function ownerUser() {
  return db().get("SELECT uid, name, role FROM users WHERE role = 'owner' AND active = 1 ORDER BY id LIMIT 1")
    || db().get("SELECT uid, name, role FROM users WHERE role = 'admin' AND active = 1 ORDER BY id LIMIT 1") || null;
}
// Who looks after it: the chosen person, else the owner. The backup is told at the same time.
export function peopleFor(l) {
  const by = (uid) => (uid ? db().get('SELECT uid, name, role, active FROM users WHERE uid = ?', [uid]) : null);
  const resp = by(l.responsible_uid);
  const o = ownerUser();
  return { responsible: resp && resp.active ? resp : o, backup: by(l.backup_uid), owner: o, isDefault: !(resp && resp.active) };
}
const isManagerish = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin', 'manager'].includes(u.role));
const isOwnerish = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.realRole === 'owner');
// The warnings this person gets about licences (Home, sounds): escalating by the step reached.
export function licenceAlertsFor(user, today = dateStr()) {
  if (!user) return [];
  const rules = licRules();
  const out = [];
  for (const l of listLicences({ today })) {
    const step = reminderStep(l, today, rules);
    const p = peopleFor(l);
    const mine = !!user.uid && ((p.responsible && p.responsible.uid === user.uid) || (p.backup && p.backup.uid === user.uid));
    const where = `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''}`;
    if (step === 'expired') {
      if (mine || isManagerish(user) || isOwnerish(user)) {
        out.push({ id: `lic-${l.uid}-expired-${today}`, level: 'urgent', text: `${where} EXPIRED on ${l.expiry_date}${l.state === 'renewing' ? ' – renewal in progress' : ''}`,
          sub: `Looked after by ${p.responsible ? p.responsible.name : 'nobody'}. Trading without it can mean a fine or closure.`, nav: { screen: 'Licence', params: { uid: l.uid } } });
      }
    } else if (step !== null) {
      const d = l.days;
      const ownerToo = d <= rules.ownerFromDays;
      if (mine || (ownerToo && isOwnerish(user))) {
        out.push({ id: `lic-${l.uid}-${step}`, level: d <= rules.urgentFromDays ? 'urgent' : d <= rules.ownerFromDays ? 'warning' : 'info',
          text: `${where} expires on ${l.expiry_date} – ${d} day${d === 1 ? '' : 's'} left${l.state === 'renewing' ? ' (renewal in progress)' : ''}`,
          sub: mine ? 'You look after this one. Start the renewal checklist.' : `Looked after by ${p.responsible ? p.responsible.name : 'nobody'}.`, nav: { screen: 'Licence', params: { uid: l.uid } } });
      }
    }
    if (l.signoff_pending && isOwnerish(user)) out.push({ id: `lic-${l.uid}-signoff`, level: 'warning', text: `${where} was renewed – please check and sign it off`, nav: { screen: 'Licence', params: { uid: l.uid } } });
    if (l.noCopy && l.state !== 'none' && (mine || isOwnerish(user))) out.push({ id: `lic-${l.uid}-nocopy`, level: 'info', text: `${where}: no current copy in the document safe`, sub: 'Take a photo or add the PDF of the current licence.', nav: { screen: 'Licence', params: { uid: l.uid } } });
  }
  return out;
}

// Once a day: a Viber alert on each reminder step (90, 60, 30, 14, 7, 1 days and the expiry day), and every day once expired.
export function dailyLicenceCheck(notifyFn, today = dateStr()) {
  if (getSetting('licence_check_day', '') === today) return [];
  setSetting('licence_check_day', today);
  const rules = licRules();
  const sent = [];
  for (const l of licenceAlerts(today).list) {
    const d = l.days;
    const hit = d < 0 || d === 0 || rules.steps.includes(d) || d === Number(l.remind_days);
    if (!hit) continue;
    const p = peopleFor(l);
    const text = `${alertText(l)}${p.responsible ? ` – looked after by ${p.responsible.name}${p.backup ? ` (backup ${p.backup.name})` : ''}` : ''}`;
    try { if (notifyFn) notifyFn('licence_due', text, { shopCode: l.shop_code }); } catch (e) { /* alerts never stop the app */ }
    sent.push(text);
  }
  return sent;
}

// ---------------------------------------------------------------- renewal checklist per licence type (admin can change)
export const CHECKLIST_DEFAULTS = {
  liquor: ['Application form filled in (Liquor Licensing Board)', 'Police report / character reference for the licensee', 'Health certificate current', 'Fire safety certificate current', 'Business licence copy attached', 'Fee paid – receipt kept', 'Lodged with the Board (reference noted)', 'New licence displayed in the shop'],
  trading: ['Application form filled in', 'Health and fire certificates current', 'Fee paid – receipt kept', 'New licence displayed in the shop'],
  health: ['Inspection booked', 'Anything the inspector asked for fixed', 'Fee paid – receipt kept', 'Certificate displayed'],
  fire: ['Inspection booked with the National Fire Authority', 'Extinguishers serviced and tagged', 'Exits and signs checked', 'Fee paid – receipt kept', 'Certificate displayed'],
  company: ['Annual return filled in', 'Fee paid – receipt kept', 'Lodged with the Registrar of Companies'],
  tax: ['Details checked with FRCS', 'Confirmation kept'],
  vehicle: ['Vehicle inspected (LTA)', 'Insurance current', 'Fee paid – receipt kept', 'Registration label on the windscreen'],
  insurance: ['Cover and sums insured checked', 'Quotes compared', 'Premium paid – receipt kept', 'Policy schedule kept'],
  staff: ['Training booked', 'Certificate copy kept'],
  premises: ['Lease terms checked', 'Renewal agreed with the landlord', 'Signed lease copy kept'],
  other: ['Application made', 'Fee paid – receipt kept', 'Copy kept'],
};
export function licenceChecklists() {
  const saved = getShared('lic_checklists', {}) || {};
  const out = {};
  for (const k of Object.keys(CATEGORIES)) out[k] = Array.isArray(saved[k]) ? saved[k] : (CHECKLIST_DEFAULTS[k] || CHECKLIST_DEFAULTS.other);
  return out;
}
export function checklistTemplate(category) { return licenceChecklists()[category] || CHECKLIST_DEFAULTS.other; }
export function saveLicenceChecklists(user, map) {
  mustEdit(user);
  const clean = {};
  for (const k of Object.keys(CATEGORIES)) {
    const v = (map || {})[k];
    if (v === undefined) continue;
    clean[k] = (Array.isArray(v) ? v : String(v).split('\n')).map(txt).filter(Boolean);
  }
  const before = getShared('lic_checklists', {}) || {};
  const after = { ...before, ...clean };
  setShared('lic_checklists', after);
  audit({ user, action: 'Changed the licence renewal checklists', table: 'shared_settings', recordUid: 'lic_checklists', before, after });
  return licenceChecklists();
}
export function checklistFor(l) {
  const c = J(l.checklist, null);
  return c && Array.isArray(c.items) ? c : null;
}
// Tick (or untick) a checklist step of the renewal in progress. Owner / admin, or the person who looks after it.
export function tickChecklist(user, uid, index, done = true) {
  const l = getLicence(uid);
  need(l, 'Not found.');
  const p = peopleFor(l);
  need(canEditLicences(user) || (p.responsible && p.responsible.uid === user.uid) || (p.backup && p.backup.uid === user.uid), 'Only the owner, the admin or the person looking after it can tick the checklist.');
  const c = checklistFor(l);
  need(c && c.items[index], 'Start the renewal first ("Renewal applied for").');
  c.items[index] = { ...c.items[index], done_at: done ? stamp() : null, by: done ? user.name : null };
  db().run(`UPDATE licences SET checklist = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(c), stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'checklist', note: `${done ? '☑' : '☐'} ${c.items[index].text}` });
  return c;
}

// ---------------------------------------------------------------- conditions (each with an optional tick)
export function conditionsFor(l) { return J(l.condition_items, []); }
// Anyone who can see licences may tick a condition as checked (e.g. "Licence displayed at the entrance").
export function tickCondition(user, uid, condId, on = true) {
  const l = getLicence(uid);
  need(l, 'Not found.');
  const items = conditionsFor(l);
  const c = items.find((x) => x.id === condId);
  need(c, 'Condition not found.');
  need(c.tick, 'This condition has no tick box.');
  c.ticked_at = on ? stamp() : null;
  c.ticked_by = on ? (user ? user.name : 'System') : null;
  db().run(`UPDATE licences SET condition_items = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(items), stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'condition', note: `${on ? '☑' : '☐'} ${c.text}` });
  return items;
}
// A note / inspection / fee paid added by the owner or admin.
export function recordNote(user, uid, ev) {
  mustEdit(user);
  return addEvent(user, uid, ev);
}

// ---------------------------------------------------------------- document safe
// The current copy: a licence copy added on or after the date the licence was (last) issued. Nothing is ever deleted;
// older copies stay as history. Copies are kept on the device that added them and on Google Drive.
export function hasCurrentCopy(l) {
  try {
    const since = l.issued_date || '0000-01-01';
    return !!db().get("SELECT 1 AS x FROM documents WHERE ref_type = 'licence' AND ref_uid = ? AND status = 'active' AND kind = 'licence_copy' AND COALESCE(doc_date, substr(added_at,1,10)) >= ? LIMIT 1", [l.uid, since]);
  } catch (e) { return false; }
}

// ---------------------------------------------------------------- compliance health (dashboard card, monthly report)
// A score out of 100 with the reasons: expired −25 each, 7 days or less −10, 30 days or less −5, no current copy −5,
// renewal waiting for the owner's sign-off −3, a tick-box condition never checked −2.
export function complianceHealth(today = dateStr()) {
  const list = listLicences({ today });
  const problems = [];
  let score = 100;
  const add = (pts, l, text, tone) => { score -= pts; problems.push({ uid: l.uid, name: l.name, shop: l.shop_name || 'Whole business', text, tone, pts }); };
  const counts = { total: list.length, ok: 0, due: 0, expired: 0, renewing: 0, noCopy: 0, unsigned: 0, conditionsOpen: 0 };
  for (const l of list) {
    if (l.state === 'overdue') { counts.expired += 1; add(25, l, `expired ${l.expiry_date}`, 'bad'); } else if (l.days !== null && l.days <= 7) { counts.due += 1; add(10, l, `${l.days} day(s) left`, 'bad'); } else if (l.days !== null && l.days <= 30) { counts.due += 1; add(5, l, `${l.days} days left`, 'warn'); } else if (l.state === 'due') counts.due += 1;
    else counts.ok += 1;
    if (l.state === 'renewing') counts.renewing += 1;
    if (l.noCopy && l.state !== 'none') { counts.noCopy += 1; add(5, l, 'no current copy', 'warn'); }
    if (l.signoff_pending) { counts.unsigned += 1; add(3, l, 'renewal not signed off', 'warn'); }
    const open = conditionsFor(l).filter((c) => c.tick && !c.ticked_at).length;
    if (open) { counts.conditionsOpen += open; add(2 * open, l, `${open} condition(s) not checked`, 'warn'); }
  }
  score = Math.max(0, Math.min(100, score));
  const tone = !list.length ? 'warn' : counts.expired || score < 60 ? 'bad' : score < 90 ? 'warn' : 'good';
  return { score, tone, counts, problems: problems.sort((a, b) => b.pts - a.pts), setUp: list.length > 0 };
}

// ---------------------------------------------------------------- inspection pack (what an inspector asks for, per shop)
export function inspectionPack(shopCode, today = dateStr()) {
  const list = listLicences({ today }).filter((l) => !shopCode || shopCode === 'ALL' || l.shop_code === shopCode || !l.shop_code);
  return list.map((l) => {
    const docs = licenceDocuments(l.uid).filter((d) => d.kind === 'licence_copy');
    const p = peopleFor(l);
    return { ...l, people: p, condItems: conditionsFor(l), copies: docs, current: hasCurrentCopy(l) };
  });
}
