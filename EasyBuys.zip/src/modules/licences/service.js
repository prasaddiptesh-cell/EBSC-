// Licences, permits and company records: what the business holds, when each expires, the copies, and every
// application kept for reference. Reminders start before anything is due for renewal.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getSetting, setSetting } from '../../services/core.js';
import { listDocuments } from '../../services/documents.js';
import { needReason } from '../../services/access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";

export const LIC_SQL = `
CREATE TABLE IF NOT EXISTS licences (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  authority TEXT,
  licence_no TEXT,
  shop_code TEXT,
  holder TEXT,
  issued_date TEXT,
  expiry_date TEXT,
  renew_months INTEGER,
  remind_days INTEGER NOT NULL DEFAULT 60,
  fee REAL,
  status TEXT NOT NULL DEFAULT 'active',
  responsible TEXT,
  conditions TEXT,
  notes TEXT,
  created_by TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS licence_events (
  uid TEXT PRIMARY KEY,
  licence_uid TEXT NOT NULL,
  kind TEXT NOT NULL,
  event_date TEXT NOT NULL,
  note TEXT,
  amount REAL,
  ref_no TEXT,
  old_expiry TEXT,
  new_expiry TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_lic_events ON licence_events(licence_uid, event_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const LIC_SYNC = {
  licences: SYNC('uid', 'Licences', ['uid', 'name', 'category', 'authority', 'licence_no', 'shop_code', 'holder', 'issued_date', 'expiry_date', 'renew_months', 'remind_days', 'fee', 'status', 'responsible', 'conditions', 'notes', 'created_by', 'created_at']),
  licence_events: SYNC('uid', 'Licences', ['uid', 'licence_uid', 'kind', 'event_date', 'note', 'amount', 'ref_no', 'old_expiry', 'new_expiry', 'by_name', 'created_at']),
};

export const CATEGORIES = {
  liquor: 'Liquor & spirit licences', trading: 'Business / trading licences', health: 'Health & food', fire: 'Fire & safety', company: 'Company records',
  tax: 'Tax & FRCS', vehicle: 'Vehicles', staff: 'Staff certificates', insurance: 'Insurance', premises: 'Premises & leases', other: 'Other',
};
// Quick add: the usual ones for a Fiji shop (all can be changed).
export const QUICK_ADD = [
  { name: 'Liquor licence', category: 'liquor', authority: 'Liquor Licensing Board (Ministry of Justice)', renewMonths: 12, remindDays: 90, perShop: true },
  { name: 'Spirit licence', category: 'liquor', authority: 'Liquor Licensing Board (Ministry of Justice)', renewMonths: 12, remindDays: 90, perShop: true },
  { name: 'Business licence', category: 'trading', authority: 'Lautoka City Council', renewMonths: 12, remindDays: 45, perShop: true },
  { name: 'Health licence (food premises)', category: 'health', authority: 'Lautoka City Council – Health', renewMonths: 12, remindDays: 60, perShop: true },
  { name: 'Fire safety certificate', category: 'fire', authority: 'National Fire Authority', renewMonths: 12, remindDays: 60, perShop: true },
  { name: 'Scales verification (weights & measures)', category: 'trading', authority: 'Dept. of National Trade Measurement & Standards', renewMonths: 12, remindDays: 30, perShop: true },
  { name: 'Company annual return', category: 'company', authority: 'Registrar of Companies', renewMonths: 12, remindDays: 30 },
  { name: 'VAT registration', category: 'tax', authority: 'FRCS', renewMonths: null, remindDays: 0 },
  { name: 'POS / VMS accreditation', category: 'tax', authority: 'FRCS', renewMonths: null, remindDays: 60 },
  { name: 'Vehicle registration', category: 'vehicle', authority: 'Land Transport Authority', renewMonths: 12, remindDays: 30 },
  { name: 'Vehicle insurance', category: 'insurance', authority: '', renewMonths: 12, remindDays: 30 },
  { name: 'Shop insurance (fire / burglary)', category: 'insurance', authority: '', renewMonths: 12, remindDays: 45 },
  { name: 'Food handler certificate', category: 'staff', authority: 'Health inspector / approved trainer', renewMonths: 12, remindDays: 30 },
  { name: 'Lease agreement', category: 'premises', authority: 'Landlord', renewMonths: null, remindDays: 120 },
];
export const DOC_KINDS = { licence_copy: 'Licence / permit copy', application: 'Application', receipt: 'Payment receipt', letter: 'Letter / correspondence', inspection: 'Inspection report', other: 'Other' };
export const EVENT_KINDS = { applied: 'Application made', paid: 'Fee paid', inspection: 'Inspection', issued: 'Issued', renewed: 'Renewed', note: 'Note', cancelled: 'Cancelled', reopened: 'Put back in use' };

export function saveLicence(user, l) {
  need(txt(l.name), 'Enter what it is, e.g. "Liquor licence".');
  need(CATEGORIES[l.category], 'Choose the type.');
  for (const [k, label] of [['issuedDate', 'Issued'], ['expiryDate', 'Expires']]) need(!txt(l[k]) || DATE.test(txt(l[k])), `${label}: enter the date as YYYY-MM-DD.`);
  const remind = Math.max(0, Math.min(365, Math.round(Number(l.remindDays ?? 60))));
  const renew = txt(l.renewMonths) === '' || l.renewMonths === null ? null : Math.max(1, Math.round(Number(l.renewMonths) || 12));
  const now = stamp(); const dev = deviceId();
  const vals = [txt(l.name), l.category, txt(l.authority) || null, txt(l.licenceNo) || null, txt(l.shopCode) || null, txt(l.holder) || null, txt(l.issuedDate) || null, txt(l.expiryDate) || null,
    renew, remind, txt(l.fee) === '' ? null : Number(l.fee), txt(l.responsible) || null, txt(l.conditions) || null, txt(l.notes) || null];
  if (l.uid) {
    const before = getLicence(l.uid);
    need(before, 'Not found.');
    db().run(`UPDATE licences SET name=?, category=?, authority=?, licence_no=?, shop_code=?, holder=?, issued_date=?, expiry_date=?, renew_months=?, remind_days=?, fee=?, responsible=?, conditions=?, notes=?, ${SYNCED} WHERE uid = ?`, [...vals, now, dev, l.uid]);
    if (before.expiry_date !== (txt(l.expiryDate) || null)) addEvent(user, l.uid, { kind: 'note', note: `Expiry date changed from ${before.expiry_date || 'none'} to ${txt(l.expiryDate) || 'none'}`, oldExpiry: before.expiry_date, newExpiry: txt(l.expiryDate) || null });
    audit({ user, action: `Changed ${txt(l.name)}`, table: 'licences', recordUid: l.uid, before });
    return l.uid;
  }
  const uid = uuid('LIC');
  db().run(`INSERT INTO licences (name, category, authority, licence_no, shop_code, holder, issued_date, expiry_date, renew_months, remind_days, fee, responsible, conditions, notes, uid, status, created_by, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?,?)`, [...vals, uid, user.name, now, now, dev]);
  audit({ user, action: `Added ${txt(l.name)}`, table: 'licences', recordUid: uid });
  return uid;
}
export function getLicence(uid) {
  const l = db().get('SELECT l.*, s.name AS shop_name FROM licences l LEFT JOIN shops s ON s.code = l.shop_code WHERE l.uid = ?', [uid]);
  return l ? { ...l, state: stateOf(l) } : null;
}
export function eventsFor(uid) { return db().all('SELECT * FROM licence_events WHERE licence_uid = ? ORDER BY event_date DESC, created_at DESC', [uid]); }
export function addEvent(user, licenceUid, { kind, date, note, amount, refNo, oldExpiry, newExpiry }) {
  need(EVENT_KINDS[kind], 'Choose what happened.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date as YYYY-MM-DD.');
  const uid = uuid('LE'); const now = stamp();
  db().run(`INSERT INTO licence_events (uid, licence_uid, kind, event_date, note, amount, ref_no, old_expiry, new_expiry, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, licenceUid, kind, d, txt(note) || null, txt(amount) === '' || amount === undefined ? null : Number(amount), txt(refNo) || null, oldExpiry || null, newExpiry || null, user ? user.name : 'System', now, now, deviceId()]);
  return uid;
}

// 'none' (does not expire) | 'ok' | 'due' (inside the reminder time) | 'overdue' (expired) | 'renewing' | 'cancelled'
export function stateOf(l, today = dateStr()) {
  if (l.status === 'cancelled') return 'cancelled';
  if (!l.expiry_date) return l.status === 'renewing' ? 'renewing' : 'none';
  if (l.expiry_date < today) return 'overdue';
  if (l.status === 'renewing') return 'renewing';
  if (l.expiry_date <= addDays(today, Number(l.remind_days) || 0)) return 'due';
  return 'ok';
}
export function daysLeft(l, today = dateStr()) {
  if (!l.expiry_date) return null;
  const a = new Date(`${today}T00:00:00`); const b = new Date(`${l.expiry_date}T00:00:00`);
  return Math.round((b - a) / 86400000);
}
export function listLicences({ shopCode, category, filter = 'all', q, today = dateStr() } = {}) {
  return db().all('SELECT l.*, s.name AS shop_name FROM licences l LEFT JOIN shops s ON s.code = l.shop_code ORDER BY (l.expiry_date IS NULL), l.expiry_date, l.name')
    .map((l) => ({ ...l, state: stateOf(l, today), days: daysLeft(l, today), docs: docCount(l.uid) }))
    .filter((l) => (!shopCode || l.shop_code === shopCode || (shopCode === 'ALL' && !l.shop_code)) && (!category || l.category === category)
      && (filter === 'all' ? l.state !== 'cancelled' : filter === 'attention' ? ['due', 'overdue', 'renewing'].includes(l.state) : filter === 'cancelled' ? l.state === 'cancelled' : true)
      && (!txt(q) || `${l.name} ${l.licence_no || ''} ${l.authority || ''} ${l.shop_name || ''}`.toLowerCase().includes(txt(q).toLowerCase())));
}
function docCount(uid) { try { return db().get("SELECT COUNT(*) AS n FROM documents WHERE ref_type = 'licence' AND ref_uid = ? AND status = 'active'", [uid]).n; } catch (e) { return 0; } }
export function licenceDocuments(uid) { return listDocuments('licence', uid); }

// Renewal: started (application made) → finished (new expiry date, new copy uploaded). Everything is kept.
export function startRenewal(user, uid, { date, note, amount, refNo } = {}) {
  const l = getLicence(uid);
  need(l && l.status !== 'cancelled', 'Not found.');
  db().run(`UPDATE licences SET status = 'renewing', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'applied', date, note: txt(note) || 'Renewal application made', amount, refNo });
  audit({ user, action: `Renewal started: ${l.name}`, table: 'licences', recordUid: uid });
}
export function finishRenewal(user, uid, { newExpiry, issuedDate, licenceNo, fee, refNo, note } = {}) {
  const l = getLicence(uid);
  need(l && l.status !== 'cancelled', 'Not found.');
  const expiry = txt(newExpiry) || (l.expiry_date && l.renew_months ? addMonths(l.expiry_date, l.renew_months) : '');
  need(DATE.test(expiry), 'Enter the new expiry date (YYYY-MM-DD).');
  need(!l.expiry_date || expiry > l.expiry_date, 'The new expiry date must be after the old one.');
  const issued = txt(issuedDate) || dateStr();
  need(DATE.test(issued), 'Issued: enter the date as YYYY-MM-DD.');
  db().run(`UPDATE licences SET status = 'active', expiry_date = ?, issued_date = ?, licence_no = COALESCE(?, licence_no), fee = COALESCE(?, fee), ${SYNCED} WHERE uid = ?`,
    [expiry, issued, txt(licenceNo) || null, txt(fee) === '' || fee === undefined ? null : Number(fee), stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'renewed', date: issued, note: txt(note) || `Renewed until ${expiry}`, amount: fee, refNo, oldExpiry: l.expiry_date, newExpiry: expiry });
  audit({ user, action: `Renewed: ${l.name} until ${expiry}`, table: 'licences', recordUid: uid });
  return expiry;
}
export function cancelLicence(user, uid, reason) {
  const l = getLicence(uid);
  need(l, 'Not found.');
  needReason(user, reason, 'Say why (e.g. "shop closed", "replaced by new licence").');
  db().run(`UPDATE licences SET status = 'cancelled', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'cancelled', note: txt(reason) });
  audit({ user, action: `No longer held: ${l.name}`, table: 'licences', recordUid: uid, reason: txt(reason) });
}
export function reopenLicence(user, uid) {
  db().run(`UPDATE licences SET status = 'active', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  addEvent(user, uid, { kind: 'reopened', note: 'Put back in use' });
}
function addMonths(d, n) {
  const [y, m, day] = d.split('-').map(Number);
  const t = new Date(y, m - 1 + Number(n), 1);
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(Math.min(day, last)).padStart(2, '0')}`;
}

// What needs attention now (Home banner, reminders).
export function licenceAlerts(today = dateStr()) {
  const list = listLicences({ filter: 'attention', today });
  return { overdue: list.filter((l) => l.state === 'overdue'), due: list.filter((l) => l.state === 'due'), renewing: list.filter((l) => l.state === 'renewing'), list };
}
export const alertText = (l) => (l.state === 'overdue' ? `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''} EXPIRED on ${l.expiry_date}`
  : `${l.name}${l.shop_name ? ` (${l.shop_name})` : ''} expires on ${l.expiry_date} – ${l.days} day${l.days === 1 ? '' : 's'} left${l.state === 'renewing' ? ' (renewal in progress)' : ''}`);

// Once a day: a Viber alert at the reminder start, then 30, 14, 7, 3, 1 and 0 days before, and every 7 days once expired.
export function dailyLicenceCheck(notifyFn, today = dateStr()) {
  if (getSetting('licence_check_day', '') === today) return [];
  setSetting('licence_check_day', today);
  const sent = [];
  for (const l of licenceAlerts(today).list) {
    const d = l.days;
    const firstDay = Number(l.remind_days) || 0;
    const hit = d === firstDay || [30, 14, 7, 3, 1, 0].includes(d) || (d < 0 && (-d) % 7 === 0);
    if (!hit) continue;
    const text = alertText(l);
    try { if (notifyFn) notifyFn('licence_due', text, { shopCode: l.shop_code }); } catch (e) { /* alerts never stop the app */ }
    sent.push(text);
  }
  return sent;
}
