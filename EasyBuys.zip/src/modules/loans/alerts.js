// Warnings for Home: loan repayments missed, rent overdue, loans and rent due soon, payments without a receipt photo,
// loans not checked against the lender statement for a while. Interest worked out by the app is added once a day here.
import { can } from '../../services/access.js';
import { getSetting, setSetting, dateStr } from '../../services/core.js';
import { regularOverview, missingReceipts, runLoanInterest, $ } from './service.js';

export const canLoans = (u) => ['loans_manage', 'ap_setup', 'payments_make'].some((p) => can(u, p));
export function alerts(user) {
  if (!canLoans(user)) return [];
  const today = dateStr();
  if (getSetting('loan_interest_ran', '') !== today) {
    try { runLoanInterest(null, today); setSetting('loan_interest_ran', today); } catch (e) { /* tried again next time */ }
  }
  const out = [];
  const s = (n) => (n === 1 ? '' : 's');
  for (const r0 of regularOverview(today).filter((x) => x.active || x.overdue)) {
    // v3.9.7 missed repayments from before the go-live date wait in "Before go-live" until the owner has seen them.
    const r = r0.warnOverdue === undefined ? r0 : { ...r0, overdue: r0.warnOverdue, overdueAmount: r0.warnOverdueAmount };
    const nav = r.kind === 'loan' ? { screen: 'LoanJourney', params: { uid: r.uid } } : { screen: 'LoansRent', params: {} };
    if (r.overdue) {
      out.push({ id: `loan-missed-${r.uid}`, level: 'urgent', text: r.kind === 'loan' ? `${r.name}: ${r.overdue} repayment${s(r.overdue)} missed – ${$(r.overdueAmount)} in arrears` : `${r.name} overdue – ${$(r.overdueAmount)}`,
        sub: r.kind === 'loan' ? 'Pay it now; the lender may charge an arrears fee.' : 'Pay it now, then take a photo of the receipt.', nav });
    } else if (r.nextDue && r.dueIn !== null && r.dueIn <= Math.max(3, r.leadDays || 0) && r.dueIn >= 0) {
      out.push({ id: `loan-due-${r.uid}-${r.nextDue}`, level: r.dueIn <= 1 ? 'warning' : 'info', text: `${r.name}: ${$(r.amount)} due ${r.dueIn === 0 ? 'today' : r.dueIn === 1 ? 'tomorrow' : `in ${r.dueIn} days`}`, sub: 'Keep the receipt – a photo is needed.', nav });
    }
    if (r.kind === 'loan' && r.active && r.reconDue) {
      out.push({ id: `loan-recon-${r.uid}`, level: 'info', text: `${r.name}: not checked against the lender statement ${r.lastReconciled ? `since ${r.lastReconciled}` : 'yet'}`, sub: 'Ask the lender for a statement and check it here.', nav: { screen: 'LoanRecon', params: { uid: r.uid } } });
    }
  }
  const miss = missingReceipts(today);
  if (miss.length) out.push({ id: 'loan-receipts', level: 'warning', text: `${miss.length} loan / rent payment${s(miss.length)} without a receipt photo`, sub: 'Take a photo of each receipt.', nav: { screen: 'RegularReceipts', params: {} } });
  return out;
}
