// Loans & rent (v3.5): regular payments of the shop loans, car loans and rents with reminders and receipt photos,
// the loan journey, checking loans against the lender statement, closed shop (V M Pillay) costs.
import { LoansRentScreen, LoanSetupScreen, RegularEditScreen, LoanJourneyScreen, RegularReceiptsScreen, LoanReconScreen, LoanRulesScreen, MakeRegularBillScreen, LoanStatementsScreen, LoanStatementNewScreen, LoanStatementMatchScreen } from './screens/LoanScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts, canLoans } from './alerts.js';
import { REPORTS } from './reports.js';

const setup = (u) => can(u, 'loans_manage') || can(u, 'ap_setup');
export default {
  id: 'loans',
  title: 'Loans & rent',
  icon: '🏦',
  switchable: true,
  screens: {
    LoansRent: { component: LoansRentScreen, can: canLoans },
    MakeRegularBill: { component: MakeRegularBillScreen, can: canLoans },
    LoanStatements: { component: LoanStatementsScreen, can: canLoans },
    LoanStatementNew: { component: LoanStatementNewScreen, can: canLoans },
    LoanStatementMatch: { component: LoanStatementMatchScreen, can: canLoans },
    LoanSetup: { component: LoanSetupScreen, can: setup },
    RegularEdit: { component: RegularEditScreen, can: setup },
    LoanJourney: { component: LoanJourneyScreen, can: canLoans },
    RegularReceipts: { component: RegularReceiptsScreen, can: canLoans },
    LoanRecon: { component: LoanReconScreen, can: canLoans },
    LoanRules: { component: LoanRulesScreen, can: setup },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
