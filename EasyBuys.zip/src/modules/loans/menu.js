// Loans & rent menu (see src/services/menus.js).
import { MENU as OWNER_MENU } from '../drawings/menu.js';

const LOANS_MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🏦', title: 'Loans & rent', note: 'What is due, missed, paid; balances left; closed shop costs.', screen: 'LoansRent' },
    { id: 'loan-receipts', icon: '🧾', title: 'Receipts to photograph', note: 'Every loan and rent payment needs a receipt photo.', screen: 'RegularReceipts' },
  ] },
  { section: 'Records', items: [
    { id: 'loan-journey', icon: '📉', title: 'Loan journey', note: 'Each repayment split into interest and principal, balance after every line, payoff date.', screen: 'LoanJourney' },
  ] },
  { section: 'Checks', items: [
    { id: 'loan-recon', icon: '⚖️', title: 'Check a loan against the lender statement', note: 'Type the statement balance, interest and fees; fix differences in one tap.', screen: 'LoanRecon' },
  ] },
  { section: 'Reports', items: [
    { id: 'loan-reports', icon: '📊', title: 'Loans, rent & closed shop reports', screen: 'ReportsHub', params: { group: 'Loans & rent' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'loan-setup', icon: '⚡', title: 'Set up loans & rent', note: 'The 3 shop loans, 2 car loans and 3 shop rents – fill in each one.', screen: 'LoanSetup', perm: ['loans_manage', 'ap_setup'] },
    { id: 'loan-rules', icon: '⚙️', title: 'Loans & rent settings', note: 'How far back receipts are checked, how often loans are checked.', screen: 'LoanRules', perm: ['loans_manage', 'ap_setup'] },
  ] },
];

// Owner's money (drawings) sits in the same menu: one place for loans, rent and the owners' own money.
export const MENU = LOANS_MENU.map((sec) => {
  const extra = (OWNER_MENU.find((o) => o.section === sec.section) || { items: [] }).items.map((it) => (it.id === 'home' ? { ...it, id: 'own-home' } : it));
  return { ...sec, items: sec.items.concat(extra) };
}).concat(OWNER_MENU.filter((o) => !LOANS_MENU.some((l) => l.section === o.section)));
