// Loans & rent reports (PDF / Excel / CSV / print / share through the shared report screen).
import { stamp } from '../../services/core.js';
import { listRecurring } from '../payables/recurring.js';
import { loanJourney, paymentsWithReceipts, closedShopCosts, getTerms, PURPOSES, $ } from './service.js';
import { costAreaLabel, areaFor } from '../../services/costAreas.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/[^A-Za-z0-9]+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});
const G = 'Loans & rent';

export const REPORTS = [
  { id: 'loan_journeys', group: G, icon: '📉', title: 'Loan journeys', desc: 'Repayments split into interest and principal, balance after each line, payoff date', perm: 'loans_manage',
    build(from, to) {
      const js = listRecurring({ kind: 'loan', includeInactive: true }).map((l) => loanJourney(l.uid, to)).filter(Boolean);
      const summary = js.map((j) => ({ loan: j.loan.name, lender: j.loan.supplier_name, area: j.areaLabel, paid: $(j.totals.paid), interest: $(j.totals.interest), fees: $(j.totals.fees), balance: $(j.balance),
        arrears: j.arrears ? $(j.arrears) : '', payoff: j.neverPaysOff ? 'never at this repayment' : j.payoffDate || '', checked: j.lastReconciled || 'not yet', _tone: j.missed.length ? 'bad' : null }));
      const detail = [];
      js.forEach((j) => j.lines.filter((l) => l.date >= from && l.date <= to && l.kind !== 'info').forEach((l) => detail.push({
        loan: j.loan.name, date: l.date, what: l.what, ref: l.ref || '', receipt: l.kind === 'payment' ? (l.receiptNo || (l.hasPhoto ? 'photo' : 'MISSING')) : '',
        amount: l.amount === null || l.amount === undefined ? '' : $(l.amount), interest: l.kind === 'payment' ? $(l.interest + l.fees) : '', principal: l.kind === 'payment' ? $(l.principal) : '',
        balance: l.balance === null || l.balance === undefined ? '' : $(l.balance), _tone: l.kind === 'missed' || (l.kind === 'payment' && !l.hasPhoto) ? 'bad' : null })));
      return base('loan_journeys', 'Loan Journeys', from, to, {
        summary: [{ label: 'Loans', value: String(js.length) }, { label: 'Total owing', value: $(js.reduce((s, j) => s + j.balance, 0)) }, { label: 'In arrears', value: $(js.reduce((s, j) => s + j.arrears, 0)) }],
        sections: [{ title: 'Loans', columns: [col('loan', 'Loan'), col('lender', 'Lender'), col('area', 'Cost area'), col('paid', 'Repaid', R), col('interest', 'Interest', R), col('fees', 'Fees', R), col('balance', 'Balance left', R), col('arrears', 'Arrears', R), col('payoff', 'Paid off by'), col('checked', 'Last checked')], rows: summary },
          { title: 'Lines in the period', columns: [col('loan', 'Loan'), col('date', 'Date'), col('what', 'What'), col('ref', 'Invoice no'), col('receipt', 'Receipt'), col('amount', 'Amount', R), col('interest', 'Interest & fees', R), col('principal', 'Principal', R), col('balance', 'Balance', R)], rows: detail }],
      });
    } },
  { id: 'regular_payments', group: G, icon: '🧾', title: 'Loan & rent payments and receipts', desc: 'Every payment of loans, rent and regular bills with its receipt number', perm: 'loans_manage',
    build(from, to) {
      const rows = [];
      listRecurring({ includeInactive: true }).forEach((r) => {
        const t = getTerms(r.uid);
        paymentsWithReceipts(r.uid).filter((p) => p.pay_date >= from && p.pay_date <= to).forEach((p) => rows.push({
          name: r.name, kind: PURPOSES[t.purpose], area: costAreaLabel(areaFor(r.shop_code)), date: p.pay_date, due: p.due_date, ref: p.invoice_no || '', how: `${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}`,
          amount: $(p.amount), receipt: p.receiptNo || (p.hasPhoto ? 'photo' : t.receipt_required ? 'MISSING' : ''), _tone: !p.hasPhoto && t.receipt_required ? 'bad' : null, _a: p.amount }));
      });
      rows.sort((a, b) => (a.date < b.date ? -1 : 1));
      return base('regular_payments', 'Loan and Rent Payments', from, to, {
        summary: [{ label: 'Payments', value: String(rows.length) }, { label: 'Total paid', value: $(rows.reduce((s, x) => s + x._a, 0)) }, { label: 'Receipts missing', value: String(rows.filter((x) => x.receipt === 'MISSING').length) }],
        sections: [{ title: 'Payments', columns: [col('date', 'Paid'), col('name', 'For'), col('kind', 'Kind'), col('area', 'Cost area'), col('due', 'Was due'), col('ref', 'Invoice no'), col('how', 'How'), col('amount', 'Amount', R), col('receipt', 'Receipt')], rows }],
      });
    } },
  { id: 'closed_shop_costs', group: G, icon: '🏚️', title: 'Closed shop costs (V M Pillay)', desc: 'Rent, loan interest and other costs of the closed shop – a whole-business line, never Shop 1 or 2', perm: 'loans_manage',
    build(from, to) {
      const c = closedShopCosts({ from, to });
      return base('closed_shop_costs', 'Closed Shop Costs', from, to, {
        summary: [{ label: 'Closed shop costs', value: $(c.total) }, { label: 'Lines', value: String(c.lines.length) }],
        sections: [{ title: 'By account', columns: [col('account', 'Account'), col('amount', 'Amount', R)], rows: Object.entries(c.byAccount).map(([account, amount]) => ({ account, amount: $(amount) })) },
          { title: 'Lines', columns: [col('date', 'Date'), col('src', 'From'), col('text', 'What'), col('account', 'Account'), col('amount', 'Amount', R)], rows: c.lines.map((l) => ({ ...l, amount: $(l.amount) })) }],
      });
    } },
];
