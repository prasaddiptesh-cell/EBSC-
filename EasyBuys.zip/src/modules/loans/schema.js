// Loans & rent (v3.5): extra details kept beside the regular bills and loans of Invoices & cheques (ap_recurring),
// the receipts of their payments, and the checks of a loan against the lender's statement.
// Nothing here is deleted: receipts and checks are put aside (void) with a reason.
export const LOANS_SQL = `
CREATE TABLE IF NOT EXISTS regular_terms (
  uid TEXT PRIMARY KEY,
  purpose TEXT NOT NULL DEFAULT 'other',
  price REAL,
  deposit REAL,
  principal REAL,
  start_fees REAL,
  term_months INTEGER,
  arrears_rule TEXT NOT NULL DEFAULT 'none',
  arrears_value REAL,
  interest_auto INTEGER NOT NULL DEFAULT 0,
  receipt_required INTEGER NOT NULL DEFAULT 1,
  recon_days INTEGER NOT NULL DEFAULT 60,
  vehicle TEXT,
  template TEXT,
  notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS regular_receipts (
  uid TEXT PRIMARY KEY,
  recurring_uid TEXT NOT NULL,
  invoice_uid TEXT,
  payment_uid TEXT,
  receipt_no TEXT,
  receipt_date TEXT,
  amount REAL,
  photo_urls TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  by_name TEXT, created_at TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_rr_rec ON regular_receipts(recurring_uid);
CREATE TABLE IF NOT EXISTS loan_recons (
  uid TEXT PRIMARY KEY,
  recurring_uid TEXT NOT NULL,
  statement_date TEXT NOT NULL,
  period_from TEXT,
  their_balance REAL NOT NULL,
  their_interest REAL,
  their_fees REAL,
  our_balance REAL NOT NULL,
  our_interest REAL,
  our_fees REAL,
  diff REAL NOT NULL,
  fixes TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  note TEXT,
  by_name TEXT, created_at TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_lr_rec ON loan_recons(recurring_uid, statement_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const LOANS_SYNC = {
  regular_terms: SYNC('uid', 'Loans & rent', ['uid', 'purpose', 'price', 'deposit', 'principal', 'start_fees', 'term_months', 'arrears_rule', 'arrears_value', 'interest_auto', 'receipt_required', 'recon_days', 'vehicle', 'template', 'notes']),
  regular_receipts: SYNC('uid', 'Loans & rent', ['uid', 'recurring_uid', 'invoice_uid', 'payment_uid', 'receipt_no', 'receipt_date', 'amount', 'photo_urls', 'note', 'status', 'by_name', 'created_at', 'void_reason']),
  loan_recons: SYNC('uid', 'Loans & rent', ['uid', 'recurring_uid', 'statement_date', 'period_from', 'their_balance', 'their_interest', 'their_fees', 'our_balance', 'our_interest', 'our_fees', 'diff', 'fixes', 'status', 'note', 'by_name', 'created_at', 'void_reason']),
};
