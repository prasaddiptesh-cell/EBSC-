// Loans & rent screens: overview, easy setup, loan / bill details, loan journey (with a simple chart), receipts,
// checking a loan against the lender's statement, settings.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, Table, PhotoPicker, useApp, useUI, Choice } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain, Stats, ReasonButton } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { dateStr, addDays } from '../../../services/core.js';
import { costAreaOptions, CLOSED } from '../../../services/costAreas.js';
import { listRecurring } from '../../payables/recurring.js';
import * as L from '../service.js';

const { $ } = L;
const loanOptions = () => listRecurring({ kind: 'loan', includeInactive: true }).map((r) => ({ value: r.uid, label: `${r.name}${r.active ? '' : ' (finished)'}` }));
const areaOpts = () => costAreaOptions({ officeValue: '' });
const two = { flexDirection: 'row', gap: 10, flexWrap: 'wrap' };
const half = { flexBasis: 170, flexGrow: 1 };

// ---------------------------------------------------------------- overview
export function LoansRentScreen() {
  const { nav, can } = useApp();
  const rows = L.regularOverview();
  const active = rows.filter((r) => r.active);
  const loans = active.filter((r) => r.kind === 'loan');
  const miss = L.missingReceipts();
  const ym = dateStr().slice(0, 7);
  let closed = { total: 0 };
  try { closed = L.closedShopCosts({ from: `${ym}-01`, to: dateStr() }); } catch (e) { closed = { total: 0 }; }
  const groups = Object.entries(L.PURPOSES).map(([k, label]) => [label, rows.filter((r) => r.purpose === k)]).filter(([, x]) => x.length);
  const setup = can('loans_manage') || can('ap_setup');
  return (
    <Screen title="Loans & rent" subtitle="Regular payments, balances left, receipts">
      <Explain>Each loan and rent makes its bill a few days before it is due (in Invoices & cheques), so it is paid like any other bill – by cheque, cash or transfer. Take a photo of every receipt. The closed V M Pillay shop's loan and rent are "Closed shop costs": a whole-business line, never Shop 1 or Shop 2.</Explain>
      <Stats items={[
        { label: 'Loans owing', value: $(loans.reduce((s, r) => s + (r.balance || 0), 0)), sub: `${loans.length} loan(s)` },
        { label: 'Missed / overdue', value: String(active.reduce((s, r) => s + r.overdue, 0)), color: active.some((r) => r.overdue) ? C.danger : C.success },
        { label: 'Receipts missing', value: String(miss.length), color: miss.length ? C.warn : C.success, onPress: () => nav.push('RegularReceipts', {}), testID: 'lr-receipts' },
        { label: 'Closed shop costs this month', value: $(closed.total), onPress: can('reports') ? () => nav.push('ReportsHub', { group: 'Loans & rent' }) : undefined },
      ]} />
      {setup ? (
        <View style={two}>
          <Btn testID="lr-setup" title="Set up loans & rent" icon="⚡" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('LoanSetup', {})} />
          <Btn testID="lr-add" title="Add another" icon="➕" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('RegularEdit', { kind: 'loan' })} />
        </View>
      ) : null}
      {can('drawings') ? <Btn title="Home rent & groceries (personal)" icon="🏠" size="md" variant="ghost" onPress={() => nav.push('PersonalReminders', {})} /> : null}
      {!rows.length ? <Hint>Nothing set up yet. Tap "Set up loans & rent" to add the 3 shop loans, the 2 car loans and the 3 shop rents.</Hint> : null}
      {groups.map(([label, list]) => (
        <Section key={label} title={label}>
          {list.map((r) => (
            <ListItem key={r.uid} testID={`lr-${r.uid}`} title={r.name} tone={r.overdue ? 'danger' : r.noReceipt ? 'warn' : undefined}
              sub={`${r.lender || ''} · ${r.areaLabel} · ${$(r.amount)} ${(L.FREQ_LABEL[r.frequency] || '').toLowerCase()}${r.nextDue ? ` · next ${r.nextDue}` : ''}${r.lastPaid ? ` · last paid ${r.lastPaid}` : ''}${r.noReceipt ? ` · ${r.noReceipt} receipt(s) missing` : ''}${r.active ? '' : ' · finished'}${r.kind === 'loan' && r.payoffDate ? ` · paid off ${r.payoffDate}` : ''}`}
              right={r.kind === 'loan' ? $(r.balance) : r.owing ? $(r.owing) : ''} rightSub={r.kind === 'loan' ? 'balance left' : r.owing ? 'to pay' : null}
              badge={r.overdue ? (r.kind === 'loan' ? 'MISSED' : 'OVERDUE') : r.closed ? 'CLOSED SHOP' : r.reconDue ? 'CHECK STATEMENT' : null} badgeColor={r.overdue ? C.danger : r.closed ? C.sub : C.info}
              onPress={() => nav.push(r.kind === 'loan' ? 'LoanJourney' : 'RegularEdit', { uid: r.uid })} />
          ))}
          {setup ? list.filter((r) => r.active).map((r) => <Btn key={`mk-${r.uid}`} testID={`lr-make-${r.uid}`} title={`Make the bill now – ${r.name}`} icon="🧾" size="sm" variant="ghost" onPress={() => nav.push('MakeRegularBill', { uid: r.uid })} />) : null}
        </Section>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- easy setup
export function LoanSetupScreen() {
  const { nav } = useApp();
  const list = L.setupStatus();
  return (
    <Screen title="Set up loans & rent" subtitle="Tap each one and fill in the real figures">
      <Hint>Nothing is filled in for you: open each one, choose the lender or landlord, and type the repayment, the next due date and (for loans) the balance owing. The V M Pillay loan and rent go to the closed shop (whole business).</Hint>
      {list.map((s) => (
        <ListItem key={s.key} testID={`ls-${s.key}`} title={`${s.done ? '☑' : '☐'} ${s.name}`} sub={`${L.PURPOSES[s.purpose]}${s.shopCode === CLOSED ? ' · Closed shop costs' : s.shopCode ? ` · ${s.shopCode}` : ' · Whole business'}${s.vehicle ? ` · ${s.vehicle}` : ''}${s.done ? ' · set up – tap to change' : ''}`}
          onPress={() => nav.push('RegularEdit', s.done ? { uid: s.uid } : { template: s.key })} />
      ))}
      <Btn testID="ls-other" title="Add another loan or regular bill" icon="➕" size="md" variant="secondary" onPress={() => nav.push('RegularEdit', { kind: 'loan' })} />
    </Screen>
  );
}

// ---------------------------------------------------------------- one loan / bill with its details
export function RegularEditScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const tpl = params.template ? L.SETUP_ITEMS.find((s) => s.key === params.template) : null;
  const r0 = params.uid ? L.getRecurring(params.uid) : null;
  const t0 = r0 ? L.getTerms(r0.uid) : null;
  const [f, setF] = useState(() => {
    if (r0) {
      return {
        uid: r0.uid, kind: r0.kind, name: r0.name, supplierUid: r0.supplier_uid, newLender: '', amount: String(r0.amount), vatType: r0.vat_type, frequency: r0.frequency, nextDate: r0.next_date, endDate: r0.end_date || '',
        leadDays: String(r0.lead_days), shopCode: r0.shop_code || '', category: r0.category || '', loanNo: r0.loan_no || '', security: r0.security || '', openingBalance: r0.opening_balance == null ? '' : String(r0.opening_balance),
        openingDate: r0.opening_date || '', interestRate: r0.interest_rate == null ? '' : String(r0.interest_rate), notes: r0.notes || '', active: !!r0.active,
        purpose: t0.purpose, price: t0.price == null ? '' : String(t0.price), deposit: t0.deposit == null ? '' : String(t0.deposit), principal: t0.principal == null ? '' : String(t0.principal),
        startFees: t0.start_fees == null ? '' : String(t0.start_fees), termMonths: t0.term_months == null ? '' : String(t0.term_months), arrearsRule: t0.arrears_rule, arrearsValue: t0.arrears_value == null ? '' : String(t0.arrears_value),
        interestAuto: t0.interest_auto, receiptRequired: t0.receipt_required, reconDays: String(t0.recon_days), vehicle: t0.vehicle || '', template: t0.template || '',
      };
    }
    const kind = tpl ? tpl.kind : params.kind === 'bill' ? 'bill' : 'loan';
    const lender = tpl && tpl.lender ? L.listSuppliers().find((s) => s.name.toLowerCase().startsWith(tpl.lender.toLowerCase())) : null;
    return {
      kind, name: tpl ? tpl.name : '', supplierUid: lender ? lender.uid : '', newLender: tpl && tpl.lender && !lender ? tpl.lender : '', amount: '', vatType: kind === 'bill' ? 'standard' : 'zero', frequency: 'monthly', nextDate: dateStr(), endDate: '',
      leadDays: '7', shopCode: tpl ? tpl.shopCode || '' : '', category: tpl && tpl.category ? tpl.category : '', loanNo: '', security: tpl && tpl.vehicle ? `Vehicle ${tpl.vehicle}` : '', openingBalance: '', openingDate: dateStr(), interestRate: '', notes: '', active: true,
      purpose: tpl ? tpl.purpose : kind === 'loan' ? 'other_loan' : 'bill', price: '', deposit: '', principal: '', startFees: '', termMonths: '', arrearsRule: 'none', arrearsValue: '', interestAuto: false, receiptRequired: true, reconDays: '', vehicle: tpl && tpl.vehicle ? tpl.vehicle : '', template: tpl ? tpl.key : '',
    };
  });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const loan = f.kind === 'loan';
  const save = () => {
    const rec = act(() => {
      const g = { ...f };
      if (!g.supplierUid && g.newLender) g.supplierUid = L.ensureLender(user, g.newLender).uid;
      if (loan && !g.openingBalance && g.principal) g.openingBalance = g.principal;
      return L.saveRegular(user, g);
    }, 'Saved');
    if (rec) nav.pop();
  };
  const purposes = Object.entries(L.PURPOSES).filter(([k]) => (loan ? k.endsWith('loan') : !k.endsWith('loan'))).map(([value, label]) => ({ value, label }));
  return (
    <Screen title={r0 ? r0.name : loan ? 'New loan' : 'New regular bill'} subtitle={loan ? 'Loan details' : 'Rent or other regular bill'} footer={<Btn testID="re-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      {!r0 && !tpl ? <Chips value={f.kind} onChange={(v) => setF((o) => ({ ...o, kind: v, purpose: v === 'loan' ? 'other_loan' : 'bill', vatType: v === 'loan' ? 'zero' : 'standard' }))} testIDPrefix="re-kind" options={[{ value: 'loan', label: 'Loan' }, { value: 'bill', label: 'Rent / regular bill' }]} /> : null}
      <Card>
        <Field testID="re-name" label="Name" value={f.name} onChangeText={set('name')} placeholder={loan ? 'e.g. Shop 1 Drasa Ave business loan' : 'e.g. Shop 2 rent'} />
        <Label>Kind</Label>
        <Chips value={f.purpose} onChange={set('purpose')} testIDPrefix="re-purpose" options={purposes} />
        <Select testID="re-lender" label={loan ? 'Lender' : 'Paid to (landlord)'} value={f.supplierUid} onChange={set('supplierUid')} options={L.listSuppliers().map((s) => ({ value: s.uid, label: s.name }))} />
        {!f.supplierUid ? <Field testID="re-newlender" label={loan ? 'Or type a new lender (e.g. BSP, Credit Corp)' : 'Or type a new landlord'} value={f.newLender} onChangeText={set('newLender')} /> : null}
        <Label>Cost area</Label>
        <Chips value={f.shopCode} onChange={set('shopCode')} testIDPrefix="re-area" options={areaOpts()} />
        {f.shopCode === CLOSED ? <Hint>Closed shop: its costs show on their own line "Closed shop costs" (whole business), never on Shop 1 or Shop 2.</Hint> : null}
      </Card>
      <Card>
        <H>{loan ? 'Repayments' : 'Payments'}</H>
        <MoneyField testID="re-amount" label={loan ? 'Repayment amount' : 'Amount (usual bill)'} value={f.amount} onChange={set('amount')} />
        {!loan ? <Chips value={f.vatType} onChange={set('vatType')} options={[{ value: 'standard', label: 'Includes VAT' }, { value: 'zero', label: 'No VAT' }]} /> : null}
        <Label>How often</Label>
        <Choice value={f.frequency} onChange={set('frequency')} testIDPrefix="re-freq" options={Object.entries(L.FREQ_LABEL).map(([value, label]) => ({ value, label }))} />
        <DateField testID="re-next" label="Next due date" value={f.nextDate} onChange={set('nextDate')} />
        <Field label="Remind and make the bill this many days before" value={f.leadDays} onChangeText={set('leadDays')} keyboardType="number-pad" />
        <DateField farDays={false} label="Last payment date (optional)" value={f.endDate} onChange={set('endDate')} />
        <Chips value={f.receiptRequired} onChange={set('receiptRequired')} testIDPrefix="re-receipt" options={[{ value: true, label: 'Receipt photo required' }, { value: false, label: 'No receipt needed' }]} />
      </Card>
      {loan ? (
        <Card>
          <H>The loan</H>
          <Field testID="re-loanno" label="Loan / account number" value={f.loanNo} onChangeText={set('loanNo')} />
          {f.purpose === 'car_loan' ? <Field testID="re-vehicle" label="Vehicle (registration)" value={f.vehicle} onChangeText={set('vehicle')} placeholder="e.g. PB 113" /> : null}
          <Field label="Security (e.g. vehicle PB 113, Shop 1 building)" value={f.security} onChangeText={set('security')} />
          <View style={two}>
            <View style={half}><MoneyField testID="re-price" label="Price (what was bought)" value={f.price} onChange={set('price')} /></View>
            <View style={half}><MoneyField testID="re-deposit" label="Deposit paid" value={f.deposit} onChange={set('deposit')} /></View>
          </View>
          <View style={two}>
            <View style={half}><MoneyField label="Fees added at the start" value={f.startFees} onChange={set('startFees')} /></View>
            <View style={half}><MoneyField testID="re-principal" label="Amount borrowed" value={f.principal} onChange={set('principal')} placeholder="price − deposit + fees" /></View>
          </View>
          <View style={two}>
            <View style={half}><MoneyField testID="re-opening" label="Balance owing on the start date" value={f.openingBalance} onChange={set('openingBalance')} placeholder="the amount borrowed" /></View>
            <View style={half}><DateField farDays={false} testID="re-opendate" label="Start date (date of that balance)" value={f.openingDate} onChange={set('openingDate')} /></View>
          </View>
          <View style={two}>
            <View style={half}><Field testID="re-rate" label="Interest rate % a year" value={f.interestRate} onChangeText={set('interestRate')} keyboardType="decimal-pad" /></View>
            <View style={half}><Field label="Loan term (months, optional)" value={f.termMonths} onChangeText={set('termMonths')} keyboardType="number-pad" /></View>
          </View>
          <Label>Interest</Label>
          <Chips value={f.interestAuto} onChange={set('interestAuto')} testIDPrefix="re-int" options={[{ value: false, label: 'Typed from the lender statement' }, { value: true, label: 'The app works it out on each due date' }]} />
          <Label>Fee for a missed repayment (arrears fee)</Label>
          <Chips value={f.arrearsRule} onChange={set('arrearsRule')} testIDPrefix="re-arr" options={Object.entries(L.ARREARS_RULES).map(([value, label]) => ({ value, label }))} />
          {f.arrearsRule !== 'none' ? <Field testID="re-arrval" label={f.arrearsRule === 'pct' ? '% of the amount in arrears' : 'Amount for each missed repayment'} value={f.arrearsValue} onChangeText={set('arrearsValue')} keyboardType="decimal-pad" /> : null}
          <Field label="Check against the lender statement every … days" value={f.reconDays} onChangeText={set('reconDays')} keyboardType="number-pad" placeholder={String(L.loanRules().reconDays)} />
        </Card>
      ) : null}
      <Card>
        <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
        <Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'Active' }, { value: false, label: loan ? 'Paid off / stopped' : 'Stopped' }]} />
      </Card>
      {r0 && loan ? <Btn title="Open the loan journey" icon="📉" size="md" variant="secondary" onPress={() => nav.replace('LoanJourney', { uid: r0.uid })} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- the loan journey
function BalanceChart({ points }) {
  if (!points.length) return null;
  const max = Math.max(...points.map((p) => p.balance), 1);
  return (
    <View testID="lj-chart" style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 140, gap: 3 }}>
        {points.map((p, i) => (
          <View key={i} style={{ flex: 1, height: `${Math.max(1, (p.balance / max) * 100)}%`, backgroundColor: p.planned ? C.infoSoft : C.primary, borderWidth: p.planned ? 1 : 0, borderColor: C.info, borderTopLeftRadius: 3, borderTopRightRadius: 3 }} />
        ))}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ fontSize: 13, color: C.sub }}>{points[0].date}</Text>
        <Text style={{ fontSize: 13, color: C.sub }}>■ so far   □ plan to zero</Text>
        <Text style={{ fontSize: 13, color: C.sub }}>{points[points.length - 1].date}</Text>
      </View>
    </View>
  );
}
export function LoanJourneyScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [pick, setPick] = useState(params.uid || '');
  const [e, setE] = useState(null);
  const uid = params.uid || pick;
  const j = uid ? L.loanJourney(uid) : null;
  if (!j) {
    return (
      <Screen title="Loan journey" subtitle="Choose a loan">
        <Select testID="lj-pick" label="Loan" value={pick} onChange={setPick} options={loanOptions()} />
        {!loanOptions().length ? <Hint>No loans yet. Add them in Loans & rent › Set up loans & rent.</Hint> : null}
      </Screen>
    );
  }
  const r = j.loan; const t = j.terms;
  const manage = can('loans_manage') || can('ap_setup');
  const rows = j.lines.map((l) => ({
    date: l.date, what: l.what, ref: l.ref || '', receipt: l.kind === 'payment' ? (l.receiptNo || (l.hasPhoto ? 'photo ✓' : '⚠ missing')) : '',
    amount: l.amount === null || l.amount === undefined ? '' : $(l.amount), int: l.kind === 'payment' ? $(l.interest + l.fees) : '', prin: l.kind === 'payment' ? $(l.principal) : '',
    bal: l.balance === null || l.balance === undefined ? '' : $(l.balance), _bg: l.kind === 'missed' ? C.dangerSoft || '#FDECEC' : l.kind === 'info' ? '#F6F4EF' : undefined,
  }));
  return (
    <Screen title={r.name} subtitle={`${r.supplier_name || ''}${r.loan_no ? ` · ${r.loan_no}` : ''} · ${j.areaLabel}`}>
      <Stats items={[
        { label: 'Balance left', value: $(j.balance), color: C.danger },
        { label: 'Repaid so far', value: $(j.totals.paid), sub: `${j.totals.payments} payment(s)`, color: C.success },
        { label: 'Interest & fees charged', value: $(j.totals.interest + j.totals.fees) },
        { label: 'Paid off by', value: j.neverPaysOff ? 'Never' : j.payoffDate || '—', sub: j.neverPaysOff ? 'repayment does not cover the interest' : `${j.plan.payments} more repayment(s)`, color: j.neverPaysOff ? C.danger : undefined },
      ]} />
      {j.missed.length ? <Banner testID="lj-missed" tone="danger" title={`${j.missed.length} repayment(s) missed – ${$(j.arrears)} in arrears`} message="Pay them in Invoices & cheques. The lender may charge an arrears fee." /> : null}
      {j.missed.length && manage ? (
        <Card>
          <Text style={{ fontSize: 16 }}>{t.arrears_rule !== 'none' ? `Arrears fee by your rule (${t.arrears_rule === 'pct' ? `${t.arrears_value}% of arrears` : `${$(t.arrears_value)} per missed repayment`}): ${$(j.suggestedFee)}` : 'No arrears fee rule: type the fee from the lender statement when it comes (Add interest / fee).'}</Text>
          {j.suggestedFee > 0 ? <Btn testID="lj-arrears" title={`Add arrears fee ${$(j.suggestedFee)}`} size="md" variant="warn" onPress={() => act(() => L.addArrearsFee(user, r.uid), 'Arrears fee added')} /> : null}
        </Card>
      ) : null}
      {j.reconDue ? <Banner tone="info" message={`Not checked against the lender statement ${j.lastReconciled ? `since ${j.lastReconciled}` : 'yet'}.`} /> : null}
      <Card>
        <Row label="Repayment" value={`${$(r.amount)} · ${L.FREQ_LABEL[r.frequency]}`} />
        <Row label="Next due" value={j.nextDue || '—'} />
        {r.interest_rate != null ? <Row label="Interest rate" value={`${r.interest_rate}% a year${t.interest_auto ? ' (worked out by the app)' : ' (typed from statements)'}`} /> : null}
        {t.vehicle ? <Row label="Vehicle" value={t.vehicle} /> : null}
        <Row label="Last checked with the lender" value={j.lastReconciled || 'not yet'} />
        <Row label="Interest paid / principal repaid" value={`${$(j.totals.interestPaid + j.totals.feesPaid)} / ${$(j.totals.principal)}`} />
      </Card>
      <Section title="Balance down to zero">
        <BalanceChart points={j.chart} />
      </Section>
      <View style={two}>
        {manage ? <Btn testID="lj-entry" title="Add interest / fee" icon="➕" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setE({ type: 'interest', amount: '', date: dateStr(), note: '' })} /> : null}
        {manage ? <Btn testID="lj-recon" title="Check the lender statement" icon="⚖️" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('LoanRecon', { uid: r.uid })} /> : null}
        {manage ? <Btn testID="lj-statements" title="Lender statements (upload / type)" icon="📄" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('LoanStatements', { uid: r.uid })} /> : null}
        <Btn testID="lj-receipts" title="Receipts" icon="🧾" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('RegularReceipts', { uid: r.uid })} />
        {manage ? <Btn testID="lj-change" title="Change loan" size="md" variant="ghost" style={{ flexGrow: 1 }} onPress={() => nav.push('RegularEdit', { uid: r.uid })} /> : null}
      </View>
      {e ? (
        <Card>
          <Chips value={e.type} onChange={(v) => setE({ ...e, type: v })} testIDPrefix="lj-type" options={Object.entries(L.ENTRY_LABEL).map(([value, label]) => ({ value, label }))} />
          <MoneyField testID="lj-amount" label="Amount" value={e.amount} onChange={(v) => setE({ ...e, amount: v })} />
          <DateField label="Date" value={e.date} onChange={(v) => setE({ ...e, date: v })} />
          <Field label={e.type.startsWith('adjust') ? 'Reason' : 'Note (optional)'} value={e.note} onChangeText={(v) => setE({ ...e, note: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setE(null)} />
            <Btn testID="lj-entry-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => L.addEntry(user, { ...e, recurringUid: r.uid }), 'Saved')) setE(null); }} />
          </View>
        </Card>
      ) : null}
      <Section title="Every line">
        <Table testID="lj-table" columns={[{ key: 'date', title: 'Date' }, { key: 'what', title: 'What', width: 250 }, { key: 'ref', title: 'Invoice no', width: 140 }, { key: 'receipt', title: 'Receipt', width: 120 },
          { key: 'amount', title: 'Amount', align: 'right' }, { key: 'int', title: 'Interest & fees', align: 'right', width: 130 }, { key: 'prin', title: 'Principal', align: 'right' }, { key: 'bal', title: 'Balance', align: 'right', bold: true, width: 120 }]} rows={rows} />
      </Section>
      {manage ? (
        <Section title="Entries">
          {j.lines.filter((l) => l.uid).slice(-8).reverse().map((l) => (
            <View key={l.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 15 }}>{l.date} · {l.what} · {$(l.amount)}</Text>
              <ReasonButton title="Put aside" size="sm" variant="ghost" prompt="Why is it wrong? (it is kept, just not counted)" confirm="Put aside" onDo={(w) => act(() => L.voidEntry(user, l.uid, w), 'Put aside')} />
            </View>
          ))}
        </Section>
      ) : null}
      <Section title="Loan papers">
        <DocumentsPanel refType="loan" refUid={r.uid} kinds={{ statement: 'Lender statement', agreement: 'Loan agreement', receipt: 'Receipt', other: 'Other' }} canAdd={manage} testID="lj-docs" />
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- receipts
export function RegularReceiptsScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [f, setF] = useState({ receiptNo: '', date: dateStr(), photos: [] });
  const ui = useUI();
  const lp = usePaper('loan');
  const LOAN_MAP = { receiptNo: 'receiptNo', date: 'date' };
  const one = params.uid ? L.getRecurring(params.uid) : null;
  const list = one ? L.paymentsWithReceipts(one.uid).map((p) => ({ ...p, recurring_uid: one.uid, name: one.name })).reverse() : L.missingReceipts();
  const start = (p) => { setOpen(`${p.payment_uid}|${p.invoice_uid}`); setF({ receiptNo: '', date: p.pay_date, photos: [] }); };
  return (
    <Screen title={one ? `Receipts – ${one.name}` : 'Receipts to photograph'} subtitle={one ? 'Every payment and its receipt' : `Loan and rent payments in the last ${L.loanRules().receiptsFromDays} days without a receipt photo`}>
      <Hint>Ask the lender or landlord for a receipt every time you pay, then take a photo here. The receipt number is kept with the payment.</Hint>
      {!list.length ? <Banner tone="success" message={one ? 'No payments yet.' : 'Every payment has its receipt photo.'} /> : null}
      {list.map((p) => {
        const k = `${p.payment_uid}|${p.invoice_uid}`;
        return (
          <View key={k} style={{ gap: 6 }}>
            <ListItem testID={`rr-${p.payment_uid}`} title={`${p.name}`} sub={`Paid ${p.pay_date} by ${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''} · bill ${p.invoice_no || ''}${p.receiptNo ? ` · receipt ${p.receiptNo}` : ''}`}
              right={$(p.amount)} badge={p.hasPhoto ? 'RECEIPT ✓' : 'NO RECEIPT'} badgeColor={p.hasPhoto ? C.success : C.warn} onPress={p.hasPhoto ? undefined : () => start(p)} />
            {open === k ? (
              <Card>
                <Field testID="rr-no" label="Receipt number" value={f.receiptNo} onChangeText={(v) => setF({ ...f, receiptNo: v })} />
                <DateField label="Receipt date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
                <PaperPhoto pr={lp} testID="rr-photo" label="Photo of the receipt" value={f.photos} onChange={(v) => setF((o) => ({ ...o, photos: v }))} required form={f} setForm={setF} map={LOAN_MAP}
                  labels={{ receiptNo: 'Receipt number', date: 'Receipt date' }} hint="The receipt number and date fill in from the photo; the amount is compared.">
                  {lp.read && lp.read.fields.amount !== undefined && Math.abs(lp.read.fields.amount - p.amount) > 0.004 ? <Banner testID="rr-amtdiff" tone="warn" message={`The receipt shows $${lp.read.fields.amount.toFixed(2)} but the payment was $${Number(p.amount).toFixed(2)}.`} /> : null}
                </PaperPhoto>
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setOpen(null)} />
                  <Btn testID="rr-save" title="Save receipt" variant="success" style={{ flex: 1 }} onPress={() => { if (!lp.okToSave(ui)) return; if (act(() => L.addReceipt(user, { recurringUid: p.recurring_uid, paymentUid: p.payment_uid, invoiceUid: p.invoice_uid, amount: p.amount, ...f }), 'Receipt saved')) { lp.log(user, 'loan_receipts', p.payment_uid, f, LOAN_MAP); lp.reset(); setOpen(null); } }} />
                </View>
              </Card>
            ) : null}
          </View>
        );
      })}
      {one ? L.listReceipts(one.uid).map((x) => (
        <View key={x.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={{ flex: 1, fontSize: 15, color: C.sub }}>Receipt {x.receipt_no || '(no number)'} · {x.receipt_date} · {x.photos.length} photo(s) · by {x.by_name}</Text>
          <ReasonButton title="Put aside" size="sm" variant="ghost" prompt="Why? (it is kept, just hidden)" confirm="Put aside" onDo={(w) => act(() => L.voidReceipt(user, x.uid, w), 'Put aside')} />
        </View>
      )) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- check against the lender statement
export function LoanReconScreen({ params = {} }) {
  const { user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const [uid, setUid] = useState(params.uid || '');
  const [f, setF] = useState({ statementDate: dateStr(), periodFrom: '', balance: '', interest: '', fees: '' });
  const [cmp, setCmp] = useState(null);
  const [apply, setApply] = useState([]);
  const set = (k) => (v) => { setF((o) => ({ ...o, [k]: v })); setCmp(null); };
  const r = uid ? L.getRecurring(uid) : null;
  const last = r ? L.lastRecon(uid) : null;
  const compare = () => { try { const c = L.reconCompare(uid, f); setCmp(c); setApply(c.fixes.map((x) => x.key)); } catch (e) { ui.error(e); } };
  const save = () => { const res = act(() => L.saveRecon(user, uid, f, { apply }), 'Saved'); if (res) { setCmp(null); ui.toast(res.status === 'agreed' ? 'The loan agrees with the lender statement ✓' : `Still ${$(res.diff)} different – saved as not agreed`); } };
  const manage = can('loans_manage') || can('ap_setup');
  return (
    <Screen title="Check a loan" subtitle="Against the lender's statement">
      <Select testID="lc-loan" label="Loan" value={uid} onChange={(v) => { setUid(v); setCmp(null); }} options={loanOptions()} />
      {!r ? <Hint>Choose the loan. You need the lender's statement (paper, PDF or a photo).</Hint> : (
        <>
          <Row label="Last checked and agreed" value={last ? last.statement_date : 'never'} />
          <Card>
            <H>From the lender statement</H>
            <View style={two}>
              <View style={half}><DateField farDays={false} testID="lc-date" label="Statement date (balance on)" value={f.statementDate} onChange={set('statementDate')} /></View>
              <View style={half}><DateField farDays={false} label="Statement starts (optional)" value={f.periodFrom} onChange={set('periodFrom')} /></View>
            </View>
            <MoneyField testID="lc-balance" label="Balance on the statement" value={f.balance} onChange={set('balance')} />
            <View style={two}>
              <View style={half}><MoneyField testID="lc-interest" label="Interest charged (optional)" value={f.interest} onChange={set('interest')} /></View>
              <View style={half}><MoneyField testID="lc-fees" label="Fees charged (optional)" value={f.fees} onChange={set('fees')} /></View>
            </View>
            <Btn testID="lc-compare" title="Compare" icon="⚖️" size="md" variant="info" onPress={compare} />
          </Card>
          {cmp ? (
            <Card>
              <Table columns={[{ key: 'what', title: '', width: 150 }, { key: 'their', title: 'Statement', align: 'right', width: 120 }, { key: 'ours', title: 'This app', align: 'right', width: 120 }, { key: 'diff', title: 'Difference', align: 'right', width: 120 }]}
                rows={[{ what: 'Balance', their: $(cmp.their.balance), ours: $(cmp.ours.balance), diff: $(cmp.diff) },
                  { what: 'Interest', their: cmp.their.interest === null ? '—' : $(cmp.their.interest), ours: $(cmp.ours.interest), diff: $(cmp.diffInterest) },
                  { what: 'Fees', their: cmp.their.fees === null ? '—' : $(cmp.their.fees), ours: $(cmp.ours.fees), diff: $(cmp.diffFees) }]} />
              <Text style={{ fontSize: 14, color: C.sub }}>{cmp.from} to {cmp.to}</Text>
              {cmp.agrees ? <Banner testID="lc-agrees" tone="success" message="The loan agrees with the lender statement ✓" /> : null}
              {cmp.fixes.map((x) => (
                <View key={x.key} style={{ gap: 4 }}>
                  <Btn testID={`lc-fix-${x.key}`} title={`${apply.includes(x.key) ? '☑' : '☐'} ${x.text}`} size="md" variant={apply.includes(x.key) ? 'info' : 'secondary'}
                    onPress={() => setApply(apply.includes(x.key) ? apply.filter((k) => k !== x.key) : apply.concat([x.key]))} />
                  {x.hint ? <Hint>{x.hint}</Hint> : null}
                </View>
              ))}
              {manage ? <Btn testID="lc-save" title={cmp.fixes.length ? 'Make the ticked fixes and save' : 'Save the check'} icon="💾" variant="success" onPress={save} /> : null}
            </Card>
          ) : null}
          <Section title="The lender statement (keep a copy)">
            <DocumentsPanel refType="loan" refUid={uid} kinds={{ statement: 'Lender statement', agreement: 'Loan agreement', receipt: 'Receipt', other: 'Other' }} defaultKind="statement" canAdd={manage} testID="lc-docs" />
          </Section>
          <Section title="Earlier checks">
            {L.listRecons(uid).map((x) => (
              <ListItem key={x.uid} title={`${x.statement_date} · statement ${$(x.their_balance)}`} sub={`${x.status === 'agreed' ? 'Agreed ✓' : x.status === 'void' ? `Put aside: ${x.void_reason || ''}` : `Differs by ${$(x.diff)}`}${x.fixes.length ? ` · ${x.fixes.length} fix(es)` : ''} · by ${x.by_name}`}
                badge={x.status === 'agreed' ? 'AGREED' : x.status === 'void' ? 'PUT ASIDE' : 'NOT AGREED'} badgeColor={x.status === 'agreed' ? C.success : x.status === 'void' ? C.sub : C.warn} />
            ))}
          </Section>
        </>
      )}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings
export function LoanRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = L.loanRules();
  const [f, setF] = useState({ receiptsFromDays: String(r0.receiptsFromDays), reconDays: String(r0.reconDays) });
  return (
    <Screen title="Loans & rent settings" footer={<Btn testID="lrs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => L.saveLoanRules(user, f), 'Saved')} />}>
      <Field testID="lrs-from" label="Look for missing receipts in the last … days" value={f.receiptsFromDays} onChangeText={(v) => setF({ ...f, receiptsFromDays: v })} keyboardType="number-pad" />
      <Field testID="lrs-recon" label="Check each loan against the lender statement every … days (unless set on the loan)" value={f.reconDays} onChangeText={(v) => setF({ ...f, reconDays: v })} keyboardType="number-pad" />
      <Hint>Each loan's arrears fee rule and how its interest is worked out are set on the loan (Loans & rent › tap the loan › Change loan).</Hint>
    </Screen>
  );
}

// v3.9.8 the admin makes a loan / rent / regular bill now (the next one due, or another date; the amount can differ).
export function MakeRegularBillScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const R = require('../../payables/recurring.js');
  const r = R.getRecurring(params.uid);
  const [f, setF] = useState(() => ({ date: (r && r.next_date) || dateStr(), amount: r ? String(r.amount) : '', note: '' }));
  if (!r) return <Screen title="Make a bill"><Hint>Not found.</Hint></Screen>;
  return (
    <Screen title={`Make the bill – ${r.name}`} subtitle="It goes to Invoices & cheques, ready to pay"
      footer={<Btn testID="mrb-save" title="Make the bill" icon="🧾" variant="success" onPress={() => { const x = act(() => R.makeRegularBillNow(user, r.uid, f), 'Bill made'); if (x) nav.back(); }} />}>
      <Hint>The bills are also made by themselves a few days before each due date. Use this when the bill came early, or the amount is different this time. The same bill is never made twice.</Hint>
      <DateField testID="mrb-date" label="Due date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
      <MoneyField testID="mrb-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
      <Field testID="mrb-note" label="Note (optional)" value={f.note} onChangeText={(v) => setF({ ...f, note: v })} />
    </Screen>
  );
}

// v3.9.8 a loan's lender statements: upload (photo read into lines, or paste the text) or type the lines; then match
// them with the app and add what is missing – only what is ticked.
export function LoanStatementsScreen({ params = {} }) {
  const { user, nav } = useApp();
  const r = listRecurring({ kind: 'loan' }).find((x) => x.uid === params.uid);
  if (!r) return <Screen title="Statements"><Hint>Loan not found.</Hint></Screen>;
  const list = L.listStatements(r.uid);
  return (
    <Screen title={`Statements – ${r.name}`} subtitle="The lender's statements, matched with the app">
      <Btn testID="ls-new" title="Add a statement (upload or type)" icon="➕" variant="info" onPress={() => nav.push('LoanStatementNew', { uid: r.uid })} />
      {!list.length ? <Hint>No statements yet. Add each statement from the lender (BSP, Credit Corp…): the app matches every repayment, interest and fee, and the balance must agree.</Hint> : null}
      {list.map((s) => (
        <ListItem key={s.uid} testID={`ls-${s.uid}`} title={`${s.period_from ? `${s.period_from} – ` : ''}${s.period_to}`} sub={`${s.lines.length} line(s)${s.closing_balance !== null ? ` · closing ${$(s.closing_balance)}` : ''}${s.rate ? ` · ${s.rate}%` : ''} · ${s.status === 'applied' ? 'matched' : 'to match'}`}
          tone={s.status === 'open' ? 'warn' : undefined} onPress={() => nav.push('LoanStatementMatch', { sUid: s.uid })} />
      ))}
      {user ? null : null}
    </Screen>
  );
}
const KIND_OPTS = Object.entries(L.STATEMENT_KINDS).map(([value, label]) => ({ value, label }));
export function LoanStatementNewScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const r = listRecurring({ kind: 'loan' }).find((x) => x.uid === params.uid);
  const [photos, setPhotos] = useState([]);
  const [text, setText] = useState('');
  const [f, setF] = useState({ periodFrom: '', periodTo: '', closingBalance: '', rate: '' });
  const [lines, setLines] = useState([]);
  const [busy, setBusy] = useState(false);
  if (!r) return <Screen title="Statement"><Hint>Loan not found.</Hint></Screen>;
  const fill = (t) => {
    const p = L.parseLoanStatement(t);
    setLines(p.lines.map((l) => ({ ...l, amount: String(l.amount), balance: l.balance === null ? '' : String(l.balance) })));
    setF((o) => ({ ...o, closingBalance: o.closingBalance || (p.closing !== null ? String(p.closing) : ''), rate: o.rate || (p.rate ? String(p.rate) : ''), periodTo: o.periodTo || (p.lines.length ? p.lines.map((l) => l.date).sort().pop() : ''), periodFrom: o.periodFrom || (p.lines.length ? p.lines.map((l) => l.date).sort()[0] : '') }));
    ui.toast(p.lines.length ? `${p.lines.length} line(s) read – check each one` : 'No lines could be read – type them below');
  };
  const read = async () => {
    if (!photos.length) { ui.toast('Take or choose the statement photo first'); return; }
    setBusy(true);
    try { const R = await require('../../../platform/paperReader.js').readPaper('loan_statement', photos); fill(R.text || ''); } catch (e) { ui.error(e); }
    setBusy(false);
  };
  const setL = (i, k) => (v) => setLines((o) => o.map((x, j) => (j === i ? { ...x, [k]: v } : x)));
  const save = () => {
    const s = act(() => L.saveStatement(user, r.uid, { ...f, lines: lines.map((l) => ({ ...l, amount: Number(l.amount), balance: l.balance === '' ? null : Number(l.balance) })), photos, source: photos.length || text ? 'upload' : 'typed' }));
    if (s) nav.replace('LoanStatementMatch', { sUid: s.uid });
  };
  return (
    <Screen title={`Statement – ${r.name}`} subtitle="Upload it, or type the lines" footer={<Btn testID="lsn-save" title="Next: match with the app" icon="🔎" variant="success" onPress={save} />}>
      <Card>
        <H>1. The statement</H>
        <PhotoPicker testID="lsn-photo" value={photos} onChange={setPhotos} label="Photo of each page (or a screenshot)" />
        <Btn testID="lsn-read" title={busy ? 'Reading…' : 'Read the photo'} icon="🔎" size="md" variant="info" disabled={busy || !photos.length} onPress={read} />
        <Field testID="lsn-text" label="Or paste the statement text (from the PDF)" value={text} onChangeText={setText} multiline />
        {text.trim() ? <Btn testID="lsn-readtext" title="Read the pasted text" size="sm" variant="secondary" onPress={() => fill(text)} /> : null}
      </Card>
      <Card>
        <H>2. Check the figures</H>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><DateField testID="lsn-from" label="From" value={f.periodFrom} onChange={(v) => setF({ ...f, periodFrom: v })} optional /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><DateField testID="lsn-to" label="To (statement date)" value={f.periodTo} onChange={(v) => setF({ ...f, periodTo: v })} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="lsn-closing" label="Closing balance" value={f.closingBalance} onChange={(v) => setF({ ...f, closingBalance: v })} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><Field testID="lsn-rate" label="Interest rate % a year (if shown)" value={f.rate} onChangeText={(v) => setF({ ...f, rate: v })} keyboardType="decimal-pad" /></View>
        </View>
        {lines.map((l, i) => (
          <View key={i} style={{ borderTopWidth: 1, borderTopColor: C.border, paddingTop: 6, gap: 4 }}>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <View style={{ flexBasis: 130, flexGrow: 1 }}><DateField label="Date" value={l.date} onChange={setL(i, 'date')} quick={false} /></View>
              <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField testID={`lsn-amt-${i}`} label="Amount" value={l.amount} onChange={setL(i, 'amount')} /></View>
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setLines((o) => o.filter((_, j) => j !== i))} />
            </View>
            <Field label="What it says" value={l.text} onChangeText={setL(i, 'text')} />
            <Chips value={l.kind} onChange={setL(i, 'kind')} testIDPrefix={`lsn-k-${i}`} options={KIND_OPTS} />
          </View>
        ))}
        <Btn testID="lsn-add" title="+ Add a line" size="sm" variant="secondary" onPress={() => setLines((o) => o.concat([{ date: f.periodTo || dateStr(), text: '', kind: 'repayment', amount: '', balance: '' }]))} />
      </Card>
    </Screen>
  );
}
export function LoanStatementMatchScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [tick, setTick] = useState({});
  let m = null; let err = null;
  try { m = L.matchStatement(params.sUid); } catch (e) { err = e.message; }
  if (!m) return <Screen title="Statement"><Hint>{err || 'Not found.'}</Hint></Screen>;
  const st = m.statement;
  const open = st.status === 'open';
  const todo = m.lines.filter((l) => ['add', 'replace_auto', 'missing_payment'].includes(l.state));
  const apply = () => {
    try {
      const keys = Object.keys(tick).filter((k) => tick[k]);
      const r = L.applyStatement(user, st.uid, keys);
      ui.alert({ title: 'Statement matched', message: `${r.done.length} change(s) made.${r.check ? (r.check.status === 'agreed' ? ' The balance now agrees with the lender.' : ` The balance still differs by ${$(r.check.diff)} – see the loan.`) : ''}` });
      nav.back();
    } catch (e) { ui.error(e); }
  };
  const TONE = { matched: C.success, add: C.warn, replace_auto: C.warn, missing_payment: C.danger, skip: C.sub };
  return (
    <Screen title="Match the statement" subtitle={`${st.period_from ? `${st.period_from} – ` : ''}${st.period_to}${st.closing_balance !== null ? ` · closing ${$(st.closing_balance)}` : ''}`}
      footer={open ? <Btn testID="lsm-apply" title={`Make the ticked changes (${Object.values(tick).filter(Boolean).length})`} icon="✅" variant="success" onPress={apply} /> : null}>
      {!open ? <Banner tone="success" title="Already matched" message={`${st.applied.length} change(s) were made.`} /> : null}
      <Hint>Green: already in the app. Amber: missing – tick to add it to the loan. Red: a repayment the app does not have (tick to add it to the loan, or record the payment in Invoices & cheques instead).</Hint>
      {m.rateChange && open ? (
        <Card tone="warn">
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`Interest rate on the statement: ${m.rateChange.to}% (the app has ${m.rateChange.from}%)`}</Text>
          <Chips value={!!tick.rate} onChange={(v) => setTick({ ...tick, rate: v })} testIDPrefix="lsm-rate" options={[{ value: true, label: 'Use the new rate' }, { value: false, label: 'Keep the old one' }]} />
        </Card>
      ) : null}
      {m.lines.map((l) => (
        <Card key={l.key}>
          <Text style={{ fontSize: 16, fontWeight: '800', color: TONE[l.state] || C.text }}>{`${l.date} · ${L.STATEMENT_KINDS[l.kind]} · ${$(l.amount)}`}</Text>
          {l.text ? <Text style={{ color: C.sub }}>{l.text}</Text> : null}
          <Text style={{ color: C.text }}>{l.state === 'matched' ? `✓ In the app: ${l.with}` : l.action}</Text>
          {open && ['add', 'replace_auto', 'missing_payment'].includes(l.state) ? <Chips value={!!tick[l.key]} onChange={(v) => setTick({ ...tick, [l.key]: v })} testIDPrefix={`lsm-${l.key}`} options={[{ value: true, label: 'Add it' }, { value: false, label: 'Leave it' }]} /> : null}
        </Card>
      ))}
      {open && todo.length > 1 ? <Btn testID="lsm-all" title="Tick all" size="sm" variant="secondary" onPress={() => setTick(Object.fromEntries(todo.map((l) => [l.key, true]).concat(m.rateChange ? [['rate', true]] : [])))} /> : null}
    </Screen>
  );
}
