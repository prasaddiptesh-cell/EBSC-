// Loans & rent (v3.5). Builds on the regular bills and loans of Invoices & cheques (ap_recurring): each one makes its
// repayment / rent bill (RI-<uid>-<due date>) before it is due and is paid like any other invoice. Here we add:
//   - the extra loan details (price, deposit, amount borrowed, fees, arrears fee rule, interest worked out by the app),
//   - a receipt for every payment (photo required – missing ones are flagged),
//   - the loan journey: every repayment split into interest and principal, the balance after every line, missed
//     payments, a simple chart down to zero and the payoff date,
//   - checking a loan against the lender's statement with one-tap fixes (as loan entries) and the "last checked" date,
//   - the closed shop (V M Pillay) costs as their own whole-business line.
// Personal regular payments (home rent, groceries) are in Owner's money (src/modules/drawings).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { r2, $, getInvoice, getSupplier, listSuppliers, saveSupplier } from '../payables/service.js';
import { getRecurring, listRecurring, saveRecurring, nextDate, FREQ_LABEL } from '../payables/recurring.js';
import { costAreaLabel, CLOSED, OFFICE, areaFor } from '../../services/costAreas.js';
import { lockDate } from '../../services/lock.js';
import { addPhotos } from '../../services/stock.js';
import { needReason, requireSetup } from '../../services/access.js';
import * as A from '../accounting/service.js';

export { $, r2, FREQ_LABEL };
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const days = (a, b) => Math.round((new Date(`${b}T00:00:00`) - new Date(`${a}T00:00:00`)) / 86400000);
const num = (v) => (v === '' || v === null || v === undefined || !Number.isFinite(Number(v)) ? null : Number(v));

export const PURPOSES = { shop_loan: 'Shop loan', car_loan: 'Car loan', other_loan: 'Other loan', rent: 'Shop rent', bill: 'Other regular bill' };
export const ARREARS_RULES = { none: 'No rule – type the fee from the statement', fixed: 'Fixed amount for each missed repayment', pct: '% of the amount in arrears' };
export const ENTRY_LABEL = { interest: 'Interest', fee: 'Fee', adjust_up: 'Correction (+)', adjust_down: 'Correction (−)' };

// ---------------------------------------------------------------- settings
export const LOAN_DEFAULTS = { receiptsFromDays: 90, reconDays: 60 };
export function loanRules() { return { ...LOAN_DEFAULTS, ...(getShared('loan_rules', {}) || {}) }; }
export function saveLoanRules(user, r) {
  requireSetup(user, 'loans_manage');
  const from = Math.round(Number(r.receiptsFromDays));
  const rd = Math.round(Number(r.reconDays));
  need(Number.isFinite(from) && from >= 7 && from <= 730, 'Look back between 7 and 730 days for missing receipts.');
  need(Number.isFinite(rd) && rd >= 7 && rd <= 400, 'Check each loan every 7 to 400 days.');
  const clean = { receiptsFromDays: from, reconDays: rd };
  const before = loanRules();
  setShared('loan_rules', clean);
  audit({ user, action: 'Changed the loans & rent settings', table: 'shared_settings', recordUid: 'loan_rules', before, after: clean });
  return clean;
}

// ---------------------------------------------------------------- the extra details of a regular bill / loan
export function getTerms(uid) {
  const r = getRecurring(uid);
  const t = uid ? db().get('SELECT * FROM regular_terms WHERE uid = ?', [uid]) : null;
  const purpose = t ? t.purpose : r && r.kind === 'loan' ? 'other_loan' : /rent/i.test(`${r ? r.name : ''} ${r ? r.category || '' : ''}`) ? 'rent' : 'bill';
  return {
    uid, purpose, price: t ? t.price : null, deposit: t ? t.deposit : null, principal: t ? t.principal : null, start_fees: t ? t.start_fees : null, term_months: t ? t.term_months : null,
    arrears_rule: t ? t.arrears_rule : 'none', arrears_value: t ? t.arrears_value : null, interest_auto: t ? !!t.interest_auto : false,
    receipt_required: t ? !!t.receipt_required : true, recon_days: t ? t.recon_days : loanRules().reconDays, vehicle: t ? t.vehicle : null, template: t ? t.template : null, notes: t ? t.notes : null, saved: !!t,
  };
}
export function saveTerms(user, uid, f = {}) {
  const r = getRecurring(uid);
  need(r, 'Save the bill or loan first.');
  const loan = r.kind === 'loan';
  const purpose = PURPOSES[f.purpose] ? f.purpose : loan ? 'other_loan' : 'bill';
  need(loan === ['shop_loan', 'car_loan', 'other_loan'].includes(purpose), loan ? 'Choose what kind of loan it is.' : 'Choose what kind of bill it is.');
  const rule = ARREARS_RULES[f.arrearsRule] ? f.arrearsRule : 'none';
  const rv = num(f.arrearsValue);
  if (rule !== 'none') need(rv !== null && rv > 0, rule === 'pct' ? 'Enter the arrears fee %.' : 'Enter the arrears fee amount.');
  if (rule === 'pct') need(rv <= 100, 'The arrears fee % must be 100 or less.');
  const money = (v, label) => { const x = num(v); need(x === null || x >= 0, `${label} cannot be below zero.`); return x === null ? null : r2(x); };
  const price = money(f.price, 'The price'); const deposit = money(f.deposit, 'The deposit'); const fees = money(f.startFees, 'The fees');
  let principal = money(f.principal, 'The amount borrowed');
  if (principal === null && price !== null) principal = r2(price - (deposit || 0) + (fees || 0));
  if (price !== null && deposit !== null) need(deposit <= price, 'The deposit cannot be more than the price.');
  const term = num(f.termMonths);
  need(term === null || (term > 0 && term <= 600), 'The loan term must be between 1 and 600 months.');
  const rd = num(f.reconDays) === null ? loanRules().reconDays : Math.round(num(f.reconDays));
  need(rd >= 7 && rd <= 400, 'Check against the statement every 7 to 400 days.');
  const auto = !!f.interestAuto;
  if (auto) need(Number(r.interest_rate) > 0, 'Enter the interest rate first, so the app can work out the interest.');
  const before = db().get('SELECT * FROM regular_terms WHERE uid = ?', [uid]);
  const vals = [purpose, loan ? price : null, loan ? deposit : null, loan ? principal : null, loan ? fees : null, loan && term ? Math.round(term) : null, loan ? rule : 'none', loan && rule !== 'none' ? rv : null,
    loan && auto ? 1 : 0, f.receiptRequired === false ? 0 : 1, rd, txt(f.vehicle) || null, txt(f.template) || (before ? before.template : null), txt(f.termsNotes) || null, stamp(), deviceId(), uid];
  db().run(`INSERT INTO regular_terms (purpose, price, deposit, principal, start_fees, term_months, arrears_rule, arrears_value, interest_auto, receipt_required, recon_days, vehicle, template, notes, updated_at, updated_device, uid)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET purpose=excluded.purpose, price=excluded.price, deposit=excluded.deposit, principal=excluded.principal, start_fees=excluded.start_fees,
    term_months=excluded.term_months, arrears_rule=excluded.arrears_rule, arrears_value=excluded.arrears_value, interest_auto=excluded.interest_auto, receipt_required=excluded.receipt_required,
    recon_days=excluded.recon_days, vehicle=excluded.vehicle, template=excluded.template, notes=excluded.notes, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`, vals);
  audit({ user, action: `${before ? 'Changed' : 'Added'} details of ${r.name}`, table: 'regular_terms', recordUid: uid, before, after: { purpose, price, deposit, principal, rule, rv, auto } });
  return getTerms(uid);
}
// Save the bill / loan (Invoices & cheques' regular bill) and its extra details together.
export function saveRegular(user, f) {
  let rec = null;
  db().transaction(() => {
    rec = saveRecurring(user, f);
    saveTerms(user, rec.uid, f);
  });
  return rec;
}

// The lender / landlord: pick one of the suppliers, or add it by name in one step.
export function ensureLender(user, name) {
  const n = txt(name);
  need(n, 'Type the name of the lender or landlord.');
  const have = listSuppliers({ includeInactive: true }).find((s) => s.name.toLowerCase() === n.toLowerCase());
  if (have) return have;
  return saveSupplier(user, { name: n, onAccount: true, payMethod: 'transfer', category: 'Loans & rent' });
}

// ---------------------------------------------------------------- easy setup: the usual ones for Easy Buys (nothing real is filled in)
export const SETUP_ITEMS = [
  { key: 'loan_s1', kind: 'loan', purpose: 'shop_loan', name: 'Shop 1 Drasa Avenue – business loan', shopCode: 'S1' },
  { key: 'loan_s2', kind: 'loan', purpose: 'shop_loan', name: 'Shop 2 Tukani Street (Kiran Palace) – business loan', shopCode: 'S2' },
  { key: 'loan_vmp', kind: 'loan', purpose: 'shop_loan', name: 'V M Pillay (closed shop) – business loan', shopCode: CLOSED },
  { key: 'car_pb113', kind: 'loan', purpose: 'car_loan', name: 'Car loan PB 113 – Credit Corp', shopCode: '', vehicle: 'PB 113', lender: 'Credit Corp' },
  { key: 'car_on485', kind: 'loan', purpose: 'car_loan', name: 'Car loan ON 485 – BSP', shopCode: '', vehicle: 'ON 485', lender: 'BSP' },
  { key: 'rent_s1', kind: 'bill', purpose: 'rent', name: 'Shop 1 Drasa Avenue – rent', shopCode: 'S1', category: 'Rent' },
  { key: 'rent_s2', kind: 'bill', purpose: 'rent', name: 'Shop 2 Tukani Street (Kiran Palace) – rent', shopCode: 'S2', category: 'Rent' },
  { key: 'rent_vmp', kind: 'bill', purpose: 'rent', name: 'V M Pillay (closed shop) – rent', shopCode: CLOSED, category: 'Rent' },
];
export function setupStatus() {
  const used = new Set(db().all('SELECT t.template FROM regular_terms t JOIN ap_recurring r ON r.uid = t.uid WHERE t.template IS NOT NULL').map((x) => x.template));
  return SETUP_ITEMS.map((s) => ({ ...s, done: used.has(s.key), uid: used.has(s.key) ? (db().get('SELECT uid FROM regular_terms WHERE template = ?', [s.key]) || {}).uid : null }));
}

// ---------------------------------------------------------------- loan entries made by the app (fixed ids: never twice, on any device)
function putEntry(user, { uid, recurringUid, type, amount, date, note }) {
  need(['interest', 'fee', 'adjust_up', 'adjust_down'].includes(type), 'Choose the type.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(DATE.test(txt(date)), 'Enter the date.');
  const l = lockDate();
  need(!l || date > l, `The books are closed up to ${l}. Use a later date, or ask the owner to reopen the month.`);
  if (db().get('SELECT 1 AS x FROM loan_entries WHERE uid = ?', [uid])) return false;
  db().run(`INSERT INTO loan_entries (uid, recurring_uid, entry_date, type, amount, note, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)`,
    [uid, recurringUid, date, type, a, txt(note) || null, user ? user.name : 'Easy Buys app', stamp(), deviceId()]);
  audit({ user, action: `Loan entry: ${ENTRY_LABEL[type]} ${$(a)}${note ? ` – ${txt(note)}` : ''}`, table: 'loan_entries', recordUid: uid, reason: note });
  return true;
}
// A loan entry typed by a person (interest / fee / correction from the statement).
export function addEntry(user, { recurringUid, type, amount, date, note }) {
  const r = getRecurring(recurringUid);
  need(r && r.kind === 'loan', 'Loan not found.');
  if (String(type).startsWith('adjust')) needReason(user, note, 'A correction needs a reason.');
  const uid = uuid('LE');
  putEntry(user, { uid, recurringUid, type, amount, date, note });
  return uid;
}
// Put aside a loan entry (wrong amount): kept with the reason, no longer counted.
export function voidEntry(user, uid, reason) {
  const e = db().get('SELECT * FROM loan_entries WHERE uid = ?', [uid]);
  need(e && e.status === 'active', 'Not found.');
  const l = lockDate();
  need(!l || e.entry_date > l, `The books are closed up to ${l}.`);
  needReason(user, reason, 'Say why it is wrong.');
  db().run(`UPDATE loan_entries SET status = 'void', note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [`${e.note ? `${e.note} · ` : ''}put aside${txt(reason) ? `: ${txt(reason)}` : ''}`, stamp(), deviceId(), uid]);
  audit({ user, action: `Put aside loan entry ${ENTRY_LABEL[e.type]} ${$(e.amount)}`, table: 'loan_entries', recordUid: uid, before: e, reason });
}

// ---------------------------------------------------------------- payments, receipts
const isLoanEntry = (t) => ['interest', 'fee', 'adjust_up', 'adjust_down'].includes(t);
function regularInvoices(uid) {
  return db().all("SELECT uid FROM ap_invoices WHERE uid LIKE ? AND status <> 'void' ORDER BY due_date", [`RI-${uid}-%`]).map((x) => getInvoice(x.uid));
}
function regularPayments(uid) {
  return db().all(`SELECT p.uid AS payment_uid, p.pay_date, p.method, p.cheque_no, p.reference, p.photo_urls, a.amount, a.invoice_uid, i.invoice_no, i.due_date
    FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' JOIN ap_invoices i ON i.uid = a.invoice_uid
    WHERE i.uid LIKE ? AND i.status <> 'void' ORDER BY p.pay_date, i.due_date`, [`RI-${uid}-%`]);
}
export function listReceipts(recurringUid, { all = false } = {}) {
  return db().all(`SELECT * FROM regular_receipts WHERE recurring_uid = ? ${all ? '' : "AND status = 'active'"} ORDER BY receipt_date DESC, created_at DESC`, [recurringUid])
    .map((r) => ({ ...r, photos: J(r.photo_urls, []) }));
}
function receiptFor(p, receipts) {
  const own = receipts.find((x) => x.payment_uid === p.payment_uid && (!x.invoice_uid || x.invoice_uid === p.invoice_uid)) || receipts.find((x) => !x.payment_uid && x.invoice_uid === p.invoice_uid);
  const payPhotos = J(p.photo_urls, []);
  return { receipt: own || null, receiptNo: own ? own.receipt_no || '' : '', hasPhoto: !!((own && own.photos.length) || payPhotos.length) };
}
// Every payment of this bill / loan with its receipt (if any).
export function paymentsWithReceipts(recurringUid) {
  const receipts = listReceipts(recurringUid);
  return regularPayments(recurringUid).map((p) => ({ ...p, ...receiptFor(p, receipts) }));
}
export function addReceipt(user, { recurringUid, paymentUid, invoiceUid, receiptNo, date, amount, photos = [], note }) {
  const r = getRecurring(recurringUid);
  need(r, 'Choose the bill or loan.');
  need((photos || []).length, 'Take a photo of the receipt (it is required).');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the receipt date.');
  if (paymentUid) need(db().get("SELECT 1 AS x FROM ap_payments WHERE uid = ? AND status = 'active'", [paymentUid]), 'That payment is not found.');
  const uid = uuid('RR');
  const now = stamp();
  db().run(`INSERT INTO regular_receipts (uid, recurring_uid, invoice_uid, payment_uid, receipt_no, receipt_date, amount, photo_urls, note, status, by_name, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?, 'active', ?,?,?,?)`, [uid, recurringUid, invoiceUid || null, paymentUid || null, txt(receiptNo) || null, d, num(amount) === null ? null : r2(amount), JSON.stringify(photos), txt(note) || null,
    user.name, now, now, deviceId()]);
  addPhotos('regreceipt', uid, photos);
  audit({ user, action: `Receipt ${txt(receiptNo) || ''} for ${r.name}`.replace('  ', ' '), table: 'regular_receipts', recordUid: uid });
  return uid;
}
export function voidReceipt(user, uid, reason) {
  const x = db().get('SELECT * FROM regular_receipts WHERE uid = ?', [uid]);
  need(x && x.status === 'active', 'Not found.');
  needReason(user, reason, 'Say why.');
  db().run(`UPDATE regular_receipts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || null, stamp(), deviceId(), uid]);
  audit({ user, action: 'Put aside a receipt', table: 'regular_receipts', recordUid: uid, before: x, reason });
}
// Payments of loans and rent (and other regular bills that need one) in the last few days without a receipt photo.
export function missingReceipts(today = dateStr()) {
  const from = addDays(today, -loanRules().receiptsFromDays);
  const out = [];
  for (const r of listRecurring({ includeInactive: true })) {
    if (!getTerms(r.uid).receipt_required) continue;
    for (const p of paymentsWithReceipts(r.uid)) {
      if (p.pay_date < from || p.hasPhoto) continue;
      out.push({ ...p, recurring_uid: r.uid, name: r.name, kind: r.kind });
    }
  }
  return out.sort((a, b) => (a.pay_date < b.pay_date ? 1 : -1));
}

// ---------------------------------------------------------------- the loan journey
// Opening balance + interest + fees ± corrections − repayments actually paid, line by line, oldest first. Each
// repayment is split into the interest (and fees) charged since the last repayment, and the principal.
export function loanJourney(uid, today = dateStr()) {
  const r = getRecurring(uid);
  if (!r || r.kind !== 'loan') return null;
  const t = getTerms(uid);
  const start = r.opening_date || '0000-01-01';
  const events = [];
  for (const e of db().all("SELECT * FROM loan_entries WHERE recurring_uid = ? AND status = 'active' AND entry_date >= ?", [uid, start])) {
    if (!isLoanEntry(e.type)) continue;
    events.push({ date: e.entry_date, order: 0, kind: e.type, uid: e.uid, amount: r2(e.amount), note: e.note || '', auto: /^L[IAR]-/.test(e.uid) });
  }
  const pays = paymentsWithReceipts(uid).filter((p) => p.pay_date >= start);
  pays.forEach((p) => events.push({ date: p.pay_date, order: 1, kind: 'payment', amount: r2(p.amount), p }));
  events.sort((a, b) => (a.date === b.date ? a.order - b.order : a.date < b.date ? -1 : 1));
  let bal = r2(r.opening_balance || 0);
  const lines = [];
  if (t.price !== null) lines.push({ date: start, kind: 'info', what: `Price${t.vehicle ? ` (${t.vehicle})` : ''}`, amount: t.price, balance: null });
  if (t.deposit !== null) lines.push({ date: start, kind: 'info', what: 'Deposit paid', amount: t.deposit, balance: null });
  if (t.start_fees !== null) lines.push({ date: start, kind: 'info', what: 'Fees added at the start', amount: t.start_fees, balance: null });
  if (t.principal !== null) lines.push({ date: start, kind: 'info', what: 'Amount borrowed', amount: t.principal, balance: null });
  lines.push({ date: start, kind: 'start', what: 'Balance owing at the start', amount: null, balance: bal });
  let pendInt = 0; let pendFee = 0;
  const tot = { paid: 0, interest: 0, fees: 0, principal: 0, interestPaid: 0, feesPaid: 0, adjust: 0, payments: 0 };
  for (const e of events) {
    if (e.kind === 'payment') {
      const ip = Math.min(e.amount, r2(pendInt));
      const fp = Math.min(r2(e.amount - ip), r2(pendFee));
      const pp = r2(e.amount - ip - fp);
      pendInt = r2(pendInt - ip); pendFee = r2(pendFee - fp);
      bal = r2(bal - e.amount);
      tot.paid = r2(tot.paid + e.amount); tot.principal = r2(tot.principal + pp); tot.interestPaid = r2(tot.interestPaid + ip); tot.feesPaid = r2(tot.feesPaid + fp); tot.payments += 1;
      const p = e.p;
      const flags = [];
      if (p.pay_date > p.due_date) flags.push(`late (due ${p.due_date})`);
      if (!p.hasPhoto) flags.push('no receipt photo');
      lines.push({ date: e.date, kind: 'payment', what: `Repayment (${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}${p.reference ? ` ${p.reference}` : ''})`, amount: e.amount, interest: ip, fees: fp, principal: pp,
        balance: bal, ref: p.invoice_no || '', receiptNo: p.receiptNo, hasPhoto: p.hasPhoto, paymentUid: p.payment_uid, invoiceUid: p.invoice_uid, late: p.pay_date > p.due_date, flags });
    } else {
      const up = e.kind !== 'adjust_down';
      bal = r2(bal + (up ? e.amount : -e.amount));
      if (e.kind === 'interest') { pendInt = r2(pendInt + e.amount); tot.interest = r2(tot.interest + e.amount); }
      if (e.kind === 'fee') { pendFee = r2(pendFee + e.amount); tot.fees = r2(tot.fees + e.amount); }
      if (e.kind.startsWith('adjust')) tot.adjust = r2(tot.adjust + (up ? e.amount : -e.amount));
      lines.push({ date: e.date, kind: e.kind, uid: e.uid, what: `${ENTRY_LABEL[e.kind]}${e.note ? ` – ${e.note}` : ''}${e.auto && e.uid.startsWith('LI-') ? ' (worked out by the app)' : ''}`, amount: e.amount, balance: bal, flags: [] });
    }
  }
  // Repayments missed (bill overdue, not fully paid) and the ones coming up.
  const invs = regularInvoices(uid);
  const missed = invs.filter((i) => i.due === 'overdue' && i.owing > 0.004);
  missed.forEach((i) => lines.push({ date: i.due_date, kind: 'missed', what: `MISSED repayment${i.partPaid ? ' (part paid)' : ''} – ${$(i.owing)} not paid`, amount: i.owing, balance: null, ref: i.invoice_no || '', invoiceUid: i.uid, flags: ['missed'] }));
  lines.sort((a, b) => (a.date === b.date ? 0 : a.date < b.date ? -1 : 1));
  const arrears = r2(missed.reduce((s, i) => s + i.owing, 0));
  let suggestedFee = 0;
  if (missed.length && t.arrears_rule === 'fixed') suggestedFee = r2(Number(t.arrears_value) * missed.length);
  if (missed.length && t.arrears_rule === 'pct') suggestedFee = r2((arrears * Number(t.arrears_value)) / 100);
  const upcoming = invs.filter((i) => i.owing > 0.004 && i.due !== 'overdue');
  const nextDue = upcoming.length ? upcoming[0].due_date : r.active ? r.next_date : null;
  const plan = projection({ balance: bal, rate: Number(r.interest_rate) || 0, repayment: Number(r.amount), frequency: r.frequency, anchor: r.anchor_day, from: nextDue || today, active: !!r.active });
  const recon = lastRecon(uid);
  return {
    loan: r, terms: t, lines, balance: bal, totals: tot, missed, arrears, suggestedFee, nextDue, upcoming, plan,
    payoffDate: plan.payoff, neverPaysOff: plan.never, lastReconciled: recon ? recon.statement_date : null,
    reconDue: !!r.active && days(recon ? recon.statement_date : start, today) > (t.recon_days || loanRules().reconDays),
    area: r.shop_code || OFFICE, areaLabel: costAreaLabel(areaFor(r.shop_code)),
    chart: chartPoints(lines.filter((l) => l.balance !== null && l.balance !== undefined).map((l) => ({ date: l.date, balance: l.balance })), plan.points),
  };
}
// From the balance now: the coming repayments until it reaches zero (a guide from the rate and the repayment).
export function projection({ balance, rate, repayment, frequency, anchor, from, active = true, max = 600 }) {
  const points = [];
  let bal = r2(balance);
  if (!active || bal <= 0.004 || !(repayment > 0) || !FREQ_LABEL[frequency]) return { points, payoff: bal <= 0.004 ? from : null, never: false, payments: 0 };
  let d = from;
  let prev = from;
  for (let k = 0; k < max && bal > 0.004; k += 1) {
    const span = k === 0 ? ({ weekly: 7, fortnightly: 14, monthly: 30.4167, quarterly: 91.25, yearly: 365 }[frequency]) : days(prev, d);
    const interest = r2((bal * rate * span) / 36500);
    if (repayment <= interest) return { points, payoff: null, never: true, payments: k };
    const pay = Math.min(r2(repayment), r2(bal + interest));
    bal = r2(bal + interest - pay);
    points.push({ date: d, balance: bal, payment: pay, interest, principal: r2(pay - interest) });
    prev = d;
    d = nextDate(d, frequency, anchor);
  }
  return { points, payoff: bal <= 0.004 && points.length ? points[points.length - 1].date : null, never: bal > 0.004, payments: points.length };
}
// At most ~24 bars for the simple chart: the balance so far, then the plan.
function chartPoints(actual, plan) {
  const pick = (list, n) => { if (list.length <= n) return list; const out = []; for (let i = 0; i < n; i += 1) out.push(list[Math.round((i * (list.length - 1)) / (n - 1))]); return out; };
  return pick(actual, 12).map((p) => ({ ...p, planned: false })).concat(pick(plan, 12).map((p) => ({ date: p.date, balance: p.balance, planned: true })));
}

// Interest worked out by the app (loans set to "the app works out the interest"): on each repayment due date, the
// balance since the last due date × the yearly rate × the days. Safe to run any number of times, on any device.
export function runLoanInterest(user, today = dateStr()) {
  let made = 0;
  const lock = lockDate();
  for (const r of listRecurring({ kind: 'loan' })) {
    const t = getTerms(r.uid);
    if (!t.interest_auto || !(Number(r.interest_rate) > 0)) continue;
    const dues = regularInvoices(r.uid).map((i) => i.due_date).filter((d) => d <= today && d > (r.opening_date || '')).sort();
    let prev = r.opening_date;
    for (const d of dues) {
      const id = `LI-${r.uid}-${d}`;
      if (!db().get('SELECT 1 AS x FROM loan_entries WHERE uid = ?', [id]) && !(lock && d <= lock)) {
        const j = loanJourney(r.uid, today);
        const balPrev = balanceOn(j, prev);
        const interest = r2((balPrev * Number(r.interest_rate) * days(prev, d)) / 36500);
        if (interest > 0 && putEntry(user, { uid: id, recurringUid: r.uid, type: 'interest', amount: interest, date: d, note: `${r.interest_rate}% a year on ${$(balPrev)}, ${days(prev, d)} days` })) made += 1;
      }
      prev = d;
    }
  }
  return made;
}
function balanceOn(j, date) {
  let b = r2(j.loan.opening_balance || 0);
  for (const l of j.lines) if (l.date <= date && l.balance !== null && l.balance !== undefined) b = l.balance;
  return b;
}
// The arrears fee by the loan's rule (one tap). One fee per loan per day.
export function addArrearsFee(user, uid, { amount, date = dateStr(), note } = {}) {
  const j = loanJourney(uid, date);
  need(j, 'Loan not found.');
  const a = r2(amount === undefined || amount === '' ? j.suggestedFee : amount);
  need(a > 0, 'Enter the arrears fee (from the lender statement).');
  const ok = putEntry(user, { uid: `LA-${uid}-${date}`, recurringUid: uid, type: 'fee', amount: a, date, note: txt(note) || `Arrears fee – ${j.missed.length} repayment(s) missed, ${$(j.arrears)} in arrears` });
  need(ok, 'An arrears fee is already recorded for this loan today.');
  return a;
}

// ---------------------------------------------------------------- check against the lender's statement
export function lastRecon(uid, { agreedOnly = true } = {}) {
  return db().get(`SELECT * FROM loan_recons WHERE recurring_uid = ? AND status ${agreedOnly ? "= 'agreed'" : "<> 'void'"} ORDER BY statement_date DESC, created_at DESC LIMIT 1`, [uid]) || null;
}
export function listRecons(uid) {
  return db().all("SELECT * FROM loan_recons WHERE recurring_uid = ? ORDER BY statement_date DESC, created_at DESC", [uid]).map((x) => ({ ...x, fixes: J(x.fixes, []) }));
}
// Ours on the statement date: the balance, and the interest and fees between the two dates.
function ours(uid, from, to) {
  const j = loanJourney(uid, to);
  const inRange = (l) => l.date >= from && l.date <= to;
  return {
    balance: balanceOn(j, to),
    interest: r2(j.lines.filter((l) => l.kind === 'interest' && inRange(l)).reduce((s, l) => s + l.amount, 0)),
    fees: r2(j.lines.filter((l) => l.kind === 'fee' && inRange(l)).reduce((s, l) => s + l.amount, 0)),
  };
}
export function reconCompare(uid, { statementDate, periodFrom, balance, interest, fees }) {
  const r = getRecurring(uid);
  need(r && r.kind === 'loan', 'Loan not found.');
  const d = txt(statementDate);
  need(DATE.test(d), 'Enter the date of the lender statement.');
  need(num(balance) !== null, 'Enter the balance on the lender statement.');
  const prev = lastRecon(uid);
  const from = txt(periodFrom) || (prev && prev.statement_date < d ? addDays(prev.statement_date, 1) : r.opening_date || d);
  need(DATE.test(from) && from <= d, 'The statement start date must be before its end date.');
  const o = ours(uid, from, d);
  const their = { balance: r2(balance), interest: num(interest) === null ? null : r2(interest), fees: num(fees) === null ? null : r2(fees) };
  const dInt = their.interest === null ? 0 : r2(their.interest - o.interest);
  const dFee = their.fees === null ? 0 : r2(their.fees - o.fees);
  const dBal = r2(their.balance - o.balance);
  const fixes = [];
  if (Math.abs(dInt) >= 0.005) fixes.push({ key: 'interest', type: dInt > 0 ? 'interest' : 'adjust_down', amount: Math.abs(dInt), note: dInt > 0 ? 'Interest from the lender statement' : 'Interest correction (statement shows less)', text: dInt > 0 ? `Add interest ${$(dInt)}` : `Take off interest ${$(-dInt)}` });
  if (Math.abs(dFee) >= 0.005) fixes.push({ key: 'fees', type: dFee > 0 ? 'fee' : 'adjust_down', amount: Math.abs(dFee), note: dFee > 0 ? 'Fees from the lender statement' : 'Fee correction (statement shows less)', text: dFee > 0 ? `Add fees ${$(dFee)}` : `Take off fees ${$(-dFee)}` });
  const rest = r2(dBal - dInt - dFee);
  if (Math.abs(rest) >= 0.005) {
    fixes.push({ key: 'balance', type: rest > 0 ? 'adjust_up' : 'adjust_down', amount: Math.abs(rest), note: 'Balance correction to agree with the lender statement',
      text: rest > 0 ? `Add ${$(rest)} to the balance` : `Take ${$(-rest)} off the balance`,
      hint: rest < 0 ? 'First check that every repayment is recorded (Invoices & cheques › Payments made). If one is missing, record it there instead.' : 'Maybe a fee or interest is missing from the statement figures you typed.' });
  }
  return { loan: r, from, to: d, their, ours: o, diff: dBal, diffInterest: dInt, diffFees: dFee, fixes, agrees: Math.abs(dBal) < 0.005 && !fixes.length };
}
// Save the check. `apply`: the keys of the fixes to make (as loan entries dated on the statement date).
export function saveRecon(user, uid, input, { apply = [], note } = {}) {
  const c = reconCompare(uid, input);
  const recUid = uuid('LR');
  const done = [];
  db().transaction(() => {
    for (const f of c.fixes.filter((x) => apply.includes(x.key))) {
      putEntry(user, { uid: `LR-${recUid}-${f.key}`, recurringUid: uid, type: f.type, amount: f.amount, date: c.to, note: f.note });
      done.push({ key: f.key, type: f.type, amount: f.amount });
    }
    const after = ours(uid, c.from, c.to);
    const diff = r2(c.their.balance - after.balance);
    const now = stamp();
    db().run(`INSERT INTO loan_recons (uid, recurring_uid, statement_date, period_from, their_balance, their_interest, their_fees, our_balance, our_interest, our_fees, diff, fixes, status, note, by_name, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [recUid, uid, c.to, c.from, c.their.balance, c.their.interest, c.their.fees, after.balance, after.interest, after.fees, diff, JSON.stringify(done),
      Math.abs(diff) < 0.005 ? 'agreed' : 'open', txt(note) || null, user.name, now, now, deviceId()]);
  });
  const rec = db().get('SELECT * FROM loan_recons WHERE uid = ?', [recUid]);
  audit({ user, action: `Checked ${c.loan.name} against the lender statement of ${c.to}: ${rec.status === 'agreed' ? 'agrees' : `differs by ${$(rec.diff)}`}`, table: 'loan_recons', recordUid: recUid, after: { fixes: done } });
  return { ...rec, fixes: done };
}
export function voidRecon(user, uid, reason) {
  const x = db().get('SELECT * FROM loan_recons WHERE uid = ?', [uid]);
  need(x && x.status !== 'void', 'Not found.');
  needReason(user, reason, 'Say why.');
  db().run(`UPDATE loan_recons SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || null, stamp(), deviceId(), uid]);
  audit({ user, action: 'Put aside a loan statement check (its fixes stay; put them aside on the loan if needed)', table: 'loan_recons', recordUid: uid, before: x, reason });
}

// ---------------------------------------------------------------- overview of loans and rent
export function regularOverview(today = dateStr()) {
  const rows = listRecurring({ includeInactive: true }).map((r) => {
    const t = getTerms(r.uid);
    const invs = regularInvoices(r.uid);
    const open = invs.filter((i) => i.owing > 0.004);
    const overdue = open.filter((i) => i.due === 'overdue');
    const pays = paymentsWithReceipts(r.uid);
    const from = addDays(today, -loanRules().receiptsFromDays);
    const noReceipt = t.receipt_required ? pays.filter((p) => p.pay_date >= from && !p.hasPhoto).length : 0;
    const j = r.kind === 'loan' ? loanJourney(r.uid, today) : null;
    const due = open.length ? open[0].due_date : r.active ? r.next_date : null;
    const dueIn = due ? days(today, due) : null;
    return {
      uid: r.uid, kind: r.kind, name: r.name, purpose: t.purpose, purposeLabel: PURPOSES[t.purpose], lender: r.supplier_name, amount: r.amount, frequency: r.frequency, active: !!r.active,
      area: r.shop_code || OFFICE, areaLabel: costAreaLabel(areaFor(r.shop_code)), closed: areaFor(r.shop_code) === CLOSED, nextDue: due, dueIn, owing: r2(open.reduce((s, i) => s + i.owing, 0)),
      overdue: overdue.length, overdueAmount: r2(overdue.reduce((s, i) => s + i.owing, 0)), lastPaid: pays.length ? pays[pays.length - 1].pay_date : null, noReceipt, leadDays: r.lead_days,
      balance: j ? j.balance : null, payoffDate: j ? j.payoffDate : null, lastReconciled: j ? j.lastReconciled : null, reconDue: j ? j.reconDue : false, suggestedFee: j ? j.suggestedFee : 0,
    };
  });
  const order = ['shop_loan', 'car_loan', 'other_loan', 'rent', 'bill'];
  return rows.sort((a, b) => (a.active !== b.active ? (a.active ? -1 : 1) : order.indexOf(a.purpose) - order.indexOf(b.purpose) || (a.name < b.name ? -1 : 1)));
}

// ---------------------------------------------------------------- closed shop costs (whole-business line)
// Every cost booked to the closed V M Pillay shop (rent, loan interest and fees, power…) in a period.
export function closedShopCosts({ from, to }) {
  const accts = Object.fromEntries(A.listAccountsGL({ includeInactive: true }).map((a) => [a.code, a]));
  const lines = [];
  for (const e of A.entries({ from, to })) {
    for (const l of e.lines) {
      if (areaFor(l.shop) !== CLOSED) continue;
      const a = accts[l.code];
      if (!a || !['expense', 'cogs', 'income'].includes(a.type)) continue;
      lines.push({ date: e.date, src: e.src, text: e.text, code: l.code, account: a.name, amount: r2(l.amount) }); // a cost is positive, income takes off
    }
  }
  const byAccount = {};
  lines.forEach((l) => { byAccount[l.account] = r2((byAccount[l.account] || 0) + l.amount); });
  return { lines, byAccount, total: r2(lines.reduce((s, l) => s + l.amount, 0)) };
}
export { getRecurring, getSupplier, listSuppliers };
