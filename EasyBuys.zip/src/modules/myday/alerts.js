// Warnings for Home: the next item of My day (a reminder with sound) and tasks that will miss their deadline (urgent).
import { mydayAlerts } from './service.js';

export function alerts(user) {
  return mydayAlerts(user);
}
