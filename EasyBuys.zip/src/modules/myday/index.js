// My day (owner & admin): the day's timeline of app tasks, meetings and errands. Managers see business tasks
// read-only; staff see busy / free.
import { MyDayScreen, TheirDayScreen, MyDayItemScreen, MyDayItemsScreen, MyDaySettingsScreen } from './screens/MyDayScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

const plans = (u) => can(u, 'myday');
export default {
  id: 'myday',
  title: 'My day',
  icon: '🗓️',
  switchable: true,
  screens: {
    MyDay: { component: MyDayScreen, can: plans },
    TheirDay: { component: TheirDayScreen, can: (u) => !!u },
    MyDayItem: { component: MyDayItemScreen, can: plans },
    MyDayItems: { component: MyDayItemsScreen, can: plans },
    MyDaySettings: { component: MyDaySettingsScreen, can: plans },
  },
  menu: MENU,
  alerts,
  reports: [],
};
