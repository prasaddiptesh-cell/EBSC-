// My day menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🗓️', title: 'My day', note: 'Tasks, meetings and errands placed in your working hours, before their deadlines.', screen: 'MyDay', perm: 'myday' },
    { id: 'md-add', icon: '➕', title: 'Add a meeting or errand', screen: 'MyDayItem', perm: 'myday' },
    { id: 'md-their', icon: '👀', title: "Owner's day (busy / free)", note: 'Managers see business tasks; others see busy or free.', screen: 'TheirDay' },
  ] },
  { section: 'Records', items: [
    { id: 'md-items', icon: '📋', title: 'My meetings & errands', note: 'Own items and repeating ones.', screen: 'MyDayItems', perm: 'myday' },
  ] },
  { section: 'Settings', items: [
    { id: 'md-settings', icon: '⚙️', title: 'My day settings', note: 'Working hours for each day, task times, Google Calendar.', screen: 'MyDaySettings', perm: 'myday' },
  ] },
];
