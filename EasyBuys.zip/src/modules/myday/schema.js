// My day: the owner's / admin's own items (meetings, errands, repeating) and what happened to each task on a day
// (done, skipped, not today, moved). Both are shared between the owner's devices.
export const MYDAY_SQL = `
CREATE TABLE IF NOT EXISTS myday_items (
  uid TEXT PRIMARY KEY,
  owner_uid TEXT NOT NULL,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'errand',
  the_date TEXT NOT NULL,
  start_time TEXT,
  minutes INTEGER NOT NULL DEFAULT 30,
  fixed INTEGER NOT NULL DEFAULT 0,
  repeat TEXT NOT NULL DEFAULT 'none',
  repeat_days TEXT,
  until_date TEXT,
  deadline TEXT,
  private INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  ext_id TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_mdi_owner ON myday_items(owner_uid, the_date);
CREATE TABLE IF NOT EXISTS myday_marks (
  uid TEXT PRIMARY KEY,
  owner_uid TEXT NOT NULL,
  day TEXT NOT NULL,
  task_key TEXT NOT NULL,
  title TEXT,
  state TEXT,
  opened_at TEXT,
  pin_time TEXT,
  order_no INTEGER,
  by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_mdm_day ON myday_marks(owner_uid, day);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const MYDAY_SYNC = {
  myday_items: SYNC('uid', 'My day', ['uid', 'owner_uid', 'title', 'kind', 'the_date', 'start_time', 'minutes', 'fixed', 'repeat', 'repeat_days', 'until_date', 'deadline', 'private', 'note', 'ext_id', 'status', 'by_name']),
  myday_marks: SYNC('uid', 'My day', ['uid', 'owner_uid', 'day', 'task_key', 'title', 'state', 'opened_at', 'pin_time', 'order_no', 'by_name']),
};
