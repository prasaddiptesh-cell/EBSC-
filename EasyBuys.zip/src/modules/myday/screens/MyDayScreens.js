// My day screens: the day timeline, own items (meetings, errands, repeating), settings, and someone else's day.
import React, { useState, useEffect } from 'react';
import { View, Pressable, Modal, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Section, Label, Choice, useApp, useUI, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Stats, Hint, Explain, DateField, TimeField } from '../../../ui/kit.js';
import { nice } from '../../../ui/timePicker.js';
import { dateStr, addDays, dayName } from '../../../services/core.js';
import { can as canDo } from '../../../services/access.js';
import { cloudCall } from '../../../platform/cloud.js';
import * as M from '../service.js';

const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const TCOL = { order: C.brandBlue, approval: C.success, check: C.info, payday: C.success, tax: C.warn, licence: C.primaryDark, monthend: C.primaryDark, watchdog: C.danger, other: C.sub, own: C.primary, google: C.info };
const typeLabel = (b) => (b.app ? `${(M.TYPE[b.type] || M.TYPE.other).icon} ${(M.TYPE[b.type] || M.TYPE.other).label}` : b.kind === 'google' ? '📅 Google Calendar' : b.kind === 'meeting' ? '🤝 Meeting' : b.kind === 'errand' ? '🚗 Errand' : '📝 Own item');
const fmtMins = (m) => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ''}` : `${m} min`);

// ---------------------------------------------------------------- the day (owner/admin edit; others read-only)
function DayView({ params, readOnlyScreen }) {
  const { user, nav } = useApp();
  const act = useAct();
  const ui = useUI();
  useTick(60000);
  const owners = M.planOwners();
  const selfPlans = canDo(user, 'myday') && owners.some((o) => o.uid === user.uid);
  const [owner, setOwner] = useState(params.ownerUid || (selfPlans && !readOnlyScreen ? user.uid : (owners.find((o) => o.role === 'owner') || owners[0] || {}).uid));
  const [day, setDay] = useState(params.date || dateStr());
  const [moving, setMoving] = useState(null); // block being moved to a time
  const [moveTo, setMoveTo] = useState('');
  const [, bump] = useState(0);
  const refresh = () => bump((x) => x + 1);
  useEffect(() => {
    if (owner && owner === user.uid && selfPlans) {
      try { M.requestMeetings(day); } catch (e) { /* offline is fine */ }
      try { if (M.mydaySettings().calendarOut) M.sendDayToCalendar(user, owner, day); } catch (e) { /* later */ }
    }
  }, [owner, day]);
  if (!owner) {
    return <Screen title="My day"><Banner tone="info" title="Nobody has a My day yet" message="My day is for the owner and admin. Add an owner or admin in Staff." /></Screen>;
  }
  const plan = M.viewPlan(user, owner, day, { user });
  const ed = plan.editable;
  const who = owners.find((o) => o.uid === owner);
  const doIt = (fn, ok) => { if (act(fn, ok) !== null) refresh(); };
  const open = (b) => {
    if (!ed && plan.level === 'busy') return;
    if (b.app && b.nav) { if (ed) M.openTask(user, owner, day, b.key, b.title); nav.push(b.nav.screen, b.nav.params || {}); return; }
    if (b.own && ed) nav.push('MyDayItem', { uid: b.item.uid });
  };
  const late = plan.blocks.filter((b) => b.late && !b.past);
  const freeMins = plan.free.reduce((a, f) => a + (f.end - f.start), 0);
  // Timeline rows: blocks with the free gaps between them.
  const rows = [];
  plan.blocks.forEach((b) => rows.push({ t: b.start, b }));
  plan.free.forEach((f) => rows.push({ t: f.start, f }));
  rows.sort((a, b) => a.t - b.t || (a.f ? 1 : -1));
  return (
    <Screen title={readOnlyScreen ? `${who ? who.name : 'Owner'}'s day` : owner === user.uid ? 'My day' : `${who ? who.name : ''}'s day`} subtitle={`${dayName(day)} ${day}${plan.window ? ` · ${nice(plan.hours.start)}–${nice(plan.hours.end)}` : ' · day off'}`}>
      {plan.level === 'full' && !readOnlyScreen ? (
        <Explain title="How My day works">
          The app puts its tasks (orders before the cut-off, approvals, checks, pay day, tax, licences, month end, warnings) into your working hours, before their deadlines.
          Meetings and other fixed items never move. Tasks you have not finished move to the next free time. Red means it will miss its deadline. Tap a task to open its screen –
          it ticks itself off when the job is done.
        </Explain>
      ) : null}
      {plan.level === 'business' ? <Hint>You can see the business tasks (read-only). Private items show as "Busy".</Hint> : null}
      {plan.level === 'busy' ? <Hint>Shows when {who ? who.name : 'they'} {day === dateStr() ? 'is' : 'will be'} busy or free.</Hint> : null}
      {owners.length > 1 ? <Choice label="Whose day" value={owner} onChange={setOwner} options={owners.map((o) => ({ value: o.uid, label: o.uid === user.uid ? `${o.name} (me)` : o.name }))} testIDPrefix="md-owner" /> : null}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
        <Btn testID="md-prev" title="‹ Day" size="sm" variant="secondary" onPress={() => setDay(addDays(day, -1))} />
        <Btn testID="md-today" title="Today" size="sm" variant={day === dateStr() ? 'info' : 'secondary'} onPress={() => setDay(dateStr())} />
        <Btn testID="md-next" title="Day ›" size="sm" variant="secondary" onPress={() => setDay(addDays(day, 1))} />
      </View>
      <DateField label="Day" value={day} onChange={(v) => { if (/^\d{4}-\d{2}-\d{2}$/.test(v)) setDay(v); }} testID="md-date" quick={false} />
      {plan.level !== 'busy' ? (
        <Stats items={[{ label: 'Planned', value: String(plan.blocks.length) }, { label: 'Will be late', value: String(late.length), color: late.length ? C.danger : undefined },
          { label: 'Free time', value: fmtMins(freeMins) }, { label: 'Done', value: String(plan.done.length), color: plan.done.length ? C.success : undefined }]} />
      ) : null}
      {late.length && plan.level !== 'busy' ? <Banner testID="md-late" tone="danger" title={`${late.length} task${late.length === 1 ? '' : 's'} will miss the deadline`} message={late.map((b) => `${b.title}${b.deadlineText ? ` (by ${b.deadlineText})` : ''}`).join('\n')} /> : null}
      {plan.overflow.length && plan.level !== 'busy' ? <Banner tone="warn" title="Not enough time today" message={`${plan.overflow.length} task(s) do not fit in the working hours. Move something to tomorrow ("Not today") or skip it.`} /> : null}
      {ed ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="md-add" title="Meeting or errand" icon="➕" size="md" variant="primary" style={{ flexGrow: 1 }} onPress={() => nav.push('MyDayItem', { date: day, ownerUid: owner })} />
          {plan.settings.calendarIn ? <Btn testID="md-google-in" title="Get meetings from Google" icon="📅" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={async () => {
            try { const r = await cloudCall({ kind: 'myday_events', date: day }); const n = M.applyGoogleEvents((M.calendarOwner() || {}).uid, day, r.events || []); ui.toast(`${n} meeting(s) from Google Calendar`); refresh(); } catch (e) { M.requestMeetings(day, { force: true }); ui.toast('No internet now – the meetings come in at the next sync.', 'warn'); }
          }} /> : null}
          {plan.settings.calendarOut ? <Btn testID="md-google-out" title="Send to Google Calendar" icon="📤" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => doIt(() => { const n = M.sendDayToCalendar(user, owner, day, { force: true }); ui.toast(`${n} task(s) will go to "${M.MYDAY_CALENDAR}" when online`); })} /> : null}
          <Btn testID="md-settings" title="Hours & settings" icon="⚙️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('MyDaySettings', {})} />
        </View>
      ) : null}
      {!plan.blocks.length ? <Card><Text style={{ color: C.sub, fontSize: 17 }}>{plan.window ? 'Nothing planned – the whole day is free.' : 'Day off.'}</Text></Card> : null}
      <View testID="md-timeline" style={{ gap: 6 }}>
        {rows.map((r) => (r.f ? (
          <View key={`f${r.f.start}`} style={{ flexDirection: 'row', gap: 10, alignItems: 'center', opacity: 0.8 }}>
            <Text style={{ width: 64, color: C.sub, fontSize: 14 }}>{nice(r.f.startText)}</Text>
            <Text style={{ flex: 1, color: C.success, fontSize: 15, fontWeight: '700', borderStyle: 'dashed', borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 8 }}>Free {nice(r.f.startText)}–{nice(r.f.endText)} · {fmtMins(r.f.end - r.f.start)}</Text>
          </View>
        ) : (
          <Block key={r.b.key} b={r.b} plan={plan} ed={ed} onOpen={() => open(r.b)}
            onUp={() => doIt(() => M.moveTask(user, owner, day, r.b.key, 'up'))} onDown={() => doIt(() => M.moveTask(user, owner, day, r.b.key, 'down'))}
            onTime={() => { setMoving(r.b); setMoveTo(r.b.startText); }}
            onNotToday={() => doIt(() => { const x = M.notToday(user, owner, day, r.b.key, r.b.title); if (x.moved) ui.toast(`Moved to ${dayName(x.moved)}`); else ui.toast('Not today – it comes back tomorrow'); })}
            onSkip={() => doIt(() => M.skipTask(user, owner, day, r.b.key, r.b.title), 'Skipped')}
            onDone={() => doIt(() => M.doneTask(user, owner, day, r.b.key, r.b.title), 'Done ✓')} />
        )))}
      </View>
      {plan.done.length && plan.level !== 'busy' ? (
        <Section title={`Done (${plan.done.length})`}>
          {plan.done.map((b) => <ListItem key={b.key} testID={`md-done-${b.key}`} title={`✓ ${b.title}`} sub={b.auto || (b.mark && !b.mark.by_name) ? 'Ticked off by itself when the job was done' : b.mark && b.mark.by_name ? `by ${b.mark.by_name}` : ''}
            right={ed ? 'Undo' : ''} onPress={ed ? () => doIt(() => M.undoMark(user, owner, day, b.key)) : undefined} />)}
        </Section>
      ) : null}
      {plan.setAside.length ? (
        <Section title="Not today / skipped">
          {plan.setAside.map((b) => <ListItem key={b.key} title={b.title} sub={b.mark.state === 'skipped' ? 'Skipped' : 'Not today – back tomorrow'} right={ed ? 'Put back' : ''} onPress={ed ? () => doIt(() => M.undoMark(user, owner, day, b.key)) : undefined} />)}
        </Section>
      ) : null}
      {moving ? (
        <Modal visible transparent animationType="fade" onRequestClose={() => setMoving(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 12 }}>
            <View style={{ maxWidth: 520, width: '100%', backgroundColor: C.card, borderRadius: 18, padding: 18, gap: 10 }}>
              <H>Move "{moving.title}"</H>
              <TimeField testID="md-move-time" label="Start at" value={moveTo} onChange={setMoveTo} showNow />
              <Hint>If something fixed is there, it goes to the next free time after it.</Hint>
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                <Btn title="Cancel" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setMoving(null)} />
                {moving.pinned ? <Btn title="Let the app choose" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { doIt(() => M.pinTask(user, owner, day, moving.key, null)); setMoving(null); }} /> : null}
                <Btn testID="md-move-ok" title="Move" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => { doIt(() => M.pinTask(user, owner, day, moving.key, moveTo)); setMoving(null); }} />
              </View>
            </View>
          </View>
        </Modal>
      ) : null}
    </Screen>
  );
}

function Block({ b, plan, ed, onOpen, onUp, onDown, onTime, onNotToday, onSkip, onDone }) {
  const busy = b.busy;
  const col = busy ? C.sub : b.late ? C.danger : TCOL[b.app ? b.type : b.kind === 'google' ? 'google' : 'own'] || C.info;
  const bg = busy ? '#EEE9E2' : b.late ? '#FDE7E7' : b.overflow ? '#FFF4DE' : C.card;
  const k = String(b.key).replace(/[^A-Za-z0-9]/g, '').slice(-24);
  return (
    <View style={{ flexDirection: 'row', gap: 10, opacity: b.past ? 0.55 : 1 }}>
      <View style={{ width: 64 }}>
        <Text style={{ fontWeight: '800', color: b.late ? C.danger : C.text, fontSize: 15 }}>{nice(b.startText)}</Text>
        <Text style={{ color: C.sub, fontSize: 13 }}>{nice(b.endText)}</Text>
      </View>
      <View style={{ flex: 1, backgroundColor: bg, borderRadius: 12, borderLeftWidth: 6, borderLeftColor: col, borderWidth: 1, borderColor: b.late ? C.danger : C.border, padding: 10, gap: 4 }}>
        <Pressable testID={`md-b-${k}`} onPress={onOpen}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: busy ? C.sub : C.text }}>{b.fixed ? '📌 ' : b.pinned ? '⏰ ' : ''}{b.title}</Text>
          {!busy ? <Text style={{ fontSize: 13, color: C.sub }}>{typeLabel(b)} · {fmtMins(b.end - b.start)}{b.deadlineText ? ` · ${b.deadlineText === 'overdue' ? 'overdue' : `by ${nice(b.deadlineText)}`}` : ''}{b.overflow ? ' · after working hours' : ''}{b.clash ? ' · clashes with another fixed item' : ''}{b.private ? ' · private' : ''}</Text> : null}
          {!busy && b.sub ? <Text style={{ fontSize: 14, color: C.text }} numberOfLines={2}>{b.sub}</Text> : null}
          {b.late && !busy ? <Text style={{ fontSize: 14, color: C.danger, fontWeight: '800' }}>Will miss the deadline</Text> : null}
        </Pressable>
        {ed ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {!b.fixed && !b.pinned ? <Btn testID={`md-up-${k}`} title="▲" size="sm" variant="secondary" onPress={onUp} /> : null}
            {!b.fixed && !b.pinned ? <Btn testID={`md-down-${k}`} title="▼" size="sm" variant="secondary" onPress={onDown} /> : null}
            {!b.fixed ? <Btn testID={`md-time-${k}`} title="Move to…" size="sm" variant="secondary" onPress={onTime} /> : null}
            <Btn testID={`md-nottoday-${k}`} title="Not today" size="sm" variant="secondary" onPress={onNotToday} />
            <Btn testID={`md-skip-${k}`} title="Skip" size="sm" variant="secondary" onPress={onSkip} />
            <Btn testID={`md-tick-${k}`} title="✓ Done" size="sm" variant="success" onPress={onDone} />
          </View>
        ) : null}
      </View>
    </View>
  );
}

export function MyDayScreen({ params }) { return <DayView params={params || {}} />; }
export function TheirDayScreen({ params }) { return <DayView params={params || {}} readOnlyScreen />; }

// ---------------------------------------------------------------- own item (meeting, errand, repeating)
export function MyDayItemScreen({ params }) {
  const { user, nav } = useApp();
  const act = useAct();
  const old = params.uid ? M.getItem(params.uid) : null;
  const [f, setF] = useState(old ? {
    uid: old.uid, ownerUid: old.owner_uid, title: old.title, kind: old.kind, date: old.the_date, start: old.start_time || '', minutes: String(old.minutes), fixed: !!old.fixed, repeat: old.repeat,
    repeatDays: old.repeat_days ? old.repeat_days.split(',').map(Number) : [], until: old.until_date || '', deadline: old.deadline || '', private: !!old.private, note: old.note || '',
  } : { ownerUid: params.ownerUid || user.uid, title: '', kind: 'meeting', date: params.date || dateStr(), start: '', minutes: '30', fixed: true, repeat: 'none', repeatDays: [], until: '', deadline: '', private: false, note: '' });
  const set = (k) => (v) => setF({ ...f, [k]: v });
  const google = old && old.kind === 'google';
  return (
    <Screen title={old ? 'Change item' : 'Meeting or errand'} subtitle="My day">
      {google ? <Banner tone="info" title="From Google Calendar" message="Change it in Google Calendar; it comes in again at the next sync. You can mark it private here." /> : null}
      <Field testID="mdi-title" label="What" value={f.title} onChangeText={set('title')} placeholder="e.g. Meeting with BSP, bank deposit, pick up stock" />
      {!google ? <Choice label="Kind" value={f.kind} onChange={(v) => setF({ ...f, kind: v, fixed: v === 'meeting' ? true : f.fixed })} options={[{ value: 'meeting', label: 'Meeting' }, { value: 'errand', label: 'Errand' }, { value: 'other', label: 'Other' }]} testIDPrefix="mdi-kind" /> : null}
      <DateField testID="mdi-date" label={f.repeat === 'none' ? 'Day' : 'Starting'} value={f.date} onChange={set('date')} />
      <TimeField testID="mdi-start" label="Time" value={f.start} onChange={set('start')} optional showNow={false} hint="Leave empty to let the app find a free time." />
      <Field testID="mdi-mins" label="How long (minutes)" value={f.minutes} onChangeText={(v) => set('minutes')(v.replace(/\D/g, ''))} keyboardType="number-pad" />
      <Choice label="Can it move?" value={f.fixed ? 'y' : 'n'} onChange={(v) => set('fixed')(v === 'y')} options={[{ value: 'y', label: 'Fixed time – never moves' }, { value: 'n', label: 'Flexible – the app may move it' }]} testIDPrefix="mdi-fixed" />
      {!f.fixed ? <TimeField testID="mdi-deadline" label="Finish by" value={f.deadline} onChange={set('deadline')} optional showNow={false} /> : null}
      {!google ? <Choice label="Repeat" value={f.repeat} onChange={set('repeat')} options={Object.entries(M.REPEATS).map(([value, label]) => ({ value, label }))} testIDPrefix="mdi-repeat" /> : null}
      {f.repeat === 'weekly' ? (
        <View style={{ gap: 6 }}>
          <Label>On these days</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {[6, 0, 1, 2, 3, 4, 5].map((d) => <Btn key={d} testID={`mdi-day-${d}`} title={WD[d].slice(0, 3)} size="sm" variant={f.repeatDays.includes(d) ? 'info' : 'secondary'} onPress={() => set('repeatDays')(f.repeatDays.includes(d) ? f.repeatDays.filter((x) => x !== d) : f.repeatDays.concat([d]))} />)}
          </View>
        </View>
      ) : null}
      {f.repeat !== 'none' ? <DateField testID="mdi-until" label="Until" value={f.until} onChange={set('until')} optional farDays={800} /> : null}
      <Choice label="Who may see what it is" value={f.private ? 'p' : 'b'} onChange={(v) => set('private')(v === 'p')} options={[{ value: 'b', label: 'Business – managers may see it' }, { value: 'p', label: 'Private – others see "Busy"' }]} testIDPrefix="mdi-private" />
      <Field label="Note" value={f.note} onChangeText={set('note')} />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {old ? <Btn testID="mdi-remove" title="Remove" size="md" variant="danger" style={{ flexGrow: 1 }} onPress={() => { if (act(() => M.archiveItem(user, old.uid), 'Removed')) nav.pop(); }} /> : null}
        <Btn testID="mdi-save" title="Save" icon="💾" size="md" variant="success" style={{ flexGrow: 2 }} onPress={() => {
          if (act(() => M.saveItem(user, { ...f, kind: google ? 'google' : f.kind, extId: old && old.ext_id }), 'Saved')) nav.pop();
        }} />
      </View>
    </Screen>
  );
}

export function MyDayItemsScreen() {
  const { user, nav } = useApp();
  const list = M.listItems(user.uid);
  return (
    <Screen title="My meetings & errands" subtitle="Own items, repeating ones first">
      <Btn testID="mdl-add" title="Meeting or errand" icon="➕" size="md" variant="primary" onPress={() => nav.push('MyDayItem', {})} />
      {!list.length ? <Text style={{ color: C.sub }}>Nothing yet.</Text> : null}
      {list.map((it) => (
        <ListItem key={it.uid} testID={`mdl-${it.uid}`} title={`${it.private ? '🔒 ' : ''}${it.title}`} sub={`${M.REPEATS[it.repeat]}${it.repeat === 'none' ? ` · ${dayName(it.the_date)} ${it.the_date}` : ` from ${it.the_date}`}${it.start_time ? ` · ${nice(it.start_time)}` : ' · flexible'} · ${it.minutes} min`}
          badge={it.fixed ? 'Fixed' : 'Flexible'} badgeColor={it.fixed ? C.info : C.success} onPress={() => nav.push('MyDayItem', { uid: it.uid })} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings: my hours (7 days), task times, Google
export function MyDaySettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const owners = M.planOwners();
  const admin = canDo(user, 'settings');
  const [who, setWho] = useState(owners.some((o) => o.uid === user.uid) ? user.uid : (owners[0] || {}).uid);
  const [hours, setHours] = useState(M.hoursList(who));
  const [rem, setRem] = useState(String(M.reminderFor(who)));
  const s0 = M.mydaySettings();
  const [s, setS] = useState({ ...s0, durations: Object.fromEntries(Object.entries(s0.durations).map(([k, v]) => [k, String(v)])) });
  const pickWho = (v) => { setWho(v); setHours(M.hoursList(v)); setRem(String(M.reminderFor(v))); };
  const hset = (i, k, v) => setHours(hours.map((h, j) => (j === i ? { ...h, [k]: v } : h)));
  return (
    <Screen title="My day settings" subtitle="Working hours, task times, Google Calendar">
      {admin && owners.length > 1 ? <Choice label="Whose hours" value={who} onChange={pickWho} options={owners.map((o) => ({ value: o.uid, label: o.name }))} testIDPrefix="mds-who" /> : null}
      <Section title="Working hours (each day can be different)">
        {[6, 0, 1, 2, 3, 4, 5].map((i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end', borderTopWidth: 1, borderTopColor: C.border, paddingTop: 6 }}>
            <Text style={{ width: 100, fontWeight: '800', fontSize: 17, color: C.text }}>{WD[i]}</Text>
            <Btn testID={`mds-off-${i}`} title={hours[i].off ? 'Day off' : 'Working'} size="sm" variant={hours[i].off ? 'secondary' : 'info'} onPress={() => hset(i, 'off', !hours[i].off)} />
            {!hours[i].off ? <View style={{ flexBasis: 200, flexGrow: 1 }}><TimeField testID={`mds-start-${i}`} label="Start" value={hours[i].start} onChange={(v) => hset(i, 'start', v)} showNow={false} /></View> : null}
            {!hours[i].off ? <View style={{ flexBasis: 200, flexGrow: 1 }}><TimeField testID={`mds-end-${i}`} label="Finish" value={hours[i].end} onChange={(v) => hset(i, 'end', v)} showNow={false} /></View> : null}
          </View>
        ))}
        <Field testID="mds-rem" label="Remind me this many minutes before each item (with sound)" value={rem} onChangeText={(v) => setRem(v.replace(/\D/g, ''))} keyboardType="number-pad" />
        <Btn testID="mds-save-hours" title="Save hours" icon="💾" size="md" variant="success" onPress={() => act(() => M.saveMyHours(user, who, hours, rem), 'Saved')} />
      </Section>
      {admin ? (
        <Section title="How long each kind of task takes (minutes)">
          {M.TASK_TYPES.map((t) => (
            <Field key={t.key} testID={`mds-dur-${t.key}`} label={`${t.icon} ${t.label}`} value={s.durations[t.key]} onChangeText={(v) => setS({ ...s, durations: { ...s.durations, [t.key]: v.replace(/\D/g, '') } })} keyboardType="number-pad" />
          ))}
          <TimeField testID="mds-payby" label="Pay day: wages paid by" value={s.payDayBy} onChange={(v) => setS({ ...s, payDayBy: v })} showNow={false} />
          <Label>Google Calendar (through the Easy Buys cloud, no Google login on this device)</Label>
          <Chips value={s.calendarIn ? 'y' : 'n'} onChange={(v) => setS({ ...s, calendarIn: v === 'y' })} testIDPrefix="mds-in" options={[{ value: 'n', label: 'Meetings: off' }, { value: 'y', label: 'Bring in meetings from the Easy Buys calendar' }]} />
          <Chips value={s.calendarOut ? 'y' : 'n'} onChange={(v) => setS({ ...s, calendarOut: v === 'y' })} testIDPrefix="mds-out" options={[{ value: 'n', label: 'Tasks: off' }, { value: 'y', label: `Send app tasks to "${M.MYDAY_CALENDAR}"` }]} />
          {owners.length > 1 ? <Choice label="The Google meetings belong to" value={s.calendarOwner || (M.calendarOwner() || {}).uid} onChange={(v) => setS({ ...s, calendarOwner: v })} options={owners.map((o) => ({ value: o.uid, label: o.name }))} testIDPrefix="mds-calowner" /> : null}
          <Hint>Meetings come from the main calendar of the Google account the Easy Buys cloud runs on. App tasks go to a separate calendar called "{M.MYDAY_CALENDAR}" (made the first time). Private meetings show as "Busy" to others.</Hint>
          <Btn testID="mds-save" title="Save settings" icon="💾" size="md" variant="success" onPress={() => act(() => M.saveMydaySettings(user, s), 'Saved')} />
        </Section>
      ) : null}
    </Screen>
  );
}
