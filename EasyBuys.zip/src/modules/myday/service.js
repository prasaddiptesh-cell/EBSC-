// My day (owner & admin): a timeline of the working day. App tasks (from the warnings of every module and from module
// services: supplier order cut-offs, approvals, checks, pay day, tax, licences, month end, watchdog flags) are placed
// automatically before their deadlines; own items (meetings, errands, repeating) sit in between. Fixed items never move,
// nothing overlaps, unfinished tasks move to the next free slot, and a task that would miss its deadline turns red.
// Google Calendar (through the cloud script only): meetings come in from the Easy Buys account's calendar and the
// app tasks go out to a separate "Easy Buys – My day" calendar.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, getSetting, setSetting, dayName, clock } from '../../services/core.js';
import { can, reasonRequired } from '../../services/access.js';
import { collectAlerts } from '../../services/alerts.js';
import { enqueue } from '../../services/stock.js';
import { listUsers } from '../../services/catalog.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const HHMM = /^\d{2}:\d{2}$/;
export const toMin = (t) => Number(String(t).slice(0, 2)) * 60 + Number(String(t).slice(3, 5));
export const fromMin = (m) => { const x = Math.max(0, Math.min(1439, Math.round(m))); return `${String(Math.floor(x / 60)).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`; };
const ISO = /^\d{4}-\d{2}-\d{2}$/;
const wdOf = (d) => new Date(`${d}T00:00:00`).getDay();

// ---------------------------------------------------------------- task types and settings
export const TASK_TYPES = [
  { key: 'order', label: 'Supplier orders', icon: '🛒', mins: 15 },
  { key: 'approval', label: 'Approvals', icon: '✅', mins: 10 },
  { key: 'check', label: 'Checks', icon: '🔎', mins: 15 },
  { key: 'payday', label: 'Pay day', icon: '💰', mins: 45 },
  { key: 'tax', label: 'Tax (VAT, FNPF, PAYE)', icon: '🧾', mins: 30 },
  { key: 'licence', label: 'Licences & permits', icon: '📜', mins: 20 },
  { key: 'monthend', label: 'Month end', icon: '📚', mins: 60 },
  { key: 'watchdog', label: 'Watchdog & system flags', icon: '🐕', mins: 15 },
  { key: 'other', label: 'Other warnings', icon: '⚠️', mins: 10 },
];
export const TYPE = Object.fromEntries(TASK_TYPES.map((t) => [t.key, t]));
// Sunday = 0 … Saturday = 6. Seven days, different hours.
export const DEFAULT_HOURS = [
  { off: false, start: '09:00', end: '13:00' }, { off: false, start: '07:30', end: '18:00' }, { off: false, start: '07:30', end: '18:00' }, { off: false, start: '07:30', end: '18:00' },
  { off: false, start: '07:30', end: '18:00' }, { off: false, start: '07:30', end: '18:00' }, { off: false, start: '07:30', end: '16:00' },
];
export const MYDAY_DEFAULTS = {
  durations: Object.fromEntries(TASK_TYPES.map((t) => [t.key, t.mins])),
  people: {},              // { [ownerUid]: { hours: [7 × { off, start, end }], reminderMins } }
  reminderMins: 10,
  payDayBy: '12:00',       // Saturday: wages paid by this time
  calendarIn: false,       // meetings come in from the Easy Buys Google account's calendar
  calendarOut: false,      // app tasks go out to the "Easy Buys – My day" calendar
  calendarOwner: null,     // whose My day the Google meetings belong to (default: the first owner)
};
export function mydaySettings() {
  const s = { ...MYDAY_DEFAULTS, ...(getShared('myday_settings', {}) || {}) };
  s.durations = { ...MYDAY_DEFAULTS.durations, ...(s.durations || {}) };
  s.people = s.people || {};
  return s;
}
export function hoursList(ownerUid) {
  const p = mydaySettings().people[ownerUid];
  return DEFAULT_HOURS.map((d, i) => ({ ...d, ...((p && p.hours && p.hours[i]) || {}) }));
}
export function hoursFor(ownerUid, date) { return hoursList(ownerUid)[wdOf(date)]; }
export function reminderFor(ownerUid) {
  const s = mydaySettings();
  const p = s.people[ownerUid];
  return p && Number.isFinite(Number(p.reminderMins)) ? Number(p.reminderMins) : s.reminderMins;
}
export function saveMyHours(user, ownerUid, hours, reminderMins) {
  need(ownerUid === user.uid || !reasonRequired(user), 'Only the owner or admin can change someone else\'s working hours.');
  const clean = Array.from({ length: 7 }, (_, i) => {
    const h = (hours || [])[i] || DEFAULT_HOURS[i];
    const off = !!h.off;
    need(off || (HHMM.test(txt(h.start)) && HHMM.test(txt(h.end)) && toMin(h.end) > toMin(h.start)), `Check the hours for ${['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][i]} (finish after start).`);
    return { off, start: txt(h.start) || DEFAULT_HOURS[i].start, end: txt(h.end) || DEFAULT_HOURS[i].end };
  });
  const s = mydaySettings();
  const r = Number(reminderMins);
  s.people = { ...s.people, [ownerUid]: { hours: clean, reminderMins: Number.isFinite(r) && r >= 0 ? Math.min(240, Math.round(r)) : s.reminderMins } };
  setShared('myday_settings', s);
  audit({ user, action: 'Changed My day working hours', table: 'shared_settings', recordUid: 'myday_settings', after: s.people[ownerUid] });
  return s.people[ownerUid];
}
export function saveMydaySettings(user, patch) {
  need(!reasonRequired(user) || can(user, 'settings'), 'Only the owner or admin can change these.');
  const s = mydaySettings();
  const durations = { ...s.durations };
  for (const t of TASK_TYPES) {
    const v = Number((patch.durations || {})[t.key]);
    if (Number.isFinite(v) && v >= 1) durations[t.key] = Math.min(480, Math.round(v));
  }
  const clean = { ...s, durations, calendarIn: patch.calendarIn === undefined ? s.calendarIn : !!patch.calendarIn, calendarOut: patch.calendarOut === undefined ? s.calendarOut : !!patch.calendarOut,
    calendarOwner: patch.calendarOwner === undefined ? s.calendarOwner : patch.calendarOwner || null,
    payDayBy: HHMM.test(txt(patch.payDayBy)) ? txt(patch.payDayBy) : s.payDayBy,
    reminderMins: Number.isFinite(Number(patch.reminderMins)) && patch.reminderMins !== '' && patch.reminderMins !== undefined ? Math.max(0, Math.round(Number(patch.reminderMins))) : s.reminderMins };
  setShared('myday_settings', clean);
  audit({ user, action: 'Changed My day settings (task times, Google Calendar)', table: 'shared_settings', recordUid: 'myday_settings', after: { durations: clean.durations, calendarIn: clean.calendarIn, calendarOut: clean.calendarOut } });
  return clean;
}
// The people who have a My day: owners and admins.
export function planOwners() {
  return listUsers().filter((u) => u.active && u.sync_status !== 'seed' && (u.role === 'owner' || u.role === 'admin'));
}
export function calendarOwner() {
  const s = mydaySettings();
  const owners = planOwners();
  return owners.find((u) => u.uid === s.calendarOwner) || owners.find((u) => u.role === 'owner') || owners[0] || null;
}

// ---------------------------------------------------------------- what kind of task a warning is, and its deadline
export function typeOf(a) {
  const id = String(a.id || '');
  const area = String(a.area || '');
  if (/^ord-/.test(id)) return 'order';
  if (/^(stat-|vat|tax|paye|fnpf)/.test(id)) return 'tax';
  if (/^lic-/.test(id) || area === 'licences') return 'licence';
  if (/^(health-|sync-|snapshot-|watchdog|wd-|outside-folder|update-)/.test(id) || area === 'watchdog') return 'watchdog';
  if (/^pay-/.test(id)) return 'payday';
  if (/(waiting|to-check|approve|unsigned|^leave-|^verify-|^acc-aronium|-draft)/.test(id)) return 'approval';
  if (/^(acc-|month)/.test(id)) return 'monthend';
  if (/^(till-|bank-|wallet-|inv-|ap-|stock|count|loan-|own-|owed-|ts-|roster-)/.test(id) || ['till', 'bank', 'inventory', 'payables', 'loans', 'owed', 'timesheets'].includes(area)) return 'check';
  return 'other';
}
// The deadline (minutes of the day) for a warning on `day`, or null when it has none today.
export function deadlineOf(a, day, hours) {
  const endOfWork = hours && !hours.off ? toMin(hours.end) : 18 * 60;
  const due = txt(a.due);
  if (due) {
    const d = due.slice(0, 10);
    if (d > day) return null;
    if (d < day) return -1; // already overdue
    return due.length >= 16 ? toMin(due.slice(11, 16)) : endOfWork;
  }
  const m = `${a.text || ''} ${a.sub || ''}`.match(/(\d{4}-\d{2}-\d{2})/);
  if (m && /due|by|expire|before/i.test(`${a.text || ''} ${a.sub || ''}`)) {
    if (m[1] > day) return null;
    if (m[1] < day) return -1;
    return endOfWork;
  }
  return a.level === 'urgent' ? endOfWork : null;
}

// ---------------------------------------------------------------- the scheduler (pure, no database)
// window: { start, end } minutes (end may be less than start = day off → null); now: minutes or null (not today)
// fixed: [{ key, start, mins }]; flex: [{ key, mins, deadline|null, pin|null, order|null, urgent }]
// → { placed: { [key]: { start, end, late, overflow, clash } } }
export function schedule({ window, now = null, fixed = [], flex = [] }) {
  const placed = {};
  const busy = [];
  const sortedFixed = fixed.slice().sort((a, b) => a.start - b.start);
  for (const f of sortedFixed) {
    const end = f.start + Math.max(1, f.mins);
    const clash = busy.some((b) => b.start < end && f.start < b.end);
    placed[f.key] = { start: f.start, end, fixed: true, clash, late: false, overflow: false };
    busy.push({ start: f.start, end });
  }
  const wStart = window ? window.start : 8 * 60;
  const wEnd = window ? window.end : wStart;
  const from = Math.max(wStart, now === null ? wStart : now);
  const free = (s, e) => !busy.some((b) => b.start < e && s < b.end);
  const firstFree = (at, len) => {
    let s = at;
    for (let guard = 0; guard < 500; guard++) {
      const hit = busy.filter((b) => b.start < s + len && s < b.end).sort((a, b) => b.end - a.end)[0];
      if (!hit) return s;
      s = hit.end;
    }
    return s;
  };
  // Pinned ones first (when their time is still ahead), then the rest in order.
  const pinned = flex.filter((t) => t.pin !== null && t.pin !== undefined && t.pin >= from);
  const rest = flex.filter((t) => !pinned.includes(t));
  for (const t of pinned.sort((a, b) => a.pin - b.pin)) {
    const s = free(t.pin, t.pin + t.mins) ? t.pin : firstFree(t.pin, t.mins);
    placed[t.key] = { start: s, end: s + t.mins, pinned: true };
    busy.push({ start: s, end: s + t.mins });
  }
  const ordered = rest.map((t, i) => ({ t, i })).sort((a, b) => {
    const oa = a.t.order !== null && a.t.order !== undefined ? a.t.order : null;
    const ob = b.t.order !== null && b.t.order !== undefined ? b.t.order : null;
    if (oa !== null && ob !== null) return oa - ob;
    if (oa !== null || ob !== null) {
      // A manually ordered list keeps its order; new urgent tasks still go first.
      if (oa === null && a.t.urgent) return -1;
      if (ob === null && b.t.urgent) return 1;
      return oa !== null ? -1 : 1;
    }
    const da = a.t.deadline === null || a.t.deadline === undefined ? 1e9 : a.t.deadline;
    const db_ = b.t.deadline === null || b.t.deadline === undefined ? 1e9 : b.t.deadline;
    return (b.t.urgent ? 1 : 0) - (a.t.urgent ? 1 : 0) || da - db_ || a.i - b.i;
  }).map((x) => x.t);
  for (const t of ordered) {
    const s = firstFree(from, t.mins);
    placed[t.key] = { start: s, end: s + t.mins };
    busy.push({ start: s, end: s + t.mins });
  }
  for (const t of flex) {
    const p = placed[t.key];
    p.overflow = !window || p.end > wEnd;
    p.late = t.deadline !== null && t.deadline !== undefined && p.end > t.deadline;
    p.clash = false;
  }
  return { placed };
}

// ---------------------------------------------------------------- own items (meetings, errands, repeating)
export const KINDS = { meeting: 'Meeting', errand: 'Errand', other: 'Other', google: 'Google Calendar' };
export const REPEATS = { none: 'Once', daily: 'Every day', weekdays: 'Mon–Fri', weekly: 'Every week', monthly: 'Every month' };
export function saveItem(user, it) {
  need(txt(it.title), 'Type what it is (e.g. Meeting with the bank).');
  need(ISO.test(txt(it.date)), 'Choose the day.');
  need(!txt(it.start) || HHMM.test(txt(it.start)), 'Check the time.');
  need(!txt(it.deadline) || HHMM.test(txt(it.deadline)), 'Check the "finish by" time.');
  const mins = Math.round(Number(it.minutes) || 0);
  need(mins >= 5 && mins <= 12 * 60, 'How long? Between 5 minutes and 12 hours.');
  const repeat = REPEATS[it.repeat] ? it.repeat : 'none';
  const fixed = it.fixed === undefined ? (it.kind === 'meeting' && !!txt(it.start)) : !!it.fixed;
  need(!fixed || txt(it.start), 'A fixed item needs a time.');
  const owner = it.ownerUid || user.uid;
  need(owner === user.uid || !reasonRequired(user), 'Only the owner or admin can add items to someone else\'s day.');
  const id = it.uid || uuid('MD');
  const now = stamp();
  const old = it.uid ? db().get('SELECT * FROM myday_items WHERE uid = ?', [it.uid]) : null;
  const row = [id, owner, txt(it.title), KINDS[it.kind] ? it.kind : 'errand', it.date, txt(it.start) || null, mins, fixed ? 1 : 0, repeat,
    (it.repeatDays || []).length ? it.repeatDays.join(',') : null, ISO.test(txt(it.until)) ? it.until : null, txt(it.deadline) || null, it.private ? 1 : 0, txt(it.note) || null, it.extId || (old && old.ext_id) || null, user ? user.name : null, now, deviceId()];
  db().run(`INSERT INTO myday_items (uid, owner_uid, title, kind, the_date, start_time, minutes, fixed, repeat, repeat_days, until_date, deadline, private, note, ext_id, status, by_name, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active',?,?,?) ON CONFLICT(uid) DO UPDATE SET owner_uid=excluded.owner_uid, title=excluded.title, kind=excluded.kind, the_date=excluded.the_date, start_time=excluded.start_time,
    minutes=excluded.minutes, fixed=excluded.fixed, repeat=excluded.repeat, repeat_days=excluded.repeat_days, until_date=excluded.until_date, deadline=excluded.deadline, private=excluded.private, note=excluded.note,
    ext_id=excluded.ext_id, status='active', by_name=excluded.by_name, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`, row);
  audit({ user, action: `${old ? 'Changed' : 'Added'} My day item "${txt(it.title)}"`, table: 'myday_items', recordUid: id, before: old, after: { title: it.title, date: it.date, start: it.start, repeat } });
  return id;
}
export function getItem(uid) { return db().get('SELECT * FROM myday_items WHERE uid = ?', [uid]); }
export function archiveItem(user, uid) {
  const it = getItem(uid);
  need(it, 'Not found.');
  db().run(`UPDATE myday_items SET status = 'archived', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: `Removed My day item "${it.title}"`, table: 'myday_items', recordUid: uid, before: it });
}
export function listItems(ownerUid, { includeGoogle = false } = {}) {
  return db().all(`SELECT * FROM myday_items WHERE owner_uid = ? AND status = 'active' ${includeGoogle ? '' : "AND kind <> 'google'"} ORDER BY repeat <> 'none' DESC, the_date DESC, start_time`, [ownerUid]);
}
// Does an item happen on this day?
export function occursOn(it, day) {
  if (it.status !== 'active' || day < it.the_date) return false;
  if (it.until_date && day > it.until_date) return false;
  const wd = wdOf(day);
  switch (it.repeat) {
    case 'daily': return true;
    case 'weekdays': return wd >= 1 && wd <= 5;
    case 'weekly': {
      const days = txt(it.repeat_days) ? it.repeat_days.split(',').map(Number) : [wdOf(it.the_date)];
      return days.includes(wd);
    }
    case 'monthly': return Number(day.slice(8, 10)) === Number(it.the_date.slice(8, 10));
    default: return day === it.the_date;
  }
}
export function itemsOn(ownerUid, day) {
  return db().all(`SELECT * FROM myday_items WHERE owner_uid = ? AND status = 'active' AND the_date <= ?`, [ownerUid, day]).filter((it) => occursOn(it, day));
}

// ---------------------------------------------------------------- marks (done / skip / not today / moved / order)
const markUid = (owner, day, key) => `${owner}|${day}|${key}`;
export function marksFor(ownerUid, day) {
  return Object.fromEntries(db().all('SELECT * FROM myday_marks WHERE owner_uid = ? AND day = ?', [ownerUid, day]).map((m) => [m.task_key, m]));
}
export function mark(user, ownerUid, day, key, patch) {
  const id = markUid(ownerUid, day, key);
  const old = db().get('SELECT * FROM myday_marks WHERE uid = ?', [id]) || {};
  const v = { state: old.state || null, opened_at: old.opened_at || null, pin_time: old.pin_time || null, order_no: old.order_no === undefined ? null : old.order_no, title: old.title || null, ...patch };
  const now = stamp();
  db().run(`INSERT INTO myday_marks (uid, owner_uid, day, task_key, title, state, opened_at, pin_time, order_no, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET title=excluded.title, state=excluded.state, opened_at=excluded.opened_at, pin_time=excluded.pin_time, order_no=excluded.order_no, by_name=excluded.by_name,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`, [id, ownerUid, day, key, v.title, v.state, v.opened_at, v.pin_time, v.order_no, user ? user.name : null, now, deviceId()]);
  return v;
}
const mustPlan = (user, ownerUid) => need(user && (user.uid === ownerUid ? can(user, 'myday') : !reasonRequired(user)), 'Only the person whose day it is (or the owner) can change it.');
export function doneTask(user, ownerUid, day, key, title) { mustPlan(user, ownerUid); return mark(user, ownerUid, day, key, { state: 'done', title }); }
export function skipTask(user, ownerUid, day, key, title) { mustPlan(user, ownerUid); return mark(user, ownerUid, day, key, { state: 'skipped', title }); }
export function undoMark(user, ownerUid, day, key) { mustPlan(user, ownerUid); return mark(user, ownerUid, day, key, { state: null }); }
export function openTask(user, ownerUid, day, key, title) { if (user && user.uid === ownerUid) mark(user, ownerUid, day, key, { opened_at: stamp(), title }); }
export function pinTask(user, ownerUid, day, key, time) {
  mustPlan(user, ownerUid);
  need(!time || HHMM.test(time), 'Check the time.');
  return mark(user, ownerUid, day, key, { pin_time: time || null });
}
// "Not today": app tasks come back tomorrow; a one-off own item moves to tomorrow; a repeating one skips today.
export function notToday(user, ownerUid, day, key, title) {
  mustPlan(user, ownerUid);
  if (key.startsWith('own:')) {
    const it = getItem(key.slice(4));
    if (it && it.repeat === 'none' && it.kind !== 'google') {
      db().run(`UPDATE myday_items SET the_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [addDays(day, 1), stamp(), deviceId(), it.uid]);
      audit({ user, action: `My day: moved "${it.title}" to ${addDays(day, 1)}`, table: 'myday_items', recordUid: it.uid });
      return { moved: addDays(day, 1) };
    }
  }
  mark(user, ownerUid, day, key, { state: 'not_today', title });
  return { moved: null };
}
// Up / down: swap places with the task before / after (the order is kept for the day).
export function moveTask(user, ownerUid, day, key, dir) {
  mustPlan(user, ownerUid);
  const plan = dayPlan(ownerUid, day);
  const flex = plan.blocks.filter((b) => !b.fixed && !b.pinned);
  const i = flex.findIndex((b) => b.key === key);
  need(i >= 0, 'That task cannot be moved (fixed items stay where they are).');
  const j = dir === 'up' ? i - 1 : i + 1;
  if (j < 0 || j >= flex.length) return false;
  const order = flex.map((b) => b.key);
  [order[i], order[j]] = [order[j], order[i]];
  order.forEach((k, n) => mark(user, ownerUid, day, k, { order_no: n + 1, title: (flex.find((b) => b.key === k) || {}).title }));
  return true;
}

// ---------------------------------------------------------------- app tasks (from warnings and module services)
function tryReq(fn) { try { return fn(); } catch (e) { return null; } }
const ownerUser = (uid) => db().get('SELECT * FROM users WHERE uid = ?', [uid]);

let collecting = 0;
export function appTasks(ownerUid, day, { now = stamp() } = {}) {
  const owner = ownerUser(ownerUid);
  if (!owner) return [];
  const s = mydaySettings();
  const hours = hoursFor(ownerUid, day);
  const dur = (t) => Number(s.durations[t]) || TYPE[t].mins;
  const today = now.slice(0, 10);
  const out = new Map();
  const add = (t) => { if (!out.has(t.key)) out.set(t.key, { mins: dur(t.type), ...t }); };
  // 1) Supplier orders before their cut-offs (inventory › order days).
  tryReq(() => {
    const S = require('../inventory/schedules.js');
    const shops = S.reminderShops(owner);
    if (Array.isArray(shops) && !shops.length) return;
    for (const r of S.ordersForDay(day, { now, shopCodes: shops || undefined })) {
      if (!['later', 'due', 'started', 'missed'].includes(r.state)) continue;
      const k = `${r.date}-${r.supplierUid}-${r.shopCode}`;
      add({ key: `ord:${k}`, type: 'order', title: r.po ? `Send order ${r.po.po_no} to ${r.supplierName} (${r.shopCode})` : `Order from ${r.supplierName} for ${r.shopCode}`,
        sub: r.cutoff ? `Cut-off ${r.cutoff}` : 'Order day', deadline: r.cutoff ? (r.state === 'missed' ? -1 : toMin(r.cutoff)) : null, urgent: r.state === 'missed',
        nav: r.po ? { screen: 'POView', params: { uid: r.po.uid } } : { screen: 'POEdit', params: { shopCode: r.shopCode, supplierUid: r.supplierUid, suggest: true } } });
    }
  });
  // 2) Every warning this person sees today (approvals, checks, tax, licences, watchdog …).
  if (day === today) {
    let list = [];
    // My day's own warnings are built from this list, so they are switched off while it is collected (no loop).
    collecting += 1;
    try { list = collectAlerts(owner, { includeHidden: true, today: day }); } catch (e) { list = []; } finally { collecting -= 1; }
    for (const a of list) {
      if (/^myday-/.test(a.id) || !a.nav) continue;
      const m = String(a.id).match(/^ord-(?:due|started|missed)-(.+)$/);
      if (m) { if (out.has(`ord:${m[1]}`)) continue; }
      const type = typeOf(a);
      add({ key: m ? `ord:${m[1]}` : `a:${a.id}`, type, title: a.text, sub: a.sub || '', deadline: deadlineOf(a, day, hours), urgent: a.level === 'urgent', level: a.level, nav: a.nav });
    }
  }
  // 3) Pay day (wages book closes Friday, wages paid Saturday).
  tryReq(() => {
    if (!['payroll_view', 'payroll_run'].some((p) => can(owner, p))) return;
    const wd = wdOf(day);
    if (wd === 6) {
      const done = tryReq(() => db().get("SELECT 1 AS x FROM pay_runs WHERE status = 'final' AND pay_date = ?", [day]));
      if (!done) add({ key: `pay:${day}`, type: 'payday', title: 'Pay day: finish the pay run and pay the wages', sub: `By ${s.payDayBy}`, deadline: toMin(s.payDayBy), nav: { screen: 'Payroll', params: {} } });
    } else if (wd === 5) add({ key: `paybook:${day}`, type: 'payday', title: 'Wages book closes today: check this week\'s timesheets', sub: 'Pay is worked out from the checked weeks.', deadline: hours.off ? null : toMin(hours.end), nav: { screen: 'Timesheets', params: {} } });
  });
  // 4) Month end and VAT (FRCS: the return and payment are due by the end of the next month).
  tryReq(() => {
    if (!can(owner, 'accounts_view')) return;
    const last = addDays(`${addDays(`${day.slice(0, 7)}-28`, 4).slice(0, 7)}-01`, -1);
    if (day === last) {
      const A = require('../accounting/service.js');
      const chk = A.monthEndChecklist(day.slice(0, 7));
      if (!chk.ready) add({ key: `monthend:${day.slice(0, 7)}`, type: 'monthend', title: 'Month end: go through the month-end checklist', sub: 'Till, invoices, bank, pay runs, stock take.', deadline: hours.off ? null : toMin(hours.end), nav: { screen: 'MonthEnd', params: { ym: day.slice(0, 7) } } });
      const prev = addDays(`${day.slice(0, 7)}-01`, -1).slice(0, 7);
      const t = getShared(`month_end_${prev}`, {}) || {};
      if (!t.vat) add({ key: `vat:${prev}`, type: 'tax', title: `VAT return for ${prev} is due today (FRCS)`, sub: 'Check it, file it and pay it.', deadline: hours.off ? null : toMin(hours.end), urgent: true, nav: { screen: 'VatReturn', params: { ym: prev } } });
    } else if (Number(addDays(last, 0).slice(8, 10)) - Number(day.slice(8, 10)) <= 4) {
      const prev = addDays(`${day.slice(0, 7)}-01`, -1).slice(0, 7);
      const t = getShared(`month_end_${prev}`, {}) || {};
      if (!t.vat) add({ key: `vat:${prev}`, type: 'tax', title: `VAT return for ${prev} due ${last}`, sub: 'Check it and file it with FRCS before the due date.', deadline: null, nav: { screen: 'VatReturn', params: { ym: prev } } });
    }
  });
  // 5) Licences expiring (for days other than today; today's come from the warnings).
  if (day !== today) {
    tryReq(() => {
      if (!can(owner, 'licences_view') && !can(owner, 'licences_manage')) return;
      const L = require('../licences/service.js');
      const la = L.licenceAlerts(day);
      for (const l of (la.overdue || []).concat(la.due || []).slice(0, 5)) add({ key: `a:lic-${l.uid}-${l.state}`, type: 'licence', title: L.alertText(l), sub: '', deadline: l.state === 'overdue' ? -1 : null, urgent: l.state === 'overdue', nav: { screen: 'Licence', params: { uid: l.uid } } });
    });
  }
  return Array.from(out.values());
}

// ---------------------------------------------------------------- the day plan
const seenKey = (owner, day) => `myday_seen_${owner}_${day}`;
export function dayPlan(ownerUid, day = dateStr(), { now = stamp(), user } = {}) {
  const hours = hoursFor(ownerUid, day);
  const today = now.slice(0, 10);
  const nowMin = day === today ? toMin(now.slice(11, 16)) : day < today ? 24 * 60 : null;
  const window = hours.off ? null : { start: toMin(hours.start), end: toMin(hours.end) };
  const marks = marksFor(ownerUid, day);
  const s = mydaySettings();
  const tasks = appTasks(ownerUid, day, { now });
  // Tasks that disappeared (the job got done in its screen) tick themselves off.
  let seen = {};
  try { seen = JSON.parse(getSetting(seenKey(ownerUid, day), '{}')) || {}; } catch (e) { seen = {}; }
  if (day === today) {
    const live = new Set(tasks.map((t) => t.key));
    for (const [k, title] of Object.entries(seen)) {
      if (!live.has(k) && !(marks[k] && marks[k].state)) { marks[k] = mark(user || null, ownerUid, day, k, { state: 'done', title: `${title}` }); marks[k].task_key = k; marks[k].auto = true; }
    }
    const nextSeen = Object.fromEntries(tasks.map((t) => [t.key, t.title]));
    try { if (JSON.stringify(nextSeen) !== JSON.stringify(seen)) setSetting(seenKey(ownerUid, day), JSON.stringify({ ...nextSeen })); } catch (e) { /* ignore */ }
  }
  const own = itemsOn(ownerUid, day).map((it) => ({
    key: `own:${it.uid}`, own: true, item: it, type: it.kind === 'google' ? 'google' : 'own', title: it.title, sub: it.note || '', private: !!it.private,
    mins: it.minutes, fixed: !!it.fixed && !!it.start_time, start: it.start_time ? toMin(it.start_time) : null, deadline: it.deadline ? toMin(it.deadline) : null, kind: it.kind,
  }));
  const all = own.concat(tasks.map((t) => ({ ...t, app: true })));
  const setAside = [];
  const done = [];
  const active = [];
  for (const t of all) {
    const m = marks[t.key];
    if (m && m.state === 'done') done.push({ ...t, mark: m });
    else if (m && (m.state === 'skipped' || m.state === 'not_today')) setAside.push({ ...t, mark: m });
    else active.push({ ...t, mark: m || null });
  }
  // Ticked off by themselves but no longer in the lists.
  Object.values(marks).filter((m) => m.state === 'done' && !all.some((t) => t.key === m.task_key)).forEach((m) => done.push({ key: m.task_key, title: m.title || 'Task', app: true, mark: m, auto: true }));
  const fixed = active.filter((t) => t.fixed || (t.own && t.start !== null && !(t.mark && t.mark.pin_time)));
  const fixedKeys = new Set(fixed.map((t) => t.key));
  const flex = active.filter((t) => !fixedKeys.has(t.key));
  const res = schedule({
    window, now: nowMin,
    fixed: fixed.map((t) => ({ key: t.key, start: t.start, mins: t.mins })),
    flex: flex.map((t) => ({ key: t.key, mins: t.mins, deadline: t.deadline, urgent: !!t.urgent || t.deadline === -1, pin: t.mark && t.mark.pin_time ? toMin(t.mark.pin_time) : null, order: t.mark && t.mark.order_no !== null && t.mark.order_no !== undefined ? t.mark.order_no : null })),
  });
  const blocks = active.map((t) => {
    const p = res.placed[t.key];
    return { ...t, fixed: fixedKeys.has(t.key) && (t.fixed || t.own), start: p.start, end: p.end, startText: fromMin(p.start), endText: fromMin(Math.min(p.end, 1439)), late: !!p.late || t.deadline === -1, overflow: !!p.overflow, clash: !!p.clash, pinned: !!p.pinned,
      past: nowMin !== null && p.end <= nowMin, deadlineText: t.deadline !== null && t.deadline !== undefined && t.deadline >= 0 ? fromMin(t.deadline) : t.deadline === -1 ? 'overdue' : null };
  }).sort((a, b) => a.start - b.start || (a.fixed ? -1 : 1));
  // Free time between blocks inside working hours.
  const free = [];
  if (window) {
    let cur = Math.max(window.start, nowMin === null ? window.start : Math.min(nowMin, window.end));
    for (const b of blocks.filter((x) => x.end > cur && x.start < window.end)) {
      if (b.start > cur) free.push({ start: cur, end: b.start, startText: fromMin(cur), endText: fromMin(b.start) });
      cur = Math.max(cur, b.end);
    }
    if (cur < window.end) free.push({ start: cur, end: window.end, startText: fromMin(cur), endText: fromMin(window.end) });
  }
  return { ownerUid, day, hours, window, nowMin, blocks, free, done, setAside, late: blocks.filter((b) => b.late && !b.past), overflow: blocks.filter((b) => b.overflow), reminderMins: reminderFor(ownerUid), settings: s };
}

// What another person may see of someone's day: the owner / admin themselves everything; owner/admin looking at
// someone else and managers: business tasks read-only, private items as "Busy"; staff: busy / free only.
export function viewPlan(viewer, ownerUid, day = dateStr(), opts = {}) {
  const plan = dayPlan(ownerUid, day, opts);
  const self = viewer && viewer.uid === ownerUid && can(viewer, 'myday');
  if (self) return { ...plan, level: 'full', editable: true };
  const business = viewer && (can(viewer, 'myday_view') || !reasonRequired(viewer));
  const hide = (b) => ({ key: b.key, start: b.start, end: b.end, startText: b.startText, endText: b.endText, title: 'Busy', busy: true, fixed: b.fixed });
  if (business) {
    return { ...plan, level: 'business', editable: false, blocks: plan.blocks.map((b) => (b.private ? hide(b) : { ...b, sub: b.app ? b.sub : '' })), done: plan.done.filter((b) => !b.private), setAside: [] };
  }
  return { ...plan, level: 'busy', editable: false, blocks: plan.blocks.map(hide), done: [], setAside: [], late: [], overflow: [] };
}

// ---------------------------------------------------------------- warnings: reminders (with sound) and late tasks
export function mydayAlerts(user, { now = stamp() } = {}) {
  if (!user || !can(user, 'myday') || collecting > 0) return [];
  const day = now.slice(0, 10);
  let plan;
  try { plan = dayPlan(user.uid, day, { now, user }); } catch (e) { return []; }
  const out = [];
  const nowMin = toMin(now.slice(11, 16));
  for (const b of plan.late.filter((x) => x.app).slice(0, 3)) {
    out.push({ id: `myday-late-${b.key}`, level: 'urgent', area: 'myday', text: `My day: "${b.title}" will miss its deadline${b.deadlineText && b.deadlineText !== 'overdue' ? ` (${b.deadlineText})` : ''}`,
      sub: 'Move something else, do it now, or tap "Not today".', nav: { screen: 'MyDay', params: { date: day } } });
  }
  const next = plan.blocks.find((b) => !b.past && b.start >= nowMin && b.start - nowMin <= plan.reminderMins);
  if (next) {
    out.push({ id: `myday-next-${next.key}-${next.startText}`, level: 'warning', notify: true, area: 'myday', text: `Coming up at ${next.startText}: ${next.title}`,
      sub: next.fixed ? 'Fixed time.' : `About ${next.mins} minutes.`, nav: next.nav && next.app ? next.nav : { screen: 'MyDay', params: { date: day } } });
  }
  return out;
}

// ---------------------------------------------------------------- Google Calendar (through the cloud script only)
export const MYDAY_CALENDAR = 'Easy Buys – My day';
// Meetings from the Easy Buys account's calendar for one day: kept as fixed items (private ones show as Busy to others).
export function applyGoogleEvents(ownerUid, date, events) {
  const owner = ownerUid || (calendarOwner() || {}).uid;
  if (!owner || !ISO.test(date)) return 0;
  const now = stamp();
  const keep = new Set();
  let n = 0;
  for (const e of events || []) {
    if (!e || !e.id || e.allDay || !HHMM.test(txt(e.start))) continue;
    const uid = `G-${date}-${String(e.id).replace(/[^A-Za-z0-9]/g, '').slice(-40)}`;
    keep.add(uid);
    const mins = Math.max(5, (HHMM.test(txt(e.end)) ? toMin(e.end) : toMin(e.start) + 30) - toMin(e.start));
    db().run(`INSERT INTO myday_items (uid, owner_uid, title, kind, the_date, start_time, minutes, fixed, repeat, private, note, ext_id, status, by_name, updated_at, updated_device)
      VALUES (?,?,?, 'google', ?,?,?, 1, 'none', ?,?,?, 'active', 'Google Calendar', ?, ?) ON CONFLICT(uid) DO UPDATE SET title=excluded.title, start_time=excluded.start_time, minutes=excluded.minutes, private=excluded.private,
      note=excluded.note, status='active', updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
    [uid, owner, txt(e.title) || 'Meeting', date, txt(e.start), mins, e.private ? 1 : 0, txt(e.location) || null, String(e.id), now, deviceId()]);
    n += 1;
  }
  db().all(`SELECT uid FROM myday_items WHERE owner_uid = ? AND the_date = ? AND kind = 'google' AND status = 'active'`, [owner, date]).filter((r) => !keep.has(r.uid))
    .forEach((r) => db().run(`UPDATE myday_items SET status = 'archived', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, deviceId(), r.uid]));
  setSetting(`myday_in_${date}`, now);
  return n;
}
// Ask the cloud for the day's meetings (when switched on; not more than every 30 minutes per day).
export function requestMeetings(date = dateStr(), { force = false } = {}) {
  const s = mydaySettings();
  if (!s.calendarIn) return false;
  const last = getSetting(`myday_in_asked_${date}`, '');
  if (!force && last && (clock.now().getTime() - new Date(last.replace(' ', 'T')).getTime()) < 30 * 60000) return false;
  setSetting(`myday_in_asked_${date}`, stamp());
  const owner = calendarOwner();
  enqueue('myday_in', { date, ownerUid: owner ? owner.uid : null });
  return true;
}
// The app tasks of a day, for the separate "Easy Buys – My day" Google calendar (own and private items stay in the app).
export function calendarPayload(ownerUid, day) {
  const plan = dayPlan(ownerUid, day);
  const items = plan.blocks.filter((b) => b.app && !b.overflow).map((b) => ({ key: b.key, title: `${b.late ? '⚠ ' : ''}${b.title}`, start: b.startText, end: b.endText, note: b.deadlineText ? `Deadline ${b.deadlineText}` : '' }));
  return { date: day, calendar: MYDAY_CALENDAR, items };
}
// Send the day's app tasks out when they changed since last time (or when asked).
export function sendDayToCalendar(user, ownerUid, day = dateStr(), { force = false } = {}) {
  const s = mydaySettings();
  need(s.calendarOut || force, 'Sending My day to Google Calendar is switched off (My day › Settings).');
  const p = calendarPayload(ownerUid, day);
  const sig = JSON.stringify(p.items);
  const k = `myday_out_${ownerUid}_${day}`;
  if (!force && getSetting(k, '') === sig) return 0;
  setSetting(k, sig);
  enqueue('myday_out', { ...p, ownerUid });
  if (force) audit({ user, action: `My day ${day} sent to Google Calendar (${p.items.length} tasks)`, table: 'myday_items' });
  return p.items.length;
}
export { dayName };
