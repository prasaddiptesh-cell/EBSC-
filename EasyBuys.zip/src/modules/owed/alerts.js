// Warnings for Home: staff credit near or over the limit, and Aronium settlement receipts missing after pay day.
import { can } from '../../services/access.js';
import { money } from '../../services/core.js';
import { whoOwesUs, settlementsDue, checkCreditLimits, customerAccounts } from './service.js';

export function alerts(user) {
  if (!can(user, 'owed_view')) return [];
  const out = [];
  try { checkCreditLimits(user); } catch (e) { /* notifications only */ }
  const list = whoOwesUs();
  const over = list.filter((p) => p.level === 'over');
  const near = list.filter((p) => p.level === 'approaching');
  if (over.length) out.push({ id: 'owed-over', level: 'urgent', text: `${over.length} staff ${over.length === 1 ? 'member is' : 'members are'} over the credit limit`, sub: over.slice(0, 3).map((p) => `${p.name} ${money(p.credit)} / ${money(p.limit)}`).join(' · '), nav: over.length === 1 ? { screen: 'OwedPerson', params: { uid: over[0].userUid } } : { screen: 'Owed', params: {} } });
  if (near.length) out.push({ id: 'owed-near', level: 'warning', text: `${near.length} staff close to the credit limit`, sub: near.slice(0, 3).map((p) => p.name).join(', '), nav: near.length === 1 ? { screen: 'OwedPerson', params: { uid: near[0].userUid } } : { screen: 'Owed', params: {} } });
  const due = settlementsDue();
  if (due.length && can(user, 'owed_manage')) out.push({ id: 'owed-receipts', level: 'warning', text: `${due.length} Aronium settlement receipt${due.length === 1 ? '' : 's'} missing for staff credit taken from pay`, sub: 'Take a photo of each receipt.', nav: { screen: 'CreditSettlements', params: {} } });
  // v3.9.5 customer accounts (e.g. Daily Needs, bread on a weekly account) not paid on their pay day.
  let acc = [];
  try { acc = customerAccounts().filter((a) => a.late > 0.004); } catch (e) { acc = []; }
  for (const a of acc.slice(0, 4)) {
    out.push({ id: `owed-acct-${a.key}-${a.lastPayDay}`, level: 'warning', text: `${a.name} has not paid: ${money(a.late)} (bought before ${a.payDayName} ${a.dueBy || a.lastPayDay})`, sub: a.lastPayment ? `Last payment ${a.lastPayment.date} ${a.lastPayment.type} ${money(a.lastPayment.amount)}` : 'No payment seen in Aronium.',
      nav: { screen: 'CustomerAccount', params: { name: a.name } } });
  }
  return out;
}
