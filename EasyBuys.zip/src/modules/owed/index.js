// Who owes us: Aronium staff credit (imported balances) + advances, loans and charges from the app; ageing, a page
// and statement per person, credit limits, and Aronium settlement receipts on pay day.
import { OwedScreen, OwedPersonScreen, OwedImportScreen, CreditSettlementsScreen, OwedSettingsScreen, CustomerAccountScreen } from './screens/OwedScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'owed',
  title: 'Who owes us',
  icon: '🧾',
  switchable: false,
  screens: {
    Owed: { component: OwedScreen, can: (u) => can(u, 'owed_view') },
    OwedPerson: { component: OwedPersonScreen, can: (u) => can(u, 'owed_view') },
    OwedImport: { component: OwedImportScreen, can: (u) => can(u, 'owed_manage') },
    CreditSettlements: { component: CreditSettlementsScreen, can: (u) => can(u, 'owed_manage') },
    OwedSettings: { component: OwedSettingsScreen, can: (u) => can(u, 'owed_setup') },
    CustomerAccount: { component: CustomerAccountScreen, can: (u) => can(u, 'owed_view') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
