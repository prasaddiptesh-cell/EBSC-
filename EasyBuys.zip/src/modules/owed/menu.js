// Who owes us menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🧾', title: 'Who owes us', note: 'Everyone, with ageing and credit limits.', screen: 'Owed' },
    { id: 'owed-settle', icon: '📸', title: 'Aronium settlement receipts', note: 'Pay day: a receipt photo for each staff credit deduction.', screen: 'CreditSettlements', perm: 'owed_manage' },
    { id: 'owed-import', icon: '📥', title: 'Bring in Aronium staff credit', note: 'CSV of the staff customer balances.', screen: 'OwedImport', perm: 'owed_manage' },
  ] },
  { section: 'Reports', items: [
    { id: 'owed-report', icon: '📄', title: 'Who owes us (PDF / Excel)', screen: 'ReportsHub', params: { group: 'Who owes us' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'owed-setup', icon: '⚙️', title: 'Credit limits', note: 'Usual limit, approaching level, receipts rule.', screen: 'OwedSettings', perm: 'owed_setup' },
  ] },
];
