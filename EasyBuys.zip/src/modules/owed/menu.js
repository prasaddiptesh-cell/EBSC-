// Who owes us menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🧾', title: 'Who owes us', note: 'Everyone, with ageing and credit limits.', screen: 'Owed' },
    { id: 'owed-settle', icon: '📸', title: 'Aronium settlement receipts', note: 'Pay day: a receipt photo for each staff credit deduction.', screen: 'CreditSettlements', perm: 'owed_manage' },
  ] },
  { section: 'Reports', items: [
    { id: 'owed-report', icon: '📄', title: 'Who owes us (PDF / Excel)', screen: 'ReportsHub', params: { group: 'Who owes us' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'owed-import', icon: '📥', title: 'Aronium back-up import: staff credit (CSV)', note: 'Only when the till PCs cannot send it (they bring it in by themselves).', screen: 'OwedImport', perm: 'owed_manage' },
    { id: 'owed-setup', icon: '⚙️', title: 'Credit limits', note: 'Usual limit, approaching level, receipts rule.', screen: 'OwedSettings', perm: 'owed_setup' },
  ] },
];
