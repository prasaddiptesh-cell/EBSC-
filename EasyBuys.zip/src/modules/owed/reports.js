// Who owes us: the list of everyone (with ageing) and, with a person chosen, that person's statement (PDF / Excel / print).
import { stamp, dateStr } from '../../services/core.js';
import * as O from './service.js';

const { $ } = O;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const LEVEL = { ok: '', approaching: 'Close to the limit', over: 'OVER the limit' };

export function owedSummaryReport(to = dateStr()) {
  const list = O.whoOwesUs({ today: to });
  const t = O.owedTotals(list);
  return {
    kind: 'who_owes_us', title: 'Who Owes Us', fileName: `Who-owes-us-${to}`, subtitle: `Easy Buys Shopping Centre · at ${to}`,
    info: [['At', to], ['Aronium staff credit as at', O.latestCredit().asOf || 'not brought in yet'], ['Generated', stamp()]],
    summary: [{ label: 'Owed to us', value: $(t.total) }, { label: 'People', value: String(t.people) }, { label: 'Over 90 days', value: $(t.ageing.over90), tone: t.ageing.over90 > 0 ? 'bad' : null },
      { label: 'Over the limit', value: String(t.over), tone: t.over ? 'bad' : null }],
    sections: [
      { title: 'Each person', columns: [col('name', 'Name'), col('credit', 'Staff credit', R), col('adv', 'Advances', R), col('loans', 'Loans', R), col('short', 'Till shortages', R), col('other', 'Other charges', R), col('total', 'Total', R), col('limit', 'Credit limit', R), col('level', 'Limit')],
        rows: list.map((p) => ({ name: p.name, credit: $(p.credit), adv: $(p.advances), loans: $(p.loans), short: $(p.tillShort), other: $(p.charges), total: $(p.total), limit: p.limit ? $(p.limit) : '—', level: LEVEL[p.level],
          _tone: p.level === 'over' ? 'bad' : p.level === 'approaching' ? 'warn' : null })) },
      { title: 'Ageing', columns: [col('name', 'Name')].concat(Object.keys(O.AGE_LABEL).map((k) => col(k, O.AGE_LABEL[k], R))),
        rows: list.map((p) => ({ name: p.name, ...Object.fromEntries(Object.keys(O.AGE_LABEL).map((k) => [k, $(p.ageing[k])])), _tone: p.ageing.over90 > 0 ? 'warn' : null })),
        note: 'Staff credit is the balance brought in from Aronium (if not brought in yet: staff credit typed in the app). Advances, loans and charges are less what pay runs have already taken back.' },
    ],
  };
}
export function personStatement(userUid, from, to = dateStr()) {
  const p = O.personOwes(userUid, { today: to });
  const items = p.items.filter((i) => i.open || !from || i.date >= from);
  return {
    kind: 'who_owes_us', title: `Statement – ${p.person.name}`, fileName: `Statement-${p.person.name.replace(/\s+/g, '-')}-${to}`, subtitle: `Easy Buys Shopping Centre · what ${p.person.name} owes at ${to}`,
    info: [['Name', p.person.name], ['Employee no.', p.person.employee_no || '—'], ['At', to], ['Credit limit', p.limit ? $(p.limit) : 'none'], ['Generated', stamp()]],
    summary: [{ label: 'Total owed', value: $(p.total), tone: p.level === 'over' ? 'bad' : null }, { label: 'Staff credit', value: $(p.credit) }, { label: 'Advances & loans', value: $(p.advances + p.loans) },
      { label: 'Till shortages & charges', value: $(p.tillShort + p.charges) }],
    sections: [
      { title: 'Advances, loans and charges', columns: [col('date', 'Date'), col('what', 'What'), col('reason', 'Reason'), col('amount', 'Amount', R), col('repaid', 'Taken from pay', R), col('balance', 'Still owed', R)],
        rows: items.map((i) => ({ date: i.date, what: i.label, reason: i.reason, amount: $(i.amount), repaid: $(i.repaid), balance: $(i.balance), _tone: i.kind === 'till_short' && i.open ? 'warn' : null })) },
      { title: 'Aronium staff credit (balances brought in)', columns: [col('date', 'As at'), col('name', 'Aronium name'), col('since', 'Oldest unpaid'), col('balance', 'Balance', R)],
        rows: p.aronium.map((a) => ({ date: a.as_of, name: a.aronium_name, since: a.since || '', balance: $(a.balance) })) },
      { title: 'Aronium settlement receipts', columns: [col('date', 'Date'), col('no', 'Receipt no.'), col('amount', 'Amount', R)],
        rows: p.settlements.map((s) => ({ date: s.settle_date, no: s.receipt_no || '', amount: $(s.amount) })) },
      { title: 'Ageing', columns: Object.keys(O.AGE_LABEL).map((k) => col(k, O.AGE_LABEL[k], R)), rows: [Object.fromEntries(Object.keys(O.AGE_LABEL).map((k) => [k, $(p.ageing[k])]))] },
    ],
  };
}
export const REPORTS = [
  { id: 'who_owes_us', group: 'Who owes us', icon: '🧾', title: 'Who owes us', desc: 'Staff credit, advances, loans and charges per person, with ageing (a statement when a person is chosen)', perm: 'owed_view',
    build(from, to, user, params = {}) { return params.personUid ? personStatement(params.personUid, from, to) : owedSummaryReport(to); } },
];
