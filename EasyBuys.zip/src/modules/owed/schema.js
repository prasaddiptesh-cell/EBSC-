// Who owes us: staff credit balances brought in from Aronium (CSV), and the Aronium settlement receipts that prove
// each staff credit deduction taken in a pay run was also settled in Aronium.
export const OWED_SQL = `
CREATE TABLE IF NOT EXISTS staff_credit_imports (
  uid TEXT PRIMARY KEY,
  as_of TEXT NOT NULL,
  file_name TEXT,
  people INTEGER, total REAL,
  by_name TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS staff_credit_balances (
  uid TEXT PRIMARY KEY,
  import_uid TEXT NOT NULL,
  as_of TEXT NOT NULL,
  user_uid TEXT,
  aronium_name TEXT,
  aronium_code TEXT,
  balance REAL NOT NULL DEFAULT 0,
  since TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_scb_user ON staff_credit_balances(user_uid, as_of);
CREATE TABLE IF NOT EXISTS credit_settlements (
  uid TEXT PRIMARY KEY,
  run_uid TEXT,
  debt_uid TEXT,
  user_uid TEXT, name TEXT,
  amount REAL,
  receipt_no TEXT,
  settle_date TEXT,
  note TEXT,
  photo_urls TEXT,
  by_name TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const OWED_SYNC = {
  staff_credit_imports: SYNC('uid', 'Who owes us', ['uid', 'as_of', 'file_name', 'people', 'total', 'by_name', 'created_at', 'status', 'void_reason']),
  staff_credit_balances: SYNC('uid', 'Who owes us', ['uid', 'import_uid', 'as_of', 'user_uid', 'aronium_name', 'aronium_code', 'balance', 'since', 'status']),
  credit_settlements: SYNC('uid', 'Who owes us', ['uid', 'run_uid', 'debt_uid', 'user_uid', 'name', 'amount', 'receipt_no', 'settle_date', 'note', 'photo_urls', 'by_name', 'created_at', 'status', 'void_reason']),
};
