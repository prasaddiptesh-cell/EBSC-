// Who owes us: everyone's balance with ageing, a page per person (PDF statement), Aronium staff credit import,
// settlement receipts on pay day, and credit limits.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Section, Select, PhotoPicker, Label, Table, useApp, useUI, Choice } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { pickTextFile } from '../../../platform/files.js';
import * as O from '../service.js';
import { LinkBanner } from '../../aronium/LinkBanner.js';

const { $ } = O;
const LEVEL = { ok: { label: '', color: C.success }, approaching: { label: 'Close to the limit', color: C.warn }, over: { label: 'OVER the limit', color: C.danger } };
const staffOpts = () => O.staffList().filter((u) => u.active).map((u) => ({ value: u.uid, label: u.name }));

export function OwedScreen() {
  const { nav, can } = useApp();
  const list = O.whoOwesUs();
  const t = O.owedTotals(list);
  const credit = O.latestCredit();
  const due = O.settlementsDue();
  return (
    <Screen title="Who owes us" subtitle="Staff credit, advances, loans and charges">
      <Explain>
        Staff credit is kept in Aronium – bring the balances in from Aronium (CSV) to see them here. Advances, staff loans, till shortages and other charges come from the app,
        less what pay runs have already taken back. Tap a person for their page and a PDF statement.
      </Explain>
      <Stats items={[{ label: 'Owed to us', value: $(t.total), sub: `${t.people} people` }, { label: 'Staff credit', value: $(t.credit), sub: credit.asOf ? `Aronium at ${credit.asOf}` : 'not brought in yet' },
        { label: 'Advances & loans', value: $(t.advances + t.loans) }, { label: 'Till shortages & charges', value: $(t.tillShort + t.charges) }]} />
      <Stats items={Object.keys(O.AGE_LABEL).map((k) => ({ label: O.AGE_LABEL[k], value: $(t.ageing[k]), color: k === 'over90' && t.ageing[k] > 0 ? C.danger : undefined }))} />
      {t.over ? <Banner tone="danger" title={`${t.over} over the credit limit`} message={list.filter((p) => p.level === 'over').map((p) => `${p.name}: ${$(p.credit)} (limit ${$(p.limit)})`).join('\n')} /> : null}
      {t.approaching ? <Banner tone="warn" message={`${t.approaching} close to the credit limit.`} /> : null}
      {due.length ? <Banner testID="owed-due" tone="warn" title={`${due.length} Aronium settlement receipt(s) missing`} message="Each staff credit deduction on pay day needs a photo of the Aronium settlement receipt." /> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {can('owed_manage') ? <Btn testID="owed-import" title="Bring in Aronium staff credit" icon="📥" size="md" variant="info" onPress={() => nav.push('OwedImport', {})} /> : null}
        {can('owed_manage') ? <Btn testID="owed-settle" title="Settlement receipts" icon="🧾" size="md" variant={due.length ? 'warn' : 'secondary'} onPress={() => nav.push('CreditSettlements', {})} /> : null}
        <Btn testID="owed-pdf" title="Statement of everyone" icon="📄" size="md" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'who_owes_us', from: dateStr(), to: dateStr() })} />
      </View>
      {(() => {
        let acc = [];
        try { acc = O.customerAccounts(); } catch (e) { acc = []; }
        return acc.length ? (
          <Section title={`Customer accounts (${acc.length})`}>
            {acc.map((a) => (
              <ListItem key={a.key} testID={`acct-${a.key}`} title={a.name} right={$(a.owing)} rightSub={a.late > 0.004 ? `${$(a.late)} not paid since ${a.lateSince}` : ''}
                sub={[`this week ${$(a.thisWeek)} (${a.thisWeekCount} sale${a.thisWeekCount === 1 ? '' : 's'})`, a.lastPayment ? `last paid ${a.lastPayment.date} ${a.lastPayment.type} ${$(a.lastPayment.amount)}` : 'no payment seen yet', `pays on ${a.payDayName}`].join(' · ')}
                badge={a.late > 0.004 ? 'NOT PAID' : undefined} badgeColor={C.danger} tone={a.late > 0.004 ? 'danger' : undefined} onPress={() => nav.push('CustomerAccount', { name: a.name })} />
            ))}
          </Section>
        ) : null;
      })()}
      <Section title={`People (${list.length})`}>
        {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nobody owes anything.</Text> : null}
        {list.map((p) => (
          <ListItem key={p.userUid} testID={`owed-${p.userUid}`} title={p.name} right={$(p.total)} rightSub={p.ageing.over90 > 0 ? `${$(p.ageing.over90)} over 90 days` : ''}
            sub={[p.credit ? `credit ${$(p.credit)}` : '', p.advances ? `advances ${$(p.advances)}` : '', p.loans ? `loans ${$(p.loans)}` : '', p.tillShort ? `till short ${$(p.tillShort)}` : '', p.charges ? `charges ${$(p.charges)}` : ''].filter(Boolean).join(' · ')}
            badge={LEVEL[p.level].label || undefined} badgeColor={LEVEL[p.level].color} tone={p.level === 'over' ? 'danger' : undefined} onPress={() => nav.push('OwedPerson', { uid: p.userUid })} />
        ))}
      </Section>
    </Screen>
  );
}

export function OwedPersonScreen({ params }) {
  const { user, nav, can } = useApp();
  const act = useAct();
  const [limit, setLimit] = useState(null);
  let p = null;
  try { p = params.uid ? O.personOwes(params.uid) : null; } catch (e) { p = null; }
  if (!p) return <Screen title="Who owes us"><Hint>Choose a person from Who owes us.</Hint></Screen>;
  const rules = O.owedRules();
  return (
    <Screen title={p.person.name} subtitle="What they owe us">
      {p.level !== 'ok' ? <Banner testID="op-level" tone={p.level === 'over' ? 'danger' : 'warn'} title={LEVEL[p.level].label} message={`Staff credit ${$(p.credit)} – limit ${$(p.limit)}.`} /> : null}
      <Stats items={[{ label: 'Total owed', value: $(p.total) }, { label: p.creditFrom === 'aronium' ? 'Staff credit (Aronium)' : 'Staff credit', value: $(p.credit) },
        { label: 'Advances & loans', value: $(p.advances + p.loans) }, { label: 'Till shortages & charges', value: $(p.tillShort + p.charges) }]} />
      <Stats items={Object.keys(O.AGE_LABEL).map((k) => ({ label: O.AGE_LABEL[k], value: $(p.ageing[k]), color: k === 'over90' && p.ageing[k] > 0 ? C.danger : undefined }))} />
      <Btn testID="op-pdf" title="Statement (PDF / print / share)" icon="📄" variant="info" onPress={() => nav.push('ReportView', { kind: 'who_owes_us', from: dateStr(), to: dateStr(), personUid: p.person.uid })} />
      {p.due.length ? <Banner tone="warn" title="Aronium settlement receipt missing" message={p.due.map((d) => `${d.payDate}: ${$(d.amount)} taken from pay`).join('\n')} /> : null}
      <Section title="Advances, loans and charges">
        {!p.items.length ? <Text style={{ color: C.sub }}>None.</Text> : null}
        {p.items.map((i) => (
          <ListItem key={i.uid} title={`${i.label} · ${i.date}`} sub={`${i.reason}${i.perPay ? ` · ${$(i.perPay)} a pay` : ''} · taken back ${$(i.repaid)}`} right={$(i.balance)} rightSub={`of ${$(i.amount)}`}
            tone={i.kind === 'till_short' && i.open ? 'danger' : undefined} badge={i.open ? (i.age > 90 ? 'Over 90 days' : undefined) : 'Paid'} badgeColor={i.open ? C.danger : C.success} />
        ))}
      </Section>
      <Section title="Aronium staff credit">
        {!p.aronium.length ? <Text style={{ color: C.sub }}>No Aronium balances brought in for this person.</Text> : null}
        {p.aronium.map((a) => <Row key={a.uid} label={`${a.as_of} · ${a.aronium_name}${a.since ? ` · since ${a.since}` : ''}`} value={$(a.balance)} />)}
      </Section>
      {(() => {
        let tr = [];
        try { tr = O.creditTrail({ userUid: p.person.uid }); } catch (e) { tr = []; }
        return tr.length ? (
          <Section title="Aronium credit sales (the trail)">
            <Hint>Every sale on this person's Aronium account from the till PCs – what was bought, paid or still owing. On pay day the deduction lists the sales it pays.</Hint>
            {tr.slice(0, 60).map((d) => <CreditSale key={`${d.source}-${d.id}`} d={d} />)}
          </Section>
        ) : null;
      })()}
      {p.settlements.length ? (
        <Section title="Settlement receipts">
          {p.settlements.map((s) => <Row key={s.uid} label={`${s.settle_date}${s.receipt_no ? ` · receipt ${s.receipt_no}` : ''}`} value={$(s.amount)} />)}
        </Section>
      ) : null}
      <Card>
        <H>Credit limit</H>
        <Row label="Limit" value={p.limit ? `${$(p.limit)}${rules.limits[p.person.uid] === undefined ? ' (usual limit)' : ''}` : 'No limit'} />
        <Text style={{ color: C.sub }}>Amber from {rules.approachingPct}% of the limit, red at the limit.</Text>
        {can('owed_setup') ? (limit !== null ? (
          <View style={{ gap: 8 }}>
            <MoneyField testID="op-limit" label="Limit for this person (blank = usual limit, 0 = no limit)" value={limit} onChange={setLimit} />
            <Btn testID="op-limit-save" title="Save the limit" size="md" variant="success" onPress={() => { if (act(() => O.setCreditLimit(user, p.person.uid, limit), 'Saved')) setLimit(null); }} />
          </View>
        ) : <Btn testID="op-limit-edit" title="Change the limit" size="md" variant="secondary" onPress={() => setLimit(rules.limits[p.person.uid] === undefined ? '' : String(rules.limits[p.person.uid]))} />) : null}
      </Card>
    </Screen>
  );
}

export function OwedImportScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [text, setText] = useState('');
  const [name, setName] = useState('');
  const [asOf, setAsOf] = useState(dateStr());
  const [who, setWho] = useState({});
  const parsed = useMemo(() => { if (!text) return null; try { return O.readCreditCsv(text); } catch (e) { return { error: e.message }; } }, [text]);
  const rows = parsed && parsed.rows ? parsed.rows.map((r, i) => ({ ...r, userUid: who[i] !== undefined ? who[i] : r.userUid })) : [];
  const bring = () => {
    try {
      if (!parsed || parsed.error) throw Object.assign(new Error(parsed ? parsed.error : 'Choose the file first.'), { isAppError: true });
      O.importStaffCredit(user, { asOf, rows, fileName: name });
      ui.toast('Staff credit brought in');
      nav.replace('Owed', {});
    } catch (e) { ui.error(e); }
  };
  const opts = [{ value: '', label: '— not staff / skip —' }].concat(staffOpts());
  return (
    <Screen title="Aronium staff credit" footer={<Btn testID="oi-bring" title="Bring in these balances" icon="📥" variant="success" onPress={bring} />}>
      <LinkBanner kind={'credit'} />
      <Hint>In Aronium: Management › Customers (staff accounts) › balances › Export to CSV. Copy the file to this tablet and choose it. Aronium itself is never changed.</Hint>
      <DateField label="Balances as at" value={asOf} onChange={setAsOf} />
      <Btn testID="oi-pick" title={name ? `File: ${name}` : 'Choose the CSV file'} icon="📂" variant="info" onPress={async () => { try { const f = await pickTextFile(); if (f) { setText(f.text); setName(f.name); setWho({}); } } catch (e) { ui.error(e); } }} />
      <Field testID="oi-text" label="…or paste the CSV text" value={text.length > 3000 ? `${text.slice(0, 3000)}…` : text} onChangeText={(t) => { if (!t.endsWith('…')) { setText(t); setWho({}); } }} multiline />
      {parsed && parsed.error ? <Banner tone="warn" message={parsed.error} /> : null}
      {rows.length ? (
        <Section title={`${rows.length} balance(s) · ${$(rows.reduce((s, r) => s + r.balance, 0))}`}>
          {parsed.errors.length ? <Banner tone="warn" message={parsed.errors.slice(0, 5).join('\n')} /> : null}
          {rows.map((r, i) => (
            <Card key={i}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: C.text }}>{r.name}{r.code ? ` (${r.code})` : ''} · {$(r.balance)}{r.since ? ` · since ${r.since}` : ''}</Text>
              <Select testID={`oi-who-${i}`} label="Staff member" value={r.userUid || ''} onChange={(v) => setWho({ ...who, [i]: v || null })} options={opts} />
            </Card>
          ))}
        </Section>
      ) : null}
      <Section title="Brought in before">
        {O.listImports().map((i) => (
          <View key={i.uid} style={{ gap: 6 }}>
            <ListItem title={`${i.as_of} · ${i.people} people`} sub={`${i.file_name || ''} · by ${i.by_name}`} right={$(i.total)} />
            <ReasonButton title="Void this import" prompt="Why?" confirm="Void" onDo={(w) => { try { O.voidImport(user, i.uid, w); ui.toast('Voided'); return true; } catch (e) { ui.error(e); return null; } }} />
          </View>
        ))}
        {!O.listImports().length ? <Text style={{ color: C.sub }}>Nothing yet.</Text> : null}
      </Section>
    </Screen>
  );
}

export function CreditSettlementsScreen() {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [f, setF] = useState(null);
  const ap = usePaper('aronium');
  const AR_MAP = { receiptNo: 'receiptNo', date: 'date' };
  const due = O.settlementsDue();
  const done = O.listSettlements({ limit: 30 });
  return (
    <Screen title="Aronium settlement receipts" subtitle="Proof for each staff credit deduction">
      <Explain>
        On pay day, staff credit taken from pay must also be paid off on the person's account in Aronium. Record the payment in Aronium, print the receipt and take a photo of it here.
        Until the photo is added, a warning stays on Home.
      </Explain>
      <Section title={`Waiting for a receipt (${due.length})`}>
        {!due.length ? <Text style={{ fontSize: 16, color: C.sub }}>Every staff credit deduction has its receipt.</Text> : null}
        {due.map((d) => (
          <View key={`${d.runUid}|${d.debtUid}`} style={{ gap: 6 }}>
            <ListItem testID={`cs-${d.debtUid}`} title={`${d.name} · pay day ${d.payDate}`} right={$(d.amount)} badge="Receipt missing" badgeColor={C.warn}
              onPress={() => setF(f && f.debtUid === d.debtUid && f.runUid === d.runUid ? null : { ...d, receiptNo: '', date: dateStr(), photos: [] })} />
            {f && f.debtUid === d.debtUid && f.runUid === d.runUid ? (
              <Card>
                <Field testID="cs-no" label="Aronium receipt number" value={f.receiptNo} onChangeText={(v) => setF({ ...f, receiptNo: v })} />
                <DateField label="Date settled in Aronium" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
                <PaperPhoto pr={ap} testID="cs-photo" label="Photo of the Aronium receipt" value={f.photos} onChange={(v) => setF((o) => ({ ...o, photos: v }))} required form={f} setForm={setF} map={AR_MAP} soft={{ date: dateStr() }}
                  labels={{ receiptNo: 'Aronium receipt number', date: 'Date settled' }} hint="The receipt number and date fill in from the photo; the amount is compared.">
                  {ap.read && ap.read.fields.total !== undefined && f.amount !== undefined && Math.abs(ap.read.fields.total - Number(f.amount)) > 0.004 ? <Banner testID="cs-amtdiff" tone="warn" message={`The receipt shows $${ap.read.fields.total.toFixed(2)} but this settlement is $${Number(f.amount).toFixed(2)}.`} /> : null}
                </PaperPhoto>
                <Btn testID="cs-save" title="Save the receipt" variant="success" onPress={() => { if (!ap.okToSave(ui)) return; if (act(() => O.addSettlement(user, f), 'Saved')) { ap.log(user, 'credit_settlements', f.debtUid, f, AR_MAP); ap.reset(); setF(null); } }} />
              </Card>
            ) : null}
          </View>
        ))}
      </Section>
      {done.length ? (
        <Section title="Recent receipts">
          {done.map((s) => <ListItem key={s.uid} title={`${s.name} · ${s.settle_date}`} sub={s.receipt_no ? `Receipt ${s.receipt_no}` : ''} right={$(s.amount)} />)}
        </Section>
      ) : null}
    </Screen>
  );
}

export function OwedSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = O.owedRules();
  const [f, setF] = useState({ approachingPct: String(r0.approachingPct), defaultLimit: String(r0.defaultLimit), settlementPhoto: r0.settlementPhoto });
  const people = O.staffList().filter((u) => u.active);
  return (
    <Screen title="Credit limits" footer={<Btn testID="ow-save" title="Save" icon="💾" variant="success" onPress={() => act(() => O.saveOwedRules(user, f), 'Saved')} />}>
      <Hint>A limit is for staff credit (Aronium). Amber when someone reaches the "approaching" level, red at the limit – shown on Home, on their page and sent as a notification.</Hint>
      <MoneyField testID="ow-default" label="Usual limit for everyone (0 = no limit)" value={f.defaultLimit} onChange={(v) => setF({ ...f, defaultLimit: v })} />
      <Field testID="ow-pct" label="Approaching level (% of the limit)" value={f.approachingPct} onChangeText={(v) => setF({ ...f, approachingPct: v.replace(/[^0-9]/g, '') })} keyboardType="number-pad" />
      <Choice label="Settlement receipt photo for each staff credit deduction" value={f.settlementPhoto ? 'y' : 'n'} onChange={(v) => setF({ ...f, settlementPhoto: v === 'y' })} testIDPrefix="ow-photo" options={[{ value: 'y', label: 'Needed' }, { value: 'n', label: 'Not needed' }]} />
      <Section title="Own limits">
        {people.map((p) => <Row key={p.uid} label={p.name} value={r0.limits[p.uid] === undefined ? `usual (${r0.defaultLimit ? $(r0.defaultLimit) : 'none'})` : r0.limits[p.uid] ? $(r0.limits[p.uid]) : 'no limit'} />)}
        <Text style={{ color: C.sub }}>Change one person's limit on their page (Who owes us › the person).</Text>
      </Section>
    </Screen>
  );
}

// v3.9.5 one sale on account (from Aronium): date, receipt, what was bought, paid or still owing.
function CreditSale({ d }) {
  const items = (d.items || []).map((i) => `${i[1] && i[1] !== 1 ? `${i[1]} × ` : ''}${i[0]}`).join(', ');
  const paid = (d.moneyPaid || (d.payments || []).filter((x) => x.money !== false));
  return (
    <ListItem title={`${d.date}${d.number ? ` · receipt ${d.number}` : ''}${d.refund ? ' · refund' : ''}${d.shop ? ` · ${d.shop}` : ''}`} sub={[items, paid.length ? `paid ${paid.map((x) => `${x.date} ${x.type} ${$(x.amount)}`).join(', ')}` : ''].filter(Boolean).join(' · ')}
      right={$(d.total)} rightSub={d.open ? `owing ${$(d.owing)}` : 'paid'} badge={d.open ? undefined : 'PAID'} badgeColor={C.success} />
  );
}

// v3.9.5 a customer on account who is not staff (e.g. Daily Needs: bread on a weekly account, paid on Sunday).
export function CustomerAccountScreen({ params = {} }) {
  const { user, can } = useApp();
  const act = useAct();
  const [, bump] = useState(0);
  let a = null;
  try { a = O.customerAccounts({ includeHidden: true }).find((x) => x.name === params.name || x.key === String(params.name || '').toLowerCase()); } catch (e) { a = null; }
  if (!a) return <Screen title="Customer account"><Hint>Not found. The till PCs send customer accounts with the Aronium link (till program 1.2).</Hint></Screen>;
  const sales = O.creditTrail({ name: a.name });
  return (
    <Screen title={a.name} subtitle={`Customer account · pays on ${a.payDayName}${a.shops.length ? ` · ${a.shops.join(', ')}` : ''}`}>
      {a.late > 0.004 ? <Banner testID="acct-late" tone="danger" title="Not paid" message={`${$(a.late)} bought before ${a.dueBy || a.lastPayDay} is still owing (since ${a.lateSince}).`} /> : null}
      <Stats items={[{ label: 'Owing now', value: $(a.owing), color: a.owing > 0.004 ? C.warn : C.success }, { label: 'This week', value: $(a.thisWeek), sub: `${a.thisWeekCount} sale(s)` },
        { label: 'Last payment', value: a.lastPayment ? $(a.lastPayment.amount) : '—', sub: a.lastPayment ? `${a.lastPayment.date} · ${a.lastPayment.type}` : 'none seen' }]} />
      {can('owed_setup') ? (
        <Card>
          <Label>Pays on</Label>
          <Choice value={String(a.payDay)} onChange={(v) => { if (act(() => O.saveAccountSetting(user, a.name, { payDay: Number(v), note: a.note }), 'Saved') !== null) bump((n) => n + 1); }} testIDPrefix="acct-day"
            options={['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((d, i) => ({ value: String(i), label: d }))} />
          <Btn testID="acct-hide" title={a.hidden ? 'Show this account again' : 'Not a customer account (hide)'} size="sm" variant="ghost" onPress={() => { if (act(() => O.saveAccountSetting(user, a.name, { payDay: a.payDay, note: a.note, hide: !a.hidden }), 'Saved') !== null) bump((n) => n + 1); }} />
        </Card>
      ) : null}
      <Section title="Payments">
        {!a.payments.length ? <Text style={{ color: C.sub }}>No payment seen in the last 120 days.</Text> : null}
        {a.payments.map((x, i) => <Row key={i} label={`${x.date} · ${x.type}${x.number ? ` · receipt ${x.number}` : ''}`} value={$(x.amount)} />)}
      </Section>
      <Section title="Sales on account">
        {sales.slice(0, 100).map((d) => <CreditSale key={`${d.source}-${d.id}`} d={d} />)}
      </Section>
    </Screen>
  );
}
