// Who owes us: everything staff owe the business, in one place.
//  • Aronium staff credit – the balances are kept in Aronium; the app brings them in from a CSV export (Customers ›
//    balances) and shows the latest balance per person. Never written back to Aronium.
//  • Advances, staff loans and charges (till shortages, breakages…) recorded in the app (Payroll), less what pay runs
//    have already taken back.
// Ageing (0–30, 31–60, 61–90, over 90 days), a page and a PDF statement per person, credit limits per person with an
// "approaching" level (amber) and over the limit (red), and the pay-day rule: every staff credit deduction taken in a
// pay run needs a photo of the Aronium settlement receipt (the payment recorded on their Aronium account).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared, money } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { notify } from '../verify/service.js';
import { parseCsv } from '../inventory/service.js';
import { listDebts, DEBT_LABEL } from '../payroll/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const days = (from, to) => Math.round((new Date(`${to}T00:00:00`) - new Date(`${String(from).slice(0, 10)}T00:00:00`)) / 86400000);

// ---------------------------------------------------------------- rules (admin)
export const OWED_DEFAULTS = { approachingPct: 80, defaultLimit: 0, limits: {}, settlementPhoto: true };
export function owedRules() {
  const s = getShared('owed_rules', {}) || {};
  return { ...OWED_DEFAULTS, ...s, limits: { ...(s.limits || {}) } };
}
export function saveOwedRules(user, r) {
  const pct = Number(r.approachingPct);
  need(Number.isFinite(pct) && pct > 0 && pct <= 100, 'The "approaching" level must be between 1 and 100 %.');
  const def = Number(r.defaultLimit || 0);
  need(Number.isFinite(def) && def >= 0, 'The usual limit cannot be below zero.');
  const before = owedRules();
  const clean = { approachingPct: Math.round(pct), defaultLimit: r2(def), limits: before.limits, settlementPhoto: r.settlementPhoto !== false };
  setShared('owed_rules', clean);
  audit({ user, action: 'Changed who-owes-us rules (credit limits)', table: 'shared_settings', recordUid: 'owed_rules', before, after: clean });
  return clean;
}
// A person's own limit ('' or null = use the usual limit; 0 = no limit).
export function setCreditLimit(user, userUid, amount) {
  const r = owedRules();
  const before = r.limits[userUid];
  if (amount === '' || amount === null || amount === undefined) delete r.limits[userUid];
  else { const a = Number(amount); need(Number.isFinite(a) && a >= 0, 'The limit cannot be below zero.'); r.limits[userUid] = r2(a); }
  setShared('owed_rules', r);
  audit({ user, action: `Credit limit for ${personName(userUid)}: ${r.limits[userUid] === undefined ? 'usual limit' : $(r.limits[userUid])}`, table: 'shared_settings', recordUid: 'owed_rules', before: { limit: before }, after: { limit: r.limits[userUid] } });
}
export function limitFor(userUid, rules = owedRules()) {
  const own = rules.limits[userUid];
  return own === undefined ? r2(rules.defaultLimit) : r2(own);
}
// 'ok' | 'approaching' (amber) | 'over' (red). No limit (0) is always ok.
export function creditLevel(total, limit, pct = owedRules().approachingPct) {
  if (!(limit > 0)) return 'ok';
  if (total >= limit - 0.004) return 'over';
  if (total >= (limit * pct) / 100 - 0.004) return 'approaching';
  return 'ok';
}
function personName(uid) { try { const u = db().get('SELECT name FROM users WHERE uid = ?', [uid]); return u ? u.name : uid; } catch (e) { return uid; } }

// ---------------------------------------------------------------- Aronium staff credit (CSV)
export const CREDIT_FIELDS = [
  { key: 'name', label: 'Customer (staff) name', need: true, guess: ['name', 'customer', 'customer name', 'client', 'account name', 'staff'] },
  { key: 'balance', label: 'Balance owed', need: true, guess: ['balance', 'amount due', 'due', 'debt', 'owing', 'outstanding', 'total'] },
  { key: 'code', label: 'Customer code', guess: ['code', 'customer code', 'id', 'number', 'account'] },
  { key: 'since', label: 'Oldest unpaid date', guess: ['since', 'oldest', 'first date', 'date', 'last purchase'] },
];
const normH = (h) => txt(h).toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
export function guessCreditMapping(headers) {
  const hs = headers.map(normH); const map = {};
  for (const f of CREDIT_FIELDS) {
    let i = hs.findIndex((h, k) => f.guess.includes(h) && !Object.values(map).includes(k));
    if (i < 0) i = hs.findIndex((h, k) => f.guess.some((g) => h.startsWith(g)) && !Object.values(map).includes(k));
    if (i >= 0) map[f.key] = i;
  }
  return map;
}
const toNum = (v) => {
  let x = txt(v).replace(/[$\s]/g, '');
  if (/^\(.*\)$/.test(x)) x = `-${x.slice(1, -1)}`;
  if (/,\d{1,2}$/.test(x) && !/\.\d/.test(x)) x = x.replace(/\./g, '').replace(',', '.'); else x = x.replace(/,/g, '');
  const n = Number(x); return Number.isFinite(n) ? n : 0;
};
const toDate = (v) => {
  const s = txt(v).split(/[ T]/)[0];
  let m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/.exec(s);
  if (m) return `${m[3].length === 2 ? `20${m[3]}` : m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return null;
};
// The staff list a name could belong to: same name (any case), else the only person whose name starts the same.
export function matchPerson(name, people = staffList()) {
  const n = txt(name).toLowerCase().replace(/\s+/g, ' ');
  if (!n) return null;
  const same = people.find((p) => p.name.toLowerCase().replace(/\s+/g, ' ') === n);
  if (same) return same.uid;
  const first = n.split(' ')[0];
  const starts = people.filter((p) => p.name.toLowerCase().startsWith(n) || n.startsWith(p.name.toLowerCase()) || p.name.toLowerCase().split(' ')[0] === first);
  return starts.length === 1 ? starts[0].uid : null;
}
export function staffList() {
  return db().all("SELECT uid, name, role, shop_code, active FROM users WHERE IFNULL(sync_status,'') <> 'seed' ORDER BY name");
}
// Reads the CSV (nothing saved yet). Each row: Aronium name, code, balance, since, and the staff member it matched.
export function readCreditCsv(text, mapping) {
  const rows = parseCsv(text);
  need(rows.length >= 2, 'The file has no rows.');
  const map = mapping || guessCreditMapping(rows[0]);
  for (const f of CREDIT_FIELDS) if (f.need) need(map[f.key] !== undefined && map[f.key] !== null && map[f.key] !== '', `Match the "${f.label}" column.`);
  const get = (r, k) => (map[k] === undefined || map[k] === null || map[k] === '' ? '' : r[Number(map[k])]);
  const people = staffList();
  const out = []; const errors = [];
  rows.slice(1).forEach((r, i) => {
    if (!r.some((c) => txt(c))) return;
    const name = txt(get(r, 'name'));
    if (!name) { errors.push(`Row ${i + 2}: no name`); return; }
    const since = get(r, 'since') ? toDate(get(r, 'since')) : null;
    out.push({ name, code: txt(get(r, 'code')) || null, balance: r2(toNum(get(r, 'balance'))), since, userUid: matchPerson(name, people) });
  });
  return { rows: out, errors, map, headers: rows[0] };
}
// Saves the balances as at a date. Rows without a staff member chosen are kept (shown as "not matched").
export function importStaffCredit(user, { asOf, rows, fileName }) {
  const d = txt(asOf) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'Enter the date of the Aronium balances (not in the future).');
  need(rows && rows.length, 'Nothing to bring in.');
  const now = stamp(); const dev = deviceId();
  const uid = uuid('SCI');
  const total = r2(rows.reduce((s, r) => s + r2(r.balance), 0));
  db().transaction(() => {
    db().run('INSERT INTO staff_credit_imports (uid, as_of, file_name, people, total, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)',
      [uid, d, txt(fileName) || null, rows.length, total, user.name, now, now, dev]);
    for (const r of rows) {
      db().run('INSERT INTO staff_credit_balances (uid, import_uid, as_of, user_uid, aronium_name, aronium_code, balance, since, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [uuid('SCB'), uid, d, r.userUid || null, txt(r.name), r.code || null, r2(r.balance), r.since || null, now, dev]);
    }
  });
  audit({ user, action: `Aronium staff credit brought in: ${rows.length} people, ${$(total)} as at ${d}`, table: 'staff_credit_imports', recordUid: uid });
  checkCreditLimits(user);
  return uid;
}
export function listImports() { return has('staff_credit_imports') ? db().all("SELECT * FROM staff_credit_imports WHERE status = 'active' ORDER BY as_of DESC, created_at DESC LIMIT 50") : []; }
export function voidImport(user, uid, reason) {
  const i = db().get("SELECT * FROM staff_credit_imports WHERE uid = ? AND status = 'active'", [uid]);
  need(i, 'Not found.');
  require('../../services/access.js').needReason(user, reason, 'Why is it void?');
  const now = stamp(); const dev = deviceId();
  db().run("UPDATE staff_credit_imports SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(reason) || 'Void', now, dev, uid]);
  db().run("UPDATE staff_credit_balances SET status = 'void', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE import_uid = ?", [now, dev, uid]);
  audit({ user, action: `Voided Aronium staff credit import of ${i.as_of}`, table: 'staff_credit_imports', recordUid: uid, reason: txt(reason) || null });
}
// Match a row that was not matched (or matched wrongly) to a staff member.
export function setBalancePerson(user, balanceUid, userUid) {
  const b = db().get('SELECT * FROM staff_credit_balances WHERE uid = ?', [balanceUid]);
  need(b, 'Not found.');
  db().run("UPDATE staff_credit_balances SET user_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [userUid || null, stamp(), deviceId(), balanceUid]);
  audit({ user, action: `Aronium credit "${b.aronium_name}" belongs to ${userUid ? personName(userUid) : 'nobody'}`, table: 'staff_credit_balances', recordUid: balanceUid });
}
// The newest import's balances (each person's latest Aronium balance).
export function latestCredit() {
  const imp = listImports()[0];
  if (!imp) return { asOf: null, rows: [] };
  return { asOf: imp.as_of, importUid: imp.uid, rows: db().all("SELECT * FROM staff_credit_balances WHERE import_uid = ? AND status = 'active' ORDER BY aronium_name", [imp.uid]) };
}

// ---------------------------------------------------------------- who owes us
const AGE = [['d30', 0, 30], ['d60', 31, 60], ['d90', 61, 90], ['over90', 91, 1e9]];
export const AGE_LABEL = { d30: '0–30 days', d60: '31–60 days', d90: '61–90 days', over90: 'Over 90 days' };
function ageInto(ageing, amount, date, today) {
  const n = date ? Math.max(0, days(date, today)) : 0;
  const b = AGE.find(([, lo, hi]) => n >= lo && n <= hi) || AGE[0];
  ageing[b[0]] = r2(ageing[b[0]] + amount);
}
// One line per person who owes anything (or has a limit warning). Aronium credit + app advances, loans and charges.
export function whoOwesUs({ today = dateStr(), includeZero = false } = {}) {
  const rules = owedRules();
  const credit = latestCredit();
  const per = {};
  const get = (uid, name) => (per[uid] = per[uid] || { userUid: uid, name, aronium: 0, aroniumAsOf: credit.asOf, appCredit: 0, advances: 0, loans: 0, tillShort: 0, charges: 0, total: 0,
    ageing: { d30: 0, d60: 0, d90: 0, over90: 0 }, items: 0 });
  const withAronium = new Set();
  for (const b of credit.rows) {
    if (!b.user_uid) continue;
    const p = get(b.user_uid, personName(b.user_uid));
    p.aronium = r2(p.aronium + b.balance);
    withAronium.add(b.user_uid);
    if (b.balance > 0) ageInto(p.ageing, b.balance, b.since || credit.asOf, today);
  }
  let debts = [];
  try { debts = listDebts({}); } catch (e) { debts = []; }
  for (const d of debts) {
    const p = get(d.user_uid, d.name || personName(d.user_uid));
    p.items += 1;
    if (d.kind === 'staff_credit') {
      // Staff credit lives in Aronium: when Aronium balances were brought in for this person they already include it.
      p.appCredit = r2(p.appCredit + d.balance);
      if (withAronium.has(d.user_uid)) continue;
    } else if (d.kind === 'advance') p.advances = r2(p.advances + d.balance);
    else if (d.kind === 'loan') p.loans = r2(p.loans + d.balance);
    else if (d.kind === 'till_short') p.tillShort = r2(p.tillShort + d.balance);
    else p.charges = r2(p.charges + d.balance);
    ageInto(p.ageing, d.balance, d.debt_date, today);
  }
  return Object.values(per).map((p) => {
    const aron = withAronium.has(p.userUid) ? p.aronium : p.appCredit;
    const total = r2(aron + p.advances + p.loans + p.tillShort + p.charges);
    const limit = limitFor(p.userUid, rules);
    return { ...p, credit: r2(aron), creditFrom: withAronium.has(p.userUid) ? 'aronium' : 'app', total, limit, level: creditLevel(aron, limit, rules.approachingPct) };
  }).filter((p) => includeZero || Math.abs(p.total) > 0.004 || p.level !== 'ok').sort((a, b) => b.total - a.total);
}
export function owedTotals(list = whoOwesUs()) {
  const sum = (k) => r2(list.reduce((s, p) => s + (p[k] || 0), 0));
  const ageing = AGE.reduce((o, [k]) => ({ ...o, [k]: r2(list.reduce((s, p) => s + p.ageing[k], 0)) }), {});
  return { people: list.length, total: sum('total'), credit: sum('credit'), advances: sum('advances'), loans: sum('loans'), tillShort: sum('tillShort'), charges: sum('charges'), ageing,
    over: list.filter((p) => p.level === 'over').length, approaching: list.filter((p) => p.level === 'approaching').length };
}
// One person's page: what they owe, each item, Aronium balances over time, settlement receipts.
export function personOwes(userUid, { today = dateStr() } = {}) {
  const u = db().get('SELECT uid, name, role, shop_code, employee_no FROM users WHERE uid = ?', [userUid]);
  need(u, 'Person not found.');
  const row = whoOwesUs({ today, includeZero: true }).find((p) => p.userUid === userUid) || { userUid, name: u.name, aronium: 0, credit: 0, advances: 0, loans: 0, tillShort: 0, charges: 0, total: 0,
    ageing: { d30: 0, d60: 0, d90: 0, over90: 0 }, limit: limitFor(userUid), level: 'ok', creditFrom: 'app' };
  let debts = [];
  try { debts = listDebts({ userUid, open: false }); } catch (e) { debts = []; }
  const items = debts.map((d) => ({ uid: d.uid, date: d.debt_date, kind: d.kind, label: DEBT_LABEL[d.kind] || 'Deduction', reason: d.reason || '', amount: d.amount, repaid: d.repaid, balance: d.balance, perPay: d.repay_per_pay,
    age: days(d.debt_date, today), open: d.balance > 0.004 })).sort((a, b) => (a.date < b.date ? 1 : -1));
  const aronium = has('staff_credit_balances') ? db().all(`SELECT b.* FROM staff_credit_balances b JOIN staff_credit_imports i ON i.uid = b.import_uid AND i.status = 'active' WHERE b.user_uid = ? AND b.status = 'active' ORDER BY b.as_of DESC LIMIT 24`, [userUid]) : [];
  return { person: u, ...row, items, aronium, settlements: listSettlements({ userUid }), due: settlementsDue().filter((s) => s.userUid === userUid) };
}

// ---------------------------------------------------------------- credit limits: warnings and notifications
// Notifies (Viber) when someone moves up to "approaching" or "over" their limit (once per level change).
export function checkCreditLimits(user) {
  const seen = getShared('owed_levels', {}) || {};
  const next = {};
  let changed = false;
  for (const p of whoOwesUs({ includeZero: true })) {
    next[p.userUid] = p.level;
    const was = seen[p.userUid] || 'ok';
    if (p.level !== was) changed = true;
    if (p.level !== 'ok' && p.level !== was && !(was === 'over' && p.level === 'approaching')) {
      try { notify('credit_limit', `${p.name} ${p.level === 'over' ? 'is OVER' : 'is close to'} the staff credit limit: owes ${$(p.credit)} on credit (limit ${$(p.limit)}).`); } catch (e) { /* ignore */ }
    }
  }
  if (changed || Object.keys(seen).some((k) => !(k in next))) setShared('owed_levels', next);
  return next;
}

// ---------------------------------------------------------------- pay day: Aronium settlement receipts
// Every staff credit deduction taken in a final pay run needs a photo of the Aronium settlement receipt.
export function settlementsDue({ since } = {}) {
  if (!has('pay_runs') || !owedRules().settlementPhoto) return [];
  const credit = new Set(has('staff_charges') ? db().all("SELECT uid FROM staff_charges WHERE source = 'staff_credit'").map((r) => r.uid) : []);
  if (!credit.size) return [];
  const done = new Set(has('credit_settlements') ? db().all("SELECT run_uid || '|' || debt_uid AS k FROM credit_settlements WHERE status = 'active'").map((r) => r.k) : []);
  const out = [];
  for (const l of db().all(`SELECT l.run_uid, l.user_uid, l.name, l.deductions, r.pay_date FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 ${since ? 'AND r.pay_date >= ?' : ''}`, since ? [since] : [])) {
    for (const d of J(l.deductions, [])) {
      if (!d.debtUid || !(d.kind === 'staff_credit' || credit.has(d.debtUid))) continue;
      if (done.has(`${l.run_uid}|${d.debtUid}`)) continue;
      out.push({ runUid: l.run_uid, payDate: l.pay_date, userUid: l.user_uid, name: l.name, debtUid: d.debtUid, amount: r2(d.amount) });
    }
  }
  return out.sort((a, b) => (a.payDate < b.payDate ? -1 : 1));
}
export function addSettlement(user, { runUid, debtUid, userUid, amount, receiptNo, date, note, photos = [] }) {
  need((photos || []).length, 'Take a photo of the Aronium settlement receipt.');
  need(userUid, 'Choose the person.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount settled in Aronium.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Enter the date.');
  if (runUid && debtUid) need(!db().get("SELECT 1 AS x FROM credit_settlements WHERE run_uid = ? AND debt_uid = ? AND status = 'active'", [runUid, debtUid]), 'This deduction already has its receipt.');
  const uid = uuid('CS'); const now = stamp();
  db().run(`INSERT INTO credit_settlements (uid, run_uid, debt_uid, user_uid, name, amount, receipt_no, settle_date, note, photo_urls, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?, '[]', ?,?,?,?)`,
    [uid, runUid || null, debtUid || null, userUid, personName(userUid), a, txt(receiptNo) || null, d, txt(note) || null, user.name, now, now, deviceId()]);
  addPhotos('credit_settle', uid, photos);
  audit({ user, action: `Aronium settlement receipt ${txt(receiptNo) || ''} ${$(a)} for ${personName(userUid)}`.replace(/\s+/g, ' '), table: 'credit_settlements', recordUid: uid });
  return uid;
}
export function listSettlements({ userUid, limit = 100 } = {}) {
  if (!has('credit_settlements')) return [];
  return db().all("SELECT * FROM credit_settlements WHERE status = 'active' AND (? IS NULL OR user_uid = ?) ORDER BY settle_date DESC, created_at DESC LIMIT ?", [userUid || null, userUid || null, limit])
    .map((s) => ({ ...s, photos: J(s.photo_urls, []) }));
}
