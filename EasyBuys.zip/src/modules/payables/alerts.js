// Warnings for Home (see src/services/alerts.js): overdue and due invoices, skipped and stale cheques, invoices to check.
import { can } from '../../services/access.js';
import { apAlerts, $, suppliersToSetUp } from './service.js';
import { unrecordedHandovers, listAllBooks } from './chequebooks.js';

const ANY = ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'];
export function alerts(user) {
  if (!ANY.some((p) => can(user, p))) return [];
  const a = apAlerts();
  const s = (n) => (n === 1 ? '' : 's');
  const out = [];
  if (a.overdue.n) out.push({ id: 'ap-overdue', level: 'urgent', text: `${a.overdue.n} supplier invoice${s(a.overdue.n)} overdue – ${$(a.overdue.amount)}`, sub: 'Pay them or agree a new date with the supplier.', nav: { screen: 'ApInvoices', params: { filter: 'overdue' } } });
  if (a.skipped) out.push({ id: 'ap-skipped', level: 'urgent', text: `${a.skipped} cheque number${s(a.skipped)} skipped`, sub: 'A cheque leaf is not recorded. Record it as written or spoiled.', nav: { screen: 'ChequeBooks', params: {} } });
  if (a.dueToday.n) out.push({ id: 'ap-due-today', level: 'warning', text: `${a.dueToday.n} invoice${s(a.dueToday.n)} due today – ${$(a.dueToday.amount)}`, nav: { screen: 'ApInvoices', params: { filter: 'due' } } });
  if (a.stale) out.push({ id: 'ap-stale', level: 'warning', text: `${a.stale} cheque${s(a.stale)} not cleared for months`, sub: 'Check with the supplier.', nav: { screen: 'Cheques', params: { tab: 'register' } } });
  const un = unrecordedHandovers();
  if (un.length && (can(user, 'payments_make') || can(user, 'cheques_manage'))) out.push({ id: 'ap-cheque-unrecorded', level: 'warning', text: `${un.length} cheque${s(un.length)} handed over but not recorded`, sub: `Cheque ${un.map((x) => x.cheque_no).slice(0, 4).join(', ')} – record the payment.`, nav: { screen: 'Verify', params: { kind: 'record' } } });
  const ns = suppliersToSetUp();
  if (ns.length && (can(user, 'ap_setup') || can(user, 'invoices_check'))) out.push({ id: 'ap-sup-setup', level: 'info', text: `${ns.length} supplier${s(ns.length)} to add properly`, sub: `${ns.slice(0, 3).map((x) => x.name).join(', ')} – typed on the photo screen. Add TIN and terms.`, nav: { screen: 'ApSupplierEdit', params: { uid: ns[0].uid } } });
  if (can(user, 'cheques_manage')) {
    const noPhoto = listAllBooks().reduce((n, b) => n + (['in_use', 'spare'].includes(b.status) ? b.noStubPhoto : 0), 0);
    if (noPhoto) out.push({ id: 'ap-stub-photo', level: 'info', text: `${noPhoto} cheque stub${s(noPhoto)} without a photo`, sub: 'Open Cheque books & stubs and add the photos.', nav: { screen: 'ChequeBooks', params: {} } });
  }
  if (a.toCheck && (can(user, 'invoices_check') || can(user, 'ap_setup'))) out.push({ id: 'ap-to-check', level: 'info', text: `${a.toCheck} invoice${s(a.toCheck)} to check`, nav: { screen: 'ApInvoices', params: { filter: 'to_check' } } });
  return out;
}
