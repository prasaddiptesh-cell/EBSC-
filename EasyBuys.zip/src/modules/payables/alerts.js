// Warnings for Home (see src/services/alerts.js): overdue and due invoices, skipped and stale cheques, invoices to check.
import { can } from '../../services/access.js';
import { apAlerts, $, suppliersToSetUp } from './service.js';
import { unrecordedHandovers, listAllBooks } from './chequebooks.js';

const ANY = ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'];
export function alerts(user) {
  // v3.9.2 cheques with no deposit behind them (also for the people who make the deposits)
  const coverFor = ['payments_make', 'cheques_manage', 'deposits', 'till_approve'].some((p) => can(user, p));
  let cover = [];
  if (coverFor) { try { cover = require('./cover.js').coverAlerts(); } catch (e) { cover = []; } }
  if (!ANY.some((p) => can(user, p))) return cover;
  const a = apAlerts();
  const s = (n) => (n === 1 ? '' : 's');
  const out = [];
  if (a.overdue.n) out.push({ id: 'ap-overdue', level: 'urgent', text: `${a.overdue.n} supplier invoice${s(a.overdue.n)} overdue – ${$(a.overdue.amount)}`, sub: 'Pay them or agree a new date with the supplier.', nav: { screen: 'ApInvoices', params: { filter: 'overdue' } } });
  if (a.skipped) out.push({ id: 'ap-skipped', level: 'urgent', text: `${a.skipped} cheque number${s(a.skipped)} skipped`, sub: 'A cheque leaf is not recorded. Record it as written or spoiled.', nav: { screen: 'ChequeBooks', params: {} } });
  if (a.dueToday.n) out.push({ id: 'ap-due-today', level: 'warning', text: `${a.dueToday.n} invoice${s(a.dueToday.n)} due today – ${$(a.dueToday.amount)}`, nav: { screen: 'ApInvoices', params: { filter: 'due' } } });
  if (a.stale) out.push({ id: 'ap-stale', level: 'warning', text: `${a.stale} cheque${s(a.stale)} not cleared for months`, sub: 'Check with the supplier.', nav: { screen: 'Cheques', params: { tab: 'register' } } });
  // build 30 (owner, 10 Nov): entered twice – two phones, offline – found after syncing; void the extra one
  try {
    const dd = require('./service.js').doubleEntries();
    for (const x of dd.invoices.slice(0, 5)) out.push({ id: `ap-double-inv-${x.again.uid}`, level: 'urgent', text: `Invoice ${x.again.invoice_no} from ${x.again.supplier_name} is entered twice`,
      sub: `${x.first.invoice_date} ${$(x.first.total)} and ${x.again.invoice_date} ${$(x.again.total)}. Open the second one and void it if it is the same invoice.`, nav: { screen: 'ApInvoice', params: { uid: x.again.uid } } });
    for (const x of dd.cheques.slice(0, 5)) out.push({ id: `ap-double-chq-${x.again.uid}`, level: 'urgent', text: `Cheque ${x.again.cheque_no} is recorded twice`,
      sub: `${x.first.supplier_name} ${$(x.first.amount)} (${x.first.pay_date}) and ${x.again.supplier_name} ${$(x.again.amount)} (${x.again.pay_date}). Void the wrong payment.`, nav: { screen: 'Cheques', params: {} } });
  } catch (e) { /* never stops Home */ }
  // Release 03: spoiled cheques wait for the owner / an admin; a question goes back to the people who pay
  try {
    const P = require('./chequePlaces.js');
    const sp = P.spoiledToCheck();
    const waiting = sp.filter((c) => c.spoil_check === 'waiting');
    const asked = sp.filter((c) => c.spoil_check === 'query');
    const boss = ['owner', 'admin'].includes(user.role) || (() => { try { return require('../../services/access.js').actsAsOwner(user); } catch (e) { return false; } })();
    if (boss && waiting.length) out.push({ id: 'ap-spoiled-check', level: 'warning', notify: true, text: `${waiting.length} spoiled cheque${s(waiting.length)} to check`, sub: `Cheque ${waiting.slice(0, 4).map((c) => c.cheque_no).join(', ')}: look at the photo and the reason, then confirm.`, nav: { screen: 'ChequeHome', params: { tab: 'spoiled' } } });
    if (asked.length && can(user, 'payments_make')) out.push({ id: 'ap-spoiled-query', level: 'warning', text: `A question about spoiled cheque ${asked[0].cheque_no}`, sub: String(asked[0].spoil_check_note || '').slice(0, 120), nav: { screen: 'ChequeHome', params: { tab: 'spoiled' } } });
  } catch (e) { /* never stops Home */ }
  // Release 03: a regular (weekly) supplier with no invoice this week – needed for the VAT
  if (can(user, 'invoices_enter') || can(user, 'invoices_check')) {
    try {
      const shop = ['supervisor', 'manager', 'staff'].includes(user.role) ? user.shop_code : undefined;
      const miss = require('./regulars.js').missingRegulars({ shop });
      if (miss.length) out.push({ id: 'ap-regular-missing', level: 'warning', notify: true, text: miss.length === 1 ? `No invoice from ${miss[0].supplier} this week` : `${miss.length} regular suppliers: no invoice this week`,
        sub: `${miss.slice(0, 3).map((m) => `${m.supplier}${m.shop ? ` (${m.shop})` : ''} – usually ${m.usualDay}`).join(' · ')}. Add the invoice, or say nothing was bought.`, nav: { screen: 'RegularSuppliers', params: {} } });
    } catch (e) { /* never stops Home */ }
  }
  const un = unrecordedHandovers();
  if (un.length && (can(user, 'payments_make') || can(user, 'cheques_manage'))) out.push({ id: 'ap-cheque-unrecorded', level: 'warning', text: (() => { const g = un.filter((x) => x.kind === 'cheque_given').length; const w = un.length - g; return [g ? `${g} handed over` : '', w ? `${w} written (waiting for pickup)` : ''].filter(Boolean).join(', ') + ` – cheque${s(un.length)} not recorded`; })(), sub: `Cheque ${un.map((x) => x.cheque_no).slice(0, 4).join(', ')} – record the payment.`, nav: { screen: 'Verify', params: { kind: 'record' } } });
  const ns = suppliersToSetUp();
  if (ns.length && (can(user, 'ap_setup') || can(user, 'invoices_check'))) out.push({ id: 'ap-sup-setup', level: 'info', text: `${ns.length} supplier${s(ns.length)} to add properly`, sub: `${ns.slice(0, 3).map((x) => x.name).join(', ')} – typed on the photo screen. Add TIN and terms.`, nav: { screen: 'ApSupplierEdit', params: { uid: ns[0].uid } } });
  // v3.9: order the next cheque book before the last one runs out.
  if (can(user, 'cheques_manage') || can(user, 'payments_make')) {
    try {
      for (const acc of require('./service.js').listAccounts()) {
        const books = listAllBooks({ accountUid: acc.uid });
        if (!books.length) continue; // no cheque books for this account (yet)
        const left = books.filter((b) => ['in_use', 'spare', 'new'].includes(b.status) || b.unused > 0).reduce((n, b) => n + (b.unused || 0), 0);
        if (left <= 5) out.push({ id: `ap-cheques-low-${acc.uid}`, level: left ? 'warning' : 'urgent', text: left ? `${acc.name}: only ${left} cheque${s(left)} left – order a new cheque book` : `${acc.name}: no cheques left in the books – add the new cheque book`, nav: { screen: 'Cheques', params: { tab: 'books' } } });
      }
    } catch (e) { /* no books yet */ }
  }
  if (can(user, 'cheques_manage')) {
    const noPhoto = listAllBooks().reduce((n, b) => n + (['in_use', 'spare'].includes(b.status) ? b.noStubPhoto : 0), 0);
    if (noPhoto) out.push({ id: 'ap-stub-photo', level: 'info', text: `${noPhoto} cheque stub${s(noPhoto)} without a photo`, sub: 'Open Cheque books & stubs and add the photos.', nav: { screen: 'ChequeBooks', params: {} } });
  }
  if (a.part && a.part.n && (can(user, 'payments_make') || can(user, 'invoices_check'))) out.push({ id: 'ap-part-paid', level: 'warning', text: `${a.part.n} invoice${s(a.part.n)} only part paid – ${$(a.part.amount)} still owing`, sub: 'Part payments are allowed; pay the rest or agree it with the supplier.', nav: { screen: 'ApInvoices', params: { filter: 'part' } } });
  if (a.toCheck && (can(user, 'invoices_check') || can(user, 'ap_setup'))) out.push({ id: 'ap-to-check', level: 'info', text: `${a.toCheck} invoice${s(a.toCheck)} to check`, nav: { screen: 'ApInvoices', params: { filter: 'to_check' } } });
  return out.concat(cover);
}
