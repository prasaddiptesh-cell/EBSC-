// 1.0.0 The cheque chain: invoice received → checked → cheque written → waiting for pickup / given to the supplier →
// deposit planned to cover it → slip written → banked (photo of the stamped slip) → shows on the bank → cleared.
// Every step has a date and time and who did it. Steps come from where they already live (the invoice, the payment,
// the hand-over photo, the deposit plan, the cleared cheque) and, where nothing else keeps the time, from cheque_steps.
// Also here: cheques staff wrote that the office still records ("Cheque written"), linking a cheque to the right
// invoice(s), unpaid invoices with no cheque, the supplier page and the supplier standings (week / month).
// Everything is looked up in batches (one pass), so Today stays fast with thousands of records.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays } from '../../services/core.js';
import { can, needReason } from '../../services/access.js';
import { addPhotos } from '../../services/stock.js';
import { assertOpen } from '../../services/lock.js';
import * as AP from './service.js';
import { requirePerm, asService, requireShop } from '../../services/guard.js';

const { r2, $ } = AP;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const SY = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
// IN (...) in chunks (SQLite allows a limited number of ? per statement).
function inChunks(sql, ids, extra = []) {
  const out = [];
  const list = [...new Set(ids.filter(Boolean))];
  for (let i = 0; i < list.length; i += 400) {
    const part = list.slice(i, i + 400);
    out.push(...db().all(sql.replace('(?)', `(${part.map(() => '?').join(',')})`), part.concat(extra)));
  }
  return out;
}

export const STEPS = [
  { key: 'invoice_received', label: 'Invoice received' },
  { key: 'invoice_checked', label: 'Invoice checked' },
  { key: 'written', label: 'Cheque written' },
  { key: 'given', label: 'Given to supplier', wait: 'Waiting for pickup' },
  { key: 'deposit_planned', label: 'Deposit planned to cover it' },
  { key: 'slip_written', label: 'Deposit slip written' },
  { key: 'banked', label: 'Banked (stamped slip)' },
  { key: 'on_bank', label: 'Deposit shows on the bank' },
  { key: 'cleared', label: 'Cheque cleared on the bank' },
];
const LABEL = Object.fromEntries(STEPS.map((s) => [s.key, s.label]));

// ---------------------------------------------------------------- steps kept here
export function addStep(user, { chequeUid, snapUid, step, note, at } = {}) {
  requirePerm(user, ['snap_upload', 'payments_make'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!has('cheque_steps') || !(chequeUid || snapUid) || !step) return null;
  const now = stamp();
  const id = uuid('CS');
  db().run('INSERT INTO cheque_steps (uid, cheque_uid, snap_uid, step, note, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)',
    [id, chequeUid || null, snapUid || null, step, txt(note) || null, user ? user.name : null, user ? user.uid : null, at || now, now, deviceId()]);
  return id;
  });
}
// Once the office records a cheque that staff wrote (or photographed), its steps move over to the cheque.
export function stepsFromSnaps(chequeUid, snaps = []) {
  if (!has('cheque_steps')) return;
  const now = stamp(); const dev = deviceId();
  for (const s of snaps) {
    db().run(`UPDATE cheque_steps SET cheque_uid = ?, ${SY} WHERE snap_uid = ? AND cheque_uid IS NULL`, [chequeUid, now, dev, s.uid]);
    const step = s.kind === 'cheque_written' ? 'written' : 'given';
    if (!db().get('SELECT 1 AS x FROM cheque_steps WHERE cheque_uid = ? AND step = ?', [chequeUid, step])) {
      db().run('INSERT INTO cheque_steps (uid, cheque_uid, snap_uid, step, note, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [uuid('CS'), chequeUid, s.uid, step, step === 'given' && s.collected_by ? `Given to ${s.collected_by}` : null, s.by_name, s.by_uid, s.created_at || now, now, dev]);
    }
  }
}

// ---------------------------------------------------------------- the chain (batched)
// chequeUids → Map(uid → chain). snapUids: cheques staff wrote / photographed that are not recorded yet.
export function chainsFor(chequeUids = [], { snapUids = [] } = {}) {
  const out = new Map();
  const cheques = chequeUids.length ? inChunks('SELECT c.*, a.name AS account_name FROM cheques c LEFT JOIN bank_accounts a ON a.uid = c.account_uid WHERE c.uid IN (?)', chequeUids) : [];
  const payUids = cheques.map((c) => c.payment_uid).filter(Boolean);
  const pays = new Map(inChunks('SELECT * FROM ap_payments WHERE uid IN (?)', payUids).map((p) => [p.uid, p]));
  const allocs = inChunks('SELECT * FROM ap_allocations WHERE payment_uid IN (?) AND amount > 0', payUids);
  const snaps = snapUids.length && has('money_snaps') ? inChunks('SELECT * FROM money_snaps WHERE uid IN (?)', snapUids) : [];
  const linkedSnaps = cheques.length && has('money_snaps') ? inChunks("SELECT * FROM money_snaps WHERE link_table = 'cheques' AND link_uid IN (?) AND status <> 'rejected'", chequeUids) : [];
  const invUids = allocs.map((a) => a.invoice_uid).concat(snaps.flatMap((s) => J(s.invoice_uids, [])));
  const invs = new Map(inChunks('SELECT uid, invoice_no, supplier_uid, supplier_name, shop_code, total, invoice_date, entered_at, entered_by_name, checked_at, checked_by_name, status FROM ap_invoices WHERE uid IN (?)', invUids).map((i) => [i.uid, i]));
  const steps = has('cheque_steps') ? inChunks('SELECT * FROM cheque_steps WHERE cheque_uid IN (?) ORDER BY at', chequeUids).concat(snapUids.length ? inChunks('SELECT * FROM cheque_steps WHERE snap_uid IN (?) AND cheque_uid IS NULL ORDER BY at', snapUids) : []) : [];
  // deposit cover: deposit plans (planned → slip → banked → on the bank) and deposits made with cover ticked
  const plans = has('deposit_plans') ? db().all("SELECT * FROM deposit_plans WHERE status <> 'void'") : [];
  const planFor = new Map();
  for (const p of plans) for (const l of J(p.lines, [])) { if (l.chequeUid) planFor.set(`c:${l.chequeUid}`, p); if (l.invoiceUid) planFor.set(`i:${l.invoiceUid}`, p); if (l.snapUid) planFor.set(`s:${l.snapUid}`, p); }
  const covers = cheques.length && has('cheque_cover') ? inChunks(`SELECT c.cheque_uid, c.invoice_uid, c.by_name, c.created_at, d.uid AS dep_uid, d.deposit_date, d.created_at AS dep_at, d.deposited_by_name, d.slip_no, d.photo_urls, e.cleared_date
    FROM cheque_cover c JOIN deposits d ON d.uid = c.deposit_uid AND d.status = 'active' LEFT JOIN bank_entries e ON e.uid = d.bank_entry_uid WHERE c.status = 'active' AND c.cheque_uid IN (?)`, chequeUids) : [];
  const coverFor = new Map(covers.map((c) => [c.cheque_uid, c]));
  const build = ({ key, cheque, snap, invList, mySteps, plan, cover, pay }) => {
    const st = (k) => mySteps.filter((x) => x.step === k).pop() || null;
    const first = invList.slice().sort((a, b) => String(a.entered_at || '').localeCompare(String(b.entered_at || '')))[0] || null;
    const allChecked = invList.length && invList.every((i) => i.status === 'approved');
    const lastChecked = invList.filter((i) => i.checked_at).sort((a, b) => String(a.checked_at).localeCompare(String(b.checked_at))).pop() || null;
    const given = st('given');
    const handedSnap = linkedSnaps.filter((s) => cheque && s.link_uid === cheque.uid && s.kind === 'cheque_given').pop() || (snap && snap.kind === 'cheque_given' ? snap : null);
    const written = st('written');
    const rows = [
      { key: 'invoice_received', done: !!first, at: first ? first.entered_at : null, by: first ? first.entered_by_name : null, note: invList.length ? invList.map((i) => `${i.invoice_no || '(no number)'} ${$(i.total)}`).join(', ') : 'Not linked to an invoice yet – the office links it' },
      { key: 'invoice_checked', done: !!allChecked, at: allChecked && lastChecked ? lastChecked.checked_at : null, by: allChecked && lastChecked ? lastChecked.checked_by_name : null },
      { key: 'written', done: !!(cheque || snap), at: written ? written.at : pay ? pay.created_at : snap ? snap.created_at : null, by: written ? written.by_name : pay ? pay.paid_by_name : snap ? snap.by_name : cheque ? cheque.written_by_name : null,
        note: cheque ? `Cheque ${cheque.cheque_no} · ${$(cheque.amount)}${cheque.cheque_date && pay && cheque.cheque_date > pay.pay_date ? ` · dated ${cheque.cheque_date}` : ''}` : snap ? `Cheque ${snap.cheque_no} · ${$(snap.amount)} – the office records it` : null },
      { key: 'given', done: !!(given || (cheque && cheque.handed_date) || handedSnap), at: given ? given.at : handedSnap ? handedSnap.created_at : cheque && cheque.handed_date ? cheque.handed_date : null,
        by: given ? given.by_name : handedSnap ? handedSnap.by_name : cheque ? cheque.handed_by_name : null, note: given && given.note ? given.note : cheque && cheque.handed_to ? `Given to ${cheque.handed_to}` : handedSnap && handedSnap.collected_by ? `Given to ${handedSnap.collected_by}` : null },
      { key: 'deposit_planned', done: !!(plan || cover), at: plan ? plan.planned_at : cover ? cover.created_at : null, by: plan ? plan.planned_by_name : cover ? cover.by_name : null, note: plan ? `Deposit for ${plan.plan_date}${plan.shop_code ? ` · ${plan.shop_code}` : ''}` : null, planUid: plan ? plan.uid : null },
      { key: 'slip_written', done: !!((plan && plan.slip_at) || cover), at: plan && plan.slip_at ? plan.slip_at : cover ? cover.dep_at : null, by: plan && plan.slip_at ? plan.slip_by_name : cover ? cover.deposited_by_name : null, note: plan && plan.slip_no ? `Slip ${plan.slip_no}` : cover && cover.slip_no ? `Slip ${cover.slip_no}` : null },
      { key: 'banked', done: !!((plan && plan.banked_at) || cover), at: plan && plan.banked_at ? plan.banked_at : cover ? cover.dep_at || cover.deposit_date : null, by: plan && plan.banked_at ? plan.banked_by_name : cover ? cover.deposited_by_name : null },
      { key: 'on_bank', done: !!((plan && plan.on_bank_at) || (cover && cover.cleared_date)), at: plan && plan.on_bank_at ? plan.on_bank_at : cover ? cover.cleared_date : null, by: plan && plan.on_bank_at ? plan.on_bank_by_name : null },
      { key: 'cleared', done: !!(cheque && cheque.status === 'presented'), at: st('cleared') ? st('cleared').at : cheque ? cheque.presented_date : null, by: st('cleared') ? st('cleared').by_name : cheque ? cheque.presented_by_name : null },
    ].map((r) => ({ ...r, label: r.key === 'given' && !r.done ? 'Waiting for pickup' : LABEL[r.key] }));
    const next = rows.find((r) => !r.done && !(r.key === 'invoice_checked' && !invList.length)) || null;
    const stage = cheque && cheque.status === 'presented' ? 'Cleared' : cheque && ['void', 'spoiled'].includes(cheque.status) ? (cheque.status === 'void' ? 'Void' : 'Spoiled')
      : !rows[3].done ? 'Waiting for pickup' : rows[4].done ? (rows[7].done ? 'Covered – waiting to clear' : 'Deposit planned') : 'Given – not covered';
    const sup = invList[0] ? { uid: invList[0].supplier_uid, name: invList[0].supplier_name } : pay ? { uid: pay.supplier_uid, name: pay.supplier_name } : snap ? { uid: snap.supplier_uid, name: snap.party } : { uid: null, name: cheque ? cheque.payee : '' };
    return { key, chequeUid: cheque ? cheque.uid : null, snapUid: snap ? snap.uid : null, no: cheque ? cheque.cheque_no : snap ? Number(snap.cheque_no) || snap.cheque_no : null,
      amount: r2(cheque ? cheque.amount : snap ? snap.amount : 0), date: cheque ? cheque.cheque_date : snap ? snap.snap_date : null, status: cheque ? cheque.status : 'not_recorded', recorded: !!cheque,
      accountUid: cheque ? cheque.account_uid : snap ? snap.account_uid : null, accountName: cheque ? cheque.account_name : null, paymentUid: cheque ? cheque.payment_uid : null,
      supplierUid: sup.uid, supplierName: sup.name, invoices: invList, linked: invList.length > 0, shop: (invList.find((i) => i.shop_code) || {}).shop_code || (snap ? snap.shop_code : null) || (pay ? pay.shop_code : null),
      steps: rows, next, stage, handedTo: cheque ? cheque.handed_to : snap ? snap.collected_by : null };
  };
  for (const c of cheques) {
    const pay = c.payment_uid ? pays.get(c.payment_uid) : null;
    const invList = allocs.filter((a) => a.payment_uid === c.payment_uid).map((a) => invs.get(a.invoice_uid)).filter(Boolean);
    const plan = planFor.get(`c:${c.uid}`) || invList.map((i) => planFor.get(`i:${i.uid}`)).find(Boolean) || null;
    out.set(c.uid, build({ key: c.uid, cheque: c, snap: null, invList, mySteps: steps.filter((s) => s.cheque_uid === c.uid), plan, cover: coverFor.get(c.uid) || null, pay }));
  }
  for (const s of snaps) {
    const invList = J(s.invoice_uids, []).map((u) => invs.get(u)).filter(Boolean);
    const plan = planFor.get(`s:${s.uid}`) || invList.map((i) => planFor.get(`i:${i.uid}`)).find(Boolean) || null;
    out.set(s.uid, build({ key: s.uid, cheque: null, snap: s, invList, mySteps: steps.filter((x) => x.snap_uid === s.uid), plan, cover: null, pay: null }));
  }
  return out;
}
export function chequeChain(uid) {
  const isCheque = !!db().get('SELECT 1 AS x FROM cheques WHERE uid = ?', [uid]);
  const m = isCheque ? chainsFor([uid]) : chainsFor([], { snapUids: [uid] });
  return m.get(uid) || null;
}
// Every cheque still in the chain (not cleared, not void) plus cheques staff wrote that are not recorded yet.
export function openChains({ shopCode } = {}) {
  const ids = db().all("SELECT uid FROM cheques WHERE status = 'written'").map((x) => x.uid);
  const snapIds = safe(() => require('./chequebooks.js').unrecordedHandovers().map((s) => s.uid), []);
  const m = chainsFor(ids, { snapUids: snapIds });
  return [...m.values()].filter((c) => !shopCode || !c.shop || c.shop === shopCode).sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')));
}

// 1.0.0 build 8 (owner, 2 Nov): the Cheques page from Home – every cheque by where it is now (written and waiting for
// pickup, given, deposit planned, covered, and the ones cleared in the last 30 days), so nothing is lost after "written".
export const BOARD_GROUPS = [
  { key: 'waiting', title: 'Written – waiting for pickup' },
  { key: 'given', title: 'Given to the supplier – deposit not planned' },
  { key: 'planned', title: 'Deposit planned' },
  { key: 'covered', title: 'Covered – waiting to clear' },
  { key: 'cleared', title: 'Cleared (last 30 days)' },
];
const groupOf = (c) => (c.stage === 'Cleared' ? 'cleared' : c.stage === 'Waiting for pickup' ? 'waiting' : c.stage === 'Deposit planned' ? 'planned'
  : c.stage === 'Covered – waiting to clear' ? 'covered' : c.stage === 'Given – not covered' ? 'given' : null);
export function chequeBoard({ shopCode, today = dateStr() } = {}) {
  const since = addDays(today, -30);
  const cleared = safe(() => db().all("SELECT uid FROM cheques WHERE status = 'presented' AND IFNULL(presented_date, cheque_date) >= ?", [since]).map((x) => x.uid), []);
  const done = cleared.length ? [...chainsFor(cleared).values()].filter((c) => !shopCode || !c.shop || c.shop === shopCode) : [];
  const all = openChains({ shopCode }).concat(done);
  return BOARD_GROUPS.map((g) => ({ ...g, list: all.filter((c) => groupOf(c) === g.key).sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))) }));
}

// ---------------------------------------------------------------- staff: "Cheque written"
// Someone who pays suppliers records the payment at once (the invoices must be checked first, as always); anyone else
// saves it for the office to record (it stays on Today until recorded). The cheque number is TYPED – never read by the AI.
// where: 'waiting' (waiting for pickup) | 'given' (given to the supplier: takenBy is the person who took it).
export function chequeWritten(user, { supplierUid, invoiceUids = [], chequeNo, amount, accountUid, where = 'waiting', takenBy, photos = [], date, shopCode, note } = {}) {
  requirePerm(user, ['snap_upload', 'payments_make'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(user, 'Log in first.');
  const sup = AP.getSupplier(supplierUid);
  need(sup, 'Choose the supplier.');
  const raw = txt(chequeNo).replace(/\s/g, '');
  need(/^\d{1,12}$/.test(raw) && Number(raw) > 0, 'Type the cheque number (numbers only, from the cheque).');
  const no = Number(raw);
  const amt = r2(amount);
  need(amt > 0, 'Type the amount on the cheque.');
  need(['waiting', 'given'].includes(where), 'Say where the cheque is now.');
  if (where === 'given') need(txt(takenBy), 'Write the name of the person who took the cheque.');
  need((photos || []).length || ['owner', 'admin'].includes(user.role), 'Take a photo of the cheque (or its stub).');
  const d = txt(date) || dateStr();
  const accounts = AP.listAccounts();
  const acct = accountUid || (accounts.length === 1 ? accounts[0].uid : null);
  // the number must not be used already (recorded, or saved by someone else)
  const used = db().get("SELECT payee, status FROM cheques WHERE cheque_no = ? AND status <> 'void' AND (? IS NULL OR account_uid = ?)", [no, acct, acct]);
  need(!used, `Cheque ${no} is already recorded (${used && used.payee ? used.payee : used && used.status}). Check the number.`);
  const dup = safe(() => db().get("SELECT snap_date, by_name FROM money_snaps WHERE kind IN ('cheque_given','cheque_written') AND status <> 'rejected' AND cheque_no = ?", [no]), null);
  need(!dup, `Cheque ${no} was already saved by ${dup && dup.by_name} on ${dup && dup.snap_date}.`);
  const invs = (invoiceUids || []).filter(Boolean).map((u) => AP.getInvoice(u)).filter(Boolean);
  need(invs.every((i) => i.supplier_uid === sup.uid && i.status !== 'void'), 'An invoice ticked is from another supplier.');
  const shop = txt(shopCode) || (invs.find((i) => i.shop_code) || {}).shop_code || user.shop_code || null;
  // Record it straight away when this person pays suppliers and the invoices are ready to pay.
  const owing = r2(invs.reduce((t, i) => t + i.owing, 0));
  const ready = can(user, 'payments_make') && acct && invs.length && owing >= amt - 0.004 && invs.every((i) => !(AP.apRules().checkBeforePay && i.status === 'to_check'));
  if (ready) {
    let left = amt;
    const allocations = invs.slice().sort((a, b) => String(a.due_date).localeCompare(String(b.due_date))).map((i) => { const a = r2(Math.min(left, i.owing)); left = r2(left - a); return { invoiceUid: i.uid, amount: a }; }).filter((a) => a.amount > 0);
    const p = AP.makePayment(user, { supplierUid: sup.uid, method: 'cheque', accountUid: acct, chequeNo: no, payDate: d, allocations, notes: txt(note) || undefined, photos });
    const c = db().get('SELECT * FROM cheques WHERE payment_uid = ?', [p.uid]);
    addStep(user, { chequeUid: c.uid, step: 'written', note: `Cheque ${no}` });
    if (where === 'given') require('./chequebooks.js').markHandedOver(user, c.uid, { date: d, to: takenBy });
    else addStep(user, { chequeUid: c.uid, step: 'waiting', note: 'Waiting for pickup' });
    return { recorded: true, chequeUid: c.uid, paymentUid: p.uid };
  }
  if (where === 'given') {
    // the hand-over photo does the rest (it stays on Today until the office records the payment)
    const V = require('../verify/service.js');
    const r = V.snap(user, { kind: 'cheque_given', shopCode: shop || 'S1', amount: amt, supplierUid: sup.uid, chequeNo: String(no), accountUid: acct || undefined, invoiceUids: invs.map((i) => i.uid), collectedBy: takenBy, photos, date: d, note });
    addStep(user, { snapUid: r.uid, step: 'written', note: `Cheque ${no}` });
    addStep(user, { snapUid: r.uid, step: 'given', note: `Given to ${txt(takenBy)}` });
    return { recorded: false, snapUid: r.uid };
  }
  const uid = uuid('SN');
  const now = stamp();
  db().run(`INSERT INTO money_snaps (uid, kind, shop_code, snap_date, amount, party, ref_no, note, photo_urls, by_name, by_uid, created_at, status, updated_at, updated_device)
    VALUES (?, 'cheque_written', ?,?,?,?,?,?, '[]', ?,?,?, 'waiting', ?,?)`, [uid, shop || 'S1', d, amt, sup.name, String(no), txt(note) || null, user.name, user.uid, now, now, deviceId()]);
  try { db().run('UPDATE money_snaps SET supplier_uid = ?, cheque_no = ?, account_uid = ?, invoice_uids = ?, cheque_check = ? WHERE uid = ?', [sup.uid, no, acct, invs.length ? JSON.stringify(invs.map((i) => i.uid)) : null, 'unrecorded', uid]); } catch (e) { /* older database */ }
  if ((photos || []).length) addPhotos('snap', uid, photos);
  addStep(user, { snapUid: uid, step: 'written', note: `Cheque ${no}` });
  addStep(user, { snapUid: uid, step: 'waiting', note: 'Waiting for pickup' });
  audit({ user, action: `Cheque ${no} written for ${sup.name} ${$(amt)} – waiting for pickup${invs.length ? '' : ' (no invoice linked yet)'}`, table: 'money_snaps', recordUid: uid });
  try { require('../verify/service.js').notify('cheque_written', `✍️ Cheque ${no} written for ${sup.name} ${$(amt)} by ${user.name} – waiting for pickup.${invs.length ? ` Pays ${invs.map((i) => i.invoice_no || '(no number)').join(', ')}.` : ' ⚠️ Not matched to an invoice yet.'}`, { shopCode: shop }); } catch (e) { /* Viber is optional */ }
  return { recorded: false, snapUid: uid };
  });
}
// The supplier picked the cheque up (a recorded cheque, or one staff wrote that the office has not recorded yet).
export function pickedUp(user, { chequeUid, snapUid, takenBy, date } = {}) {
  requirePerm(user, ['snap_upload', 'payments_make'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(takenBy), 'Write the name of the person who took the cheque.');
  const d = txt(date) || dateStr();
  if (chequeUid) { require('./chequebooks.js').markHandedOver(user, chequeUid, { date: d, to: takenBy }); return; }
  const s = db().get('SELECT * FROM money_snaps WHERE uid = ?', [snapUid]);
  need(s && s.kind === 'cheque_written' && s.status !== 'rejected', 'This cheque is not waiting for pickup.');
  const now = stamp();
  db().run(`UPDATE money_snaps SET kind = 'cheque_given', collected_by = ?, ${SY} WHERE uid = ?`, [txt(takenBy), now, deviceId(), snapUid]);
  addStep(user, { snapUid, step: 'given', note: `Given to ${txt(takenBy)}` });
  audit({ user, action: `Cheque ${s.cheque_no} given to ${txt(takenBy)}`, table: 'money_snaps', recordUid: snapUid });
  });
}

// ---------------------------------------------------------------- staff: "Paid a supplier in cash"
// cashFrom: 'safe' | 'till:<uid>'. Someone who pays suppliers records the payment at once (the invoice checked first);
// anyone else saves the receipt photo for the office (Today), with what it paid and where the cash came from.
export function cashPaid(user, { supplierUid, invoiceUid, amount, cashFrom, shopCode, photos = [], date, note } = {}) {
  requirePerm(user, ['snap_upload', 'payments_make'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(user, 'Log in first.');
  const sup = AP.getSupplier(supplierUid);
  need(sup, 'Choose the supplier.');
  const amt = r2(amount);
  need(amt > 0, 'Type the amount paid.');
  need(txt(cashFrom) === 'safe' || /^till:.+/.test(txt(cashFrom)), 'Say where the cash came from: the safe, or which till.');
  need((photos || []).length || ['owner', 'admin'].includes(user.role), 'Take a photo of their receipt.');
  const shop = txt(shopCode) || user.shop_code;
  need(shop, 'Choose the shop.');
  const d = txt(date) || dateStr();
  const inv = invoiceUid ? AP.getInvoice(invoiceUid) : null;
  if (invoiceUid) need(inv && inv.supplier_uid === sup.uid, 'That invoice is from another supplier.');
  if (inv && can(user, 'payments_make')) {
    if (inv.status === 'to_check' && (can(user, 'invoices_check') || ['owner', 'admin'].includes(user.role))) { try { AP.checkInvoice(user, inv.uid); } catch (e) { /* left to check */ } }
    need(amt <= AP.getInvoice(inv.uid).owing + 0.004, `Invoice ${inv.invoice_no || ''} only has ${$(AP.getInvoice(inv.uid).owing)} owing.`);
    const p = AP.makePayment(user, { supplierUid: sup.uid, method: 'cash', shopCode: shop, cashFrom: txt(cashFrom), payDate: d, receivedBy: sup.name, notes: txt(note) || 'Paid in cash', allocations: [{ invoiceUid: inv.uid, amount: amt }], photos });
    return { recorded: true, paymentUid: p.uid };
  }
  let from = 'the safe';
  if (/^till:/.test(cashFrom)) { const t = safe(() => db().get('SELECT name FROM tills WHERE uid = ?', [cashFrom.slice(5)]), null); from = t ? t.name : 'a till'; }
  const r = require('../verify/service.js').snap(user, { kind: 'receipt', shopCode: shop, amount: amt, party: sup.name, refNo: inv ? inv.invoice_no || '' : '', photos: photos.length ? photos : ['(no photo)'], date: d,
    note: `Paid ${sup.name} in cash from ${from}${inv ? ` for invoice ${inv.invoice_no || '(no number)'}` : ''} – the office records the payment${txt(note) ? ` · ${txt(note)}` : ''}` });
  try { db().run('UPDATE money_snaps SET supplier_uid = ?, invoice_uids = ? WHERE uid = ?', [sup.uid, inv ? JSON.stringify([inv.uid]) : null, r.uid]); } catch (e) { /* older database */ }
  return { recorded: false, snapUid: r.uid };
  });
}

// ---------------------------------------------------------------- the office links a cheque to its invoice(s)
// A recorded cheque: what it pays moves to the invoices chosen (same supplier, the cheque amount spread over what they
// owe, oldest due first). A cheque staff wrote and the office has not recorded: the invoices are noted on it.
export function linkInvoices(user, { chequeUid, snapUid, invoiceUids = [], reason } = {}) {
  requirePerm(user, 'invoices_check', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (can(user, 'payments_make') || ['owner', 'admin'].includes(user.role)), 'Only the office (paying suppliers) links cheques to invoices.');
  const list = (invoiceUids || []).filter(Boolean).map((u) => AP.getInvoice(u)).filter(Boolean);
  need(list.length, 'Tick the invoice(s) this cheque pays.');
  if (snapUid) {
    const s = db().get('SELECT * FROM money_snaps WHERE uid = ?', [snapUid]);
    need(s && ['cheque_given', 'cheque_written'].includes(s.kind), 'Cheque not found.');
    need(list.every((i) => !s.supplier_uid || i.supplier_uid === s.supplier_uid), 'An invoice is from another supplier.');
    const now = stamp();
    db().run(`UPDATE money_snaps SET invoice_uids = ?, ${SY} WHERE uid = ?`, [JSON.stringify(list.map((i) => i.uid)), now, deviceId(), snapUid]);
    addStep(user, { snapUid, step: 'linked', note: `Linked to ${list.map((i) => i.invoice_no || '(no number)').join(', ')}` });
    audit({ user, action: `Cheque ${s.cheque_no} linked to invoice(s) ${list.map((i) => i.invoice_no || '?').join(', ')}`, table: 'money_snaps', recordUid: snapUid, reason: txt(reason) || null });
    return;
  }
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
  need(c && c.payment_uid, 'Cheque not found.');
  const p = AP.getPayment(c.payment_uid);
  need(p && p.status === 'active', 'The payment for this cheque was voided.');
  assertOpen(p.pay_date, 'This payment');
  need(list.every((i) => i.supplier_uid === p.supplier_uid && i.kind === 'invoice' && i.status !== 'void'), `Choose invoices from ${p.supplier_name}.`);
  const mine = new Map(db().all('SELECT invoice_uid, SUM(amount) AS a FROM ap_allocations WHERE payment_uid = ? GROUP BY invoice_uid', [p.uid]).map((x) => [x.invoice_uid, r2(x.a)]));
  // what each chosen invoice could take if this cheque no longer paid anything
  const room = list.map((i) => ({ i, room: r2(i.owing + (mine.get(i.uid) || 0)) }));
  const total = r2(room.reduce((t, x) => t + x.room, 0));
  need(total >= p.amount - 0.004, `The invoices ticked only have ${$(total)} owing – the cheque is ${$(p.amount)}. Tick more invoices.`);
  needReason(user, reason, 'Say why the cheque is linked to a different invoice.');
  let left = r2(p.amount);
  const now = stamp(); const dev = deviceId();
  db().transaction(() => {
    db().run(`UPDATE ap_allocations SET amount = 0, ${SY} WHERE payment_uid = ?`, [now, dev, p.uid]); // kept (0) so every device sees the change
    for (const x of room.sort((a, b) => String(a.i.due_date).localeCompare(String(b.i.due_date)))) {
      const a = r2(Math.min(left, x.room));
      if (a <= 0) continue;
      left = r2(left - a);
      db().run('INSERT INTO ap_allocations (uid, payment_uid, invoice_uid, amount, updated_at, updated_device) VALUES (?,?,?,?,?,?)', [uuid('AL'), p.uid, x.i.uid, a, now, dev]);
    }
  });
  addStep(user, { chequeUid: c.uid, step: 'linked', note: `Linked to ${list.map((i) => i.invoice_no || '(no number)').join(', ')}` });
  audit({ user, action: `Cheque ${c.cheque_no} now pays ${list.map((i) => i.invoice_no || '?').join(', ')}`, table: 'ap_payments', recordUid: p.uid, reason: txt(reason) || null });
  });
}

// ---------------------------------------------------------------- unpaid invoices with no cheque
// An invoice still owing that no cheque (recorded, or written by staff and not recorded yet) and no deposit plan is
// paying: it keeps flagging until it is paid. One pass.
export function unpaidNoCheque({ shopCode, today = dateStr() } = {}) {
  const unpaid = AP.listInvoices({ filter: 'unpaid', limit: 20000 }).filter((i) => i.kind === 'invoice' && i.owing > 0.004 && i.status !== 'void' && (!shopCode || !i.shop_code || i.shop_code === shopCode));
  const onCheque = new Set();
  safe(() => require('./chequebooks.js').unrecordedHandovers(), []).forEach((s) => J(s.invoice_uids, []).forEach((u) => onCheque.add(u)));
  // cigarette invoices are paid from the cigarette fund (their own status line)
  const cig = new Set(safe(() => require('../till/cigTally.js').cigRules().suppliers || [], []));
  return unpaid.filter((i) => !onCheque.has(i.uid) && !cig.has(i.supplier_uid)).map((i) => ({ ...i, days: Math.max(0, Math.round((Date.parse(`${today}T00:00:00`) - Date.parse(`${i.invoice_date}T00:00:00`)) / 86400000)) }));
}
export function unpaidNoChequeBySupplier(opts) {
  const m = new Map();
  for (const i of unpaidNoCheque(opts)) {
    const s = m.get(i.supplier_uid) || { supplierUid: i.supplier_uid, name: i.supplier_name, count: 0, owing: 0, oldestDue: i.due_date, overdue: 0, shop: i.shop_code, list: [] };
    s.count += 1; s.owing = r2(s.owing + i.owing); if (i.due === 'overdue') s.overdue += 1; if (String(i.due_date) < String(s.oldestDue)) s.oldestDue = i.due_date; s.list.push(i);
    m.set(i.supplier_uid, s);
  }
  return [...m.values()].sort((a, b) => String(a.oldestDue).localeCompare(String(b.oldestDue)));
}

// ---------------------------------------------------------------- supplier standings (weekly / monthly)
export function periodOf(period = 'week', today = dateStr()) {
  if (period === 'month') return { from: `${today.slice(0, 7)}-01`, to: today, label: 'This month' };
  // the pay week runs Saturday → Friday; the supplier week follows it
  const d = new Date(`${today}T12:00:00`);
  const back = (d.getDay() + 1) % 7;
  return { from: addDays(today, -back), to: today, label: 'This week' };
}
export function supplierStandings({ period = 'week', today = dateStr(), shopCode } = {}) {
  const p = periodOf(period, today);
  const unpaid = AP.listInvoices({ filter: 'unpaid', limit: 20000 }).filter((i) => i.kind === 'invoice' && (!shopCode || !i.shop_code || i.shop_code === shopCode));
  const noChq = new Set(unpaidNoCheque({ shopCode, today }).map((i) => i.uid));
  const inPeriod = db().all("SELECT supplier_uid, COUNT(*) AS n, SUM(total) AS t FROM ap_invoices WHERE status <> 'void' AND kind = 'invoice' AND invoice_date BETWEEN ? AND ? AND (? IS NULL OR shop_code = ? OR shop_code IS NULL) GROUP BY supplier_uid", [p.from, p.to, shopCode || null, shopCode || null]);
  const paidIn = db().all("SELECT supplier_uid, SUM(amount) AS t FROM ap_payments WHERE status = 'active' AND method <> 'credit' AND pay_date BETWEEN ? AND ? GROUP BY supplier_uid", [p.from, p.to]);
  const chains = openChains({ shopCode });
  const owed = safe(() => require('../inventory/supplierOwed.js').owedBySupplier(), []);
  const m = new Map();
  const row = (uid, name) => { if (!m.has(uid)) m.set(uid, { supplierUid: uid, name, owing: 0, overdue: 0, noCheque: 0, noChequeOwing: 0, invoices: 0, invoiced: 0, paid: 0, waiting: 0, given: 0, notCleared: 0, owesUs: 0, nextDue: null, flags: [] }); return m.get(uid); };
  for (const i of unpaid) {
    const r = row(i.supplier_uid, i.supplier_name);
    r.owing = r2(r.owing + i.owing); if (i.due === 'overdue') r.overdue = r2(r.overdue + i.owing);
    if (noChq.has(i.uid)) { r.noCheque += 1; r.noChequeOwing = r2(r.noChequeOwing + i.owing); }
    if (!r.nextDue || String(i.due_date) < r.nextDue) r.nextDue = i.due_date;
  }
  const name = (uid) => (AP.getSupplier(uid) || {}).name || '';
  for (const x of inPeriod) { const r = row(x.supplier_uid, name(x.supplier_uid)); r.invoices = x.n; r.invoiced = r2(x.t); }
  for (const x of paidIn) { const r = row(x.supplier_uid, name(x.supplier_uid)); r.paid = r2(x.t); }
  for (const c of chains) { if (!c.supplierUid) continue; const r = row(c.supplierUid, c.supplierName); if (!c.steps[3].done) r.waiting += 1; else r.given += 1; r.notCleared = r2(r.notCleared + c.amount); }
  for (const o of owed) { if (!m.has(o.supplierUid) && !o.value) continue; row(o.supplierUid, o.name).owesUs = r2(o.value); }
  for (const r of m.values()) {
    if (r.noCheque) r.flags.push(`${r.noCheque} unpaid, no cheque`);
    if (r.overdue) r.flags.push(`${$(r.overdue)} overdue`);
    if (r.waiting) r.flags.push(`${r.waiting} cheque${r.waiting === 1 ? '' : 's'} waiting for pickup`);
    if (r.given) r.flags.push(`${r.given} cheque${r.given === 1 ? '' : 's'} given, not cleared`);
    if (r.owesUs) r.flags.push(`owes us ${$(r.owesUs)} (damaged / short)`);
  }
  const list = [...m.values()].filter((r) => r.owing || r.invoices || r.paid || r.notCleared || r.owesUs).sort((a, b) => (b.noCheque - a.noCheque) || (b.owing - a.owing));
  return { ...p, period, list, totals: { owing: r2(list.reduce((t, r) => t + r.owing, 0)), noCheque: list.reduce((t, r) => t + r.noCheque, 0), noChequeOwing: r2(list.reduce((t, r) => t + r.noChequeOwing, 0)), notCleared: r2(list.reduce((t, r) => t + r.notCleared, 0)), invoiced: r2(list.reduce((t, r) => t + r.invoiced, 0)), paid: r2(list.reduce((t, r) => t + r.paid, 0)) } };
}

// ---------------------------------------------------------------- the supplier page
// Statement in and out (with each cheque's chain), unpaid invoices flagged, their products, what they owe us.
export function supplierPage(supplierUid, { from, to = dateStr() } = {}) {
  const sup = AP.getSupplier(supplierUid);
  need(sup, 'Supplier not found.');
  const f = from || addDays(to, -90);
  let st = null;
  try { st = require('./statement.js').supplierStatement(supplierUid, f, to); } catch (e) { st = null; }
  const chqIds = db().all(`SELECT c.uid FROM cheques c JOIN ap_payments p ON p.uid = c.payment_uid WHERE p.supplier_uid = ? AND p.status = 'active' AND (c.status = 'written' OR c.cheque_date >= ?)`, [supplierUid, f]).map((x) => x.uid);
  const snapIds = safe(() => require('./chequebooks.js').unrecordedHandovers().filter((s) => s.supplier_uid === supplierUid).map((s) => s.uid), []);
  const chains = [...chainsFor(chqIds, { snapUids: snapIds }).values()].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
  const owing = AP.listInvoices({ filter: 'unpaid', supplierUid }).filter((i) => i.kind === 'invoice');
  const noCheque = new Set(unpaidNoCheque({}).filter((i) => i.supplier_uid === supplierUid).map((i) => i.uid));
  let products = [];
  try {
    const I = require('../inventory/service.js');
    products = I.supplierProducts(supplierUid, { limit: 2000 }).map((p) => ({ uid: p.uid, name: p.name, code: p.code, supplierCode: p.supplierCode, lastCost: p.lastCost, lastDate: p.lastDate, pack: Number(p.pack_size) || 1, unit: p.unit }));
  } catch (e) { products = []; }
  const owed = safe(() => require('../inventory/supplierOwed.js').listOwed({ supplierUid }), []);
  return {
    supplier: sup, from: f, to, statement: st, chains,
    owing: owing.map((i) => ({ ...i, noCheque: noCheque.has(i.uid) })), owingTotal: r2(owing.reduce((t, i) => t + i.owing, 0)), noChequeCount: noCheque.size,
    products, owed,
  };
}
