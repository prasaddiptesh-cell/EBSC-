// Release 03 (owner, 12 Nov): where each cheque book is, spare books, and spoiled cheques checked by the owner / an admin.
// - A book has a place: a shop, a vehicle, the office or a person – moved at any time (spare, in use or finished), each
//   move kept (who, when, from, to, note) in the book's own "moves" list.
// - A new book is a spare until its first leaf is used; then it is the book in use. Using a spare while a book in use
//   at the same place still has leaves left asks first (a reason from staff; the owner and admins need none).
// - A spoiled cheque (reason + photo, always) waits for the owner or an admin: Confirmed, or a question back.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit } from '../../services/core.js';
import { requirePerm, requireLogin, asService } from '../../services/guard.js';
import { needReason, actsAsOwner } from '../../services/access.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };

// The places a book can be: each shop, each vehicle, the office, a person (typed).
export function bookPlaces() {
  const out = [];
  try { db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort, code').forEach((s) => out.push({ key: `shop:${s.code}`, label: s.name || s.code, kind: 'shop' })); } catch (e) { /* no shops */ }
  try { db().all("SELECT uid, name, rego FROM ve_items WHERE kind = 'vehicle' AND COALESCE(status, 'active') = 'active' ORDER BY name").forEach((v) => out.push({ key: `vehicle:${v.uid}`, label: `${v.name}${v.rego && !String(v.name).includes(v.rego) ? ` (${v.rego})` : ''}`, kind: 'vehicle' })); } catch (e) { /* no vehicles */ }
  out.push({ key: 'office', label: 'Office', kind: 'office' });
  return out;
}
export function placeLabel(key) {
  const k = txt(key);
  if (!k) return 'Not set';
  if (k.startsWith('person:')) return `With ${k.slice(7)}`;
  const p = bookPlaces().find((x) => x.key === k);
  return p ? p.label : k.replace(/^[a-z]+:/, '');
}
export function bookMoves(book) { return J(book && book.moves, []); }

export function moveBook(user, bookUid, { to, person, note } = {}) {
  requirePerm(user, 'cheques_manage', { money: true });
  return asService(() => {
    const b = db().get('SELECT * FROM cheque_books WHERE uid = ?', [bookUid]);
    need(b, 'Cheque book not found.');
    const dest = txt(person) ? `person:${txt(person)}` : txt(to);
    need(dest, 'Where is the book going?');
    need(dest !== txt(b.location), 'The book is there already.');
    const now = stamp();
    const moves = bookMoves(b).concat([{ at: now, by: user.name, from: txt(b.location) || null, to: dest, note: txt(note) || null, state: b.status || 'in_use' }]).slice(-100);
    db().run("UPDATE cheque_books SET location = ?, moves = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [dest, JSON.stringify(moves), now, deviceId(), bookUid]);
    audit({ user, action: `Cheque book ${b.first_no}–${b.last_no} moved: ${placeLabel(b.location)} → ${placeLabel(dest)}`, table: 'cheque_books', recordUid: bookUid, reason: txt(note) || null });
    return { ...b, location: dest, moves };
  });
}

// A leaf of a spare book was used: it is the book in use now.
export function startBookIfSpare(bookUid, user) {
  const b = bookUid ? db().get('SELECT * FROM cheque_books WHERE uid = ?', [bookUid]) : null;
  if (!b || b.status !== 'spare') return false;
  db().run("UPDATE cheque_books SET status = 'in_use', active = 1, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [stamp(), deviceId(), bookUid]);
  audit({ user, action: `Cheque book ${b.first_no}–${b.last_no} started (was a spare)`, table: 'cheque_books', recordUid: bookUid });
  return true;
}

// Before a cheque from a spare book: a book in use at the same place (or anywhere, when the spare has no place) that
// still has leaves left. → null, or { book, from, to, left, message }
export function spareWarning(accountUid, chequeNo) {
  const no = Math.round(Number(chequeNo));
  const b = db().get('SELECT * FROM cheque_books WHERE account_uid = ? AND ? BETWEEN first_no AND last_no ORDER BY active DESC LIMIT 1', [accountUid, no]);
  if (!b || b.status !== 'spare') return null;
  const others = db().all("SELECT * FROM cheque_books WHERE account_uid = ? AND uid <> ? AND COALESCE(status, CASE active WHEN 1 THEN 'in_use' ELSE 'finished' END) = 'in_use'", [accountUid, b.uid])
    .filter((o) => !b.location || !o.location || o.location === b.location);
  for (const o of others) {
    const used = db().all('SELECT cheque_no FROM cheques WHERE account_uid = ? AND cheque_no BETWEEN ? AND ?', [accountUid, o.first_no, o.last_no]).map((r) => r.cheque_no);
    const top = used.length ? Math.max(...used) : o.first_no - 1;
    if (top < o.last_no) {
      const from = top + 1;
      return { book: o, from, to: o.last_no, left: o.last_no - top, message: `Cheque ${no} starts a spare book. The book in use${o.location ? ` at ${placeLabel(o.location)}` : ''} still has cheques ${from}–${o.last_no}. Use those first?` };
    }
  }
  return null;
}
// Writing from a spare book anyway: staff say why (the owner and admins need not).
export function confirmSpare(user, accountUid, chequeNo, reason) {
  requireLogin(user);
  const w = spareWarning(accountUid, chequeNo);
  if (!w) return true;
  needReason(user, reason, 'Say why a new cheque book is started while the one in use still has cheques.');
  audit({ user, action: `Spare cheque book started at cheque ${chequeNo} although book ${w.book.first_no}–${w.book.last_no} still has ${w.left} left`, table: 'cheque_books', recordUid: w.book.uid, reason: txt(reason) || null });
  return true;
}

// ---------------------------------------------------------------- spoiled cheques: checked by the owner / an admin
const mayCheck = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
export function spoiledToCheck() {
  try {
    // spoiled before Release 03 (no check asked then) are left as they are
    return db().all("SELECT * FROM cheques WHERE status = 'spoiled' AND spoil_check IN ('waiting', 'query') ORDER BY cheque_date");
  } catch (e) { return []; }
}
export function checkSpoiled(user, chequeUid, { ok, note } = {}) {
  requireLogin(user);
  return asService(() => {
    if (!mayCheck(user)) throw new AppError('Only the owner or an admin checks spoiled cheques.');
    const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
    need(c && c.status === 'spoiled', 'This cheque is not recorded as spoiled.');
    if (!ok) need(txt(note), 'Write the question for the person who recorded it.');
    const now = stamp();
    db().run("UPDATE cheques SET spoil_check = ?, spoil_check_by = ?, spoil_check_at = ?, spoil_check_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      [ok ? 'ok' : 'query', user.name, now, txt(note) || null, now, deviceId(), chequeUid]);
    audit({ user, action: `Spoiled cheque ${c.cheque_no} ${ok ? 'confirmed' : 'queried'}${note ? `: ${txt(note)}` : ''}`, table: 'cheques', recordUid: chequeUid });
    return { ok: true };
  });
}
// The person who recorded it answers a question: back to the owner / admin.
export function answerSpoiled(user, chequeUid, answer) {
  requirePerm(user, 'payments_make', { money: true });
  return asService(() => {
    const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
    need(c && c.status === 'spoiled' && c.spoil_check === 'query', 'Nothing was asked about this cheque.');
    need(txt(answer), 'Write the answer.');
    const now = stamp();
    db().run("UPDATE cheques SET spoil_check = 'waiting', spoil_check_by = NULL, spoil_check_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      [`${txt(c.spoil_check_note)} → ${user.name}: ${txt(answer)}`.slice(0, 500), now, deviceId(), chequeUid]);
    audit({ user, action: `Spoiled cheque ${c.cheque_no}: answered`, table: 'cheques', recordUid: chequeUid, reason: txt(answer) });
    return { ok: true };
  });
}
