// Cheque books & stubs (v3.5 B2): every book with its serial, leaf range, date received, who holds it and its
// status; every leaf opens its stub record (date, payee, amount, invoices, who wrote it, who it was handed to,
// stub photo, cleared date). Also the checks used when a cheque is handed over (photo screen): which cheques were
// written for a supplier, the next unused number, and what is wrong with a typed number.
import { db, keepUntilChanged } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr } from '../../services/core.js';
import { addPhotos, listPhotos } from '../../services/stock.js';
import * as AP from './service.js';
import { requirePerm, asService } from '../../services/guard.js';

const { $, r2 } = AP;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

export const LEAF_LABEL = { unused: 'Unused', written: 'Written – not cleared', presented: 'Cleared', void: 'Void', spoiled: 'Spoiled', skipped: 'Skipped!', handed: 'Handed over – not recorded' };

// ---------------------------------------------------------------- books
// Every cheque book of every account (or one account), with its counts.
// 1.0.0 kept until a cheque book, account, cheque, handed-over photo or stub photo changes (Home asks twice)
export function listAllBooks({ accountUid, status } = {}) {
  const list = keepUntilChanged(`chq|books|${accountUid || ''}`, ['cheque_books', 'bank_accounts', 'cheques', 'money_snaps', 'photos'], () => workOutBooks(accountUid));
  return list.map((b) => ({ ...b })).filter((b) => !status || b.status === status);
}
function workOutBooks(accountUid) {
  const books = db().all(`SELECT k.*, a.name AS account_name FROM cheque_books k JOIN bank_accounts a ON a.uid = k.account_uid
    WHERE (? IS NULL OR k.account_uid = ?) ORDER BY a.sort, a.name, k.first_no`, [accountUid || null, accountUid || null]);
  const all = AP.bookLeavesAll(books, { lite: true });
  return books.map((b) => {
    const v = all.get(b.uid);
    return { ...b, status: AP.bookStatusOf(b), statusLabel: AP.BOOK_STATUS[AP.bookStatusOf(b)], leavesCount: b.last_no - b.first_no + 1,
      written: v.written, presented: v.presented, void: v.void, spoiled: v.spoiled, skipped: v.skipped, unused: v.unused, handed: v.handed, noStubPhoto: v.noStubPhoto };
  });
}
export function bookFor(accountUid, no) {
  return db().get('SELECT * FROM cheque_books WHERE account_uid = ? AND ? BETWEEN first_no AND last_no ORDER BY active DESC LIMIT 1', [accountUid, no]) || null;
}
// The book a number belongs to, whatever the account (one BSP account normally).
export function findBookForNo(no, accountUid) {
  const n = Math.round(Number(no));
  if (!Number.isFinite(n) || n <= 0) return null;
  return db().get(`SELECT k.*, a.name AS account_name FROM cheque_books k JOIN bank_accounts a ON a.uid = k.account_uid WHERE ? BETWEEN k.first_no AND k.last_no AND (? IS NULL OR k.account_uid = ?)
    ORDER BY k.active DESC LIMIT 1`, [n, accountUid || null, accountUid || null]) || null;
}

// ---------------------------------------------------------------- the stub record of one leaf
export function getStub({ chequeUid, accountUid, chequeNo } = {}) {
  let c = chequeUid ? db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]) : null;
  const acc = c ? c.account_uid : accountUid || (AP.listAccounts()[0] || {}).uid;
  const no = c ? c.cheque_no : Math.round(Number(chequeNo));
  if (!c && acc && no) c = db().get("SELECT * FROM cheques WHERE account_uid = ? AND cheque_no = ? ORDER BY CASE status WHEN 'void' THEN 1 ELSE 0 END, updated_at DESC LIMIT 1", [acc, no]);
  const account = acc ? db().get('SELECT * FROM bank_accounts WHERE uid = ?', [acc]) : null;
  need(account && no, 'Cheque not found.');
  const book = bookFor(acc, no);
  const pay = c && c.payment_uid ? AP.getPayment(c.payment_uid) : null;
  const handedSnap = !c ? AP.handedNotRecorded(acc, no, no)[0] || null : null;
  const snaps = (() => { try { return db().all("SELECT * FROM money_snaps WHERE kind = 'cheque_given' AND cheque_no = ? AND (account_uid IS NULL OR account_uid = ?) ORDER BY created_at", [no, acc]); } catch (e) { return []; } })();
  let status = c ? c.status : handedSnap ? 'handed' : 'unused';
  if (status === 'unused' && book) { const leaf = (AP.bookLeaves(book.uid).leaves || []).find((l) => l.no === no); if (leaf) status = leaf.status; }
  const photos = c ? J(c.photo_urls, []) : [];
  const local = c ? listPhotos('stub', c.uid) : [];
  const hasPhoto = !!c && AP.stubPhotoCount(c) > 0;
  return {
    no, account, book, cheque: c || null, status, statusLabel: LEAF_LABEL[status] || status,
    date: c ? c.cheque_date : handedSnap ? handedSnap.snap_date : null,
    payee: c ? c.payee : handedSnap ? handedSnap.party : null,
    amount: c ? r2(c.amount) : handedSnap && handedSnap.amount !== null ? r2(handedSnap.amount) : null,
    invoices: pay ? pay.allocations : [],
    payment: pay,
    writtenBy: c ? c.written_by_name : null,
    handedDate: c ? c.handed_date : handedSnap ? handedSnap.snap_date : null,
    handedTo: c ? c.handed_to : handedSnap ? handedSnap.collected_by : null,
    handedBy: c ? c.handed_by_name : handedSnap ? handedSnap.by_name : null,
    cleared: c && c.status === 'presented' ? c.presented_date : null,
    stubNote: c ? c.stub_note : null,
    photos, localPhotos: local, hasPhoto,
    photoMissing: !!c && ['written', 'presented'].includes(c.status) && !hasPhoto,
    snaps,
    handedSnap,
  };
}

// Add a photo of the stub and/or a note to it.
export function saveStub(user, chequeUid, { photos = [], note } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
  need(c, 'Cheque not found.');
  need(photos.length || note !== undefined, 'Take a photo of the stub or write a note.');
  const now = stamp();
  if (note !== undefined && txt(note) !== txt(c.stub_note)) {
    db().run(`UPDATE cheques SET stub_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(note) || null, now, deviceId(), chequeUid]);
  }
  if (photos.length) {
    if (c.photo_urls === null || c.photo_urls === undefined) db().run("UPDATE cheques SET photo_urls = '[]' WHERE uid = ?", [chequeUid]);
    addPhotos('stub', chequeUid, photos);
  }
  audit({ user, action: `Cheque ${c.cheque_no} stub${photos.length ? ' photo added' : ''}${note !== undefined ? ' note' : ''}`, table: 'cheques', recordUid: chequeUid });
  return getStub({ chequeUid });
  });
}

// The cheque was given to the supplier (or their driver).
export function markHandedOver(user, chequeUid, { date, to } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
  need(c, 'Cheque not found.');
  need(['written', 'presented'].includes(c.status), `This cheque is ${c.status}.`);
  const d = txt(date) || dateStr();
  // a post-dated cheque is handed over before the date on it: the hand-over is after it was written (the payment date)
  const written = (c.payment_uid && (db().get('SELECT pay_date FROM ap_payments WHERE uid = ?', [c.payment_uid]) || {}).pay_date) || c.cheque_date;
  need(DATE.test(d) && d >= written, 'The hand-over date must be on or after the day the cheque was written.');
  need(txt(to), 'Write the name of the person who took the cheque.');
  const now = stamp();
  db().run(`UPDATE cheques SET handed_date = ?, handed_by_name = ?, handed_to = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [d, user.name, txt(to), now, deviceId(), chequeUid]);
  audit({ user, action: `Cheque ${c.cheque_no} handed over to ${txt(to)} on ${d}`, table: 'cheques', recordUid: chequeUid, before: { handed_date: c.handed_date, handed_to: c.handed_to }, after: { handed_date: d, handed_to: txt(to) } });
  try { require('./chain.js').addStep(user, { chequeUid, step: 'given', note: `Given to ${txt(to)}` }); } catch (e) { /* the chain falls back to the hand-over date */ }
  });
}

// ---------------------------------------------------------------- cheque handed over (photo screen)
// Cheques written for a supplier and not handed over yet, newest first.
export function chequesForSupplier(supplierUid, { includeHanded = false } = {}) {
  const s = AP.getSupplier(supplierUid);
  if (!s) return [];
  return db().all(`SELECT c.*, a.name AS account_name, p.supplier_uid FROM cheques c JOIN bank_accounts a ON a.uid = c.account_uid LEFT JOIN ap_payments p ON p.uid = c.payment_uid
    WHERE c.status IN ('written','presented') AND (p.supplier_uid = ? OR (c.payment_uid IS NULL AND lower(ifnull(c.payee,'')) = lower(?))) AND (? = 1 OR c.handed_date IS NULL)
    ORDER BY c.cheque_date DESC, c.cheque_no DESC LIMIT 50`, [supplierUid, s.name, includeHanded ? 1 : 0]);
}
// v3.9: every cheque leaf that can still be written in an account's books (for the cheque-number drop-down):
// unused leaves first (lowest first), then numbers skipped earlier. Leaves already written, spoiled, void or
// photographed as handed over are left out.
// build 44 (owner, 10 Nov: "the app is automatically assigning cheque numbers – it does not display all the cheque
// numbers that were added as books"): every unused leaf of every book of the account (in use, spare, or marked
// finished with leaves left) – not only the active books and not only the first 60 – in number order; nothing is
// chosen for the person.
export function availableCheques(accountUid, { limit = 3000 } = {}) {
  if (!accountUid) return [];
  const out = [];
  const books = db().all('SELECT * FROM cheque_books WHERE account_uid = ? ORDER BY first_no', [accountUid]).filter((b) => !['lost', 'cancelled'].includes(AP.bookStatusOf(b)));
  for (const b of books) {
    const v = AP.bookLeaves(b.uid);
    if (!v) continue;
    const st = AP.bookStatusOf(b);
    v.leaves.filter((l) => l.status === 'unused' || l.status === 'skipped').forEach((l) => out.push({ no: l.no, bookUid: b.uid, skipped: l.status === 'skipped', book: `${b.first_no}–${b.last_no}${b.serial ? ` (serial ${b.serial})` : ''}${st === 'in_use' ? '' : ` · ${AP.BOOK_STATUS[st]}`}` }));
  }
  const next = AP.nextChequeNo(accountUid);
  return out.sort((x, y) => x.no - y.no).slice(0, limit).map((x) => ({ ...x, next: x.no === next }));
}
// The next unused number in each account's books.
export function nextUnused() {
  return AP.listAccounts().map((a) => ({ accountUid: a.uid, accountName: a.name, no: AP.nextChequeNo(a.uid) })).filter((x) => x.no);
}
// Options for the cheque drop-down: cheques written for them + the next unused number (+ "type another number").
export function chequeChoices(supplierUid) {
  const out = chequesForSupplier(supplierUid).map((c) => ({ value: `c:${c.uid}`, label: `${c.cheque_no} · ${$(c.amount)} · ${c.cheque_date}`, hint: `Written for ${c.payee}${c.written_by_name ? ` by ${c.written_by_name}` : ''}`, chequeNo: c.cheque_no, chequeUid: c.uid, accountUid: c.account_uid, amount: c.amount }));
  for (const n of nextUnused()) out.push({ value: `n:${n.accountUid}:${n.no}`, label: `${n.no} · next unused cheque`, hint: `Not recorded yet – the office records the payment${AP.listAccounts().length > 1 ? ` (${n.accountName})` : ''}`, chequeNo: n.no, accountUid: n.accountUid });
  out.push({ value: 'type', label: 'Type another number…', hint: 'Any cheque number' });
  return out;
}

// What is wrong (or right) with a cheque number for a hand-over.
// state: recorded | handed | other_payee | spoiled | void | snapped | not_in_book | unrecorded | invalid
// level: ok | warn | bad. Warnings and problems still save; they show on To verify.
export function checkChequeNo({ chequeNo, supplierUid, supplierName, accountUid, exceptSnapUid } = {}) {
  const raw = txt(chequeNo).replace(/\D/g, '');
  const no = Number(raw);
  if (!raw || !Number.isFinite(no) || no <= 0) return { state: 'invalid', level: 'bad', message: 'Type the cheque number (numbers only).' };
  const sup = supplierUid ? AP.getSupplier(supplierUid) : supplierName ? AP.matchSupplier(supplierName) : null;
  const supName = sup ? sup.name : txt(supplierName);
  const rows = db().all(`SELECT c.*, p.supplier_uid FROM cheques c LEFT JOIN ap_payments p ON p.uid = c.payment_uid WHERE c.cheque_no = ? AND (? IS NULL OR c.account_uid = ?)
    ORDER BY CASE c.status WHEN 'void' THEN 1 ELSE 0 END, c.updated_at DESC`, [no, accountUid || null, accountUid || null]);
  const live = rows.find((c) => c.status !== 'void');
  const base = { chequeNo: no };
  if (live) {
    base.cheque = live; base.accountUid = live.account_uid;
    if (live.status === 'spoiled') return { ...base, state: 'spoiled', level: 'bad', message: `Cheque ${no} was recorded as spoiled${live.void_reason ? ` (${live.void_reason})` : ''}. Check the number.` };
    const forThem = sup ? (live.supplier_uid ? live.supplier_uid === sup.uid : txt(live.payee).toLowerCase() === supName.toLowerCase()) : supName ? txt(live.payee).toLowerCase() === supName.toLowerCase() : true;
    if (!forThem) return { ...base, state: 'other_payee', level: 'bad', message: `Cheque ${no} is already used for ${live.payee || 'someone else'} (${$(live.amount)}, ${live.cheque_date}). Check the number.` };
    if (live.handed_date) return { ...base, state: 'handed', level: 'bad', message: `Cheque ${no} was already handed over on ${live.handed_date}${live.handed_to ? ` to ${live.handed_to}` : ''}.` };
    return { ...base, state: 'recorded', level: 'ok', message: `Cheque ${no} for ${live.payee} – ${$(live.amount)}, written ${live.cheque_date}${live.written_by_name ? ` by ${live.written_by_name}` : ''}.` };
  }
  if (rows.length) { base.cheque = rows[0]; return { ...base, state: 'void', level: 'bad', message: `Cheque ${no} was voided${rows[0].void_reason ? ` (${rows[0].void_reason})` : ''}. It should not be handed over.` }; }
  let snapped = [];
  try { snapped = db().all("SELECT * FROM money_snaps WHERE kind = 'cheque_given' AND status <> 'rejected' AND cheque_no = ? AND uid <> ?", [no, exceptSnapUid || '']); } catch (e) { snapped = []; }
  if (snapped.length) return { ...base, state: 'snapped', level: 'bad', message: `Cheque ${no} was already photographed as handed over on ${snapped[0].snap_date}${snapped[0].collected_by ? ` (taken by ${snapped[0].collected_by})` : ''}.` };
  const book = findBookForNo(no, accountUid);
  if (!book) return { ...base, state: 'not_in_book', level: 'warn', message: `Cheque ${no} is not in any cheque book in the app. It goes on the To verify list – the office adds the cheque book and records the payment.` };
  base.accountUid = book.account_uid; base.book = book;
  const next = AP.nextChequeNo(book.account_uid);
  const skip = next && no > next ? ` Numbers ${next}${no - 1 > next ? `–${no - 1}` : ''} before it are not used yet and will show as skipped until they are recorded.` : '';
  return { ...base, state: 'unrecorded', level: 'warn', message: `Cheque ${no} is not recorded yet. It goes on the To verify list so the office records the payment.${skip}`, skipFrom: skip ? next : null };
}

// Cheques handed over (photo) but not recorded as a payment yet, for To verify and the warnings.
export function unrecordedHandovers() {
  try {
    return db().all(`SELECT s.* FROM money_snaps s WHERE s.kind IN ('cheque_given','cheque_written') AND s.status <> 'rejected' AND s.cheque_no IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM cheques c WHERE c.cheque_no = s.cheque_no AND c.status <> 'void' AND (s.account_uid IS NULL OR c.account_uid = s.account_uid))
      ORDER BY s.snap_date`);
  } catch (e) { return []; }
}

// ---------------------------------------------------------------- cheque book report
export function chequeBookReportData(from, to) {
  const books = listAllBooks();
  const leaves = [];
  for (const b of books) {
    const v = AP.bookLeaves(b.uid);
    for (const l of v.leaves) {
      const c = l.cheque;
      const d = c ? c.cheque_date : l.snap ? l.snap.snap_date : null;
      const inPeriod = d ? d >= from && d <= to : false;
      if (!inPeriod && !['skipped', 'handed'].includes(l.status)) continue;
      let invoices = '';
      if (c && c.payment_uid) invoices = db().all('SELECT i.invoice_no FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = ?', [c.payment_uid]).map((x) => x.invoice_no || '?').join(', ');
      leaves.push({ book: b, leaf: l, date: d, invoices });
    }
  }
  return { books, leaves };
}

// build 38 (owner, 10 Nov: "where we make the cheque there should be a place to search if that cheque has been used –
// not enter everything and then the app says you already have an entry"): one cheque number looked up at once, as it is
// typed – recorded (to whom, how much, when), spoiled / void, saved by staff (written or handed over), or free in a book.
// → { level: 'ok' | 'warn' | 'bad', state, message }
export function lookupChequeNo(chequeNo, accountUid) {
  const raw = txt(chequeNo).replace(/\D/g, '');
  const no = Number(raw);
  if (!raw || !(no > 0)) return null;
  const rows = db().all(`SELECT * FROM cheques WHERE cheque_no = ? AND (? IS NULL OR account_uid = ?) ORDER BY CASE status WHEN 'void' THEN 1 ELSE 0 END, updated_at DESC`, [no, accountUid || null, accountUid || null]);
  const live = rows.find((c) => c.status !== 'void');
  if (live && live.status === 'spoiled') return { level: 'bad', state: 'spoiled', message: `Cheque ${no} is recorded as spoiled${live.void_reason ? ` (${live.void_reason})` : ''}.` };
  if (live) return { level: 'bad', state: 'used', message: `Cheque ${no} is already used – ${live.payee || '?'}, ${$(live.amount)}, dated ${live.cheque_date}${live.handed_date ? `, handed over ${live.handed_date}` : ''}${live.status === 'presented' ? ', cleared the bank' : ''}.` };
  if (rows.length) return { level: 'bad', state: 'void', message: `Cheque ${no} was voided${rows[0].void_reason ? ` (${rows[0].void_reason})` : ''}.` };
  let snaps = [];
  try { snaps = db().all("SELECT * FROM money_snaps WHERE kind IN ('cheque_given','cheque_written') AND status <> 'rejected' AND cheque_no = ?", [no]); } catch (e) { snaps = []; }
  if (snaps.length) { const x = snaps[0]; return { level: 'bad', state: 'saved', message: `Cheque ${no} was already saved by ${x.by_name || 'someone'} on ${x.snap_date} – ${x.party || '?'}${x.amount ? `, ${$(x.amount)}` : ''} (${x.kind === 'cheque_given' ? 'handed over' : 'written, waiting for pickup'}).` }; }
  const book = findBookForNo(no, accountUid);
  if (!book) return { level: 'warn', state: 'not_in_book', message: `Cheque ${no} is not in any cheque book in the app – check the number (or add the book).` };
  return { level: 'ok', state: 'free', message: `Cheque ${no} is free – not used yet${book.serial ? ` (book ${book.serial})` : ''}.` };
}
