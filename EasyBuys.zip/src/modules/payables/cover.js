// v3.9.2 Cheque cover. Easy Buys deposits takings to cover the cheques it writes. A deposit can say which cheques (or
// invoices about to be paid by cheque) it covers; any extra in the deposit is simply general money. The app then
// watches every cheque that has not reached the bank yet:
//   • handed over but not covered – it can reach the bank any day (urgent after a few days)
//   • post-dated (on-account suppliers) – a reminder before its date, urgent on the date
//   • prepared but not handed over yet – shown so the deposit can be made in time
//   • overall: money in the bank and on the way, less every cheque still out – short? by how much and by when
// An invoice covered before it is paid: when it is paid by cheque, that cheque counts as covered by the same deposit.
// Works with deposits (Till & cash), cheques and payments (Invoices & cheques), the bank position, the handover, the
// warnings and the watchdog.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, money, getShared, setShared } from '../../services/core.js';
import { requireSetup } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const days = (a, b) => { const p = (d) => { const [y, m, x] = String(d).slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, x); }; return Math.round((p(b) - p(a)) / 86400000); };

export { COVER_SQL, COVER_SYNC } from './coverSchema.js';

export const COVER_DEFAULTS = { urgentAfterDays: 2, postDatedRemindDays: 3, invoiceDays: 14 };
export function coverRules() { return { ...COVER_DEFAULTS, ...(getShared('cheque_cover_rules', {}) || {}) }; }
export function saveCoverRules(user, r) {
  requirePerm(user, 'ap_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'payments_make');
  const n = (v, d) => { const x = Math.round(Number(v)); return Number.isFinite(x) && x >= 0 && x <= 60 ? x : d; };
  const clean = { urgentAfterDays: n(r.urgentAfterDays, 2), postDatedRemindDays: n(r.postDatedRemindDays, 3), invoiceDays: n(r.invoiceDays, 14) };
  setShared('cheque_cover_rules', clean);
  audit({ user, action: 'Changed the cheque cover rules', table: 'shared_settings', recordUid: 'cheque_cover_rules', after: clean });
  return clean;
  });
}

// Covered so far: directly, and through the invoices a cheque paid (each up to what the cheque paid on it).
function coveredByCheque(c) {
  const direct = db().get("SELECT IFNULL(SUM(amount),0) AS s FROM cheque_cover WHERE cheque_uid = ? AND status = 'active'", [c.uid]).s;
  let viaInv = 0;
  if (c.payment_uid) {
    for (const a of db().all('SELECT invoice_uid, amount FROM ap_allocations WHERE payment_uid = ?', [c.payment_uid])) {
      const cov = db().get("SELECT IFNULL(SUM(amount),0) AS s FROM cheque_cover WHERE invoice_uid = ? AND cheque_uid IS NULL AND status = 'active'", [a.invoice_uid]).s;
      viaInv += Math.min(cov, a.amount);
    }
  }
  return r2(direct + viaInv);
}
function coveredByInvoice(invUid) {
  return r2(db().get("SELECT IFNULL(SUM(amount),0) AS s FROM cheque_cover WHERE invoice_uid = ? AND cheque_uid IS NULL AND status = 'active'", [invUid]).s);
}
const depositsFor = (where, arg) => db().all(`SELECT c.amount, d.uid, d.slip_no, d.deposit_date, d.shop_code FROM cheque_cover c JOIN deposits d ON d.uid = c.deposit_uid WHERE c.${where} = ? AND c.status = 'active' AND d.status = 'active' ORDER BY d.deposit_date`, [arg]);

// Every cheque not yet paid by the bank, with its cover: [{ uid, no, payee, amount, date, handed, state, covered, left, ... }]
export function openCheques({ accountUid, today = dateStr() } = {}) {
  if (!has('cheques')) return [];
  const rules = coverRules();
  const rows = db().all(`SELECT c.*, a.name AS account_name FROM cheques c LEFT JOIN bank_accounts a ON a.uid = c.account_uid WHERE c.status = 'written' ${accountUid ? 'AND c.account_uid = ?' : ''} ORDER BY c.cheque_date, c.cheque_no`, accountUid ? [accountUid] : []);
  return rows.map((c) => {
    const covered = has('cheque_cover') ? Math.min(r2(c.amount), coveredByCheque(c)) : 0;
    const left = r2(Math.max(0, c.amount - covered));
    const post = c.cheque_date > today;
    const handed = c.handed_date || null;
    const state = post ? 'post_dated' : handed ? 'handed' : 'prepared';
    const sinceHanded = handed ? days(handed, today) : null;
    const toDate = post ? days(today, c.cheque_date) : null;
    let level = null;
    if (left > 0.004) {
      if (state === 'handed') level = sinceHanded >= rules.urgentAfterDays ? 'urgent' : 'warning';
      else if (state === 'post_dated') level = toDate <= 0 ? 'urgent' : toDate <= rules.postDatedRemindDays ? 'warning' : null;
    }
    return { uid: c.uid, no: c.cheque_no, payee: c.payee, amount: r2(c.amount), date: c.cheque_date, accountUid: c.account_uid, accountName: c.account_name, paymentUid: c.payment_uid,
      handed, handedTo: c.handed_to, state, sinceHanded, toDate, covered, left, level, deposits: has('cheque_cover') ? depositsFor('cheque_uid', c.uid) : [] };
  });
}
// Unpaid invoices due soon (or overdue) that a deposit can cover before the cheque is written.
export function invoicesToCover({ today = dateStr() } = {}) {
  if (!has('ap_invoices')) return [];
  const AP = require('./service.js');
  // every unpaid invoice can be covered; the ones due soonest come first
  return AP.listInvoices({ filter: 'unpaid', limit: 300 }).filter((i) => i.kind !== 'credit' && i.owing > 0.004)
    .sort((a, b) => String(a.due_date || '9999').localeCompare(String(b.due_date || '9999')))
    .map((i) => { const covered = has('cheque_cover') ? Math.min(i.owing, coveredByInvoice(i.uid)) : 0; return { uid: i.uid, supplier: i.supplier_name, invoiceNo: i.invoice_no, due: i.due_date, owing: r2(i.owing), covered, left: r2(Math.max(0, i.owing - covered)) }; });
}
// What a new deposit can cover (cheques first, then invoices), with what is still to cover on each.
export function coverChoices({ accountUid, today = dateStr() } = {}) {
  return {
    cheques: openCheques({ accountUid, today }).filter((c) => c.left > 0.004),
    invoices: invoicesToCover({ today }).filter((i) => i.left > 0.004),
  };
}
// Called by saveDeposit (inside its transaction): covers = [{ chequeUid | invoiceUid, amount }]
export function saveCovers(user, depositUid, covers, depositTotal) {
  requirePerm(user, 'payments_make', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const list = (covers || []).filter((c) => r2(c.amount) > 0 && (c.chequeUid || c.invoiceUid));
  if (!list.length) return [];
  const sum = r2(list.reduce((s, c) => s + r2(c.amount), 0));
  need(sum <= r2(depositTotal) + 0.004, `The cheques ticked come to ${$(sum)} – more than this deposit (${$(depositTotal)}). Untick some or lower the amounts.`);
  const now = stamp(); const dev = deviceId();
  const out = [];
  for (const c of list) {
    if (c.chequeUid) {
      const q = db().get("SELECT * FROM cheques WHERE uid = ? AND status = 'written'", [c.chequeUid]);
      need(q, 'A cheque ticked is no longer waiting for the bank.');
      const left = r2(q.amount - coveredByCheque(q));
      need(r2(c.amount) <= left + 0.004, `Cheque ${q.cheque_no} only needs ${$(left)} more.`);
    } else {
      const AP = require('./service.js');
      const inv = AP.getInvoice(c.invoiceUid);
      need(inv && inv.owing > 0.004, 'An invoice ticked is already paid.');
      need(r2(c.amount) <= r2(inv.owing - coveredByInvoice(inv.uid)) + 0.004, `Invoice ${inv.invoice_no || ''} only needs ${$(inv.owing - coveredByInvoice(inv.uid))} more.`);
    }
    const uid = uuid('CV');
    db().run('INSERT INTO cheque_cover (uid, deposit_uid, cheque_uid, invoice_uid, amount, status, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,\'active\',?,?,?,?)',
      [uid, depositUid, c.chequeUid || null, c.chequeUid ? null : c.invoiceUid, r2(c.amount), user ? user.name : null, now, now, dev]);
    out.push(uid);
  }
  return out;
  });
}
export function voidCoversForDeposit(depositUid) {
  if (!has('cheque_cover')) return;
  db().run("UPDATE cheque_cover SET status = 'void', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE deposit_uid = ? AND status = 'active'", [stamp(), deviceId(), depositUid]);
}
// What a deposit covered: [{ kind, label, amount, uid }]
export function depositCovers(depositUid) {
  if (!has('cheque_cover')) return [];
  return db().all("SELECT * FROM cheque_cover WHERE deposit_uid = ? AND status = 'active' ORDER BY created_at", [depositUid]).map((c) => {
    if (c.cheque_uid) { const q = db().get('SELECT cheque_no, payee, status FROM cheques WHERE uid = ?', [c.cheque_uid]) || {}; return { kind: 'cheque', uid: c.cheque_uid, label: `Cheque ${q.cheque_no || '?'}${q.payee ? ` · ${q.payee}` : ''}${q.status === 'presented' ? ' (paid by the bank)' : ''}`, amount: r2(c.amount) }; }
    const i = db().get('SELECT invoice_no, supplier_name FROM ap_invoices WHERE uid = ?', [c.invoice_uid]) || {};
    return { kind: 'invoice', uid: c.invoice_uid, label: `Invoice ${i.invoice_no || '?'}${i.supplier_name ? ` · ${i.supplier_name}` : ''}`, amount: r2(c.amount) };
  });
}

// The whole picture for an account (default: every account): cheques out, how much is covered, is the bank enough?
export function coverPicture({ today = dateStr() } = {}) {
  const list = openCheques({ today });
  const P = require('../bank/position.js');
  const accounts = has('bank_accounts') ? db().all('SELECT uid, name FROM bank_accounts WHERE active = 1 ORDER BY sort, name') : [];
  const rules = coverRules();
  const perAccount = accounts.map((a) => {
    let pos = null;
    try { pos = P.moneyPosition(a.uid, today); } catch (e) { pos = null; }
    const mine = list.filter((c) => c.accountUid === a.uid);
    const soonPost = mine.filter((c) => c.state === 'post_dated' && c.toDate <= rules.postDatedRemindDays);
    // pos.book = cheque-book balance: the bank after every cheque written (up to today) and every deposit clears.
    // Release 05: loan repayments the bank takes by itself from this account soon need covering too.
    let loans = [];
    try { loans = require('../bank/links05.js').loanDeductionsDue({ accountUid: a.uid, today, days: rules.postDatedRemindDays + 7 }); } catch (e) { loans = []; }
    const loansDue = r2(loans.reduce((s, l) => s + l.amount, 0));
    const afterAll = pos ? r2(pos.book - soonPost.reduce((s, c) => s + c.amount, 0) - loansDue) : null;
    return { uid: a.uid, name: a.name, inBank: pos ? pos.inBank : null, afterAll, loans, loansDue, short: afterAll !== null && afterAll < -0.004 ? r2(-afterAll) : 0,
      chequesOut: r2(mine.reduce((s, c) => s + c.amount, 0)), uncovered: r2(mine.reduce((s, c) => s + c.left, 0)) };
  });
  return {
    cheques: list,
    needNow: list.filter((c) => c.state === 'handed' && c.left > 0.004),
    postDated: list.filter((c) => c.state === 'post_dated'),
    prepared: list.filter((c) => c.state === 'prepared'),
    covered: list.filter((c) => c.left <= 0.004),
    accounts: perAccount,
  };
}

// Warnings for Home (bank and till people): one line each.
export function coverAlerts(today = dateStr()) {
  if (!has('cheques')) return [];
  const p = coverPicture({ today });
  const out = [];
  const handed = p.needNow;
  if (handed.length) {
    const urg = handed.filter((c) => c.level === 'urgent');
    out.push({ id: 'cover-handed', level: urg.length ? 'urgent' : 'warning', text: `${handed.length} cheque${handed.length === 1 ? '' : 's'} handed over with no deposit to cover ${handed.length === 1 ? 'it' : 'them'} (${$(handed.reduce((s, c) => s + c.left, 0))})`,
      sub: handed.slice(0, 3).map((c) => `${c.no} ${c.payee || ''} ${$(c.left)}${c.sinceHanded ? ` · ${c.sinceHanded} day${c.sinceHanded === 1 ? '' : 's'}` : ' · today'}`).join(' · '), nav: { screen: 'ChequeCover', params: {} } });
  }
  const post = p.postDated.filter((c) => c.level);
  if (post.length) {
    const due = post.filter((c) => c.level === 'urgent');
    out.push({ id: 'cover-post', level: due.length ? 'urgent' : 'warning', text: `${post.length} post-dated cheque${post.length === 1 ? '' : 's'} coming up not covered yet`, sub: post.slice(0, 3).map((c) => `${c.no} ${c.payee || ''} ${$(c.left)} on ${c.date}`).join(' · '), nav: { screen: 'ChequeCover', params: {} } });
  }
  for (const a of p.accounts) {
    if (a.short > 0) out.push({ id: `cover-short-${a.uid}`, level: 'urgent', text: `Not enough in ${a.name} for the cheques out – short ${$(a.short)}`, sub: 'Deposit before the cheques reach the bank, or hold a cheque back.', nav: { screen: 'ChequeCover', params: {} } });
  }
  return out;
}
