// v3.9.2 Cheque cover table (see cover.js).
export const COVER_SQL = `
CREATE TABLE IF NOT EXISTS cheque_cover (
  uid TEXT PRIMARY KEY,
  deposit_uid TEXT NOT NULL,
  cheque_uid TEXT,
  invoice_uid TEXT,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_cover_chq ON cheque_cover(cheque_uid);
CREATE INDEX IF NOT EXISTS idx_cover_inv ON cheque_cover(invoice_uid);
CREATE INDEX IF NOT EXISTS idx_cover_dep ON cheque_cover(deposit_uid);
`;
export const COVER_SYNC = {
  cheque_cover: { key: 'uid', section: 'Till & cash', cols: ['uid', 'deposit_uid', 'cheque_uid', 'invoice_uid', 'amount', 'status', 'by_name', 'created_at', 'updated_at', 'updated_device'] },
};

