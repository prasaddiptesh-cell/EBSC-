// 1.0.0 Deposit plan: a supervisor or manager plans a deposit, mostly to cover cheques written (and invoices about to be
// paid by cheque). Steps: planned → slip written → banked (photo of the stamped slip, required) → shows on the bank.
// Each step keeps the date, time and who. It shows on Today until it is on the bank, and in each cheque's chain.
// (The deposit itself is still recorded in Till & cash › Deposits as before; "banked" can join it to the plan, and the
// plan is then on the bank by itself when that deposit is ticked on the bank statement.)
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays } from '../../services/core.js';
import { can, needReason } from '../../services/access.js';
import { addPhotos, listPhotos } from '../../services/stock.js';
import * as AP from './service.js';
import { requirePerm, asService } from '../../services/guard.js';

const { r2, $ } = AP;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'deposit_plans'"); } catch (e) { return false; } };
const SY = "updated_at = ?, updated_device = ?, sync_status = 'pending'";

export const PLAN_STATUS = { planned: 'Planned – write the slip', slip: 'Slip written – take it to the bank', banked: 'Banked – waiting for the bank', on_bank: 'On the bank', void: 'Cancelled' };
export const PLAN_STEPS = [
  { key: 'planned', label: 'Planned' }, { key: 'slip', label: 'Slip written' }, { key: 'banked', label: 'Banked – photo of the stamped slip' }, { key: 'on_bank', label: 'Shows on the bank' },
];
const ORDER = ['planned', 'slip', 'banked', 'on_bank'];

// A supervisor or manager (or the owner / admin, or anyone who records deposits).
export function mayPlan(user) {
  return !!user && (['supervisor', 'manager', 'admin', 'owner'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || can(user, 'deposits'));
}
// A manager / supervisor plans for their own shop.
function shopFor(user, shopCode) {
  const s = txt(shopCode) || user.shop_code || '';
  if (['supervisor', 'manager'].includes(user.role) && user.shop_code) need(s === user.shop_code, `You plan deposits for ${user.shop_code} only.`);
  return s;
}

// lines: [{ chequeUid | snapUid | invoiceUid, amount }]. extra: other money in the same deposit (takings).
export function planDeposit(user, { shopCode, accountUid, date, cashFrom, lines = [], extra = 0, note } = {}) {
  requirePerm(user, ['verify_money', 'deposits'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(has(), 'Update the app first.');
  need(mayPlan(user), 'Only a supervisor, manager or the admin plans deposits.');
  const shop = shopFor(user, shopCode);
  need(shop, 'Choose the shop the money comes from.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d >= addDays(dateStr(), -7), 'Choose the day of the deposit.');
  const accounts = AP.listAccounts();
  const acct = accountUid || (accounts[0] && accounts[0].uid) || null;
  need(acct, 'Add the bank account first (Settings › Bank).');
  const clean = [];
  for (const l of lines || []) {
    const a = r2(l.amount);
    if (!(a > 0)) continue;
    if (l.chequeUid) {
      const c = db().get("SELECT cheque_no, payee, amount, status FROM cheques WHERE uid = ?", [l.chequeUid]);
      need(c && c.status === 'written', 'A cheque ticked is no longer waiting for the bank.');
      need(a <= r2(c.amount) + 0.004, `Cheque ${c.cheque_no} is only ${$(c.amount)}.`);
      clean.push({ chequeUid: l.chequeUid, amount: a, label: `Cheque ${c.cheque_no}${c.payee ? ` (${c.payee})` : ''}` });
    } else if (l.snapUid) {
      const s = db().get("SELECT cheque_no, party, amount FROM money_snaps WHERE uid = ? AND kind IN ('cheque_given','cheque_written')", [l.snapUid]);
      need(s, 'A cheque ticked was not found.');
      clean.push({ snapUid: l.snapUid, amount: a, label: `Cheque ${s.cheque_no}${s.party ? ` (${s.party})` : ''}` });
    } else if (l.invoiceUid) {
      const i = AP.getInvoice(l.invoiceUid);
      need(i && i.owing > 0.004, 'An invoice ticked is already paid.');
      clean.push({ invoiceUid: l.invoiceUid, amount: a, label: `Invoice ${i.invoice_no || '(no number)'} (${i.supplier_name})` });
    }
  }
  const ex = r2(extra);
  need(ex >= 0, 'The other money cannot be negative.');
  const total = r2(clean.reduce((t, l) => t + l.amount, 0) + ex);
  need(total > 0, 'Tick the cheques this deposit covers (or type the amount).');
  if (ex > 0) clean.push({ extra: true, amount: ex, label: 'Other money (takings)' });
  const uid = uuid('DP');
  const now = stamp();
  db().run(`INSERT INTO deposit_plans (uid, shop_code, account_uid, plan_date, cash_from, lines, total, note, status, planned_by_name, planned_by_uid, planned_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?, 'planned', ?,?,?,?,?)`, [uid, shop, acct, d, txt(cashFrom) || 'safe', JSON.stringify(clean), total, txt(note) || null, user.name, user.uid, now, now, deviceId()]);
  audit({ user, action: `Deposit planned for ${d}: ${$(total)} (${clean.map((l) => l.label).join(', ')})`, table: 'deposit_plans', recordUid: uid });
  return getPlan(uid);
  });
}
export function getPlan(uid) {
  if (!has()) return null;
  const p = db().get('SELECT * FROM deposit_plans WHERE uid = ?', [uid]);
  if (!p) return null;
  return decorate(p);
}
function decorate(p) {
  const lines = J(p.lines, []);
  const at = { planned: [p.planned_at, p.planned_by_name], slip: [p.slip_at, p.slip_by_name], banked: [p.banked_at, p.banked_by_name], on_bank: [p.on_bank_at, p.on_bank_by_name] };
  const idx = p.status === 'void' ? -1 : ORDER.indexOf(p.status);
  const steps = PLAN_STEPS.map((s, i) => ({ ...s, done: i <= idx, at: at[s.key][0] || null, by: at[s.key][1] || null, note: s.key === 'slip' && p.slip_no ? `Slip ${p.slip_no}` : s.key === 'on_bank' && p.on_bank_date ? `On the statement ${p.on_bank_date}` : null }));
  let photos = [];
  try { photos = (listPhotos('deposit_plan', p.uid) || []).map((x) => x.uri).concat(J(p.photo_urls, [])); } catch (e) { photos = J(p.photo_urls, []); }
  return { ...p, lines, steps, next: steps.find((s) => !s.done) || null, photos, statusLabel: PLAN_STATUS[p.status] || p.status };
}
export function listPlans({ open = true, shopCode, limit = 200 } = {}) {
  if (!has()) return [];
  refreshPlans();
  return db().all(`SELECT * FROM deposit_plans WHERE (? = 0 OR status IN ('planned','slip','banked')) AND (? IS NULL OR shop_code = ?) ORDER BY plan_date, planned_at LIMIT ?`, [open ? 1 : 0, shopCode || null, shopCode || null, limit]).map(decorate);
}
const step = (p, from) => need(p && p.status === from, p ? (p.status === 'void' ? 'This deposit plan was cancelled.' : `This deposit is already ${PLAN_STATUS[p.status].split(' –')[0].toLowerCase()}.`) : 'Deposit plan not found.');
export function slipWritten(user, uid, { slipNo } = {}) {
  requirePerm(user, ['verify_money', 'deposits'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(mayPlan(user), 'Only a supervisor, manager or the admin does this.');
  const p = getPlan(uid);
  step(p, 'planned');
  const now = stamp();
  db().run(`UPDATE deposit_plans SET status = 'slip', slip_no = ?, slip_by_name = ?, slip_at = ?, ${SY} WHERE uid = ?`, [txt(slipNo) || null, user.name, now, now, deviceId(), uid]);
  audit({ user, action: `Deposit slip written${txt(slipNo) ? ` (${txt(slipNo)})` : ''} for ${$(p.total)}`, table: 'deposit_plans', recordUid: uid });
  return getPlan(uid);
  });
}
// Banked: the photo of the stamped slip is required. depositUid: the deposit recorded in Till & cash (optional).
export function banked(user, uid, { photos = [], amount, depositUid } = {}) {
  requirePerm(user, ['verify_money', 'deposits'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(mayPlan(user), 'Only a supervisor, manager or the admin does this.');
  const p = getPlan(uid);
  step(p, 'slip');
  need((photos || []).length, 'Take a photo of the stamped deposit slip.');
  const a = amount === undefined || amount === null || amount === '' ? p.total : r2(amount);
  need(a > 0, 'Type the amount banked.');
  if (depositUid) need(db().get("SELECT 1 AS x FROM deposits WHERE uid = ? AND status = 'active'", [depositUid]), 'That deposit was not found.');
  const now = stamp();
  db().run(`UPDATE deposit_plans SET status = 'banked', banked_by_name = ?, banked_at = ?, banked_amount = ?, deposit_uid = ?, ${SY} WHERE uid = ?`, [user.name, now, a, depositUid || null, now, deviceId(), uid]);
  addPhotos('deposit_plan', uid, photos);
  audit({ user, action: `Deposit banked ${$(a)}${Math.abs(a - p.total) > 0.004 ? ` (planned ${$(p.total)})` : ''}`, table: 'deposit_plans', recordUid: uid });
  try { require('../verify/service.js').notify('deposit', `🏦 Deposit banked ${$(a)} by ${user.name}${p.shop_code ? ` (${p.shop_code})` : ''} – covers ${p.lines.filter((l) => !l.extra).map((l) => l.label).join(', ') || 'takings'}.`, { shopCode: p.shop_code, attach: { photos: photos.slice(0, 1) } }); } catch (e) { /* Viber is optional */ }
  return getPlan(uid);
  });
}
// Seen on the bank statement (the office). Also done by itself when the joined deposit is ticked on the statement.
export function onBank(user, uid, { date } = {}) {
  requirePerm(user, 'bank_rec', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (can(user, 'bank_rec') || can(user, 'payments_make') || ['owner', 'admin', 'manager'].includes(user.role)), 'Only the office ticks a deposit as on the bank.');
  const p = getPlan(uid);
  step(p, 'banked');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date on the bank statement.');
  const now = stamp();
  db().run(`UPDATE deposit_plans SET status = 'on_bank', on_bank_by_name = ?, on_bank_at = ?, on_bank_date = ?, ${SY} WHERE uid = ?`, [user.name, now, d, now, deviceId(), uid]);
  audit({ user, action: `Deposit ${$(p.banked_amount || p.total)} seen on the bank ${d}`, table: 'deposit_plans', recordUid: uid });
  return getPlan(uid);
  });
}
export function voidPlan(user, uid, reason) {
  requirePerm(user, ['verify_money', 'deposits'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(mayPlan(user), 'Only a supervisor, manager or the admin does this.');
  const p = getPlan(uid);
  need(p && ['planned', 'slip'].includes(p.status), 'Only a deposit not banked yet can be cancelled.');
  needReason(user, reason, 'Say why it is cancelled.');
  const now = stamp();
  db().run(`UPDATE deposit_plans SET status = 'void', void_reason = ?, voided_by_name = ?, voided_at = ?, ${SY} WHERE uid = ?`, [txt(reason) || null, user.name, now, now, deviceId(), uid]);
  audit({ user, action: `Deposit plan cancelled (${$(p.total)})`, table: 'deposit_plans', recordUid: uid, reason: txt(reason) || null });
  });
}
// Plans whose joined deposit is ticked on the bank statement move on by themselves (one query).
export function refreshPlans() {
  if (!has()) return 0;
  let rows = [];
  try { rows = db().all("SELECT p.uid, e.cleared_date FROM deposit_plans p JOIN deposits d ON d.uid = p.deposit_uid JOIN bank_entries e ON e.uid = d.bank_entry_uid WHERE p.status = 'banked' AND e.cleared_date IS NOT NULL"); } catch (e) { rows = []; }
  const now = stamp();
  for (const r of rows) db().run(`UPDATE deposit_plans SET status = 'on_bank', on_bank_by_name = 'Bank statement', on_bank_at = ?, on_bank_date = ?, ${SY} WHERE uid = ? AND status = 'banked'`, [now, r.cleared_date, now, now, deviceId(), r.uid]);
  return rows.length;
}
// What a new plan can cover: cheques not cleared (recorded, or written by staff) and what is still uncovered on each.
export function planChoices({ shopCode } = {}) {
  const C = require('./chain.js');
  const covered = new Map();
  for (const p of listPlans({ open: false })) if (p.status !== 'void') for (const l of p.lines) { const k = l.chequeUid || l.snapUid; if (k) covered.set(k, r2((covered.get(k) || 0) + l.amount)); }
  return C.openChains({ shopCode }).map((c) => {
    const k = c.chequeUid || c.snapUid;
    const cov = r2(Math.max(covered.get(k) || 0, c.steps[4].done && !covered.get(k) ? c.amount : 0));
    return { key: k, chequeUid: c.chequeUid, snapUid: c.snapUid, label: `Cheque ${c.no} · ${c.supplierName || ''}`, amount: c.amount, left: r2(Math.max(0, c.amount - cov)), stage: c.stage, given: c.steps[3].done };
  }).filter((x) => x.left > 0.004);
}
