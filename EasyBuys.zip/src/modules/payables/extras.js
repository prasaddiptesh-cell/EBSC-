// Invoices & cheques extras: pay many suppliers in one go (payment run), supplier statement check,
// and warnings on invoices (missing TIN, VAT that does not add up).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { apRules, getSupplier, listInvoices, getInvoice, makePayment, nextChequeNo, $, r2 } from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());

// ---------------------------------------------------------------- payment run
// What can be paid, grouped by supplier (checked invoices only, oldest due first).
export function payRunCandidates({ dueBy = dateStr(), shopCode } = {}) {
  const rules = apRules();
  const list = listInvoices({ filter: 'unpaid', shopCode, limit: 5000 }).filter((i) => i.total > 0 && i.supplier_uid && i.due_date <= dueBy);
  const by = {};
  for (const i of list) {
    const blocked = rules.checkBeforePay && i.status === 'to_check';
    const s = (by[i.supplier_uid] = by[i.supplier_uid] || { supplierUid: i.supplier_uid, name: i.supplier_name, payMethod: (getSupplier(i.supplier_uid) || {}).pay_method || 'cheque', invoices: [], total: 0, blocked: 0 });
    s.invoices.push({ ...i, blocked: blocked ? 'Waiting to be checked' : null });
    if (blocked) s.blocked += 1; else s.total = r2(s.total + i.owing);
  }
  return Object.values(by).sort((a, b) => a.name.localeCompare(b.name));
}
// Pay several suppliers at once. items: [{ supplierUid, invoiceUids, method?, reference? }]
// Cheques are numbered one after the other from the next leaf of the chosen account.
export function payRun(user, { accountUid, method = 'cheque', date, items = [], shopCode, referencePrefix }) {
  need(items.length, 'Tick at least one supplier to pay.');
  const d = txt(date) || dateStr();
  const done = [];
  let next = method === 'cheque' ? nextChequeNo(accountUid) : null;
  if (method === 'cheque') need(next, 'There are no cheque leaves left for this account. Add a cheque book first.');
  for (const it of items) {
    const m = it.method || method;
    const allocations = (it.invoiceUids || []).map((u) => { const i = getInvoice(u); return { invoiceUid: u, amount: i ? i.owing : 0 }; }).filter((a) => a.amount > 0);
    if (!allocations.length) continue;
    const p = makePayment(user, { supplierUid: it.supplierUid, method: m, accountUid, payDate: d, allocations, chequeNo: m === 'cheque' ? next : undefined, shopCode,
      reference: m === 'transfer' ? txt(it.reference) || `${txt(referencePrefix) || 'PAYRUN'}-${d}` : undefined, notes: 'Payment run' });
    done.push(p);
    if (m === 'cheque') next = nextChequeNo(accountUid);
  }
  need(done.length, 'Nothing was paid.');
  audit({ user, action: `Payment run ${d}: ${done.length} supplier(s), ${$(done.reduce((s, p) => s + p.amount, 0))}`, table: 'ap_payments' });
  return done;
}

// ---------------------------------------------------------------- supplier statement check
// What we say we owe a supplier on a date (invoices up to that date, less payments and credits up to that date).
export function ourBalance(supplierUid, asOf = dateStr()) {
  const inv = db().get(`SELECT COALESCE(SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END),0) AS t FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND invoice_date <= ?`, [supplierUid, asOf]).t;
  const paid = db().get(`SELECT COALESCE(SUM(a.amount),0) AS t FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid WHERE p.supplier_uid = ? AND p.status = 'active' AND p.method <> 'credit' AND p.pay_date <= ?`, [supplierUid, asOf]).t;
  return r2(inv - paid);
}
export function checkStatement(user, { supplierUid, date, theirBalance, note, photos = [] }) {
  const s = getSupplier(supplierUid);
  need(s, 'Choose the supplier.');
  const d = txt(date) || dateStr();
  const theirs = r2(theirBalance);
  need(txt(theirBalance) !== '' && Number.isFinite(theirs), 'Enter the balance shown on the supplier\'s statement.');
  const ours = ourBalance(supplierUid, d);
  const diff = r2(theirs - ours);
  const uid = uuid('SS');
  const now = stamp();
  db().run(`INSERT INTO supplier_statements (uid, supplier_uid, statement_date, their_balance, our_balance, diff, note, photo_urls, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?, '[]', ?,?,?,?)`,
    [uid, supplierUid, d, theirs, ours, diff, txt(note) || null, user.name, now, now, deviceId()]);
  if (photos.length) addPhotos('statement', uid, photos);
  audit({ user, action: `Statement check ${s.name} ${d}: theirs ${$(theirs)}, ours ${$(ours)}${Math.abs(diff) > 0.004 ? `, difference ${$(diff)}` : ' – agrees'}`, table: 'supplier_statements', recordUid: uid });
  return { uid, ours, theirs, diff, hints: Math.abs(diff) > 0.004 ? statementHints(supplierUid, d, diff) : [] };
}
// Likely reasons for a difference: an invoice the same size not entered / entered twice, a payment not yet on their side…
function statementHints(supplierUid, d, diff) {
  const out = [];
  const amt = Math.abs(diff);
  const inv = db().all("SELECT invoice_no, invoice_date, total FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND kind = 'invoice' AND ABS(total - ?) < 0.01", [supplierUid, amt]);
  if (diff < 0 && inv.length) out.push(`We have invoice ${inv.map((i) => `${i.invoice_no || '?'} (${i.invoice_date})`).join(', ')} for ${$(amt)} – check it is not entered twice and that they have it.`);
  const pays = db().all("SELECT pay_date, amount, method, cheque_no FROM ap_payments WHERE supplier_uid = ? AND status = 'active' AND ABS(amount - ?) < 0.01 AND pay_date <= ?", [supplierUid, amt, d]);
  if (diff > 0 && pays.length) out.push(`Our payment of ${$(amt)} on ${pays[0].pay_date}${pays[0].cheque_no ? ` (cheque ${pays[0].cheque_no})` : ''} may not be on their statement yet.`);
  if (diff > 0 && !pays.length) out.push(`They say we owe ${$(amt)} more: an invoice may be missing here (ask for a copy) or a credit note entered here they have not given.`);
  if (diff < 0 && !inv.length) out.push(`We show ${$(amt)} more than they do: a credit note or payment may be missing here, or an invoice entered with the wrong amount.`);
  return out;
}
export function listStatements(supplierUid) {
  return db().all('SELECT * FROM supplier_statements WHERE (? IS NULL OR supplier_uid = ?) ORDER BY statement_date DESC LIMIT 50', [supplierUid || null, supplierUid || null]);
}

// ---------------------------------------------------------------- invoice warnings (VAT claims)
export function invoiceWarnings(inv) {
  if (!inv || inv.status === 'void' || !inv.total) return [];
  const out = [];
  const sup = inv.supplier_uid ? getSupplier(inv.supplier_uid) : null;
  const rate = Number(apRules().vatRate) || 12.5;
  if (inv.vat > 0 && !(inv.supplier_tin || (sup && sup.tin))) out.push('No supplier TIN: FRCS may not allow the VAT on this invoice to be claimed. Add the TIN from the invoice.');
  if (inv.vat > 0 && sup && !sup.vat_registered) out.push('VAT is entered but the supplier is set as not VAT registered.');
  if (inv.vat_type === 'standard') {
    const expect = r2(inv.total - inv.total / (1 + rate / 100));
    if (Math.abs(expect - inv.vat) > 0.05) out.push(`VAT should be ${$(expect)} at ${rate}% of ${$(inv.total)} (entered ${$(inv.vat)}).`);
  }
  if (inv.total >= 1000 && !inv.invoice_no) out.push('No invoice number – needed for the VAT records and to stop it being paid twice.');
  return out;
}
