// Invoices & cheques module: supplier invoices (photo + reading), due flags, paying by cheque / cash / transfer,
// pay trail, credit notes, BSP cheque books and balancing, regular bills and loans.
import { PayablesHomeScreen, InvoiceListScreen, InvoiceEditScreen, InvoiceViewScreen } from './screens/InvoiceScreens.js';
import { PayScreen, PaymentViewScreen, PaymentListScreen } from './screens/PayScreens.js';
import { PayRunScreen, StatementCheckScreen } from './screens/ExtraScreens.js';
import ChequesScreen from './screens/ChequeScreens.js';
import { SupplierListScreen, SupplierEditScreen, ApRulesScreen, RecurringScreen, RecurringEditScreen, LoanScreen } from './screens/SetupScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

const any = (u) => ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(u, p));
export default {
  id: 'payables',
  title: 'Invoices & cheques',
  icon: '🧾',
  switchable: true,
  screens: {
    Payables: { component: PayablesHomeScreen, can: any },
    ApInvoices: { component: InvoiceListScreen, can: any },
    ApInvoice: { component: InvoiceViewScreen, can: any },
    ApInvoiceEdit: { component: InvoiceEditScreen, can: (u) => can(u, 'invoices_enter') || can(u, 'invoices_check') },
    ApPay: { component: PayScreen, can: (u) => can(u, 'payments_make') },
    ApPayment: { component: PaymentViewScreen, can: (u) => can(u, 'payments_make') },
    ApPayments: { component: PaymentListScreen, can: (u) => can(u, 'payments_make') },
    ApPayRun: { component: PayRunScreen, can: (u) => can(u, 'payments_make') },
    ApStatement: { component: StatementCheckScreen, can: (u) => can(u, 'payments_make') },
    Cheques: { component: ChequesScreen, can: (u) => can(u, 'cheques_manage') },
    ApSuppliers: { component: SupplierListScreen, can: any },
    ApSupplierEdit: { component: SupplierEditScreen, can: any },
    ApRules: { component: ApRulesScreen, can: (u) => can(u, 'ap_setup') },
    Recurring: { component: RecurringScreen, can: (u) => can(u, 'ap_setup') },
    RecurringEdit: { component: RecurringEditScreen, can: (u) => can(u, 'ap_setup') },
    Loan: { component: LoanScreen, can: (u) => can(u, 'ap_setup') || can(u, 'payments_make') },
  },
  reports: REPORTS,
};
