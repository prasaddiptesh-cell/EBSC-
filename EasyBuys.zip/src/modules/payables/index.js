// Invoices & cheques module: supplier invoices (photo + reading), due flags, paying by cheque / cash / transfer,
// pay trail, credit notes, BSP cheque books and balancing, regular bills and loans.
import { PayablesHomeScreen, InvoiceListScreen, InvoiceEditScreen, InvoiceViewScreen } from './screens/InvoiceScreens.js';
import { PayMethodsScreen } from './screens/PayMethodsScreen.js';
import { PayScreen, PaymentViewScreen, PaymentListScreen } from './screens/PayScreens.js';
import { PayRunScreen, StatementCheckScreen } from './screens/ExtraScreens.js';
import ChequesScreen from './screens/ChequeScreens.js';
import { ChequeBooksScreen, ChequeStubScreen, SupplierStatementScreen } from './screens/BookScreens.js';
import { SupplierListScreen, SupplierEditScreen, ApRulesScreen, RecurringScreen, RecurringEditScreen, LoanScreen } from './screens/SetupScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { ChequeCoverScreen } from './screens/CoverScreens.js';
import { ChequeTrailScreen, DepositPlanScreen, DepositPlansScreen, SupplierPageScreen, SupplierStandingsScreen, ChequeWrittenScreen, PaidCashScreen, ChequeHomeScreen } from './screens/ChainScreens.js';
import { NoSupplierQuickScreen } from '../inventory/screens/GoodsInScreens.js';
import { mayPlan } from './depositPlan.js';
import { RegularSuppliersScreen } from './screens/RegularScreens.js';

const any = (u) => ['invoices_enter', 'invoices_check', 'payments_make', 'cheques_manage', 'ap_setup'].some((p) => can(u, p));
export default {
  id: 'payables',
  title: 'Invoices & cheques',
  icon: '🧾',
  switchable: true,
  screens: {
    Payables: { component: PayablesHomeScreen, can: any },
    PayMethods: { component: PayMethodsScreen, can: (u) => !!u && ['owner', 'admin'].includes(u.role) },
    ApInvoices: { component: InvoiceListScreen, can: any },
    ApInvoice: { component: InvoiceViewScreen, can: any },
    ApInvoiceEdit: { component: InvoiceEditScreen, can: (u) => can(u, 'invoices_enter') || can(u, 'invoices_check') },
    ApPay: { component: PayScreen, can: (u) => can(u, 'payments_make') },
    ApPayment: { component: PaymentViewScreen, can: (u) => can(u, 'payments_make') },
    ApPayments: { component: PaymentListScreen, can: (u) => can(u, 'payments_make') },
    ApPayRun: { component: PayRunScreen, can: (u) => can(u, 'payments_make') },
    ApStatement: { component: StatementCheckScreen, can: (u) => can(u, 'payments_make') },
    Cheques: { component: ChequesScreen, can: (u) => can(u, 'cheques_manage') },
    ChequeBooks: { component: ChequeBooksScreen, can: (u) => can(u, 'cheques_manage') || can(u, 'payments_make') },
    ChequeStub: { component: ChequeStubScreen, can: (u) => can(u, 'cheques_manage') || can(u, 'payments_make') },
    ChequeCover: { component: ChequeCoverScreen, can: (u) => can(u, 'cheques_manage') || can(u, 'payments_make') || can(u, 'deposits') || can(u, 'till_approve') },
    ApSupplierStatement: { component: SupplierStatementScreen, can: (u) => can(u, 'payments_make') || can(u, 'invoices_check') },
    ApSuppliers: { component: SupplierListScreen, can: any },
    ApSupplierEdit: { component: SupplierEditScreen, can: any },
    // 1.0.0 many products at once (tick, or a whole Aronium group); the old one-tap list is the same screen name
    NoSupplierProducts: { component: NoSupplierQuickScreen, can: (u) => any(u) || can(u, 'inventory_view') || can(u, 'inventory_manage') },
    // 1.0.0 the cheque chain, deposit plans, the supplier page and standings, staff "Cheque written" / "Paid in cash"
    ChequeTrail: { component: ChequeTrailScreen, can: (u) => ['payments_make', 'cheques_manage', 'verify_money', 'deposits', 'invoices_check'].some((p) => can(u, p)) },
    DepositPlan: { component: DepositPlanScreen, can: (u) => mayPlan(u) || can(u, 'bank_rec') || can(u, 'payments_make') },
    DepositPlans: { component: DepositPlansScreen, can: (u) => mayPlan(u) || can(u, 'bank_rec') || can(u, 'payments_make') },
    SupplierPage: { component: SupplierPageScreen, can: (u) => any(u) || can(u, 'verify_money') || can(u, 'inventory_view') },
    RegularSuppliers: { component: RegularSuppliersScreen, can: (u) => ['invoices_enter', 'invoices_check', 'payments_make'].some((p) => can(u, p)) },
    SupplierStandings: { component: SupplierStandingsScreen, can: (u) => ['payments_make', 'invoices_check', 'verify_money'].some((p) => can(u, p)) },
    ChequeHome: { component: ChequeHomeScreen, can: (u) => can(u, 'snap_upload') || can(u, 'payments_make') },
    ChequeWritten: { component: ChequeWrittenScreen, can: (u) => can(u, 'snap_upload') || can(u, 'payments_make') },
    PaidCash: { component: PaidCashScreen, can: (u) => can(u, 'snap_upload') || can(u, 'payments_make') },
    ApRules: { component: ApRulesScreen, can: (u) => can(u, 'ap_setup') },
    Recurring: { component: RecurringScreen, can: (u) => can(u, 'ap_setup') },
    RecurringEdit: { component: RecurringEditScreen, can: (u) => can(u, 'ap_setup') },
    Loan: { component: LoanScreen, can: (u) => can(u, 'ap_setup') || can(u, 'payments_make') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
