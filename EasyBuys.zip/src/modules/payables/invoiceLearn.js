// 1.0.0 build 34 (owner, 10 Nov: "it needs to learn each time"): every supplier invoice saved teaches the app about
// that supplier's invoices – what its invoice numbers look like, its usual VAT, and every figure the reading got wrong
// and what it really was. The notes are kept with the supplier's layout (supplier_layouts, synced to every device) and
// are given to the AI with the next reading of that supplier's invoice (cloud/Code.gs aiPrompt_, hints.notes), so the
// same mistake is not made twice. Shown (and can be cleared) on the supplier's page.
import { db } from '../../db/connection.js';
import { stamp, deviceId, audit } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v)).trim();
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
export const MAX_FIXES = 8;
export const MAX_SHAPES = 3;

// "INV-10234" → "AAA-99999": what this supplier's numbers look like (never the number itself in the shape)
export const shapeOf = (no) => txt(no).toUpperCase().replace(/[A-Z]/g, 'A').replace(/[0-9]/g, '9');
const same = (field, a, b) => {
  if (field === 'total' || field === 'vat') return Math.abs(r2(a) - r2(b)) < 0.005;
  if (field === 'invoiceNo') return txt(a).toUpperCase().replace(/[^A-Z0-9]/g, '') === txt(b).toUpperCase().replace(/[^A-Z0-9]/g, '');
  return txt(a) === txt(b);
};
function rowOf(supplierUid) { try { return db().get('SELECT * FROM supplier_layouts WHERE supplier_uid = ?', [supplierUid]); } catch (e) { return null; } }

// read: what the photo reading filled in { invoiceNo, total, vat, invoiceDate } (null when nothing was read);
// saved: what was saved { invoiceNo, total, vat, invoiceDate, vatType }. Learns every time; → { learned: [text], notes }
export function learnInvoice(user, supplierUid, { read = null, saved = {} } = {}) {
  requirePerm(user, ['invoices_enter', 'po_receive'], { money: true }); // only someone who enters invoices teaches it
  return asService(() => {
  if (!supplierUid) return { learned: [], notes: '' };
  const row = rowOf(supplierUid);
  const layout = J(row && row.layout, {});
  const ai = { shapes: [], examples: [], vat: {}, fixes: [], seen: 0, ...(layout.ai || {}) };
  const learned = [];
  const no = txt(saved.invoiceNo).toUpperCase();
  if (no) {
    const sh = shapeOf(no);
    ai.shapes = [sh].concat((ai.shapes || []).filter((x) => x !== sh)).slice(0, MAX_SHAPES);
    ai.examples = [no].concat((ai.examples || []).filter((x) => x !== no)).slice(0, MAX_SHAPES);
  }
  if (saved.vatType) ai.vat = { ...(ai.vat || {}), [saved.vatType]: ((ai.vat || {})[saved.vatType] || 0) + 1 };
  if (read) {
    for (const field of ['invoiceNo', 'total', 'vat', 'invoiceDate']) {
      const was = read[field]; const now = saved[field];
      if (was === undefined || was === null || was === '' || now === undefined || now === null || now === '') continue;
      if (same(field, was, now)) continue;
      const fix = { field, read: field === 'total' || field === 'vat' ? r2(was) : txt(was), right: field === 'total' || field === 'vat' ? r2(now) : txt(now), at: stamp().slice(0, 10) };
      ai.fixes = [fix].concat((ai.fixes || []).filter((x) => !(x.field === fix.field && String(x.read) === String(fix.read)))).slice(0, MAX_FIXES);
      learned.push(`${LABEL[field]} read as ${fix.read}, really ${fix.right}`);
    }
  }
  ai.seen = (ai.seen || 0) + 1;
  layout.ai = ai;
  const now = stamp();
  db().run(`INSERT INTO supplier_layouts (uid, supplier_uid, layout, samples, updated_by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET layout = excluded.layout, updated_by_name = excluded.updated_by_name, updated_at = excluded.updated_at,
    updated_device = excluded.updated_device, sync_status = 'pending'`, [`SL-${supplierUid}`, supplierUid, JSON.stringify(layout), row ? row.samples || 0 : 0, user ? user.name : null, now, deviceId()]);
  if (learned.length) { try { audit({ user, action: `Learned from an invoice: ${learned.join('; ')}`, table: 'supplier_layouts', recordUid: `SL-${supplierUid}` }); } catch (e) { /* the learning is kept */ } }
  return { learned, notes: notesFor(layout) };
  });
}
const LABEL = { invoiceNo: 'invoice number', total: 'total', vat: 'VAT', invoiceDate: 'date' };
const VAT_WORD = { standard: 'standard-rated (VAT on everything)', zero: 'zero-rated (no VAT)', mixed: 'mixed (some lines zero-rated)' };

// The notes the AI is given for this supplier (plain words, short).
export function notesFor(layout) {
  const ai = (layout && layout.ai) || null;
  const out = [];
  if (ai) {
    if ((ai.shapes || []).length) out.push(`invoice numbers look like ${ai.examples && ai.examples.length ? ai.examples.slice(0, 2).join(' or ') : ai.shapes[0]} (pattern ${ai.shapes[0]})`);
    const v = Object.entries(ai.vat || {}).sort((a, b) => b[1] - a[1])[0];
    if (v && v[1] >= 2) out.push(`usually ${VAT_WORD[v[0]] || v[0]}`);
    for (const f of (ai.fixes || []).slice(0, 5)) out.push(`once the ${LABEL[f.field] || f.field} was read as ${f.read} but was really ${f.right}`);
  }
  if (layout && layout.labels && layout.labels.invoiceNo) out.push(`the invoice number is next to "${layout.labels.invoiceNo}"`);
  if (layout && layout.labels && layout.labels.total) out.push(`the total to pay is next to "${layout.labels.total}"`);
  if (layout && layout.pricesIncVat) out.push('line prices include VAT');
  return out.join('; ').slice(0, 400);
}
export function supplierNotes(supplierUid) { const r = rowOf(supplierUid); return r ? notesFor(J(r.layout, {})) : ''; }
export function learnedCount(supplierUid) { const r = rowOf(supplierUid); const l = r ? J(r.layout, {}) : {}; return (l.ai && l.ai.seen) || 0; }

// { supplier name: notes } for the AI (suppliers with something learned).
export function aiNotes(suppliers = []) {
  const out = {};
  let rows = [];
  try { rows = db().all('SELECT supplier_uid, layout FROM supplier_layouts'); } catch (e) { rows = []; }
  const name = new Map((suppliers || []).map((s) => [s.uid, s.name]));
  for (const r of rows) {
    const n = name.get(r.supplier_uid);
    if (!n) continue;
    const t = notesFor(J(r.layout, {}));
    if (t) out[n] = t;
    if (Object.keys(out).length >= 80) break;
  }
  return out;
}
