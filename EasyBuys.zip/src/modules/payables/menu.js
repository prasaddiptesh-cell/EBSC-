// Invoices & cheques menu (see src/services/menus.js).
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🧾', title: 'Due and overdue', note: 'What is owed to suppliers and what to pay next.', screen: 'Payables' },
    { id: 'ap-new', icon: '📷', title: 'New invoice', note: 'Photo of a supplier invoice; check supplier, number and total.', screen: 'ApInvoiceEdit', perm: 'invoices_enter' },
    { id: 'ap-pay', icon: '💸', title: 'Pay a supplier', note: 'Cheque, cash or bank transfer.', screen: 'ApPay' },
    { id: 'ap-payrun', icon: '🗂️', title: 'Pay many at once', note: 'Everything due on one screen, cheques numbered in order.', screen: 'ApPayRun' },
    { id: 'ap-cheque-written', icon: '✍️', title: 'Cheque written', note: 'Staff: supplier, invoice, cheque no. (typed), waiting for pickup or given.', screen: 'ChequeWritten', perm: ['payments_make', 'cheques_manage'] },
    { id: 'ap-cash-paid', icon: '💵', title: 'Paid a supplier in cash', note: 'Staff: which invoice, how much, from the safe or which till, photo of their receipt.', screen: 'PaidCash', perm: ['payments_make', 'cheques_manage'] },
    { id: 'ap-deposit-plans', icon: '🏦', title: 'Deposit plans', note: 'Deposits planned to cover cheques: slip written, banked (stamped slip), on the bank.', screen: 'DepositPlans' },
  ] },
  { section: 'Records', items: [
    { id: 'ap-all', icon: '🧾', title: 'All invoices', note: 'Search by supplier or number.', screen: 'ApInvoices', params: { filter: 'unpaid' } },
    { id: 'ap-credits', icon: '↩️', title: 'Credit notes', screen: 'ApInvoices', params: { filter: 'credits' } },
    { id: 'ap-payments', icon: '📒', title: 'Payments made', note: 'Every payment with the invoices it paid.', screen: 'ApPayments' },
    { id: 'ap-no-supplier', icon: '🏷️', title: 'Products with no supplier', note: 'Give many products a supplier at once.', screen: 'NoSupplierProducts', perm: ['inventory_manage', 'inventory_view', 'ap_setup'] },
    { id: 'ap-suppliers', icon: '🏷️', title: 'Suppliers', note: 'Names, TIN, terms.', screen: 'ApSuppliers' },
    { id: 'chq-cover', icon: '🛡️', title: 'Cheques to cover', note: 'Cheques not yet paid by the bank – is a deposit behind each one? Post-dated cheques too.', screen: 'ChequeCover' },
    { id: 'chq-register', icon: '🏦', title: 'Cheque register', note: 'Every cheque written and whether it has cleared.', screen: 'Cheques', params: { tab: 'register' } },
    { id: 'chq-books', icon: '📗', title: 'Cheque books & stubs', note: 'Each book, leaf by leaf; each stub with payee, invoices, who wrote it, who took it, photo, cleared date.', screen: 'ChequeBooks', perm: ['cheques_manage', 'payments_make'] },
    { id: 'chq-money', icon: '💰', title: 'Deposits & bank fees', screen: 'Cheques', params: { tab: 'money' } },
    { id: 'chq-accounts', icon: '🏛️', title: 'Bank accounts', screen: 'Cheques', params: { tab: 'accounts' } },
  ] },
  { section: 'Checks', items: [
    { id: 'ap-to-check', icon: '🔍', title: 'Invoices to check', screen: 'ApInvoices', params: { filter: 'to_check' }, perm: ['invoices_check', 'ap_setup'] },
    { id: 'ap-standings', icon: '📊', title: 'Supplier standings (week / month)', note: 'Everything still pending per supplier: owing, unpaid with no cheque, cheques not cleared.', screen: 'SupplierStandings', perm: ['payments_make', 'invoices_check', 'verify_money'] },
    { id: 'ap-sup-statement', icon: '📄', title: 'Supplier statement', note: 'Invoices, payments and cheques with a running balance; PDF / Excel / share.', screen: 'ApSupplierStatement', perm: ['payments_make', 'invoices_check'] },
    { id: 'ap-statement', icon: '📑', title: 'Check a supplier statement', note: 'Does their balance agree with ours?', screen: 'ApStatement' },
    { id: 'chq-balance', icon: '⚖️', title: 'Cheque account balance check', screen: 'Cheques', params: { tab: 'balance' } },
  ] },
  { section: 'Reports', items: [
    { id: 'ap-reports', icon: '📊', title: 'Invoice & cheque reports', screen: 'ReportsHub', params: { group: 'Invoices & cheques' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'ap-recurring', icon: '🔁', title: 'Regular bills', note: 'Rent, power, loan repayments; which shop or cost area.', screen: 'Recurring' },
    { id: 'ap-methods', icon: '💳', title: 'Payment methods', note: 'Cheque, cash, transfer – add, rename, hide or remove.', screen: 'PayMethods' },
    { id: 'ap-rules', icon: '⚙️', title: 'Invoice rules', note: 'VAT rate, days to pay, checking, categories.', screen: 'ApRules' },
  ] },
];
