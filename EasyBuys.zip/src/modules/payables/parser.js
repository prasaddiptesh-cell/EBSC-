/**
 * Easy Buys Invoice App - invoice text reader.
 *
 * Takes the text read from an invoice photo/PDF and picks out:
 * supplier, supplier TIN, invoice number, invoice date, subtotal, VAT and total.
 * Every value is only a SUGGESTION - the person scanning checks it before confirming.
 *
 * 1.0.0 (invoice reader rebuild): this is the OFFLINE reader. When online, Google Gemini reads the invoice in the cloud
 * (cloud/Code.gs invoice_ai); this parser is the fall back, and was improved on real Fiji invoices:
 *  - the invoice number on the next line(s) after its label, "INVOICE NUMBER :" / "Invoice Notes" no longer cut,
 *    two labels then two values ("ACCOUNT NO." "INVOICE NO." … CG012495 1050423282), "#0661000069293" under TAX INVOICE
 *  - VAT also from GST / TAX labels, never a percentage, labels stacked above their amounts ("SUB TOTAL: TAX" 332.95 41.62)
 *  - the total: VIP / Invoice Total / Total Incl. VAT first, never the VEP (before VAT) amount
 *  - handwritten amounts "18-00", "379-67", "$18-"
 *  - dates far from today (more than 3 years back, or a year ahead) are not taken ("9/9/20" read as 2020)
 *  - the supplier: matched on TIN, phone and name (also a close name) against the known suppliers; the shop itself
 *    (Easy Buys, TIN 50-14315-0-7) is the buyer, never the supplier.
 */

var EB_VAT_RATE = 0.125;   // Fiji standard rate (FRCS, from 1 Aug 2025). Changeable in Settings.
var EB_BUYER_TIN = '501431507';   // Easy Buys Shopping Centre (the buyer on every supplier invoice)
var EB_BUYER_RE = /easy\s*bu(y|ys|ies)\b|easy\s*boys|easbuy/i;

var MONTHS = {jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9,
              oct: 10, nov: 11, dec: 12};

function ebPad(n) { return (n < 10 ? '0' : '') + n; }

function ebIsoDate(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
  var dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCDate() !== d) return null;            // e.g. 31/02
  return y + '-' + ebPad(m) + '-' + ebPad(d);
}

/** All dates found in a line. Fiji uses day/month/year. */
function ebDatesIn(line) {
  var out = [], m;
  var num = /\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/g;
  while ((m = num.exec(line)) !== null) {
    var iso = ebIsoDate(+m[3], +m[2], +m[1]);
    if (iso) out.push(iso);
  }
  var isoRe = /\b(20\d{2})-(\d{2})-(\d{2})\b/g;
  while ((m = isoRe.exec(line)) !== null) {
    var iso2 = ebIsoDate(+m[1], +m[2], +m[3]);
    if (iso2) out.push(iso2);
  }
  var words = /\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([A-Za-z]{3,9})[\s,\-]+(\d{2,4})\b/g;
  while ((m = words.exec(line)) !== null) {
    var mon = MONTHS[m[2].toLowerCase().slice(0, 4)] || MONTHS[m[2].toLowerCase().slice(0, 3)];
    if (mon) { var iso3 = ebIsoDate(+m[3], mon, +m[1]); if (iso3) out.push(iso3); }
  }
  var words2 = /\b([A-Za-z]{3,9})\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b/g;
  while ((m = words2.exec(line)) !== null) {
    var mon2 = MONTHS[m[1].toLowerCase().slice(0, 4)] || MONTHS[m[1].toLowerCase().slice(0, 3)];
    if (mon2) { var iso4 = ebIsoDate(+m[3], mon2, +m[2]); if (iso4) out.push(iso4); }
  }
  return out;
}

/** A date is believable for an invoice photographed now: at most 3 years old and at most a year ahead. */
function ebPlausibleDate(iso, today) {
  var t = Date.parse((today || new Date().toISOString().slice(0, 10)) + 'T00:00:00Z');
  var d = Date.parse(iso + 'T00:00:00Z');
  if (!isFinite(t) || !isFinite(d)) return true;
  var days = (d - t) / 86400000;
  return days >= -3 * 366 && days <= 366;
}

/**
 * Money amounts in a line, as numbers (e.g. "$1,234.50" -> 1234.5), in the order they are written.
 * Handwritten cents after a dash count too: "18-00", "379-67", "$18-" (not dates like 16-09-2026 or phone numbers).
 * Percentages ("12.5%") are not amounts.
 */
function ebAmountsIn(line) {
  var s = String(line || '').replace(/\d+(?:\.\d+)?\s*%/g, function (x) { return x.replace(/[\d.]/g, ' '); });
  var found = [], m;
  var re = /(?:FJ?\$|\$)?\s*(\d{1,3}(?:,\d{3})+|\d+)\.(\d{2})(?!\d)/g;
  while ((m = re.exec(s)) !== null) {
    found.push({ at: m.index, v: parseFloat(m[1].replace(/,/g, '') + '.' + m[2]) });
  }
  var hw = /(^|[^\d\-\/.:,])(\$\s*)?(\d{1,5})-(\d{2})?(?![\d\-\/])/g;
  while ((m = hw.exec(s)) !== null) {
    if (m[4] === undefined && !m[2]) continue;   // "18-" only with a $ in front
    found.push({ at: m.index + m[1].length, v: parseFloat(m[3] + '.' + (m[4] || '00')) });
  }
  found.sort(function (a, b) { return a.at - b.at; });
  return found.map(function (f) { return f.v; });
}

function ebRound2(x) { return Math.round(x * 100) / 100; }

function ebNorm(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }

// Words that say nothing about which supplier it is.
var EB_GENERIC = /^(ltd|limited|pte|pty|co|company|the|and|group|sons|son|fiji|lautoka|nadi|suva|inc|enterprises?|holdings?|trading|traders)$/;
function ebWords(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9& ]+/g, ' ').split(/\s+/)
    .map(function (w) { return w.replace(/[^a-z0-9]/g, ''); })
    .filter(function (w) { return w.length >= 3 && !EB_GENERIC.test(w); });
}
// One letter wrong (OCR "Jee's" for "Yee's").
function ebClose(a, b) {
  if (a === b) return true;
  if (a.length < 4 || Math.abs(a.length - b.length) > 1) return false;
  var i = 0, j = 0, diff = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) { i++; j++; continue; }
    if (++diff > 1) return false;
    if (a.length > b.length) i++; else if (b.length > a.length) j++; else { i++; j++; }
  }
  return diff + (a.length - i) + (b.length - j) <= 1;
}

/** The known supplier on the invoice: by TIN, then phone, then name, then a close name. → { supplier, by } | null */
function ebMatchSupplier(text, lines, suppliers, tins) {
  var digits = String(text || '').replace(/[^0-9\n]/g, '');
  var sup = (suppliers || []).filter(function (s) { return s && s.name && !EB_BUYER_RE.test(s.name); });
  var i, s;
  for (i = 0; i < sup.length; i++) {
    s = sup[i];
    var t = String(s.tin || '').replace(/[^0-9]/g, '');
    if (t.length >= 7 && t !== EB_BUYER_TIN && tins.indexOf(t) >= 0) return { supplier: s, by: 'tin' };
  }
  for (i = 0; i < sup.length; i++) {
    s = sup[i];
    var t2 = String(s.tin || '').replace(/[^0-9]/g, '');
    if (t2.length >= 8 && t2 !== EB_BUYER_TIN && digits.indexOf(t2) >= 0) return { supplier: s, by: 'tin' };
  }
  for (i = 0; i < sup.length; i++) {
    s = sup[i];
    var ph = String(s.phone || '').replace(/[^0-9]/g, '').replace(/^679/, '');
    if (ph.length >= 7 && !/^0+$/.test(ph) && digits.replace(/\n/g, '').indexOf(ph) >= 0) return { supplier: s, by: 'phone' };
  }
  var flat = ebNorm(text);
  var best = null;
  for (i = 0; i < sup.length; i++) {
    var n = ebNorm(sup[i].name);
    if (n.length >= 4 && flat.indexOf(n) >= 0 && (!best || n.length > best.len)) best = { supplier: sup[i], by: 'name', len: n.length };
  }
  if (best) return best;
  // A close name: most of the supplier's own words are on the invoice (one letter may be misread).
  var textWords = [];
  for (var k = 0; k < Math.min(lines.length, 40); k++) textWords = textWords.concat(ebWords(lines[k]));
  var bestScore = 0, bestSup = null;
  for (i = 0; i < sup.length; i++) {
    var w = ebWords(sup[i].name);
    if (!w.length) continue;
    var hit = w.filter(function (x) { return textWords.some(function (y) { return ebClose(x, y); }); }).length;
    var score = hit / w.length;
    if (hit >= 2 && score >= 0.6 && score > bestScore) { bestScore = score; bestSup = sup[i]; }
  }
  return bestSup ? { supplier: bestSup, by: 'close name' } : null;
}

var EB_TITLE = /^(tax\s*invoice|sales\s*(order|invoice)|invoice|delivery\s*note|customer\s*copy|cash\s*sale|receipt|interim\s*receipt|official\s*receipt|statement|page\b.*|original|duplicate|copy)$/i;
var EB_COMPANY = /\b(ltd|limited|pte|company|co\.|& ?sons|group|distributors?|wholesal\w*|enterprises?|store|supermarket|engineering|works|trading|traders|manufacturing|industries|services)\b/i;
function ebGuessSupplier(lines) {
  var cands = [];
  for (var k = 0; k < Math.min(lines.length, 10); k++) {
    var l = lines[k].replace(/^[^A-Za-z0-9]+/, '');
    if (EB_BUYER_RE.test(l) || EB_TITLE.test(l.trim()) || /^(tel|phone|fax|p\.?\s*o\.?\s*box|www|e-?mail|tin|vat|date|invoice|bill\s*to|sold\s*to|ship|to:|name:|address)/i.test(l) || /@/.test(l)) continue;
    if (!/[a-z]{3,}/i.test(l) || l.length < 4) continue;
    cands.push({ l: l, score: (EB_COMPANY.test(l) ? 10 : 0) + (/[a-z]{3,}.*[a-z]{3,}/i.test(l) ? 1 : 0) - k * 0.1 });
  }
  cands.sort(function (a, b) { return b.score - a.score; });
  if (!cands.length) return null;
  var best = cands[0].l;
  var cut = EB_COMPANY.exec(best);   // "Central Manufacturing Company Pte Limited REGISTERED OFFICE …" → up to the last company word
  if (cut && best.length > 50) {
    var re = new RegExp(EB_COMPANY.source, 'ig'), m, end = 0;
    while ((m = re.exec(best)) !== null) end = m.index + m[0].length;
    if (end) best = best.slice(0, end);
  }
  return best.trim();
}

// ---------------------------------------------------------------- invoice number
var EB_NO_LABEL = /\b(?:tax\s*)?(?:invoice|inv|bill|docket|document|doc)\.?\s*(?:number|num\b\.?|no\b\.?|#)\s*[:.\-#]?\s*/i;
var EB_ANY_NO_LABEL = /\b(?:no\b\.?|number|#)\s*[:.]?\s*$/i;   // "ACCOUNT NO." "ORDER NO." with the value elsewhere
function ebFixCode(c) {
  c = String(c || '').replace(/^[#\\]+/, '').replace(/[.,:;]+$/, '').toUpperCase();
  // "S1-075956" (OCR read the I as 1): a short letter prefix before the dash.
  var m = /^([A-Z][A-Z01]{0,2})-(\d{3,})$/.exec(c);
  if (m && /[01]/.test(m[1])) c = m[1].replace(/1/g, 'I').replace(/0/g, 'O') + '-' + m[2];
  return c;
}
// A value that can be an invoice number: one or two short tokens with digits, not a date, amount, time or phone label.
function ebCodeOn(line) {
  var l = String(line || '').replace(/^[\s:#.\-\\]+/, '').trim();
  if (!l || ebDatesIn(l).length || /\d{1,2}:\d{2}/.test(l) || /^\$|^page\b/i.test(l)) return null;
  var toks = l.split(/\s+/);
  if (toks.length > 3) return null;
  if (!toks.every(function (t) { return /\d/.test(t) || /^[A-Z]{1,3}$/.test(t); })) return null;
  // "A 106088" → A106088
  if (toks.length >= 2 && /^[A-Z]{1,3}$/.test(toks[0]) && /^\d{4,}$/.test(toks[1])) return ebFixCode(toks[0] + toks[1]);
  var t0 = toks[0];
  if (!/\d/.test(t0) || t0.length < 3 || /^\d+\.\d{2}$/.test(t0) || /^(19|20)\d{2}$/.test(t0)) return null;
  if (!/^[#\\]*[A-Z0-9][A-Z0-9\-\/]{1,30}$/i.test(t0)) return null;
  return ebFixCode(t0);
}
function ebInvoiceNo(lines) {
  var i, m, c;
  // 1) on the same line as its label: "Invoice No: SI-075956", "Invoice # 4003", "Tax Invoice No. 123"
  for (i = 0; i < lines.length; i++) {
    m = EB_NO_LABEL.exec(lines[i]);
    if (!m || /\b(sdc|fiscal|vms|e-?invoice)\b/i.test(lines[i])) continue;   // the VMS fiscal number is not the supplier's invoice number
    var rest = lines[i].slice(m.index + m[0].length);
    var t = /^([A-Z0-9][A-Z0-9\-\/]{1,30})/i.exec(rest);
    if (t && /\d/.test(t[1]) && !/^(date|no|number)$/i.test(t[1])) return ebFixCode(t[1]);
  }
  // 2) "#0661000069293" / "SINV165193" right under "TAX INVOICE"
  for (i = 0; i < lines.length; i++) {
    if (!/^(tax\s*)?invoice$/i.test(lines[i])) continue;
    for (var j = i + 1; j <= i + 2 && j < lines.length; j++) {
      c = /^[#\\]*([A-Z]{0,5}\d{5,}[A-Z0-9\-\/]*)$/i.exec(lines[j]);
      if (c) return ebFixCode(c[1]);
    }
  }
  // 3) the label alone, the value on a later line. Labels just above it without their value ("ACCOUNT NO." then
  //    "INVOICE NO.") are filled in the same order, so their values are skipped.
  for (i = 0; i < lines.length; i++) {
    if (!/\b(invoice|inv)\.?\s*(number|num\b\.?|no\b\.?|#)\s*[:.]?\s*$/i.test(lines[i])) continue;
    var skip = 0;
    for (var b = i - 1; b >= 0 && b >= i - 3 && EB_ANY_NO_LABEL.test(lines[b]) && !ebCodeOn(lines[b].replace(EB_ANY_NO_LABEL, '')); b--) skip++;
    for (var k = i + 1; k < lines.length && k <= i + 12; k++) {
      c = ebCodeOn(lines[k]);
      if (!c) continue;
      if (skip > 0) { skip--; continue; }
      return c;
    }
  }
  // 4) older forms: "Invoice: A1234"
  for (i = 0; i < lines.length; i++) {
    if (/\b(sdc|fiscal|vms)\b/i.test(lines[i])) continue;
    m = /\b(?:invoice|inv)\b[^A-Za-z0-9]{0,3}([A-Z]{0,4}\d[\dA-Z\-\/]{2,20})/i.exec(lines[i]);
    if (m && !/^notes?$/i.test(m[1])) return ebFixCode(m[1]);
  }
  // 5) a cash-sale docket: the printed number near the DATE / CASH SALE box ("A 106088", "4003")
  for (i = 0; i < lines.length; i++) {
    if (!/\b(date|cash\s*sale|invoice)\b/i.test(lines[i])) continue;
    for (var n = i + 1; n < lines.length && n <= i + 4; n++) {
      var d = /^(?:no\.?\s*)?([A-Z]{1,2}\s?\d{4,8}|\d{4,6})$/i.exec(lines[n]);
      if (d && !/^(19|20)\d{2}$/.test(d[1])) return ebFixCode(d[1].replace(/\s+/g, ''));
    }
  }
  return null;
}

// ---------------------------------------------------------------- dates
function ebInvoiceDate(lines, today, res) {
  var seen = [];
  var ok = function (list) {
    for (var q = 0; q < list.length; q++) { seen.push(list[q]); if (ebPlausibleDate(list[q], today)) return list[q]; }
    return null;
  };
  var i, d;
  // "INVOICE DATE :" with the date on the same line or within the next few lines
  for (i = 0; i < lines.length; i++) {
    if (!/\b(invoice|inv|document|posting|tax\s*invoice)\s*date\b/i.test(lines[i])) continue;
    d = ok(ebDatesIn(lines[i]));
    for (var k = i + 1; !d && k < lines.length && k <= i + 6; k++) { if (/due/i.test(lines[k])) break; d = ok(ebDatesIn(lines[k])); }
    if (d) return d;
  }
  // a line saying "date" (not "due" / "expiry" / "delivery" / "order")
  for (i = 0; i < lines.length; i++) {
    if (/date/i.test(lines[i]) && !/due|expir|delivery|order|printed/i.test(lines[i])) { d = ok(ebDatesIn(lines[i])); if (d) return d; }
  }
  // "DATE 9/9/" … "2026": a handwritten date with the year on its own line
  for (i = 0; i < lines.length; i++) {
    var p = /\bdate\b\D{0,4}(\d{1,2})[\/.\-](\d{1,2})[\/.\-]?\s*$/i.exec(lines[i]);
    if (!p) continue;
    for (var y = i + 1; y < lines.length && y <= i + 3; y++) {
      var yy = /^(20\d{2})$/.exec(lines[y]);
      if (yy) { var iso = ebIsoDate(+yy[1], +p[2], +p[1]); if (iso && ebPlausibleDate(iso, today)) return iso; }
    }
  }
  for (i = 0; i < lines.length; i++) {
    if (/due|printed/i.test(lines[i])) continue;
    d = ok(ebDatesIn(lines[i]));
    if (d) return d;
  }
  if (seen.length) res.notes.push('A date ' + seen[0] + ' was read but it is far from today - type the invoice date.');
  return null;
}

// ---------------------------------------------------------------- amounts
var EB_LABELS = [
  { k: 'total', re: /t[o0]t[ua]l\W*(\(?vip\)?|incl?\.?|inc\b|vat\s*incl\w*)|invoice\s*total|grand\s*total|total\s*(amount\s*)?(due|payable)|amount\s*(due|payable)|balance\s*due|vat\s*inclusive|\bvip\b/i },
  { k: 'subtotal', re: /sub\s*-?\s*total|total\s*(vep|excl\w*)|excl\.?\s*vat|amount\s*excl|net\s*amount|\bvep\b/i },
  { k: 'vat', re: /\b(vat|v\.a\.t|gst|tax)\b/i },
  { k: 'freight', re: /\b(freight|delivery\s*charge|cartage)\b/i },
  { k: 'total0', re: /\btotal\b/i },
];
var EB_NOT_VAT = /(vat|gst|tax)\s*(reg\w*|no\b\.?|number|#|invoice|id\b)|\btin\b|tax\s*invoice|inclusive|incl\b|\bvip\b|vat\s*-\s*(zero|exempt)|zero\s*rated|exempt|vat\s*%|\btax\s*code/i;
function ebLabelsOn(line) {
  // the labels written on one line, in order ("SUB TOTAL: TAX" → subtotal, vat; "Freight TOTAL" → freight, total)
  var out = [];
  var s = ' ' + line + ' ';
  var re = /t[o0]t[ua]l\W*\(?vip\)?|total\W*incl?\.?(\s*vat)?|invoice\s*total|grand\s*total|sub\s*-?\s*total|total\s*vep(\s*amount)?|total\s*vat(\s*amount)?|vat\s*amount|vep|vat|gst|tax|freight|total/ig;
  var m;
  while ((m = re.exec(s)) !== null) {
    var w = m[0].toLowerCase();
    var k = /vip|incl|invoice\s*total|grand/.test(w) ? 'total' : /sub|vep/.test(w) ? 'subtotal' : /vat|gst|tax/.test(w) ? 'vat' : /freight/.test(w) ? 'freight' : 'total0';
    out.push(k);
  }
  return out;
}
function ebStacked(lines) {
  // Labels on lines without amounts, then the same number of amount-only lines: matched in order.
  var found = {};
  for (var i = 0; i < lines.length; i++) {
    if (ebAmountsIn(lines[i]).length || EB_NOT_VAT.test(lines[i]) && !/sub|total/i.test(lines[i])) continue;
    var labs = [];
    var j = i;
    while (j < lines.length && j < i + 3 && !ebAmountsIn(lines[j]).length) {
      var l = ebLabelsOn(lines[j]);
      if (!l.length || lines[j].length > 40) break;
      labs = labs.concat(l);
      j++;
    }
    if (labs.length < 2) continue;
    var vals = [];
    while (j < lines.length && vals.length < labs.length && /^[\s$FJD]*[\d,]+[.\-]\d{2}\s*$/i.test(lines[j])) { vals.push(ebAmountsIn(lines[j])[0]); j++; }
    if (vals.length !== labs.length) continue;
    for (var q = 0; q < labs.length; q++) found[labs[q]] = vals[q];
    i = j - 1;
  }
  return found;
}

/**
 * @param {string} text   text read from the invoice
 * @param {Array} suppliers  known suppliers [{name, tin, phone}] to match against
 * @param {number} vatRate   e.g. 0.125
 * @param {object} opts      { today: 'YYYY-MM-DD' } (for the date check; default the device date)
 */
function parseInvoiceText(text, suppliers, vatRate, opts) {
  vatRate = vatRate || EB_VAT_RATE;
  suppliers = suppliers || [];
  opts = opts || {};
  var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.replace(/\\([#&!*_\-])/g, '$1').replace(/\s+/g, ' ').trim(); })
    .filter(function (l) { return l.length > 0; });
  var res = {supplier: null, supplier_tin: null, invoice_no: null, invoice_date: null,
             subtotal: null, vat: null, total: null, notes: [], supplier_by: null};

  // --- TINs on the invoice (the buyer's own TIN is never the supplier's)
  var tins = [];
  for (var i = 0; i < lines.length; i++) {
    var tre = /\b(?:TIN|GST\s*Number|VAT\s*(?:Reg(?:istration)?\.?)?\s*(?:No|Number|#)?)\b\s*(?:No\.?)?\s*[:.#\-]?\s*([0-9][0-9\- .]{5,16}[0-9])/ig, t;
    while ((t = tre.exec(lines[i])) !== null) {
      var tv = t[1].replace(/[\s\-.]/g, '');
      if (tv.length >= 7 && tv !== EB_BUYER_TIN && !/buyer|customer|bill\s*to/i.test(lines[i].slice(0, t.index))) tins.push(tv);
    }
    // "TIN No:" with the number on the next line
    if (/\b(TIN|VAT\s*No)\b[^0-9]*$/i.test(lines[i]) && !/buyer|customer/i.test(lines[i]) && lines[i + 1]) {
      var nx = /^([0-9][0-9\- ]{6,16}[0-9])$/.exec(lines[i + 1]);
      if (nx) { var nv = nx[1].replace(/[\s\-]/g, ''); if (nv !== EB_BUYER_TIN) tins.push(nv); }
    }
  }
  if (tins.length) res.supplier_tin = tins[0];

  // --- supplier: a known supplier by TIN, phone or name; otherwise the company name at the top
  var hit = ebMatchSupplier(text, lines, suppliers, tins);
  if (hit) {
    res.supplier = hit.supplier.name; res.supplier_by = hit.by;
    var st = String(hit.supplier.tin || '').replace(/[^0-9]/g, '');
    if (st.length >= 7) res.supplier_tin = st;
  } else {
    var lab = null;
    for (var sl = 0; sl < lines.length && !lab; sl++) { var sm = /^(?:supplier|from|seller)\s*:\s*(.{3,80})$/i.exec(lines[sl]); if (sm) lab = sm[1].trim(); }
    res.supplier = lab || ebGuessSupplier(lines);
    if (res.supplier) res.notes.push('New supplier? Check the name.');
  }

  // --- invoice number
  res.invoice_no = ebInvoiceNo(lines);

  // --- invoice date
  res.invoice_date = ebInvoiceDate(lines, opts.today, res);

  // --- amounts
  function lastAmount(re, exclude, wantFirst) {
    var found = null;
    for (var x = 0; x < lines.length; x++) {
      if (re.test(lines[x]) && !(exclude && exclude.test(lines[x]))) {
        var am = ebAmountsIn(lines[x]);
        // the amount on the next line (a percentage line such as "12.5%" between is passed over)
        for (var y = x + 1; !am.length && y < lines.length && y <= x + 2; y++) {
          if (/^[\d.\s]+%$/.test(lines[y])) continue;
          if (/[a-z]{4}/i.test(lines[y])) break;
          am = ebAmountsIn(lines[y]);
          break;
        }
        if (am.length) { found = am[am.length - 1]; if (wantFirst) return found; }
      }
    }
    return found;
  }
  var stacked = ebStacked(lines);
  var TOTAL_STRONG = EB_LABELS[0].re;
  var NOT_TOTAL = /sub\s*-?\s*total|total\s*(excl|vep|vat\b(?!\s*incl)|tax|qty|quantity|items|weight|purchase)|\bvep\b|qty|quantity|items|carried|brought/i;
  res.total = lastAmount(TOTAL_STRONG, /sub\s*-?\s*total|\bvep\b|excl/i);
  if (res.total === null && stacked.total !== undefined) res.total = stacked.total;
  if (res.total === null) res.total = lastAmount(/(^total\b|\btotal\s*\$?\s*[\d,]+\.\d{2}\s*$|\btotal\s*(fjd|amount)\b)/i, NOT_TOTAL);
  if (res.total === null && stacked.total0 !== undefined) res.total = stacked.total0;
  res.subtotal = lastAmount(/(sub\s*-?\s*total|total\s*excl|excl\.?\s*vat|amount\s*excl|net\s*amount|\bvep\b)/i, null);
  if (res.subtotal === null && stacked.subtotal !== undefined) res.subtotal = stacked.subtotal;
  res.vat = lastAmount(/\b(vat|v\.a\.t|gst|tax)\b/i, EB_NOT_VAT);
  if (stacked.vat !== undefined && (res.vat === null || res.vat === stacked.subtotal || res.vat === stacked.total)) res.vat = stacked.vat;
  if (res.vat !== null && res.total !== null && res.vat >= res.total && res.total > 0) res.vat = null;   // the VAT is never the whole total
  if (res.vat !== null && res.subtotal !== null && res.vat >= res.subtotal && res.subtotal > 0) res.vat = null;

  // fallback total = largest amount on the document
  if (res.total === null) {
    var all = [];
    lines.forEach(function (l) { all = all.concat(ebAmountsIn(l)); });
    if (all.length) { res.total = Math.max.apply(null, all); res.notes.push('Total guessed as the largest amount.'); }
  }
  // fill gaps from each other
  if (res.total !== null && res.vat === null && res.subtotal !== null && res.total >= res.subtotal && res.total - res.subtotal < res.total * 0.2) {
    res.vat = ebRound2(res.total - res.subtotal);
  }
  if (res.total === null && res.subtotal !== null && res.vat !== null) res.total = ebRound2(res.subtotal + res.vat);
  // A VAT-inclusive (VIP) price with no VAT printed: the VAT inside it.
  if (res.total !== null && res.vat === null && /vat\s*inclusive|\(?\bvip\b\)?|incl\.?\s*vat/i.test(text || '')) {
    res.vat = ebRound2(res.total * vatRate / (1 + vatRate));
    res.notes.push('VAT worked out from the VAT-inclusive total - check it.');
  }
  if (res.subtotal === null && res.total !== null && res.vat !== null) res.subtotal = ebRound2(res.total - res.vat);

  // sanity check VAT against the standard rate
  if (res.total !== null && res.vat !== null && res.vat > 0) {
    var expected = ebRound2(res.total * vatRate / (1 + vatRate));
    if (Math.abs(expected - res.vat) > 0.10) {
      res.notes.push('VAT ' + res.vat.toFixed(2) + ' is not ' + Math.round(vatRate * 1000) / 10 + '% of the total (expected about ' +
                     expected.toFixed(2) + '). Check - part of the invoice may be zero-rated.');
    }
  }
  if (res.total !== null && res.vat === null) res.notes.push('No VAT found - zero-rated, or check the invoice.');
  ['supplier', 'invoice_no', 'invoice_date', 'total'].forEach(function (f) {
    if (!res[f]) res.notes.push('Could not read the ' + f.replace('_', ' ') + '.');
  });
  res.found = ['supplier', 'supplier_tin', 'invoice_no', 'invoice_date', 'total', 'vat']
    .filter(function (f) { return res[f] !== null; }).length;
  return res;
}

/** How well a reading went (0–6): used to decide whether to ask the cloud as well. */
function ebReadStrength(p) {
  if (!p) return 0;
  return (p.supplier ? 1 : 0) + (p.invoice_no ? 1 : 0) + (p.invoice_date ? 1 : 0) + (p.total !== null && p.total !== undefined ? 2 : 0) + (p.vat !== null && p.vat !== undefined ? 1 : 0);
}

export { parseInvoiceText, ebDatesIn, ebAmountsIn, ebPlausibleDate, ebMatchSupplier, ebReadStrength, EB_BUYER_TIN, EB_BUYER_RE };
