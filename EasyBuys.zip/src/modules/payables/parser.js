/**
 * Easy Buys Invoice App - invoice text reader.
 *
 * Takes the text Google reads from an invoice photo/PDF and picks out:
 * supplier, supplier TIN, invoice number, invoice date, subtotal, VAT and total.
 * Every value is only a SUGGESTION - the person scanning checks it before confirming.
 *
 * Runs on the tablet/phone: the cloud only turns the photo into text (when online).
 */

var EB_VAT_RATE = 0.125;   // Fiji standard rate (FRCS, from 1 Aug 2025). Changeable in Settings.

var MONTHS = {jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9,
              oct: 10, nov: 11, dec: 12};

function ebPad(n) { return (n < 10 ? '0' : '') + n; }

function ebIsoDate(y, m, d) {
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31 || y < 2000 || y > 2100) return null;
  var dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCDate() !== d) return null;            // e.g. 31/02
  return y + '-' + ebPad(m) + '-' + ebPad(d);
}

/** All dates found in a line. Fiji uses day/month/year. */
function ebDatesIn(line) {
  var out = [], m;
  var num = /\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/g;
  while ((m = num.exec(line)) !== null) {
    var iso = ebIsoDate(+m[3], +m[2], +m[1]);
    if (iso) out.push(iso);
  }
  var isoRe = /\b(20\d{2})-(\d{2})-(\d{2})\b/g;
  while ((m = isoRe.exec(line)) !== null) {
    var iso2 = ebIsoDate(+m[1], +m[2], +m[3]);
    if (iso2) out.push(iso2);
  }
  var words = /\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([A-Za-z]{3,9})[\s,\-]+(\d{2,4})\b/g;
  while ((m = words.exec(line)) !== null) {
    var mon = MONTHS[m[2].toLowerCase().slice(0, 4)] || MONTHS[m[2].toLowerCase().slice(0, 3)];
    if (mon) { var iso3 = ebIsoDate(+m[3], mon, +m[1]); if (iso3) out.push(iso3); }
  }
  var words2 = /\b([A-Za-z]{3,9})\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b/g;
  while ((m = words2.exec(line)) !== null) {
    var mon2 = MONTHS[m[1].toLowerCase().slice(0, 4)] || MONTHS[m[1].toLowerCase().slice(0, 3)];
    if (mon2) { var iso4 = ebIsoDate(+m[3], mon2, +m[2]); if (iso4) out.push(iso4); }
  }
  return out;
}

/** Money amounts in a line, as numbers (e.g. "$1,234.50" -> 1234.5). */
function ebAmountsIn(line) {
  var out = [], m;
  var re = /(?:FJ?\$|\$)?\s*(\d{1,3}(?:,\d{3})+|\d+)\.(\d{2})(?!\d)/g;
  while ((m = re.exec(line)) !== null) {
    out.push(parseFloat(m[1].replace(/,/g, '') + '.' + m[2]));
  }
  return out;
}

function ebRound2(x) { return Math.round(x * 100) / 100; }

function ebNorm(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, ''); }

/**
 * @param {string} text   text read from the invoice
 * @param {Array} suppliers  known suppliers [{name, tin}] to match against
 * @param {number} vatRate   e.g. 0.125
 */
function parseInvoiceText(text, suppliers, vatRate) {
  vatRate = vatRate || EB_VAT_RATE;
  suppliers = suppliers || [];
  var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.replace(/\s+/g, ' ').trim(); })
    .filter(function (l) { return l.length > 0; });
  var res = {supplier: null, supplier_tin: null, invoice_no: null, invoice_date: null,
             subtotal: null, vat: null, total: null, notes: []};

  // --- supplier TIN (first TIN-looking number; customer TIN usually comes later)
  for (var i = 0; i < lines.length && !res.supplier_tin; i++) {
    var t = /\b(?:TIN|VAT\s*(?:Reg(?:istration)?\.?)?\s*(?:No|Number|#)?)\s*[:.#\-]?\s*([0-9][0-9\- ]{6,16}[0-9])/i.exec(lines[i]);
    if (t) res.supplier_tin = t[1].replace(/[\s\-]/g, '');
  }

  // --- supplier: match a known supplier by TIN, then by name
  var flat = ebNorm(text);
  for (var s = 0; s < suppliers.length && !res.supplier; s++) {
    if (res.supplier_tin && suppliers[s].tin && ebNorm(suppliers[s].tin) === res.supplier_tin) {
      res.supplier = suppliers[s].name;
    }
  }
  for (var s2 = 0; s2 < suppliers.length && !res.supplier; s2++) {
    var n = ebNorm(suppliers[s2].name);
    if (n.length >= 4 && flat.indexOf(n) >= 0) res.supplier = suppliers[s2].name;
  }
  if (!res.supplier) {
    for (var k = 0; k < Math.min(lines.length, 6); k++) {
      if (!/tax\s*invoice|^invoice$|^page|^tel|^phone|^p\.?o\.? box|^www|@/i.test(lines[k]) &&
          /[a-z]{3,}/i.test(lines[k])) { res.supplier = lines[k]; res.notes.push('New supplier? Check the name.'); break; }
    }
  }

  // --- invoice number
  var invRe = /\b(?:tax\s*)?(?:invoice|inv|bill)\s*(?:no\.?|number|num\.?|#)\s*[:.\-#]?\s*([A-Z0-9][A-Z0-9\-\/]{1,24})/i;
  for (var a = 0; a < lines.length && !res.invoice_no; a++) {
    var mm = invRe.exec(lines[a]);
    if (mm && !/^(date|no|number)$/i.test(mm[1])) res.invoice_no = mm[1].toUpperCase();
  }
  if (!res.invoice_no) {
    for (var b = 0; b < lines.length && !res.invoice_no; b++) {
      var m2 = /\b(?:invoice|inv)\b[^A-Za-z0-9]{0,3}([A-Z]{0,4}\d[\dA-Z\-\/]{2,20})/i.exec(lines[b]);
      if (m2) res.invoice_no = m2[1].toUpperCase();
    }
  }

  // --- invoice date: prefer a line saying "date" (not "due")
  for (var c = 0; c < lines.length && !res.invoice_date; c++) {
    if (/date/i.test(lines[c]) && !/due|expir|delivery|order/i.test(lines[c])) {
      var ds = ebDatesIn(lines[c]);
      if (ds.length) res.invoice_date = ds[0];
    }
  }
  for (var d = 0; d < lines.length && !res.invoice_date; d++) {
    if (/due/i.test(lines[d])) continue;
    var ds2 = ebDatesIn(lines[d]);
    if (ds2.length) res.invoice_date = ds2[0];
  }

  // --- amounts
  function lastAmount(re, exclude) {
    var found = null;
    for (var x = 0; x < lines.length; x++) {
      if (re.test(lines[x]) && !(exclude && exclude.test(lines[x]))) {
        var am = ebAmountsIn(lines[x]);
        if (!am.length && x + 1 < lines.length) am = ebAmountsIn(lines[x + 1]); // amount on next line
        if (am.length) found = am[am.length - 1];
      }
    }
    return found;
  }
  res.total = lastAmount(/(grand\s*total|total\s*(amount\s*)?(due|payable)|amount\s*due|total\s*(incl|inc\.?|vip|vat\s*incl)|balance\s*due|^total\b|\btotal\s*\$?\s*[\d,]+\.\d{2}\s*$)/i,
                         /sub\s*-?\s*total|total\s*(excl|vat\b(?!\s*incl))|qty|quantity|items/i);
  res.subtotal = lastAmount(/(sub\s*-?\s*total|total\s*excl|excl\.?\s*vat|amount\s*excl|net\s*amount|vep)/i, null);
  res.vat = lastAmount(/\b(vat|v\.a\.t)\b/i, /(vat\s*(reg|no\.?\b|number|#)|tin|incl|inclusive|vip)/i);

  // fallback total = largest amount on the document
  if (res.total === null) {
    var all = [];
    lines.forEach(function (l) { all = all.concat(ebAmountsIn(l)); });
    if (all.length) { res.total = Math.max.apply(null, all); res.notes.push('Total guessed as the largest amount.'); }
  }
  // fill gaps from each other
  if (res.total !== null && res.vat === null && res.subtotal !== null && res.total >= res.subtotal) {
    res.vat = ebRound2(res.total - res.subtotal);
  }
  if (res.total === null && res.subtotal !== null && res.vat !== null) res.total = ebRound2(res.subtotal + res.vat);
  if (res.subtotal === null && res.total !== null && res.vat !== null) res.subtotal = ebRound2(res.total - res.vat);

  // sanity check VAT against the standard rate
  if (res.total !== null && res.vat !== null && res.vat > 0) {
    var expected = ebRound2(res.total * vatRate / (1 + vatRate));
    if (Math.abs(expected - res.vat) > 0.10) {
      res.notes.push('VAT ' + res.vat.toFixed(2) + ' is not ' + Math.round(vatRate * 1000) / 10 + '% of the total (expected about ' +
                     expected.toFixed(2) + '). Check - part of the invoice may be zero-rated.');
    }
  }
  if (res.total !== null && res.vat === null) res.notes.push('No VAT found - zero-rated, or check the invoice.');
  ['supplier', 'invoice_no', 'invoice_date', 'total'].forEach(function (f) {
    if (!res[f]) res.notes.push('Could not read the ' + f.replace('_', ' ') + '.');
  });
  res.found = ['supplier', 'supplier_tin', 'invoice_no', 'invoice_date', 'total', 'vat']
    .filter(function (f) { return res[f] !== null; }).length;
  return res;
}

export { parseInvoiceText, ebDatesIn, ebAmountsIn };
