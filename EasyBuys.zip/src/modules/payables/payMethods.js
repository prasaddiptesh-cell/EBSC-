// Payment methods (Invoices & cheques › Payment methods): the admin adds, renames, hides or removes them. Each one works
// like a cheque (from the bank, with a cheque number), cash (from a shop's cash) or a bank transfer (with a reference),
// so the books stay right. The three standard ones can be hidden or renamed but not removed.
import { AppError, getShared, setShared, audit, uuid } from '../../services/core.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
export const BASES = [{ value: 'cheque', label: 'Cheque (from the bank)' }, { value: 'cash', label: 'Cash (from a shop)' }, { value: 'transfer', label: 'Bank transfer' }];
const DEFAULTS = [
  { id: 'cheque', label: 'BSP cheque', icon: '🏦', base: 'cheque', builtin: true, active: true },
  { id: 'cash', label: 'Cash', icon: '💵', base: 'cash', builtin: true, active: true },
  { id: 'transfer', label: 'Bank transfer', icon: '📲', base: 'transfer', builtin: true, active: true },
];

export function payMethods({ all = false } = {}) {
  const saved = getShared('pay_methods', null);
  const list = Array.isArray(saved) && saved.length ? saved : DEFAULTS;
  // The standard three are always there (they can only be hidden).
  const out = DEFAULTS.map((d) => ({ ...d, ...(list.find((x) => x.id === d.id) || {}), builtin: true, base: d.base })).concat(list.filter((x) => !DEFAULTS.some((d) => d.id === x.id)));
  return all ? out : out.filter((m) => m.active !== false);
}
export function payMethod(id) { return payMethods({ all: true }).find((m) => m.id === id) || null; }
export function baseOf(id) { const m = payMethod(id); return m ? m.base : (['cheque', 'cash', 'transfer'].includes(id) ? id : 'cheque'); }
export function methodLabel(id) { const m = payMethod(id); return m ? m.label : id; }
function save(user, list, action) { setShared('pay_methods', list); audit({ user, action, table: 'shared_settings', recordUid: 'pay_methods' }); return payMethods({ all: true }); }
const admin = (user) => need(user && ['owner', 'admin'].includes(user.role), 'Only the owner or admin changes the payment methods.');

export function addPayMethod(user, { label, base, icon }) {
  admin(user);
  const l = String(label || '').trim();
  need(l, 'Type the name, e.g. M-PAiSA or BSP Pay.');
  need(BASES.some((b) => b.value === base), 'Choose how it works: cheque, cash or bank transfer.');
  const list = payMethods({ all: true });
  need(!list.some((m) => m.label.toLowerCase() === l.toLowerCase()), `${l} is already there.`);
  return save(user, list.concat([{ id: uuid('PM'), label: l, icon: String(icon || '💳'), base, active: true }]), `Payment method added: ${l}`);
}
export function setPayMethodActive(user, id, active) {
  admin(user);
  const list = payMethods({ all: true });
  const m = list.find((x) => x.id === id);
  need(m, 'Not found.');
  if (!active) need(list.filter((x) => x.active !== false && x.id !== id).length, 'Keep at least one payment method.');
  return save(user, list.map((x) => (x.id === id ? { ...x, active: !!active } : x)), `Payment method ${active ? 'shown' : 'hidden'}: ${m.label}`);
}
export function renamePayMethod(user, id, label) {
  admin(user);
  const l = String(label || '').trim();
  need(l, 'Type the name.');
  const list = payMethods({ all: true });
  need(list.some((x) => x.id === id), 'Not found.');
  return save(user, list.map((x) => (x.id === id ? { ...x, label: l } : x)), `Payment method renamed to ${l}`);
}
export function removePayMethod(user, id) {
  admin(user);
  const list = payMethods({ all: true });
  const m = list.find((x) => x.id === id);
  need(m, 'Not found.');
  need(!m.builtin, `${m.label} is a standard method – hide it instead.`);
  need(list.filter((x) => x.active !== false && x.id !== id).length, 'Keep at least one payment method.');
  return save(user, list.filter((x) => x.id !== id), `Payment method removed: ${m.label} (past payments keep it)`);
}
