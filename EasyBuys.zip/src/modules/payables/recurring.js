// Regular bills and loans. Each makes its invoice a few days before it is due, so it shows in
// "Due soon" and is paid like any other invoice (cheque / cash / transfer, with the pay trail).
// The invoice id is made from the bill and the date, so two devices never create it twice.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr } from '../../services/core.js';
import { r2, getSupplier, getInvoice, workOutVat, apRules, $ } from './service.js';

const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
export const FREQ_LABEL = { weekly: 'Every week', fortnightly: 'Every 2 weeks', monthly: 'Every month', quarterly: 'Every 3 months', yearly: 'Every year' };

// anchorDay: the day of the month the bill is really due (so 31 Jan -> 28 Feb -> 31 Mar, not 28 Mar).
export function nextDate(d, freq, anchorDay) {
  if (freq === 'weekly') return addDays(d, 7);
  if (freq === 'fortnightly') return addDays(d, 14);
  const months = { monthly: 1, quarterly: 3, yearly: 12 }[freq];
  const [y, m, day] = d.split('-').map(Number);
  const t = new Date(y, m - 1 + months, 1);
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  t.setDate(Math.min(anchorDay || day, last));
  return dateStr(t);
}

export function listRecurring({ kind, includeInactive = false } = {}) {
  return db().all(`SELECT r.*, s.name AS supplier_name FROM ap_recurring r LEFT JOIN ap_suppliers s ON s.uid = r.supplier_uid
    WHERE (? IS NULL OR r.kind = ?) AND (? = 1 OR r.active = 1) ORDER BY r.kind, r.next_date`, [kind || null, kind || null, includeInactive ? 1 : 0]);
}
export function getRecurring(uid) {
  return db().get('SELECT r.*, s.name AS supplier_name FROM ap_recurring r LEFT JOIN ap_suppliers s ON s.uid = r.supplier_uid WHERE r.uid = ?', [uid]);
}

export function saveRecurring(user, f) {
  const kind = f.kind === 'loan' ? 'loan' : 'bill';
  const name = txt(f.name);
  need(name, kind === 'loan' ? 'Name the loan, e.g. "Shop 1 business loan".' : 'Name the bill, e.g. "Shop 2 rent".');
  need(getSupplier(f.supplierUid), kind === 'loan' ? 'Choose the lender (add it as a supplier first, e.g. BSP, Credit Corp).' : 'Choose who is paid.');
  const amount = r2(f.amount);
  need(amount > 0, kind === 'loan' ? 'Enter the repayment amount.' : 'Enter the amount.');
  need(FREQ_LABEL[f.frequency], 'Choose how often.');
  need(DATE.test(txt(f.nextDate)), 'Enter the next due date as YYYY-MM-DD.');
  need(!txt(f.endDate) || (DATE.test(txt(f.endDate)) && f.endDate >= f.nextDate), 'The end date must be after the next due date.');
  const lead = Math.round(Number(f.leadDays === undefined || f.leadDays === '' ? 7 : f.leadDays));
  need(lead >= 0 && lead <= 60, 'Days before must be between 0 and 60.');
  if (kind === 'loan') {
    need(Number.isFinite(Number(f.openingBalance)) && Number(f.openingBalance) >= 0, 'Enter the loan balance on the start date.');
    need(DATE.test(txt(f.openingDate)), 'Enter the date of that balance.');
  }
  const uid = f.uid || uuid(kind === 'loan' ? 'LN' : 'RB');
  const before = getRecurring(uid);
  const now = stamp();
  const anchor = before && before.next_date === f.nextDate && before.anchor_day ? before.anchor_day : Number(String(f.nextDate).slice(8, 10));
  const vals = [kind, name, f.supplierUid, amount, kind === 'loan' ? 'zero' : (f.vatType || 'standard'), f.frequency, f.nextDate, txt(f.endDate) || null, lead, f.shopCode || null,
    txt(f.category) || (kind === 'loan' ? 'Loan repayment' : null), txt(f.loanNo) || null, txt(f.security) || null, kind === 'loan' ? r2(f.openingBalance) : null,
    kind === 'loan' ? f.openingDate : null, f.interestRate === '' || f.interestRate === undefined ? null : Number(f.interestRate), txt(f.notes) || null, f.active === false ? 0 : 1, anchor, now, deviceId()];
  db().run(`INSERT INTO ap_recurring (kind, name, supplier_uid, amount, vat_type, frequency, next_date, end_date, lead_days, shop_code, category, loan_no, security, opening_balance, opening_date, interest_rate, notes, active, anchor_day, updated_at, updated_device, uid)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET kind=excluded.kind, name=excluded.name, supplier_uid=excluded.supplier_uid, amount=excluded.amount, vat_type=excluded.vat_type,
    frequency=excluded.frequency, next_date=excluded.next_date, end_date=excluded.end_date, lead_days=excluded.lead_days, shop_code=excluded.shop_code, category=excluded.category, loan_no=excluded.loan_no,
    security=excluded.security, opening_balance=excluded.opening_balance, opening_date=excluded.opening_date, interest_rate=excluded.interest_rate, notes=excluded.notes, active=excluded.active, anchor_day=excluded.anchor_day,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`, vals.concat([uid]));
  audit({ user, action: `${before ? 'Changed' : 'Added'} ${kind} ${name}`, table: 'ap_recurring', recordUid: uid, before, after: { amount, freq: f.frequency, next: f.nextDate } });
  return getRecurring(uid);
}

// Make the invoices that are coming up. Safe to run any number of times, on any device.
export function runRecurring(user, today = dateStr()) {
  let made = 0;
  for (const r of listRecurring()) {
    let due = r.next_date;
    let guard = 0;
    while (due && addDays(due, -r.lead_days) <= today && (!r.end_date || due <= r.end_date) && guard++ < 60) {
      const invUid = `RI-${r.uid}-${due}`;
      if (!db().get('SELECT 1 AS x FROM ap_invoices WHERE uid = ?', [invUid])) {
        const sup = getSupplier(r.supplier_uid);
        if (!sup) break;
        const v = workOutVat({ total: r.amount, vatType: r.vat_type }, apRules().vatRate);
        const now = stamp();
        db().run(`INSERT INTO ap_invoices (uid, kind, supplier_uid, supplier_name, supplier_tin, invoice_no, invoice_date, received_date, shop_code, on_account, due_date, total, vat, zero_rated, vat_type,
          category, description, photo_urls, status, entered_by_uid, entered_by_name, entered_at, checked_by_name, checked_at, notes, updated_at, updated_device)
          VALUES (?, 'invoice', ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, '[]', 'approved', ?, ?, ?, 'Regular bill', ?, ?, ?, ?)`,
        [invUid, sup.uid, sup.name, sup.tin, `${r.kind === 'loan' ? (r.loan_no || 'LOAN') : 'BILL'}-${due.replace(/-/g, '')}`, due < today ? due : today, today, r.shop_code, due, r.amount, v.vat, v.zeroRated, r.vat_type,
          r.category, r.name, user ? user.uid : null, user ? user.name : 'Regular bills', now, now, r.kind === 'loan' ? 'Loan repayment' : 'Regular bill – check the real bill amount', now, deviceId()]);
        made += 1;
      }
      due = nextDate(due, r.frequency, r.anchor_day);
    }
    if (due !== r.next_date) db().run(`UPDATE ap_recurring SET next_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [due, stamp(), deviceId(), r.uid]);
  }
  return made;
}

// ---------------------------------------------------------------- loans
export function addLoanEntry(user, { recurringUid, type, amount, date, note }) {
  const r = getRecurring(recurringUid);
  need(r && r.kind === 'loan', 'Loan not found.');
  need(['interest', 'fee', 'adjust_up', 'adjust_down'].includes(type), 'Choose the type.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(DATE.test(txt(date)), 'Enter the date as YYYY-MM-DD.');
  if (type.startsWith('adjust')) need(txt(note), 'A correction needs a reason.');
  const uid = uuid('LE');
  db().run(`INSERT INTO loan_entries (uid, recurring_uid, entry_date, type, amount, note, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)`,
    [uid, recurringUid, date, type, a, txt(note) || null, user.name, stamp(), deviceId()]);
  audit({ user, action: `Loan ${r.name}: ${type} ${$(a)}`, table: 'loan_entries', recordUid: uid, reason: note });
}

// Loan statement: opening balance + interest/fees − repayments paid = balance left, line by line.
export function loanStatement(uid) {
  const r = getRecurring(uid);
  if (!r || r.kind !== 'loan') return null;
  const lines = [];
  db().all(`SELECT * FROM loan_entries WHERE recurring_uid = ? AND status = 'active' AND entry_date >= ?`, [uid, r.opening_date]).forEach((e) => lines.push({
    date: e.entry_date, what: { interest: 'Interest', fee: 'Fee', adjust_up: 'Correction (+)', adjust_down: 'Correction (−)' }[e.type] + (e.note ? ` – ${e.note}` : ''),
    change: ['interest', 'fee', 'adjust_up'].includes(e.type) ? e.amount : -e.amount, ref: '' }));
  db().all(`SELECT p.pay_date, p.method, p.cheque_no, p.reference, a.amount, i.invoice_no FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active'
    JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE i.uid LIKE ? AND p.pay_date >= ?`, [`RI-${uid}-%`, r.opening_date]).forEach((p) => lines.push({
    date: p.pay_date, what: `Repayment (${p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}${p.reference ? ` ${p.reference}` : ''})`, change: -p.amount, ref: p.invoice_no }));
  lines.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  let bal = r2(r.opening_balance);
  const rows = [{ date: r.opening_date, what: 'Balance at start', change: null, balance: bal, ref: '' }];
  for (const l of lines) { bal = r2(bal + l.change); rows.push({ ...l, balance: bal }); }
  const paid = r2(lines.filter((l) => l.what.startsWith('Repayment')).reduce((s, l) => s - l.change, 0));
  const owingNow = db().all(`SELECT uid FROM ap_invoices WHERE uid LIKE ? AND status <> 'void'`, [`RI-${uid}-%`]).map((x) => getInvoice(x.uid)).filter((i) => i.owing > 0);
  return { loan: r, rows, balance: bal, paid, overdue: owingNow.filter((i) => i.due === 'overdue') };
}
