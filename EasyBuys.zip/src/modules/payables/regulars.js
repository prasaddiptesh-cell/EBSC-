// Release 03 (owner, 12 Nov): "some suppliers are supplying things every week. The app should flag and ask that a
// particular supplier invoice and its records are not there, and needs to confirm if buying was done via that supplier."
// Learnt from the invoices themselves: a supplier (per shop) with an invoice in at least 3 of the last 4 weeks is a
// regular. This week, once their usual day has passed with no invoice, they are asked about: "Bought – add the
// invoice" or "No buying from them this week" (a reason from staff; the owner and admins need none). The answer is
// kept for that week (shared, so every device knows) and the question goes away.
import { db } from '../../db/connection.js';
import { getShared, setShared, audit, AppError, clock, dateStr } from '../../services/core.js';
import { requireLogin, asService } from '../../services/guard.js';
import { needReason, can } from '../../services/access.js';

const DAY = 86400000;
const iso = (d) => dateStr(d);
const parse = (s) => { const [y, m, dd] = String(s).slice(0, 10).split('-').map(Number); return new Date(y, m - 1, dd); };
// Weeks run Monday to Sunday.
export function weekStart(d) { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const wd = (x.getDay() + 6) % 7; return new Date(x.getTime() - wd * DAY); }
const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const key = (sup, shop, wk) => `${sup}|${shop || ''}|${wk}`;
const answers = () => getShared('regular_supplier_answers', {}) || {};
const supKey = (r) => r.supplier_uid || `name:${String(r.supplier_name || '').trim().toLowerCase()}`;

// Release 38 (owner, 14 Nov): a supplier can be marked as weekly by hand, with their usual day – asked about from the
// first week, without waiting for 3 weeks of invoices. { 'supplierKey|shop': { supplierKey, supplier, shop, day, by, at } }
const manual = () => getShared('regular_suppliers_manual', {}) || {};
export function weeklySuppliers() { return Object.values(manual()); }
export function markWeekly(user, { supplierUid, supplier, shop, day }) {
  requireLogin(user);
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can mark a weekly supplier.');
  const name = String(supplier || '').trim();
  if (!supplierUid && !name) throw new AppError('Which supplier?');
  if (!shop) throw new AppError('Which shop do they deliver to?');
  const d = Number(day);
  if (!(d >= 0 && d <= 6)) throw new AppError('Choose their usual day.');
  const sk = supplierUid || `name:${name.toLowerCase()}`;
  const all = manual();
  all[`${sk}|${shop}`] = { supplierKey: sk, supplier: name || sk, shop, day: d, by: user.name, at: new Date().toISOString() };
  setShared('regular_suppliers_manual', all);
  audit({ user, action: `${name || sk} marked as a weekly supplier for ${shop} (usually ${WEEKDAYS[d]})`, table: 'shared_settings', recordUid: `regular_suppliers_manual.${sk}|${shop}` });
  return all[`${sk}|${shop}`];
}
export function unmarkWeekly(user, { supplierKey, shop }) {
  requireLogin(user);
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or admin can change weekly suppliers.');
  const all = manual();
  const k = `${supplierKey}|${shop}`;
  if (!all[k]) return false;
  const was = all[k];
  delete all[k];
  setShared('regular_suppliers_manual', all);
  audit({ user, action: `${was.supplier} is no longer marked as a weekly supplier for ${shop}`, table: 'shared_settings', recordUid: `regular_suppliers_manual.${k}` });
  return true;
}

// → [{ supplierKey, supplier, shop, usualDay, weeksSeen, lastDate, lastTotal, week, expected, manual }]
// This week (today): asked once their usual day has passed (plus a day's grace for the invoice to be entered).
// Release 38 – a closed-week check: { from, to } (a week of the weekly close, Monday–Sunday or split at a month end):
// every regular whose usual day falls in from..to and who has no invoice that week and no answer.
export function missingRegulars({ today = clock.now(), shop, from: wFrom, to: wTo } = {}) {
  const forWeek = !!(wFrom && wTo);
  const wk0 = forWeek ? weekStart(parse(wFrom)) : weekStart(today);
  const from = iso(new Date(wk0.getTime() - 4 * 7 * DAY));
  const wkEnd = iso(new Date(wk0.getTime() + 6 * DAY));
  let rows = [];
  try {
    rows = db().all(`SELECT supplier_uid, supplier_name, shop_code, invoice_date, total FROM ap_invoices
      WHERE status <> 'void' AND kind = 'invoice' AND invoice_date >= ? AND invoice_date <= ? ${shop ? 'AND shop_code = ?' : ''} ORDER BY invoice_date`, shop ? [from, wkEnd, shop] : [from, wkEnd]);
  } catch (e) { return []; }
  const groups = new Map();
  const groupOf = (sk, name, sh) => {
    const k = `${sk}|${sh || ''}`;
    if (!groups.has(k)) groups.set(k, { supplierKey: sk, supplier: name, shop: sh || '', list: [] });
    return groups.get(k);
  };
  for (const r of rows) groupOf(supKey(r), r.supplier_name, r.shop_code).list.push(r);
  const marked = manual();
  for (const m of Object.values(marked)) { if (!shop || m.shop === shop) groupOf(m.supplierKey, m.supplier, m.shop).marked = m; }
  // an invoice entered under the supplier's name (no supplier record) still counts for a supplier marked by record
  const done = answers();
  const out = [];
  const wkIso = iso(wk0);
  for (const g of groups.values()) {
    const weeks = new Set();
    const days = {};
    let thisWeek = false;
    for (const r of g.list) {
      const d = parse(r.invoice_date);
      const ws = iso(weekStart(d));
      if (ws === wkIso) { thisWeek = true; continue; }
      weeks.add(ws);
      days[d.getDay()] = (days[d.getDay()] || 0) + 1;
    }
    if (!thisWeek && g.marked) {
      const nm = String(g.marked.supplier || '').trim().toLowerCase();
      thisWeek = rows.some((r) => (r.shop_code || '') === g.shop && iso(weekStart(parse(r.invoice_date))) === wkIso && String(r.supplier_name || '').trim().toLowerCase() === nm);
    }
    if (thisWeek || (!g.marked && weeks.size < 3)) continue;
    if (done[key(g.supplierKey, g.shop, wkIso)]) continue;
    const usual = g.marked ? Number(g.marked.day) : Number(Object.entries(days).sort((a, b) => b[1] - a[1])[0][0]);
    const usualDate = new Date(wk0.getTime() + ((usual + 6) % 7) * DAY);
    if (forWeek) {
      const u = iso(usualDate);
      if (u < wFrom || u > wTo) continue;
    } else if (today.getTime() < usualDate.getTime() + 2 * DAY - 1) continue;
    const last = g.list[g.list.length - 1];
    out.push({ supplierKey: g.supplierKey, supplier: g.supplier, shop: g.shop, usualDay: WEEKDAYS[usual], weeksSeen: weeks.size, lastDate: last ? last.invoice_date : null, lastTotal: last ? Number(last.total) || 0 : 0, week: wkIso, expected: iso(usualDate), manual: !!g.marked });
  }
  return out.sort((a, b) => a.expected.localeCompare(b.expected) || String(a.supplier).localeCompare(String(b.supplier)));
}

// answer: 'none' (no buying from them this week) or 'bought' (the invoice is coming – keeps asking until it is entered)
export function answerRegular(user, { supplierKey, shop, week, answer, reason }) {
  requireLogin(user);
  return asService(() => {
    if (!['invoices_enter', 'invoices_check', 'payments_make'].some((p) => can(user, p))) throw new AppError('Only someone who enters or checks invoices can answer this.');
    if (!supplierKey || !week) throw new AppError('Which supplier and week?');
    if (answer !== 'none') throw new AppError('Add the invoice instead: the question goes away once it is entered.');
    needReason(user, reason, 'Write why nothing was bought from them this week (e.g. still had stock).');
    const all = answers();
    const k = key(supplierKey, shop, week);
    all[k] = { answer, reason: String(reason || '').trim().slice(0, 200), by: user.name, at: new Date().toISOString() };
    setShared('regular_supplier_answers', all);
    audit({ user, action: `No buying this week from a regular supplier (${supplierKey}, ${shop || 'all shops'}, week of ${week})${reason ? `: ${reason}` : ''}`, table: 'shared_settings', recordUid: `regular_supplier_answers.${k}` });
    return all[k];
  });
}
export function regularAnswers() { return answers(); }
