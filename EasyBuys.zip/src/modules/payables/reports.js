// Invoices & cheques reports (PDF / Excel / CSV / print / email through the shared report screen).
import { db } from '../../db/connection.js';
import { stamp } from '../../services/core.js';
import * as AP from './service.js';
import { listRecurring, loanStatement } from './recurring.js';

const { $, r2 } = AP;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});
const daysBetween = (a, b) => Math.round((new Date(`${b}T00:00:00`) - new Date(`${a}T00:00:00`)) / 86400000);
const METHOD = { cheque: 'Cheque', cash: 'Cash', transfer: 'Transfer', credit: 'Credit note' };

export const REPORTS = [
  { id: 'ap_aged', group: 'Invoices & cheques', icon: '⏳', title: 'Unpaid invoices by age', desc: 'What is owed to each supplier, by how late it is', perm: 'payments_make',
    build(from, to) {
      const rows = [];
      const per = {};
      AP.listInvoices({ filter: 'unpaid' }).filter((i) => i.total > 0).forEach((i) => {
        const late = Math.max(0, daysBetween(i.due_date, to));
        const band = i.due_date > to ? 'notdue' : late <= 7 ? 'd7' : late <= 30 ? 'd30' : late <= 60 ? 'd60' : 'd60p';
        rows.push({ supplier: i.supplier_name, no: i.invoice_no || '', date: i.invoice_date, due: i.due_date, late: i.due_date > to ? '' : late, total: $(i.total), owing: $(i.owing), _tone: band === 'notdue' ? null : band === 'd7' ? 'warn' : 'bad' });
        const p = (per[i.supplier_name] = per[i.supplier_name] || { supplier: i.supplier_name, notdue: 0, d7: 0, d30: 0, d60: 0, d60p: 0, total: 0 });
        p[band] += i.owing; p.total += i.owing;
      });
      const sum = Object.values(per).sort((a, b) => b.total - a.total).map((p) => ({ supplier: p.supplier, notdue: $(p.notdue), d7: $(p.d7), d30: $(p.d30), d60: $(p.d60), d60p: $(p.d60p), total: $(p.total), _tone: p.d30 + p.d60 + p.d60p ? 'bad' : null }));
      const total = Object.values(per).reduce((s, p) => s + p.total, 0);
      return base('ap_aged', 'Unpaid Invoices by Age', to, to, {
        summary: [{ label: 'Owing', value: $(total) }, { label: 'Suppliers', value: String(sum.length) }, { label: 'Invoices', value: String(rows.length) }],
        sections: [{ title: 'By supplier', columns: [col('supplier', 'Supplier'), col('notdue', 'Not due', R), col('d7', '1–7 days late', R), col('d30', '8–30', R), col('d60', '31–60', R), col('d60p', 'Over 60', R), col('total', 'Total', R)], rows: sum },
          { title: 'Invoices', columns: [col('supplier', 'Supplier'), col('no', 'Invoice'), col('date', 'Date'), col('due', 'Due'), col('late', 'Days late', R), col('total', 'Total', R), col('owing', 'Owing', R)], rows }],
      });
    } },
  { id: 'ap_due', group: 'Invoices & cheques', icon: '📅', title: 'To pay this week', desc: 'Overdue plus everything due in the period', perm: 'payments_make',
    build(from, to) {
      const list = AP.listInvoices({ filter: 'unpaid' }).filter((i) => i.total > 0 && i.due_date <= to);
      const rows = list.map((i) => ({ due: i.due_date, supplier: i.supplier_name, no: i.invoice_no || '', how: (AP.getSupplier(i.supplier_uid) || {}).pay_method || '', owing: $(i.owing), state: AP.DUE_LABEL[i.due], _tone: i.due === 'overdue' ? 'bad' : 'warn' }));
      return base('ap_due', 'Invoices To Pay', from, to, {
        summary: [{ label: 'To pay', value: $(list.reduce((s, i) => s + i.owing, 0)) }, { label: 'Overdue', value: $(list.filter((i) => i.due === 'overdue').reduce((s, i) => s + i.owing, 0)), tone: 'bad' }],
        sections: [{ title: 'Invoices', columns: [col('due', 'Due'), col('supplier', 'Supplier'), col('no', 'Invoice'), col('how', 'Usually paid by'), col('owing', 'Owing', R), col('state', 'State')], rows }],
      });
    } },
  { id: 'ap_payments', group: 'Invoices & cheques', icon: '💸', title: 'Payments made', desc: 'Every payment with what it paid (pay trail)', perm: 'payments_make',
    build(from, to) {
      const pays = AP.listPayments({ from, to, includeVoid: true, limit: 5000 });
      const rows = pays.map((p) => {
        const inv = db().all('SELECT i.invoice_no, a.amount FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = ?', [p.uid]);
        return { date: p.pay_date, supplier: p.supplier_name, how: METHOD[p.method], no: p.cheque_no || p.reference || '', from: p.account_name || (p.shop_code ? `Cash ${p.shop_code}` : ''),
          invoices: inv.map((x) => `${x.invoice_no || '?'} ${$(x.amount)}`).join(', '), amount: $(p.amount), by: p.paid_by_name || '', state: p.status === 'void' ? `VOID: ${p.void_reason}` : p.cheque_status === 'written' ? 'not cleared' : '', _tone: p.status === 'void' ? 'warn' : null };
      });
      const live = pays.filter((p) => p.status === 'active' && p.method !== 'credit');
      const by = (m) => $(live.filter((p) => p.method === m).reduce((s, p) => s + p.amount, 0));
      return base('ap_payments', 'Supplier Payments', from, to, {
        summary: [{ label: 'Paid', value: $(live.reduce((s, p) => s + p.amount, 0)) }, { label: 'Cheques', value: by('cheque') }, { label: 'Cash', value: by('cash') }, { label: 'Transfers', value: by('transfer') }],
        sections: [{ title: 'Payments', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('how', 'How'), col('no', 'Cheque / ref'), col('from', 'From'), col('invoices', 'Invoices paid'), col('amount', 'Amount', R), col('by', 'Paid by'), col('state', 'Note')], rows }],
      });
    } },
  { id: 'ap_cheques', group: 'Invoices & cheques', icon: '🏦', title: 'Cheque register', desc: 'Every cheque leaf used, with status', perm: 'cheques_manage',
    build(from, to) {
      const list = AP.listCheques({ from, to, limit: 5000 }).sort((a, b) => (a.account_name + String(a.cheque_no).padStart(12, '0') < b.account_name + String(b.cheque_no).padStart(12, '0') ? -1 : 1));
      const rows = list.map((c) => ({ acct: c.account_name, no: c.cheque_no, date: c.cheque_date, payee: c.payee || '', amount: $(c.amount), status: c.status === 'presented' ? `cleared ${c.presented_date}` : c.status === 'written' ? 'not cleared' : c.status, note: c.void_reason || c.memo || '', _tone: c.status === 'written' ? 'warn' : ['void', 'spoiled'].includes(c.status) ? null : 'good' }));
      return base('ap_cheques', 'Cheque Register', from, to, {
        summary: [{ label: 'Cheques', value: String(list.filter((c) => ['written', 'presented'].includes(c.status)).length) }, { label: 'Amount', value: $(list.filter((c) => ['written', 'presented'].includes(c.status)).reduce((s, c) => s + c.amount, 0)) },
          { label: 'Not cleared', value: $(list.filter((c) => c.status === 'written').reduce((s, c) => s + c.amount, 0)), tone: 'warn' }],
        sections: [{ title: 'Cheques', columns: [col('acct', 'Account'), col('no', 'Number'), col('date', 'Date'), col('payee', 'Payee'), col('amount', 'Amount', R), col('status', 'Status'), col('note', 'Note')], rows }],
      });
    } },
  { id: 'ap_unpresented', group: 'Invoices & cheques', icon: '🕒', title: 'Cheques not cleared', desc: 'Written but not yet through the bank, oldest first', perm: 'cheques_manage',
    build(from, to) {
      const list = AP.listCheques({ status: 'written', to }).sort((a, b) => (a.cheque_date < b.cheque_date ? -1 : 1));
      const stale = AP.staleCheques(to).map((c) => c.uid);
      return base('ap_unpresented', 'Cheques Not Cleared', to, to, {
        summary: [{ label: 'Cheques', value: String(list.length) }, { label: 'Amount', value: $(list.reduce((s, c) => s + c.amount, 0)) }, { label: 'Stale', value: String(stale.length), tone: stale.length ? 'bad' : 'good' }],
        sections: [{ title: 'Not cleared', columns: [col('acct', 'Account'), col('no', 'Cheque'), col('date', 'Date'), col('days', 'Days', R), col('payee', 'Payee'), col('amount', 'Amount', R)],
          rows: list.map((c) => ({ acct: c.account_name, no: c.cheque_no, date: c.cheque_date, days: daysBetween(c.cheque_date, to), payee: c.payee, amount: $(c.amount), _tone: stale.includes(c.uid) ? 'bad' : null })) }],
      });
    } },
  { id: 'ap_vat', group: 'Invoices & cheques', icon: '🧮', title: 'VAT on purchases', desc: 'Input VAT for the FRCS return (invoice date basis)', perm: 'invoices_check',
    build(from, to) {
      const list = AP.listInvoices({ filter: 'all', from, to, limit: 20000 }).filter((i) => i.status !== 'void' && i.total > 0);
      const sign = (i) => (i.kind === 'credit' ? -1 : 1);
      const rows = list.map((i) => ({ date: i.invoice_date, supplier: i.supplier_name, tin: i.supplier_tin || '', no: i.invoice_no || '', kind: i.kind === 'credit' ? 'Credit' : 'Invoice',
        total: $(sign(i) * i.total), excl: $(sign(i) * (i.total - i.vat)), vat: $(sign(i) * i.vat), zero: $(sign(i) * i.zero_rated), checked: i.status === 'approved' ? '✓' : 'to check', _tone: i.status === 'to_check' ? 'warn' : null }));
      const t = (k) => r2(list.reduce((s, i) => s + sign(i) * i[k], 0));
      const months = {};
      list.forEach((i) => { const m = i.invoice_date.slice(0, 7); const x = (months[m] = months[m] || { month: m, total: 0, vat: 0, zero: 0 }); x.total += sign(i) * i.total; x.vat += sign(i) * i.vat; x.zero += sign(i) * i.zero_rated; });
      return base('ap_vat', 'VAT On Purchases', from, to, {
        summary: [{ label: 'Purchases incl. VAT', value: $(t('total')) }, { label: 'Input VAT', value: $(t('vat')) }, { label: 'Zero-rated', value: $(t('zero_rated')) }, { label: 'Not checked yet', value: String(list.filter((i) => i.status === 'to_check').length), tone: list.some((i) => i.status === 'to_check') ? 'warn' : 'good' }],
        sections: [{ title: 'By month', columns: [col('month', 'Month'), col('total', 'Incl. VAT', R), col('vat', 'VAT', R), col('zero', 'Zero-rated', R)], rows: Object.values(months).map((m) => ({ month: m.month, total: $(m.total), vat: $(m.vat), zero: $(m.zero) })) },
          { title: 'Invoices', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('tin', 'TIN'), col('no', 'Number'), col('kind', 'Type'), col('total', 'Incl. VAT', R), col('excl', 'Excl. VAT', R), col('vat', 'VAT', R), col('zero', 'Zero-rated', R), col('checked', 'Checked')], rows,
            note: 'Invoice basis: by invoice date. Credit notes are taken off. Check any "to check" invoices before filing.' }],
      });
    } },
  { id: 'ap_suppliers', group: 'Invoices & cheques', icon: '🏷️', title: 'Supplier summary', desc: 'Bought, paid and owing for every supplier', perm: 'payments_make',
    build(from, to) {
      const rows = AP.listSuppliers({ includeInactive: true }).map((s) => {
        const bought = db().get(`SELECT IFNULL(SUM(CASE WHEN kind='credit' THEN -total ELSE total END),0) AS t FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND invoice_date BETWEEN ? AND ?`, [s.uid, from, to]).t;
        const paid = db().get(`SELECT IFNULL(SUM(amount),0) AS t FROM ap_payments WHERE supplier_uid = ? AND status = 'active' AND method <> 'credit' AND pay_date BETWEEN ? AND ?`, [s.uid, from, to]).t;
        const owing = AP.listInvoices({ filter: 'unpaid', supplierUid: s.uid }).reduce((a, i) => a + i.owing, 0);
        return { name: s.name, tin: s.tin || '', terms: s.on_account ? `${s.terms_days} days` : 'on delivery', bought: $(bought), paid: $(paid), owing: $(owing), _b: bought, _o: owing };
      }).filter((r) => r._b || r._o);
      return base('ap_suppliers', 'Supplier Summary', from, to, {
        summary: [{ label: 'Bought', value: $(rows.reduce((s, r) => s + r._b, 0)) }, { label: 'Owing now', value: $(rows.reduce((s, r) => s + r._o, 0)) }],
        sections: [{ title: 'Suppliers', columns: [col('name', 'Supplier'), col('tin', 'TIN'), col('terms', 'Terms'), col('bought', 'Bought', R), col('paid', 'Paid', R), col('owing', 'Owing now', R)], rows }],
      });
    } },
  { id: 'ap_loans', group: 'Invoices & cheques', icon: '🏦', title: 'Loans', desc: 'Repayments made and balances left', perm: 'payments_make',
    build(from, to) {
      const loans = listRecurring({ kind: 'loan', includeInactive: true }).map((l) => loanStatement(l.uid));
      const rows = loans.map((s) => ({ name: s.loan.name, lender: s.loan.supplier_name, no: s.loan.loan_no || '', repay: `${$(s.loan.amount)} ${s.loan.frequency}`, paid: $(s.paid), balance: $(s.balance), overdue: s.overdue.length || '', _tone: s.overdue.length ? 'bad' : null }));
      const detail = [];
      loans.forEach((s) => s.rows.filter((x) => x.date >= from && x.date <= to).forEach((x) => detail.push({ loan: s.loan.name, date: x.date, what: x.what, ref: x.ref || '', change: x.change == null ? '' : $(x.change), balance: $(x.balance) })));
      return base('ap_loans', 'Loans', from, to, {
        summary: [{ label: 'Loans', value: String(loans.length) }, { label: 'Total owing', value: $(loans.reduce((s, l) => s + l.balance, 0)) }],
        sections: [{ title: 'Loans', columns: [col('name', 'Loan'), col('lender', 'Lender'), col('no', 'Number'), col('repay', 'Repayment'), col('paid', 'Repaid since start', R), col('balance', 'Balance left', R), col('overdue', 'Overdue', R)], rows },
          { title: 'Statement lines in the period', columns: [col('loan', 'Loan'), col('date', 'Date'), col('what', 'What'), col('ref', 'Invoice no'), col('change', 'Change', R), col('balance', 'Balance', R)], rows: detail }],
      });
    } },
];
