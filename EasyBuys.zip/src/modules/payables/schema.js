// Invoices & Payments tables. Added on top of the existing database (nothing is ever dropped).
// Money is kept in dollars rounded to cents. Nothing is deleted: wrong entries are voided with a reason.
export const PAYABLES_SQL = `
CREATE TABLE IF NOT EXISTS ap_suppliers (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tin TEXT,
  vat_registered INTEGER NOT NULL DEFAULT 1,
  on_account INTEGER NOT NULL DEFAULT 0,
  terms_days INTEGER NOT NULL DEFAULT 7,
  pay_method TEXT NOT NULL DEFAULT 'cheque',
  contact TEXT, phone TEXT, email TEXT,
  bank_name TEXT, bank_account TEXT,
  category TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Supplier invoices and credit notes.
CREATE TABLE IF NOT EXISTS ap_invoices (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'invoice' CHECK (kind IN ('invoice','credit')),
  supplier_uid TEXT,
  supplier_name TEXT NOT NULL,
  supplier_tin TEXT,
  invoice_no TEXT,
  invoice_date TEXT NOT NULL,
  received_date TEXT,
  shop_code TEXT,
  on_account INTEGER NOT NULL DEFAULT 0,
  due_date TEXT NOT NULL,
  total REAL NOT NULL,
  vat REAL NOT NULL DEFAULT 0,
  zero_rated REAL NOT NULL DEFAULT 0,
  vat_type TEXT NOT NULL DEFAULT 'standard',
  category TEXT,
  description TEXT,
  photo_urls TEXT,
  ocr_status TEXT,
  ocr_notes TEXT,
  status TEXT NOT NULL DEFAULT 'to_check' CHECK (status IN ('to_check','approved','void')),
  entered_by_uid TEXT, entered_by_name TEXT, entered_at TEXT,
  checked_by_uid TEXT, checked_by_name TEXT, checked_at TEXT,
  void_reason TEXT, voided_by_name TEXT, voided_at TEXT,
  notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_api_supplier ON ap_invoices(supplier_uid, invoice_date);
CREATE INDEX IF NOT EXISTS idx_api_due ON ap_invoices(due_date);

-- A payment: one cheque, one cash hand-over, one bank transfer, or a supplier credit applied.
CREATE TABLE IF NOT EXISTS ap_payments (
  uid TEXT PRIMARY KEY,
  supplier_uid TEXT,
  supplier_name TEXT NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('cheque','cash','transfer','credit')),
  pay_date TEXT NOT NULL,
  amount REAL NOT NULL,
  account_uid TEXT,
  cheque_uid TEXT,
  cheque_no TEXT,
  reference TEXT,
  credit_uid TEXT,
  shop_code TEXT,
  received_by TEXT,
  photo_urls TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  paid_by_uid TEXT, paid_by_name TEXT, created_at TEXT,
  void_reason TEXT, voided_by_name TEXT, voided_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_app_supplier ON ap_payments(supplier_uid, pay_date);

-- Which invoices a payment covers (the pay trail).
CREATE TABLE IF NOT EXISTS ap_allocations (
  uid TEXT PRIMARY KEY,
  payment_uid TEXT NOT NULL,
  invoice_uid TEXT NOT NULL,
  amount REAL NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_apa_invoice ON ap_allocations(invoice_uid);
CREATE INDEX IF NOT EXISTS idx_apa_payment ON ap_allocations(payment_uid);

CREATE TABLE IF NOT EXISTS bank_accounts (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  bank TEXT NOT NULL DEFAULT 'BSP',
  account_no TEXT,
  opening_balance REAL NOT NULL DEFAULT 0,
  opening_date TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS cheque_books (
  uid TEXT PRIMARY KEY,
  account_uid TEXT NOT NULL,
  first_no INTEGER NOT NULL,
  last_no INTEGER NOT NULL,
  received_date TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Every cheque leaf that has been used: written to a supplier, or spoiled / cancelled.
CREATE TABLE IF NOT EXISTS cheques (
  uid TEXT PRIMARY KEY,
  account_uid TEXT NOT NULL,
  book_uid TEXT,
  cheque_no INTEGER NOT NULL,
  cheque_date TEXT NOT NULL,
  payee TEXT,
  amount REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('written','presented','void','spoiled')),
  payment_uid TEXT,
  presented_date TEXT,
  memo TEXT,
  void_reason TEXT,
  written_by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_chq_acct ON cheques(account_uid, cheque_no);

-- Money into or out of a bank account that is not a cheque: deposits, transfers, bank fees, corrections.
-- (The Bank & Deposits module adds more detail later; it writes here too.)
CREATE TABLE IF NOT EXISTS bank_entries (
  uid TEXT PRIMARY KEY,
  account_uid TEXT NOT NULL,
  entry_date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('deposit','transfer_out','fee','interest','adjust_in','adjust_out')),
  amount REAL NOT NULL,
  reference TEXT,
  payment_uid TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  cleared_date TEXT,
  by_name TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_be_acct ON bank_entries(account_uid, entry_date);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const PAYABLES_SYNC = {
  ap_suppliers: SYNC('uid', 'Invoices', ['uid', 'name', 'tin', 'vat_registered', 'on_account', 'terms_days', 'pay_method', 'contact', 'phone', 'email', 'bank_name', 'bank_account', 'category', 'notes', 'active',
    'budget_monthly', 'budget_weekly', 'lead_days', 'viber', 'order_days', 'withhold_pct', 'needs_setup']),
  ap_invoices: SYNC('uid', 'Invoices', ['uid', 'kind', 'supplier_uid', 'supplier_name', 'supplier_tin', 'invoice_no', 'invoice_date', 'received_date', 'shop_code', 'on_account', 'due_date',
    'total', 'vat', 'zero_rated', 'vat_type', 'category', 'description', 'photo_urls', 'ocr_status', 'ocr_notes', 'status', 'entered_by_uid', 'entered_by_name', 'entered_at',
    'checked_by_uid', 'checked_by_name', 'checked_at', 'void_reason', 'voided_by_name', 'voided_at', 'notes', 'po_uid']),
  ap_payments: SYNC('uid', 'Payments', ['uid', 'supplier_uid', 'supplier_name', 'method', 'pay_date', 'amount', 'account_uid', 'cheque_uid', 'cheque_no', 'reference', 'credit_uid', 'shop_code',
    'received_by', 'photo_urls', 'notes', 'status', 'paid_by_uid', 'paid_by_name', 'created_at', 'void_reason', 'voided_by_name', 'voided_at', 'withheld']),
  ap_allocations: SYNC('uid', 'Payments', ['uid', 'payment_uid', 'invoice_uid', 'amount']),
  bank_accounts: SYNC('uid', 'Cheques & bank', ['uid', 'name', 'bank', 'account_no', 'opening_balance', 'opening_date', 'active', 'sort']),
  cheque_books: SYNC('uid', 'Cheques & bank', ['uid', 'account_uid', 'first_no', 'last_no', 'received_date', 'notes', 'active', 'serial', 'holder', 'status']),
  cheques: SYNC('uid', 'Cheques & bank', ['uid', 'account_uid', 'book_uid', 'cheque_no', 'cheque_date', 'payee', 'amount', 'status', 'payment_uid', 'presented_date', 'memo', 'void_reason', 'written_by_name',
    'handed_date', 'handed_by_name', 'handed_to', 'photo_urls', 'stub_note']),
  bank_entries: SYNC('uid', 'Cheques & bank', ['uid', 'account_uid', 'entry_date', 'type', 'amount', 'reference', 'payment_uid', 'note', 'status', 'cleared_date', 'by_name', 'void_reason', 'gl_code', 'split']),
};

// Regular bills (rent, power, phone) and loan repayments. Each one makes its own invoice before it is due.
export const RECURRING_SQL = `
CREATE TABLE IF NOT EXISTS ap_recurring (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'bill' CHECK (kind IN ('bill','loan')),
  name TEXT NOT NULL,
  supplier_uid TEXT NOT NULL,
  amount REAL NOT NULL,
  vat_type TEXT NOT NULL DEFAULT 'standard',
  frequency TEXT NOT NULL CHECK (frequency IN ('weekly','fortnightly','monthly','quarterly','yearly')),
  next_date TEXT NOT NULL,
  end_date TEXT,
  lead_days INTEGER NOT NULL DEFAULT 7,
  shop_code TEXT,
  category TEXT,
  loan_no TEXT,
  security TEXT,
  opening_balance REAL,
  opening_date TEXT,
  interest_rate REAL,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  anchor_day INTEGER,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
-- Loan interest, fees and corrections from the lender's statement (repayments come from payments).
CREATE TABLE IF NOT EXISTS loan_entries (
  uid TEXT PRIMARY KEY,
  recurring_uid TEXT NOT NULL,
  entry_date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('interest','fee','adjust_up','adjust_down')),
  amount REAL NOT NULL,
  note TEXT,
  by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
PAYABLES_SYNC.ap_recurring = SYNC('uid', 'Invoices', ['uid', 'kind', 'name', 'supplier_uid', 'amount', 'vat_type', 'frequency', 'next_date', 'end_date', 'lead_days', 'shop_code', 'category', 'loan_no', 'security', 'opening_balance', 'opening_date', 'interest_rate', 'notes', 'active', 'anchor_day']);
PAYABLES_SYNC.loan_entries = SYNC('uid', 'Invoices', ['uid', 'recurring_uid', 'entry_date', 'type', 'amount', 'note', 'by_name', 'status']);
// v3.5 (bank): who marked a cheque cleared; bank lines tagged by shop.
PAYABLES_SYNC.cheques.cols.push('presented_by_name', 'shop_code');
PAYABLES_SYNC.bank_entries.cols.push('shop_code');
