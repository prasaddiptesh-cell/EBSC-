// Cheque books & stubs (v3.5): every book (serial, leaves, date received, who holds it, status), its leaves, and
// each leaf's stub record. Also the supplier statement screen.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, ListItem, Stats, Hint, Explain, ReasonField, PeriodPicker, usePeriod } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { dateStr } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import * as AP from '../service.js';
import * as CB from '../chequebooks.js';
import { supplierStatement } from '../statement.js';

const { $ } = AP;
const LEAF = { unused: ['#FFFFFF', C.border, 'unused'], written: [C.warnSoft, C.warn, 'not cleared'], presented: [C.successSoft, C.success, 'cleared'], void: ['#EEE', C.sub, 'void'],
  spoiled: ['#EEE', C.sub, 'spoiled'], skipped: [C.dangerSoft, C.danger, 'SKIPPED'], handed: [C.dangerSoft, C.danger, 'NOT RECORDED'] };
const STATUS_COLOR = { in_use: C.success, spare: C.info, finished: C.sub, cancelled: C.sub, lost: C.danger };
const d = (iso) => (iso ? fmtDate(iso) : '—');

export function ChequeBooksScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const accounts = AP.listAccounts();
  const [show, setShow] = useRemembered('show', 'current');
  const all = CB.listAllBooks();
  // Opens on the book in use (or the one asked for), so its leaves show straight away.
  const [open, setOpen] = useRemembered('open', () => params.bookUid || ((all.find((b) => b.status === 'in_use') || all[0] || {}).uid) || null);
  const [edit, setEdit] = useState(null);
  const books = all.filter((b) => show === 'all' || ['in_use', 'spare'].includes(b.status));
  const view = open ? AP.bookLeaves(open) : null;
  const ob = open ? all.find((b) => b.uid === open) : null;
  const manage = can('cheques_manage');
  const startEdit = (b) => setEdit(b ? { uid: b.uid, accountUid: b.account_uid, serial: b.serial || '', firstNo: String(b.first_no), lastNo: String(b.last_no), receivedDate: b.received_date || dateStr(), holder: b.holder || '', status: b.status, notes: b.notes || '', reason: '' }
    : { accountUid: accounts[0] ? accounts[0].uid : '', serial: '', firstNo: '', lastNo: '', receivedDate: dateStr(), holder: user.name, status: 'in_use', notes: '', reason: '' });
  const total = (k) => all.reduce((s, b) => s + (b[k] || 0), 0);
  return (
    <Screen title="Cheque books & stubs" subtitle={`${all.length} book(s)`}
      footer={<Btn testID="cb-report" title="Cheque book report" icon="📊" variant="info" size="md" onPress={() => nav.push('ReportView', { kind: 'ap_chequebooks', from: `${dateStr().slice(0, 7)}-01`, to: dateStr() })} />}>
      <Explain>Each cheque book from BSP is listed with its serial number, its leaves, when it came, who keeps it and whether it is in use. Tap a book to see every leaf; tap a leaf to open its stub: date, payee, amount, invoices paid, who wrote it, who it was handed to, a photo of the stub and when it cleared the bank.</Explain>
      {!accounts.length ? <Banner tone="warn" title="No bank account yet" message="Add the BSP account first (Invoices & cheques › Bank accounts)." /> : null}
      <Stats items={[{ label: 'Books in use', value: String(all.filter((b) => b.status === 'in_use').length) }, { label: 'Leaves unused', value: String(total('unused')) },
        { label: 'Skipped', value: String(total('skipped')), color: total('skipped') ? C.danger : undefined }, { label: 'Not recorded', value: String(total('handed')), color: total('handed') ? C.danger : undefined },
        { label: 'Stub photo missing', value: String(total('noStubPhoto')), color: total('noStubPhoto') ? C.warn : undefined }]} />
      <Choice value={show} onChange={setShow} testIDPrefix="cb-show" options={[{ value: 'current', label: 'In use & spare' }, { value: 'all', label: 'All books' }]} />
      {!books.length ? <Text style={{ fontSize: 16, color: C.sub }}>No cheque books here yet.</Text> : null}
      {books.map((b) => (
        <ListItem key={b.uid} testID={`cb-book-${b.first_no}`} onPress={() => setOpen(open === b.uid ? null : b.uid)}
          title={`${b.serial ? `Book ${b.serial} · ` : ''}${b.first_no}–${b.last_no}`}
          sub={`${b.account_name} · received ${d(b.received_date)}${b.holder ? ` · held by ${b.holder}` : ''} · ${b.written + b.presented} used, ${b.unused} unused${b.noStubPhoto ? ` · ${b.noStubPhoto} stub photo(s) missing` : ''}`}
          badge={b.skipped ? `${b.skipped} SKIPPED` : b.handed ? `${b.handed} NOT RECORDED` : b.statusLabel} badgeColor={b.skipped || b.handed ? C.danger : STATUS_COLOR[b.status]} />
      ))}
      {view && ob ? (
        <Card>
          <H>{`${ob.serial ? `Book ${ob.serial}: ` : ''}cheques ${ob.first_no}–${ob.last_no}`}</H>
          <Row label="Account" value={ob.account_name} />
          <Row label="Received from the bank" value={d(ob.received_date)} />
          <Row label="Held by" value={ob.holder || '—'} />
          <Row label="Status" value={ob.statusLabel} />
          {view.skipped ? <Banner tone="danger" title="Numbers skipped" message="These leaves are not recorded but later numbers are. Open each one: record it as spoiled, or record the payment it was used for." /> : null}
          {view.handed ? <Banner tone="danger" title="Handed over but not recorded" message="A cheque was photographed as handed over but no payment is recorded with that number. Record the payment." /> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
            {view.leaves.map((l) => {
              const [bg, border, word] = LEAF[l.status] || LEAF.unused;
              return (
                <Pressable key={l.no} testID={`cb-leaf-${l.no}`} onPress={() => nav.push('ChequeStub', { accountUid: ob.account_uid, chequeNo: l.no })}
                  style={{ width: 104, padding: 6, borderRadius: 10, borderWidth: 2, borderColor: border, backgroundColor: bg }}>
                  <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{l.no}{l.noStubPhoto ? ' 📷?' : ''}</Text>
                  <Text style={{ fontSize: 12, color: border === C.border ? C.sub : border, fontWeight: '700' }} numberOfLines={1}>{l.cheque && l.cheque.payee ? l.cheque.payee : l.snap && l.snap.party ? l.snap.party : word}</Text>
                  {l.cheque && l.cheque.amount ? <Text style={{ fontSize: 12, color: C.text }}>{$(l.cheque.amount)}</Text> : null}
                </Pressable>
              );
            })}
          </View>
          <Hint>Tap any leaf to open its stub. "📷?" = no photo of the stub yet.</Hint>
          {manage ? <Btn testID="cb-edit" title="Change this book" icon="✏️" variant="secondary" size="md" onPress={() => startEdit(ob)} /> : null}
        </Card>
      ) : null}
      {edit ? (
        <Card>
          <H>{edit.uid ? 'Change cheque book' : 'New cheque book'}</H>
          {accounts.length > 1 ? <Choice label="Bank account" value={edit.accountUid} onChange={(v) => setEdit({ ...edit, accountUid: v })} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
          <Field testID="cb-serial" label="Book serial number (printed on the cover)" value={edit.serial} onChangeText={(v) => setEdit({ ...edit, serial: v })} />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="cb-first" label="First cheque number" value={edit.firstNo} onChangeText={(v) => setEdit({ ...edit, firstNo: v })} keyboardType="number-pad" /></View>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="cb-last" label="Last cheque number" value={edit.lastNo} onChangeText={(v) => setEdit({ ...edit, lastNo: v })} keyboardType="number-pad" /></View>
          </View>
          <DateField testID="cb-received" farDays={false} label="Received from BSP" value={edit.receivedDate} onChange={(v) => setEdit({ ...edit, receivedDate: v })} />
          <Field testID="cb-holder" label="Who keeps it" value={edit.holder} onChangeText={(v) => setEdit({ ...edit, holder: v })} placeholder="e.g. Divnesh (office safe)" />
          <Choice label="Status" value={edit.status} onChange={(v) => setEdit({ ...edit, status: v })} testIDPrefix="cb-status" max={5} options={Object.entries(AP.BOOK_STATUS).map(([value, label]) => ({ value, label }))} />
          {['lost', 'cancelled'].includes(edit.status) && edit.uid ? <ReasonField testID="cb-reason" label="What happened" value={edit.reason} onChangeText={(v) => setEdit({ ...edit, reason: v })} /> : null}
          <Field label="Notes" value={edit.notes} onChangeText={(v) => setEdit({ ...edit, notes: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(null)} />
            <Btn testID="cb-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { const u = act(() => AP.saveBook(user, edit), 'Saved'); if (u) { setEdit(null); setOpen(u); } }} />
          </View>
        </Card>
      ) : manage && accounts.length ? <Btn testID="cb-add" title="Add a cheque book" icon="➕" variant="secondary" onPress={() => startEdit(null)} /> : null}
    </Screen>
  );
}

export function ChequeStubScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [, bump] = useState(0);
  const [photos, setPhotos] = useState([]);
  const stubP = usePaper('cheque', { stub: true }); // build 37: the stub read by the AI (number, date, payee, amount) and checked against the cheque recorded
  const [hand, setHand] = useState(null);
  const [spoil, setSpoil] = useState(null);
  const [clear, setClear] = useState(null);
  let s = null;
  let err = '';
  try { s = CB.getStub(params); } catch (e) { err = e.message; }
  if (!s) return <Screen title="Cheque stub"><Banner tone="warn" message={err || 'Cheque not found.'} /></Screen>;
  const c = s.cheque;
  const live = c && ['written', 'presented'].includes(c.status);
  const manage = can('cheques_manage');
  const refresh = () => bump((n) => n + 1);
  return (
    <Screen title={`Cheque ${s.no}`} subtitle={`${s.account.name}${s.book && s.book.serial ? ` · book ${s.book.serial}` : ''} · ${s.statusLabel}`}>
      {s.status === 'skipped' ? <Banner testID="stub-skipped" tone="danger" title="Skipped" message="This leaf is not recorded but later numbers are. Find it: record it as spoiled, or record the payment it was used for." /> : null}
      {s.status === 'handed' ? <Banner testID="stub-handed" tone="danger" title="Handed over – not recorded" message="It was photographed as handed over but there is no payment with this number. Record the payment." /> : null}
      {s.photoMissing ? <Banner testID="stub-photo-missing" tone="warn" title="No photo of the stub" message="Take a photo of the cheque stub (the part left in the book) and add it below." /> : null}
      <Card>
        <H>Stub</H>
        <Row label="Date" value={d(s.date)} />
        <Row label="Payee" value={s.payee || '—'} />
        <Row label="Amount" value={s.amount === null ? '—' : $(s.amount)} bold />
        <Row label="Invoices paid" value={s.invoices.length ? s.invoices.map((i) => `${i.invoice_no || '?'} (${$(i.amount)})`).join(', ') : '—'} />
        <Row label="Written by" value={s.writtenBy || '—'} />
        <Row label="Handed over" value={s.handedDate ? `${d(s.handedDate)}${s.handedTo ? ` to ${s.handedTo}` : ''}${s.handedBy ? ` (by ${s.handedBy})` : ''}` : 'Not yet'} />
        <Row label="Cleared the bank" value={s.cleared ? d(s.cleared) : c && c.status === 'written' ? 'Not yet' : '—'} />
        {c && c.void_reason ? <Row label="Why void / spoiled" value={c.void_reason} /> : null}
        {s.stubNote ? <Row label="Note" value={s.stubNote} /> : null}
      </Card>
      {s.payment ? <Btn title="Open the payment" variant="secondary" size="md" onPress={() => nav.push('ApPayment', { uid: s.payment.uid })} /> : null}
      {c ? (
        <Section title="Stub photo">
          <PhotoStrip testID="stub-photos" photos={photosFor(s.localPhotos, s.photos, `Cheque ${s.no} stub`)} />
          {manage ? (
            <>
              <PaperPhoto pr={stubP} testID="stub-photo" value={photos} onChange={setPhotos} label={s.hasPhoto ? 'Add another photo' : 'Photo of the stub'} form={{}} map={{}}>
                {stubP.read && stubP.read.fields.chequeNo && String(stubP.read.fields.chequeNo) !== String(Number(s.no)) ? <Banner testID="stub-nodiff" tone="warn" message={`The photo shows cheque ${stubP.read.fields.chequeNo}, this is cheque ${s.no}. Is it the right stub?`} /> : null}
                {stubP.read && stubP.read.fields.amount !== undefined && s.amount !== null && Math.abs(stubP.read.fields.amount - s.amount) > 0.004 ? <Banner testID="stub-amtdiff" tone="warn" message={`The stub shows $${stubP.read.fields.amount.toFixed(2)} but the cheque is recorded as $${Number(s.amount).toFixed(2)}.`} /> : null}
                {stubP.read && stubP.read.fields.amount !== undefined && s.amount !== null && Math.abs(stubP.read.fields.amount - s.amount) <= 0.004 ? <Banner testID="stub-ok" tone="success" message="The stub agrees with the cheque recorded." /> : null}
                {stubP.read ? require('../../../services/chequeRead.js').compareCheque({ payee: stubP.read.fields.payee, date: stubP.read.fields.date }, { supplierName: s.payee, chequeDate: s.date }).map((x) => <Banner key={x.key} testID={`stub-${x.key}`} tone="warn" message={x.text.replace('was typed', 'is recorded')} />) : null}
              </PaperPhoto>
              <Btn testID="stub-photo-save" title="Save the photo" icon="📷" variant="success" size="md" disabled={!photos.length} onPress={() => { if (act(() => CB.saveStub(user, c.uid, { photos }), 'Photo added')) { setPhotos([]); refresh(); } }} />
            </>
          ) : null}
        </Section>
      ) : null}
      {live && manage ? (
        hand ? (
          <Card>
            <H>Handed over</H>
            <DateField testID="stub-hand-date" label="Date" value={hand.date} onChange={(v) => setHand({ ...hand, date: v })} />
            <Field testID="stub-hand-to" label="Who took it" value={hand.to} onChangeText={(v) => setHand({ ...hand, to: v })} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
              <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setHand(null)} />
              <Btn testID="stub-hand-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => CB.markHandedOver(user, c.uid, hand), 'Saved')) { setHand(null); refresh(); } }} />
            </View>
          </Card>
        ) : <Btn testID="stub-hand" title={s.handedDate ? 'Change hand-over details' : 'Mark as handed over'} icon="🤝" variant="secondary" size="md" onPress={() => setHand({ date: s.handedDate || dateStr(), to: s.handedTo || '' })} />
      ) : null}
      {c && c.status === 'written' && manage ? (
        clear ? (
          <Card>
            <DateField testID="stub-clear-date" label="Date it cleared (from the bank statement)" value={clear} onChange={setClear} />
            <Btn testID="stub-clear-save" title="Mark as presented / cleared" variant="success" size="md" onPress={() => { if (act(() => AP.markPresented(user, c.uid, clear), 'Cleared')) { setClear(null); refresh(); } }} />
          </Card>
        ) : <Btn testID="stub-clear" title="Cleared the bank" icon="✅" variant="success" size="md" onPress={() => setClear(dateStr())} />
      ) : null}
      {c && c.status === 'presented' && manage ? <Btn title="Not cleared after all" variant="ghost" size="sm" onPress={() => { if (act(() => AP.markPresented(user, c.uid, null), 'Changed')) refresh(); }} /> : null}
      {!c && s.book && manage ? (
        <>
          {can('payments_make') ? <Btn testID="stub-pay" title="Record the payment with this cheque" icon="💸" variant="success" size="md"
            onPress={() => nav.push('ApPay', { chequeNo: s.no, accountUid: s.account.uid, supplierUid: s.handedSnap ? s.handedSnap.supplier_uid || undefined : undefined,
              invoiceUids: s.handedSnap ? (() => { try { return JSON.parse(s.handedSnap.invoice_uids || '[]'); } catch (e) { return []; } })() : undefined })} /> : null}
          {spoil !== null ? (
            <Card tone="warn">
              <ReasonField testID="stub-spoil-reason" label="What happened" value={spoil} onChangeText={setSpoil} placeholder="e.g. written wrongly, torn" />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 8 }}>
                <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setSpoil(null)} />
                <Btn testID="stub-spoil-save" title="Record as spoiled" variant="warn" style={{ flex: 1 }} onPress={() => { if (act(() => AP.spoilCheque(user, { accountUid: s.account.uid, chequeNo: s.no, reason: spoil }), 'Recorded')) { setSpoil(null); refresh(); } }} />
              </View>
            </Card>
          ) : s.status !== 'handed' ? <Btn testID="stub-spoil" title="Record as spoiled" icon="🗑️" variant="secondary" size="md" onPress={() => setSpoil('')} /> : null}
        </>
      ) : null}
      {s.snaps.length ? (
        <Section title="Photos taken when it was handed over">
          {s.snaps.map((x) => <ListItem key={x.uid} title={`${x.snap_date} · ${x.party || ''}`} sub={`by ${x.by_name}${x.collected_by ? ` · taken by ${x.collected_by}` : ''}`} right={x.amount === null ? '' : $(x.amount)} badge={String(x.status).toUpperCase()} />)}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- supplier statement
const BAND = { notDue: 'Not due', due: 'Due', overdue: 'Overdue', credits: 'Credit not used' };
export function SupplierStatementScreen({ params }) {
  const { nav } = useApp();
  const sups = AP.listSuppliers({ includeInactive: true });
  const [sup, setSup] = useRemembered('sup', params.supplierUid || '');
  const [from, to, setRange] = usePeriod('thismonth', 'stmt-period');
  let st = null;
  let err = '';
  if (sup) { try { st = supplierStatement(sup, from, to); } catch (e) { err = e.message; } }
  return (
    <Screen title="Supplier statement" subtitle={st ? st.supplier.name : 'Choose the supplier'}
      footer={sup ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="ss-export" title="PDF / Excel / share" icon="📄" variant="primary" size="md" style={{ flexGrow: 1 }} disabled={!st} onPress={() => nav.push('ReportView', { kind: 'ap_supplier_statement', from, to, supplierUid: sup })} />
          <Btn testID="ss-check" title="Check their statement" icon="🔍" variant="info" size="md" style={{ flexGrow: 1 }} onPress={() => nav.push('ApStatement', { supplierUid: sup, date: to })} />
        </View>
      ) : null}>
      <Select testID="ss-sup" label="Supplier" value={sup} onChange={setSup} options={sups.map((x) => ({ value: x.uid, label: x.name, hint: x.needs_setup ? 'to add properly' : undefined }))} />
      <PeriodPicker testID="ss-period" from={from} to={to} onChange={setRange} />
      {err ? <Banner tone="danger" message={err} /> : null}
      {st ? (
        <>
          <Stats items={[{ label: 'Opening', value: $(st.opening) }, { label: 'Invoices', value: $(st.invoicesTotal) }, { label: 'Paid & credits', value: $(st.paymentsTotal + st.creditsTotal) }, { label: 'Closing', value: $(st.closing), color: C.text }]} />
          <Section title="Statement">
            <ListItem title="Opening balance" sub={d(from)} right={$(st.opening)} />
            {st.lines.map((l) => (
              <ListItem key={`${l.kind}-${l.uid}`} testID={`ss-line-${l.ref || l.uid}`} title={`${l.what}${l.ref ? ` · ${l.ref}` : ''}`}
                sub={l.kind === 'payment'
                  ? [d(l.date), l.invoices && l.invoices.length ? `for ${l.invoices.join(', ')}` : '', l.method === 'cheque' ? `written ${l.written || '—'} · handed over ${l.handed ? `${l.handed}${l.handedTo ? ` (${l.handedTo})` : ''}` : 'not yet'} · presented ${l.presented || 'not yet'}` : ''].filter(Boolean).join(' · ')
                  : `${d(l.date)}${l.due ? ` · due ${l.due}` : ''}`}
                right={`${l.charge ? '+' : '−'}${$(l.charge || l.credit)}`} rightSub={`bal. ${$(l.balance)}`} badge={l.notCleared ? 'NOT PRESENTED' : undefined} badgeColor={l.notCleared ? C.warn : undefined}
                onPress={() => (l.kind === 'payment' ? nav.push('ApPayment', { uid: l.uid }) : nav.push('ApInvoice', { uid: l.uid }))} />
            ))}
            {!st.lines.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing in this period.</Text> : null}
            <ListItem title="Closing balance" sub={d(to)} right={$(st.closing)} />
          </Section>
          <Card>
            <H>Closing balance by due date</H>
            <Row label="Not due yet" value={$(st.split.notDue)} />
            <Row label="Due now / soon" value={$(st.split.due)} color={st.split.due ? C.warn : undefined} />
            <Row label="Overdue" value={$(st.split.overdue)} color={st.split.overdue ? C.danger : undefined} />
            {st.split.credits ? <Row label="Credit notes not used yet" value={$(st.split.credits)} color={C.success} /> : null}
            <Row label="We owe" value={$(st.closing)} bold />
            {st.openItems.map((o) => <Text key={o.uid} style={{ fontSize: 14, color: o.band === 'overdue' ? C.danger : C.sub }}>• {o.ref || (o.kind === 'credit' ? 'credit note' : 'no number')} – {BAND[o.band]}{o.due ? ` (due ${o.due})` : ''}: {$(o.left)}</Text>)}
          </Card>
          <Card tone={st.unpresentedTotal ? 'warn' : undefined}>
            <H>What we owe vs cheques not presented</H>
            <Row label="What we owe (our books)" value={$(st.weOwe)} bold />
            <Row label="Cheques written, not presented yet" value={$(st.unpresentedTotal)} />
            {st.notHandedTotal ? <Row label="… of which not handed over yet" value={$(st.notHandedTotal)} color={C.warn} /> : null}
            <Row label="Their books may show until banked" value={$(st.beforeChequesClear)} bold />
            {st.unpresented.map((c) => <Text key={c.uid} style={{ fontSize: 14, color: C.sub }}>• Cheque {c.cheque_no} · {$(c.amount)} · written {c.cheque_date}{c.handed_date ? ` · handed over ${c.handed_date}` : ' · not handed over'}</Text>)}
          </Card>
          {st.lastCheck ? <Hint>{`Last statement check: ${st.lastCheck.statement_date} – theirs ${$(st.lastCheck.their_balance)}, ours ${$(st.lastCheck.our_balance)}${Math.abs(st.lastCheck.diff) < 0.005 ? ' (agreed)' : ` (difference ${$(st.lastCheck.diff)})`}.`}</Hint> : null}
        </>
      ) : null}
    </Screen>
  );
}
