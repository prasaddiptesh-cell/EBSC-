// 1.0.0 (map screens o-chq, o-dep, r-sup, rep-sup, s-cheque, s-cashpaid): the cheque trail, the deposit plan, the
// supplier page (statement in and out with each cheque's chain, products, papers, details), the supplier standings
// (week / month), and the staff screens "Cheque written" and "Paid a supplier in cash". Every choice is a drop-down.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Select, Chips, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { MoneyField, Hint, DateField } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import * as AP from '../service.js';
import * as CH from '../chain.js';
import * as DP from '../depositPlan.js';
import { Papers } from '../../verify/screens/Papers.js';
import { Row } from '../../verify/screens/TodayScreens.js';
import { papersFor, supplierPapers, papersMonths } from '../../verify/papers.js';

const { $ } = AP;
const supOptions = () => [{ value: '', label: 'Choose the supplier' }].concat(AP.listSuppliers().map((s) => ({ value: s.uid, label: s.name })));
const when = (at) => (at ? String(at).slice(5, 16).replace(' ', ' at ').replace(/^(\d\d)-(\d\d)/, '$2/$1') : '');
const shopOpts = () => { try { return require('../../admin/service.js').listShops().map((s) => ({ value: s.code, label: s.name || s.code })); } catch (e) { return [{ value: 'S1', label: 'S1' }]; } };
const cashFromOpts = (shop) => {
  let tills = [];
  try { tills = require('../../till/service.js').listTills({ shopCode: shop }); } catch (e) { tills = []; }
  return [{ value: 'safe', label: 'The safe' }].concat(tills.map((t) => ({ value: `till:${t.uid}`, label: t.name })));
};

// One step of a chain (done: time and who; waiting: grey). Papers of the step under it.
function Step({ s, papers, testID }) {
  return (
    <View testID={testID} style={{ flexDirection: 'row', gap: 10 }}>
      <Text style={{ fontSize: 18, width: 26, color: s.done ? C.success : C.sub }}>{s.done ? '✓' : '○'}</Text>
      <View style={{ flex: 1, gap: 4 }}>
        <Text style={{ fontSize: 16, fontWeight: s.done ? '800' : '600', color: s.done ? C.text : C.sub }}>{s.label}{s.done && s.at ? ` – ${when(s.at)}` : ''}{s.done && s.by ? ` (${s.by})` : ''}</Text>
        {s.note ? <Text style={{ fontSize: 14, color: C.sub }}>{s.note}</Text> : null}
        {papers && papers.length ? <Papers groups={papers} testID={`${testID}-papers`} size={90} /> : null}
      </View>
    </View>
  );
}

// ---------------------------------------------------------------- the cheque trail (o-chq)
export function ChequeTrailScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [taker, setTaker] = useState('');
  const [link, setLink] = useState(false);
  const [pick, setPick] = useState('');
  const [why, setWhy] = useState('');
  let c = null;
  try { c = CH.chequeChain(params.chequeUid || params.snapUid); } catch (e) { c = null; }
  if (!c) return <Screen title="Cheque"><Banner tone="warn" message="This cheque was not found." /></Screen>;
  const all = papersFor(c.chequeUid ? { table: 'cheques', uid: c.chequeUid } : { table: 'money_snaps', uid: c.snapUid });
  const chequePhotos = all.filter((g) => g.kind === 'cheque');
  const invPhotos = all.filter((g) => g.kind === 'invoice');
  const planUid = c.steps[4].planUid;
  const slip = planUid ? papersFor({ table: 'deposit_plans', uid: planUid }) : [];
  const stepPapers = { invoice_received: invPhotos, written: chequePhotos, banked: slip };
  const office = can('payments_make') || ['owner', 'admin'].includes(user.role);
  const unpaid = c.supplierUid ? AP.listInvoices({ filter: 'unpaid', supplierUid: c.supplierUid }).filter((i) => i.kind === 'invoice') : [];
  const run = (fn, ok) => { try { fn(); ui.toast(ok); setLink(false); setTaker(''); } catch (e) { ui.error(e); } };
  return (
    <Screen title={`Cheque ${c.no}`} subtitle={`${$(c.amount)} · ${c.supplierName || ''}`}>
      {!c.recorded ? <Banner testID="ct-unrecorded" tone="warn" title="Not recorded yet" message="Written by staff. The office records the payment (Pay a supplier, this cheque number)." /> : null}
      {!c.linked ? <Banner testID="ct-nolink" tone="danger" title="Not linked to an invoice" message="Every cheque pays an invoice or bill. Link it below." /> : null}
      <Card>
        {c.steps.map((s) => <Step key={s.key} s={s} papers={stepPapers[s.key]} testID={`ct-step-${s.key}`} />)}
      </Card>
      {!c.steps[3].done ? (
        <Card>
          <Field testID="ct-taker" label="Who took the cheque?" value={taker} onChangeText={setTaker} placeholder="e.g. Rewa driver – Joe" />
          <Btn testID="ct-picked" title="Supplier picked it up" icon="✋" variant="success" onPress={() => run(() => CH.pickedUp(user, { chequeUid: c.chequeUid, snapUid: c.chequeUid ? undefined : c.snapUid, takenBy: taker }), 'Given to the supplier')} />
        </Card>
      ) : null}
      {!c.steps[4].done && DP.mayPlan(user) ? <Btn testID="ct-plan" title="Plan a deposit to cover it" icon="🏦" size="md" variant="info" onPress={() => nav.push('DepositPlan', { cover: c.chequeUid || c.snapUid })} /> : null}
      {planUid ? <Btn testID="ct-open-plan" title="Open the deposit plan" size="md" variant="ghost" onPress={() => nav.push('DepositPlan', { uid: planUid })} /> : null}
      {!c.recorded && office ? <Btn testID="ct-record" title="Record the payment" icon="💸" size="md" variant="success" onPress={() => nav.push('ApPay', { supplierUid: c.supplierUid || undefined, chequeNo: c.no, invoiceUids: c.invoices.map((i) => i.uid), accountUid: c.accountUid || undefined })} /> : null}
      {office && c.status !== 'presented' ? <Btn testID="ct-link" title={c.linked ? 'Link to a different invoice' : 'Link it to the invoice'} size="md" variant="secondary" onPress={() => setLink(!link)} /> : null}
      {link ? (
        <Card>
          <Select testID="ct-inv" label="Which invoice does it pay?" value={pick} onChange={setPick} options={[{ value: '', label: 'Choose the invoice' }].concat(unpaid.map((i) => ({ value: i.uid, label: `${i.invoice_no || '(no number)'} · ${$(i.owing)} · ${i.invoice_date}` })))} />
          {c.recorded && c.linked ? <Field testID="ct-why" label="Why?" value={why} onChangeText={setWhy} /> : null}
          <Btn testID="ct-link-save" title="Link it" variant="success" onPress={() => run(() => CH.linkInvoices(user, { chequeUid: c.chequeUid || undefined, snapUid: c.chequeUid ? undefined : c.snapUid, invoiceUids: [pick], reason: why }), 'Linked')} />
        </Card>
      ) : null}
      {c.supplierUid ? <Btn testID="ct-sup" title={`${c.supplierName} – supplier page`} size="md" variant="ghost" onPress={() => nav.push('SupplierPage', { uid: c.supplierUid })} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Cheques (Home button, build 8)
export function ChequeHomeScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  // Release 03 (owner, 12 Nov: "so many cheque menus and sub menus all around the app"): one Cheques page –
  // the cheques, the books (where each is), spoiled cheques to check, and cheques to cover
  const [tab, setTab] = useState(params.tab || 'cheques');
  const boss = ['owner', 'admin'].includes(user.role);
  let spoiled = [];
  try { spoiled = require('../chequePlaces.js').spoiledToCheck(); } catch (e) { spoiled = []; }
  const tabs = [{ value: 'cheques', label: 'Cheques' }, { value: 'books', label: 'Books' }, { value: 'spoiled', label: spoiled.length ? `Spoiled (${spoiled.length})` : 'Spoiled' }, { value: 'cover', label: 'To cover' }];
  return (
    <Screen title="Cheques" subtitle="Write, find, books and where they are, spoiled cheques">
      <Chips value={tab} onChange={setTab} testIDPrefix="chq-home-tab" options={tabs} />
      {tab === 'cheques' ? <ChequeBoard /> : null}
      {tab === 'books' ? <BooksWhere /> : null}
      {tab === 'spoiled' ? <SpoiledList list={spoiled} boss={boss} /> : null}
      {tab === 'cover' ? (
        <Card>
          <Text style={{ fontSize: 15, color: C.sub }}>Cheques handed over or post-dated with no deposit behind them yet.</Text>
          <Btn testID="chq-open-cover" title="Open Cheques to cover" icon="🛡️" variant="primary" onPress={() => nav.push('ChequeCover', {})} />
        </Card>
      ) : null}
      {can('cheques_manage') ? <Btn testID="chq-open-register" title="Register, deposits & bank fees, balance check" icon="🏦" variant="secondary" size="md" onPress={() => nav.push('Cheques', { tab: 'register' })} /> : null}
    </Screen>
  );
}
function ChequeBoard() {
  const { nav, user, screens } = useApp();
  const shop = ['supervisor', 'manager'].includes(user.role) ? user.shop_code : undefined;
  let groups = [];
  try { groups = CH.chequeBoard({ shopCode: shop }); } catch (e) { groups = []; }
  // build 38 (owner: "a place to search if that cheque has been used"): a cheque number (or a supplier) searched here
  const [q, setQ] = useState('');
  const qq = String(q || '').trim().toLowerCase();
  const digits = /^\d+$/.test(qq);
  const hit = (c) => !qq || (digits ? String(c.no || '').includes(String(Number(qq))) : String(c.supplierName || '').toLowerCase().includes(qq));
  const shown = groups.map((g) => ({ ...g, list: g.list.filter(hit) }));
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Btn testID="chq-new" title="Write a new cheque" icon="✍️" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('ChequeWritten', {})} />
        {screens && screens.HandCheque && screens.HandCheque.can(user) ? <Btn testID="chq-hand" title="Hand over a cheque" icon="🤝" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('HandCheque', {})} /> : null}
      </View>
      <Field testID="chq-search" label="Search: cheque number (or supplier)" value={q} onChangeText={setQ} keyboardType="number-pad" />
      {digits ? require('./ChequePicker.js').ChequeNoStatus({ no: qq, testID: 'chq-search-status' }) : null}
      {(qq ? shown.filter((g) => g.list.length) : shown).map((g) => (
        <Card key={g.key} testID={`chq-g-${g.key}`}>
          <Text style={{ fontWeight: '700', fontSize: 16, marginBottom: 4 }}>{`${g.title} (${g.list.length})`}</Text>
          {!g.list.length ? <Hint>None</Hint> : g.list.map((c) => (
            <Row key={c.key} testID={`chq-${c.key}`} title={`Cheque ${c.no || '?'} · ${c.supplierName || 'supplier?'}`}
              sub={[c.date, c.shop, c.handedTo ? `taken by ${c.handedTo}` : null, !c.linked ? 'not linked to an invoice' : null].filter(Boolean).join(' · ')}
              right={$(c.amount)} onPress={() => nav.push('ChequeTrail', c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid })} />
          ))}
        </Card>
      ))}
    </View>
  );
}
// Each cheque book: spare / in use / finished, where it is, leaves left, its moves; move it (cheques_manage).
function BooksWhere() {
  const { user, can, nav } = useApp();
  const ui = useUI();
  const P = require('../chequePlaces.js');
  const [, bump] = useState(0);
  const [moving, setMoving] = useState(null);
  let books = [];
  try { books = require('../chequebooks.js').listAllBooks(); } catch (e) { books = []; }
  const order = { in_use: 0, spare: 1, finished: 2, cancelled: 3, lost: 4 };
  books.sort((a, b) => (order[a.status] ?? 5) - (order[b.status] ?? 5) || a.first_no - b.first_no);
  const places = P.bookPlaces();
  const save = () => { try { P.moveBook(user, moving.uid, { to: moving.to, person: moving.person, note: moving.note }); ui.toast('Moved'); setMoving(null); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <View style={{ gap: 10 }}>
      {!books.length ? <Hint>No cheque books yet. Add them in Register › Books.</Hint> : null}
      {books.map((b) => {
        const moves = P.bookMoves(b);
        return (
          <Card key={b.uid} testID={`book-${b.first_no}`}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${b.first_no}–${b.last_no} · ${b.statusLabel}`}</Text>
            <Text style={{ fontSize: 15, color: C.text }}>{`📍 ${P.placeLabel(b.location)}${b.holder ? ` · kept by ${b.holder}` : ''}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{`${b.unused} unused · ${b.written + b.presented} written · ${b.spoiled} spoiled${b.skipped ? ` · ${b.skipped} SKIPPED` : ''}`}</Text>
            {moves.length ? <Text style={{ fontSize: 13, color: C.sub }}>{moves.slice(-3).map((m) => `${String(m.at).slice(0, 10)} ${P.placeLabel(m.from)} → ${P.placeLabel(m.to)} (${m.by})`).join('\n')}</Text> : null}
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
              {can('cheques_manage') ? <Btn testID={`book-move-${b.first_no}`} title="Move the book" icon="📦" size="sm" variant="secondary" onPress={() => setMoving({ uid: b.uid, to: '', person: '', note: '' })} /> : null}
              <Btn testID={`book-leaves-${b.first_no}`} title="Leaf by leaf" icon="📗" size="sm" variant="secondary" onPress={() => nav.push('ChequeBooks', { bookUid: b.uid })} />
            </View>
            {moving && moving.uid === b.uid ? (
              <View style={{ gap: 8, marginTop: 8 }}>
                <Chips value={moving.to} onChange={(v) => setMoving({ ...moving, to: v, person: '' })} testIDPrefix="move-to" options={places.map((p) => ({ value: p.key, label: p.label }))} />
                <Field testID="move-person" label="Or with a person (name)" value={moving.person} onChangeText={(v) => setMoving({ ...moving, person: v, to: '' })} />
                <Field testID="move-note" label="Note (optional)" value={moving.note} onChangeText={(v) => setMoving({ ...moving, note: v })} />
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setMoving(null)} />
                  <Btn testID="move-save" title="Save the move" variant="success" style={{ flex: 1 }} onPress={save} />
                </View>
              </View>
            ) : null}
          </Card>
        );
      })}
    </View>
  );
}
function SpoiledList({ list, boss }) {
  const { user, can } = useApp();
  const ui = useUI();
  const P = require('../chequePlaces.js');
  const { ReasonButton } = require('../../../ui/kit.js');
  const { listPhotos } = require('../../../services/stock.js');
  const { PhotoStrip } = require('../../../ui/photoView.js');
  const [, bump] = useState(0);
  const run = (fn, msg) => { try { fn(); ui.toast(msg); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  if (!list.length) return <Hint>No spoiled cheques waiting. Each spoiled cheque needs a reason and a photo, then the owner or an admin checks it.</Hint>;
  return (
    <View style={{ gap: 10 }}>
      {list.map((c) => {
        let photos = [];
        try { photos = listPhotos('stub', c.uid); } catch (e) { photos = []; }
        return (
          <Card key={c.uid} testID={`spoiled-${c.cheque_no}`} tone={c.spoil_check === 'query' ? 'warn' : undefined}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`Cheque ${c.cheque_no} – spoiled ${c.cheque_date}`}</Text>
            <Text style={{ fontSize: 15, color: C.text }}>{`Why: ${c.void_reason || '–'} · by ${c.written_by_name || '?'}`}</Text>
            {c.spoil_check_note ? <Text style={{ fontSize: 14, color: C.warn }}>{`Question: ${c.spoil_check_note}`}</Text> : null}
            {photos.length ? <PhotoStrip photos={photos} size={110} /> : <Hint>No photo on this device yet (it comes with the sync).</Hint>}
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 6 }}>
              {boss && c.spoil_check === 'waiting' ? <Btn testID={`spoiled-ok-${c.cheque_no}`} title="Confirmed" icon="✅" size="md" variant="success" onPress={() => run(() => P.checkSpoiled(user, c.uid, { ok: true }), 'Confirmed')} /> : null}
              {boss && c.spoil_check === 'waiting' ? <ReasonButton testID={`spoiled-q-${c.cheque_no}`} title="Ask a question" icon="❓" prompt="What do you want to ask?" confirm="Send" variant="secondary" size="md" onDo={(w) => run(() => P.checkSpoiled(user, c.uid, { ok: false, note: w }), 'Asked')} /> : null}
              {c.spoil_check === 'query' && can('payments_make') ? <ReasonButton testID={`spoiled-a-${c.cheque_no}`} title="Answer" icon="💬" prompt="Your answer" confirm="Send" variant="primary" size="md" onDo={(w) => run(() => P.answerSpoiled(user, c.uid, w), 'Sent')} /> : null}
              {!boss && c.spoil_check === 'waiting' ? <Hint>Waiting for the owner or an admin to check it.</Hint> : null}
            </View>
          </Card>
        );
      })}
    </View>
  );
}

// ---------------------------------------------------------------- deposit plan (o-dep): one, or a new one
export function DepositPlanScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [slipNo, setSlipNo] = useState('');
  const [photos, setPhotos] = useState([]);
  const [, bump] = useState(0);
  if (!params.uid) return <NewDepositPlan params={params} />;
  const p = DP.getPlan(params.uid);
  if (!p) return <Screen title="Deposit"><Banner tone="warn" message="This deposit plan was not found." /></Screen>;
  const run = (fn, ok) => { try { fn(); ui.toast(ok); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title={`Deposit for ${p.plan_date}`} subtitle={`${p.shop_code || ''} · ${p.statusLabel}`}>
      {p.lines.map((l, i) => <Row key={i} title={l.extra ? l.label : `To cover ${l.label}`} right={$(l.amount)} onPress={l.chequeUid || l.snapUid ? () => nav.push('ChequeTrail', l.chequeUid ? { chequeUid: l.chequeUid } : { snapUid: l.snapUid }) : undefined} />)}
      <Row title="Deposit" right={$(p.total)} />
      <Row title="Cash from" right={p.cash_from === 'safe' ? `Safe – ${p.shop_code}` : p.cash_from} />
      <Card>
        {p.steps.map((s) => <Step key={s.key} s={s} papers={s.key === 'banked' && s.done ? papersFor({ table: 'deposit_plans', uid: p.uid }) : null} testID={`dp-step-${s.key}`} />)}
      </Card>
      {p.status === 'planned' && DP.mayPlan(user) ? (
        <Card>
          <Field testID="dp-slipno" label="Slip number (optional)" value={slipNo} onChangeText={setSlipNo} />
          <Btn testID="dp-slip" title="Slip written" icon="✍️" variant="success" onPress={() => run(() => DP.slipWritten(user, p.uid, { slipNo }), 'Slip written')} />
        </Card>
      ) : null}
      {p.status === 'slip' && DP.mayPlan(user) ? (
        <Card>
          <PhotoPicker testID="dp-photo" label="Photo of the stamped slip" value={photos} onChange={setPhotos} required />
          <Btn testID="dp-banked" title="Banked" icon="🏦" variant="success" onPress={() => run(() => DP.banked(user, p.uid, { photos }), 'Banked')} />
        </Card>
      ) : null}
      {p.status === 'banked' && (can('bank_rec') || can('payments_make') || ['owner', 'admin', 'manager'].includes(user.role)) ? <Btn testID="dp-onbank" title="It shows on the bank" icon="✓" variant="success" onPress={() => run(() => DP.onBank(user, p.uid, { date: dateStr() }), 'On the bank')} /> : null}
    </Screen>
  );
}
function NewDepositPlan({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [shop, setShop] = useState(user.shop_code || 'S1');
  const [date, setDate] = useState(dateStr());
  const [picked, setPicked] = useState(() => (params.cover ? [params.cover] : []));
  const [extra, setExtra] = useState('');
  const [add, setAdd] = useState('');
  if (!DP.mayPlan(user)) return <Screen title="Plan a deposit"><Banner tone="warn" message="A supervisor or manager plans deposits." /></Screen>;
  const choices = DP.planChoices({});
  const chosen = choices.filter((c) => picked.includes(c.key));
  const total = chosen.reduce((t, c) => t + c.left, 0) + (Number(extra) || 0);
  const days = [0, 1, 2, 3, 4, 5, 6].map((n) => { const d = new Date(Date.parse(`${dateStr()}T12:00:00`) + n * 86400000); const s = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; return { value: s, label: n === 0 ? `Today ${s}` : n === 1 ? `Tomorrow ${s}` : s }; });
  const save = () => {
    try {
      const p = DP.planDeposit(user, { shopCode: shop, date, lines: chosen.map((c) => ({ chequeUid: c.chequeUid || undefined, snapUid: c.chequeUid ? undefined : c.snapUid, amount: c.left })), extra });
      ui.toast('Deposit planned'); nav.replace('DepositPlan', { uid: p.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Plan a deposit" subtitle="Mostly to cover cheques" footer={<Btn testID="dp-save" title={`Plan it · ${$(total)}`} icon="🏦" variant="success" onPress={save} />}>
      {['supervisor', 'manager'].includes(user.role) ? null : <Select testID="dp-shop" label="Money from shop" value={shop} onChange={setShop} options={shopOpts()} />}
      <Select testID="dp-date" label="Deposit on" value={date} onChange={setDate} options={days} />
      {chosen.map((c) => <Row key={c.key} title={`To cover ${c.label}`} sub={c.stage} right={$(c.left)} onPress={() => setPicked(picked.filter((k) => k !== c.key))} />)}
      <Select testID="dp-add" label="Add a cheque to cover" value={add} onChange={(v) => { if (v) setPicked(picked.concat([v])); setAdd(''); }}
        options={[{ value: '', label: choices.length ? 'Choose a cheque' : 'No cheques waiting' }].concat(choices.filter((c) => !picked.includes(c.key)).map((c) => ({ value: c.key, label: `${c.label} · ${$(c.left)}`, hint: c.stage })))} />
      <MoneyField testID="dp-extra" label="Other money in the same deposit (optional)" value={extra} onChange={setExtra} />
      <Hint>Then: write the slip → bank it (photo of the stamped slip) → the office ticks it when it shows on the bank.</Hint>
    </Screen>
  );
}
export function DepositPlansScreen() {
  const { nav, user } = useApp();
  const list = DP.listPlans({ open: true, shopCode: ['supervisor', 'manager'].includes(user.role) ? user.shop_code : undefined });
  return (
    <Screen title="Deposit plans" subtitle={`${list.length} not on the bank yet`}>
      {DP.mayPlan(user) ? <Btn testID="dps-new" title="Plan a deposit" icon="➕" variant="success" onPress={() => nav.push('DepositPlan', {})} /> : null}
      {list.map((p) => <Row key={p.uid} testID={`dps-${p.uid}`} title={`${p.plan_date} · ${p.shop_code || ''}`} sub={p.statusLabel} right={$(p.total)} onPress={() => nav.push('DepositPlan', { uid: p.uid })} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- the supplier page (r-sup)
export function SupplierPageScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [tab, setTab] = useState(params.tab || 'statement');
  const [month, setMonth] = useState('');
  const [, bump] = useState(0);
  const [addPick, setAddPick] = useState('');
  let pg = null;
  try { pg = CH.supplierPage(params.uid); } catch (e) { pg = null; }
  if (!pg) return <Screen title="Supplier"><Banner tone="warn" message="Supplier not found." /></Screen>;
  const s = pg.supplier;
  const manage = can('inventory_manage') || ['owner', 'admin'].includes(user.role);
  const tabs = [{ value: 'statement', label: 'Statement (in and out)' }, { value: 'products', label: `Products (${pg.products.length})` }, { value: 'papers', label: 'Papers' }, { value: 'details', label: 'Details' }];
  const papers = tab === 'papers' ? supplierPapers(s.uid) : [];
  const months = papersMonths(papers);
  const shown = month ? papers.filter((p) => String(p.date).startsWith(month)) : papers;
  let I = null; try { I = require('../../inventory/service.js'); } catch (e) { I = null; }
  return (
    <Screen title={s.name} subtitle={`owing ${$(pg.owingTotal)}`}>
      <Select testID="sp-tab" label="Show" value={tab} onChange={setTab} options={tabs} />
      {tab === 'details' ? (() => {
        // build 34: what the app has learned from this supplier's invoices (told to the AI each time it reads one)
        let notes = ''; let seen = 0;
        try { const L = require('../invoiceLearn.js'); notes = L.supplierNotes(s.uid); seen = L.learnedCount(s.uid); } catch (e) { notes = ''; }
        return (
          <Card testID="sp-learned">
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>What the app has learned about their invoices</Text>
            <Text style={{ fontSize: 15, color: notes ? C.text : C.sub, marginTop: 4 }}>{notes ? `${notes}.` : 'Nothing yet – it learns from every invoice of theirs that is saved.'}</Text>
            {seen ? <Text style={{ fontSize: 13, color: C.sub, marginTop: 4 }}>{`From ${seen} invoice${seen === 1 ? '' : 's'}. The AI is told this each time it reads one of their invoices.`}</Text> : null}
            {notes && ['owner', 'admin'].includes(user.role) ? <Btn testID="sp-forget" title="Clear what was learned" size="sm" variant="ghost" onPress={async () => {
              if (!(await ui.confirm({ title: 'Clear what was learned?', message: `The app starts learning ${s.name}'s invoices again from the next one.`, confirmText: 'Clear', tone: 'warn' }))) return;
              try { require('../../inventory/invoiceRead.js').forgetLayout(user, s.uid); ui.toast('Cleared'); bump((n) => n + 1); } catch (e) { ui.error(e); }
            }} /> : null}
          </Card>
        );
      })() : null}
      {tab === 'statement' ? (
        <>
          {pg.noChequeCount ? <Row testID="sp-nocheque" title="Not paid, no cheque" right={`${pg.noChequeCount} invoice${pg.noChequeCount === 1 ? '' : 's'}`} level="warn" /> : null}
          {pg.owing.map((i) => <Row key={i.uid} testID={`sp-owing-${i.invoice_no}`} title={`${i.invoice_no || '(no number)'} · due ${i.due_date}`} sub={i.noCheque ? 'not paid, no cheque' : 'cheque on the way'} right={$(i.owing)} level={i.noCheque ? (i.due === 'overdue' ? 'bad' : 'warn') : null} onPress={() => nav.push('TodayInvoice', { uid: i.uid })} />)}
          <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub, marginTop: 6 }}>CHEQUES</Text>
          {pg.chains.map((c) => <Row key={c.key} testID={`sp-chq-${c.no}`} title={`Cheque ${c.no} · ${c.stage}`} sub={c.invoices.map((i) => i.invoice_no).join(', ') || 'not linked'} right={`−${$(c.amount)}`} level={!c.linked ? 'bad' : null} onPress={() => nav.push('ChequeTrail', c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid })} />)}
          <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub, marginTop: 6 }}>{`IN AND OUT SINCE ${pg.from}`}</Text>
          {(pg.statement ? pg.statement.lines.slice().reverse() : []).slice(0, 120).map((l, i) => (
            <Row key={i} title={`${l.date} · ${l.what} ${l.ref || ''}`.trim()} sub={l.kind === 'payment' ? (l.notCleared ? 'not cleared yet' : 'cleared') : null} right={l.charge ? `+${$(l.charge)}` : `−${$(l.credit)}`}
              onPress={l.kind === 'payment' ? undefined : () => nav.push('TodayInvoice', { uid: l.uid })} />
          ))}
          {pg.owed.length ? <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub, marginTop: 6 }}>THEY OWE US</Text> : null}
          {pg.owed.map((o) => <Row key={o.uid} title={`${o.name} × ${o.left}`} sub={`${o.reason} · ${o.invoice_no || ''}`} right={$(o.leftValue)} level="warn" onPress={() => nav.push('DamagedWaiting', { uid: o.uid })} />)}
          <Btn testID="sp-full" title="Full statement (any period)" size="md" variant="ghost" onPress={() => nav.push('ApSupplierStatement', { supplierUid: s.uid })} />
        </>
      ) : null}
      {tab === 'products' ? (
        <>
          <Hint>Their code, last price, carton size and when last bought. Products are added by themselves from every delivery and invoice, or here.</Hint>
          {manage && I ? (
            <Select testID="sp-add" label="Add a product to this supplier" value={addPick} search onChange={(v) => { if (!v) return; try { I.addItemSupplier(user, v, s.uid, {}); ui.toast('Added'); bump((n) => n + 1); } catch (e) { ui.error(e); } setAddPick(''); }}
              options={[{ value: '', label: 'Choose a product' }].concat(I.listProducts({ limit: 3000 }).filter((p) => !pg.products.some((x) => x.uid === p.uid)).map((p) => ({ value: p.uid, label: p.name, hint: p.code })))} />
          ) : null}
          {pg.products.map((p) => (
            <View key={p.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}><Row testID={`sp-prod-${p.code}`} title={p.name} sub={[p.supplierCode ? `their code ${p.supplierCode}` : p.code, p.pack > 1 ? `carton of ${p.pack}` : '', p.lastDate ? `last bought ${p.lastDate}` : ''].filter(Boolean).join(' · ')} right={p.lastCost !== null && p.lastCost !== undefined ? `$${Number(p.lastCost).toFixed(2)}` : ''} /></View>
              {manage ? <Btn testID={`sp-rm-${p.code}`} title="✕" size="sm" variant="ghost" onPress={() => { try { I.removeItemSupplier(user, p.uid, s.uid); ui.toast(`${p.name} removed from ${s.name}`); bump((n) => n + 1); } catch (e) { ui.error(e); } }} /> : null}
            </View>
          ))}
          {can('po_create') ? <Btn testID="sp-order" title={`New order to ${s.name}`} icon="🛒" variant="info" onPress={() => nav.push('POEdit', { supplierUid: s.uid, suggest: true })} /> : null}
        </>
      ) : null}
      {tab === 'papers' ? (
        <>
          <Select testID="sp-month" label="Month" value={month} onChange={setMonth} options={[{ value: '', label: 'All months' }].concat(months.map((m) => ({ value: m, label: m })))} />
          {!shown.length ? <Text style={{ color: C.sub, fontSize: 15 }}>No papers saved{month ? ' this month' : ''}.</Text> : null}
          {shown.slice(0, 60).map((p) => (
            <Card key={p.key}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${p.date} · ${p.label} · ${$(p.amount)}`}</Text>
              <Papers groups={[{ label: '', photos: p.photos }]} testID={`sp-paper-${p.key.replace(/[^A-Za-z0-9]/g, '')}`} size={90} />
            </Card>
          ))}
        </>
      ) : null}
      {tab === 'details' ? (
        <>
          <Row title="Pays" right={s.on_account ? `on account, ${s.terms_days} days` : 'on delivery'} />
          <Row title="Usually paid by" right={s.pay_method || ''} />
          {s.phone ? <Row title="Phone" right={s.phone} /> : null}
          {s.tin ? <Row title="TIN" right={s.tin} /> : null}
          <Btn testID="sp-edit" title="Change the details" size="md" variant="secondary" onPress={() => nav.push('ApSupplierEdit', { uid: s.uid })} />
        </>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- supplier standings (rep-sup)
export function SupplierStandingsScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [period, setPeriod] = useState(params.period || 'week');
  const st = CH.supplierStandings({ period, shopCode: ['supervisor', 'manager'].includes(user.role) ? user.shop_code : undefined });
  return (
    <Screen title="Supplier standings" subtitle={`${st.label} · ${st.from} to ${st.to}`}>
      <Select testID="ss-period" label="Period" value={period} onChange={setPeriod} options={[{ value: 'week', label: 'This week (Sat – Fri)' }, { value: 'month', label: 'This month' }]} />
      <Row title="Owing to suppliers" right={$(st.totals.owing)} />
      <Row title="Unpaid with no cheque" right={`${st.totals.noCheque} · ${$(st.totals.noChequeOwing)}`} level={st.totals.noCheque ? 'warn' : null} />
      <Row title="Cheques not cleared" right={$(st.totals.notCleared)} />
      <Row title={`Invoices this ${period === 'week' ? 'week' : 'month'}`} right={$(st.totals.invoiced)} />
      {st.list.map((r) => <Row key={r.supplierUid} testID={`ss-${r.name.replace(/[^A-Za-z0-9]/g, '')}`} title={r.name} sub={r.flags.join(' · ') || 'all settled'} right={$(r.owing)} level={r.noCheque ? 'warn' : null} onPress={() => nav.push('SupplierPage', { uid: r.supplierUid })} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff: Cheque written (s-cheque)
export function ChequeWrittenScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  // build 31 (owner: "there is no AI reading for cheque"): the photo first – the AI reads the cheque number, amount,
  // who it is made out to (the supplier) and the date; every box can still be typed, and is ticked as checked.
  const cp = usePaper('cheque');
  const [f, setF] = useState({ sup: params.supplierUid || '', no: '', amount: '', chequeDate: dateStr() });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const sup = f.sup;
  const [inv, setInv] = useState('');
  const [where, setWhere] = useState('waiting');
  const [taker, setTaker] = useState('');
  const [photos, setPhotos] = useState([]);
  // build 31 (owner: "issued by which shop is not an option – it just shows Shop 1"): the shop is chosen here
  const shops = (() => { try { return require('../../admin/service.js').listShops().filter((x) => x.active && /^S\d+$/.test(String(x.code))); } catch (e) { return []; } })();
  const [shop, setShop] = useState(user.shop_code || (shops.length === 1 ? shops[0].code : ''));
  const unpaid = sup ? AP.listInvoices({ filter: 'unpaid', supplierUid: sup }).filter((i) => i.kind === 'invoice') : [];
  const save = async () => {
    if (!cp.okToSave(ui)) return;
    if (shops.length > 1 && !shop) { ui.alert({ title: 'Which shop?', message: 'Choose the shop that issued the cheque.', tone: 'warn' }); return; }
    // build 37 (owner: "the app needs to check the name is accurate and the dates and signature is there, and NN"):
    // what the photo shows against what was typed, and a future date – asked before saving
    const supName = (AP.listSuppliers().find((x) => x.uid === sup) || {}).name || '';
    const { compareCheque } = require('../../../services/chequeRead.js');
    const read = (cp.read && cp.read.fields) || {};
    const asks = compareCheque(read, { supplierName: supName, chequeDate: f.chequeDate, amount: f.amount, chequeNo: f.no }, { today: dateStr() })
      .concat(((cp.read && cp.read.checks) || []).filter((c) => c.level === 'warn' && ['signed', 'nn'].includes(c.key)));
    if (asks.length) {
      const ok = await ui.confirm({ title: 'Check the cheque', message: `${asks.map((x) => `• ${x.text}`).join('\n')}\n\nSave it like this?`, confirmText: 'Yes – it is right', cancelText: 'Fix it', tone: 'warn' });
      if (!ok) return;
    }
    try {
      CH.chequeWritten(user, { supplierUid: sup, invoiceUids: inv && inv !== 'none' ? [inv] : [], chequeNo: f.no, amount: f.amount, chequeDate: f.chequeDate, where, takenBy: taker, photos, shopCode: shop || user.shop_code || undefined,
        note: asks.length ? `Confirmed: ${asks.map((x) => x.text).join(' ')}`.slice(0, 300) : undefined });
      cp.log(user, 'cheque_snaps', f.no, f, { chequeNo: 'no', amount: 'amount', supplierUid: 'sup' });
      nav.replace('SavedDone', { text: 'Sent to the office to check. Every cheque is linked to its invoice there.' });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Cheque written" footer={<Btn testID="cw-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <PaperPhoto pr={cp} testID="cw-photo" label="Photo of the cheque" value={photos} onChange={setPhotos} required form={f} setForm={setF}
        map={{ chequeNo: 'no', amount: 'amount', supplierUid: 'sup', date: 'chequeDate' }} soft={{ chequeDate: dateStr() }}
        labels={{ chequeNo: 'Cheque number', amount: 'Amount', supplierUid: 'Supplier (made out to)', date: 'Date on the cheque' }}
        display={(k, v) => (k === 'supplierUid' ? ((AP.listSuppliers().find((x) => x.uid === v) || {}).name || v) : undefined)}
        hint="Take the photo first – the AI reads the number, amount and who it is made out to." />
      {shops.length > 1 && !user.shop_code ? <Chips value={shop} onChange={setShop} testIDPrefix="cw-shop" options={shops.map((x) => ({ value: x.code, label: `Issued by ${String(x.name || x.code).replace(/^Shop (\d) - /, 'Shop $1 ')}` }))} /> : null}
      <Select testID="cw-sup" label="Supplier" value={sup} onChange={(v) => { set('sup')(v); setInv(''); }} options={supOptions()} />
      {sup ? <Select testID="cw-inv" label="For invoice(s)" value={inv} onChange={(v) => { setInv(v); const i = unpaid.find((x) => x.uid === v); if (i && !f.amount) set('amount')(String(i.owing)); }}
        options={[{ value: '', label: 'Choose the invoice' }].concat(unpaid.map((i) => ({ value: i.uid, label: `${i.invoice_no || '(no number)'} ${$(i.owing)}`, hint: i.invoice_date })), [{ value: 'none', label: 'Not sure – the office links it' }])} /> : null}
      <Field testID="cw-no" label="Cheque no." value={f.no} onChangeText={set('no')} keyboardType="number-pad" />
      {f.no ? require('./ChequePicker.js').ChequeNoStatus({ no: f.no, testID: 'cw-no-status' }) : null}
      <MoneyField testID="cw-amount" label="Amount" value={f.amount} onChange={set('amount')} />
      <DateField testID="cw-chqdate" label="Date written on the cheque (can be later – post-dated)" value={f.chequeDate} onChange={set('chequeDate')} />
      {f.chequeDate > dateStr() ? <Hint>{`Post-dated: the bank cannot pay it before ${f.chequeDate}.`}</Hint> : null}
      <Select testID="cw-where" label="Where is it now" value={where} onChange={setWhere} options={[{ value: 'waiting', label: 'Waiting for pickup' }, { value: 'given', label: 'Given to the supplier' }]} />
      {where === 'given' ? <Field testID="cw-taker" label="Who took it?" value={taker} onChangeText={setTaker} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff: Paid a supplier in cash (s-cashpaid)
export function PaidCashScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [shop] = useState(user.shop_code || 'S1');
  const [sup, setSup] = useState(params.supplierUid || '');
  const [inv, setInv] = useState('');
  const [amount, setAmount] = useState('');
  const [from, setFrom] = useState('');
  const [photos, setPhotos] = useState([]);
  const unpaid = sup ? AP.listInvoices({ filter: 'unpaid', supplierUid: sup }).filter((i) => i.kind === 'invoice') : [];
  const save = () => {
    try { CH.cashPaid(user, { supplierUid: sup, invoiceUid: inv && inv !== 'none' ? inv : undefined, amount, cashFrom: from, shopCode: shop, photos }); nav.replace('SavedDone', { text: 'Sent to the office to check.' }); } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Paid in cash" footer={<Btn testID="pc-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Select testID="pc-sup" label="Supplier" value={sup} onChange={(v) => { setSup(v); setInv(''); }} options={supOptions()} />
      {sup ? <Select testID="pc-inv" label="For" value={inv} onChange={(v) => { setInv(v); const i = unpaid.find((x) => x.uid === v); if (i && !amount) setAmount(String(i.owing)); }}
        options={[{ value: '', label: 'Choose the invoice' }].concat(unpaid.map((i) => ({ value: i.uid, label: `Invoice ${i.invoice_no || '(no number)'} ${$(i.owing)}` })), [{ value: 'none', label: 'No invoice – just their receipt' }])} /> : null}
      <MoneyField testID="pc-amount" label="Amount" value={amount} onChange={setAmount} />
      <Select testID="pc-from" label="Cash from" value={from} onChange={setFrom} options={[{ value: '', label: 'Choose' }].concat(cashFromOpts(shop))} />
      <PhotoPicker testID="pc-photo" label="Photo of their receipt" value={photos} onChange={setPhotos} required />
    </Screen>
  );
}
