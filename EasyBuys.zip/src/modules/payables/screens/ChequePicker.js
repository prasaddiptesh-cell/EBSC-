// v3.9 Cheque number: a drop-down of the cheque leaves still unused in the account's cheque books (the next one is
// chosen), or "Type another number…" to fill it in by hand. Used when paying suppliers (also split payments) and
// when paying the VAT return / FNPF schedule.
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Select, Field, Banner } from '../../../ui/components.js';
import { availableCheques } from '../chequebooks.js';

// build 38: as the number is typed – used already (to whom, how much, when), spoiled, saved by staff, or free
export function ChequeNoStatus({ no, accountUid, testID = 'chq-status' }) {
  let r = null;
  try { r = require('../chequebooks.js').lookupChequeNo(no, accountUid); } catch (e) { r = null; }
  if (!r) return null;
  return <Banner testID={testID} tone={r.level === 'ok' ? 'success' : r.level === 'warn' ? 'warn' : 'danger'} message={`${r.level === 'ok' ? '✅' : r.level === 'warn' ? '⚠️' : '⛔'} ${r.message}`} />;
}
export function ChequeNoPicker({ accountUid, value, onChange, testID = 'chq', label = 'Cheque number', taken = [] }) {
  let list = [];
  try { list = availableCheques(accountUid).filter((c) => !taken.includes(String(c.no))); } catch (e) { list = []; }
  const inList = list.some((c) => String(c.no) === String(value));
  const [typing, setTyping] = useState(!!value && !inList);
  // Start on the next unused cheque (or the first free one) when nothing is chosen yet.
  useEffect(() => {
    if (!value && !typing && list.length) onChange(String((list.find((c) => c.next) || list[0]).no));
  }, [accountUid, list.length, typing]);
  const options = list.map((c) => ({ value: String(c.no), label: `${c.no}${c.next ? ' · next in the book' : c.skipped ? ' · skipped earlier' : ''}`, hint: `Book ${c.book}` }))
    .concat([{ value: '__type', label: 'Type another number…' }]);
  return (
    <View style={{ gap: 6 }}>
      <Select testID={`${testID}-pick`} label={label} value={typing ? '__type' : String(value || '')} onChange={(v) => { if (v === '__type') { setTyping(true); onChange(''); } else { setTyping(false); onChange(v); } }} options={options} />
      {typing ? <Field testID={`${testID}-no`} label="Type the cheque number" value={String(value || '')} onChangeText={(v) => onChange(String(v).replace(/\D/g, ''))} keyboardType="number-pad" /> : null}
      {typing && value ? <ChequeNoStatus no={value} accountUid={accountUid} testID={`${testID}-status`} /> : null}
      {accountUid && !list.length ? <Banner tone="warn" message="No unused cheques in the books for this account. Add the new cheque book in Cheques & bank › Books, or type the number." /> : null}
    </View>
  );
}
