// Cheques & bank: register, cheque books leaf by leaf, deposits/fees, and the balance check against the statement.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, PhotoPicker, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, ReasonField } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import * as AP from '../service.js';

const { $ } = AP;
const LEAF = { unused: ['#FFFFFF', C.border, 'unused'], written: [C.warnSoft, C.warn, 'not cleared'], presented: [C.successSoft, C.success, 'cleared'], void: ['#EEE', C.sub, 'void'], spoiled: ['#EEE', C.sub, 'spoiled'], skipped: [C.dangerSoft, C.danger, 'SKIPPED'], handed: [C.dangerSoft, C.danger, 'NOT RECORDED'] };

export default function ChequesScreen({ params }) {
  const { user } = useApp();
  const accounts = AP.listAccounts();
  const [acc, setAcc] = useState(params.accountUid || (accounts[0] && accounts[0].uid) || '');
  const [tab, setTab] = useRemembered(params.tab ? `tab-${params.tab}` : 'tab', (accounts.length && params.tab) || (accounts.length ? 'register' : 'accounts'));
  const a = accounts.find((x) => x.uid === acc);
  const bal = a ? AP.bookBalance(a.uid) : null;
  return (
    <Screen title="Cheques & bank" subtitle={a ? `${a.name} · book balance ${$(bal.balance)}` : 'Add your BSP account first'}>
      {accounts.length > 1 ? <Choice value={acc} onChange={setAcc} options={accounts.map((x) => ({ value: x.uid, label: x.name }))} /> : null}
      <Chips value={tab} onChange={setTab} testIDPrefix="chq-tab" options={[{ value: 'register', label: 'Register' }, { value: 'books', label: 'Books' }, { value: 'money', label: 'Deposits & fees' }, { value: 'balance', label: 'Balance check' }, { value: 'accounts', label: 'Accounts' }]} />
      {tab === 'accounts' || !a ? <Accounts user={user} onPick={(u) => { setAcc(u); setTab('books'); }} /> : null}
      {a && tab === 'register' ? <Register a={a} user={user} /> : null}
      {a && tab === 'books' ? <Books a={a} user={user} /> : null}
      {a && tab === 'money' ? <Money a={a} user={user} /> : null}
      {a && tab === 'balance' ? <Balance a={a} user={user} /> : null}
    </Screen>
  );
}

function Accounts({ user, onPick }) {
  const act = useAct();
  const [f, setF] = useState(null);
  const list = AP.listAccounts({ includeInactive: true });
  return (
    <View style={{ gap: 10 }}>
      {list.map((a) => (
        <ListItem key={a.uid} title={a.name} sub={`${a.bank}${a.account_no ? ` · ${a.account_no}` : ''} · opening ${$(a.opening_balance)} on ${a.opening_date}${a.active ? '' : ' · not used'}`}
          right="Change" onPress={() => setF({ uid: a.uid, name: a.name, bank: a.bank, accountNo: a.account_no || '', openingBalance: String(a.opening_balance), openingDate: a.opening_date, active: !!a.active })} />
      ))}
      {f ? (
        <Card>
          <H>{f.uid ? 'Change account' : 'New bank account'}</H>
          <Field testID="acc-name" label="Name" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} placeholder="e.g. BSP Business Cheque" />
          <Field label="Bank" value={f.bank} onChangeText={(v) => setF({ ...f, bank: v })} />
          <Field testID="acc-no" label="Account number (optional)" value={f.accountNo} onChangeText={(v) => setF({ ...f, accountNo: v })} />
          <MoneyField testID="acc-open" label="Balance in the cheque book on the start date" value={f.openingBalance} onChange={(v) => setF({ ...f, openingBalance: v })} />
          <DateField farDays={false} testID="acc-date" label="Start date" value={f.openingDate} onChange={(v) => setF({ ...f, openingDate: v })} />
          <Chips value={f.active} onChange={(v) => setF({ ...f, active: v })} options={[{ value: true, label: 'In use' }, { value: false, label: 'Not used any more' }]} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="acc-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { const r = act(() => AP.saveAccount(user, f), 'Saved'); if (r) { setF(null); onPick(r.uid); } }} />
          </View>
        </Card>
      ) : <Btn testID="acc-add" title="Add a bank account" icon="➕" variant="secondary" onPress={() => setF({ name: '', bank: 'BSP', accountNo: '', openingBalance: '', openingDate: dateStr(), active: true })} />}
    </View>
  );
}

function Register({ a, user }) {
  const act = useAct();
  const [status, setStatus] = useRemembered('status', 'written');
  const [clear, setClear] = useState(null);
  const rows = AP.listCheques({ accountUid: a.uid, status: status || undefined });
  const stale = AP.staleCheques().filter((c) => c.account_uid === a.uid).map((c) => c.uid);
  return (
    <View style={{ gap: 10 }}>
      <Chips value={status} onChange={setStatus} testIDPrefix="reg" options={[{ value: 'written', label: 'Not cleared' }, { value: 'presented', label: 'Cleared' }, { value: '', label: 'All' }]} />
      <Text style={{ fontSize: 15, color: C.sub }}>{rows.length} cheque(s) · {$(rows.reduce((s, c) => s + c.amount, 0))}</Text>
      {rows.map((c) => (
        <View key={c.uid} style={{ gap: 6 }}>
          <ListItem testID={`chq-${c.cheque_no}`} title={`${c.cheque_no} · ${c.payee || '(spoiled)'}`} sub={`${c.cheque_date}${c.presented_date ? ` · cleared ${c.presented_date}${c.presented_by_name ? ` (${c.presented_by_name})` : ''}` : ''}${c.void_reason ? ` · ${c.void_reason}` : ''}`}
            right={$(c.amount)} badge={stale.includes(c.uid) ? 'STALE' : AP.ENTRY_LABEL[c.status] || (c.status === 'written' ? 'not cleared' : c.status)} badgeColor={stale.includes(c.uid) ? C.danger : c.status === 'presented' ? C.success : c.status === 'written' ? C.warn : C.sub}
            onPress={c.status === 'written' || c.status === 'presented' ? () => setClear(clear && clear.uid === c.uid ? null : { uid: c.uid, date: c.presented_date || dateStr(), status: c.status }) : null} />
          {clear && clear.uid === c.uid ? (
            <Card>
              {clear.status === 'written' ? (
                <>
                  <DateField testID="clear-date" label="Date it cleared (from the bank statement)" value={clear.date} onChange={(v) => setClear({ ...clear, date: v })} />
                  <Btn testID="clear-save" title="Mark as cleared" variant="success" style={{ marginTop: 8 }} onPress={() => { if (act(() => AP.markPresented(user, c.uid, clear.date), 'Cleared')) setClear(null); }} />
                </>
              ) : <Btn title="Not cleared after all" variant="secondary" onPress={() => { if (act(() => AP.markPresented(user, c.uid, null), 'Changed')) setClear(null); }} />}
            </Card>
          ) : null}
        </View>
      ))}
    </View>
  );
}

function Books({ a, user }) {
  const act = useAct();
  const { nav } = useApp();
  const books = AP.listBooks(a.uid);
  const [open, setOpen] = useState(books.length ? books[books.length - 1].uid : null);
  const [nb, setNb] = useState(null);
  const [spoil, setSpoil] = useState(null);
  const view = open ? AP.bookLeaves(open) : null;
  return (
    <View style={{ gap: 10 }}>
      <Choice value={open} onChange={setOpen} testIDPrefix="book" options={books.map((b) => ({ value: b.uid, label: `${b.first_no}–${b.last_no}${b.active ? '' : ' (done)'}` }))} />
      {view ? (
        <>
          <Stats items={[{ label: 'Not cleared', value: String(view.written), color: C.warn }, { label: 'Cleared', value: String(view.presented), color: C.success },
            { label: 'Void / spoiled', value: String(view.void + view.spoiled) }, { label: 'Unused', value: String(view.unused) }, view.skipped ? { label: 'Skipped!', value: String(view.skipped), color: C.danger } : null]} />
          {view.skipped ? <Banner tone="danger" title="Numbers skipped" message="These leaves are not recorded but later numbers are. Find each one: record it as spoiled, or enter the payment it was used for." /> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {view.leaves.map((l) => {
              const [bg, border, word] = LEAF[l.status] || LEAF.unused;
              return (
                <Pressable key={l.no} testID={`leaf-${l.no}`} onPress={() => (['unused', 'skipped'].includes(l.status) ? setSpoil({ no: l.no, reason: '' }) : nav.push('ChequeStub', { accountUid: a.uid, chequeNo: l.no }))}
                  style={{ width: 104, padding: 6, borderRadius: 10, borderWidth: 2, borderColor: border, backgroundColor: bg }}>
                  <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{l.no}</Text>
                  <Text style={{ fontSize: 12, color: border === C.border ? C.sub : border, fontWeight: '700' }} numberOfLines={1}>{l.cheque && l.cheque.payee ? l.cheque.payee : word}</Text>
                  {l.cheque && l.cheque.amount ? <Text style={{ fontSize: 12, color: C.text }}>{$(l.cheque.amount)}</Text> : null}
                </Pressable>
              );
            })}
          </View>
          <Text style={{ fontSize: 14, color: C.sub }}>Tap an unused or skipped number to record it as spoiled (torn, written wrongly). Tap a used one to open its stub.</Text>
          {spoil ? (
            <Card tone="warn">
              <H>Cheque {spoil.no} spoiled</H>
              <ReasonField testID="spoil-reason" label="What happened" value={spoil.reason} onChangeText={(v) => setSpoil({ ...spoil, reason: v })} placeholder="e.g. written wrongly, cancelled and kept" />
              <PhotoPicker testID="spoil-photo" label="Photo of the spoiled cheque" required value={spoil.photos || []} onChange={(v) => setSpoil({ ...spoil, photos: v })} paper />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
                <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setSpoil(null)} />
                <Btn testID="spoil-save" title="Record as spoiled" variant="warn" style={{ flex: 1 }} onPress={() => { if (act(() => AP.spoilCheque(user, { accountUid: a.uid, chequeNo: spoil.no, reason: spoil.reason, photos: spoil.photos || [] }), 'Recorded')) setSpoil(null); }} />
              </View>
            </Card>
          ) : null}
        </>
      ) : <Text style={{ fontSize: 16, color: C.sub }}>No cheque books yet.</Text>}
      {nb ? (
        <Card>
          <H>New cheque book</H>
          <Field testID="book-first" label="First cheque number" value={nb.firstNo} onChangeText={(v) => setNb({ ...nb, firstNo: v })} keyboardType="number-pad" />
          <Field testID="book-last" label="Last cheque number" value={nb.lastNo} onChangeText={(v) => setNb({ ...nb, lastNo: v })} keyboardType="number-pad" />
          <DateField farDays={false} label="Received from BSP" value={nb.receivedDate} onChange={(v) => setNb({ ...nb, receivedDate: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setNb(null)} />
            <Btn testID="book-save" title="Add book" variant="success" style={{ flex: 1 }} onPress={() => { const u = act(() => AP.saveBook(user, { ...nb, accountUid: a.uid }), 'Cheque book added'); if (u) { setNb(null); setOpen(u); } }} />
          </View>
        </Card>
      ) : <Btn testID="book-add" title="Add a cheque book" icon="➕" variant="secondary" onPress={() => setNb({ firstNo: '', lastNo: '', receivedDate: dateStr() })} />}
      {view && view.book.active && view.unused === 0 && !view.skipped ? <Btn title="Mark this book as finished" variant="ghost" onPress={() => act(() => AP.saveBook(user, { uid: view.book.uid, accountUid: a.uid, firstNo: view.book.first_no, lastNo: view.book.last_no, receivedDate: view.book.received_date, active: false }), 'Done')} /> : null}
    </View>
  );
}

function Money({ a, user }) {
  const act = useAct();
  const ui = useUI();
  const [f, setF] = useState(null);
  const rows = AP.listBankEntries({ accountUid: a.uid });
  return (
    <View style={{ gap: 10 }}>
      <Text style={{ fontSize: 15, color: C.sub }}>Money in and out of {a.name} other than cheques. Shop deposits from the Till & Cash section appear here by themselves.</Text>
      {f ? (
        <Card>
          <Chips value={f.type} onChange={(v) => setF({ ...f, type: v })} testIDPrefix="be-type" options={['deposit', 'fee', 'interest', 'adjust_in', 'adjust_out'].map((t) => ({ value: t, label: AP.ENTRY_LABEL[t] }))} />
          <MoneyField testID="be-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field label="Reference" value={f.reference} onChangeText={(v) => setF({ ...f, reference: v })} />
          <Field label={f.type.startsWith('adjust') ? 'Reason (required)' : 'Note'} value={f.note} onChangeText={(v) => setF({ ...f, note: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="be-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => AP.addBankEntry(user, { ...f, accountUid: a.uid }), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="be-add" title="Add deposit / fee / correction" icon="➕" variant="secondary" onPress={() => setF({ type: 'deposit', amount: '', date: dateStr(), reference: '', note: '' })} />}
      {rows.map((e) => (
        <ListItem key={e.uid} title={`${AP.ENTRY_LABEL[e.type]}${e.reference ? ` · ${e.reference}` : ''}`} sub={`${e.entry_date} · ${e.by_name || ''}${e.note ? ` · ${e.note}` : ''}${e.cleared_date ? ` · on statement ${e.cleared_date}` : ''}`}
          right={`${['deposit', 'interest', 'adjust_in'].includes(e.type) ? '+' : '−'}${$(e.amount)}`}
          onPress={e.payment_uid ? null : async () => {
            const ok = await ui.confirm({ title: 'Void this entry?', message: `${AP.ENTRY_LABEL[e.type]} ${$(e.amount)} on ${e.entry_date}. It stays in the history as void.`, confirmText: 'Void', tone: 'danger' });
            if (ok) act(() => AP.voidBankEntry(user, e.uid, 'Voided from Deposits & fees'), 'Voided');
          }} />
      ))}
    </View>
  );
}

function Balance({ a, user }) {
  const act = useAct();
  const [date, setDate] = useState(dateStr());
  const [stmt, setStmt] = useState('');
  const [, bump] = useState(0);
  let r = null;
  let err = '';
  if (stmt !== '') { try { r = AP.balanceCheck(a.uid, date, stmt); } catch (e) { err = e.message; } }
  const book = AP.bookBalance(a.uid, date);
  return (
    <View style={{ gap: 10 }}>
      <Card>
        <Row label="Opening balance" value={`${$(book.opening)} (${a.opening_date})`} />
        <Row label="+ Deposits & money in" value={$(book.moneyIn)} />
        <Row label="− Cheques written" value={$(book.cheques)} />
        <Row label="− Transfers & fees" value={$(book.moneyOut)} />
        <Row label={`Cheque book balance on ${date}`} value={$(book.balance)} bold />
      </Card>
      <Card>
        <H>Check against the bank statement</H>
        <DateField testID="bal-date" label="Statement date" value={date} onChange={setDate} />
        <MoneyField testID="bal-stmt" label="Closing balance on the statement" value={stmt} onChange={setStmt} />
        {err ? <Text style={{ color: C.danger }}>{err}</Text> : null}
      </Card>
      {r ? (
        <>
          <Banner testID="bal-result" tone={r.balanced ? 'success' : 'danger'} title={r.balanced ? 'Balanced ✓' : `Out by ${$(r.difference)}`}
            message={r.balanced ? 'The cheque book agrees with the bank statement.' : 'Tick the cheques and entries that ARE on the statement. What is left is the difference to look for (missing deposit, bank fee, wrong amount).'} />
          <Card>
            <Row label="Cheque book balance" value={$(r.balance)} />
            <Row label="+ Cheques not cleared yet" value={$(r.chequesOut)} />
            <Row label="− Deposits not on the statement yet" value={$(r.depositsInTransit)} />
            <Row label="+ Transfers / fees not on the statement yet" value={$(r.otherOut)} />
            <Row label="= Statement should show" value={$(r.expected)} bold />
            <Row label="Statement shows" value={$(r.statementBalance)} bold />
            <Row label="Difference" value={$(r.difference)} bold color={r.balanced ? C.success : C.danger} />
          </Card>
          <Section title="Tick what is on the statement">
            {r.notCleared.map((c) => (
              <ListItem key={c.uid} testID={`bal-chq-${c.cheque_no}`} title={`Cheque ${c.cheque_no} · ${c.payee}`} sub={c.cheque_date} right={$(c.amount)} badge="tap if cleared" badgeColor={C.warn}
                onPress={() => { act(() => AP.markPresented(user, c.uid, date)); bump((n) => n + 1); }} />
            ))}
            {r.entriesNotCleared.map((e) => (
              <ListItem key={e.uid} testID={`bal-be-${e.uid}`} title={`${AP.ENTRY_LABEL[e.type]}${e.reference ? ` · ${e.reference}` : ''}`} sub={e.entry_date} right={$(e.amount)} badge="tap if on statement" badgeColor={C.info}
                onPress={() => { act(() => AP.setEntryCleared(user, e.uid, date)); bump((n) => n + 1); }} />
            ))}
            {!r.notCleared.length && !r.entriesNotCleared.length ? <Text style={{ fontSize: 16, color: C.sub }}>Everything is on the statement.</Text> : null}
          </Section>
        </>
      ) : null}
    </View>
  );
}
