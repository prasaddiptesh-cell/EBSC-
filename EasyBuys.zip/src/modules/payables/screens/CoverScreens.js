// v3.9.2 Cheques to cover: every cheque not yet paid by the bank, and whether a deposit covers it. Tick some and make
// the deposit for them; the deposit screen links them (extra money in the deposit is fine).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Row, Section, Field, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, Explain, Stats } from '../../../ui/kit.js';
import { money } from '../../../services/core.js';
import { can } from '../../../services/access.js';
import * as CV from '../cover.js';

const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);
const STATE = { handed: 'Handed over', post_dated: 'Post-dated', prepared: 'Not handed over yet' };

function ChequeLine({ c, ticked, onTick, nav }) {
  const tone = c.level === 'urgent' ? 'danger' : c.level === 'warning' ? 'warn' : undefined;
  const when = c.state === 'handed' ? `handed ${c.handed}${c.handedTo ? ` to ${c.handedTo}` : ''}${c.sinceHanded ? ` · ${c.sinceHanded} day${c.sinceHanded === 1 ? '' : 's'} ago` : ' · today'}`
    : c.state === 'post_dated' ? `dated ${c.date}${c.toDate > 0 ? ` · in ${c.toDate} day${c.toDate === 1 ? '' : 's'}` : ' · due now'}${c.handed ? ' · handed over' : ''}` : `written ${c.date}`;
  return (
    <ListItem testID={`cv-${c.no}`} title={`${onTick ? (ticked ? '☑️ ' : '⬜ ') : ''}Cheque ${c.no} · ${c.payee || ''} · ${$(c.amount)}`}
      sub={`${when}${c.covered ? ` · covered ${$(c.covered)}${c.deposits.length ? ` (slip ${c.deposits.map((d) => d.slip_no).join(', ')})` : ''}` : ''}`}
      right={c.left > 0.004 ? `needs ${$(c.left)}` : '✓ covered'} tone={tone} onPress={onTick ? () => onTick(c) : () => nav.push('ChequeStub', { accountUid: c.accountUid, chequeNo: c.no })} />
  );
}

export function ChequeCoverScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const [ticked, setTicked] = useState({});
  const p = CV.coverPicture();
  const rules = CV.coverRules();
  const mayDeposit = can(user, 'deposits');
  const tick = (c) => setTicked((o) => { const x = { ...o }; if (x[c.uid]) delete x[c.uid]; else x[c.uid] = c.left; return x; });
  const tickedList = p.cheques.filter((c) => ticked[c.uid]);
  const tickedTotal = tickedList.reduce((s, c) => s + c.left, 0);
  const t = (c) => (mayDeposit && c.left > 0.004 ? tick : null);
  return (
    <Screen title="Cheques to cover" subtitle="Every cheque not yet paid by the bank, and the deposit behind it"
      footer={mayDeposit && tickedList.length ? <Btn testID="cv-deposit" title={`Make a deposit for these · ${$(tickedTotal)}`} icon="🏦" variant="success"
        onPress={() => nav.push('Deposit', { covers: tickedList.map((c) => ({ chequeUid: c.uid, amount: c.left })) })} /> : null}>
      <Explain>
        A cheque reaches the bank a few days after it is handed over – or on its date if it is post-dated. Make a deposit to cover it before then.
        On the deposit screen, tick the cheques the deposit is for (extra money in the deposit is fine). Red: handed over {rules.urgentAfterDays}+ days ago with no deposit, or a post-dated cheque due now.
        Tick cheques here and tap "Make a deposit for these".
      </Explain>
      {p.accounts.map((a) => (
        <Card key={a.uid} tone={a.short > 0 ? 'danger' : undefined}>
          <H>{a.name}</H>
          <Row label="Cheques still out" value={$(a.chequesOut)} />
          <Row label="Not covered by a deposit" value={$(a.uncovered)} color={a.uncovered > 0.004 ? C.warn : C.success} />
          {(a.loans || []).map((l) => <Row key={l.invoiceUid} label={`${l.name} – the bank takes it ${l.due}${l.overdue ? ' (due already)' : ''}`} value={$(l.amount)} color={C.warn} />)}
          {a.afterAll !== null ? <Row label={a.loansDue > 0 ? 'Left after every cheque, loan repayment and deposit clears' : 'Left after every cheque and deposit clears'} value={$(a.afterAll)} bold color={a.short > 0 ? C.danger : C.success} /> : null}
          {a.short > 0 ? <Banner testID={`cv-short-${a.uid}`} tone="danger" message={`Short ${$(a.short)} for the cheques out. Deposit before they reach the bank, or hold a cheque back.`} /> : null}
        </Card>
      ))}
      <Stats items={[{ label: 'Need cover now', value: String(p.needNow.length), color: p.needNow.length ? C.danger : C.success },
        { label: 'Post-dated', value: String(p.postDated.length) }, { label: 'Not handed over', value: String(p.prepared.length) }, { label: 'Covered', value: String(p.covered.length), color: C.success }]} />
      <Section title={`Handed over – no deposit yet (${p.needNow.length})`}>
        {!p.needNow.length ? <Text style={{ fontSize: 16, color: C.sub }}>Every cheque handed over is covered.</Text> : null}
        {p.needNow.map((c) => <ChequeLine key={c.uid} c={c} ticked={!!ticked[c.uid]} onTick={t(c)} nav={nav} />)}
      </Section>
      <Section title={`Post-dated (${p.postDated.length})`}>
        {!p.postDated.length ? <Text style={{ fontSize: 16, color: C.sub }}>No post-dated cheques.</Text> : null}
        {p.postDated.map((c) => <ChequeLine key={c.uid} c={c} ticked={!!ticked[c.uid]} onTick={t(c)} nav={nav} />)}
      </Section>
      <Section title={`Written, not handed over yet (${p.prepared.length})`}>
        {!p.prepared.length ? <Text style={{ fontSize: 16, color: C.sub }}>None.</Text> : null}
        {p.prepared.map((c) => <ChequeLine key={c.uid} c={c} ticked={!!ticked[c.uid]} onTick={t(c)} nav={nav} />)}
      </Section>
      {p.covered.length ? (
        <Section title={`Covered – waiting for the bank (${p.covered.length})`}>
          {p.covered.map((c) => <ChequeLine key={c.uid} c={c} nav={nav} />)}
        </Section>
      ) : null}
      <Hint>A cheque leaves this list when the bank statement shows it paid (Bank reconciliation) or it is marked cleared in the cheque register.</Hint>
      {['owner', 'admin'].includes(user.role) ? <CoverRulesCard ui={ui} user={user} /> : null}
    </Screen>
  );
}
function CoverRulesCard({ ui, user }) {
  const [f, setF] = useState(() => { const r = CV.coverRules(); return { urgentAfterDays: String(r.urgentAfterDays), postDatedRemindDays: String(r.postDatedRemindDays) }; });
  return (
    <Card>
      <H>Settings</H>
      <Field testID="cv-urgent" label="Red when a cheque handed over has no deposit after (days)" value={f.urgentAfterDays} onChangeText={(v) => setF((o) => ({ ...o, urgentAfterDays: v }))} keyboardType="number-pad" />
      <Field testID="cv-remind" label="Remind before a post-dated cheque's date (days)" value={f.postDatedRemindDays} onChangeText={(v) => setF((o) => ({ ...o, postDatedRemindDays: v }))} keyboardType="number-pad" />
      <Btn testID="cv-rules-save" title="Save" size="md" variant="secondary" onPress={() => { try { CV.saveCoverRules(user, f); ui.toast('Saved'); } catch (e) { ui.error(e); } }} />
    </Card>
  );
}

// The "What is this deposit covering?" part of the deposit screen.
export function DepositCoverPicker({ accountUid, value = [], onChange, depositTotal }) {
  const [showInv, setShowInv] = useState(false);
  let ch = { cheques: [], invoices: [] };
  try { ch = CV.coverChoices({ accountUid }); } catch (e) { ch = { cheques: [], invoices: [] }; }
  const sel = (key, uid) => value.find((x) => x[key] === uid);
  const toggle = (key, uid, left) => { if (sel(key, uid)) onChange(value.filter((x) => x[key] !== uid)); else onChange(value.concat([{ [key]: uid, amount: left }])); };
  const setAmt = (key, uid, v) => onChange(value.map((x) => (x[key] === uid ? { ...x, amount: v } : x)));
  const sum = value.reduce((s, x) => s + (Number(x.amount) || 0), 0);
  const line = (key, uid, title, sub, left, tone, testID) => {
    const s = sel(key, uid);
    return (
      <View key={uid} style={{ gap: 4 }}>
        <ListItem testID={testID} title={`${s ? '☑️' : '⬜'} ${title}`} sub={sub} right={`needs ${$(left)}`} tone={tone} onPress={() => toggle(key, uid, left)} />
        {s ? <Field testID={`${testID}-amt`} label="Amount of this deposit for it" value={String(s.amount)} onChangeText={(v) => setAmt(key, uid, v.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" /> : null}
      </View>
    );
  };
  return (
    <View style={{ gap: 6 }}>
      <H>What is this deposit covering?</H>
      <Hint>Tick the cheques (or invoices about to be paid by cheque) this money is for. Any extra in the deposit is fine – it is general money.</Hint>
      {!ch.cheques.length ? <Text style={{ fontSize: 15, color: C.sub }}>No cheques waiting for cover.</Text> : null}
      {ch.cheques.map((c) => line('chequeUid', c.uid, `Cheque ${c.no} · ${c.payee || ''}`, `${STATE[c.state]}${c.state === 'post_dated' ? ` · dated ${c.date}` : c.handed ? ` · ${c.handed}` : ''}`, c.left, c.level === 'urgent' ? 'danger' : c.level === 'warning' ? 'warn' : undefined, `dc-chq-${c.no}`))}
      {ch.invoices.length ? <Btn testID="dc-show-inv" title={showInv ? 'Hide invoices' : `Invoices not paid yet (${ch.invoices.length})`} size="sm" variant="ghost" onPress={() => setShowInv(!showInv)} /> : null}
      {showInv ? ch.invoices.slice(0, 40).map((i) => line('invoiceUid', i.uid, `Invoice ${i.invoiceNo || '?'} · ${i.supplier}`, `due ${i.due || '—'}`, i.left, undefined, `dc-inv-${i.uid}`)) : null}
      {value.length ? <Banner testID="dc-sum" tone={sum > (Number(depositTotal) || 0) + 0.004 ? 'danger' : 'info'} message={`Covering ${$(sum)} of this ${$(depositTotal)} deposit${sum > (Number(depositTotal) || 0) + 0.004 ? ' – more than the deposit! Lower the amounts.' : (Number(depositTotal) || 0) - sum > 0.004 ? ` · ${$((Number(depositTotal) || 0) - sum)} general` : ''}.`} /> : null}
    </View>
  );
}
