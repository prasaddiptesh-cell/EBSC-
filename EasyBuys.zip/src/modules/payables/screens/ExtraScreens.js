// Payment run (pay many suppliers at once) and supplier statement check.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import * as AP from '../service.js';
import * as X from '../extras.js';

const { $ } = AP;

export function PayRunScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const [dueBy, setDueBy] = useState(addDays(dateStr(), AP.apRules().dueSoonDays));
  const [method, setMethod] = useState('cheque');
  const accounts = AP.listAccounts();
  const [acc, setAcc] = useState(accounts[0] ? accounts[0].uid : '');
  const [date, setDate] = useState(dateStr());
  const [picked, setPicked] = useState({});
  const groups = X.payRunCandidates({ dueBy });
  const isOn = (inv) => picked[inv.uid] === undefined ? !inv.blocked && inv.due !== 'not_due' : picked[inv.uid];
  const chosen = groups.map((g) => ({ ...g, ids: g.invoices.filter((i) => !i.blocked && isOn(i)).map((i) => i.uid) })).filter((g) => g.ids.length);
  const total = chosen.reduce((s, g) => s + g.invoices.filter((i) => g.ids.includes(i.uid)).reduce((t, i) => t + i.owing, 0), 0);
  const next = acc && method === 'cheque' ? AP.nextChequeNo(acc) : null;
  const pay = () => {
    try {
      const done = X.payRun(user, { accountUid: acc, method, date, items: chosen.map((g) => ({ supplierUid: g.supplierUid, invoiceUids: g.ids })) });
      ui.alert({ title: 'Paid', message: done.map((p) => `${p.supplier_name}: ${$(p.amount)}${p.cheque_no ? ` – cheque ${p.cheque_no}` : ''}`).join('\n') });
      setPicked({});
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Pay many suppliers" subtitle="Payment run"
      footer={<Btn testID="pr-pay" title={`Pay ${chosen.length} supplier(s) · ${$(total)}`} icon="💸" variant="success" disabled={!chosen.length} onPress={pay} />}>
      <Hint>Everything due up to the date below, grouped by supplier. Untick anything you do not want to pay now. Invoices not checked yet cannot be paid.</Hint>
      <DateField label="Due up to" value={dueBy} onChange={setDueBy} />
      <Chips value={method} onChange={setMethod} testIDPrefix="pr-m" options={[{ value: 'cheque', label: 'Cheques' }, { value: 'transfer', label: 'Bank transfers' }]} />
      <Select label="Bank account" value={acc} onChange={setAcc} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} />
      {method === 'cheque' ? <Hint>{next ? `Cheques will be numbered from ${next}, one per supplier.` : 'No cheque leaves left – add a cheque book first.'}</Hint> : null}
      <DateField label="Payment date" value={date} onChange={setDate} />
      {!groups.length ? <Text style={{ color: C.sub }}>Nothing due.</Text> : null}
      {groups.map((g) => (
        <Card key={g.supplierUid}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{g.name}</Text>
          {g.invoices.map((i) => (
            <Pressable key={i.uid} testID={`pr-inv-${i.invoice_no}`} disabled={!!i.blocked} onPress={() => setPicked({ ...picked, [i.uid]: !isOn(i) })} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 6 }}>
              <Text style={{ fontSize: 22 }}>{i.blocked ? '⛔' : isOn(i) ? '☑' : '☐'}</Text>
              <Text style={{ flex: 1, fontSize: 16, color: i.blocked ? C.sub : C.text }}>{i.invoice_no || 'no number'} · {i.invoice_date} · due {i.due_date}{i.blocked ? ` · ${i.blocked}` : ''}</Text>
              <Text style={{ fontSize: 16, fontWeight: '800', color: i.due === 'overdue' ? C.danger : C.text }}>{$(i.owing)}</Text>
            </Pressable>
          ))}
        </Card>
      ))}
    </Screen>
  );
}

export function StatementCheckScreen() {
  const { user } = useApp();
  const ui = useUI();
  const sups = AP.listSuppliers();
  const [sup, setSup] = useState('');
  const [date, setDate] = useState(dateStr());
  const [bal, setBal] = useState('');
  const [note, setNote] = useState('');
  const [photos, setPhotos] = useState([]);
  const [res, setRes] = useState(null);
  const past = sup ? X.listStatements(sup) : [];
  return (
    <Screen title="Check a supplier statement" subtitle="Does their balance agree with ours?">
      <Explain>Most suppliers send a statement each month showing what they say we owe. Type their closing balance here. If it does not agree with what the app shows, the app suggests the likely reason – an invoice missing or entered twice, or a payment they have not yet received.</Explain>
      <Select testID="st-sup" label="Supplier" value={sup} onChange={(v) => { setSup(v); setRes(null); }} options={[{ value: '', label: 'Choose' }].concat(sups.map((x) => ({ value: x.uid, label: x.name })))} />
      {sup ? <Hint>{`We show ${$(X.ourBalance(sup, date))} owing on ${date}.`}</Hint> : null}
      <DateField label="Statement date" value={date} onChange={setDate} />
      <MoneyField testID="st-bal" label="Balance on their statement" value={bal} onChange={setBal} />
      <Field label="Note" value={note} onChangeText={setNote} />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo of the statement (optional)" />
      <Btn testID="st-check" title="Check" icon="🔍" variant="success" onPress={() => { try { setRes(X.checkStatement(user, { supplierUid: sup, date, theirBalance: bal, note, photos })); } catch (e) { ui.error(e); } }} />
      {res ? (
        <Card tone={Math.abs(res.diff) < 0.005 ? 'success' : 'warn'}>
          <Row label="Their statement" value={$(res.theirs)} />
          <Row label="Our records" value={$(res.ours)} />
          <Row label="Difference" value={Math.abs(res.diff) < 0.005 ? 'Agrees ✓' : $(res.diff)} bold color={Math.abs(res.diff) < 0.005 ? C.success : C.danger} />
          {res.hints.map((h) => <Text key={h} style={{ fontSize: 15, color: C.text }}>• {h}</Text>)}
        </Card>
      ) : null}
      {past.length ? <Section title="Earlier checks">{past.map((p) => <ListItem key={p.uid} title={p.statement_date} sub={`theirs ${$(p.their_balance)} · ours ${$(p.our_balance)} · by ${p.by_name}`} right={Math.abs(p.diff) < 0.005 ? 'agrees' : $(p.diff)} />)}</Section> : null}
    </Screen>
  );
}
