// Invoices: the overview, the list, entering / changing an invoice, and one invoice with its pay trail.
import { db } from '../../../db/connection.js';
import { FixButton } from '../../admin/screens/RecordFixScreen.js';
import React, { useState } from 'react';
import { payMethods } from '../payMethods.js';
import { View, Image, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, TONE, Hint, Action, Actions, Explain, ReasonField } from '../../../ui/kit.js';
import { invoiceWarnings } from '../extras.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { CLOSED_OPTION } from '../../../services/costAreas.js';
import * as AP from '../service.js';
import { readInvoiceNow } from '../../../platform/cloud.js';
import { offerPdf } from '../../../ui/shareDoc.js';
import { invoiceDoc } from '../../../services/taskDocs.js';

const { $ } = AP;
const METHOD = { cheque: 'Cheque', cash: 'Cash', transfer: 'Bank transfer', credit: 'Credit note' };

function dueText(i) {
  if (i.due === 'overdue') return `Overdue ${-i.daysToDue} day${i.daysToDue === -1 ? '' : 's'}`;
  if (i.due === 'due_soon') return `Due in ${i.daysToDue} day${i.daysToDue === 1 ? '' : 's'}`;
  return AP.DUE_LABEL[i.due];
}
export function InvoiceRow({ i, onPress }) {
  return (
    <ListItem testID={`inv-${i.invoice_no || i.uid}`} onPress={onPress}
      title={`${i.supplier_name}${i.invoice_no ? ` · ${i.invoice_no}` : ''}`}
      sub={`${i.kind === 'credit' ? 'Credit note · ' : ''}${i.invoice_date} · due ${i.due_date}${i.on_account ? ' · on account' : ''}${i.status === 'to_check' ? ' · to check' : ''}${i.partPaid ? ` · PART PAID ${$(i.paid)}` : ''}`}
      right={i.total ? $(i.due === 'paid' ? i.total : i.owing) : '—'} rightSub={i.partPaid ? `of ${$(i.total)}` : null}
      badge={dueText(i)} badgeColor={TONE[i.due]} tone={i.due === 'overdue' ? 'danger' : i.due === 'due_today' ? 'warn' : undefined} />
  );
}

// ---------------------------------------------------------------- overview
export function PayablesHomeScreen() {
  const { nav, can } = useApp();
  const a = AP.apAlerts();
  const due = AP.listInvoices({ filter: 'due' }).slice(0, 30);
  return (
    <Screen title="Invoices & cheques" subtitle={`Owing to suppliers: ${$(a.owingTotal)}`}>
      <Stats items={[
        { label: 'Overdue', value: $(a.overdue.amount), sub: `${a.overdue.n} invoice(s)`, color: a.overdue.n ? C.danger : C.success, onPress: () => nav.push('ApInvoices', { filter: 'overdue' }), testID: 'ap-overdue' },
        { label: 'Due today', value: $(a.dueToday.amount), sub: `${a.dueToday.n} invoice(s)`, color: a.dueToday.n ? C.warn : undefined, onPress: () => nav.push('ApInvoices', { filter: 'due' }) },
        { label: `Due in ${AP.apRules().dueSoonDays} days`, value: $(a.dueSoon.amount), sub: `${a.dueSoon.n} invoice(s)`, color: a.dueSoon.n ? C.warn : undefined, onPress: () => nav.push('ApInvoices', { filter: 'due' }) },
        { label: 'To check', value: String(a.toCheck), sub: a.toRead ? `${a.toRead} waiting to be read` : 'entered, not checked', color: a.toCheck ? C.info : undefined, onPress: () => nav.push('ApInvoices', { filter: 'to_check' }) },
      ]} />
      {a.stale ? <Banner tone="warn" title={`${a.stale} cheque(s) not cleared for over ${AP.apRules().staleMonths} months`} message="Check with the supplier; open Cheques › Register." /> : null}
      {a.skipped ? <Banner tone="danger" title={`${a.skipped} cheque number(s) skipped`} message="A leaf in the cheque book was not recorded. Open Cheques › Books to find it and record it (spoiled or written)." /> : null}
      <Section title="Every day">
        <Actions>
          {can('invoices_enter') ? <Action testID="ap-new" icon="📷" title="New invoice" note="Take a photo of a supplier invoice. Google reads it; you check the supplier, number and total." onPress={() => nav.push('ApInvoiceEdit', {})} /> : null}
          {can('payments_make') ? <Action testID="ap-pay" icon="💸" title="Pay a supplier" note="Tick the invoices to pay and choose cheque, cash or bank transfer. The cheque number comes from the cheque book." onPress={() => nav.push('ApPay', {})} /> : null}
          {can('payments_make') ? <Action testID="ap-payrun" icon="🗂️" title="Pay many at once" note="A payment run: everything due, all suppliers on one screen, cheques numbered in order." onPress={() => nav.push('ApPayRun', {})} /> : null}
          <Action testID="ap-all" icon="🧾" title="All invoices" note="Search by supplier or number; unpaid, overdue, to check, paid, credit notes." onPress={() => nav.push('ApInvoices', { filter: 'unpaid' })} />
        </Actions>
      </Section>
      <Section title="Office">
        <Actions>
          {can('payments_make') ? <Action icon="📒" title="Payments made" note="Every payment with the invoices it paid (the pay trail)." onPress={() => nav.push('ApPayments')} /> : null}
          {can('cheques_manage') ? <Action testID="ap-cheques" icon="🏦" title="Cheques & bank" note="Bank accounts, cheque books, which cheques have cleared, balance check." onPress={() => nav.push('Cheques', {})} /> : null}
          {can('payments_make') ? <Action testID="ap-statement" icon="📑" title="Check a supplier statement" note="Type the balance from the supplier's monthly statement; the app shows if it agrees and why not." onPress={() => nav.push('ApStatement', {})} /> : null}
          {can('ap_setup') || can('invoices_check') ? <Action testID="ap-suppliers" icon="🏷️" title="Suppliers" note="Names, TIN, VAT registered, on account and how many days to pay." onPress={() => nav.push('ApSuppliers')} /> : null}
        </Actions>
      </Section>
      {can('ap_setup') ? (
        <Section title="Setup">
          <Actions>
            <Action icon="🔁" title="Regular bills & loans" note="Rent, power, loan repayments: made as invoices by themselves each period." onPress={() => nav.push('Recurring')} />
            <Action testID="ap-rules" icon="⚙️" title="Invoice rules" note="VAT rate, days to pay, check before paying, photo required, categories." onPress={() => nav.push('ApRules')} />
          </Actions>
        </Section>
      ) : null}
      <Section title="Due and overdue">
        {!due.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing due in the next {AP.apRules().dueSoonDays} days. 👍</Text> : null}
        {due.map((i) => <InvoiceRow key={i.uid} i={i} onPress={() => nav.push('ApInvoice', { uid: i.uid })} />)}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- list
const FILTERS = [['unpaid', 'Unpaid'], ['due', 'Due'], ['overdue', 'Overdue'], ['part', 'Part paid'], ['to_check', 'To check'], ['paid', 'Paid'], ['credits', 'Credits'], ['void', 'Void'], ['all', 'All']];
export function InvoiceListScreen({ params }) {
  const { nav } = useApp();
  const [filter, setFilter] = useRemembered('filter', params.filter || 'unpaid');
  const [q, setQ] = useRemembered('q', '');
  const [shop, setShop] = useRemembered('shop', '');
  const rows = AP.listInvoices({ filter, q, shopCode: shop || undefined, supplierUid: params.supplierUid });
  const total = rows.reduce((s, i) => s + (filter === 'paid' || filter === 'all' || filter === 'void' ? i.total : i.owing), 0);
  return (
    <Screen title="Invoices" subtitle={`${rows.length} · ${$(total)}`}>
      <Chips value={filter} onChange={setFilter} testIDPrefix="inv-filter" options={FILTERS.map(([value, label]) => ({ value, label }))} />
      <Field testID="inv-search" label="Search supplier or invoice number" value={q} onChangeText={setQ} />
      <Chips value={shop} onChange={setShop} options={[{ value: '', label: 'All shops' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      {rows.map((i) => <InvoiceRow key={i.uid} i={i} onPress={() => nav.push('ApInvoice', { uid: i.uid })} />)}
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>No invoices here.</Text> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- enter / change
export function InvoiceEditScreen({ params }) {
  const { nav, realUser: user, can } = useApp();
  const ui = useUI();
  const act = useAct();
  const rules = AP.apRules();
  const before = params.uid ? AP.getInvoice(params.uid) : null;
  const sup0 = before && before.supplier_uid ? AP.getSupplier(before.supplier_uid) : null;
  const [f, setF] = useState(() => ({
    kind: before ? before.kind : params.kind || 'invoice', supplierUid: before ? before.supplier_uid : params.supplierUid || '', supplierName: '',
    invoiceNo: before ? before.invoice_no || '' : '', invoiceDate: before ? before.invoice_date : dateStr(), shopCode: before ? before.shop_code || '' : user.shop_code || '',
    onAccount: before ? !!before.on_account : undefined, dueDate: before ? before.due_date : '', total: before && before.total ? String(before.total) : '',
    vatType: before ? before.vat_type : (sup0 && !sup0.vat_registered ? 'zero' : 'standard'), vat: before ? String(before.vat) : '', zeroRated: before ? String(before.zero_rated || '') : '',
    category: before ? before.category || '' : '', description: before ? before.description || '' : '', notes: before ? before.notes || '' : '',
  }));
  const [photos, setPhotos] = useState([]);
  const ip = usePaper('invoice');
  const INV_MAP = { supplierUid: 'supplierUid', newSupplierName: 'supplierName', invoiceNo: 'invoiceNo', date: 'invoiceDate', total: 'total', vat: 'vat' };
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const suppliers = AP.listSuppliers();
  const sup = suppliers.find((s) => s.uid === f.supplierUid);
  const onAccount = f.onAccount === undefined ? !!(sup && sup.on_account) : f.onAccount;
  const total = Number(f.total) || 0;
  let vatPreview = null;
  try { vatPreview = total ? AP.workOutVat({ total, vatType: f.vatType, vat: f.vat, zeroRated: f.zeroRated }, rules.vatRate) : null; } catch (e) { vatPreview = { error: e.message }; }

  const save = async (allowDuplicate = false) => {
    if (!ip.okToSave(ui)) return;
    try {
      const inv = AP.saveInvoice(user, { ...f, uid: before ? before.uid : undefined, onAccount }, { photos, allowDuplicate, canCheck: can('invoices_check') });
      ip.log(user, 'ap_invoices', inv.uid, f, INV_MAP);
      ui.toast(inv.ocr_status === 'waiting' ? 'Saved – it will be read when online' : 'Saved');
      nav.replace('ApInvoice', { uid: inv.uid });
      if (!before) offerPdf(ui, () => invoiceDoc(inv.uid));
    } catch (e) {
      if (e.duplicate) {
        const go = await ui.confirm({ title: 'Already entered?', message: `${e.message}\n\nSave it anyway?`, confirmText: 'Save anyway', tone: 'warn' });
        if (go) save(true);
      } else ui.error(e);
    }
  };

  const saveAndRead = async () => {
    let inv;
    try { inv = AP.saveInvoice(user, { ...f, onAccount }, { photos, canCheck: can('invoices_check') }); } catch (e) { ui.error(e); return; }
    ui.toast('Reading the photo…');
    const r = await readInvoiceNow(inv.uid);
    if (!r.ok) await ui.alert({ title: 'Saved, but not read yet', message: r.message, tone: 'warn' });
    nav.replace(r.ok ? 'ApInvoiceEdit' : 'ApInvoice', { uid: inv.uid });
  };
  return (
    <Screen title={before ? 'Change invoice' : f.kind === 'credit' ? 'New credit note' : 'New invoice'} subtitle={before ? `${before.supplier_name} ${before.invoice_no || ''}` : 'Photo first, then the details'}
      footer={!total && photos.length && !before ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Btn testID="inv-save" title="Save – read later" icon="💾" variant="secondary" style={{ flex: 1 }} onPress={() => save()} />
          <Btn testID="inv-save-read" title="Save and read now" icon="🔍" variant="success" style={{ flex: 1 }} onPress={() => saveAndRead()} />
        </View>
      ) : <Btn testID="inv-save" title="Save" icon="💾" variant="success" onPress={() => save()} />}>
      {!before ? <Chips value={f.kind} onChange={set('kind')} testIDPrefix="inv-kind" options={[{ value: 'invoice', label: '🧾 Invoice' }, { value: 'credit', label: '↩️ Credit note' }]} /> : null}
      <Card>
        <PaperPhoto pr={ip} testID="inv-photo" label="Photo of every page" value={photos} onChange={setPhotos} required={rules.requirePhoto} form={f} setForm={setF} map={INV_MAP} soft={{ invoiceDate: dateStr() }}
          labels={{ supplierUid: 'Supplier', supplierName: 'New supplier name', invoiceNo: 'Invoice number', invoiceDate: 'Invoice date', total: 'Total', vat: 'VAT' }}
          display={(k, v) => (k === 'supplierUid' ? ((suppliers.find((x) => x.uid === v) || {}).name || v) : undefined)}
          hint="Scan the invoice, then type the supplier, number, date, total and VAT – or ask the AI to read it." />
        {before && before.photos.length ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 6 }}>{before.photos.length} photo(s) already saved.</Text> : null}
        {!before ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 6 }}>In a hurry? Take the photo and tap Save: {rules.readPhotos ? 'Google reads it when there is internet and ' : ''}someone checks it later.</Text> : null}
      </Card>
      <Card>
        <H>Supplier</H>
        <Select testID="inv-supplier" label="Supplier" value={f.supplierUid} onChange={(v) => { const s = suppliers.find((x) => x.uid === v); setF((o) => ({ ...o, supplierUid: v, onAccount: undefined, dueDate: '', vatType: s && !s.vat_registered ? 'zero' : o.vatType, category: o.category || (s && s.category) || '' })); }}
          options={suppliers.map((s) => ({ value: s.uid, label: s.name, hint: `${s.on_account ? `On account, ${s.terms_days} days` : 'Cash'}${s.tin ? ` · TIN ${s.tin}` : ''}` }))} />
        {!f.supplierUid ? <Field testID="inv-newsupplier" label="…or a new supplier name" value={f.supplierName} onChangeText={set('supplierName')} /> : null}
      </Card>
      <Card>
        <H>Invoice</H>
        <Field testID="inv-no" label={f.kind === 'credit' ? 'Credit note number' : 'Invoice number'} value={f.invoiceNo} onChangeText={set('invoiceNo')} />
        <DateField testID="inv-date" label="Invoice date" value={f.invoiceDate} onChange={set('invoiceDate')} />
        <Label>Shop</Label>
        <Chips value={f.shopCode} onChange={set('shopCode')} testIDPrefix="inv-shop" options={[{ value: '', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') }))).concat([CLOSED_OPTION])} />
        {f.kind === 'invoice' ? (
          <>
            <Label>Payment</Label>
            <Chips value={onAccount} onChange={(v) => setF((o) => ({ ...o, onAccount: v, dueDate: '' }))} testIDPrefix="inv-account"
              options={[{ value: false, label: 'Pay now' }, { value: true, label: `On account${sup ? ` (${sup.terms_days} days)` : ''}` }]} />
            {!onAccount ? (
              <Chips value={f.payMethod || (sup && sup.pay_method) || 'cheque'} onChange={set('payMethod')} testIDPrefix="inv-paywith"
                options={payMethods().map((m) => ({ value: m.id, label: `${m.icon || ''} ${m.label}`.trim() }))} />
            ) : null}
            {onAccount ? <DateField testID="inv-due" label="Due date (blank = from the supplier's terms)" value={f.dueDate} onChange={set('dueDate')} /> : null}
          </>
        ) : null}
      </Card>
      <Card>
        <H>Amount</H>
        <MoneyField testID="inv-total" label="Total including VAT" value={f.total} onChange={set('total')} />
        <Label>VAT</Label>
        <Chips value={f.vatType} onChange={set('vatType')} testIDPrefix="inv-vat"
          options={[{ value: 'standard', label: `All at ${rules.vatRate}%` }, { value: 'zero', label: 'Zero-rated / no VAT' }, { value: 'mixed', label: 'Mixed' }]} />
        {f.vatType === 'mixed' ? (
          <>
            <MoneyField label="Zero-rated part (incl. in total)" value={f.zeroRated} onChange={set('zeroRated')} />
            <MoneyField label="VAT shown on the invoice (blank = work it out)" value={f.vat} onChange={set('vat')} />
          </>
        ) : null}
        {vatPreview ? (vatPreview.error ? <Text style={{ color: C.danger, fontSize: 15 }}>{vatPreview.error}</Text>
          : <Text testID="inv-vat-preview" style={{ fontSize: 16, color: C.sub }}>VAT {$(vatPreview.vat)} · zero-rated {$(vatPreview.zeroRated)} · before VAT {$(total - vatPreview.vat)}</Text>) : null}
      </Card>
      <Card>
        <Select label="Category" value={f.category} onChange={set('category')} options={[{ value: '', label: '—' }].concat(rules.categories.map((c) => ({ value: c, label: c })))} />
        <Field label="What was bought (optional)" value={f.description} onChangeText={set('description')} />
        <Field label="Notes (optional)" value={f.notes} onChangeText={set('notes')} multiline />
      </Card>
      {act && null}
    </Screen>
  );
}

// ---------------------------------------------------------------- one invoice
export function InvoiceViewScreen({ params }) {
  const { nav, realUser: user, can, refresh } = useApp();
  const ui = useUI();
  const act = useAct();
  const [voiding, setVoiding] = useState(null);
  const [reading, setReading] = useState(false);
  const i = AP.getInvoice(params.uid);
  if (!i) return <Screen title="Invoice"><Text>Not found.</Text></Screen>;
  const trail = AP.payTrail(i.uid);
  const local = listPhotos('invoice', i.uid);
  return (
    <Screen title={`${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || ''}`} subtitle={i.supplier_name}>
      <Banner testID="inv-state" tone={i.due === 'overdue' ? 'danger' : ['due_today', 'due_soon'].includes(i.due) ? 'warn' : i.due === 'paid' ? 'success' : 'info'}
        title={`${dueText(i)}${i.owing && i.due !== 'paid' ? ` · ${$(i.owing)} ${i.kind === 'credit' ? 'left to use' : 'owing'}` : ''}`}
        message={i.status === 'to_check' ? 'Waiting to be checked.' : i.status === 'void' ? `Void: ${i.void_reason}` : `Checked by ${i.checked_by_name || '?'} ${String(i.checked_at || '').slice(0, 16)}`} />
      {['waiting', 'type', 'unreadable'].includes(i.ocr_status) && i.status === 'to_check' ? (
        <Card tone="info">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{i.ocr_status === 'waiting' ? 'Waiting to be read' : 'Not read yet'}</Text>
          <Text style={{ fontSize: 15, color: C.sub, marginBottom: 8 }}>Google reads the photo when this device is online. Or read it now, or type the details (Change).</Text>
          <Btn testID="inv-read-now" title={reading ? 'Reading the photo…' : 'Read this photo now'} icon="🔍" variant="info" size="md" disabled={reading}
            onPress={async () => { setReading(true); const r = await readInvoiceNow(i.uid); setReading(false); if (r.ok) ui.toast(r.message); else ui.alert({ title: 'Could not read it', message: r.message, tone: 'warn' }); refresh(); }} />
        </Card>
      ) : null}
      {i.ocr_notes ? <Banner tone="warn" title="Read from the photo – please check" message={i.ocr_notes} /> : null}
      {invoiceWarnings(i).map((w) => <Banner key={w} tone="warn" message={w} />)}
      <FixButton table="ap_invoices" keyVal={i.uid} />
      <Card>
        <Row label="Supplier" value={`${i.supplier_name}${i.supplier_tin ? ` (TIN ${i.supplier_tin})` : ''}`} />
        <Row label="Invoice date" value={i.invoice_date} />
        <Row label="Due" value={`${i.due_date}${i.on_account ? ' (on account)' : ''}`} />
        <Row label="Shop" value={i.shop_code || 'Whole business'} />
        {(() => {
          // v3.9: the purchase order and the deliveries this invoice belongs to (or that it has none).
          let po = null; let recs = [];
          try { po = i.po_uid ? db().get('SELECT uid, po_no, order_date FROM po_orders WHERE uid = ?', [i.po_uid]) : null; recs = db().all("SELECT uid, receive_date FROM inv_receipts WHERE invoice_uid = ? AND status = 'active'", [i.uid]); } catch (e) { po = null; recs = []; }
          return (
            <>
              <Row label="Purchase order" value={po ? `${po.po_no} (${po.order_date})` : i.kind === 'invoice' ? 'None' : '—'} color={po ? C.info : undefined} />
              {po ? <Btn testID="inv-open-po" title={`Open ${po.po_no}`} icon="📝" size="sm" variant="ghost" onPress={() => nav.push('POView', { uid: po.uid })} /> : null}
              {recs.map((r) => <Btn key={r.uid} testID={`inv-open-rc-${r.uid}`} title={`Goods received ${r.receive_date}`} icon="🚚" size="sm" variant="ghost" onPress={() => nav.push('Receipt', { uid: r.uid })} />)}
            </>
          );
        })()}
        {/* v3.9.5 subtotal, VAT and total on every invoice */}
        <Row label="Subtotal (excl. VAT)" value={$(Math.round(((Number(i.total) || 0) - (Number(i.vat) || 0)) * 100) / 100)} />
        {i.zero_rated ? <Row label="  of which zero rated" value={$(i.zero_rated)} /> : null}
        <Row label={`VAT${i.vat_type === 'zero' ? ' (zero rated)' : i.vat_type === 'mixed' ? ' (mixed)' : ''}`} value={$(i.vat)} />
        <Row label="Total (incl. VAT)" value={$(i.total)} bold />
        <Row label="Paid" value={$(i.paid)} color={C.success} />
        <Row label={i.kind === 'credit' ? 'Left to use' : 'Owing'} value={$(i.owing)} bold color={i.owing ? C.danger : C.success} />
        {i.category ? <Row label="Category" value={i.category} /> : null}
        {i.description ? <Row label="Bought" value={i.description} /> : null}
        <Row label="Entered" value={`${i.entered_by_name || '?'} ${String(i.entered_at || '').slice(0, 16)}`} />
        {i.notes ? <Text style={{ fontSize: 15, color: C.text, marginTop: 6 }}>Notes: {i.notes}</Text> : null}
      </Card>
      {local.length || i.photos.length ? (
        <Section title="Photos">
          <PhotoStrip testID="inv-photos" photos={photosFor(local, i.photos, `${i.supplier_name} ${i.invoice_no || ''}`)} size={130} />
        </Section>
      ) : null}
      <Section title="Pay trail">
        {!trail.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing paid yet.</Text> : null}
        {trail.map((p) => (
          <ListItem key={p.uid + p.applied} testID={`trail-${p.uid}`} onPress={() => nav.push('ApPayment', { uid: p.uid })} tone={p.status === 'void' ? undefined : 'success'}
            title={`${METHOD[p.method]}${p.cheque_no ? ` ${p.cheque_no}` : ''}${p.reference ? ` · ${p.reference}` : ''}${p.credit_no ? ` ${p.credit_no}` : ''}`}
            sub={`${p.pay_date} · by ${p.paid_by_name || '?'}${p.account_name ? ` · ${p.account_name}` : ''}${p.shop_code ? ` · cash from ${p.shop_code}` : ''}${p.received_by ? ` · received by ${p.received_by}` : ''}${p.cheque_status === 'presented' ? ` · cleared ${p.presented_date}` : p.cheque_status === 'written' ? ' · not cleared yet' : ''}`}
            right={$(p.applied)} badge={p.status === 'void' ? 'VOID' : null} badgeColor={C.sub} />
        ))}
      </Section>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {i.status !== 'void' && i.kind === 'invoice' && i.owing > 0 && can('payments_make') ? <Btn testID="inv-pay" title="Pay" icon="💸" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('ApPay', { supplierUid: i.supplier_uid, invoiceUid: i.uid })} /> : null}
        {i.status === 'to_check' && can('invoices_check') ? <Btn testID="inv-check" title="Checked ✓" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => AP.checkInvoice(user, i.uid), 'Checked')} /> : null}
        {i.status !== 'void' && (can('invoices_check') || (i.status === 'to_check' && i.entered_by_uid === user.uid)) ? <Btn testID="inv-edit" title="Change" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('ApInvoiceEdit', { uid: i.uid })} /> : null}
        {i.status !== 'void' && can('invoices_check') && !voiding ? <Btn title="Void" variant="ghost" onPress={() => setVoiding('')} /> : null}
      </View>
      {voiding !== null ? (
        <Card tone="danger">
          <ReasonField testID="inv-void-reason" label="Reason for voiding (required)" value={voiding} onChangeText={setVoiding} placeholder="e.g. entered twice, wrong supplier" />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setVoiding(null)} />
            <Btn testID="inv-void" title="Void invoice" variant="danger" style={{ flex: 1 }} onPress={() => { if (act(() => AP.voidInvoice(user, i.uid, voiding), 'Voided')) setVoiding(null); }} />
          </View>
        </Card>
      ) : null}
      {refresh && ui && null}
    </Screen>
  );
}
