// Invoices & cheques › Payment methods: add, rename, hide or remove the ways suppliers are paid (owner / admin).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Chips, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { payMethods, addPayMethod, setPayMethodActive, renamePayMethod, removePayMethod, BASES } from '../payMethods.js';

export function PayMethodsScreen() {
  const { user } = useApp();
  const ui = useUI();
  const [list, setList] = useState(() => payMethods({ all: true }));
  const [label, setLabel] = useState('');
  const [base, setBase] = useState('transfer');
  const [names, setNames] = useState({});
  const run = (f, msg) => { try { setList(f()); ui.toast(msg); } catch (e) { ui.error(e); } };
  const remove = async (m) => { if (await ui.confirm({ title: `Remove ${m.label}?`, message: 'Past payments keep it. It will not be offered any more.', confirmText: 'Remove', tone: 'danger' })) run(() => removePayMethod(user, m.id), 'Removed'); };
  return (
    <Screen title="Payment methods" subtitle="How suppliers are paid – shown when entering and paying invoices">
      {list.map((m) => (
        <Card key={m.id} tone={m.active === false ? undefined : 'success'}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: m.active === false ? C.sub : C.text }}>{m.icon || '💳'} {m.label}{m.active === false ? ' (hidden)' : ''}</Text>
            <Text style={{ color: C.sub }}>{(BASES.find((b) => b.value === m.base) || {}).label}</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 200, flexGrow: 1 }}><Field testID={`pm-name-${m.id}`} label="Name" value={names[m.id] === undefined ? m.label : names[m.id]} onChangeText={(v) => setNames({ ...names, [m.id]: v })} /></View>
            <Btn testID={`pm-rename-${m.id}`} title="Rename" size="sm" variant="secondary" onPress={() => run(() => renamePayMethod(user, m.id, names[m.id] === undefined ? m.label : names[m.id]), 'Renamed')} />
            <Btn testID={`pm-toggle-${m.id}`} title={m.active === false ? 'Show' : 'Hide'} size="sm" variant="secondary" onPress={() => run(() => setPayMethodActive(user, m.id, m.active === false), m.active === false ? 'Shown' : 'Hidden')} />
            {!m.builtin ? <Btn testID={`pm-remove-${m.id}`} title="Remove" size="sm" variant="danger" onPress={() => remove(m)} /> : null}
          </View>
        </Card>
      ))}
      <Section title="Add a payment method">
        <Field testID="pm-new-label" label="Name (e.g. M-PAiSA, BSP Pay, EFTPOS)" value={label} onChangeText={setLabel} />
        <Text style={{ fontWeight: '700', color: C.text }}>It works like</Text>
        <Chips value={base} onChange={setBase} testIDPrefix="pm-new-base" options={BASES} />
        <Btn testID="pm-add" title="Add" icon="➕" variant="success" onPress={() => run(() => { const r = addPayMethod(user, { label, base }); setLabel(''); return r; }, 'Added')} />
        <Hint>Cheque: from a bank account with a cheque number. Cash: from a shop's cash. Bank transfer: from a bank account with a reference.</Hint>
      </Section>
    </Screen>
  );
}
