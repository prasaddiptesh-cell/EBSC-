// Paying suppliers: choose the invoices, then cheque / cash / transfer. Credit notes are used first.
import React, { useState } from 'react';
import { payMethods, baseOf, methodLabel } from '../payMethods.js';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, ReasonField } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { listPhotos } from '../../../services/stock.js';
import { dateStr } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import * as AP from '../service.js';
import { offerPdf } from '../../../ui/shareDoc.js';
import { paymentDoc } from '../../../services/taskDocs.js';

const { $, r2 } = AP;
const METHOD = { cheque: 'Cheque', cash: 'Cash', transfer: 'Bank transfer', credit: 'Credit note' };

export function PayScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const suppliers = AP.listSuppliers();
  const [supplierUid, setSupplierUid] = useState(params.supplierUid || '');
  const sup = suppliers.find((s) => s.uid === supplierUid);
  const data = supplierUid ? AP.payableFor(supplierUid) : { invoices: [], credits: [] };
  const [amounts, setAmounts] = useState(() => {
    if (params.invoiceUid) return { [params.invoiceUid]: String(AP.getInvoice(params.invoiceUid).owing) };
    // From a cheque handed over (To verify / stub): the invoices ticked on the photo screen.
    const out = {};
    (params.invoiceUids || []).forEach((u) => { const i = AP.getInvoice(u); if (i && i.owing > 0) out[u] = String(i.owing); });
    return out;
  });
  const [useCredits, setUseCredits] = useState(true);
  const accounts = AP.listAccounts();
  const inv0 = params.invoiceUid ? AP.getInvoice(params.invoiceUid) : null;
  const [m, setM] = useState({ method: params.chequeNo ? 'cheque' : (inv0 && inv0.pay_method) || (sup ? sup.pay_method : 'cheque'), accountUid: params.accountUid || (accounts[0] ? accounts[0].uid : ''), chequeNo: params.chequeNo ? String(params.chequeNo) : '', reference: '', shopCode: user.shop_code || '', receivedBy: '', notes: '', payDate: dateStr() });
  const [photos, setPhotos] = useState([]);
  const set = (k) => (v) => setM((o) => ({ ...o, [k]: v }));
  const nextNo = m.accountUid ? AP.nextChequeNo(m.accountUid) : null;
  const chequeNo = m.chequeNo || (nextNo ? String(nextNo) : '');

  const ticked = data.invoices.filter((i) => Number(amounts[i.uid]) > 0);
  const total = r2(ticked.reduce((s, i) => s + Number(amounts[i.uid]), 0));
  const creditLeft = r2(data.credits.reduce((s, c) => s + c.owing, 0));
  const creditUse = useCredits ? Math.min(creditLeft, total) : 0;
  const toPay = r2(total - creditUse);
  // Provisional tax kept back from a contractor: the cheque / transfer is for the rest.
  let wh = { withheld: 0 };
  try { wh = toPay > 0 && supplierUid ? AP.withholdingFor(supplierUid, ticked.map((i) => ({ invoiceUid: i.uid, amount: r2(Number(amounts[i.uid]) * (toPay / (total || 1))) })), m.payDate) : wh; } catch (e) { wh = { withheld: 0 }; }
  const handOver = r2(toPay - (wh.withheld || 0));

  const toggle = (i) => setAmounts((a) => ({ ...a, [i.uid]: Number(a[i.uid]) > 0 ? '' : String(i.owing) }));
  const tickAll = () => setAmounts(Object.fromEntries(data.invoices.filter((i) => !i.blocked).map((i) => [i.uid, String(i.owing)])));

  const pay = async () => {
    try {
      if (!ticked.length) throw Object.assign(new Error('Tick at least one invoice.'), { isAppError: true });
      // Split the ticked amounts: credit notes first (oldest invoices first), then the money payment.
      const queue = ticked.map((i) => ({ invoiceUid: i.uid, amount: r2(Number(amounts[i.uid])) }));
      let creditToUse = creditUse;
      const credits = [];
      for (const c of data.credits) {
        if (creditToUse <= 0) break;
        let fromThis = Math.min(c.owing, creditToUse);
        const allocs = [];
        for (const q of queue) {
          if (fromThis <= 0) break;
          const take = r2(Math.min(q.amount, fromThis));
          if (take <= 0) continue;
          allocs.push({ invoiceUid: q.invoiceUid, amount: take });
          q.amount = r2(q.amount - take);
          fromThis = r2(fromThis - take);
          creditToUse = r2(creditToUse - take);
        }
        if (allocs.length) credits.push({ creditUid: c.uid, allocations: allocs, date: m.payDate });
      }
      const rest = queue.filter((q) => q.amount > 0);
      let payment = null;
      if (rest.length) {
        // The exact amount kept back (provisional tax) for what is really paid now.
        const held = AP.withholdingFor(supplierUid, rest, m.payDate).withheld || 0;
        const settles = r2(rest.reduce((t, q) => t + q.amount, 0));
        if (baseOf(m.method) === 'cheque') {
          const ok = await ui.confirm({ title: `Write cheque ${chequeNo}`, message: `Pay ${sup.name} ${$(settles - held)} by cheque ${chequeNo} on ${m.payDate}.${held ? `\n\n${$(held)} provisional tax (5%) is kept back and paid to FRCS – the invoices are settled in full (${$(settles)}).` : ''}\n\nWrite the cheque exactly like this.`, confirmText: 'Cheque written' });
          if (!ok) return;
        }
        payment = { supplierUid, method: m.method, payDate: m.payDate, accountUid: m.accountUid, chequeNo, reference: m.reference, shopCode: m.shopCode, receivedBy: m.receivedBy, notes: m.notes, allocations: rest, photos };
      }
      const p = AP.settle(user, { credits, payment });
      ui.toast(p ? `Paid ${$(p.amount)}${p.cheque_no ? ` – cheque ${p.cheque_no}` : ''}` : 'Credit used');
      if (p) { nav.replace('ApPayment', { uid: p.uid }); offerPdf(ui, () => paymentDoc(p.uid), { title: p.cheque_no ? `Send cheque ${p.cheque_no} to the Viber group?` : undefined }); } else nav.pop();
    } catch (e) {
      ui.error(e);
    }
  };

  return (
    <Screen title="Pay a supplier" subtitle={sup ? sup.name : 'Choose the supplier'}
      footer={supplierUid ? <Btn testID="pay-save" title={toPay ? `Pay ${$(handOver)}${baseOf(m.method) === 'cheque' ? ` – cheque ${chequeNo}` : ''}` : creditUse ? `Use credit ${$(creditUse)}` : 'Pay'} icon="💸" variant="success" onPress={pay} disabled={!total} /> : null}>
      <Select testID="pay-supplier" label="Supplier" value={supplierUid} onChange={(v) => { setSupplierUid(v); setAmounts({}); const s = suppliers.find((x) => x.uid === v); if (s) setM((o) => ({ ...o, method: s.pay_method })); }}
        options={suppliers.map((s) => ({ value: s.uid, label: s.name }))} />
      {supplierUid ? (
        <>
          <Section title={`Invoices owing (${data.invoices.length})`} right={data.invoices.length ? <Btn title="Tick all" size="sm" variant="secondary" onPress={tickAll} /> : null}>
            {!data.invoices.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing owing to {sup && sup.name}.</Text> : null}
            {data.invoices.map((i) => {
              const on = Number(amounts[i.uid]) > 0;
              return (
                <View key={i.uid} style={{ gap: 6 }}>
                  <Pressable testID={`pay-tick-${i.invoice_no || i.uid}`} disabled={!!i.blocked} onPress={() => toggle(i)}
                    style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, borderWidth: 2, borderColor: on ? C.success : i.due === 'overdue' ? C.danger : C.border, backgroundColor: on ? C.successSoft : C.card, opacity: i.blocked ? 0.5 : 1 }}>
                    <Text style={{ fontSize: 26 }}>{on ? '☑️' : '⬜'}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{i.invoice_no || '(no number)'} · {i.invoice_date}</Text>
                      <Text style={{ fontSize: 14, color: i.due === 'overdue' ? C.danger : C.sub }}>Due {i.due_date}{i.partPaid ? ` · paid ${$(i.paid)} of ${$(i.total)}` : ''}{i.blocked ? ` · ${i.blocked}` : ''}</Text>
                    </View>
                    <Text style={{ fontSize: 19, fontWeight: '900', color: C.text }}>{$(i.owing)}</Text>
                  </Pressable>
                  {on ? <MoneyField label="Pay this much (less = part payment)" value={amounts[i.uid]} onChange={(v) => setAmounts((a) => ({ ...a, [i.uid]: v }))} /> : null}
                </View>
              );
            })}
          </Section>
          {creditLeft ? (
            <Card tone="success">
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Credit notes available: {$(creditLeft)}</Text>
              <Chips value={useCredits} onChange={setUseCredits} options={[{ value: true, label: 'Use them first' }, { value: false, label: 'Keep for later' }]} />
            </Card>
          ) : null}
          <Card>
            <Row label="Invoices ticked" value={`${ticked.length} · ${$(total)}`} />
            {creditUse ? <Row label="Credit used" value={`− ${$(creditUse)}`} color={C.success} /> : null}
            <Row label={wh.withheld ? 'Settles' : 'To pay'} value={$(toPay)} bold={!wh.withheld} />
            {wh.withheld ? <Row label="Provisional tax kept back (5%)" value={`− ${$(wh.withheld)}`} color={C.warn} /> : null}
            {wh.withheld ? <Row testID="pay-net" label="Cheque / transfer for" value={$(handOver)} bold /> : null}
          </Card>
          {toPay > 0 ? (
            <Card>
              <H>How</H>
              <Chips value={m.method} onChange={set('method')} testIDPrefix="pay-method" options={payMethods().map((x) => ({ value: x.id, label: `${x.icon || ''} ${x.label}`.trim() }))} />
              <DateField testID="pay-date" label="Date" value={m.payDate} onChange={set('payDate')} />
              {baseOf(m.method) !== 'cash' ? (
                <Select testID="pay-account" label="Bank account" value={m.accountUid} onChange={(v) => setM((o) => ({ ...o, accountUid: v, chequeNo: '' }))} options={accounts.map((a) => ({ value: a.uid, label: `${a.name}${a.account_no ? ` (${a.account_no})` : ''}` }))} />
              ) : null}
              {baseOf(m.method) !== 'cash' && !accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices › Cheques & bank." /> : null}
              {baseOf(m.method) === 'cheque' ? (
                <>
                  <Field testID="pay-chequeno" label={`Cheque number${nextNo ? ` (next in the book: ${nextNo})` : ''}`} value={chequeNo} onChangeText={set('chequeNo')} keyboardType="number-pad" />
                  {!nextNo && m.accountUid ? <Banner tone="warn" message="No unused cheques in the books for this account. Add the new cheque book in Cheques & bank › Books." /> : null}
                </>
              ) : null}
              {baseOf(m.method) === 'transfer' ? <Field testID="pay-ref" label="Transfer reference" value={m.reference} onChangeText={set('reference')} /> : null}
              {baseOf(m.method) === 'cash' ? (
                <>
                  <Label>Cash taken from</Label>
                  <Chips value={m.shopCode} onChange={set('shopCode')} testIDPrefix="pay-shop" options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') }))} />
                  <Field testID="pay-received" label="Received by (name of the driver / rep)" value={m.receivedBy} onChangeText={set('receivedBy')} />
                </>
              ) : null}
              <Field label="Note (optional)" value={m.notes} onChangeText={set('notes')} />
              <PhotoPicker label="Receipt / cheque stub photo" value={photos} onChange={setPhotos} />
            </Card>
          ) : null}
        </>
      ) : null}
    </Screen>
  );
}

export function PaymentViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [reason, setReason] = useState(null);
  const p = AP.getPayment(params.uid);
  if (!p) return <Screen title="Payment"><Text>Not found.</Text></Screen>;
  return (
    <Screen title={`${(p.method_name || METHOD[p.method])}${p.cheque_no ? ` ${p.cheque_no}` : ''}`} subtitle={`${p.supplier_name} · ${$(p.amount)}`}>
      {p.status === 'void' ? <Banner tone="danger" title="Void" message={`${p.void_reason} (${p.voided_by_name}, ${String(p.voided_at).slice(0, 16)})`} /> : null}
      <Card>
        <Row label="Supplier" value={p.supplier_name} />
        <Row label="Date" value={p.pay_date} />
        <Row label="Amount" value={$(p.amount)} bold />
        <Row label="How" value={(p.method_name || METHOD[p.method])} />
        {p.account_name ? <Row label="Account" value={p.account_name} /> : null}
        {p.cheque_no ? <Row label="Cheque" value={`${p.cheque_no} · ${p.cheque_status === 'presented' ? `cleared ${p.presented_date}` : p.cheque_status === 'void' ? 'void' : 'not cleared yet'}`} /> : null}
        {p.reference ? <Row label="Reference" value={p.reference} /> : null}
        {p.shop_code ? <Row label="Cash from" value={p.shop_code} /> : null}
        {p.received_by ? <Row label="Received by" value={p.received_by} /> : null}
        <Row label="Paid by" value={`${p.paid_by_name || '?'} · ${String(p.created_at).slice(0, 16)}`} />
        {p.notes ? <Row label="Note" value={p.notes} /> : null}
      </Card>
      {p.photos.length || listPhotos('payment', p.uid).length ? <Section title="Receipt / stub"><PhotoStrip photos={photosFor(listPhotos('payment', p.uid), p.photos, `Payment to ${p.supplier_name}`)} /></Section> : null}
      <Section title="Invoices it paid">
        {p.allocations.map((a) => <ListItem key={a.invoice_uid} onPress={() => nav.push('ApInvoice', { uid: a.invoice_uid })} title={a.invoice_no || '(no number)'} sub={`${a.invoice_date} · invoice total ${$(a.total)}`} right={$(a.amount)} />)}
      </Section>
      {p.status === 'active' && can('payments_make') ? (reason === null ? <Btn testID="pay-void-open" title="Void this payment" variant="ghost" onPress={() => setReason('')} /> : (
        <Card tone="danger">
          <Text style={{ fontSize: 15, color: C.text, marginBottom: 6 }}>The invoices will show as owing again.{p.cheque_no ? ` Cheque ${p.cheque_no} is marked void (keep the cancelled cheque).` : ''}</Text>
          <ReasonField testID="pay-void-reason" label="Reason (required)" value={reason} onChangeText={setReason} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setReason(null)} />
            <Btn testID="pay-void" title="Void payment" variant="danger" style={{ flex: 1 }} onPress={() => { if (act(() => AP.voidPayment(user, p.uid, reason), 'Payment voided')) setReason(null); }} />
          </View>
        </Card>
      )) : null}
    </Screen>
  );
}

export function PaymentListScreen() {
  const { nav } = useApp();
  const [method, setMethod] = useState('');
  const rows = AP.listPayments({ method: method || undefined, includeVoid: true });
  return (
    <Screen title="Payments" subtitle={`${rows.length} shown`}>
      <Chips value={method} onChange={setMethod} options={[{ value: '', label: 'All' }, { value: 'cheque', label: 'Cheques' }, { value: 'cash', label: 'Cash' }, { value: 'transfer', label: 'Transfers' }, { value: 'credit', label: 'Credits' }]} />
      {rows.map((p) => (
        <ListItem key={p.uid} onPress={() => nav.push('ApPayment', { uid: p.uid })} title={`${p.supplier_name}`}
          sub={`${p.pay_date} · ${(p.method_name || METHOD[p.method])}${p.cheque_no ? ` ${p.cheque_no}` : ''}${p.reference ? ` ${p.reference}` : ''} · ${p.paid_by_name || ''}`}
          right={$(p.amount)} badge={p.status === 'void' ? 'VOID' : p.cheque_status === 'written' ? 'not cleared' : null} badgeColor={p.status === 'void' ? C.sub : C.warn} />
      ))}
    </Screen>
  );
}
