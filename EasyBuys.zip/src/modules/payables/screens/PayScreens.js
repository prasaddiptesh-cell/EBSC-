// Paying suppliers: choose the invoices, then cheque / cash / transfer. Credit notes are used first.
import React, { useState } from 'react';
import { payMethods, baseOf, methodLabel } from '../payMethods.js';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, ReasonField } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { listPhotos } from '../../../services/stock.js';
import { dateStr } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import * as AP from '../service.js';
import { offerPdf } from '../../../ui/shareDoc.js';
import { paymentDoc } from '../../../services/taskDocs.js';
import { ChequeNoPicker } from './ChequePicker.js';
import { FixButton } from '../../admin/screens/RecordFixScreen.js';

const { $, r2 } = AP;
const METHOD = { cheque: 'Cheque', cash: 'Cash', transfer: 'Bank transfer', credit: 'Credit note' };

export function PayScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const suppliers = AP.listSuppliers();
  const [supplierUid, setSupplierUid] = useState(params.supplierUid || '');
  const sup = suppliers.find((s) => s.uid === supplierUid);
  const data = supplierUid ? AP.payableFor(supplierUid) : { invoices: [], credits: [] };
  const [amounts, setAmounts] = useState(() => {
    if (params.invoiceUid) return { [params.invoiceUid]: String(AP.getInvoice(params.invoiceUid).owing) };
    // From a cheque handed over (To verify / stub): the invoices ticked on the photo screen.
    const out = {};
    (params.invoiceUids || []).forEach((u) => { const i = AP.getInvoice(u); if (i && i.owing > 0) out[u] = String(i.owing); });
    return out;
  });
  const [useCredits, setUseCredits] = useState(true);
  const accounts = AP.listAccounts();
  const inv0 = params.invoiceUid ? AP.getInvoice(params.invoiceUid) : null;
  const [m, setM] = useState({ method: params.chequeNo ? 'cheque' : params.method || (inv0 && inv0.pay_method) || (sup ? sup.pay_method : 'cheque'), accountUid: params.accountUid || (accounts[0] ? accounts[0].uid : ''), chequeNo: params.chequeNo ? String(params.chequeNo) : '', reference: '', shopCode: user.shop_code || '', receivedBy: '', notes: '', payDate: dateStr() });
  const [photos, setPhotos] = useState(params.photos || []); // build 35: a loan receipt brought from New invoice
  // v3.9 split payment: some cash, some cheque, some transfer for the same invoices.
  const [split, setSplit] = useState(false);
  const newPart = (method) => ({ method, amount: '', accountUid: accounts[0] ? accounts[0].uid : '', chequeNo: '', reference: '', shopCode: m.shopCode, receivedBy: '' });
  const [parts, setParts] = useState([]);
  const setPart = (i, k) => (v) => setParts((list) => list.map((x, j) => (j === i ? { ...x, [k]: v, ...(k === 'accountUid' ? { chequeNo: '' } : {}) } : x)));
  const set = (k) => (v) => setM((o) => ({ ...o, [k]: v }));
  const pp = usePaper('proof');
  const PAY_MAP = { ref: 'reference', date: 'payDate' };
  const nextNo = m.accountUid ? AP.nextChequeNo(m.accountUid) : null;
  const chequeNo = m.chequeNo; // build 44: never chosen for the person

  const ticked = data.invoices.filter((i) => Number(amounts[i.uid]) > 0);
  const total = r2(ticked.reduce((s, i) => s + Number(amounts[i.uid]), 0));
  const creditLeft = r2(data.credits.reduce((s, c) => s + c.owing, 0));
  const creditUse = useCredits ? Math.min(creditLeft, total) : 0;
  const toPay = r2(total - creditUse);
  // Provisional tax kept back from a contractor: the cheque / transfer is for the rest.
  let wh = { withheld: 0 };
  try { wh = toPay > 0 && supplierUid ? AP.withholdingFor(supplierUid, ticked.map((i) => ({ invoiceUid: i.uid, amount: r2(Number(amounts[i.uid]) * (toPay / (total || 1))) })), m.payDate) : wh; } catch (e) { wh = { withheld: 0 }; }
  const handOver = r2(toPay - (wh.withheld || 0));

  const toggle = (i) => setAmounts((a) => ({ ...a, [i.uid]: Number(a[i.uid]) > 0 ? '' : String(i.owing) }));
  const tickAll = () => setAmounts(Object.fromEntries(data.invoices.filter((i) => !i.blocked).map((i) => [i.uid, String(i.owing)])));

  const pay = async () => {
    if (!pp.okToSave(ui)) return;
    try {
      if (!ticked.length) throw Object.assign(new Error('Tick at least one invoice.'), { isAppError: true });
      // Split the ticked amounts: credit notes first (oldest invoices first), then the money payment.
      const queue = ticked.map((i) => ({ invoiceUid: i.uid, amount: r2(Number(amounts[i.uid])) }));
      let creditToUse = creditUse;
      const credits = [];
      for (const c of data.credits) {
        if (creditToUse <= 0) break;
        let fromThis = Math.min(c.owing, creditToUse);
        const allocs = [];
        for (const q of queue) {
          if (fromThis <= 0) break;
          const take = r2(Math.min(q.amount, fromThis));
          if (take <= 0) continue;
          allocs.push({ invoiceUid: q.invoiceUid, amount: take });
          q.amount = r2(q.amount - take);
          fromThis = r2(fromThis - take);
          creditToUse = r2(creditToUse - take);
        }
        if (allocs.length) credits.push({ creditUid: c.uid, allocations: allocs, date: m.payDate });
      }
      const rest = queue.filter((q) => q.amount > 0);
      let payment = null;
      if (rest.length) {
        // The exact amount kept back (provisional tax) for what is really paid now.
        const held = AP.withholdingFor(supplierUid, rest, m.payDate).withheld || 0;
        const settles = r2(rest.reduce((t, q) => t + q.amount, 0));
        if (!split && baseOf(m.method) === 'cheque') {
          if (!chequeNo) { ui.alert({ title: 'Choose the cheque number', message: 'Pick the number of the cheque leaf you are writing (all unused leaves of the cheque books are in the list), or type it.', tone: 'warn' }); return; }
          const ok = await ui.confirm({ title: `Write cheque ${chequeNo}`, message: `Pay ${sup.name} ${$(settles - held)} by cheque ${chequeNo} on ${m.payDate}.${held ? `\n\n${$(held)} provisional tax (5%) is kept back and paid to FRCS – the invoices are settled in full (${$(settles)}).` : ''}\n\nWrite the cheque exactly like this.`, confirmText: 'Cheque written' });
          if (!ok) return;
        }
        if (split) {
          const chq = parts.filter((x) => baseOf(x.method) === 'cheque' && r2(x.amount) > 0);
          const ok = await ui.confirm({ title: `Split payment – ${parts.filter((x) => r2(x.amount) > 0).length} parts`, message: parts.filter((x) => r2(x.amount) > 0).map((x) => `${methodLabel(x.method)} ${$(r2(x.amount))}${baseOf(x.method) === 'cheque' ? ` – cheque ${x.chequeNo}` : ''}`).join('\n') + `\n\nTotal ${$(r2(parts.reduce((t, x) => t + (Number(x.amount) || 0), 0)))} to ${sup.name} on ${m.payDate}.${chq.length ? '' : ''}`, confirmText: 'Save' });
          if (!ok) return;
        }
        payment = { supplierUid, method: m.method, payDate: m.payDate, chequeDate: baseOf(m.method) === 'cheque' && m.postDated ? m.chequeDate : undefined, accountUid: m.accountUid, walletUid: m.walletUid, chequeNo, reference: m.reference, shopCode: m.shopCode, receivedBy: m.receivedBy, notes: m.notes, allocations: rest, photos };
      }
      const splitPay = split && payment ? { supplierUid, payDate: m.payDate, allocations: payment.allocations, parts: parts.map((x) => ({ ...x, amount: r2(x.amount) })), notes: m.notes, photos } : null;
      const p = AP.settle(user, splitPay ? { credits, split: splitPay } : { credits, payment });
      if (p) pp.log(user, 'ap_payments', p.uid, m, PAY_MAP);
      if (p && p.split && p.split.length > 1) { ui.toast(`Paid ${$(p.split.reduce((t, x) => t + x.amount, 0))} in ${p.split.length} parts`); nav.pop(); return; }
      ui.toast(p ? `Paid ${$(p.amount)}${p.cheque_no ? ` – cheque ${p.cheque_no}` : ''}` : 'Credit used');
      if (p) { nav.replace('ApPayment', { uid: p.uid }); offerPdf(ui, () => paymentDoc(p.uid), { title: p.cheque_no ? `Send cheque ${p.cheque_no} to the Viber group?` : undefined }); } else nav.pop();
    } catch (e) {
      ui.error(e);
    }
  };

  return (
    <Screen title="Pay a supplier" subtitle={sup ? sup.name : 'Choose the supplier'}
      footer={supplierUid ? <Btn testID="pay-save" title={toPay ? (split ? `Pay ${$(handOver)} in ${parts.length} parts` : `Pay ${$(handOver)}${baseOf(m.method) === 'cheque' ? ` – cheque ${chequeNo}` : ''}`) : creditUse ? `Use credit ${$(creditUse)}` : 'Pay'} icon="💸" variant="success" onPress={pay} disabled={!total} /> : null}>
      <Select testID="pay-supplier" label="Supplier" value={supplierUid} onChange={(v) => { setSupplierUid(v); setAmounts({}); const s = suppliers.find((x) => x.uid === v); if (s) setM((o) => ({ ...o, method: s.pay_method })); }}
        options={suppliers.map((s) => ({ value: s.uid, label: s.name }))} />
      {supplierUid && (() => { try { const RC = require('../../till/recharge.js'); return !!RC.rechargeSupplier(supplierUid) && RC.mayTopUp(user); } catch (e) { return false; } })() ? (
        <Btn testID="pay-recharge" title="Top up the recharge machine" icon="📱" size="md" variant="secondary" onPress={() => nav.push('RechargeTopUp', { supplierUid })} />
      ) : null}
      {supplierUid ? (
        <>
          <Section title={`Invoices owing (${data.invoices.length})`} right={data.invoices.length ? <Btn title="Tick all" size="sm" variant="secondary" onPress={tickAll} /> : null}>
            {!data.invoices.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing owing to {sup && sup.name}.</Text> : null}
            {data.invoices.map((i) => {
              const on = Number(amounts[i.uid]) > 0;
              return (
                <View key={i.uid} style={{ gap: 6 }}>
                  <Pressable testID={`pay-tick-${i.invoice_no || i.uid}`} disabled={!!i.blocked} onPress={() => toggle(i)}
                    style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 14, borderWidth: 2, borderColor: on ? C.success : i.due === 'overdue' ? C.danger : C.border, backgroundColor: on ? C.successSoft : C.card, opacity: i.blocked ? 0.5 : 1 }}>
                    <Text style={{ fontSize: 26 }}>{on ? '☑️' : '⬜'}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{i.invoice_no || '(no number)'} · {i.invoice_date}</Text>
                      <Text style={{ fontSize: 14, color: i.due === 'overdue' ? C.danger : C.sub }}>Due {i.due_date}{i.partPaid ? ` · paid ${$(i.paid)} of ${$(i.total)}` : ''}{i.blocked ? ` · ${i.blocked}` : ''}</Text>
                    </View>
                    <Text style={{ fontSize: 19, fontWeight: '900', color: C.text }}>{$(i.owing)}</Text>
                  </Pressable>
                  {on ? <MoneyField testID={`pay-amt-${i.invoice_no || i.uid}`} label="Pay this much (less = part payment)" value={amounts[i.uid]} onChange={(v) => setAmounts((a) => ({ ...a, [i.uid]: v }))} /> : null}
                </View>
              );
            })}
          </Section>
          {(() => { const part = ticked.filter((i) => Number(amounts[i.uid]) < i.owing - 0.004); return part.length ? (
            <Banner testID="pay-part-warn" tone="warn" title="Part payment" message={`${part.map((i) => `${i.invoice_no || 'no number'}: ${$(r2(i.owing - Number(amounts[i.uid])))} still owing`).join('\n')}\nThat is allowed – the invoice stays flagged "part paid" until the rest is paid.`} />
          ) : null; })()}
          {creditLeft ? (
            <Card tone="success">
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Credit notes available: {$(creditLeft)}</Text>
              <Chips value={useCredits} onChange={setUseCredits} options={[{ value: true, label: 'Use them first' }, { value: false, label: 'Keep for later' }]} />
            </Card>
          ) : null}
          <Card>
            <Row label="Invoices ticked" value={`${ticked.length} · ${$(total)}`} />
            {creditUse ? <Row label="Credit used" value={`− ${$(creditUse)}`} color={C.success} /> : null}
            <Row label={wh.withheld ? 'Settles' : 'To pay'} value={$(toPay)} bold={!wh.withheld} />
            {wh.withheld ? <Row label="Provisional tax kept back (5%)" value={`− ${$(wh.withheld)}`} color={C.warn} /> : null}
            {wh.withheld ? <Row testID="pay-net" label="Cheque / transfer for" value={$(handOver)} bold /> : null}
          </Card>
          {toPay > 0 ? (
            <Card>
              <H>How</H>
              <Chips value={split} onChange={(v) => { setSplit(v); if (v && !parts.length) setParts([{ ...newPart('cash'), amount: '' }, { ...newPart('cheque'), amount: '' }]); }} testIDPrefix="pay-split"
                options={[{ value: false, label: 'One way' }, { value: true, label: 'Split (cash + cheque + transfer)' }]} />
              <DateField testID="pay-date" label="Date" value={m.payDate} onChange={set('payDate')} />
              {split ? (
                <View style={{ gap: 10 }}>
                  {parts.map((x, i) => (
                    <Card key={i} tone={undefined}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <H>Part {i + 1}</H>
                        {parts.length > 2 ? <Btn testID={`pay-part-${i}-remove`} title="Remove" size="sm" variant="ghost" onPress={() => setParts((l) => l.filter((_, j) => j !== i))} /> : null}
                      </View>
                      <Chips value={x.method} onChange={setPart(i, 'method')} testIDPrefix={`pay-part-${i}-method`} options={payMethods().map((pm) => ({ value: pm.id, label: `${pm.icon || ''} ${pm.label}`.trim() }))} />
                      <MoneyField testID={`pay-part-${i}-amount`} label="Amount" value={x.amount} onChange={setPart(i, 'amount')} />
                      {['cheque', 'transfer'].includes(baseOf(x.method)) ? <Select testID={`pay-part-${i}-account`} label="Bank account" value={x.accountUid} onChange={setPart(i, 'accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
                      {baseOf(x.method) === 'cheque' ? <ChequeNoPicker testID={`pay-part-${i}-chq`} accountUid={x.accountUid} value={x.chequeNo} onChange={setPart(i, 'chequeNo')}
                        taken={parts.filter((y, j) => j !== i && baseOf(y.method) === 'cheque' && y.accountUid === x.accountUid).map((y) => String(y.chequeNo))} /> : null}
                      {baseOf(x.method) === 'cheque' ? <Chips value={x.shopCode} onChange={setPart(i, 'shopCode')} testIDPrefix={`pay-part-${i}-chq-shop`} options={listShops().filter((sh) => sh.active).map((sh) => ({ value: sh.code, label: `Issued by ${sh.name.replace(/^Shop (\d) - /, 'Shop $1 ')}` })).concat([{ value: '', label: 'Office' }])} /> : null}
                      {baseOf(x.method) === 'transfer' ? <Field testID={`pay-part-${i}-ref`} label="Transfer reference" value={x.reference} onChangeText={setPart(i, 'reference')} /> : null}
                      {baseOf(x.method) === 'cash' ? (
                        <>
                          <Chips value={x.shopCode} onChange={setPart(i, 'shopCode')} testIDPrefix={`pay-part-${i}-shop`} options={listShops().filter((sh) => sh.active).map((sh) => ({ value: sh.code, label: sh.name.replace(/^Shop (\d) - /, 'Shop $1 ') }))} />
                          <Field label="Received by" value={x.receivedBy} onChangeText={setPart(i, 'receivedBy')} />
                        </>
                      ) : null}
                    </Card>
                  ))}
                  <Btn testID="pay-part-add" title="Add another part" icon="➕" size="md" variant="secondary" onPress={() => setParts((l) => l.concat([newPart('transfer')]))} />
                  {(() => { const sum = r2(parts.reduce((t, x) => t + (Number(x.amount) || 0), 0)); const diff = r2(handOver - sum); return (
                    <Banner testID="pay-split-sum" tone={Math.abs(diff) < 0.005 ? 'success' : 'warn'} message={Math.abs(diff) < 0.005 ? `The parts add up to ${$(sum)}.` : `The parts add up to ${$(sum)} – ${diff > 0 ? `${$(diff)} still to share out` : `${$(-diff)} too much`} (to pay ${$(handOver)}).`} />
                  ); })()}
                </View>
              ) : null}
              {!split ? (<>
              <Chips value={m.method} onChange={set('method')} testIDPrefix="pay-method" options={payMethods().map((x) => ({ value: x.id, label: `${x.icon || ''} ${x.label}`.trim() }))} />
              {baseOf(m.method) === 'mpaisa' ? (() => {
                let ws = [];
                try { ws = require('../../../db/connection.js').db().all('SELECT uid, name FROM wallets WHERE active = 1 ORDER BY sort'); } catch (e) { ws = []; }
                return <><Select testID="pay-wallet" label="Paid from which M-PAiSA wallet" value={m.walletUid || ''} onChange={set('walletUid')} options={[{ value: '', label: 'Choose the shop\'s wallet' }].concat(ws.map((w) => ({ value: w.uid, label: w.name })))} /><Field testID="pay-mref" label="M-PAiSA transaction reference" value={m.reference} onChangeText={set('reference')} /></>;
              })() : null}
              {['cheque', 'transfer'].includes(baseOf(m.method)) ? (
                <Select testID="pay-account" label="Bank account" value={m.accountUid} onChange={(v) => setM((o) => ({ ...o, accountUid: v, chequeNo: '' }))} options={accounts.map((a) => ({ value: a.uid, label: `${a.name}${a.account_no ? ` (${a.account_no})` : ''}` }))} />
              ) : null}
              {['cheque', 'transfer'].includes(baseOf(m.method)) && !accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices › Cheques & bank." /> : null}
              {baseOf(m.method) === 'cheque' ? (
                <>
                  <ChequeNoPicker testID="pay-chequeno" accountUid={m.accountUid} value={m.chequeNo} onChange={set('chequeNo')} />
                  <Label>Cheque issued by</Label>
                  <Chips value={m.shopCode} onChange={set('shopCode')} testIDPrefix="pay-chq-shop" options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })).concat([{ value: '', label: 'Office' }])} />
                  <Label>Date on the cheque</Label>
                  <Chips value={!!m.postDated} onChange={(v) => setM((o) => ({ ...o, postDated: v, chequeDate: o.chequeDate || o.payDate }))} testIDPrefix="pay-postdated" options={[{ value: false, label: 'Today\'s date' }, { value: true, label: '📅 Post-dated (a later date)' }]} />
                  {m.postDated ? <DateField testID="pay-chqdate" label="Date written on the cheque" value={m.chequeDate || m.payDate} onChange={set('chequeDate')} /> : null}
                  {m.postDated ? <Text style={{ fontSize: 14, color: C.sub }}>The bank cannot pay it before this date. "Cheques to cover" reminds you to deposit for it a few days before.</Text> : null}
                </>
              ) : null}
              {baseOf(m.method) === 'transfer' ? <Field testID="pay-ref" label="Transfer reference" value={m.reference} onChangeText={set('reference')} /> : null}
              {baseOf(m.method) === 'cash' ? (
                <>
                  <Label>Cash taken from</Label>
                  <Chips value={m.shopCode} onChange={set('shopCode')} testIDPrefix="pay-shop" options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') }))} />
                  <Field testID="pay-received" label="Received by (name of the driver / rep)" value={m.receivedBy} onChangeText={set('receivedBy')} />
                </>
              ) : null}
              </>) : null}
              <Field label="Note (optional)" value={m.notes} onChangeText={set('notes')} />
              <PaperPhoto pr={pp} testID="pay-photo" label="Receipt / transfer / cheque stub photo" value={photos} onChange={setPhotos} form={m} setForm={setM} map={PAY_MAP} soft={{ payDate: dateStr() }}
                labels={{ reference: 'Reference', payDate: 'Date paid' }} hint="The reference and date fill in from the photo; the amount on it is compared.">
                {pp.read && pp.read.fields.amount !== undefined && Math.abs(pp.read.fields.amount - handOver) > 0.004 ? <Banner testID="pay-amtdiff" tone="warn" message={`The paper shows $${pp.read.fields.amount.toFixed(2)} but this payment is $${Number(handOver || 0).toFixed(2)}.`} /> : null}
              </PaperPhoto>
            </Card>
          ) : null}
        </>
      ) : null}
    </Screen>
  );
}

export function PaymentViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [reason, setReason] = useState(null);
  const [voidPics, setVoidPics] = useState([]); // build 39: a cancelled cheque needs its photo
  const p = AP.getPayment(params.uid);
  if (!p) return <Screen title="Payment"><Text>Not found.</Text></Screen>;
  return (
    <Screen title={`${(p.method_name || METHOD[p.method])}${p.cheque_no ? ` ${p.cheque_no}` : ''}`} subtitle={`${p.supplier_name} · ${$(p.amount)}`}>
      <FixButton table="ap_payments" keyVal={p.uid} />
      {p.status === 'void' ? <Banner tone="danger" title="Void" message={`${p.void_reason} (${p.voided_by_name}, ${String(p.voided_at).slice(0, 16)})`} /> : null}
      <Card>
        <Row label="Supplier" value={p.supplier_name} />
        <Row label="Date" value={p.pay_date} />
        <Row label="Amount" value={$(p.amount)} bold />
        <Row label="How" value={(p.method_name || METHOD[p.method])} />
        {p.account_name ? <Row label="Account" value={p.account_name} /> : null}
        {p.cheque_no ? <Row label="Cheque" value={`${p.cheque_no} · ${p.cheque_status === 'presented' ? `cleared ${p.presented_date}` : p.cheque_status === 'void' ? 'void' : 'not cleared yet'}`} /> : null}
        {p.reference ? <Row label="Reference" value={p.reference} /> : null}
        {p.shop_code ? <Row label="Cash from" value={p.shop_code} /> : null}
        {p.received_by ? <Row label="Received by" value={p.received_by} /> : null}
        <Row label="Paid by" value={`${p.paid_by_name || '?'} · ${String(p.created_at).slice(0, 16)}`} />
        {p.notes ? <Row label="Note" value={p.notes} /> : null}
      </Card>
      {p.photos.length || listPhotos('payment', p.uid).length ? <Section title="Receipt / stub"><PhotoStrip photos={photosFor(listPhotos('payment', p.uid), p.photos, `Payment to ${p.supplier_name}`)} /></Section> : null}
      <Section title="Invoices it paid">
        {p.allocations.map((a) => <ListItem key={a.invoice_uid} onPress={() => nav.push('ApInvoice', { uid: a.invoice_uid })} title={a.invoice_no || '(no number)'} sub={`${a.invoice_date} · invoice total ${$(a.total)}`} right={$(a.amount)} />)}
      </Section>
      {p.status === 'active' && can('payments_make') ? (reason === null ? <Btn testID="pay-void-open" title="Void this payment" variant="ghost" onPress={() => setReason('')} /> : (
        <Card tone="danger">
          <Text style={{ fontSize: 15, color: C.text, marginBottom: 6 }}>The invoices will show as owing again.{p.cheque_no ? ` Cheque ${p.cheque_no} is marked void (keep the cancelled cheque).` : ''}</Text>
          <ReasonField testID="pay-void-reason" label="Reason (required)" value={reason} onChangeText={setReason} />
          {p.method === 'cheque' ? <PhotoPicker testID="pay-void-photo" label="Photo of the cancelled cheque (or its stub)" required value={voidPics} onChange={setVoidPics} paper /> : null}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setReason(null)} />
            <Btn testID="pay-void" title="Void payment" variant="danger" style={{ flex: 1 }} onPress={() => { if (act(() => AP.voidPayment(user, p.uid, reason, { photos: voidPics }), 'Payment voided')) setReason(null); }} />
          </View>
        </Card>
      )) : null}
    </Screen>
  );
}

export function PaymentListScreen() {
  const { nav } = useApp();
  const [method, setMethod] = useState('');
  const rows = AP.listPayments({ method: method || undefined, includeVoid: true });
  return (
    <Screen title="Payments" subtitle={`${rows.length} shown`}>
      <Chips value={method} onChange={setMethod} options={[{ value: '', label: 'All' }, { value: 'cheque', label: 'Cheques' }, { value: 'cash', label: 'Cash' }, { value: 'transfer', label: 'Transfers' }, { value: 'credit', label: 'Credits' }]} />
      {rows.map((p) => (
        <ListItem key={p.uid} onPress={() => nav.push('ApPayment', { uid: p.uid })} title={`${p.supplier_name}`}
          sub={`${p.pay_date} · ${(p.method_name || METHOD[p.method])}${p.cheque_no ? ` ${p.cheque_no}` : ''}${p.reference ? ` ${p.reference}` : ''} · ${p.paid_by_name || ''}`}
          right={$(p.amount)} badge={p.status === 'void' ? 'VOID' : p.cheque_status === 'written' ? 'not cleared' : null} badgeColor={p.status === 'void' ? C.sub : C.warn} />
      ))}
    </Screen>
  );
}
