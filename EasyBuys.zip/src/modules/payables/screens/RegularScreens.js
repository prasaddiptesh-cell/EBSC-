// Release 03: regular suppliers with no invoice this week – add the invoice, or say nothing was bought from them.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, H, Select, Chips, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { reasonRequired } from '../../../services/access.js';
import { missingRegulars, answerRegular, weeklySuppliers, markWeekly, unmarkWeekly } from '../regulars.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const shopsList = () => { try { return require('../../admin/service.js').listShops().filter((s) => s.active && /^S\d+$/.test(String(s.code))); } catch (e) { return []; } };

// Release 38: the owner / admin marks a supplier as weekly (shop and usual day) – asked about from the first week.
function WeeklyList({ user, ui, bump }) {
  const shops = shopsList();
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ sup: '', shop: (shops[0] || {}).code || 'S1', day: '' });
  let sups = [];
  try { sups = require('../service.js').listSuppliers(); } catch (e) { sups = []; }
  const list = weeklySuppliers();
  const run = (fn, msg) => { try { fn(); ui.toast(msg); bump(); return true; } catch (e) { ui.error(e); return false; } };
  return (
    <Card testID="reg-weekly">
      <H>Weekly suppliers</H>
      <Hint>Suppliers who deliver every week. The app also learns them from the invoices (3 of the last 4 weeks); mark one here to be asked from this week. A shop's week cannot be closed while one of them has no invoice and no answer.</Hint>
      {list.map((w) => (
        <View key={`${w.supplierKey}|${w.shop}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={{ flex: 1, fontSize: 15, color: C.text }}>{`${w.supplier} · ${w.shop} · usually ${DAYS[w.day]}`}</Text>
          <Btn testID={`reg-unmark-${w.supplier}`} title="Not weekly" variant="ghost" size="sm" onPress={() => run(() => unmarkWeekly(user, { supplierKey: w.supplierKey, shop: w.shop }), 'Taken off')} />
        </View>
      ))}
      {!list.length ? <Text style={{ fontSize: 14, color: C.sub }}>None marked by hand yet.</Text> : null}
      {!adding ? <Btn testID="reg-mark" title="Mark a weekly supplier" icon="🔁" variant="secondary" size="md" onPress={() => setAdding(true)} /> : (
        <>
          <Select testID="reg-mark-sup" label="Supplier" search value={f.sup} onChange={(v) => setF((o) => ({ ...o, sup: v }))} options={sups.map((x) => ({ value: x.uid, label: x.name }))} />
          {shops.length > 1 ? <Chips testIDPrefix="reg-mark-shop" value={f.shop} onChange={(v) => setF((o) => ({ ...o, shop: v }))} options={shops.map((x) => ({ value: x.code, label: x.name || x.code }))} /> : null}
          <Chips testIDPrefix="reg-mark-day" value={f.day} onChange={(v) => setF((o) => ({ ...o, day: v }))} options={[1, 2, 3, 4, 5, 6, 0].map((d) => ({ value: String(d), label: DAYS[d].slice(0, 3) }))} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn testID="reg-mark-save" title="Save" variant="success" size="md" style={{ flex: 1 }} onPress={() => { const sp = sups.find((x) => x.uid === f.sup); if (run(() => markWeekly(user, { supplierUid: f.sup, supplier: sp ? sp.name : '', shop: f.shop, day: f.day === '' ? NaN : Number(f.day) }), 'Marked as weekly')) { setAdding(false); setF((o) => ({ ...o, sup: '', day: '' })); } }} />
            <Btn testID="reg-mark-cancel" title="Cancel" variant="ghost" size="md" onPress={() => setAdding(false)} />
          </View>
        </>
      )}
    </Card>
  );
}

export function RegularSuppliersScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [n, setN] = useState(0);
  const forWeek = params.from && params.to ? { from: params.from, to: params.to, shop: params.shop } : null;
  const isBoss = ['owner', 'admin'].includes(user.role);
  let list = [];
  try { list = missingRegulars(forWeek || {}); } catch (e) { list = []; }
  const none = (r, why) => { try { answerRegular(user, { supplierKey: r.supplierKey, shop: r.shop, week: r.week, answer: 'none', reason: why }); ui.toast('Noted for this week'); setN((x) => x + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title={forWeek ? `Regular suppliers – week ${forWeek.from.slice(5)} to ${forWeek.to.slice(5)}` : 'Regular suppliers – this week'} subtitle="Usually an invoice every week; none yet for the week">
      <Explain>These suppliers deliver every week (marked as weekly, or an invoice almost every week for the last month). If you bought from them this week, add the invoice – it is needed for the VAT. If nothing was bought, say so and the question goes away for this week.</Explain>
      {!list.length ? <Hint>Nothing missing – every regular supplier has an invoice this week (or you said nothing was bought).</Hint> : null}
      {list.map((r) => (
        <Card key={`${r.supplierKey}|${r.shop}`} testID={`reg-${r.supplier}`}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.supplier}{r.shop ? ` · ${r.shop}` : ''}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{`Usually on ${r.usualDay} · ${r.manual ? 'marked as weekly' : `invoices in ${r.weeksSeen} of the last 4 weeks`}${r.lastDate ? ` · last ${r.lastDate} (${$(r.lastTotal)})` : ''}`}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
            <Btn testID="reg-add" title="Bought – add the invoice" icon="📷" variant="success" size="md" onPress={() => nav.push('ApInvoiceEdit', { supplierUid: String(r.supplierKey).startsWith('name:') ? undefined : r.supplierKey, shopCode: r.shop || undefined, date: forWeek ? r.expected : undefined })} />
            {reasonRequired(user)
              ? <ReasonButton testID="reg-none" title="Nothing bought this week" icon="🚫" prompt="Why nothing from them this week? (e.g. still had stock)" confirm="Save" variant="secondary" size="md" onDo={(w) => none(r, w)} />
              : <Btn testID="reg-none" title="Nothing bought this week" icon="🚫" variant="secondary" size="md" onPress={() => none(r, '')} />}
          </View>
        </Card>
      ))}
      {isBoss ? <WeeklyList user={user} ui={ui} bump={() => setN((x) => x + 1)} /> : null}
    </Screen>
  );
}
