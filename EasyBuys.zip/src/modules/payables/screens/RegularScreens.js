// Release 03: regular suppliers with no invoice this week – add the invoice, or say nothing was bought from them.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { reasonRequired } from '../../../services/access.js';
import { missingRegulars, answerRegular } from '../regulars.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export function RegularSuppliersScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [n, setN] = useState(0);
  let list = [];
  try { list = missingRegulars(); } catch (e) { list = []; }
  const none = (r, why) => { try { answerRegular(user, { supplierKey: r.supplierKey, shop: r.shop, week: r.week, answer: 'none', reason: why }); ui.toast('Noted for this week'); setN(n + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Regular suppliers – this week" subtitle="Usually an invoice every week; none yet this week">
      <Explain>These suppliers sent an invoice almost every week for the last month. If you bought from them this week, add the invoice – it is needed for the VAT. If nothing was bought, say so and the question goes away for this week.</Explain>
      {!list.length ? <Hint>Nothing missing – every regular supplier has an invoice this week (or you said nothing was bought).</Hint> : null}
      {list.map((r) => (
        <Card key={`${r.supplierKey}|${r.shop}`} testID={`reg-${r.supplier}`}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{r.supplier}{r.shop ? ` · ${r.shop}` : ''}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{`Usually on ${r.usualDay} · invoices in ${r.weeksSeen} of the last 4 weeks · last ${r.lastDate} (${$(r.lastTotal)})`}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
            <Btn testID="reg-add" title="Bought – add the invoice" icon="📷" variant="success" size="md" onPress={() => nav.push('ApInvoiceEdit', { supplierUid: String(r.supplierKey).startsWith('name:') ? undefined : r.supplierKey, shopCode: r.shop || undefined })} />
            {reasonRequired(user)
              ? <ReasonButton testID="reg-none" title="Nothing bought this week" icon="🚫" prompt="Why nothing from them this week? (e.g. still had stock)" confirm="Save" variant="secondary" size="md" onDo={(w) => none(r, w)} />
              : <Btn testID="reg-none" title="Nothing bought this week" icon="🚫" variant="secondary" size="md" onPress={() => none(r, '')} />}
          </View>
        </Card>
      ))}
    </Screen>
  );
}
