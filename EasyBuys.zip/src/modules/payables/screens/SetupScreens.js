// Suppliers, invoice rules, regular bills and loans (all admin-editable).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, Table, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import * as AP from '../service.js';
import { listRecurring, getRecurring, saveRecurring, FREQ_LABEL, loanStatement, addLoanEntry, runRecurring } from '../recurring.js';

const { $ } = AP;
const shopOpts = () => [{ value: '', label: 'Whole business' }].concat(listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })));

export function SupplierListScreen() {
  const { nav, can } = useApp();
  const [q, setQ] = useState('');
  const rows = AP.listSuppliers({ q, includeInactive: true });
  return (
    <Screen title="Suppliers" subtitle={`${rows.length}`} footer={can('ap_setup') ? <Btn testID="sup-add" title="Add supplier" icon="➕" variant="success" onPress={() => nav.push('ApSupplierEdit', {})} /> : null}>
      <Field label="Search" value={q} onChangeText={setQ} />
      {rows.map((s) => {
        const owing = AP.listInvoices({ filter: 'unpaid', supplierUid: s.uid }).reduce((a, i) => a + i.owing, 0);
        return <ListItem key={s.uid} testID={`sup-${s.name}`} onPress={() => nav.push('ApSupplierEdit', { uid: s.uid })} title={s.name}
          sub={`${s.on_account ? `On account, ${s.terms_days} days` : 'Pay now'} · ${s.pay_method}${s.tin ? ` · TIN ${s.tin}` : ''}${s.active ? '' : ' · not used'}`}
          right={owing ? $(owing) : ''} rightSub={owing ? 'owing' : null} />;
      })}
    </Screen>
  );
}

export function SupplierEditScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const s0 = params.uid ? AP.getSupplier(params.uid) : null;
  const rules = AP.apRules();
  const [f, setF] = useState(() => (s0 ? {
    uid: s0.uid, name: s0.name, tin: s0.tin || '', vatRegistered: !!s0.vat_registered, onAccount: !!s0.on_account, termsDays: String(s0.terms_days), payMethod: s0.pay_method,
    contact: s0.contact || '', phone: s0.phone || '', email: s0.email || '', bankName: s0.bank_name || '', bankAccount: s0.bank_account || '', category: s0.category || '', notes: s0.notes || '', active: !!s0.active, withholdPct: Number(s0.withhold_pct) || 0,
  } : { name: '', tin: '', vatRegistered: true, onAccount: false, termsDays: String(rules.defaultTermsDays), payMethod: 'cheque', contact: '', phone: '', email: '', bankName: '', bankAccount: '', category: '', notes: '', active: true, withholdPct: 0 }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const edit = can('ap_setup');
  return (
    <Screen title={s0 ? s0.name : 'New supplier'} footer={edit ? <Btn testID="sup-save" title="Save" icon="💾" variant="success" onPress={() => { if (act(() => AP.saveSupplier(user, f), 'Saved')) nav.pop(); }} /> : null}>
      {s0 ? <Btn title="Statement & invoices" variant="secondary" size="md" onPress={() => nav.push('ApInvoices', { filter: 'all', supplierUid: s0.uid })} /> : null}
      <Card>
        <Field testID="sup-name" label="Name" value={f.name} onChangeText={set('name')} />
        <Field testID="sup-tin" label="TIN (for VAT)" value={f.tin} onChangeText={set('tin')} keyboardType="number-pad" />
        <Chips value={f.vatRegistered} onChange={set('vatRegistered')} options={[{ value: true, label: 'VAT registered' }, { value: false, label: 'Not VAT registered' }]} />
      </Card>
      <Card>
        <H>Paying them</H>
        <Chips value={f.onAccount} onChange={set('onAccount')} testIDPrefix="sup-account" options={[{ value: false, label: 'Pay on delivery' }, { value: true, label: 'On account' }]} />
        {f.onAccount ? <Field testID="sup-terms" label="Days to pay" value={f.termsDays} onChangeText={set('termsDays')} keyboardType="number-pad" /> : null}
        <Label>Contractor (provisional tax)</Label>
        <Chips value={f.withholdPct ? 5 : 0} onChange={(v) => set('withholdPct')(v)} testIDPrefix="sup-prov" options={[{ value: 0, label: 'No' }, { value: 5, label: 'Yes – keep back 5%' }]} />
        <Hint>For contractors and people paid commission (builders, cleaners, repairers…): once you pay them more than $1,000 (without VAT) in a year, 5% is kept back from each payment and paid to FRCS by the end of the next month. Not for suppliers of goods, or if they give you an exemption letter.</Hint>
        <Label>Usually paid by</Label>
        <Chips value={f.payMethod} onChange={set('payMethod')} testIDPrefix="sup-method" options={[{ value: 'cheque', label: 'BSP cheque' }, { value: 'cash', label: 'Cash' }, { value: 'transfer', label: 'Bank transfer' }]} />
        {f.payMethod === 'transfer' ? (
          <>
            <Field label="Their bank" value={f.bankName} onChangeText={set('bankName')} />
            <Field label="Their account number" value={f.bankAccount} onChangeText={set('bankAccount')} />
          </>
        ) : null}
        <Select label="Usual category" value={f.category} onChange={set('category')} options={[{ value: '', label: '—' }].concat(rules.categories.map((c) => ({ value: c, label: c })))} />
      </Card>
      <Card>
        <Field label="Contact person" value={f.contact} onChangeText={set('contact')} />
        <Field label="Phone" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
        <Field label="Email" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
        <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
        <Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'In use' }, { value: false, label: 'Not used any more' }]} />
      </Card>
    </Screen>
  );
}

export function ApRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = AP.apRules();
  const [f, setF] = useState({ ...r0, vatRate: String(r0.vatRate), dueSoonDays: String(r0.dueSoonDays), defaultTermsDays: String(r0.defaultTermsDays), staleMonths: String(r0.staleMonths), categories: r0.categories.join('\n') });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const yn = (k, a, b) => <Chips value={f[k]} onChange={set(k)} options={[{ value: true, label: a }, { value: false, label: b }]} />;
  return (
    <Screen title="Invoice rules" subtitle="For every device" footer={<Btn testID="rules-save" title="Save" icon="💾" variant="success" onPress={() => act(() => AP.saveApRules(user, f), 'Saved')} />}>
      <Card>
        <Field testID="rules-vat" label="VAT rate %" value={f.vatRate} onChangeText={set('vatRate')} keyboardType="decimal-pad" />
        <Field testID="rules-soon" label="Warn this many days before an invoice is due" value={f.dueSoonDays} onChangeText={set('dueSoonDays')} keyboardType="number-pad" />
        <Field label="Days to pay for new on-account suppliers" value={f.defaultTermsDays} onChangeText={set('defaultTermsDays')} keyboardType="number-pad" />
        <Field label="Flag cheques not cleared after (months)" value={f.staleMonths} onChangeText={set('staleMonths')} keyboardType="number-pad" />
      </Card>
      <Card>
        <Label>Invoices must be checked before they are paid</Label>{yn('checkBeforePay', 'Yes', 'No')}
        <Label>Every invoice needs a photo</Label>{yn('requirePhoto', 'Yes', 'No')}
        <Label>Google reads invoice photos when online</Label>{yn('readPhotos', 'Yes', 'No')}
      </Card>
      <Card>
        <Field label="Categories (one per line)" value={f.categories} onChangeText={set('categories')} multiline />
      </Card>
    </Screen>
  );
}

// ---------------------------------------------------------------- regular bills & loans
export function RecurringScreen() {
  const { nav, user } = useApp();
  const act = useAct();
  const bills = listRecurring({ kind: 'bill', includeInactive: true });
  const loans = listRecurring({ kind: 'loan', includeInactive: true });
  return (
    <Screen title="Regular bills & loans" subtitle="Their invoices are made before they are due">
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="rec-add-bill" title="Add a regular bill" icon="➕" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('RecurringEdit', { kind: 'bill' })} />
        <Btn testID="rec-add-loan" title="Add a loan" icon="🏦" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('RecurringEdit', { kind: 'loan' })} />
      </View>
      <Btn title="Make the invoices that are coming up now" size="md" variant="secondary" onPress={() => act(() => runRecurring(user), 'Done')} />
      <Section title="Loans">
        {!loans.length ? <Text style={{ fontSize: 16, color: C.sub }}>No loans added.</Text> : null}
        {loans.map((r) => {
          const st = loanStatement(r.uid);
          return <ListItem key={r.uid} testID={`loan-${r.name}`} onPress={() => nav.push('Loan', { uid: r.uid })} title={r.name} tone={st.overdue.length ? 'danger' : undefined}
            sub={`${r.supplier_name}${r.loan_no ? ` · ${r.loan_no}` : ''} · ${$(r.amount)} ${FREQ_LABEL[r.frequency].toLowerCase()} · next ${r.next_date}${r.active ? '' : ' · finished'}`}
            right={$(st.balance)} rightSub="balance left" badge={st.overdue.length ? 'OVERDUE' : null} badgeColor={C.danger} />;
        })}
      </Section>
      <Section title="Regular bills">
        {!bills.length ? <Text style={{ fontSize: 16, color: C.sub }}>No regular bills added (rent, power, phone…).</Text> : null}
        {bills.map((r) => <ListItem key={r.uid} onPress={() => nav.push('RecurringEdit', { uid: r.uid })} title={r.name} sub={`${r.supplier_name} · ${FREQ_LABEL[r.frequency]} · next ${r.next_date}${r.active ? '' : ' · stopped'}`} right={$(r.amount)} />)}
      </Section>
    </Screen>
  );
}

export function RecurringEditScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const r0 = params.uid ? getRecurring(params.uid) : null;
  const kind = r0 ? r0.kind : params.kind;
  const [f, setF] = useState(() => (r0 ? {
    uid: r0.uid, kind, name: r0.name, supplierUid: r0.supplier_uid, amount: String(r0.amount), vatType: r0.vat_type, frequency: r0.frequency, nextDate: r0.next_date, endDate: r0.end_date || '',
    leadDays: String(r0.lead_days), shopCode: r0.shop_code || '', category: r0.category || '', loanNo: r0.loan_no || '', security: r0.security || '', openingBalance: r0.opening_balance == null ? '' : String(r0.opening_balance),
    openingDate: r0.opening_date || '', interestRate: r0.interest_rate == null ? '' : String(r0.interest_rate), notes: r0.notes || '', active: !!r0.active,
  } : { kind, name: '', supplierUid: '', amount: '', vatType: 'standard', frequency: 'monthly', nextDate: dateStr(), endDate: '', leadDays: '7', shopCode: '', category: '', loanNo: '', security: '', openingBalance: '', openingDate: dateStr(), interestRate: '', notes: '', active: true }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const loan = kind === 'loan';
  return (
    <Screen title={r0 ? r0.name : loan ? 'New loan' : 'New regular bill'} footer={<Btn testID="rec-save" title="Save" icon="💾" variant="success" onPress={() => { if (act(() => saveRecurring(user, f), 'Saved')) nav.pop(); }} />}>
      <Card>
        <Field testID="rec-name" label="Name" value={f.name} onChangeText={set('name')} placeholder={loan ? 'e.g. Shop 1 Drasa Ave business loan' : 'e.g. Shop 2 rent'} />
        <Select testID="rec-supplier" label={loan ? 'Lender' : 'Paid to'} value={f.supplierUid} onChange={set('supplierUid')} options={AP.listSuppliers().map((s) => ({ value: s.uid, label: s.name }))} />
        <Text style={{ fontSize: 14, color: C.sub }}>Not in the list? Add it first in Suppliers (e.g. BSP, Credit Corp, EFL, landlord).</Text>
        {loan ? (
          <>
            <Field testID="rec-loanno" label="Loan / account number" value={f.loanNo} onChangeText={set('loanNo')} />
            <Field label="Security (e.g. vehicle PB 113, Shop 1)" value={f.security} onChangeText={set('security')} />
            <MoneyField testID="rec-opening" label="Balance owing on the start date" value={f.openingBalance} onChange={set('openingBalance')} />
            <DateField testID="rec-opendate" label="Start date (date of that balance)" value={f.openingDate} onChange={set('openingDate')} />
            <Field label="Interest rate % a year (for your records)" value={f.interestRate} onChangeText={set('interestRate')} keyboardType="decimal-pad" />
          </>
        ) : null}
      </Card>
      <Card>
        <MoneyField testID="rec-amount" label={loan ? 'Repayment amount' : 'Amount (usual bill)'} value={f.amount} onChange={set('amount')} />
        {!loan ? <Chips value={f.vatType} onChange={set('vatType')} options={[{ value: 'standard', label: 'Includes VAT' }, { value: 'zero', label: 'No VAT' }]} /> : null}
        <Label>How often</Label>
        <Chips value={f.frequency} onChange={set('frequency')} testIDPrefix="rec-freq" options={Object.entries(FREQ_LABEL).map(([value, label]) => ({ value, label }))} />
        <DateField testID="rec-next" label="Next due date" value={f.nextDate} onChange={set('nextDate')} />
        <Field label="Make the invoice this many days before" value={f.leadDays} onChangeText={set('leadDays')} keyboardType="number-pad" />
        <DateField label="Last payment date (optional)" value={f.endDate} onChange={set('endDate')} />
        <Label>Shop</Label>
        <Chips value={f.shopCode} onChange={set('shopCode')} options={shopOpts()} />
        <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
        <Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'Active' }, { value: false, label: loan ? 'Paid off / stopped' : 'Stopped' }]} />
      </Card>
    </Screen>
  );
}

export function LoanScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const [e, setE] = useState(null);
  const st = loanStatement(params.uid);
  if (!st) return <Screen title="Loan"><Text>Not found.</Text></Screen>;
  const r = st.loan;
  return (
    <Screen title={r.name} subtitle={`${r.supplier_name}${r.loan_no ? ` · ${r.loan_no}` : ''}`}>
      <Card>
        <Row label="Balance left" value={$(st.balance)} bold color={C.danger} />
        <Row label="Repaid since start" value={$(st.paid)} color={C.success} />
        <Row label="Repayment" value={`${$(r.amount)} · ${FREQ_LABEL[r.frequency]}`} />
        <Row label="Next due" value={r.next_date} />
        {r.security ? <Row label="Security" value={r.security} /> : null}
        {r.interest_rate != null ? <Row label="Interest rate" value={`${r.interest_rate}% a year`} /> : null}
      </Card>
      {st.overdue.length ? <Banner tone="danger" title={`${st.overdue.length} repayment(s) overdue`} message="Open Invoices › Overdue to pay them." /> : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn title="Change loan" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('RecurringEdit', { uid: r.uid })} />
        <Btn testID="loan-entry" title="Add interest / fee from statement" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setE({ type: 'interest', amount: '', date: dateStr(), note: '' })} />
      </View>
      {e ? (
        <Card>
          <Chips value={e.type} onChange={(v) => setE({ ...e, type: v })} options={[{ value: 'interest', label: 'Interest' }, { value: 'fee', label: 'Fee' }, { value: 'adjust_up', label: 'Correction +' }, { value: 'adjust_down', label: 'Correction −' }]} />
          <MoneyField testID="loan-amount" label="Amount" value={e.amount} onChange={(v) => setE({ ...e, amount: v })} />
          <DateField label="Date" value={e.date} onChange={(v) => setE({ ...e, date: v })} />
          <Field label="Note" value={e.note} onChangeText={(v) => setE({ ...e, note: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setE(null)} />
            <Btn testID="loan-entry-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => addLoanEntry(user, { ...e, recurringUid: r.uid }), 'Saved')) setE(null); }} />
          </View>
        </Card>
      ) : null}
      <Section title="Statement">
        <Table columns={[{ key: 'date', title: 'Date' }, { key: 'what', title: 'What', width: 260 }, { key: 'ref', title: 'Invoice no', width: 150 }, { key: 'chg', title: 'Change', align: 'right' }, { key: 'bal', title: 'Balance', align: 'right', bold: true }]}
          rows={st.rows.map((x) => ({ date: x.date, what: x.what, ref: x.ref || '', chg: x.change == null ? '' : `${x.change > 0 ? '+' : ''}${$(x.change)}`, bal: $(x.balance) }))} />
      </Section>
    </Screen>
  );
}
