// Invoices & Payments: suppliers, invoices (photo + Google reading), due flags, paying by cheque / cash /
// transfer with a pay trail, supplier credit notes, BSP cheque books and balancing.
// Everything works offline and syncs. Nothing is deleted: mistakes are voided with a reason.
import { db } from '../../db/connection.js';
import { payMethod } from './payMethods.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, getShared, setShared, money, sensibleAmount, realDate } from '../../services/core.js';
import { addPhotos, enqueue } from '../../services/stock.js';
import { parseInvoiceText } from './parser.js';
import { assertOpen } from '../../services/lock.js';
import { needReason, requireSetup, can } from '../../services/access.js';
import { requirePerm, asService, requireShop } from '../../services/guard.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (cond, msg) => { if (!cond) throw new AppError(msg); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });
export const $ = (n) => money(r2(n));

// ---------------------------------------------------------------- rules (admin)
export const AP_DEFAULTS = {
  vatRate: 12.5,            // % (Fiji standard rate)
  dueSoonDays: 3,           // "due soon" warning this many days before the due date
  defaultTermsDays: 7,      // on-account suppliers: days to pay
  checkBeforePay: true,     // an invoice must be checked before it can be paid
  requirePhoto: false,      // every invoice needs a photo
  readPhotos: true,         // ask Google to read invoice photos when online
  staleMonths: 6,           // cheques not cleared after this many months are flagged
  categories: ['Stock for resale', 'Bakery ingredients', 'Liquor', 'Rent', 'Power & water', 'Phone & internet', 'Repairs', 'Transport & fuel', 'Packaging', 'Cleaning', 'Office', 'Other'],
};
export function apRules() {
  return { ...AP_DEFAULTS, ...(getShared('ap_rules', {}) || {}) };
}
export function saveApRules(user, r) {
  requirePerm(user, 'ap_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'ap_setup');
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const cats = (Array.isArray(r.categories) ? r.categories : String(r.categories || '').split('\n')).map(txt).filter(Boolean);
  const clean = {
    vatRate: n(r.vatRate, 0, 30, 'VAT rate'), dueSoonDays: Math.round(n(r.dueSoonDays, 0, 60, 'Due-soon days')),
    defaultTermsDays: Math.round(n(r.defaultTermsDays, 0, 180, 'Terms days')), checkBeforePay: !!r.checkBeforePay,
    requirePhoto: !!r.requirePhoto, readPhotos: !!r.readPhotos, staleMonths: Math.round(n(r.staleMonths, 1, 24, 'Months')),
    categories: cats.length ? Array.from(new Set(cats)) : AP_DEFAULTS.categories,
  };
  const before = apRules();
  setShared('ap_rules', clean);
  audit({ user, action: 'Changed invoice rules', table: 'shared_settings', recordUid: 'ap_rules', before, after: clean });
  return clean;
  });
}

// ---------------------------------------------------------------- suppliers
export function listSuppliers({ includeInactive = false, q = '' } = {}) {
  const like = `%${txt(q).toLowerCase()}%`;
  return db().all(`SELECT * FROM ap_suppliers WHERE (? = 1 OR active = 1) AND (lower(name) LIKE ? OR ifnull(tin,'') LIKE ?) ORDER BY name`,
    [includeInactive ? 1 : 0, like, like]);
}
export function getSupplier(uid) {
  return uid ? db().get('SELECT * FROM ap_suppliers WHERE uid = ?', [uid]) : null;
}
const before0 = (uid) => (uid ? db().get('SELECT withhold_pct FROM ap_suppliers WHERE uid = ?', [uid]) : null);
export function saveSupplier(user, s) {
  requirePerm(user, 'ap_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const name = txt(s.name);
  need(name, 'Enter the supplier name.');
  const tin = txt(s.tin).replace(/[\s-]/g, '');
  need(!tin || /^\d{6,15}$/.test(tin), 'The TIN should be numbers only.');
  const dupe = db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?) AND uid <> ?', [name, s.uid || '']);
  need(!dupe, `There is already a supplier called ${name}.`);
  if (tin) {
    const t = db().get('SELECT name FROM ap_suppliers WHERE tin = ? AND uid <> ?', [tin, s.uid || '']);
    need(!t, `TIN ${tin} is already used by ${t && t.name}.`);
  }
  const terms = Math.round(Number(s.termsDays === undefined || s.termsDays === '' ? apRules().defaultTermsDays : s.termsDays));
  need(Number.isFinite(terms) && terms >= 0 && terms <= 180, 'Days to pay must be between 0 and 180.');
  need(['cheque', 'cash', 'transfer'].includes(s.payMethod || 'cheque'), 'Choose how this supplier is paid.');
  const uid = s.uid || uuid('S');
  const before = getSupplier(uid);
  // 1.0.0 build 3: a supplier's bank details decide where money goes – only the owner, admin or whoever sets up
  // suppliers / makes payments may change them, and the owner is told.
  const bankNow = { name: txt(s.bankName) || null, acc: txt(s.bankAccount) || null };
  const bankChanged = before && (bankNow.name !== (before.bank_name || null) || bankNow.acc !== (before.bank_account || null)) && (bankNow.name || bankNow.acc || before.bank_account);
  if (bankChanged) need(user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || can(user, 'ap_setup') || can(user, 'payments_make')), 'Only the owner, admin or the person who makes payments can change a supplier\'s bank details.');
  const { now, dev } = meta();
  const wp = s.withholdPct === undefined ? (before0(s.uid) || {}).withhold_pct || 0 : Math.max(0, Math.min(20, Number(s.withholdPct) || 0));
  const row = [name, tin || null, s.vatRegistered === false ? 0 : 1, s.onAccount ? 1 : 0, terms, s.payMethod || 'cheque', txt(s.contact) || null, txt(s.phone) || null,
    txt(s.email) || null, txt(s.bankName) || null, txt(s.bankAccount) || null, txt(s.category) || null, txt(s.notes) || null, s.active === false ? 0 : 1, now, dev];
  // needs_setup: typed on the photo screen, still to be "added properly" (TIN, terms…). Saving it from the supplier screen clears it.
  const setWp = () => {
    db().run('UPDATE ap_suppliers SET withhold_pct = ? WHERE uid = ?', [wp || null, uid]);
    if (s.needsSetup !== undefined) db().run('UPDATE ap_suppliers SET needs_setup = ? WHERE uid = ?', [s.needsSetup ? 1 : 0, uid]);
  };
  if (before) {
    db().run(`UPDATE ap_suppliers SET name=?, tin=?, vat_registered=?, on_account=?, terms_days=?, pay_method=?, contact=?, phone=?, email=?, bank_name=?, bank_account=?, category=?, notes=?, active=?,
      updated_at=?, updated_device=?, sync_status='pending' WHERE uid=?`, row.concat([uid]));
    setWp();
    if (before.name !== name) db().run("UPDATE ap_invoices SET supplier_name = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE supplier_uid = ?", [name, now, dev, uid]);
  } else {
    db().run(`INSERT INTO ap_suppliers (name, tin, vat_registered, on_account, terms_days, pay_method, contact, phone, email, bank_name, bank_account, category, notes, active, updated_at, updated_device, uid)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, row.concat([uid]));
    setWp();
  }
  audit({ user, action: before ? `Changed supplier ${name}${bankChanged ? ' – BANK DETAILS' : ''}` : `Added supplier ${name}`, table: 'ap_suppliers', recordUid: uid, before, after: { name, tin, onAccount: !!s.onAccount, terms, bankName: bankNow.name, bankAccount: bankNow.acc } });
  if (bankChanged) { try { require('../verify/service.js').notify('alerts_urgent', `Supplier ${name}: bank details changed by ${user ? user.name : '?'} (${before.bank_account || 'none'} → ${bankNow.acc || 'none'}). Check before paying.`); } catch (e) { /* only a message */ } }
  return getSupplier(uid);
  });
}
// Match a name / TIN read from an invoice to a known supplier.
export function matchSupplier(name, tin) {
  const t = txt(tin).replace(/[\s-]/g, '');
  if (t) { const s = db().get('SELECT * FROM ap_suppliers WHERE tin = ?', [t]); if (s) return s; }
  const n = txt(name).toLowerCase().replace(/[^a-z0-9]/g, '');
  if (n.length < 3) return null;
  return listSuppliers().find((s) => { const k = s.name.toLowerCase().replace(/[^a-z0-9]/g, ''); return k === n || (k.length >= 4 && (n.includes(k) || k.includes(n))); }) || null;
}

// A supplier name typed on the photo screen (not in the list): added straight away so the invoice / cheque can be
// saved, but flagged "add properly" until someone fills in the TIN, terms… on the supplier screen.
export function addTypedSupplier(user, name) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const n = txt(name);
  need(n, 'Type the supplier name.');
  const same = db().get('SELECT * FROM ap_suppliers WHERE lower(name) = lower(?)', [n]);
  if (same) return same;
  return saveSupplier(user, { name: n, needsSetup: true, notes: `Typed on the photo screen by ${user.name} – add properly (TIN, terms, how paid).` });
  });
}
export function suppliersToSetUp() {
  try { return db().all('SELECT * FROM ap_suppliers WHERE needs_setup = 1 AND active = 1 ORDER BY name'); } catch (e) { return []; }
}

// ---------------------------------------------------------------- VAT
export function standardVat(total, rate = apRules().vatRate) {
  return r2((Number(total) * rate) / (100 + rate));
}
// vatType: 'standard' (all at the standard rate), 'zero' (zero-rated / exempt), 'mixed' (enter the VAT and the zero-rated part)
export function workOutVat({ total, vatType, vat, zeroRated }, rate = apRules().vatRate) {
  const t = r2(total);
  if (vatType === 'zero') return { vat: 0, zeroRated: t };
  if (vatType === 'mixed') {
    const z = r2(zeroRated);
    need(z >= 0 && z <= t, 'The zero-rated part must be between 0 and the total.');
    const v = vat === '' || vat === null || vat === undefined ? standardVat(t - z, rate) : r2(vat);
    need(v >= 0 && v <= standardVat(t - z, rate) + 0.05, `VAT can be at most ${$(standardVat(t - z, rate))} for this total.`);
    return { vat: v, zeroRated: z };
  }
  return { vat: standardVat(t, rate), zeroRated: 0 };
}

// ---------------------------------------------------------------- invoices
const paidSql = `(SELECT IFNULL(SUM(a.amount), 0) FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = i.uid)`;
// For a credit note: how much of it has been used against invoices.
const usedSql = `(SELECT IFNULL(SUM(p.amount), 0) FROM ap_payments p WHERE p.credit_uid = i.uid AND p.status = 'active')`;

export const DUE_LABEL = { overdue: 'Overdue', due_today: 'Due today', due_soon: 'Due soon', not_due: 'Not due yet', paid: 'Paid', void: 'Void', credit: 'Credit', to_read: 'Waiting to be read' };

function decorate(i, today = dateStr(), rules = apRules()) {
  if (!i) return i;
  const paid = r2(i.kind === 'credit' ? i.used : i.paid);
  const owing = r2(i.total - paid);
  let due = 'not_due';
  if (i.status === 'void') due = 'void';
  else if (i.kind === 'credit') due = 'credit';
  else if (!i.total) due = 'to_read';
  else if (owing <= 0.004) due = 'paid';
  else if (i.due_date < today) due = 'overdue';
  else if (i.due_date === today) due = 'due_today';
  else if (i.due_date <= addDays(today, rules.dueSoonDays)) due = 'due_soon';
  const days = Math.round((new Date(`${i.due_date}T00:00:00`) - new Date(`${today}T00:00:00`)) / 86400000);
  return { ...i, paid, owing: Math.max(0, owing), partPaid: paid > 0 && owing > 0.004, due, daysToDue: days, photos: parseList(i.photo_urls) };
}
function parseList(v) { try { const a = JSON.parse(v || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }

export function getInvoice(uid) {
  return decorate(db().get(`SELECT i.*, ${paidSql} AS paid, ${usedSql} AS used FROM ap_invoices i WHERE i.uid = ?`, [uid]));
}
// 1.0.0 many invoices at once, each exactly as getInvoice gives it (one read instead of one per invoice).
// `where` uses the alias i; `order` is the ORDER BY.
export function getInvoicesWhere(where, params = [], order = 'i.rowid') {
  const today = dateStr();
  const rules = apRules();
  return db().all(`SELECT i.*, ${paidSql} AS paid, ${usedSql} AS used FROM ap_invoices i WHERE ${where} ORDER BY ${order}`, params).map((r) => decorate(r, today, rules));
}
// filter: 'unpaid' | 'overdue' | 'due' (overdue + today + soon) | 'to_check' | 'paid' | 'credits' | 'void' | 'all'
export function listInvoices({ filter = 'unpaid', supplierUid, shopCode, q = '', from, to, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (supplierUid) { w.push('i.supplier_uid = ?'); a.push(supplierUid); }
  if (shopCode) { w.push('i.shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('i.invoice_date >= ?'); a.push(from); }
  if (to) { w.push('i.invoice_date <= ?'); a.push(to); }
  if (txt(q)) { w.push("(lower(i.supplier_name) LIKE ? OR lower(ifnull(i.invoice_no,'')) LIKE ?)"); a.push(`%${txt(q).toLowerCase()}%`, `%${txt(q).toLowerCase()}%`); }
  if (filter === 'void') w.push("i.status = 'void'");
  else if (filter !== 'all') w.push("i.status <> 'void'");
  if (filter === 'credits') w.push("i.kind = 'credit'");
  else if (!['all', 'void'].includes(filter)) w.push("i.kind = 'invoice'");
  if (filter === 'to_check') w.push("i.status = 'to_check'");
  // Owing / paid is decided in SQL so the limit never hides an unpaid invoice behind old paid ones.
  if (['unpaid', 'due', 'overdue', 'part'].includes(filter)) w.push(`(i.total = 0 OR i.total - ${paidSql} > 0.004)`);
  if (filter === 'credits') w.push(`i.total - ${usedSql} > 0.004`);
  if (filter === 'paid') w.push(`i.total > 0 AND i.total - ${paidSql} <= 0.004`);
  const order = ['paid', 'all', 'void'].includes(filter) ? 'i.invoice_date DESC, i.due_date DESC' : 'i.due_date, i.invoice_date';
  const rows = db().all(`SELECT i.*, ${paidSql} AS paid, ${usedSql} AS used FROM ap_invoices i WHERE ${w.join(' AND ')} ORDER BY ${order} LIMIT ?`, a.concat([limit]));
  const today = dateStr();
  const rules = apRules();
  const out = rows.map((r) => decorate(r, today, rules));
  if (filter === 'unpaid') return out.filter((i) => i.owing > 0.004 || i.due === 'to_read');
  if (filter === 'overdue') return out.filter((i) => i.due === 'overdue');
  if (filter === 'part') return out.filter((i) => i.partPaid);
  if (filter === 'due') return out.filter((i) => ['overdue', 'due_today', 'due_soon'].includes(i.due));
  if (filter === 'paid') return out.filter((i) => i.due === 'paid');
  if (filter === 'credits') return out.filter((i) => i.owing > 0.004);
  return out;
}

const normNo = (v) => txt(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
export function findDuplicate({ supplierUid, supplierName, invoiceNo, exceptUid }) {
  const no = normNo(invoiceNo);
  if (!no) return null;
  return db().all(`SELECT * FROM ap_invoices WHERE status <> 'void' AND uid <> ? AND invoice_no IS NOT NULL AND (supplier_uid = ? OR lower(supplier_name) = lower(?))`,
    [exceptUid || '', supplierUid || '-', txt(supplierName)]).find((r) => normNo(r.invoice_no) === no) || null;
}

// build 30 (owner, 10 Nov: "there shouldn't be a double entry of invoice or cheque – the app should prompt"): the same
// supplier, the same total and a date within 2 days, entered already – the number may be missing or typed differently.
export function findSimilar({ supplierUid, supplierName, total, invoiceDate, kind = 'invoice', exceptUid }) {
  const t = r2(total);
  if (!(t > 0) || !DATE.test(txt(invoiceDate))) return null;
  return db().all(`SELECT * FROM ap_invoices WHERE status <> 'void' AND uid <> ? AND kind = ? AND abs(total - ?) < 0.005 AND (supplier_uid = ? OR lower(supplier_name) = lower(?))
    AND invoice_date BETWEEN ? AND ? ORDER BY invoice_date`, [exceptUid || '', kind, t, supplierUid || '-', txt(supplierName), addDays(invoiceDate, -2), addDays(invoiceDate, 2)])[0] || null;
}
// Records entered twice that only met after syncing (two phones, offline): the same supplier's invoice number twice,
// or the same cheque number on two live payments of one account. For Home – someone voids the extra one.
export function doubleEntries() {
  const out = { invoices: [], cheques: [] };
  const seen = new Map();
  for (const r of db().all("SELECT uid, kind, supplier_uid, supplier_name, invoice_no, invoice_date, total FROM ap_invoices WHERE status <> 'void' AND invoice_no IS NOT NULL AND invoice_no <> '' ORDER BY entered_at, uid")) {
    const k = `${r.kind}|${r.supplier_uid || txt(r.supplier_name).toLowerCase()}|${normNo(r.invoice_no)}`;
    if (!normNo(r.invoice_no)) continue;
    if (seen.has(k)) out.invoices.push({ first: seen.get(k), again: r }); else seen.set(k, r);
  }
  const cs = new Map();
  for (const p of db().all("SELECT uid, supplier_name, account_uid, cheque_no, amount, pay_date FROM ap_payments WHERE status = 'active' AND method = 'cheque' AND cheque_no IS NOT NULL AND cheque_no <> '' ORDER BY created_at, uid")) {
    const k = `${p.account_uid || ''}|${String(p.cheque_no).replace(/^0+/, '')}`;
    if (cs.has(k)) out.cheques.push({ first: cs.get(k), again: p }); else cs.set(k, p);
  }
  return out;
}

// Save a new invoice / credit note, or change one. photos: new photo file uris to add.
// "Snap now, type later": with a photo and no total, it is saved for Google to read when online.
export function saveInvoice(user, f, { photos = [], allowDuplicate = false, canCheck = false, askSimilar = false, readFields = null } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const rules = apRules();
  const kind = f.kind === 'credit' ? 'credit' : 'invoice';
  const before = f.uid ? getInvoice(f.uid) : null;
  need(!before || before.status !== 'void', 'This invoice was voided and cannot be changed.');
  const total = r2(f.total);
  const hasPhoto = photos.length > 0 || (before && (before.photos.length || before.ocr_status === 'waiting'));
  const snapOnly = !total && hasPhoto && !before?.paid;
  need(snapOnly || total > 0, 'Enter the total (including VAT), or take a photo and let it be read later.');
  sensibleAmount(total, 'The invoice total');
  need(!rules.requirePhoto || hasPhoto, 'A photo of the invoice is required.');
  let supplier = f.supplierUid ? getSupplier(f.supplierUid) : null;
  const newName = txt(f.supplierName);
  if (!supplier && newName) supplier = matchSupplier(newName, f.supplierTin);
  need(supplier || newName || snapOnly, 'Choose the supplier (or type a new supplier name).');
  if (!supplier && newName) supplier = saveSupplier(user, { name: newName, tin: f.supplierTin, onAccount: !!f.onAccount });
  // 1.0.0 build 1 (stream B): the next cigarette lot only once the last cigarette invoice is paid in full (owner / admin may override).
  if (!before && kind === 'invoice' && supplier) { try { require('../till/cigTally.js').guardCigInvoice(user, supplier.uid, { override: !!f.cigOverride, reason: f.cigOverrideReason }); } catch (e) { if (e && e.isAppError) throw e; } }
  const invoiceDate = txt(f.invoiceDate) || dateStr();
  need(DATE.test(invoiceDate), 'Enter the invoice date as YYYY-MM-DD.');
  need(realDate(invoiceDate), `There is no such date as ${invoiceDate}. Check the day and the month.`);
  need(invoiceDate >= addDays(dateStr(), -5 * 366) || (before && before.invoice_date === invoiceDate), 'The invoice date is more than 5 years ago. Check the year.');
  need(invoiceDate <= addDays(dateStr(), 7) || (before && before.invoice_date === invoiceDate), 'The invoice date is in the future.');
  assertOpen(invoiceDate, 'This invoice');
  if (before) assertOpen(before.invoice_date, 'This invoice');
  const onAccount = f.onAccount === undefined ? !!(supplier && supplier.on_account) : !!f.onAccount;
  const terms = supplier ? supplier.terms_days : rules.defaultTermsDays;
  const dueDate = txt(f.dueDate) || (onAccount ? addDays(invoiceDate, terms) : invoiceDate);
  need(DATE.test(dueDate) && dueDate >= invoiceDate, 'The due date must be on or after the invoice date.');
  if (before && before.paid > 0) {
    need(total >= before.paid - 0.004, `${$(before.paid)} has already been paid on this invoice. Void the payment first to lower the total.`);
    need(!supplier || supplier.uid === before.supplier_uid, 'The supplier cannot be changed after a payment. Void the payment first.');
  }
  // Loan repayments carry no VAT.
  const vatType = /loan/i.test(txt(f.category)) ? 'zero' : ['standard', 'zero', 'mixed'].includes(f.vatType) ? f.vatType : (supplier && !supplier.vat_registered ? 'zero' : 'standard');
  const v = total ? workOutVat({ total, vatType, vat: f.vat, zeroRated: f.zeroRated }, rules.vatRate) : { vat: 0, zeroRated: 0 };
  const invoiceNo = txt(f.invoiceNo).toUpperCase() || null;
  if (!allowDuplicate && invoiceNo) {
    const d = findDuplicate({ supplierUid: supplier && supplier.uid, supplierName: supplier ? supplier.name : newName, invoiceNo, exceptUid: f.uid });
    if (d) { const e = new AppError(`Invoice ${invoiceNo} from ${d.supplier_name} is already entered (${d.invoice_date}, ${$(d.total)}).`); e.duplicate = d; throw e; }
  }
  // build 30: no number, or a different one – the same supplier, total and (nearly) date is asked about too
  if (askSimilar && !allowDuplicate && !before && total > 0 && (supplier || newName)) { // typed by a person (not top-ups, bills, repeats)
    const sm = findSimilar({ supplierUid: supplier && supplier.uid, supplierName: supplier ? supplier.name : newName, total, invoiceDate, kind, exceptUid: f.uid });
    if (sm) {
      const e = new AppError(`${kind === 'credit' ? 'A credit note' : 'An invoice'} from ${sm.supplier_name} for ${$(sm.total)} dated ${sm.invoice_date}${sm.invoice_no ? ` (no. ${sm.invoice_no})` : ' (no number)'} is already entered${sm.entered_by_name ? ` by ${sm.entered_by_name}` : ''}. Is this the same one?`);
      e.duplicate = sm; e.similar = true; throw e;
    }
  }
  const { now, dev } = meta();
  const uid = f.uid || uuid(kind === 'credit' ? 'CN' : 'IN');
  const status = before && before.status === 'approved' && !canCheck ? 'to_check' : (canCheck && total ? 'approved' : 'to_check');
  // build 34: the first save after the AI / Google read it is the person's check of that reading (learned from below)
  const ocr = snapOnly ? (rules.readPhotos ? 'waiting' : 'type') : (before ? (before.ocr_status === 'read' ? 'read_checked' : before.ocr_status) : null);
  const vals = {
    kind, supplier_uid: supplier ? supplier.uid : null, supplier_name: supplier ? supplier.name : '(photo – not read yet)', supplier_tin: supplier ? supplier.tin : (txt(f.supplierTin) || null),
    invoice_no: invoiceNo, invoice_date: invoiceDate, received_date: txt(f.receivedDate) || (before ? before.received_date : dateStr()), shop_code: f.shopCode || null,
    on_account: onAccount ? 1 : 0, pay_method: onAccount ? null : (txt(f.payMethod) || (before ? before.pay_method : null) || (supplier && supplier.pay_method) || null), due_date: dueDate, total, vat: v.vat, zero_rated: v.zeroRated, vat_type: vatType, category: txt(f.category) || (supplier && supplier.category) || null,
    description: txt(f.description) || null, ocr_status: ocr, status, notes: txt(f.notes) || null,
    checked_by_uid: status === 'approved' ? user.uid : null, checked_by_name: status === 'approved' ? user.name : null, checked_at: status === 'approved' ? now : null,
    updated_at: now, updated_device: dev,
  };
  if (before) {
    const cols = Object.keys(vals);
    db().run(`UPDATE ap_invoices SET ${cols.map((c) => `${c} = ?`).join(', ')}, sync_status = 'pending' WHERE uid = ?`, cols.map((c) => vals[c]).concat([uid]));
  } else {
    Object.assign(vals, { uid, entered_by_uid: user.uid, entered_by_name: user.name, entered_at: now, photo_urls: '[]' });
    const cols = Object.keys(vals);
    db().run(`INSERT INTO ap_invoices (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, cols.map((c) => vals[c]));
  }
  if (photos.length) {
    addPhotos('invoice', uid, photos);
    if (snapOnly && rules.readPhotos) enqueue('ocr', { invoiceUid: uid });
  }
  // build 34 (owner: "it needs to learn each time"): every invoice saved teaches the app about its supplier's invoices
  if (vals.supplier_uid && total > 0 && kind === 'invoice') {
    const readBefore = before && before.ocr_status === 'read' ? { invoiceNo: before.invoice_no, total: before.total, vat: before.vat, invoiceDate: before.invoice_date } : null;
    try { require('./invoiceLearn.js').learnInvoice(user, vals.supplier_uid, { read: readFields || readBefore, saved: { invoiceNo, total, vat: vals.vat, invoiceDate, vatType: vals.vat_type } }); } catch (e) { /* never stops the save */ }
    // Release 06 (owner: "the suppliers do not have their products paired up"): every line read on the invoice goes on
    // the supplier's product list with its cost and date – sure matches link by themselves, the rest wait for one "Yes".
    if (readFields && Array.isArray(readFields.itemLines) && readFields.itemLines.length) {
      try { keepInvoiceLines(user, vals.supplier_uid, vals.supplier_name, invoiceDate, readFields.itemLines, 'invoice'); } catch (e) { /* never stops the save */ }
    }
  }
  audit({ user, action: `${before ? 'Changed' : 'Entered'} ${kind === 'credit' ? 'credit note' : 'invoice'} ${invoiceNo || ''} ${vals.supplier_name} ${$(total)}`.replace(/\s+/g, ' '),
    table: 'ap_invoices', recordUid: uid, before: before && { total: before.total, due: before.due_date, no: before.invoice_no }, after: { total, due: dueDate, no: invoiceNo } });
  return getInvoice(uid);
  });
}

export function checkInvoice(user, uid) {
  requirePerm(user, 'invoices_check', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const i = getInvoice(uid);
  need(i, 'Invoice not found.');
  need(i.status === 'to_check', i.status === 'void' ? 'This invoice is void.' : 'Already checked.');
  need(i.total > 0 && i.supplier_uid, 'Fill in the supplier and the total first.');
  need(!i.entered_by_uid || i.entered_by_uid !== user.uid || canSelfCheck(user), 'Someone else must check an invoice you entered.');
  const { now, dev } = meta();
  db().run(`UPDATE ap_invoices SET status = 'approved', checked_by_uid = ?, checked_by_name = ?, checked_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [user.uid, user.name, now, now, dev, uid]);
  audit({ user, action: `Checked invoice ${i.invoice_no || ''} ${i.supplier_name}`, table: 'ap_invoices', recordUid: uid });
  });
}
// Owners/admins may check their own entries (small shops often have one person doing both).
function canSelfCheck(user) { return ['owner', 'admin'].includes(user.role); }

export function voidInvoice(user, uid, reason) {
  requirePerm(user, 'invoices_check', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  { const x = getInvoice(uid); if (x) assertOpen(x.invoice_date, 'This record'); }
  const i = getInvoice(uid);
  need(i, 'Invoice not found.');
  need(i.status !== 'void', 'Already void.');
  needReason(user, reason, 'Give a reason for voiding.');
  need(!(i.kind === 'credit' ? i.used : i.paid), 'Payments are recorded against it. Void those payments first.');
  const { now, dev } = meta();
  db().run(`UPDATE ap_invoices SET status = 'void', void_reason = ?, voided_by_name = ?, voided_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [txt(reason), user.name, now, now, dev, uid]);
  audit({ user, action: `Voided invoice ${i.invoice_no || ''} ${i.supplier_name} ${$(i.total)}`, table: 'ap_invoices', recordUid: uid, reason });
  });
}

// The text Google read from the photo: fill in whatever is still empty. A checked invoice is never changed.
export function applyReadText(uid, text) {
  const i = getInvoice(uid);
  if (!i) return null;
  const rules = apRules();
  const known = listSuppliers().map((s) => ({ name: s.name, tin: s.tin }));
  const p = parseInvoiceText(text || '', known, rules.vatRate / 100);
  const { now, dev } = meta();
  if (!text || i.status !== 'to_check' || i.total) {
    db().run(`UPDATE ap_invoices SET ocr_status = ?, ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [text ? 'read' : 'unreadable', text ? p.notes.join(' | ') : 'The photo could not be read. Please type the details.', now, dev, uid]);
    return getInvoice(uid);
  }
  const sup = matchSupplier(p.supplier, p.supplier_tin);
  const total = r2(p.total || 0);
  const vat = p.vat === null ? 0 : r2(p.vat);
  const vatType = !total ? 'standard' : !vat ? 'zero' : Math.abs(vat - standardVat(total, rules.vatRate)) <= 0.1 ? 'standard' : 'mixed';
  const invoiceDate = p.invoice_date || i.invoice_date;
  const onAccount = sup ? !!sup.on_account : !!i.on_account;
  const dueDate = onAccount ? addDays(invoiceDate, sup ? sup.terms_days : rules.defaultTermsDays) : invoiceDate;
  const notes = p.notes.slice();
  if (!sup && p.supplier) notes.unshift(`New supplier? Read as "${p.supplier}".`);
  const dup = findDuplicate({ supplierUid: sup && sup.uid, supplierName: p.supplier, invoiceNo: p.invoice_no, exceptUid: uid });
  if (dup) notes.unshift(`WARNING: looks like a duplicate of ${dup.invoice_no} entered on ${dup.invoice_date}.`);
  db().run(`UPDATE ap_invoices SET supplier_uid = ?, supplier_name = ?, supplier_tin = ?, invoice_no = COALESCE(invoice_no, ?), invoice_date = ?, on_account = ?, due_date = ?, total = ?, vat = ?,
    zero_rated = ?, vat_type = ?, ocr_status = 'read', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
  [sup ? sup.uid : null, sup ? sup.name : (p.supplier || i.supplier_name), sup ? sup.tin : (p.supplier_tin || null), p.invoice_no || null, invoiceDate, onAccount ? 1 : 0, dueDate, total, vatType === 'zero' ? 0 : vat,
    vatType === 'zero' ? total : vatType === 'mixed' ? r2(Math.max(0, total - (vat * (100 + rules.vatRate)) / rules.vatRate)) : 0, vatType, notes.join(' | '), now, dev, uid]);
  return getInvoice(uid);
}

// ---------------------------------------------------------------- pay trail
export function payTrail(invoiceUid) {
  return db().all(`SELECT a.amount AS applied, p.*, c.status AS cheque_status, c.presented_date, b.name AS account_name, cr.invoice_no AS credit_no
    FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid
    LEFT JOIN cheques c ON c.uid = p.cheque_uid LEFT JOIN bank_accounts b ON b.uid = p.account_uid LEFT JOIN ap_invoices cr ON cr.uid = p.credit_uid
    WHERE a.invoice_uid = ? ORDER BY p.pay_date, p.created_at`, [invoiceUid]);
}
export function getPayment(uid) {
  const p = db().get(`SELECT p.*, c.status AS cheque_status, c.presented_date, b.name AS account_name FROM ap_payments p
    LEFT JOIN cheques c ON c.uid = p.cheque_uid LEFT JOIN bank_accounts b ON b.uid = p.account_uid WHERE p.uid = ?`, [uid]);
  if (!p) return null;
  p.allocations = db().all(`SELECT a.amount, i.uid AS invoice_uid, i.invoice_no, i.invoice_date, i.total FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = ? ORDER BY i.invoice_date`, [uid]);
  p.photos = parseList(p.photo_urls);
  return p;
}
// 1.0.0 payments of the same day and time always in the same order (as before on the 3-year data)
export function listPayments({ from, to, supplierUid, method, includeVoid = false, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (from) { w.push('p.pay_date >= ?'); a.push(from); }
  if (to) { w.push('p.pay_date <= ?'); a.push(to); }
  if (supplierUid) { w.push('p.supplier_uid = ?'); a.push(supplierUid); }
  if (method) { w.push('p.method = ?'); a.push(method); }
  if (!includeVoid) w.push("p.status = 'active'");
  return db().all(`SELECT p.*, b.name AS account_name, c.status AS cheque_status FROM ap_payments p LEFT JOIN bank_accounts b ON b.uid = p.account_uid LEFT JOIN cheques c ON c.uid = p.cheque_uid
    WHERE ${w.join(' AND ')} ORDER BY p.pay_date DESC, p.created_at DESC, ${includeVoid ? 'p.rowid DESC' : supplierUid ? 'p.rowid' : 'p.method, p.rowid'} LIMIT ?`, a.concat([limit]));
}

// ---------------------------------------------------------------- paying
// What can be paid for a supplier: invoices still owing (oldest due first) and credit notes not used up.
export function payableFor(supplierUid) {
  const rules = apRules();
  const inv = listInvoices({ filter: 'unpaid', supplierUid }).filter((i) => i.total > 0);
  return {
    invoices: inv.map((i) => ({ ...i, blocked: rules.checkBeforePay && i.status === 'to_check' ? 'Waiting to be checked' : null })),
    credits: listInvoices({ filter: 'credits', supplierUid }).filter((c) => c.status !== 'to_check' || !rules.checkBeforePay),
  };
}

// Use a supplier credit note against invoices of the same supplier.
export function applyCredit(user, { creditUid, allocations, date }) {
  requirePerm(user, 'invoices_check', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getInvoice(creditUid);
  need(c && c.kind === 'credit' && c.status !== 'void', 'Credit note not found.');
  need(!apRules().checkBeforePay || c.status === 'approved', 'The credit note must be checked first.');
  const total = r2((allocations || []).reduce((s, x) => s + r2(x.amount), 0));
  need(total > 0, 'Choose the invoices to use the credit on.');
  need(total <= c.owing + 0.004, `Only ${$(c.owing)} of this credit is left.`);
  return recordPayment(user, { supplierUid: c.supplier_uid, method: 'credit', payDate: date || dateStr(), creditUid, allocations, notes: `Credit note ${c.invoice_no || ''}`.trim() });
  });
}

// Provisional tax: from a contractor (supplier marked "provisional tax"), 5% of the amount without VAT is kept back
// once the payments to them this year (without VAT) pass $1,000. That 5% is paid to FRCS by the end of the next month.
export function withholdingFor(supplierUid, allocations, date = dateStr()) {
  const sup = getSupplier(supplierUid);
  if (!sup || !(Number(sup.withhold_pct) > 0)) return { pct: 0, withheld: 0, exVat: 0, yearBefore: 0 };
  const st = { provTaxThreshold: 1000, provTaxPct: 5, ...(getShared('acct_settings', {}) || {}) };
  const pct = Number(st.provTaxPct) || 0;
  if (!pct) return { pct: 0, withheld: 0, exVat: 0, yearBefore: 0 };
  const exVatOf = (invUid, amt) => { const i = db().get('SELECT total, vat FROM ap_invoices WHERE uid = ?', [invUid]); return i && i.total ? r2(amt * (i.total - (i.vat || 0)) / i.total) : r2(amt); };
  const exVat = r2((allocations || []).reduce((t, x) => t + exVatOf(x.invoiceUid, r2(x.amount)), 0));
  const year = String(date).slice(0, 4);
  // Money actually paid this year (cheque, cash, transfer) – credit notes used are not payments.
  const before = r2(db().all(`SELECT a.invoice_uid, a.amount FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid WHERE p.supplier_uid = ? AND p.status = 'active' AND p.method IN ('cheque','cash','transfer') AND substr(p.pay_date,1,4) = ?`, [supplierUid, year])
    .reduce((t, x) => t + exVatOf(x.invoice_uid, x.amount), 0));
  if (before + exVat <= Number(st.provTaxThreshold || 0)) return { pct, withheld: 0, exVat, yearBefore: before, under: true };
  return { pct, withheld: r2(exVat * pct / 100), exVat, yearBefore: before };
}

// v3.9 Split payment: one settlement paid partly in cash, partly by cheque, partly by transfer (any of the payment
// methods). parts: [{ method, amount, accountUid, chequeNo, reference, shopCode, receivedBy }] – the amounts are what is
// handed over (after any provisional tax kept back) and must add up to it exactly. Each part becomes its own payment
// (its own cheque in the register, its own bank line, its own cash out of the shop), all saved together or not at all.
export function makeSplitPayment(user, { supplierUid, payDate, allocations = [], parts = [], notes, photos = [] }) {
  const clean = (parts || []).filter((x) => x && r2(x.amount) > 0);
  need(clean.length >= 2, 'A split payment needs at least two parts (e.g. some cash and a cheque).');
  const allocs = (allocations || []).map((x) => ({ invoiceUid: x.invoiceUid, amount: r2(x.amount) })).filter((x) => x.amount > 0);
  need(allocs.length, 'Tick at least one invoice to pay.');
  const settles = r2(allocs.reduce((t, x) => t + x.amount, 0));
  const held = withholdingFor(supplierUid, allocs, payDate || dateStr()).withheld || 0;
  const net = r2(settles - held);
  const sum = r2(clean.reduce((t, x) => t + r2(x.amount), 0));
  need(Math.abs(sum - net) < 0.005, `The parts add up to ${$(sum)} but ${$(net)} is to be paid. Make them equal.`);
  const chequeNos = clean.filter((x) => (payMethod(x.method) || { base: x.method }).base === 'cheque').map((x) => `${x.accountUid}|${Math.round(Number(x.chequeNo))}`);
  need(new Set(chequeNos).size === chequeNos.length, 'Two parts use the same cheque number.');
  const group = uuid('SP');
  // The split as a whole may still be a part payment of an invoice: marked on every part.
  const partList = allocs.map((x) => { const inv = getInvoice(x.invoiceUid); return inv && x.amount < inv.owing - 0.004 ? `${inv.invoice_no || 'no number'} (${$(r2(inv.owing - x.amount))} still owing)` : null; }).filter(Boolean);
  const partNote = partList.length ? `PART PAYMENT – ${partList.join(', ')}` : '';
  const queue = allocs.map((x) => ({ ...x }));
  const out = [];
  db().transaction(() => {
    let left = settles;
    clean.forEach((part, i) => {
      // What this part settles (the same share of the invoices as its share of the money).
      let take = i === clean.length - 1 ? r2(left) : r2((r2(part.amount) * settles) / (net || 1));
      left = r2(left - take);
      const mine = [];
      for (const q of queue) {
        if (take <= 0) break;
        const t = r2(Math.min(q.amount, take));
        if (t <= 0) continue;
        mine.push({ invoiceUid: q.invoiceUid, amount: t });
        q.amount = r2(q.amount - t);
        take = r2(take - t);
      }
      need(mine.length, 'Each part must pay something.');
      out.push(makePayment(user, { ...part, supplierUid, payDate, allocations: mine, photos: i === 0 ? photos : [], inSplit: true,
        notes: `Split payment ${i + 1} of ${clean.length} (${group})${partNote ? ` · ${partNote}` : ''}${notes ? ` – ${txt(notes)}` : ''}` }));
    });
  });
  return out;
}

// Credit notes used and the money payment together: all saved, or nothing.
export function settle(user, { credits = [], payment = null, split = null }) {
  let out = null;
  db().transaction(() => {
    for (const c of credits) applyCredit(user, c);
    if (split) { const list = makeSplitPayment(user, split); out = list[0] || null; if (out) out.split = list; } else if (payment) out = makePayment(user, payment);
  });
  return out;
}

// v3.9.8 suppliers paid in cash out of a till on a day (shown to the person counting that till; nothing is changed on the till).
export function tillPaidOuts(tillUid, date) {
  if (!tillUid || !date) return [];
  try {
    return db().all(`SELECT p.uid, p.supplier_name, p.amount, p.paid_by_name, (SELECT i.invoice_no FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = p.uid LIMIT 1) AS invoice_no
      FROM ap_payments p WHERE p.method = 'cash' AND p.status = 'active' AND p.cash_from = ? AND p.pay_date = ? ORDER BY p.created_at`, [`till:${tillUid}`, date]);
  } catch (e) { return []; }
}
export function makePayment(user, p) {
  requirePerm(user, ['payments_make', 'till_approve'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  // An admin-made method (e.g. M-PAiSA, BSP Pay) works like cheque, cash or a bank transfer; its name is kept.
  const m = payMethod(p.method);
  const q = m ? { ...p, method: m.base, methodName: m.label } : p;
  need(['cheque', 'cash', 'transfer', 'mpaisa'].includes(q.method), 'Choose how it is paid.');
  // 1.0.0 hardening (H1): without "pay suppliers", a shop manager may only pay in cash from their own shop's till or safe
  if (!can(user, 'payments_make')) {
    need(q.method === 'cash' && /^(till:|safe)/.test(String(q.cashFrom || '')), 'You may only pay a supplier in cash from your shop\'s till or safe. Cheques and transfers are paid by the office.');
    requireShop(user, q.shopCode);
  }
  return recordPayment(user, q);
  });
}

function recordPayment(user, p) {
  const sup = getSupplier(p.supplierUid);
  need(sup, 'Choose the supplier.');
  const date = txt(p.payDate) || dateStr();
  need(DATE.test(date), 'Enter the date as YYYY-MM-DD.');
  assertOpen(date, 'This payment');
  const rules = apRules();
  if (p.method === 'cash') need(p.shopCode, 'Choose which shop\'s cash it was paid from.');
  // v3.9.8 cash: from the shop's safe or from a till (which one); M-PAiSA: from the shop's own wallet.
  let cashFrom = null;
  if (p.method === 'cash' && p.cashFrom !== undefined) {
    cashFrom = txt(p.cashFrom);
    need(cashFrom === 'safe' || /^till:.+/.test(cashFrom) || cashFrom === `cig:${p.shopCode}`, 'Say where the cash came from: the shop\'s safe, or which till.');
    if (cashFrom.startsWith('till:')) need(db().get('SELECT 1 AS x FROM tills WHERE uid = ? AND shop_code = ?', [cashFrom.slice(5), p.shopCode]), 'That till is not at this shop.');
  }
  let wallet = null;
  if (p.method === 'mpaisa') {
    wallet = db().get('SELECT * FROM wallets WHERE uid = ? AND active = 1', [txt(p.walletUid)]);
    need(wallet, 'Choose the shop\'s M-PAiSA wallet it was paid from.');
    need(txt(p.reference), 'Enter the M-PAiSA transaction reference.');
  }
  const merged = {};
  (p.allocations || []).forEach((x) => { if (x && x.invoiceUid) merged[x.invoiceUid] = r2((merged[x.invoiceUid] || 0) + r2(x.amount)); });
  const allocs = Object.entries(merged).map(([invoiceUid, amount]) => ({ invoiceUid, amount })).filter((x) => x.amount > 0);
  need(allocs.length, 'Tick at least one invoice to pay.');
  for (const x of allocs) {
    const i = getInvoice(x.invoiceUid);
    need(i && i.kind === 'invoice' && i.status !== 'void', 'One of the invoices is no longer there.');
    need(i.supplier_uid === sup.uid, `Invoice ${i.invoice_no || ''} is from a different supplier.`);
    need(!(rules.checkBeforePay && i.status === 'to_check'), `Invoice ${i.invoice_no || ''} must be checked before it is paid.`);
    need(x.amount <= i.owing + 0.004, `Invoice ${i.invoice_no || ''} only has ${$(i.owing)} owing.`);
  }
  const amount = r2(allocs.reduce((s, x) => s + x.amount, 0));
  // v3.9: a part payment is allowed but marked on the payment (and the invoice stays flagged until fully paid).
  const partOf = allocs.map((x) => { const i = getInvoice(x.invoiceUid); return i && x.amount < i.owing - 0.004 ? `${i.invoice_no || 'no number'} (${$(r2(i.owing - x.amount))} still owing)` : null; }).filter(Boolean);
  if (partOf.length && !p.inSplit) p = { ...p, notes: [`PART PAYMENT – ${partOf.join(', ')}`, txt(p.notes)].filter(Boolean).join(' · ') };
  const held = ['cheque', 'cash', 'transfer', 'mpaisa'].includes(p.method) ? withholdingFor(sup.uid, allocs, date).withheld : 0;
  const net = r2(amount - held); // what the supplier actually gets (cheque / transfer / cash)
  const { now, dev } = meta();
  const uid = uuid('PY');
  let chequeUid = null;
  let chequeNo = null;
  let account = null;
  if (p.method === 'cheque' || p.method === 'transfer') {
    account = db().get('SELECT * FROM bank_accounts WHERE uid = ? AND active = 1', [p.accountUid]);
    need(account, 'Choose the bank account.');
  }
  if (p.method === 'cheque') {
    chequeNo = Math.round(Number(p.chequeNo));
    need(Number.isFinite(chequeNo) && chequeNo > 0, 'Enter the cheque number.');
    // v3.9.2 a dated (post-dated) cheque: the date written on it, for on-account suppliers
    if (txt(p.chequeDate)) { need(DATE.test(txt(p.chequeDate)) && txt(p.chequeDate) >= date, 'The date on the cheque must be the payment date or later.'); need(txt(p.chequeDate) <= addDaysLocal(date, 184), 'The date on the cheque can be up to 6 months ahead.'); }
    const book = bookFor(account.uid, chequeNo);
    need(book, `Cheque ${chequeNo} is not in any cheque book for ${account.name}. Add the cheque book first (Cheques › Books).`);
    const used = db().get('SELECT status, payee FROM cheques WHERE account_uid = ? AND cheque_no = ?', [account.uid, chequeNo]);
    need(!used, `Cheque ${chequeNo} is already used (${used && used.status}${used && used.payee ? `, ${used.payee}` : ''}).`);
    chequeUid = uuid('CQ');
  }
  if (p.method === 'transfer') need(txt(p.reference), 'Enter the bank transfer reference.');
  db().transaction(() => {
    db().run(`INSERT INTO ap_payments (uid, supplier_uid, supplier_name, method, pay_date, amount, account_uid, cheque_uid, cheque_no, reference, credit_uid, shop_code, received_by, photo_urls, notes, status,
      paid_by_uid, paid_by_name, created_at, updated_at, updated_device, withheld, method_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'[]',?,'active',?,?,?,?,?,?,?)`,
    [uid, sup.uid, sup.name, p.method === 'mpaisa' ? 'transfer' : p.method, date, amount, account ? account.uid : null, chequeUid, chequeNo ? String(chequeNo) : null, txt(p.reference) || null, p.creditUid || null,
      p.method === 'cash' || p.method === 'cheque' ? (txt(p.shopCode) || null) : null, txt(p.receivedBy) || null, txt(p.notes) || null, user.uid, user.name, now, now, dev, held || null, txt(p.methodName) || (p.method === 'mpaisa' ? 'M-PAiSA' : null)]);
    if (cashFrom || wallet) db().run('UPDATE ap_payments SET cash_from = ?, wallet_uid = ?, shop_code = COALESCE(shop_code, ?) WHERE uid = ?', [cashFrom, wallet ? wallet.uid : null, wallet ? wallet.shop_code : null, uid]);
    if (wallet) {
      db().run(`INSERT INTO wallet_moves (uid, wallet_uid, move_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'payment',?,?,?,?,?,?)`,
        [uuid('WM'), wallet.uid, date, net, txt(p.reference), `Paid to ${sup.name} (payment ${uid})`, user.name, now, dev]);
    }
    for (const x of allocs) {
      db().run('INSERT INTO ap_allocations (uid, payment_uid, invoice_uid, amount, updated_at, updated_device) VALUES (?,?,?,?,?,?)', [uuid('AL'), uid, x.invoiceUid, x.amount, now, dev]);
    }
    if (chequeUid) {
      db().run(`INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, payment_uid, memo, written_by_name, updated_at, updated_device)
        VALUES (?,?,?,?,?,?,?,'written',?,?,?,?,?)`, [chequeUid, account.uid, bookFor(account.uid, chequeNo).uid, chequeNo, txt(p.chequeDate) || date, sup.name, net, uid, txt(p.chequeDate) && txt(p.chequeDate) > date ? `Post-dated ${txt(p.chequeDate)}${txt(p.notes) ? ` · ${txt(p.notes)}` : ''}` : txt(p.notes) || null, user.name, now, dev]);
    }
    if (p.method === 'transfer') {
      db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, payment_uid, note, by_name, updated_at, updated_device) VALUES (?,?,?,'transfer_out',?,?,?,?,?,?,?)`,
        [uuid('BE'), account.uid, date, net, txt(p.reference), uid, `Payment to ${sup.name}`, user.name, now, dev]);
    }
  });
  if (p.photos && p.photos.length) addPhotos('payment', uid, p.photos);
  if (chequeUid) linkHandedSnaps(chequeUid);
  if (chequeUid) { try { require('./chequePlaces.js').startBookIfSpare(bookFor(account.uid, chequeNo).uid, user); } catch (e) { /* the book stays as it is */ } }
  audit({ user, action: `Paid ${sup.name} ${$(amount)} by ${p.method}${chequeNo ? ` (cheque ${chequeNo})` : ''}${held ? ` – ${$(held)} provisional tax kept back, ${$(net)} paid` : ''}`, table: 'ap_payments', recordUid: uid, after: { allocations: allocs } });
  return getPayment(uid);
}

// A cheque photographed as handed over before it was recorded: once recorded, the photo is linked to it and the
// cheque gets the hand-over details (date, who took it).
export function linkHandedSnaps(chequeUid) {
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
  if (!c) return;
  const snaps = handedNotRecorded(c.account_uid, c.cheque_no, c.cheque_no);
  // handedNotRecorded() no longer sees it (the cheque now exists), so look the photos up directly.
  const rows = snaps.length ? snaps : (() => { try { return db().all("SELECT * FROM money_snaps WHERE kind IN ('cheque_given','cheque_written') AND status <> 'rejected' AND cheque_no = ? AND (account_uid IS NULL OR account_uid = ?) AND (link_uid IS NULL OR link_uid <> ?)", [c.cheque_no, c.account_uid, c.uid]); } catch (e) { return []; } })();
  if (!rows.length) return;
  const { now, dev } = meta();
  const s = rows[rows.length - 1];
  db().run(`UPDATE money_snaps SET link_table = 'cheques', link_uid = ?, cheque_check = 'recorded', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE kind IN ('cheque_given','cheque_written') AND cheque_no = ? AND status <> 'rejected' AND (account_uid IS NULL OR account_uid = ?)`,
    [c.uid, now, dev, c.cheque_no, c.account_uid]);
  // 1.0.0 a cheque written by staff (waiting for pickup) keeps its "written" time and who in the cheque chain
  try { require('./chain.js').stepsFromSnaps(c.uid, rows); } catch (e) { /* the chain falls back to the payment */ }
  if (!c.handed_date && s.kind === 'cheque_given') {
    db().run(`UPDATE cheques SET handed_date = ?, handed_by_name = ?, handed_to = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [s.snap_date, s.by_name, s.collected_by, now, dev, c.uid]);
  }
}

export function voidPayment(user, uid, reason, { photos = [] } = {}) {
  requirePerm(user, 'payments_make', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  { const x = getPayment(uid); if (x) assertOpen(x.pay_date, 'This record'); }
  const p = getPayment(uid);
  need(p, 'Payment not found.');
  need(p.status === 'active', 'Already void.');
  needReason(user, reason, 'Give a reason.');
  need(!(p.cheque_status === 'presented'), 'This cheque has already cleared the bank. Record a refund from the supplier instead.');
  // build 39: a cheque cancelled – a photo of it (the cancelled cheque, or the stub when it is gone)
  if (p.method === 'cheque') need((photos || []).length, 'Take a photo of the cancelled cheque (or its stub) – it is required.');
  need(!db().get("SELECT 1 AS x FROM bank_entries WHERE payment_uid = ? AND status = 'active' AND cleared_date IS NOT NULL", [uid]), 'This transfer is already on a bank statement. Un-match it in Bank reconciliation first.');
  const { now, dev } = meta();
  if ((photos || []).length) { addPhotos('payment', uid, photos); const cq = db().get('SELECT uid FROM cheques WHERE payment_uid = ?', [uid]); if (cq) { db().run("UPDATE cheques SET photo_urls = COALESCE(photo_urls, '[]') WHERE uid = ?", [cq.uid]); addPhotos('stub', cq.uid, photos); } }
  db().transaction(() => {
    db().run(`UPDATE ap_payments SET status = 'void', void_reason = ?, voided_by_name = ?, voided_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), user.name, now, now, dev, uid]);
    if (p.cheque_uid) db().run(`UPDATE cheques SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, p.cheque_uid]);
    db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE payment_uid = ?`, [txt(reason), now, dev, uid]);
    try { db().run(`UPDATE wallet_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE note LIKE ? AND status = 'active'`, [txt(reason), now, dev, `%(payment ${uid})`]); } catch (e) { /* no wallets */ }
  });
  audit({ user, action: `Voided payment to ${p.supplier_name} ${$(p.amount)}${p.cheque_no ? ` (cheque ${p.cheque_no})` : ''}`, table: 'ap_payments', recordUid: uid, reason });
  });
}

// ---------------------------------------------------------------- bank accounts & cheque books
export function listAccounts({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM bank_accounts WHERE (? = 1 OR active = 1) ORDER BY sort, name`, [includeInactive ? 1 : 0]);
}
export function saveAccount(user, a) {
  requirePerm(user, 'cheques_manage', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'cheques_manage');
  const name = txt(a.name);
  need(name, 'Enter a name, e.g. "BSP Business Cheque".');
  const ob = r2(a.openingBalance);
  const od = txt(a.openingDate) || dateStr();
  need(DATE.test(od), 'Enter the opening date as YYYY-MM-DD.');
  const uid = a.uid || uuid('BA');
  const before = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [uid]);
  const { now, dev } = meta();
  db().run(`INSERT INTO bank_accounts (uid, name, bank, account_no, opening_balance, opening_date, active, sort, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,COALESCE((SELECT MAX(sort)+1 FROM bank_accounts),0),?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, bank=excluded.bank, account_no=excluded.account_no, opening_balance=excluded.opening_balance, opening_date=excluded.opening_date,
    active=excluded.active, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, name, txt(a.bank) || 'BSP', txt(a.accountNo) || null, ob, od, a.active === false ? 0 : 1, now, dev]);
  audit({ user, action: before ? `Changed bank account ${name}` : `Added bank account ${name}`, table: 'bank_accounts', recordUid: uid, before, after: { name, ob, od } });
  return db().get('SELECT * FROM bank_accounts WHERE uid = ?', [uid]);
  });
}
export function listBooks(accountUid) {
  return db().all('SELECT * FROM cheque_books WHERE account_uid = ? ORDER BY first_no', [accountUid]);
}
function bookFor(accountUid, no) {
  return db().get('SELECT * FROM cheque_books WHERE account_uid = ? AND ? BETWEEN first_no AND last_no ORDER BY active DESC LIMIT 1', [accountUid, no]);
}
export const BOOK_STATUS = { in_use: 'In use', spare: 'Not started (spare)', finished: 'Finished', cancelled: 'Cancelled', lost: 'Lost / stolen' };
export const bookStatusOf = (b) => (b ? b.status || (b.active ? 'in_use' : 'finished') : null);
export function saveBook(user, b) {
  requirePerm(user, 'cheques_manage', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const first = Math.round(Number(b.firstNo));
  const last = Math.round(Number(b.lastNo));
  need(db().get('SELECT 1 AS x FROM bank_accounts WHERE uid = ?', [b.accountUid]), 'Choose the bank account.');
  need(first > 0 && last >= first, 'Enter the first and last cheque numbers in the book.');
  need(last - first < 1000, 'A cheque book can have at most 1000 cheques.');
  const overlap = db().get('SELECT first_no, last_no FROM cheque_books WHERE account_uid = ? AND uid <> ? AND NOT (last_no < ? OR first_no > ?)', [b.accountUid, b.uid || '', first, last]);
  need(!overlap, `These numbers overlap the book ${overlap && overlap.first_no}–${overlap && overlap.last_no}.`);
  const uid = b.uid || uuid('CB');
  const old = db().get('SELECT * FROM cheque_books WHERE uid = ?', [uid]);
  // Status (in use / spare / finished / cancelled / lost); "active" follows it so older screens keep working.
  let status = b.status || (b.active === false ? 'finished' : b.active === true && old && !['in_use', 'spare'].includes(old.status) ? 'in_use' : (old && bookStatusOf(old)) || 'in_use');
  if (!BOOK_STATUS[status]) status = 'in_use';
  if (old && ['lost', 'cancelled'].includes(status) && status !== old.status) needReason(user, b.reason || b.notes, 'Say what happened to the cheque book.');
  b = { ...b, active: ['in_use', 'spare'].includes(status) };
  const { now, dev } = meta();
  db().run(`INSERT INTO cheque_books (uid, account_uid, first_no, last_no, received_date, notes, active, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET first_no=excluded.first_no, last_no=excluded.last_no, received_date=excluded.received_date, notes=excluded.notes, active=excluded.active,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, b.accountUid, first, last, txt(b.receivedDate) || dateStr(), txt(b.notes) || null, b.active === false ? 0 : 1, now, dev]);
  db().run('UPDATE cheque_books SET serial = ?, holder = ?, status = ? WHERE uid = ?',
    [b.serial === undefined ? (old ? old.serial : null) : txt(b.serial) || null, b.holder === undefined ? (old ? old.holder : null) : txt(b.holder) || null, status, uid]);
  audit({ user, action: `Cheque book ${first}–${last}${b.serial ? ` (serial ${txt(b.serial)})` : ''} – ${BOOK_STATUS[status]}`, table: 'cheque_books', recordUid: uid, before: old, after: { first, last, status, holder: b.holder, serial: b.serial }, reason: txt(b.reason) || null });
  return uid;
  });
}

// The next unused cheque number: the lowest free leaf in the active books, after the last one used.
export function nextChequeNo(accountUid) {
  // Release 03: books in use first; a spare book only when no book in use has a leaf left
  const books = db().all("SELECT * FROM cheque_books WHERE account_uid = ? AND active = 1 ORDER BY CASE COALESCE(status, 'in_use') WHEN 'spare' THEN 1 ELSE 0 END, first_no", [accountUid]);
  for (const b of books) {
    const top = Math.max(db().get('SELECT MAX(cheque_no) AS n FROM cheques WHERE account_uid = ? AND cheque_no BETWEEN ? AND ?', [accountUid, b.first_no, b.last_no]).n || 0,
      ...handedNotRecorded(accountUid, b.first_no, b.last_no).map((h) => h.cheque_no));
    const next = top ? top + 1 : b.first_no;
    if (next <= b.last_no) return next;
  }
  return null;
}

// Cheques photographed as handed over (To verify) whose number is not recorded as a cheque yet.
export function handedNotRecorded(accountUid, first = 0, last = 1e12) {
  if (!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'money_snaps'")) return [];
  try {
    return db().all(`SELECT s.* FROM money_snaps s WHERE s.kind IN ('cheque_given','cheque_written') AND s.status <> 'rejected' AND s.cheque_no BETWEEN ? AND ?
      AND (s.account_uid IS NULL OR s.account_uid = ?) AND NOT EXISTS (SELECT 1 FROM cheques c WHERE c.cheque_no = s.cheque_no AND (s.account_uid IS NULL OR c.account_uid = s.account_uid))
      ORDER BY s.cheque_no`, [first, last, accountUid]);
  } catch (e) { return []; } // older database without the v3.5 columns
}
export function stubPhotoCount(c, localCounts) {
  if (!c) return 0;
  let n = 0;
  try { n = JSON.parse(c.photo_urls || '[]').length; } catch (e) { n = 0; }
  // 1.0.0 a whole cheque book's stub photos are counted in one read (localCounts: cheque uid → photos on this device)
  const local = localCounts ? { n: localCounts.get(c.uid) || 0 } : db().get("SELECT COUNT(*) AS n FROM photos WHERE ref_type = 'stub' AND ref_id = ?", [c.uid]);
  return Math.max(n, local ? local.n : 0);
}
// Every leaf in a book: used / cleared / void / spoiled / unused, "handed" = handed over (photo) but not recorded,
// and "skipped" = unused but a later number is used.
export function bookLeaves(bookUid) {
  const b = db().get('SELECT * FROM cheque_books WHERE uid = ?', [bookUid]);
  if (!b) return null;
  const used = db().all('SELECT * FROM cheques WHERE account_uid = ? AND cheque_no BETWEEN ? AND ?', [b.account_uid, b.first_no, b.last_no]);
  const handed = handedNotRecorded(b.account_uid, b.first_no, b.last_no);
  const stubs = new Map();
  try {
    db().all(`SELECT p.ref_id AS u, COUNT(*) AS n FROM photos p WHERE p.ref_type = 'stub' AND p.ref_id IN (SELECT uid FROM cheques WHERE account_uid = ? AND cheque_no BETWEEN ? AND ?) GROUP BY p.ref_id`,
      [b.account_uid, b.first_no, b.last_no]).forEach((r) => stubs.set(r.u, r.n));
  } catch (e) { /* no photos table: none */ }
  return leavesOf(b, used, handed, stubs);
}
// 1.0.0 every book of a list at once (the cheque book list, Home): one read of the cheques, the handed-over photos
// and the stub photos per account instead of three per book – each book's leaves exactly as bookLeaves gives them.
// lite: only what the counts need from each cheque (the cheque book list) – the leaves then carry those fields only.
export function bookLeavesAll(books, { lite = false } = {}) {
  const out = new Map();
  const accts = Array.from(new Set(books.map((b) => b.account_uid)));
  for (const acct of accts) {
    const mine = books.filter((b) => b.account_uid === acct);
    const chq = db().all(`SELECT ${lite ? 'uid, cheque_no, status, photo_urls' : '*'} FROM cheques WHERE account_uid = ? ORDER BY cheque_no, rowid`, [acct]);
    const snaps = handedNotRecorded(acct, -1e15, 1e15);
    const stubs = new Map();
    try {
      db().all("SELECT p.ref_id AS u, COUNT(*) AS n FROM photos p WHERE p.ref_type = 'stub' AND p.ref_id IN (SELECT uid FROM cheques WHERE account_uid = ?) GROUP BY p.ref_id", [acct])
        .forEach((r) => stubs.set(r.u, r.n));
    } catch (e) { /* no photos table: none */ }
    for (const b of mine) {
      const inBook = (n) => n !== null && n !== undefined && Number(n) >= Number(b.first_no) && Number(n) <= Number(b.last_no);
      out.set(b.uid, leavesOf(b, chq.filter((c) => inBook(c.cheque_no)), snaps.filter((h) => inBook(h.cheque_no)), stubs));
    }
  }
  return out;
}
function leavesOf(b, usedRows, handedRows, stubs) {
  const used = {};
  usedRows.forEach((c) => { used[c.cheque_no] = c; });
  const handed = {};
  handedRows.forEach((h) => { handed[h.cheque_no] = h; });
  const top = Math.max(0, ...Object.keys(used).map(Number), ...Object.keys(handed).map(Number));
  const leaves = [];
  for (let n = b.first_no; n <= b.last_no; n++) {
    const c = used[n];
    const st = c ? c.status : handed[n] ? 'handed' : n < top ? 'skipped' : 'unused';
    leaves.push({ no: n, status: st, cheque: c || null, snap: handed[n] || null, noStubPhoto: !!c && ['written', 'presented'].includes(c.status) && !stubPhotoCount(c, stubs) });
  }
  const count = (s) => leaves.filter((l) => l.status === s).length;
  return { book: b, leaves, written: count('written'), presented: count('presented'), void: count('void'), spoiled: count('spoiled'), skipped: count('skipped'), unused: count('unused'),
    handed: count('handed'), noStubPhoto: leaves.filter((l) => l.noStubPhoto).length };
}

export function spoilCheque(user, { accountUid, chequeNo, reason, date, photos = [] }) {
  requirePerm(user, 'payments_make', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const no = Math.round(Number(chequeNo));
  need(bookFor(accountUid, no), `Cheque ${no} is not in a cheque book for this account.`);
  need(!db().get('SELECT 1 AS x FROM cheques WHERE account_uid = ? AND cheque_no = ?', [accountUid, no]), `Cheque ${no} is already recorded.`);
  // Release 03 (owner, 12 Nov): a spoiled cheque always has a reason and a photo, and is checked by the owner / an admin
  need(txt(reason), 'Say what happened to the cheque (e.g. written wrongly, torn).');
  // build 39 (owner: "if the cheque is spoilt or something happens a picture still needs to be taken")
  need((photos || []).length, 'Take a photo of the spoiled cheque (it is required).');
  const { now, dev } = meta();
  const uid = uuid('CQ');
  db().run(`INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, void_reason, written_by_name, updated_at, updated_device) VALUES (?,?,?,?,?,NULL,0,'spoiled',?,?,?,?)`,
    [uid, accountUid, bookFor(accountUid, no).uid, no, txt(date) || dateStr(), txt(reason), user.name, now, dev]);
  db().run("UPDATE cheques SET photo_urls = '[]' WHERE uid = ?", [uid]);
  addPhotos('stub', uid, photos);
  db().run("UPDATE cheques SET spoil_check = 'waiting' WHERE uid = ?", [uid]);
  try { require('./chequePlaces.js').startBookIfSpare(bookFor(accountUid, no).uid, user); } catch (e) { /* the book stays as it is */ }
  audit({ user, action: `Cheque ${no} spoiled`, table: 'cheques', recordUid: uid, reason });
  });
}

export function markPresented(user, chequeUid, date) {
  requirePerm(user, ['payments_make', 'verify_money'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chequeUid]);
  need(c, 'Cheque not found.');
  const { now, dev } = meta();
  if (date === null) {
    need(c.status === 'presented', 'Not marked as cleared.');
    db().run(`UPDATE cheques SET status = 'written', presented_date = NULL, presented_by_name = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, chequeUid]);
    audit({ user, action: `Cheque ${c.cheque_no} un-marked as cleared`, table: 'cheques', recordUid: chequeUid });
    return;
  }
  need(c.status === 'written', c.status === 'presented' ? 'Already cleared.' : `This cheque is ${c.status}.`);
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d >= c.cheque_date, 'The cleared date must be on or after the cheque date.');
  db().run(`UPDATE cheques SET status = 'presented', presented_date = ?, presented_by_name = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [d, user ? user.name : null, now, dev, chequeUid]);
  audit({ user, action: `Cheque ${c.cheque_no} cleared ${d}`, table: 'cheques', recordUid: chequeUid });
  try { require('./chain.js').addStep(user, { chequeUid, step: 'cleared', note: `Cleared on the bank ${d}` }); } catch (e) { /* the chain falls back to the cleared date */ }
  });
}

export function listCheques({ accountUid, status, from, to, limit = 1000 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (accountUid) { w.push('c.account_uid = ?'); a.push(accountUid); }
  if (status) { w.push('c.status = ?'); a.push(status); }
  if (from) { w.push('c.cheque_date >= ?'); a.push(from); }
  if (to) { w.push('c.cheque_date <= ?'); a.push(to); }
  return db().all(`SELECT c.*, b.name AS account_name FROM cheques c JOIN bank_accounts b ON b.uid = c.account_uid WHERE ${w.join(' AND ')} ORDER BY c.account_uid, c.cheque_no DESC LIMIT ?`, a.concat([limit]));
}
export function staleCheques(today = dateStr()) {
  const m = apRules().staleMonths;
  const d = new Date(`${today}T00:00:00`);
  d.setMonth(d.getMonth() - m);
  return listCheques({ status: 'written', to: dateStr(d) });
}

// Deposits, fees, interest and corrections on a bank account (not cheques).
export const ENTRY_LABEL = { deposit: 'Deposit', transfer_out: 'Transfer out', fee: 'Bank fee', interest: 'Interest', adjust_in: 'Correction (+)', adjust_out: 'Correction (−)' };
const IN_TYPES = ['deposit', 'interest', 'adjust_in'];
export function addBankEntry(user, e) {
  requirePerm(user, 'cheques_manage', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  assertOpen(String(e.date || dateStr()), 'This bank line');
  need(db().get('SELECT 1 AS x FROM bank_accounts WHERE uid = ?', [e.accountUid]), 'Choose the bank account.');
  need(ENTRY_LABEL[e.type], 'Choose the type.');
  const amt = r2(e.amount);
  need(amt > 0, 'Enter the amount.');
  const d = txt(e.date) || dateStr();
  need(DATE.test(d), 'Enter the date as YYYY-MM-DD.');
  if (e.type.startsWith('adjust')) needReason(user, e.note, 'A correction needs a reason.');
  const { now, dev } = meta();
  const uid = e.uid || uuid('BE');
  db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, cleared_date, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, e.accountUid, d, e.type, amt, txt(e.reference) || null, txt(e.note) || null, user.name, txt(e.clearedDate) || null, now, dev]);
  audit({ user, action: `${ENTRY_LABEL[e.type]} ${$(amt)}`, table: 'bank_entries', recordUid: uid, reason: e.note });
  return uid;
  });
}
export function voidBankEntry(user, uid, reason) {
  requirePerm(user, 'cheques_manage', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  { const x = db().get('SELECT entry_date FROM bank_entries WHERE uid = ?', [uid]); if (x) assertOpen(x.entry_date, 'This bank line'); }
  needReason(user, reason, 'Give a reason.');
  const e = db().get('SELECT * FROM bank_entries WHERE uid = ?', [uid]);
  need(e && e.status === 'active', 'Entry not found.');
  need(!e.payment_uid, 'This is a supplier payment: void the payment instead.');
  const { now, dev } = meta();
  db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Voided ${ENTRY_LABEL[e.type]} ${$(e.amount)}`, table: 'bank_entries', recordUid: uid, reason });
  });
}
export function setEntryCleared(user, uid, date) {
  requirePerm(user, 'cheques_manage', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const { now, dev } = meta();
  db().run(`UPDATE bank_entries SET cleared_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [date || null, now, dev, uid]);
  });
}
export function listBankEntries({ accountUid, from, to, includeVoid = false } = {}) {
  const w = ['account_uid = ?'];
  const a = [accountUid];
  if (from) { w.push('entry_date >= ?'); a.push(from); }
  if (to) { w.push('entry_date <= ?'); a.push(to); }
  if (!includeVoid) w.push("status = 'active'");
  return db().all(`SELECT * FROM bank_entries WHERE ${w.join(' AND ')} ORDER BY entry_date DESC, updated_at DESC`, a);
}

// Cheque-book (stub) balance at a date: opening + money in − cheques written − money out.
export function bookBalance(accountUid, asOf = dateStr()) {
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ?', [accountUid]);
  if (!acc) return null;
  const ins = db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM bank_entries WHERE account_uid = ? AND status = 'active' AND type IN ('deposit','interest','adjust_in') AND entry_date >= ? AND entry_date <= ?`, [accountUid, acc.opening_date, asOf]).s;
  const outs = db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM bank_entries WHERE account_uid = ? AND status = 'active' AND type IN ('transfer_out','fee','adjust_out') AND entry_date >= ? AND entry_date <= ?`, [accountUid, acc.opening_date, asOf]).s;
  const chq = db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM cheques WHERE account_uid = ? AND status IN ('written','presented') AND cheque_date >= ? AND cheque_date <= ?`, [accountUid, acc.opening_date, asOf]).s;
  return { account: acc, opening: r2(acc.opening_balance), moneyIn: r2(ins), moneyOut: r2(outs), cheques: r2(chq), balance: r2(acc.opening_balance + ins - outs - chq) };
}

// Balance the cheque book against the bank statement.
export function balanceCheck(accountUid, statementDate, statementBalance) {
  need(DATE.test(txt(statementDate)), 'Enter the statement date as YYYY-MM-DD.');
  const sb = Number(statementBalance);
  need(Number.isFinite(sb), 'Enter the closing balance from the statement.');
  const book = bookBalance(accountUid, statementDate);
  need(book, 'Account not found.');
  const notCleared = db().all(`SELECT * FROM cheques WHERE account_uid = ? AND status = 'written' AND cheque_date <= ? ORDER BY cheque_no`, [accountUid, statementDate])
    .concat(db().all(`SELECT * FROM cheques WHERE account_uid = ? AND status = 'presented' AND cheque_date <= ? AND presented_date > ? ORDER BY cheque_no`, [accountUid, statementDate, statementDate]));
  const entries = db().all(`SELECT * FROM bank_entries WHERE account_uid = ? AND status = 'active' AND entry_date <= ? AND entry_date >= ? AND (cleared_date IS NULL OR cleared_date > ?) ORDER BY entry_date`,
    [accountUid, statementDate, book.account.opening_date, statementDate]);
  const chequesOut = r2(notCleared.reduce((s, c) => s + c.amount, 0));
  const depositsInTransit = r2(entries.filter((e) => IN_TYPES.includes(e.type)).reduce((s, e) => s + e.amount, 0));
  const otherOut = r2(entries.filter((e) => !IN_TYPES.includes(e.type)).reduce((s, e) => s + e.amount, 0));
  const expected = r2(book.balance + chequesOut - depositsInTransit + otherOut);
  const difference = r2(sb - expected);
  return { ...book, statementDate, statementBalance: r2(sb), notCleared, chequesOut, entriesNotCleared: entries, depositsInTransit, otherOut, expected, difference, balanced: Math.abs(difference) < 0.005 };
}

// ---------------------------------------------------------------- what needs attention (Home)
export function apAlerts(today = dateStr()) {
  // v3.9.7 invoices, bills and cheques from before the go-live date only once the owner has seen them ("Before go-live").
  let keepOld = (l) => l;
  try { const G = require('../../services/goLive.js'); keepOld = (l, k, d) => G.keepList(l, k, d); } catch (e) { /* none */ }
  const inv = (l) => keepOld(l, (i) => `ap_invoices:${i.uid}`, (i) => i.invoice_date || i.due_date);
  const due = inv(listInvoices({ filter: 'unpaid' }));
  const sum = (list) => r2(list.reduce((s, i) => s + i.owing, 0));
  const pick = (k) => due.filter((i) => i.due === k);
  const skipped = listAccounts().reduce((n, a) => n + listBooks(a.uid).filter((b) => b.active).reduce((m, b) => m + bookLeaves(b.uid).skipped, 0), 0);
  return {
    overdue: { n: pick('overdue').length, amount: sum(pick('overdue')) },
    dueToday: { n: pick('due_today').length, amount: sum(pick('due_today')) },
    dueSoon: { n: pick('due_soon').length, amount: sum(pick('due_soon')) },
    toCheck: inv(listInvoices({ filter: 'to_check' })).length,
    // v3.9: invoices paid only in part (allowed, but kept in view until the rest is paid).
    part: { n: due.filter((i) => i.partPaid).length, amount: sum(due.filter((i) => i.partPaid)) },
    toRead: due.filter((i) => i.due === 'to_read').length,
    owingTotal: sum(due),
    stale: keepOld(staleCheques(today), (c) => `cheques:${c.uid}`, (c) => c.cheque_date).length,
    skipped,
    duplicateCheques: db().all("SELECT account_uid, cheque_no FROM cheques WHERE status <> 'void' GROUP BY account_uid, cheque_no HAVING COUNT(*) > 1").length,
  };
}

// Purchase orders of a supplier an invoice can be for (photo screen drop-down), newest first.
export function posForSupplier(supplierUid) {
  if (!supplierUid || !db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'po_orders'")) return [];
  return db().all("SELECT uid, po_no, order_date, total, status, shop_code FROM po_orders WHERE supplier_uid = ? AND status IN ('approved','sent','part','received','closed') ORDER BY order_date DESC LIMIT 30", [supplierUid]);
}

function addDaysLocal(d, n) { const [y, m, x] = String(d).split('-').map(Number); const t = new Date(Date.UTC(y, m - 1, x + n)); return t.toISOString().slice(0, 10); }

// build 42 (owner, 10 Nov: "all invoices need to show their VAT – most haven't been vetted to check if VAT is part of the
// invoice used for the VAT return"): for each invoice, its VAT and whether the VAT return counts it (and on which line),
// or why not – checked against the same rules as the return (payroll/returns.js vatReturnFRCS).
// → { vat, counted, line, level: 'ok' | 'warn' | 'bad' | 'none', text }
export function vatStatusOf(i) {
  if (!i) return null;
  const vat = r2(Math.abs(Number(i.vat) || 0));
  const sup = i.supplier_uid ? (() => { try { return getSupplier(i.supplier_uid); } catch (e) { return null; } })() : null;
  if (i.status === 'void') return { vat, counted: false, line: null, level: 'none', text: 'Void – not in the VAT return' };
  if (i.kind === 'credit') return vat ? { vat, counted: true, line: 5, level: 'ok', text: `Credit note: VAT ${$(vat)} goes on line 5 (reduces the VAT claimed)` } : { vat, counted: false, line: null, level: 'none', text: 'Credit note with no VAT' };
  if (!vat) {
    if (i.vat_type === 'zero' || (sup && !sup.vat_registered)) return { vat, counted: false, line: null, level: 'none', text: i.vat_type === 'zero' ? 'No VAT (zero-rated)' : 'No VAT – the supplier is not VAT-registered' };
    return { vat, counted: false, line: null, level: 'warn', text: 'VAT is $0 – check the invoice: is VAT on it?' };
  }
  // build 43: the VAT must fit the total – standard-rated: (total − zero-rated) × 12.5/112.5 (a few cents either way)
  const rate = (() => { try { return Number(apRules().vatRate) || 12.5; } catch (e) { return 12.5; } })();
  const total = Math.abs(Number(i.total) || 0); const zero = Math.abs(Number(i.zero_rated) || 0);
  const expect = r2(((total - zero) * rate) / (100 + rate));
  if (i.vat_type !== 'mixed' && Math.abs(expect - vat) > Math.max(0.05, total * 0.002)) return { vat, counted: !!txt(i.supplier_tin), line: txt(i.supplier_tin) ? 7 : null, level: 'bad', expect, text: `VAT ${$(vat)} does not fit the total ${$(total)}${zero ? ` (zero-rated ${$(zero)})` : ''} – it should be about ${$(expect)}. Check the invoice.` };
  if (i.vat_type === 'mixed' && vat > r2((total * rate) / (100 + rate)) + 0.05) return { vat, counted: !!txt(i.supplier_tin), line: txt(i.supplier_tin) ? 7 : null, level: 'bad', text: `VAT ${$(vat)} is more than ${rate}% of the whole total – check the invoice.` };
  if (!txt(i.supplier_tin)) return { vat, counted: false, line: null, level: 'bad', text: `VAT ${$(vat)} NOT claimed – the supplier has no TIN (add it to claim)` };
  if (i.status === 'to_check') return { vat, counted: true, line: 7, level: 'warn', text: `VAT ${$(vat)} – in the VAT return (line 7) once checked` };
  return { vat, counted: true, line: 7, level: 'ok', text: `VAT ${$(vat)} – in the VAT return (line 7, input schedule)` };
}

// ---------------------------------------------------------------- Release 06: a corrected payment carries through
// Owner, 12 Nov: "somewhere things are not talking to each other when a change is made". After a payment or its cheque
// is corrected, everything joined to it follows: the amount put against the invoice (when it pays one invoice), the
// cheque, the bank line of a transfer, the M-PAiSA wallet line, and the "PART PAYMENT … still owing" note. A payment
// over several invoices cannot be shared out by guessing: it is flagged until the amounts are put right.
// from: 'payment' (the payment was corrected) or 'cheque' (its cheque was corrected).
export function followPayment(paymentUid, from = 'payment') {
  const p = db().get('SELECT * FROM ap_payments WHERE uid = ?', [paymentUid || '']);
  if (!p || p.status !== 'active') return { changed: [] };
  const changed = [];
  const { now, dev } = meta();
  const held = r2(p.withheld || 0);
  const chq = p.cheque_uid ? db().get('SELECT * FROM cheques WHERE uid = ?', [p.cheque_uid]) : null;
  // the cheque was corrected: the payment takes its amount (plus what was kept back), number and date
  if (from === 'cheque' && chq) {
    const amt = r2(Number(chq.amount) + held);
    if (Math.abs(amt - Number(p.amount)) > 0.004 || String(chq.cheque_no) !== String(p.cheque_no || '')) {
      db().run(`UPDATE ap_payments SET amount = ?, cheque_no = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [amt, String(chq.cheque_no), now, dev, p.uid]);
      p.amount = amt; p.cheque_no = String(chq.cheque_no); changed.push('payment');
    }
  }
  const net = r2(Number(p.amount) - held);
  // the cheque follows the payment
  if (from === 'payment' && chq) {
    const sets = []; const vals = [];
    if (Math.abs(Number(chq.amount) - net) > 0.004) { sets.push('amount = ?'); vals.push(net); }
    if (p.cheque_no && String(chq.cheque_no) !== String(p.cheque_no)) { sets.push('cheque_no = ?'); vals.push(Number(p.cheque_no)); }
    if (sets.length) { db().run(`UPDATE cheques SET ${sets.join(', ')}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, vals.concat([now, dev, chq.uid])); changed.push('cheque'); }
  }
  // the bank line of a transfer and the wallet line of an M-PAiSA payment
  const be = db().get("SELECT * FROM bank_entries WHERE payment_uid = ? AND status = 'active'", [p.uid]);
  if (be && Math.abs(Number(be.amount) - net) > 0.004) { db().run(`UPDATE bank_entries SET amount = ?, entry_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [net, p.pay_date, now, dev, be.uid]); changed.push('bank line'); }
  try {
    const wm = db().get("SELECT * FROM wallet_moves WHERE note LIKE ? AND status = 'active'", [`%(payment ${p.uid})%`]);
    if (wm && Math.abs(Number(wm.amount) - net) > 0.004) { db().run(`UPDATE wallet_moves SET amount = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [net, now, dev, wm.uid]); changed.push('M-PAiSA line'); }
  } catch (e) { /* no wallets */ }
  // the invoice(s) it pays
  const al = db().all('SELECT * FROM ap_allocations WHERE payment_uid = ?', [p.uid]);
  const sumAl = r2(al.reduce((s, a) => s + Number(a.amount), 0));
  let unshared = 0;
  if (al.length === 1 && Math.abs(sumAl - Number(p.amount)) > 0.004) {
    const inv = getInvoice(al[0].invoice_uid);
    // what the invoice can still take: its owing plus what this payment already put on it
    const room = inv ? r2(inv.owing + Number(al[0].amount)) : 0;
    const put = r2(Math.min(Number(p.amount), room));
    db().run(`UPDATE ap_allocations SET amount = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [put, now, dev, al[0].uid]);
    changed.push('the invoice it pays');
    unshared = r2(Number(p.amount) - put);
  } else if (al.length > 1) unshared = r2(Number(p.amount) - sumAl);
  // the PART PAYMENT note says what is really still owing now
  const parts = db().all('SELECT a.amount, a.invoice_uid FROM ap_allocations a WHERE a.payment_uid = ?', [p.uid]).map((a) => {
    const i = getInvoice(a.invoice_uid);
    return i && i.owing > 0.004 ? `${i.invoice_no || 'no number'} (${$(i.owing)} still owing)` : null;
  }).filter(Boolean);
  const rest = String(p.notes || '').split(' · ').filter((x) => x && !/^PART PAYMENT/.test(x));
  const notes = [parts.length ? `PART PAYMENT – ${parts.join(', ')}` : null].concat(rest).filter(Boolean).join(' · ') || null;
  if ((notes || '') !== (p.notes || '')) { db().run(`UPDATE ap_payments SET notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [notes, now, dev, p.uid]); changed.push('note'); }
  return { changed, unshared: Math.abs(unshared) > 0.004 ? unshared : 0 };
}

// Release 06: item lines read from a supplier's invoice ({ code, description, qty, unitCost (before VAT), vatPct, unit })
// → the supplier's product list (inv_supplier_catalog: linked by itself when sure, otherwise "please confirm").
export function keepInvoiceLines(user, supplierUid, supplierName, date, lines, source = 'invoice') {
  if (!supplierUid || !Array.isArray(lines) || !lines.length) return null;
  const rows = lines.filter((l) => l && (txt(l.description) || txt(l.code))).map((l) => ({
    supplierUid, supplierName, code: txt(l.code) || null, name: txt(l.description) || null, unit: txt(l.unit) || null,
    cost: Number.isFinite(Number(l.unitCost)) && Number(l.unitCost) > 0 ? Math.round(Number(l.unitCost) * 10000) / 10000 : null,
    vat: l.vatPct === null || l.vatPct === undefined ? null : Number(l.vatPct), date: date || null,
  }));
  if (!rows.length) return null;
  return require('../inventory/supplierCatalog.js').keepLines(user, rows, { source });
}
