// Supplier statement (v3.5 B2): for one supplier and a period – opening balance, invoices and credit notes,
// payments (with cheque number and the dates the cheque was written / handed over / presented), a running
// balance, the closing balance split into not due / due / overdue, and what we owe compared with cheques that
// have not gone through the bank yet. The supplier statement check (their balance vs ours) sits next to it.
import { db } from '../../db/connection.js';
import { AppError, addDays, dateStr } from '../../services/core.js';
import * as AP from './service.js';
import { ourBalance } from './extras.js';

const { r2 } = AP;
const need = (c, m) => { if (!c) throw new AppError(m); };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const METHOD = { cheque: 'Cheque', cash: 'Cash', transfer: 'Bank transfer' };

// What was still owing on each invoice (and unused on each credit note) at the end of a day.
// What was paid on each invoice and used of each credit note up to a day, for every supplier at once (the
// all-suppliers summary works out each supplier's statement with it).
function doneUpTo(asOf) {
  const paid = new Map(); const used = new Map();
  db().all("SELECT a.invoice_uid AS u, SUM(a.amount) AS t FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE p.pay_date <= ? GROUP BY a.invoice_uid", [asOf])
    .forEach((r) => paid.set(r.u, r.t));
  db().all("SELECT credit_uid AS u, SUM(amount) AS t FROM ap_payments WHERE credit_uid IS NOT NULL AND status = 'active' AND pay_date <= ? GROUP BY credit_uid", [asOf]).forEach((r) => used.set(r.u, r.t));
  return { asOf, paid, used };
}
function openItemsAt(supplierUid, asOf, done = null) {
  let inv;
  if (done && done.asOf === asOf) {
    inv = db().all("SELECT * FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND invoice_date <= ? AND total > 0", [supplierUid, asOf])
      .map((i) => ({ ...i, _done: (i.kind === 'credit' ? done.used.get(i.uid) : done.paid.get(i.uid)) || 0 }));
  } else {
    // 1.0.0 speed: what was paid / used on each one is added up in the same read (was one read per invoice)
    inv = db().all(`SELECT i.*, CASE WHEN i.kind = 'credit'
        THEN (SELECT IFNULL(SUM(amount),0) FROM ap_payments WHERE credit_uid = i.uid AND status = 'active' AND pay_date <= ?)
        ELSE (SELECT IFNULL(SUM(a.amount),0) FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = i.uid AND p.pay_date <= ?) END AS _done
      FROM ap_invoices i WHERE i.supplier_uid = ? AND i.status <> 'void' AND i.invoice_date <= ? AND i.total > 0`, [asOf, asOf, supplierUid, asOf]);
  }
  const out = [];
  for (const row of inv) {
    const { _done, ...i } = row;
    if (i.kind === 'credit') {
      const left = r2(i.total - _done);
      if (left > 0.004) out.push({ ...i, left: -left });
    } else {
      const left = r2(i.total - _done);
      if (left > 0.004) out.push({ ...i, left });
    }
  }
  return out;
}

export function supplierStatement(supplierUid, from, to, { today = dateStr(), done = null } = {}) {
  const sup = AP.getSupplier(supplierUid);
  need(sup, 'Choose the supplier.');
  need(DATE.test(String(from)) && DATE.test(String(to)) && from <= to, 'Choose the period.');
  const rules = AP.apRules();
  const opening = ourBalance(supplierUid, addDays(from, -1));
  const lines = [];
  for (const i of db().all("SELECT * FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' AND total > 0 AND invoice_date BETWEEN ? AND ? ORDER BY invoice_date, entered_at", [supplierUid, from, to])) {
    const credit = i.kind === 'credit';
    lines.push({ date: i.invoice_date, sort: 0, kind: credit ? 'credit' : 'invoice', what: credit ? 'Credit note' : 'Invoice', ref: i.invoice_no || '', due: credit ? '' : i.due_date,
      charge: credit ? 0 : r2(i.total), credit: credit ? r2(i.total) : 0, uid: i.uid, status: i.status });
  }
  const pays = db().all(`SELECT p.*, c.cheque_date, c.handed_date, c.handed_to, c.presented_date, c.status AS cheque_status FROM ap_payments p LEFT JOIN cheques c ON c.uid = p.cheque_uid
      WHERE p.supplier_uid = ? AND p.status = 'active' AND p.method <> 'credit' AND p.pay_date BETWEEN ? AND ? ORDER BY p.pay_date, p.created_at`, [supplierUid, from, to]);
  // 1.0.0 the invoice numbers of all these payments in one read (in the same order as one read per payment gave)
  const invOf = new Map();
  if (pays.length) {
    for (const x of db().all(`SELECT a.payment_uid AS pu, i.invoice_no FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid JOIN ap_payments p ON p.uid = a.payment_uid
        WHERE p.supplier_uid = ? AND p.status = 'active' AND p.method <> 'credit' AND p.pay_date BETWEEN ? AND ? ORDER BY a.payment_uid, a.rowid`, [supplierUid, from, to])) {
      if (!invOf.has(x.pu)) invOf.set(x.pu, []);
      invOf.get(x.pu).push(x.invoice_no || '?');
    }
  }
  for (const p of pays) {
    const inv = invOf.get(p.uid) || [];
    lines.push({ date: p.pay_date, sort: 1, kind: 'payment', what: `${METHOD[p.method] || p.method}${p.withheld ? ' (incl. provisional tax kept back)' : ''}`, ref: p.cheque_no ? `Cheque ${p.cheque_no}` : p.reference || '',
      charge: 0, credit: r2(p.amount), uid: p.uid, method: p.method, chequeNo: p.cheque_no || null, invoices: inv,
      written: p.method === 'cheque' ? p.cheque_date || p.pay_date : null, handed: p.handed_date || null, handedTo: p.handed_to || null,
      presented: p.cheque_status === 'presented' ? p.presented_date : null, notCleared: p.method === 'cheque' && (p.cheque_status !== 'presented' || (p.presented_date && p.presented_date > to)) });
  }
  lines.sort((a, b) => (a.date === b.date ? a.sort - b.sort : a.date < b.date ? -1 : 1));
  let bal = opening;
  for (const l of lines) { bal = r2(bal + l.charge - l.credit); l.balance = bal; }
  const closing = r2(bal);
  // Closing balance split by due date (as at the last day of the period).
  const open = openItemsAt(supplierUid, to, done);
  const soon = addDays(to, rules.dueSoonDays);
  const split = { notDue: 0, due: 0, overdue: 0, credits: 0 };
  const openRows = [];
  for (const i of open) {
    let band = 'credits';
    if (i.kind !== 'credit') band = i.due_date < to ? 'overdue' : i.due_date <= soon ? 'due' : 'notDue';
    split[band] = r2(split[band] + i.left);
    openRows.push({ uid: i.uid, ref: i.invoice_no || '', date: i.invoice_date, due: i.kind === 'credit' ? '' : i.due_date, left: i.left, band, kind: i.kind,
      daysLate: i.kind !== 'credit' && i.due_date < to ? Math.round((new Date(`${to}T00:00:00`) - new Date(`${i.due_date}T00:00:00`)) / 86400000) : 0 });
  }
  openRows.sort((a, b) => (a.due || '9') < (b.due || '9') ? -1 : 1);
  // Cheques written to them that had not gone through the bank by the end of the period.
  const unpresented = db().all(`SELECT c.*, p.supplier_uid FROM cheques c JOIN ap_payments p ON p.uid = c.payment_uid AND p.status = 'active'
    WHERE p.supplier_uid = ? AND c.status IN ('written','presented') AND c.cheque_date <= ? AND (c.status = 'written' OR c.presented_date > ?) ORDER BY c.cheque_date`, [supplierUid, to, to]);
  const notHanded = unpresented.filter((c) => !c.handed_date || c.handed_date > to);
  const unpresentedTotal = r2(unpresented.reduce((s, c) => s + c.amount, 0));
  const notHandedTotal = r2(notHanded.reduce((s, c) => s + c.amount, 0));
  return {
    supplier: sup, from, to, today, opening, lines, closing,
    invoicesTotal: r2(lines.reduce((s, l) => s + l.charge, 0)),
    creditsTotal: r2(lines.filter((l) => l.kind === 'credit').reduce((s, l) => s + l.credit, 0)),
    paymentsTotal: r2(lines.filter((l) => l.kind === 'payment').reduce((s, l) => s + l.credit, 0)),
    split, openItems: openRows,
    unpresented, unpresentedTotal, notHanded, notHandedTotal,
    // What we owe in our books, and what the supplier will still be waiting for until our cheques are banked.
    weOwe: closing,
    beforeChequesClear: r2(closing + unpresentedTotal),
    lastCheck: db().get('SELECT * FROM supplier_statements WHERE supplier_uid = ? ORDER BY statement_date DESC, created_at DESC LIMIT 1', [supplierUid]) || null,
  };
}

// Suppliers with something in the period or a balance (for the all-suppliers summary).
export function statementSummary(from, to) {
  const list = AP.listSuppliers({ includeInactive: true });
  const done = list.length > 3 ? doneUpTo(to) : null; // 1.0.0 what was paid on every invoice, read once for all suppliers
  return list.map((s) => {
    const st = supplierStatement(s.uid, from, to, { done });
    return st;
  }).filter((st) => st.lines.length || Math.abs(st.closing) > 0.004 || Math.abs(st.opening) > 0.004);
}
