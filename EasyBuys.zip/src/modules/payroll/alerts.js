// Warnings for Home: pay runs to finish, tax / FNPF figures not checked, FNPF / PAYE payments late or due soon,
// payslips not signed (pay not released), "something is wrong" answers, and the tax & statutory calendar.
import { can } from '../../services/access.js';
import { payrollAlerts } from './service.js';
import { statAlerts } from './statutory.js';
import { signoffAlerts } from './signoff.js';
import { taxAlerts } from './taxCalendar.js';
import { returnsAlerts } from './returns.js';
import { $ } from '../payables/service.js';

export function alerts(user) {
  const out = [];
  const payOn = ['payroll_view', 'payroll_run', 'payroll_setup'].some((p) => can(user, p));
  if (payOn) {
    const p = payrollAlerts();
    if (p.draft) out.push({ id: 'pay-draft', level: 'info', text: `${p.draft} pay run${p.draft === 1 ? '' : 's'} to finish`, nav: { screen: 'Payroll', params: {} } });
    if (!p.confirmed && can(user, 'payroll_setup')) out.push({ id: 'pay-rules', level: 'warning', text: 'Payroll: check the tax and FNPF figures', sub: 'Tick "Checked" in Payroll rules when done.', nav: { screen: 'PayRules', params: {} } });
  }
  try { out.push(...signoffAlerts(user)); } catch (e) { /* tables not ready */ }
  if (can(user, 'statutory')) {
    let st = { late: [], dueSoon: [] };
    try { st = statAlerts(); } catch (e) { st = { late: [], dueSoon: [] }; }
    for (const x of st.late) out.push({ id: `stat-late-${x.kind}-${x.period}`, level: 'urgent', text: `${String(x.kind).toUpperCase()} for ${x.period} is late – ${$(x.amount)}`, sub: `It was due ${x.due_date}.`, nav: { screen: 'Statutory', params: {} } });
    for (const x of st.dueSoon) out.push({ id: `stat-due-${x.kind}-${x.period}`, level: 'warning', text: `${String(x.kind).toUpperCase()} for ${x.period} due ${x.due_date} – ${$(x.amount)}`, nav: { screen: 'Statutory', params: {} } });
  }
  // The tax calendar (FNPF / PAYE already warned about above are not repeated).
  const seen = new Set(out.filter((a) => /^stat-/.test(a.id)).map((a) => a.id.replace(/^stat-(late|due)-/, '')));
  // 3.9 returns: lodged then changed (amend), or paid short.
  try { out.push(...returnsAlerts(user)); } catch (e) { /* returns not ready */ }
  try { out.push(...taxAlerts(user).filter((a) => !seen.has(`${a.nav.params.kind}-${a.nav.params.period}`) || /lodged|proof|paid_not/.test(a.id))); } catch (e) { /* calendar not ready */ }
  return out;
}
