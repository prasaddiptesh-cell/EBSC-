// Payroll's dashboard card: tax & statutory deadlines with their two proofs (the "Tax due" card shows the amounts).
import { registerCard } from '../../services/dashboardCards.js';
import { taxCardData } from './taxCalendar.js';

registerCard({ id: 'taxcal', title: 'Tax deadlines', icon: '🗓️', order: 61, roles: ['payroll'], build() {
  return taxCardData();
} });
