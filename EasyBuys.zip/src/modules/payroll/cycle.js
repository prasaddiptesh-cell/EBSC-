// The pay cycle: which days a pay run covers and when it is paid. Fully admin-editable (Payroll › Pay cycle & pay day):
// how often (weekly / fortnightly / monthly), the day the pay week starts, and the pay day (days after the period ends).
// The default is the Easy Buys week: Saturday to Friday, paid on the Saturday after (the pay-day Saturday starts the next week).
import { AppError, addDays, dateStr, getShared, setShared, audit } from '../../services/core.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
export const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const FREQUENCIES = { weekly: 'Every week', fortnightly: 'Every two weeks', monthly: 'Every month' };
export const PERIODS_PER_YEAR = { weekly: 52, fortnightly: 26, monthly: 12 };

export const CYCLE_DEFAULTS = {
  frequency: 'weekly',
  startDay: 6,          // 0 = Sunday … 6 = Saturday (the pay week starts on this day)
  payDayAfter: 1,       // pay day = this many days after the last day of the period (0 = the last day itself)
  anchor: '2026-01-03', // fortnightly: a date on which a fortnight starts (keeps the fortnights in step)
  monthStartDay: 1,     // monthly: the day of the month a pay month starts (1 = calendar month)
};
export function payCycle() {
  return { ...CYCLE_DEFAULTS, ...(getShared('pay_cycle', {}) || {}) };
}
export function savePayCycle(user, c) {
  need(FREQUENCIES[c.frequency], 'Choose how often staff are paid.');
  const startDay = Number(c.startDay);
  need(Number.isInteger(startDay) && startDay >= 0 && startDay <= 6, 'Choose the day the pay week starts.');
  const payDayAfter = Number(c.payDayAfter);
  need(Number.isInteger(payDayAfter) && payDayAfter >= 0 && payDayAfter <= 31, 'Pay day must be 0 to 31 days after the period ends.');
  const anchor = String(c.anchor || CYCLE_DEFAULTS.anchor).trim();
  need(DATE.test(anchor), 'Choose a date when a fortnight starts.');
  const monthStartDay = Number(c.monthStartDay || 1);
  need(Number.isInteger(monthStartDay) && monthStartDay >= 1 && monthStartDay <= 28, 'A pay month starts on day 1 to 28.');
  const clean = { frequency: c.frequency, startDay, payDayAfter, anchor, monthStartDay };
  const before = payCycle();
  setShared('pay_cycle', clean);
  audit({ user, action: 'Changed the pay cycle and pay day', table: 'shared_settings', recordUid: 'pay_cycle', before, after: clean });
  return clean;
}

const dow = (iso) => { const [y, m, d] = iso.split('-').map(Number); return new Date(y, m - 1, d).getDay(); };
const daysBetween = (a, b) => { const [y1, m1, d1] = a.split('-').map(Number); const [y2, m2, d2] = b.split('-').map(Number); return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86400000); };
const pad = (n) => String(n).padStart(2, '0');
function monthAdd(y, m, n) { const t = y * 12 + (m - 1) + n; return [Math.floor(t / 12), (t % 12) + 1]; }

// The pay period a date falls in: { from, to, payDate, frequency, days, weeks, perYear }.
export function payPeriod(date = dateStr(), cycle = payCycle()) {
  const d = String(date).slice(0, 10);
  need(DATE.test(d), 'Choose a date.');
  let from;
  let to;
  if (cycle.frequency === 'monthly') {
    const [y, m, day] = d.split('-').map(Number);
    const sd = cycle.monthStartDay || 1;
    const [fy, fm] = day >= sd ? [y, m] : monthAdd(y, m, -1);
    from = `${fy}-${pad(fm)}-${pad(sd)}`;
    const [ny, nm] = monthAdd(fy, fm, 1);
    to = addDays(`${ny}-${pad(nm)}-${pad(sd)}`, -1);
  } else {
    const back = (dow(d) - Number(cycle.startDay) + 7) % 7;
    from = addDays(d, -back);
    if (cycle.frequency === 'fortnightly') {
      const a = cycle.anchor || CYCLE_DEFAULTS.anchor;
      const aStart = addDays(a, -((dow(a) - Number(cycle.startDay) + 7) % 7));
      const weeks = Math.round(daysBetween(aStart, from) / 7);
      if (((weeks % 2) + 2) % 2 === 1) from = addDays(from, -7);
      to = addDays(from, 13);
    } else to = addDays(from, 6);
  }
  const days = daysBetween(from, to) + 1;
  return { from, to, payDate: addDays(to, Number(cycle.payDayAfter) || 0), frequency: cycle.frequency, days, weeks: cycle.frequency === 'monthly' ? 52 / 12 : days / 7, perYear: PERIODS_PER_YEAR[cycle.frequency] || 52 };
}
// The period before the one a date falls in (the usual one to pay: "last week").
export function previousPeriod(date = dateStr(), cycle = payCycle()) {
  return payPeriod(addDays(payPeriod(date, cycle).from, -1), cycle);
}
// Blocks of up to 7 days inside a period (overtime is worked out per week).
export function weekBlocks(from, to) {
  const out = [];
  for (let s = from; s <= to; s = addDays(s, 7)) { const e = addDays(s, 6); out.push([s, e < to ? e : to]); }
  return out;
}
// Plain words for the Pay cycle screen: "Every week, Saturday to Friday, paid Saturday (1 day after)".
export function cycleWords(cycle = payCycle(), today = dateStr()) {
  const p = payPeriod(today, cycle);
  const what = cycle.frequency === 'monthly'
    ? `Every month from day ${cycle.monthStartDay || 1}`
    : `${FREQUENCIES[cycle.frequency]}, ${WEEKDAY_NAMES[cycle.startDay]} to ${WEEKDAY_NAMES[(Number(cycle.startDay) + 6) % 7]}`;
  return `${what}, paid ${cycle.payDayAfter ? `${cycle.payDayAfter} day${cycle.payDayAfter === 1 ? '' : 's'} after the period ends` : 'on the last day'} (${WEEKDAY_NAMES[dow(p.payDate)]}). This period: ${p.from} to ${p.to}, pay day ${p.payDate}.`;
}
