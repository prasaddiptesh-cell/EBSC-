// Filing formats (v3.5): the admin uploads the official FRCS / FNPF template (Excel or CSV) and says which of our
// figures goes in each of its columns. Until a template is set up, the app gives PDF / Excel / CSV copies of its own
// layout. Pre-filing checks run first (missing TIN or FNPF number, draft pay runs, unsigned payslips, totals that do
// not agree…). Also the weekly pay day report that puts both shops together.
import JSZip from 'jszip';
import { db } from '../../db/connection.js';
import { AppError, stamp, audit, getShared, setShared, money } from '../../services/core.js';
import { actsAsOwner } from '../../services/access.js';
import * as P from './service.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';

export const FILING_KINDS = {
  fnpf: { title: 'FNPF monthly schedule', to: 'FNPF', period: 'month' },
  paye: { title: 'PAYE employer monthly schedule', to: 'FRCS', period: 'month' },
  payday: { title: 'Pay day report (both shops)', to: 'FRCS', period: 'payday' },
};
// The figures that can go into a template column.
export const FILING_FIELDS = {
  employer_name: 'Employer name', employer_tin: 'Employer TIN', employer_fnpf: 'Employer FNPF number', period: 'Period (month or pay day)', pay_date: 'Pay day',
  name: 'Full name', first_name: 'First name', last_name: 'Surname', employee_no: 'Employee number', shop: 'Shop', tin: 'TIN', fnpf_no: 'FNPF number',
  gross: 'Gross pay', fnpf_wages: 'Wages counted for FNPF', fnpf_employee: 'FNPF employee', fnpf_employer: 'FNPF employer', fnpf_total: 'FNPF total',
  taxable: 'Pay counted for PAYE', paye: 'PAYE / SRT', net: 'Net pay', weeks: 'Pays in the period',
};
const GUESS = [
  [/employee.*(contr|share|8)|member.*contr/i, 'fnpf_employee'], [/employer.*(contr|share|10)/i, 'fnpf_employer'], [/total.*contr|contr.*total/i, 'fnpf_total'],
  [/employer.*tin|tin.*employer/i, 'employer_tin'], [/employer.*(fnpf|reg)/i, 'employer_fnpf'], [/employer|company/i, 'employer_name'],
  [/first|given/i, 'first_name'], [/sur|last|family/i, 'last_name'], [/^name$|full.?name|member.?name|employee.?name/i, 'name'],
  [/fnpf.*(no|num|#)|member.*(no|num)/i, 'fnpf_no'], [/tin/i, 'tin'], [/emp.*(no|num|id)|staff.*(no|id)/i, 'employee_no'],
  [/paye|tax.*deduct|srt/i, 'paye'], [/taxable|chargeable/i, 'taxable'], [/gross|total.*(wage|pay|earn)/i, 'gross'], [/wage|salary|earn/i, 'fnpf_wages'], [/net/i, 'net'],
  [/pay.*date|date.*paid/i, 'pay_date'], [/period|month/i, 'period'], [/shop|branch|site/i, 'shop'],
];
export function guessMapping(headers) {
  const out = {};
  headers.forEach((h) => { const g = GUESS.find(([re]) => re.test(String(h))); out[h] = g ? { field: g[1] } : { field: '' }; });
  return out;
}
// Headers from an uploaded template: the first row that has at least two filled cells (rows: arrays of cells; or CSV text).
export function templateHeaders(rowsOrText) {
  let rows = rowsOrText;
  if (typeof rowsOrText === 'string') rows = parseCsv(rowsOrText);
  const row = (rows || []).find((r) => (r || []).filter((c) => txt(c)).length >= 2) || [];
  return row.map(txt).filter(Boolean);
}
export function parseCsv(text) {
  const out = [];
  let row = []; let cell = ''; let q = false;
  const s = String(text || '').replace(/^﻿/, '');
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) { if (ch === '"' && s[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch; continue; }
    if (ch === '"') q = true; else if (ch === ',') { row.push(cell); cell = ''; } else if (ch === '\n' || ch === '\r') { if (ch === '\r' && s[i + 1] === '\n') i++; row.push(cell); out.push(row); row = []; cell = ''; } else cell += ch;
  }
  if (cell || row.length) { row.push(cell); out.push(row); }
  return out;
}

// ---------------------------------------------------------------- employer details and templates (admin)
export function employerDetails() { return { name: 'Easy Buys Shopping Centre', tin: '', fnpfNo: '', ...(getShared('employer_details', {}) || {}) }; }
export function saveEmployerDetails(user, d) {
  need(isTop(user), 'Only the owner or admin can change the employer details.');
  const cur = employerDetails();
  const keep = (k) => (d[k] === undefined ? cur[k] || '' : txt(d[k]));
  // 3.9: the rest of the FNPF Contribution Schedule header (trading name, postal address, city, contribution type).
  const clean = { name: txt(d.name) || 'Easy Buys Shopping Centre', tin: txt(d.tin).replace(/\s/g, ''), fnpfNo: txt(d.fnpfNo), tradingName: keep('tradingName'), postal: keep('postal'), city: keep('city') || 'Lautoka', contributionType: keep('contributionType') || 'Normal' };
  setShared('employer_details', clean);
  audit({ user, action: 'Changed the employer details for filing', table: 'shared_settings', recordUid: 'employer_details', after: clean });
  return clean;
}
export function filingTemplates() { return getShared('filing_templates', {}) || {}; }
export function filingTemplate(kind) { return filingTemplates()[kind] || null; }
// mapping: { header: { field } | { fixed: 'text' } }
export function saveFilingTemplate(user, kind, { name, fileType = 'csv', headers = [], mapping = {}, docUid }) {
  need(isTop(user), 'Only the owner or admin can set up filing templates.');
  need(FILING_KINDS[kind], 'Which filing?');
  const hs = headers.map(txt).filter(Boolean);
  need(hs.length, 'The template has no column headings. Choose the official file again.');
  const clean = {};
  for (const h of hs) {
    const m = mapping[h] || {};
    if (m.fixed !== undefined && txt(m.fixed)) clean[h] = { fixed: txt(m.fixed) };
    else clean[h] = { field: FILING_FIELDS[m.field] ? m.field : '' };
  }
  const t = { name: txt(name) || FILING_KINDS[kind].title, fileType: fileType === 'xlsx' ? 'xlsx' : 'csv', headers: hs, mapping: clean, docUid: docUid || null, savedBy: user.name, savedAt: stamp() };
  const all = filingTemplates();
  const before = all[kind] || null;
  setShared('filing_templates', { ...all, [kind]: t });
  audit({ user, action: `Filing template for ${FILING_KINDS[kind].title} saved (${hs.length} columns)`, table: 'shared_settings', recordUid: `filing_templates.${kind}`, before, after: t });
  return t;
}
export function removeFilingTemplate(user, kind) {
  need(isTop(user), 'Only the owner or admin can change filing templates.');
  const all = filingTemplates();
  const before = all[kind];
  if (!before) return;
  const next = { ...all };
  delete next[kind];
  setShared('filing_templates', next);
  audit({ user, action: `Filing template for ${FILING_KINDS[kind].title} taken off (the app's own layout is used again)`, table: 'shared_settings', recordUid: `filing_templates.${kind}`, before });
}

// ---------------------------------------------------------------- the figures
function linesFor(kind, period) {
  if (!has('pay_runs')) return [];
  if (kind === 'payday') return db().all(`SELECT l.*, r.pay_date, r.uid AS run FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND r.pay_date = ? ORDER BY l.shop_code, l.name`, [period]);
  return db().all(`SELECT l.*, r.pay_date, r.uid AS run FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND substr(r.pay_date,1,7) = ? ORDER BY l.name`, [period]);
}
// One row per person with every field (money as plain numbers, 2 decimals).
export function filingRows(kind, period) {
  need(FILING_KINDS[kind], 'Which filing?');
  const emp = employerDetails();
  const per = {};
  for (const l of linesFor(kind, period)) {
    const p = P.getProfile(l.user_uid) || {};
    const x = (per[l.user_uid] = per[l.user_uid] || { userUid: l.user_uid, name: l.name, employee_no: l.employee_no || '', shop: l.shop_code || '', tin: p.tin || '', fnpf_no: p.fnpf_no || '',
      gross: 0, fnpf_wages: 0, fnpf_employee: 0, fnpf_employer: 0, taxable: 0, paye: 0, net: 0, weeks: 0, pay_date: l.pay_date });
    x.gross += l.gross; x.fnpf_wages += l.fnpf_base; x.fnpf_employee += l.fnpf_employee; x.fnpf_employer += l.fnpf_employer; x.taxable += l.taxable; x.paye += l.paye; x.net += l.net; x.weeks += 1;
    if (l.pay_date > x.pay_date) x.pay_date = l.pay_date;
  }
  return Object.values(per).map((x) => {
    const parts = String(x.name).trim().split(/\s+/);
    const out = { ...x, first_name: parts.slice(0, -1).join(' ') || parts[0], last_name: parts.length > 1 ? parts[parts.length - 1] : '', employer_name: emp.name, employer_tin: emp.tin, employer_fnpf: emp.fnpfNo, period };
    ['gross', 'fnpf_wages', 'fnpf_employee', 'fnpf_employer', 'taxable', 'paye', 'net'].forEach((k) => { out[k] = r2(out[k]); });
    out.fnpf_total = r2(out.fnpf_employee + out.fnpf_employer);
    return out;
  }).filter((x) => (kind === 'fnpf' ? x.fnpf_total > 0 || x.fnpf_wages > 0 : true)).sort((a, b) => (a.name < b.name ? -1 : 1));
}

// Pre-filing checks: [{ level: 'bad' | 'warn' | 'ok', text }].
export function filingChecks(kind, period) {
  const rows = filingRows(kind, period);
  const out = [];
  const emp = employerDetails();
  if (!rows.length) out.push({ level: 'bad', text: 'There are no final pay runs in this period.' });
  const draft = has('pay_runs') ? db().all(`SELECT week_start, pay_date FROM pay_runs WHERE status = 'draft' AND ${kind === 'payday' ? 'pay_date = ?' : 'substr(pay_date,1,7) = ?'}`, [period]) : [];
  if (draft.length) out.push({ level: 'bad', text: `${draft.length} pay run(s) paid in this period are still drafts – make them final first.` });
  if (kind !== 'fnpf') rows.filter((r) => !r.tin && r.paye > 0).forEach((r) => out.push({ level: 'bad', text: `${r.name}: no TIN.` }));
  if (kind !== 'paye') rows.filter((r) => !r.fnpf_no && r.fnpf_total > 0).forEach((r) => out.push({ level: 'bad', text: `${r.name}: no FNPF number.` }));
  if (kind === 'fnpf' && !emp.fnpfNo) out.push({ level: 'warn', text: 'The employer FNPF number is not set (Filing formats › Employer details).' });
  if (kind !== 'fnpf' && !emp.tin) out.push({ level: 'warn', text: 'The employer TIN is not set (Filing formats › Employer details).' });
  rows.filter((r) => r.net < 0).forEach((r) => out.push({ level: 'bad', text: `${r.name}: net pay is below zero.` }));
  // FNPF must be the set % of the wages counted (rounding up to 5 cents per pay allowed).
  if (kind === 'fnpf') {
    const rules = P.payRules();
    rows.forEach((r) => { const pct = P.employerPctOn(rules, r.pay_date); if (Math.abs(r.fnpf_employer - r2(r.fnpf_wages * pct / 100)) > 0.05 * r.weeks) out.push({ level: 'warn', text: `${r.name}: employer FNPF does not equal ${pct}% of the wages counted (the rate on ${r.pay_date}).` }); });
  }
  // Payslips not signed.
  if (has('pay_slip_status') && kind === 'payday') {
    try {
      const { runSlips } = require('./signoff.js');
      const runs = db().all("SELECT uid FROM pay_runs WHERE status = 'final' AND pay_date = ?", [period]);
      const n = runs.reduce((s, r) => s + runSlips(r.uid).filter((x) => !x.released).length, 0);
      if (n) out.push({ level: 'warn', text: `${n} payslip(s) not signed yet.` });
    } catch (e) { /* ignore */ }
  }
  // Undecided till shortages in the period.
  const undecided = linesFor(kind, period).reduce((s, l) => s + J(l.undecided, []).length, 0);
  if (undecided) out.push({ level: 'warn', text: `${undecided} till shortage(s) were not decided when the pay was worked out.` });
  // Totals agree with the FNPF / PAYE payment records.
  if ((kind === 'fnpf' || kind === 'paye') && has('stat_payments')) {
    const s = db().get("SELECT * FROM stat_payments WHERE uid = ? AND status = 'active'", [`STAT-${kind}-${period}`]);
    const total = r2(rows.reduce((a, r) => a + (kind === 'fnpf' ? r.fnpf_total : r.paye), 0));
    if (s && s.paid_amount !== null && s.paid_amount !== undefined && Math.abs(s.paid_amount - total) > 0.004) out.push({ level: 'warn', text: `Paid ${$(s.paid_amount)} but this schedule adds up to ${$(total)}.` });
  }
  if (!out.length) out.push({ level: 'ok', text: 'Every check passed.' });
  return out;
}

// The table to file: the template's columns when set up, otherwise the app's own layout.
const DEFAULT_COLUMNS = {
  fnpf: ['fnpf_no', 'name', 'employee_no', 'fnpf_wages', 'fnpf_employee', 'fnpf_employer', 'fnpf_total'],
  paye: ['tin', 'name', 'employee_no', 'gross', 'taxable', 'paye'],
  payday: ['shop', 'name', 'employee_no', 'tin', 'gross', 'taxable', 'paye', 'fnpf_employee', 'fnpf_employer', 'net'],
};
export function filingTable(kind, period) {
  const rows = filingRows(kind, period);
  const t = filingTemplate(kind);
  if (t) {
    return { template: t, headers: t.headers, rows: rows.map((r) => t.headers.map((h) => { const m = t.mapping[h] || {}; if (m.fixed !== undefined) return m.fixed; return m.field ? (r[m.field] === undefined ? '' : r[m.field]) : ''; })) };
  }
  const keys = DEFAULT_COLUMNS[kind];
  return { template: null, headers: keys.map((k) => FILING_FIELDS[k]), rows: rows.map((r) => keys.map((k) => r[k])) };
}
const csvCell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
export function tableCsv(headers, rows) { return [headers].concat(rows).map((r) => r.map(csvCell).join(',')).join('\r\n'); }
// A one-sheet Excel file with just the headings and rows (the official layout).
export async function tableXlsxBase64(headers, rows, sheet = 'Sheet1') {
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const colName = (i) => { let s = ''; let n = i + 1; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const cell = (ref, v) => (v === null || v === undefined || v === '' ? '' : typeof v === 'number' && Number.isFinite(v) ? `<c r="${ref}"><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`);
  const data = [headers].concat(rows).map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => cell(`${colName(ci)}${ri + 1}`, v)).join('')}</row>`).join('');
  const zip = new JSZip();
  zip.file('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
  zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${esc(String(sheet).slice(0, 31))}" sheetId="1" r:id="rId1"/></sheets></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
  zip.file('xl/worksheets/sheet1.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${data}</sheetData></worksheet>`);
  return zip.generateAsync({ type: 'base64' });
}
// The filing as a report (PDF / Excel / CSV copy with the checks on it).
export function filingReport(kind, period) {
  const k = FILING_KINDS[kind];
  need(k, 'Which filing?');
  const tab = filingTable(kind, period);
  const checks = filingChecks(kind, period);
  const rows = filingRows(kind, period);
  const t = (f) => $(rows.reduce((s, r) => s + r[f], 0));
  const keys = tab.headers.map((h, i) => `c${i}`);
  const money = new Set(['gross', 'fnpf_wages', 'fnpf_employee', 'fnpf_employer', 'fnpf_total', 'taxable', 'paye', 'net']);
  const fieldOf = (i) => (tab.template ? (tab.template.mapping[tab.headers[i]] || {}).field : DEFAULT_COLUMNS[kind][i]);
  return {
    kind: `filing_${kind}`, title: k.title, fileName: `${k.title.replace(/\W+/g, '-')}-${period}`, subtitle: `${employerDetails().name} · ${period}${tab.template ? ` · layout: ${tab.template.name}` : ''}`,
    info: [['Period', period], ['Employer TIN', employerDetails().tin || '—'], ['Employer FNPF no', employerDetails().fnpfNo || '—'], ['Layout', tab.template ? `${tab.template.name} (uploaded template)` : "The app's own layout – no template uploaded yet"], ['Generated', stamp()]],
    summary: [{ label: 'People', value: String(rows.length) }, { label: 'Gross', value: t('gross') }].concat(kind === 'fnpf' ? [{ label: 'FNPF total', value: t('fnpf_total') }] : [{ label: 'PAYE', value: t('paye') }]),
    sections: [
      { title: 'Checks before filing', columns: [col('l', 'Result'), col('t', 'Check')], rows: checks.map((c) => ({ l: c.level === 'ok' ? '✓' : c.level === 'bad' ? 'FIX' : 'Check', t: c.text, _tone: c.level === 'bad' ? 'bad' : c.level === 'warn' ? 'warn' : null })) },
      { title: 'Schedule', columns: tab.headers.map((h, i) => col(keys[i], h, money.has(fieldOf(i)) ? R : 'left')), rows: tab.rows.map((r) => Object.fromEntries(r.map((v, i) => [keys[i], money.has(fieldOf(i)) && typeof v === 'number' ? v.toFixed(2) : v]))) },
    ],
  };
}

// ---------------------------------------------------------------- weekly pay day report (both shops together)
export function payDayReport(from, to = from) {
  const lines = has('pay_runs') ? db().all(`SELECT l.*, r.pay_date, r.run_kind, r.label FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND r.pay_date BETWEEN ? AND ? ORDER BY r.pay_date, l.shop_code, l.name`, [from, to]) : [];
  const shops = Array.from(new Set(lines.map((l) => l.shop_code || 'Not set'))).sort();
  const sum = (list, k) => r2(list.reduce((s, l) => s + l[k], 0));
  const row = (l) => { const p = P.getProfile(l.user_uid) || {}; return { pay: l.pay_date, name: l.name, emp: l.employee_no || '', tin: p.tin || '', fnpfNo: p.fnpf_no || '', gross: $(l.gross), taxable: $(l.taxable), paye: $(l.paye), fe: $(l.fnpf_employee), fr: $(l.fnpf_employer), net: $(l.net), how: l.pay_method === 'bank' ? 'bank' : 'cash', _tone: (!p.tin && l.paye > 0) ? 'warn' : null }; };
  const cols = [col('pay', 'Pay day'), col('name', 'Name'), col('emp', 'Emp no'), col('tin', 'TIN'), col('fnpfNo', 'FNPF no'), col('gross', 'Gross', R), col('taxable', 'Counted for PAYE', R), col('paye', 'PAYE', R), col('fe', 'FNPF staff', R), col('fr', 'FNPF employer', R), col('net', 'Net', R), col('how', 'Paid by')];
  const totalsRow = (label, list) => ({ shop: label, people: String(new Set(list.map((l) => l.user_uid)).size), gross: $(sum(list, 'gross')), paye: $(sum(list, 'paye')), fe: $(sum(list, 'fnpf_employee')), fr: $(sum(list, 'fnpf_employer')), net: $(sum(list, 'net')) });
  return {
    kind: 'pay_day_report', title: 'Pay Day Report', fileName: `Pay-Day-Report-${from}${from === to ? '' : `-to-${to}`}`, subtitle: `Easy Buys Shopping Centre · both shops · pay day${from === to ? ` ${from}` : `s ${from} to ${to}`}`,
    info: [['Pay day(s)', from === to ? from : `${from} to ${to}`], ['Shops', shops.join(', ') || '—'], ['Generated', stamp()]],
    summary: [{ label: 'People', value: String(new Set(lines.map((l) => l.user_uid)).size) }, { label: 'Gross', value: $(sum(lines, 'gross')) }, { label: 'PAYE', value: $(sum(lines, 'paye')) }, { label: 'FNPF (employee + employer)', value: $(sum(lines, 'fnpf_employee') + sum(lines, 'fnpf_employer')) }, { label: 'Net', value: $(sum(lines, 'net')) }],
    sections: [{ title: 'Both shops together', columns: [col('shop', 'Shop'), col('people', 'People', R), col('gross', 'Gross', R), col('paye', 'PAYE', R), col('fe', 'FNPF staff', R), col('fr', 'FNPF employer', R), col('net', 'Net', R)],
      rows: shops.map((s) => totalsRow(s, lines.filter((l) => (l.shop_code || 'Not set') === s))).concat([totalsRow('ALL SHOPS', lines)]) }]
      .concat(shops.map((s) => ({ title: `Shop ${s}`, columns: cols, rows: lines.filter((l) => (l.shop_code || 'Not set') === s).map(row) }))),
  };
}
export const FILING_REPORTS = [
  { id: 'pay_day_report', group: 'Payroll', icon: '🗓️', title: 'Pay day report (both shops)', desc: 'Everyone paid on the pay days in the period, shop by shop and together – for the PAYE pay day filing', perm: 'payroll_view', build(from, to) { return payDayReport(from, to); } },
  { id: 'filing_fnpf', group: 'Payroll', icon: '🏦', title: 'FNPF schedule (filing layout)', desc: 'In the uploaded FNPF template layout, with the checks before filing (month of the first day)', perm: 'statutory', build(from) { return filingReport('fnpf', from.slice(0, 7)); } },
  { id: 'filing_paye', group: 'Payroll', icon: '🧮', title: 'PAYE schedule (filing layout)', desc: 'In the uploaded FRCS template layout, with the checks before filing (month of the first day)', perm: 'statutory', build(from) { return filingReport('paye', from.slice(0, 7)); } },
];
