// Payroll module: pay runs from the timesheets (any pay cycle), extra pay runs, pay details, advances & loans,
// tax/FNPF rules, payslips and the pay sign-off, the tax & statutory calendar and filing.
import { PayrollHomeScreen, PayRunScreen, PayLineScreen, PayProfilesScreen, PayProfileScreen, StaffDebtsScreen, PayRulesScreen, MyPayslipsScreen } from './screens/PayrollScreens.js';
import { NewPayRunScreen } from './screens/PayRunStepsScreens.js';
import { REPORTS } from './reports.js';
import { StatutoryScreen, YearEndScreen, FinalPayScreen } from './screens/StatutoryScreens.js';
import { PayCycleScreen, ExtraPayRunScreen, PaySignOffScreen, PaySignLockedScreen, PaySignSettingsScreen, PayStatRulesScreen, TaxCalendarScreen, TaxItemScreen, TaxCalendarSettingsScreen,
  FilingScreen, FilingSetupScreen } from './screens/Payroll35Screens.js';
import { TaxReturnsScreen, TaxReturnScreen } from './screens/ReturnsScreens.js';
import { STAT_REPORTS } from './statReports.js';
import { FILING_REPORTS } from './filing.js';
import { payslipReport } from './payslip.js';
import { canRunSignoff } from './signoff.js';
import { can } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import './cards.js';
import { V1_PAY_REPORTS } from './v1Pay.js';
import { PayWeekScreen, PayslipCleanScreen, MyPayScreen, FnpfMonthScreen } from './screens/V1PayScreens.js';

const taxView = (u) => can(u, 'statutory') || can(u, 'accounts_view') || can(u, 'payroll_view');
// One payslip (opened from a pay run or the sign-off); without a line, the latest final payslip.
const ONE_PAYSLIP = { id: 'payslip_one', group: 'Payroll', icon: '🧾', title: 'One payslip', desc: 'The latest payslip (open a person in a pay run to choose one)', perm: 'payroll_view',
  build(from, to, user, params = {}) {
    const l = params.lineUid ? { uid: params.lineUid } : db().get("SELECT l.uid FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 ORDER BY r.pay_date DESC LIMIT 1");
    return payslipReport(l ? l.uid : '');
  } };

export default {
  id: 'payroll',
  title: 'Payroll',
  icon: '💰',
  switchable: true,
  screens: {
    Payroll: { component: PayrollHomeScreen, can: (u) => can(u, 'payroll_view') || can(u, 'payroll_run') || can(u, 'payroll_setup') },
    NewPayRun: { component: NewPayRunScreen, can: (u) => can(u, 'payroll_run') },
    PayRun: { component: PayRunScreen, can: (u) => can(u, 'payroll_view') || can(u, 'payroll_run') },
    PayLine: { component: PayLineScreen, can: (u) => can(u, 'payroll_view') || can(u, 'my_hours') },
    PayProfiles: { component: PayProfilesScreen, can: (u) => can(u, 'payroll_setup') },
    PayProfile: { component: PayProfileScreen, can: (u) => can(u, 'payroll_setup') },
    StaffDebts: { component: StaffDebtsScreen, can: (u) => can(u, 'payroll_run') },
    PayRules: { component: PayRulesScreen, can: (u) => can(u, 'payroll_setup') },
    Statutory: { component: StatutoryScreen, can: (u) => can(u, 'statutory') || can(u, 'payroll_view') },
    PayYearEnd: { component: YearEndScreen, can: (u) => can(u, 'statutory') },
    FinalPay: { component: FinalPayScreen, can: (u) => can(u, 'payroll_run') },
    MyPayslips: { component: MyPayslipsScreen, can: (u) => can(u, 'my_hours') },
    // v3.5
    PayCycle: { component: PayCycleScreen, can: (u) => can(u, 'payroll_setup') || can(u, 'payroll_view') },
    ExtraPayRun: { component: ExtraPayRunScreen, can: (u) => can(u, 'payroll_run') },
    PaySignOff: { component: PaySignOffScreen, can: (u) => canRunSignoff(u) },
    PaySignLocked: { component: PaySignLockedScreen, can: (u) => canRunSignoff(u) },
    PaySignSettings: { component: PaySignSettingsScreen, can: (u) => can(u, 'payroll_setup') },
    PayStatRules: { component: PayStatRulesScreen, can: (u) => can(u, 'payroll_setup') },
    TaxCalendar: { component: TaxCalendarScreen, can: taxView },
    TaxItem: { component: TaxItemScreen, can: taxView },
    TaxReturns: { component: TaxReturnsScreen, can: taxView },
    TaxReturn: { component: TaxReturnScreen, can: taxView },
    TaxCalendarSettings: { component: TaxCalendarSettingsScreen, can: (u) => can(u, 'payroll_setup') || can(u, 'accounts_setup') },
    Filing: { component: FilingScreen, can: (u) => can(u, 'statutory') || can(u, 'payroll_view') },
    FilingSetup: { component: FilingSetupScreen, can: (u) => can(u, 'payroll_setup') },
    // 1.0.0 (build 1) payroll at a glance, the clean payslip, My pay, FNPF for the accountant
    PayWeek: { component: PayWeekScreen, can: (u) => can(u, 'payroll_view') || can(u, 'payroll_run') },
    PayslipClean: { component: PayslipCleanScreen, can: (u) => !!u },
    MyPay: { component: MyPayScreen, can: (u) => !!u },
    FnpfMonth: { component: FnpfMonthScreen, can: (u) => can(u, 'statutory') || can(u, 'payroll_view') || can(u, 'accounts_view') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS.concat(STAT_REPORTS, FILING_REPORTS, [ONE_PAYSLIP], V1_PAY_REPORTS),
};
