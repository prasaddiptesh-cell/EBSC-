// Payroll module: weekly pay runs from the timesheets, pay details, advances & loans, tax/FNPF rules, payslips.
import { PayrollHomeScreen, PayRunScreen, PayLineScreen, PayProfilesScreen, PayProfileScreen, StaffDebtsScreen, PayRulesScreen, MyPayslipsScreen } from './screens/PayrollScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

export default {
  id: 'payroll',
  title: 'Payroll',
  icon: '💰',
  switchable: true,
  screens: {
    Payroll: { component: PayrollHomeScreen, can: (u) => can(u, 'payroll_view') || can(u, 'payroll_run') || can(u, 'payroll_setup') },
    PayRun: { component: PayRunScreen, can: (u) => can(u, 'payroll_view') || can(u, 'payroll_run') },
    PayLine: { component: PayLineScreen, can: (u) => can(u, 'payroll_view') || can(u, 'my_hours') },
    PayProfiles: { component: PayProfilesScreen, can: (u) => can(u, 'payroll_setup') },
    PayProfile: { component: PayProfileScreen, can: (u) => can(u, 'payroll_setup') },
    StaffDebts: { component: StaffDebtsScreen, can: (u) => can(u, 'payroll_run') },
    PayRules: { component: PayRulesScreen, can: (u) => can(u, 'payroll_setup') },
    MyPayslips: { component: MyPayslipsScreen, can: (u) => can(u, 'my_hours') },
  },
  reports: REPORTS,
};
