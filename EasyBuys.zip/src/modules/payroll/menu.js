// Payroll menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '💰', title: 'Pay runs', note: 'This pay period and the latest pay runs.', screen: 'Payroll' },
    { id: 'pay-new', icon: '▶️', title: 'Start a pay run', note: 'Confirm the dates, choose who is paid, check each person.', screen: 'NewPayRun', perm: 'payroll_run' },
    { id: 'pay-signoff', icon: '✍️', title: 'Pay sign-off', note: 'Each person checks and signs their payslip – then their pay is released.', screen: 'PaySignOff' },
    { id: 'pay-extra', icon: '🎁', title: 'Extra pay run', note: 'A one-off bonus or back pay.', screen: 'ExtraPayRun', perm: 'payroll_run' },
    { id: 'pay-debts', icon: '🤝', title: 'Advances & staff loans', screen: 'StaffDebts' },
    { id: 'pay-final', icon: '👋', title: 'Someone leaving (final pay)', screen: 'FinalPay' },
    { id: 'pay-mine', icon: '🧾', title: 'My payslips', screen: 'MyPayslips' },
  ] },
  { section: 'Records', items: [
    { id: 'pay-stat', icon: '🏦', title: 'FNPF & PAYE payments', screen: 'Statutory' },
    { id: 'pay-taxcal', icon: '🗓️', title: 'Tax & statutory calendar', note: 'VAT, FNPF, PAYE, pay day reports, provisional, advance and company tax – lodgement and payment proofs.', screen: 'TaxCalendar' },
  ] },
  { section: 'Checks', items: [
    { id: 'pay-yearend', icon: '📅', title: 'Year end', note: 'Totals per person, certificates.', screen: 'PayYearEnd' },
    { id: 'pay-filing', icon: '📤', title: 'Filing (FNPF / FRCS)', note: 'Checks before filing, then the file in the official layout.', screen: 'Filing' },
  ] },
  { section: 'Reports', items: [
    { id: 'pay-reports', icon: '📊', title: 'Payroll reports', screen: 'ReportsHub', params: { group: 'Payroll' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'pay-profiles', icon: '🪪', title: 'Pay details', note: 'Rates, salaries, FNPF and TIN numbers, FNPF / PAYE per person.', screen: 'PayProfiles' },
    { id: 'pay-rules', icon: '⚙️', title: 'Rules, tax, FNPF, holidays', screen: 'PayRules' },
    { id: 'pay-cycle', icon: '🔁', title: 'Pay cycle & pay day', note: 'Weekly, fortnightly or monthly; the day the week starts; pay day.', screen: 'PayCycle' },
    { id: 'pay-signoff-settings', icon: '✍️', title: 'Pay sign-off settings', note: 'Who may run it; email / Viber after signing.', screen: 'PaySignSettings' },
    { id: 'pay-taxcal-settings', icon: '🗓️', title: 'Tax calendar settings', note: 'Due rules, reminders and the responsible person.', screen: 'TaxCalendarSettings' },
    { id: 'pay-filing-setup', icon: '📑', title: 'Filing templates', note: 'Upload the official FRCS / FNPF files and match their columns.', screen: 'FilingSetup' },
  ] },
];
