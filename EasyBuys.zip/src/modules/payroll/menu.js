// Payroll menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '💰', title: 'Pay runs', note: 'This week and the latest pay runs.', screen: 'Payroll' },
    { id: 'pay-debts', icon: '🤝', title: 'Advances & staff loans', screen: 'StaffDebts' },
    { id: 'pay-final', icon: '👋', title: 'Someone leaving (final pay)', screen: 'FinalPay' },
    { id: 'pay-mine', icon: '🧾', title: 'My payslips', screen: 'MyPayslips' },
  ] },
  { section: 'Records', items: [
    { id: 'pay-stat', icon: '🏦', title: 'FNPF & PAYE payments', screen: 'Statutory' },
  ] },
  { section: 'Checks', items: [
    { id: 'pay-yearend', icon: '📅', title: 'Year end', note: 'Totals per person, certificates.', screen: 'PayYearEnd' },
  ] },
  { section: 'Reports', items: [
    { id: 'pay-reports', icon: '📊', title: 'Payroll reports', screen: 'ReportsHub', params: { group: 'Payroll' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'pay-profiles', icon: '🪪', title: 'Pay details', note: 'Rates, salaries, FNPF and TIN numbers.', screen: 'PayProfiles' },
    { id: 'pay-rules', icon: '⚙️', title: 'Rules, tax, FNPF, holidays', screen: 'PayRules' },
  ] },
];
