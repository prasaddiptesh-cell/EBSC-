// v3.6 pay run in steps: 1 confirm the pay period and pay date, 2 choose who is paid, 3 check each person (timesheet
// fixed from inside the pay run), 4 make final. People left out show as "not paid yet for this period" and can be paid
// later in their own run for the same period – never twice.
import { db } from '../../db/connection.js';
import { AppError, dateStr, addDays, stamp, deviceId, audit, uuid } from '../../services/core.js';
import { needReason } from '../../services/access.js';
import { payCycle, payPeriod } from './cycle.js';
import { listProfiles, getProfile, computeLine, payRules, createRun, getRun, editLine, recalcRun } from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const hoursOf = (h) => r2((h.normal || 0) + (h.ot || 0) + (h.sunday || 0) + (h.holiday || 0));

// Who is already paid (included in a draft or final run) for any part of this period.
function paidIn(from, to, exceptRun = null) {
  const rows = db().all(`SELECT l.user_uid, r.uid AS run_uid, r.status, r.pay_date FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid
    WHERE r.status IN ('draft','final') AND l.include = 1 AND IFNULL(r.run_kind,'regular') IN ('regular','catchup') AND NOT (r.week_end < ? OR r.week_start > ?) AND r.uid <> ?`, [from, to, exceptRun || '']);
  const out = {};
  rows.forEach((x) => { out[x.user_uid] = x; });
  return out;
}

// Step 1 + 2: the period for a date, the pay day, warnings, and everyone who could be paid with their hours.
export function planRun(anyDateInPeriod, { payDate } = {}) {
  const c = payCycle();
  const per = payPeriod(anyDateInPeriod || addDays(dateStr(), -1), c);
  const pd = payDate && DATE.test(payDate) ? payDate : per.payDate;
  const warnings = [];
  const existing = db().get("SELECT uid, status, pay_date FROM pay_runs WHERE status <> 'void' AND IFNULL(run_kind,'regular') = 'regular' AND NOT (week_end < ? OR week_start > ?)", [per.from, per.to]);
  if (existing) warnings.push({ tone: 'bad', text: `There is already a pay run for this period (${existing.status}, paid ${existing.pay_date}). Open it instead, or pay people left out with "Pay people left out".` });
  if (pd < per.to) warnings.push({ tone: 'warn', text: `The pay day (${pd}) is before the end of the period (${per.to}).` });
  if (pd > addDays(per.to, 14)) warnings.push({ tone: 'warn', text: `The pay day (${pd}) is more than two weeks after the period ends.` });
  if (per.to > dateStr()) warnings.push({ tone: 'warn', text: 'This period has not finished yet – hours after today are not in.' });
  const paid = paidIn(per.from, per.to);
  const rules = payRules();
  const people = listProfiles().filter((p) => p.hasProfile && p.active !== 0)
    .filter((p) => !(p.start_date && p.start_date > per.to) && !(p.end_date && p.end_date < per.from))
    .map((p) => {
      let hours = 0;
      try {
        const u = db().get('SELECT * FROM users WHERE uid = ?', [p.user_uid]);
        hours = hoursOf(computeLine(u, getProfile(p.user_uid), per.from, rules, { periodTo: per.to, frequency: per.frequency, payDate: pd }).hours || {});
      } catch (e) { hours = 0; }
      return { userUid: p.user_uid, name: p.name, shop: p.shop_code || '', employeeNo: p.employee_no || '', payType: p.pay_type, hours, alreadyPaid: !!paid[p.user_uid] };
    });
  return { from: per.from, to: per.to, payDate: pd, frequency: per.frequency, existing: existing || null, warnings, people };
}

// Start the pay run with only the people chosen. Pay day can be changed from the usual one.
export function startRunWithPeople(user, { date, payDate, people }) {
  const plan = planRun(date, { payDate });
  need(!plan.existing, plan.warnings[0] ? plan.warnings[0].text : 'There is already a pay run for this period.');
  const chosen = new Set((people || []).filter(Boolean));
  need(chosen.size, 'Tick at least one person to pay.');
  const run = createRun(user, plan.from);
  if (run.pay_date !== plan.payDate) {
    db().run("UPDATE pay_runs SET pay_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [plan.payDate, stamp(), deviceId(), run.uid]);
  }
  for (const l of getRun(run.uid).lines) {
    if (!chosen.has(l.user_uid)) editLine(user, l.uid, { include: false, reason: 'Not in this pay run (chosen when starting it)' });
  }
  audit({ user, action: `Pay run ${plan.from} – ${plan.to} paid ${plan.payDate}: ${chosen.size} of ${plan.people.length} people`, table: 'pay_runs', recordUid: run.uid });
  return getRun(run.uid);
}

// People with hours in a run's period who are not paid in this or any other run for it.
export function notPaidYet(runUid) {
  const r = getRun(runUid);
  if (!r) return [];
  const paid = paidIn(r.week_start, r.week_end);
  return r.lines.filter((l) => !l.include && !paid[l.user_uid]).map((l) => ({ userUid: l.user_uid, name: l.name, lineUid: l.uid, hours: hoursOf(l.hours || {}), net: l.net }));
}

// Draft run: put people back in. Final run: pay them in their own run for the same period ("Paid later").
export function payLeftOut(user, runUid, userUids) {
  const r = getRun(runUid);
  need(r, 'Pay run not found.');
  const want = new Set(userUids || []);
  need(want.size, 'Choose who to pay.');
  const open = notPaidYet(runUid).filter((x) => want.has(x.userUid));
  need(open.length, 'They are already paid for this period.');
  if (r.status === 'draft') {
    open.forEach((x) => editLine(user, x.lineUid, { include: true, reason: 'Added to this pay run' }));
    return getRun(runUid);
  }
  // A "Paid later" run for the same period with only these people, worked out from their timesheets.
  const uid = uuid(`PL-${r.week_start}-`);
  const now = stamp();
  db().transaction(() => {
    db().run(`INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, totals, created_by_name, created_at, run_kind, label, frequency, version, updated_at, updated_device)
      VALUES (?,?,?,?,'draft','{}',?,?,'catchup',?,?,1,?,?)`, [uid, r.week_start, r.week_end, dateStr() > r.pay_date ? dateStr() : r.pay_date, user.name, now, `Paid later (${r.week_start})`, r.frequency || 'weekly', now, deviceId()]);
    for (const x of open) {
      db().run(`INSERT INTO pay_lines (uid, run_uid, user_uid, name, pay_type, rate, hours, earnings, allowances, adjustments, overrides, gross, taxable, fnpf_base, fnpf_employee, fnpf_employer, paye,
        deductions, total_deductions, net, pay_method, warnings, include, updated_at, updated_device) VALUES (?,?,?,?, 'hourly', 0, '{}','{}','[]','[]','{}',0,0,0,0,0,0,'[]',0,0,'cash','[]',1,?,?)`,
        [`${uid}|${x.userUid}`, uid, x.userUid, x.name, now, deviceId()]);
    }
  });
  recalcRun(user, uid);
  audit({ user, action: `Paid later for ${r.week_start} – ${r.week_end}: ${open.map((x) => x.name).join(', ')}`, table: 'pay_runs', recordUid: uid });
  return getRun(uid);
}

// Change the pay day of a draft run.
export function setPayDate(user, runUid, payDate, reason) {
  const r = getRun(runUid);
  need(r && r.status === 'draft', 'Only a draft pay run can have its pay day changed.');
  need(DATE.test(payDate || ''), 'Choose the pay day.');
  needReason(user, reason, 'Why change the pay day?');
  db().run("UPDATE pay_runs SET pay_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [payDate, stamp(), deviceId(), runUid]);
  audit({ user, action: `Pay day for ${r.week_start} changed ${r.pay_date} → ${payDate}`, table: 'pay_runs', recordUid: runUid, reason });
  return getRun(runUid);
}

// The pay runs counted in a month (by pay day) – shown on the FNPF & PAYE month.
export function monthRuns(ym) {
  return db().all(`SELECT r.uid, r.week_start, r.week_end, r.pay_date, r.run_kind, r.label, r.version, SUM(l.fnpf_employee) AS fe, SUM(l.fnpf_employer) AS fr, SUM(l.paye) AS paye, COUNT(*) AS people
    FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid AND l.include = 1 WHERE r.status = 'final' AND substr(r.pay_date,1,7) = ? GROUP BY r.uid ORDER BY r.pay_date, r.week_start`, [ym])
    .map((x) => ({ ...x, fnpf: r2((x.fe || 0) + (x.fr || 0)), paye: r2(x.paye || 0) }));
}
