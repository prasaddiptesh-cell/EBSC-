// The payslip as structured data: sections and lines with stable keys. The on-screen payslip for signing, the PDF,
// the email copy and the Viber text are all made from this, so they always show the same full, exact figures.
// The document designer (another package) can show / hide / rename each part by its key:
//   payslipSections(lineOrUid) → [{ key, title, lines: [{ key, label, detail?, amount?, value?, tone?, kind? }] }]
// Section keys: header, hours, earnings, gross, deductions, net, counted, employer, ytd, signoff, correction.
// Line keys inside a section are stable too (e.g. 'gross', 'paye', 'fnpf', 'net', 'ded_<debt id>', 'extra_<n>').
import { db } from '../../db/connection.js';
import { stamp } from '../../services/core.js';
import * as P from './service.js';

const { $ } = P;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const PAYSLIP_SECTION_KEYS = ['header', 'correction', 'hours', 'earnings', 'gross', 'deductions', 'net', 'counted', 'employer', 'ytd', 'signoff'];
export const PAYSLIP_SECTION_TITLES = { header: 'Payslip', correction: 'Corrected payslip', hours: 'Hours', earnings: 'Pay', gross: 'Gross pay', deductions: 'Taken off', net: 'Net pay',
  counted: 'Pay counted for FNPF / PAYE', employer: 'Paid by Easy Buys on top', ytd: 'Year to date', signoff: 'Signed for' };

function lineOf(lineOrUid) {
  if (lineOrUid && typeof lineOrUid === 'object') return lineOrUid.hours && typeof lineOrUid.hours === 'object' ? lineOrUid : P.decodeLine(lineOrUid);
  const l = db().get('SELECT * FROM pay_lines WHERE uid = ?', [String(lineOrUid || '')]);
  return l ? P.decodeLine(l) : null;
}
const sec = (key, lines, title) => ({ key, title: title || PAYSLIP_SECTION_TITLES[key], lines });

export function payslipSections(lineOrUid, { withSignoff = true } = {}) {
  const l = lineOf(lineOrUid);
  if (!l) return [];
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [l.run_uid]) || {};
  const rules = P.payRules();
  const p = P.getProfile(l.user_uid) || {};
  const extraRun = (run.run_kind || 'regular') === 'extra';
  const out = [];
  out.push(sec('header', [
    { key: 'employer', label: 'Employer', value: 'Easy Buys Shopping Centre' },
    { key: 'name', label: 'Name', value: l.name },
    { key: 'employee_no', label: 'Employee no', value: l.employee_no || '—' },
    { key: 'job', label: 'Job', value: p.job_title || '—' },
    { key: 'shop', label: 'Shop', value: l.shop_code || '—' },
    { key: 'pay_run', label: extraRun ? 'Extra pay' : 'Pay period', value: extraRun ? `${run.label || 'Extra pay'} (${run.week_start}${run.week_end !== run.week_start ? ` to ${run.week_end}` : ''})` : `${run.week_start} to ${run.week_end}` },
    { key: 'pay_date', label: 'Pay day', value: run.pay_date || '—' },
    { key: 'tin', label: 'TIN', value: p.tin || '—' },
    { key: 'fnpf_no', label: 'FNPF no', value: p.fnpf_no || '—' },
    { key: 'pay_method', label: 'Paid by', value: l.pay_method === 'bank' ? `Bank${p.bank_name ? ` – ${p.bank_name}` : ''}${p.bank_account ? ` ${p.bank_account}` : ''}` : 'Cash' },
    { key: 'rate', label: 'Rate', value: l.pay_type === 'salary' ? 'Salary' : `${$(l.rate)} an hour` },
  ]));
  if ((run.version || 1) > 1) out.push(sec('correction', [{ key: 'version', label: 'Corrected payslip', value: `Version ${run.version} – replaces the earlier payslip${run.reopen_reason ? ` (${run.reopen_reason})` : ''}`, tone: 'warn' }]));
  const h = l.hours || {};
  if (!extraRun) {
    out.push(sec('hours', [['normal', 'Normal hours'], ['ot', 'Overtime hours'], ['sunday', 'Sunday hours'], ['holiday', 'Public holiday hours'], ['leave', 'Paid leave hours']]
      .filter(([k]) => h[k]).map(([k, label]) => ({ key: k, label, value: `${h[k]} h` }))));
  }
  const E = l.earnings || {};
  const earn = [];
  if (E.salary !== undefined) earn.push({ key: 'salary', label: 'Salary', amount: E.salary, kind: 'salary' });
  if (E.normal) earn.push({ key: 'normal', label: 'Normal hours', detail: `${h.normal} h × ${$(l.rate)}`, amount: E.normal, kind: 'normal' });
  if (E.ot) earn.push({ key: 'ot', label: 'Overtime', detail: `${h.ot} h × ${$(l.rate)} × ${rules.otMultiplier}`, amount: E.ot, kind: 'ot' });
  if (E.sunday) earn.push({ key: 'sunday', label: 'Sunday', detail: `${h.sunday} h × ${rules.sundayMultiplier}`, amount: E.sunday, kind: 'sunday' });
  if (E.holiday) earn.push({ key: 'holiday', label: 'Public holiday', detail: `${h.holiday} h × ${rules.holidayMultiplier}`, amount: E.holiday, kind: 'holiday' });
  if (E.leave) earn.push({ key: 'leave', label: 'Paid leave', detail: `${h.leave} h`, amount: E.leave, kind: 'leave' });
  (l.allowances || []).forEach((a, i) => earn.push({ key: `allowance_${i}`, label: a.name, detail: `allowance${a.taxable === false ? ', not taxed' : ''}${a.fnpf === false ? ', no FNPF' : ''}`, amount: a.amount, kind: P.kindOfExtra(a) }));
  (l.adjustments || []).forEach((a, i) => earn.push({ key: `extra_${i}`, label: a.label, detail: `${P.PAY_KINDS[a.kind] || 'extra'}${a.taxable === false ? ', not taxed' : ''}${a.fnpf === false ? ', no FNPF' : ''}`, amount: a.amount, kind: a.kind || P.kindOfExtra(a) }));
  out.push(sec('earnings', earn));
  out.push(sec('gross', [{ key: 'gross', label: 'GROSS PAY', amount: l.gross, bold: true }]));
  const ded = [
    { key: 'paye', label: 'PAYE tax', amount: -l.paye },
    { key: 'fnpf', label: 'FNPF', detail: `${rules.fnpfEmployeePct}%${p.fnpf_extra_pct ? ` + ${p.fnpf_extra_pct}% extra` : ''}`, amount: -l.fnpf_employee },
  ];
  (l.deductions || []).forEach((d, i) => ded.push({ key: d.debtUid ? `ded_${d.debtUid}` : `ded_${i}`, label: d.label, detail: d.detail || (d.manual ? 'this pay' : d.kind === 'regular' ? 'every pay' : ''), amount: -d.amount,
    kind: d.kind || (d.manual ? 'manual' : 'other'), tone: d.highlight ? 'highlight' : undefined }));
  out.push(sec('deductions', ded));
  out.push(sec('net', [{ key: 'net', label: 'NET PAY', detail: l.pay_method === 'bank' ? 'into your bank' : 'cash', amount: l.net, bold: true, tone: 'good' }]));
  const c = l.counted || { fnpf: { base: l.fnpf_base, words: 'All pay' }, paye: { base: l.taxable, words: 'All pay' } };
  out.push(sec('counted', [
    { key: 'fnpf_counted', label: 'Pay counted for FNPF', detail: c.fnpf.words, amount: c.fnpf.base },
    { key: 'paye_counted', label: 'Pay counted for PAYE', detail: c.paye.words, amount: c.paye.base },
  ]));
  out.push(sec('employer', [{ key: 'fnpf_employer', label: 'FNPF paid by Easy Buys', detail: `${rules.fnpfEmployerPct}%`, amount: l.fnpf_employer }]));
  const ytd = P.yearToDate(l.user_uid, String(run.pay_date || '').slice(0, 4), run.pay_date);
  out.push(sec('ytd', [
    { key: 'ytd_gross', label: 'Gross this year', amount: ytd.gross }, { key: 'ytd_paye', label: 'PAYE this year', amount: ytd.paye },
    { key: 'ytd_fnpf', label: 'FNPF this year', amount: ytd.fnpfEmployee }, { key: 'ytd_net', label: 'Net this year', amount: ytd.net },
  ]));
  if (withSignoff && has('pay_signoffs')) {
    const so = db().get('SELECT * FROM pay_signoffs WHERE run_uid = ? AND user_uid = ?', [l.run_uid, l.user_uid]);
    const st = has('pay_slip_status') ? db().get('SELECT * FROM pay_slip_status WHERE run_uid = ? AND user_uid = ?', [l.run_uid, l.user_uid]) : null;
    const lines = [];
    if (so && so.status === 'signed') lines.push({ key: 'signed', label: 'Signed by', value: `${l.name} ${String(so.signed_at || '').slice(0, 16)}` });
    else if (so && so.status === 'query') lines.push({ key: 'query', label: 'Something is wrong', value: so.note || '', tone: 'warn' });
    else lines.push({ key: 'not_signed', label: 'Not signed yet', value: '' });
    if (st && st.released) lines.push({ key: 'released', label: 'Released', value: st.override_reason !== null && st.override_reason !== undefined && !(so && so.status === 'signed') ? `by ${st.released_by_name} without signature${st.override_reason ? ` – ${st.override_reason}` : ''}` : String(st.released_at || '').slice(0, 16) });
    out.push(sec('signoff', lines));
  }
  return out.filter((s) => s.lines.length);
}

// Amount text as shown on the payslip ("− $12.00" for money taken off).
export function amountText(a) {
  if (a === undefined || a === null) return '';
  return a < 0 ? `− ${$(-a)}` : $(a);
}

// One payslip as a report (PDF / Excel / print / email) built from the sections.
export function payslipReport(lineOrUid) {
  const l = lineOf(lineOrUid);
  if (!l) return { kind: 'payslip', title: 'Payslip', fileName: 'Payslip', subtitle: 'Not found', info: [], sections: [] };
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [l.run_uid]) || {};
  const s = payslipSections(l);
  const col = (key, title, align = 'left') => ({ key, title, align });
  const head = s.find((x) => x.key === 'header');
  return {
    kind: 'payslip', title: 'Payslip', fileName: `Payslip-${String(l.name).replace(/\W+/g, '-')}-${run.pay_date || ''}`,
    subtitle: `Easy Buys Shopping Centre · ${l.name} · paid ${run.pay_date || ''}`,
    info: head ? head.lines.map((x) => [x.label, x.value]) : [], generated: stamp(),
    summary: [{ label: 'Gross', value: $(l.gross) }, { label: 'Taken off', value: $(l.total_deductions) }, { label: 'Net pay', value: $(l.net), tone: 'good' }],
    sections: s.filter((x) => x.key !== 'header').map((x) => ({ key: x.key, title: x.title, columns: [col('item', 'Item'), col('detail', 'Detail'), col('amount', 'Amount', 'right')],
      rows: x.lines.map((y) => ({ key: y.key, item: y.label, detail: y.detail || y.value || '', amount: amountText(y.amount), _tone: y.tone === 'highlight' || y.tone === 'warn' ? 'warn' : null })) })),
  };
}

// Short text for a Viber message (the full payslip PDF goes by email / print).
export function payslipText(lineOrUid) {
  const l = lineOf(lineOrUid);
  if (!l) return '';
  const out = [];
  for (const s of payslipSections(l, { withSignoff: false })) {
    if (s.key === 'header') { out.push(`Easy Buys payslip – ${l.name}`); s.lines.filter((x) => ['pay_run', 'pay_date', 'pay_method'].includes(x.key)).forEach((x) => out.push(`${x.label}: ${x.value}`)); continue; }
    if (s.key === 'hours') continue;
    out.push('');
    out.push(s.title.toUpperCase());
    s.lines.forEach((x) => out.push(`${x.label}${x.detail ? ` (${x.detail})` : ''}: ${x.amount !== undefined ? amountText(x.amount) : x.value}`));
  }
  return out.join('\n');
}
