// Payroll reports: pay run summary, payslips, FNPF and PAYE for the month, bank / cash pay list, year to date, advances.
import { db } from '../../db/connection.js';
import { stamp, weekStart, addDays } from '../../services/core.js';
import * as P from './service.js';
import { payslipReport } from './payslip.js';

const { $, r2 } = P;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const J = (v, d) => { try { return JSON.parse(v || '') || d; } catch (e) { return d; } };
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});
// The regular pay run whose period has this date (any pay cycle); before v3.5 runs always started on the week start.
const runFor = (date) => db().get("SELECT uid FROM pay_runs WHERE status <> 'void' AND IFNULL(run_kind,'regular') = 'regular' AND ? BETWEEN week_start AND week_end ORDER BY week_start DESC LIMIT 1", [date])
  || db().get("SELECT uid FROM pay_runs WHERE week_start = ? AND status <> 'void'", [weekStart(date)]);
const finalLines = (from, to) => db().all(`SELECT l.*, r.pay_date, r.week_start FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final'
  WHERE l.include = 1 AND r.pay_date BETWEEN ? AND ? ORDER BY l.name, r.pay_date`, [from, to]);
const profile = (uid) => P.getProfile(uid) || {};

export const REPORTS = [
  { id: 'pay_summary', group: 'Payroll', icon: '💰', title: 'Pay run summary', desc: 'Everyone in the week: hours, gross, tax, FNPF, net', perm: 'payroll_view', week: true,
    build(from) {
      const rr = runFor(from);
      const run = rr ? P.getRun(rr.uid) : null;
      const ws = run ? run.week_start : weekStart(from);
      const we = run ? run.week_end : addDays(ws, 6);
      const lines = run ? run.lines.filter((l) => l.include) : [];
      const rows = lines.map((l) => ({ name: l.name, emp: l.employee_no || '', shop: l.shop_code || '', normal: l.hours.normal || '', ot: l.hours.ot || '', sun: l.hours.sunday || '', hol: l.hours.holiday || '', leave: l.hours.leave || '',
        gross: $(l.gross), paye: $(l.paye), fnpf: $(l.fnpf_employee), other: $(l.total_deductions - l.paye - l.fnpf_employee), net: $(l.net), how: l.pay_method, emp10: $(l.fnpf_employer), _tone: l.warnings.length ? 'warn' : null }));
      const t = run ? run.totals : {};
      return base('pay_summary', 'Pay Run Summary', ws, we, {
        info: [['Period', `${ws} to ${we}`], ['Pay day', run ? run.pay_date : '—'], ['Status', run ? run.status : 'no pay run'], ['Generated', stamp()]],
        summary: [{ label: 'Gross', value: $(t.gross || 0) }, { label: 'PAYE', value: $(t.paye || 0) }, { label: 'FNPF (employee + employer)', value: $((t.fnpfEmployee || 0) + (t.fnpfEmployer || 0)) }, { label: 'Net', value: $(t.net || 0) }],
        sections: [{ title: 'Staff', columns: [col('name', 'Name'), col('emp', 'Emp no'), col('shop', 'Shop'), col('normal', 'Normal h', R), col('ot', 'OT h', R), col('sun', 'Sun h', R), col('hol', 'Hol h', R), col('leave', 'Leave h', R),
          col('gross', 'Gross', R), col('paye', 'PAYE', R), col('fnpf', 'FNPF 8%', R), col('other', 'Other ded.', R), col('net', 'Net', R), col('how', 'Paid by'), col('emp10', 'FNPF employer', R)], rows,
        note: run && run.status === 'draft' ? 'DRAFT – not final yet.' : '' }],
      });
    } },
  { id: 'payslips', group: 'Payroll', icon: '🧾', title: 'Payslips', desc: 'One payslip per person for the week (print or email)', perm: 'payroll_view', week: true,
    build(from) {
      // Every payslip of the pay run, each made from the same sections as the payslip people sign (payslip.js).
      const rr = runFor(from);
      const run = rr ? P.getRun(rr.uid) : null;
      const ws = run ? run.week_start : weekStart(from);
      const we = run ? run.week_end : addDays(ws, 6);
      const sections = [];
      (run ? run.lines.filter((l) => l.include) : []).forEach((l) => {
        const one = payslipReport(l);
        sections.push({ title: `${l.name}${l.employee_no ? ` (${l.employee_no})` : ''} · ${one.info.filter(([k]) => ['TIN', 'FNPF no'].includes(k)).map(([k, v]) => `${k} ${v}`).join(' · ')}`,
          columns: [col('item', 'Item'), col('detail', 'Detail'), col('amount', 'Amount', R)], rows: one.sections.flatMap((x) => [{ item: x.title.toUpperCase(), detail: '', amount: '' }].concat(x.rows)) });
      });
      return base('payslips', 'Payslips', ws, we, { info: [['Period', `${ws} to ${we}`], ['Pay day', run ? run.pay_date : '—'], ['Generated', stamp()]], summary: [{ label: 'Payslips', value: String(sections.length) }], sections });
    } },
  { id: 'pay_fnpf', group: 'Payroll', icon: '🏛️', title: 'FNPF contributions', desc: 'Per member for pay days in the period (monthly schedule)', perm: 'payroll_view',
    build(from, to) {
      const per = {};
      finalLines(from, to).forEach((l) => {
        const p = profile(l.user_uid);
        const x = (per[l.user_uid] = per[l.user_uid] || { name: l.name, fnpf: p.fnpf_no || '', wages: 0, ee: 0, er: 0 });
        x.wages += l.fnpf_base; x.ee += l.fnpf_employee; x.er += l.fnpf_employer;
      });
      // Only people FNPF is paid for (owners / family without FNPF are left off, as on the FNPF schedule).
      const list = Object.values(per).filter((x) => x.ee + x.er > 0.004);
      const rows = list.map((x) => ({ name: x.name, fnpf: x.fnpf, wages: $(x.wages), ee: $(x.ee), er: $(x.er), total: $(x.ee + x.er), _tone: x.fnpf ? null : 'warn' }));
      return base('pay_fnpf', 'FNPF Contributions', from, to, {
        summary: [{ label: 'Wages', value: $(list.reduce((s, x) => s + x.wages, 0)) }, { label: 'Employee', value: $(list.reduce((s, x) => s + x.ee, 0)) }, { label: 'Employer', value: $(list.reduce((s, x) => s + x.er, 0)) }, { label: 'To pay FNPF', value: $(list.reduce((s, x) => s + x.ee + x.er, 0)) }],
        sections: [{ title: 'Members', columns: [col('name', 'Name'), col('fnpf', 'FNPF no'), col('wages', 'Wages', R), col('ee', 'Employee', R), col('er', 'Employer', R), col('total', 'Total', R)], rows }],
      });
    } },
  { id: 'pay_paye', group: 'Payroll', icon: '🧮', title: 'PAYE deducted', desc: 'Tax per employee for pay days in the period (for FRCS)', perm: 'payroll_view',
    build(from, to) {
      const per = {};
      finalLines(from, to).forEach((l) => {
        const p = profile(l.user_uid);
        const x = (per[l.user_uid] = per[l.user_uid] || { name: l.name, tin: p.tin || '', gross: 0, taxable: 0, paye: 0 });
        x.gross += l.gross; x.taxable += l.taxable; x.paye += l.paye;
      });
      const list = Object.values(per);
      return base('pay_paye', 'PAYE Deducted', from, to, {
        summary: [{ label: 'Gross', value: $(list.reduce((s, x) => s + x.gross, 0)) }, { label: 'PAYE to pay FRCS', value: $(list.reduce((s, x) => s + x.paye, 0)) }],
        sections: [{ title: 'Employees', columns: [col('name', 'Name'), col('tin', 'TIN'), col('gross', 'Gross', R), col('taxable', 'Taxable', R), col('paye', 'PAYE', R)],
          rows: list.map((x) => ({ name: x.name, tin: x.tin, gross: $(x.gross), taxable: $(x.taxable), paye: $(x.paye), _tone: x.tin ? null : 'warn' })) }],
      });
    } },
  { id: 'pay_list', group: 'Payroll', icon: '💵', title: 'Pay list (cash & bank)', desc: 'Who gets what: bank transfers and cash envelopes with notes and coins', perm: 'payroll_view', week: true,
    build(from) {
      const rr = runFor(from);
      const run = rr ? P.getRun(rr.uid) : null;
      const ws = run ? run.week_start : weekStart(from);
      const lines = run ? run.lines.filter((l) => l.include) : [];
      // (v3.9: defined before use – the Pay List crashed when a week had bank payments.) Not signed = not released (pay sign-off).
      const rel = (l) => { if (!run || run.status !== 'final') return 'not final'; try { const st = require('./signoff.js').slipState(run.uid, l.user_uid); return st.signed ? 'signed' : st.released ? 'released by owner/admin' : 'NOT SIGNED – hold'; } catch (e) { return ''; } };
      const bank = lines.filter((l) => l.pay_method === 'bank').map((l) => { const p = profile(l.user_uid); return { name: l.name, bank: p.bank_name || '', acct: p.bank_account || '', net: $(l.net), rel: rel(l) }; });
      const cash = lines.filter((l) => l.pay_method !== 'bank');
      const notes = P.cashBreakdown(cash.map((l) => l.net));
      return base('pay_list', 'Pay List', ws, run ? run.week_end : addDays(ws, 6), {
        summary: [{ label: 'Bank', value: $(lines.filter((l) => l.pay_method === 'bank').reduce((s, l) => s + l.net, 0)) }, { label: 'Cash', value: $(cash.reduce((s, l) => s + l.net, 0)) }],
        sections: [{ title: 'Bank transfers', columns: [col('name', 'Name'), col('bank', 'Bank'), col('acct', 'Account'), col('net', 'Amount', R), col('rel', 'Payslip')], rows: bank },
          { title: 'Cash envelopes (signed for)', columns: [col('name', 'Name'), col('net', 'Amount', R), col('notes', 'Notes & coins'), col('rel', 'Payslip'), col('sign', 'Signature')],
            rows: cash.map((l) => ({ name: l.name, net: $(l.net), notes: P.cashBreakdown([l.net]).map((n) => `${n.label}×${n.count}`).join(' '), rel: rel(l), sign: '' })) },
          { title: 'Cash to get from the bank', columns: [col('label', 'Note / coin'), col('count', 'How many', R), col('value', 'Value', R)], rows: notes.map((n) => ({ label: n.label, count: n.count, value: $(n.value * n.count) })) }],
      });
    } },
  { id: 'pay_ytd', group: 'Payroll', icon: '📅', title: 'Year to date', desc: 'Gross, PAYE, FNPF and net per person this year', perm: 'payroll_view',
    build(from, to) {
      const year = to.slice(0, 4);
      const people = db().all(`SELECT DISTINCT l.user_uid, l.name FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE substr(r.pay_date,1,4) = ? ORDER BY l.name`, [year]);
      const rows = people.map((p) => { const y = P.yearToDate(p.user_uid, year, to); return { name: p.name, weeks: y.weeks, gross: $(y.gross), paye: $(y.paye), fnpf: $(y.fnpfEmployee), er: $(y.fnpfEmployer), net: $(y.net) }; });
      return base('pay_ytd', `Payroll Year To Date ${year}`, `${year}-01-01`, to, {
        summary: [{ label: 'People', value: String(rows.length) }],
        sections: [{ title: 'Staff', columns: [col('name', 'Name'), col('weeks', 'Weeks', R), col('gross', 'Gross', R), col('paye', 'PAYE', R), col('fnpf', 'FNPF staff', R), col('er', 'FNPF employer', R), col('net', 'Net', R)], rows }],
      });
    } },
  { id: 'pay_debts', group: 'Payroll', icon: '🤝', title: 'Advances & staff loans', desc: 'Given, repaid and still owing', perm: 'payroll_view',
    build(from, to) {
      const list = P.listDebts({ open: false });
      return base('pay_debts', 'Advances And Staff Loans', from, to, {
        summary: [{ label: 'Still owing', value: $(list.reduce((s, d) => s + d.balance, 0)) }],
        sections: [{ title: 'Advances & loans', columns: [col('name', 'Name'), col('kind', 'Type'), col('date', 'Date'), col('reason', 'Reason'), col('amount', 'Amount', R), col('per', 'Weekly', R), col('repaid', 'Repaid', R), col('bal', 'Owing', R), col('by', 'Given by')],
          rows: list.map((d) => ({ name: d.name, kind: d.kind, date: d.debt_date, reason: d.reason || '', amount: $(d.amount), per: $(d.repay_per_pay), repaid: $(d.repaid), bal: $(d.balance), by: d.given_by_name || '', _tone: d.balance > 0 ? 'warn' : null })) }],
      });
    } },
];
