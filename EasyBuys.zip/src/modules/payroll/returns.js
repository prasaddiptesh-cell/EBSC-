// v3.9 Returns: the FRCS VAT return (form IRS217, lines 1–13) with its VAT Input Schedule, and the FNPF Contribution
// Schedule (FNPF's form, one row per member). Each month's return is worked out from the app's records, checked, then
// LODGED (a frozen copy is kept; a later change makes an amended version – nothing is ever deleted) and PAID. Lodging
// and paying go through the tax calendar's two proofs (taxCalendar.js) and paying books the money:
//   VAT  → Accounting tax payment (VAT account 2200 against the bank / cash) – it shows in the bank reconciliation.
//   FNPF → Payroll › FNPF payment (FNPF to pay 2100 against the bank) – it shows in the bank reconciliation.
// A VAT refund month needs no payment; the refund is recorded when FRCS pays it. Late penalties are estimated so the
// owner sees what a delay costs, and a penalty actually paid is booked to its own expense account (6250).
import { db, keepUntilChanged, keepTracked } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays, money } from '../../services/core.js';
import { actsAsOwner, can, needReason } from '../../services/access.js';
import * as TX from './taxCalendar.js';
import * as P from './service.js';
import { requirePerm, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const YM = /^\d{4}-\d{2}$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const pad = (n) => String(n).padStart(2, '0');
const ymAdd = (ym, n) => { const t = Number(ym.slice(0, 4)) * 12 + Number(ym.slice(5, 7)) - 1 + n; return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`; };
const monthEnd = (ym) => addDays(`${ymAdd(ym, 1)}-01`, -1);
const A = () => require('../accounting/service.js');
const F = () => require('../accounting/full.js');
const S = () => require('./statutory.js');
const FL = () => require('./filing.js');

export { RETURNS_SQL, RETURNS_SYNC } from './returnsSchema.js';
export const RETURN_KINDS = { vat: { title: 'VAT return', to: 'FRCS', form: 'FRCS VAT return (IRS217)' }, fnpf: { title: 'FNPF contribution schedule', to: 'FNPF', form: 'FNPF Contribution Schedule' } };

// ---------------------------------------------------------------- the file row (adjustments, payment links)
const fileUid = (kind, period) => `${kind}|${period}`;
export function fileRow(kind, period) {
  const r = has('tax_returns') ? db().get('SELECT * FROM tax_returns WHERE uid = ?', [fileUid(kind, period)]) : null;
  return r ? { ...r, adjust: J(r.adjust, {}) } : null;
}
function ensureFile(kind, period) {
  const cur = fileRow(kind, period);
  if (cur) return cur;
  db().run("INSERT INTO tax_returns (uid, kind, period, adjust, updated_at, updated_device) VALUES (?,?,?, '{}', ?,?)", [fileUid(kind, period), kind, period, stamp(), deviceId()]);
  return fileRow(kind, period);
}
function setFile(kind, period, fields) {
  ensureFile(kind, period);
  const keys = Object.keys(fields);
  db().run(`UPDATE tax_returns SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    keys.map((k) => (k === 'adjust' ? JSON.stringify(fields[k] || {}) : fields[k])).concat([stamp(), deviceId(), fileUid(kind, period)]));
}
function canFile(user, kind) {
  if (isTop(user)) return true;
  const rule = TX.taxRules()[kind] || {};
  return (rule.responsibleUid && user && rule.responsibleUid === user.uid) || (kind === 'vat' ? can(user, 'accounts_view') : can(user, 'statutory'));
}
export function canFileReturn(user, kind) { return canFile(user, kind); }

// ---------------------------------------------------------------- VAT (FRCS IRS217)
// Standard rate by period: 15% until July 2025, 12.5% from 1 August 2025 (the admin's VAT rate in Invoices › Rules
// after that, in case it changes again).
export function vatRateFor(ym) {
  if (ym < '2025-08') return ym < '2023-08' ? 9 : 15;
  let r = 12.5;
  try { r = Number(require('../payables/service.js').apRules().vatRate) || 12.5; } catch (e) { r = 12.5; }
  return r;
}
export const VAT_LINES = [
  [1, 'Total taxable supplies (sales incl. VAT, standard and zero-rated)'],
  [2, 'Zero-rated supplies'],
  [3, 'Total supplies subject to VAT (line 1 − line 2)'],
  [4, 'VAT collected (line 3 × tax fraction)'],
  [5, 'VAT on output adjustments (credit notes received, private use, other corrections)'],
  [6, 'Total VAT charged on taxable supplies (line 4 + line 5)'],
  [7, 'VAT paid on local purchases and expenses (VAT Input Schedule)'],
  [8, 'Customs VAT (imports – IM4 entries paid)'],
  [9, 'VAT on input adjustments (debit notes received, bad debts, other corrections)'],
  [10, 'Total VAT on purchases (line 7 + line 8 + line 9)'],
  [11, 'VAT on purchases not wholly used for taxable supplies'],
  [12, 'Total input tax (line 10 − line 11)'],
  [13, 'Amount to pay (refund due if negative) (line 6 − line 12)'],
];
// Typed-in figures for lines 5, 8, 9 and 11 (anything the app cannot see), each with a note.
export const VAT_ADJUST_LINES = { l5: 5, l8: 8, l9: 9, l11: 11 };
export function vatReturnFRCS(ym, { adjust } = {}) {
  need(YM.test(ym), 'Choose the month.');
  const v = A().vatReturn({ ym });
  const rate = vatRateFor(ym);
  const adj = adjust || ((fileRow('vat', ym) || {}).adjust || {});
  const a = (k) => r2((adj[k] && adj[k].amount) || 0);
  // Purchases: tax invoices with the supplier's TIN go on the Input Schedule (line 7). Credit notes received reduce the
  // VAT we paid, so FRCS has them as an output adjustment (line 5). VAT without a TIN cannot be claimed.
  const schedule = [];
  const noTin = [];
  const credits = []; // build 42: the credit notes behind line 5
  let creditVat = 0;
  for (const r of v.purchaseRows) {
    if (!r.vat) continue;
    if (r.kind === 'credit') { creditVat += Math.abs(r.vat); credits.push(r); continue; }
    if (!txt(r.tin)) { noTin.push(r); continue; }
    schedule.push({ tin: r.tin, supplier: r.supplier, no: r.no, date: r.date, total: r.total, vat: r.vat, shop: r.shop, status: r.status, go: r.go });
  }
  schedule.sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : String(x.supplier) < String(y.supplier) ? -1 : 1));
  const L = {};
  L[1] = r2(v.sales.total);
  L[2] = r2(v.sales.zeroRated);
  L[3] = r2(L[1] - L[2]);
  L[4] = r2((L[3] * rate) / (100 + rate));
  L[5] = r2(creditVat + a('l5'));
  L[6] = r2(L[4] + L[5]);
  L[7] = r2(schedule.reduce((s, x) => s + x.vat, 0));
  L[8] = a('l8');
  L[9] = a('l9');
  L[10] = r2(L[7] + L[8] + L[9]);
  L[11] = a('l11');
  L[12] = r2(L[10] - L[11]);
  L[13] = r2(L[6] - L[12]);
  const checks = [];
  if (v.purchases.toCheck) checks.push({ level: 'bad', text: `${v.purchases.toCheck} supplier invoice(s) in ${ym} are not checked yet – check them first.` });
  if (noTin.length) checks.push({ level: 'warn', text: `${noTin.length} invoice(s) with VAT ${$(noTin.reduce((s, x) => s + x.vat, 0))} have no supplier TIN – that VAT is left out (add the TIN to claim it).` });
  if (v.aronium && v.aronium.unresolved) checks.push({ level: 'bad', text: `${v.aronium.unresolved} Aronium End of day(s) differ from the till and are not explained.` });
  if (v.aronium && v.aronium.missingTill) checks.push({ level: 'warn', text: `${v.aronium.missingTill} Aronium End of day(s) have no till balance.` });
  const missingDays = salesDaysMissing(ym);
  if (missingDays.length) checks.push({ level: 'warn', text: `No sales recorded for ${missingDays.length} shop-day(s) (${missingDays.slice(0, 4).join(', ')}${missingDays.length > 4 ? ' …' : ''}). Every trading day should have its End of day.` });
  const diff = r2(v.sales.output - L[4]);
  if (Math.abs(diff) > 1) checks.push({ level: 'warn', text: `Aronium's VAT on the End of days (${$(v.sales.output)}) differs from line 4 (${$(L[4])}) by ${$(diff)} – check the zero-rated sales.` });
  // build 43 (owner: "the VAT return needs to be done very very properly"): the figures themselves checked
  try {
    const AP = require('../payables/service.js');
    const monthInv = db().all("SELECT uid FROM ap_invoices WHERE status <> 'void' AND substr(invoice_date,1,7) = ?", [ym]).map((x) => AP.getInvoice(x.uid)).filter(Boolean);
    const wrong = monthInv.filter((i) => { const st = AP.vatStatusOf(i); return st && /does not fit|more than/.test(st.text); });
    if (wrong.length) checks.push({ level: 'bad', text: `${wrong.length} invoice(s) have VAT that does not fit their total (${wrong.slice(0, 3).map((i) => `${i.supplier_name} ${i.invoice_no || ''}`.trim()).join(', ')}${wrong.length > 3 ? ' …' : ''}) – Invoices › VAT to check.`, items: wrong.map((i) => i.uid) });
    const zeroVat = monthInv.filter((i) => { const st = AP.vatStatusOf(i); return st && /VAT is \$0/.test(st.text); });
    if (zeroVat.length) checks.push({ level: 'warn', text: `${zeroVat.length} invoice(s) from VAT-registered suppliers show $0 VAT – is VAT on them? (Invoices › VAT to check)` });
    const dd = AP.doubleEntries();
    const dupIn = dd.invoices.filter((x) => String(x.again.invoice_date).slice(0, 7) === ym || String(x.first.invoice_date).slice(0, 7) === ym);
    if (dupIn.length) checks.push({ level: 'bad', text: `${dupIn.length} invoice(s) are entered twice (${dupIn.slice(0, 3).map((x) => `${x.again.supplier_name} ${x.again.invoice_no}`).join(', ')}) – their VAT would be claimed twice. Void the extra one.` });
  } catch (e) { /* the return still works */ }
  if (!L[1] && !schedule.length) checks.push({ level: 'warn', text: 'Nothing to declare: FRCS still needs a nil return (with a short letter saying why).' });
  for (const [k, n] of Object.entries(VAT_ADJUST_LINES)) if (a(k) && !txt(adj[k] && adj[k].note)) checks.push({ level: 'bad', text: `Line ${n}: write what the typed-in amount is for.` });
  // build 44 (owner: "done automatically but each entry will need to be checked"): every day's sales and every invoice ticked
  let ticks = null;
  try { ticks = require('../accounting/monthRecords.js').vatChecks(ym); } catch (e) { ticks = null; }
  if (ticks && ticks.left) checks.push({ level: 'bad', text: `${ticks.left} of ${ticks.total} entries are not checked yet (${ticks.days - ticks.daysDone} day(s) of sales, ${ticks.invoices - ticks.invoicesDone} invoice(s)) – Month records: tick each one.`, go: ['MonthRecords', { ym, shop: ticks.firstLeft ? ticks.firstLeft.shop : undefined }] });
  if (!checks.length) checks.push({ level: 'ok', text: 'Every check passed.' });
  return {
    ticks,
    kind: 'vat', period: ym, rate, fraction: `${rate}/${100 + rate}`, lines: L, adjust: adj, schedule, noTin, credits, creditVat: r2(creditVat), checks, missingDays, toCheck: v.purchaseRows.filter((r) => r.status === 'to_check'),
    amount: L[13], payable: L[13] >= 0, due: lastDayNext(ym), sales: v.sales, saleRows: v.saleRows,
    blocking: checks.filter((c) => c.level === 'bad'),
  };
}
const lastDayNext = (ym) => monthEnd(ymAdd(ym, 1));
// Shop-days in the month with no End of day / till balance / typed sale (days before today only).
function salesDaysMissing(ym) {
  // 1.0.0 kept until the shops, End of days or till counts change (and worked out again the next day)
  return keepUntilChanged(`ret|missing|${ym}|${dateStr()}`, ['shops', 'aronium_eods', 'till_counts'], () => workOutSalesDaysMissing(ym));
}
function workOutSalesDaysMissing(ym) {
  try {
    const shops = db().all('SELECT code FROM shops WHERE active = 1 ORDER BY sort, code').map((r) => r.code);
    const have = new Set();
    if (has('aronium_eods')) db().all("SELECT shop_code, eod_date FROM aronium_eods WHERE state <> 'void' AND substr(eod_date,1,7) = ?", [ym]).forEach((r) => have.add(`${r.shop_code}|${r.eod_date}`));
    if (has('till_counts')) db().all("SELECT shop_code, shift_date FROM till_counts WHERE status <> 'void' AND substr(shift_date,1,7) = ?", [ym]).forEach((r) => have.add(`${r.shop_code}|${r.shift_date}`));
    if (!have.size) return [];
    // Only shops that traded at all in the month are checked.
    const traded = new Set(Array.from(have).map((k) => k.split('|')[0]));
    const out = [];
    const today = dateStr();
    for (let d = `${ym}-01`; d <= monthEnd(ym) && d < today; d = addDays(d, 1)) for (const s of shops) if (traded.has(s) && !have.has(`${s}|${d}`)) out.push(`${s} ${d.slice(5)}`);
    return out;
  } catch (e) { return []; }
}
export function saveVatAdjust(user, ym, lines) {
  need(canFile(user, 'vat'), 'You cannot change the VAT return.');
  need(YM.test(ym), 'Choose the month.');
  const cur = fileRow('vat', ym);
  const before = cur ? cur.adjust : {};
  const clean = {};
  for (const k of Object.keys(VAT_ADJUST_LINES)) {
    const x = (lines || {})[k] || {};
    const amount = r2(x.amount);
    need(Number.isFinite(amount), `Line ${VAT_ADJUST_LINES[k]}: enter a number.`);
    if (k !== 'l9' && k !== 'l5') need(amount >= 0, `Line ${VAT_ADJUST_LINES[k]} cannot be below zero.`);
    if (amount) { need(txt(x.note), `Line ${VAT_ADJUST_LINES[k]}: write what it is for.`); clean[k] = { amount, note: txt(x.note) }; }
  }
  setFile('vat', ym, { adjust: clean });
  audit({ user, action: `VAT return ${ym}: typed-in lines changed`, table: 'tax_returns', recordUid: fileUid('vat', ym), before, after: clean });
  return vatReturnFRCS(ym);
}

// ---------------------------------------------------------------- FNPF Contribution Schedule
// FNPF's mandatory employer rate on a date (the law, not what Easy Buys chooses to pay): anything paid above it is
// "employer additional". The same changes as the pay rules unless the admin changed those.
export const FNPF_MANDATORY = { employee: 8, employer: [{ from: '0000-01-01', pct: 10 }, { from: '2026-08-01', pct: 8 }] };
export function fnpfMandatoryEmployerPct(date) {
  let pct = 10;
  for (const c of FNPF_MANDATORY.employer) if (c.from <= date) pct = c.pct;
  return pct;
}
const STATUS_TEXT = { 1: 'Active', 2: 'On leave', 3: 'Terminated' };
const FREQ = { weekly: 1, fortnightly: 2, monthly: 3 };
export const FNPF_COLUMNS = ['Line No.', 'Member Number', "Member's First Name", "Member's Middle Name", "Member's Last Name", "Member's Tax ID No.", 'Compulsory Contribution Amount',
  'Employer Additional Contribution Amount', 'Member Additional Contribution Amount', 'Total Contribution Amount', 'Monthly Gross Salary', 'Employment Status', 'Employment Status Date', 'Payment Frequency'];
export function fnpfSchedule(ym) {
  need(YM.test(ym), 'Choose the month.');
  const emp = FL().employerDetails();
  const lines = has('pay_runs') ? db().all(`SELECT l.*, r.pay_date, r.frequency FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND substr(r.pay_date,1,7) = ? ORDER BY l.name`, [ym]) : [];
  const per = {};
  for (const l of lines) {
    const x = (per[l.user_uid] = per[l.user_uid] || { userUid: l.user_uid, name: l.name, gross: 0, base: 0, employee: 0, employer: 0, compEmployee: 0, compEmployer: 0, pays: 0, freq: l.frequency || 'weekly', lastPay: l.pay_date });
    const base = Number(l.fnpf_base) || 0;
    x.gross += Number(l.gross) || 0; x.base += base; x.employee += Number(l.fnpf_employee) || 0; x.employer += Number(l.fnpf_employer) || 0; x.pays += 1;
    x.compEmployee += Math.min(Number(l.fnpf_employee) || 0, r2((base * FNPF_MANDATORY.employee) / 100));
    x.compEmployer += Math.min(Number(l.fnpf_employer) || 0, r2((base * fnpfMandatoryEmployerPct(l.pay_date)) / 100));
    if (l.pay_date > x.lastPay) x.lastPay = l.pay_date;
  }
  const checks = [];
  const rows = Object.values(per).filter((x) => x.employee + x.employer > 0).map((x) => {
    const p = P.getProfile(x.userUid) || {};
    const parts = String(x.name).trim().split(/\s+/);
    const first = parts[0] || '';
    const last = parts.length > 1 ? parts[parts.length - 1] : '';
    const middle = parts.length > 2 ? parts.slice(1, -1).join(' ') : '';
    const ended = p.end_date && p.end_date <= monthEnd(ym);
    const status = ended ? 3 : 1;
    const comp = r2(x.compEmployee + x.compEmployer);
    const empAdd = r2(x.employer - x.compEmployer);
    const memAdd = r2(x.employee - x.compEmployee);
    const total = r2(x.employee + x.employer);
    if (!txt(p.fnpf_no)) checks.push({ level: 'bad', text: `${x.name}: no FNPF member number (Payroll › person).` });
    if (!txt(p.tin)) checks.push({ level: 'warn', text: `${x.name}: no TIN.` });
    if (x.employer - x.compEmployer > 0.05 * x.pays) checks.push({ level: 'warn', text: `${x.name}: the employer share is more than FNPF's ${fnpfMandatoryEmployerPct(x.lastPay)}% – the extra ${$(empAdd)} goes in "Employer additional".` });
    if (x.compEmployer < r2((x.base * fnpfMandatoryEmployerPct(x.lastPay)) / 100) - 0.05 * x.pays) checks.push({ level: 'bad', text: `${x.name}: the employer share is LESS than FNPF's ${fnpfMandatoryEmployerPct(x.lastPay)}% – check the pay rules.` });
    return {
      userUid: x.userUid, name: x.name, memberNo: txt(p.fnpf_no), first, middle, last, tin: txt(p.tin), compulsory: comp, employerAdditional: empAdd, memberAdditional: memAdd, total,
      gross: r2(x.base), grossPaid: r2(x.gross), status, statusText: STATUS_TEXT[status], statusDate: ended ? p.end_date : (p.start_date && p.start_date.slice(0, 7) === ym ? p.start_date : ''),
      frequency: FREQ[x.freq] || 1, employee: r2(x.employee), employer: r2(x.employer), pays: x.pays,
    };
  }).sort((a, b) => (a.last + a.first < b.last + b.first ? -1 : 1));
  const draft = has('pay_runs') ? db().all("SELECT uid FROM pay_runs WHERE status = 'draft' AND substr(pay_date,1,7) = ?", [ym]).length : 0;
  if (draft) checks.unshift({ level: 'bad', text: `${draft} pay run(s) paid in ${ym} are still drafts – make them final first.` });
  if (!rows.length) checks.unshift({ level: 'warn', text: `No FNPF in ${ym} (no final pay runs with FNPF).` });
  if (!txt(emp.fnpfNo)) checks.push({ level: 'bad', text: 'The employer FNPF reference number is not set (Payroll › Filing formats › Employer details).' });
  if (!checks.length) checks.push({ level: 'ok', text: 'Every check passed.' });
  const t = (k) => r2(rows.reduce((s, x) => s + x[k], 0));
  const next = ymAdd(ym, 1);
  const rule = TX.taxRules().fnpf || {};
  return {
    kind: 'fnpf', period: ym, employer: { refNo: emp.fnpfNo || '', name: emp.name, tradingName: emp.tradingName || emp.name, postal: emp.postal || '', city: emp.city || '', tin: emp.tin || '' },
    contributionType: emp.contributionType || 'Normal', contribution: { month: Number(ym.slice(5, 7)), year: Number(ym.slice(0, 4)) }, wages: { month: Number(ym.slice(5, 7)), year: Number(ym.slice(0, 4)) },
    csDue: `${next}-${pad(Math.min(Number(rule.lodgeDay || 14), 28))}`, payDue: monthEnd(next), rows,
    totals: { contributions: t('total'), wages: t('gross'), employees: rows.length, compulsory: t('compulsory'), employerAdditional: t('employerAdditional'), memberAdditional: t('memberAdditional'), employee: t('employee'), employer: t('employer') },
    amount: t('total'), checks, blocking: checks.filter((c) => c.level === 'bad'),
  };
}
// The table exactly as on FNPF's form (for Excel / CSV).
export function fnpfTable(ym) {
  const s = fnpfSchedule(ym);
  return { headers: FNPF_COLUMNS, rows: s.rows.map((r, i) => [i + 1, r.memberNo, r.first, r.middle, r.last, r.tin, r.compulsory, r.employerAdditional, r.memberAdditional, r.total, r.gross, r.status, r.statusDate, r.frequency]) };
}

// ---------------------------------------------------------------- one return: where it is up to
export function workOut(kind, period) {
  need(RETURN_KINDS[kind], 'Which return?');
  return kind === 'vat' ? vatReturnFRCS(period) : fnpfSchedule(period);
}
export function versions(kind, period) {
  return has('tax_return_versions') ? db().all('SELECT * FROM tax_return_versions WHERE kind = ? AND period = ? ORDER BY version DESC', [kind, period]).map((v) => ({ ...v, data: J(v.data, {}) })) : [];
}
export function lodgedVersion(kind, period) { return versions(kind, period).find((v) => v.status === 'lodged') || null; }
// Penalties (estimates – FRCS and FNPF decide). VAT: lodging late 20% + 5% a month; paying late 25% + 5% a month.
// FNPF: 10% of what is unpaid for every month late.
export function penaltyEstimate(kind, { amount, lodgeDue, payDue, lodged, paid, today = dateStr() }) {
  const monthsLate = (due) => (due && due < today ? 1 + Math.floor((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${due}T00:00:00Z`)) / (30.4 * 86400000)) : 0);
  const a = Math.max(0, r2(amount));
  const out = [];
  if (kind === 'vat') {
    const ml = lodged ? 0 : monthsLate(lodgeDue);
    if (ml) out.push({ what: 'Late lodgement', months: ml, amount: r2(a * (0.2 + 0.05 * (ml - 1))) });
    const mp = paid ? 0 : monthsLate(payDue);
    if (mp && a) out.push({ what: 'Late payment', months: mp, amount: r2(a * (0.25 + 0.05 * (mp - 1))) });
  } else {
    const mp = paid ? 0 : monthsLate(payDue);
    if (mp && a) out.push({ what: 'Late payment (10% a month)', months: mp, amount: r2(a * 0.1 * mp) });
  }
  return { lines: out, total: r2(out.reduce((s, x) => s + x.amount, 0)) };
}
// round 2: kept until what it read changes (at most 5 minutes; the penalties go by the date). Shared: read only.
export function returnStatus(kind, period, { today = dateStr() } = {}) {
  return keepTracked(`ret|status|${kind}|${period}|${today}`, () => returnStatusNow(kind, period, { today }), { maxAgeMs: 5 * 60000 });
}
function returnStatusNow(kind, period, { today = dateStr() } = {}) {
  const now = workOut(kind, period);
  const lodged = lodgedVersion(kind, period);
  const file = fileRow(kind, period) || {};
  const lodgeDue = kind === 'fnpf' ? now.csDue : now.due;
  const payDue = kind === 'fnpf' ? now.payDue : now.due;
  const lodgedAmount = lodged ? r2(lodged.amount) : null;
  const item = TX.itemState(kind, period, { due: payDue, amount: lodged ? lodgedAmount : now.amount }, TX.taxRules()[kind], today);
  const changed = lodged ? r2(now.amount - lodgedAmount) : 0;
  const owed = lodged ? lodgedAmount : now.amount;
  const refund = kind === 'vat' && owed < 0;
  const paidAmount = file.paid_date ? r2(file.paid_amount) : item.paid && item.row && item.row.paid_amount ? r2(item.row.paid_amount) : 0;
  const short = !refund && (file.paid_date || item.paid) ? r2(owed - paidAmount) : 0;
  const flags = [];
  if (lodged && Math.abs(changed) > 0.004) flags.push({ key: 'changed', level: 'bad', text: `The figures changed by ${$(changed)} since it was lodged (version ${lodged.version}) – lodge an amended return.` });
  if (short > 0.004) flags.push({ key: 'short', level: 'bad', text: `Paid ${$(paidAmount)} but ${$(owed)} is owed – ${$(short)} still to pay.` });
  if (short < -0.004) flags.push({ key: 'over', level: 'warn', text: `Paid ${$(paidAmount)}, ${$(-short)} more than the return – ask ${RETURN_KINDS[kind].to} for a credit or refund.` });
  if (refund && !file.refund_date) flags.push({ key: 'refund', level: 'info', text: `Refund of ${$(-owed)} due from FRCS – record it when it reaches the bank.` });
  const pen = penaltyEstimate(kind, { amount: owed, lodgeDue, payDue, lodged: !!lodged || item.lodged, paid: refund || item.paid, today });
  if (pen.total) flags.push({ key: 'late', level: 'bad', text: `Late: estimated penalty ${$(pen.total)} (${pen.lines.map((l) => `${l.what} ${$(l.amount)}`).join(', ')}). Lodge and pay now to stop it growing.` });
  return { kind, period, now, lodged, versions: versions(kind, period), file, item, lodgeDue, payDue, owed, refund, paidAmount, short, changed, flags, penalty: pen };
}

// ---------------------------------------------------------------- lodging (a frozen copy each time)
export function lodgeReturn(user, kind, period, { date, ref, photos = [], note, force = false, reason } = {}) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(RETURN_KINDS[kind], 'Which return?');
  need(canFile(user, kind), `You cannot lodge the ${RETURN_KINDS[kind].title}.`);
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date it was lodged.');
  need(txt(ref) || (photos || []).length, `Enter the ${RETURN_KINDS[kind].to} receipt / reference number, or take a photo of the proof.`);
  const now = workOut(kind, period);
  if (now.blocking.length) {
    need(force && isTop(user), `Fix these first: ${now.blocking.map((c) => c.text).join(' ')}`);
    needReason(user, reason, 'Write why it is lodged with problems.');
  }
  const prev = lodgedVersion(kind, period);
  const version = (versions(kind, period)[0] || { version: 0 }).version + 1;
  const ts = stamp();
  const data = kind === 'vat' ? { lines: now.lines, rate: now.rate, adjust: now.adjust, schedule: now.schedule, noTin: now.noTin.length, checks: now.checks }
    : { rows: now.rows, totals: now.totals, employer: now.employer, csDue: now.csDue, checks: now.checks };
  if (prev) {
    db().run(`UPDATE tax_return_versions SET status = 'superseded', superseded_at = ?, superseded_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [ts, `Amended by version ${version}`, ts, deviceId(), prev.uid]);
  }
  const uid = `${kind}|${period}|v${version}`;
  db().run(`INSERT INTO tax_return_versions (uid, kind, period, version, amount, data, lodged_at, lodged_by_name, lodge_ref, note, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?, 'lodged', ?,?)`,
    [uid, kind, period, version, r2(now.amount), JSON.stringify(data), d, user.name, txt(ref) || null, txt(note) || (force ? `Lodged with problems: ${txt(reason)}` : null), ts, deviceId()]);
  ensureFile(kind, period);
  // The tax calendar's lodgement proof (an amendment adds to it).
  TX.recordLodgement(user, kind, period, { date: d, ref: `${txt(ref) || 'see photo'}${version > 1 ? ` (amended, version ${version})` : ''}`, photos, note: `${RETURN_KINDS[kind].form} version ${version}: ${$(now.amount)}`, due: kind === 'fnpf' ? now.csDue : now.due, amount: now.amount });
  db().run("UPDATE tax_proofs SET amount = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [r2(now.amount), ts, deviceId(), `${kind}|${period}`]);
  // A VAT refund month needs no payment.
  if (kind === 'vat' && now.amount < 0) {
    const row = db().get('SELECT not_needed FROM tax_proofs WHERE uid = ?', [`vat|${period}`]);
    if (row && !(row.not_needed & 2)) db().run("UPDATE tax_proofs SET not_needed = not_needed | 2, pay_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [`Refund due ${$(-now.amount)} – nothing to pay`, ts, deviceId(), `vat|${period}`]);
  }
  audit({ user, action: `${RETURN_KINDS[kind].title} ${period} lodged (version ${version}, ${$(now.amount)})${prev ? ` – amends version ${prev.version}` : ''}`, table: 'tax_return_versions', recordUid: uid, reason: force ? txt(reason) : null });
  return returnStatus(kind, period);
  });
}

// ---------------------------------------------------------------- paying (booked in the accounts and the bank)
// via: 'bank:<account uid>' or 'cash' / 'cash:<shop>'. method: 'transfer' | 'cheque' | 'cash'.
// A cheque is chosen from the account's unused cheque leaves (or typed); it goes into the cheque register (payee FRCS /
// FNPF) so the cheque book, the bank position and the bank reconciliation all see it – once.
export function payReturn(user, kind, period, { date, amount, via, method = 'transfer', ref, chequeNo, photos = [], penalty = 0, note } = {}) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(RETURN_KINDS[kind], 'Which return?');
  need(canFile(user, kind), `You cannot record the ${RETURN_KINDS[kind].title} payment.`);
  const st = returnStatus(kind, period);
  need(!st.file.pay_link, 'A payment is already recorded. Take it back first if it was wrong.');
  need(!st.refund, 'This month is a refund – there is nothing to pay. Record the refund when FRCS pays it.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date it was paid.');
  const a = r2(amount === undefined || amount === '' || amount === null ? st.owed : amount);
  need(a > 0, 'Enter the amount paid.');
  need(['transfer', 'cheque', 'cash'].includes(method), 'Choose how it was paid.');
  const v = txt(via) || (method === 'cash' ? 'cash' : '');
  const isCash = v === 'cash' || v.startsWith('cash:');
  need(isCash || v.startsWith('bank:'), 'Choose the bank account it was paid from.');
  need(method === 'cash' ? isCash : v.startsWith('bank:'), method === 'cash' ? 'Cash is paid from the cash, not a bank account.' : 'A transfer or cheque comes from a bank account – choose it.');
  const pen = r2(penalty);
  need(pen >= 0, 'The penalty cannot be below zero.');
  const accountUid = v.startsWith('bank:') ? v.slice(5) : null;
  let cheque = null;
  if (method === 'cheque') cheque = checkChequeLeaf(accountUid, chequeNo !== undefined && chequeNo !== '' ? chequeNo : ref);
  else need(txt(ref), 'Enter the bank / receipt reference.');
  const refText = cheque ? `Cheque ${cheque.no}${txt(ref) && txt(ref) !== String(cheque.no) ? ` (${txt(ref)})` : ''}` : txt(ref);
  const bankEntry = !cheque;
  let link;
  let chequeUid = null;
  db().transaction(() => {
    if (cheque) {
      chequeUid = `CQ-${kind.toUpperCase()}-${period}-${cheque.no}`;
      db().run(`INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, memo, written_by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,'written',?,?,?,?)`,
        [chequeUid, accountUid, cheque.bookUid, cheque.no, d, kind === 'vat' ? 'FRCS (VAT)' : 'FNPF', r2(a + pen), `${RETURN_KINDS[kind].title} ${period}${pen ? ` incl. penalty ${$(pen)}` : ''}`, user.name, stamp(), deviceId()]);
    }
    if (kind === 'vat') {
      const m = F().moneyCode(v);
      link = A().saveJournal(user, { date: d, memo: `VAT ${period} paid to FRCS`, kind: 'tax_payment', bankEntry, meta: { tax: 'vat', amount: a, ym: period, year: null, n: null, reference: refText },
        lines: [{ code: '2200', debit: a, credit: 0, shop: 'OFFICE' }, { code: m.code, debit: 0, credit: a, shop: m.shop }] });
    } else {
      S().prepareMonth(period);
      const uid = `STAT-fnpf-${period}`;
      S().payStat(user, uid, { date: d, amount: a, method, accountUid, reference: refText, receiptNo: '', photos, notes: txt(note) || null, chequeInRegister: !!cheque });
      link = uid;
    }
  });
  let penaltyLink = null;
  if (pen > 0) {
    A().ensureAccounts();
    const m = F().moneyCode(v);
    penaltyLink = A().saveJournal(user, { date: d, memo: `${RETURN_KINDS[kind].to} penalty – ${RETURN_KINDS[kind].title} ${period}`, kind: 'tax_payment', bankEntry,
      meta: { tax: `${kind}_penalty`, amount: pen, ym: period, reference: refText }, lines: [{ code: '6250', debit: pen, credit: 0, shop: 'OFFICE' }, { code: m.code, debit: 0, credit: pen, shop: m.shop }] });
  }
  setFile(kind, period, { pay_link: String(link), pay_via: v, pay_method: method, pay_ref: refText, paid_date: d, paid_amount: a, cheque_uid: chequeUid, penalty_link: penaltyLink, penalty_amount: pen || null, notes: txt(note) || null });
  TX.recordTaxPaymentProof(user, kind, period, { date: d, amount: a, ref: refText, photos, note: `Booked: ${kind === 'vat' ? 'Accounting › tax payment' : 'Payroll › FNPF payment'}${pen ? `; penalty ${$(pen)}` : ''}`, due: st.payDue });
  audit({ user, action: `${RETURN_KINDS[kind].title} ${period} paid ${$(a)} by ${method}${pen ? ` (+ penalty ${$(pen)})` : ''}`, table: 'tax_returns', recordUid: fileUid(kind, period) });
  return returnStatus(kind, period);
  });
}
// A cheque number for a payment: it must be in one of the account's cheque books and not used yet.
export function checkChequeLeaf(accountUid, chequeNo) {
  need(accountUid, 'Choose the bank account the cheque is from.');
  const raw = txt(chequeNo).replace(/\D/g, '');
  const no = Number(raw);
  need(raw && Number.isFinite(no) && no > 0, 'Choose the cheque number (or type it).');
  const book = db().get('SELECT * FROM cheque_books WHERE account_uid = ? AND ? BETWEEN first_no AND last_no ORDER BY active DESC LIMIT 1', [accountUid, no]);
  need(book, `Cheque ${no} is not in any cheque book for this account. Add the cheque book first (Invoices & cheques › Cheque books).`);
  const used = db().get('SELECT status, payee FROM cheques WHERE account_uid = ? AND cheque_no = ?', [accountUid, no]);
  need(!used, `Cheque ${no} is already used (${used && used.status}${used && used.payee ? `, ${used.payee}` : ''}).`);
  return { no, bookUid: book.uid };
}
export function chequeOptions(accountUid) {
  try { return require('../payables/chequebooks.js').availableCheques(accountUid); } catch (e) { return []; }
}
// Take back a payment recorded by mistake: the accounts, the bank line and the proof are all reversed (kept in the history).
export function undoReturnPayment(user, kind, period, reason) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(canFile(user, kind), 'You cannot change this payment.');
  needReason(user, reason, 'Write why the payment is taken back.');
  const f = fileRow(kind, period);
  need(f && f.pay_link, 'No payment recorded.');
  if (kind === 'vat') A().voidJournal(user, f.pay_link, txt(reason) || 'Taken back');
  else S().undoStatPayment(user, f.pay_link, txt(reason) || 'Taken back');
  if (f.penalty_link) A().voidJournal(user, f.penalty_link, txt(reason) || 'Taken back');
  // The cheque leaf stays in the register as void (it cannot be used again once written).
  if (f.cheque_uid) db().run("UPDATE cheques SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'written'", [txt(reason) || 'Taken back', stamp(), deviceId(), f.cheque_uid]);
  try { TX.undoTaxProof(user, kind, period, 'pay', txt(reason) || 'Taken back'); } catch (e) { /* proof already gone */ }
  setFile(kind, period, { pay_link: null, pay_via: null, pay_method: null, pay_ref: null, paid_date: null, paid_amount: null, cheque_uid: null, penalty_link: null, penalty_amount: null });
  audit({ user, action: `${RETURN_KINDS[kind].title} ${period}: payment taken back`, table: 'tax_returns', recordUid: fileUid(kind, period), reason: txt(reason) || null });
  return returnStatus(kind, period);
  });
}
// VAT refund received from FRCS (money into the bank, the VAT account cleared).
export function recordVatRefund(user, ym, { date, amount, via, ref } = {}) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(canFile(user, 'vat'), 'You cannot record VAT refunds.');
  const st = returnStatus('vat', ym);
  need(st.refund, 'This month is not a refund.');
  need(!st.file.refund_link, 'The refund is already recorded.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date it reached the bank.');
  const a = r2(amount === undefined || amount === '' ? -st.owed : amount);
  need(a > 0, 'Enter the amount received.');
  const v = txt(via);
  need(v.startsWith('bank:') || v === 'cash' || v.startsWith('cash:'), 'Choose the bank account it went into.');
  const m = F().moneyCode(v);
  const link = A().saveJournal(user, { date: d, memo: `VAT refund ${ym} from FRCS`, kind: 'tax_payment', meta: { tax: 'vat_refund', amount: a, ym, reference: txt(ref) || null },
    lines: [{ code: m.code, debit: a, credit: 0, shop: m.shop }, { code: '2200', debit: 0, credit: a, shop: 'OFFICE' }] });
  setFile('vat', ym, { refund_link: String(link), refund_amount: a, refund_date: d });
  audit({ user, action: `VAT ${ym}: refund ${$(a)} received`, table: 'tax_returns', recordUid: fileUid('vat', ym) });
  return returnStatus('vat', ym);
  });
}

// ---------------------------------------------------------------- list, warnings
// Months with something to file (from the tax calendar), newest first.
export function returnsList(kind, { today = dateStr(), months = 12 } = {}) {
  const last = ymAdd(today.slice(0, 7), -1);
  const out = [];
  for (let i = 0; i < months; i++) {
    const ym = ymAdd(last, -i);
    let st;
    try { st = returnStatus(kind, ym, { today }); } catch (e) { continue; }
    if (!st.lodged && !st.file.pay_link && !Math.abs(st.now.amount) && !(kind === 'vat' && st.now.lines[1])) continue;
    out.push(st);
  }
  return out;
}
export function returnsAlerts(user, today = dateStr()) {
  const out = [];
  for (const kind of Object.keys(RETURN_KINDS)) {
    if (!canFile(user, kind)) continue;
    // Only months already lodged or paid can be "changed" or "paid short" – cheap to find, so Home stays quick.
    let list = [];
    try {
      const from = ymAdd(today.slice(0, 7), -6);
      const yms = db().all('SELECT DISTINCT period FROM tax_return_versions WHERE kind = ? AND period >= ? UNION SELECT period FROM tax_returns WHERE kind = ? AND period >= ? AND pay_link IS NOT NULL', [kind, from, kind, from]).map((r) => r.period);
      list = yms.map((ym) => returnStatus(kind, ym, { today }));
    } catch (e) { list = []; }
    for (const st of list) {
      // Late lodging / paying is already warned about by the tax calendar; here: changed after lodging, paid short.
      for (const f of st.flags.filter((x) => x.key === 'changed' || x.key === 'short')) {
        out.push({ id: `ret-${kind}-${st.period}-${f.key}`, level: 'urgent', area: 'Tax', text: `${RETURN_KINDS[kind].title} ${st.period}: ${f.text}`,
          nav: { screen: 'TaxReturn', params: { kind, period: st.period } } });
      }
    }
  }
  return out;
}
