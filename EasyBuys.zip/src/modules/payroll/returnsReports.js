// v3.9 Returns as documents (PDF / Excel / CSV through the reports hub and the return screen): the FRCS VAT return
// laid out line by line like form IRS217, the VAT Input Schedule FRCS asks for with it, and the FNPF Contribution
// Schedule with FNPF's own columns, header and signature block. A lodged return prints the frozen lodged copy.
import { stamp } from '../../services/core.js';
import * as RT from './returns.js';
import { employerDetails } from './filing.js';

const { $ } = RT;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const monthName = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const checkRows = (checks) => (checks || []).map((c) => ({ l: c.level === 'ok' ? '✓' : c.level === 'bad' ? 'FIX' : 'Check', t: c.text, _tone: c.level === 'bad' ? 'bad' : c.level === 'warn' ? 'warn' : null }));

// The return as worked out now, or the lodged copy (version) when asked.
function vatData(ym, version) {
  if (version) {
    const v = RT.versions('vat', ym).find((x) => x.version === Number(version));
    if (v) return { ...v.data, lodged: v, amount: v.amount };
  }
  return RT.vatReturnFRCS(ym);
}
export function vatReturnReport(ym, { version } = {}) {
  const v = vatData(ym, version);
  const emp = employerDetails();
  const L = v.lines;
  const rows = RT.VAT_LINES.map(([n, label]) => {
    const note = n === 5 && v.creditVat ? `includes credit notes received ${$(v.creditVat)}` : (v.adjust && Object.entries(RT.VAT_ADJUST_LINES).find(([, x]) => x === n) && (v.adjust[Object.entries(RT.VAT_ADJUST_LINES).find(([, x]) => x === n)[0]] || {}).note) || '';
    return { n: String(n), label, note, amount: $(L[n]), _tone: n === 13 ? 'highlight' : null };
  });
  return {
    kind: 'vat_frcs', title: 'VAT Return', fileName: `VAT-Return-FRCS-${ym}${v.lodged ? `-v${v.lodged.version}` : ''}`, subtitle: `${emp.name} · ${monthName(ym)} · Fiji Revenue & Customs Service (form IRS217)`,
    info: [['Registered person', emp.name], ['TIN', emp.tin || '—'], ['Taxable period', `${ym}-01 to ${monthName(ym)} end`], ['Basis', 'Invoice basis'], ['VAT rate', `${v.rate}% (tax fraction ${v.rate}/${100 + v.rate})`],
      ['Due', RT.vatReturnFRCS(ym).due], ['Status', v.lodged ? `Lodged ${v.lodged.lodged_at} (version ${v.lodged.version}, ref ${v.lodged.lodge_ref || '—'})` : 'Draft – not lodged'], ['Generated', stamp()]],
    summary: [{ label: 'VAT collected (line 6)', value: $(L[6]) }, { label: 'Input tax (line 12)', value: $(L[12]) }, { label: L[13] >= 0 ? 'To pay FRCS (line 13)' : 'Refund due (line 13)', value: $(Math.abs(L[13])), tone: L[13] >= 0 ? 'bad' : undefined }],
    sections: [
      { title: 'VAT return – lines as on the FRCS form', columns: [col('n', 'Line'), col('label', 'Description'), col('note', 'Note'), col('amount', 'Amount (FJD)', R)], rows },
      { title: 'VAT Input Schedule (line 7) – local purchases with a tax invoice', columns: [col('i', 'No.'), col('tin', 'Supplier TIN'), col('supplier', 'Supplier name'), col('no', 'Tax invoice no.'), col('date', 'Invoice date'), col('total', 'Value incl. VAT', R), col('vat', 'VAT', R)],
        rows: (v.schedule || []).map((r, i) => ({ i: String(i + 1), ...r, total: $(r.total), vat: $(r.vat) })).concat([{ i: '', tin: '', supplier: 'TOTAL', no: '', date: '', total: $((v.schedule || []).reduce((s, x) => s + x.total, 0)), vat: $(L[7]), _tone: 'highlight' }]),
        note: 'FRCS does not allow input tax claims without this schedule. Invoices without the supplier TIN are left out.' },
      { title: 'Checks before lodging', columns: [col('l', 'Result'), col('t', 'Check')], rows: checkRows(v.checks) },
    ],
  };
}
// Just the Input Schedule (for Excel / CSV upload).
export function vatInputScheduleReport(ym, { version } = {}) {
  const v = vatData(ym, version);
  return {
    kind: 'vat_input_schedule', title: 'VAT Input Schedule', fileName: `VAT-Input-Schedule-${ym}`, subtitle: `${employerDetails().name} · ${monthName(ym)}`,
    info: [['TIN', employerDetails().tin || '—'], ['Taxable period', monthName(ym)], ['Generated', stamp()]],
    summary: [{ label: 'Invoices', value: String((v.schedule || []).length) }, { label: 'Input VAT', value: $(v.lines[7]) }],
    sections: [{ title: 'Input schedule', columns: [col('tin', 'Supplier TIN'), col('supplier', 'Supplier name'), col('no', 'Tax invoice no.'), col('date', 'Invoice date'), col('total', 'Value incl. VAT', R), col('vat', 'VAT', R)],
      rows: (v.schedule || []).map((r) => ({ ...r, total: Number(r.total).toFixed(2), vat: Number(r.vat).toFixed(2) })) }],
  };
}

function fnpfData(ym, version) {
  if (version) {
    const v = RT.versions('fnpf', ym).find((x) => x.version === Number(version));
    if (v) return { ...RT.fnpfSchedule(ym), ...v.data, lodged: v };
  }
  return RT.fnpfSchedule(ym);
}
export function fnpfScheduleReport(ym, { version } = {}) {
  const s = fnpfData(ym, version);
  const e = s.employer;
  return {
    kind: 'fnpf_cs', title: 'Contribution Schedule Form', fileName: `FNPF-Contribution-Schedule-${ym}${s.lodged ? `-v${s.lodged.version}` : ''}`, subtitle: `Fiji National Provident Fund · ${e.name} · ${monthName(ym)}`,
    info: [['Employer Reference No.', e.refNo || '— (not set)'], ['Employer Name', e.name], ['Employer Trading Name', e.tradingName || e.name], ['Postal Address', e.postal || '—'], ['City', e.city || '—'],
      ['Contribution Type', s.contributionType || 'Normal'], ['Contribution Month and Year', monthName(ym)], ['Wages Month and Year', monthName(ym)], ['CS Due Date', s.csDue], ['Payment due', s.payDue],
      ['Status', s.lodged ? `Lodged ${s.lodged.lodged_at} (version ${s.lodged.version}, ref ${s.lodged.lodge_ref || '—'})` : 'Draft – not lodged'], ['Generated', stamp()]],
    summary: [{ label: 'Total Contributions', value: $(s.totals.contributions) }, { label: 'Total Wages', value: $(s.totals.wages) }, { label: 'Total no. of Employees', value: String(s.totals.employees) }],
    sections: [
      { title: 'Members', columns: [col('i', 'Line No.'), col('memberNo', 'Member Number'), col('first', "First Name"), col('middle', 'Middle Name'), col('last', 'Last Name'), col('tin', 'Tax ID No.'),
        col('compulsory', 'Compulsory Contribution', R), col('employerAdditional', 'Employer Additional', R), col('memberAdditional', 'Member Additional', R), col('total', 'Total Contribution', R),
        col('gross', 'Monthly Gross Salary', R), col('status', 'Employment Status'), col('statusDate', 'Status Date'), col('frequency', 'Payment Frequency')],
        rows: s.rows.map((r, i) => ({ i: String(i + 1), memberNo: r.memberNo || 'MISSING', first: r.first, middle: r.middle, last: r.last, tin: r.tin, compulsory: $(r.compulsory), employerAdditional: $(r.employerAdditional),
          memberAdditional: $(r.memberAdditional), total: $(r.total), gross: $(r.gross), status: `${r.status} ${r.statusText}`, statusDate: r.statusDate || '', frequency: `${r.frequency} ${['', 'Weekly', 'Fortnightly', 'Monthly'][r.frequency] || ''}`, _tone: r.memberNo ? null : 'bad' }))
          .concat([{ i: '', memberNo: '', first: 'TOTAL', middle: '', last: '', tin: '', compulsory: $(s.totals.compulsory), employerAdditional: $(s.totals.employerAdditional), memberAdditional: $(s.totals.memberAdditional), total: $(s.totals.contributions), gross: $(s.totals.wages), status: '', statusDate: '', frequency: '', _tone: 'highlight' }]),
        note: 'Employment Status: 1 = Active, 2 = On leave, 3 = Terminated. Payment Frequency: 1 = Weekly, 2 = Fortnightly, 3 = Monthly. Compulsory = employee 8% + the employer rate set by FNPF.' },
      { title: 'Employer representative', columns: [col('k', ''), col('v', '')], rows: [{ k: 'Employer Rep. Name', v: '' }, { k: 'Designation', v: '' }, { k: 'Employer Rep. Signature', v: '' }, { k: 'Date', v: '' }] },
      { title: 'Checks before lodging', columns: [col('l', 'Result'), col('t', 'Check')], rows: checkRows(s.checks) },
    ],
  };
}

// 1.0.0 build 45 (owner, 11 Nov: "for VAT calculation transparency and connection needs to be there – an Excel export
// of the VAT return for each month for easier assessing"): one workbook per month with every figure and every record
// behind it, amounts as numbers (so they can be added up in Excel):
//   Summary · VAT return (each line, how it is worked out) · Sales by day (every End of day / till balance / typed sale
//   of every shop, empty days too, with who checked the day) · Purchases (every invoice of the month and where its VAT
//   went: line 7, line 5, left out and why) · Cross-check (each line added up again from the sheets) · Checks.
const n2 = (x) => Math.round((Number(x) || 0) * 100) / 100;
const HOW = {
  1: 'Sum of "Sales incl. VAT" on the Sales by day sheet',
  2: 'Sum of "Zero-rated" on the Sales by day sheet',
  3: 'Line 1 − line 2',
  4: 'Line 3 × tax fraction',
  5: 'VAT on credit notes received (Purchases sheet, "Line 5") + amount typed in',
  6: 'Line 4 + line 5',
  7: 'Sum of VAT on the Purchases sheet rows marked "Line 7"',
  8: 'Typed in (customs VAT on imports)',
  9: 'Typed in',
  10: 'Line 7 + line 8 + line 9',
  11: 'Typed in',
  12: 'Line 10 − line 11',
  13: 'Line 6 − line 12 (to pay FRCS; a refund if negative)',
};
export function vatWorkbookReport(ym, { version } = {}) {
  const v = vatData(ym, version);
  const now = RT.vatReturnFRCS(ym); // the records behind it (as they are now)
  const emp = employerDetails();
  const L = v.lines;
  const MR = require('../accounting/monthRecords.js');
  const adjNote = (n) => { const k = Object.entries(RT.VAT_ADJUST_LINES).find(([, x]) => x === n); return k && v.adjust && v.adjust[k[0]] ? v.adjust[k[0]].note || '' : ''; };
  const lineRows = RT.VAT_LINES.map(([n, label]) => ({ n, label, amount: n2(L[n]), how: HOW[n] + (n === 4 ? ` (${v.fraction})` : ''), note: adjNote(n), _tone: n === 13 ? 'highlight' : null }));

  // Sales: every record, and every shop-day with none (so gaps show), with the day's check
  const shops = (() => { try { return require('../../db/connection.js').db().all('SELECT code FROM shops WHERE active = 1 ORDER BY sort, code').map((r) => r.code).filter((c) => /^S\d+$/.test(String(c))); } catch (e) { return []; } })();
  const dayInfo = {};
  for (const s of shops) for (const d of MR.monthRecords({ ym, shop: s }).days) dayInfo[`${s}|${d.date}`] = d;
  const checkedText = (s, date) => { const d = dayInfo[`${s}|${date}`]; if (!d || d.future) return ''; const c = MR.dayChecked(s, d); return c ? `Checked – ${c.by} ${String(c.at).slice(0, 16)}` : 'NOT CHECKED'; };
  const src = (r) => (r.aronium ? 'Aronium End of day' : r.go && r.go[0] === 'TillCountView' ? 'Till balance' : r.typed ? 'Typed in' : 'Other');
  const sales = (now.saleRows || []).map((r) => ({ date: r.date, shop: r.shop, src: src(r), ref: r.ref || '', total: n2(r.total), zero: n2(r.zero), std: n2(n2(r.total) - n2(r.zero)), vat: n2(r.vat), checked: checkedText(r.shop, r.date) }));
  for (const [k, d] of Object.entries(dayInfo)) {
    const [s] = k.split('|');
    if (d.future || d.rows.length) continue;
    sales.push({ date: d.date, shop: s, src: 'NO SALES RECORDED', ref: '', total: 0, zero: 0, std: 0, vat: 0, checked: checkedText(s, d.date), _tone: 'warn' });
  }
  sales.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.shop < b.shop ? -1 : a.shop > b.shop ? 1 : 0));
  const sum = (rows, k) => n2(rows.reduce((t, r) => t + (Number(r[k]) || 0), 0));

  // Purchases: every invoice of the month + typed expenses with VAT, and where the VAT went
  const AP = require('../payables/service.js');
  const uidOf = (r) => (r.go && r.go[1] && r.go[1].uid) || '';
  const used = {};
  const pur = [];
  const add = (r, where, kind) => { const u = uidOf(r); if (u) used[u] = true; pur.push({ date: r.date, supplier: r.supplier || '', tin: r.tin || '', no: r.no || '', shop: r.shop || '', kind, total: n2(r.total), vat: n2(r.vat), where, status: r.status || '', vatCheck: '' }); };
  (v.schedule || []).forEach((r) => add(r, 'Line 7 – Input Schedule', 'Tax invoice'));
  (v.credits || []).forEach((r) => add({ ...r, vat: Math.abs(r.vat) }, 'Line 5 – credit note received', 'Credit note'));
  (v.noTin || []).forEach((r) => add(r, 'LEFT OUT – no supplier TIN', 'Tax invoice'));
  const { db } = require('../../db/connection.js');
  for (const x of db().all("SELECT uid FROM ap_invoices WHERE status <> 'void' AND substr(invoice_date,1,7) = ? ORDER BY invoice_date", [ym])) {
    const i = AP.getInvoice(x.uid);
    if (!i) continue;
    const st = AP.vatStatusOf(i);
    const row = pur.find((p) => p.no === (i.invoice_no || '') && p.date === i.invoice_date && n2(p.total) === n2(Math.abs(i.total)));
    if (used[i.uid] || row) { if (row) { row.vatCheck = st ? st.text : ''; row.status = i.status; } continue; }
    pur.push({ date: i.invoice_date, supplier: i.supplier_name, tin: i.supplier_tin || '', no: i.invoice_no || '', shop: i.shop_code || '', kind: 'Tax invoice', total: n2(i.total), vat: n2(i.vat), where: n2(i.vat) ? 'Not counted – see Checks' : 'No VAT on it', status: i.status, vatCheck: st ? st.text : '' });
  }
  pur.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  pur.forEach((p) => { p.checked = p.status === 'to_check' ? 'NOT CHECKED' : p.status ? 'Checked' : ''; if (p.where.startsWith('LEFT') || p.checked === 'NOT CHECKED' || /does not fit|more than/.test(p.vatCheck)) p._tone = 'warn'; });

  // Cross-check: every line added up again from the sheets
  const l7 = n2(pur.filter((p) => p.where.startsWith('Line 7')).reduce((t, p) => t + p.vat, 0));
  const cr = n2(pur.filter((p) => p.where.startsWith('Line 5')).reduce((t, p) => t + p.vat, 0));
  const cross = [
    { what: 'Line 1 – sales incl. VAT', sheet: sum(sales, 'total'), ret: n2(L[1]) },
    { what: 'Line 2 – zero-rated sales', sheet: sum(sales, 'zero'), ret: n2(L[2]) },
    { what: 'Line 4 – VAT collected (line 3 × fraction)', sheet: n2(((sum(sales, 'total') - sum(sales, 'zero')) * v.rate) / (100 + v.rate)), ret: n2(L[4]) },
    { what: 'VAT on each sale added up (shown on the sales)', sheet: sum(sales, 'vat'), ret: n2(L[4]), info: true },
    { what: 'Line 7 – VAT on the Input Schedule', sheet: l7, ret: n2(L[7]) },
    { what: 'Line 5 – credit notes (without typed-in part)', sheet: cr, ret: n2(v.creditVat || 0) },
    { what: 'Line 13 – line 6 − line 12', sheet: n2(L[6] - L[12]), ret: n2(L[13]) },
  ].map((c) => { const d = n2(c.sheet - c.ret); return { ...c, diff: d, ok: Math.abs(d) < 0.01 ? 'Agrees' : c.info ? `Differs by ${d.toFixed(2)} (rounding on each sale – line 4 is the one used)` : `DIFFERS by ${d.toFixed(2)}`, _tone: Math.abs(d) < 0.01 ? null : c.info ? 'warn' : 'bad' }; });

  const tk = now.ticks;
  return {
    kind: 'vat_workbook', title: 'VAT Return – workings', fileName: `VAT-Return-workings-${ym}${v.lodged ? `-v${v.lodged.version}` : ''}`, subtitle: `${emp.name} · ${monthName(ym)}`,
    info: [['Registered person', emp.name], ['TIN', emp.tin || '—'], ['Taxable period', monthName(ym)], ['Basis', 'Invoice basis'], ['VAT rate', `${v.rate}% (tax fraction ${v.fraction})`], ['Due', now.due],
      ['Status', v.lodged ? `Lodged ${v.lodged.lodged_at} (version ${v.lodged.version}, ref ${v.lodged.lodge_ref || '—'})` : 'Draft – not lodged'],
      ['Entries checked', tk ? `${tk.done} of ${tk.total} (sales days ${tk.daysDone}/${tk.days}, invoices ${tk.invoicesDone}/${tk.invoices})` : '—'],
      ['Cross-check', cross.some((c) => c._tone === 'bad') ? 'SOME FIGURES DO NOT AGREE – see the Cross-check sheet' : 'Every line agrees with the sheets'], ['Generated', stamp()]],
    summary: [{ label: 'Sales incl. VAT (line 1)', value: n2(L[1]) }, { label: 'Zero-rated (line 2)', value: n2(L[2]) }, { label: 'VAT collected (line 6)', value: n2(L[6]) }, { label: 'Input tax (line 12)', value: n2(L[12]) },
      { label: L[13] >= 0 ? 'To pay FRCS (line 13)' : 'Refund due from FRCS (line 13)', value: n2(Math.abs(L[13])) }],
    sections: [
      { title: 'VAT return', columns: [col('n', 'Line'), col('label', 'Description'), col('amount', 'Amount (FJD)', R), col('how', 'How it is worked out'), col('note', 'Note typed in')], rows: lineRows },
      { title: 'Sales by day', columns: [col('date', 'Date'), col('shop', 'Shop'), col('src', 'Record'), col('ref', 'Reference'), col('total', 'Sales incl. VAT', R), col('zero', 'Zero-rated', R), col('std', 'Standard-rated incl. VAT', R), col('vat', 'VAT', R), col('checked', 'Checked')],
        rows: sales, totals: [{ label: 'Sales incl. VAT (line 1)', value: sum(sales, 'total'), strong: true }, { label: 'Zero-rated (line 2)', value: sum(sales, 'zero') }] },
      { title: 'Purchases', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('tin', 'Supplier TIN'), col('no', 'Invoice no.'), col('shop', 'Shop'), col('kind', 'Type'), col('total', 'Total incl. VAT', R), col('vat', 'VAT', R), col('where', 'Where the VAT went'), col('checked', 'Checked'), col('vatCheck', 'VAT check')],
        rows: pur, totals: [{ label: 'VAT claimed on line 7', value: l7, strong: true }, { label: 'Credit notes on line 5', value: cr }] },
      { title: 'Cross-check', columns: [col('what', 'Figure'), col('sheet', 'Added up from the sheets', R), col('ret', 'On the return', R), col('diff', 'Difference', R), col('ok', 'Result')], rows: cross },
      { title: 'Checks', columns: [col('l', 'Result'), col('t', 'Check')], rows: checkRows(now.checks) },
    ],
  };
}
