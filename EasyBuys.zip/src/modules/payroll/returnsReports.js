// v3.9 Returns as documents (PDF / Excel / CSV through the reports hub and the return screen): the FRCS VAT return
// laid out line by line like form IRS217, the VAT Input Schedule FRCS asks for with it, and the FNPF Contribution
// Schedule with FNPF's own columns, header and signature block. A lodged return prints the frozen lodged copy.
import { stamp } from '../../services/core.js';
import * as RT from './returns.js';
import { employerDetails } from './filing.js';

const { $ } = RT;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const monthName = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const checkRows = (checks) => (checks || []).map((c) => ({ l: c.level === 'ok' ? '✓' : c.level === 'bad' ? 'FIX' : 'Check', t: c.text, _tone: c.level === 'bad' ? 'bad' : c.level === 'warn' ? 'warn' : null }));

// The return as worked out now, or the lodged copy (version) when asked.
function vatData(ym, version) {
  if (version) {
    const v = RT.versions('vat', ym).find((x) => x.version === Number(version));
    if (v) return { ...v.data, lodged: v, amount: v.amount };
  }
  return RT.vatReturnFRCS(ym);
}
export function vatReturnReport(ym, { version } = {}) {
  const v = vatData(ym, version);
  const emp = employerDetails();
  const L = v.lines;
  const rows = RT.VAT_LINES.map(([n, label]) => {
    const note = n === 5 && v.creditVat ? `includes credit notes received ${$(v.creditVat)}` : (v.adjust && Object.entries(RT.VAT_ADJUST_LINES).find(([, x]) => x === n) && (v.adjust[Object.entries(RT.VAT_ADJUST_LINES).find(([, x]) => x === n)[0]] || {}).note) || '';
    return { n: String(n), label, note, amount: $(L[n]), _tone: n === 13 ? 'highlight' : null };
  });
  return {
    kind: 'vat_frcs', title: 'VAT Return', fileName: `VAT-Return-FRCS-${ym}${v.lodged ? `-v${v.lodged.version}` : ''}`, subtitle: `${emp.name} · ${monthName(ym)} · Fiji Revenue & Customs Service (form IRS217)`,
    info: [['Registered person', emp.name], ['TIN', emp.tin || '—'], ['Taxable period', `${ym}-01 to ${monthName(ym)} end`], ['Basis', 'Invoice basis'], ['VAT rate', `${v.rate}% (tax fraction ${v.rate}/${100 + v.rate})`],
      ['Due', RT.vatReturnFRCS(ym).due], ['Status', v.lodged ? `Lodged ${v.lodged.lodged_at} (version ${v.lodged.version}, ref ${v.lodged.lodge_ref || '—'})` : 'Draft – not lodged'], ['Generated', stamp()]],
    summary: [{ label: 'VAT collected (line 6)', value: $(L[6]) }, { label: 'Input tax (line 12)', value: $(L[12]) }, { label: L[13] >= 0 ? 'To pay FRCS (line 13)' : 'Refund due (line 13)', value: $(Math.abs(L[13])), tone: L[13] >= 0 ? 'bad' : undefined }],
    sections: [
      { title: 'VAT return – lines as on the FRCS form', columns: [col('n', 'Line'), col('label', 'Description'), col('note', 'Note'), col('amount', 'Amount (FJD)', R)], rows },
      { title: 'VAT Input Schedule (line 7) – local purchases with a tax invoice', columns: [col('i', 'No.'), col('tin', 'Supplier TIN'), col('supplier', 'Supplier name'), col('no', 'Tax invoice no.'), col('date', 'Invoice date'), col('total', 'Value incl. VAT', R), col('vat', 'VAT', R)],
        rows: (v.schedule || []).map((r, i) => ({ i: String(i + 1), ...r, total: $(r.total), vat: $(r.vat) })).concat([{ i: '', tin: '', supplier: 'TOTAL', no: '', date: '', total: $((v.schedule || []).reduce((s, x) => s + x.total, 0)), vat: $(L[7]), _tone: 'highlight' }]),
        note: 'FRCS does not allow input tax claims without this schedule. Invoices without the supplier TIN are left out.' },
      { title: 'Checks before lodging', columns: [col('l', 'Result'), col('t', 'Check')], rows: checkRows(v.checks) },
    ],
  };
}
// Just the Input Schedule (for Excel / CSV upload).
export function vatInputScheduleReport(ym, { version } = {}) {
  const v = vatData(ym, version);
  return {
    kind: 'vat_input_schedule', title: 'VAT Input Schedule', fileName: `VAT-Input-Schedule-${ym}`, subtitle: `${employerDetails().name} · ${monthName(ym)}`,
    info: [['TIN', employerDetails().tin || '—'], ['Taxable period', monthName(ym)], ['Generated', stamp()]],
    summary: [{ label: 'Invoices', value: String((v.schedule || []).length) }, { label: 'Input VAT', value: $(v.lines[7]) }],
    sections: [{ title: 'Input schedule', columns: [col('tin', 'Supplier TIN'), col('supplier', 'Supplier name'), col('no', 'Tax invoice no.'), col('date', 'Invoice date'), col('total', 'Value incl. VAT', R), col('vat', 'VAT', R)],
      rows: (v.schedule || []).map((r) => ({ ...r, total: Number(r.total).toFixed(2), vat: Number(r.vat).toFixed(2) })) }],
  };
}

function fnpfData(ym, version) {
  if (version) {
    const v = RT.versions('fnpf', ym).find((x) => x.version === Number(version));
    if (v) return { ...RT.fnpfSchedule(ym), ...v.data, lodged: v };
  }
  return RT.fnpfSchedule(ym);
}
export function fnpfScheduleReport(ym, { version } = {}) {
  const s = fnpfData(ym, version);
  const e = s.employer;
  return {
    kind: 'fnpf_cs', title: 'Contribution Schedule Form', fileName: `FNPF-Contribution-Schedule-${ym}${s.lodged ? `-v${s.lodged.version}` : ''}`, subtitle: `Fiji National Provident Fund · ${e.name} · ${monthName(ym)}`,
    info: [['Employer Reference No.', e.refNo || '— (not set)'], ['Employer Name', e.name], ['Employer Trading Name', e.tradingName || e.name], ['Postal Address', e.postal || '—'], ['City', e.city || '—'],
      ['Contribution Type', s.contributionType || 'Normal'], ['Contribution Month and Year', monthName(ym)], ['Wages Month and Year', monthName(ym)], ['CS Due Date', s.csDue], ['Payment due', s.payDue],
      ['Status', s.lodged ? `Lodged ${s.lodged.lodged_at} (version ${s.lodged.version}, ref ${s.lodged.lodge_ref || '—'})` : 'Draft – not lodged'], ['Generated', stamp()]],
    summary: [{ label: 'Total Contributions', value: $(s.totals.contributions) }, { label: 'Total Wages', value: $(s.totals.wages) }, { label: 'Total no. of Employees', value: String(s.totals.employees) }],
    sections: [
      { title: 'Members', columns: [col('i', 'Line No.'), col('memberNo', 'Member Number'), col('first', "First Name"), col('middle', 'Middle Name'), col('last', 'Last Name'), col('tin', 'Tax ID No.'),
        col('compulsory', 'Compulsory Contribution', R), col('employerAdditional', 'Employer Additional', R), col('memberAdditional', 'Member Additional', R), col('total', 'Total Contribution', R),
        col('gross', 'Monthly Gross Salary', R), col('status', 'Employment Status'), col('statusDate', 'Status Date'), col('frequency', 'Payment Frequency')],
        rows: s.rows.map((r, i) => ({ i: String(i + 1), memberNo: r.memberNo || 'MISSING', first: r.first, middle: r.middle, last: r.last, tin: r.tin, compulsory: $(r.compulsory), employerAdditional: $(r.employerAdditional),
          memberAdditional: $(r.memberAdditional), total: $(r.total), gross: $(r.gross), status: `${r.status} ${r.statusText}`, statusDate: r.statusDate || '', frequency: `${r.frequency} ${['', 'Weekly', 'Fortnightly', 'Monthly'][r.frequency] || ''}`, _tone: r.memberNo ? null : 'bad' }))
          .concat([{ i: '', memberNo: '', first: 'TOTAL', middle: '', last: '', tin: '', compulsory: $(s.totals.compulsory), employerAdditional: $(s.totals.employerAdditional), memberAdditional: $(s.totals.memberAdditional), total: $(s.totals.contributions), gross: $(s.totals.wages), status: '', statusDate: '', frequency: '', _tone: 'highlight' }]),
        note: 'Employment Status: 1 = Active, 2 = On leave, 3 = Terminated. Payment Frequency: 1 = Weekly, 2 = Fortnightly, 3 = Monthly. Compulsory = employee 8% + the employer rate set by FNPF.' },
      { title: 'Employer representative', columns: [col('k', ''), col('v', '')], rows: [{ k: 'Employer Rep. Name', v: '' }, { k: 'Designation', v: '' }, { k: 'Employer Rep. Signature', v: '' }, { k: 'Date', v: '' }] },
      { title: 'Checks before lodging', columns: [col('l', 'Result'), col('t', 'Check')], rows: checkRows(s.checks) },
    ],
  };
}
