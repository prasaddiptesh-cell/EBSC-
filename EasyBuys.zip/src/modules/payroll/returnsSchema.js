// v3.9 Returns tables (see returns.js): one file row per return and month (typed-in lines, payment links) and every
// lodged version (frozen copy; an amendment supersedes it, nothing is deleted).
export const RETURNS_SQL = `
CREATE TABLE IF NOT EXISTS tax_returns (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  period TEXT NOT NULL,
  adjust TEXT,
  pay_link TEXT, pay_via TEXT, pay_method TEXT, pay_ref TEXT, paid_date TEXT, paid_amount REAL,
  cheque_uid TEXT,
  penalty_link TEXT, penalty_amount REAL,
  refund_link TEXT, refund_amount REAL, refund_date TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS tax_return_versions (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  period TEXT NOT NULL,
  version INTEGER NOT NULL,
  amount REAL,
  data TEXT,
  lodged_at TEXT, lodged_by_name TEXT, lodge_ref TEXT, note TEXT,
  status TEXT NOT NULL DEFAULT 'lodged',
  superseded_at TEXT, superseded_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_trv_kp ON tax_return_versions(kind, period);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const RETURNS_SYNC = {
  tax_returns: SYNC('uid', 'Payroll', ['uid', 'kind', 'period', 'adjust', 'pay_link', 'pay_via', 'pay_method', 'pay_ref', 'paid_date', 'paid_amount', 'cheque_uid', 'penalty_link', 'penalty_amount',
    'refund_link', 'refund_amount', 'refund_date', 'notes', 'status']),
  tax_return_versions: SYNC('uid', 'Payroll', ['uid', 'kind', 'period', 'version', 'amount', 'data', 'lodged_at', 'lodged_by_name', 'lodge_ref', 'note', 'status', 'superseded_at', 'superseded_reason']),
};
