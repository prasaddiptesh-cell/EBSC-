// Payroll tables: pay details per person, advances and staff loans, weekly pay runs and their lines.
export const PAYROLL_SQL = `
CREATE TABLE IF NOT EXISTS pay_profiles (
  user_uid TEXT PRIMARY KEY,
  pay_type TEXT NOT NULL DEFAULT 'hourly' CHECK (pay_type IN ('hourly','salary')),
  rate REAL NOT NULL DEFAULT 0,
  weekly_salary REAL NOT NULL DEFAULT 0,
  normal_hours REAL,
  job_title TEXT,
  wage_category TEXT,
  fnpf_no TEXT,
  tin TEXT,
  tax_status TEXT NOT NULL DEFAULT 'resident',
  fnpf_member INTEGER NOT NULL DEFAULT 1,
  fnpf_extra_pct REAL NOT NULL DEFAULT 0,
  pay_method TEXT NOT NULL DEFAULT 'cash',
  bank_name TEXT, bank_account TEXT,
  allowances TEXT,
  deductions TEXT,
  start_date TEXT, end_date TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS staff_debts (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT,
  kind TEXT NOT NULL CHECK (kind IN ('advance','loan')),
  debt_date TEXT NOT NULL,
  amount REAL NOT NULL,
  repay_per_pay REAL NOT NULL,
  reason TEXT,
  shop_code TEXT,
  paid_from TEXT,
  given_by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  void_reason TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

-- Money a staff member owes the business and repays from pay: till shortages, breakages, other.
CREATE TABLE IF NOT EXISTS staff_charges (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT,
  charge_date TEXT NOT NULL,
  amount REAL NOT NULL,
  per_pay REAL NOT NULL,
  reason TEXT,
  source TEXT NOT NULL DEFAULT 'other',
  ref_uid TEXT,
  shop_code TEXT,
  by_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS pay_runs (
  uid TEXT PRIMARY KEY,
  week_start TEXT NOT NULL,
  week_end TEXT NOT NULL,
  pay_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','final','void')),
  totals TEXT,
  notes TEXT,
  created_by_name TEXT, created_at TEXT,
  finalised_by_name TEXT, finalised_at TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS pay_lines (
  uid TEXT PRIMARY KEY,
  run_uid TEXT NOT NULL,
  user_uid TEXT NOT NULL,
  name TEXT NOT NULL,
  employee_no TEXT,
  shop_code TEXT,
  pay_type TEXT,
  rate REAL,
  hours TEXT,
  earnings TEXT,
  allowances TEXT,
  adjustments TEXT,
  overrides TEXT,
  gross REAL NOT NULL DEFAULT 0,
  taxable REAL NOT NULL DEFAULT 0,
  fnpf_base REAL NOT NULL DEFAULT 0,
  fnpf_employee REAL NOT NULL DEFAULT 0,
  fnpf_employer REAL NOT NULL DEFAULT 0,
  paye REAL NOT NULL DEFAULT 0,
  deductions TEXT,
  total_deductions REAL NOT NULL DEFAULT 0,
  net REAL NOT NULL DEFAULT 0,
  pay_method TEXT,
  warnings TEXT,
  edited_by_name TEXT,
  edit_reason TEXT,
  include INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pl_run ON pay_lines(run_uid);
CREATE INDEX IF NOT EXISTS idx_pl_user ON pay_lines(user_uid);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const PAYROLL_SYNC = {
  pay_profiles: SYNC('user_uid', 'Payroll', ['user_uid', 'pay_type', 'rate', 'weekly_salary', 'normal_hours', 'job_title', 'wage_category', 'fnpf_no', 'tin', 'tax_status', 'fnpf_member', 'fnpf_extra_pct',
    'pay_method', 'bank_name', 'bank_account', 'allowances', 'deductions', 'start_date', 'end_date', 'active', 'notes']),
  staff_debts: SYNC('uid', 'Payroll', ['uid', 'user_uid', 'name', 'kind', 'debt_date', 'amount', 'repay_per_pay', 'reason', 'shop_code', 'paid_from', 'given_by_name', 'status', 'void_reason', 'created_at']),
  staff_charges: SYNC('uid', 'Payroll', ['uid', 'user_uid', 'name', 'charge_date', 'amount', 'per_pay', 'reason', 'source', 'ref_uid', 'shop_code', 'by_name', 'status', 'void_reason', 'created_at', 'photo_urls']),
  pay_runs: SYNC('uid', 'Payroll', ['uid', 'week_start', 'week_end', 'pay_date', 'status', 'totals', 'notes', 'created_by_name', 'created_at', 'finalised_by_name', 'finalised_at', 'void_reason']),
  pay_lines: SYNC('uid', 'Payroll', ['uid', 'run_uid', 'user_uid', 'name', 'employee_no', 'shop_code', 'pay_type', 'rate', 'hours', 'earnings', 'allowances', 'adjustments', 'overrides', 'gross', 'taxable',
    'fnpf_base', 'fnpf_employee', 'fnpf_employer', 'paye', 'deductions', 'total_deductions', 'net', 'pay_method', 'warnings', 'edited_by_name', 'edit_reason', 'include']),
};
