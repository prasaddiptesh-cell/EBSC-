// Payroll v3.5 (B5): pay slip release after the employee signs, tax & statutory calendar with two proofs per period
// (lodgement + payment), and new columns for flexible pay cycles, extra pay runs, reopening a final run and the
// per-person FNPF / PAYE rules.
export const PAY35_SQL = `
-- One row per person per pay run: released (signed, or owner/admin override), sent by email / Viber, printed.
CREATE TABLE IF NOT EXISTS pay_slip_status (
  uid TEXT PRIMARY KEY,
  run_uid TEXT NOT NULL,
  user_uid TEXT NOT NULL,
  name TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  released INTEGER NOT NULL DEFAULT 0,
  released_at TEXT,
  released_by_name TEXT,
  override_reason TEXT,
  emailed_to TEXT, emailed_at TEXT,
  viber_at TEXT,
  printed_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pss_run ON pay_slip_status(run_uid);

-- Tax & statutory: one row per obligation and period (VAT 2026-09, FNPF 2026-09, pay day report 2026-10-10 …).
CREATE TABLE IF NOT EXISTS tax_proofs (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  period TEXT NOT NULL,
  due_date TEXT,
  amount REAL,
  lodged_at TEXT, lodged_by_name TEXT, lodge_ref TEXT, lodge_photos TEXT, lodge_note TEXT,
  paid_at TEXT, paid_by_name TEXT, paid_amount REAL, pay_ref TEXT, pay_photos TEXT, pay_note TEXT,
  not_needed INTEGER NOT NULL DEFAULT 0,
  override_by_name TEXT, override_at TEXT, override_reason TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_taxp_kind ON tax_proofs(kind, period);
`;

// New columns on the payroll tables (added on start-up by src/db/columns.js).
export const PAY35_COLUMNS = {
  pay_runs: [['run_kind', 'TEXT'], ['label', 'TEXT'], ['frequency', 'TEXT'], ['version', 'INTEGER'], ['reopened_by_name', 'TEXT'], ['reopened_at', 'TEXT'], ['reopen_reason', 'TEXT']],
  pay_lines: [['counted', 'TEXT'], ['undecided', 'TEXT']],
  pay_profiles: [['fnpf_rule', 'TEXT'], ['paye_rule', 'TEXT'], ['email', 'TEXT'], ['viber', 'TEXT'], ['family_split', 'TEXT'], ['day_rate', 'REAL']],
};
// Synced copies of the new columns (added to the payroll sync lists).
export const PAY35_SYNC_COLS = {
  pay_runs: ['run_kind', 'label', 'frequency', 'version', 'reopened_by_name', 'reopened_at', 'reopen_reason'],
  pay_lines: ['counted', 'undecided'],
  pay_profiles: ['fnpf_rule', 'paye_rule', 'email', 'viber', 'family_split', 'day_rate'],
};

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const PAY35_SYNC = {
  pay_slip_status: SYNC('uid', 'Payroll', ['uid', 'run_uid', 'user_uid', 'name', 'version', 'released', 'released_at', 'released_by_name', 'override_reason', 'emailed_to', 'emailed_at', 'viber_at', 'printed_at']),
  tax_proofs: SYNC('uid', 'Payroll', ['uid', 'kind', 'period', 'due_date', 'amount', 'lodged_at', 'lodged_by_name', 'lodge_ref', 'lodge_photos', 'lodge_note', 'paid_at', 'paid_by_name', 'paid_amount',
    'pay_ref', 'pay_photos', 'pay_note', 'not_needed', 'override_by_name', 'override_at', 'override_reason', 'status']),
};
