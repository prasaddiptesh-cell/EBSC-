// v3.6 "Start a pay run" in steps: 1 dates (pay period + pay day, shown big, confirm), 2 who is paid (ticked, hours,
// quick buttons, warning when leaving out someone with hours). Steps 3 and 4 happen on the pay run screen.
import React, { useState, useMemo } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { DateField, Hint } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { fmtDate } from '../../../services/dates.js';
import * as S from '../payRunSteps.js';

const TONE = { bad: 'danger', warn: 'warn' };
export function NewPayRunScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const [date, setDate] = useState(addDays(dateStr(), -1));
  const [payDate, setPayDate] = useState('');
  const [step, setStep] = useState(1);
  const plan = useMemo(() => { try { return S.planRun(date, { payDate: payDate || undefined }); } catch (e) { return { error: e.message, people: [], warnings: [] }; } }, [date, payDate]);
  const [picked, setPicked] = useState(null);
  const sel = picked || new Set(plan.people.filter((p) => !p.alreadyPaid).map((p) => p.userUid));
  const flip = (uid) => { const n = new Set(sel); if (n.has(uid)) n.delete(uid); else n.add(uid); setPicked(n); };
  const only = (f) => setPicked(new Set(plan.people.filter((p) => !p.alreadyPaid && f(p)).map((p) => p.userUid)));
  const shops = Array.from(new Set(plan.people.map((p) => p.shop).filter(Boolean)));
  const start = async () => {
    const leftWithHours = plan.people.filter((p) => !p.alreadyPaid && !sel.has(p.userUid) && p.hours > 0);
    if (leftWithHours.length) {
      const ok = await ui.confirm({ title: 'Leave them out?', message: `${leftWithHours.map((p) => `${p.name} has ${p.hours} hours`).join('\n')}\n\nThey show as "Not paid yet for this period" and can be paid later – never twice.`, confirmText: 'Leave them out' });
      if (!ok) return;
    }
    try { const r = S.startRunWithPeople(user, { date, payDate: plan.payDate, people: Array.from(sel) }); nav.replace('PayRun', { uid: r.uid }); } catch (e) { ui.error(e); }
  };
  if (plan.error) return <Screen title="Start a pay run"><Banner tone="danger" message={plan.error} /></Screen>;
  return (
    <Screen title="Start a pay run" subtitle={step === 1 ? 'Step 1 of 2 – the dates' : 'Step 2 of 2 – who is paid'}>
      <Card>
        <Text testID="npr-period" style={{ fontSize: 22, fontWeight: '900', color: C.text }}>Pay period: {fmtDate(plan.from)} – {fmtDate(plan.to)}</Text>
        <Text testID="npr-paydate" style={{ fontSize: 22, fontWeight: '900', color: C.success }}>Paid on: {fmtDate(plan.payDate)}</Text>
      </Card>
      {plan.warnings.map((w) => <Banner key={w.text} tone={TONE[w.tone] || 'warn'} message={w.text} />)}
      {step === 1 ? (
        <>
          <DateField testID="npr-date" label="Any day in the period to pay" value={date} onChange={(v) => { setDate(v); setPicked(null); }} />
          <DateField testID="npr-pay" label="Pay day (if different from the usual)" value={payDate || plan.payDate} onChange={setPayDate} />
          <Hint>The period follows the pay cycle (Payroll › Pay cycle & pay day). Check both dates, then confirm.</Hint>
          <Btn testID="npr-confirm" title="Confirm dates" icon="✅" variant="success" disabled={!!plan.existing} onPress={() => setStep(2)} />
          {plan.existing ? <Btn title="Open the pay run for this period" size="md" variant="info" onPress={() => nav.replace('PayRun', { uid: plan.existing.uid })} /> : null}
        </>
      ) : (
        <>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn testID="npr-all" title="All" size="sm" variant="secondary" onPress={() => only(() => true)} />
            <Btn testID="npr-none" title="None" size="sm" variant="secondary" onPress={() => setPicked(new Set())} />
            <Btn testID="npr-hours" title="Only people with hours" size="sm" variant="secondary" onPress={() => only((p) => p.hours > 0 || p.payType === 'salary')} />
            {shops.map((s) => <Btn key={s} testID={`npr-shop-${s}`} title={`Only ${s}`} size="sm" variant="secondary" onPress={() => only((p) => p.shop === s)} />)}
          </View>
          <Section title={`${sel.size} of ${plan.people.filter((p) => !p.alreadyPaid).length} ticked`}>
            {plan.people.map((p) => {
              const on = sel.has(p.userUid);
              return (
                <Pressable key={p.userUid} testID={`npr-p-${p.employeeNo || p.name}`} disabled={p.alreadyPaid} onPress={() => flip(p.userUid)}
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border, opacity: p.alreadyPaid ? 0.5 : 1 }}>
                  <Text style={{ fontSize: 24, color: on ? C.success : C.sub }}>{p.alreadyPaid ? '✓' : on ? '☑' : '☐'}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 18, fontWeight: '700', color: C.text }}>{p.name}</Text>
                    <Text style={{ fontSize: 14, color: C.sub }}>{p.shop || '—'} · {p.payType === 'salary' ? 'salary' : `${p.hours} hours`}{p.alreadyPaid ? ' · already paid for this period' : ''}</Text>
                  </View>
                  {!on && !p.alreadyPaid && p.hours > 0 ? <Text style={{ color: C.warn, fontWeight: '800' }}>has hours</Text> : null}
                </Pressable>
              );
            })}
          </Section>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Btn title="‹ Dates" size="md" variant="secondary" onPress={() => setStep(1)} />
            <Btn testID="npr-start" title={`Start the pay run (${sel.size})`} icon="💰" variant="success" style={{ flexGrow: 1 }} onPress={start} />
          </View>
        </>
      )}
    </Screen>
  );
}
