// Payroll v3.5 screens: pay cycle & pay day, extra pay run, pay sign-off (list, locked employee view, settings),
// FNPF / PAYE per person, tax & statutory calendar (list, one item with its two proofs, settings) and filing.
import React, { useEffect, useState } from 'react';
import { View, BackHandler } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, PhotoPicker, Table, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain, ReasonButton, Actions, Action } from '../../../ui/kit.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { SignaturePad } from '../../../ui/signature.js';
import { dateStr, addDays } from '../../../services/core.js';
import { ROLES, ROLE_LABEL, actsAsOwner } from '../../../services/access.js';
import { adminPinOk } from '../../../services/health.js';
import { listUsers } from '../../../services/catalog.js';
import * as P from '../service.js';
import * as CY from '../cycle.js';
import * as SO from '../signoff.js';
import * as TX from '../taxCalendar.js';
import * as FL from '../filing.js';
import { payslipSections, payslipReport, amountText } from '../payslip.js';
import { sharePayslipViber, printPayslip, pickFilingTemplate, shareFilingTable } from '../../../platform/payShare.js';
import { db } from '../../../db/connection.js';
import { SafeModal } from '../../../ui/safeModal.js';

const { $ } = P;
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const lastYm = () => { const d = dateStr(); const [y, m] = d.split('-').map(Number); return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`; };
const TONE_COLOR = { highlight: C.danger, good: C.success, warn: C.warn };

// ---------------------------------------------------------------- the payslip (always the full, exact payslip)
export function PayslipView({ lineUid, testID = 'payslip' }) {
  const secs = payslipSections(lineUid);
  if (!secs.length) return <Banner tone="warn" message="Payslip not found." />;
  return (
    <Card>
      <View testID={testID} style={{ gap: 2 }}>
        {secs.map((s) => (
          <View key={s.key} testID={`${testID}-${s.key}`} style={{ marginBottom: 8 }}>
            <Text style={{ fontSize: 15, fontWeight: '800', color: s.key === 'correction' ? C.warn : C.info, marginBottom: 2 }}>{s.title.toUpperCase()}</Text>
            {s.lines.map((l) => (
              <Row key={l.key} label={`${l.label}${l.detail ? ` (${l.detail})` : ''}`} value={l.amount !== undefined ? amountText(l.amount) : String(l.value || '')} bold={!!l.bold} color={TONE_COLOR[l.tone]} />
            ))}
          </View>
        ))}
      </View>
    </Card>
  );
}

// ---------------------------------------------------------------- pay cycle & pay day (admin)
export function PayCycleScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const c0 = CY.payCycle();
  const [f, setF] = useState(() => ({ ...c0, startDay: c0.startDay, payDayAfter: String(c0.payDayAfter), monthStartDay: String(c0.monthStartDay || 1) }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  let words = '';
  try { words = CY.cycleWords({ ...f, startDay: Number(f.startDay), payDayAfter: Number(f.payDayAfter) || 0, monthStartDay: Number(f.monthStartDay) || 1 }); } catch (e) { words = e.message; }
  return (
    <Screen title="Pay cycle & pay day" subtitle="For every device"
      footer={can('payroll_setup') ? <Btn testID="cyc-save" title="Save" icon="💾" variant="success" onPress={() => act(() => CY.savePayCycle(user, f), 'Pay cycle saved')} /> : null}>
      <Explain>How often staff are paid and which days a pay run covers. Easy Buys: Saturday to Friday, paid on the Saturday after (that Saturday already counts for the next week). Changing it only changes new pay runs.</Explain>
      <Card>
        <Label>How often</Label>
        <Chips testIDPrefix="cyc-freq" value={f.frequency} onChange={set('frequency')} options={Object.entries(CY.FREQUENCIES).map(([value, label]) => ({ value, label }))} />
        {f.frequency !== 'monthly' ? (
          <Select testID="cyc-start" label="The pay week starts on" value={Number(f.startDay)} onChange={(v) => set('startDay')(Number(v))} options={CY.WEEKDAY_NAMES.map((n, i) => ({ value: i, label: n }))} />
        ) : <Field testID="cyc-monthday" label="A pay month starts on day (1 = calendar month)" value={f.monthStartDay} onChangeText={set('monthStartDay')} keyboardType="number-pad" />}
        {f.frequency === 'fortnightly' ? <DateField farDays={false} label="A day on which a fortnight starts (keeps the fortnights in step)" value={f.anchor} onChange={set('anchor')} /> : null}
        <Field testID="cyc-payday" label="Pay day: days after the period ends (0 = the last day)" value={f.payDayAfter} onChangeText={set('payDayAfter')} keyboardType="number-pad" />
      </Card>
      <Banner testID="cyc-words" tone="info" title="This means" message={words} />
    </Screen>
  );
}

// ---------------------------------------------------------------- extra pay run (bonus, back pay)
export function ExtraPayRunScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  const people = P.listProfiles().filter((p) => p.hasProfile && p.active !== 0);
  const [f, setF] = useState({ label: 'Bonus', kind: 'bonus', payDate: dateStr(), from: '', to: '', amounts: {}, taxable: true, takeDebts: false });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const total = Object.values(f.amounts).reduce((s, v) => s + (Number(v) || 0), 0);
  const make = () => {
    try {
      const r = P.createExtraRun(user, { label: f.label, payDate: f.payDate, from: f.from || f.payDate, to: f.to || f.payDate, takeDebts: f.takeDebts,
        people: people.map((p) => ({ userUid: p.user_uid, amount: f.amounts[p.user_uid], kind: f.kind, label: f.label, taxable: f.taxable })) });
      nav.replace('PayRun', { uid: r.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Extra pay run" subtitle="A one-off bonus or back pay" footer={<Btn testID="xr-make" title={`Start the extra pay run · ${$(total)}`} icon="🎁" variant="success" onPress={make} />}>
      <Explain>An extra pay run pays only the amounts you type here – no hours. PAYE is worked out on top of each person's normal pay; FNPF follows their FNPF rule. It is checked and made final like any pay run, and each person signs their payslip.</Explain>
      <Card>
        <Field testID="xr-label" label="What is it for" value={f.label} onChangeText={set('label')} />
        <Chips testIDPrefix="xr-kind" value={f.kind} onChange={set('kind')} options={[{ value: 'bonus', label: 'Bonus' }, { value: 'backpay', label: 'Back pay' }, { value: 'allowance', label: 'Other extra pay' }]} />
        <DateField label="Pay day" value={f.payDate} onChange={set('payDate')} />
        <DateField farDays={false} label="For the days from (optional)" value={f.from} onChange={set('from')} />
        <DateField farDays={false} label="to (optional)" value={f.to} onChange={set('to')} />
        <Label>Taxed (PAYE)</Label>
        <Chips value={f.taxable} onChange={set('taxable')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'Not taxed' }]} />
        <Label>Also take advances, loans and staff charges from it</Label>
        <Chips value={f.takeDebts} onChange={set('takeDebts')} options={[{ value: false, label: 'No' }, { value: true, label: 'Yes' }]} />
      </Card>
      <Section title="Who gets how much">
        {people.map((p) => (
          <View key={p.user_uid} style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8 }}>
            <Text style={{ flex: 2, fontSize: 17, color: C.text, paddingBottom: 16 }}>{p.name}</Text>
            <View style={{ flex: 1, minWidth: 110 }}><MoneyField testID={`xr-amt-${p.employee_no || p.name}`} label="Amount" value={f.amounts[p.user_uid] || ''} onChange={(v) => setF((o) => ({ ...o, amounts: { ...o.amounts, [p.user_uid]: v } }))} /></View>
          </View>
        ))}
        {!people.length ? <Hint>No one has pay details yet.</Hint> : null}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- pay sign-off
export function PaySignOffScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const [runUid, setRunUid] = useState(params.runUid || null);
  const [answer, setAnswer] = useState('');
  if (!SO.canRunSignoff(user)) return <Screen title="Pay sign-off"><Banner tone="warn" message="Your role cannot run the pay sign-off. The admin chooses who can (Payroll › Pay sign-off settings)." /></Screen>;
  if (!runUid) {
    const list = SO.runsToSign();
    return (
      <Screen title="Pay sign-off" subtitle="Each person signs their payslip – then their pay is released">
        <Explain>On pay day open the pay run here and hand the tablet to each person. They see their full payslip on a locked screen and either sign it or tap "Something is wrong". Pay is released only when signed (the owner or admin can release it anyway – that is recorded). The screen can only be left with the admin's PIN.</Explain>
        {isTop(user) ? <Btn testID="pso-settings" title="Pay sign-off settings" icon="⚙️" size="md" variant="secondary" onPress={() => nav.push('PaySignSettings')} /> : null}
        {list.map((x) => (
          <ListItem key={x.run.uid} testID={`pso-run-${x.run.pay_date}`} onPress={() => setRunUid(x.run.uid)} title={`${x.run.run_kind === 'extra' ? `${x.run.label || 'Extra pay'} · ` : ''}Paid ${x.run.pay_date}`}
            sub={`${x.run.week_start} – ${x.run.week_end} · ${x.signed} of ${x.total} signed${x.queries ? ` · ${x.queries} "something is wrong"` : ''}`} badge={x.waiting ? `${x.waiting} to sign` : '✓'} badgeColor={x.waiting ? C.warn : C.success} />
        ))}
        {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No final pay runs yet.</Text> : null}
      </Screen>
    );
  }
  const run = P.getRun(runUid);
  if (!run) return <Screen title="Pay sign-off"><Text>Not found.</Text></Screen>;
  const slips = SO.runSlips(runUid);
  const tone = { to_sign: C.warn, signed: C.success, query: C.danger, released: C.info };
  return (
    <Screen title={`Pay sign-off · paid ${run.pay_date}`} subtitle={`${slips.filter((s) => s.signed).length} of ${slips.length} signed`} onBack={params.runUid ? undefined : () => setRunUid(null)}>
      {run.status !== 'final' ? <Banner tone="warn" message="This pay run is not final – staff sign once it is final." /> : null}
      {slips.map((s) => (
        <View key={s.line.uid} style={{ gap: 6 }}>
          <ListItem testID={`pso-${s.line.employee_no || s.line.name}`} title={s.line.name} sub={`${SO.SLIP_STATE[s.state]}${s.signoff && s.signoff.status === 'signed' ? ` · ${String(s.signoff.signed_at).slice(0, 16)}` : ''}`}
            right={$(s.line.net)} rightSub={s.line.pay_method === 'bank' ? 'bank' : 'cash'} badge={s.signed ? '✓' : s.state === 'query' ? '!' : s.released ? 'released' : 'sign'} badgeColor={tone[s.state]}
            onPress={run.status === 'final' ? () => nav.push('PaySignLocked', { runUid, userUid: s.line.user_uid }) : undefined} />
          {s.state === 'query' ? (
            <Card tone="warn">
              <Text style={{ fontSize: 16, color: C.text }}>"{s.signoff.note}"</Text>
              {s.signoff.answer ? <Text style={{ fontSize: 15, color: C.sub }}>Answer from {s.signoff.answered_by_name}: {s.signoff.answer}</Text> : (
                <View style={{ gap: 6 }}>
                  <Field testID={`pso-answer-${s.line.employee_no || s.line.name}`} label="Answer" value={answer} onChangeText={setAnswer} multiline />
                  <Btn title="Send the answer" size="sm" variant="info" onPress={() => { if (act(() => require('../../people/service.js').answerQuery(user, `${runUid}|${s.line.user_uid}`, answer), 'Answered')) setAnswer(''); }} />
                </View>
              )}
            </Card>
          ) : null}
          {!s.released && isTop(user) ? <ReasonButton testID={`pso-release-${s.line.employee_no || s.line.name}`} title="Release without signature" prompt="Why is the pay released without a signature?" confirm="Release" variant="warn" size="sm"
            onDo={(why) => act(() => SO.releaseWithoutSignature(user, { runUid, userUid: s.line.user_uid, reason: why }), 'Released – recorded')} /> : null}
        </View>
      ))}
    </Screen>
  );
}

// The locked employee view: only this person's payslip; leaving needs the admin's PIN.
export function PaySignLockedScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const act = useAct();
  const [mode, setMode] = useState('signed');
  const [sig, setSig] = useState(null);
  const [note, setNote] = useState('');
  const [after, setAfter] = useState(null);
  const [askPin, setAskPin] = useState(false);
  const [pin, setPin] = useState('');
  const locked = !!(params.runUid && params.userUid);
  useEffect(() => {
    if (!locked) return undefined;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => { setAskPin(true); return true; });
    return () => sub.remove();
  }, [locked]);
  if (!locked) return <Screen title="Payslip"><Banner tone="info" message="Open a pay run in Payroll › Pay sign-off and tap a person." /></Screen>;
  const line = db().get('SELECT * FROM pay_lines WHERE run_uid = ? AND user_uid = ? AND include = 1', [params.runUid, params.userUid]);
  if (!line) return <Screen title="Payslip"><Text>Not found.</Text></Screen>;
  const st = SO.slipState(params.runUid, params.userUid);
  const d = after || (st.signed ? SO.deliveryFor(params.runUid, params.userUid) : null);
  const unlock = () => {
    const ok = adminPinOk(pin);
    setPin('');
    if (ok) { setAskPin(false); nav.pop(); } else ui.alert({ title: 'Wrong PIN', message: 'Only the owner or admin PIN opens this screen.', tone: 'danger' });
  };
  const sign = () => {
    const r = act(() => SO.signPayslip(user, { runUid: params.runUid, userUid: params.userUid, signature: sig }), 'Signed – thank you. Your pay is released.');
    if (r) { setSig(null); const a = SO.afterSigned(user, params.runUid, params.userUid); setAfter(a); if (a.emailed) ui.toast(`Signed – the payslip will be emailed to ${a.emailed}`); }
  };
  const query = () => { if (act(() => SO.signPayslip(user, { runUid: params.runUid, userUid: params.userUid, signature: sig, status: 'query', note }), 'Sent to the manager')) { setSig(null); setNote(''); setMode('signed'); } };
  const viber = async () => { try { await sharePayslipViber(SO.viberShare(params.runUid, params.userUid)); SO.markViberShared(user, params.runUid, params.userUid); } catch (e) { ui.error(e); } };
  const print = async () => { try { await printPayslip(payslipReport(line.uid)); SO.markPrinted(user, params.runUid, params.userUid); } catch (e) { ui.error(e); } };
  return (
    <Screen title={`Payslip – ${line.name}`} subtitle="Check every line, then sign" hideUser onBack={() => setAskPin(true)}>
      <PayslipView lineUid={line.uid} testID="psl" />
      {st.signed ? <Banner testID="psl-signed" tone="success" title="Signed – your pay is released" message={String(st.signoff.signed_at || '').slice(0, 16)} /> : null}
      {st.state === 'query' ? <Banner tone="warn" title="You said something is wrong" message={`${st.signoff.note}${st.signoff.answer ? `\nAnswer: ${st.signoff.answer}` : '\nThe manager will look at it.'}`} /> : null}
      {!st.signed ? (
        <Card>
          <Chips value={mode} onChange={setMode} testIDPrefix="psl-mode" options={[{ value: 'signed', label: '✓ My payslip is right' }, { value: 'query', label: '✗ Something is wrong' }]} />
          {mode === 'signed' ? (
            <>
              <SignaturePad value={sig} onChange={setSig} testID="psl-sig" label={`${line.name}, sign here`} />
              <Btn testID="psl-sign" title="Sign" icon="✍️" variant="success" disabled={!sig} onPress={sign} />
            </>
          ) : (
            <>
              <Field testID="psl-note" label="What is wrong?" value={note} onChangeText={setNote} multiline />
              <SignaturePad value={sig} onChange={setSig} testID="psl-sig-q" label="Sign (optional)" />
              <Btn testID="psl-query" title="Send to the manager" variant="warn" onPress={query} />
            </>
          )}
        </Card>
      ) : null}
      {st.signed && d ? (
        <Card>
          <H>Your copy</H>
          {d.mode === 'off' ? <Hint>Sending payslips is switched off. You can still print it.</Hint> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {d.viber ? <Btn testID="psl-viber" title="Share on Viber" icon="💬" size="md" variant="info" style={{ flexGrow: 1 }} onPress={viber} /> : null}
            {d.email && d.mode !== 'off' ? <Btn testID="psl-email" title={d.autoEmail ? `Email again to ${d.email}` : `Email to ${d.email}`} icon="✉️" size="md" variant="secondary" style={{ flexGrow: 1 }}
              onPress={() => act(() => SO.sendPayslipEmail(user, params.runUid, params.userUid), 'Email is on its way (sent when online)')} /> : null}
            {d.print ? <Btn testID="psl-print" title="Print (optional)" icon="🖨️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={print} /> : null}
          </View>
          {!d.email && d.mode !== 'off' ? <Hint>No email address in the pay details – share it on Viber or print it.</Hint> : null}
        </Card>
      ) : null}
      <Btn testID="psl-done" title="Done – give the tablet back" icon="🔒" size="md" variant="secondary" onPress={() => setAskPin(true)} />
      <SafeModal visible={askPin} transparent animationType="fade" onRequestClose={() => setAskPin(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View testID="psl-pin-box" style={{ backgroundColor: C.card, borderRadius: 18, padding: 20, width: '100%', maxWidth: 440, gap: 10 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>Admin PIN to leave</Text>
            <Field testID="psl-pin" label="Owner or admin PIN" value={pin} onChangeText={setPin} secure keyboardType="number-pad" />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Btn title="Stay" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setPin(''); setAskPin(false); }} />
              <Btn testID="psl-unlock" title="Leave" size="md" variant="primary" style={{ flex: 1 }} onPress={unlock} />
            </View>
          </View>
        </View>
      </SafeModal>
    </Screen>
  );
}

export function PaySignSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState(() => SO.signoffRules());
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const top = isTop(user);
  return (
    <Screen title="Pay sign-off settings" footer={top ? <Btn testID="pss-save" title="Save" icon="💾" variant="success" onPress={() => act(() => SO.saveSignoffRules(user, f), 'Saved')} /> : null}>
      {!top ? <Banner tone="info" message="Only the owner or admin can change these." /> : null}
      <Card>
        <H>Who may run the pay sign-off</H>
        <Hint>The owner and admin always can.</Hint>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {ROLES.filter((r) => r !== 'owner' && r !== 'admin').map((r) => {
            const on = f.roles.includes(r);
            return <Btn key={r} testID={`pss-role-${r}`} title={`${on ? '✓ ' : ''}${ROLE_LABEL[r]}`} size="sm" variant={on ? 'info' : 'secondary'} onPress={() => set('roles')(on ? f.roles.filter((x) => x !== r) : f.roles.concat([r]))} />;
          })}
        </View>
      </Card>
      <Card>
        <H>After signing</H>
        <Chips testIDPrefix="pss-mode" value={f.sendMode} onChange={set('sendMode')} options={Object.entries(SO.SEND_MODES).map(([value, label]) => ({ value, label }))} />
        <Label>Email the payslip PDF (when the person has an address)</Label>
        <Chips value={f.email} onChange={set('email')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
        <Label>Offer one-tap Viber share</Label>
        <Chips value={f.viber} onChange={set('viber')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
        <Label>Offer printing (never required)</Label>
        <Chips value={f.print} onChange={set('print')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
        <Label>Pay is released only when signed</Label>
        <Chips value={f.mustSign} onChange={set('mustSign')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />
      </Card>
    </Screen>
  );
}

// ---------------------------------------------------------------- FNPF / PAYE for one person (owner / admin)
function RuleCard({ which, rule, onChange, disabled }) {
  const set = (k) => (v) => onChange({ ...rule, [k]: v });
  return (
    <Card>
      <H>{which === 'fnpf' ? 'FNPF' : 'PAYE'}</H>
      <Chips testIDPrefix={`sr-${which}-on`} value={rule.on !== false} onChange={disabled ? () => {} : set('on')} options={[{ value: true, label: which === 'fnpf' ? 'Pays FNPF' : 'PAYE taken' }, { value: false, label: which === 'fnpf' ? 'No FNPF' : 'No PAYE' }]} />
      {rule.on !== false ? (
        <>
          <Label>On which pay</Label>
          <Chips testIDPrefix={`sr-${which}-mode`} value={rule.mode} onChange={disabled ? () => {} : set('mode')} options={Object.entries(P.RULE_MODES).map(([value, label]) => ({ value, label }))} />
          {rule.mode === 'fixed' ? <MoneyField testID={`sr-${which}-amount`} label="Amount a week" value={rule.amount} onChange={set('amount')} /> : null}
          {rule.mode === 'pct' ? <Field testID={`sr-${which}-pct`} label="% of gross pay" value={String(rule.pct)} onChangeText={set('pct')} keyboardType="decimal-pad" /> : null}
          {rule.mode === 'kinds' ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {Object.entries(P.PAY_KINDS).map(([k, label]) => {
                const on = (rule.kinds || []).includes(k);
                return <Btn key={k} testID={`sr-${which}-kind-${k}`} title={`${on ? '✓ ' : ''}${label}`} size="sm" variant={on ? 'info' : 'secondary'} onPress={() => !disabled && set('kinds')(on ? rule.kinds.filter((x) => x !== k) : (rule.kinds || []).concat([k]))} />;
              })}
            </View>
          ) : null}
        </>
      ) : null}
      <Field testID={`sr-${which}-note`} label={rule.on === false ? 'Note – why not' : 'Note (optional)'} value={rule.note || ''} onChangeText={set('note')} />
    </Card>
  );
}
export function PayStatRulesScreen({ params = {} }) {
  const { user } = useApp();
  const act = useAct();
  const people = P.listProfiles().filter((p) => p.hasProfile);
  const [who, setWho] = useState(params.userUid || (people[0] && people[0].user_uid) || '');
  const prof = who ? P.getProfile(who) : null;
  const [rules, setRules] = useState(() => ({}));
  const cur = (w) => rules[`${who}|${w}`] || P.statRuleOf(prof, w);
  const top = isTop(user);
  return (
    <Screen title="FNPF & PAYE per person" subtitle="Who pays, and on which pay">
      <Banner tone="warn" title="Check first" message={P.STAT_RULE_HINT} />
      {!top ? <Banner tone="info" message="Only the owner or admin can change these." /> : null}
      <Select testID="sr-person" label="Person" value={who} onChange={setWho} options={people.map((p) => ({ value: p.user_uid, label: p.name }))} />
      {prof ? (
        <>
          {['fnpf', 'paye'].map((w) => (
            <View key={w} style={{ gap: 6 }}>
              <RuleCard which={w} rule={cur(w)} disabled={!top} onChange={(r) => setRules((o) => ({ ...o, [`${who}|${w}`]: r }))} />
              {top ? <Btn testID={`sr-${w}-save`} title={`Save ${w === 'fnpf' ? 'FNPF' : 'PAYE'}`} icon="💾" size="md" variant="success" onPress={() => act(() => P.saveStatRule(user, who, w, cur(w)), 'Saved')} /> : null}
            </View>
          ))}
          <Hint>The payslip shows "Pay counted for FNPF" and "Pay counted for PAYE" with these rules.</Hint>
        </>
      ) : <Hint>Choose a person with pay details.</Hint>}
    </Screen>
  );
}

// ---------------------------------------------------------------- tax & statutory calendar
const FLAG_TONE = { overdue: 'danger', lodged_not_paid: 'danger', paid_not_lodged: 'danger', proof_missing: 'warn', due_soon: 'warn', upcoming: 'info', done: 'success', override: 'success' };
const FLAG_COLOR = { danger: C.danger, warn: C.warn, info: C.info, success: C.success };
export function TaxCalendarScreen() {
  const { nav, user } = useApp();
  const [all, setAll] = useState(false);
  let list = [];
  try { list = TX.taxCalendar(); } catch (e) { list = []; }
  const shown = all ? list : list.filter((i) => !i.done);
  return (
    <Screen title="Tax & statutory calendar" subtitle="Lodgement and payment proof for every period">
      <Explain>Every return and payment for VAT, FNPF, PAYE, the pay day reports, provisional tax, advance tax and company tax. Each needs two proofs: the lodgement (filed) and the payment – with a photo of each. Red: lodged but not paid, paid but not lodged, or overdue. Amber: a proof photo is missing. The month-end checklist waits until both are in.</Explain>
      <Hint>{TX.TAX_HINT}</Hint>
      {isTop(user) ? <Btn testID="tc-settings" title="Due rules, reminders, who is responsible" icon="⚙️" size="md" variant="secondary" onPress={() => nav.push('TaxCalendarSettings')} /> : null}
      <Chips testIDPrefix="tc-show" value={all} onChange={setAll} options={[{ value: false, label: 'To do' }, { value: true, label: 'All' }]} />
      {shown.map((i) => {
        const tone = FLAG_TONE[i.state] || 'info';
        return (
          <ListItem key={i.uid} testID={`tc-${i.kind}-${i.period}`} onPress={() => nav.push('TaxItem', { kind: i.kind, period: i.period })} title={i.title}
            sub={`${i.due ? `Due ${i.due}` : ''}${i.amount ? ` · ${$(i.amount)}` : ''} · ${[i.needLodge ? `lodged ${i.lodged ? (i.lodgeProof ? '✓' : '(no proof)') : '✗'}` : '', i.needPay ? `paid ${i.paid ? (i.payProof ? '✓' : '(no proof)') : '✗'}` : ''].filter(Boolean).join(' · ')}`}
            badge={i.done ? (i.override ? 'accepted' : '✓') : TX.TAX_FLAG[i.flags[0]]} badgeColor={FLAG_COLOR[tone]} tone={tone === 'danger' ? 'danger' : tone === 'warn' ? 'warn' : undefined} />
        );
      })}
      {!shown.length ? <Banner tone="success" message="Nothing to do – every lodgement and payment has its proof." /> : null}
    </Screen>
  );
}
function ProofCard({ which, item, user, act }) {
  const pay = which === 'pay';
  const [f, setF] = useState({ date: dateStr(), ref: '', amount: item.amount ? String(item.amount) : '', photos: [], note: '' });
  const [more, setMore] = useState([]);
  const ui = useUI();
  const tp = usePaper(pay ? 'proof' : 'lodgement');
  const TMAP = pay ? { amount: 'amount', ref: 'ref', date: 'date' } : { ref: 'ref', date: 'date' };
  const readAmt = tp.read ? tp.read.fields.amount : undefined;
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const r = item.row || {};
  const done = pay ? item.paid : item.lodged;
  const proof = pay ? item.payProof : item.lodgeProof;
  const needed = pay ? item.needPay : item.needLodge;
  return (
    <Card tone={!needed ? undefined : done && proof ? 'success' : done ? 'warn' : undefined}>
      <H>{pay ? '2. Payment' : '1. Lodgement (return / schedule filed)'}</H>
      {!needed ? <Text style={{ fontSize: 16, color: C.sub }}>Not needed{(pay ? r.pay_note : r.lodge_note) ? ` – ${pay ? r.pay_note : r.lodge_note}` : ''}.</Text> : null}
      {needed && done ? (
        <View>
          {pay && !r.paid_at && item.elsewhere ? <Row label="Recorded in" value={item.elsewhere.where} /> : null}
          <Row label={pay ? 'Paid' : 'Lodged'} value={pay ? (r.paid_at || (item.elsewhere && item.elsewhere.date) || '') : r.lodged_at} />
          {pay ? <Row label="Amount" value={$(r.paid_amount || (item.elsewhere && item.elsewhere.amount) || 0)} /> : null}
          <Row label="Reference" value={(pay ? r.pay_ref || (item.elsewhere && item.elsewhere.ref) : r.lodge_ref) || '—'} />
          <Row label="By" value={(pay ? r.paid_by_name : r.lodged_by_name) || '—'} />
          <Row label="Proof" value={proof ? '✓ photo / document' : 'MISSING'} color={proof ? C.success : C.warn} />
          {!proof ? (
            <View style={{ gap: 6 }}>
              <PhotoPicker testID={`ti-${which}-more`} value={more} onChange={setMore} label="Photo of the proof" />
              <Btn testID={`ti-${which}-addproof`} title="Add the proof" size="md" variant="success" onPress={() => { if (act(() => TX.addTaxProof(user, item.kind, item.period, which, more), 'Proof added')) setMore([]); }} />
            </View>
          ) : null}
          {(pay ? r.paid_at : r.lodged_at) ? <ReasonButton title="Take it back (recorded by mistake)" prompt="Why?" confirm="Take back" onDo={(w) => act(() => TX.undoTaxProof(user, item.kind, item.period, which, w), 'Taken back')} /> : null}
        </View>
      ) : null}
      {needed && !done && ['vat', 'fnpf'].includes(item.kind) ? <Hint>Lodge and pay it on the return screen (button above) – that books the payment in the accounts and the bank.</Hint> : null}
      {needed && !done && !['vat', 'fnpf'].includes(item.kind) ? (
        <View style={{ gap: 6 }}>
          <PaperPhoto pr={tp} testID={`ti-${which}-photo`} value={f.photos} onChange={set('photos')} label={pay ? 'Photo of the payment proof' : 'Photo / screenshot of the lodgement receipt'} form={f} setForm={setF} map={TMAP} soft={{ date: dateStr() }}
            labels={{ ref: 'Reference', date: pay ? 'Date paid' : 'Date lodged', amount: 'Amount paid' }} hint="Take the photo first – the reference and date fill in.">
            {pay && readAmt !== undefined && f.amount !== '' && Math.abs(readAmt - Number(f.amount)) > 0.004 ? <Banner testID={`ti-${which}-amtdiff`} tone="warn" message={`The proof shows ${$(readAmt)} but the amount below is ${$(Number(f.amount))}.`} /> : null}
          </PaperPhoto>
          <DateField farDays={false} label={pay ? 'Date paid' : 'Date lodged'} value={f.date} onChange={set('date')} />
          {pay ? <MoneyField testID={`ti-${which}-amount`} label="Amount paid" value={f.amount} onChange={set('amount')} /> : null}
          <Field testID={`ti-${which}-ref`} label={pay ? 'Bank / receipt reference' : 'Lodgement / receipt number'} value={f.ref} onChangeText={set('ref')} />
          <Field label="Note (optional)" value={f.note} onChangeText={set('note')} />
          <Btn testID={`ti-${which}-save`} title={pay ? 'Record the payment' : 'Record the lodgement'} icon="💾" variant="success" size="md"
            onPress={() => { if (!tp.okToSave(ui)) return; if (act(() => (pay ? TX.recordTaxPaymentProof(user, item.kind, item.period, { ...f, due: item.due }) : TX.recordLodgement(user, item.kind, item.period, { ...f, due: item.due, amount: item.amount })), 'Saved')) { tp.log(user, 'tax_items', `${item.kind}-${item.period}`, f, TMAP); tp.reset(); } }} />
          <ReasonButton testID={`ti-${which}-notneeded`} title={pay ? 'Nothing to pay this time' : 'Nothing to lodge this time'} prompt="Why?" confirm="OK" variant="warn" size="sm" onDo={(w) => act(() => TX.markNotNeeded(user, item.kind, item.period, which, w), 'Saved')} />
        </View>
      ) : null}
    </Card>
  );
}
export function TaxItemScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  if (!params.kind || !TX.TAX_ITEMS[params.kind]) return <Screen title="Tax item"><Banner tone="info" message="Open an item from the Tax & statutory calendar." /></Screen>;
  const item = TX.getTaxItem(params.kind, params.period);
  const hist = TX.taxItemHistory(params.kind, params.period);
  const rules = TX.taxRules()[params.kind] || {};
  const resp = rules.responsibleUid ? (listUsers().find((u) => u.uid === rules.responsibleUid) || {}).name : '';
  return (
    <Screen title={item.title} subtitle={`${TX.TAX_ITEMS[params.kind].label} · to ${TX.TAX_ITEMS[params.kind].to}`}>
      <Card>
        <Row label="Due" value={item.due || '—'} />
        {item.amount ? <Row label="Amount" value={$(item.amount)} /> : null}
        <Row label="Responsible" value={resp || 'Not set'} />
      </Card>
      {item.done ? <Banner testID="ti-done" tone="success" title={item.override ? 'Accepted by the owner / admin' : 'Both proofs are in'} message={item.override ? `${item.row.override_by_name} ${String(item.row.override_at).slice(0, 16)}${item.row.override_reason ? ` – ${item.row.override_reason}` : ''}` : ''} />
        : item.flags.map((f) => <Banner key={f} testID={`ti-flag-${f}`} tone={FLAG_TONE[f] === 'danger' ? 'danger' : FLAG_TONE[f] === 'warn' ? 'warn' : 'info'} message={TX.TAX_FLAG[f]} />)}
      {['vat', 'fnpf'].includes(params.kind) ? <Btn testID="ti-return" title={params.kind === 'vat' ? 'Open the VAT return – lodge & pay' : 'Open the FNPF schedule – lodge & pay'} icon="🧾" variant="info" size="md" onPress={() => nav.push('TaxReturn', { kind: params.kind, period: params.period })} /> : null}
      <ProofCard which="lodge" item={item} user={user} act={act} />
      <ProofCard which="pay" item={item} user={user} act={act} />
      {!item.done && isTop(user) ? <ReasonButton testID="ti-override" title="Accept without both proofs" prompt="Why (e.g. filed by the accountant)?" confirm="Accept" variant="warn" onDo={(w) => act(() => TX.overrideTaxItem(user, params.kind, params.period, w), 'Accepted – recorded')} /> : null}
      <Section title="History">
        {hist.map((h, i) => <ListItem key={i} title={h.action} sub={`${String(h.at).slice(0, 16)} · ${h.user_name}${h.reason ? ` · ${h.reason}` : ''}`} />)}
        {!hist.length ? <Text style={{ fontSize: 15, color: C.sub }}>Nothing recorded yet.</Text> : null}
      </Section>
    </Screen>
  );
}
export function TaxCalendarSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState(() => TX.taxRules());
  const people = listUsers({ includeInactive: false }).filter((u) => u.sync_status !== 'seed');
  const setK = (k, key) => (v) => setF((o) => ({ ...o, [k]: { ...o[k], [key]: v } }));
  const top = isTop(user);
  return (
    <Screen title="Tax calendar settings" subtitle="Due rules, reminders, responsible people" footer={top ? <Btn testID="tcs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => TX.saveTaxRules(user, f), 'Saved')} /> : null}>
      <Banner tone="warn" title="Check the dates" message={TX.TAX_HINT} />
      {!top ? <Banner tone="info" message="Only the owner or admin can change these." /> : null}
      <Field testID="tcs-start" label="Track from month (YYYY-MM; blank = the last 3 months)" value={f.startYm} onChangeText={(v) => setF((o) => ({ ...o, startYm: v }))} />
      {TX.TAX_KIND_ORDER.map((k) => {
        const r = f[k];
        const def = TX.TAX_ITEMS[k];
        return (
          <Card key={k}>
            <H>{def.label}</H>
            <Chips testIDPrefix={`tcs-${k}-on`} value={r.on !== false} onChange={setK(k, 'on')} options={[{ value: true, label: 'Track it' }, { value: false, label: 'Not for us' }]} />
            {r.on !== false ? (
              <>
                {def.freq === 'monthly' ? <Field testID={`tcs-${k}-day`} label="Due on day of the next month (0 = last day)" value={String(r.dueDay)} onChangeText={setK(k, 'dueDay')} keyboardType="number-pad" /> : null}
                {def.freq === 'payday' ? <Field testID={`tcs-${k}-after`} label="Due days after each pay day" value={String(r.afterDays)} onChangeText={setK(k, 'afterDays')} keyboardType="number-pad" /> : null}
                {def.freq === 'yearly' ? (
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <View style={{ flex: 1 }}><Field label="Due month (1–12) after the tax year" value={String(r.dueMonth)} onChangeText={setK(k, 'dueMonth')} keyboardType="number-pad" /></View>
                    <View style={{ flex: 1 }}><Field label="Due day" value={String(r.dueDay)} onChangeText={setK(k, 'dueDay')} keyboardType="number-pad" /></View>
                  </View>
                ) : null}
                {def.freq === 'instalments' ? <Hint>Instalments and amounts come from Accounting › Settings (last year's tax, tax year end).</Hint> : null}
                <Field testID={`tcs-${k}-lead`} label="Start reminding this many days before" value={String(r.lead)} onChangeText={setK(k, 'lead')} keyboardType="number-pad" />
                <Select testID={`tcs-${k}-who`} label="Responsible person" value={r.responsibleUid} onChange={setK(k, 'responsibleUid')} options={[{ value: '', label: 'Not set (everyone allowed)' }].concat(people.map((u) => ({ value: u.uid, label: `${u.name} (${ROLE_LABEL[u.role] || u.role})` })))} />
                <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                  <Chips value={r.lodge !== false} onChange={setK(k, 'lodge')} options={[{ value: true, label: 'Needs lodgement' }, { value: false, label: 'No lodgement' }]} />
                  <Chips value={r.pay !== false} onChange={setK(k, 'pay')} options={[{ value: true, label: 'Needs payment' }, { value: false, label: 'No payment' }]} />
                </View>
              </>
            ) : null}
          </Card>
        );
      })}
    </Screen>
  );
}

// ---------------------------------------------------------------- filing
export function FilingScreen() {
  const { nav } = useApp();
  const ui = useUI();
  const [kind, setKind] = useState('fnpf');
  const [ym, setYm] = useState(lastYm());
  const days = db().all("SELECT DISTINCT pay_date FROM pay_runs WHERE status = 'final' ORDER BY pay_date DESC LIMIT 30").map((r) => r.pay_date);
  const [payDate, setPayDate] = useState(days[0] || dateStr());
  const period = kind === 'payday' ? payDate : ym;
  const okPeriod = kind === 'payday' ? /^\d{4}-\d{2}-\d{2}$/.test(period) : /^\d{4}-\d{2}$/.test(period);
  const checks = okPeriod ? FL.filingChecks(kind, period) : [];
  const tab = okPeriod ? FL.filingTable(kind, period) : { headers: [], rows: [], template: null };
  const t = FL.filingTemplate(kind);
  const share = async (fileType) => { try { await shareFilingTable({ fileName: `${FL.FILING_KINDS[kind].title}-${period}`, headers: tab.headers, rows: tab.rows, fileType }); } catch (e) { ui.error(e); } };
  const bad = checks.filter((c) => c.level === 'bad').length;
  return (
    <Screen title="Filing (FNPF / FRCS)" subtitle="Checks first, then the file">
      <Choice35 testIDPrefix="fl-kind" value={kind} onChange={setKind} options={Object.entries(FL.FILING_KINDS).map(([value, k]) => ({ value, label: k.title }))} />
      {kind === 'payday' ? <Select testID="fl-payday" label="Pay day" value={payDate} onChange={setPayDate} options={days.map((d) => ({ value: d, label: d }))} />
        : <Field testID="fl-month" label="Month (YYYY-MM)" value={ym} onChangeText={setYm} />}
      <Card>
        <H>Checks before filing</H>
        {checks.map((c, i) => <Text key={i} testID={`fl-check-${c.level}`} style={{ fontSize: 16, color: c.level === 'bad' ? C.danger : c.level === 'warn' ? C.warn : C.success }}>{c.level === 'ok' ? '✓' : c.level === 'bad' ? '✗' : '!'} {c.text}</Text>)}
      </Card>
      <Banner tone={t ? 'success' : 'info'} title={t ? `Layout: ${t.name}` : 'No official template uploaded yet'} message={t ? `${t.headers.length} columns, ${t.fileType === 'xlsx' ? 'Excel' : 'CSV'}. Change it in Filing templates.` : "The app's own layout is used. The admin can upload the official FRCS / FNPF file in Payroll › Filing templates."} />
      {tab.rows.length ? <Table testID="fl-table" columns={tab.headers.map((h, i) => ({ key: `c${i}`, title: h, width: Math.max(90, h.length * 9 + 24) }))} rows={tab.rows.slice(0, 30).map((r) => Object.fromEntries(r.map((v, i) => [`c${i}`, typeof v === 'number' ? v.toFixed(2) : String(v)])))} /> : null}
      {bad ? <Banner tone="danger" message={`${bad} thing(s) to fix before filing.`} /> : null}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="fl-csv" title="File as CSV" icon="🧾" size="md" variant="info" style={{ flexGrow: 1 }} disabled={!tab.rows.length} onPress={() => share('csv')} />
        <Btn testID="fl-xlsx" title="File as Excel" icon="📊" size="md" variant="success" style={{ flexGrow: 1 }} disabled={!tab.rows.length} onPress={() => share('xlsx')} />
        <Btn testID="fl-copy" title="PDF / Excel / CSV copy with checks" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} disabled={!okPeriod}
          onPress={() => nav.push('ReportView', kind === 'payday' ? { kind: 'pay_day_report', from: payDate, to: payDate } : { kind: `filing_${kind}`, from: `${ym}-01`, to: `${ym}-28` })} />
      </View>
      <Btn testID="fl-payday-report" title="Weekly pay day report (both shops)" icon="🗓️" size="md" variant="secondary" onPress={() => nav.push('ReportView', { kind: 'pay_day_report', from: addDays(dateStr(), -6), to: dateStr() })} />
    </Screen>
  );
}
// Few choices as chips, otherwise a drop-down (same rule as Choice, without importing it twice).
function Choice35({ testIDPrefix, value, onChange, options }) {
  return <Chips testIDPrefix={testIDPrefix} value={value} onChange={onChange} options={options} />;
}
export function FilingSetupScreen() {
  const { user } = useApp();
  const ui = useUI();
  const act = useAct();
  const top = isTop(user);
  const [emp, setEmp] = useState(() => FL.employerDetails());
  const [kind, setKind] = useState('fnpf');
  const [draft, setDraft] = useState(null); // { name, fileType, headers, mapping }
  const [paste, setPaste] = useState('');
  const t = FL.filingTemplate(kind);
  const start = (headers, name, fileType) => {
    if (!headers.length) { ui.alert({ title: 'No column headings found', message: 'The file has no heading row. Choose the official file again, or type the headings.', tone: 'warn' }); return; }
    setDraft({ name: name || FL.FILING_KINDS[kind].title, fileType, headers, mapping: FL.guessMapping(headers) });
  };
  const upload = async () => {
    try {
      const f = await pickFilingTemplate();
      if (!f) return;
      start(FL.templateHeaders(f.rows || f.text || ''), f.name, f.kind === 'xlsx' ? 'xlsx' : 'csv');
    } catch (e) { ui.error(e); }
  };
  const fieldOptions = [{ value: '', label: 'Leave empty' }, { value: '__fixed', label: 'Fixed text…' }].concat(Object.entries(FL.FILING_FIELDS).map(([value, label]) => ({ value, label })));
  return (
    <Screen title="Filing templates" subtitle="Official FRCS / FNPF layouts">
      {!top ? <Banner tone="info" message="Only the owner or admin can change these." /> : null}
      <Card>
        <H>Employer details</H>
        <Field testID="fs-name" label="Employer name" value={emp.name} onChangeText={(v) => setEmp({ ...emp, name: v })} />
        <Field testID="fs-tin" label="Employer TIN" value={emp.tin} onChangeText={(v) => setEmp({ ...emp, tin: v })} />
        <Field testID="fs-fnpf" label="Employer FNPF reference number" value={emp.fnpfNo} onChangeText={(v) => setEmp({ ...emp, fnpfNo: v })} />
        <Field testID="fs-trading" label="Trading name (FNPF schedule)" value={emp.tradingName || ''} onChangeText={(v) => setEmp({ ...emp, tradingName: v })} />
        <Field testID="fs-postal" label="Postal address" value={emp.postal || ''} onChangeText={(v) => setEmp({ ...emp, postal: v })} />
        <Field testID="fs-city" label="City" value={emp.city || ''} onChangeText={(v) => setEmp({ ...emp, city: v })} />
        <Field testID="fs-ctype" label="FNPF contribution type" value={emp.contributionType || 'Normal'} onChangeText={(v) => setEmp({ ...emp, contributionType: v })} />
        {top ? <Btn testID="fs-emp-save" title="Save employer details" size="md" variant="success" onPress={() => act(() => FL.saveEmployerDetails(user, emp), 'Saved')} /> : null}
      </Card>
      <Chips testIDPrefix="fs-kind" value={kind} onChange={(v) => { setKind(v); setDraft(null); }} options={Object.entries(FL.FILING_KINDS).map(([value, k]) => ({ value, label: k.title }))} />
      <Card>
        <H>{FL.FILING_KINDS[kind].title}</H>
        {t ? <Text style={{ fontSize: 16, color: C.text }}>Uploaded: {t.name} · {t.headers.length} columns · saved by {t.savedBy} {String(t.savedAt).slice(0, 10)}</Text> : <Text style={{ fontSize: 16, color: C.sub }}>No template yet – the app's own layout is used.</Text>}
        {top ? (
          <View style={{ gap: 8, marginTop: 8 }}>
            <Btn testID="fs-upload" title="Upload the official file (Excel or CSV)" icon="📂" size="md" variant="info" onPress={upload} />
            <Field testID="fs-paste" label="Or type / paste the heading row (comma between columns)" value={paste} onChangeText={setPaste} />
            <Btn testID="fs-paste-go" title="Use these headings" size="sm" variant="secondary" disabled={!paste.trim()} onPress={() => start(FL.templateHeaders(paste), FL.FILING_KINDS[kind].title, 'csv')} />
            {t ? <ReasonButton testID="fs-remove" title="Stop using this template" prompt="Why?" confirm="Stop using it" onDo={() => act(() => FL.removeFilingTemplate(user, kind), 'The app layout is used again')} /> : null}
          </View>
        ) : null}
      </Card>
      {draft ? (
        <Card>
          <H>Which figure goes in each column</H>
          <Field testID="fs-tname" label="Name of this template" value={draft.name} onChangeText={(v) => setDraft({ ...draft, name: v })} />
          <Chips value={draft.fileType} onChange={(v) => setDraft({ ...draft, fileType: v })} options={[{ value: 'csv', label: 'File as CSV' }, { value: 'xlsx', label: 'File as Excel' }]} />
          {draft.headers.map((h, i) => {
            const m = draft.mapping[h] || {};
            const v = m.fixed !== undefined ? '__fixed' : m.field || '';
            return (
              <View key={h} style={{ gap: 4 }}>
                <Select testID={`fs-map-${i}`} label={h} value={v} options={fieldOptions} onChange={(x) => setDraft({ ...draft, mapping: { ...draft.mapping, [h]: x === '__fixed' ? { fixed: '' } : { field: x } } })} />
                {v === '__fixed' ? <Field label="Text" value={m.fixed || ''} onChangeText={(x) => setDraft({ ...draft, mapping: { ...draft.mapping, [h]: { fixed: x } } })} /> : null}
              </View>
            );
          })}
          <Btn testID="fs-save" title="Save the template" icon="💾" variant="success" onPress={() => { if (act(() => FL.saveFilingTemplate(user, kind, draft), 'Template saved')) setDraft(null); }} />
        </Card>
      ) : null}
      <Actions>
        <Action icon="ℹ️" title="Why upload the official file?" note="FRCS and FNPF want their own column order. Once the file is uploaded and its columns matched, the Filing screen makes the file in exactly that layout." />
      </Actions>
    </Screen>
  );
}
