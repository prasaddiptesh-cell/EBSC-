// Payroll screens: overview, pay run, one person's pay (change with a reason / payslip), pay details,
// advances & staff loans, payroll rules (rates, tax, FNPF, holidays), and staff's own payslips.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { PersonWeekGrid } from '../../timesheets/screens/TimesheetGridScreen.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Action, Actions, Explain, ReasonField, ReasonButton } from '../../../ui/kit.js';
import { payChanges, statAlerts } from '../statutory.js';
import { dateStr, addDays, weekStart } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import * as P from '../service.js';
import { listAccounts } from '../../payables/service.js';
import { db } from '../../../db/connection.js';
import { listPhotos } from '../../../services/stock.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { previousPeriod, payPeriod, cycleWords } from '../cycle.js';
import { PayslipView } from './Payroll35Screens.js';
import { actsAsOwner } from '../../../services/access.js';
import * as ST from '../payRunSteps.js';
import { fmtDate } from '../../../services/dates.js';

const { $, r2 } = P;
const STATUS = { draft: ['Draft – can be changed', C.warn], final: ['Final', C.success], void: ['Void', C.sub] };
const hrs = (h) => (h ? `${h} h` : '—');
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

export function PayrollHomeScreen() {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = P.payRules();
  const runs = P.listRuns().slice(0, 20);
  const lastP = previousPeriod(dateStr());
  const thisP = payPeriod(dateStr());
  const make = (d) => { try { const r = P.createRun(user, d); nav.push('PayRun', { uid: r.uid }); } catch (e) { ui.error(e); } };
  let stat = { late: [], dueSoon: [] };
  try { stat = statAlerts(); } catch (e) { /* none yet */ }
  return (
    <Screen title="Payroll" subtitle={cycleWords().split('. This period')[0]}>
      {!rules.confirmed ? <Banner testID="pay-unconfirmed" tone="warn" title="Check the tax and FNPF figures" message="The PAYE brackets, FNPF rates, minimum wage and public holidays are set up but must be checked against FRCS / FNPF before real pay runs. Payroll › Rules." /> : null}
      {can('payroll_run') ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          <Btn testID="pay-new-last" title="Start a pay run" icon="💰" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('NewPayRun', {})} />
          <Btn testID="pay-extra" title="Extra pay run" icon="🎁" size="md" variant="secondary" onPress={() => nav.push('ExtraPayRun')} />
        </View>
      ) : null}
      {stat.late.length ? <Banner tone="danger" title="FNPF / PAYE payment late" message={stat.late.map((x) => `${x.kind.toUpperCase()} ${x.period}: ${$(x.amount)} was due ${x.due_date}`).join('\n')} /> : null}
      {stat.dueSoon.length ? <Banner tone="warn" title="FNPF / PAYE due soon" message={stat.dueSoon.map((x) => `${x.kind.toUpperCase()} ${x.period}: ${$(x.amount)} due ${x.due_date}`).join('\n')} /> : null}
      <Section title="Every month">
        <Actions>
          <Action testID="pay-signoff" icon="✍️" title="Pay sign-off" note="Each person checks and signs their payslip; then their pay is released." onPress={() => nav.push('PaySignOff')} />
          <Action testID="pay-taxcal" icon="🗓️" title="Tax & statutory calendar" note="Lodgement and payment proof for VAT, FNPF, PAYE and the other taxes." onPress={() => nav.push('TaxCalendar')} />
          <Action testID="pay-filing" icon="📤" title="Filing (FNPF / FRCS)" note="Checks, then the file in the official layout; pay day report for both shops." onPress={() => nav.push('Filing')} />
          <Action testID="pay-stat" icon="🏦" title="FNPF & PAYE payments" note="What is owed to FNPF and FRCS each month, when it is due, record the payment, see it reach the bank." onPress={() => nav.push('Statutory')} />
          {can('payroll_run') ? <Action testID="pay-debts" icon="🤝" title="Advances & staff loans" note="Money given to staff before pay day or lent – taken back from pay a bit each week." onPress={() => nav.push('StaffDebts')} /> : null}
          {can('payroll_run') ? <Action icon="👋" title="Someone leaving" note="Final pay: leave not taken, advances still owing." onPress={() => nav.push('FinalPay')} /> : null}
          {can('statutory') ? <Action icon="📅" title="Year end" note="PAYE year-end reconciliation and each person's pay & tax certificate." onPress={() => nav.push('PayYearEnd')} /> : null}
        </Actions>
      </Section>
      {can('payroll_setup') ? (
        <Section title="Setup">
          <Actions>
            <Action testID="pay-profiles" icon="🪪" title="Pay details" note="Each person's rate or salary, FNPF and TIN numbers, cash or bank, allowances." onPress={() => nav.push('PayProfiles')} />
            <Action testID="pay-cycle" icon="🔁" title="Pay cycle & pay day" note="Weekly, fortnightly or monthly; the day the week starts; pay day." onPress={() => nav.push('PayCycle')} />
            <Action testID="pay-statrules" icon="🧮" title="FNPF & PAYE per person" note="On / off with a note, or only part of the pay (owner / admin)." onPress={() => nav.push('PayStatRules')} />
            <Action testID="pay-rules" icon="⚙️" title="Rules, tax, FNPF, holidays" note="Overtime, PAYE brackets, FNPF %, minimum wage and public holidays." onPress={() => nav.push('PayRules')} />
          </Actions>
        </Section>
      ) : null}
      <Section title="Pay runs">
        {!runs.length ? <Text style={{ fontSize: 16, color: C.sub }}>No pay runs yet.</Text> : null}
        {runs.map((r) => (
          <ListItem key={r.uid} testID={`run-${r.week_start}`} onPress={() => nav.push('PayRun', { uid: r.uid })} title={`${r.run_kind === 'extra' ? `${r.label || 'Extra pay'} · ` : ''}${r.week_start} – ${r.week_end}${r.version > 1 ? ` (corrected v${r.version})` : ''}`}
            sub={`Paid ${r.pay_date} · ${r.totals.people || 0} people · gross ${$(r.totals.gross || 0)}${r.totals.warnings ? ` · ${r.totals.warnings} to look at` : ''}`}
            right={$(r.totals.net || 0)} rightSub="net" badge={STATUS[r.status][0].split(' –')[0]} badgeColor={STATUS[r.status][1]} />
        ))}
      </Section>
    </Screen>
  );
}

export function PayRunScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const act = useAct();
  const [reason, setReason] = useState('');
  const [, setTick] = useState(0);
  // Coming back from a timesheet: work the draft out again so the pay follows the fixed hours (line changes are kept).
  React.useEffect(() => { try { const x = P.getRun(params.uid); if (x && x.status === 'draft' && can('payroll_run')) { P.recalcRun(user, params.uid); setTick((n) => n + 1); } } catch (e) { /* shown below */ } }, [params.uid]);
  const r = P.getRun(params.uid);
  if (!r) return <Screen title="Pay run"><Text>Not found.</Text></Screen>;
  const t = r.totals;
  const draft = r.status === 'draft';
  const cash = P.cashBreakdown(r.lines.filter((l) => l.include && l.pay_method !== 'bank').map((l) => l.net));
  const changes = draft ? payChanges(r.uid) : [];
  const finalise = async () => {
    const warn = r.lines.filter((l) => l.include && l.warnings.length).length;
    const ok = await ui.confirm({ title: 'Make this pay run final?', message: `${t.people} people · net ${$(t.net)}${warn ? `\n\n${warn} line(s) still have warnings.` : ''}\n\nAfter this it cannot be changed (only voided by the owner).`, confirmText: 'Make final', tone: warn ? 'warn' : 'primary' });
    if (ok) act(() => P.finaliseRun(user, r.uid), 'Pay run is final');
  };
  // v3.9.7 once final, only the owner / admin see the finer details; everyone else the clean payslips.
  const details = P.seesPayDetails(user, r);
  return (
    <Screen title={`${r.run_kind === 'extra' ? `${r.label || 'Extra pay'} ` : 'Pay '}${r.week_start} – ${r.week_end}`} subtitle={`Pay day ${r.pay_date} · ${STATUS[r.status][0]}${r.version > 1 ? ` · version ${r.version}` : ''}`}>
      <Stats items={[{ label: 'Gross', value: $(t.gross) }, { label: 'PAYE', value: $(t.paye) }, { label: 'FNPF staff 8%', value: $(t.fnpfEmployee) }, { label: 'FNPF Easy Buys', value: $(t.fnpfEmployer) },
        { label: 'Net pay', value: $(t.net), color: C.success }, { label: 'Cash / bank', value: `${$(t.cash)} / ${$(t.bank)}` }]} />
      {r.status === 'void' ? <Banner tone="danger" title="Void" message={r.void_reason} /> : null}
      {t.undecided ? <Banner testID="run-undecided" tone="danger" title="Till shortages not decided yet" message={r.lines.flatMap((l) => (l.undecided || []).map((x) => `${l.name}: ${$(x.amount)} short on ${x.date} (${x.shop || ''}) – ${x.status === 'disagreed' ? 'cashier disagrees, manager to decide' : 'cashier to agree'}`)).join('\n')} /> : null}
      {r.reopened_at ? <Banner tone="warn" title={`Reopened by ${r.reopened_by_name} to correct it`} message={`${String(r.reopened_at).slice(0, 16)}${r.reopen_reason ? ` – ${r.reopen_reason}` : ''}. Everyone signs the corrected payslip again.`} /> : null}
      {draft && changes.length ? <Banner tone="warn" title="Check before making final" message={changes.map((c) => `${c.name}: ${c.why}`).join('\n')} /> : null}
      {r.status === 'final' ? <Banner tone="success" title={`Final – ${r.finalised_by_name}`} message={String(r.finalised_at).slice(0, 16)} /> : null}
      {draft && can('payroll_run') ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="run-recalc" title="Work out again from timesheets" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => P.recalcRun(user, r.uid), 'Updated')} />
          <Btn testID="run-final" title="Make final" icon="✅" variant="success" style={{ flexGrow: 1 }} onPress={finalise} />
        </View>
      ) : null}
      <Card>
        <Text testID="run-dates" style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Pay period {fmtDate(r.week_start)} – {fmtDate(r.week_end)} · paid on {fmtDate(r.pay_date)}</Text>
        {draft && can('payroll_run') ? <DateField testID="run-paydate" label="Change the pay day" value={r.pay_date} onChange={(v) => { if (v && v !== r.pay_date) act(() => ST.setPayDate(user, r.uid, v, 'Pay day changed in the pay run'), 'Pay day changed'); }} /> : null}
      </Card>
      {(() => {
        const left = ST.notPaidYet(r.uid);
        return left.length && can('payroll_run') ? (
          <Card tone="warn">
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Not paid yet for this period ({left.length})</Text>
            {left.map((x) => <Text key={x.userUid} style={{ color: C.text }}>{x.name}{x.hours ? ` · ${x.hours} hours` : ''}</Text>)}
            <Btn testID="run-pay-left" title={draft ? 'Add them to this pay run' : 'Pay them now (their own run for this period)'} size="md" variant="info"
              onPress={() => { try { const nr = ST.payLeftOut(user, r.uid, left.map((x) => x.userUid)); if (nr.uid !== r.uid) nav.push('PayRun', { uid: nr.uid }); else setTick((n) => n + 1); } catch (e) { ui.error(e); } }} />
          </Card>
        ) : null;
      })()}
      <Section title={`People (${r.lines.length})`}>
        {r.lines.slice().sort((a, b) => (b.include - a.include) || ((b.warnings.length + (b.undecided || []).length > 0) - (a.warnings.length + (a.undecided || []).length > 0))).map((l) => (
          <ListItem key={l.uid} testID={`line-${l.employee_no || l.name}`} onPress={() => nav.push('PayLine', { uid: l.uid })} title={`${l.name}${l.include ? '' : ' (left out)'}`}
            sub={!details ? `Gross ${$(l.gross)}` : `${(l.counted && l.counted.family) ? 'Family pay' : l.pay_type === 'salary' ? 'Salary' : `${$(l.rate)}/h`} · ${hrs(l.hours.normal)}${l.hours.ot ? ` + OT ${l.hours.ot} h` : ''}${l.hours.sunday ? ` · Sun ${l.hours.sunday} h` : ''}${l.hours.holiday ? ` · Hol ${l.hours.holiday} h` : ''}${l.hours.leave ? ` · leave ${l.hours.leave} h` : ''} · gross ${$(l.gross)}${l.counted && l.counted.paidChanged ? ' · paid hours changed' : ''}${l.edited_by_name ? ' · changed' : ''}`}
            right={$(l.net)} rightSub={l.pay_method === 'bank' ? 'bank' : 'cash'} badge={(l.undecided || []).length ? 'till short?' : l.warnings.length ? `${l.warnings.length} ⚠` : null} badgeColor={(l.undecided || []).length ? C.danger : C.warn} tone={l.net < 0 || (l.undecided || []).length ? 'danger' : l.warnings.length ? 'warn' : undefined} />
        ))}
      </Section>
      {cash.length ? (
        <Section title="Notes and coins for cash pay (each pay made up exactly)">
          <Text style={{ fontSize: 17, color: C.text }}>{cash.map((c) => `${c.label} × ${c.count}`).join('   ')}</Text>
        </Section>
      ) : null}
      {r.status === 'final' ? <Btn testID="run-sign" title="Pay sign-off (staff sign their payslips)" icon="✍️" size="md" variant="info" onPress={() => nav.push('PaySignOff', { runUid: r.uid })} /> : null}
      {r.status === 'final' && isTop(user) ? <ReasonButton testID="run-reopen" title="Reopen to correct it" icon="✏️" prompt="What needs correcting?" confirm="Reopen" variant="warn" onDo={(w) => act(() => P.reopenRun(user, r.uid, w), 'Reopened – correct it, then make it final again')} /> : null}
      <Btn title="Payslips & reports" size="md" variant="secondary" onPress={() => nav.push('ReportsHub', { group: 'Payroll' })} />
      {r.status !== 'void' && isTop(user) ? (
        <Card>
          <ReasonField label="Reason to void (then start the week again)" value={reason} onChangeText={setReason} />
          <Btn title="Void pay run" variant="danger" size="sm" style={{ marginTop: 8 }} onPress={() => act(() => P.voidRun(user, r.uid, reason), 'Voided')} />
        </Card>
      ) : null}
    </Screen>
  );
}

export function PayLineScreen({ params }) {
  const { user, can, nav } = useApp();
  const act = useAct();
  const [, setTick] = useState(0);
  React.useEffect(() => { try { const x = P.getRun(String(params.uid).split('|')[0]); if (x && x.status === 'draft' && can('payroll_run')) { P.recalcRun(user, x.uid); setTick((n) => n + 1); } } catch (e) { /* shown below */ } }, [params.uid]);
  const run = P.getRun(String(params.uid).split('|')[0]);
  const l = run && run.lines.find((x) => x.uid === params.uid);
  const rules = P.payRules();
  const [f, setF] = useState(() => (l ? {
    fnpfHours: l.overrides.fnpfHours ?? '', normal: l.overrides.normal ?? '', ot: l.overrides.ot ?? '', sunday: l.overrides.sunday ?? '', holiday: l.overrides.holiday ?? '', leave: l.overrides.leave ?? '', rate: l.overrides.rate ?? '', paye: l.overrides.paye ?? '',
    adjustments: l.adjustments.map((a) => ({ ...a, amount: String(a.amount) })), deductions: l.deductions.filter((d) => d.manual).map((d) => ({ ...d, amount: String(d.amount) })), include: !!l.include, reason: '',
  } : {}));
  if (!l || (!can('payroll_view') && l.user_uid !== user.uid)) return <Screen title="Pay"><Text>Not found.</Text></Screen>;
  const draft = run.status === 'draft' && can('payroll_run');
  const details = P.seesPayDetails(user, run);
  const C2 = l.counted || {};
  const sumH = (h) => Math.round(['normal', 'ot', 'sunday', 'holiday', 'leave'].reduce((a, k) => a + (Number((h || {})[k]) || 0), 0) * 100) / 100;
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const ytd = P.yearToDate(l.user_uid, run.pay_date.slice(0, 4), run.pay_date);
  const E = l.earnings;
  return (
    <Screen title={l.name} subtitle={`Week ${run.week_start} – ${run.week_end} · paid ${run.pay_date}`}
      footer={draft ? <Btn testID="pl-save" title="Save changes" icon="💾" variant="success" onPress={() => { if (act(() => P.editLine(user, l.uid, f), 'Changed')) { try { const fresh = P.getRun(run.uid).lines.find((x) => x.uid === l.uid); if (fresh) setF((o) => ({ ...o, deductions: fresh.deductions.filter((d) => d.manual).map((d) => ({ ...d, amount: String(d.amount) })) })); } catch (e) { /* kept */ } } }} /> : null}>
      {(() => {
        // Release 22: person by person through the pay run without leaving it
        const ppl = run.lines.filter((x) => x.include || draft);
        const i = ppl.findIndex((x) => x.uid === l.uid);
        if (ppl.length < 2) return null;
        return (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn testID="pl-prev" title="‹ Previous person" size="sm" variant="secondary" style={{ flex: 1 }} disabled={i <= 0} onPress={() => nav.replace('PayLine', { uid: ppl[i - 1].uid })} />
            <Text style={{ alignSelf: 'center', color: C.sub }}>{`${i + 1} of ${ppl.length}`}</Text>
            <Btn testID="pl-next" title="Next person ›" size="sm" variant="secondary" style={{ flex: 1 }} disabled={i >= ppl.length - 1} onPress={() => nav.replace('PayLine', { uid: ppl[i + 1].uid })} />
          </View>
        );
      })()}
      {/* Release 24: the timesheet problems in one box – what is wrong each day and how to fix it (in the timesheet below) */}
      {details ? (() => {
        const ts = l.warnings.filter((w) => /^(Sun|Mon|Tue|Wed|Thu|Fri|Sat) \d+\/\d+: |^Timesheet problem/.test(w));
        const other = l.warnings.filter((w) => !ts.includes(w));
        return (
          <>
            {other.map((w) => <Banner key={w} tone="warn" message={w} />)}
            {ts.length ? (
              <Card testID="pl-tsproblems" style={{ backgroundColor: C.warnSoft, borderColor: C.warn }}>
                <Text style={{ fontSize: 17, fontWeight: '900', color: C.text }}>{`⚠ Timesheet – ${ts.length} thing${ts.length === 1 ? '' : 's'} to check`}</Text>
                {ts.map((w) => <Text key={w} style={{ fontSize: 15, color: C.text, marginTop: 6 }}>{`• ${w}`}</Text>)}
                <Text style={{ fontSize: 14, color: C.sub, marginTop: 8 }}>Fix them in the timesheet further down this page – the pay is worked out again after each Save.</Text>
              </Card>
            ) : null}
          </>
        );
      })() : null}
      {details && C2.worked ? <Card testID="pl-worked"><Text style={{ fontSize: 17, fontWeight: '800', color: C2.paidChanged ? C.warn : C.text }}>{`Worked ${sumH(C2.worked)} h · Paid ${sumH(l.hours)} h`}</Text>{C2.paidChanged && l.edit_reason ? <Text style={{ color: C.sub }}>{`Why: ${l.edit_reason}`}</Text> : null}</Card> : null}
      {details && C2.fnpfHours !== null && C2.fnpfHours !== undefined ? <Text testID="pl-fnpfhours" style={{ fontSize: 15, color: C.text }}>{`FNPF counted on ${C2.fnpfHours} hours (${$(l.fnpf_base)})`}</Text> : null}
      {details && C2.family ? <Card testID="pl-family"><Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`Family pay ${$(C2.family.total)}: wages ${$(C2.family.wages)} (on the payslip) + owner's drawings ${$(C2.family.drawings)}`}</Text><Text style={{ color: C.sub }}>The drawings part is booked in Owner's money when the pay run is made final.</Text></Card> : null}
      {details && can('timesheets_view') && draft && can('timesheets_edit') ? (
        // Release 22 (owner: "when we run pay it should have this layout for timesheet"): the person's timesheet week(s)
        // right in the pay – type the times, Day off, Sick, a note; the pay is worked out again after each change.
        <Card testID="pl-weekgrid">
          {(() => { const ws = []; for (let d = run.week_start; d <= run.week_end; d = addDays(d, 7)) ws.push(d); return ws; })().map((wk) => (
            <PersonWeekGrid key={wk} embedded params={{ userUid: l.user_uid, date: wk }} onChanged={() => { try { P.recalcRun(user, run.uid); } catch (e) { /* shown below */ } setTick((n) => n + 1); }} />
          ))}
        </Card>
      ) : null}
      {details && can('timesheets_view') ? <Btn testID="pl-timesheet" title="Every punch for this period" icon="🗓️" size="sm" variant="ghost" onPress={() => nav.push('TimesheetPerson', { userUid: l.user_uid, date: run.week_start })} /> : null}
      {details && l.edited_by_name ? <Banner tone="info" title={`Changed by ${l.edited_by_name}`} message={l.edit_reason} /> : null}
      {(() => {
        // Release 18: shop things this person paid for with their own money – paid back with this pay (not wages, no FNPF)
        const back = run.status === 'draft' ? P.reimbursementsFor(l.user_uid) : [];
        const wait = run.status === 'draft' ? P.reimbursementsToCheck(l.user_uid) : [];
        if (!back.length && !wait.length) return null;
        const tot = back.reduce((t, i) => t + i.owing, 0);
        return (
          <Card testID="pl-payback" tone="info">
            <H>{back.length ? `Also pay back ${$(tot)} – shop things they paid for` : 'Shop things they paid for'}</H>
            {back.map((i) => <Text key={i.uid} style={{ color: C.text }}>{`${i.invoice_date} · ${i.supplier_name}${i.invoice_no ? ` ${i.invoice_no}` : ''} · ${$(i.owing)}`}</Text>)}
            {back.length ? <Text style={{ color: C.sub }}>Not wages – no FNPF or PAYE. When this pay run is made final, each invoice is paid in cash from the shop's safe. Give it to them with their pay.</Text> : null}
            {wait.length ? <Text style={{ color: C.warn }}>{`${wait.length} more waiting to be checked (Verify): ${wait.map((i) => `${i.supplier_name} ${$(i.total)}`).join(', ')}`}</Text> : null}
          </Card>
        );
      })()}
      <PayslipView lineUid={l.uid} testID="pl-slip" />
      {draft && Array.isArray(l.hours.days) ? (
        // Release 18: a daily-rate person – each day worked is a full day unless payroll makes it a half day or none
        <Card testID="pl-days">
          <H>{`Days paid – ${$(l.hours.dayRate || 0)} a day (one shift)`}</H>
          <Text style={{ color: C.sub }}>Each day worked counts as a full day. Make a day a half day or none here (it saves at once, with a reason if you give one above).</Text>
          {l.hours.days.map((d) => (
            <View key={d.date} style={{ gap: 4 }}>
              <Text style={{ fontWeight: '700', color: C.text }}>{`${d.date}${d.worked ? '' : ' (not on the timesheet)'}`}</Text>
              <Chips testIDPrefix={`pl-day-${d.date}`} value={String(d.part)} onChange={(v) => act(() => P.editLine(user, l.uid, { days: { [d.date]: Number(v) }, reason: f.reason || '' }), 'Changed') && setTick((n) => n + 1)}
                options={[{ value: '1', label: 'Full day' }, { value: '0.5', label: 'Half day' }, { value: '0', label: 'None' }].concat(['1', '0.5', '0'].includes(String(d.part)) ? [] : [{ value: String(d.part), label: `${d.part} day` }])} />
            </View>
          ))}
        </Card>
      ) : null}
      {draft ? (
        <>
          <Card>
            <H>Hours paid, rate, FNPF hours (blank = from the timesheet)</H>
            <Text style={{ color: C.sub }}>Paying different hours from the hours worked (e.g. covering hours missed) or counting FNPF on other hours needs a reason below.</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {[['normal', 'Normal h paid'], ['ot', 'Overtime h paid'], ['sunday', 'Sunday h paid'], ['holiday', 'Holiday h paid'], ['leave', 'Leave h'], ['rate', 'Rate $/h'], ['paye', 'PAYE $'], ['fnpfHours', 'FNPF on hours (this week)']].map(([k, label]) => (
                <View key={k} style={{ flexBasis: 140, flexGrow: 1 }}><Field testID={`pl-${k}`} label={label} value={String(f[k] ?? '')} onChangeText={set(k)} keyboardType="decimal-pad" placeholder={k === 'rate' ? String(l.rate) : k === 'paye' ? String(l.paye) : k === 'fnpfHours' ? (C2.fnpfHours !== null && C2.fnpfHours !== undefined ? String(C2.fnpfHours) : 'all hours') : String((C2.worked || l.hours)[k] ?? '')} /></View>
              ))}
            </View>
          </Card>
          <Card>
            <H>Extra pay this week</H>
            {f.adjustments.map((a, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <View style={{ flexBasis: 160, flexGrow: 2 }}><Select label="What" value={a.label} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, label: v } : x)))} options={rules.allowanceTypes.map((x) => ({ value: x, label: x }))} /></View>
                <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField label="Amount" value={a.amount} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
                <Chips value={a.taxable !== false} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, taxable: v } : x)))} options={[{ value: true, label: 'Taxed' }, { value: false, label: 'Not taxed' }]} />
                <Btn title="✕" size="sm" variant="ghost" onPress={() => set('adjustments')(f.adjustments.filter((_, k) => k !== i))} />
              </View>
            ))}
            <Btn testID="pl-add-adj" title="+ Extra pay" size="sm" variant="secondary" onPress={() => set('adjustments')(f.adjustments.concat([{ label: rules.allowanceTypes[0], amount: '' }]))} />
          </Card>
          <Card>
            <H>Deductions this week</H>
            {f.deductions.map((d, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <View style={{ flexBasis: 160, flexGrow: 2 }}><Select label="What" value={d.label} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, label: v } : x)))} options={rules.deductionTypes.map((x) => ({ value: x, label: x }))} /></View>
                <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField label="Amount" value={d.amount} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
                <Btn title="✕" size="sm" variant="ghost" onPress={() => set('deductions')(f.deductions.filter((_, k) => k !== i))} />
                {/* Release 24: a note and (optional) receipt for each deduction */}
                <View style={{ flexBasis: '100%', gap: 6, paddingBottom: 10, borderBottomWidth: 1, borderColor: C.border }}>
                  <Field testID={`pl-ded-note-${i}`} label="Note (optional)" value={d.note || ''} onChangeText={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, note: v } : x)))} placeholder="e.g. 2 loaves bread + milk, 12 Nov" />
                  {(() => { let old = []; try { old = d.pid ? require('../../../services/stock.js').listPhotos('pay_deduction', d.pid) : []; } catch (e) { old = []; } return old.length ? <PhotoStrip testID={`pl-ded-photos-${i}`} size={80} photos={old.map((ph) => ({ uri: ph.cloud_url || ph.uri }))} /> : null; })()}
                  <PhotoPicker testID={`pl-ded-photo-${i}`} label="Receipt (optional)" value={d.newPhotos || []} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, newPhotos: v } : x)))} />
                </View>
              </View>
            ))}
            <Btn title="+ Deduction" size="sm" variant="secondary" onPress={() => set('deductions')(f.deductions.concat([{ label: rules.deductionTypes[0], amount: '' }]))} />
            <Label>Pay this person in this run</Label>
            <Chips value={f.include} onChange={set('include')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'Leave out' }]} />
            <ReasonField testID="pl-reason" label="Reason for the change (required)" value={f.reason} onChangeText={set('reason')} />
          </Card>
        </>
      ) : null}
    </Screen>
  );
}

export function PayProfilesScreen() {
  const { nav } = useApp();
  const rows = P.listProfiles();
  return (
    <Screen title="Pay details" subtitle="Rate, tax, FNPF, how each person is paid">
      {rows.map((p) => (
        <ListItem key={p.user_uid} testID={`prof-${p.name}`} onPress={() => nav.push('PayProfile', { userUid: p.user_uid })} title={p.name}
          sub={p.hasProfile ? `${p.pay_type === 'salary' ? `Salary ${$(p.weekly_salary)}/week` : `${$(p.rate)}/hour`} · ${p.pay_method}${p.tin ? '' : ' · no TIN'}${p.fnpf_no ? '' : ' · no FNPF no'}${p.active === 0 ? ' · not paid' : ''}` : 'No pay details yet – tap to add'}
          badge={p.hasProfile ? null : 'NEW'} badgeColor={C.info} />
      ))}
    </Screen>
  );
}
export function PayProfileScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const u = listUsers().find((x) => x.uid === params.userUid);
  const p0 = P.getProfile(params.userUid);
  const rules = P.payRules();
  const [f, setF] = useState(() => (p0 ? {
    userUid: params.userUid, payType: Number(p0.day_rate) > 0 ? 'daily' : p0.pay_type, dayRate: String(p0.day_rate || ''), rate: String(p0.rate || ''), weeklySalary: String(p0.weekly_salary || ''), normalHours: p0.normal_hours == null ? '' : String(p0.normal_hours), jobTitle: p0.job_title || '',
    wageCategory: p0.wage_category || '', fnpfNo: p0.fnpf_no || '', tin: p0.tin || '', taxStatus: p0.tax_status, fnpfMember: !!p0.fnpf_member, fnpfExtraPct: String(p0.fnpf_extra_pct || 0), payMethod: p0.pay_method,
    bankName: p0.bank_name || '', bankAccount: p0.bank_account || '', allowances: p0.allowances.map((a) => ({ ...a, amount: String(a.amount) })), deductions: p0.deductions.map((d) => ({ ...d, amount: String(d.amount) })),
    startDate: p0.start_date || '', endDate: p0.end_date || '', active: !!p0.active, notes: p0.notes || '', email: p0.email || '', viber: p0.viber || '',
  } : { userUid: params.userUid, payType: 'hourly', rate: String(rules.minimumWage), weeklySalary: '', normalHours: '', jobTitle: '', wageCategory: 'Shop assistant', fnpfNo: '', tin: '', taxStatus: 'resident', fnpfMember: true,
    fnpfExtraPct: '0', payMethod: 'cash', bankName: 'BSP', bankAccount: '', allowances: [], deductions: [], startDate: dateStr(), endDate: '', active: true, notes: '', email: '', viber: '' }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  if (!u) return <Screen title="Pay details"><Text>Not found.</Text></Screen>;
  return (
    <Screen title={u.name} subtitle="Pay details" footer={<Btn testID="prof-save" title="Save" icon="💾" variant="success" onPress={() => { if (act(() => P.saveProfile(user, f), 'Saved')) nav.pop(); }} />}>
      <Card>
        <Chips value={f.payType} onChange={set('payType')} testIDPrefix="prof-type" options={[{ value: 'hourly', label: 'Paid by the hour' }, { value: 'daily', label: 'Daily rate (per shift)' }, { value: 'salary', label: 'Weekly fixed' }]} />
        {f.payType === 'daily' ? (
          <>
            <MoneyField testID="prof-dayrate" label="Pay for one day (one shift)" value={f.dayRate || ''} onChange={set('dayRate')} />
            <Text style={{ color: C.sub }}>Each day worked pays this. In the pay run, payroll can make a day a half day or none.</Text>
          </>
        ) : f.payType === 'hourly' ? <MoneyField testID="prof-rate" label="Hourly rate" value={f.rate} onChange={set('rate')} /> : <MoneyField testID="prof-salary" label="Weekly salary" value={f.weeklySalary} onChange={set('weeklySalary')} />}
        {f.payType === 'hourly' && Number(f.rate) < rules.minimumWage ? <Banner tone="warn" message={`Below the minimum wage (${$(rules.minimumWage)}).`} /> : null}
        <Field label={`Normal hours a week (blank = ${rules.normalHoursWeek})`} value={f.normalHours} onChangeText={set('normalHours')} keyboardType="decimal-pad" />
        <Field label="Job title" value={f.jobTitle} onChangeText={set('jobTitle')} />
        <Field label="Wage category (minimum wage group)" value={f.wageCategory} onChangeText={set('wageCategory')} />
      </Card>
      <Card>
        <H>Tax and FNPF</H>
        <Field testID="prof-tin" label="TIN" value={f.tin} onChangeText={set('tin')} keyboardType="number-pad" />
        <Chips value={f.taxStatus} onChange={set('taxStatus')} options={[{ value: 'resident', label: 'Resident' }, { value: 'non_resident', label: 'Non-resident' }]} />
        <Field testID="prof-fnpf" label="FNPF number" value={f.fnpfNo} onChangeText={set('fnpfNo')} />
        {isTop(user) ? <Chips value={f.fnpfMember} onChange={set('fnpfMember')} options={[{ value: true, label: 'Pays FNPF' }, { value: false, label: 'No FNPF' }]} /> : <Text style={{ fontSize: 15, color: C.sub }}>{f.fnpfMember ? 'Pays FNPF' : 'No FNPF'} (only the owner or admin can change this)</Text>}
        <Btn testID="prof-statrules" title="FNPF & PAYE: on / off or only part of the pay" size="sm" variant="secondary" onPress={() => nav.push('PayStatRules', { userUid: params.userUid })} />
        <Field label="Extra FNPF % chosen by the employee" value={f.fnpfExtraPct} onChangeText={set('fnpfExtraPct')} keyboardType="decimal-pad" />
      </Card>
      <Card>
        <H>Paid by</H>
        <Chips value={f.payMethod} onChange={set('payMethod')} testIDPrefix="prof-method" options={[{ value: 'cash', label: 'Cash' }, { value: 'bank', label: 'Bank' }]} />
        <Field testID="prof-email" label="Email for payslips (optional)" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
        <Field testID="prof-viber" label="Viber number (optional)" value={f.viber} onChangeText={set('viber')} keyboardType="phone-pad" />
        {f.payMethod === 'bank' ? <><Field label="Bank" value={f.bankName} onChangeText={set('bankName')} /><Field label="Account number" value={f.bankAccount} onChangeText={set('bankAccount')} /></> : null}
      </Card>
      <Card>
        <H>Every week</H>
        <Label>Allowances</Label>
        {f.allowances.map((a, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 150, flexGrow: 2 }}><Select label="What" value={a.name} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, name: v } : x)))} options={rules.allowanceTypes.map((x) => ({ value: x, label: x }))} /></View>
            <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField label="Amount" value={a.amount} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Chips value={a.taxable !== false} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, taxable: v } : x)))} options={[{ value: true, label: 'Taxed' }, { value: false, label: 'Not taxed' }]} />
            <Chips value={a.fnpf !== false} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, fnpf: v } : x)))} options={[{ value: true, label: 'FNPF' }, { value: false, label: 'No FNPF' }]} />
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('allowances')(f.allowances.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Allowance" size="sm" variant="secondary" onPress={() => set('allowances')(f.allowances.concat([{ name: rules.allowanceTypes[0], amount: '' }]))} />
        <Label>Regular deductions</Label>
        {f.deductions.map((d, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 150, flexGrow: 2 }}><Select label="What" value={d.name} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, name: v } : x)))} options={rules.deductionTypes.map((x) => ({ value: x, label: x }))} /></View>
            <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField label="Amount" value={d.amount} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('deductions')(f.deductions.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Deduction" size="sm" variant="secondary" onPress={() => set('deductions')(f.deductions.concat([{ name: rules.deductionTypes[0], amount: '' }]))} />
      </Card>
      <Card>
        <DateField farDays={false} label="Started" value={f.startDate} onChange={set('startDate')} />
        <DateField farDays={false} label="Finished (blank = still working)" value={f.endDate} onChange={set('endDate')} />
        <Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'On the payroll' }, { value: false, label: 'Not paid' }]} />
        <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
      </Card>
    </Screen>
  );
}

export function StaffDebtsScreen() {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [f, setF] = useState(null);
  const dp = usePaper('aronium');
  const DEBT_MAP = { total: 'amount', date: 'date' };
  const [showAll, setShowAll] = useState(false);
  const [openUid, setOpenUid] = useState(null);
  const debts = P.listDebts({ open: !showAll });
  const people = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  return (
    <Screen title="Advances, loans & staff credit" subtitle="Taken back from pay each week until repaid">
      {f ? (
        <Card>
          <Chips value={f.kind} onChange={(v) => setF({ ...f, kind: v })} testIDPrefix="debt-kind" options={[{ value: 'advance', label: 'Advance' }, { value: 'loan', label: 'Staff loan' }, { value: 'credit', label: 'Staff credit (Aronium)' }]} />
          {f.kind === 'credit' ? <Hint>Staff credit is kept in Aronium. Print or show the person's credit receipt / account in Aronium and take a photo – it is the proof for taking it from their pay.</Hint> : null}
          <Select testID="debt-person" label="Staff member" value={f.userUid} onChange={(v) => setF({ ...f, userUid: v })} options={people.map((u) => ({ value: u.uid, label: u.name }))} />
          <MoneyField testID="debt-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
          {f.kind === 'advance' ? <Hint>An advance given during the work week (Saturday to Friday) is part of that week's pay: it all comes off that week's pay, and FNPF is on the full pay with the advance in it.</Hint>
            : <MoneyField testID="debt-repay" label="Take back each week" value={f.repayPerPay} onChange={(v) => setF({ ...f, repayPerPay: v })} />}
          <DateField label={f.kind === 'credit' ? 'Date' : 'Date given'} value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <ReasonField testID="debt-reason" label="Reason" value={f.reason} onChangeText={(v) => setF({ ...f, reason: v })} />
          {f.kind === 'credit' ? (
            <>
              <Label>Shop</Label>
              <Chips value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }))} />
              <PaperPhoto pr={dp} testID="debt-photo" value={f.photos || []} onChange={(v) => setF((o) => ({ ...o, photos: v }))} label="Photo of the Aronium receipt / credit statement (needed)" form={f} setForm={setF} map={DEBT_MAP} soft={{ date: dateStr() }}
                labels={{ amount: 'Amount', date: 'Date' }} hint="The amount and date fill in from the photo." />
            </>
          ) : (
            <>
              <Label>Given from</Label>
              <Chips value={f.paidFrom} onChange={(v) => setF({ ...f, paidFrom: v })} options={[{ value: 'cash', label: 'Shop cash' }, { value: 'bank', label: 'Bank' }]} />
              {f.paidFrom === 'cash' ? <Chips value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }))} /> : null}
            </>
          )}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="debt-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (f.kind === 'credit' && !dp.okToSave(ui)) return; if (f.kind === 'credit') { dp.log(user, 'staff_charges', null, f, DEBT_MAP); dp.reset(); } if (act(() => (f.kind === 'credit'
              ? P.chargeStaff(user, { userUid: f.userUid, amount: f.amount, perPay: f.repayPerPay, reason: f.reason, source: 'staff_credit', shopCode: f.shopCode, date: f.date, photos: f.photos || [] })
              : P.giveDebt(user, f)), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="debt-add" title="Advance, loan or staff credit" icon="➕" variant="success" onPress={() => setF({ kind: 'advance', userUid: '', amount: '', repayPerPay: '', date: dateStr(), reason: '', paidFrom: 'cash', shopCode: user.shop_code || 'S1' })} />}
      <Chips value={showAll} onChange={setShowAll} options={[{ value: false, label: 'Still owing' }, { value: true, label: 'All' }]} />
      {debts.map((d) => {
        const local = d.charge ? listPhotos('charge', d.uid) : [];
        const pics = photosFor(local, d.photos || [], 'Aronium receipt');
        return (
          <View key={d.uid}>
            <ListItem title={`${d.name} · ${P.DEBT_LABEL[d.kind] || d.kind}${pics.length ? ' · 📷' : ''}`} sub={`${d.debt_date} · ${d.reason || ''} · ${$(d.repay_per_pay)} a week · by ${d.given_by_name || ''}`} right={$(d.balance)} rightSub={`of ${$(d.amount)}`}
              onPress={pics.length ? () => setOpenUid(openUid === d.uid ? null : d.uid) : undefined} />
            {openUid === d.uid ? <PhotoStrip photos={pics} size={140} /> : null}
          </View>
        );
      })}
      {!debts.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing owing.</Text> : null}
    </Screen>
  );
}

export function PayRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = P.payRules();
  const [f, setF] = useState(() => ({ ...r0, taxBrackets: r0.taxBrackets.map((b) => ({ upTo: b.upTo === null ? '' : String(b.upTo), rate: String(b.rate) })),
    srtBrackets: (r0.srtBrackets || []).map((b) => ({ over: String(b.over), rate: String(b.rate) })), publicHolidays: r0.publicHolidays.slice(), allowanceTypes: r0.allowanceTypes.join('\n'), deductionTypes: r0.deductionTypes.join('\n') }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const num = (k, label) => <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID={`pr-${k}`} label={label} value={String(f[k])} onChangeText={set(k)} keyboardType="decimal-pad" /></View>;
  return (
    <Screen title="Payroll rules" subtitle="For every device · check with FRCS / FNPF" footer={<Btn testID="pr-save" title="Save" icon="💾" variant="success" onPress={() => act(() => P.savePayRules(user, f), 'Saved')} />}>
      <Card tone={f.confirmed ? 'success' : 'warn'}>
        <Label>I have checked these figures against FRCS and FNPF</Label>
        <Chips value={f.confirmed} onChange={set('confirmed')} testIDPrefix="pr-confirmed" options={[{ value: false, label: 'Not yet' }, { value: true, label: 'Checked' }]} />
      </Card>
      <Card>
        <H>Hours and rates</H>
        <Label>Overtime and Sunday rates</Label>
        <Chips value={f.allHoursNormal !== false} onChange={set('allHoursNormal')} testIDPrefix="pr-allnormal" options={[{ value: true, label: 'Off – every hour is a normal hour' }, { value: false, label: 'On – work out overtime and Sunday' }]} />
        {f.allHoursNormal !== false ? <Text style={{ fontSize: 14, color: C.sub }}>All hours worked are paid as normal hours (no overtime, no Sunday rate). Public holidays still use the public holiday rate below.</Text> : null}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {num('normalHoursWeek', 'Normal hours a week')}{num('normalHoursDay', 'Normal hours a day (0 = none)')}{num('otMultiplier', 'Overtime × rate')}
          {num('sundayMultiplier', 'Sunday × rate (1 = normal)')}{num('holidayMultiplier', 'Public holiday × rate')}{num('leaveHoursPerDay', 'Paid leave hours a day')}{num('minimumWage', 'Minimum wage $/h')}
        </View>
        <Label>Cash wages for staff with no shop come from</Label>
        <Chips value={f.wagesDefaultShop || 'S1'} onChange={set('wagesDefaultShop')} options={listShops().filter((x) => x.active).map((x) => ({ value: x.code, label: x.code }))} />
        <Text style={{ fontSize: 14, color: C.sub }}>Everyone else is paid from their own shop's cash. The cash on hand goes down by itself when the pay run is made final.</Text>
        <Label>Pay by bank comes out of</Label>
        <Chips value={f.wagesBankAccount || ''} onChange={set('wagesBankAccount')} options={[{ value: '', label: 'Not recorded' }].concat(listAccounts().map((a) => ({ value: a.uid, label: a.name })))} />
        <Label>Salaried staff are paid overtime</Label>
        <Chips value={!!f.salaryOvertime} onChange={set('salaryOvertime')} options={[{ value: false, label: 'No' }, { value: true, label: 'Yes' }]} />
        <Label>Timesheet must be ticked as checked before paying</Label>
        <Chips value={f.needCheckedTimesheets} onChange={set('needCheckedTimesheets')} options={[{ value: true, label: 'Warn if not' }, { value: false, label: 'No' }]} />
      </Card>
      <Card>
        <H>FNPF</H>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{num('fnpfEmployeePct', 'Employee %')}{num('fnpfEmployerPct', 'Employer %')}</View>
      </Card>
      <Card>
        <H>PAYE (yearly income brackets)</H>
        {f.taxBrackets.map((b, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 2 }}><Field label={i === f.taxBrackets.length - 1 ? 'Above (no limit)' : 'Up to $ a year'} value={b.upTo} onChangeText={(v) => set('taxBrackets')(f.taxBrackets.map((x, k) => (k === i ? { ...x, upTo: v } : x)))} keyboardType="decimal-pad" /></View>
            <View style={{ flex: 1 }}><Field label="Rate %" value={b.rate} onChangeText={(v) => set('taxBrackets')(f.taxBrackets.map((x, k) => (k === i ? { ...x, rate: v } : x)))} keyboardType="decimal-pad" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('taxBrackets')(f.taxBrackets.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Bracket" size="sm" variant="secondary" onPress={() => set('taxBrackets')(f.taxBrackets.slice(0, -1).concat([{ upTo: '', rate: '' }], f.taxBrackets.slice(-1)))} />
        <Label>Social Responsibility Tax (on top, for high incomes)</Label>
        {f.srtBrackets.map((b, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 2 }}><Field label="On income over $" value={b.over} onChangeText={(v) => set('srtBrackets')(f.srtBrackets.map((x, k) => (k === i ? { ...x, over: v } : x)))} keyboardType="decimal-pad" /></View>
            <View style={{ flex: 1 }}><Field label="Rate %" value={b.rate} onChangeText={(v) => set('srtBrackets')(f.srtBrackets.map((x, k) => (k === i ? { ...x, rate: v } : x)))} keyboardType="decimal-pad" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('srtBrackets')(f.srtBrackets.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ SRT band" size="sm" variant="secondary" onPress={() => set('srtBrackets')(f.srtBrackets.concat([{ over: '', rate: '' }]))} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{num('nonResidentRate', 'Non-resident flat %')}{num('noTinRate', 'No TIN: at least %')}</View>
        <Label>Staff FNPF is taken off before working out PAYE</Label>
        <Chips value={f.fnpfReducesTax} onChange={set('fnpfReducesTax')} options={[{ value: false, label: 'No' }, { value: true, label: 'Yes' }]} />
      </Card>
      <Card>
        <H>Public holidays</H>
        {f.publicHolidays.map((h, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
            <View style={{ flex: 2, minWidth: 220 }}><DateField label="Date" farDays={false} quick={false} value={h.date} onChange={(v) => set('publicHolidays')(f.publicHolidays.map((x, k) => (k === i ? { ...x, date: v } : x)))} /></View>
            <View style={{ flex: 2 }}><Field label="Name" value={h.name} onChangeText={(v) => set('publicHolidays')(f.publicHolidays.map((x, k) => (k === i ? { ...x, name: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('publicHolidays')(f.publicHolidays.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Holiday" size="sm" variant="secondary" onPress={() => set('publicHolidays')(f.publicHolidays.concat([{ date: '', name: '' }]))} />
        <Text style={{ fontSize: 14, color: C.sub }}>Add the ones that change each year (Girmit Day, Ratu Sukuna Day, Prophet Mohammed's Birthday, Diwali, Constitution Day) when they are announced.</Text>
      </Card>
      <Card>
        <Field label="Allowance types (one per line)" value={f.allowanceTypes} onChangeText={set('allowanceTypes')} multiline />
        <Field label="Deduction types (one per line)" value={f.deductionTypes} onChangeText={set('deductionTypes')} multiline />
      </Card>
    </Screen>
  );
}

// Staff see their own payslips (final pay runs only).
export function MyPayslipsScreen() {
  const { user, nav } = useApp();
  const rows = db().all(`SELECT l.uid, l.net, l.gross, r.week_start, r.pay_date FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 ORDER BY r.week_start DESC LIMIT 60`, [user.uid]);
  return (
    <Screen title="My payslips">
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>No payslips yet.</Text> : null}
      {rows.map((l) => <ListItem key={l.uid} onPress={() => nav.push('PayLine', { uid: l.uid })} title={`Paid ${l.pay_date}`} sub={`Week ${l.week_start} · gross ${$(l.gross)}`} right={$(l.net)} />)}
    </Screen>
  );
}
