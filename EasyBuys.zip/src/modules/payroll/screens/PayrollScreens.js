// Payroll screens: overview, pay run, one person's pay (change with a reason / payslip), pay details,
// advances & staff loans, payroll rules (rates, tax, FNPF, holidays), and staff's own payslips.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Action, Actions, Explain } from '../../../ui/kit.js';
import { payChanges, statAlerts } from '../statutory.js';
import { dateStr, addDays, weekStart } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import * as P from '../service.js';
import { listAccounts } from '../../payables/service.js';
import { db } from '../../../db/connection.js';

const { $, r2 } = P;
const STATUS = { draft: ['Draft – can be changed', C.warn], final: ['Final', C.success], void: ['Void', C.sub] };
const hrs = (h) => (h ? `${h} h` : '—');

export function PayrollHomeScreen() {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = P.payRules();
  const runs = P.listRuns().slice(0, 20);
  const last = weekStart(addDays(dateStr(), -7));
  const make = (d) => { try { const r = P.createRun(user, d); nav.push('PayRun', { uid: r.uid }); } catch (e) { ui.error(e); } };
  let stat = { late: [], dueSoon: [] };
  try { stat = statAlerts(); } catch (e) { /* none yet */ }
  return (
    <Screen title="Payroll" subtitle="Weeks Saturday to Friday, paid Saturday">
      {!rules.confirmed ? <Banner testID="pay-unconfirmed" tone="warn" title="Check the tax and FNPF figures" message="The PAYE brackets, FNPF rates, minimum wage and public holidays are set up but must be checked against FRCS / FNPF before real pay runs. Payroll › Rules." /> : null}
      {can('payroll_run') ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          <Btn testID="pay-new-last" title={`Pay run for ${last} – ${addDays(last, 6)}`} icon="💰" variant="success" style={{ flexGrow: 1 }} onPress={() => make(last)} />
          <Btn title="This week" size="md" variant="secondary" onPress={() => make(dateStr())} />
        </View>
      ) : null}
      {stat.late.length ? <Banner tone="danger" title="FNPF / PAYE payment late" message={stat.late.map((x) => `${x.kind.toUpperCase()} ${x.period}: ${$(x.amount)} was due ${x.due_date}`).join('\n')} /> : null}
      {stat.dueSoon.length ? <Banner tone="warn" title="FNPF / PAYE due soon" message={stat.dueSoon.map((x) => `${x.kind.toUpperCase()} ${x.period}: ${$(x.amount)} due ${x.due_date}`).join('\n')} /> : null}
      <Section title="Every month">
        <Actions>
          <Action testID="pay-stat" icon="🏦" title="FNPF & PAYE payments" note="What is owed to FNPF and FRCS each month, when it is due, record the payment, see it reach the bank." onPress={() => nav.push('Statutory')} />
          {can('payroll_run') ? <Action testID="pay-debts" icon="🤝" title="Advances & staff loans" note="Money given to staff before pay day or lent – taken back from pay a bit each week." onPress={() => nav.push('StaffDebts')} /> : null}
          {can('payroll_run') ? <Action icon="👋" title="Someone leaving" note="Final pay: leave not taken, advances still owing." onPress={() => nav.push('FinalPay')} /> : null}
          {can('statutory') ? <Action icon="📅" title="Year end" note="PAYE year-end reconciliation and each person's pay & tax certificate." onPress={() => nav.push('PayYearEnd')} /> : null}
        </Actions>
      </Section>
      {can('payroll_setup') ? (
        <Section title="Setup">
          <Actions>
            <Action testID="pay-profiles" icon="🪪" title="Pay details" note="Each person's rate or salary, FNPF and TIN numbers, cash or bank, allowances." onPress={() => nav.push('PayProfiles')} />
            <Action testID="pay-rules" icon="⚙️" title="Rules, tax, FNPF, holidays" note="Overtime, PAYE brackets, FNPF %, minimum wage and public holidays." onPress={() => nav.push('PayRules')} />
          </Actions>
        </Section>
      ) : null}
      <Section title="Pay runs">
        {!runs.length ? <Text style={{ fontSize: 16, color: C.sub }}>No pay runs yet.</Text> : null}
        {runs.map((r) => (
          <ListItem key={r.uid} testID={`run-${r.week_start}`} onPress={() => nav.push('PayRun', { uid: r.uid })} title={`Week ${r.week_start} – ${r.week_end}`}
            sub={`Paid ${r.pay_date} · ${r.totals.people || 0} people · gross ${$(r.totals.gross || 0)}${r.totals.warnings ? ` · ${r.totals.warnings} to look at` : ''}`}
            right={$(r.totals.net || 0)} rightSub="net" badge={STATUS[r.status][0].split(' –')[0]} badgeColor={STATUS[r.status][1]} />
        ))}
      </Section>
    </Screen>
  );
}

export function PayRunScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const act = useAct();
  const [reason, setReason] = useState('');
  const r = P.getRun(params.uid);
  if (!r) return <Screen title="Pay run"><Text>Not found.</Text></Screen>;
  const t = r.totals;
  const draft = r.status === 'draft';
  const cash = P.cashBreakdown(r.lines.filter((l) => l.include && l.pay_method !== 'bank').map((l) => l.net));
  const changes = draft ? payChanges(r.uid) : [];
  const finalise = async () => {
    const warn = r.lines.filter((l) => l.include && l.warnings.length).length;
    const ok = await ui.confirm({ title: 'Make this pay run final?', message: `${t.people} people · net ${$(t.net)}${warn ? `\n\n${warn} line(s) still have warnings.` : ''}\n\nAfter this it cannot be changed (only voided by the owner).`, confirmText: 'Make final', tone: warn ? 'warn' : 'primary' });
    if (ok) act(() => P.finaliseRun(user, r.uid), 'Pay run is final');
  };
  return (
    <Screen title={`Pay week ${r.week_start} – ${r.week_end}`} subtitle={`Pay day ${r.pay_date} · ${STATUS[r.status][0]}`}>
      <Stats items={[{ label: 'Gross', value: $(t.gross) }, { label: 'PAYE', value: $(t.paye) }, { label: 'FNPF staff 8%', value: $(t.fnpfEmployee) }, { label: 'FNPF Easy Buys', value: $(t.fnpfEmployer) },
        { label: 'Net pay', value: $(t.net), color: C.success }, { label: 'Cash / bank', value: `${$(t.cash)} / ${$(t.bank)}` }]} />
      {r.status === 'void' ? <Banner tone="danger" title="Void" message={r.void_reason} /> : null}
      {draft && changes.length ? <Banner tone="warn" title="Check before making final" message={changes.map((c) => `${c.name}: ${c.why}`).join('\n')} /> : null}
      {r.status === 'final' ? <Banner tone="success" title={`Final – ${r.finalised_by_name}`} message={String(r.finalised_at).slice(0, 16)} /> : null}
      {draft && can('payroll_run') ? (
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="run-recalc" title="Work out again from timesheets" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => P.recalcRun(user, r.uid), 'Updated')} />
          <Btn testID="run-final" title="Make final" icon="✅" variant="success" style={{ flexGrow: 1 }} onPress={finalise} />
        </View>
      ) : null}
      <Section title={`People (${r.lines.length})`}>
        {r.lines.map((l) => (
          <ListItem key={l.uid} testID={`line-${l.employee_no || l.name}`} onPress={() => nav.push('PayLine', { uid: l.uid })} title={`${l.name}${l.include ? '' : ' (left out)'}`}
            sub={`${l.pay_type === 'salary' ? 'Salary' : `${$(l.rate)}/h`} · ${hrs(l.hours.normal)}${l.hours.ot ? ` + OT ${l.hours.ot} h` : ''}${l.hours.sunday ? ` · Sun ${l.hours.sunday} h` : ''}${l.hours.holiday ? ` · Hol ${l.hours.holiday} h` : ''}${l.hours.leave ? ` · leave ${l.hours.leave} h` : ''} · gross ${$(l.gross)}${l.edited_by_name ? ' · changed' : ''}`}
            right={$(l.net)} rightSub={l.pay_method === 'bank' ? 'bank' : 'cash'} badge={l.warnings.length ? `${l.warnings.length} ⚠` : null} badgeColor={C.warn} tone={l.net < 0 ? 'danger' : l.warnings.length ? 'warn' : undefined} />
        ))}
      </Section>
      {cash.length ? (
        <Section title="Notes and coins for cash pay (each pay made up exactly)">
          <Text style={{ fontSize: 17, color: C.text }}>{cash.map((c) => `${c.label} × ${c.count}`).join('   ')}</Text>
        </Section>
      ) : null}
      {r.status === 'final' ? <Btn testID="run-sign" title="Staff sign for their pay" icon="✍️" size="md" variant="info" onPress={() => nav.push('PaySign', { runUid: r.uid })} /> : null}
      <Btn title="Payslips & reports" size="md" variant="secondary" onPress={() => nav.push('ReportsHub', { group: 'Payroll' })} />
      {r.status !== 'void' && ['owner', 'admin'].includes(user.role) ? (
        <Card>
          <Field label="Reason to void (then start the week again)" value={reason} onChangeText={setReason} />
          <Btn title="Void pay run" variant="danger" size="sm" style={{ marginTop: 8 }} onPress={() => act(() => P.voidRun(user, r.uid, reason), 'Voided')} />
        </Card>
      ) : null}
    </Screen>
  );
}

export function PayLineScreen({ params }) {
  const { user, can } = useApp();
  const act = useAct();
  const run = P.getRun(String(params.uid).split('|')[0]);
  const l = run && run.lines.find((x) => x.uid === params.uid);
  const rules = P.payRules();
  const [f, setF] = useState(() => (l ? {
    normal: l.overrides.normal ?? '', ot: l.overrides.ot ?? '', sunday: l.overrides.sunday ?? '', holiday: l.overrides.holiday ?? '', leave: l.overrides.leave ?? '', rate: l.overrides.rate ?? '', paye: l.overrides.paye ?? '',
    adjustments: l.adjustments.map((a) => ({ ...a, amount: String(a.amount) })), deductions: l.deductions.filter((d) => d.manual).map((d) => ({ ...d, amount: String(d.amount) })), include: !!l.include, reason: '',
  } : {}));
  if (!l || (!can('payroll_view') && l.user_uid !== user.uid)) return <Screen title="Pay"><Text>Not found.</Text></Screen>;
  const draft = run.status === 'draft' && can('payroll_run');
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const ytd = P.yearToDate(l.user_uid, run.pay_date.slice(0, 4), run.pay_date);
  const E = l.earnings;
  return (
    <Screen title={l.name} subtitle={`Week ${run.week_start} – ${run.week_end} · paid ${run.pay_date}`}
      footer={draft ? <Btn testID="pl-save" title="Save changes" icon="💾" variant="success" onPress={() => act(() => P.editLine(user, l.uid, f), 'Changed')} /> : null}>
      {l.warnings.map((w) => <Banner key={w} tone="warn" message={w} />)}
      {l.edited_by_name ? <Banner tone="info" title={`Changed by ${l.edited_by_name}`} message={l.edit_reason} /> : null}
      <Card>
        <H>Payslip</H>
        <Row label="Employee no" value={l.employee_no || '—'} />
        <Row label="Rate" value={l.pay_type === 'salary' ? 'Salary' : `${$(l.rate)} an hour`} />
        {E.salary !== undefined ? <Row label="Salary" value={$(E.salary)} /> : null}
        {E.normal !== undefined ? <Row label={`Normal ${l.hours.normal} h`} value={$(E.normal)} /> : null}
        {E.ot ? <Row label={`Overtime ${l.hours.ot} h × ${rules.otMultiplier}`} value={$(E.ot)} /> : null}
        {E.sunday ? <Row label={`Sunday ${l.hours.sunday} h × ${rules.sundayMultiplier}`} value={$(E.sunday)} /> : null}
        {E.holiday ? <Row label={`Public holiday ${l.hours.holiday} h × ${rules.holidayMultiplier}`} value={$(E.holiday)} /> : null}
        {E.leave ? <Row label={`Paid leave ${l.hours.leave} h`} value={$(E.leave)} /> : null}
        {l.allowances.map((a, i) => <Row key={`a${i}`} label={`${a.name}${a.taxable === false ? ' (not taxed)' : ''}`} value={$(a.amount)} />)}
        {l.adjustments.map((a, i) => <Row key={`j${i}`} label={a.label} value={$(a.amount)} />)}
        <Row label="Gross pay" value={$(l.gross)} bold />
        <Row label="PAYE tax" value={`− ${$(l.paye)}`} />
        <Row label="FNPF (staff)" value={`− ${$(l.fnpf_employee)}`} />
        {l.deductions.map((d, i) => <Row key={`d${i}`} label={d.label} value={`− ${$(d.amount)}`} />)}
        <Row label="NET PAY" value={$(l.net)} bold color={C.success} />
        <Row label={`Paid by`} value={l.pay_method === 'bank' ? 'Bank' : 'Cash'} />
        <Row label="FNPF paid by Easy Buys" value={$(l.fnpf_employer)} />
        <Row label={`Year to date (${ytd.weeks} weeks)`} value={`gross ${$(ytd.gross)} · PAYE ${$(ytd.paye)} · FNPF ${$(ytd.fnpfEmployee)}`} />
      </Card>
      {draft ? (
        <>
          <Card>
            <H>Change hours or rate (blank = from the timesheet)</H>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {[['normal', 'Normal h'], ['ot', 'Overtime h'], ['sunday', 'Sunday h'], ['holiday', 'Holiday h'], ['leave', 'Leave h'], ['rate', 'Rate $/h'], ['paye', 'PAYE $']].map(([k, label]) => (
                <View key={k} style={{ flexBasis: 140, flexGrow: 1 }}><Field testID={`pl-${k}`} label={label} value={String(f[k])} onChangeText={set(k)} keyboardType="decimal-pad" placeholder={k === 'rate' ? String(l.rate) : k === 'paye' ? String(l.paye) : String(l.hours[k] ?? '')} /></View>
              ))}
            </View>
          </Card>
          <Card>
            <H>Extra pay this week</H>
            {f.adjustments.map((a, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <View style={{ flexBasis: 160, flexGrow: 2 }}><Select label="What" value={a.label} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, label: v } : x)))} options={rules.allowanceTypes.map((x) => ({ value: x, label: x }))} /></View>
                <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField label="Amount" value={a.amount} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
                <Chips value={a.taxable !== false} onChange={(v) => set('adjustments')(f.adjustments.map((x, k) => (k === i ? { ...x, taxable: v } : x)))} options={[{ value: true, label: 'Taxed' }, { value: false, label: 'Not taxed' }]} />
                <Btn title="✕" size="sm" variant="ghost" onPress={() => set('adjustments')(f.adjustments.filter((_, k) => k !== i))} />
              </View>
            ))}
            <Btn testID="pl-add-adj" title="+ Extra pay" size="sm" variant="secondary" onPress={() => set('adjustments')(f.adjustments.concat([{ label: rules.allowanceTypes[0], amount: '' }]))} />
          </Card>
          <Card>
            <H>Deductions this week</H>
            {f.deductions.map((d, i) => (
              <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                <View style={{ flexBasis: 160, flexGrow: 2 }}><Select label="What" value={d.label} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, label: v } : x)))} options={rules.deductionTypes.map((x) => ({ value: x, label: x }))} /></View>
                <View style={{ flexBasis: 110, flexGrow: 1 }}><MoneyField label="Amount" value={d.amount} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
                <Btn title="✕" size="sm" variant="ghost" onPress={() => set('deductions')(f.deductions.filter((_, k) => k !== i))} />
              </View>
            ))}
            <Btn title="+ Deduction" size="sm" variant="secondary" onPress={() => set('deductions')(f.deductions.concat([{ label: rules.deductionTypes[0], amount: '' }]))} />
            <Label>Pay this person in this run</Label>
            <Chips value={f.include} onChange={set('include')} options={[{ value: true, label: 'Yes' }, { value: false, label: 'Leave out' }]} />
            <Field testID="pl-reason" label="Reason for the change (required)" value={f.reason} onChangeText={set('reason')} />
          </Card>
        </>
      ) : null}
    </Screen>
  );
}

export function PayProfilesScreen() {
  const { nav } = useApp();
  const rows = P.listProfiles();
  return (
    <Screen title="Pay details" subtitle="Rate, tax, FNPF, how each person is paid">
      {rows.map((p) => (
        <ListItem key={p.user_uid} testID={`prof-${p.name}`} onPress={() => nav.push('PayProfile', { userUid: p.user_uid })} title={p.name}
          sub={p.hasProfile ? `${p.pay_type === 'salary' ? `Salary ${$(p.weekly_salary)}/week` : `${$(p.rate)}/hour`} · ${p.pay_method}${p.tin ? '' : ' · no TIN'}${p.fnpf_no ? '' : ' · no FNPF no'}${p.active === 0 ? ' · not paid' : ''}` : 'No pay details yet – tap to add'}
          badge={p.hasProfile ? null : 'NEW'} badgeColor={C.info} />
      ))}
    </Screen>
  );
}
export function PayProfileScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const u = listUsers().find((x) => x.uid === params.userUid);
  const p0 = P.getProfile(params.userUid);
  const rules = P.payRules();
  const [f, setF] = useState(() => (p0 ? {
    userUid: params.userUid, payType: p0.pay_type, rate: String(p0.rate || ''), weeklySalary: String(p0.weekly_salary || ''), normalHours: p0.normal_hours == null ? '' : String(p0.normal_hours), jobTitle: p0.job_title || '',
    wageCategory: p0.wage_category || '', fnpfNo: p0.fnpf_no || '', tin: p0.tin || '', taxStatus: p0.tax_status, fnpfMember: !!p0.fnpf_member, fnpfExtraPct: String(p0.fnpf_extra_pct || 0), payMethod: p0.pay_method,
    bankName: p0.bank_name || '', bankAccount: p0.bank_account || '', allowances: p0.allowances.map((a) => ({ ...a, amount: String(a.amount) })), deductions: p0.deductions.map((d) => ({ ...d, amount: String(d.amount) })),
    startDate: p0.start_date || '', endDate: p0.end_date || '', active: !!p0.active, notes: p0.notes || '',
  } : { userUid: params.userUid, payType: 'hourly', rate: String(rules.minimumWage), weeklySalary: '', normalHours: '', jobTitle: '', wageCategory: 'Shop assistant', fnpfNo: '', tin: '', taxStatus: 'resident', fnpfMember: true,
    fnpfExtraPct: '0', payMethod: 'cash', bankName: 'BSP', bankAccount: '', allowances: [], deductions: [], startDate: dateStr(), endDate: '', active: true, notes: '' }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  if (!u) return <Screen title="Pay details"><Text>Not found.</Text></Screen>;
  return (
    <Screen title={u.name} subtitle="Pay details" footer={<Btn testID="prof-save" title="Save" icon="💾" variant="success" onPress={() => { if (act(() => P.saveProfile(user, f), 'Saved')) nav.pop(); }} />}>
      <Card>
        <Chips value={f.payType} onChange={set('payType')} testIDPrefix="prof-type" options={[{ value: 'hourly', label: 'Paid by the hour' }, { value: 'salary', label: 'Weekly salary' }]} />
        {f.payType === 'hourly' ? <MoneyField testID="prof-rate" label="Hourly rate" value={f.rate} onChange={set('rate')} /> : <MoneyField testID="prof-salary" label="Weekly salary" value={f.weeklySalary} onChange={set('weeklySalary')} />}
        {f.payType === 'hourly' && Number(f.rate) < rules.minimumWage ? <Banner tone="warn" message={`Below the minimum wage (${$(rules.minimumWage)}).`} /> : null}
        <Field label={`Normal hours a week (blank = ${rules.normalHoursWeek})`} value={f.normalHours} onChangeText={set('normalHours')} keyboardType="decimal-pad" />
        <Field label="Job title" value={f.jobTitle} onChangeText={set('jobTitle')} />
        <Field label="Wage category (minimum wage group)" value={f.wageCategory} onChangeText={set('wageCategory')} />
      </Card>
      <Card>
        <H>Tax and FNPF</H>
        <Field testID="prof-tin" label="TIN" value={f.tin} onChangeText={set('tin')} keyboardType="number-pad" />
        <Chips value={f.taxStatus} onChange={set('taxStatus')} options={[{ value: 'resident', label: 'Resident' }, { value: 'non_resident', label: 'Non-resident' }]} />
        <Field testID="prof-fnpf" label="FNPF number" value={f.fnpfNo} onChangeText={set('fnpfNo')} />
        <Chips value={f.fnpfMember} onChange={set('fnpfMember')} options={[{ value: true, label: 'Pays FNPF' }, { value: false, label: 'No FNPF' }]} />
        <Field label="Extra FNPF % chosen by the employee" value={f.fnpfExtraPct} onChangeText={set('fnpfExtraPct')} keyboardType="decimal-pad" />
      </Card>
      <Card>
        <H>Paid by</H>
        <Chips value={f.payMethod} onChange={set('payMethod')} testIDPrefix="prof-method" options={[{ value: 'cash', label: 'Cash' }, { value: 'bank', label: 'Bank' }]} />
        {f.payMethod === 'bank' ? <><Field label="Bank" value={f.bankName} onChangeText={set('bankName')} /><Field label="Account number" value={f.bankAccount} onChangeText={set('bankAccount')} /></> : null}
      </Card>
      <Card>
        <H>Every week</H>
        <Label>Allowances</Label>
        {f.allowances.map((a, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 150, flexGrow: 2 }}><Select label="What" value={a.name} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, name: v } : x)))} options={rules.allowanceTypes.map((x) => ({ value: x, label: x }))} /></View>
            <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField label="Amount" value={a.amount} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Chips value={a.taxable !== false} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, taxable: v } : x)))} options={[{ value: true, label: 'Taxed' }, { value: false, label: 'Not taxed' }]} />
            <Chips value={a.fnpf !== false} onChange={(v) => set('allowances')(f.allowances.map((x, k) => (k === i ? { ...x, fnpf: v } : x)))} options={[{ value: true, label: 'FNPF' }, { value: false, label: 'No FNPF' }]} />
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('allowances')(f.allowances.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Allowance" size="sm" variant="secondary" onPress={() => set('allowances')(f.allowances.concat([{ name: rules.allowanceTypes[0], amount: '' }]))} />
        <Label>Regular deductions</Label>
        {f.deductions.map((d, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 150, flexGrow: 2 }}><Select label="What" value={d.name} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, name: v } : x)))} options={rules.deductionTypes.map((x) => ({ value: x, label: x }))} /></View>
            <View style={{ flexBasis: 100, flexGrow: 1 }}><MoneyField label="Amount" value={d.amount} onChange={(v) => set('deductions')(f.deductions.map((x, k) => (k === i ? { ...x, amount: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('deductions')(f.deductions.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Deduction" size="sm" variant="secondary" onPress={() => set('deductions')(f.deductions.concat([{ name: rules.deductionTypes[0], amount: '' }]))} />
      </Card>
      <Card>
        <DateField label="Started" value={f.startDate} onChange={set('startDate')} />
        <DateField label="Finished (blank = still working)" value={f.endDate} onChange={set('endDate')} />
        <Chips value={f.active} onChange={set('active')} options={[{ value: true, label: 'On the payroll' }, { value: false, label: 'Not paid' }]} />
        <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
      </Card>
    </Screen>
  );
}

export function StaffDebtsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState(null);
  const [showAll, setShowAll] = useState(false);
  const debts = P.listDebts({ open: !showAll });
  const people = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  return (
    <Screen title="Advances & staff loans" subtitle="Taken back from pay each week until repaid">
      {f ? (
        <Card>
          <Chips value={f.kind} onChange={(v) => setF({ ...f, kind: v })} testIDPrefix="debt-kind" options={[{ value: 'advance', label: 'Advance' }, { value: 'loan', label: 'Staff loan' }]} />
          <Select testID="debt-person" label="Staff member" value={f.userUid} onChange={(v) => setF({ ...f, userUid: v })} options={people.map((u) => ({ value: u.uid, label: u.name }))} />
          <MoneyField testID="debt-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
          <MoneyField testID="debt-repay" label="Take back each week" value={f.repayPerPay} onChange={(v) => setF({ ...f, repayPerPay: v })} />
          <DateField label="Date given" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field testID="debt-reason" label="Reason" value={f.reason} onChangeText={(v) => setF({ ...f, reason: v })} />
          <Label>Given from</Label>
          <Chips value={f.paidFrom} onChange={(v) => setF({ ...f, paidFrom: v })} options={[{ value: 'cash', label: 'Shop cash' }, { value: 'bank', label: 'Bank' }]} />
          {f.paidFrom === 'cash' ? <Chips value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} options={listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }))} /> : null}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="debt-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => P.giveDebt(user, f), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="debt-add" title="Give an advance or loan" icon="➕" variant="success" onPress={() => setF({ kind: 'advance', userUid: '', amount: '', repayPerPay: '', date: dateStr(), reason: '', paidFrom: 'cash', shopCode: user.shop_code || 'S1' })} />}
      <Chips value={showAll} onChange={setShowAll} options={[{ value: false, label: 'Still owing' }, { value: true, label: 'All' }]} />
      {debts.map((d) => <ListItem key={d.uid} title={`${d.name} · ${d.kind === 'loan' ? 'Staff loan' : 'Advance'}`} sub={`${d.debt_date} · ${d.reason || ''} · ${$(d.repay_per_pay)} a week · given by ${d.given_by_name}`} right={$(d.balance)} rightSub={`of ${$(d.amount)}`} />)}
      {!debts.length ? <Text style={{ fontSize: 16, color: C.sub }}>Nothing owing.</Text> : null}
    </Screen>
  );
}

export function PayRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = P.payRules();
  const [f, setF] = useState(() => ({ ...r0, taxBrackets: r0.taxBrackets.map((b) => ({ upTo: b.upTo === null ? '' : String(b.upTo), rate: String(b.rate) })),
    srtBrackets: (r0.srtBrackets || []).map((b) => ({ over: String(b.over), rate: String(b.rate) })), publicHolidays: r0.publicHolidays.slice(), allowanceTypes: r0.allowanceTypes.join('\n'), deductionTypes: r0.deductionTypes.join('\n') }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const num = (k, label) => <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID={`pr-${k}`} label={label} value={String(f[k])} onChangeText={set(k)} keyboardType="decimal-pad" /></View>;
  return (
    <Screen title="Payroll rules" subtitle="For every device · check with FRCS / FNPF" footer={<Btn testID="pr-save" title="Save" icon="💾" variant="success" onPress={() => act(() => P.savePayRules(user, f), 'Saved')} />}>
      <Card tone={f.confirmed ? 'success' : 'warn'}>
        <Label>I have checked these figures against FRCS and FNPF</Label>
        <Chips value={f.confirmed} onChange={set('confirmed')} testIDPrefix="pr-confirmed" options={[{ value: false, label: 'Not yet' }, { value: true, label: 'Checked' }]} />
      </Card>
      <Card>
        <H>Hours and rates</H>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {num('normalHoursWeek', 'Normal hours a week')}{num('normalHoursDay', 'Normal hours a day (0 = none)')}{num('otMultiplier', 'Overtime × rate')}
          {num('sundayMultiplier', 'Sunday × rate (1 = normal)')}{num('holidayMultiplier', 'Public holiday × rate')}{num('leaveHoursPerDay', 'Paid leave hours a day')}{num('minimumWage', 'Minimum wage $/h')}
        </View>
        <Label>Cash wages for staff with no shop come from</Label>
        <Chips value={f.wagesDefaultShop || 'S1'} onChange={set('wagesDefaultShop')} options={listShops().filter((x) => x.active).map((x) => ({ value: x.code, label: x.code }))} />
        <Text style={{ fontSize: 14, color: C.sub }}>Everyone else is paid from their own shop's cash. The cash on hand goes down by itself when the pay run is made final.</Text>
        <Label>Pay by bank comes out of</Label>
        <Chips value={f.wagesBankAccount || ''} onChange={set('wagesBankAccount')} options={[{ value: '', label: 'Not recorded' }].concat(listAccounts().map((a) => ({ value: a.uid, label: a.name })))} />
        <Label>Salaried staff are paid overtime</Label>
        <Chips value={!!f.salaryOvertime} onChange={set('salaryOvertime')} options={[{ value: false, label: 'No' }, { value: true, label: 'Yes' }]} />
        <Label>Timesheet must be ticked as checked before paying</Label>
        <Chips value={f.needCheckedTimesheets} onChange={set('needCheckedTimesheets')} options={[{ value: true, label: 'Warn if not' }, { value: false, label: 'No' }]} />
      </Card>
      <Card>
        <H>FNPF</H>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{num('fnpfEmployeePct', 'Employee %')}{num('fnpfEmployerPct', 'Employer %')}</View>
      </Card>
      <Card>
        <H>PAYE (yearly income brackets)</H>
        {f.taxBrackets.map((b, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 2 }}><Field label={i === f.taxBrackets.length - 1 ? 'Above (no limit)' : 'Up to $ a year'} value={b.upTo} onChangeText={(v) => set('taxBrackets')(f.taxBrackets.map((x, k) => (k === i ? { ...x, upTo: v } : x)))} keyboardType="decimal-pad" /></View>
            <View style={{ flex: 1 }}><Field label="Rate %" value={b.rate} onChangeText={(v) => set('taxBrackets')(f.taxBrackets.map((x, k) => (k === i ? { ...x, rate: v } : x)))} keyboardType="decimal-pad" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('taxBrackets')(f.taxBrackets.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Bracket" size="sm" variant="secondary" onPress={() => set('taxBrackets')(f.taxBrackets.slice(0, -1).concat([{ upTo: '', rate: '' }], f.taxBrackets.slice(-1)))} />
        <Label>Social Responsibility Tax (on top, for high incomes)</Label>
        {f.srtBrackets.map((b, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 2 }}><Field label="On income over $" value={b.over} onChangeText={(v) => set('srtBrackets')(f.srtBrackets.map((x, k) => (k === i ? { ...x, over: v } : x)))} keyboardType="decimal-pad" /></View>
            <View style={{ flex: 1 }}><Field label="Rate %" value={b.rate} onChangeText={(v) => set('srtBrackets')(f.srtBrackets.map((x, k) => (k === i ? { ...x, rate: v } : x)))} keyboardType="decimal-pad" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('srtBrackets')(f.srtBrackets.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ SRT band" size="sm" variant="secondary" onPress={() => set('srtBrackets')(f.srtBrackets.concat([{ over: '', rate: '' }]))} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{num('nonResidentRate', 'Non-resident flat %')}{num('noTinRate', 'No TIN: at least %')}</View>
        <Label>Staff FNPF is taken off before working out PAYE</Label>
        <Chips value={f.fnpfReducesTax} onChange={set('fnpfReducesTax')} options={[{ value: false, label: 'No' }, { value: true, label: 'Yes' }]} />
      </Card>
      <Card>
        <H>Public holidays</H>
        {f.publicHolidays.map((h, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 1 }}><Field label="Date" value={h.date} onChangeText={(v) => set('publicHolidays')(f.publicHolidays.map((x, k) => (k === i ? { ...x, date: v } : x)))} placeholder="YYYY-MM-DD" /></View>
            <View style={{ flex: 2 }}><Field label="Name" value={h.name} onChangeText={(v) => set('publicHolidays')(f.publicHolidays.map((x, k) => (k === i ? { ...x, name: v } : x)))} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => set('publicHolidays')(f.publicHolidays.filter((_, k) => k !== i))} />
          </View>
        ))}
        <Btn title="+ Holiday" size="sm" variant="secondary" onPress={() => set('publicHolidays')(f.publicHolidays.concat([{ date: '', name: '' }]))} />
        <Text style={{ fontSize: 14, color: C.sub }}>Add the ones that change each year (Girmit Day, Ratu Sukuna Day, Prophet Mohammed's Birthday, Diwali, Constitution Day) when they are announced.</Text>
      </Card>
      <Card>
        <Field label="Allowance types (one per line)" value={f.allowanceTypes} onChangeText={set('allowanceTypes')} multiline />
        <Field label="Deduction types (one per line)" value={f.deductionTypes} onChangeText={set('deductionTypes')} multiline />
      </Card>
    </Screen>
  );
}

// Staff see their own payslips (final pay runs only).
export function MyPayslipsScreen() {
  const { user, nav } = useApp();
  const rows = db().all(`SELECT l.uid, l.net, l.gross, r.week_start, r.pay_date FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 ORDER BY r.week_start DESC LIMIT 60`, [user.uid]);
  return (
    <Screen title="My payslips">
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>No payslips yet.</Text> : null}
      {rows.map((l) => <ListItem key={l.uid} onPress={() => nav.push('PayLine', { uid: l.uid })} title={`Paid ${l.pay_date}`} sub={`Week ${l.week_start} · gross ${$(l.gross)}`} right={$(l.net)} />)}
    </Screen>
  );
}
