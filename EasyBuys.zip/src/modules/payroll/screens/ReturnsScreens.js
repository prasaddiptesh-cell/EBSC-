// v3.9 Returns screens: the list of months (VAT / FNPF) and one return – worked out from the records, checked,
// documents (PDF, Excel, CSV), 1) lodge (a frozen copy; amendments keep the old one), 2) pay (cheque from the cheque
// books, transfer or cash – booked in the accounts and the bank) or record the refund. History at the bottom.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Table, useApp, useUI } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { fillEmpty } from '../../../services/paperRead.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { actsAsOwner } from '../../../services/access.js';
import { shareReport } from '../../../platform/files.js';
import { shareFilingTable } from '../../../platform/payShare.js';
import { ChequeNoPicker } from '../../payables/screens/ChequePicker.js';
import { moneyOptions } from '../../accounting/full.js';
import * as RT from '../returns.js';
import * as TX from '../taxCalendar.js';
import { vatReturnReport, vatInputScheduleReport, fnpfScheduleReport } from '../returnsReports.js';

const { $ } = RT;
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const ymLabel = (ym) => `${MONTHS[Number(ym.slice(5, 7)) - 1]} ${ym.slice(0, 4)}`;
const pad = (n) => String(n).padStart(2, '0');
const ymAdd = (ym, n) => { const t = Number(ym.slice(0, 4)) * 12 + Number(ym.slice(5, 7)) - 1 + n; return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`; };
const lastYm = () => ymAdd(dateStr().slice(0, 7), -1);
const TONE = { bad: 'danger', warn: 'warn', ok: 'success', info: 'info' };
const pdf = (ui, rep) => shareReport(rep, 'pdf').catch((e) => ui.error(e));
const xlsx = (ui, rep) => shareReport(rep, 'xlsx').catch((e) => ui.error(e));

function statusBadge(st) {
  if (st.flags.some((f) => f.key === 'changed')) return ['Changed – amend', C.danger];
  if (st.flags.some((f) => f.key === 'short')) return ['Paid short', C.danger];
  if (st.refund && st.lodged) return [st.file.refund_date ? 'Refund received' : 'Refund due', C.success];
  if (st.lodged && st.item.paid) return ['Lodged & paid', C.success];
  if (st.lodged) return ['Lodged – to pay', C.warn];
  if (st.item.paid) return ['Paid – not lodged', C.danger];
  if (st.flags.some((f) => f.key === 'late')) return ['LATE', C.danger];
  return ['To lodge', C.info];
}

// ---------------------------------------------------------------- the list
export function TaxReturnsScreen({ params = {} }) {
  const { nav } = useApp();
  const [kind, setKind] = useState(params.kind || 'vat');
  const [ym, setYm] = useState(lastYm());
  let list = [];
  try { list = RT.returnsList(kind, { months: 12 }); } catch (e) { list = []; }
  return (
    <Screen title="VAT & FNPF returns" subtitle="Work out · check · lodge · pay">
      <Chips value={kind} onChange={setKind} testIDPrefix="rl-kind" options={[{ value: 'vat', label: '🧾 VAT return (FRCS)' }, { value: 'fnpf', label: '👥 FNPF schedule' }]} />
      <Explain>
        {kind === 'vat'
          ? 'Each month the app fills the FRCS VAT return (lines 1–13) and the VAT Input Schedule from the End of days and the supplier invoices. Lodge it on TPOS, record the lodgement here, then pay – the payment is booked in the accounts and the bank. Due by the last day of the next month.'
          : "Each month the app fills FNPF's Contribution Schedule from the final pay runs (paid in that month). Lodge it by the 14th of the next month and pay by the end of that month – the payment is booked in Payroll and the bank."}
      </Explain>
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <Btn testID="rl-prev" title="‹" size="sm" variant="secondary" onPress={() => setYm(ymAdd(ym, -1))} />
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, minWidth: 130, textAlign: 'center' }}>{ymLabel(ym)}</Text>
        <Btn testID="rl-next" title="›" size="sm" variant="secondary" onPress={() => setYm(ymAdd(ym, 1))} />
        <Btn testID="rl-open" title="Open this month" size="md" variant="info" onPress={() => nav.push('TaxReturn', { kind, period: ym })} />
      </View>
      <Section title="Recent months">
        {list.map((st) => {
          const [b, col] = statusBadge(st);
          return (
            <ListItem key={st.period} testID={`rl-${kind}-${st.period}`} title={`${ymLabel(st.period)} · ${st.refund ? 'refund ' : ''}${$(Math.abs(st.owed))}`}
              sub={`${kind === 'fnpf' ? `Schedule by ${st.lodgeDue} · pay by ${st.payDue}` : `Due ${st.payDue}`}${st.lodged ? ` · lodged v${st.lodged.version}` : ''}`} badge={b} badgeColor={col}
              onPress={() => nav.push('TaxReturn', { kind, period: st.period })} />
          );
        })}
        {!list.length ? <Hint>Nothing yet – months with sales, invoices or pay runs show here.</Hint> : null}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- one return
export function TaxReturnScreen({ params = {} }) {
  const { user, nav, refresh } = useApp();
  const ui = useUI();
  const act = useAct();
  const kind = RT.RETURN_KINDS[params.kind] ? params.kind : 'vat';
  const period = params.period || lastYm();
  const [tick, setTick] = useState(0);
  const again = () => { setTick(tick + 1); if (refresh) refresh(); };
  let st;
  try { st = RT.returnStatus(kind, period); } catch (e) { return <Screen title="Return"><Banner tone="danger" message={e.message} /></Screen>; }
  const may = RT.canFileReturn(user, kind);
  const now = st.now;
  return (
    <Screen title={`${RT.RETURN_KINDS[kind].title} ${ymLabel(period)}`} subtitle={`${RT.RETURN_KINDS[kind].form} · to ${RT.RETURN_KINDS[kind].to}`}>
      <Card>
        <Row label={kind === 'fnpf' ? 'Schedule due (CS due date)' : 'Return and payment due'} value={st.lodgeDue} />
        {kind === 'fnpf' ? <Row label="Payment due" value={st.payDue} /> : null}
        <Row label={st.refund ? 'Refund due from FRCS' : st.lodged ? `Owed (lodged version ${st.lodged.version})` : 'Owed (worked out now)'} value={$(Math.abs(st.owed))} bold color={st.refund ? C.success : C.danger} />
        {st.item.paid ? <Row label="Paid" value={`${$(st.paidAmount)} on ${st.file.paid_date || (st.item.row && st.item.row.paid_at) || ''}`} color={C.success} /> : null}
      </Card>
      {st.flags.map((f, i) => <Banner key={i} testID={`tr-flag-${f.key}`} tone={TONE[f.level] || 'info'} message={f.text} />)}

      {kind === 'vat' ? <VatBody st={st} user={user} may={may} act={act} again={again} /> : <FnpfBody st={st} />}

      <Section title="Checks before lodging">
        {now.checks.map((c, i) => <Banner key={i} testID={`tr-check-${i}`} tone={TONE[c.level] || 'info'} message={c.text} />)}
      </Section>

      <Section title="Documents">
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          {kind === 'vat' ? (
            <>
              <Btn testID="tr-pdf" title="VAT return (PDF)" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => pdf(ui, vatReturnReport(period))} />
              <Btn testID="tr-sched" title="Input schedule (Excel)" icon="📊" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => xlsx(ui, vatInputScheduleReport(period))} />
            </>
          ) : (
            <>
              <Btn testID="tr-pdf" title="Contribution schedule (PDF)" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => pdf(ui, fnpfScheduleReport(period))} />
              <Btn testID="tr-xlsx" title="FNPF columns (Excel)" icon="📊" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { const t = RT.fnpfTable(period); shareFilingTable({ fileName: `FNPF-Contribution-Schedule-${period}`, headers: t.headers, rows: t.rows, fileType: 'xlsx' }).catch((e) => ui.error(e)); }} />
              <Btn testID="tr-csv" title="CSV" icon="🧾" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { const t = RT.fnpfTable(period); shareFilingTable({ fileName: `FNPF-Contribution-Schedule-${period}`, headers: t.headers, rows: t.rows, fileType: 'csv' }).catch((e) => ui.error(e)); }} />
            </>
          )}
        </View>
        <Hint>{kind === 'vat' ? 'The PDF has every line of the FRCS form and the Input Schedule. Type the same figures into TPOS.' : 'The Excel / CSV has exactly the columns of the FNPF Contribution Schedule.'}</Hint>
      </Section>

      <LodgeCard st={st} user={user} may={may} act={act} again={again} />
      <PayCard st={st} user={user} may={may} act={act} again={again} />

      <Section title="Lodged versions">
        {st.versions.map((v) => (
          <ListItem key={v.uid} testID={`tr-v${v.version}`} title={`Version ${v.version} · ${$(v.amount)}`} sub={`Lodged ${v.lodged_at} by ${v.lodged_by_name}${v.lodge_ref ? ` · ref ${v.lodge_ref}` : ''}${v.status === 'superseded' ? ` · replaced (${v.superseded_reason || ''})` : ''}`}
            badge={v.status === 'lodged' ? 'Current' : 'Replaced'} badgeColor={v.status === 'lodged' ? C.success : C.sub}
            onPress={() => pdf(ui, kind === 'vat' ? vatReturnReport(period, { version: v.version }) : fnpfScheduleReport(period, { version: v.version }))} />
        ))}
        {!st.versions.length ? <Hint>Not lodged yet.</Hint> : <Hint>Tap a version for its PDF exactly as it was lodged.</Hint>}
      </Section>
      <Btn testID="tr-item" title="Proofs & full history (tax calendar)" icon="🗓️" size="md" variant="ghost" onPress={() => nav.push('TaxItem', { kind, period })} />
    </Screen>
  );
}

// build 42 (owner, 10 Nov: "I want to see what is calculated for the VAT return – all linked and related, transparent,
// it needs to show what all is part of the calculation"): every line opens what makes it up – each End of day / till
// count, each supplier invoice, each credit note, each typed correction – and each of those opens its own record.
// Lines that are sums show their sum with the figures. What is left out (no TIN, not checked) is shown with why.
const LINE_SUM = { 3: [[1, 1], [2, -1]], 6: [[4, 1], [5, 1]], 10: [[7, 1], [8, 1], [9, 1]], 12: [[10, 1], [11, -1]], 13: [[6, 1], [12, -1]] };
function VatLineDetail({ n, v, nav }) {
  const L = v.lines;
  const go = (r) => (r && r.go ? () => nav.push(r.go[0], r.go[1]) : undefined);
  const sale = (r, k, amt) => <ListItem key={`${k}`} testID={`vat-src-${n}-${k}`} title={`${r.date} · ${r.shop} · ${r.ref || ''}`} sub={`total ${$(r.total)}${r.zero ? ` · zero-rated ${$(r.zero)}` : ''}${r.typed ? '' : ''}`} right={$(amt)} onPress={go(r)} />;
  const inv = (r, k, why) => <ListItem key={`${k}`} testID={`vat-src-${n}-${k}`} title={`${r.date} · ${r.supplier || ''} ${r.no ? `#${r.no}` : ''}`.trim()} sub={why || `TIN ${r.tin || '—'} · total ${$(r.total)}`} right={$(Math.abs(r.vat))} tone={why ? 'warn' : undefined} onPress={go(r)} />;
  const rows = v.saleRows || [];
  const adj = (k) => (v.adjust && v.adjust[k] && Number(v.adjust[k].amount) ? <Row label={`Typed in: ${v.adjust[k].note || '(no note)'}`} value={$(v.adjust[k].amount)} /> : null);
  const sum = LINE_SUM[n];
  return (
    <Card testID={`vat-detail-${n}`}>
      <H>{`Line ${n} – what makes ${$(L[n])}`}</H>
      {sum ? <Text style={{ fontSize: 16, color: C.text }}>{sum.map(([m, sg], i) => `${i ? (sg < 0 ? ' − ' : ' + ') : ''}line ${m} ${$(L[m])}`).join('')}{` = ${$(L[n])}`}</Text> : null}
      {n === 1 ? <>
        <Hint>{`${rows.length} sale record(s) – every Aronium End of day of the month (balanced or not), each till balance not already in one, and sales typed in. Tap one to open it.`}</Hint>
        {rows.map((r, k) => sale(r, k, r.total))}
        {(v.missingDays || []).length ? <><Text style={{ fontSize: 15, fontWeight: '800', color: C.danger, marginTop: 8 }}>{`No End of day at all (${v.missingDays.length} shop-day${v.missingDays.length === 1 ? '' : 's'})`}</Text><Hint>{`${v.missingDays.join(', ')} – these days' sales are NOT in line 1. Get the End of day (Aronium › Send everything again) or type the sales.`}</Hint></> : null}
      </> : null}
      {n === 2 ? <><Hint>The zero-rated part of each sale record (rice, flour, sugar… no VAT).</Hint>{rows.filter((r) => r.zero).map((r, k) => sale(r, k, r.zero))}{!rows.some((r) => r.zero) ? <Hint>No zero-rated sales recorded – check the End of days split them.</Hint> : null}</> : null}
      {n === 4 ? <><Text style={{ fontSize: 16, color: C.text }}>{`line 3 ${$(L[3])} × ${v.fraction} = ${$(L[4])}`}</Text><Hint>{`Aronium's own VAT on the End of days comes to ${$(v.sales && v.sales.output)}.`}</Hint></> : null}
      {n === 5 ? <>{(v.credits || []).map((r, k) => inv(r, k, `credit note · VAT ${$(Math.abs(r.vat))}`))}{!(v.credits || []).length ? <Hint>No credit notes received this month.</Hint> : null}{adj('l5')}</> : null}
      {n === 7 ? <>
        <Hint>{`${v.schedule.length} supplier tax invoice(s) with a TIN – the VAT Input Schedule.`}</Hint>
        {v.schedule.map((r, k) => inv(r, k))}
        {(v.noTin || []).length ? <><Text style={{ fontSize: 15, fontWeight: '800', color: C.warn, marginTop: 8 }}>{`Left out – no supplier TIN (${$(v.noTin.reduce((t, x) => t + x.vat, 0))})`}</Text>{v.noTin.map((r, k) => inv(r, `nt${k}`, 'no TIN – add it on the supplier to claim this VAT'))}</> : null}
        {(v.toCheck || []).length ? <><Text style={{ fontSize: 15, fontWeight: '800', color: C.danger, marginTop: 8 }}>{`Not checked yet (${v.toCheck.length})`}</Text>{v.toCheck.map((r, k) => inv(r, `tc${k}`, 'to check – check it so it counts for sure'))}</> : null}
      </> : null}
      {[8, 9, 11].includes(n) ? (adj(`l${n}`) || <Hint>Nothing typed in for this line.</Hint>) : null}
    </Card>
  );
}
function VatBody({ st, user, may, act, again }) {
  const v = st.now;
  const { nav } = useApp();
  const [open, setOpen] = useState(null);
  const [edit, setEdit] = useState(false);
  const [adj, setAdj] = useState(() => Object.fromEntries(Object.keys(RT.VAT_ADJUST_LINES).map((k) => [k, { amount: v.adjust[k] ? String(v.adjust[k].amount) : '', note: v.adjust[k] ? v.adjust[k].note : '' }])));
  const setA = (k, f) => (val) => setAdj((o) => ({ ...o, [k]: { ...o[k], [f]: val } }));
  const tk = v.ticks;
  return (
    <>
      {tk ? (
        <Card tone={tk.all ? 'success' : 'warn'}>
          <H>{tk.all ? '✅ Every entry checked' : `☐ ${tk.done} of ${tk.total} entries checked`}</H>
          <Text testID="tr-ticks" style={{ fontSize: 15, color: C.text }}>{`Sales days: ${tk.daysDone} of ${tk.days} · Invoices: ${tk.invoicesDone} of ${tk.invoices}. The app works the return out by itself – a person ticks each entry so nothing wrong goes to FRCS.`}</Text>
          <Btn testID="tr-check-entries" title={tk.all ? 'See the entries' : 'Check the entries'} icon="☑️" variant={tk.all ? 'secondary' : 'primary'} size="md" onPress={() => nav.push('MonthRecords', { ym: st.period, shop: tk.firstLeft ? tk.firstLeft.shop : undefined, date: tk.firstLeft ? tk.firstLeft.date : undefined })} />
        </Card>
      ) : null}
      <Section title={`The return (VAT ${v.rate}%, tax fraction ${v.fraction})`}>
        {(() => {
          const rows = v.saleRows || [];
          const eods = rows.filter((r) => r.aronium).length; const tills = rows.filter((r) => !r.aronium && !r.typed && r.go && r.go[0] === 'TillCountView').length; const typed = rows.length - eods - tills;
          return (
            <Card testID="vat-how">
              <H>How this return was worked out</H>
              <Text style={{ fontSize: 15, color: C.text, lineHeight: 22 }}>{[
                `Sales: ${$(v.lines[1])} from ${eods} Aronium End of day${eods === 1 ? '' : 's'}${tills ? `, ${tills} till balance${tills === 1 ? '' : 's'}` : ''}${typed > 0 ? ` and ${typed} sale${typed === 1 ? '' : 's'} typed in` : ''} – every End of day of the month counts, balanced or not.`,
                `Zero-rated part: ${$(v.lines[2])} (no VAT on it), so VAT applies to ${$(v.lines[3])}.`,
                `VAT on sales: ${$(v.lines[3])} × ${v.fraction} = ${$(v.lines[4])}${v.lines[5] ? `, plus ${$(v.lines[5])} adjustments (credit notes received${v.adjust && v.adjust.l5 && Number(v.adjust.l5.amount) ? ' and a typed correction' : ''})` : ''}.`,
                `VAT on purchases: ${$(v.lines[7])} from ${v.schedule.length} supplier invoice${v.schedule.length === 1 ? '' : 's'} with a TIN${v.lines[8] ? `, ${$(v.lines[8])} customs VAT` : ''}${v.lines[9] ? `, ${$(v.lines[9])} other` : ''}.`,
                (v.noTin || []).length ? `Left out: ${$(v.noTin.reduce((t, x) => t + x.vat, 0))} VAT on ${v.noTin.length} invoice${v.noTin.length === 1 ? '' : 's'} with no supplier TIN.` : '',
                (v.missingDays || []).length ? `Missing: ${v.missingDays.length} shop-day${v.missingDays.length === 1 ? '' : 's'} with no End of day – their sales are not in.` : '',
                `${v.lines[13] >= 0 ? 'To pay FRCS' : 'Refund due'}: ${$(v.lines[6])} − ${$(v.lines[12])} = ${$(Math.abs(v.lines[13]))}.`,
              ].filter(Boolean).join('\n')}</Text>
            </Card>
          );
        })()}
        <Hint>Tap a line to see everything that makes it up.</Hint>
        {RT.VAT_LINES.map(([n, label]) => (
          <ListItem key={n} testID={`tr-line-${n}`} title={`${n}. ${label}`} right={$(v.lines[n])} tone={open === n ? 'success' : undefined} onPress={() => setOpen(open === n ? null : n)} />
        ))}
        {open ? <VatLineDetail n={open} v={v} nav={nav} /> : null}
        <Hint>{`Line 7 is the VAT on ${v.schedule.length} supplier tax invoice(s) with a TIN.${v.creditVat ? ` Line 5 includes credit notes received (${$(v.creditVat)}).` : ''}`}</Hint>
      </Section>
      {may ? (
        edit ? (
          <Card>
            <H>Lines the app cannot see</H>
            <Hint>Customs VAT on imports (IM4), and corrections. Each needs a note.</Hint>
            {Object.entries(RT.VAT_ADJUST_LINES).map(([k, n]) => (
              <View key={k} style={{ gap: 4 }}>
                <MoneyField testID={`tr-adj-${n}`} label={`Line ${n}: ${RT.VAT_LINES.find((x) => x[0] === n)[1]}`} value={adj[k].amount} onChange={setA(k, 'amount')} />
                {Number(adj[k].amount) ? <Field testID={`tr-adj-${n}-note`} label={`What line ${n} is for`} value={adj[k].note} onChangeText={setA(k, 'note')} /> : null}
              </View>
            ))}
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(false)} />
              <Btn testID="tr-adj-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => RT.saveVatAdjust(user, st.period, adj), 'Saved')) { setEdit(false); again(); } }} />
            </View>
          </Card>
        ) : <Btn testID="tr-adj" title="Customs VAT / corrections (lines 5, 8, 9, 11)" icon="✏️" size="md" variant="secondary" onPress={() => setEdit(true)} />
      ) : null}
    </>
  );
}

function FnpfBody({ st }) {
  const s = st.now;
  return (
    <Section title={`Members (${s.rows.length})`}>
      <Card>
        <Row label="Employer reference no." value={s.employer.refNo || 'NOT SET'} color={s.employer.refNo ? undefined : C.danger} />
        <Row label="Total contributions" value={$(s.totals.contributions)} bold />
        <Row label="Total wages" value={$(s.totals.wages)} />
        <Row label="Employee share / employer share" value={`${$(s.totals.employee)} / ${$(s.totals.employer)}`} />
      </Card>
      <Table testID="tr-members" columns={[{ key: 'name', title: 'Member' }, { key: 'no', title: 'FNPF no.', width: 90 }, { key: 'gross', title: 'Wages', align: 'right', width: 90 }, { key: 'total', title: 'Total', align: 'right', width: 90 }]}
        rows={s.rows.map((r) => ({ name: `${r.first}${r.middle ? ` ${r.middle}` : ''} ${r.last}`.trim(), no: r.memberNo || 'MISSING', gross: $(r.gross), total: $(r.total), _tone: r.memberNo ? null : 'bad' }))} />
      <Hint>Family members who do not take FNPF are left off (set in Payroll › person).</Hint>
    </Section>
  );
}

function LodgeCard({ st, user, may, act, again }) {
  const [f, setF] = useState({ date: dateStr(), ref: '', photos: [], note: '' });
  const ui = useUI();
  const lp = usePaper('lodgement');
  const LODGE_MAP = { ref: 'ref', date: 'date' };
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const changed = st.flags.some((x) => x.key === 'changed');
  const need = !st.lodged || changed;
  const blocked = st.now.blocking.length > 0;
  const go = (extra = {}) => { if (!lp.okToSave(ui)) return; if (act(() => RT.lodgeReturn(user, st.kind, st.period, { ...f, ...extra }), st.lodged ? 'Amended return lodged' : 'Lodged')) { lp.log(user, 'tax_returns', `${st.kind}-${st.period}`, f, LODGE_MAP); lp.reset(); setF({ date: dateStr(), ref: '', photos: [], note: '' }); again(); } };
  const lodgedAmt = lp.read ? lp.read.fields.amount : undefined;
  return (
    <Card tone={st.lodged && !changed ? 'success' : undefined}>
      <H>1. Lodge</H>
      {st.lodged ? <Row label={`Lodged (version ${st.lodged.version})`} value={`${st.lodged.lodged_at} · ${st.lodged.lodge_ref || ''}`} /> : null}
      {need && may ? (
        <View style={{ gap: 6 }}>
          {changed ? <Hint>The figures changed since it was lodged: lodge the amended return with FRCS / FNPF, then record it here (version {st.lodged.version + 1}).</Hint> : null}
          <PaperPhoto pr={lp} testID="tr-lodge-photo" label="Screenshot / photo of the lodgement receipt" value={f.photos} onChange={set('photos')} form={f} setForm={setF} map={LODGE_MAP} soft={{ date: dateStr() }}
            labels={{ ref: 'Receipt / reference number', date: 'Date lodged' }} hint="Take the photo (or pick the screenshot) first – the reference number and date fill in.">
            {lodgedAmt !== undefined && Math.abs(Math.abs(lodgedAmt) - Math.abs(st.owed)) > 0.05 ? <Banner testID="tr-lodge-amtdiff" tone="warn" message={`The receipt shows ${$(lodgedAmt)} but this ${st.kind === 'vat' ? 'return' : 'schedule'} comes to ${$(Math.abs(st.owed))}. Is it the right receipt, or were different figures lodged?`} /> : null}
          </PaperPhoto>
          <DateField farDays={false} label="Date lodged" value={f.date} onChange={set('date')} />
          <Field testID="tr-lodge-ref" label={`${RT.RETURN_KINDS[st.kind].to} receipt / reference number`} value={f.ref} onChangeText={set('ref')} />
          <Field label="Note (optional)" value={f.note} onChangeText={set('note')} />
          {blocked ? <Banner tone="danger" message="Fix the problems marked FIX above first." /> : null}
          {!blocked ? <Btn testID="tr-lodge" title={st.lodged ? 'Record the amended return' : 'Record the lodgement'} icon="📨" variant="success" size="md" onPress={() => go()} /> : null}
          {blocked && isTop(user) ? <ReasonButton testID="tr-lodge-force" title="Lodge anyway (owner / admin)" prompt="Why is it lodged with these problems?" confirm="Lodge" variant="warn" onDo={(w) => go({ force: true, reason: w })} /> : null}
        </View>
      ) : null}
      {need && !may ? <Hint>Only the owner, admin or the responsible person can lodge it.</Hint> : null}
    </Card>
  );
}

function PayCard({ st, user, may, act, again }) {
  const money = moneyOptions();
  const banks = money.filter((m) => m.value.startsWith('bank:'));
  const cash = money.filter((m) => m.value.startsWith('cash:'));
  const [f, setF] = useState({ date: dateStr(), amount: st.owed > 0 ? String(st.owed) : '', method: 'transfer', via: banks[0] ? banks[0].value : '', chequeNo: '', ref: '', penalty: '', photos: [], note: '' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const ui = useUI();
  const pp = usePaper('proof');
  const PAY_MAP = { ref: 'ref', date: 'date', chequeNo: 'chequeNo' };
  const proofAmt = pp.read ? pp.read.fields.amount : undefined;
  const setMethod = (m) => setF((o) => ({ ...o, method: m, via: m === 'cash' ? (cash[0] || {}).value || 'cash' : (banks[0] || {}).value || '', chequeNo: '' }));
  const late = st.penalty.total > 0;
  const file = st.file || {};
  if (st.refund) {
    return (
      <Card tone={file.refund_date ? 'success' : undefined}>
        <H>2. Refund from FRCS</H>
        {file.refund_date ? <Row label="Refund received" value={`${$(file.refund_amount)} on ${file.refund_date}`} /> : may ? (
          <View style={{ gap: 6 }}>
            <Hint>Nothing to pay this month. When FRCS pays the refund into the bank, record it here.</Hint>
            <DateField farDays={false} label="Date received" value={f.date} onChange={set('date')} />
            <MoneyField testID="tr-refund-amount" label="Amount received" value={f.amount || String(-st.owed)} onChange={set('amount')} />
            <Select testID="tr-refund-via" label="Into" value={f.via} onChange={set('via')} options={banks} />
            <Field label="Reference" value={f.ref} onChangeText={set('ref')} />
            <Btn testID="tr-refund-save" title="Record the refund" icon="💰" variant="success" size="md" onPress={() => { if (act(() => RT.recordVatRefund(user, st.period, { date: f.date, amount: f.amount || -st.owed, via: f.via, ref: f.ref }), 'Refund recorded')) again(); }} />
          </View>
        ) : null}
      </Card>
    );
  }
  return (
    <Card tone={st.item.paid && !(st.short > 0.004) ? 'success' : undefined}>
      <H>2. Pay</H>
      {file.pay_link ? (
        <View>
          <Row label="Paid" value={`${$(file.paid_amount)} on ${file.paid_date}`} />
          <Row label="How" value={`${file.pay_method === 'cheque' ? 'Cheque' : file.pay_method === 'cash' ? 'Cash' : 'Bank transfer'} · ${file.pay_ref || ''}`} />
          {file.penalty_amount ? <Row label="Penalty paid" value={$(file.penalty_amount)} /> : null}
          <Row label="Booked in" value={st.kind === 'vat' ? 'Accounting (VAT account) and the bank' : 'Payroll › FNPF payments and the bank'} />
          {may ? <ReasonButton testID="tr-pay-undo" title="Take the payment back (recorded by mistake)" prompt="Why?" confirm="Take back" onDo={(w) => { if (act(() => RT.undoReturnPayment(user, st.kind, st.period, w), 'Taken back')) again(); }} /> : null}
        </View>
      ) : st.item.paid ? (
        <Hint>A payment was recorded in the tax calendar or Payroll › FNPF payments before this screen existed. See "Proofs & full history".</Hint>
      ) : may ? (
        <View style={{ gap: 6 }}>
          {!st.lodged ? <Hint>You can pay before lodging; remember to lodge too.</Hint> : null}
          <PaperPhoto pr={pp} testID="tr-pay-photo" label="Photo of the receipt / transfer / cheque stub" value={f.photos} onChange={set('photos')} form={f} setForm={setF}
            apply={(form, x, prev) => { const r = fillEmpty(form, x, PAY_MAP, prev, { date: dateStr() }); if (x.chequeNo && form.method !== 'cheque') { r.form.method = 'cheque'; } return r; }}
            labels={{ ref: 'Reference', date: 'Date paid', chequeNo: 'Cheque number' }} hint="Take the photo first – the reference, date and cheque number fill in, and the amount is compared.">
            {proofAmt !== undefined && Math.abs(proofAmt - Number(f.amount || 0)) > 0.004 ? <Banner testID="tr-pay-amtdiff" tone="warn" message={`The receipt shows ${$(proofAmt)} but the amount below is ${$(Number(f.amount || 0))}.`} /> : null}
            {proofAmt !== undefined && Math.abs(proofAmt - Number(f.amount || 0)) <= 0.004 ? <Banner testID="tr-pay-amtok" tone="success" message={`The receipt agrees: ${$(proofAmt)}.`} /> : null}
          </PaperPhoto>
          <DateField farDays={false} label="Date paid" value={f.date} onChange={set('date')} />
          <MoneyField testID="tr-pay-amount" label="Amount paid" value={f.amount} onChange={set('amount')} />
          <Chips value={f.method} onChange={setMethod} testIDPrefix="tr-pay-method" options={[{ value: 'transfer', label: '🏦 Bank transfer' }, { value: 'cheque', label: '📝 Cheque' }, { value: 'cash', label: '💵 Cash' }]} />
          <Select testID="tr-pay-via" label={f.method === 'cash' ? 'Cash from' : 'Bank account'} value={f.via} onChange={(v) => setF((o) => ({ ...o, via: v, chequeNo: '' }))} options={f.method === 'cash' ? cash : banks} />
          {f.method === 'cheque' ? <ChequeNoPicker testID="tr-pay-chq" accountUid={String(f.via).startsWith('bank:') ? f.via.slice(5) : ''} value={f.chequeNo} onChange={set('chequeNo')} /> : null}
          <Field testID="tr-pay-ref" label={f.method === 'cheque' ? 'Receipt number (optional)' : f.method === 'cash' ? 'Receipt number' : 'Bank transfer reference'} value={f.ref} onChangeText={set('ref')} />
          {late ? <MoneyField testID="tr-pay-penalty" label={`Penalty paid as well (estimate ${$(st.penalty.total)})`} value={f.penalty} onChange={set('penalty')} /> : null}
          <Field label="Note (optional)" value={f.note} onChangeText={set('note')} />
          <Btn testID="tr-pay" title={`Record the payment${f.method === 'cheque' && f.chequeNo ? ` – cheque ${f.chequeNo}` : ''}`} icon="💸" variant="success" size="md"
            onPress={() => { if (!pp.okToSave(ui)) return; if (act(() => RT.payReturn(user, st.kind, st.period, { ...f, ref: f.method === 'cheque' ? f.ref || '' : f.ref }), 'Payment recorded')) { pp.log(user, 'tax_returns', `${st.kind}-${st.period}`, f, PAY_MAP); pp.reset(); again(); } }} />
        </View>
      ) : <Hint>Only the owner, admin or the responsible person can record the payment.</Hint>}
    </Card>
  );
}
