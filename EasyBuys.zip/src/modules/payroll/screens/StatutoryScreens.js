// FNPF and PAYE payments (owed, due, paid, seen in the bank), year-end figures, and final pay for someone leaving.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, Table, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { shareReport } from '../../../platform/files.js';
import { listAccounts } from '../../payables/service.js';
import { listUsers } from '../../../services/catalog.js';
import * as S from '../statutory.js';
import { monthRuns } from '../payRunSteps.js';
import { fnpfScheduleReport, yearEndReport, certificateReport } from '../statReports.js';

const { $ } = S;
const STATE_COLOR = { nothing: C.sub, to_pay: C.info, due_soon: C.warn, late: C.danger, paid: C.warn, verified: C.success };

export function StatutoryScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const [open, setOpen] = useState(null);
  const accounts = listAccounts();
  const [f, setF] = useState({});
  const months = S.statOverview({ months: 12 });
  const r = S.statRules();
  const [dd, setDd] = useState({ fnpfDueDay: String(r.fnpfDueDay), payeDueDay: String(r.payeDueDay), payChangePct: String(r.payChangePct) });
  return (
    <Screen title="FNPF & PAYE payments" subtitle="Owed from the pay runs, paid, and seen in the bank">
      <Explain>
        Every pay run takes FNPF (staff 8%, and Easy Buys adds the employer share – 8% from 1 August 2026) and PAYE / SRT tax from wages. That money belongs to FNPF and FRCS and must be paid to them every month.{'\n\n'}
        Step 1: when you pay, record it here (bank reference or receipt number, and a photo of the receipt).{'\n'}
        Step 2: it is verified when it shows on the bank statement (bank reconciliation or To verify).{'\n\n'}
        Late payments attract penalties, so anything late shows in red on the home screen.
      </Explain>
      {!months.length ? <Text style={{ color: C.sub }}>No final pay runs yet.</Text> : null}
      {months.map(({ ym, items }) => (
        <Section key={ym} title={ym}>
          {(() => {
            const runs = monthRuns(ym);
            return runs.length ? (
              <Card>
                <Text style={{ fontSize: 15, fontWeight: '800', color: C.sub }}>PAY RUNS PAID IN {ym} ({runs.length})</Text>
                {runs.map((x) => (
                  <View key={x.uid} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}>
                    <Text style={{ flex: 1, color: C.text }}>{x.run_kind === 'extra' ? `${x.label || 'Extra'} · ` : x.run_kind === 'catchup' ? 'Paid later · ' : ''}{x.week_start} – {x.week_end} · paid {x.pay_date} · {x.people} people</Text>
                    <Text style={{ color: C.text, fontWeight: '700' }}>FNPF {$(x.fnpf)} · PAYE {$(x.paye)}</Text>
                  </View>
                ))}
              </Card>
            ) : null;
          })()}
          {items.filter((s) => s.changedSincePaid).map((s) => <Banner key={`ch-${s.uid}`} tone="warn" title={`${s.kind === 'fnpf' ? 'FNPF' : 'PAYE'} owed has changed by ${$(s.changedSincePaid)} since you paid`} message="A pay run in this month was corrected or added after the payment. Pay the difference (or ask for a refund) and record it." />)}
          {items.map((s) => (
            <View key={s.uid} style={{ gap: 6 }}>
              <ListItem testID={`stat-${s.uid}`} onPress={() => { setOpen(open === s.uid ? null : s.uid); setF({ date: dateStr(), amount: String(s.amount), method: 'transfer', accountUid: accounts[0] ? accounts[0].uid : '', reference: '', receiptNo: '', photos: [] }); }}
                title={s.kind === 'fnpf' ? 'FNPF (staff + employer)' : 'PAYE / SRT'} sub={`due ${s.due_date}${s.paid_date ? ` · paid ${s.paid_date} by ${s.by_name}${s.reference ? ` · ref ${s.reference}` : ''}${s.receipt_no ? ` · receipt ${s.receipt_no}` : ''}` : ''}${s.cleared ? ` · in the bank ${s.cleared}` : ''}`}
                right={$(s.amount)} rightSub={s.paid_date && Math.abs(s.short) > 0.004 ? `paid ${$(s.paid_amount)}` : ''} badge={S.STAT_STATE[s.state]} badgeColor={STATE_COLOR[s.state]} tone={s.state === 'late' ? 'danger' : undefined} />
              {open === s.uid ? (
                <Card>
                  {s.kind === 'fnpf' ? <Btn title="FNPF schedule (who, how much)" icon="📄" size="sm" variant="secondary" onPress={() => Promise.resolve().then(() => shareReport(fnpfScheduleReport(ym), 'xlsx')).catch((e) => ui.error(e))} /> : null}
                  {!s.paid_date && can('statutory') ? (
                    <>
                      <DateField label="Paid on" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
                      <MoneyField testID="stat-amount" label="Amount paid" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
                      <Chips value={f.method} onChange={(v) => setF({ ...f, method: v })} testIDPrefix="stat-m" options={[{ value: 'transfer', label: 'Bank transfer / online' }, { value: 'cheque', label: 'Cheque' }, { value: 'cash', label: 'Cash at the counter' }]} />
                      {f.method !== 'cash' ? <Select label="From bank account" value={f.accountUid} onChange={(v) => setF({ ...f, accountUid: v })} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
                      <Field testID="stat-ref" label="Bank reference / cheque no." value={f.reference} onChangeText={(v) => setF({ ...f, reference: v })} />
                      <Field label={s.kind === 'fnpf' ? 'FNPF receipt no.' : 'FRCS receipt no.'} value={f.receiptNo} onChangeText={(v) => setF({ ...f, receiptNo: v })} />
                      {s.kind === 'fnpf' ? <DateField label="Schedule sent to FNPF on" optional value={f.scheduleSent || ''} onChange={(v) => setF({ ...f, scheduleSent: v })} /> : null}
                      <PhotoPicker value={f.photos} onChange={(v) => setF({ ...f, photos: v })} label="Photo of the receipt" />
                      <Btn testID="stat-pay" title="Record the payment" icon="💾" variant="success" onPress={() => { if (act(() => S.payStat(user, s.uid, f), 'Recorded – it is verified when it shows in the bank')) setOpen(null); }} />
                    </>
                  ) : null}
                  {s.paid_date && can('statutory') ? <ReasonButton title="Undo this payment" prompt="Why?" confirm="Undo" onDo={(w) => act(() => S.undoStatPayment(user, s.uid, w), 'Undone')} /> : null}
                </Card>
              ) : null}
            </View>
          ))}
        </Section>
      ))}
      {can('payroll_setup') ? (
        <Section title="Due dates">
          <Hint>Day of the following month the payment is due (0 = the last day). Check the current dates with FNPF and FRCS.</Hint>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="FNPF due day" value={dd.fnpfDueDay} onChangeText={(v) => setDd({ ...dd, fnpfDueDay: v })} keyboardType="number-pad" /></View>
            <View style={{ flexBasis: 160, flexGrow: 1 }}><Field label="PAYE due day" value={dd.payeDueDay} onChangeText={(v) => setDd({ ...dd, payeDueDay: v })} keyboardType="number-pad" /></View>
            <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag pay changes over (%)" value={dd.payChangePct} onChangeText={(v) => setDd({ ...dd, payChangePct: v })} keyboardType="number-pad" /></View>
          </View>
          <Btn title="Save" size="md" variant="success" onPress={() => act(() => S.saveStatRules(user, dd), 'Saved')} />
        </Section>
      ) : null}
    </Screen>
  );
}

export function YearEndScreen() {
  const ui = useUI();
  const [year, setYear] = useState(String(Number(dateStr().slice(0, 4)) - (dateStr().slice(5, 7) <= '03' ? 1 : 0)));
  const y = S.yearEnd(year);
  return (
    <Screen title="Year-end PAYE & FNPF" subtitle={`Year ${year} (January–December)`}>
      <Chips value={year} onChange={setYear} options={[0, 1, 2].map((k) => String(Number(dateStr().slice(0, 4)) - k))} />
      <Explain>After the year ends, FRCS needs the employer's year-end PAYE reconciliation, and each staff member gets a certificate of their pay and tax for the year. This screen adds up every final pay run and compares it with what was paid to FRCS and FNPF.</Explain>
      <Stats items={[
        { label: 'Gross pay', value: $(y.gross) }, { label: 'PAYE taken', value: $(y.paye), sub: `paid to FRCS ${$(y.payePaid)}` },
        { label: 'PAYE not paid', value: $(y.payeDiff), color: Math.abs(y.payeDiff) > 0.004 ? C.danger : C.success },
        { label: 'FNPF not paid', value: $(y.fnpfDiff), color: Math.abs(y.fnpfDiff) > 0.004 ? C.danger : C.success },
      ]} />
      <Table columns={[{ key: 'name', title: 'Name', width: 180 }, { key: 'tin', title: 'TIN' }, { key: 'gross', title: 'Gross', align: 'right' }, { key: 'paye', title: 'PAYE', align: 'right' }, { key: 'fnpf', title: 'FNPF 8%', align: 'right' }]}
        rows={y.people.map((p) => ({ name: p.name, tin: p.tin || '—', gross: $(p.gross), paye: $(p.paye), fnpf: $(p.fnpfEmployee) }))} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn title="Reconciliation (Excel)" icon="📊" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => Promise.resolve().then(() => shareReport(yearEndReport(year), 'xlsx')).catch((e) => ui.error(e))} />
        <Btn title="All certificates (PDF)" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => Promise.resolve().then(() => shareReport(certificateReport(year), 'pdf')).catch((e) => ui.error(e))} />
      </View>
    </Screen>
  );
}

export function FinalPayScreen() {
  const { nav } = useApp();
  const ui = useUI();
  const staff = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const [who, setWho] = useState('');
  const [last, setLast] = useState(dateStr());
  let s = null;
  let err = null;
  try { s = who ? S.finalPaySummary(who, { lastDay: last }) : null; } catch (e) { err = e.message; }
  return (
    <Screen title="Final pay – someone leaving" subtitle="What is still owed to them and by them">
      <Explain>When someone leaves: their last week is paid in the normal pay run. Add the annual leave not taken (paid out) as extra pay on their line, and their advances / loans still owing are taken from it. Then switch their login off in Staff.</Explain>
      <Select label="Who is leaving?" value={who} onChange={setWho} options={[{ value: '', label: 'Choose' }].concat(staff.map((u) => ({ value: u.uid, label: u.name })))} />
      <DateField farDays={false} label="Last day of work" value={last} onChange={setLast} />
      {err ? <Banner tone="warn" message={err} /> : null}
      {s ? (
        <Card>
          <Row label="Pay for one day" value={$(s.dayRate)} />
          {s.leavePay.map((l) => <Row key={l.type} label={`${l.type}: ${l.days} day(s) not taken`} value={$(l.amount)} />)}
          <Row label="Leave to pay out" value={$(s.leaveTotal)} bold />
          {s.debts.map((d, i) => <Row key={i} label={`${d.label} (${d.date}) still owing`} value={$(d.owing)} color={C.danger} />)}
          <Row label="They still owe" value={$(s.debtTotal)} bold color={s.debtTotal ? C.danger : undefined} />
          <Hint>Open the pay run for their last week, tap their name, add "Leave paid out" as extra pay ({$(s.leaveTotal)}) – advances and loans are taken off by themselves (change the amount there if all of it should come off).</Hint>
          <Btn title="Open Payroll" size="md" variant="info" onPress={() => nav.push('Payroll')} />
        </Card>
      ) : null}
    </Screen>
  );
}
