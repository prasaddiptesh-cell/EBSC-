// 1.0.0 (build 1) payroll for the new office and staff (map screens rep-pay, rep-fnpf, s-mypay).
// Exported for the new shell: PayWeekScreen, PayslipCleanScreen, MyPayScreen, FnpfMonthScreen.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Section, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, useAct } from '../../../ui/kit.js';
import { can } from '../../../services/access.js';
import * as PV from '../v1Pay.js';
import * as P from '../service.js';
import { MonthPicker, $ } from '../../accounting/screens/V1Screens.js';
import * as V from '../../accounting/v1.js';

const tryRun = (f) => { try { return f(); } catch (e) { return { error: e.message || String(e) }; } };
const dm = (d) => (d ? `${Number(d.slice(8, 10))} ${V.MONTHS[Number(d.slice(5, 7)) - 1]}` : '');

// The clean payslip: hours, pay, FNPF, staff credit, till short, net.
function Payslip({ s, testID }) {
  return (
    <Card>
      <View testID={testID} style={{ gap: 8 }}>
        {s.rows.map((r) => (
          <View key={r.key} style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: r.strong ? 2 : 0, borderTopColor: C.border, paddingTop: r.strong ? 8 : 0 }}>
            <Text style={{ fontSize: r.strong ? 20 : 17, fontWeight: r.strong ? '900' : '700', color: C.text }}>{r.label}</Text>
            <Text style={{ fontSize: r.strong ? 20 : 17, fontWeight: r.strong ? '900' : '700', color: r.amount < 0 ? C.danger : C.text }}>{r.amount === undefined ? r.value : $(r.amount)}</Text>
          </View>
        ))}
      </View>
    </Card>
  );
}

// ---------------------------------------------------------------- My pay (s-mypay)
export function MyPayScreen() {
  const { user, nav } = useApp();
  const m = useMemo(() => tryRun(() => PV.myPay(user)), [user && user.uid]);
  const s = m.latest;
  return (
    <Screen title="My pay" subtitle={s ? `week ${dm(s.weekStart)} – ${dm(s.weekEnd)}` : ''}>
      {m.error ? <Banner tone="danger" message={m.error} /> : null}
      {!s ? <Hint>No payslip yet. It shows here after the first pay day.</Hint> : <Payslip s={s} testID="mypay-slip" />}
      {s && s.tillShort ? <Hint>The till short was agreed by you at the end of your shift.</Hint> : null}
      {(m.earlier || []).length ? (
        <Section title="Earlier weeks">
          {m.earlier.map((x) => <ListItem key={x.lineUid} title={`${dm(x.weekStart)} – ${dm(x.weekEnd)}`} sub={`paid ${x.payDate}`} right={$(x.net)} onPress={() => nav.push('PayslipClean', { lineUid: x.lineUid })} />)}
        </Section>
      ) : null}
    </Screen>
  );
}
export function PayslipCleanScreen({ params = {} }) {
  const { user, nav } = useApp();
  const s = useMemo(() => tryRun(() => PV.cleanPayslip(params.lineUid || '')), [params.lineUid]);
  const mine = s && !s.error && user && s.userUid === user.uid;
  const sees = can(user, 'payroll_view') || can(user, 'payroll_run');
  if (!s || s.error || (!mine && !sees)) return <Screen title="Payslip"><Banner tone="danger" message={s && s.error ? s.error : 'Payslip not found.'} /></Screen>;
  return (
    <Screen title={s.name} subtitle={`week ${dm(s.weekStart)} – ${dm(s.weekEnd)} · paid ${s.payDate}`}>
      <Payslip s={s} testID="payslip-clean" />
      {s.fnpfOff ? <Hint>FNPF is switched off for this person (family).</Hint> : null}
      {sees ? <Btn testID="payslip-details" title="All the details (payroll only)" size="md" variant="secondary" onPress={() => nav.push('PayLine', { uid: s.lineUid })} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Payroll this week (rep-pay)
export function PayWeekScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [n, bump] = useState(0);
  const runs = useMemo(() => tryRun(() => P.listRuns().filter((r) => (r.run_kind || 'regular') === 'regular').slice(0, 12)), [n]);
  const [runUid, setRunUid] = useState(params.runUid || null);
  const w = useMemo(() => tryRun(() => PV.payWeek(runUid)), [runUid, n]);
  if (!w) return <Screen title="Payroll"><Hint>No pay run yet. Make the first one in Payroll.</Hint><Btn testID="pw-payroll" title="Open Payroll" size="md" variant="secondary" onPress={() => nav.push('Payroll', {})} /></Screen>;
  if (w.error) return <Screen title="Payroll"><Banner tone="danger" message={w.error} /></Screen>;
  const idx = Array.isArray(runs) ? runs.findIndex((r) => r.uid === w.run.uid) : -1;
  const approve = () => { if (act(() => P.finaliseRun(user, w.run.uid), 'Pay approved')) bump((x) => x + 1); };
  return (
    <Screen title={`Pay week ${dm(w.run.weekStart)} – ${dm(w.run.weekEnd)}`} subtitle={`${w.run.status === 'final' ? 'paid' : 'to pay'} ${w.run.payDate}`}
      footer={w.run.status === 'draft' && can(user, 'payroll_run') ? <Btn testID="pw-approve" title="Approve pay" icon="✅" variant="primary" onPress={approve} /> : null}>
      {Array.isArray(runs) && runs.length > 1 ? (
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 10 }}>
          <Btn testID="pw-older" title="‹ Earlier week" size="sm" variant="secondary" disabled={idx < 0 || idx >= runs.length - 1} onPress={() => setRunUid(runs[idx + 1].uid)} />
          <Btn testID="pw-newer" title="Later week ›" size="sm" variant="secondary" disabled={idx <= 0} onPress={() => setRunUid(runs[idx - 1].uid)} />
        </View>
      ) : null}
      <Banner tone={w.run.status === 'final' ? 'success' : 'warn'} message={w.run.status === 'final' ? 'Approved – payslips issued.' : 'Not approved yet. The staff profile sets each person\'s pay; check and approve.'} />
      {w.lines.map((l) => <ListItem key={l.lineUid} testID={`pw-line-${l.userUid}`} title={l.name} sub={[l.staffCredit ? `staff credit ${$(l.staffCredit)}` : '', l.tillShort ? `till short ${$(l.tillShort)}` : '', l.fnpfOff ? 'no FNPF (family)' : ''].filter(Boolean).join(' · ') || undefined} right={$(l.net)} onPress={() => nav.push('PayslipClean', { lineUid: l.lineUid })} />)}
      <ListItem testID="pw-credit" title="Staff credit taken off (Aronium)" right={$(w.staffCredit)} />
      <ListItem testID="pw-fnpf" title="FNPF total (staff + employer)" right={$(w.fnpfTotal)} />
      <ListItem testID="pw-net" title="Net pay" right={$(w.net)} tone="success" />
      {w.warnings.length ? <Banner tone="warn" title={`${w.warnings.length} thing${w.warnings.length === 1 ? '' : 's'} to check`} message={w.warnings.slice(0, 5).join('\n')} /> : null}
      <Btn testID="pw-full" title="Open the full pay run" size="md" variant="secondary" onPress={() => nav.push('PayRun', { uid: w.run.uid })} />
    </Screen>
  );
}

// ---------------------------------------------------------------- FNPF (rep-fnpf)
export function FnpfMonthScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [ym, setYm] = useState(params.ym && /^\d{4}-\d{2}$/.test(params.ym) ? params.ym : V.lastFullMonth());
  const [n, bump] = useState(0);
  const f = useMemo(() => tryRun(() => PV.fnpfMonth(ym)), [ym, n]);
  if (f.error) return <Screen title="FNPF"><MonthPicker ym={ym} onChange={setYm} /><Banner tone="danger" message={f.error} /></Screen>;
  const send = () => { if (act(() => V.markSent(user, 'fnpf', ym), 'Marked as sent to the accountant')) { bump((x) => x + 1); nav.push('ReportView', { kind: 'v1_fnpf', from: `${ym}-01`, to: `${ym}-01` }); } };
  return (
    <Screen title={`FNPF – ${V.ymLabel(ym)}`} subtitle={f.due ? `due ${f.due}` : ''} footer={<Btn testID="fnpf-send" title="Send to the accountant (Excel)" icon="📤" variant="primary" onPress={send} />}>
      <MonthPicker ym={ym} onChange={setYm} testID="fnpf" />
      {f.people.map((p) => (
        <View key={p.userUid} style={{ gap: 4 }}>
          <ListItem testID={`fnpf-person-${p.userUid}`} title={`${p.name}${p.fnpfNo ? ` · FNPF ••${String(p.fnpfNo).slice(-4)}` : ' · no FNPF number'}`} sub={`staff ${$(p.staff)} · employer ${$(p.employer)} · ${p.weeks} week${p.weeks === 1 ? '' : 's'}`} right={$(p.total)} tone={p.fnpfNo ? undefined : 'danger'} />
          {f.rows.filter((r) => r.userUid === p.userUid).map((r) => (
            <Text key={r.lineUid} style={{ fontSize: 14, color: C.sub, marginLeft: 14 }}>{`${dm(r.weekStart)} – ${dm(r.weekEnd)} (paid ${dm(r.payDate)}): pay ${$(r.pay)} · FNPF ${$(r.staff)} · employer ${$(r.employer)}`}</Text>
          ))}
        </View>
      ))}
      {!f.people.length ? <Hint>No FNPF in {V.ymLabel(ym)} (no approved pay runs with FNPF).</Hint> : null}
      {f.excluded ? <Hint>{`${f.excluded} family member${f.excluded === 1 ? '' : 's'} with FNPF switched off – not included.`}</Hint> : null}
      <ListItem testID="fnpf-total" title="Total payable" sub="Rates from Settings › Pay" right={$(f.totals.total)} tone="success" />
      {f.checks.map((c, i) => <Hint key={i}>{`${c.level === 'bad' ? '⛔' : '⚠️'} ${c.text}`}</Hint>)}
      <Section title="Where it is up to">
        {f.trail.map((s) => <ListItem key={s.key} title={`${s.done ? '●' : '○'} ${s.label}`} sub={s.when || undefined} />)}
      </Section>
      <Btn testID="fnpf-file" title="Filed / paid – record it" size="md" variant="secondary" onPress={() => nav.push('TaxReturn', { kind: 'fnpf', period: ym })} />
    </Screen>
  );
}
