// Payroll: the weekly pay run (Saturday to Friday, paid on Saturday) worked out from the timesheets and leave.
// Every rate, tax table and rule is admin-editable. Before a run is final every line can be changed
// (hours, rate, extra pay, deductions) with a reason; after that it is locked (void and redo if wrong).
import { db } from '../../db/connection.js';
import { assertOpen } from '../../services/lock.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, weekStart, getShared, setShared, money } from '../../services/core.js';
import { shiftsBetween, checkFor } from '../timesheets/service.js';
import { listLeave, countLeaveDays } from '../leave/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const h2 = (m) => Math.round((m / 60) * 100) / 100;

// ---------------------------------------------------------------- rules (admin). These figures must be checked with FRCS / FNPF.
export const PAY_DEFAULTS = {
  confirmed: false,               // turned on by the owner once the figures below are checked
  normalHoursWeek: 48,            // hours a week at the normal rate, then overtime
  normalHoursDay: 0,              // 0 = no daily limit; e.g. 9 = hours over 9 in a day are overtime
  otMultiplier: 1.5,
  sundayMultiplier: 1.5,          // 1 = Sunday is a normal day
  holidayMultiplier: 2,
  leaveHoursPerDay: 8,
  minimumWage: 5.44,              // warning only (retail & wholesale, from 1 April 2025)
  fnpfEmployeePct: 8,
  fnpfEmployerPct: 10,
  taxBrackets: [{ upTo: 30000, rate: 0 }, { upTo: 50000, rate: 18 }, { upTo: 270000, rate: 20 }, { upTo: null, rate: 20 }],
  srtBrackets: [],                // Social Responsibility Tax bands on top: [{ over, rate }]
  nonResidentRate: 20,
  noTinRate: 0,                   // extra rate when there is no TIN (0 = treat as resident)
  fnpfReducesTax: false,
  needCheckedTimesheets: true,
  salaryOvertime: false,          // salaried staff get overtime pay too
  wagesDefaultShop: 'S1',         // cash wages for staff with no shop come from this shop's cash
  wagesBankAccount: '',           // pay by bank comes out of this account (Invoices & cheques › Cheques & bank)
  publicHolidays: [
    { date: '2026-01-01', name: "New Year's Day" }, { date: '2026-04-03', name: 'Good Friday' }, { date: '2026-04-04', name: 'Easter Saturday' },
    { date: '2026-04-06', name: 'Easter Monday' }, { date: '2026-10-10', name: 'Fiji Day' }, { date: '2026-12-25', name: 'Christmas Day' }, { date: '2026-12-26', name: 'Boxing Day' },
  ],
  allowanceTypes: ['Meal', 'Transport', 'Responsibility', 'Bonus', 'Other'],
  deductionTypes: ['Union fees', 'Uniform', 'Shop account', 'Breakage', 'Other'],
};
export function payRules() {
  return { ...PAY_DEFAULTS, ...(getShared('pay_rules', {}) || {}) };
}
export function savePayRules(user, r) {
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const brackets = (r.taxBrackets || []).map((b) => ({ upTo: b.upTo === '' || b.upTo === null || b.upTo === undefined ? null : n(b.upTo, 0, 1e9, 'Bracket limit'), rate: n(b.rate, 0, 100, 'Tax rate') }));
  need(brackets.length && brackets[brackets.length - 1].upTo === null, 'The last tax bracket must have no upper limit.');
  for (let i = 1; i < brackets.length - 1; i++) need(brackets[i].upTo > brackets[i - 1].upTo, 'Tax brackets must go up in order.');
  const hol = (r.publicHolidays || []).map((h) => ({ date: txt(h.date), name: txt(h.name) })).filter((h) => h.date);
  hol.forEach((h) => need(DATE.test(h.date), `Holiday date ${h.date}: use YYYY-MM-DD.`));
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const clean = {
    confirmed: !!r.confirmed, normalHoursWeek: n(r.normalHoursWeek, 1, 80, 'Normal hours a week'), normalHoursDay: n(r.normalHoursDay, 0, 24, 'Normal hours a day'),
    otMultiplier: n(r.otMultiplier, 1, 4, 'Overtime rate'), sundayMultiplier: n(r.sundayMultiplier, 1, 4, 'Sunday rate'), holidayMultiplier: n(r.holidayMultiplier, 1, 4, 'Public holiday rate'),
    leaveHoursPerDay: n(r.leaveHoursPerDay, 0, 24, 'Leave hours a day'), minimumWage: n(r.minimumWage, 0, 100, 'Minimum wage'),
    fnpfEmployeePct: n(r.fnpfEmployeePct, 0, 50, 'FNPF employee %'), fnpfEmployerPct: n(r.fnpfEmployerPct, 0, 50, 'FNPF employer %'),
    taxBrackets: brackets, srtBrackets: (r.srtBrackets || []).map((b) => ({ over: n(b.over, 0, 1e9, 'SRT from'), rate: n(b.rate, 0, 100, 'SRT rate') })),
    nonResidentRate: n(r.nonResidentRate, 0, 100, 'Non-resident rate'), noTinRate: n(r.noTinRate, 0, 100, 'No-TIN rate'),
    fnpfReducesTax: !!r.fnpfReducesTax, needCheckedTimesheets: !!r.needCheckedTimesheets, salaryOvertime: !!r.salaryOvertime, wagesDefaultShop: txt(r.wagesDefaultShop) || 'S1', wagesBankAccount: txt(r.wagesBankAccount),
    publicHolidays: hol.sort((a, b) => (a.date < b.date ? -1 : 1)), allowanceTypes: list(r.allowanceTypes), deductionTypes: list(r.deductionTypes),
  };
  const before = payRules();
  setShared('pay_rules', clean);
  audit({ user, action: 'Changed payroll rules', table: 'shared_settings', recordUid: 'pay_rules', before, after: clean });
  return clean;
}

// Yearly tax on yearly income using the brackets (+ SRT bands), then shared out per week.
export function annualTax(income, rules = payRules()) {
  let tax = 0;
  let low = 0;
  for (const b of rules.taxBrackets) {
    const top = b.upTo === null ? Infinity : b.upTo;
    if (income > low) tax += (Math.min(income, top) - low) * (b.rate / 100);
    low = top;
    if (income <= top) break;
  }
  for (const s of rules.srtBrackets || []) if (income > s.over) tax += (income - s.over) * (s.rate / 100);
  return r2(tax);
}
export function weeklyPaye(taxableWeek, profile, rules = payRules()) {
  if (taxableWeek <= 0) return 0;
  if (profile && profile.tax_status === 'non_resident') return r2(taxableWeek * (rules.nonResidentRate / 100));
  let t = r2(annualTax(taxableWeek * 52, rules) / 52);
  if (profile && !txt(profile.tin) && rules.noTinRate) t = Math.max(t, r2(taxableWeek * (rules.noTinRate / 100)));
  return t;
}

// ---------------------------------------------------------------- pay details per person
export function getProfile(userUid) {
  const p = db().get('SELECT * FROM pay_profiles WHERE user_uid = ?', [userUid]);
  return p ? { ...p, allowances: J(p.allowances, []), deductions: J(p.deductions, []) } : null;
}
export function listProfiles() {
  return db().all(`SELECT p.*, u.uid AS uid, u.name, u.employee_no, u.shop_code, u.active AS user_active FROM users u LEFT JOIN pay_profiles p ON p.user_uid = u.uid
    WHERE u.active = 1 AND u.sync_status <> 'seed' ORDER BY u.name`).map((r) => ({ ...r, user_uid: r.uid, allowances: J(r.allowances, []), deductions: J(r.deductions, []), hasProfile: r.pay_type !== null && r.pay_type !== undefined }));
}
export function saveProfile(user, p) {
  const u = db().get('SELECT * FROM users WHERE uid = ?', [p.userUid || '']);
  need(u, 'Staff member not found.');
  need(['hourly', 'salary'].includes(p.payType), 'Choose hourly or salary.');
  const rate = r2(p.rate);
  const sal = r2(p.weeklySalary);
  if (p.payType === 'hourly') need(rate > 0 && rate < 1000, 'Enter the hourly rate.');
  else need(sal > 0, 'Enter the weekly salary.');
  const nh = txt(p.normalHours) === '' ? null : Number(p.normalHours);
  need(nh === null || (nh > 0 && nh <= 80), 'Normal hours a week must be between 1 and 80.');
  need(['resident', 'non_resident'].includes(p.taxStatus || 'resident'), 'Choose the tax status.');
  need(['cash', 'bank'].includes(p.payMethod || 'cash'), 'Choose cash or bank.');
  if (p.payMethod === 'bank') need(txt(p.bankAccount), 'Enter the bank account for pay by bank.');
  const allowances = (p.allowances || []).filter((a) => txt(a.name) && r2(a.amount)).map((a) => ({ name: txt(a.name), amount: r2(a.amount), taxable: a.taxable !== false, fnpf: a.fnpf !== false }));
  const deductions = (p.deductions || []).filter((d) => txt(d.name) && r2(d.amount)).map((d) => ({ name: txt(d.name), amount: r2(d.amount) }));
  const before = getProfile(u.uid);
  const { now, dev } = meta();
  db().run(`INSERT INTO pay_profiles (user_uid, pay_type, rate, weekly_salary, normal_hours, job_title, wage_category, fnpf_no, tin, tax_status, fnpf_member, fnpf_extra_pct, pay_method, bank_name, bank_account,
    allowances, deductions, start_date, end_date, active, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(user_uid) DO UPDATE SET pay_type=excluded.pay_type, rate=excluded.rate, weekly_salary=excluded.weekly_salary, normal_hours=excluded.normal_hours, job_title=excluded.job_title,
    wage_category=excluded.wage_category, fnpf_no=excluded.fnpf_no, tin=excluded.tin, tax_status=excluded.tax_status, fnpf_member=excluded.fnpf_member, fnpf_extra_pct=excluded.fnpf_extra_pct,
    pay_method=excluded.pay_method, bank_name=excluded.bank_name, bank_account=excluded.bank_account, allowances=excluded.allowances, deductions=excluded.deductions, start_date=excluded.start_date,
    end_date=excluded.end_date, active=excluded.active, notes=excluded.notes, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [u.uid, p.payType, rate, sal, nh, txt(p.jobTitle) || null, txt(p.wageCategory) || null, txt(p.fnpfNo) || null, txt(p.tin).replace(/\D/g, '') || null, p.taxStatus || 'resident',
    p.fnpfMember === false ? 0 : 1, Number(p.fnpfExtraPct) || 0, p.payMethod || 'cash', txt(p.bankName) || null, txt(p.bankAccount) || null, JSON.stringify(allowances), JSON.stringify(deductions),
    txt(p.startDate) || null, txt(p.endDate) || null, p.active === false ? 0 : 1, txt(p.notes) || null, now, dev]);
  audit({ user, action: `Pay details for ${u.name}`, table: 'pay_profiles', recordUid: u.uid, before: before && { type: before.pay_type, rate: before.rate, salary: before.weekly_salary },
    after: { type: p.payType, rate, salary: sal } });
  return getProfile(u.uid);
}

// ---------------------------------------------------------------- advances & staff loans
export function giveDebt(user, d) {
  assertOpen(String(d.date || dateStr()), 'This advance / loan');
  const u = db().get('SELECT * FROM users WHERE uid = ?', [d.userUid || '']);
  need(u, 'Choose the staff member.');
  need(['advance', 'loan'].includes(d.kind), 'Advance or loan?');
  const amt = r2(d.amount);
  need(amt > 0, 'Enter the amount.');
  const per = r2(d.repayPerPay || amt);
  need(per > 0 && per <= amt, 'The weekly repayment must be more than 0 and not more than the amount.');
  const date = txt(d.date) || dateStr();
  need(DATE.test(date), 'Enter the date as YYYY-MM-DD.');
  need(txt(d.reason), 'Write the reason.');
  const { now, dev } = meta();
  const uid = uuid('SD');
  db().run(`INSERT INTO staff_debts (uid, user_uid, name, kind, debt_date, amount, repay_per_pay, reason, shop_code, paid_from, given_by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, u.uid, u.name, d.kind, date, amt, per, txt(d.reason), d.shopCode || null, d.paidFrom || 'cash', user.name, now, now, dev]);
  // An advance in cash comes out of the shop's cash on hand.
  if (d.paidFrom === 'cash' && d.shopCode) {
    try {
      db().run(`INSERT INTO cash_moves (uid, shop_code, move_date, type, amount, ref_uid, category, note, photo_urls, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,'petty_out',?,?,'Staff advance',?,'[]',?,?,?,?)`,
        [uuid('CM'), d.shopCode, date, amt, uid, `${d.kind === 'loan' ? 'Staff loan' : 'Advance'} to ${u.name}`, user.name, user.uid, now, dev]);
    } catch (e) { /* till module not installed */ }
  }
  audit({ user, action: `${d.kind === 'loan' ? 'Staff loan' : 'Advance'} ${$(amt)} to ${u.name}`, table: 'staff_debts', recordUid: uid, reason: d.reason });
  return uid;
}
export function voidDebt(user, uid, reason) {
  { const x = db().get('SELECT debt_date FROM staff_debts WHERE uid = ?', [uid]); if (x) assertOpen(x.debt_date, 'This advance / loan'); }
  need(txt(reason), 'Give a reason.');
  const d = debtBalance(uid);
  need(d && d.status === 'active', 'Not found.');
  need(!d.repaid, 'Repayments were already taken in pay runs. Record a correction instead.');
  const { now, dev } = meta();
  db().run(`UPDATE staff_debts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  try { db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ?`, [txt(reason), now, dev, uid]); } catch (e) { /* none */ }
  audit({ user, action: `Voided ${d.kind} for ${d.name}`, table: 'staff_debts', recordUid: uid, reason });
}
// Repaid = deductions for this debt in FINAL pay runs.
export const DEBT_LABEL = { advance: 'Advance', loan: 'Staff loan', till_short: 'Till shortage', breakage: 'Breakage / damage', other: 'Deduction' };
// Staff charges (till shortages, breakages…) are taken from pay the same way as advances.
function chargeAsDebt(c) {
  return c && { uid: c.uid, user_uid: c.user_uid, name: c.name, kind: c.source || 'other', debt_date: c.charge_date, amount: c.amount, repay_per_pay: c.per_pay, reason: c.reason,
    shop_code: c.shop_code, given_by_name: c.by_name, status: c.status, void_reason: c.void_reason, ref_uid: c.ref_uid, charge: true };
}
export function debtBalance(uid) {
  let d = db().get('SELECT * FROM staff_debts WHERE uid = ?', [uid]);
  if (!d) d = chargeAsDebt(db().get('SELECT * FROM staff_charges WHERE uid = ?', [uid]));
  if (!d) return null;
  let repaid = 0;
  db().all(`SELECT l.deductions FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1`, [d.user_uid])
    .forEach((l) => J(l.deductions, []).forEach((x) => { if (x.debtUid === uid) repaid += x.amount; }));
  return { ...d, repaid: r2(repaid), balance: r2(d.amount - repaid) };
}
export function listDebts({ userUid, open = true } = {}) {
  const ids = db().all(`SELECT uid, debt_date AS d FROM staff_debts WHERE status = 'active' AND (? IS NULL OR user_uid = ?)
    UNION ALL SELECT uid, charge_date AS d FROM staff_charges WHERE status = 'active' AND (? IS NULL OR user_uid = ?) ORDER BY d`, [userUid || null, userUid || null, userUid || null, userUid || null]);
  return ids.map((x) => debtBalance(x.uid)).filter((d) => !open || d.balance > 0.004);
}

// A charge to a staff member, taken from pay (till shortage, breakage, other). Admin can void it with a reason.
export function chargeStaff(user, { userUid, amount, perPay, reason, source = 'other', refUid, shopCode, date }) {
  assertOpen(String(date || dateStr()), 'This charge');
  const u = db().get('SELECT * FROM users WHERE uid = ?', [userUid || '']);
  need(u, 'Choose the staff member.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  const per = r2(perPay || a);
  need(per > 0 && per <= a, 'The weekly amount must be more than 0 and not more than the total.');
  need(txt(reason), 'Write the reason.');
  const { now, dev } = meta();
  const uid = uuid('SC');
  db().run(`INSERT INTO staff_charges (uid, user_uid, name, charge_date, amount, per_pay, reason, source, ref_uid, shop_code, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, u.uid, u.name, txt(date) || dateStr(), a, per, txt(reason), source, refUid || null, shopCode || null, user.name, now, now, dev]);
  audit({ user, action: `${DEBT_LABEL[source] || 'Deduction'} ${$(a)} charged to ${u.name}`, table: 'staff_charges', recordUid: uid, reason });
  return uid;
}
export function voidCharge(user, uid, reason) {
  { const x = db().get('SELECT charge_date FROM staff_charges WHERE uid = ?', [uid]); if (x) assertOpen(x.charge_date, 'This charge'); }
  need(txt(reason), 'Give a reason.');
  const d = debtBalance(uid);
  need(d && d.charge && d.status === 'active', 'Not found.');
  need(!d.repaid, 'Part of it was already taken from pay. Give the money back as extra pay instead.');
  const { now, dev } = meta();
  db().run(`UPDATE staff_charges SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled ${DEBT_LABEL[d.kind] || 'deduction'} for ${d.name}`, table: 'staff_charges', recordUid: uid, reason });
}

// ---------------------------------------------------------------- working out one person's week
function holidaysIn(rules, from, to) {
  const out = {};
  (rules.publicHolidays || []).forEach((h) => { if (h.date >= from && h.date <= to) out[h.date] = h.name; });
  return out;
}
export function computeLine(user, profile, weekStartDate, rules = payRules(), extra = {}) {
  const ws = weekStartDate;
  const we = addDays(ws, 6);
  const ov = extra.overrides || {};
  const warnings = [];
  const hol = holidaysIn(rules, ws, we);
  const shifts = (shiftsBetween(ws, we, { userUid: user.uid })[0] || { shifts: [] }).shifts.slice().sort((a, b) => ((a.in_at || '') < (b.in_at || '') ? -1 : 1));
  const normalLimit = (profile.normal_hours || rules.normalHoursWeek) * 60;
  let normal = 0; let ot = 0; let sunday = 0; let holiday = 0;
  for (const s of shifts) {
    const m = s.workedMinutes;
    if (s.problems) warnings.push(`Timesheet problem on ${s.date}`);
    const dow = new Date(`${s.date}T00:00:00`).getDay();
    if (hol[s.date]) { holiday += m; continue; }
    if (dow === 0 && rules.sundayMultiplier > 1) { sunday += m; continue; }
    let dayNormal = m;
    let dayOt = 0;
    if (rules.normalHoursDay > 0 && m > rules.normalHoursDay * 60) { dayNormal = rules.normalHoursDay * 60; dayOt = m - dayNormal; }
    const room = Math.max(0, normalLimit - normal);
    const toNormal = Math.min(room, dayNormal);
    normal += toNormal;
    ot += dayOt + (dayNormal - toNormal);
  }
  // Paid leave (approved) in the week.
  const leave = listLeave({ status: 'approved', userUid: user.uid, from: ws, to: we }).filter((l) => l.paid);
  let leaveDays = 0;
  const worked = new Set(shifts.filter((s) => s.workedMinutes > 0).map((s) => s.date));
  leave.forEach((l) => {
    for (let d = l.from_date; d <= l.to_date; d = addDays(d, 1)) {
      if (d < ws || d > we || hol[d] || worked.has(d)) continue;
      if (!countLeaveDays(d, d)) continue; // same day rule as the leave balance (e.g. Mon–Sat)
      leaveDays += l.days === 0.5 ? 0.5 : 1;
    }
  });
  const check = checkFor(user.uid, ws);
  if (rules.needCheckedTimesheets && shifts.length && !(check && check.status === 'checked')) warnings.push('Timesheet week not ticked as checked');
  const hours = {
    normal: ov.normal !== undefined ? Number(ov.normal) : h2(normal), ot: ov.ot !== undefined ? Number(ov.ot) : h2(ot), sunday: ov.sunday !== undefined ? Number(ov.sunday) : h2(sunday),
    holiday: ov.holiday !== undefined ? Number(ov.holiday) : h2(holiday), leave: ov.leave !== undefined ? Number(ov.leave) : r2(leaveDays * rules.leaveHoursPerDay),
  };
  const rate = ov.rate !== undefined ? r2(ov.rate) : profile.pay_type === 'hourly' ? r2(profile.rate) : r2(profile.weekly_salary / (profile.normal_hours || rules.normalHoursWeek));
  if (profile.pay_type === 'hourly' && rate < rules.minimumWage) warnings.push(`Rate ${$(rate)} is below the minimum wage ${$(rules.minimumWage)}`);
  const earnings = profile.pay_type === 'salary'
    ? { salary: r2(profile.weekly_salary), ot: r2(hours.ot * rate * rules.otMultiplier), sunday: r2(hours.sunday * rate * (rules.sundayMultiplier - 1)), holiday: r2(hours.holiday * rate * (rules.holidayMultiplier - 1)) }
    : { normal: r2(hours.normal * rate), ot: r2(hours.ot * rate * rules.otMultiplier), sunday: r2(hours.sunday * rate * rules.sundayMultiplier), holiday: r2(hours.holiday * rate * rules.holidayMultiplier), leave: r2(hours.leave * rate) };
  if (profile.pay_type === 'salary' && !rules.salaryOvertime) { earnings.ot = ov.ot !== undefined ? earnings.ot : 0; }
  const allowances = (profile.allowances || []).concat(extra.allowances || []);
  const adjustments = extra.adjustments || [];
  const gross = r2(Object.values(earnings).reduce((s, v) => s + v, 0) + allowances.reduce((s, a) => s + a.amount, 0) + adjustments.reduce((s, a) => s + a.amount, 0));
  const fnpfBase = r2(gross - allowances.filter((a) => a.fnpf === false).reduce((s, a) => s + a.amount, 0) - adjustments.filter((a) => a.fnpf === false).reduce((s, a) => s + a.amount, 0));
  const member = profile.fnpf_member !== 0;
  const fnpfEmployee = member ? r2(fnpfBase * ((rules.fnpfEmployeePct + (Number(profile.fnpf_extra_pct) || 0)) / 100)) : 0;
  const fnpfEmployer = member ? r2(fnpfBase * (rules.fnpfEmployerPct / 100)) : 0;
  let taxable = r2(gross - allowances.filter((a) => a.taxable === false).reduce((s, a) => s + a.amount, 0) - adjustments.filter((a) => a.taxable === false).reduce((s, a) => s + a.amount, 0));
  if (rules.fnpfReducesTax) taxable = r2(taxable - fnpfEmployee);
  const paye = ov.paye !== undefined ? r2(ov.paye) : weeklyPaye(taxable, profile, rules);
  if (!txt(profile.tin)) warnings.push('No TIN');
  if (member && !txt(profile.fnpf_no)) warnings.push('No FNPF number');
  // Deductions: regular ones from the pay details, advances / loans, and ones added to this week.
  const deductions = (profile.deductions || []).map((d) => ({ label: d.name, amount: d.amount })).concat(extra.deductions || []);
  let left = r2(gross - fnpfEmployee - paye - deductions.reduce((s, d) => s + d.amount, 0));
  for (const debt of listDebts({ userUid: user.uid })) {
    if (debt.debt_date > we) continue;
    const skip = (extra.skipDebts || []).includes(debt.uid);
    if (skip) continue;
    const take = r2(Math.min(debt.repay_per_pay, debt.balance, Math.max(0, left)));
    if (take > 0) { deductions.push({ label: `${DEBT_LABEL[debt.kind] || 'Deduction'} (${debt.debt_date})`, amount: take, debtUid: debt.uid }); left = r2(left - take); }
    if (take < Math.min(debt.repay_per_pay, debt.balance)) warnings.push(`Not enough pay to take the full ${debt.kind} repayment`);
  }
  const totalDeductions = r2(fnpfEmployee + paye + deductions.reduce((s, d) => s + d.amount, 0));
  const net = r2(gross - totalDeductions);
  if (net < 0) warnings.push('Net pay is below zero');
  if (!shifts.length && profile.pay_type === 'hourly' && !hours.leave && !ov.normal) warnings.push('No hours this week');
  return { hours, rate, earnings, allowances, adjustments, gross, taxable, fnpfBase, fnpfEmployee, fnpfEmployer, paye, deductions, totalDeductions, net, warnings: Array.from(new Set(warnings)) };
}

// ---------------------------------------------------------------- pay runs
export function getRun(uid) {
  const r = db().get('SELECT * FROM pay_runs WHERE uid = ?', [uid]);
  if (!r) return null;
  r.totals = J(r.totals, {});
  r.lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? ORDER BY name', [uid]).map(decodeLine);
  return r;
}
function decodeLine(l) {
  return { ...l, hours: J(l.hours, {}), earnings: J(l.earnings, {}), allowances: J(l.allowances, []), adjustments: J(l.adjustments, []), overrides: J(l.overrides, {}), deductions: J(l.deductions, []), warnings: J(l.warnings, []) };
}
export function listRuns({ includeVoid = false } = {}) {
  return db().all(`SELECT * FROM pay_runs WHERE (? = 1 OR status <> 'void') ORDER BY week_start DESC`, [includeVoid ? 1 : 0]).map((r) => ({ ...r, totals: J(r.totals, {}) }));
}
function writeLine(runUid, u, profile, ws, extra, edit) {
  const c = computeLine(u, profile, ws, payRules(), extra);
  const { now, dev } = meta();
  const uid = `${runUid}|${u.uid}`;
  db().run(`INSERT INTO pay_lines (uid, run_uid, user_uid, name, employee_no, shop_code, pay_type, rate, hours, earnings, allowances, adjustments, overrides, gross, taxable, fnpf_base, fnpf_employee,
    fnpf_employer, paye, deductions, total_deductions, net, pay_method, warnings, edited_by_name, edit_reason, include, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, employee_no=excluded.employee_no, shop_code=excluded.shop_code, pay_type=excluded.pay_type, rate=excluded.rate, hours=excluded.hours, earnings=excluded.earnings,
    allowances=excluded.allowances, adjustments=excluded.adjustments, overrides=excluded.overrides, gross=excluded.gross, taxable=excluded.taxable, fnpf_base=excluded.fnpf_base, fnpf_employee=excluded.fnpf_employee,
    fnpf_employer=excluded.fnpf_employer, paye=excluded.paye, deductions=excluded.deductions, total_deductions=excluded.total_deductions, net=excluded.net, pay_method=excluded.pay_method, warnings=excluded.warnings,
    edited_by_name=excluded.edited_by_name, edit_reason=excluded.edit_reason, include=excluded.include, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, runUid, u.uid, u.name, u.employee_no || null, u.shop_code || null, profile.pay_type, c.rate, JSON.stringify(c.hours), JSON.stringify(c.earnings), JSON.stringify(c.allowances), JSON.stringify(c.adjustments),
    JSON.stringify(extra.overrides || {}), c.gross, c.taxable, c.fnpfBase, c.fnpfEmployee, c.fnpfEmployer, c.paye, JSON.stringify(c.deductions), c.totalDeductions, c.net, profile.pay_method,
    JSON.stringify(c.warnings), edit ? edit.by : null, edit ? edit.reason : null, extra.include === false ? 0 : 1, now, dev]);
  return uid;
}
function extraOf(line) {
  if (!line) return {};
  const manualDeds = line.deductions.filter((d) => d.manual).map((d) => ({ label: d.label, amount: d.amount, manual: true }));
  return { overrides: line.overrides, adjustments: line.adjustments, deductions: manualDeds, include: !!line.include, skipDebts: line.overrides.skipDebts || [] };
}
function retotal(runUid) {
  const lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1', [runUid]);
  const sum = (k) => r2(lines.reduce((s, l) => s + l[k], 0));
  const totals = { people: lines.length, gross: sum('gross'), paye: sum('paye'), fnpfEmployee: sum('fnpf_employee'), fnpfEmployer: sum('fnpf_employer'), net: sum('net'),
    deductions: r2(sum('total_deductions') - sum('paye') - sum('fnpf_employee')), cash: r2(lines.filter((l) => l.pay_method !== 'bank').reduce((s, l) => s + l.net, 0)),
    bank: r2(lines.filter((l) => l.pay_method === 'bank').reduce((s, l) => s + l.net, 0)), warnings: lines.reduce((s, l) => s + J(l.warnings, []).length, 0) };
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET totals = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(totals), now, dev, runUid]);
  return totals;
}

export function createRun(user, anyDateInWeek) {
  const ws = weekStart(anyDateInWeek || addDays(dateStr(), -1));
  const we = addDays(ws, 6);
  const existing = db().get("SELECT uid, status FROM pay_runs WHERE week_start = ? AND status <> 'void'", [ws]);
  need(!existing, `There is already a pay run for the week ${ws} (${existing && existing.status}).`);
  const people = listProfiles().filter((p) => p.hasProfile && p.active !== 0);
  need(people.length, 'No one has pay details yet. Add them in Payroll › Pay details.');
  // Each run has its own id: a voided run stays as it was (history), and nothing is ever deleted.
  const uid = uuid(`PR-${ws}-`);
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, totals, created_by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,'draft','{}',?,?,?,?)`,
      [uid, ws, we, addDays(we, 1), user.name, now, now, dev]);
    for (const p of people) {
      const u = db().get('SELECT * FROM users WHERE uid = ?', [p.user_uid]);
      if (p.start_date && p.start_date > we) continue;
      if (p.end_date && p.end_date < ws) continue;
      writeLine(uid, u, getProfile(u.uid), ws, {}, null);
    }
    retotal(uid);
  });
  audit({ user, action: `Started pay run for ${ws} to ${we}`, table: 'pay_runs', recordUid: uid });
  return getRun(uid);
}

// Work the whole run out again from the timesheets (keeps each line's changes).
export function recalcRun(user, runUid) {
  const r = getRun(runUid);
  need(r && r.status === 'draft', 'Only a draft pay run can be worked out again.');
  db().transaction(() => {
    for (const l of r.lines) {
      const u = db().get('SELECT * FROM users WHERE uid = ?', [l.user_uid]);
      const p = getProfile(l.user_uid);
      if (u && p) writeLine(runUid, u, p, r.week_start, extraOf(l), l.edited_by_name ? { by: l.edited_by_name, reason: l.edit_reason } : null);
    }
    retotal(runUid);
  });
}

// Change one line before the run is final: hours, rate, PAYE, extra pay, deductions, leave it out.
export function editLine(user, lineUid, change) {
  const l = db().get('SELECT * FROM pay_lines WHERE uid = ?', [lineUid]);
  need(l, 'Line not found.');
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [l.run_uid]);
  need(run.status === 'draft', 'This pay run is final. Void it and start again to change it.');
  need(txt(change.reason), 'Write the reason for the change.');
  const cur = extraOf(decodeLine(l));
  const ov = { ...cur.overrides };
  ['normal', 'ot', 'sunday', 'holiday', 'leave', 'rate', 'paye'].forEach((k) => {
    if (change[k] === undefined) return;
    if (change[k] === '' || change[k] === null) delete ov[k];
    else { const v = Number(change[k]); need(Number.isFinite(v) && v >= 0, `${k} must be a number.`); ov[k] = v; }
  });
  if (change.skipDebts) ov.skipDebts = change.skipDebts;
  const adjustments = change.adjustments !== undefined ? change.adjustments.filter((a) => txt(a.label) && r2(a.amount)).map((a) => ({ label: txt(a.label), amount: r2(a.amount), taxable: a.taxable !== false, fnpf: a.fnpf !== false })) : cur.adjustments;
  const deductions = change.deductions !== undefined ? change.deductions.filter((d) => txt(d.label) && r2(d.amount) > 0).map((d) => ({ label: txt(d.label), amount: r2(d.amount), manual: true })) : cur.deductions;
  const include = change.include !== undefined ? !!change.include : cur.include;
  const u = db().get('SELECT * FROM users WHERE uid = ?', [l.user_uid]);
  writeLine(l.run_uid, u, getProfile(l.user_uid), run.week_start, { overrides: ov, adjustments, deductions, include, skipDebts: ov.skipDebts || [] }, { by: user.name, reason: txt(change.reason) });
  retotal(l.run_uid);
  audit({ user, action: `Changed pay for ${l.name} (${run.week_start})`, table: 'pay_lines', recordUid: lineUid, before: { gross: l.gross, net: l.net }, after: change, reason: change.reason });
  return decodeLine(db().get('SELECT * FROM pay_lines WHERE uid = ?', [lineUid]));
}

export function finaliseRun(user, runUid) {
  { const x = db().get('SELECT pay_date FROM pay_runs WHERE uid = ?', [runUid]); if (x) assertOpen(x.pay_date, 'This pay run'); }
  const r = getRun(runUid);
  need(r && r.status === 'draft', 'Only a draft pay run can be made final.');
  recalcRun(user, runUid);
  const bad = getRun(runUid).lines.filter((l) => l.include && l.net < 0);
  need(!bad.length, `${bad.map((l) => l.name).join(', ')}: net pay below zero. Fix before making final.`);
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET status = 'final', finalised_by_name = ?, finalised_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [user.name, now, now, dev, runUid]);
  // Pay by bank: one transfer out of the wages account (cash wages come off each shop's cash on hand by themselves).
  const fin = getRun(runUid);
  const bankAcc = payRules().wagesBankAccount;
  if (fin.totals.bank > 0 && bankAcc) {
    try {
      db().run(`INSERT OR REPLACE INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, status, by_name, updated_at, updated_device, sync_status) VALUES (?,?,?,'transfer_out',?,?,?,'active',?,?,?,'pending')`,
        [`BE-WAGES-${runUid}`, bankAcc, fin.pay_date, fin.totals.bank, `Wages ${fin.week_start}`, `Wages paid by bank, week ${fin.week_start} to ${fin.week_end}`, user.name, now, dev]);
    } catch (e) { /* no bank module */ }
  }
  audit({ user, action: `Pay run ${r.week_start} made final: net ${$(getRun(runUid).totals.net)}`, table: 'pay_runs', recordUid: runUid });
  return getRun(runUid);
}
export function voidRun(user, runUid, reason) {
  { const x = db().get('SELECT pay_date FROM pay_runs WHERE uid = ?', [runUid]); if (x) assertOpen(x.pay_date, 'This pay run'); }
  need(['owner', 'admin'].includes(user.role), 'Only the owner or admin can void a pay run.');
  need(txt(reason), 'Give a reason.');
  const r = getRun(runUid);
  need(r && r.status !== 'void', 'Not found.');
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, runUid]);
  try { db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, `BE-WAGES-${runUid}`]); } catch (e) { /* none */ }
  audit({ user, action: `Voided pay run ${r.week_start}`, table: 'pay_runs', recordUid: runUid, reason });
}

// Year to date for a person (final runs paid in the year).
export function yearToDate(userUid, year = dateStr().slice(0, 4), upTo = '9999-12-31') {
  const rows = db().all(`SELECT l.* FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 AND substr(r.pay_date,1,4) = ? AND r.pay_date <= ?`, [userUid, String(year), upTo]);
  const s = (k) => r2(rows.reduce((a, l) => a + l[k], 0));
  return { gross: s('gross'), paye: s('paye'), fnpfEmployee: s('fnpf_employee'), fnpfEmployer: s('fnpf_employer'), net: s('net'), weeks: rows.length };
}

// Notes and coins needed to pay cash wages (each person's pay made up exactly).
export function cashBreakdown(amounts) {
  const D = [100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05];
  const total = {};
  D.forEach((d) => { total[d] = 0; });
  amounts.forEach((a) => {
    let left = Math.round(r2(a) * 100);
    left = Math.round(left / 5) * 5;
    D.forEach((d) => { const c = Math.round(d * 100); const n = Math.floor(left / c); total[d] += n; left -= n * c; });
  });
  return D.map((d) => ({ value: d, label: d >= 1 ? `$${d}` : `${Math.round(d * 100)}c`, count: total[d] })).filter((x) => x.count);
}

export function payrollAlerts() {
  const draft = db().get("SELECT COUNT(*) AS n FROM pay_runs WHERE status = 'draft'").n;
  const ws = weekStart(addDays(dateStr(), -7));
  const lastWeekDone = !!db().get("SELECT 1 AS x FROM pay_runs WHERE week_start = ? AND status = 'final'", [ws]);
  return { draft, lastWeek: ws, lastWeekDone, confirmed: payRules().confirmed };
}
