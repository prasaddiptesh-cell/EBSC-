// Payroll: the weekly pay run (Saturday to Friday, paid on Saturday) worked out from the timesheets and leave.
// Every rate, tax table and rule is admin-editable. Before a run is final every line can be changed
// (hours, rate, extra pay, deductions) with a reason; after that it is locked (void and redo if wrong).
import { db } from '../../db/connection.js';
import { assertOpen } from '../../services/lock.js';
import { addPhotos } from '../../services/stock.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, weekStart, getShared, setShared, money } from '../../services/core.js';
import { shiftsBetween, checkFor } from '../timesheets/service.js';
import { listLeave, countLeaveDays } from '../leave/service.js';
import { needReason, reasonRequired, actsAsOwner, can, requireSetup } from '../../services/access.js';
import { payPeriod, previousPeriod, payCycle } from './cycle.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const h2 = (m) => Math.round((m / 60) * 100) / 100;

// ---------------------------------------------------------------- rules (admin). These figures must be checked with FRCS / FNPF.
export const PAY_DEFAULTS = {
  confirmed: false,               // turned on by the owner once the figures below are checked
  normalHoursWeek: 48,            // hours a week at the normal rate, then overtime
  normalHoursDay: 0,              // 0 = no daily limit; e.g. 9 = hours over 9 in a day are overtime
  otMultiplier: 1.5,
  sundayMultiplier: 1.5,          // 1 = Sunday is a normal day
  holidayMultiplier: 2,
  leaveHoursPerDay: 8,
  minimumWage: 5.44,              // warning only (retail & wholesale, from 1 April 2025)
  fnpfEmployeePct: 8,
  fnpfEmployerPct: 10,
  // 3.9: employer FNPF rate changes by pay date (FNPF: 10% → 8% from 1 August 2026). Each pay uses the rate in force
  // on its pay day; before the first change it is fnpfEmployerPct. The admin can add or change these.
  fnpfEmployerChanges: [{ from: '2026-08-01', pct: 8 }],
  taxBrackets: [{ upTo: 30000, rate: 0 }, { upTo: 50000, rate: 18 }, { upTo: 270000, rate: 20 }, { upTo: null, rate: 20 }],
  srtBrackets: [],                // Social Responsibility Tax bands on top: [{ over, rate }]
  nonResidentRate: 20,
  noTinRate: 0,                   // extra rate when there is no TIN (0 = treat as resident)
  fnpfReducesTax: false,
  needCheckedTimesheets: true,
  salaryOvertime: false,          // salaried staff get overtime pay too
  wagesDefaultShop: 'S1',         // cash wages for staff with no shop come from this shop's cash
  wagesBankAccount: '',           // pay by bank comes out of this account (Invoices & cheques › Cheques & bank)
  publicHolidays: [
    { date: '2026-01-01', name: "New Year's Day" }, { date: '2026-04-03', name: 'Good Friday' }, { date: '2026-04-04', name: 'Easter Saturday' },
    { date: '2026-04-06', name: 'Easter Monday' }, { date: '2026-10-10', name: 'Fiji Day' }, { date: '2026-12-25', name: 'Christmas Day' }, { date: '2026-12-26', name: 'Boxing Day' },
  ],
  allowanceTypes: ['Meal', 'Transport', 'Responsibility', 'Bonus', 'Other'],
  deductionTypes: ['Union fees', 'Uniform', 'Shop account', 'Breakage', 'Other'],
};
export function payRules() {
  return { ...PAY_DEFAULTS, ...(getShared('pay_rules', {}) || {}) };
}
// The employer FNPF % for pay paid on this date.
export function employerPctOn(rules = payRules(), date = dateStr()) {
  let pct = Number(rules.fnpfEmployerPct);
  const list = (Array.isArray(rules.fnpfEmployerChanges) ? rules.fnpfEmployerChanges : []).filter((c) => c && DATE.test(String(c.from))).sort((a, b) => (a.from < b.from ? -1 : 1));
  for (const c of list) if (c.from <= String(date || dateStr())) pct = Number(c.pct);
  return Number.isFinite(pct) ? pct : 10;
}
export function savePayRules(user, r) {
  requireSetup(user, 'payroll_setup');
  const n = (v, lo, hi, label) => { const x = Number(v); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be between ${lo} and ${hi}.`); return x; };
  const brackets = (r.taxBrackets || []).map((b) => ({ upTo: b.upTo === '' || b.upTo === null || b.upTo === undefined ? null : n(b.upTo, 0, 1e9, 'Bracket limit'), rate: n(b.rate, 0, 100, 'Tax rate') }));
  need(brackets.length && brackets[brackets.length - 1].upTo === null, 'The last tax bracket must have no upper limit.');
  for (let i = 1; i < brackets.length - 1; i++) need(brackets[i].upTo > brackets[i - 1].upTo, 'Tax brackets must go up in order.');
  const hol = (r.publicHolidays || []).map((h) => ({ date: txt(h.date), name: txt(h.name) })).filter((h) => h.date);
  hol.forEach((h) => need(DATE.test(h.date), `Holiday date ${h.date}: use YYYY-MM-DD.`));
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const clean = {
    confirmed: !!r.confirmed, normalHoursWeek: n(r.normalHoursWeek, 1, 80, 'Normal hours a week'), normalHoursDay: n(r.normalHoursDay, 0, 24, 'Normal hours a day'),
    otMultiplier: n(r.otMultiplier, 1, 4, 'Overtime rate'), sundayMultiplier: n(r.sundayMultiplier, 1, 4, 'Sunday rate'), holidayMultiplier: n(r.holidayMultiplier, 1, 4, 'Public holiday rate'),
    leaveHoursPerDay: n(r.leaveHoursPerDay, 0, 24, 'Leave hours a day'), minimumWage: n(r.minimumWage, 0, 100, 'Minimum wage'),
    fnpfEmployeePct: n(r.fnpfEmployeePct, 0, 50, 'FNPF employee %'), fnpfEmployerPct: n(r.fnpfEmployerPct, 0, 50, 'FNPF employer %'),
    fnpfEmployerChanges: (Array.isArray(r.fnpfEmployerChanges) ? r.fnpfEmployerChanges : PAY_DEFAULTS.fnpfEmployerChanges).filter((c) => c && txt(c.from))
      .map((c) => { need(DATE.test(txt(c.from)), `FNPF employer rate change: date ${txt(c.from)} – use YYYY-MM-DD.`); return { from: txt(c.from), pct: n(c.pct, 0, 50, 'FNPF employer %') }; })
      .sort((a, b) => (a.from < b.from ? -1 : 1)),
    taxBrackets: brackets, srtBrackets: (r.srtBrackets || []).map((b) => ({ over: n(b.over, 0, 1e9, 'SRT from'), rate: n(b.rate, 0, 100, 'SRT rate') })),
    nonResidentRate: n(r.nonResidentRate, 0, 100, 'Non-resident rate'), noTinRate: n(r.noTinRate, 0, 100, 'No-TIN rate'),
    fnpfReducesTax: !!r.fnpfReducesTax, needCheckedTimesheets: !!r.needCheckedTimesheets, salaryOvertime: !!r.salaryOvertime, wagesDefaultShop: txt(r.wagesDefaultShop) || 'S1', wagesBankAccount: txt(r.wagesBankAccount),
    publicHolidays: hol.sort((a, b) => (a.date < b.date ? -1 : 1)), allowanceTypes: list(r.allowanceTypes), deductionTypes: list(r.deductionTypes),
  };
  const before = payRules();
  setShared('pay_rules', clean);
  audit({ user, action: 'Changed payroll rules', table: 'shared_settings', recordUid: 'pay_rules', before, after: clean });
  return clean;
}

// Yearly tax on yearly income using the brackets (+ SRT bands), then shared out per week.
export function annualTax(income, rules = payRules()) {
  let tax = 0;
  let low = 0;
  for (const b of rules.taxBrackets) {
    const top = b.upTo === null ? Infinity : b.upTo;
    if (income > low) tax += (Math.min(income, top) - low) * (b.rate / 100);
    low = top;
    if (income <= top) break;
  }
  for (const s of rules.srtBrackets || []) if (income > s.over) tax += (income - s.over) * (s.rate / 100);
  return r2(tax);
}
export function weeklyPaye(taxableWeek, profile, rules = payRules()) {
  if (taxableWeek <= 0) return 0;
  if (profile && profile.tax_status === 'non_resident') return r2(taxableWeek * (rules.nonResidentRate / 100));
  let t = r2(annualTax(taxableWeek * 52, rules) / 52);
  if (profile && !txt(profile.tin) && rules.noTinRate) t = Math.max(t, r2(taxableWeek * (rules.noTinRate / 100)));
  return t;
}

// ---------------------------------------------------------------- pay details per person
export function getProfile(userUid) {
  const p = db().get('SELECT * FROM pay_profiles WHERE user_uid = ?', [userUid]);
  return p ? { ...p, allowances: J(p.allowances, []), deductions: J(p.deductions, []) } : null;
}
export function listProfiles() {
  return db().all(`SELECT p.*, u.uid AS uid, u.name, u.employee_no, u.shop_code, u.active AS user_active FROM users u LEFT JOIN pay_profiles p ON p.user_uid = u.uid
    WHERE u.active = 1 AND u.sync_status <> 'seed' ORDER BY u.name`).map((r) => ({ ...r, user_uid: r.uid, allowances: J(r.allowances, []), deductions: J(r.deductions, []), hasProfile: r.pay_type !== null && r.pay_type !== undefined }));
}
export function saveProfile(user, p) {
  const u = db().get('SELECT * FROM users WHERE uid = ?', [p.userUid || '']);
  need(u, 'Staff member not found.');
  need(['hourly', 'salary'].includes(p.payType), 'Choose hourly or salary.');
  const rate = r2(p.rate);
  const sal = r2(p.weeklySalary);
  if (p.payType === 'hourly') need(rate > 0 && rate < 1000, 'Enter the hourly rate.');
  else need(sal > 0, 'Enter the weekly salary.');
  const nh = txt(p.normalHours) === '' ? null : Number(p.normalHours);
  need(nh === null || (nh > 0 && nh <= 80), 'Normal hours a week must be between 1 and 80.');
  need(['resident', 'non_resident'].includes(p.taxStatus || 'resident'), 'Choose the tax status.');
  need(['cash', 'bank'].includes(p.payMethod || 'cash'), 'Choose cash or bank.');
  if (p.payMethod === 'bank') need(txt(p.bankAccount), 'Enter the bank account for pay by bank.');
  const allowances = (p.allowances || []).filter((a) => txt(a.name) && r2(a.amount)).map((a) => ({ name: txt(a.name), amount: r2(a.amount), taxable: a.taxable !== false, fnpf: a.fnpf !== false }));
  const deductions = (p.deductions || []).filter((d) => txt(d.name) && r2(d.amount)).map((d) => ({ name: txt(d.name), amount: r2(d.amount) }));
  const before = getProfile(u.uid);
  // FNPF on / off is the owner's or admin's decision (Pay details › FNPF & PAYE).
  const fnpfMember = p.fnpfMember === false ? 0 : 1;
  if (!isTop(user)) need(before ? before.fnpf_member === fnpfMember || p.fnpfMember === undefined : fnpfMember === 1, 'Only the owner or admin can change whether a person pays FNPF.');
  const email = txt(p.email).toLowerCase();
  need(!email || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), 'The email address does not look right.');
  const { now, dev } = meta();
  db().run(`INSERT INTO pay_profiles (user_uid, pay_type, rate, weekly_salary, normal_hours, job_title, wage_category, fnpf_no, tin, tax_status, fnpf_member, fnpf_extra_pct, pay_method, bank_name, bank_account,
    allowances, deductions, start_date, end_date, active, notes, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(user_uid) DO UPDATE SET pay_type=excluded.pay_type, rate=excluded.rate, weekly_salary=excluded.weekly_salary, normal_hours=excluded.normal_hours, job_title=excluded.job_title,
    wage_category=excluded.wage_category, fnpf_no=excluded.fnpf_no, tin=excluded.tin, tax_status=excluded.tax_status, fnpf_member=excluded.fnpf_member, fnpf_extra_pct=excluded.fnpf_extra_pct,
    pay_method=excluded.pay_method, bank_name=excluded.bank_name, bank_account=excluded.bank_account, allowances=excluded.allowances, deductions=excluded.deductions, start_date=excluded.start_date,
    end_date=excluded.end_date, active=excluded.active, notes=excluded.notes, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [u.uid, p.payType, rate, sal, nh, txt(p.jobTitle) || null, txt(p.wageCategory) || null, txt(p.fnpfNo) || null, txt(p.tin).replace(/\D/g, '') || null, p.taxStatus || 'resident',
    p.fnpfMember === undefined && before ? before.fnpf_member : fnpfMember, Number(p.fnpfExtraPct) || 0, p.payMethod || 'cash', txt(p.bankName) || null, txt(p.bankAccount) || null, JSON.stringify(allowances), JSON.stringify(deductions),
    txt(p.startDate) || null, txt(p.endDate) || null, p.active === false ? 0 : 1, txt(p.notes) || null, now, dev]);
  const saved = before && J(before.fnpf_rule, null);
  if (saved && p.fnpfMember !== undefined && (saved.on !== false) !== (fnpfMember === 1)) db().run('UPDATE pay_profiles SET fnpf_rule = ? WHERE user_uid = ?', [JSON.stringify({ ...saved, on: fnpfMember === 1 }), u.uid]);
  if (p.email !== undefined || p.viber !== undefined) {
    db().run('UPDATE pay_profiles SET email = ?, viber = ? WHERE user_uid = ?', [p.email !== undefined ? email || null : (before && before.email) || null, p.viber !== undefined ? txt(p.viber) || null : (before && before.viber) || null, u.uid]);
  }
  audit({ user, action: `Pay details for ${u.name}`, table: 'pay_profiles', recordUid: u.uid, before: before && { type: before.pay_type, rate: before.rate, salary: before.weekly_salary },
    after: { type: p.payType, rate, salary: sal } });
  return getProfile(u.uid);
}

// ---------------------------------------------------------------- advances & staff loans
export function giveDebt(user, d) {
  assertOpen(String(d.date || dateStr()), 'This advance / loan');
  const u = db().get('SELECT * FROM users WHERE uid = ?', [d.userUid || '']);
  need(u, 'Choose the staff member.');
  need(['advance', 'loan'].includes(d.kind), 'Advance or loan?');
  const amt = r2(d.amount);
  need(amt > 0, 'Enter the amount.');
  const per = r2(d.repayPerPay || amt);
  need(per > 0 && per <= amt, 'The weekly repayment must be more than 0 and not more than the amount.');
  const date = txt(d.date) || dateStr();
  need(DATE.test(date), 'Enter the date as YYYY-MM-DD.');
  needReason(user, d.reason, 'Write the reason.');
  const { now, dev } = meta();
  const uid = uuid('SD');
  db().run(`INSERT INTO staff_debts (uid, user_uid, name, kind, debt_date, amount, repay_per_pay, reason, shop_code, paid_from, given_by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, u.uid, u.name, d.kind, date, amt, per, txt(d.reason), d.shopCode || null, d.paidFrom || 'cash', user.name, now, now, dev]);
  // An advance in cash comes out of the shop's cash on hand.
  if (d.paidFrom === 'cash' && d.shopCode) {
    try {
      db().run(`INSERT INTO cash_moves (uid, shop_code, move_date, type, amount, ref_uid, category, note, photo_urls, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,'petty_out',?,?,'Staff advance',?,'[]',?,?,?,?)`,
        [uuid('CM'), d.shopCode, date, amt, uid, `${d.kind === 'loan' ? 'Staff loan' : 'Advance'} to ${u.name}`, user.name, user.uid, now, dev]);
    } catch (e) { /* till module not installed */ }
  }
  audit({ user, action: `${d.kind === 'loan' ? 'Staff loan' : 'Advance'} ${$(amt)} to ${u.name}`, table: 'staff_debts', recordUid: uid, reason: d.reason });
  return uid;
}
export function voidDebt(user, uid, reason) {
  { const x = db().get('SELECT debt_date FROM staff_debts WHERE uid = ?', [uid]); if (x) assertOpen(x.debt_date, 'This advance / loan'); }
  needReason(user, reason, 'Give a reason.');
  const d = debtBalance(uid);
  need(d && d.status === 'active', 'Not found.');
  need(!d.repaid, 'Repayments were already taken in pay runs. Record a correction instead.');
  const { now, dev } = meta();
  db().run(`UPDATE staff_debts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  try { db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ?`, [txt(reason), now, dev, uid]); } catch (e) { /* none */ }
  audit({ user, action: `Voided ${d.kind} for ${d.name}`, table: 'staff_debts', recordUid: uid, reason });
}
// Repaid = deductions for this debt in FINAL pay runs.
export const DEBT_LABEL = { advance: 'Advance', loan: 'Staff loan', staff_credit: 'Staff credit (Aronium)', till_short: 'Till shortage', breakage: 'Breakage / damage', other: 'Deduction' };
// Staff charges (till shortages, breakages…) are taken from pay the same way as advances.
function chargeAsDebt(c) {
  return c && { uid: c.uid, user_uid: c.user_uid, name: c.name, kind: c.source || 'other', debt_date: c.charge_date, amount: c.amount, repay_per_pay: c.per_pay, reason: c.reason,
    shop_code: c.shop_code, given_by_name: c.by_name, status: c.status, void_reason: c.void_reason, ref_uid: c.ref_uid, charge: true,
    photos: (() => { try { return JSON.parse(c.photo_urls || '[]') || []; } catch (e) { return []; } })() };
}
export function debtBalance(uid) {
  let d = db().get('SELECT * FROM staff_debts WHERE uid = ?', [uid]);
  if (!d) d = chargeAsDebt(db().get('SELECT * FROM staff_charges WHERE uid = ?', [uid]));
  if (!d) return null;
  let repaid = 0;
  db().all(`SELECT l.deductions FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1`, [d.user_uid])
    .forEach((l) => J(l.deductions, []).forEach((x) => { if (x.debtUid === uid) repaid += x.amount; }));
  return { ...d, repaid: r2(repaid), balance: r2(d.amount - repaid) };
}
export function listDebts({ userUid, open = true } = {}) {
  const ids = db().all(`SELECT uid, debt_date AS d FROM staff_debts WHERE status = 'active' AND (? IS NULL OR user_uid = ?)
    UNION ALL SELECT uid, charge_date AS d FROM staff_charges WHERE status = 'active' AND (? IS NULL OR user_uid = ?) ORDER BY d`, [userUid || null, userUid || null, userUid || null, userUid || null]);
  return ids.map((x) => debtBalance(x.uid)).filter((d) => !open || d.balance > 0.004);
}

// A charge to a staff member, taken from pay (till shortage, breakage, other). Admin can void it with a reason.
export function chargeStaff(user, { userUid, amount, perPay, reason, source = 'other', refUid, shopCode, date, photos = [] }) {
  assertOpen(String(date || dateStr()), 'This charge');
  const u = db().get('SELECT * FROM users WHERE uid = ?', [userUid || '']);
  need(u, 'Choose the staff member.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  const per = r2(perPay || a);
  need(per > 0 && per <= a, 'The weekly amount must be more than 0 and not more than the total.');
  needReason(user, reason, 'Write the reason.');
  // Staff credit is kept in Aronium: the receipt / customer statement from Aronium is the proof for the pay deduction.
  if (source === 'staff_credit') need((photos || []).length, 'Take a photo of the Aronium receipt or credit statement – it is the proof for this pay deduction.');
  const { now, dev } = meta();
  const uid = uuid('SC');
  db().run(`INSERT INTO staff_charges (uid, user_uid, name, charge_date, amount, per_pay, reason, source, ref_uid, shop_code, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, u.uid, u.name, txt(date) || dateStr(), a, per, txt(reason), source, refUid || null, shopCode || null, user.name, now, now, dev]);
  if ((photos || []).length) addPhotos('charge', uid, photos);
  audit({ user, action: `${DEBT_LABEL[source] || 'Deduction'} ${$(a)} charged to ${u.name}`, table: 'staff_charges', recordUid: uid, reason });
  return uid;
}
export function voidCharge(user, uid, reason) {
  { const x = db().get('SELECT charge_date FROM staff_charges WHERE uid = ?', [uid]); if (x) assertOpen(x.charge_date, 'This charge'); }
  needReason(user, reason, 'Give a reason.');
  const d = debtBalance(uid);
  need(d && d.charge && d.status === 'active', 'Not found.');
  need(!d.repaid, 'Part of it was already taken from pay. Give the money back as extra pay instead.');
  const { now, dev } = meta();
  db().run(`UPDATE staff_charges SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Cancelled ${DEBT_LABEL[d.kind] || 'deduction'} for ${d.name}`, table: 'staff_charges', recordUid: uid, reason });
}

// ---------------------------------------------------------------- FNPF / PAYE per person (owner/admin only)
// Pay kinds (used for "only certain pay kinds" and the payslip). Extra pay is put in a kind by its name.
export const PAY_KINDS = { salary: 'Salary', normal: 'Normal hours', ot: 'Overtime', sunday: 'Sunday', holiday: 'Public holiday', leave: 'Paid leave', allowance: 'Allowances', bonus: 'Bonus', backpay: 'Back pay' };
export const RULE_MODES = { all: 'All pay', fixed: 'Fixed amount a week', pct: '% of gross pay', kinds: 'Only certain pay kinds', hours: 'Set hours a week (v3.9.7)' };
export function kindOfExtra(a) {
  if (a && a.kind && PAY_KINDS[a.kind]) return a.kind;
  const t = String((a && (a.label || a.name)) || '');
  if (/bonus/i.test(t)) return 'bonus';
  if (/back\s*-?pay/i.test(t)) return 'backpay';
  if (/overtime/i.test(t)) return 'ot';
  return 'allowance';
}
const DEFAULT_RULE = { on: true, mode: 'all', amount: 0, pct: 100, kinds: [], note: '' };
// The rule for one person (old pay details: FNPF on/off came from fnpf_member).
export function statRuleOf(profile, which) {
  const saved = profile ? J(profile[which === 'fnpf' ? 'fnpf_rule' : 'paye_rule'], null) : null;
  const r = { ...DEFAULT_RULE, ...(saved || {}) };
  if (!saved && which === 'fnpf' && profile && profile.fnpf_member === 0) r.on = false;
  return r;
}
export function ruleWords(rule) {
  if (!rule || rule.on === false) return `Not counted${rule && rule.note ? ` – ${rule.note}` : ''}`;
  const base = rule.mode === 'hours' ? `Counted on ${Number(rule.hours) || 0} hours a week` : rule.mode === 'fixed' ? `Fixed ${$(rule.amount)} a week` : rule.mode === 'pct' ? `${rule.pct}% of gross pay` : rule.mode === 'kinds' ? `Only ${(rule.kinds || []).map((k) => PAY_KINDS[k] || k).join(', ') || 'nothing'}` : 'All pay';
  return `${base}${rule.note ? ` – ${rule.note}` : ''}`;
}
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
export const STAT_RULE_HINT = 'Check with your accountant, FNPF and FRCS before changing who pays FNPF or PAYE, or on which pay.';
// Only the owner or admin may change who pays FNPF / PAYE and on which pay.
export function saveStatRule(user, userUid, which, rule) {
  need(isTop(user), 'Only the owner or admin can change FNPF / PAYE for a person.');
  need(['fnpf', 'paye'].includes(which), 'FNPF or PAYE?');
  const p = getProfile(userUid);
  need(p, 'Add the pay details first.');
  const mode = RULE_MODES[rule.mode] ? rule.mode : 'all';
  const clean = { on: rule.on !== false, mode, amount: r2(rule.amount), pct: Number(rule.pct === undefined || rule.pct === '' ? 100 : rule.pct), kinds: (rule.kinds || []).filter((k) => PAY_KINDS[k]), hours: Math.round((Number(rule.hours) || 0) * 100) / 100, note: txt(rule.note) };
  if (clean.on && mode === 'hours') need(which === 'fnpf', 'Set hours are for FNPF only.');
  if (clean.on && mode === 'hours') need(clean.hours > 0 && clean.hours <= 80, 'Enter the hours a week FNPF is counted on (1 to 80).');
  if (clean.on && mode === 'fixed') need(clean.amount > 0, 'Enter the fixed amount a week.');
  if (clean.on && mode === 'pct') need(clean.pct > 0 && clean.pct <= 100, 'The % of gross must be between 1 and 100.');
  if (clean.on && mode === 'kinds') need(clean.kinds.length, 'Choose at least one kind of pay.');
  if (!clean.on) need(clean.note || !reasonRequired(user), 'Write a note why this person does not pay it.');
  const before = statRuleOf(p, which);
  const { now, dev } = meta();
  db().run(`UPDATE pay_profiles SET ${which === 'fnpf' ? 'fnpf_rule' : 'paye_rule'} = ?${which === 'fnpf' ? ', fnpf_member = ?' : ''}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE user_uid = ?`,
    which === 'fnpf' ? [JSON.stringify(clean), clean.on ? 1 : 0, now, dev, userUid] : [JSON.stringify(clean), now, dev, userUid]);
  const u = db().get('SELECT name FROM users WHERE uid = ?', [userUid]) || {};
  audit({ user, action: `${which === 'fnpf' ? 'FNPF' : 'PAYE'} for ${u.name || userUid}: ${ruleWords(clean)}`, table: 'pay_profiles', recordUid: userUid, before, after: clean, reason: clean.note || null });
  return clean;
}
// Pay counted under a rule. items: [{ kind, amount, excluded }] (excluded = allowance marked "no FNPF" / "not taxed").
// v3.9.7 mode 'hours': FNPF on a set number of hours a week at the person's rate (all hours are still paid);
// ctx = { rate, hours: the hours for this period when changed for one week }.
export function countedPay(rule, items, gross, weeks, ctx = {}) {
  if (!rule || rule.on === false) return 0;
  const usual = r2(items.filter((i) => !i.excluded).reduce((s, i) => s + i.amount, 0));
  if (rule.mode === 'hours') {
    const h = ctx.hours !== undefined && ctx.hours !== null ? Number(ctx.hours) : (Number(rule.hours) || 0) * (weeks || 1);
    return r2(Math.max(0, Math.min(usual, h * (Number(ctx.rate) || 0))));
  }
  if (rule.mode === 'fixed') return r2(Math.max(0, Math.min(usual, r2(rule.amount) * (weeks || 1))));
  if (rule.mode === 'pct') return r2(Math.max(0, gross) * (Number(rule.pct) || 0) / 100);
  if (rule.mode === 'kinds') return r2(items.filter((i) => !i.excluded && (rule.kinds || []).includes(i.kind)).reduce((s, i) => s + i.amount, 0));
  return usual;
}
// PAYE for one pay period (yearly brackets shared out over the periods in a year).
export function periodPaye(taxable, profile, rules = payRules(), perYear = 52) {
  if (taxable <= 0) return 0;
  if (profile && profile.tax_status === 'non_resident') return r2(taxable * (rules.nonResidentRate / 100));
  let t = r2(annualTax(taxable * perYear, rules) / perYear);
  if (profile && !txt(profile.tin) && rules.noTinRate) t = Math.max(t, r2(taxable * (rules.noTinRate / 100)));
  return t;
}

// ---------------------------------------------------------------- working out one person's pay period
function holidaysIn(rules, from, to) {
  const out = {};
  (rules.publicHolidays || []).forEach((h) => { if (h.date >= from && h.date <= to) out[h.date] = h.name; });
  return out;
}
// The latest regular pay of a person before a date (extra pay is taxed on top of it).
function lastRegularTaxable(userUid, before) {
  const r = db().get(`SELECT l.taxable FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 AND IFNULL(r.run_kind,'regular') = 'regular' AND r.pay_date <= ?
    ORDER BY r.pay_date DESC LIMIT 1`, [userUid, before]);
  return r ? r.taxable : 0;
}
const h2sum = (h) => Math.round(['normal', 'ot', 'sunday', 'holiday', 'leave'].reduce((a, k) => a + (Number((h || {})[k]) || 0), 0) * 100) / 100;
// v3.9.7 family member split (pay_profiles.family_split): { on, wages: wages a week, memberId, note }.
export function familySplitOf(profile) {
  const f = profile ? J(profile.family_split, null) : null;
  if (!f || f.on === false || profile.pay_type !== 'salary') return null;
  const wages = r2(f.wages);
  if (!(wages >= 0)) return null;
  return { on: true, wages: Math.min(wages, r2(profile.weekly_salary)), memberId: txt(f.memberId) || null, note: txt(f.note) };
}
// Only the owner or admin sets a family member's split (fixed pay a week, the wages part with FNPF; the rest drawings).
export function saveFamilySplit(user, userUid, { on = true, weekly, wages, memberId, note } = {}) {
  need(isTop(user), 'Only the owner or admin can set a family member\'s pay split.');
  const p = getProfile(userUid);
  need(p, 'Add the pay details first.');
  const u = db().get('SELECT name FROM users WHERE uid = ?', [userUid]) || {};
  const { now, dev } = meta();
  if (on === false) {
    db().run(`UPDATE pay_profiles SET family_split = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE user_uid = ?`, [now, dev, userUid]);
    audit({ user, action: `Family pay split turned off for ${u.name || userUid}`, table: 'pay_profiles', recordUid: userUid, reason: txt(note) || null });
    return null;
  }
  const total = weekly !== undefined && weekly !== '' ? r2(weekly) : r2(p.weekly_salary);
  need(total > 0, 'Enter the fixed pay a week.');
  const w = r2(wages);
  need(w >= 0 && w <= total, 'The wages part must be between $0 and the fixed pay a week.');
  const before = J(p.family_split, null);
  const clean = { on: true, wages: w, memberId: txt(memberId) || null, note: txt(note) };
  db().run(`UPDATE pay_profiles SET pay_type = 'salary', weekly_salary = ?, family_split = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE user_uid = ?`, [total, JSON.stringify(clean), now, dev, userUid]);
  audit({ user, action: `Family pay for ${u.name || userUid}: ${$(total)} a week – wages ${$(w)} (FNPF / PAYE), owner's drawings ${$(r2(total - w))}`, table: 'pay_profiles', recordUid: userUid, before, after: { total, ...clean }, reason: clean.note || null });
  return clean;
}
// v3.9.7 who sees the finer details of a pay run (rates, hours changes and why, FNPF hours, the drawings part):
// while it is a draft, those who run payroll; once it is final, the owner and admin only. Everyone else sees the clean payslip.
export function seesPayDetails(user, run) {
  if (isTop(user)) return true;
  if (!run || run.status !== 'draft') return false;
  try { return require('../../services/access.js').can(user, 'payroll_run'); } catch (e) { return false; }
}
// extra: { overrides, adjustments, deductions, skipDebts, include, periodTo, frequency, kind: 'regular'|'extra', payDate, takeDebts }
export function computeLine(user, profile, weekStartDate, rules = payRules(), extra = {}) {
  const ws = weekStartDate;
  const we = extra.periodTo || addDays(ws, 6);
  const isExtra = extra.kind === 'extra';
  const days = Math.round((Date.UTC(...we.split('-').map((x, i) => (i === 1 ? Number(x) - 1 : Number(x)))) - Date.UTC(...ws.split('-').map((x, i) => (i === 1 ? Number(x) - 1 : Number(x))))) / 86400000) + 1;
  const monthly = extra.frequency === 'monthly';
  const weeks = isExtra ? 1 : monthly ? 52 / 12 : Math.max(1, days / 7);
  const perYear = isExtra ? 52 : monthly ? 12 : Math.max(1, Math.round(52 / weeks));
  const ov = extra.overrides || {};
  const warnings = [];
  const hol = holidaysIn(rules, ws, we);
  const shifts = isExtra ? [] : (shiftsBetween(ws, we, { userUid: user.uid })[0] || { shifts: [] }).shifts.slice().sort((a, b) => ((a.in_at || '') < (b.in_at || '') ? -1 : 1));
  const weekNormal = (profile.normal_hours || rules.normalHoursWeek) * 60;
  let normal = 0; let ot = 0; let sunday = 0; let holiday = 0;
  // Overtime is worked out per week (7-day blocks from the start of the period).
  const usedInBlock = {};
  for (const s of shifts) {
    const m = s.workedMinutes;
    if (s.problems) warnings.push(`Timesheet problem on ${s.date}`);
    const dow = new Date(`${s.date}T00:00:00`).getDay();
    if (hol[s.date]) { holiday += m; continue; }
    if (dow === 0 && rules.sundayMultiplier > 1) { sunday += m; continue; }
    let dayNormal = m;
    let dayOt = 0;
    if (rules.normalHoursDay > 0 && m > rules.normalHoursDay * 60) { dayNormal = rules.normalHoursDay * 60; dayOt = m - dayNormal; }
    const block = Math.floor((Date.parse(`${s.date}T00:00:00Z`) - Date.parse(`${ws}T00:00:00Z`)) / (7 * 86400000));
    const room = Math.max(0, weekNormal - (usedInBlock[block] || 0));
    const toNormal = Math.min(room, dayNormal);
    usedInBlock[block] = (usedInBlock[block] || 0) + toNormal;
    normal += toNormal;
    ot += dayOt + (dayNormal - toNormal);
  }
  // Paid leave (approved) in the period.
  let leaveDays = 0;
  if (!isExtra) {
    const leave = listLeave({ status: 'approved', userUid: user.uid, from: ws, to: we }).filter((l) => l.paid);
    const worked = new Set(shifts.filter((s) => s.workedMinutes > 0).map((s) => s.date));
    leave.forEach((l) => {
      for (let d = l.from_date; d <= l.to_date; d = addDays(d, 1)) {
        if (d < ws || d > we || hol[d] || worked.has(d)) continue;
        if (!countLeaveDays(d, d)) continue; // same day rule as the leave balance (e.g. Mon–Sat)
        leaveDays += l.days === 0.5 ? 0.5 : 1;
      }
    });
    if (rules.needCheckedTimesheets && shifts.length) {
      for (let b = ws; b <= we; b = addDays(b, 7)) {
        const blockShifts = shifts.filter((s) => s.date >= b && s.date <= addDays(b, 6));
        if (!blockShifts.length) continue;
        const check = checkFor(user.uid, weekStart(b));
        if (!(check && check.status === 'checked')) { warnings.push('Timesheet week not ticked as checked'); break; }
      }
    }
  }
  // v3.9.5 unpaid days marked on the roster (absent, or sick without a sheet). Hourly staff are simply not paid for
  // hours not worked; a salary has the days taken off (salary ÷ working days a week, 6 by default).
  let unpaid = [];
  if (!isExtra) {
    try {
      const worked = new Set(shifts.filter((s) => s.workedMinutes > 0).map((s) => s.date));
      unpaid = require('../timesheets/absence.js').unpaidDays(user.uid, ws, we).filter((m) => !hol[m.mark_date] && !worked.has(m.mark_date));
    } catch (e) { unpaid = []; }
    if (unpaid.length) warnings.push(`${unpaid.length} unpaid day${unpaid.length === 1 ? '' : 's'}: ${unpaid.map((m) => `${m.mark_date} ${m.kind === 'sick' ? 'sick, no sheet' : `absent${m.reason ? ` (${m.reason})` : ''}`}`).join(', ')}`);
  }
  // v3.9.7 the hours worked (from the timesheet) are kept next to the hours paid, which the payroll manager may change.
  const worked = isExtra ? {} : { normal: h2(normal), ot: h2(ot), sunday: h2(sunday), holiday: h2(holiday), leave: r2(leaveDays * rules.leaveHoursPerDay) };
  const hours = isExtra ? {} : {
    normal: ov.normal !== undefined ? Number(ov.normal) : h2(normal), ot: ov.ot !== undefined ? Number(ov.ot) : h2(ot), sunday: ov.sunday !== undefined ? Number(ov.sunday) : h2(sunday),
    holiday: ov.holiday !== undefined ? Number(ov.holiday) : h2(holiday), leave: ov.leave !== undefined ? Number(ov.leave) : r2(leaveDays * rules.leaveHoursPerDay),
  };
  const rate = ov.rate !== undefined ? r2(ov.rate) : profile.pay_type === 'hourly' ? r2(profile.rate) : r2(profile.weekly_salary / (profile.normal_hours || rules.normalHoursWeek));
  if (!isExtra && profile.pay_type === 'hourly' && rate < rules.minimumWage) warnings.push(`Rate ${$(rate)} is below the minimum wage ${$(rules.minimumWage)}`);
  let earnings = {};
  // v3.9.7 family member: a fixed pay a week, part of it wages (FNPF / PAYE) and the rest owner's drawings (set by the admin).
  const fam = familySplitOf(profile);
  let drawings = 0;
  if (!isExtra && fam) {
    const total = r2(Number(profile.weekly_salary) * weeks);
    const wages = r2(Math.min(total, fam.wages * weeks));
    drawings = r2(total - wages);
    earnings = { salary: wages };
  } else if (!isExtra) {
    earnings = profile.pay_type === 'salary'
      ? { salary: r2(Math.max(0, profile.weekly_salary * weeks - (ov.salary === undefined && rules.deductUnpaidSalary !== false ? unpaid.length * (profile.weekly_salary / (Number(rules.workDaysWeek) || 6)) : 0))), ot: r2(hours.ot * rate * rules.otMultiplier), sunday: r2(hours.sunday * rate * (rules.sundayMultiplier - 1)), holiday: r2(hours.holiday * rate * (rules.holidayMultiplier - 1)) }
      : { normal: r2(hours.normal * rate), ot: r2(hours.ot * rate * rules.otMultiplier), sunday: r2(hours.sunday * rate * rules.sundayMultiplier), holiday: r2(hours.holiday * rate * rules.holidayMultiplier), leave: r2(hours.leave * rate) };
    if (profile.pay_type === 'salary' && !rules.salaryOvertime) { earnings.ot = ov.ot !== undefined ? earnings.ot : 0; }
  }
  // Regular allowances are per week: a fortnight pays two, a month 52/12.
  const allowances = isExtra ? [] : (profile.allowances || []).map((a) => (weeks === 1 ? a : { ...a, amount: r2(a.amount * weeks) })).concat(extra.allowances || []);
  const adjustments = (extra.adjustments || []).map((a) => ({ ...a, kind: kindOfExtra(a) }));
  const gross = r2(Object.values(earnings).reduce((s, v) => s + v, 0) + allowances.reduce((s, a) => s + a.amount, 0) + adjustments.reduce((s, a) => s + a.amount, 0));
  // Every piece of pay with its kind, for the FNPF / PAYE rules.
  const items = Object.entries(earnings).map(([k, v]) => ({ kind: k, amount: v, fnpfOff: false, taxOff: false }))
    .concat(allowances.map((a) => ({ kind: kindOfExtra(a), amount: a.amount, fnpfOff: a.fnpf === false, taxOff: a.taxable === false })))
    .concat(adjustments.map((a) => ({ kind: a.kind, amount: a.amount, fnpfOff: a.fnpf === false, taxOff: a.taxable === false })));
  const fnpfRule = statRuleOf(profile, 'fnpf');
  const payeRule = statRuleOf(profile, 'paye');
  const fnpfHoursWeek = ov.fnpfHours !== undefined && ov.fnpfHours !== null ? Number(ov.fnpfHours) : null;
  const fnpfRuleUsed = fnpfHoursWeek !== null && fnpfRule.on !== false ? { ...fnpfRule, mode: 'hours', hours: fnpfHoursWeek } : fnpfRule;
  const fnpfBase = countedPay(fnpfRuleUsed, items.map((i) => ({ kind: i.kind, amount: i.amount, excluded: i.fnpfOff })), gross, weeks, { rate, hours: fnpfHoursWeek });
  const member = fnpfRule.on !== false;
  const fnpfEmployee = member ? r2(fnpfBase * ((rules.fnpfEmployeePct + (Number(profile.fnpf_extra_pct) || 0)) / 100)) : 0;
  const fnpfEmployer = member ? r2(fnpfBase * (employerPctOn(rules, extra.payDate || addDays(weekStartDate, 7)) / 100)) : 0;
  let taxable = countedPay(payeRule, items.map((i) => ({ kind: i.kind, amount: i.amount, excluded: i.taxOff })), gross, weeks);
  if (rules.fnpfReducesTax && taxable > 0) taxable = r2(Math.max(0, taxable - fnpfEmployee));
  let paye;
  if (ov.paye !== undefined) paye = r2(ov.paye);
  else if (payeRule.on === false) paye = 0;
  else if (isExtra) { const base = lastRegularTaxable(user.uid, extra.payDate || we); paye = r2(Math.max(0, periodPaye(base + taxable, profile, rules, 52) - periodPaye(base, profile, rules, 52))); }
  else paye = periodPaye(taxable, profile, rules, perYear);
  const paidChanged = !isExtra && ['normal', 'ot', 'sunday', 'holiday', 'leave'].some((k) => Math.abs((Number(hours[k]) || 0) - (Number(worked[k]) || 0)) > 0.004);
  const fnpfHours = fnpfRuleUsed.mode === 'hours' && fnpfRuleUsed.on !== false ? (fnpfHoursWeek !== null ? fnpfHoursWeek : r2((Number(fnpfRule.hours) || 0) * weeks)) : null;
  const counted = { fnpf: { base: fnpfBase, words: ruleWords(fnpfRuleUsed) + (fnpfHoursWeek !== null ? ' (this period only)' : '') }, paye: { base: taxable, words: ruleWords(payeRule) },
    worked, paidChanged, fnpfHours, drawings, family: fam ? { total: r2(Number(profile.weekly_salary) * weeks), wages: r2(fam.wages * weeks), drawings } : null };
  if (payeRule.on !== false && !txt(profile.tin)) warnings.push('No TIN');
  if (member && !txt(profile.fnpf_no)) warnings.push('No FNPF number');
  // Deductions: regular ones from the pay details, advances / loans / staff charges, and ones added to this run.
  const deductions = (isExtra ? [] : (profile.deductions || []).map((d) => ({ label: d.name, amount: r2(d.amount * weeks), kind: 'regular' }))).concat(extra.deductions || []);
  let left = r2(gross - fnpfEmployee - paye - deductions.reduce((s, d) => s + d.amount, 0));
  if (!isExtra || extra.takeDebts) {
    for (const debt of listDebts({ userUid: user.uid })) {
      if (debt.debt_date > we) continue;
      const skip = (extra.skipDebts || []).includes(debt.uid);
      if (skip) continue;
      const take = r2(Math.min(debt.repay_per_pay, debt.balance, Math.max(0, left)));
      // Each charge is its own payslip line; till shortages and staff credit are highlighted.
      if (take > 0) {
        deductions.push({ label: `${DEBT_LABEL[debt.kind] || 'Deduction'} (${debt.debt_date})`, amount: take, debtUid: debt.uid, kind: debt.kind, ...(debt.reason ? { detail: debt.reason } : {}),
          ...(debt.kind === 'till_short' || debt.kind === 'staff_credit' ? { highlight: true } : {}) });
        left = r2(left - take);
      }
      if (take < Math.min(debt.repay_per_pay, debt.balance)) warnings.push(`Not enough pay to take the full ${DEBT_LABEL[debt.kind] || debt.kind} repayment`);
    }
    // v3.9.5 staff credit straight from Aronium (the till PCs send the balance and the sales behind it): taken on pay day,
    // the payslip lists the sales it pays. Not when the credit is also typed in the app as a charge (that is taken above).
    if (!isExtra && rules.aroniumCredit !== false) {
      try {
        const O = require('../owed/service.js');
        const typed = listDebts({ userUid: user.uid }).some((d) => d.kind === 'staff_credit' && d.balance > 0.004);
        const ar = typed ? null : O.aroniumCreditDeduction(user.uid, we);
        if (ar && !(extra.skipDebts || []).includes(ar.debtUid)) {
          const take = r2(Math.min(ar.amount, Math.max(0, left)));
          if (take > 0) {
            deductions.push({ label: 'Staff credit (Aronium)', amount: take, debtUid: ar.debtUid, kind: 'staff_credit', highlight: true, aronium: true,
              detail: ar.sales.length ? `Pays: ${O.salesText(ar.sales)}` : `Aronium balance ${$(ar.balance)} on ${ar.asOf}`, sales: ar.sales.map((d) => ({ date: d.date, number: d.number, owing: d.owing, items: (d.items || []).slice(0, 6) })) });
            left = r2(left - take);
          }
          if (take < ar.amount) warnings.push(`Not enough pay to take all the Aronium staff credit (${$(ar.amount)})`);
        }
      } catch (e) { /* who owes us not in use */ }
    }
  }
  // Till shortages the cashier has not agreed to yet (or disagreed with): shown red in the pay run until decided.
  const undecided = [];
  try {
    const { undecidedShortages } = require('../till/shifts.js');
    undecidedShortages({ userUid: user.uid, to: we }).forEach((x) => {
      undecided.push({ uid: x.uid, amount: r2(x.amount), date: x.shift_date, shop: x.shop_code, status: x.status });
      warnings.push(`Till shortage ${$(x.amount)} (${x.shift_date}) not decided yet${x.status === 'disagreed' ? ' – cashier disagrees, manager to decide' : ' – cashier to agree'}`);
    });
  } catch (e) { /* till module not there */ }
  const totalDeductions = r2(fnpfEmployee + paye + deductions.reduce((s, d) => s + d.amount, 0));
  const net = r2(gross - totalDeductions);
  if (net < 0) warnings.push('Net pay is below zero');
  if (!isExtra && !shifts.length && profile.pay_type === 'hourly' && !hours.leave && !ov.normal) warnings.push('No hours this week');
  if (paidChanged) warnings.push(`Paid hours changed: worked ${h2sum(worked)} h, paid ${h2sum(hours)} h`);
  return { hours, worked, rate, earnings, allowances, adjustments, gross, taxable, fnpfBase, fnpfEmployee, fnpfEmployer, paye, deductions, totalDeductions, net, drawings, counted, undecided, unpaidDays: unpaid.length, warnings: Array.from(new Set(warnings)) };
}

// ---------------------------------------------------------------- pay runs
export const RUN_KIND = { regular: 'Regular pay', extra: 'Extra pay run' };
export function getRun(uid) {
  const r = db().get('SELECT * FROM pay_runs WHERE uid = ?', [uid]);
  if (!r) return null;
  r.totals = J(r.totals, {});
  r.run_kind = r.run_kind || 'regular';
  r.version = r.version || 1;
  r.lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? ORDER BY name', [uid]).map(decodeLine);
  return r;
}
export function decodeLine(l) {
  return { ...l, hours: J(l.hours, {}), earnings: J(l.earnings, {}), allowances: J(l.allowances, []), adjustments: J(l.adjustments, []), overrides: J(l.overrides, {}), deductions: J(l.deductions, []), warnings: J(l.warnings, []),
    counted: J(l.counted, null), undecided: J(l.undecided, []) };
}
export function listRuns({ includeVoid = false } = {}) {
  return db().all(`SELECT * FROM pay_runs WHERE (? = 1 OR status <> 'void') ORDER BY pay_date DESC, week_start DESC`, [includeVoid ? 1 : 0]).map((r) => ({ ...r, run_kind: r.run_kind || 'regular', version: r.version || 1, totals: J(r.totals, {}) }));
}
const runExtra = (run) => ({ periodTo: run.week_end, frequency: run.frequency || 'weekly', kind: run.run_kind || 'regular', payDate: run.pay_date });
function writeLine(run, u, profile, extra, edit) {
  const c = computeLine(u, profile, run.week_start, payRules(), { ...extra, ...runExtra(run), takeDebts: !!(extra.overrides && extra.overrides.takeDebts) });
  const { now, dev } = meta();
  const runUid = run.uid;
  const uid = `${runUid}|${u.uid}`;
  db().run(`INSERT INTO pay_lines (uid, run_uid, user_uid, name, employee_no, shop_code, pay_type, rate, hours, earnings, allowances, adjustments, overrides, gross, taxable, fnpf_base, fnpf_employee,
    fnpf_employer, paye, deductions, total_deductions, net, pay_method, warnings, edited_by_name, edit_reason, include, counted, undecided, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET name=excluded.name, employee_no=excluded.employee_no, shop_code=excluded.shop_code, pay_type=excluded.pay_type, rate=excluded.rate, hours=excluded.hours, earnings=excluded.earnings,
    allowances=excluded.allowances, adjustments=excluded.adjustments, overrides=excluded.overrides, gross=excluded.gross, taxable=excluded.taxable, fnpf_base=excluded.fnpf_base, fnpf_employee=excluded.fnpf_employee,
    fnpf_employer=excluded.fnpf_employer, paye=excluded.paye, deductions=excluded.deductions, total_deductions=excluded.total_deductions, net=excluded.net, pay_method=excluded.pay_method, warnings=excluded.warnings,
    edited_by_name=excluded.edited_by_name, edit_reason=excluded.edit_reason, include=excluded.include, counted=excluded.counted, undecided=excluded.undecided, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, runUid, u.uid, u.name, u.employee_no || null, u.shop_code || null, profile.pay_type, c.rate, JSON.stringify(c.hours), JSON.stringify(c.earnings), JSON.stringify(c.allowances), JSON.stringify(c.adjustments),
    JSON.stringify(extra.overrides || {}), c.gross, c.taxable, c.fnpfBase, c.fnpfEmployee, c.fnpfEmployer, c.paye, JSON.stringify(c.deductions), c.totalDeductions, c.net, profile.pay_method,
    JSON.stringify(c.warnings), edit ? edit.by : null, edit ? edit.reason : null, extra.include === false ? 0 : 1, JSON.stringify(c.counted), JSON.stringify(c.undecided), now, dev]);
  return uid;
}
function extraOf(line) {
  if (!line) return {};
  const manualDeds = line.deductions.filter((d) => d.manual).map((d) => ({ label: d.label, amount: d.amount, manual: true }));
  return { overrides: line.overrides, adjustments: line.adjustments, deductions: manualDeds, include: !!line.include, skipDebts: line.overrides.skipDebts || [] };
}
function retotal(runUid) {
  const lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1', [runUid]);
  const sum = (k) => r2(lines.reduce((s, l) => s + l[k], 0));
  const totals = { people: lines.length, gross: sum('gross'), paye: sum('paye'), fnpfEmployee: sum('fnpf_employee'), fnpfEmployer: sum('fnpf_employer'), net: sum('net'),
    deductions: r2(sum('total_deductions') - sum('paye') - sum('fnpf_employee')), cash: r2(lines.filter((l) => l.pay_method !== 'bank').reduce((s, l) => s + l.net, 0)),
    bank: r2(lines.filter((l) => l.pay_method === 'bank').reduce((s, l) => s + l.net, 0)), warnings: lines.reduce((s, l) => s + J(l.warnings, []).length, 0),
    undecided: lines.reduce((s, l) => s + J(l.undecided, []).length, 0) };
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET totals = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(totals), now, dev, runUid]);
  return totals;
}

// A regular pay run for the pay period a date falls in (the pay cycle is set in Payroll › Pay cycle & pay day).
export function createRun(user, anyDateInPeriod, { cycle } = {}) {
  const c = cycle || payCycle();
  const per = payPeriod(anyDateInPeriod || addDays(dateStr(), -1), c);
  const ws = per.from;
  const we = per.to;
  const existing = db().get("SELECT uid, status, week_start, week_end FROM pay_runs WHERE status <> 'void' AND IFNULL(run_kind,'regular') = 'regular' AND NOT (week_end < ? OR week_start > ?)", [ws, we]);
  need(!existing, `There is already a pay run for the week ${existing && existing.week_start} (${existing && existing.status}).`);
  const people = listProfiles().filter((p) => p.hasProfile && p.active !== 0);
  need(people.length, 'No one has pay details yet. Add them in Payroll › Pay details.');
  // Each run has its own id: a voided run stays as it was (history), and nothing is ever deleted.
  const uid = uuid(`PR-${ws}-`);
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, totals, created_by_name, created_at, run_kind, frequency, version, updated_at, updated_device) VALUES (?,?,?,?,'draft','{}',?,?,'regular',?,1,?,?)`,
      [uid, ws, we, per.payDate, user.name, now, per.frequency, now, dev]);
    const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [uid]);
    for (const p of people) {
      const u = db().get('SELECT * FROM users WHERE uid = ?', [p.user_uid]);
      if (p.start_date && p.start_date > we) continue;
      if (p.end_date && p.end_date < ws) continue;
      writeLine(run, u, getProfile(u.uid), {}, null);
    }
    retotal(uid);
  });
  audit({ user, action: `Started pay run for ${ws} to ${we}`, table: 'pay_runs', recordUid: uid });
  return getRun(uid);
}

// A one-off extra pay run (bonus, back pay…): only the people and amounts given, no hours.
// people: [{ userUid, amount, label?, kind?: 'bonus'|'backpay'|'allowance', taxable?, fnpf? }]
export function createExtraRun(user, { label, payDate, from, to, people = [], takeDebts = false }) {
  need(can(user, 'payroll_run') || isTop(user), 'You cannot start pay runs.');
  const pd = txt(payDate) || dateStr();
  need(DATE.test(pd), 'Choose the pay day.');
  const f = txt(from) || pd;
  const t = txt(to) || pd;
  need(DATE.test(f) && DATE.test(t) && f <= t, 'Choose the dates this extra pay is for.');
  const what = txt(label) || 'Extra pay';
  const list = people.filter((x) => x && x.userUid && r2(x.amount) > 0);
  need(list.length, 'Add at least one person and amount.');
  const uid = uuid(`PX-${pd}-`);
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, totals, created_by_name, created_at, run_kind, label, frequency, version, updated_at, updated_device) VALUES (?,?,?,?,'draft','{}',?,?,'extra',?,?,1,?,?)`,
      [uid, f, t, pd, user.name, now, what, payCycle().frequency, now, dev]);
    const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [uid]);
    for (const x of list) {
      const u = db().get('SELECT * FROM users WHERE uid = ?', [x.userUid]);
      const p = getProfile(x.userUid);
      need(u && p, 'Someone in the list has no pay details.');
      const kind = PAY_KINDS[x.kind] ? x.kind : kindOfExtra({ label: x.label || what });
      writeLine(run, u, p, { overrides: takeDebts ? { takeDebts: true } : {}, adjustments: [{ label: txt(x.label) || what, amount: r2(x.amount), kind, taxable: x.taxable !== false, fnpf: x.fnpf !== false }] }, null);
    }
    retotal(uid);
  });
  audit({ user, action: `Started extra pay run "${what}" paid ${pd} (${list.length} people)`, table: 'pay_runs', recordUid: uid });
  return getRun(uid);
}

// Work the whole run out again from the timesheets (keeps each line's changes).
export function recalcRun(user, runUid) {
  const r = getRun(runUid);
  need(r && r.status === 'draft', 'Only a draft pay run can be worked out again.');
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [runUid]);
  db().transaction(() => {
    for (const l of r.lines) {
      const u = db().get('SELECT * FROM users WHERE uid = ?', [l.user_uid]);
      const p = getProfile(l.user_uid);
      if (u && p) writeLine(run, u, p, extraOf(l), l.edited_by_name ? { by: l.edited_by_name, reason: l.edit_reason } : null);
    }
    retotal(runUid);
  });
}

// Change one line before the run is final: hours, rate, PAYE, extra pay, deductions, leave it out.
export function editLine(user, lineUid, change) {
  const l = db().get('SELECT * FROM pay_lines WHERE uid = ?', [lineUid]);
  need(l, 'Line not found.');
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [l.run_uid]);
  need(run.status === 'draft', 'This pay run is final. The owner or admin can reopen it to correct it.');
  need(isTop(user) || require('../../services/access.js').can(user, 'payroll_run'), 'Only the payroll manager, owner or admin can change pay.');
  needReason(user, change.reason, 'Write the reason for the change.');
  // v3.9.7 hours paid different from hours worked, or FNPF on other hours: always with a reason (owner and admin too).
  if (['normal', 'ot', 'sunday', 'holiday', 'leave', 'rate', 'fnpfHours'].some((k) => change[k] !== undefined && change[k] !== '' && change[k] !== null)) need(txt(change.reason), 'Write why the hours, rate or FNPF hours are different.');
  const cur = extraOf(decodeLine(l));
  const ov = { ...cur.overrides };
  ['normal', 'ot', 'sunday', 'holiday', 'leave', 'rate', 'paye', 'fnpfHours'].forEach((k) => {
    if (change[k] === undefined) return;
    if (change[k] === '' || change[k] === null) delete ov[k];
    else { const v = Number(change[k]); need(Number.isFinite(v) && v >= 0, `${k} must be a number.`); ov[k] = v; }
  });
  if (change.skipDebts) ov.skipDebts = change.skipDebts;
  const adjustments = change.adjustments !== undefined ? change.adjustments.filter((a) => txt(a.label) && r2(a.amount)).map((a) => ({ label: txt(a.label), amount: r2(a.amount), taxable: a.taxable !== false, fnpf: a.fnpf !== false, kind: kindOfExtra(a) })) : cur.adjustments;
  const deductions = change.deductions !== undefined ? change.deductions.filter((d) => txt(d.label) && r2(d.amount) > 0).map((d) => ({ label: txt(d.label), amount: r2(d.amount), manual: true })) : cur.deductions;
  const include = change.include !== undefined ? !!change.include : cur.include;
  const u = db().get('SELECT * FROM users WHERE uid = ?', [l.user_uid]);
  writeLine(run, u, getProfile(l.user_uid), { overrides: ov, adjustments, deductions, include, skipDebts: ov.skipDebts || [] }, { by: user.name, reason: txt(change.reason) });
  retotal(l.run_uid);
  audit({ user, action: `Changed pay for ${l.name} (${run.week_start})`, table: 'pay_lines', recordUid: lineUid, before: { gross: l.gross, net: l.net }, after: change, reason: change.reason });
  return decodeLine(db().get('SELECT * FROM pay_lines WHERE uid = ?', [lineUid]));
}

export function finaliseRun(user, runUid) {
  { const x = db().get('SELECT pay_date FROM pay_runs WHERE uid = ?', [runUid]); if (x) assertOpen(x.pay_date, 'This pay run'); }
  const r = getRun(runUid);
  need(r && r.status === 'draft', 'Only a draft pay run can be made final.');
  recalcRun(user, runUid);
  const bad = getRun(runUid).lines.filter((l) => l.include && l.net < 0);
  need(!bad.length, `${bad.map((l) => l.name).join(', ')}: net pay below zero. Fix before making final.`);
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET status = 'final', finalised_by_name = ?, finalised_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [user.name, now, now, dev, runUid]);
  // Pay by bank: one transfer out of the wages account (cash wages come off each shop's cash on hand by themselves).
  const fin = getRun(runUid);
  const bankAcc = payRules().wagesBankAccount;
  if (fin.totals.bank > 0 && bankAcc) {
    try {
      db().run(`INSERT OR REPLACE INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, status, by_name, updated_at, updated_device, sync_status) VALUES (?,?,?,'transfer_out',?,?,?,'active',?,?,?,'pending')`,
        [`BE-WAGES-${runUid}`, bankAcc, fin.pay_date, fin.totals.bank, `Wages ${fin.week_start}`, `Wages paid by bank, ${fin.run_kind === 'extra' ? fin.label || 'extra pay' : `week ${fin.week_start} to ${fin.week_end}`}`, user.name, now, dev]);
    } catch (e) { /* no bank module */ }
  }
  // v3.9.7 family members: the part of their fixed pay that is not wages is booked as owner's drawings.
  try { bookFamilyDrawings(user, fin); } catch (e) { /* drawings not in use – the pay run is still final */ }
  // Payslips are issued (again, after a correction): each person signs before their pay is released.
  try { require('./signoff.js').issuePayslips(fin); } catch (e) { /* sign-off not available */ }
  audit({ user, action: `Pay run ${r.week_start} made final${fin.version > 1 ? ` (corrected, version ${fin.version})` : ''}: net ${$(fin.totals.net)}`, table: 'pay_runs', recordUid: runUid });
  return getRun(runUid);
}
// Reopen a final pay run to correct it (owner / admin). Logged; everyone signs the corrected payslip again.
export function reopenRun(user, runUid, reason) {
  need(isTop(user), 'Only the owner or admin can reopen a final pay run.');
  const r = getRun(runUid);
  need(r && r.status === 'final', 'Only a final pay run can be reopened.');
  assertOpen(r.pay_date, 'This pay run');
  needReason(user, reason, 'Write why the pay run is reopened.');
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET status = 'draft', version = ?, reopened_by_name = ?, reopened_at = ?, reopen_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [(r.version || 1) + 1, user.name, now, txt(reason) || null, now, dev, runUid]);
  try { db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`Pay run reopened${reason ? `: ${txt(reason)}` : ''}`, now, dev, `BE-WAGES-${runUid}`]); } catch (e) { /* none */ }
  try { require('./signoff.js').payslipsReopened(user, r); } catch (e) { /* sign-off not available */ }
  try { voidFamilyDrawings(user, runUid, `Pay run reopened${reason ? `: ${txt(reason)}` : ''}`); } catch (e) { /* none */ }
  audit({ user, action: `Reopened pay run ${r.week_start} to ${r.week_end} to correct it`, table: 'pay_runs', recordUid: runUid, before: { status: 'final', version: r.version, net: r.totals.net }, after: { status: 'draft', version: (r.version || 1) + 1 }, reason: txt(reason) || null });
  return getRun(runUid);
}
export function voidRun(user, runUid, reason) {
  { const x = db().get('SELECT pay_date FROM pay_runs WHERE uid = ?', [runUid]); if (x) assertOpen(x.pay_date, 'This pay run'); }
  need(isTop(user), 'Only the owner or admin can void a pay run.');
  needReason(user, reason, 'Give a reason.');
  const r = getRun(runUid);
  need(r && r.status !== 'void', 'Not found.');
  const { now, dev } = meta();
  db().run(`UPDATE pay_runs SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || null, now, dev, runUid]);
  try { db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || null, now, dev, `BE-WAGES-${runUid}`]); } catch (e) { /* none */ }
  try { voidFamilyDrawings(user, runUid, `Pay run voided: ${txt(reason)}`); } catch (e) { /* none */ }
  audit({ user, action: `Voided pay run ${r.week_start}`, table: 'pay_runs', recordUid: runUid, reason });
}

// v3.9.7 the owner's drawings part of family members' pay (marked with the pay run, so a reopen or void undoes it).
const drawRef = (runUid) => `PAY-${runUid}`;
function bookFamilyDrawings(user, run) {
  const D = require('../drawings/service.js');
  const already = db().all("SELECT uid FROM owner_moves WHERE invoice_no = ? AND status = 'active'", [drawRef(run.uid)]);
  if (already.length) return;
  const bankAcc = payRules().wagesBankAccount;
  for (const l of run.lines.filter((x) => x.include)) {
    const c = l.counted || {};
    const amt = r2(c.drawings);
    if (!(amt > 0)) continue;
    const prof = getProfile(l.user_uid);
    const fam = familySplitOf(prof) || {};
    const via = l.pay_method === 'bank' && bankAcc ? `bank:${bankAcc}` : `cash:${l.shop_code || (db().get("SELECT code FROM shops WHERE active = 1 AND code LIKE 'S%' ORDER BY sort, code LIMIT 1") || {}).code}`;
    const members = D.memberOptions({ all: true });
    const memberId = fam.memberId && members.some((m) => m.value === fam.memberId) ? fam.memberId : (members.find((m) => String(m.label).toLowerCase() === String(l.name).toLowerCase()) || members[0] || {}).value;
    D.saveMove(user, { kind: 'take_out', date: run.pay_date, amount: amt, memberId, via, what: `${l.name} – family pay, drawings part (pay ${run.week_start} – ${run.week_end})`, invoiceNo: drawRef(run.uid) });
  }
}
function voidFamilyDrawings(user, runUid, reason) {
  if (!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'owner_moves'")) return;
  const D = require('../drawings/service.js');
  for (const m of db().all("SELECT uid FROM owner_moves WHERE invoice_no = ? AND status = 'active'", [drawRef(runUid)])) {
    try { D.voidMove(user, m.uid, reason || 'Pay run changed'); } catch (e) { /* left for a person */ }
  }
}

// Year to date for a person (final runs paid in the year).
export function yearToDate(userUid, year = dateStr().slice(0, 4), upTo = '9999-12-31') {
  const rows = db().all(`SELECT l.* FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 AND substr(r.pay_date,1,4) = ? AND r.pay_date <= ?`, [userUid, String(year), upTo]);
  const s = (k) => r2(rows.reduce((a, l) => a + l[k], 0));
  return { gross: s('gross'), paye: s('paye'), fnpfEmployee: s('fnpf_employee'), fnpfEmployer: s('fnpf_employer'), net: s('net'), weeks: rows.length };
}

// Notes and coins needed to pay cash wages (each person's pay made up exactly).
export function cashBreakdown(amounts) {
  const D = [100, 50, 20, 10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05];
  const total = {};
  D.forEach((d) => { total[d] = 0; });
  amounts.forEach((a) => {
    let left = Math.round(r2(a) * 100);
    left = Math.round(left / 5) * 5;
    D.forEach((d) => { const c = Math.round(d * 100); const n = Math.floor(left / c); total[d] += n; left -= n * c; });
  });
  return D.map((d) => ({ value: d, label: d >= 1 ? `$${d}` : `${Math.round(d * 100)}c`, count: total[d] })).filter((x) => x.count);
}

export function payrollAlerts() {
  const draft = db().get("SELECT COUNT(*) AS n FROM pay_runs WHERE status = 'draft'").n;
  const ws = previousPeriod(dateStr()).from;
  const lastWeekDone = !!db().get("SELECT 1 AS x FROM pay_runs WHERE week_start = ? AND status = 'final'", [ws]);
  return { draft, lastWeek: ws, lastWeekDone, confirmed: payRules().confirmed };
}
