// Pay sign-off (v3.5): after a pay run is final each person sees their full, exact payslip on a locked screen and
// signs it ("Sign") or says "Something is wrong". Not signed = not released (the owner or admin can release it
// anyway; that is recorded). After signing the payslip is sent: email (if the person has an address, through the
// cloud outbox) and / or a one-tap Viber share; printing is optional. Payroll setting: automatic / ask / don't send.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { enqueue } from '../../services/stock.js';
import { ROLES, can, actsAsOwner, needReason, requireSetup } from '../../services/access.js';
import * as P from './service.js';
import { payslipText } from './payslip.js';
import { requirePerm, asService } from '../../services/guard.js';

const { $ } = P;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

export const SEND_MODES = { auto: 'Send by itself after signing', ask: 'Ask each time', off: "Don't send" };
export const SIGNOFF_DEFAULTS = {
  roles: ['owner', 'admin', 'payroll', 'manager'], // who may open the pay sign-off (hand the tablet to staff)
  sendMode: 'ask',
  email: true,          // email the payslip PDF when the person has an email address
  viber: true,          // offer the one-tap Viber share (shown first)
  print: true,          // offer printing (never required)
  mustSign: true,       // not signed = not released
};
export function signoffRules() { return { ...SIGNOFF_DEFAULTS, ...(getShared('pay_signoff_rules', {}) || {}) }; }
export function saveSignoffRules(user, r) {
  requirePerm(user, 'payroll_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'payroll_setup');
  need(isTop(user), 'Only the owner or admin can change the pay sign-off settings.');
  const clean = {
    roles: Array.from(new Set((r.roles || []).filter((x) => ROLES.includes(x)).concat(['owner', 'admin']))),
    sendMode: SEND_MODES[r.sendMode] ? r.sendMode : 'ask', email: r.email !== false, viber: r.viber !== false, print: r.print !== false, mustSign: r.mustSign !== false,
  };
  const before = signoffRules();
  setShared('pay_signoff_rules', clean);
  audit({ user, action: 'Changed the pay sign-off settings', table: 'shared_settings', recordUid: 'pay_signoff_rules', before, after: clean });
  return clean;
  });
}
// May this person run the pay sign-off (Home tile, Payroll › Pay sign-off)?
export function canRunSignoff(user) {
  if (!user) return false;
  if (isTop(user)) return true;
  return signoffRules().roles.includes(user.role);
}

const statusUid = (runUid, userUid) => `${runUid}|${userUid}`;
function statusRow(runUid, userUid) { return db().get('SELECT * FROM pay_slip_status WHERE uid = ?', [statusUid(runUid, userUid)]); }
function upsertStatus(runUid, userUid, name, set) {
  const now = stamp();
  const cur = statusRow(runUid, userUid);
  if (!cur) {
    db().run(`INSERT INTO pay_slip_status (uid, run_uid, user_uid, name, version, released, updated_at, updated_device) VALUES (?,?,?,?,?,0,?,?)`, [statusUid(runUid, userUid), runUid, userUid, name || null, set.version || 1, now, deviceId()]);
  }
  const keys = Object.keys(set);
  if (keys.length) db().run(`UPDATE pay_slip_status SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, keys.map((k) => set[k]).concat([now, deviceId(), statusUid(runUid, userUid)]));
  return statusRow(runUid, userUid);
}

// Called when a run is made final (also after a correction): everyone in it gets a payslip to sign.
export function issuePayslips(run) {
  const r = typeof run === 'string' ? P.getRun(run) : run;
  if (!r || r.status !== 'final') return;
  for (const l of r.lines.filter((x) => x.include)) {
    const cur = statusRow(r.uid, l.user_uid);
    if (!cur || (cur.version || 1) !== (r.version || 1)) upsertStatus(r.uid, l.user_uid, l.name, { version: r.version || 1, released: 0, released_at: null, released_by_name: null, override_reason: null, emailed_at: null, viber_at: null, printed_at: null });
  }
}
// A final run was reopened: the old signatures no longer count (they stay in the history as "replaced").
export function payslipsReopened(user, run) {
  requirePerm(user, 'payroll_run', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (has('pay_signoffs')) db().run(`UPDATE pay_signoffs SET status = 'replaced', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE run_uid = ? AND status IN ('signed','query')`, [stamp(), deviceId(), run.uid]);
  db().run(`UPDATE pay_slip_status SET released = 0, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE run_uid = ?`, [stamp(), deviceId(), run.uid]);
  });
}

// Where one person's payslip stands: to_sign | signed | query | released (override) – and whether pay is released.
export function slipState(runUid, userUid) {
  const so = has('pay_signoffs') ? db().get("SELECT * FROM pay_signoffs WHERE run_uid = ? AND user_uid = ? AND status <> 'replaced'", [runUid, userUid]) : null;
  const st = statusRow(runUid, userUid);
  const signed = !!(so && so.status === 'signed');
  const released = signed || !!(st && st.released) || !signoffRules().mustSign;
  const state = signed ? 'signed' : so && so.status === 'query' ? 'query' : released ? 'released' : 'to_sign';
  return { state, released, signed, signoff: so || null, status: st || null, override: !!(st && st.released && !signed) };
}
export const SLIP_STATE = { to_sign: 'Not signed – pay not released', signed: 'Signed – released', query: 'Something is wrong – waiting for the manager', released: 'Released by the owner / admin without signature' };

// Everyone in a final run with their state.
export function runSlips(runUid) {
  const r = P.getRun(runUid);
  if (!r) return [];
  return r.lines.filter((l) => l.include).map((l) => ({ line: l, ...slipState(runUid, l.user_uid) }));
}
// Final runs that still have payslips waiting (newest first), for the Home tile and the daily task.
export function runsToSign({ days = 120 } = {}) {
  const since = addDays(dateStr(), -days);
  return db().all("SELECT uid FROM pay_runs WHERE status = 'final' AND pay_date >= ? ORDER BY pay_date DESC", [since]).map((x) => {
    const r = P.getRun(x.uid);
    const slips = runSlips(x.uid);
    return { run: r, total: slips.length, waiting: slips.filter((s) => !s.released).length, queries: slips.filter((s) => s.state === 'query').length, signed: slips.filter((s) => s.signed).length };
  }).filter((x) => x.total);
}
export function signoffSummary() {
  const list = runsToSign();
  return { waiting: list.reduce((s, x) => s + x.waiting, 0), queries: list.reduce((s, x) => s + x.queries, 0), runs: list.filter((x) => x.waiting).length };
}

// The person signs their payslip (or says something is wrong). Signing releases their pay.
export function signPayslip(byUser, { runUid, userUid, signature, status = 'signed', note, witness }) {
  const { signPay } = require('../people/service.js');
  // A replaced signature (before a correction) must not block a new one.
  if (has('pay_signoffs')) {
    const old = db().get("SELECT * FROM pay_signoffs WHERE run_uid = ? AND user_uid = ? AND status = 'replaced'", [runUid, userUid]);
    if (old) audit({ user: byUser, action: `Earlier signature of ${old.name} replaced by the corrected payslip`, table: 'pay_signoffs', recordUid: old.uid });
  }
  signPay(byUser, { runUid, userUid, signature, status, note, witness });
  const l = db().get('SELECT name FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]) || {};
  const run = P.getRun(runUid);
  if (status === 'signed') { upsertStatus(runUid, userUid, l.name, { version: run.version || 1, released: 1, released_at: stamp(), released_by_name: `${l.name} (signed)`, override_reason: null }); keepPayslipCopy(runUid, userUid); }
  return { ...slipState(runUid, userUid), delivery: deliveryFor(runUid, userUid) };
}
// 1.0.0 (owner, 2 Nov): once a payslip is released, a PDF copy goes to Drive › Easy Buys › Records › month › Payslips.
function keepPayslipCopy(runUid, userUid) {
  try { const l = db().get('SELECT uid FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]); if (l) enqueue('payslip_drive', { lineUid: l.uid }); } catch (e) { /* never stops the pay */ }
}
// Owner / admin release pay without a signature (recorded).
export function releaseWithoutSignature(user, { runUid, userUid, reason }) {
  need(isTop(user), 'Only the owner or admin can release pay that is not signed.');
  needReason(user, reason, 'Write why the pay is released without a signature.');
  const l = db().get('SELECT * FROM pay_lines WHERE run_uid = ? AND user_uid = ? AND include = 1', [runUid, userUid]);
  need(l, 'This person is not in the pay run.');
  const run = P.getRun(runUid);
  need(run && run.status === 'final', 'The pay run is not final.');
  upsertStatus(runUid, userUid, l.name, { version: run.version || 1, released: 1, released_at: stamp(), released_by_name: user.name, override_reason: txt(reason) });
  keepPayslipCopy(runUid, userUid);
  audit({ user, action: `Released pay of ${l.name} ${$(l.net)} without a signature (pay day ${run.pay_date})`, table: 'pay_slip_status', recordUid: statusUid(runUid, userUid), reason: txt(reason) || null });
  return slipState(runUid, userUid);
}

// ---------------------------------------------------------------- sending the payslip
export function payslipEmail(userUid) {
  const p = P.getProfile(userUid) || {};
  if (txt(p.email)) return txt(p.email);
  try { const o = db().get("SELECT email FROM onboarding WHERE user_uid = ? AND email IS NOT NULL AND email <> '' ORDER BY rowid DESC LIMIT 1", [userUid]); if (o) return txt(o.email); } catch (e) { /* no onboarding */ }
  return '';
}
// What happens after signing: { mode, email, viber, print, autoEmail }.
export function deliveryFor(runUid, userUid) {
  const r = signoffRules();
  const email = r.email ? payslipEmail(userUid) : '';
  const p = P.getProfile(userUid) || {};
  return { mode: r.sendMode, email: email || null, viber: r.viber && r.sendMode !== 'off', viberPhone: txt(p.viber) || null, print: !!r.print, autoEmail: r.sendMode === 'auto' && !!email };
}
export function sendPayslipEmail(user, runUid, userUid) {
  const to = payslipEmail(userUid);
  need(to, 'This person has no email address. Add it in Payroll › Pay details.');
  const st = slipState(runUid, userUid);
  need(st.released, 'The payslip is sent once it is signed (or released by the owner or admin).');
  const l = db().get('SELECT * FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]);
  const run = P.getRun(runUid);
  enqueue('payslip_email', { lineUid: l.uid, to, subject: `Easy Buys payslip – ${l.name} – paid ${run.pay_date}${(run.version || 1) > 1 ? ' (corrected)' : ''}`, text: `Hello ${String(l.name).split(' ')[0]},\n\nYour payslip for ${run.week_start} to ${run.week_end} (paid ${run.pay_date}) is attached.\nNet pay: ${$(l.net)}.\n\nEasy Buys Shopping Centre` });
  upsertStatus(runUid, userUid, l.name, { emailed_to: to, emailed_at: stamp() });
  audit({ user, action: `Payslip of ${l.name} (${run.pay_date}) sent by email to ${to}`, table: 'pay_slip_status', recordUid: statusUid(runUid, userUid) });
  return to;
}
// After signing: send by itself when the setting is "automatic" (email); Viber always needs one tap on the device.
export function afterSigned(user, runUid, userUid) {
  const d = deliveryFor(runUid, userUid);
  let emailed = null;
  if (d.autoEmail) { try { emailed = sendPayslipEmail(user, runUid, userUid); } catch (e) { emailed = null; } }
  return { ...d, emailed };
}
export function markViberShared(user, runUid, userUid) {
  const l = db().get('SELECT name FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]) || {};
  upsertStatus(runUid, userUid, l.name, { viber_at: stamp() });
  audit({ user, action: `Payslip of ${l.name} shared on Viber`, table: 'pay_slip_status', recordUid: statusUid(runUid, userUid) });
}
export function markPrinted(user, runUid, userUid) {
  const l = db().get('SELECT name FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]) || {};
  upsertStatus(runUid, userUid, l.name, { printed_at: stamp() });
}
// The Viber message (full payslip text) and the viber:// link to open it with one tap.
export function viberShare(runUid, userUid) {
  const l = db().get('SELECT uid FROM pay_lines WHERE run_uid = ? AND user_uid = ?', [runUid, userUid]);
  const text = l ? payslipText(l.uid) : '';
  return { text, url: `viber://forward?text=${encodeURIComponent(text)}` };
}

// Warnings for Home: payslips waiting to be signed, and "something is wrong" answers to give.
export function signoffAlerts(user) {
  if (!canRunSignoff(user) && !can(user, 'payroll_run')) return [];
  const s = signoffSummary();
  const out = [];
  if (s.queries) out.push({ id: 'pay-sign-query', level: 'warning', text: `${s.queries} payslip${s.queries === 1 ? '' : 's'}: "Something is wrong"`, sub: 'Look at it and answer the person.', nav: { screen: 'PaySignOff', params: {} } });
  if (s.waiting) out.push({ id: 'pay-sign-wait', level: 'info', text: `${s.waiting} payslip${s.waiting === 1 ? '' : 's'} not signed yet – pay not released`, nav: { screen: 'PaySignOff', params: {} } });
  return out;
}
