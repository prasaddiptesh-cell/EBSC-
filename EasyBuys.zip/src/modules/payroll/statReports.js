// FNPF monthly schedule, year-end PAYE reconciliation and employee certificates.
import { stamp } from '../../services/core.js';
import * as S from './statutory.js';

const { $ } = S;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';

export function fnpfScheduleReport(ym) {
  const f = S.monthFigures(ym);
  return { kind: 'fnpf', title: `FNPF Schedule ${ym}`, fileName: `FNPF-schedule-${ym}`, subtitle: 'Easy Buys Shopping Centre', info: [['Month', ym], ['Generated', stamp()]],
    summary: [{ label: 'Members', value: String(f.people.filter((p) => p.fnpf > 0).length) }, { label: 'Employee share', value: $(f.fnpfEmployee) }, { label: 'Employer share', value: $(f.fnpfEmployer) }, { label: 'Total to pay', value: $(f.fnpf) }],
    sections: [{ title: 'Members', columns: [col('fnpfNo', 'FNPF no.'), col('name', 'Name'), col('employeeNo', 'Emp no.'), col('base', 'Wages (FNPF)', R), col('fe', 'Employee', R), col('fr', 'Employer', R), col('t', 'Total', R)],
      rows: f.people.filter((p) => p.fnpf > 0).map((p) => ({ ...p, base: $(p.base), fe: $(p.fnpfEmployee), fr: $(p.fnpfEmployer), t: $(p.fnpf), _tone: p.fnpfNo ? null : 'warn' })),
      note: f.missingFnpfNo ? `${f.missingFnpfNo} person(s) have no FNPF number – add it in Payroll › Pay details.` : '' }] };
}
export function yearEndReport(year) {
  const y = S.yearEnd(year);
  return { kind: 'ye', title: `PAYE Year-end ${year}`, fileName: `PAYE-year-end-${year}`, subtitle: 'Easy Buys Shopping Centre – employer year-end reconciliation', info: [['Year', `${year} (Jan–Dec)`], ['Generated', stamp()]],
    summary: [{ label: 'Gross', value: $(y.gross) }, { label: 'PAYE taken', value: $(y.paye) }, { label: 'PAYE paid', value: $(y.payePaid) }, { label: 'Difference', value: $(y.payeDiff), tone: Math.abs(y.payeDiff) > 0.004 ? 'bad' : undefined }],
    sections: [{ title: 'Employees', columns: [col('name', 'Name'), col('employee_no', 'Emp no.'), col('tin', 'TIN'), col('fnpfNo', 'FNPF no.'), col('gross', 'Gross', R), col('paye', 'PAYE', R), col('fe', 'FNPF employee', R), col('fr', 'FNPF employer', R), col('weeks', 'Weeks', R)],
      rows: y.people.map((p) => ({ ...p, gross: $(p.gross), paye: $(p.paye), fe: $(p.fnpfEmployee), fr: $(p.fnpfEmployer), _tone: p.tin ? null : 'warn' })) }] };
}
export function certificateReport(year) {
  const y = S.yearEnd(year);
  return { kind: 'cert', title: `Pay & tax certificates ${year}`, fileName: `Certificates-${year}`, subtitle: 'Easy Buys Shopping Centre', info: [['Year', `${year} (Jan–Dec)`], ['Generated', stamp()]],
    sections: y.people.map((p) => ({ title: `${p.name}${p.employee_no ? ` (${p.employee_no})` : ''}`, columns: [col('k', ''), col('v', '', R)],
      rows: [{ k: 'TIN', v: p.tin || '—' }, { k: 'FNPF number', v: p.fnpfNo || '—' }, { k: 'Gross pay for the year', v: $(p.gross) }, { k: 'PAYE / SRT deducted', v: $(p.paye) },
        { k: 'FNPF deducted (employee share)', v: $(p.fnpfEmployee) }, { k: 'FNPF paid by employer', v: $(p.fnpfEmployer) }, { k: 'Net pay', v: $(p.net) }, { k: 'Weeks paid', v: String(p.weeks) }],
      note: 'Signed for Easy Buys: ______________________   Date: ____________' })) };
}
export const STAT_REPORTS = [
  { id: 'pay_fnpf_schedule', group: 'Payroll', icon: '🏦', title: 'FNPF monthly schedule', desc: 'Members, wages and contributions for the month (first day of the period)', perm: 'statutory', build(from) { return fnpfScheduleReport(from.slice(0, 7)); } },
  { id: 'pay_year_end', group: 'Payroll', icon: '📅', title: 'PAYE year-end reconciliation', desc: 'Every employee for the year, and tax paid to FRCS', perm: 'statutory', build(from) { return yearEndReport(from.slice(0, 4)); } },
  { id: 'pay_certificates', group: 'Payroll', icon: '📜', title: 'Employee pay & tax certificates', desc: 'One per person for the year', perm: 'statutory', build(from) { return certificateReport(from.slice(0, 4)); } },
];
