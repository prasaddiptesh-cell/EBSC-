// FNPF and PAYE / SRT: what is owed each month (from the final pay runs), when it is due, paying it, and checking the
// payment reached the bank. Also the year-end PAYE reconciliation, pay changes worth checking, and final pay.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { assertOpen } from '../../services/lock.js';
import { payRules, yearToDate, listDebts, getProfile, DEBT_LABEL, $, r2 } from './service.js';
import { balances as leaveBalances } from '../leave/service.js';
import { needReason, requireSetup } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';
// The screens and reports use S.$ for money, so pass it on.
export { $ };

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });

export const STAT_SQL = `
CREATE TABLE IF NOT EXISTS stat_payments (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  period TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  due_date TEXT,
  paid_date TEXT,
  paid_amount REAL,
  method TEXT,
  account_uid TEXT,
  reference TEXT,
  receipt_no TEXT,
  schedule_sent TEXT,
  photo_urls TEXT,
  by_name TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const STAT_SYNC = {
  stat_payments: SYNC('uid', 'Payroll', ['uid', 'kind', 'period', 'amount', 'due_date', 'paid_date', 'paid_amount', 'method', 'account_uid', 'reference', 'receipt_no', 'schedule_sent', 'photo_urls', 'by_name', 'notes', 'status', 'void_reason']),
};

// Due dates: day of the following month (0 = last day). Editable in Payroll › Rules because they can change.
export const STAT_DEFAULTS = { fnpfDueDay: 0, payeDueDay: 0, payChangePct: 25 };
export function statRules() { return { ...STAT_DEFAULTS, ...(getShared('stat_rules', {}) || {}) }; }
export function saveStatRules(user, r) {
  requirePerm(user, 'payroll_setup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'payroll_setup');
  const d = (v) => Math.max(0, Math.min(28, Math.round(Number(v) || 0)));
  const clean = { fnpfDueDay: d(r.fnpfDueDay), payeDueDay: d(r.payeDueDay), payChangePct: Math.max(1, Number(r.payChangePct) || 25) };
  setShared('stat_rules', clean);
  audit({ user, action: 'Changed FNPF / PAYE due days', table: 'shared_settings', recordUid: 'stat_rules', after: clean });
  });
}
function dueFor(ym, day) {
  const y = Number(ym.slice(0, 4)); const m = Number(ym.slice(5, 7));
  const next = m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
  if (day > 0) return `${next}-${String(day).padStart(2, '0')}`;
  const after = Number(next.slice(5, 7)) === 12 ? `${Number(next.slice(0, 4)) + 1}-01-01` : `${next.slice(0, 4)}-${String(Number(next.slice(5, 7)) + 1).padStart(2, '0')}-01`;
  return addDays(after, -1);
}

// What the pay runs paid in a month (by pay date): FNPF (staff 8% + employer 10%) and PAYE / SRT, per person.
export function monthFigures(ym) {
  const rows = db().all(`SELECT l.user_uid, l.name, l.employee_no, SUM(l.gross) AS gross, SUM(l.fnpf_base) AS base, SUM(l.fnpf_employee) AS fe, SUM(l.fnpf_employer) AS fr, SUM(l.paye) AS paye,
    COUNT(*) AS weeks FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND substr(r.pay_date,1,7) = ? GROUP BY l.user_uid ORDER BY l.name`, [ym]);
  const people = rows.map((r) => {
    const p = getProfile(r.user_uid) || {};
    return { userUid: r.user_uid, name: r.name, employeeNo: r.employee_no || '', fnpfNo: p.fnpf_no || '', tin: p.tin || '', gross: r2(r.gross), base: r2(r.base), fnpfEmployee: r2(r.fe), fnpfEmployer: r2(r.fr), fnpf: r2(r.fe + r.fr), paye: r2(r.paye), weeks: r.weeks };
  });
  const t = (k) => r2(people.reduce((s, x) => s + x[k], 0));
  return { ym, people, fnpf: t('fnpf'), fnpfEmployee: t('fnpfEmployee'), fnpfEmployer: t('fnpfEmployer'), paye: t('paye'), gross: t('gross'), missingFnpfNo: people.filter((x) => x.fnpf > 0 && !x.fnpfNo).length, missingTin: people.filter((x) => !x.tin).length };
}
const uidFor = (kind, ym) => `STAT-${kind}-${ym}`;
// Make / refresh the two records for a month (amounts follow the pay runs until paid).
export function prepareMonth(ym) {
  need(/^\d{4}-\d{2}$/.test(ym), 'Choose the month.');
  const f = monthFigures(ym);
  const r = statRules();
  const { now, dev } = meta();
  for (const [kind, amount, day] of [['fnpf', f.fnpf, r.fnpfDueDay], ['paye', f.paye, r.payeDueDay]]) {
    const uid = uidFor(kind, ym);
    const cur = db().get('SELECT * FROM stat_payments WHERE uid = ?', [uid]);
    if (!cur) db().run(`INSERT INTO stat_payments (uid, kind, period, amount, due_date, photo_urls, status, updated_at, updated_device) VALUES (?,?,?,?,?, '[]', 'active', ?,?)`, [uid, kind, ym, amount, dueFor(ym, day), now, dev]);
    else if (!cur.paid_date && (Math.abs(cur.amount - amount) > 0.004 || cur.due_date !== dueFor(ym, day))) {
      db().run(`UPDATE stat_payments SET amount = ?, due_date = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [amount, dueFor(ym, day), now, dev, uid]);
    }
  }
  return listStat({ ym });
}
export function listStat({ ym, kind } = {}) {
  return db().all(`SELECT * FROM stat_payments WHERE status = 'active' AND (? IS NULL OR period = ?) AND (? IS NULL OR kind = ?) ORDER BY period DESC, kind`, [ym || null, ym || null, kind || null, kind || null])
    .map((s) => decorate(s));
}
function decorate(s) {
  const today = dateStr();
  let cleared = null;
  if (s.paid_date && s.method !== 'cash') {
    const be = db().get('SELECT cleared_date FROM bank_entries WHERE uid = ?', [`BE-STAT-${s.uid}`]);
    cleared = be ? be.cleared_date : null;
  }
  const state = !s.amount ? 'nothing' : !s.paid_date ? (s.due_date < today ? 'late' : addDays(today, 7) >= s.due_date ? 'due_soon' : 'to_pay') : s.method === 'cash' ? 'paid' : cleared ? 'verified' : 'paid';
  // Paid already, but a pay run in that month was corrected (or a late pay run added) since: what changed.
  let changedSincePaid = 0;
  if (s.paid_date) { try { const f = monthFigures(s.period); changedSincePaid = r2((s.kind === 'fnpf' ? f.fnpf : f.paye) - s.amount); } catch (e) { changedSincePaid = 0; } }
  return { ...s, photos: J(s.photo_urls, []), cleared, state, short: s.paid_date ? r2(s.amount - (s.paid_amount || 0)) : 0, changedSincePaid: Math.abs(changedSincePaid) > 0.004 ? changedSincePaid : 0 };
}
export const STAT_STATE = { nothing: 'Nothing owed', to_pay: 'To pay', due_soon: 'Due soon', late: 'LATE', paid: 'Paid – waiting for the bank', verified: 'Paid and seen in the bank' };
// Every month that has final pay runs, newest first (prepared on the fly).
export function statOverview({ months = 12 } = {}) {
  const yms = db().all("SELECT DISTINCT substr(pay_date,1,7) AS ym FROM pay_runs WHERE status = 'final' ORDER BY ym DESC LIMIT ?", [months]).map((r) => r.ym);
  yms.forEach(prepareMonth);
  return yms.map((ym) => ({ ym, items: listStat({ ym }) }));
}
// Step 1: record the payment. Step 2 happens when it shows in the bank (bank reconciliation / To verify).
export function payStat(user, uid, { date, amount, method = 'transfer', accountUid, reference, receiptNo, scheduleSent, photos = [], notes, chequeInRegister = false }) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const s = db().get('SELECT * FROM stat_payments WHERE uid = ?', [uid]);
  need(s && s.status === 'active', 'Not found.');
  need(!s.paid_date, 'Already recorded as paid.');
  const d = txt(date) || dateStr();
  assertOpen(d, 'This payment');
  const amt = r2(amount === undefined || amount === '' ? s.amount : amount);
  need(amt > 0, 'Enter the amount paid.');
  need(['transfer', 'cheque', 'cash'].includes(method), 'Choose how it was paid.');
  if (method !== 'cash') need(accountUid, 'Choose the bank account it was paid from.');
  need(txt(reference) || txt(receiptNo), 'Enter the bank reference or the FRCS / FNPF receipt number.');
  const { now, dev } = meta();
  db().run(`UPDATE stat_payments SET paid_date = ?, paid_amount = ?, method = ?, account_uid = ?, reference = ?, receipt_no = ?, schedule_sent = ?, by_name = ?, notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [d, amt, method, method === 'cash' ? null : accountUid, txt(reference) || null, txt(receiptNo) || null, txt(scheduleSent) || null, user.name, txt(notes) || null, now, dev, uid]);
  // A cheque already in the cheque register shows in the bank from there (no second bank line).
  if (method !== 'cash' && !chequeInRegister) {
    db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'transfer_out',?,?,?,?,?,?)
      ON CONFLICT(uid) DO UPDATE SET status = 'active', account_uid = excluded.account_uid, entry_date = excluded.entry_date, amount = excluded.amount, reference = excluded.reference, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [`BE-STAT-${uid}`, accountUid, d, amt, txt(reference) || txt(receiptNo), `${s.kind === 'fnpf' ? 'FNPF' : 'PAYE / SRT'} for ${s.period}`, user.name, now, dev]);
  }
  if (photos.length) addPhotos('stat', uid, photos);
  audit({ user, action: `${s.kind === 'fnpf' ? 'FNPF' : 'PAYE / SRT'} for ${s.period} paid ${$(amt)} by ${method}`, table: 'stat_payments', recordUid: uid });
  });
}
export function undoStatPayment(user, uid, reason) {
  requirePerm(user, 'statutory', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const s = db().get('SELECT * FROM stat_payments WHERE uid = ?', [uid]);
  need(s && s.paid_date, 'Not paid yet.');
  needReason(user, reason, 'Say why.');
  assertOpen(s.paid_date, 'This payment');
  const { now, dev } = meta();
  db().run(`UPDATE stat_payments SET paid_date = NULL, paid_amount = NULL, method = NULL, reference = NULL, receipt_no = NULL, notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`Payment undone: ${txt(reason)}`, now, dev, uid]);
  db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, `BE-STAT-${uid}`]);
  audit({ user, action: `Undid ${s.kind} payment for ${s.period}`, table: 'stat_payments', recordUid: uid, reason: txt(reason) });
  });
}
export function statAlerts() {
  try { statOverview({ months: 3 }); } catch (e) { /* pay runs missing */ }
  const list = listStat().filter((s) => ['late', 'due_soon'].includes(s.state));
  return { late: list.filter((s) => s.state === 'late'), dueSoon: list.filter((s) => s.state === 'due_soon') };
}

// ---------------------------------------------------------------- year end
// Per person for the year: gross, PAYE, FNPF – the employer's year-end PAYE reconciliation and each person's certificate.
export function yearEnd(year) {
  const people = db().all(`SELECT DISTINCT l.user_uid, l.name, l.employee_no FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE substr(r.pay_date,1,4) = ? ORDER BY l.name`, [String(year)])
    .map((p) => { const y = yearToDate(p.user_uid, String(year)); const pr = getProfile(p.user_uid) || {}; return { ...p, tin: pr.tin || '', fnpfNo: pr.fnpf_no || '', ...y }; });
  const paid = db().all("SELECT kind, SUM(paid_amount) AS t FROM stat_payments WHERE status = 'active' AND paid_date IS NOT NULL AND substr(period,1,4) = ? GROUP BY kind", [String(year)]);
  const paidOf = (k) => r2((paid.find((x) => x.kind === k) || {}).t || 0);
  const t = (k) => r2(people.reduce((s, x) => s + x[k], 0));
  return { year: String(year), people, gross: t('gross'), paye: t('paye'), fnpfEmployee: t('fnpfEmployee'), fnpfEmployer: t('fnpfEmployer'),
    payePaid: paidOf('paye'), fnpfPaid: paidOf('fnpf'), payeDiff: r2(t('paye') - paidOf('paye')), fnpfDiff: r2(t('fnpfEmployee') + t('fnpfEmployer') - paidOf('fnpf')) };
}

// ---------------------------------------------------------------- pay changes worth a look before finalising
export function payChanges(runUid) {
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [runUid]);
  if (!run) return [];
  const pct = statRules().payChangePct;
  const prev = db().get("SELECT uid FROM pay_runs WHERE status = 'final' AND week_start < ? ORDER BY week_start DESC LIMIT 1", [run.week_start]);
  const before = prev ? Object.fromEntries(db().all('SELECT user_uid, net, pay_method FROM pay_lines WHERE run_uid = ? AND include = 1', [prev.uid]).map((l) => [l.user_uid, l])) : {};
  const out = [];
  for (const l of db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1', [runUid])) {
    const b = before[l.user_uid];
    if (!b) { if (prev) out.push({ name: l.name, why: 'New this week (not paid last week)' }); continue; }
    if (b.net > 0 && Math.abs(l.net - b.net) / b.net * 100 > pct) out.push({ name: l.name, why: `Net pay ${$(b.net)} → ${$(l.net)} (${l.net > b.net ? '+' : ''}${Math.round(((l.net - b.net) / b.net) * 100)}%)` });
    if (b.pay_method !== l.pay_method) out.push({ name: l.name, why: `Paid by ${l.pay_method} this week, ${b.pay_method} last week` });
  }
  return out;
}

// ---------------------------------------------------------------- final pay (someone leaving)
// What is still owed to / by a person who is leaving: leave not taken (paid out), advances and loans still owing.
export function finalPaySummary(userUid, { lastDay = dateStr() } = {}) {
  const p = getProfile(userUid);
  need(p, 'This person has no pay details.');
  const rules = payRules();
  // Annual leave not taken is paid out; sick leave is not.
  const leave = leaveBalances(userUid, Number(lastDay.slice(0, 4))).filter((b) => b.paid && b.limited && b.left > 0 && (b.type === 'annual' || /annual/i.test(b.name)));
  const hoursDay = rules.leaveHoursPerDay || 8;
  const dayRate = p.pay_type === 'salary' ? r2(p.weekly_salary / 6) : r2(p.rate * hoursDay);
  const leavePay = leave.map((b) => ({ type: b.name || b.type, days: b.left, amount: r2(b.left * dayRate) }));
  const debts = listDebts({ userUid, open: true }).map((d) => ({ label: DEBT_LABEL[d.kind] || d.kind || 'Owing', date: d.debt_date, owing: d.balance }));
  return { dayRate, leavePay, leaveTotal: r2(leavePay.reduce((s, x) => s + x.amount, 0)), debts, debtTotal: r2(debts.reduce((s, x) => s + x.owing, 0)), lastDay };
}
