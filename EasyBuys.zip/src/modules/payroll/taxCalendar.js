// Tax & statutory calendar (v3.5): VAT, FNPF, PAYE, pay day reports, provisional tax, advance tax and company tax.
// The admin sets each one's due rule, the reminder lead and the responsible person. Every period needs two proofs:
// the lodgement (return / schedule filed) and the payment – each with a photo or document as proof.
// Flags: lodged but not paid (red), paid but not lodged (red), proof missing (amber), overdue (urgent).
// The month-end checklist waits until both proofs are in (the owner or admin can override; recorded).
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { can, actsAsOwner, needReason } from '../../services/access.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const isTop = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const pad = (n) => String(n).padStart(2, '0');
const ymAdd = (ym, n) => { const t = Number(ym.slice(0, 4)) * 12 + Number(ym.slice(5, 7)) - 1 + n; return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}`; };
const monthEnd = (ym) => addDays(`${ymAdd(ym, 1)}-01`, -1);

// What each obligation is. freq: monthly (period yyyy-mm, due in the next month) | payday (one per pay run) |
// instalments (company advance tax) | yearly (period = tax year). lodge / pay: which proofs it needs.
export const TAX_ITEMS = {
  vat: { label: 'VAT return', short: 'VAT', freq: 'monthly', lodge: true, pay: true, perm: 'accounts_view', to: 'FRCS' },
  fnpf: { label: 'FNPF contributions', short: 'FNPF', freq: 'monthly', lodge: true, pay: true, perm: 'statutory', to: 'FNPF' },
  paye: { label: 'PAYE / SRT (employer monthly)', short: 'PAYE', freq: 'monthly', lodge: true, pay: true, perm: 'statutory', to: 'FRCS' },
  payday: { label: 'Pay day report (PAYE)', short: 'Pay day report', freq: 'payday', lodge: true, pay: false, perm: 'statutory', to: 'FRCS' },
  prov: { label: 'Provisional tax (withheld from contractors)', short: 'Provisional tax', freq: 'monthly', lodge: true, pay: true, perm: 'accounts_view', to: 'FRCS' },
  advance: { label: 'Company advance tax instalment', short: 'Advance tax', freq: 'instalments', lodge: false, pay: true, perm: 'accounts_view', to: 'FRCS' },
  company: { label: 'Company income tax return', short: 'Company tax', freq: 'yearly', lodge: true, pay: true, perm: 'accounts_view', to: 'FRCS' },
};
export const TAX_KIND_ORDER = ['vat', 'fnpf', 'paye', 'payday', 'prov', 'advance', 'company'];
// Due rules (admin). dueDay: day of the following month (0 = last day). afterDays: days after pay day.
// company: due on dueMonth/dueDay of the year after the tax year ends. lead: days before the due date to start reminding.
export const TAX_RULE_DEFAULTS = {
  vat: { on: true, dueDay: 0, lead: 10, responsibleUid: '', lodge: true, pay: true },
  fnpf: { on: true, dueDay: 0, lead: 7, responsibleUid: '', lodge: true, pay: true },
  paye: { on: true, dueDay: 0, lead: 7, responsibleUid: '', lodge: true, pay: true },
  payday: { on: true, afterDays: 7, lead: 2, responsibleUid: '', lodge: true, pay: false },
  prov: { on: true, dueDay: 0, lead: 10, responsibleUid: '', lodge: true, pay: true },
  advance: { on: true, lead: 14, responsibleUid: '', lodge: false, pay: true },
  company: { on: true, dueMonth: 3, dueDay: 31, lead: 30, responsibleUid: '', lodge: true, pay: true },
  startYm: '',      // track from this month ('' = the last 3 months)
};
export const TAX_HINT = 'Due dates and what must be filed can change. Check them with your accountant, FRCS and FNPF.';

export function taxRules() {
  const saved = getShared('tax_calendar_rules', {}) || {};
  const out = { startYm: saved.startYm || '' };
  let stat = {};
  try { stat = getShared('stat_rules', {}) || {}; } catch (e) { stat = {}; }
  for (const k of TAX_KIND_ORDER) {
    out[k] = { ...TAX_RULE_DEFAULTS[k], ...(k === 'fnpf' && stat.fnpfDueDay !== undefined ? { dueDay: stat.fnpfDueDay } : {}), ...(k === 'paye' && stat.payeDueDay !== undefined ? { dueDay: stat.payeDueDay } : {}), ...(saved[k] || {}) };
  }
  return out;
}
export function saveTaxRules(user, r) {
  need(isTop(user), 'Only the owner or admin can change the tax calendar.');
  const n = (v, lo, hi, label) => { const x = Math.round(Number(v)); need(Number.isFinite(x) && x >= lo && x <= hi, `${label} must be ${lo} to ${hi}.`); return x; };
  const clean = { startYm: txt(r.startYm) };
  need(!clean.startYm || /^\d{4}-\d{2}$/.test(clean.startYm), 'Start month: choose a month.');
  for (const k of TAX_KIND_ORDER) {
    const x = { ...TAX_RULE_DEFAULTS[k], ...((r && r[k]) || {}) };
    const c = { on: x.on !== false, lead: n(x.lead, 0, 120, `${TAX_ITEMS[k].short}: reminder days`), responsibleUid: txt(x.responsibleUid), lodge: x.lodge !== false, pay: x.pay !== false };
    if (k === 'payday') c.afterDays = n(x.afterDays, 0, 60, 'Pay day report: days after pay day');
    else if (k === 'company') { c.dueMonth = n(x.dueMonth, 1, 12, 'Company tax: due month'); c.dueDay = n(x.dueDay, 1, 31, 'Company tax: due day'); } else if (k !== 'advance') c.dueDay = n(x.dueDay, 0, 28, `${TAX_ITEMS[k].short}: due day`);
    need(c.lodge || c.pay, `${TAX_ITEMS[k].short}: it needs a lodgement, a payment or both.`);
    clean[k] = c;
  }
  const before = taxRules();
  setShared('tax_calendar_rules', clean);
  // FNPF / PAYE due days are shared with Payroll › FNPF & PAYE payments.
  try { setShared('stat_rules', { ...(getShared('stat_rules', {}) || {}), fnpfDueDay: clean.fnpf.dueDay, payeDueDay: clean.paye.dueDay }); } catch (e) { /* ignore */ }
  audit({ user, action: 'Changed the tax & statutory calendar (due rules, reminders, responsible people)', table: 'shared_settings', recordUid: 'tax_calendar_rules', before, after: clean });
  return clean;
}

function dueMonthly(ym, day) {
  const next = ymAdd(ym, 1);
  if (day > 0) return `${next}-${pad(Math.min(day, Number(monthEnd(next).slice(8, 10))))}`;
  return monthEnd(next);
}
const A = () => require('../accounting/service.js');
const F = () => require('../accounting/full.js');

// Every period to show for one obligation: [{ period, due, amount, label }].
function periodsFor(kind, rule, { today, fromYm }) {
  const lastYm = ymAdd(today.slice(0, 7), -1);
  const months = [];
  for (let m = fromYm; m <= lastYm; m = ymAdd(m, 1)) months.push(m);
  const out = [];
  if (kind === 'vat') {
    for (const ym of months) {
      let amount = null;
      try { amount = A().vatReturn({ ym }).net; } catch (e) { amount = null; }
      out.push({ period: ym, due: dueMonthly(ym, rule.dueDay), amount });
    }
  } else if (kind === 'fnpf' || kind === 'paye') {
    if (has('pay_runs')) {
      const { monthFigures } = require('./statutory.js');
      for (const ym of months) {
        const f = monthFigures(ym);
        if (!f.people.length) continue;
        out.push({ period: ym, due: dueMonthly(ym, rule.dueDay), amount: kind === 'fnpf' ? f.fnpf : f.paye });
      }
    }
  } else if (kind === 'payday') {
    if (has('pay_runs')) {
      db().all("SELECT pay_date, SUM(json_extract(totals,'$.paye')) AS paye, COUNT(*) AS n FROM pay_runs WHERE status = 'final' AND pay_date >= ? AND pay_date <= ? GROUP BY pay_date ORDER BY pay_date", [`${fromYm}-01`, today])
        .forEach((r) => out.push({ period: r.pay_date, due: addDays(r.pay_date, rule.afterDays || 0), amount: r2(r.paye) }));
    }
  } else if (kind === 'prov') {
    try {
      F().provTaxMonths().filter((p) => p.ym >= fromYm && p.ym <= lastYm).forEach((p) => out.push({ period: p.ym, due: dueMonthly(p.ym, rule.dueDay), amount: p.withheld, paidAuto: p.owing <= 0.004 && p.paid > 0 ? { date: p.paidOn, amount: p.paid } : null }));
    } catch (e) { /* accounting not there */ }
  } else if (kind === 'advance') {
    try {
      const y = Number(today.slice(0, 4));
      [y - 1, y].forEach((yy) => F().advanceTaxPlan(yy, today).filter((i) => i.state !== 'before' && i.due.slice(0, 7) >= fromYm)
        .forEach((i) => out.push({ period: `${yy}-${i.n}`, label: `${yy} instalment ${i.n}`, due: i.due, amount: i.amount, paidAuto: i.paid >= i.amount - 0.004 && i.paid > 0 ? { amount: i.paid } : null })));
    } catch (e) { /* accounting not there */ }
  } else if (kind === 'company') {
    let endM = 12;
    try { endM = F().acctSettings().taxYearEndMonth || 12; } catch (e) { endM = 12; }
    const y = Number(today.slice(0, 4));
    for (const yy of [y - 2, y - 1]) {
      const yearEnd = monthEnd(`${yy}-${pad(endM)}`);
      if (yearEnd.slice(0, 7) < fromYm) continue;
      const dueY = Number(yearEnd.slice(0, 4)) + (rule.dueMonth <= endM ? 1 : 0);
      const dm = `${dueY}-${pad(rule.dueMonth)}`;
      out.push({ period: String(yy), label: `Tax year to ${yearEnd}`, due: `${dm}-${pad(Math.min(rule.dueDay, Number(monthEnd(dm).slice(8, 10))))}`, amount: null });
    }
  }
  return out;
}
// Payments already recorded elsewhere in the app (FNPF / PAYE payments, tax payments in Accounting).
function paymentElsewhere(kind, period) {
  try {
    if ((kind === 'fnpf' || kind === 'paye') && has('stat_payments')) {
      const s = db().get("SELECT * FROM stat_payments WHERE uid = ? AND status = 'active' AND paid_date IS NOT NULL", [`STAT-${kind}-${period}`]);
      if (s) return { date: s.paid_date, amount: s.paid_amount, ref: s.reference || s.receipt_no || '', photos: J(s.photo_urls, []).length, where: 'Payroll › FNPF & PAYE payments' };
    }
    if (['vat', 'prov', 'company'].includes(kind) && has('gl_journals')) {
      const j = db().all("SELECT jdate, meta FROM gl_journals WHERE status = 'active' AND kind = 'tax_payment'").map((x) => ({ ...J(x.meta, {}), date: x.jdate }))
        .filter((m) => m.tax === kind && (kind === 'company' ? String(m.year) === String(period) : m.ym === period));
      if (j.length) return { date: j[j.length - 1].date, amount: r2(j.reduce((s, x) => s + Number(x.amount || 0), 0)), ref: j[j.length - 1].reference || '', photos: 0, where: 'Accounting › Tax centre' };
    }
  } catch (e) { /* ignore */ }
  return null;
}

const proofUid = (kind, period) => `${kind}|${period}`;
function proofRow(kind, period) { return db().get('SELECT * FROM tax_proofs WHERE uid = ?', [proofUid(kind, period)]); }
function ensureRow(kind, period, due, amount) {
  const cur = proofRow(kind, period);
  if (cur) return cur;
  const now = stamp();
  db().run(`INSERT INTO tax_proofs (uid, kind, period, due_date, amount, lodge_photos, pay_photos, updated_at, updated_device) VALUES (?,?,?,?,?, '[]', '[]', ?,?)`, [proofUid(kind, period), kind, period, due || null, amount === null || amount === undefined ? null : r2(amount), now, deviceId()]);
  return proofRow(kind, period);
}

export const TAX_FLAG = { overdue: 'Overdue', lodged_not_paid: 'Lodged but not paid', paid_not_lodged: 'Paid but not lodged', proof_missing: 'Proof missing', due_soon: 'Due soon', upcoming: 'Coming up', done: 'Both proofs in', override: 'Accepted by the owner / admin' };
// Works out one item's state from its proofs.
export function itemState(kind, period, { due, amount, label, paidAuto } = {}, rule = taxRules()[kind], today = dateStr()) {
  const row = proofRow(kind, period) || {};
  const needLodge = rule.lodge !== false && !(row.not_needed & 1);
  const needPay = rule.pay !== false && !(row.not_needed & 2);
  const elsewhere = row.paid_at ? null : paymentElsewhere(kind, period) || (paidAuto ? { ...paidAuto, ref: '', photos: 0, where: 'Accounting' } : null);
  const lodged = !!row.lodged_at;
  const paid = !!row.paid_at || !!elsewhere;
  const lodgeProof = lodged && J(row.lodge_photos, []).length > 0;
  const payProof = (!!row.paid_at && J(row.pay_photos, []).length > 0) || (!row.paid_at && elsewhere && elsewhere.photos > 0);
  const dueDate = row.due_date && !due ? row.due_date : due;
  const flags = [];
  const complete = (!needLodge || lodgeProof) && (!needPay || payProof);
  const override = !!row.override_at;
  if (!complete && !override) {
    if (needLodge && needPay && lodged && !paid) flags.push('lodged_not_paid');
    if (needLodge && needPay && paid && !lodged) flags.push('paid_not_lodged');
    if ((lodged && needLodge && !lodgeProof) || (paid && needPay && !payProof)) flags.push('proof_missing');
    if (dueDate && dueDate < today && ((needLodge && !lodged) || (needPay && !paid))) flags.push('overdue');
    else if (dueDate && addDays(today, rule.lead || 0) >= dueDate && ((needLodge && !lodged) || (needPay && !paid))) flags.push('due_soon');
    if (!flags.length) flags.push('upcoming');
  }
  const state = override && !complete ? 'override' : complete ? 'done' : flags[0];
  const red = flags.includes('overdue') || flags.includes('lodged_not_paid') || flags.includes('paid_not_lodged');
  return {
    uid: proofUid(kind, period), kind, period, label: label || period, title: `${TAX_ITEMS[kind].short} ${label || period}`, due: dueDate, amount: amount === undefined ? row.amount : amount,
    needLodge, needPay, lodged, paid, lodgeProof, payProof, elsewhere, flags, state, red, done: complete || override, override,
    level: flags.includes('overdue') ? 'urgent' : red ? 'urgent' : flags.includes('proof_missing') || flags.includes('due_soon') ? 'warning' : 'info',
    row: { ...row, lodge_photos: J(row.lodge_photos, []), pay_photos: J(row.pay_photos, []) }, responsibleUid: rule.responsibleUid || '',
  };
}
// The whole calendar: every obligation and period, worst first within each kind.
export function taxCalendar({ today = dateStr(), kinds } = {}) {
  const rules = taxRules();
  const fromYm = rules.startYm || ymAdd(today.slice(0, 7), -3);
  const out = [];
  for (const kind of kinds || TAX_KIND_ORDER) {
    const rule = rules[kind];
    if (!rule || rule.on === false) continue;
    const list = periodsFor(kind, rule, { today, fromYm });
    // Periods that already have proofs are always shown, even before the start month.
    if (has('tax_proofs')) {
      db().all("SELECT * FROM tax_proofs WHERE kind = ? AND status = 'active'", [kind]).forEach((r) => { if (!list.some((x) => x.period === r.period)) list.push({ period: r.period, due: r.due_date, amount: r.amount }); });
    }
    list.forEach((p) => out.push(itemState(kind, p.period, p, rule, today)));
  }
  return out.sort((a, b) => (a.due || '9999') < (b.due || '9999') ? -1 : (a.due || '9999') > (b.due || '9999') ? 1 : 0);
}
export function getTaxItem(kind, period, today = dateStr()) {
  need(TAX_ITEMS[kind], 'Unknown tax item.');
  const found = taxCalendar({ today, kinds: [kind] }).find((x) => x.period === period);
  return found || itemState(kind, period, {}, taxRules()[kind], today);
}

// ---------------------------------------------------------------- the two proofs
function canFile(user, kind) {
  if (isTop(user)) return true;
  const rule = taxRules()[kind] || {};
  return (rule.responsibleUid && user && rule.responsibleUid === user.uid) || can(user, TAX_ITEMS[kind].perm) || can(user, 'statutory');
}
// Lodgement: the return / schedule was filed. photos: proof (screenshot of the FRCS / FNPF receipt, stamped copy…).
export function recordLodgement(user, kind, period, { date, ref, photos = [], note, due, amount } = {}) {
  need(TAX_ITEMS[kind], 'Unknown tax item.');
  need(canFile(user, kind), 'You cannot record tax filings.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date it was lodged.');
  need(txt(ref) || (photos || []).length, 'Enter the lodgement / receipt number, or take a photo of the proof.');
  const row = ensureRow(kind, period, due, amount);
  const list = J(row.lodge_photos, []).concat(photos || []);
  db().run(`UPDATE tax_proofs SET lodged_at = ?, lodged_by_name = ?, lodge_ref = ?, lodge_photos = ?, lodge_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [d, user.name, txt(ref) || null, JSON.stringify(list), txt(note) || null, stamp(), deviceId(), row.uid]);
  if ((photos || []).length) addPhotos('tax_lodge', row.uid, photos);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: lodged ${d}${ref ? ` (ref ${txt(ref)})` : ''}${(photos || []).length ? ' with proof' : ''}`, table: 'tax_proofs', recordUid: row.uid });
  return getTaxItem(kind, period);
}
export function recordTaxPaymentProof(user, kind, period, { date, amount, ref, photos = [], note, due } = {}) {
  need(TAX_ITEMS[kind], 'Unknown tax item.');
  need(canFile(user, kind), 'You cannot record tax payments.');
  const d = txt(date) || dateStr();
  need(DATE.test(d), 'Choose the date it was paid.');
  const a = r2(amount);
  need(a > 0, 'Enter the amount paid.');
  need(txt(ref) || (photos || []).length, 'Enter the bank / receipt reference, or take a photo of the proof.');
  const row = ensureRow(kind, period, due, null);
  const list = J(row.pay_photos, []).concat(photos || []);
  db().run(`UPDATE tax_proofs SET paid_at = ?, paid_by_name = ?, paid_amount = ?, pay_ref = ?, pay_photos = ?, pay_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [d, user.name, a, txt(ref) || null, JSON.stringify(list), txt(note) || null, stamp(), deviceId(), row.uid]);
  if ((photos || []).length) addPhotos('tax_pay', row.uid, photos);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: paid ${$(a)} on ${d}${ref ? ` (ref ${txt(ref)})` : ''}${(photos || []).length ? ' with proof' : ''}`, table: 'tax_proofs', recordUid: row.uid });
  return getTaxItem(kind, period);
}
// Add the proof photo later (the "proof missing" flag goes away). which: 'lodge' | 'pay'.
export function addTaxProof(user, kind, period, which, photos = []) {
  need(['lodge', 'pay'].includes(which), 'Lodgement or payment?');
  need((photos || []).length, 'Take a photo of the proof.');
  need(canFile(user, kind), 'You cannot add tax proofs.');
  const item = getTaxItem(kind, period);
  let row = proofRow(kind, period);
  if (which === 'pay' && !(row && row.paid_at) && item.elsewhere) {
    // The payment was recorded elsewhere (FNPF & PAYE payments / Tax centre): copy it here with the proof.
    return recordTaxPaymentProof(user, kind, period, { date: item.elsewhere.date || dateStr(), amount: item.elsewhere.amount || item.amount || 0.01, ref: item.elsewhere.ref || 'recorded in the app', photos, due: item.due });
  }
  need(row && (which === 'lodge' ? row.lodged_at : row.paid_at), which === 'lodge' ? 'Record the lodgement first.' : 'Record the payment first.');
  const col = which === 'lodge' ? 'lodge_photos' : 'pay_photos';
  db().run(`UPDATE tax_proofs SET ${col} = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(J(row[col], []).concat(photos)), stamp(), deviceId(), row.uid]);
  addPhotos(which === 'lodge' ? 'tax_lodge' : 'tax_pay', row.uid, photos);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: ${which === 'lodge' ? 'lodgement' : 'payment'} proof added`, table: 'tax_proofs', recordUid: row.uid });
  row = proofRow(kind, period);
  return getTaxItem(kind, period);
}
// Nothing to pay (e.g. a VAT refund month) or nothing to lodge this time. Bit 1 = lodgement, bit 2 = payment.
export function markNotNeeded(user, kind, period, which, reason) {
  need(['lodge', 'pay'].includes(which), 'Lodgement or payment?');
  need(canFile(user, kind), 'You cannot change tax items.');
  needReason(user, reason, 'Write why it is not needed.');
  const item = getTaxItem(kind, period);
  const row = ensureRow(kind, period, item.due, item.amount);
  const bits = (row.not_needed || 0) | (which === 'lodge' ? 1 : 2);
  db().run(`UPDATE tax_proofs SET not_needed = ?, ${which === 'lodge' ? 'lodge_note' : 'pay_note'} = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [bits, `Not needed${reason ? `: ${txt(reason)}` : ''}`, stamp(), deviceId(), row.uid]);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: ${which === 'lodge' ? 'no lodgement' : 'no payment'} needed`, table: 'tax_proofs', recordUid: row.uid, reason: txt(reason) || null });
  return getTaxItem(kind, period);
}
// Take back a lodgement or payment recorded by mistake (kept in the history).
export function undoTaxProof(user, kind, period, which, reason) {
  need(['lodge', 'pay'].includes(which), 'Lodgement or payment?');
  need(canFile(user, kind), 'You cannot change tax items.');
  needReason(user, reason, 'Write why it is taken back.');
  const row = proofRow(kind, period);
  need(row, 'Nothing recorded.');
  const before = { ...row };
  if (which === 'lodge') db().run(`UPDATE tax_proofs SET lodged_at = NULL, lodged_by_name = NULL, lodge_ref = NULL, lodge_photos = '[]', not_needed = not_needed & 2, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [stamp(), deviceId(), row.uid]);
  else db().run(`UPDATE tax_proofs SET paid_at = NULL, paid_by_name = NULL, paid_amount = NULL, pay_ref = NULL, pay_photos = '[]', not_needed = not_needed & 1, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [stamp(), deviceId(), row.uid]);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: ${which === 'lodge' ? 'lodgement' : 'payment'} taken back`, table: 'tax_proofs', recordUid: row.uid, before, reason: txt(reason) || null });
  return getTaxItem(kind, period);
}
// Owner / admin accept an item without both proofs (e.g. the accountant filed it); recorded for the audit.
export function overrideTaxItem(user, kind, period, reason) {
  need(isTop(user), 'Only the owner or admin can accept a tax item without both proofs.');
  needReason(user, reason, 'Write why.');
  const item = getTaxItem(kind, period);
  const row = ensureRow(kind, period, item.due, item.amount);
  db().run(`UPDATE tax_proofs SET override_by_name = ?, override_at = ?, override_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [user.name, stamp(), txt(reason) || null, stamp(), deviceId(), row.uid]);
  audit({ user, action: `${TAX_ITEMS[kind].short} ${period}: accepted without both proofs`, table: 'tax_proofs', recordUid: row.uid, reason: txt(reason) || null });
  return getTaxItem(kind, period);
}
// Change history of one item (for the audit).
export function taxItemHistory(kind, period) {
  return db().all('SELECT at, user_name, action, reason FROM audit_log WHERE record_uid = ? ORDER BY at DESC LIMIT 100', [proofUid(kind, period)]);
}

// ---------------------------------------------------------------- month end, warnings, dashboard
// Items that belong to a month: monthly ones for that month, pay day reports paid in it, instalments / yearly due in it.
export function taxItemsForMonth(ym, today = dateStr()) {
  return taxCalendar({ today }).filter((i) => (TAX_ITEMS[i.kind].freq === 'monthly' ? i.period === ym : TAX_ITEMS[i.kind].freq === 'payday' ? i.period.slice(0, 7) === ym : String(i.due || '').slice(0, 7) === ym));
}
// Lines for the accounting month-end checklist ({ key, label, left }): blocks until both proofs are in.
export function taxMonthEndItems(ym) {
  return taxItemsForMonth(ym).map((i) => ({ key: `tax_${i.kind}_${i.period}`, label: `${i.title}: ${[i.needLodge ? 'lodgement' : '', i.needPay ? 'payment' : ''].filter(Boolean).join(' and ')} proof in${i.override ? ' (accepted by the owner/admin)' : ''}`, left: i.done ? 0 : 1 }));
}
// Who sees an item's warnings: its responsible person, the owner / admin, or (if no one is set) people with the permission.
export function seesTaxItem(user, item) {
  if (!user) return false;
  if (isTop(user)) return true;
  if (item.responsibleUid) return item.responsibleUid === user.uid;
  return can(user, TAX_ITEMS[item.kind].perm) || can(user, 'statutory');
}
export function taxAlerts(user, today = dateStr()) {
  let list = [];
  try { list = taxCalendar({ today }); } catch (e) { return []; }
  const out = [];
  for (const i of list) {
    if (i.done || !seesTaxItem(user, i)) continue;
    if (i.flags.includes('upcoming')) continue;
    const words = i.flags.map((f) => TAX_FLAG[f]).join(', ');
    out.push({ id: `tax-${i.kind}-${i.period}-${i.flags.join('-')}`, level: i.level, text: `${i.title}: ${words}`, sub: `${i.due ? `Due ${i.due}` : ''}${i.amount ? ` · ${$(i.amount)}` : ''}`.replace(/^ · /, ''), nav: { screen: 'TaxItem', params: { kind: i.kind, period: i.period } }, area: 'Tax' });
  }
  return out;
}
export function taxCardData(today = dateStr()) {
  const list = taxCalendar({ today }).filter((i) => !i.done);
  if (!list.length) return { value: 'All in', sub: 'Every lodgement and payment has its proof', tone: 'good', lines: [], nav: { screen: 'TaxCalendar', params: {} } };
  const overdue = list.filter((i) => i.flags.includes('overdue'));
  const red = list.filter((i) => i.red);
  const next = list.filter((i) => i.due && i.due >= today)[0];
  return {
    value: overdue.length ? `${overdue.length} overdue` : red.length ? `${red.length} to fix` : `${list.length} coming`, sub: next ? `Next: ${next.title} due ${next.due}` : '', tone: red.length ? 'bad' : list.some((i) => i.level === 'warning') ? 'warn' : undefined,
    lines: list.slice(0, 6).map((i) => [i.title, `${i.due || ''} · ${TAX_FLAG[i.flags[0]] || ''}`, i.red ? 'bad' : i.level === 'warning' ? 'warn' : undefined]), nav: { screen: 'TaxCalendar', params: {} },
  };
}
