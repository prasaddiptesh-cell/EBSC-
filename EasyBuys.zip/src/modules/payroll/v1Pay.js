// 1.0.0 (build 1) payroll for the new office and the staff's "My pay" (map screens rep-pay, rep-fnpf, s-mypay).
//   payWeek      – the pay week at a glance: each person's net pay, staff credit taken off (Aronium), FNPF, approve.
//   cleanPayslip – the clean payslip staff see: hours, pay, FNPF, staff credit, till short, net (the finer details stay
//                  on the payroll / admin payslip).
//   fnpfMonth    – FNPF per employee per pay week (pay, FNPF deduction, employer part, FNPF number, the pay week's
//                  dates) and the monthly payable summary, for the accountant to file on the FNPF employer portal.
//                  People with FNPF switched off (family) are never on it.
// The pay itself is worked out by service.js (the staff profile holds each person's rules and rates; fixed weekly
// salaries are paid in each weekly run; Aronium staff credit is taken off on pay day).
import { db } from '../../db/connection.js';
import { money } from '../../services/core.js';
import * as P from './service.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
const YM = /^\d{4}-\d{2}$/;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const HOUR_KINDS = ['normal', 'ot', 'sunday', 'holiday', 'leave'];

export function fnpfOff(userUid) {
  const p = safe(() => P.getProfile(userUid), null);
  return !!p && P.statRuleOf(p, 'fnpf').on === false;
}

// ---------------------------------------------------------------- the clean payslip
// Every amount taken off is in exactly one bucket, so pay − FNPF − PAYE − staff credit − till short − other = net.
export function cleanPayslip(lineOrUid) {
  const raw = typeof lineOrUid === 'string' ? db().get('SELECT * FROM pay_lines WHERE uid = ?', [lineOrUid]) : lineOrUid;
  if (!raw) return null;
  const l = P.decodeLine(raw);
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [l.run_uid]) || {};
  const ded = l.deductions || [];
  const sumKind = (k) => r2(ded.filter((d) => d.kind === k).reduce((s, d) => s + (Number(d.amount) || 0), 0));
  const staffCredit = sumKind('staff_credit');
  const tillShort = sumKind('till_short');
  const advance = r2(ded.filter((d) => d.inWeek).reduce((s, d) => s + (Number(d.amount) || 0), 0)); // build 19: given during the week
  const other = r2(ded.filter((d) => d.kind !== 'staff_credit' && d.kind !== 'till_short' && !d.inWeek).reduce((s, d) => s + (Number(d.amount) || 0), 0));
  const hours = r2(['normal', 'ot', 'sunday', 'holiday'].reduce((s, k) => s + (Number((l.hours || {})[k]) || 0), 0)); // build 19: hours worked, all normal
  const leaveH = r2((l.hours || {}).leave);
  const fnpf = r2(l.fnpf_employee);
  const paye = r2(l.paye);
  const net = r2(l.net);
  const worked = r2(l.gross - fnpf - paye - staffCredit - tillShort - advance - other);
  return {
    lineUid: l.uid, runUid: l.run_uid, userUid: l.user_uid, name: l.name, weekStart: run.week_start, weekEnd: run.week_end, payDate: run.pay_date, status: run.status,
    hours, salary: l.pay_type === 'salary', pay: r2(l.gross), fnpf, paye, staffCredit, tillShort, advance, other, net, adds: Math.abs(worked - net) < 0.01,
    fnpfOff: fnpfOff(l.user_uid),
    rows: [
      { key: 'hours', label: 'Normal hours worked', value: hours ? `${hours} h` : (l.pay_type === 'salary' ? 'weekly salary' : '0') },
      leaveH ? { key: 'leave', label: 'Paid leave', value: `${leaveH} h` } : null,
      { key: 'pay', label: 'Pay', amount: r2(l.gross) },
      fnpf ? { key: 'fnpf', label: 'FNPF', amount: -fnpf } : null,
      paye ? { key: 'paye', label: 'Tax (PAYE)', amount: -paye } : null,
      staffCredit ? { key: 'credit', label: 'Staff credit (Aronium)', amount: -staffCredit } : null,
      tillShort ? { key: 'short', label: 'Till short', amount: -tillShort } : null,
      advance ? { key: 'advance', label: 'Advance already given (part of this pay)', amount: -advance } : null,
      other ? { key: 'other', label: 'Other (advance, loan …)', amount: -other } : null,
      { key: 'net', label: `Paid ${run.pay_date || ''}`.trim(), amount: net, strong: true },
    ].filter(Boolean),
  };
}
// My pay: the latest final payslip and the ones before it (staff see only their own).
export function myPay(user, { limit = 12 } = {}) {
  if (!user || !has('pay_lines')) return { latest: null, earlier: [] };
  const lines = db().all(`SELECT l.* FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.user_uid = ? AND l.include = 1 ORDER BY r.pay_date DESC, r.week_start DESC LIMIT ?`, [user.uid, limit]);
  const all = lines.map(cleanPayslip).filter(Boolean);
  return { latest: all[0] || null, earlier: all.slice(1) };
}

// ---------------------------------------------------------------- the pay week (rep-pay)
export function payWeek(runUid) {
  const run = runUid ? db().get('SELECT * FROM pay_runs WHERE uid = ?', [runUid])
    : db().get("SELECT * FROM pay_runs WHERE status IN ('draft','final') AND IFNULL(run_kind,'regular') = 'regular' ORDER BY pay_date DESC, week_start DESC LIMIT 1");
  if (!run) return null;
  const lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1 ORDER BY name', [run.uid]).map(cleanPayslip).filter(Boolean);
  const sum = (k) => r2(lines.reduce((s, x) => s + (Number(x[k]) || 0), 0));
  const employer = r2(db().get('SELECT IFNULL(SUM(fnpf_employer),0) AS s FROM pay_lines WHERE run_uid = ? AND include = 1', [run.uid]).s);
  const warnings = db().all('SELECT name, warnings FROM pay_lines WHERE run_uid = ? AND include = 1', [run.uid]).flatMap((x) => J(x.warnings, []).map((w) => `${x.name}: ${w}`));
  return {
    run: { uid: run.uid, weekStart: run.week_start, weekEnd: run.week_end, payDate: run.pay_date, status: run.status },
    lines, people: lines.length, net: sum('net'), pay: sum('pay'), staffCredit: sum('staffCredit'), tillShort: sum('tillShort'), fnpfStaff: sum('fnpf'), fnpfEmployer: employer,
    fnpfTotal: r2(sum('fnpf') + employer), paye: sum('paye'), warnings,
  };
}

// ---------------------------------------------------------------- FNPF (rep-fnpf)
export function fnpfMonth(ym) {
  if (!YM.test(String(ym || ''))) throw new Error('Choose the month.');
  const rows = [];
  const people = new Map();
  const left = new Map();
  if (has('pay_runs')) {
    for (const l of db().all(`SELECT l.uid, l.user_uid, l.name, l.gross, l.fnpf_base, l.fnpf_employee, l.fnpf_employer, r.uid AS run_uid, r.pay_date, r.week_start, r.week_end
      FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND substr(r.pay_date,1,7) = ? ORDER BY l.name, r.pay_date`, [ym])) {
      const off = fnpfOff(l.user_uid);
      const staff = r2(l.fnpf_employee); const employer = r2(l.fnpf_employer);
      if (off) { const x = left.get(l.user_uid) || { name: l.name, amount: 0 }; x.amount = r2(x.amount + staff + employer); left.set(l.user_uid, x); continue; }
      if (!(staff + employer > 0.004)) continue;
      const p = safe(() => P.getProfile(l.user_uid), {}) || {};
      const row = { lineUid: l.uid, userUid: l.user_uid, name: l.name, fnpfNo: p.fnpf_no || '', tin: p.tin || '', weekStart: l.week_start, weekEnd: l.week_end, payDate: l.pay_date,
        pay: r2(l.gross), base: r2(l.fnpf_base), staff, employer, total: r2(staff + employer) };
      rows.push(row);
      const x = people.get(l.user_uid) || { userUid: l.user_uid, name: l.name, fnpfNo: row.fnpfNo, weeks: 0, pay: 0, base: 0, staff: 0, employer: 0, total: 0 };
      x.weeks += 1; x.pay = r2(x.pay + row.pay); x.base = r2(x.base + row.base); x.staff = r2(x.staff + staff); x.employer = r2(x.employer + employer); x.total = r2(x.total + row.total);
      people.set(l.user_uid, x);
    }
  }
  const list = [...people.values()];
  const t = (k) => r2(list.reduce((s, x) => s + x[k], 0));
  const R = safe(() => require('./returns.js'), null);
  const status = R ? safe(() => R.returnStatus('fnpf', ym), null) : null;
  const sched = R ? safe(() => R.fnpfSchedule(ym), null) : null;
  const checks = [];
  list.filter((x) => !x.fnpfNo).forEach((x) => checks.push({ level: 'bad', text: `${x.name}: no FNPF number – add it on the staff profile.` }));
  [...left.values()].filter((x) => x.amount > 0.004).forEach((x) => checks.push({ level: 'warn', text: `${x.name} has FNPF switched off but ${$(x.amount)} FNPF was worked out this month – check the pay run.` }));
  const draft = has('pay_runs') ? db().get("SELECT COUNT(*) AS n FROM pay_runs WHERE status = 'draft' AND substr(pay_date,1,7) = ?", [ym]).n : 0;
  if (draft) checks.unshift({ level: 'bad', text: `${draft} pay run(s) paid in ${ym} are still drafts – approve them first.` });
  return {
    ym, rows, people: list, excluded: left.size, totals: { staff: t('staff'), employer: t('employer'), total: t('total'), pay: t('pay'), base: t('base'), employees: list.length },
    due: sched ? sched.payDue : null, lodgeDue: sched ? sched.csDue : null, checks, status,
    trail: safe(() => trailFor(ym, status), []),
  };
}
function trailFor(ym, status) {
  const { getShared } = require('../../services/core.js');
  const t = getShared(`fnpf_trail_${ym}`, {}) || {};
  const lodged = status && (status.lodged || (status.item && status.item.lodged));
  const paid = status && ((status.file && status.file.paid_date) || (status.item && status.item.paid));
  return [
    { key: 'worked', label: 'Worked out from the pay runs', done: true, when: t.worked ? `${t.worked.by} · ${String(t.worked.at).slice(0, 16)}` : 'now' },
    { key: 'sent', label: 'Sent to the accountant (Excel)', done: !!t.sent, when: t.sent ? `${t.sent.by} · ${String(t.sent.at).slice(0, 16)}` : null },
    { key: 'filed', label: 'Filed on the FNPF employer portal', done: !!lodged, when: null },
    { key: 'paid', label: 'Paid to FNPF', done: !!paid, when: paid ? String((status.file && status.file.paid_date) || '') : null },
  ];
}
const col = (key, title, align = 'left') => ({ key, title, align });
export function fnpfMonthReport(from) {
  const ym = YM.test(String(from || '').slice(0, 7)) ? String(from).slice(0, 7) : null;
  const f = fnpfMonth(ym || require('../accounting/v1.js').lastFullMonth());
  return {
    title: `FNPF – ${f.ym}`, subtitle: `Per employee per pay week · pay by ${f.due || '–'}${f.excluded ? ` · ${f.excluded} family member(s) with FNPF off not included` : ''}`,
    summary: [{ label: 'Staff part (deducted)', value: $(f.totals.staff) }, { label: 'Employer part', value: $(f.totals.employer) }, { label: 'Total payable', value: $(f.totals.total) }, { label: 'Employees', value: String(f.totals.employees) }],
    sections: [
      { title: 'Per pay week', columns: [col('name', 'Employee'), col('fnpfNo', 'FNPF number'), col('weekStart', 'Pay week from'), col('weekEnd', 'to'), col('payDate', 'Paid'), col('pay', 'Pay', 'right'),
        col('base', 'FNPF wages', 'right'), col('staff', 'FNPF deducted', 'right'), col('employer', 'Employer part', 'right'), col('total', 'Total', 'right')], rows: f.rows,
      totals: [{ label: 'Total payable', value: f.totals.total, strong: true }] },
      { title: 'Monthly summary', columns: [col('name', 'Employee'), col('fnpfNo', 'FNPF number'), col('weeks', 'Weeks', 'right'), col('pay', 'Pay', 'right'), col('base', 'FNPF wages', 'right'),
        col('staff', 'FNPF deducted', 'right'), col('employer', 'Employer part', 'right'), col('total', 'Total', 'right')], rows: f.people },
      { title: 'Checks', columns: [col('level', 'Level'), col('text', 'Check')], rows: f.checks },
    ],
  };
}
export function payWeekReport(from, to, user, params = {}) {
  const w = payWeek(params.runUid);
  if (!w) return { title: 'Pay week', subtitle: 'No pay run yet', sections: [] };
  return {
    title: `Pay week ${w.run.weekStart} – ${w.run.weekEnd}`, subtitle: `Paid ${w.run.payDate} · ${w.run.status === 'final' ? 'approved' : 'not approved yet'}`,
    summary: [{ label: 'Net pay', value: $(w.net) }, { label: 'Staff credit taken off (Aronium)', value: $(w.staffCredit) }, { label: 'FNPF (staff + employer)', value: $(w.fnpfTotal) }],
    sections: [{ title: 'People', columns: [col('name', 'Name'), col('hours', 'Hours', 'right'), col('pay', 'Pay', 'right'), col('fnpf', 'FNPF', 'right'), col('staffCredit', 'Staff credit', 'right'),
      col('tillShort', 'Till short', 'right'), col('other', 'Other', 'right'), col('net', 'Net', 'right')], rows: w.lines }],
  };
}
export const V1_PAY_REPORTS = [
  { id: 'v1_fnpf', group: 'Payroll', icon: '🏦', title: 'FNPF for the accountant (per week)', desc: 'Per employee per pay week and the monthly payable – family members with FNPF off left out', perm: 'payroll_view', build: fnpfMonthReport },
  { id: 'v1_payweek', group: 'Payroll', icon: '💵', title: 'Pay week at a glance', desc: 'Each person\'s pay, FNPF, staff credit, till short and net', perm: 'payroll_view', build: payWeekReport },
];
