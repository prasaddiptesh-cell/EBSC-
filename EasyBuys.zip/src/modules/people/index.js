// Recruitment & onboarding: vacancies, applicants, hiring, onboarding checklist, contracts signed on screen, pay sign-off.
import { RecruitHomeScreen, OpeningScreen, ApplicantScreen, OnboardingScreen, ContractScreen, PaySignScreen, RecruitSetupScreen, ContractPdfSetupScreen } from './screens/PeopleScreens.js';
import { can } from '../../services/access.js';

const m = (u) => can(u, 'recruit_manage');
export default {
  id: 'recruitment',
  title: 'Recruitment & onboarding',
  icon: '🧑‍💼',
  switchable: true,
  screens: {
    Recruitment: { component: RecruitHomeScreen, can: m },
    Opening: { component: OpeningScreen, can: m },
    Applicant: { component: ApplicantScreen, can: m },
    Onboarding: { component: OnboardingScreen, can: (u) => m(u) || can(u, 'contract_sign') },
    Contract: { component: ContractScreen, can: (u) => m(u) || can(u, 'contract_sign') },
    PaySign: { component: PaySignScreen, can: (u) => can(u, 'payroll_run') || can(u, 'payroll_view') },
    RecruitSetup: { component: RecruitSetupScreen, can: (u) => can(u, 'settings') },
    ContractPdfSetup: { component: ContractPdfSetupScreen, can: (u) => can(u, 'settings') },
  },
  reports: [],
};
