// Recruitment & onboarding menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🧑‍💼', title: 'Vacancies & applicants', screen: 'Recruitment' },
    { id: 'rc-new-job', icon: '📣', title: 'New vacancy', screen: 'Opening' },
    { id: 'rc-new-app', icon: '🧑', title: 'Add an applicant', screen: 'Applicant' },
  ] },
  { section: 'Settings', items: [
    { id: 'rc-setup', icon: '⚙️', title: 'Onboarding checklist & probation', screen: 'RecruitSetup' },
    { id: 'rc-pdf', icon: '📄', title: 'Company contract PDF', screen: 'ContractPdfSetup' },
  ] },
];
