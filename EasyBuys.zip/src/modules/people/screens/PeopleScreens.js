// Recruitment & onboarding: vacancies, applicants, hiring, the onboarding checklist, contracts signed on screen,
// and staff signing for their pay.
import React, { useState } from 'react';
import { View, ScrollView, Image } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, Choice } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, Action, Actions, ReasonButton, ReasonField, DateTimeField } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { SignaturePad, SignatureView } from '../../../ui/signature.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { shareReport, printReport } from '../../../platform/files.js';
import * as PP from '../service.js';
import { finishContractPdf, readContractPdf, uploadContractTemplate, saveStampPhoto, saveDirectorSignature, previewContractPdf } from '../../../platform/contractFiles.js';
import { cleanLayout, PLACE_WHAT } from '../../../services/contractPdf.js';
import { getDocument } from '../../../services/documents.js';
import { openDocument, pickAnyFile } from '../../../platform/docFiles.js';

const { $ } = PP;
const shopOpts = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const STAGE_COLOR = { applied: C.info, shortlisted: C.info, interview: C.warn, offer: C.warn, hired: C.success, rejected: C.sub, withdrawn: C.sub };

// ---------------------------------------------------------------- home
export function RecruitHomeScreen() {
  const { nav } = useApp();
  const openings = PP.listOpenings();
  const apps = PP.listApplicants({ active: true });
  const onb = PP.listOnboarding();
  const al = PP.peopleAlerts();
  return (
    <Screen title="Recruitment & onboarding" subtitle="From job advert to a fully set-up staff member">
      <Stats items={[
        { label: 'Open vacancies', value: String(openings.length) }, { label: 'Applicants in progress', value: String(apps.length) },
        { label: 'Being onboarded', value: String(onb.filter((o) => !o.complete).length) }, { label: 'Probation ending soon', value: String(al.probationDue.length), color: al.probationDue.length ? C.warn : undefined },
      ]} />
      {al.probationDue.map((o) => <Banner key={o.uid} tone="warn" title={`Probation: ${o.user && o.user.name}`} message={`Ends ${o.probation_end}. Decide: passed, extended or ended.`} />)}
      {al.queries ? <Banner tone="warn" title={`${al.queries} pay query(s) from staff`} message="Someone did not agree with their pay. Open Pay sign-off › Queries." /> : null}
      <Section title="Hiring">
        <Actions>
          <Action testID="rc-new-job" icon="📣" title="New vacancy" note="Job title, shop, pay and what the job is." onPress={() => nav.push('Opening', {})} />
          <Action testID="rc-new-app" icon="🧑" title="Add an applicant" note="Name, phone, photo of their CV / letter, which job." onPress={() => nav.push('Applicant', {})} />
        </Actions>
      </Section>
      <Section title="Vacancies">
        {!openings.length ? <Text style={{ color: C.sub }}>No open vacancies.</Text> : null}
        {openings.map((o) => <ListItem key={o.uid} title={`${o.title}${o.shop_code ? ` · ${o.shop_code}` : ''}`} sub={`${o.active} in progress · ${o.total} applied · since ${o.opened_at}`} onPress={() => nav.push('Opening', { uid: o.uid })} />)}
      </Section>
      <Section title="Applicants in progress">
        {apps.map((a) => <ListItem key={a.uid} testID={`app-${a.name}`} title={a.name} sub={`${a.job || 'Any job'} · ${a.phone || a.email || ''}${a.interview_at ? ` · interview ${a.interview_at}` : ''}`} badge={PP.STAGES[a.stage]} badgeColor={STAGE_COLOR[a.stage]} onPress={() => nav.push('Applicant', { uid: a.uid })} />)}
      </Section>
      <Section title="Onboarding">
        {onb.map((o) => <ListItem key={o.uid} testID={`onb-${o.user && o.user.name}`} title={o.user ? o.user.name : ''} sub={`started ${o.start_date}${o.probation_end ? ` · probation to ${o.probation_end}` : ''}${o.probation_result ? ` · ${o.probation_result}` : ''}`}
          right={`${o.done}/${o.total}`} badge={o.complete ? 'DONE' : 'TO DO'} badgeColor={o.complete ? C.success : C.warn} onPress={() => nav.push('Onboarding', { userUid: o.user_uid })} />)}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- vacancy
export function OpeningScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const o = params.uid ? PP.listOpenings({ all: true }).find((x) => x.uid === params.uid) : null;
  const [f, setF] = useState(o ? { uid: o.uid, title: o.title, shopCode: o.shop_code || '', payType: o.pay_type || 'hourly', rate: o.rate ? String(o.rate) : '', hours: o.hours || '', description: o.description || '', status: o.status }
    : { title: '', shopCode: user.shop_code || 'S1', payType: 'hourly', rate: '', hours: '', description: '', status: 'open' });
  const apps = o ? PP.listApplicants({ openingUid: o.uid }) : [];
  return (
    <Screen title={o ? o.title : 'New vacancy'} footer={<Btn testID="op-save" title="Save" icon="💾" variant="success" onPress={() => { const uid = act(() => PP.saveOpening(user, f), 'Saved'); if (uid && !o) nav.replace('Opening', { uid }); }} />}>
      <Field testID="op-title" label="Job title" value={f.title} onChangeText={(v) => setF({ ...f, title: v })} placeholder="e.g. Cashier, Baker, Stock hand" />
      <Label>Shop</Label>
      <Chips value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} options={shopOpts()} />
      <Chips value={f.payType} onChange={(v) => setF({ ...f, payType: v })} options={[{ value: 'hourly', label: 'Paid by the hour' }, { value: 'salary', label: 'Weekly salary' }]} />
      <MoneyField label={f.payType === 'salary' ? 'Weekly salary' : 'Rate per hour'} value={f.rate} onChange={(v) => setF({ ...f, rate: v })} />
      <Field label="Hours / days" value={f.hours} onChangeText={(v) => setF({ ...f, hours: v })} placeholder="e.g. 48 hours, Mon–Sat" />
      <Field label="About the job (for the advert)" value={f.description} onChangeText={(v) => setF({ ...f, description: v })} multiline />
      <Chips value={f.status} onChange={(v) => setF({ ...f, status: v })} options={[{ value: 'open', label: 'Open' }, { value: 'closed', label: 'Closed (filled)' }]} />
      {o ? (
        <Section title={`Applicants (${apps.length})`}>
          <Btn title="Add an applicant for this job" size="md" variant="info" onPress={() => nav.push('Applicant', { openingUid: o.uid })} />
          {apps.map((a) => <ListItem key={a.uid} title={a.name} sub={a.phone || ''} badge={PP.STAGES[a.stage]} badgeColor={STAGE_COLOR[a.stage]} right={a.score !== null && a.score !== undefined ? `${a.score}/10` : ''} onPress={() => nav.push('Applicant', { uid: a.uid })} />)}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- applicant
export function ApplicantScreen({ params }) {
  const { nav, user } = useApp();
  const act = useAct();
  const ui = useUI();
  const a = params.uid ? PP.getApplicant(params.uid) : null;
  const [f, setF] = useState(a ? { uid: a.uid, openingUid: a.opening_uid || '', name: a.name, phone: a.phone || '', email: a.email || '', address: a.address || '', stage: a.stage, interviewAt: a.interview_at || '', score: a.score === null ? '' : String(a.score), notes: a.notes || '', source: a.source || '', rejectReason: a.reject_reason || '' }
    : { openingUid: params.openingUid || '', name: '', phone: '', email: '', address: '', stage: 'applied', interviewAt: '', score: '', notes: '', source: '', rejectReason: '' });
  const [photos, setPhotos] = useState([]);
  const [hireF, setHireF] = useState(null);
  const openings = PP.listOpenings();
  const save = () => { const uid = act(() => PP.saveApplicant(user, f, { photos }), 'Saved'); if (uid) { setPhotos([]); if (!a) nav.replace('Applicant', { uid }); } };
  const doHire = () => {
    try {
      const r = PP.hire(user, a.uid, hireF);
      ui.alert({ title: `${a.name} is hired`, message: `Employee number ${r.employeeNo}.\nTime Clock PIN: ${r.pin}\n\nGive them the PIN (they can change it later with the manager). The onboarding checklist has started${hireF.email ? ' and a welcome email is on its way' : ''}.` });
      nav.replace('Onboarding', { userUid: r.user.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={a ? a.name : 'New applicant'} subtitle={a ? PP.STAGES[a.stage] : ''} footer={hireF ? null : <Btn testID="ap-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Select label="Job" value={f.openingUid} onChange={(v) => setF({ ...f, openingUid: v })} options={[{ value: '', label: 'Any job' }].concat(openings.map((o) => ({ value: o.uid, label: `${o.title}${o.shop_code ? ` (${o.shop_code})` : ''}` })))} />
      <Field testID="ap-name" label="Name" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 180, flexGrow: 1 }}><Field testID="ap-phone" label="Phone" value={f.phone} onChangeText={(v) => setF({ ...f, phone: v })} keyboardType="phone-pad" /></View>
        <View style={{ flexBasis: 220, flexGrow: 1 }}><Field testID="ap-email" label="Email (for the welcome email and contract)" value={f.email} onChangeText={(v) => setF({ ...f, email: v })} /></View>
      </View>
      <Field label="Address" value={f.address} onChangeText={(v) => setF({ ...f, address: v })} />
      <Field label="How did they hear about the job?" value={f.source} onChangeText={(v) => setF({ ...f, source: v })} placeholder="e.g. sign in the shop, Facebook, a friend" />
      {a ? (
        <>
          <Label>Stage</Label>
          <Choice value={f.stage} onChange={(v) => setF({ ...f, stage: v })} testIDPrefix="ap-st" options={Object.entries(PP.STAGES).filter(([k]) => k !== 'hired' || a.stage === 'hired').map(([value, label]) => ({ value, label }))} />
          {['interview', 'offer'].includes(f.stage) ? <DateTimeField label="Interview date and time" value={f.interviewAt || ''} onChange={(v) => setF({ ...f, interviewAt: v })} /> : null}
          {f.stage === 'rejected' ? <ReasonField label="Why not suitable (kept for fairness)" value={f.rejectReason} onChangeText={(v) => setF({ ...f, rejectReason: v })} /> : null}
          <Field label="Interview score (0–10)" value={f.score} onChangeText={(v) => setF({ ...f, score: v.replace(/\D/g, '') })} keyboardType="number-pad" />
        </>
      ) : null}
      <Field label="Notes (interview, references)" value={f.notes} onChangeText={(v) => setF({ ...f, notes: v })} multiline />
      {a ? <PhotoStrip photos={photosFor(listPhotos('applicant', a.uid), a.photos, 'CV / documents')} /> : null}
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo of CV, letter, ID or references" />
      {a && a.stage !== 'hired' && !['rejected', 'withdrawn'].includes(a.stage) ? (
        hireF ? (
          <Card tone="success">
            <H>Hire {a.name}</H>
            <Label>Shop</Label>
            <Chips value={hireF.shopCode} onChange={(v) => setHireF({ ...hireF, shopCode: v })} options={shopOpts()} testIDPrefix="hire-shop" />
            <DateField label="Starts on" value={hireF.startDate} onChange={(v) => setHireF({ ...hireF, startDate: v })} />
            <Field label="Job title" value={hireF.jobTitle} onChangeText={(v) => setHireF({ ...hireF, jobTitle: v })} />
            <MoneyField testID="hire-rate" label="Rate per hour" value={hireF.rate} onChange={(v) => setHireF({ ...hireF, rate: v })} />
            <Field testID="hire-email" label="Email for the welcome message (optional)" value={hireF.email} onChangeText={(v) => setHireF({ ...hireF, email: v })} />
            <Hint>Hiring makes their staff login with a new Time Clock PIN, starts their pay details, the onboarding checklist and (with an email) sends a welcome email asking for their documents.</Hint>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setHireF(null)} />
              <Btn testID="hire-go" title="Hire" size="md" variant="success" style={{ flex: 1 }} onPress={doHire} />
            </View>
          </Card>
        ) : <Btn testID="ap-hire" title="Hire" icon="🤝" variant="success" onPress={() => { const o = openings.find((x) => x.uid === a.opening_uid); setHireF({ shopCode: (o && o.shop_code) || user.shop_code || 'S1', startDate: dateStr(), jobTitle: o ? o.title : '', rate: o && o.rate ? String(o.rate) : '', email: a.email || '' }); }} />
      ) : null}
      {a && a.hired_user_uid ? <Btn title="Open onboarding" size="md" variant="info" onPress={() => nav.push('Onboarding', { userUid: a.hired_user_uid })} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- onboarding
export function OnboardingScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const o = PP.getOnboarding(params.userUid);
  const [email, setEmail] = useState(o ? o.email || '' : '');
  const [note, setNote] = useState('');
  if (!o) {
    return (
      <Screen title="Onboarding">
        <Btn title="Start onboarding for this person" variant="success" onPress={() => act(() => PP.startOnboarding(user, params.userUid, dateStr()), 'Started')} />
      </Screen>
    );
  }
  const contracts = PP.contractsFor(params.userUid);
  return (
    <Screen title={`Onboarding · ${o.user ? o.user.name : ''}`} subtitle={`${o.done} of ${o.total} done · started ${o.start_date}`}>
      <Hint>Tick each item when it is done. Items marked "set in the app" tick themselves (e.g. the contract is signed, the TIN is in pay details).</Hint>
      {o.list.map((x) => (
        <ListItem key={x.key} testID={`ob-${x.key}`} title={`${x.done ? '✅' : '⬜'} ${x.label}`} sub={x.done ? `${x.by || ''}${x.at ? ` · ${x.at.slice(0, 10)}` : ''}` : x.auto ? 'ticks itself when done in the app' : 'tap when done'}
          tone={x.done ? 'success' : undefined} onPress={x.auto ? null : () => act(() => PP.tickOnboarding(user, params.userUid, x.key, !x.done))} />
      ))}
      <Section title="Contract">
        {contracts.map((c) => <ListItem key={c.uid} testID={`ct-${c.status}`} title={c.title} sub={`${{ draft: 'Not signed yet', employee_signed: 'Employee signed – Easy Buys to sign', signed: 'Signed by both', void: `Void: ${c.void_reason}` }[c.status]}`} onPress={() => nav.push('Contract', { uid: c.uid })} />)}
        {!contracts.some((c) => c.status !== 'void') ? <Btn testID="ob-make-contract" title="Make the contract" icon="📝" size="md" variant="info" onPress={() => { const uid = act(() => PP.makeContract(user, params.userUid, { startDate: o.start_date })); if (uid) nav.push('Contract', { uid }); }} /> : null}
      </Section>
      <Section title="Email">
        <Field testID="ob-email" label="Their email" value={email} onChangeText={setEmail} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn title="Save email" size="sm" variant="secondary" onPress={() => act(() => PP.setOnboardingEmail(user, params.userUid, email), 'Saved')} />
          <Btn testID="ob-welcome" title="Send the welcome email" size="sm" variant="info" onPress={() => { if (act(() => { PP.setOnboardingEmail(user, params.userUid, email); PP.sendWelcomeEmail(user, params.userUid); })) ui.toast('Welcome email will be sent when online'); }} />
        </View>
      </Section>
      {o.probation_end ? (
        <Section title={`Probation – ends ${o.probation_end}`}>
          {o.probation_result ? <Text style={{ fontSize: 16, color: C.text }}>{o.probation_result}</Text> : (
            <>
              <Field label="Note" value={note} onChangeText={setNote} />
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                <Btn title="Passed" size="sm" variant="success" onPress={() => act(() => PP.probationDecision(user, params.userUid, 'passed', note), 'Saved')} />
                <Btn title="Extend 1 month" size="sm" variant="warn" onPress={() => act(() => PP.probationDecision(user, params.userUid, 'extended', note), 'Saved')} />
                <Btn title="Not kept on" size="sm" variant="danger" onPress={() => act(() => PP.probationDecision(user, params.userUid, 'ended', note), 'Saved')} />
              </View>
            </>
          )}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- contract
export function ContractScreen({ params }) {
  const { user, can, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const c = PP.getContract(params.uid);
  const [body, setBody] = useState(c ? c.body : '');
  const [sig, setSig] = useState(null);
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  if (!c) return <Screen title="Contract"><Text>Not found.</Text></Screen>;
  const pdfMode = c.mode === 'pdf';
  const cp = PP.contractPdfSettings();
  const emp = PP.getSignature(c.employee_sig_uid);
  const er = PP.getSignature(c.employer_sig_uid);
  const run = async (fn, done) => { setBusy(true); try { const r = await fn(); if (done) done(r); } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); } };
  const finish = () => run(() => finishContractPdf(user, c.uid), (r) => ui.toast(r.email ? `Signed PDF made – it will be emailed to ${r.email}` : 'Signed PDF made (no email address – share it from here)'));
  const signEr = (useDirector) => {
    const r = act(() => PP.signContractEmployer(user, c.uid, useDirector ? null : sig, { useDirector }));
    if (!r) return;
    setSig(null);
    if (r.pdf) finish();
    else ui.toast(r.email ? `Signed – a copy will be emailed to ${r.email}` : 'Signed (no email address – share the PDF)');
  };
  return (
    <Screen title={c.title} subtitle={`${c.name} · ${{ draft: 'not signed', employee_signed: 'employee signed', signed: 'signed by both', void: 'VOID' }[c.status]}`}>
      {pdfMode ? (
        <Card>
          <Text style={{ fontSize: 16, color: C.text }}>This is the company's own contract (PDF). {c.name}'s details are filled in where the admin placed them.</Text>
          <Btn testID="ct-read" title="Open the contract to read" icon="📖" size="md" variant="info" disabled={busy} onPress={() => run(() => readContractPdf(c.uid))} />
        </Card>
      ) : c.status === 'draft' && can('recruit_manage') ? (
        <>
          <Hint>Read it through with the new staff member. You can still change the wording for this person before they sign.</Hint>
          <Field testID="ct-body" label="Contract" value={body} onChangeText={setBody} multiline />
          {body !== c.body ? <Btn title="Save changes" size="sm" variant="secondary" onPress={() => act(() => PP.editContract(user, c.uid, body), 'Saved')} /> : null}
        </>
      ) : (
        <Card><ScrollView style={{ maxHeight: 420 }}><Text style={{ fontSize: 16, color: C.text, lineHeight: 24 }}>{c.body}</Text></ScrollView></Card>
      )}
      {emp ? <View><Label>Employee</Label><SignatureView data={emp} /><Text style={{ color: C.sub }}>{c.name} · {String(c.employee_signed_at).slice(0, 16)}</Text></View> : null}
      {er ? <View><Label>For Easy Buys</Label><SignatureView data={er} /><Text style={{ color: C.sub }}>{c.employer_name} · {String(c.employer_signed_at).slice(0, 16)}</Text></View> : null}
      {c.status === 'draft' ? (
        <Card>
          <H>{c.name} signs</H>
          <Chips value={agree ? 'y' : 'n'} onChange={(v) => setAgree(v === 'y')} testIDPrefix="ct-agree" options={[{ value: 'y', label: '☑ I have read and understood this contract and agree to it' }]} />
          <SignaturePad value={sig} onChange={setSig} testID="ct-sig" />
          <Btn testID="ct-sign-emp" title="Sign the contract" icon="✍️" variant="success" disabled={!agree || !sig} onPress={() => { if (act(() => PP.signContractEmployee(user, c.uid, sig), 'Signed')) setSig(null); }} />
        </Card>
      ) : null}
      {c.status === 'employee_signed' && can('contract_sign') ? (
        <Card>
          {pdfMode && cp.directorSigUid ? (
            <>
              <H>Approve for Easy Buys</H>
              <Hint>{`${cp.directorName || 'The director'}'s saved signature${cp.stampSigUid ? ' and the company stamp are' : ' is'} added to the PDF. Approving is recorded under your name (${user.name}).`}</Hint>
              <Btn testID="ct-approve" title="Approve – add director's signature & stamp" icon="✅" variant="success" disabled={busy} onPress={() => signEr(true)} />
              <Label>…or sign yourself instead</Label>
            </>
          ) : <H>Sign for Easy Buys ({user.name})</H>}
          <SignaturePad value={sig} onChange={setSig} testID="ct-sig2" />
          <Btn testID="ct-sign-er" title="Sign for the employer" icon="✍️" variant={pdfMode && cp.directorSigUid ? 'secondary' : 'success'} disabled={!sig || busy} onPress={() => signEr(false)} />
        </Card>
      ) : null}
      {busy ? <Banner tone="info" message="Please wait – making the PDF…" /> : null}
      {pdfMode && c.status === 'signed' ? (
        c.doc_uid ? (
          <Btn testID="ct-open-signed" title="Open / share the signed contract" icon="📄" size="md" variant="info" disabled={busy} onPress={() => run(() => openDocument(c.doc_uid))} />
        ) : <Btn testID="ct-finish" title="Make the signed PDF" icon="📄" size="md" variant="success" disabled={busy} onPress={finish} />
      ) : null}
      {!pdfMode ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Btn title="PDF" icon="📄" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => Promise.resolve().then(() => shareReport(PP.contractReport(c.uid), 'pdf')).catch((e) => ui.error(e))} />
          <Btn title="Print" icon="🖨️" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => printReport(PP.contractReport(c.uid)).catch((e) => ui.error(e))} />
        </View>
      ) : null}
      {c.status !== 'void' && can('contract_sign') ? <ReasonButton title="Void this contract" prompt="Why?" confirm="Void" onDo={(w) => act(() => PP.voidContract(user, c.uid, w), 'Voided')} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff sign for their pay
export function PaySignScreen({ params }) {
  const { user, can } = useApp();
  const act = useAct();
  const [who, setWho] = useState(null);
  const [sig, setSig] = useState(null);
  const [mode, setMode] = useState('signed');
  const [note, setNote] = useState('');
  const list = PP.signoffsFor(params.runUid);
  const signed = list.filter((x) => x.signoff && x.signoff.status === 'signed').length;
  const cur = who ? list.find((x) => x.line.user_uid === who) : null;
  if (cur) {
    const l = cur.line;
    return (
      <Screen title={`${l.name} – pay`} subtitle="Check your pay and sign" onBack={() => { setWho(null); setSig(null); setNote(''); setMode('signed'); }}>
        <Card>
          <Row label="Gross pay" value={$(l.gross)} />
          <Row label="FNPF (8%)" value={`− ${$(l.fnpf_employee)}`} />
          <Row label="PAYE tax" value={`− ${$(l.paye)}`} />
          {l.deductions.map((d, i) => <Row key={i} label={d.label} value={`− ${$(d.amount)}`} />)}
          <Row label={l.pay_method === 'bank' ? 'Paid into your bank' : 'Cash you receive'} value={$(l.net)} bold />
        </Card>
        <Chips value={mode} onChange={setMode} testIDPrefix="ps-mode" options={[{ value: 'signed', label: '✓ I received this and agree' }, { value: 'query', label: '✗ Something is wrong' }]} />
        {mode === 'signed' ? (
          <>
            <SignaturePad value={sig} onChange={setSig} testID="ps-sig" label={`${l.name}, sign here`} />
            <Btn testID="ps-sign" title={l.pay_method === 'bank' ? 'Sign' : `Sign – I received ${$(l.net)}`} icon="✍️" variant="success" disabled={!sig} onPress={() => { if (act(() => PP.signPay(user, { runUid: params.runUid, userUid: l.user_uid, signature: sig }), 'Signed – thank you')) { setWho(null); setSig(null); } }} />
          </>
        ) : (
          <>
            <Field testID="ps-note" label="What is wrong?" value={note} onChangeText={setNote} multiline />
            <SignaturePad value={sig} onChange={setSig} testID="ps-sig-q" label="Sign (optional)" />
            <Btn testID="ps-query" title="Send the query to the manager" variant="warn" onPress={() => { if (act(() => PP.signPay(user, { runUid: params.runUid, userUid: l.user_uid, signature: sig, status: 'query', note }), 'Sent to the manager')) { setWho(null); setSig(null); setNote(''); setMode('signed'); } }} />
          </>
        )}
      </Screen>
    );
  }
  const queries = list.filter((x) => x.signoff && x.signoff.status === 'query');
  return (
    <Screen title="Pay sign-off" subtitle={`${signed} of ${list.length} signed`}>
      <Explain>On pay day hand the tablet to each person: they check their payslip (hours, FNPF, tax and every deduction) and sign to say they received it. If something is wrong they tap "Something is wrong" and write why – the manager sees it. When everyone paid in cash at a shop has signed, the cash wages for that shop count as verified.</Explain>
      {queries.length && can('payroll_run') ? (
        <Section title="Queries">
          {queries.map((q) => <QueryCard key={q.signoff.uid} q={q.signoff} user={user} act={act} />)}
        </Section>
      ) : null}
      {list.map((x) => (
        <ListItem key={x.line.uid} testID={`ps-${x.line.employee_no || x.line.name}`} title={x.line.name} sub={`${x.line.pay_method === 'bank' ? 'bank' : 'cash'} · ${x.signoff ? `${x.signoff.status === 'signed' ? 'signed' : 'QUERY'} ${String(x.signoff.signed_at).slice(0, 16)}` : 'not signed yet'}`}
          right={$(x.line.net)} badge={x.signoff ? (x.signoff.status === 'signed' ? '✓' : '?') : null} badgeColor={x.signoff && x.signoff.status === 'signed' ? C.success : C.warn} onPress={() => setWho(x.line.user_uid)} />
      ))}
    </Screen>
  );
}
function QueryCard({ q, user, act }) {
  const [ans, setAns] = useState('');
  return (
    <Card tone="warn">
      <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{q.name}: {q.note}</Text>
      {q.answer ? <Text style={{ color: C.sub }}>Answered by {q.answered_by_name}: {q.answer}</Text> : (
        <>
          <Field label="Answer / what was done" value={ans} onChangeText={setAns} />
          <Btn title="Save answer" size="sm" variant="secondary" onPress={() => act(() => PP.answerQuery(user, q.uid, ans), 'Saved')} />
        </>
      )}
    </Card>
  );
}

// ---------------------------------------------------------------- settings
export function RecruitSetupScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const [s, setS] = useState(PP.peopleSettings());
  return (
    <Screen title="Recruitment & onboarding settings" subtitle="Admin" footer={<Btn testID="rs2-save" title="Save" icon="💾" variant="success" onPress={() => act(() => PP.savePeopleSettings(user, s), 'Saved')} />}>
      <Field label="Probation (months, 0 = none)" value={String(s.probationMonths)} onChangeText={(v) => setS({ ...s, probationMonths: v })} keyboardType="number-pad" />
      <Section title="Onboarding checklist">
        {s.checklist.map((x, i) => (
          <View key={x.key} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
            <View style={{ flex: 1 }}><Field label={x.auto ? 'Ticks itself' : `Item ${i + 1}`} value={x.label} onChangeText={(v) => setS({ ...s, checklist: s.checklist.map((y, k) => (k === i ? { ...y, label: v } : y)) })} /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setS({ ...s, checklist: s.checklist.filter((_, k) => k !== i) })} />
          </View>
        ))}
        <Btn title="+ Item" size="sm" variant="secondary" onPress={() => setS({ ...s, checklist: s.checklist.concat([{ key: `item${Date.now()}`, label: '' }]) })} />
      </Section>
      <Action testID="rs2-pdf" icon="📄" title="Company contract PDF" note="Use your own contract PDF: staff sign on the tablet, the director's signature and the company stamp are added by themselves." onPress={() => nav.push('ContractPdfSetup')} />
      <Section title="Standard contract (used when the company PDF is not switched on)">
        <Hint>These words are filled in for each person: {'{name} {employee_no} {job_title} {shop} {start_date} {pay} {pay_method} {normal_hours} {probation_months} {annual_leave} {sick_leave} {sick_photo_days} {fnpf_employee} {fnpf_employer} {employer}'}. Have a lawyer check the wording once.</Hint>
        <Field label="Title" value={s.contractTitle} onChangeText={(v) => setS({ ...s, contractTitle: v })} />
        <Field testID="rs2-body" label="Contract text" value={s.contractBody} onChangeText={(v) => setS({ ...s, contractBody: v })} multiline />
      </Section>
      <Section title="Emails to new staff">
        <Hint>Sent from the Google account the Easy Buys cloud runs on. Words like {'{first_name} {job_title} {shop} {start_date} {employer}'} are filled in.</Hint>
        <Field label="Welcome email – subject" value={s.welcomeSubject} onChangeText={(v) => setS({ ...s, welcomeSubject: v })} />
        <Field label="Welcome email – text (congratulations and documents to bring)" value={s.welcomeBody} onChangeText={(v) => setS({ ...s, welcomeBody: v })} multiline />
        <Field label="Signed contract email – text (the PDF is attached)" value={s.contractEmailBody} onChangeText={(v) => setS({ ...s, contractEmailBody: v })} multiline />
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- the company's own contract PDF (admin)
export function ContractPdfSetupScreen() {
  const { user, refresh } = useApp();
  const act = useAct();
  const ui = useUI();
  const cp = PP.contractPdfSettings();
  const [layout, setLayout] = useState(() => cleanLayout(cp.layout));
  const [dirName, setDirName] = useState(cp.directorName || '');
  const [dirSig, setDirSig] = useState(null);
  const [stampPics, setStampPics] = useState([]);
  const [busy, setBusy] = useState(false);
  const run = async (fn, msg) => { setBusy(true); try { await fn(); if (msg) ui.toast(msg); } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); } };
  const tpl = cp.templateDocUid ? getDocument(cp.templateDocUid) : null;
  const savedDir = PP.getSignature(cp.directorSigUid);
  const savedStamp = PP.getSignature(cp.stampSigUid);
  const setItem = (i, k, v) => setLayout({ ...layout, items: layout.items.map((x, n) => (n === i ? { ...x, [k]: v } : x)) });
  return (
    <Screen title="Company contract PDF" subtitle={cp.on ? 'In use for new contracts' : 'Not in use – the app\'s own contract text is used'}>
      <Explain>Upload the contract you already use (as a PDF). For each new staff member the app fills in their details, they sign on the tablet, and when a manager approves, the director's signature and the company stamp are added by themselves. The finished PDF is kept with the person's records, saved to Google Drive and emailed to them.</Explain>
      <Section title="1. The contract PDF">
        {tpl ? <Row label="Current file" value={tpl.name} /> : <Hint>No PDF uploaded yet.</Hint>}
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="cps-upload" title={tpl ? 'Upload a new version' : 'Upload the contract PDF'} icon="📂" size="md" variant="info" disabled={busy} style={{ flexGrow: 1 }}
            onPress={() => run(async () => { const f = await pickAnyFile({ pdfOnly: true }); if (f) await uploadContractTemplate(user, f); }, 'Contract PDF saved')} />
          {tpl ? <Btn title="Open" icon="📖" size="md" variant="secondary" disabled={busy} onPress={() => run(() => openDocument(tpl.uid))} /> : null}
        </View>
        <Hint>Earlier versions are kept (Documents). Contracts already made keep the version they were made with.</Hint>
      </Section>
      <Section title="2. Director's signature">
        {savedDir ? <View><SignatureView data={savedDir} /><Text style={{ color: C.sub }}>{cp.directorName}</Text></View> : <Hint>Not saved yet.</Hint>}
        <Field testID="cps-dir-name" label="Director's name (printed under the signature)" value={dirName} onChangeText={setDirName} />
        <SignaturePad value={dirSig} onChange={setDirSig} testID="cps-dir" label="Director signs here (once)" />
        <Btn testID="cps-dir-save" title="Save the director's signature" size="md" variant="success" disabled={!dirSig || !dirName.trim()} onPress={() => { if (act(() => saveDirectorSignature(user, dirSig, dirName.trim()), 'Saved')) setDirSig(null); }} />
      </Section>
      <Section title="3. Company stamp">
        {savedStamp ? <Image source={{ uri: savedStamp }} style={{ width: 140, height: 140, backgroundColor: '#fff' }} resizeMode="contain" /> : <Hint>Not saved yet.</Hint>}
        <Hint>Stamp it clearly on a clean white sheet of paper and take a close photo (fill the screen with the stamp). The white paper does not show on the contract.</Hint>
        <PhotoPicker testID="cps-stamp" value={stampPics} onChange={(v) => setStampPics(v.slice(-1))} label="Photo of the stamp" />
        <Btn testID="cps-stamp-save" title="Save the stamp" size="md" variant="success" disabled={!stampPics.length || busy} onPress={() => run(async () => { await saveStampPhoto(user, stampPics[0]); setStampPics([]); }, 'Stamp saved')} />
      </Section>
      <Section title="4. Where the signatures go">
        <Chips value={layout.signPage ? 'y' : 'n'} onChange={(v) => setLayout({ ...layout, signPage: v === 'y' })} testIDPrefix="cps-page" options={[{ value: 'y', label: 'Add a signing page at the end' }, { value: 'n', label: 'No extra page' }]} />
        <Chips value={layout.initialsEachPage ? 'y' : 'n'} onChange={(v) => setLayout({ ...layout, initialsEachPage: v === 'y' })} options={[{ value: 'y', label: 'Employee signs (small) on every page' }, { value: 'n', label: 'Not on every page' }]} />
        <Hint>To put a signature, the stamp or a detail (name, job, pay…) on the contract's own pages, add a place below. Across = % from the left edge, Down = % from the top, Width = % of the page width. Then tap Preview and adjust.</Hint>
        {layout.items.map((it, i) => (
          <Card key={i}>
            <Select label="What" value={it.what} onChange={(v) => setItem(i, 'what', v)} options={PLACE_WHAT.map(([value, label]) => ({ value, label }))} />
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              <View style={{ flexBasis: 90, flexGrow: 1 }}><Field label="Page (last = last)" value={String(it.page)} onChangeText={(v) => setItem(i, 'page', v.trim().toLowerCase() === 'last' ? 'last' : v)} /></View>
              <View style={{ flexBasis: 80, flexGrow: 1 }}><Field label="Across %" value={String(it.x)} onChangeText={(v) => setItem(i, 'x', v)} keyboardType="decimal-pad" /></View>
              <View style={{ flexBasis: 80, flexGrow: 1 }}><Field label="Down %" value={String(it.y)} onChangeText={(v) => setItem(i, 'y', v)} keyboardType="decimal-pad" /></View>
              <View style={{ flexBasis: 80, flexGrow: 1 }}><Field label="Width %" value={String(it.w)} onChangeText={(v) => setItem(i, 'w', v)} keyboardType="decimal-pad" /></View>
            </View>
            <Btn title="Remove" size="sm" variant="ghost" onPress={() => setLayout({ ...layout, items: layout.items.filter((_, n) => n !== i) })} />
          </Card>
        ))}
        <Btn testID="cps-add" title="+ Place something on the contract" size="sm" variant="secondary" onPress={() => setLayout({ ...layout, items: layout.items.concat([{ what: 'emp_sig', page: 'last', x: 10, y: 80, w: 25 }]) })} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <Btn testID="cps-save" title="Save places" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => PP.saveContractPdfSettings(user, { layout: cleanLayout(layout) }), 'Saved')} />
          <Btn testID="cps-preview" title="Preview" icon="👁️" size="md" variant="info" style={{ flexGrow: 1 }} disabled={!tpl || busy}
            onPress={() => run(async () => { PP.saveContractPdfSettings(user, { layout: cleanLayout(layout) }); await previewContractPdf(); })} />
        </View>
      </Section>
      <Section title="5. Use it">
        <Chips value={cp.on ? 'y' : 'n'} testIDPrefix="cps-on" onChange={(v) => act(() => PP.saveContractPdfSettings(user, { on: v === 'y' }), v === 'y' ? 'New contracts use the company PDF' : 'New contracts use the app text')}
          options={[{ value: 'y', label: 'Use the company PDF for new contracts' }, { value: 'n', label: 'Use the app\'s contract text' }]} />
        {!cp.directorSigUid || !cp.stampSigUid ? <Banner tone="warn" message="Save the director's signature and the stamp so they can be added by themselves." /> : null}
      </Section>
      {busy ? <Banner tone="info" message="Please wait…" /> : null}
    </Screen>
  );
}
