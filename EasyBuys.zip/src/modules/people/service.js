// Recruitment, onboarding, employment contracts (signed on the screen) and staff signing for their pay.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { saveUser, listUsers } from '../../services/catalog.js';
import { enqueue } from '../../services/stock.js';
import { saveProfile, payRules, employerPctOn } from '../payroll/service.js';
import { needReason, requireSetup } from '../../services/access.js';
import { requirePerm, requireLogin, requireShop, shopOf, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
export const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);

export const PEOPLE_SQL = `
CREATE TABLE IF NOT EXISTS job_openings (
  uid TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  shop_code TEXT,
  pay_type TEXT, rate REAL, hours TEXT,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  opened_at TEXT, closed_at TEXT, by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS applicants (
  uid TEXT PRIMARY KEY,
  opening_uid TEXT,
  name TEXT NOT NULL,
  phone TEXT, email TEXT, address TEXT,
  applied_date TEXT NOT NULL,
  stage TEXT NOT NULL DEFAULT 'applied',
  interview_at TEXT,
  score INTEGER,
  notes TEXT,
  source TEXT,
  photo_urls TEXT,
  hired_user_uid TEXT,
  reject_reason TEXT,
  by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS onboarding (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  email TEXT,
  start_date TEXT NOT NULL,
  probation_end TEXT,
  items TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  probation_result TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS signatures (
  uid TEXT PRIMARY KEY,
  data TEXT NOT NULL,
  signer_name TEXT,
  signed_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS contracts (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  start_date TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  employee_sig_uid TEXT, employee_signed_at TEXT,
  employer_sig_uid TEXT, employer_name TEXT, employer_signed_at TEXT,
  void_reason TEXT,
  created_by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS pay_signoffs (
  uid TEXT PRIMARY KEY,
  run_uid TEXT NOT NULL,
  user_uid TEXT NOT NULL,
  name TEXT,
  net REAL,
  status TEXT NOT NULL,
  note TEXT,
  sig_uid TEXT,
  signed_at TEXT,
  witness_name TEXT,
  answered_by_name TEXT, answer TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const PEOPLE_SYNC = {
  job_openings: SYNC('uid', 'Recruitment', ['uid', 'title', 'shop_code', 'pay_type', 'rate', 'hours', 'description', 'status', 'opened_at', 'closed_at', 'by_name']),
  applicants: SYNC('uid', 'Recruitment', ['uid', 'opening_uid', 'name', 'phone', 'email', 'address', 'applied_date', 'stage', 'interview_at', 'score', 'notes', 'source', 'photo_urls', 'hired_user_uid', 'reject_reason', 'by_name']),
  onboarding: SYNC('uid', 'Recruitment', ['uid', 'user_uid', 'email', 'start_date', 'probation_end', 'items', 'status', 'probation_result']),
  signatures: SYNC('uid', 'Recruitment', ['uid', 'data', 'signer_name', 'signed_at']),
  contracts: SYNC('uid', 'Recruitment', ['uid', 'user_uid', 'title', 'body', 'start_date', 'status', 'employee_sig_uid', 'employee_signed_at', 'employer_sig_uid', 'employer_name', 'employer_signed_at', 'void_reason', 'created_by_name', 'created_at', 'mode', 'template_doc_uid', 'doc_uid']),
  pay_signoffs: SYNC('uid', 'Payroll', ['uid', 'run_uid', 'user_uid', 'name', 'net', 'status', 'note', 'sig_uid', 'signed_at', 'witness_name', 'answered_by_name', 'answer']),
};

// ---------------------------------------------------------------- settings
export const PEOPLE_DEFAULTS = {
  probationMonths: 3,
  checklist: [
    { key: 'details', label: 'Address, phone and next of kin written down' },
    { key: 'id', label: 'Photo of ID (birth certificate, passport, voter ID or driving licence)' },
    { key: 'tin', label: 'TIN number', auto: 'tin' },
    { key: 'fnpf', label: 'FNPF number', auto: 'fnpf' },
    { key: 'pay', label: 'Pay rate and cash / bank set in Payroll', auto: 'pay' },
    { key: 'bank', label: 'Bank account (if paid by bank)' },
    { key: 'contract', label: 'Employment contract signed', auto: 'contract' },
    { key: 'pin', label: 'Time Clock PIN given', auto: 'pin' },
    { key: 'face', label: 'Face enrolled for the Time Clock', auto: 'face' },
    { key: 'uniform', label: 'Uniform / name badge given' },
    { key: 'induction', label: 'Induction: shop rules, safety, fire exits' },
    { key: 'till', label: 'Till and cash rules explained (shortages are deducted)' },
  ],
  welcomeSubject: 'Welcome to Easy Buys, {first_name}!',
  welcomeBody: `Bula {first_name},

Congratulations and welcome to the Easy Buys team! You start as {job_title} at {shop} on {start_date}.

Please bring (or send a photo of) these documents before or on your first day:
• Your ID (birth certificate, passport, voter ID or driving licence)
• Your TIN letter or card (FRCS)
• Your FNPF number / card
• Your bank account details (if you want your pay into the bank)
• Your address, phone number and the name and phone number of your next of kin

Your employment contract will be ready for you to sign on your first day. If you have any questions, call us.

We look forward to working with you.
{employer}`,
  contractEmailBody: `Bula {first_name},

Thank you for signing your employment contract with {employer}. A copy is attached for you to keep.

{employer}`,
  contractTitle: 'Contract of Employment',
  contractBody: `This contract is between {employer} ("the Employer") and {name} ("the Employee"), employee number {employee_no}.

1. Job: The Employee is employed as {job_title} at {shop}, starting on {start_date}. The Employee may be asked to work at any Easy Buys shop.

2. Probation: The first {probation_months} months are a probation period. During probation either side may end this contract with one week's notice.

3. Hours: Normal hours are up to {normal_hours} hours a week, Saturday to Friday, as shown on the roster. Overtime, Sundays and public holidays are paid as set out in the Employment Relations Act 2007 and the wage regulations in force.

4. Pay: {pay}. Pay is weekly, on Saturday, for the week Saturday to Friday, {pay_method}. PAYE tax and FNPF (employee {fnpf_employee}%) are deducted; the Employer adds the employer FNPF contribution ({fnpf_employer}%).

5. Deductions: Advances, staff loans, and cash shortages or breakages that are the Employee's responsibility (after they have been explained to the Employee) may be deducted from pay as agreed in writing. Every deduction is shown on the payslip, which the Employee signs to confirm.

6. Time Clock: The Employee must clock in and out (and for breaks) on the Time Clock. Hours are paid from the Time Clock records as checked by the manager.

7. Leave: Annual leave of {annual_leave} days a year after 12 months' service, sick leave of {sick_leave} days a year (a medical certificate is needed for more than {sick_photo_days} days), and other leave as provided by law.

8. Conduct: The Employee will follow the shop rules, cash-handling rules and lawful instructions, and keep the business's information confidential.

9. Ending the contract: After probation, notice is as provided by the Employment Relations Act 2007 (at least one pay period), except for serious misconduct.

Signed electronically on the Easy Buys app.`,
};
export function peopleSettings() { const s = getShared('people_settings', {}) || {}; return { ...PEOPLE_DEFAULTS, ...s }; }
export function savePeopleSettings(user, s) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'recruit_manage');
  const list = (s.checklist || []).map((x, i) => ({ key: txt(x.key) || `item${i}`, label: txt(x.label), auto: x.auto || undefined })).filter((x) => x.label);
  need(list.length, 'Keep at least one checklist item.');
  need(txt(s.contractBody), 'The contract text cannot be empty.');
  const clean = { probationMonths: Math.max(0, Math.min(12, Math.round(Number(s.probationMonths) || 0))), checklist: list, contractTitle: txt(s.contractTitle) || PEOPLE_DEFAULTS.contractTitle, contractBody: String(s.contractBody),
    welcomeSubject: txt(s.welcomeSubject) || PEOPLE_DEFAULTS.welcomeSubject, welcomeBody: String(s.welcomeBody || PEOPLE_DEFAULTS.welcomeBody), contractEmailBody: String(s.contractEmailBody || PEOPLE_DEFAULTS.contractEmailBody) };
  setShared('people_settings', clean);
  audit({ user, action: 'Changed recruitment, onboarding and contract settings', table: 'shared_settings', recordUid: 'people_settings' });
  return clean;
  });
}

// ---------------------------------------------------------------- vacancies & applicants
export const STAGES = { applied: 'Applied', shortlisted: 'Shortlisted', interview: 'Interview', offer: 'Offer made', hired: 'Hired', rejected: 'Not suitable', withdrawn: 'Withdrew' };
export function saveOpening(user, o) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, o && (o.shopCode || o.shop_code || shopOf('job_openings', o.uid))); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(txt(o.title), 'Enter the job title, e.g. "Cashier".');
  const uid = o.uid || uuid('JO');
  const { now, dev } = meta();
  db().run(`INSERT INTO job_openings (uid, title, shop_code, pay_type, rate, hours, description, status, opened_at, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET title=excluded.title, shop_code=excluded.shop_code, pay_type=excluded.pay_type, rate=excluded.rate, hours=excluded.hours, description=excluded.description, status=excluded.status,
    updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, txt(o.title), txt(o.shopCode) || null, o.payType === 'salary' ? 'salary' : 'hourly', Number(o.rate) || null, txt(o.hours) || null, txt(o.description) || null, o.status === 'closed' ? 'closed' : 'open', dateStr(), user.name, now, dev]);
  audit({ user, action: `Vacancy ${txt(o.title)} ${txt(o.shopCode)}`, table: 'job_openings', recordUid: uid });
  return uid;
  });
}
export function listOpenings({ all = false } = {}) {
  return db().all(`SELECT o.*, (SELECT COUNT(*) FROM applicants a WHERE a.opening_uid = o.uid AND a.stage NOT IN ('rejected','withdrawn','hired')) AS active,
    (SELECT COUNT(*) FROM applicants a WHERE a.opening_uid = o.uid) AS total FROM job_openings o WHERE (? = 1 OR o.status = 'open') ORDER BY o.opened_at DESC`, [all ? 1 : 0]);
}
export function saveApplicant(user, a, { photos = [] } = {}) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(a.name), 'Enter the applicant\'s name.');
  need(txt(a.phone) || txt(a.email), 'Enter a phone number (or email) to contact them.');
  const before = a.uid ? getApplicant(a.uid) : null;
  const uid = a.uid || uuid('AP');
  const stage = STAGES[a.stage] ? a.stage : (before ? before.stage : 'applied');
  if (stage === 'rejected' && !(before && before.reject_reason)) needReason(user, a.rejectReason, 'Say why they are not suitable (kept for fairness).');
  need(stage !== 'hired' || (before && before.hired_user_uid), 'Use "Hire" to take someone on – it makes their staff login.');
  const score = a.score === '' || a.score === undefined || a.score === null ? null : Math.max(0, Math.min(10, Math.round(Number(a.score))));
  const { now, dev } = meta();
  db().run(`INSERT INTO applicants (uid, opening_uid, name, phone, email, address, applied_date, stage, interview_at, score, notes, source, photo_urls, reject_reason, by_name, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?, '[]', ?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET opening_uid=excluded.opening_uid, name=excluded.name, phone=excluded.phone, email=excluded.email, address=excluded.address, stage=excluded.stage, interview_at=excluded.interview_at,
    score=excluded.score, notes=excluded.notes, source=excluded.source, reject_reason=excluded.reject_reason, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, a.openingUid || null, txt(a.name), txt(a.phone) || null, txt(a.email) || null, txt(a.address) || null, txt(a.appliedDate) || (before ? before.applied_date : dateStr()), stage, txt(a.interviewAt) || null,
    score, txt(a.notes) || null, txt(a.source) || null, txt(a.rejectReason) || (before ? before.reject_reason : null), user.name, now, dev]);
  if (photos.length) addPhotos('applicant', uid, photos);
  if (!before || before.stage !== stage) audit({ user, action: `Applicant ${txt(a.name)}: ${STAGES[stage]}`, table: 'applicants', recordUid: uid, reason: txt(a.rejectReason) || null });
  return uid;
  });
}
export function getApplicant(uid) { const a = db().get('SELECT * FROM applicants WHERE uid = ?', [uid]); return a && { ...a, photos: J(a.photo_urls, []) }; }
export function listApplicants({ openingUid, stage, active = false } = {}) {
  return db().all(`SELECT a.*, o.title AS job FROM applicants a LEFT JOIN job_openings o ON o.uid = a.opening_uid WHERE (? IS NULL OR a.opening_uid = ?) AND (? IS NULL OR a.stage = ?)
    AND (? = 0 OR a.stage NOT IN ('rejected','withdrawn','hired')) ORDER BY a.applied_date DESC`, [openingUid || null, openingUid || null, stage || null, stage || null, active ? 1 : 0]);
}
function nextEmployeeNo() {
  const nums = db().all("SELECT employee_no AS e FROM users WHERE employee_no LIKE 'EB%'").map((r) => Number(String(r.e).replace(/\D/g, ''))).filter(Boolean);
  return `EB${String((nums.length ? Math.max(...nums) : 0) + 1).padStart(3, '0')}`;
}
function freePin() {
  for (let i = 0; i < 200; i += 1) {
    const p = String(1000 + Math.floor(Math.random() * 9000));
    if (!db().get('SELECT 1 AS x FROM users WHERE pin = ? AND active = 1', [p]) && !require('../../services/pins.js').pinTaken(p)) return p;
  }
  throw new AppError('Could not find a free PIN. Set one by hand in Staff.');
}
// Hire: makes the staff login (with a new PIN shown once), starts pay details and the onboarding checklist.
export function hire(user, applicantUid, { shopCode, role = 'staff', startDate, rate, payType = 'hourly', jobTitle, email, sendWelcome = true } = {}) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopCode); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const a = getApplicant(applicantUid);
  need(a, 'Applicant not found.');
  need(!a.hired_user_uid, 'Already hired.');
  const o = a.opening_uid ? db().get('SELECT * FROM job_openings WHERE uid = ?', [a.opening_uid]) : null;
  const shop = txt(shopCode) || (o && o.shop_code);
  need(shop, 'Choose the shop.');
  const start = txt(startDate) || dateStr();
  const pin = freePin();
  const employeeNo = nextEmployeeNo();
  const u = saveUser({ name: a.name, pin, role, employeeNo, shopCode: shop, phone: a.phone || undefined }, user, { hire: true });
  const r = Number(rate) || (o && o.rate) || 0;
  if (has('pay_profiles') && r > 0) {
    try {
      saveProfile(user, { userUid: u.uid, payType, rate: payType === 'salary' ? 0 : r, weeklySalary: payType === 'salary' ? r : 0, jobTitle: txt(jobTitle) || (o && o.title) || '', payMethod: 'cash', startDate: start });
    } catch (e) { /* pay details can be finished in Payroll */ }
  }
  const mail = txt(email) || a.email || '';
  startOnboarding(user, u.uid, start, { email: mail, sendWelcome });
  const { now, dev } = meta();
  db().run(`UPDATE applicants SET stage = 'hired', hired_user_uid = ?, ${SYNCED} WHERE uid = ?`, [u.uid, now, dev, applicantUid]);
  audit({ user, action: `Hired ${a.name} (${employeeNo}) for ${shop}, starting ${start}`, table: 'applicants', recordUid: applicantUid });
  return { user: u, pin, employeeNo };
  });
}

// ---------------------------------------------------------------- onboarding
const addMonths = (d, n) => {
  const [y, m, dd] = d.split('-').map(Number);
  const last = new Date(y, m - 1 + n + 1, 0).getDate(); // 31 Aug + 3 months = 30 Nov, not 1 Dec
  return dateStr(new Date(y, m - 1 + n, Math.min(dd, last)));
};
const isEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '').trim());
export function startOnboarding(user, userUid, startDate = dateStr(), { email, sendWelcome = true } = {}) {
  const uid = `OB-${userUid}`;
  const s = peopleSettings();
  const { now, dev } = meta();
  db().run(`INSERT OR IGNORE INTO onboarding (uid, user_uid, email, start_date, probation_end, items, status, updated_at, updated_device) VALUES (?,?,?,?,?, '{}', 'open', ?,?)`,
    [uid, userUid, txt(email) || null, startDate, s.probationMonths ? addMonths(startDate, s.probationMonths) : null, now, dev]);
  if (sendWelcome && isEmail(email)) sendWelcomeEmail(user, userUid);
  return uid;
}
const firstName = (n) => String(n || '').split(' ')[0];
// Congratulations and the list of documents to bring – sent through the Easy Buys cloud (Gmail of the cloud account) when online.
export function sendWelcomeEmail(user, userUid) {
  const o = db().get('SELECT * FROM onboarding WHERE user_uid = ?', [userUid]);
  need(o && isEmail(o.email), 'Add the person\'s email address first.');
  const s = peopleSettings();
  const f = { ...contractFields(userUid, o.start_date), first_name: firstName(db().get('SELECT name FROM users WHERE uid = ?', [userUid]).name) };
  enqueue('email', { to: o.email, subject: fillTemplate(s.welcomeSubject, f), text: fillTemplate(s.welcomeBody, f) });
  audit({ user, action: `Welcome email queued to ${o.email}`, table: 'onboarding', recordUid: o.uid });
  return o.email;
}
export function setOnboardingEmail(user, userUid, email) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(isEmail(email), 'Enter a proper email address.');
  const { now, dev } = meta();
  db().run(`UPDATE onboarding SET email = ?, ${SYNCED} WHERE user_uid = ?`, [txt(email), now, dev, userUid]);
  });
}
function autoDone(key, userUid) {
  try {
    const p = has('pay_profiles') ? db().get('SELECT * FROM pay_profiles WHERE user_uid = ?', [userUid]) : null;
    if (key === 'tin') return !!(p && p.tin);
    if (key === 'fnpf') return !!(p && p.fnpf_no);
    if (key === 'pay') return !!(p && (p.rate > 0 || p.weekly_salary > 0));
    if (key === 'contract') return !!db().get("SELECT 1 AS x FROM contracts WHERE user_uid = ? AND status = 'signed'", [userUid]);
    if (key === 'pin') return !!db().get('SELECT 1 AS x FROM users WHERE uid = ? AND pin IS NOT NULL', [userUid]);
    if (key === 'face') return !!db().get("SELECT 1 AS x FROM users WHERE uid = ? AND face IS NOT NULL AND face <> ''", [userUid]);
  } catch (e) { return false; }
  return false;
}
export function getOnboarding(userUid) {
  const o = db().get('SELECT * FROM onboarding WHERE user_uid = ?', [userUid]);
  if (!o) return null;
  const items = J(o.items, {});
  const list = peopleSettings().checklist.map((c) => {
    const tick = items[c.key];
    const auto = c.auto ? autoDone(c.auto, userUid) : false;
    return { ...c, done: auto || !!tick, by: tick ? tick.by : auto ? 'set in the app' : null, at: tick ? tick.at : null };
  });
  const u = db().get('SELECT name, shop_code, employee_no FROM users WHERE uid = ?', [userUid]);
  return { ...o, user: u, list, done: list.filter((x) => x.done).length, total: list.length, complete: list.every((x) => x.done) };
}
export function tickOnboarding(user, userUid, key, on = true) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const o = db().get('SELECT * FROM onboarding WHERE user_uid = ?', [userUid]);
  need(o, 'Onboarding not started.');
  const items = J(o.items, {});
  if (on) items[key] = { by: user.name, at: stamp() }; else delete items[key];
  const { now, dev } = meta();
  db().run(`UPDATE onboarding SET items = ?, ${SYNCED} WHERE uid = ?`, [JSON.stringify(items), now, dev, o.uid]);
  const g = getOnboarding(userUid);
  if (g.complete && o.status === 'open') db().run(`UPDATE onboarding SET status = 'done', ${SYNCED} WHERE uid = ?`, [now, dev, o.uid]);
  });
}
export function probationDecision(user, userUid, result, note) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(['passed', 'extended', 'ended'].includes(result), 'Choose the result.');
  const o = db().get('SELECT * FROM onboarding WHERE user_uid = ?', [userUid]);
  need(o, 'Not found.');
  const { now, dev } = meta();
  const ext = result === 'extended' ? addMonths(o.probation_end || dateStr(), 1) : o.probation_end;
  db().run(`UPDATE onboarding SET probation_result = ?, probation_end = ?, ${SYNCED} WHERE uid = ?`, [`${result}${txt(note) ? `: ${txt(note)}` : ''} (${user.name} ${dateStr()})`, ext, now, dev, o.uid]);
  audit({ user, action: `Probation ${result}`, table: 'onboarding', recordUid: o.uid, reason: txt(note) || null });
  });
}
export function listOnboarding({ open = true } = {}) {
  return db().all(`SELECT user_uid FROM onboarding WHERE (? = 0 OR status = 'open' OR (probation_result IS NULL AND probation_end IS NOT NULL)) ORDER BY start_date DESC`, [open ? 1 : 0]).map((r) => getOnboarding(r.user_uid)).filter(Boolean);
}
export function peopleAlerts(today = dateStr()) {
  const list = listOnboarding();
  return {
    probationDue: list.filter((o) => o.probation_end && !o.probation_result && o.probation_end <= addDays(today, 14)),
    unfinished: list.filter((o) => !o.complete && o.start_date <= addDays(today, -7)),
    queries: has('pay_signoffs') ? db().all("SELECT * FROM pay_signoffs WHERE status = 'query' AND answer IS NULL").length : 0,
  };
}

// ---------------------------------------------------------------- signatures & contracts
export function saveSignature(data, signerName) {
  need(data && /^data:image\/(png|jpeg);base64,/.test(data), 'Please sign first.');
  need(data.length < 45000, 'The signature is too big – clear it and sign again a bit smaller.');
  const uid = uuid('SG');
  const { now, dev } = meta();
  db().run('INSERT INTO signatures (uid, data, signer_name, signed_at, updated_at, updated_device) VALUES (?,?,?,?,?,?)', [uid, data, signerName || null, now, now, dev]);
  return uid;
}
export function getSignature(uid) { const s = uid ? db().get('SELECT * FROM signatures WHERE uid = ?', [uid]) : null; return s ? s.data : null; }

export function contractFields(userUid, startDate) {
  const u = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  need(u, 'Staff member not found.');
  const p = has('pay_profiles') ? db().get('SELECT * FROM pay_profiles WHERE user_uid = ?', [userUid]) : null;
  const shop = db().get('SELECT name FROM shops WHERE code = ?', [u.shop_code || '']);
  const s = peopleSettings();
  let lt = { annual: 10, sick: 10 };
  try { const rows = db().all('SELECT code, default_days FROM leave_types'); lt = { annual: (rows.find((r) => r.code === 'ANNUAL') || {}).default_days || 10, sick: (rows.find((r) => r.code === 'SICK') || {}).default_days || 10 }; } catch (e) { /* defaults */ }
  let sickDays = 2;
  try { sickDays = (getShared('leave_rules', {}) || {}).sickPhotoAfterDays ?? 2; } catch (e) { /* default */ }
  let tplName = 'Easy Buys Shopping Centre';
  try { tplName = (getShared('report_template', {}) || {}).businessName || tplName; } catch (e) { /* default */ }
  const pay = p ? (p.pay_type === 'salary' ? `${$(p.weekly_salary)} a week (salary)` : `${$(p.rate)} an hour`) : 'as agreed in writing';
  return {
    employer: tplName, name: u.name, employee_no: u.employee_no || '', job_title: (p && p.job_title) || 'Shop assistant', shop: shop ? shop.name : (u.shop_code || ''),
    start_date: txt(startDate) || (p && p.start_date) || dateStr(), probation_months: String(s.probationMonths), normal_hours: String((p && p.normal_hours) || 48), pay,
    pay_method: p && p.pay_method === 'bank' ? `paid into the Employee's bank account${p.bank_name ? ` (${p.bank_name})` : ''}` : 'paid in cash against the Employee\'s signature',
    annual_leave: String(lt.annual), sick_leave: String(lt.sick), sick_photo_days: String(sickDays),
    fnpf_employee: String(fnpfPct('fnpfEmployeePct', 8)), fnpf_employer: String((() => { try { return employerPctOn(payRules(), dateStr()); } catch (e) { return fnpfPct('fnpfEmployerPct', 10); } })()),
  };
}
function fnpfPct(k, d) { try { const v = Number(payRules()[k]); return Number.isFinite(v) ? v : d; } catch (e) { return d; } }
export const fillTemplate = (text, f) => String(text).replace(/\{(\w+)\}/g, (m, k) => (f[k] !== undefined ? f[k] : m));
export function makeContract(user, userUid, { startDate } = {}) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const live = db().get("SELECT uid FROM contracts WHERE user_uid = ? AND status IN ('draft','employee_signed')", [userUid]);
  need(!live, 'This person already has a contract waiting to be signed.');
  const s = peopleSettings();
  const cp = contractPdfSettings();
  const f = contractFields(userUid, startDate);
  const uid = uuid('CT');
  const { now, dev } = meta();
  if (cp.on) need(cp.templateDocUid, 'Upload the company contract PDF first (Admin › Recruitment & onboarding › Company contract PDF).');
  db().run(`INSERT INTO contracts (uid, user_uid, title, body, start_date, status, created_by_name, created_at, updated_at, updated_device, mode, template_doc_uid) VALUES (?,?,?,?,?, 'draft', ?,?,?,?,?,?)`,
    [uid, userUid, s.contractTitle, cp.on ? `The company contract (${cp.templateName || 'PDF'}). Open it to read it before signing.` : fillTemplate(s.contractBody, f), f.start_date, user.name, now, now, dev,
      cp.on ? 'pdf' : 'text', cp.on ? cp.templateDocUid : null]);
  audit({ user, action: `Contract made for ${f.name}`, table: 'contracts', recordUid: uid });
  return uid;
  });
}
export function getContract(uid) { return db().get('SELECT c.*, u.name FROM contracts c LEFT JOIN users u ON u.uid = c.user_uid WHERE c.uid = ?', [uid]); }
export function contractsFor(userUid) { return db().all('SELECT * FROM contracts WHERE user_uid = ? ORDER BY created_at DESC', [userUid]); }
// The text can still be changed until the employee signs.
export function editContract(user, uid, body) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getContract(uid);
  need(c && c.status === 'draft', 'A contract cannot be changed after it is signed. Void it and make a new one.');
  need(txt(body), 'The contract text cannot be empty.');
  const { now, dev } = meta();
  db().run(`UPDATE contracts SET body = ?, ${SYNCED} WHERE uid = ?`, [String(body), now, dev, uid]);
  });
}
export function signContractEmployee(user, uid, signature) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getContract(uid);
  need(c && c.status === 'draft', 'This contract is not waiting for the employee to sign.');
  const sig = saveSignature(signature, c.name);
  const { now, dev } = meta();
  db().run(`UPDATE contracts SET status = 'employee_signed', employee_sig_uid = ?, employee_signed_at = ?, ${SYNCED} WHERE uid = ?`, [sig, now, now, dev, uid]);
  audit({ user, action: `${c.name} signed the contract`, table: 'contracts', recordUid: uid });
  });
}
export function signContractEmployer(user, uid, signature, { useDirector = false } = {}) {
  requirePerm(user, 'contract_sign'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getContract(uid);
  need(c && c.status === 'employee_signed', c && c.status === 'draft' ? 'The employee signs first.' : 'This contract is not waiting for the employer to sign.');
  const cp = contractPdfSettings();
  // The director's saved signature is added by itself when a person allowed to sign contracts approves it.
  const director = useDirector && cp.directorSigUid && getSignature(cp.directorSigUid);
  need(director || signature, useDirector ? 'Save the director\'s signature first (Admin › Recruitment & onboarding › Company contract PDF).' : 'Please sign first.');
  const sig = director ? cp.directorSigUid : saveSignature(signature, user.name);
  const signer = director ? (cp.directorName || user.name) : user.name;
  const { now, dev } = meta();
  db().run(`UPDATE contracts SET status = 'signed', employer_sig_uid = ?, employer_name = ?, employer_signed_at = ?, ${SYNCED} WHERE uid = ?`, [sig, signer, now, now, dev, uid]);
  audit({ user, action: `Contract of ${c.name} signed for the employer${director ? ` (director's signature added, approved by ${user.name})` : ''}`, table: 'contracts', recordUid: uid });
  // The company PDF is finished (signatures and stamp put on it) by the screen, which then sends the email.
  if (c.mode === 'pdf') return { email: contractEmailTo(c.user_uid), pdf: true };
  // A copy goes to the employee by email (PDF attached) when there is an email address.
  const o = db().get('SELECT email FROM onboarding WHERE user_uid = ?', [c.user_uid]);
  if (o && isEmail(o.email)) {
    const s = peopleSettings();
    const f = { ...contractFields(c.user_uid, c.start_date), first_name: firstName(c.name) };
    enqueue('contract_email', { contractUid: uid, to: o.email, subject: `${c.title} – ${f.employer}`, text: fillTemplate(s.contractEmailBody, f) });
    return { email: o.email };
  }
  return { email: null };
  });
}
function contractEmailTo(userUid) { const o = db().get('SELECT email FROM onboarding WHERE user_uid = ?', [userUid]); return o && isEmail(o.email) ? o.email : null; }
// After the signed company PDF is made: keep it with the contract and email it to the employee.
export function attachSignedContract(user, uid, docUid) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getContract(uid);
  need(c, 'Contract not found.');
  const { now, dev } = meta();
  db().run(`UPDATE contracts SET doc_uid = ?, ${SYNCED} WHERE uid = ?`, [docUid, now, dev, uid]);
  const to = contractEmailTo(c.user_uid);
  if (to) {
    const s = peopleSettings();
    const f = { ...contractFields(c.user_uid, c.start_date), first_name: firstName(c.name) };
    enqueue('contract_email', { contractUid: uid, docUid, to, subject: `${c.title} – ${f.employer}`, text: fillTemplate(s.contractEmailBody, f) });
  }
  return { email: to };
  });
}

// ---------------------------------------------------------------- the company's own contract PDF
export const CONTRACT_PDF_DEFAULTS = { on: false, templateDocUid: null, templateName: '', layout: null, directorName: '', directorSigUid: null, stampSigUid: null };
export function contractPdfSettings() { return { ...CONTRACT_PDF_DEFAULTS, ...(getShared('contract_pdf', {}) || {}) }; }
export function saveContractPdfSettings(user, s) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  requireSetup(user, 'recruit_manage');
  const cur = contractPdfSettings();
  const next = { ...cur, ...s };
  if (next.on) need(next.templateDocUid, 'Upload the company contract PDF first.');
  next.directorName = txt(next.directorName);
  setShared('contract_pdf', next);
  audit({ user, action: 'Changed the company contract PDF settings', table: 'shared_settings', recordUid: 'contract_pdf' });
  return next;
  });
}
// Everything needed to put on the PDF (the platform layer does the drawing).
export function contractPdfData(uid, { sample = false } = {}) {
  const cp = contractPdfSettings();
  if (sample) {
    return { name: 'Sample Employee', employer: contractEmployer(), job_title: 'Shop assistant', start_date: dateStr(), pay: '$5.60 an hour', shop: 'Shop 1', employee_no: 'EB000',
      contractNo: 'SAMPLE', empSig: null, empAt: stamp(), dirSig: getSignature(cp.directorSigUid), dirName: cp.directorName, dirAt: stamp(), stamp: getSignature(cp.stampSigUid) };
  }
  const c = getContract(uid);
  need(c, 'Contract not found.');
  const f = contractFields(c.user_uid, c.start_date);
  const signed = c.status === 'signed';
  return { name: c.name, employer: f.employer, job_title: f.job_title, start_date: f.start_date, pay: f.pay, shop: f.shop, employee_no: f.employee_no, contractNo: c.uid,
    empSig: getSignature(c.employee_sig_uid), empAt: c.employee_signed_at, dirSig: signed ? getSignature(c.employer_sig_uid) : null, dirName: signed ? c.employer_name : '', dirAt: c.employer_signed_at,
    stamp: signed ? getSignature(cp.stampSigUid) : null, templateDocUid: c.template_doc_uid || cp.templateDocUid, layout: cp.layout };
}
function contractEmployer() { try { return (getShared('report_template', {}) || {}).businessName || 'Easy Buys Shopping Centre'; } catch (e) { return 'Easy Buys Shopping Centre'; } }

export function voidContract(user, uid, reason) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const c = getContract(uid);
  need(c && c.status !== 'void', 'Not found.');
  needReason(user, reason, 'Say why.');
  const { now, dev } = meta();
  db().run(`UPDATE contracts SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason), now, dev, uid]);
  audit({ user, action: `Contract of ${c.name} voided`, table: 'contracts', recordUid: uid, reason: txt(reason) });
  });
}
export function contractReport(uid) {
  const c = getContract(uid);
  const emp = getSignature(c.employee_sig_uid);
  const er = getSignature(c.employer_sig_uid);
  return {
    kind: 'contract', title: c.title, fileName: `Contract-${(c.name || '').replace(/\s+/g, '-')}`, subtitle: `${c.name} · starting ${c.start_date || ''}`,
    info: [['Status', { draft: 'Not signed', employee_signed: 'Signed by the employee', signed: 'Signed by both', void: 'VOID' }[c.status]], ['Employee signed', c.employee_signed_at ? c.employee_signed_at.slice(0, 16) : '—'],
      ['Employer signed', c.employer_signed_at ? `${c.employer_name} ${c.employer_signed_at.slice(0, 16)}` : '—']],
    sections: [{ title: 'Contract', columns: [{ key: 't', title: '', align: 'left' }], rows: String(c.body).split(/\n\n+/).map((p) => ({ t: p })) }],
    signatures: [{ label: `Employee: ${c.name}`, data: emp, at: c.employee_signed_at }, { label: `For the employer: ${c.employer_name || ''}`, data: er, at: c.employer_signed_at }],
  };
}

// ---------------------------------------------------------------- staff sign for their pay
export function signoffsFor(runUid) {
  const lines = db().all('SELECT * FROM pay_lines WHERE run_uid = ? AND include = 1 ORDER BY name', [runUid]);
  const so = Object.fromEntries(db().all('SELECT * FROM pay_signoffs WHERE run_uid = ?', [runUid]).map((s) => [s.user_uid, s]));
  return lines.map((l) => ({ line: { ...l, deductions: J(l.deductions, []) }, signoff: so[l.user_uid] || null }));
}
// status: 'signed' (received and agree) | 'query' (does not agree – note required)
export function signPay(byUser, { runUid, userUid, signature, status = 'signed', note, witness }) {
  requireLogin(byUser); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const run = db().get('SELECT * FROM pay_runs WHERE uid = ?', [runUid]);
  need(run && run.status === 'final', 'Staff sign once the pay run is final.');
  const l = db().get('SELECT * FROM pay_lines WHERE run_uid = ? AND user_uid = ? AND include = 1', [runUid, userUid]);
  need(l, 'This person is not in the pay run.');
  if (status === 'query') need(txt(note), 'Write what is wrong with the pay.');
  const sig = signature ? saveSignature(signature, l.name) : null;
  if (status === 'signed') need(sig, 'Please sign.');
  const uid = `${runUid}|${userUid}`;
  const { now, dev } = meta();
  db().run(`INSERT INTO pay_signoffs (uid, run_uid, user_uid, name, net, status, note, sig_uid, signed_at, witness_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET status = excluded.status, note = excluded.note, sig_uid = excluded.sig_uid, signed_at = excluded.signed_at, witness_name = excluded.witness_name, answered_by_name = NULL, answer = NULL,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [uid, runUid, userUid, l.name, l.net, status, txt(note) || null, sig, now, txt(witness) || (byUser && byUser.uid !== userUid ? byUser.name : null), now, dev]);
  audit({ user: byUser, action: `${l.name} ${status === 'signed' ? 'signed for' : 'queried'} pay ${$(l.net)} (week ${run.week_start})`, table: 'pay_signoffs', recordUid: uid, reason: txt(note) || null });
  // Cash handed over and signed for = the cash wages are verified.
  if (status === 'signed' && l.pay_method !== 'bank' && has('verifications')) {
    const all = signoffsFor(runUid).filter((x) => x.line.pay_method !== 'bank' && (x.line.shop_code || '') === (l.shop_code || ''));
    if (all.every((x) => x.signoff && x.signoff.status === 'signed')) {
      db().run(`INSERT INTO verifications (uid, table_name, record_uid, status, note, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(uid) DO UPDATE SET status = 'verified', note = excluded.note, at = excluded.at, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
      [`pay_cash:${runUid}|${l.shop_code || ''}`, 'pay_cash', `${runUid}|${l.shop_code || ''}`, 'verified', 'Every person signed for their cash pay', byUser ? byUser.name : 'Staff', byUser ? byUser.uid : null, now, now, dev]);
    }
  }
  });
}
export function answerQuery(user, uid, answer) {
  requirePerm(user, 'recruit_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(answer), 'Write the answer.');
  const { now, dev } = meta();
  db().run(`UPDATE pay_signoffs SET answered_by_name = ?, answer = ?, ${SYNCED} WHERE uid = ?`, [user.name, txt(answer), now, dev, uid]);
  });
}
export function listQueries() { return has('pay_signoffs') ? db().all("SELECT s.*, r.week_start FROM pay_signoffs s JOIN pay_runs r ON r.uid = s.run_uid WHERE s.status = 'query' ORDER BY s.signed_at DESC LIMIT 100") : []; }
