// THE list of modules. To add a module (e.g. Payroll): make src/modules/payroll/index.js and add it here.
// Each module brings its own screens, reports, rules and sync tables; they share the database,
// logins, roles, look, sync bar and report export.
import timeclock from './timeclock/index.js';
import timesheets from './timesheets/index.js';
import leave from './leave/index.js';
import staff from './staff/index.js';
import bakery from './bakery/index.js';
import admin from './admin/index.js';
import sync from './sync/index.js';
import devices from './devices/index.js';
import payables from './payables/index.js';
import till from './till/index.js';
import bank from './bank/index.js';
import payroll from './payroll/index.js';
import inventory from './inventory/index.js';
import verify from './verify/index.js';
import accounting from './accounting/index.js';
import people from './people/index.js';
import licences from './licences/index.js';
import vehicles from './vehicles/index.js';
import home from './home/index.js';
import owed from './owed/index.js';
import dashboard from './dashboard/index.js';
import loans from './loans/index.js';
import drawings from './drawings/index.js';
import aronium from './aronium/index.js'; // 1.0.0 stream D: the one Aronium place
import { moduleOn } from './admin/service.js';
import { setAlertSources } from '../services/alerts.js';

export const MODULES = [home, timeclock, timesheets, leave, staff, payroll, payables, loans, drawings, till, bank, inventory, verify, accounting, people, licences, vehicles, bakery, admin, devices, sync, owed, dashboard, aronium]; // My day: left out of 3.8, comes back in a later build

// name -> { component, can(user), bakery?, module }
export function allScreens() {
  const out = {};
  for (const m of MODULES) {
    for (const [name, s] of Object.entries(m.screens || {})) {
      if (out[name] && !(out[name].shared && s.shared)) throw new Error(`Screen name "${name}" is used by two modules (${out[name].module}, ${m.id}).`);
      out[name] = { ...s, module: m.id, can: (u) => (!m.switchable || moduleOn(m.id)) && s.can(u) };
    }
  }
  return out;
}

export function allReports() {
  const out = [];
  for (const m of MODULES) {
    if (m.switchable && !moduleOn(m.id)) continue;
    (m.reports || []).forEach((r) => out.push({ ...r, module: m.id }));
  }
  return out;
}
export function findReport(id) {
  for (const m of MODULES) {
    const r = (m.reports || []).find((x) => x.id === id);
    if (r) return r;
  }
  return null;
}
export function getModule(id) {
  return MODULES.find((m) => m.id === id);
}

// Modules that give warnings (src/services/alerts.js), only those switched on.
export function alertSources() {
  return MODULES.filter((m) => typeof m.alerts === 'function' && (!m.switchable || moduleOn(m.id))).map((m) => ({ id: m.id, alerts: m.alerts }));
}
// Modules with a menu (src/services/menus.js), only those switched on.
export function menuModules() {
  return MODULES.filter((m) => Array.isArray(m.menu) && (!m.switchable || moduleOn(m.id)));
}
setAlertSources(alertSources);
