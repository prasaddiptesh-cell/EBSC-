// 1.0.0 (build 1) Per-person switches kept with the staff profile (synced to every device as one shared setting):
//   worksShifts – an admin, manager or payroll person who also works shifts gets the staff buttons ("My shift").
//   ownTill     – may count and balance their own till at the end of the shift. The count is marked "own till" and
//                 someone else must still check it (nobody approves their own over / short).
// Only the owner / admin changes them. The old role permission "May run and balance their own till" still counts.
import { AppError, getShared, setShared, audit } from '../../services/core.js';
import { can, actsAsOwner } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { requirePerm, asService } from '../../services/guard.js';

export const STAFF_FLAGS = {
  worksShifts: { label: 'Works shifts', help: 'Gets the staff buttons (Start shift, End shift …) under "My shift", with a way back to the office.' },
  ownTill: { label: 'Can balance own till', help: 'May count their own till at the end of the shift. Someone else still checks the count.' },
};
const KEY = 'staff_flags';
const all = () => { try { return getShared(KEY, {}) || {}; } catch (e) { return {}; } };

export function staffFlags(userUid) {
  const f = all()[userUid] || {};
  return { worksShifts: !!f.worksShifts, ownTill: !!f.ownTill };
}
export function setStaffFlag(byUser, userUid, key, on) {
  requirePerm(byUser, 'staff_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!byUser || !(actsAsOwner(byUser) || ['owner', 'admin'].includes(byUser.role))) throw new AppError('Only the owner or admin can change this.');
  if (!STAFF_FLAGS[key]) throw new AppError('Unknown switch.');
  const p = db().get('SELECT uid, name FROM users WHERE uid = ?', [userUid]);
  if (!p) throw new AppError('Person not found.');
  const cur = all();
  const next = { ...cur, [userUid]: { ...(cur[userUid] || {}), [key]: !!on } };
  setShared(KEY, next);
  audit({ user: byUser, action: `${p.name}: "${STAFF_FLAGS[key].label}" ${on ? 'on' : 'off'}`, table: 'users', recordUid: userUid });
  return staffFlags(userUid);
  });
}
// May this person count their own till? Owner / admin always; else the switch on their profile, or the role permission.
export function canBalanceOwnTill(user) {
  if (!user) return false;
  if (actsAsOwner(user) || ['owner', 'admin'].includes(user.role)) return true;
  if (staffFlags(user.uid).ownTill) return true;
  try { return can(user, 'till_self_balance'); } catch (e) { return false; }
}
// Does this person work shifts (staff and bakers always do)?
export function worksShifts(user) {
  if (!user) return false;
  if (['staff', 'worker'].includes(user.role)) return true;
  return staffFlags(user.uid).worksShifts;
}
