import { StaffProfileScreen, StaffDetailsScreen, MyStaffProfileScreen } from './screens/StaffProfileScreens.js';
// Staff module: one list of people for the whole business, PINs, roles, faces.
import { StaffListScreen, UserEditScreen } from './screens/StaffScreens.js';
import FaceEnrolScreen from './screens/FaceEnrolScreen.js';
import { MyChecklistScreen, DutyListsScreen, DutyListEditScreen, TeamChecklistScreen } from './screens/DutyScreens.js';
import { actsAsOwner } from '../../services/access.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';

export default {
  id: 'staff',
  title: 'Staff',
  icon: '👥',
  screens: {
    Users: { component: StaffListScreen, can: (u) => can(u, 'staff_manage') || can(u, 'face_enrol') },
    // Names, PINs and roles: staff_manage only. Face enrolment has its own screen (FaceEnrol, from the staff profile).
    UserEdit: { component: UserEditScreen, can: (u) => can(u, 'staff_manage') },
    StaffProfile: { component: StaffProfileScreen, can: (u) => can(u, 'staff_manage') || can(u, 'face_enrol') },
    // Release 03: anyone opens their own profile (only their own: the screen shows nobody else's).
    MyStaffProfile: { component: MyStaffProfileScreen, can: (u) => !!u },
    StaffDetails: { component: StaffDetailsScreen, can: (u) => can(u, 'staff_manage') },
    FaceEnrol: { component: FaceEnrolScreen, can: (u) => can(u, 'face_enrol') },
    // v3.9.5 end-of-shift checklists
    MyChecklist: { component: MyChecklistScreen, can: (u) => !!u },
    TeamChecklist: { component: TeamChecklistScreen, can: (u) => !!u && (can(u, 'till_count') || can(u, 'till_approve') || can(u, 'staff_manage') || actsAsOwner(u)) },
    DutyLists: { component: DutyListsScreen, can: (u) => can(u, 'settings') || actsAsOwner(u) },
    DutyListEdit: { component: DutyListEditScreen, can: (u) => can(u, 'settings') || actsAsOwner(u) },
  },
  menu: MENU,
  reports: [],
};
