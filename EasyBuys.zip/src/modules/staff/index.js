import { StaffProfileScreen, StaffDetailsScreen } from './screens/StaffProfileScreens.js';
// Staff module: one list of people for the whole business, PINs, roles, faces.
import { StaffListScreen, UserEditScreen } from './screens/StaffScreens.js';
import FaceEnrolScreen from './screens/FaceEnrolScreen.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';

export default {
  id: 'staff',
  title: 'Staff',
  icon: '👥',
  screens: {
    Users: { component: StaffListScreen, can: (u) => can(u, 'staff_manage') || can(u, 'face_enrol') },
    UserEdit: { component: UserEditScreen, can: (u) => can(u, 'staff_manage') || can(u, 'face_enrol') },
    StaffProfile: { component: StaffProfileScreen, can: (u) => can(u, 'staff_manage') || can(u, 'face_enrol') },
    StaffDetails: { component: StaffDetailsScreen, can: (u) => can(u, 'staff_manage') },
    FaceEnrol: { component: FaceEnrolScreen, can: (u) => can(u, 'face_enrol') },
  },
  menu: MENU,
  reports: [],
};
