// Staff menu.
export const MENU = [
  { section: 'Records', items: [
    { id: 'home', icon: '👥', title: 'Staff list', note: 'People, PINs, roles, shops, faces.', screen: 'Users' },
  ] },
  { section: 'Settings', items: [
  ] },
];
