// Staff menu.
export const MENU = [
  { section: 'Records', items: [
    { id: 'home', icon: '👥', title: 'Staff list', note: 'People, PINs, roles, shops, faces.', screen: 'Users' },
    { id: 'staff-team', icon: '☑️', title: "Shop assistants' checklists today", screen: 'TeamChecklist' },
  ] },
  { section: 'Settings', items: [
    { id: 'staff-duties', icon: '☑️', title: 'End-of-shift checklists', note: 'The checklist for each job; who does which job.', screen: 'DutyLists' },
  ] },
];
