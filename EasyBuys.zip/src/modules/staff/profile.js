// Staff profile: everything about one person on one page – details, pay, hours, leave, what they owe, payslips,
// contract and onboarding. Each part is read from its own module; a part whose module is off (or fails) is left out.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays } from '../../services/core.js';
import { can } from '../../services/access.js';
import * as TS from '../timesheets/service.js';
import * as LV from '../leave/service.js';
import * as OW from '../owed/service.js';
import * as PY from '../payroll/service.js';
import * as PE from '../people/service.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const safe = (f, dflt = null) => { try { return f(); } catch (e) { return dflt; } };

export const DETAIL_FIELDS = ['email', 'address', 'birth_date', 'emergency_name', 'emergency_phone', 'emergency_relation', 'start_date', 'notes'];

export function getDetails(userUid) {
  return (has('staff_details') && db().get('SELECT * FROM staff_details WHERE user_uid = ?', [userUid])) || { user_uid: userUid };
}
export function saveDetails(user, userUid, d) {
  requirePerm(user, 'staff_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(can(user, 'staff_manage'), 'Only someone who manages staff can change these details.');
  need(db().get('SELECT 1 AS x FROM users WHERE uid = ?', [userUid]), 'Person not found.');
  if (d.birth_date) need(/^\d{4}-\d{2}-\d{2}$/.test(d.birth_date), 'Date of birth: choose a date.');
  if (d.start_date) need(/^\d{4}-\d{2}-\d{2}$/.test(d.start_date), 'Start date: choose a date.');
  if (d.email) need(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(d.email).trim()), 'Email address does not look right.');
  const before = getDetails(userUid);
  const row = {};
  DETAIL_FIELDS.forEach((k) => { row[k] = d[k] !== undefined ? (String(d[k] || '').trim() || null) : (before[k] || null); });
  db().run(`INSERT INTO staff_details (user_uid, ${DETAIL_FIELDS.join(', ')}, updated_at, updated_device, sync_status) VALUES (?, ${DETAIL_FIELDS.map(() => '?').join(', ')}, ?, ?, 'pending')
    ON CONFLICT(user_uid) DO UPDATE SET ${DETAIL_FIELDS.map((k) => `${k} = excluded.${k}`).join(', ')}, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [userUid, ...DETAIL_FIELDS.map((k) => row[k]), stamp(), deviceId()]);
  const u = db().get('SELECT name FROM users WHERE uid = ?', [userUid]);
  audit({ user, action: `Personal details changed: ${u.name}`, table: 'staff_details', recordUid: userUid, before, after: row });
  return getDetails(userUid);
  });
}

// Everything for the profile page. `on` (for tests) says which modules are on; by default all.
export function staffProfile(userUid, { today = dateStr(), on = () => true, viewer = null } = {}) {
  const u = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  need(u, 'Person not found.');
  const mayPay = !viewer || can(viewer, 'payroll_view') || can(viewer, 'payroll_run') || can(viewer, 'payroll_setup');
  const shop = safe(() => db().get('SELECT name FROM shops WHERE code = ?', [u.shop_code]), null);
  const details = getDetails(userUid);
  const out = {
    person: { uid: u.uid, id: u.id, name: u.name, role: u.role, active: !!u.active, employeeNo: u.employee_no || '', phone: u.phone || '', shopCode: u.shop_code || '', shopName: shop ? shop.name : (u.shop_code || ''), usesClock: !!u.uses_clock, face: !!u.face, faceAt: u.face_at || null, login: !!u.username },
    details,
    warnings: [],
  };
  // Pay details (rate, FNPF, TIN, how paid).
  if (on('payroll') && mayPay && has('pay_profiles')) {
    const p = db().get('SELECT * FROM pay_profiles WHERE user_uid = ?', [userUid]);
    out.pay = p ? { payType: p.pay_type, rate: p.rate, weeklySalary: p.weekly_salary, jobTitle: p.job_title || '', fnpfNo: p.fnpf_no || '', tin: p.tin || '', fnpfMember: !!p.fnpf_member, method: p.pay_method, bank: [p.bank_name, p.bank_account].filter(Boolean).join(' '), startDate: p.start_date || null, endDate: p.end_date || null } : null;
    if (!p) out.warnings.push({ key: 'pay', text: 'No pay details yet – this person is left out of pay runs.' });
    else {
      if (p.fnpf_member && !p.fnpf_no) out.warnings.push({ key: 'fnpf', text: 'FNPF number missing.' });
      if (!p.tin) out.warnings.push({ key: 'tin', text: 'TIN missing.' });
      if (p.pay_method === 'bank' && !p.bank_account) out.warnings.push({ key: 'bank', text: 'Paid by bank but no account number.' });
    }
    out.payslips = safe(() => db().all(`SELECT l.uid, r.uid AS run_uid, r.week_start, r.week_end, r.pay_date, l.gross, l.net, l.fnpf_employee, l.paye FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid
      WHERE r.status = 'final' AND l.include = 1 AND l.user_uid = ? ORDER BY r.pay_date DESC, r.week_start DESC LIMIT 6`, [userUid]), []);
    const ytd = safe(() => db().get(`SELECT SUM(l.gross) g, SUM(l.net) n, SUM(l.paye) t, SUM(l.fnpf_employee) f FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid
      WHERE r.status = 'final' AND l.include = 1 AND l.user_uid = ? AND substr(r.pay_date, 1, 4) = ?`, [userUid, today.slice(0, 4)]), null);
    out.ytd = ytd ? { gross: r2(ytd.g), net: r2(ytd.n), paye: r2(ytd.t), fnpf: r2(ytd.f) } : null;
  }
  // Hours: this week so far and last week, and the usual week.
  if ((on('timesheets') || on('timeclock')) && has('punches')) {
    const tsMod = TS;
    if (tsMod) {
      const wk = safe(() => tsMod.personWeek(userUid, today), null);
      const last = safe(() => tsMod.personWeek(userUid, addDays(today, -7)), null);
      out.hours = {
        thisWeek: wk ? { from: wk.weekStart, to: wk.weekEnd, minutes: wk.totalMinutes, checked: !!wk.check, open: (wk.shifts || []).some((s) => !s.end) } : null,
        lastWeek: last ? { from: last.weekStart, to: last.weekEnd, minutes: last.totalMinutes, checked: !!last.check } : null,
        usual: safe(() => tsMod.getRoster(userUid), {}),
      };
      if (last && last.totalMinutes > 0 && !last.check) out.warnings.push({ key: 'ts', text: `Last week's timesheet (${last.weekStart}) is not ticked as checked.` });
    }
  }
  // Leave balances this year and what is coming up.
  if (on('leave') && has('leave_requests')) {
    const lv = LV;
    if (lv) {
      out.leave = {
        balances: safe(() => lv.balances(userUid, Number(today.slice(0, 4))), []).filter((b) => b.limited || b.taken || b.waiting),
        upcoming: safe(() => db().all("SELECT uid, type, from_date, to_date, days, status FROM leave_requests WHERE user_uid = ? AND to_date >= ? AND status IN ('approved','requested') ORDER BY from_date LIMIT 5", [userUid, today]), []),
      };
      if (out.leave.upcoming.some((x) => x.status === 'requested')) out.warnings.push({ key: 'leave', text: 'A leave request is waiting for a decision.' });
    }
  }
  // Money owed to the business: advances, staff loans, charges, Aronium staff credit.
  if (on('owed') || on('payroll')) {
    const ow = on('owed') ? OW : null;
    const o = ow ? safe(() => ow.personOwes(userUid, { today }), null) : null;
    if (o) out.owes = { total: r2(o.total), aronium: r2(o.aronium), advances: r2(o.advances), loans: r2(o.loans), charges: r2((o.charges || 0) + (o.tillShort || 0)), limit: o.limit, level: o.level, open: (o.items || []).filter((x) => x.open).slice(0, 6) };
    else if (on('payroll') && has('staff_debts')) {
      const P = PY;
      const debts = P ? safe(() => P.listDebts({ userUid }), []) : [];
      out.owes = { total: r2(debts.reduce((a, d) => a + d.balance, 0)), open: debts.map((d) => ({ uid: d.uid, date: d.debt_date, label: d.kind, reason: d.reason || '', balance: d.balance })) };
    }
    if (out.owes && out.owes.level === 'over') out.warnings.push({ key: 'credit', text: 'Over the staff credit limit.' });
  }
  // Contract and onboarding.
  if (on('recruitment') && has('onboarding')) {
    const pe = PE;
    if (pe) {
      const ob = safe(() => pe.getOnboarding(userUid), null);
      out.onboarding = ob ? { done: ob.done, total: ob.total, complete: ob.complete, probation: ob.probation_result || null, startDate: ob.start_date || null } : null;
      out.contracts = safe(() => pe.contractsFor(userUid), []).map((c) => ({ uid: c.uid, status: c.status, startDate: c.start_date || null, created: String(c.created_at || '').slice(0, 10), employeeSigned: !!c.employee_signed_at, employerSigned: !!c.employer_signed_at }));
      if (ob && !ob.complete) out.warnings.push({ key: 'onboard', text: `Onboarding not finished (${ob.done} of ${ob.total}).` });
      if (u.active && (!out.contracts || !out.contracts.some((c) => c.status !== 'void'))) out.warnings.push({ key: 'contract', text: 'No employment contract in the app yet.' });
    }
  }
  if (!details.emergency_phone) out.warnings.push({ key: 'emergency', text: 'No emergency contact.' });
  if (u.uses_clock && !u.face) out.warnings.push({ key: 'face', text: 'Face not enrolled for the Time Clock.' });
  // Latest changes about this person.
  out.history = safe(() => db().all("SELECT at, user_name, action FROM audit_log WHERE record_uid = ? OR action LIKE ? ORDER BY at DESC LIMIT 8", [userUid, `%${u.name}%`]), []);
  return out;
}

// v3.9.8 One tap on the staff profile: a person who has left can no longer log in (PIN, password or face) on any
// device. Nothing about them is deleted – their pay, leave and history stay. It can be turned back on.
export function setLoginOn(user, userUid, on, reason) {
  requirePerm(user, 'staff_manage'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const boss = !!user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
  if (!(boss || can(user, 'staff_manage'))) throw new AppError('Only the owner, admin or someone who manages staff can turn a login off or on.');
  const u = db().get('SELECT id, uid, name, role, active FROM users WHERE uid = ?', [userUid]);
  if (!u) throw new AppError('Person not found.');
  if (user && user.uid === u.uid) throw new AppError('You cannot turn off your own login.');
  if (!on && !String(reason || '').trim()) throw new AppError('Write why (for example "left on 31 Oct").');
  if (!on && ['owner', 'admin'].includes(u.role)) {
    if (!boss) throw new AppError('Only the owner or admin can turn off an admin\'s login.');
    const left = db().get("SELECT COUNT(*) AS c FROM users WHERE role IN ('admin','owner') AND active = 1 AND uid <> ?", [u.uid]).c;
    if (left < 1) throw new AppError('You cannot remove the last active Admin or Owner.');
  }
  if (!!u.active === !!on) return false;
  db().run("UPDATE users SET active = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [on ? 1 : 0, stamp(), deviceId(), u.uid]);
  audit({ user, action: `${on ? 'Turned on' : 'Turned off'} the login of ${u.name}`, table: 'users', recordUid: u.uid, reason: String(reason || '').trim() || null });
  return true;
  });
}
