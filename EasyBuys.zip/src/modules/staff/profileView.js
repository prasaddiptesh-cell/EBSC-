// Release 03: the staff profile laid out as ONE page per person (owner: "one place for staff profile, no duplicates").
// staffProfile() (profile.js) reads the data from each module; profileView() below is a pure function that turns it into
// the sections the page shows – Details, Pay, This week, Leave, Payslips & FNPF, Owes, Documents & contract – keeping
// only what the person looking may see, with a link to the existing screen that changes each part.
// Staff looking at their own profile see their own pay, hours, leave, payslips and what they owe; never anyone else's.
import { db } from '../../db/connection.js';
import { money } from '../../services/core.js';
import { fmtDate } from '../../services/dates.js';

const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');
const hm = (m) => `${Math.floor((m || 0) / 60)}h ${String(Math.round((m || 0) % 60)).padStart(2, '0')}m`;
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];
const PAY_PERMS = ['payroll_view', 'payroll_run', 'payroll_setup'];

// FNPF (employee and employer) for each of the latest payslips; staffProfile() only carries the employee part.
export function payslipFnpf(userUid) {
  try {
    const rows = db().all(`SELECT l.uid, l.fnpf_employee, l.fnpf_employer FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid
      WHERE r.status = 'final' AND l.include = 1 AND l.user_uid = ? ORDER BY r.pay_date DESC, r.week_start DESC LIMIT 12`, [userUid]);
    const out = {};
    rows.forEach((r) => { out[r.uid] = { employee: Number(r.fnpf_employee) || 0, employer: Number(r.fnpf_employer) || 0 }; });
    return out;
  } catch (e) { return {}; }
}

/**
 * Turns staffProfile() data into the page's sections.
 * @param P       staffProfile(uid) result
 * @param viewer  the logged-in person
 * @param can     (user, perm) => bool   (access.js can)
 * @param may     (screenName) => bool   (screen exists and the viewer may open it)
 * @param fnpf    payslipFnpf(uid) result (optional)
 * @param today   'YYYY-MM-DD'
 * Each section: { key, title, rows: [{ label, value, bold, link }], notes: [text], links: [{ id, title, screen, params, icon }] }.
 */
export function profileView(P, { viewer, can = () => false, may = () => false, fnpf = {}, today = '' } = {}) {
  if (!P || !P.person) return { allowed: false, self: false, sections: [], summary: [], warnings: [] };
  const p = P.person; const det = P.details || {};
  const self = !!viewer && !!viewer.uid && viewer.uid === p.uid;
  const c = (perm) => !!viewer && !!can(viewer, perm);
  const manager = c('staff_manage') || c('face_enrol');
  const allowed = self || manager;
  if (!allowed) return { allowed: false, self, sections: [], summary: [], warnings: [] };
  const link = (id, title, screen, params = {}, icon) => (may(screen) ? { id, title, screen, params, icon } : null);
  const links = (...xs) => xs.filter(Boolean);
  const sections = [];
  const summary = [];

  // ---- Details
  const emergency = det.emergency_name ? `${det.emergency_name}${det.emergency_relation ? ` (${det.emergency_relation})` : ''} ${det.emergency_phone || ''}`.trim() : '–';
  sections.push({ key: 'details', title: 'Details', rows: [
    { label: 'Name', value: p.name },
    { label: 'Employee no.', value: p.employeeNo || '–' },
    { label: 'Job', value: (P.pay && P.pay.jobTitle) || '–' },
    { label: 'Shop', value: p.shopName || '–' },
    { label: 'Phone', value: p.phone || '–' },
    { label: 'Email', value: det.email || '–' },
    { label: 'Started', value: d(det.start_date || (P.pay && P.pay.startDate)) },
    { label: 'Date of birth', value: d(det.birth_date) },
    { label: 'Address', value: det.address || '–' },
    { label: 'Emergency contact', value: emergency },
    { label: 'Uses the Time Clock', value: p.usesClock ? 'Yes' : 'No' },
  ], notes: det.notes && manager ? [det.notes] : [],
  links: links(link('edit', 'Name, role, shop, PIN', 'UserEdit', { id: p.id }, '✎'), link('details', 'Personal details', 'StaffDetails', { uid: p.uid }, '✎')) });

  // ---- Pay (rate or fixed weekly pay, FNPF, TIN)
  const seePay = self || PAY_PERMS.some(c);
  if (seePay && P.pay !== undefined) {
    const pay = P.pay;
    const rows = pay ? [
      { label: 'Pay', value: pay.payType === 'salary' ? `${money(pay.weeklySalary)} a week (fixed)` : `${money(pay.rate)} an hour`, bold: true },
      { label: 'Paid by', value: pay.method === 'bank' ? `Bank ${pay.bank}`.trim() : (pay.method || '–') },
      { label: 'Takes FNPF', value: pay.fnpfMember ? 'Yes' : 'No (owner / family)' },
      ...(pay.fnpfMember ? [{ label: 'FNPF number', value: pay.fnpfNo || 'missing' }] : []),
      { label: 'TIN', value: pay.tin || 'missing' },
    ] : [];
    sections.push({ key: 'pay', title: 'Pay', rows, notes: pay ? [] : ['No pay details yet – left out of pay runs until they are set up.'],
      links: links(link('pay', pay ? 'Change pay details' : 'Set up pay', 'PayProfile', { userUid: p.uid }, '💰')) });
    if (pay) summary.push({ key: 'pay', label: 'Pay', value: pay.payType === 'salary' ? `${money(pay.weeklySalary)}/wk` : `${money(pay.rate)}/h` });
  }

  // ---- This week (hours from the timesheet)
  const seeHours = self || c('timesheets_view');
  if (seeHours && P.hours) {
    const h = P.hours; const rows = [];
    if (h.thisWeek) rows.push({ label: `This week (${d(h.thisWeek.from)} – ${d(h.thisWeek.to)})`, value: `${hm(h.thisWeek.minutes)}${h.thisWeek.open ? ' · on shift now' : ''}`, bold: true });
    if (h.lastWeek) rows.push({ label: `Last week (from ${d(h.lastWeek.from)})`, value: `${hm(h.lastWeek.minutes)} · ${h.lastWeek.checked ? 'checked ✓' : 'not checked'}` });
    const usual = DAYS.map(([k, l]) => { const x = (h.usual || {})[k]; return x && x.start ? `${l} ${x.start}–${x.end}` : null; }).filter(Boolean).join(' · ');
    const fix = link('ts', 'Fix this week', 'TimesheetPerson', { userUid: p.uid, date: today }, '🕒') || (self ? link('myhours', 'My hours', 'MyHours', {}, '🕒') : null);
    sections.push({ key: 'week', title: 'This week', rows, notes: [`Usual week: ${usual || 'not set'}`],
      links: links(fix, self ? null : link('roster', 'Usual week', 'Roster', {}, '🗓️')) });
    if (h.thisWeek) summary.push({ key: 'week', label: 'This week', value: hm(h.thisWeek.minutes) });
  }

  // ---- Leave
  const seeLeave = self || c('leave_approve') || c('staff_manage');
  if (seeLeave && P.leave) {
    const rows = P.leave.balances.map((b) => ({ label: b.name, value: b.limited ? `${b.left} left of ${b.allowed} (taken ${b.taken}${b.waiting ? `, waiting ${b.waiting}` : ''})` : `taken ${b.taken}` }));
    const notes = P.leave.upcoming.map((x) => `${x.type} ${d(x.from_date)} – ${d(x.to_date)} (${x.days} day${x.days === 1 ? '' : 's'}, ${x.status === 'requested' ? 'waiting' : 'approved'})`);
    if (!rows.length && !notes.length) notes.push('No leave set up or taken yet.');
    sections.push({ key: 'leave', title: 'Leave', rows, notes,
      links: links(self ? link('leave', 'Ask for leave', 'Leave', { tab: 'mine' }, '🌴') : link('leave', 'Request or approve leave', 'Leave', { tab: c('leave_approve') ? 'approve' : 'mine' }, '🌴')) });
    const annual = P.leave.balances.find((b) => b.limited);
    if (annual) summary.push({ key: 'leave', label: annual.name, value: `${annual.left} left` });
  }

  // ---- Payslips & FNPF (one row per week)
  if (seePay && P.payslips !== undefined) {
    const member = P.pay ? P.pay.fnpfMember : true;
    const rows = (P.payslips || []).map((s) => {
      const f = fnpf[s.uid] || { employee: Number(s.fnpf_employee) || 0, employer: 0 };
      const fn = member ? ` · FNPF ${money(f.employee)}${f.employer ? ` + ${money(f.employer)} employer` : ''}` : '';
      return { label: `Week ${d(s.week_start)} – ${d(s.week_end)}`, value: `Net ${money(s.net)}${fn}`,
        link: link(`slip-${s.uid}`, 'Open', 'PayLine', { uid: s.uid }) };
    });
    const notes = [];
    if (!rows.length) notes.push('No payslips yet.');
    if (!member) notes.push('Does not take FNPF (owner / family).');
    if (P.ytd) rows.push({ label: `This year (${String(today).slice(0, 4)})`, value: `Gross ${money(P.ytd.gross)} · PAYE ${money(P.ytd.paye)} · FNPF ${money(P.ytd.fnpf)}`, bold: true });
    sections.push({ key: 'payslips', title: 'Payslips & FNPF', rows, notes,
      links: links(self ? link('myslips', 'All my payslips', 'MyPayslips', {}, '🧾') : link('payroll', 'Payroll & FNPF', 'Payroll', {}, '🧾')) });
  }

  // ---- Owes the business (Aronium staff credit + advances / loans)
  const seeOwes = self || c('owed_view') || c('payroll_run');
  if (seeOwes && P.owes) {
    const o = P.owes;
    const rows = [{ label: 'Total owed', value: money(o.total), bold: true, warn: o.total > 0 }];
    if (o.aronium) rows.push({ label: 'Staff credit (Aronium)', value: money(o.aronium) });
    if (o.advances) rows.push({ label: 'Advances', value: money(o.advances) });
    if (o.loans) rows.push({ label: 'Staff loans', value: money(o.loans) });
    if (o.charges) rows.push({ label: 'Shortages & charges', value: money(o.charges) });
    if (o.limit) rows.push({ label: 'Credit limit', value: `${money(o.limit)}${o.level === 'over' ? ' · over' : o.level === 'approaching' ? ' · nearly reached' : ''}` });
    sections.push({ key: 'owes', title: 'Owes the business', rows, notes: [],
      links: links(link('owed', 'Details', 'OwedPerson', { uid: p.uid }, '🤝'), self ? null : link('debts', 'Give an advance or loan', 'StaffDebts', {}, '➕')) });
    summary.push({ key: 'owes', label: 'Owes', value: money(o.total) });
  }

  // ---- Documents & contract
  const seeDocs = self || c('staff_manage') || c('recruit_manage') || c('contract_sign');
  if (seeDocs && (P.contracts || P.onboarding)) {
    const rows = [];
    if (P.onboarding) rows.push({ label: 'Onboarding', value: P.onboarding.complete ? 'Done ✓' : `${P.onboarding.done} of ${P.onboarding.total} done` });
    if (P.onboarding && P.onboarding.probation) rows.push({ label: 'Probation', value: P.onboarding.probation });
    (P.contracts || []).forEach((k) => rows.push({ label: `Contract ${d(k.startDate || k.created)}`, value: `${k.status}${k.employeeSigned && k.employerSigned ? ' · signed ✓' : ''}`,
      link: link(`contract-${k.uid}`, 'Open', 'Contract', { uid: k.uid }) }));
    const notes = [];
    if (!(P.contracts || []).length) notes.push('No contract in the app yet.');
    if (!P.onboarding) notes.push('No onboarding checklist.');
    sections.push({ key: 'docs', title: 'Documents & contract', rows, notes,
      links: links(link('onb', 'Onboarding & documents', 'Onboarding', { userUid: p.uid }, '📋')) });
  }

  return { allowed: true, self, sections, summary, warnings: c('staff_manage') ? (P.warnings || []) : [] };
}
