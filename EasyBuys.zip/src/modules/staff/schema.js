// Personal details kept with each person's profile (synced to every device).
export const STAFF_SQL = `
CREATE TABLE IF NOT EXISTS staff_details (
  user_uid TEXT PRIMARY KEY,
  email TEXT, address TEXT, birth_date TEXT,
  emergency_name TEXT, emergency_phone TEXT, emergency_relation TEXT,
  start_date TEXT, notes TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const STAFF_SYNC = {
  staff_details: SYNC('user_uid', 'Staff', ['user_uid', 'email', 'address', 'birth_date', 'emergency_name', 'emergency_phone', 'emergency_relation', 'start_date', 'notes']),
};
