// v3.9.5 End-of-shift checklists: "My checklist" (each person ticks theirs on the shop tablet), the cashier checking the
// shop assistants, and the owner / admin settings (switch a job's list on, edit its items, who does which job).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Field, Section, Chips, Select, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, Hint, ListItem } from '../../../ui/kit.js';
import * as D from '../../../services/duties.js';
import { listUsers } from '../../../services/catalog.js';

function Tick({ on, skipped, text, onPress, testID }) {
  return (
    <Pressable testID={testID} onPress={onPress}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 14, borderWidth: 2, borderColor: on ? C.success : skipped ? C.warn : C.border, backgroundColor: on ? '#DDF4E4' : C.card, opacity: pressed ? 0.7 : 1 })}>
      <View style={{ width: 34, height: 34, borderRadius: 10, borderWidth: 2, borderColor: on ? C.success : C.border, backgroundColor: on ? C.success : C.white, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: C.white, fontSize: 20, fontWeight: '900' }}>{on ? '✓' : ''}</Text>
      </View>
      <Text style={{ flex: 1, fontSize: 18, fontWeight: '700', color: C.text }}>{text}</Text>
    </Pressable>
  );
}

// The list of the person logged in, for today.
export function MyChecklistScreen() {
  const { user } = useApp();
  const ui = useUI();
  const act = useAct();
  const [, bump] = useState(0);
  const [why, setWhy] = useState({}); // itemId -> reason being typed
  const [skipOpen, setSkipOpen] = useState(null);
  let d = null;
  try { d = D.myDutyToday(user); } catch (e) { d = null; }
  if (!d) {
    return (
      <Screen title="My checklist" subtitle="Before you finish work">
        <Hint>There is no checklist for your job. The owner or admin switches them on in Settings › People & pay › End-of-shift checklists.</Hint>
      </Screen>
    );
  }
  const run = (fn, msg) => { if (act(fn, msg) !== null) bump((n) => n + 1); };
  const left = d.items.filter((it) => !d.ticks[it.id] && !d.skipped[it.id]).length;
  return (
    <Screen title="My checklist" subtitle={`${d.dutyLabel} · ${d.ticked} of ${d.total} done`}
      footer={!d.done ? <Btn testID="duty-finish" title={left ? `${left} still to tick` : 'Finished – checklist done'} icon="✅" variant={left ? 'secondary' : 'success'} onPress={() => run(() => D.finishDuty(user), 'Checklist done – thank you')} /> : null}>
      {d.done ? <Card tone="success"><Text style={{ fontSize: 18, fontWeight: '800', color: C.success }}>{`Done at ${String(d.run.done_at).slice(11, 16)} – thank you.`}</Text>{d.run.checked_by_name ? <Text style={{ fontSize: 15, color: C.text }}>{`Checked by ${d.run.checked_by_name}${d.run.check_note ? `: ${d.run.check_note}` : ''}`}</Text> : null}</Card> : <Hint>Tick each job when it is done. If something could not be done, tap "Not done" and write why – the cashier and the owner see it.</Hint>}
      <View style={{ gap: 10 }}>
        {d.items.map((it) => (
          <View key={it.id} style={{ gap: 6 }}>
            <Tick testID={`duty-${it.id}`} on={!!d.ticks[it.id]} skipped={!!d.skipped[it.id]} text={it.text} onPress={() => (d.done ? null : run(() => D.tickDuty(user, it.id, !d.ticks[it.id])))} />
            {d.skipped[it.id] && !d.ticks[it.id] ? <Text style={{ fontSize: 14, color: C.warn, fontWeight: '700', marginLeft: 8 }}>{`Not done – ${d.skipped[it.id]}`}</Text> : null}
            {!d.done && !d.ticks[it.id] ? (
              skipOpen === it.id ? (
                <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
                  <View style={{ flex: 1 }}><Field testID={`duty-why-${it.id}`} label="Why was it not done?" value={why[it.id] || ''} onChangeText={(v) => setWhy((w) => ({ ...w, [it.id]: v }))} /></View>
                  <Btn testID={`duty-skip-save-${it.id}`} title="Save" size="md" variant="warn" onPress={() => { run(() => D.skipDuty(user, it.id, why[it.id])); setSkipOpen(null); }} />
                </View>
              ) : <Pressable testID={`duty-skip-${it.id}`} onPress={() => setSkipOpen(it.id)} style={{ alignSelf: 'flex-start', marginLeft: 8 }}><Text style={{ fontSize: 15, color: C.sub, textDecorationLine: 'underline' }}>Not done?</Text></Pressable>
            ) : null}
          </View>
        ))}
      </View>
    </Screen>
  );
}

// The cashier (or a manager) checks the shop assistants on the shift. Used on its own and inside the handover.
export function TeamChecklists({ shopCode, date, onChange }) {
  const { user } = useApp();
  const act = useAct();
  const [note, setNote] = useState({});
  const [open, setOpen] = useState(null);
  let team = [];
  try { team = D.teamDuties({ shopCode, date }); } catch (e) { team = []; }
  if (!team.length) return <Text style={{ fontSize: 15, color: C.sub }}>No shop assistant has clocked in at this shop today.</Text>;
  const done = (fn, msg) => { if (act(fn, msg) !== null && onChange) onChange(); };
  return (
    <View style={{ gap: 8 }}>
      {team.map((p) => (
        <Card key={p.uid} tone={p.checked ? (p.checkOk ? 'success' : 'warn') : undefined}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: p.done ? C.success : C.warn }} />
            <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: C.text }}>{p.name}</Text>
            <Text style={{ fontSize: 15, fontWeight: '700', color: p.done ? C.success : C.warn }}>{`Checklist ${p.ticked} of ${p.total}${p.done ? ' ✓' : ''}`}</Text>
          </View>
          {p.items.filter((it) => !p.ticks[it.id]).map((it) => <Text key={it.id} style={{ fontSize: 14, color: C.warn }}>{`• ${it.text}${p.skipped[it.id] ? ` – ${p.skipped[it.id]}` : ' – not ticked'}`}</Text>)}
          {p.checked ? <Text style={{ fontSize: 14, color: p.checkOk ? C.success : C.warn, fontWeight: '700' }}>{`Checked by ${p.run.checked_by_name}${p.run.check_note ? ` – ${p.run.check_note}` : ''}`}</Text> : null}
          {!p.checked && p.uid !== user.uid ? (
            <View style={{ gap: 6 }}>
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                <Btn testID={`team-ok-${p.uid}`} title="✓ All done – checked" size="sm" variant="success" onPress={() => done(() => D.checkTeamDuty(user, p.uid, { date, shopCode, ok: true }), `${p.name}: checked`)} />
                <Btn testID={`team-no-${p.uid}`} title="Not everything done" size="sm" variant="secondary" onPress={() => setOpen(open === p.uid ? null : p.uid)} />
              </View>
              {open === p.uid ? (
                <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
                  <View style={{ flex: 1 }}><Field testID={`team-note-${p.uid}`} label="What was not done, and why?" value={note[p.uid] || ''} onChangeText={(v) => setNote((n) => ({ ...n, [p.uid]: v }))} /></View>
                  <Btn testID={`team-no-save-${p.uid}`} title="Save" size="md" variant="warn" onPress={() => { done(() => D.checkTeamDuty(user, p.uid, { date, shopCode, ok: false, note: note[p.uid] }), 'Saved – it goes to To verify'); setOpen(null); }} />
                </View>
              ) : null}
            </View>
          ) : null}
        </Card>
      ))}
    </View>
  );
}

// Settings: the list for each job (on / off, items), and who does which job.
export function DutyListsScreen() {
  const { nav, user } = useApp();
  const act = useAct();
  const [, bump] = useState(0);
  const lists = D.listDutyLists();
  const users = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const [person, setPerson] = useState('');
  const map = D.dutyMap();
  return (
    <Screen title="End-of-shift checklists" subtitle="One list for each job – switch on, edit the items">
      <Hint>Each person ticks their list on the shop tablet before finishing. At the handover the cashier checks the shop assistants' lists. Anything not done, and why, goes to To verify.</Hint>
      {D.DUTY_ORDER.map((duty) => {
        const mine = lists.filter((l) => l.duty === duty);
        const on = mine.find((l) => l.active);
        const l = on || mine[0];
        return (
          <Card key={duty}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <Text style={{ flex: 1, fontSize: 18, fontWeight: '800', color: C.text }}>{D.DUTIES[duty]}</Text>
              <Text style={{ fontSize: 15, fontWeight: '800', color: on ? C.success : C.sub }}>{on ? 'ON' : 'OFF'}</Text>
            </View>
            {l ? <Text style={{ fontSize: 15, color: C.sub }}>{l.items.map((it) => it.text).join(' · ')}</Text> : <Text style={{ fontSize: 15, color: C.sub }}>No list yet.</Text>}
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
              {l ? <Btn testID={`dl-toggle-${duty}`} title={on ? 'Switch off' : 'Switch on'} size="sm" variant={on ? 'secondary' : 'success'} onPress={() => { if (act(() => D.setDutyListOn(user, l.uid, !on), on ? 'Switched off' : 'Switched on') !== null) bump((n) => n + 1); }} /> : null}
              <Btn testID={`dl-edit-${duty}`} title="Edit the items" size="sm" variant="info" onPress={() => nav.push('DutyListEdit', { uid: l ? l.uid : null, duty })} />
            </View>
          </Card>
        );
      })}
      <Section title="Who does which job">
        <Hint>Shop staff are shop assistants, bakers are bakers, accountant and payroll logins have theirs. Make a person a cashier (or give a manager a list) here.</Hint>
        <Select testID="dl-person" label="Person" value={person} onChange={setPerson} search options={users.map((u) => ({ value: u.uid, label: u.name, hint: D.DUTIES[D.dutyOf(u)] || 'no checklist' }))} />
        {person ? (() => {
          const u = users.find((x) => x.uid === person);
          const cur = D.dutyOf(u) || '';
          return (
            <Chips value={Object.prototype.hasOwnProperty.call(map, person) ? map[person] || 'none' : cur || 'none'} testIDPrefix="dl-duty"
              onChange={(v) => { if (act(() => D.setDuty(user, person, v === 'none' ? '' : v), 'Saved') !== null) bump((n) => n + 1); }}
              options={D.DUTY_ORDER.map((k) => ({ value: k, label: D.DUTIES[k] })).concat([{ value: 'none', label: 'No checklist' }])} />
          );
        })() : null}
      </Section>
    </Screen>
  );
}

export function DutyListEditScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const lists = D.listDutyLists();
  const l = params.uid ? lists.find((x) => x.uid === params.uid) : null;
  const duty = l ? l.duty : params.duty;
  const [items, setItems] = useState(() => (l ? l.items.map((it) => ({ ...it })) : (D.STARTER[duty] || []).map((text, i) => ({ id: `${duty}${i + 1}`, text }))));
  const [name, setName] = useState(l ? l.name : `${D.DUTIES[duty] || ''} – end of shift`);
  const set = (i, text) => setItems((xs) => xs.map((x, k) => (k === i ? { ...x, text } : x)));
  const move = (i, step) => setItems((xs) => { const j = i + step; if (j < 0 || j >= xs.length) return xs; const n = xs.slice(); [n[i], n[j]] = [n[j], n[i]]; return n; });
  return (
    <Screen title={`Checklist: ${D.DUTIES[duty] || ''}`} subtitle="Change the wording, add or remove items"
      footer={<Btn testID="dl-save" title="Save the checklist" icon="💾" variant="success" onPress={() => { if (act(() => D.saveDutyList(user, { uid: l ? l.uid : null, duty, name, items, active: l ? !!l.active : true }), 'Saved') !== null) nav.pop(); }} />}>
      <Field testID="dl-name" label="Name" value={name} onChangeText={setName} />
      {items.map((it, i) => (
        <View key={it.id} style={{ flexDirection: 'row', gap: 6, alignItems: 'flex-end' }}>
          <View style={{ flex: 1 }}><Field testID={`dl-item-${i}`} label={`Item ${i + 1}`} value={it.text} onChangeText={(v) => set(i, v)} /></View>
          <Btn title="↑" size="sm" variant="ghost" onPress={() => move(i, -1)} />
          <Btn title="↓" size="sm" variant="ghost" onPress={() => move(i, 1)} />
          <Btn testID={`dl-del-${i}`} title="✕" size="sm" variant="ghost" onPress={() => setItems((xs) => xs.filter((_, k) => k !== i))} />
        </View>
      ))}
      <Btn testID="dl-add" title="Add an item" icon="➕" size="md" variant="secondary" onPress={() => setItems((xs) => xs.concat([{ id: `${duty}${Date.now().toString(36)}`, text: '' }]))} />
      {D.STARTER[duty] ? <Btn title="Start again from the usual list" size="sm" variant="ghost" onPress={() => setItems(D.STARTER[duty].map((text, i) => ({ id: `${duty}${i + 1}`, text })))} /> : null}
    </Screen>
  );
}

// Today's shop assistants for the cashier (also inside Handover).
export function TeamChecklistScreen({ params = {} }) {
  const { user } = useApp();
  const [, bump] = useState(0);
  const shop = params.shopCode || user.shop_code || 'S1';
  const date = params.date || require('../../../services/core.js').dateStr();
  return (
    <Screen title="Shop assistants' checklists" subtitle={`${shop} · ${date}`}>
      <Hint>Check each shop assistant's list before you hand over. If something was not done, say what and why – it goes to To verify.</Hint>
      <TeamChecklists shopCode={shop} date={date} onChange={() => bump((n) => n + 1)} />
    </Screen>
  );
}
export { ListItem };
