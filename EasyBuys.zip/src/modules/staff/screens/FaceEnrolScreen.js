// Enrol a staff member's face: 3 photos, all on the tablet. Only numbers are kept, not the photos.
import React, { useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { db } from '../../../db/connection.js';
import { getEngine, useEngineStatus } from '../../timeclock/engineHost.js';
import FrontCamera from '../../timeclock/camera.js';
import { ENROL_PHOTOS, checkEnrolment, compact } from '../../timeclock/face.js';
import { saveFace } from '../../timeclock/service.js';

const HINTS = ['Look straight at the camera', 'Turn your head a little to the left', 'Turn your head a little to the right', 'Look straight again', 'Chin a little up'];

export default function FaceEnrolScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const { isPhone, width } = useLayout();
  const person = db().get('SELECT * FROM users WHERE uid = ?', [params.userUid]);
  const camera = useRef(null);
  const engine = useEngineStatus();
  const [shots, setShots] = useState([]);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState(null);
  const done = shots.length >= ENROL_PHOTOS;

  const take = async () => {
    setMsg(null); setBusy('Reading the face…');
    const shot = camera.current ? await camera.current.snap() : null;
    if (!shot) { setBusy(''); setMsg({ tone: 'danger', text: 'Could not take a photo. Check the camera is allowed.' }); return; }
    const eng = getEngine();
    const r = eng && eng.ready() ? await eng.describe(shot.b64) : { ok: false, reason: 'not_ready' };
    setBusy('');
    if (!r.ok) { setMsg({ tone: 'danger', text: r.reason === 'no_face' ? 'No face seen. Move closer, face the light, and try again.' : `Face engine problem: ${r.message || r.reason}` }); return; }
    if (r.faces > 1) { setMsg({ tone: 'danger', text: 'More than one person in the picture. Only this person please.' }); return; }
    const next = shots.concat([compact(r.descriptor)]);
    const problem = checkEnrolment(next);
    if (problem) { setShots([]); setMsg({ tone: 'danger', text: problem }); return; }
    setShots(next);
  };
  const save = () => {
    try {
      saveFace(user, person.uid, shots);
      ui.toast(`Face saved for ${person.name}`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  const w = isPhone ? Math.min(300, width - 40) : 340;
  return (
    <Screen title={`Enrol face – ${person ? person.name : ''}`} subtitle="3 photos, good light, only this person">
      {engine.state === 'failed' ? <Banner tone="danger" title="Face engine not working on this device" message={engine.message} /> : null}
      {engine.state === 'off' ? <Banner tone="warn" message="Face check is switched off in Time Clock rules (mode: off or photo only)." /> : null}
      {engine.state === 'loading' ? <Banner tone="info" message="Face engine starting… (up to a minute the first time)" /> : null}
      <View style={{ alignItems: 'center', gap: 10 }}>
        <FrontCamera ref={camera} width={w} height={w * 1.25} />
        <Text testID="enrol-step" style={{ fontSize: 22, fontWeight: '800', color: C.text, textAlign: 'center' }}>
          {done ? 'All photos taken' : `Photo ${shots.length + 1} of ${ENROL_PHOTOS}: ${HINTS[shots.length]}`}
        </Text>
      </View>
      {msg ? <Banner tone={msg.tone} message={msg.text} /> : null}
      {busy ? <Banner tone="info" title={busy} message="Hold still." /> : done
        ? <Btn testID="enrol-save" title={`Save face for ${person ? person.name.split(' ')[0] : ''}`} variant="success" onPress={save} />
        : <Btn testID="enrol-take" title="Take photo" icon="📷" onPress={take} disabled={engine.state !== 'ready'} />}
      {shots.length && !busy ? <Btn title="Start again" variant="secondary" size="md" onPress={() => setShots([])} /> : null}
    </Screen>
  );
}
