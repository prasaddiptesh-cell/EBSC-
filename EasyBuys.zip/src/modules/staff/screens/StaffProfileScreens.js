// Staff profile: one page per person with everything about them, and a link to change each part.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Row, RoleBadge, Badge, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ReasonButton, useAct } from '../../../ui/kit.js';
import { DateField } from '../../../ui/dateField.js';
import { money, dateStr } from '../../../services/core.js';
import { can } from '../../../services/access.js';
import { fmtDate } from '../../../services/dates.js';
import { db } from '../../../db/connection.js';
import { moduleOn } from '../../admin/service.js';
import { allScreens } from '../../registry.js';
import { staffProfile, getDetails, saveDetails, setLoginOn } from '../profile.js';
import { removeFace } from '../../timeclock/service.js';
import { PermissionsSummary } from '../../home/V1Screens.js'; // 1.0.0 each person's permissions (stream A)

const hm = (m) => `${Math.floor((m || 0) / 60)}h ${String(Math.round((m || 0) % 60)).padStart(2, '0')}m`;
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];
const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');

function uidFrom(params) {
  if (params.uid) return params.uid;
  if (params.id) { const r = db().get('SELECT uid FROM users WHERE id = ?', [params.id]); return r ? r.uid : null; }
  return null;
}

export function StaffProfileScreen({ params = {} }) {
  const { nav, user, screens: ctxScreens } = useApp();
  const act = useAct();
  const ui = useUI();
  const [, bump] = useState(0);
  const uid = uidFrom(params);
  const screens = ctxScreens || allScreens();
  const may = (name) => { const s = screens[name]; return !!s && (!s.can || s.can(user)); };
  const go = (name, p) => nav.push(name, p || {});
  let P = null; let err = null;
  try { P = staffProfile(uid, { on: (m) => safeOn(m), viewer: user }); } catch (e) { err = e.message; }
  if (!P) return <Screen title="Staff"><Banner tone="danger" message={err || 'Person not found.'} /></Screen>;
  const p = P.person; const det = P.details;
  const btn = (id, title, name, prm, icon) => (may(name) ? <Btn key={id} testID={`sp-${id}`} title={title} icon={icon} size="sm" variant="secondary" onPress={() => go(name, prm)} /> : null);
  return (
    <Screen title={p.name} subtitle={[p.employeeNo, p.shopName, P.pay && P.pay.jobTitle].filter(Boolean).join(' · ') || 'Staff profile'}>
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
        <RoleBadge role={p.role} />
        {p.active ? null : <Badge text="Left / inactive" color={C.sub} />}
        {p.face ? <Badge text="Face ✓" color={C.success} /> : null}
        {p.login ? <Badge text="Password login" color={C.sub} /> : null}
      </View>
      {P.warnings.length ? (
        <Card tone="warn">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>To sort out ({P.warnings.length})</Text>
          {P.warnings.map((w) => <Text testID={`sp-warn-${w.key}`} key={w.key} style={{ color: C.text, fontSize: 15 }}>• {w.text}</Text>)}
        </Card>
      ) : <Banner tone="success" message="Everything is in place for this person." />}

      {(can(user, 'staff_manage') || ['owner', 'admin'].includes(user.role)) && user.uid !== p.uid ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {p.active ? (
            <ReasonButton testID="sp-login-off" title="Left the business – turn off login" icon="🚪" prompt="Why? (e.g. left on 31 Oct)" confirm="Turn off login" size="sm"
              onDo={(why) => { const r = act(() => setLoginOn(user, p.uid, false, why), 'Login turned off – they cannot sign in on any device'); bump((x) => x + 1); return r; }} />
          ) : (
            <Btn testID="sp-login-on" title="Turn the login back on" icon="🔓" size="sm" variant="secondary" onPress={() => { act(() => setLoginOn(user, p.uid, true, ''), 'Login turned back on'); bump((x) => x + 1); }} />
          )}
        </View>
      ) : null}
      <Section title="Details" right={btn('edit', 'Edit', 'UserEdit', { id: p.id }, '✎')}>
        <Row label="Phone" value={p.phone || '–'} />
        <Row label="Shop" value={p.shopName || '–'} />
        <Row label="Uses the Time Clock" value={p.usesClock ? 'Yes' : 'No'} />
      </Section>

      <Section title="Personal details & emergency contact" right={btn('details', 'Edit', 'StaffDetails', { uid }, '✎')}>
        <Row label="Started" value={d(det.start_date || (P.pay && P.pay.startDate))} />
        <Row label="Date of birth" value={d(det.birth_date)} />
        <Row label="Email" value={det.email || '–'} />
        <Row label="Address" value={det.address || '–'} />
        <Row label="Emergency contact" value={det.emergency_name ? `${det.emergency_name}${det.emergency_relation ? ` (${det.emergency_relation})` : ''} ${det.emergency_phone || ''}` : '–'} />
        {det.notes ? <Hint>{det.notes}</Hint> : null}
      </Section>

      {P.pay !== undefined ? (
        <Section title="Pay" right={btn('pay', P.pay ? 'Edit' : 'Set up', 'PayProfile', { userUid: uid }, '💰')}>
          {P.pay ? (
            <>
              <Row label="Pay" value={P.pay.payType === 'salary' ? `${money(P.pay.weeklySalary)} a week` : `${money(P.pay.rate)} an hour`} />
              <Row label="Paid by" value={P.pay.method === 'bank' ? `Bank ${P.pay.bank}` : P.pay.method} />
              <Row label="FNPF number" value={P.pay.fnpfMember ? (P.pay.fnpfNo || 'missing') : 'Not a member'} />
              <Row label="TIN" value={P.pay.tin || 'missing'} />
              {P.ytd ? <Row label={`This year (${dateStr().slice(0, 4)})`} value={`Gross ${money(P.ytd.gross)} · PAYE ${money(P.ytd.paye)} · FNPF ${money(P.ytd.fnpf)}`} /> : null}
            </>
          ) : <Hint>No pay details yet.</Hint>}
          {(P.payslips || []).length ? <Text style={{ fontSize: 16, fontWeight: '700', color: C.text, marginTop: 8 }}>Latest payslips</Text> : null}
          {(P.payslips || []).map((s) => (
            <View key={s.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
              <Text style={{ flex: 1, color: C.text }}>Paid {d(s.pay_date)} · {d(s.week_start)} – {d(s.week_end)}</Text>
              <Text style={{ fontWeight: '700', color: C.text }}>{money(s.net)}</Text>
              {may('PayLine') ? <Btn testID={`sp-slip-${s.uid}`} title="Open" size="sm" variant="secondary" onPress={() => go('PayLine', { uid: s.uid })} /> : null}
            </View>
          ))}
        </Section>
      ) : null}

      {P.hours ? (
        <Section title="Hours" right={btn('ts', 'Timesheet', 'TimesheetPerson', { userUid: uid, date: dateStr() }, '🕒')}>
          {P.hours.thisWeek ? <Row label={`This week (from ${d(P.hours.thisWeek.from)})`} value={`${hm(P.hours.thisWeek.minutes)}${P.hours.thisWeek.open ? ' · on shift now' : ''}`} /> : null}
          {P.hours.lastWeek ? <Row label={`Last week (from ${d(P.hours.lastWeek.from)})`} value={`${hm(P.hours.lastWeek.minutes)} · ${P.hours.lastWeek.checked ? 'checked ✓' : 'not checked'}`} /> : null}
          <Text style={{ fontSize: 15, color: C.sub, marginTop: 6 }}>Usual week: {DAYS.map(([k, l]) => { const x = (P.hours.usual || {})[k]; return x && x.start ? `${l} ${x.start}–${x.end}` : null; }).filter(Boolean).join(' · ') || 'not set'}</Text>
          {btn('roster', 'Usual week', 'Roster', {}, '🗓️')}
        </Section>
      ) : null}

      {P.leave ? (
        <Section title="Leave" right={btn('leave', 'Leave', 'Leave', {}, '🌴')}>
          {!P.leave.balances.length ? <Hint>No leave set up for this person yet.</Hint> : null}
          {P.leave.balances.map((b) => <Row key={b.type} label={b.name} value={b.limited ? `${b.left} left of ${b.allowed} (taken ${b.taken}${b.waiting ? `, waiting ${b.waiting}` : ''})` : `taken ${b.taken}`} />)}
          {P.leave.upcoming.map((x) => <Text key={x.uid} style={{ color: C.text }}>• {x.type} {d(x.from_date)} – {d(x.to_date)} ({x.days} day{x.days === 1 ? '' : 's'}, {x.status === 'requested' ? 'waiting' : 'approved'})</Text>)}
        </Section>
      ) : null}

      {P.owes ? (
        <Section title="Owes the business" right={btn('owed', 'Details', 'OwedPerson', { uid }, '🤝')}>
          <Row label="Total owed" value={money(P.owes.total)} bold color={P.owes.total > 0 ? C.warn : undefined} />
          {P.owes.aronium ? <Row label="Staff credit (Aronium)" value={money(P.owes.aronium)} /> : null}
          {P.owes.advances ? <Row label="Advances" value={money(P.owes.advances)} /> : null}
          {P.owes.loans ? <Row label="Staff loans" value={money(P.owes.loans)} /> : null}
          {P.owes.charges ? <Row label="Shortages & charges" value={money(P.owes.charges)} /> : null}
          {btn('debts', 'Give an advance or loan', 'StaffDebts', {}, '➕')}
        </Section>
      ) : null}

      {P.contracts || P.onboarding ? (
        <Section title="Contract & onboarding" right={btn('onb', 'Onboarding', 'Onboarding', { userUid: uid }, '📋')}>
          {P.onboarding ? <Row label="Onboarding" value={P.onboarding.complete ? 'Done ✓' : `${P.onboarding.done} of ${P.onboarding.total} done`} /> : <Hint>No onboarding checklist.</Hint>}
          {P.onboarding && P.onboarding.probation ? <Row label="Probation" value={P.onboarding.probation} /> : null}
          {(P.contracts || []).map((c) => (
            <View key={c.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, color: C.text }}>Contract {d(c.startDate || c.created)} · {c.status}{c.employeeSigned && c.employerSigned ? ' · signed ✓' : ''}</Text>
              {btn(`contract-${c.uid}`, 'Open', 'Contract', { uid: c.uid })}
            </View>
          ))}
        </Section>
      ) : null}

      <Section title="Time Clock face">
        <Row label="Time Clock" value={p.face ? `Face enrolled ${d(p.faceAt)}` : 'Face not enrolled yet'} />
        {btn('face', p.face ? 'Enrol again' : 'Enrol face', 'FaceEnrol', { userUid: uid }, '📷')}
        {p.face && can(user, 'face_enrol') ? (
          <Btn testID="sp-face-remove" title="Remove face" size="sm" variant="secondary" onPress={async () => {
            if (await ui.confirm({ title: 'Remove face?', message: `${p.name} will need to be enrolled again for the face check.`, confirmText: 'Remove', tone: 'danger' })) {
              try { removeFace(user, uid); ui.toast('Face removed'); bump((x) => x + 1); } catch (e) { ui.error(e); }
            }
          }} />
        ) : null}
      </Section>

      <PermissionsSummary person={p} />
      {P.history.length ? (
        <Section title="Latest changes">
          {P.history.map((h, i) => <Text key={i} style={{ color: C.sub, fontSize: 14 }}>{d(h.at)} · {h.user_name || 'app'} · {h.action}</Text>)}
        </Section>
      ) : null}
    </Screen>
  );
}
function safeOn(m) { try { return moduleOn(m); } catch (e) { return true; } }

export function StaffDetailsScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const uid = params.uid;
  const u = db().get('SELECT name FROM users WHERE uid = ?', [uid]);
  const [f, setF] = useState(() => ({ ...getDetails(uid) }));
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const mayEdit = can(user, 'staff_manage');
  const save = () => { try { saveDetails(user, uid, f); ui.toast('Saved'); nav.pop(); } catch (e) { ui.error(e); } };
  if (!u) return <Screen title="Personal details"><Banner tone="danger" message="Person not found." /></Screen>;
  return (
    <Screen title="Personal details" subtitle={u.name} footer={mayEdit ? <Btn testID="sd-save" title="Save" icon="💾" variant="success" onPress={save} /> : null}>
      <DateField testID="sd-start" label="Started work" value={f.start_date || ''} onChange={set('start_date')} optional farDays={20000} quick={false} />
      <DateField testID="sd-birth" label="Date of birth" value={f.birth_date || ''} onChange={set('birth_date')} optional farDays={40000} quick={false} />
      <Field testID="sd-email" label="Email" value={f.email || ''} onChangeText={set('email')} keyboardType="email-address" />
      <Field testID="sd-address" label="Home address" value={f.address || ''} onChangeText={set('address')} multiline />
      <Section title="Emergency contact">
        <Field testID="sd-em-name" label="Name" value={f.emergency_name || ''} onChangeText={set('emergency_name')} />
        <Field testID="sd-em-rel" label="Relation (e.g. wife, father)" value={f.emergency_relation || ''} onChangeText={set('emergency_relation')} />
        <Field testID="sd-em-phone" label="Phone" value={f.emergency_phone || ''} onChangeText={set('emergency_phone')} keyboardType="phone-pad" />
      </Section>
      <Field testID="sd-notes" label="Notes" value={f.notes || ''} onChangeText={set('notes')} multiline />
    </Screen>
  );
}
