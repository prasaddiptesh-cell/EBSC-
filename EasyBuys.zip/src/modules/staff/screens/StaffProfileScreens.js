// Staff profile: one page per person with everything about them, and a link to change each part.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Section, Row, RoleBadge, Badge, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ReasonButton, useAct } from '../../../ui/kit.js';
import { DateField } from '../../../ui/dateField.js';
import { dateStr } from '../../../services/core.js';
import { can } from '../../../services/access.js';
import { fmtDate } from '../../../services/dates.js';
import { db } from '../../../db/connection.js';
import { moduleOn } from '../../admin/service.js';
import { allScreens } from '../../registry.js';
import { staffProfile, getDetails, saveDetails, setLoginOn } from '../profile.js';
import { profileView, payslipFnpf } from '../profileView.js';
import { removeFace } from '../../timeclock/service.js';
import { PermissionsSummary } from '../../home/V1Screens.js'; // 1.0.0 each person's permissions (stream A)

const d = (x) => (x ? fmtDate(String(x).slice(0, 10)) : '–');

function uidFrom(params) {
  if (params.uid) return params.uid;
  if (params.id) { const r = db().get('SELECT uid FROM users WHERE id = ?', [params.id]); return r ? r.uid : null; }
  return null;
}

export function StaffProfileScreen({ params = {} }) {
  const { nav, user, screens: ctxScreens } = useApp();
  const act = useAct();
  const ui = useUI();
  const [, bump] = useState(0);
  const uid = uidFrom(params) || (params.self && user ? user.uid : null);
  const screens = ctxScreens || allScreens();
  const may = (name) => { const s = screens[name]; return !!s && (!s.can || s.can(user)); };
  const go = (name, p) => nav.push(name, p || {});
  const self = !!user && user.uid === uid;
  const today = dateStr();
  let P = null; let err = null;
  // Your own profile shows your own pay; for anyone else the pay part needs a payroll permission.
  try { P = staffProfile(uid, { on: (m) => safeOn(m), viewer: self ? null : user, today }); } catch (e) { err = e.message; }
  if (!P) return <Screen title="Staff"><Banner tone="danger" message={err || 'Person not found.'} /></Screen>;
  const V = profileView(P, { viewer: user, can, may, fnpf: payslipFnpf(uid), today });
  if (!V.allowed) return <Screen title="Staff"><Banner tone="danger" message="You can only see your own profile." /></Screen>;
  const p = P.person;
  const linkBtn = (l) => <Btn key={l.id} testID={`sp-${l.id}`} title={l.title} icon={l.icon} size="sm" variant="secondary" onPress={() => go(l.screen, l.params)} />;
  return (
    <Screen title={self ? `${p.name} (you)` : p.name} subtitle={[p.employeeNo, p.shopName, P.pay && P.pay.jobTitle].filter(Boolean).join(' · ') || 'Staff profile'}>
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
        <RoleBadge role={p.role} />
        {p.active ? null : <Badge text="Left / inactive" color={C.sub} />}
        {p.face ? <Badge text="Face ✓" color={C.success} /> : null}
        {p.login ? <Badge text="Password login" color={C.sub} /> : null}
      </View>
      {V.summary.length ? (
        <View testID="sp-summary" style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {V.summary.map((s) => (
            <View key={s.key} style={{ flexGrow: 1, minWidth: 120, minHeight: 56, backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.border, paddingHorizontal: 12, paddingVertical: 8, justifyContent: 'center' }}>
              <Text style={{ fontSize: 13, color: C.sub }}>{s.label}</Text>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{s.value}</Text>
            </View>
          ))}
        </View>
      ) : null}
      {V.warnings.length ? (
        <Card tone="warn">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>To sort out ({V.warnings.length})</Text>
          {V.warnings.map((w) => <Text testID={`sp-warn-${w.key}`} key={w.key} style={{ color: C.text, fontSize: 15 }}>• {w.text}</Text>)}
        </Card>
      ) : (can(user, 'staff_manage') ? <Banner tone="success" message="Everything is in place for this person." /> : null)}

      {(can(user, 'staff_manage') || ['owner', 'admin'].includes(user.role)) && user.uid !== p.uid ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {p.active ? (
            <ReasonButton testID="sp-login-off" title="Left the business – turn off login" icon="🚪" prompt="Why? (e.g. left on 31 Oct)" confirm="Turn off login" size="sm"
              onDo={(why) => { const r = act(() => setLoginOn(user, p.uid, false, why), 'Login turned off – they cannot sign in on any device'); bump((x) => x + 1); return r; }} />
          ) : (
            <Btn testID="sp-login-on" title="Turn the login back on" icon="🔓" size="sm" variant="secondary" onPress={() => { act(() => setLoginOn(user, p.uid, true, ''), 'Login turned back on'); bump((x) => x + 1); }} />
          )}
        </View>
      ) : null}

      {V.sections.map((s) => (
        <Card key={s.key} style={{ gap: 6 }}>
          <View testID={`sp-section-${s.key}`}>
            <Section title={s.title}>
              {s.rows.map((r, i) => (
                <View key={`${s.key}-${i}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: r.link ? 52 : undefined }}>
                  <View style={{ flex: 1 }}><Row label={r.label} value={r.value} bold={r.bold} color={r.warn ? C.warn : undefined} /></View>
                  {r.link ? linkBtn(r.link) : null}
                </View>
              ))}
              {s.notes.map((n, i) => <Hint key={`${s.key}-n${i}`}>{n}</Hint>)}
              {s.links.length ? <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>{s.links.map(linkBtn)}</View> : null}
            </Section>
          </View>
        </Card>
      ))}

      {!self || can(user, 'face_enrol') ? (
        <Card style={{ gap: 6 }}>
          <Section title="Time Clock face">
            <Row label="Time Clock" value={p.face ? `Face enrolled ${d(p.faceAt)}` : 'Face not enrolled yet'} />
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              {may('FaceEnrol') ? <Btn testID="sp-face" title={p.face ? 'Enrol again' : 'Enrol face'} icon="📷" size="sm" variant="secondary" onPress={() => go('FaceEnrol', { userUid: uid })} /> : null}
              {p.face && can(user, 'face_enrol') ? (
                <Btn testID="sp-face-remove" title="Remove face" size="sm" variant="secondary" onPress={async () => {
                  if (await ui.confirm({ title: 'Remove face?', message: `${p.name} will need to be enrolled again for the face check.`, confirmText: 'Remove', tone: 'danger' })) {
                    try { removeFace(user, uid); ui.toast('Face removed'); bump((x) => x + 1); } catch (e) { ui.error(e); }
                  }
                }} />
              ) : null}
            </View>
          </Section>
        </Card>
      ) : null}

      <PermissionsSummary person={p} />
      {P.history.length && can(user, 'staff_manage') ? (
        <Section title="Latest changes">
          {P.history.map((h, i) => <Text key={i} style={{ color: C.sub, fontSize: 14 }}>{d(h.at)} · {h.user_name || 'app'} · {h.action}</Text>)}
        </Section>
      ) : null}
    </Screen>
  );
}
// Release 03: every person's own profile (any logged-in person; shows only their own).
export function MyStaffProfileScreen() {
  const { user } = useApp();
  return <StaffProfileScreen params={{ uid: user ? user.uid : null }} />;
}
function safeOn(m) { try { return moduleOn(m); } catch (e) { return true; } }

export function StaffDetailsScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const uid = params.uid;
  const u = db().get('SELECT name FROM users WHERE uid = ?', [uid]);
  const [f, setF] = useState(() => ({ ...getDetails(uid) }));
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: v }));
  const mayEdit = can(user, 'staff_manage');
  const save = () => { try { saveDetails(user, uid, f); ui.toast('Saved'); nav.pop(); } catch (e) { ui.error(e); } };
  if (!u) return <Screen title="Personal details"><Banner tone="danger" message="Person not found." /></Screen>;
  return (
    <Screen title="Personal details" subtitle={u.name} footer={mayEdit ? <Btn testID="sd-save" title="Save" icon="💾" variant="success" onPress={save} /> : null}>
      <DateField testID="sd-start" label="Started work" value={f.start_date || ''} onChange={set('start_date')} optional farDays={20000} quick={false} />
      <DateField testID="sd-birth" label="Date of birth" value={f.birth_date || ''} onChange={set('birth_date')} optional farDays={40000} quick={false} />
      <Field testID="sd-email" label="Email" value={f.email || ''} onChangeText={set('email')} keyboardType="email-address" />
      <Field testID="sd-address" label="Home address" value={f.address || ''} onChangeText={set('address')} multiline />
      <Section title="Emergency contact">
        <Field testID="sd-em-name" label="Name" value={f.emergency_name || ''} onChangeText={set('emergency_name')} />
        <Field testID="sd-em-rel" label="Relation (e.g. wife, father)" value={f.emergency_relation || ''} onChangeText={set('emergency_relation')} />
        <Field testID="sd-em-phone" label="Phone" value={f.emergency_phone || ''} onChangeText={set('emergency_phone')} keyboardType="phone-pad" />
      </Section>
      <Field testID="sd-notes" label="Notes" value={f.notes || ''} onChangeText={set('notes')} multiline />
    </Screen>
  );
}
