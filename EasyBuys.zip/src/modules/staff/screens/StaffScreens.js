// Staff: one list of people for the whole business (shops, bakery, office).
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Field, Chips, Btn, Label, RoleBadge, Badge, Banner, Select, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { db } from '../../../db/connection.js';
import { listUsers, getUser, saveUser } from '../../../services/catalog.js';
import { ROLES, ROLE_LABEL, ROLE_HELP, can, actsAsOwner, hasOwner } from '../../../services/access.js';
import { removeFace } from '../../timeclock/service.js';

export function StaffListScreen() {
  const { nav, user } = useApp();
  const [shop, setShop] = useRemembered('shop', 'ALL');
  const [q, setQ] = useRemembered('q', '');
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const all = listUsers();
  const people = all.filter((u) => (shop === 'ALL' || u.shop_code === shop) && (!q || `${u.name} ${u.employee_no || ''}`.toLowerCase().includes(q.toLowerCase())));
  const mayEdit = can(user, 'staff_manage');
  return (
    <Screen title="Staff" subtitle={`${all.filter((u) => u.active).length} active`}
      footer={mayEdit ? <Btn testID="add-user" title="Add staff member" icon="➕" onPress={() => nav.push('UserEdit', {})} /> : null}>
      {!hasOwner() && actsAsOwner(user) ? (
        <Banner tone="warn" title="No Owner set yet" message="Open your own record (or your brother's) and set the role to Owner. Until then, Admins act as Owners." />
      ) : null}
      <Field testID="staff-search" label="Search name or employee number" value={q} onChangeText={setQ} />
      <Chips value={shop} onChange={setShop} testIDPrefix="staff-shop"
        options={[{ value: 'ALL', label: 'All' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      {people.map((u) => (
        <Pressable key={u.id} testID={`user-${u.name}`} onPress={() => nav.push('UserEdit', { id: u.id })}
          style={({ pressed }) => ({ backgroundColor: u.active ? C.card : '#EEE9E1', borderRadius: 16, padding: 14, borderWidth: 1, borderColor: C.border, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1, gap: 10 })}>
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{u.name}</Text>
            <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
              <RoleBadge role={u.role} />
              {u.shop_code ? <Badge text={u.shop_code} color={C.sub} /> : null}
              {u.employee_no ? <Badge text={u.employee_no} color={C.sub} /> : null}
              {!u.pin ? <Badge text="No PIN" color={C.danger} /> : null}
              {u.face ? <Badge text="Face ✓" color={C.success} /> : null}
              {!u.active ? <Badge text="Left / inactive" color={C.sub} /> : null}
            </View>
          </View>
          <Text style={{ fontSize: 20, color: C.sub }}>›</Text>
        </Pressable>
      ))}
    </Screen>
  );
}

export function UserEditScreen({ params }) {
  const { nav, user: me } = useApp();
  const ui = useUI();
  const [u, setU] = useState(() => (params.id ? getUser(params.id) : null));
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const [f, setF] = useState(() => ({
    name: u ? u.name : '', pin: u ? u.pin : '', role: u ? u.role : 'staff', active: u ? !!u.active : true,
    username: u && u.username ? u.username : '', password: '', employeeNo: u ? u.employee_no || '' : '',
    shopCode: u ? u.shop_code || '' : '', phone: u ? u.phone || '' : '', usesClock: u ? !!u.uses_clock : true,
  }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const mayEdit = can(me, 'staff_manage') || (u && u.id === me.id);
  const roles = ROLES.filter((r) => actsAsOwner(me) || (r !== 'owner' && !(r === 'admin' && me.role !== 'admin')));

  const save = () => {
    try {
      const saved = saveUser({ id: u ? u.id : undefined, ...f }, me);
      ui.toast(u ? `${saved.name} updated` : `${saved.name} added`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={u ? u.name : 'New staff member'}
      footer={mayEdit ? <Btn testID="save-user" title="Save" icon="💾" variant="success" onPress={save} /> : null}>
      {u && u.id === me.id ? <Banner tone="info" message="You are editing your own record." /> : null}
      <Card style={{ gap: 14 }}>
        <Field testID="user-name" label="Full name" value={f.name} onChangeText={set('name')} placeholder="e.g. Mere Tuilau" />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flex: 1, minWidth: 150 }}><Field testID="user-empno" label="Employee number" value={f.employeeNo} onChangeText={set('employeeNo')} placeholder="e.g. EB0012" /></View>
          <View style={{ flex: 1, minWidth: 150 }}><Field testID="user-phone" label="Phone" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" /></View>
        </View>
        <Select testID="user-shop" label="Shop" value={f.shopCode} onChange={set('shopCode')} options={shops.map((s) => ({ value: s.code, label: s.name }))} />
        <Field testID="user-pin" label="PIN (4-6 digits, must be unique) – used to log in and clock in" value={f.pin} onChangeText={(t) => set('pin')(t.replace(/[^0-9]/g, ''))} keyboardType="number-pad" maxLength={6} />
        <View>
          <Label>Role</Label>
          <Chips value={f.role} onChange={set('role')} testIDPrefix="role" options={roles.map((r) => ({ value: r, label: ROLE_LABEL[r] }))} />
          <Text style={{ fontSize: 15, color: C.sub, marginTop: 8 }}>{ROLE_HELP[f.role]}</Text>
        </View>
        <View>
          <Label>Time Clock</Label>
          <Chips value={f.usesClock} onChange={set('usesClock')} testIDPrefix="uses-clock" options={[{ value: true, label: 'Clocks in and out' }, { value: false, label: 'Does not clock' }]} />
        </View>
        <Field testID="user-username" label="Username (optional – to log in with a password)" value={f.username} onChangeText={(t) => set('username')(t.replace(/\s/g, '').toLowerCase())} />
        {f.username ? <Field testID="user-password" label={u && u.password_hash && u.username === f.username ? 'New password (leave empty to keep it)' : 'Password (at least 6 characters)'} value={f.password} onChangeText={set('password')} secure /> : null}
        <View>
          <Label>Status</Label>
          <Chips value={f.active} onChange={set('active')} testIDPrefix="active" options={[{ value: true, label: 'Active' }, { value: false, label: 'Left / inactive' }]} />
        </View>
      </Card>
      {u && can(me, 'face_enrol') ? (
        <Card>
          <Label>Face check</Label>
          <Text style={{ fontSize: 16, color: u.face ? C.success : C.sub, marginBottom: 10 }}>
            {u.face ? `Face enrolled ${u.face_at ? u.face_at.slice(0, 10) : ''}${u.face_by ? ` by ${u.face_by}` : ''}` : 'Face not enrolled yet.'}
          </Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn testID="enrol-face" title={u.face ? 'Enrol again' : 'Enrol face'} icon="📷" size="md" style={{ flex: 1 }} onPress={() => nav.push('FaceEnrol', { userUid: u.uid })} />
            {u.face ? <Btn title="Remove face" size="md" variant="secondary" style={{ flex: 1 }} onPress={async () => {
              if (await ui.confirm({ title: 'Remove face?', message: `${u.name} will need to be enrolled again for the face check.`, confirmText: 'Remove', tone: 'danger' })) {
                removeFace(me, u.uid); setU(getUser(u.id)); ui.toast('Face removed');
              }
            }} /> : null}
          </View>
        </Card>
      ) : null}
    </Screen>
  );
}
