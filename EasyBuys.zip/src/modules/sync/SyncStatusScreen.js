// Sync status for every section, with Force sync.
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Btn, Banner, Row, Section, Badge, useApp, useUI } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { db } from '../../db/connection.js';
import { getSettings, getSetting } from '../../services/core.js';
import { pendingBySection } from '../../services/records.js';
import { getSyncState, onSyncState } from '../../services/syncBus.js';
import { SyncNowPanel } from '../../ui/chrome.js';
import { can } from '../../services/access.js';

const KIND_LABEL = { report: 'Bakery shift reports', po: 'Purchase orders', photo: 'Photos', backup: 'Daily backup' };

export default function SyncStatusScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const [st, setSt] = useState(getSyncState());
  const [, tick] = useState(0);
  useEffect(() => onSyncState((s) => { setSt(s); tick((n) => n + 1); }), []);
  const linked = !!getSettings().cloudUrl;
  const per = pendingBySection();
  const outbox = db().all('SELECT kind, count(*) AS c, max(last_error) AS err FROM outbox WHERE sent_at IS NULL AND attempts < 3 GROUP BY kind');
  const S = require('../../services/stock.js');
  const stuck = S.stuckOutbox();
  const boss = !!user && (['owner', 'admin'].includes(user.role) || user.realRole === 'owner');
  let rejected = [];
  try { rejected = JSON.parse(getSetting('last_rejected', '[]')) || []; } catch (e) { rejected = []; }
  const total = Object.values(per).reduce((a, b) => a + b, 0) + outbox.reduce((a, o) => a + o.c, 0);
  return (
    <Screen title="Sync status" subtitle={linked ? 'Tablet ⇄ Google ⇄ phones and main software' : 'Not linked to the cloud yet'}>
      <SyncNowPanel />
      {!linked ? (
        <Banner tone="warn" title="Everything is being saved on this device" message="Link it to the Google cloud to share with the phones and the main software (Admin › Online & email)." />
      ) : st.error ? (
        <Banner tone={/cloud is busy|slow or no connection/i.test(st.error) ? 'warn' : 'danger'} title={/slow or no connection/i.test(st.error) ? 'Slow or no connection – trying again in a minute' : /cloud is busy/i.test(st.error) ? 'The cloud is busy – trying again' : /network|fetch|timed|abort/i.test(st.error) ? 'No internet right now' : 'Sync problem'} message={`${st.error}\nNothing is lost – it will keep trying every minute.`} />
      ) : total ? (
        <Banner tone="warn" title={`${total} waiting to send`} message="They will send by themselves, or tap Sync now." />
      ) : <Banner tone="success" title="All synced" message={st.lastOk ? `Last successful sync ${st.lastOk}` : 'Nothing waiting.'} />}
      {(() => {
        // 1.0.0 build 17: what the last sync that moved something sent and received, by part of the app
        let w = null;
        try { w = JSON.parse(getSetting('last_sync_what', '') || 'null'); } catch (e) { w = null; }
        if (!w) return null;
        const line = (o) => Object.entries(o || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${k} ${n}`).join(' · ');
        return (
          <Card testID="sync-what">
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`Last sync with changes – ${String(w.at || '').slice(11, 16)}`}</Text>
            <Text testID="sync-what-sent" style={{ fontSize: 15, color: C.text }}>{`Sent: ${line(w.sent) || 'nothing'}`}</Text>
            <Text testID="sync-what-got" style={{ fontSize: 15, color: C.text }}>{`Received: ${line(w.got) || 'nothing'}`}</Text>
          </Card>
        );
      })()}
      {stuck.length ? (
        <Card testID="sync-stuck">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${stuck.length} file${stuck.length === 1 ? '' : 's'} or email${stuck.length === 1 ? '' : 's'} keep failing`}</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>Your records sync normally – only these are held back. They are tried again by themselves.</Text>
          {stuck.map((o) => (
            <View key={o.id} style={{ paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#F0EBE3', gap: 4 }}>
              <Text style={{ fontSize: 15, color: C.text }}>{`${KIND_LABEL[o.kind] || o.kind} · from ${String(o.created_at || '').slice(0, 16)} · ${o.attempts} tries`}</Text>
              {o.last_error ? <Text style={{ fontSize: 14, color: C.danger }}>{String(o.last_error).slice(0, 200)}</Text> : null}
              {boss ? <Btn testID={`sync-drop-${o.id}`} title="Stop trying this one" size="sm" variant="ghost" onPress={() => { try { S.dropOutbox(o.id); tick((n) => n + 1); } catch (e) { /* shown next time */ } }} /> : null}
            </View>
          ))}
        </Card>
      ) : null}
      <Card>
        <Row label="Last successful sync" value={getSetting('last_sync_ok_at', '') || 'never'} />
        <Row label="Last attempt" value={getSetting('last_sync_at', '') || 'never'} />
        <Row label="Sent last time" value={String(st.sent || 0)} />
        <Row label="Received last time" value={String(st.received || 0)} />
      </Card>
      <Section title="Each section">
        {Object.entries(per).map(([sec, n]) => (
          <View key={sec} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{sec}</Text>
            {n ? <Badge text={`${n} waiting`} color={C.warn} /> : <Badge text="✓ synced" color={C.success} />}
          </View>
        ))}
        {outbox.map((o) => (
          <View key={o.kind} style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{KIND_LABEL[o.kind] || o.kind}</Text>
              <Badge text={`${o.c} waiting`} color={C.warn} />
            </View>
            {o.err ? <Text style={{ fontSize: 13, color: C.danger }}>{o.err}</Text> : null}
          </View>
        ))}
      </Section>
      {rejected.length ? (
        <Section title="Not accepted by the cloud (newer change elsewhere)">
          {rejected.map((r, i) => <Text key={i} style={{ fontSize: 14, color: C.sub }}>{r.t} · {r.k} · {r.why || ''}</Text>)}
        </Section>
      ) : null}
      {boss && linked ? (
        <Card>
          <Text style={{ fontSize: 15, color: C.text }}>Bank accounts or cheque books on this device but not on the website or another phone? Send them again – nothing is lost or doubled.</Text>
          <Btn testID="sync-resend-bank" title="Send this device's bank accounts & cheque books again" icon="📤" size="md" variant="info"
            onPress={() => { try { const r = require('../bank/links05.js').resendBankRecords(user); setSt(getSyncState()); tick((n) => n + 1); ui.toast(`${r.bank_accounts} account(s), ${r.cheque_books} cheque book(s) and ${r.cheques} cheque(s) will be sent with the next sync`); } catch (e) { ui.error(e); } }} />
        </Card>
      ) : null}
      {can(user, 'settings') ? <Btn title="Online & email settings" size="md" variant="secondary" onPress={() => nav.push('Settings')} /> : null}
    </Screen>
  );
}
