// Sync status for every section, with Force sync.
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../ui/scale.js';
import { Screen, Card, Btn, Banner, Row, Section, Badge, useApp } from '../../ui/components.js';
import { C } from '../../ui/theme.js';
import { db } from '../../db/connection.js';
import { getSettings, getSetting } from '../../services/core.js';
import { pendingBySection } from '../../services/records.js';
import { getSyncState, onSyncState } from '../../services/syncBus.js';
import { SyncNowPanel } from '../../ui/chrome.js';
import { can } from '../../services/access.js';

const KIND_LABEL = { report: 'Bakery shift reports', po: 'Purchase orders', photo: 'Photos', backup: 'Daily backup' };

export default function SyncStatusScreen() {
  const { nav, user } = useApp();
  const [st, setSt] = useState(getSyncState());
  const [, tick] = useState(0);
  useEffect(() => onSyncState((s) => { setSt(s); tick((n) => n + 1); }), []);
  const linked = !!getSettings().cloudUrl;
  const per = pendingBySection();
  const outbox = db().all('SELECT kind, count(*) AS c, max(last_error) AS err FROM outbox WHERE sent_at IS NULL GROUP BY kind');
  let rejected = [];
  try { rejected = JSON.parse(getSetting('last_rejected', '[]')) || []; } catch (e) { rejected = []; }
  const total = Object.values(per).reduce((a, b) => a + b, 0) + outbox.reduce((a, o) => a + o.c, 0);
  return (
    <Screen title="Sync status" subtitle={linked ? 'Tablet ⇄ Google ⇄ phones and main software' : 'Not linked to the cloud yet'}>
      <SyncNowPanel />
      {!linked ? (
        <Banner tone="warn" title="Everything is being saved on this device" message="Link it to the Google cloud to share with the phones and the main software (Admin › Online & email)." />
      ) : st.error ? (
        <Banner tone={/cloud is busy|slow or no connection/i.test(st.error) ? 'warn' : 'danger'} title={/slow or no connection/i.test(st.error) ? 'Slow or no connection – trying again in a minute' : /cloud is busy/i.test(st.error) ? 'The cloud is busy – trying again' : /network|fetch|timed|abort/i.test(st.error) ? 'No internet right now' : 'Sync problem'} message={`${st.error}\nNothing is lost – it will keep trying every minute.`} />
      ) : total ? (
        <Banner tone="warn" title={`${total} waiting to send`} message="They will send by themselves, or tap Sync now." />
      ) : <Banner tone="success" title="All synced" message={st.lastOk ? `Last successful sync ${st.lastOk}` : 'Nothing waiting.'} />}
      <Card>
        <Row label="Last successful sync" value={getSetting('last_sync_ok_at', '') || 'never'} />
        <Row label="Last attempt" value={getSetting('last_sync_at', '') || 'never'} />
        <Row label="Sent last time" value={String(st.sent || 0)} />
        <Row label="Received last time" value={String(st.received || 0)} />
      </Card>
      <Section title="Each section">
        {Object.entries(per).map(([sec, n]) => (
          <View key={sec} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{sec}</Text>
            {n ? <Badge text={`${n} waiting`} color={C.warn} /> : <Badge text="✓ synced" color={C.success} />}
          </View>
        ))}
        {outbox.map((o) => (
          <View key={o.kind} style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ flex: 1, fontSize: 17, color: C.text }}>{KIND_LABEL[o.kind] || o.kind}</Text>
              <Badge text={`${o.c} waiting`} color={C.warn} />
            </View>
            {o.err ? <Text style={{ fontSize: 13, color: C.danger }}>{o.err}</Text> : null}
          </View>
        ))}
      </Section>
      {rejected.length ? (
        <Section title="Not accepted by the cloud (newer change elsewhere)">
          {rejected.map((r, i) => <Text key={i} style={{ fontSize: 14, color: C.sub }}>{r.t} · {r.k} · {r.why || ''}</Text>)}
        </Section>
      ) : null}
      {can(user, 'settings') ? <Btn title="Online & email settings" size="md" variant="secondary" onPress={() => nav.push('Settings')} /> : null}
    </Screen>
  );
}
