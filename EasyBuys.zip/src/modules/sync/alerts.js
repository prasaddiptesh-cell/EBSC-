// Warning for Home when sync has been failing or items have waited too long (everyone sees it; anyone may press Sync now).
// v3.9: also the things two devices can do to each other offline (paid twice, same cheque, same till count, same
// pay week, same order received twice) – urgent for the owner, admin and managers – and records that could not be saved.
import { currentSyncLight } from '../../services/syncInfo.js';
import { syncConflicts } from '../../services/conflicts.js';
import { can, actsAsOwner } from '../../services/access.js';
import { failedSyncRecords } from '../../services/records.js';

export function alerts(user) {
  const out = [];
  // v3.9.3 a device clock that is wrong (checked against Google's clock at each sync)
  try {
    const { getSetting } = require('../../services/core.js');
    const sk = Number(getSetting('clock_skew_min', '0')) || 0;
    if (Math.abs(sk) >= 5) out.push({ id: 'clock-skew', level: Math.abs(sk) >= 60 ? 'urgent' : 'warning', text: `This device's clock is ${Math.abs(sk) >= 120 ? `${Math.round(Math.abs(sk) / 60)} hours` : `${Math.abs(sk)} minutes`} ${sk > 0 ? 'fast' : 'slow'}`, sub: 'Set the date and time to automatic: Android Settings › General management › Date and time › Automatic date and time. A wrong clock puts wrong times on records and can refuse entries.', nav: null });
  } catch (e) { /* not known yet */ }
  // v3.9.2 opened by the owner / admin while the cloud still has it blocked or paused
  try {
    const C = require('../devices/control.js');
    const o = C.lockOverride();
    const { getSetting } = require('../../services/core.js');
    if (o && (getSetting('device_blocked', '0') === '1' || getSetting('device_lock', ''))) out.push({ id: 'device-override', level: 'urgent', text: `This device is blocked in the Easy Buys cloud – opened by ${o.by}; nothing syncs`, sub: 'Allow it again: Admin › Devices on another device (Allow again), or the Google Sheet › Devices tab › status "active". Then press Sync now.', nav: { screen: 'SyncStatus', params: {} } });
  } catch (e) { /* devices module off */ }
  let l = null;
  try { l = currentSyncLight(); } catch (e) { l = null; }
  if (l && l.color === 'red' && !l.running) out.push({ id: 'sync-stuck', level: 'warning', text: l.text.replace(/^✗\s*/, 'Sync: '), sub: 'Tap to open Sync and press Sync now.', nav: { screen: 'SyncStatus', params: {} } });
  const boss = !!user && (actsAsOwner(user) || ['owner', 'admin', 'manager'].includes(user.role) || can(user, 'payments_make'));
  if (boss) {
    for (const c of syncConflicts()) out.push({ id: `conflict-${c.kind}-${c.text.slice(0, 40).replace(/\W+/g, '')}`, level: 'urgent', area: 'Sync', text: c.text, sub: c.sub, nav: c.nav });
    const failed = failedSyncRecords();
    if (failed.length && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role))) out.push({ id: `sync-failed-${failed.length}`, level: 'warning', text: `${failed.length} record(s) from other devices could not be saved here`, sub: 'Open Sync – send the problem report to support.', nav: { screen: 'SyncStatus', params: {} } });
  }
  return out;
}
