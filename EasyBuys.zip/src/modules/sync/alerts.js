// Warning for Home when sync has been failing or items have waited too long (everyone sees it; anyone may press Sync now).
import { currentSyncLight } from '../../services/syncInfo.js';

export function alerts() {
  const l = currentSyncLight();
  if (l.color !== 'red' || l.running) return [];
  return [{ id: 'sync-stuck', level: 'warning', text: l.text.replace(/^✗\s*/, 'Sync: '), sub: 'Tap to open Sync and press Sync now.', nav: { screen: 'SyncStatus', params: {} } }];
}
