// Warning for Home when sync has been failing or items have waited too long (everyone sees it; anyone may press Sync now).
// v3.9: also the things two devices can do to each other offline (paid twice, same cheque, same till count, same
// pay week, same order received twice) – urgent for the owner, admin and managers – and records that could not be saved.
import { currentSyncLight } from '../../services/syncInfo.js';
import { syncConflicts } from '../../services/conflicts.js';
import { can, actsAsOwner } from '../../services/access.js';
import { failedSyncRecords } from '../../services/records.js';

export function alerts(user) {
  const out = [];
  let l = null;
  try { l = currentSyncLight(); } catch (e) { l = null; }
  if (l && l.color === 'red' && !l.running) out.push({ id: 'sync-stuck', level: 'warning', text: l.text.replace(/^✗\s*/, 'Sync: '), sub: 'Tap to open Sync and press Sync now.', nav: { screen: 'SyncStatus', params: {} } });
  const boss = !!user && (actsAsOwner(user) || ['owner', 'admin', 'manager'].includes(user.role) || can(user, 'payments_make'));
  if (boss) {
    for (const c of syncConflicts()) out.push({ id: `conflict-${c.kind}-${c.text.slice(0, 40).replace(/\W+/g, '')}`, level: 'urgent', area: 'Sync', text: c.text, sub: c.sub, nav: c.nav });
    const failed = failedSyncRecords();
    if (failed.length && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role))) out.push({ id: `sync-failed-${failed.length}`, level: 'warning', text: `${failed.length} record(s) from other devices could not be saved here`, sub: 'Open Sync – send the problem report to support.', nav: { screen: 'SyncStatus', params: {} } });
  }
  return out;
}
