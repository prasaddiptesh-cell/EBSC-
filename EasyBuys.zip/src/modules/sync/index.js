// Sync module: status of every section and Force sync (open to everyone who is logged in).
import SyncStatusScreen from './SyncStatusScreen.js';
import { alerts } from './alerts.js';

export default {
  id: 'sync',
  title: 'Sync',
  icon: '⟳',
  screens: { SyncStatus: { component: SyncStatusScreen, can: (u) => !!u } },
  alerts,
  reports: [],
};
