// Warnings for Home: till counts waiting for approval, cashiers short again and again, and (v3.5) Aronium End of day
// differences, End of day without a till balance, shifts not balanced, shortages waiting for the cashier.
import { can } from '../../services/access.js';
import { money, clock } from '../../services/core.js';
import { tillAlerts } from './service.js';
import { undecidedShortages } from './shifts.js';

const n = (k, one, many) => `${k} ${k === 1 ? one : many}`;
// Till PCs whose link has gone quiet: only checked 8 am – 9 pm, and only for tills that have sent something before.
export function quietTills(now = clock.now()) {
  const h = now.getHours();
  if (h < 8 || h >= 21) return [];
  const { linkStatus } = require('../aronium/link.js');
  return (linkStatus().tills || []).filter((t) => {
    if (!t.lastSeen) return false;
    const s = String(t.lastSeen);
    const at = new Date(/Z$/.test(s) ? s : `${s.replace(' ', 'T').slice(0, 19)}Z`).getTime();
    return Number.isFinite(at) && now.getTime() - at > 3 * 3600000;
  });
}
export function alerts(user) {
  const seeAll = can(user, 'till_approve');
  if (!seeAll && !can(user, 'till_count')) {
    // Anyone: their own till shortage waiting for them to agree.
    let mine = [];
    try { mine = undecidedShortages({ userUid: user.uid }); } catch (e) { mine = []; }
    return mine.length ? [{ id: 'till-shortages', level: 'warning', text: `${n(mine.length, 'till shortage waits', 'till shortages wait')} for you to agree or not`, nav: { screen: 'TillShortages', params: {} } }] : [];
  }
  const t = tillAlerts();
  const out = [];
  // 1.0.0 the cigarette tally at each shift change, and the cigarette fund
  try { out.push(...require('./cigTally.js').cigAlerts(user)); } catch (e) { /* never stops Home */ }
  if (seeAll) {
    if (t.eodNoTill && t.eodNoTill.length) out.push({ id: 'till-eod-missing', level: 'urgent', text: `Till balance missing: ${n(t.eodNoTill.length, 'Aronium End of day has', 'Aronium End of days have')} no till balance`, sub: t.eodNoTill.slice(0, 3).map((e) => `${e.shop_code} ${e.eod_date}${e.z_number ? ` Z ${e.z_number}` : ''} ${money(e.total)}`).join(' · '), nav: { screen: 'AroniumEods', params: { show: 'open' } } });
    if (t.eodDiff && t.eodDiff.length) out.push({ id: 'till-eod-diff', level: 'urgent', text: `${n(t.eodDiff.length, 'Aronium End of day differs', 'Aronium End of days differ')} from the till – explain`, sub: t.eodDiff.slice(0, 3).map((e) => `${e.shop_code} ${e.eod_date} ${money(e.diff)}`).join(' · '), nav: { screen: 'AroniumEods', params: { show: 'open' } } });
    if (t.continued && t.continued.length) out.push({ id: 'till-continued', level: 'urgent', text: `${n(t.continued.length, 'shift was', 'shifts were')} continued without a count – count ${t.continued.length === 1 ? 'it' : 'them'}`, sub: t.continued.slice(0, 3).map((s) => `${s.till_name} ${s.shift} ${s.shift_date}`).join(' · '), nav: { screen: 'TillShifts', params: {} } });
    const late = (t.lateShifts || []).filter((s) => s.status === 'open');
    if (late.length) out.push({ id: 'till-shift-late', level: 'warning', text: `${n(late.length, 'shift from an earlier day is', 'shifts from earlier days are')} not balanced`, nav: { screen: 'TillShifts', params: {} } });
    if (t.unsigned) out.push({ id: 'till-unsigned', level: 'warning', text: `${n(t.unsigned, 'till balance needs', 'till balances need')} the two signatures`, nav: { screen: 'Till', params: {} } });
    if (t.waiting) out.push({ id: 'till-waiting', level: 'info', text: `${t.waiting} till count${t.waiting === 1 ? '' : 's'} to approve`, nav: { screen: 'Till', params: {} } });
    const rep = Array.isArray(t.repeat) ? t.repeat : [];
    if (rep.length) out.push({ id: 'till-repeat-short', level: 'warning', text: `${rep.length} cashier${rep.length === 1 ? '' : 's'} short again and again`, sub: 'Worth a talk or more training.', nav: { screen: 'Till', params: {} } });    // v3.9.2 second counts asked for by the rule, till over waiting for a decision, cashiers over again and again
    try {
      const RC = require('./recount.js');
      const sc = RC.countsWaitingSecond();
      if (sc.length) out.push({ id: 'till-second', level: 'warning', text: `${n(sc.length, 'till needs', 'tills need')} a second count by a supervisor`, sub: sc.slice(0, 3).map((c) => `${c.till_name} ${c.shift} ${c.shift_date}`).join(' · '), nav: { screen: 'TillCountView', params: { uid: sc[0].uid } } });
      const ov = RC.listSurpluses({ status: 'open' });
      if (ov.length) out.push({ id: 'till-over', level: 'warning', text: `${n(ov.length, 'till was', 'tills were')} over – decide what happens to the extra cash`, sub: ov.slice(0, 3).map((o) => `${o.name} ${o.shift_date} ${money(o.amount)}`).join(' · '), nav: { screen: 'TillShortages', params: {} } });
      const hw = require('../../services/handover.js').waitingTakeover();
      if (hw.length) out.push({ id: 'till-handover-wait', level: 'info', text: `${n(hw.length, 'handover waits', 'handovers wait')} to be taken over`, sub: hw.slice(0, 3).map((h) => `${h.shop_code} ${h.hand_date}${h.shift ? ` ${h.shift}` : ''} from ${h.from_name}`).join(' · '), nav: { screen: 'Handover', params: { uid: hw[0].uid } } });
      const ro = RC.repeatOvers();
      if (ro.length) out.push({ id: 'till-repeat-over', level: 'warning', text: `${ro.length} cashier${ro.length === 1 ? '' : 's'} over again and again`, sub: 'Often change not given or sales not rung up – worth a look.', nav: { screen: 'TillShortages', params: {} } });
    } catch (e) { /* older data */ }
    // v3.9.4 Aronium insights: cashiers with refunds / voids / discounts well above the team, things sold below cost
    try {
      const N = require('../aronium/insights.js');
      const flagged = N.cashierWatch({}).filter((c) => c.flags.length);
      if (flagged.length) out.push({ id: 'till-cashier-watch', level: 'warning', text: `Cashier watch: ${flagged.map((c) => c.name).slice(0, 3).join(', ')} – refunds, voids or discounts well above the rest`, sub: flagged[0].flags[0], nav: { screen: 'AroniumInsights', params: { tab: 'cashiers' } } });
      const below = N.priceCheck({ days: 7 }).belowCost;
      if (below.length) out.push({ id: 'till-below-cost', level: 'info', text: `${n(below.length, 'product was', 'products were')} sold below cost this week`, sub: below.slice(0, 3).map((x) => `${x.name} ${money(x.lowest)} (cost ${money(x.cost)})`).join(' · '), nav: { screen: 'AroniumInsights', params: { tab: 'prices' } } });
    } catch (e) { /* no figures yet */ }
    // v3.9.4 a till PC's Aronium link has not sent anything for 3 hours during trading hours (8 am – 9 pm)
    try {
      // shops with opening hours are watched more closely (salesWatch.linkWatchAlerts): only the others here
      const SW = require('./salesWatch.js');
      const quiet = quietTills().filter((t) => !SW.hoursKnown(t.shop));
      if (quiet.length) out.push({ id: 'till-link-quiet', level: 'warning', text: `${n(quiet.length, 'till PC has', 'till PCs have')} not sent Aronium figures for over 3 hours`, sub: `${quiet.slice(0, 3).map((x) => x.till).join(' · ')} – is the PC on and the internet working?`, nav: { screen: 'AroniumLink', params: {} } });
    } catch (e) { /* no link yet */ }
    // 1.0.0 sales watch: a till has started, no sales for a while while the shop is open, sales while the shop is closed
    try { out.push(...require('./salesWatch.js').salesWatchAlerts()); } catch (e) { /* no link yet */ }
    try { out.push(...require('./salesWatch.js').linkWatchAlerts()); } catch (e) { /* no link yet */ }
  }
  // 1.0.0 build 1: the safe is counted at the interval the admin set
  if (seeAll || can(user, 'deposits')) {
    try {
      const due = require('./service.js').safeCountsDue();
      const mine = seeAll ? due : due.filter((x) => !user.shop_code || x.shopCode === user.shop_code);
      if (mine.length) out.push({ id: `till-safe-due-${mine.map((x) => x.shopCode).join('-')}`, level: 'warning', text: `Count the safe: ${mine.map((x) => `${x.shopCode}${x.last ? ` (last ${x.days} days ago)` : ' (never counted)'}`).join(', ')}`, nav: { screen: 'CashOnHand', params: { shopCode: mine[0].shopCode } } });
    } catch (e) { /* never stops Home */ }
  }
  const sh = (t.shortages || []).filter((s) => seeAll || s.user_uid === user.uid);
  if (sh.length) {
    const dis = sh.filter((s) => s.status === 'disagreed');
    out.push({ id: 'till-shortages', level: dis.length && seeAll ? 'urgent' : 'warning', text: `${n(sh.length, 'till shortage is', 'till shortages are')} not agreed yet${dis.length ? ` (${dis.length} disagreed – manager to decide)` : ''}`, sub: 'Shown red in the pay run until decided.', nav: { screen: 'TillShortages', params: {} } });
  }
  return out;
}
