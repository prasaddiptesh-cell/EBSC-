// Warnings for Home: till counts waiting for approval, cashiers short again and again, and (v3.5) Aronium End of day
// differences, End of day without a till balance, shifts not balanced, shortages waiting for the cashier.
import { can } from '../../services/access.js';
import { money } from '../../services/core.js';
import { tillAlerts } from './service.js';
import { undecidedShortages } from './shifts.js';

const n = (k, one, many) => `${k} ${k === 1 ? one : many}`;
export function alerts(user) {
  const seeAll = can(user, 'till_approve');
  if (!seeAll && !can(user, 'till_count')) {
    // Anyone: their own till shortage waiting for them to agree.
    let mine = [];
    try { mine = undecidedShortages({ userUid: user.uid }); } catch (e) { mine = []; }
    return mine.length ? [{ id: 'till-shortages', level: 'warning', text: `${n(mine.length, 'till shortage waits', 'till shortages wait')} for you to agree or not`, nav: { screen: 'TillShortages', params: {} } }] : [];
  }
  const t = tillAlerts();
  const out = [];
  if (seeAll) {
    if (t.eodNoTill && t.eodNoTill.length) out.push({ id: 'till-eod-missing', level: 'urgent', text: `Till balance missing: ${n(t.eodNoTill.length, 'Aronium End of day has', 'Aronium End of days have')} no till balance`, sub: t.eodNoTill.slice(0, 3).map((e) => `${e.shop_code} ${e.eod_date}${e.z_number ? ` Z ${e.z_number}` : ''} ${money(e.total)}`).join(' · '), nav: { screen: 'AroniumEods', params: { show: 'open' } } });
    if (t.eodDiff && t.eodDiff.length) out.push({ id: 'till-eod-diff', level: 'urgent', text: `${n(t.eodDiff.length, 'Aronium End of day differs', 'Aronium End of days differ')} from the till – explain`, sub: t.eodDiff.slice(0, 3).map((e) => `${e.shop_code} ${e.eod_date} ${money(e.diff)}`).join(' · '), nav: { screen: 'AroniumEods', params: { show: 'open' } } });
    if (t.continued && t.continued.length) out.push({ id: 'till-continued', level: 'urgent', text: `${n(t.continued.length, 'shift was', 'shifts were')} continued without a count – count ${t.continued.length === 1 ? 'it' : 'them'}`, sub: t.continued.slice(0, 3).map((s) => `${s.till_name} ${s.shift} ${s.shift_date}`).join(' · '), nav: { screen: 'TillShifts', params: {} } });
    const late = (t.lateShifts || []).filter((s) => s.status === 'open');
    if (late.length) out.push({ id: 'till-shift-late', level: 'warning', text: `${n(late.length, 'shift from an earlier day is', 'shifts from earlier days are')} not balanced`, nav: { screen: 'TillShifts', params: {} } });
    if (t.unsigned) out.push({ id: 'till-unsigned', level: 'warning', text: `${n(t.unsigned, 'till balance needs', 'till balances need')} the two signatures`, nav: { screen: 'Till', params: {} } });
    if (t.waiting) out.push({ id: 'till-waiting', level: 'info', text: `${t.waiting} till count${t.waiting === 1 ? '' : 's'} to approve`, nav: { screen: 'Till', params: {} } });
    const rep = Array.isArray(t.repeat) ? t.repeat : [];
    if (rep.length) out.push({ id: 'till-repeat-short', level: 'warning', text: `${rep.length} cashier${rep.length === 1 ? '' : 's'} short again and again`, sub: 'Worth a talk or more training.', nav: { screen: 'Till', params: {} } });
  }
  const sh = (t.shortages || []).filter((s) => seeAll || s.user_uid === user.uid);
  if (sh.length) {
    const dis = sh.filter((s) => s.status === 'disagreed');
    out.push({ id: 'till-shortages', level: dis.length && seeAll ? 'urgent' : 'warning', text: `${n(sh.length, 'till shortage is', 'till shortages are')} not agreed yet${dis.length ? ` (${dis.length} disagreed – manager to decide)` : ''}`, sub: 'Shown red in the pay run until decided.', nav: { screen: 'TillShortages', params: {} } });
  }
  return out;
}
