// 1.0.0 build 2 (owner, 1 Nov): "Balance the till" made simple – for the person who balances (often not tech savvy).
// One page for ONE Aronium End of day that came in from a till PC (the Aronium Link):
//   where it is (the shop and till come by themselves from the till PC that sent it – S1-T1 = Shop 1 Till 1),
//   Aronium's figures (read only), whose shift it was (a drop-down, filled in), count the notes and coins, the result
//   at once (balanced / SHORT / OVER and what happens), a note, and one Save and sign.
// No money maths of its own: the expected cash is endShift.js's (zFigures / workOutEnd – float + cash sales + cash in
// − cash out − suppliers paid from the till), and the save is the till service's saveTillCount with the same figures
// End shift books (source 'link' + the End of day, so no Z photo), then the shortage services (take from pay / paid
// now). Own till, nobody approves their own short, the amount sanity and the closed month all stay in those services.
import { db } from '../../db/connection.js';
import { AppError, dateStr, addDays, money, stamp, deviceId, audit } from '../../services/core.js';
import { can } from '../../services/access.js';
import { requirePerm, requireShop, asService } from '../../services/guard.js';
import * as T from './service.js';
import * as E from './eod.js';
import * as ES from './endShift.js';
import * as MP from './mpaisaShift.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const need = (c, m) => { if (!c) throw new AppError(m); };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const isCashName = (n) => /cash/i.test(String(n || '')) && !/cheque|card|account/i.test(String(n || ''));

// ---------------------------------------------------------------- where: the shop and the till, from the till PC
export function shopName(code) {
  const s = safe(() => db().get('SELECT name FROM shops WHERE code = ?', [code]), null);
  return (s && txt(s.name)) || txt(code) || 'Shop';
}
// "S1-T2" from the End of day's id (EOD-S1-T2-z1043), else from the till name it carries ("Shop 1, Till 2").
export function sourceOf(e) {
  const m = /^EOD-(S\d+-T(\d+))-/i.exec(txt(e && e.uid));
  if (m) return { source: m[1].toUpperCase(), tillNo: m[2].replace(/^0+(?=.)/, '') };
  const n = E.tillNo(e && e.till_name);
  return { source: n ? `${txt(e && e.shop_code)}-T${n}` : '', tillNo: n || '' };
}
// The app's till for a till PC: the till of that shop with the same number; one till only and the till PC is Till 1:
// that one; none – it is made by the app itself ("Till N") the first time, so nobody has to pick anything.
export function appTillFor(shopCode, tillNo, { create = false, user = null, float = 0 } = {}) {
  const tills = T.listTills({ shopCode });
  const n = txt(tillNo) || '1';
  // a shop with one app till: Aronium's Till 1 uses it whatever it is called (4 Nov); another till number gets its own till
  let t = tills.find((x) => E.tillNo(x.name) === n) || (tills.length === 1 && (n === '1' || !E.tillNo(tills[0].name)) ? tills[0] : null);
  if (!t && create) {
    const uid = asService(() => T.saveTill(user, { shopCode, name: `Till ${n}`, floatAmount: Math.max(0, r2(float)) }));
    t = db().get('SELECT * FROM tills WHERE uid = ?', [uid]);
  }
  return t || null;
}
// "Shop 1 - Drasa Avenue · Till 1" for an End of day row.
export function whereOf(e, opts = {}) {
  const { source, tillNo } = sourceOf(e);
  const till = e ? appTillFor(e.shop_code, tillNo, opts) : null;
  const name = shopName(e && e.shop_code);
  const tillName = till ? till.name : `Till ${tillNo || '1'}`;
  return { source, shopCode: e ? e.shop_code : '', shopName: name, tillNo: tillNo || '1', till, tillName, label: `${name} · ${tillName}` };
}
// The same words for a till balance (till_counts row) – the office lists.
export const countWhere = (c) => (c ? `${shopName(c.shop_code)} · ${c.till_name || 'Till'}` : '');
const hm = (s) => { const t = txt(s).slice(11, 16); if (!/^\d{2}:\d{2}$/.test(t)) return ''; const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`; };
export const zTime = (closedAt) => hm(closedAt);

// ---------------------------------------------------------------- the End of days waiting for a till balance
// [{ uid, label, z, time, date, total, link, target, text }] – own shop only for a shop manager / supervisor.
export function waitingBalances(user, screens) {
  if (!user) return [];
  let list = [];
  try { list = E.eodProblems().noTill; } catch (e) { list = []; }
  list = list.filter((e) => !user.shop_code || ['owner', 'admin'].includes(user.role) || e.shop_code === user.shop_code);
  return list.map((e) => {
    const w = whereOf(e);
    const sh = ES.eodShape(e);
    const link = e.source === 'link';
    const time = zTime(sh && sh.closedAt);
    return {
      uid: e.uid, label: w.label, shopName: w.shopName, tillName: w.tillName, z: e.z_number || '', time, date: e.eod_date, total: r2(e.total), link,
      text: `${w.shopName.replace(/\s+-\s+.*$/, '')} ${w.tillName} – End of day ${e.z_number ? `Z ${e.z_number}` : e.eod_date} is in`,
      target: link ? { screen: 'BalanceTill', params: { eodUid: e.uid } }
        : { screen: 'TillCount', params: { shopCode: e.shop_code, shiftDate: e.eod_date, zNumber: e.z_number || '', zTotal: e.total, ...(e.cash !== null && e.cash !== undefined ? { zCash: e.cash } : {}) } },
    };
  });
}

// ---------------------------------------------------------------- the page
export function mayBalance(user) { return !!user && (can(user, 'till_count') || can(user, 'till_approve')); }

export function balancePlan(user, eodUid) {
  requirePerm(user, ['till_count', 'till_approve']);
  const e = E.getEod(txt(eodUid));
  need(e && e.state !== 'void', 'This End of day is not found.');
  requireShop(user, e.shop_code);
  need(e.source === 'link', 'This End of day was typed by hand – use "Type the figures myself".');
  const eod = ES.eodShape(e);
  const where = whereOf(e, { create: e.state === 'no_till', user, float: eod.float || 0 });
  const plan = basePlan(user, { e, eod, where, shopCode: e.shop_code, date: e.eod_date, closedAt: eod.closedAt });
  plan.done = e.state !== 'no_till';
  plan.figures = figuresOf(plan);
  plan.mp = MP.mpPlan({ shopCode: plan.shopCode, tillUid: plan.tillUid, date: plan.date, tenders: ES.zFigures(plan).tenders });
  plan.rcUntil = ES.rcUntil(plan.closedAt || eod.closedAt);
  plan.rc = rcPlans(plan);
  return plan;
}
// 1.0.0 the recharge machine balances of the shop (Vodafone / Inkk): what each should be at the End of day
function rcPlans(plan) {
  try { return require('./recharge.js').shiftPlan(plan.shopCode, plan.rcUntil || stamp()); } catch (e) { return []; }
}
// The till PCs this person may balance by hand: [{ key, shopCode, tillUid, label }] (their own shop first).
export function tillChoices(user) {
  const out = [];
  for (const sh of ES.shopsForUser(user).filter((x) => !user.shop_code || ['owner', 'admin'].includes(user.role) || x.code === user.shop_code)) {
    for (const t of T.listTills({ shopCode: sh.code })) out.push({ key: t.uid, shopCode: sh.code, tillUid: t.uid, label: `${shopName(sh.code)} · ${t.name}` });
  }
  return out;
}
// "End of day not in yet? Balance by hand": the same page with a very short Z (and its photo).
// z: { zNumber, total, cash, payments: { 'M-PAiSA': 50, … } (Aronium's payment names), photos }
export function manualPlan(user, { tillUid, z = {} } = {}) {
  requirePerm(user, ['till_count', 'till_approve']);
  const choices = tillChoices(user);
  const mine = ES.myOpenShift(user);
  const pick = choices.find((c) => c.tillUid === txt(tillUid)) || (mine && choices.find((c) => c.tillUid === mine.till_uid)) || choices[0];
  need(pick, 'There is no till at this shop yet. The admin adds it in Settings › Tills & rules.');
  requireShop(user, pick.shopCode);
  const till = db().get('SELECT * FROM tills WHERE uid = ?', [pick.tillUid]);
  const where = { source: '', shopCode: pick.shopCode, shopName: shopName(pick.shopCode), tillNo: E.tillNo(till.name) || '1', till, tillName: till.name, label: pick.label };
  const plan = basePlan(user, { e: null, eod: null, where, shopCode: pick.shopCode, date: dateStr(), closedAt: '' });
  plan.manual = true; plan.choices = choices; plan.done = false;
  plan.manualZ = manualZOf(z);
  const zf = ES.zFigures(plan, plan.manualZ);
  plan.figures = zf && zf.zCash !== null ? figuresOf(plan) : null;
  plan.mp = MP.mpPlan({ shopCode: plan.shopCode, tillUid: plan.tillUid, date: plan.date, tenders: zf ? zf.tenders : [] });
  plan.rcUntil = stamp();
  plan.rc = rcPlans(plan);
  return plan;
}
function manualZOf(z) {
  const pays = z.payments || {};
  const mp = Object.entries(pays).filter(([n]) => /paisa/i.test(n)).reduce((s, [, a]) => s + (Number(a) || 0), 0);
  const card = Object.entries(pays).filter(([n]) => !/paisa/i.test(n)).reduce((s, [, a]) => s + (Number(a) || 0), 0);
  return { zNumber: txt(z.zNumber), total: z.total, cash: z.cash, mpaisa: mp || '', card: card || '', photos: z.photos || [] };
}
function basePlan(user, { e, eod, where, shopCode, date, closedAt }) {
  const till = where.till;
  // the person clocked in on that till (their shift is still running), else the shift by the End of day's time
  const running = till ? safe(() => db().get("SELECT * FROM shift_ends WHERE till_uid = ? AND status = 'started' AND shift_date BETWEEN ? AND ? ORDER BY started_at DESC LIMIT 1", [till.uid, addDays(date, -1), date]), null) : null;
  const names = ES.shiftNames();
  const h = Number(txt(closedAt).slice(11, 13));
  let shift = running && running.shift ? running.shift : ES.defaultShift(Number.isFinite(h) && txt(closedAt).length >= 13 ? new Date(2000, 0, 1, h) : undefined);
  const taken = (s) => till && safe(() => !!db().get("SELECT uid FROM till_counts WHERE till_uid = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [till.uid, date, s]), false);
  if (taken(shift)) shift = names.find((s) => !taken(s)) || shift;
  const fl = till ? ES.floatFor(shopCode, till.uid) : { amount: 0, from: 'app', app: 0 };
  const float = eod && eod.float !== null ? { amount: eod.float, from: 'Aronium', app: fl.app } : fl;
  const paidOuts = till ? safe(() => require('../payables/service.js').tillPaidOuts(till.uid, date), []) : [];
  const staff = safe(() => db().all("SELECT uid, name, role, shop_code FROM users WHERE active = 1 AND role NOT IN ('accountant') AND IFNULL(sync_status,'') <> 'seed' ORDER BY name"), []);
  // whose shift: Aronium's cashier (the one who took the most) when the name is a staff member, else who is clocked in
  const low = (s) => txt(s).toLowerCase();
  const byName = (n) => staff.find((p) => low(p.name) === low(n)) || staff.find((p) => low(p.name).split(/\s+/)[0] === low(n).split(/\s+/)[0] && low(n));
  const ar = Object.entries((eod && eod.cashiers) || {}).sort((a, b) => r2(b[1]) - r2(a[1])).map(([n]) => n);
  let cashierUid = ''; let cashierFrom = '';
  for (const n of ar) { const p = byName(n); if (p) { cashierUid = p.uid; cashierFrom = 'Aronium'; break; } }
  if (!cashierUid && running) { cashierUid = running.user_uid; cashierFrom = 'clocked in'; }
  return { kind: 'till', e, eod, where, till, tillUid: till ? till.uid : '', shopCode, date, shift, float, paidOuts, rules: T.tillRules(), staff,
    cashierUid, cashierFrom, aroniumCashiers: ar, running, zTime: zTime(closedAt) };
}
// Edit a figure (owner / admin / manager): the page's figures with the corrections put in (the reason is asked on save).
// edit: { total, cash, float, mpaisa, cashIn, cashOut } – only the ones given change.
export function withEdit(plan, edit) {
  if (!edit || !plan.eod) return plan;
  const n = (v) => (v === '' || v === null || v === undefined || !Number.isFinite(Number(v)) ? null : r2(v));
  const eod = { ...plan.eod };
  const what = [];
  const ch = (k, label, cur) => { const v = n(edit[k]); if (v !== null && Math.abs(v - r2(cur)) > 0.004) { what.push(`${label} ${$(cur)} → ${$(v)}`); return v; } return null; };
  let v;
  if ((v = ch('total', 'total sales', eod.total)) !== null) eod.total = v;
  if ((v = ch('cash', 'cash sales', eod.cash === null ? eod.total : eod.cash)) !== null) eod.cash = v;
  if ((v = ch('cashIn', 'cash in', eod.cashIn)) !== null) eod.cashIn = v;
  if ((v = ch('cashOut', 'cash out', eod.cashOut)) !== null) eod.cashOut = v;
  const curMp = r2(eod.tenders.filter((t) => /paisa/i.test(t.method)).reduce((s, t) => s + t.amount, 0));
  if ((v = ch('mpaisa', 'M-PAiSA', curMp)) !== null) eod.tenders = eod.tenders.filter((t) => !/paisa/i.test(t.method)).concat(v ? [{ method: 'M-PAiSA', amount: v }] : []);
  let float = plan.float;
  if ((v = ch('float', 'float', plan.float.amount)) !== null) float = { ...plan.float, amount: v, from: 'edited' };
  if (!what.length) return plan;
  eod.payments = null;
  const p = { ...plan, eod, float, edited: what };
  p.figures = figuresOf(p);
  p.mp = MP.mpPlan({ shopCode: p.shopCode, tillUid: p.tillUid, date: p.date, tenders: ES.zFigures(p).tenders });
  return p;
}

// What the page shows from Aronium (and what should be in the till) – the money maths is endShift's.
export function figuresOf(plan) {
  const z = ES.zFigures(plan, plan.manualZ);
  const w = ES.workOutEnd(plan, { denominations: {}, manualZ: plan.manualZ });
  const pays = [];
  if (plan.eod && plan.eod.payments) {
    for (const [name, amt] of Object.entries(plan.eod.payments)) if (!isCashName(name) && Math.abs(r2(amt)) >= 0.005) pays.push({ name, amount: r2(amt) });
  } else (z.tenders || []).forEach((t) => pays.push({ name: t.method, amount: r2(t.amount) }));
  const supplierPaid = r2((plan.paidOuts || []).reduce((s, p) => s + r2(p.amount), 0));
  return { total: r2(z.zTotal), cash: r2(z.zCash), payments: pays, float: r2(z.float), floatFrom: plan.float.from, cashIn: r2(z.cashIn), cashOut: r2(z.cashOut), supplierPaid, expected: w.expected };
}

// The result box: counted, should be, and balanced / short / over (the till rules' tolerance).
export function resultOf(plan, denominations) {
  const w = ES.workOutEnd(plan, { denominations: denominations || {}, manualZ: plan.manualZ });
  if (w.expected === null) return { counted: w.counted, expected: null, overShort: null, amount: 0, state: 'none', tolerance: Number(plan.rules.tolerance) || 0 };
  const tol = Number(plan.rules.tolerance) || 0;
  const os = w.overShort;
  const state = !(w.counted > 0) ? 'none' : Math.abs(os) <= tol + 0.004 ? 'balanced' : os < 0 ? 'short' : 'over';
  return { counted: w.counted, expected: w.expected, overShort: os, amount: r2(Math.abs(os)), state, tolerance: tol };
}

// ---------------------------------------------------------------- Save and sign
// input: { eodUid | manual: { tillUid, z }, cashierUid, denominations, shortAction: 'pay' | 'paid_now', note,
//          signature (the balancer), cashierSig (the cashier, when there), confirmOdd,
//          edit: { total, cash, float, mpaisa, cashIn, cashOut, reason } (owner / admin / manager),
//          mpClose (M-PAiSA wallet balance now, from the phone), mpAction ('pay' | 'paid_now' | 'explain'), mpNote }
export function saveBalance(user, input = {}) {
  requirePerm(user, ['till_count', 'till_approve'], { money: true });
  if (!input.manual) {
    const e0 = E.getEod(txt(input.eodUid));
    need(e0, 'This End of day is not found.');
    requireShop(user, e0.shop_code);
  }
  return asService(() => {
    let plan = input.manual ? manualPlan(user, input.manual) : balancePlan(user, input.eodUid);
    need(!plan.done, 'This End of day already has its till balance.');
    need(plan.till, 'There is no till at this shop.');
    let source = plan.manual ? 'manual' : 'link';
    if (!plan.manual && input.edit) {
      plan = withEdit(plan, input.edit);
      if (plan.edited) source = 'link_edit';
    }
    if (plan.manual) {
      const m = plan.manualZ;
      need(txt(m.zNumber) && m.total !== '' && m.total !== undefined && m.cash !== '' && m.cash !== undefined, 'Type the Z number, the total sales and the cash sales from the Z report.');
      need((m.photos || []).length, 'Take a photo of the Z report.');
    }
    const cashier = plan.staff.find((p) => p.uid === txt(input.cashierUid));
    need(cashier, 'Choose whose shift it was.');
    const res = resultOf(plan, input.denominations);
    need(res.counted > 0, 'Count the cash.');
    need(txt(input.signature), 'Sign at the bottom.');
    const w = ES.workOutEnd(plan, { denominations: input.denominations, manualZ: plan.manualZ });
    const z = w.z;
    const probs = ES.sanityProblems({ counted: w.counted, expected: w.expected, zCash: z.zCash, zTotal: z.zTotal, tenders: z.tenders, denominations: input.denominations });
    const stop = probs.filter((p) => p.level === 'stop');
    need(!stop.length, stop.map((p) => p.text).join(' '));
    const check = probs.filter((p) => p.level === 'check');
    need(!check.length || input.confirmOdd, check.map((p) => p.text).join(' '));
    const own = cashier.uid === user.uid;
    const cashierSig = own ? txt(input.signature) : txt(input.cashierSig);
    const shortAction = res.state === 'short' ? (input.shortAction === 'paid_now' ? 'paid_now' : 'pay') : null;
    const reasons = [source === 'manual' ? 'Z typed by hand (Aronium End of day not in yet)' : source === 'link_edit' ? `Aronium's figures changed: ${plan.edited.join(', ')} – ${txt(input.edit.reason)}` : 'Figures as Aronium sent them'];
    if (res.state === 'short') reasons.push(shortAction === 'paid_now' ? 'Short – paid in cash now' : 'Short – taken from pay');
    if (res.state === 'over') reasons.push('Over – the office decides');
    if (txt(input.note)) reasons.push(txt(input.note));
    if (shortAction === 'paid_now') need(cashierSig, `${cashier.name} must be here and sign for the money paid now.`);
    const payouts = (plan.paidOuts || []).map((p) => ({ what: 'Supplier paid from till', amount: r2(p.amount), note: `${p.supplier_name}${p.invoice_no ? ` ${p.invoice_no}` : ''}` }));
    if (z.cashOut > 0) payouts.push({ what: 'Other', amount: z.cashOut, note: 'Cash taken out in Aronium' });
    const adjustments = z.cashIn > 0 ? [{ amount: z.cashIn, reason: 'Cash put in (Aronium)' }] : [];
    const c = T.saveTillCount(user, {
      shopCode: plan.shopCode, tillUid: plan.till.uid, shiftDate: plan.date, shift: plan.shift, cashierUid: cashier.uid, balancerUid: user.uid,
      openingFloat: z.float, denominations: input.denominations, zCash: z.zCash, zTotal: z.zTotal, zNumber: z.zNumber, zVat: z.zVat, zZeroRated: z.zZero,
      tenders: z.tenders, payouts, adjustments, drops: 0, floatKept: r2(Math.min(w.counted, r2(z.float))), reason: reasons.join('. '),
      notes: own ? 'Own till – balanced by the cashier; someone else checks it.' : `Balanced by ${user.name} (Balance the till).`,
      cashierSig: cashierSig || null, balancerSig: txt(input.signature), source, eodUid: plan.e ? plan.e.uid : null,
      editReason: input.edit ? input.edit.reason : '', editWhat: plan.edited ? plan.edited.join(', ') : '',
    }, { photos: plan.manual ? plan.manualZ.photos : [] });
    let shortDone = null;
    if (shortAction) {
      const S = require('./shifts.js');
      const sh = S.shortageForCount(c.uid);
      if (sh && ['waiting', 'disagreed'].includes(sh.status)) {
        if (shortAction === 'paid_now') { require('./recount.js').payShortageNow(user, sh.uid, { amount: sh.amount, signature: cashierSig, note: 'Paid when the till was balanced' }); shortDone = 'paid_now'; }
        else if (cashierSig) { S.agreeShortage(user, sh.uid, { signature: cashierSig }); shortDone = 'agreed'; }
        else shortDone = 'waiting'; // the cashier signs to agree later (My pay); it still comes off the next pay
      }
    }
    // the M-PAiSA wallet balance now (from the phone): opening + this shift's M-PAiSA sales − paid out = should be
    let mp = null;
    if (input.mpClose !== undefined && input.mpClose !== null && input.mpClose !== '' && plan.mp) {
      const mpp = MP.mpPlan({ shopCode: plan.shopCode, tillUid: plan.tillUid, date: plan.date, tenders: z.tenders });
      mp = MP.applyMp(user, { count: T.getTillCount(c.uid), mp: mpp, close: input.mpClose, action: input.mpAction, note: input.mpNote, tolerance: plan.rules.tolerance });
    }
    // 1.0.0 the recharge machine balances read off the machine (rcClose: { walletUid: amount })
    let rc = [];
    if (input.rcClose && Object.keys(input.rcClose).length && (plan.rc || []).length) {
      rc = require('./recharge.js').applyRc(user, { count: T.getTillCount(c.uid), shopCode: plan.shopCode, date: plan.date, until: plan.rcUntil || stamp(), close: input.rcClose, action: input.rcAction || {}, note: input.rcNote || {}, tolerance: plan.rules.tolerance });
    }
    const after = plan.e ? E.getEod(plan.e.uid) : null;
    return { countUid: c.uid, eodUid: plan.e ? plan.e.uid : null, label: plan.where.label, shift: plan.shift, date: plan.date, zNumber: z.zNumber || '', cashierName: cashier.name,
      counted: c.cash_counted, expected: c.expected_cash, overShort: c.over_short, state: res.state, shortAction, shortDone, eodState: after ? after.state : null, mp, rc, source };
  });
}

// ---------------------------------------------------------------- the Link's End of day arrives after a balance by hand
// Called after a till PC's End of day is put in and matched (eod.js putLinkedEod). For each till balance it was matched
// to whose Z was typed by hand: the till PC's figures replace the typed ones (the typed ones are kept on the record
// and in the history), the over / short is worked out again (the shortage / over follow), the End of day is matched
// again, and a difference over the tolerance is flagged for the office ("typed Z differed from Aronium").
export function linkReplacesTyped(eodUid) {
  const e = E.getEod(eodUid);
  if (!e || e.source !== 'link' || !e.count_uids.length) return [];
  const sh = ES.eodShape(e);
  const out = [];
  asService(() => {
    for (const uid of e.count_uids) {
      const c = db().get("SELECT * FROM till_counts WHERE uid = ? AND status <> 'void'", [uid]);
      if (!c || c.z_source !== 'manual') continue;
      const tenders = sh.tenders;
      const cash = sh.cash === null ? r2(sh.total - tenders.reduce((s, t) => s + t.amount, 0)) : sh.cash;
      const J0 = (v) => { try { return JSON.parse(v || '[]'); } catch (x) { return []; } };
      const typed = { zNumber: c.z_number, total: c.z_total, cash: c.z_cash, tenders: J0(c.tenders), overShort: c.over_short };
      const dCash = r2(cash - r2(c.z_cash));
      const expected = r2(r2(c.expected_cash) + dCash);
      const os = r2(r2(c.cash_counted) - expected);
      const diffTotal = r2(r2(sh.total) - r2(c.z_total));
      const now = stamp();
      db().run(`UPDATE till_counts SET z_total = ?, z_cash = ?, tenders = ?, z_vat = COALESCE(?, z_vat), z_zero_rated = COALESCE(?, z_zero_rated), z_number = COALESCE(?, z_number), expected_cash = ?, over_short = ?,
        z_source = 'link_replaced', z_typed = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [r2(sh.total), cash, JSON.stringify(tenders), sh.vat ?? null, sh.zero ?? null, sh.zNumber || null, expected, os, JSON.stringify(typed), now, deviceId(), uid]);
      const saved = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
      const tol = Number(T.tillRules().tolerance) || 0;
      try { require('./shifts.js').syncShortage(null, saved, tol); } catch (x) { /* the count is right; the shortage follows on the next check */ }
      try { require('./recount.js').syncSurplus(null, saved, tol); } catch (x) { /* as above */ }
      const changed = Math.abs(dCash) > 0.004 || Math.abs(diffTotal) > 0.004;
      audit({ user: null, action: `${c.till_name} ${c.shift} ${c.shift_date}: the till PC's End of day ${sh.zNumber || ''} came in – typed Z ${$(typed.total)} (cash ${$(typed.cash)}) replaced by Aronium's ${$(sh.total)} (cash ${$(cash)})${Math.abs(os - r2(typed.overShort)) > 0.004 ? `; the till is now ${Math.abs(os) < 0.005 ? 'balanced' : os < 0 ? `short ${$(-os)}` : `over ${$(os)}`} (was ${$(typed.overShort)})` : ''}`.replace(/\s+/g, ' '), table: 'till_counts', recordUid: uid });
      if (changed && (Math.abs(dCash) > tol || Math.abs(diffTotal) > tol)) {
        try { require('../verify/service.js').notify('eod_diff', `Typed Z differed from Aronium: ${countWhere(c)} ${c.shift} ${c.shift_date} – typed ${$(typed.total)} (cash ${$(typed.cash)}), Aronium ${$(sh.total)} (cash ${$(cash)}). Aronium's figures are used; ${c.cashier_name}'s till is now ${Math.abs(os) <= tol ? 'balanced' : os < 0 ? `SHORT ${$(-os)}` : `OVER ${$(os)}`}.`, { shopCode: c.shop_code }); } catch (x) { /* only a message */ }
      }
      out.push({ countUid: uid, typed, overShort: os, changed });
    }
  });
  if (out.length) E.rematchEods({ shopCode: e.shop_code, date: e.eod_date });
  return out;
}

// The done page: from the till balance (and its End of day).
export function doneInfo(countUid) {
  const c = T.getTillCount(countUid);
  if (!c) return null;
  const tol = Number(T.tillRules().tolerance) || 0;
  const os = r2(c.over_short);
  const state = Math.abs(os) <= tol + 0.004 ? 'balanced' : os < 0 ? 'short' : 'over';
  const sh = safe(() => require('./shifts.js').shortageForCount(c.uid), null);
  const e = safe(() => E.eodForCount(c.uid), null);
  return { c, label: countWhere(c), state, amount: r2(Math.abs(os)), shortage: sh, eod: e, zTime: e ? zTime((ES.eodShape(e) || {}).closedAt) : '' };
}
export { $ as moneyText };
