// 1.0.0 Cigarette tally at the end of each shift, and the cigarette fund.
// Cigarettes come on one week's credit: what is sold is put aside (packets × cost price) so the next invoice can be
// paid from it.
//   • Aronium: the packets sold in the End of days of the shop since the last tally (the till PC's Aronium Link sends
//     the products of each End of day – "z_items"). Each End of day is used by one tally only.
//   • The cabinet: opening (the last tally's count) + received / moved since − counted now = sold.
//   • The two are compared; any difference needs a reason and is flagged (and sent to Viber).
//   • "Put aside for cigarettes $X": the cash goes from the shop's takings into the cigarette fund (a cash correction
//     out of the shop, tagged cig_fund), so the shop's cash on hand stays right. Cigarette invoices are paid from the
//     fund (cash from "cig:<shop>"), or the fund is given back to the shop's cash.
// An End of day that comes in late (till PC slow) is added to the tally of its shift afterwards; when its value differs
// from what was put aside, the app says how much more to put aside (or give back).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared, clock } from '../../services/core.js';
import { needReason, can } from '../../services/access.js';
import { notify } from '../verify/service.js';
import { normZ, tillNo } from './eod.js';
import { requirePerm, requireShop, shopOf, asService } from '../../services/guard.js';

export const CIG_SQL = `
CREATE TABLE IF NOT EXISTS cig_tallies (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  shift_date TEXT NOT NULL,
  shift TEXT NOT NULL,
  at TEXT, by_uid TEXT, by_name TEXT,
  lines TEXT, z_keys TEXT,
  aronium_complete INTEGER NOT NULL DEFAULT 0,
  aronium_packets REAL, counted_packets REAL, diff_packets REAL,
  aronium_value REAL, counted_value REAL, suggested REAL, aside REAL NOT NULL DEFAULT 0, topped_up REAL NOT NULL DEFAULT 0,
  reason TEXT, note TEXT,
  status TEXT NOT NULL DEFAULT 'saved', void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_cig_shop ON cig_tallies(shop_code, shift_date);
`;
export const CIG_SYNC = {
  cig_tallies: { key: 'uid', section: 'Sales & tills', cols: ['uid', 'shop_code', 'shift_date', 'shift', 'at', 'by_uid', 'by_name', 'lines', 'z_keys', 'aronium_complete', 'aronium_packets', 'counted_packets', 'diff_packets',
    'aronium_value', 'counted_value', 'suggested', 'aside', 'topped_up', 'reason', 'note', 'status', 'void_reason', 'updated_at', 'updated_device'] },
};

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const $ = (n) => `$${r2(n).toFixed(2)}`;
const need = (c, m) => { if (!c) throw new AppError(m); };
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const boss = (u) => !!u && (['owner', 'admin', 'manager'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const ago = (days) => dateStr(new Date(clock.now().getTime() - days * 86400000));
const SET = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
export const FUND = 'cig_fund';

// ---------------------------------------------------------------- settings
const DEF = { on: true, groups: ['Cigarettes', 'Tobacco'], suppliers: [], shops: [], includeVat: true, tolerance: 0 };
export function cigRules() {
  const s = getShared('cig_tally', {}) || {};
  const list = (v, d) => (Array.isArray(v) ? v.map(txt).filter(Boolean) : d);
  return { ...DEF, ...s, groups: list(s.groups, DEF.groups), suppliers: list(s.suppliers, []), shops: list(s.shops, []), includeVat: s.includeVat !== false, on: s.on !== false, tolerance: Math.max(0, Number(s.tolerance) || 0) };
}
export function saveCigRules(user, r) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || can(user, 'settings')), 'Only the owner or admin can change this.');
  const cur = cigRules();
  const next = { ...cur, ...r };
  next.groups = (Array.isArray(next.groups) ? next.groups : txt(next.groups).split(/[,;]/)).map(txt).filter(Boolean);
  need(next.groups.length, 'Name at least one Aronium group (e.g. Cigarettes).');
  setShared('cig_tally', { on: next.on !== false, groups: next.groups, suppliers: (next.suppliers || []).map(txt).filter(Boolean), shops: (next.shops || []).map(txt).filter(Boolean), includeVat: next.includeVat !== false, tolerance: Math.max(0, Number(next.tolerance) || 0) });
  audit({ user, action: `Cigarette tally settings: groups ${next.groups.join(', ')}; ${next.suppliers.length} supplier(s); shops ${next.shops.join(', ') || 'all'}; cost ${next.includeVat ? 'with' : 'without'} VAT`, table: 'settings' });
  return cigRules();
  });
}

// The cigarette products (by their Aronium group) and the shops that do the tally.
export function cigItems() {
  const g = cigRules().groups.map((x) => x.toLowerCase());
  if (!g.length) return [];
  return safe(() => db().all(`SELECT uid, code, name, group_name, unit, cost, vat_type, pack_size FROM inv_items WHERE active = 1 AND removed_at IS NULL AND lower(IFNULL(group_name,'')) IN (${g.map(() => '?').join(',')}) ORDER BY name`, g), null)
    || safe(() => db().all(`SELECT uid, code, name, group_name, unit, cost, vat_type, pack_size FROM inv_items WHERE active = 1 AND lower(IFNULL(group_name,'')) IN (${g.map(() => '?').join(',')}) ORDER BY name`, g), []);
}
export function cigShops() {
  const r = cigRules();
  if (!r.on) return [];
  const all0 = safe(() => db().all('SELECT code FROM shops ORDER BY code').map((s) => s.code), []);
  // by default the shops with tills (the bakery has none)
  const withTills = new Set(safe(() => db().all('SELECT DISTINCT shop_code FROM tills WHERE IFNULL(active,1) = 1').map((t) => t.shop_code), []));
  const all = withTills.size ? all0.filter((c) => withTills.has(c)) : all0;
  return r.shops.length ? all.filter((c) => r.shops.includes(c)) : all;
}
// What one packet costs us – with VAT by default, as that is what the invoice is paid with.
export function packetCost(it) {
  const c = Number(it && it.cost) || 0;
  return r4(cigRules().includeVat && (!it.vat_type || it.vat_type === 'standard') ? c * 1.125 : c);
}

// ---------------------------------------------------------------- Aronium: End of days not used by a tally yet
function feed(kind, where = '', args = []) { return has('aronium_feed') ? safe(() => db().all(`SELECT * FROM aronium_feed WHERE kind = ? ${where}`, [kind, ...args]), []) : []; }
function usedKeys(shopCode, exceptUid = '') {
  const s = new Set();
  for (const t of has('cig_tallies') ? db().all("SELECT uid, z_keys FROM cig_tallies WHERE shop_code = ? AND status <> 'void'", [shopCode]) : []) if (t.uid !== exceptUid) for (const k of J(t.z_keys, [])) s.add(k);
  return s;
}
function zItems(source, key) {
  const parts = feed('z_items', 'AND source = ? AND period = ? ORDER BY part', [source, key]);
  const per = {};
  for (const p of parts) {
    const d = J(p.data, {});
    const cols = d.cols || ['code', 'qty'];
    const ci = cols.indexOf('code'); const qi = cols.indexOf('qty');
    for (const row of d.rows || []) { const c = txt(row[ci]).toLowerCase(); if (c) per[c] = q3((per[c] || 0) + (Number(row[qi]) || 0)); }
  }
  return { per, found: parts.length > 0 };
}
// The End of days of a shop for a tally: not used by another tally, from the day of the last tally (or this day) to this day.
export function aroniumFor(shopCode, date, shift, { exceptUid = '' } = {}) {
  const last = lastTally(shopCode, { before: { date, shift }, exceptUid });
  const from = last ? last.shift_date : date;
  const used = usedKeys(shopCode, exceptUid);
  const zs = feed('z', 'AND shop_code = ?', [shopCode]).map((r) => ({ row: r, z: J(r.data, {}) }))
    .filter((x) => x.z && x.z.date && x.z.date >= from && x.z.date <= date && x.z.z_id !== null && x.z.z_id !== undefined)
    .map((x) => ({ ...x, key: `${x.row.source}|${x.z.key}` })).filter((x) => !used.has(x.key));
  const per = {};
  const keys = [];
  let itemsMissing = 0;
  for (const x of zs) {
    const it = zItems(x.row.source, x.z.key);
    if (!it.found) { itemsMissing += 1; continue; } // an End of day from an older Link: no products in it
    keys.push(x.key);
    for (const [c, n] of Object.entries(it.per)) per[c] = q3((per[c] || 0) + n);
  }
  // Till balances of this shift whose End of day has not come from the till PC yet.
  const counts = has('till_counts') ? safe(() => db().all("SELECT till_name, z_number FROM till_counts WHERE shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [shopCode, date, shift]), []) : [];
  const waiting = counts.filter((c) => !zs.some((x) => (c.z_number ? normZ(x.z.number) === normZ(c.z_number) : true) && (!tillNo(c.till_name) || !tillNo(x.row.till) || tillNo(c.till_name) === tillNo(x.row.till))))
    .map((c) => `${c.till_name || 'Till'}${c.z_number ? ` (End of day ${c.z_number})` : ''}`);
  return { per, keys, ends: zs.length - itemsMissing, waiting, itemsMissing, complete: zs.length - itemsMissing > 0 && !waiting.length && !itemsMissing };
}

// ---------------------------------------------------------------- the tally
export function lastTally(shopCode, { before = null, exceptUid = '' } = {}) {
  if (!has('cig_tallies')) return null;
  const rows = db().all("SELECT * FROM cig_tallies WHERE shop_code = ? AND status <> 'void' AND uid <> ? ORDER BY shift_date DESC, at DESC, rowid DESC", [shopCode, exceptUid || '']);
  if (!before) return rows[0] || null;
  return rows.find((t) => t.shift_date < before.date || (t.shift_date === before.date && t.shift !== before.shift)) || null;
}
// Stock that came in or went out since the last tally (deliveries, transfers, returns, write-offs) – not sales.
function movedSince(shopCode, at) {
  if (!at) return {};
  const out = {};
  for (const r of safe(() => db().all("SELECT item_uid, SUM(qty) AS q FROM inv_moves WHERE shop_code = ? AND status = 'active' AND type NOT IN ('sale', 'count', 'opening') AND created_at > ? GROUP BY item_uid", [shopCode, at]), [])) out[r.item_uid] = q3(r.q);
  return out;
}

// What the screen shows before saving: each product's opening, moved, Aronium sold; with the counts typed, sold and differences.
export function workOutTally({ shopCode, date = dateStr(), shift, closing = {}, exceptUid = '' }) {
  const items = cigItems();
  const last = lastTally(shopCode, { before: { date, shift }, exceptUid });
  const open = Object.fromEntries((last ? J(last.lines, []) : []).map((l) => [l.itemUid, l.closing]));
  const moved = movedSince(shopCode, last && last.at);
  const ar = aroniumFor(shopCode, date, shift, { exceptUid });
  const lines = items.map((it) => {
    const c = closing[it.uid];
    const counted = c === '' || c === null || c === undefined ? null : q3(c);
    const opening = open[it.uid] === undefined || open[it.uid] === null ? null : q3(open[it.uid]);
    const mv = q3(moved[it.uid] || 0);
    const soldCount = counted === null || opening === null ? null : q3(opening + mv - counted);
    const soldAronium = ar.ends ? q3(ar.per[txt(it.code).toLowerCase()] || 0) : null;
    const cost = packetCost(it);
    return { itemUid: it.uid, code: it.code, name: it.name, opening, moved: mv, closing: counted, soldCount, soldAronium, diff: soldCount === null || soldAronium === null ? null : q3(soldCount - soldAronium), cost };
  });
  const sum = (f) => q3(lines.reduce((t, l) => t + (Number(f(l)) || 0), 0));
  const aroniumPackets = ar.ends ? sum((l) => l.soldAronium) : null;
  const countedPackets = lines.some((l) => l.soldCount !== null) ? sum((l) => l.soldCount) : null;
  const aroniumValue = ar.ends ? r2(lines.reduce((t, l) => t + (l.soldAronium || 0) * l.cost, 0)) : null;
  const countedValue = countedPackets === null ? null : r2(lines.reduce((t, l) => t + (l.soldCount || 0) * l.cost, 0));
  const tol = cigRules().tolerance;
  const diffs = lines.filter((l) => l.diff !== null && Math.abs(l.diff) > tol + 0.0005);
  // money: what Aronium says was sold when it is all in, else the cabinet count
  const suggested = ar.complete ? aroniumValue : countedValue !== null ? Math.max(0, countedValue) : aroniumValue || 0;
  return { shopCode, date, shift, lines, first: !last, last, aronium: ar, aroniumPackets, countedPackets, aroniumValue, countedValue, diffs, suggested: r2(suggested),
    uncounted: lines.filter((l) => l.closing === null).length };
}

function cashMove(user, { shopCode, date, type, amount, refUid, note }) {
  const T = require('./service.js');
  return T.addCashMove({ shopCode, date, type, amount: r2(amount), refUid, category: FUND, note, user });
}
function voidFundMoves(refUid, why) {
  db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, ${SET} WHERE ref_uid = ? AND category = ? AND status = 'active'`, [why, stamp(), deviceId(), refUid, FUND]);
}

export function saveTally(user, { shopCode, date = dateStr(), shift, closing = {}, aside, reason = '', note = '' }) {
  need(user, 'Log in first.');
  need(txt(shopCode), 'Choose the shop.');
  need(txt(shift), 'Choose the shift.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(date) && date <= dateStr(), 'Enter the shift date (not in the future).');
  const items = cigItems();
  need(items.length, `No cigarette products found. Check the groups in the cigarette settings (now: ${cigRules().groups.join(', ')}).`);
  const before = db().get("SELECT * FROM cig_tallies WHERE shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [shopCode, date, shift]);
  if (before) need(boss(user) || before.by_uid === user.uid, `This shift's tally was done by ${before.by_name}. A manager can change it.`);
  const missing = items.filter((it) => closing[it.uid] === '' || closing[it.uid] === null || closing[it.uid] === undefined || !Number.isFinite(Number(closing[it.uid])));
  need(!missing.length, `Count every cigarette product (0 if none left). Not counted: ${missing.slice(0, 4).map((x) => x.name).join(', ')}${missing.length > 4 ? ` and ${missing.length - 4} more` : ''}.`);
  need(items.every((it) => Number(closing[it.uid]) >= 0), 'A count cannot be below 0.');
  const w = workOutTally({ shopCode, date, shift, closing, exceptUid: before ? before.uid : '' });
  if (w.diffs.length) needReason(user, reason, `${w.diffs.length} product${w.diffs.length === 1 ? '' : 's'} differ from the Aronium sales (${w.diffs.slice(0, 3).map((l) => `${l.name} ${l.diff > 0 ? `${l.diff} more gone` : `${-l.diff} less gone`}`).join(', ')}). Write the reason.`);
  const a = aside === undefined || aside === null || aside === '' ? w.suggested : r2(aside);
  need(Number.isFinite(a) && a >= 0, 'Enter the cigarette money put aside.');
  if (Math.abs(a - w.suggested) > 0.009) needReason(user, reason, `The cigarette money should be ${$(w.suggested)}. Write why ${$(a)} was put aside.`);
  const uid = before ? before.uid : uuid('CT');
  const now = stamp(); const dev = deviceId();
  const vals = [shopCode, date, shift, before ? before.at : now, user.uid, user.name, JSON.stringify(w.lines), JSON.stringify(w.aronium.keys), w.aronium.complete ? 1 : 0, w.aroniumPackets, w.countedPackets,
    w.aroniumPackets === null || w.countedPackets === null ? null : q3(w.countedPackets - w.aroniumPackets), w.aroniumValue, w.countedValue, w.suggested, a, txt(reason) || null, txt(note) || null, now, dev];
  db().transaction(() => {
    if (before) {
      db().run(`UPDATE cig_tallies SET shop_code=?, shift_date=?, shift=?, at=?, by_uid=?, by_name=?, lines=?, z_keys=?, aronium_complete=?, aronium_packets=?, counted_packets=?, diff_packets=?, aronium_value=?, counted_value=?, suggested=?, aside=?, topped_up=0, reason=?, note=?,
        updated_at=?, updated_device=?, sync_status='pending' WHERE uid = ?`, vals.concat([uid]));
      voidFundMoves(uid, 'Tally changed');
    } else {
      db().run(`INSERT INTO cig_tallies (shop_code, shift_date, shift, at, by_uid, by_name, lines, z_keys, aronium_complete, aronium_packets, counted_packets, diff_packets, aronium_value, counted_value, suggested, aside, reason, note, updated_at, updated_device, uid)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, vals.concat([uid]));
    }
    if (a > 0) cashMove(user, { shopCode, date, type: 'adjust_out', amount: a, refUid: uid, note: `To the cigarette fund – ${shift} ${date}` });
  });
  audit({ user, action: `Cigarette tally ${shopCode} ${shift} ${date}: ${w.countedPackets ?? '–'} packets counted sold, Aronium ${w.aroniumPackets ?? '–'}; ${$(a)} put aside`, table: 'cig_tallies', recordUid: uid, reason });
  if (w.diffs.length) notify('cig_diff', `Cigarette tally ${shift} ${date}: the cabinet differs from the Aronium sales – ${w.diffs.slice(0, 5).map((l) => `${l.name} ${l.diff > 0 ? '+' : ''}${l.diff}`).join(', ')}. Reason: ${txt(reason) || '—'} (${user.name})`, { shopCode });
  return getTally(uid);
}
export function getTally(uid) {
  const t = has('cig_tallies') ? db().get('SELECT * FROM cig_tallies WHERE uid = ?', [uid]) : null;
  return t ? { ...t, lines: J(t.lines, []), z_keys: J(t.z_keys, []) } : null;
}
export function listTallies({ shopCode, from, limit = 60 } = {}) {
  if (!has('cig_tallies')) return [];
  return db().all(`SELECT * FROM cig_tallies WHERE status <> 'void' AND (? IS NULL OR shop_code = ?) AND (? IS NULL OR shift_date >= ?) ORDER BY shift_date DESC, at DESC LIMIT ?`, [shopCode || null, shopCode || null, from || null, from || null, limit])
    .map((t) => ({ ...t, lines: J(t.lines, []), z_keys: J(t.z_keys, []) }));
}
export function voidTally(user, uid, reason) {
  requirePerm(user, 'till_approve', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopOf('cig_tallies', uid)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(boss(user), 'Only a manager, the owner or admin can remove a tally.');
  needReason(user, reason, 'Give a reason.');
  const t = getTally(uid);
  need(t && t.status !== 'void', 'Not found.');
  db().run(`UPDATE cig_tallies SET status = 'void', void_reason = ?, ${SET} WHERE uid = ?`, [txt(reason), stamp(), deviceId(), uid]);
  voidFundMoves(uid, `Tally removed: ${txt(reason)}`);
  audit({ user, action: `Removed the cigarette tally ${t.shop_code} ${t.shift} ${t.shift_date}`, table: 'cig_tallies', recordUid: uid, reason });
  });
}

// End of days that came from the till PC after the tally was saved: added to that tally (its shift), and the
// difference in money worked out. Safe to call often.
export function attachLate() {
  if (!has('cig_tallies')) return 0;
  let n = 0;
  for (const t of db().all("SELECT * FROM cig_tallies WHERE status <> 'void' AND aronium_complete = 0 AND shift_date >= ? ORDER BY shift_date, at", [ago(7)])) {
    try {
      const counts = safe(() => db().all("SELECT till_name, z_number FROM till_counts WHERE shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [t.shop_code, t.shift_date, t.shift]), []);
      if (!counts.length) continue;
      const used = usedKeys(t.shop_code);
      const mine = new Set(J(t.z_keys, []));
      const zs = feed('z', 'AND shop_code = ?', [t.shop_code]).map((r) => ({ row: r, z: J(r.data, {}) })).filter((x) => x.z && x.z.date && Math.abs(new Date(x.z.date) - new Date(t.shift_date)) <= 86400000);
      const add = [];
      let allIn = true;
      for (const c of counts) {
        const x = zs.find((y) => (c.z_number ? normZ(y.z.number) === normZ(c.z_number) : y.z.date === t.shift_date) && (!tillNo(c.till_name) || !tillNo(y.row.till) || tillNo(c.till_name) === tillNo(y.row.till)));
        if (!x) { allIn = false; continue; }
        const key = `${x.row.source}|${x.z.key}`;
        if (mine.has(key)) continue;
        if (used.has(key)) continue; // a later tally already took it
        if (!zItems(x.row.source, x.z.key).found) { allIn = false; continue; }
        add.push(key);
      }
      if (!add.length && !allIn) continue;
      const keys = [...mine, ...add];
      const per = {};
      for (const k of keys) { const [src, ...rest] = k.split('|'); for (const [c, q] of Object.entries(zItems(src, rest.join('|')).per)) per[c] = q3((per[c] || 0) + q); }
      const lines = J(t.lines, []).map((l) => { const s = q3(per[txt(l.code).toLowerCase()] || 0); return { ...l, soldAronium: s, diff: l.soldCount === null ? null : q3(l.soldCount - s) }; });
      const ap = q3(lines.reduce((s, l) => s + (l.soldAronium || 0), 0));
      const av = r2(lines.reduce((s, l) => s + (l.soldAronium || 0) * (l.cost || 0), 0));
      db().run(`UPDATE cig_tallies SET lines = ?, z_keys = ?, aronium_complete = ?, aronium_packets = ?, aronium_value = ?, diff_packets = ?, ${SET} WHERE uid = ?`,
        [JSON.stringify(lines), JSON.stringify(keys), allIn ? 1 : 0, ap, av, t.counted_packets === null ? null : q3(t.counted_packets - ap), stamp(), deviceId(), t.uid]);
      n += 1;
    } catch (e) { /* one tally never stops the rest */ }
  }
  return n;
}
// Put the rest aside (or give back) when the Aronium value came in later and differs from what was put aside.
export function settleLate(user, uid) {
  requirePerm(user, ['till_approve', 'till_count', 'shop_staff'], { money: true }); // the cashier puts the rest aside when the End of day comes in late // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user, 'Log in first.');
  const t = getTally(uid);
  need(t && t.status !== 'void', 'Not found.');
  const should = t.aronium_complete ? r2(t.aronium_value) : null;
  need(should !== null, 'The Aronium figures for this shift are not all in yet.');
  const diff = r2(should - r2(t.aside) - r2(t.topped_up));
  need(Math.abs(diff) > 0.009, 'Nothing to put aside – it is right.');
  cashMove(user, { shopCode: t.shop_code, date: dateStr(), type: diff > 0 ? 'adjust_out' : 'adjust_in', amount: Math.abs(diff), refUid: uid, note: `${diff > 0 ? 'More to' : 'Back from'} the cigarette fund – ${t.shift} ${t.shift_date} (Aronium came in later)` });
  db().run(`UPDATE cig_tallies SET topped_up = ?, ${SET} WHERE uid = ?`, [r2(r2(t.topped_up) + diff), stamp(), deviceId(), uid]);
  audit({ user, action: `Cigarette fund ${diff > 0 ? '+' : '−'}${$(Math.abs(diff))} for ${t.shop_code} ${t.shift} ${t.shift_date} (Aronium came in later)`, table: 'cig_tallies', recordUid: uid });
  return diff;
  });
}

// ---------------------------------------------------------------- the fund
export function fundOf(shopCode) {
  const m = (type) => r2(safe(() => db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM cash_moves WHERE shop_code = ? AND category = ? AND type = ? AND status = 'active'`, [shopCode, FUND, type]).s, 0));
  const paid = r2(safe(() => db().get("SELECT IFNULL(SUM(amount - IFNULL(withheld,0)),0) AS s FROM ap_payments WHERE method = 'cash' AND status = 'active' AND cash_from = ?", [`cig:${shopCode}`]).s, 0));
  const put = m('adjust_out'); const back = m('adjust_in');
  return { shopCode, put, back, paid, balance: r2(put - back - paid) };
}
export function fundMoves(shopCode, limit = 60) {
  const a = safe(() => db().all(`SELECT move_date AS date, type, amount, note, by_name FROM cash_moves WHERE shop_code = ? AND category = ? AND status = 'active' ORDER BY move_date DESC, updated_at DESC LIMIT ?`, [shopCode, FUND, limit]), [])
    .map((x) => ({ date: x.date, amount: x.type === 'adjust_out' ? x.amount : -x.amount, what: x.note, by: x.by_name }));
  const b = safe(() => db().all("SELECT pay_date AS date, amount, supplier_name, paid_by_name FROM ap_payments WHERE method = 'cash' AND status = 'active' AND cash_from = ? ORDER BY pay_date DESC LIMIT ?", [`cig:${shopCode}`, limit]), [])
    .map((x) => ({ date: x.date, amount: -x.amount, what: `Paid ${x.supplier_name}`, by: x.paid_by_name }));
  return a.concat(b).sort((x, y) => String(y.date).localeCompare(String(x.date))).slice(0, limit);
}
// The cigarette invoices still owing (from the suppliers chosen in the settings).
export function cigInvoices() {
  const AP = require('../payables/service.js');
  return cigRules().suppliers.flatMap((s) => safe(() => AP.listInvoices({ filter: 'unpaid', supplierUid: s }), [])).filter((i) => i.kind !== 'credit')
    .sort((a, b) => String(a.due_date).localeCompare(String(b.due_date)));
}
export function payFromFund(user, { shopCode, invoiceUids = [], payDate = dateStr(), receivedBy = '' }) {
  need(user && (boss(user) || can(user, 'payments_make')), 'You cannot pay suppliers.');
  const AP = require('../payables/service.js');
  const inv = invoiceUids.map((u) => AP.getInvoice(u)).filter(Boolean);
  need(inv.length, 'Tick the invoices to pay.');
  const sup = inv[0].supplier_uid;
  need(inv.every((i) => i.supplier_uid === sup), 'Pay one supplier at a time.');
  const total = r2(inv.reduce((t, i) => t + r2(i.owing), 0));
  const f = fundOf(shopCode);
  need(f.balance >= total - 0.004, `The cigarette fund at ${shopCode} has ${$(f.balance)} – not enough for ${$(total)}.`);
  return AP.makePayment(user, { supplierUid: sup, method: 'cash', shopCode, cashFrom: `cig:${shopCode}`, payDate, receivedBy, notes: 'From the cigarette fund', allocations: inv.map((i) => ({ invoiceUid: i.uid, amount: r2(i.owing) })) });
}
// The fund's cash goes back to the shop (e.g. the invoice was paid by cheque).
export function fundBack(user, { shopCode, amount, reason }) {
  need(boss(user), 'Only a manager, the owner or admin can do this.');
  needReason(user, reason, 'Say why (e.g. the invoice was paid by cheque).');
  const a = r2(amount);
  need(a > 0, 'Enter the amount.');
  need(fundOf(shopCode).balance >= a - 0.004, 'The cigarette fund does not have that much.');
  cashMove(user, { shopCode, date: dateStr(), type: 'adjust_in', amount: a, refUid: uuid('CF'), note: `Back from the cigarette fund – ${txt(reason)}` });
  audit({ user, action: `${$(a)} back from the cigarette fund to ${shopCode} cash`, table: 'cash_moves', reason });
}

// ---------------------------------------------------------------- 1.0.0 build 1: this lot's status, and no new lot before the last is paid
// One supplier, a 7-day account. The status of the lot now: its invoice, what has been sold of it so far (at cost, from
// the tallies since it came), what is put aside in the cigarette bag, what is still needed, and when it is due.
export function cigStatus(shopCode) {
  const owing = safe(() => cigInvoices(), []);
  const AP = safe(() => require('../payables/service.js'), null);
  let inv = owing[0] || null;
  if (!inv && AP) {
    // nothing owing: the last cigarette invoice received (already paid)
    const last = cigRules().suppliers.map((s) => safe(() => AP.listInvoices({ supplierUid: s, limit: 5 }), [])).flat().filter((i) => i.kind !== 'credit' && i.status !== 'void')
      .sort((a, b) => String(b.invoice_date).localeCompare(String(a.invoice_date)))[0];
    inv = last || null;
  }
  const shop = txt(shopCode) || (inv && inv.shop_code) || (cigShops()[0] || '');
  const fund = shop ? fundOf(shop) : { balance: 0, put: 0, back: 0, paid: 0 };
  if (!inv) return { shopCode: shop, invoice: null, sold: 0, aside: fund.balance, needed: 0, due: null, overdue: false, canReceive: true, owingCount: 0, fund };
  const from = inv.invoice_date;
  const sold = r2(listTallies({ shopCode: shop, from, limit: 1000 }).reduce((t, x) => t + (x.aronium_complete ? r2(x.aronium_value) : r2(x.counted_value ?? x.suggested ?? x.aside)), 0));
  const left = r2(inv.owing !== undefined ? inv.owing : inv.total);
  const needed = r2(Math.max(0, left - fund.balance));
  const due = inv.due_date || null;
  return { shopCode: shop, invoice: { uid: inv.uid, no: inv.invoice_no, date: inv.invoice_date, total: r2(inv.total), owing: left, supplier: inv.supplier_name }, sold, aside: fund.balance, needed, due,
    overdue: !!due && left > 0.004 && due < dateStr(), canReceive: !owing.length, owingCount: owing.length, fund };
}
// Called when a new invoice is entered (Invoices / Goods came in): a cigarette supplier's next invoice is refused while
// the last one is not paid in full. The owner / admin may let it through with a reason (kept and sent to Viber).
export function guardCigInvoice(user, supplierUid, { override = false, reason = '' } = {}) {
  if (!supplierUid || !cigRules().suppliers.includes(supplierUid)) return null;
  const owing = safe(() => cigInvoices(), []).filter((i) => r2(i.owing) > 0.004);
  if (!owing.length) return null;
  const i = owing[0];
  const msg = `The last cigarette invoice ${i.invoice_no || ''} (${$(i.owing)} still owing${i.due_date ? `, due ${i.due_date}` : ''}) must be paid in full before the next lot is received.`;
  const top = !!user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
  if (!override || !top) throw new AppError(`${msg}${top ? ' To receive it anyway, tick "Let it through" and write why.' : ' The owner or admin can let it through.'}`);
  need(txt(reason).length >= 4, 'Write why the next cigarette lot is received before the last invoice is paid.');
  audit({ user, action: `Cigarette invoice received while ${i.invoice_no || 'the last one'} is unpaid (${$(i.owing)})`, table: 'ap_invoices', recordUid: i.uid, reason });
  try { notify('cig_diff', `${user.name} let a new cigarette invoice in while ${i.invoice_no || 'the last one'} still owes ${$(i.owing)}: ${txt(reason)}`, {}); } catch (e) { /* only a message */ }
  return { overridden: true, invoice: i };
}

// ---------------------------------------------------------------- reminders
export function cigAlerts(user) {
  const out = [];
  const shops = cigShops();
  if (!shops.length || !has('cig_tallies') || !cigItems().length) return out;
  let fresh = '';
  try { fresh = require('../../services/goLive.js').freshFrom() || ''; } catch (e) { fresh = ''; }
  const from = [ago(1), fresh].filter(Boolean).sort().pop();
  for (const shop of shops) {
    const counts = safe(() => db().all("SELECT DISTINCT shift_date, shift FROM till_counts WHERE shop_code = ? AND shift_date >= ? AND status <> 'void' ORDER BY shift_date, shift", [shop, from]), []);
    const done = new Set(db().all("SELECT shift_date, shift FROM cig_tallies WHERE shop_code = ? AND status <> 'void' AND shift_date >= ?", [shop, from]).map((t) => `${t.shift_date}|${t.shift}`));
    const todo = counts.filter((c) => !done.has(`${c.shift_date}|${c.shift}`));
    if (todo.length) out.push({ id: `cig-todo-${shop}-${todo.length}`, level: 'warning', text: `Cigarette tally not done: ${shop} ${todo.map((c) => `${c.shift} ${c.shift_date.slice(5)}`).join(', ')}`, sub: 'Count the cabinet and put the cigarette money aside.', nav: { screen: 'CigTally', params: { shopCode: shop, date: todo[0].shift_date, shift: todo[0].shift } } });
  }
  if (boss(user)) {
    const week = ago(7);
    const bad = listTallies({ from: week }).filter((t) => t.lines.some((l) => l.diff !== null && Math.abs(l.diff) > cigRules().tolerance + 0.0005));
    if (bad.length) out.push({ id: `cig-diff-${bad.length}-${bad[0].uid}`, level: 'warning', notify: true, text: `Cigarettes: ${bad.length} shift${bad.length === 1 ? '' : 's'} where the cabinet differs from Aronium`, sub: bad.slice(0, 3).map((t) => `${t.shop_code} ${t.shift} ${t.shift_date.slice(5)}: ${t.reason || ''}`).join(' · '), nav: { screen: 'CigFund' } });
    const late = listTallies({ from: week }).filter((t) => t.aronium_complete && Math.abs(r2(t.aronium_value) - r2(t.aside) - r2(t.topped_up)) > 0.009);
    if (late.length) out.push({ id: `cig-late-${late.length}-${late[0].uid}`, level: 'info', text: `Cigarette money: ${late.length} shift${late.length === 1 ? '' : 's'} to put right (Aronium came in later)`, nav: { screen: 'CigFund' } });
    const owing = cigInvoices();
    if (owing.length) {
      const due = owing.filter((i) => i.due_date && i.due_date <= ago(-2));
      const tot = r2(due.reduce((t, i) => t + r2(i.owing), 0));
      const bal = r2(shops.reduce((t, s) => t + fundOf(s).balance, 0));
      if (due.length && bal < tot - 0.004) out.push({ id: `cig-short-${due.length}`, level: 'warning', text: `Cigarette invoices due ${$(tot)} – the cigarette fund has ${$(bal)}`, nav: { screen: 'CigFund' } });
    }
  }
  return out;
}

// The shift names (Tills & rules), and the shift to tally now: the latest balanced shift of today not tallied yet.
export function shiftChoices() { const r = getShared('till_rules', {}) || {}; return Array.isArray(r.shifts) && r.shifts.length ? r.shifts : ['Morning', 'Afternoon', 'Night', 'Full day']; }
export function nextShift(shopCode, date = dateStr()) {
  const done = new Set(has('cig_tallies') ? db().all("SELECT shift FROM cig_tallies WHERE shop_code = ? AND shift_date = ? AND status <> 'void'", [shopCode, date]).map((t) => t.shift) : []);
  const counted = safe(() => db().all("SELECT shift FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void' ORDER BY counted_at DESC", [shopCode, date]).map((c) => c.shift), []);
  return counted.find((s) => !done.has(s)) || counted[0] || shiftChoices()[0];
}
