// 1.0.0 (build 1) Start shift and End shift – one page each, for the cashier, the shop assistant and the baker.
//
// Start shift: clocked in on the Time Clock (face check), then that shop's (or the bakery's) own checklist. Till staff see
// the float the till started with – read from Aronium (the till PC's StartingCash), never typed. The handover notes
// written since the last shift are shown to read.
//
// End shift (one page, top to bottom):
//   1. Aronium End of day – already in from the till PC (Z number, sales, cash, float). Only when the till PC has sent
//      nothing: a very short manual Z (Z number, total, cash, M-PAiSA) with a REQUIRED photo of the Z report.
//   2. Count the cash – notes and coins only; over / short shown at once. A short is taken from pay unless paid now.
//   3. Cigarettes – the cabinet count, what Aronium sold, the money to put aside (cigTally.js).
//   4. The checklist.
//   5. Handover – who takes over, the notes of the shift.
//   Finish stays shut until all is done. The owner / admin can let it through with their PIN (who and why kept).
// Bakery: what was baked, wastage, the checklist and handover only – never any till money.
//
// Everything is booked through the screens' own services (till count, shortage, cigarette tally, checklist,
// handover, Time Clock), inside ONE transaction: either the whole shift end is saved or nothing is.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, clock, money } from '../../services/core.js';
import { actsAsOwner, can } from '../../services/access.js';
import * as T from './service.js';
import { tillNo } from './eod.js';
import * as MP from './mpaisaShift.js';
import * as D from '../../services/duties.js';
import * as HN from '../../services/handoverNotes.js';
import { requirePerm, requireShop, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const ownerish = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
const isCash = (n) => /cash/i.test(String(n || '')) && !/cheque|card|account/i.test(String(n || ''));
const isCard = (n) => /card|eftpos|visa|master|debit/i.test(String(n || ''));

// ---------------------------------------------------------------- who, where, which shift
export function isBakeryPerson(user) {
  if (!user) return false;
  if (user.role === 'worker') return true;
  return safe(() => D.dutyOf(user) === 'baker', false);
}
export function shiftNames() { return T.tillRules().shifts; }
// The shift by the time of day (the person can change it with the drop-down).
export function defaultShift(now = clock.now()) {
  const names = shiftNames();
  if (names.length === 1) return names[0];
  const h = now.getHours();
  const want = h < 12 ? /morn/i : h < 17 ? /after|day/i : /night|even/i;
  return names.find((n) => want.test(n)) || names[0];
}
export function shopsForUser(user) {
  const all = safe(() => db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort, code'), []);
  return user && user.shop_code && all.some((s) => s.code === user.shop_code) ? all.filter((s) => s.code === user.shop_code).concat(all.filter((s) => s.code !== user.shop_code)) : all;
}
export const placeOf = (kind, shopCode) => (kind === 'bakery' ? HN.BAKERY : shopCode);

// ---------------------------------------------------------------- Aronium: the float and the End of day of a till
const matchTill = (tillName, aroniumTill, count) => {
  const a = tillNo(tillName); const b = tillNo(aroniumTill);
  return a && b ? a === b : count === 1;
};
// The float the till started with: Aronium's opening cash (StartingCash) when the till PC sent it, else the app's.
export function floatFor(shopCode, tillUid) {
  const till = tillUid ? db().get('SELECT * FROM tills WHERE uid = ?', [tillUid]) : null;
  const app = till ? T.openingFloat(till.uid) : 0;
  let ar = null;
  try {
    const L = require('../aronium/link.js');
    const list = L.tillDrawer({ shop: shopCode });
    const t = list.find((x) => matchTill(till && till.name, x.till || x.source, list.length));
    if (t && t.floatFrom === 'Aronium') ar = r2(t.float);
  } catch (e) { ar = null; }
  return ar === null ? { amount: r2(app), from: 'app', app: r2(app) } : { amount: ar, from: 'Aronium', app: r2(app) };
}
// The till PC's End of day for this till, not matched to a till balance yet (the newest).
export function linkEodFor(shopCode, tillUid, date = dateStr()) {
  if (!has('aronium_eods')) return null;
  const till = tillUid ? db().get('SELECT * FROM tills WHERE uid = ?', [tillUid]) : null;
  const tills = T.listTills({ shopCode });
  const rows = db().all("SELECT * FROM aronium_eods WHERE shop_code = ? AND source = 'link' AND state = 'no_till' AND eod_date BETWEEN ? AND ? ORDER BY eod_date DESC, created_at DESC",
    [shopCode, addDays(date, -1), date]).filter((e) => !e.till_name || !till || matchTill(till.name, e.till_name, tills.length));
  return rows[0] ? eodShape(rows[0]) : null;
}
// 1.0.0 the moment an End of day closed ('YYYY-MM-DD HH:MM:SS'), for the recharge sales of that shift; a time
// later than now (a till PC's clock running fast) is taken as now.
export function rcUntil(closedAt) {
  const t = String(closedAt || '').replace('T', ' ').slice(0, 19);
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/.test(t)) return stamp();
  const full = t.length === 16 ? `${t}:00` : t;
  return full > stamp() ? stamp() : full;
}
// 1.0.0 build 2: one End of day row (aronium_eods) in the shape the End shift and Balance the till pages use.
export function eodShape(e) {
  if (!e) return null;
  const shopCode = e.shop_code;
  // the till PC's own figures: payment names, the float and cash in / out (aronium_feed kind 'z')
  let z = null;
  try {
    for (const r of db().all("SELECT source, data FROM aronium_feed WHERE kind = 'z' AND shop_code = ?", [shopCode])) {
      const d = J(r.data, null);
      if (d && `EOD-${r.source}-${d.key}` === e.uid) { z = d; break; }
    }
  } catch (x) { z = null; }
  const tenders = [];
  if (z && z.payments && typeof z.payments === 'object') {
    for (const [name, amt] of Object.entries(z.payments)) if (!isCash(name) && Math.abs(r2(amt)) >= 0.005) tenders.push({ method: isCard(name) ? 'EFTPOS / card' : /paisa/i.test(name) ? 'M-PAiSA' : name, amount: r2(amt) });
  } else {
    if (Math.abs(r2(e.card)) >= 0.005) tenders.push({ method: 'EFTPOS / card', amount: r2(e.card) });
    if (Math.abs(r2(e.other)) >= 0.005) tenders.push({ method: 'M-PAiSA', amount: r2(e.other) });
  }
  const fl = z && z.float && typeof z.float === 'object' ? z.float : {};
  const hasFloat = fl.opening !== undefined && fl.opening !== null && Number.isFinite(Number(fl.opening));
  return {
    uid: e.uid, zNumber: e.z_number || '', date: e.eod_date, total: r2(e.total), cash: e.cash === null || e.cash === undefined ? null : r2(e.cash), vat: e.vat, zero: e.zero,
    tenders, float: hasFloat ? r2(fl.opening) : null, cashIn: r2(fl.cash_in || 0), cashOut: r2(fl.cash_out || 0), tillName: e.till_name || '',
    refunds: z ? r2(z.refunds) : null, receipts: z ? Number(z.receipts) || 0 : null,
    closedAt: z ? txt(z.closed_at) : '', cashiers: z && z.cashiers && typeof z.cashiers === 'object' ? z.cashiers : {}, payments: z && z.payments && typeof z.payments === 'object' ? z.payments : null,
  };
}

// ---------------------------------------------------------------- amount sanity (figures that cannot be right)
// [{ level: 'stop' | 'check', key, text }] – 'stop' is refused; 'check' must be confirmed ("Yes, it is right").
export function sanityProblems({ counted, expected, zCash, zTotal, aroniumCash, tenders = [], denominations } = {}) {
  const out = [];
  const nums = [['counted', counted, 'The cash counted'], ['zCash', zCash, 'The cash sales'], ['zTotal', zTotal, 'The total sales']];
  for (const [k, v, label] of nums) if (v !== null && v !== undefined && v !== '' && Number(v) < 0) out.push({ level: 'stop', key: `neg-${k}`, text: `${label} cannot be below zero.` });
  for (const t of tenders || []) if (Number(t.amount) < 0) out.push({ level: 'stop', key: 'neg-tender', text: `${t.method || 'A payment'} cannot be below zero.` });
  for (const [k, n] of Object.entries(denominations || {})) {
    const q = Number(n);
    if (n !== '' && n !== null && n !== undefined && (!Number.isFinite(q) || q < 0)) out.push({ level: 'stop', key: 'neg-note', text: 'A number of notes or coins cannot be below zero.' });
    else if (q > 2000) out.push({ level: 'check', key: `many-${k}`, text: `${q} of one note or coin is a lot – did you type the dollars instead of how many?` });
  }
  const c = r2(counted); const e = r2(expected);
  if (Number.isFinite(c) && Number.isFinite(e)) {
    if (e >= 20 && c > e * 10) out.push({ level: 'stop', key: 'ten-times', text: `The cash counted (${$(c)}) is more than 10 times what should be in the till (${$(e)}). Count again – maybe a dollar amount was typed where the number of notes goes.` });
    else if (c >= 20 && e >= 0 && e < 1 && c > 500) out.push({ level: 'check', key: 'no-sales', text: `${$(c)} counted but almost nothing should be in the till. Is this the right till?` });
    else if (e >= 100 && c < e / 10) out.push({ level: 'check', key: 'tenth', text: `Only ${$(c)} counted – ${$(e)} should be in the till. Is the count complete?` });
  }
  if (aroniumCash !== null && aroniumCash !== undefined && zCash !== null && zCash !== undefined && zCash !== '') {
    const a = r2(aroniumCash); const z = r2(zCash);
    if (a >= 20 && z > a * 10) out.push({ level: 'stop', key: 'z-ten-times', text: `The cash typed from the Z report (${$(z)}) is more than 10 times what Aronium has seen today (${$(a)}). Check the figure.` });
    if (z >= 20 && a >= 0 && z * 10 < a) out.push({ level: 'check', key: 'z-tenth', text: `The cash typed from the Z report (${$(z)}) is much less than Aronium has seen today (${$(a)}). Check the figure.` });
  }
  if (zTotal !== null && zTotal !== undefined && zTotal !== '' && zCash !== null && zCash !== undefined && zCash !== '' && r2(zCash) > r2(zTotal) + 0.004) out.push({ level: 'stop', key: 'cash-over-total', text: `The cash sales (${$(zCash)}) cannot be more than the total sales (${$(zTotal)}).` });
  return out;
}

// ---------------------------------------------------------------- the shift record
export function getShiftEnd(uid) {
  const r = has('shift_ends') ? db().get('SELECT * FROM shift_ends WHERE uid = ?', [uid]) : null;
  return r ? { ...r, flags: J(r.flags, []) } : null;
}
// This person's shift still running (started, not finished), today or yesterday (a night shift).
export function myOpenShift(user, date = dateStr()) {
  if (!user || !has('shift_ends')) return null;
  const r = db().get("SELECT * FROM shift_ends WHERE user_uid = ? AND status = 'started' AND shift_date BETWEEN ? AND ? ORDER BY started_at DESC LIMIT 1", [user.uid, addDays(date, -1), date]);
  return r ? { ...r, flags: J(r.flags, []) } : null;
}
export function lastFinished(user) {
  if (!user || !has('shift_ends')) return null;
  const r = db().get("SELECT * FROM shift_ends WHERE user_uid = ? AND status = 'finished' ORDER BY finished_at DESC LIMIT 1", [user.uid]);
  return r ? { ...r, flags: J(r.flags, []) } : null;
}
function clockState(user) { try { return require('../timeclock/service.js').stateOf(user.uid); } catch (e) { return { state: 'out' }; } }

// What the Start shift page shows.
export function startInfo(user, { date = dateStr(), shopCode, tillUid, shift } = {}) {
  need(user, 'Log in first.');
  const kind = isBakeryPerson(user) ? 'bakery' : 'till';
  const open = myOpenShift(user, date);
  const shops = shopsForUser(user);
  const shop = txt(open ? open.shop_code : shopCode) || (shops[0] || {}).code || txt(user.shop_code) || 'S1';
  const tills = kind === 'till' ? T.listTills({ shopCode: shop }) : [];
  const till = kind === 'till' ? (tills.find((t) => t.uid === (open ? open.till_uid : tillUid)) || tills[0] || null) : null;
  const sh = txt(open ? open.shift : shift) || defaultShift();
  const fl = kind === 'till' && till ? floatFor(shop, till.uid) : null;
  const duty = safe(() => D.myDutyToday(user, date, { shopCode: kind === 'bakery' ? HN.BAKERY : shop }), null);
  const place = placeOf(kind, shop);
  // 1.0.0 build 2: the shop's M-PAiSA wallet – the balance now is asked once at the start (the last close filled in)
  const mp = kind === 'till' && till ? safe(() => { const w = MP.mpWallet(shop); return w ? { wallet: w, last: MP.lastClose(shop) } : null; }, null) : null;
  // 1.0.0 the recharge machine balances (Vodafone / Inkk) – asked only when no shift has closed them yet
  const rc = kind === 'till' && till ? safe(() => require('./recharge.js').startPlan(shop), []) : [];
  return { kind, date, open, shops, shopCode: shop, tills, till, tillUid: till ? till.uid : '', shift: sh, shifts: shiftNames(), float: fl, clock: clockState(user), duty, place, mp, rc,
    unread: HN.unreadNotes(user, place), notes: HN.listNotes({ place }) };
}

// Start the shift: must be clocked in (Time Clock). Till staff: the till shift starts with Aronium's float.
export function startShift(user, { date = dateStr(), shopCode, tillUid, shift, mpOpen, rcOpen } = {}) {
  const info = startInfo(user, { date, shopCode, tillUid, shift });
  need(info.clock.state !== 'out', 'Clock in first on the Time Clock (your face), then start the shift.');
  if (info.open) return { shift: info.open, warning: null };
  need(txt(info.shift), 'Choose the shift.');
  if (info.kind === 'till') need(info.till, 'There is no till at this shop yet. The admin adds it in Settings › Tills & rules.');
  const uid = uuid('SE');
  const now = stamp();
  let warning = null;
  const flags = [];
  if (info.kind === 'till') {
    try { require('./shifts.js').startShift(user, { shopCode: info.shopCode, tillUid: info.till.uid, date, shift: info.shift, cashierUid: user.uid, openingFloat: info.float.amount }); } catch (e) {
      if (!/already (started|balanced)/i.test(String(e.message))) { warning = e.message; flags.push('earlier shift not balanced'); }
    }
    if (info.float.from === 'Aronium' && Math.abs(info.float.amount - info.float.app) > 0.004) flags.push(`float: Aronium ${$(info.float.amount)}, the app had ${$(info.float.app)}`);
  }
  const mpo = info.mp && mpOpen !== undefined && mpOpen !== null && mpOpen !== '' && Number.isFinite(Number(mpOpen)) ? r2(mpOpen) : (info.mp && info.mp.last ? info.mp.last.amount : null);
  if (mpo !== null) need(mpo >= 0, 'The M-PAiSA balance cannot be below zero.');
  if (info.mp && info.mp.last && mpo !== null && Math.abs(mpo - info.mp.last.amount) > 0.004) flags.push(`M-PAiSA at the start ${$(mpo)}, the last shift closed at ${$(info.mp.last.amount)}`);
  for (const p of info.rc || []) need(p.last || (rcOpen && rcOpen[p.wallet.uid] !== undefined && rcOpen[p.wallet.uid] !== null && rcOpen[p.wallet.uid] !== ''), `Type the ${p.wallet.name} balance on the recharge machine.`);
  db().run(`INSERT INTO shift_ends (uid, kind, user_uid, name, shop_code, till_uid, till_name, shift_date, shift, started_at, float_start, float_from, flags, status, updated_at, updated_device, mp_open)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'started', ?,?,?)`,
  [uid, info.kind, user.uid, user.name, info.shopCode, info.till ? info.till.uid : null, info.till ? info.till.name : null, date, info.shift, now,
    info.float ? info.float.amount : null, info.float ? info.float.from : null, JSON.stringify(flags), now, deviceId(), mpo]);
  audit({ user, action: `Started ${info.kind === 'bakery' ? 'the bakery shift' : `${info.till.name} ${info.shift}`} ${date}${info.float ? ` – float ${$(info.float.amount)} (${info.float.from === 'Aronium' ? 'from Aronium' : 'the app'})` : ''}`, table: 'shift_ends', recordUid: uid });
  // 1.0.0 the recharge machine balances at the start (filled in with the last close – kept only when different)
  if ((info.rc || []).length) {
    const R = require('./recharge.js');
    asService(() => R.recordOpen(user, { shopCode: info.shopCode, values: rcOpen || {}, shiftUid: uid, date, at: now })).forEach((x) => { if (x.flag) flags.push(x.flag); });
    db().run('UPDATE shift_ends SET flags = ? WHERE uid = ?', [JSON.stringify(flags), uid]);
  }
  return { shift: getShiftEnd(uid), warning };
}

// ---------------------------------------------------------------- what the End shift page shows
function bakedToday(date) {
  const rows = safe(() => db().all(`SELECT p.name AS name, SUM(COALESCE(b.good, b.cut_pieces, b.expected_pieces, 0)) AS n FROM batches b JOIN products p ON p.id = b.product_id
    WHERE b.status = 'finished' AND substr(COALESCE(b.finished_at, b.started_at), 1, 10) = ? GROUP BY p.name ORDER BY p.name`, [date]), []);
  const active = safe(() => db().get("SELECT COUNT(*) AS n FROM batches WHERE status = 'active'").n, 0);
  const waste = safe(() => db().get("SELECT COUNT(*) AS n FROM transactions WHERE type = 'WASTAGE' AND txn_date = ?", [date]).n, 0);
  return { lines: rows.map((r) => ({ name: r.name, qty: Math.round(Number(r.n) || 0) })), total: rows.reduce((s, r) => s + (Math.round(Number(r.n) || 0)), 0), active, wastage: waste };
}
export function endPlan(user, { date = dateStr(), shopCode, tillUid, shift } = {}) {
  need(user, 'Log in first.');
  const start = startInfo(user, { date, shopCode, tillUid, shift });
  const kind = start.kind;
  const shop = start.shopCode;
  const till = start.till;
  const sDate = start.open ? start.open.shift_date : date;
  const out = { kind, date: sDate, shopCode: shop, till, tillUid: till ? till.uid : '', tills: start.tills, shift: start.shift, shifts: start.shifts, open: start.open, place: start.place, shops: start.shops };
  out.duty = safe(() => D.myDutyToday(user, sDate, { shopCode: kind === 'bakery' ? HN.BAKERY : shop }), null);
  out.notes = HN.shiftNotes({ place: start.place, date: sDate });
  out.staff = safe(() => db().all("SELECT uid, name, role, shop_code FROM users WHERE active = 1 AND uid <> ? AND role <> 'accountant' AND IFNULL(sync_status,'') <> 'seed' ORDER BY name", [user.uid]), []);
  out.clock = clockState(user);
  if (kind === 'bakery') { out.baked = bakedToday(sDate); return out; }
  out.ownTill = (() => { try { return require('../staff/flags.js').canBalanceOwnTill(user); } catch (e) { return false; } })();
  out.checkers = out.staff.filter((p) => ['owner', 'admin', 'manager', 'supervisor'].includes(p.role) || safe(() => can(db().get('SELECT * FROM users WHERE uid = ?', [p.uid]), 'till_approve'), false));
  out.eod = till ? linkEodFor(shop, till.uid, sDate) : null;
  const fl = till ? floatFor(shop, till.uid) : { amount: 0, from: 'app', app: 0 };
  // the float at the start: the End of day's own (Aronium), else what the shift started with, else Aronium's / the app's now
  out.float = out.eod && out.eod.float !== null ? { amount: out.eod.float, from: 'Aronium', app: fl.app }
    : start.open && start.open.float_start !== null && start.open.float_start !== undefined ? { amount: r2(start.open.float_start), from: start.open.float_from || 'app', app: fl.app } : fl;
  out.paidOuts = till ? safe(() => require('../payables/service.js').tillPaidOuts(till.uid, sDate), []) : [];
  out.rules = T.tillRules();
  // cigarettes: only at a shop that does the tally and has cigarette products
  out.cig = { on: false, items: [] };
  try {
    const CG = require('./cigTally.js');
    const items = CG.cigShops().includes(shop) ? CG.cigItems() : [];
    if (items.length) {
      const done = db().get("SELECT uid FROM cig_tallies WHERE shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [shop, sDate, start.shift]);
      out.cig = { on: true, items, done: done ? done.uid : null, last: CG.lastTally(shop, { before: { date: sDate, shift: start.shift } }) };
    }
  } catch (e) { out.cig = { on: false, items: [] }; }
  // what Aronium has seen as cash today (for the sanity check of a typed Z)
  out.aroniumCashNow = null;
  try {
    const L = require('../aronium/link.js');
    const list = L.tillDrawer({ shop });
    const t = list.find((x) => matchTill(till && till.name, x.till || x.source, list.length));
    if (t && t.exact !== undefined) out.aroniumCashNow = r2(t.cashSales - t.cashRefunds);
  } catch (e) { out.aroniumCashNow = null; }
  out.counted = till ? db().get("SELECT uid FROM till_counts WHERE till_uid = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [till.uid, sDate, start.shift]) : null;
  return out;
}

// The figures of the till balance: from the till PC's End of day, or the manual Z.
export function zFigures(plan, manualZ) {
  if (plan.eod) {
    const e = plan.eod;
    const paid = r2((plan.paidOuts || []).reduce((s, p) => s + r2(p.amount), 0));
    // cash taken out in Aronium for a supplier paid from the till is the same money as the payment: counted once
    const extraOut = r2(Math.max(0, e.cashOut - paid));
    return { source: 'link', eodUid: e.uid, zNumber: e.zNumber, zTotal: e.total, zCash: e.cash === null ? r2(e.total - e.tenders.reduce((s, t) => s + t.amount, 0)) : e.cash, tenders: e.tenders,
      zVat: e.vat, zZero: e.zero, cashIn: e.cashIn, cashOut: extraOut, float: plan.float.amount };
  }
  if (!manualZ) return null;
  const m = manualZ;
  const num = (v) => (v === '' || v === null || v === undefined ? null : r2(v));
  const tenders = [];
  if (num(m.mpaisa)) tenders.push({ method: 'M-PAiSA', amount: num(m.mpaisa) });
  if (num(m.card)) tenders.push({ method: 'EFTPOS / card', amount: num(m.card) });
  return { source: 'manual', eodUid: null, zNumber: txt(m.zNumber), zTotal: num(m.total), zCash: num(m.cash), tenders, zVat: null, zZero: null, cashIn: 0, cashOut: 0, float: plan.float.amount, photos: m.photos || [] };
}
// Count the cash: what should be in the till and the over / short (shown at once on the page).
export function workOutEnd(plan, { denominations, manualZ } = {}) {
  const z = zFigures(plan, manualZ);
  const counted = T.countDenoms(denominations || {});
  if (!z || z.zCash === null) return { z, counted, expected: null, overShort: null };
  const payouts = r2((plan.paidOuts || []).reduce((s, p) => s + r2(p.amount), 0) + z.cashOut);
  const expected = r2(r2(z.float) + r2(z.zCash) + r2(z.cashIn) - payouts);
  return { z, counted, expected, overShort: r2(counted - expected), payouts };
}

// What is still to do before Finish (each with a plain line for the page).
export function blockersFor(plan, input = {}) {
  const out = [];
  if (plan.kind === 'till') {
    const z = zFigures(plan, input.manualZ);
    if (!plan.till) out.push({ key: 'till', text: 'There is no till at this shop.' });
    else if (plan.counted) out.push({ key: 'counted', text: 'This till and shift is already balanced.', hard: true });
    if (!z) out.push({ key: 'eod', text: 'Aronium\'s End of day is not in yet. Check again in a minute, or type the Z report (with a photo).' });
    else if (z.source === 'manual') {
      if (!z.zNumber || z.zTotal === null || z.zCash === null) out.push({ key: 'eod', text: 'Type the Z number, the total and the cash from the Z report.' });
      if (!(z.photos || []).length) out.push({ key: 'zphoto', text: 'Take a photo of the Z report.', hard: true });
    }
    if (!Object.values(input.denominations || {}).some((n) => Number(n) > 0)) out.push({ key: 'count', text: 'Count the cash.' });
    if (plan.cig && plan.cig.on && !plan.cig.done) {
      const cl = input.cigClosing || {};
      const left = plan.cig.items.filter((it) => cl[it.uid] === '' || cl[it.uid] === null || cl[it.uid] === undefined);
      if (left.length) out.push({ key: 'cig', text: `Count the cigarettes (${left.length} left).` });
    }
    if (!plan.ownTill && !input.checkerUid) out.push({ key: 'checker', text: 'Choose who checked the count with you.' });
    if (!plan.ownTill && input.checkerUid && !input.checkerSig) out.push({ key: 'checkersig', text: 'The person who checked must sign.', hard: true });
  } else if (!plan.baked.total && !input.noBake) out.push({ key: 'baked', text: 'Nothing baked is saved for today. Enter what you baked.' });
  if (plan.duty && !plan.duty.done && !plan.duty.complete) out.push({ key: 'checklist', text: `Tick the checklist (${plan.duty.total - plan.duty.ticked - plan.duty.skippedN} left).` });
  if (!input.takerUid && !input.noTaker) out.push({ key: 'handover', text: 'Choose who takes over.' });
  if (plan.kind === 'till' && !txt(input.signature)) out.push({ key: 'sign', text: 'Sign at the bottom.', hard: true });
  return out;
}

// The owner / admin lets the shift end through with their PIN (kept: who, when, why, and what was not done).
export function checkOverride(override) {
  need(override && txt(override.adminUid), 'Choose the owner or admin.');
  const T2 = require('../timeclock/service.js');
  const a = T2.checkStaffPin(override.adminUid, override.pin);
  need(ownerish(a), 'Only the owner or admin can let the shift finish without everything done.');
  need(txt(override.reason).length >= 4, 'Write why the shift may finish anyway.');
  return a;
}

// ---------------------------------------------------------------- Finish
export function finishShift(user, input = {}) {
  requirePerm(user, ['till_count', 'shop_staff', 'bakery'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, input && (input.shopCode || input.shop)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  need(user, 'Log in first.');
  const plan = endPlan(user, { date: input.date, shopCode: input.shopCode, tillUid: input.tillUid, shift: input.shift });
  const blockers = blockersFor(plan, input);
  const hard = blockers.filter((b) => b.hard);
  need(!hard.length, hard.map((b) => b.text).join(' '));
  let admin = null;
  if (blockers.length) {
    need(input.override, blockers.map((b) => b.text).join(' '));
    admin = checkOverride(input.override);
  }
  const date = plan.date;
  const flags = [];
  let w = null;
  if (plan.kind === 'till' && plan.till && zFigures(plan, input.manualZ) && Object.values(input.denominations || {}).some((n) => Number(n) > 0)) {
    w = workOutEnd(plan, input);
    const probs = sanityProblems({ counted: w.counted, expected: w.expected, zCash: w.z.zCash, zTotal: w.z.zTotal, aroniumCash: w.z.source === 'manual' ? plan.aroniumCashNow : null, tenders: w.z.tenders, denominations: input.denominations });
    const stop = probs.filter((p) => p.level === 'stop');
    need(!stop.length, stop.map((p) => p.text).join(' '));
    const check = probs.filter((p) => p.level === 'check');
    need(!check.length || input.confirmOdd, check.map((p) => p.text).join(' '));
    check.forEach((p) => flags.push(`confirmed: ${p.text}`));
  }
  const own = plan.kind === 'till' && (!input.checkerUid || input.checkerUid === user.uid);
  const checker = !own && input.checkerUid ? db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [input.checkerUid]) : null;
  const res = { kind: plan.kind, date, shift: plan.shift, countUid: null, overShort: null, shortAction: null, cigAside: null, taker: null, clockedOut: null, override: !!admin };
  const seUid = plan.open ? plan.open.uid : uuid('SE');
  db().transaction(() => {
    // 1–2. the till balance (with the Aronium figures, or the manual Z and its photo)
    if (w) {
      const z = w.z;
      const tol = plan.rules.tolerance;
      const os = w.overShort;
      const shortAction = os < -tol - 0.004 ? (input.shortAction === 'paid_now' ? 'paid_now' : 'pay') : null;
      const reasons = [];
      if (z.source === 'link') reasons.push('Figures as Aronium sent them');
      if (Math.abs(os) > tol) reasons.push(os < 0 ? (shortAction === 'paid_now' ? 'Short – paid in cash now' : 'Short – taken from my pay') : 'Over – the office decides');
      if (txt(input.reason)) reasons.push(txt(input.reason));
      if (z.float !== null && Math.abs(r2(z.float) - plan.float.app) > 0.004) flags.push(`float ${$(z.float)} (${plan.float.from}), the app had ${$(plan.float.app)}`);
      const payouts = (plan.paidOuts || []).map((p) => ({ what: 'Supplier paid from till', amount: r2(p.amount), note: `${p.supplier_name}${p.invoice_no ? ` ${p.invoice_no}` : ''}` }));
      if (z.cashOut > 0) payouts.push({ what: 'Other', amount: z.cashOut, note: 'Cash taken out in Aronium' });
      const adjustments = z.cashIn > 0 ? [{ amount: z.cashIn, reason: 'Cash put in (Aronium)' }] : [];
      const floatKept = r2(Math.min(w.counted, r2(z.float)));
      const c = T.saveTillCount(user, {
        shopCode: plan.shopCode, tillUid: plan.till.uid, shiftDate: date, shift: plan.shift, cashierUid: user.uid, balancerUid: own ? user.uid : checker.uid,
        openingFloat: z.float, denominations: input.denominations, zCash: z.zCash, zTotal: z.zTotal, zNumber: z.zNumber, zVat: z.zVat, zZeroRated: z.zZero,
        tenders: z.tenders, payouts, adjustments, drops: 0, floatKept, reason: reasons.join('. '), notes: own ? 'Own till – counted by the cashier; someone else checks it.' : `Counted with ${checker.name}.`,
        // own till without the switch (only with the owner / admin's PIN): not signed as balanced – the office checks it
        cashierSig: input.signature, balancerSig: own ? (plan.ownTill ? input.signature : null) : input.checkerSig, source: z.source, eodUid: z.eodUid,
      }, { photos: z.source === 'manual' ? z.photos : [] });
      res.countUid = c.uid; res.overShort = c.over_short;
      if (z.source === 'manual') flags.push('manual Z (Aronium End of day not in)');
      if (own) flags.push(plan.ownTill ? 'own till' : 'own till – nobody checked the count');
      // the short: taken from pay (the cashier signs to agree), or paid now (the person who checked takes the money)
      if (shortAction) {
        const S = require('./shifts.js');
        const sh = S.shortageForCount(c.uid);
        if (sh && ['waiting', 'disagreed'].includes(sh.status)) {
          if (shortAction === 'paid_now') {
            need(checker, 'Paid now: the person who checked the count takes the money – choose them above.');
            require('./recount.js').payShortageNow(checker, sh.uid, { amount: sh.amount, signature: input.signature, note: 'Paid at the end of the shift' });
          } else S.agreeShortage(user, sh.uid, { signature: input.signature });
        }
        res.shortAction = shortAction;
      }
      // 1.0.0 build 2: the M-PAiSA wallet balance now (from the phone) against what it should be
      if (input.mpClose !== undefined && input.mpClose !== null && input.mpClose !== '') {
        const mpp = MP.mpPlan({ shopCode: plan.shopCode, tillUid: plan.till.uid, date, tenders: z.tenders });
        if (mpp) res.mp = MP.applyMp(user, { count: T.getTillCount(c.uid), mp: mpp, close: input.mpClose, action: input.mpAction, note: input.mpNote, tolerance: tol });
      }
      // 1.0.0 the recharge machine balances now (read off the machine) against what they should be
      if (input.rcClose && Object.keys(input.rcClose).length) {
        res.rc = require('./recharge.js').applyRc(user, { count: T.getTillCount(c.uid), shopCode: plan.shopCode, date, until: plan.eod && plan.eod.closedAt ? rcUntil(plan.eod.closedAt) : stamp(), close: input.rcClose, action: input.rcAction || {}, note: input.rcNote || {}, tolerance: tol, shiftUid: seUid });
      }
    }
    // 3. cigarettes
    if (plan.kind === 'till' && plan.cig && plan.cig.on && !plan.cig.done) {
      const cl = input.cigClosing || {};
      if (plan.cig.items.every((it) => cl[it.uid] !== '' && cl[it.uid] !== null && cl[it.uid] !== undefined)) {
        const CG = require('./cigTally.js');
        const t = CG.saveTally(user, { shopCode: plan.shopCode, date, shift: plan.shift, closing: cl, reason: input.cigReason || '' });
        res.cigAside = r2(t.aside); res.tallyUid = t.uid;
      } else flags.push('cigarettes not counted');
    }
    // 4. the checklist (with the owner / admin's PIN: what was not done is written down with the reason)
    if (plan.duty && !plan.duty.done) {
      const shopCode = plan.kind === 'bakery' ? HN.BAKERY : plan.shopCode;
      if (!plan.duty.complete) {
        plan.duty.items.filter((it) => !plan.duty.ticks[it.id] && !plan.duty.skipped[it.id])
          .forEach((it) => D.skipDuty(user, it.id, `Not done – ${admin.name} let the shift finish: ${txt(input.override.reason)}`, { date, shopCode }));
        flags.push('checklist not finished');
      }
      D.finishDuty(user, { date, shopCode });
    }
    // 5. handover: the shop's handover sheet (signed over) – the bakery keeps its notes only
    const taker = input.takerUid ? db().get('SELECT uid, name FROM users WHERE uid = ?', [input.takerUid]) : null;
    res.taker = taker ? taker.name : null;
    let hoUid = null;
    if (plan.kind === 'till') {
      const notes = plan.notes.map((n) => `${String(n.at).slice(11, 16)} ${n.text}`).join(' · ');
      const ho = require('../../services/handover.js').handOver(user, { shopCode: plan.shopCode, date, shift: plan.shift, notes: [taker ? `Taking over: ${taker.name}` : '', notes].filter(Boolean).join(' – '), signature: input.signature });
      hoUid = ho.uid;
    }
    if (!taker) flags.push('nobody chosen to take over');
    // clock out (the person is logged in with their own PIN)
    const st = clockState(user);
    if (st.state !== 'out') {
      const p = require('../timeclock/service.js').punch({ user, type: 'OUT', shopCode: plan.kind === 'bakery' ? (user.shop_code || plan.shopCode) : plan.shopCode });
      if (p && p.ok) res.clockedOut = p.time;
    }
    const now = stamp();
    const vals = {
      kind: plan.kind, user_uid: user.uid, name: user.name, shop_code: plan.shopCode, till_uid: plan.till ? plan.till.uid : null, till_name: plan.till ? plan.till.name : null,
      shift_date: date, shift: plan.shift, count_uid: res.countUid, eod_uid: w && w.z.eodUid ? w.z.eodUid : null, manual_z: w && w.z.source === 'manual' ? 1 : 0,
      tally_uid: res.tallyUid || null, duty_run_uid: plan.duty && plan.duty.run ? plan.duty.run.uid : null, handover_uid: hoUid, taker_uid: taker ? taker.uid : null, taker_name: taker ? taker.name : null,
      own_till: own ? 1 : 0, checker_uid: checker ? checker.uid : null, checker_name: checker ? checker.name : null, counted: w ? w.counted : null, expected: w ? w.expected : null,
      over_short: w ? w.overShort : null, short_action: res.shortAction, cig_aside: res.cigAside, finished_at: now,
      override_by_uid: admin ? admin.uid : null, override_by_name: admin ? admin.name : null, override_reason: admin ? txt(input.override.reason) : null,
      override_what: admin ? blockers.map((b) => b.text).join(' ') : null, flags: JSON.stringify(((plan.open && plan.open.flags) || []).concat(flags)), status: 'finished', updated_at: now, updated_device: deviceId(),
    };
    if (plan.open) {
      const cols = Object.keys(vals);
      db().run(`UPDATE shift_ends SET ${cols.map((k) => `${k} = ?`).join(', ')}, sync_status = 'pending' WHERE uid = ?`, cols.map((k) => vals[k]).concat([seUid]));
    } else {
      const cols = ['uid', 'started_at', 'float_start', 'float_from'].concat(Object.keys(vals));
      const all = { uid: seUid, started_at: null, float_start: plan.float ? plan.float.amount : null, float_from: plan.float ? plan.float.from : null, ...vals };
      db().run(`INSERT INTO shift_ends (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, cols.map((k) => all[k]));
    }
    audit({ user, action: `Shift finished: ${plan.kind === 'bakery' ? 'bakery' : `${plan.till ? plan.till.name : ''} ${plan.shift}`} ${date}${w ? ` – counted ${$(w.counted)}, ${Math.abs(w.overShort) < 0.005 ? 'balanced' : w.overShort < 0 ? `short ${$(-w.overShort)}` : `over ${$(w.overShort)}`}` : ''}${admin ? ` – let through by ${admin.name}` : ''}`,
      table: 'shift_ends', recordUid: seUid, reason: admin ? txt(input.override.reason) : undefined });
  });
  if (admin) { try { require('../verify/service.js').notify('till_short', `${user.name}'s ${plan.kind === 'bakery' ? 'bakery shift' : `${plan.shift} shift`} ${date} was finished by ${admin.name}'s PIN without: ${blockers.map((b) => b.text).join(' ')} Why: ${txt(input.override.reason)}`, { shopCode: plan.shopCode }); } catch (e) { /* only a message */ } }
  res.uid = seUid;
  res.record = getShiftEnd(seUid);
  return res;
  });
}

// Shift ends for the office (Today / Till checks): newest first.
export function listShiftEnds({ shopCode, from, to, status = 'finished', limit = 200 } = {}) {
  if (!has('shift_ends')) return [];
  const w = ['1=1']; const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); }
  return db().all(`SELECT * FROM shift_ends WHERE ${w.join(' AND ')} ORDER BY COALESCE(finished_at, started_at) DESC LIMIT ?`, a.concat([limit])).map((r) => ({ ...r, flags: J(r.flags, []) }));
}
// A till balance counted by the cashier on their own till (marked "own till"; someone else must check it).
export function isOwnTill(count) { return !!count && !!count.cashier_uid && count.cashier_uid === (count.balancer_uid || count.counted_by_uid); }
