// Aronium End of day (v3.5). Every Aronium End of day (Z) is matched to the till balance of that shift (same shop,
// same Z number; without a Z number: the whole day of that shop). A difference is flagged straight away: red mark on
// the till balance, an urgent Home warning, the To verify list and a Viber notification. Someone explains it
// (owner/admin need not write anything). Until explained, the VAT return uses Aronium's figure; the month-end
// checklist shows what is still open. An Aronium End of day with no till balance is red ("till balance missing").
// Aronium sales are no longer booked into the books: cash and banking come from the till balance; Aronium gives the
// VAT split (standard / zero-rated), products and departments.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, money } from '../../services/core.js';
import { needReason } from '../../services/access.js';
import { notify } from '../verify/service.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const EOD_STATE = { matched: 'Agrees with the till', difference: 'Difference – explain it', resolved: 'Difference explained', no_till: 'Till balance missing', void: 'Void' };
// Differences up to this much count as agreeing (admin: Till & cash › Tills & rules).
export function eodTolerance() {
  const r = getShared('till_rules', {}) || {};
  const t = Number(r.eodTolerance);
  return Number.isFinite(t) && t >= 0 ? t : 0.05;
}
// "Z-0412", "z 412", "0412" → "412"
export function normZ(z) {
  return txt(z).toUpperCase().replace(/^Z(\s*(REPORT|NO|NUMBER))?/, '').replace(/[^A-Z0-9]/g, '').replace(/^0+(?=.)/, '');
}
// The sales total of a till balance (Z total, else cash + other payments).
export function countTotal(c) {
  if (c.z_total !== null && c.z_total !== undefined && c.z_total !== '') return r2(c.z_total);
  return r2(Number(c.z_cash) + J(c.tenders, []).reduce((t, x) => t + r2(x.amount), 0));
}

export function addEod(user, e) {
  need(txt(e.shopCode), 'Choose the shop.');
  const date = txt(e.date);
  need(DATE.test(date) && date <= dateStr(), 'Enter the End of day date (not in the future).');
  const total = r2(e.total);
  need(Number.isFinite(Number(e.total)) && e.total !== '' && e.total !== null, 'Enter the total sales from the Aronium End of day.');
  const z = txt(e.zNumber) || null;
  if (z) {
    const dup = db().get("SELECT uid FROM aronium_eods WHERE shop_code = ? AND state <> 'void' AND z_number IS NOT NULL", [e.shopCode]) && db().all("SELECT uid, z_number FROM aronium_eods WHERE shop_code = ? AND state <> 'void' AND z_number IS NOT NULL", [e.shopCode]).find((x) => normZ(x.z_number) === normZ(z));
    need(!dup, `Aronium End of day ${z} for ${e.shopCode} is already recorded.`);
  } else {
    const dup = db().get("SELECT uid FROM aronium_eods WHERE shop_code = ? AND eod_date = ? AND z_number IS NULL AND state <> 'void' AND ABS(total - ?) < 0.005", [e.shopCode, date, total]);
    need(!dup, `The Aronium figures for ${e.shopCode} on ${date} are already recorded.`);
  }
  const num = (v) => (v === '' || v === null || v === undefined ? null : r2(v));
  const uid = uuid('EOD');
  const now = stamp();
  db().run(`INSERT INTO aronium_eods (uid, shop_code, eod_date, z_number, total, vat, zero, cash, card, other, source, batch_uid, note, state, created_by_name, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'no_till', ?,?,?,?)`,
  [uid, e.shopCode, date, z, total, num(e.vat), num(e.zero), num(e.cash), num(e.card), num(e.other), e.source || 'typed', e.batchUid || null, txt(e.note) || null, user ? user.name : 'System', now, now, deviceId()]);
  audit({ user, action: `Aronium End of day ${z || ''} ${e.shopCode} ${date}: ${$(total)}`.replace(/\s+/g, ' '), table: 'aronium_eods', recordUid: uid });
  rematchEods({ shopCode: e.shopCode, date });
  return getEod(uid);
}

// An End of day sent by the Aronium link on a till PC: a fixed id per till and Z, so it is never recorded twice.
// One already typed by hand for the same shop, Z number and day is kept (nothing doubles up).
export const tillNo = (t) => { const m = /(\d+)\s*$/.exec(txt(t)); return m ? m[1] : ''; };
export function putLinkedEod(e) {
  const uid = txt(e.uid);
  need(uid && txt(e.shopCode) && DATE.test(txt(e.date)), 'End of day from the link is incomplete.');
  if (db().get('SELECT uid FROM aronium_eods WHERE uid = ?', [uid])) return { uid, added: false };
  const z = txt(e.zNumber) || null;
  if (z) {
    const typed = db().all("SELECT uid, z_number, till_name FROM aronium_eods WHERE shop_code = ? AND state <> 'void' AND z_number IS NOT NULL AND eod_date BETWEEN date(?, '-1 day') AND date(?, '+1 day') AND (source IS NULL OR source <> 'link')", [e.shopCode, e.date, e.date])
      .find((x) => normZ(x.z_number) === normZ(z) && (!x.till_name || tillNo(x.till_name) === tillNo(e.tillName)));
    if (typed) return { uid: typed.uid, added: false, typed: true };
  }
  const num = (v) => (v === '' || v === null || v === undefined ? null : r2(v));
  const now = stamp();
  db().run(`INSERT INTO aronium_eods (uid, shop_code, eod_date, z_number, total, vat, zero, cash, card, other, source, batch_uid, note, state, created_by_name, created_at, updated_at, updated_device, till_name)
    VALUES (?,?,?,?,?,?,?,?,?,?, 'link', NULL, ?, 'no_till', 'Aronium link', ?,?,?,?)`,
  [uid, e.shopCode, e.date, z, r2(e.total), num(e.vat), num(e.zero), num(e.cash), num(e.card), num(e.other), txt(e.note) || null, now, now, deviceId(), txt(e.tillName) || null]);
  audit({ user: null, action: `Aronium End of day ${z || ''} ${e.shopCode} ${txt(e.tillName)} ${e.date}: ${$(e.total)} (from the till PC)`.replace(/\s+/g, ' '), table: 'aronium_eods', recordUid: uid });
  rematchEods({ shopCode: e.shopCode, date: e.date });
  return { uid, added: true };
}

export function getEod(uid) {
  const r = db().get('SELECT * FROM aronium_eods WHERE uid = ?', [uid]);
  return r ? { ...r, count_uids: J(r.count_uids, []) } : null;
}
export function listEods({ shopCode, from, to, state, states, limit = 500 } = {}) {
  if (!has('aronium_eods')) return [];
  const w = ['1=1']; const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('eod_date >= ?'); a.push(from); }
  if (to) { w.push('eod_date <= ?'); a.push(to); }
  if (state) { w.push('state = ?'); a.push(state); } else if (states) { w.push(`state IN (${states.map(() => '?').join(',')})`); a.push(...states); } else w.push("state <> 'void'");
  return db().all(`SELECT * FROM aronium_eods WHERE ${w.join(' AND ')} ORDER BY eod_date DESC, created_at DESC LIMIT ?`, a.concat([limit])).map((r) => ({ ...r, count_uids: J(r.count_uids, []) }));
}

// Matches the End of day figures of one shop and day (and the day before / after for Z numbers of night shifts)
// to the till balances, works out each difference and raises the flags.
export function rematchEods({ shopCode, date }) {
  if (!has('aronium_eods') || !shopCode || !date) return;
  const eods = db().all("SELECT * FROM aronium_eods WHERE shop_code = ? AND eod_date = ? AND state <> 'void' ORDER BY z_number IS NULL, created_at", [shopCode, date]);
  if (!eods.length) return;
  const counts = db().all("SELECT * FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void' ORDER BY counted_at", [shopCode, date]);
  // A Z number may also be on a till balance dated the day before or after (night shift past midnight).
  const near = db().all("SELECT * FROM till_counts WHERE shop_code = ? AND shift_date BETWEEN date(?, '-1 day') AND date(?, '+1 day') AND status <> 'void' AND z_number IS NOT NULL", [shopCode, date, date]);
  const taken = new Set();
  // Till balances already matched by an End of day of another date stay with it.
  db().all("SELECT count_uids FROM aronium_eods WHERE shop_code = ? AND eod_date <> ? AND state <> 'void' AND eod_date BETWEEN date(?, '-1 day') AND date(?, '+1 day')", [shopCode, date, date, date])
    .forEach((r) => J(r.count_uids, []).forEach((u) => taken.add(u)));
  const plan = {};
  for (const e of eods.filter((x) => x.z_number)) {
    // Two tills of one shop each count their own Z numbers: when both sides say which till, they must agree.
    const c = near.find((x) => !taken.has(x.uid) && normZ(x.z_number) === normZ(e.z_number) && (!e.till_name || !x.till_name || !tillNo(x.till_name) || tillNo(x.till_name) === tillNo(e.till_name)));
    if (c) { plan[e.uid] = [c]; taken.add(c.uid); }
  }
  const left = counts.filter((c) => !taken.has(c.uid));
  const zLeft = eods.filter((x) => x.z_number && !plan[x.uid]);
  const dayEods = eods.filter((x) => !x.z_number);
  // One End of day with a Z number not typed on any till balance, and one till balance left that day: they belong together.
  if (zLeft.length === 1 && !dayEods.length && left.length === 1 && !normZ(left[0].z_number)) { plan[zLeft[0].uid] = [left[0]]; taken.add(left[0].uid); }
  // Whole-day figures (no Z number): every till balance of the day not matched yet.
  if (dayEods.length) {
    const rest = counts.filter((c) => !taken.has(c.uid));
    dayEods.forEach((e, i) => { plan[e.uid] = i === 0 ? rest : []; });
  }
  const tol = eodTolerance();
  const now = stamp(); const dev = deviceId();
  for (const e of eods) {
    const list = plan[e.uid] || [];
    const tillTotal = list.length ? r2(list.reduce((s, c) => s + countTotal(c), 0)) : null;
    const diff = list.length ? r2(Number(e.total) - tillTotal) : null;
    let state = 'no_till';
    if (list.length) {
      if (Math.abs(diff) <= tol + 0.0001) state = 'matched';
      else if (e.explanation !== null && e.resolved_at && e.resolved_diff !== null && Math.abs(Number(e.resolved_diff) - diff) < 0.01) state = 'resolved';
      else state = 'difference';
    }
    const uids = JSON.stringify(list.map((c) => c.uid));
    if (state !== e.state || uids !== (e.count_uids || '[]') || tillTotal !== e.till_total || diff !== e.diff) {
      db().run(`UPDATE aronium_eods SET count_uids = ?, till_total = ?, diff = ?, state = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [uids, tillTotal, diff, state, now, dev, e.uid]);
    }
    // Flag it straight away (once per kind of problem).
    // v3.9.7 not for End of days from before the go-live date (history only – no message).
    let oldDay = false;
    try { oldDay = require('../../services/goLive.js').isOld(e.eod_date); } catch (x) { oldDay = false; }
    if ((state === 'difference' || state === 'no_till') && e.notified_state !== state && !oldDay) {
      const text = state === 'difference'
        ? `Aronium End of day ${e.z_number || ''} ${e.eod_date} says ${$(e.total)} but the till balance says ${$(tillTotal)} (difference ${$(diff)}). Please explain it.`
        : `Aronium End of day ${e.z_number || ''} ${e.eod_date} (${$(e.total)}) has no till balance. Till balance missing.`;
      try { notify('eod_diff', text.replace(/\s+/g, ' '), { shopCode }); } catch (x) { /* never stops the match */ }
      db().run("UPDATE aronium_eods SET notified_state = ?, sync_status = 'pending' WHERE uid = ?", [state, e.uid]);
    }
  }
}
// After a till balance is saved, changed or voided: match again around its date.
export function rematchAround(shopCode, date) {
  if (!has('aronium_eods') || !shopCode || !DATE.test(String(date || ''))) return;
  const days = db().all("SELECT DISTINCT eod_date AS d FROM aronium_eods WHERE shop_code = ? AND state <> 'void' AND eod_date BETWEEN date(?, '-1 day') AND date(?, '+1 day')", [shopCode, date, date]);
  days.forEach((r) => rematchEods({ shopCode, date: r.d }));
}

// Explain a difference. Choose which figure is right for VAT: Aronium's (default) or the till balance's.
export function resolveEod(user, uid, { explanation, use = 'aronium' } = {}) {
  const e = getEod(uid);
  need(e && e.state !== 'void', 'Not found.');
  need(e.state === 'difference' || e.state === 'resolved', e.state === 'no_till' ? 'There is no till balance for this End of day yet – count the till first.' : 'There is no difference to explain.');
  needReason(user, explanation, 'Explain the difference.');
  const now = stamp();
  db().run(`UPDATE aronium_eods SET explanation = ?, use_figure = ?, resolved_diff = ?, resolved_by_name = ?, resolved_at = ?, state = 'resolved', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [txt(explanation), use === 'till' ? 'till' : 'aronium', e.diff, user.name, now, now, deviceId(), uid]);
  audit({ user, action: `Explained Aronium End of day ${e.z_number || ''} ${e.shop_code} ${e.eod_date} difference ${$(e.diff)} (VAT uses ${use === 'till' ? 'the till balance' : "Aronium's figure"})`, table: 'aronium_eods', recordUid: uid, reason: txt(explanation) || null });
  return getEod(uid);
}
export function voidEod(user, uid, reason) {
  const e = getEod(uid);
  need(e && e.state !== 'void', 'Not found.');
  needReason(user, reason, 'Why is it void?');
  db().run(`UPDATE aronium_eods SET state = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || 'Void', stamp(), deviceId(), uid]);
  audit({ user, action: `Voided Aronium End of day ${e.z_number || ''} ${e.shop_code} ${e.eod_date}`, table: 'aronium_eods', recordUid: uid, reason: txt(reason) || null });
}
// The End of day matched to a till balance (for the red mark on the till balance).
export function eodForCount(countUid) {
  if (!has('aronium_eods') || !countUid) return null;
  const r = db().all("SELECT * FROM aronium_eods WHERE state <> 'void' AND count_uids LIKE ?", [`%${countUid}%`]).find((x) => J(x.count_uids, []).includes(countUid));
  return r ? { ...r, count_uids: J(r.count_uids, []) } : null;
}
// What is still open (Home, To verify, month end).
export function eodProblems({ from, to, shopCode, history = false } = {}) {
  // v3.9.7 End of days from before the go-live date are history only – never a problem to sort out.
  let f = from;
  if (!history) { try { const g = require('../../services/goLive.js').freshFrom(); if (g && (!f || g > f)) f = g; } catch (e) { /* none */ } }
  const list = listEods({ from: f, to, shopCode, states: ['difference', 'no_till'], limit: 5000 });
  return { differences: list.filter((e) => e.state === 'difference'), noTill: list.filter((e) => e.state === 'no_till') };
}
// For the VAT return: the figure to use for each End of day of the period (the till balances it covers are then left out).
export function eodVatRows({ from, to, shopCode } = {}) {
  return listEods({ from, to, shopCode, limit: 20000 }).filter((e) => !(e.state === 'resolved' && e.use_figure === 'till')).map((e) => ({ ...e, vatUse: 'aronium' }));
}
