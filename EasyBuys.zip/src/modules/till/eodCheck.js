// Release 28 (owner, 14 Nov: "can you run through both shops' end of day records and find any discrepancy"): one check
// over every End of day (Z) of both shops, run on the device (the figures never leave it). It lists, per shop:
//   • End of day numbers that never came in (a gap in a till's Z numbers)
//   • the same Z number twice
//   • till balances that do not match the End of day (and not explained yet)
//   • End of days not balanced yet (no till balance) – older than today
//   • days where the till PC's sales for the day and the End of days of that day do not add up
//   • days with sales but no End of day at all
//   • an End of day whose VAT does not fit its standard-rated sales (12.5% VAT)
import { db } from '../../db/connection.js';
import { dateStr, addDays } from '../../services/core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const $ = (n) => `$${r2(Math.abs(n)).toFixed(2)}`;
const VAT = 0.125;

export function eodCheck({ from = '', to = dateStr(), shopCode = '' } = {}) {
  const today = dateStr();
  if (!from) { from = addDays(today, -30); const g = safe(() => require('../../services/goLive.js').freshFrom(), ''); if (g && g > from) from = g; }
  const E = require('./eod.js');
  const eods = safe(() => E.listEods({ from, to, shopCode, limit: 5000 }), []).filter((e) => e.state !== 'void');
  const shops = safe(() => db().all('SELECT code, name FROM shops WHERE IFNULL(active,1) = 1 ORDER BY code'), [])
    .filter((s) => !shopCode || s.code === shopCode);
  const out = [];
  const add = (shop, kind, level, date, text, nav = null, amount = null) => out.push({ shop, kind, level, date, text, nav, amount });

  // 1. Z numbers that never came in
  const gaps = safe(() => require('../aronium/missingEod.js').missingEods(shopCode), []);
  for (const g of gaps) add(g.shop, 'gap', 'high', '', `${require('../aronium/missingEod.js').tillName(g.source)}: End of day${g.missing.length === 1 ? '' : 's'} ${g.missing.join(', ')} never came in from the till PC.`, { screen: 'AroniumLink', params: {} });

  // 2. the same Z number twice (same shop and till)
  const seen = new Map();
  for (const e of eods) {
    if (!e.z_number) continue;
    const till = (/^EOD-(S\d+-T\d+)-/.exec(e.uid || '') || [])[1] || e.till_name || '';
    const k = `${e.shop_code}|${till}|${e.z_number}`;
    if (seen.has(k)) add(e.shop_code, 'dup', 'high', e.eod_date, `Z ${e.z_number} is there twice (${seen.get(k).eod_date} and ${e.eod_date}) – one may need to be removed.`, { screen: 'AroniumEod', params: { uid: e.uid } });
    else seen.set(k, e);
  }

  // 3. till balance ≠ End of day, not explained;  4. not balanced yet
  for (const e of eods) {
    const z = e.z_number ? `Z ${e.z_number}` : 'End of day';
    if (e.state === 'difference') {
      const d = r2(e.diff);
      add(e.shop_code, 'diff', Math.abs(d) >= 5 ? 'high' : 'medium', e.eod_date, `${z}: the till balance is ${$(d)} ${d < 0 ? 'SHORT' : 'OVER'} against Aronium (till PC ${$(e.total)}, counted ${$(e.till_total)}). Not explained yet.`, { screen: 'AroniumEod', params: { uid: e.uid } }, d);
    } else if (e.state === 'no_till' && e.eod_date < today && Number(e.total) > 0.004) {
      add(e.shop_code, 'unbalanced', 'medium', e.eod_date, `${z} (${$(e.total)}) has no till balance – the till was not counted for it.`, { screen: 'AroniumEod', params: { uid: e.uid } }, Number(e.total));
    } else if (e.state === 'resolved' && Math.abs(Number(e.resolved_diff) || 0) >= 0.01) {
      add(e.shop_code, 'explained', 'low', e.eod_date, `${z}: ${$(e.resolved_diff)} ${Number(e.resolved_diff) < 0 ? 'short' : 'over'} – explained by ${e.resolved_by_name || '?'}: "${String(e.explanation || '').slice(0, 120)}"`, { screen: 'AroniumEod', params: { uid: e.uid } }, Number(e.resolved_diff));
    }
    // 7. VAT that does not fit the standard-rated sales
    if (e.vat !== null && e.vat !== undefined && e.zero !== null && e.zero !== undefined && Number(e.total) > 0) {
      const std = r2(Number(e.total) - Number(e.zero));
      const expect = r2((std * VAT) / (1 + VAT));
      if (Math.abs(expect - Number(e.vat)) > Math.max(1, std * 0.01)) add(e.shop_code, 'vat', 'medium', e.eod_date, `${z}: VAT ${$(e.vat)} does not fit the standard-rated sales ${$(std)} (12.5% would be ${$(expect)}). A product may have the wrong VAT in Aronium.`, { screen: 'AroniumEod', params: { uid: e.uid } });
    }
  }

  // 5 / 6. each day: the till PC's sales vs the End of days of that day
  const sales = safe(() => require('../aronium/link.js').linkSalesMap({ from, to, shop: shopCode }), new Map());
  const zByDay = new Map();
  for (const e of eods) {
    const k = `${e.eod_date}|${e.shop_code}`;
    zByDay.set(k, r2((zByDay.get(k) || 0) + Number(e.total || 0)));
  }
  for (const [k, s] of sales) {
    if (s.date >= today) continue;
    const z = zByDay.get(k);
    if (z === undefined) {
      if (s.value > 0.004) add(s.shop, 'noz', 'high', s.date, `Sales of ${$(s.value)} on the till PC, but no End of day for the day.`, { screen: 'AroniumEods', params: {} }, s.value);
      continue;
    }
    const d = r2(z - s.value);
    if (Math.abs(d) >= 1) add(s.shop, 'daysum', Math.abs(d) >= 20 ? 'medium' : 'low', s.date, `End of days ${$(z)} vs the day's sales ${$(s.value)} – ${$(d)} ${d > 0 ? 'more' : 'less'} in the End of days. Often a shift past midnight (it shows on the next day); check the day before / after.`, { screen: 'AroniumEods', params: {} }, d);
  }

  const order = { high: 0, medium: 1, low: 2 };
  out.sort((a, b) => (a.shop < b.shop ? -1 : a.shop > b.shop ? 1 : order[a.level] - order[b.level] || String(b.date).localeCompare(String(a.date))));
  const per = shops.map((s) => {
    const list = out.filter((x) => x.shop === s.code);
    return { code: s.code, name: s.name, findings: list, eods: eods.filter((e) => e.shop_code === s.code).length,
      short: r2(list.filter((x) => x.kind === 'diff' && x.amount < 0).reduce((t, x) => t + x.amount, 0)),
      over: r2(list.filter((x) => x.kind === 'diff' && x.amount > 0).reduce((t, x) => t + x.amount, 0)) };
  });
  return { from, to, shops: per, total: out.length, high: out.filter((x) => x.level === 'high').length };
}
