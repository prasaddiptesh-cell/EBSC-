// Till & cash module: shift till counts with the Z report photo, cash on hand at each shop, deposits, petty cash.
import { TillHomeScreen, TillCountScreen, TillCountViewScreen, DepositScreen, DepositListScreen, CashOnHandScreen, TillSetupScreen } from './screens/TillScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

const any = (u) => ['till_count', 'till_approve', 'deposits'].some((p) => can(u, p));
export default {
  id: 'till',
  title: 'Till & cash',
  icon: '💵',
  switchable: true,
  screens: {
    Till: { component: TillHomeScreen, can: any },
    TillCount: { component: TillCountScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    TillCountView: { component: TillCountViewScreen, can: any },
    Deposit: { component: DepositScreen, can: (u) => can(u, 'deposits') },
    Deposits: { component: DepositListScreen, can: (u) => can(u, 'deposits') },
    CashOnHand: { component: CashOnHandScreen, can: (u) => can(u, 'deposits') || can(u, 'till_approve') },
    TillSetup: { component: TillSetupScreen, can: (u) => can(u, 'till_approve') },
  },
  reports: REPORTS,
};
