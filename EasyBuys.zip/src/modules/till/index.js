// Till & cash module: shift till counts with the Z report photo, cash on hand at each shop, deposits, petty cash.
import { TillHomeScreen, TillCountScreen, TillCountViewScreen, DepositScreen, DepositListScreen, CashOnHandScreen, TillSetupScreen } from './screens/TillScreens.js';
import { TillShiftsScreen, AroniumEodsScreen, AroniumEodScreen, TillShortagesScreen } from './screens/Till35Screens.js';
import { HandoverScreen, HandoversScreen } from './screens/HandoverScreens.js';
import { REPORTS } from './reports.js';
import { SALES_REPORTS } from './salesHistory.js';
import { SalesHistoryScreen, SalesDayScreen } from './screens/SalesHistoryScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

const any = (u) => ['till_count', 'till_approve', 'deposits'].some((p) => can(u, p));
export default {
  id: 'till',
  title: 'Till & cash',
  icon: '💵',
  switchable: true,
  screens: {
    SalesHistory: { component: SalesHistoryScreen, can: (u) => can(u, 'till_approve') || can(u, 'reports') || can(u, 'dashboard') },
    SalesDay: { component: SalesDayScreen, can: (u) => can(u, 'till_approve') || can(u, 'reports') || can(u, 'dashboard') },
    Till: { component: TillHomeScreen, can: any },
    TillCount: { component: TillCountScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    TillCountView: { component: TillCountViewScreen, can: any },
    Deposit: { component: DepositScreen, can: (u) => can(u, 'deposits') },
    Deposits: { component: DepositListScreen, can: (u) => can(u, 'deposits') },
    CashOnHand: { component: CashOnHandScreen, can: (u) => can(u, 'deposits') || can(u, 'till_approve') },
    TillSetup: { component: TillSetupScreen, can: (u) => can(u, 'till_approve') },
    TillShifts: { component: TillShiftsScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    AroniumEods: { component: AroniumEodsScreen, can: (u) => can(u, 'till_approve') || can(u, 'accounts_view') },
    AroniumEod: { component: AroniumEodScreen, can: (u) => can(u, 'till_approve') || can(u, 'accounts_view') },
    TillShortages: { component: TillShortagesScreen, can: (u) => !!u },
    Handover: { component: HandoverScreen, can: any },
    Handovers: { component: HandoversScreen, can: any },
  },
  menu: MENU,
  alerts,
  reports: REPORTS.concat(SALES_REPORTS),
};
