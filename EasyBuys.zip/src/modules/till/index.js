// Till & cash module: shift till counts with the Z report photo, cash on hand at each shop, deposits, petty cash.
import { TillHomeScreen, TillCountScreen, TillCountViewScreen, DepositScreen, DepositListScreen, CashOnHandScreen, TillSetupScreen } from './screens/TillScreens.js';
import { TillShiftsScreen, AroniumEodsScreen, AroniumEodScreen, TillShortagesScreen } from './screens/Till35Screens.js';
import { HandoverScreen, HandoversScreen } from './screens/HandoverScreens.js';
import { REPORTS } from './reports.js';
import { SALES_REPORTS } from './salesHistory.js';
import { withSalesSummary } from '../aronium/periodReports.js'; // 1.0.0 Sales history + VAT, zero-rated, average sale
import { SalesHistoryScreen, SalesDayScreen } from './screens/SalesHistoryScreens.js';
import { CigTallyScreen, CigFundScreen } from './screens/CigScreens.js';
import { StartMyShiftScreen, BakeryStartMyShiftScreen, HandoverNotesScreen, EndMyShiftScreen, BakeryEndMyShiftScreen, ShiftFinishedScreen, TillCheckScreen, CigStatusScreen } from './screens/ShiftScreens.js';
import { BalanceTillScreen, BalanceDoneScreen } from './screens/BalanceScreens.js';
import { RechargeScreen, RechargeWalletScreen, RechargeTopUpScreen, RechargeSetupScreen } from './screens/RechargeScreens.js';
import { RECHARGE_REPORTS, mayTopUp } from './recharge.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

const any = (u) => ['till_count', 'till_approve', 'deposits'].some((p) => can(u, p));
export default {
  id: 'till',
  title: 'Till & cash',
  icon: '💵',
  switchable: true,
  screens: {
    SalesHistory: { component: SalesHistoryScreen, can: (u) => can(u, 'till_approve') || can(u, 'reports') || can(u, 'dashboard') },
    SalesDay: { component: SalesDayScreen, can: (u) => can(u, 'till_approve') || can(u, 'reports') || can(u, 'dashboard') },
    Till: { component: TillHomeScreen, can: any },
    CigTally: { component: CigTallyScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    CigFund: { component: CigFundScreen, can: any },
    TillCount: { component: TillCountScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    TillCountView: { component: TillCountViewScreen, can: any },
    Deposit: { component: DepositScreen, can: (u) => can(u, 'deposits') },
    Deposits: { component: DepositListScreen, can: (u) => can(u, 'deposits') },
    CashOnHand: { component: CashOnHandScreen, can: (u) => can(u, 'deposits') || can(u, 'till_approve') },
    TillSetup: { component: TillSetupScreen, can: (u) => can(u, 'till_approve') },
    TillShifts: { component: TillShiftsScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    AroniumEods: { component: AroniumEodsScreen, can: (u) => can(u, 'till_approve') || can(u, 'accounts_view') },
    AroniumEod: { component: AroniumEodScreen, can: (u) => can(u, 'till_approve') || can(u, 'accounts_view') },
    TillShortages: { component: TillShortagesScreen, can: (u) => !!u },
    Handover: { component: HandoverScreen, can: any },
    Handovers: { component: HandoversScreen, can: any },
    // 1.0.0 build 1: the staff's own shift (Start shift, Handover notes, End shift – one page each) and two office checks.
    StartMyShift: { component: StartMyShiftScreen, can: (u) => !!u },
    BakeryStartMyShift: { component: BakeryStartMyShiftScreen, can: (u) => !!u },
    HandoverNotes: { component: HandoverNotesScreen, can: (u) => !!u },
    EndMyShift: { component: EndMyShiftScreen, can: (u) => !!u },
    BakeryEndMyShift: { component: BakeryEndMyShiftScreen, can: (u) => !!u },
    ShiftFinished: { component: ShiftFinishedScreen, can: (u) => !!u },
    TillCheck: { component: TillCheckScreen, can: (u) => can(u, 'till_approve') },
    // 1.0.0 build 2: Balance the till – the simple page for one Aronium End of day (and the done page).
    BalanceTill: { component: BalanceTillScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    BalanceDone: { component: BalanceDoneScreen, can: (u) => can(u, 'till_count') || can(u, 'till_approve') },
    // 1.0.0 the recharge machines: the balances (Records › Money), one balance's history, top up, and the set-up.
    Recharge: { component: RechargeScreen, can: (u) => !!u && (mayTopUp(u) || can(u, 'till_approve') || can(u, 'reports')) },
    RechargeWallet: { component: RechargeWalletScreen, can: (u) => !!u && (mayTopUp(u) || can(u, 'till_approve') || can(u, 'reports')) },
    RechargeTopUp: { component: RechargeTopUpScreen, can: (u) => mayTopUp(u) },
    RechargeSetup: { component: RechargeSetupScreen, can: (u) => !!u && ['owner', 'admin'].includes(u.role) },
    CigStatus: { component: CigStatusScreen, can: (u) => can(u, 'till_approve') || can(u, 'payments_make') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS.concat(SALES_REPORTS.map(withSalesSummary), RECHARGE_REPORTS),
};
