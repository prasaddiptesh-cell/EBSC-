// Till & cash menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '💵', title: 'Today at the tills', note: 'Counts to approve and cash at each shop.', screen: 'Till' },
    { id: 'till-shifts', icon: '🔁', title: 'Till shifts', note: 'Start a shift; the next one starts when the last is balanced.', screen: 'TillShifts' },
    { id: 'till-count', icon: '🧮', title: 'Count a till', note: 'End of shift, with the Z report photo and two signatures.', screen: 'TillCount' },
    { id: 'till-cig', icon: '🚬', title: 'Cigarette tally', note: 'End of shift: count the cabinet, compare with Aronium, put the cigarette money aside.', screen: 'CigTally' },
    { id: 'till-cig-fund', icon: '🗃️', title: 'Cigarettes – this lot & money', note: 'One place: this week\'s cigarette invoice, packets in and sold each day (Aronium), money put aside, and whether it is paid.', screen: 'CigFund' },
    { id: 'till-shiftstock', icon: '📦', title: 'Fast-moving items (shift count)', note: 'Counted at the start and end of each shift; top-ups; short / over at selling price and cost.', screen: 'ShiftStockList' },
    { id: 'till-shortages', icon: '✍️', title: 'Till shortages & over', note: 'Paid now in cash, or agreed and taken from pay; a till over is decided.', screen: 'TillShortages' },
    { id: 'till-deposit', icon: '🏦', title: 'Bank deposit', note: 'Tick the cheques the deposit covers.', screen: 'Deposit' },
    { id: 'till-cash', icon: '👛', title: 'Petty cash, move cash, count the safe', screen: 'CashOnHand' },
    { id: 'till-handover', icon: '🤝', title: 'Handover & takeover', note: 'The day on one page – sign it over at the end of your shift; the next person signs to take over.', screen: 'Handover' },
  ] },
  { section: 'Records', items: [
    { id: 'till-sales', icon: '📈', title: 'Sales history', note: 'Day by day for each shop and till; tap a day for products, hours and cashiers.', screen: 'SalesHistory' },
    { id: 'till-deposits', icon: '📒', title: 'Deposits', screen: 'Deposits' },
    { id: 'till-handovers', icon: '🗓️', title: 'Handovers by day', note: 'Every handover – what happened on any day or shift.', screen: 'Handovers' },
  ] },
  { section: 'Checks', items: [
    { id: 'till-eod', icon: '🧾', title: 'Aronium End of day', note: "Matched to each shift's Z; differences and missing till balances.", screen: 'AroniumEods' },
  ] },
  { section: 'Reports', items: [
    { id: 'till-reports', icon: '📊', title: 'Till & cash reports', screen: 'ReportsHub', params: { group: 'Till & cash' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'till-shiftstock-items', icon: '📦', title: 'Items counted at each shift', note: 'The admin chooses the fast-moving items for each shop.', screen: 'ShiftStockItems' },
    { id: 'till-setup', icon: '⚙️', title: 'Tills & rules', note: 'Tills, floats, payment types, shortages.', screen: 'TillSetup' },
  ] },
];
