// Till & cash menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '💵', title: 'Today at the tills', note: 'Counts to approve and cash at each shop.', screen: 'Till' },
    { id: 'till-shifts', icon: '🔁', title: 'Till shifts', note: 'Start a shift; the next one starts when the last is balanced.', screen: 'TillShifts' },
    { id: 'till-count', icon: '🧮', title: 'Count a till', note: 'End of shift, with the Z report photo and two signatures.', screen: 'TillCount' },
    { id: 'till-shortages', icon: '✍️', title: 'Till shortages', note: 'The cashier agrees and signs, or a manager decides.', screen: 'TillShortages' },
    { id: 'till-deposit', icon: '🏦', title: 'Bank deposit', screen: 'Deposit' },
    { id: 'till-cash', icon: '👛', title: 'Petty cash, move cash, count the safe', screen: 'CashOnHand' },
  ] },
  { section: 'Records', items: [
    { id: 'till-deposits', icon: '📒', title: 'Deposits', screen: 'Deposits' },
  ] },
  { section: 'Checks', items: [
    { id: 'till-eod', icon: '🧾', title: 'Aronium End of day', note: "Matched to each shift's Z; differences and missing till balances.", screen: 'AroniumEods' },
  ] },
  { section: 'Reports', items: [
    { id: 'till-reports', icon: '📊', title: 'Till & cash reports', screen: 'ReportsHub', params: { group: 'Till & cash' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'till-setup', icon: '⚙️', title: 'Tills & rules', note: 'Tills, floats, payment types, shortages.', screen: 'TillSetup' },
  ] },
];
