// 1.0.0 build 2 (owner, 1 Nov): the M-PAiSA wallet balance per shift.
//   Start shift asks ONE thing: "M-PAiSA wallet balance now" (the shop's wallet, read off the M-PAiSA phone) – filled in
//   with the last shift's closing balance, so it is usually just a confirm.
//   End shift / Balance the till: M-PAiSA should be = opening + this shift's M-PAiSA sales (Aronium's End of day)
//   − M-PAiSA paid out / sent to the bank (+ corrections in) recorded in the wallet since the opening; the closing
//   balance is typed from the phone and the difference is shown like the cash (Balanced / SHORT / OVER).
// The books: the wallet already gets Aronium's M-PAiSA sales from the till balance (wallets.js walletSales), so only the
// DIFFERENCE is booked, once, as a wallet correction (adjust_out when short, adjust_in when over). A short is then
// taken from the cashier's pay (staff charge), paid now in cash (cash on hand), or left for the office ("explain").
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, addDays, money } from '../../services/core.js';
import { asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const need = (c, m) => { if (!c) throw new AppError(m); };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const num = (v) => (v === '' || v === null || v === undefined || !Number.isFinite(Number(v)) ? null : r2(v));
const isMp = (m) => /paisa/i.test(String(m || ''));

export const MP_COUNT_COLUMNS = [['mp_wallet_uid', 'TEXT'], ['mp_open', 'REAL'], ['mp_close', 'REAL'], ['mp_expected', 'REAL'], ['mp_diff', 'REAL'], ['mp_action', 'TEXT'], ['mp_note', 'TEXT'], ['z_source', 'TEXT'], ['z_typed', 'TEXT']];
export const MP_SHIFT_COLUMNS = [['mp_open', 'REAL'], ['mp_close', 'REAL']];

// The shop's M-PAiSA wallet (one per shop).
export function mpWallet(shopCode) {
  return safe(() => db().get("SELECT * FROM wallets WHERE shop_code = ? AND active = 1 AND provider = 'M-PAiSA' ORDER BY rowid LIMIT 1", [shopCode]), null);
}
// The last closing balance typed for this wallet (End shift / Balance the till), else the wallet's book balance.
export function lastClose(shopCode) {
  const w = mpWallet(shopCode);
  if (!w) return null;
  const c = safe(() => db().get("SELECT mp_close, counted_at FROM till_counts WHERE mp_wallet_uid = ? AND mp_close IS NOT NULL AND status <> 'void' ORDER BY shift_date DESC, counted_at DESC LIMIT 1", [w.uid]), null);
  if (c) return { amount: r2(c.mp_close), from: 'last shift', at: c.counted_at };
  const p = safe(() => require('../bank/wallets.js').walletPosition(w.uid), null);
  return p ? { amount: r2(p.balance), from: 'wallet', at: null } : null;
}
// The opening of a shift on a till: what was confirmed at Start shift, else the last close.
export function openingFor(shopCode, tillUid, date) {
  const s = tillUid ? safe(() => db().get("SELECT mp_open, started_at FROM shift_ends WHERE till_uid = ? AND mp_open IS NOT NULL AND shift_date BETWEEN ? AND ? AND status = 'started' ORDER BY started_at DESC LIMIT 1", [tillUid, addDays(date, -1), date]), null) : null;
  const last = lastClose(shopCode);
  // a shift started (and its balance confirmed) after the last close wins; an older one was already closed by someone
  if (s && (!last || !last.at || txt(s.started_at) > txt(last.at))) return { amount: r2(s.mp_open), from: 'start of shift', at: s.started_at };
  return last;
}
// What should be in the wallet now: { wallet, open, from, sales, outs, ins, expected } (null without a wallet).
export function mpPlan({ shopCode, tillUid, date, tenders = [], open } = {}) {
  const w = mpWallet(shopCode);
  if (!w) return null;
  const o = open !== undefined && open !== null && open !== '' ? { amount: r2(open), from: 'typed', at: null } : openingFor(shopCode, tillUid, date);
  const sales = r2((tenders || []).filter((t) => isMp(t.method)).reduce((s, t) => s + r2(t.amount), 0));
  const since = (o && o.at) || `${date}T00:00:00`;
  const moves = safe(() => db().all("SELECT type, amount FROM wallet_moves WHERE wallet_uid = ? AND status = 'active' AND updated_at > ? AND move_date <= ? AND IFNULL(note,'') NOT LIKE 'M-PAiSA %at the end of%'", [w.uid, since, date]), []);
  const outs = r2(moves.filter((m) => ['transfer_bank', 'fee', 'adjust_out', 'payment'].includes(m.type)).reduce((s, m) => s + r2(m.amount), 0));
  const ins = r2(moves.filter((m) => m.type === 'adjust_in').reduce((s, m) => s + r2(m.amount), 0));
  const openAmt = o ? r2(o.amount) : 0;
  return { wallet: w, open: openAmt, from: o ? o.from : 'none', sales, outs, ins, expected: r2(openAmt + sales - outs + ins) };
}
export function mpResult(mp, close, tolerance = 0) {
  if (!mp || num(close) === null) return { state: 'none', diff: null, amount: 0 };
  const diff = r2(num(close) - mp.expected);
  const state = Math.abs(diff) <= Number(tolerance) + 0.004 ? 'balanced' : diff < 0 ? 'short' : 'over';
  return { state, diff, amount: r2(Math.abs(diff)) };
}

// After the till balance is saved: keep the opening / closing on it, book the difference once and settle a short.
// action (short only): 'pay' (from the cashier's pay), 'paid_now' (cash now), 'explain' (the office decides – needs a note).
export function applyMp(user, { count, mp, close, action, note, tolerance = 0 }) {
  if (!mp || num(close) === null || !count) return null;
  return asService(() => {
    const res = mpResult(mp, close, tolerance);
    need(num(close) >= 0, 'The M-PAiSA balance cannot be below zero.');
    const act = res.state === 'short' ? (['pay', 'paid_now', 'explain'].includes(action) ? action : 'pay') : null;
    if (act === 'explain') need(txt(note).length >= 3, 'Write why the M-PAiSA wallet is short.');
    const W = require('../bank/wallets.js');
    const what = `${count.till_name || 'Till'} ${count.shift || ''} ${count.shift_date}`.replace(/\s+/g, ' ');
    if (res.state === 'short' || res.state === 'over') {
      W.recordWalletMove(user, { walletUid: mp.wallet.uid, type: res.state === 'short' ? 'adjust_out' : 'adjust_in', date: count.shift_date, amount: res.amount,
        note: `M-PAiSA ${res.state} at the end of ${what} (${count.cashier_name})${txt(note) ? ` – ${txt(note)}` : ''}` });
    }
    if (act === 'pay') {
      require('../payroll/service.js').chargeStaff(user, { userUid: count.cashier_uid, amount: res.amount, reason: `M-PAiSA short ${count.shop_code} ${what}`, source: 'mpaisa_short', refUid: count.uid, shopCode: count.shop_code, date: count.shift_date });
    } else if (act === 'paid_now') {
      require('./service.js').addCashMove({ shopCode: count.shop_code, date: count.shift_date, type: 'adjust_in', amount: res.amount, refUid: count.uid, category: 'M-PAiSA short repaid', note: `${count.cashier_name} paid the M-PAiSA short of ${what}`, user });
    }
    db().run(`UPDATE till_counts SET mp_wallet_uid = ?, mp_open = ?, mp_close = ?, mp_expected = ?, mp_diff = ?, mp_action = ?, mp_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [mp.wallet.uid, mp.open, num(close), mp.expected, res.diff, act || (res.state === 'over' ? 'over' : null), txt(note) || null, stamp(), deviceId(), count.uid]);
    db().run("UPDATE shift_ends SET mp_close = ?, sync_status = 'pending' WHERE count_uid = ? OR (till_uid = ? AND shift_date = ? AND status = 'started')", [num(close), count.uid, count.till_uid, count.shift_date]);
    audit({ user, action: `M-PAiSA ${what}: opening ${$(mp.open)} + sales ${$(mp.sales)} − out ${$(mp.outs)} = ${$(mp.expected)}; phone says ${$(close)} – ${res.state === 'balanced' ? 'balanced' : `${res.state} ${$(res.amount)}${act ? ` (${act})` : ''}`}`, table: 'till_counts', recordUid: count.uid, reason: txt(note) || undefined });
    if (res.state === 'short') { try { require('../verify/service.js').notify('till_short', `M-PAiSA SHORT ${$(res.amount)} at the end of ${what} (${count.cashier_name})${act === 'explain' ? ` – ${txt(note)}` : act === 'paid_now' ? ' – paid now' : ' – from pay'}`, { shopCode: count.shop_code }); } catch (e) { /* only a message */ } }
    return { ...res, action: act };
  });
}
// The shifts' typed M-PAiSA balances of a wallet (for the M-PAiSA reconciliation): [{ date, shift, till, open, close, expected, diff }]
export function shiftBalances(walletUid, from, to) {
  return safe(() => db().all(`SELECT uid, shift_date, shift, till_name, cashier_name, mp_open, mp_close, mp_expected, mp_diff, mp_action FROM till_counts
    WHERE mp_wallet_uid = ? AND mp_close IS NOT NULL AND status <> 'void' AND shift_date BETWEEN ? AND ? ORDER BY shift_date, counted_at`, [walletUid, from || '0000-01-01', to || '9999-12-31']), [])
    .map((c) => ({ countUid: c.uid, date: c.shift_date, shift: c.shift, till: c.till_name, cashier: c.cashier_name, open: c.mp_open, close: c.mp_close, expected: c.mp_expected, diff: c.mp_diff, action: c.mp_action }));
}
