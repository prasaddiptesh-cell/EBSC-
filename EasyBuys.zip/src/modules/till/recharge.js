// 1.0.0 (owner, 2 Nov): the electronic mobile-recharge machines. Each shop has one machine with TWO balances that are
// topped up apart: Vodafone and Inkk – so a "wallet" per shop per network (Shop 1 Vodafone, Shop 1 Inkk, …), made by
// the app for every shop with a till. The admin can rename one or switch it off.
//   Selling: recharge is rung up in Aronium. Each sale takes its FULL face value off that balance ($10 sold = $10 off);
//     a refund puts it back. Which Aronium products (or product group) are Vodafone / Inkk is set once per shop
//     (locked setting recharge_setup). The sales come from what the Aronium Link already sends: the day's sales per
//     product (sales_day) and the live receipts with their lines. recharge_sales keeps ONE figure per till PC, day and
//     network: the day's figure once it is in, the receipts until then – so nothing is ever counted twice.
//   Top-ups: "Top up the recharge machine" – what was paid to the supplier and the value put on the machine. It is a
//     supplier invoice + a payment (the payables services, so the supplier's statement shows it) plus a top-up row.
//     The difference (value put on − paid) is the commission.
//   Each shift: should be = the last balance read off the machine + top-ups since − Aronium recharge sales since
//     (+ refunds). The balance now is typed; Balanced / SHORT / OVER as the cash and M-PAiSA. Only the difference is
//     booked (once, on the reading).
// The books (accounting/service.js): each wallet is its own current asset (1031 Shop 1 Vodafone, 1032 Shop 1 Inkk,
// 1033 Shop 2 Vodafone, 1034 Shop 2 Inkk). Top-up: the invoice goes to 1030 (top-ups paid), then the wallet gets the
// value put on (Dr wallet, Cr 1030 paid, Cr 4300 commission). Sales: Dr 5300 recharge sold (face value), Cr wallet.
// A difference at a shift: Dr / Cr 6900 against the wallet.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, addDays, dateStr, money, getShared, setShared } from '../../services/core.js';
import { asService, requireTop, requirePerm, liveUser } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const need = (c, m) => { if (!c) throw new AppError(m); };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const num = (v) => (v === '' || v === null || v === undefined || !Number.isFinite(Number(v)) ? null : r2(v));
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);

export const PROVIDERS = [{ key: 'vodafone', label: 'Vodafone' }, { key: 'inkk', label: 'Inkk' }];
const provLabel = (p) => (PROVIDERS.find((x) => x.key === p) || { label: p }).label;
export const TOPUP_CATEGORY = 'Recharge machine top-up';

export const RECHARGE_SQL = `
CREATE TABLE IF NOT EXISTS recharge_moves (
  uid TEXT PRIMARY KEY,
  wallet_uid TEXT NOT NULL, shop_code TEXT NOT NULL, provider TEXT NOT NULL,
  kind TEXT NOT NULL,
  move_date TEXT NOT NULL, at TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0, paid REAL, commission REAL,
  supplier_uid TEXT, supplier_name TEXT, invoice_uid TEXT, payment_uid TEXT, method TEXT,
  reading TEXT, expected REAL, diff REAL, sales REAL, topups REAL, open_amount REAL, open_at TEXT,
  count_uid TEXT, shift_uid TEXT, cashier_uid TEXT, cashier_name TEXT, action TEXT, charge_uid TEXT,
  note TEXT, by_uid TEXT, by_name TEXT, status TEXT NOT NULL DEFAULT 'active',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_recharge_moves_wallet ON recharge_moves (wallet_uid, at);
CREATE TABLE IF NOT EXISTS recharge_sales (
  uid TEXT PRIMARY KEY,
  source TEXT NOT NULL, shop_code TEXT NOT NULL, provider TEXT NOT NULL, sale_date TEXT NOT NULL,
  value REAL NOT NULL DEFAULT 0, refunds REAL NOT NULL DEFAULT 0, src TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_recharge_sales_day ON recharge_sales (shop_code, sale_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const RECHARGE_SYNC = {
  recharge_moves: SYNC('uid', 'Till & cash', ['uid', 'wallet_uid', 'shop_code', 'provider', 'kind', 'move_date', 'at', 'amount', 'paid', 'commission', 'supplier_uid', 'supplier_name',
    'invoice_uid', 'payment_uid', 'method', 'reading', 'expected', 'diff', 'sales', 'topups', 'open_amount', 'open_at', 'count_uid', 'shift_uid', 'cashier_uid', 'cashier_name',
    'action', 'charge_uid', 'note', 'by_uid', 'by_name', 'status']),
  recharge_sales: SYNC('uid', 'Till & cash', ['uid', 'source', 'shop_code', 'provider', 'sale_date', 'value', 'refunds', 'src']),
};

// ---------------------------------------------------------------- the set-up (locked: Settings › Recharge machines)
// recharge_setup: { wallets: { uid: { name, active, low, usual } }, map: { S1: { vodafone: { codes, groups }, inkk: … } },
//                   suppliers: { supplierUid: 'vodafone' | 'inkk' | 'both' } }
export function rcSetup() {
  const s = getShared('recharge_setup', {}) || {};
  return { wallets: s.wallets && typeof s.wallets === 'object' ? s.wallets : {}, map: s.map && typeof s.map === 'object' ? s.map : {}, suppliers: s.suppliers && typeof s.suppliers === 'object' ? s.suppliers : {} };
}
const top = (u) => !!u && ['owner', 'admin'].includes(u.role);
function saveSetup(user, next, what) {
  requireTop(user, 'set up the recharge machines');
  return asService(() => {
    setShared('recharge_setup', next);
    audit({ user, action: `Recharge machines: ${what}`, table: 'shared_settings', recordUid: 'recharge_setup' });
    return rcSetup();
  });
}
export const walletUid = (shop, prov) => `RW-${shop}-${prov}`;
const shopNo = (shop) => { const m = /^S(\d+)$/i.exec(txt(shop)); return m ? Number(m[1]) : null; };
// The wallet's own account in the chart: 1031 + 2 per shop (Shop 1 1031/1032, Shop 2 1033/1034 …), 1039 for the rest.
export function walletCode(shop, prov) {
  const n = shopNo(shop);
  const c = n && n <= 4 ? 1031 + (n - 1) * 2 + (prov === 'inkk' ? 1 : 0) : 1039;
  return String(c);
}
const shortShop = (code) => {
  const s = safe(() => db().get('SELECT name FROM shops WHERE code = ?', [code]), null);
  const n = s && txt(s.name) ? txt(s.name).replace(/\s+-\s+.*$/, '') : '';
  return n || (shopNo(code) ? `Shop ${shopNo(code)}` : code);
};
// Every wallet (one per shop with a till per network): [{ uid, shop_code, provider, name, active, low, usual, code, inUse }]
export function listWallets({ includeOff = false, shop = '' } = {}) {
  const st = rcSetup();
  const shops = safe(() => db().all("SELECT DISTINCT t.shop_code AS code FROM tills t LEFT JOIN shops s ON s.code = t.shop_code WHERE t.active = 1 AND IFNULL(s.active, 1) = 1 AND t.shop_code <> 'BAKERY' ORDER BY t.shop_code"), []);
  const out = [];
  for (const { code } of shops) {
    if (shop && code !== shop) continue;
    for (const p of PROVIDERS) {
      const uid = walletUid(code, p.key);
      const o = st.wallets[uid] || {};
      const m = ((st.map[code] || {})[p.key]) || {};
      const mapped = (m.codes || []).length > 0 || (m.groups || []).length > 0;
      const active = o.active !== false;
      const w = { uid, shop_code: code, provider: p.key, providerLabel: p.label, name: txt(o.name) || `${shortShop(code)} ${p.label}`, active, low: num(o.low), usual: num(o.usual), code: walletCode(code, p.key), mapped };
      w.inUse = active && (mapped || safe(() => !!db().get("SELECT 1 AS x FROM recharge_moves WHERE wallet_uid = ? AND status = 'active' LIMIT 1", [uid]), false));
      if (includeOff || active) out.push(w);
    }
  }
  return out;
}
export const getWallet = (uid) => listWallets({ includeOff: true }).find((w) => w.uid === uid) || null;
// The wallets' accounts in the chart (added once; synced like every account).
export function ensureWalletAccounts() {
  const now = stamp(); const dev = deviceId();
  for (const w of listWallets({ includeOff: true })) {
    safe(() => db().run('INSERT OR IGNORE INTO gl_accounts (code, name, type, grp, system, updated_at, updated_device) VALUES (?,?,?,?,1,?,?)', [w.code, w.code === '1039' ? 'Recharge machines – other shops' : `Recharge machine – ${w.name}`, 'asset', 'Recharge machines', now, dev]), null);
  }
}
export function saveWalletSettings(user, uid, { name, active, low, usual } = {}) {
  const w = getWallet(uid);
  need(w, 'This recharge balance is not found.');
  const lo = num(low); const us = num(usual);
  need(lo === null || lo >= 0, 'The top-up level cannot be below zero.');
  need(us === null || us > 0, 'The usual top-up must be more than zero.');
  const st = rcSetup();
  const next = { ...st, wallets: { ...st.wallets, [uid]: { name: txt(name) || w.name, active: active !== false, low: lo, usual: us } } };
  return saveSetup(user, next, `${w.name} – ${active === false ? 'switched off' : `top up when below ${lo === null ? '(no level)' : $(lo)}`}`);
}
export function saveRechargeSuppliers(user, map = {}) {
  const st = rcSetup();
  const clean = {};
  for (const [k, v] of Object.entries(map || {})) if (txt(k) && ['vodafone', 'inkk', 'both'].includes(v)) clean[k] = v;
  return saveSetup(user, { ...st, suppliers: clean }, `recharge suppliers (${Object.keys(clean).length})`);
}
export const rechargeSupplier = (supplierUid) => rcSetup().suppliers[txt(supplierUid)] || null;

// ---------------------------------------------------------------- which Aronium products are recharge
// All products of a shop as Aronium has them: [{ code, name, group }]
export function shopProducts(shop) {
  const L = require('../aronium/link.js');
  const items = safe(() => L.aroniumProducts(shop).items, []) || [];
  const seen = new Set(); const out = [];
  for (const p of items) { const c = txt(p.code); if (!c || seen.has(c.toUpperCase())) continue; seen.add(c.toUpperCase()); out.push({ code: c, name: txt(p.name) || c, group: txt(p.group) }); }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
export const guessProvider = (name) => (/inkk/i.test(name) ? 'inkk' : /voda/i.test(name) ? 'vodafone' : /recharge|top\s*-?\s*up|e-?load|airtime/i.test(name) ? '?' : null);
// The suggestion: products (and groups) whose name says recharge – with the network when the name says it.
export function suggestMapping(shop) {
  const prods = shopProducts(shop);
  const products = prods.map((p) => ({ ...p, guess: guessProvider(`${p.name} ${p.group}`) })).filter((p) => p.guess);
  const groups = Array.from(new Set(prods.map((p) => p.group).filter(Boolean))).map((g) => ({ group: g, guess: guessProvider(g) })).filter((g) => g.guess);
  return { products, groups };
}
export function mappingFor(shop) {
  const m = rcSetup().map[shop] || {};
  const o = {};
  for (const p of PROVIDERS) o[p.key] = { codes: ((m[p.key] || {}).codes || []).map(txt).filter(Boolean), groups: ((m[p.key] || {}).groups || []).map(txt).filter(Boolean) };
  return o;
}
// map: { vodafone: { codes: [...], groups: [...] }, inkk: { … } }
export function saveMapping(user, shop, map = {}) {
  need(txt(shop), 'Choose the shop.');
  const clean = {};
  const used = new Map();
  for (const p of PROVIDERS) {
    const codes = Array.from(new Set(((map[p.key] || {}).codes || []).map(txt).filter(Boolean)));
    const groups = Array.from(new Set(((map[p.key] || {}).groups || []).map(txt).filter(Boolean)));
    for (const c of codes) { need(!used.has(`c${c.toUpperCase()}`), `Product ${c} is ticked as both Vodafone and Inkk – choose one.`); used.set(`c${c.toUpperCase()}`, p.key); }
    for (const g of groups) { need(!used.has(`g${g.toLowerCase()}`), `Group ${g} is chosen for both Vodafone and Inkk – choose one.`); used.set(`g${g.toLowerCase()}`, p.key); }
    clean[p.key] = { codes, groups };
  }
  const st = rcSetup();
  const r = saveSetup(user, { ...st, map: { ...st.map, [shop]: clean } }, `${shop} products – Vodafone ${clean.vodafone.codes.length + clean.vodafone.groups.length}, Inkk ${clean.inkk.codes.length + clean.inkk.groups.length}`);
  safe(() => refreshSales({ from: addDays(dateStr(), -35) }), null);
  return r;
}
// code → 'vodafone' | 'inkk' | null for one shop (a product ticked by itself wins over its group).
export function providerLookup(shop) {
  const m = mappingFor(shop);
  const byCode = new Map(); const byGroup = new Map();
  for (const p of PROVIDERS) { m[p.key].codes.forEach((c) => byCode.set(c.toUpperCase(), p.key)); m[p.key].groups.forEach((g) => byGroup.set(g.toLowerCase(), p.key)); }
  let groupOf = null;
  if (byGroup.size) { groupOf = new Map(); shopProducts(shop).forEach((p) => groupOf.set(p.code.toUpperCase(), p.group.toLowerCase())); }
  return (code) => {
    const k = txt(code).toUpperCase();
    if (byCode.has(k)) return byCode.get(k);
    if (groupOf) { const g = groupOf.get(k); if (g && byGroup.has(g)) return byGroup.get(g); }
    return null;
  };
}

// ---------------------------------------------------------------- the sales (from the Aronium Link, read only)
const sourcesOf = (shop) => safe(() => db().all("SELECT DISTINCT source FROM aronium_feed WHERE shop_code = ? AND kind IN ('sales_day','receipts') ORDER BY source", [shop]).map((r) => r.source), []);
function dayLines(source, date) {
  const L = require('../aronium/link.js');
  const d = safe(() => L.aroniumSalesByDay({ from: date, withLines: true }).find((x) => x.source === source && x.date === date), null);
  return d ? d.lines || [] : null;
}
function receiptsOf(shop, source, date) {
  const L = require('../aronium/link.js');
  return safe(() => L.aroniumReceipts({ date, shop }).filter((r) => r.source === source), []);
}
// What one till PC sold of each network on a day: { vodafone: { value, refunds }, inkk: … , src } – the day's figure
// when it is in, else the receipts sent so far.
function sourceDay(shop, source, date, look) {
  const out = { vodafone: { value: 0, refunds: 0 }, inkk: { value: 0, refunds: 0 }, src: null };
  const lines = dayLines(source, date);
  if (lines) {
    out.src = 'day';
    for (const l of lines) {
      const p = look(l.code); if (!p) continue;
      out[p].value = r2(out[p].value + Number(l.sold_value || 0) - Number(l.refund_value || 0));
      out[p].refunds = r2(out[p].refunds + Number(l.refund_value || 0));
    }
    return out;
  }
  const rc = receiptsOf(shop, source, date);
  if (!rc.length) return out;
  out.src = 'receipts';
  for (const r of rc) {
    for (const l of r.items || []) {
      const p = look(l.code); if (!p) continue;
      const v = r2(l.total || l.qty * l.price - l.disc);
      if (r.refund) { out[p].value = r2(out[p].value - v); out[p].refunds = r2(out[p].refunds + v); } else out[p].value = r2(out[p].value + v);
    }
  }
  return out;
}
// Keeps recharge_sales up to date (one row per till PC, day and network – replaced, never added). Run by the Link's
// processing and when a recharge page opens.
export function refreshSales({ from = addDays(dateStr(), -7), to = dateStr() } = {}) {
  if (!has('aronium_feed')) return 0;
  let n = 0;
  const shops = Array.from(new Set(listWallets().filter((w) => w.mapped).map((w) => w.shop_code)));
  for (const shop of shops) {
    const look = providerLookup(shop);
    const dates = safe(() => db().all("SELECT DISTINCT period AS d FROM aronium_feed WHERE shop_code = ? AND kind IN ('sales_day','receipts') AND period BETWEEN ? AND ? ORDER BY period", [shop, from, to]).map((r) => r.d), []);
    for (const source of sourcesOf(shop)) {
      for (const date of dates) {
        const s = sourceDay(shop, source, date, look);
        if (!s.src) continue;
        for (const p of PROVIDERS) {
          const uid = `RS|${source}|${date}|${p.key}`;
          const v = s[p.key];
          const before = db().get('SELECT value, refunds, src FROM recharge_sales WHERE uid = ?', [uid]);
          if (before && r2(before.value) === r2(v.value) && r2(before.refunds) === r2(v.refunds) && before.src === s.src) continue;
          if (!before && !v.value && !v.refunds) continue;
          db().run(`INSERT INTO recharge_sales (uid, source, shop_code, provider, sale_date, value, refunds, src, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(uid) DO UPDATE SET value = excluded.value, refunds = excluded.refunds, src = excluded.src, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
          [uid, source, shop, p.key, date, r2(v.value), r2(v.refunds), s.src, stamp(), deviceId()]);
          n += 1;
        }
      }
    }
  }
  return n;
}
export function salesOn(walletUidOrW, from, to) {
  const w = typeof walletUidOrW === 'string' ? getWallet(walletUidOrW) : walletUidOrW;
  if (!w) return 0;
  return r2(safe(() => db().get('SELECT SUM(value) AS s FROM recharge_sales WHERE shop_code = ? AND provider = ? AND sale_date BETWEEN ? AND ?', [w.shop_code, w.provider, from, to]).s, 0));
}
// The recharge sold between two moments ('YYYY-MM-DD HH:MM:SS', from exclusive): { value, refunds }.
// Per till PC and day: the receipts in that time (live); a day without receipt lines (an older Link) counts its day
// figure less what earlier shift readings of that day already took.
export function salesBetween(w, from, to) {
  const out = { value: 0, refunds: 0 };
  if (!w || !w.mapped) return out;
  const look = providerLookup(w.shop_code);
  const d0 = txt(from).slice(0, 10) || dateStr(); const d1 = txt(to).slice(0, 10) || dateStr();
  for (let d = d0 < addDays(d1, -14) ? addDays(d1, -14) : d0; d <= d1; d = addDays(d, 1)) {
    for (const source of sourcesOf(w.shop_code)) {
      const rc = receiptsOf(w.shop_code, source, d);
      const withLines = rc.some((r) => (r.items || []).length);
      if (withLines) {
        for (const r of rc) {
          const at = `${d} ${r.time}`;
          if (at <= txt(from) || at > txt(to)) continue;
          for (const l of r.items || []) {
            if (look(l.code) !== w.provider) continue;
            const v = r2(l.total || l.qty * l.price - l.disc);
            if (r.refund) { out.value = r2(out.value - v); out.refunds = r2(out.refunds + v); } else out.value = r2(out.value + v);
          }
        }
        continue;
      }
      const lines = dayLines(source, d);
      if (!lines) continue;
      let v = 0; let rf = 0;
      for (const l of lines) { if (look(l.code) !== w.provider) continue; v += Number(l.sold_value || 0) - Number(l.refund_value || 0); rf += Number(l.refund_value || 0); }
      const taken = d === d0 ? r2(safe(() => db().get("SELECT SUM(sales) AS s FROM recharge_moves WHERE wallet_uid = ? AND kind = 'reading' AND reading = 'close' AND status = 'active' AND move_date = ? AND at <= ?", [w.uid, d, txt(from)]).s, 0)) : 0;
      out.value = r2(out.value + v - taken); out.refunds = r2(out.refunds + rf);
    }
  }
  return out;
}

// ---------------------------------------------------------------- the balance: read off the machine, and what it should be
export function lastReading(uid, before = '9999-12-31 99') {
  return safe(() => db().get("SELECT * FROM recharge_moves WHERE wallet_uid = ? AND kind = 'reading' AND status = 'active' AND at <= ? ORDER BY at DESC, rowid DESC LIMIT 1", [uid, before]), null);
}
export const lastClose = (uid) => safe(() => db().get("SELECT * FROM recharge_moves WHERE wallet_uid = ? AND kind = 'reading' AND reading = 'close' AND status = 'active' ORDER BY at DESC, rowid DESC LIMIT 1", [uid]), null);
// What should be on one balance at a moment: { wallet, open, from ('last shift' | 'start of shift' | 'none'), openAt,
// topups, sales, refunds, expected }
export function shouldBe(w, until = stamp()) {
  const r = lastReading(w.uid, until);
  const firstTop = r ? null : safe(() => db().get("SELECT MIN(at) AS a FROM recharge_moves WHERE wallet_uid = ? AND kind = 'topup' AND status = 'active'", [w.uid]).a, null);
  const since = r ? r.at : firstTop ? `${txt(firstTop).slice(0, 10)} 00:00:00` : `${txt(until).slice(0, 10)} 00:00:00`;
  const topups = r2(safe(() => db().get("SELECT SUM(amount) AS s FROM recharge_moves WHERE wallet_uid = ? AND kind = 'topup' AND status = 'active' AND at > ? AND at <= ?", [w.uid, r ? r.at : '0000', until]).s, 0));
  const s = salesBetween(w, since, until);
  const open = r ? r2(r.amount) : 0;
  return { wallet: w, open, from: r ? (r.reading === 'close' ? 'last shift' : 'start of shift') : 'none', openAt: r ? r.at : null, since, topups, sales: s.value, refunds: s.refunds, expected: r2(open + topups - s.value) };
}
// The balances to ask about at a shift change of a shop (the wallets in use).
export function shiftPlan(shopCode, until = stamp()) {
  return listWallets({ shop: shopCode }).filter((w) => w.inUse).map((w) => shouldBe(w, until));
}
export function rcResult(p, close, tolerance = 0) {
  if (!p || num(close) === null) return { state: 'none', diff: null, amount: 0 };
  const diff = r2(num(close) - p.expected);
  const state = Math.abs(diff) <= Number(tolerance) + 0.004 ? 'balanced' : diff < 0 ? 'short' : 'over';
  return { state, diff, amount: r2(Math.abs(diff)) };
}
// Start shift: the balance on each machine – only asked when there is no closing yet; otherwise the last close is
// filled in (to confirm). values: { walletUid: amount }
export function startPlan(shopCode) {
  return listWallets({ shop: shopCode }).filter((w) => w.inUse).map((w) => { const c = lastClose(w.uid); return { wallet: w, last: c ? { amount: r2(c.amount), at: c.at } : null }; });
}
export function recordOpen(user, { shopCode, values = {}, shiftUid, date = dateStr(), at = stamp() } = {}) {
  const out = [];
  for (const p of startPlan(shopCode)) {
    const typed = num(values[p.wallet.uid]);
    need(typed !== null || p.last, `Type the ${p.wallet.name} balance on the recharge machine.`);
    const amount = typed !== null ? typed : p.last.amount;
    need(amount >= 0, 'The recharge balance cannot be below zero.');
    // the same as the last close: nothing new to keep (the last close stays the start)
    if (p.last && Math.abs(amount - p.last.amount) < 0.005) { out.push({ wallet: p.wallet, amount, same: true }); continue; }
    const exp = shouldBe(p.wallet, at);
    const diff = p.last ? r2(amount - exp.expected) : 0;
    const uid = uuid('RC');
    db().run(`INSERT INTO recharge_moves (uid, wallet_uid, shop_code, provider, kind, move_date, at, amount, reading, expected, diff, sales, topups, open_amount, open_at, shift_uid, cashier_uid, cashier_name, note, by_uid, by_name, updated_at, updated_device)
      VALUES (?,?,?,?, 'reading', ?,?,?, 'open', ?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, p.wallet.uid, p.wallet.shop_code, p.wallet.provider, date, at, amount, p.last ? exp.expected : null, diff, p.last ? exp.sales : 0, p.last ? exp.topups : 0, exp.open, exp.openAt, shiftUid || null, user.uid, user.name,
      p.last ? `Start of shift: ${$(amount)}, the last shift closed at ${$(p.last.amount)}` : 'First balance read off the machine', user.uid, user.name, stamp(), deviceId()]);
    audit({ user, action: `${p.wallet.name} at the start of the shift: ${$(amount)}${p.last ? ` (last close ${$(p.last.amount)})` : ''}`, table: 'recharge_moves', recordUid: uid });
    out.push({ wallet: p.wallet, amount, diff, flag: p.last ? `${p.wallet.name} at the start ${$(amount)}, the last shift closed at ${$(p.last.amount)}` : null });
  }
  return out;
}
// End shift / Balance the till: keep each balance read off the machine, book the difference once and settle a short.
// close: { walletUid: amount }; action: { walletUid: 'pay' | 'paid_now' | 'explain' }; note: { walletUid: text }
export function applyRc(user, { count, shopCode, date, until = stamp(), close = {}, action = {}, note = {}, tolerance = 0, shiftUid } = {}) {
  const shop = shopCode || (count && count.shop_code);
  const plans = shiftPlan(shop, until);
  if (!plans.length) return [];
  const me = liveUser(user, { fresh: true }) || user;
  // staff only enter the balances of their own shift
  if (count && ['staff', 'worker'].includes(me.role)) need(count.cashier_uid === me.uid, 'You can only enter the recharge balances of your own shift.');
  return asService(() => plans.filter((p) => num(close[p.wallet.uid]) !== null).map((p) => {
    const uidW = p.wallet.uid;
    const c = num(close[uidW]);
    need(c >= 0, 'The recharge balance cannot be below zero.');
    const res = rcResult(p, c, tolerance);
    const act = res.state === 'short' ? (['pay', 'paid_now', 'explain'].includes(action[uidW]) ? action[uidW] : 'pay') : res.state === 'over' ? 'over' : null;
    if (act === 'explain') need(txt(note[uidW]).length >= 3, `Write why the ${p.wallet.name} balance is short.`);
    const d = date || (count && count.shift_date) || txt(until).slice(0, 10);
    const what = count ? `${count.till_name || 'Till'} ${count.shift || ''} ${count.shift_date}`.replace(/\s+/g, ' ') : d;
    const cashierUid = count ? count.cashier_uid : user.uid; const cashierName = count ? count.cashier_name : user.name;
    // one reading per balance per till count (saved again → the same reading)
    const uid = count ? `RC-${count.uid}-${p.wallet.provider}` : uuid('RC');
    need(!db().get('SELECT 1 AS x FROM recharge_moves WHERE uid = ?', [uid]), `The ${p.wallet.name} balance of this shift is already saved.`);
    let chargeUid = null;
    if (act === 'pay') {
      const ch = require('../payroll/service.js').chargeStaff(user, { userUid: cashierUid, amount: res.amount, reason: `${p.wallet.name} recharge short ${what}`, source: 'recharge_short', refUid: uid, shopCode: shop, date: d });
      chargeUid = ch && ch.uid ? ch.uid : null;
    } else if (act === 'paid_now') {
      require('./service.js').addCashMove({ shopCode: shop, date: d, type: 'adjust_in', amount: res.amount, refUid: uid, category: 'Recharge short repaid', note: `${cashierName} paid the ${p.wallet.name} short of ${what}`, user });
    }
    db().run(`INSERT INTO recharge_moves (uid, wallet_uid, shop_code, provider, kind, move_date, at, amount, reading, expected, diff, sales, topups, open_amount, open_at, count_uid, shift_uid, cashier_uid, cashier_name, action, charge_uid, note, by_uid, by_name, updated_at, updated_device)
      VALUES (?,?,?,?, 'reading', ?,?,?, 'close', ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, uidW, shop, p.wallet.provider, d, until, c, p.expected, res.diff, p.sales, p.topups, p.open, p.openAt, count ? count.uid : null, shiftUid || null, cashierUid, cashierName, act, chargeUid, txt(note[uidW]) || null, user.uid, user.name, stamp(), deviceId()]);
    audit({ user, action: `${p.wallet.name} ${what}: opening ${$(p.open)} + top-ups ${$(p.topups)} − sales ${$(p.sales)} = ${$(p.expected)}; machine says ${$(c)} – ${res.state === 'balanced' ? 'balanced' : `${res.state} ${$(res.amount)}${act && act !== 'over' ? ` (${act})` : ''}`}`, table: 'recharge_moves', recordUid: uid, reason: txt(note[uidW]) || undefined });
    if (res.state === 'short') { safe(() => require('../verify/service.js').notify('till_short', `${p.wallet.name} recharge SHORT ${$(res.amount)} at the end of ${what} (${cashierName})${act === 'explain' ? ` – ${txt(note[uidW])}` : act === 'paid_now' ? ' – paid now' : ' – from pay'}`, { shopCode: shop }), null); }
    return { wallet: p.wallet, expected: p.expected, close: c, ...res, action: act };
  }));
}

// ---------------------------------------------------------------- top up the machine (from the supplier payment)
// Owner / admin, or a manager / supervisor of that shop.
export function mayTopUp(user, shopCode) {
  const u = liveUser(user) || user;
  if (!u) return false;
  if (top(u) || safe(() => require('../../services/access.js').actsAsOwner(u), false)) return true;
  return ['manager', 'supervisor'].includes(u.role) && !!u.shop_code && (!shopCode || u.shop_code === shopCode);
}
// input: { shopCode, provider, paid, credited, supplierUid, method: 'cash' | 'mpaisa' | 'transfer' | 'cheque', cashFrom,
//          walletUid (M-PAiSA), accountUid, reference, chequeNo, date, photos, note }
export function topUp(user, input = {}) {
  const shop = txt(input.shopCode);
  need(shop, 'Choose the shop.');
  const u = requirePerm(user, ['role:owner', 'role:admin', 'role:manager', 'role:supervisor'], { shop, money: true }) || liveUser(user, { fresh: true }) || user;
  need(mayTopUp(u, shop), mayTopUp(u) ? 'You can only top up your own shop\'s recharge machine.' : 'Only the owner, an admin, or the shop\'s manager or supervisor tops up the recharge machine.');
  const w = getWallet(walletUid(shop, txt(input.provider)));
  need(w && w.active, 'Choose Vodafone or Inkk.');
  const paid = num(input.paid); const credited = num(input.credited);
  need(paid !== null && paid > 0, 'Type the amount paid to the supplier.');
  need(credited !== null && credited > 0, 'Type the value put on the machine.');
  need(credited >= paid - 0.004, 'The value put on the machine is less than what was paid. Check the two figures.');
  need(credited <= paid * 1.5 + 0.004, 'The value put on the machine is much more than what was paid. Check the two figures.');
  const AP = require('../payables/service.js');
  const sup = AP.getSupplier(txt(input.supplierUid));
  need(sup, 'Choose the supplier.');
  const date = txt(input.date) || dateStr();
  const method = ['cash', 'mpaisa', 'transfer', 'cheque'].includes(input.method) ? input.method : 'cash';
  return asService(() => {
    ensureWalletAccounts();
    const ref = txt(input.reference);
    const inv = AP.saveInvoice(u, { supplierUid: sup.uid, total: paid, invoiceNo: ref || `TOPUP-${w.shop_code}-${w.provider.toUpperCase()}-${stamp().replace(/\D/g, '')}`, invoiceDate: date, shopCode: shop, vatType: 'zero',
      category: TOPUP_CATEGORY, onAccount: false, payMethod: method, description: `${w.name} top-up: paid ${$(paid)}, ${$(credited)} put on the machine`, notes: txt(input.note) || null }, { photos: input.photos || [], allowDuplicate: true, canCheck: true });
    const pay = AP.makePayment(u, { supplierUid: sup.uid, method, payDate: date, shopCode: shop, cashFrom: method === 'cash' ? (txt(input.cashFrom) || 'safe') : undefined, walletUid: input.walletUid,
      accountUid: input.accountUid, reference: ref || (method === 'cash' ? undefined : ref), chequeNo: input.chequeNo, notes: `${w.name} top-up`, allocations: [{ invoiceUid: inv.uid, amount: paid }] });
    const uid = uuid('RT');
    const commission = r2(credited - paid);
    db().run(`INSERT INTO recharge_moves (uid, wallet_uid, shop_code, provider, kind, move_date, at, amount, paid, commission, supplier_uid, supplier_name, invoice_uid, payment_uid, method, note, by_uid, by_name, updated_at, updated_device)
      VALUES (?,?,?,?, 'topup', ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, w.uid, shop, w.provider, date, stamp(), credited, paid, commission, sup.uid, sup.name, inv.uid, pay.uid, method, txt(input.note) || null, u.uid, u.name, stamp(), deviceId()]);
    audit({ user: u, action: `Topped up ${w.name}: paid ${sup.name} ${$(paid)} by ${method}, ${$(credited)} put on the machine (commission ${$(commission)})`, table: 'recharge_moves', recordUid: uid });
    return { uid, wallet: w, paid, credited, commission, invoiceUid: inv.uid, paymentUid: pay.uid };
  });
}

// ---------------------------------------------------------------- the office: each balance now, history, warnings
export function walletStatus(w, today = dateStr()) {
  const now = stamp();
  const sb = shouldBe(w, now);
  const lt = safe(() => db().get("SELECT * FROM recharge_moves WHERE wallet_uid = ? AND kind = 'topup' AND status = 'active' ORDER BY at DESC LIMIT 1", [w.uid]), null);
  const mon = `${today.slice(0, 7)}-01`;
  const wk = addDays(today, -6);
  const commissionMonth = r2(safe(() => db().get("SELECT SUM(commission) AS s FROM recharge_moves WHERE wallet_uid = ? AND kind = 'topup' AND status = 'active' AND move_date BETWEEN ? AND ?", [w.uid, mon, today]).s, 0));
  const below = w.low !== null && sb.expected < w.low - 0.004;
  const reading = lastReading(w.uid);
  return { wallet: w, balance: sb.expected, should: sb, lastTopUp: lt ? { date: lt.move_date, amount: r2(lt.amount), paid: r2(lt.paid), supplier: lt.supplier_name } : null,
    salesToday: salesOn(w, today, today), salesWeek: salesOn(w, wk, today), commissionMonth, below, lastReading: reading ? { at: reading.at, amount: r2(reading.amount), kind: reading.reading } : null };
}
const seesShop = (u, shop) => !!u && (top(u) || !u.shop_code || u.shop_code === shop || safe(() => require('../../services/access.js').can(u, 'reports'), false));
export function overview(user, { refresh = true } = {}) {
  if (refresh) safe(() => refreshSales(), null);
  return listWallets().filter((w) => w.inUse && seesShop(user, w.shop_code)).map((w) => walletStatus(w));
}
export function history(uid, { limit = 100 } = {}) {
  return safe(() => db().all("SELECT * FROM recharge_moves WHERE wallet_uid = ? AND status = 'active' ORDER BY at DESC, rowid DESC LIMIT ?", [uid, limit]), []).map((m) => ({
    uid: m.uid, date: m.move_date, at: m.at, kind: m.kind, reading: m.reading, amount: r2(m.amount), paid: m.paid, commission: m.commission, supplier: m.supplier_name, diff: m.diff, expected: m.expected,
    who: m.cashier_name || m.by_name, action: m.action, note: m.note,
    text: m.kind === 'topup' ? `Top-up ${$(m.amount)} (paid ${m.supplier_name} ${$(m.paid)}, commission ${$(m.commission)})`
      : m.reading === 'open' ? `Start of shift: ${$(m.amount)}` : `End of shift: ${$(m.amount)} – ${Math.abs(Number(m.diff) || 0) < 0.005 ? 'balanced' : `${Number(m.diff) < 0 ? 'short' : 'over'} ${$(Math.abs(m.diff))}`}`,
  }));
}
// Home warning (and phone notification once a day): "Top up Shop 1 Vodafone – balance about $X".
export function lowAlerts(user, today = dateStr()) {
  if (!user || !listWallets().some((w) => w.inUse && w.low !== null)) return [];
  return listWallets().filter((w) => w.inUse && w.low !== null && mayTopUp(user, w.shop_code)).map((w) => ({ w, b: shouldBe(w).expected })).filter((x) => x.b < x.w.low - 0.004)
    .map(({ w, b }) => ({ id: `recharge-low-${w.uid}-${today}`, level: 'warning', notify: true, area: 'Recharge', text: `Top up ${w.name} – balance about ${$(Math.max(0, b))}`,
      sub: `Top up when below ${$(w.low)}${w.usual ? ` · usual top-up ${$(w.usual)}` : ''}`, nav: { screen: 'RechargeTopUp', params: { shopCode: w.shop_code, provider: w.provider } } }));
}
// Office › Today: the business at a glance – each balance, and the ones below their level.
export function glanceItems(user, shop = '') {
  return safe(() => listWallets().filter((w) => w.inUse && (!shop || w.shop_code === shop) && seesShop(user, w.shop_code)).map((w) => {
    const b = shouldBe(w).expected; const low = w.low !== null && b < w.low - 0.004;
    return { key: `rc-${w.shop_code}-${w.provider}`, label: w.name, value: $(b), screen: 'Recharge', note: low ? `Below ${$(w.low)} – top up` : null, low };
  }), []);
}

// ---------------------------------------------------------------- report: recharge sales and commission by shop and month
const col = (key, title, align = 'left') => ({ key, title, align });
export const RECHARGE_REPORTS = [
  { id: 'recharge_month', group: 'Till & cash', icon: '📱', title: 'Recharge sales & commission', desc: 'Each recharge balance by month: sold (face value), topped up, commission', perm: 'reports',
    build(from, to) {
      safe(() => refreshSales({ from, to }), null);
      const rows = [];
      const wallets = listWallets({ includeOff: true });
      const months = new Set();
      safe(() => db().all('SELECT DISTINCT substr(sale_date,1,7) AS m FROM recharge_sales WHERE sale_date BETWEEN ? AND ? UNION SELECT DISTINCT substr(move_date,1,7) FROM recharge_moves WHERE kind = \'topup\' AND move_date BETWEEN ? AND ?', [from, to, from, to]), []).forEach((r) => months.add(r.m));
      let sold = 0; let comm = 0; let topped = 0;
      for (const m of Array.from(months).sort()) {
        const a = m < from.slice(0, 7) ? from : `${m}-01`; const b = `${m}-31` > to ? to : `${m}-31`;
        for (const w of wallets) {
          const s = salesOn(w, a, b);
          const t = safe(() => db().get("SELECT SUM(amount) AS c, SUM(paid) AS p, SUM(commission) AS k FROM recharge_moves WHERE wallet_uid = ? AND kind = 'topup' AND status = 'active' AND move_date BETWEEN ? AND ?", [w.uid, a, b]), {}) || {};
          if (!s && !t.c) continue;
          sold += s; comm += Number(t.k) || 0; topped += Number(t.c) || 0;
          rows.push({ month: m, shop: w.shop_code, wallet: w.name, sold: $(s), topped: $(t.c || 0), paid: $(t.p || 0), commission: $(t.k || 0) });
        }
      }
      return { kind: 'recharge_month', title: 'Recharge Sales and Commission', fileName: `Recharge-sales-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`, info: [['Period', `${from} to ${to}`], ['Generated', stamp()]],
        summary: [{ label: 'Recharge sold (face value)', value: $(sold) }, { label: 'Put on the machines', value: $(topped) }, { label: 'Commission', value: $(comm) }],
        sections: [{ title: 'By shop and month', columns: [col('month', 'Month'), col('shop', 'Shop'), col('wallet', 'Balance'), col('sold', 'Sold', 'right'), col('topped', 'Put on', 'right'), col('paid', 'Paid', 'right'), col('commission', 'Commission', 'right')], rows }] };
    } },
];
