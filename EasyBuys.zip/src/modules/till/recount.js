// v3.9.2 Till: a second count by a supervisor, surpluses (till over) recorded and decided, and a shortage paid by the
// cashier there and then (all or part – the rest goes to the pay run as before).
// Works with the rest of Till & cash: the cash moves follow every change (so cash on hand, deposits and the books stay
// right), the shortage / surplus records follow the count, and the warnings, handover and watchdog read them.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, money } from '../../services/core.js';
import { actsAsOwner, needReason, can } from '../../services/access.js';
import { requirePerm, requireShop, shopOf, asService } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const top = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
const supervisor = (u) => top(u) || (u && can(u, 'till_approve'));
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export { TILL392_SQL, TILL392_COUNT_COLUMNS, TILL392_SHORT_COLUMNS, TILL392_SYNC } from './schema392.js';
export const SURPLUS_STATUS = { open: 'Over – to decide', kept: 'Kept by the business', set_off: 'Set against a shortage', returned: 'Given back', void: 'Cancelled' };
export const SECOND_STATUS = { waiting: 'Waiting for the second count', confirmed: 'Second count agrees', differs: 'Second count was different' };

// ---------------------------------------------------------------- second count
export function secondCountRule() {
  try { return require('./service.js').tillRules().secondCount || 'off'; } catch (e) { return 'off'; }
}
// Called after every save of a count: does it need a supervisor to count again?
export function flagSecondCount(count, rules) {
  const rule = (rules && rules.secondCount) || secondCountRule(); // 'off' (default): a supervisor counts again only when they choose to
  const tol = rules ? rules.tolerance : 2;
  const want = rule === 'always' || (rule === 'when_off' && Math.abs(Number(count.over_short) || 0) > tol + 0.004);
  const done = ['confirmed', 'differs'].includes(count.second_status);
  const next = done ? count.second_status : want ? 'waiting' : null;
  if (next !== (count.second_status || null)) db().run('UPDATE till_counts SET second_status = ? WHERE uid = ?', [next, count.uid]);
  return next;
}
export function countsWaitingSecond({ shopCode } = {}) {
  if (!has('till_counts')) return [];
  return db().all(`SELECT * FROM till_counts WHERE second_status = 'waiting' AND status <> 'void' ${shopCode ? 'AND shop_code = ?' : ''} ORDER BY shift_date, counted_at`, shopCode ? [shopCode] : []);
}
// A supervisor (or the owner / admin) counts the drawer again without seeing the first count. Their count stands; the
// first count and the difference between the two are kept. Shortage / surplus and the cash moved to the safe follow.
export function saveSecondCount(user, uid, { denominations, counted, note } = {}) {
  requirePerm(user, 'till_count', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopOf('till_counts', uid)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const S = require('./service.js');
  const c = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
  need(c && c.status !== 'void', 'This till count is not found.');
  need(c.status !== 'approved' || top(user), 'This count is approved. A manager must re-open it first.');
  need(supervisor(user), 'Only a supervisor, the owner or admin does the second count.');
  need(user.uid !== c.counted_by_uid && user.uid !== c.cashier_uid, 'The second count must be done by someone else – not the person who counted first or the cashier.');
  const n = denominations && Object.keys(denominations).length ? S.countDenoms(denominations) : r2(counted);
  need(Number.isFinite(n) && n >= 0 && (n > 0 || Number(counted) === 0), 'Count the cash.');
  need(n >= r2(c.float_kept), `The cash counted (${$(n)}) is less than the float left in the till (${$(c.float_kept)}). Change the float on the count first.`);
  const diff = r2(n - Number(c.cash_counted));
  const first = J(c.first_count, null) || { denominations: J(c.denominations, {}), counted: c.cash_counted, by_uid: c.counted_by_uid, by_name: c.counted_by_name, at: c.counted_at };
  const { now, dev } = meta();
  const same = Math.abs(diff) < 0.005;
  const rules = S.tillRules();
  db().transaction(() => {
    if (same) {
      db().run(`UPDATE till_counts SET first_count = ?, second_status = 'confirmed', second_by_uid = ?, second_by_name = ?, second_at = ?, second_diff = 0, second_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
        [JSON.stringify(first), user.uid, user.name, now, txt(note) || null, now, dev, uid]);
    } else {
      const overShort = r2(n - Number(c.expected_cash));
      db().run(`UPDATE till_counts SET first_count = ?, denominations = ?, cash_counted = ?, over_short = ?, second_status = 'differs', second_by_uid = ?, second_by_name = ?, second_at = ?, second_diff = ?, second_note = ?,
        updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [JSON.stringify(first), JSON.stringify(denominations || {}), n, overShort, user.uid, user.name, now, diff, txt(note) || null, now, dev, uid]);
      // The cash that went to the safe follows the second count.
      db().run(`UPDATE cash_moves SET status = 'void', void_reason = 'Second count', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND type = 'from_till' AND status = 'active'`, [now, dev, uid]);
      const toSafe = r2(n - Number(c.float_kept) + Number(c.drops || 0));
      if (toSafe > 0) S.addCashMove({ shopCode: c.shop_code, date: c.shift_date, type: 'from_till', amount: toSafe, refUid: uid, note: `${c.till_name || 'Till'} ${c.shift || ''} ${c.shift_date} (second count)`, user });
      const saved = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
      require('./shifts.js').syncShortage(user, saved, rules.tolerance);
      syncSurplus(user, saved, rules.tolerance);
    }
  });
  audit({ user, action: `Second count ${c.till_name || 'Till'} ${c.shop_code} ${c.shift_date} ${c.shift || ''}: ${same ? `agrees (${$(n)})` : `${$(n)} – first count ${$(c.cash_counted)} by ${c.counted_by_name} (difference ${diff > 0 ? '+' : '−'}${$(Math.abs(diff))})`}`,
    table: 'till_counts', recordUid: uid, before: { counted: c.cash_counted, overShort: c.over_short }, after: { counted: n }, reason: txt(note) || undefined });
  if (!same) { try { require('../verify/service.js').notify('till_short', `Second count of ${c.till_name || 'Till'} ${c.shift || ''} ${c.shift_date} (${c.shop_code}) by ${user.name}: ${$(n)} – the first count by ${c.counted_by_name} was ${$(c.cash_counted)}.`, { shopCode: c.shop_code }); } catch (e) { /* offline */ } }
  return { same, diff, counted: n, count: S.getTillCount(uid) };
  });
}

// ---------------------------------------------------------------- surplus (till over)
export function surplusForCount(countUid) {
  if (!has('till_surplus')) return null;
  return db().get("SELECT * FROM till_surplus WHERE count_uid = ? AND status <> 'void' ORDER BY created_at DESC LIMIT 1", [countUid]);
}
// Kept in step with the till count: over by more than the tolerance → a surplus waiting for a decision.
export function syncSurplus(user, count, tolerance) {
  requirePerm(user, 'till_approve', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!has('till_surplus')) return null;
  const over = Number(count.over_short) > tolerance + 0.004 ? r2(count.over_short) : 0;
  const cur = surplusForCount(count.uid);
  const { now, dev } = meta();
  if (!over) {
    if (cur && cur.status === 'open') db().run(`UPDATE till_surplus SET status = 'void', decision_note = 'Till count changed – not over any more', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, cur.uid]);
    return null;
  }
  if (cur && cur.status === 'open') {
    if (Math.abs(cur.amount - over) > 0.004 || cur.user_uid !== count.cashier_uid) db().run(`UPDATE till_surplus SET amount = ?, user_uid = ?, name = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [over, count.cashier_uid, count.cashier_name, now, dev, cur.uid]);
    return cur.uid;
  }
  if (cur) return cur.uid; // already decided
  const uid = uuid('TO');
  db().run(`INSERT INTO till_surplus (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?, 'open', ?,?,?,?)`,
    [uid, count.uid, count.shop_code, count.shift_date, count.cashier_uid, count.cashier_name, over, user ? user.name : null, now, now, dev]);
  try { require('../verify/service.js').notify('till_short', `${count.till_name || 'Till'} ${count.shift || ''} ${count.shift_date} (${count.shop_code}) is OVER ${$(over)} (cashier ${count.cashier_name}).`, { shopCode: count.shop_code }); } catch (e) { /* offline */ }
  return uid;
  });
}
export function getSurplus(uid) { return has('till_surplus') ? db().get('SELECT * FROM till_surplus WHERE uid = ?', [uid]) : null; }
export function listSurpluses({ status, statuses, userUid, from, to, limit = 500 } = {}) {
  if (!has('till_surplus')) return [];
  const w = ['1=1']; const a = [];
  if (userUid) { w.push('user_uid = ?'); a.push(userUid); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); } else if (statuses) { w.push(`status IN (${statuses.map(() => '?').join(',')})`); a.push(...statuses); } else w.push("status <> 'void'");
  return db().all(`SELECT * FROM till_surplus WHERE ${w.join(' AND ')} ORDER BY shift_date DESC, created_at DESC LIMIT ?`, a.concat([limit]));
}
// Shortages of the same cashier that a surplus can be set against (not decided yet).
export function setOffChoices(surplusUid) {
  const s = getSurplus(surplusUid);
  if (!s) return [];
  return db().all("SELECT * FROM till_shortages WHERE status IN ('waiting','disagreed') AND user_uid IS ? ORDER BY shift_date", [s.user_uid]);
}
// keep: the business keeps it (already counted as till over in the books). set_off: set against the cashier's
// shortage (it is not taken from pay). returned: the extra cash was given back (a customer short-changed) – cash out.
export function decideSurplus(user, uid, { action, shortageUid, amount, note } = {}) {
  requirePerm(user, 'till_approve', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const s = getSurplus(uid);
  need(s && s.status === 'open', 'This surplus is already decided.');
  need(supervisor(user), 'Only a supervisor, the owner or admin decides a surplus.');
  need(['keep', 'set_off', 'returned'].includes(action), 'Choose what happens to the extra money.');
  // 1.0.0 build 3: nobody decides their own till over (it would let them take the cash out or cancel their shortage)
  need(top(user) || s.user_uid !== user.uid, 'Someone else must decide the extra money from your own till.');
  const { now, dev } = meta();
  if (action === 'keep') {
    db().run(`UPDATE till_surplus SET status = 'kept', decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [user.name, now, txt(note) || null, now, dev, uid]);
    audit({ user, action: `Till over ${$(s.amount)} (${s.name}, ${s.shift_date}) kept by the business`, table: 'till_surplus', recordUid: uid, reason: txt(note) || undefined });
  } else if (action === 'set_off') {
    const sh = db().get('SELECT * FROM till_shortages WHERE uid = ?', [shortageUid || '']);
    need(sh && ['waiting', 'disagreed'].includes(sh.status), 'Choose a shortage that is not decided yet.');
    need(sh.user_uid === s.user_uid || top(user), 'Only the owner or admin can set it against another cashier\'s shortage.');
    const use = r2(Math.min(s.amount, sh.amount));
    const left = r2(sh.amount - use);
    db().transaction(() => {
      db().run(`UPDATE till_shortages SET amount = ?, status = ?, set_off_from = ?, decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
        [left > 0.004 ? left : sh.amount, left > 0.004 ? sh.status : 'set_off', uid, left > 0.004 ? sh.decided_by_name : user.name, left > 0.004 ? sh.decided_at : now, left > 0.004 ? sh.decision_note : `Set against the surplus of ${s.shift_date}`, now, dev, sh.uid]);
      if (left <= 0.004) db().run(`UPDATE till_counts SET short_action = 'set_off', short_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`Set against the surplus of ${s.shift_date}`, now, dev, sh.count_uid]);
      db().run(`UPDATE till_surplus SET status = 'set_off', set_off_uid = ?, set_off_amount = ?, decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
        [sh.uid, use, user.name, now, txt(note) || (use < s.amount ? `${$(s.amount - use)} more than the shortage – kept` : null), now, dev, uid]);
    });
    audit({ user, action: `Till over ${$(s.amount)} (${s.name}, ${s.shift_date}) set against the shortage of ${sh.shift_date} (${$(use)})`, table: 'till_surplus', recordUid: uid, reason: txt(note) || undefined });
  } else {
    needReason(user, note, 'Write who it was given back to and why.');
    const amt = amount === undefined || amount === '' || amount === null ? s.amount : r2(amount);
    need(amt > 0 && amt <= s.amount + 0.004, `Up to ${$(s.amount)}.`);
    const S = require('./service.js');
    need(S.cashOnHand(s.shop_code).onHand + 0.004 >= amt, 'There is not that much cash recorded at this shop.');
    let cashUid = null;
    db().transaction(() => {
      cashUid = S.addCashMove({ shopCode: s.shop_code, date: dateStr(), type: 'adjust_out', amount: amt, refUid: uid, category: 'Till over given back', note: `Till over ${s.shift_date} given back – ${txt(note)}`, user });
      db().run(`UPDATE till_surplus SET status = 'returned', returned_amount = ?, cash_uid = ?, decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
        [amt, cashUid, user.name, now, txt(note) || null, now, dev, uid]);
    });
    audit({ user, action: `Till over ${$(s.amount)} (${s.name}, ${s.shift_date}): ${$(amt)} given back`, table: 'till_surplus', recordUid: uid, reason: txt(note) || undefined });
    try { require('../verify/service.js').notify('till_short', `Till over ${$(s.amount)} (${s.name}, ${s.shift_date}): ${$(amt)} given back by ${user.name} – ${txt(note)}`, { shopCode: s.shop_code }); } catch (e) { /* only a message */ }
  }
  return getSurplus(uid);
  });
}
// Cashiers over 3+ times in 30 days (often change not given, or sales not rung up).
export function repeatOvers({ days = 30, times = 3, today = dateStr() } = {}) {
  const [y, m, d] = today.split('-').map(Number);
  const from = dateStr(new Date(y, m - 1, d - days));
  const per = {};
  listSurpluses({ from, to: today, limit: 100000 }).forEach((s) => {
    const k = s.user_uid || s.name;
    const p = (per[k] = per[k] || { name: s.name, uid: s.user_uid, times: 0, amount: 0 });
    p.times += 1; p.amount = r2(p.amount + s.amount);
  });
  return Object.values(per).filter((p) => p.times >= times).sort((a, b) => b.amount - a.amount);
}

// ---------------------------------------------------------------- shortage paid now
// The cashier pays the shortage (or part of it) in cash there and then and signs. The cash goes into the shop's cash;
// the rest (if any) still waits for the cashier to agree – it is taken from pay as before.
export function payShortageNow(user, uid, { amount, signature, note } = {}) {
  requirePerm(user, 'till_approve', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  requireShop(user, shopOf('till_shortages', uid)); // 1.0.0 hardening (H1): own shop only
  return asService(() => {
  const sh = db().get('SELECT * FROM till_shortages WHERE uid = ?', [uid]);
  need(sh && ['waiting', 'disagreed'].includes(sh.status), 'This shortage is not waiting – it is already decided.');
  need(supervisor(user), 'A supervisor, the owner or admin takes the money and records it.');
  need(user.uid !== sh.user_uid || top(user), 'Someone else must take the money from the cashier.');
  need(txt(signature), `${sh.name} must sign for the money paid.`);
  const amt = amount === undefined || amount === '' || amount === null ? r2(sh.amount) : r2(amount);
  need(amt > 0 && amt <= sh.amount + 0.004, `Enter the amount paid (up to ${$(sh.amount)}).`);
  const left = r2(sh.amount - amt);
  const { now, dev } = meta();
  const S = require('./service.js');
  let cashUid = null;
  db().transaction(() => {
    cashUid = S.addCashMove({ shopCode: sh.shop_code, date: dateStr(), type: 'adjust_in', amount: amt, refUid: uid, category: 'Till shortage repaid', note: `${sh.name} paid the till shortage of ${sh.shift_date}${txt(note) ? ` – ${txt(note)}` : ''}`, user });
    db().run(`UPDATE till_shortages SET amount = ?, status = ?, paid_now = ?, paid_now_at = ?, paid_now_sig = ?, paid_cash_uid = ?, paid_now_by = ?, decided_by_name = ?, decided_at = ?, decision_note = ?,
      updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [left > 0.004 ? left : sh.amount, left > 0.004 ? sh.status : 'paid', r2((Number(sh.paid_now) || 0) + amt), now, signature, cashUid, user.name,
      left > 0.004 ? sh.decided_by_name : user.name, left > 0.004 ? sh.decided_at : now, left > 0.004 ? sh.decision_note : `Paid in cash by ${sh.name}`, now, dev, uid]);
    if (left <= 0.004) db().run(`UPDATE till_counts SET short_action = 'paid', short_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`Paid in cash by ${sh.name} (${$(amt)})`, now, dev, sh.count_uid]);
  });
  audit({ user, action: `${sh.name} paid ${$(amt)} of the till shortage of ${sh.shift_date} in cash${left > 0.004 ? ` – ${$(left)} still to be taken from pay` : ' – paid in full'}`, table: 'till_shortages', recordUid: uid, reason: txt(note) || undefined });
  return { paid: amt, left: left > 0.004 ? left : 0, shortage: db().get('SELECT * FROM till_shortages WHERE uid = ?', [uid]), cashUid };
  });
}
