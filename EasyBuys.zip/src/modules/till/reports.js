// Till & cash reports.
import { stamp } from '../../services/core.js';
import { listShops } from '../admin/service.js';
import * as T from './service.js';

const { $, r2 } = T;
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});

export const REPORTS = [
  { id: 'till_counts', group: 'Till & cash', icon: '🧮', title: 'Till counts', desc: 'Every count: Z report, counted, over / short, reasons', perm: 'till_approve',
    build(from, to) {
      const list = T.listTillCounts({ from, to, limit: 5000 }).slice().reverse();
      const rows = list.map((c) => ({ date: c.shift_date, shop: c.shop_code, till: c.till_name, shift: c.shift, cashier: c.cashier_name, z: c.z_number || '', ztotal: c.z_total == null ? '' : $(c.z_total), zcash: $(c.z_cash),
        expected: $(c.expected_cash), counted: $(c.cash_counted), diff: $(c.over_short), reason: c.reason || '', status: c.status === 'approved' ? `✓ ${c.approved_by_name}` : c.status, _tone: c.over_short < -0.004 ? 'bad' : c.over_short > 0.004 ? 'warn' : null }));
      const per = {};
      list.forEach((c) => { const p = (per[c.cashier_name] = per[c.cashier_name] || { name: c.cashier_name, n: 0, short: 0, over: 0 }); p.n += 1; if (c.over_short < 0) p.short += c.over_short; else p.over += c.over_short; });
      return base('till_counts', 'Till Counts', from, to, {
        summary: [{ label: 'Counts', value: String(list.length) }, { label: 'Total short', value: $(list.filter((c) => c.over_short < 0).reduce((s, c) => s + c.over_short, 0)), tone: 'bad' },
          { label: 'Total over', value: $(list.filter((c) => c.over_short > 0).reduce((s, c) => s + c.over_short, 0)) }, { label: 'Not approved', value: String(list.filter((c) => c.status !== 'approved').length) }],
        sections: [{ title: 'By cashier', columns: [col('name', 'Cashier'), col('n', 'Counts', R), col('short', 'Short', R), col('over', 'Over', R)], rows: Object.values(per).map((p) => ({ name: p.name, n: p.n, short: $(p.short), over: $(p.over), _tone: p.short < -0.004 ? 'bad' : null })) },
          { title: 'Counts', columns: [col('date', 'Date'), col('shop', 'Shop'), col('till', 'Till'), col('shift', 'Shift'), col('cashier', 'Cashier'), col('z', 'Z no'), col('ztotal', 'Z total', R), col('zcash', 'Z cash', R),
            col('expected', 'Should be', R), col('counted', 'Counted', R), col('diff', 'Over/short', R), col('reason', 'Reason'), col('status', 'Approved')], rows }],
      });
    } },
  { id: 'till_sales', group: 'Till & cash', icon: '🧾', title: 'Sales from Z reports', desc: 'Daily sales by shop and payment type (as typed from the Z reports)', perm: 'till_approve',
    build(from, to) {
      const list = T.listTillCounts({ from, to, limit: 5000 });
      const types = new Set();
      const days = {};
      list.forEach((c) => {
        const k = `${c.shift_date}|${c.shop_code}`;
        const d = (days[k] = days[k] || { date: c.shift_date, shop: c.shop_code, total: 0, cash: 0 });
        d.total += Number(c.z_total) || 0; d.cash += c.z_cash;
        JSON.parse(c.tenders || '[]').forEach((t) => { types.add(t.method); d[t.method] = (d[t.method] || 0) + t.amount; });
      });
      const tlist = Array.from(types);
      const rows = Object.values(days).sort((a, b) => (a.date + a.shop < b.date + b.shop ? -1 : 1)).map((d) => {
        const r = { date: d.date, shop: d.shop, total: $(d.total), cash: $(d.cash) };
        tlist.forEach((t) => { r[t] = $(d[t] || 0); });
        return r;
      });
      return base('till_sales', 'Sales From Z Reports', from, to, {
        summary: [{ label: 'Sales', value: $(Object.values(days).reduce((s, d) => s + d.total, 0)) }, { label: 'Cash', value: $(Object.values(days).reduce((s, d) => s + d.cash, 0)) }],
        sections: [{ title: 'By day and shop', columns: [col('date', 'Date'), col('shop', 'Shop'), col('total', 'Total sales', R), col('cash', 'Cash', R)].concat(tlist.map((t) => col(t, t, R))), rows,
          note: 'From the Z reports typed in at each till count. Aronium figures will be compared here once the main software is linked.' }],
      });
    } },
  { id: 'cash_on_hand', group: 'Till & cash', icon: '💵', title: 'Cash on hand', desc: 'Cash at each shop and how it moved', perm: 'deposits',
    build(from, to) {
      const shops = listShops().filter((s) => s.active);
      const rows = shops.map((s) => { const c = T.cashOnHand(s.code, to); return { shop: s.name, safe: $(c.onHand), floats: $(c.floats), total: $(c.total) }; });
      const moves = T.listCashMoves({ from, to, limit: 5000 }).reverse().map((m) => ({ date: m.move_date, shop: m.shop_code, what: T.MOVE_LABEL[m.type], cat: m.category || '', note: m.note || '', by: m.by_name || '',
        amount: `${['opening', 'from_till', 'petty_in', 'transfer_in', 'adjust_in'].includes(m.type) ? '+' : '−'}${$(m.amount)}` }));
      return base('cash_on_hand', 'Cash On Hand', from, to, {
        summary: [{ label: 'Total cash at shops', value: $(shops.reduce((s, x) => s + T.cashOnHand(x.code, to).total, 0)) }],
        sections: [{ title: `At ${to}`, columns: [col('shop', 'Shop'), col('safe', 'Safe / office', R), col('floats', 'Till floats', R), col('total', 'Total', R)], rows },
          { title: 'Movements', columns: [col('date', 'Date'), col('shop', 'Shop'), col('what', 'What'), col('cat', 'Category'), col('note', 'Note'), col('by', 'By'), col('amount', 'Amount', R)], rows: moves }],
      });
    } },
  { id: 'deposits', group: 'Till & cash', icon: '🏦', title: 'Bank deposits', desc: 'Every deposit: slip, cash, cheques, who banked it', perm: 'deposits',
    build(from, to) {
      const list = T.listDeposits({ from, to, includeVoid: true }).reverse();
      const rows = list.map((d) => ({ date: d.deposit_date, shop: d.shop_code, slip: d.slip_no, acct: d.account_name || '', cash: $(d.cash_amount), chq: $(d.cheque_amount), total: $(d.total), by: d.deposited_by_name,
        takings: d.takings_from ? `${d.takings_from}${d.takings_to && d.takings_to !== d.takings_from ? ` – ${d.takings_to}` : ''}` : '', stmt: d.status === 'void' ? `VOID: ${d.void_reason}` : d.cleared_date || 'not yet', _tone: d.status === 'void' ? 'warn' : d.cleared_date ? null : 'warn' }));
      const live = list.filter((d) => d.status === 'active');
      return base('deposits', 'Bank Deposits', from, to, {
        summary: [{ label: 'Deposited', value: $(live.reduce((s, d) => s + d.total, 0)) }, { label: 'Deposits', value: String(live.length) }, { label: 'Not on a statement yet', value: String(live.filter((d) => !d.cleared_date).length) }],
        sections: [{ title: 'Deposits', columns: [col('date', 'Date'), col('shop', 'Shop'), col('slip', 'Slip'), col('acct', 'Account'), col('cash', 'Cash', R), col('chq', 'Cheques', R), col('total', 'Total', R), col('by', 'Banked by'), col('takings', 'Takings'), col('stmt', 'On statement')], rows }],
      });
    } },
  { id: 'petty_cash', group: 'Till & cash', icon: '🪙', title: 'Petty cash', desc: 'Petty cash spent by shop and category', perm: 'deposits',
    build(from, to) {
      const list = T.listCashMoves({ from, to, limit: 5000 }).filter((m) => m.type === 'petty_out').reverse();
      const cats = {};
      list.forEach((m) => { cats[m.category || 'Other'] = r2((cats[m.category || 'Other'] || 0) + m.amount); });
      return base('petty_cash', 'Petty Cash', from, to, {
        summary: [{ label: 'Spent', value: $(list.reduce((s, m) => s + m.amount, 0)) }],
        sections: [{ title: 'By category', columns: [col('cat', 'Category'), col('amount', 'Amount', R)], rows: Object.entries(cats).map(([cat, a]) => ({ cat, amount: $(a) })) },
          { title: 'Spending', columns: [col('date', 'Date'), col('shop', 'Shop'), col('cat', 'Category'), col('note', 'What'), col('by', 'By'), col('amount', 'Amount', R)],
            rows: list.map((m) => ({ date: m.move_date, shop: m.shop_code, cat: m.category || '', note: m.note || '', by: m.by_name || '', amount: $(m.amount) })) }],
      });
    } },
];
