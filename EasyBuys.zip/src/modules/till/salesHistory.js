// v1.0.0 Sales history: every day's sales per shop and till, from Aronium (the till PCs, through the Aronium link),
// with the End of day figures (VAT, cash, receipts) when there is one, and a day's detail: products sold, sales by
// hour and per cashier. Each shop separately or both together, any period. Read only.
import { db } from '../../db/connection.js';
import { dateStr, addDays } from '../../services/core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ok = (d) => /^\d{4}-\d{2}-\d{2}$/.test(String(d || ''));
const L = () => safe(() => require('../aronium/link.js'), null);

// Day by day: [{ date, day, total, shops: { S1: { value, tills: { 'S1-T1': v }, eod: {total, vat, cash, receipts} } }, receipts }]
export function salesHistory({ from, to = dateStr(), shop = '' } = {}) {
  if (!ok(to)) to = dateStr();
  if (!ok(from)) from = addDays(to, -30);
  const map = new Map();
  const get = (d) => map.get(d) || map.set(d, { date: d, day: DAYS[new Date(`${d}T12:00:00`).getDay()], total: 0, shops: {}, receipts: 0, fromTill: false }).get(d);
  for (const x of (L() ? safe(() => L().aroniumSalesByDay({ from }), []) : [])) {
    if (x.date > to || (shop && x.shop !== shop)) continue;
    const o = get(x.date);
    const s = o.shops[x.shop] || (o.shops[x.shop] = { value: 0, tills: {}, eod: null });
    s.value = r2(s.value + x.value); s.tills[x.source] = r2((s.tills[x.source] || 0) + x.value);
    o.total = r2(o.total + x.value); o.fromTill = true;
  }
  // End of day (Aronium Z) figures: VAT, cash, receipts – and the sales for days the till PCs did not send
  if (has('aronium_eods')) {
    for (const e of safe(() => db().all("SELECT eod_date AS d, shop_code AS s, SUM(total) AS t, SUM(vat) AS v, SUM(cash) AS c, SUM(IFNULL(card,0)+IFNULL(other,0)) AS o, COUNT(*) AS n FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ? GROUP BY eod_date, shop_code", [from, to]), [])) {
      if (shop && e.s !== shop) continue;
      const o = get(e.d);
      const s = o.shops[e.s] || (o.shops[e.s] = { value: 0, tills: {}, eod: null });
      s.eod = { total: r2(e.t), vat: r2(e.v), cash: r2(e.c), other: r2(e.o), ends: e.n };
      if (!s.value) { s.value = r2(e.t); o.total = r2(o.total + e.t); }
    }
  }
  for (const z of (L() ? safe(() => L().aroniumZByDay({ from }), []) : [])) {
    if (z.date > to || (shop && z.shop !== shop) || !map.has(z.date)) continue;
    map.get(z.date).receipts += Number(z.receipts) || 0;
  }
  const days = [...map.values()].sort((a, b) => (a.date < b.date ? 1 : -1));
  const total = r2(days.reduce((s, d) => s + d.total, 0));
  const best = days.reduce((b, d) => (!b || d.total > b.total ? d : b), null);
  return { from, to, shop: shop || null, days, total, perDay: days.length ? r2(total / days.length) : 0, best,
    shops: [...new Set(days.flatMap((d) => Object.keys(d.shops)))].sort() };
}

// One day: products sold (both tills added up), sales by hour, per cashier.
export function salesDay(date, { shop = '' } = {}) {
  if (!ok(date)) date = dateStr();
  const lines = new Map();
  for (const x of (L() ? safe(() => L().aroniumSalesByDay({ from: date, withLines: true }), []) : [])) {
    if (x.date !== date || (shop && x.shop !== shop)) continue;
    for (const l of x.lines || []) {
      const k = `${x.shop}|${l.code || l.name}`;
      const o = lines.get(k) || { shop: x.shop, code: l.code, name: l.name, qty: 0, value: 0 };
      o.qty = r2(o.qty + (Number(l.net) || 0)); o.value = r2(o.value + (Number(l.sold_value) || 0) - (Number(l.refund_value) || 0));
      lines.set(k, o);
    }
  }
  const hours = {}; const cashiers = {};
  if (has('aronium_feed')) {
    for (const r of safe(() => db().all("SELECT source, data FROM aronium_feed WHERE kind = 'activity' AND period = ?", [date]), [])) {
      const sh = String(r.source).split('-')[0];
      if (shop && sh !== shop) continue;
      const a = J(r.data, {});
      for (const [hh, x] of Object.entries(a.hours || {})) { const h = hours[hh] || (hours[hh] = { value: 0, receipts: 0 }); h.value = r2(h.value + (Number(x.value) || 0)); h.receipts += Number(x.receipts) || 0; }
      for (const [n, c] of Object.entries(a.cashiers || {})) { const o = cashiers[n] || (cashiers[n] = { name: n, sales: 0, receipts: 0, refunds: 0, voids: 0 }); o.sales = r2(o.sales + (Number(c.sales) || 0)); o.receipts += Number(c.receipts) || 0; o.refunds += Number(c.refunds) || 0; o.voids += Number(c.voids) || 0; }
    }
  }
  const products = [...lines.values()].sort((a, b) => b.value - a.value);
  // live: each receipt (newest first), how the money came in, refunds, and what should be in each till now
  const receipts = L() ? safe(() => L().aroniumReceipts({ date, shop }), []) : [];
  const payments = {}; const refunds = receipts.filter((x) => x.refund);
  for (const x of receipts) {
    const ways = x.pays.length ? x.pays : [{ name: x.pay || 'Not known', amount: x.total }];
    for (const p of ways) payments[p.name] = r2((payments[p.name] || 0) + (x.refund ? -p.amount : p.amount));
  }
  const sold = receipts.filter((x) => !x.refund);
  return { date, shop: shop || null, products, total: r2(products.reduce((s, p) => s + p.value, 0)),
    hours: Object.keys(hours).sort().map((h) => ({ hour: h, ...hours[h] })), cashiers: Object.values(cashiers).sort((a, b) => b.sales - a.sales),
    receipts, live: { receipts: sold.length, sales: r2(sold.reduce((t, x) => t + x.total, 0)), refunds: refunds.length, refundValue: r2(refunds.reduce((t, x) => t + x.total, 0)),
      net: r2(sold.reduce((t, x) => t + x.total, 0) - refunds.reduce((t, x) => t + x.total, 0)), last: receipts.length ? receipts[0].time.slice(0, 5) : null,
      payments: Object.entries(payments).map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount) },
    drawers: date === dateStr() && L() ? safe(() => L().tillDrawer({ date, shop }), []) : [] };
}

export function salesHistoryReport(from, to, user, params = {}) {
  const h = salesHistory({ from, to, shop: (params && params.shop) || '' });
  const $ = (n) => `$${(Number(n) || 0).toFixed(2)}`;
  const col = (key, title, align = 'left') => ({ key, title, align });
  return {
    kind: 'sales_history', title: 'Sales History', fileName: `Sales-history-${from}-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}${h.shop ? ` · ${h.shop}` : ''}`,
    info: [['From', from], ['To', to], ['Shop', h.shop || 'Both shops']],
    summary: [{ label: 'Sales', value: $(h.total) }, { label: 'Per trading day', value: $(h.perDay) }].concat(h.best ? [{ label: 'Best day', value: `${h.best.day} ${h.best.date} ${$(h.best.total)}` }] : []),
    sections: [{ title: 'Day by day', columns: [col('date', 'Date'), col('day', 'Day')].concat(h.shops.map((s) => col(s, s, 'right'))).concat([col('total', 'Total', 'right'), col('vat', 'VAT (End of day)', 'right'), col('receipts', 'Receipts', 'right')]),
      rows: h.days.map((d) => ({ date: d.date, day: d.day, ...Object.fromEntries(h.shops.map((s) => [s, d.shops[s] ? $(d.shops[s].value) : ''])), total: $(d.total),
        vat: $(Object.values(d.shops).reduce((t, s) => t + (s.eod ? s.eod.vat : 0), 0)), receipts: d.receipts || '' })) }],
  };
}
export const SALES_REPORTS = [
  { id: 'till_sales_history', group: 'Till & cash', icon: '📈', title: 'Sales history', desc: 'Sales day by day for each shop and both together, with VAT and receipts (from the till PCs and End of days)', perm: 'reports', build: salesHistoryReport },
];
