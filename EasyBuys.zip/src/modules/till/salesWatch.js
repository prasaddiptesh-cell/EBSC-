// 1.0.0 Sales watch, live from the till PCs (Aronium Link):
//   • a till has started for the day (its first sale) – a notification to the managers and the owner;
//   • no sales for a while (default 60 minutes) while the shop is open (its opening hours on the shop page);
//   • sales rung up while the shop is closed (outside its opening hours).
// Read only. Uses the receipts the till PCs send (to the minute) or, from an older Aronium Link, its sales by hour.
import { db, keepTracked } from '../../db/connection.js';
import { getShared, setShared, audit, AppError, clock, dateStr, addDays, realFromWall, wallFromReal } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };
const L = () => require('../aronium/link.js');
const SP = () => require('../../services/shopProfile.js');
const pad = (n) => String(n).padStart(2, '0');
const hm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const at = (date, t) => { const d = new Date(`${date}T${String(t).slice(0, 5)}:00`); return Number.isFinite(d.getTime()) ? d : null; };
const parseSeen = (s) => { const x = String(s || ''); const t = Date.parse(/Z$/.test(x) ? x : `${x.replace(' ', 'T').slice(0, 19)}Z`); return Number.isFinite(t) ? t : null; };

export const QUIET_CHOICES = [0, 30, 45, 60, 90, 120];
export function salesWatchSettings() {
  const s = getShared('sales_watch', null) || {};
  const q = Number(s.quietMins);
  return { quietMins: QUIET_CHOICES.includes(q) ? q : 60, started: s.started !== false, afterHours: s.afterHours !== false };
}
export function saveSalesWatch(user, { quietMins, started, afterHours } = {}) {
  requirePerm(user, ['settings', 'till_approve']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner changes the sales watch.');
  const q = Number(quietMins);
  need(QUIET_CHOICES.includes(q), 'Choose how long without a sale (or Off).');
  const before = salesWatchSettings();
  const after = { quietMins: q, started: started !== false, afterHours: afterHours !== false };
  setShared('sales_watch', after);
  audit({ user, action: `Sales watch: ${q ? `no sales for ${q} min while open` : 'no-sales warning off'}, till started ${after.started ? 'on' : 'off'}, after hours ${after.afterHours ? 'on' : 'off'}`, table: 'shared_settings', recordUid: 'sales_watch', before, after });
  return after;
  });
}

function shops() {
  return safe(() => db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY code'), [])
    .map((s) => ({ code: s.code, name: s.name || s.code, hours: safe(() => SP().getShop(s.code).hours, null) }));
}
// Today's opening time for a shop (null when not set or closed today / open from last night only).
function openedAt(hours, now) {
  const o = safe(() => SP().openNow(hours, now), { open: false });
  if (!o || !o.open) return { open: false, known: !!(o && o.known) };
  const days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const h = safe(() => SP().normHours(hours), {});
  const d = h[days[now.getDay()]] || null;
  const t = hm(now);
  if (!d || !d.open || t < d.open) return { open: true, opened: null, until: o.until }; // still open from last night
  return { open: true, opened: d.open, until: o.until };
}

// Everything at once (for Home warnings, the watchdog and the Sales history screen).
export function salesWatch({ now = clock.now(), date } = {}) {
  const today = date || dateStr(now);
  const cfg = salesWatchSettings();
  const tills = safe(() => L().tillDay(today), []);
  const started = tills.filter((t) => t.first).map((t) => ({ ...t, id: `${t.source}-${today}` }));
  const quiet = []; const afterHours = [];
  for (const s of shops()) {
    const mine = tills.filter((t) => t.shop === s.code);
    if (!mine.length) continue; // no till PC sends for this shop: nothing to watch
    const o = openedAt(s.hours, now);
    if (cfg.quietMins && o.open && o.opened) {
      const openT = at(today, o.opened);
      const lastSale = mine.map((t) => t.last).filter(Boolean).sort().pop() || null;
      const since = lastSale ? at(today, lastSale) : openT;
      const mins = since ? Math.floor((now.getTime() - Math.max(since.getTime(), openT ? openT.getTime() : 0)) / 60000) : 0;
      if (openT && now.getTime() - openT.getTime() >= cfg.quietMins * 60000 && mins >= cfg.quietMins) {
        const seen = mine.map((t) => parseSeen(t.lastSeen)).filter((x) => x !== null).sort().pop() || null;
        const pcQuiet = seen === null || realFromWall(now) - seen > Math.max(cfg.quietMins, 30) * 60000;
        quiet.push({ shop: s.code, name: s.name, lastSale, opened: o.opened, mins, pcQuiet, lastSeen: seen ? new Date(seen).toISOString() : null });
      }
    }
    if (cfg.afterHours && s.hours) {
      const rc = safe(() => L().aroniumReceipts({ date: today, shop: s.code }), []);
      // 1.0.0 the opening hours are looked at once per minute of the day (not once per receipt)
      const closedAt = new Map();
      const closed = (r) => {
        const k = String(r.time).slice(0, 5);
        if (!closedAt.has(k)) { const d = at(today, r.time); const x = d ? safe(() => SP().openNow(s.hours, d), null) : null; closedAt.set(k, !!d && !!x && x.known !== false && x.open === false); }
        return closedAt.get(k);
      };
      const out = rc.filter(closed);
      if (out.length) afterHours.push({ shop: s.code, name: s.name, date: today, receipts: out.length, total: Math.round(out.reduce((t, r) => t + r.total, 0) * 100) / 100, first: out[out.length - 1].time.slice(0, 5), last: out[0].time.slice(0, 5), who: [...new Set(out.map((r) => r.who).filter(Boolean))] });
    }
  }
  return { date: today, settings: cfg, tills, started, quiet, afterHours };
}

// Sales rung up while the shop was closed, over the last days (for the watchdog).
// round 2: each day kept until that day's receipts (or the shops, their hours, the settings) change – a new sale only
// works out today again. The same as salesWatch(...).afterHours for each day.
export function afterHoursSales({ days = 7, today = dateStr() } = {}) {
  const out = [];
  for (let i = 0; i < days; i += 1) {
    const d = addDays(today, -i);
    out.push(...keepTracked(`sw|after|${d}`, () => afterHoursOn(d)));
  }
  return out;
}
// One day of afterHoursSales worked out ahead (Home's background collection: one day per part).
export function warmAfterHours(daysBack, today = dateStr()) { const d = addDays(today, -daysBack); safe(() => keepTracked(`sw|after|${d}`, () => afterHoursOn(d)), null); return []; }
function afterHoursOn(today) {
  const cfg = salesWatchSettings();
  const out = [];
  if (!cfg.afterHours) return out;
  for (const s of shops()) {
    if (!s.hours) continue;
    // a shop with no till PC has no receipts: nothing (as salesWatch, which skips it)
    const rc = safe(() => L().aroniumReceipts({ date: today, shop: s.code }), []);
    const closedAt = new Map();
    const closed = (r) => {
      const k = String(r.time).slice(0, 5);
      if (!closedAt.has(k)) { const d = at(today, r.time); const x = d ? safe(() => SP().openNow(s.hours, d), null) : null; closedAt.set(k, !!d && !!x && x.known !== false && x.open === false); }
      return closedAt.get(k);
    };
    const hit = rc.filter(closed);
    if (hit.length) out.push({ shop: s.code, name: s.name, date: today, receipts: hit.length, total: Math.round(hit.reduce((t, r) => t + r.total, 0) * 100) / 100, first: hit[hit.length - 1].time.slice(0, 5), last: hit[0].time.slice(0, 5), who: [...new Set(hit.map((r) => r.who).filter(Boolean))] });
  }
  return out;
}

const mins = (m) => (m >= 120 ? `${Math.floor(m / 60)} h ${m % 60 ? `${m % 60} min` : ''}`.trim() : `${m} min`);
// The Home warnings (and the phone notifications that go with them).
export function salesWatchAlerts({ now = clock.now() } = {}) {
  const w = salesWatch({ now });
  const out = [];
  if (w.settings.started) {
    for (const t of w.started) {
      const first = at(w.date, t.first);
      if (!first || now.getTime() - first.getTime() > 90 * 60000) continue; // only the first hour and a half
      out.push({ id: `till-started-${t.id}`, level: 'info', notify: true, text: `${t.till} has started – first sale ${t.exact ? 'at' : 'about'} ${t.first}`,
        sub: `${t.receipts} receipt${t.receipts === 1 ? '' : 's'} so far · live in Sales & tills › Sales history`, nav: { screen: 'SalesDay', params: { date: w.date, shop: t.shop } } });
    }
  }
  for (const q of w.quiet) {
    if (q.pcQuiet) continue; // the till PC itself is quiet: the "till PC not sending" warning says so (linkWatchAlerts)
    out.push({ id: `till-no-sales-${q.shop}-${w.date}-${q.lastSale || 'none'}`, level: 'warning', notify: true,
      text: q.lastSale ? `No sales at ${q.name} for ${mins(q.mins)} (last at ${q.lastSale})` : `No sales at ${q.name} yet – open since ${q.opened}`,
      sub: q.pcQuiet ? 'The till PC has not sent either – is it on, and the internet working?' : 'The shop is open. Is the till being used? Anything wrong at the shop?',
      nav: { screen: 'SalesDay', params: { date: w.date, shop: q.shop } } });
  }
  for (const a of w.afterHours) {
    out.push({ id: `till-after-hours-${a.shop}-${a.date}-${a.receipts}`, level: 'warning', notify: true,
      text: `${a.receipts} sale${a.receipts === 1 ? '' : 's'} at ${a.name} while the shop was closed (${a.first}${a.first !== a.last ? `–${a.last}` : ''}, $${a.total.toFixed(2)})`,
      sub: `${a.who.length ? `By ${a.who.join(', ')}. ` : ''}Outside the opening hours on the shop page – check them.`, nav: { screen: 'SalesDay', params: { date: a.date, shop: a.shop } } });
  }
  return out;
}

// ---------------------------------------------------------------- the Aronium Link itself (tamper / switched off)
// Sending stopped or the Link removed on a till PC (it tells the app first), and a till PC that has gone quiet while
// its shop is open (power, internet, PC off): a warning after 45 minutes, urgent after 2 hours.
export const LINK_QUIET_MINS = 45;
export function linkWatch({ now = clock.now() } = {}) {
  const tills = safe(() => L().linkStatus().tills, []) || [];
  const notices = safe(() => db().all("SELECT source, till, data FROM aronium_feed WHERE kind = 'notice'"), []).map((r) => ({ source: r.source, till: r.till, ...(safe(() => JSON.parse(r.data), {}) || {}) }));
  const off = [];
  const bySource = new Map();
  for (const n of notices) { if (!n.event || !n.at) continue; const m = bySource.get(n.source) || {}; if (!m[n.event] || n.at > m[n.event].at) m[n.event] = n; bySource.set(n.source, m); }
  for (const [source, m] of bySource) {
    const bad = ['uninstalled', 'stopped'].map((e) => m[e]).filter(Boolean).sort((a, b) => (a.at < b.at ? 1 : -1))[0];
    if (!bad || (m.started && m.started.at > bad.at)) continue;
    const age = realFromWall(now) - (Date.parse(bad.at) || 0); // bad.at is a real (UTC) instant; now a Fiji wall time
    if (age > 14 * 86400000) continue; // a till taken out of use long ago
    off.push({ source, shop: String(source).split('-')[0], till: bad.till || source, event: bad.event, at: bad.at, who: bad.who || '', pc: bad.pc || '' });
  }
  const quiet = [];
  const shopList = shops();
  for (const t of tills) {
    if (off.some((o) => o.source === t.source)) continue;
    const s = shopList.find((x) => x.code === t.shop);
    if (!s || !s.hours) continue;
    const o = openedAt(s.hours, now);
    if (!o.open || !o.opened) continue;
    const openT = at(dateStr(now), o.opened);
    const seenReal = parseSeen(t.lastSeen);
    if (!openT || seenReal === null) continue;
    const seen = wallFromReal(seenReal).getTime(); // the till PC's real instant as Fiji wall time, like now and openT
    const mins = Math.floor((now.getTime() - Math.max(seen, openT.getTime())) / 60000);
    if (mins >= LINK_QUIET_MINS) quiet.push({ source: t.source, shop: t.shop, name: s.name, till: t.till, mins, lastSeen: new Date(seenReal), level: mins >= 120 ? 'urgent' : 'warning' });
  }
  return { off, quiet };
}
const when = (iso) => { const d = new Date(iso); return Number.isFinite(d.getTime()) ? `${dateStr(d)} ${hm(d)}` : String(iso || '').slice(0, 16); };
export function linkWatchAlerts({ now = clock.now() } = {}) {
  const w = linkWatch({ now });
  const out = [];
  for (const o of w.off) {
    out.push({ id: `till-link-off-${o.source}-${o.at}`, level: 'urgent', notify: true,
      text: `${o.till}: the Aronium Link was ${o.event === 'uninstalled' ? 'REMOVED' : 'switched off'} (${when(o.at)})`,
      sub: `${o.who ? `Windows user ${o.who}${o.pc ? ` on ${o.pc}` : ''}. ` : ''}This till's sales are not coming to the app. If it was not you, check the till PC; turn it back on with "Send on its own" (Link PIN).`,
      nav: { screen: 'AroniumLink', params: {} } });
  }
  for (const q of w.quiet) {
    out.push({ id: `till-pc-quiet-${q.source}-${dateStr(now)}-${q.level}`, level: q.level, notify: true,
      text: `${q.till} has not sent anything for ${q.mins >= 120 ? `${Math.floor(q.mins / 60)} h` : `${q.mins} min`} while ${q.name} is open`,
      sub: 'Is the till PC on, and is the internet working? Sales on it are not being seen.', nav: { screen: 'AroniumLink', params: {} } });
  }
  return out;
}
export function hoursKnown(shopCode) { const s = shops().find((x) => x.code === shopCode); return !!(s && s.hours && Object.values(s.hours).some((d) => d && (d.closed || (d.open && d.close)))); }
