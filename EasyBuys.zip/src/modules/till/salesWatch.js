// 1.0.0 Sales watch, live from the till PCs (Aronium Link):
//   • a till has started for the day (its first sale) – a notification to the managers and the owner;
//   • no sales for a while (default 60 minutes) while the shop is open (its opening hours on the shop page);
//   • sales rung up while the shop is closed (outside its opening hours).
// Read only. Uses the receipts the till PCs send (to the minute) or, from an older Aronium Link, its sales by hour.
import { db } from '../../db/connection.js';
import { getShared, setShared, audit, AppError, clock, dateStr, addDays } from '../../services/core.js';

const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const need = (c, m) => { if (!c) throw new AppError(m); };
const L = () => require('../aronium/link.js');
const SP = () => require('../../services/shopProfile.js');
const pad = (n) => String(n).padStart(2, '0');
const hm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const at = (date, t) => { const d = new Date(`${date}T${String(t).slice(0, 5)}:00`); return Number.isFinite(d.getTime()) ? d : null; };
const parseSeen = (s) => { const x = String(s || ''); const t = Date.parse(/Z$/.test(x) ? x : `${x.replace(' ', 'T').slice(0, 19)}Z`); return Number.isFinite(t) ? t : null; };

export const QUIET_CHOICES = [0, 30, 45, 60, 90, 120];
export function salesWatchSettings() {
  const s = getShared('sales_watch', null) || {};
  const q = Number(s.quietMins);
  return { quietMins: QUIET_CHOICES.includes(q) ? q : 60, started: s.started !== false, afterHours: s.afterHours !== false };
}
export function saveSalesWatch(user, { quietMins, started, afterHours } = {}) {
  need(user && (['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)), 'Only a manager, the admin or the owner changes the sales watch.');
  const q = Number(quietMins);
  need(QUIET_CHOICES.includes(q), 'Choose how long without a sale (or Off).');
  const before = salesWatchSettings();
  const after = { quietMins: q, started: started !== false, afterHours: afterHours !== false };
  setShared('sales_watch', after);
  audit({ user, action: `Sales watch: ${q ? `no sales for ${q} min while open` : 'no-sales warning off'}, till started ${after.started ? 'on' : 'off'}, after hours ${after.afterHours ? 'on' : 'off'}`, table: 'shared_settings', recordUid: 'sales_watch', before, after });
  return after;
}

function shops() {
  return safe(() => db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY code'), [])
    .map((s) => ({ code: s.code, name: s.name || s.code, hours: safe(() => SP().getShop(s.code).hours, null) }));
}
// Today's opening time for a shop (null when not set or closed today / open from last night only).
function openedAt(hours, now) {
  const o = safe(() => SP().openNow(hours, now), { open: false });
  if (!o || !o.open) return { open: false, known: !!(o && o.known) };
  const days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const h = safe(() => SP().normHours(hours), {});
  const d = h[days[now.getDay()]] || null;
  const t = hm(now);
  if (!d || !d.open || t < d.open) return { open: true, opened: null, until: o.until }; // still open from last night
  return { open: true, opened: d.open, until: o.until };
}

// Everything at once (for Home warnings, the watchdog and the Sales history screen).
export function salesWatch({ now = clock.now(), date } = {}) {
  const today = date || dateStr(now);
  const cfg = salesWatchSettings();
  const tills = safe(() => L().tillDay(today), []);
  const started = tills.filter((t) => t.first).map((t) => ({ ...t, id: `${t.source}-${today}` }));
  const quiet = []; const afterHours = [];
  for (const s of shops()) {
    const mine = tills.filter((t) => t.shop === s.code);
    if (!mine.length) continue; // no till PC sends for this shop: nothing to watch
    const o = openedAt(s.hours, now);
    if (cfg.quietMins && o.open && o.opened) {
      const openT = at(today, o.opened);
      const lastSale = mine.map((t) => t.last).filter(Boolean).sort().pop() || null;
      const since = lastSale ? at(today, lastSale) : openT;
      const mins = since ? Math.floor((now.getTime() - Math.max(since.getTime(), openT ? openT.getTime() : 0)) / 60000) : 0;
      if (openT && now.getTime() - openT.getTime() >= cfg.quietMins * 60000 && mins >= cfg.quietMins) {
        const seen = mine.map((t) => parseSeen(t.lastSeen)).filter((x) => x !== null).sort().pop() || null;
        const pcQuiet = seen === null || now.getTime() - seen > Math.max(cfg.quietMins, 30) * 60000;
        quiet.push({ shop: s.code, name: s.name, lastSale, opened: o.opened, mins, pcQuiet, lastSeen: seen ? new Date(seen).toISOString() : null });
      }
    }
    if (cfg.afterHours && s.hours) {
      const rc = safe(() => L().aroniumReceipts({ date: today, shop: s.code }), []);
      const out = rc.filter((r) => { const d = at(today, r.time); if (!d) return false; const x = safe(() => SP().openNow(s.hours, d), null); return x && x.known !== false && x.open === false; });
      if (out.length) afterHours.push({ shop: s.code, name: s.name, date: today, receipts: out.length, total: Math.round(out.reduce((t, r) => t + r.total, 0) * 100) / 100, first: out[out.length - 1].time.slice(0, 5), last: out[0].time.slice(0, 5), who: [...new Set(out.map((r) => r.who).filter(Boolean))] });
    }
  }
  return { date: today, settings: cfg, tills, started, quiet, afterHours };
}

// Sales rung up while the shop was closed, over the last days (for the watchdog).
export function afterHoursSales({ days = 7, today = dateStr() } = {}) {
  const out = [];
  for (let i = 0; i < days; i += 1) {
    const d = addDays(today, -i);
    const w = salesWatch({ now: at(d, '23:59') || clock.now(), date: d });
    out.push(...w.afterHours);
  }
  return out;
}

const mins = (m) => (m >= 120 ? `${Math.floor(m / 60)} h ${m % 60 ? `${m % 60} min` : ''}`.trim() : `${m} min`);
// The Home warnings (and the phone notifications that go with them).
export function salesWatchAlerts({ now = clock.now() } = {}) {
  const w = salesWatch({ now });
  const out = [];
  if (w.settings.started) {
    for (const t of w.started) {
      const first = at(w.date, t.first);
      if (!first || now.getTime() - first.getTime() > 90 * 60000) continue; // only the first hour and a half
      out.push({ id: `till-started-${t.id}`, level: 'info', notify: true, text: `${t.till} has started – first sale ${t.exact ? 'at' : 'about'} ${t.first}`,
        sub: `${t.receipts} receipt${t.receipts === 1 ? '' : 's'} so far · live in Sales & tills › Sales history`, nav: { screen: 'SalesDay', params: { date: w.date, shop: t.shop } } });
    }
  }
  for (const q of w.quiet) {
    out.push({ id: `till-no-sales-${q.shop}-${w.date}-${q.lastSale || 'none'}`, level: 'warning', notify: true,
      text: q.lastSale ? `No sales at ${q.name} for ${mins(q.mins)} (last at ${q.lastSale})` : `No sales at ${q.name} yet – open since ${q.opened}`,
      sub: q.pcQuiet ? 'The till PC has not sent either – is it on, and the internet working?' : 'The shop is open. Is the till being used? Anything wrong at the shop?',
      nav: { screen: 'SalesDay', params: { date: w.date, shop: q.shop } } });
  }
  for (const a of w.afterHours) {
    out.push({ id: `till-after-hours-${a.shop}-${a.date}-${a.receipts}`, level: 'warning', notify: true,
      text: `${a.receipts} sale${a.receipts === 1 ? '' : 's'} at ${a.name} while the shop was closed (${a.first}${a.first !== a.last ? `–${a.last}` : ''}, $${a.total.toFixed(2)})`,
      sub: `${a.who.length ? `By ${a.who.join(', ')}. ` : ''}Outside the opening hours on the shop page – check them.`, nav: { screen: 'SalesDay', params: { date: a.date, shop: a.shop } } });
  }
  return out;
}
