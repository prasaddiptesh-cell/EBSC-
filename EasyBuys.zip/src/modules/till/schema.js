// Till & cash: end-of-shift till counts (with the Z report), cash held at each shop, bank deposits, petty cash.
export const TILL_SQL = `
CREATE TABLE IF NOT EXISTS tills (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  name TEXT NOT NULL,
  float_amount REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS till_counts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  till_uid TEXT,
  till_name TEXT,
  shift_date TEXT NOT NULL,
  shift TEXT,
  cashier_uid TEXT, cashier_name TEXT,
  counted_by_uid TEXT, counted_by_name TEXT, counted_at TEXT,
  opening_float REAL NOT NULL DEFAULT 0,
  denominations TEXT,
  cash_counted REAL NOT NULL DEFAULT 0,
  float_kept REAL NOT NULL DEFAULT 0,
  z_number TEXT,
  z_total REAL,
  z_cash REAL,
  tenders TEXT,
  payouts TEXT,
  drops REAL NOT NULL DEFAULT 0,
  adjustments TEXT,
  expected_cash REAL,
  over_short REAL,
  reason TEXT,
  notes TEXT,
  photo_urls TEXT,
  status TEXT NOT NULL DEFAULT 'counted' CHECK (status IN ('counted','approved','queried','void')),
  approved_by_name TEXT, approved_at TEXT, approve_note TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_tc_shop ON till_counts(shop_code, shift_date);

-- Cash held at each shop (safe / office): every movement in or out, so cash on hand is always known.
CREATE TABLE IF NOT EXISTS cash_moves (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  move_date TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('opening','from_till','deposit','petty_out','petty_in','transfer_in','transfer_out','adjust_in','adjust_out')),
  amount REAL NOT NULL,
  ref_uid TEXT,
  category TEXT,
  note TEXT,
  photo_urls TEXT,
  by_name TEXT, by_uid TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_cm_shop ON cash_moves(shop_code, move_date);

CREATE TABLE IF NOT EXISTS deposits (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  account_uid TEXT,
  deposit_date TEXT NOT NULL,
  slip_no TEXT,
  branch TEXT,
  cash_amount REAL NOT NULL DEFAULT 0,
  cheque_amount REAL NOT NULL DEFAULT 0,
  cheques TEXT,
  denominations TEXT,
  total REAL NOT NULL,
  takings_from TEXT, takings_to TEXT,
  deposited_by_uid TEXT, deposited_by_name TEXT,
  witness TEXT,
  bank_entry_uid TEXT,
  notes TEXT,
  photo_urls TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','void')),
  void_reason TEXT,
  created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const TILL_SYNC = {
  tills: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'name', 'float_amount', 'active', 'sort']),
  till_counts: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'till_uid', 'till_name', 'shift_date', 'shift', 'cashier_uid', 'cashier_name', 'counted_by_uid', 'counted_by_name', 'counted_at',
    'opening_float', 'denominations', 'cash_counted', 'float_kept', 'z_number', 'z_total', 'z_cash', 'tenders', 'payouts', 'drops', 'adjustments', 'expected_cash', 'over_short', 'reason', 'notes',
    'photo_urls', 'status', 'approved_by_name', 'approved_at', 'approve_note', 'void_reason',
    'z_vat', 'z_zero_rated', 'z_refunds', 'z_voids', 'z_customers', 'short_action', 'short_charge_uid', 'short_note']),
  cash_moves: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'move_date', 'type', 'amount', 'ref_uid', 'category', 'note', 'photo_urls', 'by_name', 'by_uid', 'status', 'void_reason']),
  deposits: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'account_uid', 'deposit_date', 'slip_no', 'branch', 'cash_amount', 'cheque_amount', 'cheques', 'denominations', 'total', 'takings_from', 'takings_to',
    'deposited_by_uid', 'deposited_by_name', 'witness', 'bank_entry_uid', 'notes', 'photo_urls', 'status', 'void_reason', 'created_at']),
};
