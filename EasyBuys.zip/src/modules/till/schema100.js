// 1.0.0 (build 1) Start shift / End shift on one page, and handover notes written during the shift.
//   shift_ends     – one row per person per shift: started (clocked in, float from Aronium) → finished (till count,
//                    cigarettes, checklist, handover, clocked out), with an admin PIN override kept with who and why.
//   handover_notes – short notes added any time during a shift; the next person reads them when they take over.
export const SHIFT100_SQL = `
CREATE TABLE IF NOT EXISTS shift_ends (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'till',
  user_uid TEXT NOT NULL, name TEXT,
  shop_code TEXT, till_uid TEXT, till_name TEXT,
  shift_date TEXT NOT NULL, shift TEXT,
  started_at TEXT, float_start REAL, float_from TEXT,
  count_uid TEXT, eod_uid TEXT, manual_z INTEGER NOT NULL DEFAULT 0,
  tally_uid TEXT, duty_run_uid TEXT, handover_uid TEXT,
  taker_uid TEXT, taker_name TEXT,
  own_till INTEGER NOT NULL DEFAULT 0, checker_uid TEXT, checker_name TEXT,
  counted REAL, expected REAL, over_short REAL, short_action TEXT, cig_aside REAL,
  finished_at TEXT,
  override_by_uid TEXT, override_by_name TEXT, override_reason TEXT, override_what TEXT,
  flags TEXT,
  status TEXT NOT NULL DEFAULT 'started',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_shift_ends_day ON shift_ends(shift_date, shop_code);
CREATE TABLE IF NOT EXISTS handover_notes (
  uid TEXT PRIMARY KEY,
  place TEXT NOT NULL,
  note_date TEXT NOT NULL,
  shift TEXT,
  text TEXT NOT NULL,
  by_uid TEXT, by_name TEXT, at TEXT,
  read_by TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_handover_notes_day ON handover_notes(place, note_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const SHIFT100_SYNC = {
  shift_ends: SYNC('uid', 'Till & cash', ['uid', 'kind', 'user_uid', 'name', 'shop_code', 'till_uid', 'till_name', 'shift_date', 'shift', 'started_at', 'float_start', 'float_from',
    'count_uid', 'eod_uid', 'manual_z', 'tally_uid', 'duty_run_uid', 'handover_uid', 'taker_uid', 'taker_name', 'own_till', 'checker_uid', 'checker_name', 'counted', 'expected', 'over_short',
    'short_action', 'cig_aside', 'finished_at', 'override_by_uid', 'override_by_name', 'override_reason', 'override_what', 'flags', 'status']),
  handover_notes: SYNC('uid', 'Till & cash', ['uid', 'place', 'note_date', 'shift', 'text', 'by_uid', 'by_name', 'at', 'read_by', 'status']),
};
// 1.0.0 a checklist per shop (and one for the bakery): the job's list for that shop wins over the job's list for all shops.
export const SHIFT100_COLUMNS = { duty_lists: [['shop_code', 'TEXT']] };
