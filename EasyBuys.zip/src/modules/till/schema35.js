// Till & cash v3.5: till shifts (one till balance per till per shift), Aronium End of day figures matched to each
// shift's Z, and till shortages the cashier agrees to (or not) before they go to the pay run.
export const TILL35_SQL = `
CREATE TABLE IF NOT EXISTS till_shifts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  till_uid TEXT,
  till_name TEXT,
  shift_date TEXT NOT NULL,
  shift TEXT NOT NULL,
  cashier_uid TEXT, cashier_name TEXT,
  opening_float REAL,
  opened_by_name TEXT, opened_by_uid TEXT, opened_at TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  count_uid TEXT,
  continued_by_name TEXT, continued_at TEXT, continue_note TEXT,
  eod_z_number TEXT, eod_total REAL,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_tsh_till ON till_shifts(till_uid, shift_date);

CREATE TABLE IF NOT EXISTS aronium_eods (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  eod_date TEXT NOT NULL,
  z_number TEXT,
  total REAL NOT NULL DEFAULT 0,
  vat REAL, zero REAL, cash REAL, card REAL, other REAL,
  source TEXT, batch_uid TEXT, note TEXT,
  count_uids TEXT,
  till_total REAL,
  diff REAL,
  state TEXT NOT NULL DEFAULT 'no_till',
  explanation TEXT, use_figure TEXT, resolved_diff REAL, resolved_by_name TEXT, resolved_at TEXT,
  notified_state TEXT,
  created_by_name TEXT, created_at TEXT,
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_eod_shop ON aronium_eods(shop_code, eod_date);

CREATE TABLE IF NOT EXISTS till_shortages (
  uid TEXT PRIMARY KEY,
  count_uid TEXT NOT NULL,
  shop_code TEXT,
  shift_date TEXT,
  user_uid TEXT, name TEXT,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting',
  per_pay REAL, parts INTEGER,
  signature TEXT,
  agreed_at TEXT,
  disagree_note TEXT,
  decided_by_name TEXT, decided_at TEXT, decision_note TEXT,
  charge_uid TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_tshort_user ON till_shortages(user_uid, status);
`;

// New columns on till_counts (added on start-up by src/db/columns.js).
export const TILL35_COLUMNS = [['balancer_uid', 'TEXT'], ['balancer_name', 'TEXT'], ['cashier_sig', 'TEXT'], ['balancer_sig', 'TEXT'], ['signed_at', 'TEXT'], ['shift_uid', 'TEXT']];

const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const TILL35_SYNC = {
  till_shifts: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'till_uid', 'till_name', 'shift_date', 'shift', 'cashier_uid', 'cashier_name', 'opening_float', 'opened_by_name', 'opened_by_uid', 'opened_at',
    'status', 'count_uid', 'continued_by_name', 'continued_at', 'continue_note', 'eod_z_number', 'eod_total', 'void_reason']),
  aronium_eods: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'eod_date', 'z_number', 'total', 'vat', 'zero', 'cash', 'card', 'other', 'source', 'batch_uid', 'note', 'count_uids', 'till_total', 'diff',
    'state', 'explanation', 'use_figure', 'resolved_diff', 'resolved_by_name', 'resolved_at', 'notified_state', 'created_by_name', 'created_at', 'void_reason']),
  till_shortages: SYNC('uid', 'Till & cash', ['uid', 'count_uid', 'shop_code', 'shift_date', 'user_uid', 'name', 'amount', 'status', 'per_pay', 'parts', 'signature', 'agreed_at', 'disagree_note',
    'decided_by_name', 'decided_at', 'decision_note', 'charge_uid', 'by_name', 'created_at']),
};
