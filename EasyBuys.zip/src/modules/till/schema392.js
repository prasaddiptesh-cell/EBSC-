// v3.9.2 Till: second count columns, surplus table, shortage paid in cash (see recount.js).
export const TILL392_SQL = `
CREATE TABLE IF NOT EXISTS till_surplus (
  uid TEXT PRIMARY KEY,
  count_uid TEXT NOT NULL,
  shop_code TEXT, shift_date TEXT,
  user_uid TEXT, name TEXT,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  set_off_uid TEXT, set_off_amount REAL,
  returned_amount REAL, cash_uid TEXT,
  decided_by_name TEXT, decided_at TEXT, decision_note TEXT,
  by_name TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_tsurplus_user ON till_surplus(user_uid, status);
`;
export const TILL392_COUNT_COLUMNS = [['first_count', 'TEXT'], ['second_status', 'TEXT'], ['second_by_uid', 'TEXT'], ['second_by_name', 'TEXT'], ['second_at', 'TEXT'], ['second_diff', 'REAL'], ['second_note', 'TEXT']];
export const TILL392_SHORT_COLUMNS = [['paid_now', 'REAL'], ['paid_now_at', 'TEXT'], ['paid_now_sig', 'TEXT'], ['paid_cash_uid', 'TEXT'], ['paid_now_by', 'TEXT'], ['set_off_from', 'TEXT']];
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const TILL392_SYNC = {
  till_surplus: SYNC('uid', 'Till & cash', ['uid', 'count_uid', 'shop_code', 'shift_date', 'user_uid', 'name', 'amount', 'status', 'set_off_uid', 'set_off_amount', 'returned_amount', 'cash_uid',
    'decided_by_name', 'decided_at', 'decision_note', 'by_name', 'created_at']),
};
