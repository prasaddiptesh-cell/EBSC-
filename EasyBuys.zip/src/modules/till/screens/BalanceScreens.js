// 1.0.0 build 2 (owner, 1 Nov): "Balance the till" – one simple page for the person who balances (often not tech savvy).
// Top to bottom, big and plain: WHERE (shop and till, by themselves from the till PC), Aronium's End of day (read only),
// whose shift (drop-down, filled in), count the notes and coins, the result (Balanced ✓ / SHORT / OVER and what
// happens), a note, Save and sign. More than one End of day waiting: a short list first, one tap each.
// The old long form stays at the bottom ("Type the figures myself") for unusual cases. All saving is balanceTill.js.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Row, Select, PhotoPicker, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, ListItem, MoneyField } from '../../../ui/kit.js';
import { SignaturePad } from '../../../ui/signature.js';
import { money } from '../../../services/core.js';
import * as B from '../balanceTill.js';
import { Notes, MpBox } from './ShiftScreens.js';
import { RcBox, rcHandlers, rcOk } from './RechargeScreens.js';
import { PullEodBox } from '../../aronium/PullEodBox.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };

function Where({ label, sub, testID = 'bt-where' }) {
  return (
    <View style={{ backgroundColor: C.infoSoft || '#E3EEF9', borderRadius: 16, padding: 16, gap: 4 }}>
      <Text testID={testID} style={{ fontSize: 24, fontWeight: '900', color: C.text }}>{label}</Text>
      {sub ? <Text testID={`${testID}-sub`} style={{ fontSize: 18, color: C.text }}>{sub}</Text> : null}
    </View>
  );
}
function ResultBox({ res, name }) {
  if (!res || res.state === 'none') {
    return <View testID="bt-result" style={{ borderRadius: 16, padding: 18, backgroundColor: C.card, borderWidth: 2, borderColor: C.border }}><Text style={{ fontSize: 20, color: C.sub, textAlign: 'center' }}>Count the cash – the result shows here</Text></View>;
  }
  const tone = res.state === 'balanced' ? [C.success, C.successSoft] : res.state === 'short' ? [C.danger, C.dangerSoft] : [C.warn, C.warnSoft];
  const big = res.state === 'balanced' ? 'Balanced ✓' : res.state === 'short' ? `SHORT ${$(res.amount)}` : `OVER ${$(res.amount)}`;
  const words = res.state === 'balanced' ? 'The cash agrees with Aronium.'
    : res.state === 'short' ? `This comes off ${name || 'the cashier'}'s pay on Saturday unless it is paid now.`
      : 'It is kept as a till over for the office to decide.';
  return (
    <View testID="bt-result" style={{ borderRadius: 16, padding: 18, backgroundColor: tone[1], borderWidth: 3, borderColor: tone[0], gap: 6 }}>
      <Text testID={`bt-result-${res.state}`} style={{ fontSize: 34, fontWeight: '900', color: tone[0], textAlign: 'center' }}>{big}</Text>
      <Text style={{ fontSize: 18, color: C.text, textAlign: 'center' }}>{`Counted ${$(res.counted)} · should be ${$(res.expected)}`}</Text>
      <Text style={{ fontSize: 18, fontWeight: '700', color: C.text, textAlign: 'center' }}>{words}</Text>
    </View>
  );
}

function Picker({ list, nav }) {
  return (
    <Screen title="Balance the till" subtitle={list.length ? `${list.length} End of day${list.length > 1 ? 's' : ''} waiting` : 'Nothing waiting'}>
      {!list.length ? <Banner tone="success" message="Nothing waiting. When Aronium's End of day comes in from a till, it shows here." /> : null}
      {list.map((w) => (
        <ListItem key={w.uid} testID={`bt-pick-${w.uid}`} title={w.label} sub={`${w.z ? `Z ${w.z}` : 'Whole day'}${w.time ? ` · ${w.time}` : ''} · ${w.date}`} right={$(w.total)}
          onPress={() => nav.push(w.target.screen, w.target.params)} />
      ))}
      {/* 1.0.0 build 5: pull the End of day from the till PCs first, before hand entry */}
      <PullEodBox testID="bt-pull" onByHand={() => nav.push('BalanceTill', { manual: true })} />
      <Btn testID="bt-by-hand" title="End of day not in yet? Balance by hand" icon="✍️" size="md" variant="secondary" onPress={() => nav.push('BalanceTill', { manual: true })} />
      <Btn testID="bt-typed" title="Type the figures myself" size="md" variant="ghost" onPress={() => nav.push('TillCount', {})} />
    </Screen>
  );
}

export function BalanceTillScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [f, setF] = useState({ denominations: {}, cashierUid: null, shortAction: 'pay', note: '', signature: null, cashierSig: null, confirmOdd: false, z: { payments: {} }, tillUid: '', edit: null, mpAction: 'pay' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const setZ = (k) => (v) => setF((o) => ({ ...o, z: { ...o.z, [k]: v } }));
  if (!params.eodUid && !params.manual) return <Picker list={safe(() => B.waitingBalances(user), [])} nav={nav} />;
  let plan = null; let err = null;
  try { plan = params.manual ? B.manualPlan(user, { tillUid: f.tillUid, z: f.z }) : B.balancePlan(user, params.eodUid); } catch (e) { err = e; }
  const mayEdit = ['owner', 'admin', 'manager'].includes(user.role);
  if (plan && f.edit && !plan.manual) plan = B.withEdit(plan, f.edit);
  // 4 Nov (owner): the first balance for a till PC the app has no till for yet makes that till – a locked setting. The
  // owner unlocks it right here; anyone else is told plainly what to ask for (it used to show only the lock message).
  if (!plan && err && err.code === 'LOCKED') {
    const boss = ['owner', 'admin'].includes(user.role) || user.realRole === 'owner';
    return (
      <Screen title="Balance the till">
        <Banner testID="bt-locked" tone="warn" title="This till is new to the app" message={boss ? 'Aronium has a till here that the app does not have yet. Type your PIN once to add it – then the balance opens.' : 'Aronium has a till here that the app does not have yet. Ask the owner or admin to open this End of day once (it adds the till), or to add it in Settings › Tills.'} />
        {boss ? <Btn testID="bt-unlock" title="1. Unlock (owner PIN)" icon="🔓" variant="primary" onPress={() => ui.error(err)} /> : null}
        {boss ? <Btn testID="bt-unlock-go" title="2. Open the balance" icon="💵" variant="success" onPress={() => setF((o) => ({ ...o }))} /> : null}
        <Btn testID="bt-typed" title="Type the figures myself" size="md" variant="ghost" onPress={() => nav.push('TillCount', {})} />
      </Screen>
    );
  }
  if (!plan) return <Screen title="Balance the till"><Banner tone="warn" message={(err && err.message) || 'Not found.'} /><Btn testID="bt-typed" title="Type the figures myself" size="md" variant="ghost" onPress={() => nav.push('TillCount', {})} /></Screen>;
  const where = `${plan.where.label}`;
  const sub = plan.manual ? `${plan.shift} shift · ${plan.date} · Z typed by hand` : `${plan.shift} shift · ${plan.e.z_number ? `Z ${plan.e.z_number}` : 'whole day'} · ${plan.date}${plan.zTime ? ` · ${plan.zTime}` : ''}`;
  if (plan.done) {
    return (
      <Screen title="Balance the till">
        <Where label={where} sub={sub} />
        <Banner tone="success" message="This End of day already has its till balance." />
        <Btn testID="bt-home" title="Back to home" variant="secondary" onPress={() => nav.home()} />
      </Screen>
    );
  }
  const fig = plan.figures || { total: 0, cash: 0, payments: [], float: plan.float.amount, floatFrom: plan.float.from, cashIn: 0, cashOut: 0, supplierPaid: 0, expected: null };
  const mpRes = plan.mp ? require('../mpaisaShift.js').mpResult(plan.mp, f.mpClose, plan.rules.tolerance) : { state: 'none' };
  const cashierUid = f.cashierUid === null ? plan.cashierUid : f.cashierUid;
  const cashier = plan.staff.find((p) => p.uid === cashierUid);
  const res = B.resultOf(plan, f.denominations);
  const own = cashier && cashier.uid === user.uid;
  const odd = res.counted > 0 ? safe(() => require('../endShift.js').sanityProblems({ counted: res.counted, expected: res.expected, zCash: fig.cash, zTotal: fig.total, denominations: f.denominations }), []) : [];
  const stop = odd.filter((p) => p.level === 'stop');
  const check = odd.filter((p) => p.level === 'check');
  const manualOk = !plan.manual || (String(f.z.zNumber || '').trim() && f.z.total !== undefined && f.z.total !== '' && f.z.cash !== undefined && f.z.cash !== '' && (f.z.photos || []).length);
  const editOk = !f.edit || !plan.edited || String(f.edit.reason || '').trim().length >= 4;
  const mpOk = !(mpRes.state === 'short' && f.mpAction === 'explain' && String(f.mpNote || '').trim().length < 3);
  const ready = cashier && manualOk && editOk && mpOk && rcOk(plan.rc, f, plan.rules.tolerance) && res.counted > 0 && f.signature && !stop.length && (!check.length || f.confirmOdd) && !(res.state === 'short' && f.shortAction === 'paid_now' && !own && !f.cashierSig);
  const save = () => {
    try {
      const r = B.saveBalance(user, { ...(plan.manual ? { manual: { tillUid: plan.tillUid, z: f.z } } : { eodUid: plan.e.uid, edit: f.edit && plan.edited ? f.edit : undefined }), cashierUid, denominations: f.denominations, shortAction: f.shortAction, note: f.note,
        signature: f.signature, cashierSig: own ? null : f.cashierSig, confirmOdd: f.confirmOdd, mpClose: f.mpClose, mpAction: f.mpAction, mpNote: f.mpNote, rcClose: f.rcClose, rcAction: f.rcAction, rcNote: f.rcNote });
      nav.replace('BalanceDone', { countUid: r.countUid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Balance the till" subtitle={sub}>
      <Where label={where} sub={sub} />
      {!plan.manual && plan.e && B.mayConfirmZ(user) && fig.expected !== null && !B.oneTapProblem(user, plan) ? (
        <Card testID="bt-confirmz">
          <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>We ran this till ourselves</Text>
          <Text style={{ fontSize: 14, color: C.sub }}>{`Confirm Aronium's Z as it is – the cash is taken as ${'$' + Number(fig.expected).toFixed(2)}, no count. The record says it was confirmed in one tap.`}</Text>
          <Btn testID="bt-confirmz-btn" title="Confirm the Z – one tap" icon="✅" variant="success" onPress={() => { try { const r = B.confirmZ(user, plan.e.uid); nav.replace('BalanceDone', { countUid: r.countUid }); } catch (e) { ui.error(e); } }} />
        </Card>
      ) : null}
      {plan.manual ? <PullEodBox testID="bt-pull" /> : null}
      {plan.manual ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Which till</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {plan.choices.map((c) => <Btn key={c.key} testID={`bt-till-${c.tillUid}`} title={`${c.tillUid === plan.tillUid ? '✓ ' : ''}${c.label}`} size="md" variant={c.tillUid === plan.tillUid ? 'info' : 'secondary'} onPress={() => set('tillUid')(c.tillUid)} />)}
          </View>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>1 · The Z report</Text>
          <Hint>Aronium's End of day has not come in yet. Type these four from the Z report and take its photo. When Aronium's comes in, the app puts it right by itself.</Hint>
          <Field testID="bt-z-no" label="Z number" value={f.z.zNumber || ''} onChangeText={setZ('zNumber')} keyboardType="number-pad" />
          <MoneyField testID="bt-z-total" label="Total sales" value={f.z.total} onChange={setZ('total')} />
          <MoneyField testID="bt-z-cash" label="Cash sales" value={f.z.cash} onChange={setZ('cash')} />
          <MoneyField testID="bt-z-mp" label="M-PAiSA" value={(f.z.payments || {})['M-PAiSA']} onChange={(v) => setF((o) => ({ ...o, z: { ...o.z, payments: { ...o.z.payments, 'M-PAiSA': v } } }))} />
          <PhotoPicker testID="bt-z-photo" label="Photo of the Z report" required value={f.z.photos || []} onChange={setZ('photos')} />
          {plan.figures ? <View testID="bt-expected"><Row label="Cash that should be in the till" value={$(fig.expected)} bold color={C.info} /></View> : null}
        </Card>
      ) : (
      <Card>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>1 · Aronium's End of day</Text>
        <Hint>{plan.edited ? `Changed: ${plan.edited.join(', ')}` : 'Filled in from the till PC – nothing to type.'}</Hint>
        <Row label="Total sales" value={$(fig.total)} />
        <Row label="CASH sales" value={$(fig.cash)} bold />
        {fig.payments.map((p) => <Row key={p.name} label={p.name} value={$(p.amount)} />)}
        <Row label={`Float${fig.floatFrom === 'Aronium' ? ' (from Aronium)' : ''}`} value={$(fig.float)} />
        {fig.cashIn ? <Row label="Cash put in" value={$(fig.cashIn)} /> : null}
        {fig.cashOut ? <Row label="Cash taken out" value={`− ${$(fig.cashOut)}`} /> : null}
        {fig.supplierPaid ? <Row label="Suppliers paid from the till" value={`− ${$(fig.supplierPaid)}`} /> : null}
        <View testID="bt-expected"><Row label="Cash that should be in the till" value={$(fig.expected)} bold color={C.info} /></View>
        {mayEdit && !f.edit ? <Text testID="bt-edit" onPress={() => set('edit')({ reason: '' })} style={{ fontSize: 15, color: C.sub, textAlign: 'right', textDecorationLine: 'underline', paddingTop: 6 }}>Edit a figure</Text> : null}
        {mayEdit && f.edit ? (
          <View style={{ gap: 8, paddingTop: 8 }}>
            <MoneyField testID="bt-ed-total" label="Total sales" value={f.edit.total !== undefined ? f.edit.total : String(plan.e.total)} onChange={(v) => set('edit')({ ...f.edit, total: v })} />
            <MoneyField testID="bt-ed-cash" label="CASH sales" value={f.edit.cash !== undefined ? f.edit.cash : String(plan.e.cash === null ? plan.e.total : plan.e.cash)} onChange={(v) => set('edit')({ ...f.edit, cash: v })} />
            <MoneyField testID="bt-ed-float" label="Float" value={f.edit.float !== undefined ? f.edit.float : String(fig.float)} onChange={(v) => set('edit')({ ...f.edit, float: v })} />
            <Field testID="bt-ed-why" label="Why is it changed? (kept in the history)" value={f.edit.reason || ''} onChangeText={(v) => set('edit')({ ...f.edit, reason: v })} />
            <Btn testID="bt-ed-cancel" title="Use Aronium's figures" size="sm" variant="ghost" onPress={() => set('edit')(null)} />
          </View>
        ) : null}
      </Card>
      )}
      <Card>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>2 · Whose shift</Text>
        <Select testID="bt-cashier" label="The cashier" value={cashierUid || ''} onChange={set('cashierUid')} options={plan.staff.map((p) => ({ value: p.uid, label: p.name }))} />
        {plan.cashierFrom ? <Hint>{plan.cashierFrom === 'Aronium' ? 'From Aronium\'s End of day.' : 'The person clocked in on this till.'}</Hint> : null}
      </Card>
      <Card>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>3 · Count the cash</Text>
        <Hint>How many of each note and coin.</Hint>
        <Notes value={f.denominations} onChange={set('denominations')} testIDPrefix="bt-n" />
        <Text testID="bt-counted" style={{ fontSize: 24, fontWeight: '900', color: C.text, textAlign: 'right' }}>{`Counted ${$(res.counted)}`}</Text>
      </Card>
      <ResultBox res={res} name={cashier ? cashier.name : ''} />
      {res.state === 'short' ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Btn testID="bt-short-pay" title={f.shortAction === 'pay' ? '✓ Take from pay' : 'Take from pay'} size="md" variant={f.shortAction === 'pay' ? 'danger' : 'secondary'} style={{ flex: 1 }} onPress={() => set('shortAction')('pay')} />
          <Btn testID="bt-short-now" title={f.shortAction === 'paid_now' ? '✓ Paid now' : 'Paid now'} size="md" variant={f.shortAction === 'paid_now' ? 'success' : 'secondary'} style={{ flex: 1 }} onPress={() => set('shortAction')('paid_now')} />
        </View>
      ) : null}
      {(plan.rc || []).length && res.state !== 'none' ? <RcBox plans={plan.rc} {...rcHandlers(f, setF)} tol={plan.rules.tolerance} prefix="bt" name={cashier ? cashier.name : ''} /> : null}
      {plan.mp && res.state !== 'none' ? <MpBox mp={plan.mp} value={f.mpClose} onChange={set('mpClose')} action={f.mpAction} onAction={set('mpAction')} note={f.mpNote || ''} onNote={set('mpNote')} tol={plan.rules.tolerance} prefix="bt" name={cashier ? cashier.name : ''} /> : null}
      {stop.length ? <Banner testID="bt-stop" tone="danger" message={stop.map((p) => p.text).join('\n')} /> : null}
      {check.length ? (
        <>
          <Banner testID="bt-odd" tone="warn" message={check.map((p) => p.text).join('\n')} />
          <Btn testID="bt-odd-ok" title={f.confirmOdd ? '✓ Yes, the figures are right' : 'Yes, the figures are right'} size="md" variant={f.confirmOdd ? 'success' : 'secondary'} onPress={() => set('confirmOdd')(!f.confirmOdd)} />
        </>
      ) : null}
      <Field testID="bt-note" label="Note (if you want)" value={f.note} onChangeText={set('note')} />
      <SignaturePad testID="bt-sig" value={f.signature} onChange={set('signature')} label={`${user.name} (balanced the till) signs`} />
      {cashier && !own ? <SignaturePad testID="bt-cashier-sig" value={f.cashierSig} onChange={set('cashierSig')} label={`${cashier.name} signs if here${res.state === 'short' && f.shortAction === 'paid_now' ? ' (needed – paid now)' : ''}`} /> : null}
      <Btn testID="bt-save" title="Save and sign" icon="✅" variant="success" disabled={!ready} onPress={save} />
      <Text testID="bt-typed" onPress={() => nav.push('TillCount', plan.e ? { shopCode: plan.shopCode, shiftDate: plan.date, zNumber: plan.e.z_number || '', zTotal: plan.e.total, ...(plan.e.cash !== null && plan.e.cash !== undefined ? { zCash: plan.e.cash } : {}) } : { shopCode: plan.shopCode })}
        style={{ fontSize: 16, color: C.sub, textAlign: 'center', paddingVertical: 12, textDecorationLine: 'underline' }}>Type the figures myself</Text>
    </Screen>
  );
}

export function BalanceDoneScreen({ params = {} }) {
  const { nav } = useApp();
  const d = params.countUid ? safe(() => B.doneInfo(params.countUid), null) : null;
  if (!d) return <Screen title="Till balanced"><Banner tone="warn" message="Not found." /></Screen>;
  const c = d.c;
  const big = d.state === 'balanced' ? 'Balanced ✓' : d.state === 'short' ? `SHORT ${$(d.amount)}` : `OVER ${$(d.amount)}`;
  const col = d.state === 'balanced' ? C.success : d.state === 'short' ? C.danger : C.warn;
  const sh = d.shortage;
  const what = d.state === 'balanced' ? 'Saved. The End of day agrees with the till.'
    : d.state === 'over' ? 'Kept as a till over – the office decides.'
      : c.short_action === 'paid' || (sh && sh.status === 'paid') ? `${c.cashier_name} paid it now.`
        : `Comes off ${c.cashier_name}'s pay on Saturday${sh && sh.status === 'waiting' ? ` – ${c.cashier_name} signs to agree in My pay` : ''}.`;
  return (
    <Screen title="Till balanced" subtitle={`${c.shift} · ${c.shift_date}`}>
      <Where label={d.label} sub={`${c.shift} shift · ${c.z_number ? `Z ${c.z_number}` : 'whole day'} · ${c.shift_date}${d.zTime ? ` · ${d.zTime}` : ''}`} testID="bd-where" />
      <View style={{ alignItems: 'center', paddingVertical: 8 }}><Text testID="bd-result" style={{ fontSize: 40, fontWeight: '900', color: col }}>{big}</Text></View>
      <Card>
        <Row label="Cashier" value={c.cashier_name} />
        <Row label="Counted" value={$(c.cash_counted)} bold />
        <Row label="Should be" value={$(c.expected_cash)} />
        <Row label="Balanced by" value={c.balancer_name || c.counted_by_name} />
        {c.mp_close !== null && c.mp_close !== undefined ? <Row label="M-PAiSA" value={Math.abs(Number(c.mp_diff) || 0) <= (Number(require('../service.js').tillRules().tolerance) || 0) + 0.004 ? 'Balanced ✓' : `${Number(c.mp_diff) < 0 ? 'SHORT' : 'OVER'} ${$(Math.abs(c.mp_diff))}`} bold /> : null}
        {c.z_source === 'manual' ? <Row label="Z" value="Typed by hand – Aronium's comes in later" /> : null}
      </Card>
      <Text testID="bd-what" style={{ fontSize: 19, fontWeight: '700', color: C.text, textAlign: 'center' }}>{what}</Text>
      <Btn testID="bd-more" title="Balance another till" size="md" variant="secondary" onPress={() => nav.replace('BalanceTill', { pick: true })} />
      <Btn testID="bd-home" title="Back to home" variant="success" onPress={() => nav.home()} />
    </Screen>
  );
}
