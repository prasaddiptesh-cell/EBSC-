// 1.0.0 Cigarette tally (each shift) and the cigarette money (fund, weekly invoice, settings).
import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint, Stats } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { listSuppliers } from '../../payables/service.js';
import * as CG from '../cigTally.js';
import { shopChips } from '../../inventory/screens/common.js';

const $ = (n) => (n === null || n === undefined ? '–' : `$${(Number(n) || 0).toFixed(2)}`);
const num = (n) => (n === null || n === undefined ? '–' : String(Math.round(n * 1000) / 1000));
const readCount = (it, v) => {
  if (v && typeof v === 'object') return CG.packetsOf(v.s, v.p); // build 41: sleeves + packets
  const t = String(v === undefined ? '' : v).trim();
  if (!t) return '';
  if (/^\d+(\.\d+)?$/.test(t)) return Number(t);
  try { return require('../../inventory/packTerms.js').readQty(it.itemUid, t).qty; } catch (e) { return NaN; }
};

export function CigTallyScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const act = useAct();
  const shops = CG.cigShops();
  const [shop, setShop] = useState(params.shopCode || user.shopCode || shops[0] || 'S1');
  const [date] = useState(params.date || dateStr());
  const [shift, setShift] = useState(params.shift || CG.nextShift(params.shopCode || user.shopCode || shops[0] || 'S1', params.date || dateStr()));
  const [typed, setTyped] = useState({});
  const [aside, setAside] = useState('');
  const [reason, setReason] = useState('');
  const [, bump] = useState(0);
  useEffect(() => { const t = setInterval(() => bump((n) => n + 1), 30000); return () => clearInterval(t); }, []); // the till PC's End of day may come in
  const lines0 = CG.workOutTally({ shopCode: shop, date, shift }).lines;
  const closing = Object.fromEntries(lines0.map((l) => [l.itemUid, readCount(l, typed[l.itemUid])]));
  const bad = lines0.filter((l) => Number.isNaN(closing[l.itemUid]));
  const w = CG.workOutTally({ shopCode: shop, date, shift, closing: Object.fromEntries(Object.entries(closing).map(([k, v]) => [k, Number.isNaN(v) ? '' : v])) });
  const existing = CG.listTallies({ shopCode: shop, from: date }).find((t) => t.shift_date === date && t.shift === shift);
  const save = () => {
    const r = act(() => CG.saveTally(user, { shopCode: shop, date, shift, closing, aside: aside === '' ? undefined : aside, reason }), null);
    if (r) { ui.toast(`Saved – put ${$(r.aside)} in the cigarette envelope`); setTyped({}); setAside(''); setReason(''); nav.push('CigFund', { shopCode: shop }); }
  };
  if (!shops.length) return <Screen title="Cigarette tally"><Banner tone="info" message="The cigarette tally is switched off (Cigarette money › Settings)." /></Screen>;
  return (
    <Screen title="Cigarette tally" subtitle={`${shop} · ${shift} · ${date}`}
      footer={<Btn testID="cig-save" title={`Save – put aside ${$(aside === '' ? w.suggested : aside)}`} icon="🚬" variant="success" disabled={!w.lines.length} onPress={save} />}>
      <Hint>At the end of the shift: count every cigarette packet in the cabinet. The app compares it with what Aronium sold, and says how much cigarette money (packets sold × cost, with VAT) to take out of the takings into the cigarette envelope – for the weekly cigarette invoice.</Hint>
      {shops.length > 1 ? <Chips testIDPrefix="cig-shop" value={shop} onChange={(v) => { setShop(v); setTyped({}); }} options={shopChips().filter((o) => shops.includes(o.value))} /> : null}
      <Chips testIDPrefix="cig-shift" value={shift} onChange={(v) => { setShift(v); setTyped({}); }} options={CG.shiftChoices().map((s) => ({ value: s, label: s }))} />
      {existing ? <Banner tone="info" message={`Already done by ${existing.by_name} – saving again replaces it (${$(existing.aside)} was put aside).`} /> : null}
      {!w.lines.length ? <Banner tone="warn" message={`No cigarette products yet – they come from Aronium (groups: ${CG.cigRules().groups.join(', ')}).`} /> : null}
      {w.aronium.waiting.length ? <Banner tone="warn" title="Waiting for the till PC" message={`${w.aronium.waiting.join(', ')}: the End of day has not come in yet. Wait a minute, or save – the cabinet count is used now and the app puts it right when Aronium comes in.`} /> : null}
      {!w.aronium.ends && !w.aronium.waiting.length ? <Banner tone="info" message="No new End of day from Aronium for this shop yet – the cabinet count is used." /> : null}
      {w.first ? <Hint>First tally: this count is the starting point – from the next shift the cabinet shows what was sold.</Hint> : null}
      <Stats items={[
        { label: 'Aronium sold', value: w.aroniumPackets === null ? '–' : `${num(w.aroniumPackets)} pkts`, sub: $(w.aroniumValue), testID: 'cig-ar' },
        { label: 'Cabinet says sold', value: w.countedPackets === null ? '–' : `${num(w.countedPackets)} pkts`, sub: $(w.countedValue), testID: 'cig-count' },
        { label: 'Put aside', value: $(w.suggested), sub: w.aronium.complete ? 'from Aronium' : 'from the cabinet', testID: 'cig-aside' },
      ]} />
      {w.diffs.length ? <Banner tone="danger" title={`${w.diffs.length} product${w.diffs.length === 1 ? '' : 's'} differ`} message={w.diffs.map((l) => `${l.name}: cabinet ${num(l.soldCount)} gone, Aronium sold ${num(l.soldAronium)}`).join('\n')} /> : null}
      <Section title={`Count the cabinet (${w.lines.length - w.uncounted} of ${w.lines.length})`}>
        {w.lines.map((l) => (
          <Card key={l.itemUid} testID={`cig-${l.code}`} tone={l.diff !== null && l.diff !== 0 ? 'danger' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{l.name}</Text>
                <Text style={{ fontSize: 13, color: C.sub }}>{`Start ${num(l.opening)}${l.moved ? ` · in/out ${l.moved > 0 ? '+' : ''}${num(l.moved)}` : ''} · Aronium sold ${num(l.soldAronium)}${l.soldCount !== null ? ` · gone ${num(l.soldCount)}` : ''} · ${$(l.cost)} each`}</Text>
              </View>
              <View style={{ width: 110 }}><Field testID={`cig-s-${l.code}`} label={`Sleeves (×${CG.sleeveSize()})`} value={String((typed[l.itemUid] || {}).s || '')} onChangeText={(v) => setTyped({ ...typed, [l.itemUid]: { ...(typed[l.itemUid] || {}), s: v.replace(/\D/g, '') } })} keyboardType="number-pad" lettersToo={false} /></View>
              <View style={{ width: 110 }}><Field testID={`cig-n-${l.code}`} label="Packets" value={String((typed[l.itemUid] || {}).p || '')} onChangeText={(v) => setTyped({ ...typed, [l.itemUid]: { ...(typed[l.itemUid] || {}), p: v.replace(/\D/g, '') } })} keyboardType="number-pad" lettersToo={false} /></View>
            </View>
          </Card>
        ))}
      </Section>
      {bad.length ? <Banner tone="warn" message={`Not understood: ${bad.map((l) => l.name).join(', ')} – type the sleeves and the loose packets as numbers.`} /> : null}
      <Field testID="cig-aside-amt" label={`Cigarette money taken out (the app says ${$(w.suggested)})`} value={aside} onChangeText={setAside} keyboardType="decimal-pad" placeholder={w.suggested.toFixed(2)} />
      {w.diffs.length || (aside !== '' && Math.abs(Number(aside) - w.suggested) > 0.009) ? <Field testID="cig-reason" label="Reason (needed)" value={reason} onChangeText={setReason} placeholder="Why the cabinet or the money differs" /> : null}
    </Screen>
  );
}

// build 40 (owner: "a very easy way to monitor and track the cigarette tally – all from one place, tracked to the
// invoice, with the status of its payment"): one lot = one cigarette invoice, from the delivery to the payment.
const LOT_STATUS = { paid: ['✅ Paid', C.success], part: ['Part paid', C.warn], owing: ['Owing', C.warn], overdue: ['⛔ OVERDUE', C.danger] };
function LotView({ shop, user, nav, act, bump }) {
  const [pick, setPick] = useState(null);
  let v = null;
  try { v = CG.lotView(shop, { invoiceUid: pick }); } catch (e) { v = null; }
  if (!v || !v.lot) return <Banner testID="lot-none" tone="info" message={v && v.noSuppliers ? 'Choose the cigarette supplier(s) under Settings – then each of their invoices is a lot here.' : 'No cigarette invoice yet. Enter it when the cigarettes come (Goods came in, with the products, so the packets are counted).'} />;
  const L = v.lot; const I = L.invoice;
  const [stLabel, stColor] = LOT_STATUS[L.status] || ['', C.text];
  const pct = I.total ? Math.min(100, Math.round(((I.paid + Math.min(L.fund, I.owing)) / I.total) * 100)) : 0;
  return (
    <>
      <Card testID="lot-card">
        <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>{`${I.supplier} · invoice ${I.no || '(no number)'}`}</Text>
        <Text style={{ fontSize: 15, color: C.sub }}>{`Came ${I.date} · due ${I.due || '—'}${L.daysToDue !== null && L.status !== 'paid' ? (L.daysToDue >= 0 ? ` (in ${L.daysToDue} day${L.daysToDue === 1 ? '' : 's'})` : ` (${-L.daysToDue} days late)`) : ''}`}</Text>
        <Text testID="lot-status" style={{ fontSize: 20, fontWeight: '900', color: stColor, marginTop: 6 }}>{`${stLabel} · ${$(I.total)}${I.paid ? ` · paid ${$(I.paid)}` : ''}${I.owing > 0.004 ? ` · owing ${$(I.owing)}` : ''}`}</Text>
        <View style={{ height: 12, borderRadius: 6, backgroundColor: C.border, overflow: 'hidden', marginTop: 8 }}><View style={{ width: `${pct}%`, height: '100%', backgroundColor: L.status === 'paid' ? C.success : C.warn }} /></View>
        <Text style={{ fontSize: 13, color: C.sub, marginTop: 4 }}>{L.status === 'paid' ? 'This lot is paid.' : `Paid + in the cigarette fund: ${pct}% of the invoice`}</Text>
      </Card>
      <Stats items={[
        { label: 'Packets in', value: L.packetsIn === null ? '—' : String(L.packetsIn), testID: 'lot-in' },
        { label: 'Sold (Aronium)', value: String(L.sold), testID: 'lot-sold' },
        { label: 'Should be left', value: L.left === null ? '—' : String(L.left), testID: 'lot-left', color: L.left !== null && L.lastCount && L.lastCount.packets !== L.left ? C.danger : undefined },
        { label: 'Last count', value: L.lastCount ? String(L.lastCount.packets) : '—', sub: L.lastCount ? L.lastCount.date : '' },
      ]} />
      {L.brands && L.brands.length ? <Section title="Left of each brand (sleeves of 10)">{L.brands.map((b) => <ListItem key={b.itemUid} testID={`lot-brand-${b.name}`} title={b.name}
        sub={`in ${b.in === null ? '—' : CG.sleevesText(b.in, L.sleeve)} · sold ${CG.sleevesText(b.sold, L.sleeve)}${b.counted !== null ? ` · last count ${CG.sleevesText(b.counted, L.sleeve)}` : ''}`}
        right={b.left === null ? '—' : CG.sleevesText(b.left, L.sleeve)} tone={b.left !== null && b.counted !== null && b.counted !== b.left ? 'danger' : undefined} />)}</Section> : null}
      {L.packetsIn === null ? <Hint>The packets received are not known: enter the delivery with the products (Goods came in) so the app knows how many came on this invoice.</Hint> : null}
      <Stats items={[
        { label: 'Sold (cost)', value: $(L.soldValue) },
        { label: 'Put aside', value: $(L.aside), color: L.aside + 0.009 < L.soldValue ? C.danger : C.success, testID: 'lot-aside' },
        { label: 'In the fund now', value: $(L.fund) },
        { label: 'Still to put aside', value: $(L.stillToPutAside), color: L.stillToPutAside > 0 ? C.warn : C.success, testID: 'lot-need' },
      ]} />
      {L.missingDays.length ? <Banner testID="lot-missing" tone="warn" title="Days with no tally" message={`${L.missingDays.join(', ')} – the money for those days has not been put aside. Do the tally (or check the till PC sent its End of day).`} /> : null}
      <Btn testID="lot-tally" title="Do today's cigarette tally" icon="🚬" variant="info" onPress={() => nav.push('CigTally', { shopCode: shop })} />
      {L.enoughToPay ? <Btn testID="lot-pay" title={`Pay ${$(I.owing)} from the cigarette fund`} icon="💵" variant="success" onPress={() => { if (act(() => CG.payFromFund(user, { shopCode: shop, invoiceUids: [I.uid] }), 'Paid from the cigarette fund') !== null) bump((n) => n + 1); }} /> : null}
      {I.owing > 0.004 && !L.enoughToPay ? <Hint>{`When the fund reaches ${$(I.owing)} the invoice can be paid from it here (or pay it by cheque from the invoice).`}</Hint> : null}
      <Btn testID="lot-invoice" title="Open the invoice" size="md" variant="secondary" onPress={() => nav.push('ApInvoice', { uid: I.uid })} />
      <Section title="Day by day">
        {L.days.map((d) => (
          <ListItem key={d.date} testID={`lot-day-${d.date}`} title={`${d.date}${d.missing ? ' · no tally' : ` · ${d.packets} packets sold`}`}
            sub={d.missing ? 'Nothing put aside yet' : `${d.shifts} shift${d.shifts === 1 ? '' : 's'}${d.complete ? '' : ' · Aronium not all in'}${d.diff ? ` · cabinet differs by ${d.diff}` : ''}`}
            right={d.missing ? '—' : $(d.aside)} rightSub={d.missing ? '' : `sold ${$(d.value)}`} tone={d.missing ? 'warn' : d.diff ? 'danger' : undefined} />
        ))}
      </Section>
      {L.payments.length ? <Section title="Payments of this invoice">{L.payments.map((p, k) => <ListItem key={k} title={`${p.pay_date} · ${p.method === 'cash' && String(p.cash_from || '').startsWith('cig:') ? 'cash from the cigarette fund' : p.method}${p.cheque_no ? ` ${p.cheque_no}` : ''}`} right={$(p.amount)} />)}</Section> : null}
      {v.earlier.length ? <Section title="Earlier lots">{v.earlier.map((e) => <ListItem key={e.uid} testID={`lot-prev-${e.no}`} title={`${e.date} · invoice ${e.no || '?'}`} sub={e.status === 'paid' ? 'paid' : `owing ${$(e.owing)}`} right={$(e.total)} tone={e.status === 'paid' ? undefined : 'warn'} onPress={() => setPick(e.uid)} />)}</Section> : null}
      {pick ? <Btn title="Back to the current lot" size="md" variant="ghost" onPress={() => setPick(null)} /> : null}
    </>
  );
}
export function CigFundScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const shops = CG.cigShops().length ? CG.cigShops() : [user.shopCode || 'S1'];
  const [shop, setShop] = useState(params.shopCode || user.shopCode || shops[0]);
  const [tab, setTab] = useState(params.tab || 'lot');
  const [pick, setPick] = useState([]);
  const [backAmt, setBackAmt] = useState('');
  const [backWhy, setBackWhy] = useState('');
  const [voidWhy, setVoidWhy] = useState('');
  const [, bump] = useState(0);
  const boss = ['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const f = CG.fundOf(shop);
  const tallies = CG.listTallies({ shopCode: shop, limit: 30 });
  const inv = CG.cigInvoices();
  const R = CG.cigRules();
  const [groups, setGroups] = useState(R.groups.join(', '));
  const sups = listSuppliers();
  const picked = inv.filter((i) => pick.includes(i.uid));
  return (
    <Screen title="Cigarette money" subtitle={`${shop} · fund ${$(f.balance)}`}>
      {shops.length > 1 ? <Chips testIDPrefix="cf-shop" value={shop} onChange={setShop} options={shopChips().filter((o) => shops.includes(o.value))} /> : null}
      <Chips testIDPrefix="cf-tab" value={tab} onChange={setTab} options={[{ value: 'lot', label: 'This lot' }, { value: 'fund', label: 'Fund & invoices' }, { value: 'tallies', label: 'Shift tallies' }].concat(boss ? [{ value: 'settings', label: 'Settings' }] : [])} />
      {tab === 'lot' ? <LotView shop={shop} user={user} nav={nav} act={act} bump={bump} /> : null}
      {tab === 'fund' ? (
        <>
          <Stats items={[{ label: 'In the cigarette fund', value: $(f.balance), testID: 'cf-bal' }, { label: 'Put aside', value: $(f.put) }, { label: 'Paid to suppliers', value: $(f.paid) }]} />
          <Btn testID="cf-tally" title="Do the cigarette tally now" icon="🚬" variant="info" onPress={() => nav.push('CigTally', { shopCode: shop })} />
          <Section title={`Cigarette invoices owing (${inv.length})`}>
            {!R.suppliers.length ? <Banner tone="info" message="Choose the cigarette suppliers under Settings – their invoices show here." /> : null}
            {inv.map((i) => (
              <ListItem key={i.uid} testID={`cf-inv-${i.invoice_no}`} tone={pick.includes(i.uid) ? 'success' : undefined} title={`${pick.includes(i.uid) ? '☑ ' : '☐ '}${i.supplier_name} ${i.invoice_no || ''}`} sub={`due ${i.due_date || '–'} · owing ${$(i.owing)}`}
                onPress={() => setPick(pick.includes(i.uid) ? pick.filter((x) => x !== i.uid) : pick.concat([i.uid]))} />
            ))}
            {picked.length ? <Btn testID="cf-pay" title={`Pay ${$(picked.reduce((t, i) => t + Number(i.owing || 0), 0))} from the fund (cash)`} icon="💵" variant="success"
              onPress={() => { if (act(() => CG.payFromFund(user, { shopCode: shop, invoiceUids: pick }), 'Paid from the cigarette fund') !== null) { setPick([]); bump((n) => n + 1); } }} /> : null}
          </Section>
          {boss ? (
            <Card>
              <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>Give fund money back to the shop</Text>
              <Hint>e.g. the invoice was paid by cheque – the cash goes back with the shop's takings.</Hint>
              <Field testID="cf-back-amt" label="Amount" value={backAmt} onChangeText={setBackAmt} keyboardType="decimal-pad" />
              <Field testID="cf-back-why" label="Why" value={backWhy} onChangeText={setBackWhy} />
              <Btn testID="cf-back" title="Back to the shop's cash" size="sm" variant="secondary" onPress={() => { if (act(() => CG.fundBack(user, { shopCode: shop, amount: backAmt, reason: backWhy }), 'Back in the shop\'s cash') !== null) { setBackAmt(''); setBackWhy(''); bump((n) => n + 1); } }} />
            </Card>
          ) : null}
          <Section title="Money in and out">
            {CG.fundMoves(shop, 30).map((m, k) => <ListItem key={k} title={`${m.amount >= 0 ? '+' : '−'}${$(Math.abs(m.amount))} · ${m.what || ''}`} sub={`${m.date}${m.by ? ` · ${m.by}` : ''}`} />)}
          </Section>
        </>
      ) : null}
      {tab === 'tallies' ? (
        <Section title="Shift tallies">
          {!tallies.length ? <Banner tone="info" message="No tallies yet." /> : null}
          {boss && tallies.length ? <Field testID="cf-void-why" label="To remove a tally: the reason" value={voidWhy} onChangeText={setVoidWhy} /> : null}
          {tallies.map((t) => {
            const late = t.aronium_complete && Math.abs(Number(t.aronium_value) - Number(t.aside) - Number(t.topped_up)) > 0.009;
            const d = t.lines.filter((l) => l.diff !== null && l.diff !== 0);
            return (
              <Card key={t.uid} testID={`cf-t-${t.shift}`} tone={d.length ? 'danger' : late ? 'warn' : undefined}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`${t.shift} ${t.shift_date} · ${t.by_name}`}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{`Aronium ${num(t.aronium_packets)} pkts${t.aronium_complete ? '' : ' (not all in)'} · cabinet ${num(t.counted_packets)} · put aside ${$(Number(t.aside) + Number(t.topped_up))}`}</Text>
                {d.length ? <Text style={{ fontSize: 14, color: C.danger }}>{`${d.map((l) => `${l.name} ${l.diff > 0 ? '+' : ''}${l.diff}`).join(', ')} – ${t.reason || ''}`}</Text> : null}
                {late ? <Btn testID={`cf-settle-${t.shift}`} title={`Aronium came in: ${Number(t.aronium_value) - Number(t.aside) - Number(t.topped_up) > 0 ? 'put' : 'take'} ${$(Math.abs(Number(t.aronium_value) - Number(t.aside) - Number(t.topped_up)))} ${Number(t.aronium_value) - Number(t.aside) - Number(t.topped_up) > 0 ? 'more aside' : 'back'}`} size="sm" variant="info"
                  onPress={() => { if (act(() => CG.settleLate(user, t.uid), 'Done') !== null) bump((n) => n + 1); }} /> : null}
                {boss ? <Btn testID={`cf-void-${t.shift}`} title="Remove (its money goes back to the shop)" size="sm" variant="ghost" disabled={!voidWhy.trim()} onPress={() => { if (act(() => CG.voidTally(user, t.uid, voidWhy), 'Removed') !== null) { setVoidWhy(''); bump((n) => n + 1); } }} /> : null}
              </Card>
            );
          })}
        </Section>
      ) : null}
      {tab === 'settings' && boss ? (
        <Card>
          <Field testID="cf-groups" label="Aronium groups that are cigarettes" value={groups} onChangeText={setGroups} placeholder="Cigarettes, Tobacco" />
          <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{`Cigarette suppliers (one week's credit) – ${CG.cigItems().length} cigarette products found`}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {sups.map((s) => <Btn key={s.uid} testID={`cf-sup-${s.name.replace(/[^A-Za-z0-9]/g, '')}`} title={`${R.suppliers.includes(s.uid) ? '☑' : '☐'} ${s.name}`} size="sm" variant={R.suppliers.includes(s.uid) ? 'info' : 'secondary'}
              onPress={() => { act(() => CG.saveCigRules(user, { suppliers: R.suppliers.includes(s.uid) ? R.suppliers.filter((x) => x !== s.uid) : R.suppliers.concat([s.uid]) })); bump((n) => n + 1); }} />)}
          </View>
          <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>Shops that do the tally</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {shopChips().map((o) => { const on = !R.shops.length || R.shops.includes(o.value); return <Btn key={o.value} testID={`cf-shopon-${o.value}`} title={`${on ? '☑' : '☐'} ${o.label}`} size="sm" variant={on ? 'info' : 'secondary'}
              onPress={() => { const cur = R.shops.length ? R.shops : shopChips().map((x) => x.value); act(() => CG.saveCigRules(user, { shops: on ? cur.filter((x) => x !== o.value) : cur.concat([o.value]) })); bump((n) => n + 1); }} />; })}
          </View>
          <Btn testID="cf-vat" title={`${R.includeVat ? '☑' : '☐'} Cost with VAT (what the invoice is paid with)`} size="sm" variant={R.includeVat ? 'info' : 'secondary'} onPress={() => { act(() => CG.saveCigRules(user, { includeVat: !R.includeVat })); bump((n) => n + 1); }} />
          <Btn testID="cf-on" title={R.on ? 'Switch the cigarette tally off' : 'Switch the cigarette tally on'} size="sm" variant="ghost" onPress={() => { act(() => CG.saveCigRules(user, { on: !R.on })); bump((n) => n + 1); }} />
          <Btn testID="cf-save" title="Save the groups" size="sm" variant="success" onPress={() => { act(() => CG.saveCigRules(user, { groups }), 'Saved'); bump((n) => n + 1); }} />
        </Card>
      ) : null}
    </Screen>
  );
}
