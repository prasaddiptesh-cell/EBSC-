// Release 28: the End of day check – every discrepancy in both shops' End of days in one list (see ../eodCheck.js).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, Stats } from '../../../ui/kit.js';
import { eodCheck } from '../eodCheck.js';

const LEVEL = { high: ['🔴', C.danger], medium: ['🟠', C.warn], low: ['⚪', C.sub] };
const KIND = { gap: 'Missing End of day', dup: 'Z twice', diff: 'Till ≠ End of day', unbalanced: 'Not balanced', explained: 'Explained difference', vat: 'VAT', noz: 'No End of day', daysum: 'Day total' };

export function EodCheckScreen({ params = {} }) {
  const { nav } = useApp();
  const [from, setFrom] = useState(params.from || '');
  const [to, setTo] = useState(params.to || '');
  const [showLow, setShowLow] = useState(false);
  let r = null; let err = '';
  try { r = eodCheck({ from: from || undefined, to: to || undefined }); } catch (e) { err = e.message; }
  if (!r) return <Screen title="End of day check"><Banner tone="danger" message={err || 'Could not run the check.'} /></Screen>;
  return (
    <Screen title="End of day check" subtitle={`Both shops · ${r.from} to ${r.to}`}>
      <Hint>Every End of day (Z) of both shops checked against the till balances, the till PC's day sales, the Z numbers and the VAT. Tap a line to open it.</Hint>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexGrow: 1, minWidth: 150 }}><Field testID="ec-from" label="From (YYYY-MM-DD)" value={from} onChangeText={setFrom} placeholder={r.from} /></View>
        <View style={{ flexGrow: 1, minWidth: 150 }}><Field testID="ec-to" label="To" value={to} onChangeText={setTo} placeholder={r.to} /></View>
      </View>
      {r.total === 0 ? <Banner tone="success" message="Nothing found – every End of day matches." /> : null}
      {r.shops.map((s) => {
        const list = s.findings.filter((f) => showLow || f.level !== 'low');
        return (
          <Card key={s.code} testID={`ec-shop-${s.code}`}>
            <Text style={{ fontSize: 20, fontWeight: '900', color: C.text }}>{s.name || s.code}</Text>
            <Stats items={[
              { label: 'End of days', value: String(s.eods) },
              { label: 'Things to check', value: String(s.findings.filter((f) => f.level !== 'low').length), color: s.findings.some((f) => f.level === 'high') ? C.danger : C.text },
              { label: 'Till short (unexplained)', value: `$${Math.abs(s.short).toFixed(2)}`, color: s.short < 0 ? C.danger : C.text },
              { label: 'Till over (unexplained)', value: `$${s.over.toFixed(2)}` },
            ]} />
            {!list.length ? <Text style={{ fontSize: 16, color: C.success }}>Nothing to check ✓</Text> : null}
            {list.map((f, i) => (
              <View key={i} style={{ paddingVertical: 8, borderTopWidth: 1, borderColor: C.border }}>
                <Text style={{ fontSize: 14, fontWeight: '800', color: LEVEL[f.level][1] }}>{`${LEVEL[f.level][0]} ${KIND[f.kind] || f.kind}${f.date ? ` · ${f.date}` : ''}`}</Text>
                <Text style={{ fontSize: 16, color: C.text }}>{f.text}</Text>
                {f.nav ? <Btn title="Open" size="sm" variant="secondary" onPress={() => nav.push(f.nav.screen, f.nav.params || {})} /> : null}
              </View>
            ))}
          </Card>
        );
      })}
      <Btn testID="ec-low" title={showLow ? 'Hide the small / explained ones' : 'Show the small / explained ones too'} size="sm" variant="ghost" onPress={() => setShowLow(!showLow)} />
    </Screen>
  );
}
