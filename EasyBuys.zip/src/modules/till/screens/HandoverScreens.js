// v3.9.2 Handover & takeover screens: the run-through of the day (or a shift) at a shop, the person finishing signs it
// over, the person taking over signs. Every line opens its record. History by date.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, useApp, useUI, Choice } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Hint, Explain, Stats, DateField } from '../../../ui/kit.js';
import { SignaturePad, SignatureView } from '../../../ui/signature.js';
import { dateStr, money } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import { shareReport } from '../../../platform/files.js';
import * as HO from '../../../services/handover.js';
import * as T from '../service.js';
import { TeamChecklists } from '../../staff/screens/DutyScreens.js';
import { handoverDutyBlockers, myDutyToday } from '../../../services/duties.js';

const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);
const TONE = { bad: 'danger', warn: 'warn', good: undefined };
const shopOpts = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') }));

export function HandoverScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const saved = params.uid ? HO.getHandover(params.uid) : null;
  const [shop, setShop] = useState(saved ? saved.shop_code : params.shopCode || user.shop_code || (shopOpts()[0] || {}).value || 'S1');
  const [date, setDate] = useState(saved ? saved.hand_date : params.date || dateStr());
  const [shift, setShift] = useState(saved ? saved.shift || '' : params.shift || '');
  const [notes, setNotes] = useState('');
  const [sig, setSig] = useState(null);
  const [taker, setTaker] = useState('');
  const [takeSig, setTakeSig] = useState(null);
  const [takeNote, setTakeNote] = useState('');
  const [, bump] = useState(0);
  let day = null; let err = null;
  try { day = HO.handoverDay({ shopCode: shop, date, shift }); } catch (e) { err = e.message; }
  const h = saved ? HO.getHandover(saved.uid) : null;
  const waiting = !saved ? HO.waitingTakeover({ shopCode: shop }) : [];
  const staff = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const t = day ? day.totals : {};
  const doHand = () => {
    try {
      // v3.9.5 the cashier makes sure the shop assistants finished their checklists before handing over
      // (the owner / admin may hand over anyway).
      const left = handoverDutyBlockers({ shopCode: shop, date });
      if (left.length && !['owner', 'admin'].includes(user.role)) throw Object.assign(new Error(`Check ${left.map((p) => p.name).join(', ')}'s checklist first (above), then hand over.`), { isAppError: true });
      const r = HO.handOver(user, { shopCode: shop, date, shift, notes, signature: sig });
      ui.toast('Handed over – the next person signs to take over');
      nav.replace('Handover', { uid: r.uid });
    } catch (e) { ui.error(e); }
  };
  const doTake = () => {
    try {
      HO.takeOver(user, h.uid, { takerUid: taker || user.uid, signature: takeSig, note: takeNote });
      ui.toast('Taken over');
      setTakeSig(null); setTakeNote(''); bump((x) => x + 1);
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Handover & takeover" subtitle={`${shop} · ${date}${shift ? ` · ${shift}` : ' · whole day'}`}>
      {!saved ? <Explain>The whole day (or one shift) on one page, read from everything recorded in the app: till balances, banking and the cheques each deposit covered, cheques written and handed over, deliveries and invoices, payments, petty cash, staff, and what is still open. Tap any line to open it. Sign it over at the end of your shift; the next person signs to take over.</Explain> : null}
      {h ? (
        <Card tone={h.status === 'taken' ? 'success' : 'warn'}>
          <H>{h.status === 'taken' ? 'Handed over and taken over' : 'Handed over – waiting for the next person to take over'}</H>
          <Row label="Handed over by" value={`${h.from_name} · ${String(h.from_at).slice(0, 16)}`} />
          {h.from_sig ? <SignatureView data={h.from_sig} height={70} /> : null}
          {h.notes ? <Row label="Notes" value={h.notes} /> : null}
          {h.to_name ? <Row label="Taken over by" value={`${h.to_name} · ${String(h.to_at).slice(0, 16)}`} /> : null}
          {h.to_sig ? <SignatureView data={h.to_sig} height={70} /> : null}
          {h.to_note ? <Row label="Their note" value={h.to_note} /> : null}
          {h.summary && h.summary.totals ? <Hint>{`At handover: sales ${$(h.summary.totals.sales)} · banked ${$(h.summary.totals.banked)}${h.summary.totals.uncovered ? ` · cheques not covered ${$(h.summary.totals.uncovered)}` : ''} · ${h.summary.open.length} open item(s). The lines below are as they are now.`}</Hint> : null}
        </Card>
      ) : (
        <>
          <Label>Shop</Label>
          <Chips value={shop} onChange={setShop} testIDPrefix="ho-shop" options={shopOpts()} />
          <DateField label="Day" value={date} onChange={setDate} />
          <Choice value={shift} onChange={setShift} testIDPrefix="ho-shift" options={[{ value: '', label: 'Whole day' }].concat(T.tillRules().shifts.map((s) => ({ value: s, label: s })))} />
        </>
      )}
      {waiting.length ? waiting.map((w) => <Btn key={w.uid} testID={`ho-wait-${w.uid}`} title={`Take over from ${w.from_name} (${w.hand_date}${w.shift ? ` ${w.shift}` : ''})`} icon="🤝" variant="warn" size="md" onPress={() => nav.push('Handover', { uid: w.uid })} />) : null}
      {err ? <Banner tone="warn" message={err} /> : null}
      {day ? (
        <>
          <Stats items={[{ label: 'Sales', value: $(t.sales) }, { label: 'Banked', value: $(t.banked) }, { label: 'Cash at the shop', value: t.cashOnHand === null ? '—' : $(t.cashOnHand) },
            { label: 'Cheques not covered', value: $(t.uncovered), color: t.uncovered > 0.004 ? C.danger : C.success }, { label: 'Still open', value: String(t.openItems), color: t.openItems ? C.warn : C.success }]} />
          {day.sections.map((s) => (
            <Section key={s.key} title={`${s.title}${s.total ? ` · ${s.total}` : ''}`}>
              {!s.rows.length ? <Text style={{ fontSize: 15, color: C.sub }}>{s.key === 'open' ? 'Nothing open – all clear.' : 'None.'}</Text> : null}
              {s.rows.map((r, i) => <ListItem key={i} testID={`ho-${s.key}-${i}`} title={r.text} sub={r.sub} right={r.amount} tone={TONE[r.tone]} onPress={r.nav ? () => nav.push(r.nav.screen, r.nav.params || {}) : null} />)}
            </Section>
          ))}
          <Btn testID="ho-pdf" title="Handover sheet (PDF)" icon="📄" size="md" variant="secondary" onPress={() => shareReport(HO.handoverReport(h ? { uid: h.uid } : { shopCode: shop, date, shift }), 'pdf').catch((e) => ui.error(e))} />
        </>
      ) : null}
      {!saved && day ? (
        <Section title="Shop assistants' checklists">
          <TeamChecklists shopCode={shop} date={date} onChange={() => bump((x) => x + 1)} />
          {(() => { let m = null; try { m = myDutyToday(user, date); } catch (e) { m = null; } return m && !m.done ? <Btn testID="ho-mylist" title={`My checklist: ${m.ticked} of ${m.total} done`} icon="☑️" size="md" variant="warn" onPress={() => nav.push('MyChecklist', {})} /> : null; })()}
        </Section>
      ) : null}
      {!saved && day ? (
        <Card>
          <H>Hand over</H>
          <Field testID="ho-notes" label="Notes for the next person (anything they should know)" value={notes} onChangeText={setNotes} multiline />
          <SignaturePad value={sig} onChange={setSig} testID="ho-sig" label={`${user.name}, sign to hand over`} />
          <Btn testID="ho-hand" title="Hand over" icon="🤝" variant="success" disabled={!sig} onPress={doHand} />
        </Card>
      ) : null}
      {h && h.status === 'handed' ? (
        <Card>
          <H>Take over</H>
          <Select testID="ho-taker" label="Who is taking over" value={taker || (user.uid !== h.from_uid ? user.uid : '')} onChange={setTaker} options={[{ value: '', label: 'Choose' }].concat(staff.filter((u) => u.uid !== h.from_uid).map((u) => ({ value: u.uid, label: u.name })))} />
          <Hint>Go through the list above with the person handing over. Anything that does not agree – write it below.</Hint>
          <Field testID="ho-takenote" label="Note (optional)" value={takeNote} onChangeText={setTakeNote} multiline />
          <SignaturePad value={takeSig} onChange={setTakeSig} testID="ho-takesig" label="Sign to take over" />
          <Btn testID="ho-take" title="Take over" icon="✅" variant="success" disabled={!takeSig} onPress={doTake} />
        </Card>
      ) : null}
    </Screen>
  );
}

export function HandoversScreen() {
  const { nav, user } = useApp();
  const [shop, setShop] = useState(user.shop_code || '');
  const list = HO.listHandovers({ shopCode: shop || undefined, limit: 200 });
  return (
    <Screen title="Handovers" subtitle="Every handover, by day – tap to see the day">
      <Chips value={shop} onChange={setShop} testIDPrefix="hos-shop" options={[{ value: '', label: 'All shops' }].concat(shopOpts())} />
      <Btn testID="hos-new" title="Hand over now" icon="🤝" variant="success" onPress={() => nav.push('Handover', { shopCode: shop || undefined })} />
      {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No handovers yet.</Text> : null}
      {list.map((h) => <ListItem key={h.uid} testID={`hos-${h.uid}`} title={`${h.shop_code} · ${h.hand_date}${h.shift ? ` · ${h.shift}` : ''}`} sub={`${h.from_name}${h.to_name ? ` → ${h.to_name}` : ' → waiting'}${h.notes ? ` · ${h.notes}` : ''}`}
        badge={h.status === 'taken' ? 'Taken over' : 'Waiting'} badgeColor={h.status === 'taken' ? C.success : C.warn} onPress={() => nav.push('Handover', { uid: h.uid })} />)}
    </Screen>
  );
}
