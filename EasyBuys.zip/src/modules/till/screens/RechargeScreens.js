// 1.0.0 (owner, 2 Nov): the recharge machines – Vodafone and Inkk balance per shop.
//   Recharge          – Records › Money: each balance now, last top-up, sold today / this week, commission this month
//   RechargeWallet    – one balance: the same, and its history (top-ups, the balances read at each shift)
//   RechargeTopUp     – "Top up the recharge machine": shop, Vodafone / Inkk, paid, value put on, supplier, how paid, photo
//   RechargeSetup     – owner / admin (locked): which Aronium products are Vodafone / Inkk, the names and top-up levels,
//                       and which suppliers are recharge suppliers
//   RcBox             – the shift box (End shift, Balance the till): should be, the balance now, Balanced / SHORT / OVER
import React, { useState } from 'react';
import { View, Image } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Field, Row, Select, PhotoPicker, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';

// The network's own logo on its colour (owner, 2 Nov): staff see at a glance which balance it is.
const BRAND = {
  vodafone: { bg: '#E60000', logo: require('../../../../assets/recharge/vodafone.png'), ratio: 360 / 115 },
  inkk: { bg: '#3DB62B', logo: require('../../../../assets/recharge/inkk.png'), ratio: 1, scale: 1.6 },
};
export function ProviderBadge({ provider, label, size = 34 }) {
  const b = BRAND[String(provider || '').toLowerCase()];
  if (!b) return <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{label}</Text>;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: b.bg, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 6, alignSelf: 'flex-start' }}>
      <Image source={b.logo} style={{ height: size * (b.scale || 1), width: size * (b.scale || 1) * b.ratio }} resizeMode="contain" accessibilityLabel={label} />
      {/* the logo already says the network: only a longer name ("Shop 1 Vodafone") is written beside it */}
      {label && label.toLowerCase() !== String(provider).toLowerCase() ? <Text style={{ fontSize: 16, fontWeight: '800', color: '#FFFFFF' }}>{label}</Text> : null}
    </View>
  );
}
import { Hint, ListItem, MoneyField } from '../../../ui/kit.js';
import { money, dateStr } from '../../../services/core.js';
import * as R from '../recharge.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const boss = (u) => !!u && ['owner', 'admin'].includes(u.role);

// ---------------------------------------------------------------- the shift box
export function RcBox({ plans = [], close = {}, onClose, action = {}, onAction, note = {}, onNote, tol = 0, prefix = 'rc', name = '' }) {
  if (!plans.length) return null;
  return (
    <Card>
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Recharge machine</Text>
      {plans.map((p) => {
        const k = p.wallet.uid; const pv = p.wallet.provider;
        const res = R.rcResult(p, close[k], tol);
        const tone = res.state === 'balanced' ? [C.success, C.successSoft] : res.state === 'short' ? [C.danger, C.dangerSoft] : res.state === 'over' ? [C.warn, C.warnSoft] : [C.sub, C.card];
        return (
          <View key={k} style={{ gap: 6, paddingTop: 6 }}>
            <ProviderBadge provider={pv} label={p.wallet.providerLabel} />
            <Row label={p.from === 'none' ? 'At the start (not read yet)' : 'At the start'} value={$(p.open)} />
            {p.topups ? <Row label="Topped up" value={$(p.topups)} /> : null}
            <Row label={`${p.wallet.providerLabel} sold (Aronium)`} value={`− ${$(p.sales)}`} />
            {p.refunds ? <Row label="Refunds (put back)" value={$(p.refunds)} /> : null}
            <View testID={`${prefix}-rc-${pv}-should`}><Row label={`${p.wallet.providerLabel} should be`} value={$(p.expected)} bold color={C.info} /></View>
            <MoneyField testID={`${prefix}-rc-${pv}-close`} label={`${p.wallet.providerLabel} balance now (on the machine)`} value={close[k]} onChange={(v) => onClose(k, v)} />
            {res.state !== 'none' ? (
              <View testID={`${prefix}-rc-${pv}-result`} style={{ borderRadius: 14, padding: 12, backgroundColor: tone[1], borderWidth: 2, borderColor: tone[0] }}>
                <Text testID={`${prefix}-rc-${pv}-${res.state}`} style={{ fontSize: 24, fontWeight: '900', color: tone[0], textAlign: 'center' }}>{res.state === 'balanced' ? `${p.wallet.providerLabel} balanced ✓` : `${p.wallet.providerLabel} ${res.state === 'short' ? 'SHORT' : 'OVER'} ${$(res.amount)}`}</Text>
                {res.state === 'over' ? <Text style={{ fontSize: 16, color: C.text, textAlign: 'center' }}>Recorded and flagged for the office to check (a top-up not entered?).</Text> : null}
                {res.state === 'short' && !R.rcEnforced() ? <Text style={{ fontSize: 16, color: C.text, textAlign: 'center' }}>Recorded and flagged for the office to check. Nobody is charged.</Text> : null}
              </View>
            ) : null}
            {res.state === 'short' && !R.rcEnforced() ? <Field testID={`${prefix}-rc-${pv}-note`} label="Any reason you know? (optional)" value={note[k] || ''} onChangeText={(v) => onNote(k, v)} /> : null}
            {res.state === 'short' && R.rcEnforced() ? (
              <>
                <Select testID={`${prefix}-rc-${pv}-action`} label={`The ${p.wallet.providerLabel} short`} value={action[k] || 'pay'} onChange={(v) => onAction(k, v)}
                  options={[{ value: 'pay', label: `Take from ${name || 'the cashier'}'s pay` }, { value: 'paid_now', label: 'Paid now in cash' }, { value: 'explain', label: 'Explain it (the office decides)' }]} />
                {(action[k] || 'pay') === 'explain' ? <Field testID={`${prefix}-rc-${pv}-note`} label="Why is it short?" value={note[k] || ''} onChangeText={(v) => onNote(k, v)} /> : null}
              </>
            ) : null}
          </View>
        );
      })}
    </Card>
  );
}
// For the pages: the box's state handlers on one object field (f.rcClose / f.rcAction / f.rcNote).
export const rcHandlers = (f, setF) => ({
  close: f.rcClose || {}, action: f.rcAction || {}, note: f.rcNote || {},
  onClose: (k, v) => setF((o) => ({ ...o, rcClose: { ...(o.rcClose || {}), [k]: v } })),
  onAction: (k, v) => setF((o) => ({ ...o, rcAction: { ...(o.rcAction || {}), [k]: v } })),
  onNote: (k, v) => setF((o) => ({ ...o, rcNote: { ...(o.rcNote || {}), [k]: v } })),
});
// A short to explain needs the note.
export const rcOk = (plans, f, tol) => (plans || []).every((p) => { const res = R.rcResult(p, (f.rcClose || {})[p.wallet.uid], tol); return !(res.state === 'short' && ((f.rcAction || {})[p.wallet.uid] || 'pay') === 'explain' && String((f.rcNote || {})[p.wallet.uid] || '').trim().length < 3); });

// ---------------------------------------------------------------- Records › Money › Recharge machines
function WalletCard({ s, onPress }) {
  const w = s.wallet;
  return (
    <View style={{ gap: 4 }}>
    <ProviderBadge provider={w.provider} label={w.name} size={26} />
    <ListItem testID={`rc-w-${w.uid}`} title={w.name} tone={s.below ? 'danger' : undefined} onPress={onPress}
      sub={[s.below ? `BELOW ${$(w.low)} – top up` : null, s.lastTopUp ? `Last top-up ${$(s.lastTopUp.amount)} on ${s.lastTopUp.date}` : 'No top-up yet', `Sold today ${$(s.salesToday)} · this week ${$(s.salesWeek)}`, `Commission this month ${$(s.commissionMonth)}`].filter(Boolean).join('\n')}
      right={$(s.balance)} rightSub="about now" />
    </View>
  );
}
export function RechargeScreen() {
  const { user, nav } = useApp();
  const list = safe(() => R.overview(user), []);
  const all = safe(() => R.listWallets(), []);
  return (
    <Screen title="Recharge machines" subtitle="Vodafone and Inkk balance per shop">
      {R.mayTopUp(user) ? <Btn testID="rc-topup" title="Top up the recharge machine" icon="📱" onPress={() => nav.push('RechargeTopUp', {})} /> : null}
      {!list.length ? <Banner tone="info" message={all.length ? 'No recharge balance is in use yet. The owner or admin chooses which Aronium products are Vodafone and Inkk recharge (Set up).' : 'There is no shop with a till yet.'} /> : null}
      {list.map((s) => <WalletCard key={s.wallet.uid} s={s} onPress={() => nav.push('RechargeWallet', { uid: s.wallet.uid })} />)}
      <Hint>The balance is the last balance read off the machine at a shift, plus top-ups since, less Aronium's recharge sales since.</Hint>
      {boss(user) ? <Btn testID="rc-setup" title="Set up – products and top-up levels" icon="⚙️" size="md" variant="secondary" onPress={() => nav.push('RechargeSetup', {})} /> : null}
    </Screen>
  );
}
export function RechargeWalletScreen({ params = {} }) {
  const { user, nav } = useApp();
  const w = safe(() => R.getWallet(params.uid), null);
  if (!w) return <Screen title="Recharge machine"><Banner tone="warn" message="Not found." /></Screen>;
  const s = R.walletStatus(w);
  const h = R.history(w.uid, { limit: 60 });
  return (
    <Screen title={w.name} subtitle="Recharge machine">
      <ProviderBadge provider={w.provider} label={w.name} />
      <Card>
        <Row label="Balance now (about)" value={$(s.balance)} bold color={s.below ? C.danger : C.text} />
        {w.low !== null ? <Row label="Top up when below" value={$(w.low)} /> : null}
        {s.lastReading ? <Row label={`Last read off the machine (${s.lastReading.at.slice(0, 16)})`} value={$(s.lastReading.amount)} /> : null}
        <Row label="Last top-up" value={s.lastTopUp ? `${$(s.lastTopUp.amount)} · ${s.lastTopUp.date}` : '—'} />
        <Row label="Sold today" value={$(s.salesToday)} />
        <Row label="Sold this week" value={$(s.salesWeek)} />
        <Row label="Commission this month" value={$(s.commissionMonth)} />
      </Card>
      {R.mayTopUp(user, w.shop_code) ? <Btn testID="rcw-topup" title={`Top up ${w.providerLabel}`} icon="📱" onPress={() => nav.push('RechargeTopUp', { shopCode: w.shop_code, provider: w.provider })} /> : null}
      <Label>History</Label>
      {!h.length ? <Text style={{ fontSize: 17, color: C.sub }}>Nothing yet.</Text> : null}
      {h.map((m) => <ListItem key={m.uid} testID={`rcw-h-${m.uid}`} title={m.text} sub={`${m.at.slice(0, 16)}${m.who ? ` · ${m.who}` : ''}${m.note ? ` · ${m.note}` : ''}`} tone={m.kind === 'reading' && Number(m.diff) < -0.004 ? 'danger' : undefined} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- Top up the recharge machine
export function RechargeTopUpScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const wallets = safe(() => R.listWallets().filter((w) => R.mayTopUp(user, w.shop_code)), []);
  const shops = Array.from(new Set(wallets.map((w) => w.shop_code)));
  const AP = require('../../payables/service.js');
  const sups = safe(() => AP.listSuppliers(), []);
  const marked = R.rcSetup().suppliers;
  const supOpts = sups.slice().sort((a, b) => (marked[b.uid] ? 1 : 0) - (marked[a.uid] ? 1 : 0)).map((s) => ({ value: s.uid, label: s.name, hint: marked[s.uid] ? 'Recharge supplier' : undefined }));
  const first = params.supplierUid && marked[params.supplierUid] && marked[params.supplierUid] !== 'both' ? marked[params.supplierUid] : 'vodafone';
  const [f, setF] = useState({ shopCode: params.shopCode || (user.shop_code && shops.includes(user.shop_code) ? user.shop_code : shops[0] || ''), provider: params.provider || first, supplierUid: params.supplierUid || '', method: 'cash', cashFrom: 'safe', photos: [] });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  if (!shops.length) return <Screen title="Top up the recharge machine"><Banner tone="warn" message="There is no recharge machine you can top up." /></Screen>;
  const w = wallets.find((x) => x.shop_code === f.shopCode && x.provider === f.provider);
  const tills = safe(() => require('../service.js').listTills({ shopCode: f.shopCode }), []);
  const mpw = safe(() => require('../mpaisaShift.js').mpWallet(f.shopCode), null);
  const accounts = safe(() => AP.listAccounts(), []);
  const comm = r2(Number(f.credited) - Number(f.paid));
  const needPhoto = safe(() => AP.apRules().requirePhoto, false);
  const ready = w && f.supplierUid && Number(f.paid) > 0 && Number(f.credited) > 0 && (!needPhoto || f.photos.length)
    && (f.method !== 'mpaisa' || (mpw && String(f.reference || '').trim())) && (f.method !== 'transfer' || (f.accountUid && String(f.reference || '').trim())) && (f.method !== 'cheque' || (f.accountUid && String(f.chequeNo || '').trim()));
  const save = () => {
    try {
      const r = R.topUp(user, { shopCode: f.shopCode, provider: f.provider, paid: f.paid, credited: f.credited, supplierUid: f.supplierUid, method: f.method, cashFrom: f.cashFrom,
        walletUid: mpw ? mpw.uid : undefined, accountUid: f.accountUid, reference: f.reference, chequeNo: f.chequeNo, photos: f.photos, note: f.note, date: dateStr() });
      ui.toast(`${r.wallet.name}: ${$(r.credited)} put on – commission ${$(r.commission)}`);
      nav.replace('RechargeWallet', { uid: r.wallet.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Top up the recharge machine" subtitle={w ? w.name : ''} footer={<Btn testID="rct-save" title="Save the top-up" icon="📱" variant="success" disabled={!ready} onPress={save} />}>
      {shops.length > 1 ? <Select testID="rct-shop" label="Which shop" value={f.shopCode} onChange={set('shopCode')} options={shops.map((s) => ({ value: s, label: (wallets.find((x) => x.shop_code === s) || {}).name ? wallets.find((x) => x.shop_code === s).name.replace(/\s+(Vodafone|Inkk)$/i, '') : s }))} /> : null}
      <Select testID="rct-provider" label="Vodafone or Inkk" value={f.provider} onChange={set('provider')} options={wallets.filter((x) => x.shop_code === f.shopCode).map((x) => ({ value: x.provider, label: x.providerLabel }))} />
      <Select testID="rct-supplier" label="Supplier" value={f.supplierUid} onChange={set('supplierUid')} options={supOpts} />
      <MoneyField testID="rct-paid" label="Amount paid to the supplier" value={f.paid} onChange={set('paid')} />
      <MoneyField testID="rct-credited" label="Value put on the machine" value={f.credited} onChange={set('credited')} />
      {Number(f.paid) > 0 && Number(f.credited) > 0 ? <Row label="Commission (value put on − paid)" value={$(comm)} bold color={comm < 0 ? C.danger : C.success} /> : null}
      <Select testID="rct-method" label="Paid by" value={f.method} onChange={set('method')} options={[{ value: 'cash', label: 'Cash' }, { value: 'mpaisa', label: 'M-PAiSA (the shop\'s wallet)' }, { value: 'transfer', label: 'Bank transfer' }, { value: 'cheque', label: 'Cheque' }]} />
      {f.method === 'cash' ? <Select testID="rct-cashfrom" label="Cash from" value={f.cashFrom} onChange={set('cashFrom')} options={[{ value: 'safe', label: 'The shop\'s safe' }].concat(tills.map((t) => ({ value: `till:${t.uid}`, label: t.name })))} /> : null}
      {f.method === 'transfer' || f.method === 'cheque' ? <Select testID="rct-account" label="Bank account" value={f.accountUid} onChange={set('accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
      {f.method === 'cheque' ? <Field testID="rct-chequeno" label="Cheque number" value={f.chequeNo || ''} onChangeText={set('chequeNo')} keyboardType="number-pad" /> : null}
      {f.method === 'mpaisa' && !mpw ? <Banner tone="warn" message="This shop has no M-PAiSA wallet in the app." /> : null}
      {f.method !== 'cash' ? <Field testID="rct-ref" label={f.method === 'cheque' ? 'Receipt number (optional)' : 'Transaction reference'} value={f.reference || ''} onChangeText={set('reference')} /> : <Field testID="rct-ref" label="Receipt number (optional)" value={f.reference || ''} onChangeText={set('reference')} />}
      <PhotoPicker testID="rct-photo" label={needPhoto ? 'Photo of the receipt' : 'Photo of the receipt (optional)'} required={needPhoto} value={f.photos} onChange={set('photos')} />
      <Field testID="rct-note" label="Note (optional)" value={f.note || ''} onChangeText={set('note')} />
    </Screen>
  );
}

// ---------------------------------------------------------------- Settings: products, levels, suppliers (locked)
const NET = [{ value: '', label: 'Not recharge' }].concat(R.PROVIDERS.map((p) => ({ value: p.key, label: p.label })));
export function RechargeSetupScreen() {
  const { user } = useApp();
  const ui = useUI();
  const all = safe(() => R.listWallets({ includeOff: true }), []);
  const shops = Array.from(new Set(all.map((w) => w.shop_code)));
  const [shop, setShop] = useState(shops[0] || '');
  const [, bump] = useState(0);
  const cur = safe(() => R.mappingFor(shop), { vodafone: { codes: [], groups: [] }, inkk: { codes: [], groups: [] } });
  const prods = safe(() => R.shopProducts(shop), []);
  const sug = safe(() => R.suggestMapping(shop), { products: [], groups: [] });
  const initPicks = () => {
    const m = {};
    R.PROVIDERS.forEach((p) => cur[p.key].codes.forEach((c) => { m[c] = p.key; }));
    if (!Object.keys(m).length) sug.products.forEach((p) => { m[p.code] = p.guess === '?' ? '' : p.guess; });
    return m;
  };
  const [picks, setPicks] = useState(null);
  const [groups, setGroups] = useState(null);
  const [lv, setLv] = useState({});
  const [sp, setSp] = useState(null);
  const P = picks || initPicks();
  const G = groups || { vodafone: cur.vodafone.groups[0] || '', inkk: cur.inkk.groups[0] || '' };
  const listed = Array.from(new Set(Object.keys(P).concat(sug.products.map((p) => p.code))));
  const name = (c) => (prods.find((p) => p.code === c) || { name: `Product ${c}` }).name;
  const groupOpts = [{ value: '', label: 'No group – only the products below' }].concat(Array.from(new Set(prods.map((p) => p.group).filter(Boolean))).sort().map((g) => ({ value: g, label: g, hint: R.guessProvider(g) ? 'looks like recharge' : undefined })));
  const saveMap = () => {
    try {
      const m = {};
      R.PROVIDERS.forEach((p) => { m[p.key] = { codes: Object.entries(P).filter(([, v]) => v === p.key).map(([c]) => c), groups: G[p.key] ? [G[p.key]] : [] }; });
      R.saveMapping(user, shop, m);
      ui.toast('Recharge products saved'); setPicks(null); setGroups(null); bump((x) => x + 1);
    } catch (e) { ui.error(e); }
  };
  const SUP = sp || R.rcSetup().suppliers;
  const sups = safe(() => require('../../payables/service.js').listSuppliers(), []);
  return (
    <Screen title="Recharge machines – set up" subtitle="Owner / admin · locked">
      {!shops.length ? <Banner tone="warn" message="There is no shop with a till yet." /> : null}
      {shops.length ? <Select testID="rcs-shop" label="Shop" value={shop} onChange={(v) => { setShop(v); setPicks(null); setGroups(null); }} options={shops.map((s) => ({ value: s, label: (all.find((w) => w.shop_code === s) || { name: s }).name.replace(/\s+(Vodafone|Inkk)$/i, '') }))} /> : null}
      {shop ? (
        <Card>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Which Aronium products are recharge</Text>
          <Hint>Each sale takes its full price off that balance ($10 sold = $10 off). The app suggests products whose name says Vodafone, Inkk, recharge or top up.</Hint>
          {!prods.length ? <Banner tone="warn" message="No products from Aronium for this shop yet – they come in from the till PC by themselves." /> : null}
          {R.PROVIDERS.map((p) => <Select key={p.key} testID={`rcs-group-${p.key}`} label={`${p.label}: a whole Aronium product group (optional)`} value={G[p.key]} onChange={(v) => setGroups({ ...G, [p.key]: v })} options={groupOpts} />)}
          {listed.map((c) => <Select key={c} testID={`rcs-p-${c}`} label={`${name(c)} (${c})`} value={P[c] || ''} onChange={(v) => setPicks({ ...P, [c]: v })} options={NET} />)}
          {prods.length ? <Select testID="rcs-add" label="Add another product" value="" onChange={(v) => setPicks({ ...P, [v]: '' })} options={prods.filter((x) => !listed.includes(x.code)).map((x) => ({ value: x.code, label: x.name, hint: x.group || undefined }))} placeholder="Tap to choose a product" /> : null}
          <Btn testID="rcs-save-map" title="Save the recharge products" size="md" variant="success" onPress={saveMap} />
        </Card>
      ) : null}
      {all.filter((w) => w.shop_code === shop).map((w) => {
        const v = { name: w.name, active: w.active ? 'on' : 'off', low: w.low === null ? '' : String(w.low), usual: w.usual === null ? '' : String(w.usual), ...(lv[w.uid] || {}) };
        const setV = (k) => (x) => setLv((o) => ({ ...o, [w.uid]: { ...v, [k]: x } }));
        return (
          <Card key={w.uid}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{w.name}</Text>
            <Field testID={`rcs-name-${w.provider}`} label="Name" value={v.name} onChangeText={setV('name')} />
            <Select testID={`rcs-on-${w.provider}`} label="In use" value={v.active} onChange={setV('active')} options={[{ value: 'on', label: 'On' }, { value: 'off', label: 'Off – not used at this shop' }]} />
            <MoneyField testID={`rcs-low-${w.provider}`} label="Top up when below $" value={v.low} onChange={setV('low')} />
            <MoneyField testID={`rcs-usual-${w.provider}`} label="Usual top-up (optional)" value={v.usual} onChange={setV('usual')} />
            <Btn testID={`rcs-save-${w.provider}`} title="Save" size="md" variant="secondary" onPress={() => { try { R.saveWalletSettings(user, w.uid, { name: v.name, active: v.active !== 'off', low: v.low, usual: v.usual }); ui.toast('Saved'); setLv((o) => ({ ...o, [w.uid]: undefined })); } catch (e) { ui.error(e); } }} />
          </Card>
        );
      })}
      <Card>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>When a balance does not agree</Text>
        <Select testID="rcs-enforce" label="A recharge short" value={R.rcEnforced() ? 'on' : 'off'} onChange={(x) => { try { R.setRcEnforce(user, x === 'on'); ui.toast('Saved'); setSp((o) => (o ? { ...o } : o)); } catch (e) { ui.error(e); } }}
          options={[{ value: 'off', label: 'Record it and flag it for the office (now)' }, { value: 'on', label: 'The cashier pays it – take from pay / paid now / explain' }]} />
      </Card>
      <Card>
        <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>Recharge suppliers</Text>
        <Hint>Paying one of these in "Pay a supplier" offers "Top up the recharge machine".</Hint>
        {Object.keys(SUP).map((uid) => <Select key={uid} testID={`rcs-sup-${uid}`} label={(sups.find((s) => s.uid === uid) || { name: uid }).name} value={SUP[uid]} onChange={(x) => setSp({ ...SUP, [uid]: x })}
          options={[{ value: 'vodafone', label: 'Vodafone' }, { value: 'inkk', label: 'Inkk' }, { value: 'both', label: 'Both' }, { value: 'none', label: 'Not a recharge supplier' }]} />)}
        <Select testID="rcs-sup-add" label="Add a recharge supplier" value="" onChange={(x) => setSp({ ...SUP, [x]: 'both' })} options={sups.filter((s) => !SUP[s.uid]).map((s) => ({ value: s.uid, label: s.name }))} placeholder="Tap to choose a supplier" />
        <Btn testID="rcs-save-sup" title="Save the suppliers" size="md" variant="secondary" onPress={() => { try { R.saveRechargeSuppliers(user, SUP); ui.toast('Saved'); setSp(null); } catch (e) { ui.error(e); } }} />
      </Card>
    </Screen>
  );
}
