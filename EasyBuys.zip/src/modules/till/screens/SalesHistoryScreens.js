// v1.0.0 Sales history: day by day per shop and till; tap a day for its products, hours and cashiers.
import React, { useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, Chips, Section, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Stats, Hint } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { salesHistory, salesDay } from '../salesHistory.js';
import { salesWatchSettings, saveSalesWatch, QUIET_CHOICES } from '../salesWatch.js';

// Today's figures keep coming from the till PCs: the screen reads them again every 30 seconds.
function useLive(on, ms = 30000) {
  const [n, setN] = useState(0);
  useEffect(() => { if (!on) return undefined; const t = setInterval(() => setN((x) => x + 1), ms); return () => clearInterval(t); }, [on, ms]);
  return n;
}

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const RANGES = [{ value: '7', label: '7 days' }, { value: '30', label: '30 days' }, { value: '90', label: '3 months' }, { value: '365', label: 'Year' }];

export function SalesHistoryScreen() {
  const { nav } = useApp();
  const [range, setRange] = useRemembered('sh-range', '30');
  const [shop, setShop] = useRemembered('sh-shop', '');
  const to = dateStr();
  const from = addDays(to, -(Number(range) || 30) + 1);
  const live = useLive(true);
  const h = useMemo(() => { try { return salesHistory({ from, to, shop }); } catch (e) { return { error: e.message }; } }, [range, shop, live]);
  const t = useMemo(() => { try { return salesDay(to, { shop }); } catch (e) { return null; } }, [shop, live]);
  if (h.error) return <Screen title="Sales history"><Banner tone="danger" message={h.error} /></Screen>;
  const max = Math.max(0, ...h.days.map((d) => d.total));
  return (
    <Screen title="Sales history" subtitle={`${from} to ${to}`}
      footer={<Btn testID="sh-pdf" title="PDF / Excel" icon="📄" variant="primary" onPress={() => nav.push('ReportView', { kind: 'till_sales_history', from, to, shop })} />}>
      <Chips value={shop} onChange={setShop} testIDPrefix="sh-shop" options={[{ value: '', label: 'Both shops' }, { value: 'S1', label: 'Shop 1' }, { value: 'S2', label: 'Shop 2' }]} />
      <Chips value={range} onChange={setRange} testIDPrefix="sh-range" options={RANGES} />
      {t ? (
        <ListItem testID="sh-today" title={`🟢 Today – live${t.live.last ? ` · last sale ${t.live.last}` : ''}`} right={$(t.live.receipts ? t.live.net : (h.days[0] && h.days[0].date === to ? h.days[0].total : 0))}
          sub={t.live.receipts ? `${t.live.receipts} receipts${t.live.refunds ? ` · ${t.live.refunds} refund${t.live.refunds === 1 ? '' : 's'} ${$(t.live.refundValue)}` : ''} · ${t.live.payments.slice(0, 3).map((p) => `${p.name} ${$(p.amount)}`).join(' · ')}` : 'Receipts, how they were paid, refunds and the cash that should be in each till'}
          rightSub="tap" onPress={() => nav.push('SalesDay', { date: to, shop })} />
      ) : null}
      <Stats items={[{ label: 'Sales', value: $(h.total) }, { label: 'Per trading day', value: $(h.perDay) }, h.best ? { label: 'Best day', value: $(h.best.total), sub: `${h.best.day} ${h.best.date}` } : null]} />
      {!h.days.length ? <Banner tone="info" title="No sales yet" message="Sales come from the till PCs (Aronium link) every few minutes, and from each Aronium End of day. If none show, check Settings › Aronium link (till PCs)." /> : null}
      {h.days.map((d) => (
        <ListItem key={d.date} testID={`sh-day-${d.date}`} title={`${d.day} ${d.date}`} right={$(d.total)}
          sub={Object.entries(d.shops).map(([s, x]) => `${s} ${$(x.value)}${Object.keys(x.tills).length > 1 ? ` (${Object.entries(x.tills).map(([t, v]) => `${t.split('-')[1] || t} ${$(v)}`).join(', ')})` : ''}${x.eod ? ` · VAT ${$(x.eod.vat)}` : ''}${x.gap ? `\n⚠ ${s}: ${x.gap.text}` : ''}`).join(' · ')}
          rightSub={d.gaps && d.gaps.length ? 'a till is missing' : d.receipts ? `${d.receipts} receipts` : (d.fromTill ? 'live' : 'End of day')}
          onPress={() => nav.push('SalesDay', { date: d.date, shop })} />
      ))}
      {max ? <Hint>Tap a day for its products, the busy hours and each cashier.</Hint> : null}
      <WatchSettings />
    </Screen>
  );
}

function WatchSettings() {
  const { user } = useApp();
  const ui = useUI();
  const [w, setW] = useState(() => salesWatchSettings());
  if (!user || !(['owner', 'admin', 'manager'].includes(user.role) || ['owner', 'admin'].includes(user.realRole))) return null;
  const save = (x) => { try { setW(saveSalesWatch(user, { ...w, ...x })); ui.toast('Saved'); } catch (e) { ui.error(e); } };
  return (
    <Section title="Sales watch (notifications)">
      <Hint>Warn when a shop is open (its opening hours on the shop page) and no sale has come through for:</Hint>
      <Chips value={String(w.quietMins)} onChange={(v) => save({ quietMins: Number(v) })} testIDPrefix="sw-quiet" options={QUIET_CHOICES.map((m) => ({ value: String(m), label: m ? `${m} min` : 'Off' }))} />
      <Chips value={w.started ? 'on' : 'off'} onChange={(v) => save({ started: v === 'on' })} testIDPrefix="sw-started" options={[{ value: 'on', label: '🔔 Till started: on' }, { value: 'off', label: 'Till started: off' }]} />
      <Chips value={w.afterHours ? 'on' : 'off'} onChange={(v) => save({ afterHours: v === 'on' })} testIDPrefix="sw-after" options={[{ value: 'on', label: '🌙 Sales while closed: on' }, { value: 'off', label: 'Sales while closed: off' }]} />
    </Section>
  );
}

export function SalesDayScreen({ params = {} }) {
  const { nav } = useApp();
  const isToday = (params.date || dateStr()) === dateStr();
  const live = useLive(isToday);
  const [show, setShow] = useState(60);
  const d = useMemo(() => { try { return salesDay(params.date, { shop: params.shop || '' }); } catch (e) { return null; } }, [params.date, params.shop, live]);
  if (!d) return <Screen title="Sales"><Banner tone="danger" message="Could not read that day." /></Screen>;
  const maxH = Math.max(0, ...d.hours.map((x) => x.value));
  const L = d.live;
  return (
    <Screen title={`Sales ${d.date}`} subtitle={`${params.shop || 'Both shops'} · ${$(L.receipts ? L.net : d.total)}${isToday ? ' · live' : ''}`}>
      {L.receipts || L.refunds ? (
        <Stats items={[{ label: 'Receipts', value: String(L.receipts), sub: L.last ? `last ${L.last}` : '' }, { label: 'Sales', value: $(L.sales) },
          { label: 'Refunds', value: L.refunds ? $(L.refundValue) : '–', sub: L.refunds ? `${L.refunds}` : '' }, { label: 'Net', value: $(L.net) }]} />
      ) : null}
      {d.drawers.length ? (
        <Section title="Cash that should be in the till now">
          {d.drawers.map((t) => (
            <View key={t.source} style={{ gap: 6 }}>
              <ListItem testID={`sd-drawer-${t.source}`} title={`${t.till}`} right={$(t.expected)} rightSub="expected cash"
                sub={`Float ${$(t.float)}${t.floatFrom === 'app' ? ' (app)' : t.floatFrom === 'none' ? ' (not set)' : ''}${t.cashIn ? ` + put in ${$(t.cashIn)}` : ''}${t.cashOut ? ` − taken out ${$(t.cashOut)}` : ''} + cash sales ${$(t.cashSales)}${t.cashRefunds ? ` − cash refunds ${$(t.cashRefunds)}` : ''}${t.since ? ` · since End of day at ${t.since.slice(0, 5)}` : ' · since the last End of day'}`} />
              {Object.keys(t.payments).length ? <Hint>{`Taken since then: ${Object.entries(t.payments).map(([n, v]) => `${n} ${$(v)}`).join(' · ')}${t.refunds ? ` · ${t.refunds} refund${t.refunds === 1 ? '' : 's'} ${$(t.refundValue)}` : ''}`}</Hint> : null}
              {!t.withAmounts ? <Hint>{'This till PC sends only the payment names – install the newest Aronium Link on it for exact amounts.'}</Hint> : null}
              <Btn testID={`sd-balance-${t.source}`} title="Balance this till now" icon="🧮" size="sm" variant="secondary"
                onPress={() => nav.push('TillCount', { shopCode: t.shop, shiftDate: d.date, zCash: (t.cashSales - t.cashRefunds).toFixed(2), zTotal: Object.values(t.payments).reduce((a, b) => a + b, 0).toFixed(2), openingFloat: t.float.toFixed(2) })} />
            </View>
          ))}
          <Hint>Worked out from the sales the till PC has sent (every few minutes). Cash paid out or dropped to the safe is entered when you balance.</Hint>
        </Section>
      ) : null}
      {L.payments.length ? (
        <Section title="How it was paid">
          {L.payments.map((p) => <ListItem key={p.name} testID={`sd-pay-${p.name}`} title={p.name} right={$(p.amount)} />)}
        </Section>
      ) : null}
      {d.receipts.length ? (
        <Section title={`Receipts (${d.receipts.length})`}>
          {d.receipts.slice(0, show).map((r) => (
            <ListItem key={`${r.source}${r.no}${r.time}`} testID={`sd-rc-${r.no}`} tone={r.refund ? 'danger' : undefined}
              title={`${r.time.slice(0, 5)}  ${r.refund ? '↩︎ REFUND ' : ''}${r.no ? `#${r.no}` : ''}`} right={`${r.refund ? '−' : ''}${$(r.total)}`}
              rightSub={r.pays.length ? r.pays.map((p) => p.name).join(' + ') : (r.pay || '')}
              sub={`${r.shop}${r.source.split('-')[1] ? ` ${r.source.split('-')[1]}` : ''}${r.who ? ` · ${r.who}` : ''}${r.lines ? ` · ${r.lines} line${r.lines === 1 ? '' : 's'}` : ''}${r.pays.length > 1 ? ` · ${r.pays.map((p) => `${p.name} ${$(p.amount)}`).join(', ')}` : ''}`} />
          ))}
          {d.receipts.length > show ? <Btn testID="sd-more" title={`Show more (${d.receipts.length - show})`} size="sm" variant="secondary" onPress={() => setShow((n) => n + 100)} /> : null}
        </Section>
      ) : (isToday ? <Hint>Each receipt shows here a few minutes after it is made, once the till PC has the newest Aronium Link.</Hint> : null)}
      {d.hours.length ? (
        <Section title="By hour">
          {d.hours.map((x) => (
            <View key={x.hour} style={{ gap: 2 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: C.text, fontWeight: '700' }}>{`${x.hour}:00`}</Text><Text style={{ color: C.sub }}>{`${$(x.value)} · ${x.receipts} receipts`}</Text></View>
              <View style={{ height: 8, borderRadius: 4, backgroundColor: C.border }}><View style={{ width: `${maxH ? Math.max(2, Math.round((x.value / maxH) * 100)) : 0}%`, height: 8, borderRadius: 4, backgroundColor: C.info }} /></View>
            </View>
          ))}
        </Section>
      ) : null}
      {d.cashiers.length ? (
        <Section title="Cashiers">
          {d.cashiers.map((c) => <ListItem key={c.name} title={c.name} right={$(c.sales)} sub={`${c.receipts} receipts${c.refunds ? ` · ${c.refunds} refunds` : ''}${c.voids ? ` · ${c.voids} voids` : ''}`} />)}
        </Section>
      ) : null}
      <Section title={`Products (${d.products.length})`}>
        {!d.products.length ? <Hint>No product lines from the till PCs for this day.</Hint> : null}
        {d.products.slice(0, 300).map((p) => <ListItem key={`${p.shop}${p.code}${p.name}`} title={p.name} sub={`${p.shop} · ${p.code || ''}`} right={$(p.value)} rightSub={`${p.qty} sold`} />)}
      </Section>
    </Screen>
  );
}
