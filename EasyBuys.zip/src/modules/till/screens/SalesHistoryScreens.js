// v1.0.0 Sales history: day by day per shop and till; tap a day for its products, hours and cashiers.
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, Chips, Section, useApp, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ListItem, Stats, Hint } from '../../../ui/kit.js';
import { dateStr, addDays } from '../../../services/core.js';
import { salesHistory, salesDay } from '../salesHistory.js';

const $ = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const RANGES = [{ value: '7', label: '7 days' }, { value: '30', label: '30 days' }, { value: '90', label: '3 months' }, { value: '365', label: 'Year' }];

export function SalesHistoryScreen() {
  const { nav } = useApp();
  const [range, setRange] = useRemembered('sh-range', '30');
  const [shop, setShop] = useRemembered('sh-shop', '');
  const to = dateStr();
  const from = addDays(to, -(Number(range) || 30) + 1);
  const h = useMemo(() => { try { return salesHistory({ from, to, shop }); } catch (e) { return { error: e.message }; } }, [range, shop]);
  if (h.error) return <Screen title="Sales history"><Banner tone="danger" message={h.error} /></Screen>;
  const max = Math.max(0, ...h.days.map((d) => d.total));
  return (
    <Screen title="Sales history" subtitle={`${from} to ${to}`}
      footer={<Btn testID="sh-pdf" title="PDF / Excel" icon="📄" variant="primary" onPress={() => nav.push('ReportView', { kind: 'till_sales_history', from, to, shop })} />}>
      <Chips value={shop} onChange={setShop} testIDPrefix="sh-shop" options={[{ value: '', label: 'Both shops' }, { value: 'S1', label: 'Shop 1' }, { value: 'S2', label: 'Shop 2' }]} />
      <Chips value={range} onChange={setRange} testIDPrefix="sh-range" options={RANGES} />
      <Stats items={[{ label: 'Sales', value: $(h.total) }, { label: 'Per trading day', value: $(h.perDay) }, h.best ? { label: 'Best day', value: $(h.best.total), sub: `${h.best.day} ${h.best.date}` } : null]} />
      {!h.days.length ? <Banner tone="info" title="No sales yet" message="Sales come from the till PCs (Aronium link) every few minutes, and from each Aronium End of day. If none show, check Settings › Aronium link (till PCs)." /> : null}
      {h.days.map((d) => (
        <ListItem key={d.date} testID={`sh-day-${d.date}`} title={`${d.day} ${d.date}`} right={$(d.total)}
          sub={Object.entries(d.shops).map(([s, x]) => `${s} ${$(x.value)}${Object.keys(x.tills).length > 1 ? ` (${Object.entries(x.tills).map(([t, v]) => `${t.split('-')[1] || t} ${$(v)}`).join(', ')})` : ''}${x.eod ? ` · VAT ${$(x.eod.vat)}` : ''}`).join(' · ')}
          rightSub={d.receipts ? `${d.receipts} receipts` : (d.fromTill ? 'live' : 'End of day')}
          onPress={() => nav.push('SalesDay', { date: d.date, shop })} />
      ))}
      {max ? <Hint>Tap a day for its products, the busy hours and each cashier.</Hint> : null}
    </Screen>
  );
}

export function SalesDayScreen({ params = {} }) {
  const d = useMemo(() => { try { return salesDay(params.date, { shop: params.shop || '' }); } catch (e) { return null; } }, [params.date, params.shop]);
  if (!d) return <Screen title="Sales"><Banner tone="danger" message="Could not read that day." /></Screen>;
  const maxH = Math.max(0, ...d.hours.map((x) => x.value));
  return (
    <Screen title={`Sales ${d.date}`} subtitle={`${params.shop || 'Both shops'} · ${$(d.total)} from the till PCs`}>
      {d.hours.length ? (
        <Section title="By hour">
          {d.hours.map((x) => (
            <View key={x.hour} style={{ gap: 2 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ color: C.text, fontWeight: '700' }}>{`${x.hour}:00`}</Text><Text style={{ color: C.sub }}>{`${$(x.value)} · ${x.receipts} receipts`}</Text></View>
              <View style={{ height: 8, borderRadius: 4, backgroundColor: C.border }}><View style={{ width: `${maxH ? Math.max(2, Math.round((x.value / maxH) * 100)) : 0}%`, height: 8, borderRadius: 4, backgroundColor: C.info }} /></View>
            </View>
          ))}
        </Section>
      ) : null}
      {d.cashiers.length ? (
        <Section title="Cashiers">
          {d.cashiers.map((c) => <ListItem key={c.name} title={c.name} right={$(c.sales)} sub={`${c.receipts} receipts${c.refunds ? ` · ${c.refunds} refunds` : ''}${c.voids ? ` · ${c.voids} voids` : ''}`} />)}
        </Section>
      ) : null}
      <Section title={`Products (${d.products.length})`}>
        {!d.products.length ? <Hint>No product lines from the till PCs for this day.</Hint> : null}
        {d.products.slice(0, 300).map((p) => <ListItem key={`${p.shop}${p.code}${p.name}`} title={p.name} sub={`${p.shop} · ${p.code || ''}`} right={$(p.value)} rightSub={`${p.qty} sold`} />)}
      </Section>
    </Screen>
  );
}
