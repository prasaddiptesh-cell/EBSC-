// 1.0.0 (build 1) Start shift, Handover notes and End shift – the screens the staff use every day (the map "Try the new
// app": s-start, s-hand, s-end, s-count, s-cigcount, s-endok and their bakery versions), and two office checks
// (o-till: check a till balance, o-cig: the cigarette lot). Big buttons, plain words, drop-downs for every choice.
// The End shift is ONE page, top to bottom; each step opens in place. Finish stays grey until all is done.
import React, { useState } from 'react';
import { View, Pressable, TextInput } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Select, PhotoPicker, Label, useApp, useUI, useLayout, useRemembered, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, MoneyField, ListItem } from '../../../ui/kit.js';
import { SignaturePad } from '../../../ui/signature.js';
import { dateStr, money } from '../../../services/core.js';
import * as ES from '../endShift.js';
import * as T from '../service.js';
import * as HN from '../../../services/handoverNotes.js';
import * as D from '../../../services/duties.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const hm = (s) => { const t = String(s || '').slice(11, 16); if (!t) return ''; const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`; };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };

// One step of a page: a title, what is on the right (✓, $5.00 short …) and a line under it. Tapping opens it.
function Step({ testID, title, right, sub, tone, open, onPress, children }) {
  const col = tone === 'ok' ? C.success : tone === 'bad' ? C.danger : tone === 'warn' ? C.warn : C.sub;
  return (
    <View style={{ backgroundColor: C.card, borderRadius: 16, borderWidth: open ? 2 : 1, borderColor: open ? C.info : C.border, overflow: 'hidden' }}>
      <Pressable testID={testID} onPress={onPress} disabled={!onPress} style={({ pressed }) => ({ padding: 16, gap: 4, opacity: pressed ? 0.7 : 1 })}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Text style={{ flex: 1, fontSize: 20, fontWeight: '800', color: C.text }}>{title}</Text>
          {right ? <Text style={{ fontSize: 18, fontWeight: '900', color: col }}>{right}</Text> : null}
          {onPress ? <Text style={{ fontSize: 20, color: C.sub }}>{open ? '▴' : '▾'}</Text> : null}
        </View>
        {sub ? <Text style={{ fontSize: 16, color: C.sub }}>{sub}</Text> : null}
      </Pressable>
      {open && children ? <View style={{ paddingHorizontal: 16, paddingBottom: 16, gap: 12 }}>{children}</View> : null}
    </View>
  );
}
function Tick({ testID, text, on, onPress, note }) {
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 56, paddingVertical: 6, opacity: pressed ? 0.6 : 1 })}>
      <View style={{ width: 34, height: 34, borderRadius: 8, borderWidth: 2, borderColor: on ? C.success : C.border, backgroundColor: on ? C.success : C.white, alignItems: 'center', justifyContent: 'center' }}>
        {on ? <Text style={{ color: C.white, fontSize: 20, fontWeight: '900' }}>✓</Text> : null}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 18, color: C.text }}>{text}</Text>
        {note ? <Text style={{ fontSize: 14, color: C.warn }}>{note}</Text> : null}
      </View>
    </Pressable>
  );
}
// Notes and coins: how many of each (never dollars).
export function Notes({ value, onChange, testIDPrefix }) {
  const { isPhone } = useLayout();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {T.DENOMS.map((d) => {
        const n = Number(value[d.key]) || 0;
        return (
          <View key={d.key} style={{ width: isPhone ? '48%' : 170, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.bg, borderRadius: 12, padding: 6 }}>
            <Text style={{ width: 50, fontSize: 19, fontWeight: '900', color: C.text }}>{d.label}</Text>
            <TextInput testID={`${testIDPrefix}-${d.key}`} value={value[d.key] === undefined ? '' : String(value[d.key])} keyboardType="number-pad" placeholder="0"
              onChangeText={(t) => onChange({ ...value, [d.key]: t.replace(/\D/g, '').slice(0, 5) })}
              style={{ flex: 1, minWidth: 44, borderWidth: 2, borderColor: n ? C.info : C.border, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 8, fontSize: 22, fontWeight: '800', color: C.text, backgroundColor: C.white, textAlign: 'center' }} />
            {!isPhone ? <Text style={{ width: 62, textAlign: 'right', fontSize: 14, color: n ? C.text : C.sub }}>{n ? $(n * d.value) : ''}</Text> : null}
          </View>
        );
      })}
    </View>
  );
}
function Checklist({ duty, user, shopCode, date, onChange, prefix }) {
  const ui = useUI();
  if (!duty) return <Hint>No checklist for your job. The admin switches checklists on in Settings.</Hint>;
  return (
    <View>
      {duty.items.map((it) => (
        <Tick key={it.id} testID={`${prefix}-${it.id}`} text={it.text} on={!!duty.ticks[it.id]} note={duty.skipped[it.id] ? `Not done: ${duty.skipped[it.id]}` : null}
          onPress={() => { if (duty.done) return; try { D.tickDuty(user, it.id, !duty.ticks[it.id], { date, shopCode }); onChange(); } catch (e) { ui.error(e); } }} />
      ))}
    </View>
  );
}

// ================================================================ Start shift (s-start)
export function StartMyShiftScreen() {
  const { user, nav, openClock } = useApp();
  const ui = useUI();
  useTick(30000);
  const [, bump] = useState(0);
  const [pick, setPick] = useRemembered('pick', {});
  let info = null; let err = null;
  try { info = ES.startInfo(user, pick); } catch (e) { err = e.message; }
  if (!info) return <Screen title="Start shift"><Banner tone="warn" message={err || 'Not available.'} /></Screen>;
  const bakery = info.kind === 'bakery';
  const started = info.open;
  const ck = info.clock;
  const shopCode = bakery ? HN.BAKERY : info.shopCode;
  const start = () => {
    try {
      const r = ES.startShift(user, { shopCode: info.shopCode, tillUid: info.tillUid, shift: info.shift, mpOpen: pick.mpOpen });
      if (r.warning) ui.alert({ title: 'Shift started', message: `${r.warning}\nTell the manager.`, tone: 'warn' });
      else ui.toast('Shift started');
      bump((x) => x + 1);
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Start shift" subtitle={bakery ? `Bakery · ${info.shift}` : `${info.till ? info.till.name : 'Till'} · ${info.shift}`}>
      <Step testID="ss-clock" title={ck.state === 'out' ? 'Clock in' : 'Clocked in'} right={ck.state === 'out' ? 'not yet' : hm(ck.since)} tone={ck.state === 'out' ? 'bad' : 'ok'}
        sub={ck.state === 'out' ? 'Clock in on the Time Clock with your face, then come back here.' : ck.state === 'break' ? 'On a break' : 'On the Time Clock'} />
      {ck.state === 'out' && openClock ? <Btn testID="ss-open-clock" title="Clock in on the Time Clock" icon="⏱️" variant="success" onPress={openClock} /> : null}
      {!started ? (
        <Card>
          <View style={{ gap: 12 }}>
            {!bakery && info.shops.length > 1 ? <Select testID="ss-shop" label="Shop" value={info.shopCode} onChange={(v) => setPick({ ...pick, shopCode: v, tillUid: '' })} options={info.shops.map((s) => ({ value: s.code, label: s.name }))} /> : null}
            {!bakery && info.tills.length > 1 ? <Select testID="ss-till" label="Till" value={info.tillUid} onChange={(v) => setPick({ ...pick, tillUid: v })} options={info.tills.map((t) => ({ value: t.uid, label: t.name }))} /> : null}
            <Select testID="ss-shift" label="Shift" value={info.shift} onChange={(v) => setPick({ ...pick, shift: v })} options={info.shifts.map((s) => ({ value: s, label: s }))} />
          </View>
        </Card>
      ) : <Step testID="ss-started" title="Shift started" right={hm(started.started_at)} tone="ok" sub={bakery ? 'Bakery' : `${started.till_name || ''} · ${started.shift}`} />}
      {!bakery && info.float ? (
        <Step testID="ss-float" title={`Float in ${info.till ? info.till.name : 'the till'}`} right={$(started && started.float_start !== null ? started.float_start : info.float.amount)} tone="ok"
          sub={info.float.from === 'Aronium' ? 'From Aronium when you opened the shift' : 'Aronium has not sent it yet – this is the float the till was left with'} />
      ) : null}
      {!bakery && info.mp && !started ? (
        <Card>
          <MoneyField testID="ss-mp" label={`M-PAiSA wallet balance now (${info.mp.wallet.name})`} value={pick.mpOpen !== undefined ? pick.mpOpen : (info.mp.last ? String(info.mp.last.amount) : '')} onChange={(v) => setPick({ ...pick, mpOpen: v })} />
          <Hint>{info.mp.last ? `Look at the M-PAiSA phone. The last shift closed at ${$(info.mp.last.amount)} – change it only if the phone says something else.` : 'Look at the M-PAiSA phone and type the balance.'}</Hint>
        </Card>
      ) : null}
      {!bakery && info.mp && started && started.mp_open !== null && started.mp_open !== undefined ? <Step testID="ss-mp-done" title="M-PAiSA at the start" right={$(started.mp_open)} tone="ok" /> : null}
      {!bakery && !info.till ? <Banner tone="warn" message="There is no till at this shop yet. The admin adds it in Settings › Tills & rules." /> : null}
      {info.unread.length ? (
        <Card tone="warn">
          <H>{`Handover notes for you (${info.unread.length})`}</H>
          {info.unread.map((n) => <Text key={n.uid} style={{ fontSize: 17, color: C.text, paddingVertical: 4 }}>{`${hm(n.at)} – ${n.text} (${n.by_name})`}</Text>)}
          <Btn testID="ss-read" title="I have read them" size="md" variant="secondary" onPress={() => { HN.markRead(user, info.unread.map((n) => n.uid)); bump((x) => x + 1); }} />
        </Card>
      ) : null}
      <Label>{bakery ? 'Bakery checklist – tick during the shift' : `${(info.shops.find((s) => s.code === info.shopCode) || { name: info.shopCode }).name} checklist – tick during the shift`}</Label>
      <Card><Checklist duty={info.duty} user={user} shopCode={shopCode} date={info.date} prefix="ss-tick" onChange={() => bump((x) => x + 1)} /></Card>
      {!started ? <Btn testID="ss-start" title="Start my shift" icon="▶️" variant="success" disabled={ck.state === 'out' || (!bakery && !info.till)} onPress={start} /> : null}
      <Btn testID="ss-done" title="Done for now" variant="secondary" onPress={() => nav.pop()} />
    </Screen>
  );
}
export const BakeryStartMyShiftScreen = StartMyShiftScreen;

// ================================================================ Handover notes (s-hand)
export function HandoverNotesScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const [text, setText] = useState('');
  const [, bump] = useState(0);
  const info = safe(() => ES.startInfo(user, {}), null);
  const place = params.place || (info ? info.place : user.shop_code) || 'S1';
  const notes = HN.listNotes({ place });
  const add = () => { try { HN.addNote(user, { place, text, shift: info ? info.shift : '' }); setText(''); ui.toast('Note added'); bump((x) => x + 1); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Handover notes" subtitle={place === HN.BAKERY ? 'Bakery' : place}>
      <Hint>Write anything the next shift should know. They read the notes when they take over.</Hint>
      {!notes.length ? <Text style={{ fontSize: 17, color: C.sub }}>No notes yet.</Text> : null}
      {notes.map((n) => (
        <View key={n.uid} style={{ backgroundColor: C.card, borderRadius: 14, borderWidth: 1, borderColor: C.border, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 18, color: C.text }}>{`${hm(n.at)} – ${n.text}`}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>{`${n.by_name}${n.note_date !== dateStr() ? ` · ${n.note_date}` : ''}`}</Text>
          </View>
          {n.by_uid === user.uid ? <Btn testID={`hn-cross-${n.uid}`} title="Cross out" size="sm" variant="ghost" onPress={() => { try { HN.crossOut(user, n.uid); bump((x) => x + 1); } catch (e) { ui.error(e); } }} /> : null}
        </View>
      ))}
      <Field testID="hn-text" label="Add a note…" value={text} onChangeText={setText} multiline maxLength={500} />
      <Btn testID="hn-add" title="Add note" icon="📝" variant="success" disabled={text.trim().length < 2} onPress={add} />
    </Screen>
  );
}

// ================================================================ End shift (s-end, s-count, s-cigcount)
export function EndMyShiftScreen() {
  const { user, nav } = useApp();
  const ui = useUI();
  useTick(30000);
  const [, bump] = useState(0);
  const [f, setF] = useRemembered('end', { denominations: {}, cigClosing: {}, open: '' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const toggle = (k) => setF((o) => ({ ...o, open: o.open === k ? '' : k }));
  let plan = null; let err = null;
  try { plan = ES.endPlan(user, { shift: f.shift }); } catch (e) { err = e.message; }
  if (!plan) return <Screen title="End shift"><Banner tone="warn" message={err || 'Not available.'} /></Screen>;
  const bakery = plan.kind === 'bakery';
  const input = { ...f, shift: plan.shift, manualZ: f.manual ? f.manualZ || {} : undefined };
  const blockers = ES.blockersFor(plan, input);
  const w = !bakery && plan.till ? ES.workOutEnd(plan, input) : null;
  const odd = w && w.expected !== null && w.counted > 0 ? ES.sanityProblems({ counted: w.counted, expected: w.expected, zCash: w.z && w.z.zCash, zTotal: w.z && w.z.zTotal, aroniumCash: w.z && w.z.source === 'manual' ? plan.aroniumCashNow : null, tenders: w.z ? w.z.tenders : [], denominations: f.denominations }) : [];
  const stop = odd.filter((p) => p.level === 'stop');
  const checkOdd = odd.filter((p) => p.level === 'check');
  const tol = plan.rules ? plan.rules.tolerance : 2;
  const short = w && w.overShort !== null && w.overShort < -tol - 0.004;
  const finish = (override) => {
    try {
      const r = ES.finishShift(user, { ...input, override, confirmOdd: f.confirmOdd });
      setF({ denominations: {}, cigClosing: {}, open: '' });
      nav.replace('ShiftFinished', { uid: r.uid });
    } catch (e) { ui.error(e); }
  };
  // ---- cigarettes: the tally worked out as the cabinet is counted
  let cw = null;
  if (!bakery && plan.cig && plan.cig.on && !plan.cig.done) { try { cw = require('../cigTally.js').workOutTally({ shopCode: plan.shopCode, date: plan.date, shift: plan.shift, closing: f.cigClosing || {} }); } catch (e) { cw = null; } }
  const eod = plan.eod;
  const mpp = !bakery && plan.till && w && w.z ? safe(() => require('../mpaisaShift.js').mpPlan({ shopCode: plan.shopCode, tillUid: plan.till.uid, date: plan.date, tenders: w.z.tenders }), null) : null;
  const duty = plan.duty;
  const dutyLeft = duty ? duty.total - duty.ticked - duty.skippedN : 0;
  const people = plan.staff.map((p) => ({ value: p.uid, label: p.name }));
  const canFinish = !blockers.length && !stop.length && (!checkOdd.length || f.confirmOdd);
  const first = stop[0] ? stop[0].text : blockers[0] ? blockers[0].text : checkOdd.length && !f.confirmOdd ? 'Check the figures first' : '';
  return (
    <Screen title="End shift" subtitle={bakery ? `Bakery · ${plan.shift}` : `${plan.till ? plan.till.name : 'Till'} · ${plan.shift}`}>
      {!plan.open && !plan.eod ? <Select testID="es-shift" label="Which shift" value={plan.shift} onChange={set('shift')} options={plan.shifts.map((s) => ({ value: s, label: s }))} /> : null}
      {bakery ? (
        <>
          <Step testID="es-baked" title="1 · What we baked" right={plan.baked.total ? '✓ saved' : 'nothing yet'} tone={plan.baked.total ? 'ok' : 'bad'}
            sub={plan.baked.total ? plan.baked.lines.map((l) => `${l.qty} ${l.name}`).join(', ') : 'Enter each batch in the Bakery.'} open={f.open === 'baked'} onPress={() => toggle('baked')}>
            {plan.baked.active ? <Banner tone="warn" message={`${plan.baked.active} batch${plan.baked.active === 1 ? ' is' : 'es are'} still running – finish ${plan.baked.active === 1 ? 'it' : 'them'} in the Bakery.`} /> : null}
            <Btn testID="es-bake-open" title="Open the Bakery" size="md" variant="secondary" onPress={() => nav.push('Area', { area: 'bakery' })} />
          </Step>
          <Step testID="es-waste" title="2 · Wastage" right={plan.baked.wastage ? String(plan.baked.wastage) : 'none'} sub="Burnt or spoiled? Add it under Something happened, or in the Bakery." onPress={() => nav.push('Wastage', {})} />
        </>
      ) : (
        <>
          {/* 1 · Aronium End of day */}
          {eod ? (
            <Step testID="es-eod" title="1 · Aronium End of day" right="✓ in" tone="ok"
              sub={`Z ${eod.zNumber} · ${plan.shift} · sales ${$(eod.total)} · cash ${$(eod.cash === null ? eod.total : eod.cash)}${eod.tenders.map((t) => ` · ${t.method} ${$(t.amount)}`).join('')} · float ${$(plan.float.amount)}${eod.cashIn ? ` · cash in ${$(eod.cashIn)}` : ''}${eod.cashOut ? ` · cash out ${$(eod.cashOut)}` : ''}`} />
          ) : (
            <Step testID="es-eod" title="1 · Aronium End of day" right={f.manual ? 'typed' : 'not in'} tone={f.manual ? 'warn' : 'bad'} open={f.open === 'eod'} onPress={() => toggle('eod')}
              sub={f.manual ? `Z ${(f.manualZ || {}).zNumber || '—'} · sales ${$((f.manualZ || {}).total)} · photo ${((f.manualZ || {}).photos || []).length ? '✓' : 'needed'}` : 'Do the End of day on the till PC. It comes in by itself in a minute.'}>
              <Btn testID="es-eod-again" title="Check again" icon="🔄" size="md" variant="secondary" onPress={() => { try { require('../../../platform/cloud.js').syncNow().catch(() => {}).then(() => bump((x) => x + 1)); } catch (e) { bump((x) => x + 1); } }} />
              {!f.manual ? <Btn testID="es-eod-manual" title="The till PC is off – type the Z report" size="md" variant="warn" onPress={() => setF((o) => ({ ...o, manual: true, manualZ: o.manualZ || {} }))} /> : (
                <View style={{ gap: 10 }}>
                  <Hint>Only when Aronium did not send its End of day. Copy from the printed Z report and take a photo of it.</Hint>
                  <Field testID="es-z-no" label="Z number" value={(f.manualZ || {}).zNumber || ''} onChangeText={(v) => setF((o) => ({ ...o, manualZ: { ...o.manualZ, zNumber: v } }))} keyboardType="number-pad" />
                  <MoneyField testID="es-z-total" label="Total sales" value={(f.manualZ || {}).total} onChange={(v) => setF((o) => ({ ...o, manualZ: { ...o.manualZ, total: v } }))} />
                  <MoneyField testID="es-z-cash" label="Cash" value={(f.manualZ || {}).cash} onChange={(v) => setF((o) => ({ ...o, manualZ: { ...o.manualZ, cash: v } }))} />
                  <MoneyField testID="es-z-mp" label="M-PAiSA" value={(f.manualZ || {}).mpaisa} onChange={(v) => setF((o) => ({ ...o, manualZ: { ...o.manualZ, mpaisa: v } }))} />
                  <PhotoPicker testID="es-z-photo" label="Photo of the Z report" required value={(f.manualZ || {}).photos || []} onChange={(v) => setF((o) => ({ ...o, manualZ: { ...o.manualZ, photos: v } }))} />
                  <Btn testID="es-z-cancel" title="Aronium came in – don't type it" size="sm" variant="ghost" onPress={() => setF((o) => ({ ...o, manual: false }))} />
                </View>
              )}
            </Step>
          )}
          {/* 2 · Count the cash */}
          <Step testID="es-count" title="2 · Count the cash" open={f.open === 'count'} onPress={() => toggle('count')}
            right={!w || !w.counted ? 'tap to count' : w.overShort === null ? $(w.counted) : Math.abs(w.overShort) < 0.005 ? '✓ balanced' : w.overShort < 0 ? `${$(-w.overShort)} short` : `${$(w.overShort)} over`}
            tone={!w || !w.counted ? 'bad' : w.overShort === null || Math.abs(w.overShort) <= tol ? 'ok' : 'warn'}
            sub={w && w.counted ? `Counted ${$(w.counted)} – tap to change` : 'Notes and coins only – the app does the sums'}>
            <Notes value={f.denominations || {}} onChange={set('denominations')} testIDPrefix="es-n" />
            <Row label="Counted" value={$(w ? w.counted : 0)} bold />
            {w && w.expected !== null ? <Row label="Should be (Aronium cash + float)" value={$(w.expected)} /> : <Text style={{ fontSize: 15, color: C.sub }}>What should be in the till shows once Aronium's End of day is in.</Text>}
            {w && w.expected !== null && w.counted ? <Row label={Math.abs(w.overShort) < 0.005 ? 'Balanced' : w.overShort < 0 ? 'Short' : 'Over'} value={$(Math.abs(w.overShort))} bold color={Math.abs(w.overShort) <= tol ? C.success : C.warn} /> : null}
            {(plan.paidOuts || []).length ? <Hint>{`Paid out of this till today: ${plan.paidOuts.map((p) => `${p.supplier_name} ${$(p.amount)}`).join(', ')} – already taken off.`}</Hint> : null}
            {short ? <Select testID="es-short" label="Short paid now?" value={f.shortAction || 'pay'} onChange={set('shortAction')} options={[{ value: 'pay', label: 'No – take it from my pay' }, { value: 'paid_now', label: 'Yes – I pay it now (the person checking takes it)' }]} /> : null}
            {plan.ownTill && f.shortAction !== 'paid_now' ? <Hint>You count your own till. Someone in the office checks it.</Hint> : (
              <>
                <Select testID="es-checker" label={plan.ownTill ? 'Who takes the money' : 'Who checked the count with you'} value={f.checkerUid || ''} onChange={set('checkerUid')} options={plan.checkers.map((p) => ({ value: p.uid, label: p.name }))} />
                {f.checkerUid ? <SignaturePad value={f.checkerSig || null} onChange={set('checkerSig')} testID="es-checker-sig" label={`${(plan.checkers.find((p) => p.uid === f.checkerUid) || {}).name || 'They'} sign`} /> : null}
              </>
            )}
            <Btn testID="es-count-done" title="Done" size="md" variant="secondary" onPress={() => toggle('count')} />
          </Step>
          {mpp ? <MpBox mp={mpp} value={f.mpClose} onChange={set('mpClose')} action={f.mpAction || 'pay'} onAction={set('mpAction')} note={f.mpNote || ''} onNote={set('mpNote')} tol={tol} prefix="es" name={user.name} /> : null}
          {/* 3 · Cigarettes */}
          {plan.cig && plan.cig.on ? (
            <Step testID="es-cig" title="3 · Cigarettes" open={f.open === 'cig'} onPress={plan.cig.done ? null : () => toggle('cig')}
              right={plan.cig.done ? '✓' : cw && !cw.uncounted ? '✓' : 'count them'} tone={plan.cig.done || (cw && !cw.uncounted) ? 'ok' : 'bad'}
              sub={plan.cig.done ? 'Counted for this shift' : cw && !cw.uncounted ? `Sold ${cw.countedPackets ?? '–'}${cw.aroniumPackets !== null ? ` · Aronium ${cw.aroniumPackets}` : ''} · put aside ${$(cw.suggested)}` : 'Count the cabinet; the app says what to put aside'}>
              {plan.cig.items.map((it) => (
                <View key={it.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Text style={{ flex: 1, fontSize: 18, color: C.text }}>{`${it.name} – in cabinet`}</Text>
                  <TextInput testID={`es-cig-${it.code}`} value={(f.cigClosing || {})[it.uid] === undefined ? '' : String(f.cigClosing[it.uid])} keyboardType="number-pad" placeholder="0"
                    onChangeText={(t) => setF((o) => ({ ...o, cigClosing: { ...o.cigClosing, [it.uid]: t.replace(/\D/g, '') } }))}
                    style={{ width: 90, borderWidth: 2, borderColor: C.border, borderRadius: 10, padding: 8, fontSize: 22, fontWeight: '800', textAlign: 'center', backgroundColor: C.white, color: C.text }} />
                </View>
              ))}
              {cw && cw.aroniumPackets !== null && cw.countedPackets !== null ? (
                <View style={{ backgroundColor: cw.diffs.length ? C.warnSoft : C.successSoft, borderRadius: 12, padding: 10 }}>
                  <Text style={{ fontSize: 17, color: C.text }}>{`Aronium sold ${cw.aroniumPackets} · cabinet says ${cw.countedPackets} gone ${cw.diffs.length ? '– not the same' : '✓'}`}</Text>
                </View>
              ) : null}
              {cw && cw.diffs.length ? <Field testID="es-cig-why" label="Why is it different?" value={f.cigReason || ''} onChangeText={set('cigReason')} /> : null}
              {cw ? <Row label="Put in the cigarette bag" value={$(cw.suggested)} bold /> : null}
              <Btn testID="es-cig-done" title="Done" size="md" variant="secondary" onPress={() => toggle('cig')} />
            </Step>
          ) : null}
        </>
      )}
      {/* checklist */}
      <Step testID="es-check" title={`${bakery ? 3 : plan.cig && plan.cig.on ? 4 : 3} · Checklist`} open={f.open === 'check'} onPress={() => toggle('check')}
        right={duty ? (duty.done ? '✓' : `${duty.ticked} of ${duty.total}`) : '—'} tone={!duty || duty.done || !dutyLeft ? 'ok' : 'bad'}
        sub={duty && dutyLeft ? `${duty.items.filter((it) => !duty.ticks[it.id] && !duty.skipped[it.id]).slice(0, 2).map((it) => it.text).join(', ')} – not ticked` : 'All ticked'}>
        <Checklist duty={duty} user={user} shopCode={bakery ? HN.BAKERY : plan.shopCode} date={plan.date} prefix="es-tick" onChange={() => bump((x) => x + 1)} />
      </Step>
      {/* handover */}
      <Step testID="es-hand" title={`${bakery ? 4 : plan.cig && plan.cig.on ? 5 : 4} · Handover`} open={f.open === 'hand'} onPress={() => toggle('hand')}
        right={`${plan.notes.length} note${plan.notes.length === 1 ? '' : 's'}`} tone={f.takerUid ? 'ok' : 'bad'}
        sub={f.takerUid ? `Taking over: ${(plan.staff.find((p) => p.uid === f.takerUid) || {}).name || ''}` : 'Who takes over?'}>
        <Select testID="es-taker" label="Who takes over" value={f.takerUid || ''} onChange={set('takerUid')} options={people} />
        <Btn testID="es-notes" title="Handover notes" icon="📝" size="md" variant="secondary" onPress={() => nav.push('HandoverNotes', { place: plan.place })} />
      </Step>
      {!bakery ? <SignaturePad value={f.signature || null} onChange={set('signature')} testID="es-sig" label={`${user.name}, sign to finish`} /> : null}
      {stop.length ? <Banner testID="es-stop" tone="danger" message={stop.map((p) => p.text).join('\n')} /> : null}
      {checkOdd.length ? (
        <Card tone="warn">
          <Text style={{ fontSize: 17, color: C.text }}>{checkOdd.map((p) => p.text).join('\n')}</Text>
          <Btn testID="es-odd-ok" title={f.confirmOdd ? '✓ Yes, the figures are right' : 'Yes, the figures are right'} size="md" variant={f.confirmOdd ? 'success' : 'secondary'} onPress={() => setF((o) => ({ ...o, confirmOdd: !o.confirmOdd }))} />
        </Card>
      ) : null}
      <Btn testID="es-finish" title={canFinish ? 'Finish shift' : `Finish shift – ${first.replace(/\.$/, '').toLowerCase()}`} icon={canFinish ? '✅' : undefined} variant="success" disabled={!canFinish} onPress={() => finish(undefined)} />
      <AdminOverride blockers={blockers} disabled={!!stop.length || blockers.some((b) => b.hard)} onFinish={finish} />
    </Screen>
  );
}
export const BakeryEndMyShiftScreen = EndMyShiftScreen;

// The owner / admin lets the shift finish without everything done – their PIN, and why.
function AdminOverride({ blockers, disabled, onFinish }) {
  const [open, setOpen] = useState(false);
  const [who, setWho] = useState('');
  const [pin, setPin] = useState('');
  const [why, setWhy] = useState('');
  const admins = safe(() => require('../../../services/catalog.js').listUsers({ includeInactive: false }).filter((u) => ['owner', 'admin'].includes(u.role)), []);
  if (!blockers.length) return null;
  if (!open) return <Text testID="es-admin" onPress={() => setOpen(true)} style={{ fontSize: 16, color: C.sub, textAlign: 'center', paddingVertical: 10, textDecorationLine: 'underline' }}>Admin can override with their PIN</Text>;
  return (
    <Card tone="warn">
      <H>Finish without everything done</H>
      <Text style={{ fontSize: 16, color: C.text }}>{`Not done: ${blockers.map((b) => b.text).join(' ')}`}</Text>
      <Select testID="es-admin-who" label="Owner or admin" value={who} onChange={setWho} options={admins.map((a) => ({ value: a.uid, label: a.name }))} />
      <Field testID="es-admin-pin" label="Their PIN" value={pin} onChangeText={(t) => setPin(t.replace(/\D/g, '').slice(0, 6))} keyboardType="number-pad" secure />
      <Field testID="es-admin-why" label="Why" value={why} onChangeText={setWhy} />
      <Btn testID="es-admin-go" title="Finish with the PIN" variant="warn" disabled={disabled || !who || !pin || why.trim().length < 4} onPress={() => onFinish({ adminUid: who, pin, reason: why })} />
    </Card>
  );
}

// ================================================================ Shift finished (s-endok)
export function ShiftFinishedScreen({ params = {} }) {
  const { nav, logout } = useApp();
  const r = params.uid ? ES.getShiftEnd(params.uid) : null;
  if (!r) return <Screen title="Shift finished"><Banner tone="warn" message="Not found." /></Screen>;
  const os = r.over_short;
  return (
    <Screen title="Shift finished" subtitle={`${r.shift_date} · ${r.shift || ''}`}>
      <View style={{ alignItems: 'center', paddingVertical: 10 }}><Text testID="sf-ok" style={{ fontSize: 72, color: C.success }}>✓</Text></View>
      <Card>
        <Row label="Clocked out" value={hm(r.finished_at)} />
        {r.kind === 'till' && os !== null ? <Row label={Math.abs(os) < 0.005 ? 'Till' : os < 0 ? 'Short' : 'Over'} value={Math.abs(os) < 0.005 ? 'Balanced' : `${$(Math.abs(os))}${os < 0 ? (r.short_action === 'paid_now' ? ' – paid now' : r.short_action === 'pay' ? ' – from pay' : '') : ' – the office decides'}`} bold color={Math.abs(os) < 0.005 ? C.success : C.warn} /> : null}
        {r.cig_aside !== null && r.cig_aside !== undefined ? <Row label="Cigarette money" value={`${$(r.cig_aside)} in the bag`} /> : null}
        {r.own_till ? <Row label="Counted" value="Own till – the office checks it" /> : r.checker_name ? <Row label="Checked by" value={r.checker_name} /> : null}
        <Row label="Handed over to" value={r.taker_name || '—'} />
        {r.override_by_name ? <Row label="Let through by" value={`${r.override_by_name}: ${r.override_reason}`} color={C.warn} /> : null}
      </Card>
      {logout ? <Btn testID="sf-logout" title="Log out" variant="success" onPress={logout} /> : null}
      <Btn testID="sf-home" title="Back to home" variant="secondary" onPress={() => nav.home()} />
    </Screen>
  );
}

// 1.0.0 build 2: the M-PAiSA wallet at the end of the shift – what it should be, the balance on the phone, the result.
export function MpBox({ mp, value, onChange, action, onAction, note, onNote, tol = 0, prefix = 'mp', name = '' }) {
  const MPS = require('../mpaisaShift.js');
  const res = MPS.mpResult(mp, value, tol);
  const tone = res.state === 'balanced' ? [C.success, C.successSoft] : res.state === 'short' ? [C.danger, C.dangerSoft] : res.state === 'over' ? [C.warn, C.warnSoft] : [C.sub, C.card];
  return (
    <Card>
      <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>M-PAiSA wallet</Text>
      <Row label="At the start" value={$(mp.open)} />
      <Row label="M-PAiSA sales (Aronium)" value={$(mp.sales)} />
      {mp.outs ? <Row label="Paid out / sent to the bank" value={`− ${$(mp.outs)}`} /> : null}
      {mp.ins ? <Row label="Put in" value={$(mp.ins)} /> : null}
      <Row label="M-PAiSA should be" value={$(mp.expected)} bold color={C.info} />
      <MoneyField testID={`${prefix}-mp-close`} label="M-PAiSA wallet balance now (on the phone)" value={value} onChange={onChange} />
      {res.state !== 'none' ? (
        <View testID={`${prefix}-mp-result`} style={{ borderRadius: 14, padding: 12, backgroundColor: tone[1], borderWidth: 2, borderColor: tone[0] }}>
          <Text testID={`${prefix}-mp-${res.state}`} style={{ fontSize: 26, fontWeight: '900', color: tone[0], textAlign: 'center' }}>{res.state === 'balanced' ? 'M-PAiSA balanced ✓' : `M-PAiSA ${res.state === 'short' ? 'SHORT' : 'OVER'} ${$(res.amount)}`}</Text>
          {res.state === 'over' ? <Text style={{ fontSize: 16, color: C.text, textAlign: 'center' }}>Kept as an over for the office to decide.</Text> : null}
        </View>
      ) : null}
      {res.state === 'short' ? (
        <>
          <Select testID={`${prefix}-mp-action`} label="The M-PAiSA short" value={action} onChange={onAction} options={[{ value: 'pay', label: `Take from ${name || 'the cashier'}'s pay` }, { value: 'paid_now', label: 'Paid now in cash' }, { value: 'explain', label: 'Explain it (the office decides)' }]} />
          {action === 'explain' ? <Field testID={`${prefix}-mp-note`} label="Why is it short?" value={note} onChangeText={onNote} /> : null}
        </>
      ) : null}
    </Card>
  );
}

// ================================================================ Office: check a till balance (o-till)
export function TillCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [decide, setDecide] = useState('');
  const [why, setWhy] = useState('');
  const [, bump] = useState(0);
  const c = params.uid ? T.getTillCount(params.uid) : null;
  if (!c && !params.uid) {
    // 1.0.0 build 2: the list – every row names the shop and the till ("Shop 1 - Drasa Avenue · Till 1")
    const B = require('../balanceTill.js');
    const waiting = safe(() => B.waitingBalances(user), []);
    const toCheck = safe(() => T.listTillCounts({ status: 'counted', limit: 100 }), []).filter((x) => !user.shop_code || ['owner', 'admin'].includes(user.role) || x.shop_code === user.shop_code);
    return (
      <Screen title="Check a till balance" subtitle="Till balances to check">
        {waiting.length ? <Label>{`Waiting to be balanced (${waiting.length})`}</Label> : null}
        {waiting.map((w) => <ListItem key={w.uid} testID={`tck-wait-${w.uid}`} title={w.label} sub={`${w.z ? `Z ${w.z}` : 'Whole day'}${w.time ? ` · ${w.time}` : ''} · ${w.date} · Balance`} right={$(w.total)} tone="danger" onPress={() => nav.push(w.target.screen, w.target.params)} />)}
        <Label>{`To check (${toCheck.length})`}</Label>
        {!toCheck.length ? <Text style={{ fontSize: 17, color: C.sub }}>Nothing to check.</Text> : null}
        {toCheck.map((x) => <ListItem key={x.uid} testID={`tck-row-${x.uid}`} title={B.countWhere(x)} sub={`${x.shift} · ${x.shift_date} · ${x.cashier_name}${x.z_number ? ` · Z ${x.z_number}` : ''}`}
          right={Math.abs(x.over_short) < 0.005 ? 'Balanced' : x.over_short < 0 ? `Short ${$(-x.over_short)}` : `Over ${$(x.over_short)}`} onPress={() => nav.push('TillCheck', { uid: x.uid })} />)}
      </Screen>
    );
  }
  if (!c) return <Screen title="Check a till balance"><Banner tone="warn" message="Not found." /></Screen>;
  const tol = T.tillRules().tolerance;
  const short = c.over_short < -tol - 0.004 ? r2(-c.over_short) : 0;
  const own = ES.isOwnTill(c);
  const mine = c.counted_by_uid === user.uid || c.cashier_uid === user.uid;
  const S = safe(() => require('../shifts.js'), null);
  const sh = S ? S.shortageForCount(c.uid) : null;
  const go = () => {
    try {
      T.approveTillCount(user, c.uid, short && decide === 'write_off' ? { shortAction: 'write_off', writeOffReason: why } : {});
      ui.toast('Checked'); bump((x) => x + 1);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={safe(() => require('../balanceTill.js').countWhere(c), `${c.shop_code} · ${c.till_name}`)} subtitle={`${c.shift} · ${c.shift_date} · ${c.cashier_name}`}>
      <Card>
        <Row label="Aronium cash sales" value={$(c.z_cash)} />
        <Row label="Float" value={$(c.opening_float)} />
        <Row label="Counted" value={$(c.cash_counted)} bold />
        <Row label={Math.abs(c.over_short) < 0.005 ? 'Balanced' : c.over_short < 0 ? 'Short' : 'Over'} value={$(Math.abs(c.over_short))} bold color={Math.abs(c.over_short) <= tol ? C.success : C.warn} />
        <Row label="Counted by" value={own ? `${c.cashier_name} – own till` : `${c.cashier_name} with ${c.balancer_name || c.counted_by_name}`} color={own ? C.warn : undefined} />
        {sh ? <Row label="The short" value={S.SHORT_STATUS[sh.status] || sh.status} /> : null}
        <Row label="Status" value={c.status === 'approved' ? `Checked by ${c.approved_by_name}` : 'To check'} />
      </Card>
      {c.status !== 'approved' && c.status !== 'void' ? (
        mine && !['owner', 'admin'].includes(user.role) ? <Banner tone="warn" message={`${c.cashier_name} can't approve their own count – someone else checks it.`} /> : (
          <>
            {short ? <Select testID="tck-decide" label="Decide" value={decide || 'pay'} onChange={setDecide} options={[{ value: 'pay', label: `Take from ${c.cashier_name}'s pay` }, { value: 'write_off', label: 'Write it off (owner / admin)' }]} /> : null}
            {short && decide === 'write_off' ? <Field testID="tck-why" label="Why" value={why} onChangeText={setWhy} /> : null}
            <Btn testID="tck-verify" title="Verify" variant="success" onPress={go} />
          </>
        )
      ) : null}
      <Btn testID="tck-open" title="Open the full till balance" size="md" variant="secondary" onPress={() => nav.push('TillCountView', { uid: c.uid })} />
    </Screen>
  );
}

// ================================================================ Office: cigarettes status (o-cig)
export function CigStatusScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const CG = require('../cigTally.js');
  const s = safe(() => CG.cigStatus(params.shopCode || ''), null);
  // 1.0.0 Records › Cigarettes opens this page: the cigarette tally and the cigarette money stay one tap away
  const more = <Btn testID="cs-more" title="Cigarette tally & money" icon="🗂️" size="md" variant="secondary" onPress={() => nav.push('Area', { area: 'cigarettes' })} />;
  if (!s) return <Screen title="Cigarettes"><Banner tone="warn" message="Cigarettes are not set up yet." />{more}</Screen>;
  const pay = () => {
    try { CG.payFromFund(user, { shopCode: s.shopCode, invoiceUids: [s.invoice.uid] }); ui.toast('Paid from the cigarette money'); bump((x) => x + 1); } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={`Cigarettes – ${s.shopCode || ''}`} subtitle="7-day account">
      {s.invoice ? (
        <>
          <Step testID="cs-lot" title={`This lot: invoice ${s.invoice.no || ''}`} right={$(s.invoice.total)} sub={`came ${s.invoice.date}${s.due ? ` · due ${s.due}` : ''}`} tone={s.overdue ? 'bad' : undefined} />
          <Card>
            <Row label="Sold so far (at cost)" value={$(s.sold)} />
            <Row label="Put aside in the bag" value={$(s.aside)} />
            <Row label="Still owing" value={$(s.invoice.owing)} />
            <Row label="Still needed" value={$(s.needed)} bold color={s.needed > 0.004 ? C.warn : C.success} />
          </Card>
          {s.invoice.owing > 0.004 ? <Btn testID="cs-pay" title={`Pay ${s.invoice.no || 'it'} from the cigarette money`} variant="success" disabled={s.needed > 0.004} onPress={pay} /> : null}
          <Hint>{s.canReceive ? 'The last invoice is paid – the next lot can be received.' : `Next lot can be received once ${s.invoice.no || 'this invoice'} is paid.`}</Hint>
        </>
      ) : <Text style={{ fontSize: 17, color: C.sub }}>No cigarette invoice yet. Choose the cigarette supplier in the cigarette settings.</Text>}
      {more}
    </Screen>
  );
}
