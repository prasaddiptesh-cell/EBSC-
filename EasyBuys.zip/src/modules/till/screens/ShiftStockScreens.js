// Release 27: the fast-moving items counted at the start and the end of each shift (one count per shop), the top-ups
// added during the shift, and the balance in items and money (selling price and cost). See ../shiftStock.js.
import React, { useState } from 'react';
import { View, TextInput } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Select, Label, Table, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { dateStr, money } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import * as SS from '../shiftStock.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const sgn = (n) => (n > 0.0005 ? `+${n}` : `${n}`);
const $s = (n) => (n > 0.004 ? `+${$(n)}` : n < -0.004 ? `-${$(-n)}` : $(0));
const hm = (s) => String(s || '').slice(11, 16);
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const shopName = (code) => { const s = safe(() => listShops().find((x) => x.code === code), null); return s ? s.name : code; };

function CountBox({ testID, value, onChange }) {
  return (
    <TextInput testID={testID} value={value === undefined || value === null ? '' : String(value)} onChangeText={(t) => onChange(t.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" placeholder="0"
      style={{ width: 90, minHeight: 44, borderWidth: 2, borderColor: C.border, borderRadius: 10, paddingHorizontal: 10, fontSize: 18, fontWeight: '800', color: C.text, backgroundColor: C.white, textAlign: 'center' }} />
  );
}

// The small card on Start shift / End shift / Balance the till: where the shop's count is, and a button to it.
export function ShiftStockCard({ shopCode, date = dateStr(), shift, when = 'start' }) {
  const { nav } = useApp();
  const items = safe(() => SS.shiftItems(shopCode), []);
  if (!shopCode || !shift || !items.length) return null;
  const c = safe(() => SS.getCount(shopCode, date, shift), null);
  const b = c && c.status === 'open' ? safe(() => SS.balanceOf(c), null) : null;
  const r = c && c.status === 'closed' ? c.result : null;
  const title = !c ? `Count the ${items.length} fast-moving items` : c.status === 'open' ? (when === 'start' ? 'Fast-moving items counted ✓' : 'Count the fast-moving items again (end of shift)') : 'Fast-moving items balanced ✓';
  const tone = !c || (c.status === 'open' && when !== 'start') ? C.warn : C.success;
  return (
    <Card testID="ssk-card" style={{ borderColor: tone, borderWidth: 2 }}>
      <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>{`📦 ${title}`}</Text>
      {!c ? <Text style={{ fontSize: 15, color: C.sub }}>{`${shopName(shopCode)} · ${shift}: count them before the shift starts selling.`}</Text> : null}
      {c && c.status === 'open' ? <Text style={{ fontSize: 15, color: C.sub }}>{`Started ${hm(c.opened_at)} by ${c.opened_by_name}${c.adds.length ? ` · ${c.adds.length} top-up${c.adds.length === 1 ? '' : 's'}` : ''}${b ? ` · stock now ≈ ${$(b.stockSell)} (selling) / ${$(b.stockCost)} (cost)` : ''}`}</Text> : null}
      {r ? <Text style={{ fontSize: 16, fontWeight: '800', color: r.short ? C.danger : C.success }}>{`${r.short} short · ${r.over} over · ${$s(r.diffSell)} at selling price · ${$s(r.diffCost)} at cost`}</Text> : null}
      <Btn testID="ssk-open" title={!c ? 'Count now' : c.status === 'open' ? (when === 'start' ? 'Open the count (add stock)' : 'Count and balance') : 'See the balance'} size="md" variant={!c || (c.status === 'open' && when !== 'start') ? 'primary' : 'secondary'}
        onPress={() => nav.push('ShiftStock', { shopCode, date, shift })} />
    </Card>
  );
}

export function ShiftStockScreen({ params = {} }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const [, bump] = useState(0);
  const shopCode = params.shopCode || user.shop_code || 'S1';
  const date = params.date || dateStr();
  const shift = params.shift || '';
  const items = safe(() => SS.shiftItems(shopCode), []);
  const c = params.uid ? safe(() => SS.getCountByUid(params.uid), null) : safe(() => SS.getCount(shopCode, date, shift), null);
  const last = safe(() => SS.lastClosed(shopCode, c ? c.uid : ''), null);
  const [counts, setCounts] = useState(() => {
    const o = {};
    if (!c && last && last.close_counts) items.forEach((it) => { if (last.close_counts[it.code] !== undefined) o[it.code] = String(last.close_counts[it.code]); });
    return o;
  });
  const [add, setAdd] = useState({ code: items[0] ? items[0].code : '', qty: '', note: '' });
  const [note, setNote] = useState('');
  const act = (fn, msg) => { try { const r = fn(); ui.toast(msg); setCounts({}); bump((n) => n + 1); return r; } catch (e) { ui.error(e); return null; } };
  const isMgr = safe(() => require('../../../services/access.js').can(user, 'till_approve'), false) || ['owner', 'admin'].includes(user.role);

  if (!items.length) {
    return (
      <Screen title="Fast-moving items">
        <Banner tone="warn" message={`No items are chosen for the shift count at ${shopName(shopCode)} yet.`} />
        {['owner', 'admin'].includes(user.role) ? <Btn testID="ssk-setup" title="Choose the items" variant="primary" onPress={() => nav.push('ShiftStockItems', { shopCode })} /> : <Hint>The admin chooses them in Settings › Items counted at each shift.</Hint>}
      </Screen>
    );
  }
  const head = `${shopName(shopCode)} · ${c ? c.shift : shift} · ${c ? c.count_date : date}`;

  // ---------------- not started: the opening count
  if (!c) {
    return (
      <Screen title="Count at the start of the shift" subtitle={head}>
        <Hint>{last ? `The numbers from the last close (${last.shift} ${last.count_date}, ${last.closed_by_name}) are filled in – change any that are different on the shelf.` : 'Count each item on the shelf / behind the counter.'}</Hint>
        <Card>
          {items.map((it) => (
            <View key={it.code} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderBottomWidth: 1, borderColor: C.border }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{it.name}</Text>
                <Text style={{ fontSize: 13, color: C.sub }}>{`${it.code} · sells ${$(it.price)} · cost ${$(it.cost)}`}</Text>
              </View>
              <CountBox testID={`ssk-open-${it.code}`} value={counts[it.code]} onChange={(v) => setCounts((o) => ({ ...o, [it.code]: v }))} />
            </View>
          ))}
        </Card>
        <Field testID="ssk-note" label="Note (optional)" value={note} onChangeText={setNote} />
        <Btn testID="ssk-start" title="Save the start count" icon="✅" variant="success" disabled={!shift} onPress={() => {
          const r = act(() => SS.openCount(user, { shopCode, date, shift, counts, note }), 'Start count saved');
          if (r && r.diffs && r.diffs.length) ui.alert({ title: 'Different from the last close', message: `${r.diffs.join('\n')}\n\nThe manager is told (it is in the history).`, tone: 'warn' });
        }} />
        {!shift ? <Banner tone="warn" message="Open this from Start shift (the shift is needed)." /> : null}
      </Screen>
    );
  }

  const b = c.status === 'open' ? safe(() => SS.balanceOf(c), null) : { ...(c.result || {}), lines: (c.result && c.result.lines) || [] };
  const cols = [
    { key: 'name', title: 'Item', width: 170 },
    { key: 'open', title: 'Start', width: 64, align: 'right' },
    { key: 'added', title: '+ Added', width: 74, align: 'right' },
    { key: 'sold', title: '− Sold', width: 70, align: 'right' },
    { key: 'expected', title: '= Should be', width: 92, align: 'right' },
  ].concat(c.status === 'closed' ? [
    { key: 'counted', title: 'Counted', width: 76, align: 'right' },
    { key: 'diff', title: 'Short / over', width: 96, align: 'right' },
    { key: 'sell', title: 'At selling', width: 96, align: 'right' },
    { key: 'cost', title: 'At cost', width: 90, align: 'right' },
  ] : [
    { key: 'sell', title: 'Stock (selling)', width: 110, align: 'right' },
    { key: 'cost', title: 'Stock (cost)', width: 100, align: 'right' },
  ]);
  const rows = (b.lines || []).map((l) => ({ name: l.name, open: l.open, added: l.added ? `+${l.added}` : '0', sold: l.sold, expected: l.expected,
    counted: l.counted === null ? '' : l.counted, diff: l.diff === null ? '' : sgn(l.diff),
    sell: c.status === 'closed' ? (l.diffSell === null ? '' : $s(l.diffSell)) : $(l.stockSell), cost: c.status === 'closed' ? (l.diffCost === null ? '' : $s(l.diffCost)) : $(l.stockCost) }));

  return (
    <Screen title={c.status === 'closed' ? 'Fast-moving items – balanced' : 'Fast-moving items – this shift'} subtitle={head}>
      <Text style={{ fontSize: 14, color: C.sub }}>{`Start count ${hm(c.opened_at)} by ${c.opened_by_name}${c.closed_at ? ` · end count ${hm(c.closed_at)} by ${c.closed_by_name}` : ''}`}</Text>
      {b && b.receipts === false ? <Banner tone="warn" message="No item sales from the till PCs for this shift yet – 'Sold' is 0 until Aronium sends the receipts." /> : null}
      <Table testID="ssk-table" columns={cols} rows={rows} />
      {c.status === 'closed' ? (
        <Card testID="ssk-result" style={{ borderWidth: 2, borderColor: b.short ? C.danger : C.success }}>
          <Row label="Items short" value={String(b.short || 0)} color={b.short ? C.danger : C.text} />
          <Row label="Items over" value={String(b.over || 0)} />
          <Row label="Difference at selling price" value={$s(b.diffSell || 0)} bold color={(b.diffSell || 0) < -0.004 ? C.danger : C.text} />
          <Row label="Difference at cost" value={$s(b.diffCost || 0)} bold color={(b.diffCost || 0) < -0.004 ? C.danger : C.text} />
          <Row label="Sold this shift (selling price)" value={$(b.soldSell || 0)} />
          <Row label="Stock left (selling / cost)" value={`${$(b.stockSell || 0)} / ${$(b.stockCost || 0)}`} />
          {c.note ? <Text style={{ fontSize: 15, color: C.text }}>{`Note: ${c.note}`}</Text> : null}
        </Card>
      ) : null}

      {c.adds.length ? (
        <Card>
          <H>Stock added during the shift</H>
          {c.adds.map((a) => (
            <View key={a.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
              <Text style={{ flex: 1, fontSize: 16, color: C.text }}>{`${hm(a.at)} · ${a.name} +${a.qty} · ${a.by_name}${a.note ? ` – ${a.note}` : ''}`}</Text>
              {c.status === 'open' && (a.by_uid === user.uid || isMgr) ? <Btn title="✕" size="sm" variant="ghost" onPress={() => act(() => SS.removeAdd(user, { uid: c.uid, id: a.id, reason: 'taken off' }), 'Taken off')} /> : null}
            </View>
          ))}
        </Card>
      ) : null}

      {c.status === 'open' ? (
        <>
          <Card>
            <H>+ Stock added (top-up)</H>
            <Select testID="ssk-add-item" label="Item" value={add.code} onChange={(v) => setAdd({ ...add, code: v })} options={items.map((it) => ({ value: it.code, label: it.name }))} />
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-end' }}>
              <View><Label>How many</Label><CountBox testID="ssk-add-qty" value={add.qty} onChange={(v) => setAdd({ ...add, qty: v })} /></View>
              <View style={{ flex: 1 }}><Field testID="ssk-add-note" label="Note (optional)" value={add.note} onChangeText={(v) => setAdd({ ...add, note: v })} placeholder="e.g. from the store room" /></View>
            </View>
            <Btn testID="ssk-add" title="Add to this shift" variant="primary" disabled={!add.qty} onPress={() => { if (act(() => SS.addStock(user, { uid: c.uid, code: add.code, qty: add.qty, note: add.note }), 'Stock added')) setAdd({ ...add, qty: '', note: '' }); }} />
          </Card>
          <Card>
            <H>End of the shift: count again</H>
            {items.map((it) => {
              const l = (b.lines || []).find((x) => x.code === it.code) || {};
              return (
                <View key={it.code} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderBottomWidth: 1, borderColor: C.border }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{it.name}</Text>
                    <Text style={{ fontSize: 13, color: C.sub }}>{`should be about ${l.expected === undefined ? '?' : l.expected}`}</Text>
                  </View>
                  <CountBox testID={`ssk-close-${it.code}`} value={counts[it.code]} onChange={(v) => setCounts((o) => ({ ...o, [it.code]: v }))} />
                </View>
              );
            })}
            <Field testID="ssk-cnote" label="Note (optional)" value={note} onChangeText={setNote} />
            <Btn testID="ssk-close" title="Save the end count and balance" icon="⚖️" variant="success" onPress={() => act(() => SS.closeCount(user, { uid: c.uid, counts, note }), 'Balanced')} />
          </Card>
        </>
      ) : isMgr ? (
        <Card>
          <Field testID="ssk-why" label="Open the count again (a counting mistake) – why?" value={note} onChangeText={setNote} placeholder="e.g. miscounted one item" />
          <Btn testID="ssk-reopen" title="Open the count again" size="sm" variant="secondary" disabled={!note.trim()} onPress={() => { if (act(() => SS.reopenCount(user, { uid: c.uid, reason: note }), 'Opened again')) setNote(''); }} />
        </Card>
      ) : null}
      <Btn testID="ssk-history" title="Earlier counts" size="sm" variant="secondary" onPress={() => nav.push('ShiftStockList', { shopCode })} />
    </Screen>
  );
}

export function ShiftStockListScreen({ params = {} }) {
  const { nav } = useApp();
  const shopCode = params.shopCode || '';
  const rows = safe(() => SS.listCounts({ shopCode }), []);
  return (
    <Screen title="Fast-moving item counts" subtitle={shopCode ? shopName(shopCode) : 'Both shops'}>
      {!rows.length ? <Text style={{ fontSize: 16, color: C.sub }}>No counts in the last 14 days.</Text> : null}
      {rows.map((c) => (
        <Card key={c.uid}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${c.count_date} · ${shopName(c.shop_code)} · ${c.shift}`}</Text>
          <Text style={{ fontSize: 15, color: c.result && c.result.short ? C.danger : C.sub }}>{c.status === 'closed' && c.result ? `${c.result.short} short · ${c.result.over} over · ${$s(c.result.diffSell)} selling · ${$s(c.result.diffCost)} cost` : 'Still open (no end count yet)'}</Text>
          <Btn title="Open" size="sm" variant="secondary" onPress={() => nav.push('ShiftStock', { uid: c.uid, shopCode: c.shop_code })} />
        </Card>
      ))}
    </Screen>
  );
}

// The admin chooses the items counted at each shift, per shop.
export function ShiftStockItemsScreen({ params = {} }) {
  const { user } = useApp();
  const ui = useUI();
  const shops = safe(() => listShops().filter((s) => s.active), []);
  const [shop, setShop] = useState(params.shopCode || (shops[0] ? shops[0].code : 'S1'));
  const [q, setQ] = useState('');
  const [, bump] = useState(0);
  const chosen = safe(() => SS.shiftItems(shop), []);
  const found = q.length >= 2 ? safe(() => SS.findItems(q), []) : [];
  const save = (codes, msg) => { try { SS.setShiftItems(user, shop, codes); ui.toast(msg); bump((n) => n + 1); } catch (e) { ui.error(e); } };
  if (!['owner', 'admin'].includes(user.role)) return <Screen title="Items counted at each shift"><Banner tone="warn" message="Only the owner or an admin chooses these." /></Screen>;
  return (
    <Screen title="Items counted at each shift" subtitle="Fast-moving items – counted at the start and end of every shift">
      <Hint>Choose the items staff count at the start and end of each shift (e.g. cigarettes, phone cards). Sales come from Aronium; top-ups are added on the shift; the balance shows any shortage at selling price and at cost.</Hint>
      <Select testID="ssi-shop" label="Shop" value={shop} onChange={setShop} options={shops.map((s) => ({ value: s.code, label: s.name }))} />
      <Card>
        <H>{`Counted at ${shopName(shop)} (${chosen.length})`}</H>
        {!chosen.length ? <Text style={{ fontSize: 15, color: C.sub }}>None yet – search below and add.</Text> : null}
        {chosen.map((it) => (
          <View key={it.code} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
            <Text style={{ flex: 1, fontSize: 16, color: it.missing ? C.danger : C.text }}>{`${it.name} · ${it.code}${it.missing ? ' (not in the products)' : ` · ${$(it.price)}`}`}</Text>
            <Btn testID={`ssi-rm-${it.code}`} title="Remove" size="sm" variant="ghost" onPress={() => save(chosen.map((x) => x.code).filter((x) => x !== it.code), 'Removed')} />
          </View>
        ))}
      </Card>
      <Field testID="ssi-q" label="Find a product (name, code or barcode)" value={q} onChangeText={setQ} />
      {found.map((p) => {
        const on = chosen.some((x) => x.code === p.code);
        return (
          <View key={p.code} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
            <Text style={{ flex: 1, fontSize: 16, color: C.text }}>{`${p.name} · ${p.code} · ${$(p.price)}`}</Text>
            <Btn testID={`ssi-add-${p.code}`} title={on ? 'Added ✓' : 'Add'} size="sm" variant={on ? 'ghost' : 'primary'} disabled={on} onPress={() => save(chosen.map((x) => x.code).concat([p.code]), `${p.name} added`)} />
          </View>
        );
      })}
    </Screen>
  );
}
