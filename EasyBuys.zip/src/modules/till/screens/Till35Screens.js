// Till & cash v3.5 screens: shifts (start, continue by the owner), Aronium End of day (matched to each shift's Z),
// till shortages (the cashier agrees and signs, or disagrees and a manager decides), and the two signatures.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, Section, Select, Label, useApp, useUI, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton, ReasonField } from '../../../ui/kit.js';
import { SignaturePad, SignatureView } from '../../../ui/signature.js';
import { dateStr } from '../../../services/core.js';
import { actsAsOwner } from '../../../services/access.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import * as T from '../service.js';
import * as S from '../shifts.js';
import * as RC from '../recount.js';
import * as E from '../eod.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { fillEmpty } from '../../../services/paperRead.js';
import { addPhotos } from '../../../services/stock.js';

const { $ } = T;
const shops = () => listShops().filter((s) => s.active && /^S\d/.test(s.code));
const shopOpts = () => shops().map((s) => ({ value: s.code, label: s.name }));
const staffOpts = () => listUsers().filter((u) => u.active && u.sync_status !== 'seed').map((u) => ({ value: u.uid, label: u.name }));
const ownerish = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
const EOD_TONE = { matched: C.success, resolved: C.info, difference: C.danger, no_till: C.danger, void: C.sub };
const SHIFT_TONE = { open: C.warn, continued: C.danger, counted: C.success, void: C.sub };
const SHORT_TONE = { waiting: C.danger, disagreed: C.danger, agreed: C.success, deducted: C.warn, written_off: C.info, paid: C.success, set_off: C.success, void: C.sub };
const OVER_TONE = { open: C.warn, kept: C.info, set_off: C.success, returned: C.success, void: C.sub };

// ---------------------------------------------------------------- shifts
export function TillShiftsScreen() {
  const { user, nav, can } = useApp();
  const act = useAct();
  const [f, setF] = useState(null);
  const [cont, setCont] = useState(null);
  const today = dateStr();
  const toDo = S.shiftsToBalance(today);
  const recent = S.listShifts({ from: today, to: today, limit: 50 }).filter((s) => s.status === 'counted');
  const tills = f ? T.listTills({ shopCode: f.shopCode }) : [];
  const rules = T.tillRules();
  return (
    <Screen title="Till shifts" subtitle="One till balance per till per shift">
      <Explain title="How shifts work">
        Each till has 2–3 shifts a day with one cashier per shift. Start the shift when the cashier takes over the till. The next shift on a till can only start when the
        previous one is balanced (counted and signed). Only the owner can let the next shift start without it – the Aronium End of day number and total of that shift
        must be written down, and the shift stays flagged red until it is counted.
      </Explain>
      {can('till_count') ? (f ? (
        <Card>
          <H>Start a shift</H>
          <Choice label="Shop" value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v, tillUid: '' })} testIDPrefix="sh-shop" options={shopOpts()} />
          {tills.length ? <Choice label="Till" value={f.tillUid || tills[0].uid} onChange={(v) => setF({ ...f, tillUid: v })} testIDPrefix="sh-till" options={tills.map((t) => ({ value: t.uid, label: t.name }))} />
            : <Banner tone="warn" message="No tills set up for this shop yet (Till & cash › Tills & rules)." />}
          <Choice label="Shift" value={f.shift} onChange={(v) => setF({ ...f, shift: v })} testIDPrefix="sh-shift" options={rules.shifts.map((x) => ({ value: x, label: x }))} />
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Select testID="sh-cashier" label="Cashier on this till" value={f.cashierUid} onChange={(v) => setF({ ...f, cashierUid: v })} options={staffOpts()} />
          <MoneyField testID="sh-float" label="Float at the start (blank = what the till was left with)" value={f.openingFloat} onChange={(v) => setF({ ...f, openingFloat: v })} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="sh-start" title="Start the shift" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => S.startShift(user, { ...f, tillUid: f.tillUid || (tills[0] && tills[0].uid) || '' }), 'Shift started')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="sh-new" title="Start a shift" icon="▶️" variant="success" onPress={() => setF({ shopCode: user.shop_code && /^S\d/.test(user.shop_code) ? user.shop_code : ((shops()[0] || {}).code || ''), tillUid: '', shift: rules.shifts[0], date: today, cashierUid: '', openingFloat: '' })} />) : null}
      <Section title={`Still to balance (${toDo.length})`}>
        {!toDo.length ? <Text style={{ fontSize: 16, color: C.sub }}>Every shift is balanced.</Text> : null}
        {toDo.map((s) => (
          <View key={s.uid} style={{ gap: 6 }}>
            <ListItem testID={`shift-${s.uid}`} title={`${s.shop_code} · ${s.till_name} · ${s.shift} · ${s.shift_date}`} sub={`${s.cashier_name} · started by ${s.opened_by_name}${s.status === 'continued' ? ` · continued by ${s.continued_by_name}, End of day ${s.eod_z_number}: ${$(s.eod_total)}` : ''}`}
              badge={s.status === 'continued' ? 'COUNT IT' : s.late ? 'NOT BALANCED' : 'Running'} badgeColor={s.status === 'continued' || s.late ? C.danger : SHIFT_TONE[s.status]} tone={s.status === 'continued' || s.late ? 'danger' : undefined}
              onPress={() => setCont(cont && cont.uid === s.uid ? null : { uid: s.uid, zNumber: '', zTotal: '', note: '' })} />
            {cont && cont.uid === s.uid ? (
              <Card>
                {can('till_count') ? <Btn testID="sh-count" title="Count this till now" icon="🧮" size="md" variant="success" onPress={() => nav.push('TillCount', { shiftUid: s.uid })} /> : null}
                {s.status === 'open' && ownerish(user) ? (
                  <View style={{ gap: 8, marginTop: 8 }}>
                    <Label>Owner: let the next shift start without counting this one</Label>
                    <Field testID="sh-z" label="Aronium End of day (Z) number of this shift" value={cont.zNumber} onChangeText={(v) => setCont({ ...cont, zNumber: v })} />
                    <MoneyField testID="sh-ztotal" label="Total sales on that End of day" value={cont.zTotal} onChange={(v) => setCont({ ...cont, zTotal: v })} />
                    <Field label="Note (optional)" value={cont.note} onChangeText={(v) => setCont({ ...cont, note: v })} />
                    <Btn testID="sh-continue" title="Continue – count it later" variant="warn" size="md" onPress={() => { if (act(() => S.continueShift(user, s.uid, cont), 'Continued – it stays flagged until counted')) setCont(null); }} />
                  </View>
                ) : null}
                {s.status === 'open' && can('till_approve') ? <ReasonButton title="Cancel this shift (started by mistake)" prompt="Why?" confirm="Cancel shift" onDo={(w) => act(() => S.voidShift(user, s.uid, w), 'Cancelled')} /> : null}
              </Card>
            ) : null}
          </View>
        ))}
      </Section>
      {recent.length ? (
        <Section title="Balanced today">
          {recent.map((s) => <ListItem key={s.uid} title={`${s.shop_code} · ${s.till_name} · ${s.shift}`} sub={s.cashier_name} badge="Balanced" badgeColor={C.success} onPress={() => s.count_uid && nav.push('TillCountView', { uid: s.count_uid })} />)}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- Aronium End of day
export function AroniumEodsScreen({ params }) {
  const { user, nav, can } = useApp();
  const ui = useUI();
  const act = useAct();
  const [show, setShow] = useRemembered('show', params.show || 'open');
  const [f, setF] = useState(null);
  const ep = usePaper('z');
  // The Z report photo → the End of day boxes (card and the other payments added up).
  const eodApply = (form, x, prev) => {
    const tend = x.tenders || [];
    const card = tend.filter((t) => /card|eftpos/i.test(t.method)).reduce((a, t) => a + t.amount, 0);
    const other = tend.filter((t) => !/card|eftpos/i.test(t.method)).reduce((a, t) => a + t.amount, 0);
    const extra = { ...x, card: card ? Math.round(card * 100) / 100 : undefined, other: other ? Math.round(other * 100) / 100 : undefined };
    return fillEmpty(form, extra, { zNumber: 'zNumber', zTotal: 'total', zVat: 'vat', zZeroRated: 'zero', zCash: 'cash', card: 'card', other: 'other', date: 'date' }, prev, { date: dateStr() });
  };
  const EOD_MAP = { zNumber: 'zNumber', zTotal: 'total', zVat: 'vat', zZeroRated: 'zero', zCash: 'cash', date: 'date' };
  const list = show === 'open' ? E.listEods({ states: ['difference', 'no_till'] }) : E.listEods({ limit: 200 });
  const p = E.eodProblems();
  return (
    <Screen title="Aronium End of day" subtitle="Matched to each shift's Z on the till balance">
      <Explain>
        Every Aronium End of day (Z) is matched to the till balance of the same shop and Z number (a whole-day figure without a Z number is matched to the whole day).
        A difference is flagged straight away. Someone must explain it (the owner and admin need not write anything). Until it is explained, the VAT return uses
        Aronium's figure. An End of day with no till balance is red: the till balance is missing. Aronium sales are not booked – cash and banking come from the till.
      </Explain>
      <Stats items={[{ label: 'Differences', value: String(p.differences.length), color: p.differences.length ? C.danger : C.success, onPress: () => setShow('open') },
        { label: 'Till balance missing', value: String(p.noTill.length), color: p.noTill.length ? C.danger : C.success, onPress: () => setShow('open') }]} />
      {can('till_approve') ? (f ? (
        <Card>
          <H>Type an Aronium End of day</H>
          <PaperPhoto pr={ep} testID="eod-photo" label="Photo of the Aronium End of day (Z report)" value={f.photos || []} onChange={(v) => setF((o) => ({ ...o, photos: v }))} form={f} setForm={setF} apply={eodApply}
            labels={{ total: 'Total sales', vat: 'VAT', zero: 'Zero-rated sales', cash: 'Cash', card: 'Card', other: 'Other payments' }} hint="Take the photo first – the figures fill in by themselves." />
          <Choice label="Shop" value={f.shopCode} onChange={(v) => setF({ ...f, shopCode: v })} testIDPrefix="eod-shop" options={shopOpts()} />
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field testID="eod-z" label="End of day (Z) number" value={f.zNumber} onChangeText={(v) => setF({ ...f, zNumber: v })} />
          <MoneyField testID="eod-total" label="Total sales (incl. VAT)" value={f.total} onChange={(v) => setF({ ...f, total: v })} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="eod-vat" label="VAT" value={f.vat} onChange={(v) => setF({ ...f, vat: v })} /></View>
            <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField label="Zero-rated sales" value={f.zero} onChange={(v) => setF({ ...f, zero: v })} /></View>
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="eod-save" title="Save and match" variant="success" style={{ flex: 1 }} onPress={() => { if (!ep.okToSave(ui)) return; const r = act(() => E.addEod(user, { ...f, source: ep.read ? 'photo' : 'typed' })); if (r) { if ((f.photos || []).length) { try { addPhotos('eod', r.uid, f.photos); } catch (e) { /* the figures are saved */ } } ep.log(user, 'aronium_eods', r.uid, f, EOD_MAP); ep.reset(); setF(null); nav.push('AroniumEod', { uid: r.uid }); } }} />
          </View>
        </Card>
      ) : <Btn testID="eod-new" title="Type an End of day from Aronium" icon="✍️" variant="info" onPress={() => setF({ shopCode: (shops()[0] || {}).code || '', date: dateStr(), zNumber: '', total: '', vat: '', zero: '', cash: '', card: '', other: '', photos: [] })} />) : null}
      {can('accounts_journal') ? <Btn title="Bring in Aronium sales (CSV)" icon="📥" size="md" variant="secondary" onPress={() => nav.push('AroniumImport', {})} /> : null}
      <Choice value={show} onChange={setShow} testIDPrefix="eod-show" options={[{ value: 'open', label: 'To sort out' }, { value: 'all', label: 'All' }]} />
      {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>{show === 'open' ? 'Nothing to sort out – every End of day agrees with the tills.' : 'No Aronium End of day figures yet.'}</Text> : null}
      {list.map((e) => (
        <ListItem key={e.uid} testID={`eod-${e.uid}`} title={`${e.shop_code} · ${e.eod_date} · Z ${e.z_number || '(whole day)'}`} sub={`Aronium ${$(e.total)}${e.till_total !== null ? ` · till ${$(e.till_total)}` : ''}${e.explanation ? ` · ${e.explanation}` : ''}`}
          right={e.diff !== null ? $(e.diff) : ''} badge={E.EOD_STATE[e.state]} badgeColor={EOD_TONE[e.state]} tone={e.state === 'difference' || e.state === 'no_till' ? 'danger' : undefined} onPress={() => nav.push('AroniumEod', { uid: e.uid })} />
      ))}
    </Screen>
  );
}
export function AroniumEodScreen({ params }) {
  const { user, nav, can } = useApp();
  const act = useAct();
  const [why, setWhy] = useState('');
  const [use, setUse] = useState('aronium');
  const e = params.uid ? E.getEod(params.uid) : null;
  if (!e) return <Screen title="Aronium End of day"><Hint>Not found. Open it from Till & cash › Aronium End of day.</Hint></Screen>;
  const counts = e.count_uids.map((u) => T.getTillCount(u)).filter(Boolean);
  return (
    <Screen title={`Aronium End of day ${e.z_number || ''}`.trim()} subtitle={`${e.shop_code} · ${e.eod_date}`}>
      <Banner testID="eod-state" tone={e.state === 'matched' ? 'success' : e.state === 'resolved' ? 'info' : e.state === 'void' ? 'info' : 'danger'} title={E.EOD_STATE[e.state]}
        message={e.state === 'difference' ? `Aronium ${$(e.total)}, till balance ${$(e.till_total)}: difference ${$(e.diff)}. Until explained, the VAT return uses Aronium's figure.` : e.state === 'no_till' ? 'No till balance for this End of day. Count the till (or find the till balance) – cash and banking come only from the till balance.' : e.explanation ? `Explained by ${e.resolved_by_name}: ${e.explanation}` : ''} />
      <Card>
        <Row label="Aronium total" value={$(e.total)} bold />
        {e.vat !== null ? <Row label="VAT / zero-rated" value={`${$(e.vat)} / ${$(e.zero || 0)}`} /> : null}
        {e.cash !== null ? <Row label="Cash / card / other" value={`${$(e.cash)} / ${$(e.card || 0)} / ${$(e.other || 0)}`} /> : null}
        <Row label="Till balance total" value={e.till_total === null ? '—' : $(e.till_total)} />
        <Row label="Difference" value={e.diff === null ? '—' : $(e.diff)} color={e.state === 'difference' ? C.danger : undefined} />
        <Row label="From" value={`${e.source === 'csv' ? 'Aronium CSV' : e.source === 'typed' ? 'Typed in' : e.source || ''} · ${e.created_by_name || ''}`} />
        {e.state === 'resolved' ? <Row label="VAT uses" value={e.use_figure === 'till' ? 'The till balance' : "Aronium's figure"} /> : null}
      </Card>
      {counts.length ? (
        <Section title="Till balances matched">
          {counts.map((c) => <ListItem key={c.uid} title={`${c.till_name} · ${c.shift} · Z ${c.z_number || '—'}`} sub={`${c.cashier_name} · ${c.shift_date}`} right={$(E.countTotal(c))} onPress={() => nav.push('TillCountView', { uid: c.uid })} />)}
        </Section>
      ) : null}
      {(e.state === 'difference' || e.state === 'resolved') && can('till_approve') ? (
        <Card>
          <H>{e.state === 'resolved' ? 'Change the explanation' : 'Explain the difference'}</H>
          <ReasonField testID="eod-why" label="What happened (e.g. refund not done in Aronium, sale rung up twice)" value={why} onChangeText={setWhy} multiline />
          <Choice label="Which figure is right for VAT?" value={use} onChange={setUse} testIDPrefix="eod-use" options={[{ value: 'aronium', label: "Aronium's figure" }, { value: 'till', label: 'The till balance' }]} />
          <Btn testID="eod-resolve" title="Save the explanation" variant="success" onPress={() => { if (act(() => E.resolveEod(user, e.uid, { explanation: why, use }), 'Explained')) setWhy(''); }} />
        </Card>
      ) : null}
      {e.state === 'no_till' && can('till_count') ? <Btn title="Count the till for this day" icon="🧮" variant="success" onPress={() => nav.push('TillCount', { shopCode: e.shop_code, shiftDate: e.eod_date, zNumber: e.z_number || '' })} /> : null}
      {e.state !== 'void' && can('till_approve') ? <ReasonButton title="Void (typed by mistake / duplicate)" prompt="Why?" confirm="Void" onDo={(w) => act(() => E.voidEod(user, e.uid, w), 'Voided')} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- shortages
export function TillShortagesScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [sig, setSig] = useState(null);
  const [parts, setParts] = useState('1');
  const [note, setNote] = useState('');
  const [amount, setAmount] = useState('');
  const [paySig, setPaySig] = useState(null);
  const [payAmt, setPayAmt] = useState('');
  const [openOver, setOpenOver] = useState(null);
  const [overNote, setOverNote] = useState('');
  const [overAmt, setOverAmt] = useState('');
  const seeAll = can('till_approve');
  const overs = seeAll ? RC.listSurpluses({ status: 'open' }) : [];
  const oversDone = seeAll ? RC.listSurpluses({ statuses: ['kept', 'set_off', 'returned'], limit: 30 }) : [];
  const waiting = S.undecidedShortages().filter((s) => seeAll || s.user_uid === user.uid);
  const done = S.listShortages({ statuses: ['agreed', 'deducted', 'written_off', 'paid', 'set_off'], limit: 30 }).filter((s) => seeAll || s.user_uid === user.uid);
  const reset = () => { setOpen(null); setSig(null); setParts('1'); setNote(''); setAmount(''); setPaySig(null); setPayAmt(''); };
  const resetOver = () => { setOpenOver(null); setOverNote(''); setOverAmt(''); };
  return (
    <Screen title="Till short & over" subtitle="Shortages: paid now, or from pay · Surplus: decided">
      <Explain>
        When a till is short by more than the allowed difference, the cashier can pay it there and then in cash (all or part – a supervisor takes the money and the cashier signs),
        or agree and sign to have it taken from pay (all in the next pay or in parts). If they do not agree, a manager decides (take it from pay, or the owner writes it off).
        A till that is over is recorded too: a supervisor decides to keep it, set it against the same cashier's shortage, or record that it was given back to a customer.
        Shortages not decided yet show red in the pay run.
      </Explain>
      <Section title={`Waiting (${waiting.length})`}>
        {!waiting.length ? <Text style={{ fontSize: 16, color: C.sub }}>No shortage is waiting.</Text> : null}
        {waiting.map((s) => (
          <View key={s.uid} style={{ gap: 6 }}>
            <ListItem testID={`short-${s.uid}`} title={`${s.name} · short ${$(s.amount)}`} sub={`${s.shop_code} · ${s.shift_date}${s.disagree_note ? ` · does not agree: ${s.disagree_note}` : ''}`}
              badge={S.SHORT_STATUS[s.status]} badgeColor={SHORT_TONE[s.status]} tone="danger" onPress={() => { if (open === s.uid) reset(); else { reset(); setOpen(s.uid); } }} />
            {open === s.uid ? (
              <Card>
                {s.status === 'waiting' ? (
                  <View style={{ gap: 8 }}>
                    <H>{s.name}: do you agree?</H>
                    <Text style={{ fontSize: 16, color: C.text }}>The till was short {$(s.amount)} on {s.shift_date}. If you agree, it is taken from your pay.</Text>
                    <Choice label="Pay it back in" value={parts} onChange={setParts} testIDPrefix="short-parts" options={['1', '2', '3', '4'].map((n) => ({ value: n, label: n === '1' ? 'One go' : `${n} parts (${$(Math.ceil((s.amount / Number(n)) * 100) / 100)} each)` }))} />
                    <SignaturePad value={sig} onChange={setSig} testID="short-sig" label={`${s.name}, sign to agree`} />
                    <Btn testID="short-agree" title={`I agree – take ${$(s.amount)} from my pay`} variant="success" disabled={!sig} onPress={() => { if (act(() => S.agreeShortage(user, s.uid, { signature: sig, parts }), 'Agreed – added to the pay run')) reset(); }} />
                    <Field testID="short-note" label="If you do NOT agree, say why" value={note} onChangeText={setNote} multiline />
                    <Btn testID="short-disagree" title="I do not agree – send to a manager" variant="warn" onPress={() => { if (act(() => S.disagreeShortage(user, s.uid, { note, signature: sig }), 'Sent to a manager')) reset(); }} />
                  </View>
                ) : null}
                {seeAll && s.user_uid !== user.uid ? (
                  <View style={{ gap: 8, marginTop: 10 }}>
                    <H>💵 {s.name} pays now in cash</H>
                    <MoneyField testID="short-payamt" label={`Amount paid now (up to ${$(s.amount)} – the rest is taken from pay)`} value={payAmt} onChange={setPayAmt} placeholder={String(s.amount)} />
                    <SignaturePad value={paySig} onChange={setPaySig} testID="short-paysig" label={`${s.name}, sign for the money you paid`} />
                    <Btn testID="short-paynow" title={`Received ${$(payAmt === '' ? s.amount : payAmt)} in cash from ${s.name}`} variant="success" disabled={!paySig}
                      onPress={() => { const r = act(() => RC.payShortageNow(user, s.uid, { amount: payAmt, signature: paySig }), 'Recorded – the cash is in the shop cash'); if (r) reset(); }} />
                  </View>
                ) : null}
                {seeAll && (s.status === 'disagreed' || ownerish(user)) ? (
                  <View style={{ gap: 8, marginTop: 10 }}>
                    <H>Manager decides</H>
                    <ReasonField testID="short-why" label="What was decided and why" value={note} onChangeText={setNote} multiline />
                    <MoneyField label={`Amount to take from pay (up to ${$(s.amount)})`} value={amount} onChange={setAmount} placeholder={String(s.amount)} />
                    <Choice label="In" value={parts} onChange={setParts} testIDPrefix="short-dparts" options={['1', '2', '3', '4'].map((n) => ({ value: n, label: n === '1' ? 'One go' : `${n} parts` }))} />
                    <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
                      <Btn testID="short-deduct" title="Take it from pay" variant="danger" style={{ flexGrow: 1 }} onPress={() => { if (act(() => S.decideShortage(user, s.uid, { action: 'deduct', amount, parts, note }), 'Added to the pay run')) reset(); }} />
                      {ownerish(user) || T.tillRules().shortageRule === 'decide' ? <Btn testID="short-writeoff" title="Write it off" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { if (act(() => S.decideShortage(user, s.uid, { action: 'write_off', note }), 'Written off')) reset(); }} /> : null}
                    </View>
                  </View>
                ) : null}
              </Card>
            ) : null}
          </View>
        ))}
      </Section>
      {seeAll ? (
        <Section title={`Till over – to decide (${overs.length})`}>
          {!overs.length ? <Text style={{ fontSize: 16, color: C.sub }}>No till over waiting.</Text> : null}
          {overs.map((o) => {
            const choices = openOver === o.uid ? RC.setOffChoices(o.uid) : [];
            return (
              <View key={o.uid} style={{ gap: 6 }}>
                <ListItem testID={`over-${o.uid}`} title={`${o.name} · over ${$(o.amount)}`} sub={`${o.shop_code} · ${o.shift_date}`} badge={RC.SURPLUS_STATUS[o.status]} badgeColor={OVER_TONE[o.status]} tone="warn"
                  onPress={() => { if (openOver === o.uid) resetOver(); else { resetOver(); setOpenOver(o.uid); } }} />
                {openOver === o.uid ? (
                  <Card>
                    <Field testID="over-note" label="Note (optional for the owner / admin)" value={overNote} onChangeText={setOverNote} multiline />
                    <Btn testID="over-keep" title="Keep it – the business keeps the extra" icon="🏪" variant="secondary" onPress={() => { if (act(() => RC.decideSurplus(user, o.uid, { action: 'keep', note: overNote }), 'Kept')) resetOver(); }} />
                    {choices.map((sh) => <Btn key={sh.uid} testID={`over-setoff-${sh.uid}`} title={`Set against ${sh.name}'s shortage of ${sh.shift_date} (${$(sh.amount)})`} icon="⚖️" variant="success" onPress={() => { if (act(() => RC.decideSurplus(user, o.uid, { action: 'set_off', shortageUid: sh.uid, note: overNote }), 'Set against the shortage')) resetOver(); }} />)}
                    <MoneyField testID="over-backamt" label={`Given back to a customer (up to ${$(o.amount)})`} value={overAmt} onChange={setOverAmt} placeholder={String(o.amount)} />
                    <Btn testID="over-back" title="It was given back (write who and why above)" icon="↩️" variant="warn" onPress={() => { if (act(() => RC.decideSurplus(user, o.uid, { action: 'returned', amount: overAmt, note: overNote }), 'Recorded – cash taken out of the shop cash')) resetOver(); }} />
                  </Card>
                ) : null}
              </View>
            );
          })}
        </Section>
      ) : null}
      {oversDone.length ? (
        <Section title="Till over – decided">
          {oversDone.map((o) => <ListItem key={o.uid} title={`${o.name} · over ${$(o.amount)}`} sub={`${o.shift_date}${o.decided_by_name ? ` · by ${o.decided_by_name}` : ''}${o.decision_note ? ` · ${o.decision_note}` : ''}`} badge={RC.SURPLUS_STATUS[o.status]} badgeColor={OVER_TONE[o.status]} />)}
        </Section>
      ) : null}
      {done.length ? (
        <Section title="Decided">
          {done.map((s) => (
            <ListItem key={s.uid} title={`${s.name} · ${$(s.amount)}${s.paid_now ? ` · paid ${$(s.paid_now)} in cash` : ''}`} sub={`${s.shift_date}${s.parts > 1 ? ` · ${s.parts} parts of ${$(s.per_pay)}` : ''}${s.decided_by_name ? ` · by ${s.decided_by_name}` : ''}`}
              badge={S.SHORT_STATUS[s.status]} badgeColor={SHORT_TONE[s.status]} />
          ))}
        </Section>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- two signatures (used on the till balance screens)
export function SignBox({ count, onSigned, cashierUid, balancerUid, setBalancerUid, sigs, setSigs, saveNow = true }) {
  const { user } = useApp();
  const act = useAct();
  const cashier = cashierUid || (count && count.cashier_uid);
  const balancer = balancerUid || (count && count.balancer_uid) || user.uid;
  const cashierName = (listUsers().find((u) => u.uid === cashier) || {}).name || (count && count.cashier_name) || 'Cashier';
  const same = cashier && balancer && cashier === balancer;
  return (
    <Card>
      <H>Signatures</H>
      <Hint>The cashier and the person who balanced the till both sign. The same person may do both only if they are the owner/admin or have "May run and balance their own till".</Hint>
      <Select testID="sig-balancer" label="Balanced by" value={balancer} onChange={setBalancerUid} options={staffOpts()} />
      {same ? <Banner tone="warn" message="Cashier and balancer are the same person – only allowed for the owner/admin or with the permission." /> : null}
      <SignaturePad testID="sig-cashier" value={sigs.cashier} onChange={(v) => setSigs({ ...sigs, cashier: v })} label={`${cashierName} (cashier) signs`} />
      <SignaturePad testID="sig-bal" value={sigs.balancer} onChange={(v) => setSigs({ ...sigs, balancer: v })} label={`${(listUsers().find((u) => u.uid === balancer) || {}).name || 'Balancer'} (balanced the till) signs`} />
      {saveNow && count ? <Btn testID="sig-save" title="Save the signatures" variant="success" disabled={!sigs.cashier || !sigs.balancer}
        onPress={() => { if (act(() => T.signTillCount(user, count.uid, { cashierSig: sigs.cashier, balancerSig: sigs.balancer, balancerUid: balancer }), 'Signed')) onSigned && onSigned(); }} /> : null}
    </Card>
  );
}
export function SignedBy({ c }) {
  if (!c || !(c.cashier_sig || c.balancer_sig)) return null;
  return (
    <Card>
      <H>Signed</H>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 16 }}>
        <View><SignatureView data={c.cashier_sig} /><Text style={{ color: C.sub }}>{c.cashier_name} (cashier)</Text></View>
        <View><SignatureView data={c.balancer_sig} /><Text style={{ color: C.sub }}>{c.balancer_name} (balanced it)</Text></View>
      </View>
      {c.signed_at ? <Text style={{ color: C.sub }}>{String(c.signed_at).slice(0, 16)}</Text> : null}
    </Card>
  );
}
