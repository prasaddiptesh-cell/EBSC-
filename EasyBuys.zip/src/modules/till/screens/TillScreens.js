// Till & cash screens: overview, count a till (with the Z report), one count, deposits, cash on hand, setup.
import React, { useState } from 'react';
import { View, Image, TextInput } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats } from '../../../ui/kit.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import { listAccounts } from '../../payables/service.js';
import * as T from '../service.js';

const { $, r2 } = T;
const shops = () => listShops().filter((s) => s.active);
const shopName = (code) => { const s = listShops().find((x) => x.code === code); return s ? s.name.replace(/^Shop (\d) - /, 'Shop $1 ') : code; };
const shopChips = () => shops().map((s) => ({ value: s.code, label: shopName(s.code) }));
const OS = (n) => (Math.abs(n) < 0.005 ? 'Balanced' : n > 0 ? `Over ${$(n)}` : `Short ${$(-n)}`);
const osColor = (n) => (Math.abs(n) < 0.005 ? C.success : n > 0 ? C.warn : C.danger);

// ---------------------------------------------------------------- overview
export function TillHomeScreen() {
  const { nav, can } = useApp();
  const a = T.tillAlerts();
  const waiting = can('till_approve') ? T.listTillCounts({ status: 'counted' }).concat(T.listTillCounts({ status: 'queried' })) : [];
  const recent = T.listTillCounts({ limit: 15 });
  return (
    <Screen title="Till & cash" subtitle="Till counts, cash at each shop, deposits">
      {can('till_approve') || can('deposits') ? (
        <Stats items={shops().map((s) => { const c = T.cashOnHand(s.code); return { label: `${shopName(s.code)} cash`, value: $(c.onHand), sub: `+ floats ${$(c.floats)}`, onPress: () => nav.push('CashOnHand', { shopCode: s.code }), testID: `cash-${s.code}` }; })} />
      ) : null}
      {a.shortWeek ? <Banner tone="danger" title={`${a.shortWeek} short till(s) in the last 7 days`} message={`Total ${$(-a.shortAmount)} short.`} /> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {can('till_count') ? <Btn testID="till-count" title="Count a till" icon="🧮" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('TillCount', {})} /> : null}
        {can('deposits') ? <Btn testID="till-deposit" title="Bank deposit" icon="🏦" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('Deposit', {})} /> : null}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {can('deposits') ? <Btn testID="till-cash" title="Petty cash / move cash" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('CashOnHand', {})} /> : null}
        {can('deposits') ? <Btn title="Deposits" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('Deposits')} /> : null}
        {can('till_approve') ? <Btn testID="till-setup" title="Tills & rules" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('TillSetup')} /> : null}
      </View>
      {waiting.length ? (
        <Section title={`Waiting for approval (${waiting.length})`}>
          {waiting.map((c) => <CountRow key={c.uid} c={c} onPress={() => nav.push('TillCountView', { uid: c.uid })} />)}
        </Section>
      ) : null}
      <Section title="Recent counts">
        {!recent.length ? <Text style={{ fontSize: 16, color: C.sub }}>No till counts yet.</Text> : null}
        {recent.map((c) => <CountRow key={c.uid} c={c} onPress={() => nav.push('TillCountView', { uid: c.uid })} />)}
      </Section>
    </Screen>
  );
}
function CountRow({ c, onPress }) {
  return <ListItem testID={`count-${c.uid}`} onPress={onPress} title={`${shopName(c.shop_code)} · ${c.till_name} · ${c.shift}`} sub={`${c.shift_date} · ${c.cashier_name} · counted by ${c.counted_by_name}${c.status === 'approved' ? ` · approved by ${c.approved_by_name}` : c.status === 'queried' ? ' · QUERIED' : ' · to approve'}`}
    right={$(c.cash_counted)} rightSub={OS(c.over_short)} badge={OS(c.over_short)} badgeColor={osColor(c.over_short)} tone={c.over_short < -0.004 ? 'danger' : undefined} />;
}

// ---------------------------------------------------------------- count a till
function Denoms({ value, onChange, testIDPrefix }) {
  const { isPhone } = useLayout();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {T.DENOMS.map((d) => {
        const n = Number(value[d.key]) || 0;
        return (
          <View key={d.key} style={{ width: isPhone ? '47%' : 170, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 6 }}>
            <Text style={{ width: 52, fontSize: 18, fontWeight: '900', color: C.text }}>{d.label}</Text>
            <Text style={{ fontSize: 16, color: C.sub }}>×</Text>
            <TextInput testID={`${testIDPrefix}-${d.key}`} value={value[d.key] === undefined ? '' : String(value[d.key])} keyboardType="number-pad" placeholder="0"
              onChangeText={(t) => onChange({ ...value, [d.key]: t.replace(/\D/g, '') })}
              style={{ flex: 1, minWidth: 40, borderWidth: 2, borderColor: C.border, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, fontSize: 20, color: C.text, backgroundColor: C.white }} />
            <Text style={{ width: 62, textAlign: 'right', fontSize: 14, color: n ? C.text : C.sub }}>{n ? $(n * d.value) : ''}</Text>
          </View>
        );
      })}
    </View>
  );
}
function Lines({ items, onChange, fields, addLabel, testIDPrefix }) {
  return (
    <View style={{ gap: 8 }}>
      {items.map((it, i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          {fields.map((f) => (
            <View key={f.key} style={{ flexGrow: f.grow || 1, flexBasis: f.basis || 120 }}>
              {f.options ? <Select label={f.label} value={it[f.key]} onChange={(v) => onChange(items.map((x, k) => (k === i ? { ...x, [f.key]: v } : x)))} options={f.options.map((o) => ({ value: o, label: o }))} />
                : <Field testID={`${testIDPrefix}-${i}-${f.key}`} label={f.label} value={it[f.key] === undefined ? '' : String(it[f.key])} keyboardType={f.money ? 'decimal-pad' : undefined}
                  onChangeText={(v) => onChange(items.map((x, k) => (k === i ? { ...x, [f.key]: f.money ? v.replace(/[^0-9.\-]/g, '') : v } : x)))} />}
            </View>
          ))}
          <Btn title="✕" size="sm" variant="ghost" onPress={() => onChange(items.filter((_, k) => k !== i))} />
        </View>
      ))}
      <Btn testID={`${testIDPrefix}-add`} title={addLabel} size="sm" variant="secondary" onPress={() => onChange(items.concat([{}]))} />
    </View>
  );
}

export function TillCountScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = T.tillRules();
  const before = params.uid ? T.getTillCount(params.uid) : null;
  const [c, setC] = useState(() => (before ? {
    uid: before.uid, shopCode: before.shop_code, tillUid: before.till_uid, shiftDate: before.shift_date, shift: before.shift, cashierUid: before.cashier_uid, openingFloat: String(before.opening_float),
    denominations: before.denominations, zNumber: before.z_number || '', zTotal: before.z_total == null ? '' : String(before.z_total), zCash: String(before.z_cash), tenders: before.tenders.map((t) => ({ ...t, amount: String(t.amount) })),
    payouts: before.payouts.map((p) => ({ ...p, amount: String(p.amount) })), drops: String(before.drops || ''), adjustments: before.adjustments.map((a) => ({ ...a, amount: String(a.amount) })),
    floatKept: String(before.float_kept), reason: before.reason || '', notes: before.notes || '',
  } : { shopCode: user.shop_code || (shops()[0] && shops()[0].code) || '', tillUid: '', shiftDate: dateStr(), shift: rules.shifts[0], cashierUid: user.uid, openingFloat: '', denominations: {},
    zNumber: '', zTotal: '', zCash: '', tenders: rules.tenders.slice(0, 2).map((m) => ({ method: m, amount: '' })), payouts: [], drops: '', adjustments: [], floatKept: '', reason: '', notes: '' }));
  const [photos, setPhotos] = useState([]);
  const [shown, setShown] = useState(!rules.blindCount || !!before);
  const set = (k) => (v) => setC((o) => ({ ...o, [k]: v }));
  const tills = T.listTills({ shopCode: c.shopCode });
  const tillUid = c.tillUid || (tills[0] && tills[0].uid) || '';
  const till = tills.find((t) => t.uid === tillUid);
  const opening = c.openingFloat !== '' ? c.openingFloat : String(till ? T.openingFloat(till.uid) : 0);
  const floatKept = c.floatKept !== '' ? c.floatKept : String(till ? till.float_amount : 0);
  const data = { ...c, tillUid, openingFloat: opening, floatKept };
  const w = T.workOut(data);
  const staff = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const save = () => {
    try {
      const r = T.saveTillCount(user, data, { photos });
      ui.toast(Math.abs(r.over_short) < 0.005 ? 'Saved – balanced' : `Saved – ${OS(r.over_short).toLowerCase()}`);
      nav.replace('TillCountView', { uid: r.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={before ? 'Change till count' : 'Count a till'} subtitle={`${shopName(c.shopCode)}${till ? ` · ${till.name}` : ''} · ${c.shift}`}
      footer={<Btn testID="tc-save" title={shown ? `Save · ${OS(w.overShort)}` : 'Save the count'} icon="💾" variant={shown && w.overShort < -rules.tolerance ? 'danger' : 'success'} onPress={save} />}>
      <Card>
        <Label>Shop</Label>
        <Chips value={c.shopCode} onChange={(v) => setC((o) => ({ ...o, shopCode: v, tillUid: '', openingFloat: '', floatKept: '' }))} testIDPrefix="tc-shop" options={shopChips()} />
        {tills.length > 1 ? <><Label>Till</Label><Chips value={tillUid} onChange={(v) => setC((o) => ({ ...o, tillUid: v, openingFloat: '', floatKept: '' }))} testIDPrefix="tc-till" options={tills.map((t) => ({ value: t.uid, label: t.name }))} /></> : null}
        {!tills.length ? <Banner tone="warn" message="No tills set up for this shop yet (Till & cash › Tills & rules). You can still count." /> : null}
        <Label>Shift</Label>
        <Chips value={c.shift} onChange={set('shift')} testIDPrefix="tc-shift" options={rules.shifts.map((s) => ({ value: s, label: s }))} />
        <DateField label="Date" value={c.shiftDate} onChange={set('shiftDate')} />
        {staff.length ? <Select label="Cashier on this till" value={c.cashierUid} onChange={set('cashierUid')} options={staff.map((u) => ({ value: u.uid, label: u.name }))} /> : null}
      </Card>
      <Card>
        <H>1. Count the cash in the till</H>
        <Denoms value={c.denominations} onChange={set('denominations')} testIDPrefix="tc-d" />
        <Text testID="tc-counted" style={{ fontSize: 22, fontWeight: '900', color: C.text, marginTop: 8 }}>Counted: {$(w.counted)}</Text>
        <MoneyField testID="tc-float-kept" label="Float left in the till for the next shift" value={floatKept} onChange={set('floatKept')} />
        <Text style={{ fontSize: 16, color: C.sub }}>Cash taken out to the safe / office: {$(w.toSafe)}</Text>
      </Card>
      <Card>
        <H>2. From the Z report</H>
        <Field testID="tc-z" label="Z report number" value={c.zNumber} onChangeText={set('zNumber')} />
        <MoneyField testID="tc-ztotal" label="Total sales" value={c.zTotal} onChange={set('zTotal')} />
        <MoneyField testID="tc-zcash" label="CASH sales" value={c.zCash} onChange={set('zCash')} />
        <Label>Other payments on the Z report</Label>
        <Lines items={c.tenders} onChange={set('tenders')} testIDPrefix="tc-tender" addLabel="+ Another payment type"
          fields={[{ key: 'method', label: 'Type', options: rules.tenders, grow: 2 }, { key: 'amount', label: 'Amount', money: true }]} />
        {w.zCheck !== null && Math.abs(w.zCheck) > 0.004 ? <Banner tone="warn" message={`Total sales minus cash and the other payments leaves ${$(w.zCheck)}. Check the Z report figures.`} /> : null}
        <PhotoPicker testID="tc-photo" label="Photo of the Z report" value={photos} onChange={setPhotos} required={rules.requireZPhoto} />
        {before && before.photos.length ? <Text style={{ fontSize: 14, color: C.sub }}>{before.photos.length} photo(s) already saved.</Text> : null}
      </Card>
      <Card>
        <H>3. Cash in and out during the shift</H>
        <MoneyField testID="tc-opening" label="Float at the start of the shift" value={opening} onChange={set('openingFloat')} />
        <Label>Cash paid out of the till</Label>
        <Lines items={c.payouts} onChange={set('payouts')} testIDPrefix="tc-payout" addLabel="+ Cash paid out"
          fields={[{ key: 'what', label: 'What for', options: rules.payoutTypes, grow: 2 }, { key: 'amount', label: 'Amount', money: true }, { key: 'note', label: 'Note', grow: 2 }]} />
        <MoneyField label="Cash taken to the safe during the shift (drops)" value={c.drops} onChange={set('drops')} />
        <Label>Corrections (manual entries, each with a reason)</Label>
        <Lines items={c.adjustments} onChange={set('adjustments')} testIDPrefix="tc-adj" addLabel="+ Correction"
          fields={[{ key: 'amount', label: 'Amount (+ or −)', money: true }, { key: 'reason', label: 'Reason', grow: 3 }]} />
      </Card>
      {shown ? (
        <Card tone={Math.abs(w.overShort) <= rules.tolerance ? 'success' : 'danger'}>
          <Row label="Float at start" value={$(opening)} />
          <Row label="+ Cash sales (Z)" value={$(c.zCash)} />
          <Row label="− Paid out" value={$(w.payouts)} />
          {r2(c.drops) ? <Row label="− Drops to safe" value={$(c.drops)} /> : null}
          {w.adjust ? <Row label="± Corrections" value={$(w.adjust)} /> : null}
          <Row label="= Cash that should be in the till" value={$(w.expected)} bold />
          <Row label="Cash counted" value={$(w.counted)} bold />
          <Row label="Difference" value={OS(w.overShort)} bold color={osColor(w.overShort)} />
        </Card>
      ) : (
        <Card><Text style={{ fontSize: 16, color: C.sub }}>Blind count: the expected cash is shown after you save.</Text><Btn title="Show it now" size="sm" variant="ghost" onPress={() => setShown(true)} /></Card>
      )}
      <Card>
        <Field testID="tc-reason" label={`Reason for any difference${Math.abs(w.overShort) > rules.tolerance ? ' (required)' : ''}`} value={c.reason} onChangeText={set('reason')} multiline />
        <Field label="Notes" value={c.notes} onChangeText={set('notes')} />
      </Card>
      {can && null}
    </Screen>
  );
}

export function TillCountViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [note, setNote] = useState('');
  const c = T.getTillCount(params.uid);
  if (!c) return <Screen title="Till count"><Text>Not found.</Text></Screen>;
  const local = listPhotos('till', c.uid);
  return (
    <Screen title={`${shopName(c.shop_code)} · ${c.till_name} · ${c.shift}`} subtitle={`${c.shift_date} · ${c.cashier_name}`}>
      <Banner testID="tc-result" tone={Math.abs(c.over_short) < 0.005 ? 'success' : c.over_short > 0 ? 'warn' : 'danger'} title={OS(c.over_short)}
        message={`${c.status === 'approved' ? `Approved by ${c.approved_by_name}` : c.status === 'queried' ? `Queried: ${c.approve_note}` : c.status === 'void' ? `Void: ${c.void_reason}` : 'Waiting for approval'}${c.reason ? `\nReason: ${c.reason}` : ''}`} />
      <Card>
        <Row label="Counted" value={$(c.cash_counted)} bold />
        <Row label="Should be" value={$(c.expected_cash)} />
        <Row label="Float at start / left" value={`${$(c.opening_float)} / ${$(c.float_kept)}`} />
        <Row label="Z report" value={`${c.z_number || '—'} · total ${c.z_total == null ? '—' : $(c.z_total)} · cash ${$(c.z_cash)}`} />
        {c.tenders.map((t) => <Row key={t.method} label={t.method} value={$(t.amount)} />)}
        {c.payouts.map((p, i) => <Row key={i} label={`Paid out: ${p.what}${p.note ? ` (${p.note})` : ''}`} value={$(p.amount)} />)}
        {c.drops ? <Row label="Drops to safe" value={$(c.drops)} /> : null}
        {c.adjustments.map((a, i) => <Row key={i} label={`Correction: ${a.reason}`} value={$(a.amount)} />)}
        <Row label="Counted by" value={`${c.counted_by_name} · ${String(c.counted_at).slice(0, 16)}`} />
        {c.notes ? <Row label="Notes" value={c.notes} /> : null}
      </Card>
      <Section title="Notes and coins">
        <Text style={{ fontSize: 16, color: C.text }}>{T.DENOMS.filter((d) => Number(c.denominations[d.key])).map((d) => `${d.label} × ${c.denominations[d.key]}`).join('   ') || 'Total typed in'}</Text>
      </Section>
      {local.length ? <Section title="Z report photo"><View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>{local.map((p) => <Image key={p.id} source={{ uri: p.uri }} style={{ width: 160, height: 220, borderRadius: 10 }} />)}</View></Section> : null}
      {c.status === 'counted' || c.status === 'queried' ? (
        <View style={{ gap: 10 }}>
          <Btn testID="tc-edit" title="Change the count" variant="secondary" onPress={() => nav.push('TillCount', { uid: c.uid })} />
          {can('till_approve') ? (
            <Card>
              <Field testID="tc-note" label="Note (required to query)" value={note} onChangeText={setNote} />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
                <Btn testID="tc-approve" title="Approve" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => T.approveTillCount(user, c.uid, { note }), 'Approved')} />
                <Btn title="Query" variant="warn" style={{ flexGrow: 1 }} onPress={() => act(() => T.approveTillCount(user, c.uid, { query: true, note }), 'Queried')} />
                <Btn title="Void" variant="ghost" onPress={() => act(() => T.voidTillCount(user, c.uid, note), 'Voided')} />
              </View>
            </Card>
          ) : null}
        </View>
      ) : null}
      {c.status === 'approved' && can('till_approve') ? (
        <Card>
          <Field label="Reason to re-open" value={note} onChangeText={setNote} />
          <Btn title="Re-open" variant="warn" style={{ marginTop: 10 }} onPress={() => act(() => T.reopenTillCount(user, c.uid, note), 'Re-opened')} />
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- deposits
export function DepositScreen() {
  const { nav, user } = useApp();
  const ui = useUI();
  const accounts = listAccounts();
  const richest = () => shops().map((s) => ({ code: s.code, cash: T.cashOnHand(s.code).onHand })).sort((a, b) => b.cash - a.cash)[0];
  const [d, setD] = useState({ shopCode: user.shop_code || (richest() && richest().code) || '', accountUid: accounts[0] ? accounts[0].uid : '', date: dateStr(), slipNo: '', branch: '', byNotes: true, denominations: {}, cashAmount: '', cheques: [], takingsFrom: dateStr(), takingsTo: dateStr(), witness: '', notes: '' });
  const [photos, setPhotos] = useState([]);
  const set = (k) => (v) => setD((o) => ({ ...o, [k]: v }));
  const cash = d.byNotes ? T.countDenoms(d.denominations) : r2(d.cashAmount);
  const chq = r2(d.cheques.reduce((s, c) => s + r2(c.amount), 0));
  const onHand = d.shopCode ? T.cashOnHand(d.shopCode).onHand : 0;
  const save = () => {
    try {
      const r = T.saveDeposit(user, { ...d, denominations: d.byNotes ? d.denominations : {}, cashAmount: cash }, { photos });
      ui.toast(`Deposit ${$(r.total)} saved`);
      nav.pop();
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Bank deposit" subtitle={`Cash at ${shopName(d.shopCode)}: ${$(onHand)}`} footer={<Btn testID="dep-save" title={`Save deposit ${$(cash + chq)}`} icon="🏦" variant="success" onPress={save} />}>
      {!accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices & cheques › Cheques & bank › Accounts." /> : null}
      <Card>
        <Label>Cash from</Label>
        <Chips value={d.shopCode} onChange={set('shopCode')} testIDPrefix="dep-shop" options={shopChips()} />
        <Select label="Into account" value={d.accountUid} onChange={set('accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} />
        <DateField label="Date banked" value={d.date} onChange={set('date')} />
        <Field testID="dep-slip" label="Deposit slip number" value={d.slipNo} onChangeText={set('slipNo')} />
        <Field label="Branch / ATM" value={d.branch} onChangeText={set('branch')} placeholder="e.g. BSP Lautoka" />
        <DateField label="Takings from" value={d.takingsFrom} onChange={set('takingsFrom')} />
        <DateField label="Takings to" value={d.takingsTo} onChange={set('takingsTo')} />
      </Card>
      <Card>
        <H>Cash</H>
        <Chips value={d.byNotes} onChange={set('byNotes')} options={[{ value: true, label: 'Count notes & coins' }, { value: false, label: 'Type the total' }]} />
        {d.byNotes ? <Denoms value={d.denominations} onChange={set('denominations')} testIDPrefix="dep-d" /> : <MoneyField testID="dep-cash" label="Cash total" value={d.cashAmount} onChange={set('cashAmount')} />}
        <Text style={{ fontSize: 20, fontWeight: '900', color: C.text }}>Cash {$(cash)}</Text>
      </Card>
      <Card>
        <H>Cheques in this deposit</H>
        <Lines items={d.cheques} onChange={set('cheques')} testIDPrefix="dep-chq" addLabel="+ Cheque"
          fields={[{ key: 'drawer', label: 'From (customer)', grow: 2 }, { key: 'bank', label: 'Bank' }, { key: 'number', label: 'Cheque no' }, { key: 'amount', label: 'Amount', money: true }]} />
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Cheques {$(chq)}</Text>
      </Card>
      <Card>
        <Field label="Witness / second person (optional)" value={d.witness} onChangeText={set('witness')} />
        <Field label="Notes" value={d.notes} onChangeText={set('notes')} multiline />
        <PhotoPicker label="Photo of the stamped deposit slip" value={photos} onChange={setPhotos} />
        <Text style={{ fontSize: 15, color: C.sub }}>Banked by {user.name}</Text>
      </Card>
    </Screen>
  );
}
export function DepositListScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [reason, setReason] = useState('');
  const rows = T.listDeposits({ includeVoid: true });
  return (
    <Screen title="Deposits" subtitle={`${rows.length}`}>
      {rows.map((d) => (
        <View key={d.uid} style={{ gap: 6 }}>
          <ListItem testID={`dep-${d.slip_no}`} onPress={() => setOpen(open === d.uid ? null : d.uid)} title={`${shopName(d.shop_code)} · slip ${d.slip_no}`}
            sub={`${d.deposit_date} · ${d.deposited_by_name}${d.account_name ? ` · ${d.account_name}` : ''}${d.cleared_date ? ` · on statement ${d.cleared_date}` : ' · not on a statement yet'}`}
            right={$(d.total)} rightSub={d.cheque_amount ? `cash ${$(d.cash_amount)} + chq ${$(d.cheque_amount)}` : null} badge={d.status === 'void' ? 'VOID' : null} badgeColor={C.sub} />
          {open === d.uid && d.status === 'active' && can('deposits') ? (
            <Card>
              {T.getDeposit(d.uid).cheques.map((c, i) => <Row key={i} label={`Cheque ${c.number} ${c.drawer} (${c.bank})`} value={$(c.amount)} />)}
              {d.takings_from ? <Row label="Takings" value={`${d.takings_from} to ${d.takings_to || d.takings_from}`} /> : null}
              {d.witness ? <Row label="Witness" value={d.witness} /> : null}
              {d.notes ? <Row label="Notes" value={d.notes} /> : null}
              <Field label="Reason to void" value={reason} onChangeText={setReason} />
              <Btn title="Void deposit" variant="danger" size="sm" style={{ marginTop: 8 }} onPress={() => { if (act(() => T.voidDeposit(user, d.uid, reason), 'Voided')) setOpen(null); }} />
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- cash on hand
export function CashOnHandScreen({ params }) {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [shop, setShop] = useState(params.shopCode || user.shop_code || (shops()[0] && shops()[0].code) || '');
  const [f, setF] = useState(null);
  const rules = T.tillRules();
  const c = T.cashOnHand(shop);
  const moves = T.listCashMoves({ shopCode: shop, limit: 100 });
  return (
    <Screen title="Cash on hand" subtitle={`${shopName(shop)}: ${$(c.onHand)} + floats ${$(c.floats)}`}>
      <Chips value={shop} onChange={setShop} testIDPrefix="coh-shop" options={shopChips()} />
      <Card>
        <Row label="Cash in the safe / office" value={$(c.onHand)} bold />
        <Row label="Floats in the tills" value={$(c.floats)} />
        <Row label="Total cash at the shop" value={$(c.total)} bold />
        <Row label="Paid to suppliers in cash (all time)" value={$(c.supplierCash)} />
      </Card>
      {f ? (
        <Card>
          <Chips value={f.type} onChange={(v) => setF({ ...f, type: v })} testIDPrefix="coh-type"
            options={[{ value: 'petty_out', label: 'Petty cash spent' }, { value: 'petty_in', label: 'Top-up' }, { value: 'transfer', label: 'To another shop' }, { value: 'opening', label: 'Starting cash' }, { value: 'adjust_in', label: 'Correction +' }, { value: 'adjust_out', label: 'Correction −' }]} />
          {f.type === 'transfer' ? <><Label>To</Label><Chips value={f.toShop} onChange={(v) => setF({ ...f, toShop: v })} options={shopChips().filter((o) => o.value !== shop)} /></> : null}
          {f.type === 'petty_out' ? <Select label="Category" value={f.category} onChange={(v) => setF({ ...f, category: v })} options={rules.pettyCategories.map((x) => ({ value: x, label: x }))} /> : null}
          <MoneyField testID="coh-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field testID="coh-note" label={f.type === 'petty_out' ? 'What was bought' : 'Note / reason'} value={f.note} onChangeText={(v) => setF({ ...f, note: v })} />
          {f.type === 'petty_out' ? <PhotoPicker label="Receipt" value={f.photos} onChange={(v) => setF({ ...f, photos: v })} /> : null}
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="coh-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => T.recordCash(user, { ...f, shopCode: shop }), 'Saved')) setF(null); }} />
          </View>
        </Card>
      ) : <Btn testID="coh-add" title="Petty cash / move cash" icon="➕" variant="secondary" onPress={() => setF({ type: 'petty_out', amount: '', date: dateStr(), note: '', category: rules.pettyCategories[0], toShop: '', photos: [] })} />}
      <Section title="Movements">
        {moves.map((m) => (
          <ListItem key={m.uid} title={`${T.MOVE_LABEL[m.type]}${m.category ? ` · ${m.category}` : ''}`} sub={`${m.move_date} · ${m.by_name || ''}${m.note ? ` · ${m.note}` : ''}`}
            right={`${['opening', 'from_till', 'petty_in', 'transfer_in', 'adjust_in'].includes(m.type) ? '+' : '−'}${$(m.amount)}`}
            onPress={['from_till', 'deposit'].includes(m.type) ? null : async () => {
              const ok = await ui.confirm({ title: 'Void this?', message: `${T.MOVE_LABEL[m.type]} ${$(m.amount)} on ${m.move_date}`, confirmText: 'Void', tone: 'danger' });
              if (ok) act(() => T.voidCashMove(user, m.uid, 'Voided on Cash on hand'), 'Voided');
            }} />
        ))}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- setup
export function TillSetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = T.tillRules();
  const [f, setF] = useState({ ...r0, tolerance: String(r0.tolerance), shifts: r0.shifts.join('\n'), tenders: r0.tenders.join('\n'), payoutTypes: r0.payoutTypes.join('\n'), pettyCategories: r0.pettyCategories.join('\n') });
  const [t, setT] = useState(null);
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const yn = (k) => <Chips value={f[k]} onChange={set(k)} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />;
  return (
    <Screen title="Tills & rules" footer={<Btn testID="till-rules-save" title="Save rules" icon="💾" variant="success" onPress={() => act(() => T.saveTillRules(user, f), 'Saved')} />}>
      <Section title="Tills">
        {T.listTills({ includeInactive: true }).map((x) => <ListItem key={x.uid} title={`${shopName(x.shop_code)} · ${x.name}`} sub={`Float ${$(x.float_amount)}${x.active ? '' : ' · not used'}`} right="Change"
          onPress={() => setT({ uid: x.uid, shopCode: x.shop_code, name: x.name, floatAmount: String(x.float_amount), active: !!x.active })} />)}
        {t ? (
          <Card>
            <Chips value={t.shopCode} onChange={(v) => setT({ ...t, shopCode: v })} testIDPrefix="till-shop" options={shopChips()} />
            <Field testID="till-name" label="Till name" value={t.name} onChangeText={(v) => setT({ ...t, name: v })} />
            <MoneyField testID="till-float" label="Standard float" value={t.floatAmount} onChange={(v) => setT({ ...t, floatAmount: v })} />
            <Chips value={t.active} onChange={(v) => setT({ ...t, active: v })} options={[{ value: true, label: 'In use' }, { value: false, label: 'Not used' }]} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setT(null)} />
              <Btn testID="till-save" title="Save till" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => T.saveTill(user, t), 'Saved')) setT(null); }} />
            </View>
          </Card>
        ) : <Btn testID="till-add" title="Add a till" icon="➕" variant="secondary" onPress={() => setT({ shopCode: shops()[0] ? shops()[0].code : '', name: 'Till 1', floatAmount: '200', active: true })} />}
      </Section>
      <Card>
        <Field label="Difference allowed without a reason ($)" value={f.tolerance} onChangeText={set('tolerance')} keyboardType="decimal-pad" />
        <Label>Photo of the Z report required</Label>{yn('requireZPhoto')}
        <Label>Blind count (cashier does not see the expected cash first)</Label>{yn('blindCount')}
        <Label>A manager must approve each count</Label>{yn('managerApproves')}
      </Card>
      <Card>
        <Field label="Shift names (one per line)" value={f.shifts} onChangeText={set('shifts')} multiline />
        <Field label="Payment types on the Z report (one per line)" value={f.tenders} onChangeText={set('tenders')} multiline />
        <Field label="Cash paid out types (one per line)" value={f.payoutTypes} onChangeText={set('payoutTypes')} multiline />
        <Field label="Petty cash categories (one per line)" value={f.pettyCategories} onChangeText={set('pettyCategories')} multiline />
      </Card>
    </Screen>
  );
}
