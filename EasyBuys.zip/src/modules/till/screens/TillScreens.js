// Till & cash screens: overview, count a till (with the Z report), one count, deposits, cash on hand, setup.
import { FixButton } from '../../admin/screens/RecordFixScreen.js';
import React, { useState } from 'react';
import { View, Image, TextInput } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, PhotoPicker, Label, useApp, useUI, useLayout, Choice } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, ReasonButton, Action, Actions, ReasonField } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { usePaper, PaperPhoto, receiptApply } from '../../../ui/paperPhoto.js';
import { applyZRead, zReadChanges, Z_LABELS } from '../zRead.js';
import * as RC from '../recount.js';
import { DepositCoverPicker } from '../../payables/screens/CoverScreens.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { listUsers } from '../../../services/catalog.js';
import { listAccounts } from '../../payables/service.js';
import * as T from '../service.js';
import { offerPdf } from '../../../ui/shareDoc.js';
import { depositDoc } from '../../../services/taskDocs.js';
import { SignBox, SignedBy } from './Till35Screens.js';
import { getShift, shortageForCount, SHORT_STATUS } from '../shifts.js';
import { eodForCount, EOD_STATE } from '../eod.js';

const { $, r2 } = T;
const shops = () => listShops().filter((s) => s.active);
const shopName = (code) => { const s = listShops().find((x) => x.code === code); return s ? s.name.replace(/^Shop (\d) - /, 'Shop $1 ') : code; };
const shopChips = () => shops().map((s) => ({ value: s.code, label: shopName(s.code) }));
const OS = (n) => (Math.abs(n) < 0.005 ? 'Balanced' : n > 0 ? `Over ${$(n)}` : `Short ${$(-n)}`);
const osColor = (n) => (Math.abs(n) < 0.005 ? C.success : n > 0 ? C.warn : C.danger);

// ---------------------------------------------------------------- overview
export function TillHomeScreen() {
  const { nav, can } = useApp();
  const a = T.tillAlerts();
  const waiting = can('till_approve') ? T.listTillCounts({ status: 'counted' }).concat(T.listTillCounts({ status: 'queried' })) : [];
  const recent = T.listTillCounts({ limit: 15 });
  return (
    <Screen title="Till & cash" subtitle="Till counts, cash at each shop, deposits">
      {can('till_approve') || can('deposits') ? (
        <Stats items={shops().map((s) => { const c = T.cashOnHand(s.code); return { label: `${shopName(s.code)} cash`, value: $(c.onHand), sub: `+ floats ${$(c.floats)}`, onPress: () => nav.push('CashOnHand', { shopCode: s.code }), testID: `cash-${s.code}` }; })} />
      ) : null}
      {a.shortWeek ? <Banner tone="danger" title={`${a.shortWeek} short till(s) in the last 7 days`} message={`Total ${$(-a.shortAmount)} short.`} /> : null}
      {can('till_approve') && a.repeat.length ? <Banner tone="danger" title="Short again and again (last 30 days)" message={a.repeat.map((p) => `${p.name}: ${p.times} times, ${$(-p.amount)}`).join('\n')} /> : null}
      <Section title="Every day">
        <Actions>
          {can('till_count') ? <Action testID="till-shifts" icon="🔁" title="Till shifts" note="Start a shift; the next shift starts only when the last one is balanced." badge={a.continued && a.continued.length ? a.continued.length : null} onPress={() => nav.push('TillShifts', {})} /> : null}
          {can('till_approve') ? <Action testID="till-eod" icon="🧾" title="Aronium End of day" note="Matched to each shift's Z. Differences and missing till balances are red." badge={(a.eodDiff || []).length + (a.eodNoTill || []).length || null} tone={(a.eodDiff || []).length + (a.eodNoTill || []).length ? 'danger' : undefined} onPress={() => nav.push('AroniumEods', {})} /> : null}
          <Action testID="till-shortages" icon="✍️" title="Till shortages" note="The cashier agrees and signs, or a manager decides." badge={(a.shortages || []).length || null} onPress={() => nav.push('TillShortages', {})} />
          {can('till_count') ? <Action testID="till-count" icon="🧮" title="Count a till" note="End of shift: count notes and coins, type the Z report totals and take its photo. Any short or over is worked out." onPress={() => nav.push('TillCount', {})} /> : null}
          {can('deposits') ? <Action testID="till-deposit" icon="🏦" title="Bank deposit" note="Cash and cheques taken to the bank, with a photo of the slip. Verified when it shows in the bank." onPress={() => nav.push('Deposit', {})} /> : null}
          {can('deposits') ? <Action testID="till-cash" icon="👛" title="Petty cash, move cash, count the safe" note="Money spent from the safe (with receipt), cash moved between shops, and safe counts." onPress={() => nav.push('CashOnHand', {})} /> : null}
          {can('snap_upload') ? <Action icon="📷" title="Photo of an invoice or cheque" note="Something a supplier left, or a cheque handed over – a supervisor confirms it." onPress={() => nav.push('Snap', {})} /> : null}
        </Actions>
      </Section>
      <Section title="Office">
        <Actions>
          {can('deposits') ? <Action icon="📒" title="Deposits" note="Every deposit and whether the bank has it yet." onPress={() => nav.push('Deposits')} /> : null}
          {can('till_approve') ? <Action testID="till-setup" icon="⚙️" title="Tills & rules" note="Tills and floats, payment types, shortage rules, petty cash types." onPress={() => nav.push('TillSetup')} /> : null}
        </Actions>
      </Section>
      {waiting.length ? (
        <Section title={`Waiting for approval (${waiting.length})`}>
          {waiting.map((c) => <CountRow key={c.uid} c={c} onPress={() => nav.push('TillCountView', { uid: c.uid })} />)}
        </Section>
      ) : null}
      <Section title="Recent counts">
        {!recent.length ? <Text style={{ fontSize: 16, color: C.sub }}>No till counts yet.</Text> : null}
        {recent.map((c) => <CountRow key={c.uid} c={c} onPress={() => nav.push('TillCountView', { uid: c.uid })} />)}
      </Section>
    </Screen>
  );
}
function CountRow({ c, onPress }) {
  const eod = eodForCount(c.uid);
  const red = eod && (eod.state === 'difference');
  const unsigned = !c.cashier_sig || !c.balancer_sig;
  return <ListItem testID={`count-${c.uid}`} onPress={onPress} title={`${red ? '🔴 ' : ''}${shopName(c.shop_code)} · ${c.till_name} · ${c.shift}`} sub={`${c.shift_date} · ${c.cashier_name} · counted by ${c.counted_by_name}${c.status === 'approved' ? ` · approved by ${c.approved_by_name}` : c.status === 'queried' ? ' · QUERIED' : ' · to approve'}${unsigned && c.status !== 'approved' ? ' · NOT SIGNED' : ''}${red ? ` · Aronium differs ${$(eod.diff)}` : ''}`}
    right={$(c.cash_counted)} rightSub={OS(c.over_short)} badge={red ? 'ARONIUM DIFFERS' : OS(c.over_short)} badgeColor={red ? C.danger : osColor(c.over_short)} tone={c.over_short < -0.004 || red ? 'danger' : undefined} />;
}

// ---------------------------------------------------------------- count a till
function Denoms({ value, onChange, testIDPrefix }) {
  const { isPhone } = useLayout();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {T.DENOMS.map((d) => {
        const n = Number(value[d.key]) || 0;
        return (
          <View key={d.key} style={{ width: isPhone ? '47%' : 170, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 6 }}>
            <Text style={{ width: 52, fontSize: 18, fontWeight: '900', color: C.text }}>{d.label}</Text>
            <Text style={{ fontSize: 16, color: C.sub }}>×</Text>
            <TextInput testID={`${testIDPrefix}-${d.key}`} value={value[d.key] === undefined ? '' : String(value[d.key])} keyboardType="number-pad" placeholder="0"
              onChangeText={(t) => onChange({ ...value, [d.key]: t.replace(/\D/g, '') })}
              style={{ flex: 1, minWidth: 40, borderWidth: 2, borderColor: C.border, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, fontSize: 20, color: C.text, backgroundColor: C.white }} />
            <Text style={{ width: 62, textAlign: 'right', fontSize: 14, color: n ? C.text : C.sub }}>{n ? $(n * d.value) : ''}</Text>
          </View>
        );
      })}
    </View>
  );
}
function Lines({ items, onChange, fields, addLabel, testIDPrefix }) {
  return (
    <View style={{ gap: 8 }}>
      {items.map((it, i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          {fields.map((f) => (
            <View key={f.key} style={{ flexGrow: f.grow || 1, flexBasis: f.basis || 120 }}>
              {f.options ? <Select label={f.label} value={it[f.key]} onChange={(v) => onChange(items.map((x, k) => (k === i ? { ...x, [f.key]: v } : x)))} options={f.options.map((o) => ({ value: o, label: o }))} />
                : <Field testID={`${testIDPrefix}-${i}-${f.key}`} label={f.label} value={it[f.key] === undefined ? '' : String(it[f.key])} keyboardType={f.money ? 'decimal-pad' : undefined}
                  onChangeText={(v) => onChange(items.map((x, k) => (k === i ? { ...x, [f.key]: f.money ? v.replace(/[^0-9.\-]/g, '') : v } : x)))} />}
            </View>
          ))}
          <Btn title="✕" size="sm" variant="ghost" onPress={() => onChange(items.filter((_, k) => k !== i))} />
        </View>
      ))}
      <Btn testID={`${testIDPrefix}-add`} title={addLabel} size="sm" variant="secondary" onPress={() => onChange(items.concat([{}]))} />
    </View>
  );
}

// Opened from a shift (Till shifts) or from an Aronium End of day with the till balance missing: fill in what is known.
function prefill(params) {
  const sh = params.shiftUid ? getShift(params.shiftUid) : null;
  if (sh) return { shopCode: sh.shop_code, tillUid: sh.till_uid || '', shiftDate: sh.shift_date, shift: sh.shift, cashierUid: sh.cashier_uid, openingFloat: sh.opening_float == null ? '' : String(sh.opening_float), zNumber: sh.eod_z_number || '', zTotal: sh.eod_total == null ? '' : String(sh.eod_total) };
  const out = {};
  if (params.shopCode) out.shopCode = params.shopCode;
  if (params.shiftDate) out.shiftDate = params.shiftDate;
  if (params.zNumber) out.zNumber = params.zNumber;
  return out;
}
export function TillCountScreen({ params }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const rules = T.tillRules();
  const before = params.uid ? T.getTillCount(params.uid) : null;
  const [c, setC] = useState(() => (before ? {
    uid: before.uid, shopCode: before.shop_code, tillUid: before.till_uid, shiftDate: before.shift_date, shift: before.shift, cashierUid: before.cashier_uid, openingFloat: String(before.opening_float),
    denominations: before.denominations, zNumber: before.z_number || '', zTotal: before.z_total == null ? '' : String(before.z_total), zCash: String(before.z_cash), zVat: before.z_vat == null ? '' : String(before.z_vat), zZeroRated: before.z_zero_rated == null ? '' : String(before.z_zero_rated),
    zRefunds: before.z_refunds == null ? '' : String(before.z_refunds), zVoids: before.z_voids == null ? '' : String(before.z_voids), zCustomers: before.z_customers == null ? '' : String(before.z_customers), tenders: before.tenders.map((t) => ({ ...t, amount: String(t.amount) })),
    payouts: before.payouts.map((p) => ({ ...p, amount: String(p.amount) })), drops: String(before.drops || ''), adjustments: before.adjustments.map((a) => ({ ...a, amount: String(a.amount) })),
    floatKept: String(before.float_kept), reason: before.reason || '', notes: before.notes || '',
  } : { shopCode: user.shop_code || (shops()[0] && shops()[0].code) || '', tillUid: '', shiftDate: dateStr(), shift: rules.shifts[0], cashierUid: user.uid, openingFloat: '', denominations: {},
    zNumber: '', zTotal: '', zCash: '', zVat: '', zZeroRated: '', zRefunds: '', zVoids: '', zCustomers: '', tenders: rules.tenders.map((m) => ({ method: m, amount: '' })), payouts: [], drops: '', adjustments: [], floatKept: '', reason: '', notes: '', ...prefill(params) }));
  const [photos, setPhotos] = useState([]);
  const zp = usePaper('z');
  const [sigs, setSigs] = useState({ cashier: null, balancer: null });
  const [balancerUid, setBalancerUid] = useState(before && before.balancer_uid ? before.balancer_uid : user.uid);
  const [shown, setShown] = useState(!rules.blindCount || !!before);
  const set = (k) => (v) => setC((o) => ({ ...o, [k]: v }));
  const tills = T.listTills({ shopCode: c.shopCode });
  const tillUid = c.tillUid || (tills[0] && tills[0].uid) || '';
  const till = tills.find((t) => t.uid === tillUid);
  const opening = c.openingFloat !== '' ? c.openingFloat : String(till ? T.openingFloat(till.uid) : 0);
  const floatKept = c.floatKept !== '' ? c.floatKept : String(till ? till.float_amount : 0);
  const data = { ...c, tillUid, openingFloat: opening, floatKept, balancerUid, cashierSig: sigs.cashier, balancerSig: sigs.balancer };
  const w = T.workOut(data);
  const staff = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const save = () => {
    if (!zp.okToSave(ui)) return;
    try {
      const zChanged = zp.read ? zReadChanges(c, zp.read.fields) : [];
      const r = T.saveTillCount(user, { ...data, zRead: zp.summary(zChanged) }, { photos });
      zp.log(user, 'till_counts', r.uid, c, null, zChanged);
      ui.toast(Math.abs(r.over_short) < 0.005 ? 'Saved – balanced' : `Saved – ${OS(r.over_short).toLowerCase()}`);
      nav.replace('TillCountView', { uid: r.uid });
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={before ? 'Change till count' : 'Count a till'} subtitle={`${shopName(c.shopCode)}${till ? ` · ${till.name}` : ''} · ${c.shift}`}
      footer={<Btn testID="tc-save" title={shown ? `Save · ${OS(w.overShort)}` : 'Save the count'} icon="💾" variant={shown && w.overShort < -rules.tolerance ? 'danger' : 'success'} onPress={save} />}>
      <Card>
        <Label>Shop</Label>
        <Chips value={c.shopCode} onChange={(v) => setC((o) => ({ ...o, shopCode: v, tillUid: '', openingFloat: '', floatKept: '' }))} testIDPrefix="tc-shop" options={shopChips()} />
        {tills.length > 1 ? <><Label>Till</Label><Choice value={tillUid} onChange={(v) => setC((o) => ({ ...o, tillUid: v, openingFloat: '', floatKept: '' }))} testIDPrefix="tc-till" options={tills.map((t) => ({ value: t.uid, label: t.name }))} /></> : null}
        {!tills.length ? <Banner tone="warn" message="No tills set up for this shop yet (Till & cash › Tills & rules). You can still count." /> : null}
        <Label>Shift</Label>
        <Choice value={c.shift} onChange={set('shift')} testIDPrefix="tc-shift" options={rules.shifts.map((s) => ({ value: s, label: s }))} />
        <DateField label="Date" value={c.shiftDate} onChange={set('shiftDate')} />
        {staff.length ? <Select label="Cashier on this till" value={c.cashierUid} onChange={set('cashierUid')} options={staff.map((u) => ({ value: u.uid, label: u.name }))} /> : null}
      </Card>
      <Card>
        <H>1. Count the cash in the till</H>
        <Denoms value={c.denominations} onChange={set('denominations')} testIDPrefix="tc-d" />
        <Text testID="tc-counted" style={{ fontSize: 22, fontWeight: '900', color: C.text, marginTop: 8 }}>Counted: {$(w.counted)}</Text>
        <MoneyField testID="tc-float-kept" label="Float left in the till for the next shift" value={floatKept} onChange={set('floatKept')} />
        <Text style={{ fontSize: 16, color: C.sub }}>Cash taken out to the safe / office: {$(w.toSafe)}</Text>
      </Card>
      <Card>
        <H>2. From the Z report</H>
        <PaperPhoto pr={zp} testID="tc-photo" label="Photo of the Z report" value={photos} onChange={setPhotos} required={rules.requireZPhoto}
          form={c} setForm={setC} apply={(f, x, p) => applyZRead(f, { fields: x }, p)} hint="Take the photo first – the figures below fill in by themselves. Then check each one against the paper." />
        {zp.read && zp.read.fields.date && zp.read.fields.date !== c.shiftDate ? <Banner testID="tc-zdate" tone="warn" message={`The Z report is dated ${zp.read.fields.date} but this count is for ${c.shiftDate}. Is it the right Z report?`} /> : null}
        <Field testID="tc-z" label="Z report number" value={c.zNumber} onChangeText={set('zNumber')} />
        <MoneyField testID="tc-ztotal" label="Total sales" value={c.zTotal} onChange={set('zTotal')} />
        <MoneyField testID="tc-zcash" label="CASH sales" value={c.zCash} onChange={set('zCash')} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="tc-zvat" label="VAT on the Z report" value={c.zVat} onChange={set('zVat')} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField testID="tc-zzero" label="Zero-rated sales" value={c.zZeroRated} onChange={set('zZeroRated')} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField label="Refunds" value={c.zRefunds} onChange={set('zRefunds')} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><MoneyField label="Voids" value={c.zVoids} onChange={set('zVoids')} /></View>
          <View style={{ flexBasis: 150, flexGrow: 1 }}><Field label="Customers" value={c.zCustomers} onChangeText={set('zCustomers')} keyboardType="number-pad" /></View>
        </View>
        <Label>Other payments on the Z report</Label>
        <Lines items={c.tenders} onChange={set('tenders')} testIDPrefix="tc-tender" addLabel="+ Another payment type"
          fields={[{ key: 'method', label: 'Type', options: rules.tenders, grow: 2 }, { key: 'amount', label: 'Amount', money: true }]} />
        {w.zCheck !== null && Math.abs(w.zCheck) > 0.004 ? <Banner tone="warn" message={`Total sales minus cash and the other payments leaves ${$(w.zCheck)}. Check the Z report figures.`} /> : null}
        {before && before.photos.length ? <Text style={{ fontSize: 14, color: C.sub }}>{before.photos.length} photo(s) already saved.</Text> : null}
      </Card>
      <Card>
        <H>3. Cash in and out during the shift</H>
        <MoneyField testID="tc-opening" label="Float at the start of the shift" value={opening} onChange={set('openingFloat')} />
        <Label>Cash paid out of the till</Label>
        <Lines items={c.payouts} onChange={set('payouts')} testIDPrefix="tc-payout" addLabel="+ Cash paid out"
          fields={[{ key: 'what', label: 'What for', options: rules.payoutTypes, grow: 2 }, { key: 'amount', label: 'Amount', money: true }, { key: 'note', label: 'Note', grow: 2 }]} />
        <MoneyField label="Cash taken to the safe during the shift (drops)" value={c.drops} onChange={set('drops')} />
        <Label>Corrections (manual entries, each with a reason)</Label>
        <Lines items={c.adjustments} onChange={set('adjustments')} testIDPrefix="tc-adj" addLabel="+ Correction"
          fields={[{ key: 'amount', label: 'Amount (+ or −)', money: true }, { key: 'reason', label: 'Reason', grow: 3 }]} />
      </Card>
      {shown ? (
        <Card tone={Math.abs(w.overShort) <= rules.tolerance ? 'success' : 'danger'}>
          <Row label="Float at start" value={$(opening)} />
          <Row label="+ Cash sales (Z)" value={$(c.zCash)} />
          <Row label="− Paid out" value={$(w.payouts)} />
          {r2(c.drops) ? <Row label="− Drops to safe" value={$(c.drops)} /> : null}
          {w.adjust ? <Row label="± Corrections" value={$(w.adjust)} /> : null}
          <Row label="= Cash that should be in the till" value={$(w.expected)} bold />
          <Row label="Cash counted" value={$(w.counted)} bold />
          <Row label="Difference" value={OS(w.overShort)} bold color={osColor(w.overShort)} />
        </Card>
      ) : (
        <Card><Text style={{ fontSize: 16, color: C.sub }}>Blind count: the expected cash is shown after you save.</Text><Btn title="Show it now" size="sm" variant="ghost" onPress={() => setShown(true)} /></Card>
      )}
      <SignBox cashierUid={c.cashierUid} balancerUid={balancerUid} setBalancerUid={setBalancerUid} sigs={sigs} setSigs={setSigs} saveNow={false} />
      {before && before.cashier_sig ? <Hint>Changing the count clears the old signatures – both sign again.</Hint> : null}
      <Card>
        <ReasonField testID="tc-reason" label={`Reason for any difference${Math.abs(w.overShort) > rules.tolerance ? ' (required)' : ''}`} value={c.reason} onChangeText={set('reason')} multiline />
        <Field testID="tc-remarks" label="Remarks (anything the manager should know about this shift)" value={c.notes} onChangeText={set('notes')} multiline />
      </Card>
      {can && null}
    </Screen>
  );
}

export function TillCountViewScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [note, setNote] = useState('');
  const [wo, setWo] = useState({ on: false, reason: '' });
  const [sigs, setSigs] = useState({ cashier: null, balancer: null });
  const [balancerUid, setBalancerUid] = useState('');
  const [recount, setRecount] = useState(null);
  const ui = useUI();
  const c = params.uid ? T.getTillCount(params.uid) : null;
  if (!c) return <Screen title="Till count"><Text>Not found.</Text></Screen>;
  const ov = RC.surplusForCount(c.uid);
  const canRecount = c.status !== 'void' && (c.status !== 'approved' || ['owner', 'admin'].includes(user.role)) && (can('till_approve') || ['owner', 'admin'].includes(user.role)) && user.uid !== c.counted_by_uid && user.uid !== c.cashier_uid;
  // v3.9.2 Second count: the first count is not shown while counting again.
  if (recount) {
    const total = T.countDenoms(recount.denominations);
    return (
      <Screen title="Second count" subtitle={`${c.till_name} · ${c.shift} · ${c.shift_date} · cashier ${c.cashier_name}`}
        footer={<Btn testID="rc2-save" title={`Save the second count · ${$(total)}`} icon="💾" variant="success" onPress={() => {
          const r = act(() => RC.saveSecondCount(user, c.uid, { denominations: recount.denominations, note: recount.note }));
          if (r) { setRecount(null); ui.alert({ title: r.same ? 'The counts agree' : 'The counts are different', message: r.same ? `Both counts: ${$(r.counted)}.` : `Your count ${$(r.counted)} stands. The first count by ${c.counted_by_name} was ${$(r.counted - r.diff)} (difference ${r.diff > 0 ? '+' : '−'}${$(Math.abs(r.diff))}). The shortage / over and the cash moved to the safe now follow your count.`, tone: r.same ? 'success' : 'warn' }); }
        }} />}>
        <Banner tone="info" message="Count the cash in the drawer again yourself. The first count is not shown until you save, so the two counts are independent." />
        <Card><Denoms value={recount.denominations} onChange={(v) => setRecount((o) => ({ ...o, denominations: v }))} testIDPrefix="rc2-d" />
          <Text testID="rc2-total" style={{ fontSize: 22, fontWeight: '900', color: C.text, marginTop: 8 }}>Counted: {$(total)}</Text></Card>
        <Field testID="rc2-note" label="Note (optional)" value={recount.note} onChangeText={(v) => setRecount((o) => ({ ...o, note: v }))} multiline />
        <Btn title="Cancel" variant="secondary" size="md" onPress={() => setRecount(null)} />
      </Screen>
    );
  }
  const local = listPhotos('till', c.uid);
  const rules = T.tillRules();
  const isShort = c.over_short < -rules.tolerance - 0.004;
  const signed = T.isSigned(c);
  const eod = eodForCount(c.uid);
  const sh = shortageForCount(c.uid);
  const ownerLike = ['owner', 'admin'].includes(user.role);
  return (
    <Screen title={`${shopName(c.shop_code)} · ${c.till_name} · ${c.shift}`} subtitle={`${c.shift_date} · ${c.cashier_name}`}>
      <FixButton table="till_counts" keyVal={params.uid} />
      <Banner testID="tc-result" tone={Math.abs(c.over_short) < 0.005 ? 'success' : c.over_short > 0 ? 'warn' : 'danger'} title={OS(c.over_short)}
        message={`${c.status === 'approved' ? `Approved by ${c.approved_by_name}` : c.status === 'queried' ? `Queried: ${c.approve_note}` : c.status === 'void' ? `Void: ${c.void_reason}` : 'Waiting for approval'}${c.reason ? `\nReason: ${c.reason}` : ''}`} />
      {c.second_status === 'waiting' ? <Banner testID="tc-second-wait" tone="warn" title="Waiting for a second count" message="A supervisor counts the drawer again to confirm." /> : null}
      {c.second_status === 'confirmed' ? <Banner testID="tc-second-ok" tone="success" message={`Second count by ${c.second_by_name} agrees (${$(c.cash_counted)}).`} /> : null}
      {c.second_status === 'differs' ? (() => { const f = (() => { try { return JSON.parse(c.first_count || '{}'); } catch (e) { return {}; } })(); return <Banner testID="tc-second-diff" tone="warn" title="The second count was different" message={`Second count by ${c.second_by_name}: ${$(c.cash_counted)} (this one stands).\nFirst count by ${f.by_name || c.counted_by_name}: ${$(f.counted)} – difference ${c.second_diff > 0 ? '+' : '−'}${$(Math.abs(c.second_diff || 0))}.${c.second_note ? `\n${c.second_note}` : ''}`} />; })() : null}
      {canRecount ? <Btn testID="tc-recount" title={c.second_status === 'waiting' ? 'Do the second count now' : c.second_status ? 'Count it again' : 'Second count (count the drawer again)'} icon="🔁" size="md" variant={c.second_status === 'waiting' ? 'warn' : 'ghost'} onPress={() => setRecount({ denominations: {}, note: '' })} /> : null}
      {eod && eod.state !== 'matched' ? (
        <Banner testID="tc-eod" tone={eod.state === 'resolved' ? 'info' : 'danger'} title={`🔴 Aronium End of day ${eod.z_number || ''}: ${EOD_STATE[eod.state]}`}
          message={`Aronium ${$(eod.total)} · till ${$(eod.till_total)} · difference ${$(eod.diff)}${eod.explanation ? `\n${eod.explanation}` : ''}`} />
      ) : eod ? <Banner tone="success" message={`Agrees with Aronium End of day ${eod.z_number || ''} (${$(eod.total)}).`} /> : null}
      {eod ? <Btn title="Open the Aronium End of day" size="sm" variant="ghost" onPress={() => nav.push('AroniumEod', { uid: eod.uid })} /> : null}
      {c.status !== 'void' && !signed && rules.requireSignatures ? <Banner tone="warn" title="Not signed yet" message="The cashier and the person who balanced the till must both sign before it can be approved." /> : null}
      <Card>
        <Row label="Counted" value={$(c.cash_counted)} bold />
        <Row label="Should be" value={$(c.expected_cash)} />
        <Row label="Float at start / left" value={`${$(c.opening_float)} / ${$(c.float_kept)}`} />
        <Row label="Z report" value={`${c.z_number || '—'} · total ${c.z_total == null ? '—' : $(c.z_total)} · cash ${$(c.z_cash)}`} />
        {c.tenders.map((t) => <Row key={t.method} label={t.method} value={$(t.amount)} />)}
        {c.payouts.map((p, i) => <Row key={i} label={`Paid out: ${p.what}${p.note ? ` (${p.note})` : ''}`} value={$(p.amount)} />)}
        {c.drops ? <Row label="Drops to safe" value={$(c.drops)} /> : null}
        {c.adjustments.map((a, i) => <Row key={i} label={`Correction: ${a.reason}`} value={$(a.amount)} />)}
        <Row label="Counted by" value={`${c.counted_by_name} · ${String(c.counted_at).slice(0, 16)}`} />
        {c.balancer_name ? <Row label="Balanced by" value={c.balancer_name} /> : null}
        {c.notes ? <Row label="Remarks" value={c.notes} /> : null}
        {c.z_vat != null ? <Row label="VAT on Z / zero-rated" value={`${$(c.z_vat)} / ${$(c.z_zero_rated || 0)}`} /> : null}
        {c.z_refunds || c.z_voids ? <Row label="Refunds / voids" value={`${$(c.z_refunds || 0)} / ${$(c.z_voids || 0)}`} /> : null}
        {sh ? <Row label="Shortage" value={`${$(sh.amount)} · ${SHORT_STATUS[sh.status]}${sh.parts > 1 ? ` (${sh.parts} parts)` : ''}`} color={['waiting', 'disagreed'].includes(sh.status) ? C.danger : undefined} /> : null}
        {sh && sh.paid_now ? <Row label="Paid by the cashier in cash" value={`${$(sh.paid_now)} · ${String(sh.paid_now_at || '').slice(0, 16)} (taken by ${sh.paid_now_by || '—'})`} color={C.success} /> : null}
        {ov ? <Row label="Till over" value={`${$(ov.amount)} · ${RC.SURPLUS_STATUS[ov.status]}${ov.decision_note ? ` – ${ov.decision_note}` : ''}`} color={ov.status === 'open' ? C.warn : undefined} /> : null}
        {!sh && c.short_action === 'deduct' ? <Row label="Shortage" value="Taken from the cashier's pay" color={C.danger} /> : null}
        {c.short_action === 'write_off' ? <Row label="Shortage written off" value={c.short_note || ''} /> : null}
      </Card>
      {sh && ['waiting', 'disagreed'].includes(sh.status) ? <Btn testID="tc-shortage" title={sh.status === 'waiting' ? `${sh.name}: pay now, or agree and sign` : 'Manager: decide the shortage'} icon="✍️" variant="danger" onPress={() => nav.push('TillShortages', {})} /> : null}
      {ov && ov.status === 'open' && can('till_approve') ? <Btn testID="tc-over" title={`Till over ${$(ov.amount)} – decide what happens to it`} icon="⚖️" variant="warn" onPress={() => nav.push('TillShortages', {})} /> : null}
      <SignedBy c={c} />
      {c.status !== 'void' && c.status !== 'approved' && !signed ? (
        <SignBox count={c} cashierUid={c.cashier_uid} balancerUid={balancerUid || c.balancer_uid || user.uid} setBalancerUid={setBalancerUid} sigs={sigs} setSigs={setSigs} onSigned={() => setSigs({ cashier: null, balancer: null })} />
      ) : null}
      <Section title="Notes and coins">
        <Text style={{ fontSize: 16, color: C.text }}>{T.DENOMS.filter((d) => Number(c.denominations[d.key])).map((d) => `${d.label} × ${c.denominations[d.key]}`).join('   ') || 'Total typed in'}</Text>
      </Section>
      {c.zRead ? <Banner testID="tc-zread" tone={c.zRead.changed && c.zRead.changed.length ? 'warn' : 'info'} title="Z report figures read from the photo"
        message={`${(c.zRead.filled || []).length} box(es) filled from the photo${c.zRead.checked ? `, checked by ${c.counted_by_name}` : ''}.${(c.zRead.changed || []).length ? `\nChanged by the person: ${c.zRead.changed.map((x) => `${Z_LABELS[x.field] || String(x.field).replace('tender:', '')} ${x.read} → ${x.kept === '' ? '(empty)' : x.kept}`).join(', ')}` : '\nEverything kept as read.'}`} /> : null}
      {local.length || c.photos.length ? <Section title="Z report photo (tap to enlarge)"><PhotoStrip testID="tc-photos" photos={photosFor(local, c.photos, `Z report ${c.z_number || ''} · ${c.shift_date}`)} size={140} /></Section> : null}
      {c.status === 'counted' || c.status === 'queried' ? (
        <View style={{ gap: 10 }}>
          <Btn testID="tc-edit" title="Change the count" variant="secondary" onPress={() => nav.push('TillCount', { uid: c.uid })} />
          {can('till_approve') ? (
            <Card>
              {isShort ? (
                <View style={{ gap: 8, marginBottom: 10 }}>
                  <Text style={{ fontSize: 18, fontWeight: '800', color: C.danger }}>Short {$(-c.over_short)}</Text>
                  <Hint>The cashier agrees and signs (taken from pay, all at once or in parts) or disagrees and a manager decides – Till & cash › Till shortages.{ownerLike || rules.shortageRule === 'decide' ? ' You can also write it off here.' : ''}</Hint>
                  {(ownerLike || rules.shortageRule === 'decide') && sh && ['waiting', 'disagreed'].includes(sh.status) ? (
                    <Chips value={wo.on ? 'w' : 'a'} onChange={(v) => setWo({ ...wo, on: v === 'w' })} testIDPrefix="short" options={[{ value: 'a', label: 'Cashier to agree' }, { value: 'w', label: 'Write it off' }]} />
                  ) : null}
                  {wo.on ? <ReasonField label="Why it is written off (required)" value={wo.reason} onChangeText={(v) => setWo({ ...wo, reason: v })} /> : null}
                </View>
              ) : c.over_short > 0.004 ? <Text style={{ fontSize: 16, color: C.warn, marginBottom: 8 }}>Surplus {$(c.over_short)}: it stays in the shop's cash and is recorded in the shortages & surpluses report.</Text> : null}
              <Field testID="tc-note" label="Note (required to query)" value={note} onChangeText={setNote} />
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
                <Btn testID="tc-approve" title="Approve" variant="success" style={{ flexGrow: 1 }} onPress={() => act(() => T.approveTillCount(user, c.uid, { note, shortAction: isShort && wo.on ? 'write_off' : undefined, writeOffReason: wo.reason }), 'Approved')} />
                <Btn title="Query" variant="warn" style={{ flexGrow: 1 }} onPress={() => act(() => T.approveTillCount(user, c.uid, { query: true, note }), 'Queried')} />
                <Btn title="Void" variant="ghost" onPress={() => act(() => T.voidTillCount(user, c.uid, note), 'Voided')} />
              </View>
            </Card>
          ) : null}
        </View>
      ) : null}
      {c.status === 'approved' && can('till_approve') ? (
        <Card>
          <ReasonField label="Reason to re-open" value={note} onChangeText={setNote} />
          <Btn title="Re-open" variant="warn" style={{ marginTop: 10 }} onPress={() => act(() => T.reopenTillCount(user, c.uid, note), 'Re-opened')} />
        </Card>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- deposits
export function DepositScreen({ params = {} }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const accounts = listAccounts();
  const richest = () => shops().map((s) => ({ code: s.code, cash: T.cashOnHand(s.code).onHand })).sort((a, b) => b.cash - a.cash)[0];
  const [d, setD] = useState({ shopCode: user.shop_code || (richest() && richest().code) || '', accountUid: accounts[0] ? accounts[0].uid : '', date: dateStr(), slipNo: '', branch: '', byNotes: true, denominations: {}, cashAmount: '', cheques: [], takingsFrom: dateStr(), takingsTo: dateStr(), witness: '', notes: '' });
  const [photos, setPhotos] = useState([]);
  const dp = usePaper('deposit');
  const [covers, setCovers] = useState(() => (params.covers || []).map((x) => ({ ...x, amount: String(x.amount) })));
  const set = (k) => (v) => setD((o) => ({ ...o, [k]: v }));
  const cash = d.byNotes ? T.countDenoms(d.denominations) : r2(d.cashAmount);
  const chq = r2(d.cheques.reduce((s, c) => s + r2(c.amount), 0));
  const onHand = d.shopCode ? T.cashOnHand(d.shopCode).onHand : 0;
  const DEP_MAP = { slipNo: 'slipNo', branch: 'branch', date: 'date', cash: 'cashAmount' };
  const slip = dp.read ? dp.read.fields : {};
  const slipTotal = slip.total !== undefined ? slip.total : (slip.cash !== undefined ? r2((slip.cash || 0) + (slip.cheques || 0)) : null);
  const save = () => {
    if (!dp.okToSave(ui)) return;
    try {
      const r = T.saveDeposit(user, { ...d, denominations: d.byNotes ? d.denominations : {}, cashAmount: cash, covers }, { photos });
      dp.log(user, 'deposits', r.uid, d, DEP_MAP);
      ui.toast(`Deposit ${$(r.total)} saved`);
      nav.pop();
      offerPdf(ui, () => depositDoc(r.uid));
    } catch (e) { ui.error(e); }
  };
  return (
    <Screen title="Bank deposit" subtitle={`Cash at ${shopName(d.shopCode)}: ${$(onHand)}`} footer={<Btn testID="dep-save" title={`Save deposit ${$(cash + chq)}`} icon="🏦" variant="success" onPress={save} />}>
      {!accounts.length ? <Banner tone="warn" message="Add the bank account first: Invoices & cheques › Cheques & bank › Accounts." /> : null}
      <Card>
        <PaperPhoto pr={dp} testID="dep-photo" label="Photo of the stamped deposit slip" value={photos} onChange={setPhotos} form={d} setForm={setD}
          map={d.byNotes ? { slipNo: 'slipNo', branch: 'branch', date: 'date' } : DEP_MAP} soft={{ date: dateStr() }}
          hint="Have the stamped slip? Take its photo first – the slip number, date and branch fill in, and the amount is checked against your count.">
          {slipTotal !== null && Math.abs(slipTotal - r2(cash + chq)) > 0.004 && (cash + chq) > 0 ? <Banner testID="dep-slipdiff" tone="warn" message={`The slip shows ${$(slipTotal)} but this deposit adds up to ${$(cash + chq)}. Check the count and the slip.`} /> : null}
          {slipTotal !== null && Math.abs(slipTotal - r2(cash + chq)) <= 0.004 ? <Banner testID="dep-slipok" tone="success" message={`The slip agrees: ${$(slipTotal)}.`} /> : null}
        </PaperPhoto>
      </Card>
      <Card>
        <Label>Cash from</Label>
        <Chips value={d.shopCode} onChange={set('shopCode')} testIDPrefix="dep-shop" options={shopChips()} />
        <Select label="Into account" value={d.accountUid} onChange={set('accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} />
        <DateField label="Date banked" value={d.date} onChange={set('date')} />
        <Field testID="dep-slip" label="Deposit slip number" value={d.slipNo} onChangeText={set('slipNo')} />
        <Field label="Branch / ATM" value={d.branch} onChangeText={set('branch')} placeholder="e.g. BSP Lautoka" />
        <DateField label="Takings from" value={d.takingsFrom} onChange={set('takingsFrom')} />
        <DateField label="Takings to" value={d.takingsTo} onChange={set('takingsTo')} />
      </Card>
      <Card>
        <H>Cash</H>
        <Chips value={d.byNotes} onChange={set('byNotes')} options={[{ value: true, label: 'Count notes & coins' }, { value: false, label: 'Type the total' }]} />
        {d.byNotes ? <Denoms value={d.denominations} onChange={set('denominations')} testIDPrefix="dep-d" /> : <MoneyField testID="dep-cash" label="Cash total" value={d.cashAmount} onChange={set('cashAmount')} />}
        <Text style={{ fontSize: 20, fontWeight: '900', color: C.text }}>Cash {$(cash)}</Text>
      </Card>
      <Card>
        <H>Cheques in this deposit</H>
        <Lines items={d.cheques} onChange={set('cheques')} testIDPrefix="dep-chq" addLabel="+ Cheque"
          fields={[{ key: 'drawer', label: 'From (customer)', grow: 2 }, { key: 'bank', label: 'Bank' }, { key: 'number', label: 'Cheque no' }, { key: 'amount', label: 'Amount', money: true }]} />
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Cheques {$(chq)}</Text>
      </Card>
      <Card>
        <DepositCoverPicker accountUid={d.accountUid} value={covers} onChange={setCovers} depositTotal={r2(cash + chq)} />
      </Card>
      <Card>
        <Field label="Witness / second person (optional)" value={d.witness} onChangeText={set('witness')} />
        <Field label="Notes" value={d.notes} onChangeText={set('notes')} multiline />
        <Text style={{ fontSize: 15, color: C.sub }}>Banked by {user.name}</Text>
      </Card>
    </Screen>
  );
}
export function DepositListScreen() {
  const { user, can } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(null);
  const [reason, setReason] = useState('');
  const rows = T.listDeposits({ includeVoid: true });
  return (
    <Screen title="Deposits" subtitle={`${rows.length}`}>
      {rows.map((d) => (
        <View key={d.uid} style={{ gap: 6 }}>
          <ListItem testID={`dep-${d.slip_no}`} onPress={() => setOpen(open === d.uid ? null : d.uid)} title={`${shopName(d.shop_code)} · slip ${d.slip_no}`}
            sub={`${d.deposit_date} · ${d.deposited_by_name}${d.account_name ? ` · ${d.account_name}` : ''}${d.cleared_date ? ` · on statement ${d.cleared_date}` : ' · not on a statement yet'}`}
            right={$(d.total)} rightSub={d.cheque_amount ? `cash ${$(d.cash_amount)} + chq ${$(d.cheque_amount)}` : null} badge={d.status === 'void' ? 'VOID' : null} badgeColor={C.sub} />
          {open === d.uid && d.status === 'active' && can('deposits') ? (
            <Card>
              {T.getDeposit(d.uid).cheques.map((c, i) => <Row key={i} label={`Cheque ${c.number} ${c.drawer} (${c.bank})`} value={$(c.amount)} />)}
              {d.takings_from ? <Row label="Takings" value={`${d.takings_from} to ${d.takings_to || d.takings_from}`} /> : null}
              {d.witness ? <Row label="Witness" value={d.witness} /> : null}
              <PhotoStrip photos={photosFor(listPhotos('deposit', d.uid), T.getDeposit(d.uid).photos, `Deposit slip ${d.slip_no}`)} size={110} />
              {(() => { let cv = []; try { cv = require('../../payables/cover.js').depositCovers(d.uid); } catch (e) { cv = []; } return cv.length ? <Banner testID={`dep-covers-${d.slip_no}`} tone="info" title="This deposit covered" message={cv.map((x) => `• ${x.label}: ${$(x.amount)}`).join('\n')} /> : null; })()}
              {d.notes ? <Row label="Notes" value={d.notes} /> : null}
              <ReasonField label="Reason to void" value={reason} onChangeText={setReason} />
              <Btn title="Void deposit" variant="danger" size="sm" style={{ marginTop: 8 }} onPress={() => { if (act(() => T.voidDeposit(user, d.uid, reason), 'Voided')) setOpen(null); }} />
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- cash on hand
function SafeCount({ shop }) {
  const { user, can } = useApp();
  const act = useAct();
  const [open, setOpen] = useState(false);
  const [den, setDen] = useState({});
  const [note, setNote] = useState('');
  const [witness, setWitness] = useState('');
  const list = T.listSafeCounts({ shopCode: shop, limit: 10 });
  const counted = T.countDenoms(den);
  const expected = T.cashOnHand(shop).onHand;
  return (
    <Section title="Safe counts">
      <Hint>Count the cash in the safe / office now and then (also by surprise). The app compares it with what should be there; any difference is recorded and the owner decides.</Hint>
      {open ? (
        <Card>
          <Denoms value={den} onChange={setDen} testIDPrefix="sf-d" />
          <Row label="Counted" value={$(counted)} bold />
          <Row label="Should be" value={$(expected)} />
          <Row label="Difference" value={$(counted - expected)} color={osColor(counted - expected)} bold />
          <Field testID="sf-note" label="Note (needed if there is a difference)" value={note} onChangeText={setNote} />
          <Field label="Witness (who watched the count)" value={witness} onChangeText={setWitness} />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setOpen(false)} />
            <Btn testID="sf-save" title="Save safe count" size="md" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => T.saveSafeCount(user, { shopCode: shop, denominations: den, note, witness }), 'Safe count saved')) { setOpen(false); setDen({}); setNote(''); setWitness(''); } }} />
          </View>
        </Card>
      ) : <Btn testID="sf-open" title="Count the safe" icon="🔐" size="md" variant="secondary" onPress={() => setOpen(true)} />}
      {list.map((x) => (
        <View key={x.uid} style={{ gap: 6 }}>
          <ListItem title={`${x.count_date} · ${x.by_name}${x.witness ? ` (witness ${x.witness})` : ''}`} sub={`counted ${$(x.counted)}, should be ${$(x.expected)}${x.note ? ` · ${x.note}` : ''}${x.adjust_uid ? ' · difference booked' : ''}`}
            right={OS(x.diff)} badge={Math.abs(x.diff) < 0.005 ? null : OS(x.diff)} badgeColor={osColor(x.diff)} />
          {Math.abs(x.diff) > 0.004 && !x.adjust_uid && can('till_approve') ? <ReasonButton title="Accept and book the difference" prompt="Why is it accepted?" confirm="Book it" variant="warn" onDo={(w) => act(() => T.bookSafeDifference(user, x.uid, w), 'Booked')} /> : null}
        </View>
      ))}
    </Section>
  );
}

export function CashOnHandScreen({ params }) {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [shop, setShop] = useState(params.shopCode || user.shop_code || (shops()[0] && shops()[0].code) || '');
  const [f, setF] = useState(null);
  const pp = usePaper('invoice');
  const rules = T.tillRules();
  const c = T.cashOnHand(shop);
  const moves = T.listCashMoves({ shopCode: shop, limit: 100 });
  return (
    <Screen title="Cash on hand" subtitle={`${shopName(shop)}: ${$(c.onHand)} + floats ${$(c.floats)}`}>
      <Chips value={shop} onChange={setShop} testIDPrefix="coh-shop" options={shopChips()} />
      <Card>
        <Row label="Cash in the safe / office" value={$(c.onHand)} bold />
        <Row label="Floats in the tills" value={$(c.floats)} />
        <Row label="Total cash at the shop" value={$(c.total)} bold />
        <Row label="Paid to suppliers in cash (all time)" value={$(c.supplierCash)} />
      </Card>
      {f ? (
        <Card>
          <Chips value={f.type} onChange={(v) => setF({ ...f, type: v })} testIDPrefix="coh-type"
            options={[{ value: 'petty_out', label: 'Petty cash spent' }, { value: 'petty_in', label: 'Top-up' }, { value: 'transfer', label: 'To another shop' }, { value: 'opening', label: 'Starting cash' }, { value: 'adjust_in', label: 'Correction +' }, { value: 'adjust_out', label: 'Correction −' }]} />
          {f.type === 'transfer' ? <><Label>To</Label><Chips value={f.toShop} onChange={(v) => setF({ ...f, toShop: v })} options={shopChips().filter((o) => o.value !== shop)} /></> : null}
          {f.type === 'petty_out' ? <Select label="Category" value={f.category} onChange={(v) => setF({ ...f, category: v })} options={rules.pettyCategories.map((x) => ({ value: x, label: x }))} /> : null}
          {f.type === 'petty_out' ? <PaperPhoto pr={pp} testID="coh-photo" label="Receipt" value={f.photos} onChange={(v) => setF((o) => ({ ...o, photos: v }))} form={f} setForm={setF}
            apply={(form, x, prev) => receiptApply(form, x, prev, { amount: 'amount', date: 'date', note: 'note' })} hint="Take the receipt photo first – the amount, date and shop fill in." /> : null}
          <MoneyField testID="coh-amount" label="Amount" value={f.amount} onChange={(v) => setF({ ...f, amount: v })} />
          <DateField label="Date" value={f.date} onChange={(v) => setF({ ...f, date: v })} />
          <Field testID="coh-note" label={f.type === 'petty_out' ? 'What was bought' : 'Note / reason'} value={f.note} onChangeText={(v) => setF({ ...f, note: v })} />
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setF(null)} />
            <Btn testID="coh-save" title="Save" variant="success" style={{ flex: 1 }} onPress={() => { if (f.type === 'petty_out' && !pp.okToSave(ui)) return; if (act(() => T.recordCash(user, { ...f, shopCode: shop }), 'Saved')) { if (f.type === 'petty_out') pp.log(user, 'cash_moves', null, f, { total: 'amount', date: 'date' }); pp.reset(); setF(null); } }} />
          </View>
        </Card>
      ) : <Btn testID="coh-add" title="Petty cash / move cash" icon="➕" variant="secondary" onPress={() => setF({ type: 'petty_out', amount: '', date: dateStr(), note: '', category: rules.pettyCategories[0], toShop: '', photos: [] })} />}
      <SafeCount shop={shop} />
      <Section title="Movements">
        {moves.map((m) => (
          <ListItem key={m.uid} title={`${T.MOVE_LABEL[m.type]}${m.category ? ` · ${m.category}` : ''}`} sub={`${m.move_date} · ${m.by_name || ''}${m.note ? ` · ${m.note}` : ''}`}
            right={`${['opening', 'from_till', 'petty_in', 'transfer_in', 'adjust_in'].includes(m.type) ? '+' : '−'}${$(m.amount)}`}
            onPress={['from_till', 'deposit'].includes(m.type) ? null : async () => {
              const ok = await ui.confirm({ title: 'Void this?', message: `${T.MOVE_LABEL[m.type]} ${$(m.amount)} on ${m.move_date}`, confirmText: 'Void', tone: 'danger' });
              if (ok) act(() => T.voidCashMove(user, m.uid, 'Voided on Cash on hand'), 'Voided');
            }} />
        ))}
      </Section>
    </Screen>
  );
}

// ---------------------------------------------------------------- setup
export function TillSetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = T.tillRules();
  const [f, setF] = useState({ ...r0, tolerance: String(r0.tolerance), shifts: r0.shifts.join('\n'), tenders: r0.tenders.join('\n'), payoutTypes: r0.payoutTypes.join('\n'), pettyCategories: r0.pettyCategories.join('\n') });
  const [t, setT] = useState(null);
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const yn = (k) => <Chips value={f[k]} onChange={set(k)} options={[{ value: true, label: 'Yes' }, { value: false, label: 'No' }]} />;
  return (
    <Screen title="Tills & rules" footer={<Btn testID="till-rules-save" title="Save rules" icon="💾" variant="success" onPress={() => act(() => T.saveTillRules(user, f), 'Saved')} />}>
      <Section title="Tills">
        {T.listTills({ includeInactive: true }).map((x) => <ListItem key={x.uid} title={`${shopName(x.shop_code)} · ${x.name}`} sub={`Float ${$(x.float_amount)}${x.active ? '' : ' · not used'}`} right="Change"
          onPress={() => setT({ uid: x.uid, shopCode: x.shop_code, name: x.name, floatAmount: String(x.float_amount), active: !!x.active })} />)}
        {t ? (
          <Card>
            <Chips value={t.shopCode} onChange={(v) => setT({ ...t, shopCode: v })} testIDPrefix="till-shop" options={shopChips()} />
            <Field testID="till-name" label="Till name" value={t.name} onChangeText={(v) => setT({ ...t, name: v })} />
            <MoneyField testID="till-float" label="Standard float" value={t.floatAmount} onChange={(v) => setT({ ...t, floatAmount: v })} />
            <Chips value={t.active} onChange={(v) => setT({ ...t, active: v })} options={[{ value: true, label: 'In use' }, { value: false, label: 'Not used' }]} />
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setT(null)} />
              <Btn testID="till-save" title="Save till" variant="success" style={{ flex: 1 }} onPress={() => { if (act(() => T.saveTill(user, t), 'Saved')) setT(null); }} />
            </View>
          </Card>
        ) : <Btn testID="till-add" title="Add a till" icon="➕" variant="secondary" onPress={() => setT({ shopCode: shops()[0] ? shops()[0].code : '', name: 'Till 1', floatAmount: '200', active: true })} />}
      </Section>
      <Card>
        <Field label="Difference allowed without a reason ($)" value={f.tolerance} onChangeText={set('tolerance')} keyboardType="decimal-pad" />
        <Label>Photo of the Z report required</Label>{yn('requireZPhoto')}
        <Label>Second count by a supervisor</Label>
        <Chips value={f.secondCount || 'off'} onChange={set('secondCount')} testIDPrefix="tr-second" options={[{ value: 'off', label: 'When they choose to' }, { value: 'when_off', label: 'Ask for it when short or over' }, { value: 'always', label: 'Every till' }]} />
        <Label>Blind count (cashier does not see the expected cash first)</Label>{yn('blindCount')}
        <Label>A manager must approve each count</Label>{yn('managerApproves')}
        <Label>Cashier and balancer both sign each till balance</Label>{yn('requireSignatures')}
        <Field testID="till-eod-tol" label="Aronium End of day may differ from the till by up to ($)" value={f.eodTolerance === undefined ? '0.05' : String(f.eodTolerance)} onChangeText={set('eodTolerance')} keyboardType="decimal-pad" />
        <Label>Shortages over the allowed difference</Label>
        <Chips value={f.shortageRule} onChange={set('shortageRule')} options={[{ value: 'deduct', label: 'Cashier agrees – taken from pay (only the owner can write off)' }, { value: 'decide', label: 'The manager may also write it off' }]} />
        <Field label="Shortage taken from pay: at most this much a week (0 = all at once)" value={String(f.shortagePerWeek ?? 0)} onChangeText={set('shortagePerWeek')} keyboardType="decimal-pad" />
      </Card>
      <Card>
        <Field label="Shift names (one per line)" value={f.shifts} onChangeText={set('shifts')} multiline />
        <Field label="Payment types on the Z report (one per line)" value={f.tenders} onChangeText={set('tenders')} multiline />
        <Field label="Cash paid out types (one per line)" value={f.payoutTypes} onChangeText={set('payoutTypes')} multiline />
        <Field label="Petty cash categories (one per line)" value={f.pettyCategories} onChangeText={set('pettyCategories')} multiline />
      </Card>
    </Screen>
  );
}
