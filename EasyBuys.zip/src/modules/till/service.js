// Till & cash. At the end of a shift the cashier counts the till note by note, types in the Z report totals,
// takes a photo of the Z report, and explains any difference. A manager approves it.
// The cash taken from the till goes into the shop's cash on hand; deposits and petty cash take it out.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared, money } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });

// Fiji notes and coins.
export const DENOMS = [
  { key: 'n100', label: '$100', value: 100 }, { key: 'n50', label: '$50', value: 50 }, { key: 'n20', label: '$20', value: 20 }, { key: 'n10', label: '$10', value: 10 },
  { key: 'n5', label: '$5', value: 5 }, { key: 'c2', label: '$2', value: 2 }, { key: 'c1', label: '$1', value: 1 }, { key: 'c50', label: '50c', value: 0.5 },
  { key: 'c20', label: '20c', value: 0.2 }, { key: 'c10', label: '10c', value: 0.1 }, { key: 'c5', label: '5c', value: 0.05 },
];
export function countDenoms(d) {
  return r2(DENOMS.reduce((s, x) => s + (Math.max(0, Math.round(Number((d || {})[x.key]) || 0)) * x.value), 0));
}

// ---------------------------------------------------------------- rules (admin)
export const TILL_DEFAULTS = {
  shifts: ['Morning', 'Afternoon', 'Night', 'Full day'],
  tenders: ['EFTPOS / card', 'M-PAiSA', 'MyCash', 'Cheques received', 'On account (credit sales)', 'Vouchers'],
  payoutTypes: ['Supplier paid from till', 'Refund', 'Staff advance', 'Petty cash', 'Other'],
  tolerance: 2,              // differences up to this much need no reason
  requireZPhoto: true,       // a photo of the Z report must be taken
  blindCount: false,         // the cashier does not see the expected cash until the count is saved
  managerApproves: true,     // a manager must approve every count
  pettyCategories: ['Cleaning', 'Office', 'Transport', 'Food & tea', 'Repairs', 'Other'],
};
export function tillRules() {
  return { ...TILL_DEFAULTS, ...(getShared('till_rules', {}) || {}) };
}
export function saveTillRules(user, r) {
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const tol = Number(r.tolerance);
  need(Number.isFinite(tol) && tol >= 0 && tol <= 1000, 'Tolerance must be between 0 and 1000.');
  const clean = { shifts: list(r.shifts), tenders: list(r.tenders), payoutTypes: list(r.payoutTypes), pettyCategories: list(r.pettyCategories), tolerance: r2(tol),
    requireZPhoto: !!r.requireZPhoto, blindCount: !!r.blindCount, managerApproves: !!r.managerApproves };
  need(clean.shifts.length, 'Add at least one shift name.');
  const before = tillRules();
  setShared('till_rules', clean);
  audit({ user, action: 'Changed till rules', table: 'shared_settings', recordUid: 'till_rules', before, after: clean });
  return clean;
}

// ---------------------------------------------------------------- tills (admin)
export function listTills({ shopCode, includeInactive = false } = {}) {
  return db().all(`SELECT * FROM tills WHERE (? IS NULL OR shop_code = ?) AND (? = 1 OR active = 1) ORDER BY shop_code, sort, name`, [shopCode || null, shopCode || null, includeInactive ? 1 : 0]);
}
export function saveTill(user, t) {
  need(txt(t.shopCode), 'Choose the shop.');
  need(txt(t.name), 'Name the till, e.g. "Till 1".');
  const f = r2(t.floatAmount);
  need(f >= 0 && f <= 10000, 'The float must be between 0 and 10,000.');
  const uid = t.uid || uuid('TL');
  const { now, dev } = meta();
  db().run(`INSERT INTO tills (uid, shop_code, name, float_amount, active, sort, updated_at, updated_device) VALUES (?,?,?,?,?,COALESCE((SELECT MAX(sort)+1 FROM tills),0),?,?)
    ON CONFLICT(uid) DO UPDATE SET shop_code=excluded.shop_code, name=excluded.name, float_amount=excluded.float_amount, active=excluded.active, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, t.shopCode, txt(t.name), f, t.active === false ? 0 : 1, now, dev]);
  audit({ user, action: `Till ${txt(t.name)} (${t.shopCode}) float ${$(f)}`, table: 'tills', recordUid: uid });
  return uid;
}

// The float the till started with: the float left at its last count, else its standard float.
export function openingFloat(tillUid) {
  const last = db().get("SELECT float_kept FROM till_counts WHERE till_uid = ? AND status <> 'void' ORDER BY shift_date DESC, counted_at DESC LIMIT 1", [tillUid]);
  if (last) return r2(last.float_kept);
  const t = db().get('SELECT float_amount FROM tills WHERE uid = ?', [tillUid]);
  return t ? r2(t.float_amount) : 0;
}

// expected cash in the drawer = float at start + cash sales on the Z report − cash paid out − cash dropped to the safe ± corrections
export function workOut(c) {
  const payouts = r2((c.payouts || []).reduce((s, p) => s + r2(p.amount), 0));
  const adjust = r2((c.adjustments || []).reduce((s, a) => s + r2(a.amount), 0));
  const byNotes = c.denominations ? countDenoms(c.denominations) : 0;
  const counted = byNotes > 0 ? byNotes : r2(c.cashCounted);
  const expected = r2(r2(c.openingFloat) + r2(c.zCash) - payouts - r2(c.drops) + adjust);
  const overShort = r2(counted - expected);
  const toSafe = r2(counted - r2(c.floatKept) + r2(c.drops));
  const tenders = r2((c.tenders || []).reduce((s, t) => s + r2(t.amount), 0));
  const zCheck = c.zTotal === '' || c.zTotal === null || c.zTotal === undefined ? null : r2(r2(c.zTotal) - r2(c.zCash) - tenders);
  return { counted, payouts, adjust, expected, overShort, toSafe, tenders, zCheck };
}

export function saveTillCount(user, c, { photos = [] } = {}) {
  const rules = tillRules();
  need(txt(c.shopCode), 'Choose the shop.');
  const till = c.tillUid ? db().get('SELECT * FROM tills WHERE uid = ?', [c.tillUid]) : null;
  need(till || !listTills({ shopCode: c.shopCode }).length, 'Choose the till.');
  const date = txt(c.shiftDate) || dateStr();
  need(DATE.test(date) && date <= dateStr(), 'Enter the shift date (not in the future).');
  need(txt(c.shift), 'Choose the shift.');
  const w = workOut(c);
  need(w.counted >= 0, 'Count the cash.');
  need(c.zCash !== '' && c.zCash !== undefined && c.zCash !== null && r2(c.zCash) >= 0, 'Enter the CASH sales from the Z report.');
  need(r2(c.floatKept) >= 0 && r2(c.floatKept) <= w.counted, 'The float left in the till cannot be more than the cash counted.');
  need(r2(c.drops) >= 0, 'Drops to the safe cannot be below zero.');
  for (const p of c.payouts || []) need(r2(p.amount) > 0 && txt(p.what), 'Each cash paid out needs what it was for and the amount.');
  for (const a of c.adjustments || []) need(r2(a.amount) !== 0 && txt(a.reason), 'Each correction needs an amount and a reason.');
  need(Math.abs(w.overShort) <= rules.tolerance || txt(c.reason), `The till is ${w.overShort > 0 ? 'over' : 'short'} by ${$(Math.abs(w.overShort))}. Write the reason.`);
  const before = c.uid ? db().get('SELECT * FROM till_counts WHERE uid = ?', [c.uid]) : null;
  need(!before || before.status !== 'approved', 'This count is approved. A manager must re-open it first.');
  const hasPhoto = photos.length > 0 || (before && (J(before.photo_urls, []).length || db().get("SELECT 1 AS x FROM photos WHERE ref_type = 'till' AND ref_id = ?", [before.uid])));
  need(!rules.requireZPhoto || hasPhoto, 'Take a photo of the Z report.');
  const dupe = db().get("SELECT counted_by_name FROM till_counts WHERE till_uid IS ? AND shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void' AND uid <> ?",
    [c.tillUid || null, c.shopCode, date, c.shift, c.uid || '']);
  need(!dupe, `This till and shift was already counted by ${dupe && dupe.counted_by_name}. Open that count instead.`);
  const { now, dev } = meta();
  const uid = c.uid || uuid('TC');
  const cashier = c.cashierUid ? db().get('SELECT uid, name FROM users WHERE uid = ?', [c.cashierUid]) : null;
  const vals = {
    shop_code: c.shopCode, till_uid: till ? till.uid : null, till_name: till ? till.name : 'Till', shift_date: date, shift: c.shift,
    cashier_uid: cashier ? cashier.uid : user.uid, cashier_name: cashier ? cashier.name : user.name, counted_by_uid: user.uid, counted_by_name: user.name, counted_at: now,
    opening_float: r2(c.openingFloat), denominations: JSON.stringify(c.denominations || {}), cash_counted: w.counted, float_kept: r2(c.floatKept),
    z_number: txt(c.zNumber) || null, z_total: c.zTotal === '' || c.zTotal === undefined ? null : r2(c.zTotal), z_cash: r2(c.zCash),
    tenders: JSON.stringify((c.tenders || []).filter((t) => r2(t.amount)).map((t) => ({ method: t.method, amount: r2(t.amount) }))),
    payouts: JSON.stringify((c.payouts || []).map((p) => ({ what: txt(p.what), amount: r2(p.amount), note: txt(p.note) }))), drops: r2(c.drops),
    adjustments: JSON.stringify((c.adjustments || []).map((a) => ({ amount: r2(a.amount), reason: txt(a.reason) }))),
    expected_cash: w.expected, over_short: w.overShort, reason: txt(c.reason) || null, notes: txt(c.notes) || null,
    status: rules.managerApproves ? 'counted' : 'approved', updated_at: now, updated_device: dev,
  };
  db().transaction(() => {
    if (before) {
      const cols = Object.keys(vals);
      db().run(`UPDATE till_counts SET ${cols.map((k) => `${k} = ?`).join(', ')}, sync_status = 'pending' WHERE uid = ?`, cols.map((k) => vals[k]).concat([uid]));
    } else {
      Object.assign(vals, { uid, photo_urls: '[]' });
      const cols = Object.keys(vals);
      db().run(`INSERT INTO till_counts (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, cols.map((k) => vals[k]));
    }
    // The cash that leaves the till goes to the shop's cash on hand (one movement per count, replaced if the count changes).
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = 'Count changed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND type = 'from_till' AND status = 'active'`, [now, dev, uid]);
    if (w.toSafe > 0) addMove({ shopCode: c.shopCode, date, type: 'from_till', amount: w.toSafe, refUid: uid, note: `${vals.till_name} ${c.shift} ${date}`, user });
  });
  if (photos.length) addPhotos('till', uid, photos);
  audit({ user, action: `Till count ${vals.till_name} ${c.shopCode} ${date} ${c.shift}: ${w.overShort ? `${w.overShort > 0 ? 'over' : 'short'} ${$(Math.abs(w.overShort))}` : 'balanced'}`,
    table: 'till_counts', recordUid: uid, before: before && { counted: before.cash_counted, overShort: before.over_short }, after: { counted: w.counted, expected: w.expected, overShort: w.overShort }, reason: c.reason });
  return getTillCount(uid);
}

export function getTillCount(uid) {
  const r = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
  if (!r) return null;
  return { ...r, denominations: J(r.denominations, {}), tenders: J(r.tenders, []), payouts: J(r.payouts, []), adjustments: J(r.adjustments, []), photos: J(r.photo_urls, []) };
}
export function listTillCounts({ shopCode, from, to, status, limit = 300 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); } else w.push("status <> 'void'");
  return db().all(`SELECT * FROM till_counts WHERE ${w.join(' AND ')} ORDER BY shift_date DESC, counted_at DESC LIMIT ?`, a.concat([limit]));
}

export function approveTillCount(user, uid, { query = false, note = '' } = {}) {
  const c = getTillCount(uid);
  need(c, 'Count not found.');
  need(c.status === 'counted' || c.status === 'queried', c.status === 'approved' ? 'Already approved.' : 'This count is void.');
  need(!query || txt(note), 'Write what needs to be checked.');
  need(query || c.counted_by_uid !== user.uid || ['owner', 'admin'].includes(user.role), 'Someone else must approve your own count.');
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET status = ?, approved_by_name = ?, approved_at = ?, approve_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [query ? 'queried' : 'approved', user.name, now, txt(note) || null, now, dev, uid]);
  audit({ user, action: `${query ? 'Queried' : 'Approved'} till count ${c.till_name} ${c.shop_code} ${c.shift_date}`, table: 'till_counts', recordUid: uid, reason: note });
}
export function reopenTillCount(user, uid, reason) {
  need(txt(reason), 'Give a reason.');
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET status = 'counted', approve_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'approved'`, [`Re-opened: ${txt(reason)}`, now, dev, uid]);
  audit({ user, action: 'Re-opened till count', table: 'till_counts', recordUid: uid, reason });
}
export function voidTillCount(user, uid, reason) {
  need(txt(reason), 'Give a reason.');
  const c = getTillCount(uid);
  need(c && c.status !== 'void', 'Count not found.');
  need(c.status !== 'approved', 'Re-open it first.');
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`UPDATE till_counts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND status = 'active'`, [txt(reason), now, dev, uid]);
  });
  audit({ user, action: `Voided till count ${c.till_name} ${c.shift_date}`, table: 'till_counts', recordUid: uid, reason });
}

// ---------------------------------------------------------------- cash on hand
export const MOVE_LABEL = { opening: 'Starting cash', from_till: 'From till', deposit: 'Banked', petty_out: 'Petty cash spent', petty_in: 'Petty cash top-up', transfer_in: 'From another shop', transfer_out: 'To another shop', adjust_in: 'Correction (+)', adjust_out: 'Correction (−)' };
const IN = ['opening', 'from_till', 'petty_in', 'transfer_in', 'adjust_in'];
function addMove({ shopCode, date, type, amount, refUid, category, note, user, photos }) {
  const { now, dev } = meta();
  const uid = uuid('CM');
  db().run(`INSERT INTO cash_moves (uid, shop_code, move_date, type, amount, ref_uid, category, note, photo_urls, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,'[]',?,?,?,?)`,
    [uid, shopCode, date, type, r2(amount), refUid || null, category || null, note || null, user ? user.name : null, user ? user.uid : null, now, dev]);
  if (photos && photos.length) addPhotos('cash', uid, photos);
  return uid;
}

// Petty cash, top-ups, moving cash between shops, starting cash and corrections.
export function recordCash(user, m) {
  need(txt(m.shopCode), 'Choose the shop.');
  need(['opening', 'petty_out', 'petty_in', 'transfer', 'adjust_in', 'adjust_out'].includes(m.type), 'Choose what happened.');
  const amt = r2(m.amount);
  need(amt > 0, 'Enter the amount.');
  const date = txt(m.date) || dateStr();
  need(DATE.test(date), 'Enter the date as YYYY-MM-DD.');
  if (m.type === 'petty_out') need(txt(m.category) && txt(m.note), 'Say what the petty cash was spent on.');
  if (m.type.startsWith('adjust')) need(txt(m.note), 'A correction needs a reason.');
  if (m.type === 'transfer') {
    need(txt(m.toShop) && m.toShop !== m.shopCode, 'Choose the shop the cash went to.');
    const ref = uuid('TR');
    addMove({ shopCode: m.shopCode, date, type: 'transfer_out', amount: amt, refUid: ref, note: `To ${m.toShop}${m.note ? ` – ${txt(m.note)}` : ''}`, user });
    addMove({ shopCode: m.toShop, date, type: 'transfer_in', amount: amt, refUid: ref, note: `From ${m.shopCode}${m.note ? ` – ${txt(m.note)}` : ''}`, user });
  } else {
    if (m.type === 'petty_out') need(cashOnHand(m.shopCode, date).onHand >= amt - 0.004, 'There is not that much cash recorded at this shop.');
    addMove({ shopCode: m.shopCode, date, type: m.type, amount: amt, category: txt(m.category) || null, note: txt(m.note) || null, user, photos: m.photos });
  }
  audit({ user, action: `${MOVE_LABEL[m.type] || 'Cash moved'} ${$(amt)} ${m.shopCode}${m.toShop ? ` → ${m.toShop}` : ''}`, table: 'cash_moves', reason: m.note });
}
export function voidCashMove(user, uid, reason) {
  need(txt(reason), 'Give a reason.');
  const m = db().get('SELECT * FROM cash_moves WHERE uid = ?', [uid]);
  need(m && m.status === 'active', 'Not found.');
  need(!['from_till', 'deposit'].includes(m.type), 'Change the till count or the deposit instead.');
  const { now, dev } = meta();
  const rows = m.type.startsWith('transfer') ? db().all("SELECT uid FROM cash_moves WHERE ref_uid = ? AND status = 'active'", [m.ref_uid]) : [m];
  rows.forEach((x) => db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, x.uid]));
  audit({ user, action: `Voided ${MOVE_LABEL[m.type]} ${$(m.amount)}`, table: 'cash_moves', recordUid: uid, reason });
}

// Cash at a shop now: what is in the safe/office, plus the floats left in the tills,
// minus cash paid to suppliers from that shop (Invoices › Pay › Cash).
export function cashOnHand(shopCode, asOf = dateStr()) {
  const moves = db().all(`SELECT type, SUM(amount) AS s FROM cash_moves WHERE shop_code = ? AND status = 'active' AND move_date <= ? GROUP BY type`, [shopCode, asOf]);
  const by = Object.fromEntries(moves.map((m) => [m.type, r2(m.s)]));
  const ins = r2(IN.reduce((s, t) => s + (by[t] || 0), 0));
  const outs = r2(['deposit', 'petty_out', 'transfer_out', 'adjust_out'].reduce((s, t) => s + (by[t] || 0), 0));
  let supplierCash = 0;
  try {
    supplierCash = r2(db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM ap_payments WHERE method = 'cash' AND status = 'active' AND shop_code = ? AND pay_date <= ?`, [shopCode, asOf]).s);
  } catch (e) { supplierCash = 0; }
  const floats = r2(listTills({ shopCode }).reduce((s, t) => s + openingFloat(t.uid), 0));
  const onHand = r2(ins - outs - supplierCash);
  return { shopCode, by, ins, outs, supplierCash, onHand, floats, total: r2(onHand + floats) };
}
export function listCashMoves({ shopCode, from, to, includeVoid = false, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('move_date >= ?'); a.push(from); }
  if (to) { w.push('move_date <= ?'); a.push(to); }
  if (!includeVoid) w.push("status = 'active'");
  return db().all(`SELECT * FROM cash_moves WHERE ${w.join(' AND ')} ORDER BY move_date DESC, updated_at DESC LIMIT ?`, a.concat([limit]));
}

// ---------------------------------------------------------------- deposits
export function saveDeposit(user, d, { photos = [] } = {}) {
  need(txt(d.shopCode), 'Choose the shop the cash is from.');
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ? AND active = 1', [d.accountUid || '']);
  need(acc, 'Choose the bank account it went into.');
  const date = txt(d.date) || dateStr();
  need(DATE.test(date) && date <= dateStr(), 'Enter the deposit date (not in the future).');
  need(txt(d.slipNo), 'Enter the deposit slip number.');
  const cash = d.denominations && Object.keys(d.denominations).length ? countDenoms(d.denominations) : r2(d.cashAmount);
  const cheques = (d.cheques || []).filter((c) => r2(c.amount) > 0).map((c) => ({ drawer: txt(c.drawer), bank: txt(c.bank), number: txt(c.number), amount: r2(c.amount) }));
  for (const c of cheques) need(c.drawer && c.number, 'Each cheque needs who it is from and its number.');
  const chq = r2(cheques.reduce((s, c) => s + c.amount, 0));
  const total = r2(cash + chq);
  need(total > 0, 'Enter the cash and/or cheques deposited.');
  need(!d.takingsFrom || DATE.test(d.takingsFrom), 'Takings from: YYYY-MM-DD.');
  need(!d.takingsTo || DATE.test(d.takingsTo), 'Takings to: YYYY-MM-DD.');
  const onHand = cashOnHand(d.shopCode, date).onHand;
  need(cash <= onHand + 0.004 || txt(d.notes), `Only ${$(onHand)} cash is recorded at this shop. Explain in the notes (e.g. takings not counted yet).`);
  need(!db().get("SELECT 1 AS x FROM deposits WHERE slip_no = ? AND account_uid = ? AND status = 'active'", [txt(d.slipNo), acc.uid]), `Deposit slip ${txt(d.slipNo)} is already recorded.`);
  const { now, dev } = meta();
  const uid = uuid('DP');
  const beUid = uuid('BE');
  db().transaction(() => {
    db().run(`INSERT INTO deposits (uid, shop_code, account_uid, deposit_date, slip_no, branch, cash_amount, cheque_amount, cheques, denominations, total, takings_from, takings_to,
      deposited_by_uid, deposited_by_name, witness, bank_entry_uid, notes, photo_urls, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'[]',?,?,?)`,
    [uid, d.shopCode, acc.uid, date, txt(d.slipNo), txt(d.branch) || null, cash, chq, JSON.stringify(cheques), JSON.stringify(d.denominations || {}), total, txt(d.takingsFrom) || null, txt(d.takingsTo) || null,
      user.uid, user.name, txt(d.witness) || null, beUid, txt(d.notes) || null, now, now, dev]);
    db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'deposit',?,?,?,?,?,?)`,
      [beUid, acc.uid, date, total, `Slip ${txt(d.slipNo)}`, `${d.shopCode} takings${d.takingsFrom ? ` ${d.takingsFrom}${d.takingsTo && d.takingsTo !== d.takingsFrom ? ` to ${d.takingsTo}` : ''}` : ''}`, user.name, now, dev]);
    if (cash > 0) addMove({ shopCode: d.shopCode, date, type: 'deposit', amount: cash, refUid: uid, note: `Slip ${txt(d.slipNo)}`, user });
  });
  if (photos.length) addPhotos('deposit', uid, photos);
  audit({ user, action: `Deposit ${$(total)} from ${d.shopCode} (slip ${txt(d.slipNo)})`, table: 'deposits', recordUid: uid });
  return getDeposit(uid);
}
export function getDeposit(uid) {
  const r = db().get('SELECT d.*, b.name AS account_name FROM deposits d LEFT JOIN bank_accounts b ON b.uid = d.account_uid WHERE d.uid = ?', [uid]);
  return r ? { ...r, cheques: J(r.cheques, []), denominations: J(r.denominations, {}), photos: J(r.photo_urls, []) } : null;
}
export function listDeposits({ shopCode, from, to, includeVoid = false } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('d.shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('d.deposit_date >= ?'); a.push(from); }
  if (to) { w.push('d.deposit_date <= ?'); a.push(to); }
  if (!includeVoid) w.push("d.status = 'active'");
  return db().all(`SELECT d.*, b.name AS account_name, e.cleared_date FROM deposits d LEFT JOIN bank_accounts b ON b.uid = d.account_uid LEFT JOIN bank_entries e ON e.uid = d.bank_entry_uid
    WHERE ${w.join(' AND ')} ORDER BY d.deposit_date DESC, d.created_at DESC`, a);
}
export function voidDeposit(user, uid, reason) {
  need(txt(reason), 'Give a reason.');
  const d = getDeposit(uid);
  need(d && d.status === 'active', 'Not found.');
  need(!db().get('SELECT 1 AS x FROM bank_entries WHERE uid = ? AND cleared_date IS NOT NULL', [d.bank_entry_uid]), 'This deposit is already on a bank statement. Un-match it in Bank reconciliation first.');
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`UPDATE deposits SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
    db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, d.bank_entry_uid]);
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND type = 'deposit'`, [txt(reason), now, dev, uid]);
  });
  audit({ user, action: `Voided deposit ${$(d.total)} slip ${d.slip_no}`, table: 'deposits', recordUid: uid, reason });
}

export function tillAlerts() {
  const waiting = listTillCounts({ status: 'counted' }).length + listTillCounts({ status: 'queried' }).length;
  const short = listTillCounts({ from: dateStr(new Date(Date.now() - 7 * 86400000)) }).filter((c) => c.over_short < -tillRules().tolerance);
  return { waiting, shortWeek: short.length, shortAmount: r2(short.reduce((s, c) => s + c.over_short, 0)) };
}
