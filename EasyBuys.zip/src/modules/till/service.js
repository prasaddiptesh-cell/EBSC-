// Till & cash. At the end of a shift the cashier counts the till note by note, types in the Z report totals,
// takes a photo of the Z report, and explains any difference. A manager approves it.
// The cash taken from the till goes into the shop's cash on hand; deposits and petty cash take it out.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared, money } from '../../services/core.js';
import { addPhotos } from '../../services/stock.js';
import { notify } from '../verify/service.js';
import { assertOpen } from '../../services/lock.js';
import { needReason, can, actsAsOwner, requireSetup } from '../../services/access.js';
import { linkCountToShift, unlinkCount, unbalancedBefore, syncShortage, cancelShortage, shortageForCount } from './shifts.js';
import { rematchAround } from './eod.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const ownerish = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
// Cashier and balancer: two different people, unless that person is the owner/admin or may run and balance their own till.
export function checkSigners(cashierUid, balancerUid) {
  need(balancerUid, 'Choose who balanced the till.');
  if (cashierUid !== balancerUid) return;
  const p = db().get('SELECT * FROM users WHERE uid = ?', [balancerUid]);
  need(p && (ownerish(p) || can(p, 'till_self_balance')),
    `${p ? p.name : 'This person'} cannot be both the cashier and the balancer. Choose someone else to balance the till (or the admin can give the permission "May run and balance their own till").`);
}

// Fiji notes and coins.
export const DENOMS = [
  { key: 'n100', label: '$100', value: 100 }, { key: 'n50', label: '$50', value: 50 }, { key: 'n20', label: '$20', value: 20 }, { key: 'n10', label: '$10', value: 10 },
  { key: 'n5', label: '$5', value: 5 }, { key: 'c2', label: '$2', value: 2 }, { key: 'c1', label: '$1', value: 1 }, { key: 'c50', label: '50c', value: 0.5 },
  { key: 'c20', label: '20c', value: 0.2 }, { key: 'c10', label: '10c', value: 0.1 }, { key: 'c5', label: '5c', value: 0.05 },
];
export function countDenoms(d) {
  return r2(DENOMS.reduce((s, x) => s + (Math.max(0, Math.round(Number((d || {})[x.key]) || 0)) * x.value), 0));
}

// ---------------------------------------------------------------- rules (admin)
export const TILL_DEFAULTS = {
  shifts: ['Morning', 'Afternoon', 'Night', 'Full day'],
  tenders: ['EFTPOS / card', 'M-PAiSA', 'MyCash', 'Cheques received', 'On account (credit sales)', 'Vouchers'],
  payoutTypes: ['Supplier paid from till', 'Refund', 'Staff advance', 'Petty cash', 'Other'],
  tolerance: 2,              // differences up to this much need no reason
  requireZPhoto: true,       // a photo of the Z report must be taken
  blindCount: false,         // the cashier does not see the expected cash until the count is saved
  managerApproves: true,     // a manager must approve every count
  shortageRule: 'deduct',    // 'deduct': a shortage over the tolerance is taken from the cashier's pay unless the owner writes it off; 'decide': the approver chooses
  shortagePerWeek: 0,        // 0 = all in the next pay; otherwise at most this much a week
  pettyCategories: ['Cleaning', 'Office', 'Transport', 'Food & tea', 'Repairs', 'Other'],
  requireSignatures: true,   // v3.5: the cashier and the balancer both sign every till balance before it is approved
  eodTolerance: 0.05,        // v3.5: an Aronium End of day this close to the till's Z total agrees
  secondCount: 'off',        // v3.9.2: a second count by a supervisor – 'off' (when they choose to), 'when_off' (asked for when short or over) or 'always'
};
export function tillRules() {
  return { ...TILL_DEFAULTS, ...(getShared('till_rules', {}) || {}) };
}
export function saveTillRules(user, r) {
  requireSetup(user, 'till_approve');
  const list = (v) => (Array.isArray(v) ? v : String(v || '').split('\n')).map(txt).filter(Boolean);
  const tol = Number(r.tolerance);
  need(Number.isFinite(tol) && tol >= 0 && tol <= 1000, 'Tolerance must be between 0 and 1000.');
  const clean = { shifts: list(r.shifts), tenders: list(r.tenders), payoutTypes: list(r.payoutTypes), pettyCategories: list(r.pettyCategories), tolerance: r2(tol),
    requireZPhoto: !!r.requireZPhoto, blindCount: !!r.blindCount, managerApproves: !!r.managerApproves,
    shortageRule: r.shortageRule === 'decide' ? 'decide' : 'deduct', shortagePerWeek: Math.max(0, r2(r.shortagePerWeek)),
    requireSignatures: r.requireSignatures !== false, eodTolerance: Math.max(0, r2(r.eodTolerance === undefined || r.eodTolerance === '' ? 0.05 : r.eodTolerance)),
    secondCount: ['always', 'when_off', 'off'].includes(r.secondCount) ? r.secondCount : 'off' };
  need(clean.shifts.length, 'Add at least one shift name.');
  const before = tillRules();
  setShared('till_rules', clean);
  audit({ user, action: 'Changed till rules', table: 'shared_settings', recordUid: 'till_rules', before, after: clean });
  return clean;
}

// ---------------------------------------------------------------- tills (admin)
export function listTills({ shopCode, includeInactive = false } = {}) {
  return db().all(`SELECT * FROM tills WHERE (? IS NULL OR shop_code = ?) AND (? = 1 OR active = 1) ORDER BY shop_code, sort, name`, [shopCode || null, shopCode || null, includeInactive ? 1 : 0]);
}
export function saveTill(user, t) {
  need(txt(t.shopCode), 'Choose the shop.');
  need(txt(t.name), 'Name the till, e.g. "Till 1".');
  const f = r2(t.floatAmount);
  need(f >= 0 && f <= 10000, 'The float must be between 0 and 10,000.');
  const uid = t.uid || uuid('TL');
  const { now, dev } = meta();
  db().run(`INSERT INTO tills (uid, shop_code, name, float_amount, active, sort, updated_at, updated_device) VALUES (?,?,?,?,?,COALESCE((SELECT MAX(sort)+1 FROM tills),0),?,?)
    ON CONFLICT(uid) DO UPDATE SET shop_code=excluded.shop_code, name=excluded.name, float_amount=excluded.float_amount, active=excluded.active, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, t.shopCode, txt(t.name), f, t.active === false ? 0 : 1, now, dev]);
  audit({ user, action: `Till ${txt(t.name)} (${t.shopCode}) float ${$(f)}`, table: 'tills', recordUid: uid });
  return uid;
}

// The float the till started with: the float left at its last count, else its standard float.
export function openingFloat(tillUid) {
  const last = db().get("SELECT float_kept FROM till_counts WHERE till_uid = ? AND status <> 'void' ORDER BY shift_date DESC, counted_at DESC LIMIT 1", [tillUid]);
  if (last) return r2(last.float_kept);
  const t = db().get('SELECT float_amount FROM tills WHERE uid = ?', [tillUid]);
  return t ? r2(t.float_amount) : 0;
}

// expected cash in the drawer = float at start + cash sales on the Z report − cash paid out − cash dropped to the safe ± corrections
export function workOut(c) {
  const payouts = r2((c.payouts || []).reduce((s, p) => s + r2(p.amount), 0));
  const adjust = r2((c.adjustments || []).reduce((s, a) => s + r2(a.amount), 0));
  const byNotes = c.denominations ? countDenoms(c.denominations) : 0;
  const counted = byNotes > 0 ? byNotes : r2(c.cashCounted);
  const expected = r2(r2(c.openingFloat) + r2(c.zCash) - payouts - r2(c.drops) + adjust);
  const overShort = r2(counted - expected);
  const toSafe = r2(counted - r2(c.floatKept) + r2(c.drops));
  const tenders = r2((c.tenders || []).reduce((s, t) => s + r2(t.amount), 0));
  const zCheck = c.zTotal === '' || c.zTotal === null || c.zTotal === undefined ? null : r2(r2(c.zTotal) - r2(c.zCash) - tenders);
  return { counted, payouts, adjust, expected, overShort, toSafe, tenders, zCheck };
}

export function saveTillCount(user, c, { photos = [] } = {}) {
  assertOpen(txt(c.shiftDate) || dateStr(), 'This till count');
  const rules = tillRules();
  need(txt(c.shopCode), 'Choose the shop.');
  const till = c.tillUid ? db().get('SELECT * FROM tills WHERE uid = ?', [c.tillUid]) : null;
  need(till || !listTills({ shopCode: c.shopCode }).length, 'Choose the till.');
  const date = txt(c.shiftDate) || dateStr();
  need(DATE.test(date) && date <= dateStr(), 'Enter the shift date (not in the future).');
  need(txt(c.shift), 'Choose the shift.');
  const w = workOut(c);
  need(w.counted >= 0, 'Count the cash.');
  need(c.zCash !== '' && c.zCash !== undefined && c.zCash !== null && r2(c.zCash) >= 0, 'Enter the CASH sales from the Z report.');
  need(r2(c.floatKept) >= 0 && r2(c.floatKept) <= w.counted, 'The float left in the till cannot be more than the cash counted.');
  need(r2(c.drops) >= 0, 'Drops to the safe cannot be below zero.');
  for (const p of c.payouts || []) need(r2(p.amount) > 0 && txt(p.what), 'Each cash paid out needs what it was for and the amount.');
  for (const a of c.adjustments || []) { need(r2(a.amount) !== 0, 'Each correction needs an amount.'); needReason(user, a.reason, 'Each correction needs an amount and a reason.'); }
  if (Math.abs(w.overShort) > rules.tolerance) needReason(user, c.reason, `The till is ${w.overShort > 0 ? 'over' : 'short'} by ${$(Math.abs(w.overShort))}. Write the reason.`);
  const before = c.uid ? db().get('SELECT * FROM till_counts WHERE uid = ?', [c.uid]) : null;
  need(!before || before.status !== 'approved', 'This count is approved. A manager must re-open it first.');
  const hasPhoto = photos.length > 0 || (before && (J(before.photo_urls, []).length || db().get("SELECT 1 AS x FROM photos WHERE ref_type = 'till' AND ref_id = ?", [before.uid])));
  need(!rules.requireZPhoto || hasPhoto, 'Take a photo of the Z report.');
  const dupe = db().get("SELECT counted_by_name FROM till_counts WHERE till_uid IS ? AND shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void' AND uid <> ?",
    [c.tillUid || null, c.shopCode, date, c.shift, c.uid || '']);
  need(!dupe, `This till and shift was already counted by ${dupe && dupe.counted_by_name}. Open that count instead.`);
  // One shift after the other: an earlier shift of this till started but not balanced must be balanced first.
  if (!before && till && !ownerish(user)) {
    const open = unbalancedBefore(till.uid, date, c.shift);
    need(!open.length, open.length ? `${till.name} – ${open[0].shift} ${open[0].shift_date} (${open[0].cashier_name}) is not balanced yet. Balance that shift first (or the owner can continue it).` : '');
  }
  const { now, dev } = meta();
  const uid = c.uid || uuid('TC');
  const cashier = c.cashierUid ? db().get('SELECT uid, name FROM users WHERE uid = ?', [c.cashierUid]) : null;
  // Two signatures: the cashier and the person who balanced the till (both chosen from the staff list).
  const balancer = db().get('SELECT uid, name FROM users WHERE uid = ?', [c.balancerUid || user.uid]);
  const sigs = !!(txt(c.cashierSig) && txt(c.balancerSig));
  if (sigs) checkSigners(cashier ? cashier.uid : user.uid, balancer ? balancer.uid : user.uid);
  const vals = {
    shop_code: c.shopCode, till_uid: till ? till.uid : null, till_name: till ? till.name : 'Till', shift_date: date, shift: c.shift,
    cashier_uid: cashier ? cashier.uid : user.uid, cashier_name: cashier ? cashier.name : user.name, counted_by_uid: user.uid, counted_by_name: user.name, counted_at: now,
    opening_float: r2(c.openingFloat), denominations: JSON.stringify(c.denominations || {}), cash_counted: w.counted, float_kept: r2(c.floatKept),
    z_number: txt(c.zNumber) || null, z_total: c.zTotal === '' || c.zTotal === undefined ? null : r2(c.zTotal), z_cash: r2(c.zCash),
    tenders: JSON.stringify((c.tenders || []).filter((t) => r2(t.amount)).map((t) => ({ method: t.method, amount: r2(t.amount) }))),
    payouts: JSON.stringify((c.payouts || []).map((p) => ({ what: txt(p.what), amount: r2(p.amount), note: txt(p.note) }))), drops: r2(c.drops),
    adjustments: JSON.stringify((c.adjustments || []).map((a) => ({ amount: r2(a.amount), reason: txt(a.reason), ...(a.kind === 'tender_fix' ? { kind: 'tender_fix', to: txt(a.to) || 'M-PAiSA' } : {}) }))),
    expected_cash: w.expected, over_short: w.overShort, reason: txt(c.reason) || null, notes: txt(c.notes) || null,
    z_vat: c.zVat === '' || c.zVat === undefined || c.zVat === null ? null : r2(c.zVat), z_zero_rated: c.zZeroRated === '' || c.zZeroRated === undefined || c.zZeroRated === null ? null : r2(c.zZeroRated),
    z_refunds: c.zRefunds === '' || c.zRefunds === undefined || c.zRefunds === null ? null : r2(c.zRefunds), z_voids: c.zVoids === '' || c.zVoids === undefined || c.zVoids === null ? null : r2(c.zVoids),
    z_customers: c.zCustomers === '' || c.zCustomers === undefined || c.zCustomers === null ? null : Math.round(Number(c.zCustomers)),
    status: rules.managerApproves ? 'counted' : 'approved', updated_at: now, updated_device: dev,
    balancer_uid: balancer ? balancer.uid : null, balancer_name: balancer ? balancer.name : null,
    // A changed count must be signed again (the signatures were for the old figures).
    cashier_sig: sigs ? c.cashierSig : null, balancer_sig: sigs ? c.balancerSig : null, signed_at: sigs ? now : null,
    // v3.9.2 What was read from the Z report photo and what the person changed (shown on the count).
    z_read: c.zRead ? JSON.stringify(c.zRead).slice(0, 4000) : (before ? before.z_read || null : null),
  };
  if (!rules.managerApproves && rules.requireSignatures) need(sigs, 'The cashier and the balancer must both sign the till balance.');
  db().transaction(() => {
    if (before) {
      const cols = Object.keys(vals);
      db().run(`UPDATE till_counts SET ${cols.map((k) => `${k} = ?`).join(', ')}, sync_status = 'pending' WHERE uid = ?`, cols.map((k) => vals[k]).concat([uid]));
    } else {
      Object.assign(vals, { uid, photo_urls: '[]' });
      const cols = Object.keys(vals);
      db().run(`INSERT INTO till_counts (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, cols.map((k) => vals[k]));
    }
    // The cash that leaves the till goes to the shop's cash on hand (one movement per count, replaced if the count changes).
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = 'Count changed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND type = 'from_till' AND status = 'active'`, [now, dev, uid]);
    if (w.toSafe > 0) addMove({ shopCode: c.shopCode, date, type: 'from_till', amount: w.toSafe, refUid: uid, note: `${vals.till_name} ${c.shift} ${date}`, user });
    const saved = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
    const shiftUid = linkCountToShift(user, saved);
    db().run('UPDATE till_counts SET shift_uid = ? WHERE uid = ?', [shiftUid, uid]);
    syncShortage(user, saved, rules.tolerance);
    try { const RC = require('./recount.js'); RC.syncSurplus(user, saved, rules.tolerance); RC.flagSecondCount(saved, rules); } catch (e) { if (e && e.isAppError) throw e; }
  });
  if (before && (before.shop_code !== c.shopCode || before.shift_date !== date)) rematchAround(before.shop_code, before.shift_date);
  rematchAround(c.shopCode, date);
  if (photos.length) addPhotos('till', uid, photos);
  audit({ user, action: `Till count ${vals.till_name} ${c.shopCode} ${date} ${c.shift}: ${w.overShort ? `${w.overShort > 0 ? 'over' : 'short'} ${$(Math.abs(w.overShort))}` : 'balanced'}`,
    table: 'till_counts', recordUid: uid, before: before && { counted: before.cash_counted, overShort: before.over_short }, after: { counted: w.counted, expected: w.expected, overShort: w.overShort }, reason: c.reason });
  if (!before && w.overShort < -tillRules().tolerance) notify('till_short', `${vals.till_name} ${c.shift} ${date} is SHORT ${$(-w.overShort)} (counted by ${user.name}). Reason given: ${txt(c.reason) || '—'}`, { shopCode: c.shopCode });
  return getTillCount(uid);
}

export function getTillCount(uid) {
  const r = db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]);
  if (!r) return null;
  return { ...r, denominations: J(r.denominations, {}), tenders: J(r.tenders, []), payouts: J(r.payouts, []), adjustments: J(r.adjustments, []), photos: J(r.photo_urls, []), zRead: J(r.z_read, null) };
}
export function listTillCounts({ shopCode, from, to, status, limit = 300 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); } else w.push("status <> 'void'");
  return db().all(`SELECT * FROM till_counts WHERE ${w.join(' AND ')} ORDER BY shift_date DESC, counted_at DESC LIMIT ?`, a.concat([limit]));
}

// The cashier and the balancer sign the till balance (it can be signed after it was saved).
export function signTillCount(user, uid, { cashierSig, balancerSig, balancerUid } = {}) {
  const c = getTillCount(uid);
  need(c && c.status !== 'void', 'Count not found.');
  need(c.status !== 'approved', 'This till balance is already approved.');
  need(txt(cashierSig), `${c.cashier_name} (the cashier) must sign.`);
  need(txt(balancerSig), 'The person who balanced the till must sign.');
  const b = db().get('SELECT uid, name FROM users WHERE uid = ?', [balancerUid || c.balancer_uid || user.uid]);
  need(b, 'Choose who balanced the till.');
  checkSigners(c.cashier_uid, b.uid);
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET balancer_uid = ?, balancer_name = ?, cashier_sig = ?, balancer_sig = ?, signed_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [b.uid, b.name, cashierSig, balancerSig, now, now, dev, uid]);
  audit({ user, action: `Till balance ${c.till_name} ${c.shift} ${c.shift_date} signed by ${c.cashier_name} (cashier) and ${b.name} (balancer)`, table: 'till_counts', recordUid: uid });
  return getTillCount(uid);
}
export const isSigned = (c) => !!(c && c.cashier_sig && c.balancer_sig);

// Approve (or query) a count. Both signatures are needed first. A shortage over the tolerance goes to the cashier to
// agree (or not) – see shifts.js; only the owner/admin can write it off here with a reason.
export function approveTillCount(user, uid, { query = false, note = '', shortAction, writeOffReason } = {}) {
  const c = getTillCount(uid);
  need(c, 'Count not found.');
  need(c.status === 'counted' || c.status === 'queried', c.status === 'approved' ? 'Already approved.' : 'This count is void.');
  need(!query || txt(note), 'Write what needs to be checked.');
  need(query || c.counted_by_uid !== user.uid || ['owner', 'admin'].includes(user.role), 'Someone else must approve your own count.');
  const rules = tillRules();
  need(query || !rules.requireSignatures || isSigned(c), 'The cashier and the balancer must both sign the till balance before it is approved.');
  const short = c.over_short < -rules.tolerance - 0.004 ? r2(-c.over_short) : 0;
  let action = c.short_action || null;
  if (!query && short) {
    need(shortAction === undefined || shortAction === null || shortAction === '' || ['deduct', 'agreement', 'write_off'].includes(shortAction), `The till is short ${$(short)}. Choose: the cashier agrees (taken from pay), or write it off.`);
    let s = shortageForCount(uid);
    if (!s) { syncShortage(user, db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]), rules.tolerance); s = shortageForCount(uid); }
    if (shortAction === 'write_off') {
      need(s && ['waiting', 'disagreed'].includes(s.status), 'This shortage is already decided.');
      const { decideShortage } = require('./shifts.js');
      decideShortage(user, s.uid, { action: 'write_off', note: writeOffReason });
      action = 'write_off';
    } else if (s && ['waiting', 'disagreed'].includes(s.status)) action = 'agreement';
  }
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET status = ?, approved_by_name = ?, approved_at = ?, approve_note = ?, short_action = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [query ? 'queried' : 'approved', user.name, now, txt(note) || null, action, now, dev, uid]);
  audit({ user, action: `${query ? 'Queried' : 'Approved'} till count ${c.till_name} ${c.shop_code} ${c.shift_date}${action === 'agreement' ? ' – shortage waiting for the cashier' : action === 'write_off' ? ' – shortage written off' : ''}`,
    table: 'till_counts', recordUid: uid, reason: note || writeOffReason });
}
export function reopenTillCount(user, uid, reason) {
  { const x = db().get('SELECT shift_date FROM till_counts WHERE uid = ?', [uid]); if (x) assertOpen(x.shift_date, 'This till count'); }
  needReason(user, reason, 'Give a reason.');
  const c = getTillCount(uid);
  need(c && c.status === 'approved', 'Only an approved till count can be re-opened.');
  cancelShortage(user, uid, `re-opened: ${txt(reason)}`);
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET status = 'counted', approve_note = ?, short_action = NULL, short_charge_uid = NULL, short_note = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ? AND status = 'approved'`, [`Re-opened: ${txt(reason)}`, now, dev, uid]);
  // The shortage is worked out again and goes back to the cashier.
  syncShortage(user, db().get('SELECT * FROM till_counts WHERE uid = ?', [uid]), tillRules().tolerance);
  audit({ user, action: 'Re-opened till count', table: 'till_counts', recordUid: uid, reason });
}
export function voidTillCount(user, uid, reason) {
  { const x = db().get('SELECT shift_date FROM till_counts WHERE uid = ?', [uid]); if (x) assertOpen(x.shift_date, 'This till count'); }
  needReason(user, reason, 'Give a reason.');
  const c = getTillCount(uid);
  need(c && c.status !== 'void', 'Count not found.');
  need(c.status !== 'approved', 'Re-open it first.');
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`UPDATE till_counts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND status = 'active'`, [txt(reason), now, dev, uid]);
    cancelShortage(user, uid, `voided: ${txt(reason)}`);
    unlinkCount(uid);
  });
  rematchAround(c.shop_code, c.shift_date);
  audit({ user, action: `Voided till count ${c.till_name} ${c.shift_date}`, table: 'till_counts', recordUid: uid, reason });
}

// ---------------------------------------------------------------- cash on hand
export const MOVE_LABEL = { opening: 'Starting cash', from_till: 'From till', deposit: 'Banked', petty_out: 'Petty cash spent', petty_in: 'Petty cash top-up', transfer_in: 'From another shop', transfer_out: 'To another shop', adjust_in: 'Correction (+)', adjust_out: 'Correction (−)' };
const IN = ['opening', 'from_till', 'petty_in', 'transfer_in', 'adjust_in'];
export function addCashMove(m) { return addMove(m); }
function addMove({ shopCode, date, type, amount, refUid, category, note, user, photos }) {
  const { now, dev } = meta();
  const uid = uuid('CM');
  db().run(`INSERT INTO cash_moves (uid, shop_code, move_date, type, amount, ref_uid, category, note, photo_urls, by_name, by_uid, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,'[]',?,?,?,?)`,
    [uid, shopCode, date, type, r2(amount), refUid || null, category || null, note || null, user ? user.name : null, user ? user.uid : null, now, dev]);
  if (photos && photos.length) addPhotos('cash', uid, photos);
  return uid;
}

// Petty cash, top-ups, moving cash between shops, starting cash and corrections.
export function recordCash(user, m) {
  need(txt(m.shopCode), 'Choose the shop.');
  assertOpen(txt(m.date) || dateStr(), 'This cash record');
  need(['opening', 'petty_out', 'petty_in', 'transfer', 'adjust_in', 'adjust_out'].includes(m.type), 'Choose what happened.');
  const amt = r2(m.amount);
  need(amt > 0, 'Enter the amount.');
  const date = txt(m.date) || dateStr();
  need(DATE.test(date), 'Enter the date as YYYY-MM-DD.');
  if (m.type === 'petty_out') need(txt(m.category) && txt(m.note), 'Say what the petty cash was spent on.');
  if (m.type.startsWith('adjust')) needReason(user, m.note, 'A correction needs a reason.');
  if (m.type === 'transfer') {
    need(txt(m.toShop) && m.toShop !== m.shopCode, 'Choose the shop the cash went to.');
    const ref = uuid('TR');
    addMove({ shopCode: m.shopCode, date, type: 'transfer_out', amount: amt, refUid: ref, note: `To ${m.toShop}${m.note ? ` – ${txt(m.note)}` : ''}`, user });
    addMove({ shopCode: m.toShop, date, type: 'transfer_in', amount: amt, refUid: ref, note: `From ${m.shopCode}${m.note ? ` – ${txt(m.note)}` : ''}`, user });
  } else {
    if (m.type === 'petty_out') need(cashOnHand(m.shopCode, date).onHand >= amt - 0.004, 'There is not that much cash recorded at this shop.');
    addMove({ shopCode: m.shopCode, date, type: m.type, amount: amt, category: txt(m.category) || null, note: txt(m.note) || null, user, photos: m.photos });
  }
  audit({ user, action: `${MOVE_LABEL[m.type] || 'Cash moved'} ${$(amt)} ${m.shopCode}${m.toShop ? ` → ${m.toShop}` : ''}`, table: 'cash_moves', reason: m.note });
}
export function voidCashMove(user, uid, reason) {
  { const x = db().get('SELECT move_date FROM cash_moves WHERE uid = ?', [uid]); if (x) assertOpen(x.move_date, 'This cash record'); }
  needReason(user, reason, 'Give a reason.');
  const m = db().get('SELECT * FROM cash_moves WHERE uid = ?', [uid]);
  need(m && m.status === 'active', 'Not found.');
  need(!['from_till', 'deposit'].includes(m.type), 'Change the till count or the deposit instead.');
  const { now, dev } = meta();
  const rows = m.type.startsWith('transfer') ? db().all("SELECT uid FROM cash_moves WHERE ref_uid = ? AND status = 'active'", [m.ref_uid]) : [m];
  rows.forEach((x) => db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, x.uid]));
  audit({ user, action: `Voided ${MOVE_LABEL[m.type]} ${$(m.amount)}`, table: 'cash_moves', recordUid: uid, reason });
}

// Cash at a shop now: what is in the safe/office, plus the floats left in the tills,
// minus cash paid to suppliers from that shop (Invoices › Pay › Cash).
export function cashOnHand(shopCode, asOf = dateStr()) {
  const moves = db().all(`SELECT type, SUM(amount) AS s FROM cash_moves WHERE shop_code = ? AND status = 'active' AND move_date <= ? GROUP BY type`, [shopCode, asOf]);
  const by = Object.fromEntries(moves.map((m) => [m.type, r2(m.s)]));
  const ins = r2(IN.reduce((s, t) => s + (by[t] || 0), 0));
  const outs = r2(['deposit', 'petty_out', 'transfer_out', 'adjust_out'].reduce((s, t) => s + (by[t] || 0), 0));
  let supplierCash = 0;
  try {
    // v3.9.8 cash paid from a till is not taken from the safe: the person counting that till enters it as paid out.
    supplierCash = r2(db().get(`SELECT IFNULL(SUM(amount),0) AS s FROM ap_payments WHERE method = 'cash' AND status = 'active' AND shop_code = ? AND pay_date <= ? AND IFNULL(cash_from,'') NOT LIKE 'till:%'`, [shopCode, asOf]).s);
  } catch (e) { supplierCash = 0; }
  // Cash wages: each shop pays its own staff (staff without a shop: the payroll rule's shop).
  let wagesCash = 0;
  try {
    const { payRules } = require('../payroll/service.js');
    const fallback = payRules().wagesDefaultShop || '';
    wagesCash = r2(db().get(`SELECT IFNULL(SUM(l.net),0) AS s FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final'
      WHERE l.include = 1 AND IFNULL(l.pay_method,'cash') <> 'bank' AND COALESCE(NULLIF(l.shop_code,''), ?) = ? AND r.pay_date <= ?`, [fallback, shopCode, asOf]).s);
  } catch (e) { wagesCash = 0; }
  const floats = r2(listTills({ shopCode }).reduce((s, t) => s + openingFloat(t.uid), 0));
  const onHand = r2(ins - outs - supplierCash - wagesCash);
  return { shopCode, by, ins, outs, supplierCash, wagesCash, onHand, floats, total: r2(onHand + floats) };
}
export function listCashMoves({ shopCode, from, to, includeVoid = false, limit = 500 } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('move_date >= ?'); a.push(from); }
  if (to) { w.push('move_date <= ?'); a.push(to); }
  if (!includeVoid) w.push("status = 'active'");
  return db().all(`SELECT * FROM cash_moves WHERE ${w.join(' AND ')} ORDER BY move_date DESC, updated_at DESC LIMIT ?`, a.concat([limit]));
}

// ---------------------------------------------------------------- deposits
export function saveDeposit(user, d, { photos = [] } = {}) {
  assertOpen(txt(d.date) || dateStr(), 'This deposit');
  need(txt(d.shopCode), 'Choose the shop the cash is from.');
  const acc = db().get('SELECT * FROM bank_accounts WHERE uid = ? AND active = 1', [d.accountUid || '']);
  need(acc, 'Choose the bank account it went into.');
  const date = txt(d.date) || dateStr();
  need(DATE.test(date) && date <= dateStr(), 'Enter the deposit date (not in the future).');
  need(txt(d.slipNo), 'Enter the deposit slip number.');
  const cash = d.denominations && Object.keys(d.denominations).length ? countDenoms(d.denominations) : r2(d.cashAmount);
  const cheques = (d.cheques || []).filter((c) => r2(c.amount) > 0).map((c) => ({ drawer: txt(c.drawer), bank: txt(c.bank), number: txt(c.number), amount: r2(c.amount) }));
  for (const c of cheques) need(c.drawer && c.number, 'Each cheque needs who it is from and its number.');
  const chq = r2(cheques.reduce((s, c) => s + c.amount, 0));
  const total = r2(cash + chq);
  need(total > 0, 'Enter the cash and/or cheques deposited.');
  need(!d.takingsFrom || DATE.test(d.takingsFrom), 'Takings from: YYYY-MM-DD.');
  need(!d.takingsTo || DATE.test(d.takingsTo), 'Takings to: YYYY-MM-DD.');
  const onHand = cashOnHand(d.shopCode, date).onHand;
  if (cash > onHand + 0.004) needReason(user, d.notes, `Only ${$(onHand)} cash is recorded at this shop. Explain in the notes (e.g. takings not counted yet).`);
  need(!db().get("SELECT 1 AS x FROM deposits WHERE slip_no = ? AND account_uid = ? AND status = 'active'", [txt(d.slipNo), acc.uid]), `Deposit slip ${txt(d.slipNo)} is already recorded.`);
  const { now, dev } = meta();
  const uid = uuid('DP');
  const beUid = uuid('BE');
  db().transaction(() => {
    db().run(`INSERT INTO deposits (uid, shop_code, account_uid, deposit_date, slip_no, branch, cash_amount, cheque_amount, cheques, denominations, total, takings_from, takings_to,
      deposited_by_uid, deposited_by_name, witness, bank_entry_uid, notes, photo_urls, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'[]',?,?,?)`,
    [uid, d.shopCode, acc.uid, date, txt(d.slipNo), txt(d.branch) || null, cash, chq, JSON.stringify(cheques), JSON.stringify(d.denominations || {}), total, txt(d.takingsFrom) || null, txt(d.takingsTo) || null,
      user.uid, user.name, txt(d.witness) || null, beUid, txt(d.notes) || null, now, now, dev]);
    db().run(`INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?,'deposit',?,?,?,?,?,?)`,
      [beUid, acc.uid, date, total, `Slip ${txt(d.slipNo)}`, `${d.shopCode} takings${d.takingsFrom ? ` ${d.takingsFrom}${d.takingsTo && d.takingsTo !== d.takingsFrom ? ` to ${d.takingsTo}` : ''}` : ''}`, user.name, now, dev]);
    if (cash > 0) addMove({ shopCode: d.shopCode, date, type: 'deposit', amount: cash, refUid: uid, note: `Slip ${txt(d.slipNo)}`, user });
    // v3.9.2 the cheques / invoices this deposit covers (the rest of the deposit is general money)
    if ((d.covers || []).length) require('../payables/cover.js').saveCovers(user, uid, d.covers, total);
  });
  if (photos.length) addPhotos('deposit', uid, photos);
  audit({ user, action: `Deposit ${$(total)} from ${d.shopCode} (slip ${txt(d.slipNo)})`, table: 'deposits', recordUid: uid });
  notify('deposit', `Bank deposit ${$(total)} (cash ${$(cash)}, cheques ${$(chq)}) slip ${txt(d.slipNo)} by ${user.name} on ${date}.`, { shopCode: d.shopCode });
  return getDeposit(uid);
}
export function getDeposit(uid) {
  const r = db().get('SELECT d.*, b.name AS account_name FROM deposits d LEFT JOIN bank_accounts b ON b.uid = d.account_uid WHERE d.uid = ?', [uid]);
  return r ? { ...r, cheques: J(r.cheques, []), denominations: J(r.denominations, {}), photos: J(r.photo_urls, []) } : null;
}
export function listDeposits({ shopCode, from, to, includeVoid = false } = {}) {
  const w = ['1=1'];
  const a = [];
  if (shopCode) { w.push('d.shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('d.deposit_date >= ?'); a.push(from); }
  if (to) { w.push('d.deposit_date <= ?'); a.push(to); }
  if (!includeVoid) w.push("d.status = 'active'");
  return db().all(`SELECT d.*, b.name AS account_name, e.cleared_date FROM deposits d LEFT JOIN bank_accounts b ON b.uid = d.account_uid LEFT JOIN bank_entries e ON e.uid = d.bank_entry_uid
    WHERE ${w.join(' AND ')} ORDER BY d.deposit_date DESC, d.created_at DESC`, a);
}
export function voidDeposit(user, uid, reason) {
  { const x = db().get('SELECT deposit_date FROM deposits WHERE uid = ?', [uid]); if (x) assertOpen(x.deposit_date, 'This deposit'); }
  needReason(user, reason, 'Give a reason.');
  const d = getDeposit(uid);
  need(d && d.status === 'active', 'Not found.');
  need(!db().get('SELECT 1 AS x FROM bank_entries WHERE uid = ? AND cleared_date IS NOT NULL', [d.bank_entry_uid]), 'This deposit is already on a bank statement. Un-match it in Bank reconciliation first.');
  const { now, dev } = meta();
  db().transaction(() => {
    db().run(`UPDATE deposits SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, uid]);
    db().run(`UPDATE bank_entries SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), now, dev, d.bank_entry_uid]);
    db().run(`UPDATE cash_moves SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE ref_uid = ? AND type = 'deposit'`, [txt(reason), now, dev, uid]);
    try { require('../payables/cover.js').voidCoversForDeposit(uid); } catch (e) { /* no covers */ }
  });
  audit({ user, action: `Voided deposit ${$(d.total)} slip ${d.slip_no}`, table: 'deposits', recordUid: uid, reason });
}

export function tillAlerts() {
  let waiting = listTillCounts({ status: 'counted' }).length + listTillCounts({ status: 'queried' }).length;
  const short = listTillCounts({ from: dateStr(new Date(Date.now() - 7 * 86400000)) }).filter((c) => c.over_short < -tillRules().tolerance);
  // v3.5: shifts still to balance, till balances not signed, Aronium End of day problems, shortages waiting for the cashier.
  let shifts = []; let eod = { differences: [], noTill: [] }; let shortages = []; let unsigned = 0;
  try { shifts = require('./shifts.js').shiftsToBalance(); } catch (e) { shifts = []; }
  try { eod = require('./eod.js').eodProblems(); } catch (e) { eod = { differences: [], noTill: [] }; }
  try { shortages = require('./shifts.js').undecidedShortages(); } catch (e) { shortages = []; }
  try { unsigned = tillRules().requireSignatures ? db().get("SELECT COUNT(*) AS n FROM till_counts WHERE status IN ('counted','queried') AND (cashier_sig IS NULL OR balancer_sig IS NULL)").n : 0; } catch (e) { unsigned = 0; }
  // v3.9.7 fresh start: nothing dated before the go-live date is a warning (Aronium history, old shifts and counts);
  // an old shortage only once the owner has marked it Seen in "Before go-live".
  let G = null;
  try { G = require('../../services/goLive.js'); } catch (e) { G = null; }
  const from = G ? G.freshFrom() : null;
  if (from) {
    shifts = shifts.filter((s) => !s.shift_date || s.shift_date >= from);
    eod = { differences: eod.differences.filter((e) => e.eod_date >= from), noTill: eod.noTill.filter((e) => e.eod_date >= from) };
    shortages = G.keepList(shortages, (x) => `till_shortages:${x.uid}`, (x) => x.shift_date);
    try {
      waiting = db().get("SELECT COUNT(*) AS n FROM till_counts WHERE status IN ('counted','queried') AND shift_date >= ?", [from]).n;
      if (unsigned) unsigned = db().get("SELECT COUNT(*) AS n FROM till_counts WHERE status IN ('counted','queried') AND (cashier_sig IS NULL OR balancer_sig IS NULL) AND shift_date >= ?", [from]).n;
    } catch (e) { /* keep the counts */ }
  }
  const shortList = from ? short.filter((c) => !c.shift_date || c.shift_date >= from) : short;
  return { waiting, shortWeek: shortList.length, shortAmount: r2(shortList.reduce((s, c) => s + c.over_short, 0)), repeat: repeatShorts(from ? { from } : {}),
    shifts, continued: shifts.filter((s) => s.status === 'continued'), lateShifts: shifts.filter((s) => s.late), eodDiff: eod.differences, eodNoTill: eod.noTill, shortages, unsigned };
}

// Cashiers short again and again (e.g. 3 times in 30 days) – worth a talk, more training or closer watching.
export function repeatShorts({ days = 30, times = 3, today = dateStr(), from: notBefore } = {}) {
  let from = addDaysLocal(today, -days);
  if (notBefore && notBefore > from) from = notBefore;
  const tol = tillRules().tolerance;
  const per = {};
  listTillCounts({ from, to: today, limit: 100000 }).filter((c) => c.status !== 'void' && c.over_short < -tol).forEach((c) => {
    const k = c.cashier_uid || c.cashier_name;
    const p = (per[k] = per[k] || { name: c.cashier_name, uid: c.cashier_uid, times: 0, amount: 0 });
    p.times += 1; p.amount = r2(p.amount + c.over_short);
  });
  return Object.values(per).filter((p) => p.times >= times).sort((a, b) => a.amount - b.amount);
}
function addDaysLocal(d, n) { const [y, m, dd] = d.split('-').map(Number); return dateStr(new Date(y, m - 1, dd + n)); }

// ---------------------------------------------------------------- safe count
// Count the cash kept at the shop (safe / office) and compare it with what the app says should be there.
// A difference is recorded; the owner / admin may book it as a correction (with a reason).
export function saveSafeCount(user, { shopCode, date, denominations, counted, note, witness }) {
  need(txt(shopCode), 'Choose the shop.');
  const d = txt(date) || dateStr();
  const c = denominations && Object.keys(denominations).length ? countDenoms(denominations) : r2(counted);
  need(c >= 0, 'Enter the cash counted.');
  const expected = cashOnHand(shopCode, d).onHand;
  const diff = r2(c - expected);
  if (Math.abs(diff) > tillRules().tolerance) need(txt(note), `The safe is ${diff > 0 ? 'over' : 'short'} by ${$(Math.abs(diff))}. Write what you think happened.`);
  const { now, dev } = meta();
  const uid = uuid('SF');
  db().run(`INSERT INTO safe_counts (uid, shop_code, count_date, denominations, counted, expected, diff, note, witness, by_name, by_uid, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, shopCode, d, JSON.stringify(denominations || {}), c, expected, diff, txt(note) || null, txt(witness) || null, user.name, user.uid, now, now, dev]);
  audit({ user, action: `Safe count ${shopCode} ${d}: ${$(c)} counted, ${$(expected)} expected (${diff ? `${diff > 0 ? 'over' : 'short'} ${$(Math.abs(diff))}` : 'right'})`, table: 'safe_counts', recordUid: uid, reason: txt(note) || null });
  if (diff < -tillRules().tolerance) notify('till_short', `Safe count ${shopCode}: SHORT ${$(-diff)} (counted ${$(c)}, should be ${$(expected)}) by ${user.name}.`, { shopCode });
  return getSafeCount(uid);
}
export function getSafeCount(uid) { return db().get('SELECT * FROM safe_counts WHERE uid = ?', [uid]); }
export function listSafeCounts({ shopCode, limit = 50 } = {}) {
  return db().all('SELECT * FROM safe_counts WHERE (? IS NULL OR shop_code = ?) ORDER BY count_date DESC, created_at DESC LIMIT ?', [shopCode || null, shopCode || null, limit]);
}
// Book the difference so cash on hand matches the safe (owner / admin, with a reason).
export function bookSafeDifference(user, uid, reason) {
  const s = getSafeCount(uid);
  need(s && !s.adjust_uid, s ? 'Already booked.' : 'Not found.');
  need(Math.abs(s.diff) > 0.004, 'There is no difference to book.');
  needReason(user, reason, 'Say why the difference is being accepted.');
  const mv = addMove({ shopCode: s.shop_code, date: s.count_date, type: s.diff > 0 ? 'adjust_in' : 'adjust_out', amount: Math.abs(s.diff), refUid: uid, note: `Safe count: ${txt(reason)}`, user });
  const { now, dev } = meta();
  db().run(`UPDATE safe_counts SET adjust_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [mv || 'booked', now, dev, uid]);
  audit({ user, action: `Booked safe difference ${$(s.diff)} at ${s.shop_code}`, table: 'safe_counts', recordUid: uid, reason: txt(reason) });
}

// Sales for a shop by day, from the till counts (the Z report figures typed in). VAT: as typed, else worked out at the standard rate.
export function dailySales({ from, to, shopCode, vatRate = 12.5 } = {}) {
  const rows = listTillCounts({ from, to, shopCode, limit: 100000 }).filter((c) => c.status !== 'void');
  const days = {};
  rows.forEach((c) => {
    const k = `${c.shift_date}|${c.shop_code}`;
    const d = (days[k] = days[k] || { date: c.shift_date, shop: c.shop_code, total: 0, cash: 0, vat: 0, zero: 0, refunds: 0, customers: 0, counts: 0, overShort: 0, tenders: {} });
    const total = Number(c.z_total) || 0;
    const zero = Number(c.z_zero_rated) || 0;
    d.total += total; d.cash += c.z_cash; d.zero += zero; d.refunds += Number(c.z_refunds) || 0; d.customers += Number(c.z_customers) || 0; d.counts += 1; d.overShort += c.over_short;
    d.vat += c.z_vat !== null && c.z_vat !== undefined ? Number(c.z_vat) : ((total - zero) * vatRate) / (100 + vatRate);
    JSON.parse(c.tenders || '[]').forEach((t) => { d.tenders[t.method] = (d.tenders[t.method] || 0) + t.amount; });
  });
  return Object.values(days).map((d) => ({ ...d, total: r2(d.total), cash: r2(d.cash), vat: r2(d.vat), zero: r2(d.zero), refunds: r2(d.refunds), overShort: r2(d.overShort) }))
    .sort((a, b) => (a.date + a.shop < b.date + b.shop ? -1 : 1));
}
