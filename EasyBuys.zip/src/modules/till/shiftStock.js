// Release 27 (owner, 14 Nov: "another part of balancing at the start and end of a shift will be the balancing of fast
// moving items, with their money value shown. This will be a major part of the Z report. If there was a replenishment of
// such stock it will reflect when balancing and a new balance will be there. The products are selected by the admin, then
// they show at the start and finish of a shift." Owner's choices: one count per SHOP (not per till); staff add the
// top-ups on the shift; money shown at BOTH selling price and cost).
//
// One record per shop per shift (shop | date | shift name):
//   opening count  → + stock added during the shift (top-ups, by whom) → − sold (Aronium receipts of the shop between
//   the opening and the closing count) = expected → closing count → difference (short / over), in money at the selling
//   price and at cost. The next shift's opening count starts from this closing count.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared } from '../../services/core.js';
import { can, actsAsOwner } from '../../services/access.js';
import { asService, requirePerm } from '../../services/guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const q3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const need = (c, m) => { if (!c) throw new AppError(m); };
const J = (s, d) => { try { const v = JSON.parse(s || ''); return v === null || v === undefined ? d : v; } catch (e) { return d; } };

export const SHIFT_STOCK_SQL = `
CREATE TABLE IF NOT EXISTS shop_shift_counts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  count_date TEXT NOT NULL,
  shift TEXT NOT NULL,
  opened_at TEXT, opened_by_uid TEXT, opened_by_name TEXT, open_counts TEXT,
  adds TEXT,
  closed_at TEXT, closed_by_uid TEXT, closed_by_name TEXT, close_counts TEXT,
  result TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_shop_shift_counts ON shop_shift_counts(shop_code, count_date);
`;
export const SHIFT_STOCK_SYNC = {
  shop_shift_counts: { key: 'uid', section: 'Till & cash', cols: ['uid', 'shop_code', 'count_date', 'shift', 'opened_at', 'opened_by_uid', 'opened_by_name', 'open_counts', 'adds', 'closed_at', 'closed_by_uid', 'closed_by_name', 'close_counts', 'result', 'note', 'status', 'updated_at', 'updated_device'] },
};
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'shop_shift_counts'"); } catch (e) { return false; } };
const isAdmin = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || can(u, 'settings'));

// ---------------------------------------------------------------- the items (chosen by the admin, per shop)
const KEY = 'shift_stock_items';
export function shiftItems(shopCode) {
  const all = getShared(KEY, {}) || {};
  const list = Array.isArray(all[shopCode]) ? all[shopCode] : [];
  return list.map((c) => itemInfo(c, shopCode)).filter(Boolean);
}
export function itemInfo(code, shopCode) {
  const it = db().get('SELECT uid, code, name, unit, cost, price FROM inv_items WHERE upper(code) = upper(?)', [txt(code)]);
  if (!it) return { code: txt(code), name: txt(code), unit: '', cost: 0, price: 0, missing: true };
  let price = Number(it.price) || 0;
  try { const s = db().get('SELECT price FROM inv_item_shops WHERE item_uid = ? AND shop_code = ? AND price IS NOT NULL', [it.uid, shopCode]); if (s && Number(s.price) > 0) price = Number(s.price); } catch (e) { /* the main price */ }
  return { code: it.code, name: it.name, unit: it.unit || '', cost: r2(it.cost), price: r2(price) };
}
export function findItems(q, limit = 30) {
  const s = `%${txt(q).toLowerCase()}%`;
  if (txt(q).length < 2) return [];
  return db().all('SELECT code, name, price, cost FROM inv_items WHERE active = 1 AND (lower(name) LIKE ? OR lower(code) LIKE ? OR barcode = ?) ORDER BY name LIMIT ?', [s, s, txt(q), limit]);
}
export function setShiftItems(user, shopCode, codes) {
  requirePerm(user, 'settings'); // checked against the real login (a forged "owner" changes nothing)
  need(isAdmin(user), 'Only the owner or an admin chooses the items counted at each shift.');
  need(txt(shopCode), 'Choose the shop.');
  const clean = Array.from(new Set((codes || []).map(txt).filter(Boolean))).slice(0, 60);
  const all = { ...(getShared(KEY, {}) || {}) };
  const before = all[shopCode] || [];
  all[shopCode] = clean;
  setShared(KEY, all);
  audit({ user, action: `Items counted at each shift (${shopCode}): ${clean.length}`, table: 'shared_settings', recordUid: KEY, before: { codes: before }, after: { codes: clean } });
  return clean;
}

// ---------------------------------------------------------------- the shop's count for a shift
const keyOf = (shopCode, date, shift) => `${shopCode}|${date}|${shift}`;
function row(uid) { return has() ? db().get('SELECT * FROM shop_shift_counts WHERE uid = ?', [uid]) : null; }
function shape(r) {
  if (!r) return null;
  return { ...r, open_counts: J(r.open_counts, {}), adds: J(r.adds, []), close_counts: J(r.close_counts, null), result: J(r.result, null) };
}
export function getCount(shopCode, date, shift) { return shape(row(keyOf(shopCode, date, shift))); }
export function getCountByUid(uid) { return shape(row(uid)); }
// The last closed count of the shop before this one: its closing numbers are where this shift starts.
export function lastClosed(shopCode, beforeUid = '') {
  if (!has()) return null;
  return shape(db().get("SELECT * FROM shop_shift_counts WHERE shop_code = ? AND status = 'closed' AND uid <> ? ORDER BY closed_at DESC LIMIT 1", [shopCode, beforeUid]));
}
const cleanCounts = (items, counts, what) => {
  const out = {};
  for (const it of items) {
    const v = counts ? counts[it.code] : undefined;
    need(v !== undefined && v !== null && txt(v) !== '' && Number.isFinite(Number(v)) && Number(v) >= 0, `Count ${it.name} (${what}).`);
    out[it.code] = q3(v);
  }
  return out;
};
export function openCount(user, { shopCode, date = dateStr(), shift, counts, note = '' } = {}) {
  return asService(() => {
    need(user, 'Log in first.');
    need(txt(shopCode) && txt(shift), 'Choose the shop and the shift.');
    const items = shiftItems(shopCode);
    need(items.length, 'No items are chosen for the shift count at this shop yet (Settings › Items counted at each shift).');
    const uid = keyOf(shopCode, date, shift);
    const cur = row(uid);
    need(!cur, `The ${shift} count at ${shopCode} was already started by ${cur ? cur.opened_by_name : ''}.`);
    const open = cleanCounts(items, counts, 'start of the shift');
    const now = stamp();
    db().run(`INSERT INTO shop_shift_counts (uid, shop_code, count_date, shift, opened_at, opened_by_uid, opened_by_name, open_counts, adds, note, status, updated_at, updated_device, sync_status)
      VALUES (?,?,?,?,?,?,?,?, '[]', ?, 'open', ?, ?, 'pending')`, [uid, shopCode, date, shift, now, user.uid, user.name, JSON.stringify(open), txt(note) || null, now, deviceId()]);
    const last = lastClosed(shopCode, uid);
    const diffs = last && last.close_counts ? items.filter((it) => last.close_counts[it.code] !== undefined && Math.abs(last.close_counts[it.code] - open[it.code]) > 0.0005).map((it) => `${it.name}: last shift closed ${last.close_counts[it.code]}, counted ${open[it.code]}`) : [];
    audit({ user, action: `Shift count started – ${shopCode} ${shift} ${date}${diffs.length ? ` (${diffs.length} different from the last close)` : ''}`, table: 'shop_shift_counts', recordUid: uid, after: { open, diffs } });
    return { count: getCount(shopCode, date, shift), diffs };
  });
}
export function addStock(user, { uid, code, qty, note = '' } = {}) {
  return asService(() => {
    need(user, 'Log in first.');
    const r = shape(row(uid));
    need(r, 'Start the shift count first.');
    need(r.status === 'open', 'This shift count is closed.');
    const it = shiftItems(r.shop_code).find((x) => x.code === txt(code));
    need(it, 'Choose the item.');
    const n = q3(qty);
    need(n > 0 && n < 100000, 'Type how many were added.');
    const adds = r.adds.concat([{ id: uuid('SA'), code: it.code, name: it.name, qty: n, by_uid: user.uid, by_name: user.name, at: stamp(), note: txt(note).slice(0, 200) }]);
    db().run("UPDATE shop_shift_counts SET adds = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [JSON.stringify(adds), stamp(), deviceId(), uid]);
    audit({ user, action: `Stock added on the shift – ${it.name} +${n} (${r.shop_code} ${r.shift})`, table: 'shop_shift_counts', recordUid: uid, after: { code: it.code, qty: n, note } });
    return getCountByUid(uid);
  });
}
export function removeAdd(user, { uid, id, reason = '' } = {}) {
  return asService(() => {
    const r = shape(row(uid));
    need(r && r.status === 'open', 'This shift count is closed.');
    const a = r.adds.find((x) => x.id === id);
    need(a, 'Not found.');
    need(a.by_uid === user.uid || isAdmin(user) || can(user, 'till_approve'), 'Only the person who added it, a manager or the admin can take it off.');
    db().run("UPDATE shop_shift_counts SET adds = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [JSON.stringify(r.adds.filter((x) => x.id !== id)), stamp(), deviceId(), uid]);
    audit({ user, action: `Stock added on the shift taken off – ${a.name} +${a.qty}`, table: 'shop_shift_counts', recordUid: uid, before: a, reason });
    return getCountByUid(uid);
  });
}

// What the shop's tills sold of each item between two moments (Aronium receipts – refunds count back).
export function soldBetween(shopCode, fromAt, toAt, codes) {
  const want = new Set((codes || []).map((c) => txt(c).toUpperCase()));
  const out = {};
  const from = String(fromAt || '').slice(0, 19);
  const to = String(toAt || stamp()).slice(0, 19);
  let d = from.slice(0, 10);
  const last = to.slice(0, 10);
  let guard = 0;
  let L = null;
  try { L = require('../aronium/link.js'); } catch (e) { return { sold: out, receipts: false }; }
  let any = false;
  while (d <= last && guard < 4) {
    let rc = [];
    try { rc = L.aroniumReceipts({ date: d, shop: shopCode }); } catch (e) { rc = []; }
    for (const r of rc) {
      const at = `${d} ${r.time}`;
      if (at < from || at > to) continue;
      if ((r.items || []).length) any = true;
      for (const l of r.items || []) {
        const k = txt(l.code).toUpperCase();
        if (!want.has(k)) continue;
        out[k] = q3((out[k] || 0) + (r.refund ? -l.qty : l.qty));
      }
    }
    d = addDays(d, 1); guard += 1;
  }
  return { sold: out, receipts: any };
}
// The balance so far (open) or at the close: per item opening + added − sold = expected; counted; difference; money.
export function balanceOf(c, closeCounts = null, at = null) {
  const items = shiftItems(c.shop_code);
  const codes = items.map((i) => i.code);
  const toAt = at || c.closed_at || stamp();
  const s = soldBetween(c.shop_code, c.opened_at, toAt, codes);
  const counted = closeCounts || c.close_counts || null;
  const lines = items.map((it) => {
    const open = Number(c.open_counts[it.code]) || 0;
    const added = q3(c.adds.filter((a) => a.code === it.code).reduce((t, a) => t + a.qty, 0));
    const sold = q3(s.sold[it.code.toUpperCase()] || 0);
    const expected = q3(open + added - sold);
    const cnt = counted && counted[it.code] !== undefined ? q3(counted[it.code]) : null;
    const diff = cnt === null ? null : q3(cnt - expected);
    return { code: it.code, name: it.name, unit: it.unit, price: it.price, cost: it.cost, open, added, sold, expected, counted: cnt, diff,
      diffSell: diff === null ? null : r2(diff * it.price), diffCost: diff === null ? null : r2(diff * it.cost),
      soldSell: r2(sold * it.price), stockSell: r2((cnt === null ? expected : cnt) * it.price), stockCost: r2((cnt === null ? expected : cnt) * it.cost) };
  });
  const sum = (k) => r2(lines.reduce((t, l) => t + (Number(l[k]) || 0), 0));
  return { lines, receipts: s.receipts, short: lines.filter((l) => l.diff !== null && l.diff < -0.0005).length, over: lines.filter((l) => l.diff !== null && l.diff > 0.0005).length,
    diffSell: sum('diffSell'), diffCost: sum('diffCost'), soldSell: sum('soldSell'), stockSell: sum('stockSell'), stockCost: sum('stockCost') };
}
export function closeCount(user, { uid, counts, note = '' } = {}) {
  return asService(() => {
    need(user, 'Log in first.');
    const c = shape(row(uid));
    need(c, 'Start the shift count first.');
    need(c.status === 'open', 'This shift count is already closed.');
    const items = shiftItems(c.shop_code);
    const close = cleanCounts(items, counts, 'end of the shift');
    const now = stamp();
    const b = balanceOf(c, close, now);
    const result = { lines: b.lines, short: b.short, over: b.over, diffSell: b.diffSell, diffCost: b.diffCost, soldSell: b.soldSell, stockSell: b.stockSell, stockCost: b.stockCost, receipts: b.receipts };
    db().run(`UPDATE shop_shift_counts SET closed_at = ?, closed_by_uid = ?, closed_by_name = ?, close_counts = ?, result = ?, note = COALESCE(?, note), status = 'closed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [now, user.uid, user.name, JSON.stringify(close), JSON.stringify(result), txt(note) || null, now, deviceId(), uid]);
    audit({ user, action: `Shift count closed – ${c.shop_code} ${c.shift} ${c.count_date}: ${b.short} short, ${b.over} over (${b.diffSell >= 0 ? '+' : ''}${b.diffSell.toFixed(2)} at selling price)`, table: 'shop_shift_counts', recordUid: uid, after: { close, diffSell: b.diffSell, diffCost: b.diffCost } });
    return getCountByUid(uid);
  });
}
// Re-open a closed count (a counting mistake): managers / admin only, with a reason.
export function reopenCount(user, { uid, reason } = {}) {
  return asService(() => {
    need(isAdmin(user) || can(user, 'till_approve'), 'Only a manager or the admin can open a closed count again.');
    requirePerm(user, 'till_approve');
    need(txt(reason), 'Write why.');
    const c = shape(row(uid));
    need(c && c.status === 'closed', 'This count is not closed.');
    db().run("UPDATE shop_shift_counts SET status = 'open', closed_at = NULL, closed_by_uid = NULL, closed_by_name = NULL, close_counts = NULL, result = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [stamp(), deviceId(), uid]);
    audit({ user, action: `Shift count opened again – ${c.shop_code} ${c.shift} ${c.count_date}`, table: 'shop_shift_counts', recordUid: uid, before: { close: c.close_counts }, reason });
    return getCountByUid(uid);
  });
}
export function listCounts({ shopCode = '', from = addDays(dateStr(), -14), to = dateStr(), limit = 100 } = {}) {
  if (!has()) return [];
  return db().all(`SELECT * FROM shop_shift_counts WHERE count_date BETWEEN ? AND ? ${shopCode ? 'AND shop_code = ?' : ''} ORDER BY COALESCE(closed_at, opened_at) DESC LIMIT ?`,
    shopCode ? [from, to, shopCode, limit] : [from, to, limit]).map(shape);
}
