// Till shifts and shortages (v3.5).
// One till balance per till per shift (2–3 shifts a day, one cashier per till per shift). A till's next shift can't
// start until the previous shift is balanced – unless the OWNER continues it: the Aronium End of day (Z number and
// total) of that shift must still be written down, and the shift stays flagged until it is counted.
// A shortage over the tolerance goes to the cashier: they agree and sign (all at once or in parts), or disagree and
// a manager decides. Agreed shortages go to the pay run by themselves (a staff charge of kind 'till_short').
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, money } from '../../services/core.js';
import { actsAsOwner, needReason, can } from '../../services/access.js';
import { notify } from '../verify/service.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const meta = () => ({ now: stamp(), dev: deviceId() });
const isOwnerish = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
const shiftNames = () => { const r = getShared('till_rules', {}) || {}; return Array.isArray(r.shifts) && r.shifts.length ? r.shifts : ['Morning', 'Afternoon', 'Night', 'Full day']; };
export const SHIFT_STATUS = { open: 'Running – not balanced yet', continued: 'Continued by the owner – still to count', counted: 'Balanced', void: 'Void' };

// The order of shifts in a day (as listed in the till rules).
export function shiftOrder(name) { const i = shiftNames().indexOf(name); return i < 0 ? 99 : i; }
const before = (a, b) => (a.shift_date !== b.shift_date ? a.shift_date < b.shift_date : shiftOrder(a.shift) < shiftOrder(b.shift));

export function getShift(uid) { return db().get('SELECT * FROM till_shifts WHERE uid = ?', [uid]); }
export function listShifts({ shopCode, tillUid, from, to, status, statuses, limit = 300 } = {}) {
  const w = ['1=1']; const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (tillUid) { w.push('till_uid = ?'); a.push(tillUid); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); } else if (statuses) { w.push(`status IN (${statuses.map(() => '?').join(',')})`); a.push(...statuses); } else w.push("status <> 'void'");
  return db().all(`SELECT * FROM till_shifts WHERE ${w.join(' AND ')} ORDER BY shift_date DESC, opened_at DESC LIMIT ?`, a.concat([limit]));
}
// Earlier shifts of this till that were started but never balanced (and not continued by the owner).
export function unbalancedBefore(tillUid, date, shift) {
  if (!tillUid) return [];
  return db().all("SELECT * FROM till_shifts WHERE till_uid = ? AND status = 'open' AND shift_date <= ?", [tillUid, date])
    .filter((s) => before(s, { shift_date: date, shift }));
}

// Start a shift on a till: the cashier and the float at the start.
export function startShift(user, { shopCode, tillUid, date, shift, cashierUid, openingFloat }) {
  need(txt(shopCode), 'Choose the shop.');
  const till = tillUid ? db().get('SELECT * FROM tills WHERE uid = ? AND active = 1', [tillUid]) : null;
  need(till && till.shop_code === shopCode, 'Choose the till.');
  const d = txt(date) || dateStr();
  need(DATE.test(d) && d <= dateStr(), 'Enter the shift date (not in the future).');
  need(txt(shift), 'Choose the shift.');
  const cashier = db().get('SELECT uid, name FROM users WHERE uid = ?', [cashierUid || '']);
  need(cashier, 'Choose the cashier on this till.');
  const dup = db().get("SELECT uid FROM till_shifts WHERE till_uid = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [till.uid, d, shift]);
  need(!dup, `${till.name} ${shift} on ${d} was already started.`);
  const counted = db().get("SELECT uid FROM till_counts WHERE till_uid = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [till.uid, d, shift]);
  need(!counted, `${till.name} ${shift} on ${d} is already balanced.`);
  const open = unbalancedBefore(till.uid, d, shift);
  if (open.length) {
    const p = open[0];
    throw new AppError(`${till.name} – ${p.shift} ${p.shift_date} (${p.cashier_name}) is not balanced yet. Balance it first${isOwnerish(user) ? ', or continue it (you need its Aronium End of day number and total).' : '. Only the owner can let the next shift start without it.'}`);
  }
  const { now, dev } = meta();
  const uid = uuid('SH');
  let fl = openingFloat === '' || openingFloat === undefined || openingFloat === null ? null : r2(openingFloat);
  if (fl === null) { try { fl = require('./service.js').openingFloat(till.uid); } catch (e) { fl = r2(till.float_amount); } }
  db().run(`INSERT INTO till_shifts (uid, shop_code, till_uid, till_name, shift_date, shift, cashier_uid, cashier_name, opening_float, opened_by_name, opened_by_uid, opened_at, status, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'open', ?,?)`, [uid, shopCode, till.uid, till.name, d, shift, cashier.uid, cashier.name, fl, user.name, user.uid, now, now, dev]);
  audit({ user, action: `Started ${till.name} ${shift} ${d} – cashier ${cashier.name}`, table: 'till_shifts', recordUid: uid });
  return getShift(uid);
}

// The owner lets the next shift start although this one is not balanced. The Aronium End of day (Z number and total)
// is written down now; the shift stays flagged until it is counted.
export function continueShift(user, uid, { zNumber, zTotal, note } = {}) {
  need(isOwnerish(user), 'Only the owner can continue a shift that is not balanced.');
  const s = getShift(uid);
  need(s && s.status === 'open', s ? 'This shift is not waiting to be balanced.' : 'Shift not found.');
  need(txt(zNumber), 'Write the Aronium End of day (Z) number of this shift.');
  need(zTotal !== '' && zTotal !== null && zTotal !== undefined && Number.isFinite(Number(zTotal)) && Number(zTotal) >= 0, 'Write the total sales on that End of day.');
  const { now, dev } = meta();
  db().run(`UPDATE till_shifts SET status = 'continued', continued_by_name = ?, continued_at = ?, continue_note = ?, eod_z_number = ?, eod_total = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [user.name, now, txt(note) || null, txt(zNumber), r2(zTotal), now, dev, uid]);
  audit({ user, action: `Continued ${s.till_name} ${s.shift} ${s.shift_date} without a count (End of day ${txt(zNumber)}, ${$(zTotal)})`, table: 'till_shifts', recordUid: uid, reason: txt(note) || null });
  try { notify('shift_continued', `${s.till_name} ${s.shift} ${s.shift_date} (${s.cashier_name}) continued by ${user.name} without a count. End of day ${txt(zNumber)}: ${$(zTotal)}. It must still be counted.`, { shopCode: s.shop_code }); } catch (e) { /* ignore */ }
  return getShift(uid);
}
export function voidShift(user, uid, reason) {
  const s = getShift(uid);
  need(s && s.status === 'open', 'Only a shift not balanced yet can be cancelled.');
  needReason(user, reason, 'Why is this shift cancelled?');
  const { now, dev } = meta();
  db().run(`UPDATE till_shifts SET status = 'void', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason) || 'Cancelled', now, dev, uid]);
  audit({ user, action: `Cancelled ${s.till_name} ${s.shift} ${s.shift_date}`, table: 'till_shifts', recordUid: uid, reason: txt(reason) || null });
}

// Called by saveTillCount: the count belongs to its shift (made if the shift was never started in the app).
export function linkCountToShift(user, count) {
  const { now, dev } = meta();
  let s = db().get("SELECT * FROM till_shifts WHERE till_uid IS ? AND shop_code = ? AND shift_date = ? AND shift = ? AND status <> 'void'", [count.till_uid || null, count.shop_code, count.shift_date, count.shift]);
  if (!s) {
    const uid = uuid('SH');
    db().run(`INSERT INTO till_shifts (uid, shop_code, till_uid, till_name, shift_date, shift, cashier_uid, cashier_name, opening_float, opened_by_name, opened_by_uid, opened_at, status, count_uid, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'counted', ?,?,?)`, [uid, count.shop_code, count.till_uid || null, count.till_name, count.shift_date, count.shift, count.cashier_uid, count.cashier_name, count.opening_float, user.name, user.uid, now, count.uid, now, dev]);
    s = getShift(uid);
  } else if (s.status !== 'counted' || s.count_uid !== count.uid) {
    db().run(`UPDATE till_shifts SET status = 'counted', count_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [count.uid, now, dev, s.uid]);
  }
  return s.uid;
}
// A till balance voided: its shift is waiting to be balanced again (still flagged if the owner had continued it).
export function unlinkCount(countUid) {
  const s = db().get("SELECT * FROM till_shifts WHERE count_uid = ? AND status = 'counted'", [countUid]);
  if (!s) return;
  const { now, dev } = meta();
  db().run(`UPDATE till_shifts SET status = ?, count_uid = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [s.continued_at ? 'continued' : 'open', now, dev, s.uid]);
}
// Shifts still to balance: running ones from earlier days and every one the owner continued.
export function shiftsToBalance(today = dateStr()) {
  return listShifts({ statuses: ['open', 'continued'], limit: 1000 }).map((s) => ({ ...s, late: s.status === 'continued' || s.shift_date < today }));
}

// ---------------------------------------------------------------- shortages
export const SHORT_STATUS = { waiting: 'Waiting for the cashier', agreed: 'Agreed – taken from pay', disagreed: 'Cashier disagrees – manager to decide', deducted: 'Manager decided – taken from pay', written_off: 'Written off', void: 'Cancelled' };
export function getShortage(uid) { return db().get('SELECT * FROM till_shortages WHERE uid = ?', [uid]); }
export function shortageForCount(countUid) { return db().get("SELECT * FROM till_shortages WHERE count_uid = ? AND status <> 'void' ORDER BY created_at DESC LIMIT 1", [countUid]); }
export function listShortages({ userUid, status, statuses, from, to, limit = 500 } = {}) {
  const w = ['1=1']; const a = [];
  if (userUid) { w.push('user_uid = ?'); a.push(userUid); }
  if (from) { w.push('shift_date >= ?'); a.push(from); }
  if (to) { w.push('shift_date <= ?'); a.push(to); }
  if (status) { w.push('status = ?'); a.push(status); } else if (statuses) { w.push(`status IN (${statuses.map(() => '?').join(',')})`); a.push(...statuses); } else w.push("status <> 'void'");
  return db().all(`SELECT * FROM till_shortages WHERE ${w.join(' AND ')} ORDER BY shift_date DESC, created_at DESC LIMIT ?`, a.concat([limit]));
}
// Shortages not decided yet (shown red in the pay run).
export function undecidedShortages({ userUid, to } = {}) {
  return listShortages({ userUid, to, statuses: ['waiting', 'disagreed'], limit: 1000 });
}
// Kept in step with the till balance (called by saveTillCount): a shortage over the tolerance waits for the cashier.
export function syncShortage(user, count, tolerance) {
  const short = count.over_short < -tolerance - 0.004 ? r2(-count.over_short) : 0;
  const cur = shortageForCount(count.uid);
  const { now, dev } = meta();
  if (!short) {
    if (cur && ['waiting', 'disagreed'].includes(cur.status)) db().run(`UPDATE till_shortages SET status = 'void', decision_note = 'Till balance changed – no shortage', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, cur.uid]);
    return null;
  }
  if (cur && ['waiting', 'disagreed'].includes(cur.status)) {
    if (Math.abs(cur.amount - short) > 0.004 || cur.user_uid !== count.cashier_uid) {
      db().run(`UPDATE till_shortages SET amount = ?, user_uid = ?, name = ?, status = 'waiting', signature = NULL, disagree_note = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [short, count.cashier_uid, count.cashier_name, now, dev, cur.uid]);
    }
    return cur.uid;
  }
  if (cur) return cur.uid; // already decided
  const uid = uuid('TS');
  db().run(`INSERT INTO till_shortages (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, by_name, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?, 'waiting', ?,?,?,?)`,
    [uid, count.uid, count.shop_code, count.shift_date, count.cashier_uid, count.cashier_name, short, user ? user.name : null, now, now, dev]);
  return uid;
}
function chargeFor(user, s, { perPay, note }) {
  const { chargeStaff } = require('../payroll/service.js');
  const c = db().get('SELECT * FROM till_counts WHERE uid = ?', [s.count_uid]) || {};
  return chargeStaff(user, { userUid: s.user_uid, amount: s.amount, perPay: perPay || s.amount, reason: `Till short ${s.shop_code} ${c.till_name || ''} ${c.shift || ''} ${s.shift_date}${note ? ` – ${note}` : ''}`.replace(/\s+/g, ' '),
    source: 'till_short', refUid: s.count_uid, shopCode: s.shop_code, date: s.shift_date });
}
function setCountShort(countUid, action, chargeUid, note) {
  const { now, dev } = meta();
  db().run(`UPDATE till_counts SET short_action = ?, short_charge_uid = ?, short_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [action, chargeUid || null, note || null, now, dev, countUid]);
}
// The cashier agrees and signs. parts: number of pay weeks to spread it over (1 = all in the next pay).
export function agreeShortage(user, uid, { signature, parts = 1 } = {}) {
  const s = getShortage(uid);
  need(s && ['waiting', 'disagreed'].includes(s.status), 'This shortage is not waiting for the cashier.');
  need(txt(signature), `${s.name} must sign to agree.`);
  const n = Math.max(1, Math.min(52, Math.round(Number(parts) || 1)));
  const per = r2(Math.ceil((s.amount / n) * 100) / 100);
  const chargeUid = chargeFor(user, s, { perPay: per, note: 'agreed by the cashier' });
  const { now, dev } = meta();
  db().run(`UPDATE till_shortages SET status = 'agreed', signature = ?, parts = ?, per_pay = ?, agreed_at = ?, charge_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [signature, n, per, now, chargeUid, now, dev, uid]);
  setCountShort(s.count_uid, 'deduct', chargeUid, n > 1 ? `Agreed by ${s.name}, ${n} parts of ${$(per)}` : `Agreed by ${s.name}`);
  audit({ user, action: `${s.name} agreed to the till shortage ${$(s.amount)} (${s.shift_date})${n > 1 ? ` in ${n} parts of ${$(per)}` : ''}`, table: 'till_shortages', recordUid: uid });
  try { require('../owed/service.js').checkCreditLimits(user); } catch (e) { /* ignore */ }
  return getShortage(uid);
}
// The cashier does not agree: it goes to a manager.
export function disagreeShortage(user, uid, { note, signature } = {}) {
  const s = getShortage(uid);
  need(s && s.status === 'waiting', 'This shortage is not waiting for the cashier.');
  need(txt(note), 'Write why the cashier does not agree.');
  const { now, dev } = meta();
  db().run(`UPDATE till_shortages SET status = 'disagreed', disagree_note = ?, signature = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(note), signature || null, now, dev, uid]);
  audit({ user, action: `${s.name} does not agree with the till shortage ${$(s.amount)} (${s.shift_date})`, table: 'till_shortages', recordUid: uid, reason: txt(note) });
  return getShortage(uid);
}
// A manager decides: take it from pay (all or part, optionally in parts) or – owner/admin – write it off.
export function decideShortage(user, uid, { action, amount, parts = 1, note } = {}) {
  const s = getShortage(uid);
  need(s && ['waiting', 'disagreed'].includes(s.status), 'This shortage is already decided.');
  need(can(user, 'till_approve'), 'Only a manager can decide a shortage.');
  need(['deduct', 'write_off'].includes(action), 'Choose: take it from pay, or write it off.');
  need(s.user_uid !== user.uid || isOwnerish(user), 'Someone else must decide your own shortage.');
  const { now, dev } = meta();
  if (action === 'write_off') {
    const rules = getShared('till_rules', {}) || {};
    need(isOwnerish(user) || rules.shortageRule === 'decide', 'Only the owner or admin can write off a shortage.');
    needReason(user, note, 'Write why the shortage is written off.');
    db().run(`UPDATE till_shortages SET status = 'written_off', decided_by_name = ?, decided_at = ?, decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [user.name, now, txt(note) || null, now, dev, uid]);
    setCountShort(s.count_uid, 'write_off', null, txt(note) || 'Written off');
  } else {
    need(s.status === 'disagreed' || isOwnerish(user), 'The cashier has not answered yet. Ask them to agree and sign, or wait until they disagree.');
    needReason(user, note, 'Write what was decided and why.');
    const amt = amount === undefined || amount === '' || amount === null ? s.amount : r2(amount);
    need(amt > 0 && amt <= s.amount + 0.004, `The amount can be up to ${$(s.amount)}.`);
    const n = Math.max(1, Math.min(52, Math.round(Number(parts) || 1)));
    const per = r2(Math.ceil((amt / n) * 100) / 100);
    const chargeUid = chargeFor(user, { ...s, amount: amt }, { perPay: per, note: `decided by ${user.name}` });
    db().run(`UPDATE till_shortages SET status = 'deducted', amount = ?, parts = ?, per_pay = ?, decided_by_name = ?, decided_at = ?, decision_note = ?, charge_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [amt, n, per, user.name, now, txt(note) || null, chargeUid, now, dev, uid]);
    setCountShort(s.count_uid, 'deduct', chargeUid, `Decided by ${user.name}`);
  }
  audit({ user, action: `Till shortage ${$(s.amount)} of ${s.name} (${s.shift_date}): ${action === 'write_off' ? 'written off' : 'taken from pay'}`, table: 'till_shortages', recordUid: uid, reason: txt(note) || null });
  return getShortage(uid);
}
// A till balance re-opened or voided: its shortage and the pay deduction are cancelled (not if already taken in pay).
export function cancelShortage(user, countUid, reason) {
  const s = shortageForCount(countUid);
  if (!s) return;
  if (s.charge_uid) {
    const { voidCharge, debtBalance } = require('../payroll/service.js');
    const d = debtBalance(s.charge_uid);
    if (d && d.status === 'active') voidCharge(user, s.charge_uid, `Till balance changed: ${txt(reason) || 'changed'}`);
  }
  const { now, dev } = meta();
  db().run(`UPDATE till_shortages SET status = 'void', decision_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [`Cancelled: ${txt(reason) || 'till balance changed'}`, now, dev, s.uid]);
}
