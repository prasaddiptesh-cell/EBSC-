// v3.9.2 Reading the Aronium Z report (End of day) from its photo.
// The photo is read on the tablet (Google ML Kit, offline). This file turns the text into the till-count fields:
// Z number, date, total sales, cash, the other payment types, VAT, zero-rated sales, refunds, voids, customers.
// Nothing is trusted blindly: every figure read is marked "check it" on the screen, the sums are tested (cash + other
// payments = total; VAT = 12.5/112.5 of the standard-rated sales) and the person counting must confirm before saving.
// Kept free of React / device code so it can be tested with sample Z reports.

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const low = (s) => String(s || '').toLowerCase();
const squash = (s) => low(s).replace(/[^a-z0-9]/g, '');

// OCR mistakes inside numbers: O→0, l/I/|→1, S→5, B→8, "," as decimal point, spaces in thousands.
function fixDigits(tok) {
  return tok.replace(/[Oo]/g, '0').replace(/[lI|]/g, '1').replace(/S/g, '5').replace(/B/g, '8');
}
// All money amounts on a line, left to right: "1,234.50", "$ 812.40", "-12.00", "(12.00)", "812,40".
export function amountsOn(line) {
  const out = [];
  const s = String(line || '').replace(/\$\s+/g, '$');
  // The number must start with a real digit and must not run on from a word ("Total 650.00" is not "l 650.00").
  const re = /(\(?-?\$?[0-9][0-9OolIS|B]{0,2}(?:[ ,][0-9OolIS|B]{3})*[.,][0-9OolIS|B]{2}\)?|\(?-?\$?[0-9][0-9OolIS|B]*[.,][0-9OolIS|B]{2}\)?)(?![0-9A-Za-z])/g;
  let m;
  while ((m = re.exec(s))) {
    let t = m[1];
    const prev = m.index > 0 ? s[m.index - 1] : ' ';
    if (/[A-Za-z0-9]/.test(prev)) continue;
    // A percentage is not money ("VAT 12.50%").
    if (s[m.index + m[0].length] === '%' || /^\s*%/.test(s.slice(m.index + m[0].length))) continue;
    const neg = /^\(.*\)$/.test(t) || /-/.test(t);
    t = fixDigits(t.replace(/[()$\-\s]/g, ''));
    // "1,234.50" → 1234.50; "812,40" → 812.40
    const dec = t.slice(-3);
    const whole = t.slice(0, -3).replace(/[,.]/g, '');
    const v = Number(`${whole}.${dec.slice(1)}`);
    if (Number.isFinite(v)) out.push(neg ? -v : v);
  }
  return out;
}
const lastAmount = (line) => { const a = amountsOn(line); return a.length ? a[a.length - 1] : null; };
const firstAmount = (line) => { const a = amountsOn(line); return a.length ? a[0] : null; };
const intOn = (line) => { const m = String(line).match(/(\d[\d,]*)\s*$/) || String(line).match(/[:#]\s*(\d[\d,]*)/); return m ? Number(m[1].replace(/,/g, '')) : null; };

// Names for the payment types of the till rules, as Aronium may print them.
const TENDER_WORDS = [
  [/m.?pa.?i?sa/i, /m\s*-?\s*pa\s*i?\s*sa|mpaisa|m-paisa|vodafone/i],
  [/my.?cash/i, /my\s*cash|mycash|digicel/i],
  [/eftpos|card/i, /eftpos|card|visa|master/i],
  [/cheque/i, /cheque|check/i],
  [/account|credit/i, /account|credit|on acc|staff/i],
  [/voucher/i, /voucher|gift/i],
];
function tenderPattern(method) {
  for (const [rule, words] of TENDER_WORDS) if (rule.test(method)) return words;
  const w = squash(method).slice(0, 6);
  return w ? new RegExp(w.split('').join('\\s*'), 'i') : null;
}

const DATE_RE = /(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})|(\d{4})-(\d{2})-(\d{2})/;
function dateOf(line) {
  const m = String(line).match(DATE_RE);
  if (!m) return null;
  if (m[4]) return `${m[4]}-${m[5]}-${m[6]}`;
  const y = m[3].length === 2 ? `20${m[3]}` : m[3];
  const d = Number(m[1]); const mo = Number(m[2]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

// text: the photo text (rows "label   amount" where possible). opts: { tenders: [names from the till rules], vatRate: 0.125 }
// → { fields: { zNumber, date, zTotal, zCash, zVat, zZeroRated, zRefunds, zVoids, zCustomers, tenders: [{ method, amount }] },
//     from: { field: 'line it came from' }, checks: [{ level: 'ok'|'warn', text }], found: n, looksLikeZ }
export function readZText(text, { tenders = [], vatRate = 0.125 } = {}) {
  const lines = String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const f = {};
  const from = {};
  const put = (k, v, line) => { if (v === null || v === undefined || (typeof v === 'number' && !Number.isFinite(v))) return; if (f[k] === undefined) { f[k] = v; from[k] = line; } };
  const totals = [];
  const tenderAmts = {};
  let inPayments = false;
  let inTax = false;
  const vatLines = [];
  lines.forEach((line, i) => {
    const l = low(line);
    const next = lines[i + 1] || '';
    // A label on one line and its amount alone on the next (happens when the photo is read in columns).
    const amt = lastAmount(line) !== null ? lastAmount(line) : (amountsOn(next).length && !/[a-z]{3}/i.test(next.replace(/[OolISB|]/g, '0')) ? lastAmount(next) : null);
    if (/payment\s*type|payments|tender|by payment/.test(l)) { inPayments = true; inTax = false; }
    if (/\btax(es)?\b|\bvat\b|tax rate/.test(l) && !/total/.test(l)) inTax = true;
    // Z number
    if (f.zNumber === undefined) {
      const zm = line.match(/\bz\s*[-#:]?\s*(?:report|rep\.?)?\s*(?:no\.?|number|#|:)?\s*[-#:]?\s*0*(\d{1,7})\b/i)
        || (/(end of day|z report|closing|document)\s*(no|number|#)/i.test(line) && line.match(/(\d{1,7})\s*$/))
        || (/^(number|no\.?|#)\s*[:#]?\s*\d+$/i.test(line) && line.match(/(\d{1,7})\s*$/));
      if (zm) put('zNumber', String(Number(zm[1])), line);
    }
    if (f.date === undefined && dateOf(line)) put('date', dateOf(line), line);
    // Payment types
    if (/^cash\b|\bcash\s*(sales|total|payments?)?\s*[:$0-9(]/i.test(line) && !/cash\s*(in|out|drawer|float|start|starting|opening|declared|counted|difference|back|rounding)|(start(ing)?|opening|float|petty|declared|counted)\s*cash/i.test(line) && amt !== null && f.zCash === undefined) { put('zCash', amt, line); inPayments = true; }
    for (const m of tenders) {
      const p = tenderPattern(m);
      if (p && p.test(line) && amt !== null && amt !== 0 && tenderAmts[m] === undefined && !/^cash\b/i.test(line)) { tenderAmts[m] = amt; from[`tender:${m}`] = line; }
    }
    // Refunds, voids, customers
    if (/refund|return/i.test(l) && amt !== null) put('zRefunds', Math.abs(amt), line);
    if (/\bvoid|cancel|deleted/i.test(l) && amt !== null) put('zVoids', Math.abs(amt), line);
    if (/customers?|receipts?\s*(count)?|no\.?\s*of\s*(sales|docs?|documents|receipts|transactions)|transactions|document count|documents?\b/i.test(l) && !/total\s*(sales|amount)/i.test(l)) {
      const n = intOn(line.replace(/\d+[.,]\d{2}/g, ''));
      if (n !== null && n < 100000) put('zCustomers', n, line);
    }
    // Tax lines: "VAT 12.5%  1,234.00  137.11" (base, tax) or "VAT 0% 250.00 0.00" (zero-rated base)
    if ((/\bvat\b|\btax\b|\bgst\b/.test(l) || (inTax && /%/.test(l))) && amountsOn(line).length) {
      const pct = (l.match(/(\d{1,2}(?:[.,]\d{1,2})?)\s*%/) || [])[1];
      vatLines.push({ line, pct: pct === undefined ? null : Number(pct.replace(',', '.')), amounts: amountsOn(line), total: /total/.test(l) });
    } else if (/zero.?rated|exempt|0\s*%/.test(l) && amt !== null) {
      vatLines.push({ line, pct: 0, amounts: amountsOn(line), total: false });
    }
    // Total sales candidates
    if (/\btotal\b|grand\s*total|net\s*sales|gross\s*sales|\bsales\b/.test(l) && amt !== null && !/tax|vat|refund|void|discount|cash\s*(in|out)|items?\s*sold|quantity|qty/.test(l)) {
      const w = /grand\s*total/.test(l) ? 4 : /total\s*sales|sales\s*total|net\s*sales/.test(l) ? 3 : inPayments && /total/.test(l) ? 2 : 1;
      totals.push({ v: amt, w, line });
    }
  });
  // VAT: the standard rate line gives the tax; a 0% line gives the zero-rated sales.
  const std = vatLines.filter((v) => v.pct !== null && v.pct > 0);
  const zero = vatLines.filter((v) => v.pct === 0 || /zero|exempt/i.test(v.line));
  const tot = vatLines.filter((v) => v.total && v.pct === null);
  if (std.length) { const v = std[0]; put('zVat', Math.abs(v.amounts[v.amounts.length - 1]), v.line); if (v.pct) f._rate = v.pct / 100; }
  else if (tot.length) put('zVat', Math.abs(tot[0].amounts[tot[0].amounts.length - 1]), tot[0].line);
  if (zero.length) put('zZeroRated', Math.abs(zero[0].amounts[0]), zero[0].line);
  const tenderList = Object.entries(tenderAmts).map(([method, amount]) => ({ method, amount: r2(amount) }));
  // Total: prefer the figure that equals cash + the other payments; else the strongest label.
  const paid = r2((f.zCash || 0) + tenderList.reduce((s, t) => s + t.amount, 0));
  const match = totals.find((t) => Math.abs(t.v - paid) < 0.02);
  const best = match || totals.sort((a, b) => b.w - a.w || b.v - a.v)[0];
  if (best) { f.zTotal = r2(best.v); from.zTotal = best.line; }
  const fields = {};
  ['zNumber', 'date', 'zTotal', 'zCash', 'zVat', 'zZeroRated', 'zRefunds', 'zVoids', 'zCustomers'].forEach((k) => { if (f[k] !== undefined) fields[k] = f[k]; });
  if (tenderList.length) fields.tenders = tenderList;
  // Checks a person should look at.
  const checks = [];
  if (fields.zTotal !== undefined && fields.zCash !== undefined) {
    const diff = r2(fields.zTotal - paid);
    checks.push(Math.abs(diff) < 0.02 ? { level: 'ok', key: 'sum', text: `Cash + other payments = total sales (${r2(paid).toFixed(2)})` }
      : { level: 'warn', key: 'sum', text: `Cash + other payments come to ${paid.toFixed(2)} but the total read is ${fields.zTotal.toFixed(2)} – a payment type may have been missed or misread.` });
  }
  if (fields.zVat !== undefined && fields.zTotal !== undefined) {
    const rate = f._rate || vatRate;
    const want = r2((fields.zTotal - (fields.zZeroRated || 0)) * rate / (1 + rate));
    checks.push(Math.abs(want - fields.zVat) <= Math.max(0.05, want * 0.02) ? { level: 'ok', key: 'vat', text: `VAT agrees with the sales (${(rate * 100).toFixed(1)}%)` }
      : { level: 'warn', key: 'vat', text: `VAT read ${fields.zVat.toFixed(2)}; on these sales it would be about ${want.toFixed(2)} – check the VAT and zero-rated figures.` });
  }
  const found = Object.keys(fields).filter((k) => k !== 'date').length + (fields.tenders ? fields.tenders.length - 1 : 0);
  const looksLikeZ = /z\s*report|end\s*of\s*day|closing|x\s*report|daily\s*report|shift\s*report/i.test(text) || found >= 3;
  return { fields, from, checks, found, looksLikeZ };
}

// Field names for the screen and the history.
export const Z_LABELS = { zNumber: 'Z report number', date: 'Date', zTotal: 'Total sales', zCash: 'CASH sales', zVat: 'VAT', zZeroRated: 'Zero-rated sales', zRefunds: 'Refunds', zVoids: 'Voids', zCustomers: 'Customers' };

// Put what was read into the form: only boxes that are empty or were filled by an earlier reading (never over what the
// person typed). Returns { form, filled: [keys] }.
export function applyZRead(form, read, prevFilled = []) {
  const out = { ...form };
  const filled = [];
  const empty = (v) => v === '' || v === null || v === undefined;
  for (const k of ['zNumber', 'zTotal', 'zCash', 'zVat', 'zZeroRated', 'zRefunds', 'zVoids', 'zCustomers']) {
    const v = read.fields[k];
    if (v === undefined) continue;
    if (empty(out[k]) || prevFilled.includes(k)) { out[k] = String(v); filled.push(k); }
  }
  if (read.fields.tenders && read.fields.tenders.length) {
    const t = (out.tenders || []).map((x) => ({ ...x }));
    for (const r of read.fields.tenders) {
      const i = t.findIndex((x) => x.method === r.method);
      const key = `tender:${r.method}`;
      if (i >= 0) { if (empty(t[i].amount) || prevFilled.includes(key)) { t[i].amount = String(r.amount); filled.push(key); } } else { t.push({ method: r.method, amount: String(r.amount) }); filled.push(key); }
    }
    out.tenders = t;
  }
  return { form: out, filled };
}
// What the person changed after the reading (kept with the count so the owner can see it).
export function zReadChanges(form, readFields) {
  const ch = [];
  for (const k of ['zNumber', 'zTotal', 'zCash', 'zVat', 'zZeroRated', 'zRefunds', 'zVoids', 'zCustomers']) {
    if (readFields[k] === undefined) continue;
    const a = String(readFields[k]); const b = String(form[k] === undefined ? '' : form[k]);
    const same = k === 'zNumber' ? a === b.trim() : Math.abs(Number(a) - Number(b)) < 0.005 && b !== '';
    if (!same) ch.push({ field: k, read: readFields[k], kept: b });
  }
  for (const r of readFields.tenders || []) {
    const t = (form.tenders || []).find((x) => x.method === r.method);
    if (!t || Math.abs(Number(t.amount) - r.amount) >= 0.005) ch.push({ field: `tender:${r.method}`, read: r.amount, kept: t ? t.amount : '' });
  }
  return ch;
}
