// Hidden face engine: a tiny invisible web page inside the app that turns a photo into a
// face fingerprint. Works with no internet (everything is packed into the app).
import React, {forwardRef, useEffect, useImperativeHandle, useRef} from 'react';
import {View} from 'react-native';
import {WebView} from 'react-native-webview';

const PAGE = 'file:///android_asset/face/index.html';
const START_TIMEOUT_MS = 90000;
const DESCRIBE_TIMEOUT_MS = 25000;

/** onStatus({state: 'loading'|'ready'|'failed', backend, message}) */
const FaceEngine = forwardRef(function FaceEngine({onStatus}, ref) {
  const web = useRef(null);
  const pending = useRef({});
  const state = useRef('loading');
  const report = (s) => { state.current = s.state; onStatus && onStatus(s); };

  useEffect(() => {
    report({state: 'loading'});
    const t = setTimeout(() => {
      if (state.current === 'loading') report({state: 'failed', message: 'The face engine took too long to start.'});
    }, START_TIMEOUT_MS);
    return () => clearTimeout(t);
  }, []);

  useImperativeHandle(ref, () => ({
    ready: () => state.current === 'ready',
    /** b64: JPEG photo. Answers {ok, descriptor, faces} or {ok: false, reason}. Never throws. */
    describe: (b64) => new Promise((resolve) => {
      if (state.current !== 'ready' || !web.current) { resolve({ok: false, reason: 'not_ready'}); return; }
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
      const timer = setTimeout(() => { delete pending.current[id]; resolve({ok: false, reason: 'timeout'}); }, DESCRIBE_TIMEOUT_MS);
      pending.current[id] = (r) => { clearTimeout(timer); resolve(r); };
      web.current.postMessage(JSON.stringify({type: 'describe', id, b64}));
    }),
  }));

  function onMessage(e) {
    let m;
    try { m = JSON.parse(e.nativeEvent.data); } catch (err) { return; }
    if (m.type === 'ready') report({state: 'ready', backend: m.backend});
    else if (m.type === 'failed') report({state: 'failed', message: m.message});
    else if (m.type === 'result' && pending.current[m.id]) {
      const done = pending.current[m.id];
      delete pending.current[m.id];
      done(m);
    }
  }

  return (
    <View pointerEvents="none" style={{position: 'absolute', left: 0, top: 0, width: 4, height: 4, opacity: 0}}>
      <WebView
        ref={web}
        source={{uri: PAGE}}
        originWhitelist={['*']}
        javaScriptEnabled
        allowFileAccess
        allowFileAccessFromFileURLs
        allowUniversalAccessFromFileURLs
        onMessage={onMessage}
        onError={(e) => report({state: 'failed', message: 'Could not open the face engine: ' + (e.nativeEvent.description || '')})}
        onRenderProcessGone={() => report({state: 'failed', message: 'The face engine stopped. Close and open the app.'})}
        style={{width: 4, height: 4}}
      />
    </View>
  );
});

export default FaceEngine;
