// Front camera for the Time Clock and face enrolment.
// ref.snap() -> { b64, uri } (small JPEG, kept in the app's storage) or null. Never throws.
import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImageManipulator from 'expo-image-manipulator';
import { Text } from '../../ui/scale.js';
import { keep } from '../../platform/photos.js';

const FrontCamera = forwardRef(function FrontCamera({ width, height }, ref) {
  const cam = useRef(null);
  const ready = useRef(false);
  const [perm, requestPerm] = useCameraPermissions();
  useEffect(() => { if (perm && !perm.granted && perm.canAskAgain) requestPerm(); }, [perm, requestPerm]);
  useImperativeHandle(ref, () => ({
    allowed: () => !!(perm && perm.granted),
    snap: async () => {
      try {
        for (let i = 0; i < 40 && !ready.current; i++) await new Promise((r) => setTimeout(r, 100));
        if (!cam.current || !ready.current) return null;
        const pic = await cam.current.takePictureAsync({ quality: 0.7 });
        const small = await ImageManipulator.manipulateAsync(pic.uri, [{ resize: { width: 480 } }],
          { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG, base64: true });
        let uri = small.uri;
        try { uri = await keep(small.uri); } catch (e) { /* keep the cache copy */ }
        return { b64: small.base64 || null, uri };
      } catch (e) {
        return null;
      }
    },
  }));
  const box = { width, height, backgroundColor: '#111', borderRadius: 16, overflow: 'hidden' };
  if (!perm) return <View style={box} />;
  if (!perm.granted) {
    return (
      <View style={[box, { alignItems: 'center', justifyContent: 'center', padding: 10 }]}>
        <Text style={{ color: '#fff', textAlign: 'center', fontSize: 15 }}>Camera not allowed.{'\n'}Allow it in Android Settings › Apps › Easy Buys.</Text>
      </View>
    );
  }
  return (
    <View style={box}>
      <CameraView ref={cam} facing="front" style={{ flex: 1 }} onCameraReady={() => { ready.current = true; }} />
    </View>
  );
});
export default FrontCamera;
