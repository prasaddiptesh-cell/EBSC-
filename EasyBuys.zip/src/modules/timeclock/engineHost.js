// One face engine for the whole app, started when the app opens, so it is ready before anyone clocks in.
// (Before, it started each time the Time Clock opened, and early punches only saved a photo.)
import React, { useEffect, useRef, useState } from 'react';
import FaceEngine from './FaceEngine.js';

let engine = null;
let status = { state: 'off' };
const listeners = new Set();
function setStatus(s) {
  status = { ...s, at: Date.now() };
  listeners.forEach((f) => f(status));
}

export function getEngine() { return engine; }
export function engineStatus() { return status; }
export function useEngineStatus() {
  const [s, set] = useState(status);
  useEffect(() => { listeners.add(set); set(status); return () => listeners.delete(set); }, []);
  return s;
}
// Wait (up to ms) for the engine to be ready. Resolves true / false.
export async function waitForEngine(ms = 30000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (status.state === 'ready' && engine && engine.ready()) return true;
    if (status.state === 'failed' || status.state === 'off') return false;
    await new Promise((r) => setTimeout(r, 250));
  }
  return false;
}

// Put this once near the top of the app. `on` = this device uses face matching.
export function FaceEngineHost({ on }) {
  const ref = useRef(null);
  const [key, setKey] = useState(0);
  useEffect(() => { if (!on) { engine = null; setStatus({ state: 'off' }); } }, [on]);
  useEffect(() => {
    // A failed engine is retried once a minute (e.g. the tablet was busy starting up).
    if (status.state !== 'failed' || !on) return undefined;
    const t = setTimeout(() => setKey((k) => k + 1), 60000);
    return () => clearTimeout(t);
  });
  if (!on) return null;
  return <FaceEngine key={key} ref={(r) => { ref.current = r; engine = r; }} onStatus={setStatus} />;
}
export function restartEngine() { setStatus({ state: 'loading' }); }
