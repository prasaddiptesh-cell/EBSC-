// Face check rules for the Time Clock (no phone parts here, so they are tested on any computer).
// The tablet turns each photo into 128 numbers (a "face fingerprint"). Two photos of the same
// person give fingerprints that are close together; the distance between them decides.

const RESULTS = ['match', 'no_match', 'no_face', 'not_enrolled', 'unavailable', 'photo_only', 'off'];
const ENROL_PHOTOS = 3;
const ENROL_SAME_PERSON = 0.6;    // enrolment photos further apart than this are probably not one person

function distance(a, b) {
  if (!a || !b || a.length !== b.length) return Infinity;
  let s = 0;
  for (let i = 0; i < a.length; i++) { const d = a[i] - b[i]; s += d * d; }
  return Math.sqrt(s);
}

/** Closest distance between a new fingerprint and any of the enrolled ones. */
function bestDistance(descriptor, enrolled) {
  let best = Infinity;
  (enrolled || []).forEach((e) => { best = Math.min(best, distance(descriptor, e)); });
  return best;
}

const usesCamera = (mode) => mode !== 'off';
const usesMatching = (mode) => mode === 'flag' || mode === 'block';

/**
 * Decide the face result for one punch.
 * detection: the engine's answer {ok, descriptor, reason} or null if the engine is not ready.
 */
function decide({mode, limit, enrolled, engineReady, detection, photoTaken}) {
  if (mode === 'off') return {result: 'off', distance: null};
  if (mode === 'photo') return {result: photoTaken ? 'photo_only' : 'unavailable', distance: null};
  if (!photoTaken) return {result: 'unavailable', distance: null};
  if (!enrolled || !enrolled.length) return {result: 'not_enrolled', distance: null};
  if (!engineReady || !detection) return {result: 'unavailable', distance: null};
  if (!detection.ok) return {result: detection.reason === 'no_face' ? 'no_face' : 'unavailable', distance: null};
  const d = bestDistance(detection.descriptor, enrolled);
  return {result: d <= limit ? 'match' : 'no_match', distance: Math.round(d * 1000) / 1000};
}

/** In "block" mode only a clear mismatch (or no face) stops the punch. Problems on the tablet never lock staff out. */
function isBlocked(mode, result) {
  return mode === 'block' && (result === 'no_match' || result === 'no_face');
}

function resultMessage(result) {
  return {
    match: 'Face matched',
    no_match: 'Face did not match',
    no_face: 'No face seen - look at the camera',
    not_enrolled: 'Face not enrolled yet - ask the manager',
    unavailable: 'Face check not available - punch saved with PIN',
    photo_only: 'Photo saved',
    off: '',
  }[result] || '';
}

/** Enrolment photos must all look like the same person. Returns '' when fine. */
function checkEnrolment(descriptors) {
  if (!descriptors.length) return 'Take the photos first.';
  for (let i = 0; i < descriptors.length; i++) {
    for (let j = i + 1; j < descriptors.length; j++) {
      if (distance(descriptors[i], descriptors[j]) > ENROL_SAME_PERSON) {
        return 'The photos do not look like the same person. Start again with only this person in front of the camera.';
      }
    }
  }
  return '';
}

/** Smaller numbers to send (4 decimals is plenty). */
function compact(descriptor) {
  return Array.from(descriptor).map((x) => Math.round(x * 10000) / 10000);
}

export {RESULTS, ENROL_PHOTOS, distance, bestDistance, usesCamera, usesMatching, decide, isBlocked, resultMessage, checkEnrolment, compact};
