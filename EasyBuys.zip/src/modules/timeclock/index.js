// Time Clock module: staff Clock IN/OUT and breaks on the tablet (PIN + face check), offline.
import { ClockRulesScreen } from '../admin/screens/AdminScreens.js';
import { can } from '../../services/access.js';

export default {
  id: 'timeclock',
  title: 'Time Clock',
  icon: '⏱️',
  switchable: true,
  screens: {
    ClockRules: { component: ClockRulesScreen, can: (u) => can(u, 'settings') },
  },
  reports: [],
};
