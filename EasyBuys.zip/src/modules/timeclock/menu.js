// Time Clock menu (the Time Clock itself opens from Home or the login screen).
export const MENU = [
  { section: 'Settings', items: [
    { id: 'home', icon: '⏱️', title: 'Time Clock rules', note: 'Breaks, rounding, face check, late tolerance.', screen: 'ClockRules' },
    { id: 'tc-facetest', icon: '🙂', title: 'Test the face check', screen: 'FaceTest' },
  ] },
];
