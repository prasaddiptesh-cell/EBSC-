// Time Clock rules and face check settings. Shared by every device; the admin changes them
// in Admin > Time Clock rules. Defaults are Easy Buys' starting values.
import { getShared, setShared, audit, AppError } from '../../services/core.js';

export const CLOCK_DEFAULTS = {
  breakMode: 'buttons',      // 'buttons' = staff clock breaks, 'auto' = fixed break taken off, 'none'
  autoBreakMinutes: 30,      // used when breakMode = 'auto'
  autoBreakAfterHours: 5,    // ...for shifts longer than this
  roundMinutes: 0,           // 0 = exact times; 5, 10 or 15 = round to nearest
  graceMinutes: 5,           // late arrivals within this are not flagged (used with rosters)
  maxShiftHours: 16,         // a Clock In with no Clock Out after this is "missing Clock Out"
  doubleTapMinutes: 2,       // a second tap of the same button within this is ignored
  longShiftHours: 12,        // flag shifts longer than this
  noBreakAfterHours: 5,      // flag shifts longer than this without a break (breakMode 'buttons')
  showAllShops: true,        // the one tablet shows staff of every shop
};
export const FACE_DEFAULTS = {
  mode: 'flag',              // 'off' | 'photo' | 'flag' | 'block'
  threshold: 0.5,            // lower = stricter
  keepPhotoDays: 60,
};

export function clockRules() {
  return { ...CLOCK_DEFAULTS, ...(getShared('clock_rules', {}) || {}) };
}
export function faceSettings() {
  return { ...FACE_DEFAULTS, ...(getShared('face_settings', {}) || {}) };
}

const num = (v, lo, hi, label) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < lo || n > hi) throw new AppError(`${label} must be between ${lo} and ${hi}.`);
  return n;
};

export function saveClockRules(user, r) {
  if (!['buttons', 'auto', 'none'].includes(r.breakMode)) throw new AppError('Choose how breaks work.');
  if (![0, 5, 10, 15].includes(Number(r.roundMinutes))) throw new AppError('Rounding must be none, 5, 10 or 15 minutes.');
  const clean = {
    breakMode: r.breakMode,
    autoBreakMinutes: num(r.autoBreakMinutes, 0, 120, 'Automatic break'),
    autoBreakAfterHours: num(r.autoBreakAfterHours, 0, 12, 'Automatic break after'),
    roundMinutes: Number(r.roundMinutes),
    graceMinutes: num(r.graceMinutes, 0, 60, 'Grace period'),
    maxShiftHours: num(r.maxShiftHours, 8, 24, 'Longest possible shift'),
    doubleTapMinutes: num(r.doubleTapMinutes, 0, 30, 'Double-tap time'),
    longShiftHours: num(r.longShiftHours, 6, 24, 'Long shift warning'),
    noBreakAfterHours: num(r.noBreakAfterHours, 2, 12, 'No-break warning'),
    showAllShops: !!r.showAllShops,
  };
  const before = clockRules();
  setShared('clock_rules', clean);
  audit({ user, action: 'Changed Time Clock rules', table: 'shared_settings', recordUid: 'clock_rules', before, after: clean });
  return clean;
}

export function saveFaceSettings(user, f) {
  if (!['off', 'photo', 'flag', 'block'].includes(f.mode)) throw new AppError('Choose a face check setting.');
  const clean = {
    mode: f.mode,
    threshold: num(f.threshold, 0.3, 0.8, 'Strictness'),
    keepPhotoDays: Math.round(num(f.keepPhotoDays, 7, 400, 'Keep photos (days)')),
  };
  const before = faceSettings();
  setShared('face_settings', clean);
  audit({ user, action: 'Changed face check settings', table: 'shared_settings', recordUid: 'face_settings', before, after: clean });
  return clean;
}
