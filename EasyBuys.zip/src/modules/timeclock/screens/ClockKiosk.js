// The Time Clock on the shop tablet. No login: staff tap their name, look at the camera,
// enter their PIN and tap Clock IN / OUT / Break. Works with no internet.
import React, { useEffect, useRef, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, PinPad, Btn, Chips, Banner, Grid, useLayout, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { clock, hhmm, getSetting } from '../../../services/core.js';
import { db } from '../../../db/connection.js';
import { clockStaff, checkStaffPin, allowedTypes, punch, TYPE_LABEL, stateOf, voidPunch } from '../service.js';
import { personWeek, hm } from '../../timesheets/service.js';
import { plannedFor as rosterFor, rosterSettings } from '../../timesheets/roster.js';
import { setPunchReason } from '../service.js';
import { whoIsOff, balances } from '../../leave/service.js';
import { dateStr as todayStr, addDays as addDaysK } from '../../../services/core.js';
import { clockRules, faceSettings } from '../rules.js';
import { decide, isBlocked, resultMessage, usesCamera, usesMatching } from '../face.js';
import { getEngine, useEngineStatus, waitForEngine } from '../engineHost.js';
import FrontCamera from '../camera.js';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const BTN = { IN: ['success', '🟢'], OUT: ['danger', '🔴'], BREAK_START: ['warn', '☕'], BREAK_END: ['info', '↩️'] };

const ampm = (t) => { if (!t) return ''; const [h, m] = t.slice(11, 16).split(':').map(Number); return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'pm' : 'am'}`; };
const ampmHHMM = (t) => (t ? ampm(`2000-01-01 ${t}`) : '');
const initials = (n) => String(n || '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');
function minsSince(at, now) { return Math.max(0, Math.round((now - new Date(at.replace(' ', 'T'))) / 60000)); }
function dur(m) { return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, '0')}`; }

// Everything the board shows about one person: state, since when, today and week hours, roster, late, leave.
function personInfo(p, now, offToday) {
  const today = todayStr(now);
  const w = personWeek(p.uid, today);
  const todayMin = w.shifts.filter((x) => x.date === today).reduce((a, x) => a + x.workedMinutes, 0) + (p.state !== 'out' && p.since ? 0 : 0);
  const openMin = p.state === 'in' && p.since ? minsSince(p.since, now) : 0;
  const ro = rosterFor(p.uid, today);
  const nowHM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const onLeave = offToday.some((l) => l.user_uid === p.uid);
  let line1 = 'Out';
  let tone = 'out';
  if (p.state === 'in') { line1 = `In since ${ampm(p.since)}`; tone = 'in'; }
  else if (p.state === 'break') { line1 = `On break · ${dur(minsSince(p.since, now))}`; tone = 'break'; }
  else if (onLeave) line1 = 'On leave today';
  else if (ro && nowHM > ro.start && nowHM < ro.end && !w.shifts.some((x) => x.date === today)) { line1 = `Late · due ${ampmHHMM(ro.start)}`; tone = 'late'; }
  else if (ro && nowHM <= ro.start) line1 = `Out · starts ${ampmHHMM(ro.start)}`;
  const line2 = p.state === 'out' ? (p.last && p.last.type === 'OUT' ? `Left ${ampm(p.last.at)}${p.last.at.slice(0, 10) !== today ? ' (earlier day)' : ''}` : '')
    : `${dur(todayMin + openMin)} today · ${hm(w.totalMinutes + openMin)} h week`;
  return { line1, line2, tone, week: w, todayMin: todayMin + openMin, ro };
}
const TONE = { in: [C.success, C.successSoft], break: [C.warn, C.warnSoft], late: [C.danger, C.dangerSoft], out: [C.sub, '#F2EEEA'] };

export default function ClockKiosk({ onExit }) {
  useTick(15000);
  const rules = clockRules();
  const face = faceSettings();
  const { isPhone } = useLayout();
  const [shop, setShop] = useState(getSetting('device_shop', '') || 'ALL');
  const [person, setPerson] = useState(null);
  const engine = useEngineStatus();
  const [done, setDone] = useState(null);
  useEffect(() => {
    if (!done) return undefined;
    const t = setTimeout(() => setDone(null), done.ask ? 20000 : 8000);
    return () => clearTimeout(t);
  }, [done]);

  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const staff = clockStaff({ shopCode: shop === 'ALL' ? null : shop });
  const inNow = staff.filter((p) => p.state === 'in').length;
  const onBreak = staff.filter((p) => p.state === 'break').length;
  const now = clock.now();
  const off = whoIsOff(todayStr(now));
  const late = staff.filter((p) => personInfo(p, now, off).tone === 'late').length;


  if (person) {
    return (
      <>
        <PinStep person={person} face={face} engine={engine}
          onCancel={() => setPerson(null)}
          onDone={(r) => { setPerson(null); setDone(r); }} />
      </>
    );
  }
  return (
    <Screen title="Time Clock" subtitle={`${DAYS[now.getDay()]} ${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`} hideUser
      onBack={onExit} right={<Text testID="clock-time" style={{ fontSize: isPhone ? 24 : 32, fontWeight: '900', color: C.text, marginRight: 4 }}>{String(now.getHours()).padStart(2, '0')}:{String(now.getMinutes()).padStart(2, '0')}</Text>}>
      {done ? <DonePanel done={done} onClose={() => setDone(null)} /> : null}
      <Text style={{ fontSize: 17, color: C.sub, fontWeight: '700' }}>Tap your name, then your PIN. In now: {inNow}{onBreak ? ` · On break: ${onBreak}` : ''}{late ? ` · Late: ${late}` : ''}{off.length ? ` · On leave: ${off.length}` : ''}</Text>
      {rules.showAllShops ? (
        <Chips value={shop} onChange={setShop} testIDPrefix="clock-shop"
          options={[{ value: 'ALL', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      ) : null}
      {usesMatching(face.mode) && engine.state === 'failed' ? (
        <Banner tone="warn" title="Face check not working on this tablet" message="Clock in with your PIN as normal. Tell the manager." />
      ) : null}
      {!staff.length ? <Banner tone="info" title="No staff here yet" message="The manager adds staff and PINs in Staff." /> : null}
      <Grid cols={isPhone ? 2 : undefined}>
        {staff.map((p) => {
          const info = personInfo(p, now, off);
          const [fg, bg] = TONE[info.tone];
          return (
            <Pressable key={p.uid} testID={`clock-person-${p.employee_no || p.uid}`} onPress={() => setPerson(p)}
              style={({ pressed }) => ({ minHeight: 104, borderRadius: 18, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card,
                borderWidth: 3, borderColor: info.tone === 'out' ? C.border : fg, opacity: pressed ? 0.7 : 1 })}>
              <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontSize: 20, fontWeight: '900', color: fg }}>{initials(p.name)}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }} numberOfLines={1}>{p.name}</Text>
                <Text testID={`clock-status-${p.employee_no || p.uid}`} style={{ fontSize: 15, fontWeight: '800', color: fg }} numberOfLines={1}>{info.line1}</Text>
                {info.line2 ? <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={1}>{info.line2}</Text> : null}
                {!p.hasPin ? <Text style={{ fontSize: 13, color: C.danger }}>No PIN yet – see the manager</Text> : null}
              </View>
            </Pressable>
          );
        })}
      </Grid>
    </Screen>
  );
}

function PinStep({ person, face, engine, onCancel, onDone }) {
  const { isPhone, width } = useLayout();
  const [pin, setPin] = useState('');
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');
  const tries = useRef(0);
  const camera = useRef(null);
  const withCamera = usesCamera(face.mode);
  const state = stateOf(person.uid).state;

  const tryPin = (p) => {
    setError('');
    try {
      const u = checkStaffPin(person.uid, p);
      setUser(u);
    } catch (e) {
      setPin('');
      setError(e.message);
    }
  };
  const onPin = (v) => {
    setPin(v);
    setError('');
    if (v.length >= 4 && v.length === person.pinLength) tryPin(v);
  };

  const go = async (type) => {
    if (busy) return;
    let fr = { result: 'off', distance: null, photoUri: null };
    if (withCamera) {
      setBusy('Checking face…');
      const shot = camera.current ? await camera.current.snap() : null;
      // The engine starts with the app; if it is still starting, wait for it rather than skip the check.
      if (usesMatching(face.mode) && person.faceList) { setBusy('Face check starting…'); await waitForEngine(30000); setBusy('Checking face…'); }
      const eng = getEngine();
      const ready = !!(eng && eng.ready && eng.ready());
      let detection = null;
      if (shot && usesMatching(face.mode) && person.faceList && ready) detection = await eng.describe(shot.b64);
      const d = decide({ mode: face.mode, limit: face.threshold, enrolled: person.faceList, engineReady: ready, detection, photoTaken: !!shot });
      setBusy('');
      if (isBlocked(face.mode, d.result)) {
        tries.current += 1;
        setError(tries.current >= 3 ? `${resultMessage(d.result)}. Please see the manager - they can add your time.` : `${resultMessage(d.result)}. Look straight at the camera and try again.`);
        return;
      }
      fr = { result: d.result, distance: d.distance, photoUri: shot ? shot.uri : null };
    }
    const r = punch({ user, type, face: fr });
    if (!r.ok) { setError(r.message); return; }
    const note = ['match', 'off', 'photo_only'].includes(fr.result) ? '' : resultMessage(fr.result);
    const w = personWeek(person.uid, todayStr());
    const ro = rosterFor(person.uid, todayStr());
    let timing = '';
    let ask = null;
    const lateAfter = rosterSettings().lateReasonAfter;
    if (ro && type === 'IN') { const diff = Math.round((new Date(`2000-01-01T${r.time}`) - new Date(`2000-01-01T${ro.start}`)) / 60000); timing = diff > 0 ? `${diff} min late (rostered ${ampmHHMM(ro.start)})` : `On time${diff < 0 ? ` – ${-diff} min early` : ''}`; if (lateAfter && diff > lateAfter) ask = 'late'; }
    if (ro && type === 'OUT') { const early = Math.round((new Date(`2000-01-01T${ro.end}`) - new Date(`2000-01-01T${r.time}`)) / 60000); if (early > 0 && early < 600) { timing = `${early} min before the rostered finish (${ampmHHMM(ro.end)})`; if (lateAfter && early > lateAfter) ask = 'early'; } }
    let leaveLeft = null;
    try { const b = balances(person.uid).find((x) => x.type === 'ANNUAL'); leaveLeft = b ? b.left : null; } catch (e) { leaveLeft = null; }
    onDone({
      tone: r.warning || note ? 'warn' : 'success', punchUid: r.uid, person, type,
      title: `Bula, ${person.name.split(' ')[0]}!`, action: `${TYPE_LABEL[type]} at ${ampmHHMM(r.time)}`,
      message: [r.warning, note].filter(Boolean).join('\n') || null, timing,
      roster: ro ? `${ampmHHMM(ro.start)} – ${ampmHHMM(ro.end)}` : null, week: hm(w.totalMinutes), leaveLeft, ask,
      days: Array.from({ length: 7 }, (_, i) => { const d = addDaysK(w.weekStart, i); const m = w.shifts.filter((x) => x.date === d).reduce((a, x) => a + x.workedMinutes, 0); return { d, m, today: d === todayStr() }; }),
    });
  };

  const camW = isPhone ? Math.min(260, width - 40) : 300;
  return (
    <Screen title={person.name} subtitle={user ? 'Choose what you are doing' : 'Enter your PIN'} hideUser onBack={onCancel}>
      <View style={{ flexDirection: isPhone ? 'column' : 'row', gap: 16, alignItems: isPhone ? 'center' : 'flex-start', justifyContent: 'center' }}>
        {withCamera ? (
          <View style={{ alignItems: 'center', gap: 6 }}>
            <FrontCamera ref={camera} width={camW} height={isPhone ? camW * 0.9 : 380} />
            <Text style={{ fontSize: 15, color: C.sub }}>{usesMatching(face.mode) ? 'Look at the camera' : 'A photo is taken when you clock'}</Text>
            {usesMatching(face.mode) && !person.faceList ? <Text style={{ fontSize: 14, color: C.warn }}>Face not enrolled yet</Text> : null}
            {usesMatching(face.mode) && engine.state === 'loading' ? <Text style={{ fontSize: 14, color: C.sub }}>Face check starting…</Text> : null}
          </View>
        ) : null}
        <View style={{ flex: isPhone ? undefined : 1, width: isPhone ? '100%' : undefined, maxWidth: 460, gap: 12 }}>
          {error ? <Banner testID="clock-error" tone="danger" message={error} /> : null}
          {!user ? (
            <>
              <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14 }}>
                {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
                  <View key={i} style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: i < pin.length ? C.primary : C.border }} />
                ))}
              </View>
              <PinPad value={pin} onChange={onPin} />
              <Btn testID="clock-pin-ok" title="OK" icon="✔️" onPress={() => tryPin(pin)} disabled={pin.length < 4} />
            </>
          ) : busy ? (
            <Banner tone="info" title={busy} message="Hold still for a moment." />
          ) : (
            allowedTypes(state).map((t) => (
              <Btn key={t} testID={`clock-${t}`} title={TYPE_LABEL[t]} icon={BTN[t][1]} variant={BTN[t][0]} onPress={() => go(t)} />
            ))
          )}
          <Btn title="Cancel" variant="secondary" size="md" onPress={onCancel} />
        </View>
      </View>
    </Screen>
  );
}

const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
// Late in / early out: one tap to say why (the manager sees it on the timesheet). Nobody is stopped from clocking.
const REASONS = { late: ['Transport / bus', 'Sick', 'Family', 'Swapped shift', 'Manager said OK', 'Other'], early: ['Sick', 'Family', 'Manager said OK', 'Finished the work', 'Swapped shift', 'Other'] };
function ReasonChips({ done, onClose }) {
  const [saved, setSaved] = useState(null);
  if (saved) return <Text style={{ fontSize: 17, color: C.white, fontWeight: '800' }}>Thank you – "{saved}" noted.</Text>;
  return (
    <View style={{ gap: 6, marginTop: 6 }}>
      <Text style={{ fontSize: 17, color: C.white, fontWeight: '800' }}>{done.ask === 'late' ? 'Why late today?' : 'Why leaving early?'} (tap one)</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {REASONS[done.ask].map((r) => (
          <Pressable key={r} testID={`reason-${r}`} onPress={() => { try { setPunchReason(done.punchUid, `${done.ask === 'late' ? 'Late' : 'Left early'}: ${r}`); } catch (e) { /* ignore */ } setSaved(r); }}
            style={{ backgroundColor: C.white, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{r}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
// The big welcome after clocking: who, what, when, and how the week looks. "Not me" undoes it.
function DonePanel({ done, onClose }) {
  const { isPhone } = useLayout();
  const good = done.tone === 'success';
  const bg = good ? C.success : C.warn;
  return (
    <View testID="clock-done" style={{ backgroundColor: bg, borderRadius: 22, padding: isPhone ? 16 : 26, flexDirection: isPhone ? 'column' : 'row', gap: 18 }}>
      <View style={{ flex: 3, gap: 6 }}>
        <Text style={{ fontSize: 22, color: '#E8FBEF', fontWeight: '700' }}>{done.title}</Text>
        <Text style={{ fontSize: isPhone ? 34 : 46, color: C.white, fontWeight: '900' }}>{done.action}</Text>
        {done.timing ? <Text style={{ fontSize: 19, color: C.white, fontWeight: '700' }}>{done.timing}</Text> : null}
        {done.message ? <Text style={{ fontSize: 17, color: C.white }}>{done.message}</Text> : null}
        {done.ask ? <ReasonChips done={done} onClose={onClose} /> : null}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 8 }}>
          {done.roster ? <View style={{ backgroundColor: 'rgba(0,0,0,0.18)', borderRadius: 12, padding: 10 }}><Text style={{ color: '#E8FBEF', fontSize: 13 }}>Rostered today</Text><Text style={{ color: C.white, fontSize: 19, fontWeight: '800' }}>{done.roster}</Text></View> : null}
          <View style={{ backgroundColor: 'rgba(0,0,0,0.18)', borderRadius: 12, padding: 10 }}><Text style={{ color: '#E8FBEF', fontSize: 13 }}>This week so far</Text><Text style={{ color: C.white, fontSize: 19, fontWeight: '800' }}>{done.week} h</Text></View>
          {done.leaveLeft !== null && done.leaveLeft !== undefined ? <View style={{ backgroundColor: 'rgba(0,0,0,0.18)', borderRadius: 12, padding: 10 }}><Text style={{ color: '#E8FBEF', fontSize: 13 }}>Annual leave left</Text><Text style={{ color: C.white, fontSize: 19, fontWeight: '800' }}>{done.leaveLeft} days</Text></View> : null}
        </View>
      </View>
      <View style={{ flex: 2, backgroundColor: C.white, borderRadius: 16, padding: 12, gap: 8 }}>
        <View style={{ flexDirection: 'row', gap: 4 }}>
          {done.days.map((x) => (
            <View key={x.d} style={{ flex: 1, alignItems: 'center', borderRadius: 8, paddingVertical: 6, backgroundColor: x.today ? C.primaryDark : x.m ? C.successSoft : '#F2EEEA' }}>
              <Text style={{ fontSize: 12, fontWeight: '800', color: x.today ? C.white : C.sub }}>{WD[new Date(`${x.d}T00:00:00`).getDay()]}</Text>
              <Text style={{ fontSize: 13, fontWeight: '800', color: x.today ? C.white : C.text }}>{x.m ? hm(x.m) : x.today ? 'now' : '–'}</Text>
            </View>
          ))}
        </View>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Btn testID="clock-undo" title="Not me – undo" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { try { voidPunch(done.person, done.punchUid, 'Wrong person – undone at the Time Clock'); } catch (e) { /* already changed */ } onClose(); }} />
          <Btn testID="clock-done-ok" title="Done" size="md" variant="primary" style={{ flex: 1 }} onPress={onClose} />
        </View>
      </View>
    </View>
  );
}
