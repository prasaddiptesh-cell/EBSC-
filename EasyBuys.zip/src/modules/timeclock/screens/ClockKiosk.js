// The Time Clock on the shop tablet. No login: staff tap their name, look at the camera,
// enter their PIN and tap Clock IN / OUT / Break. Works with no internet.
import React, { useEffect, useRef, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, PinPad, Btn, Chips, Banner, Grid, useLayout, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { clock, hhmm, getSetting } from '../../../services/core.js';
import { db } from '../../../db/connection.js';
import { clockStaff, checkStaffPin, allowedTypes, punch, TYPE_LABEL, stateOf } from '../service.js';
import { clockRules, faceSettings } from '../rules.js';
import { decide, isBlocked, resultMessage, usesCamera, usesMatching } from '../face.js';
import FaceEngine from '../FaceEngine.js';
import FrontCamera from '../camera.js';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const BTN = { IN: ['success', '🟢'], OUT: ['danger', '🔴'], BREAK_START: ['warn', '☕'], BREAK_END: ['info', '↩️'] };

function StatusText({ p }) {
  if (p.state === 'in') return <Text style={{ fontSize: 15, color: C.success, fontWeight: '800' }}>In since {hhmm(p.since)}</Text>;
  if (p.state === 'break') return <Text style={{ fontSize: 15, color: C.warn, fontWeight: '800' }}>On break since {hhmm(p.since)}</Text>;
  return <Text style={{ fontSize: 15, color: C.sub }}>Out</Text>;
}

export default function ClockKiosk({ onExit }) {
  useTick(15000);
  const rules = clockRules();
  const face = faceSettings();
  const { isPhone } = useLayout();
  const [shop, setShop] = useState(getSetting('device_shop', '') || 'ALL');
  const [person, setPerson] = useState(null);
  const [engine, setEngine] = useState({ state: 'off' });
  const engineRef = useRef(null);
  const [done, setDone] = useState(null);
  useEffect(() => {
    if (!done) return undefined;
    const t = setTimeout(() => setDone(null), 5000);
    return () => clearTimeout(t);
  }, [done]);

  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const staff = clockStaff({ shopCode: shop === 'ALL' ? null : shop });
  const inNow = staff.filter((p) => p.state === 'in').length;
  const onBreak = staff.filter((p) => p.state === 'break').length;
  const now = clock.now();

  const engineEl = usesMatching(face.mode) ? <FaceEngine ref={engineRef} onStatus={setEngine} /> : null;

  if (person) {
    return (
      <>
        {engineEl}
        <PinStep person={person} face={face} engineRef={engineRef} engine={engine}
          onCancel={() => setPerson(null)}
          onDone={(r) => { setPerson(null); setDone(r); }} />
      </>
    );
  }
  return (
    <Screen title="Time Clock" subtitle={`${DAYS[now.getDay()]} ${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`} hideUser
      onBack={onExit} right={<Text testID="clock-time" style={{ fontSize: isPhone ? 24 : 32, fontWeight: '900', color: C.text, marginRight: 4 }}>{String(now.getHours()).padStart(2, '0')}:{String(now.getMinutes()).padStart(2, '0')}</Text>}>
      {engineEl}
      {done ? <Banner testID="clock-done" tone={done.tone} title={done.title} message={done.message} /> : null}
      <Text style={{ fontSize: 17, color: C.sub, fontWeight: '700' }}>Tap your name. In now: {inNow}{onBreak ? ` · On break: ${onBreak}` : ''}</Text>
      {rules.showAllShops ? (
        <Chips value={shop} onChange={setShop} testIDPrefix="clock-shop"
          options={[{ value: 'ALL', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      ) : null}
      {usesMatching(face.mode) && engine.state === 'failed' ? (
        <Banner tone="warn" title="Face check not working on this tablet" message="Clock in with your PIN as normal. Tell the manager." />
      ) : null}
      {!staff.length ? <Banner tone="info" title="No staff here yet" message="The manager adds staff and PINs in Staff." /> : null}
      <Grid cols={isPhone ? 2 : undefined}>
        {staff.map((p) => (
          <Pressable key={p.uid} testID={`clock-person-${p.employee_no || p.uid}`} onPress={() => setPerson(p)}
            style={({ pressed }) => ({ minHeight: 104, borderRadius: 18, padding: 14, justifyContent: 'center', backgroundColor: C.card,
              borderWidth: 3, borderColor: p.state === 'in' ? C.success : p.state === 'break' ? C.warn : C.border, opacity: pressed ? 0.7 : 1 })}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }} numberOfLines={2}>{p.name}</Text>
            <StatusText p={p} />
            {!p.hasPin ? <Text style={{ fontSize: 13, color: C.danger }}>No PIN yet</Text> : null}
          </Pressable>
        ))}
      </Grid>
    </Screen>
  );
}

function PinStep({ person, face, engineRef, engine, onCancel, onDone }) {
  const { isPhone, width } = useLayout();
  const [pin, setPin] = useState('');
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');
  const tries = useRef(0);
  const camera = useRef(null);
  const withCamera = usesCamera(face.mode);
  const state = stateOf(person.uid).state;

  const tryPin = (p) => {
    setError('');
    try {
      const u = checkStaffPin(person.uid, p);
      setUser(u);
    } catch (e) {
      setPin('');
      setError(e.message);
    }
  };
  const onPin = (v) => {
    setPin(v);
    setError('');
    if (v.length >= 4 && v.length === person.pinLength) tryPin(v);
  };

  const go = async (type) => {
    if (busy) return;
    let fr = { result: 'off', distance: null, photoUri: null };
    if (withCamera) {
      setBusy('Checking face…');
      const shot = camera.current ? await camera.current.snap() : null;
      const eng = engineRef.current;
      const ready = !!(eng && eng.ready && eng.ready());
      let detection = null;
      if (shot && usesMatching(face.mode) && person.faceList && ready) detection = await eng.describe(shot.b64);
      const d = decide({ mode: face.mode, limit: face.threshold, enrolled: person.faceList, engineReady: ready, detection, photoTaken: !!shot });
      setBusy('');
      if (isBlocked(face.mode, d.result)) {
        tries.current += 1;
        setError(tries.current >= 3 ? `${resultMessage(d.result)}. Please see the manager - they can add your time.` : `${resultMessage(d.result)}. Look straight at the camera and try again.`);
        return;
      }
      fr = { result: d.result, distance: d.distance, photoUri: shot ? shot.uri : null };
    }
    const r = punch({ user, type, face: fr });
    if (!r.ok) { setError(r.message); return; }
    const note = ['match', 'off', 'photo_only'].includes(fr.result) ? '' : resultMessage(fr.result);
    onDone({
      tone: r.warning || note ? 'warn' : 'success',
      title: `Bula ${person.name.split(' ')[0]}! ${TYPE_LABEL[type]} at ${r.time}`,
      message: [r.warning, note].filter(Boolean).join('\n') || null,
    });
  };

  const camW = isPhone ? Math.min(260, width - 40) : 300;
  return (
    <Screen title={person.name} subtitle={user ? 'Choose what you are doing' : 'Enter your PIN'} hideUser onBack={onCancel}>
      <View style={{ flexDirection: isPhone ? 'column' : 'row', gap: 16, alignItems: isPhone ? 'center' : 'flex-start', justifyContent: 'center' }}>
        {withCamera ? (
          <View style={{ alignItems: 'center', gap: 6 }}>
            <FrontCamera ref={camera} width={camW} height={isPhone ? camW * 0.9 : 380} />
            <Text style={{ fontSize: 15, color: C.sub }}>{usesMatching(face.mode) ? 'Look at the camera' : 'A photo is taken when you clock'}</Text>
            {usesMatching(face.mode) && !person.faceList ? <Text style={{ fontSize: 14, color: C.warn }}>Face not enrolled yet</Text> : null}
            {usesMatching(face.mode) && engine.state === 'loading' ? <Text style={{ fontSize: 14, color: C.sub }}>Face check starting…</Text> : null}
          </View>
        ) : null}
        <View style={{ flex: isPhone ? undefined : 1, width: isPhone ? '100%' : undefined, maxWidth: 460, gap: 12 }}>
          {error ? <Banner testID="clock-error" tone="danger" message={error} /> : null}
          {!user ? (
            <>
              <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14 }}>
                {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
                  <View key={i} style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: i < pin.length ? C.primary : C.border }} />
                ))}
              </View>
              <PinPad value={pin} onChange={onPin} />
              <Btn testID="clock-pin-ok" title="OK" icon="✔️" onPress={() => tryPin(pin)} disabled={pin.length < 4} />
            </>
          ) : busy ? (
            <Banner tone="info" title={busy} message="Hold still for a moment." />
          ) : (
            allowedTypes(state).map((t) => (
              <Btn key={t} testID={`clock-${t}`} title={TYPE_LABEL[t]} icon={BTN[t][1]} variant={BTN[t][0]} onPress={() => go(t)} />
            ))
          )}
          <Btn title="Cancel" variant="secondary" size="md" onPress={onCancel} />
        </View>
      </View>
    </Screen>
  );
}
