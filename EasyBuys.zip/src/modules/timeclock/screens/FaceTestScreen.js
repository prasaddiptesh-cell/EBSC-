// Face check test: shows exactly what the face engine is doing on this tablet, and who a test photo matches.
import React, { useRef, useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Row, useApp, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { PhotoStrip } from '../../../ui/photoView.js';
import { db } from '../../../db/connection.js';
import FrontCamera from '../camera.js';
import { getEngine, useEngineStatus, restartEngine } from '../engineHost.js';
import { faceSettings } from '../rules.js';
import { distance } from '../face.js';

export default function FaceTestScreen() {
  const { nav } = useApp();
  const { isPhone, width } = useLayout();
  const engine = useEngineStatus();
  const face = faceSettings();
  const camera = useRef(null);
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const enrolled = db().all("SELECT uid, name, face FROM users WHERE active = 1 AND face IS NOT NULL AND face <> ''");
  const notEnrolled = db().all("SELECT name FROM users WHERE active = 1 AND uses_clock = 1 AND (face IS NULL OR face = '') AND sync_status <> 'seed'");

  const test = async () => {
    setBusy(true);
    const t0 = Date.now();
    const shot = camera.current ? await camera.current.snap() : null;
    if (!shot) { setRes({ error: 'The camera did not give a photo. Check Android Settings › Apps › Easy Buys › Camera is allowed.' }); setBusy(false); return; }
    const eng = getEngine();
    if (!eng || !eng.ready()) { setRes({ error: `The face engine is not ready (${engine.state}${engine.message ? `: ${engine.message}` : ''}).`, photo: shot.uri }); setBusy(false); return; }
    const r = await eng.describe(shot.b64);
    const ms = Date.now() - t0;
    if (!r.ok) { setRes({ error: r.reason === 'no_face' ? 'No face found in the photo. Face the light, come closer.' : `Engine answer: ${r.reason}${r.message ? ` – ${r.message}` : ''}`, photo: shot.uri, ms }); setBusy(false); return; }
    const scores = enrolled.map((u) => {
      let list = [];
      try { list = JSON.parse(u.face); } catch (e) { list = []; }
      const d = Math.min(...list.map((x) => distance(r.descriptor, x)));
      return { name: u.name, d: Math.round(d * 1000) / 1000 };
    }).sort((a, b) => a.d - b.d);
    setRes({ faces: r.faces, scores, ms, photo: shot.uri });
    setBusy(false);
  };

  const w = isPhone ? Math.min(300, width - 40) : 320;
  const stateText = { off: 'Off on this device', loading: 'Starting…', ready: 'Ready', failed: 'NOT WORKING' }[engine.state] || engine.state;
  return (
    <Screen title="Face check test" subtitle="See what the face check does on this tablet">
      <Card tone={engine.state === 'ready' ? 'success' : engine.state === 'failed' ? 'danger' : 'warn'}>
        <Row label="Face check mode" value={{ off: 'Off', photo: 'Photo only (no matching)', flag: 'Check and flag', block: 'Check and block' }[face.mode]} />
        <Row label="Face engine" value={stateText} bold color={engine.state === 'ready' ? C.success : engine.state === 'failed' ? C.danger : C.warn} />
        {engine.backend ? <Row label="Runs on" value={engine.backend === 'webgl' ? 'Graphics chip (fast)' : 'Processor (slower)'} /> : null}
        {engine.message ? <Text style={{ fontSize: 15, color: C.danger, marginTop: 6 }}>{engine.message}</Text> : null}
        <Row label="Match limit (lower = stricter)" value={String(face.threshold)} />
        <Row label="Staff with faces enrolled" value={String(enrolled.length)} />
        {notEnrolled.length ? <Text style={{ fontSize: 15, color: C.warn, marginTop: 6 }}>Not enrolled yet (their clock-ins only save a photo): {notEnrolled.map((u) => u.name).join(', ')}</Text> : null}
        {face.mode === 'photo' || face.mode === 'off' ? <Banner tone="warn" message="Matching is off. Change the mode to 'Check and flag' in Time Clock rules." /> : null}
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
          {engine.state === 'failed' ? <Btn title="Try starting it again" size="md" variant="warn" onPress={restartEngine} /> : null}
          <Btn title="Staff & face enrolment" size="md" variant="secondary" onPress={() => nav.push('Users')} />
        </View>
      </Card>
      <View style={{ alignItems: 'center', gap: 10 }}>
        <FrontCamera ref={camera} width={w} height={w * 1.2} />
        <Btn testID="face-test" title={busy ? 'Checking…' : 'Take a test photo'} icon="📷" onPress={test} disabled={busy} />
      </View>
      {res ? (
        <Card tone={res.error ? 'danger' : 'info'}>
          <H>Result{res.ms ? ` (${(res.ms / 1000).toFixed(1)} s)` : ''}</H>
          {res.error ? <Text style={{ fontSize: 17, color: C.danger }}>{res.error}</Text> : null}
          {res.faces ? <Row label="Faces in the photo" value={String(res.faces)} /> : null}
          {(res.scores || []).slice(0, 5).map((s, i) => (
            <Row key={s.name} label={`${i === 0 ? 'Closest: ' : ''}${s.name}`} value={`${s.d} ${s.d <= face.threshold ? '✓ match' : '✗ no'}`} color={s.d <= face.threshold ? C.success : C.sub} bold={i === 0} />
          ))}
          {res.scores && !res.scores.length ? <Text style={{ fontSize: 16, color: C.warn }}>The face was read correctly, but nobody is enrolled yet to compare with.</Text> : null}
          {res.photo ? <PhotoStrip photos={[{ uri: res.photo, caption: 'Test photo' }]} size={90} /> : null}
        </Card>
      ) : null}
    </Screen>
  );
}
