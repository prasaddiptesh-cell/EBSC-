// Time Clock: Clock In / Out and breaks. Works with no internet: punches are saved on the
// tablet and shared through the cloud. A wrong punch is never deleted - it is voided with a reason.
import { db } from '../../db/connection.js';
import {
  AppError, stamp, uuid, deviceId, deviceName, audit, parseStamp, clock, hhmm,
} from '../../services/core.js';
import { clockRules } from './rules.js';
import { addPhotos } from '../../services/stock.js';

export const TYPE_LABEL = { IN: 'Clock IN', OUT: 'Clock OUT', BREAK_START: 'Break start', BREAK_END: 'Break end' };

// Staff who use the Time Clock (optionally one shop), with where they are right now.
export function clockStaff({ shopCode } = {}) {
  const people = db().all(
    `SELECT id, uid, name, role, employee_no, shop_code, face, pin FROM users
     WHERE active = 1 AND uses_clock = 1 ${shopCode ? 'AND shop_code = ?' : ''} ORDER BY name`,
    shopCode ? [shopCode] : []
  );
  return people.map((p) => ({ ...p, hasPin: !!p.pin, pinLength: p.pin ? String(p.pin).length : 0, pin: undefined, faceList: parseFace(p.face), face: undefined, ...stateOf(p.uid) }));
}

export function parseFace(text) {
  try {
    const a = JSON.parse(text || 'null');
    return Array.isArray(a) && a.length ? a : null;
  } catch (e) {
    return null;
  }
}

function lastPunches(userUid, n = 1) {
  return db().all('SELECT * FROM punches WHERE user_uid = ? AND voided = 0 ORDER BY at DESC, recorded_at DESC LIMIT ?', [userUid, n]);
}

// 'out' | 'in' | 'break', plus since when.
export function stateOf(userUid, now = clock.now()) {
  const [last] = lastPunches(userUid);
  if (!last) return { state: 'out', since: null, last: null };
  const hours = (now - parseStamp(last.at)) / 3600000;
  const rules = clockRules();
  if (last.type === 'OUT' || hours > rules.maxShiftHours) return { state: 'out', since: last.type === 'OUT' ? last.at : null, last };
  if (last.type === 'BREAK_START') return { state: 'break', since: last.at, last };
  return { state: 'in', since: last.type === 'IN' ? last.at : inSince(userUid), last };
}
function inSince(userUid) {
  const r = db().get("SELECT at FROM punches WHERE user_uid = ? AND voided = 0 AND type = 'IN' ORDER BY at DESC LIMIT 1", [userUid]);
  return r ? r.at : null;
}

// Which buttons make sense right now.
export function allowedTypes(state) {
  if (state === 'in') return ['OUT', 'BREAK_START'];
  if (state === 'break') return ['BREAK_END', 'OUT'];
  return ['IN'];
}

// Check a punch before saving. Returns { ok, message, warning }.
export function checkPunch(userUid, type, at = stamp()) {
  const rules = clockRules();
  const [last] = lastPunches(userUid);
  if (last && last.type === type) {
    const mins = (parseStamp(at) - parseStamp(last.at)) / 60000;
    if (mins >= 0 && mins < rules.doubleTapMinutes) return { ok: false, duplicate: true, message: `Already done at ${hhmm(last.at)}.` };
  }
  const { state } = stateOf(userUid, parseStamp(at));
  if (!allowedTypes(state).includes(type)) {
    const msg = {
      in: `Already clocked IN at ${last ? hhmm(last.at) : '?'}. Did you mean Clock OUT?`,
      break: 'You are on a break. Tap "Break end" first (or Clock OUT).',
      out: type === 'OUT' ? 'You are not clocked in. Tap Clock IN.' : 'Clock IN first.',
    }[state];
    return { ok: false, message: msg };
  }
  let warning = null;
  if (type === 'IN' && last && last.type === 'IN') warning = `No Clock OUT was recorded after ${last.at.slice(0, 16)}. The manager will fix it.`;
  return { ok: true, warning };
}

/**
 * Save a punch from the Time Clock.
 * face: { result, distance, photoUri } from the face check (optional).
 */
export function punch({ user, type, face = null, shopCode = null, at = null }) {
  if (!user || !user.uid) throw new AppError('Choose your name first.');
  if (!TYPE_LABEL[type]) throw new AppError('Unknown button.');
  const when = at || stamp();
  const check = checkPunch(user.uid, type, when);
  if (!check.ok) return check;
  const uid = uuid('P');
  const now = stamp();
  db().run(
    `INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, face_result, face_distance, photo_uri,
      updated_at, updated_device, sync_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [uid, user.uid, user.name, type, when, now, shopCode || user.shop_code || null, deviceName(), face && face.result && face.result !== 'off' ? 'pin+face' : 'pin',
      face ? face.result || null : null, face && face.distance !== undefined ? face.distance : null, face ? face.photoUri || null : null, now, deviceId()]
  );
  if (face && face.photoUri) addPhotos('punch', uid, [face.photoUri]); // uploaded to Drive when online
  return { ok: true, uid, type, time: hhmm(when), warning: check.warning };
}

// Manager: add a missing punch. A reason is required and kept forever.
export function addManualPunch(byUser, { userUid, type, at, reason }) {
  if (!String(reason || '').trim()) throw new AppError('Please give a reason (e.g. forgot to clock out, left 5pm).');
  if (!TYPE_LABEL[type]) throw new AppError('Choose In, Out or a break.');
  const t = parseStamp(at);
  if (!t) throw new AppError('Enter the date and time as YYYY-MM-DD HH:MM.');
  if (t > clock.now()) throw new AppError('That time is in the future.');
  const person = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  if (!person) throw new AppError('Staff member not found.');
  const when = stamp(t);
  const uid = uuid('P');
  const now = stamp();
  db().run(
    `INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, reason, created_by_uid, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'manual', ?, ?, ?, ?, 'pending')`,
    [uid, userUid, person.name, type, when, now, person.shop_code, deviceName(), String(reason).trim(), byUser ? byUser.uid : null, now, deviceId()]
  );
  audit({ user: byUser, action: `Added ${TYPE_LABEL[type]} for ${person.name}`, table: 'punches', recordUid: uid, after: { type, at: when }, reason });
  return uid;
}

// Manager: cancel a wrong punch (kept, marked void, with the reason).
export function voidPunch(byUser, punchUid, reason) {
  if (!String(reason || '').trim()) throw new AppError('Please give a reason.');
  const p = db().get('SELECT * FROM punches WHERE uid = ?', [punchUid]);
  if (!p) throw new AppError('Punch not found.');
  if (p.voided) throw new AppError('Already cancelled.');
  const now = stamp();
  db().run(`UPDATE punches SET voided = 1, void_reason = ?, voided_by_uid = ?, voided_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [String(reason).trim(), byUser ? byUser.uid : null, now, now, deviceId(), punchUid]);
  audit({ user: byUser, action: `Cancelled ${TYPE_LABEL[p.type]} for ${p.name}`, table: 'punches', recordUid: punchUid, before: { type: p.type, at: p.at }, reason });
}

// Manager: change a punch time = cancel the old one and add the right one (both kept).
export function changePunchTime(byUser, punchUid, newAt, reason) {
  const p = db().get('SELECT * FROM punches WHERE uid = ?', [punchUid]);
  if (!p) throw new AppError('Punch not found.');
  return db().transaction(() => {
    voidPunch(byUser, punchUid, `Time changed: ${reason}`);
    return addManualPunch(byUser, { userUid: p.user_uid, type: p.type, at: newAt, reason });
  });
}

export function listPunches({ userUid, from, to, includeVoided = true } = {}) {
  const where = [];
  const args = [];
  if (userUid) { where.push('user_uid = ?'); args.push(userUid); }
  if (from) { where.push('at >= ?'); args.push(`${from} 00:00:00`); }
  if (to) { where.push('at <= ?'); args.push(`${to} 23:59:59`); }
  if (!includeVoided) where.push('voided = 0');
  return db().all(`SELECT * FROM punches ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY at, recorded_at`, args);
}

// Who is in right now, across all shops.
export function whoIsIn() {
  return clockStaff().filter((p) => p.state !== 'out');
}

// The face numbers saved for someone (3 photos at enrolment). Manager PIN checked by the screen.
export function saveFace(byUser, userUid, descriptors) {
  if (!Array.isArray(descriptors) || !descriptors.length || descriptors.length > 5) throw new AppError('Take 1 to 5 face photos.');
  const clean = descriptors.map((d) => {
    if (!Array.isArray(d) || d.length !== 128 || d.some((x) => !Number.isFinite(Number(x)))) throw new AppError('Face data not recognised. Try again.');
    return d.map((x) => Math.round(Number(x) * 10000) / 10000);
  });
  const person = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  if (!person) throw new AppError('Staff member not found.');
  const now = stamp();
  db().run(`UPDATE users SET face = ?, face_at = ?, face_by = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [JSON.stringify(clean), now, byUser ? byUser.name : null, now, deviceId(), userUid]);
  audit({ user: byUser, action: `Enrolled face for ${person.name}`, table: 'users', recordUid: userUid, after: { photos: clean.length } });
}
export function removeFace(byUser, userUid) {
  const person = db().get('SELECT * FROM users WHERE uid = ?', [userUid]);
  if (!person) throw new AppError('Staff member not found.');
  const now = stamp();
  db().run(`UPDATE users SET face = NULL, face_at = NULL, face_by = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, deviceId(), userUid]);
  audit({ user: byUser, action: `Removed face for ${person.name}`, table: 'users', recordUid: userUid });
}

// PIN check at the Time Clock (works offline). 5 wrong tries locks that person for 5 minutes.
const pinFails = {};
export function checkStaffPin(userUid, pin) {
  const f = pinFails[userUid] || { n: 0, until: 0 };
  const now = clock.now().getTime();
  if (f.until > now) throw new AppError(`Too many wrong PINs. Try again in ${Math.ceil((f.until - now) / 60000)} min or see the manager.`);
  const u = db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [userUid]);
  if (!u) throw new AppError('Name not found.');
  if (!u.pin) throw new AppError('No PIN set yet. Ask the manager to set your PIN.');
  if (String(pin) !== String(u.pin)) {
    f.n += 1;
    if (f.n >= 5) { f.n = 0; f.until = now + 5 * 60000; }
    pinFails[userUid] = f;
    throw new AppError(f.until > now ? 'Wrong PIN. Locked for 5 minutes.' : `Wrong PIN. ${5 - f.n} tries left.`);
  }
  delete pinFails[userUid];
  return u;
}

// The reason a person gave at the Time Clock for being late or leaving early (shown on the timesheet).
export function setPunchReason(punchUid, reason) {
  const r = String(reason || '').trim();
  if (!r) return;
  db().run(`UPDATE punches SET reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r, stamp(), deviceId(), punchUid]);
}
