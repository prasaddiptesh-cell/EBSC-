// v3.9.5 What a person's day was, when it was not a normal working day: Day off, Leave, Sick (with a sick sheet = paid
// sick leave from the balance; without = unpaid, recorded as absent "sick, no sheet") or Absent (unpaid, reason needed).
// Set by tapping the day on the roster, or when the app asks "Absent?" for someone rostered who has not clocked in.
// Staff do not have the app on their phones: leave is asked in person and a manager enters it here.
// The pay run takes it by itself (paid leave and paid sick days; unpaid days come off a salary), and the absence
// record shows each person's days by month and year.
import { db } from '../../db/connection.js';
import { AppError, stamp, deviceId, audit, dateStr, addDays } from '../../services/core.js';
import { can } from '../../services/access.js';
import { addPhotos } from '../../services/stock.js';
import { requirePerm, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });

export const ABSENCE_SQL = `
CREATE TABLE IF NOT EXISTS roster_marks (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT,
  mark_date TEXT NOT NULL,
  kind TEXT NOT NULL,
  reason TEXT,
  sheet INTEGER NOT NULL DEFAULT 0,
  paid INTEGER NOT NULL DEFAULT 0,
  leave_uid TEXT,
  leave_type TEXT,
  by_name TEXT, by_uid TEXT, at TEXT,
  removed INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_roster_marks_date ON roster_marks(mark_date);
CREATE TABLE IF NOT EXISTS day_notes (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT,
  note_date TEXT NOT NULL,
  note TEXT,
  by_name TEXT, by_uid TEXT, at TEXT,
  removed INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_day_notes_date ON day_notes(note_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const ABSENCE_SYNC = {
  roster_marks: SYNC('uid', 'Roster', ['uid', 'user_uid', 'name', 'mark_date', 'kind', 'reason', 'sheet', 'paid', 'leave_uid', 'leave_type', 'by_name', 'by_uid', 'at', 'removed']),
  day_notes: SYNC('uid', 'Roster', ['uid', 'user_uid', 'name', 'note_date', 'note', 'by_name', 'by_uid', 'at', 'removed']),
};

// Release 21 (owner, 14 Nov: "there should be a comment that is internal for each day – optional, appears if a button is
// pressed"): one internal note per person per day, for managers / payroll only (not on the payslip, not shown to staff).
const hasNotes = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'day_notes'"); } catch (e) { return false; } };
export function dayNote(userUid, date) {
  if (!hasNotes()) return null;
  return db().get('SELECT * FROM day_notes WHERE uid = ? AND removed = 0', [`${userUid}|${date}`]) || null;
}
export function dayNotesBetween(from, to) {
  if (!hasNotes()) return {};
  return Object.fromEntries(db().all('SELECT * FROM day_notes WHERE removed = 0 AND note_date BETWEEN ? AND ?', [from, to]).map((r) => [`${r.user_uid}|${r.note_date}`, r]));
}
export function saveDayNote(user, { userUid, date, note }) {
  requirePerm(user, 'timesheets_edit');
  return asService(() => {
    need(okUser(user), 'Only a manager, payroll or the owner can write this.');
    need(/^\d{4}-\d{2}-\d{2}$/.test(txt(date)), 'Choose the day.');
    const person = db().get('SELECT uid, name FROM users WHERE uid = ?', [userUid]);
    need(person, 'Staff member not found.');
    const t = txt(note).slice(0, 1000);
    const uid = `${userUid}|${date}`;
    const before = dayNote(userUid, date);
    const { now, dev } = meta();
    if (!t) {
      if (before) db().run("UPDATE day_notes SET removed = 1, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, dev, uid]);
      audit({ user, action: `${person.name} ${date}: internal note removed`, table: 'day_notes', recordUid: uid, before });
      return null;
    }
    db().run(`INSERT INTO day_notes (uid, user_uid, name, note_date, note, by_name, by_uid, at, removed, updated_at, updated_device, sync_status) VALUES (?,?,?,?,?,?,?,?,0,?,?,'pending')
      ON CONFLICT(uid) DO UPDATE SET note = excluded.note, by_name = excluded.by_name, by_uid = excluded.by_uid, at = excluded.at, removed = 0, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [uid, userUid, person.name, date, t, user.name, user.uid, now, now, dev]);
    audit({ user, action: `${person.name} ${date}: internal note`, table: 'day_notes', recordUid: uid, before, after: { note: t } });
    return dayNote(userUid, date);
  });
}

export const MARK_LABEL = { work: 'Work', off: 'Day off', leave: 'Leave', sick: 'Sick', absent: 'Absent' };
export const ABSENT_REASONS = ['No call, no show', 'Family', 'Transport', 'Sick, no sheet', 'Late – sent home', 'Other'];
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'roster_marks'"); } catch (e) { return false; } };
const okUser = (u) => can(u, 'timesheets_edit') || can(u, 'leave_approve');

export function markOf(userUid, date) {
  if (!has()) return null;
  return db().get('SELECT * FROM roster_marks WHERE uid = ? AND removed = 0', [`${userUid}|${date}`]) || null;
}
// "user|date" → mark, for the roster grid and the pay run.
export function marksBetween(from, to, { userUid } = {}) {
  if (!has()) return {};
  const rows = db().all('SELECT * FROM roster_marks WHERE removed = 0 AND mark_date BETWEEN ? AND ? AND (? IS NULL OR user_uid = ?)', [from, to, userUid || null, userUid || null]);
  return Object.fromEntries(rows.map((r) => [`${r.user_uid}|${r.mark_date}`, r]));
}
// Unpaid days (absent, or sick without a sheet) of a person in a period – for the pay run.
export function unpaidDays(userUid, from, to) {
  return Object.values(marksBetween(from, to, { userUid })).filter((m) => !m.paid && (m.kind === 'absent' || m.kind === 'sick'));
}

// Mark a day. kind: work (clears the mark) | off | leave | sick | absent.
//   leave: { leaveType } (ANNUAL by default) – entered and approved at once (the person asked in person).
//   sick:  { sheet: true, photos } = paid sick leave (SICK, approved); { sheet: false } = unpaid, absent "sick, no sheet".
//   absent: { reason } required.
// Release 20 (owner, 14 Nov: "if sick then with sick sheet or not, and a button to say if they are going to get paid"):
//   sick: { sheet, paid } – paid defaults to "with a sheet"; a sheet without pay and pay without a sheet are allowed.
export function markDay(user, { userUid, date, kind, reason, sheet = false, paid: paidAsked, photos = [], leaveType } = {}) {
  requirePerm(user, 'timesheets_edit'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(okUser(user), 'Only a manager, payroll or the owner can change this.');
  need(MARK_LABEL[kind], 'Choose Work, Day off, Leave, Sick or Absent.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(txt(date)), 'Choose the day.');
  const person = db().get('SELECT uid, name FROM users WHERE uid = ?', [userUid]);
  need(person, 'Staff member not found.');
  need(person.uid !== user.uid || kind === 'work' || ['owner', 'admin'].includes(user.role), 'Someone else marks your own day.');
  const L = require('../leave/service.js');
  const before = markOf(userUid, date);
  // Leave made for an earlier mark of this day is cancelled first (the day changed).
  if (before && before.leave_uid) {
    try {
      const lr = db().get('SELECT status FROM leave_requests WHERE uid = ?', [before.leave_uid]);
      if (lr && ['requested', 'approved'].includes(lr.status)) L.cancelLeave(user, before.leave_uid, `Roster: day changed to ${MARK_LABEL[kind]}`);
    } catch (e) { /* the leave stays; the mark below is still right */ }
  }
  const { now, dev } = meta();
  const uid = `${userUid}|${date}`;
  if (kind === 'work') {
    if (before) db().run("UPDATE roster_marks SET removed = 1, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, dev, uid]);
    audit({ user, action: `${person.name} ${date}: working`, table: 'roster_marks', recordUid: uid, before });
    return null;
  }
  let leaveUid = null;
  let paid = 0;
  let type = null;
  let why = txt(reason);
  if (kind === 'leave') {
    type = txt(leaveType) || 'ANNUAL';
    const t = db().get('SELECT * FROM leave_types WHERE code = ?', [type]);
    need(t, 'Choose the type of leave.');
    leaveUid = L.requestLeave(user, { userUid, type, from: date, to: date, reason: why || 'Entered on the roster', managerEntry: true });
    L.decideLeave(user, leaveUid, true, 'Entered on the roster');
    paid = t.paid ? 1 : 0;
    why = why || t.name;
  } else if (kind === 'sick') {
    if (sheet) need(photos && photos.length, 'Take a photo of the sick sheet (medical certificate).');
    const payIt = paidAsked === undefined ? !!sheet : !!paidAsked;
    if (payIt) {
      type = 'SICK';
      leaveUid = L.requestLeave(user, { userUid, type: 'SICK', from: date, to: date, reason: why || (sheet ? 'Sick – sheet given' : 'Sick – paid without a sheet'), photoUri: photos && photos[0], managerEntry: true });
      L.decideLeave(user, leaveUid, true, sheet ? 'Sick sheet given' : 'Paid sick day (no sheet)');
      if (photos && photos.length) { try { addPhotos('leave', leaveUid, photos); } catch (e) { /* the first photo is on the leave already */ } }
      paid = 1;
      why = why || (sheet ? 'Sick – sheet given, paid' : 'Sick, no sheet – paid');
    } else {
      why = why ? `Sick, ${sheet ? 'sheet given' : 'no sheet'}, not paid – ${why}` : `Sick, ${sheet ? 'sheet given' : 'no sheet'}, not paid`;
    }
  } else if (kind === 'absent') {
    need(why, 'Choose or write the reason.');
  }
  db().run(`INSERT INTO roster_marks (uid, user_uid, name, mark_date, kind, reason, sheet, paid, leave_uid, leave_type, by_name, by_uid, at, removed, updated_at, updated_device, sync_status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?, 'pending')
    ON CONFLICT(uid) DO UPDATE SET kind=excluded.kind, reason=excluded.reason, sheet=excluded.sheet, paid=excluded.paid, leave_uid=excluded.leave_uid, leave_type=excluded.leave_type,
      by_name=excluded.by_name, by_uid=excluded.by_uid, at=excluded.at, removed=0, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [uid, userUid, person.name, date, kind, why || null, sheet ? 1 : 0, paid, leaveUid, type, user.name, user.uid, now, now, dev]);
  // A day off, leave, sick or absent day has no shift: the planned shift of that day is taken off the roster.
  try {
    const R = require('./roster.js');
    R.shiftsFor({ userUid, date }).forEach((s) => R.removeShift(user, s.uid));
  } catch (e) { /* roster planner not in use */ }
  audit({ user, action: `${person.name} ${date}: ${MARK_LABEL[kind]}${why ? ` – ${why}` : ''}${kind === 'sick' ? (sheet ? ' (paid)' : ' (unpaid)') : ''}`, table: 'roster_marks', recordUid: uid, before });
  return markOf(userUid, date);
  });
}

// People rostered today who have not clocked in 30 minutes after their start, with no mark and no leave:
// the supervisor is asked "Absent?".
export function notClockedIn(now = new Date(), { graceMin = 30 } = {}) {
  if (!has()) return [];
  const today = dateStr(now);
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const R = require('./roster.js');
  let users = [];
  try { users = db().all("SELECT uid, name, shop_code FROM users WHERE active = 1 AND IFNULL(uses_clock, 1) = 1 AND IFNULL(sync_status, '') <> 'seed' AND role NOT IN ('owner')"); } catch (e) { users = []; }
  const marks = marksBetween(today, today);
  const out = [];
  for (const u of users) {
    if (marks[`${u.uid}|${today}`]) continue;
    let plan = null;
    try { plan = R.plannedFor(u.uid, today); } catch (e) { plan = null; }
    if (!plan || !plan.start) continue;
    const [h, m] = plan.start.split(':').map(Number);
    const due = h * 60 + m + graceMin;
    const [nh, nm] = hhmm.split(':').map(Number);
    if (nh * 60 + nm < due) continue;
    if (plan.end && plan.end > plan.start && hhmm > plan.end) continue; // the shift is over: the day's record is made in the absence list
    const inToday = db().get("SELECT 1 AS x FROM punches WHERE user_uid = ? AND voided = 0 AND type = 'IN' AND substr(at, 1, 10) = ?", [u.uid, today]);
    if (inToday) continue;
    const onLeave = db().get("SELECT 1 AS x FROM leave_requests WHERE user_uid = ? AND status = 'approved' AND from_date <= ? AND to_date >= ?", [u.uid, today, today]);
    if (onLeave) continue;
    out.push({ uid: u.uid, name: u.name, shop: plan.shop || u.shop_code, start: plan.start, end: plan.end });
  }
  return out;
}

// Each person's absence record: absent, sick with / without a sheet, leave, days off – by month or year.
export function absenceRecord({ from, to, userUid } = {}) {
  if (!has()) return [];
  const rows = db().all('SELECT * FROM roster_marks WHERE removed = 0 AND mark_date BETWEEN ? AND ? AND (? IS NULL OR user_uid = ?) ORDER BY name, mark_date', [from, to, userUid || null, userUid || null]);
  const by = {};
  for (const r of rows) {
    const p = by[r.user_uid] || (by[r.user_uid] = { userUid: r.user_uid, name: r.name, absent: 0, sickPaid: 0, sickUnpaid: 0, leave: 0, off: 0, unpaid: 0, days: [] });
    if (r.kind === 'absent') p.absent += 1;
    if (r.kind === 'sick' && r.sheet) p.sickPaid += 1;
    if (r.kind === 'sick' && !r.sheet) p.sickUnpaid += 1;
    if (r.kind === 'leave') p.leave += 1;
    if (r.kind === 'off') p.off += 1;
    if (!r.paid && (r.kind === 'absent' || r.kind === 'sick')) p.unpaid += 1;
    p.days.push({ date: r.mark_date, kind: r.kind, reason: r.reason, paid: !!r.paid });
  }
  return Object.values(by).sort((a, b) => b.unpaid - a.unpaid || String(a.name).localeCompare(String(b.name)));
}

// Late starts of a person in a period (from the roster plan against the first clock-in of the day).
export function lateStarts(from, to, { userUid, graceMin = 5 } = {}) {
  const R = require('./roster.js');
  const out = [];
  let rows = [];
  try {
    rows = db().all(`SELECT user_uid, substr(at, 1, 10) AS d, MIN(substr(at, 12, 5)) AS first_in FROM punches WHERE voided = 0 AND type = 'IN' AND substr(at, 1, 10) BETWEEN ? AND ? AND (? IS NULL OR user_uid = ?)
      GROUP BY user_uid, substr(at, 1, 10)`, [from, to, userUid || null, userUid || null]);
  } catch (e) { rows = []; }
  for (const r of rows) {
    let plan = null;
    try { plan = R.plannedFor(r.user_uid, r.d); } catch (e) { plan = null; }
    if (!plan || !plan.start || !r.first_in) continue;
    const [ph, pm] = plan.start.split(':').map(Number);
    const [ih, im] = r.first_in.split(':').map(Number);
    const late = ih * 60 + im - (ph * 60 + pm);
    if (late > graceMin && late < 720) out.push({ userUid: r.user_uid, date: r.d, late, planned: plan.start, firstIn: r.first_in });
  }
  return out;
}

export function monthRange(ym) {
  const [y, m] = ym.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return [`${ym}-01`, `${ym}-${String(last).padStart(2, '0')}`];
}
export { addDays };
