// Warnings for Home: timesheet problems this week, people still clocked in after 12 hours.
import { can } from '../../services/access.js';
import { dateStr } from '../../services/core.js';
import { weekTimesheet } from './service.js';
import { stillIn } from './roster.js';

export function alerts(user) {
  if (!can(user, 'timesheets_view')) return [];
  const out = [];
  const toFix = weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0);
  if (toFix) out.push({ id: 'ts-problems', level: 'warning', text: `${toFix} timesheet problem${toFix === 1 ? '' : 's'} this week`, sub: 'Missing Clock OUT, long shifts or no breaks.', nav: { screen: 'Timesheets', params: {} } });
  let still = [];
  try { still = stillIn(12); } catch (e) { still = []; }
  if (still.length) out.push({ id: 'ts-still-in', level: 'warning', text: `Still clocked in after 12 hours: ${still.map((x) => x.name).join(', ')}`, sub: 'Probably forgot to clock out. Fix it in Timesheets.', nav: { screen: 'Timesheets', params: {} } });
  return out;
}
