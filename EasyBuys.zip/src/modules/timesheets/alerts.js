// Warnings for Home: timesheet problems this week, people still clocked in after 12 hours.
import { can } from '../../services/access.js';
import { dateStr } from '../../services/core.js';
import { weekTimesheet } from './service.js';
import { stillIn } from './roster.js';
import { rosterAlerts } from './rosterPlus.js';

export function alerts(user) {
  // v3.5: my changed shift today / tomorrow (everyone), short days and clashes (managers).
  let mine = [];
  try { mine = rosterAlerts(user, can); } catch (e) { mine = []; }
  if (!can(user, 'timesheets_view')) return mine;
  const out = mine.slice();
  const toFix = weekTimesheet(dateStr()).rows.reduce((a, r) => a + r.problems, 0);
  if (toFix) out.push({ id: 'ts-problems', level: 'warning', text: `${toFix} timesheet problem${toFix === 1 ? '' : 's'} this week`, sub: 'Missing Clock OUT, long shifts or no breaks.', nav: { screen: 'Timesheets', params: {} } });
  let still = [];
  try { still = stillIn(12); } catch (e) { still = []; }
  if (still.length) out.push({ id: 'ts-still-in', level: 'warning', text: `Still clocked in after 12 hours: ${still.map((x) => x.name).join(', ')}`, sub: 'Probably forgot to clock out. Fix it in Timesheets.', nav: { screen: 'Timesheets', params: {} } });
  // v3.9.5 rostered but not clocked in 30 minutes after the start: "Absent?" – tap to mark the day.
  if (can(user, 'timesheets_edit') || can(user, 'leave_approve')) {
    let missing = [];
    try { missing = require('./absence.js').notClockedIn(); } catch (e) { missing = []; }
    for (const m of missing.slice(0, 6)) {
      out.push({ id: `ts-absent-${m.uid}-${dateStr()}`, level: 'warning', text: `${m.name} has not clocked in (due ${m.start}${m.shop ? ` at ${m.shop}` : ''}) – absent?`,
        sub: 'Tap to mark the day: late, absent, sick or day off.', nav: { screen: 'MarkDay', params: { userUid: m.uid, date: dateStr() } } });
    }
  }
  return out;
}
