// Timesheets module: punches -> shifts -> Saturday-Friday weeks; manager fixes and "week checked".
import TimesheetWeekScreen from './screens/TimesheetWeekScreen.js';
import TimesheetPersonScreen from './screens/TimesheetPersonScreen.js';
import MyHoursScreen from './screens/MyHoursScreen.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

export default {
  id: 'timesheets',
  title: 'Timesheets',
  icon: '🗓️',
  switchable: true,
  screens: {
    Timesheets: { component: TimesheetWeekScreen, can: (u) => can(u, 'timesheets_view') },
    TimesheetPerson: { component: TimesheetPersonScreen, can: (u) => can(u, 'timesheets_view') },
    MyHours: { component: MyHoursScreen, can: (u) => can(u, 'my_hours') },
  },
  reports: REPORTS,
};
