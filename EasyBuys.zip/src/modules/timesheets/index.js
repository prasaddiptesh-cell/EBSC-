// Timesheets module: punches -> shifts -> Saturday-Friday weeks; manager fixes and "week checked".
import TimesheetWeekScreen from './screens/TimesheetWeekScreen.js';
import TimesheetPersonScreen from './screens/TimesheetPersonScreen.js';
import MyHoursScreen from './screens/MyHoursScreen.js';
import TimesheetGridScreen from './screens/TimesheetGridScreen.js';
import RosterScreen from './screens/RosterScreen.js';
import { RosterPlannerScreen, PlanVsActualScreen, WhoIsOnScreen, RosterSettingsScreen } from './screens/RosterPlannerScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';

export default {
  id: 'timesheets',
  title: 'Timesheets',
  icon: '🗓️',
  switchable: true,
  screens: {
    Timesheets: { component: TimesheetWeekScreen, can: (u) => can(u, 'timesheets_view') },
    TimesheetPerson: { component: TimesheetPersonScreen, can: (u) => can(u, 'timesheets_view') },
    MyHours: { component: MyHoursScreen, can: (u) => can(u, 'my_hours') },
    TimesheetGrid: { component: TimesheetGridScreen, can: (u) => can(u, 'timesheets_view') },
    Roster: { component: RosterScreen, can: (u) => can(u, 'timesheets_edit') },
    RosterPlanner: { component: RosterPlannerScreen, can: (u) => can(u, 'timesheets_view') },
    PlanVsActual: { component: PlanVsActualScreen, can: (u) => can(u, 'timesheets_view') },
    WhoIsOn: { component: WhoIsOnScreen, can: (u) => can(u, 'timesheets_view') },
    RosterSettings: { component: RosterSettingsScreen, can: (u) => can(u, 'settings') },
  },
  reports: REPORTS,
};
