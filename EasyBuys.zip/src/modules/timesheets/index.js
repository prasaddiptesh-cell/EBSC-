// Timesheets module: punches -> shifts -> Saturday-Friday weeks; manager fixes and "week checked".
import TimesheetWeekScreen from './screens/TimesheetWeekScreen.js';
import TimesheetPersonScreen from './screens/TimesheetPersonScreen.js';
import MyHoursScreen from './screens/MyHoursScreen.js';
import TimesheetGridScreen from './screens/TimesheetGridScreen.js';
import RosterScreen from './screens/RosterScreen.js';
import { PlanVsActualScreen, WhoIsOnScreen, RosterSettingsScreen } from './screens/RosterPlannerScreens.js';
import { RosterPlannerScreen, MyRosterScreen, RosterRulesScreen } from './screens/RosterPlusScreens.js';
import { MarkDayScreen, AbsenceScreen } from './screens/AbsenceScreens.js';
import { REPORTS } from './reports.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'timesheets',
  title: 'Timesheets',
  icon: '🗓️',
  switchable: true,
  screens: {
    Timesheets: { component: TimesheetWeekScreen, can: (u) => can(u, 'timesheets_view') },
    TimesheetPerson: { component: TimesheetPersonScreen, can: (u) => can(u, 'timesheets_view') },
    MyHours: { component: MyHoursScreen, can: (u) => can(u, 'my_hours') },
    TimesheetGrid: { component: TimesheetGridScreen, can: (u) => can(u, 'timesheets_view') },
    Roster: { component: RosterScreen, can: (u) => can(u, 'timesheets_edit') },
    RosterPlanner: { component: RosterPlannerScreen, can: (u) => can(u, 'timesheets_view') },
    MyRoster: { component: MyRosterScreen, can: (u) => can(u, 'my_hours') },
    RosterRules: { component: RosterRulesScreen, can: (u) => can(u, 'settings') },
    PlanVsActual: { component: PlanVsActualScreen, can: (u) => can(u, 'timesheets_view') },
    WhoIsOn: { component: WhoIsOnScreen, can: (u) => can(u, 'timesheets_view') },
    RosterSettings: { component: RosterSettingsScreen, can: (u) => can(u, 'settings') },
    // v3.9.5 day off / leave / sick / absent, and the absence record
    MarkDay: { component: MarkDayScreen, can: (u) => can(u, 'timesheets_edit') || can(u, 'leave_approve') },
    Absence: { component: AbsenceScreen, can: (u) => can(u, 'timesheets_view') || can(u, 'leave_approve') },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
