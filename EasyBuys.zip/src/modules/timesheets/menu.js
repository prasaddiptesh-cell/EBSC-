// Timesheets & roster menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🗓️', title: 'This week\'s timesheets', note: 'Saturday to Friday; fix and tick as checked.', screen: 'Timesheets' },
    { id: 'ts-roster', icon: '📅', title: 'Roster', note: 'Sat–Fri. Tap a day: shift, day off, leave, sick or absent.', screen: 'RosterPlanner' },
    { id: 'ts-markday', icon: '🤒', title: 'Day off, leave, sick or absent', note: 'Sick sheet = paid; no sheet = unpaid. Staff ask in person.', screen: 'MarkDay' },
    { id: 'ts-whoison', icon: '👀', title: 'Who is on now', screen: 'WhoIsOn' },
    { id: 'ts-myhours', icon: '🙋', title: 'My hours', screen: 'MyHours' },
    { id: 'ts-myroster', icon: '📆', title: 'My roster', note: 'Your shifts this week and next; changes to today and tomorrow.', screen: 'MyRoster', perm: 'my_hours' },
  ] },
  { section: 'Records', items: [
    { id: 'ts-grid', icon: '📋', title: 'Timesheet grid', screen: 'TimesheetGrid' },
    { id: 'ts-usual', icon: '🗓️', title: 'Usual weeks', note: 'Each person\'s normal days and times.', screen: 'Roster' },
    { id: 'ts-absence', icon: '📉', title: 'Absence record', note: 'Absent, sick with / without a sheet, late starts – by month and year.', screen: 'Absence' },
  ] },
  { section: 'Checks', items: [
    { id: 'ts-plan', icon: '⚖️', title: 'Plan against actual', screen: 'PlanVsActual' },
  ] },
  { section: 'Reports', items: [
    { id: 'ts-reports', icon: '📊', title: 'Timesheet reports', screen: 'ReportsHub', params: { group: 'Timesheets' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 'ts-settings', icon: '⚙️', title: 'Roster settings', screen: 'RosterSettings' },
    { id: 'ts-rules', icon: '📏', title: 'Roster rules & staff needed', note: 'Hour limits, rest between shifts, double shifts, staff needed per shift.', screen: 'RosterRules', perm: 'settings' },
    { id: 'ts-clock', icon: '⏱️', title: 'Time Clock rules', screen: 'ClockRules' },
    { id: 'ts-facetest', icon: '🙂', title: 'Test the face check', screen: 'FaceTest' },
  ] },
];
