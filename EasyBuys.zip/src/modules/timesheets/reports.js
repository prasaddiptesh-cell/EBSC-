// Timesheet reports (PDF / Excel / CSV / print / email through the shared report screen).
import { db } from '../../db/connection.js';
import { stamp, dayName, addDays, weekStart } from '../../services/core.js';
import { shiftsBetween, hm, FLAG_LABEL, PROBLEM_FLAGS } from './service.js';
import { listPunches, TYPE_LABEL } from '../timeclock/service.js';
import { wagesVsSales, planVsActual } from './roster.js';

const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});
const hrs = (m) => (Math.round((m / 60) * 100) / 100).toFixed(2);

export const REPORTS = [
  { id: 'tc_wages_sales', group: 'Timesheets', icon: '⚖️', title: 'Wages against sales', desc: 'Hours and wage cost per shop per day, as a % of the Z report sales', perm: 'timesheets_view',
    build(from, to) {
      const rows = wagesVsSales({ from, to });
      const c = rows.reduce((s, r) => s + r.cost, 0); const sl = rows.reduce((s, r) => s + r.sales, 0);
      return { kind: 'tc_wages_sales', title: 'Wages Against Sales', fileName: `Wages-vs-sales-${from}-to-${to}`, subtitle: `Easy Buys Shopping Centre · ${from} to ${to}`, info: [['Period', `${from} to ${to}`], ['Generated', stamp()]],
        summary: [{ label: 'Wage cost', value: `$${c.toFixed(2)}` }, { label: 'Sales', value: `$${sl.toFixed(2)}` }, { label: 'Wages % of sales', value: sl ? `${((c / sl) * 100).toFixed(1)}%` : '—' }],
        sections: [{ title: 'By day and shop', columns: [{ key: 'date', title: 'Date', align: 'left' }, { key: 'shop', title: 'Shop', align: 'left' }, { key: 'hours', title: 'Hours', align: 'right' }, { key: 'cost', title: 'Wages', align: 'right' }, { key: 'sales', title: 'Sales', align: 'right' }, { key: 'pct', title: '%', align: 'right' }],
          rows: rows.map((r) => ({ ...r, cost: `$${r.cost.toFixed(2)}`, sales: `$${r.sales.toFixed(2)}`, pct: r.pct === null ? '' : `${r.pct}%`, _tone: r.pct !== null && r.pct > 15 ? 'warn' : null })),
          note: 'Wage cost is hours worked × pay rate (before FNPF). Sales are the Z report totals typed at the till counts.' }] };
    } },
  { id: 'tc_plan_actual', group: 'Timesheets', icon: '📅', title: 'Planned against worked', desc: 'Roster against the Time Clock: late, absent, extra hours (week)', perm: 'timesheets_view', week: true,
    build(from) {
      const r = planVsActual(from);
      return { kind: 'tc_plan_actual', title: 'Planned Against Worked', fileName: `Planned-vs-worked-${r.weekStart}`, subtitle: `Easy Buys Shopping Centre · week ${r.weekStart}`, info: [['Week', r.weekStart], ['Generated', stamp()]],
        summary: [{ label: 'Planned', value: hm(r.plannedMin) }, { label: 'Worked', value: hm(r.workedMin) }, { label: 'Late', value: String(r.late) }, { label: 'Absent', value: String(r.absent), tone: r.absent ? 'bad' : undefined }],
        sections: [{ title: 'People', columns: [{ key: 'name', title: 'Name', align: 'left' }].concat(r.days.map((d) => ({ key: d, title: `${dayName(d)} ${d.slice(8)}`, align: 'left' }))).concat([{ key: 'p', title: 'Planned', align: 'right' }, { key: 'w', title: 'Worked', align: 'right' }]),
          rows: r.rows.map((x) => ({ name: x.user.name, ...Object.fromEntries(x.days.map((d) => [d.date, `${d.planned || '–'} / ${d.workedMin ? hm(d.workedMin) : '–'}${d.status === 'late' ? ` late ${d.late}m` : d.status === 'absent' ? ' ABSENT' : ''}`])), p: hm(x.plannedMin), w: hm(x.workedMin), _tone: x.absent ? 'bad' : x.late ? 'warn' : null })) }] };
    } },
  { id: 'tc_week', group: 'Timesheets', icon: '🗓️', title: 'Weekly timesheet', desc: 'Hours per person per day (Sat–Fri)', perm: 'timesheets_view', week: true,
    build(from) {
      const ws = weekStart(from);
      const days = Array.from({ length: 7 }, (_, i) => addDays(ws, i));
      const data = shiftsBetween(ws, addDays(ws, 6));
      const rows = data.filter((d) => d.shifts.length).map(({ user, shifts }) => {
        const r = { name: user.name, emp: user.employee_no || '', shop: user.shop_code || '' };
        days.forEach((d) => { const m = shifts.filter((s) => s.date === d).reduce((a, s) => a + s.workedMinutes, 0); r[d] = m ? hm(m) : ''; });
        const tot = shifts.reduce((a, s) => a + s.workedMinutes, 0);
        const probs = shifts.reduce((a, s) => a + s.problems, 0);
        const chk = db().get("SELECT status FROM timesheet_checks WHERE uid = ?", [`${user.uid}|${ws}`]);
        Object.assign(r, { total: hm(tot), decimal: hrs(tot), problems: probs || '', checked: chk && chk.status === 'checked' ? '✓' : '', _tone: probs ? 'bad' : null });
        return r;
      });
      const total = data.reduce((a, d) => a + d.shifts.reduce((x, s) => x + s.workedMinutes, 0), 0);
      return base('tc_week', 'Weekly Timesheet', ws, addDays(ws, 6), {
        summary: [{ label: 'Staff', value: String(rows.length) }, { label: 'Total hours', value: hm(total) },
          { label: 'To fix', value: String(rows.reduce((a, r) => a + (Number(r.problems) || 0), 0)), tone: rows.some((r) => r.problems) ? 'bad' : 'good' }],
        sections: [{ title: 'Hours per day', columns: [col('name', 'Name'), col('emp', 'Emp no'), col('shop', 'Shop')].concat(days.map((d) => col(d, `${dayName(d)} ${d.slice(8)}`, R)))
          .concat([col('total', 'Total', R), col('decimal', 'Hours (decimal)', R), col('problems', 'To fix', R), col('checked', 'Checked')]), rows,
        note: 'Hours = Clock IN to Clock OUT minus breaks. Overtime and pay are worked out in Payroll.' }],
      });
    } },
  { id: 'tc_detail', group: 'Timesheets', icon: '⏱️', title: 'Attendance detail', desc: 'Every shift: in, out, breaks, hours, flags', perm: 'timesheets_view',
    build(from, to) {
      const rows = [];
      shiftsBetween(from, to).forEach(({ user, shifts }) => shifts.forEach((s) => rows.push({
        date: s.date, day: dayName(s.date), name: user.name, shop: user.shop_code || '', in: s.in_at ? s.in_at.slice(11, 16) : '—', out: s.out_at ? s.out_at.slice(11, 16) : '—',
        brk: s.breakMinutes ? `${s.breakMinutes} min${s.autoBreak ? ' (auto)' : ''}` : '', hours: hm(s.workedMinutes), flags: s.flags.map((f) => FLAG_LABEL[f]).join(', '),
        _tone: s.problems ? 'bad' : s.flags.includes('manual') ? 'warn' : null,
      })));
      rows.sort((a, b) => (a.date + a.name < b.date + b.name ? -1 : 1));
      return base('tc_detail', 'Attendance Detail', from, to, {
        summary: [{ label: 'Shifts', value: String(rows.length) }],
        sections: [{ title: 'Shifts', columns: [col('date', 'Date'), col('day', 'Day'), col('name', 'Name'), col('shop', 'Shop'), col('in', 'In'), col('out', 'Out'), col('brk', 'Break'), col('hours', 'Hours', R), col('flags', 'Notes')], rows }],
      });
    } },
  { id: 'tc_problems', group: 'Timesheets', icon: '⚠️', title: 'Problems & changes', desc: 'Missing clock-outs, long shifts, no breaks, manager changes', perm: 'timesheets_view',
    build(from, to) {
      const rows = [];
      shiftsBetween(from, to).forEach(({ user, shifts }) => shifts.filter((s) => s.flags.some((f) => PROBLEM_FLAGS.includes(f) || f === 'manual')).forEach((s) => rows.push({
        date: s.date, name: user.name, in: s.in_at ? s.in_at.slice(11, 16) : '—', out: s.out_at ? s.out_at.slice(11, 16) : '—', flags: s.flags.map((f) => FLAG_LABEL[f]).join(', '),
        reasons: s.punches.filter((p) => p.reason).map((p) => p.reason).join(' | '), _tone: s.problems ? 'bad' : 'warn',
      })));
      const cancelled = listPunches({ from, to }).filter((p) => p.voided).map((p) => ({ when: p.at.slice(0, 16), name: p.name, type: TYPE_LABEL[p.type], reason: p.void_reason }));
      return base('tc_problems', 'Timesheet Problems and Changes', from, to, {
        summary: [{ label: 'Shifts flagged', value: String(rows.length), tone: rows.length ? 'warn' : 'good' }, { label: 'Punches cancelled', value: String(cancelled.length) }],
        sections: [{ title: 'Flagged shifts', columns: [col('date', 'Date'), col('name', 'Name'), col('in', 'In'), col('out', 'Out'), col('flags', 'What'), col('reasons', 'Manager reasons')], rows },
          { title: 'Cancelled punches', columns: [col('when', 'When'), col('name', 'Name'), col('type', 'Punch'), col('reason', 'Reason')], rows: cancelled }],
      });
    } },
  { id: 'tc_face', group: 'Timesheets', icon: '🙂', title: 'Face check results', desc: 'Punches where the face did not match', perm: 'timesheets_view',
    build(from, to) {
      const all = listPunches({ from, to, includeVoided: false }).filter((p) => p.face_result);
      const bad = all.filter((p) => !['match', 'photo_only', 'off'].includes(p.face_result));
      const rows = bad.map((p) => ({ when: p.at.slice(0, 16), name: p.name, type: TYPE_LABEL[p.type], result: p.face_result.replace('_', ' '), dist: p.face_distance == null ? '' : p.face_distance, photo: p.photo_url || (p.photo_uri ? 'on tablet' : ''), _tone: ['no_match', 'no_face'].includes(p.face_result) ? 'bad' : 'warn' }));
      return base('tc_face', 'Face Check Results', from, to, {
        summary: [{ label: 'Punches with face check', value: String(all.length) }, { label: 'Matched', value: String(all.filter((p) => p.face_result === 'match').length), tone: 'good' }, { label: 'To look at', value: String(bad.length), tone: bad.length ? 'bad' : 'good' }],
        sections: [{ title: 'To look at', columns: [col('when', 'When'), col('name', 'Name'), col('type', 'Punch'), col('result', 'Result'), col('dist', 'Distance', R), col('photo', 'Photo')], rows }],
      });
    } },
  { id: 'tc_shop', group: 'Timesheets', icon: '🏪', title: 'Hours by shop', desc: 'Staff hours for each shop', perm: 'timesheets_view',
    build(from, to) {
      const per = {};
      shiftsBetween(from, to).forEach(({ user, shifts }) => { const m = shifts.reduce((a, s) => a + s.workedMinutes, 0); if (m) { const k = user.shop_code || '—'; per[k] = per[k] || { shop: k, people: 0, mins: 0 }; per[k].people += 1; per[k].mins += m; } });
      const rows = Object.values(per).map((p) => ({ shop: p.shop, people: p.people, hours: hm(p.mins), decimal: hrs(p.mins) }));
      return base('tc_shop', 'Hours by Shop', from, to, { summary: rows.map((r) => ({ label: r.shop, value: r.hours })), sections: [{ title: 'Shops', columns: [col('shop', 'Shop'), col('people', 'Staff', R), col('hours', 'Hours', R), col('decimal', 'Decimal', R)], rows }] });
    } },
];
