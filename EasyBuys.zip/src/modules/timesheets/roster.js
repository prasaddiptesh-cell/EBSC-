// Roster planner (planning only – nobody is ever stopped from clocking in) and the "plan against what was worked" tracker.
// Shifts are planned per shop and day. The usual week (rosters table) can fill a week; a week can be copied to the next.
// When the admin switches it on, the published roster also goes into a Google Calendar per shop.
import { requireSetup } from '../../services/access.js';
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, weekStart as weekStartOf, getShared, setShared, money } from '../../services/core.js';
import { enqueue } from '../../services/stock.js';
import { listUsers } from '../../services/catalog.js';
import { weekDays, weekTimesheet, getRoster, DOW, hm } from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const HHMM = /^\d{2}:\d{2}$/;
const meta = () => ({ now: stamp(), dev: deviceId() });

export const ROSTER_SQL = `
CREATE TABLE IF NOT EXISTS roster_shifts (
  uid TEXT PRIMARY KEY,
  week_start TEXT NOT NULL,
  shift_date TEXT NOT NULL,
  user_uid TEXT NOT NULL,
  shop_code TEXT,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  break_min INTEGER NOT NULL DEFAULT 0,
  role TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_rs_week ON roster_shifts(week_start, shop_code);
CREATE INDEX IF NOT EXISTS idx_rs_user ON roster_shifts(user_uid, shift_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const ROSTER_SYNC = {
  roster_shifts: SYNC('uid', 'Timesheets', ['uid', 'week_start', 'shift_date', 'user_uid', 'shop_code', 'start_time', 'end_time', 'break_min', 'role', 'note', 'status', 'by_name']),
};

// ---------------------------------------------------------------- settings
export const ROSTER_DEFAULTS = {
  templates: [{ name: 'Morning', start: '07:00', end: '15:00', breakMin: 30 }, { name: 'Afternoon', start: '13:00', end: '21:00', breakMin: 30 }, { name: 'Full day', start: '08:00', end: '17:00', breakMin: 60 }],
  calendar: false,         // publish the roster to Google Calendar (one calendar per shop)
  lateReasonAfter: 10,     // ask for a reason when clocking in more than this many minutes late / leaving early
};
export function rosterSettings() { return { ...ROSTER_DEFAULTS, ...(getShared('roster_settings', {}) || {}) }; }
export function saveRosterSettings(user, s) {
  requireSetup(user, 'timesheets_edit');
  const templates = (s.templates || []).map((t) => ({ name: txt(t.name), start: txt(t.start), end: txt(t.end), breakMin: Math.max(0, Math.round(Number(t.breakMin) || 0)) })).filter((t) => t.name && HHMM.test(t.start) && HHMM.test(t.end));
  const clean = { templates, calendar: !!s.calendar, lateReasonAfter: Math.max(0, Math.round(Number(s.lateReasonAfter) || 0)) };
  setShared('roster_settings', clean);
  audit({ user, action: 'Changed roster settings', table: 'shared_settings', recordUid: 'roster_settings', after: clean });
  return clean;
}

// ---------------------------------------------------------------- shifts
const minutes = (start, end, br = 0) => {
  const [a, b] = [start, end].map((t) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5)));
  return Math.max(0, (b > a ? b - a : b + 1440 - a) - (Number(br) || 0));
};
export function shiftMinutes(s) { return minutes(s.start_time, s.end_time, s.break_min); }

export function setShift(user, { uid, userUid, date, shopCode, start, end, breakMin = 0, role, note }) {
  need(userUid, 'Choose the person.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(txt(date)), 'Choose the day.');
  need(HHMM.test(txt(start)) && HHMM.test(txt(end)), 'Choose the start and finish times.');
  need(start !== end, 'Start and finish cannot be the same.');
  const { now, dev } = meta();
  const id = uid || uuid('RS');
  db().run(`INSERT INTO roster_shifts (uid, week_start, shift_date, user_uid, shop_code, start_time, end_time, break_min, role, note, status, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?)
    ON CONFLICT(uid) DO UPDATE SET shift_date=excluded.shift_date, week_start=excluded.week_start, user_uid=excluded.user_uid, shop_code=excluded.shop_code, start_time=excluded.start_time, end_time=excluded.end_time,
    break_min=excluded.break_min, role=excluded.role, note=excluded.note, status='active', by_name=excluded.by_name, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
  [id, weekStartOf(date), date, userUid, txt(shopCode) || null, start, end, Math.max(0, Math.round(Number(breakMin) || 0)), txt(role) || null, txt(note) || null, user ? user.name : null, now, dev]);
  return id;
}
export function removeShift(user, uid) {
  const { now, dev } = meta();
  db().run(`UPDATE roster_shifts SET status = 'removed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, uid]);
}
export function shiftsFor({ weekStart, shopCode, userUid, date } = {}) {
  return db().all(`SELECT * FROM roster_shifts WHERE status = 'active' AND (? IS NULL OR week_start = ?) AND (? IS NULL OR shop_code = ?) AND (? IS NULL OR user_uid = ?) AND (? IS NULL OR shift_date = ?)
    ORDER BY shift_date, start_time`, [weekStart || null, weekStart || null, shopCode || null, shopCode || null, userUid || null, userUid || null, date || null, date || null]);
}
// The planned shift for a person on a day: the roster planner first, then their usual week.
export function plannedFor(userUid, date) {
  const s = db().get("SELECT * FROM roster_shifts WHERE status = 'active' AND user_uid = ? AND shift_date = ? ORDER BY start_time LIMIT 1", [userUid, date]);
  if (s) return { start: s.start_time, end: s.end_time, shop: s.shop_code, breakMin: s.break_min, uid: s.uid, source: 'plan' };
  const d = getRoster(userUid)[DOW[new Date(`${date}T00:00:00`).getDay()]];
  return d && d.start ? { ...d, source: 'usual' } : null;
}

// People who belong in a shop's planner: everyone of that shop plus anyone planned there this week.
function peopleFor(shopCode, ws) {
  const users = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const planned = new Set(shiftsFor({ weekStart: ws, shopCode }).map((s) => s.user_uid));
  return users.filter((u) => !shopCode || u.shop_code === shopCode || planned.has(u.uid));
}
const rateOf = (userUid) => {
  try {
    const p = db().get('SELECT pay_type, rate, weekly_salary FROM pay_profiles WHERE user_uid = ?', [userUid]);
    if (!p) return 0;
    return p.pay_type === 'salary' ? r2((p.weekly_salary || 0) / 48) : Number(p.rate) || 0;
  } catch (e) { return 0; }
};

export function weekPlan(anyDate, { shopCode } = {}) {
  const ws = weekStartOf(anyDate || dateStr());
  const days = weekDays(ws);
  const shifts = shiftsFor({ weekStart: ws, shopCode });
  const people = peopleFor(shopCode, ws).map((u) => {
    const mine = shifts.filter((s) => s.user_uid === u.uid);
    const byDay = Object.fromEntries(days.map((d) => [d, mine.filter((s) => s.shift_date === d)]));
    const mins = mine.reduce((a, s) => a + shiftMinutes(s), 0);
    const rate = rateOf(u.uid);
    return { user: u, byDay, minutes: mins, hours: hm(mins), cost: r2((mins / 60) * rate), rate };
  });
  const perDay = Object.fromEntries(days.map((d) => [d, { people: shifts.filter((s) => s.shift_date === d).length, minutes: shifts.filter((s) => s.shift_date === d).reduce((a, s) => a + shiftMinutes(s), 0) }]));
  return { weekStart: ws, days, people, perDay, totalMinutes: people.reduce((a, p) => a + p.minutes, 0), totalCost: r2(people.reduce((a, p) => a + p.cost, 0)) };
}
// Copy one week's shifts to another (skips people who already have a shift that day).
export function copyWeek(user, { fromWeek, toWeek, shopCode }) {
  const src = shiftsFor({ weekStart: weekStartOf(fromWeek), shopCode });
  need(src.length, 'That week has no shifts to copy.');
  const to = weekStartOf(toWeek);
  const diff = Math.round((new Date(`${to}T00:00:00`) - new Date(`${weekStartOf(fromWeek)}T00:00:00`)) / 86400000);
  let n = 0;
  for (const s of src) {
    const d = addDays(s.shift_date, diff);
    if (shiftsFor({ userUid: s.user_uid, date: d }).length) continue;
    setShift(user, { userUid: s.user_uid, date: d, shopCode: s.shop_code, start: s.start_time, end: s.end_time, breakMin: s.break_min, role: s.role, note: s.note });
    n += 1;
  }
  audit({ user, action: `Copied roster ${weekStartOf(fromWeek)} → ${to}${shopCode ? ` (${shopCode})` : ''}: ${n} shifts`, table: 'roster_shifts' });
  return n;
}
// Fill a week from everyone's usual week.
export function fillFromUsual(user, { weekStart: ws, shopCode }) {
  const w = weekStartOf(ws);
  let n = 0;
  for (const u of peopleFor(shopCode, w)) {
    const usual = getRoster(u.uid);
    for (const d of weekDays(w)) {
      const x = usual[DOW[new Date(`${d}T00:00:00`).getDay()]];
      if (!x || !x.start || shiftsFor({ userUid: u.uid, date: d }).length) continue;
      setShift(user, { userUid: u.uid, date: d, shopCode: x.shop || u.shop_code || shopCode, start: x.start, end: x.end, breakMin: 0 });
      n += 1;
    }
  }
  return n;
}

// ---------------------------------------------------------------- plan against what was worked
export function planVsActual(anyDate, { shopCode } = {}) {
  const ws = weekStartOf(anyDate || dateStr());
  const plan = weekPlan(ws, { shopCode });
  const ts = weekTimesheet(ws, { shopCode });
  const worked = Object.fromEntries(ts.rows.map((r) => [r.user.uid, r]));
  const today = dateStr();
  const graceMin = 5;
  const rows = plan.people.map((p) => {
    const w = worked[p.user.uid];
    const days = plan.days.map((d) => {
      const planned = p.byDay[d];
      const sh = w ? w.days[d] : [];
      const pm = planned.reduce((a, s) => a + shiftMinutes(s), 0);
      const wm = sh.reduce((a, s) => a + s.workedMinutes, 0);
      const firstIn = sh.length && sh[0].in ? sh[0].in.at.slice(11, 16) : null;
      const late = planned.length && firstIn ? Math.max(0, minutes(planned[0].start_time, firstIn) < 720 ? minutes(planned[0].start_time, firstIn) : 0) : 0;
      const status = !planned.length && !sh.length ? 'off' : planned.length && !sh.length ? (d < today ? 'absent' : d === today ? 'not_in' : 'planned') : !planned.length ? 'extra' : late > graceMin ? 'late' : 'ok';
      return { date: d, planned: planned.map((s) => `${s.start_time}–${s.end_time}`).join(', '), plannedMin: pm, workedMin: wm, late, status };
    });
    const pm = days.reduce((a, x) => a + x.plannedMin, 0);
    const wm = days.reduce((a, x) => a + x.workedMin, 0);
    return { user: p.user, days, plannedMin: pm, workedMin: wm, diffMin: wm - pm, plannedCost: p.cost, actualCost: r2((wm / 60) * p.rate), absent: days.filter((x) => x.status === 'absent').length, late: days.filter((x) => x.status === 'late').length };
  });
  // People who worked here without being in the planner.
  ts.rows.filter((r) => !plan.people.some((p) => p.user.uid === r.user.uid) && r.totalMinutes).forEach((r) => rows.push({ user: r.user, days: plan.days.map((d) => ({ date: d, planned: '', plannedMin: 0, workedMin: (r.days[d] || []).reduce((a, s) => a + s.workedMinutes, 0), late: 0, status: (r.days[d] || []).length ? 'extra' : 'off' })),
    plannedMin: 0, workedMin: r.totalMinutes, diffMin: r.totalMinutes, plannedCost: 0, actualCost: r2((r.totalMinutes / 60) * rateOf(r.user.uid)), absent: 0, late: 0 }));
  const sum = (k) => rows.reduce((a, r) => a + r[k], 0);
  return { weekStart: ws, days: plan.days, rows, plannedMin: sum('plannedMin'), workedMin: sum('workedMin'), plannedCost: r2(sum('plannedCost')), actualCost: r2(sum('actualCost')), absent: sum('absent'), late: sum('late') };
}

// ---------------------------------------------------------------- who is on now
export function whoIsOn(shopCode, now = new Date()) {
  const today = dateStr();
  const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const ts = weekTimesheet(today, { shopCode });
  const users = listUsers().filter((u) => u.active && u.sync_status !== 'seed' && (!shopCode || u.shop_code === shopCode || shiftsFor({ shopCode, date: today }).some((s) => s.user_uid === u.uid)));
  return users.map((u) => {
    const plan = plannedFor(u.uid, today);
    const row = ts.rows.find((r) => r.user.uid === u.uid);
    const sh = row ? row.days[today] || [] : [];
    const last = sh[sh.length - 1];
    const state = !last ? 'not_in' : !last.out ? (last.breakOpen ? 'break' : 'in') : 'finished';
    const late = plan && state === 'not_in' && hhmm > plan.start ? minutes(plan.start, hhmm) : 0;
    const status = state !== 'not_in' ? state : !plan ? 'off' : late > 5 ? 'late' : hhmm < plan.start ? 'later' : 'due';
    return { user: u, plan, state, status, late, since: last && last.in ? last.in.at.slice(11, 16) : null, worked: sh.reduce((a, s) => a + s.workedMinutes, 0) };
  }).filter((x) => x.status !== 'off' || x.state !== 'not_in').sort((a, b) => ['late', 'due', 'in', 'break', 'later', 'finished', 'off'].indexOf(a.status) - ['late', 'due', 'in', 'break', 'later', 'finished', 'off'].indexOf(b.status));
}
// Still clocked in for too long (forgot to clock out) – for the manager's home screen.
export function stillIn(hours = 12) {
  const rows = weekTimesheet(dateStr()).rows.concat(weekTimesheet(addDays(dateStr(), -7)).rows);
  const out = [];
  const now = Date.now();
  for (const r of rows) for (const s of r.shifts) if (s.in && !s.out && (now - new Date(s.in.at.replace(' ', 'T')).getTime()) / 3600000 > hours) out.push({ name: r.user.name, since: s.in.at });
  return out;
}

// ---------------------------------------------------------------- Google Calendar
// Sends the week (per shop) to the cloud, which writes it into one Google Calendar per shop.
export function publishWeek(user, anyDate) {
  const s = rosterSettings();
  need(s.calendar, 'Google Calendar is switched off (Admin › Settings › Roster).');
  const ws = weekStartOf(anyDate || dateStr());
  const names = Object.fromEntries(listUsers().map((u) => [u.uid, u.name]));
  const shifts = shiftsFor({ weekStart: ws }).map((x) => ({ shop: x.shop_code || 'Other', date: x.shift_date, start: x.start_time, end: x.end_time, name: names[x.user_uid] || '', note: x.note || '' }));
  enqueue('calendar', { weekStart: ws, weekEnd: addDays(ws, 6), shifts });
  audit({ user, action: `Roster week ${ws} sent to Google Calendar (${shifts.length} shifts)`, table: 'roster_shifts' });
  return shifts.length;
}

// ---------------------------------------------------------------- wages against sales
export function wagesVsSales({ from, to, shopCode }) {
  const days = [];
  let d = from;
  while (d <= to && days.length < 400) { days.push(d); d = addDays(d, 1); }
  const sales = {};
  try {
    db().all(`SELECT shift_date AS d, shop_code AS s, SUM(COALESCE(z_total, 0)) AS t FROM till_counts WHERE status <> 'void' AND shift_date BETWEEN ? AND ? GROUP BY shift_date, shop_code`, [from, to])
      .forEach((r) => { sales[`${r.d}|${r.s}`] = r.t; });
  } catch (e) { /* no till */ }
  // 1.0.0 build 4: the till PCs' sales (Aronium Link) for each shop and day that has them, else the till balances
  try {
    const fallback = Object.entries(sales).map(([k, v]) => { const [date, shop] = k.split('|'); return { date, shop, value: v }; });
    const merged = require('../aronium/link.js').salesPerShopDay({ from, to, fallback });
    for (const k of Object.keys(sales)) delete sales[k];
    for (const x of merged) sales[`${x.date}|${x.shop}`] = x.value;
  } catch (e) { /* the till balances stand */ }
  const out = [];
  const weeks = Array.from(new Set(days.map((x) => weekStartOf(x))));
  const worked = {};
  for (const w of weeks) {
    for (const r of weekTimesheet(w, { shopCode }).rows) {
      const shop = r.user.shop_code || 'Other';
      const rate = rateOf(r.user.uid);
      for (const s of r.shifts) {
        if (s.date < from || s.date > to) continue;
        const k = `${s.date}|${shop}`;
        worked[k] = worked[k] || { minutes: 0, cost: 0 };
        worked[k].minutes += s.workedMinutes;
        worked[k].cost += (s.workedMinutes / 60) * rate;
      }
    }
  }
  const keys = Array.from(new Set(Object.keys(worked).concat(Object.keys(sales)))).filter((k) => !shopCode || k.endsWith(`|${shopCode}`)).sort();
  for (const k of keys) {
    const [date, shop] = k.split('|');
    const w = worked[k] || { minutes: 0, cost: 0 };
    const s = sales[k] || 0;
    out.push({ date, shop, hours: hm(w.minutes), cost: r2(w.cost), sales: r2(s), pct: s ? r2((w.cost / s) * 100) : null });
  }
  return out;
}
