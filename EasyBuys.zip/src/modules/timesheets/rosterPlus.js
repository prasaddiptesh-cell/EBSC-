// v3.5 roster: rules (hour limits, rest, double shifts, staff needed per shift), checks that SUGGEST what to do instead
// (swap with X, move the time, Y is free, or "Allow anyway" for owner/admin), paint / copy / swap helpers, undo, the
// list of changes to today's and tomorrow's roster (staff are told), colours and the shareable roster report.
// Everything here is planning only – nobody is ever stopped from clocking in.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, weekStart as weekStartOf, getShared, setShared, getSetting, setSetting, dayName } from '../../services/core.js';
import { reasonRequired } from '../../services/access.js';
import { listUsers } from '../../services/catalog.js';
import { enqueue } from '../../services/stock.js';
import { weekDays, hm } from './service.js';
import * as R from './roster.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const HHMM = /^\d{2}:\d{2}$/;
export const toMin = (t) => Number(String(t).slice(0, 2)) * 60 + Number(String(t).slice(3, 5));
export const fromMin = (m) => { const x = ((Math.round(m) % 1440) + 1440) % 1440; return `${String(Math.floor(x / 60)).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`; };
const dayNo = (d) => Math.round(Date.parse(`${d}T00:00:00Z`) / 86400000);
// A shift as absolute minutes (overnight shifts end the next day).
export function span(date, start, end) {
  const s = dayNo(date) * 1440 + toMin(start);
  let e = dayNo(date) * 1440 + toMin(end);
  if (e <= s) e += 1440;
  return [s, e];
}
const nameOf = (uid) => { const u = db().get('SELECT name FROM users WHERE uid = ?', [uid]); return u ? u.name : 'Someone'; };

// ---------------------------------------------------------------- rules (admin can change all of them)
export const RULE_DEFAULTS = {
  maxWeekHours: 48,        // weekly hour limit per person (0 = no limit)
  minRestHours: 10,        // rest between the end of one shift and the start of the next
  maxShiftsPerDay: 1,      // more than this on one day is a "double shift"
  tellViber: false,        // also post today/tomorrow roster changes to the Viber group
  needs: {},               // { S1: [{ name, start, end, count: [Sun..Sat] }] } staff needed per shift
};
export function rosterRules() {
  const r = { ...RULE_DEFAULTS, ...(getShared('roster_rules', {}) || {}) };
  r.needs = r.needs && typeof r.needs === 'object' ? r.needs : {};
  return r;
}
export function saveRosterRules(user, r) {
  const num = (v, d, max) => { const n = Number(v); return Number.isFinite(n) && n >= 0 ? Math.min(max, n) : d; };
  const needs = {};
  for (const [shop, list] of Object.entries(r.needs || {})) {
    needs[shop] = (list || []).map((x) => ({ name: txt(x.name) || 'Shift', start: txt(x.start), end: txt(x.end), count: Array.from({ length: 7 }, (_, i) => Math.max(0, Math.round(Number((x.count || [])[i]) || 0))) }))
      .filter((x) => HHMM.test(x.start) && HHMM.test(x.end) && x.start !== x.end);
  }
  const clean = { maxWeekHours: num(r.maxWeekHours, 48, 168), minRestHours: num(r.minRestHours, 10, 24), maxShiftsPerDay: Math.max(1, Math.round(num(r.maxShiftsPerDay, 1, 4))), tellViber: !!r.tellViber, needs };
  setShared('roster_rules', clean);
  audit({ user, action: 'Changed roster rules (hour limits, rest, staff needed)', table: 'shared_settings', recordUid: 'roster_rules', after: clean });
  return clean;
}

// ---------------------------------------------------------------- colours (same in the app and the shared picture)
export const SHIFT_COLOURS = {
  morning: { bg: '#FFF4CC', fg: '#7A5B00', label: 'Morning' },
  day: { bg: '#DDF3E4', fg: '#1E6B3A', label: 'Full day' },
  afternoon: { bg: '#DCEBFF', fg: '#1F4E8C', label: 'Afternoon' },
  night: { bg: '#EADCF8', fg: '#5B2C83', label: 'Evening' },
  leave: { bg: '#FBE0E6', fg: '#9B1C3A', label: 'On leave' },
  off: { bg: '#F6F2EC', fg: '#8A8178', label: 'Off' },
};
export function shiftKind(s) {
  if (!s) return 'off';
  const a = toMin(s.start_time || s.start);
  const len = R.shiftMinutes({ start_time: s.start_time || s.start, end_time: s.end_time || s.end, break_min: 0 });
  if (len >= 8 * 60 && a < 11 * 60) return 'day';
  if (a < 11 * 60) return 'morning';
  if (a < 16 * 60) return 'afternoon';
  return 'night';
}

// ---------------------------------------------------------------- facts used by the checks
function onLeave(userUid, date) {
  try {
    return db().get(`SELECT r.*, t.name AS type_name FROM leave_requests r LEFT JOIN leave_types t ON t.code = r.type WHERE r.user_uid = ? AND r.status IN ('approved','requested') AND r.from_date <= ? AND r.to_date >= ?
      ORDER BY CASE r.status WHEN 'approved' THEN 0 ELSE 1 END LIMIT 1`, [userUid, date, date]) || null;
  } catch (e) { return null; }
}
const activeShifts = (where, args) => db().all(`SELECT * FROM roster_shifts WHERE status = 'active' AND ${where} ORDER BY shift_date, start_time`, args);

// Coverage of the "staff needed" slots on one day for a shop. `shifts` may be a what-if list.
export function coverage(date, shopCode, shifts = null) {
  const rules = rosterRules();
  const slots = (rules.needs[shopCode] || []);
  const wd = new Date(`${date}T00:00:00`).getDay();
  const list = shifts || activeShifts('shift_date = ? AND shop_code = ?', [date, shopCode]);
  return slots.map((x) => {
    const [a, b] = span(date, x.start, x.end);
    const have = list.filter((s) => s.shift_date === date && (!s.shop_code || s.shop_code === shopCode)).filter((s) => {
      const [c, d] = span(s.shift_date, s.start_time, s.end_time);
      return Math.min(b, d) - Math.max(a, c) >= (b - a) / 2;
    }).length;
    const needN = Number(x.count[wd]) || 0;
    return { name: x.name, start: x.start, end: x.end, need: needN, have, short: Math.max(0, needN - have) };
  }).filter((x) => x.need > 0);
}

// ---------------------------------------------------------------- one shift: what clashes, and what to do instead
// input: { uid?, userUid, date, start, end, breakMin, shopCode }
// → { ok, blocks: [{ kind, text }], warns: [{ kind, text }], suggestions: [{ kind, text, ... }] }
export function checkShift(input, { user, deep = true } = {}) {
  const rules = rosterRules();
  const { uid, userUid, date, start, end } = input;
  const blocks = [];
  const warns = [];
  const [s, e] = span(date, start, end);
  const lv = onLeave(userUid, date);
  if (lv) (lv.status === 'approved' ? blocks : warns).push({ kind: 'leave', text: `${nameOf(userUid)} is ${lv.status === 'approved' ? 'on' : 'asking for'} ${String(lv.type_name || lv.type || 'leave').toLowerCase()} leave that day.` });
  const others = activeShifts('user_uid = ? AND shift_date BETWEEN ? AND ?', [userUid, addDays(date, -1), addDays(date, 1)]).filter((x) => x.uid !== uid);
  const sameDay = others.filter((x) => x.shift_date === date);
  if (sameDay.length + 1 > rules.maxShiftsPerDay) blocks.push({ kind: 'double', text: `${nameOf(userUid)} already works ${sameDay.map((x) => `${x.start_time}–${x.end_time}`).join(', ')} that day (double shift).` });
  // Rest between shifts (and overlapping shifts).
  let restBefore = null;
  let restAfter = null;
  if (rules.minRestHours > 0) {
    for (const o of others) {
      const [os, oe] = span(o.shift_date, o.start_time, o.end_time);
      if (oe <= s) { const gap = s - oe; if (gap < rules.minRestHours * 60 && !(o.shift_date === date && rules.maxShiftsPerDay > 1)) restBefore = restBefore === null ? oe : Math.max(restBefore, oe); }
      else if (os >= e) { const gap = os - e; if (gap < rules.minRestHours * 60 && !(o.shift_date === date && rules.maxShiftsPerDay > 1)) restAfter = restAfter === null ? os : Math.min(restAfter, os); }
      else if (o.shift_date !== date) blocks.push({ kind: 'rest', text: `It overlaps ${nameOf(userUid)}'s shift on ${dayName(o.shift_date)} ${o.start_time}–${o.end_time}.` });
    }
    if (restBefore !== null) blocks.push({ kind: 'rest', text: `Only ${hm(s - restBefore)} rest after the previous shift (at least ${rules.minRestHours} hours).` });
    if (restAfter !== null) blocks.push({ kind: 'rest', text: `Only ${hm(restAfter - e)} rest before the next shift (at least ${rules.minRestHours} hours).` });
  }
  // Weekly hours.
  const ws = weekStartOf(date);
  const mins = R.shiftMinutes({ start_time: start, end_time: end, break_min: input.breakMin || 0 });
  const weekMins = activeShifts('user_uid = ? AND week_start = ?', [userUid, ws]).filter((x) => x.uid !== uid).reduce((a, x) => a + R.shiftMinutes(x), 0);
  if (rules.maxWeekHours > 0 && weekMins + mins > rules.maxWeekHours * 60) blocks.push({ kind: 'hours', text: `${nameOf(userUid)} would work ${hm(weekMins + mins)} this week (limit ${rules.maxWeekHours} hours).` });
  // Short-staffed: does this change leave a slot short (e.g. moving someone away)?
  const shop = input.shopCode;
  if (shop) {
    const before = activeShifts('shift_date = ?', [date]);
    const old = uid ? db().get('SELECT * FROM roster_shifts WHERE uid = ?', [uid]) : null;
    const after = before.filter((x) => x.uid !== uid).concat([{ uid: uid || 'new', user_uid: userUid, shift_date: date, shop_code: shop, start_time: start, end_time: end }]);
    const shopsToCheck = Array.from(new Set([shop].concat(old && old.shop_code && old.shop_code !== shop && old.shift_date === date ? [old.shop_code] : [])));
    for (const sc of shopsToCheck) {
      const b = coverage(date, sc, before);
      const a = coverage(date, sc, after);
      a.forEach((x, i) => { if (x.short > (b[i] ? b[i].short : 0)) warns.push({ kind: 'short', text: `${sc} ${x.name} (${x.start}–${x.end}) would be short: ${x.have} of ${x.need}.` }); });
    }
  }
  const out = { ok: !blocks.length, blocks, warns, suggestions: [] };
  if (!blocks.length || !deep) return out;
  out.suggestions = suggest(input, { blocks, restBefore, restAfter, weekMins, rules, user });
  return out;
}

function suggest(input, { blocks, restBefore, restAfter, weekMins, rules, user }) {
  const { uid, userUid, date, start, end, shopCode } = input;
  const len = toMin(end) > toMin(start) ? toMin(end) - toMin(start) : toMin(end) + 1440 - toMin(start);
  const kinds = new Set(blocks.map((b) => b.kind));
  const out = [];
  const passes = (x) => checkShift(x, { deep: false }).ok;
  // Move the time (rest problems, hour limit).
  if (kinds.has('rest') && !kinds.has('leave') && !kinds.has('double')) {
    const base = dayNo(date) * 1440;
    if (restBefore !== null) {
      const ns = restBefore + rules.minRestHours * 60;
      const st = fromMin(ns - base);
      const en = fromMin(ns - base + len);
      if (ns - base < 1440 && passes({ ...input, start: st, end: en })) out.push({ kind: 'move', start: st, end: en, text: `Move it to ${st}–${en}` });
    }
    if (restAfter !== null) {
      const ne = restAfter - rules.minRestHours * 60;
      const st = fromMin(ne - len - base);
      const en = fromMin(ne - base);
      if (ne - len - base >= 0 && passes({ ...input, start: st, end: en })) out.push({ kind: 'move', start: st, end: en, text: `Move it to ${st}–${en}` });
    }
  }
  if (kinds.has('hours') && !kinds.has('leave') && rules.maxWeekHours > 0) {
    const left = rules.maxWeekHours * 60 - weekMins + Number(input.breakMin || 0);
    if (left >= 120 && left < len) {
      const en = fromMin(toMin(start) + Math.floor(left / 30) * 30);
      if (passes({ ...input, end: en })) out.push({ kind: 'move', start, end: en, text: `Make it shorter: ${start}–${en}` });
    }
  }
  if (kinds.has('double')) {
    const other = activeShifts('user_uid = ? AND shift_date = ?', [userUid, date]).find((x) => x.uid !== uid);
    if (other) out.push({ kind: 'replace', uid: other.uid, start, end, text: `Change the existing ${other.start_time}–${other.end_time} shift to ${start}–${end} instead` });
  }
  // Swap with someone working that day: they take these times, this person takes theirs.
  const sameDay = activeShifts('shift_date = ? AND user_uid <> ?', [date, userUid]).filter((x) => !shopCode || x.shop_code === shopCode);
  for (const x of sameDay) {
    if (out.filter((o) => o.kind === 'swap').length >= 2) break;
    if (x.start_time === start && x.end_time === end) continue;
    const me = { ...input, start: x.start_time, end: x.end_time, breakMin: x.break_min };
    const them = { uid: x.uid, userUid: x.user_uid, date, start, end, breakMin: input.breakMin, shopCode: x.shop_code };
    if (passes(me) && passes(them)) out.push({ kind: 'swap', withUid: x.user_uid, shiftUid: x.uid, start: x.start_time, end: x.end_time, text: `Swap with ${nameOf(x.user_uid)}: ${nameOf(userUid)} works ${x.start_time}–${x.end_time}, ${nameOf(x.user_uid)} works ${start}–${end}` });
  }
  // Someone else is free.
  const busy = new Set(activeShifts('shift_date = ?', [date]).map((x) => x.user_uid));
  const people = listUsers().filter((u) => u.active && u.sync_status !== 'seed' && u.uid !== userUid && !busy.has(u.uid) && u.role !== 'owner' && (!shopCode || !u.shop_code || u.shop_code === shopCode));
  for (const u of people) {
    if (out.filter((o) => o.kind === 'free').length >= 3) break;
    if (passes({ userUid: u.uid, date, start, end, breakMin: input.breakMin, shopCode })) out.push({ kind: 'free', userUid: u.uid, text: `${u.name} is free – give the shift to ${u.name}` });
  }
  if (user && !reasonRequired(user)) out.push({ kind: 'allow', text: 'Allow anyway' });
  return out;
}

// ---------------------------------------------------------------- changes: undo, and today/tomorrow changes for staff
export const CHANGES_SQL = `
CREATE TABLE IF NOT EXISTS roster_changes (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  shift_date TEXT NOT NULL,
  before_text TEXT,
  after_text TEXT,
  changed_at TEXT NOT NULL,
  by_name TEXT,
  seen_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_rc_user ON roster_changes(user_uid, shift_date);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const CHANGES_SYNC = {
  roster_changes: SYNC('uid', 'Timesheets', ['uid', 'user_uid', 'shift_date', 'before_text', 'after_text', 'changed_at', 'by_name', 'seen_at']),
};

const COLS = ['uid', 'week_start', 'shift_date', 'user_uid', 'shop_code', 'start_time', 'end_time', 'break_min', 'role', 'note', 'status', 'by_name'];
function snapshotWeeks(weeks) {
  const ws = Array.from(new Set(weeks));
  return db().all(`SELECT ${COLS.join(', ')} FROM roster_shifts WHERE week_start IN (${ws.map(() => '?').join(',')})`, ws);
}
const dayText = (rows, userUid, date) => rows.filter((r) => r.status === 'active' && r.user_uid === userUid && r.shift_date === date).sort((a, b) => (a.start_time < b.start_time ? -1 : 1))
  .map((r) => `${r.start_time}–${r.end_time}${r.shop_code ? ` ${r.shop_code}` : ''}`).join(', ') || 'Off';

function logChanges(user, before, after) {
  const today = dateStr();
  const days = [today, addDays(today, 1)];
  const people = new Set(before.concat(after).filter((r) => days.includes(r.shift_date)).map((r) => r.user_uid));
  const now = stamp();
  const out = [];
  for (const u of people) {
    for (const d of days) {
      const a = dayText(before, u, d);
      const b = dayText(after, u, d);
      if (a === b) continue;
      const uid = uuid('RC');
      db().run(`INSERT INTO roster_changes (uid, user_uid, shift_date, before_text, after_text, changed_at, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)`,
        [uid, u, d, a, b, now, user ? user.name : null, now, deviceId()]);
      out.push({ uid, userUid: u, date: d, before: a, after: b });
    }
  }
  if (out.length && rosterRules().tellViber) {
    try { enqueue('viber', { text: `Roster change:\n${out.map((c) => `${nameOf(c.userUid)} ${c.date === today ? 'today' : 'tomorrow'}: ${c.after} (was ${c.before})`).join('\n')}` }); } catch (e) { /* no viber */ }
  }
  return out;
}

const UNDO_KEY = 'roster_undo';
function undoStack() { try { return JSON.parse(getSetting(UNDO_KEY, '[]')) || []; } catch (e) { return []; } }
function saveUndo(list) { setSetting(UNDO_KEY, JSON.stringify(list.slice(-10))); }
// What "Undo" would take back (newest first), for the button label.
export function undoLabel() { const s = undoStack(); return s.length ? s[s.length - 1].label : null; }

function restore(rows, weeks) {
  const now = stamp();
  const dev = deviceId();
  const keep = new Set(rows.map((r) => r.uid));
  for (const r of rows) {
    db().run(`INSERT INTO roster_shifts (${COLS.join(', ')}, updated_at, updated_device, sync_status) VALUES (${COLS.map(() => '?').join(',')}, ?, ?, 'pending')
      ON CONFLICT(uid) DO UPDATE SET ${COLS.filter((c) => c !== 'uid').map((c) => `${c}=excluded.${c}`).join(', ')}, updated_at=excluded.updated_at, updated_device=excluded.updated_device, sync_status='pending'`,
    COLS.map((c) => r[c]).concat([now, dev]));
  }
  for (const r of snapshotWeeks(weeks)) {
    if (!keep.has(r.uid) && r.status === 'active') db().run(`UPDATE roster_shifts SET status = 'removed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [now, dev, r.uid]);
  }
}

// Run a change to the roster: remember how it was (Undo) and tell staff about changes to today / tomorrow.
export function mutate(user, label, dates, fn) {
  const weeks = Array.from(new Set(dates.filter(Boolean).map((d) => weekStartOf(d)).concat([weekStartOf(dateStr()), weekStartOf(addDays(dateStr(), 1))])));
  const before = snapshotWeeks(weeks);
  const res = fn();
  const after = snapshotWeeks(weeks);
  const changed = JSON.stringify(before.filter((r) => r.status === 'active').map((r) => COLS.map((c) => r[c]))) !== JSON.stringify(after.filter((r) => r.status === 'active').map((r) => COLS.map((c) => r[c])));
  if (changed) {
    const st = undoStack();
    st.push({ label, weeks, rows: before, at: stamp() });
    saveUndo(st);
    logChanges(user, before, after);
  }
  return res;
}
export function undo(user) {
  const st = undoStack();
  const last = st.pop();
  need(last, 'Nothing to undo.');
  const before = snapshotWeeks(last.weeks);
  restore(last.rows, last.weeks);
  saveUndo(st);
  logChanges(user, before, snapshotWeeks(last.weeks));
  audit({ user, action: `Roster: undid "${last.label}"`, table: 'roster_shifts' });
  return last.label;
}

// ---------------------------------------------------------------- changing the roster (all with checks)
// Add or change a shift. When something clashes the change is NOT made unless allow = true (owner/admin only);
// the result then carries the problems and the suggestions.
export function planShift(user, input, { allow = false } = {}) {
  need(input.userUid, 'Choose the person.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(txt(input.date)), 'Choose the day.');
  need(HHMM.test(txt(input.start)) && HHMM.test(txt(input.end)), 'Choose the start and finish times.');
  const chk = checkShift(input, { user });
  if (!chk.ok && !allow) return { ok: false, saved: false, ...chk };
  if (!chk.ok && allow) need(!reasonRequired(user), 'Only the owner or admin can allow a shift that clashes. Choose one of the suggestions.');
  const old = input.uid ? db().get('SELECT shift_date FROM roster_shifts WHERE uid = ?', [input.uid]) : null;
  const uid = mutate(user, `${nameOf(input.userUid)} ${dayName(input.date)} ${input.start}–${input.end}`, [input.date, old && old.shift_date], () => R.setShift(user, input));
  if (!chk.ok) audit({ user, action: `Roster: allowed anyway – ${chk.blocks.map((b) => b.text).join(' ')}`, table: 'roster_shifts', recordUid: uid });
  return { ok: true, saved: true, uid, ...chk };
}
export function dayOff(user, uid) {
  const s = db().get('SELECT * FROM roster_shifts WHERE uid = ?', [uid]);
  need(s, 'That shift is not there any more.');
  const warns = coverageLoss(s);
  mutate(user, `${nameOf(s.user_uid)} ${dayName(s.shift_date)} off`, [s.shift_date], () => R.removeShift(user, uid));
  return { ok: true, warns };
}
function coverageLoss(s) {
  if (!s.shop_code) return [];
  const before = activeShifts('shift_date = ?', [s.shift_date]);
  const b = coverage(s.shift_date, s.shop_code, before);
  const a = coverage(s.shift_date, s.shop_code, before.filter((x) => x.uid !== s.uid));
  return a.filter((x, i) => x.short > b[i].short).map((x) => ({ kind: 'short', text: `${s.shop_code} ${x.name} is now short: ${x.have} of ${x.need}.` }));
}
// Apply one of the suggestions from checkShift.
export function applySuggestion(user, input, sg) {
  if (sg.kind === 'allow') return planShift(user, input, { allow: true });
  if (sg.kind === 'move') return planShift(user, { ...input, start: sg.start, end: sg.end });
  if (sg.kind === 'free') return planShift(user, { ...input, userUid: sg.userUid });
  if (sg.kind === 'replace') return planShift(user, { ...input, uid: sg.uid });
  if (sg.kind === 'swap') {
    const x = db().get('SELECT * FROM roster_shifts WHERE uid = ?', [sg.shiftUid]);
    need(x && x.status === 'active', 'That shift has changed. Look again.');
    return mutate(user, `Swap ${nameOf(input.userUid)} and ${nameOf(x.user_uid)} ${dayName(input.date)}`, [input.date], () => {
      R.setShift(user, { uid: x.uid, userUid: x.user_uid, date: x.shift_date, shopCode: x.shop_code, start: input.start, end: input.end, breakMin: input.breakMin || 0, note: x.note });
      const id = R.setShift(user, { ...input, start: x.start_time, end: x.end_time, breakMin: x.break_min });
      return { ok: true, saved: true, uid: id, blocks: [], warns: [], suggestions: [] };
    });
  }
  throw new AppError('Unknown suggestion.');
}

// Paint mode: the brush is a quick shift { start, end, breakMin } or 'off'.
export function paint(user, { userUid, date, shopCode, brush }, opts = {}) {
  const existing = activeShifts('user_uid = ? AND shift_date = ?', [userUid, date]);
  if (brush === 'off') {
    if (!existing.length) return { ok: true };
    return mutate(user, `${nameOf(userUid)} ${dayName(date)} off`, [date], () => { existing.forEach((s) => R.removeShift(user, s.uid)); return { ok: true }; });
  }
  return planShift(user, { uid: existing[0] ? existing[0].uid : undefined, userUid, date, shopCode, start: brush.start, end: brush.end, breakMin: brush.breakMin || 0, note: brush.note }, opts);
}

// Copy a day (all its shifts in a shop) to other days. Clashing shifts are skipped and listed.
export function copyDay(user, { fromDate, toDates, shopCode }) {
  const src = activeShifts('shift_date = ? AND (? IS NULL OR shop_code = ?)', [fromDate, shopCode || null, shopCode || null]);
  need(src.length, 'That day has no shifts to copy.');
  need((toDates || []).length, 'Choose the days to copy to.');
  const skipped = [];
  let copied = 0;
  mutate(user, `Copy ${dayName(fromDate)} to ${toDates.length} day(s)`, [fromDate].concat(toDates), () => {
    for (const d of toDates) {
      if (d === fromDate) continue;
      for (const s of src) {
        const ex = activeShifts('user_uid = ? AND shift_date = ?', [s.user_uid, d]);
        const input = { uid: ex[0] ? ex[0].uid : undefined, userUid: s.user_uid, date: d, shopCode: s.shop_code, start: s.start_time, end: s.end_time, breakMin: s.break_min, note: s.note };
        const c = checkShift(input, { deep: false });
        if (!c.ok) { skipped.push({ name: nameOf(s.user_uid), date: d, why: c.blocks[0].text }); continue; }
        R.setShift(user, input);
        copied += 1;
      }
    }
  });
  audit({ user, action: `Roster: copied ${fromDate} to ${toDates.join(', ')} (${copied} shifts, ${skipped.length} skipped)`, table: 'roster_shifts' });
  return { copied, skipped };
}
// Swap two people's shifts on some days (one day or the whole week).
export function swapPeople(user, { aUid, bUid, dates, shopCode }, { allow = false } = {}) {
  need(aUid && bUid && aUid !== bUid, 'Choose two different people.');
  need((dates || []).length, 'Choose the day(s).');
  const weeks = dates.map((d) => weekStartOf(d));
  const before = snapshotWeeks(weeks.concat([weekStartOf(dateStr()), weekStartOf(addDays(dateStr(), 1))]));
  const run = () => {
    for (const d of dates) {
      const a = activeShifts('user_uid = ? AND shift_date = ? AND (? IS NULL OR shop_code = ?)', [aUid, d, shopCode || null, shopCode || null]);
      const b = activeShifts('user_uid = ? AND shift_date = ? AND (? IS NULL OR shop_code = ?)', [bUid, d, shopCode || null, shopCode || null]);
      const now = stamp();
      a.forEach((s) => db().run(`UPDATE roster_shifts SET user_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [bUid, now, deviceId(), s.uid]));
      b.forEach((s) => db().run(`UPDATE roster_shifts SET user_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [aUid, now, deviceId(), s.uid]));
    }
  };
  const res = mutate(user, `Swap ${nameOf(aUid)} and ${nameOf(bUid)}`, dates, () => {
    run();
    // Check both people afterwards; put it back when something clashes and nobody allowed it.
    const blocks = [];
    for (const d of dates) {
      for (const s of activeShifts('shift_date = ? AND user_uid IN (?, ?)', [d, aUid, bUid])) {
        const c = checkShift({ uid: s.uid, userUid: s.user_uid, date: s.shift_date, start: s.start_time, end: s.end_time, breakMin: s.break_min, shopCode: s.shop_code }, { deep: false });
        c.blocks.forEach((x) => blocks.push(x));
      }
    }
    if (blocks.length && !(allow && !reasonRequired(user))) { restore(before, before.length ? Array.from(new Set(before.map((r) => r.week_start))) : weeks); return { ok: false, blocks }; }
    return { ok: true, blocks };
  });
  if (res.ok) audit({ user, action: `Roster: swapped ${nameOf(aUid)} and ${nameOf(bUid)} on ${dates.join(', ')}`, table: 'roster_shifts' });
  return { ...res, allowAnyway: !res.ok && !reasonRequired(user) };
}
// Copy last week / usual week, through the undo list.
export function copyLastWeek(user, { weekStart: ws, shopCode }) {
  return mutate(user, 'Copy last week', weekDays(ws), () => R.copyWeek(user, { fromWeek: addDays(ws, -7), toWeek: ws, shopCode }));
}
export function fillUsualWeek(user, { weekStart: ws, shopCode }) {
  return mutate(user, 'Fill from usual weeks', weekDays(ws), () => R.fillFromUsual(user, { weekStart: ws, shopCode }));
}

// ---------------------------------------------------------------- the week: warnings, coverage, leave, changes
export function weekWarnings(anyDate, { shopCode } = {}) {
  const rules = rosterRules();
  const ws = weekStartOf(anyDate || dateStr());
  const days = weekDays(ws);
  const out = [];
  const shifts = activeShifts('week_start = ?', [ws]);
  const mine = shifts.filter((s) => !shopCode || s.shop_code === shopCode);
  const people = Array.from(new Set(mine.map((s) => s.user_uid)));
  for (const u of people) {
    const all = shifts.filter((s) => s.user_uid === u);
    for (const s of all.filter((x) => !shopCode || x.shop_code === shopCode)) {
      const c = checkShift({ uid: s.uid, userUid: u, date: s.shift_date, start: s.start_time, end: s.end_time, breakMin: s.break_min }, { deep: false });
      c.blocks.filter((b) => b.kind !== 'hours').forEach((b) => out.push({ kind: b.kind, level: b.kind === 'leave' ? 'urgent' : 'warning', userUid: u, date: s.shift_date, shiftUid: s.uid, text: `${dayName(s.shift_date)}: ${b.text}` }));
      c.warns.filter((w) => w.kind === 'leave').forEach((w) => out.push({ kind: 'leave', level: 'info', userUid: u, date: s.shift_date, shiftUid: s.uid, text: `${dayName(s.shift_date)}: ${w.text}` }));
    }
    const mins = all.reduce((a, s) => a + R.shiftMinutes(s), 0);
    if (rules.maxWeekHours > 0 && mins > rules.maxWeekHours * 60) out.push({ kind: 'hours', level: 'warning', userUid: u, text: `${nameOf(u)}: ${hm(mins)} this week (limit ${rules.maxWeekHours} hours).` });
  }
  const shops = shopCode ? [shopCode] : Object.keys(rules.needs);
  for (const sc of shops) for (const d of days) coverage(d, sc).filter((x) => x.short).forEach((x) => out.push({ kind: 'short', level: d <= addDays(dateStr(), 1) ? 'urgent' : 'warning', date: d, shopCode: sc, text: `${dayName(d)} ${Number(d.slice(8))} ${sc} ${x.name} ${x.start}–${x.end}: ${x.have} of ${x.need} staff – short by ${x.short}.` }));
  // Same text only once.
  const seen = new Set();
  return out.filter((w) => (seen.has(w.text) ? false : (seen.add(w.text), true)));
}
// Approved / asked leave per person per day in a week (for the grid).
export function weekLeave(anyDate) {
  const ws = weekStartOf(anyDate || dateStr());
  const to = addDays(ws, 6);
  const out = {};
  try {
    db().all(`SELECT r.user_uid, r.from_date, r.to_date, r.status, r.type, t.name AS type_name FROM leave_requests r LEFT JOIN leave_types t ON t.code = r.type WHERE r.status IN ('approved','requested') AND r.from_date <= ? AND r.to_date >= ?`, [to, ws])
      .forEach((r) => { for (const d of weekDays(ws)) if (r.from_date <= d && r.to_date >= d && !(out[`${r.user_uid}|${d}`] && out[`${r.user_uid}|${d}`].status === 'approved')) out[`${r.user_uid}|${d}`] = { status: r.status, type: r.type_name || r.type }; });
  } catch (e) { /* no leave module */ }
  return out;
}
// Today's and tomorrow's changes (for highlighting in the grid and for the manager).
export function recentChanges({ userUid } = {}) {
  const today = dateStr();
  return db().all(`SELECT * FROM roster_changes WHERE shift_date >= ? AND shift_date <= ? AND (? IS NULL OR user_uid = ?) ORDER BY changed_at DESC`, [today, addDays(today, 1), userUid || null, userUid || null]);
}
export function changedCells() {
  const m = {};
  recentChanges().forEach((c) => { m[`${c.user_uid}|${c.shift_date}`] = m[`${c.user_uid}|${c.shift_date}`] || c; });
  return m;
}
// For the person themselves: changes not seen yet.
export function unseenChanges(userUid) {
  return recentChanges({ userUid }).filter((c) => !c.seen_at);
}
export function markSeen(user) {
  const now = stamp();
  db().run(`UPDATE roster_changes SET seen_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE user_uid = ? AND seen_at IS NULL`, [now, now, deviceId(), user.uid]);
}
// My shifts: this week and next (for the person's own roster screen).
export function myShifts(userUid, from = dateStr(), days = 14) {
  return activeShifts('user_uid = ? AND shift_date BETWEEN ? AND ?', [userUid, from, addDays(from, days - 1)]);
}

// Warnings for Home (timesheets module): my changed shift, and the manager's view of short days and clashes.
export function rosterAlerts(user, can) {
  const out = [];
  if (!user) return out;
  const mine = unseenChanges(user.uid);
  for (const c of mine.slice(0, 3)) {
    out.push({ id: `roster-chg-${c.uid}`, level: 'warning', notify: true, area: 'timesheets', text: `Your shift ${c.shift_date === dateStr() ? 'today' : 'tomorrow'} changed: ${c.after_text}`, sub: `It was ${c.before_text}. Tap to see your roster and tick "Seen".`, nav: { screen: 'MyRoster', params: {} } });
  }
  if (can && can(user, 'timesheets_view')) {
    const w = weekWarnings(dateStr()).filter((x) => (x.date === dateStr() || x.date === addDays(dateStr(), 1)) && x.level !== 'info');
    for (const x of w.slice(0, 5)) out.push({ id: `roster-${x.kind}-${x.date}-${x.shiftUid || x.shopCode || ''}`, level: x.kind === 'short' || x.kind === 'leave' ? 'urgent' : 'warning', area: 'timesheets', text: `Roster: ${x.text}`, nav: { screen: 'RosterPlanner', params: { date: x.date, shopCode: x.shopCode } } });
    const notSeen = recentChanges().filter((c) => !c.seen_at && c.user_uid !== user.uid);
    if (notSeen.length) out.push({ id: `roster-unseen-${notSeen.length}`, level: 'info', area: 'timesheets', text: `${notSeen.length} roster change${notSeen.length === 1 ? '' : 's'} not seen by staff yet`, sub: notSeen.slice(0, 3).map((c) => `${nameOf(c.user_uid)}: ${c.after_text}`).join(' · '), nav: { screen: 'RosterPlanner', params: { date: dateStr() } } });
  }
  return out;
}

// ---------------------------------------------------------------- the shareable roster (PDF / Excel / picture)
export function rosterReport(anyDate, { shopCode } = {}) {
  const p = R.weekPlan(anyDate, { shopCode });
  const lv = weekLeave(p.weekStart);
  const cell = (x, d) => {
    const l = lv[`${x.user.uid}|${d}`];
    const s = x.byDay[d];
    if (s.length) return s.map((y) => `${y.start_time}–${y.end_time}`).join(', ') + (l ? ' (leave!)' : '');
    return l ? `Leave${l.status === 'requested' ? '?' : ''}` : 'Off';
  };
  const rows = p.people.filter((x) => x.minutes || p.days.some((d) => lv[`${x.user.uid}|${d}`])).map((x) => ({ name: x.user.name, ...Object.fromEntries(p.days.map((d) => [d, cell(x, d)])), hours: x.hours }));
  const per = p.days.map((d) => `${dayName(d)} ${p.perDay[d].people}`).join(' · ');
  return {
    kind: 'tc_roster', title: `Roster ${shopCode || 'all shops'}`, fileName: `Roster-${shopCode || 'all'}-${p.weekStart}`,
    subtitle: `Easy Buys Shopping Centre · week ${p.weekStart} to ${addDays(p.weekStart, 6)}`,
    info: [['Week', `${p.weekStart} to ${addDays(p.weekStart, 6)}`], ['Shop', shopCode || 'All'], ['Generated', stamp()]],
    summary: [{ label: 'People', value: String(rows.length) }, { label: 'Hours', value: hm(p.totalMinutes) }],
    sections: [{ title: 'Who works when', columns: [{ key: 'name', title: 'Name', align: 'left' }].concat(p.days.map((d) => ({ key: d, title: `${dayName(d)} ${d.slice(8)}`, align: 'left' }))).concat([{ key: 'hours', title: 'Hours', align: 'right' }]),
      rows, note: `People on each day: ${per}. Ask the manager about any change.` }],
  };
}
