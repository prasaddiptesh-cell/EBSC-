// v3.9.5 Mark a day (Work / Day off / Leave / Sick / Absent) and the absence record.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Chips, Field, Label, Select, PhotoPicker, Section, Table, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, Hint, Stats } from '../../../ui/kit.js';
import { dateStr, dayName } from '../../../services/core.js';
import { listUsers } from '../../../services/catalog.js';
import * as A from '../absence.js';

export function MarkDayScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const people = listUsers().filter((u) => u.active && u.sync_status !== 'seed');
  const [who, setWho] = useState(params.userUid || '');
  const [date] = useState(params.date || dateStr());
  const cur = who ? A.markOf(who, date) : null;
  const [kind, setKind] = useState(params.kind || (cur ? cur.kind : 'absent'));
  const [reason, setReason] = useState('');
  const [pick, setPick] = useState('');
  const [sheet, setSheet] = useState(null); // null = not answered, true / false
  const [photos, setPhotos] = useState([]);
  const [leaveType, setLeaveType] = useState('ANNUAL');
  let types = [];
  try { types = require('../../leave/service.js').listLeaveTypes().filter((t) => t.active !== 0 && t.code !== 'SICK'); } catch (e) { types = []; }
  const person = people.find((u) => u.uid === who);
  const save = () => {
    const why = kind === 'absent' ? [pick && pick !== 'Other' ? pick : '', reason].filter(Boolean).join(' – ') : reason;
    const r = act(() => A.markDay(user, { userUid: who, date, kind, reason: why, sheet: kind === 'sick' ? sheet === true : false, photos, leaveType }),
      kind === 'work' ? 'Marked as working' : `Saved: ${A.MARK_LABEL[kind]}${kind === 'sick' ? (sheet ? ' (paid sick leave)' : ' (unpaid)') : kind === 'absent' ? ' (unpaid)' : ''}`);
    if (r !== null) {
      if (kind === 'absent' || (kind === 'sick' && !sheet)) { try { require('../../verify/service.js').notify('absent', `${person ? person.name : 'Staff'} ${kind === 'sick' ? 'sick (no sheet – unpaid)' : `absent – ${why}`} on ${date}. Marked by ${user.name}.`, { shopCode: person ? person.shop_code : undefined }); } catch (e) { /* optional */ } }
      nav.pop();
    }
  };
  return (
    <Screen title="What was this day?" subtitle={`${person ? person.name : 'Choose the person'} · ${dayName(date)} ${date}`}
      footer={who ? <Btn testID="md-save" title="Save" icon="💾" variant="success" onPress={save} /> : null}>
      {!params.userUid ? <Select testID="md-who" label="Person" value={who} onChange={setWho} search options={people.map((u) => ({ value: u.uid, label: u.name }))} /> : null}
      {cur ? <Hint>{`Now marked: ${A.MARK_LABEL[cur.kind]}${cur.reason ? ` – ${cur.reason}` : ''} (by ${cur.by_name}).`}</Hint> : null}
      <Chips value={kind} onChange={setKind} testIDPrefix="md-k" options={[{ value: 'work', label: '✅ Working (late is fine)' }, { value: 'off', label: '🛌 Day off' }, { value: 'leave', label: '🌴 Leave' }, { value: 'sick', label: '🤒 Sick' }, { value: 'absent', label: '❌ Absent' }]} />
      {kind === 'leave' ? (
        <Card>
          <Label>Type of leave</Label>
          <Chips value={leaveType} onChange={setLeaveType} testIDPrefix="md-lt" options={types.map((t) => ({ value: t.code, label: `${t.name}${t.paid ? '' : ' (unpaid)'}` }))} />
          <Hint>Entered and approved now (asked in person). It comes off the leave balance; paid leave is in the pay run by itself.</Hint>
        </Card>
      ) : null}
      {kind === 'sick' ? (
        <Card>
          <Label>Did they bring a sick sheet (medical certificate)?</Label>
          <Chips value={sheet === null ? '' : sheet ? 'yes' : 'no'} onChange={(v) => setSheet(v === 'yes')} testIDPrefix="md-sheet" options={[{ value: 'yes', label: 'Yes – sick sheet' }, { value: 'no', label: 'No sheet' }]} />
          {sheet === true ? <PhotoPicker testID="md-photo" label="Photo of the sick sheet" value={photos} onChange={setPhotos} required /> : null}
          <Hint>{sheet === true ? 'With a sheet: paid sick leave from their balance.' : sheet === false ? 'No sheet: unpaid. It is recorded as absent with the reason "sick, no sheet".' : 'A sick sheet means paid sick leave; no sheet means an unpaid day.'}</Hint>
        </Card>
      ) : null}
      {kind === 'absent' ? (
        <Card>
          <Label>Why?</Label>
          <Chips value={pick} onChange={setPick} testIDPrefix="md-r" options={A.ABSENT_REASONS.filter((r) => r !== 'Sick, no sheet').map((r) => ({ value: r, label: r }))} />
          <Hint>An absent day is unpaid. It shows in the absence record.</Hint>
        </Card>
      ) : null}
      {kind !== 'work' ? <Field testID="md-note" label={kind === 'absent' ? (pick === 'Other' || !pick ? 'Reason (needed)' : 'More detail (optional)') : 'Note (optional)'} value={reason} onChangeText={setReason} /> : null}
      {kind === 'off' ? <Hint>Their shift that day comes off the roster. Usual week: 6 days on, 1 day off.</Hint> : null}
    </Screen>
  );
}

const ym = (d) => d.slice(0, 7);
export function AbsenceScreen() {
  const { nav } = useApp();
  const [period, setPeriod] = useState('month');
  const [month, setMonth] = useState(ym(dateStr()));
  const year = month.slice(0, 4);
  const [from, to] = period === 'month' ? A.monthRange(month) : [`${year}-01-01`, `${year}-12-31`];
  const rows = A.absenceRecord({ from, to });
  let late = [];
  try { late = A.lateStarts(from, to); } catch (e) { late = []; }
  const lateBy = late.reduce((m, x) => { m[x.userUid] = (m[x.userUid] || 0) + 1; return m; }, {});
  const shift = (n) => { const [y, m] = month.split('-').map(Number); const d = new Date(Date.UTC(y, m - 1 + n, 1)); setMonth(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`); };
  const sum = (k) => rows.reduce((a, r) => a + r[k], 0);
  return (
    <Screen title="Absence record" subtitle={period === 'month' ? month : year}>
      <Chips value={period} onChange={setPeriod} testIDPrefix="ab-p" options={[{ value: 'month', label: 'Month' }, { value: 'year', label: 'Year' }]} />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn testID="ab-prev" title="‹" size="sm" variant="secondary" onPress={() => shift(period === 'month' ? -1 : -12)} />
        <Btn title="This month" size="sm" variant="secondary" onPress={() => setMonth(ym(dateStr()))} />
        <Btn testID="ab-next" title="›" size="sm" variant="secondary" onPress={() => shift(period === 'month' ? 1 : 12)} />
        <Btn testID="ab-mark" title="Mark a day" icon="➕" size="sm" variant="info" onPress={() => nav.push('MarkDay', {})} />
      </View>
      <Stats items={[{ label: 'Absent', value: String(sum('absent')), color: sum('absent') ? C.danger : undefined }, { label: 'Sick with sheet', value: String(sum('sickPaid')) },
        { label: 'Sick, no sheet', value: String(sum('sickUnpaid')), color: sum('sickUnpaid') ? C.warn : undefined }, { label: 'Late starts', value: String(late.length) }]} />
      {!rows.length && !late.length ? <Hint>No absences, sick days or late starts in this period.</Hint> : null}
      <Table testID="ab-table" columns={[{ key: 'name', title: 'Person', width: 160 }, { key: 'absent', title: 'Absent', width: 80 }, { key: 'sickPaid', title: 'Sick ✓', width: 80 }, { key: 'sickUnpaid', title: 'Sick ✗', width: 80 }, { key: 'leave', title: 'Leave', width: 80 }, { key: 'late', title: 'Late', width: 70 }, { key: 'unpaid', title: 'Unpaid days', width: 110 }]}
        rows={rows.map((r) => ({ ...r, late: lateBy[r.userUid] || 0 })).concat(Object.keys(lateBy).filter((u) => !rows.some((r) => r.userUid === u)).map((u) => {
          const p = listUsers().find((x) => x.uid === u);
          return { name: p ? p.name : u, absent: 0, sickPaid: 0, sickUnpaid: 0, leave: 0, late: lateBy[u], unpaid: 0 };
        }))} />
      {rows.map((r) => (
        <Section key={r.userUid} title={r.name}>
          {r.days.map((d) => <Text key={d.date} style={{ fontSize: 15, color: d.paid ? C.text : C.danger }}>{`${dayName(d.date)} ${d.date} · ${A.MARK_LABEL[d.kind]}${d.reason ? ` – ${d.reason}` : ''}${d.paid ? ' (paid)' : d.kind === 'off' ? '' : ' (unpaid)'}`}</Text>)}
        </Section>
      ))}
    </Screen>
  );
}
