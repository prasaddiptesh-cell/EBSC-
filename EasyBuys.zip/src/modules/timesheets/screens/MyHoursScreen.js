// Anyone logged in: my hours this week and last week, and my leave left.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Badge, Section, Row, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { addDays, dateStr, dayName, hhmm } from '../../../services/core.js';
import { personWeek, hm, FLAG_LABEL, PROBLEM_FLAGS } from '../service.js';
import { balances } from '../../leave/service.js';
import { stateOf } from '../../timeclock/service.js';

export default function MyHoursScreen() {
  const { user, nav } = useApp();
  const [date, setDate] = useState(dateStr());
  const w = personWeek(user.uid, date);
  const st = stateOf(user.uid);
  const bal = balances(user.uid).filter((b) => b.limited || b.taken || b.waiting);
  return (
    <Screen title="My hours" subtitle={`Week ${w.weekStart} to ${w.weekEnd}`}
      footer={<Btn testID="my-ask-leave" title="Ask for leave" icon="🌴" onPress={() => nav.push('Leave', { tab: 'mine' })} />}>
      <Card tone={st.state === 'in' ? 'success' : st.state === 'break' ? 'warn' : undefined}>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>
          {st.state === 'in' ? `Clocked in since ${hhmm(st.since)}` : st.state === 'break' ? `On break since ${hhmm(st.since)}` : 'Not clocked in'}
        </Text>
      </Card>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Previous" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(w.weekStart, -7))} />
        <Btn title="This week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(dateStr())} />
      </View>
      <Section title={`Total: ${hm(w.totalMinutes)} hours`} right={w.check && w.check.status === 'checked' ? <Badge text="✓ Checked by manager" color={C.success} /> : null}>
        {!w.shifts.length ? <Text style={{ fontSize: 16, color: C.sub }}>No shifts this week.</Text> : null}
        {w.shifts.map((s, i) => (
          <Card key={i} tone={s.problems ? 'warn' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, minWidth: 90 }}>{dayName(s.date)} {s.date.slice(8)}/{s.date.slice(5, 7)}</Text>
              <Text style={{ fontSize: 17, color: C.text }}>{s.in_at ? hhmm(s.in_at) : '??'} – {s.out_at ? hhmm(s.out_at) : '??'}</Text>
              <View style={{ flex: 1 }} />
              <Text style={{ fontSize: 19, fontWeight: '900', color: C.text }}>{hm(s.workedMinutes)}</Text>
            </View>
            {s.flags.filter((f) => PROBLEM_FLAGS.includes(f)).map((f) => <Text key={f} style={{ fontSize: 14, color: C.warn }}>{FLAG_LABEL[f]} – the manager will check it</Text>)}
          </Card>
        ))}
      </Section>
      <Section title="My leave this year">
        {bal.map((b) => <Row key={b.type} label={b.name} value={b.limited ? `${b.left} left of ${b.allowed}${b.waiting ? ` (${b.waiting} waiting)` : ''}` : `${b.taken} taken`} />)}
      </Section>
    </Screen>
  );
}
