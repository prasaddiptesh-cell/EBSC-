// Roster planner (planning only), plan against what was actually worked, and who is on now.
import React, { useState } from 'react';
import { View, Pressable, Modal, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useUI, useLayout, useTick } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Stats, Hint, Explain } from '../../../ui/kit.js';
import { ClockFacePicker, nice, TimeField } from '../../../ui/timePicker.js';
import { dateStr, addDays, money } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import { hm } from '../service.js';
import * as R from '../roster.js';

const shopOpts = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayLabel = (d) => `${WD[new Date(`${d}T00:00:00`).getDay()]} ${Number(d.slice(8, 10))}`;
let lastShop = null;

// ---------------------------------------------------------------- planner
export function RosterPlannerScreen({ params }) {
  const { user, can } = useApp();
  const act = useAct();
  const ui = useUI();
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date || addDays(dateStr(), 7));
  const [shop, setShopS] = useState(params.shopCode || lastShop || user.shop_code || 'S1');
  const setShop = (v) => { lastShop = v; setShopS(v); };
  const [edit, setEdit] = useState(null); // { userUid, name, date, uid?, start, end, breakMin, note }
  const [pick, setPick] = useState(null); // 'start' | 'end'
  const p = R.weekPlan(date, { shopCode: shop });
  const st = R.rosterSettings();
  const editable = can('timesheets_edit');
  const open = (u, d, s) => setEdit(s ? { userUid: u.uid, name: u.name, date: d, uid: s.uid, start: s.start_time, end: s.end_time, breakMin: String(s.break_min || 0), note: s.note || '' }
    : { userUid: u.uid, name: u.name, date: d, start: st.templates[0] ? st.templates[0].start : '08:00', end: st.templates[0] ? st.templates[0].end : '17:00', breakMin: String(st.templates[0] ? st.templates[0].breakMin : 30), note: '' });
  const save = () => { if (act(() => R.setShift(user, { uid: edit.uid, userUid: edit.userUid, date: edit.date, shopCode: shop, start: edit.start, end: edit.end, breakMin: edit.breakMin, note: edit.note }), 'Saved')) setEdit(null); };
  const cellW = isPhone ? 74 : 112;
  return (
    <Screen title="Roster planner" subtitle={`${shop} · week ${p.weekStart} – ${addDays(p.weekStart, 6)}`}>
      <Explain title="What the roster is for">
        The roster is a plan: who should work when. It never stops anyone clocking in. The Time Clock shows who is late against it, the timesheet can fill rostered times
        with one tap, and "Planned against worked" shows the difference each week. Tap a box to add or change a shift.
      </Explain>
      <Chips value={shop} onChange={setShop} options={shopOpts()} testIDPrefix="rp-shop" />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn title="‹ Week" size="sm" variant="secondary" onPress={() => setDate(addDays(p.weekStart, -7))} />
        <Btn title="This week" size="sm" variant="secondary" onPress={() => setDate(dateStr())} />
        <Btn title="Next week" size="sm" variant="secondary" onPress={() => setDate(addDays(dateStr(), 7))} />
        <Btn title="Week ›" size="sm" variant="secondary" onPress={() => setDate(addDays(p.weekStart, 7))} />
      </View>
      <Stats items={[{ label: 'Planned hours', value: hm(p.totalMinutes) }, { label: 'Planned wages', value: money(p.totalCost), sub: 'from pay rates' }, { label: 'People', value: String(p.people.filter((x) => x.minutes).length) }]} />
      {editable ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="rp-copy" title="Copy last week" icon="⧉" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = R.copyWeek(user, { fromWeek: addDays(p.weekStart, -7), toWeek: p.weekStart, shopCode: shop }); ui.toast(`${n} shift(s) copied`); })} />
          <Btn testID="rp-usual" title="Fill from usual weeks" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = R.fillFromUsual(user, { weekStart: p.weekStart, shopCode: shop }); ui.toast(`${n} shift(s) added`); })} />
          {st.calendar ? <Btn testID="rp-cal" title="Send to Google Calendar" icon="📅" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = R.publishWeek(user, p.weekStart); ui.toast(`${n} shift(s) will be sent when online`); })} /> : null}
        </View>
      ) : null}
      <ScrollView horizontal>
        <View>
          <View style={{ flexDirection: 'row' }}>
            <Text style={{ width: isPhone ? 110 : 170, fontWeight: '800', color: C.sub, padding: 6 }}>Person</Text>
            {p.days.map((d) => <Text key={d} style={{ width: cellW, fontWeight: '800', color: d === dateStr() ? C.primary : C.sub, padding: 6, textAlign: 'center' }}>{dayLabel(d)}{'\n'}{p.perDay[d].people ? `${p.perDay[d].people} on` : ''}</Text>)}
            <Text style={{ width: 80, fontWeight: '800', color: C.sub, padding: 6, textAlign: 'right' }}>Hours</Text>
          </View>
          {p.people.map((x) => (
            <View key={x.user.uid} style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.border }}>
              <Text style={{ width: isPhone ? 110 : 170, padding: 6, fontWeight: '700', color: C.text }} numberOfLines={2}>{x.user.name}</Text>
              {p.days.map((d) => {
                const s = x.byDay[d][0];
                return (
                  <Pressable key={d} testID={`rp-${x.user.employee_no || x.user.name}-${d}`} disabled={!editable} onPress={() => open(x.user, d, s)}
                    style={{ width: cellW - 4, margin: 2, minHeight: 50, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: s ? C.infoSoft : '#F6F2EC', borderWidth: 1, borderColor: s ? C.info : C.border }}>
                    <Text style={{ fontSize: isPhone ? 12 : 14, fontWeight: '800', color: s ? C.info : C.sub }}>{s ? `${nice(s.start_time).replace(':00', '')}\n${nice(s.end_time).replace(':00', '')}` : '+'}</Text>
                  </Pressable>
                );
              })}
              <Text style={{ width: 80, padding: 6, textAlign: 'right', fontWeight: '800', color: C.text }}>{x.hours}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      {edit ? (
        <Modal visible transparent animationType="fade" onRequestClose={() => setEdit(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 12 }}>
            <ScrollView style={{ maxWidth: 520, width: '100%' }} contentContainerStyle={{ backgroundColor: C.card, borderRadius: 18, padding: 18, gap: 10 }}>
              <H>{edit.name} · {dayLabel(edit.date)}</H>
              <Label>Quick shifts</Label>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {st.templates.map((t) => <Btn key={t.name} testID={`rp-t-${t.name}`} title={`${t.name} ${nice(t.start)}–${nice(t.end)}`} size="sm" variant="info" onPress={() => setEdit({ ...edit, start: t.start, end: t.end, breakMin: String(t.breakMin) })} />)}
              </View>
              {pick ? (
                <>
                  <ClockFacePicker value={edit[pick]} onChange={(v) => setEdit({ ...edit, [pick]: v })} />
                  <Btn title="OK" size="md" variant="primary" onPress={() => setPick(null)} />
                </>
              ) : (
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <Btn testID="rp-start" title={`Start ${nice(edit.start)}`} size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setPick('start')} />
                  <Btn testID="rp-end" title={`Finish ${nice(edit.end)}`} size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setPick('end')} />
                </View>
              )}
              <Field label="Break (minutes)" value={edit.breakMin} onChangeText={(v) => setEdit({ ...edit, breakMin: v.replace(/\D/g, '') })} keyboardType="number-pad" />
              <Field label="Note (e.g. till 2, stock delivery)" value={edit.note} onChangeText={(v) => setEdit({ ...edit, note: v })} />
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {edit.uid ? <Btn testID="rp-remove" title="Day off" size="md" variant="danger" style={{ flex: 1 }} onPress={() => { act(() => R.removeShift(user, edit.uid), 'Removed'); setEdit(null); }} /> : null}
                <Btn title="Cancel" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setEdit(null); setPick(null); }} />
                <Btn testID="rp-save" title="Save" size="md" variant="success" style={{ flex: 1 }} onPress={save} />
              </View>
            </ScrollView>
          </View>
        </Modal>
      ) : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- planned against worked
const ST = { ok: ['✓', C.success], late: ['late', C.warn], absent: ['absent', C.danger], not_in: ['not in', C.warn], extra: ['not planned', C.info], planned: ['', C.sub], off: ['', C.sub] };
export function PlanVsActualScreen({ params }) {
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShop] = useState(params.shopCode || lastShop || 'S1');
  const r = R.planVsActual(date, { shopCode: shop });
  return (
    <Screen title="Planned against worked" subtitle={`${shop} · week ${r.weekStart}`}>
      <Hint>The roster (plan) next to what the Time Clock recorded. Late = clocked in after the planned start. Absent = planned but no clock-in.</Hint>
      <Chips value={shop} onChange={setShop} options={shopOpts()} />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Week" size="sm" variant="secondary" onPress={() => setDate(addDays(r.weekStart, -7))} />
        <Btn title="This week" size="sm" variant="secondary" onPress={() => setDate(dateStr())} />
        <Btn title="Week ›" size="sm" variant="secondary" onPress={() => setDate(addDays(r.weekStart, 7))} />
      </View>
      <Stats items={[
        { label: 'Planned', value: hm(r.plannedMin), sub: money(r.plannedCost) }, { label: 'Worked', value: hm(r.workedMin), sub: money(r.actualCost), color: r.workedMin > r.plannedMin ? C.warn : undefined },
        { label: 'Late', value: String(r.late), color: r.late ? C.warn : undefined }, { label: 'Absent', value: String(r.absent), color: r.absent ? C.danger : undefined },
      ]} />
      {r.rows.map((x) => (
        <Card key={x.user.uid}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{x.user.name}</Text>
            <Text style={{ fontSize: 15, color: x.diffMin > 30 ? C.warn : C.sub }}>planned {hm(x.plannedMin)} · worked {hm(x.workedMin)}</Text>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4 }}>
            {x.days.map((d) => (
              <View key={d.date} style={{ flexGrow: 1, flexBasis: 80, borderRadius: 8, padding: 6, backgroundColor: '#F6F2EC' }}>
                <Text style={{ fontSize: 12, color: C.sub, fontWeight: '800' }}>{dayLabel(d.date)}</Text>
                <Text style={{ fontSize: 12, color: C.text }}>{d.planned || '—'}</Text>
                <Text style={{ fontSize: 13, color: C.text, fontWeight: '700' }}>{d.workedMin ? hm(d.workedMin) : ''}</Text>
                {ST[d.status][0] ? <Text style={{ fontSize: 12, fontWeight: '800', color: ST[d.status][1] }}>{ST[d.status][0]}{d.status === 'late' ? ` ${d.late}m` : ''}</Text> : null}
              </View>
            ))}
          </View>
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- who is on now
const NOW = { due: ['Due now', C.warn], in: ['At work', C.success], break: ['On break', C.info], late: ['LATE – not in', C.danger], later: ['Starts later', C.sub], finished: ['Finished', C.sub], off: ['Off', C.sub] };
export function WhoIsOnScreen({ params }) {
  useTick(30000);
  const [shop, setShop] = useState(params.shopCode || lastShop || 'S1');
  const list = R.whoIsOn(shop);
  const still = R.stillIn(12);
  return (
    <Screen title="Who is on now" subtitle={`${shop} · ${new Date().toTimeString().slice(0, 5)}`}>
      <Chips value={shop} onChange={setShop} options={shopOpts()} testIDPrefix="won-shop" />
      {still.length ? <Banner tone="warn" title="Still clocked in after 12 hours" message={still.map((s) => `${s.name} since ${s.since.slice(0, 16)}`).join('\n')} /> : null}
      <Stats items={['in', 'break', 'late'].map((k) => ({ label: NOW[k][0], value: String(list.filter((x) => x.status === k).length), color: k === 'late' && list.some((x) => x.status === 'late') ? C.danger : undefined }))} />
      {!list.length ? <Text style={{ color: C.sub }}>Nobody planned or clocked in today.</Text> : null}
      {list.map((x) => (
        <ListItem key={x.user.uid} title={x.user.name} sub={`${x.plan ? `planned ${nice(x.plan.start)}–${nice(x.plan.end)}` : 'not planned'}${x.since ? ` · in since ${nice(x.since)}` : ''}${x.late ? ` · ${x.late} min late` : ''}`}
          right={x.worked ? hm(x.worked) : ''} badge={NOW[x.status][0]} badgeColor={NOW[x.status][1]} tone={x.status === 'late' ? 'danger' : undefined} />
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- roster settings (admin)
export function RosterSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [s, setS] = useState(R.rosterSettings());
  return (
    <Screen title="Roster settings" subtitle="Admin">
      <Section title="Quick shifts">
        {s.templates.map((t, i) => (
          <View key={i} style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <View style={{ flexBasis: 140, flexGrow: 1 }}><Field label="Name" value={t.name} onChangeText={(v) => setS({ ...s, templates: s.templates.map((x, k) => (k === i ? { ...x, name: v } : x)) })} /></View>
            <View style={{ flexBasis: 220, flexGrow: 1 }}><TimeField testID={`rs-start-${i}`} label="Start" showNow={false} value={t.start} onChange={(v) => setS({ ...s, templates: s.templates.map((x, k) => (k === i ? { ...x, start: v } : x)) })} /></View>
            <View style={{ flexBasis: 220, flexGrow: 1 }}><TimeField testID={`rs-end-${i}`} label="Finish" showNow={false} value={t.end} onChange={(v) => setS({ ...s, templates: s.templates.map((x, k) => (k === i ? { ...x, end: v } : x)) })} /></View>
            <View style={{ flexBasis: 90, flexGrow: 1 }}><Field label="Break min" value={String(t.breakMin)} onChangeText={(v) => setS({ ...s, templates: s.templates.map((x, k) => (k === i ? { ...x, breakMin: v } : x)) })} keyboardType="number-pad" /></View>
            <Btn title="✕" size="sm" variant="ghost" onPress={() => setS({ ...s, templates: s.templates.filter((_, k) => k !== i) })} />
          </View>
        ))}
        <Btn title="+ Quick shift" size="sm" variant="secondary" onPress={() => setS({ ...s, templates: s.templates.concat([{ name: '', start: '08:00', end: '17:00', breakMin: 30 }]) })} />
      </Section>
      <Section title="Time Clock">
        <Field label="Ask why when more than this many minutes late / leaving early (0 = never ask)" value={String(s.lateReasonAfter)} onChangeText={(v) => setS({ ...s, lateReasonAfter: v })} keyboardType="number-pad" />
        <Hint>Asking never stops anyone clocking in – it only notes the reason for the manager.</Hint>
      </Section>
      <Section title="Google Calendar">
        <Chips value={s.calendar ? 'y' : 'n'} onChange={(v) => setS({ ...s, calendar: v === 'y' })} testIDPrefix="rs-cal" options={[{ value: 'n', label: 'Off' }, { value: 'y', label: 'Send the roster to Google Calendar' }]} />
        <Hint>When on, "Send to Google Calendar" on the planner puts each shop's week into a calendar called "Easy Buys Roster – shop" in the Google account the Easy Buys cloud runs on. Share that calendar with staff from Google Calendar (once).</Hint>
      </Section>
      <Btn testID="rs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => R.saveRosterSettings(user, s), 'Saved')} />
    </Screen>
  );
}
