// v3.5 roster planner: week grid (people × days, colour-coded) with hours and cost, paint mode, tap menu, long-press copy,
// copy last week / usual week / a day to other days, swap two people, staff needed per shift, warnings, undo,
// today / tomorrow changes highlighted, share as picture or PDF, one day at a time on a phone. When a change is not
// possible the app suggests what to do instead. Also: My roster (for staff) and the roster rules (admin).
import React, { useState, useRef } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Section, Label, Choice, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Stats, Hint, Explain, TimeField } from '../../../ui/kit.js';
import { nice } from '../../../ui/timePicker.js';
import { dateStr, addDays, money, dayName } from '../../../services/core.js';
import { listShops } from '../../admin/service.js';
import { shareReport } from '../../../platform/files.js';
import { sharePicture } from '../../../platform/viewShot.js';
import { hm } from '../service.js';
import * as R from '../roster.js';
import * as X from '../rosterPlus.js';
import { SafeModal } from '../../../ui/safeModal.js';

const shopOpts = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayLabel = (d) => `${WD[new Date(`${d}T00:00:00`).getDay()]} ${Number(d.slice(8, 10))}`;
const short = (t) => nice(t).replace(':00', '').replace(' ', '');
const tid = (u) => u.employee_no || u.name;
let lastShop = null;

// One box of the grid.
// v3.9.5 a marked day (Day off / Leave / Sick / Absent) shows what it was.
const MARK_COL = { off: { bg: '#EDE7E3', fg: '#6B6160' }, leave: { bg: '#E1EAFB', fg: '#2F5FC4' }, sick: { bg: '#FEF0C7', fg: '#B45309' }, absent: { bg: '#FBE4E4', fg: '#C8242A' } };
const markText = (m) => (m.kind === 'off' ? 'Day off' : m.kind === 'leave' ? 'Leave' : m.kind === 'sick' ? (m.sheet ? 'Sick ✓sheet' : 'Sick – unpaid') : 'Absent');
function Cell({ s, lv, mark, changed, warn, w, onPress, onLongPress, testID, compact }) {
  if (mark && !s) {
    const mc = MARK_COL[mark.kind] || MARK_COL.off;
    return (
      <Pressable testID={testID} onPress={onPress} onLongPress={onLongPress}
        style={{ width: w, margin: 2, minHeight: compact ? 44 : 52, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 2, backgroundColor: mc.bg, borderWidth: 1, borderColor: mc.fg }}>
        <Text style={{ fontSize: compact ? 12 : 13, fontWeight: '800', color: mc.fg, textAlign: 'center' }}>{markText(mark)}</Text>
      </Pressable>
    );
  }
  const k = s ? X.shiftKind(s) : lv ? 'leave' : 'off';
  const col = X.SHIFT_COLOURS[k];
  return (
    <Pressable testID={testID} onPress={onPress} onLongPress={onLongPress}
      style={{ width: w, margin: 2, minHeight: compact ? 44 : 52, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 2,
        backgroundColor: col.bg, borderWidth: changed || warn ? 3 : 1, borderColor: warn ? C.danger : changed ? C.warn : s ? col.fg : C.border }}>
      <Text style={{ fontSize: compact ? 12 : 13, fontWeight: '800', color: col.fg, textAlign: 'center' }}>
        {s ? `${short(s.start_time)}–${short(s.end_time)}` : lv ? (lv.status === 'approved' ? 'Leave' : 'Leave?') : '+'}
      </Text>
      {s && lv ? <Text style={{ fontSize: 10, color: C.danger, fontWeight: '800' }}>on leave!</Text> : null}
      {changed ? <Text style={{ fontSize: 10, color: C.warn, fontWeight: '800' }}>changed</Text> : null}
    </Pressable>
  );
}

// ---------------------------------------------------------------- planner
export function RosterPlannerScreen({ params }) {
  const { user, can, nav } = useApp();
  const act = useAct();
  const ui = useUI();
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShopS] = useState(params.shopCode || lastShop || user.shop_code || 'S1');
  const setShop = (v) => { lastShop = v; setShopS(v); };
  const [mode, setMode] = useState('tap');          // 'tap' | 'paint'
  const [brush, setBrush] = useState(0);            // template index or 'off'
  const [clip, setClip] = useState(null);           // copied shift
  const [menu, setMenu] = useState(null);           // { user, date, s }
  const [edit, setEdit] = useState(null);           // shift being changed
  const [sugg, setSugg] = useState(null);           // { input, res }
  const [dayMenu, setDayMenu] = useState(null);     // date
  const [copyTo, setCopyTo] = useState(null);       // { from, to: [] }
  const [swap, setSwap] = useState(null);           // { a, b, dates }
  const [share, setShare] = useState(false);
  const [phoneDay, setPhoneDay] = useState(params.date || dateStr());
  const [, bump] = useState(0);
  const pic = useRef(null);
  const refresh = () => bump((x) => x + 1);
  const p = R.weekPlan(date, { shopCode: shop });
  const st = R.rosterSettings();
  const rules = X.rosterRules();
  const lv = X.weekLeave(p.weekStart);
  let marks = {};
  try { marks = require('../absence.js').marksBetween(p.weekStart, addDays(p.weekStart, 6)); } catch (e) { marks = {}; }
  const changed = X.changedCells();
  const warnings = X.weekWarnings(p.weekStart, { shopCode: shop });
  const warnCells = new Set(warnings.filter((w) => w.shiftUid && w.level !== 'info').map((w) => w.shiftUid));
  const editable = can('timesheets_edit');
  const owner = !require('../../../services/access.js').reasonRequired(user);
  const undoL = X.undoLabel();
  const dayCost = Object.fromEntries(p.days.map((d) => [d, p.people.reduce((a, x) => a + (x.byDay[d].reduce((m, s) => m + R.shiftMinutes(s), 0) / 60) * x.rate, 0)]));
  const cover = Object.fromEntries(p.days.map((d) => [d, X.coverage(d, shop)]));

  // Run a change; when it clashes show what to do instead.
  const run = (input, fn) => {
    try {
      const res = fn();
      if (res && res.ok === false) { setSugg({ input, res }); return false; }
      if (res && res.warns && res.warns.length) ui.toast(res.warns.map((w) => w.text).join(' '), 'warn');
      refresh();
      return true;
    } catch (e) { ui.error(e); return false; }
  };
  const cellPress = (u, d, s) => {
    if (!editable) return;
    if (mode === 'paint') {
      const b = brush === 'off' ? 'off' : st.templates[brush];
      if (!b) return;
      run({ uid: s && s.uid, userUid: u.uid, date: d, shopCode: shop, start: b.start, end: b.end, breakMin: b.breakMin }, () => X.paint(user, { userUid: u.uid, date: d, shopCode: shop, brush: b }));
      return;
    }
    if (clip) {
      const input = { uid: s && s.uid, userUid: u.uid, date: d, shopCode: shop, start: clip.start, end: clip.end, breakMin: clip.breakMin, note: clip.note };
      run(input, () => X.planShift(user, input));
      return;
    }
    setMenu({ user: u, date: d, s });
  };
  const longPress = (u, d, s) => {
    if (!editable || !s) return;
    setClip({ start: s.start_time, end: s.end_time, breakMin: s.break_min, note: s.note, from: `${u.name} ${dayLabel(d)}` });
    setMode('tap');
    ui.toast(`Copied ${short(s.start_time)}–${short(s.end_time)} – tap other boxes to paste`);
  };
  const openEdit = (u, d, s) => {
    const t = st.templates[0];
    setEdit(s ? { uid: s.uid, userUid: u.uid, name: u.name, date: d, start: s.start_time, end: s.end_time, breakMin: String(s.break_min || 0), note: s.note || '' }
      : { userUid: u.uid, name: u.name, date: d, start: t ? t.start : '08:00', end: t ? t.end : '17:00', breakMin: String(t ? t.breakMin : 30), note: '' });
  };
  const saveEdit = () => {
    const input = { uid: edit.uid, userUid: edit.userUid, date: edit.date, shopCode: shop, start: edit.start, end: edit.end, breakMin: Number(edit.breakMin) || 0, note: edit.note };
    if (run(input, () => X.planShift(user, input))) { setEdit(null); ui.toast('Saved'); }
    else setEdit(null);
  };
  const applySg = (sg) => {
    const { input } = sugg;
    setSugg(null);
    if (sg.kind === 'allow-swap') { run(input, () => X.swapPeople(user, input, { allow: true })); return; }
    run(input, () => X.applySuggestion(user, input, sg));
  };
  const nameW = isPhone ? 96 : 160;
  const cellW = isPhone ? 70 : 104;
  const legend = ['morning', 'day', 'afternoon', 'night', 'leave'];

  // The grid (also what the picture is taken of).
  const grid = (forPicture) => (
    <View ref={forPicture ? pic : undefined} collapsable={false} style={{ backgroundColor: C.card, padding: forPicture ? 8 : 0 }}>
      {forPicture ? <Text style={{ fontSize: 16, fontWeight: '800', color: C.text, padding: 4 }}>Easy Buys roster {shop} · {dayLabel(p.weekStart)} – {dayLabel(addDays(p.weekStart, 6))}</Text> : null}
      <View style={{ flexDirection: 'row' }}>
        <Text style={{ width: nameW, fontWeight: '800', color: C.sub, padding: 6 }}>Person</Text>
        {p.days.map((d) => (
          <Pressable key={d} testID={forPicture ? undefined : `rp-day-${d}`} onPress={() => (editable && !forPicture ? setDayMenu(d) : null)} style={{ width: cellW, padding: 4 }}>
            <Text style={{ fontWeight: '800', color: d === dateStr() ? C.primary : C.sub, textAlign: 'center' }}>{dayLabel(d)}</Text>
            <Text style={{ fontSize: 11, color: C.sub, textAlign: 'center' }}>{p.perDay[d].people} on · {hm(p.perDay[d].minutes)}</Text>
            {!forPicture ? <Text style={{ fontSize: 11, color: C.sub, textAlign: 'center' }}>{money(dayCost[d])}</Text> : null}
            {cover[d].map((c) => <Text key={c.name} style={{ fontSize: 11, fontWeight: '800', textAlign: 'center', color: c.short ? C.danger : C.success }}>{c.name.slice(0, 7)} {c.have}/{c.need}</Text>)}
          </Pressable>
        ))}
        <Text style={{ width: 90, fontWeight: '800', color: C.sub, padding: 6, textAlign: 'right' }}>Hours{forPicture ? '' : '\nCost'}</Text>
      </View>
      {p.people.map((x) => (
        <View key={x.user.uid} style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: C.border, alignItems: 'center' }}>
          <Text style={{ width: nameW, padding: 6, fontWeight: '700', color: C.text }} numberOfLines={2}>{x.user.name}</Text>
          {p.days.map((d) => {
            const s = x.byDay[d][0];
            return <Cell key={d} s={s} lv={lv[`${x.user.uid}|${d}`]} mark={marks[`${x.user.uid}|${d}`]} changed={!!changed[`${x.user.uid}|${d}`]} warn={s && warnCells.has(s.uid)} w={cellW - 4} compact={forPicture}
              testID={forPicture ? undefined : `rp-${tid(x.user)}-${d}`} onPress={forPicture ? undefined : () => cellPress(x.user, d, s)} onLongPress={forPicture ? undefined : () => longPress(x.user, d, s)} />;
          })}
          <View style={{ width: 90, padding: 6 }}>
            <Text style={{ textAlign: 'right', fontWeight: '800', color: rules.maxWeekHours && x.minutes > rules.maxWeekHours * 60 ? C.danger : C.text }}>{x.hours}</Text>
            {!forPicture ? <Text style={{ textAlign: 'right', fontSize: 12, color: C.sub }}>{money(x.cost)}</Text> : null}
          </View>
        </View>
      ))}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingTop: 6 }}>
        {legend.map((k) => <Text key={k} style={{ fontSize: 12, fontWeight: '800', color: X.SHIFT_COLOURS[k].fg, backgroundColor: X.SHIFT_COLOURS[k].bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>{X.SHIFT_COLOURS[k].label}</Text>)}
        {!forPicture ? <Text style={{ fontSize: 12, fontWeight: '800', color: C.warn, borderColor: C.warn, borderWidth: 2, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 1 }}>Changed today / tomorrow</Text> : null}
        {!forPicture ? <Text style={{ fontSize: 12, fontWeight: '800', color: C.danger, borderColor: C.danger, borderWidth: 2, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 1 }}>Clash</Text> : null}
      </View>
    </View>
  );

  return (
    <Screen title="Roster planner" subtitle={`${shop} · week ${dayLabel(p.weekStart)} – ${dayLabel(addDays(p.weekStart, 6))}`}>
      <Explain title="How the roster works">
        The roster is a plan: who should work when. It never stops anyone clocking in. Tap a box for choices, or press and hold to copy it and then tap other boxes to paste.
        Paint mode: choose a shift, then tap boxes to fill them. Tap a day at the top to copy it to other days or to swap two people. When something clashes (leave, too many hours,
        not enough rest, two shifts, not enough staff) the app shows what you can do instead.
      </Explain>
      <Chips value={shop} onChange={setShop} options={shopOpts()} testIDPrefix="rp-shop" />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <Btn testID="rp-prev" title="‹ Week" size="sm" variant="secondary" onPress={() => setDate(addDays(p.weekStart, -7))} />
        <Btn title="This week" size="sm" variant="secondary" onPress={() => { setDate(dateStr()); setPhoneDay(dateStr()); }} />
        <Btn testID="rp-nextweek" title="Next week" size="sm" variant="secondary" onPress={() => { setDate(addDays(dateStr(), 7)); setPhoneDay(addDays(dateStr(), 7)); }} />
        <Btn testID="rp-next" title="Week ›" size="sm" variant="secondary" onPress={() => setDate(addDays(p.weekStart, 7))} />
      </View>
      <Stats items={[{ label: 'Planned hours', value: hm(p.totalMinutes) }, { label: 'Planned wages', value: money(p.totalCost), sub: 'from pay rates' }, { label: 'People', value: String(p.people.filter((x) => x.minutes).length) },
        { label: 'Warnings', value: String(warnings.filter((w) => w.level !== 'info').length), color: warnings.some((w) => w.level === 'urgent') ? C.danger : warnings.length ? C.warn : undefined }]} />
      {editable ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Btn testID="rp-copy" title="Copy last week" icon="⧉" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = X.copyLastWeek(user, { weekStart: p.weekStart, shopCode: shop }); ui.toast(`${n} shift(s) copied`); refresh(); })} />
          <Btn testID="rp-usual" title="Usual week" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = X.fillUsualWeek(user, { weekStart: p.weekStart, shopCode: shop }); ui.toast(`${n} shift(s) added`); refresh(); })} />
          <Btn testID="rp-undo" title={undoL ? `Undo: ${undoL}` : 'Undo'} icon="↶" size="md" variant="secondary" disabled={!undoL} style={{ flexGrow: 1 }} onPress={() => act(() => { const l = X.undo(user); ui.toast(`Undone: ${l}`); refresh(); })} />
          <Btn testID="rp-share" title="Share" icon="📤" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setShare(true)} />
          {st.calendar ? <Btn testID="rp-cal" title="Google Calendar" icon="📅" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => act(() => { const n = R.publishWeek(user, p.weekStart); ui.toast(`${n} shift(s) will be sent when online`); })} /> : null}
        </View>
      ) : <Btn testID="rp-share" title="Share" icon="📤" size="md" variant="secondary" onPress={() => setShare(true)} />}
      {editable ? (
        <Card>
          <Chips value={mode} onChange={(v) => { setMode(v); setClip(null); }} testIDPrefix="rp-mode" options={[{ value: 'tap', label: 'Tap for choices' }, { value: 'paint', label: '🖌 Paint' }]} />
          {mode === 'paint' ? (
            <View style={{ gap: 6 }}>
              <Label>Brush – then tap boxes</Label>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {st.templates.map((t, i) => <Btn key={t.name} testID={`rp-brush-${i}`} title={`${t.name} ${short(t.start)}–${short(t.end)}`} size="sm" variant={brush === i ? 'info' : 'secondary'} onPress={() => setBrush(i)} />)}
                <Btn testID="rp-brush-off" title="Day off" size="sm" variant={brush === 'off' ? 'danger' : 'secondary'} onPress={() => setBrush('off')} />
              </View>
            </View>
          ) : null}
          {clip ? (
            <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <Text testID="rp-clip" style={{ flex: 1, fontWeight: '800', color: C.info }}>Copied {short(clip.start)}–{short(clip.end)} ({clip.from}) – tap boxes to paste</Text>
              <Btn testID="rp-clip-stop" title="Stop pasting" size="sm" variant="secondary" onPress={() => setClip(null)} />
            </View>
          ) : null}
        </Card>
      ) : null}
      {warnings.length ? (
        <Section title={`Warnings (${warnings.length})`}>
          {warnings.slice(0, 12).map((w, i) => <ListItem key={i} testID={`rp-warn-${i}`} title={w.text} tone={w.level === 'urgent' ? 'danger' : undefined} badge={{ leave: 'Leave', hours: 'Hours', rest: 'Rest', double: 'Double', short: 'Short' }[w.kind]} badgeColor={w.level === 'urgent' ? C.danger : w.level === 'info' ? C.info : C.warn} />)}
        </Section>
      ) : null}
      {isPhone ? (
        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {p.days.map((d) => <Btn key={d} testID={`rp-pday-${d}`} title={dayLabel(d)} size="sm" variant={d === phoneDay ? 'info' : 'secondary'} onPress={() => setPhoneDay(d)} />)}
          </View>
          {(() => {
            const d = p.days.includes(phoneDay) ? phoneDay : p.days[0];
            return (
              <View style={{ gap: 6 }}>
                <Pressable testID="rp-pday-menu" onPress={() => (editable ? setDayMenu(d) : null)}>
                  <Text style={{ fontWeight: '800', color: C.text, fontSize: 17 }}>{dayName(d)} {d} · {p.perDay[d].people} on · {hm(p.perDay[d].minutes)} · {money(dayCost[d])}{editable ? '  ⋯' : ''}</Text>
                  {cover[d].map((c) => <Text key={c.name} style={{ fontSize: 13, fontWeight: '800', color: c.short ? C.danger : C.success }}>{c.name} {c.start}–{c.end}: {c.have} of {c.need}{c.short ? ` – short by ${c.short}` : ''}</Text>)}
                </Pressable>
                {p.people.map((x) => {
                  const s = x.byDay[d][0];
                  return (
                    <View key={x.user.uid} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <Text style={{ flex: 1, fontWeight: '700', color: C.text, fontSize: 16 }}>{x.user.name}{'\n'}<Text style={{ fontSize: 12, color: C.sub }}>{x.hours} this week</Text></Text>
                      <Cell s={s} lv={lv[`${x.user.uid}|${d}`]} mark={marks[`${x.user.uid}|${d}`]} changed={!!changed[`${x.user.uid}|${d}`]} warn={s && warnCells.has(s.uid)} w={150} testID={`rp-${tid(x.user)}-${d}`} onPress={() => cellPress(x.user, d, s)} onLongPress={() => longPress(x.user, d, s)} />
                    </View>
                  );
                })}
              </View>
            );
          })()}
        </View>
      ) : <ScrollView horizontal>{grid(false)}</ScrollView>}

      {/* Tap menu */}
      {menu ? (
        <Sheet onClose={() => setMenu(null)} title={`${menu.user.name} · ${dayName(menu.date)} ${Number(menu.date.slice(8))}`}>
          {menu.s ? <Text style={{ color: C.sub }}>Now: {nice(menu.s.start_time)}–{nice(menu.s.end_time)}{menu.s.note ? ` · ${menu.s.note}` : ''}</Text> : <Text style={{ color: C.sub }}>Off this day.</Text>}
          <Label>Quick shifts</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {st.templates.map((t) => <Btn key={t.name} testID={`rp-q-${t.name}`} title={`${t.name} ${short(t.start)}–${short(t.end)}`} size="sm" variant="info" onPress={() => {
              const input = { uid: menu.s && menu.s.uid, userUid: menu.user.uid, date: menu.date, shopCode: shop, start: t.start, end: t.end, breakMin: t.breakMin };
              setMenu(null); run(input, () => X.planShift(user, input));
            }} />)}
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            <Btn testID="rp-m-edit" title={menu.s ? 'Change times…' : 'Other times…'} size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { openEdit(menu.user, menu.date, menu.s); setMenu(null); }} />
            {menu.s ? <Btn testID="rp-m-copy" title="Copy" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { longPress(menu.user, menu.date, menu.s); setMenu(null); }} /> : null}
            <Btn testID="rp-m-copyday" title="Copy this day to…" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { setCopyTo({ from: menu.date, to: [] }); setMenu(null); }} />
            <Btn testID="rp-m-swap" title="Swap with…" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => { setSwap({ a: menu.user.uid, b: null, dates: [menu.date] }); setMenu(null); }} />
            {menu.s ? <Btn testID="rp-m-off" title="Day off" size="md" variant="danger" style={{ flexGrow: 1 }} onPress={() => { const uid = menu.s.uid; setMenu(null); run({}, () => X.dayOff(user, uid)); }} /> : null}
          </View>
          {/* v3.9.5 what the day was: day off, leave, sick (sheet = paid) or absent (unpaid, with the reason) */}
          <Label>Not working this day</Label>
          {marks[`${menu.user.uid}|${menu.date}`] ? <Text style={{ color: C.text, fontWeight: '700' }}>{`Marked: ${markText(marks[`${menu.user.uid}|${menu.date}`])}${marks[`${menu.user.uid}|${menu.date}`].reason ? ` – ${marks[`${menu.user.uid}|${menu.date}`].reason}` : ''}`}</Text> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {[['off', 'Day off'], ['leave', 'Leave'], ['sick', 'Sick'], ['absent', 'Absent'], ['work', 'Working']].map(([k, label]) => (
              <Btn key={k} testID={`rp-mark-${k}`} title={label} size="sm" variant={k === 'absent' ? 'danger' : k === 'work' ? 'success' : 'secondary'} style={{ flexGrow: 1 }}
                onPress={() => { const m = menu; setMenu(null); nav.push('MarkDay', { userUid: m.user.uid, date: m.date, kind: k }); }} />
            ))}
          </View>
        </Sheet>
      ) : null}

      {/* Day menu */}
      {dayMenu ? (
        <Sheet onClose={() => setDayMenu(null)} title={`${dayName(dayMenu)} ${dayMenu}`}>
          <Btn testID="rp-d-copy" title="Copy this day to other days…" size="md" variant="secondary" onPress={() => { setCopyTo({ from: dayMenu, to: [] }); setDayMenu(null); }} />
          <Btn testID="rp-d-swap" title="Swap two people…" size="md" variant="secondary" onPress={() => { setSwap({ a: null, b: null, dates: [dayMenu] }); setDayMenu(null); }} />
        </Sheet>
      ) : null}

      {/* Copy a day to other days */}
      {copyTo ? (
        <Sheet onClose={() => setCopyTo(null)} title={`Copy ${dayName(copyTo.from)} to…`}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {p.days.concat(p.days.map((d) => addDays(d, 7))).filter((d) => d !== copyTo.from).map((d) => (
              <Btn key={d} testID={`rp-ct-${d}`} title={dayLabel(d)} size="sm" variant={copyTo.to.includes(d) ? 'info' : 'secondary'} onPress={() => setCopyTo({ ...copyTo, to: copyTo.to.includes(d) ? copyTo.to.filter((x) => x !== d) : copyTo.to.concat([d]) })} />
            ))}
          </View>
          <Hint>Everyone's shift that day is copied. People on leave, or who would get too many hours or too little rest, are left out and listed.</Hint>
          <Btn testID="rp-ct-go" title={`Copy to ${copyTo.to.length} day(s)`} size="md" variant="success" disabled={!copyTo.to.length} onPress={() => {
            const c = copyTo; setCopyTo(null);
            act(() => { const r = X.copyDay(user, { fromDate: c.from, toDates: c.to, shopCode: shop }); refresh(); if (r.skipped.length) ui.alert({ title: `${r.copied} shift(s) copied`, message: `Left out:\n${r.skipped.map((s) => `${s.name} ${dayLabel(s.date)}: ${s.why}`).join('\n')}`, tone: 'warn' }); else ui.toast(`${r.copied} shift(s) copied`); });
          }} />
        </Sheet>
      ) : null}

      {/* Swap two people */}
      {swap ? (
        <Sheet onClose={() => setSwap(null)} title="Swap two people">
          <Choice label="First person" value={swap.a} onChange={(v) => setSwap({ ...swap, a: v })} options={p.people.map((x) => ({ value: x.user.uid, label: x.user.name }))} testIDPrefix="rp-sw-a" />
          <Choice label="Swap with" value={swap.b} onChange={(v) => setSwap({ ...swap, b: v })} options={p.people.filter((x) => x.user.uid !== swap.a).map((x) => ({ value: x.user.uid, label: x.user.name }))} testIDPrefix="rp-sw-b" />
          <Chips value={swap.dates.length > 1 ? 'week' : 'day'} onChange={(v) => setSwap({ ...swap, dates: v === 'week' ? p.days : [swap.dates[0]] })} testIDPrefix="rp-sw-scope" options={[{ value: 'day', label: `Only ${dayLabel(swap.dates[0])}` }, { value: 'week', label: 'The whole week' }]} />
          <Btn testID="rp-sw-go" title="Swap" size="md" variant="success" disabled={!swap.a || !swap.b} onPress={() => {
            const input = { aUid: swap.a, bUid: swap.b, dates: swap.dates, shopCode: shop };
            setSwap(null);
            try {
              const r = X.swapPeople(user, input);
              if (!r.ok) setSugg({ input, res: { blocks: r.blocks, warns: [], suggestions: r.allowAnyway ? [{ kind: 'allow-swap', text: 'Allow anyway' }] : [] }, swap: true });
              else { ui.toast('Swapped'); refresh(); }
            } catch (e) { ui.error(e); }
          }} />
        </Sheet>
      ) : null}

      {/* Change times */}
      {edit ? (
        <Sheet onClose={() => setEdit(null)} title={`${edit.name} · ${dayLabel(edit.date)}`}>
          <TimeField testID="rp-start" label="Start" value={edit.start} onChange={(v) => setEdit({ ...edit, start: v })} showNow={false} />
          <TimeField testID="rp-end" label="Finish" value={edit.end} onChange={(v) => setEdit({ ...edit, end: v })} showNow={false} />
          <Field label="Break (minutes)" value={edit.breakMin} onChangeText={(v) => setEdit({ ...edit, breakMin: v.replace(/\D/g, '') })} keyboardType="number-pad" />
          <Field label="Note (e.g. till 2, stock delivery)" value={edit.note} onChangeText={(v) => setEdit({ ...edit, note: v })} />
          <Btn testID="rp-save" title="Save" size="md" variant="success" onPress={saveEdit} />
        </Sheet>
      ) : null}

      {/* What to do instead */}
      {sugg ? (
        <Sheet onClose={() => setSugg(null)} title={sugg.swap ? 'This swap clashes' : 'This shift clashes'} testID="rp-sugg">
          {sugg.res.blocks.map((b, i) => <Text key={i} style={{ color: C.danger, fontWeight: '800', fontSize: 16 }}>• {b.text}</Text>)}
          {(sugg.res.warns || []).map((b, i) => <Text key={`w${i}`} style={{ color: C.warn, fontWeight: '700', fontSize: 15 }}>• {b.text}</Text>)}
          <Label>{sugg.res.suggestions.length ? 'What you can do instead' : 'Try another person or time.'}</Label>
          {sugg.res.suggestions.map((sg, i) => (
            <Btn key={i} testID={`rp-sg-${sg.kind}${sg.kind === 'allow' || sg.kind === 'allow-swap' ? '' : `-${i}`}`} title={sg.text} size="md" variant={sg.kind === 'allow' || sg.kind === 'allow-swap' ? 'danger' : 'info'} onPress={() => applySg(sg)} />
          ))}
          {!owner ? <Hint>Only the owner or admin can allow a clash.</Hint> : null}
        </Sheet>
      ) : null}

      {/* Share */}
      {share ? (
        <Sheet onClose={() => setShare(false)} title="Share the roster" wide>
          <Hint>Send it to the staff Viber or WhatsApp group: choose the app, then the group.</Hint>
          <ScrollView horizontal>{grid(true)}</ScrollView>
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn testID="rp-share-pic" title="As a picture" icon="🖼" size="md" variant="info" style={{ flexGrow: 1 }} onPress={async () => {
              try { await sharePicture(pic, { title: `Roster ${shop}` }); setShare(false); } catch (e) {
                if (e.noPicture) { try { await shareReport(X.rosterReport(p.weekStart, { shopCode: shop }), 'pdf'); setShare(false); } catch (x) { ui.error(x); } } else ui.error(e);
              }
            }} />
            <Btn testID="rp-share-pdf" title="As a PDF" icon="📄" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={async () => { try { await shareReport(X.rosterReport(p.weekStart, { shopCode: shop }), 'pdf'); setShare(false); } catch (e) { ui.error(e); } }} />
          </View>
        </Sheet>
      ) : null}
    </Screen>
  );
}

function Sheet({ title, children, onClose, testID, wide }) {
  return (
    <SafeModal visible transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 12 }}>
        <ScrollView style={{ maxWidth: wide ? 1100 : 560, width: '100%' }} contentContainerStyle={{ backgroundColor: C.card, borderRadius: 18, padding: 18, gap: 10 }}>
          <View testID={testID} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <H style={{ flex: 1 }}>{title}</H>
            <Btn testID="sheet-close" title="✕" size="sm" variant="ghost" onPress={onClose} />
          </View>
          {children}
        </ScrollView>
      </View>
    </SafeModal>
  );
}

// ---------------------------------------------------------------- my roster (everyone)
export function MyRosterScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const [, bump] = useState(0);
  const list = X.myShifts(user.uid, dateStr(), 14);
  const unseen = X.unseenChanges(user.uid);
  const changes = X.recentChanges({ userUid: user.uid });
  const byDate = {};
  list.forEach((s) => { (byDate[s.shift_date] = byDate[s.shift_date] || []).push(s); });
  return (
    <Screen title="My roster" subtitle={user.name}>
      {unseen.length ? (
        <Banner testID="mr-changed" tone="warn" title="Your roster changed" message={unseen.map((c) => `${c.shift_date === dateStr() ? 'Today' : 'Tomorrow'}: ${c.after_text} (was ${c.before_text})`).join('\n')} />
      ) : null}
      {unseen.length ? <Btn testID="mr-seen" title="Seen – thank you" icon="✓" size="md" variant="success" onPress={() => { act(() => X.markSeen(user), 'Thank you'); bump((x) => x + 1); }} /> : null}
      {Array.from({ length: 14 }, (_, i) => addDays(dateStr(), i)).map((d) => {
        const s = byDate[d] || [];
        const ch = changes.find((c) => c.shift_date === d);
        return (
          <ListItem key={d} testID={`mr-${d}`} title={`${dayName(d)} ${Number(d.slice(8))}${d === dateStr() ? ' (today)' : ''}`} sub={s.length ? s.map((x) => `${nice(x.start_time)}–${nice(x.end_time)}${x.shop_code ? ` · ${x.shop_code}` : ''}${x.note ? ` · ${x.note}` : ''}`).join('\n') : 'Off'}
            badge={ch ? 'Changed' : s.length ? X.SHIFT_COLOURS[X.shiftKind(s[0])].label : undefined} badgeColor={ch ? C.warn : C.info} />
        );
      })}
    </Screen>
  );
}

// ---------------------------------------------------------------- roster rules (admin)
export function RosterRulesScreen() {
  const { user } = useApp();
  const act = useAct();
  const r0 = X.rosterRules();
  const shops = shopOpts();
  const [r, setR] = useState({ ...r0, maxWeekHours: String(r0.maxWeekHours), minRestHours: String(r0.minRestHours), maxShiftsPerDay: String(r0.maxShiftsPerDay) });
  const [shop, setShop] = useState((shops[0] || {}).value || 'S1');
  const slots = r.needs[shop] || [];
  const setSlots = (list) => setR({ ...r, needs: { ...r.needs, [shop]: list } });
  const setSlot = (i, patch) => setSlots(slots.map((x, k) => (k === i ? { ...x, ...patch } : x)));
  return (
    <Screen title="Roster rules" subtitle="Admin · hour limits, rest, staff needed">
      <Section title="Limits">
        <Field testID="rr-max" label="Most hours a person may work in a week (0 = no limit)" value={r.maxWeekHours} onChangeText={(v) => setR({ ...r, maxWeekHours: v })} keyboardType="number-pad" />
        <Field testID="rr-rest" label="Rest between shifts, at least (hours)" value={r.minRestHours} onChangeText={(v) => setR({ ...r, minRestHours: v })} keyboardType="number-pad" />
        <Field testID="rr-double" label="Shifts a person may have on one day (more = double shift)" value={r.maxShiftsPerDay} onChangeText={(v) => setR({ ...r, maxShiftsPerDay: v })} keyboardType="number-pad" />
        <Chips value={r.tellViber ? 'y' : 'n'} onChange={(v) => setR({ ...r, tellViber: v === 'y' })} testIDPrefix="rr-viber" options={[{ value: 'n', label: 'Tell staff in the app' }, { value: 'y', label: 'Also post changes to the Viber group' }]} />
        <Hint>Changes to today's and tomorrow's roster always show on the person's Home screen (with a sound) until they tap "Seen".</Hint>
      </Section>
      <Section title="Staff needed per shift">
        <Chips value={shop} onChange={setShop} options={shops} testIDPrefix="rr-shop" />
        {slots.map((x, i) => (
          <Card key={i}>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <View style={{ flexBasis: 140, flexGrow: 1 }}><Field testID={`rr-name-${i}`} label="Shift" value={x.name} onChangeText={(v) => setSlot(i, { name: v })} /></View>
              <View style={{ flexBasis: 200, flexGrow: 1 }}><TimeField testID={`rr-start-${i}`} label="From" value={x.start} onChange={(v) => setSlot(i, { start: v })} showNow={false} /></View>
              <View style={{ flexBasis: 200, flexGrow: 1 }}><TimeField testID={`rr-end-${i}`} label="To" value={x.end} onChange={(v) => setSlot(i, { end: v })} showNow={false} /></View>
              <Btn title="✕" size="sm" variant="ghost" onPress={() => setSlots(slots.filter((_, k) => k !== i))} />
            </View>
            <Label>People needed</Label>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {[6, 0, 1, 2, 3, 4, 5].map((d) => (
                <View key={d} style={{ width: 70 }}>
                  <Field testID={`rr-c-${i}-${d}`} label={WD[d]} value={String((x.count || [])[d] ?? '')} onChangeText={(v) => { const c = (x.count || [0, 0, 0, 0, 0, 0, 0]).slice(); c[d] = v.replace(/\D/g, ''); setSlot(i, { count: c }); }} keyboardType="number-pad" />
                </View>
              ))}
            </View>
          </Card>
        ))}
        <Btn testID="rr-add" title="+ Shift" size="sm" variant="secondary" onPress={() => setSlots(slots.concat([{ name: slots.length ? 'Afternoon' : 'Morning', start: slots.length ? '13:00' : '07:00', end: slots.length ? '21:00' : '15:00', count: [1, 2, 2, 2, 2, 2, 2] }]))} />
      </Section>
      <Btn testID="rr-save" title="Save" icon="💾" variant="success" onPress={() => act(() => X.saveRosterRules(user, r), 'Saved')} />
    </Screen>
  );
}
