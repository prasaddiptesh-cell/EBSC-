// Roster: the days and times each person should work. Used for "late" on the Time Clock and "rostered times" on the timesheet.
import React, { useState } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, useApp, useUI, Choice } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ClockFacePicker, nice } from '../../../ui/timePicker.js';
import { listUsers } from '../../../services/catalog.js';
import { getRoster, saveRoster, DOW } from '../service.js';
import { SafeModal } from '../../../ui/safeModal.js';

const ORDER = ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri'];
const NAME = { sat: 'Saturday', sun: 'Sunday', mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday' };

export default function RosterScreen() {
  const { user } = useApp();
  const ui = useUI();
  const staff = listUsers().filter((u) => u.active && u.uses_clock !== 0 && u.sync_status !== 'seed');
  const [who, setWho] = useState(staff[0] ? staff[0].uid : '');
  const [days, setDays] = useState(() => (staff[0] ? getRoster(staff[0].uid) : {}));
  const [pick, setPick] = useState(null); // { day, field }
  const choose = (uid) => { setWho(uid); setDays(getRoster(uid)); };
  const save = () => { try { saveRoster(user, who, days); ui.toast('Roster saved'); } catch (e) { ui.error(e); } };
  return (
    <Screen title="Roster" subtitle="Who works when (used for late arrivals and quick timesheet entry)" footer={who ? <Btn testID="roster-save" title="Save roster" icon="💾" variant="success" onPress={save} /> : null}>
      <Banner tone="info" message="Set each person's usual days and times once. The Time Clock then shows who is late, and the weekly timesheet can fill in rostered times with one tap." />
      <Choice value={who} onChange={choose} testIDPrefix="roster-who" options={staff.map((u) => ({ value: u.uid, label: u.name }))} />
      {ORDER.map((d) => {
        const v = days[d];
        return (
          <Card key={d}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, minWidth: 110 }}>{NAME[d]}</Text>
              <Chips value={!!v} onChange={(on) => setDays({ ...days, [d]: on ? { start: '08:00', end: '17:00' } : null })} testIDPrefix={`roster-${d}`} options={[{ value: true, label: 'Works' }, { value: false, label: 'Off' }]} />
              {v ? (
                <>
                  <Btn title={`Start ${nice(v.start)}`} size="sm" variant="secondary" onPress={() => setPick({ day: d, field: 'start' })} />
                  <Btn title={`Finish ${nice(v.end)}`} size="sm" variant="secondary" onPress={() => setPick({ day: d, field: 'end' })} />
                </>
              ) : null}
            </View>
          </Card>
        );
      })}
      {pick ? (
        <SafeModal visible transparent animationType="fade" onRequestClose={() => setPick(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 12 }}>
            <ScrollView style={{ maxWidth: 460, width: '100%' }} contentContainerStyle={{ backgroundColor: C.card, borderRadius: 18, padding: 18 }}>
              <H>{NAME[pick.day]} – {pick.field === 'start' ? 'start' : 'finish'}</H>
              <ClockFacePicker value={days[pick.day][pick.field]} onChange={(t) => setDays({ ...days, [pick.day]: { ...days[pick.day], [pick.field]: t } })} />
              <Btn title="Done" variant="primary" style={{ marginTop: 12 }} onPress={() => setPick(null)} />
            </ScrollView>
          </View>
        </SafeModal>
      ) : null}
    </Screen>
  );
}
