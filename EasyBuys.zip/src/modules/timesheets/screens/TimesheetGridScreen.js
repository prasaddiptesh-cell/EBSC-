// One person's week as a grid: tap a time to set it on the clock face. Every change needs a reason.
import React, { useState } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ClockFacePicker, nice } from '../../../ui/timePicker.js';
import { addDays, dayName } from '../../../services/core.js';
import { personWeek, dayCells, setDayTime, clearDay, fillDay, hm, checkWeek } from '../service.js';
import { plannedFor as rosterFor } from '../roster.js';
import { listUsers } from '../../../services/catalog.js';
import { ReasonField } from '../../../ui/kit.js';
import { SafeModal } from '../../../ui/safeModal.js';

const CELL_LABEL = { in: 'Clock IN', break_out: 'Break start', break_in: 'Break end', out: 'Clock OUT' };
const ORDER = ['in', 'break_out', 'break_in', 'out'];

export default function TimesheetGridScreen({ params }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date);
  const [edit, setEdit] = useState(null); // { date, cell, time, reason }
  const [, bump] = useState(0);
  const w = personWeek(params.userUid, date);
  const person = listUsers().find((u) => u.uid === params.userUid);
  const days = Array.from({ length: 7 }, (_, i) => addDays(w.weekStart, i));
  const checked = !!(w.check && w.check.status === 'checked');
  const run = (fn, msg) => { try { fn(); ui.toast(msg); setEdit(null); bump((n) => n + 1); } catch (e) { ui.error(e); } };

  const open = (d, cell, cur) => {
    if (checked) { ui.alert({ title: 'Week checked', message: 'Untick the week first (Timesheets › the person › Untick week).', tone: 'warn' }); return; }
    const ro = rosterFor(params.userUid, d);
    const guess = cur ? cur.time : cell === 'in' ? (ro ? ro.start : '08:00') : cell === 'out' ? (ro ? ro.end : '17:00') : cell === 'break_out' ? '12:00' : '12:30';
    setEdit({ date: d, cell, time: guess, reason: edit ? edit.reason : '' });
  };
  const prevDay = (d) => dayCells(params.userUid, addDays(d, -1));

  const picker = edit ? (
    <Card testID="grid-picker">
      <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub }}>{dayName(edit.date).toUpperCase()} {edit.date.slice(8)}/{edit.date.slice(5, 7)}</Text>
      <H>{CELL_LABEL[edit.cell]}</H>
      <ClockFacePicker testID="tp" value={edit.time} onChange={(v) => setEdit({ ...edit, time: v })}
        quick={(() => { const ro = rosterFor(params.userUid, edit.date); return ro ? [{ label: `Rostered ${nice(edit.cell === 'out' ? ro.end : ro.start)}`, value: edit.cell === 'out' ? ro.end : ro.start }] : []; })()} />
      <ReasonField testID="grid-reason" label="Reason (required)" value={edit.reason} onChangeText={(v) => setEdit({ ...edit, reason: v })} placeholder="e.g. forgot to clock out, paper timesheet" />
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
        <Btn title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(null)} />
        <Btn testID="grid-save" title={`Save ${nice(edit.time)}`} variant="primary" style={{ flex: 2 }} onPress={() => run(() => setDayTime(user, { userUid: params.userUid, ...edit }), 'Saved')} />
      </View>
    </Card>
  ) : null;

  return (
    <Screen title={person ? person.name : 'Timesheet'} subtitle={`Week ${w.weekStart} – ${w.weekEnd} · ${hm(w.totalMinutes)} h`}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setEdit(null); setDate(addDays(w.weekStart, -7)); }} />
        <Btn title="Week ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setEdit(null); setDate(addDays(w.weekStart, 7)); }} />
        <Btn title="Every punch" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => nav.push('TimesheetPerson', { userUid: params.userUid, date })} />
      </View>
      {checked ? <Banner tone="success" title="Week checked" message="Untick it in Every punch to change times." /> : null}
      <View style={{ flexDirection: isPhone ? 'column' : 'row', gap: 14, alignItems: 'flex-start' }}>
        <View style={{ flex: 1, width: isPhone ? '100%' : undefined, gap: 8 }}>
          {days.map((d) => {
            const cur = dayCells(params.userUid, d);
            const s = cur.shift;
            const ro = rosterFor(params.userUid, d);
            const problem = s && s.problems;
            return (
              <View key={d} testID={`grid-day-${d}`} style={{ backgroundColor: problem ? C.warnSoft : C.card, borderRadius: 14, borderWidth: 1, borderColor: problem ? C.warn : C.border, padding: 10, gap: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Text style={{ fontSize: 18, fontWeight: '900', color: C.text, minWidth: 74 }}>{dayName(d)} {Number(d.slice(8))}</Text>
                  <Text style={{ fontSize: 13, color: C.sub, flex: 1 }}>{ro ? `Rostered ${nice(ro.start)}–${nice(ro.end)}` : 'Not rostered'}{s && s.autoBreak ? ' · auto break' : ''}{s && s.status === 'open' ? ' · still in' : ''}{problem ? ' · needs fixing' : ''}</Text>
                  <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>{s && s.workedMinutes ? hm(s.workedMinutes) : '–'}</Text>
                </View>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                  {ORDER.map((cell) => {
                    const c = cur[cell];
                    const on = edit && edit.date === d && edit.cell === cell;
                    return (
                      <Pressable key={cell} testID={`grid-${d}-${cell}`} onPress={() => open(d, cell, c)}
                        style={{ flexGrow: 1, flexBasis: 110, minHeight: 52, borderRadius: 10, borderWidth: 2, borderStyle: c ? 'solid' : 'dashed', borderColor: on ? C.info : c ? C.border : '#CFC6BC',
                          backgroundColor: on ? C.infoSoft : C.white, paddingHorizontal: 10, justifyContent: 'center' }}>
                        <Text style={{ fontSize: 12, color: C.sub, fontWeight: '700' }}>{CELL_LABEL[cell]}</Text>
                        <Text style={{ fontSize: 17, fontWeight: '800', color: c ? C.text : C.sub }}>{c ? `${nice(c.time)}${c.date !== d ? ' (next day)' : ''}` : '+ add'}</Text>
                      </Pressable>
                    );
                  })}
                </View>
                {!checked ? (
                  <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                    {!s && prevDay(d).shift ? <Btn title="Same as the day before" size="sm" variant="ghost" onPress={() => {
                      const p = prevDay(d);
                      const reason = (edit && edit.reason) || 'Same as the day before';
                      run(() => fillDay(user, { userUid: params.userUid, date: d, times: { in: p.in && p.in.time, break_out: p.break_out && p.break_out.time, break_in: p.break_in && p.break_in.time, out: p.out && p.out.time }, reason }), 'Day filled');
                    }} /> : null}
                    {!s && ro ? <Btn title="Rostered times" size="sm" variant="ghost" onPress={() => run(() => fillDay(user, { userUid: params.userUid, date: d, times: { in: ro.start, out: ro.end }, reason: 'Worked rostered hours' }), 'Day filled')} /> : null}
                    {s ? <Btn title="Clear day" size="sm" variant="ghost" onPress={async () => { const ok = await ui.confirm({ title: `Clear ${dayName(d)}?`, message: 'The times are cancelled (kept in the history).', confirmText: 'Clear', tone: 'danger' }); if (ok) run(() => clearDay(user, { userUid: params.userUid, date: d, reason: (edit && edit.reason) || 'Cleared on the weekly grid' }), 'Cleared'); }} /> : null}
                  </View>
                ) : null}
              </View>
            );
          })}
          <Card>
            <Row label="Week total" value={`${hm(w.totalMinutes)} h`} bold />
            {!checked ? <Btn testID="grid-check" title="Week checked ✓" variant="success" style={{ marginTop: 8 }} onPress={() => run(() => checkWeek(user, params.userUid, w.weekStart, ''), 'Week checked')} /> : null}
          </Card>
        </View>
        {!isPhone ? <View style={{ width: 420 }}>{picker || <Card><Text style={{ fontSize: 16, color: C.sub }}>Tap a time on the left to set it on the clock.</Text></Card>}</View> : null}
      </View>
      {isPhone && picker ? (
        <SafeModal visible transparent animationType="slide" onRequestClose={() => setEdit(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' }}>
            <ScrollView style={{ maxHeight: '92%' }} contentContainerStyle={{ padding: 10 }} keyboardShouldPersistTaps="handled">{picker}</ScrollView>
          </View>
        </SafeModal>
      ) : null}
    </Screen>
  );
}
