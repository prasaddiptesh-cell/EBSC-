// One person's week as a grid: tap a time to set it on the clock face. Every change needs a reason.
import React, { useState } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Field, Row, useApp, useUI, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { ClockFacePicker, nice } from '../../../ui/timePicker.js';
import { addDays, dayName } from '../../../services/core.js';
import { personWeek, dayCells, setDayTime, clearDay, fillDay, hm, checkWeek } from '../service.js';
import { plannedFor as rosterFor } from '../roster.js';
import { listUsers } from '../../../services/catalog.js';
import { ReasonField } from '../../../ui/kit.js';
import { SafeModal } from '../../../ui/safeModal.js';
import { TextInput } from '../../../ui/scale.js';
import { parseTime, fmtTime, timeFormat } from '../../../services/dates.js';
import { reasonRequired } from '../../../services/access.js';
import { saveDay, dayShop, setDayShop, problemText } from '../service.js';
import { listShops } from '../../admin/service.js';
import { DayEditor } from './TimesheetWeekScreen.js';

const CELL_LABEL = { in: 'Clock IN', break_out: 'Break start', break_in: 'Break end', out: 'Clock OUT' };
const ORDER = ['in', 'break_out', 'break_in', 'out'];

export default function TimesheetGridScreen({ params }) { return <PersonWeekGrid params={params} />; }
// Release 22 (owner: "when we run pay it should have this layout for timesheet"): the same week grid, inside the pay run
// (embedded) – after each change the pay is worked out again (onChanged).
export function PersonWeekGrid({ params, embedded, onChanged }) {
  const { user, nav } = useApp();
  const ui = useUI();
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date);
  const [edit, setEdit] = useState(null); // { date, cell, time, reason }
  const [, bump] = useState(0);
  const [dayOpen, setDayOpen] = useState(null);
  const [why, setWhy] = useState('');
  const [pickShop, setPickShop] = useState({});
  let shops = []; try { shops = listShops(); } catch (e) { shops = []; }
  const w = personWeek(params.userUid, date);
  const person = listUsers().find((u) => u.uid === params.userUid);
  const days = Array.from({ length: 7 }, (_, i) => addDays(w.weekStart, i));
  const checked = !!(w.check && w.check.status === 'checked');
  const run = (fn, msg) => { try { fn(); ui.toast(msg); setEdit(null); bump((n) => n + 1); if (onChanged) { try { onChanged(); } catch (e) { /* shown there */ } } } catch (e) { ui.error(e); } };

  const open = (d, cell, cur) => {
    if (checked) { ui.alert({ title: 'Week checked', message: 'Untick the week first (Timesheets › the person › Untick week).', tone: 'warn' }); return; }
    const ro = rosterFor(params.userUid, d);
    const guess = cur ? cur.time : cell === 'in' ? (ro ? ro.start : '08:00') : cell === 'out' ? (ro ? ro.end : '17:00') : cell === 'break_out' ? '12:00' : '12:30';
    setEdit({ date: d, cell, time: guess, reason: edit ? edit.reason : '' });
  };
  const prevDay = (d) => dayCells(params.userUid, addDays(d, -1));

  const picker = edit ? (
    <Card testID="grid-picker">
      <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub }}>{dayName(edit.date).toUpperCase()} {edit.date.slice(8)}/{edit.date.slice(5, 7)}</Text>
      <H>{CELL_LABEL[edit.cell]}</H>
      <ClockFacePicker testID="tp" value={edit.time} onChange={(v) => setEdit({ ...edit, time: v })}
        quick={(() => { const ro = rosterFor(params.userUid, edit.date); return ro ? [{ label: `Rostered ${nice(edit.cell === 'out' ? ro.end : ro.start)}`, value: edit.cell === 'out' ? ro.end : ro.start }] : []; })()} />
      <ReasonField testID="grid-reason" label="Reason (required)" value={edit.reason} onChangeText={(v) => setEdit({ ...edit, reason: v })} placeholder="e.g. forgot to clock out, paper timesheet" />
      <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
        <Btn title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(null)} />
        <Btn testID="grid-save" title={`Save ${nice(edit.time)}`} variant="primary" style={{ flex: 2 }} onPress={() => run(() => setDayTime(user, { userUid: params.userUid, ...edit }), 'Saved')} />
      </View>
    </Card>
  ) : null;

  return (
    <Wrap embedded={embedded} title={person ? person.name : 'Timesheet'} subtitle={`Week ${w.weekStart} – ${w.weekEnd} · ${hm(w.totalMinutes)} h`}>
      {embedded ? <Text style={{ fontSize: 16, fontWeight: '800', color: C.text }}>{`Timesheet – week ${w.weekStart} to ${w.weekEnd} · ${hm(w.totalMinutes)} h`}</Text> : null}
      {embedded ? null : <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setEdit(null); setDate(addDays(w.weekStart, -7)); }} />
        <Btn title="Week ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => { setEdit(null); setDate(addDays(w.weekStart, 7)); }} />
        <Btn title="Every punch" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => nav.push('TimesheetPerson', { userUid: params.userUid, date })} />
      </View>}
      {checked ? <Banner tone="success" title="Week checked" message="Untick it in Every punch to change times." /> : null}
      {!checked && reasonRequired(user) ? <ReasonField testID="grid-why" label="Why are times changed? (e.g. paper timesheet, forgot to clock out)" value={why} onChangeText={setWhy} /> : null}
      {!checked ? <Text style={{ fontSize: 13, color: C.sub }}>Type the times (8:30, 1730 or 5:30pm) and press Save on that day. A time out earlier than the time in is the next morning.</Text> : null}
      <View style={{ flexDirection: isPhone ? 'column' : 'row', gap: 14, alignItems: 'flex-start' }}>
        <View style={{ flex: 1, width: isPhone ? '100%' : undefined, gap: 8 }}>
          {days.map((d) => {
            const cur = dayCells(params.userUid, d);
            const s = cur.shift;
            const ro = rosterFor(params.userUid, d);
            const problem = s && s.problems;
            let mark = null; let note = null;
            try { const A = require('../absence.js'); mark = A.markOf(params.userUid, d); note = A.dayNote(params.userUid, d); } catch (e) { /* none */ }
            return (
              <View key={d} testID={`grid-day-${d}`} style={{ backgroundColor: problem ? C.warnSoft : C.card, borderRadius: 14, borderWidth: 1, borderColor: problem ? C.warn : C.border, padding: 10, gap: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Text style={{ fontSize: 18, fontWeight: '900', color: C.text, minWidth: 74 }}>{dayName(d)} {Number(d.slice(8))}</Text>
                  <Text style={{ fontSize: 13, color: C.sub, flex: 1 }}>{ro ? `Rostered ${nice(ro.start)}–${nice(ro.end)}` : 'Not rostered'}{s && s.autoBreak ? ' · auto break' : ''}{s && s.status === 'open' ? ' · still in' : ''}{problem ? ' · needs fixing' : ''}</Text>
                  <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>{s && s.workedMinutes ? hm(s.workedMinutes) : '–'}</Text>
                </View>
                {/* Release 21 (owner: "one day will have a sign in and sign out time, a break out and in – right now I have to
                    select the date and time"): the four times of the day typed straight in (8:30, 1730, 5:30pm), then Save */}
                {problem ? (() => { let lines = []; try { lines = problemText(s); } catch (e) { lines = []; } return lines.map((x) => <Text key={x} style={{ fontSize: 14, fontWeight: '700', color: C.warn }}>{`⚠ ${x.replace(/^[^:]+: /, '')}`}</Text>); })() : null}
                <TimeRow d={d} cur={cur} ro={ro} disabled={checked} onSave={(times) => run(() => saveDay(user, { userUid: params.userUid, date: d, times, shopCode: pickShop[d] || (cur.shift ? null : (person && person.shop_code)), reason: why || (reasonRequired(user) ? '' : 'Timesheet') }), 'Saved')} />
                {/* Release 24: which shop the person worked at that day */}
                {shops.length > 1 ? (
                  <View testID={`grid-shop-${d}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <Text style={{ fontSize: 14, fontWeight: '800', color: C.text }}>Worked at:</Text>
                    {shops.map((sh) => {
                      const on = (cur.shift ? dayShop(params.userUid, d) : pickShop[d] || null) === sh.code;
                      return <Btn key={sh.code} testID={`grid-shop-${d}-${sh.code}`} title={sh.name || sh.code} size="sm" variant={on ? 'primary' : 'secondary'} disabled={checked}
                        onPress={() => { if (!cur.shift) { setPickShop((o) => ({ ...o, [d]: sh.code })); return; } if (on) return; run(() => setDayShop(user, { userUid: params.userUid, date: d, shopCode: sh.code, reason: why || (reasonRequired(user) ? '' : 'Timesheet') }), `Worked at ${sh.name || sh.code}`); }} />;
                    })}
                  </View>
                ) : null}
                {mark ? <Text style={{ fontSize: 14, fontWeight: '700', color: C.text }}>{`${mark.reason || mark.kind}`}</Text> : null}
                {/* Release 24 (owner: "the note that we put here should be visible"): the note shown in full, in a yellow box */}
                {note ? (
                  <Pressable testID={`grid-notebox-${d}`} onPress={() => !checked && setDayOpen(`${d}|note`)} style={{ backgroundColor: '#FFF6D6', borderColor: '#E9C46A', borderWidth: 1, borderRadius: 10, padding: 10 }}>
                    <Text style={{ fontSize: 12, fontWeight: '800', color: '#8A6D1F' }}>💬 NOTE{note.by_name ? ` – ${note.by_name}` : ''}</Text>
                    <Text style={{ fontSize: 16, color: C.text, marginTop: 2 }}>{note.note}</Text>
                  </Pressable>
                ) : null}
                {!checked ? (
                  <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                    <Btn testID={`grid-off-${d}`} title="Day off" icon="🏖️" size="sm" variant={mark && mark.kind === 'off' ? 'primary' : 'secondary'} onPress={() => run(() => require('../absence.js').markDay(user, { userUid: params.userUid, date: d, kind: mark && mark.kind === 'off' ? 'work' : 'off', reason: why }), mark && mark.kind === 'off' ? 'Day off taken away' : 'Day off')} />
                    <Btn testID={`grid-sick-${d}`} title="Sick" icon="🤒" size="sm" variant={mark && mark.kind === 'sick' ? 'primary' : 'secondary'} onPress={() => setDayOpen(dayOpen === `${d}|sick` ? null : `${d}|sick`)} />
                    <Btn testID={`grid-note-${d}`} title={note ? '💬 Edit note' : '💬 Add note'} size="sm" variant="ghost" onPress={() => setDayOpen(dayOpen === `${d}|note` ? null : `${d}|note`)} />
                    {mark && mark.kind !== 'off' ? <Btn testID={`grid-work-${d}`} title="Working (clear)" size="sm" variant="ghost" onPress={() => run(() => require('../absence.js').markDay(user, { userUid: params.userUid, date: d, kind: 'work', reason: why }), 'Cleared')} /> : null}
                  </View>
                ) : null}
                {dayOpen && dayOpen.startsWith(`${d}|`) && person ? <DayEditor key={dayOpen} start={dayOpen.split('|')[1]} user={user} person={person} date={d} onClose={() => setDayOpen(null)} onDone={() => { setDayOpen(null); bump((n) => n + 1); }} /> : null}
                {!checked ? (
                  <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                    {!s && prevDay(d).shift ? <Btn title="Same as the day before" size="sm" variant="ghost" onPress={() => {
                      const p = prevDay(d);
                      const reason = (edit && edit.reason) || 'Same as the day before';
                      run(() => fillDay(user, { userUid: params.userUid, date: d, times: { in: p.in && p.in.time, break_out: p.break_out && p.break_out.time, break_in: p.break_in && p.break_in.time, out: p.out && p.out.time }, reason }), 'Day filled');
                    }} /> : null}
                    {!s && ro ? <Btn title="Rostered times" size="sm" variant="ghost" onPress={() => run(() => fillDay(user, { userUid: params.userUid, date: d, times: { in: ro.start, out: ro.end }, reason: 'Worked rostered hours' }), 'Day filled')} /> : null}
                    {s ? <Btn title="Clear day" size="sm" variant="ghost" onPress={async () => { const ok = await ui.confirm({ title: `Clear ${dayName(d)}?`, message: 'The times are cancelled (kept in the history).', confirmText: 'Clear', tone: 'danger' }); if (ok) run(() => clearDay(user, { userUid: params.userUid, date: d, reason: (edit && edit.reason) || 'Cleared on the weekly grid' }), 'Cleared'); }} /> : null}
                  </View>
                ) : null}
              </View>
            );
          })}
          <Card>
            <Row label="Week total" value={`${hm(w.totalMinutes)} h`} bold />
            {!checked ? <Btn testID="grid-check" title="Week checked ✓" variant="success" style={{ marginTop: 8 }} onPress={() => run(() => checkWeek(user, params.userUid, w.weekStart, ''), 'Week checked')} /> : null}
          </Card>
        </View>
        {!isPhone && picker ? <View style={{ width: 420 }}>{picker}</View> : null}
      </View>
      {isPhone && picker ? (
        <SafeModal visible transparent animationType="slide" onRequestClose={() => setEdit(null)}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' }}>
            <ScrollView style={{ maxHeight: '92%' }} contentContainerStyle={{ padding: 10 }} keyboardShouldPersistTaps="handled">{picker}</ScrollView>
          </View>
        </SafeModal>
      ) : null}
    </Wrap>
  );
}

// Release 21: one day's four times typed in a row.
const BOX = { in: 'Sign in', break_out: 'Break out', break_in: 'Break in', out: 'Sign out' };
function TimeRow({ d, cur, ro, disabled, onSave }) {
  const fmt = timeFormat();
  const now = (c) => (cur[c] ? cur[c].time : '');
  const [v, setV] = useState({ in: now('in'), break_out: now('break_out'), break_in: now('break_in'), out: now('out') });
  const [txt, setTxt] = useState({});
  React.useEffect(() => { setV({ in: now('in'), break_out: now('break_out'), break_in: now('break_in'), out: now('out') }); setTxt({}); }, [now('in'), now('break_out'), now('break_in'), now('out')]);
  const changed = ORDER.some((c) => (v[c] || '') !== now(c));
  const bad = ORDER.filter((c) => txt[c] !== undefined && txt[c] !== '' && !parseTime(txt[c]).ok);
  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {ORDER.map((c) => (
          <View key={c} style={{ flexGrow: 1, flexBasis: 110, gap: 2 }}>
            <Text style={{ fontSize: 12, color: C.sub, fontWeight: '700' }}>{BOX[c]}</Text>
            <TextInput testID={`grid-${d}-${c}`} editable={!disabled} keyboardType="numbers-and-punctuation"
              value={txt[c] !== undefined ? txt[c] : v[c] ? fmtTime(v[c], fmt) : ''}
              placeholder={c === 'in' && ro ? fmtTime(ro.start, fmt) : c === 'out' && ro ? fmtTime(ro.end, fmt) : '–'} placeholderTextColor="#B8AEA3"
              onChangeText={(t) => { setTxt((o) => ({ ...o, [c]: t })); const r = parseTime(t); setV((o) => ({ ...o, [c]: r.ok ? r.hhmm : t.trim() === '' ? '' : o[c] })); }}
              style={{ minHeight: 48, borderRadius: 10, borderWidth: 2, borderColor: bad.includes(c) ? C.danger : cur[c] ? C.border : '#CFC6BC', borderStyle: cur[c] ? 'solid' : 'dashed', backgroundColor: disabled ? '#F4F1EC' : C.white, paddingHorizontal: 10, fontSize: 17, fontWeight: '700', color: C.text }} />
            {cur[c] && cur[c].date !== d ? <Text style={{ fontSize: 11, color: C.sub }}>next day</Text> : null}
          </View>
        ))}
      </View>
      {changed && !disabled ? <Btn testID={`grid-save-${d}`} title={bad.length ? 'Check the times' : 'Save this day'} icon="💾" size="sm" variant="success" disabled={!!bad.length} onPress={() => onSave(v)} /> : null}
      {!cur.shift && ro && !changed && !disabled ? <Btn testID={`grid-ros-${d}`} title={`Worked the roster (${fmtTime(ro.start, fmt)} – ${fmtTime(ro.end, fmt)})`} size="sm" variant="ghost" onPress={() => onSave({ in: ro.start, out: ro.end })} /> : null}
    </View>
  );
}

function Wrap({ embedded, title, subtitle, children }) {
  if (embedded) return <View style={{ gap: 10 }}>{children}</View>;
  return <Screen title={title} subtitle={subtitle}>{children}</Screen>;
}
