// One person's week: every shift and punch, and the manager's fixes (always with a reason).
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Badge, Banner, Chips, Field, Row, Section, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { can } from '../../../services/access.js';
import { addDays, dayName, hhmm, stamp } from '../../../services/core.js';
import { personWeek, hm, FLAG_LABEL, PROBLEM_FLAGS, fixAddPunch, fixCancelPunch, fixChangeTime, checkWeek, uncheckWeek } from '../service.js';
import { TYPE_LABEL } from '../../timeclock/service.js';

const FACE_TEXT = { match: 'face ✓', no_match: 'face ✗', no_face: 'no face', not_enrolled: 'not enrolled', unavailable: 'face n/a', photo_only: 'photo' };

export default function TimesheetPersonScreen({ params }) {
  const { user } = useApp();
  const ui = useUI();
  const [date, setDate] = useState(params.date);
  const [, refresh] = useState(0);
  const [edit, setEdit] = useState(null); // { mode: 'add'|'change'|'cancel', punch, type, at, reason }
  const [note, setNote] = useState('');
  const w = personWeek(params.userUid, date);
  const mayEdit = can(user, 'timesheets_edit');
  const checked = !!(w.check && w.check.status === 'checked');
  const days = Array.from({ length: 7 }, (_, i) => addDays(w.weekStart, i));

  const run = (fn, msg) => {
    try {
      fn();
      ui.toast(msg);
      setEdit(null);
      refresh((n) => n + 1);
    } catch (e) {
      ui.error(e);
    }
  };
  const save = () => {
    const e = edit;
    if (e.mode === 'add') run(() => fixAddPunch(user, { userUid: params.userUid, type: e.type, at: e.at, reason: e.reason }), 'Added');
    if (e.mode === 'change') run(() => fixChangeTime(user, e.punch.uid, e.at, e.reason), 'Time changed');
    if (e.mode === 'cancel') run(() => fixCancelPunch(user, e.punch.uid, e.reason), 'Cancelled');
  };

  return (
    <Screen title={w.user ? w.user.name : 'Timesheet'} subtitle={`Week ${w.weekStart} to ${w.weekEnd} · ${hm(w.totalMinutes)} hours`}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="‹ Previous week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(w.weekStart, -7))} />
        <Btn title="Next week ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(w.weekStart, 7))} />
      </View>
      {checked ? <Banner testID="week-checked" tone="success" title={`Week checked by ${w.check.checked_by_name || '?'}`} message={`${w.check.checked_at}${w.check.note ? ` · ${w.check.note}` : ''}. Untick it to make changes.`} /> : null}

      <Section title="Shifts">
        {!w.shifts.length ? <Text style={{ fontSize: 16, color: C.sub }}>No shifts this week.</Text> : null}
        {days.map((d) => w.shifts.filter((s) => s.date === d).map((s, i) => (
          <Card key={d + i} tone={s.problems ? 'danger' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, minWidth: 110 }}>{dayName(d)} {d.slice(8)}/{d.slice(5, 7)}</Text>
              <Text style={{ fontSize: 18, color: C.text }}>{s.in_at ? hhmm(s.in_at) : '??'} – {s.out_at ? hhmm(s.out_at) : '??'}</Text>
              {s.breakMinutes ? <Text style={{ fontSize: 15, color: C.sub }}>break {s.breakMinutes} min{s.autoBreak ? ' (auto)' : ''}</Text> : null}
              <View style={{ flex: 1 }} />
              <Text style={{ fontSize: 20, fontWeight: '900', color: C.text }}>{hm(s.workedMinutes)}</Text>
            </View>
            {s.flags.length ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 }}>
                {s.flags.map((f) => <Badge key={f} text={FLAG_LABEL[f] || f} color={PROBLEM_FLAGS.includes(f) ? C.danger : f === 'open' ? C.info : C.sub} />)}
              </View>
            ) : null}
          </Card>
        )))}
      </Section>

      <Section title="Every punch (cancelled ones kept for the record)">
        {w.punches.map((p) => (
          <View key={p.uid} style={{ borderBottomWidth: 1, borderBottomColor: '#F0EBE3', paddingVertical: 8, opacity: p.voided ? 0.55 : 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, textDecorationLine: p.voided ? 'line-through' : 'none' }}>
                {dayName(p.at)} {p.at.slice(8, 10)}/{p.at.slice(5, 7)} {hhmm(p.at)} · {TYPE_LABEL[p.type]}
              </Text>
              {p.method === 'manual' ? <Badge text="manager" color={C.warn} /> : null}
              {p.face_result && FACE_TEXT[p.face_result] ? <Badge text={FACE_TEXT[p.face_result]} color={p.face_result === 'match' ? C.success : ['no_match', 'no_face'].includes(p.face_result) ? C.danger : C.sub} /> : null}
              {p.voided ? <Badge text="cancelled" color={C.sub} /> : null}
              <View style={{ flex: 1 }} />
              {mayEdit && !p.voided && !checked ? (
                <>
                  <Btn testID={`change-${p.uid}`} title="Change time" size="sm" variant="secondary" onPress={() => setEdit({ mode: 'change', punch: p, at: p.at.slice(0, 16), reason: '' })} />
                  <Btn testID={`cancel-${p.uid}`} title="Cancel" size="sm" variant="ghost" onPress={() => setEdit({ mode: 'cancel', punch: p, reason: '' })} />
                </>
              ) : null}
            </View>
            {p.reason ? <Text style={{ fontSize: 14, color: C.sub }}>Reason: {p.reason}</Text> : null}
            {p.voided ? <Text style={{ fontSize: 14, color: C.sub }}>Cancelled: {p.void_reason}</Text> : null}
            <Text style={{ fontSize: 13, color: C.sub }}>Recorded {p.recorded_at} on {p.device || '?'}{p.photo_url ? ' · photo saved' : p.photo_uri ? ' · photo waiting to upload' : ''}</Text>
          </View>
        ))}
        {!w.punches.length ? <Text style={{ fontSize: 16, color: C.sub }}>No punches.</Text> : null}
      </Section>

      {mayEdit && !checked ? (
        <Card>
          {edit ? (
            <View style={{ gap: 12 }}>
              <H>{edit.mode === 'add' ? 'Add a missing punch' : edit.mode === 'change' ? `Change ${TYPE_LABEL[edit.punch.type]} time` : `Cancel ${TYPE_LABEL[edit.punch.type]} at ${hhmm(edit.punch.at)}`}</H>
              {edit.mode === 'add' ? (
                <Chips value={edit.type} onChange={(v) => setEdit({ ...edit, type: v })} testIDPrefix="fix-type"
                  options={Object.keys(TYPE_LABEL).map((k) => ({ value: k, label: TYPE_LABEL[k] }))} />
              ) : null}
              {edit.mode !== 'cancel' ? <Field testID="fix-at" label="Date and time (YYYY-MM-DD HH:MM)" value={edit.at} onChangeText={(v) => setEdit({ ...edit, at: v })} /> : null}
              <Field testID="fix-reason" label="Reason (required)" value={edit.reason} onChangeText={(v) => setEdit({ ...edit, reason: v })} placeholder="e.g. forgot to clock out, left at 5pm" />
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Btn title="Back" variant="secondary" style={{ flex: 1 }} onPress={() => setEdit(null)} />
                <Btn testID="fix-save" title="Save" variant={edit.mode === 'cancel' ? 'danger' : 'primary'} style={{ flex: 1 }} onPress={save} />
              </View>
            </View>
          ) : (
            <View style={{ gap: 10 }}>
              <Btn testID="fix-add" title="Add a missing punch" icon="➕" variant="secondary" onPress={() => setEdit({ mode: 'add', type: 'OUT', at: `${w.weekStart} 17:00`, reason: '' })} />
              <Field testID="check-note" label="Note for the week (optional)" value={note} onChangeText={setNote} />
              <Btn testID="check-week" title="Week checked ✓" variant="success" onPress={() => run(() => checkWeek(user, params.userUid, w.weekStart, note), 'Week checked')} />
            </View>
          )}
        </Card>
      ) : null}
      {mayEdit && checked ? (
        <Card>
          <Field testID="uncheck-reason" label="Reason to untick (required)" value={note} onChangeText={setNote} />
          <Btn testID="uncheck-week" title="Untick week" variant="warn" style={{ marginTop: 10 }} onPress={() => run(() => uncheckWeek(user, params.userUid, w.weekStart, note), 'Week unticked')} />
        </Card>
      ) : null}
      {w.user ? <Row label="Generated" value={stamp()} /> : null}
    </Screen>
  );
}
