// The weekly timesheet (Saturday-Friday) for everyone, or one shop.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Chips, Btn, Badge, Banner, Card, useApp, useLayout, useRemembered, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, MoneyField, ReasonField } from '../../../ui/kit.js';
import { can } from '../../../services/access.js';
import { money } from '../../../services/core.js';
import { db } from '../../../db/connection.js';
import { dateStr, addDays, dayName } from '../../../services/core.js';
import { weekTimesheet, hm } from '../service.js';

// 1.0.0 build 19: the fixed weekly pay of salaried staff, changed right here for this week only or from this week on.
function payApi() { try { return require('../../payroll/service.js'); } catch (e) { return null; } }
function FixedPay({ user, person, weekStart, onDone }) {
  const ui = useUI();
  const P = payApi();
  const [ed, setEd] = useState(null);
  const fp = P ? (() => { try { return P.weekFixedPay(person.uid, weekStart); } catch (e) { return null; } })() : null;
  if (!fp) return null;
  const id = person.employee_no || person.uid;
  const save = () => {
    try { P.setWeekFixedPay(user, { userUid: person.uid, weekStart, amount: ed.amount, scope: ed.scope, reason: ed.reason }); ui.toast(ed.scope === 'after' ? 'Fixed pay changed from this week on' : 'Fixed pay changed for this week'); setEd(null); onDone(); } catch (e) { ui.error(e); }
  };
  return (
    <View style={{ marginTop: 8, borderTopWidth: 1, borderTopColor: C.border, paddingTop: 8 }}>
      {!ed ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={{ flex: 1, fontSize: 15, color: C.sub, fontWeight: '700' }}>Fixed pay this week{fp.changed ? ` (usual ${money(fp.usual)})` : ''}</Text>
          <Text testID={`fixed-pay-${id}`} style={{ fontSize: 18, fontWeight: '900', color: fp.changed ? C.warn : C.text }}>{money(fp.week)}</Text>
          <Btn testID={`fixed-edit-${id}`} title="✎ Change" size="sm" variant="secondary" onPress={() => setEd({ amount: String(fp.week), scope: 'week', reason: '' })} />
        </View>
      ) : (
        <View style={{ gap: 6 }}>
          <MoneyField testID={`fixed-amount-${id}`} label={`Fixed pay for the week of ${weekStart}`} value={ed.amount} onChange={(v) => setEd({ ...ed, amount: v })} />
          <Chips value={ed.scope} onChange={(v) => setEd({ ...ed, scope: v })} testIDPrefix={`fixed-scope-${id}`}
            options={[{ value: 'week', label: 'Only this week' }, { value: 'after', label: 'This week and after' }]} />
          <ReasonField testID={`fixed-reason-${id}`} label="Why" value={ed.reason} onChangeText={(v) => setEd({ ...ed, reason: v })} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setEd(null)} />
            <Btn testID={`fixed-save-${id}`} title="Save" size="md" variant="success" style={{ flex: 1 }} onPress={save} />
          </View>
        </View>
      )}
    </View>
  );
}

export default function TimesheetWeekScreen({ params }) {
  const { nav, user } = useApp();
  const [, bump] = useState(0);
  const seesPay = !!user && can(user, 'payroll_run');
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShop] = useRemembered('shop', params.shop || 'ALL');
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const ts = weekTimesheet(date, { shopCode: shop === 'ALL' ? null : shop });
  const problems = ts.rows.reduce((a, r) => a + r.problems, 0);
  const checked = ts.rows.filter((r) => r.checked).length;
  const total = ts.rows.reduce((a, r) => a + r.totalMinutes, 0);
  return (
    <Screen title="Timesheets" subtitle={`Week ${ts.weekStart} to ${ts.weekEnd} (Sat-Fri)`}
      footer={<Btn title="Timesheet reports" icon="📄" size="md" variant="info" onPress={() => nav.push('ReportsHub', { group: 'Timesheets' })} />}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn testID="week-prev" title="‹ Previous" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, -7))} />
        <Btn testID="week-this" title="This week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(dateStr())} />
        <Btn testID="week-next" title="Next ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, 7))} />

      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Btn testID="week-roster" title="Roster planner" icon="📅" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('RosterPlanner', {})} />
        <Btn testID="week-pva" title="Planned vs worked" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('PlanVsActual', { date: ts.weekStart })} />
        <Btn testID="week-won" title="Who is on now" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('WhoIsOn', {})} />
        <Btn testID="week-usual" title="Usual weeks" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('Roster')} />
      </View>
      <Hint>Tap a person to see and change their week. Changes need a reason (optional for the owner and admin) and are kept in the history. A week that has been paid cannot be changed.</Hint>
      <Chips value={shop} onChange={setShop} testIDPrefix="ts-shop"
        options={[{ value: 'ALL', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {[['Hours', hm(total), C.text], ['To fix', String(problems), problems ? C.danger : C.success], ['Weeks checked', `${checked} of ${ts.rows.length}`, checked === ts.rows.length && ts.rows.length ? C.success : C.warn]].map(([l, v, col]) => (
          <View key={l} style={{ flexGrow: 1, minWidth: 120, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, borderLeftWidth: 5, borderLeftColor: C.brandRed }}>
            <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{l.toUpperCase()}</Text>
            <Text style={{ fontSize: 24, fontWeight: '900', color: col }}>{v}</Text>
          </View>
        ))}
      </View>
      {problems ? <Banner tone="warn" title={`${problems} thing(s) to fix`} message="Tap a person with a red number to fix missing Clock IN/OUT and other problems." /> : null}
      {!ts.rows.length ? <Banner tone="info" message="No staff in this shop yet." /> : null}
      {ts.rows.map((r) => (
        <View key={r.user.uid}>
        <Pressable testID={`ts-row-${r.user.employee_no || r.user.uid}`} onPress={() => nav.push('TimesheetGrid', { userUid: r.user.uid, date: ts.weekStart })}>
          <Card tone={r.problems ? 'danger' : r.checked ? 'success' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{r.user.name}{r.user.active ? '' : ' (left)'}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{r.user.employee_no || ''} {r.user.shop_code || ''}</Text>
              </View>
              {r.problems ? <Badge text={`${r.problems} to fix`} color={C.danger} /> : null}
              {r.checked ? <Badge text="✓ Checked" color={C.success} /> : null}
              <Text style={{ fontSize: 22, fontWeight: '900', color: C.text, minWidth: 70, textAlign: 'right' }}>{hm(r.totalMinutes)}</Text>
            </View>
            <View style={{ flexDirection: 'row', marginTop: 8, gap: 4 }}>
              {ts.days.map((d) => {
                const list = r.days[d];
                const mins = list.reduce((a, s) => a + s.workedMinutes, 0);
                const bad = list.some((s) => s.problems);
                return (
                  <View key={d} style={{ flex: 1, alignItems: 'center', borderRadius: 8, paddingVertical: 4, backgroundColor: bad ? C.dangerSoft : mins ? '#F2EEEA' : 'transparent' }}>
                    <Text style={{ fontSize: 12, color: C.sub, fontWeight: '700' }}>{isPhone ? dayName(d).slice(0, 2) : dayName(d)}</Text>
                    <Text style={{ fontSize: isPhone ? 12 : 15, fontWeight: '800', color: bad ? C.danger : C.text }}>{bad && !mins ? '!' : mins ? hm(mins) : '–'}</Text>
                  </View>
                );
              })}
            </View>
          </Card>
        </Pressable>
        {seesPay ? <View style={{ marginTop: -6, paddingHorizontal: 12 }}><FixedPay user={user} person={r.user} weekStart={ts.weekStart} onDone={() => bump((n) => n + 1)} /></View> : null}
        </View>
      ))}
    </Screen>
  );
}
