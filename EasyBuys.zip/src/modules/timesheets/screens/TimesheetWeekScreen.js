// The weekly timesheet (Saturday-Friday) for everyone, or one shop.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Chips, Btn, Badge, Banner, Card, useApp, useLayout } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { db } from '../../../db/connection.js';
import { dateStr, addDays, dayName } from '../../../services/core.js';
import { weekTimesheet, hm } from '../service.js';

export default function TimesheetWeekScreen({ params }) {
  const { nav } = useApp();
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShop] = useState(params.shop || 'ALL');
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const ts = weekTimesheet(date, { shopCode: shop === 'ALL' ? null : shop });
  const problems = ts.rows.reduce((a, r) => a + r.problems, 0);
  const checked = ts.rows.filter((r) => r.checked).length;
  const total = ts.rows.reduce((a, r) => a + r.totalMinutes, 0);
  return (
    <Screen title="Timesheets" subtitle={`Week ${ts.weekStart} to ${ts.weekEnd} (Sat-Fri)`}
      footer={<Btn title="Timesheet reports" icon="📄" size="md" variant="info" onPress={() => nav.push('ReportsHub', { group: 'Timesheets' })} />}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn testID="week-prev" title="‹ Previous" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, -7))} />
        <Btn testID="week-this" title="This week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(dateStr())} />
        <Btn testID="week-next" title="Next ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, 7))} />

      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Btn testID="week-roster" title="Roster planner" icon="📅" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('RosterPlanner', {})} />
        <Btn testID="week-pva" title="Planned vs worked" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('PlanVsActual', { date: ts.weekStart })} />
        <Btn testID="week-won" title="Who is on now" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('WhoIsOn', {})} />
        <Btn testID="week-usual" title="Usual weeks" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('Roster')} />
      </View>
      <Hint>Tap a person to see and change their week. Changes always need a reason and are kept in the history. A week that has been paid cannot be changed.</Hint>
      <Chips value={shop} onChange={setShop} testIDPrefix="ts-shop"
        options={[{ value: 'ALL', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {[['Hours', hm(total), C.text], ['To fix', String(problems), problems ? C.danger : C.success], ['Weeks checked', `${checked} of ${ts.rows.length}`, checked === ts.rows.length && ts.rows.length ? C.success : C.warn]].map(([l, v, col]) => (
          <View key={l} style={{ flexGrow: 1, minWidth: 120, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, borderLeftWidth: 5, borderLeftColor: C.brandRed }}>
            <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{l.toUpperCase()}</Text>
            <Text style={{ fontSize: 24, fontWeight: '900', color: col }}>{v}</Text>
          </View>
        ))}
      </View>
      {problems ? <Banner tone="warn" title={`${problems} thing(s) to fix`} message="Tap a person with a red number to fix missing Clock IN/OUT and other problems." /> : null}
      {!ts.rows.length ? <Banner tone="info" message="No staff in this shop yet." /> : null}
      {ts.rows.map((r) => (
        <Pressable key={r.user.uid} testID={`ts-row-${r.user.employee_no || r.user.uid}`} onPress={() => nav.push('TimesheetGrid', { userUid: r.user.uid, date: ts.weekStart })}>
          <Card tone={r.problems ? 'danger' : r.checked ? 'success' : undefined}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{r.user.name}{r.user.active ? '' : ' (left)'}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{r.user.employee_no || ''} {r.user.shop_code || ''}</Text>
              </View>
              {r.problems ? <Badge text={`${r.problems} to fix`} color={C.danger} /> : null}
              {r.checked ? <Badge text="✓ Checked" color={C.success} /> : null}
              <Text style={{ fontSize: 22, fontWeight: '900', color: C.text, minWidth: 70, textAlign: 'right' }}>{hm(r.totalMinutes)}</Text>
            </View>
            <View style={{ flexDirection: 'row', marginTop: 8, gap: 4 }}>
              {ts.days.map((d) => {
                const list = r.days[d];
                const mins = list.reduce((a, s) => a + s.workedMinutes, 0);
                const bad = list.some((s) => s.problems);
                return (
                  <View key={d} style={{ flex: 1, alignItems: 'center', borderRadius: 8, paddingVertical: 4, backgroundColor: bad ? C.dangerSoft : mins ? '#F2EEEA' : 'transparent' }}>
                    <Text style={{ fontSize: 12, color: C.sub, fontWeight: '700' }}>{isPhone ? dayName(d).slice(0, 2) : dayName(d)}</Text>
                    <Text style={{ fontSize: isPhone ? 12 : 15, fontWeight: '800', color: bad ? C.danger : C.text }}>{bad && !mins ? '!' : mins ? hm(mins) : '–'}</Text>
                  </View>
                );
              })}
            </View>
          </Card>
        </Pressable>
      ))}
    </Screen>
  );
}
