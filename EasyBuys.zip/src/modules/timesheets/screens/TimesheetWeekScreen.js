// The weekly timesheet (Saturday-Friday) for everyone, or one shop.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Chips, Btn, Badge, Banner, Card, PhotoPicker, useApp, useLayout, useRemembered, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint, MoneyField, ReasonField } from '../../../ui/kit.js';
import { can } from '../../../services/access.js';
import { money } from '../../../services/core.js';
import { db } from '../../../db/connection.js';
import { dateStr, addDays, dayName } from '../../../services/core.js';
import { weekTimesheet, hm, dayCells, saveDay, weekAsRostered } from '../service.js';
import { TimeField } from '../../../ui/timePicker.js';
import { reasonRequired } from '../../../services/access.js';

// 1.0.0 build 19: the fixed weekly pay of salaried staff, changed right here for this week only or from this week on.
function payApi() { try { return require('../../payroll/service.js'); } catch (e) { return null; } }
function FixedPay({ user, person, weekStart, onDone }) {
  const ui = useUI();
  const P = payApi();
  const [ed, setEd] = useState(null);
  const fp = P ? (() => { try { return P.weekFixedPay(person.uid, weekStart); } catch (e) { return null; } })() : null;
  if (!fp) return null;
  const id = person.employee_no || person.uid;
  const save = () => {
    try { P.setWeekFixedPay(user, { userUid: person.uid, weekStart, amount: ed.amount, scope: ed.scope, reason: ed.reason }); ui.toast(ed.scope === 'after' ? 'Fixed pay changed from this week on' : 'Fixed pay changed for this week'); setEd(null); onDone(); } catch (e) { ui.error(e); }
  };
  return (
    <View style={{ marginTop: 8, borderTopWidth: 1, borderTopColor: C.border, paddingTop: 8 }}>
      {!ed ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={{ flex: 1, fontSize: 15, color: C.sub, fontWeight: '700' }}>Fixed pay this week{fp.changed ? ` (usual ${money(fp.usual)})` : ''}</Text>
          <Text testID={`fixed-pay-${id}`} style={{ fontSize: 18, fontWeight: '900', color: fp.changed ? C.warn : C.text }}>{money(fp.week)}</Text>
          <Btn testID={`fixed-edit-${id}`} title="✎ Change" size="sm" variant="secondary" onPress={() => setEd({ amount: String(fp.week), scope: 'week', reason: '' })} />
        </View>
      ) : (
        <View style={{ gap: 6 }}>
          <MoneyField testID={`fixed-amount-${id}`} label={`Fixed pay for the week of ${weekStart}`} value={ed.amount} onChange={(v) => setEd({ ...ed, amount: v })} />
          <Chips value={ed.scope} onChange={(v) => setEd({ ...ed, scope: v })} testIDPrefix={`fixed-scope-${id}`}
            options={[{ value: 'week', label: 'Only this week' }, { value: 'after', label: 'This week and after' }]} />
          <ReasonField testID={`fixed-reason-${id}`} label="Why" value={ed.reason} onChangeText={(v) => setEd({ ...ed, reason: v })} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setEd(null)} />
            <Btn testID={`fixed-save-${id}`} title="Save" size="md" variant="success" style={{ flex: 1 }} onPress={save} />
          </View>
        </View>
      )}
    </View>
  );
}

// Release 03: fix a day right here – start, break, finish (filled from the roster), or day off / sick / leave – no
// jumping to another screen. Staff and managers give a reason; the owner and admins need not.
export function DayEditor({ user, person, date, onDone, onClose, start }) {
  // Release 20 (owner, 14 Nov: "for one day or shift there should be a time in, time out; day off a button; if sick then
  // with sick sheet or not, and a button to say if they are going to get paid"): one day, simply.
  const ui = useUI();
  const cur = (() => { try { return dayCells(person.uid, date); } catch (e) { return {}; } })();
  let ro = null;
  try { ro = require('../roster.js').plannedFor(person.uid, date); } catch (e) { ro = null; }
  let mk = null;
  try { mk = require('../absence.js').markOf(person.uid, date); } catch (e) { mk = null; }
  const t = (c) => (cur[c] ? cur[c].time : '');
  const [f, setF] = useState({ in: t('in') || (ro && ro.start) || '', break_out: t('break_out'), break_in: t('break_in'), out: t('out') || (ro && ro.end) || '', reason: '' });
  const [brk, setBrk] = useState(!!(t('break_out') || t('break_in')));
  const [sick, setSick] = useState(start === 'sick' ? { sheet: false, paid: false, photos: [] } : null); // { sheet, paid, photos }
  // Release 21: the internal note of the day (managers / payroll only) – shown when "Note" is pressed, or when there is one
  const note0 = (() => { try { return require('../absence.js').dayNote(person.uid, date); } catch (e) { return null; } })();
  const [noteOpen, setNoteOpen] = useState(!!note0 || start === 'note');
  const [note, setNote] = useState(note0 ? note0.note : '');
  const needWhy = reasonRequired(user);
  const run = (fn, msg) => { try { fn(); ui.toast(msg); onDone(); } catch (e) { ui.error(e); } };
  const mark = (kind, extra = {}) => run(() => require('../absence.js').markDay(user, { userUid: person.uid, date, kind, reason: f.reason, ...extra }), 'Saved');
  const id = person.employee_no || person.uid;
  const half = { flexGrow: 1, flexBasis: 140 };
  return (
    <View testID={`day-edit-${id}-${date}`}><Card>
      <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{`${person.name} – ${dayName(date)} ${date.slice(8, 10)}`}</Text>
      <Text style={{ fontSize: 13, color: C.sub }}>{mk ? `Marked: ${mk.reason || mk.kind}` : ro ? `Rostered ${ro.start}–${ro.end}` : 'Not rostered this day'}</Text>
      {start === 'note' ? null : !sick ? (
        <>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <View style={half}><TimeField testID="de-in" label="Time in" value={f.in} onChange={(v) => setF({ ...f, in: v })} /></View>
            <View style={half}><TimeField testID="de-out" label="Time out" value={f.out} onChange={(v) => setF({ ...f, out: v })} /></View>
          </View>
          {brk ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              <View style={half}><TimeField testID="de-bo" label="Break start" optional value={f.break_out} onChange={(v) => setF({ ...f, break_out: v })} /></View>
              <View style={half}><TimeField testID="de-bi" label="Break end" optional value={f.break_in} onChange={(v) => setF({ ...f, break_in: v })} /></View>
            </View>
          ) : <Btn testID="de-addbreak" title="+ Add a break" size="sm" variant="ghost" onPress={() => setBrk(true)} />}
          {needWhy ? <ReasonField testID="de-reason" label="Why (e.g. forgot to clock out)" value={f.reason} onChangeText={(v) => setF({ ...f, reason: v })} /> : null}
          <Btn testID="de-save" title="Save the times" icon="💾" size="md" variant="success" onPress={() => run(() => saveDay(user, { userUid: person.uid, date, times: { in: f.in, break_out: brk ? f.break_out : '', break_in: brk ? f.break_in : '', out: f.out }, reason: f.reason }), 'Saved')} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <Btn testID="de-off" title="Day off" icon="🏖️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => mark('off')} />
            <Btn testID="de-sick" title="Sick" icon="🤒" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => setSick({ sheet: false, paid: false, photos: [] })} />
            <Btn testID="de-leave" title="Leave" icon="✈️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => mark('leave')} />
            {mk ? <Btn testID="de-work" title="Working (clear the mark)" size="md" variant="ghost" style={{ flexGrow: 1 }} onPress={() => mark('work')} /> : null}
          </View>
        </>
      ) : (
        <>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.text }}>Sick sheet (medical certificate)?</Text>
          <Chips testIDPrefix="de-sheet" value={sick.sheet ? 'yes' : 'no'} onChange={(v) => setSick({ ...sick, sheet: v === 'yes', paid: v === 'yes' })} options={[{ value: 'yes', label: 'Yes, sick sheet' }, { value: 'no', label: 'No sick sheet' }]} />
          {sick.sheet ? <PhotoPicker testID="de-sheet-photo" label="Photo of the sick sheet" value={sick.photos} onChange={(ph) => setSick({ ...sick, photos: ph })} required /> : null}
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.text }}>Paid for this day?</Text>
          <Chips testIDPrefix="de-paid" value={sick.paid ? 'yes' : 'no'} onChange={(v) => setSick({ ...sick, paid: v === 'yes' })} options={[{ value: 'yes', label: 'Paid (from sick leave)' }, { value: 'no', label: 'Not paid' }]} />
          <ReasonField testID="de-sick-why" label="Note (optional)" value={f.reason} onChangeText={(v) => setF({ ...f, reason: v })} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Btn title="Back" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => (start === 'sick' ? onClose() : setSick(null))} />
            <Btn testID="de-sick-save" title="Save – sick" size="md" variant="success" style={{ flex: 2 }} onPress={() => mark('sick', { sheet: sick.sheet, paid: sick.paid, photos: (sick.photos || []).map((x) => (typeof x === 'string' ? x : x.uri)) })} />
          </View>
        </>
      )}
      {noteOpen ? (
        <View testID="de-note-box" style={{ gap: 6, backgroundColor: '#FAF8F5', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#E3DDD3' }}>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.text }}>💬 Internal note (managers and payroll only – not on the payslip)</Text>
          {note0 ? <Text style={{ fontSize: 12, color: C.sub }}>{`Last written by ${note0.by_name} on ${String(note0.at).slice(0, 16)}`}</Text> : null}
          <ReasonField testID="de-note" label="Note for this day" value={note} onChangeText={setNote} />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {note0 ? <Btn testID="de-note-del" title="Remove" size="sm" variant="ghost" style={{ flex: 1 }} onPress={() => run(() => require('../absence.js').saveDayNote(user, { userUid: person.uid, date, note: '' }), 'Note removed')} /> : null}
            <Btn testID="de-note-save" title="Save the note" size="sm" variant="success" style={{ flex: 2 }} onPress={() => run(() => require('../absence.js').saveDayNote(user, { userUid: person.uid, date, note }), 'Note saved')} />
          </View>
        </View>
      ) : <Btn testID="de-note-open" title="💬 Add an internal note" size="sm" variant="ghost" onPress={() => setNoteOpen(true)} />}
      <Btn title="Close" size="sm" variant="ghost" onPress={onClose} />
    </Card></View>
  );
}

export default function TimesheetWeekScreen({ params }) {
  const { nav, user } = useApp();
  const [, bump] = useState(0);
  const [editing, setEditing] = useState(null); // { uid, date }
  const ui = useUI();
  const seesPay = !!user && can(user, 'payroll_run');
  const { isPhone } = useLayout();
  const [date, setDate] = useState(params.date || dateStr());
  const [shop, setShop] = useRemembered('shop', params.shop || 'ALL');
  const shops = db().all('SELECT code, name FROM shops WHERE active = 1 ORDER BY sort');
  const ts = weekTimesheet(date, { shopCode: shop === 'ALL' ? null : shop });
  const notes = (() => { try { return require('../absence.js').dayNotesBetween(ts.weekStart, ts.weekEnd); } catch (e) { return {}; } })(); // Release 21
  const problems = ts.rows.reduce((a, r) => a + r.problems, 0);
  const checked = ts.rows.filter((r) => r.checked).length;
  const total = ts.rows.reduce((a, r) => a + r.totalMinutes, 0);
  return (
    <Screen title="Timesheets" subtitle={`Week ${ts.weekStart} to ${ts.weekEnd} (Sat-Fri)`}
      footer={<Btn title="Timesheet reports" icon="📄" size="md" variant="info" onPress={() => nav.push('ReportsHub', { group: 'Timesheets' })} />}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn testID="week-prev" title="‹ Previous" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, -7))} />
        <Btn testID="week-this" title="This week" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(dateStr())} />
        <Btn testID="week-next" title="Next ›" size="md" variant="secondary" style={{ flex: 1 }} onPress={() => setDate(addDays(ts.weekStart, 7))} />

      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        <Btn testID="week-roster" title="Roster planner" icon="📅" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('RosterPlanner', {})} />
        <Btn testID="week-pva" title="Planned vs worked" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('PlanVsActual', { date: ts.weekStart })} />
        <Btn testID="week-won" title="Who is on now" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('WhoIsOn', {})} />
        <Btn testID="week-usual" title="Usual weeks" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('Roster')} />
      </View>
      <Hint>Tap a day to fix it right here (start, break, finish, or day off / sick / leave). Tap the name for every punch. Changes need a reason (optional for the owner and admin) and are kept in the history. A week that has been paid cannot be changed.</Hint>
      <Chips value={shop} onChange={setShop} testIDPrefix="ts-shop"
        options={[{ value: 'ALL', label: 'All shops' }].concat(shops.map((s) => ({ value: s.code, label: s.name.replace(/^Shop (\d) - /, 'Shop $1 ') })))} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {[['Hours', hm(total), C.text], ['To fix', String(problems), problems ? C.danger : C.success], ['Weeks checked', `${checked} of ${ts.rows.length}`, checked === ts.rows.length && ts.rows.length ? C.success : C.warn]].map(([l, v, col]) => (
          <View key={l} style={{ flexGrow: 1, minWidth: 120, backgroundColor: C.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: C.border, borderLeftWidth: 5, borderLeftColor: C.brandRed }}>
            <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{l.toUpperCase()}</Text>
            <Text style={{ fontSize: 24, fontWeight: '900', color: col }}>{v}</Text>
          </View>
        ))}
      </View>
      {problems ? <Banner tone="warn" title={`${problems} thing(s) to fix`} message="Tap a person with a red number to fix missing Clock IN/OUT and other problems." /> : null}
      {!ts.rows.length ? <Banner tone="info" message="No staff in this shop yet." /> : null}
      {ts.rows.map((r) => (
        <View key={r.user.uid}>
          <Card tone={r.problems ? 'danger' : r.checked ? 'success' : undefined}>
            <Pressable testID={`ts-row-${r.user.employee_no || r.user.uid}`} accessibilityLabel={`${r.user.name}: every punch`} onPress={() => nav.push('TimesheetGrid', { userUid: r.user.uid, date: ts.weekStart })} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{r.user.name}{r.user.active ? '' : ' (left)'}</Text>
                <Text style={{ fontSize: 14, color: C.sub }}>{r.user.employee_no || ''} {r.user.shop_code || ''}</Text>
              </View>
              {r.problems ? <Badge text={`${r.problems} to fix`} color={C.danger} /> : null}
              {r.checked ? <Badge text="✓ Checked" color={C.success} /> : null}
              <Text style={{ fontSize: 22, fontWeight: '900', color: C.text, minWidth: 70, textAlign: 'right' }}>{hm(r.totalMinutes)}</Text>
            </Pressable>
            <View style={{ flexDirection: 'row', marginTop: 8, gap: 4 }}>
              {ts.days.map((d) => {
                const list = r.days[d];
                const mins = list.reduce((a, s) => a + s.workedMinutes, 0);
                const bad = list.some((s) => s.problems);
                return (
                  <Pressable key={d} testID={`ts-day-${r.user.employee_no || r.user.uid}-${d}`} accessibilityLabel={`Fix ${dayName(d)}`} onPress={() => setEditing({ uid: r.user.uid, date: d })}
                    style={{ flex: 1, alignItems: 'center', borderRadius: 8, paddingVertical: 6, minHeight: 44, backgroundColor: editing && editing.uid === r.user.uid && editing.date === d ? C.infoSoft : bad ? C.dangerSoft : mins ? '#F2EEEA' : 'transparent' }}>
                    <Text style={{ fontSize: 12, color: C.sub, fontWeight: '700' }}>{isPhone ? dayName(d).slice(0, 2) : dayName(d)}</Text>
                    <Text style={{ fontSize: isPhone ? 12 : 15, fontWeight: '800', color: bad ? C.danger : C.text }}>{bad && !mins ? '!' : mins ? hm(mins) : '–'}</Text>
                    {notes[`${r.user.uid}|${d}`] ? <Text testID={`ts-note-${r.user.employee_no || r.user.uid}-${d}`} style={{ fontSize: 11 }}>💬</Text> : null}
                  </Pressable>
                );
              })}
            </View>
          </Card>
        {editing && editing.uid === r.user.uid ? <DayEditor user={user} person={r.user} date={editing.date} onClose={() => setEditing(null)} onDone={() => { setEditing(null); bump((n) => n + 1); }} /> : null}
        {editing && editing.uid === r.user.uid ? <Btn testID={`ts-rostered-${r.user.employee_no || r.user.uid}`} title="Whole week as rostered (empty days only)" icon="📅" size="md" variant="secondary"
          onPress={() => { try { const n = weekAsRostered(user, { userUid: r.user.uid, date: ts.weekStart, reason: 'Filled as rostered' }); ui.toast(`${n} day(s) filled`); setEditing(null); bump((x) => x + 1); } catch (e) { ui.error(e); } }} /> : null}
        {seesPay ? <View style={{ marginTop: -6, paddingHorizontal: 12 }}><FixedPay user={user} person={r.user} weekStart={ts.weekStart} onDone={() => bump((n) => n + 1)} /></View> : null}
        </View>
      ))}
    </Screen>
  );
}
