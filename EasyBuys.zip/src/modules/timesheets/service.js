// Timesheets: punches from the Time Clock become shifts, days and Saturday-Friday weeks.
// Problems are flagged; the manager fixes them (with a reason) and ticks the week as checked.
import { db } from '../../db/connection.js';
import {
  AppError, stamp, parseStamp, addDays, weekStart as weekStartOf, deviceId, audit, clock, dateStr,
} from '../../services/core.js';
import { clockRules } from '../timeclock/rules.js';
import { addManualPunch, voidPunch, changePunchTime, listPunches } from '../timeclock/service.js';

export const FLAG_LABEL = {
  missing_out: 'No Clock OUT',
  missing_in: 'No Clock IN',
  open: 'Still at work',
  long_shift: 'Very long shift',
  no_break: 'No break taken',
  break_not_ended: 'Break not ended',
  manual: 'Changed by manager',
  face: 'Face did not match',
  stray_break: 'Break outside a shift',
};
export const PROBLEM_FLAGS = ['missing_out', 'missing_in', 'long_shift', 'no_break', 'break_not_ended', 'face', 'stray_break'];

function roundStamp(s, mins) {
  if (!mins || !s) return s;
  const d = parseStamp(s);
  const step = mins * 60000;
  return stamp(new Date(Math.round(d.getTime() / step) * step));
}
const minutes = (a, b) => Math.max(0, Math.round((parseStamp(b) - parseStamp(a)) / 60000));

/**
 * Turn one person's punches (any order, voided ignored) into shifts.
 * Pure: no database. `now` decides whether an unfinished shift is still running.
 */
export function buildShifts(punchList, rules = clockRules(), now = clock.now()) {
  const list = punchList.filter((p) => !p.voided).slice().sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : 0));
  const shifts = [];
  let open = null;
  const finish = (s) => {
    const r = rules.roundMinutes;
    s.in_at = s.in ? roundStamp(s.in.at, r) : null;
    s.out_at = s.out ? roundStamp(s.out.at, r) : null;
    s.date = (s.in_at || s.out_at).slice(0, 10);
    s.breakMinutes = s.breaks.reduce((a, b) => a + minutes(b.start, b.end), 0);
    s.grossMinutes = s.in_at && s.out_at ? minutes(s.in_at, s.out_at) : 0;
    if (s.status === 'complete' && rules.breakMode === 'auto' && !s.breaks.length && s.grossMinutes > rules.autoBreakAfterHours * 60) {
      s.breakMinutes = rules.autoBreakMinutes;
      s.autoBreak = true;
    }
    s.workedMinutes = s.status === 'complete' ? Math.max(0, s.grossMinutes - s.breakMinutes) : 0;
    const f = s.flags;
    if (s.status === 'missing_out') f.push('missing_out');
    if (s.status === 'missing_in') f.push('missing_in');
    if (s.status === 'open') f.push('open');
    if (s.grossMinutes > rules.longShiftHours * 60) f.push('long_shift');
    if (s.status === 'complete' && rules.breakMode === 'buttons' && !s.breaks.length && s.grossMinutes > rules.noBreakAfterHours * 60) f.push('no_break');
    if (s.punches.some((p) => p.method === 'manual')) f.push('manual');
    if (s.punches.some((p) => p.face_result === 'no_match' || p.face_result === 'no_face')) f.push('face');
    s.problems = f.filter((x) => PROBLEM_FLAGS.includes(x)).length;
    shifts.push(s);
  };
  const start = (p) => ({ in: p, out: null, breaks: [], breakOpen: null, punches: [p], flags: [], status: 'complete' });
  for (const p of list) {
    if (p.type === 'IN') {
      if (open) { open.status = 'missing_out'; finish(open); }
      open = start(p);
    } else if (p.type === 'BREAK_START') {
      if (open && !open.breakOpen) { open.breakOpen = p; open.punches.push(p); } else if (!open) {
        const s = { in: null, out: null, breaks: [], punches: [p], flags: ['stray_break'], status: 'missing_in' };
        s.in = null; s.out = p; finish(s);
      } else open.punches.push(p);
    } else if (p.type === 'BREAK_END') {
      if (open && open.breakOpen) { open.breaks.push({ start: open.breakOpen.at, end: p.at }); open.breakOpen = null; open.punches.push(p); } else if (open) {
        open.punches.push(p); open.flags.push('stray_break');
      } else {
        const s = { in: null, out: p, breaks: [], punches: [p], flags: ['stray_break'], status: 'missing_in' };
        finish(s);
      }
    } else if (p.type === 'OUT') {
      if (open && minutes(open.in.at, p.at) <= rules.maxShiftHours * 60) {
        if (open.breakOpen) { open.breaks.push({ start: open.breakOpen.at, end: p.at }); open.flags.push('break_not_ended'); open.breakOpen = null; }
        open.out = p; open.punches.push(p); open.status = 'complete'; finish(open); open = null;
      } else {
        if (open) { open.status = 'missing_out'; finish(open); open = null; }
        finish({ in: null, out: p, breaks: [], punches: [p], flags: [], status: 'missing_in' });
      }
    }
  }
  if (open) {
    open.status = (now - parseStamp(open.in.at)) / 3600000 > rules.maxShiftHours ? 'missing_out' : 'open';
    finish(open);
  }
  return shifts;
}

export function weekDays(weekStart) {
  return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
}

export function checkFor(userUid, weekStart) {
  return db().get('SELECT * FROM timesheet_checks WHERE uid = ?', [`${userUid}|${weekStart}`]);
}
export function isChecked(userUid, weekStart) {
  const c = checkFor(userUid, weekStart);
  return !!(c && c.status === 'checked');
}

function staffList(shopCode) {
  return db().all(
    `SELECT id, uid, name, role, employee_no, shop_code, active, uses_clock FROM users
     WHERE uses_clock = 1 ${shopCode ? 'AND shop_code = ?' : ''} ORDER BY name`, shopCode ? [shopCode] : []
  );
}

/** Shifts for everyone (or one shop / one person) between two dates, by the shift's start date. */
export function shiftsBetween(from, to, { shopCode, userUid } = {}) {
  const rules = clockRules();
  const punches = listPunches({ from: addDays(from, -1), to: addDays(to, 1), userUid });
  const people = userUid ? db().all('SELECT * FROM users WHERE uid = ?', [userUid]) : staffList(shopCode);
  const byUser = {};
  punches.forEach((p) => { (byUser[p.user_uid] = byUser[p.user_uid] || []).push(p); });
  return people.map((u) => ({
    user: u,
    shifts: buildShifts(byUser[u.uid] || [], rules).filter((s) => s.date >= from && s.date <= to),
  }));
}

/** The weekly timesheet (Saturday to Friday). */
export function weekTimesheet(anyDate, { shopCode } = {}) {
  const start = weekStartOf(anyDate || dateStr());
  const end = addDays(start, 6);
  const days = weekDays(start);
  const rows = shiftsBetween(start, end, { shopCode }).map(({ user, shifts }) => {
    const byDay = {};
    days.forEach((d) => { byDay[d] = []; });
    shifts.forEach((s) => byDay[s.date].push(s));
    const total = shifts.reduce((a, s) => a + s.workedMinutes, 0);
    const problems = shifts.reduce((a, s) => a + s.problems, 0);
    const check = checkFor(user.uid, start);
    return { user, days: byDay, shifts, totalMinutes: total, problems, checked: !!(check && check.status === 'checked'), check };
  }).filter((r) => r.shifts.length || r.user.active);
  return { weekStart: start, weekEnd: end, days, rows };
}

/** One person's week with every punch (cancelled ones too, for the history). */
export function personWeek(userUid, anyDate) {
  const start = weekStartOf(anyDate || dateStr());
  const end = addDays(start, 6);
  const [row] = shiftsBetween(start, end, { userUid });
  const all = listPunches({ userUid, from: start, to: end, includeVoided: true });
  return { weekStart: start, weekEnd: end, user: row ? row.user : null, shifts: row ? row.shifts : [], punches: all,
    totalMinutes: row ? row.shifts.reduce((a, s) => a + s.workedMinutes, 0) : 0, check: checkFor(userUid, start) };
}

function guardWeek(userUid, at) {
  const ws = weekStartOf(String(at).slice(0, 10));
  if (isChecked(userUid, ws)) throw new AppError('This week is already ticked as checked. Untick it first (with a reason) to make changes.');
}

// ---------- manager fixes (all keep the history) ----------
export function fixAddPunch(byUser, { userUid, type, at, reason }) {
  guardWeek(userUid, at);
  return addManualPunch(byUser, { userUid, type, at, reason });
}
export function fixCancelPunch(byUser, punchUid, reason) {
  const p = db().get('SELECT * FROM punches WHERE uid = ?', [punchUid]);
  if (!p) throw new AppError('Punch not found.');
  guardWeek(p.user_uid, p.at);
  return voidPunch(byUser, punchUid, reason);
}
export function fixChangeTime(byUser, punchUid, newAt, reason) {
  const p = db().get('SELECT * FROM punches WHERE uid = ?', [punchUid]);
  if (!p) throw new AppError('Punch not found.');
  guardWeek(p.user_uid, p.at);
  guardWeek(p.user_uid, newAt);
  return changePunchTime(byUser, punchUid, newAt, reason);
}

// ---------- week checked ----------
export function checkWeek(byUser, userUid, anyDate, note = '') {
  const start = weekStartOf(anyDate);
  const [row] = shiftsBetween(start, addDays(start, 6), { userUid });
  const open = row ? row.shifts.filter((s) => s.status === 'missing_out' || s.status === 'missing_in') : [];
  if (open.length) throw new AppError(`Fix the ${open.length} missing Clock IN/OUT first.`);
  const uid = `${userUid}|${start}`;
  const now = stamp();
  db().run(
    `INSERT INTO timesheet_checks (uid, user_uid, week_start, status, checked_by_uid, checked_by_name, checked_at, note, updated_at, updated_device, sync_status)
     VALUES (?, ?, ?, 'checked', ?, ?, ?, ?, ?, ?, 'pending')
     ON CONFLICT(uid) DO UPDATE SET status = 'checked', checked_by_uid = excluded.checked_by_uid, checked_by_name = excluded.checked_by_name,
       checked_at = excluded.checked_at, note = excluded.note, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [uid, userUid, start, byUser ? byUser.uid : null, byUser ? byUser.name : null, now, String(note || '').trim() || null, now, deviceId()]
  );
  audit({ user: byUser, action: 'Ticked week as checked', table: 'timesheet_checks', recordUid: uid, after: { week: start }, reason: note });
}
export function uncheckWeek(byUser, userUid, anyDate, reason) {
  if (!String(reason || '').trim()) throw new AppError('Please give a reason for unticking.');
  const start = weekStartOf(anyDate);
  const uid = `${userUid}|${start}`;
  const now = stamp();
  db().run(`UPDATE timesheet_checks SET status = 'unchecked', note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [String(reason).trim(), now, deviceId(), uid]);
  audit({ user: byUser, action: 'Unticked checked week', table: 'timesheet_checks', recordUid: uid, reason });
}

export function hm(mins) {
  const m = Math.max(0, Math.round(mins || 0));
  return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`;
}
