// Warnings for Home: a number given twice, credit accounts without a signed agreement, agreements ending – and
// (1.0.0 build 24, goods in) Aronium purchases with no supplier invoice photo in the app, and invoices in the app that
// were never entered in Aronium. Only while Wholesale is switched on (Easy Buys keeps its Aronium purchases screen).
import { canView, tradeAlertList } from './service.js';
import { can } from '../../services/access.js';
import { dateStr, addDays, money } from '../../services/core.js';
import { purchasesCheck } from '../aronium/purchasesCheck.js';
import { deliveryAlerts } from './deliveries.js';

const s = (n) => (n === 1 ? '' : 's');
export function goodsInAlerts(user) {
  if (!(can(user, 'invoices_check') || can(user, 'ap_setup') || can(user, 'inventory_manage'))) return [];
  let r;
  try { r = purchasesCheck({ from: addDays(dateStr(), -45) }); } catch (e) { return []; }
  const out = [];
  const yesterday = addDays(dateStr(), -1);
  const missing = r.missing.filter((p) => p.date <= yesterday); // the day's own deliveries get a day to be photographed
  if (missing.length) {
    out.push({ id: 'trade-goodsin-nophoto', level: 'warning', text: `${missing.length} Aronium purchase${s(missing.length)} with no supplier invoice photo`,
      sub: missing.slice(0, 3).map((p) => `${p.supplier || 'Supplier ?'} ${p.reference || p.number} ${money(p.total)}`).join(' · '), nav: { screen: 'ArPurchases', params: {} } });
  }
  if (r.notInAronium.length) {
    out.push({ id: 'trade-goodsin-notaronium', level: 'warning', text: `${r.notInAronium.length} supplier invoice${s(r.notInAronium.length)} not entered in Aronium`,
      sub: r.notInAronium.slice(0, 3).map((i) => `${i.supplier_name} ${i.invoice_no || ''} ${money(i.total)}`).join(' · '), nav: { screen: 'ArPurchases', params: {} } });
  }
  if (r.differ.length) {
    out.push({ id: 'trade-goodsin-differ', level: 'info', text: `${r.differ.length} supplier invoice${s(r.differ.length)} with a different total in Aronium`, nav: { screen: 'ArPurchases', params: {} } });
  }
  return out;
}

export function alerts(user) {
  const out = canView(user) ? tradeAlertList().map((a) => ({ ...a, area: 'trade' })) : [];
  return out.concat(goodsInAlerts(user).map((a) => ({ ...a, area: 'trade' })), deliveryAlerts(user).map((a) => ({ ...a, area: 'trade' })));
}
