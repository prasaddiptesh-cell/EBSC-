// Warnings for Home: a number given twice, credit accounts without a signed agreement, agreements ending.
import { canView, tradeAlertList } from './service.js';

export function alerts(user) {
  if (!canView(user)) return [];
  return tradeAlertList().map((a) => ({ ...a, area: 'trade' }));
}
