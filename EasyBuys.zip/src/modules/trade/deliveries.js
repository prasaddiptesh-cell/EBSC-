// Deliveries (1.0.0 build 25, wholesale). The invoice is made in Aronium as usual; the Link sends it with its lines.
//   1. Dispatch (office): picks Aronium invoices of account customers, the driver and the truck, adds the note
//      ("Collect cheque", "Credit 30 days"…) → the delivery is on the driver's phone.
//   2. Driver: checks every line onto the truck (short / wrong → the office is told before the truck leaves).
//   3. Driver: leaves → on the road.  4. At the customer: name and signature of the receiver, the money taken (a cheque
//      needs its number and a photo), printed copy handed over → delivered; the invoice copy is emailed to the
//      customer's address on the account.
//   5. The money shows "Collected – not yet in Aronium" until the Aronium invoice shows it paid (then "Matched").
// Aronium is never written to. Every step keeps who and when.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, getShared, setShared, dateStr, addDays } from '../../services/core.js';
import { can } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';
import { addPhotos, listPhotos, enqueue } from '../../services/stock.js';
import { aroniumCreditTrail } from '../aronium/link.js';
import { searchAccounts, getAccount, displayName } from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const J = (s, d) => { try { const v = JSON.parse(s); return v === null || v === undefined ? d : v; } catch (e) { return d; } };
const has = () => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'dl_deliveries'");
const norm = (s) => txt(s).toLowerCase().replace(/[^a-z0-9]/g, '');
const tell = (event, text) => { try { require('../verify/service.js').notify(event, text); } catch (e) { /* only a message */ } };

export const STATUS = { waiting: 'Waiting to load', checked: 'Loaded and checked', on_road: 'On the road', delivered: 'Delivered', problem: 'Problem', cancelled: 'Cancelled' };
export const canDispatch = (u) => can(u, 'trade_dispatch');
export const canDrive = (u) => can(u, 'trade_drive') || can(u, 'trade_dispatch');

// ---------------------------------------------------------------- settings (owner / admin)
export const DEFAULT_DL = {
  notes: ['Collect cheque', 'Cash on delivery', 'Credit – on account', 'Collect empty crates', 'Call before arriving'],
  methods: ['Cash', 'Cheque', 'M-PAiSA', 'Bank transfer', 'On account (no money now)'],
  emailInvoice: true,
  days: 3, // how far back Aronium invoices are offered for dispatch
};
export function deliverySettings() {
  const s = getShared('delivery_settings', null) || {};
  const list = (v, d) => (Array.isArray(v) ? v.map(txt).filter(Boolean).slice(0, 20) : d);
  return { notes: list(s.notes, DEFAULT_DL.notes), methods: list(s.methods, DEFAULT_DL.methods), emailInvoice: s.emailInvoice !== false, days: Math.max(1, Math.min(30, Number(s.days) || DEFAULT_DL.days)) };
}
export function saveDeliverySettings(user, s) {
  requirePerm(user, 'settings');
  return asService(() => {
    const cur = deliverySettings();
    const out = { ...cur, ...s };
    const clean = { notes: (out.notes || []).map(txt).filter(Boolean).slice(0, 20), methods: (out.methods || []).map(txt).filter(Boolean).slice(0, 20), emailInvoice: out.emailInvoice !== false, days: Math.max(1, Math.min(30, Number(out.days) || 3)) };
    need(clean.methods.some((m) => /cheque/i.test(m)) || clean.methods.length, 'Keep at least one way to pay.');
    setShared('delivery_settings', clean);
    audit({ user, action: 'Delivery settings changed', table: 'shared_settings', recordUid: 'delivery_settings', after: clean });
    return clean;
  });
}

// ---------------------------------------------------------------- what can be sent
// The account behind an Aronium customer: by the code in Aronium (the account number), else by the name.
function accountFor(code, name) {
  if (code) {
    const a = db().get("SELECT uid FROM trade_accounts WHERE kind = 'customer' AND (lower(aronium_code) = lower(?) OR lower(number) = lower(?))", [code, code]);
    if (a) return getAccount(a.uid);
  }
  const n = norm(name);
  if (n.length < 3) return null;
  const hit = searchAccounts({ kind: 'customer', status: 'all' }).find((a) => norm(a.name) === n || norm(a.trading_name) === n);
  return hit || null;
}
const docKey = (d) => `${d.source}|${d.id}`;
// Aronium invoices of account customers from the last few days that are not a delivery yet.
export function toDispatch({ days } = {}) {
  if (!has()) return [];
  const back = days || deliverySettings().days;
  const from = addDays(dateStr(), -back);
  const made = new Set(db().all("SELECT doc_key FROM dl_deliveries WHERE status <> 'cancelled'").map((r) => r.doc_key));
  const out = [];
  for (const d of aroniumCreditTrail()) {
    if (d.refund || d.date < from || made.has(docKey(d))) continue;
    const acct = accountFor(d.customer_code, d.customer);
    if (!acct) continue;
    out.push({ key: docKey(d), number: d.number, date: d.date, customer: d.customer, code: d.customer_code || '', total: d.total, owing: d.owing, items: d.items, shop: d.shop, account: acct });
  }
  return out.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
}

// ---------------------------------------------------------------- reading
function decorate(r) {
  if (!r) return null;
  const lines = J(r.lines, []);
  const check = J(r.check_lines, null);
  return { ...r, lines, check, photos: listPhotos('dlcheque', r.uid), payState: payState(r), statusText: STATUS[r.status] || r.status };
}
export function getDelivery(uid) { return has() ? decorate(db().get('SELECT * FROM dl_deliveries WHERE uid = ?', [uid])) : null; }
export function listDeliveries({ status, driverUid, from, to, q } = {}) {
  if (!has()) return [];
  const where = ['1 = 1']; const args = [];
  if (status === 'open') where.push("status IN ('waiting','checked','on_road','problem')");
  else if (status) { where.push('status = ?'); args.push(status); }
  if (driverUid) { where.push('driver_uid = ?'); args.push(driverUid); }
  if (from) { where.push('substr(made_at, 1, 10) >= ?'); args.push(from); }
  if (to) { where.push('substr(made_at, 1, 10) <= ?'); args.push(to); }
  let rows = db().all(`SELECT * FROM dl_deliveries WHERE ${where.join(' AND ')} ORDER BY made_at DESC LIMIT 500`, args);
  if (q) { const w = norm(q); rows = rows.filter((r) => norm(`${r.customer_name} ${r.invoice_no} ${r.customer_code}`).includes(w)); }
  return rows.map(decorate);
}
// The driver's own list: not finished yet, plus what was finished today.
export function myDeliveries(user) {
  if (!has() || !user) return [];
  const today = dateStr();
  return db().all("SELECT * FROM dl_deliveries WHERE driver_uid = ? AND (status IN ('waiting','checked','on_road','problem') OR substr(COALESCE(delivered_at, ''), 1, 10) = ?) ORDER BY made_at", [user.uid, today]).map(decorate);
}
// Money taken on the road against what Aronium shows paid for that invoice.
export function payState(r) {
  const amt = r2(r.pay_amount);
  if (r.status !== 'delivered' || !(amt > 0)) return amt > 0 ? 'collected' : 'none';
  let d = null;
  try { const [src, id] = String(r.doc_key).split('|'); d = aroniumCreditTrail().find((x) => x.source === src && String(x.id) === id) || null; } catch (e) { d = null; }
  if (!d) return 'collected';
  const after = (d.payments || []).filter((p) => p.money !== false && (!r.delivered_at || p.date >= String(r.delivered_at).slice(0, 10)));
  const paidSince = r2(after.reduce((a, p) => a + Math.abs(Number(p.amount) || 0), 0));
  return (d.owing <= 0.005 || paidSince + 0.005 >= amt) ? 'matched' : 'collected';
}

// ---------------------------------------------------------------- 1. dispatch
export function createDelivery(user, { key, driverUid, vehicleUid, note }) {
  requirePerm(user, 'trade_dispatch');
  return asService(() => {
    need(has(), 'Deliveries are not set up on this device yet.');
    const d = toDispatch({ days: 30 }).find((x) => x.key === key);
    need(d, 'That Aronium invoice is not waiting to be sent (already a delivery, or not for an account customer).');
    const driver = driverUid ? db().get('SELECT uid, name FROM users WHERE uid = ? AND active = 1', [driverUid]) : null;
    need(driver, 'Choose the driver.');
    let vehicle = null;
    if (vehicleUid) { try { vehicle = db().get('SELECT uid, name FROM ve_items WHERE uid = ?', [vehicleUid]); } catch (e) { vehicle = null; } }
    const now = stamp();
    const uid = uuid('DL');
    const lines = (d.items || []).map((i) => ({ name: txt(i[0]) || '(item)', qty: Number(i[1]) || 0, amount: i[2] === null || i[2] === undefined ? null : r2(i[2]) }));
    db().run(`INSERT INTO dl_deliveries (uid, doc_key, invoice_no, invoice_date, customer_name, customer_code, account_uid, shop_code, total, owing, lines, note, driver_uid, driver_name, vehicle_uid, vehicle_name,
      status, made_by, made_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'waiting',?,?,?,?)`,
    [uid, d.key, d.number || null, d.date || null, d.account ? d.account.display : d.customer, d.code || (d.account && d.account.number) || null, d.account ? d.account.uid : null, d.shop || null,
      r2(d.total), r2(d.owing), JSON.stringify(lines), txt(note) || null, driver.uid, driver.name, vehicle ? vehicle.uid : null, vehicle ? vehicle.name : null, user.name, now, now, deviceId()]);
    audit({ user, action: `Delivery made: invoice ${d.number} for ${d.customer} – driver ${driver.name}${note ? ` – note: ${txt(note)}` : ''}`, table: 'dl_deliveries', recordUid: uid });
    return uid;
  });
}
export function cancelDelivery(user, uid, reason) {
  requirePerm(user, 'trade_dispatch');
  return asService(() => {
    const r = getDelivery(uid);
    need(r, 'Delivery not found.');
    need(r.status !== 'delivered', 'A delivered order cannot be cancelled.');
    need(txt(reason), 'Give a reason.');
    db().run("UPDATE dl_deliveries SET status = 'cancelled', problem = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(reason), stamp(), deviceId(), uid]);
    audit({ user, action: `Delivery cancelled: invoice ${r.invoice_no} for ${r.customer_name} – ${txt(reason)}`, table: 'dl_deliveries', recordUid: uid });
  });
}
const mine = (user, r) => r.driver_uid === user.uid || can(user, 'trade_dispatch');

// ---------------------------------------------------------------- 2. the check on loading
// got: one number per line (what is on the truck). Anything less (or more) is kept and the office is told.
export function checkLoad(user, uid, got) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    const r = getDelivery(uid);
    need(r, 'Delivery not found.');
    need(mine(user, r), 'This delivery is for another driver.');
    need(['waiting', 'checked'].includes(r.status), 'This delivery has already left.');
    need(Array.isArray(got) && got.length === r.lines.length, 'Check every line.');
    const check = r.lines.map((l, i) => { const g = Number(got[i]); need(Number.isFinite(g) && g >= 0, `Line ${i + 1}: enter how many are on the truck.`); return { got: g, diff: Math.round((g - l.qty) * 1000) / 1000 }; });
    const off = check.map((c, i) => ({ ...c, name: r.lines[i].name, want: r.lines[i].qty })).filter((c) => Math.abs(c.diff) > 0.0005);
    const now = stamp();
    db().run("UPDATE dl_deliveries SET status = 'checked', check_lines = ?, short = ?, checked_at = ?, checked_by = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      [JSON.stringify(check), off.length ? 1 : 0, now, user.name, now, deviceId(), uid]);
    audit({ user, action: `Load checked: invoice ${r.invoice_no} for ${r.customer_name}${off.length ? ` – NOT AS INVOICED: ${off.map((o) => `${o.name} ${o.got} of ${o.want}`).join(', ')}` : ' – all there'}`, table: 'dl_deliveries', recordUid: uid });
    if (off.length) tell('delivery', `Load for ${r.customer_name} (invoice ${r.invoice_no}) is not as invoiced: ${off.map((o) => `${o.name} ${o.got} of ${o.want}`).join(', ')}. Checked by ${user.name}.`);
    return { off };
  });
}

// ---------------------------------------------------------------- 3. leaving
export function leaveNow(user, uids, { lat, lng } = {}) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    const list = (Array.isArray(uids) ? uids : [uids]).map(getDelivery).filter(Boolean);
    need(list.length, 'Choose the deliveries on the truck.');
    for (const r of list) {
      need(mine(user, r), 'One of these deliveries is for another driver.');
      need(r.status === 'checked', `${r.customer_name}: check the load first.`);
    }
    const now = stamp();
    for (const r of list) db().run("UPDATE dl_deliveries SET status = 'on_road', left_at = ?, left_lat = ?, left_lng = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, lat ?? null, lng ?? null, now, deviceId(), r.uid]);
    audit({ user, action: `Left with ${list.length} deliver${list.length === 1 ? 'y' : 'ies'}: ${list.map((r) => r.customer_name).join(', ')}`, table: 'dl_deliveries', recordUid: list[0].uid });
    return list.length;
  });
}
export function arrived(user, uid, at = stamp()) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    const r = getDelivery(uid);
    need(r && mine(user, r), 'Delivery not found.');
    if (r.arrived_at || r.status !== 'on_road') return false;
    db().run("UPDATE dl_deliveries SET arrived_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [at, stamp(), deviceId(), uid]);
    return true;
  });
}

// ---------------------------------------------------------------- 4. at the customer
export function deliver(user, uid, f) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    const r = getDelivery(uid);
    need(r, 'Delivery not found.');
    need(mine(user, r), 'This delivery is for another driver.');
    need(['on_road', 'checked'].includes(r.status), r.status === 'delivered' ? 'Already delivered.' : 'Check the load before delivering.');
    need(txt(f.receiver), 'Enter the name of the person receiving the goods.');
    need(/^data:image\/png;base64,/.test(String(f.signature || '')) && String(f.signature).length < 200000, 'The receiver must sign.');
    const methods = deliverySettings().methods;
    const method = txt(f.method);
    need(methods.includes(method), 'Choose how the customer paid (or "On account").');
    const onAccount = /on account/i.test(method);
    const amount = onAccount ? 0 : r2(f.amount);
    need(onAccount || amount > 0, 'Enter the amount received.');
    need(amount <= r2(r.total) * 3 + 1, 'That amount is far more than the invoice – check it.');
    const isCheque = /cheque/i.test(method);
    const photos = Array.isArray(f.photos) ? f.photos.filter(Boolean) : [];
    if (isCheque) {
      need(txt(f.chequeNo), 'Enter the cheque number.');
      need(photos.length || r.photos.length, 'Take a photo of the cheque.');
    }
    const now = stamp();
    db().run(`UPDATE dl_deliveries SET status = 'delivered', delivered_at = ?, arrived_at = COALESCE(arrived_at, ?), at_lat = ?, at_lng = ?, receiver_name = ?, signature = ?, pay_method = ?, pay_amount = ?, cheque_no = ?, cheque_bank = ?,
      printed = ?, problem = NULL, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [now, now, f.lat ?? null, f.lng ?? null, txt(f.receiver), f.signature, method, amount, isCheque ? txt(f.chequeNo) : null, isCheque ? (txt(f.chequeBank) || null) : null, f.printed ? 1 : 0, now, deviceId(), uid]);
    if (photos.length) addPhotos('dlcheque', uid, photos);
    audit({ user, action: `Delivered: invoice ${r.invoice_no} to ${r.customer_name}, received by ${txt(f.receiver)}${amount ? ` – ${method} $${amount.toFixed(2)}${isCheque ? ` (cheque ${txt(f.chequeNo)})` : ''}` : ` – ${method}`}`, table: 'dl_deliveries', recordUid: uid });
    tell(isCheque ? 'cheque_received' : 'delivery', `Delivered to ${r.customer_name} (invoice ${r.invoice_no}) by ${user.name}, signed by ${txt(f.receiver)}${amount ? ` – ${method} $${amount.toFixed(2)}` : ''}.`);
    // the invoice copy to the customer (the cloud only sends to an address saved on a customer account)
    const acct = r.account_uid ? getAccount(r.account_uid) : null;
    if (deliverySettings().emailInvoice && acct && acct.email) enqueue('delivery_email', { uid, to: acct.email });
    enqueue('delivery_drive', { uid });
    return uid;
  });
}
export function reportProblem(user, uid, reason) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    const r = getDelivery(uid);
    need(r && mine(user, r), 'Delivery not found.');
    need(r.status !== 'delivered', 'Already delivered.');
    need(txt(reason), 'Say what the problem is (shop closed, refused, wrong goods…).');
    db().run("UPDATE dl_deliveries SET status = 'problem', problem = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(reason), stamp(), deviceId(), uid]);
    audit({ user, action: `Delivery problem: invoice ${r.invoice_no} for ${r.customer_name} – ${txt(reason)}`, table: 'dl_deliveries', recordUid: uid });
    tell('delivery', `Delivery problem – ${r.customer_name} (invoice ${r.invoice_no}): ${txt(reason)}. Driver ${user.name}.`);
  });
}
export function markEmailed(uid) {
  db().run("UPDATE dl_deliveries SET emailed_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [stamp(), stamp(), deviceId(), uid]);
}

// ---------------------------------------------------------------- the delivery copy (PDF / print / email / Drive)
export function deliveryReport(uid) {
  const r = getDelivery(uid);
  if (!r) return { kind: 'delivery', title: 'Delivery', fileName: 'Delivery', info: [], sections: [] };
  const col = (key, title, align = 'left') => ({ key, title, align });
  const $ = (n) => (n === null || n === undefined ? '' : `$${r2(n).toFixed(2)}`);
  const info = [['Customer', r.customer_name], ['Account', r.customer_code || ''], ['Invoice', `${r.invoice_no || ''} · ${r.invoice_date || ''}`], ['Total', $(r.total)],
    ['Driver', `${r.driver_name || ''}${r.vehicle_name ? ` · ${r.vehicle_name}` : ''}`], ['Left the warehouse', r.left_at || ''], ['Delivered', r.delivered_at || ''],
    ['Received by', r.receiver_name || ''], ['Paid', r.pay_amount ? `${r.pay_method} ${$(r.pay_amount)}${r.cheque_no ? ` · cheque ${r.cheque_no}${r.cheque_bank ? ` ${r.cheque_bank}` : ''}` : ''}` : (r.pay_method || '')]];
  if (r.note) info.push(['Dispatch note', r.note]);
  return {
    kind: 'delivery', title: 'Delivery note', fileName: `Delivery-${String(r.invoice_no || r.uid).replace(/\W+/g, '-')}`,
    subtitle: `${r.customer_name} · invoice ${r.invoice_no || ''}`, info, generated: stamp(),
    sections: [{ key: 'lines', title: 'Goods', columns: [col('item', 'Item'), col('qty', 'Qty', 'right'), col('got', 'Delivered', 'right'), col('amount', 'Amount', 'right')],
      rows: r.lines.map((l, i) => ({ key: String(i), item: l.name, qty: String(l.qty), got: r.check && r.check[i] ? String(r.check[i].got) : '', amount: l.amount === null ? '' : $(l.amount), _tone: r.check && r.check[i] && Math.abs(r.check[i].diff) > 0.0005 ? 'warn' : null })) }],
    signatures: r.signature ? [{ data: r.signature, label: `Received by ${r.receiver_name || ''}`, at: r.delivered_at }] : [],
  };
}

// ---------------------------------------------------------------- Home
export function deliveryAlerts(user) {
  if (!has()) return [];
  const out = [];
  const s = (n) => (n === 1 ? 'y' : 'ies');
  if (can(user, 'trade_dispatch')) {
    const short = db().all("SELECT * FROM dl_deliveries WHERE short = 1 AND status IN ('checked','on_road')");
    if (short.length) out.push({ id: 'dl-short', level: 'urgent', text: `${short.length} load${short.length === 1 ? '' : 's'} not as invoiced`, sub: short.slice(0, 3).map((r) => `${r.customer_name} (${r.invoice_no})`).join(' · '), nav: { screen: 'DlBoard', params: { tab: 'open' } } });
    const prob = db().all("SELECT * FROM dl_deliveries WHERE status = 'problem'");
    if (prob.length) out.push({ id: 'dl-problem', level: 'urgent', text: `${prob.length} deliver${s(prob.length)} with a problem`, sub: prob.slice(0, 3).map((r) => `${r.customer_name}: ${r.problem}`).join(' · '), nav: { screen: 'DlBoard', params: { tab: 'open' } } });
    const waiting = toDispatch().length;
    if (waiting) out.push({ id: 'dl-todispatch', level: 'info', text: `${waiting} Aronium invoice${waiting === 1 ? '' : 's'} to send out`, nav: { screen: 'DlBoard', params: { tab: 'send' } } });
    const old = addDays(dateStr(), -1);
    const notIn = db().all("SELECT * FROM dl_deliveries WHERE status = 'delivered' AND pay_amount > 0 AND substr(delivered_at, 1, 10) <= ?", [old]).map(decorate).filter((r) => r.payState === 'collected');
    if (notIn.length) out.push({ id: 'dl-notmatched', level: 'warning', text: `${notIn.length} payment${notIn.length === 1 ? '' : 's'} collected on the road, not yet in Aronium`, sub: notIn.slice(0, 3).map((r) => `${r.customer_name} ${r.pay_method} $${r2(r.pay_amount).toFixed(2)}`).join(' · '), nav: { screen: 'DlBoard', params: { tab: 'money' } } });
  }
  if (can(user, 'trade_drive')) {
    const mineOpen = myDeliveries(user).filter((r) => ['waiting', 'checked', 'on_road'].includes(r.status));
    if (mineOpen.length) out.push({ id: 'dl-mine', level: 'info', text: `${mineOpen.length} deliver${s(mineOpen.length)} for you`, nav: { screen: 'DlMine', params: {} } });
  }
  return out;
}
export { displayName };
