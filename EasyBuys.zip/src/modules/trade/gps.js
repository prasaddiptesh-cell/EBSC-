// GPS for deliveries (1.0.0 build 26). While a driver has deliveries loaded or on the road, the driver's phone sends
// its position (every ~30 s while the delivery screens are open). Saved places (warehouse, branches…) and the pins of
// the customers on the truck have a circle; crossing one stamps the time by itself:
//   leaving the warehouse circle → the checked deliveries are "on the road" (left at …)
//   entering a customer's circle → "arrived" on that customer's delivery
//   a long stop outside every circle, or no position for a while → a warning (each can be switched off).
// Nothing is tracked when the driver has no delivery out (off duty).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, getShared, setShared, dateStr } from '../../services/core.js';
import { can } from '../../services/access.js';
import { requirePerm, asService } from '../../services/guard.js';
import { getAccount } from './service.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = () => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'dl_points'");
const okLat = (v) => Number.isFinite(Number(v)) && Math.abs(Number(v)) <= 90;
const okLng = (v) => Number.isFinite(Number(v)) && Math.abs(Number(v)) <= 180;
const mins = (a, b) => Math.round((Date.parse(String(b).replace(' ', 'T')) - Date.parse(String(a).replace(' ', 'T'))) / 60000);

export const PLACE_KINDS = { warehouse: 'Warehouse', branch: 'Shop / branch', supplier: 'Supplier', fuel: 'Fuel station', other: 'Other' };
export const DEFAULT_GPS = { customerRadius: 100, stopMinutes: 10, noSignalMinutes: 15, alerts: { stop: true, nosignal: true }, everySeconds: 30 };
export function gpsSettings() {
  const s = getShared('gps_settings', null) || {};
  const n = (v, d, lo, hi) => Math.max(lo, Math.min(hi, Number.isFinite(Number(v)) && v !== '' && v !== null ? Number(v) : d));
  return { customerRadius: n(s.customerRadius, 100, 30, 2000), stopMinutes: n(s.stopMinutes, 10, 3, 180), noSignalMinutes: n(s.noSignalMinutes, 15, 5, 240),
    alerts: { ...DEFAULT_GPS.alerts, ...(s.alerts || {}) }, everySeconds: n(s.everySeconds, 30, 10, 300) };
}
export function saveGpsSettings(user, s) {
  requirePerm(user, 'settings');
  return asService(() => {
    const merged = { ...gpsSettings(), ...s, alerts: { ...gpsSettings().alerts, ...(s.alerts || {}) } };
    setShared('gps_settings', merged);
    const out = gpsSettings();
    audit({ user, action: 'Map and GPS settings changed', table: 'shared_settings', recordUid: 'gps_settings', after: out });
    return out;
  });
}

// Metres between two points.
export function metres(a, b) {
  const R = 6371000; const r = (x) => (Number(x) * Math.PI) / 180;
  const dLat = r(b.lat - a.lat); const dLng = r(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.min(1, Math.sqrt(h))));
}

// ---------------------------------------------------------------- places (owner / admin)
export function listPlaces({ all = false } = {}) {
  if (!has()) return [];
  return db().all(`SELECT * FROM dl_places ${all ? '' : 'WHERE active = 1'} ORDER BY kind = 'warehouse' DESC, name`);
}
export function savePlace(user, f) {
  requirePerm(user, 'settings');
  return asService(() => {
    need(txt(f.name), 'Give the place a name.');
    need(okLat(f.lat) && okLng(f.lng) && !(Number(f.lat) === 0 && Number(f.lng) === 0), 'The pin is not a real place.');
    const radius = Math.round(Number(f.radius) || 150);
    need(radius >= 30 && radius <= 5000, 'The circle is 30 to 5,000 metres.');
    const kind = PLACE_KINDS[f.kind] ? f.kind : 'other';
    const uid = txt(f.uid) || uuid('PL');
    const now = stamp();
    const before = db().get('SELECT * FROM dl_places WHERE uid = ?', [uid]);
    if (before) db().run("UPDATE dl_places SET name = ?, kind = ?, lat = ?, lng = ?, radius = ?, active = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(f.name), kind, Number(f.lat), Number(f.lng), radius, f.active === false ? 0 : 1, now, deviceId(), uid]);
    else db().run('INSERT INTO dl_places (uid, name, kind, lat, lng, radius, active, updated_at, updated_device) VALUES (?,?,?,?,?,?,1,?,?)', [uid, txt(f.name), kind, Number(f.lat), Number(f.lng), radius, now, deviceId()]);
    audit({ user, action: `${before ? 'Map place changed' : 'Map place added'}: ${txt(f.name)} (${PLACE_KINDS[kind]}, ${radius} m)`, table: 'dl_places', recordUid: uid });
    return uid;
  });
}

// ---------------------------------------------------------------- positions and stamps
function openDeliveries(driverUid) {
  return db().all("SELECT * FROM dl_deliveries WHERE driver_uid = ? AND status IN ('checked','on_road')", [driverUid]);
}
// The circles that matter for this driver now: saved places + the customers on the truck.
function circles(driverUid) {
  const st = gpsSettings();
  const out = listPlaces().map((p) => ({ key: `P:${p.uid}`, place: p, lat: p.lat, lng: p.lng, r: p.radius, label: p.name, kind: p.kind }));
  for (const d of openDeliveries(driverUid)) {
    const a = d.account_uid ? getAccount(d.account_uid) : null;
    if (a && a.lat !== null && a.lat !== undefined) out.push({ key: `A:${a.uid}`, account: a, delivery: d, lat: a.lat, lng: a.lng, r: st.customerRadius, label: a.display, kind: 'customer' });
  }
  return out;
}
function addEvent(user, e) {
  db().run(`INSERT INTO dl_events (uid, driver_uid, driver_name, vehicle_uid, kind, place_uid, account_uid, delivery_uid, label, at, lat, lng, minutes, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [uuid('EV'), user.uid, user.name, e.vehicle || null, e.kind, e.place || null, e.account || null, e.delivery || null, e.label || null, e.at, e.lat ?? null, e.lng ?? null, e.minutes ?? null, stamp(), deviceId()]);
}
const tell = (text) => { try { require('../verify/service.js').notify('delivery', text); } catch (e) { /* only a message */ } };

// A position from the driver's phone. at: 'YYYY-MM-DD HH:MM:SS' (the phone's time of the reading).
export function recordPosition(user, pos, { at = stamp() } = {}) {
  requirePerm(user, 'trade_drive');
  return asService(() => {
    if (!has() || !pos || !okLat(pos.lat) || !okLng(pos.lng)) return { kept: false };
    if (pos.accuracy !== undefined && pos.accuracy !== null && Number(pos.accuracy) > 300) return { kept: false, why: 'not accurate' };
    const open = openDeliveries(user.uid);
    if (!open.length) return { kept: false, why: 'off duty' }; // nobody is tracked without a delivery out
    const vehicle = open[0].vehicle_uid || null;
    const last = db().get('SELECT * FROM dl_points WHERE driver_uid = ? ORDER BY at DESC LIMIT 1', [user.uid]);
    const cur = { lat: Number(pos.lat), lng: Number(pos.lng) };
    const events = [];
    // the circles crossed since the last position
    if (last) {
      for (const c of circles(user.uid)) {
        const was = metres(last, c) <= c.r;
        const now = metres(cur, c) <= (was ? c.r * 1.2 : c.r); // a little slack before "left", so GPS jitter at the edge is not a stamp
        if (was === now) continue;
        if (now) {
          events.push({ kind: 'enter', label: c.label, place: c.place && c.place.uid, account: c.account && c.account.uid, delivery: c.delivery && c.delivery.uid });
          if (c.delivery && c.delivery.status === 'on_road' && !c.delivery.arrived_at) {
            db().run("UPDATE dl_deliveries SET arrived_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [at, stamp(), deviceId(), c.delivery.uid]);
          }
        } else {
          events.push({ kind: 'leave', label: c.label, place: c.place && c.place.uid, account: c.account && c.account.uid, delivery: c.delivery && c.delivery.uid });
          if (c.kind === 'warehouse') {
            const ready = open.filter((d) => d.status === 'checked');
            for (const d of ready) db().run("UPDATE dl_deliveries SET status = 'on_road', left_at = ?, left_lat = ?, left_lng = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [at, cur.lat, cur.lng, stamp(), deviceId(), d.uid]);
            if (ready.length) audit({ user, action: `Left ${c.label} (GPS) with ${ready.length} deliver${ready.length === 1 ? 'y' : 'ies'}: ${ready.map((d) => d.customer_name).join(', ')}`, table: 'dl_deliveries', recordUid: ready[0].uid });
          }
        }
      }
    }
    for (const e of events) addEvent(user, { ...e, vehicle, at, lat: cur.lat, lng: cur.lng });
    // a long stop outside every circle (once per stop)
    const st = gpsSettings();
    const inside = circles(user.uid).some((c) => metres(cur, c) <= c.r);
    if (!inside) {
      const since = db().get('SELECT MIN(at) AS a FROM dl_points WHERE driver_uid = ? AND at >= ? ', [user.uid, String(at).slice(0, 10)]);
      const away = db().all('SELECT at, lat, lng FROM dl_points WHERE driver_uid = ? AND at <= ? ORDER BY at DESC LIMIT 60', [user.uid, at]);
      let stoppedFrom = null;
      for (const p of away) { if (metres(p, cur) > 60) break; stoppedFrom = p.at; }
      const m = stoppedFrom ? mins(stoppedFrom, at) : 0;
      if (since.a && m >= st.stopMinutes) {
        const lastStop = db().get("SELECT * FROM dl_events WHERE driver_uid = ? AND kind = 'stop' ORDER BY at DESC LIMIT 1", [user.uid]);
        if (!lastStop || metres(lastStop, cur) > 60 || lastStop.at < stoppedFrom) {
          addEvent(user, { kind: 'stop', label: 'Stopped (not a saved place)', vehicle, at, lat: cur.lat, lng: cur.lng, minutes: m });
          if (st.alerts.stop) tell(`${user.name} stopped ${m} minutes at a place that is not saved (${cur.lat.toFixed(5)}, ${cur.lng.toFixed(5)}).`);
        } else db().run('UPDATE dl_events SET minutes = ?, updated_at = ?, updated_device = ?, sync_status = \'pending\' WHERE uid = ?', [m, stamp(), deviceId(), lastStop.uid]);
      }
    }
    // keep the point (every reading the phone gives: it already spaces them by time and distance)
    db().run('INSERT INTO dl_points (uid, driver_uid, driver_name, vehicle_uid, at, lat, lng, acc, speed, source, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [uuid('PT'), user.uid, user.name, vehicle, at, cur.lat, cur.lng, pos.accuracy ?? null, pos.speed ?? null, 'phone', stamp(), deviceId()]);
    return { kept: true, events: events.map((e) => `${e.kind} ${e.label}`) };
  });
}

// ---------------------------------------------------------------- the map and the operations screen
// One line per driver on duty today: where, what, how long since the last position.
export function fleet({ now = stamp() } = {}) {
  if (!has()) return [];
  const day = String(now).slice(0, 10);
  const st = gpsSettings();
  const drivers = db().all("SELECT DISTINCT driver_uid, driver_name FROM dl_deliveries WHERE driver_uid IS NOT NULL AND (status IN ('checked','on_road','problem') OR substr(COALESCE(delivered_at, made_at), 1, 10) = ?)", [day]);
  return drivers.map((d) => {
    const all = db().all("SELECT * FROM dl_deliveries WHERE driver_uid = ? AND status <> 'cancelled' AND (status IN ('waiting','checked','on_road','problem') OR substr(COALESCE(delivered_at, ''), 1, 10) = ?) ORDER BY made_at", [d.driver_uid, day]);
    const last = db().get('SELECT * FROM dl_points WHERE driver_uid = ? ORDER BY at DESC LIMIT 1', [d.driver_uid]);
    const ago = last ? mins(last.at, now) : null;
    const lastEv = db().get('SELECT * FROM dl_events WHERE driver_uid = ? ORDER BY at DESC LIMIT 1', [d.driver_uid]);
    const onRoad = all.filter((x) => x.status === 'on_road');
    const atCustomer = lastEv && lastEv.kind === 'enter' && lastEv.account_uid && onRoad.some((x) => x.account_uid === lastEv.account_uid) ? lastEv.label : null;
    const stopped = lastEv && lastEv.kind === 'stop' && last && metres(lastEv, last) <= 60 ? lastEv : null;
    let state = 'loading';
    if (onRoad.length) state = ago !== null && ago > st.noSignalMinutes ? 'nosignal' : stopped ? 'stopped' : atCustomer ? 'customer' : 'moving';
    else if (all.length && all.every((x) => x.status === 'delivered')) state = 'done';
    return {
      driverUid: d.driver_uid, driver: d.driver_name, vehicle: (all[0] && all[0].vehicle_name) || '', last, minutesAgo: ago, state, atCustomer, stopMinutes: stopped ? stopped.minutes : null,
      done: all.filter((x) => x.status === 'delivered').length, total: all.length, next: onRoad[0] ? onRoad[0].customer_name : null,
    };
  });
}
// What happened today, newest first: GPS stamps and the delivery steps.
export function feed({ day = dateStr(), limit = 40 } = {}) {
  if (!has()) return [];
  const ev = db().all('SELECT * FROM dl_events WHERE substr(at, 1, 10) = ? ORDER BY at DESC LIMIT ?', [day, limit]).map((e) => ({
    at: e.at, tone: e.kind === 'stop' ? 'warn' : null,
    text: e.kind === 'enter' ? `${e.driver_name} arrived at ${e.label}` : e.kind === 'leave' ? `${e.driver_name} left ${e.label}` : `${e.driver_name} stopped ${e.minutes || ''} min – not a saved place`,
  }));
  const dl = db().all("SELECT * FROM dl_deliveries WHERE substr(COALESCE(delivered_at, ''), 1, 10) = ? OR (status = 'problem' AND substr(updated_at, 1, 10) = ?)", [day, day]).map((r) => (r.status === 'problem'
    ? { at: r.updated_at, tone: 'danger', text: `${r.driver_name}: problem at ${r.customer_name} – ${r.problem}` }
    : { at: r.delivered_at, tone: null, text: `${r.driver_name}: ${r.customer_name} signed by ${r.receiver_name}${r.pay_amount ? ` · ${r.pay_method} $${Number(r.pay_amount).toFixed(2)}` : ''}` }));
  return ev.concat(dl).sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, limit);
}
export function trip(driverUid, day = dateStr()) {
  if (!has()) return { points: [], events: [] };
  return {
    points: db().all('SELECT at, lat, lng FROM dl_points WHERE driver_uid = ? AND substr(at, 1, 10) = ? ORDER BY at', [driverUid, day]),
    events: db().all('SELECT * FROM dl_events WHERE driver_uid = ? AND substr(at, 1, 10) = ? ORDER BY at', [driverUid, day]),
  };
}
// Everything the map draws: places, customer pins of today's deliveries, trucks (last position).
export function mapData({ now = stamp() } = {}) {
  const st = gpsSettings();
  const places = listPlaces().map((p) => ({ name: p.name, kind: p.kind, lat: p.lat, lng: p.lng, r: p.radius }));
  const customers = [];
  const seen = new Set();
  if (has()) {
    for (const d of db().all("SELECT DISTINCT account_uid FROM dl_deliveries WHERE account_uid IS NOT NULL AND status IN ('waiting','checked','on_road','problem')")) {
      const a = getAccount(d.account_uid);
      if (a && a.lat !== null && a.lat !== undefined && !seen.has(a.uid)) { seen.add(a.uid); customers.push({ name: a.display, lat: a.lat, lng: a.lng, r: st.customerRadius }); }
    }
  }
  const trucks = fleet({ now }).filter((f) => f.last).map((f) => ({ name: f.driver, vehicle: f.vehicle, lat: f.last.lat, lng: f.last.lng, state: f.state, ago: f.minutesAgo }));
  return { places, customers, trucks };
}

// ---------------------------------------------------------------- Home
export function gpsAlerts(user, { now = stamp() } = {}) {
  if (!has() || !(can(user, 'trade_dispatch') || can(user, 'trade_map'))) return [];
  const st = gpsSettings();
  const out = [];
  const f = fleet({ now });
  if (st.alerts.nosignal) {
    const lost = f.filter((x) => x.state === 'nosignal');
    if (lost.length) out.push({ id: 'gps-nosignal', level: 'warning', text: `${lost.length} truck${lost.length === 1 ? '' : 's'} with no position for ${st.noSignalMinutes}+ minutes`, sub: lost.map((x) => `${x.driver} (${x.minutesAgo} min)`).join(' · '), nav: { screen: 'DlMap', params: {} } });
  }
  if (st.alerts.stop) {
    const stops = f.filter((x) => x.state === 'stopped');
    if (stops.length) out.push({ id: 'gps-stop', level: 'warning', text: `${stops.length} truck${stops.length === 1 ? '' : 's'} stopped at a place that is not saved`, sub: stops.map((x) => `${x.driver} ${x.stopMinutes} min`).join(' · '), nav: { screen: 'DlMap', params: {} } });
  }
  return out;
}
