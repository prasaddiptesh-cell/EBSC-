// Trade accounts (1.0.0 build 23, wholesale): customer and supplier accounts with their numbers, terms, the signed
// credit agreement, shop photos and the map pin. Switched off until the owner turns it on (Admin › Modules).
import * as S from './screens/TradeScreens.js';
import * as DS from './screens/DeliveryScreens.js';
import { canDispatch, canDrive } from './deliveries.js';
import * as MS from './screens/MapScreens.js';
const canMap = (u) => can(u, 'trade_map') || can(u, 'trade_dispatch');
import { canView, canManage } from './service.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'trade',
  title: 'Trade accounts',
  icon: '🏪',
  switchable: true,
  screens: {
    TradeList: { component: S.TradeListScreen, can: canView },
    TradeAccount: { component: S.TradeAccountScreen, can: canView },
    TradeEdit: { component: S.TradeEditScreen, can: canManage },
    DlBoard: { component: DS.DlBoardScreen, can: canDispatch },
    DlSend: { component: DS.DlSendScreen, can: canDispatch },
    DlView: { component: DS.DlViewScreen, can: canDrive },
    DlMine: { component: DS.DlMineScreen, can: canDrive },
    DlCheck: { component: DS.DlCheckScreen, can: canDrive },
    DlDeliver: { component: DS.DlDeliverScreen, can: canDrive },
    DlMap: { component: MS.DlMapScreen, can: canMap },
    DlOps: { component: MS.DlOpsScreen, can: canMap },
    DlPlaces: { component: MS.DlPlacesScreen, can: (u) => can(u, 'settings') },
    DlSettings: { component: DS.DlSettingsScreen, can: (u) => can(u, 'settings') },
    TradeFiling: { component: S.TradeFilingScreen, can: (u) => can(u, 'settings') },
    TradeSettings: { component: S.TradeSettingsScreen, can: (u) => can(u, 'settings') },
  },
  menu: MENU,
  alerts,
  reports: [],
};
