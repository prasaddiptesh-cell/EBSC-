// Trade accounts menu (wholesale): customers on account and suppliers.
import { canManage } from './service.js';
import { canDispatch, canDrive } from './deliveries.js';
import { can } from '../../services/access.js';

export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'dl-board', icon: '🚚', title: 'Deliveries', note: 'Send Aronium invoices out: driver, truck and dispatch note. What is out now, and the money collected.', screen: 'DlBoard', perm: canDispatch },
    { id: 'dl-map', icon: '🗺️', title: 'Live map', note: 'Every truck on the map, stops, arrivals; the operations screen for a wall monitor.', screen: 'DlMap', perm: (u) => can(u, 'trade_map') || canDispatch(u) },
    { id: 'dl-mine', icon: '📦', title: 'My deliveries', note: 'Check the load, leave, get the signature and the payment.', screen: 'DlMine', perm: canDrive },
    { id: 'home', icon: '🏪', title: 'Customers', note: 'Search by name, number or phone. Shop photos and map pin for the drivers.', screen: 'TradeList', params: { kind: 'customer' } },
    { id: 'tr-suppliers', icon: '🚛', title: 'Suppliers', note: 'Supplier accounts, terms and agreements.', screen: 'TradeList', params: { kind: 'supplier' } },
    { id: 'tr-new', icon: '➕', title: 'Open an account', note: 'Customer or supplier – a credit account needs the signed agreement.', screen: 'TradeEdit', perm: canManage },
  ] },
  { section: 'Settings', items: [
    { id: 'dl-places', icon: '📍', title: 'Map places and GPS', note: 'Warehouse and other places with their circles; stop and no-position alerts.', screen: 'DlPlaces', perm: (u) => can(u, 'settings') },
    { id: 'dl-settings', icon: '🚚', title: 'Delivery settings', note: 'Dispatch notes, how customers pay the driver, emailing the delivery note.', screen: 'DlSettings', perm: (u) => can(u, 'settings') },
    { id: 'tr-filing', icon: '🗂️', title: 'Filing', note: 'Month › Inbound / Outbound › supplier or customer › kind – order, names and file names.', screen: 'TradeFiling', perm: (u) => can(u, 'settings') },
    { id: 'tr-settings', icon: '⚙️', title: 'Account numbers', note: 'Location codes and what they mean (town or branch), year and digits.', screen: 'TradeSettings', perm: (u) => can(u, 'settings') },
  ] },
];
