// Trade accounts menu (wholesale): customers on account and suppliers.
import { canManage } from './service.js';
import { can } from '../../services/access.js';

export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🏪', title: 'Customers', note: 'Search by name, number or phone. Shop photos and map pin for the drivers.', screen: 'TradeList', params: { kind: 'customer' } },
    { id: 'tr-suppliers', icon: '🚛', title: 'Suppliers', note: 'Supplier accounts, terms and agreements.', screen: 'TradeList', params: { kind: 'supplier' } },
    { id: 'tr-new', icon: '➕', title: 'Open an account', note: 'Customer or supplier – a credit account needs the signed agreement.', screen: 'TradeEdit', perm: canManage },
  ] },
  { section: 'Settings', items: [
    { id: 'tr-settings', icon: '⚙️', title: 'Account numbers', note: 'Location codes and what they mean (town or branch), year and digits.', screen: 'TradeSettings', perm: (u) => can(u, 'settings') },
  ] },
];
