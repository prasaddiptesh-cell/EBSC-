// Trade accounts (1.0.0 build 23, the wholesale module): customers who buy on account and the suppliers the business
// buys from, each with an account number (location code + year + running number), payment terms, the signed credit
// agreement, shop photos and the map pin for the drivers. Aronium stays the main record: the account number is put
// in the Aronium customer / supplier code so the invoices match.
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
const S = "updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'";

export const TRADE_SQL = `
CREATE TABLE IF NOT EXISTS trade_accounts (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'customer',
  number TEXT NOT NULL,
  loc_code TEXT NOT NULL,
  num_year INTEGER,
  num_seq INTEGER NOT NULL,
  name TEXT NOT NULL,
  trading_name TEXT,
  contact TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  town TEXT,
  lat REAL,
  lng REAL,
  directions TEXT,
  tin TEXT,
  terms TEXT NOT NULL DEFAULT 'cash',
  credit_days INTEGER,
  credit_limit REAL,
  agreement_until TEXT,
  no_agreement_by TEXT,
  no_agreement_reason TEXT,
  aronium_code TEXT,
  ap_supplier_uid TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_by TEXT, created_at TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_trade_accounts_number ON trade_accounts(number);
CREATE INDEX IF NOT EXISTS idx_trade_accounts_name ON trade_accounts(name);

-- 1.0.0 build 25: deliveries. One row per Aronium invoice sent out on a truck: the copy of the invoice (number,
-- customer, lines), the dispatch note, who drives, the check on loading, the times, the signature, the money taken.
CREATE TABLE IF NOT EXISTS dl_deliveries (
  uid TEXT PRIMARY KEY,
  doc_key TEXT NOT NULL,
  invoice_no TEXT,
  invoice_date TEXT,
  customer_name TEXT NOT NULL,
  customer_code TEXT,
  account_uid TEXT,
  shop_code TEXT,
  total REAL NOT NULL DEFAULT 0,
  owing REAL NOT NULL DEFAULT 0,
  lines TEXT NOT NULL DEFAULT '[]',
  note TEXT,
  driver_uid TEXT, driver_name TEXT,
  vehicle_uid TEXT, vehicle_name TEXT,
  status TEXT NOT NULL DEFAULT 'waiting',
  check_lines TEXT,
  short INTEGER NOT NULL DEFAULT 0,
  checked_at TEXT, checked_by TEXT,
  left_at TEXT, left_lat REAL, left_lng REAL,
  arrived_at TEXT,
  delivered_at TEXT, at_lat REAL, at_lng REAL,
  receiver_name TEXT, signature TEXT,
  pay_method TEXT, pay_amount REAL, cheque_no TEXT, cheque_bank TEXT, photo_urls TEXT,
  printed INTEGER NOT NULL DEFAULT 0,
  emailed_at TEXT,
  problem TEXT,
  made_by TEXT, made_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_dl_doc ON dl_deliveries(doc_key);
CREATE INDEX IF NOT EXISTS idx_dl_driver ON dl_deliveries(driver_uid, status);

-- 1.0.0 build 26: GPS. Saved places with a circle (warehouse, branches, fuel…); the trucks' positions while on the road
-- (from the driver's phone, or a fixed tracker later); and the stamps made when a truck crosses a circle.
CREATE TABLE IF NOT EXISTS dl_places (
  uid TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'other',
  lat REAL NOT NULL, lng REAL NOT NULL,
  radius INTEGER NOT NULL DEFAULT 150,
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS dl_points (
  uid TEXT PRIMARY KEY,
  driver_uid TEXT, driver_name TEXT, vehicle_uid TEXT,
  at TEXT NOT NULL,
  lat REAL NOT NULL, lng REAL NOT NULL, acc REAL, speed REAL,
  source TEXT NOT NULL DEFAULT 'phone',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_dl_points ON dl_points(driver_uid, at);
CREATE TABLE IF NOT EXISTS dl_events (
  uid TEXT PRIMARY KEY,
  driver_uid TEXT, driver_name TEXT, vehicle_uid TEXT,
  kind TEXT NOT NULL,
  place_uid TEXT, account_uid TEXT, delivery_uid TEXT, label TEXT,
  at TEXT NOT NULL, lat REAL, lng REAL, minutes INTEGER,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_dl_events ON dl_events(driver_uid, at);
`;

export const TRADE_SYNC = {
  trade_accounts: SYNC('uid', 'Trade accounts', ['uid', 'kind', 'number', 'loc_code', 'num_year', 'num_seq', 'name', 'trading_name', 'contact', 'phone', 'email', 'address', 'town',
    'lat', 'lng', 'directions', 'tin', 'terms', 'credit_days', 'credit_limit', 'agreement_until', 'no_agreement_by', 'no_agreement_reason', 'aronium_code', 'ap_supplier_uid', 'notes', 'status',
    'created_by', 'created_at']),
  dl_deliveries: SYNC('uid', 'Deliveries', ['uid', 'doc_key', 'invoice_no', 'invoice_date', 'customer_name', 'customer_code', 'account_uid', 'shop_code', 'total', 'owing', 'lines', 'note',
    'driver_uid', 'driver_name', 'vehicle_uid', 'vehicle_name', 'status', 'check_lines', 'short', 'checked_at', 'checked_by', 'left_at', 'left_lat', 'left_lng', 'arrived_at', 'delivered_at',
    'at_lat', 'at_lng', 'receiver_name', 'signature', 'pay_method', 'pay_amount', 'cheque_no', 'cheque_bank', 'photo_urls', 'printed', 'emailed_at', 'problem', 'made_by', 'made_at']),
  dl_places: SYNC('uid', 'Map places', ['uid', 'name', 'kind', 'lat', 'lng', 'radius', 'active']),
  dl_points: SYNC('uid', 'Truck positions', ['uid', 'driver_uid', 'driver_name', 'vehicle_uid', 'at', 'lat', 'lng', 'acc', 'speed', 'source']),
  dl_events: SYNC('uid', 'Trip stamps', ['uid', 'driver_uid', 'driver_name', 'vehicle_uid', 'kind', 'place_uid', 'account_uid', 'delivery_uid', 'label', 'at', 'lat', 'lng', 'minutes']),
};
