// Trade accounts (1.0.0 build 23, the wholesale module): customers who buy on account and the suppliers the business
// buys from, each with an account number (location code + year + running number), payment terms, the signed credit
// agreement, shop photos and the map pin for the drivers. Aronium stays the main record: the account number is put
// in the Aronium customer / supplier code so the invoices match.
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
const S = "updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'";

export const TRADE_SQL = `
CREATE TABLE IF NOT EXISTS trade_accounts (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'customer',
  number TEXT NOT NULL,
  loc_code TEXT NOT NULL,
  num_year INTEGER,
  num_seq INTEGER NOT NULL,
  name TEXT NOT NULL,
  trading_name TEXT,
  contact TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  town TEXT,
  lat REAL,
  lng REAL,
  directions TEXT,
  tin TEXT,
  terms TEXT NOT NULL DEFAULT 'cash',
  credit_days INTEGER,
  credit_limit REAL,
  agreement_until TEXT,
  no_agreement_by TEXT,
  no_agreement_reason TEXT,
  aronium_code TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_by TEXT, created_at TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_trade_accounts_number ON trade_accounts(number);
CREATE INDEX IF NOT EXISTS idx_trade_accounts_name ON trade_accounts(name);
`;

export const TRADE_SYNC = {
  trade_accounts: SYNC('uid', 'Trade accounts', ['uid', 'kind', 'number', 'loc_code', 'num_year', 'num_seq', 'name', 'trading_name', 'contact', 'phone', 'email', 'address', 'town',
    'lat', 'lng', 'directions', 'tin', 'terms', 'credit_days', 'credit_limit', 'agreement_until', 'no_agreement_by', 'no_agreement_reason', 'aronium_code', 'notes', 'status',
    'created_by', 'created_at']),
};
