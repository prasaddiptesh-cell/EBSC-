// Deliveries (1.0.0 build 25): the office's dispatch board, sending an Aronium invoice out, the driver's list, the load
// check, delivering (signature, payment, cheque photo) and the settings. Lists refresh by themselves while open.
import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Row, Section, Label, useApp, Choice, PhotoPicker } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint, MoneyField } from '../../../ui/kit.js';
import { SignaturePad, SignatureView } from '../../../ui/signature.js';
import { money, dateStr } from '../../../services/core.js';
import { db } from '../../../db/connection.js';
import { can } from '../../../services/access.js';
import * as D from '../deliveries.js';
import { useTracking } from './MapScreens.js';

// While a list is open the phone asks the cloud for news every 20 seconds (a new delivery reaches the driver quickly).
function useLive(ms = 20000) {
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(async () => {
      try { await require('../../../platform/cloud.js').syncNow(); } catch (e) { /* offline: the next try */ }
      tick((n) => n + 1);
    }, ms);
    return () => clearInterval(t);
  }, [ms]);
}
const TONE = { waiting: C.sub, checked: C.success, on_road: C.primary, delivered: C.success, problem: C.danger, cancelled: C.sub };
const PAY = { matched: ['Matched in Aronium', C.success], collected: ['Collected – not yet in Aronium', C.warn], none: ['', null] };
const drivers = () => db().all('SELECT uid, name, role FROM users WHERE active = 1 ORDER BY name').filter((u) => can(u, 'trade_drive'));
const vehicles = () => { try { return db().all("SELECT uid, name FROM ve_items WHERE kind = 'vehicle' AND status = 'active' ORDER BY name"); } catch (e) { return []; } };

// ------------------------------------------------------------------ office: the board
export function DlBoardScreen({ params = {} }) {
  const { nav } = useApp();
  useLive();
  const [tab, setTab] = useState(params.tab || 'send');
  const send = tab === 'send' ? D.toDispatch() : [];
  const list = tab === 'open' ? D.listDeliveries({ status: 'open' }) : tab === 'money' ? D.listDeliveries({ status: 'delivered' }).filter((r) => r.pay_amount > 0) : tab === 'done' ? D.listDeliveries({ status: 'delivered' }).slice(0, 100) : [];
  return (
    <Screen title="Deliveries" subtitle="Aronium invoices out to customers">
      <Chips value={tab} onChange={setTab} testIDPrefix="dl-tab" options={[{ value: 'send', label: 'To send' }, { value: 'open', label: 'Out now' }, { value: 'money', label: 'Money' }, { value: 'done', label: 'Delivered' }]} />
      {tab === 'send' ? <>
        <Hint>Invoices made in Aronium for account customers in the last few days. Tap one to send it out.</Hint>
        {send.map((d) => <ListItem key={d.key} testID={`dl-send-${d.number}`} title={d.account ? d.account.display : d.customer} sub={`Invoice ${d.number} · ${d.date} · ${(d.items || []).length} lines`} right={money(d.total)} onPress={() => nav.push('DlSend', { key: d.key })} />)}
        {!send.length ? <Hint>Nothing waiting. New Aronium invoices for account customers show here within a minute or two.</Hint> : null}
      </> : null}
      {list.map((r) => {
        const p = PAY[r.payState] || PAY.none;
        return <ListItem key={r.uid} testID={`dl-${r.uid}`} title={r.customer_name} sub={`${r.invoice_no || ''} · ${r.driver_name || ''} · ${r.statusText}${r.short ? ' · NOT AS INVOICED' : ''}${tab === 'money' && p[0] ? ` · ${p[0]}` : ''}`}
          right={tab === 'money' ? `${r.pay_method} ${money(r.pay_amount)}` : money(r.total)} badgeColor={r.short || r.status === 'problem' ? C.danger : TONE[r.status]} onPress={() => nav.push('DlView', { uid: r.uid })} />;
      })}
      {tab !== 'send' && !list.length ? <Hint>None.</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ office: send one out
export function DlSendScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const d = D.toDispatch({ days: 30 }).find((x) => x.key === params.key);
  const ds = drivers();
  const vs = vehicles();
  const st = D.deliverySettings();
  const [driver, setDriver] = useState(ds.length === 1 ? ds[0].uid : '');
  const [vehicle, setVehicle] = useState(vs.length === 1 ? vs[0].uid : '');
  const [preset, setPreset] = useState('');
  const [note, setNote] = useState('');
  if (!d) return <Screen title="Send out"><Hint>This invoice is already out, or no longer waiting.</Hint></Screen>;
  const a = d.account;
  const go = () => {
    const full = [preset, note].map((x) => String(x || '').trim()).filter(Boolean).join(' – ');
    const uid = act(() => D.createDelivery(user, { key: d.key, driverUid: driver, vehicleUid: vehicle, note: full }), 'Sent to the driver');
    if (uid) nav.replace('DlView', { uid });
  };
  return (
    <Screen title={a ? a.display : d.customer} subtitle={`Invoice ${d.number} · ${d.date} · ${money(d.total)}`} footer={<Btn testID="dl-go" title="Send to the driver" icon="🚚" variant="success" onPress={go} />}>
      {a && a.status !== 'active' ? <Banner tone="danger" title={`This account is ${a.status === 'on_hold' ? 'ON HOLD' : 'closed'}`} message="Check with the owner before sending goods." /> : null}
      {a && a.terms === 'credit' && a.credit_limit !== null && a.credit_limit !== undefined && d.owing > a.credit_limit ? <Banner tone="warn" title="Over the credit limit" message={`Owing ${money(d.owing)} on this invoice; limit ${money(a.credit_limit)}.`} /> : null}
      <Choice label="Driver" value={driver} onChange={setDriver} testIDPrefix="dl-driver" options={ds.map((u) => ({ value: u.uid, label: u.name }))} />
      {!ds.length ? <Hint>Nobody may drive deliveries yet: give the permission "Drive deliveries" (Admin › People).</Hint> : null}
      {vs.length ? <Choice label="Truck" value={vehicle} onChange={setVehicle} testIDPrefix="dl-truck" options={vs.map((v) => ({ value: v.uid, label: v.name }))} /> : null}
      <Label>Dispatch note for the driver</Label>
      <Chips value={preset} onChange={(v) => setPreset(preset === v ? '' : v)} testIDPrefix="dl-note" options={st.notes.map((n) => ({ value: n, label: n }))} />
      <Field testID="dl-note-text" label="More (optional)" value={note} onChangeText={setNote} placeholder="e.g. cheque for $1,250 – ask for Mr Sharma" />
      <Section title={`Goods (${d.items.length} lines)`}>
        {d.items.map((i, n) => <Row key={n} label={String(i[0] || '')} value={`${i[1]}${i[2] !== null && i[2] !== undefined ? ` · ${money(i[2])}` : ''}`} />)}
      </Section>
    </Screen>
  );
}

// ------------------------------------------------------------------ one delivery (office and driver)
export function DlViewScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  useLive(30000);
  const r = D.getDelivery(params.uid);
  const [why, setWhy] = useState('');
  useTracking(user, !!r && r.driver_uid === user.uid && ['checked', 'on_road'].includes(r.status));
  if (!r) return <Screen title="Delivery"><Hint>Not found.</Hint></Screen>;
  const isDriver = r.driver_uid === user.uid || D.canDispatch(user);
  const p = PAY[r.payState] || PAY.none;
  return (
    <Screen title={r.customer_name} subtitle={`Invoice ${r.invoice_no || ''} · ${r.statusText}`}
      footer={isDriver && ['waiting', 'checked'].includes(r.status) ? <Btn testID="dl-check" title={r.status === 'checked' ? 'Check the load again' : 'Check the load'} icon="✅" onPress={() => nav.push('DlCheck', { uid: r.uid })} />
        : isDriver && r.status === 'on_road' ? <Btn testID="dl-deliver" title="Deliver: signature and payment" icon="✍️" variant="success" onPress={() => nav.push('DlDeliver', { uid: r.uid })} /> : null}>
      {r.note ? <Banner tone="warn" title="Dispatch note" message={r.note} /> : null}
      {r.short ? <Banner tone="danger" title="Load not as invoiced" message={r.check.map((c, i) => (Math.abs(c.diff) > 0.0005 ? `${r.lines[i].name}: ${c.got} of ${r.lines[i].qty}` : null)).filter(Boolean).join(' · ')} /> : null}
      {r.status === 'problem' ? <Banner tone="danger" title="Problem" message={r.problem} /> : null}
      <Card>
        <Row label="Total" value={money(r.total)} bold />
        <Row label="Driver" value={`${r.driver_name || ''}${r.vehicle_name ? ` · ${r.vehicle_name}` : ''}`} />
        <Row label="Sent by" value={`${r.made_by || ''} · ${String(r.made_at || '').slice(0, 16)}`} />
        {r.checked_at ? <Row label="Load checked" value={`${r.checked_by} · ${r.checked_at.slice(11, 16)}`} /> : null}
        {r.left_at ? <Row label="Left" value={r.left_at.slice(0, 16)} /> : null}
        {r.arrived_at ? <Row label="Arrived" value={r.arrived_at.slice(0, 16)} /> : null}
        {r.delivered_at ? <Row label="Delivered" value={`${r.delivered_at.slice(0, 16)} · ${r.receiver_name}`} /> : null}
        {r.pay_method ? <Row label="Payment" value={`${r.pay_method}${r.pay_amount ? ` ${money(r.pay_amount)}` : ''}${r.cheque_no ? ` · cheque ${r.cheque_no}` : ''}`} /> : null}
        {p[0] ? <Row label="Aronium" value={p[0]} color={p[1]} /> : null}
        {r.emailed_at ? <Row label="Emailed" value={r.emailed_at.slice(0, 16)} /> : null}
      </Card>
      {r.signature ? <SignatureView data={r.signature} /> : null}
      <Section title={`Goods (${r.lines.length} lines)`}>
        {r.lines.map((l, i) => <Row key={i} label={l.name} value={`${l.qty}${r.check && r.check[i] ? ` · loaded ${r.check[i].got}` : ''}`} color={r.check && r.check[i] && Math.abs(r.check[i].diff) > 0.0005 ? C.danger : undefined} />)}
      </Section>
      {isDriver && r.status !== 'delivered' && r.status !== 'cancelled' ? (
        <Section title="Can't deliver?">
          <Field testID="dl-why" label="What happened" value={why} onChangeText={setWhy} placeholder="Shop closed, refused, wrong goods…" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <Btn testID="dl-problem" title="Report a problem" icon="⚠️" variant="danger" size="md" onPress={() => act(() => D.reportProblem(user, r.uid, why), 'The office is told')} />
            {D.canDispatch(user) ? <Btn testID="dl-cancel" title="Cancel the delivery" icon="✖️" size="md" variant="secondary" onPress={() => act(() => D.cancelDelivery(user, r.uid, why), 'Cancelled')} /> : null}
          </View>
        </Section>
      ) : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ driver: my deliveries
export function DlMineScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  useLive();
  const list = D.myDeliveries(user);
  useTracking(user, list.some((r) => ['checked', 'on_road'].includes(r.status))); // build 26: GPS while a delivery is out
  const ready = list.filter((r) => r.status === 'checked');
  return (
    <Screen title="My deliveries" subtitle={dateStr()} footer={ready.length ? <Btn testID="dl-leave" title={`Leave now with ${ready.length}`} icon="🚚" variant="success" onPress={() => act(() => D.leaveNow(user, ready.map((r) => r.uid)), 'On the road')} /> : null}>
      {list.map((r) => <ListItem key={r.uid} testID={`dlm-${r.uid}`} title={r.customer_name} sub={`${r.invoice_no || ''} · ${r.statusText}${r.note ? ` · ${r.note}` : ''}`} right={money(r.total)}
        badgeColor={r.short || r.status === 'problem' ? C.danger : TONE[r.status]} onPress={() => nav.push('DlView', { uid: r.uid })} />)}
      {!list.length ? <Hint>Nothing for you yet. New deliveries show here by themselves.</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ driver: check the load
export function DlCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const r = D.getDelivery(params.uid);
  const [got, setGot] = useState(() => (r ? r.lines.map((l, i) => String(r.check && r.check[i] ? r.check[i].got : l.qty)) : []));
  if (!r) return <Screen title="Check the load"><Hint>Not found.</Hint></Screen>;
  const save = () => { const x = act(() => D.checkLoad(user, r.uid, got.map(Number)), 'Load checked'); if (x) nav.pop(); };
  return (
    <Screen title="Check the load" subtitle={`${r.customer_name} · invoice ${r.invoice_no || ''}`} footer={<Btn testID="dlc-save" title="Load checked" icon="✅" variant="success" onPress={save} />}>
      <Hint>Count each line onto the truck. Change the number if it is not all there – the office is told before you leave.</Hint>
      {r.lines.map((l, i) => (
        <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Text style={{ flex: 1 }}>{`${l.name} (${l.qty})`}</Text>
          <View style={{ width: 110 }}><Field testID={`dlc-${i}`} label="" value={got[i]} onChangeText={(v) => setGot((o) => o.map((x, j) => (j === i ? v.replace(/[^0-9.]/g, '') : x)))} keyboardType="decimal-pad" /></View>
        </View>
      ))}
    </Screen>
  );
}

// ------------------------------------------------------------------ driver: deliver
export function DlDeliverScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const r = D.getDelivery(params.uid);
  const st = D.deliverySettings();
  const [f, setF] = useState({ receiver: '', signature: '', method: '', amount: r ? String(r.owing || r.total || '') : '', chequeNo: '', chequeBank: '', printed: true, photos: [] });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  if (!r) return <Screen title="Deliver"><Hint>Not found.</Hint></Screen>;
  const cheque = /cheque/i.test(f.method);
  const onAccount = /on account/i.test(f.method);
  const save = () => { const x = act(() => D.deliver(user, r.uid, f), 'Delivered'); if (x) nav.replace('DlView', { uid: r.uid }); };
  return (
    <Screen title="Deliver" subtitle={`${r.customer_name} · invoice ${r.invoice_no || ''} · ${money(r.total)}`} footer={<Btn testID="dld-save" title="Delivered" icon="✅" variant="success" onPress={save} />}>
      {r.note ? <Banner tone="warn" title="Dispatch note" message={r.note} /> : null}
      <Field testID="dld-receiver" label="Received by (name)" value={f.receiver} onChangeText={set('receiver')} />
      <SignaturePad testID="dld-sig" value={f.signature} onChange={set('signature')} label="Receiver signs here" />
      <Label>Payment</Label>
      <Chips value={f.method} onChange={set('method')} testIDPrefix="dld-m" options={st.methods.map((m) => ({ value: m, label: m }))} />
      {f.method && !onAccount ? <MoneyField label="Amount received" value={f.amount} onChange={set('amount')} /> : null}
      {cheque ? <>
        <Field testID="dld-cq" label="Cheque number" value={f.chequeNo} onChangeText={set('chequeNo')} keyboardType="number-pad" />
        <Field label="Bank" value={f.chequeBank} onChangeText={set('chequeBank')} placeholder="BSP, ANZ, Westpac…" />
        <PhotoPicker testID="dld-photo" label="Photo of the cheque (required)" required value={f.photos} onChange={set('photos')} />
      </> : null}
      <Chips value={f.printed ? 'y' : 'n'} onChange={(v) => set('printed')(v === 'y')} testIDPrefix="dld-printed" options={[{ value: 'y', label: 'Printed copy handed over' }, { value: 'n', label: 'No printed copy' }]} />
      <Hint>{st.emailInvoice ? 'The signed delivery note is emailed to the customer when the phone has signal.' : 'Emailing the customer is switched off in the settings.'}</Hint>
    </Screen>
  );
}

// ------------------------------------------------------------------ settings (owner / admin)
export function DlSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const cur = D.deliverySettings();
  const [notes, setNotes] = useState(cur.notes.join('\n'));
  const [methods, setMethods] = useState(cur.methods.join('\n'));
  const [email, setEmail] = useState(cur.emailInvoice ? 'y' : 'n');
  const [days, setDays] = useState(String(cur.days));
  const save = () => act(() => D.saveDeliverySettings(user, { notes: notes.split('\n'), methods: methods.split('\n'), emailInvoice: email === 'y', days: Number(days) }), 'Saved');
  return (
    <Screen title="Delivery settings" footer={<Btn testID="dls-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Field testID="dls-notes" label="Dispatch notes to choose from (one per line)" value={notes} onChangeText={setNotes} multiline />
      <Field testID="dls-methods" label="How customers pay the driver (one per line)" value={methods} onChangeText={setMethods} multiline />
      <Hint>A method with "cheque" in its name asks for the cheque number and photo. One with "on account" takes no money.</Hint>
      <Label>Email the signed delivery note to the customer</Label>
      <Chips value={email} onChange={setEmail} testIDPrefix="dls-email" options={[{ value: 'y', label: 'Yes' }, { value: 'n', label: 'No' }]} />
      <Field label="Offer Aronium invoices from the last … days" value={days} onChangeText={setDays} keyboardType="number-pad" />
    </Screen>
  );
}
