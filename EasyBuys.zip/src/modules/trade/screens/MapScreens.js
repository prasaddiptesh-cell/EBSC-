// The live map, the operations screen (a wall monitor: view only, refreshes itself) and the saved places with their
// circles and the GPS settings (1.0.0 build 26).
import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, Btn, Banner, Chips, Field, Row, Section, Label, useApp } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint } from '../../../ui/kit.js';
import { FleetMap, MAP_COLORS } from '../../../ui/fleetMap.js';
import { stamp } from '../../../services/core.js';
import { parsePin } from '../service.js';
import * as G from '../gps.js';
import { where, askLocation, follow } from '../../../platform/location.js';

const STATE_TEXT = { moving: 'On the road', customer: 'At a customer', stopped: 'Stopped', nosignal: 'No position', loading: 'Loading', done: 'All delivered' };
function useEvery(ms) {
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(async () => { try { await require('../../../platform/cloud.js').syncNow(); } catch (e) { /* offline */ } tick((n) => n + 1); }, ms);
    return () => clearInterval(t);
  }, [ms]);
}
// While a driver's screen is open and a delivery is out: the phone's position every ~30 s (stamps by itself).
export function useTracking(user, on) {
  useEffect(() => {
    if (!on || !user) return undefined;
    let stop = () => {};
    let gone = false;
    (async () => {
      if (!(await askLocation()) || gone) return;
      stop = await follow((p) => { try { G.recordPosition(user, p, { at: stamp() }); } catch (e) { /* off duty or no permission */ } }, { ms: G.gpsSettings().everySeconds * 1000, metres: 40 });
    })();
    return () => { gone = true; stop(); };
  }, [user && user.uid, on]); // eslint-disable-line react-hooks/exhaustive-deps
}

function FleetList({ list }) {
  return list.map((f) => (
    <ListItem key={f.driverUid} testID={`fl-${f.driverUid}`} title={`${f.driver}${f.vehicle ? ` · ${f.vehicle}` : ''}`}
      sub={`${STATE_TEXT[f.state]}${f.atCustomer ? ` – ${f.atCustomer}` : ''}${f.stopMinutes ? ` ${f.stopMinutes} min` : ''}${f.next && !f.atCustomer ? ` · next: ${f.next}` : ''}${f.minutesAgo !== null ? ` · ${f.minutesAgo} min ago` : ''}`}
      right={`${f.done} of ${f.total}`} badgeColor={MAP_COLORS[f.state]} />
  ));
}
function Feed({ items }) {
  return items.map((e, i) => <Text key={i} style={{ color: e.tone === 'danger' ? C.danger : e.tone === 'warn' ? C.warn : C.text, paddingVertical: 2 }}>{`${String(e.at).slice(11, 16)}  ${e.text}`}</Text>);
}

export function DlMapScreen() {
  const { nav } = useApp();
  useEvery(20000);
  const data = G.mapData();
  const list = G.fleet();
  return (
    <Screen title="Live map" subtitle="Trucks on the road today">
      <FleetMap data={data} height={380} />
      <Text style={{ color: C.sub }}>Green on the road · blue at a customer · orange stopped · red no position</Text>
      <Section title="Trucks"><FleetList list={list} />{!list.length ? <Hint>No deliveries out today.</Hint> : null}</Section>
      <Section title="Today"><Feed items={G.feed()} /></Section>
      <Btn testID="map-ops" title="Open the operations screen" icon="🖥️" variant="secondary" onPress={() => nav.push('DlOps', {})} />
    </Screen>
  );
}

// The wall screen: no buttons that change anything; refreshes every 15 seconds.
export function DlOpsScreen() {
  const { user } = useApp();
  useEvery(15000);
  useEffect(() => { const K = require('../../../services/keepSession.js'); K.holdSession(user); return () => K.releaseSession(); }, [user && user.uid]); // eslint-disable-line react-hooks/exhaustive-deps
  const data = G.mapData();
  const list = G.fleet();
  const alerts = G.gpsAlerts(user).concat(require('../deliveries.js').deliveryAlerts(user).filter((a) => ['dl-short', 'dl-problem'].includes(a.id)));
  const done = list.reduce((a, f) => a + f.done, 0); const total = list.reduce((a, f) => a + f.total, 0);
  return (
    <Screen title="Operations · live" subtitle={`${stamp().slice(11, 16)} · ${done} of ${total} delivered`}>
      {alerts.map((a) => <Banner key={a.id} tone={a.level === 'urgent' ? 'danger' : 'warn'} title={a.text} message={a.sub} />)}
      <FleetMap data={data} height={520} />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 16 }}>
        <View style={{ flex: 1, minWidth: 300 }}><Label>Trucks</Label><FleetList list={list} /></View>
        <View style={{ flex: 1, minWidth: 300 }}><Label>Live feed</Label><Feed items={G.feed({ limit: 20 })} /></View>
      </View>
    </Screen>
  );
}

export function DlPlacesScreen() {
  const { user } = useApp();
  const act = useAct();
  const [f, setF] = useState({ uid: '', name: '', kind: 'warehouse', pin: '', radius: '150' });
  const [s, setS] = useState(() => G.gpsSettings());
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const places = G.listPlaces();
  const pin = parsePin(f.pin);
  const here = async () => { const p = await where(); if (p) set('pin')(`${p.lat.toFixed(6)}, ${p.lng.toFixed(6)}`); else act(() => { throw new Error('This phone could not say where it is. Paste a Google Maps link instead.'); }); };
  const save = () => { const id = act(() => G.savePlace(user, { ...f, lat: pin && pin.lat, lng: pin && pin.lng }), 'Saved'); if (id) setF({ uid: '', name: '', kind: 'warehouse', pin: '', radius: '150' }); };
  return (
    <Screen title="Map places and GPS" subtitle="Circles that stamp the time when a truck goes in or out">
      <FleetMap data={{ places: places.map((p) => ({ name: p.name, kind: p.kind, lat: p.lat, lng: p.lng, r: p.radius })), customers: [], trucks: [] }} height={260} />
      {places.map((p) => <ListItem key={p.uid} testID={`pl-${p.uid}`} title={p.name} sub={`${G.PLACE_KINDS[p.kind]} · ${p.radius} m`} onPress={() => setF({ uid: p.uid, name: p.name, kind: p.kind, pin: `${p.lat}, ${p.lng}`, radius: String(p.radius) })} />)}
      <Section title={f.uid ? 'Change the place' : 'Add a place'}>
        <Field testID="pl-name" label="Name" value={f.name} onChangeText={set('name')} placeholder="Warehouse" />
        <Chips value={f.kind} onChange={set('kind')} testIDPrefix="pl-kind" options={Object.entries(G.PLACE_KINDS).map(([value, label]) => ({ value, label }))} />
        <Field testID="pl-pin" label="Pin – paste a Google Maps link or latitude, longitude" value={f.pin} onChangeText={set('pin')} />
        <Btn testID="pl-here" title="Use where I am now" icon="📍" size="md" variant="secondary" onPress={here} />
        {f.pin ? <Hint>{pin ? `📍 ${pin.lat}, ${pin.lng}` : 'Not understood yet.'}</Hint> : null}
        <Field testID="pl-r" label="Circle (metres)" value={f.radius} onChangeText={set('radius')} keyboardType="number-pad" />
        <Btn testID="pl-save" title="Save the place" icon="💾" variant="success" onPress={save} />
      </Section>
      <Section title="GPS settings and alerts">
        <Field label="Customer circle (metres)" value={String(s.customerRadius)} onChangeText={(v) => setS((o) => ({ ...o, customerRadius: v }))} keyboardType="number-pad" />
        <Field label="Warn after a stop of … minutes (not at a saved place)" value={String(s.stopMinutes)} onChangeText={(v) => setS((o) => ({ ...o, stopMinutes: v }))} keyboardType="number-pad" />
        <Chips value={s.alerts.stop ? 'y' : 'n'} onChange={(v) => setS((o) => ({ ...o, alerts: { ...o.alerts, stop: v === 'y' } }))} testIDPrefix="gps-stop" options={[{ value: 'y', label: 'Stop alerts on' }, { value: 'n', label: 'Off' }]} />
        <Field label="Warn when a truck has no position for … minutes" value={String(s.noSignalMinutes)} onChangeText={(v) => setS((o) => ({ ...o, noSignalMinutes: v }))} keyboardType="number-pad" />
        <Chips value={s.alerts.nosignal ? 'y' : 'n'} onChange={(v) => setS((o) => ({ ...o, alerts: { ...o.alerts, nosignal: v === 'y' } }))} testIDPrefix="gps-nosig" options={[{ value: 'y', label: 'No-position alerts on' }, { value: 'n', label: 'Off' }]} />
        <Btn testID="gps-save" title="Save the settings" icon="💾" variant="success" onPress={() => act(() => setS(G.saveGpsSettings(user, s)), 'Saved')} />
      </Section>
    </Screen>
  );
}
