// Trade accounts screens: the list with search (names first), one account (shop photos, map pin, agreement, terms),
// opening / changing an account, and the account number settings.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Label, useApp, useRemembered, Choice } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, ListItem, Hint, DateField, MoneyField } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { money, uuid } from '../../../services/core.js';
import * as T from '../service.js';

const AGREEMENT = { ok: ['Agreement OK', C.success], expiring: ['Agreement ends soon', C.warn], expired: ['AGREEMENT ENDED', C.danger], missing: ['NO AGREEMENT', C.danger], overridden: ['No agreement (allowed)', C.warn] };
const STATUS = { on_hold: ['ON HOLD', C.warn], closed: ['CLOSED', C.danger] };
const termsText = (a) => (a.terms === 'credit' ? `Credit ${a.credit_days} days${a.credit_limit !== null && a.credit_limit !== undefined ? ` · limit ${money(a.credit_limit)}` : ''}` : 'Cash / pay on delivery');

// ------------------------------------------------------------------ the list (search by name)
export function TradeListScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [kind, setKind] = useRemembered('kind', params.kind || 'customer');
  const [q, setQ] = useState(params.q || '');
  const [status, setStatus] = useRemembered('status', 'active');
  const list = T.searchAccounts({ q, kind, status });
  return (
    <Screen title={kind === 'supplier' ? 'Suppliers' : 'Customers'} subtitle="Search by name, number, phone or Aronium code"
      footer={T.canManage(user) ? <Btn testID="tr-new" title={kind === 'supplier' ? 'Open a supplier account' : 'Open a customer account'} icon="➕" onPress={() => nav.push('TradeEdit', { kind })} /> : null}>
      <Chips value={kind} onChange={setKind} testIDPrefix="tr-kind" options={[{ value: 'customer', label: 'Customers' }, { value: 'supplier', label: 'Suppliers' }]} />
      <Field testID="tr-q" label="Search" value={q} onChangeText={setQ} placeholder="Start typing a name – e.g. sharm" />
      <Chips value={status} onChange={setStatus} testIDPrefix="tr-status" options={[{ value: 'active', label: 'Open' }, { value: 'on_hold', label: 'On hold' }, { value: 'all', label: 'All' }]} />
      {list.map((a) => {
        const flag = STATUS[a.status] || (AGREEMENT[a.agreementState] && ['missing', 'expired', 'overridden'].includes(a.agreementState) ? AGREEMENT[a.agreementState] : null);
        return <ListItem key={a.uid} testID={`tr-${a.uid}`} title={a.display} sub={`${a.number} · ${termsText(a)}${a.photos.length ? ' · 📷' : ''}${a.lat !== null && a.lat !== undefined ? ' · 📍' : ''}`}
          badge={flag ? flag[0] : null} badgeColor={flag ? flag[1] : null} onPress={() => nav.push('TradeAccount', { uid: a.uid })} />;
      })}
      {!list.length ? <Hint>{q ? 'Nobody matches – check the spelling or try part of the name.' : 'No accounts yet.'}</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ one account
export function TradeAccountScreen({ params = {} }) {
  const { nav, user } = useApp();
  const act = useAct();
  const a = T.getAccount(params.uid);
  const [hold, setHold] = useState('');
  if (!a) return <Screen title="Account"><Hint>Account not found.</Hint></Screen>;
  const manage = T.canManage(user);
  const ag = AGREEMENT[a.agreementState];
  return (
    <Screen title={a.display} subtitle={`${T.KINDS[a.kind]} · ${a.number}`}
      footer={manage ? <Btn testID="tr-edit" title="Change" icon="✏️" onPress={() => nav.push('TradeEdit', { uid: a.uid })} /> : null}>
      {STATUS[a.status] ? <Banner tone="warn" title={`This account is ${a.status === 'on_hold' ? 'on hold' : 'closed'}`} /> : null}
      {a.agreementState === 'missing' || a.agreementState === 'expired' ? <Banner tone="danger" title={ag[0]} message="Add the signed credit agreement below." /> : null}
      {a.agreementState === 'overridden' ? <Banner tone="warn" title="Credit without a signed agreement" message={`Allowed by ${a.no_agreement_by}: ${a.no_agreement_reason}`} /> : null}
      <Section title="Shop photos and where to find it">
        <DocumentsPanel refType={T.REF_TYPE} refUid={a.uid} kinds={{ shop_photo: T.DOC_KINDS.shop_photo }} canAdd={manage} testID="tr-photos" defaultKind="shop_photo" />
        {a.address ? <Row label="Address" value={a.address} /> : null}
        {a.directions ? <Row label="Directions" value={a.directions} /> : null}
        {a.mapUrl ? <Btn testID="tr-map" title="Open the map" icon="📍" onPress={() => Linking.openURL(a.mapUrl)} /> : <Hint>No map pin yet – add it with Change.</Hint>}
      </Section>
      <Card>
        <Row label="Account number" value={a.number} bold />
        <Row label="Aronium code" value={a.aronium_code || a.number} />
        <Row label="Terms" value={termsText(a)} />
        {a.terms === 'credit' ? <Row label="Credit agreement" value={ag ? ag[0] : '-'} color={ag ? ag[1] : undefined} /> : null}
        {a.agreement_until ? <Row label="Agreement until" value={a.agreement_until} /> : null}
        {a.contact ? <Row label="Contact" value={a.contact} /> : null}
        {a.phone ? <Row label="Phone" value={a.phone} /> : null}
        {a.email ? <Row label="Email" value={a.email} /> : null}
        {a.tin ? <Row label="TIN" value={a.tin} /> : null}
        {a.notes ? <Row label="Notes" value={a.notes} /> : null}
      </Card>
      <Section title="Credit agreement and papers">
        <DocumentsPanel refType={T.REF_TYPE} refUid={a.uid} kinds={{ agreement: T.DOC_KINDS.agreement, id: T.DOC_KINDS.id, other: T.DOC_KINDS.other }} canAdd={manage} testID="tr-docs" defaultKind="agreement" />
      </Section>
      {manage ? (
        <Section title={a.status === 'active' ? 'Put on hold or close' : 'Open again'}>
          {a.status === 'active' ? <>
            <Field testID="tr-hold-why" label="Reason" value={hold} onChangeText={setHold} placeholder="e.g. over the limit, payments late" />
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              <Btn testID="tr-hold" title="Put on hold" icon="⏸️" onPress={() => act(() => T.setAccountStatus(user, a.uid, 'on_hold', hold), 'On hold')} />
              <Btn testID="tr-close" title="Close the account" icon="🔒" variant="danger" onPress={() => act(() => T.setAccountStatus(user, a.uid, 'closed', hold), 'Closed')} />
            </View>
          </> : <Btn testID="tr-open" title="Open again" icon="▶️" onPress={() => act(() => T.setAccountStatus(user, a.uid, 'active', ''), 'Open again')} />}
        </Section>
      ) : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ open / change an account
export function TradeEditScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const before = params.uid ? T.getAccount(params.uid) : null;
  const [f, setF] = useState(() => (before ? {
    uid: before.uid, kind: before.kind, name: before.name, tradingName: before.trading_name || '', contact: before.contact || '', phone: before.phone || '', email: before.email || '',
    address: before.address || '', town: before.town || '', pin: before.lat !== null && before.lat !== undefined ? `${before.lat}, ${before.lng}` : '', directions: before.directions || '',
    tin: before.tin || '', terms: before.terms, creditDays: before.credit_days ? String(before.credit_days) : '30', creditLimit: before.credit_limit === null || before.credit_limit === undefined ? '' : String(before.credit_limit),
    agreementUntil: before.agreement_until || '', aroniumCode: before.aronium_code || '', notes: before.notes || '', overrideAgreement: false, overrideReason: '',
  } : { uid: uuid('TA'), kind: params.kind || 'customer', name: '', tradingName: '', contact: '', phone: '', email: '', address: '', town: '', pin: '', directions: '', tin: '', terms: 'cash',
    creditDays: '30', creditLimit: '', agreementUntil: '', aroniumCode: '', notes: '', locCode: '', overrideAgreement: false, overrideReason: '' }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const codes = T.codeOptions(f.kind);
  const preview = !before && f.locCode ? T.nextNumber(f.kind, f.locCode).number : null;
  const pin = T.parsePin(f.pin);
  const docs = require('../../../services/documents.js').listDocuments(T.REF_TYPE, f.uid);
  const signed = docs.some((d) => d.kind === 'agreement');
  const save = () => {
    if (f.pin && !pin) { act(() => { throw new Error('The map pin was not understood. Paste a Google Maps link or "latitude, longitude".'); }); return; }
    const uid = act(() => T.saveAccount(user, { ...f, lat: pin ? pin.lat : null, lng: pin ? pin.lng : null }), before ? 'Saved' : 'Account opened');
    if (uid) nav.replace('TradeAccount', { uid });
  };
  return (
    <Screen title={before ? `Change ${before.display}` : 'Open an account'} subtitle={before ? before.number : null}
      footer={<Btn testID="tr-save" title={before ? 'Save' : 'Open the account'} icon="💾" variant="success" onPress={save} />}>
      {!before ? <>
        <Chips value={f.kind} onChange={(v) => setF((o) => ({ ...o, kind: v, locCode: '' }))} testIDPrefix="tre-kind" options={[{ value: 'customer', label: 'Customer' }, { value: 'supplier', label: 'Supplier' }]} />
        {codes.length ? <Choice label="Location code (for the account number)" value={f.locCode} onChange={set('locCode')} testIDPrefix="tre-code" options={codes} />
          : <Banner tone="warn" title="No location codes yet" message="Add them first: Trade accounts › Account numbers." />}
        {preview ? <Hint>{`Account number: ${preview} (given when you save; it never changes)`}</Hint> : null}
      </> : null}
      <Field testID="tre-name" label="Business name" value={f.name} onChangeText={set('name')} placeholder="e.g. Sharma's Store" />
      <Field label="Trading name (if different)" value={f.tradingName} onChangeText={set('tradingName')} />
      <Field testID="tre-town" label="Town" value={f.town} onChangeText={set('town')} placeholder="e.g. Lautoka" />
      <Field label="Contact person" value={f.contact} onChangeText={set('contact')} />
      <Field testID="tre-phone" label="Phone" value={f.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
      <Field label="Email (invoices are sent here)" value={f.email} onChangeText={set('email')} keyboardType="email-address" />
      <Field label="TIN" value={f.tin} onChangeText={set('tin')} />
      <Section title="Where to find it (for the drivers)">
        <Field label="Address" value={f.address} onChangeText={set('address')} multiline />
        <Field testID="tre-pin" label="Map pin – paste a Google Maps link or latitude, longitude" value={f.pin} onChangeText={set('pin')} placeholder="-17.6155, 177.4500" />
        {f.pin ? <Hint>{pin ? `📍 ${pin.lat}, ${pin.lng}` : 'Not understood yet – paste the whole link.'}</Hint> : null}
        <Field label="Directions for the driver" value={f.directions} onChangeText={set('directions')} multiline placeholder="e.g. blue shop opposite the school, deliver at the back" />
        <DocumentsPanel refType={T.REF_TYPE} refUid={f.uid} kinds={{ shop_photo: T.DOC_KINDS.shop_photo }} testID="tre-photos" defaultKind="shop_photo" />
      </Section>
      <Section title="Payment terms">
        <Chips value={f.terms} onChange={set('terms')} testIDPrefix="tre-terms" options={[{ value: 'cash', label: 'Cash / pay on delivery' }, { value: 'credit', label: 'Credit (on account)' }]} />
        {f.terms === 'credit' ? <>
          <Field testID="tre-days" label="Credit terms (days)" value={f.creditDays} onChangeText={set('creditDays')} keyboardType="number-pad" />
          <MoneyField label="Credit limit (leave empty for none)" value={f.creditLimit} onChange={set('creditLimit')} />
          <Label>Signed credit agreement (required)</Label>
          <DocumentsPanel refType={T.REF_TYPE} refUid={f.uid} kinds={{ agreement: T.DOC_KINDS.agreement, id: T.DOC_KINDS.id }} testID="tre-agr" defaultKind="agreement" />
          <DateField label="Agreement valid until (optional)" value={f.agreementUntil} onChange={set('agreementUntil')} />
          {!signed && !(before && before.no_agreement_by) ? (T.canOverride(user) ? <>
            <Chips value={f.overrideAgreement ? 'y' : 'n'} onChange={(v) => set('overrideAgreement')(v === 'y')} testIDPrefix="tre-override" options={[{ value: 'n', label: 'I will add the agreement' }, { value: 'y', label: 'Open without it (owner / admin)' }]} />
            {f.overrideAgreement ? <Field testID="tre-override-why" label="Reason (kept with the account)" value={f.overrideReason} onChangeText={set('overrideReason')} /> : null}
          </> : <Hint>Add the signed agreement above to open a credit account. Only the owner, an admin or someone given the permission can open one without it.</Hint>) : null}
        </> : null}
      </Section>
      <Field label="Aronium code (normally the account number)" value={f.aroniumCode} onChangeText={set('aroniumCode')} placeholder={preview || (before ? before.number : '')} />
      <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
    </Screen>
  );
}

// ------------------------------------------------------------------ account number settings
export function TradeSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const cur = T.tradeSettings();
  const [s, setS] = useState(cur);
  const [code, setCode] = useState({ code: '', label: '', kind: 'town' });
  const set = (k) => (v) => setS((o) => ({ ...o, [k]: v }));
  const rules = Object.entries(T.RULES).map(([value, label]) => ({ value, label }));
  const add = () => { if (!code.code.trim()) return; setS((o) => ({ ...o, codes: o.codes.concat([{ ...code }]) })); setCode({ code: '', label: '', kind: code.kind }); };
  const example = (() => { const y = s.year === 0 ? '' : s.year === 4 ? '-2026' : '-26'; return `${(s.codes[0] || { code: 'LTK' }).code}${y}-${'1'.padStart(s.digits, '0')}`; })();
  return (
    <Screen title="Account numbers" subtitle={`Example: ${example}`} footer={<Btn testID="trs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => T.saveTradeSettings(user, s), 'Saved')} />}>
      <Hint>Numbers already given never change – a new rule is only used for new accounts.</Hint>
      <Choice label="Customer numbers start with" value={s.customerRule} onChange={set('customerRule')} testIDPrefix="trs-crule" options={rules} />
      <Choice label="Supplier numbers start with" value={s.supplierRule} onChange={set('supplierRule')} testIDPrefix="trs-srule" options={rules} />
      <Field label="Supplier prefix (empty for none)" value={s.supplierPrefix} onChangeText={set('supplierPrefix')} placeholder="SUP" />
      <Label>Year in the number</Label>
      <Chips value={String(s.year)} onChange={(v) => set('year')(Number(v))} testIDPrefix="trs-year" options={[{ value: '2', label: '26' }, { value: '4', label: '2026' }, { value: '0', label: 'No year' }]} />
      <Label>Digits of the running number</Label>
      <Chips value={String(s.digits)} onChange={(v) => set('digits')(Number(v))} testIDPrefix="trs-digits" options={[{ value: '3', label: '001' }, { value: '4', label: '0001' }]} />
      <Section title="Location codes">
        {s.codes.map((c, i) => <ListItem key={c.code + i} testID={`trs-code-${c.code}`} title={`${c.code}${c.label ? ` – ${c.label}` : ''}`} sub={c.kind === 'branch' ? 'Shop / branch' : 'Town'} right="Remove" onPress={() => setS((o) => ({ ...o, codes: o.codes.filter((_, j) => j !== i) }))} />)}
        <Chips value={code.kind} onChange={(v) => setCode((o) => ({ ...o, kind: v }))} testIDPrefix="trs-ckind" options={[{ value: 'town', label: 'Town' }, { value: 'branch', label: 'Shop / branch' }]} />
        <Field testID="trs-code" label="Code (2–6 letters)" value={code.code} onChangeText={(v) => setCode((o) => ({ ...o, code: v.toUpperCase() }))} placeholder="LTK" />
        <Field testID="trs-label" label="Name" value={code.label} onChangeText={(v) => setCode((o) => ({ ...o, label: v }))} placeholder="Lautoka" />
        <Btn testID="trs-add" title="Add the code" icon="➕" onPress={add} />
      </Section>
    </Screen>
  );
}

// ------------------------------------------------------------------ filing (owner / admin)
const LEVEL_NAMES = { month: 'Month', direction: 'Inbound / Outbound', party: 'Supplier or customer', type: 'Kind of paper' };
export function TradeFilingScreen() {
  const { user } = useApp();
  const act = useAct();
  const [l, setL] = useState(() => T.recordsLayout());
  const set = (k) => (v) => setL((o) => ({ ...o, [k]: v }));
  const move = (i, d) => setL((o) => { const a = o.order.slice(); const j = i + d; if (j < 0 || j >= a.length) return o; [a[i], a[j]] = [a[j], a[i]]; return { ...o, order: a }; });
  return (
    <Screen title="Filing" subtitle="Where supplier invoice and payment photos go in Google Drive" footer={<Btn testID="trf-save" title="Save" icon="💾" variant="success" onPress={() => act(() => T.saveRecordsLayout(user, l), 'Saved')} />}>
      <Hint>Only new papers follow a change. Papers already filed stay where they are.</Hint>
      <Chips value={l.mode} onChange={set('mode')} testIDPrefix="trf-mode" options={[{ value: 'shop', label: 'By shop (as now)' }, { value: 'party', label: 'By supplier / customer' }]} />
      {l.mode === 'party' ? <>
        <Section title="Folder order">
          {l.order.map((k, i) => (
            <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1 }}>{`${i + 1}. ${LEVEL_NAMES[k]}`}</Text>
              <Btn testID={`trf-up-${k}`} title="↑" size="sm" variant="secondary" onPress={() => move(i, -1)} />
              <Btn testID={`trf-down-${k}`} title="↓" size="sm" variant="secondary" onPress={() => move(i, 1)} />
            </View>
          ))}
        </Section>
        <Section title="Folder names">
          <Field testID="trf-in" label="Goods in (suppliers)" value={l.inbound} onChangeText={set('inbound')} />
          <Field testID="trf-out" label="Goods out (customers)" value={l.outbound} onChangeText={set('outbound')} />
          <Field label="Invoices folder" value={l.types.invoice} onChangeText={(v) => setL((o) => ({ ...o, types: { ...o.types, invoice: v } }))} />
          <Field label="Payments folder" value={l.types.payment} onChangeText={(v) => setL((o) => ({ ...o, types: { ...o.types, payment: v } }))} />
        </Section>
        <Section title="File name">
          <Field testID="trf-name" label="Pattern" value={l.name} onChangeText={set('name')} />
          <Hint>{'Use {date} {party} {number} {amount} {shop}. {date} must stay.'}</Hint>
        </Section>
      </> : null}
      <Card><Label>Example</Label><Text testID="trf-example">{T.filingExample(l)}</Text></Card>
    </Screen>
  );
}
