// Trade accounts (1.0.0 build 23, the wholesale module).
//  • Account numbers: location code + year + running number, e.g. LTK-26-014 (suppliers SUP-LTK-26-005). The admin
//    chooses what the code means (the customer's town, the serving shop / branch, or chosen for each account), how
//    the year is written and the codes themselves. A number never changes once given.
//  • Names first everywhere: "Sharma's Store, Lautoka"; the number shows small and is used on invoices and file names.
//  • A credit account needs the signed credit agreement. The owner or an admin – or a person given the permission
//    "Open a credit account without the agreement" – can override it, with a reason that is kept.
//  • Shop photos and the map pin go with the account so the driver finds the right shop.
//  • Search by name (part of a word is enough, "sharm" finds "Sharma's Store"), number, phone or Aronium code.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, getShared, setShared, dateStr, addDays } from '../../services/core.js';
import { can } from '../../services/access.js';
import { listDocuments } from '../../services/documents.js';
import { requirePerm, requireLogin, asService } from '../../services/guard.js';
import { saveSupplier, getSupplier } from '../payables/service.js';
import { cleanLayout, photoPlace } from '../../services/photoNames.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const numOrNull = (v) => (v === null || v === undefined || txt(v) === '' ? null : Number(v));
const has = () => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'trade_accounts'");

// ---------------------------------------------------------------- who may do what
export const canView = (u) => can(u, 'trade_view') || can(u, 'trade_manage');
export const canManage = (u) => can(u, 'trade_manage');
export const canOverride = (u) => can(u, 'trade_credit_override');

export const KINDS = { customer: 'Customer', supplier: 'Supplier' };
export const TERMS = { cash: 'Cash / pay on delivery', credit: 'Credit (on account)' };
export const DOC_KINDS = { agreement: 'Signed credit agreement', shop_photo: 'Shop photo', id: 'ID / company registration', other: 'Other' };
export const REF_TYPE = 'trade_account';

// ---------------------------------------------------------------- numbering rules (admin)
export const RULES = { town: "The customer's town (where the goods go)", branch: 'The shop / branch that serves them', choose: 'Chosen for each account' };
export const DEFAULT_SETTINGS = {
  customerRule: 'town',
  supplierRule: 'town',
  supplierPrefix: 'SUP',
  year: 2, // 2 → 26, 4 → 2026, 0 → no year
  digits: 3,
  codes: [], // [{ code: 'LTK', label: 'Lautoka', kind: 'town' | 'branch' }]
};
export function tradeSettings() {
  const s = getShared('trade_settings', null) || {};
  return { ...DEFAULT_SETTINGS, ...s, codes: Array.isArray(s.codes) ? s.codes : [] };
}
export function saveTradeSettings(user, s) {
  requirePerm(user, 'settings');
  return asService(() => {
    need(can(user, 'settings'), 'Only the owner or admin can change the account number rules.');
    const cur = tradeSettings();
    const codes = (Array.isArray(s.codes) ? s.codes : cur.codes).map((c) => ({ code: txt(c.code).toUpperCase().replace(/[^A-Z0-9]/g, ''), label: txt(c.label), kind: c.kind === 'branch' ? 'branch' : 'town' }))
      .filter((c) => c.code);
    const seen = new Set();
    codes.forEach((c) => { need(c.code.length >= 2 && c.code.length <= 6, `"${c.code}": a code is 2 to 6 letters or numbers.`); need(!seen.has(c.code), `The code ${c.code} is in the list twice.`); seen.add(c.code); });
    const out = {
      customerRule: RULES[s.customerRule] ? s.customerRule : cur.customerRule,
      supplierRule: RULES[s.supplierRule] ? s.supplierRule : cur.supplierRule,
      supplierPrefix: txt(s.supplierPrefix === undefined ? cur.supplierPrefix : s.supplierPrefix).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6),
      year: [0, 2, 4].includes(Number(s.year)) ? Number(s.year) : cur.year,
      digits: Math.max(2, Math.min(6, Number(s.digits) || cur.digits)),
      codes,
    };
    setShared('trade_settings', out);
    audit({ user, action: 'Account number rules changed (numbers already given stay as they are)', table: 'shared_settings', recordUid: 'trade_settings', after: out });
    return out;
  });
}
// The codes that may be used for a new account of this kind (rule "choose" → all of them).
export function codeOptions(kind = 'customer') {
  const s = tradeSettings();
  const rule = kind === 'supplier' ? s.supplierRule : s.customerRule;
  return s.codes.filter((c) => rule === 'choose' || c.kind === rule).map((c) => ({ value: c.code, label: c.label ? `${c.code} – ${c.label}` : c.code, kind: c.kind }));
}

function yearPart(s, d) {
  const y = Number(String(d).slice(0, 4));
  if (s.year === 0) return { y: null, text: '' };
  return { y, text: s.year === 4 ? String(y) : String(y).slice(2) };
}
// The next number for this kind and code (each code and year counts on its own).
export function nextNumber(kind, code, date = dateStr()) {
  const s = tradeSettings();
  const c = txt(code).toUpperCase();
  const yp = yearPart(s, date);
  const row = has() ? db().get('SELECT MAX(num_seq) AS n FROM trade_accounts WHERE kind = ? AND loc_code = ? AND COALESCE(num_year, 0) = ?', [kind, c, yp.y || 0]) : null;
  const seq = ((row && row.n) || 0) + 1;
  const parts = [];
  if (kind === 'supplier' && s.supplierPrefix) parts.push(s.supplierPrefix);
  parts.push(c);
  if (yp.text) parts.push(yp.text);
  parts.push(String(seq).padStart(s.digits, '0'));
  return { number: parts.join('-'), seq, year: yp.y, code: c };
}

// ---------------------------------------------------------------- names first
export function displayName(a) {
  if (!a) return '';
  const n = txt(a.trading_name) || txt(a.name);
  return a.town ? `${n}, ${a.town}` : n;
}

// The map pin from what people paste: "-17.6, 177.4", a Google Maps link (…/@-17.6,177.4,17z or ?q=-17.6,177.4) or an
// OpenStreetMap link (mlat=…&mlon=…). → { lat, lng } or null.
export function parsePin(text) {
  const t = txt(text);
  if (!t) return null;
  const pats = [/@(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)/, /[?&](?:q|query|ll|destination)=(-?\d+(?:\.\d+)?)(?:,|%2C)\s*(-?\d+(?:\.\d+)?)/i,
    /mlat=(-?\d+(?:\.\d+)?)&mlon=(-?\d+(?:\.\d+)?)/, /!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)/, /^\s*(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)\s*$/];
  for (const re of pats) {
    const m = re.exec(t);
    if (m) {
      const lat = Number(m[1]); const lng = Number(m[2]);
      if (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) return { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 };
    }
  }
  return null;
}

// ---------------------------------------------------------------- reading
export function getAccount(uid) {
  if (!has()) return null;
  const a = db().get('SELECT * FROM trade_accounts WHERE uid = ?', [uid]);
  return a ? decorate(a) : null;
}
function decorate(a) {
  const docs = listDocuments(REF_TYPE, a.uid);
  const agreement = docs.filter((d) => d.kind === 'agreement');
  const photos = docs.filter((d) => d.kind === 'shop_photo');
  const today = dateStr();
  const agreementState = a.terms !== 'credit' ? 'none'
    : !agreement.length ? (a.no_agreement_by ? 'overridden' : 'missing')
      : a.agreement_until && a.agreement_until < today ? 'expired'
        : a.agreement_until && a.agreement_until <= addDays(today, 30) ? 'expiring' : 'ok';
  return { ...a, display: displayName(a), agreements: agreement, photos, agreementState, mapUrl: a.lat !== null && a.lat !== undefined && a.lng !== null && a.lng !== undefined ? `https://www.openstreetmap.org/?mlat=${a.lat}&mlon=${a.lng}#map=18/${a.lat}/${a.lng}` : null };
}
// Words people type: lower case, apostrophes and dots dropped ("Sharma's" → "sharmas"), split on spaces.
const fold = (v) => txt(v).toLowerCase().replace(/['’`.]/g, '').replace(/[^a-z0-9@]+/g, ' ').trim();
export function searchAccounts({ q = '', kind, status = 'active', limit = 200 } = {}) {
  if (!has()) return [];
  const rows = db().all(`SELECT * FROM trade_accounts WHERE (? IS NULL OR kind = ?) AND (? = 'all' OR status = ?)`, [kind || null, kind || null, status, status]);
  const words = fold(q).split(' ').filter(Boolean);
  const scored = [];
  for (const r of rows) {
    if (!words.length) { scored.push([0, r]); continue; }
    const name = fold(`${r.name} ${r.trading_name || ''}`);
    const hay = `${name} ${fold(r.town)} ${fold(r.number)} ${fold(r.aronium_code)} ${fold(r.contact)} ${txt(r.phone).replace(/\D/g, '')} ${fold(r.email)}`;
    const hayNoSpace = hay.replace(/ /g, '');
    if (!words.every((w) => hay.includes(w) || hayNoSpace.includes(w) || (/^\d+$/.test(w) && txt(r.phone).replace(/\D/g, '').includes(w)))) continue;
    const first = words[0];
    const score = name.startsWith(first) ? 3 : name.split(' ').some((x) => x.startsWith(first)) ? 2 : fold(r.number).startsWith(first) ? 1 : 0;
    scored.push([score, r]);
  }
  scored.sort((a, b) => b[0] - a[0] || displayName(a[1]).localeCompare(displayName(b[1])));
  return scored.slice(0, limit).map(([, r]) => decorate(r));
}

// ---------------------------------------------------------------- saving
// A new account: f.uid may be given (the form makes it first, so the agreement and photos can be added before saving).
export function saveAccount(user, f) {
  requirePerm(user, 'trade_manage');
  return asService(() => {
    need(has(), 'Trade accounts are not set up on this device yet.');
    const before = f.uid ? db().get('SELECT * FROM trade_accounts WHERE uid = ?', [f.uid]) : null;
    const kind = KINDS[f.kind] ? f.kind : (before ? before.kind : 'customer');
    const name = txt(f.name);
    need(name, 'Enter the business name.');
    const terms = TERMS[f.terms] ? f.terms : 'cash';
    const creditDays = terms === 'credit' ? numOrNull(f.creditDays) : null;
    const creditLimit = terms === 'credit' ? numOrNull(f.creditLimit) : null;
    if (terms === 'credit') {
      need(creditDays !== null && creditDays >= 1 && creditDays <= 365, 'Enter the credit terms in days (for example 30).');
      need(creditLimit === null || creditLimit >= 0, 'The credit limit cannot be below 0.');
    }
    const email = txt(f.email);
    need(!email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), 'That email address does not look right.');
    const lat = numOrNull(f.lat);
    const lng = numOrNull(f.lng);
    need((lat === null) === (lng === null), 'The map pin needs both latitude and longitude.');
    need(lat === null || (lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180), 'The map pin is not a real place.');
    const uid = before ? before.uid : (txt(f.uid) || uuid('TA'));
    // The credit agreement: needed for a credit account, unless someone allowed to overrides it (reason kept).
    const now = stamp();
    let noAgreementBy = before ? before.no_agreement_by : null;
    let noAgreementReason = before ? before.no_agreement_reason : null;
    if (terms === 'credit') {
      const signed = listDocuments(REF_TYPE, uid).some((d) => d.kind === 'agreement');
      if (signed) { noAgreementBy = null; noAgreementReason = null; }
      else if (!noAgreementBy || !before || before.terms !== 'credit') {
        need(f.overrideAgreement, 'A credit account needs the signed credit agreement. Add a photo or scan of it first.');
        need(canOverride(user), 'Only the owner, an admin or someone given the permission can open a credit account without the agreement.');
        need(txt(f.overrideReason), 'Give a reason for opening it without the agreement.');
        noAgreementBy = `${user ? user.name : 'System'} (${now.slice(0, 10)})`;
        noAgreementReason = txt(f.overrideReason);
      }
    } else { noAgreementBy = null; noAgreementReason = null; }
    const until = txt(f.agreementUntil);
    need(!until || /^\d{4}-\d{2}-\d{2}$/.test(until), 'The agreement end date is not a date.');
    const common = [name, txt(f.tradingName) || null, txt(f.contact) || null, txt(f.phone) || null, email || null, txt(f.address) || null, txt(f.town) || null, lat, lng,
      txt(f.directions) || null, txt(f.tin) || null, terms, creditDays, creditLimit, until || null, noAgreementBy, noAgreementReason, txt(f.notes) || null];
    if (before) {
      db().run(`UPDATE trade_accounts SET name = ?, trading_name = ?, contact = ?, phone = ?, email = ?, address = ?, town = ?, lat = ?, lng = ?, directions = ?, tin = ?, terms = ?,
        credit_days = ?, credit_limit = ?, agreement_until = ?, no_agreement_by = ?, no_agreement_reason = ?, notes = ?, aronium_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      common.concat([txt(f.aroniumCode) || before.aronium_code || before.number, now, deviceId(), uid]));
      audit({ user, action: `${KINDS[kind]} account changed: ${name} (${before.number})`, table: 'trade_accounts', recordUid: uid, before, after: f });
      if (kind === 'supplier') linkSupplier(user, uid);
      return uid;
    }
    const code = txt(f.locCode).toUpperCase();
    need(code, 'Choose the location code for the account number.');
    const allowed = codeOptions(kind).map((c) => c.value);
    need(allowed.includes(code), `The code ${code} is not in the list for ${kind === 'supplier' ? 'suppliers' : 'customers'} (Trade accounts › Settings).`);
    const n = nextNumber(kind, code);
    db().run(`INSERT INTO trade_accounts (name, trading_name, contact, phone, email, address, town, lat, lng, directions, tin, terms, credit_days, credit_limit, agreement_until,
      no_agreement_by, no_agreement_reason, notes, uid, kind, number, loc_code, num_year, num_seq, aronium_code, status, created_by, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    common.concat([uid, kind, n.number, n.code, n.year, n.seq, txt(f.aroniumCode) || n.number, 'active', user ? user.name : 'System', now, now, deviceId()]));
    audit({ user, action: `${KINDS[kind]} account opened: ${name} (${n.number})${noAgreementBy ? ` – credit WITHOUT the agreement: ${noAgreementReason}` : ''}`, table: 'trade_accounts', recordUid: uid });
    if (kind === 'supplier') linkSupplier(user, uid);
    return uid;
  });
}
// 1.0.0 build 24: a supplier account is joined to its supplier in Invoices & Payments, so invoices get their due
// dates from the account's terms and payments are made in the usual place. The supplier there is found by the link,
// else by the same name, else made. Whoever may set up suppliers (ap_setup) keeps the terms in step; anyone else
// only links an existing one (the terms are then set by the office).
export function linkSupplier(user, uid) {
  const a = db().get("SELECT * FROM trade_accounts WHERE uid = ? AND kind = 'supplier'", [uid]);
  if (!a) return null;
  const hasAp = !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'ap_suppliers'");
  if (!hasAp) return null;
  let ap = a.ap_supplier_uid ? getSupplier(a.ap_supplier_uid) : null;
  if (!ap) { const r = db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?)', [txt(a.trading_name) || a.name]) || db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?)', [a.name]); ap = r ? getSupplier(r.uid) : null; }
  let apUid = ap ? ap.uid : null;
  if (can(user, 'ap_setup')) {
    const saved = saveSupplier(user, {
      uid: ap ? ap.uid : undefined, name: ap ? ap.name : (txt(a.trading_name) || a.name), tin: a.tin || (ap && ap.tin) || '',
      vatRegistered: ap ? !!ap.vat_registered : true, onAccount: a.terms === 'credit', termsDays: a.terms === 'credit' ? (a.credit_days || 0) : 0,
      payMethod: ap ? ap.pay_method : 'cheque', contact: a.contact || (ap && ap.contact) || '', phone: a.phone || (ap && ap.phone) || '', email: a.email || (ap && ap.email) || '',
      bankName: ap ? ap.bank_name : '', bankAccount: ap ? ap.bank_account : '', category: ap ? ap.category : '', notes: ap ? ap.notes : `Supplier account ${a.number}`, active: a.status !== 'closed',
      ...(ap && ap.needs_setup ? { needsSetup: false } : {}),
    });
    apUid = saved && typeof saved === 'object' ? saved.uid : saved;
  }
  if (apUid && apUid !== a.ap_supplier_uid) db().run("UPDATE trade_accounts SET ap_supplier_uid = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [apUid, stamp(), deviceId(), uid]);
  return apUid;
}
// The trade account behind an Invoices & Payments supplier (for names, numbers and the Aronium code).
export function accountForSupplier(apUid) {
  if (!has() || !apUid) return null;
  const a = db().get("SELECT * FROM trade_accounts WHERE kind = 'supplier' AND ap_supplier_uid = ?", [apUid]);
  return a ? decorate(a) : null;
}
export function setAccountStatus(user, uid, status, reason) {
  requirePerm(user, 'trade_manage');
  return asService(() => {
    const a = getAccount(uid);
    need(a, 'Account not found.');
    need(['active', 'on_hold', 'closed'].includes(status), 'Unknown status.');
    if (status !== 'active') need(txt(reason), 'Give a reason.');
    db().run("UPDATE trade_accounts SET status = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [status, stamp(), deviceId(), uid]);
    audit({ user, action: `${a.display} (${a.number}): ${status === 'on_hold' ? 'put on hold' : status === 'closed' ? 'closed' : 'opened again'}${reason ? ` – ${txt(reason)}` : ''}`, table: 'trade_accounts', recordUid: uid });
  });
}

// ---------------------------------------------------------------- checks for Home
// Two devices without signal could give the same number: shown so the owner can sort it before it goes into Aronium.
export function duplicateNumbers() {
  if (!has()) return [];
  return db().all("SELECT number, COUNT(*) AS n FROM trade_accounts WHERE status != 'closed' GROUP BY number HAVING COUNT(*) > 1");
}
export function tradeAlertList() {
  if (!has()) return [];
  const out = [];
  for (const d of duplicateNumbers()) out.push({ id: `trade-dup-${d.number}`, level: 'urgent', text: `Account number ${d.number} was given twice`, sub: 'Two devices opened accounts at the same time without signal. Change one before it goes into Aronium.', nav: { screen: 'TradeList', params: { q: d.number } } });
  const today = dateStr();
  const soon = addDays(today, 30);
  for (const a of db().all("SELECT * FROM trade_accounts WHERE status = 'active' AND terms = 'credit'")) {
    const x = decorate(a);
    if (x.agreementState === 'missing' || x.agreementState === 'overridden') out.push({ id: `trade-noagr-${a.uid}`, level: 'warn', text: `${x.display}: credit account without a signed agreement`, sub: x.no_agreement_reason ? `Opened by ${x.no_agreement_by}: ${x.no_agreement_reason}` : 'Add the signed agreement.', nav: { screen: 'TradeAccount', params: { uid: a.uid } } });
    else if (x.agreementState === 'expired') out.push({ id: `trade-exp-${a.uid}`, level: 'warn', text: `${x.display}: credit agreement ended ${a.agreement_until}`, sub: 'Get a new signed agreement.', nav: { screen: 'TradeAccount', params: { uid: a.uid } } });
    else if (x.agreementState === 'expiring' && a.agreement_until <= soon) out.push({ id: `trade-soon-${a.uid}`, level: 'info', text: `${x.display}: credit agreement ends ${a.agreement_until}`, nav: { screen: 'TradeAccount', params: { uid: a.uid } } });
  }
  return out;
}
// ---------------------------------------------------------------- filing (1.0.0 build 24)
// How photos of supplier invoices and payments are filed in Drive: by shop (as before) or by the other party
// (month › Inbound › supplier › Invoices), the folder order, the folder names and the file name. Owner / admin.
export function recordsLayout() { return cleanLayout(getShared('records_layout', null)); }
export function saveRecordsLayout(user, l) {
  requirePerm(user, 'settings');
  return asService(() => {
    need(can(user, 'settings'), 'Only the owner or admin can change how papers are filed.');
    need(!l.name || String(l.name).includes('{date}'), 'The file name must start from the date: keep {date} in it.');
    const out = cleanLayout(l);
    need(out.order.indexOf('month') >= 0, 'Keep the month folder.');
    setShared('records_layout', out);
    audit({ user, action: `Filing changed: ${out.mode === 'party' ? `by supplier / customer (${out.order.join(' › ')})` : 'by shop'} – new papers only; papers already filed stay where they are`, table: 'shared_settings', recordUid: 'records_layout', after: out });
    return out;
  });
}
// What a supplier invoice would look like with these settings (for the screen).
export function filingExample(l) {
  const p = photoPlace({ refType: 'invoice', record: { invoice_date: dateStr(), supplier_name: 'Flour Mills', invoice_no: '5521', total: 1234 }, shop: { code: 'S1', name: 'Drasa Avenue' }, layout: cleanLayout(l) });
  if (!p) return '';
  const folders = p.folders || [p.monthFolder, p.shopFolder, p.typeFolder].filter(Boolean);
  return `Records › ${folders.join(' › ')} › ${p.fileName}`;
}
export { requireLogin };
