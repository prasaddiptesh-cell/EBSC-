// Warnings for Home: services / registration / inspections overdue or due soon, things out of use, faults,
// unusual fuel entries and (when switched on) vehicles without today's daily check.
import { canView, veAlertList } from './service.js';

export function alerts(user) {
  if (!canView(user)) return [];
  return veAlertList().map((a) => ({ ...a, area: 'vehicles' }));
}
