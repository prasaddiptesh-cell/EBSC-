// Vehicles & equipment (v3.5 B7): the register of vans, cars and equipment (the bakery's too), what is due, service &
// repair history, faults with out-of-use time, the fuel log (fuel entered once goes everywhere) and daily checks.
// Opened from Licences & permits › Vehicles & equipment, from the Bakery (Equipment) and from the Home search.
import * as S from './screens/VeScreens.js';
import { canView, canUse, canManage } from './service.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';
import { REPORTS } from './reports.js';

export default {
  id: 'vehicles',
  title: 'Vehicles & equipment',
  icon: '🚚',
  switchable: true,
  screens: {
    VeList: { component: S.VeListScreen, can: canView },
    VeItem: { component: S.VeItemScreen, can: canView },
    VeEdit: { component: S.VeEditScreen, can: canManage },
    VeDue: { component: S.VeDueScreen, can: canView },
    VeWork: { component: S.VeWorkScreen, can: canUse },
    VeWorkList: { component: S.VeWorkListScreen, can: canView },
    VeFault: { component: S.VeFaultScreen, can: canView },
    VeFaults: { component: S.VeFaultsScreen, can: canView },
    VeFuel: { component: S.VeFuelScreen, can: canUse },
    VeFuelLog: { component: S.VeFuelLogScreen, can: canView },
    VeCheck: { component: S.VeCheckScreen, can: canUse },
    VeTypes: { component: S.VeTypesScreen, can: canManage },
    VeSettings: { component: S.VeSettingsScreen, can: canManage },
  },
  menu: MENU,
  alerts,
  reports: REPORTS,
};
