// Vehicles & equipment menu (a sub-menu of Licences & permits; see src/services/menus.js).
import { veRules, canUse } from './service.js';

export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '🚚', title: 'Vehicles & equipment', note: 'The register: what is due, faults, fuel.', screen: 'VeList' },
    { id: 've-fuel', icon: '⛽', title: 'Enter fuel', note: 'Km, litres and amount – goes to the expenses, VAT and the money it came from.', screen: 'VeFuel', perm: canUse },
    { id: 've-fault', icon: '⚠️', title: 'Report a fault', note: 'Something broken or not working – and whether it is out of use.', screen: 'VeFault' },
    { id: 've-check', icon: '✅', title: 'Daily vehicle check', note: 'Tyres, lights, oil… (switched on in Settings).', screen: 'VeCheck', perm: () => { try { return veRules().dailyChecksOn; } catch (e) { return false; } } },
  ] },
  { section: 'Records', items: [
    { id: 've-due', icon: '📅', title: 'What is due', note: 'Services, registration, inspections – by date, km or hours.', screen: 'VeDue' },
    { id: 've-work', icon: '🔧', title: 'Service & repair history', note: 'Every service and repair with its cost and invoice.', screen: 'VeWorkList' },
    { id: 've-faults', icon: '🛠️', title: 'Faults & out-of-use time', screen: 'VeFaults' },
    { id: 've-fuellog', icon: '📒', title: 'Fuel log', note: 'Km per litre and anything unusual.', screen: 'VeFuelLog' },
  ] },
  { section: 'Reports', items: [
    { id: 've-reports', icon: '📊', title: 'Running-cost reports', screen: 'ReportsHub', params: { group: 'Vehicles & equipment' }, perm: 'reports' },
  ] },
  { section: 'Settings', items: [
    { id: 've-add', icon: '➕', title: 'Add a vehicle or equipment', screen: 'VeEdit' },
    { id: 've-types', icon: '🗂️', title: 'Types & inspection intervals', note: 'The kinds of equipment and how often each is serviced or inspected.', screen: 'VeTypes' },
    { id: 've-rules', icon: '⚙️', title: 'Vehicles & equipment settings', note: 'Reminders, fuel flags, daily checks on/off.', screen: 'VeSettings' },
  ] },
];
