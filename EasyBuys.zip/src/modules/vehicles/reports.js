// Vehicles & equipment reports (PDF / Excel / CSV / print / share through the shared report screen).
import { stamp, money } from '../../services/core.js';
import { runningCosts, listFuel, listWork, listFaults, allDue, WORK_KINDS } from './service.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const col = (key, title, align = 'left') => ({ key, title, align });
const R = 'right';
const G = 'Vehicles & equipment';
const base = (id, title, from, to, extra) => ({
  kind: id, title, fileName: `${title.replace(/[^A-Za-z0-9]+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`,
  subtitle: `Easy Buys Shopping Centre · ${from === to ? from : `${from} to ${to}`}`,
  info: [['Period', from === to ? from : `${from} to ${to}`], ['Generated', stamp()]], ...extra,
});
const hrs = (m) => (m ? `${Math.round(m / 6) / 10} h` : '');

export const REPORTS = [
  { id: 've_running_costs', group: G, icon: '🚚', title: 'Running costs per vehicle & equipment', desc: 'Fuel, services and repairs, km travelled, km per litre, cost per km, time out of use', perm: 'reports',
    build(from, to) {
      const c = runningCosts(from, to);
      const rows = c.rows.map((r) => ({ name: `${r.name}${r.rego ? ` (${r.rego})` : ''}`, area: r.areaLabel || '', km: r.km ? String(Math.round(r.km)) : '', litres: r.litres ? String(r.litres) : '',
        kmpl: r.kmPerL ? String(r.kmPerL) : '', fuel: $(r.fuelExVat), work: $(r.work), total: $(r.total), perKm: r.perKm ? $(r.perKm) : '', faults: String(r.faults || ''), out: r.hoursOut ? `${r.hoursOut} h` : '' }));
      return base('ve_running_costs', 'Vehicle and Equipment Running Costs', from, to, {
        summary: [{ label: 'Fuel (excl. VAT)', value: $(c.totals.fuelExVat) }, { label: 'Services & repairs', value: $(c.totals.work) }, { label: 'Total', value: $(c.totals.total) }, { label: 'Km travelled', value: String(Math.round(c.totals.km)) }],
        sections: [{ title: 'Per vehicle / equipment', columns: [col('name', 'Vehicle / equipment'), col('area', 'Shop / cost area'), col('km', 'Km', R), col('litres', 'Litres', R), col('kmpl', 'Km/L', R),
          col('fuel', 'Fuel ex VAT', R), col('work', 'Service & repair', R), col('total', 'Total', R), col('perKm', 'Per km', R), col('faults', 'Faults', R), col('out', 'Out of use', R)], rows }],
      });
    } },
  { id: 've_fuel_log', group: G, icon: '⛽', title: 'Fuel log', desc: 'Every fill-up: km, litres, amount, VAT, km per litre, paid from, flags', perm: 'reports',
    build(from, to) {
      const list = listFuel({ from, to }).slice().reverse();
      const rows = list.map((f) => ({ date: f.fill_date, vehicle: `${f.item_name}${f.rego ? ` ${f.rego}` : ''}`, km: String(Math.round(f.km)), litres: String(f.litres), amount: $(f.amount), vat: $(f.vat),
        kmpl: f.km_per_l ? String(f.km_per_l) : '', supplier: f.supplier || '', receipt: f.receipt_no || '', flags: f.flagList.map((x) => x.text).join(' '), _tone: f.flagList.length ? 'bad' : null }));
      return base('ve_fuel_log', 'Fuel Log', from, to, {
        summary: [{ label: 'Fill-ups', value: String(rows.length) }, { label: 'Litres', value: String(r2(list.reduce((s, f) => s + f.litres, 0))) }, { label: 'Amount', value: $(list.reduce((s, f) => s + f.amount, 0)) },
          { label: 'Input VAT', value: $(list.reduce((s, f) => s + f.vat, 0)) }, { label: 'Flagged', value: String(list.filter((f) => f.flagList.length).length) }],
        sections: [{ title: 'Fill-ups', columns: [col('date', 'Date'), col('vehicle', 'Vehicle'), col('km', 'Km', R), col('litres', 'Litres', R), col('amount', 'Amount', R), col('vat', 'VAT', R), col('kmpl', 'Km/L', R),
          col('supplier', 'Supplier'), col('receipt', 'Receipt no'), col('flags', 'Flags')], rows }],
      });
    } },
  { id: 've_service_history', group: G, icon: '🔧', title: 'Service & repair history', desc: 'Services, repairs and inspections with cost, supplier and invoice number', perm: 'reports',
    build(from, to) {
      const list = listWork({ from, to }).slice().reverse();
      const rows = list.map((w) => ({ date: w.work_date, item: `${w.item_name}${w.rego ? ` ${w.rego}` : ''}`, kind: WORK_KINDS[w.kind] || w.kind, note: w.note, km: w.km ? String(Math.round(w.km)) : w.hours ? `${w.hours} h` : '',
        supplier: w.supplier || '', inv: w.invoice_no || '', cost: w.cost === null ? '' : $(w.cost) }));
      return base('ve_service_history', 'Service and Repair History', from, to, {
        summary: [{ label: 'Jobs', value: String(rows.length) }, { label: 'Cost', value: $(list.reduce((s, w) => s + (w.cost || 0), 0)) }],
        sections: [{ title: 'Work done', columns: [col('date', 'Date'), col('item', 'Vehicle / equipment'), col('kind', 'Kind'), col('note', 'Work done'), col('km', 'Km / hours', R), col('supplier', 'Supplier'), col('inv', 'Invoice no'), col('cost', 'Cost', R)], rows }],
      });
    } },
  { id: 've_faults', group: G, icon: '🛠️', title: 'Faults & out-of-use time', desc: 'Every fault reported, how long it was out of use and when it was fixed; what is due now', perm: 'reports',
    build(from, to) {
      const list = listFaults({ from, to }).slice().reverse();
      const rows = list.map((f) => ({ date: f.reported_at.slice(0, 16), item: f.item_name, note: f.note, by: f.reported_by || '', out: f.out_of_use ? hrs(f.minutesOut) || '0 h' : 'no', fixed: f.resolved_at ? f.resolved_at.slice(0, 10) : 'OPEN', _tone: f.status === 'open' ? 'bad' : null }));
      const due = allDue({}).map((d) => ({ item: `${d.item.name}${d.item.rego ? ` ${d.item.rego}` : ''}`, what: d.name, state: d.state === 'overdue' ? 'OVERDUE' : 'Due soon', when: d.text, _tone: d.state === 'overdue' ? 'bad' : null }));
      return base('ve_faults', 'Faults and Out-of-use Time', from, to, {
        summary: [{ label: 'Faults', value: String(rows.length) }, { label: 'Still open', value: String(list.filter((f) => f.status === 'open').length) }, { label: 'Hours out of use', value: String(Math.round(list.reduce((s, f) => s + f.minutesOut, 0) / 6) / 10) }],
        sections: [{ title: 'Faults', columns: [col('date', 'Reported'), col('item', 'Vehicle / equipment'), col('note', 'Problem'), col('by', 'By'), col('out', 'Out of use', R), col('fixed', 'Fixed')], rows },
          { title: 'Due now', columns: [col('item', 'Vehicle / equipment'), col('what', 'What'), col('state', 'State'), col('when', 'When')], rows: due }],
      });
    } },
];
