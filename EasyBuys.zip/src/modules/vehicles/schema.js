// Vehicles & equipment (v3.5): the register, what is due (by date, km or hours), service & repair history, faults
// with out-of-use time, the fuel log and the daily checks. Shared with every device (the bakery's equipment too).
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
const S = "updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'";

export const VE_SQL = `
CREATE TABLE IF NOT EXISTS ve_items (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'equipment',
  name TEXT NOT NULL,
  type_key TEXT,
  rego TEXT,
  make_model TEXT,
  year INTEGER,
  serial TEXT,
  area TEXT,
  in_bakery INTEGER NOT NULL DEFAULT 0,
  meter TEXT NOT NULL DEFAULT 'none',
  km REAL,
  hours REAL,
  fuel_type TEXT,
  tank_l REAL,
  loan_uid TEXT,
  asset_uid TEXT,
  insurance_uid TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  legacy_id TEXT,
  created_by TEXT, created_at TEXT,
  ${S}
);
CREATE TABLE IF NOT EXISTS ve_due (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  name TEXT NOT NULL,
  every_days INTEGER,
  every_km REAL,
  every_hours REAL,
  last_date TEXT,
  last_km REAL,
  last_hours REAL,
  next_date TEXT,
  next_km REAL,
  next_hours REAL,
  alerted_for TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_ve_due_item ON ve_due(item_uid);
CREATE TABLE IF NOT EXISTS ve_work (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  kind TEXT NOT NULL,
  work_date TEXT NOT NULL,
  km REAL,
  hours REAL,
  note TEXT NOT NULL,
  cost REAL,
  invoice_uid TEXT,
  invoice_no TEXT,
  supplier TEXT,
  due_uid TEXT,
  fault_uid TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_ve_work_item ON ve_work(item_uid, work_date);
CREATE TABLE IF NOT EXISTS ve_faults (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  reported_at TEXT NOT NULL,
  note TEXT NOT NULL,
  reported_by TEXT, reported_by_uid TEXT,
  out_of_use INTEGER NOT NULL DEFAULT 0,
  out_from TEXT,
  back_at TEXT,
  resolved_at TEXT,
  resolved_by TEXT,
  work_uid TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_ve_faults_item ON ve_faults(item_uid, status);
CREATE TABLE IF NOT EXISTS ve_fuel (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  fill_date TEXT NOT NULL,
  km REAL NOT NULL,
  litres REAL NOT NULL,
  amount REAL NOT NULL,
  price_per_l REAL,
  full_tank INTEGER NOT NULL DEFAULT 1,
  tax_invoice INTEGER NOT NULL DEFAULT 1,
  vat REAL NOT NULL DEFAULT 0,
  via TEXT,
  area TEXT,
  supplier TEXT,
  supplier_tin TEXT,
  receipt_no TEXT,
  journal_uid TEXT,
  km_per_l REAL,
  flags TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_ve_fuel_item ON ve_fuel(item_uid, fill_date);
CREATE TABLE IF NOT EXISTS ve_checks (
  uid TEXT PRIMARY KEY,
  item_uid TEXT NOT NULL,
  check_date TEXT NOT NULL,
  answers TEXT,
  ok INTEGER NOT NULL DEFAULT 1,
  km REAL,
  note TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  ${S}
);
CREATE INDEX IF NOT EXISTS idx_ve_checks_item ON ve_checks(item_uid, check_date);
`;

export const VE_SYNC = {
  ve_items: SYNC('uid', 'Vehicles & equipment', ['uid', 'kind', 'name', 'type_key', 'rego', 'make_model', 'year', 'serial', 'area', 'in_bakery', 'meter', 'km', 'hours', 'fuel_type', 'tank_l',
    'loan_uid', 'asset_uid', 'insurance_uid', 'notes', 'status', 'legacy_id', 'created_by', 'created_at']),
  ve_due: SYNC('uid', 'Vehicles & equipment', ['uid', 'item_uid', 'name', 'every_days', 'every_km', 'every_hours', 'last_date', 'last_km', 'last_hours', 'next_date', 'next_km', 'next_hours', 'alerted_for', 'status', 'created_at']),
  ve_work: SYNC('uid', 'Vehicles & equipment', ['uid', 'item_uid', 'kind', 'work_date', 'km', 'hours', 'note', 'cost', 'invoice_uid', 'invoice_no', 'supplier', 'due_uid', 'fault_uid', 'by_name', 'by_uid', 'created_at', 'status', 'void_reason']),
  ve_faults: SYNC('uid', 'Vehicles & equipment', ['uid', 'item_uid', 'reported_at', 'note', 'reported_by', 'reported_by_uid', 'out_of_use', 'out_from', 'back_at', 'resolved_at', 'resolved_by', 'work_uid', 'status']),
  ve_fuel: SYNC('uid', 'Vehicles & equipment', ['uid', 'item_uid', 'fill_date', 'km', 'litres', 'amount', 'price_per_l', 'full_tank', 'tax_invoice', 'vat', 'via', 'area', 'supplier', 'supplier_tin', 'receipt_no',
    'journal_uid', 'km_per_l', 'flags', 'by_name', 'by_uid', 'created_at', 'status', 'void_reason']),
  ve_checks: SYNC('uid', 'Vehicles & equipment', ['uid', 'item_uid', 'check_date', 'answers', 'ok', 'km', 'note', 'by_name', 'by_uid', 'created_at']),
};
