// Vehicles & equipment screens: the register, one item (due items, faults, history, fuel, documents, links), adding and
// changing, fuel, faults, services & repairs, daily checks, types & intervals, settings.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, Select, Label, useApp, Choice, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, DateField, MoneyField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { DocumentsPanel } from '../../../ui/documents.js';
import { dateStr, money } from '../../../services/core.js';
import * as V from '../service.js';

const STATE = { overdue: ['OVERDUE', C.danger], due: ['Due soon', C.warn], ok: ['OK', C.success] };
const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);
const DOC_KINDS = { registration: 'Registration papers', insurance: 'Insurance', service: 'Service record', invoice: 'Invoice / receipt', manual: 'Manual / warranty', photo: 'Photo', other: 'Other' };
const itemOpts = (user, kind) => V.listItems({ kind, bakery: V.bakeryOnly(user) ? true : undefined }).map((i) => ({ value: i.uid, label: `${i.name}${i.rego ? ` (${i.rego})` : ''}` }));
const half = (el, key) => <View key={key} style={{ flexBasis: 160, flexGrow: 1 }}>{el}</View>;
const twoUp = (...els) => <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>{els.map((e, i) => half(e, i))}</View>;

// ------------------------------------------------------------------ the register
export function VeListScreen({ params = {} }) {
  const { nav, user } = useApp();
  const onlyBakery = params.bakery || V.bakeryOnly(user);
  const [kind, setKind] = useRemembered('kind', '');
  const [q, setQ] = useRemembered('q', '');
  const list = V.listItems({ kind: kind || undefined, q, bakery: onlyBakery ? true : undefined });
  const due = list.reduce((n, i) => n + i.due.filter((d) => d.state !== 'ok').length, 0);
  const out = list.filter((i) => i.outOfUse).length;
  const faults = list.reduce((n, i) => n + i.openFaults.length, 0);
  return (
    <Screen title={onlyBakery ? 'Bakery equipment' : 'Vehicles & equipment'} subtitle="What is due, faults, fuel and running costs">
      <Explain>Every vehicle and piece of equipment in one register{onlyBakery ? ' (here: the bakery’s ovens, mixers and other equipment)' : ''}. Each one shows what is due (service, registration, inspection – by date, km or hours), faults and how long it was out of use, the service & repair history with costs, and for vehicles the fuel log.</Explain>
      <Stats items={[{ label: 'Due / overdue', value: String(due), color: due ? C.warn : C.success }, { label: 'Out of use', value: String(out), color: out ? C.danger : C.success }, { label: 'Open faults', value: String(faults), color: faults ? C.warn : C.success }]} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="ve-report-fault" title="Report a fault" icon="⚠️" size="md" variant="danger" style={{ flexGrow: 1 }} onPress={() => nav.push('VeFault', { bakery: onlyBakery })} />
        {V.canUse(user) && !onlyBakery ? <Btn testID="ve-enter-fuel" title="Enter fuel" icon="⛽" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('VeFuel', {})} /> : null}
        {V.canManage(user) ? <Btn testID="ve-add" title="Add" icon="➕" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('VeEdit', { bakery: onlyBakery })} /> : null}
      </View>
      {!onlyBakery ? <Chips value={kind} onChange={setKind} testIDPrefix="ve-k" options={[{ value: '', label: 'All' }, { value: 'vehicle', label: 'Vehicles' }, { value: 'equipment', label: 'Equipment' }]} /> : null}
      <Field testID="ve-q" label="Search" value={q} onChangeText={setQ} placeholder="name, rego, serial" />
      {list.map((i) => (
        <ListItem key={i.uid} testID={`ve-${i.uid}`} title={`${i.kind === 'vehicle' ? '🚚' : '🔧'} ${i.name}${i.rego ? ` · ${i.rego}` : ''}`}
          sub={`${i.typeLabel || ''} · ${i.areaLabel || ''}${i.km !== null && i.km !== undefined ? ` · ${Math.round(i.km)} km` : ''}${i.hours ? ` · ${i.hours} h` : ''}${i.due.length ? ` · ${i.due.filter((d) => d.state !== 'ok').map((d) => `${d.name}: ${d.text}`).join(', ') || `next: ${i.due[0].text}`}` : ''}${i.openFaults.length ? ` · ⚠️ ${i.openFaults[0].note}` : ''}`}
          badge={i.outOfUse ? 'OUT OF USE' : i.openFaults.length ? 'FAULT' : STATE[i.dueState][0]} badgeColor={i.outOfUse ? C.danger : i.openFaults.length ? C.warn : STATE[i.dueState][1]}
          onPress={() => nav.push('VeItem', { uid: i.uid })} />
      ))}
      {!list.length ? <Hint>Nothing in the register yet.{V.canManage(user) ? ' Tap "Add" to put in the vans, cars, ovens, mixers, fridges and generator.' : ''}</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ one vehicle / piece of equipment
export function VeItemScreen({ params }) {
  const { user, nav, refresh } = useApp();
  const act = useAct();
  const [mode, setMode] = useState(null);
  const [d, setD] = useState({});
  const i = params.uid ? V.getItem(params.uid) : null;
  if (!i) return <Screen title="Vehicles & equipment"><Banner tone="warn" message="Not found." /></Screen>;
  const manage = V.canManage(user);
  const use = V.canUse(user);
  const links = V.linksFor(i);
  const work = V.listWork({ itemUid: i.uid }).slice(0, 20);
  const faults = V.listFaults({ itemUid: i.uid }).slice(0, 20);
  const fuel = i.kind === 'vehicle' ? V.listFuel({ itemUid: i.uid }).slice(0, 10) : [];
  const go = (fn, msg) => { if (act(fn, msg)) { setMode(null); setD({}); refresh(); } };
  return (
    <Screen title={i.name} subtitle={`${i.typeLabel || ''}${i.rego ? ` · ${i.rego}` : ''} · ${i.areaLabel || ''}`}>
      {i.status !== 'active' ? <Banner tone="info" message="No longer in use (kept for the history)." /> : null}
      {i.outOfUse ? <Banner testID="ve-out" tone="danger" title="Out of use" message={i.openFaults.filter((f) => f.out_of_use && !f.back_at).map((f) => f.note).join(' · ')} /> : null}
      <Card>
        {i.make_model ? <Row label="Make / model" value={`${i.make_model}${i.year ? ` (${i.year})` : ''}`} /> : null}
        {i.serial ? <Row label="Serial / chassis no" value={i.serial} /> : null}
        {i.meter === 'km' ? <Row label="Odometer" value={i.km === null ? '—' : `${Math.round(i.km)} km`} /> : null}
        {i.meter === 'hours' ? <Row label="Hour meter" value={i.hours === null ? '—' : `${i.hours} hours`} /> : null}
        {i.fuel_type ? <Row label="Fuel" value={`${i.fuel_type}${i.tank_l ? ` · tank ${i.tank_l} L` : ''}`} /> : null}
        <Row label="Costs go to" value={i.areaLabel || '—'} />
        {links.loan ? <Row label="Loan" value={links.loan.name} /> : null}
        {links.asset ? <Row label="Fixed asset" value={`${links.asset.name} · ${$(links.asset.cost)}`} /> : null}
        {links.insurance ? <Row label="Insurance / registration" value={`${links.insurance.name}${links.insurance.expiry_date ? ` · until ${links.insurance.expiry_date}` : ''}`} /> : null}
        {i.notes ? <Text style={{ color: C.sub, marginTop: 6 }}>{i.notes}</Text> : null}
      </Card>
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <Btn testID="vi-fault" title="Report a fault" icon="⚠️" size="md" variant="danger" style={{ flexGrow: 1 }} onPress={() => nav.push('VeFault', { uid: i.uid })} />
        {use ? <Btn testID="vi-work" title="Service / repair done" icon="🔧" size="md" variant="success" style={{ flexGrow: 1 }} onPress={() => nav.push('VeWork', { uid: i.uid })} /> : null}
        {use && i.kind === 'vehicle' ? <Btn testID="vi-fuel" title="Enter fuel" icon="⛽" size="md" variant="info" style={{ flexGrow: 1 }} onPress={() => nav.push('VeFuel', { uid: i.uid })} /> : null}
        {manage ? <Btn testID="vi-edit" title="Change details" icon="✏️" size="md" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push('VeEdit', { uid: i.uid })} /> : null}
      </View>
      <Section title="What is due" right={manage ? <Btn testID="vi-due-add" title="Add" size="sm" variant="secondary" onPress={() => { setMode('due'); setD({}); }} /> : null}>
        {i.due.map((x) => (
          <ListItem key={x.uid} testID={`vi-due-${x.uid}`} title={x.name} sub={`${x.text}${x.every_days ? ` · every ${x.every_days} days` : ''}${x.every_km ? ` · every ${x.every_km} km` : ''}${x.every_hours ? ` · every ${x.every_hours} h` : ''} · last ${x.last_date || '—'}`}
            badge={STATE[x.state][0]} badgeColor={STATE[x.state][1]} onPress={manage ? () => { setMode('due'); setD({ uid: x.uid, name: x.name, everyDays: x.every_days ? String(x.every_days) : '', everyKm: x.every_km ? String(x.every_km) : '', everyHours: x.every_hours ? String(x.every_hours) : '', lastDate: x.last_date || '', nextDate: '' }); } : undefined} />
        ))}
        {!i.due.length ? <Hint>Nothing set to be due.</Hint> : null}
      </Section>
      {mode === 'due' ? (
        <Card>
          <H>{d.uid ? 'Change' : 'Add'} a due item</H>
          <Field testID="vd-name" label="What (e.g. Service, Registration, Inspection)" value={d.name || ''} onChangeText={(v) => setD({ ...d, name: v })} />
          {twoUp(<Field testID="vd-days" label="Every … days" value={d.everyDays || ''} onChangeText={(v) => setD({ ...d, everyDays: v })} keyboardType="number-pad" />,
            i.meter === 'km' ? <Field testID="vd-km" label="Every … km" value={d.everyKm || ''} onChangeText={(v) => setD({ ...d, everyKm: v })} keyboardType="number-pad" />
              : i.meter === 'hours' ? <Field label="Every … hours" value={d.everyHours || ''} onChangeText={(v) => setD({ ...d, everyHours: v })} keyboardType="number-pad" /> : <View />)}
          {twoUp(<DateField farDays={false} label="Last done" value={d.lastDate || dateStr()} onChange={(v) => setD({ ...d, lastDate: v })} />,
            <DateField farDays={false} label="Or: next due on (optional)" value={d.nextDate || ''} onChange={(v) => setD({ ...d, nextDate: v })} />)}
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Btn testID="vd-save" title="Save" variant="success" size="md" style={{ flexGrow: 1 }} onPress={() => go(() => (d.uid ? V.saveDue(user, d.uid, { name: d.name, every_days: d.everyDays, every_km: d.everyKm, every_hours: d.everyHours, lastDate: d.lastDate, nextDate: d.nextDate })
              : V.addDue(user, i.uid, { name: d.name, every_days: d.everyDays, every_km: d.everyKm, every_hours: d.everyHours, lastDate: d.lastDate, lastKm: i.km, lastHours: i.hours, nextDate: d.nextDate })), 'Saved')} />
            {d.uid ? <Btn title="Stop reminding" variant="secondary" size="md" style={{ flexGrow: 1 }} onPress={() => go(() => V.stopDue(user, d.uid), 'Stopped')} /> : null}
          </View>
        </Card>
      ) : null}
      <Section title="Faults">
        {faults.map((f) => (
          <View key={f.uid} style={{ gap: 6 }}>
            <ListItem title={`${f.status === 'open' ? '⚠️' : '✔️'} ${f.note}`} sub={`${f.reported_at.slice(0, 16)} · ${f.reported_by || ''}${f.out_of_use ? ` · out of use ${Math.round(f.minutesOut / 6) / 10} h` : ''}${f.resolved_at ? ` · fixed ${f.resolved_at.slice(0, 10)}` : ''}`}
              badge={f.status === 'open' ? (f.out_of_use && !f.back_at ? 'OUT OF USE' : 'OPEN') : 'Fixed'} badgeColor={f.status === 'open' ? C.danger : C.success} />
            {f.status === 'open' && use ? (
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                {f.out_of_use && !f.back_at ? <Btn testID={`vf-back-${f.uid}`} title="Back in use" size="sm" variant="success" onPress={() => go(() => V.setOutOfUse(user, f.uid, false), 'Back in use')} />
                  : <Btn title="Out of use" size="sm" variant="danger" onPress={() => go(() => V.setOutOfUse(user, f.uid, true), 'Marked out of use')} />}
                <Btn title="Repaired" size="sm" variant="info" onPress={() => nav.push('VeWork', { uid: i.uid, faultUid: f.uid, kind: 'repair' })} />
                <ReasonButton title="Close without repair" size="sm" variant="secondary" prompt="What happened?" confirm="Close" onDo={(w) => go(() => V.closeFault(user, f.uid, w), 'Closed')} />
              </View>
            ) : null}
          </View>
        ))}
        {!faults.length ? <Hint>No faults reported.</Hint> : null}
      </Section>
      <Section title="Service & repair history">
        {work.map((w) => (
          <ListItem key={w.uid} title={`${V.WORK_KINDS[w.kind] || w.kind} · ${w.work_date}`} sub={`${w.note}${w.km ? ` · ${Math.round(w.km)} km` : ''}${w.supplier ? ` · ${w.supplier}` : ''}${w.invoice_no ? ` · invoice ${w.invoice_no}` : ''} · ${w.by_name || ''}`}
            right={w.cost === null ? '' : $(w.cost)} />
        ))}
        {!work.length ? <Hint>Nothing recorded yet.</Hint> : null}
      </Section>
      {i.kind === 'vehicle' ? (
        <Section title="Fuel (last 10)">
          {fuel.map((f) => (
            <ListItem key={f.uid} title={`${f.fill_date} · ${f.litres} L · ${Math.round(f.km)} km`} sub={`${f.km_per_l ? `${f.km_per_l} km/L` : 'km/L at the next full tank'}${f.flagList.length ? ` · ⚠️ ${f.flagList.map((x) => x.text).join(' ')}` : ''}`} right={$(f.amount)} tone={f.flagList.length ? 'warn' : undefined} />
          ))}
          {!fuel.length ? <Hint>No fuel entered yet.</Hint> : null}
        </Section>
      ) : null}
      <Section title="Documents">
        <DocumentsPanel refType="vehicle" refUid={i.uid} kinds={DOC_KINDS} canAdd={use} testID="vdoc" defaultKind={i.kind === 'vehicle' ? 'registration' : 'manual'} />
      </Section>
      {manage ? (i.status === 'active'
        ? <ReasonButton testID="vi-archive" title="No longer in use (sold / scrapped)" prompt="Why? (e.g. sold, scrapped)" confirm="Save" onDo={(w) => go(() => V.archiveItem(user, i.uid, w), 'Saved')} />
        : <Btn title="Put back in use" size="md" variant="secondary" onPress={() => go(() => V.restoreItem(user, i.uid), 'Done')} />) : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ add / change
export function VeEditScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const before = params.uid ? V.getItem(params.uid) : null;
  const types = V.listTypes();
  const [f, setF] = useState(() => (before ? {
    uid: before.uid, kind: before.kind, name: before.name, typeKey: before.type_key || '', rego: before.rego || '', makeModel: before.make_model || '', year: before.year ? String(before.year) : '', serial: before.serial || '',
    area: before.area || '', inBakery: !!before.in_bakery, meter: before.meter, km: before.km === null ? '' : String(before.km), hours: before.hours === null ? '' : String(before.hours), fuelType: before.fuel_type || '',
    tankL: before.tank_l ? String(before.tank_l) : '', loanUid: before.loan_uid || '', assetUid: before.asset_uid || '', insuranceUid: before.insurance_uid || '', notes: before.notes || '',
  } : { kind: params.bakery ? 'equipment' : 'vehicle', name: '', typeKey: params.bakery ? 'oven' : 'van', rego: '', makeModel: '', year: '', serial: '', area: params.bakery ? 'S1' : 'OFFICE', inBakery: !!params.bakery, meter: params.bakery ? 'none' : 'km', km: '', hours: '', fuelType: params.bakery ? '' : 'Diesel', tankL: '', loanUid: '', assetUid: '', insuranceUid: '', notes: '', lastServiceDate: dateStr() }));
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const pickType = (k) => { const t = types.find((x) => x.key === k); setF((o) => ({ ...o, typeKey: k, kind: t ? t.kind : o.kind, meter: t ? t.meter : o.meter, inBakery: t ? !!t.bakery : o.inBakery })); };
  const links = V.linkOptions();
  const t = types.find((x) => x.key === f.typeKey);
  const save = () => { const uid = act(() => V.saveItem(user, f), 'Saved'); if (uid) nav.replace('VeItem', { uid }); };
  return (
    <Screen title={before ? `Change ${before.name}` : 'Add a vehicle or equipment'} footer={<Btn testID="ve-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Label>Type</Label>
      <Choice value={f.typeKey} onChange={pickType} testIDPrefix="ve-type" options={types.map((x) => ({ value: x.key, label: x.label }))} />
      {!before && t && t.due.length ? <Hint>{`Added straight away: ${t.due.map((d) => `${d.name} every ${[d.every_days ? `${d.every_days} days` : '', d.every_km ? `${d.every_km} km` : '', d.every_hours ? `${d.every_hours} hours` : ''].filter(Boolean).join(' or ')}`).join('; ')}. Each can be changed afterwards.`}</Hint> : null}
      <Field testID="ve-name" label="Name" value={f.name} onChangeText={set('name')} placeholder={f.kind === 'vehicle' ? 'e.g. Delivery van' : 'e.g. Oven 2'} />
      {f.kind === 'vehicle' ? twoUp(<Field testID="ve-rego" label="Registration number (rego)" value={f.rego} onChangeText={set('rego')} placeholder="e.g. PB 113" />,
        <Field testID="ve-km" label="Odometer now (km)" value={f.km} onChangeText={set('km')} keyboardType="number-pad" />) : null}
      {f.kind !== 'vehicle' && f.meter === 'hours' ? <Field label="Hour meter now" value={f.hours} onChangeText={set('hours')} keyboardType="decimal-pad" /> : null}
      {twoUp(<Field label="Make / model" value={f.makeModel} onChangeText={set('makeModel')} />, <Field label="Year" value={f.year} onChangeText={set('year')} keyboardType="number-pad" />)}
      <Field label={f.kind === 'vehicle' ? 'Chassis / engine number' : 'Serial number'} value={f.serial} onChangeText={set('serial')} />
      {f.kind === 'vehicle' ? twoUp(<Choice label="Fuel" value={f.fuelType} onChange={set('fuelType')} options={['Diesel', 'Petrol', 'Other']} />, <Field label="Tank size (litres)" value={f.tankL} onChangeText={set('tankL')} keyboardType="number-pad" />) : null}
      <Select testID="ve-area" label="Costs go to (shop / cost area)" value={f.area} onChange={set('area')} options={V.areaOptions()} />
      <Label>Bakery equipment?</Label>
      <Chips value={f.inBakery ? 'y' : 'n'} onChange={(v) => set('inBakery')(v === 'y')} options={[{ value: 'n', label: 'No' }, { value: 'y', label: 'Yes – bakers report its faults' }]} />
      {!before ? <DateField farDays={false} label="Last serviced (for the first reminders)" value={f.lastServiceDate || dateStr()} onChange={set('lastServiceDate')} /> : null}
      <Section title="Links">
        <Select label="Loan (car loan / equipment loan)" value={f.loanUid} onChange={set('loanUid')} options={[{ value: '', label: 'None' }].concat(links.loans)} />
        <Select label="Fixed asset" value={f.assetUid} onChange={set('assetUid')} options={[{ value: '', label: 'None' }].concat(links.assets)} />
        <Select label="Insurance / registration (from Licences)" value={f.insuranceUid} onChange={set('insuranceUid')} options={[{ value: '', label: 'None' }].concat(links.insurance)} />
      </Section>
      <Field label="Notes" value={f.notes} onChangeText={set('notes')} multiline />
    </Screen>
  );
}

// ------------------------------------------------------------------ what is due
export function VeDueScreen() {
  const { nav, user } = useApp();
  const [all, setAll] = useRemembered('all', 'due');
  const list = V.allDue({ states: all === 'all' ? null : ['overdue', 'due'] }).filter((d) => !V.bakeryOnly(user) || d.item.in_bakery);
  return (
    <Screen title="What is due" subtitle="Services, registration, inspections">
      <Chips value={all} onChange={setAll} testIDPrefix="vdue" options={[{ value: 'due', label: 'Due & overdue' }, { value: 'all', label: 'Everything' }]} />
      {list.map((d) => (
        <ListItem key={d.uid} testID={`vdue-${d.uid}`} title={`${d.item.name}${d.item.rego ? ` (${d.item.rego})` : ''}: ${d.name}`} sub={d.text} badge={STATE[d.state][0]} badgeColor={STATE[d.state][1]} onPress={() => nav.push('VeItem', { uid: d.item.uid })} />
      ))}
      {!list.length ? <Hint>Nothing due. 👍</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ service / repair done
export function VeWorkScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [f, setF] = useState({ itemUid: params.uid || '', kind: params.kind || 'service', date: dateStr(), note: '', cost: '', km: '', hours: '', invoiceUid: '', invoiceNo: '', supplier: '', faultUid: params.faultUid || '', dueUid: '' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const i = f.itemUid ? V.getItem(f.itemUid) : null;
  const save = () => { if (act(() => V.recordWork(user, f), 'Saved')) nav.pop(); };
  return (
    <Screen title="Service or repair done" footer={<Btn testID="vw-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Select testID="vw-item" label="Vehicle / equipment" value={f.itemUid} onChange={set('itemUid')} options={itemOpts(user)} />
      <Choice label="What was done" value={f.kind} onChange={set('kind')} testIDPrefix="vw-kind" options={Object.entries(V.WORK_KINDS).map(([value, label]) => ({ value, label }))} />
      {i && i.due.length ? <Select label="This was the due item (it starts again from today)" value={f.dueUid} onChange={set('dueUid')} options={[{ value: '', label: 'Work it out (service → "Service")' }].concat(i.due.map((d) => ({ value: d.uid, label: d.name })))} /> : null}
      {i && i.openFaults.length ? <Select label="Fault fixed" value={f.faultUid} onChange={set('faultUid')} options={[{ value: '', label: f.kind === 'repair' ? 'All open faults' : 'None' }].concat(i.openFaults.map((x) => ({ value: x.uid, label: x.note })))} /> : null}
      <DateField farDays={false} label="Date" value={f.date} onChange={set('date')} />
      <Field testID="vw-note" label="Work done" value={f.note} onChangeText={set('note')} multiline placeholder="e.g. Oil and filter changed" />
      {i && i.meter === 'km' ? <Field testID="vw-km" label="Odometer (km)" value={f.km} onChangeText={set('km')} keyboardType="number-pad" /> : null}
      {i && i.meter === 'hours' ? <Field label="Hour meter" value={f.hours} onChangeText={set('hours')} keyboardType="decimal-pad" /> : null}
      <Select label="Supplier invoice (already entered in Invoices)" value={f.invoiceUid} onChange={set('invoiceUid')} options={[{ value: '', label: 'None / not entered yet' }].concat(V.invoiceOptions())} />
      {!f.invoiceUid ? twoUp(<MoneyField testID="vw-cost" label="Cost" value={f.cost} onChange={set('cost')} />, <Field label="Invoice number" value={f.invoiceNo} onChangeText={set('invoiceNo')} />) : null}
      {!f.invoiceUid ? <Field label="Done by (garage / technician)" value={f.supplier} onChangeText={set('supplier')} /> : null}
      <Hint>The cost is kept here for the running-cost reports. Enter the supplier's invoice in Invoices as usual so it is paid and goes into the books (pick it above to link it).</Hint>
    </Screen>
  );
}

export function VeWorkListScreen() {
  const { nav } = useApp();
  const list = V.listWork({}).slice(0, 200);
  return (
    <Screen title="Service & repair history">
      {list.map((w) => (
        <ListItem key={w.uid} title={`${w.item_name} · ${V.WORK_KINDS[w.kind] || w.kind} · ${w.work_date}`} sub={`${w.note}${w.supplier ? ` · ${w.supplier}` : ''}${w.invoice_no ? ` · invoice ${w.invoice_no}` : ''}`}
          right={w.cost === null ? '' : $(w.cost)} onPress={() => nav.push('VeItem', { uid: w.item_uid })} />
      ))}
      {!list.length ? <Hint>Nothing recorded yet.</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ faults
export function VeFaultScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const [f, setF] = useState({ itemUid: params.uid || '', note: '', outOfUse: false });
  const opts = V.listItems({ bakery: params.bakery || V.bakeryOnly(user) ? true : undefined }).map((i) => ({ value: i.uid, label: `${i.name}${i.rego ? ` (${i.rego})` : ''}` }));
  const save = () => { if (act(() => V.reportFault(user, f), 'Fault reported – the owner and managers are told')) nav.pop(); };
  return (
    <Screen title="Report a fault" footer={<Btn testID="vft-save" title="Report it" icon="⚠️" variant="danger" onPress={save} />}>
      <Select testID="vft-item" label="What is broken?" value={f.itemUid} onChange={(v) => setF({ ...f, itemUid: v })} options={opts} />
      <Field testID="vft-note" label="What is wrong?" value={f.note} onChangeText={(v) => setF({ ...f, note: v })} multiline placeholder="e.g. Oven 2 top deck not heating" />
      <Label>Can it still be used?</Label>
      <Chips value={f.outOfUse ? 'out' : 'ok'} onChange={(v) => setF({ ...f, outOfUse: v === 'out' })} testIDPrefix="vft-use" options={[{ value: 'ok', label: 'Yes, still in use' }, { value: 'out', label: 'No – out of use' }]} />
      <Hint>Out of use: the time until it is back in use is counted (running-cost reports).</Hint>
    </Screen>
  );
}
export function VeFaultsScreen() {
  const { nav, user } = useApp();
  const [st, setSt] = useRemembered('st', 'open');
  const list = V.listFaults({ status: st === 'all' ? undefined : 'open' }).filter((f) => !V.bakeryOnly(user) || f.in_bakery);
  return (
    <Screen title="Faults & out-of-use time">
      <Chips value={st} onChange={setSt} testIDPrefix="vfl" options={[{ value: 'open', label: 'Open' }, { value: 'all', label: 'All' }]} />
      {list.map((f) => (
        <ListItem key={f.uid} title={`${f.item_name}: ${f.note}`} sub={`${f.reported_at.slice(0, 16)} · ${f.reported_by || ''}${f.out_of_use ? ` · out of use ${Math.round(f.minutesOut / 6) / 10} h` : ''}`}
          badge={f.status === 'open' ? (f.out_of_use && !f.back_at ? 'OUT OF USE' : 'OPEN') : 'Fixed'} badgeColor={f.status === 'open' ? C.danger : C.success} onPress={() => nav.push('VeItem', { uid: f.item_uid })} />
      ))}
      {!list.length ? <Hint>No faults.</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ fuel
export function VeFuelScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const vehicles = itemOpts(user, 'vehicle');
  const [f, setF] = useState({ itemUid: params.uid || (vehicles.length === 1 ? vehicles[0].value : ''), date: dateStr(), km: '', litres: '', amount: '', fullTank: true, taxInvoice: true, vat: '', via: '', supplier: '', tin: '', receiptNo: '' });
  const set = (k) => (v) => setF((o) => ({ ...o, [k]: v }));
  const i = f.itemUid ? V.getItem(f.itemUid) : null;
  const [res, setRes] = useState(null);
  const save = () => { const r = act(() => V.saveFuel(user, f), 'Saved – expense, VAT and money all done'); if (r) { if (r.flags.length) setRes(r); else nav.pop(); } };
  if (res) {
    return (
      <Screen title="Fuel saved" footer={<Btn testID="vfu-done" title="OK" variant="success" onPress={() => nav.pop()} />}>
        <Banner tone="warn" title="Please check" message={res.flags.map((x) => x.text).join('\n')} />
        {res.kmPerL ? <Text style={{ fontSize: 18, color: C.text }}>{`${res.kmPerL} km per litre`}</Text> : null}
      </Screen>
    );
  }
  return (
    <Screen title="Enter fuel" subtitle="Entered once – goes to expenses, VAT and the money" footer={<Btn testID="vfu-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Select testID="vfu-item" label="Vehicle" value={f.itemUid} onChange={set('itemUid')} options={vehicles} />
      {i ? <Hint>{`Last odometer: ${i.km === null ? 'not known' : `${Math.round(i.km)} km`} · costs go to ${i.areaLabel}`}</Hint> : null}
      <DateField farDays={false} label="Date" value={f.date} onChange={set('date')} />
      {twoUp(<Field testID="vfu-km" label="Odometer (km)" value={f.km} onChangeText={set('km')} keyboardType="number-pad" />, <Field testID="vfu-litres" label="Litres" value={f.litres} onChangeText={set('litres')} keyboardType="decimal-pad" />)}
      <MoneyField testID="vfu-amount" label="Amount paid (incl. VAT)" value={f.amount} onChange={set('amount')} />
      <Label>Filled the tank full?</Label>
      <Chips value={f.fullTank ? 'y' : 'n'} onChange={(v) => set('fullTank')(v === 'y')} testIDPrefix="vfu-full" options={[{ value: 'y', label: 'Full tank' }, { value: 'n', label: 'Part fill' }]} />
      <Label>Receipt</Label>
      <Chips value={f.taxInvoice ? 'y' : 'n'} onChange={(v) => set('taxInvoice')(v === 'y')} testIDPrefix="vfu-tax" options={[{ value: 'y', label: 'VAT tax invoice (claim VAT)' }, { value: 'n', label: 'No tax invoice' }]} />
      {f.taxInvoice ? twoUp(<MoneyField label="VAT (blank = worked out)" value={f.vat} onChange={set('vat')} />, <Field label="Station TIN" value={f.tin} onChangeText={set('tin')} />) : null}
      <Select testID="vfu-via" label="Paid from" value={f.via} onChange={set('via')} options={V.paidFromOptions()} />
      {twoUp(<Field label="Station" value={f.supplier} onChangeText={set('supplier')} placeholder="e.g. Total Drasa" />, <Field label="Receipt number" value={f.receiptNo} onChangeText={set('receiptNo')} />)}
      <Hint>Paid by bank: it shows in the bank reconciliation. Paid from an M-PAiSA wallet: the wallet's balance goes down. A fuel card can be added later as its own money account.</Hint>
    </Screen>
  );
}
export function VeFuelLogScreen() {
  const { user, nav } = useApp();
  const act = useAct();
  const [flagged, setFlagged] = useRemembered('flagged', 'all');
  const list = V.listFuel({ flagged: flagged === 'flagged' }).slice(0, 200);
  return (
    <Screen title="Fuel log" subtitle="Km per litre and anything unusual">
      <Chips value={flagged} onChange={setFlagged} testIDPrefix="vfl-f" options={[{ value: 'all', label: 'All' }, { value: 'flagged', label: 'Flagged' }]} />
      {V.canUse(user) ? <Btn title="Enter fuel" icon="⛽" size="md" variant="info" onPress={() => nav.push('VeFuel', {})} /> : null}
      {list.map((f) => (
        <View key={f.uid} style={{ gap: 4 }}>
          <ListItem title={`${f.fill_date} · ${f.item_name}${f.rego ? ` ${f.rego}` : ''}`} sub={`${Math.round(f.km)} km · ${f.litres} L${f.km_per_l ? ` · ${f.km_per_l} km/L` : ''}${f.supplier ? ` · ${f.supplier}` : ''}${f.flagList.length ? ` · ⚠️ ${f.flagList.map((x) => x.text).join(' ')}` : ''}`}
            right={$(f.amount)} rightSub={f.vat ? `VAT ${$(f.vat)}` : 'no VAT'} tone={f.flagList.length ? 'warn' : undefined} />
          {V.canUse(user) ? <ReasonButton title="Cancel this entry" size="sm" variant="secondary" prompt="Why is it cancelled?" confirm="Cancel it" onDo={(w) => act(() => V.voidFuel(user, f.uid, w), 'Cancelled – the expense is reversed')} /> : null}
        </View>
      ))}
      {!list.length ? <Hint>No fuel entered.</Hint> : null}
    </Screen>
  );
}

// ------------------------------------------------------------------ daily checks (off until switched on)
export function VeCheckScreen({ params = {} }) {
  const { user, nav } = useApp();
  const act = useAct();
  const rules = V.veRules();
  const vehicles = itemOpts(user, 'vehicle');
  const [f, setF] = useState({ itemUid: params.uid || (vehicles.length === 1 ? vehicles[0].value : ''), answers: {}, km: '', note: '' });
  if (!rules.dailyChecksOn) return <Screen title="Daily vehicle check"><Banner tone="info" message="Daily checks are switched off. The owner or admin can switch them on in Vehicles & equipment settings." /></Screen>;
  const save = () => { if (act(() => V.saveCheck(user, f), 'Check saved')) nav.pop(); };
  return (
    <Screen title="Daily vehicle check" footer={<Btn testID="vc-save" title="Save" icon="💾" variant="success" onPress={save} />}>
      <Select label="Vehicle" value={f.itemUid} onChange={(v) => setF({ ...f, itemUid: v })} options={vehicles} />
      {rules.checkItems.map((k, n) => (
        <View key={k} style={{ gap: 4 }}>
          <Label>{k}</Label>
          <Chips value={f.answers[k] === undefined ? '' : f.answers[k] ? 'ok' : 'bad'} testIDPrefix={`vc-${n}`} onChange={(v) => setF({ ...f, answers: { ...f.answers, [k]: v === 'ok' } })} options={[{ value: 'ok', label: 'OK' }, { value: 'bad', label: 'Not OK' }]} />
        </View>
      ))}
      <Field label="Odometer (km)" value={f.km} onChangeText={(v) => setF({ ...f, km: v })} keyboardType="number-pad" />
      <Field label="What is wrong (if anything)" value={f.note} onChangeText={(v) => setF({ ...f, note: v })} multiline />
    </Screen>
  );
}

// ------------------------------------------------------------------ settings
export function VeTypesScreen() {
  const { user } = useApp();
  const act = useAct();
  const [list, setList] = useState(() => V.listTypes().map((t) => ({ ...t, due: t.due.map((d) => ({ ...d })) })));
  const upd = (n, k, v) => setList((l) => l.map((t, j) => (j === n ? { ...t, [k]: v } : t)));
  const updDue = (n, m, k, v) => setList((l) => l.map((t, j) => (j === n ? { ...t, due: t.due.map((d, x) => (x === m ? { ...d, [k]: v } : d)) } : t)));
  return (
    <Screen title="Types & inspection intervals" footer={<Btn testID="vt-save" title="Save" icon="💾" variant="success" onPress={() => act(() => V.saveTypes(user, list), 'Saved')} />}>
      <Hint>New vehicles and equipment of a type get its due items straight away (each can be changed on the item). Blank = not by that measure.</Hint>
      {list.map((t, n) => (
        <Card key={n}>
          <Field testID={`vt-label-${n}`} label="Type" value={t.label} onChangeText={(v) => upd(n, 'label', v)} />
          <Chips value={t.kind} onChange={(v) => upd(n, 'kind', v)} options={Object.entries(V.KINDS).map(([value, label]) => ({ value, label }))} />
          <Chips value={t.meter} onChange={(v) => upd(n, 'meter', v)} options={Object.entries(V.METERS).map(([value, label]) => ({ value, label }))} />
          {t.due.map((d, m) => (
            <View key={m} style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              {half(<Field label="Due item" value={d.name} onChangeText={(v) => updDue(n, m, 'name', v)} />, 'a')}
              {half(<Field label="Days" value={d.every_days ? String(d.every_days) : ''} onChangeText={(v) => updDue(n, m, 'every_days', v)} keyboardType="number-pad" />, 'b')}
              {t.meter === 'km' ? half(<Field label="Km" value={d.every_km ? String(d.every_km) : ''} onChangeText={(v) => updDue(n, m, 'every_km', v)} keyboardType="number-pad" />, 'c') : null}
              {t.meter === 'hours' ? half(<Field label="Hours" value={d.every_hours ? String(d.every_hours) : ''} onChangeText={(v) => updDue(n, m, 'every_hours', v)} keyboardType="number-pad" />, 'd') : null}
              <Btn title="✕" size="sm" variant="secondary" onPress={() => upd(n, 'due', t.due.filter((_, x) => x !== m))} />
            </View>
          ))}
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn title="Add due item" size="sm" variant="secondary" onPress={() => upd(n, 'due', t.due.concat([{ name: '', every_days: 365 }]))} />
            <Btn title="Remove type" size="sm" variant="secondary" onPress={() => setList((l) => l.filter((_, j) => j !== n))} />
          </View>
        </Card>
      ))}
      <Btn testID="vt-add" title="Add a type" icon="➕" size="md" variant="secondary" onPress={() => setList((l) => l.concat([{ key: '', label: '', kind: 'equipment', meter: 'none', due: [] }]))} />
    </Screen>
  );
}
export function VeSettingsScreen() {
  const { user } = useApp();
  const act = useAct();
  const [r, setR] = useState(() => { const x = V.veRules(); return { ...x, checkItems: x.checkItems.join('\n') }; });
  const set = (k) => (v) => setR((o) => ({ ...o, [k]: v }));
  return (
    <Screen title="Vehicles & equipment settings" footer={<Btn testID="vs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => V.saveVeRules(user, r), 'Saved')} />}>
      <Section title="Reminders">
        {twoUp(<Field label="Days before a date" value={String(r.remindDays)} onChangeText={set('remindDays')} keyboardType="number-pad" />,
          <Field label="Km before" value={String(r.remindKm)} onChangeText={set('remindKm')} keyboardType="number-pad" />,
          <Field label="Hours before" value={String(r.remindHours)} onChangeText={set('remindHours')} keyboardType="number-pad" />)}
      </Section>
      <Section title="Fuel flags">
        {twoUp(<Field label="Flag when km/L is worse than usual by … %" value={String(r.fuelFlagPct)} onChangeText={set('fuelFlagPct')} keyboardType="number-pad" />,
          <Field label="Flag a gap of more than … km between fill-ups" value={String(r.fuelGapKm)} onChangeText={set('fuelGapKm')} keyboardType="number-pad" />)}
      </Section>
      <Section title="Daily vehicle checks">
        <Chips value={r.dailyChecksOn ? 'on' : 'off'} onChange={(v) => set('dailyChecksOn')(v === 'on')} testIDPrefix="vs-checks" options={[{ value: 'off', label: 'Off' }, { value: 'on', label: 'On' }]} />
        <Field label="Check items (one per line)" value={r.checkItems} onChangeText={set('checkItems')} multiline />
      </Section>
    </Screen>
  );
}
