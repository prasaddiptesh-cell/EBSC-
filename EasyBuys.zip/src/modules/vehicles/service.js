// Vehicles & equipment: one register for the vans/cars and every piece of equipment (the bakery's ovens and mixers
// too). For each one: what is due (service, registration, inspection…) by date, km or hours, the service & repair
// history (costs linked to the supplier invoice), faults with the time it was out of use, the fuel log by km
// (km per litre and flags) and – when switched on – a daily check.
// Fuel entered once goes everywhere: the "Transport & fuel" expense for the vehicle's shop / cost area, input VAT when
// it is a tax invoice, paid from a shop's cash, an M-PAiSA wallet or the bank (then it shows in the bank reconciliation).
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, r3 } from '../../services/core.js';
import { can, needReason, requireSetup } from '../../services/access.js';
import { raiseAlert, addPhotos } from '../../services/stock.js';
import { listCostAreas, costAreaLabel, OFFICE } from '../../services/costAreas.js';
import { moneyOptions, moneyCode, vatIn } from '../accounting/full.js';
import { saveJournal, voidJournal, glMap } from '../accounting/service.js';
import { ensureDefaultWallets } from '../bank/wallets.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const numOrNull = (v) => (v === null || v === undefined || txt(v) === '' ? null : Number(v));
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const SYNCED = "updated_at = ?, updated_device = ?, sync_status = 'pending'";
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const who = (user) => ({ name: user ? user.name : 'System', uid: user ? user.uid || null : null });

// ---------------------------------------------------------------- who may do what
export const canView = (u) => can(u, 'vehicles_view') || can(u, 'vehicles_use') || can(u, 'vehicles_manage') || can(u, 'bakery');
// Bakery people without the vehicles permissions see only the bakery's equipment (where they report faults).
export const bakeryOnly = (u) => !!u && !(can(u, 'vehicles_view') || can(u, 'vehicles_use') || can(u, 'vehicles_manage')) && can(u, 'bakery');
export const canUse = (u) => can(u, 'vehicles_use') || can(u, 'vehicles_manage');
export const canManage = (u) => can(u, 'vehicles_manage');
const mustManage = (u) => need(!u || canManage(u), 'Only the owner or admin can change the register.');
const mustUse = (u) => need(!u || canUse(u), 'You are not allowed to record this.');

// ---------------------------------------------------------------- types (admin can change them) and rules
export const KINDS = { vehicle: 'Vehicle', equipment: 'Equipment' };
export const METERS = { km: 'Kilometres (odometer)', hours: 'Hours (hour meter)', none: 'No meter' };
export const WORK_KINDS = { service: 'Service', repair: 'Repair', inspection: 'Inspection / check' };
// Sensible defaults; every interval can be changed per type (Settings) and per item.
export const DEFAULT_TYPES = [
  { key: 'van', label: 'Van / truck', kind: 'vehicle', meter: 'km', due: [{ name: 'Service', every_km: 5000, every_days: 180 }, { name: 'Registration (LTA)', every_days: 365 }, { name: 'Tyres & wheel alignment', every_km: 20000 }] },
  { key: 'car', label: 'Car', kind: 'vehicle', meter: 'km', due: [{ name: 'Service', every_km: 5000, every_days: 180 }, { name: 'Registration (LTA)', every_days: 365 }] },
  { key: 'oven', label: 'Oven', kind: 'equipment', meter: 'none', bakery: true, due: [{ name: 'Service', every_days: 90 }] },
  { key: 'mixer', label: 'Mixer / dough machine', kind: 'equipment', meter: 'none', bakery: true, due: [{ name: 'Service', every_days: 90 }] },
  { key: 'bakery', label: 'Other bakery equipment', kind: 'equipment', meter: 'none', bakery: true, due: [{ name: 'Service', every_days: 90 }] },
  { key: 'fridge', label: 'Fridge / freezer / chiller', kind: 'equipment', meter: 'none', due: [{ name: 'Service (gas & coils)', every_days: 180 }] },
  { key: 'generator', label: 'Generator', kind: 'equipment', meter: 'hours', due: [{ name: 'Service', every_hours: 250, every_days: 365 }] },
  { key: 'aircon', label: 'Air conditioner', kind: 'equipment', meter: 'none', due: [{ name: 'Clean & service', every_days: 180 }] },
  { key: 'scales', label: 'Scales', kind: 'equipment', meter: 'none', due: [{ name: 'Verification (Trade Measurement)', every_days: 365 }] },
  { key: 'extinguisher', label: 'Fire extinguisher', kind: 'equipment', meter: 'none', due: [{ name: 'Inspection', every_days: 180 }] },
  { key: 'pos', label: 'Till / computer / printer', kind: 'equipment', meter: 'none', due: [] },
  { key: 'other', label: 'Other', kind: 'equipment', meter: 'none', due: [] },
];
export function listTypes() {
  const saved = getShared('ve_types', null);
  return Array.isArray(saved) && saved.length ? saved : DEFAULT_TYPES;
}
export function typeOf(key) { return listTypes().find((t) => t.key === key) || null; }
export function saveTypes(user, list) {
  need(!user || can(user, 'vehicles_manage'), 'Only the owner or admin can change the types.');
  const seen = new Set();
  const clean = (list || []).map((t) => {
    const label = txt(t.label);
    need(label, 'Every type needs a name.');
    const key = txt(t.key) || label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30) || uuid('T');
    need(!seen.has(key), `"${label}" is listed twice.`);
    seen.add(key);
    return { key, label, kind: KINDS[t.kind] ? t.kind : 'equipment', meter: METERS[t.meter] ? t.meter : 'none', bakery: !!t.bakery,
      due: (t.due || []).filter((d) => txt(d.name)).map((d) => cleanInterval(d)) };
  });
  need(clean.length, 'Keep at least one type.');
  const before = listTypes();
  setShared('ve_types', clean);
  audit({ user, action: 'Changed the vehicle & equipment types', table: 'shared_settings', recordUid: 've_types', before, after: clean });
  return clean;
}
function cleanInterval(d) {
  const pos = (v, label, max) => {
    const n = numOrNull(v);
    if (n === null) return null;
    need(Number.isFinite(n) && n > 0 && n <= max, `${label} must be between 1 and ${max}.`);
    return Math.round(n);
  };
  return { name: txt(d.name), every_days: pos(d.every_days, 'Days', 3650), every_km: pos(d.every_km, 'Km', 500000), every_hours: pos(d.every_hours, 'Hours', 100000) };
}

export const RULE_DEFAULTS = {
  remindDays: 14, remindKm: 500, remindHours: 25,
  dailyChecksOn: false,
  checkItems: ['Tyres (pressure & damage)', 'Lights & indicators', 'Engine oil', 'Water / coolant', 'Brakes', 'Body damage', 'Clean inside'],
  fuelFlagPct: 25, fuelGapKm: 1500,
};
export function veRules() { return { ...RULE_DEFAULTS, ...(getShared('ve_rules', {}) || {}) }; }
export function saveVeRules(user, r) {
  requireSetup(user, 'vehicles_manage');
  need(!user || can(user, 'vehicles_manage'), 'Only the owner or admin can change these rules.');
  const c = { ...veRules(), ...r };
  const int = (v, lo, hi, label) => { const n = Math.round(Number(v)); need(Number.isFinite(n) && n >= lo && n <= hi, `${label}: ${lo} to ${hi}.`); return n; };
  c.remindDays = int(c.remindDays, 0, 365, 'Remind days before');
  c.remindKm = int(c.remindKm, 0, 20000, 'Remind km before');
  c.remindHours = int(c.remindHours, 0, 2000, 'Remind hours before');
  c.fuelFlagPct = int(c.fuelFlagPct, 5, 90, 'Fuel flag %');
  c.fuelGapKm = int(c.fuelGapKm, 100, 20000, 'Long gap km');
  c.dailyChecksOn = !!c.dailyChecksOn;
  c.checkItems = (Array.isArray(c.checkItems) ? c.checkItems : String(c.checkItems || '').split('\n')).map(txt).filter(Boolean);
  need(c.checkItems.length, 'Keep at least one daily check item.');
  const before = veRules();
  setShared('ve_rules', c);
  audit({ user, action: 'Changed the vehicle & equipment rules', table: 'shared_settings', recordUid: 've_rules', before, after: c });
  return c;
}

// ---------------------------------------------------------------- the old bakery equipment list moves in here (once)
let migrated = null;
export function __resetMigration() { migrated = null; }
export function ensureVe() {
  if (migrated === db()) return;
  migrated = db();
  if (!has('ve_items') || !has('equipment')) return;
  const dev = deviceId();
  const old = db().all('SELECT * FROM equipment ORDER BY id');
  if (!old.length) return;
  const done = new Set(db().all('SELECT legacy_id FROM ve_items WHERE legacy_id IS NOT NULL').map((r) => r.legacy_id));
  const users = Object.fromEntries(db().all('SELECT id, uid, name FROM users').map((u) => [u.id, u]));
  db().transaction(() => {
    for (const e of old) {
      const lid = `${dev}:${e.id}`;
      if (done.has(lid)) continue;
      const uid = `VE-${dev}-${e.id}`;
      const now = stamp();
      db().run(`INSERT OR IGNORE INTO ve_items (uid, kind, name, type_key, area, in_bakery, meter, status, legacy_id, created_by, created_at, updated_at, updated_device)
        VALUES (?, 'equipment', ?, 'bakery', 'S1', 1, 'none', ?, ?, 'Bakery app', ?, ?, ?)`, [uid, e.name, e.active ? 'active' : 'archived', lid, e.created_at || now, now, dev]);
      if (e.service_days) {
        const last = (e.last_service_at || e.created_at || now).slice(0, 10);
        db().run(`INSERT OR IGNORE INTO ve_due (uid, item_uid, name, every_days, last_date, next_date, alerted_for, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [`${uid}-SVC`, uid, 'Service', e.service_days, last, addDays(last, e.service_days), e.service_alerted_at ? addDays(last, e.service_days) : null, now, now, dev]);
      }
      const logs = has('equipment_log') ? db().all('SELECT * FROM equipment_log WHERE equipment_id = ? ORDER BY id', [e.id]) : [];
      for (const l of logs) {
        const u = users[l.user_id] || {}; const r = users[l.resolved_by] || {};
        if (l.type === 'fault') {
          db().run(`INSERT OR IGNORE INTO ve_faults (uid, item_uid, reported_at, note, reported_by, reported_by_uid, out_of_use, resolved_at, resolved_by, status, updated_at, updated_device)
            VALUES (?,?,?,?,?,?,0,?,?,?,?,?)`, [`${uid}-F${l.id}`, uid, l.at, l.note, u.name || null, u.uid || null, l.resolved_at || null, r.name || null, l.resolved_at ? 'fixed' : 'open', now, dev]);
        } else {
          db().run(`INSERT OR IGNORE INTO ve_work (uid, item_uid, kind, work_date, note, cost, fault_uid, by_name, by_uid, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
            [`${uid}-W${l.id}`, uid, l.type, l.at.slice(0, 10), l.note, l.cost, l.fault_id ? `${uid}-F${l.fault_id}` : null, u.name || null, u.uid || null, l.at, now, dev]);
        }
      }
    }
  });
}

// ---------------------------------------------------------------- the register
export function areaOptions() { return listCostAreas().map((a) => ({ value: a.code, label: a.name })); }
export function getItem(uid) {
  ensureVe();
  const i = db().get('SELECT * FROM ve_items WHERE uid = ?', [uid]);
  return i ? decorate(i) : null;
}
function decorate(i, today = dateStr(), rules = veRules()) {
  const due = dueFor(i, today, rules);
  const faults = db().all("SELECT * FROM ve_faults WHERE item_uid = ? AND status = 'open' ORDER BY reported_at DESC", [i.uid]);
  const t = typeOf(i.type_key);
  const worst = due.some((d) => d.state === 'overdue') ? 'overdue' : due.some((d) => d.state === 'due') ? 'due' : 'ok';
  return { ...i, typeLabel: t ? t.label : (i.type_key || KINDS[i.kind]), areaLabel: costAreaLabel(i.area), due, openFaults: faults,
    outOfUse: faults.some((f) => f.out_of_use && !f.back_at), dueState: worst };
}
export function listItems({ kind, area, q, bakery, includeArchived = false, today = dateStr() } = {}) {
  ensureVe();
  const rules = veRules();
  return db().all(`SELECT * FROM ve_items ${includeArchived ? '' : "WHERE status = 'active'"} ORDER BY kind DESC, name`)
    .filter((i) => (!kind || i.kind === kind) && (!area || i.area === area) && (bakery === undefined || !!i.in_bakery === !!bakery)
      && (!txt(q) || `${i.name} ${i.rego || ''} ${i.serial || ''} ${i.make_model || ''}`.toLowerCase().includes(txt(q).toLowerCase())))
    .map((i) => decorate(i, today, rules));
}
export function saveItem(user, f) {
  mustManage(user);
  ensureVe();
  const name = txt(f.name);
  need(KINDS[f.kind], 'Vehicle or equipment?');
  need(name, f.kind === 'vehicle' ? 'Name the vehicle, e.g. "Delivery van".' : 'Name it, e.g. "Oven 2".');
  if (f.kind === 'vehicle') need(txt(f.rego), 'Enter the registration number (rego), e.g. "PB 113".');
  const meter = f.kind === 'vehicle' ? 'km' : (METERS[f.meter] ? f.meter : 'none');
  const km = numOrNull(f.km); const hours = numOrNull(f.hours);
  need(km === null || (Number.isFinite(km) && km >= 0), 'The km reading cannot be negative.');
  need(hours === null || (Number.isFinite(hours) && hours >= 0), 'The hours reading cannot be negative.');
  const tank = numOrNull(f.tankL);
  need(tank === null || (tank > 0 && tank < 1000), 'Tank size: litres between 1 and 999.');
  const year = numOrNull(f.year);
  need(year === null || (year > 1950 && year < 2100), 'Year: e.g. 2019.');
  const area = txt(f.area) || OFFICE;
  const dupe = txt(f.rego) ? db().get("SELECT uid FROM ve_items WHERE upper(replace(rego,' ','')) = upper(replace(?,' ','')) AND uid != ? AND status = 'active'", [txt(f.rego), f.uid || '']) : null;
  need(!dupe, `${txt(f.rego)} is already in the register.`);
  const t = typeOf(f.typeKey);
  const inBakery = f.inBakery === undefined ? !!(t && t.bakery) : !!f.inBakery;
  const now = stamp(); const dev = deviceId();
  const vals = [f.kind, name, txt(f.typeKey) || null, txt(f.rego).toUpperCase() || null, txt(f.makeModel) || null, year, txt(f.serial) || null, area, inBakery ? 1 : 0, meter,
    km, hours, txt(f.fuelType) || null, tank, txt(f.loanUid) || null, txt(f.assetUid) || null, txt(f.insuranceUid) || null, txt(f.notes) || null];
  if (f.uid) {
    const before = db().get('SELECT * FROM ve_items WHERE uid = ?', [f.uid]);
    need(before, 'Not found.');
    db().run(`UPDATE ve_items SET kind=?, name=?, type_key=?, rego=?, make_model=?, year=?, serial=?, area=?, in_bakery=?, meter=?, km=?, hours=?, fuel_type=?, tank_l=?, loan_uid=?, asset_uid=?, insurance_uid=?, notes=?, ${SYNCED} WHERE uid = ?`,
      [...vals, now, dev, f.uid]);
    audit({ user, action: `Changed ${name}`, table: 've_items', recordUid: f.uid, before });
    return f.uid;
  }
  const uid = uuid('VE');
  db().transaction(() => {
    db().run(`INSERT INTO ve_items (kind, name, type_key, rego, make_model, year, serial, area, in_bakery, meter, km, hours, fuel_type, tank_l, loan_uid, asset_uid, insurance_uid, notes, uid, status, created_by, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'active', ?,?,?,?)`, [...vals, uid, who(user).name, now, now, dev]);
    // The type's usual due items (service, registration, inspection…) are added straight away; each can be changed.
    const base = txt(f.lastServiceDate) || dateStr();
    for (const d of (f.dueItems || (t ? t.due : []))) {
      addDue(null, uid, { ...d, lastDate: base, lastKm: km, lastHours: hours });
    }
  });
  audit({ user, action: `Added ${KINDS[f.kind].toLowerCase()} ${name}`, table: 've_items', recordUid: uid });
  return uid;
}
export function archiveItem(user, uid, reason) {
  mustManage(user);
  const i = getItem(uid);
  need(i && i.status === 'active', 'Not found.');
  needReason(user, reason, 'Say why (e.g. "sold", "scrapped").');
  db().run(`UPDATE ve_items SET status = 'archived', notes = ?, ${SYNCED} WHERE uid = ?`, [`${i.notes || ''}${i.notes ? '\n' : ''}No longer in use: ${txt(reason) || 'no reason given'}`, stamp(), deviceId(), uid]);
  audit({ user, action: `No longer in use: ${i.name}`, table: 've_items', recordUid: uid, reason: txt(reason) });
}
export function restoreItem(user, uid) {
  mustManage(user);
  db().run(`UPDATE ve_items SET status = 'active', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: 'Put back in use', table: 've_items', recordUid: uid });
}
// A new reading (km or hours) – also from fuel, services and daily checks. Never goes backwards.
function bumpMeter(uid, { km, hours }) {
  const i = db().get('SELECT km, hours FROM ve_items WHERE uid = ?', [uid]);
  if (!i) return;
  const k = numOrNull(km); const h = numOrNull(hours);
  if (k !== null && (i.km === null || k > i.km)) db().run(`UPDATE ve_items SET km = ?, ${SYNCED} WHERE uid = ?`, [k, stamp(), deviceId(), uid]);
  if (h !== null && (i.hours === null || h > i.hours)) db().run(`UPDATE ve_items SET hours = ?, ${SYNCED} WHERE uid = ?`, [h, stamp(), deviceId(), uid]);
}

// What the loan, fixed asset and insurance links point to (shown on the item; each opens its own screen).
export function linkOptions() {
  const loans = has('ap_recurring') ? db().all("SELECT uid, name FROM ap_recurring WHERE kind = 'loan' ORDER BY active DESC, name").map((l) => ({ value: l.uid, label: l.name })) : [];
  const assets = has('fixed_assets') ? db().all("SELECT uid, name FROM fixed_assets WHERE status <> 'void' ORDER BY name").map((a) => ({ value: a.uid, label: a.name })) : [];
  const ins = has('licences') ? db().all("SELECT uid, name, licence_no FROM licences WHERE status <> 'cancelled' AND category IN ('insurance','vehicle') ORDER BY name").map((l) => ({ value: l.uid, label: `${l.name}${l.licence_no ? ` (${l.licence_no})` : ''}` })) : [];
  return { loans, assets, insurance: ins };
}
export function linksFor(i) {
  const out = {};
  if (i.loan_uid && has('ap_recurring')) out.loan = db().get('SELECT uid, name, amount, next_date FROM ap_recurring WHERE uid = ?', [i.loan_uid]);
  if (i.asset_uid && has('fixed_assets')) out.asset = db().get('SELECT uid, name, cost, purchase_date, status FROM fixed_assets WHERE uid = ?', [i.asset_uid]);
  if (i.insurance_uid && has('licences')) out.insurance = db().get('SELECT uid, name, licence_no, expiry_date, status FROM licences WHERE uid = ?', [i.insurance_uid]);
  return out;
}

// ---------------------------------------------------------------- due items (by date, km or hours)
function nextOf(d) {
  const nd = d.every_days && d.last_date ? addDays(d.last_date, d.every_days) : null;
  const nk = d.every_km && d.last_km !== null && d.last_km !== undefined ? d.last_km + d.every_km : null;
  const nh = d.every_hours && d.last_hours !== null && d.last_hours !== undefined ? d.last_hours + d.every_hours : null;
  return { next_date: nd, next_km: nk, next_hours: nh };
}
export function addDue(user, itemUid, d) {
  if (user) mustManage(user);
  const c = cleanInterval(d);
  need(c.name, 'Name it, e.g. "Service".');
  const nextDate = txt(d.nextDate);
  need(!nextDate || DATE.test(nextDate), 'Next due: YYYY-MM-DD.');
  need(c.every_days || c.every_km || c.every_hours || nextDate, 'Enter how often (days, km or hours) or the next due date.');
  const last = { last_date: txt(d.lastDate) || dateStr(), last_km: numOrNull(d.lastKm), last_hours: numOrNull(d.lastHours) };
  const n = nextOf({ ...c, ...last });
  const uid = txt(d.uid) || uuid('VD');
  const now = stamp();
  db().run(`INSERT INTO ve_due (uid, item_uid, name, every_days, every_km, every_hours, last_date, last_km, last_hours, next_date, next_km, next_hours, created_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [uid, itemUid, c.name, c.every_days, c.every_km, c.every_hours, last.last_date, last.last_km, last.last_hours, nextDate || n.next_date, n.next_km, n.next_hours, now, now, deviceId()]);
  if (user) audit({ user, action: `Due item added: ${c.name}`, table: 've_due', recordUid: uid });
  return uid;
}
export function saveDue(user, uid, d) {
  mustManage(user);
  const before = db().get('SELECT * FROM ve_due WHERE uid = ?', [uid]);
  need(before, 'Not found.');
  const c = cleanInterval({ ...before, ...d });
  need(c.name, 'Name it.');
  const nextDate = txt(d.nextDate);
  need(!nextDate || DATE.test(nextDate), 'Next due: YYYY-MM-DD.');
  const merged = { ...before, ...c, last_date: txt(d.lastDate) || before.last_date, last_km: d.lastKm === undefined ? before.last_km : numOrNull(d.lastKm), last_hours: d.lastHours === undefined ? before.last_hours : numOrNull(d.lastHours) };
  const n = nextOf(merged);
  db().run(`UPDATE ve_due SET name=?, every_days=?, every_km=?, every_hours=?, last_date=?, last_km=?, last_hours=?, next_date=?, next_km=?, next_hours=?, alerted_for = NULL, ${SYNCED} WHERE uid = ?`,
    [c.name, c.every_days, c.every_km, c.every_hours, merged.last_date, merged.last_km, merged.last_hours, nextDate || n.next_date, n.next_km, n.next_hours, stamp(), deviceId(), uid]);
  audit({ user, action: `Due item changed: ${c.name}`, table: 've_due', recordUid: uid, before });
}
export function stopDue(user, uid) {
  mustManage(user);
  db().run(`UPDATE ve_due SET status = 'stopped', ${SYNCED} WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: 'Due item stopped', table: 've_due', recordUid: uid });
}
// 'overdue' | 'due' (inside the reminder window) | 'ok', with the plain-words reason.
export function dueState(d, item, today = dateStr(), rules = veRules()) {
  const parts = [];
  let state = 'ok';
  const bump = (s) => { if (s === 'overdue' || (s === 'due' && state === 'ok')) state = s; };
  if (d.next_date) {
    if (d.next_date < today) { bump('overdue'); parts.push(`was due ${d.next_date}`); } else if (d.next_date <= addDays(today, rules.remindDays)) { bump('due'); parts.push(`due ${d.next_date}`); } else parts.push(`next ${d.next_date}`);
  }
  if (d.next_km !== null && d.next_km !== undefined) {
    const left = d.next_km - (item.km || 0);
    if (left <= 0) { bump('overdue'); parts.push(`${Math.round(-left)} km over`); } else if (left <= rules.remindKm) { bump('due'); parts.push(`${Math.round(left)} km left`); } else parts.push(`at ${Math.round(d.next_km)} km`);
  }
  if (d.next_hours !== null && d.next_hours !== undefined) {
    const left = d.next_hours - (item.hours || 0);
    if (left <= 0) { bump('overdue'); parts.push(`${Math.round(-left)} hours over`); } else if (left <= rules.remindHours) { bump('due'); parts.push(`${Math.round(left)} hours left`); } else parts.push(`at ${Math.round(d.next_hours)} hours`);
  }
  return { state, text: parts.join(' · ') || 'no due date' };
}
function dueFor(item, today, rules) {
  return db().all("SELECT * FROM ve_due WHERE item_uid = ? AND status = 'active' ORDER BY next_date IS NULL, next_date, name", [item.uid]).map((d) => ({ ...d, ...dueState(d, item, today, rules) }));
}
export function allDue({ states = ['overdue', 'due'], today = dateStr() } = {}) {
  const out = [];
  for (const i of listItems({ today })) for (const d of i.due) if (!states || states.includes(d.state)) out.push({ ...d, item: i });
  return out.sort((a, b) => (a.state === b.state ? String(a.next_date || '9').localeCompare(String(b.next_date || '9')) : a.state === 'overdue' ? -1 : 1));
}

// ---------------------------------------------------------------- service & repair history
export function recordWork(user, f) {
  mustUse(user);
  const i = getItem(f.itemUid);
  need(i, 'Choose the vehicle or equipment.');
  need(WORK_KINDS[f.kind], 'Service, repair or inspection?');
  const note = txt(f.note);
  need(note, 'Describe the work done.');
  const date = txt(f.date) || dateStr();
  need(DATE.test(date), 'Enter the date.');
  need(date <= dateStr(), 'The date cannot be in the future.');
  let cost = numOrNull(f.cost);
  need(cost === null || (Number.isFinite(cost) && cost >= 0), 'Cost cannot be negative.');
  const km = numOrNull(f.km); const hours = numOrNull(f.hours);
  if (km !== null && i.km !== null) need(km >= i.km - 0.5 || date < dateStr(), `The km reading is lower than the last one (${Math.round(i.km)} km).`);
  let inv = null;
  if (txt(f.invoiceUid)) {
    inv = has('ap_invoices') ? db().get('SELECT uid, invoice_no, supplier_name, total FROM ap_invoices WHERE uid = ?', [f.invoiceUid]) : null;
    need(inv, 'That invoice was not found.');
    if (cost === null) cost = inv.total;
  }
  const uid = uuid('VW');
  const w = who(user);
  const now = stamp(); const dev = deviceId();
  db().transaction(() => {
    db().run(`INSERT INTO ve_work (uid, item_uid, kind, work_date, km, hours, note, cost, invoice_uid, invoice_no, supplier, due_uid, fault_uid, by_name, by_uid, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [uid, i.uid, f.kind, date, km, hours, note, cost === null ? null : r2(cost), inv ? inv.uid : null, inv ? inv.invoice_no : (txt(f.invoiceNo) || null),
      inv ? inv.supplier_name : (txt(f.supplier) || null), txt(f.dueUid) || null, txt(f.faultUid) || null, w.name, w.uid, now, now, dev]);
    bumpMeter(i.uid, { km, hours });
    // The due item this work satisfies starts again from today (a service with no due item picked resets "Service").
    let dueUid = txt(f.dueUid);
    if (!dueUid && f.kind === 'service') { const s = i.due.find((d) => /service/i.test(d.name)); if (s) dueUid = s.uid; }
    if (!dueUid && f.kind === 'inspection') { const s = i.due.find((d) => /inspect|verif|check/i.test(d.name)); if (s) dueUid = s.uid; }
    if (dueUid) {
      const d = db().get('SELECT * FROM ve_due WHERE uid = ?', [dueUid]);
      if (d) {
        const last = { last_date: date, last_km: km !== null ? km : (i.km ?? d.last_km), last_hours: hours !== null ? hours : (i.hours ?? d.last_hours) };
        const n = nextOf({ ...d, ...last });
        db().run(`UPDATE ve_due SET last_date = ?, last_km = ?, last_hours = ?, next_date = ?, next_km = ?, next_hours = ?, alerted_for = NULL, ${SYNCED} WHERE uid = ?`,
          [last.last_date, last.last_km, last.last_hours, n.next_date || (d.every_days ? null : d.next_date), n.next_km, n.next_hours, now, dev, dueUid]);
        db().run('UPDATE ve_work SET due_uid = ? WHERE uid = ?', [dueUid, uid]);
      }
    }
    // A repair fixes the fault it was for (or every open fault when none was picked).
    const faults = txt(f.faultUid) ? [txt(f.faultUid)] : f.kind === 'repair' ? i.openFaults.map((x) => x.uid) : [];
    for (const fu of faults) {
      db().run(`UPDATE ve_faults SET status = 'fixed', resolved_at = ?, resolved_by = ?, work_uid = ?, back_at = CASE WHEN out_of_use = 1 AND back_at IS NULL THEN ? ELSE back_at END, ${SYNCED} WHERE uid = ? AND status = 'open'`,
        [now, w.name, uid, now, now, dev, fu]);
    }
  });
  audit({ user, action: `${WORK_KINDS[f.kind]}: ${i.name}${cost !== null ? ` $${r2(cost).toFixed(2)}` : ''}`, table: 've_work', recordUid: uid });
  return uid;
}
export function voidWork(user, uid, reason) {
  mustManage(user);
  needReason(user, reason, 'Say why.');
  db().run(`UPDATE ve_work SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ? AND status = 'active'`, [txt(reason) || null, stamp(), deviceId(), uid]);
  audit({ user, action: 'Service / repair entry voided', table: 've_work', recordUid: uid, reason: txt(reason) });
}
export function listWork({ itemUid, from, to, kind } = {}) {
  ensureVe();
  return db().all(`SELECT w.*, i.name AS item_name, i.rego, i.area FROM ve_work w JOIN ve_items i ON i.uid = w.item_uid WHERE w.status = 'active'
    AND (? IS NULL OR w.item_uid = ?) AND (? IS NULL OR w.work_date >= ?) AND (? IS NULL OR w.work_date <= ?) AND (? IS NULL OR w.kind = ?) ORDER BY w.work_date DESC, w.created_at DESC`,
  [itemUid || null, itemUid || null, from || null, from || null, to || null, to || null, kind || null, kind || null]);
}
// Supplier invoices to link a service or repair to (the cost is already in the books through the invoice).
export function invoiceOptions(limit = 80) {
  if (!has('ap_invoices')) return [];
  return db().all("SELECT uid, invoice_no, supplier_name, invoice_date, total FROM ap_invoices WHERE status <> 'void' AND kind = 'invoice' ORDER BY invoice_date DESC LIMIT ?", [limit])
    .map((v) => ({ value: v.uid, label: `${v.supplier_name} · ${v.invoice_no || 'no number'} · ${v.invoice_date} · $${Number(v.total).toFixed(2)}` }));
}

// ---------------------------------------------------------------- faults (with out-of-use time)
export function reportFault(user, { itemUid, note, outOfUse = false, photos = [] }) {
  const i = getItem(itemUid);
  need(i, 'Choose the vehicle or equipment.');
  const n = txt(note);
  need(n, 'Describe the problem.');
  const uid = uuid('VF');
  const w = who(user);
  const now = stamp();
  db().transaction(() => {
    db().run(`INSERT INTO ve_faults (uid, item_uid, reported_at, note, reported_by, reported_by_uid, out_of_use, out_from, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?, 'open', ?,?)`,
      [uid, i.uid, now, n, w.name, w.uid, outOfUse ? 1 : 0, outOfUse ? now : null, now, deviceId()]);
    if (i.in_bakery) {
      const s = has('shifts') ? db().get("SELECT id FROM shifts WHERE status = 'open' ORDER BY id DESC LIMIT 1") : null;
      raiseAlert({ type: 'FAULT', severity: 'bad', shiftId: s ? s.id : null, userId: user && user.id ? user.id : null, message: `${i.name}: ${n}` });
    }
    if (photos && photos.length) addPhotos('ve_fault', uid, photos);
  });
  audit({ user, action: `Fault reported: ${i.name}${outOfUse ? ' (out of use)' : ''}`, table: 've_faults', recordUid: uid });
  return uid;
}
export function setOutOfUse(user, faultUid, on) {
  mustUse(user);
  const f = db().get('SELECT * FROM ve_faults WHERE uid = ?', [faultUid]);
  need(f && f.status === 'open', 'Not found.');
  if (on) db().run(`UPDATE ve_faults SET out_of_use = 1, out_from = COALESCE(out_from, ?), back_at = NULL, ${SYNCED} WHERE uid = ?`, [stamp(), stamp(), deviceId(), faultUid]);
  else db().run(`UPDATE ve_faults SET back_at = ?, ${SYNCED} WHERE uid = ?`, [stamp(), stamp(), deviceId(), faultUid]);
  audit({ user, action: on ? 'Out of use' : 'Back in use', table: 've_faults', recordUid: faultUid });
}
export function closeFault(user, faultUid, note) {
  mustUse(user);
  const f = db().get('SELECT * FROM ve_faults WHERE uid = ?', [faultUid]);
  need(f && f.status === 'open', 'Not found.');
  needReason(user, note, 'Say what happened (e.g. "fixed itself", "reported twice").');
  const now = stamp();
  db().run(`UPDATE ve_faults SET status = 'fixed', resolved_at = ?, resolved_by = ?, note = ?, back_at = CASE WHEN out_of_use = 1 AND back_at IS NULL THEN ? ELSE back_at END, ${SYNCED} WHERE uid = ?`,
    [now, who(user).name, `${f.note}${txt(note) ? ` — closed: ${txt(note)}` : ''}`, now, now, deviceId(), faultUid]);
  audit({ user, action: 'Fault closed without a repair', table: 've_faults', recordUid: faultUid, reason: txt(note) });
}
// Minutes out of use inside a period (a fault still out of use counts until now).
export function outOfUseMinutes(f, from = '0000-01-01', to = '9999-12-31', nowStamp = stamp()) {
  if (!f.out_of_use || !f.out_from) return 0;
  const a = Math.max(Date.parse(f.out_from.replace(' ', 'T')), Date.parse(`${from}T00:00:00`));
  const endTo = Date.parse(`${to}T23:59:59`);
  const b = Math.min(Date.parse((f.back_at || nowStamp).replace(' ', 'T')), endTo);
  return b > a ? Math.round((b - a) / 60000) : 0;
}
export function listFaults({ itemUid, status, from, to } = {}) {
  ensureVe();
  return db().all(`SELECT f.*, i.name AS item_name, i.rego, i.in_bakery FROM ve_faults f JOIN ve_items i ON i.uid = f.item_uid WHERE f.status <> 'void'
    AND (? IS NULL OR f.item_uid = ?) AND (? IS NULL OR f.status = ?) AND (? IS NULL OR substr(f.reported_at,1,10) >= ?) AND (? IS NULL OR substr(f.reported_at,1,10) <= ?) ORDER BY f.reported_at DESC`,
  [itemUid || null, itemUid || null, status || null, status || null, from || null, from || null, to || null, to || null]).map((f) => ({ ...f, minutesOut: outOfUseMinutes(f) }));
}

// ---------------------------------------------------------------- fuel (entered once, goes everywhere)
const WALLET_TABLES = ['mpaisa_wallets', 'money_wallets', 'wallets'];
// Where the money came from: a shop's cash, an M-PAiSA wallet (one per shop) or the bank. Works before the wallets
// exist as their own money accounts (then the M-PAiSA payment is booked against "M-PAiSA & cards to be banked").
export function paidFromOptions() {
  try { if (has('wallets')) ensureDefaultWallets(); } catch (e) { /* wallets not ready */ }
  const base = moneyOptions();
  let wallets = [];
  for (const t of WALLET_TABLES) {
    if (!has(t)) continue;
    try { wallets = db().all(`SELECT * FROM ${t} WHERE COALESCE(active, 1) = 1 ORDER BY name`).map((w) => ({ value: `mpaisa:${w.uid}`, label: `M-PAiSA – ${w.name}`, shop: w.shop_code || null })); } catch (e) { wallets = []; }
    if (wallets.length) break;
  }
  if (!wallets.length) {
    let shops = [];
    try { shops = db().all("SELECT code, name FROM shops WHERE active = 1 AND code LIKE 'S%' ORDER BY sort, code"); } catch (e) { shops = []; }
    wallets = shops.map((s) => ({ value: `mpaisa:${s.code}`, label: `M-PAiSA wallet – ${s.name}`, shop: s.code }));
  }
  return base.filter((o) => o.value.startsWith('cash:')).concat(wallets.map(({ value, label }) => ({ value, label }))).concat(base.filter((o) => !o.value.startsWith('cash:')));
}
export function moneyFor(via, area) {
  try { return moneyCode(via, area); } catch (e) {
    const v = txt(via);
    if (!v.startsWith('mpaisa:')) throw e;
    const id = v.slice(7);
    let shop = /^S\d+$/.test(id) ? id : null;
    for (const t of WALLET_TABLES) { if (!shop && has(t)) { try { const w = db().get(`SELECT * FROM ${t} WHERE uid = ?`, [id]); if (w && w.shop_code) shop = w.shop_code; } catch (x) { /* no shop column */ } } }
    return { code: '1110', shop: shop || area || OFFICE };
  }
}
// The wallet behind an "mpaisa:<wallet uid>" choice (null when paid from cash or the bank, or wallets are not set up).
export function walletOf(via) {
  const v = txt(via);
  if (!v.startsWith('mpaisa:') || !has('wallets') || !has('wallet_moves')) return null;
  return db().get('SELECT * FROM wallets WHERE uid = ?', [v.slice(7)]) || null;
}
export function fuelAccount() { return (glMap().ap || {})['Transport & fuel'] || '6040'; }

// km per litre for a full tank: the km since the previous full tank ÷ every litre put in since then.
function efficiency(itemUid, km, litres, excludeUid) {
  const prevFull = db().get("SELECT * FROM ve_fuel WHERE item_uid = ? AND status = 'active' AND full_tank = 1 AND km < ? AND uid <> ? ORDER BY km DESC LIMIT 1", [itemUid, km, excludeUid || '']);
  if (!prevFull) return null;
  const between = db().get("SELECT COALESCE(SUM(litres), 0) AS l FROM ve_fuel WHERE item_uid = ? AND status = 'active' AND km > ? AND km < ? AND uid <> ?", [itemUid, prevFull.km, km, excludeUid || '']).l;
  const total = between + litres;
  return total > 0 ? r2((km - prevFull.km) / total) : null;
}
export function usualKmPerL(itemUid, beforeKm = 1e12) {
  const rows = db().all("SELECT km_per_l FROM ve_fuel WHERE item_uid = ? AND status = 'active' AND km_per_l IS NOT NULL AND km < ? ORDER BY km DESC LIMIT 5", [itemUid, beforeKm]);
  return rows.length ? r2(rows.reduce((s, r) => s + r.km_per_l, 0) / rows.length) : null;
}
export function fuelFlags(item, { km, litres, kmPerL }, rules = veRules()) {
  const flags = [];
  const last = db().get("SELECT MAX(km) AS km FROM ve_fuel WHERE item_uid = ? AND status = 'active'", [item.uid]).km;
  if (last !== null && last !== undefined && km < last) flags.push({ key: 'km_back', text: `The km reading is lower than the last fill-up (${Math.round(last)} km).` });
  if (last !== null && last !== undefined && km - last > rules.fuelGapKm) flags.push({ key: 'gap', text: `${Math.round(km - last)} km since the last fill-up – was a fill-up missed?` });
  if (item.tank_l && litres > item.tank_l * 1.05) flags.push({ key: 'tank', text: `${litres} L is more than the tank holds (${item.tank_l} L).` });
  const usual = usualKmPerL(item.uid, km);
  if (kmPerL !== null && usual) {
    if (kmPerL < usual * (1 - rules.fuelFlagPct / 100)) flags.push({ key: 'low', text: `Only ${kmPerL} km/L – usually ${usual} km/L.` });
    else if (kmPerL > usual * (1 + (rules.fuelFlagPct * 2) / 100)) flags.push({ key: 'high', text: `${kmPerL} km/L is much better than usual (${usual}) – a fill-up may be missing.` });
  }
  return flags;
}
export function saveFuel(user, f) {
  mustUse(user);
  const i = getItem(f.itemUid);
  need(i && i.kind === 'vehicle', 'Choose the vehicle.');
  need(i.status === 'active', 'This vehicle is no longer in use.');
  const date = txt(f.date) || dateStr();
  need(DATE.test(date), 'Enter the date.');
  need(date <= dateStr(), 'The date cannot be in the future.');
  const km = Number(f.km);
  need(txt(f.km) !== '' && Number.isFinite(km) && km > 0, 'Enter the km on the odometer.');
  const litres = r2(f.litres);
  need(litres > 0 && litres < 1000, 'Enter the litres put in.');
  const amount = r2(f.amount);
  need(amount > 0, 'Enter the amount paid (incl. VAT).');
  const taxInv = f.taxInvoice !== false;
  const vat = taxInv ? (txt(f.vat) === '' || f.vat === undefined ? vatIn(amount) : r2(f.vat)) : 0;
  need(vat >= 0 && vat < amount, 'The VAT amount is not right.');
  need(txt(f.via), 'Choose where the money came from.');
  const area = txt(f.area) || i.area || OFFICE;
  const from = moneyFor(f.via, area);
  const full = f.fullTank !== false;
  const uid = uuid('FUEL');
  const kmPerL = full ? efficiency(i.uid, km, litres, uid) : null;
  const flags = fuelFlags(i, { km, litres, kmPerL });
  const w = who(user);
  const now = stamp();
  const label = `${i.name}${i.rego ? ` ${i.rego}` : ''}`;
  db().transaction(() => {
    const D = (code, a, shop) => ({ code, debit: r2(a), credit: 0, shop });
    const C = (code, a, shop) => ({ code, debit: 0, credit: r2(a), shop });
    const jUid = saveJournal(user || { name: 'System' }, {
      date, memo: `Fuel ${label}: ${litres} L at ${Math.round(km)} km${txt(f.supplier) ? ` (${txt(f.supplier)})` : ''}`, kind: 'expense', refUid: uid,
      meta: { total: amount, vat, zero: 0, shop: area, supplier: txt(f.supplier) || null, tin: txt(f.tin) || null, no: txt(f.receiptNo) || null, reference: txt(f.receiptNo) || null, fuel: uid },
      lines: [D(fuelAccount(), amount - vat, area), D('2200', vat, area), C(from.code, amount, from.shop)].filter((l) => l.debit || l.credit),
    });
    db().run(`INSERT INTO ve_fuel (uid, item_uid, fill_date, km, litres, amount, price_per_l, full_tank, tax_invoice, vat, via, area, supplier, supplier_tin, receipt_no, journal_uid, km_per_l, flags, by_name, by_uid, created_at, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, [uid, i.uid, date, km, litres, amount, r3(amount / litres), full ? 1 : 0, taxInv ? 1 : 0, vat, txt(f.via), area, txt(f.supplier) || null, txt(f.tin) || null,
      txt(f.receiptNo) || null, jUid, kmPerL, flags.length ? JSON.stringify(flags) : null, w.name, w.uid, now, now, deviceId()]);
    bumpMeter(i.uid, { km });
    // Paid from an M-PAiSA wallet: the wallet's balance goes down too (its history shows "Paid from the wallet").
    const wal = walletOf(f.via);
    if (wal) {
      db().run(`INSERT INTO wallet_moves (uid, wallet_uid, move_date, type, amount, reference, note, by_name, updated_at, updated_device) VALUES (?,?,?, 'payment', ?,?,?,?,?,?)`,
        [`WM-${uid}`, wal.uid, date, amount, txt(f.receiptNo) || null, `Fuel ${label}`, w.name, now, deviceId()]);
    }
    if (f.photos && f.photos.length) addPhotos('ve_fuel', uid, f.photos);
  });
  audit({ user, action: `Fuel ${label}: ${litres} L $${amount.toFixed(2)}`, table: 've_fuel', recordUid: uid });
  return { uid, kmPerL, flags };
}
export function voidFuel(user, uid, reason) {
  mustUse(user);
  const f = db().get('SELECT * FROM ve_fuel WHERE uid = ?', [uid]);
  need(f && f.status === 'active', 'Not found.');
  needReason(user, reason, 'Say why it is being cancelled.');
  db().transaction(() => {
    if (f.journal_uid) {
      const j = db().get('SELECT status FROM gl_journals WHERE uid = ?', [f.journal_uid]);
      if (j && j.status === 'active') voidJournal(user, f.journal_uid, txt(reason) || 'Fuel entry cancelled');
    }
    db().run(`UPDATE ve_fuel SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ?`, [txt(reason) || null, stamp(), deviceId(), uid]);
    if (has('wallet_moves')) db().run(`UPDATE wallet_moves SET status = 'void', void_reason = ?, ${SYNCED} WHERE uid = ? AND status = 'active'`, [txt(reason) || 'Fuel entry cancelled', stamp(), deviceId(), `WM-${uid}`]);
  });
  audit({ user, action: 'Fuel entry cancelled', table: 've_fuel', recordUid: uid, reason: txt(reason) });
}
export function listFuel({ itemUid, from, to, flagged } = {}) {
  ensureVe();
  return db().all(`SELECT f.*, i.name AS item_name, i.rego FROM ve_fuel f JOIN ve_items i ON i.uid = f.item_uid WHERE f.status = 'active'
    AND (? IS NULL OR f.item_uid = ?) AND (? IS NULL OR f.fill_date >= ?) AND (? IS NULL OR f.fill_date <= ?) ORDER BY f.fill_date DESC, f.km DESC`,
  [itemUid || null, itemUid || null, from || null, from || null, to || null, to || null]).map((f) => ({ ...f, flagList: J(f.flags, []) })).filter((f) => !flagged || f.flagList.length);
}

// ---------------------------------------------------------------- daily checks (built, switched off until the admin turns them on)
export function saveCheck(user, { itemUid, answers, km, note }) {
  mustUse(user);
  const rules = veRules();
  need(rules.dailyChecksOn, 'Daily checks are switched off (Settings › Vehicles & equipment rules).');
  const i = getItem(itemUid);
  need(i, 'Choose the vehicle or equipment.');
  const a = answers || {};
  const missing = rules.checkItems.filter((k) => a[k] === undefined || a[k] === null);
  need(!missing.length, `Answer every item: ${missing.join(', ')}.`);
  const bad = rules.checkItems.filter((k) => a[k] === false);
  need(!bad.length || txt(note), 'Say what is wrong.');
  const uid = uuid('VC');
  const w = who(user);
  const now = stamp();
  db().transaction(() => {
    db().run(`INSERT INTO ve_checks (uid, item_uid, check_date, answers, ok, km, note, by_name, by_uid, created_at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [uid, i.uid, dateStr(), JSON.stringify(a), bad.length ? 0 : 1, numOrNull(km), txt(note) || null, w.name, w.uid, now, now, deviceId()]);
    bumpMeter(i.uid, { km });
    if (bad.length) reportFault(user, { itemUid: i.uid, note: `Daily check: ${bad.join(', ')} not OK. ${txt(note)}`.trim() });
  });
  return uid;
}
export function checksFor(itemUid, limit = 30) { return db().all('SELECT * FROM ve_checks WHERE item_uid = ? ORDER BY check_date DESC, created_at DESC LIMIT ?', [itemUid, limit]).map((c) => ({ ...c, answers: J(c.answers, {}) })); }
export function checkedToday(itemUid, today = dateStr()) { return !!db().get('SELECT 1 AS x FROM ve_checks WHERE item_uid = ? AND check_date = ?', [itemUid, today]); }

// ---------------------------------------------------------------- running costs
export function runningCosts(from, to) {
  ensureVe();
  const rows = listItems({ includeArchived: true }).map((i) => {
    const fuel = db().get("SELECT COALESCE(SUM(amount),0) AS a, COALESCE(SUM(vat),0) AS v, COALESCE(SUM(litres),0) AS l, MIN(km) AS k0, MAX(km) AS k1, COUNT(*) AS n FROM ve_fuel WHERE item_uid = ? AND status = 'active' AND fill_date BETWEEN ? AND ?", [i.uid, from, to]);
    const work = db().get("SELECT COALESCE(SUM(cost),0) AS c, COUNT(*) AS n FROM ve_work WHERE item_uid = ? AND status = 'active' AND work_date BETWEEN ? AND ?", [i.uid, from, to]);
    const faults = db().all("SELECT * FROM ve_faults WHERE item_uid = ? AND status <> 'void'", [i.uid]);
    const minsOut = faults.reduce((s, f) => s + outOfUseMinutes(f, from, to), 0);
    const nFaults = faults.filter((f) => f.reported_at.slice(0, 10) >= from && f.reported_at.slice(0, 10) <= to).length;
    // Km travelled: from the last reading before the period (if any) to the highest reading in it.
    const before = db().get("SELECT MAX(km) AS k FROM ve_fuel WHERE item_uid = ? AND status = 'active' AND fill_date < ?", [i.uid, from]).k;
    const startKm = before !== null && before !== undefined ? before : fuel.k0;
    const km = fuel.k1 !== null && startKm !== null ? Math.max(0, fuel.k1 - startKm) : 0;
    const fuelEx = r2(fuel.a - fuel.v);
    const total = r2(fuelEx + work.c);
    return { uid: i.uid, name: i.name, rego: i.rego, kind: i.kind, area: i.area, areaLabel: i.areaLabel, fuel: r2(fuel.a), fuelExVat: fuelEx, litres: r2(fuel.l), fills: fuel.n, km,
      kmPerL: fuel.l && km ? r2(km / fuel.l) : null, work: r2(work.c), jobs: work.n, total, perKm: km ? r2(total / km) : null, faults: nFaults, hoursOut: Math.round(minsOut / 6) / 10, status: i.status };
  }).filter((r) => r.status === 'active' || r.total || r.fills || r.jobs);
  const sum = (k) => r2(rows.reduce((s, r) => s + (r[k] || 0), 0));
  return { rows, totals: { fuel: sum('fuel'), fuelExVat: sum('fuelExVat'), litres: sum('litres'), work: sum('work'), total: sum('total'), km: sum('km'), hoursOut: sum('hoursOut') } };
}

// ---------------------------------------------------------------- warnings
export function veAlertList(today = dateStr()) {
  const out = [];
  for (const d of allDue({ today })) {
    out.push({ id: `ve-due-${d.uid}-${d.state}-${d.next_date || ''}`, level: d.state === 'overdue' ? 'urgent' : 'warning',
      text: `${d.item.name}${d.item.rego ? ` (${d.item.rego})` : ''}: ${d.name} ${d.state === 'overdue' ? 'OVERDUE' : 'due soon'} – ${d.text}`, nav: { screen: 'VeItem', params: { uid: d.item.uid } } });
  }
  for (const f of listFaults({ status: 'open' })) {
    if (f.out_of_use && !f.back_at) out.push({ id: `ve-out-${f.uid}`, level: 'warning', text: `${f.item_name} is out of use: ${f.note}`, sub: `since ${f.out_from.slice(0, 16)}`, nav: { screen: 'VeItem', params: { uid: f.item_uid } } });
    else out.push({ id: `ve-fault-${f.uid}`, level: 'info', text: `Fault on ${f.item_name}: ${f.note}`, nav: { screen: 'VeItem', params: { uid: f.item_uid } } });
  }
  for (const f of listFuel({ from: addDays(today, -7), flagged: true })) {
    out.push({ id: `ve-fuel-${f.uid}`, level: 'info', text: `Fuel ${f.item_name} ${f.fill_date}: ${f.flagList[0].text}`, nav: { screen: 'VeFuelLog', params: {} } });
  }
  if (veRules().dailyChecksOn) {
    for (const i of listItems({ kind: 'vehicle', today })) {
      if (!checkedToday(i.uid, today)) out.push({ id: `ve-check-${i.uid}-${today}`, level: 'info', text: `No daily check yet today for ${i.name}`, nav: { screen: 'VeCheck', params: { uid: i.uid } } });
    }
  }
  return out;
}
