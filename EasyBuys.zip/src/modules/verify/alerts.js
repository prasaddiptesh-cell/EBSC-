// Warnings for Home: money records not seen in the bank yet, and the To verify queue.
import { can } from '../../services/access.js';
import { queueSummary } from './service.js';

export function alerts(user) {
  if (!can(user, 'verify_money')) return [];
  const q = queueSummary();
  const out = [];
  if (q.late) out.push({ id: 'verify-late', level: 'urgent', text: `${q.late} money record${q.late === 1 ? '' : 's'} not seen in the bank yet`, sub: 'Deposits or cheques older than expected.', nav: { screen: 'Verify', params: {} } });
  if (q.waiting > q.late) out.push({ id: 'verify-waiting', level: 'info', text: `${q.waiting - q.late} record${q.waiting - q.late === 1 ? '' : 's'} waiting to be verified`, nav: { screen: 'Verify', params: {} } });
  return out;
}
