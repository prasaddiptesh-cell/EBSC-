// To verify: 2nd step for every money record, staff photos of invoices / cheques, Viber alerts.
import { VerifyScreen, SnapScreen, MySnapsScreen, VerifySetupScreen, ReceiveScreen, HandChequeScreen, MyQueriesScreen } from './screens/VerifyScreens.js';
import { can } from '../../services/access.js';
import { OfficeTodayScreen, TodayInvoiceScreen, TodayItemScreen, SavedDoneScreen } from './screens/TodayScreens.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'verify',
  title: 'To verify',
  icon: '✅',
  switchable: false,
  screens: {
    Verify: { component: VerifyScreen, can: (u) => can(u, 'verify_money') || can(u, 'bank_rec') },
    Snap: { component: SnapScreen, can: (u) => can(u, 'snap_upload') || can(u, 'po_receive') },
    MySnaps: { component: MySnapsScreen, can: (u) => can(u, 'snap_upload') },
    ReceiveGoods: { component: ReceiveScreen, can: (u) => can(u, 'snap_upload') || can(u, 'po_receive') },
    HandCheque: { component: HandChequeScreen, can: (u) => can(u, 'snap_upload') },
    MyQueries: { component: MyQueriesScreen, can: (u) => !!u },
    VerifySetup: { component: VerifySetupScreen, can: (u) => can(u, 'verify_setup') },
    // 1.0.0 Office › Today (the new shell's Today tab) and its check screens
    OfficeToday: { component: OfficeTodayScreen, can: (u) => !!u && u.role !== 'accountant' && (['verify_money', 'payments_make', 'invoices_check', 'till_approve'].some((p) => can(u, p)) || ['owner', 'admin'].includes(u.role)) },
    TodayInvoice: { component: TodayInvoiceScreen, can: (u) => ['invoices_enter', 'invoices_check', 'payments_make', 'verify_money'].some((p) => can(u, p)) },
    TodayItem: { component: TodayItemScreen, can: (u) => can(u, 'verify_money') || can(u, 'payments_make') },
    SavedDone: { component: SavedDoneScreen, can: (u) => !!u },
  },
  menu: MENU,
  alerts,
  reports: [],
};
