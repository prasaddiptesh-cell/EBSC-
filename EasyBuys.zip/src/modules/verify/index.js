// To verify: 2nd step for every money record, staff photos of invoices / cheques, Viber alerts.
import { VerifyScreen, SnapScreen, MySnapsScreen, VerifySetupScreen } from './screens/VerifyScreens.js';
import { can } from '../../services/access.js';

export default {
  id: 'verify',
  title: 'To verify',
  icon: '✅',
  switchable: false,
  screens: {
    Verify: { component: VerifyScreen, can: (u) => can(u, 'verify_money') || can(u, 'bank_rec') },
    Snap: { component: SnapScreen, can: (u) => can(u, 'snap_upload') },
    MySnaps: { component: MySnapsScreen, can: (u) => can(u, 'snap_upload') },
    VerifySetup: { component: VerifySetupScreen, can: (u) => can(u, 'verify_setup') },
  },
  reports: [],
};
