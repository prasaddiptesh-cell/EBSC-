// To verify: 2nd step for every money record, staff photos of invoices / cheques, Viber alerts.
import { VerifyScreen, SnapScreen, MySnapsScreen, VerifySetupScreen, ReceiveScreen, HandChequeScreen, MyQueriesScreen } from './screens/VerifyScreens.js';
import { can } from '../../services/access.js';
import { MENU } from './menu.js';
import { alerts } from './alerts.js';

export default {
  id: 'verify',
  title: 'To verify',
  icon: '✅',
  switchable: false,
  screens: {
    Verify: { component: VerifyScreen, can: (u) => can(u, 'verify_money') || can(u, 'bank_rec') },
    Snap: { component: SnapScreen, can: (u) => can(u, 'snap_upload') || can(u, 'po_receive') },
    MySnaps: { component: MySnapsScreen, can: (u) => can(u, 'snap_upload') },
    ReceiveGoods: { component: ReceiveScreen, can: (u) => can(u, 'snap_upload') || can(u, 'po_receive') },
    HandCheque: { component: HandChequeScreen, can: (u) => can(u, 'snap_upload') },
    MyQueries: { component: MyQueriesScreen, can: (u) => !!u },
    VerifySetup: { component: VerifySetupScreen, can: (u) => can(u, 'verify_setup') },
  },
  menu: MENU,
  alerts,
  reports: [],
};
