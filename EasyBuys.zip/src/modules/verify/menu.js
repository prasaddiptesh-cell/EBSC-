// To verify menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '✅', title: 'To verify', note: 'Second check of money records and staff photos.', screen: 'Verify' },
    { id: 'vf-snap', icon: '📷', title: 'Photo of invoice / cheque', screen: 'Snap' },
  ] },
  { section: 'Records', items: [
    { id: 'vf-mine', icon: '🗂️', title: 'My photos', screen: 'MySnaps' },
  ] },
  { section: 'Settings', items: [
    { id: 'vf-setup', icon: '⚙️', title: 'Verification & Viber alerts', screen: 'VerifySetup' },
  ] },
];
