// To verify menu.
export const MENU = [
  { section: 'Daily tasks', items: [
    { id: 'home', icon: '✅', title: 'To verify', note: 'Second check of money records and staff photos.', screen: 'Verify' },
    { id: 'vf-receive', icon: '📦', title: 'Receive goods & invoice', note: 'Delivery, invoice photo and the order – together.', screen: 'ReceiveGoods' },
    { id: 'vf-cheque', icon: '✍️', title: 'Hand over a cheque', note: 'Photo, who took it, which invoices it pays.', screen: 'HandCheque' },
    { id: 'vf-snap', icon: '📷', title: 'Other papers (cheque received, receipt…)', screen: 'Snap' },
  ] },
  { section: 'Records', items: [
    { id: 'vf-mine', icon: '🗂️', title: 'My photos', screen: 'MySnaps' },
  ] },
  { section: 'Settings', items: [
    { id: 'vf-setup', icon: '⚙️', title: 'Verification & Viber alerts', screen: 'VerifySetup' },
  ] },
];
