// 1.0.0 The papers behind everything on Today (owner: "I will need access to the invoices and cheques when doing my
// verifications"): the invoice / bill photos or PDF, the cheque photo and stub, the stamped deposit slip, the damaged
// goods photo, the cash-paid receipt, the till count's Z photo – shown right on the check screen.
// A photo lives on the phone that took it (photos table) and in Google Drive (its link on the photo and on the record).
// When the phone's own copy is gone (cleared after the kept days, or taken on another device), resolvePaper() fetches
// it from Drive by itself; offline it says so plainly. The file IO is passed in (io), so this file has no React Native.
import { db } from '../../db/connection.js';

const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const one = (sql, a) => { try { return db().get(sql, a) || null; } catch (e) { return null; } };
const all = (sql, a) => { try { return db().all(sql, a) || []; } catch (e) { return []; } };
const isHttp = (u) => /^https?:/i.test(String(u || ''));
export const isPdf = (u) => /\.pdf(\?|#|$)/i.test(String(u || ''));

// The Drive file id in a Drive link (https://drive.google.com/file/d/<id>/view, ...?id=<id>, /open?id=<id>).
export function driveIdOf(url) {
  const s = String(url || '');
  if (!/google\.com/i.test(s)) return null;
  const m = /\/d\/([A-Za-z0-9_-]{10,})/.exec(s) || /[?&]id=([A-Za-z0-9_-]{10,})/.exec(s);
  return m ? m[1] : null;
}
// One record's photos: the local ones (each with its own Drive link once uploaded) and the Drive links on the record
// that no local photo has (taken on another device).
export function photosOf(refType, refId, urls = [], caption = '') {
  const local = all('SELECT id, uri, cloud_url, created_at FROM photos WHERE ref_type = ? AND ref_id = ? ORDER BY id', [refType, String(refId)]);
  const out = local.map((p) => ({ uri: p.uri, cloudUrl: p.cloud_url || null, driveId: driveIdOf(p.cloud_url), caption, at: p.created_at, pdf: isPdf(p.uri) }));
  const seen = new Set(local.map((p) => p.cloud_url).filter(Boolean));
  for (const u of urls || []) {
    if (!u || seen.has(u)) continue;
    // a list of local uris (e.g. damaged goods keep the phone's file names) or Drive links
    out.push(isHttp(u) ? { uri: null, cloudUrl: u, driveId: driveIdOf(u), caption, pdf: isPdf(u) } : { uri: u, cloudUrl: null, driveId: null, caption, pdf: isPdf(u) });
  }
  return out;
}
const group = (label, photos, extra = {}) => (photos.length ? [{ label, photos, ...extra }] : []);
function invoicePapers(uid, label) {
  const i = one('SELECT uid, invoice_no, kind, photo_urls FROM ap_invoices WHERE uid = ?', [uid]);
  if (!i) return [];
  return group(label || `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || ''}`.trim(), photosOf('invoice', uid, J(i.photo_urls, []), `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || ''}`.trim()), { kind: i.kind === 'credit' ? 'credit' : 'invoice', refUid: uid });
}
function chequePapers(chequeUid) {
  const c = one('SELECT uid, cheque_no, payment_uid, photo_urls FROM cheques WHERE uid = ?', [chequeUid]);
  if (!c) return [];
  let out = group(`Cheque ${c.cheque_no} – photo / stub`, photosOf('stub', c.uid, J(c.photo_urls, []), `Cheque ${c.cheque_no}`), { kind: 'cheque', refUid: c.uid });
  for (const s of all("SELECT uid, kind, photo_urls FROM money_snaps WHERE link_table = 'cheques' AND link_uid = ? AND status <> 'rejected'", [c.uid])) {
    out = out.concat(group(s.kind === 'cheque_written' ? `Cheque ${c.cheque_no} – photo` : `Cheque ${c.cheque_no} – handed over`, photosOf('snap', s.uid, J(s.photo_urls, []), `Cheque ${c.cheque_no}`), { kind: 'cheque', refUid: s.uid }));
  }
  if (c.payment_uid) {
    const p = one('SELECT photo_urls FROM ap_payments WHERE uid = ?', [c.payment_uid]);
    out = out.concat(group(`Cheque ${c.cheque_no} – signed slip`, photosOf('payment', c.payment_uid, J(p && p.photo_urls, []), `Cheque ${c.cheque_no}`), { kind: 'cheque', refUid: c.payment_uid }));
    for (const a of all('SELECT invoice_uid FROM ap_allocations WHERE payment_uid = ? AND amount > 0', [c.payment_uid])) out = out.concat(invoicePapers(a.invoice_uid));
  }
  return out;
}
function planPapers(uid) {
  const p = one('SELECT uid, plan_date, photo_urls, deposit_uid FROM deposit_plans WHERE uid = ?', [uid]);
  if (!p) return [];
  return group(`Stamped deposit slip ${p.plan_date}`, photosOf('deposit_plan', uid, J(p.photo_urls, []), 'Stamped deposit slip'), { kind: 'deposit', refUid: uid })
    .concat(p.deposit_uid ? depositPapers(p.deposit_uid) : []);
}
function depositPapers(uid) {
  const d = one('SELECT uid, deposit_date, slip_no, photo_urls FROM deposits WHERE uid = ?', [uid]);
  return d ? group(`Deposit slip ${d.slip_no || d.deposit_date}`, photosOf('deposit', uid, J(d.photo_urls, []), 'Deposit slip'), { kind: 'deposit', refUid: uid }) : [];
}
// item: { table, uid } (a Today / To verify item, or any record). Returns [{ label, kind, refUid, photos: [...] }].
export function papersFor(item) {
  if (!item) return [];
  const t = item.table; const uid = item.uid;
  try {
    if (t === 'ap_invoices') return invoicePapers(uid);
    if (t === 'cheques') return chequePapers(uid);
    if (t === 'money_snaps') {
      const s = one('SELECT * FROM money_snaps WHERE uid = ?', [uid]);
      if (!s) return [];
      const lab = s.kind === 'invoice' ? 'Invoice photo' : /cheque/.test(s.kind) ? `Cheque ${s.cheque_no || s.ref_no || ''} – photo`.trim() : 'Photo';
      let out = group(lab, photosOf('snap', uid, J(s.photo_urls, []), lab), { kind: /cheque/.test(s.kind) ? 'cheque' : 'paper', refUid: uid });
      if (s.link_table === 'ap_invoices') out = out.concat(invoicePapers(s.link_uid));
      if (s.link_table === 'cheques') out = out.concat(chequePapers(s.link_uid).filter((g) => g.refUid !== uid));
      J(s.invoice_uids, []).forEach((u) => { out = out.concat(invoicePapers(u)); });
      return out;
    }
    if (t === 'deposit_plans') return planPapers(uid);
    if (t === 'deposits') return depositPapers(uid);
    if (t === 'supplier_owed') {
      const o = one('SELECT uid, name, photo_urls, invoice_uid, receipt_uid FROM supplier_owed WHERE uid = ?', [uid]);
      if (!o) return [];
      return group(`Damaged – ${o.name}`, photosOf('owed', uid, J(o.photo_urls, []), `Damaged – ${o.name}`), { kind: 'damaged', refUid: uid })
        .concat(o.invoice_uid ? invoicePapers(o.invoice_uid, 'The invoice it came on') : [])
        .concat(o.receipt_uid ? group('Delivery photo', photosOf('receipt', o.receipt_uid, [], 'Delivery'), { kind: 'paper', refUid: o.receipt_uid }) : []);
    }
    if (t === 'ap_payments') {
      const p = one('SELECT uid, method, cheque_uid, photo_urls FROM ap_payments WHERE uid = ?', [uid]);
      if (!p) return [];
      let out = group(p.method === 'cash' ? 'Their receipt / signed slip' : 'Payment slip', photosOf('payment', uid, J(p.photo_urls, []), 'Payment'), { kind: 'paper', refUid: uid });
      if (p.cheque_uid) out = out.concat(chequePapers(p.cheque_uid).filter((g) => g.refUid !== uid));
      else for (const a of all('SELECT invoice_uid FROM ap_allocations WHERE payment_uid = ? AND amount > 0', [uid])) out = out.concat(invoicePapers(a.invoice_uid));
      return out;
    }
    if (t === 'till_counts') {
      const c = one('SELECT uid, z_number, photo_urls FROM till_counts WHERE uid = ?', [uid]);
      return c ? group(`Z report${c.z_number ? ` ${c.z_number}` : ''}`, photosOf('till', uid, J(c.photo_urls, []), 'Z report'), { kind: 'z', refUid: uid }) : [];
    }
    if (t === 'inv_receipts') {
      const r = one('SELECT uid, invoice_uid FROM inv_receipts WHERE uid = ?', [uid]);
      if (!r) return [];
      return group('Delivery photo', photosOf('receipt', uid, [], 'Delivery'), { kind: 'paper', refUid: uid }).concat(r.invoice_uid ? invoicePapers(r.invoice_uid) : []);
    }
  } catch (e) { return []; }
  return [];
}
// Every paper of one supplier, newest first (the supplier page's "Papers"): invoices, credit notes, cheque photos and
// stubs, cash-paid receipts, deposit slips that covered their cheques. month: 'YYYY-MM' to show one month.
export function supplierPapers(supplierUid, { month } = {}) {
  const out = [];
  const inMonth = (d) => !month || String(d || '').slice(0, 7) === month;
  for (const i of all("SELECT uid, kind, invoice_no, invoice_date, total, photo_urls FROM ap_invoices WHERE supplier_uid = ? AND status <> 'void' ORDER BY invoice_date DESC", [supplierUid])) {
    if (!inMonth(i.invoice_date)) continue;
    const ph = photosOf('invoice', i.uid, J(i.photo_urls, []), `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || ''}`.trim());
    if (ph.length) out.push({ key: `inv:${i.uid}`, date: i.invoice_date, kind: i.kind === 'credit' ? 'credit' : 'invoice', label: `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || '(no number)'}`, amount: i.total, photos: ph, table: 'ap_invoices', uid: i.uid });
  }
  for (const p of all("SELECT p.uid, p.method, p.pay_date, p.amount, p.cheque_uid, p.cheque_no, p.photo_urls FROM ap_payments p WHERE p.supplier_uid = ? AND p.status = 'active' ORDER BY p.pay_date DESC", [supplierUid])) {
    if (!inMonth(p.pay_date)) continue;
    let ph = photosOf('payment', p.uid, J(p.photo_urls, []), 'Payment');
    if (p.cheque_uid) {
      const c = one('SELECT photo_urls FROM cheques WHERE uid = ?', [p.cheque_uid]);
      ph = photosOf('stub', p.cheque_uid, J(c && c.photo_urls, []), `Cheque ${p.cheque_no}`).concat(ph);
      for (const s of all("SELECT uid, photo_urls FROM money_snaps WHERE link_table = 'cheques' AND link_uid = ?", [p.cheque_uid])) ph = ph.concat(photosOf('snap', s.uid, J(s.photo_urls, []), `Cheque ${p.cheque_no}`));
    }
    if (ph.length) out.push({ key: `pay:${p.uid}`, date: p.pay_date, kind: p.method === 'cheque' ? 'cheque' : 'payment', label: p.method === 'cheque' ? `Cheque ${p.cheque_no}` : `Paid ${p.method === 'cash' ? 'in cash' : 'by transfer'}`, amount: p.amount, photos: ph, table: p.cheque_uid ? 'cheques' : 'ap_payments', uid: p.cheque_uid || p.uid });
  }
  for (const s of all("SELECT uid, kind, snap_date, amount, cheque_no, photo_urls FROM money_snaps WHERE supplier_uid = ? AND kind IN ('cheque_given','cheque_written') AND link_uid IS NULL AND status <> 'rejected'", [supplierUid])) {
    if (!inMonth(s.snap_date)) continue;
    const ph = photosOf('snap', s.uid, J(s.photo_urls, []), `Cheque ${s.cheque_no}`);
    if (ph.length) out.push({ key: `snap:${s.uid}`, date: s.snap_date, kind: 'cheque', label: `Cheque ${s.cheque_no} (not recorded yet)`, amount: s.amount, photos: ph, table: 'money_snaps', uid: s.uid });
  }
  // deposit slips of deposit plans that covered this supplier's cheques / invoices
  const mine = new Set(all("SELECT c.uid FROM cheques c JOIN ap_payments p ON p.uid = c.payment_uid WHERE p.supplier_uid = ?", [supplierUid]).map((x) => x.uid)
    .concat(all('SELECT uid FROM ap_invoices WHERE supplier_uid = ?', [supplierUid]).map((x) => x.uid))
    .concat(all("SELECT uid FROM money_snaps WHERE supplier_uid = ?", [supplierUid]).map((x) => x.uid)));
  for (const d of all("SELECT uid, plan_date, total, lines, photo_urls FROM deposit_plans WHERE status IN ('banked','on_bank') ORDER BY plan_date DESC", [])) {
    if (!inMonth(d.plan_date) || !J(d.lines, []).some((l) => mine.has(l.chequeUid) || mine.has(l.invoiceUid) || mine.has(l.snapUid))) continue;
    const ph = photosOf('deposit_plan', d.uid, J(d.photo_urls, []), 'Stamped deposit slip');
    if (ph.length) out.push({ key: `dp:${d.uid}`, date: d.plan_date, kind: 'deposit', label: `Deposit slip ${d.plan_date}`, amount: d.total, photos: ph, table: 'deposit_plans', uid: d.uid });
  }
  return out.sort((a, b) => String(b.date).localeCompare(String(a.date)));
}
export const papersMonths = (list) => [...new Set(list.map((p) => String(p.date || '').slice(0, 7)).filter(Boolean))].sort().reverse();

// ---------------------------------------------------------------- opening a paper
// io: { exists(uri) → bool, cached(driveId) → uri|null, fetch(driveId) → base64 (throws when offline / refused),
//       save(driveId, base64, pdf) → uri }. Returns { uri, fromDrive?, external?, error? }.
export const OFFLINE_TEXT = 'This photo is kept in Google Drive (the phone\'s copy was cleared). The phone is offline – it opens when the phone is online again.';
export async function resolvePaper(p, io) {
  if (!p) return { error: 'No photo.' };
  try { if (p.uri && !isHttp(p.uri) && (await io.exists(p.uri))) return { uri: p.uri }; } catch (e) { /* check Drive */ }
  const id = p.driveId || driveIdOf(p.cloudUrl || (isHttp(p.uri) ? p.uri : ''));
  if (!id) {
    if (p.cloudUrl || isHttp(p.uri)) return { uri: p.cloudUrl || p.uri, external: true };
    return { error: 'This photo is not on this phone and has not reached Google Drive yet. Open it on the phone that took it, or let that phone sync first.' };
  }
  try { const c = io.cached ? await io.cached(id) : null; if (c) return { uri: c, fromDrive: true }; } catch (e) { /* fetch */ }
  let data;
  try { data = await io.fetch(id); } catch (e) {
    const msg = String((e && e.message) || e || '');
    if (/network|offline|fetch|internet|timeout|abort|cloud web address/i.test(msg)) return { error: OFFLINE_TEXT, offline: true, cloudUrl: p.cloudUrl || null };
    return { error: `Could not load it from Google Drive: ${msg}`, cloudUrl: p.cloudUrl || null };
  }
  if (!data) return { error: 'Google Drive sent nothing back for this photo.' };
  const uri = await io.save(id, data, p.pdf);
  return { uri, fromDrive: true };
}
