// v3.9.5 "Query" on To verify: the owner (or whoever verifies) asks the person who did it about one item. The question
// shows on that person's Home (and goes to Viber); they answer on the tablet; the item stays on To verify, marked
// "Query", until it is verified.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from '../../services/core.js';
import { requirePerm, requireLogin, asService } from '../../services/guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const meta = () => ({ now: stamp(), dev: deviceId() });

export const VQ_SQL = `
CREATE TABLE IF NOT EXISTS verify_queries (
  uid TEXT PRIMARY KEY,
  item_key TEXT NOT NULL,
  table_name TEXT, record_uid TEXT,
  title TEXT,
  to_uid TEXT, to_name TEXT,
  question TEXT NOT NULL,
  asked_by_uid TEXT, asked_by_name TEXT, asked_at TEXT,
  answer TEXT, answered_by_name TEXT, answered_at TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  nav TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_vq_key ON verify_queries(item_key);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const VQ_SYNC = {
  verify_queries: SYNC('uid', 'To verify', ['uid', 'item_key', 'table_name', 'record_uid', 'title', 'to_uid', 'to_name', 'question', 'asked_by_uid', 'asked_by_name', 'asked_at',
    'answer', 'answered_by_name', 'answered_at', 'status', 'nav']),
};
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'verify_queries'"); } catch (e) { return false; } };
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

// The person who did an item: by uid if known, else by name.
function findPerson(uid, name) {
  if (uid) { const u = db().get('SELECT uid, name FROM users WHERE uid = ?', [uid]); if (u) return u; }
  if (txt(name)) { const u = db().get('SELECT uid, name FROM users WHERE active = 1 AND lower(name) = lower(?)', [txt(name)]); if (u) return u; }
  return null;
}

export function askQuery(user, { key, table, uid, title, toUid, toName, question, nav }) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(question), 'Write the question.');
  need(txt(key), 'Item not found.');
  const p = findPerson(toUid, toName);
  const { now, dev } = meta();
  const id = uuid('VQ');
  db().run(`INSERT INTO verify_queries (uid, item_key, table_name, record_uid, title, to_uid, to_name, question, asked_by_uid, asked_by_name, asked_at, status, nav, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?, 'open', ?,?,?)`, [id, key, table || null, uid || null, txt(title) || null, p ? p.uid : null, p ? p.name : txt(toName) || null, txt(question), user.uid, user.name, now, nav ? JSON.stringify(nav) : null, now, dev]);
  audit({ user, action: `Query to ${p ? p.name : txt(toName) || 'staff'}: ${txt(question)}`, table: 'verify_queries', recordUid: id });
  try {
    const V = require('./service.js');
    V.notify('verify_query', `❓ ${user.name} asks ${p ? p.name : txt(toName) || 'staff'} about ${txt(title) || 'an item'}: ${txt(question)}`);
  } catch (e) { /* Viber is optional */ }
  return id;
  });
}
export function answerQuery(user, quid, answer) {
  requireLogin(user); // the person asked (staff) answers the office's query // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(answer), 'Write your answer.');
  const q = db().get('SELECT * FROM verify_queries WHERE uid = ?', [quid]);
  need(q, 'Question not found.');
  need(q.status === 'open', 'This question is already answered.');
  const { now, dev } = meta();
  db().run("UPDATE verify_queries SET answer = ?, answered_by_name = ?, answered_at = ?, status = 'answered', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(answer), user.name, now, now, dev, quid]);
  audit({ user, action: `Answered a query: ${txt(answer)}`, table: 'verify_queries', recordUid: quid });
  try { require('./service.js').notify('verify_query', `💬 ${user.name} answered about ${q.title || 'an item'}: ${txt(answer)}`); } catch (e) { /* optional */ }
  });
}
export function closeQueriesFor(key) {
  if (!has()) return;
  const { now, dev } = meta();
  db().run("UPDATE verify_queries SET status = 'closed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE item_key = ? AND status <> 'closed'", [now, dev, key]);
}
export function openQueriesFor(userUid) {
  if (!has() || !userUid) return [];
  return db().all("SELECT * FROM verify_queries WHERE to_uid = ? AND status = 'open' ORDER BY asked_at", [userUid]).map((q) => ({ ...q, nav: J(q.nav, null) }));
}
// item key → the latest question about it (for To verify).
export function queriesByKey() {
  if (!has()) return {};
  const out = {};
  db().all("SELECT * FROM verify_queries WHERE status <> 'closed' ORDER BY asked_at").forEach((q) => { out[q.item_key] = { ...q, nav: J(q.nav, null) }; });
  return out;
}
export function getQuery(uid) {
  if (!has()) return null;
  const q = db().get('SELECT * FROM verify_queries WHERE uid = ?', [uid]);
  return q ? { ...q, nav: J(q.nav, null) } : null;
}
