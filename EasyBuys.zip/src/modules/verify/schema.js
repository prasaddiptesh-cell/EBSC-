// Two-step checks: person verifications of money records, photos snapped by staff, alerts sent.
export const VERIFY_SQL = `
CREATE TABLE IF NOT EXISTS verifications (
  uid TEXT PRIMARY KEY,
  table_name TEXT NOT NULL,
  record_uid TEXT NOT NULL,
  status TEXT NOT NULL,
  note TEXT,
  by_name TEXT, by_uid TEXT, at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS money_snaps (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  shop_code TEXT,
  snap_date TEXT NOT NULL,
  amount REAL,
  party TEXT,
  ref_no TEXT,
  note TEXT,
  collected_by TEXT,
  photo_urls TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'waiting',
  confirmed_by_name TEXT, confirmed_at TEXT, confirm_note TEXT,
  link_table TEXT, link_uid TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS alert_log (
  uid TEXT PRIMARY KEY,
  at TEXT NOT NULL,
  event TEXT,
  text TEXT,
  mode TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const VERIFY_SYNC = {
  verifications: SYNC('uid', 'To verify', ['uid', 'table_name', 'record_uid', 'status', 'note', 'by_name', 'by_uid', 'at']),
  money_snaps: SYNC('uid', 'To verify', ['uid', 'kind', 'shop_code', 'snap_date', 'amount', 'party', 'ref_no', 'note', 'collected_by', 'photo_urls', 'by_name', 'by_uid', 'created_at', 'status',
    'confirmed_by_name', 'confirmed_at', 'confirm_note', 'link_table', 'link_uid',
    'supplier_uid', 'cheque_no', 'account_uid', 'cheque_check', 'invoice_uids', 'po_uid', 'taker_sig', 'cheque_date']),
  alert_log: SYNC('uid', 'To verify', ['uid', 'at', 'event', 'text', 'mode']),
};
