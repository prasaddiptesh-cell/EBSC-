// 1.0.0 The papers on a check screen: each group (the invoice, the cheque, the stamped deposit slip…) as big thumbnails;
// tap one to see it full screen (zoom, next / previous page). A photo whose phone copy was cleared is loaded from
// Google Drive by itself ("Loading from Google Drive…"); offline it says so plainly. A PDF opens in the PDF viewer.
import React, { useEffect, useState } from 'react';
import { View, Image, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { C } from '../../../ui/theme.js';
import { PhotoViewer } from '../../../ui/photoView.js';

let fetcher = null;
const io = () => { if (!fetcher) fetcher = require('../../../platform/paperFetch.js'); return fetcher; };

function usePaperUris(photos) {
  const [st, setSt] = useState(() => photos.map(() => ({ loading: true })));
  const key = photos.map((p) => `${p.uri || ''}|${p.cloudUrl || ''}`).join(',');
  useEffect(() => {
    let live = true;
    setSt(photos.map(() => ({ loading: true })));
    photos.forEach((p, i) => {
      Promise.resolve().then(() => io().openPaper(p)).then((r) => { if (live) setSt((o) => o.map((x, k) => (k === i ? { ...r, loading: false } : x))); },
        (e) => { if (live) setSt((o) => o.map((x, k) => (k === i ? { loading: false, error: (e && e.message) || String(e) } : x))); });
    });
    return () => { live = false; };
  }, [key]);
  return st;
}

function Group({ g, testID, size }) {
  const st = usePaperUris(g.photos);
  const [open, setOpen] = useState(null);
  const ready = g.photos.map((p, i) => ({ p, s: st[i] || {} })).filter((x) => x.s.uri && !x.s.external && !x.p.pdf);
  const viewList = ready.map((x) => ({ uri: x.s.uri, caption: x.p.caption || g.label }));
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ fontSize: 15, fontWeight: '800', color: C.text }}>{g.label}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {g.photos.map((p, i) => {
          const s = st[i] || {};
          const tap = () => {
            if (s.loading || s.error) return;
            if (p.pdf || /\.pdf(\?|#|$)/i.test(String(s.uri || ''))) { io().openPdf(s.uri).catch(() => {}); return; }
            if (s.external) { try { require('react-native').Linking.openURL(s.uri); } catch (e) { /* no browser */ } return; }
            setOpen(Math.max(0, ready.findIndex((x) => x.p === p)));
          };
          return (
            <Pressable key={`${p.uri || p.cloudUrl}-${i}`} testID={`${testID}-${i}`} onPress={tap}
              style={{ width: size, height: size * 1.3, borderRadius: 12, overflow: 'hidden', borderWidth: 2, borderColor: s.error ? C.warn : C.border, backgroundColor: '#EEE9E1', alignItems: 'center', justifyContent: 'center' }}>
              {s.loading ? <Text style={{ fontSize: 13, color: C.info, textAlign: 'center', padding: 6 }}>{p.uri ? 'Opening…' : 'Loading from Google Drive…'}</Text>
                : s.error ? <Text style={{ fontSize: 12, color: C.text, textAlign: 'center', padding: 6 }}>{s.offline ? '📵 Offline – the photo is in Google Drive. It opens when the phone is online.' : s.error}</Text>
                  : p.pdf || /\.pdf(\?|#|$)/i.test(String(s.uri || '')) ? <Text style={{ fontSize: 15, fontWeight: '800', color: C.info, textAlign: 'center' }}>📄 PDF{'\n'}tap to open</Text>
                    : s.external ? <Text style={{ fontSize: 13, color: C.info, textAlign: 'center', padding: 6 }}>In Google Drive{'\n'}(tap)</Text>
                      : <Image source={{ uri: s.uri }} style={{ width: '100%', height: '100%' }} />}
              {s.fromDrive ? <View style={{ position: 'absolute', left: 4, top: 4, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 6, paddingHorizontal: 5 }}><Text style={{ color: '#fff', fontSize: 11 }}>Drive</Text></View> : null}
              {!s.loading && !s.error ? <View style={{ position: 'absolute', right: 4, bottom: 4, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 8, paddingHorizontal: 6 }}><Text style={{ color: '#fff', fontSize: 12 }}>⤢</Text></View> : null}
            </Pressable>
          );
        })}
      </View>
      {open !== null && viewList.length ? <PhotoViewer photos={viewList} index={open} onClose={() => setOpen(null)} /> : null}
    </View>
  );
}

// groups: from papersFor() – [{ label, photos: [{ uri, cloudUrl, driveId, pdf, caption }] }]
export function Papers({ groups, testID = 'papers', size = 110, empty = 'No photo or paper saved with this.' }) {
  const list = (groups || []).filter((g) => g && g.photos && g.photos.length);
  if (!list.length) return <Text testID={`${testID}-none`} style={{ fontSize: 14, color: C.sub }}>{empty}</Text>;
  return <View testID={testID} style={{ gap: 12 }}>{list.map((g, i) => <Group key={`${g.label}-${i}`} g={g} testID={`${testID}-${i}`} size={size} />)}</View>;
}
