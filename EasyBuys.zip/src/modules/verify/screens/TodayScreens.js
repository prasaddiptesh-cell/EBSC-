// 1.0.0 Office › Today (map screens o-today, o-inv): one list of everything to check, the business at a glance, and
// the check screens – the papers right there (tap to zoom), who did it and when, an optional comment, then
// "Correct – verify" or "Something is wrong". Shop managers see only their own shop.
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Btn, Banner, Field, Select, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { Hint } from '../../../ui/kit.js';
import { dateStr, money } from '../../../services/core.js';
import * as TD from '../today.js';
import { Papers } from './Papers.js';

const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);
const LEVEL = { bad: C.danger, warn: C.warn };
const shopOptions = () => { try { return [{ value: '', label: 'Both shops' }].concat(require('../../admin/service.js').listShops().map((s) => ({ value: s.code, label: s.name || s.code }))); } catch (e) { return [{ value: '', label: 'Both shops' }]; } };

export function Row({ title, right, sub, level, onPress, testID }) {
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12, paddingHorizontal: 12, borderRadius: 12, backgroundColor: C.card, borderWidth: 1, borderColor: level ? LEVEL[level] : C.border, borderLeftWidth: level ? 6 : 1, opacity: pressed ? 0.7 : 1 })}>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }} numberOfLines={2}>{title}</Text>
        {sub ? <Text style={{ fontSize: 14, color: C.sub }} numberOfLines={2}>{sub}</Text> : null}
      </View>
      {right ? <Text style={{ fontSize: 17, fontWeight: '800', color: level ? LEVEL[level] : C.text }}>{right}</Text> : null}
      {onPress ? <Text style={{ fontSize: 20, color: C.sub }}>›</Text> : null}
    </Pressable>
  );
}
export function Trail({ list, testID = 'trail' }) {
  if (!list || !list.length) return null;
  return (
    <View testID={testID} style={{ gap: 4, backgroundColor: '#F7F4F0', borderRadius: 12, padding: 10 }}>
      <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub }}>WHO DID WHAT</Text>
      {list.map((t, i) => <Text key={i} style={{ fontSize: 14, color: C.text }}>{`${String(t.at || '').slice(5, 16).replace(' ', ' at ')} · ${t.by_name || t.by || ''} · ${t.label}${t.note ? ` – “${t.note}”` : ''}`}</Text>)}
    </View>
  );
}

// ---------------------------------------------------------------- Today
export function OfficeTodayScreen({ params = {} }) {
  const { nav, user } = useApp();
  const [shop, setShop] = useState(params.shopCode || '');
  const [show, setShow] = useState('all');
  let t = null; let err = null;
  try { t = TD.todayList(user, { shopCode: shop || undefined }); } catch (e) { err = e; }
  if (!t) return <Screen title="Today"><Banner tone="danger" message={`Today could not be worked out: ${err && err.message}`} /></Screen>;
  const d = dateStr();
  const head = `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(`${d}T12:00:00`).getDay()]} ${Number(d.slice(8))} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][Number(d.slice(5, 7)) - 1]}`;
  const groups = TD.GROUPS.filter((g) => t.counts[g.key]);
  const list = show === 'all' ? t.items : t.items.filter((x) => x.group === show);
  return (
    <Screen title="Today" subtitle={`${head}${t.shop ? ` · ${t.shop} only` : ''}`}>
      {t.glance.length ? (
        <View testID="td-glance" style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {t.glance.map((g) => (
            <Pressable key={g.key} testID={`td-glance-${g.key}`} onPress={() => { try { nav.push(g.screen, {}); } catch (e) { /* not for this role */ } }}
              style={{ flexGrow: 1, flexBasis: 100, backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 10 }}>
              <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700' }}>{g.label}</Text>
              <Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{g.value}</Text>
              {g.note ? <Text style={{ fontSize: 12, color: C.warn }}>{g.note}</Text> : null}
            </Pressable>
          ))}
        </View>
      ) : null}
      <View testID="td-strip" style={{ backgroundColor: C.infoSoft || '#E1EAFB', borderRadius: 12, padding: 12 }}>
        <Text style={{ fontSize: 17, color: C.text }}><Text style={{ fontWeight: '800' }}>{`${t.total} to check`}</Text>{` · ${t.done} done today${t.suggestions ? ` · ${t.suggestions} suggestion${t.suggestions === 1 ? '' : 's'}` : ''}`}</Text>
      </View>
      {TD.seesAllShops(user) ? <Select testID="td-shop" label="Shop" value={shop} onChange={setShop} options={shopOptions()} /> : null}
      {groups.length > 1 ? <Select testID="td-show" label="Show" value={show} onChange={setShow} options={[{ value: 'all', label: `Everything (${t.items.length})` }].concat(groups.map((g) => ({ value: g.key, label: `${g.label} (${t.counts[g.key]})` })))} /> : null}
      {!t.items.length ? <Banner testID="td-clear" tone="success" title="Nothing to check" message="Everything is verified. Well done." /> : null}
      {(show === 'all' ? groups : groups.filter((g) => g.key === show)).map((g) => (
        <View key={g.key} style={{ gap: 6 }}>
          <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub, letterSpacing: 0.5, marginTop: 6 }}>{g.label.toUpperCase()}</Text>
          {list.filter((x) => x.group === g.key).slice(0, 150).map((x) => (
            <Row key={x.key} testID={`td-${x.key}`} title={x.title} sub={[x.sub, x.shop && !t.shop ? x.shop : ''].filter(Boolean).join(' · ')} right={x.amount ? $(x.amount) : ''} level={x.level}
              onPress={() => { try { nav.push(x.screen, x.params || {}); } catch (e) { /* screen not allowed */ } }} />
          ))}
          {list.filter((x) => x.group === g.key).length > 150 ? <Hint>{`Showing the first 150 of ${list.filter((x) => x.group === g.key).length}.`}</Hint> : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- check an invoice (o-inv)
export function TodayInvoiceScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [note, setNote] = useState('');
  const AP = require('../../payables/service.js');
  const i = AP.getInvoice(params.uid);
  if (!i) return <Screen title="Invoice"><Banner tone="warn" message="This invoice is not here any more." /></Screen>;
  let lines = null;
  try { const r = require('../../../db/connection.js').db().get("SELECT lines FROM inv_receipts WHERE invoice_uid = ? AND IFNULL(status,'active') <> 'void' ORDER BY created_at DESC LIMIT 1", [i.uid]); lines = r ? JSON.parse(r.lines || '[]') : null; } catch (e) { lines = null; }
  const key = `ap_invoices:${i.uid}`;
  const trail = require('../trail.js').trailFor(key);
  const papers = require('../papers.js').papersFor({ table: 'ap_invoices', uid: i.uid });
  const mayCheck = can('invoices_check') || ['owner', 'admin'].includes(user.role);
  const go = (ok) => {
    try { TD.verifyInvoice(user, i.uid, { note, ok }); ui.toast(ok ? 'Verified' : 'Sent back with your comment'); nav.pop(); } catch (e) { ui.error(e); }
  };
  return (
    <Screen title={i.invoice_no || '(no number)'} subtitle={i.supplier_name}>
      <Papers groups={papers} testID="ti-papers" size={150} empty="No photo of this invoice was saved." />
      <Row title="Amount" right={$(i.total)} />
      <Row title="VAT" right={$(i.vat)} />
      {lines ? <Row title="Products" right={`${lines.length} matched`} sub={lines.slice(0, 4).map((l) => `${l.name} × ${l.qty}`).join(', ')} /> : <Row title="Products" right="none – a bill" />}
      <Row title="Received by" right={`${i.entered_by_name || '?'} · ${String(i.entered_at || '').slice(5, 16)}`} />
      {i.shop_code ? <Row title="Shop" right={i.shop_code} /> : null}
      <Trail list={trail} />
      {i.status === 'to_check' && mayCheck ? (
        <>
          <Field testID="ti-note" label="Comment (optional)" value={note} onChangeText={setNote} multiline placeholder="e.g. checked against the paper" />
          <Btn testID="ti-ok" title="Correct – verify" icon="✓" variant="success" onPress={() => go(true)} />
          <Btn testID="ti-bad" title="Something is wrong" variant="secondary" onPress={() => { if (!note.trim()) { ui.alert({ title: 'Write what is wrong', message: 'Type a comment first – it goes to the person who received it.', tone: 'warn' }); return; } go(false); }} />
        </>
      ) : <Banner tone={i.status === 'approved' ? 'success' : 'info'} message={i.status === 'approved' ? `Checked by ${i.checked_by_name} · ${String(i.checked_at || '').slice(5, 16)}` : 'You can look at it; the office checks it.'} />}
      <Btn testID="ti-open" title="Open the whole invoice" size="md" variant="ghost" onPress={() => nav.push('ApInvoice', { uid: i.uid })} />
    </Screen>
  );
}

// ---------------------------------------------------------------- any other item on Today
export function TodayItemScreen({ params = {} }) {
  const { nav, user, can } = useApp();
  const ui = useUI();
  const [note, setNote] = useState('');
  let x = null;
  try { x = TD.todayItem(user, params.key); } catch (e) { x = null; }
  if (!x) return <Screen title="Check"><Banner tone="success" message="Nothing left to check here – it was verified." /></Screen>;
  const papers = TD.itemPapers(x);
  const trail = TD.itemTrail(x);
  const may = (can('verify_money') || ['owner', 'admin'].includes(user.role)) && ['person', 'confirm'].includes(x.how);
  const go = (ok) => { try { TD.verifyToday(user, x, { note, ok }); ui.toast(ok ? 'Verified' : 'Marked – something is wrong'); nav.pop(); } catch (e) { ui.error(e); } };
  return (
    <Screen title={x.title} subtitle={[x.date, x.shop].filter(Boolean).join(' · ')}>
      {x.amount ? <Row title="Amount" right={$(x.amount)} /> : null}
      {x.sub ? <Text style={{ fontSize: 16, color: C.text }}>{x.sub}</Text> : null}
      <Papers groups={papers} testID="tx-papers" size={150} />
      <Trail list={trail} />
      {x.query ? <Banner tone={x.query.status === 'answered' ? 'success' : 'warn'} message={`❓ ${x.query.asked_by_name}: ${x.query.question}${x.query.answer ? `\n💬 ${x.query.answered_by_name}: ${x.query.answer}` : '\nWaiting for the answer.'}`} /> : null}
      {may ? (
        <>
          <Field testID="tx-note" label="Comment (optional)" value={note} onChangeText={setNote} multiline />
          <Btn testID="tx-ok" title="Correct – verify" icon="✓" variant="success" onPress={() => go(true)} />
          <Btn testID="tx-bad" title="Something is wrong" variant="secondary" onPress={() => { if (!note.trim()) { ui.alert({ title: 'Write what is wrong', message: 'Type a comment first.', tone: 'warn' }); return; } go(false); }} />
        </>
      ) : null}
      {x.go && x.go[0] ? <Btn testID="tx-open" title="Open it" size="md" variant="info" onPress={() => nav.push(x.go[0], x.go[1] || {})} /> : null}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff: saved (s-saved)
export function SavedDoneScreen({ params = {} }) {
  const { nav } = useApp();
  return (
    <Screen title="Saved">
      <Text testID="saved-ok" style={{ fontSize: 80, textAlign: 'center', color: C.success }}>✓</Text>
      <Text style={{ fontSize: 18, textAlign: 'center', color: C.text }}>{params.text || 'Sent to the office to check. You can still fix it until it is checked.'}</Text>
      <Btn testID="saved-home" title="Back to home" variant="success" onPress={() => nav.home()} />
    </Screen>
  );
}
