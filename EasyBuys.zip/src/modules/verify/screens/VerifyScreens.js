// To verify (2nd step for every money record), staff photos of invoices / cheques, and the alert settings.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, PhotoPicker, Label, useApp, useUI } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { setupViberChannel } from '../../../platform/cloud.js';
import * as V from '../service.js';

const { $ } = V;
const shopChips = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const HOW = { bank: { label: 'Checked by the bank', color: C.info }, person: { label: 'Checked by a person', color: C.warn }, confirm: { label: 'Photo to confirm', color: C.primary }, pay: { label: 'To pay', color: C.danger } };

export function VerifyScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [show, setShow] = useState('waiting');
  const [kind, setKind] = useState(params.kind || 'all');
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const all = V.queue({ include: show === 'done' ? 'done' : 'waiting' });
  const list = all.filter((x) => kind === 'all' || x.how === kind || (kind === 'late' && x.late));
  const sum = V.queueSummary();
  const rules = V.verifyRules();
  return (
    <Screen title="To verify" subtitle="Step 2 for every money record">
      <Explain title="How verifying works">
        Every money record has two steps. Step 1: someone records it (a deposit, a cheque, cash paid out, petty cash, a photo of an invoice). Step 2: it is checked.{'\n\n'}
        • Bank items (deposits, cheques, transfers) are verified when they show on the bank statement – tick "Seen in the bank" here or in the bank reconciliation.{'\n'}
        • Cash items are verified by a person who has checked the cash, the receipt or the signature.{'\n'}
        • Photos taken by staff are confirmed by a supervisor or admin.{'\n'}
        {rules.secondPerson ? 'The admin has set that a different person must do step 2.' : 'The same person may do both steps (the admin can change this).'}
      </Explain>
      <Stats items={[
        { label: 'Waiting', value: String(sum.waiting), sub: $(sum.value), onPress: () => setKind('all') },
        { label: 'Late', value: String(sum.late), color: sum.late ? C.danger : undefined, sub: 'not in the bank yet', onPress: () => setKind('late') },
        { label: 'Photos to confirm', value: String(sum.photos), onPress: () => setKind('confirm') },
        { label: 'Cash to check', value: String(sum.cash), onPress: () => setKind('person') },
      ]} />
      {can('snap_upload') ? <Btn testID="vf-snap" title="Take a photo of an invoice or cheque" icon="📷" variant="info" onPress={() => nav.push('Snap', {})} /> : null}
      <Chips value={kind} onChange={setKind} testIDPrefix="vf-k" options={[{ value: 'all', label: 'All' }, { value: 'late', label: 'Late' }, { value: 'confirm', label: 'Photos' }, { value: 'person', label: 'Cash' }, { value: 'bank', label: 'Bank' }]} />
      <Chips value={show} onChange={setShow} testIDPrefix="vf-s" options={[{ value: 'waiting', label: 'Waiting' }, { value: 'done', label: 'Done' }]} />
      {!list.length ? <Text style={{ color: C.sub, fontSize: 16 }}>{show === 'waiting' ? 'Nothing waiting – everything is verified.' : 'Nothing here.'}</Text> : null}
      {list.slice(0, 200).map((x) => (
        <View key={x.key} style={{ gap: 6 }}>
          <ListItem testID={`vf-${x.key}`} onPress={() => { setOpen(open === x.key ? null : x.key); setNote(''); }} title={`${x.type}${x.shop ? ` · ${x.shop}` : ''}`}
            sub={`${x.date} · ${x.who || ''}${x.text ? ` · ${x.text}` : ''}${x.doneText ? ` · ${x.doneText}` : ''}`} right={x.amount === null || x.amount === undefined ? '' : $(x.amount)}
            badge={x.late ? 'LATE' : x.problem ? 'PROBLEM' : HOW[x.how].label} badgeColor={x.late || x.problem ? C.danger : HOW[x.how].color} tone={x.late ? 'danger' : undefined} />
          {open === x.key ? (
            <Card>
              {x.how === 'confirm' ? <PhotoStrip photos={photosFor(listPhotos('snap', x.uid).map((p) => p.uri), x.photos, x.type)} /> : null}
              {x.how === 'bank' && !x.done ? (
                <>
                  <Hint>Look at the bank statement or internet banking. When this amount is there, tap below. (Bank reconciliation does the same.)</Hint>
                  {can('bank_rec') || can('verify_money') ? <Btn testID="vf-bank" title="Seen in the bank today" icon="🏦" size="md" variant="success" onPress={() => act(() => V.seenInBank(user, x, dateStr()), 'Verified – seen in the bank')} /> : null}
                </>
              ) : null}
              {x.how === 'person' && !x.done && can('verify_money') ? (
                <>
                  <Hint>Check the cash, the receipt or the signed slip. If it is right, verify it. If not, say what is wrong – it stays on the list as a problem.</Hint>
                  <Field testID="vf-note" label="Note (needed for a problem)" value={note} onChangeText={setNote} />
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    <Btn testID="vf-ok" title="Verified ✓" size="md" variant="success" style={{ flex: 1 }} onPress={() => act(() => V.verify(user, { table: x.table, uid: x.uid, recordedByUid: x.recordedByUid, note }), 'Verified')} />
                    <Btn testID="vf-problem" title="Problem" size="md" variant="danger" style={{ flex: 1 }} onPress={() => act(() => V.verify(user, { table: x.table, uid: x.uid, recordedByUid: x.recordedByUid, note, ok: false }), 'Marked as a problem')} />
                  </View>
                </>
              ) : null}
              {x.how === 'confirm' && !x.done && can('verify_money') ? (
                x.linkTable === 'ap_invoices' ? (
                  <>
                    <Hint>This photo was entered as an invoice. Open it, check the supplier, invoice number and total, and tap "Checked" – the photo is then confirmed too.</Hint>
                    <Btn testID="vf-open-inv" title="Open the invoice" size="md" variant="info" onPress={() => nav.push('ApInvoice', { uid: x.linkUid })} />
                    <ReasonButton title="Reject (not a real invoice / duplicate)" prompt="What is wrong?" confirm="Reject" onDo={(w) => act(() => V.rejectSnap(user, x.snapUid, w), 'Rejected')} />
                  </>
                ) : (
                  <>
                    <Hint>Check the photo against the cheque book / the cheque, the amount and who took it.</Hint>
                    <Btn testID="vf-confirm" title="Confirm" size="md" variant="success" onPress={() => act(() => V.confirmSnap(user, x.snapUid), 'Confirmed')} />
                    <ReasonButton title="Reject" prompt="What is wrong?" confirm="Reject" onDo={(w) => act(() => V.rejectSnap(user, x.snapUid, w), 'Rejected')} />
                  </>
                )
              ) : null}
              {x.how === 'pay' ? <Btn title="Open FNPF & tax payments" size="md" variant="info" onPress={() => nav.push('Statutory', {})} /> : null}
              {x.done && x.how === 'person' && can('verify_money') ? <ReasonButton title="Undo the verification" prompt="Why?" confirm="Undo" onDo={(w) => act(() => V.unverify(user, x.table, x.uid, w), 'Undone')} /> : null}
              {x.go ? <Btn title="Open the record" size="sm" variant="ghost" onPress={() => nav.push(x.go[0], x.go[1])} /> : null}
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff photo
export function SnapScreen({ params }) {
  const { nav, user } = useApp();
  const ui = useUI();
  const [kind, setKind] = useState(params.kind || 'invoice');
  const [shop, setShop] = useState(user.shop_code || (shopChips()[0] && shopChips()[0].value) || 'S1');
  const [photos, setPhotos] = useState([]);
  const [party, setParty] = useState('');
  const [refNo, setRefNo] = useState('');
  const [amount, setAmount] = useState('');
  const [collectedBy, setCollectedBy] = useState('');
  const [note, setNote] = useState('');
  const [done, setDone] = useState(null);
  const rules = V.verifyRules();
  const save = () => {
    try {
      const r = V.snap(user, { kind, shopCode: shop, amount, party, refNo, note, photos, collectedBy });
      setDone(r);
      ui.toast('Saved – a supervisor will confirm it');
    } catch (e) { ui.error(e); }
  };
  if (done) {
    return (
      <Screen title="Photo saved" subtitle="Waiting for a supervisor to confirm">
        <Banner tone="success" title="Saved" message="It is on the supervisor's To verify list. Thank you." />
        {done.message && rules.viberMode === 'share' ? (
          <>
            <Hint>{`Tell the "${rules.viberGroup}" Viber group: tap below, then pick the group and press send.`}</Hint>
            <Btn testID="snap-viber" title="Tell the Viber group" icon="💬" variant="info" onPress={() => Promise.resolve(Linking.openURL(V.viberShareLink(done.message))).catch(() => ui.alert({ title: 'Viber did not open', message: 'Is Viber installed on this device?' }))} />
          </>
        ) : null}
        {done.message && rules.viberMode === 'channel' ? <Hint>The Viber alert goes out by itself when this device is online.</Hint> : null}
        <Btn testID="snap-another" title="Take another" size="md" variant="secondary" onPress={() => { setDone(null); setPhotos([]); setParty(''); setRefNo(''); setAmount(''); setNote(''); setCollectedBy(''); }} />
        <Btn title="Done" size="md" variant="success" onPress={() => nav.pop()} />
      </Screen>
    );
  }
  return (
    <Screen title="Photo of an invoice or cheque" subtitle="A supervisor or admin confirms it"
      footer={<Btn testID="snap-save" title="Save the photo" icon="📷" variant="success" onPress={save} />}>
      <Label>What is it?</Label>
      <Chips value={kind} onChange={setKind} testIDPrefix="snap-k" options={Object.entries(V.SNAP_KIND).map(([value, label]) => ({ value, label }))} />
      <Hint>{{
        invoice: 'A supplier left an invoice / delivery note. Take a clear photo of the whole page – it is read by Google and goes to the office to be checked and paid.',
        cheque_given: 'A cheque from Easy Buys was handed to someone (e.g. a supplier\'s driver). Photograph the cheque and write who took it.',
        cheque_received: 'A customer paid with a cheque. Photograph the front of the cheque.',
        receipt: 'Any other paper that has to do with money (a receipt, a credit note…).',
      }[kind]}</Hint>
      <Label>Shop</Label>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="snap-shop" />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo" required testID="snap-photo" />
      <Field testID="snap-party" label={kind === 'cheque_received' ? 'Customer' : kind === 'cheque_given' ? 'Paid to (supplier)' : 'Supplier'} value={party} onChangeText={setParty} />
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="snap-ref" label={kind.startsWith('cheque') ? 'Cheque number' : 'Invoice number'} value={refNo} onChangeText={setRefNo} /></View>
        <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="snap-amount" label="Amount (if you can see it)" value={amount} onChange={setAmount} /></View>
      </View>
      {kind === 'cheque_given' ? <Field testID="snap-who" label="Name of the person who took the cheque" value={collectedBy} onChangeText={setCollectedBy} /> : null}
      <Field label="Note (optional)" value={note} onChangeText={setNote} />
    </Screen>
  );
}

export function MySnapsScreen() {
  const { user } = useApp();
  const list = V.listSnaps({ byUid: user.uid, limit: 100 });
  return (
    <Screen title="My photos" subtitle="Invoices and cheques I photographed">
      {!list.length ? <Text style={{ color: C.sub }}>None yet.</Text> : null}
      {list.map((s) => <ListItem key={s.uid} title={`${V.SNAP_KIND[s.kind]}${s.party ? ` · ${s.party}` : ''}`} sub={`${s.snap_date} · ${s.shop_code}${s.ref_no ? ` · no. ${s.ref_no}` : ''}`}
        right={s.amount === null ? '' : $(s.amount)} badge={s.status === 'waiting' ? 'WAITING' : s.status === 'confirmed' ? 'CONFIRMED' : 'REJECTED'} badgeColor={s.status === 'confirmed' ? C.success : s.status === 'waiting' ? C.warn : C.danger} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings
export function VerifySetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [r, setR] = useState(V.verifyRules());
  const [token, setToken] = useState('');
  const [oldToken, setOldToken] = useState('');
  const [busy, setBusy] = useState(false);
  const connect = async () => {
    setBusy(true);
    const res = await setupViberChannel(token, oldToken);
    setBusy(false);
    ui.alert({ title: res.ok ? 'Viber Channel' : 'Not connected', message: res.message, tone: res.ok ? 'primary' : 'danger' });
  };
  return (
    <Screen title="Verification & Viber alerts" subtitle="Admin settings">
      <Section title="Verifying">
        <Chips value={r.secondPerson ? 'y' : 'n'} onChange={(v) => setR({ ...r, secondPerson: v === 'y' })} testIDPrefix="vs-2nd" options={[{ value: 'n', label: 'Same person may verify' }, { value: 'y', label: 'A different person must verify' }]} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag deposits / transfers not in the bank after (days)" value={String(r.bankDays)} onChangeText={(v) => setR({ ...r, bankDays: v })} keyboardType="number-pad" /></View>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag cheques not cleared after (days)" value={String(r.chequeDays)} onChangeText={(v) => setR({ ...r, chequeDays: v })} keyboardType="number-pad" /></View>
        </View>
      </Section>
      <Section title="Viber alerts">
        <Chips value={r.viberMode} onChange={(v) => setR({ ...r, viberMode: v })} testIDPrefix="vs-mode" options={[{ value: 'off', label: 'Off' }, { value: 'share', label: 'One tap to a Viber group' }, { value: 'channel', label: 'Automatic (Viber Channel)' }]} />
        <Explain title="Which one?">
          One tap: after something happens, Viber opens with the message written – pick the group and press send. Works with any normal Viber group.{'\n\n'}
          Automatic: Viber only lets apps post by themselves to a Viber Channel (not a normal group). Create a channel in Viber (e.g. "Easy Buys Alerts"), add the people who should get the alerts,
          then in the channel open Settings › Developer tools, copy the token and paste it below. Alerts are sent through the Easy Buys cloud when the device is online.
        </Explain>
        {r.viberMode === 'share' ? <Field label="Name of the Viber group (shown to staff)" value={r.viberGroup} onChangeText={(v) => setR({ ...r, viberGroup: v })} /> : null}
        {r.viberMode === 'channel' ? (
          <>
            <Field testID="vs-token" label="Viber Channel token" value={token} onChangeText={setToken} placeholder="paste the token" />
            <Field label="Current token (only when replacing one already connected)" value={oldToken} onChangeText={setOldToken} />
            <Btn title={busy ? 'Connecting…' : 'Connect and send a test message'} size="md" variant="info" disabled={busy || (!token.trim() && !oldToken.trim())} onPress={connect} />
          </>
        ) : null}
        <Label>Send an alert when</Label>
        {Object.entries(V.EVENT_LABEL).map(([k, label]) => (
          <Chips key={k} value={r.events[k] ? 'y' : 'n'} onChange={(v) => setR({ ...r, events: { ...r.events, [k]: v === 'y' } })} testIDPrefix={`vs-ev-${k}`} options={[{ value: 'y', label: `✓ ${label}` }, { value: 'n', label: 'No' }]} />
        ))}
      </Section>
      <Btn testID="vs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => V.saveVerifyRules(user, r), 'Saved')} />
      <Section title="Recent alerts">
        {V.recentAlerts(20).map((a) => <ListItem key={a.uid} title={a.text} sub={`${String(a.at).slice(0, 16)} · ${a.mode}`} />)}
      </Section>
    </Screen>
  );
}
