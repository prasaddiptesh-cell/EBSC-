// To verify (2nd step for every money record), staff photos of invoices / cheques, and the alert settings.
import React, { useState } from 'react';
import { View, Linking, Pressable } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Badge, Chips, Field, Row, Section, PhotoPicker, Label, Select, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { usePaper, PaperPhoto } from '../../../ui/paperPhoto.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { PhotoStrip, PhotoViewer, photosFor } from '../../../ui/photoView.js';
import * as Q from '../queries395.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { setupViberChannel } from '../../../platform/cloud.js';
import * as V from '../service.js';
import * as AP from '../../payables/service.js';
import * as CB from '../../payables/chequebooks.js';
import { listPOs } from '../../inventory/service.js';
import { ChequeNoPicker } from '../../payables/screens/ChequePicker.js';
import { SignaturePad } from '../../../ui/signature.js';

const { $ } = V;
const shopChips = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const HOW = { bank: { label: 'Checked by the bank', color: C.info }, person: { label: 'Checked by a person', color: C.warn }, confirm: { label: 'Photo to confirm', color: C.primary }, pay: { label: 'To pay', color: C.danger }, record: { label: 'To record', color: C.danger }, explain: { label: 'Explain it', color: C.danger } };

// v3.9.5 To verify: the owner's one place to confirm what staff did. Each item shows who did it, what it is, anything
// that does not match, and every record or paper joined to it (one tap opens it). "✓ Verified" or "Query" (asks the
// person who did it; their answer comes back here).
const GROUPS = {
  invoices: { label: 'Orders, invoices & deliveries', test: (x) => x.table === 'inv_receipts' || x.table === 'po_orders' || (x.table === 'money_snaps' && x.how === 'confirm' && /Invoice|Receipt/.test(x.type || '')) },
  cheques: { label: 'Cheques', test: (x) => x.table === 'cheques' || x.how === 'record' || (x.table === 'money_snaps' && /Cheque/.test(x.type || '')) },
  bank: { label: 'In the bank', test: (x) => x.how === 'bank' },
  cash: { label: 'Cash', test: (x) => x.how === 'person' && ['ap_payments', 'cash_moves', 'staff_debts', 'pay_cash'].includes(x.table) },
  tills: { label: 'Tills & handovers', test: (x) => ['aronium_eods', 'handovers'].includes(x.table) },
  checklists: { label: 'Checklists', test: (x) => x.table === 'duty_runs' },
};
const KIND_TONE = { invoices: ['#E1EAFB', '#2F5FC4'], cheques: ['#FEF0C7', '#B45309'], bank: ['#DDF4E4', '#157F3B'], cash: ['#FBE4E4', '#C8242A'], tills: ['#EDE7E3', '#2B1A1C'], checklists: ['#EDE7E3', '#6B6160'] };
const groupOf = (x) => Object.keys(GROUPS).find((g) => GROUPS[g].test(x)) || 'cash';

function DocChips({ docs, nav, testID }) {
  const [view, setView] = useState(null);
  if (!docs || !docs.length) return null;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
      {docs.map((d, i) => (
        <Pressable key={`${d.label}-${i}`} testID={`${testID}-doc-${i}`} onPress={() => (d.photos ? setView(d.photos) : nav.push(d.screen, d.params || {}))}
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.infoSoft || '#E1EAFB', borderRadius: 8, paddingVertical: 6, paddingHorizontal: 10, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 14 }}>{d.photos ? '🖼️' : '📄'}</Text>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.info }}>{d.label}</Text>
        </Pressable>
      ))}
      {view ? <PhotoViewer photos={view} onClose={() => setView(null)} /> : null}
    </View>
  );
}

const shopTitle = (code) => { try { const r = require('../../../db/connection.js').db().get('SELECT name FROM shops WHERE code = ?', [code]); return (r && r.name) || code; } catch (e) { return code; } };
export function VerifyScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [show, setShow] = useRemembered('show', 'waiting');
  const [kind, setKind] = useRemembered('kind395', params.kind || 'all');
  const [open, setOpen] = useState(null); // key of the item whose Query box is open
  const [note, setNote] = useState('');
  const all = V.queue({ include: show === 'done' ? 'done' : 'waiting', withDocs: true });
  const list = all.filter((x) => kind === 'all' || (kind === 'late' && x.late) || (kind === 'record' && x.how === 'record') || (kind === 'confirm' && x.how === 'confirm') || (kind === 'person' && x.how === 'person') || (GROUPS[kind] && GROUPS[kind].test(x)));
  const sum = V.queueSummary();
  const queries = all.filter((x) => x.query && x.query.status === 'open').length;
  const answered = all.filter((x) => x.query && x.query.status === 'answered').length;
  const rules = V.verifyRules();
  const count = (g) => all.filter((x) => GROUPS[g].test(x)).length;
  const mayVerify = can('verify_money');
  const ask = (x) => act(() => { Q.askQuery(user, { key: x.key, table: x.table, uid: x.uid, title: `${x.type}${x.amount !== null && x.amount !== undefined ? ` ${$(x.amount)}` : ''}`, toUid: x.recordedByUid, toName: x.who, question: note, nav: x.go ? { screen: x.go[0], params: x.go[1] } : null }); setOpen(null); setNote(''); }, 'Query sent – the answer comes back here');
  return (
    <Screen title="To verify" subtitle={`Everything staff did that you confirm · ${sum.waiting} waiting`}>
      <Btn testID="vf-to-today" title="Today – everything to check in one list" icon="📋" size="md" variant="info" onPress={() => nav.push('OfficeToday', {})} />
      <Explain title="How verifying works">
        Everything staff record lands here: invoices and deliveries, cheques handed over and whether they cleared the bank, cash paid out, till differences, handovers and checklists. Open the papers joined to an item (one tap), then tap "✓ Verified". If something is not right, tap "Query" and ask the person who did it – the question shows on their Home and the answer comes back here.{'\n\n'}
        Bank items (deposits, cheques, transfers) are verified when they show on the bank statement – tick "Seen in the bank" here or in the bank reconciliation.{'\n'}
        {rules.secondPerson ? 'The admin has set that a different person must verify.' : 'The same person may record and verify (the admin can change this).'}
      </Explain>
      <Stats items={[
        { label: 'Waiting', value: String(sum.waiting), sub: $(sum.value), onPress: () => setKind('all') },
        { label: 'Late', value: String(sum.late), color: sum.late ? C.danger : undefined, sub: 'not in the bank yet', onPress: () => setKind('late') },
        { label: 'Queries', value: String(queries), sub: answered ? `${answered} answered` : 'waiting for an answer', color: answered ? C.success : undefined },
      ]} />
      <Chips value={kind} onChange={setKind} testIDPrefix="vf-k" options={[{ value: 'all', label: `All ${all.length}` }].concat(Object.keys(GROUPS).map((g) => ({ value: g, label: `${GROUPS[g].label} ${count(g)}` })),
        [{ value: 'late', label: `Late ${all.filter((x) => x.late).length}` }, { value: 'record', label: 'Cheques to record' }])} />
      <Chips value={show} onChange={setShow} testIDPrefix="vf-s" options={[{ value: 'waiting', label: 'Waiting' }, { value: 'done', label: 'Done' }]} />
      {!list.length ? <Text style={{ color: C.sub, fontSize: 16 }}>{show === 'waiting' ? 'Nothing waiting – everything is verified.' : 'Nothing here.'}</Text> : null}
      {list.slice(0, 200).map((x, i, arr) => {
        const g = groupOf(x);
        const head = i === 0 || (arr[i - 1].shop || '') !== (x.shop || '') ? (x.shop ? shopTitle(x.shop) : 'Whole business (no shop)') : null;
        const [bg, ink] = KIND_TONE[g];
        const qy = x.query;
        return (
          <React.Fragment key={x.key}>
          {head ? <Text testID={`vf-head-${x.shop || 'none'}`} style={{ fontSize: 18, fontWeight: '900', color: C.text, marginTop: 8 }}>{head}</Text> : null}
          <View testID={`vf-${x.key}`} style={{ backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: x.late || x.problem ? C.danger : C.border, padding: 14, gap: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <View style={{ backgroundColor: bg, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 }}><Text style={{ fontSize: 12, fontWeight: '800', color: ink, letterSpacing: 0.5 }}>{GROUPS[g].label.toUpperCase()}</Text></View>
              <Text style={{ fontSize: 13, color: C.sub, fontWeight: '600', flex: 1 }}>{[x.who, x.date, x.at && String(x.at).length >= 16 ? String(x.at).slice(11, 16) : null].filter(Boolean).join(' · ')}</Text>
              {x.late ? <Badge text="LATE" color={C.danger} /> : x.problem ? <Badge text="PROBLEM" color={C.danger} /> : qy ? <Badge text={qy.status === 'answered' ? 'ANSWERED' : 'QUERY'} color={qy.status === 'answered' ? C.success : C.warn} /> : null}
            </View>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{`${x.type}${x.amount === null || x.amount === undefined ? '' : ` · ${$(x.amount)}`}`}</Text>
            {x.text ? <Text style={{ fontSize: 15, color: C.text }}>{x.text}</Text> : null}
            {x.flag ? <Text style={{ fontSize: 14, fontWeight: '700', color: C.danger }}>{x.flag}</Text> : null}
            {(x.reasons || []).map((r, i) => <Text key={i} style={{ fontSize: 14, fontWeight: '700', color: C.danger }}>{`• ${r}`}</Text>)}
            {x.doneText ? <Text style={{ fontSize: 14, color: C.success, fontWeight: '700' }}>{x.doneText}</Text> : null}
            {qy ? (
              <View style={{ backgroundColor: qy.status === 'answered' ? '#DDF4E4' : '#FEF0C7', borderRadius: 10, padding: 10, gap: 2 }}>
                <Text style={{ fontSize: 14, color: C.text }}>{`❓ ${qy.asked_by_name} asked ${qy.to_name || ''}: ${qy.question}`}</Text>
                {qy.answer ? <Text style={{ fontSize: 14, color: C.text, fontWeight: '700' }}>{`💬 ${qy.answered_by_name}: ${qy.answer}`}</Text> : <Text style={{ fontSize: 13, color: C.sub }}>Waiting for the answer.</Text>}
              </View>
            ) : null}
            <DocChips docs={x.docs} nav={nav} testID={`vf-${x.key}`} />
            {!x.done ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
                {x.how === 'bank' && (can('bank_rec') || mayVerify) ? <Btn testID="vf-bank" title="✓ Seen in the bank" size="md" variant="success" onPress={() => act(() => V.seenInBank(user, x, dateStr()), 'Verified – seen in the bank')} /> : null}
                {x.how === 'person' && mayVerify ? <Btn testID="vf-ok" title="✓ Verified" size="md" variant="success" onPress={() => act(() => V.verify(user, { table: x.table, uid: x.uid, recordedByUid: x.recordedByUid, note: '' }), 'Verified')} /> : null}
                {x.how === 'confirm' && mayVerify && x.linkTable === 'ap_invoices' ? <Btn testID="vf-open-inv" title="Check the invoice" size="md" variant="info" onPress={() => nav.push('ApInvoice', { uid: x.linkUid })} /> : null}
                {x.how === 'confirm' && mayVerify && x.linkTable !== 'ap_invoices' ? <Btn testID="vf-confirm" title="✓ Verified" size="md" variant="success" onPress={() => act(() => V.confirmSnap(user, x.snapUid), 'Verified')} /> : null}
                {x.how === 'record' ? (x.notInBook ? <Btn testID="vf-add-book" title="Open Cheque books & stubs" size="md" variant="info" onPress={() => nav.push('ChequeBooks', {})} />
                  : <Btn testID="vf-record" title="Record the payment" icon="💸" size="md" variant="success" onPress={() => nav.push('ApPay', x.go[1])} />) : null}
                {x.how === 'pay' ? <Btn title="Open FNPF & tax payments" size="md" variant="info" onPress={() => nav.push('Statutory', {})} /> : null}
                {x.how === 'approve' ? <Btn testID="vf-approve" title="Open the order to authorise" size="md" variant="success" onPress={() => nav.push('POView', { uid: x.uid })} /> : null}
                {x.how === 'explain' && x.go ? <Btn testID="vf-explain" title="Explain it" size="md" variant="info" onPress={() => nav.push(x.go[0], x.go[1])} /> : null}
                {mayVerify && x.how !== 'pay' ? <Btn testID={`vf-query-${x.key}`} title="Query" size="md" variant="secondary" onPress={() => { setOpen(open === x.key ? null : x.key); setNote(''); }} /> : null}
                {x.how === 'confirm' && mayVerify ? <ReasonButton title={x.linkTable === 'ap_invoices' ? 'Reject (not real / duplicate)' : 'Reject'} prompt="What is wrong?" confirm="Reject" size="md" onDo={(w) => act(() => V.rejectSnap(user, x.snapUid, w), 'Rejected')} /> : null}
              </View>
            ) : null}
            {open === x.key ? (
              <Card>
                <Hint>{`Ask ${x.who || 'the person who did it'}. The question shows on their Home and goes to Viber; their answer comes back here.`}</Hint>
                <Field testID="vf-query-text" label="Question" value={note} onChangeText={setNote} placeholder="e.g. The invoice says 15 bags – where is the 15th?" multiline />
                <Btn testID="vf-query-send" title="Send the query" icon="❓" size="md" variant="warn" onPress={() => ask(x)} />
              </Card>
            ) : null}
            {x.done && x.how === 'person' && mayVerify ? <ReasonButton title="Undo the verification" prompt="Why?" confirm="Undo" size="sm" onDo={(w) => act(() => V.unverify(user, x.table, x.uid, w), 'Undone')} /> : null}
          </View>
          </React.Fragment>
        );
      })}
    </Screen>
  );
}

// v3.9.5 questions from To verify for the person who did the work (shown on their Home); they answer here.
export function MyQueriesScreen() {
  const { nav, user } = useApp();
  const act = useAct();
  const [text, setText] = useState({});
  const list = Q.openQueriesFor(user.uid);
  return (
    <Screen title="Questions for you" subtitle="From the owner or a manager about something you did">
      {!list.length ? <Text style={{ fontSize: 16, color: C.sub }}>No questions – thank you.</Text> : null}
      {list.map((q) => (
        <Card key={q.uid}>
          <Text style={{ fontSize: 13, color: C.sub }}>{`${q.asked_by_name} · ${String(q.asked_at || '').slice(0, 16).replace('T', ' ')}`}</Text>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{q.title || 'An item'}</Text>
          <Text style={{ fontSize: 16, color: C.text }}>{`❓ ${q.question}`}</Text>
          {q.nav && q.nav.screen ? <Btn title="Open it" icon="📄" size="sm" variant="ghost" onPress={() => nav.push(q.nav.screen, q.nav.params || {})} /> : null}
          <Field testID={`mq-text-${q.uid}`} label="Your answer" value={text[q.uid] || ''} onChangeText={(v) => setText((t) => ({ ...t, [q.uid]: v }))} multiline />
          <Btn testID={`mq-send-${q.uid}`} title="Send the answer" icon="💬" size="md" variant="success" onPress={() => act(() => { Q.answerQuery(user, q.uid, text[q.uid]); setText((t) => ({ ...t, [q.uid]: '' })); }, 'Answer sent')} />
        </Card>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff photo
export function SnapScreen({ params }) {
  const { nav, user, can, screens } = useApp();
  const ui = useUI();
  // v3.9.5 mode 'receive' = "Receive goods & invoice" (goods with an invoice, or no goods – just a bill);
  // mode 'cheque' = "Hand over a cheque" (with the signature of the person taking it).
  const mode = params.mode || null;
  const [kind, setKind] = useState(mode === 'cheque' ? 'cheque_given' : mode === 'receive' ? 'invoice' : params.kind || 'invoice');
  const [sig, setSig] = useState(null);
  const [shop, setShop] = useState(params.shopCode || user.shop_code || (shopChips()[0] && shopChips()[0].value) || 'S1');
  const [photos, setPhotos] = useState([]);
  const [party, setParty] = useState('');
  const [supUid, setSupUid] = useState('');
  const [poUid, setPoUid] = useState('');
  const [chq, setChq] = useState('');
  const [refNo, setRefNo] = useState('');
  const [amount, setAmount] = useState('');
  const [collectedBy, setCollectedBy] = useState('');
  const [note, setNote] = useState('');
  const [ticked, setTicked] = useState({});
  const [done, setDone] = useState(null);
  // v3.9 receiving starts here: goods (counted in against the purchase order, or without one – stock is updated) or
  // a bill with no goods (rent, power…), which may be a receipt for a bill already paid.
  const [goods, setGoods] = useState(params.goods || 'stock');
  const [category, setCategory] = useState('');
  const [paid, setPaid] = useState({ method: '', shopCode: '', accountUid: '', chequeNo: '', reference: '' });
  const setP = (k) => (v) => setPaid((o) => ({ ...o, [k]: v, ...(k === 'accountUid' ? { chequeNo: '' } : {}) }));
  const canReceive = can ? can('po_receive') : false;
  // v3.9.2 The photo fills in the supplier, number and amount (a cheque: its number and amount).
  const paperKind = kind === 'cheque_given' || kind === 'cheque_received' ? 'proof' : 'invoice';
  const sp = usePaper(paperKind);
  const snapForm = { supUid, party, refNo, amount };
  const setSnapForm = (fn) => {
    const n = typeof fn === 'function' ? fn(snapForm) : fn;
    if (n.supUid !== supUid) setSupUid(n.supUid || '');
    if (n.party !== party) setParty(n.party || '');
    if (n.refNo !== refNo) setRefNo(n.refNo || '');
    if (n.amount !== amount) setAmount(n.amount || '');
  };
  const SNAP_MAP = paperKind === 'proof' ? { chequeNo: 'refNo', amount: 'amount' } : { supplierUid: 'supUid', newSupplierName: 'party', invoiceNo: 'refNo', total: 'amount' };
  const accounts = AP.listAccounts();
  const rules = V.verifyRules();
  const withSupplier = kind === 'invoice' || kind === 'cheque_given';
  const suppliers = withSupplier ? AP.listSuppliers() : [];
  const sup = supUid ? suppliers.find((x) => x.uid === supUid) : null;
  const typedMatch = !sup && party.trim().length >= 3 ? AP.matchSupplier(party) : null;
  const effSup = sup || typedMatch;
  // Cheque handed over: the drop-down (cheques written for them, next unused, type a number) and the checks.
  const choices = kind === 'cheque_given' && effSup ? CB.chequeChoices(effSup.uid) : [];
  const pick = choices.find((c) => c.value === chq) || null;
  const typing = kind === 'cheque_given' && (!effSup || chq === 'type' || !pick);
  const chequeNo = pick && pick.chequeNo ? pick.chequeNo : refNo;
  const check = kind === 'cheque_given' && String(chequeNo || '').trim() ? CB.checkChequeNo({ chequeNo, supplierUid: effSup ? effSup.uid : undefined, supplierName: party, accountUid: pick ? pick.accountUid : undefined }) : null;
  const recordedCheque = check && check.state === 'recorded' ? check.cheque : null;
  const payment = recordedCheque && recordedCheque.payment_uid ? AP.getPayment(recordedCheque.payment_uid) : null;
  const unpaid = kind === 'cheque_given' && effSup && !recordedCheque ? AP.payableFor(effSup.uid).invoices : [];
  const pos = kind === 'invoice' && effSup ? AP.posForSupplier(effSup.uid) : [];
  const tickedUids = unpaid.filter((i) => ticked[i.uid]).map((i) => i.uid);
  const tickedTotal = unpaid.filter((i) => ticked[i.uid]).reduce((t, i) => t + i.owing, 0);
  const reset = () => { setSig(null); sp.reset(); setDone(null); setPhotos([]); setParty(''); setSupUid(''); setPoUid(''); setChq(''); setRefNo(''); setAmount(''); setNote(''); setCollectedBy(''); setTicked({}); setPaid({ method: '', shopCode: '', accountUid: '', chequeNo: '', reference: '' }); };
  const stockMode = kind === 'invoice' && goods === 'stock' && canReceive;
  let openPos = [];
  try { openPos = stockMode && effSup ? listPOs({ supplierUid: effSup.uid, shopCode: shop, status: 'to_receive', limit: 10 }) : []; } catch (e) { openPos = []; }
  // Goods: go on to count them in (against the order, or without one); the invoice photo and numbers go with them.
  const countIn = (po) => {
    try {
      if (!photos.length) throw Object.assign(new Error('Take a photo of the invoice first.'), { isAppError: true });
      let s0 = sup || typedMatch;
      if (!s0 && party.trim()) s0 = AP.addTypedSupplier(user, party.trim());
      if (!s0) throw Object.assign(new Error('Choose the supplier.'), { isAppError: true });
      const prefill = { invoiceNo: refNo, total: amount, photos };
      nav.replace('POReceive', po ? { poUid: po, prefill } : { shopCode: shop, supplierUid: s0.uid, prefill });
    } catch (e) { ui.error(e); }
  };
  const save = () => {
    if (!sp.okToSave(ui)) return;
    if (stockMode) { sp.log(user, null, null, snapForm, SNAP_MAP); countIn(poUid || null); return; }
    // v3.9.8 paid in cash: say where the cash came from (the safe or which till) – no default.
    if (mode === 'receive' && paid.method === 'cash' && !paid.cashFrom) { ui.alert({ title: 'Where did the cash come from?', message: 'Choose the shop\'s safe or the till it came from.', tone: 'warn' }); return; }
    if (paid.method === 'mpaisa' && (!paid.walletUid || !String(paid.reference || '').trim())) { ui.alert({ title: 'M-PAiSA', message: 'Choose the shop\'s wallet and enter the transaction reference.', tone: 'warn' }); return; }
    try {
      const amt = amount !== '' ? amount : recordedCheque ? recordedCheque.amount : tickedUids.length ? Math.round(tickedTotal * 100) / 100 : '';
      const r = V.snap(user, { kind, shopCode: shop, amount: amt, party: sup ? '' : party, supplierUid: sup ? sup.uid : undefined, poUid: kind === 'invoice' ? poUid || undefined : undefined,
        refNo: kind === 'cheque_given' ? String(chequeNo || '') : refNo, chequeUid: pick && pick.chequeUid ? pick.chequeUid : undefined, accountUid: pick ? pick.accountUid : undefined,
        invoiceUids: kind === 'cheque_given' ? tickedUids : undefined, note, photos, collectedBy, signature: kind === 'cheque_given' ? sig : undefined,
        category: kind === 'invoice' && goods === 'total' ? 'Stock for resale' : kind === 'invoice' && goods === 'bill' ? category || undefined : undefined, paid: kind === 'invoice' && (goods === 'bill' || goods === 'total') && paid.method ? { ...paid, shopCode: paid.shopCode || shop } : undefined });
      sp.log(user, 'verify_items', r && (r.uid || (r.item && r.item.uid)), snapForm, SNAP_MAP);
      sp.reset();
      setDone(r);
      ui.toast('Saved – a supervisor will confirm it');
    } catch (e) { ui.error(e); }
  };
  if (done) {
    return (
      <Screen title="Photo saved" subtitle="Waiting for a supervisor to confirm">
        <Banner tone="success" title="Saved" message="It is on the supervisor's To verify list. Thank you." />
        {done.check && done.check.level !== 'ok' ? <Banner testID="snap-done-check" tone="warn" title="The office will check the cheque number" message={done.check.message} /> : null}
        {done.message && rules.viberMode === 'share' ? (
          <>
            <Hint>{`Tell the "${rules.viberGroup}" Viber group: tap below, then pick the group and press send.`}</Hint>
            <Btn testID="snap-viber" title="Tell the Viber group" icon="💬" variant="info" onPress={() => Promise.resolve(Linking.openURL(V.viberShareLink(done.message))).catch(() => ui.alert({ title: 'Viber did not open', message: 'Is Viber installed on this device?' }))} />
          </>
        ) : null}
        {done.message && rules.viberMode === 'channel' ? <Hint>The Viber alert goes out by itself when this device is online.</Hint> : null}
        <Btn testID="snap-another" title="Take another" size="md" variant="secondary" onPress={reset} />
        <Btn title="Done" size="md" variant="success" onPress={() => nav.pop()} />
      </Screen>
    );
  }
  const title = mode === 'receive' ? 'Receive goods & invoice' : mode === 'cheque' ? 'Hand over a cheque' : 'Receive goods & papers';
  const subtitle = mode === 'receive' ? 'The delivery, the invoice photo and the order – together' : mode === 'cheque' ? 'Photo, who took it, which invoices it pays' : 'Invoices, receipts, cheques – everything received starts here';
  return (
    <Screen title={title} subtitle={subtitle}
      footer={<Btn testID="snap-save" title={stockMode ? 'Next: count the goods in' : mode === 'cheque' ? 'Save – cheque handed over' : mode === 'receive' ? 'Save the bill' : 'Save the photo'} icon={stockMode ? '📦' : '📷'} variant="success" onPress={save} />}>
      {mode === 'receive' ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          {[['1', 'Supplier & order', true], ['2', 'Count the goods', goods === 'stock'], ['3', 'Invoice', true], ['4', 'Save', true]].filter((x) => x[2]).map(([n, t], i) => (
            <View key={n} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: i === 0 ? C.primary : C.border, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: i === 0 ? C.white : C.text, fontWeight: '800', fontSize: 13 }}>{i + 1}</Text></View>
              <Text style={{ fontSize: 15, fontWeight: i === 0 ? '800' : '600', color: i === 0 ? C.text : C.sub }}>{t}</Text>
            </View>
          ))}
        </View>
      ) : null}
      {(() => {
        // 1.0.0 build 3 (owner): every kind of paper in ONE drop-down – no separate buttons for each
        const bakeryShop = shopChips().find((x) => /^BAK/i.test(x.value));
        const canFuel = screens && screens.VeFuel && (() => { try { return screens.VeFuel.can(user); } catch (e) { return false; } })();
        if (mode === 'receive') {
          const opts = [{ value: 'stock', label: '📦 Goods with an invoice' }, { value: 'total', label: '📦 Goods – invoice total only (no products)' }, { value: 'bill', label: '🧾 No goods – just a bill (EFL, rent, repairs…)' }]
            .concat(bakeryShop ? [{ value: 'bakery', label: '🥖 Bakery expense' }] : []).concat(canFuel ? [{ value: 'fuel', label: '⛽ Vehicle refuel' }] : [])
            .concat([{ value: 'other', label: '📷 Something else (cheque received, receipt, other paper)' }]);
          const pick = (v) => {
            if (v === 'other') { nav.replace('Snap', {}); return; }
            if (v === 'fuel') { nav.push('VeFuel', {}); return; }
            if (v === 'bakery') { setKind('invoice'); setGoods('bill'); setShop(bakeryShop.value); setPaid((o) => ({ ...o, method: o.method || 'cash' })); setPoUid(''); return; }
            setGoods(v); setPoUid('');
          };
          return <Select testID="snap-goods" label="What came in?" value={goods} options={opts} onChange={pick} search={false} optionTestID={(v) => (v === 'other' ? 'snap-other-papers' : v === 'fuel' ? 'snap-fuel' : v === 'bakery' ? 'snap-bakery-exp' : `snap-goods-${v}`)} />;
        }
        if (mode) return <Btn testID="snap-other-papers" title="Something else? (cheque received, receipt, other paper)" icon="📷" size="sm" variant="ghost" onPress={() => nav.replace('Snap', {})} />;
        const opts = [{ value: 'invoice', label: '📦 Delivery / invoice' }, { value: 'expense', label: '🧾 Expense paid (receipt)' }].concat(Object.entries(V.SNAP_KIND).filter(([value]) => value !== 'invoice' && value !== 'cheque_written').map(([value, label]) => ({ value, label })))
          .concat(bakeryShop ? [{ value: 'bakery', label: '🥖 Bakery expense' }] : []).concat(canFuel ? [{ value: 'fuel', label: '⛽ Vehicle refuel' }] : []);
        const pick = (v) => {
          setChq(''); setTicked({}); setPoUid('');
          if (v === 'fuel') { nav.push('VeFuel', {}); return; }
          if (v === 'bakery') { setKind('invoice'); setGoods('bill'); setShop(bakeryShop.value); setPaid((o) => ({ ...o, method: o.method || 'cash' })); return; }
          if (v === 'expense') { setKind('invoice'); setGoods('bill'); setPaid((o) => ({ ...o, method: o.method || 'cash' })); } else { setKind(v); if (v === 'invoice') setPaid((o) => ({ ...o, method: '' })); }
        };
        return <Select testID="snap-k" label="What is it?" value={kind === 'invoice' && goods === 'bill' && paid.method ? 'expense' : kind} options={opts} onChange={pick} search={false}
          optionTestID={(v) => (v === 'fuel' ? 'snap-fuel' : v === 'bakery' ? 'snap-bakery-exp' : `snap-k-${v}`)} />;
      })()}
      <Hint>{{
        invoice: 'A supplier left an invoice / delivery note. Take a clear photo of the whole page – it is read and goes to the office to be checked and paid.',
        cheque_given: 'A cheque from Easy Buys was handed to someone (e.g. a supplier\'s driver). Photograph the cheque, choose the cheque and write who took it.',
        cheque_received: 'A customer paid with a cheque. Photograph the front of the cheque.',
        receipt: 'Any other paper that has to do with money (a credit note…). A receipt for a bill already paid (rent, power…) is better entered as a paid bill – tap below.',
      }[kind]}</Hint>
      {kind === 'receipt' ? <Btn testID="snap-paidbill" title="It is a receipt for a bill already paid (rent, power…)" icon="🧾" size="md" variant="info"
        onPress={() => { setKind('invoice'); setGoods('bill'); setPaid((o) => ({ ...o, method: 'cash' })); }} /> : null}
      {kind === 'invoice' && mode !== 'receive' ? (
        <>
          <Select testID="snap-goods" label="What came with it?" value={goods} onChange={(v) => { setGoods(v); setPoUid(''); }} search={false} optionTestID={(v) => `snap-goods-${v}`}
            options={[{ value: 'stock', label: '📦 Goods / stock' }, { value: 'bill', label: '🧾 A bill – no goods (rent, power, repairs…)' }]} />
          {goods === 'stock' && !canReceive ? <Hint>Take the photo; a supervisor counts the goods in against the order so the stock is right.</Hint> : null}
          {goods === 'stock' && canReceive ? <Hint>Photo and supplier first, then you count what arrived – the stock is updated and the invoice is joined to the order.</Hint> : null}
        </>
      ) : null}
      <Label>Shop</Label>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="snap-shop" />
      <PaperPhoto pr={sp} value={photos} onChange={setPhotos} label="Photo" required testID="snap-photo" form={snapForm} setForm={setSnapForm} map={SNAP_MAP}
        labels={{ supUid: 'Supplier', party: 'Supplier name', refNo: kind === 'invoice' ? 'Invoice number' : 'Cheque number', amount: 'Amount' }}
        display={(k, v) => (k === 'supUid' ? ((suppliers.find((x) => x.uid === v) || {}).name || v) : undefined)}
        hint="Take the photo first – the supplier, number and amount fill in by themselves. Then check them against the paper." />
      {withSupplier ? (
        <>
          <Select testID="snap-sup" label={kind === 'cheque_given' ? 'Paid to (supplier)' : 'Supplier'} value={supUid} onChange={(v) => { setSupUid(v); setChq(''); setTicked({}); setPoUid(''); }}
            options={[{ value: '', label: 'Not in the list – type it below' }].concat(suppliers.map((x) => ({ value: x.uid, label: x.name, hint: x.needs_setup ? 'new – to add properly' : undefined })))} />
          {!sup ? (
            <>
              <Field testID="snap-party" label="Or type the supplier name" value={party} onChangeText={setParty} />
              {party.trim() ? <Hint>{typedMatch ? `Matches "${typedMatch.name}".` : 'New supplier – it is added and flagged so the office adds it properly (TIN, terms).'}</Hint> : null}
            </>
          ) : null}
        </>
      ) : <Field testID="snap-party" label={kind === 'cheque_received' ? 'Customer' : 'From'} value={party} onChangeText={setParty} />}
      {stockMode && effSup ? (
        <Card tone="info">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{openPos.length ? 'Which purchase order is it for?' : `No open purchase order from ${effSup.name} for ${shop}.`}</Text>
          {openPos.map((x) => <Btn key={x.uid} testID={`snap-rpo-${x.po_no}`} title={`${x.po_no} · ordered ${x.order_date} · ${$(x.total)}`} icon="📝" size="md" variant={poUid === x.uid ? 'success' : 'secondary'} onPress={() => setPoUid(poUid === x.uid ? '' : x.uid)} />)}
          <Hint>{poUid ? 'Tap "Next" to count the goods against this order.' : openPos.length ? 'Not for any of these? Tap "Next" to receive without an order (the photo is kept with it).' : 'Tap "Next" to receive the products without an order (the photo is kept with it).'}</Hint>
        </Card>
      ) : null}
      {kind === 'invoice' && (goods === 'bill' || goods === 'total') ? (
        <Card>
          {goods === 'total' ? <Text style={{ fontSize: 15, color: C.sub }}>Loose items or a one-off buy: only the invoice total and photo are kept (stock is not counted in). It goes to the office as Stock for resale.</Text> : null}
          {goods === 'total' ? null : <Select testID="snap-cat" label="What is the bill for?" value={category} onChange={setCategory} options={[{ value: '', label: 'Choose (the office can change it)' }].concat(AP.apRules().categories.filter((c) => !/stock|ingredient|liquor/i.test(c)).map((c) => ({ value: c, label: c })))} />}
          <Label>{goods === 'total' ? 'Paid now?' : 'Paid already? (a receipt)'}</Label>
          <Chips value={paid.method} onChange={setP('method')} testIDPrefix="snap-paid" options={[{ value: '', label: 'Not paid yet' }, { value: 'cash', label: '💵 Paid in cash' }, { value: 'cheque', label: '📝 Paid by cheque' }, { value: 'transfer', label: '🏦 Paid by transfer' }, { value: 'mpaisa', label: '📱 Paid by M-PAiSA' }]} />
          {paid.method === 'cash' ? <Chips value={paid.shopCode || shop} onChange={setP('shopCode')} testIDPrefix="snap-paid-shop" options={shopChips()} /> : null}
          {paid.method === 'cash' ? (() => {
            let tills = [];
            try { tills = require('../../../db/connection.js').db().all('SELECT uid, name FROM tills WHERE shop_code = ? AND active = 1 ORDER BY sort, name', [paid.shopCode || shop]); } catch (e) { tills = []; }
            return <><Label>Where did the cash come from?</Label><Chips value={paid.cashFrom || ''} onChange={setP('cashFrom')} testIDPrefix="snap-paid-from" options={[{ value: 'safe', label: '🔐 The shop\'s safe' }].concat(tills.map((t) => ({ value: `till:${t.uid}`, label: `🧾 ${t.name}` })))} /></>;
          })() : null}
          {paid.method === 'mpaisa' ? (() => {
            let ws = [];
            try { ws = require('../../../db/connection.js').db().all('SELECT uid, name FROM wallets WHERE shop_code = ? AND active = 1 ORDER BY sort', [paid.shopCode || shop]); } catch (e) { ws = []; }
            if (!paid.walletUid && ws.length) setTimeout(() => setP('walletUid')(ws[0].uid), 0);
            return <><Hint>{ws.length ? `From ${ws[0].name}.` : 'This shop has no M-PAiSA wallet set up yet.'}</Hint><Field testID="snap-paid-mref" label="M-PAiSA transaction reference" value={paid.reference} onChangeText={setP('reference')} /></>;
          })() : null}
          {paid.method === 'cheque' || paid.method === 'transfer' ? <Select testID="snap-paid-acct" label="Bank account" value={paid.accountUid} onChange={setP('accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
          {paid.method === 'cheque' ? <ChequeNoPicker testID="snap-paid-chq" accountUid={paid.accountUid} value={paid.chequeNo} onChange={setP('chequeNo')} /> : null}
          {paid.method === 'transfer' ? <Field testID="snap-paid-ref" label="Transfer reference" value={paid.reference} onChangeText={setP('reference')} /> : null}
          <Hint>{`Booked to ${shop}${/^BAK/i.test(shop) ? ' (the Bakery)' : ''} – change the shop above for a shop, the bakery or the office.`}</Hint>
          {paid.method ? <Hint>{can && can('payments_make') ? 'The bill and its payment are saved together, so it is never paid twice.' : 'The office records the payment from this receipt.'} Enter the amount below.</Hint> : null}
        </Card>
      ) : null}
      {kind === 'invoice' && !stockMode && effSup && pos.length ? (
        <Select testID="snap-po" label="Purchase order (optional)" value={poUid} onChange={setPoUid}
          options={[{ value: '', label: 'No purchase order' }].concat(pos.map((p) => ({ value: p.uid, label: `${p.po_no} · ${p.order_date}`, hint: `${p.shop_code} · ${p.status}${p.total ? ` · ${$(p.total)}` : ''}` })))} />
      ) : null}
      {kind === 'cheque_given' && effSup ? (
        <Select testID="snap-chq" label="Which cheque?" value={chq} onChange={(v) => { setChq(v); setTicked({}); }} options={choices.map(({ value, label, hint }) => ({ value, label, hint }))} />
      ) : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {kind !== 'cheque_given' || typing ? <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="snap-ref" label={kind.startsWith('cheque') ? 'Cheque number' : 'Invoice number'} value={refNo} onChangeText={setRefNo} keyboardType={kind.startsWith('cheque') ? 'number-pad' : undefined} /></View> : null}
        <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="snap-amount" label={recordedCheque ? `Amount (cheque is ${$(recordedCheque.amount)})` : 'Amount (if you can see it)'} value={amount} onChange={setAmount} /></View>
      </View>
      {check ? <Banner testID="snap-check" tone={check.level === 'ok' ? 'success' : check.level === 'warn' ? 'warn' : 'danger'} title={check.level === 'ok' ? 'Cheque found ✓' : check.level === 'warn' ? 'Not recorded yet' : 'Check the number'} message={check.message} /> : null}
      {payment && payment.allocations.length ? <Hint>{`Pays invoice ${payment.allocations.map((x) => `${x.invoice_no || '?'} (${$(x.amount)})`).join(', ')}.`}</Hint> : null}
      {kind === 'cheque_given' && unpaid.length ? (
        <Section title="Which invoices is it for? (tick)">
          {unpaid.map((i) => (
            <ListItem key={i.uid} testID={`snap-inv-${i.invoice_no || i.uid}`} onPress={() => setTicked((t) => ({ ...t, [i.uid]: !t[i.uid] }))}
              title={`${ticked[i.uid] ? '☑️' : '⬜'} ${i.invoice_no || 'no number'} · ${i.invoice_date}`} sub={`Due ${i.due_date}`} right={$(i.owing)} />
          ))}
          {tickedUids.length ? <Hint>{`Ticked: ${$(tickedTotal)}`}</Hint> : null}
        </Section>
      ) : null}
      {kind === 'cheque_given' ? <Field testID="snap-who" label="Name of the person who took the cheque" value={collectedBy} onChangeText={setCollectedBy} /> : null}
      {kind === 'cheque_given' && mode === 'cheque' ? <SignaturePad testID="snap-sig" label="Signature of the person taking the cheque" value={sig} onChange={setSig} /> : null}
      {mode === 'receive' && goods === 'stock' && !canReceive ? <Hint>Take the photo and save it; a supervisor counts the goods in against the order so the stock is right.</Hint> : null}
      <Field label="Note (optional)" value={note} onChangeText={setNote} />
      <OtherEntries nav={nav} user={user} screens={screens} />
    </Screen>
  );
}

// v3.9: every other kind of entry is reachable from the receiving screen too, so staff start in one place.
const OTHER_ENTRIES = [
  ['VeFuel', {}, '⛽', 'Vehicle refuel'],
  ['VeWork', {}, '🔧', 'Vehicle service / repair'],
  ['ApInvoiceEdit', { kind: 'credit' }, '↩️', 'Credit note from a supplier'],
  ['SupplierReturn', {}, '📦', 'Goods back to a supplier'],
  ['CashOnHand', {}, '👛', 'Petty cash out of the shop'],
  ['AcctEntry', {}, '✍️', 'Other money in or out (typed)'],
  ['ApPay', {}, '💸', 'Pay a supplier (also split / part payments)'],
  ['MySnaps', {}, '🗂️', 'What I entered'],
];
function OtherEntries({ nav, user, screens }) {
  const list = OTHER_ENTRIES.filter(([n]) => { try { return screens && screens[n] && screens[n].can(user); } catch (e) { return false; } });
  if (!list.length) return null;
  return (
    <Section title="Other entries">
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {list.map(([n, p, icon, title]) => <Btn key={n} testID={`snap-other-${n}`} title={title} icon={icon} size="sm" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push(n, p)} />)}
      </View>
    </Section>
  );
}

export function MySnapsScreen() {
  const { user } = useApp();
  const list = V.listSnaps({ byUid: user.uid, limit: 100 });
  return (
    <Screen title="My photos" subtitle="Invoices and cheques I photographed">
      {!list.length ? <Text style={{ color: C.sub }}>None yet.</Text> : null}
      {list.map((s) => <ListItem key={s.uid} title={`${V.SNAP_KIND[s.kind]}${s.party ? ` · ${s.party}` : ''}`} sub={`${s.snap_date} · ${s.shop_code}${s.ref_no ? ` · no. ${s.ref_no}` : ''}`}
        right={s.amount === null ? '' : $(s.amount)} badge={s.status === 'waiting' ? 'WAITING' : s.status === 'confirmed' ? 'CONFIRMED' : 'REJECTED'} badgeColor={s.status === 'confirmed' ? C.success : s.status === 'waiting' ? C.warn : C.danger} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings
export function VerifySetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [r, setR] = useState(V.verifyRules());
  const [token, setToken] = useState('');
  const [oldToken, setOldToken] = useState('');
  const [chan, setChan] = useState('');
  const [busy, setBusy] = useState(false);
  const connect = async () => {
    setBusy(true);
    const res = await setupViberChannel(token, oldToken, chan || undefined);
    setBusy(false);
    ui.alert({ title: res.ok ? 'Viber Channel' : 'Not connected', message: res.message, tone: res.ok ? 'primary' : 'danger' });
  };
  return (
    <Screen title="Verification & Viber alerts" subtitle="Admin settings">
      <Section title="Verifying">
        <Chips value={r.secondPerson ? 'y' : 'n'} onChange={(v) => setR({ ...r, secondPerson: v === 'y' })} testIDPrefix="vs-2nd" options={[{ value: 'n', label: 'Same person may verify' }, { value: 'y', label: 'A different person must verify' }]} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag deposits / transfers not in the bank after (days)" value={String(r.bankDays)} onChangeText={(v) => setR({ ...r, bankDays: v })} keyboardType="number-pad" /></View>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag cheques not cleared after (days)" value={String(r.chequeDays)} onChangeText={(v) => setR({ ...r, chequeDays: v })} keyboardType="number-pad" /></View>
        </View>
      </Section>
      <Section title="Viber alerts">
        <Chips value={r.viberMode} onChange={(v) => setR({ ...r, viberMode: v })} testIDPrefix="vs-mode" options={[{ value: 'off', label: 'Off' }, { value: 'share', label: 'One tap to a Viber group' }, { value: 'channel', label: 'Automatic (Viber Channel)' }]} />
        <Explain title="Which one?">
          One tap: after something happens, Viber opens with the message written – pick the group and press send. Works with any normal Viber group.{'\n\n'}
          Automatic: Viber only lets apps post by themselves to a Viber Channel (not a normal group). Create a channel in Viber (e.g. "Easy Buys Alerts"), add the people who should get the alerts,
          then in the channel open Settings › Developer tools, copy the token and paste it below. Alerts are sent through the Easy Buys cloud when the device is online.
        </Explain>
        {r.viberMode === 'share' ? <Field label="Name of the Viber group (shown to staff)" value={r.viberGroup} onChangeText={(v) => setR({ ...r, viberGroup: v })} /> : null}
        <Label>PDF after saving</Label>
        <Hint>After a deposit, a supplier payment or cheque, an invoice or a purchase order is saved, the app offers a PDF of it (with the photo). Staff tap Viber and pick the group.</Hint>
        <Chips value={r.askPdf === false ? 'n' : 'y'} onChange={(v) => setR({ ...r, askPdf: v === 'y' })} testIDPrefix="vs-pdf" options={[{ value: 'y', label: 'Offer the PDF' }, { value: 'n', label: 'Do not ask' }]} />
        {r.viberMode === 'channel' ? (
          <>
            <Label>Which channel?</Label>
            <Chips value={chan} onChange={setChan} testIDPrefix="vs-chan" options={[{ value: '', label: 'Main channel (owner / admin)' }].concat(shopChips().filter((x) => /^S/i.test(x.value)).map((x) => ({ value: x.value, label: `${x.label}'s own channel` })))} />
            <Hint>Each shop can have its own Viber Channel with its managers and admin: that shop's alerts go there. Bank, wages, loans, FNPF / PAYE and other business-wide matters only go to the main channel.</Hint>
            <Field testID="vs-token" label="Viber Channel token" value={token} onChangeText={setToken} placeholder="paste the token" />
            <Field label="Current token (only when replacing one already connected)" value={oldToken} onChangeText={setOldToken} />
            <Btn title={busy ? 'Connecting…' : 'Connect and send a test message'} size="md" variant="info" disabled={busy || (!token.trim() && !oldToken.trim())} onPress={connect} />
          </>
        ) : null}
        {r.viberMode === 'channel' ? (
          <>
            <Label>Photos and PDFs in the Channel</Label>
            <Chips value={r.attach === false ? 'n' : 'y'} onChange={(v) => setR({ ...r, attach: v === 'y' })} testIDPrefix="vs-attach" options={[{ value: 'y', label: '✓ Attach the photo / PDF' }, { value: 'n', label: 'Text only' }]} />
            <Field testID="vs-morning" label="Morning summary at (24-hour time, e.g. 07:30)" value={r.morningAt || '07:30'} onChangeText={(v) => setR({ ...r, morningAt: v })} />
          </>
        ) : null}
        <Label>Send an alert when</Label>
        {Object.entries(V.EVENT_LABEL).map(([k, label]) => (
          <Chips key={k} value={r.events[k] ? 'y' : 'n'} onChange={(v) => setR({ ...r, events: { ...r.events, [k]: v === 'y' } })} testIDPrefix={`vs-ev-${k}`} options={[{ value: 'y', label: `✓ ${label}` }, { value: 'n', label: 'No' }]} />
        ))}
      </Section>
      <Btn testID="vs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => V.saveVerifyRules(user, r), 'Saved')} />
      <Section title="Recent alerts">
        {V.recentAlerts(20).map((a) => <ListItem key={a.uid} title={a.text} sub={`${String(a.at).slice(0, 16)} · ${a.mode}`} />)}
      </Section>
    </Screen>
  );
}

// v3.9.5 the two staff jobs, each with its own name on Home and in the menus (same screen as the photo screen).
export function ReceiveScreen({ params = {} }) { return <SnapScreen params={{ goods: 'stock', ...params, mode: 'receive', kind: 'invoice' }} />; }
export function HandChequeScreen({ params = {} }) { return <SnapScreen params={{ ...params, mode: 'cheque', kind: 'cheque_given' }} />; }
