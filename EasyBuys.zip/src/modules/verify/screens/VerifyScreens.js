// To verify (2nd step for every money record), staff photos of invoices / cheques, and the alert settings.
import React, { useState } from 'react';
import { View, Linking } from 'react-native';
import { Text } from '../../../ui/scale.js';
import { Screen, Card, H, Btn, Banner, Chips, Field, Row, Section, PhotoPicker, Label, Select, useApp, useUI, useRemembered } from '../../../ui/components.js';
import { C } from '../../../ui/theme.js';
import { useAct, MoneyField, DateField, ListItem, Stats, Hint, Explain, ReasonButton } from '../../../ui/kit.js';
import { PhotoStrip, photosFor } from '../../../ui/photoView.js';
import { dateStr } from '../../../services/core.js';
import { listPhotos } from '../../../services/stock.js';
import { listShops } from '../../admin/service.js';
import { setupViberChannel } from '../../../platform/cloud.js';
import * as V from '../service.js';
import * as AP from '../../payables/service.js';
import * as CB from '../../payables/chequebooks.js';
import { listPOs } from '../../inventory/service.js';
import { ChequeNoPicker } from '../../payables/screens/ChequePicker.js';

const { $ } = V;
const shopChips = () => listShops().filter((s) => s.active).map((s) => ({ value: s.code, label: s.code }));
const HOW = { bank: { label: 'Checked by the bank', color: C.info }, person: { label: 'Checked by a person', color: C.warn }, confirm: { label: 'Photo to confirm', color: C.primary }, pay: { label: 'To pay', color: C.danger }, record: { label: 'To record', color: C.danger }, explain: { label: 'Explain it', color: C.danger } };

export function VerifyScreen({ params }) {
  const { nav, user, can } = useApp();
  const act = useAct();
  const [show, setShow] = useRemembered('show', 'waiting');
  const [kind, setKind] = useRemembered('kind', params.kind || 'all');
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const all = V.queue({ include: show === 'done' ? 'done' : 'waiting' });
  const list = all.filter((x) => kind === 'all' || x.how === kind || (kind === 'late' && x.late));
  const sum = V.queueSummary();
  const rules = V.verifyRules();
  return (
    <Screen title="To verify" subtitle="Step 2 for every money record">
      <Explain title="How verifying works">
        Every money record has two steps. Step 1: someone records it (a deposit, a cheque, cash paid out, petty cash, a photo of an invoice). Step 2: it is checked.{'\n\n'}
        • Bank items (deposits, cheques, transfers) are verified when they show on the bank statement – tick "Seen in the bank" here or in the bank reconciliation.{'\n'}
        • Cash items are verified by a person who has checked the cash, the receipt or the signature.{'\n'}
        • Photos taken by staff are confirmed by a supervisor or admin.{'\n'}
        {rules.secondPerson ? 'The admin has set that a different person must do step 2.' : 'The same person may do both steps (the admin can change this).'}
      </Explain>
      <Stats items={[
        { label: 'Waiting', value: String(sum.waiting), sub: $(sum.value), onPress: () => setKind('all') },
        { label: 'Late', value: String(sum.late), color: sum.late ? C.danger : undefined, sub: 'not in the bank yet', onPress: () => setKind('late') },
        { label: 'Photos to confirm', value: String(sum.photos), onPress: () => setKind('confirm') },
        { label: 'Cash to check', value: String(sum.cash), onPress: () => setKind('person') },
      ]} />
      {can('snap_upload') ? <Btn testID="vf-snap" title="Take a photo of an invoice or cheque" icon="📷" variant="info" onPress={() => nav.push('Snap', {})} /> : null}
      <Chips value={kind} onChange={setKind} testIDPrefix="vf-k" options={[{ value: 'all', label: 'All' }, { value: 'late', label: 'Late' }, { value: 'confirm', label: 'Photos' }, { value: 'person', label: 'Cash' }, { value: 'bank', label: 'Bank' }, { value: 'record', label: 'Cheques to record' }]} />
      <Chips value={show} onChange={setShow} testIDPrefix="vf-s" options={[{ value: 'waiting', label: 'Waiting' }, { value: 'done', label: 'Done' }]} />
      {!list.length ? <Text style={{ color: C.sub, fontSize: 16 }}>{show === 'waiting' ? 'Nothing waiting – everything is verified.' : 'Nothing here.'}</Text> : null}
      {list.slice(0, 200).map((x) => (
        <View key={x.key} style={{ gap: 6 }}>
          <ListItem testID={`vf-${x.key}`} onPress={() => { setOpen(open === x.key ? null : x.key); setNote(''); }} title={`${x.type}${x.shop ? ` · ${x.shop}` : ''}`}
            sub={`${x.date} · ${x.who || ''}${x.text ? ` · ${x.text}` : ''}${x.doneText ? ` · ${x.doneText}` : ''}`} right={x.amount === null || x.amount === undefined ? '' : $(x.amount)}
            badge={x.late ? 'LATE' : x.problem ? 'PROBLEM' : HOW[x.how].label} badgeColor={x.late || x.problem ? C.danger : HOW[x.how].color} tone={x.late ? 'danger' : undefined} />
          {open === x.key ? (
            <Card>
              {x.how === 'confirm' ? <PhotoStrip photos={photosFor(listPhotos('snap', x.uid), x.photos, x.type)} /> : null}
              {x.how === 'bank' && !x.done ? (
                <>
                  <Hint>Look at the bank statement or internet banking. When this amount is there, tap below. (Bank reconciliation does the same.)</Hint>
                  {can('bank_rec') || can('verify_money') ? <Btn testID="vf-bank" title="Seen in the bank today" icon="🏦" size="md" variant="success" onPress={() => act(() => V.seenInBank(user, x, dateStr()), 'Verified – seen in the bank')} /> : null}
                </>
              ) : null}
              {x.how === 'person' && !x.done && can('verify_money') ? (
                <>
                  <Hint>Check the cash, the receipt or the signed slip. If it is right, verify it. If not, say what is wrong – it stays on the list as a problem.</Hint>
                  <Field testID="vf-note" label="Note (needed for a problem)" value={note} onChangeText={setNote} />
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    <Btn testID="vf-ok" title="Verified ✓" size="md" variant="success" style={{ flex: 1 }} onPress={() => act(() => V.verify(user, { table: x.table, uid: x.uid, recordedByUid: x.recordedByUid, note }), 'Verified')} />
                    <Btn testID="vf-problem" title="Problem" size="md" variant="danger" style={{ flex: 1 }} onPress={() => act(() => V.verify(user, { table: x.table, uid: x.uid, recordedByUid: x.recordedByUid, note, ok: false }), 'Marked as a problem')} />
                  </View>
                </>
              ) : null}
              {x.how === 'confirm' && !x.done && can('verify_money') ? (
                x.linkTable === 'ap_invoices' ? (
                  <>
                    <Hint>This photo was entered as an invoice. Open it, check the supplier, invoice number and total, and tap "Checked" – the photo is then confirmed too.</Hint>
                    <Btn testID="vf-open-inv" title="Open the invoice" size="md" variant="info" onPress={() => nav.push('ApInvoice', { uid: x.linkUid })} />
                    <ReasonButton title="Reject (not a real invoice / duplicate)" prompt="What is wrong?" confirm="Reject" onDo={(w) => act(() => V.rejectSnap(user, x.snapUid, w), 'Rejected')} />
                  </>
                ) : (
                  <>
                    <Hint>Check the photo against the cheque book / the cheque, the amount and who took it.</Hint>
                    <Btn testID="vf-confirm" title="Confirm" size="md" variant="success" onPress={() => act(() => V.confirmSnap(user, x.snapUid), 'Confirmed')} />
                    <ReasonButton title="Reject" prompt="What is wrong?" confirm="Reject" onDo={(w) => act(() => V.rejectSnap(user, x.snapUid, w), 'Rejected')} />
                  </>
                )
              ) : null}
              {x.how === 'record' ? (
                <>
                  <Hint>{x.notInBook ? 'This cheque number is not in any cheque book in the app. Add the cheque book first (Cheque books & stubs), then record the payment.' : 'A cheque was handed over with this number but no payment is recorded with it. Record the payment – the invoices ticked on the photo are filled in.'}</Hint>
                  {x.notInBook ? <Btn testID="vf-add-book" title="Open Cheque books & stubs" size="md" variant="info" onPress={() => nav.push('ChequeBooks', {})} />
                    : <Btn testID="vf-record" title="Record the payment" icon="💸" size="md" variant="success" onPress={() => nav.push('ApPay', x.go[1])} />}
                </>
              ) : null}
              {x.how === 'pay' ? <Btn title="Open FNPF & tax payments" size="md" variant="info" onPress={() => nav.push('Statutory', {})} /> : null}
              {x.done && x.how === 'person' && can('verify_money') ? <ReasonButton title="Undo the verification" prompt="Why?" confirm="Undo" onDo={(w) => act(() => V.unverify(user, x.table, x.uid, w), 'Undone')} /> : null}
              {x.go && x.how !== 'record' ? <Btn title="Open the record" size="sm" variant="ghost" onPress={() => nav.push(x.go[0], x.go[1])} /> : null}
            </Card>
          ) : null}
        </View>
      ))}
    </Screen>
  );
}

// ---------------------------------------------------------------- staff photo
export function SnapScreen({ params }) {
  const { nav, user, can, screens } = useApp();
  const ui = useUI();
  const [kind, setKind] = useState(params.kind || 'invoice');
  const [shop, setShop] = useState(user.shop_code || (shopChips()[0] && shopChips()[0].value) || 'S1');
  const [photos, setPhotos] = useState([]);
  const [party, setParty] = useState('');
  const [supUid, setSupUid] = useState('');
  const [poUid, setPoUid] = useState('');
  const [chq, setChq] = useState('');
  const [refNo, setRefNo] = useState('');
  const [amount, setAmount] = useState('');
  const [collectedBy, setCollectedBy] = useState('');
  const [note, setNote] = useState('');
  const [ticked, setTicked] = useState({});
  const [done, setDone] = useState(null);
  // v3.9 receiving starts here: goods (counted in against the purchase order, or without one – stock is updated) or
  // a bill with no goods (rent, power…), which may be a receipt for a bill already paid.
  const [goods, setGoods] = useState(params.goods || 'stock');
  const [category, setCategory] = useState('');
  const [paid, setPaid] = useState({ method: '', shopCode: '', accountUid: '', chequeNo: '', reference: '' });
  const setP = (k) => (v) => setPaid((o) => ({ ...o, [k]: v, ...(k === 'accountUid' ? { chequeNo: '' } : {}) }));
  const canReceive = can ? can('po_receive') : false;
  const accounts = AP.listAccounts();
  const rules = V.verifyRules();
  const withSupplier = kind === 'invoice' || kind === 'cheque_given';
  const suppliers = withSupplier ? AP.listSuppliers() : [];
  const sup = supUid ? suppliers.find((x) => x.uid === supUid) : null;
  const typedMatch = !sup && party.trim().length >= 3 ? AP.matchSupplier(party) : null;
  const effSup = sup || typedMatch;
  // Cheque handed over: the drop-down (cheques written for them, next unused, type a number) and the checks.
  const choices = kind === 'cheque_given' && effSup ? CB.chequeChoices(effSup.uid) : [];
  const pick = choices.find((c) => c.value === chq) || null;
  const typing = kind === 'cheque_given' && (!effSup || chq === 'type' || !pick);
  const chequeNo = pick && pick.chequeNo ? pick.chequeNo : refNo;
  const check = kind === 'cheque_given' && String(chequeNo || '').trim() ? CB.checkChequeNo({ chequeNo, supplierUid: effSup ? effSup.uid : undefined, supplierName: party, accountUid: pick ? pick.accountUid : undefined }) : null;
  const recordedCheque = check && check.state === 'recorded' ? check.cheque : null;
  const payment = recordedCheque && recordedCheque.payment_uid ? AP.getPayment(recordedCheque.payment_uid) : null;
  const unpaid = kind === 'cheque_given' && effSup && !recordedCheque ? AP.payableFor(effSup.uid).invoices : [];
  const pos = kind === 'invoice' && effSup ? AP.posForSupplier(effSup.uid) : [];
  const tickedUids = unpaid.filter((i) => ticked[i.uid]).map((i) => i.uid);
  const tickedTotal = unpaid.filter((i) => ticked[i.uid]).reduce((t, i) => t + i.owing, 0);
  const reset = () => { setDone(null); setPhotos([]); setParty(''); setSupUid(''); setPoUid(''); setChq(''); setRefNo(''); setAmount(''); setNote(''); setCollectedBy(''); setTicked({}); setPaid({ method: '', shopCode: '', accountUid: '', chequeNo: '', reference: '' }); };
  const stockMode = kind === 'invoice' && goods === 'stock' && canReceive;
  let openPos = [];
  try { openPos = stockMode && effSup ? listPOs({ supplierUid: effSup.uid, shopCode: shop, status: 'to_receive', limit: 10 }) : []; } catch (e) { openPos = []; }
  // Goods: go on to count them in (against the order, or without one); the invoice photo and numbers go with them.
  const countIn = (po) => {
    try {
      if (!photos.length) throw Object.assign(new Error('Take a photo of the invoice first.'), { isAppError: true });
      let s0 = sup || typedMatch;
      if (!s0 && party.trim()) s0 = AP.addTypedSupplier(user, party.trim());
      if (!s0) throw Object.assign(new Error('Choose the supplier.'), { isAppError: true });
      const prefill = { invoiceNo: refNo, total: amount, photos };
      nav.replace('POReceive', po ? { poUid: po, prefill } : { shopCode: shop, supplierUid: s0.uid, prefill });
    } catch (e) { ui.error(e); }
  };
  const save = () => {
    if (stockMode) { countIn(poUid || null); return; }
    try {
      const amt = amount !== '' ? amount : recordedCheque ? recordedCheque.amount : tickedUids.length ? Math.round(tickedTotal * 100) / 100 : '';
      const r = V.snap(user, { kind, shopCode: shop, amount: amt, party: sup ? '' : party, supplierUid: sup ? sup.uid : undefined, poUid: kind === 'invoice' ? poUid || undefined : undefined,
        refNo: kind === 'cheque_given' ? String(chequeNo || '') : refNo, chequeUid: pick && pick.chequeUid ? pick.chequeUid : undefined, accountUid: pick ? pick.accountUid : undefined,
        invoiceUids: kind === 'cheque_given' ? tickedUids : undefined, note, photos, collectedBy,
        category: kind === 'invoice' && goods === 'bill' ? category || undefined : undefined, paid: kind === 'invoice' && goods === 'bill' && paid.method ? { ...paid, shopCode: paid.shopCode || shop } : undefined });
      setDone(r);
      ui.toast('Saved – a supervisor will confirm it');
    } catch (e) { ui.error(e); }
  };
  if (done) {
    return (
      <Screen title="Photo saved" subtitle="Waiting for a supervisor to confirm">
        <Banner tone="success" title="Saved" message="It is on the supervisor's To verify list. Thank you." />
        {done.check && done.check.level !== 'ok' ? <Banner testID="snap-done-check" tone="warn" title="The office will check the cheque number" message={done.check.message} /> : null}
        {done.message && rules.viberMode === 'share' ? (
          <>
            <Hint>{`Tell the "${rules.viberGroup}" Viber group: tap below, then pick the group and press send.`}</Hint>
            <Btn testID="snap-viber" title="Tell the Viber group" icon="💬" variant="info" onPress={() => Promise.resolve(Linking.openURL(V.viberShareLink(done.message))).catch(() => ui.alert({ title: 'Viber did not open', message: 'Is Viber installed on this device?' }))} />
          </>
        ) : null}
        {done.message && rules.viberMode === 'channel' ? <Hint>The Viber alert goes out by itself when this device is online.</Hint> : null}
        <Btn testID="snap-another" title="Take another" size="md" variant="secondary" onPress={reset} />
        <Btn title="Done" size="md" variant="success" onPress={() => nav.pop()} />
      </Screen>
    );
  }
  return (
    <Screen title="Receive goods & papers" subtitle="Invoices, receipts, cheques – everything received starts here"
      footer={<Btn testID="snap-save" title={stockMode ? 'Next: count the goods in' : 'Save the photo'} icon={stockMode ? '📦' : '📷'} variant="success" onPress={save} />}>
      <Label>What is it?</Label>
      <Chips value={kind === 'invoice' && goods === 'bill' && paid.method ? 'expense' : kind} testIDPrefix="snap-k"
        onChange={(v) => { setChq(''); setTicked({}); setPoUid(''); if (v === 'expense') { setKind('invoice'); setGoods('bill'); setPaid((o) => ({ ...o, method: o.method || 'cash' })); } else { setKind(v); if (v === 'invoice') setPaid((o) => ({ ...o, method: '' })); } }}
        options={[{ value: 'invoice', label: '📦 Delivery / invoice' }, { value: 'expense', label: '🧾 Expense paid (receipt)' }].concat(Object.entries(V.SNAP_KIND).filter(([value]) => value !== 'invoice').map(([value, label]) => ({ value, label })))} />
      <Hint>{{
        invoice: 'A supplier left an invoice / delivery note. Take a clear photo of the whole page – it is read and goes to the office to be checked and paid.',
        cheque_given: 'A cheque from Easy Buys was handed to someone (e.g. a supplier\'s driver). Photograph the cheque, choose the cheque and write who took it.',
        cheque_received: 'A customer paid with a cheque. Photograph the front of the cheque.',
        receipt: 'Any other paper that has to do with money (a credit note…). A receipt for a bill already paid (rent, power…) is better entered as a paid bill – tap below.',
      }[kind]}</Hint>
      {(() => {
        // v3.9 quick starts: a bakery expense (the Bakery as the cost area) and a vehicle refuel.
        const bakeryShop = shopChips().find((x) => /^BAK/i.test(x.value));
        const canFuel = screens && screens.VeFuel && (() => { try { return screens.VeFuel.can(user); } catch (e) { return false; } })();
        return (
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            {bakeryShop ? <Btn testID="snap-bakery-exp" title="Bakery expense" icon="🥖" size="sm" variant="secondary" onPress={() => { setKind('invoice'); setGoods('bill'); setShop(bakeryShop.value); setPaid((o) => ({ ...o, method: o.method || 'cash' })); }} /> : null}
            {canFuel ? <Btn testID="snap-fuel" title="Vehicle refuel" icon="⛽" size="sm" variant="secondary" onPress={() => nav.push('VeFuel', {})} /> : null}
          </View>
        );
      })()}
      {kind === 'receipt' ? <Btn testID="snap-paidbill" title="It is a receipt for a bill already paid (rent, power…)" icon="🧾" size="md" variant="info"
        onPress={() => { setKind('invoice'); setGoods('bill'); setPaid((o) => ({ ...o, method: 'cash' })); }} /> : null}
      {kind === 'invoice' ? (
        <>
          <Label>What came with it?</Label>
          <Chips value={goods} onChange={(v) => { setGoods(v); setPoUid(''); }} testIDPrefix="snap-goods" options={[{ value: 'stock', label: '📦 Goods / stock' }, { value: 'bill', label: '🧾 A bill – no goods (rent, power, repairs…)' }]} />
          {goods === 'stock' && !canReceive ? <Hint>Take the photo; a supervisor counts the goods in against the order so the stock is right.</Hint> : null}
          {goods === 'stock' && canReceive ? <Hint>Photo and supplier first, then you count what arrived – the stock is updated and the invoice is joined to the order.</Hint> : null}
        </>
      ) : null}
      <Label>Shop</Label>
      <Chips value={shop} onChange={setShop} options={shopChips()} testIDPrefix="snap-shop" />
      <PhotoPicker value={photos} onChange={setPhotos} label="Photo" required testID="snap-photo" />
      {withSupplier ? (
        <>
          <Select testID="snap-sup" label={kind === 'cheque_given' ? 'Paid to (supplier)' : 'Supplier'} value={supUid} onChange={(v) => { setSupUid(v); setChq(''); setTicked({}); setPoUid(''); }}
            options={[{ value: '', label: 'Not in the list – type it below' }].concat(suppliers.map((x) => ({ value: x.uid, label: x.name, hint: x.needs_setup ? 'new – to add properly' : undefined })))} />
          {!sup ? (
            <>
              <Field testID="snap-party" label="Or type the supplier name" value={party} onChangeText={setParty} />
              {party.trim() ? <Hint>{typedMatch ? `Matches "${typedMatch.name}".` : 'New supplier – it is added and flagged so the office adds it properly (TIN, terms).'}</Hint> : null}
            </>
          ) : null}
        </>
      ) : <Field testID="snap-party" label={kind === 'cheque_received' ? 'Customer' : 'From'} value={party} onChangeText={setParty} />}
      {stockMode && effSup ? (
        <Card tone="info">
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{openPos.length ? 'Which purchase order is it for?' : `No open purchase order from ${effSup.name} for ${shop}.`}</Text>
          {openPos.map((x) => <Btn key={x.uid} testID={`snap-rpo-${x.po_no}`} title={`${x.po_no} · ordered ${x.order_date} · ${$(x.total)}`} icon="📝" size="md" variant={poUid === x.uid ? 'success' : 'secondary'} onPress={() => setPoUid(poUid === x.uid ? '' : x.uid)} />)}
          <Hint>{poUid ? 'Tap "Next" to count the goods against this order.' : openPos.length ? 'Not for any of these? Tap "Next" to receive without an order (the photo is kept with it).' : 'Tap "Next" to receive the products without an order (the photo is kept with it).'}</Hint>
        </Card>
      ) : null}
      {kind === 'invoice' && goods === 'bill' ? (
        <Card>
          <Select testID="snap-cat" label="What is the bill for?" value={category} onChange={setCategory} options={[{ value: '', label: 'Choose (the office can change it)' }].concat(AP.apRules().categories.filter((c) => !/stock|ingredient|liquor/i.test(c)).map((c) => ({ value: c, label: c })))} />
          <Label>Paid already? (a receipt)</Label>
          <Chips value={paid.method} onChange={setP('method')} testIDPrefix="snap-paid" options={[{ value: '', label: 'Not paid yet' }, { value: 'cash', label: '💵 Paid in cash' }, { value: 'cheque', label: '📝 Paid by cheque' }, { value: 'transfer', label: '🏦 Paid by transfer' }]} />
          {paid.method === 'cash' ? <Chips value={paid.shopCode || shop} onChange={setP('shopCode')} testIDPrefix="snap-paid-shop" options={shopChips()} /> : null}
          {paid.method === 'cheque' || paid.method === 'transfer' ? <Select testID="snap-paid-acct" label="Bank account" value={paid.accountUid} onChange={setP('accountUid')} options={accounts.map((a) => ({ value: a.uid, label: a.name }))} /> : null}
          {paid.method === 'cheque' ? <ChequeNoPicker testID="snap-paid-chq" accountUid={paid.accountUid} value={paid.chequeNo} onChange={setP('chequeNo')} /> : null}
          {paid.method === 'transfer' ? <Field testID="snap-paid-ref" label="Transfer reference" value={paid.reference} onChangeText={setP('reference')} /> : null}
          <Hint>{`Booked to ${shop}${/^BAK/i.test(shop) ? ' (the Bakery)' : ''} – change the shop above for a shop, the bakery or the office.`}</Hint>
          {paid.method ? <Hint>{can && can('payments_make') ? 'The bill and its payment are saved together, so it is never paid twice.' : 'The office records the payment from this receipt.'} Enter the amount below.</Hint> : null}
        </Card>
      ) : null}
      {kind === 'invoice' && !stockMode && effSup && pos.length ? (
        <Select testID="snap-po" label="Purchase order (optional)" value={poUid} onChange={setPoUid}
          options={[{ value: '', label: 'No purchase order' }].concat(pos.map((p) => ({ value: p.uid, label: `${p.po_no} · ${p.order_date}`, hint: `${p.shop_code} · ${p.status}${p.total ? ` · ${$(p.total)}` : ''}` })))} />
      ) : null}
      {kind === 'cheque_given' && effSup ? (
        <Select testID="snap-chq" label="Which cheque?" value={chq} onChange={(v) => { setChq(v); setTicked({}); }} options={choices.map(({ value, label, hint }) => ({ value, label, hint }))} />
      ) : null}
      <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
        {kind !== 'cheque_given' || typing ? <View style={{ flexBasis: 160, flexGrow: 1 }}><Field testID="snap-ref" label={kind.startsWith('cheque') ? 'Cheque number' : 'Invoice number'} value={refNo} onChangeText={setRefNo} keyboardType={kind.startsWith('cheque') ? 'number-pad' : undefined} /></View> : null}
        <View style={{ flexBasis: 160, flexGrow: 1 }}><MoneyField testID="snap-amount" label={recordedCheque ? `Amount (cheque is ${$(recordedCheque.amount)})` : 'Amount (if you can see it)'} value={amount} onChange={setAmount} /></View>
      </View>
      {check ? <Banner testID="snap-check" tone={check.level === 'ok' ? 'success' : check.level === 'warn' ? 'warn' : 'danger'} title={check.level === 'ok' ? 'Cheque found ✓' : check.level === 'warn' ? 'Not recorded yet' : 'Check the number'} message={check.message} /> : null}
      {payment && payment.allocations.length ? <Hint>{`Pays invoice ${payment.allocations.map((x) => `${x.invoice_no || '?'} (${$(x.amount)})`).join(', ')}.`}</Hint> : null}
      {kind === 'cheque_given' && unpaid.length ? (
        <Section title="Which invoices is it for? (tick)">
          {unpaid.map((i) => (
            <ListItem key={i.uid} testID={`snap-inv-${i.invoice_no || i.uid}`} onPress={() => setTicked((t) => ({ ...t, [i.uid]: !t[i.uid] }))}
              title={`${ticked[i.uid] ? '☑️' : '⬜'} ${i.invoice_no || 'no number'} · ${i.invoice_date}`} sub={`Due ${i.due_date}`} right={$(i.owing)} />
          ))}
          {tickedUids.length ? <Hint>{`Ticked: ${$(tickedTotal)}`}</Hint> : null}
        </Section>
      ) : null}
      {kind === 'cheque_given' ? <Field testID="snap-who" label="Name of the person who took the cheque" value={collectedBy} onChangeText={setCollectedBy} /> : null}
      <Field label="Note (optional)" value={note} onChangeText={setNote} />
      <OtherEntries nav={nav} user={user} screens={screens} />
    </Screen>
  );
}

// v3.9: every other kind of entry is reachable from the receiving screen too, so staff start in one place.
const OTHER_ENTRIES = [
  ['VeFuel', {}, '⛽', 'Vehicle refuel'],
  ['VeWork', {}, '🔧', 'Vehicle service / repair'],
  ['ApInvoiceEdit', { kind: 'credit' }, '↩️', 'Credit note from a supplier'],
  ['SupplierReturn', {}, '📦', 'Goods back to a supplier'],
  ['CashOnHand', {}, '👛', 'Petty cash out of the shop'],
  ['AcctEntry', {}, '✍️', 'Other money in or out (typed)'],
  ['ApPay', {}, '💸', 'Pay a supplier (also split / part payments)'],
  ['MySnaps', {}, '🗂️', 'What I entered'],
];
function OtherEntries({ nav, user, screens }) {
  const list = OTHER_ENTRIES.filter(([n]) => { try { return screens && screens[n] && screens[n].can(user); } catch (e) { return false; } });
  if (!list.length) return null;
  return (
    <Section title="Other entries">
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {list.map(([n, p, icon, title]) => <Btn key={n} testID={`snap-other-${n}`} title={title} icon={icon} size="sm" variant="secondary" style={{ flexGrow: 1 }} onPress={() => nav.push(n, p)} />)}
      </View>
    </Section>
  );
}

export function MySnapsScreen() {
  const { user } = useApp();
  const list = V.listSnaps({ byUid: user.uid, limit: 100 });
  return (
    <Screen title="My photos" subtitle="Invoices and cheques I photographed">
      {!list.length ? <Text style={{ color: C.sub }}>None yet.</Text> : null}
      {list.map((s) => <ListItem key={s.uid} title={`${V.SNAP_KIND[s.kind]}${s.party ? ` · ${s.party}` : ''}`} sub={`${s.snap_date} · ${s.shop_code}${s.ref_no ? ` · no. ${s.ref_no}` : ''}`}
        right={s.amount === null ? '' : $(s.amount)} badge={s.status === 'waiting' ? 'WAITING' : s.status === 'confirmed' ? 'CONFIRMED' : 'REJECTED'} badgeColor={s.status === 'confirmed' ? C.success : s.status === 'waiting' ? C.warn : C.danger} />)}
    </Screen>
  );
}

// ---------------------------------------------------------------- settings
export function VerifySetupScreen() {
  const { user } = useApp();
  const act = useAct();
  const ui = useUI();
  const [r, setR] = useState(V.verifyRules());
  const [token, setToken] = useState('');
  const [oldToken, setOldToken] = useState('');
  const [busy, setBusy] = useState(false);
  const connect = async () => {
    setBusy(true);
    const res = await setupViberChannel(token, oldToken);
    setBusy(false);
    ui.alert({ title: res.ok ? 'Viber Channel' : 'Not connected', message: res.message, tone: res.ok ? 'primary' : 'danger' });
  };
  return (
    <Screen title="Verification & Viber alerts" subtitle="Admin settings">
      <Section title="Verifying">
        <Chips value={r.secondPerson ? 'y' : 'n'} onChange={(v) => setR({ ...r, secondPerson: v === 'y' })} testIDPrefix="vs-2nd" options={[{ value: 'n', label: 'Same person may verify' }, { value: 'y', label: 'A different person must verify' }]} />
        <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag deposits / transfers not in the bank after (days)" value={String(r.bankDays)} onChangeText={(v) => setR({ ...r, bankDays: v })} keyboardType="number-pad" /></View>
          <View style={{ flexBasis: 200, flexGrow: 1 }}><Field label="Flag cheques not cleared after (days)" value={String(r.chequeDays)} onChangeText={(v) => setR({ ...r, chequeDays: v })} keyboardType="number-pad" /></View>
        </View>
      </Section>
      <Section title="Viber alerts">
        <Chips value={r.viberMode} onChange={(v) => setR({ ...r, viberMode: v })} testIDPrefix="vs-mode" options={[{ value: 'off', label: 'Off' }, { value: 'share', label: 'One tap to a Viber group' }, { value: 'channel', label: 'Automatic (Viber Channel)' }]} />
        <Explain title="Which one?">
          One tap: after something happens, Viber opens with the message written – pick the group and press send. Works with any normal Viber group.{'\n\n'}
          Automatic: Viber only lets apps post by themselves to a Viber Channel (not a normal group). Create a channel in Viber (e.g. "Easy Buys Alerts"), add the people who should get the alerts,
          then in the channel open Settings › Developer tools, copy the token and paste it below. Alerts are sent through the Easy Buys cloud when the device is online.
        </Explain>
        {r.viberMode === 'share' ? <Field label="Name of the Viber group (shown to staff)" value={r.viberGroup} onChangeText={(v) => setR({ ...r, viberGroup: v })} /> : null}
        <Label>PDF after saving</Label>
        <Hint>After a deposit, a supplier payment or cheque, an invoice or a purchase order is saved, the app offers a PDF of it (with the photo). Staff tap Viber and pick the group.</Hint>
        <Chips value={r.askPdf === false ? 'n' : 'y'} onChange={(v) => setR({ ...r, askPdf: v === 'y' })} testIDPrefix="vs-pdf" options={[{ value: 'y', label: 'Offer the PDF' }, { value: 'n', label: 'Do not ask' }]} />
        {r.viberMode === 'channel' ? (
          <>
            <Field testID="vs-token" label="Viber Channel token" value={token} onChangeText={setToken} placeholder="paste the token" />
            <Field label="Current token (only when replacing one already connected)" value={oldToken} onChangeText={setOldToken} />
            <Btn title={busy ? 'Connecting…' : 'Connect and send a test message'} size="md" variant="info" disabled={busy || (!token.trim() && !oldToken.trim())} onPress={connect} />
          </>
        ) : null}
        <Label>Send an alert when</Label>
        {Object.entries(V.EVENT_LABEL).map(([k, label]) => (
          <Chips key={k} value={r.events[k] ? 'y' : 'n'} onChange={(v) => setR({ ...r, events: { ...r.events, [k]: v === 'y' } })} testIDPrefix={`vs-ev-${k}`} options={[{ value: 'y', label: `✓ ${label}` }, { value: 'n', label: 'No' }]} />
        ))}
      </Section>
      <Btn testID="vs-save" title="Save" icon="💾" variant="success" onPress={() => act(() => V.saveVerifyRules(user, r), 'Saved')} />
      <Section title="Recent alerts">
        {V.recentAlerts(20).map((a) => <ListItem key={a.uid} title={a.text} sub={`${String(a.at).slice(0, 16)} · ${a.mode}`} />)}
      </Section>
    </Screen>
  );
}
