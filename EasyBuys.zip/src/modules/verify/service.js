// "To verify": every money record is done in two steps – recorded (deposited, paid, given…), then verified.
//  • Anything that goes through the bank (deposits, cheques, transfers, FNPF / tax payments) is verified when it
//    shows on the bank statement (ticked in the bank reconciliation, or here with "seen in the bank").
//  • Cash (cash payments, petty cash, cash moved, advances, cash wages) is verified by a person. The same person may
//    verify unless the admin switches on "a different person must verify".
//  • Photos snapped by cashiers / shop assistants (an invoice received, a cheque handed over or received) are
//    confirmed by a supervisor or admin.
// Alerts can go to a Viber Channel automatically, or be shared to a Viber group with one tap.
import { db } from '../../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getShared, setShared, money } from '../../services/core.js';
import { addPhotos, enqueue } from '../../services/stock.js';
import * as AP from '../payables/service.js';
import * as B from '../bank/service.js';

export const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
export const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });
const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);

// ---------------------------------------------------------------- rules (admin)
export const VERIFY_DEFAULTS = {
  secondPerson: false,     // true: the person who recorded it cannot verify it
  bankDays: 5,             // a deposit / transfer not seen in the bank after this many days is flagged
  chequeDays: 30,          // a cheque not cleared after this many days is flagged
  viberMode: 'share',      // 'off' | 'share' (one tap to a Viber group) | 'channel' (sent automatically to a Viber Channel)
  viberGroup: 'Easy Buys Alerts',
  events: { invoice_snap: true, cheque_given: true, cheque_received: true, deposit: true, till_short: true, po_approval: true, big_writeoff: true, statutory_due: true },
};
export const EVENT_LABEL = {
  invoice_snap: 'Invoice received (photo)', cheque_given: 'Cheque handed over (photo)', cheque_received: 'Cheque received from a customer', deposit: 'Bank deposit made',
  till_short: 'Till short over the tolerance', po_approval: 'Purchase order needs approval', big_writeoff: 'Large stock write-off', statutory_due: 'FNPF / PAYE due soon',
};
export function verifyRules() {
  const s = getShared('verify_rules', {}) || {};
  return { ...VERIFY_DEFAULTS, ...s, events: { ...VERIFY_DEFAULTS.events, ...(s.events || {}) } };
}
export function saveVerifyRules(user, r) {
  const clean = {
    secondPerson: !!r.secondPerson, bankDays: Math.max(1, Math.round(Number(r.bankDays) || 5)), chequeDays: Math.max(1, Math.round(Number(r.chequeDays) || 30)),
    viberMode: ['off', 'share', 'channel'].includes(r.viberMode) ? r.viberMode : 'share', viberGroup: txt(r.viberGroup) || 'Easy Buys Alerts',
    events: Object.fromEntries(Object.keys(EVENT_LABEL).map((k) => [k, !!(r.events || {})[k]])),
  };
  const before = verifyRules();
  setShared('verify_rules', clean);
  audit({ user, action: 'Changed verification and alert rules', table: 'shared_settings', recordUid: 'verify_rules', before, after: clean });
  return clean;
}

// ---------------------------------------------------------------- alerts (Viber)
// Returns the text; in 'channel' mode it is also queued to be sent through the cloud when online.
export function notify(event, text, { shopCode } = {}) {
  const r = verifyRules();
  if (r.viberMode === 'off' || !r.events[event]) return null;
  const msg = `Easy Buys${shopCode ? ` ${shopCode}` : ''}: ${text}`;
  if (r.viberMode === 'channel') enqueue('viber', { text: msg, event });
  const { now, dev } = meta();
  if (has('alert_log')) db().run('INSERT INTO alert_log (uid, at, event, text, mode, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)', [uuid('AL'), now, event, msg, r.viberMode, now, dev]);
  return msg;
}
export const viberShareLink = (text) => `viber://forward?text=${encodeURIComponent(text)}`;
export function recentAlerts(limit = 50) { return has('alert_log') ? db().all('SELECT * FROM alert_log ORDER BY at DESC LIMIT ?', [limit]) : []; }

// ---------------------------------------------------------------- snaps (staff photos)
export const SNAP_KIND = { invoice: 'Invoice received', cheque_given: 'Cheque handed over', cheque_received: 'Cheque received', receipt: 'Receipt / other paper' };
// An invoice snap also enters the invoice (waiting to be read and checked) so it is only typed once.
export function snap(user, { kind, shopCode, amount, party, refNo, note, photos = [], date, collectedBy }) {
  need(SNAP_KIND[kind], 'Choose what the photo is of.');
  need(photos.length, 'Take a photo first.');
  need(txt(shopCode), 'Choose the shop.');
  const amt = txt(amount) === '' ? null : r2(amount);
  need(amt === null || amt >= 0, 'The amount cannot be negative.');
  if (kind === 'cheque_given') need(txt(collectedBy), 'Write the name of the person who took the cheque.');
  const d = txt(date) || dateStr();
  const uid = uuid('SN');
  let linkTable = null;
  let linkUid = null;
  if (kind === 'invoice') {
    const sup = txt(party) ? AP.matchSupplier(txt(party)) : null;
    const inv = AP.saveInvoice(user, { supplierUid: sup ? sup.uid : undefined, supplierName: sup ? undefined : txt(party) || undefined, invoiceNo: refNo, total: amt || 0,
      invoiceDate: d, shopCode, notes: [txt(note), `Photo by ${user.name}`].filter(Boolean).join(' – ') }, { photos, allowDuplicate: false });
    linkTable = 'ap_invoices'; linkUid = inv.uid;
  }
  if (kind === 'cheque_given' && txt(refNo)) {
    const c = db().get("SELECT * FROM cheques WHERE CAST(cheque_no AS TEXT) = ? AND status <> 'void' ORDER BY cheque_date DESC LIMIT 1", [txt(refNo).replace(/\D/g, '')]);
    if (c) { linkTable = 'cheques'; linkUid = c.uid; }
  }
  const { now, dev } = meta();
  db().run(`INSERT INTO money_snaps (uid, kind, shop_code, snap_date, amount, party, ref_no, note, collected_by, photo_urls, by_name, by_uid, created_at, status, link_table, link_uid, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?, '[]', ?,?,?, 'waiting', ?,?,?,?)`,
  [uid, kind, shopCode, d, amt, txt(party) || null, txt(refNo) || null, txt(note) || null, txt(collectedBy) || null, user.name, user.uid, now, linkTable, linkUid, now, dev]);
  if (kind !== 'invoice') addPhotos('snap', uid, photos);
  audit({ user, action: `Photo: ${SNAP_KIND[kind]}${txt(party) ? ` – ${txt(party)}` : ''}${amt !== null ? ` ${$(amt)}` : ''}`, table: 'money_snaps', recordUid: uid });
  const text = `${SNAP_KIND[kind]}${txt(party) ? ` – ${txt(party)}` : ''}${txt(refNo) ? ` no. ${txt(refNo)}` : ''}${amt !== null ? ` ${$(amt)}` : ''}${kind === 'cheque_given' ? `, collected by ${txt(collectedBy)}` : ''}. Photo by ${user.name}. Please confirm in the app (To verify).`;
  const msg = notify(kind === 'invoice' ? 'invoice_snap' : kind === 'receipt' ? 'invoice_snap' : kind, text, { shopCode });
  return { uid, message: msg, linkUid };
}
export function getSnap(uid) {
  const s = db().get('SELECT * FROM money_snaps WHERE uid = ?', [uid]);
  return s && { ...s, photos: J(s.photo_urls, []) };
}
export function listSnaps({ status, shopCode, byUid, limit = 200 } = {}) {
  return db().all(`SELECT * FROM money_snaps WHERE (? IS NULL OR status = ?) AND (? IS NULL OR shop_code = ?) AND (? IS NULL OR by_uid = ?) ORDER BY created_at DESC LIMIT ?`,
    [status || null, status || null, shopCode || null, shopCode || null, byUid || null, byUid || null, limit]).map((s) => ({ ...s, photos: J(s.photo_urls, []) }));
}
export function confirmSnap(user, uid, { note } = {}) {
  const s = getSnap(uid);
  need(s && s.status === 'waiting', 'This photo is not waiting to be confirmed.');
  const r = verifyRules();
  if (r.secondPerson) need(s.by_uid !== user.uid, 'A different person must confirm it.');
  if (s.link_table === 'ap_invoices') {
    const inv = AP.getInvoice(s.link_uid);
    need(inv && inv.status !== 'void', 'The invoice from this photo was voided.');
    need(inv.status === 'approved', 'Open the invoice, check the supplier, number and total, and tap "Checked" – that confirms the photo too.');
  }
  const { now, dev } = meta();
  db().run(`UPDATE money_snaps SET status = 'confirmed', confirmed_by_name = ?, confirmed_at = ?, confirm_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [user.name, now, txt(note) || null, now, dev, uid]);
  audit({ user, action: `Confirmed photo: ${SNAP_KIND[s.kind]} ${s.party || ''}`, table: 'money_snaps', recordUid: uid });
}
export function rejectSnap(user, uid, reason) {
  const s = getSnap(uid);
  need(s && s.status === 'waiting', 'This photo is not waiting to be confirmed.');
  need(txt(reason), 'Say what is wrong.');
  const { now, dev } = meta();
  db().run(`UPDATE money_snaps SET status = 'rejected', confirmed_by_name = ?, confirmed_at = ?, confirm_note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [user.name, now, txt(reason), now, dev, uid]);
  if (s.link_table === 'ap_invoices') { try { AP.voidInvoice(user, s.link_uid, `Photo rejected: ${txt(reason)}`); } catch (e) { /* already paid / checked: leave */ } }
  audit({ user, action: `Rejected photo: ${SNAP_KIND[s.kind]} ${s.party || ''}`, table: 'money_snaps', recordUid: uid, reason: txt(reason) });
}
// An invoice snap is confirmed by itself once its invoice is checked.
function syncInvoiceSnaps(user) {
  const rows = db().all("SELECT s.uid, i.status, i.checked_by_name FROM money_snaps s JOIN ap_invoices i ON i.uid = s.link_uid WHERE s.status = 'waiting' AND s.link_table = 'ap_invoices' AND i.status IN ('approved','void')");
  const { now, dev } = meta();
  for (const r of rows) {
    db().run(`UPDATE money_snaps SET status = ?, confirmed_by_name = ?, confirmed_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
      [r.status === 'approved' ? 'confirmed' : 'rejected', r.checked_by_name || (user && user.name) || null, now, now, dev, r.uid]);
  }
}

// ---------------------------------------------------------------- person verification (cash)
const vKey = (table, uid) => `${table}:${uid}`;
export function isVerified(table, uid) {
  return db().get("SELECT * FROM verifications WHERE uid = ? AND status = 'verified'", [vKey(table, uid)]) || null;
}
// Who recorded a record (looked up here, never taken from the screen).
function recordedBy(table, uid) {
  try {
    if (table === 'ap_payments') { const x = db().get('SELECT paid_by_uid AS u, paid_by_name AS n FROM ap_payments WHERE uid = ?', [uid]); return x || {}; }
    if (table === 'cash_moves') { const x = db().get('SELECT by_uid AS u, by_name AS n FROM cash_moves WHERE uid = ?', [uid]); return x || {}; }
    if (table === 'staff_debts') { const x = db().get('SELECT given_by_name AS n FROM staff_debts WHERE uid = ?', [uid]); return x || {}; }
    if (table === 'pay_cash') { const x = db().get('SELECT finalised_by_name AS n FROM pay_runs WHERE uid = ?', [String(uid).split('|')[0]]); return x || {}; }
  } catch (e) { return {}; }
  return {};
}
export function verify(user, { table, uid, note, ok = true }) {
  need(table && uid, 'Nothing to verify.');
  const r = verifyRules();
  if (r.secondPerson) { const by = recordedBy(table, uid); need(!((by.u && by.u === user.uid) || (by.n && by.n === user.name)), 'A different person must verify this.'); }
  if (!ok) need(txt(note), 'Say what is wrong.');
  const { now, dev } = meta();
  db().run(`INSERT INTO verifications (uid, table_name, record_uid, status, note, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(uid) DO UPDATE SET status = excluded.status, note = excluded.note, by_name = excluded.by_name, by_uid = excluded.by_uid, at = excluded.at,
    updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
  [vKey(table, uid), table, uid, ok ? 'verified' : 'problem', txt(note) || null, user.name, user.uid, now, now, dev]);
  audit({ user, action: ok ? `Verified ${table} record` : `Problem found: ${table} record`, table, recordUid: uid, reason: txt(note) || null });
}
export function unverify(user, table, uid, reason) {
  need(txt(reason), 'Say why.');
  const { now, dev } = meta();
  db().run(`UPDATE verifications SET status = 'undone', note = ?, by_name = ?, at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [txt(reason), user.name, now, now, dev, vKey(table, uid)]);
  audit({ user, action: `Verification undone: ${table}`, table, recordUid: uid, reason: txt(reason) });
}

// ---------------------------------------------------------------- the queue
// Every money record and where it stands. how: 'bank' (verified when seen on the statement) | 'person' | 'confirm' (photo)
export function queue({ from, to = dateStr(), shopCode, include = 'waiting' } = {}) {
  syncInvoiceSnaps(null);
  const r = verifyRules();
  const today = dateStr();
  const start = from || addDays(today, -120);
  const out = [];
  const days = (d) => Math.round((new Date(`${today}T00:00:00`) - new Date(`${String(d).slice(0, 10)}T00:00:00`)) / 86400000);
  const vmap = Object.fromEntries(db().all("SELECT * FROM verifications WHERE status IN ('verified','problem')").map((v) => [v.uid, v]));
  const shopOk = (s) => !shopCode || !s || s === shopCode;
  // Deposits
  if (has('deposits')) {
    for (const d of db().all(`SELECT d.*, e.cleared_date FROM deposits d LEFT JOIN bank_entries e ON e.uid = d.bank_entry_uid WHERE d.status = 'active' AND d.deposit_date BETWEEN ? AND ?`, [start, to])) {
      if (!shopOk(d.shop_code)) continue;
      out.push({ key: `deposits:${d.uid}`, table: 'deposits', uid: d.uid, type: 'Bank deposit', how: 'bank', date: d.deposit_date, shop: d.shop_code, amount: d.total,
        who: d.deposited_by_name, recordedByUid: d.deposited_by_uid, text: `Slip ${d.slip_no || '—'}${d.notes ? ` · ${d.notes}` : ''}`, bankEntryUid: d.bank_entry_uid,
        done: !!d.cleared_date, doneText: d.cleared_date ? `In the bank ${d.cleared_date}` : null, late: !d.cleared_date && days(d.deposit_date) > r.bankDays, go: ['Deposits', {}] });
    }
  }
  // Cheques written
  for (const c of db().all("SELECT * FROM cheques WHERE status IN ('written','presented') AND cheque_date BETWEEN ? AND ?", [start, to])) {
    out.push({ key: `cheques:${c.uid}`, table: 'cheques', uid: c.uid, type: `Cheque ${c.cheque_no}`, how: 'bank', date: c.cheque_date, shop: null, amount: c.amount, who: c.written_by_name,
      text: c.payee || '', chequeUid: c.uid, done: c.status === 'presented', doneText: c.presented_date ? `Cleared ${c.presented_date}` : null, late: c.status === 'written' && days(c.cheque_date) > r.chequeDays });
  }
  // Other bank entries (transfers out, FNPF / tax, wages by bank, fees…) not from a deposit
  for (const e of db().all(`SELECT e.* FROM bank_entries e WHERE e.status = 'active' AND e.entry_date BETWEEN ? AND ? AND e.uid NOT IN (SELECT bank_entry_uid FROM deposits WHERE bank_entry_uid IS NOT NULL)`, [start, to])) {
    out.push({ key: `bank_entries:${e.uid}`, table: 'bank_entries', uid: e.uid, type: { transfer_out: 'Bank transfer / payment', fee: 'Bank fee', interest: 'Interest', adjust_in: 'Bank in', adjust_out: 'Bank out', deposit: 'Money in' }[e.type] || e.type,
      how: 'bank', date: e.entry_date, shop: null, amount: e.amount, who: e.by_name, text: [e.reference, e.note].filter(Boolean).join(' · '), bankEntryUid: e.uid,
      done: !!e.cleared_date, doneText: e.cleared_date ? `In the bank ${e.cleared_date}` : null, late: !e.cleared_date && days(e.entry_date) > r.bankDays });
  }
  // Cash payments to suppliers
  for (const p of db().all("SELECT * FROM ap_payments WHERE status = 'active' AND method = 'cash' AND pay_date BETWEEN ? AND ?", [start, to])) {
    if (!shopOk(p.shop_code)) continue;
    const v = vmap[`ap_payments:${p.uid}`];
    out.push({ key: `ap_payments:${p.uid}`, table: 'ap_payments', uid: p.uid, type: 'Cash paid to supplier', how: 'person', date: p.pay_date, shop: p.shop_code, amount: p.amount, who: p.paid_by_name,
      recordedByUid: p.paid_by_uid, text: `${p.supplier_name}${p.received_by ? ` · taken by ${p.received_by}` : ''}`, done: !!v, problem: v && v.status === 'problem', doneText: v ? `${v.status === 'problem' ? 'Problem' : 'Verified'} by ${v.by_name}` : null, go: ['ApPayment', { uid: p.uid }] });
  }
  // Petty cash and cash moved
  if (has('cash_moves')) {
    const L = { petty_out: 'Petty cash spent', petty_in: 'Petty cash back', transfer_in: 'Cash moved in', transfer_out: 'Cash moved out', adjust_in: 'Cash added (correction)', adjust_out: 'Cash taken (correction)', opening: 'Opening cash' };
    const debtUids = has('staff_debts') ? new Set(db().all('SELECT uid FROM staff_debts').map((r) => r.uid)) : new Set();
    for (const m of db().all(`SELECT * FROM cash_moves WHERE status = 'active' AND type IN ('petty_out','petty_in','transfer_in','transfer_out','adjust_in','adjust_out','opening') AND move_date BETWEEN ? AND ?`, [start, to])) {
      if (m.ref_uid && debtUids.has(m.ref_uid)) continue; // shown once, as the advance / loan
      if (!shopOk(m.shop_code)) continue;
      const v = vmap[`cash_moves:${m.uid}`];
      out.push({ key: `cash_moves:${m.uid}`, table: 'cash_moves', uid: m.uid, type: L[m.type], how: 'person', date: m.move_date, shop: m.shop_code, amount: m.amount, who: m.by_name, recordedByUid: m.by_uid,
        text: [m.category, m.note].filter(Boolean).join(' · '), done: !!v, problem: v && v.status === 'problem', doneText: v ? `${v.status === 'problem' ? 'Problem' : 'Verified'} by ${v.by_name}` : null, go: ['CashOnHand', { shopCode: m.shop_code }] });
    }
  }
  // Advances / loans paid out in cash
  if (has('staff_debts')) {
    for (const d of db().all("SELECT * FROM staff_debts WHERE status = 'active' AND debt_date BETWEEN ? AND ? AND ifnull(paid_from,'cash') LIKE 'cash%'", [start, to])) {
      if (!shopOk(d.shop_code)) continue;
      const v = vmap[`staff_debts:${d.uid}`];
      out.push({ key: `staff_debts:${d.uid}`, table: 'staff_debts', uid: d.uid, type: d.kind === 'loan' ? 'Staff loan (cash)' : 'Staff advance (cash)', how: 'person', date: d.debt_date, shop: d.shop_code, amount: d.amount,
        who: d.given_by_name, text: `${d.name}${d.reason ? ` · ${d.reason}` : ''}`, done: !!v, problem: v && v.status === 'problem', doneText: v ? `${v.status === 'problem' ? 'Problem' : 'Verified'} by ${v.by_name}` : null });
    }
  }
  // Cash wages per pay run and shop
  if (has('pay_lines')) {
    for (const g of db().all(`SELECT r.uid AS run, r.week_start, r.pay_date, COALESCE(l.shop_code,'') AS shop, SUM(l.net) AS net, COUNT(*) AS n, r.finalised_by_name AS who FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid
      WHERE r.status = 'final' AND l.include = 1 AND ifnull(l.pay_method,'cash') <> 'bank' AND r.pay_date BETWEEN ? AND ? GROUP BY r.uid, l.shop_code`, [start, to])) {
      if (!shopOk(g.shop)) continue;
      const k = `${g.run}|${g.shop}`;
      const v = vmap[`pay_cash:${k}`];
      out.push({ key: `pay_cash:${k}`, table: 'pay_cash', uid: k, type: 'Cash wages handed out', how: 'person', date: g.pay_date, shop: g.shop || null, amount: g.net, who: g.who,
        text: `Week from ${g.week_start} · ${g.n} people`, done: !!v, problem: v && v.status === 'problem', doneText: v ? `${v.status === 'problem' ? 'Problem' : 'Verified'} by ${v.by_name}` : null });
    }
  }
  // Statutory payments (FNPF / PAYE) – verified through the bank like any payment; listed if not paid yet.
  if (has('stat_payments')) {
    for (const s of db().all("SELECT * FROM stat_payments WHERE status = 'active' AND period BETWEEN ? AND ?", [start.slice(0, 7), to.slice(0, 7)])) {
      if (s.paid_date) continue;
      out.push({ key: `stat_payments:${s.uid}`, table: 'stat_payments', uid: s.uid, type: `${s.kind === 'fnpf' ? 'FNPF' : 'PAYE / SRT'} for ${s.period}`, how: 'pay', date: s.due_date, shop: null, amount: s.amount, who: '',
        text: 'Not paid yet', done: false, late: s.due_date < today, go: ['Statutory', {}] });
    }
  }
  // Staff photos
  for (const s of db().all('SELECT * FROM money_snaps WHERE snap_date BETWEEN ? AND ?', [start, to])) {
    if (!shopOk(s.shop_code)) continue;
    out.push({ key: `money_snaps:${s.uid}`, table: 'money_snaps', uid: s.uid, type: SNAP_KIND[s.kind], how: 'confirm', date: s.snap_date, shop: s.shop_code, amount: s.amount, who: s.by_name, recordedByUid: s.by_uid,
      text: [s.party, s.ref_no ? `no. ${s.ref_no}` : '', s.collected_by ? `taken by ${s.collected_by}` : '', s.note].filter(Boolean).join(' · '), photos: J(s.photo_urls, []), snapUid: s.uid, linkTable: s.link_table, linkUid: s.link_uid,
      done: s.status !== 'waiting', problem: s.status === 'rejected', doneText: s.status === 'waiting' ? null : `${s.status === 'confirmed' ? 'Confirmed' : 'Rejected'} by ${s.confirmed_by_name}` });
  }
  const list = out.filter((x) => (include === 'all' ? true : include === 'done' ? x.done : !x.done)).sort((a, b) => (a.late === b.late ? (a.date < b.date ? -1 : 1) : a.late ? -1 : 1));
  return list;
}
export function queueSummary(opts) {
  const q = queue(opts);
  return { waiting: q.length, late: q.filter((x) => x.late).length, value: r2(q.reduce((s, x) => s + (Number(x.amount) || 0), 0)), photos: q.filter((x) => x.how === 'confirm').length,
    cash: q.filter((x) => x.how === 'person').length, bank: q.filter((x) => x.how === 'bank').length };
}
// "Seen in the bank": ticks the bank item as cleared (same as in the bank reconciliation).
export function seenInBank(user, item, date) {
  need(item.how === 'bank', 'This is checked by a person, not the bank.');
  if (item.chequeUid) B.tickCleared(user, { kind: 'cheque', uid: item.chequeUid }, date || dateStr());
  else B.tickCleared(user, { kind: 'entry', uid: item.bankEntryUid }, date || dateStr());
}
