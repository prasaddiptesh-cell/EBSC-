// 1.0.0 Office › Today: ONE list of everything to check – "the most important part of managing and growing the
// business". Invoices received, till balances (own till too), cheques and where each is in its chain, deposit plans,
// damaged goods waiting for a replacement, the cigarette invoice, unpaid invoices with no cheque, suggestions (order
// what is running low), the accountant's questions, and everything else waiting on To verify.
// Shop managers (and supervisors) see only their own shop. Every verify keeps who, when and the comment (verify_trail).
// Fast: each source is one query (no lookups per row), and the whole list is kept until anything in the database
// changes (writeCount) – thousands of records stay quick.
import { db, writeCount, noteDeps, trackReads } from '../../db/connection.js';
import { AppError, dateStr, addDays, money } from '../../services/core.js';
import { can } from '../../services/access.js';
import * as V from './service.js';
import { addTrail, trailFor, doneToday } from './trail.js';
import { papersFor } from './papers.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dayName = (d) => (d ? DAY[new Date(`${String(d).slice(0, 10)}T12:00:00`).getDay()] : '');
const daysAgo = (d, today) => Math.round((Date.parse(`${today}T00:00:00`) - Date.parse(`${String(d).slice(0, 10)}T00:00:00`)) / 86400000);

export const GROUPS = [
  { key: 'invoices', label: 'Invoices & deliveries received' },
  { key: 'tills', label: 'Till balances' },
  { key: 'cheques', label: 'Cheques' },
  { key: 'deposits', label: 'Deposit plans' },
  { key: 'damaged', label: 'Damaged / short – waiting for the supplier' },
  { key: 'cig', label: 'Cigarette invoice' },
  { key: 'unpaid', label: 'Unpaid invoices with no cheque' },
  { key: 'suggest', label: 'Suggestions' },
  { key: 'questions', label: 'Questions' },
  { key: 'other', label: 'Other things to check' },
];

// Which shop this person sees: managers and supervisors only their own; the owner / admin / payroll all (or one chosen).
export function todayShop(user, chosen) {
  if (!user) return null;
  if (['manager', 'supervisor'].includes(user.role) && user.shop_code) return user.shop_code;
  return txt(chosen) || null;
}
export const seesAllShops = (user) => !!user && !(['manager', 'supervisor'].includes(user.role) && user.shop_code);

let memo = null;
// opts: { shopCode (owner / admin choice), today, fresh (skip the memo) }
export function todayList(user, { shopCode, today = dateStr(), fresh = false } = {}) {
  need(user, 'Log in first.');
  const shop = todayShop(user, shopCode);
  const key = `${writeCount()}|${user.uid}|${shop || ''}|${today}`;
  if (!fresh && memo && memo.key === key && memo.db === db() && Date.now() - memo.at < 20000) { noteDeps(memo.deps); return memo.v; }
  const { value: v, deps } = trackReads(() => build(user, shop, today));
  memo = { key, db: db(), v, at: Date.now(), deps };
  return v;
}
// A manager sees an item only when it is for their shop (business-wide items – bank, cheques for other shops – are not).
const shopOk = (shop, s) => !shop || s === shop;

function build(user, shop, today) {
  const items = [];
  const add = (x) => { if (shopOk(shop, x.shop)) items.push({ level: null, amount: null, ...x }); };
  const office = can(user, 'payments_make') || can(user, 'invoices_check') || ['owner', 'admin'].includes(user.role);

  // ---- invoices received, waiting to be checked (bills too)
  for (const i of safe(() => db().all("SELECT uid, kind, supplier_uid, supplier_name, invoice_no, invoice_date, total, shop_code, entered_by_name, entered_at, category, ocr_status FROM ap_invoices WHERE status = 'to_check' ORDER BY entered_at"), [])) {
    const bill = i.category && !/stock|ingredient|liquor/i.test(i.category);
    add({ key: `ap_invoices:${i.uid}`, group: 'invoices', table: 'ap_invoices', uid: i.uid, shop: i.shop_code, date: i.invoice_date, amount: i.total || null,
      title: `${i.kind === 'credit' ? 'Credit note' : bill ? 'Bill' : 'Invoice'} ${i.supplier_name} ${i.invoice_no || ''}`.replace(/\s+/g, ' ').trim(),
      sub: [i.entered_by_name ? `received by ${i.entered_by_name}` : '', i.entered_at ? String(i.entered_at).slice(5, 16) : '', i.ocr_status === 'waiting' ? 'not read yet' : ''].filter(Boolean).join(' · '),
      level: i.ocr_status === 'waiting' || !i.total ? 'warn' : null, screen: 'TodayInvoice', params: { uid: i.uid }, supplierUid: i.supplier_uid });
  }
  // ---- till balances to approve (own till marked)
  if (has('till_counts')) {
    for (const c of safe(() => db().all("SELECT uid, shop_code, till_name, shift_date, shift, cashier_uid, cashier_name, balancer_uid, balancer_name, counted_by_name, over_short, cash_counted, expected_cash FROM till_counts WHERE status IN ('counted','queried') ORDER BY shift_date, shift"), [])) {
      const own = !!(c.balancer_uid && c.cashier_uid && c.balancer_uid === c.cashier_uid);
      const os = r2(c.over_short);
      add({ key: `till_counts:${c.uid}`, group: 'tills', table: 'till_counts', uid: c.uid, shop: c.shop_code, date: c.shift_date, amount: Math.abs(os) > 0.004 ? Math.abs(os) : null,
        title: `${Math.abs(os) < 0.005 ? 'Till balanced' : os < 0 ? 'Till short' : 'Till over'} – ${c.shop_code} ${c.till_name || ''} (${c.cashier_name || c.counted_by_name || '?'})`.replace(/\s+/g, ' '),
        sub: [`${c.shift || ''} ${c.shift_date}`, own ? 'OWN TILL – someone else checks it' : c.balancer_name ? `balanced by ${c.balancer_name}` : ''].filter(Boolean).join(' · '),
        level: Math.abs(os) > 0.004 || own ? 'warn' : null, own, screen: 'TillCountView', params: { uid: c.uid } });
    }
  }
  // ---- cheques: each one where it is in its chain (recorded, or written by staff and not recorded yet)
  const C = safe(() => require('../payables/chain.js'), null);
  const chains = C ? safe(() => C.openChains({}), []) : [];
  for (const c of chains) {
    const k = c.chequeUid || c.snapUid;
    const late = c.steps[3].done && !c.steps[4].done;
    add({ key: c.chequeUid ? `cheques:${c.chequeUid}` : `money_snaps:${c.snapUid}`, group: 'cheques', table: c.chequeUid ? 'cheques' : 'money_snaps', uid: k, shop: c.shop, date: c.date, amount: c.amount,
      title: `Cheque ${c.no} – ${c.supplierName || ''} – ${c.recorded ? c.stage.toLowerCase() : 'not recorded yet'}`.replace(/ – $/, ''),
      sub: [c.linked ? `pays ${c.invoices.map((i) => i.invoice_no || '(no number)').join(', ')}` : 'NOT LINKED TO AN INVOICE – link it', c.next ? `next: ${c.next.label.toLowerCase()}` : ''].filter(Boolean).join(' · '),
      level: !c.linked || !c.recorded ? 'bad' : late ? 'warn' : null, screen: 'ChequeTrail', params: c.chequeUid ? { chequeUid: c.chequeUid } : { snapUid: c.snapUid }, supplierUid: c.supplierUid });
  }
  // ---- deposit plans not on the bank yet
  const DP = safe(() => require('../payables/depositPlan.js'), null);
  for (const p of DP ? safe(() => DP.listPlans({ open: true }), []) : []) {
    add({ key: `deposit_plans:${p.uid}`, group: 'deposits', table: 'deposit_plans', uid: p.uid, shop: p.shop_code, date: p.plan_date, amount: p.total,
      title: `Deposit for ${dayName(p.plan_date)} ${p.plan_date.slice(8)}/${p.plan_date.slice(5, 7)} – ${p.next ? p.next.label.toLowerCase().replace(' – photo of the stamped slip', '') : ''}`,
      sub: [p.lines.filter((l) => !l.extra).map((l) => l.label).join(', '), `planned by ${p.planned_by_name}`].filter(Boolean).join(' · '),
      level: p.plan_date < today ? 'warn' : null, screen: 'DepositPlan', params: { uid: p.uid } });
  }
  // ---- damaged / short / not delivered: until the supplier replaces or credits it
  for (const o of safe(() => require('../inventory/supplierOwed.js').listOwed({}), [])) {
    add({ key: `supplier_owed:${o.uid}`, group: 'damaged', table: 'supplier_owed', uid: o.uid, shop: o.shop_code, date: o.owed_date, amount: o.leftValue,
      title: `${o.reason === 'damaged' ? 'Damaged' : o.reason === 'short' ? 'Short' : o.reason === 'not_delivered' ? 'Not delivered' : 'Owed'}: ${o.left} × ${o.name} – not ${o.reason === 'damaged' ? 'replaced' : 'sorted'}`,
      sub: [o.supplier_name, o.invoice_no ? `invoice ${o.invoice_no}` : 'no invoice', o.days ? `${o.days} day${o.days === 1 ? '' : 's'}` : 'today', o.told_at ? 'supplier told' : 'supplier not told yet'].join(' · '),
      level: o.days >= 7 ? 'bad' : 'warn', screen: 'DamagedWaiting', params: { uid: o.uid }, supplierUid: o.supplier_uid });
  }
  // ---- cigarette invoice (7-day account): what is still needed in the cigarette money
  const CG = safe(() => require('../till/cigTally.js'), null);
  if (CG) {
    const inv = safe(() => CG.cigInvoices(), []);
    if (inv.length) {
      const shops = safe(() => CG.cigShops(), []);
      const fund = r2(shops.filter((s) => !shop || s === shop).reduce((t, s) => t + safe(() => CG.fundOf(s).balance, 0), 0));
      const owing = r2(inv.reduce((t, i) => t + i.owing, 0));
      const due = inv[0].due_date;
      add({ key: `cig:${inv.map((i) => i.uid).join(',')}`, group: 'cig', table: 'ap_invoices', uid: inv[0].uid, shop: shop || null, date: due, amount: r2(Math.max(0, owing - fund)),
        title: `Cigarette invoice${inv.length > 1 ? 's' : ''} due ${dayName(due)} ${String(due).slice(8)}/${String(due).slice(5, 7)}${owing - fund > 0.004 ? ` – ${$(owing - fund)} more needed` : ' – the money is there'}`,
        sub: `${inv.map((i) => i.invoice_no || '(no number)').join(', ')} · owing ${$(owing)} · put aside ${$(fund)}`, level: due <= addDays(today, 1) && owing - fund > 0.004 ? 'bad' : owing - fund > 0.004 ? 'warn' : null, screen: 'CigFund', params: {} });
    }
  }
  // ---- unpaid invoices with no cheque (one row per supplier) – keeps flagging until paid
  if (C && office) {
    for (const s of safe(() => C.unpaidNoChequeBySupplier({ shopCode: shop, today }), [])) {
      add({ key: `unpaid:${s.supplierUid}`, group: 'unpaid', table: 'ap_suppliers', uid: s.supplierUid, shop: shop || null, date: s.oldestDue, amount: s.owing,
        title: `${s.name} – ${s.count} unpaid, no cheque`, sub: `oldest due ${s.oldestDue}${s.overdue ? ` · ${s.overdue} overdue` : ''}`, level: s.overdue ? 'bad' : 'warn', screen: 'SupplierPage', params: { uid: s.supplierUid }, supplierUid: s.supplierUid });
    }
  }
  // ---- suggestions: order what is running low (per shop and supplier)
  if (can(user, 'po_create') || can(user, 'inventory_view') || ['owner', 'admin'].includes(user.role)) {
    const I = safe(() => require('../inventory/service.js'), null);
    const shops = shop ? [shop] : safe(() => db().all('SELECT code FROM shops WHERE active = 1 ORDER BY sort, code').map((x) => x.code), []);
    for (const sc of I ? shops : []) {
      const by = new Map();
      for (const r of safe(() => I.stockList({ shopCode: sc, filter: 'order', today }), [])) {
        const k = r.supplier_uid || '';
        const g = by.get(k) || { supplierUid: r.supplier_uid || null, name: r.supplier_name || 'No supplier yet', items: [], first: null };
        g.items.push(r); if (r.daysLeft !== null && (!g.first || r.daysLeft < g.first.daysLeft)) g.first = r;
        by.set(k, g);
      }
      for (const g of by.values()) {
        const f = g.first || g.items[0];
        add({ key: `suggest:${sc}:${g.supplierUid || 'none'}`, group: 'suggest', table: null, uid: null, shop: sc, date: today,
          title: `Suggestion: order ${g.items.length === 1 ? f.name : `${g.items.length} products`} from ${g.name}`,
          sub: `${sc}${f && f.daysLeft !== null ? ` · ${f.name}: about ${f.daysLeft} day${f.daysLeft === 1 ? '' : 's'} left` : ''}`, level: f && f.daysLeft !== null && f.daysLeft <= 2 ? 'warn' : null,
          screen: g.supplierUid ? 'POEdit' : 'NoSupplierProducts', params: g.supplierUid ? { supplierUid: g.supplierUid, shopCode: sc, suggest: true } : {} });
      }
    }
  }
  // ---- the accountant's questions (owner / admin)
  if (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole)) {
    for (const q of has('accountant_queries') ? safe(() => db().all("SELECT uid, text, by_name, created_at FROM accountant_queries WHERE status = 'open' ORDER BY created_at"), []) : []) {
      add({ key: `accountant_queries:${q.uid}`, group: 'questions', table: 'accountant_queries', uid: q.uid, shop: null, date: String(q.created_at || '').slice(0, 10), title: `Question from ${q.by_name || 'the accountant'}`, sub: String(q.text || '').slice(0, 120), level: 'warn', screen: 'Queries', params: {} });
    }
  }
  // answered questions on To verify come back to the person who asked
  // ---- everything else on To verify (cash paid, deposits, bank lines, deliveries, orders to approve, stock takes,
  //      handovers, checklists, End of day differences…). Cheques and invoices are above (their own rows).
  const q = safe(() => V.queue({ shopCode: shop || undefined }), []);
  const invShown = new Set(items.filter((x) => x.table === 'ap_invoices').map((x) => x.uid));
  for (const x of q) {
    if (x.table === 'cheques' || x.how === 'record') continue;
    if (x.table === 'money_snaps' && (x.linkTable === 'ap_invoices' && invShown.has(x.linkUid))) continue;
    if (x.table === 'money_snaps' && /^Cheque/.test(x.type || '')) continue;
    const grp = x.table === 'inv_receipts' || x.table === 'po_orders' || (x.table === 'money_snaps' && x.linkTable === 'ap_invoices') ? 'invoices' : x.table === 'aronium_eods' || x.table === 'handovers' ? 'tills' : x.table === 'deposits' ? 'deposits' : 'other';
    add({ key: x.key, group: grp, table: x.table, uid: x.uid, shop: x.shop || null, date: x.date, amount: x.amount, title: `${x.type}${x.who ? ` (${x.who})` : ''}`, sub: [x.text, x.flag].filter(Boolean).join(' · '),
      level: x.late || x.problem ? 'bad' : x.flag ? 'warn' : null, how: x.how, recordedByUid: x.recordedByUid, screen: 'TodayItem', params: { key: x.key }, query: x.query || null, go: x.go || null });
  }
  // a business-wide item (no shop) is shown to managers only when it is theirs: drop the rest
  const list = shop && !seesAllShops(user) ? items.filter((x) => x.shop === shop) : items;
  const order = Object.fromEntries(GROUPS.map((g, i) => [g.key, i]));
  const rank = (x) => (x.level === 'bad' ? 0 : x.level === 'warn' ? 1 : 2);
  list.sort((a, b) => (order[a.group] - order[b.group]) || (rank(a) - rank(b)) || String(a.date || '').localeCompare(String(b.date || '')));
  const counts = Object.fromEntries(GROUPS.map((g) => [g.key, list.filter((x) => x.group === g.key).length]));
  return { shop, today, items: list, counts, total: list.filter((x) => x.group !== 'suggest').length, suggestions: counts.suggest, done: doneToday(today, shop), glance: glance(user, shop, today) };
}

// "Business at a glance": sales yesterday (from the till PCs' End of day, only believable figures), cash in the safe,
// the BSP bank. Each figure on its own: one that cannot be worked out is left out (never a wrong number).
export function glance(user, shop, today = dateStr()) {
  const y = addDays(today, -1);
  const out = [];
  const eods = has('aronium_eods') ? safe(() => db().all("SELECT shop_code, total FROM aronium_eods WHERE eod_date = ? AND IFNULL(state,'') <> 'void'", [y]), []) : [];
  const ok = eods.filter((e) => Number.isFinite(Number(e.total)) && Number(e.total) >= 0 && Number(e.total) < 500000 && shopOk(shop, e.shop_code));
  const flagged = eods.length - ok.length - eods.filter((e) => !shopOk(shop, e.shop_code)).length;
  if (ok.length) out.push({ key: 'sales', label: 'Sales yesterday', value: $(ok.reduce((t, e) => t + Number(e.total), 0)), screen: 'DayStart', note: flagged > 0 ? `${flagged} figure${flagged === 1 ? '' : 's'} looked wrong – not counted` : null });
  if (can(user, 'deposits') || can(user, 'till_approve') || ['owner', 'admin'].includes(user.role)) {
    const P = safe(() => require('../bank/position.js'), null);
    const cash = P ? safe(() => P.cashOnHandAll().filter((c) => shopOk(shop, c.shop)), null) : null;
    if (cash && cash.length) out.push({ key: 'safe', label: 'Cash in safe', value: $(cash.reduce((t, c) => t + (Number(c.onHand) || 0), 0)), screen: 'CashOnHand' });
    if (!shop && (can(user, 'bank_rec') || can(user, 'payments_make') || ['owner', 'admin'].includes(user.role))) {
      const acc = P ? safe(() => P.mainAccount(), null) : null;
      const pos = acc ? safe(() => P.moneyPosition(acc.uid, today), null) : null;
      if (pos) out.push({ key: 'bank', label: `${acc.name || 'Bank'}`, value: $(pos.inBank), screen: 'BankRec' });
    }
  }
  return out;
}

// ---------------------------------------------------------------- one item: its papers, trail and the verify
export function todayItem(user, key, opts = {}) {
  const t = todayList(user, opts);
  return t.items.find((x) => x.key === key) || null;
}
export function itemPapers(item) {
  if (!item) return [];
  if (item.table && item.uid) return papersFor({ table: item.table, uid: item.uid });
  return [];
}
export const itemTrail = (item) => (item ? trailFor(item.key) : []);
// Verify an item from Today (the ones a person checks: cash, deliveries, handovers, checklists…), with a comment.
export function verifyToday(user, item, { note, ok = true } = {}) {
  need(item, 'Item not found.');
  need(can(user, 'verify_money') || ['owner', 'admin'].includes(user.role), 'You cannot verify.');
  const shop = todayShop(user);
  if (shop && !seesAllShops(user)) need(item.shop === shop, `You verify for ${shop} only.`);
  if (item.how === 'confirm') { if (ok) V.confirmSnap(user, item.uid, { note }); else V.rejectSnap(user, item.uid, note); return; }
  need(item.how === 'person' || item.how === 'explain' || !item.how, 'Open it to check it.');
  V.verify(user, { table: item.table, uid: item.uid, note, ok, shopCode: item.shop });
}
// Check an invoice from Today: "Correct – verify" (with an optional comment) or "Something is wrong" (a comment).
export function verifyInvoice(user, invoiceUid, { note, ok = true } = {}) {
  const AP = require('../payables/service.js');
  const i = AP.getInvoice(invoiceUid);
  need(i, 'Invoice not found.');
  const shop = todayShop(user);
  if (shop && !seesAllShops(user)) need(!i.shop_code || i.shop_code === shop, `You check invoices for ${shop} only.`);
  if (!ok) {
    need(txt(note), 'Say what is wrong.');
    addTrail(user, { key: `ap_invoices:${invoiceUid}`, table: 'ap_invoices', uid: invoiceUid, action: 'problem', note, shopCode: i.shop_code });
    safe(() => require('./queries395.js').askQuery(user, { key: `ap_invoices:${invoiceUid}`, table: 'ap_invoices', uid: invoiceUid, title: `Invoice ${i.supplier_name} ${i.invoice_no || ''} ${$(i.total)}`, toUid: i.entered_by_uid, toName: i.entered_by_name, question: note, nav: { screen: 'TodayInvoice', params: { uid: invoiceUid } } }), null);
    return;
  }
  AP.checkInvoice(user, invoiceUid);
  addTrail(user, { key: `ap_invoices:${invoiceUid}`, table: 'ap_invoices', uid: invoiceUid, action: 'checked', note, shopCode: i.shop_code });
  safe(() => require('./queries395.js').closeQueriesFor(`ap_invoices:${invoiceUid}`), null);
}
