// 1.0.0 The verify trail: every verify, problem, undo and confirm made on Today / To verify is kept as its own line
// (who, when, the optional comment). The verifications table keeps only the latest state; this keeps the history.
import { db } from '../../db/connection.js';
import { stamp, uuid, deviceId } from '../../services/core.js';
import { requirePerm, asService } from '../../services/guard.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'verify_trail'"); } catch (e) { return false; } };

export const TRAIL_ACTION = { verified: 'Verified', problem: 'Something is wrong', undone: 'Verification undone', confirmed: 'Photo confirmed', rejected: 'Photo rejected', checked: 'Invoice checked', comment: 'Comment', approved: 'Approved' };

// item key: `${table}:${uid}` (the same key To verify uses).
export function addTrail(user, { key, table, uid, action, note, shopCode } = {}) {
  requirePerm(user, 'verify_money'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!has() || !key || !action) return null;
  const now = stamp();
  const id = uuid('VT');
  try {
    db().run(`INSERT INTO verify_trail (uid, item_key, table_name, record_uid, action, note, shop_code, by_name, by_uid, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, key, table || null, uid || null, action, txt(note) || null, shopCode || null, user ? user.name : null, user ? user.uid : null, now, now, deviceId()]);
  } catch (e) { return null; }
  return id;
  });
}
export function trailFor(key) {
  if (!has() || !key) return [];
  return db().all('SELECT * FROM verify_trail WHERE item_key = ? ORDER BY at, uid', [key]).map((t) => ({ ...t, label: TRAIL_ACTION[t.action] || t.action }));
}
// Done today (for the "2 done today" line on Today), optionally one shop.
export function doneToday(day, shopCode) {
  if (!has()) return 0;
  try { return db().get(`SELECT COUNT(DISTINCT item_key) AS n FROM verify_trail WHERE at >= ? AND at < ? AND action IN ('verified','confirmed','checked','approved') AND (? IS NULL OR shop_code = ?)`, [`${day} 00:00:00`, `${day} 99`, shopCode || null, shopCode || null]).n || 0; } catch (e) { return 0; }
}
