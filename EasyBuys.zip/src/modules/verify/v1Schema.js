// 1.0.0 (new simple app) tables for Today, the cheque chain and deposit plans – one file so moreSchemas.js only needs one line.
//  • verify_trail: every verify / problem / undo / confirm on Today, with who, when and the comment (never overwritten).
//  • cheque_steps: the cheque chain steps that have no other place with a date AND time and who (written, waiting for
//    pickup, given to the supplier, linked to an invoice, cleared). Invoice received / checked come from the invoice.
//  • deposit_plans: a deposit planned (by a supervisor or manager) to cover cheques: planned → slip written → banked
//    (photo of the stamped slip) → shows on the bank. Each step keeps who and when.
//  • Speed indexes for Today (one pass over thousands of records).
export const V1C_SQL = `
CREATE TABLE IF NOT EXISTS verify_trail (
  uid TEXT PRIMARY KEY,
  item_key TEXT NOT NULL,
  table_name TEXT, record_uid TEXT,
  action TEXT NOT NULL,
  note TEXT,
  shop_code TEXT,
  by_name TEXT, by_uid TEXT, at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_vt_key ON verify_trail(item_key, at);
CREATE TABLE IF NOT EXISTS cheque_steps (
  uid TEXT PRIMARY KEY,
  cheque_uid TEXT,
  snap_uid TEXT,
  step TEXT NOT NULL,
  note TEXT,
  by_name TEXT, by_uid TEXT, at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_cs_chq ON cheque_steps(cheque_uid, at);
CREATE TABLE IF NOT EXISTS deposit_plans (
  uid TEXT PRIMARY KEY,
  shop_code TEXT,
  account_uid TEXT,
  plan_date TEXT NOT NULL,
  cash_from TEXT,
  lines TEXT,
  total REAL NOT NULL DEFAULT 0,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'planned',
  planned_by_name TEXT, planned_by_uid TEXT, planned_at TEXT,
  slip_no TEXT, slip_by_name TEXT, slip_at TEXT,
  banked_by_name TEXT, banked_at TEXT, banked_amount REAL, deposit_uid TEXT, photo_urls TEXT,
  on_bank_by_name TEXT, on_bank_at TEXT, on_bank_date TEXT,
  void_reason TEXT, voided_by_name TEXT, voided_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_dp_status ON deposit_plans(status, plan_date);
CREATE INDEX IF NOT EXISTS idx_invread_rc ON invoice_reads(receipt_uid);
CREATE INDEX IF NOT EXISTS idx_api_status ON ap_invoices(status, kind);
CREATE INDEX IF NOT EXISTS idx_chq_status ON cheques(status, cheque_date);
CREATE INDEX IF NOT EXISTS idx_snap_date ON money_snaps(snap_date);
CREATE INDEX IF NOT EXISTS idx_rc_date ON inv_receipts(receive_date);
CREATE INDEX IF NOT EXISTS idx_app_status ON ap_payments(status, method);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const V1C_SYNC = {
  verify_trail: SYNC('uid', 'To verify', ['uid', 'item_key', 'table_name', 'record_uid', 'action', 'note', 'shop_code', 'by_name', 'by_uid', 'at']),
  cheque_steps: SYNC('uid', 'Cheques & bank', ['uid', 'cheque_uid', 'snap_uid', 'step', 'note', 'by_name', 'by_uid', 'at']),
  deposit_plans: SYNC('uid', 'Till & cash', ['uid', 'shop_code', 'account_uid', 'plan_date', 'cash_from', 'lines', 'total', 'note', 'status', 'planned_by_name', 'planned_by_uid', 'planned_at',
    'slip_no', 'slip_by_name', 'slip_at', 'banked_by_name', 'banked_at', 'banked_amount', 'deposit_uid', 'photo_urls', 'on_bank_by_name', 'on_bank_at', 'on_bank_date', 'void_reason', 'voided_by_name', 'voided_at']),
};
