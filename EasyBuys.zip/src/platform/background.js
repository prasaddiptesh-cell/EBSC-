// v3.9.6 Background sync on every device: when the app is closed or in the background, Android wakes it about every
// 15 minutes (Android decides the exact time and may wait longer to save battery) to send and fetch changes, and to
// tell the people who verify about new papers in To verify. Nothing here may ever crash the app: every step is
// guarded, and the app works the same if the phone does not allow background work.
import { Platform } from 'react-native';

export const SYNC_TASK = 'easybuys-background-sync';
let TM = null; let BT = null;
try { TM = require('expo-task-manager'); } catch (e) { TM = null; }
try { BT = require('expo-background-task'); } catch (e) { BT = null; }

// Sends the "new to verify" notification for anything new (used after every sync, in front or behind).
export async function tellNewToVerify() {
  try {
    const W = require('../services/verifyWatch.js');
    const { withSystem } = require('../db/connection.js');
    const r = withSystem(() => W.newToVerify());
    const msg = W.verifyMessage(r.items);
    if (!msg) return 0;
    const N = require('expo-notifications');
    await N.scheduleNotificationAsync({
      content: { title: msg.title, body: msg.body, sound: 'default', data: { screen: 'Verify' }, ...(Platform.OS === 'android' ? { channelId: 'warnings-2' } : {}) },
      trigger: null,
    });
    return r.items.length;
  } catch (e) { return 0; }
}

async function runOnce() {
  const started = Date.now();
  try {
    const core = require('../services/core.js');
    core.setSetting('bg_last_run', core.stamp());
    const { syncNow } = require('./cloud.js');
    await syncNow();
    await tellNewToVerify();
    core.setSetting('bg_last_ok', core.stamp());
    core.setSetting('bg_last_ms', String(Date.now() - started));
  } catch (e) {
    try { require('../services/core.js').setSetting('bg_last_error', String(e && e.message || e).slice(0, 200)); } catch (x) { /* nothing more to do */ }
  }
}

// Must run when the app's code is first loaded (index.js), also when Android starts it only for the background work.
if (TM && BT && Platform.OS !== 'web') {
  try {
    TM.defineTask(SYNC_TASK, async () => {
      await runOnce();
      return BT.BackgroundTaskResult.Success;
    });
  } catch (e) { /* background work not available on this phone */ }
}

// Called at start-up: ask Android to wake the app about every 15 minutes.
export async function startBackgroundSync() {
  if (!TM || !BT || Platform.OS === 'web') return { on: false, why: 'not available' };
  try {
    const status = await BT.getStatusAsync();
    if (status !== BT.BackgroundTaskStatus.Available) return { on: false, why: 'restricted' };
    const done = await TM.isTaskRegisteredAsync(SYNC_TASK);
    if (!done) await BT.registerTaskAsync(SYNC_TASK, { minimumInterval: 15 });
    return { on: true };
  } catch (e) { return { on: false, why: String(e && e.message || e) }; }
}
export function backgroundInfo() {
  try {
    const g = require('../services/core.js').getSetting;
    return { lastRun: g('bg_last_run', ''), lastOk: g('bg_last_ok', ''), lastError: g('bg_last_error', '') };
  } catch (e) { return {}; }
}
