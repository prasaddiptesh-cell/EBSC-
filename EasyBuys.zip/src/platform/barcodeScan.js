// Continuous barcode scanning with the camera (expo-camera): keeps reading, one code at a time.
// The same code is ignored for a moment so one scan is not counted twice; `paused` stops it while the quantity is asked.
// Without a camera (or permission) it says so; a handheld scanner or typing still works (see ScanBar).
import React, { useRef, useEffect } from 'react';
import { View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Text } from '../ui/scale.js';

export const PRODUCT_BARCODES = ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39', 'qr'];
export const REPEAT_MS = 1500;
// Pure: should this read be used? (exported for tests)
export function acceptScan(last, code, now, repeatMs = REPEAT_MS) {
  if (!code) return false;
  return !(last && last.code === code && now - last.at < repeatMs);
}
export function ContinuousScanner({ onScan, paused, height = 220 }) {
  const [perm, requestPerm] = useCameraPermissions();
  const last = useRef(null);
  useEffect(() => { if (perm && !perm.granted && perm.canAskAgain) requestPerm(); }, [perm, requestPerm]);
  const box = { width: '100%', maxWidth: 520, height, backgroundColor: '#111', borderRadius: 16, overflow: 'hidden', alignSelf: 'center' };
  if (!perm) return <View style={box} />;
  if (!perm.granted) {
    return (
      <View style={[box, { alignItems: 'center', justifyContent: 'center', padding: 12 }]}>
        <Text style={{ color: '#fff', textAlign: 'center', fontSize: 15 }}>Camera not allowed.{'\n'}Allow it in Android Settings › Apps › Easy Buys, or use a handheld scanner / type the code.</Text>
      </View>
    );
  }
  return (
    <View testID="barcode-camera" style={box}>
      <CameraView facing="back" style={{ flex: 1 }} barcodeScannerSettings={{ barcodeTypes: PRODUCT_BARCODES }}
        onBarcodeScanned={paused ? undefined : (r) => {
          const code = r && r.data ? String(r.data).trim() : '';
          const now = Date.now();
          if (!acceptScan(last.current, code, now)) return;
          last.current = { code, at: now };
          onScan(code);
        }} />
    </View>
  );
}
