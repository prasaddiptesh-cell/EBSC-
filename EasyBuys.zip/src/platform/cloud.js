// Sends data to the bakery's Google account (via the Apps Script "bakery cloud").
// Works offline-first: everything waits in the outbox until the tablet is online.
import { db } from '../db/connection.js';
import { getSettings, setSetting, getSetting, stamp, APP_VERSION, dateStr, deviceId, deviceName } from '../services/core.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor, SYNC_TABLES } from '../services/records.js';
import { setSyncState } from '../services/syncBus.js';
import { pendingOutbox, markOutboxSent, markOutboxFailed, getPhoto, setPhotoCloudUrl, markPoSent, enqueue } from '../services/stock.js';
import { shiftReport, purchaseOrderDoc } from '../services/reports.js';
import { markReportSent, getShift } from '../services/shifts.js';
import { buildSnapshot } from '../services/dashboard.js';
import { applyOnlinePlans, planSeq } from '../services/plan.js';
import { reportPdf, reportXlsx, fileBase64, fileExists } from './files.js';
import { retireSampleLogins } from '../modules/devices/service.js';
import { contractReport } from '../modules/people/service.js';
import { isTraining } from '../services/trainingFlag.js';
import { getDocument, setCloudCopy, setLocalPath, extFor } from '../services/documents.js';
import * as FS from 'expo-file-system/legacy';

let running = false;

// Any request to the cloud. Linked devices send their own token; the first device may use the cloud key.
export async function cloudCall(body, timeoutMs = 60000) {
  return post(body, timeoutMs);
}

async function post(body, timeoutMs = 90000) {
  const s = getSettings();
  const token = getSetting('cloud_token', '');
  if (!s.cloudUrl) throw new Error('The cloud web address is not set (Admin → Settings → Online & email).');
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(s.cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ key: token ? undefined : s.cloudKey, token: token || undefined, app: APP_VERSION, location: s.locationName, sentAt: stamp(), device: { id: deviceId(), name: deviceName(), kind: getSetting('device_kind', 'tablet') }, ...body }),
      signal: ctrl ? ctrl.signal : undefined,
    });
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw new Error(res.status === 200 ? 'The cloud did not reply correctly. Check the web address and that it is deployed for "Anyone".' : `Cloud error ${res.status}`);
    }
    if (json.waiting) setSetting('link_waiting', '1');
    // The owner blocked this device (lost or stolen): lock it until it is unblocked.
    setSetting('device_blocked', json.blocked ? '1' : (json.ok ? '0' : getSetting('device_blocked', '0')));
    if (!json.ok) throw new Error(json.error || 'The cloud refused the request.');
    if (getSetting('link_waiting', '') === '1') setSetting('link_waiting', '0');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function testConnection() {
  const r = await post({ kind: 'ping' }, 30000);
  return r;
}

// Every table (Easy Buys and Bakery) for the daily backup in Google Drive. PINs, passwords and the cloud key are hidden.
export function dumpDatabase() {
  const tables = db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('outbox') ORDER BY name").map((r) => r.name);
  const out = { _meta: { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: tables.length } };
  for (const t of tables) {
    out[t] = db().all(`SELECT * FROM ${t}`).map((r) => {
      if (t === 'users') return { ...r, pin: r.pin ? '****' : r.pin, pin_hash: r.pin_hash, password_hash: r.password_hash ? '****' : null };
      if (t === 'settings' && /key|token|secret/i.test(String(r.key))) return { ...r, value: '****' };
      return r;
    });
  }
  return out;
}
// Put back the shared records from a backup file (owner only, from Admin). Records in the backup replace the same
// records here and are sent to the cloud again; nothing else is deleted. Logins and device settings are not touched.
export function restoreBackup(data) {
  let n = 0;
  const skip = new Set(['users', 'settings', 'shared_settings']);
  db().transaction(() => {
    for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
      if (skip.has(t) || !Array.isArray(data[t])) continue;
      const cols = db().all(`PRAGMA table_info(${t})`).map((c) => c.name);
      for (const row of data[t]) {
        // Restored rows are stamped now so the cloud takes them as the newest version.
        const r2 = { ...row, ...(cols.includes('updated_at') ? { updated_at: stamp() } : {}), ...(cols.includes('updated_device') ? { updated_device: deviceId() } : {}) };
        const keys = Object.keys(r2).filter((k) => cols.includes(k) && k !== 'sync_status');
        if (!keys.length || r2[cfg.key] === undefined) continue;
        db().run(`INSERT OR REPLACE INTO ${t} (${keys.join(', ')}, sync_status) VALUES (${keys.map(() => '?').join(', ')}, 'pending')`, keys.map((k) => r2[k]));
        n += 1;
      }
    }
  });
  return n;
}
export async function backupNow() {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    const d = dateStr();
    await post({ kind: 'backup', fileName: `backup-${d}-${stamp().slice(11, 16).replace(':', '')}.json`, data: JSON.stringify(dumpDatabase()) }, 300000);
    setSetting('last_backup_at', stamp());
    return { ok: true, message: 'Backed up to Google Drive (Easy Buys › Backups).' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

function addPhotoUrl(table, uid, url) {
  let row = null;
  try { row = db().get(`SELECT photo_urls FROM ${table} WHERE uid = ?`, [uid]); } catch (e) { return; }
  if (!row) return;
  let list = [];
  try { list = JSON.parse(row.photo_urls || '[]'); } catch (e) { list = []; }
  if (!list.includes(url)) list.push(url);
  db().run(`UPDATE ${table} SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
}

// Ask Google to read an invoice's photos and fill in the invoice. Returns { ok, message }.
async function readInvoice(invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText } = require('../modules/payables/service.js');
  const pics = listPhotos('invoice', invoiceUid).slice(0, 4);
  const files = [];
  for (const ph of pics) if (await fileExists(ph.uri)) files.push({ mimeType: 'image/jpeg', data: await fileBase64(ph.uri) });
  if (!files.length) return { ok: false, message: 'There is no photo of this invoice on this device.' };
  const r = await post({ kind: 'ocr', files }, 180000);
  if (r.off) {
    db().run("UPDATE ap_invoices SET ocr_status = 'type', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      ['Reading photos is not switched on in the Google cloud yet. Please type the details.', stamp(), deviceId(), invoiceUid]);
    return { ok: false, message: "Google's photo reading is not switched on yet. One-time step: in the Google Apps Script project click Services ➕ › Drive API › Add, then Deploy › Manage deployments › New version." };
  }
  const inv = applyReadText(invoiceUid, r.text || '');
  if (!r.text) return { ok: false, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  return { ok: true, invoice: inv, message: inv && inv.total ? 'Read – please check the figures.' : 'Read, but the total was not found. Please type it.' };
}

// "Read this photo now" button: straight away, not waiting for the next sync.
// Admin: give the cloud the Viber Channel token (kept only in the cloud) and send a test message.
export async function setupViberChannel(token, oldToken) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    const r = await post({ kind: 'viber_setup', token: String(token || '').trim(), oldToken: String(oldToken || '').trim() }, 45000);
    return r.ok ? { ok: true, message: r.message || 'Viber Channel connected – a test message was sent.' } : { ok: false, message: r.error || 'Viber did not accept the token.' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

export async function readInvoiceNow(invoiceUid) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'This device is not linked to the Easy Buys cloud yet (Admin › Online & email, or Link to Easy Buys). Photos are read by Google when online.' };
  try {
    return await readInvoice(invoiceUid);
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. It will be read by itself when the device is back online.' : m };
  }
}

async function handle(item) {
  const s = getSettings();
  const p = item.payload;
  if (item.kind === 'report') {
    const rep = shiftReport(p.shiftId);
    if (!rep) return;
    const pdf = await reportPdf(rep);
    const xlsx = await reportXlsx(rep);
    const sh = getShift(p.shiftId);
    await post({
      kind: 'report', emails: s.reportEmails, subject: `${s.bakeryName} – Shift report ${sh.shift_date} ${sh.shift_name} (${sh.code})`,
      html: pdf.html, fileName: rep.fileName, pdf: pdf.base64, xlsx: xlsx.base64, month: sh.shift_date.slice(0, 7), shiftCode: sh.code,
      summary: rep.summary,
    }, 180000);
    markReportSent(p.shiftId);
  } else if (item.kind === 'po') {
    const doc = purchaseOrderDoc(p.poId);
    if (!doc) return;
    const pdf = await reportPdf(doc);
    await post({
      kind: 'po', emails: s.poEmails.length ? s.poEmails : s.reportEmails, subject: `${s.bakeryName} – Purchase order ${doc.po.po_no} (${doc.po.supplier || 'supplier'})`,
      html: pdf.html, fileName: doc.fileName, pdf: pdf.base64, month: doc.po.created_at.slice(0, 7), supplierEmail: doc.po.supplier_email || '',
    }, 120000);
    markPoSent(p.poId);
  } else if (item.kind === 'photo') {
    const ph = getPhoto(p.photoId);
    if (!ph || !(await fileExists(ph.uri))) return;
    const data = await fileBase64(ph.uri);
    const r = await post({ kind: 'photo', refType: ph.ref_type, refId: ph.ref_id, data, fileName: `${ph.ref_type}-${ph.ref_id}-${ph.id}.jpg`, month: ph.created_at.slice(0, 7) }, 180000);
    if (r.url) {
      setPhotoCloudUrl(ph.id, r.url);
      // Easy Buys modules: put the Drive link on the record so every device can open the photo.
      const link = { punch: 'punches', leave: 'leave_requests' }[ph.ref_type];
      if (link) db().run(`UPDATE ${link} SET photo_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.url, stamp(), deviceId(), ph.ref_id]);
      // Records with several photos (invoice pages, receipts, Z reports) keep a list of links.
      const many = { invoice: 'ap_invoices', payment: 'ap_payments', till: 'till_counts', deposit: 'deposits', cash: 'cash_moves', snap: 'money_snaps', receipt: 'inv_receipts', stat: 'stat_payments', asset: 'fixed_assets', statement: 'supplier_statements', applicant: 'applicants', charge: 'staff_charges' }[ph.ref_type];
      if (many) addPhotoUrl(many, ph.ref_id, r.url);
    }
  } else if (item.kind === 'doc_upload') {
    // A document (licence copy, application, contract…) goes to Google Drive › Easy Buys › Documents.
    const d = getDocument(p.uid);
    if (!d || d.cloud_id || !d.path || !(await fileExists(d.path))) return;
    const data = await fileBase64(d.path);
    const r = await post({ kind: 'file_put', folder: d.ref_type, fileName: `${d.uid}-${String(d.name).replace(/[^A-Za-z0-9 ._-]+/g, '-').slice(0, 60)}.${extFor(d.mime, d.name)}`, mime: d.mime || 'application/octet-stream', data }, 300000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
    if (r && r.id) setCloudCopy(d.uid, r.id, r.url);
  } else if (item.kind === 'email' || item.kind === 'contract_email') {
    let attachments = [];
    if (item.kind === 'contract_email') {
      // The company's own PDF (signed and stamped) when the contract was made from it; otherwise the app's contract.
      const signed = p.docUid ? getDocument(p.docUid) : null;
      const b64 = signed ? await documentBase64(signed) : (await reportPdf(contractReport(p.contractUid))).base64;
      attachments = [{ name: `${p.subject.replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64, mime: 'application/pdf' }];
    }
    const r = await post({ kind: 'email', to: p.to, subject: p.subject, text: p.text, attachments }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'calendar') {
    const r = await post({ kind: 'calendar', ...p }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'viber') {
    const r = await post({ kind: 'viber', text: p.text }, 45000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'ocr') {
    await readInvoice(p.invoiceUid);
  } else if (item.kind === 'backup') {
    await post({ kind: 'backup', fileName: `backup-${p.date}.json`, data: JSON.stringify(dumpDatabase()) }, 300000);
    setSetting('last_backup_at', stamp());
  }
}

// One sync round: send the live status, then work through the outbox.
// Shared records (staff, punches, timesheets, leave...): send ours, then fetch other devices' changes.
async function syncRecords() {
  let sent = 0;
  let received = 0;
  for (let round = 0; round < 20; round++) {
    const batch = pendingRecords(200);
    if (!batch.length) break;
    const r = await post({ kind: 'push', records: batch }, 90000);
    markRecordsSent(batch);
    sent += batch.length;
    if (r.rejected && r.rejected.length) setSetting('last_rejected', JSON.stringify(r.rejected.slice(0, 20)));
  }
  for (let round = 0; round < 20; round++) {
    const r = await post({ kind: 'pull', since: pullCursor() }, 90000);
    const list = r.records || [];
    if (list.length) received += applyPulledRecords(list);
    if (typeof r.next === 'number') setPullCursor(r.next);
    if (!r.more) break;
  }
  try { retireSampleLogins(); } catch (e) { /* try again next round */ }
  return { sent, received };
}

export async function syncNow({ force = false } = {}) {
  const s = getSettings();
  if (!s.cloudUrl || running || isTraining()) return { skipped: true };
  running = true;
  setSyncState({ running: true, lastTry: stamp() });
  let sent = 0;
  let received = 0;
  let error = null;
  let planChanged = 0;
  try {
    const rec = await syncRecords();
    sent += rec.sent;
    received = rec.received;
    const today = dateStr();
    if (getSetting('last_backup_date') !== today) {
      enqueue('backup', { date: today });
      setSetting('last_backup_date', today);
    }
    const r = await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 45000);
    // Plan changes made on the online dashboard come back with the reply.
    if (r.planEdits && r.planEdits.length) {
      planChanged = applyOnlinePlans(r.planEdits);
      await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 45000); // confirm to the dashboard straight away
    }
    for (const item of pendingOutbox(force ? 50 : 10)) {
      try {
        await handle(item);
        markOutboxSent(item.id);
        sent += 1;
      } catch (e) {
        markOutboxFailed(item.id, e.message || e);
        error = e.message || String(e);
        // No internet: stop and try again next round. Anything else (e.g. a bad email address): skip it so it does not hold up the rest.
        if (/network|fetch|abort|timed|offline|Failed to/i.test(error)) break;
      }
    }
    setSetting('last_sync_at', stamp());
  } catch (e) {
    error = e.message || String(e);
  } finally {
    running = false;
    setSetting('last_sync_error', error || '');
    if (!error) setSetting('last_sync_ok_at', stamp());
    setSyncState({ running: false, error: error || '', lastOk: getSetting('last_sync_ok_at', ''), sent, received });
  }
  return { sent, received, error, planChanged };
}

export function syncStatus() {
  return {
    configured: !!getSettings().cloudUrl,
    lastOk: getSetting('last_sync_ok_at', ''),
    lastTry: getSetting('last_sync_at', ''),
    error: getSetting('last_sync_error', ''),
  };
}

// ---------------------------------------------------------------- documents kept in Google Drive
// The file of a document as base64: from this device, or fetched from the cloud copy (then kept here too).
export async function documentBase64(d) {
  if (d.path && (await fileExists(d.path))) return fileBase64(d.path);
  if (!d.cloud_id) throw new Error('This document is on another device and has not reached the cloud yet. Open it there, or sync that device first.');
  if (isTraining()) throw new Error('Not available in training mode.');
  const r = await post({ kind: 'file_get', id: d.cloud_id }, 300000);
  if (!r || !r.data) throw new Error((r && r.error) || 'Could not fetch the document from the cloud.');
  const dir = `${FS.documentDirectory}docs/`;
  try { await FS.makeDirectoryAsync(dir, { intermediates: true }); } catch (e) { /* already there */ }
  const path = `${dir}${d.uid}.${extFor(d.mime, d.name)}`;
  await FS.writeAsStringAsync(path, r.data, { encoding: FS.EncodingType.Base64 });
  setLocalPath(d.uid, path);
  return r.data;
}
