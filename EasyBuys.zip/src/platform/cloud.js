// Sends data to the bakery's Google account (via the Apps Script "bakery cloud").
// Works offline-first: everything waits in the outbox until the tablet is online.
import { db, withSystem } from '../db/connection.js';
import { getSettings, setSetting, getSetting, stamp, APP_VERSION, dateStr, deviceId, deviceName, minutesBetween } from '../services/core.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor, SYNC_TABLES, pendingBySection } from '../services/records.js';
import { snapshotNow } from '../services/snapshots.js';
import { applyFresh, freshMarker } from '../services/startFresh.js';
import { postBakeryReceipts } from '../modules/bakery/store.js';
import { recipientsFor, sendAnswered, packDue, noteMade } from '../services/emailPrefs.js';
import { accountantPack } from '../modules/accounting/statements.js';
import { autoViberAlerts } from '../services/viberAuto.js';
import { deviceStat, applyControl, runCommands, setDeviceLock, wipeThisDevice, deviceLock } from '../modules/devices/control.js';
import { cachedDevices, cacheDevices } from '../modules/devices/service.js';
import { setSyncState } from '../services/syncBus.js';
import { pendingOutbox, markOutboxSent, markOutboxFailed, getPhoto, setPhotoCloudUrl, markPoSent, enqueue, countPendingOutbox } from '../services/stock.js';
import { shiftReport, purchaseOrderDoc } from '../services/reports.js';
import { markReportSent, getShift } from '../services/shifts.js';
import { buildSnapshot } from '../services/dashboard.js';
import { applyOnlinePlans, planSeq } from '../services/plan.js';
import { reportPdf, reportXlsx, fileBase64, fileExists } from './files.js';
import { retireSampleLogins } from '../modules/devices/service.js';
import { contractReport } from '../modules/people/service.js';
import { isTraining } from '../services/trainingFlag.js';
import { getDocument, setCloudCopy, setLocalPath, extFor } from '../services/documents.js';
import * as FS from 'expo-file-system/legacy';
import { describeDocument, uploadIdFor, markUploading, markUploaded, markUploadFailed, markFetched, localCopiesToClear, markLocalCleared, filesToFetch, backupDue, backupManifest } from '../services/driveDocs.js';
import { base64Fingerprint } from '../services/sha256.js';
import { appUser } from '../services/errorLog.js';

let running = false;

// Any request to the cloud. Linked devices send their own token; the first device may use the cloud key.
export async function cloudCall(body, timeoutMs = 60000) {
  return post(body, timeoutMs);
}

// v3.9.2 in practice (training) mode only these read-only requests reach the cloud – nothing is changed for real.
const TRAINING_OK = ['ping', 'devices', 'ocr', 'problem_log_get', 'file_get', 'check_update'];
async function post(body, timeoutMs = 90000) {
  if (isTraining() && !TRAINING_OK.includes(body && body.kind)) throw new Error('Not available in practice mode – nothing is sent to the cloud. Switch back to the real app first (Admin › Training).');
  const s = getSettings();
  const token = getSetting('cloud_token', '');
  if (!s.cloudUrl) throw new Error('The cloud web address is not set (Admin → Settings → Online & email).');
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(s.cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ key: token ? undefined : s.cloudKey, token: token || undefined, app: APP_VERSION + (getSetting('fresh_applied', '') ? ` fresh:${String(getSetting('fresh_applied', '')).slice(-6)}` : ''), location: s.locationName, sentAt: stamp(), device: { id: deviceId(), name: deviceName(), kind: getSetting('device_kind', 'tablet') }, ...body }),
      signal: ctrl ? ctrl.signal : undefined,
    });
    const text = await res.text();
    // v3.9.3 the device clock checked against Google's: a wrong clock refuses entries and confuses sync.
    try {
      const hd = res.headers && res.headers.get ? res.headers.get('date') : null;
      const t = hd ? Date.parse(hd) : NaN;
      if (Number.isFinite(t) && !isTraining()) setSetting('clock_skew_min', String(Math.round((Date.now() - t) / 60000)));
    } catch (e) { /* no date header */ }
    let json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw new Error(res.status === 200 ? 'The cloud did not reply correctly. Check the web address and that it is deployed for "Anyone".' : `Cloud error ${res.status}`);
    }
    if (json.waiting) setSetting('link_waiting', '1');
    if (isTraining()) { if (!json.ok) throw new Error(json.error || 'The cloud refused the request.'); return json; } // practice: never locks
    // The owner blocked this device (lost or stolen): lock it until it is unblocked.
    setSetting('device_blocked', json.blocked ? '1' : (json.ok ? '0' : getSetting('device_blocked', '0')));
    if (json.ok && !json.lock) { try { require('../modules/devices/control.js').clearLockOverride(); } catch (e) { /* none */ } }
    // v3.6 Admin › Devices: paused, access ended, removed or wiped (the cloud enforces it; the device shows why).
    if (json.wipe) { try { withSystem(() => wipeThisDevice()); } catch (e) { withSystem(() => setDeviceLock({ kind: 'wiped' })); } }
    else if (json.lock) withSystem(() => setDeviceLock(json.lock));
    else if (json.removed && getSetting('cloud_token', '')) withSystem(() => setDeviceLock({ kind: 'removed' }));
    else if (json.ok) { const l = deviceLock(); if (l && l.kind !== 'wiped' && l.kind !== 'blocked') withSystem(() => setDeviceLock(null)); }
    if (!json.ok) throw new Error(json.error || 'The cloud refused the request.');
    if (getSetting('link_waiting', '') === '1') setSetting('link_waiting', '0');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function testConnection() {
  const r = await post({ kind: 'ping' }, 30000);
  if (r && r.version) setSetting('cloud_script_version', String(r.version));
  return r;
}

// Every table (Easy Buys and Bakery) for the daily backup in Google Drive. PINs, passwords and the cloud key are hidden.
export function dumpDatabase() {
  const tables = db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('outbox') ORDER BY name").map((r) => r.name);
  const out = { _meta: { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: tables.length } };
  for (const t of tables) {
    out[t] = db().all(`SELECT * FROM ${t}`).map((r) => {
      if (t === 'users') return { ...r, pin: r.pin ? '****' : r.pin, pin_hash: r.pin_hash, password_hash: r.password_hash ? '****' : null };
      if (t === 'settings' && /key|token|secret/i.test(String(r.key))) return { ...r, value: '****' };
      return r;
    });
  }
  return out;
}
// Put back the shared records from a backup file (owner only, from Admin). Records in the backup replace the same
// records here and are sent to the cloud again; nothing else is deleted. Logins and device settings are not touched.
export function restoreBackup(data) {
  let n = 0;
  const skip = new Set(['users', 'settings', 'shared_settings']);
  db().transaction(() => {
    for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
      if (skip.has(t) || !Array.isArray(data[t])) continue;
      const cols = db().all(`PRAGMA table_info(${t})`).map((c) => c.name);
      for (const row of data[t]) {
        // Restored rows are stamped now so the cloud takes them as the newest version.
        const r2 = { ...row, ...(cols.includes('updated_at') ? { updated_at: stamp() } : {}), ...(cols.includes('updated_device') ? { updated_device: deviceId() } : {}) };
        const keys = Object.keys(r2).filter((k) => cols.includes(k) && k !== 'sync_status');
        if (!keys.length || r2[cfg.key] === undefined) continue;
        db().run(`INSERT OR REPLACE INTO ${t} (${keys.join(', ')}, sync_status) VALUES (${keys.map(() => '?').join(', ')}, 'pending')`, keys.map((k) => r2[k]));
        n += 1;
      }
    }
  });
  return n;
}
export async function backupNow() {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    const d = dateStr();
    await post({ kind: 'backup', fileName: `backup-${d}-${stamp().slice(11, 16).replace(':', '')}.json`, data: JSON.stringify(dumpDatabase()) }, 300000);
    setSetting('last_backup_at', stamp());
    return { ok: true, message: 'Backed up to Google Drive (Easy Buys › Backups).' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

function addPhotoUrl(table, uid, url) {
  let row = null;
  try { row = db().get(`SELECT photo_urls FROM ${table} WHERE uid = ?`, [uid]); } catch (e) { return; }
  if (!row) return;
  let list = [];
  try { list = JSON.parse(row.photo_urls || '[]'); } catch (e) { list = []; }
  if (!list.includes(url)) list.push(url);
  db().run(`UPDATE ${table} SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
}

// Ask Google to read an invoice's photos and fill in the invoice. Returns { ok, message }.
async function readInvoice(invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText } = require('../modules/payables/service.js');
  const pics = listPhotos('invoice', invoiceUid).slice(0, 6);
  const files = [];
  for (const ph of pics) if (await fileExists(ph.uri)) files.push({ mimeType: 'image/jpeg', data: await fileBase64(ph.uri) });
  if (!files.length) return { ok: false, message: 'There is no photo of this invoice on this device.' };
  const r = await post({ kind: 'ocr', files }, 180000);
  if (r.off) {
    db().run("UPDATE ap_invoices SET ocr_status = 'type', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      ['Reading photos is not switched on in the Google cloud yet. Please type the details.', stamp(), deviceId(), invoiceUid]);
    return { ok: false, message: "Google's photo reading is not switched on yet. One-time step: in the Google Apps Script project click Services ➕ › Drive API › Add, then Deploy › Manage deployments › New version." };
  }
  const inv = applyReadText(invoiceUid, r.text || '');
  if (!r.text) return { ok: false, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  return { ok: true, invoice: inv, message: inv && inv.total ? 'Read – please check the figures.' : 'Read, but the total was not found. Please type it.' };
}

// "Read this photo now" button: straight away, not waiting for the next sync.
// Admin: give the cloud the Viber Channel token (kept only in the cloud) and send a test message.
export async function setupViberChannel(token, oldToken) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    // v3.9.4 the Viber token travels as viberToken: "token" is this device's own pass to the cloud (sending the Viber
    // token there made the cloud say "This device is not linked any more").
    // v3.9.6 ask the cloud which script it runs now (the version was only noted when this device sent the dashboard,
    // so a freshly pasted script could still be taken for the old one).
    if (Number(getSetting('cloud_script_version', '0')) < 8) {
      try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); } catch (e) { /* the check below says what to do */ }
    }
    if (Number(getSetting('cloud_script_version', '0')) < 8) return { ok: false, message: `The cloud still runs script version ${getSetting('cloud_script_version', '?') || '?'}. Paste the new cloud script (version 8), then Deploy › Manage deployments › ✏️ › Version: New version › Deploy. Then try again.` };
    const r = await post({ kind: 'viber_setup', viberToken: String(token || '').trim(), oldToken: String(oldToken || '').trim(), selfUrl: getSettings().cloudUrl }, 45000);
    return r.ok ? { ok: true, message: r.message || 'Viber Channel connected – a test message was sent.' } : { ok: false, message: r.error || 'Viber did not accept the token.' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

// Bank / M-PAiSA statements (v3.5): Google reads the text of a PDF or a screenshot. files: [{ mimeType, data (base64) }].
export async function readTextNow(files) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Reading a PDF or photo needs the Easy Buys cloud (this device is not linked). Copy the text from the PDF and paste it instead.' };
  try {
    const r = await post({ kind: 'ocr', files: (files || []).slice(0, 6) }, 180000);
    if (r.off) return { ok: false, message: "Google's reading is not switched on in the cloud yet. Paste the statement text instead." };
    return r.text ? { ok: true, text: r.text } : { ok: false, message: 'Google could not read any text. Try the CSV / Excel file, or paste the text.' };
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. Reading a PDF or screenshot needs internet – or paste the text.' : m };
  }
}

export async function readInvoiceNow(invoiceUid) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'This device is not linked to the Easy Buys cloud yet (Admin › Online & email, or Link to Easy Buys). Photos are read by Google when online.' };
  try {
    return await readInvoice(invoiceUid);
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. It will be read by itself when the device is back online.' : m };
  }
}

async function handle(item) {
  const s = getSettings();
  const p = item.payload;
  if (item.kind === 'report') {
    const rep = shiftReport(p.shiftId);
    if (!rep) return;
    const pdf = await reportPdf(rep);
    const xlsx = await reportXlsx(rep);
    const sh = getShift(p.shiftId);
    await post({
      kind: 'report', emails: recipientsFor('shift_report', p), subject: `${s.bakeryName} – Shift report ${sh.shift_date} ${sh.shift_name} (${sh.code})`,
      html: pdf.html, fileName: rep.fileName, pdf: pdf.base64, xlsx: xlsx.base64, month: sh.shift_date.slice(0, 7), shiftCode: sh.code,
      summary: rep.summary,
    }, 180000);
    withSystem(() => markReportSent(p.shiftId));
  } else if (item.kind === 'po') {
    const doc = purchaseOrderDoc(p.poId);
    if (!doc) return;
    const pdf = await reportPdf(doc);
    await post({
      kind: 'po', emails: recipientsFor('bakery_po', p), subject: `${s.bakeryName} – Purchase order ${doc.po.po_no} (${doc.po.supplier || 'supplier'})`,
      html: pdf.html, fileName: doc.fileName, pdf: pdf.base64, month: doc.po.created_at.slice(0, 7), supplierEmail: doc.po.supplier_email || '',
    }, 120000);
    withSystem(() => markPoSent(p.poId));
  } else if (item.kind === 'acct_pack') {
    const to = recipientsFor('accountant_pack', p);
    if (!to.length) return;
    const rep = accountantPack(p.from, p.to);
    const xlsx = await reportXlsx(rep);
    await post({ kind: 'pack_email', subject: `Easy Buys – accountant pack ${p.from} to ${p.to}`, text: `Hello,\n\nThe Easy Buys accountant pack for ${p.from} to ${p.to} is attached (Excel).\n\nEasy Buys Shopping Centre`,
      attachments: [{ b64: xlsx.base64, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name: `${rep.fileName}.xlsx` }] }, 180000);
  } else if (item.kind === 'photo') {
    const ph = getPhoto(p.photoId);
    if (!ph || !(await fileExists(ph.uri))) return;
    const data = await fileBase64(ph.uri);
    const r = await post({ kind: 'photo', refType: ph.ref_type, refId: ph.ref_id, data, fileName: `${ph.ref_type}-${ph.ref_id}-${ph.id}.jpg`, month: ph.created_at.slice(0, 7) }, 180000);
    if (r.url) {
      withSystem(() => setPhotoCloudUrl(ph.id, r.url));
      // Easy Buys modules: put the Drive link on the record so every device can open the photo.
      const link = { punch: 'punches', leave: 'leave_requests' }[ph.ref_type];
      if (link) db().run(`UPDATE ${link} SET photo_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.url, stamp(), deviceId(), ph.ref_id]);
      // Records with several photos (invoice pages, receipts, Z reports) keep a list of links.
      const many = { invoice: 'ap_invoices', payment: 'ap_payments', till: 'till_counts', deposit: 'deposits', cash: 'cash_moves', snap: 'money_snaps', receipt: 'inv_receipts', stat: 'stat_payments', asset: 'fixed_assets', statement: 'supplier_statements', applicant: 'applicants', charge: 'staff_charges', credit_settle: 'credit_settlements', regreceipt: 'regular_receipts', owner: 'owner_moves' }[ph.ref_type];
      if (many) addPhotoUrl(many, ph.ref_id, r.url);
    }
  } else if (item.kind === 'doc_upload') {
    // A document goes to Google Drive › Easy Buys › Documents › <type folder> [› year › month] (v3.5: checked, safe to retry).
    await uploadDocument(p.uid);
  } else if (item.kind === 'email' || item.kind === 'contract_email') {
    let attachments = [];
    if (item.kind === 'contract_email') {
      // The company's own PDF (signed and stamped) when the contract was made from it; otherwise the app's contract.
      const signed = p.docUid ? getDocument(p.docUid) : null;
      const b64 = signed ? await documentBase64(signed) : (await reportPdf(contractReport(p.contractUid))).base64;
      attachments = [{ name: `${p.subject.replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64, mime: 'application/pdf' }];
    }
    const r = await post({ kind: 'email', to: p.to, subject: p.subject, text: p.text, attachments }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'payslip_email') {
    // v3.5 pay sign-off: the signed payslip as a PDF to the person's own email address (Code.gs checks the address).
    const { payslipReport } = require('../modules/payroll/payslip.js');
    const pdf = await reportPdf(payslipReport(p.lineUid));
    const r = await post({ kind: 'payslip_email', to: p.to, subject: p.subject, text: p.text, attachments: [{ name: `${String(p.subject).replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64: pdf.base64, mime: 'application/pdf' }] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'support_email') {
    // Problem report to the app's support person. The cloud script decides the address (a device cannot choose it).
    const r = await post({ kind: 'support_email', subject: p.subject, text: p.text }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'calendar') {
    const r = await post({ kind: 'calendar', ...p }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'myday_in') {
    // v3.5 My day: meetings for one day from the Easy Buys Google account's calendar.
    const r = await post({ kind: 'myday_events', date: p.date }, 60000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
    require('../modules/myday/service.js').applyGoogleEvents(p.ownerUid, p.date, r.events || []);
  } else if (item.kind === 'myday_out') {
    // v3.5 My day: the day's app tasks → the "Easy Buys – My day" calendar.
    const r = await post({ kind: 'myday_out', date: p.date, calendar: p.calendar, items: p.items || [] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'viber') {
    // v3.9.4 the photo (invoice, cheque stub) or the PO's PDF goes with the post (cloud script 7 or newer).
    const files = [];
    if (p.attach && Number(getSetting('cloud_script_version', '0')) >= 7) {
      try {
        for (const uri of (p.attach.photos || []).slice(0, 3)) {
          if (await fileExists(uri)) files.push({ name: `photo-${files.length + 1}.jpg`, mime: 'image/jpeg', data: await fileBase64(uri) });
        }
        if (p.attach.poUid) {
          const R = require('../modules/inventory/reports.js');
          const rep = R.poReport(p.attach.poUid);
          const pdf = await reportPdf(rep);
          files.push({ name: `${rep.fileName || 'Purchase-order'}.pdf`, mime: 'application/pdf', data: pdf.base64 });
        }
      } catch (e) { /* the text still goes; the file is left out */ }
    }
    const r = await post(files.length ? { kind: 'viber', text: p.text, files } : { kind: 'viber', text: p.text }, files.length ? 180000 : 45000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'ocr') {
    await readInvoice(p.invoiceUid);
  } else if (item.kind === 'archive') {
    // v3.9 year-end archive: the whole business as it was, kept in Drive › Backups › Manual (never pruned).
    const r = await post({ kind: 'backup', tier: 'manual', date: p.date, fileName: p.fileName, data: JSON.stringify({ _archive: p.meta, ...dumpDatabase() }), manifest: JSON.stringify({ archive: p.meta, files: backupManifest() }) }, 300000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
    withSystem(() => require('../services/yearArchive.js').archiveSent(p.year, r || {}));
  } else if (item.kind === 'backup') {
    // v3.5: kept as a daily backup (30 days) and the first of each month as a monthly one (12 months), with a file
    // manifest. Older cloud scripts ignore the extra fields and keep it in Backups as before.
    await post({ kind: 'backup', tier: p.tier || 'daily', date: p.date, fileName: `backup-${p.date}.json`, data: JSON.stringify(dumpDatabase()), manifest: JSON.stringify(backupManifest()) }, 300000);
    setSetting('last_backup_at', stamp());
  }
}

// One sync round: send the live status, then work through the outbox.
// Shared records (staff, punches, timesheets, leave...): send ours, then fetch other devices' changes.
async function pushRecords(rounds = 20) {
  let sent = 0;
  for (let round = 0; round < rounds; round++) {
    const batch = pendingRecords(200);
    if (!batch.length) break;
    const r = await post({ kind: 'push', records: batch }, 90000);
    withSystem(() => markRecordsSent(batch));
    sent += batch.length;
    if (r.rejected && r.rejected.length) setSetting('last_rejected', JSON.stringify(r.rejected.slice(0, 20)));
  }
  return sent;
}
async function syncRecords() {
  let sent = await pushRecords();
  let received = 0;
  for (let round = 0; round < 20; round++) {
    let stat = null;
    try { stat = deviceStat(Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox()); } catch (e) { stat = null; }
    const r = await post({ kind: 'pull', since: pullCursor(), stat }, 90000);
    try { withSystem(() => applyControl(r.control)); } catch (e) { /* next round */ }
    if (r.commands && r.commands.length) { try { await runCommands(r.commands, { send: (b) => post(b, 60000) }); } catch (e) { /* next round */ } }
    const list = r.records || [];
    if (list.length) received += withSystem(() => applyPulledRecords(list));
    if (typeof r.next === 'number') withSystem(() => setPullCursor(r.next));
    if (!r.more) break;
  }
  try { withSystem(() => retireSampleLogins()); } catch (e) { /* try again next round */ }
  // Go-live: the owner started fresh on the main tablet – clear the same old records here too (safety copy first).
  try { await applyFresh(freshMarker(), { snapshot: () => snapshotNow('fresh') }); } catch (e) { /* next round */ }
  try { withSystem(() => postBakeryReceipts()); } catch (e) { /* next round */ }
  try { withSystem(() => sendAnswered()); } catch (e) { /* next round */ }
  // Automatic Viber Channel alerts (main tablet only, each once).
  try { withSystem(() => autoViberAlerts({ isMain: !!getSetting('cloud_key', '') })); } catch (e) { /* next round */ }
  // The monthly accountant pack (main tablet only).
  try {
    const due = packDue({ today: dateStr(), isMain: !!getSetting('cloud_key', '') });
    if (due) withSystem(() => { if (due.mode === 'auto') enqueue('acct_pack', { from: due.from, to: due.to }); else noteMade('accountant_pack', { from: due.from, to: due.to }, `Accountant pack ${due.month}`); setSetting('acct_pack_month', due.month); });
  } catch (e) { /* next round */ }
  // The device list (for the device warnings), every 30 minutes.
  try {
    const c = cachedDevices();
    if (!c || Date.now() - new Date(String(c.at).replace(' ', 'T')).getTime() > 30 * 60000) { const d = await post({ kind: 'devices' }, 30000); withSystem(() => cacheDevices(d.devices || [])); }
  } catch (e) { /* next round */ }
  return { sent, received };
}

export async function syncNow({ force = false } = {}) {
  const s = getSettings();
  if (!s.cloudUrl || running || isTraining()) return { skipped: true };
  running = true;
  let waiting0 = 0;
  try { waiting0 = Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox(); } catch (e) { waiting0 = 0; }
  setSyncState({ running: true, lastTry: stamp(), progress: waiting0 ? `Sending ${waiting0} item${waiting0 === 1 ? '' : 's'}…` : 'Checking for changes…' });
  let sent = 0;
  let received = 0;
  let error = null;
  let planChanged = 0;
  let linkFresh = false;
  try {
    const rec = await syncRecords();
    setSyncState({ progress: 'Fetching changes from the other devices…' });
    sent += rec.sent;
    received = rec.received;
    // v3.9.4 the Aronium link: the main tablet turns what the till PCs sent into sales, End of days and products.
    try {
      const L = require('../modules/aronium/link.js');
      let last = null;
      try { last = JSON.parse(getSetting('aronium_link_last', '') || 'null'); } catch (e) { last = null; }
      const stale = !last || !last.at || minutesBetween(last.at, stamp()) >= 10;
      if (L.isLinkDevice() && (received > 0 || (last && last.left > 0) || stale)) {
        setSyncState({ progress: 'Bringing in the tills\' figures…' });
        const pr = L.processLink();
        if (pr && pr.did && pr.did.length) linkFresh = true;
      }
    } catch (e) { /* never stops the sync; the next round tries again */ }
    const today = dateStr();
    // Nightly full backup: from the main tablet only (when one is chosen), otherwise once a day as before.
    if (getSetting('last_backup_date') !== today && backupDue({ last: getSetting('last_backup_date', '') })) {
      withSystem(() => enqueue('backup', { date: today, tier: 'daily' }));
      setSetting('last_backup_date', today);
    }
    // v3.9.4 one device sends the online dashboard (see services/board.js), every 2–5 minutes.
    let sendDash = true;
    try {
      const B = require('../services/board.js');
      let isMain = false;
      try { isMain = require('../modules/aronium/link.js').isLinkDevice(); } catch (e) { isMain = false; }
      // v3.9.4 new figures (a sale from a till PC, a change on another device): the dashboard goes out straight away
      // (at most every 30 seconds) instead of waiting for its 2–5 minute turn.
      const fresh = linkFresh || received > 0;
      if (fresh) B.boardStale();
      sendDash = withSystem(() => B.shouldSendDashboard({ isMain, fresh }));
    } catch (e) { sendDash = true; }
    if (sendDash) {
      setSyncState({ progress: 'Updating the online dashboard…' });
      const r = await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000);
      if (r && r.version) setSetting('cloud_script_version', String(r.version));
      // Plan changes made on the online dashboard come back with the reply.
      if (r.planEdits && r.planEdits.length) {
        planChanged = applyOnlinePlans(r.planEdits);
        await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000); // confirm to the dashboard straight away
      }
    }
    // v3.9.4 records made during this sync (the dashboard's first build, the till figures, the alerts) go now, not
    // next round, so "All synced" really means nothing is waiting.
    sent += await pushRecords(5);
    const jobs = pendingOutbox(force ? 50 : 10);
    for (const [k, item] of jobs.entries()) {
      setSyncState({ progress: `Sending files and emails (${k + 1} of ${jobs.length})…` });
      try {
        await handle(item);
        withSystem(() => markOutboxSent(item.id));
        sent += 1;
      } catch (e) {
        withSystem(() => markOutboxFailed(item.id, e.message || e));
        error = e.message || String(e);
        // No internet: stop and try again next round. Anything else (e.g. a bad email address): skip it so it does not hold up the rest.
        if (/network|fetch|abort|timed|offline|Failed to/i.test(error)) break;
      }
    }
    setSetting('last_sync_at', stamp());
    try { await clearOldLocalCopies(); } catch (e) { /* next time */ }
    // v3.9.6 Deleted bin: records more than 90 days in it are gone for good (checked each sync; cheap when none).
    try { withSystem(() => require('../services/bin.js').purgeBin()); } catch (e) { /* next time */ }
  } catch (e) {
    error = e.message || String(e);
  } finally {
    running = false;
    setSetting('last_sync_error', error || '');
    if (!error) setSetting('last_sync_ok_at', stamp());
    setSyncState({ running: false, error: error || '', lastOk: getSetting('last_sync_ok_at', ''), sent, received, progress: '' });
  }
  return { sent, received, error, planChanged };
}

export function syncStatus() {
  return {
    configured: !!getSettings().cloudUrl,
    lastOk: getSetting('last_sync_ok_at', ''),
    lastTry: getSetting('last_sync_at', ''),
    error: getSetting('last_sync_error', ''),
  };
}

// ---------------------------------------------------------------- documents kept in Google Drive
// Upload one document: unique upload id (a repeated upload returns the file already in Drive), size + SHA-256 sent
// and checked against what the cloud script got. Status on the document: uploading → verified / failed / login.
export async function uploadDocument(uid) {
  const d0 = getDocument(uid);
  if (!d0 || d0.status !== 'active') return 'skipped';
  if (d0.upload_status === 'verified' && d0.cloud_id) return 'verified';
  if (!d0.path || !(await fileExists(d0.path))) {
    if (!d0.cloud_id) withSystem(() => markUploadFailed(uid, 'The file is not on this device.'));
    return 'missing';
  }
  const d = describeDocument(d0);
  const data = await fileBase64(d0.path);
  const fp = base64Fingerprint(data);
  withSystem(() => markUploading(uid));
  let r;
  try {
    r = await post({ kind: 'file_put', uploadId: uploadIdFor(d0), folder: d0.ref_type, path: d.folder, docType: d.doc_type, access: d.access_class, refUid: d0.ref_uid || '',
      fileName: `${d0.uid}-${String(d0.name).replace(/[^A-Za-z0-9 ._-]+/g, '-').slice(0, 60)}.${extFor(d0.mime, d0.name)}`, mime: d0.mime || 'application/octet-stream', data, size: fp.size, sha256: fp.sha256 }, 300000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } catch (e) {
    withSystem(() => markUploadFailed(uid, e.message || String(e)));
    throw e;
  }
  return withSystem(() => markUploaded(uid, fp, r));
}

// The file of a document as base64: from this device, or fetched from the cloud copy (then kept here too).
// The cloud checks the logged-in person's role against the document visibility setting before sending it.
export async function documentBase64(d, user = appUser()) {
  if (d.path && (await fileExists(d.path))) return fileBase64(d.path);
  if (!d.cloud_id) throw new Error('This document is on another device and has not reached the cloud yet. Open it there, or sync that device first.');
  if (isTraining()) throw new Error('Not available in training mode.');
  const r = await post({ kind: 'file_get', id: d.cloud_id, user: user ? { uid: user.uid, role: user.role } : undefined }, 300000);
  if (!r || !r.data) throw new Error((r && r.error) || 'Could not fetch the document from the cloud.');
  if (d.sha256) {
    const fp = base64Fingerprint(r.data);
    if (fp.sha256 !== String(d.sha256).toLowerCase()) throw new Error('The copy fetched from Google Drive does not match the original (fingerprint differs). It was not opened.');
  }
  const dir = `${FS.documentDirectory}docs/`;
  try { await FS.makeDirectoryAsync(dir, { intermediates: true }); } catch (e) { /* already there */ }
  const path = `${dir}${d.uid}.${extFor(d.mime, d.name)}`;
  await FS.writeAsStringAsync(path, r.data, { encoding: FS.EncodingType.Base64 });
  withSystem(() => markFetched(d.uid, path));
  return r.data;
}

// Tablet copies of documents verified in Drive and older than the admin's retention (default 90 days) are removed
// from this device; they are fetched again when opened.
export async function clearOldLocalCopies() {
  let n = 0;
  for (const d of localCopiesToClear()) {
    try { await FS.deleteAsync(d.path, { idempotent: true }); } catch (e) { continue; }
    withSystem(() => markLocalCleared(d.uid));
    n += 1;
  }
  return n;
}

// New or replaced tablet, after the data was restored: fetch back the recent document files (each checked).
export async function fetchNeededFiles(onProgress = () => {}) {
  const list = filesToFetch();
  let ok = 0;
  const failed = [];
  for (const [i, d] of list.entries()) {
    onProgress(i + 1, list.length, d.name);
    try { await documentBase64({ ...getDocument(d.uid), path: null }); ok += 1; } catch (e) { failed.push({ name: d.name, error: e.message || String(e) }); }
  }
  return { total: list.length, ok, failed };
}
