// Sends data to the bakery's Google account (via the Apps Script "bakery cloud").
// Works offline-first: everything waits in the outbox until the tablet is online.
import { db, withSystem } from '../db/connection.js';
import { getSettings, setSetting, getSetting, stamp, APP_VERSION, dateStr, deviceId, deviceName, minutesBetween, audit, AppError, stripSecretsText } from '../services/core.js';
import { actsAsOwner } from '../services/access.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor, SYNC_TABLES, pendingBySection } from '../services/records.js';
import { snapshotNow } from '../services/snapshots.js';
import { applyFresh, freshMarker } from '../services/startFresh.js';
import { postBakeryReceipts } from '../modules/bakery/store.js';
import { recipientsFor, sendAnswered, packDue, noteMade } from '../services/emailPrefs.js';
import { accountantPack } from '../modules/accounting/statements.js';
import { autoViberAlerts } from '../services/viberAuto.js';
import { deviceStat, applyControl, runCommands, setDeviceLock, wipeThisDevice, deviceLock } from '../modules/devices/control.js';
import { cachedDevices, cacheDevices } from '../modules/devices/service.js';
import { setSyncState } from '../services/syncBus.js';
import { crumb } from '../services/breadcrumbs.js';
import { pendingOutbox, markOutboxSent, markOutboxFailed, getPhoto, setPhotoCloudUrl, markPoSent, enqueue, countPendingOutbox } from '../services/stock.js';
import { shiftReport, purchaseOrderDoc } from '../services/reports.js';
import { markReportSent, getShift } from '../services/shifts.js';
import { buildSnapshot } from '../services/dashboard.js';
import { applyOnlinePlans, planSeq } from '../services/plan.js';
import { reportPdf, reportXlsx, fileBase64, fileExists } from './files.js';
import { retireSampleLogins } from '../modules/devices/service.js';
import { contractReport } from '../modules/people/service.js';
import { isTraining } from '../services/trainingFlag.js';
import { getDocument, setCloudCopy, setLocalPath, extFor } from '../services/documents.js';
import * as FS from 'expo-file-system/legacy';
import { describeDocument, uploadIdFor, markUploading, markUploaded, markUploadFailed, markFetched, localCopiesToClear, markLocalCleared, filesToFetch, backupDue, backupManifest } from '../services/driveDocs.js';
import { base64Fingerprint } from '../services/sha256.js';
import { appUser } from '../services/errorLog.js';
import { photoPlaceFromDb, payslipPlace, poPlace, docPlace } from '../services/photoNames.js';
// 1.0.0 (owner, 2 Nov): where the cloud (script 16) keeps a record's photo or a document: Records › month › [shop ›] kind.
// Older scripts ignore these and keep the old place.
export function recordsPlace(place) {
  return place ? { niceName: place.fileName, monthFolder: place.monthFolder, shopFolder: place.shopFolder, typeFolder: place.typeFolder } : {};
}
import { signBody, sentAtNow } from '../services/deviceSign.js';
import { requirePerm, asService, requireTop } from '../services/guard.js';

let running = false;
// Business-wide money alerts: the owner / admin channel only (never a shop's channel, where the staff are).
// The phone's clock is checked against the cloud's only when the answer came back quickly. A reply that arrives while
// the app is paused in the background is read minutes later and used to look like a fast clock (owner, 2 Nov:
// "This phone's clock is 35 minutes fast" on a phone set to automatic time – money entries were stopped).
export const SKEW_TRUST_MS = 20000;
export function skewTrust(sentAt, now = Date.now()) { return Number.isFinite(sentAt) && now - sentAt >= 0 && now - sentAt <= SKEW_TRUST_MS; }

export const OWNER_EVENTS = ['statutory_due', 'watchdog_urgent', 'morning', 'alerts_urgent', 'locked_change'];

// Any request to the cloud. Linked devices send their own token; the first device may use the cloud key.
// 1.0.0 (owner, 2 Nov): Admin › Backup › "Tidy Drive photos into month folders" – the cloud (script 16) moves the photos
// already in Drive › Photos into Records › month › …, about 5 minutes a go; asked again until it says it is done.
export async function tidyDrivePhotos(onStep, maxRuns = 40) {
  const total = { moved: 0, left: 0, runs: 0 };
  for (let i = 0; i < maxRuns; i++) {
    const r = await cloudCall({ kind: 'tidy_records' }, 360000);
    if (!r || r.ok === false) return { ok: false, message: (r && r.error) || 'The cloud did not answer.', ...total };
    total.moved += Number(r.moved) || 0; total.left = Number(r.left) || 0; total.runs++;
    if (onStep) onStep({ ...total });
    if (!r.more) return { ok: true, more: false, ...total };
  }
  return { ok: true, more: true, ...total };
}
export async function cloudCall(body, timeoutMs = 60000) {
  await ensureSession();
  return post(body, timeoutMs);
}

// 1.0.0 build 1: after a PIN login on this device, the cloud checks the person too (user_login with the proof of the
// PIN, worked out at login and kept in memory only) and gives a session for 12 hours. Without the internet the person
// works on as before; owner / admin changes wait on the device until the session is there.
export async function ensureSession() {
  const P = require('../services/pins.js');
  const pend = P.takePendingLogin();
  let me = null;
  try { me = appUser(); } catch (e) { me = null; }
  // (me: the person on the screen; none when the app runs without screens, e.g. the tests)
  if (!pend || (me && me.uid !== pend.uid) || isTraining() || !getSettings().cloudUrl) return null;
  if (Number(getSetting('cloud_script_version', '0')) < 12) return null;
  try {
    const r = await post({ kind: 'user_login', uid: pend.uid, proof: pend.proof }, 30000);
    P.setCloudSession(pend.uid, r.session, r.until);
    return r.session;
  } catch (e) {
    // a wrong / unknown PIN in the cloud: keep working on this device; owner work waits (the Sync screen says why)
    setSetting('cloud_login_problem', String(e && e.message ? e.message : e).slice(0, 200));
    if (!/not reached the cloud yet/.test(String(e && e.message))) P.setCloudSession(pend.uid, null);
    return null;
  }
}

// v3.9.2 in practice (training) mode only these read-only requests reach the cloud – nothing is changed for real.
// 1.0.0 invoice_ai: the AI reading an invoice only reads (nothing is kept in the cloud).
const TRAINING_OK = ['ping', 'devices', 'ocr', 'invoice_ai', 'fccc_lpg', 'problem_log_get', 'file_get', 'check_update'];
async function post(body, timeoutMs = 90000) {
  if (isTraining() && !TRAINING_OK.includes(body && body.kind)) throw Object.assign(new Error('Not available in practice mode – nothing is sent to the cloud. Switch back to the real app first (Admin › Training).'), { isAppError: true });
  const s = getSettings();
  const token = getSetting('cloud_token', '');
  if (!s.cloudUrl) throw Object.assign(new Error('The cloud web address is not set (Admin → Settings → Online & email).'), { isAppError: true });
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    // 1.0.0 build 1: signed with this device's pass; once the cloud is version 12 a linked device no longer sends the
    // pass itself. The person logged in goes with their cloud session (the cloud checks owner / admin work by it).
    const v12 = Number(getSetting('cloud_script_version', '0')) >= 12;
    const P = require('../services/pins.js');
    let session;
    try { const me = appUser(); session = P.cloudSession(me ? me.uid : undefined) || undefined; } catch (e) { session = undefined; }
    const out = { key: token ? undefined : s.cloudKey, token: token && !v12 ? token : undefined, app: APP_VERSION + (getSetting('fresh_applied', '') ? ` fresh:${String(getSetting('fresh_applied', '')).slice(-6)}` : ''), location: s.locationName, sentAt: sentAtNow(), device: { id: deviceId(), name: deviceName(), kind: getSetting('device_kind', 'tablet') }, session, ...body };
    if (!out.pinSalt && ['ping', 'pull'].includes(body.kind)) { try { out.pinSalt = P.pinSalt() || undefined; } catch (e) { /* none */ } }
    const sig = signBody(token || s.cloudKey, out.device.id, out);
    if (sig) out.sig = sig;
    const sentAt = Date.now(); // 2 Nov: the clock check only trusts a quick answer (see below)
    const res = await fetch(s.cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(out),
      signal: ctrl ? ctrl.signal : undefined,
    });
    const text = await res.text();
    // v3.9.3 the device clock checked against Google's: a wrong clock refuses entries and confuses sync.
    try {
      const hd = res.headers && res.headers.get ? res.headers.get('date') : null;
      const t = hd ? Date.parse(hd) : NaN;
      if (Number.isFinite(t) && !isTraining() && skewTrust(sentAt)) setSetting('clock_skew_min', String(Math.round((Date.now() - t) / 60000)));
    } catch (e) { /* no date header */ }
    let json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw new Error(res.status === 200 ? 'The cloud did not reply correctly. Check the web address and that it is deployed for "Anyone".' : `Cloud error ${res.status}`);
    }
    // 1.0.0 hardening: the cloud's own clock in every reply (script 12+) – more exact than the Date header
    try { const st = Number(json && json.serverTime); if (Number.isFinite(st) && st > 0 && !isTraining() && skewTrust(sentAt)) { setSetting('clock_skew_min', String(Math.round(((sentAt + Date.now()) / 2 - st) / 60000))); setSetting('clock_checked_at', String(Date.now())); } } catch (e) { /* older script */ }
    if (json.waiting) setSetting('link_waiting', '1');
    if (isTraining()) { if (!json.ok) throw new Error(json.error || 'The cloud refused the request.'); return json; } // practice: never locks
    // The owner blocked this device (lost or stolen): lock it until it is unblocked.
    setSetting('device_blocked', json.blocked ? '1' : (json.ok ? '0' : getSetting('device_blocked', '0')));
    if (json.ok && !json.lock) { try { require('../modules/devices/control.js').clearLockOverride(); } catch (e) { /* none */ } }
    // v3.6 Admin › Devices: paused, access ended, removed or wiped (the cloud enforces it; the device shows why).
    if (json.wipe) { try { withSystem(() => wipeThisDevice()); } catch (e) { withSystem(() => setDeviceLock({ kind: 'wiped' })); } }
    else if (json.lock) withSystem(() => setDeviceLock(json.lock));
    else if (json.removed && getSetting('cloud_token', '')) withSystem(() => setDeviceLock({ kind: 'removed' }));
    else if (json.ok) { const l = deviceLock(); if (l && l.kind !== 'wiped' && l.kind !== 'blocked') withSystem(() => setDeviceLock(null)); }
    if (!json.ok) throw new Error(json.error || 'The cloud refused the request.');
    if (getSetting('link_waiting', '') === '1') setSetting('link_waiting', '0');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function testConnection() {
  const r = await post({ kind: 'ping' }, 30000);
  if (r && r.version) setSetting('cloud_script_version', String(r.version));
  return r;
}

// Every table (Easy Buys and Bakery) for the daily backup in Google Drive. PINs, passwords and the cloud key are hidden.
// 1.0.0 speed: tables the app works out again by itself are not backed up (inventory/stockMonths.js).
const DUMP_SKIP = ['outbox', 'inv_stock_months'];
function dumpTables() {
  return db().all(`SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT IN (${DUMP_SKIP.map((t) => `'${t}'`).join(', ')}) ORDER BY name`).map((r) => r.name);
}
function dumpRow(t, r) {
  if (t === 'users') return { ...r, pin: r.pin ? '****' : r.pin, ...('pin_hash' in r ? { pin_hash: r.pin_hash ? '****' : null } : {}), ...('pin_proof' in r ? { pin_proof: null } : {}), password_hash: r.password_hash ? '****' : null };
  if (t === 'settings' && /key|token|secret|salt|session/i.test(String(r.key))) return { ...r, value: '****' };
  // older history entries and Deleted-bin copies may still hold a PIN: hidden the same way
  if (t === 'audit_log') return { ...r, before: stripSecretsText(r.before), after: stripSecretsText(r.after) };
  if (t === 'bin_parts') return { ...r, data: stripSecretsText(r.data) };
  return r;
}
// The rows of a table a slice at a time, in the same order as SELECT * gives them (rowid order).
// size: a number, or a function giving the size of the next slice (the backup makes slices smaller when one holds the
// screen up too long). after: start after this rowid (a backup going on where it stopped). Each slice is an array of
// rows with .last = the rowid of its last row ('all' for a table with no rowid, which comes in one slice).
function* tableSlices(t, size, after = null) {
  const sz = typeof size === 'function' ? size : () => size;
  let hasRowid = true;
  try { db().get(`SELECT rowid AS _r FROM ${t} LIMIT 1`); } catch (e) { hasRowid = false; }
  if (!hasRowid) { if (after === 'all') return; const all = db().all(`SELECT * FROM ${t}`); all.last = 'all'; yield all; return; }
  let last = after;
  for (;;) {
    const n = Math.max(1, Math.floor(sz()));
    const rows = last === null ? db().all(`SELECT rowid AS _eb_rowid, * FROM ${t} ORDER BY rowid LIMIT ?`, [n]) : db().all(`SELECT rowid AS _eb_rowid, * FROM ${t} WHERE rowid > ? ORDER BY rowid LIMIT ?`, [last, n]);
    if (!rows.length) return;
    last = rows[rows.length - 1]._eb_rowid;
    const out = rows.map((r) => { const { _eb_rowid, ...x } = r; return x; });
    out.last = last;
    yield out;
    if (rows.length < n) return;
  }
}
// 1.0.0 speed: slices sized by time, not by a fixed count – a slice that took long (wide rows: the change history,
// photos' notes …) makes the next one smaller, a quick one makes it bigger, so one slice never holds the screen up
// for more than about 50 ms on this device and small rows go quickly. The rows and their order are the same.
function sliceSizer(start = 400, { aimMs = 25, min = 20, max = 4000 } = {}) {
  let size = start;
  return {
    size: () => size,
    // a new table starts small again (its rows may be much wider than the last table's)
    reset() { size = Math.min(size, 50); },
    took(ms) { if (ms > aimMs * 2 && size > min) size = Math.max(min, Math.floor(size / 2)); else if (ms < aimMs / 2 && size < max) size = Math.min(max, size * 2); },
  };
}
export function dumpDatabase() {
  const tables = dumpTables();
  const out = { _meta: { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: tables.length } };
  for (const t of tables) {
    out[t] = db().all(`SELECT * FROM ${t}`).map((r) => dumpRow(t, r));
  }
  return out;
}
// 1.0.0 every table a slice of rows at a time, each row as the backup writes it (JSON text), with a pause between
// slices so the screens keep answering while a big backup is made. fn(table, jsonRows, { first, last }) per slice
// (a table with no rows gives one call with no rows). Returns { tables, rows }.
export async function forEachDumpSlice(fn, { slice = 400, onProgress = null, pause = () => new Promise((r) => setTimeout(r, 0)) } = {}) {
  const tables = dumpTables();
  const sizer = sliceSizer(slice);
  let n = 0;
  for (let i = 0; i < tables.length; i += 1) {
    const t = tables[i];
    let firstSlice = true;
    sizer.reset();
    const it = tableSlices(t, sizer.size);
    let t0 = Date.now();
    let cur = it.next();
    if (cur.done) fn(t, [], { first: true, last: true });
    while (!cur.done) {
      const part = cur.value.map((r) => JSON.stringify(dumpRow(t, r)));
      n += part.length;
      sizer.took(Date.now() - t0);
      // the next slice is read after the pause (so a slice is one hold-up, not two)
      await pause();
      t0 = Date.now();
      cur = it.next();
      fn(t, part, { first: firstSlice, last: cur.done });
      firstSlice = false;
      if (onProgress) { try { onProgress({ table: t, rows: n, tables: tables.length, done: i }); } catch (e) { /* only a note */ } }
    }
  }
  return { tables: tables.length, rows: n };
}
// The backup file's text: exactly JSON.stringify(dumpDatabase()) (with `head` fields first, e.g. the year archive),
// made with forEachDumpSlice. NOTE: one text for the whole business only works while the data is not too big (a
// phone, like Node, cannot hold one text of more than about 500 MB; 3 years of data is near that) – see the report
// of the speed work: the backup has to go up in parts (cloud side).
export async function dumpDatabaseText({ head = null, slice = 400, onProgress = null, pause } = {}) {
  const meta = { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: dumpTables().length };
  const parts = ['{'];
  let first = true;
  const key = (k, v) => { parts.push(`${first ? '' : ','}${JSON.stringify(k)}:${v}`); first = false; };
  if (head) for (const [k, v] of Object.entries(head)) { if (v !== undefined && typeof v !== 'function') key(k, JSON.stringify(v)); }
  key('_meta', JSON.stringify(meta));
  let rows = [];
  await forEachDumpSlice((t, part, { first: f, last }) => {
    if (f) rows = [];
    for (const x of part) rows.push(x);
    if (last) key(t, `[${rows.join(',')}]`);
  }, { slice, onProgress, ...(pause ? { pause } : {}) });
  parts.push('}');
  return parts.join('');
}
// 1.0.0 speed: the backup goes up to Drive in parts of a few MB (cloud script: backup_part, then backup_done), a slice
// of rows at a time with a pause between slices, so the screens never freeze and a phone never has to hold the whole
// business as one text. Where it got to is kept (setting backup_upload) after every part: a backup cut off (app closed,
// no internet) goes on from the next part on the next try instead of starting again. Each part is
// {"_part":n,"tables":{"<table>":[rows…],…}}; a table can go on into the next part. The file kept in Drive under
// fileName is the index ({ _meta, _parts, … }); fetchDriveBackup() puts the parts back together for a restore.
// An older cloud script (no backup_part) gets the whole backup in one go as before.
export const BACKUP_PART_BYTES = 3 * 1024 * 1024;
const UPLOAD_KEY = 'backup_upload';
export function backupUploadState() { try { return JSON.parse(getSetting(UPLOAD_KEY, '') || 'null'); } catch (e) { return null; } }
export async function uploadBackupInParts({ tier = 'daily', date = dateStr(), fileName, head = null, manifest = null, send = (b) => post(b, 300000), partBytes = BACKUP_PART_BYTES, onProgress = null,
  pause = () => new Promise((r) => setTimeout(r, 0)), whole = null } = {}) {
  const name = fileName || `backup-${date}.json`;
  let st = backupUploadState();
  if (!st || st.fileName !== name || st.tier !== tier) {
    st = { fileName: name, tier, date, id: `BK-${deviceId()}-${Date.now().toString(36)}`, made: stamp(), n: 0, t: 0, r: null, rows: 0 };
    setSetting(UPLOAD_KEY, JSON.stringify(st));
  }
  const tables = dumpTables();
  const sizer = sliceSizer(400);
  let pieces = []; let bytes = 0; let open = null; // the part being made: `"table":[rows` pieces
  const sendPart = async (ti, r) => {
    if (open !== null) { pieces.push(']'); open = null; }
    const data = `{"_part":${st.n},"tables":{${pieces.join('')}}}`;
    try {
      await send({ kind: 'backup_part', upload: st.id, fileName: st.fileName, tier: st.tier, date: st.date, n: st.n, data });
    } catch (e) {
      if (st.n === 0 && /Unknown request/i.test(String((e && e.message) || e))) throw Object.assign(new Error('old cloud script'), { oldScript: true });
      throw e;
    }
    st = { ...st, n: st.n + 1, t: ti, r };
    setSetting(UPLOAD_KEY, JSON.stringify(st));
    pieces = []; bytes = 0;
  };
  try {
    for (let ti = st.t; ti < tables.length; ti += 1) {
      const t = tables[ti];
      const after = ti === st.t ? st.r : null;
      const startTable = () => { pieces.push(`${pieces.length ? ',' : ''}${JSON.stringify(t)}:[`); open = t; };
      if (after === null) startTable(); // an empty table still shows in the backup (as in one file)
      sizer.reset();
      const it = tableSlices(t, sizer.size, after);
      let t0 = Date.now();
      for (let cur = it.next(); !cur.done; cur = it.next()) {
        const rows = cur.value;
        if (open === null) startTable();
        let firstRow = pieces[pieces.length - 1].endsWith('[');
        for (const r of rows) { const x = JSON.stringify(dumpRow(t, r)); pieces.push(firstRow ? x : `,${x}`); bytes += x.length + 1; firstRow = false; }
        st.rows = (st.rows || 0) + rows.length;
        sizer.took(Date.now() - t0);
        if (bytes >= partBytes) await sendPart(ti, rows.last);
        if (onProgress) { try { onProgress({ table: t, rows: st.rows, tables: tables.length, done: ti, parts: st.n }); } catch (e) { /* only a note */ } }
        await pause();
        t0 = Date.now();
      }
      if (open !== null) { pieces.push(']'); open = null; }
    }
    if (pieces.length || st.n === 0) await sendPart(tables.length, null);
    const meta = { app: 'Easy Buys', made: st.made, device: deviceId(), tables: tables.length, parts: st.n, rows: st.rows };
    const r = await send({ kind: 'backup_done', upload: st.id, fileName: st.fileName, tier: st.tier, date: st.date, parts: st.n, meta, head: head || undefined, manifest: manifest || undefined });
    setSetting(UPLOAD_KEY, '');
    return { ...(r || {}), parts: st.n, rows: st.rows };
  } catch (e) {
    if (!e || !e.oldScript) throw e;
    // an older cloud script: the whole backup in one go (as before 1.0.0)
    setSetting(UPLOAD_KEY, '');
    const one = whole || (async () => send({ kind: 'backup', tier: tier === 'plain' ? undefined : tier, date, fileName: name, data: await dumpDatabaseText({ head, pause }), manifest: manifest || undefined }));
    const r = await one();
    return { ...(r || {}), parts: 0, whole: true };
  }
}
// A backup kept in Drive, as one object (the parts of a backup made in parts put back together).
export async function fetchDriveBackup(id, { call = (b) => cloudCall(b, 300000) } = {}) {
  const r = await call({ kind: 'backup_get', id });
  const data = JSON.parse((r && r.text) || '{}');
  if (!data || !Array.isArray(data._parts)) return data;
  const { _parts, _upload, ...out } = data;
  for (let n = 0; n < _parts.length; n += 1) {
    const p = await call({ kind: 'backup_get_part', id, n });
    const part = JSON.parse((p && p.text) || '{}');
    if (!part || part._part !== n || !part.tables) throw Object.assign(new Error(`Part ${n + 1} of this backup is missing or damaged in Google Drive.`), { isAppError: true });
    for (const [t, rows] of Object.entries(part.tables)) out[t] = out[t] ? out[t].concat(rows) : rows;
  }
  return out;
}

// Put back the shared records from a backup file (owner or admin only, from Admin). Records in the backup replace the
// same records here and are sent to the cloud again; nothing else is deleted. Logins and device settings are not
// touched, the change history is never replaced (it only grows), and records in a closed month are left as they are.
// The restore itself is written in the change history.
export const RESTORE_SKIP = ['users', 'settings', 'shared_settings', 'audit_log', 'alert_log', 'po_versions', 'tax_return_versions', 'roster_changes', 'inv_cost_changes', 'bin_records', 'bin_parts'];
export function restoreBackup(user, data, fileName = '') {
  requireTop(user, 'restore a backup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !(actsAsOwner(user) || ['owner', 'admin'].includes(user.role))) throw new AppError('Only the owner or an admin can restore a backup.');
  if (!data || typeof data !== 'object' || Array.isArray(data) || !data._meta) throw new AppError('This is not an Easy Buys backup file.');
  let n = 0;
  let closed = 0;
  const skip = new Set(RESTORE_SKIP);
  let inClosed = () => false;
  try {
    const lock = require('../services/lock.js').lockDate();
    const B = require('../services/bin.js');
    if (lock && B.inClosedMonth) inClosed = (t, row) => B.inClosedMonth(t, row, lock);
  } catch (e) { inClosed = () => false; }
  db().transaction(() => {
    for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
      if (skip.has(t) || !Array.isArray(data[t])) continue;
      const cols = db().all(`PRAGMA table_info(${t})`).map((c) => c.name);
      for (const row of data[t]) {
        if (!row || typeof row !== 'object') continue;
        // 1.0.0 hardening (audit M8): restored rows keep their own time stamps (never "now"), so a restore can never
        // overwrite a newer record – here or on another device (the cloud keeps the newest version).
        // (a row with no time of its own – a hand-made file – is put back as now)
        const r2 = { ...row, ...(cols.includes('updated_at') && !row.updated_at ? { updated_at: stamp() } : {}) };
        const keys = Object.keys(r2).filter((k) => cols.includes(k) && k !== 'sync_status');
        if (!keys.length || r2[cfg.key] === undefined) continue;
        // a closed month: neither the copy in the backup nor the record here may change
        let here = null;
        try { here = db().get(`SELECT * FROM ${t} WHERE ${cfg.key} = ?`, [r2[cfg.key]]); } catch (e) { here = null; }
        if (inClosed(t, r2) || (here && inClosed(t, here))) { closed += 1; continue; }
        if (here && row.updated_at && cols.includes('updated_at') && String(here.updated_at || '') >= String(row.updated_at)) continue; // this device's copy is as new or newer
        db().run(`INSERT OR REPLACE INTO ${t} (${keys.join(', ')}, sync_status) VALUES (${keys.map(() => '?').join(', ')}, 'pending')`, keys.map((k) => r2[k]));
        n += 1;
      }
    }
    const name = String(fileName || (data._meta && data._meta.made ? `backup made ${data._meta.made}` : 'a backup file')).slice(0, 120);
    audit({ user, action: `Backup restored from ${name}`, table: 'backup', recordUid: name, after: { records: n, leftInClosedMonths: closed } });
  });
  return n;
  });
}
export async function backupNow() {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    const d = dateStr();
    // a backup cut off part way goes on where it stopped (same file)
    const was = backupUploadState();
    const fileName = was && was.tier === 'plain' ? was.fileName : `backup-${d}-${stamp().slice(11, 16).replace(':', '')}.json`;
    await uploadBackupInParts({ tier: 'plain', date: was && was.tier === 'plain' ? was.date : d, fileName,
      whole: async () => post({ kind: 'backup', fileName, data: await dumpDatabaseText() }, 300000) });
    setSetting('last_backup_at', stamp());
    return { ok: true, message: 'Backed up to Google Drive (Easy Buys › Backups).' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

function addPhotoUrl(table, uid, url) {
  let row = null;
  try { row = db().get(`SELECT photo_urls FROM ${table} WHERE uid = ?`, [uid]); } catch (e) { return; }
  if (!row) return;
  let list = [];
  try { list = JSON.parse(row.photo_urls || '[]'); } catch (e) { list = []; }
  if (!list.includes(url)) list.push(url);
  db().run(`UPDATE ${table} SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
}

// Ask the cloud to read an invoice's photos and fill in the invoice. Returns { ok, message }.
// 1.0.0 the AI (Google Gemini in the owner's Apps Script) first – photos and PDFs; Google's text reading (OCR) when
// the cloud has no AI key or the AI fails.
async function readInvoice(invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText, listSuppliers, apRules } = require('../modules/payables/service.js');
  const pics = listPhotos('invoice', invoiceUid).slice(0, 6);
  const files = [];
  const pdf = (u) => /\.pdf(\?|#|$)/i.test(String(u || ''));
  for (const ph of pics) if (await fileExists(ph.uri)) files.push({ mimeType: pdf(ph.uri) ? 'application/pdf' : 'image/jpeg', data: await fileBase64(ph.uri) });
  if (!files.length) return { ok: false, message: 'There is no photo of this invoice on this device.' };
  let aiWhy = '';
  try {
    const AI = require('../services/invoiceAi.js');
    const a = await post({ kind: 'invoice_ai', files, hints: AI.aiHints(listSuppliers(), (Number(apRules().vatRate) || 12.5) / 100) }, 170000);
    if (a && a.ok && a.invoice) {
      const ai = AI.cleanAi(a.invoice, { today: dateStr() });
      const inv = applyReadText(invoiceUid, AI.aiToText(ai));
      return { ok: true, invoice: inv, engine: 'ai', message: inv && inv.total ? 'Read by AI – please check the figures.' : 'Read by AI, but the total was not found. Please type it.' };
    }
  } catch (e) {
    const m = e && e.message ? e.message : String(e);
    if (/network|fetch|abort|timed/i.test(m)) throw e; // no internet: tried again later
    aiWhy = /NO_AI_KEY/.test(m) ? '' : ` (the AI could not read it: ${m.replace(/^AI_ERROR:\s*/, '')})`;
  }
  const images = files.filter((f) => f.mimeType !== 'application/pdf');
  if (!images.length) return { ok: false, message: `A PDF is read by the AI in the cloud only${aiWhy || ' – switch the AI on (Script properties › GEMINI_KEY)'}. Please type the details.` };
  const r = await post({ kind: 'ocr', files: images }, 180000);
  if (r.off) {
    db().run("UPDATE ap_invoices SET ocr_status = 'type', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      ['Reading photos is not switched on in the Google cloud yet. Please type the details.', stamp(), deviceId(), invoiceUid]);
    return { ok: false, message: "Google's photo reading is not switched on yet. One-time step: in the Google Apps Script project click Services ➕ › Drive API › Add, then Deploy › Manage deployments › New version." };
  }
  const inv = applyReadText(invoiceUid, r.text || '');
  if (!r.text) return { ok: false, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  return { ok: true, invoice: inv, engine: 'cloud', message: `${inv && inv.total ? 'Read by Google (text only) – please check the figures.' : 'Read by Google, but the total was not found. Please type it.'}${aiWhy}` };
}

// "Read this photo now" button: straight away, not waiting for the next sync.
// Admin: give the cloud the Viber Channel token (kept only in the cloud) and send a test message.
// v3.9.8 web checks after a sync: never awaited by the sync, never two rounds at once, 90 s limit per check.
let webChecksBusy = false;
const limit = (p, ms) => Promise.race([Promise.resolve().then(p), new Promise((res) => setTimeout(res, ms))]);
export function autoProblemReport(now = Date.now()) {
  if (isTrainingNow()) return false;
  const E = require('../services/errorLog.js');
  const since = getSetting('auto_report_since', '') || '';
  // (errors in the same second as the last one reported are told apart by their message)
  let seen = [];
  try { seen = JSON.parse(getSetting('auto_report_seen', '[]') || '[]'); } catch (e) { seen = []; }
  const key = (e) => `${e.at}|${e.message}`;
  const errs = E.listErrors(200).filter((e) => e.device === deviceName() && (e.at > since || (e.at === since && !seen.includes(key(e)))));
  if (!errs.length) return false;
  const last = Number(getSetting('auto_report_ms', '0')) || 0;
  const fatal = errs.some((e) => e.fatal || /closed|crash/i.test(String(e.message || '')));
  if (!fatal && now - last < 12 * 3600000) return false;
  const text = `${errs.length} new problem${errs.length === 1 ? '' : 's'} since ${since || 'the last report'}.\n\n${E.problemReport()}`;
  enqueue('support_email', { subject: `Easy Buys problem report (automatic) – v${APP_VERSION} – ${deviceName()}`, text });
  const newest = errs[0].at;
  const same = E.listErrors(200).filter((e) => e.device === deviceName() && e.at === newest).map(key);
  setSetting('auto_report_since', newest);
  setSetting('auto_report_seen', JSON.stringify(same.slice(0, 50)));
  setSetting('auto_report_ms', String(now));
  return true;
}
const isTrainingNow = () => { try { return require('../services/trainingFlag.js').isTraining(); } catch (e) { return false; } };
export function runWebChecks() {
  if (webChecksBusy) return;
  webChecksBusy = true;
  (async () => {
    try { await limit(() => require('../modules/inventory/fccc.js').checkFccc(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../modules/inventory/lpg.js').checkLpg(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../modules/inventory/lpg.js').checkFuel(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../services/utilityBills.js').checkWaterBills(), 90000); } catch (e) { /* next round */ }
  })().finally(() => { webChecksBusy = false; });
}
export async function setupViberChannel(token, oldToken, shopCode) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    // v3.9.4 the Viber token travels as viberToken: "token" is this device's own pass to the cloud (sending the Viber
    // token there made the cloud say "This device is not linked any more").
    // v3.9.6 ask the cloud which script it runs now (the version was only noted when this device sent the dashboard,
    // so a freshly pasted script could still be taken for the old one).
    if (Number(getSetting('cloud_script_version', '0')) < 8) {
      try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); } catch (e) { /* the check below says what to do */ }
    }
    if (shopCode && Number(getSetting('cloud_script_version', '0')) < 9) {
      try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); } catch (e) { /* below */ }
      if (Number(getSetting('cloud_script_version', '0')) < 9) return { ok: false, message: 'A Viber Channel for each shop needs the new cloud script (version 9). Paste it, then Deploy › Manage deployments › ✏️ › Version: New version › Deploy. Then try again.' };
    }
    if (Number(getSetting('cloud_script_version', '0')) < 8) return { ok: false, message: `The cloud still runs script version ${getSetting('cloud_script_version', '?') || '?'}. Paste the new cloud script (version 8), then Deploy › Manage deployments › ✏️ › Version: New version › Deploy. Then try again.` };
    const r = await post({ kind: 'viber_setup', viberToken: String(token || '').trim(), oldToken: String(oldToken || '').trim(), selfUrl: getSettings().cloudUrl, shopCode: shopCode || undefined }, 45000);
    if (r.ok) {
      // v3.9.8 remember which shops have their own channel (the set-up steps count it; the token itself stays in the cloud).
      try { const S = require('../services/core.js'); const m = { ...(S.getShared('viber_channels', {}) || {}) }; m[shopCode || 'MAIN'] = stamp(); S.setShared('viber_channels', m); } catch (e) { /* only a note */ }
    }
    return r.ok ? { ok: true, message: r.message || 'Viber Channel connected – a test message was sent.' } : { ok: false, message: r.error || 'Viber did not accept the token.' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

// Bank / M-PAiSA statements (v3.5): Google reads the text of a PDF or a screenshot. files: [{ mimeType, data (base64) }].
export async function readTextNow(files) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Reading a PDF or photo needs the Easy Buys cloud (this device is not linked). Copy the text from the PDF and paste it instead.' };
  try {
    const r = await post({ kind: 'ocr', files: (files || []).slice(0, 6) }, 180000);
    if (r.off) return { ok: false, message: "Google's reading is not switched on in the cloud yet. Paste the statement text instead." };
    return r.text ? { ok: true, text: r.text } : { ok: false, message: 'Google could not read any text. Try the CSV / Excel file, or paste the text.' };
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. Reading a PDF or screenshot needs internet – or paste the text.' : m };
  }
}

export async function readInvoiceNow(invoiceUid) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'This device is not linked to the Easy Buys cloud yet (Admin › Online & email, or Link to Easy Buys). Photos are read by Google when online.' };
  try {
    return await readInvoice(invoiceUid);
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. It will be read by itself when the device is back online.' : m };
  }
}

async function handle(item) {
  const s = getSettings();
  const p = item.payload;
  if (item.kind === 'report') {
    const rep = shiftReport(p.shiftId);
    if (!rep) return;
    const pdf = await reportPdf(rep);
    const xlsx = await reportXlsx(rep);
    const sh = getShift(p.shiftId);
    await post({
      kind: 'report', emails: recipientsFor('shift_report', p), subject: `${s.bakeryName} – Shift report ${sh.shift_date} ${sh.shift_name} (${sh.code})`,
      html: pdf.html, fileName: rep.fileName, pdf: pdf.base64, xlsx: xlsx.base64, month: sh.shift_date.slice(0, 7), shiftCode: sh.code,
      summary: rep.summary, ...recordsPlace(docPlace({ date: sh.shift_date, kind: 'Shift report', party: s.bakeryName || 'Bakery', number: sh.code, typeFolder: 'Shift reports' })),
    }, 180000);
    withSystem(() => markReportSent(p.shiftId));
  } else if (item.kind === 'po') {
    const doc = purchaseOrderDoc(p.poId);
    if (!doc) return;
    const pdf = await reportPdf(doc);
    await post({
      kind: 'po', emails: recipientsFor('bakery_po', p), subject: `${s.bakeryName} – Purchase order ${doc.po.po_no} (${doc.po.supplier || 'supplier'})`,
      html: pdf.html, fileName: doc.fileName, pdf: pdf.base64, month: doc.po.created_at.slice(0, 7), supplierEmail: doc.po.supplier_email || '',
      ...recordsPlace(poPlace({ poNo: doc.po.po_no, supplier: doc.po.supplier, date: doc.po.created_at })),
    }, 120000);
    withSystem(() => markPoSent(p.poId));
  } else if (item.kind === 'acct_pack') {
    const to = recipientsFor('accountant_pack', p);
    if (!to.length) return;
    const rep = accountantPack(p.from, p.to);
    const xlsx = await reportXlsx(rep);
    await post({ kind: 'pack_email', subject: `Easy Buys – accountant pack ${p.from} to ${p.to}`, text: `Hello,\n\nThe Easy Buys accountant pack for ${p.from} to ${p.to} is attached (Excel).\n\nEasy Buys Shopping Centre`,
      attachments: [{ b64: xlsx.base64, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name: `${rep.fileName}.xlsx` }] }, 180000);
  } else if (item.kind === 'photo') {
    const ph = getPhoto(p.photoId);
    if (!ph || !(await fileExists(ph.uri))) return;
    const data = await fileBase64(ph.uri);
    const isPdf = /\.pdf(\?|#|$)/i.test(String(ph.uri || '')); // 1.0.0 an invoice PDF keeps its .pdf name; mime is sent for the cloud's 'photo' case to use (it saves JPEG type for now)
    // 1.0.0 (owner, 2 Nov): invoices, cheques / payments, deposits and Z reports get a readable name and go in
    // Records › month › shop (services/photoNames.js); the cloud keeps the old place for everything else (and old scripts).
    let place = null;
    try { place = photoPlaceFromDb((sql, args) => db().get(sql, args), ph, isPdf ? 'pdf' : 'jpg'); } catch (e) { place = null; }
    const r = await post({ kind: 'photo', refType: ph.ref_type, refId: ph.ref_id, data, fileName: `${ph.ref_type}-${ph.ref_id}-${ph.id}.${isPdf ? 'pdf' : 'jpg'}`, mime: isPdf ? 'application/pdf' : undefined, month: ph.created_at.slice(0, 7),
      ...recordsPlace(place) }, 180000);
    if (r.url) {
      withSystem(() => setPhotoCloudUrl(ph.id, r.url));
      // Easy Buys modules: put the Drive link on the record so every device can open the photo.
      const link = { punch: 'punches', leave: 'leave_requests' }[ph.ref_type];
      if (link) db().run(`UPDATE ${link} SET photo_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.url, stamp(), deviceId(), ph.ref_id]);
      // Records with several photos (invoice pages, receipts, Z reports) keep a list of links.
      const many = { invoice: 'ap_invoices', payment: 'ap_payments', till: 'till_counts', deposit: 'deposits', cash: 'cash_moves', snap: 'money_snaps', receipt: 'inv_receipts', stat: 'stat_payments', asset: 'fixed_assets', statement: 'supplier_statements', applicant: 'applicants', charge: 'staff_charges', credit_settle: 'credit_settlements', regreceipt: 'regular_receipts', owner: 'owner_moves' }[ph.ref_type];
      if (many) addPhotoUrl(many, ph.ref_id, r.url);
    }
  } else if (item.kind === 'doc_upload') {
    // A document goes to Google Drive › Easy Buys › Documents › <type folder> [› year › month] (v3.5: checked, safe to retry).
    await uploadDocument(p.uid);
  } else if (item.kind === 'email' || item.kind === 'contract_email') {
    let attachments = [];
    if (item.kind === 'contract_email') {
      // The company's own PDF (signed and stamped) when the contract was made from it; otherwise the app's contract.
      const signed = p.docUid ? getDocument(p.docUid) : null;
      const b64 = signed ? await documentBase64(signed) : (await reportPdf(contractReport(p.contractUid))).base64;
      attachments = [{ name: `${p.subject.replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64, mime: 'application/pdf' }];
    }
    const r = await post({ kind: 'email', to: p.to, subject: p.subject, text: p.text, attachments }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'payslip_drive') {
    // 1.0.0 (owner, 2 Nov): a copy of each released payslip in Drive › Easy Buys › Records › month › Payslips.
    const l = db().get('SELECT l.uid, l.name, r.week_end, r.version FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid WHERE l.uid = ?', [p.lineUid]);
    const place = l ? payslipPlace({ weekEnd: l.week_end, name: l.name, version: l.version }) : null;
    if (!place) return;
    const { payslipReport } = require('../modules/payroll/payslip.js');
    const pdf = await reportPdf(payslipReport(p.lineUid));
    const r = await post({ kind: 'payslip_save', data: pdf.base64, fileName: place.fileName, monthFolder: place.monthFolder, typeFolder: place.typeFolder }, 180000);
    if (r && r.ok === false) throw new Error(r.error || 'The payslip copy was not saved (update the cloud script to 16).');
  } else if (item.kind === 'payslip_email') {
    // v3.5 pay sign-off: the signed payslip as a PDF to the person's own email address (Code.gs checks the address).
    const { payslipReport } = require('../modules/payroll/payslip.js');
    const pdf = await reportPdf(payslipReport(p.lineUid));
    const r = await post({ kind: 'payslip_email', to: p.to, subject: p.subject, text: p.text, attachments: [{ name: `${String(p.subject).replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64: pdf.base64, mime: 'application/pdf' }] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'support_email') {
    // Problem report to the app's support person. The cloud script decides the address (a device cannot choose it).
    const r = await post({ kind: 'support_email', subject: p.subject, text: p.text }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'calendar') {
    const r = await post({ kind: 'calendar', ...p }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'myday_in') {
    // v3.5 My day: meetings for one day from the Easy Buys Google account's calendar.
    const r = await post({ kind: 'myday_events', date: p.date }, 60000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
    require('../modules/myday/service.js').applyGoogleEvents(p.ownerUid, p.date, r.events || []);
  } else if (item.kind === 'myday_out') {
    // v3.5 My day: the day's app tasks → the "Easy Buys – My day" calendar.
    const r = await post({ kind: 'myday_out', date: p.date, calendar: p.calendar, items: p.items || [] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'viber') {
    // v3.9.4 the photo (invoice, cheque stub) or the PO's PDF goes with the post (cloud script 7 or newer).
    const files = [];
    if (p.attach && Number(getSetting('cloud_script_version', '0')) >= 7) {
      try {
        for (const uri of (p.attach.photos || []).slice(0, 3)) {
          if (await fileExists(uri)) files.push({ name: `photo-${files.length + 1}.jpg`, mime: 'image/jpeg', data: await fileBase64(uri) });
        }
        if (p.attach.poUid) {
          const R = require('../modules/inventory/reports.js');
          const rep = R.poReport(p.attach.poUid);
          const pdf = await reportPdf(rep);
          files.push({ name: `${rep.fileName || 'Purchase-order'}.pdf`, mime: 'application/pdf', data: pdf.base64 });
        }
      } catch (e) { /* the text still goes; the file is left out */ }
    }
    // 1.0.0 build 1: business-wide money alerts go only to the owner / admin channel (cloud script 12); a shop's alerts
    // to that shop's channel (the main channel until the shop has its own).
    const owner = !!p.owner || OWNER_EVENTS.includes(p.event);
    const base = { kind: 'viber', text: p.text, shopCode: owner ? undefined : p.shopCode || undefined, owner: owner || undefined };
    const r = await post(files.length ? { ...base, files } : base, files.length ? 180000 : 45000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'ocr') {
    await readInvoice(p.invoiceUid);
  } else if (item.kind === 'archive') {
    // v3.9 year-end archive: the whole business as it was, kept in Drive › Backups › Manual (never pruned).
    const manifest = JSON.stringify({ archive: p.meta, files: backupManifest() });
    const r = await uploadBackupInParts({ tier: 'manual', date: p.date, fileName: p.fileName, head: { _archive: p.meta }, manifest,
      whole: async () => post({ kind: 'backup', tier: 'manual', date: p.date, fileName: p.fileName, data: await dumpDatabaseText({ head: { _archive: p.meta } }), manifest }, 300000) });
    if (r && r.ok === false && r.error) throw new Error(r.error);
    withSystem(() => require('../services/yearArchive.js').archiveSent(p.year, r || {}));
  } else if (item.kind === 'backup') {
    // v3.5: kept as a daily backup (30 days) and the first of each month as a monthly one (12 months), with a file
    // manifest. Older cloud scripts ignore the extra fields and keep it in Backups as before.
    const manifest = JSON.stringify(backupManifest());
    await uploadBackupInParts({ tier: p.tier || 'daily', date: p.date, fileName: `backup-${p.date}.json`, manifest,
      whole: async () => post({ kind: 'backup', tier: p.tier || 'daily', date: p.date, fileName: `backup-${p.date}.json`, data: await dumpDatabaseText(), manifest }, 300000) });
    setSetting('last_backup_at', stamp());
  }
}

// One sync round: send the live status, then work through the outbox.
// Shared records (staff, punches, timesheets, leave...): send ours, then fetch other devices' changes.
async function pushRecords(rounds = 20) {
  let sent = 0;
  for (let round = 0; round < rounds; round++) {
    const batch = pendingRecords(200);
    if (!batch.length) break;
    const r = await post({ kind: 'push', records: batch }, 90000);
    // 1.0.0 build 1: a locked change the cloud refused for want of an owner / admin login stays waiting here (it goes
    // when the owner or admin is logged in); everything else is done.
    const wait = new Set((r.rejected || []).filter((x) => x.code === 'LOGIN').map((x) => `${x.t}|${x.k}`));
    const done = batch.filter((x) => !wait.has(`${x.t}|${x.k}`));
    withSystem(() => markRecordsSent(done));
    sent += done.length;
    if (r.rejected && r.rejected.length) setSetting('last_rejected', JSON.stringify(r.rejected.map((x) => ({ t: x.t, k: x.k, why: x.why, code: x.code })).slice(0, 20)));
    if (wait.size && wait.size === batch.length) break; // nothing more can go now
  }
  return sent;
}
async function syncRecords() {
  // 1.0.0 build 1: the business PIN salt before sending (a PIN just set goes with its proof made with it).
  if (!getSetting('pin_salt_cloud', '')) {
    try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); if (p && p.pinSalt) { withSystem(() => require('../services/pins.js').adoptCloudSalt(p.pinSalt)); setSetting('pin_salt_cloud', '1'); } } catch (e) { /* the pull below tries */ }
  }
  await ensureSession();
  let sent = await pushRecords();
  let received = 0;
  for (let round = 0; round < 20; round++) {
    let stat = null;
    try { stat = deviceStat(Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox()); } catch (e) { stat = null; }
    const r = await post({ kind: 'pull', since: pullCursor(), stat }, 90000);
    if (r.version) setSetting('cloud_script_version', String(r.version));
    if (r.pinSalt) { try { withSystem(() => require('../services/pins.js').adoptCloudSalt(r.pinSalt)); setSetting('pin_salt_cloud', '1'); } catch (e) { /* next round */ } }
    if (r.admin === true || r.admin === false) setSetting('device_is_admin', r.admin ? '1' : '0');
    try { withSystem(() => applyControl(r.control)); } catch (e) { /* next round */ }
    if (r.commands && r.commands.length) { try { await runCommands(r.commands, { send: (b) => post(b, 60000) }); } catch (e) { /* next round */ } }
    const list = r.records || [];
    if (list.length) received += withSystem(() => applyPulledRecords(list));
    if (typeof r.next === 'number') withSystem(() => setPullCursor(r.next));
    if (!r.more) break;
  }
  try { withSystem(() => retireSampleLogins()); } catch (e) { /* try again next round */ }
  // Go-live: the owner started fresh on the main tablet – clear the same old records here too (safety copy first).
  try { await applyFresh(freshMarker(), { snapshot: () => snapshotNow('fresh') }); } catch (e) { /* next round */ }
  try { withSystem(() => postBakeryReceipts()); } catch (e) { /* next round */ }
  try { withSystem(() => sendAnswered()); } catch (e) { /* next round */ }
  // Automatic Viber Channel alerts (main tablet only, each once).
  try { if (getSetting('cloud_key', '')) await require('../services/board.js').buildBoardAsync(); } catch (e) { /* worked out below */ }
  try { withSystem(() => autoViberAlerts({ isMain: !!getSetting('cloud_key', '') })); } catch (e) { /* next round */ }
  // v3.9.8 the FCCC lists and the monthly LPG (gas) prices: looked at on the main tablet every few hours (each
  // check waits 6 hours by itself, and never stops the sync).
  // v3.9.8 the FCCC lists, the monthly LPG (gas) and fuel prices and the water bills: looked at on the main tablet
  // (each check waits its own hours). They run on their own, one round at a time, each with a time limit – a slow
  // website never holds up the sync.
  if (getSetting('cloud_key', '')) runWebChecks();
  // v3.9.8 the problem loop: new errors on this device go to support by themselves (at most every 12 hours, at once
  // after a crash), so every problem reaches the person who fixes the app – nobody has to remember to send it.
  // v3.9.8 the app checks itself once a day; anything wrong goes into the problem report just below.
  // 1.0.0 a check at a time with a pause after each (the screens keep answering); saves are the app's own (system)
  try { await require('../services/selfCheck.js').runSelfCheckAsync({ wrap: withSystem }); } catch (e) { /* next round */ }
  // 1.0.0 the full check of a long change history, a slice per round (Home only adds the new entries)
  try { withSystem(() => require('../services/watchdog.js').verifyChainStep()); } catch (e) { /* next round */ }
  try { autoProblemReport(); } catch (e) { /* next round */ }
  // The monthly accountant pack (main tablet only).
  try {
    const due = packDue({ today: dateStr(), isMain: !!getSetting('cloud_key', '') });
    if (due) withSystem(() => { if (due.mode === 'auto') enqueue('acct_pack', { from: due.from, to: due.to }); else noteMade('accountant_pack', { from: due.from, to: due.to }, `Accountant pack ${due.month}`); setSetting('acct_pack_month', due.month); });
  } catch (e) { /* next round */ }
  // The device list (for the device warnings), every 30 minutes.
  try {
    const c = cachedDevices();
    if (!c || Date.now() - new Date(String(c.at).replace(' ', 'T')).getTime() > 30 * 60000) { const d = await post({ kind: 'devices' }, 30000); withSystem(() => cacheDevices(d.devices || [])); }
  } catch (e) { /* next round */ }
  return { sent, received };
}

export async function syncNow({ force = false } = {}) {
  const s = getSettings();
  if (!s.cloudUrl || running || isTraining()) return { skipped: true };
  running = true;
  const syncT0 = Date.now();
  let waiting0 = 0;
  try { waiting0 = Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox(); } catch (e) { waiting0 = 0; }
  setSyncState({ running: true, lastTry: stamp(), progress: waiting0 ? `Sending ${waiting0} item${waiting0 === 1 ? '' : 's'}…` : 'Checking for changes…' });
  let sent = 0;
  let received = 0;
  let error = null;
  let planChanged = 0;
  let linkFresh = false;
  try {
    const rec = await syncRecords();
    setSyncState({ progress: 'Fetching changes from the other devices…' });
    sent += rec.sent;
    received = rec.received;
    // v3.9.4 the Aronium link: the main tablet turns what the till PCs sent into sales, End of days and products.
    try {
      const L = require('../modules/aronium/link.js');
      let last = null;
      try { last = JSON.parse(getSetting('aronium_link_last', '') || 'null'); } catch (e) { last = null; }
      const stale = !last || !last.at || minutesBetween(last.at, stamp()) >= 10;
      // v1.0.0 every device makes the sales and End of days (the main tablet also the products, FCCC, credit…)
      if (received > 0 || (last && last.left > 0) || stale) {
        setSyncState({ progress: 'Bringing in the tills\' figures…' });
        const pr = L.processLink();
        if (pr && pr.did && pr.did.length) linkFresh = true;
      }
    } catch (e) { /* never stops the sync; the next round tries again */ }
    const today = dateStr();
    // Nightly full backup: from the main tablet only (when one is chosen), otherwise once a day as before.
    if (getSetting('last_backup_date') !== today && backupDue({ last: getSetting('last_backup_date', '') })) {
      withSystem(() => enqueue('backup', { date: today, tier: 'daily' }));
      setSetting('last_backup_date', today);
    }
    // v3.9.4 one device sends the online dashboard (see services/board.js), every 2–5 minutes.
    let sendDash = true;
    try {
      const B = require('../services/board.js');
      let isMain = false;
      try { isMain = require('../modules/aronium/link.js').isLinkDevice(); } catch (e) { isMain = false; }
      // v3.9.4 new figures (a sale from a till PC, a change on another device): the dashboard goes out straight away
      // (at most every 30 seconds) instead of waiting for its 2–5 minute turn.
      const fresh = linkFresh || received > 0;
      if (fresh) B.boardStale();
      sendDash = withSystem(() => B.shouldSendDashboard({ isMain, fresh }));
    } catch (e) { sendDash = true; }
    if (sendDash) {
      setSyncState({ progress: 'Updating the online dashboard…' });
      // the board is worked out a part at a time first (the screens keep answering); the snapshot then uses it
      try { await require('../services/board.js').buildBoardAsync(); } catch (e) { /* the snapshot works it out */ }
      const r = await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000);
      if (r && r.version) setSetting('cloud_script_version', String(r.version));
      // Plan changes made on the online dashboard come back with the reply.
      if (r.planEdits && r.planEdits.length) {
        planChanged = withSystem(() => applyOnlinePlans(r.planEdits)); // the app's own work (sync), not a person
        await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000); // confirm to the dashboard straight away
      }
    }
    // v3.9.4 records made during this sync (the dashboard's first build, the till figures, the alerts) go now, not
    // next round, so "All synced" really means nothing is waiting.
    sent += await pushRecords(5);
    const jobs = pendingOutbox(force ? 50 : 10);
    for (const [k, item] of jobs.entries()) {
      setSyncState({ progress: `Sending files and emails (${k + 1} of ${jobs.length})…` });
      try {
        await handle(item);
        withSystem(() => markOutboxSent(item.id));
        sent += 1;
      } catch (e) {
        withSystem(() => markOutboxFailed(item.id, e.message || e));
        error = e.message || String(e);
        // No internet: stop and try again next round. Anything else (e.g. a bad email address): skip it so it does not hold up the rest.
        if (/network|fetch|abort|timed|offline|Failed to/i.test(error)) break;
      }
    }
    setSetting('last_sync_at', stamp());
    try { await clearOldLocalCopies(); } catch (e) { /* next time */ }
    // v3.9.6 Deleted bin: records more than 90 days in it are gone for good (checked each sync; cheap when none).
    try { withSystem(() => require('../services/bin.js').purgeBin()); } catch (e) { /* next time */ }
  } catch (e) {
    error = e.message || String(e);
  } finally {
    running = false;
    setSetting('last_sync_error', error || '');
    if (!error) setSetting('last_sync_ok_at', stamp());
    setSyncState({ running: false, error: error || '', lastOk: getSetting('last_sync_ok_at', ''), sent, received, progress: '' });
    crumb('sync', `${waiting0} waiting · sent ${sent} · got ${received} · ${Date.now() - syncT0}ms${error ? ' · ERROR ' + String(error).slice(0, 120) : ' · ok'}`);
  }
  return { sent, received, error, planChanged };
}

export function syncStatus() {
  return {
    configured: !!getSettings().cloudUrl,
    lastOk: getSetting('last_sync_ok_at', ''),
    lastTry: getSetting('last_sync_at', ''),
    error: getSetting('last_sync_error', ''),
  };
}

// ---------------------------------------------------------------- documents kept in Google Drive
// Upload one document: unique upload id (a repeated upload returns the file already in Drive), size + SHA-256 sent
// and checked against what the cloud script got. Status on the document: uploading → verified / failed / login.
export async function uploadDocument(uid) {
  const d0 = getDocument(uid);
  if (!d0 || d0.status !== 'active') return 'skipped';
  if (d0.upload_status === 'verified' && d0.cloud_id) return 'verified';
  if (!d0.path || !(await fileExists(d0.path))) {
    if (!d0.cloud_id) withSystem(() => markUploadFailed(uid, 'The file is not on this device.'));
    return 'missing';
  }
  const d = describeDocument(d0);
  const data = await fileBase64(d0.path);
  const fp = base64Fingerprint(data);
  withSystem(() => markUploading(uid));
  let r;
  try {
    r = await post({ kind: 'file_put', uploadId: uploadIdFor(d0), folder: d0.ref_type, path: d.folder, docType: d.doc_type, access: d.access_class, refUid: d0.ref_uid || '',
      fileName: `${d0.uid}-${String(d0.name).replace(/[^A-Za-z0-9 ._-]+/g, '-').slice(0, 60)}.${extFor(d0.mime, d0.name)}`, mime: d0.mime || 'application/octet-stream', data, size: fp.size, sha256: fp.sha256 }, 300000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } catch (e) {
    withSystem(() => markUploadFailed(uid, e.message || String(e)));
    throw e;
  }
  return withSystem(() => markUploaded(uid, fp, r));
}

// The file of a document as base64: from this device, or fetched from the cloud copy (then kept here too).
// The cloud checks the logged-in person's role against the document visibility setting before sending it.
export async function documentBase64(d, user = appUser()) {
  if (d.path && (await fileExists(d.path))) return fileBase64(d.path);
  if (!d.cloud_id) throw new Error('This document is on another device and has not reached the cloud yet. Open it there, or sync that device first.');
  if (isTraining()) throw Object.assign(new Error('Not available in training mode.'), { isAppError: true });
  const r = await post({ kind: 'file_get', id: d.cloud_id, user: user ? { uid: user.uid, role: user.role } : undefined }, 300000);
  if (!r || !r.data) throw new Error((r && r.error) || 'Could not fetch the document from the cloud.');
  if (d.sha256) {
    const fp = base64Fingerprint(r.data);
    if (fp.sha256 !== String(d.sha256).toLowerCase()) throw new Error('The copy fetched from Google Drive does not match the original (fingerprint differs). It was not opened.');
  }
  const dir = `${FS.documentDirectory}docs/`;
  try { await FS.makeDirectoryAsync(dir, { intermediates: true }); } catch (e) { /* already there */ }
  const path = `${dir}${d.uid}.${extFor(d.mime, d.name)}`;
  await FS.writeAsStringAsync(path, r.data, { encoding: FS.EncodingType.Base64 });
  withSystem(() => markFetched(d.uid, path));
  return r.data;
}

// Tablet copies of documents verified in Drive and older than the admin's retention (default 90 days) are removed
// from this device; they are fetched again when opened.
export async function clearOldLocalCopies() {
  let n = 0;
  for (const d of localCopiesToClear()) {
    try { await FS.deleteAsync(d.path, { idempotent: true }); } catch (e) { continue; }
    withSystem(() => markLocalCleared(d.uid));
    n += 1;
  }
  return n;
}

// New or replaced tablet, after the data was restored: fetch back the recent document files (each checked).
export async function fetchNeededFiles(onProgress = () => {}) {
  const list = filesToFetch();
  let ok = 0;
  const failed = [];
  for (const [i, d] of list.entries()) {
    onProgress(i + 1, list.length, d.name);
    try { await documentBase64({ ...getDocument(d.uid), path: null }); ok += 1; } catch (e) { failed.push({ name: d.name, error: e.message || String(e) }); }
  }
  return { total: list.length, ok, failed };
}
