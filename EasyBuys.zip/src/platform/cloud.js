// Sends data to the bakery's Google account (via the Apps Script "bakery cloud").
// Works offline-first: everything waits in the outbox until the tablet is online.
import { db, withSystem } from '../db/connection.js';
import { getSettings, setSetting, getSetting, getShared, stamp, APP_VERSION, dateStr, deviceId, deviceName, minutesBetween, audit, AppError, stripSecretsText } from '../services/core.js';
import { actsAsOwner } from '../services/access.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor, SYNC_TABLES, pendingBySection } from '../services/records.js';
import { snapshotNow } from '../services/snapshots.js';
import { applyFresh, freshMarker } from '../services/startFresh.js';
import { postBakeryReceipts } from '../modules/bakery/store.js';
import { recipientsFor, sendAnswered, packDue, noteMade } from '../services/emailPrefs.js';
import { accountantPack } from '../modules/accounting/statements.js';
import { autoViberAlerts } from '../services/viberAuto.js';
import { deviceStat, applyControl, runCommands, setDeviceLock, wipeThisDevice, deviceLock } from '../modules/devices/control.js';
import { cachedDevices, cacheDevices } from '../modules/devices/service.js';
import { setSyncState } from '../services/syncBus.js';
import { crumb } from '../services/breadcrumbs.js';
import { pendingOutbox, markOutboxSent, markOutboxFailed, getPhoto, setPhotoCloudUrl, markPoSent, enqueue, countPendingOutbox } from '../services/stock.js';
import { shiftReport, purchaseOrderDoc } from '../services/reports.js';
import { markReportSent, getShift } from '../services/shifts.js';
import { buildSnapshot } from '../services/dashboard.js';
import { applyOnlinePlans, planSeq } from '../services/plan.js';
import { reportPdf, reportXlsx, fileBase64, fileExists } from './files.js';
import { retireSampleLogins } from '../modules/devices/service.js';
import { contractReport } from '../modules/people/service.js';
import { isTraining } from '../services/trainingFlag.js';
import { getDocument, setCloudCopy, setLocalPath, extFor } from '../services/documents.js';
import * as FS from 'expo-file-system/legacy';
import { describeDocument, uploadIdFor, markUploading, markUploaded, markUploadFailed, markFetched, localCopiesToClear, markLocalCleared, filesToFetch, backupDue, backupManifest } from '../services/driveDocs.js';
import { base64Fingerprint } from '../services/sha256.js';
import { appUser } from '../services/errorLog.js';
import { photoPlaceFromDb, payslipPlace, poPlace, docPlace, deliveryPlace } from '../services/photoNames.js';
// 1.0.0 (owner, 2 Nov): where the cloud (script 16) keeps a record's photo or a document: Records › month › [shop ›] kind.
// Older scripts ignore these and keep the old place.
export function recordsPlace(place) {
  return place ? { niceName: place.fileName, monthFolder: place.monthFolder, shopFolder: place.shopFolder, typeFolder: place.typeFolder, ...(place.folders ? { folders: place.folders } : {}) } : {};
}
import { signBody, sentAtNow } from '../services/deviceSign.js';
import { mayDoJob, refreshLeases, jobMark, setJobMark, renewLease, ASK_EVERY_MS } from '../services/jobLease.js';
import { requirePerm, asService, requireTop } from '../services/guard.js';

let running = false;
// Business-wide money alerts: the owner / admin channel only (never a shop's channel, where the staff are).
// The phone's clock is checked against the cloud's only when the answer came back quickly. A reply that arrives while
// the app is paused in the background is read minutes later and used to look like a fast clock (owner, 2 Nov:
// "This phone's clock is 35 minutes fast" on a phone set to automatic time – money entries were stopped).
export const SKEW_TRUST_MS = 20000;
export function skewTrust(sentAt, now = Date.now()) { return Number.isFinite(sentAt) && now - sentAt >= 0 && now - sentAt <= SKEW_TRUST_MS; }

export const OWNER_EVENTS = ['statutory_due', 'watchdog_urgent', 'morning', 'alerts_urgent', 'locked_change'];

// Any request to the cloud. Linked devices send their own token; the first device may use the cloud key.
// 1.0.0 (owner, 2 Nov): Admin › Backup › "Tidy Drive photos into month folders" – the cloud (script 16) moves the photos
// already in Drive › Photos into Records › month › …, about 5 minutes a go; asked again until it says it is done.
export async function tidyDrivePhotos(onStep, maxRuns = 40) {
  const total = { moved: 0, left: 0, runs: 0 };
  for (let i = 0; i < maxRuns; i++) {
    const r = await cloudCall({ kind: 'tidy_records' }, 360000);
    if (!r || r.ok === false) return { ok: false, message: (r && r.error) || 'The cloud did not answer.', ...total };
    total.moved += Number(r.moved) || 0; total.left = Number(r.left) || 0; total.runs++;
    if (onStep) onStep({ ...total });
    if (!r.more) return { ok: true, more: false, ...total };
  }
  return { ok: true, more: true, ...total };
}
export async function cloudCall(body, timeoutMs = 60000) {
  await ensureSession();
  return post(body, timeoutMs);
}

// 1.0.0 build 1: after a PIN login on this device, the cloud checks the person too (user_login with the proof of the
// PIN, worked out at login and kept in memory only) and gives a session for 12 hours. Without the internet the person
// works on as before; owner / admin changes wait on the device until the session is there.
export async function ensureSession() {
  const P = require('../services/pins.js');
  const pend = P.takePendingLogin();
  let me = null;
  try { me = appUser(); } catch (e) { me = null; }
  // (me: the person on the screen; none when the app runs without screens, e.g. the tests)
  if (!pend || (me && me.uid !== pend.uid) || isTraining() || !getSettings().cloudUrl) return null;
  if (Number(getSetting('cloud_script_version', '0')) < 12) return null;
  try {
    const r = await post({ kind: 'user_login', uid: pend.uid, proof: pend.proof }, 30000);
    P.setCloudSession(pend.uid, r.session, r.until);
    return r.session;
  } catch (e) {
    // a wrong / unknown PIN in the cloud: keep working on this device; owner work waits (the Sync screen says why)
    setSetting('cloud_login_problem', String(e && e.message ? e.message : e).slice(0, 200));
    if (!/not reached the cloud yet/.test(String(e && e.message))) P.setCloudSession(pend.uid, null);
    return null;
  }
}

// 1.0.0 build 13 (owner, 6 Nov): the owner / an admin on a staff phone. A staff phone never holds the owner / admin PIN
// hashes (the cloud keeps them to admin devices), so their PIN is checked by the cloud instead (online only): the proof
// of the PIN typed is sent for each owner / admin login on this phone, and the one the cloud accepts is logged in with a
// cloud session. Only when the person taps "Owner or admin? Check online" – a staff member's wrong PIN never counts
// against the owner in the cloud. → the person, or null when the cloud accepted none
export function cloudPinPossible() {
  try {
    if (isTraining() || !getSettings().cloudUrl || !getSetting('cloud_token', '')) return false;
    if (Number(getSetting('cloud_script_version', '0')) < 12) return false;
    return !!db().get("SELECT 1 AS x FROM users WHERE active = 1 AND role IN ('owner', 'admin') AND uid IS NOT NULL AND (pin_hash IS NULL OR pin_hash = '') LIMIT 1");
  } catch (e) { return false; }
}
export async function cloudPinLogin(pin) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  if (!/^\d{4,6}$/.test(p) || !cloudPinPossible()) return null;
  const P = require('../services/pins.js');
  const tops = db().all("SELECT * FROM users WHERE active = 1 AND role IN ('owner', 'admin') AND uid IS NOT NULL AND (pin_hash IS NULL OR pin_hash = '') ORDER BY CASE role WHEN 'owner' THEN 0 ELSE 1 END, id");
  for (const u of tops) {
    const proof = P.pinProof(p, u.uid);
    if (!proof) continue;
    let r;
    try { r = await post({ kind: 'user_login', uid: u.uid, proof }, 30000); } catch (e) {
      const m = String(e && e.message ? e.message : e);
      if (/did not accept this PIN|not reached the cloud yet/.test(m)) continue; // not this person
      throw e; // no internet, too many tries, …: said on the screen
    }
    if (r && r.session) { P.setCloudSession(u.uid, r.session, r.until); return u; }
  }
  return null;
}

// v3.9.2 in practice (training) mode only these read-only requests reach the cloud – nothing is changed for real.
// 1.0.0 invoice_ai: the AI reading an invoice only reads (nothing is kept in the cloud).
// 1.0.0 build 10: the cloud is busy (it answered "busy", or did not answer within our time limit). Never shown as
// "No internet": the message has none of the words the screens take for no internet (see services/syncInfo.js).
export const BUSY_MESSAGE = 'The cloud is busy – trying again';
// review (3 Nov): our own time limit ran out = the connection (a hung or very slow line), not the cloud – said so.
export const SLOW_MESSAGE = 'Slow or no connection – trying again in a minute';
export function busyError(retryMs, slow = false) {
  return Object.assign(new Error(slow ? SLOW_MESSAGE : BUSY_MESSAGE), { busy: true, slow, retryMs: Number(retryMs) > 0 ? Number(retryMs) : 0 });
}
export const isBusy = (e) => !!(e && (e.busy || String(e.message || e) === BUSY_MESSAGE));
// A request tried again (with a growing wait) when the cloud is busy – within the same sync, not a minute later. No
// internet is not tried again (it fails at once). onRetry(n, e) before each new try (the sync shows it).
export const RETRY_WAITS = [1500, 4000, 9000];
// the wait between tries (tests make it instant)
export const syncTiming = { wait: (ms) => new Promise((r) => setTimeout(r, ms)) };
// retrySlow: false – our own time limit ran out (e.slow): not asked again at the same size (the caller asks for a smaller
// page instead), so a slow page never waits 4 × its time limit.
export async function postRetry(body, timeoutMs = 60000, { tries = RETRY_WAITS.length + 1, onRetry = null, wait = (ms) => syncTiming.wait(ms), send = post, retrySlow = true } = {}) {
  let last = null;
  for (let n = 0; n < tries; n += 1) {
    try { return await send(body, timeoutMs, n); } catch (e) {
      if (!isBusy(e) || n === tries - 1 || (e.slow && !retrySlow)) throw e;
      last = e;
      if (onRetry) { try { onRetry(n + 1, e); } catch (x) { /* only a note */ } }
      const base = RETRY_WAITS[Math.min(n, RETRY_WAITS.length - 1)];
      await wait(Math.max(base, Math.min(15000, e.retryMs || 0)) + Math.floor(Math.random() * 500));
    }
  }
  throw last;
}
// cloudCall that tries again when the cloud is busy (the devices list, the lease…)
export async function cloudCallRetry(body, timeoutMs = 45000, opts = {}) {
  await ensureSession();
  return postRetry(body, timeoutMs, opts);
}
const TRAINING_OK = ['ping', 'devices', 'ocr', 'invoice_ai', 'fccc_lpg', 'problem_log_get', 'file_get', 'check_update'];
// 1.0.0 build 27: the move to Cloudflare. The old cloud answers "moved" with the new address; the phone only goes
// there after the new cloud has answered its own signed check (so it knows this device, i.e. it really is this
// business's cloud). Anything not sent yet stays on the phone and goes to the new address.
export const MOVE_RE = /^https:\/\/[a-z0-9-]+(\.[a-z0-9-]+)+(\/[A-Za-z0-9._~\/-]*)?$/i;
let moving = null;
// build 46 (11 Nov, the real move): a phone checked the new cloud (its pings arrived and were answered OK) and still
// stayed on Google. Now: the new address is saved and read back, the request then goes straight to the new address
// (not through the saved setting again), every step is noted in the activity trail, and when it cannot move the
// message says why (so Sync status shows the real reason).
let lastMoveWhy = '';
export function moveProblem() { return lastMoveWhy; }
export async function followMove(to, from) {
  const url = String(to || '').trim();
  if (!MOVE_RE.test(url) || url === from) { lastMoveWhy = `the new address is not usable (${url.slice(0, 60)})`; return false; }
  if (moving) return moving;
  const p = (async () => {
    let r;
    try { r = await post({ kind: 'ping' }, 45000, 0, { url }); } catch (e) {
      lastMoveWhy = `the new cloud's check failed: ${String((e && e.message) || e).slice(0, 160)}`;
      try { crumb('sync', `move: ${lastMoveWhy}`); } catch (x) { /* only a note */ }
      return false;
    }
    if (!r || !r.ok) { lastMoveWhy = `the new cloud said: ${String((r && r.error) || 'no answer').slice(0, 160)}`; try { crumb('sync', `move: ${lastMoveWhy}`); } catch (x) { /* note */ } return false; }
    try { setSetting('cloud_url', url); } catch (e) {
      lastMoveWhy = `the new address could not be saved on this phone: ${String((e && e.message) || e).slice(0, 160)}`;
      try { crumb('sync', `move: ${lastMoveWhy}`); } catch (x) { /* note */ }
      return url; // this request still goes to the new address; the next one tries saving again
    }
    const back = getSetting('cloud_url', '');
    if (back !== url) { try { crumb('sync', `move: saved, but the setting reads back ${String(back).slice(0, 50)}`); } catch (x) { /* note */ } }
    try { if (r.version) setSetting('cloud_script_version', String(r.version)); } catch (e) { /* only a note */ }
    try { setSetting('cloud_moved_at', stamp()); } catch (e) { /* only a note */ }
    try { audit({ user: null, action: `Cloud moved to the new address (${url.replace(/^https:\/\//, '').split('/')[0]}) – the old one said so and the new one knows this device`, table: 'settings', recordUid: 'cloud_url' }); } catch (e) { /* only a note */ }
    try { crumb('sync', `move: moved to ${url.replace(/^https:\/\//, '').split('/')[0]}`); } catch (x) { /* note */ }
    lastMoveWhy = '';
    return url;
  })();
  moving = p;
  try { return await p; } finally { moving = null; }
}
async function post(body, timeoutMs = 90000, _try = 0, { url: overUrl = null } = {}) {
  if (isTraining() && !TRAINING_OK.includes(body && body.kind)) throw Object.assign(new Error('Not available in practice mode – nothing is sent to the cloud. Switch back to the real app first (Admin › Training).'), { isAppError: true });
  const s = getSettings();
  const token = getSetting('cloud_token', '');
  if (!s.cloudUrl && !overUrl) throw Object.assign(new Error('The cloud web address is not set (Admin → Settings → Online & email).'), { isAppError: true });
  const target = overUrl || s.cloudUrl;
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    // 1.0.0 build 1: signed with this device's pass; once the cloud is version 12 a linked device no longer sends the
    // pass itself. The person logged in goes with their cloud session (the cloud checks owner / admin work by it).
    const v12 = Number(getSetting('cloud_script_version', '0')) >= 12;
    const P = require('../services/pins.js');
    let session;
    try { const me = appUser(); session = P.cloudSession(me ? me.uid : undefined) || undefined; } catch (e) { session = undefined; }
    const out = { key: token ? undefined : s.cloudKey, token: token && !v12 ? token : undefined, app: APP_VERSION + (getSetting('fresh_applied', '') ? ` fresh:${String(getSetting('fresh_applied', '')).slice(-6)}` : ''), location: s.locationName, sentAt: sentAtNow(), device: { id: deviceId(), name: deviceName(), kind: getSetting('device_kind', 'tablet') }, session, ...body };
    if (!out.pinSalt && ['ping', 'pull'].includes(body.kind)) { try { out.pinSalt = P.pinSalt() || undefined; } catch (e) { /* none */ } }
    const sig = signBody(token || s.cloudKey, out.device.id, out);
    if (sig) out.sig = sig;
    const sentAt = Date.now(); // 2 Nov: the clock check only trusts a quick answer (see below)
    let res; let text;
    try {
      res = await fetch(target, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(out),
        signal: ctrl ? ctrl.signal : undefined,
      });
      text = await res.text();
    } catch (e) {
      // 1.0.0 build 10 (go-live, 2 Nov): our own time limit ran out while the cloud was answering other phones – the
      // internet is fine, the cloud is busy (it used to say "Aborted", shown as "No internet right now").
      if ((ctrl && ctrl.signal && ctrl.signal.aborted) || (e && e.name === 'AbortError')) throw busyError(0, true);
      throw e;
    }
    // v3.9.3 the device clock checked against Google's: a wrong clock refuses entries and confuses sync.
    try {
      const hd = res.headers && res.headers.get ? res.headers.get('date') : null;
      const t = hd ? Date.parse(hd) : NaN;
      if (Number.isFinite(t) && !isTraining() && skewTrust(sentAt)) setSetting('clock_skew_min', String(Math.round((Date.now() - t) / 60000)));
    } catch (e) { /* no date header */ }
    let json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw new Error(res.status === 200 ? 'The cloud did not reply correctly. Check the web address and that it is deployed for "Anyone".' : `Cloud error ${res.status}`);
    }
    // 1.0.0 hardening: the cloud's own clock in every reply (script 12+) – more exact than the Date header
    try { const st = Number(json && json.serverTime); if (Number.isFinite(st) && st > 0 && !isTraining() && skewTrust(sentAt)) { setSetting('clock_skew_min', String(Math.round(((sentAt + Date.now()) / 2 - st) / 60000))); setSetting('clock_checked_at', String(Date.now())); } } catch (e) { /* older script */ }
    if (json.busy && !json.ok) throw busyError(json.retryMs);
    if (json.moved && !json.ok && !overUrl) {
      // the old cloud only says where the business went: nothing here is locked or changed by that answer
      const to = await followMove(json.moved, target);
      if (to) return post(body, timeoutMs, _try, { url: typeof to === 'string' ? to : null });
      throw Object.assign(new Error(`The cloud is moving to its new address. Your entries are kept on this phone and sent as soon as it is ready.${lastMoveWhy ? ` (${lastMoveWhy})` : ''}`), { isAppError: true, moving: true });
    }
    if (json.waiting) setSetting('link_waiting', '1');
    if (isTraining()) { if (!json.ok) throw new Error(json.error || 'The cloud refused the request.'); return json; } // practice: never locks
    // The owner blocked this device (lost or stolen): lock it until it is unblocked.
    setSetting('device_blocked', json.blocked ? '1' : (json.ok ? '0' : getSetting('device_blocked', '0')));
    if (json.ok && !json.lock) { try { require('../modules/devices/control.js').clearLockOverride(); } catch (e) { /* none */ } }
    // v3.6 Admin › Devices: paused, access ended, removed or wiped (the cloud enforces it; the device shows why).
    if (json.wipe) { try { withSystem(() => wipeThisDevice()); } catch (e) { withSystem(() => setDeviceLock({ kind: 'wiped' })); } }
    else if (json.lock) withSystem(() => setDeviceLock(json.lock));
    else if (json.removed && getSetting('cloud_token', '')) withSystem(() => setDeviceLock({ kind: 'removed' }));
    else if (json.ok) { const l = deviceLock(); if (l && l.kind !== 'wiped' && l.kind !== 'blocked') withSystem(() => setDeviceLock(null)); }
    if (!json.ok) throw new Error(json.error || 'The cloud refused the request.');
    if (getSetting('link_waiting', '') === '1') setSetting('link_waiting', '0');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function testConnection() {
  const r = await post({ kind: 'ping' }, 30000);
  if (r && r.version) setSetting('cloud_script_version', String(r.version));
  return r;
}

// Every table (Easy Buys and Bakery) for the daily backup in Google Drive. PINs, passwords and the cloud key are hidden.
// 1.0.0 speed: tables the app works out again by itself are not backed up (inventory/stockMonths.js).
const DUMP_SKIP = ['outbox', 'inv_stock_months'];
function dumpTables() {
  return db().all(`SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name NOT IN (${DUMP_SKIP.map((t) => `'${t}'`).join(', ')}) ORDER BY name`).map((r) => r.name);
}
function dumpRow(t, r) {
  if (t === 'users') return { ...r, pin: r.pin ? '****' : r.pin, ...('pin_hash' in r ? { pin_hash: r.pin_hash ? '****' : null } : {}), ...('pin_proof' in r ? { pin_proof: null } : {}), password_hash: r.password_hash ? '****' : null };
  if (t === 'settings' && /key|token|secret|salt|session/i.test(String(r.key))) return { ...r, value: '****' };
  // older history entries and Deleted-bin copies may still hold a PIN: hidden the same way
  if (t === 'audit_log') return { ...r, before: stripSecretsText(r.before), after: stripSecretsText(r.after) };
  if (t === 'bin_parts') return { ...r, data: stripSecretsText(r.data) };
  return r;
}
// The rows of a table a slice at a time, in the same order as SELECT * gives them (rowid order).
// size: a number, or a function giving the size of the next slice (the backup makes slices smaller when one holds the
// screen up too long). after: start after this rowid (a backup going on where it stopped). Each slice is an array of
// rows with .last = the rowid of its last row ('all' for a table with no rowid, which comes in one slice).
function* tableSlices(t, size, after = null) {
  const sz = typeof size === 'function' ? size : () => size;
  let hasRowid = true;
  try { db().get(`SELECT rowid AS _r FROM ${t} LIMIT 1`); } catch (e) { hasRowid = false; }
  if (!hasRowid) { if (after === 'all') return; const all = db().all(`SELECT * FROM ${t}`); all.last = 'all'; yield all; return; }
  let last = after;
  for (;;) {
    const n = Math.max(1, Math.floor(sz()));
    const rows = last === null ? db().all(`SELECT rowid AS _eb_rowid, * FROM ${t} ORDER BY rowid LIMIT ?`, [n]) : db().all(`SELECT rowid AS _eb_rowid, * FROM ${t} WHERE rowid > ? ORDER BY rowid LIMIT ?`, [last, n]);
    if (!rows.length) return;
    last = rows[rows.length - 1]._eb_rowid;
    const out = rows.map((r) => { const { _eb_rowid, ...x } = r; return x; });
    out.last = last;
    yield out;
    if (rows.length < n) return;
  }
}
// 1.0.0 speed: slices sized by time, not by a fixed count – a slice that took long (wide rows: the change history,
// photos' notes …) makes the next one smaller, a quick one makes it bigger, so one slice never holds the screen up
// for more than about 50 ms on this device and small rows go quickly. The rows and their order are the same.
function sliceSizer(start = 400, { aimMs = 25, min = 20, max = 4000 } = {}) {
  let size = start;
  return {
    size: () => size,
    // a new table starts small again (its rows may be much wider than the last table's)
    reset() { size = Math.min(size, 50); },
    took(ms) { if (ms > aimMs * 2 && size > min) size = Math.max(min, Math.floor(size / 2)); else if (ms < aimMs / 2 && size < max) size = Math.min(max, size * 2); },
  };
}
export function dumpDatabase() {
  const tables = dumpTables();
  const out = { _meta: { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: tables.length } };
  for (const t of tables) {
    out[t] = db().all(`SELECT * FROM ${t}`).map((r) => dumpRow(t, r));
  }
  return out;
}
// 1.0.0 every table a slice of rows at a time, each row as the backup writes it (JSON text), with a pause between
// slices so the screens keep answering while a big backup is made. fn(table, jsonRows, { first, last }) per slice
// (a table with no rows gives one call with no rows). Returns { tables, rows }.
export async function forEachDumpSlice(fn, { slice = 400, onProgress = null, pause = () => new Promise((r) => setTimeout(r, 0)) } = {}) {
  const tables = dumpTables();
  const sizer = sliceSizer(slice);
  let n = 0;
  for (let i = 0; i < tables.length; i += 1) {
    const t = tables[i];
    let firstSlice = true;
    sizer.reset();
    const it = tableSlices(t, sizer.size);
    let t0 = Date.now();
    let cur = it.next();
    if (cur.done) fn(t, [], { first: true, last: true });
    while (!cur.done) {
      const part = cur.value.map((r) => JSON.stringify(dumpRow(t, r)));
      n += part.length;
      sizer.took(Date.now() - t0);
      // the next slice is read after the pause (so a slice is one hold-up, not two)
      await pause();
      t0 = Date.now();
      cur = it.next();
      fn(t, part, { first: firstSlice, last: cur.done });
      firstSlice = false;
      if (onProgress) { try { onProgress({ table: t, rows: n, tables: tables.length, done: i }); } catch (e) { /* only a note */ } }
    }
  }
  return { tables: tables.length, rows: n };
}
// The backup file's text: exactly JSON.stringify(dumpDatabase()) (with `head` fields first, e.g. the year archive),
// made with forEachDumpSlice. NOTE: one text for the whole business only works while the data is not too big (a
// phone, like Node, cannot hold one text of more than about 500 MB; 3 years of data is near that) – see the report
// of the speed work: the backup has to go up in parts (cloud side).
export async function dumpDatabaseText({ head = null, slice = 400, onProgress = null, pause } = {}) {
  const meta = { app: 'Easy Buys', made: stamp(), device: deviceId(), tables: dumpTables().length };
  const parts = ['{'];
  let first = true;
  const key = (k, v) => { parts.push(`${first ? '' : ','}${JSON.stringify(k)}:${v}`); first = false; };
  if (head) for (const [k, v] of Object.entries(head)) { if (v !== undefined && typeof v !== 'function') key(k, JSON.stringify(v)); }
  key('_meta', JSON.stringify(meta));
  let rows = [];
  await forEachDumpSlice((t, part, { first: f, last }) => {
    if (f) rows = [];
    for (const x of part) rows.push(x);
    if (last) key(t, `[${rows.join(',')}]`);
  }, { slice, onProgress, ...(pause ? { pause } : {}) });
  parts.push('}');
  return parts.join('');
}
// 1.0.0 speed: the backup goes up to Drive in parts of a few MB (cloud script: backup_part, then backup_done), a slice
// of rows at a time with a pause between slices, so the screens never freeze and a phone never has to hold the whole
// business as one text. Where it got to is kept (setting backup_upload) after every part: a backup cut off (app closed,
// no internet) goes on from the next part on the next try instead of starting again. Each part is
// {"_part":n,"tables":{"<table>":[rows…],…}}; a table can go on into the next part. The file kept in Drive under
// fileName is the index ({ _meta, _parts, … }); fetchDriveBackup() puts the parts back together for a restore.
// An older cloud script (no backup_part) gets the whole backup in one go as before.
export const BACKUP_PART_BYTES = 3 * 1024 * 1024;
const UPLOAD_KEY = 'backup_upload';
export function backupUploadState() { try { return JSON.parse(getSetting(UPLOAD_KEY, '') || 'null'); } catch (e) { return null; } }
export async function uploadBackupInParts({ tier = 'daily', date = dateStr(), fileName, head = null, manifest = null, send = (b) => post(b, 300000), partBytes = BACKUP_PART_BYTES, onProgress = null,
  pause = () => new Promise((r) => setTimeout(r, 0)), whole = null } = {}) {
  const name = fileName || `backup-${date}.json`;
  let st = backupUploadState();
  if (!st || st.fileName !== name || st.tier !== tier) {
    st = { fileName: name, tier, date, id: `BK-${deviceId()}-${Date.now().toString(36)}`, made: stamp(), n: 0, t: 0, r: null, rows: 0 };
    setSetting(UPLOAD_KEY, JSON.stringify(st));
  }
  const tables = dumpTables();
  const sizer = sliceSizer(400);
  let pieces = []; let bytes = 0; let open = null; // the part being made: `"table":[rows` pieces
  const sendPart = async (ti, r) => {
    if (open !== null) { pieces.push(']'); open = null; }
    const data = `{"_part":${st.n},"tables":{${pieces.join('')}}}`;
    try {
      await send({ kind: 'backup_part', upload: st.id, fileName: st.fileName, tier: st.tier, date: st.date, n: st.n, data });
    } catch (e) {
      if (st.n === 0 && /Unknown request/i.test(String((e && e.message) || e))) throw Object.assign(new Error('old cloud script'), { oldScript: true });
      throw e;
    }
    st = { ...st, n: st.n + 1, t: ti, r };
    setSetting(UPLOAD_KEY, JSON.stringify(st));
    pieces = []; bytes = 0;
  };
  try {
    for (let ti = st.t; ti < tables.length; ti += 1) {
      const t = tables[ti];
      const after = ti === st.t ? st.r : null;
      const startTable = () => { pieces.push(`${pieces.length ? ',' : ''}${JSON.stringify(t)}:[`); open = t; };
      if (after === null) startTable(); // an empty table still shows in the backup (as in one file)
      sizer.reset();
      const it = tableSlices(t, sizer.size, after);
      let t0 = Date.now();
      for (let cur = it.next(); !cur.done; cur = it.next()) {
        const rows = cur.value;
        if (open === null) startTable();
        let firstRow = pieces[pieces.length - 1].endsWith('[');
        for (const r of rows) { const x = JSON.stringify(dumpRow(t, r)); pieces.push(firstRow ? x : `,${x}`); bytes += x.length + 1; firstRow = false; }
        st.rows = (st.rows || 0) + rows.length;
        sizer.took(Date.now() - t0);
        if (bytes >= partBytes) await sendPart(ti, rows.last);
        if (onProgress) { try { onProgress({ table: t, rows: st.rows, tables: tables.length, done: ti, parts: st.n }); } catch (e) { /* only a note */ } }
        await pause();
        t0 = Date.now();
      }
      if (open !== null) { pieces.push(']'); open = null; }
    }
    if (pieces.length || st.n === 0) await sendPart(tables.length, null);
    const meta = { app: 'Easy Buys', made: st.made, device: deviceId(), tables: tables.length, parts: st.n, rows: st.rows };
    const r = await send({ kind: 'backup_done', upload: st.id, fileName: st.fileName, tier: st.tier, date: st.date, parts: st.n, meta, head: head || undefined, manifest: manifest || undefined });
    setSetting(UPLOAD_KEY, '');
    return { ...(r || {}), parts: st.n, rows: st.rows };
  } catch (e) {
    if (!e || !e.oldScript) throw e;
    // an older cloud script: the whole backup in one go (as before 1.0.0)
    setSetting(UPLOAD_KEY, '');
    const one = whole || (async () => send({ kind: 'backup', tier: tier === 'plain' ? undefined : tier, date, fileName: name, data: await dumpDatabaseText({ head, pause }), manifest: manifest || undefined }));
    const r = await one();
    return { ...(r || {}), parts: 0, whole: true };
  }
}
// A backup kept in Drive, as one object (the parts of a backup made in parts put back together).
export async function fetchDriveBackup(id, { call = (b) => cloudCall(b, 300000) } = {}) {
  const r = await call({ kind: 'backup_get', id });
  const data = JSON.parse((r && r.text) || '{}');
  if (!data || !Array.isArray(data._parts)) return data;
  const { _parts, _upload, ...out } = data;
  for (let n = 0; n < _parts.length; n += 1) {
    const p = await call({ kind: 'backup_get_part', id, n });
    const part = JSON.parse((p && p.text) || '{}');
    if (!part || part._part !== n || !part.tables) throw Object.assign(new Error(`Part ${n + 1} of this backup is missing or damaged in Google Drive.`), { isAppError: true });
    for (const [t, rows] of Object.entries(part.tables)) out[t] = out[t] ? out[t].concat(rows) : rows;
  }
  return out;
}

// Put back the shared records from a backup file (owner or admin only, from Admin). Records in the backup replace the
// same records here and are sent to the cloud again; nothing else is deleted. Logins and device settings are not
// touched, the change history is never replaced (it only grows), and records in a closed month are left as they are.
// The restore itself is written in the change history.
export const RESTORE_SKIP = ['users', 'settings', 'shared_settings', 'audit_log', 'alert_log', 'po_versions', 'tax_return_versions', 'roster_changes', 'inv_cost_changes', 'bin_records', 'bin_parts'];
export function restoreBackup(user, data, fileName = '') {
  requireTop(user, 'restore a backup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !(actsAsOwner(user) || ['owner', 'admin'].includes(user.role))) throw new AppError('Only the owner or an admin can restore a backup.');
  if (!data || typeof data !== 'object' || Array.isArray(data) || !data._meta) throw new AppError('This is not an Easy Buys backup file.');
  let n = 0;
  let closed = 0;
  const skip = new Set(RESTORE_SKIP);
  let inClosed = () => false;
  try {
    const lock = require('../services/lock.js').lockDate();
    const B = require('../services/bin.js');
    if (lock && B.inClosedMonth) inClosed = (t, row) => B.inClosedMonth(t, row, lock);
  } catch (e) { inClosed = () => false; }
  db().transaction(() => {
    for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
      if (skip.has(t) || !Array.isArray(data[t])) continue;
      const cols = db().all(`PRAGMA table_info(${t})`).map((c) => c.name);
      for (const row of data[t]) {
        if (!row || typeof row !== 'object') continue;
        // 1.0.0 hardening (audit M8): restored rows keep their own time stamps (never "now"), so a restore can never
        // overwrite a newer record – here or on another device (the cloud keeps the newest version).
        // (a row with no time of its own – a hand-made file – is put back as now)
        const r2 = { ...row, ...(cols.includes('updated_at') && !row.updated_at ? { updated_at: stamp() } : {}) };
        const keys = Object.keys(r2).filter((k) => cols.includes(k) && k !== 'sync_status');
        if (!keys.length || r2[cfg.key] === undefined) continue;
        // a closed month: neither the copy in the backup nor the record here may change
        let here = null;
        try { here = db().get(`SELECT * FROM ${t} WHERE ${cfg.key} = ?`, [r2[cfg.key]]); } catch (e) { here = null; }
        if (inClosed(t, r2) || (here && inClosed(t, here))) { closed += 1; continue; }
        if (here && row.updated_at && cols.includes('updated_at') && String(here.updated_at || '') >= String(row.updated_at)) continue; // this device's copy is as new or newer
        db().run(`INSERT OR REPLACE INTO ${t} (${keys.join(', ')}, sync_status) VALUES (${keys.map(() => '?').join(', ')}, 'pending')`, keys.map((k) => r2[k]));
        n += 1;
      }
    }
    const name = String(fileName || (data._meta && data._meta.made ? `backup made ${data._meta.made}` : 'a backup file')).slice(0, 120);
    audit({ user, action: `Backup restored from ${name}`, table: 'backup', recordUid: name, after: { records: n, leftInClosedMonths: closed } });
  });
  return n;
  });
}
export async function backupNow() {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    const d = dateStr();
    // a backup cut off part way goes on where it stopped (same file)
    const was = backupUploadState();
    const fileName = was && was.tier === 'plain' ? was.fileName : `backup-${d}-${stamp().slice(11, 16).replace(':', '')}.json`;
    await uploadBackupInParts({ tier: 'plain', date: was && was.tier === 'plain' ? was.date : d, fileName,
      whole: async () => post({ kind: 'backup', fileName, data: await dumpDatabaseText() }, 300000) });
    setSetting('last_backup_at', stamp());
    return { ok: true, message: 'Backed up to Google Drive (Easy Buys › Backups).' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

function addPhotoUrl(table, uid, url) {
  let row = null;
  try { row = db().get(`SELECT photo_urls FROM ${table} WHERE uid = ?`, [uid]); } catch (e) { return; }
  if (!row) return;
  let list = [];
  try { list = JSON.parse(row.photo_urls || '[]'); } catch (e) { list = []; }
  if (!list.includes(url)) list.push(url);
  db().run(`UPDATE ${table} SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
}

// Ask the cloud to read an invoice's photos and fill in the invoice. Returns { ok, message }.
// 1.0.0 the AI (Google Gemini in the owner's Apps Script) first – photos and PDFs; Google's text reading (OCR) when
// the cloud has no AI key or the AI fails.
async function readInvoice(invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText, listSuppliers, apRules } = require('../modules/payables/service.js');
  const pics = listPhotos('invoice', invoiceUid).slice(0, 6);
  const files = [];
  const pdf = (u) => /(\.pdf(\?|#|$)|^data:application\/pdf)/i.test(String(u || ''));
  for (const ph of pics) if (await fileExists(ph.uri)) files.push({ mimeType: pdf(ph.uri) ? 'application/pdf' : 'image/jpeg', data: await fileBase64(ph.uri) });
  if (!files.length) return { ok: false, message: 'There is no photo of this invoice on this device.' };
  let aiWhy = '';
  try {
    const AI = require('../services/invoiceAi.js');
    const a = await post({ kind: 'invoice_ai', files, hints: AI.aiHints(listSuppliers(), (Number(apRules().vatRate) || 12.5) / 100) }, 170000);
    if (a && a.ok && a.invoice) {
      const ai = AI.cleanAi(a.invoice, { today: dateStr() });
      const inv = applyReadText(invoiceUid, AI.aiToText(ai));
      // Release 06: the lines go on the supplier's product list (paired with the products)
      try { if (inv && inv.supplier_uid && ai.lines && ai.lines.length) require('../modules/payables/service.js').keepInvoiceLines(null, inv.supplier_uid, inv.supplier_name, inv.invoice_date, AI.aiItemLines(ai), 'invoice'); } catch (e) { /* the invoice is read anyway */ }
      return { ok: true, invoice: inv, engine: 'ai', message: inv && inv.total ? 'Read by AI – please check the figures.' : 'Read by AI, but the total was not found. Please type it.' };
    }
  } catch (e) {
    const m = e && e.message ? e.message : String(e);
    if (/network|fetch|abort|timed/i.test(m) || isBusy(e)) throw e; // no internet / the cloud busy: tried again later
    aiWhy = /NO_AI_KEY/.test(m) ? '' : ` (the AI could not read it: ${m.replace(/^AI_ERROR:\s*/, '')})`;
  }
  const images = files.filter((f) => f.mimeType !== 'application/pdf');
  if (!images.length) return { ok: false, message: `A PDF is read by the AI in the cloud only${aiWhy || ' – switch the AI on (Script properties › GEMINI_KEY)'}. Please type the details.` };
  const r = await post({ kind: 'ocr', files: images }, 180000);
  if (r.off) {
    db().run("UPDATE ap_invoices SET ocr_status = 'type', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      ['Reading photos is not switched on in the Google cloud yet. Please type the details.', stamp(), deviceId(), invoiceUid]);
    return { ok: false, message: "Google's photo reading is not switched on yet. One-time step: in the Google Apps Script project click Services ➕ › Drive API › Add, then Deploy › Manage deployments › New version." };
  }
  const inv = applyReadText(invoiceUid, r.text || '');
  if (!r.text) return { ok: false, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  return { ok: true, invoice: inv, engine: 'cloud', message: `${inv && inv.total ? 'Read by Google (text only) – please check the figures.' : 'Read by Google, but the total was not found. Please type it.'}${aiWhy}` };
}

// "Read this photo now" button: straight away, not waiting for the next sync.
// Admin: give the cloud the Viber Channel token (kept only in the cloud) and send a test message.
// v3.9.8 web checks after a sync: never awaited by the sync, never two rounds at once, 90 s limit per check.
let webChecksBusy = false;
const limit = (p, ms) => Promise.race([Promise.resolve().then(p), new Promise((res) => setTimeout(res, ms))]);
export function autoProblemReport(now = Date.now()) {
  if (isTrainingNow()) return false;
  const E = require('../services/errorLog.js');
  const since = getSetting('auto_report_since', '') || '';
  // (errors in the same second as the last one reported are told apart by their message)
  let seen = [];
  try { seen = JSON.parse(getSetting('auto_report_seen', '[]') || '[]'); } catch (e) { seen = []; }
  const key = (e) => `${e.at}|${e.message}`;
  const errs = E.listErrors(200).filter((e) => e.device === deviceName() && (e.at > since || (e.at === since && !seen.includes(key(e)))));
  if (!errs.length) return false;
  const last = Number(getSetting('auto_report_ms', '0')) || 0;
  const fatal = errs.some((e) => e.fatal || /closed|crash/i.test(String(e.message || '')));
  if (!fatal && now - last < 12 * 3600000) return false;
  const text = `${errs.length} new problem${errs.length === 1 ? '' : 's'} since ${since || 'the last report'}.\n\n${E.problemReport()}`;
  enqueue('support_email', { subject: `Easy Buys problem report (automatic) – v${APP_VERSION} – ${deviceName()}`, text });
  const newest = errs[0].at;
  const same = E.listErrors(200).filter((e) => e.device === deviceName() && e.at === newest).map(key);
  setSetting('auto_report_since', newest);
  setSetting('auto_report_seen', JSON.stringify(same.slice(0, 50)));
  setSetting('auto_report_ms', String(now));
  return true;
}
const isTrainingNow = () => { try { return require('../services/trainingFlag.js').isTraining(); } catch (e) { return false; } };
export function runWebChecks() {
  if (webChecksBusy) return;
  webChecksBusy = true;
  (async () => {
    try { await limit(() => require('../modules/inventory/fccc.js').checkFccc(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../modules/inventory/lpg.js').checkLpg(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../modules/inventory/lpg.js').checkFuel(), 90000); } catch (e) { /* next round */ }
    try { await limit(() => require('../services/utilityBills.js').checkWaterBills(), 90000); } catch (e) { /* next round */ }
  })().finally(() => { webChecksBusy = false; });
}
export async function setupViberChannel(token, oldToken, shopCode) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Link this device to the Easy Buys cloud first.' };
  try {
    // v3.9.4 the Viber token travels as viberToken: "token" is this device's own pass to the cloud (sending the Viber
    // token there made the cloud say "This device is not linked any more").
    // v3.9.6 ask the cloud which script it runs now (the version was only noted when this device sent the dashboard,
    // so a freshly pasted script could still be taken for the old one).
    if (Number(getSetting('cloud_script_version', '0')) < 8) {
      try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); } catch (e) { /* the check below says what to do */ }
    }
    if (shopCode && Number(getSetting('cloud_script_version', '0')) < 9) {
      try { const p = await post({ kind: 'ping' }, 30000); if (p && p.version) setSetting('cloud_script_version', String(p.version)); } catch (e) { /* below */ }
      if (Number(getSetting('cloud_script_version', '0')) < 9) return { ok: false, message: 'A Viber Channel for each shop needs the new cloud script (version 9). Paste it, then Deploy › Manage deployments › ✏️ › Version: New version › Deploy. Then try again.' };
    }
    if (Number(getSetting('cloud_script_version', '0')) < 8) return { ok: false, message: `The cloud still runs script version ${getSetting('cloud_script_version', '?') || '?'}. Paste the new cloud script (version 8), then Deploy › Manage deployments › ✏️ › Version: New version › Deploy. Then try again.` };
    const r = await post({ kind: 'viber_setup', viberToken: String(token || '').trim(), oldToken: String(oldToken || '').trim(), selfUrl: getSettings().cloudUrl, shopCode: shopCode || undefined }, 45000);
    if (r.ok) {
      // v3.9.8 remember which shops have their own channel (the set-up steps count it; the token itself stays in the cloud).
      try { const S = require('../services/core.js'); const m = { ...(S.getShared('viber_channels', {}) || {}) }; m[shopCode || 'MAIN'] = stamp(); S.setShared('viber_channels', m); } catch (e) { /* only a note */ }
    }
    return r.ok ? { ok: true, message: r.message || 'Viber Channel connected – a test message was sent.' } : { ok: false, message: r.error || 'Viber did not accept the token.' };
  } catch (e) { return { ok: false, message: e.message || String(e) }; }
}

// Bank / M-PAiSA statements (v3.5): Google reads the text of a PDF or a screenshot. files: [{ mimeType, data (base64) }].
export async function readTextNow(files) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'Reading a PDF or photo needs the Easy Buys cloud (this device is not linked). Copy the text from the PDF and paste it instead.' };
  try {
    const r = await post({ kind: 'ocr', files: (files || []).slice(0, 6) }, 180000);
    if (r.off) return { ok: false, message: "Google's reading is not switched on in the cloud yet. Paste the statement text instead." };
    return r.text ? { ok: true, text: r.text } : { ok: false, message: 'Google could not read any text. Try the CSV / Excel file, or paste the text.' };
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. Reading a PDF or screenshot needs internet – or paste the text.' : m };
  }
}

export async function readInvoiceNow(invoiceUid) {
  if (!getSettings().cloudUrl) return { ok: false, message: 'This device is not linked to the Easy Buys cloud yet (Admin › Online & email, or Link to Easy Buys). Photos are read by Google when online.' };
  try {
    return await readInvoice(invoiceUid);
  } catch (e) {
    const m = e.message || String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now. It will be read by itself when the device is back online.' : m };
  }
}

async function handle(item) {
  const s = getSettings();
  const p = item.payload;
  if (item.kind === 'report') {
    const rep = shiftReport(p.shiftId);
    if (!rep) return;
    const pdf = await reportPdf(rep);
    const xlsx = await reportXlsx(rep);
    const sh = getShift(p.shiftId);
    await post({
      kind: 'report', emails: recipientsFor('shift_report', p), subject: `${s.bakeryName} – Shift report ${sh.shift_date} ${sh.shift_name} (${sh.code})`,
      html: pdf.html, fileName: rep.fileName, pdf: pdf.base64, xlsx: xlsx.base64, month: sh.shift_date.slice(0, 7), shiftCode: sh.code,
      summary: rep.summary, ...recordsPlace(docPlace({ date: sh.shift_date, kind: 'Shift report', party: s.bakeryName || 'Bakery', number: sh.code, typeFolder: 'Shift reports' })),
    }, 180000);
    withSystem(() => markReportSent(p.shiftId));
  } else if (item.kind === 'po') {
    const doc = purchaseOrderDoc(p.poId);
    if (!doc) return;
    const pdf = await reportPdf(doc);
    await post({
      kind: 'po', emails: recipientsFor('bakery_po', p), subject: `${s.bakeryName} – Purchase order ${doc.po.po_no} (${doc.po.supplier || 'supplier'})`,
      html: pdf.html, fileName: doc.fileName, pdf: pdf.base64, month: doc.po.created_at.slice(0, 7), supplierEmail: doc.po.supplier_email || '',
      ...recordsPlace(poPlace({ poNo: doc.po.po_no, supplier: doc.po.supplier, date: doc.po.created_at })),
    }, 120000);
    withSystem(() => markPoSent(p.poId));
  } else if (item.kind === 'acct_pack') {
    const to = recipientsFor('accountant_pack', p);
    if (!to.length) return;
    const rep = accountantPack(p.from, p.to);
    const xlsx = await reportXlsx(rep);
    await post({ kind: 'pack_email', subject: `Easy Buys – accountant pack ${p.from} to ${p.to}`, text: `Hello,\n\nThe Easy Buys accountant pack for ${p.from} to ${p.to} is attached (Excel).\n\nEasy Buys Shopping Centre`,
      attachments: [{ b64: xlsx.base64, mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', name: `${rep.fileName}.xlsx` }] }, 180000);
  } else if (item.kind === 'photo') {
    const ph = getPhoto(p.photoId);
    if (!ph || !(await fileExists(ph.uri))) return;
    const data = await fileBase64(ph.uri);
    const isPdf = /(\.pdf(\?|#|$)|^data:application\/pdf)/i.test(String(ph.uri || '')); // 1.0.0 an invoice PDF keeps its .pdf name; mime is sent for the cloud's 'photo' case to use (it saves JPEG type for now)
    // 1.0.0 (owner, 2 Nov): invoices, cheques / payments, deposits and Z reports get a readable name and go in
    // Records › month › shop (services/photoNames.js); the cloud keeps the old place for everything else (and old scripts).
    let place = null;
    try { place = photoPlaceFromDb((sql, args) => db().get(sql, args), ph, isPdf ? 'pdf' : 'jpg', getShared('records_layout', null)); } catch (e) { place = null; }
    const r = await post({ kind: 'photo', refType: ph.ref_type, refId: ph.ref_id, data, fileName: `${ph.ref_type}-${ph.ref_id}-${ph.id}.${isPdf ? 'pdf' : 'jpg'}`, mime: isPdf ? 'application/pdf' : undefined, month: ph.created_at.slice(0, 7),
      ...recordsPlace(place) }, 180000);
    if (r.url) {
      withSystem(() => setPhotoCloudUrl(ph.id, r.url));
      // Easy Buys modules: put the Drive link on the record so every device can open the photo.
      const link = { punch: 'punches', leave: 'leave_requests' }[ph.ref_type];
      if (link) db().run(`UPDATE ${link} SET photo_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.url, stamp(), deviceId(), ph.ref_id]);
      // Records with several photos (invoice pages, receipts, Z reports) keep a list of links.
      const many = { invoice: 'ap_invoices', payment: 'ap_payments', till: 'till_counts', deposit: 'deposits', cash: 'cash_moves', snap: 'money_snaps', receipt: 'inv_receipts', stat: 'stat_payments', asset: 'fixed_assets', dlcheque: 'dl_deliveries', statement: 'supplier_statements', applicant: 'applicants', charge: 'staff_charges', credit_settle: 'credit_settlements', regreceipt: 'regular_receipts', owner: 'owner_moves' }[ph.ref_type];
      if (many) addPhotoUrl(many, ph.ref_id, r.url);
    }
  } else if (item.kind === 'doc_upload') {
    // A document goes to Google Drive › Easy Buys › Documents › <type folder> [› year › month] (v3.5: checked, safe to retry).
    await uploadDocument(p.uid);
  } else if (item.kind === 'email' || item.kind === 'contract_email') {
    let attachments = [];
    if (item.kind === 'contract_email') {
      // The company's own PDF (signed and stamped) when the contract was made from it; otherwise the app's contract.
      const signed = p.docUid ? getDocument(p.docUid) : null;
      const b64 = signed ? await documentBase64(signed) : (await reportPdf(contractReport(p.contractUid))).base64;
      attachments = [{ name: `${p.subject.replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64, mime: 'application/pdf' }];
    }
    const r = await post({ kind: 'email', to: p.to, subject: p.subject, text: p.text, attachments }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'delivery_email' || item.kind === 'delivery_drive') {
    // 1.0.0 build 25: the signed delivery note – to the customer's address on the account (the cloud checks it is
    // one), and a copy in Drive (Records › month › Outbound › customer › Deliveries, or month › shop › Deliveries).
    const D = require('../modules/trade/deliveries.js');
    const r = D.getDelivery(p.uid);
    if (!r || r.status !== 'delivered') return;
    const pdf = await reportPdf(D.deliveryReport(p.uid));
    if (item.kind === 'delivery_email') {
      const res = await post({ kind: 'customer_email', to: p.to, subject: `Delivery – invoice ${r.invoice_no || ''} – ${r.customer_name}`,
        text: `Hello,\n\nPlease find the signed delivery note for invoice ${r.invoice_no || ''} delivered ${String(r.delivered_at).slice(0, 16)}, received by ${r.receiver_name || ''}.\n\nThank you.`,
        attachments: [{ name: `Delivery ${String(r.invoice_no || '').replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64: pdf.base64, mime: 'application/pdf' }] }, 120000);
      if (res && res.ok === false && res.error) throw new Error(res.error);
      withSystem(() => D.markEmailed(p.uid));
    } else {
      const shop = r.shop_code ? db().get('SELECT code, name FROM shops WHERE code = ?', [r.shop_code]) : null;
      const place = deliveryPlace(r, shop, getShared('records_layout', null));
      if (!place) return;
      const res = await post({ kind: 'delivery_save', data: pdf.base64, niceName: place.fileName, monthFolder: place.monthFolder, shopFolder: place.shopFolder, typeFolder: 'Deliveries', ...(place.folders ? { folders: place.folders } : {}) }, 180000);
      if (res && res.ok === false) throw new Error(res.error || 'The delivery note was not saved (update the cloud script to 25).');
    }
  } else if (item.kind === 'payslip_drive') {
    // 1.0.0 (owner, 2 Nov): a copy of each released payslip in Drive › Easy Buys › Records › month › Payslips.
    const l = db().get('SELECT l.uid, l.name, r.week_end, r.version FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid WHERE l.uid = ?', [p.lineUid]);
    const place = l ? payslipPlace({ weekEnd: l.week_end, name: l.name, version: l.version }) : null;
    if (!place) return;
    const { payslipReport } = require('../modules/payroll/payslip.js');
    const pdf = await reportPdf(payslipReport(p.lineUid));
    const r = await post({ kind: 'payslip_save', data: pdf.base64, fileName: place.fileName, monthFolder: place.monthFolder, typeFolder: place.typeFolder }, 180000);
    if (r && r.ok === false) throw new Error(r.error || 'The payslip copy was not saved (update the cloud script to 16).');
  } else if (item.kind === 'payslip_email') {
    // v3.5 pay sign-off: the signed payslip as a PDF to the person's own email address (Code.gs checks the address).
    const { payslipReport } = require('../modules/payroll/payslip.js');
    const pdf = await reportPdf(payslipReport(p.lineUid, { staff: true })); // build 19: the staff copy (hours, pay, taken off, net)
    const r = await post({ kind: 'payslip_email', to: p.to, subject: p.subject, text: p.text, attachments: [{ name: `${String(p.subject).replace(/[^A-Za-z0-9 _-]/g, '')}.pdf`, b64: pdf.base64, mime: 'application/pdf' }] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'support_email') {
    // Problem report to the app's support person. The cloud script decides the address (a device cannot choose it).
    const r = await post({ kind: 'support_email', subject: p.subject, text: p.text }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'calendar') {
    const r = await post({ kind: 'calendar', ...p }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'myday_in') {
    // v3.5 My day: meetings for one day from the Easy Buys Google account's calendar.
    const r = await post({ kind: 'myday_events', date: p.date }, 60000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
    require('../modules/myday/service.js').applyGoogleEvents(p.ownerUid, p.date, r.events || []);
  } else if (item.kind === 'myday_out') {
    // v3.5 My day: the day's app tasks → the "Easy Buys – My day" calendar.
    const r = await post({ kind: 'myday_out', date: p.date, calendar: p.calendar, items: p.items || [] }, 120000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'viber') {
    // v3.9.4 the photo (invoice, cheque stub) or the PO's PDF goes with the post (cloud script 7 or newer).
    const files = [];
    if (p.attach && Number(getSetting('cloud_script_version', '0')) >= 7) {
      try {
        for (const uri of (p.attach.photos || []).slice(0, 3)) {
          if (await fileExists(uri)) files.push({ name: `photo-${files.length + 1}.jpg`, mime: 'image/jpeg', data: await fileBase64(uri) });
        }
        if (p.attach.poUid) {
          const R = require('../modules/inventory/reports.js');
          const rep = R.poReport(p.attach.poUid);
          const pdf = await reportPdf(rep);
          files.push({ name: `${rep.fileName || 'Purchase-order'}.pdf`, mime: 'application/pdf', data: pdf.base64 });
        }
      } catch (e) { /* the text still goes; the file is left out */ }
    }
    // 1.0.0 build 1: business-wide money alerts go only to the owner / admin channel (cloud script 12); a shop's alerts
    // to that shop's channel (the main channel until the shop has its own).
    const owner = !!p.owner || OWNER_EVENTS.includes(p.event);
    // 1.0.0 build 10: the automatic posts carry a once key – the cloud posts each once, whichever device made it
    const base = { kind: 'viber', text: p.text, shopCode: owner ? undefined : p.shopCode || undefined, owner: owner || undefined, once: p.once || undefined, forget: p.forget || undefined };
    const r = await post(files.length ? { ...base, files } : base, files.length ? 180000 : 45000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } else if (item.kind === 'ocr') {
    await readInvoice(p.invoiceUid);
  } else if (item.kind === 'archive') {
    // v3.9 year-end archive: the whole business as it was, kept in Drive › Backups › Manual (never pruned).
    const manifest = JSON.stringify({ archive: p.meta, files: backupManifest() });
    const r = await uploadBackupInParts({ tier: 'manual', date: p.date, fileName: p.fileName, head: { _archive: p.meta }, manifest,
      whole: async () => post({ kind: 'backup', tier: 'manual', date: p.date, fileName: p.fileName, data: await dumpDatabaseText({ head: { _archive: p.meta } }), manifest }, 300000) });
    if (r && r.ok === false && r.error) throw new Error(r.error);
    withSystem(() => require('../services/yearArchive.js').archiveSent(p.year, r || {}));
  } else if (item.kind === 'backup') {
    // v3.5: kept as a daily backup (30 days) and the first of each month as a monthly one (12 months), with a file
    // manifest. Older cloud scripts ignore the extra fields and keep it in Backups as before.
    const manifest = JSON.stringify(backupManifest());
    // the backup job kept while the parts go up (a long backup)
    await uploadBackupInParts({ tier: p.tier || 'daily', date: p.date, fileName: `backup-${p.date}.json`, manifest,
      send: async (b) => { try { await renewLease('backup', { post: leasePost }); } catch (e) { /* the backup goes on */ } return post(b, 300000); },
      whole: async () => post({ kind: 'backup', tier: p.tier || 'daily', date: p.date, fileName: `backup-${p.date}.json`, data: await dumpDatabaseText(), manifest }, 300000) });
    setSetting('last_backup_at', stamp());
  }
}

// One sync round: send the live status, then work through the outbox.
// Shared records (staff, punches, timesheets, leave...): send ours, then fetch other devices' changes.
// 1.0.0 build 10 (go-live): big pages get a longer time limit than small calls; a busy cloud is asked again within this
// sync (with a growing wait); a page that ran out of time goes again as a smaller one.
export const PUSH_PAGE = 200;
export const BIG_MS = 150000;   // a push or pull page
export const SMALL_MS = 45000;  // ping, devices, lease
// review (3 Nov): a hung connection kept one sync going 7–10 minutes (150 s × smaller and smaller pages) and "Sync now"
// could not be pressed meanwhile. Now: after one time-out the smaller page gets a shorter limit (60 s); two time-outs
// in a row = the connection (the sync stops: "Slow or no connection – trying again in a minute"); and a whole sync
// stops starting new pages after about 3 minutes (the rest goes with the next sync, a minute later).
export const AFTER_TIMEOUT_MS = 60000;
// Release 10: the website leaves the history sections out of its download (cloud script 43) – the change history,
// Aronium's raw feed, truck positions, alerts, verify trails, product watch, deleted bin, old AI reads. They are not
// needed to open any page; leaving them out makes the website open in seconds.
export const WEB_SKIP = ['audit_log', 'aronium_feed', 'dl_points', 'dl_events', 'alert_log', 'verify_trail', 'product_changes', 'inv_cost_changes', 'bin_parts', 'bin_records', 'money_snaps', 'invoice_reads'];
// Release 25 (owner, 14 Nov: "it still seems like it is syncing and downloading – not everything is showing when opened"):
// whether the last download got to the end (the website waits on "Getting the business" until it has).
let pullDone = false;
export function pullFinished() { return pullDone; }
function webSkip() { try { return require('react-native').Platform.OS === 'web' ? WEB_SKIP : undefined; } catch (e) { return undefined; } }
export const SYNC_CAP_MS = 180000;
export const MIN_PAGE_MS = 20000;
export const syncClock = { now: () => Date.now() };
let syncDeadline = 0;
// the time limit for the next page: never past the end of this sync's 3 minutes (at least 20 s)
const pageMs = (base) => (syncDeadline ? Math.max(MIN_PAGE_MS, Math.min(base, syncDeadline - syncClock.now())) : base);
const pastCap = () => !!syncDeadline && syncClock.now() >= syncDeadline;
const slowStop = () => Object.assign(new Error(SLOW_MESSAGE), { busy: true, slow: true, stop: true });
// 1.0.0 build 17 (owner, 7 Nov: "when it's syncing can it show what it's syncing?"): what is going each way, by its
// part of the app (Staff, Time Clock, Inventory …) – on the sync bar while it runs, and on Sync status afterwards.
let syncWhat = { sent: {}, got: {} };
export function bySection(list) {
  const out = {};
  for (const r of list || []) {
    const sec = (SYNC_TABLES[r.t] && SYNC_TABLES[r.t].section) || 'Other';
    out[sec] = (out[sec] || 0) + 1;
  }
  return out;
}
const addTo = (into, counts) => { for (const [k, n] of Object.entries(counts || {})) into[k] = (into[k] || 0) + n; return into; };
// { Inventory: 120, Invoices: 3, Staff: 1, Leave: 1 } → "Inventory 120 · Invoices 3 · Staff 1 · 1 more"
export function whatText(counts, max = 3) {
  const list = Object.entries(counts || {}).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]);
  if (!list.length) return '';
  const shown = list.slice(0, max).map(([k, n]) => `${k} ${Number(n).toLocaleString('en-US')}`);
  const rest = list.length - max;
  return shown.join(' · ') + (rest > 0 ? ` · ${rest} more` : '');
}
// "Receiving 1,200 of 2,850…"
export const receivingText = (got, all) => `Receiving ${Number(got).toLocaleString('en-US')} of ${Number(all).toLocaleString('en-US')}…`;
const retryNote = (what) => (n) => setSyncState({ progress: `The cloud is busy – trying again (${what}, ${n})…` });
const leasePost = (b) => postRetry(b, SMALL_MS, { tries: 2 });
async function pushRecords(rounds = 20) {
  let sent = 0;
  let page = PUSH_PAGE;
  let cuts = 0;
  let timedOut = false; // the last page ran out of time
  for (let round = 0; round < rounds; round++) {
    if (pastCap()) break; // the rest goes with the next sync
    const batch = pendingRecords(page);
    if (!batch.length) break;
    setSyncState({ progress: `Sending ${batch.length.toLocaleString('en-US')}: ${whatText(bySection(batch))}` });
    let r;
    try {
      r = await postRetry({ kind: 'push', records: batch }, pageMs(timedOut ? AFTER_TIMEOUT_MS : BIG_MS), { onRetry: retryNote('sending'), retrySlow: false });
    } catch (e) {
      // our time limit ran out (a slow line): once – again as a smaller page (200 → 100 → 50) with a shorter limit;
      // sending the same records twice is harmless (the cloud keeps the newest). Twice in a row: the connection.
      if (!isBusy(e) || !e.slow) throw e;
      if (timedOut || page <= 50 || cuts >= 3) throw slowStop();
      page = Math.max(50, Math.floor(page / 2));
      cuts += 1;
      timedOut = true;
      round -= 1;
      continue;
    }
    timedOut = false;
    // 1.0.0 build 1: a locked change the cloud refused for want of an owner / admin login stays waiting here (it goes
    // when the owner or admin is logged in); everything else is done.
    const wait = new Set((r.rejected || []).filter((x) => x.code === 'LOGIN').map((x) => `${x.t}|${x.k}`));
    const done = batch.filter((x) => !wait.has(`${x.t}|${x.k}`));
    withSystem(() => markRecordsSent(done));
    sent += done.length;
    addTo(syncWhat.sent, bySection(done));
    if (r.rejected && r.rejected.length) setSetting('last_rejected', JSON.stringify(r.rejected.map((x) => ({ t: x.t, k: x.k, why: x.why, code: x.code })).slice(0, 20)));
    if (wait.size && wait.size === batch.length) break; // nothing more can go now
  }
  return sent;
}
// 1.0.0 build 16: access is "A|S1|manager" (admin device, shop, role). Wider: more of the business than before.
const ROLE_RANK = { staff: 1, bakery: 1, manager: 2, owner: 3, '': 3 };
export function widerRole(was, now) {
  const r = (a) => { const p = String(a || '').split('|'); return { admin: p[0] === 'A', role: p.length > 2 ? p[2] : '' }; };
  const a = r(was); const b = r(now);
  return (ROLE_RANK[b.role] || 3) > (ROLE_RANK[a.role] || 3) || (b.admin && !a.admin);
}
export async function refreshUsers(access) {
  const r = await postRetry({ kind: 'users_all' }, SMALL_MS);
  const list = (r && r.records) || [];
  const n = list.length ? withSystem(() => applyPulledRecords(list)) : 0;
  setSetting('users_access', String(r && r.access ? r.access : access || ''));
  return n;
}
async function syncRecords() {
  // 1.0.0 build 1: the business PIN salt before sending (a PIN just set goes with its proof made with it).
  if (!getSetting('pin_salt_cloud', '')) {
    try { const p = await postRetry({ kind: 'ping' }, SMALL_MS); if (p && p.version) setSetting('cloud_script_version', String(p.version)); if (p && p.pinSalt) { withSystem(() => require('../services/pins.js').adoptCloudSalt(p.pinSalt)); setSetting('pin_salt_cloud', '1'); } } catch (e) { /* the pull below tries */ }
  }
  await ensureSession();
  let sent = await pushRecords();
  let received = 0;
  // 1.0.0 build 10: pages until everything is in, in this one sync ("Receiving 800 of 2853…"); a page that ran out of
  // time is asked again smaller (800 → 400 → 200 …).
  let covered = 0;
  let limit = 0;
  let cuts = 0;
  let timedOut = false;
  let access = null;
  // 1.0.0 build 16 (owner, 7 Nov: "getting a new device hooked on is a hassle"): a new device gets the logins first
  // (one small request), so the PIN pad works while the rest of the business comes in.
  if (pullCursor() === 0 && !getSetting('users_access', '') && Number(getSetting('cloud_script_version', '0')) >= 19) {
    try { received += await refreshUsers(''); } catch (e) { /* they come with the pull */ }
  }
  pullDone = false;
  for (let round = 0; round < 60; round++) {
    if (round > 0 && pastCap()) break; // the rest comes with the next sync (the place is kept)
    let stat = null;
    try { stat = deviceStat(Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox()); } catch (e) { stat = null; }
    let r;
    try {
      r = await postRetry({ kind: 'pull', since: pullCursor(), stat, limit: limit || undefined, skip: webSkip() }, pageMs(timedOut ? AFTER_TIMEOUT_MS : BIG_MS), { onRetry: retryNote('receiving'), retrySlow: false });
    } catch (e) {
      // our time limit ran out: once – the same place again as a smaller page (800 → 400 → 200 → 100) with a shorter
      // limit; twice in a row – the connection: stop (the next sync carries on from the same place)
      if (!isBusy(e) || !e.slow) throw e;
      if (timedOut || (limit && limit <= 100) || cuts >= 4) throw slowStop();
      limit = Math.max(100, Math.floor((limit || 800) / 2));
      cuts += 1;
      timedOut = true;
      continue;
    }
    timedOut = false;
    if (typeof r.page === 'number' && typeof r.left === 'number') {
      covered += r.page;
    }
    if (r.version) setSetting('cloud_script_version', String(r.version));
    if (r.pinSalt) { try { withSystem(() => require('../services/pins.js').adoptCloudSalt(r.pinSalt)); setSetting('pin_salt_cloud', '1'); } catch (e) { /* next round */ } }
    if (r.admin === true || r.admin === false) setSetting('device_is_admin', r.admin ? '1' : '0');
    if (typeof r.access === 'string') access = r.access;
    // 1.0.0 build 16: the device's role (staff and bakery devices take no shared job – services/jobLease.js)
    if (r.deviceRole !== undefined) setSetting('device_role', r.deviceRole || '');
    if (r.procAt !== undefined) setSetting('proc_at', String(r.procAt || '')); // Release 33: when the cloud last processed the till PCs' figures
    // 1.0.0 build 10: new phones waiting for the owner (the owner's / an admin's device asks "Allow …?")
    if (Array.isArray(r.waitingDevices)) setSetting('devices_waiting', JSON.stringify(r.waitingDevices.slice(0, 10)));
    try { withSystem(() => applyControl(r.control)); } catch (e) { /* next round */ }
    if (r.commands && r.commands.length) { try { await runCommands(r.commands, { send: (b) => post(b, 60000) }); } catch (e) { /* next round */ } }
    const list = r.records || [];
    if (list.length) received += withSystem(() => applyPulledRecords(list));
    if (list.length) addTo(syncWhat.got, bySection(list));
    if (typeof r.page === 'number' && typeof r.left === 'number' && r.more) setSyncState({ progress: `${receivingText(covered, covered + r.left)} ${whatText(syncWhat.got)}` });
    else if (list.length) setSyncState({ progress: `Received: ${whatText(syncWhat.got)}` });
    if (typeof r.next === 'number') withSystem(() => setPullCursor(r.next));
    if (!r.more) { pullDone = true; break; }
  }
  // 1.0.0 build 13 (owner, 6 Nov): this device was made an admin device or moved to another shop – every login comes
  // again with the PINs it may now hold (before, the owner's PIN only came with the owner's next change).
  if (access && access !== getSetting('users_access', '')) {
    // 1.0.0 build 16: given a role with more than before (shop → manager → owner): everything is asked for again from
    // the start – what the old role left out comes now (once; the records already here are only checked again).
    const was = getSetting('users_access', '');
    if (was && widerRole(was, access)) { try { withSystem(() => setPullCursor(0)); } catch (e) { /* next sync */ } }
    try { received += await refreshUsers(access); } catch (e) { /* asked again next sync */ }
  }
  // 1.0.0 build 10: which of the one-device jobs are this device's now (any linked device; see services/jobLease.js)
  try { await refreshLeases({ post: leasePost, every: ASK_EVERY_MS }); } catch (e) { /* the last answer stays */ }
  try { withSystem(() => retireSampleLogins()); } catch (e) { /* try again next round */ }
  // Go-live: the owner started fresh on the main tablet – clear the same old records here too (safety copy first).
  try { await applyFresh(freshMarker(), { snapshot: () => snapshotNow('fresh') }); } catch (e) { /* next round */ }
  try { withSystem(() => postBakeryReceipts()); } catch (e) { /* next round */ }
  try { withSystem(() => sendAnswered()); } catch (e) { /* next round */ }
  // Automatic Viber Channel alerts (the device holding the viber job; each once – the cloud checks the once keys too).
  try { if (mayDoJob('viber')) await require('../services/board.js').buildBoardAsync(); } catch (e) { /* worked out below */ }
  try { withSystem(() => autoViberAlerts({ isMain: mayDoJob('viber') })); } catch (e) { /* next round */ }
  // v3.9.8 the FCCC lists and the monthly LPG (gas) prices: looked at on the main tablet every few hours (each
  // check waits 6 hours by itself, and never stops the sync).
  // v3.9.8 the FCCC lists, the monthly LPG (gas) and fuel prices and the water bills: looked at on the main tablet
  // (each check waits its own hours). They run on their own, one round at a time, each with a time limit – a slow
  // website never holds up the sync.
  if (mayDoJob('web')) runWebChecks();
  // v3.9.8 the problem loop: new errors on this device go to support by themselves (at most every 12 hours, at once
  // after a crash), so every problem reaches the person who fixes the app – nobody has to remember to send it.
  // v3.9.8 the app checks itself once a day; anything wrong goes into the problem report just below.
  // 1.0.0 a check at a time with a pause after each (the screens keep answering); saves are the app's own (system)
  try { await require('../services/selfCheck.js').runSelfCheckAsync({ wrap: withSystem }); } catch (e) { /* next round */ }
  // 1.0.0 the full check of a long change history, a slice per round (Home only adds the new entries)
  try { withSystem(() => require('../services/watchdog.js').verifyChainStep()); } catch (e) { /* next round */ }
  try { autoProblemReport(); } catch (e) { /* next round */ }
  // The monthly accountant pack (the device holding the pack job; once a month – the month is kept with the job).
  try {
    const due = packDue({ today: dateStr(), isMain: mayDoJob('pack') });
    if (due && jobMark('pack') === due.month) setSetting('acct_pack_month', due.month); // another device made it
    else if (due) {
      withSystem(() => { if (due.mode === 'auto') enqueue('acct_pack', { from: due.from, to: due.to }); else noteMade('accountant_pack', { from: due.from, to: due.to }, `Accountant pack ${due.month}`); setSetting('acct_pack_month', due.month); });
      await setJobMark('pack', due.month, { post: leasePost });
    }
  } catch (e) { /* next round */ }
  // The device list (for the device warnings), every 30 minutes.
  try {
    const c = cachedDevices();
    if (!c || Date.now() - new Date(String(c.at).replace(' ', 'T')).getTime() > 30 * 60000) { const d = await postRetry({ kind: 'devices' }, SMALL_MS); withSystem(() => cacheDevices(d.devices || [])); }
  } catch (e) { /* next round */ }
  return { sent, received };
}

// Release 07: asked while a sync is running (a live "changed", a save) – one more sync right after it
let syncAgain = false;
export async function syncNow({ force = false } = {}) {
  const s = getSettings();
  if (running && s.cloudUrl) syncAgain = true;
  if (!s.cloudUrl || running || isTraining()) return { skipped: true };
  running = true;
  const syncT0 = Date.now();
  syncDeadline = syncClock.now() + SYNC_CAP_MS;
  let waiting0 = 0;
  try { waiting0 = Object.values(pendingBySection()).reduce((a, b) => a + b, 0) + countPendingOutbox(); } catch (e) { waiting0 = 0; }
  syncWhat = { sent: {}, got: {} };
  setSyncState({ running: true, lastTry: stamp(), progress: waiting0 ? `Sending ${waiting0} item${waiting0 === 1 ? '' : 's'}…` : 'Checking for changes…' });
  let fileError = '';
  let sent = 0;
  let received = 0;
  let error = null;
  let planChanged = 0;
  let linkFresh = false;
  // 1.0.0 build 47: the device linked with the master cloud key (the first "main tablet") swaps it for its own pass,
  // like every other device (cloud script 35+); the master key is then no longer kept on it
  try {
    if (getSetting('cloud_key', '') && !getSetting('cloud_token', '') && Number(getSetting('cloud_script_version', '0')) >= 35) {
      const r = await post({ kind: 'key_to_token' }, 45000);
      if (r && r.ok && r.token) {
        try { const J = require('../services/core.js'); if (!J.getShared('main_tablet_device', '')) J.setShared('main_tablet_device', deviceId()); } catch (e) { /* jobs go by the lease */ }
        setSetting('cloud_token', r.token);
        setSetting('cloud_key', '');
        crumb('sync', 'own pass instead of the cloud key');
        audit({ user: null, action: 'This tablet got its own pass – the master cloud key is no longer kept on it', table: 'settings', recordUid: 'cloud_token' });
      }
    }
  } catch (e) { /* tried again next sync */ }
  try {
    const rec = await syncRecords();
    setSyncState({ progress: 'Fetching changes from the other devices…' });
    sent += rec.sent;
    received = rec.received;
    // v3.9.4 the Aronium link: the main tablet turns what the till PCs sent into sales, End of days and products.
    try {
      const L = require('../modules/aronium/link.js');
      let last = null;
      try { last = JSON.parse(getSetting('aronium_link_last', '') || 'null'); } catch (e) { last = null; }
      const stale = !last || !last.at || minutesBetween(last.at, stamp()) >= 10;
      // v1.0.0 every device makes the sales and End of days (the main tablet also the products, FCCC, credit…)
      if (received > 0 || (last && last.left > 0) || stale) {
        setSyncState({ progress: 'Bringing in the tills\' figures…' });
        // review (3 Nov): the holder of the "link" job asks the cloud again right before the products / suppliers round
        // (an answer older than a minute) – a device that is no longer the holder makes only the sales and End of days
        try { if (mayDoJob('link')) await renewLease('link', { post: leasePost, maxAgeMs: 60000 }); } catch (e) { /* the last answer stays */ }
        const pr = L.processLink();
        if (pr && pr.did && pr.did.length) linkFresh = true;
        // Release 29: an End of day still missing → the shop's till PCs are asked again by themselves (at most every 3 h)
        try { require('../modules/aronium/pullEod.js').autoHeal().catch(() => {}); } catch (e) { /* the next round */ }
      }
    } catch (e) { /* never stops the sync; the next round tries again */ }
    // Release 06 (cloud script 41): the two-way check – every 30 minutes (and right after this update) each table is
    // compared with the cloud; what is missing here is fetched, what the cloud lacks is sent again (next sync).
    try {
      const last = require('../services/records.js').lastTwoWayCheck();
      // the website checks every 10 minutes (the owner works there), phones and tablets every 30
      const every = typeof document !== 'undefined' && typeof window !== 'undefined' ? 10 : 30;
      const due = !last || !last.at || minutesBetween(last.at, stamp()) >= every;
      if (due && Number(getSetting('cloud_script_version', '0')) >= 41 && syncClock.now() < syncDeadline - 60000) {
        setSyncState({ progress: 'Checking every section against the cloud…' });
        const r = await require('../services/records.js').twoWayCheck((b, ms) => post(b, ms));
        received += r.differ.reduce((t, d) => t + (d.fetched || 0), 0);
      }
    } catch (e) { crumb('sync', `two-way check: ${String(e && e.message ? e.message : e).slice(0, 120)}`); }
    const today = dateStr();
    // Nightly full backup: the device holding the backup job (an admin device; the main one first), once a day for the
    // whole business – the day is kept with the job, so a device taking it over does not back up again.
    if (getSetting('last_backup_date') !== today && mayDoJob('backup') && jobMark('backup') !== today && backupDue({ last: getSetting('last_backup_date', ''), main: deviceId() })) {
      withSystem(() => enqueue('backup', { date: today, tier: 'daily' }));
      setSetting('last_backup_date', today);
      try { await setJobMark('backup', today, { post: leasePost }); } catch (e) { /* goes with the next sync */ }
    }
    // v3.9.4 one device sends the online dashboard (see services/board.js), every 2–5 minutes.
    let sendDash = true;
    try {
      const B = require('../services/board.js');
      let isMain = false;
      try { isMain = mayDoJob('link'); } catch (e) { isMain = false; }
      // v3.9.4 new figures (a sale from a till PC, a change on another device): the dashboard goes out straight away
      // (at most every 30 seconds) instead of waiting for its 2–5 minute turn.
      const fresh = linkFresh || received > 0;
      if (fresh) B.boardStale();
      sendDash = withSystem(() => B.shouldSendDashboard({ isMain, fresh }));
    } catch (e) { sendDash = true; }
    // 2 Nov (owner): "I don't even look at the online dashboard … I need this syncing to work" – the dashboard is off
    // unless switched on (shared setting online_dashboard = true); syncs are shorter and lighter without it
    try { if (require('../services/core.js').getShared('online_dashboard', false) !== true) sendDash = false; } catch (e) { sendDash = false; }
    if (sendDash) {
      setSyncState({ progress: 'Updating the online dashboard…' });
      // the board is worked out a part at a time first (the screens keep answering); the snapshot then uses it
      try { await require('../services/board.js').buildBoardAsync(); } catch (e) { /* the snapshot works it out */ }
      // 2 Nov: a refused dashboard update never stops the sync (it used to – records then never went: "Staff 1 waiting",
      // a new login's PIN never reached the other phones)
      let r = {};
      try { r = (await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000)) || {}; setSetting('dash_refused', ''); }
      catch (e) { setSetting('dash_refused', String((e && e.message) || e).slice(0, 200)); r = {}; } // never stops the sync: records and files still go
      if (r && r.version) setSetting('cloud_script_version', String(r.version));
      // Plan changes made on the online dashboard come back with the reply.
      if (r.planEdits && r.planEdits.length) {
        planChanged = withSystem(() => applyOnlinePlans(r.planEdits)); // the app's own work (sync), not a person
        try { await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 60000); } catch (e) { /* next round */ } // confirm to the dashboard straight away
      }
    }
    // v3.9.4 records made during this sync (the dashboard's first build, the till figures, the alerts) go now, not
    // next round, so "All synced" really means nothing is waiting.
    sent += await pushRecords(5);
    const jobs = pendingOutbox(force ? 50 : 10);
    for (const [k, item] of jobs.entries()) {
      if (pastCap()) break; // files and emails carry on with the next sync
      setSyncState({ progress: `Sending files and emails (${k + 1} of ${jobs.length})…` });
      try {
        await handle(item);
        withSystem(() => markOutboxSent(item.id));
        sent += 1;
      } catch (e) {
        withSystem(() => markOutboxFailed(item.id, e.message || e));
        fileError = `${item.kind}: ${e.message || String(e)}`;
        // No internet: stop and try again next round. Anything else (e.g. a bad email address): skip it so it does not hold up the rest.
        if (/network|fetch|abort|timed|offline|Failed to/i.test(fileError) || isBusy(e)) break;
      }
    }
    // 4 Nov (owner: "no good sync for 29 hours"): a file or email that fails is noted on its own (Sync status shows it and
    // it is tried again next round) – it never makes the whole sync count as failed; the records went through.
    setSetting('outbox_last_error', fileError ? `${stamp()} ${fileError}`.slice(0, 300) : '');
    setSetting('last_sync_at', stamp());
    try { await clearOldLocalCopies(); } catch (e) { /* next time */ }
    // v3.9.6 Deleted bin: records more than 90 days in it are gone for good (checked each sync; cheap when none).
    try { withSystem(() => require('../services/bin.js').purgeBin()); } catch (e) { /* next time */ }
  } catch (e) {
    error = e.message || String(e);
  } finally {
    running = false;
    if (syncAgain) { syncAgain = false; setTimeout(() => { syncNow().catch(() => {}); }, 300); }
    syncDeadline = 0;
    setSetting('last_sync_error', error || '');
    if (!error) setSetting('last_sync_ok_at', stamp());
    // what the last sync that moved something sent and received (Sync status shows it)
    if (Object.keys(syncWhat.sent).length || Object.keys(syncWhat.got).length) setSetting('last_sync_what', JSON.stringify({ at: stamp(), sent: syncWhat.sent, got: syncWhat.got }));
    setSyncState({ running: false, error: error || '', lastOk: getSetting('last_sync_ok_at', ''), sent, received, progress: '' });
    crumb('sync', `${waiting0} waiting · sent ${sent} · got ${received} · ${Date.now() - syncT0}ms${error ? ' · ERROR ' + String(error).slice(0, 120) : ' · ok'}`);
  }
  return { sent, received, error, planChanged };
}

export function syncStatus() {
  return {
    configured: !!getSettings().cloudUrl,
    lastOk: getSetting('last_sync_ok_at', ''),
    lastTry: getSetting('last_sync_at', ''),
    error: getSetting('last_sync_error', ''),
  };
}

// ---------------------------------------------------------------- documents kept in Google Drive
// Upload one document: unique upload id (a repeated upload returns the file already in Drive), size + SHA-256 sent
// and checked against what the cloud script got. Status on the document: uploading → verified / failed / login.
export async function uploadDocument(uid) {
  const d0 = getDocument(uid);
  if (!d0 || d0.status !== 'active') return 'skipped';
  if (d0.upload_status === 'verified' && d0.cloud_id) return 'verified';
  if (!d0.path || !(await fileExists(d0.path))) {
    if (!d0.cloud_id) withSystem(() => markUploadFailed(uid, 'The file is not on this device.'));
    return 'missing';
  }
  const d = describeDocument(d0);
  const data = await fileBase64(d0.path);
  const fp = base64Fingerprint(data);
  withSystem(() => markUploading(uid));
  let r;
  try {
    r = await post({ kind: 'file_put', uploadId: uploadIdFor(d0), folder: d0.ref_type, path: d.folder, docType: d.doc_type, access: d.access_class, refUid: d0.ref_uid || '',
      fileName: `${d0.uid}-${String(d0.name).replace(/[^A-Za-z0-9 ._-]+/g, '-').slice(0, 60)}.${extFor(d0.mime, d0.name)}`, mime: d0.mime || 'application/octet-stream', data, size: fp.size, sha256: fp.sha256 }, 300000);
    if (r && r.ok === false && r.error) throw new Error(r.error);
  } catch (e) {
    withSystem(() => markUploadFailed(uid, e.message || String(e)));
    throw e;
  }
  return withSystem(() => markUploaded(uid, fp, r));
}

// The file of a document as base64: from this device, or fetched from the cloud copy (then kept here too).
// The cloud checks the logged-in person's role against the document visibility setting before sending it.
export async function documentBase64(d, user = appUser()) {
  if (d.path && (await fileExists(d.path))) return fileBase64(d.path);
  if (!d.cloud_id) throw new Error('This document is on another device and has not reached the cloud yet. Open it there, or sync that device first.');
  if (isTraining()) throw Object.assign(new Error('Not available in training mode.'), { isAppError: true });
  const r = await post({ kind: 'file_get', id: d.cloud_id, user: user ? { uid: user.uid, role: user.role } : undefined }, 300000);
  if (!r || !r.data) throw new Error((r && r.error) || 'Could not fetch the document from the cloud.');
  if (d.sha256) {
    const fp = base64Fingerprint(r.data);
    if (fp.sha256 !== String(d.sha256).toLowerCase()) throw new Error('The copy fetched from Google Drive does not match the original (fingerprint differs). It was not opened.');
  }
  const dir = `${FS.documentDirectory}docs/`;
  try { await FS.makeDirectoryAsync(dir, { intermediates: true }); } catch (e) { /* already there */ }
  const path = `${dir}${d.uid}.${extFor(d.mime, d.name)}`;
  await FS.writeAsStringAsync(path, r.data, { encoding: FS.EncodingType.Base64 });
  withSystem(() => markFetched(d.uid, path));
  return r.data;
}

// Tablet copies of documents verified in Drive and older than the admin's retention (default 90 days) are removed
// from this device; they are fetched again when opened.
export async function clearOldLocalCopies() {
  let n = 0;
  for (const d of localCopiesToClear()) {
    try { await FS.deleteAsync(d.path, { idempotent: true }); } catch (e) { continue; }
    withSystem(() => markLocalCleared(d.uid));
    n += 1;
  }
  return n;
}

// New or replaced tablet, after the data was restored: fetch back the recent document files (each checked).
export async function fetchNeededFiles(onProgress = () => {}) {
  const list = filesToFetch();
  let ok = 0;
  const failed = [];
  for (const [i, d] of list.entries()) {
    onProgress(i + 1, list.length, d.name);
    try { await documentBase64({ ...getDocument(d.uid), path: null }); ok += 1; } catch (e) { failed.push({ name: d.name, error: e.message || String(e) }); }
  }
  return { total: list.length, ok, failed };
}
