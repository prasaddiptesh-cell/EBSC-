// Sends data to the bakery's Google account (via the Apps Script "bakery cloud").
// Works offline-first: everything waits in the outbox until the tablet is online.
import { db } from '../db/connection.js';
import { getSettings, setSetting, getSetting, stamp, APP_VERSION, dateStr, deviceId, deviceName } from '../services/core.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor } from '../services/records.js';
import { setSyncState } from '../services/syncBus.js';
import { pendingOutbox, markOutboxSent, markOutboxFailed, getPhoto, setPhotoCloudUrl, markPoSent, enqueue } from '../services/stock.js';
import { shiftReport, purchaseOrderDoc } from '../services/reports.js';
import { markReportSent, getShift } from '../services/shifts.js';
import { buildSnapshot } from '../services/dashboard.js';
import { applyOnlinePlans, planSeq } from '../services/plan.js';
import { reportPdf, reportXlsx, fileBase64, fileExists } from './files.js';
import { retireSampleLogins } from '../modules/devices/service.js';

let running = false;

// Any request to the cloud. Linked devices send their own token; the first device may use the cloud key.
export async function cloudCall(body, timeoutMs = 60000) {
  return post(body, timeoutMs);
}

async function post(body, timeoutMs = 90000) {
  const s = getSettings();
  const token = getSetting('cloud_token', '');
  if (!s.cloudUrl) throw new Error('The cloud web address is not set (Admin → Settings → Online & email).');
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(s.cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ key: token ? undefined : s.cloudKey, token: token || undefined, app: APP_VERSION, location: s.locationName, sentAt: stamp(), device: { id: deviceId(), name: deviceName(), kind: getSetting('device_kind', 'tablet') }, ...body }),
      signal: ctrl ? ctrl.signal : undefined,
    });
    const text = await res.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch (e) {
      throw new Error(res.status === 200 ? 'The cloud did not reply correctly. Check the web address and that it is deployed for "Anyone".' : `Cloud error ${res.status}`);
    }
    if (json.waiting) setSetting('link_waiting', '1');
    if (!json.ok) throw new Error(json.error || 'The cloud refused the request.');
    if (getSetting('link_waiting', '') === '1') setSetting('link_waiting', '0');
    return json;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function testConnection() {
  const r = await post({ kind: 'ping' }, 30000);
  return r;
}

function dumpDatabase() {
  const tables = ['settings', 'users', 'suppliers', 'materials', 'products', 'recipes', 'shift_names', 'steps', 'product_steps', 'shifts', 'shift_workers',
    'shift_stock', 'transactions', 'batches', 'batch_ingredients', 'batch_steps', 'alerts', 'purchase_orders', 'photos'];
  const out = {};
  for (const t of tables) {
    out[t] = db().all(`SELECT * FROM ${t}`).map((r) => {
      if (t === 'users') return { ...r, pin: '****', password_hash: r.password_hash ? '****' : null };
      if (t === 'settings' && r.key === 'cloud_key') return { ...r, value: '****' };
      return r;
    });
  }
  return out;
}

function addPhotoUrl(table, uid, url) {
  const row = db().get(`SELECT photo_urls FROM ${table} WHERE uid = ?`, [uid]);
  if (!row) return;
  let list = [];
  try { list = JSON.parse(row.photo_urls || '[]'); } catch (e) { list = []; }
  if (!list.includes(url)) list.push(url);
  db().run(`UPDATE ${table} SET photo_urls = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(list), stamp(), deviceId(), uid]);
}

async function handle(item) {
  const s = getSettings();
  const p = item.payload;
  if (item.kind === 'report') {
    const rep = shiftReport(p.shiftId);
    if (!rep) return;
    const pdf = await reportPdf(rep);
    const xlsx = await reportXlsx(rep);
    const sh = getShift(p.shiftId);
    await post({
      kind: 'report', emails: s.reportEmails, subject: `${s.bakeryName} – Shift report ${sh.shift_date} ${sh.shift_name} (${sh.code})`,
      html: pdf.html, fileName: rep.fileName, pdf: pdf.base64, xlsx: xlsx.base64, month: sh.shift_date.slice(0, 7), shiftCode: sh.code,
      summary: rep.summary,
    }, 180000);
    markReportSent(p.shiftId);
  } else if (item.kind === 'po') {
    const doc = purchaseOrderDoc(p.poId);
    if (!doc) return;
    const pdf = await reportPdf(doc);
    await post({
      kind: 'po', emails: s.poEmails.length ? s.poEmails : s.reportEmails, subject: `${s.bakeryName} – Purchase order ${doc.po.po_no} (${doc.po.supplier || 'supplier'})`,
      html: pdf.html, fileName: doc.fileName, pdf: pdf.base64, month: doc.po.created_at.slice(0, 7), supplierEmail: doc.po.supplier_email || '',
    }, 120000);
    markPoSent(p.poId);
  } else if (item.kind === 'photo') {
    const ph = getPhoto(p.photoId);
    if (!ph || !(await fileExists(ph.uri))) return;
    const data = await fileBase64(ph.uri);
    const r = await post({ kind: 'photo', refType: ph.ref_type, refId: ph.ref_id, data, fileName: `${ph.ref_type}-${ph.ref_id}-${ph.id}.jpg`, month: ph.created_at.slice(0, 7) }, 180000);
    if (r.url) {
      setPhotoCloudUrl(ph.id, r.url);
      // Easy Buys modules: put the Drive link on the record so every device can open the photo.
      const link = { punch: 'punches', leave: 'leave_requests' }[ph.ref_type];
      if (link) db().run(`UPDATE ${link} SET photo_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [r.url, stamp(), deviceId(), ph.ref_id]);
      // Records with several photos (invoice pages, receipts, Z reports) keep a list of links.
      const many = { invoice: 'ap_invoices', payment: 'ap_payments', till: 'till_counts', deposit: 'deposits', cash: 'cash_moves' }[ph.ref_type];
      if (many) addPhotoUrl(many, ph.ref_id, r.url);
    }
  } else if (item.kind === 'ocr') {
    // Ask Google to read the invoice photos, then fill in the invoice on this device.
    const { listPhotos } = require('../services/stock.js');
    const { applyReadText } = require('../modules/payables/service.js');
    const pics = listPhotos('invoice', p.invoiceUid).slice(0, 4);
    const files = [];
    for (const ph of pics) if (await fileExists(ph.uri)) files.push({ mimeType: 'image/jpeg', data: await fileBase64(ph.uri) });
    if (!files.length) return;
    const r = await post({ kind: 'ocr', files }, 180000);
    if (r.off) db().run("UPDATE ap_invoices SET ocr_status = 'type', ocr_notes = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      ['Reading photos is not switched on in the cloud. Please type the details.', stamp(), deviceId(), p.invoiceUid]);
    else applyReadText(p.invoiceUid, r.text || '');
  } else if (item.kind === 'backup') {
    await post({ kind: 'backup', fileName: `backup-${p.date}.json`, data: JSON.stringify(dumpDatabase()) }, 180000);
  }
}

// One sync round: send the live status, then work through the outbox.
// Shared records (staff, punches, timesheets, leave...): send ours, then fetch other devices' changes.
async function syncRecords() {
  let sent = 0;
  let received = 0;
  for (let round = 0; round < 20; round++) {
    const batch = pendingRecords(200);
    if (!batch.length) break;
    const r = await post({ kind: 'push', records: batch }, 90000);
    markRecordsSent(batch);
    sent += batch.length;
    if (r.rejected && r.rejected.length) setSetting('last_rejected', JSON.stringify(r.rejected.slice(0, 20)));
  }
  for (let round = 0; round < 20; round++) {
    const r = await post({ kind: 'pull', since: pullCursor() }, 90000);
    const list = r.records || [];
    if (list.length) received += applyPulledRecords(list);
    if (typeof r.next === 'number') setPullCursor(r.next);
    if (!r.more) break;
  }
  try { retireSampleLogins(); } catch (e) { /* try again next round */ }
  return { sent, received };
}

export async function syncNow({ force = false } = {}) {
  const s = getSettings();
  if (!s.cloudUrl || running) return { skipped: true };
  running = true;
  setSyncState({ running: true, lastTry: stamp() });
  let sent = 0;
  let received = 0;
  let error = null;
  let planChanged = 0;
  try {
    const rec = await syncRecords();
    sent += rec.sent;
    received = rec.received;
    const today = dateStr();
    if (getSetting('last_backup_date') !== today) {
      enqueue('backup', { date: today });
      setSetting('last_backup_date', today);
    }
    const r = await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 45000);
    // Plan changes made on the online dashboard come back with the reply.
    if (r.planEdits && r.planEdits.length) {
      planChanged = applyOnlinePlans(r.planEdits);
      await post({ kind: 'snapshot', snapshot: buildSnapshot(), planSeq: planSeq() }, 45000); // confirm to the dashboard straight away
    }
    for (const item of pendingOutbox(force ? 50 : 10)) {
      try {
        await handle(item);
        markOutboxSent(item.id);
        sent += 1;
      } catch (e) {
        markOutboxFailed(item.id, e.message || e);
        error = e.message || String(e);
        break; // try again next round (keeps order, saves data when offline)
      }
    }
    setSetting('last_sync_at', stamp());
  } catch (e) {
    error = e.message || String(e);
  } finally {
    running = false;
    setSetting('last_sync_error', error || '');
    if (!error) setSetting('last_sync_ok_at', stamp());
    setSyncState({ running: false, error: error || '', lastOk: getSetting('last_sync_ok_at', ''), sent, received });
  }
  return { sent, received, error, planChanged };
}

export function syncStatus() {
  return {
    configured: !!getSettings().cloudUrl,
    lastOk: getSetting('last_sync_ok_at', ''),
    lastTry: getSetting('last_sync_at', ''),
    error: getSetting('last_sync_error', ''),
  };
}
