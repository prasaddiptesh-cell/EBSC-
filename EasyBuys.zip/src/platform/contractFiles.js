// The company's own contract PDF on the tablet: upload it, the stamp photo, preview, and the finished signed copy.
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as ImageManipulator from 'expo-image-manipulator';
import { stampContract } from '../services/contractPdf.js';
import { contractPdfSettings, saveContractPdfSettings, contractPdfData, attachSignedContract, saveSignature, getContract } from '../modules/people/service.js';
import { addFileDocument, addBase64Document, documentData } from './docFiles.js';

export async function uploadContractTemplate(user, file) {
  if (!file) throw Object.assign(new Error('Choose the PDF first.'), { isAppError: true });
  if (!/pdf$/i.test(file.mime || '') && !/\.pdf$/i.test(file.name || '')) throw Object.assign(new Error('The contract must be a PDF file. (In Word: File › Save as › PDF.)'), { isAppError: true });
  const uid = await addFileDocument(user, { refType: 'contract_template', kind: 'contract_template', name: file.name || 'Company contract.pdf' }, file);
  return saveContractPdfSettings(user, { templateDocUid: uid, templateName: file.name || 'Company contract.pdf' });
}

// The stamp: a photo of the stamp on white paper, made small enough to keep with the records.
export async function saveStampPhoto(user, uri) {
  let data = null;
  for (const [w, q] of [[420, 0.7], [340, 0.6], [260, 0.5], [200, 0.45]]) {
    const r = await ImageManipulator.manipulateAsync(uri, [{ resize: { width: w } }], { compress: q, format: ImageManipulator.SaveFormat.JPEG, base64: true });
    data = `data:image/jpeg;base64,${r.base64}`;
    if (data.length < 44000) break;
  }
  const sig = saveSignature(data, 'Company stamp');
  return saveContractPdfSettings(user, { stampSigUid: sig });
}
export function saveDirectorSignature(user, dataUrl, name) {
  const sig = saveSignature(dataUrl, name || 'Director');
  return saveContractPdfSettings(user, { directorSigUid: sig, directorName: name });
}

async function share(base64, name) {
  const path = `${FileSystem.cacheDirectory}${String(name).replace(/[^A-Za-z0-9._-]+/g, '-')}.pdf`;
  await FileSystem.writeAsStringAsync(path, base64, { encoding: FileSystem.EncodingType.Base64 });
  await Sharing.shareAsync(path, { mimeType: 'application/pdf', dialogTitle: name });
  return path;
}

// Preview with the director's signature and the stamp where they will go (employee signature left empty).
export async function previewContractPdf() {
  const cp = contractPdfSettings();
  if (!cp.templateDocUid) throw Object.assign(new Error('Upload the company contract PDF first.'), { isAppError: true });
  const tpl = await documentData(cp.templateDocUid);
  const out = await stampContract(tpl, cp.layout, contractPdfData(null, { sample: true }));
  return share(out, 'Contract-preview');
}
// The employee reads the contract (with their details filled in) before signing.
export async function readContractPdf(uid) {
  const d = contractPdfData(uid);
  const tpl = await documentData(d.templateDocUid);
  const out = await stampContract(tpl, { ...(d.layout || {}), signPage: false, initialsEachPage: false }, { ...d, empSig: null, dirSig: null, stamp: null, empAt: '', dirAt: '' });
  return share(out, `Contract-${d.name}`);
}
// After both have signed: the finished PDF (signatures + stamp) is kept with the contract, sent to Drive and emailed.
export async function finishContractPdf(user, uid) {
  const d = contractPdfData(uid);
  const tpl = await documentData(d.templateDocUid);
  const out = await stampContract(tpl, d.layout, d);
  const c = getContract(uid);
  const docUid = await addBase64Document(user, { refType: 'contract', refUid: uid, kind: 'signed_contract', name: `Signed contract – ${c.name}.pdf`, docDate: String(c.employer_signed_at || '').slice(0, 10) }, out);
  return attachSignedContract(user, uid, docUid);
}
