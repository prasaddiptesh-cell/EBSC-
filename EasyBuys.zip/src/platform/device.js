// Small facts about the phone or tablet: free storage, the size of the database file, Android version.
// Every call is safe: when the phone cannot tell, the answer is null.
import { Platform } from 'react-native';
import * as FS from 'expo-file-system/legacy';

export const DB_FILE = 'bakery.db';
export const TRAINING_DB_FILE = 'easybuys-training.db';

// expo-sqlite keeps databases in <documents>/SQLite/<name>.
export function dbDir() { return `${FS.documentDirectory || 'file:///'}SQLite/`; }
export function dbPath(name = DB_FILE) { return `${dbDir()}${name}`; }
// SQLite needs a plain path (no "file://").
export function plainPath(uri) { return String(uri || '').replace(/^file:\/\//, ''); }

export async function freeDiskBytes() {
  try { const n = await FS.getFreeDiskStorageAsync(); return Number.isFinite(Number(n)) ? Number(n) : null; } catch (e) { return null; }
}
export async function fileSize(uri) {
  try { const i = await FS.getInfoAsync(uri, { size: true }); return i && i.exists ? Number(i.size || 0) : null; } catch (e) { return null; }
}
export async function storageUsed() {
  const db = await fileSize(dbPath());
  const wal = await fileSize(`${dbPath()}-wal`);
  return db === null ? null : db + (wal || 0);
}
export function androidVersion() {
  try { return Platform.OS === 'android' ? `Android ${Platform.Version}` : String(Platform.OS || ''); } catch (e) { return ''; }
}
export function bytesText(n) {
  if (n === null || n === undefined || !Number.isFinite(Number(n))) return '—';
  const v = Number(n);
  if (v >= 1e9) return `${(v / 1e9).toFixed(1)} GB`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(1)} MB`;
  if (v >= 1e3) return `${Math.round(v / 1e3)} KB`;
  return `${v} bytes`;
}

// v3.9.5 the space a folder of the app takes (photos, safety copies, documents). Large folders are counted up to
// `max` files and the rest estimated from the average, so the Storage screen stays quick.
export async function folderSize(sub, { max = 2500 } = {}) {
  try {
    const dir = `${FS.documentDirectory || 'file:///'}${sub}`;
    const info = await FS.getInfoAsync(dir);
    if (!info || !info.exists) return { bytes: 0, files: 0 };
    const names = await FS.readDirectoryAsync(dir);
    let bytes = 0; let counted = 0;
    for (const n of names.slice(0, max)) {
      const i = await FS.getInfoAsync(`${dir}${n}`, { size: true });
      if (i && i.exists && !i.isDirectory) { bytes += Number(i.size || 0); counted += 1; }
    }
    if (names.length > max && counted) bytes = Math.round((bytes / counted) * names.length);
    return { bytes, files: names.length };
  } catch (e) { return { bytes: null, files: null }; }
}
export async function storageReport() {
  const [free, db, photos, snaps, docs] = await Promise.all([freeDiskBytes(), storageUsed(), folderSize('photos/'), folderSize('snapshots/'), folderSize('docs/')]);
  return { free, db, photos, snaps, docs };
}
