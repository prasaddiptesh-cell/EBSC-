// Small facts about the phone or tablet: free storage, the size of the database file, Android version.
// Every call is safe: when the phone cannot tell, the answer is null.
import { Platform } from 'react-native';
import * as FS from 'expo-file-system/legacy';

export const DB_FILE = 'bakery.db';
export const TRAINING_DB_FILE = 'easybuys-training.db';

// expo-sqlite keeps databases in <documents>/SQLite/<name>.
export function dbDir() { return `${FS.documentDirectory || 'file:///'}SQLite/`; }
export function dbPath(name = DB_FILE) { return `${dbDir()}${name}`; }
// SQLite needs a plain path (no "file://").
export function plainPath(uri) { return String(uri || '').replace(/^file:\/\//, ''); }

export async function freeDiskBytes() {
  try { const n = await FS.getFreeDiskStorageAsync(); return Number.isFinite(Number(n)) ? Number(n) : null; } catch (e) { return null; }
}
export async function fileSize(uri) {
  try { const i = await FS.getInfoAsync(uri, { size: true }); return i && i.exists ? Number(i.size || 0) : null; } catch (e) { return null; }
}
export async function storageUsed() {
  const db = await fileSize(dbPath());
  const wal = await fileSize(`${dbPath()}-wal`);
  return db === null ? null : db + (wal || 0);
}
export function androidVersion() {
  try { return Platform.OS === 'android' ? `Android ${Platform.Version}` : String(Platform.OS || ''); } catch (e) { return ''; }
}
export function bytesText(n) {
  if (n === null || n === undefined || !Number.isFinite(Number(n))) return '—';
  const v = Number(n);
  if (v >= 1e9) return `${(v / 1e9).toFixed(1)} GB`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(1)} MB`;
  if (v >= 1e3) return `${Math.round(v / 1e3)} KB`;
  return `${v} bytes`;
}
