// Adding files to the app's documents (from the phone's files, the camera, or made by the app) and opening them.
import * as FileSystem from 'expo-file-system/legacy';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import { recordDocument, getDocument, extFor, mimeFor } from '../services/documents.js';
import { uuid, AppError } from '../services/core.js';
import { canSeeDocument } from '../services/driveDocs.js';
import { appUser } from '../services/errorLog.js';
import { documentBase64 } from './cloud.js';

const DIR = () => `${FileSystem.documentDirectory}docs/`;
async function ensureDir() { try { await FileSystem.makeDirectoryAsync(DIR(), { intermediates: true }); } catch (e) { /* already there */ } }

// Opens the phone's file chooser (PDF, Word, photos…). Returns { uri, name, mime, size } or null.
export async function pickAnyFile({ pdfOnly = false } = {}) {
  const r = await DocumentPicker.getDocumentAsync({ type: pdfOnly ? ['application/pdf'] : ['*/*'], copyToCacheDirectory: true, multiple: false });
  if (!r || r.canceled || !r.assets || !r.assets.length) return null;
  const a = r.assets[0];
  return { uri: a.uri, name: a.name || 'document', mime: a.mimeType || mimeFor(a.name), size: a.size || null };
}

// Keeps a copy of a picked file / photo in the app and records it (it then goes to Google Drive when online).
export async function addFileDocument(user, meta, file) {
  if (!file || !file.uri) throw new Error('Choose the file first.');
  await ensureDir();
  const uid = uuid('DOC');
  const path = `${DIR()}${uid}.${extFor(file.mime, file.name)}`;
  await FileSystem.copyAsync({ from: file.uri, to: path });
  return recordDocument(user, { ...meta, uid, name: meta.name || file.name, mime: file.mime || mimeFor(file.name), size: file.size, path });
}
// Photos taken in the app (camera / gallery uris).
export async function addPhotoDocuments(user, meta, uris = []) {
  const out = [];
  let i = 0;
  for (const uri of uris) {
    i += 1;
    out.push(await addFileDocument(user, { ...meta, name: uris.length > 1 ? `${meta.name} (${i})` : meta.name }, { uri, name: `${meta.name || 'photo'}.jpg`, mime: 'image/jpeg' }));
  }
  return out;
}
// A file made by the app (e.g. the signed contract PDF), given as base64.
export async function addBase64Document(user, meta, base64, mime = 'application/pdf') {
  await ensureDir();
  const uid = uuid('DOC');
  const path = `${DIR()}${uid}.${extFor(mime, meta.name)}`;
  await FileSystem.writeAsStringAsync(path, base64, { encoding: FileSystem.EncodingType.Base64 });
  return recordDocument(user, { ...meta, uid, mime, size: Math.round(base64.length * 0.75), path });
}

// Opens a document: Android asks which app to use (PDF viewer, Drive, Gallery, WhatsApp to send it…).
export async function openDocument(uid) {
  let d = getDocument(uid);
  if (!d) throw new Error('Document not found.');
  // v3.5: documents filed by type follow the admin's "who can see documents" setting.
  const who = appUser();
  if (d.doc_type && who && !canSeeDocument(who, d)) throw new AppError('Your role may not open this type of document. Ask the owner.');
  if (!d.path || !(await exists(d.path))) { await documentBase64(d); d = getDocument(uid); }
  if (!(await Sharing.isAvailableAsync())) throw new Error('Opening files is not available on this device.');
  await Sharing.shareAsync(d.path, { mimeType: d.mime || 'application/octet-stream', dialogTitle: d.name });
}
export async function documentData(uid) {
  const d = getDocument(uid);
  if (!d) throw new Error('Document not found.');
  return documentBase64(d);
}
async function exists(p) { try { return (await FileSystem.getInfoAsync(p)).exists; } catch (e) { return false; } }
