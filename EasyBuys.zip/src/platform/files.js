// Creating PDF / Excel / CSV files on the tablet and sharing them.
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import * as DocumentPicker from 'expo-document-picker';
import { reportToHtml, reportToCsv, reportToXlsxBase64 } from '../services/export.js';
import { decodeBase64Text } from '../services/textDecode.js';
import { prepareDoc, pageSizePt, docMetaFromRep } from '../services/docOutput.js';
import { recordIssued } from '../services/issuedDocs.js';
import { docSettings, folderPathFor } from '../services/driveDocs.js';
import { docType } from '../services/docDesign.js';
import { appUser } from '../services/errorLog.js';
import { isTraining } from '../services/trainingFlag.js';
import { db } from '../db/connection.js';
import { LOGO_DATA_URI } from './logoData.js';
import { printHtml } from './printer.js';

// v3.5: every document opens in the preview first (Send / Save PDF / Excel / Print / Close). The preview host
// (src/ui/docPreview.js, mounted once in App.js) registers itself here; without it (tests, background jobs) the
// action happens straight away.
let previewHandler = null;
export function setPreviewHandler(fn) { previewHandler = fn || null; }
export function previewAvailable() { return !!previewHandler; }
const wantPreview = (opts) => !!previewHandler && !(opts && opts.direct) && (() => { try { return docSettings().previewFirst; } catch (e) { return true; } })();

const safe = (name) => String(name).replace(/[^A-Za-z0-9._-]+/g, '-').slice(0, 80);

export async function reportPdf(rep0, { paper } = {}) {
  const rep = prepareDoc(rep0, { paper });
  const html = reportToHtml(rep, { logoUri: LOGO_DATA_URI });
  const size = pageSizePt(rep);
  const res = await Print.printToFileAsync({ html, width: size.width, height: size.height, base64: true });
  const target = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.pdf`;
  await FileSystem.deleteAsync(target, { idempotent: true });
  await FileSystem.copyAsync({ from: res.uri, to: target });
  return { uri: target, base64: res.base64, html, rep };
}

export async function reportXlsx(rep) {
  const base64 = await reportToXlsxBase64(rep);
  const uri = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.xlsx`;
  await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
  return { uri, base64 };
}

export async function reportCsv(rep) {
  const text = reportToCsv(rep);
  const uri = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.csv`;
  await FileSystem.writeAsStringAsync(uri, '﻿' + text, { encoding: FileSystem.EncodingType.UTF8 });
  return { uri, text };
}

const MIME = {
  pdf: 'application/pdf',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  csv: 'text/csv',
};

// format: 'pdf' | 'xlsx' | 'csv'  -> opens the preview first, then the Android share sheet (WhatsApp, Gmail, Drive...)
export async function shareReport(rep, format, opts = {}) {
  if (wantPreview(opts)) return previewHandler(rep, { ...opts, action: format || 'pdf' });
  return shareReportNow(rep, format, opts);
}
// build 50: the website – a browser has no share sheet or app files: Excel / CSV are downloaded, a PDF opens the
// browser's print window (choose "Save as PDF" there).
const isWeb = () => { try { return require('react-native').Platform.OS === 'web'; } catch (e) { return false; } };
function webDownload(base64OrText, name, mime, isText = false) {
  const data = isText ? new Blob(['\ufeff' + base64OrText], { type: mime }) : new Blob([Uint8Array.from(atob(base64OrText), (c) => c.charCodeAt(0))], { type: mime });
  const url = URL.createObjectURL(data);
  const a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { try { a.remove(); URL.revokeObjectURL(url); } catch (e) { /* gone */ } }, 4000);
  return url;
}
export async function webReportOut(rep0, format, { paper } = {}) {
  const rep = prepareDoc(rep0, { paper });
  if (format === 'xlsx') { webDownload(await reportToXlsxBase64(rep), `${safe(rep.fileName)}.xlsx`, MIME.xlsx); return 'downloaded'; }
  if (format === 'csv') { webDownload(reportToCsv(rep), `${safe(rep.fileName)}.csv`, MIME.csv, true); return 'downloaded'; }
  await printHtml(reportToHtml(rep, { logoUri: LOGO_DATA_URI }), pageSizePt(rep));
  return 'printed';
}
export async function shareReportNow(rep0, format, { paper, pdf: made } = {}) {
  if (isWeb()) return webReportOut(rep0, format, { paper });
  const rep = prepareDoc(rep0, { paper });
  const file = format === 'xlsx' ? await reportXlsx(rep) : format === 'csv' ? await reportCsv(rep) : made || await reportPdf(rep);
  if (!(await Sharing.isAvailableAsync())) throw Object.assign(new Error('Sharing is not available on this device.'), { isAppError: true });
  await Sharing.shareAsync(file.uri, { mimeType: MIME[format] || MIME.pdf, dialogTitle: rep.title });
  await afterOutput(rep, { how: format === 'xlsx' || format === 'csv' ? 'excel' : 'send', pdf: format === 'pdf' || !format ? file : null });
  return file.uri;
}

export async function printReport(rep, opts = {}) {
  if (wantPreview(opts)) return previewHandler(rep, { ...opts, action: 'print' });
  return printReportNow(rep, opts);
}
// System print (Android print service): A4 / A5, or an 80 mm page for receipt printers.
export async function printReportNow(rep0, { paper } = {}) {
  const rep = prepareDoc(rep0, { paper });
  await printHtml(reportToHtml(rep, { logoUri: LOGO_DATA_URI }), pageSizePt(rep));
  await afterOutput(rep, { how: 'print' });
}
// "Save PDF": keeps the PDF in the app's documents (and so in Google Drive, filed by type).
export async function saveReportPdf(rep0, { paper, pdf: made } = {}) {
  if (isWeb()) { await webReportOut(rep0, 'pdf', { paper }); return { uri: null, docUid: null }; }
  const rep = prepareDoc(rep0, { paper });
  const pdf = made || await reportPdf(rep);
  const uid = await afterOutput(rep, { how: 'save', pdf, force: true });
  return { uri: pdf.uri, docUid: uid };
}

// After a document was sent, printed or saved: record the issued copy (for the barcode check) and file the PDF in
// the documents (→ Google Drive) once per version. Never in training mode.
export async function afterOutput(rep, { how = 'pdf', pdf = null, force = false } = {}) {
  const user = appUser();
  try { if (rep._identity) recordIssued(rep, rep._identity, { user, how }); } catch (e) { /* the copy is still made */ }
  if (isTraining() || !rep._identity) return null;
  let settings;
  try { settings = docSettings(); } catch (e) { return null; }
  if (!force && !settings.fileOnSend) return null;
  try {
    const have = db().get("SELECT uid FROM documents WHERE issued_hash = ? AND status = 'active'", [rep._identity.hash]);
    if (have) return have.uid;
    const file = pdf || await reportPdf(rep);
    if (!file || !file.base64) return null;
    const { addBase64Document } = require('./docFiles.js');
    const t = docType(rep._typeId);
    const meta = docMetaFromRep(rep);
    const today = new Date().toISOString().slice(0, 10);
    return await addBase64Document(user, {
      refType: rep._typeId, refUid: rep.refUid || null, kind: 'finished', name: String(rep.title || rep.fileName || 'Document').slice(0, 120), docDate: rep.docDate || today,
      notes: `${t.label} · ${rep._identity.ref}`,
      meta35: { doc_type: rep._typeId, ...meta, access_class: t.access, folder_path: JSON.stringify(folderPathFor(rep._typeId, rep.docDate || today)), issued_ref: rep._identity.ref, issued_hash: rep._identity.hash },
    }, file.base64, 'application/pdf');
  } catch (e) { return null; }
}

export async function fileBase64(uri) {
  const W = require('./webFiles.js');
  if (W.isInline(uri)) return W.inlineBase64(uri); // Release 12: a file kept in the website's tab
  return FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
}

export async function fileExists(uri) {
  if (require('./webFiles.js').isInline(uri)) return true;
  try {
    const info = await FileSystem.getInfoAsync(uri);
    return info.exists;
  } catch (e) {
    return false;
  }
}

// Choose a CSV / text file on the device (e.g. an Aronium export) and read it as text.
export async function pickTextFile() {
  const r = await DocumentPicker.getDocumentAsync({ type: ['text/*', 'text/csv', 'text/comma-separated-values', 'application/vnd.ms-excel', '*/*'], copyToCacheDirectory: true, multiple: false });
  if (!r || r.canceled || !r.assets || !r.assets.length) return null;
  const a = r.assets[0];
  // Read the bytes and work out the text encoding (Aronium / Excel on Windows save Windows-1252 or UTF-16).
  const b64 = await (require('./webFiles.js').isInline(a.uri) ? require('./webFiles.js').inlineBase64(a.uri) : FileSystem.readAsStringAsync(a.uri, { encoding: FileSystem.EncodingType.Base64 }));
  const text = decodeBase64Text(b64);
  return { name: a.name || 'file.csv', text };
}

// Puts photos (taken on this device, or already in the cloud) into a report so they print in the PDF.
export async function withPhotos(rep, photos = []) {
  const images = [];
  for (const p of (photos || []).slice(0, 4)) {
    const uri = typeof p === 'string' ? p : p && p.uri;
    const caption = (p && p.caption) || 'Photo';
    if (!uri) continue;
    try {
      if (/^https?:/i.test(uri)) images.push({ src: uri, caption });
      else if (await fileExists(uri)) images.push({ src: `data:image/jpeg;base64,${await fileBase64(uri)}`, caption });
    } catch (e) { /* a photo that cannot be read is left out */ }
  }
  return { ...rep, images };
}
// 1.0.0 a ready-made text file (e.g. the Aronium update CSV) → the Android share sheet (Drive, Gmail, WhatsApp…).
export async function shareTextFile(name, text, { mime = 'text/csv', bom = true } = {}) {
  const uri = `${FileSystem.cacheDirectory}${safe(String(name).replace(/\.[a-z]+$/i, ''))}${(String(name).match(/\.[a-z]+$/i) || ['.csv'])[0]}`;
  await FileSystem.writeAsStringAsync(uri, (bom ? '﻿' : '') + text, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) throw Object.assign(new Error('Sharing is not available on this device.'), { isAppError: true });
  await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: name });
  return uri;
}
