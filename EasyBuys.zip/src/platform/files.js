// Creating PDF / Excel / CSV files on the tablet and sharing them.
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';
import * as DocumentPicker from 'expo-document-picker';
import { reportToHtml, reportToCsv, reportToXlsxBase64 } from '../services/export.js';
import { decodeBase64Text } from '../services/textDecode.js';
import { LOGO_DATA_URI } from './logoData.js';

const safe = (name) => String(name).replace(/[^A-Za-z0-9._-]+/g, '-').slice(0, 80);

export async function reportPdf(rep) {
  const html = reportToHtml(rep, { logoUri: LOGO_DATA_URI });
  const res = await Print.printToFileAsync({ html, width: 595, height: 842, base64: true });
  const target = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.pdf`;
  await FileSystem.deleteAsync(target, { idempotent: true });
  await FileSystem.copyAsync({ from: res.uri, to: target });
  return { uri: target, base64: res.base64, html };
}

export async function reportXlsx(rep) {
  const base64 = await reportToXlsxBase64(rep);
  const uri = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.xlsx`;
  await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
  return { uri, base64 };
}

export async function reportCsv(rep) {
  const text = reportToCsv(rep);
  const uri = `${FileSystem.cacheDirectory}${safe(rep.fileName)}.csv`;
  await FileSystem.writeAsStringAsync(uri, '﻿' + text, { encoding: FileSystem.EncodingType.UTF8 });
  return { uri, text };
}

const MIME = {
  pdf: 'application/pdf',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  csv: 'text/csv',
};

// format: 'pdf' | 'xlsx' | 'csv'  -> opens the Android share sheet (WhatsApp, Gmail, Drive...)
export async function shareReport(rep, format) {
  const file = format === 'xlsx' ? await reportXlsx(rep) : format === 'csv' ? await reportCsv(rep) : await reportPdf(rep);
  if (!(await Sharing.isAvailableAsync())) throw new Error('Sharing is not available on this device.');
  await Sharing.shareAsync(file.uri, { mimeType: MIME[format] || MIME.pdf, dialogTitle: rep.title });
  return file.uri;
}

export async function printReport(rep) {
  await Print.printAsync({ html: reportToHtml(rep, { logoUri: LOGO_DATA_URI }), width: 595, height: 842 });
}

export async function fileBase64(uri) {
  return FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
}

export async function fileExists(uri) {
  try {
    const info = await FileSystem.getInfoAsync(uri);
    return info.exists;
  } catch (e) {
    return false;
  }
}

// Choose a CSV / text file on the device (e.g. an Aronium export) and read it as text.
export async function pickTextFile() {
  const r = await DocumentPicker.getDocumentAsync({ type: ['text/*', 'text/csv', 'text/comma-separated-values', 'application/vnd.ms-excel', '*/*'], copyToCacheDirectory: true, multiple: false });
  if (!r || r.canceled || !r.assets || !r.assets.length) return null;
  const a = r.assets[0];
  // Read the bytes and work out the text encoding (Aronium / Excel on Windows save Windows-1252 or UTF-16).
  const b64 = await FileSystem.readAsStringAsync(a.uri, { encoding: FileSystem.EncodingType.Base64 });
  const text = decodeBase64Text(b64);
  return { name: a.name || 'file.csv', text };
}

// Puts photos (taken on this device, or already in the cloud) into a report so they print in the PDF.
export async function withPhotos(rep, photos = []) {
  const images = [];
  for (const p of (photos || []).slice(0, 4)) {
    const uri = typeof p === 'string' ? p : p && p.uri;
    const caption = (p && p.caption) || 'Photo';
    if (!uri) continue;
    try {
      if (/^https?:/i.test(uri)) images.push({ src: uri, caption });
      else if (await fileExists(uri)) images.push({ src: `data:image/jpeg;base64,${await fileBase64(uri)}`, caption });
    } catch (e) { /* a photo that cannot be read is left out */ }
  }
  return { ...rep, images };
}
