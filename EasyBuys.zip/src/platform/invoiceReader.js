// Reading invoice photos: first on the tablet (offline, ML Kit), then Google's cloud reading as a backup.
// Service functions for any screen (receiving, invoices, the photo-of-invoice screen):
//   readPhotosText(uris)                     → { ok, text, engine: 'device' | 'cloud', message }
//   readInvoicePhotos(user, uris, ctx)       → also the item lines matched to the order / delivery, saved as a reading
//   readInvoiceOnDevice(user, invoiceUid)    → fills in an entered invoice from its photos (device first, cloud backup)
import { recognizeText } from './textRecognition.js';
import { cloudCall, readInvoiceNow } from './cloud.js';
import { fileBase64, fileExists } from './files.js';
import { getSettings } from '../services/core.js';
import { readInvoiceText, saveRead } from '../modules/inventory/invoiceRead.js';

export async function readPhotosText(uris = [], { cloud = true, rows = false } = {}) {
  const list = (uris || []).filter(Boolean).slice(0, 4);
  if (!list.length) return { ok: false, message: 'Take a photo of the invoice first.' };
  // UI tests (web) give the photo text directly.
  const fake = typeof globalThis !== 'undefined' && globalThis.__ebPaperText;
  if (fake) return { ok: true, text: typeof fake === 'function' ? fake() : String(fake), engine: 'test' };
  const parts = [];
  for (const u of list) { const r = await recognizeText(u, { rows }); if (r.ok) parts.push(r.text); }
  if (parts.length) return { ok: true, text: parts.join('\n'), engine: 'device' };
  if (!cloud) return { ok: false, message: 'The photo could not be read on this device.' };
  let s = {};
  try { s = getSettings() || {}; } catch (e) { s = {}; }
  if (!s.cloudUrl) return { ok: false, message: 'The photo could not be read on this device, and it is not linked to the Easy Buys cloud. Please type the details.' };
  try {
    const files = [];
    for (const u of list) if (await fileExists(u)) files.push({ mimeType: 'image/jpeg', data: await fileBase64(u) });
    if (!files.length) return { ok: false, message: 'The photo file was not found on this device.' };
    const r = await cloudCall({ kind: 'ocr', files }, 180000);
    if (r && r.off) return { ok: false, message: "Google's photo reading is not switched on in the cloud yet. Please type the details." };
    return r && r.text ? { ok: true, text: r.text, engine: 'cloud' } : { ok: false, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  } catch (e) {
    const m = e && e.message ? e.message : String(e);
    return { ok: false, message: /network|fetch|abort|timed/i.test(m) ? 'No internet right now and the photo could not be read on this device. Please type the details.' : m };
  }
}

// ctx: { supplierUid, poUid, receiptUid, invoiceUid }
export async function readInvoicePhotos(user, uris, ctx = {}) {
  const t = await readPhotosText(uris);
  if (!t.ok) return t;
  const result = readInvoiceText(t.text, ctx);
  const readUid = saveRead(user, { ...ctx, supplierUid: result.supplierUid || ctx.supplierUid, engine: t.engine, text: t.text, result });
  return { ok: true, engine: t.engine, text: t.text, result, readUid,
    message: `${t.engine === 'device' ? 'Read on this device' : 'Read by Google'} – ${result.lines.length} line(s) found. Please check them.` };
}

// An invoice already entered (with photos): read it on the device; if that fails, Google reads it (as before).
export async function readInvoiceOnDevice(user, invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText, getInvoice } = require('../modules/payables/service.js');
  const uris = listPhotos('invoice', invoiceUid).map((p) => p.uri);
  const t = await readPhotosText(uris, { cloud: false });
  if (!t.ok) return readInvoiceNow(invoiceUid);
  const inv = applyReadText(invoiceUid, t.text);
  const result = readInvoiceText(t.text, { supplierUid: inv && inv.supplier_uid, poUid: inv && inv.po_uid, invoiceUid });
  saveRead(user, { invoiceUid, supplierUid: result.supplierUid, poUid: inv && inv.po_uid, engine: 'device', text: t.text, result });
  const fresh = getInvoice(invoiceUid);
  return { ok: true, invoice: fresh, result, engine: 'device', message: fresh && fresh.total ? 'Read on this device – please check the figures.' : 'Read on this device, but the total was not found. Please type it.' };
}
