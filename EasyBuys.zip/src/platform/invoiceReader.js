// Reading invoice photos and PDFs. 1.0.0: online, the AI in the owner's cloud reads them (Google Gemini through the
// Apps Script, cloud/Code.gs invoice_ai); offline – or when the cloud has no AI key, or the AI fails – they are read
// on this phone (ML Kit), and Google's text reading is the backup when the phone's reading is weak.
// The flow itself is in services/invoiceReadFlow.js (tested in Node); this file gives it the camera files, ML Kit and the cloud.
// Service functions for any screen (receiving, invoices, the photo-of-invoice screen):
//   readPhotosText(uris, { cloud, rows })   → { ok, text, engine: 'device' | 'cloud', pageErrors, message }  (text only)
//   readInvoiceFiles(uris, { hints })       → { ok, engine: 'ai' | 'device' | 'cloud', ai, text, label, aiPending, message }
//   readInvoicePhotos(user, uris, ctx)      → also the item lines matched to the order / delivery, saved as a reading
//   readInvoiceOnDevice(user, invoiceUid)   → fills in an entered invoice from its photos (AI first, then the phone)
import { recognizeText } from './textRecognition.js';
import { cloudCall } from './cloud.js';
import { fileBase64, fileExists } from './files.js';
import { getSettings, dateStr } from '../services/core.js';
import { readInvoiceText, saveRead } from '../modules/inventory/invoiceRead.js';
import * as Flow from '../services/invoiceReadFlow.js';
import { aiHints } from '../services/invoiceAi.js';

export const readerDeps = {
  cloudUrl: () => { try { return (getSettings() || {}).cloudUrl || ''; } catch (e) { return ''; } },
  cloudCall: (body, ms) => cloudCall(body, ms),
  recognizeText: (uri, o) => recognizeText(uri, o),
  fileBase64: (uri) => fileBase64(uri),
  // 1.0.0 build 4: a lighter copy for the AI – 1500 px wide, JPEG 0.7 (about a third of the size, still sharp to read)
  aiCopyBase64: async (uri) => {
    const IM = require('expo-image-manipulator');
    const r = await IM.manipulateAsync(uri, [{ resize: { width: 1500 } }], { compress: 0.7, format: IM.SaveFormat.JPEG, base64: true });
    return r && r.base64 ? r.base64 : null;
  },
  fileExists: (uri) => fileExists(uri),
  today: () => dateStr(),
};

function vatRate() {
  try { return (Number(require('../modules/payables/service.js').apRules().vatRate) || 12.5) / 100; } catch (e) { return 0.125; }
}
// What the AI is told: the known suppliers, the buyer (Easy Buys, never the supplier) and the VAT rate.
export function invoiceHints() {
  let sups = [];
  try { sups = require('../modules/payables/service.js').listSuppliers(); } catch (e) { sups = []; }
  return aiHints(sups, vatRate());
}

export async function readPhotosText(uris = [], { cloud = true, rows = false } = {}) {
  return Flow.readPhotosText(uris, { cloud, rows, deps: readerDeps });
}

export async function readInvoiceFiles(uris = [], { hints, rows = true } = {}) {
  return Flow.readInvoiceFiles(uris, { hints: hints || invoiceHints(), rows, deps: readerDeps });
}

// ctx: { supplierUid, poUid, receiptUid, invoiceUid }
export async function readInvoicePhotos(user, uris, ctx = {}) {
  const t = await readInvoiceFiles(uris);
  if (!t.ok) return t;
  const result = readInvoiceText(t.text, ctx, t.ai || null);
  result.engine = t.engine;
  result.engineLabel = t.label;
  if (t.aiPending) result.aiPending = true;
  if (t.pageErrors && t.pageErrors.length) result.flags.push(...t.pageErrors);
  const readUid = saveRead(user, { ...ctx, supplierUid: result.supplierUid || ctx.supplierUid, engine: t.engine, text: t.text, result });
  return { ok: true, engine: t.engine, label: t.label, aiPending: !!t.aiPending, text: t.text, result, readUid,
    message: `${t.label} – ${result.lines.length} line(s) found. Please check them.${t.aiPending ? ' AI re-read when online.' : ''}${t.why ? ` ${t.why}` : ''}` };
}

// An invoice already entered (with photos): the AI reads it (or this phone, offline) and the invoice is filled in.
export async function readInvoiceOnDevice(user, invoiceUid) {
  const { listPhotos } = require('../services/stock.js');
  const { applyReadText, getInvoice } = require('../modules/payables/service.js');
  const uris = listPhotos('invoice', invoiceUid).map((p) => p.uri);
  const t = await readInvoiceFiles(uris);
  if (!t.ok) { applyReadText(invoiceUid, ''); return { ok: false, message: t.message }; }
  const inv = applyReadText(invoiceUid, t.text);
  const result = readInvoiceText(t.text, { supplierUid: inv && inv.supplier_uid, poUid: inv && inv.po_uid, invoiceUid }, t.ai || null);
  result.engine = t.engine;
  saveRead(user, { invoiceUid, supplierUid: result.supplierUid, poUid: inv && inv.po_uid, engine: t.engine, text: t.text, result });
  const fresh = getInvoice(invoiceUid);
  return { ok: true, invoice: fresh, result, engine: t.engine, label: t.label, aiPending: !!t.aiPending,
    message: `${t.label}${fresh && fresh.total ? ' – please check the figures.' : ', but the total was not found. Please type it.'}${t.aiPending ? ' AI re-read when online.' : ''}` };
}
