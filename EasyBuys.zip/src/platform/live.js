// Release 07 – the live connection. While the app or the website is open and linked, it keeps a WebSocket to the
// Easy Buys cloud on Cloudflare (cloud script 42+). The cloud never sends data over it, only "changed" when another
// device's change is accepted; this device then syncs at once (a second or two instead of the next 1-minute sync).
// Its own saves are sent straight away too (onLocalSave → sync within ~2 seconds). Without the connection everything
// still works: the regular sync and the two-way check carry on.
import { getSettings, getSetting } from '../services/core.js';

let ws = null;
let timer = null;
let pinger = null;
let backoff = 3000;
let stopped = true;
let soon = null;
let deps = null;

const wsUrl = (cloudUrl, ticket) => {
  const u = String(cloudUrl || '').replace(/\/+$/, '').replace(/^http/i, 'ws');
  return `${u}/live?ticket=${encodeURIComponent(ticket)}`;
};
// d: { post(body, ms), sync(), canLive() }
export function startLive(d) {
  deps = d;
  if (!stopped) return;
  stopped = false;
  connect();
}
export function stopLive() {
  stopped = true;
  clearTimeout(timer); clearInterval(pinger);
  try { if (ws) ws.close(); } catch (e) { /* closed */ }
  ws = null;
}
export function liveState() { return { on: !!(ws && ws.readyState === 1) }; }
function later(ms) { clearTimeout(timer); if (!stopped) timer = setTimeout(connect, ms); }
async function connect() {
  if (stopped || !deps) return;
  try {
    const s = getSettings();
    if (!s.cloudUrl || !getSetting('cloud_token', '') || Number(getSetting('cloud_script_version', '0')) < 42 || (deps.canLive && !deps.canLive()) || typeof WebSocket === 'undefined') { later(60000); return; }
    const t = await deps.post({ kind: 'live_ticket' }, 20000);
    if (!t || !t.ok || !t.ticket) { later(Math.min(backoff *= 2, 120000)); return; }
    const sock = new WebSocket(wsUrl(s.cloudUrl, t.ticket));
    ws = sock;
    sock.onopen = () => {
      backoff = 3000;
      clearInterval(pinger);
      pinger = setInterval(() => { try { if (sock.readyState === 1) sock.send('ping'); } catch (e) { /* closed */ } }, 30000);
      nudge(500); // anything missed while it was not connected
    };
    sock.onmessage = (ev) => { if (String(ev && ev.data) !== 'pong') nudge(400); };
    sock.onclose = () => { clearInterval(pinger); if (ws === sock) ws = null; later(Math.min(backoff *= 2, 60000)); };
    sock.onerror = () => { try { sock.close(); } catch (e) { /* closed */ } };
  } catch (e) { later(Math.min(backoff *= 2, 120000)); }
}
// sync soon (several nudges together make one sync)
export function nudge(ms = 400) {
  if (!deps) return;
  clearTimeout(soon);
  soon = setTimeout(() => { Promise.resolve(deps.sync()).catch(() => {}); }, ms);
}
