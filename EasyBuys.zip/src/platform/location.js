// The phone's position (1.0.0 build 26, deliveries GPS). expo-location is loaded only when there (tests and old
// builds have none): every call answers null when the phone cannot say where it is (no permission, GPS off, indoors).
let L = null;
function lib() {
  if (L !== null) return L || null;
  try { L = require('expo-location'); } catch (e) { L = false; }
  return L || null;
}
export const hasLocation = () => !!lib();
// Asks once (Android shows its own question). → true when allowed.
export async function askLocation() {
  const x = lib();
  if (!x) return false;
  try { const r = await x.requestForegroundPermissionsAsync(); return r && r.status === 'granted'; } catch (e) { return false; }
}
// One reading, at most `ms` long. → { lat, lng, accuracy, speed, at } or null.
export async function where(ms = 15000) {
  const x = lib();
  if (!x) return null;
  try {
    const p = await Promise.race([x.getCurrentPositionAsync({ accuracy: x.Accuracy ? x.Accuracy.High : 4 }), new Promise((res) => setTimeout(() => res(null), ms))]);
    if (!p || !p.coords) return null;
    return { lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, speed: p.coords.speed, at: p.timestamp };
  } catch (e) { return null; }
}
// Readings while a screen is open: every `ms` or `metres` moved. → stop()
export async function follow(onPos, { ms = 30000, metres = 40 } = {}) {
  const x = lib();
  if (!x) return () => {};
  try {
    const sub = await x.watchPositionAsync({ accuracy: x.Accuracy ? x.Accuracy.High : 4, timeInterval: ms, distanceInterval: metres },
      (p) => { if (p && p.coords) onPos({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, speed: p.coords.speed, at: p.timestamp }); });
    return () => { try { sub.remove(); } catch (e) { /* gone */ } };
  } catch (e) { return () => {}; }
}
