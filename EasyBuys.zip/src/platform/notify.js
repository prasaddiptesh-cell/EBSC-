// Sound + pop-up reminders for batch steps (cutting, proofing, baking, finished),
// so bakers are alerted even if the app is in the background.
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { listActiveBatches } from '../services/batches.js';
import { parseStamp, clock } from '../services/core.js';

const CHANNEL = 'batch-steps';
let ready = false;

export async function setupNotifications() {
  try {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowAlert: true }),
    });
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync(CHANNEL, {
        name: 'Batch step reminders',
        importance: Notifications.AndroidImportance.MAX,
        sound: 'default',
        vibrationPattern: [0, 600, 300, 600, 300, 600],
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
    }
    const cur = await Notifications.getPermissionsAsync();
    if (!cur.granted) await Notifications.requestPermissionsAsync();
    ready = true;
  } catch (e) {
    ready = false;
  }
}

// Cancels all reminders and schedules fresh ones for every open batch:
// at the due time, then again 5 and 10 minutes later if nobody has confirmed.
export async function rescheduleReminders() {
  if (!ready) return;
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const now = clock.now().getTime();
    for (const b of listActiveBatches()) {
      if (!b.nextStep || !b.dueAt) continue;
      const due = parseStamp(b.dueAt).getTime();
      for (const extra of [0, 5, 10]) {
        const at = due + extra * 60000;
        if (at <= now + 2000) continue;
        const cur = b.currentStep ? b.currentStep.name : 'Step';
        const what = b.currentStep && b.currentStep.kind === 'mix' ? 'Mixing should be done – check the mix'
          : b.nextStep.kind === 'finish' ? `${cur} should be done – enter production` : `${cur} should be done – next: ${b.nextStep.name}`;
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `${extra ? '⏰ Reminder: ' : ''}${what} – ${b.product_name}`,
            body: `${b.code} · ${b.nextStep.kind === 'cut' ? `Cut at ${b.cut_weight_g} g per piece (about ${b.expected_pieces} pieces). ` : ''}${b.nextStep.kind === 'bake' && b.decks && b.decks.length ? `Ovens: ${b.decks.map((d) => `${d.deck} top ${d.top ?? '–'}° / bottom ${d.bottom ?? '–'}°`).join(', ')}. ` : ''}${b.cut_pieces === null && b.steps.some((s) => s.kind === 'cut' && s.started_at) ? 'Enter the pieces cut. ' : ''}Open the app to confirm or snooze.`,
            sound: 'default',
            data: { batchId: b.id },
          },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(at), channelId: CHANNEL },
        });
      }
    }
  } catch (e) {
    // Reminders are a convenience; the in-app pop-up still works without them.
  }
}

export function setKeepAwake(on) {
  try {
    if (on) activateKeepAwakeAsync('bakery');
    else deactivateKeepAwake('bakery');
  } catch (e) {
    // ignore
  }
}
