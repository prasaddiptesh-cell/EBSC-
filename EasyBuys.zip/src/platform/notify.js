// Sound + pop-up reminders for batch steps (cutting, proofing, baking, finished),
// so bakers are alerted even if the app is in the background.
import { Platform, Linking } from 'react-native';
import * as Notifications from 'expo-notifications';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { listActiveBatches } from '../services/batches.js';
import { parseStamp, clock } from '../services/core.js';
import { licenceAlerts, alertText } from '../modules/licences/service.js';

const CHANNEL = 'batch-steps';
// v3.6: new channel ids – Android keeps a channel's sound for ever, so the softer chimes need new channels.
const URGENT_CHANNEL = 'urgent-alerts-2';
const WARN_CHANNEL = 'warnings-2';
let ready = false;

export async function setupNotifications() {
  try {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false, shouldShowAlert: true }),
    });
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync(CHANNEL, {
        name: 'Batch step reminders',
        importance: Notifications.AndroidImportance.MAX,
        sound: 'default',
        vibrationPattern: [0, 600, 300, 600, 300, 600],
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
    }
    if (Platform.OS === 'android') {
      // Urgent warnings: alarm-style (full volume, vibration, on the lock screen, through Do Not Disturb once the
      // owner allows it in Admin › Alerts & sounds).
      for (const old of ['urgent-alerts', 'warnings']) { try { await Notifications.deleteNotificationChannelAsync(old); } catch (e) { /* not there */ } }
      await Notifications.setNotificationChannelAsync(URGENT_CHANNEL, {
        name: 'Urgent warnings',
        importance: Notifications.AndroidImportance.MAX,
        sound: 'urgent_bell.mp3',
        bypassDnd: true,
        enableVibrate: true,
        vibrationPattern: [0, 800, 400, 800, 400, 800],
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
      await Notifications.setNotificationChannelAsync(WARN_CHANNEL, {
        name: 'Warnings',
        importance: Notifications.AndroidImportance.HIGH,
        sound: 'warning_bell.mp3',
        lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      });
    }
    const cur = await Notifications.getPermissionsAsync();
    if (!cur.granted) await Notifications.requestPermissionsAsync();
    ready = true;
  } catch (e) {
    ready = false;
  }
}

// Cancels all reminders and schedules fresh ones for every open batch:
// at the due time, then again 5 and 10 minutes later if nobody has confirmed.
export async function rescheduleReminders() {
  if (!ready) return;
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const now = clock.now().getTime();
    for (const b of listActiveBatches()) {
      if (!b.nextStep || !b.dueAt) continue;
      const due = parseStamp(b.dueAt).getTime();
      for (const extra of [0, 5, 10]) {
        const at = due + extra * 60000;
        if (at <= now + 2000) continue;
        const cur = b.currentStep ? b.currentStep.name : 'Step';
        const what = b.currentStep && b.currentStep.kind === 'mix' ? 'Mixing should be done – check the mix'
          : b.nextStep.kind === 'finish' ? `${cur} should be done – enter production` : `${cur} should be done – next: ${b.nextStep.name}`;
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `${extra ? '⏰ Reminder: ' : ''}${what} – ${b.product_name}`,
            body: `${b.code} · ${b.nextStep.kind === 'cut' ? `Cut at ${b.cut_weight_g} g per piece (about ${b.expected_pieces} pieces). ` : ''}${b.nextStep.kind === 'bake' && b.decks && b.decks.length ? `Ovens: ${b.decks.map((d) => `${d.deck} top ${d.top ?? '–'}° / bottom ${d.bottom ?? '–'}°`).join(', ')}. ` : ''}${b.cut_pieces === null && b.steps.some((s) => s.kind === 'cut' && s.started_at) ? 'Enter the pieces cut. ' : ''}Open the app to confirm or snooze.`,
            sound: 'default',
            data: { batchId: b.id },
          },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(at), channelId: CHANNEL },
        });
      }
    }
    // Licences and permits due for renewal: a reminder at 9 o'clock on the next two mornings.
    try {
      const a = licenceAlerts();
      const n = a.overdue.length + a.due.length;
      if (n) {
        for (const k of [1, 2]) {
          const at = new Date(clock.now()); at.setDate(at.getDate() + k); at.setHours(9, 0, 0, 0);
          await Notifications.scheduleNotificationAsync({
            content: { title: a.overdue.length ? `⚠️ ${a.overdue.length} licence / permit expired` : `📜 ${n} licence / permit to renew soon`, body: a.list.slice(0, 3).map(alertText).join('\n'), sound: 'default', data: { screen: 'Licences' } },
            trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: at, channelId: CHANNEL },
          });
        }
      }
    } catch (e) { /* licences module not in use */ }
  } catch (e) {
    // Reminders are a convenience; the in-app pop-up still works without them.
  }
}

export function setKeepAwake(on) {
  try {
    if (on) { const p = activateKeepAwakeAsync('bakery'); if (p && p.catch) p.catch(() => {}); } // the website: the browser may refuse
    else deactivateKeepAwake('bakery');
  } catch (e) {
    // ignore
  }
}

// A phone notification for a warning (urgent ones on the alarm-style channel). Shown straight away.
export async function notifyAlert(alert) {
  if (!ready || !alert) return false;
  try {
    await Notifications.scheduleNotificationAsync({
      content: { title: `${alert.level === 'urgent' ? '🚨 Urgent' : '⚠️ Warning'}: ${alert.text}`, body: alert.sub || 'Open Easy Buys to see it.', sound: alert.level === 'urgent' ? 'urgent_bell.mp3' : 'warning.wav',
        data: { screen: alert.nav ? alert.nav.screen : null, alertId: alert.id }, priority: 'max' },
      trigger: Platform.OS === 'android' ? { channelId: alert.level === 'urgent' ? URGENT_CHANNEL : WARN_CHANNEL } : null,
    });
    return true;
  } catch (e) { return false; }
}
// Opens Android's "Do Not Disturb access" page so the owner can let urgent warnings ring through.
export async function openDndSettings() {
  try {
    if (Platform.OS === 'android' && Linking.sendIntent) { await Linking.sendIntent('android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS'); return true; }
  } catch (e) { /* fall through */ }
  try { await Linking.openSettings(); return true; } catch (e) { return false; }
}
