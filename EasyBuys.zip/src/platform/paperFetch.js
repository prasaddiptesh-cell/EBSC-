// 1.0.0 Opening a paper on Today: the phone's own copy when it is still there, else fetched from Google Drive (the
// cloud's file_get) and kept on the phone (papers/<drive id>). See src/modules/verify/papers.js (resolvePaper).
import * as FS from 'expo-file-system/legacy';
import { fileExists } from './files.js';
import { cloudCall } from './cloud.js';
import { resolvePaper } from '../modules/verify/papers.js';
import { appUser } from '../services/errorLog.js';

const dir = () => `${FS.documentDirectory}papers/`;
const pathFor = (id, pdf) => `${dir()}${String(id).replace(/[^A-Za-z0-9_-]/g, '')}.${pdf ? 'pdf' : 'jpg'}`;
const known = new Map(); // drive id → local uri, this session

export const paperIO = {
  exists: (uri) => fileExists(uri),
  async cached(id) {
    if (known.has(id)) return known.get(id);
    for (const pdf of [false, true]) { const p = pathFor(id, pdf); try { const i = await FS.getInfoAsync(p); if (i && i.exists) { known.set(id, p); return p; } } catch (e) { /* not kept */ } }
    return null;
  },
  async fetch(id) {
    const u = appUser();
    const r = await cloudCall({ kind: 'file_get', id, user: u ? { uid: u.uid, role: u.role } : undefined }, 120000);
    if (!r || r.ok === false || !r.data) throw new Error((r && r.error) || 'Google Drive sent nothing back.');
    return r.data;
  },
  async save(id, data, pdf) {
    try { await FS.makeDirectoryAsync(dir(), { intermediates: true }); } catch (e) { /* already there */ }
    const p = pathFor(id, pdf);
    await FS.writeAsStringAsync(p, data, { encoding: FS.EncodingType.Base64 });
    known.set(id, p);
    return p;
  },
};
export const openPaper = (p) => resolvePaper(p, paperIO);
// A PDF (an invoice sent as a PDF) opens in the phone's PDF viewer.
export async function openPdf(uri) {
  const Sharing = require('expo-sharing');
  if (!(await Sharing.isAvailableAsync())) throw Object.assign(new Error('Opening PDF files is not available on this device.'), { isAppError: true });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', dialogTitle: 'Invoice (PDF)' });
}
