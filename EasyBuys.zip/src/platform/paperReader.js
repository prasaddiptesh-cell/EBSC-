// v3.9.2 Read a photo of paper and work out the boxes for the screen (see services/paperRead.js).
// 1.0.0 invoices and fuel receipts: the AI in the owner's cloud reads them when online (photos and PDFs); offline, or
// when the AI is not switched on, they are read on this phone. Other papers are read on this phone, with Google's
// text reading as the backup when this phone cannot read them.
import { readPhotosText, readInvoiceFiles, invoiceHints } from './invoiceReader.js';
import { readPaperText, readPaperAi, AI_PAPER_KINDS } from '../services/paperRead.js';
import { engineLabel } from '../services/invoiceReadFlow.js';

const NAMES = { cheque: 'cheque', z: 'Z report', invoice: 'invoice or receipt', fuel: 'fuel receipt', deposit: 'deposit slip', lodgement: 'lodgement receipt', proof: 'payment proof', aronium: 'Aronium receipt', loan: 'loan receipt', efl_bill: 'bill' };

function context(kind) {
  const ctx = {};
  try { const T = require('../modules/till/service.js'); ctx.tenders = T.tillRules().tenders; } catch (e) { ctx.tenders = []; }
  try { const AP = require('../modules/payables/service.js'); ctx.vatRate = (Number(AP.apRules().vatRate) || 12.5) / 100; } catch (e) { ctx.vatRate = 0.125; }
  try { ctx.today = require('../services/core.js').dateStr(); } catch (e) { /* the device date */ }
  if (kind === 'invoice' || kind === 'fuel') {
    try { ctx.suppliers = require('../modules/payables/service.js').listSuppliers().map((s) => ({ uid: s.uid, name: s.name, tin: s.tin, phone: s.phone })); } catch (e) { ctx.suppliers = []; }
  }
  return ctx;
}

// → { ok, read: { fields, from, checks, found }, engine, label, aiPending, text, message }
export async function readPaper(kind, uris, extra = {}) {
  // build 31: a cheque – the AI reads its number, amount, payee and date (services/chequeRead.js)
  if (kind === 'cheque') {
    const { readCheque } = require('../services/chequeRead.js');
    const { readerDeps } = require('./invoiceReader.js');
    let suppliers = [];
    try { suppliers = require('../modules/payables/service.js').listSuppliers().map((s) => ({ uid: s.uid, name: s.name })); } catch (e) { suppliers = []; }
    return readCheque(uris, { ...readerDeps, suppliers, today: readerDeps.today(), stub: !!(extra && extra.stub), readText: (u) => readPhotosText(u, { rows: true }) });
  }
  const what = NAMES[kind] || 'paper';
  const ai = AI_PAPER_KINDS.includes(kind);
  let t;
  // 1.0.0 build 54: a power / water bill is read by the same AI, told it is an EFL or WAF bill (account number, due date)
  const hints = () => (kind === 'efl_bill' ? { ...invoiceHints(), bill: extra && extra.billKind === 'water' ? 'water' : extra && extra.billKind === 'power' ? 'power' : 'any' } : invoiceHints());
  try { t = ai ? await readInvoiceFiles(uris, { hints: hints(), rows: true }) : await readPhotosText(uris, { rows: true }); } catch (e) { t = { ok: false, message: e && e.message ? e.message : String(e) }; }
  if (!t || !t.ok) return { ok: false, message: (t && t.message ? t.message : 'The photo could not be read.').replace(/the invoice/g, `the ${what}`) };
  const ctx = { ...context(kind), ...extra };
  const read = (t.ai && readPaperAi(kind, t.ai, ctx)) || readPaperText(kind, t.text, ctx);
  // Release 06: the item lines the AI read are kept with the reading (the supplier's products are paired from them)
  if (t.ai && read && Array.isArray(t.ai.lines) && t.ai.lines.length) { try { read.itemLines = require('../services/invoiceAi.js').aiItemLines(t.ai); } catch (e) { /* header only */ } }
  for (const p of t.pageErrors || []) read.checks.push({ level: 'warn', text: p });
  if (t.why) read.checks.push({ level: 'warn', text: t.why });
  const label = t.label || engineLabel(t.engine);
  if (!read.found) return { ok: false, read, engine: t.engine, label, text: t.text, message: `Nothing could be read from the ${what}. Take the photo again flat, in good light, the whole paper in the picture – or type the figures.` };
  return { ok: true, read, engine: t.engine, label, aiPending: !!t.aiPending, text: t.text };
}
