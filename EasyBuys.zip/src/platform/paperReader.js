// v3.9.2 Read a photo of paper and work out the boxes for the screen (see services/paperRead.js).
// On the tablet first (offline); Google's cloud reading only as a backup when this tablet cannot read it.
import { readPhotosText } from './invoiceReader.js';
import { readPaperText } from '../services/paperRead.js';

const NAMES = { z: 'Z report', invoice: 'invoice or receipt', fuel: 'fuel receipt', deposit: 'deposit slip', lodgement: 'lodgement receipt', proof: 'payment proof', aronium: 'Aronium receipt', loan: 'loan receipt' };

function context(kind) {
  const ctx = {};
  try { const T = require('../modules/till/service.js'); ctx.tenders = T.tillRules().tenders; } catch (e) { ctx.tenders = []; }
  try { const AP = require('../modules/payables/service.js'); ctx.vatRate = (Number(AP.apRules().vatRate) || 12.5) / 100; } catch (e) { ctx.vatRate = 0.125; }
  if (kind === 'invoice' || kind === 'fuel') {
    try { ctx.suppliers = require('../modules/payables/service.js').listSuppliers().map((s) => ({ uid: s.uid, name: s.name, tin: s.tin })); } catch (e) { ctx.suppliers = []; }
  }
  return ctx;
}

// → { ok, read: { fields, from, checks, found }, engine, text, message }
export async function readPaper(kind, uris, extra = {}) {
  const what = NAMES[kind] || 'paper';
  let t;
  try { t = await readPhotosText(uris, { rows: true }); } catch (e) { t = { ok: false, message: e && e.message ? e.message : String(e) }; }
  if (!t || !t.ok) return { ok: false, message: (t && t.message ? t.message : 'The photo could not be read.').replace(/the invoice/g, `the ${what}`) };
  const read = readPaperText(kind, t.text, { ...context(kind), ...extra });
  if (!read.found) return { ok: false, read, engine: t.engine, text: t.text, message: `Nothing could be read from the ${what}. Take the photo again flat, in good light, the whole paper in the picture – or type the figures.` };
  return { ok: true, read, engine: t.engine, text: t.text };
}
