// Phone-only parts of payroll v3.5: one-tap Viber share of a payslip, printing a payslip, choosing an official
// FRCS / FNPF template file, and sharing a filing file (CSV / Excel in the template's own layout).
// Each has a safe fallback (Android share sheet, or a plain error message) when the native part is missing.
import { Linking, Share } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { printReport, shareReport } from './files.js';
import { pickStatementFile } from './statementFiles.js';
import { tableCsv, tableXlsxBase64 } from '../modules/payroll/filing.js';

const safe = (name) => String(name).replace(/[^A-Za-z0-9._-]+/g, '-').slice(0, 80);

// Viber first: opens Viber's "forward" screen with the payslip text; without Viber, the normal share sheet.
export async function sharePayslipViber({ url, text }) {
  try {
    if (url && (await Linking.canOpenURL(url))) { await Linking.openURL(url); return 'viber'; }
  } catch (e) { /* no Viber – fall back */ }
  await Share.share({ message: text || '' });
  return 'share';
}
export async function printPayslip(rep) { await printReport(rep); }
export async function sharePayslipPdf(rep) { return shareReport(rep, 'pdf'); }

// The official template: Excel (rows) or CSV (text). Returns { name, kind, rows?, text? } or null when cancelled.
export async function pickFilingTemplate() {
  const f = await pickStatementFile({ ocr: false });
  if (!f) return null;
  if (f.kind !== 'xlsx' && f.kind !== 'text') throw new Error('Choose the Excel (.xlsx) or CSV file from FRCS / FNPF.');
  return f;
}

// Share the filing in the template's own columns.
export async function shareFilingTable({ fileName, headers, rows, fileType = 'csv' }) {
  let uri;
  if (fileType === 'xlsx') {
    const b64 = await tableXlsxBase64(headers, rows);
    uri = `${FileSystem.cacheDirectory}${safe(fileName)}.xlsx`;
    await FileSystem.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
  } else {
    uri = `${FileSystem.cacheDirectory}${safe(fileName)}.csv`;
    await FileSystem.writeAsStringAsync(uri, '﻿' + tableCsv(headers, rows), { encoding: FileSystem.EncodingType.UTF8 });
  }
  if (!(await Sharing.isAvailableAsync())) throw new Error('Sharing is not available on this device.');
  await Sharing.shareAsync(uri, { mimeType: fileType === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'text/csv', dialogTitle: fileName });
  return uri;
}
