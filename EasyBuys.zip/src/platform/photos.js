// Taking photos (invoices, wastage, rejected products) and keeping them in the app's own storage.
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';

// v3.9.3 photos are made smaller before they are kept (long side at most 2000 px – still sharp for reading the text):
// a full-size phone photo is 2–4 MB; hundreds a month would fill the tablet and slow the sync.
const MAX_SIDE = 2000;
async function shrink(asset) {
  try {
    const w = Number(asset.width) || 0; const h = Number(asset.height) || 0;
    if (!w || !h || Math.max(w, h) <= MAX_SIDE) return asset.uri;
    const resize = w >= h ? { width: MAX_SIDE } : { height: MAX_SIDE };
    const r = await ImageManipulator.manipulateAsync(asset.uri, [{ resize }], { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG });
    return r && r.uri ? r.uri : asset.uri;
  } catch (e) { return asset.uri; } // never lose the photo because it could not be made smaller
}

const DIR = `${FileSystem.documentDirectory}photos/`;

export async function keep(uri) {
  await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
  const target = `${DIR}${Date.now()}-${Math.floor(Math.random() * 1e6)}.jpg`;
  await FileSystem.copyAsync({ from: uri, to: target });
  return target;
}

// source: 'camera' | 'library'. Returns the saved file uri, or null if cancelled.
export async function takePhoto(source = 'camera') {
  if (source === 'camera') {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) throw new Error('Camera permission was not given. Allow it in Android Settings → Apps → Easy Buys → Permissions.');
    const r = await ImagePicker.launchCameraAsync({ quality: 0.5, allowsEditing: false, exif: false });
    if (r.canceled || !r.assets || !r.assets.length) return null;
    return keep(await shrink(r.assets[0]));
  }
  const p = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!p.granted) throw new Error('Photo library permission was not given.');
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.5, allowsMultipleSelection: false });
  if (r.canceled || !r.assets || !r.assets.length) return null;
  return keep(await shrink(r.assets[0]));
}
