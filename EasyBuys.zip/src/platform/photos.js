// Taking photos (invoices, wastage, rejected products) and keeping them in the app's own storage.
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';

const DIR = `${FileSystem.documentDirectory}photos/`;

export async function keep(uri) {
  await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
  const target = `${DIR}${Date.now()}-${Math.floor(Math.random() * 1e6)}.jpg`;
  await FileSystem.copyAsync({ from: uri, to: target });
  return target;
}

// source: 'camera' | 'library'. Returns the saved file uri, or null if cancelled.
export async function takePhoto(source = 'camera') {
  if (source === 'camera') {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) throw new Error('Camera permission was not given. Allow it in Android Settings → Apps → Easy Buys → Permissions.');
    const r = await ImagePicker.launchCameraAsync({ quality: 0.5, allowsEditing: false, exif: false });
    if (r.canceled || !r.assets || !r.assets.length) return null;
    return keep(r.assets[0].uri);
  }
  const p = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!p.granted) throw new Error('Photo library permission was not given.');
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.5, allowsMultipleSelection: false });
  if (r.canceled || !r.assets || !r.assets.length) return null;
  return keep(r.assets[0].uri);
}
