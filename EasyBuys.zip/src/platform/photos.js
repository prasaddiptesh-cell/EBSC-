// Taking photos (invoices, wastage, rejected products) and keeping them in the app's own storage.
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as ImageManipulator from 'expo-image-manipulator';
import * as DocumentPicker from 'expo-document-picker';

// 1.0.0 photos are kept sharp enough to read: quality 0.85, and only made smaller when the SHORT side is over 1600 px
// (so it stays at least 1600 px). Before, the long side was cut to 2000 px at 0.6, which made a long till receipt or a
// 3-column invoice unreadable. A 12 MP phone photo becomes about 2130 × 1600 px (0.5–0.9 MB).
export const READ_QUALITY = 0.85;
export const MIN_SHORT_SIDE = 1600;
export function targetSize(w, h) {
  w = Number(w) || 0; h = Number(h) || 0;
  if (!w || !h || Math.min(w, h) <= MIN_SHORT_SIDE) return null; // small enough already: kept as it is
  return w <= h ? { width: MIN_SHORT_SIDE } : { height: MIN_SHORT_SIDE };
}
async function shrink(asset) {
  try {
    const resize = targetSize(asset.width, asset.height);
    if (!resize) return asset.uri;
    const r = await ImageManipulator.manipulateAsync(asset.uri, [{ resize }], { compress: READ_QUALITY, format: ImageManipulator.SaveFormat.JPEG });
    return r && r.uri ? r.uri : asset.uri;
  } catch (e) { return asset.uri; } // never lose the photo because it could not be made smaller
}

const DIR = `${FileSystem.documentDirectory}photos/`;

export async function keep(uri, ext = 'jpg') {
  await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
  const target = `${DIR}${Date.now()}-${Math.floor(Math.random() * 1e6)}.${ext}`;
  await FileSystem.copyAsync({ from: uri, to: target });
  return target;
}

// 1.0.0 build 20: papers (invoices, receipts, slips) – Google's document scanner on this phone finds the paper's edges,
// takes it by itself and crops it straight; before Done the corners can be dragged, the page turned, more pages added.
// Without it (older app, no Google Play services) the camera opens with a crop box after the photo.
// (read straight from Expo's native modules – the app is still built if modules/doc-scanner is left out)
function nativeScanner() { try { return globalThis.expo && globalThis.expo.modules ? globalThis.expo.modules.DocScanner || null : null; } catch (e) { return null; } }
export function hasDocScanner() { return !!nativeScanner(); }
async function keepScanned(uri) {
  let asset = { uri };
  try { const r = await ImageManipulator.manipulateAsync(uri, [], { compress: READ_QUALITY, format: ImageManipulator.SaveFormat.JPEG }); if (r && r.uri) asset = r; } catch (e) { /* keep as it is */ }
  return keep(await shrink(asset));
}
// → [uris] (empty when the person backed out), or null when the scanner is not on this phone.
export async function scanDocument({ pages = 1, gallery = true } = {}) {
  const m = nativeScanner();
  if (!m || typeof m.scan !== 'function') return null;
  let list;
  try { list = await m.scan(Math.max(1, Math.min(20, Number(pages) || 1)), !!gallery); } catch (e) { return null; } // not available here: a plain photo
  const out = [];
  for (const u of list || []) out.push(await keepScanned(String(u)));
  return out;
}

// source: 'camera' | 'library'. Returns the saved file uri, or null if cancelled.
// crop: build 20 – the crop box shows after the photo (papers, when the document scanner is not on this phone).
export async function takePhoto(source = 'camera', { crop = false } = {}) {
  if (source === 'camera') {
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) throw Object.assign(new Error('Camera permission was not given. Allow it in Android Settings → Apps → Easy Buys → Permissions.'), { isAppError: true });
    const r = await ImagePicker.launchCameraAsync({ quality: READ_QUALITY, allowsEditing: !!crop, exif: false });
    if (r.canceled || !r.assets || !r.assets.length) return null;
    return keep(await shrink(r.assets[0]));
  }
  const p = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!p.granted) throw Object.assign(new Error('Photo library permission was not given.'), { isAppError: true });
  const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: READ_QUALITY, allowsMultipleSelection: false, allowsEditing: !!crop });
  if (r.canceled || !r.assets || !r.assets.length) return null;
  return keep(await shrink(r.assets[0]));
}

// 1.0.0 an invoice the supplier sent as a PDF (email, Viber). Kept like a photo; only the AI in the cloud reads PDFs.
export const MAX_PDF_BYTES = 12 * 1024 * 1024;
export async function choosePdf() {
  const r = await DocumentPicker.getDocumentAsync({ type: ['application/pdf'], copyToCacheDirectory: true, multiple: false });
  if (!r || r.canceled || !r.assets || !r.assets.length) return null;
  const a = r.assets[0];
  if (a.size && a.size > MAX_PDF_BYTES) throw Object.assign(new Error('That PDF is too big to read (over 12 MB). Ask the supplier for a smaller copy, or take photos of the pages.'), { isAppError: true });
  if (a.mimeType && !/pdf/i.test(a.mimeType) && !/\.pdf$/i.test(a.name || '')) throw Object.assign(new Error('Choose a PDF file.'), { isAppError: true });
  return keep(a.uri, 'pdf');
}
