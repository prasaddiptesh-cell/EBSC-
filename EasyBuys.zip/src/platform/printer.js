// Printing. Uses Android's system print (expo-print): any printer with an Android print service – office A4/A5
// printers and most 80 mm receipt printers (their maker's "print service" app, Wi-Fi or Bluetooth) – with the page
// size set from the document (80 mm pages are one long page).
// Direct Bluetooth ESC/POS printing is NOT included: no ESC/POS Bluetooth library was found that is known to work
// with Expo SDK 54 (new architecture). `bluetoothPrinting()` says so; when a compatible library exists it can be
// added here without changing any screen.
import * as Print from 'expo-print';

export function bluetoothPrinting() {
  return { available: false, message: 'Printing goes through Android\'s print service. For an 80 mm Bluetooth receipt printer, install the printer maker\'s print-service app once; then choose that printer in the print screen.' };
}

// size: { width, height } in points (1/72 inch). 80 mm ≈ 227 pt wide.
export async function printHtml(html, size = { width: 595, height: 842 }) {
  await Print.printAsync({ html, width: Math.round(size.width), height: Math.round(size.height) });
}
