// Camera barcode reader (expo-camera): QR codes, Code 128 (Easy Buys documents) and product barcodes (EAN / UPC).
// Reads one code and hands back the text. Without a camera the Scan screen offers typing the code.
import React, { useRef, useEffect } from 'react';
import { View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Text } from '../ui/scale.js';

export const BARCODE_TYPES = ['qr', 'code128', 'code39', 'ean13', 'ean8', 'upc_a', 'upc_e'];
export function CodeScanner({ onScan, height = 260 }) {
  const [perm, requestPerm] = useCameraPermissions();
  const done = useRef(false);
  useEffect(() => { if (perm && !perm.granted && perm.canAskAgain) requestPerm(); }, [perm, requestPerm]);
  const box = { width: '100%', maxWidth: 520, height, backgroundColor: '#111', borderRadius: 16, overflow: 'hidden', alignSelf: 'center' };
  if (!perm) return <View style={box} />;
  if (!perm.granted) {
    return (
      <View style={[box, { alignItems: 'center', justifyContent: 'center', padding: 12 }]}>
        <Text style={{ color: '#fff', textAlign: 'center', fontSize: 15 }}>Camera not allowed.{'\n'}Allow it in Android Settings › Apps › Easy Buys, or type the code below.</Text>
      </View>
    );
  }
  return (
    <View testID="code-scanner" style={box}>
      <CameraView facing="back" style={{ flex: 1 }} barcodeScannerSettings={{ barcodeTypes: BARCODE_TYPES }}
        onBarcodeScanned={(r) => {
          if (done.current || !r || !r.data) return;
          done.current = true;
          onScan(String(r.data));
        }} />
    </View>
  );
}
