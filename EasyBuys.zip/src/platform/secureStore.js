// 1.0.0 (audit H): the phone's secure store (Android keystore) for this device's pass to the cloud.
// services/core.js keeps the pass there once this is plugged in; on the web, in the tests or if the store is missing,
// nothing is plugged in and the pass stays in the database as before.
import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import { setSecureBackend } from '../services/core.js';

export function plugInSecureStore() {
  try {
    if (Platform.OS !== 'android' && Platform.OS !== 'ios') return false;
    const S = SecureStore || {};
    if (typeof S.getItem !== 'function' || typeof S.setItem !== 'function') return false;
    setSecureBackend({
      getItem: (k) => S.getItem(k),
      setItem: (k, v) => S.setItem(k, v),
      // the store has only an async delete; an empty value reads back as "nothing" (core.js) at once
      deleteItem: (k) => { S.setItem(k, ''); if (typeof S.deleteItemAsync === 'function') S.deleteItemAsync(k).catch(() => {}); },
    });
    return true;
  } catch (e) { return false; }
}
