// Files for the safety copies (snapshots) of the database on this tablet, and the "outside" folder chosen once with
// Android's storage access (so a copy survives even if the app is uninstalled).
import * as FS from 'expo-file-system/legacy';
import { dbPath, DB_FILE } from './device.js';
import { getSetting, setSetting } from '../services/core.js';

const SAF = () => FS.StorageAccessFramework;

// The file operations the snapshot service needs (tests give their own, see setSnapshotFs).
export const deviceFs = {
  dir: () => `${FS.documentDirectory || 'file:///'}snapshots/`,
  dbFile: () => dbPath(DB_FILE),
  async ensureDir(d) { try { await FS.makeDirectoryAsync(d, { intermediates: true }); } catch (e) { /* already there */ } },
  async list(d) { try { return await FS.readDirectoryAsync(d); } catch (e) { return []; } },
  async size(uri) { try { const i = await FS.getInfoAsync(uri, { size: true }); return i && i.exists ? Number(i.size || 0) : null; } catch (e) { return null; } },
  async exists(uri) { try { const i = await FS.getInfoAsync(uri); return !!(i && i.exists); } catch (e) { return false; } },
  async copy(from, to) { await FS.copyAsync({ from, to }); },
  async remove(uri) { try { await FS.deleteAsync(uri, { idempotent: true }); } catch (e) { /* gone */ } },
};

// ---------------------------------------------------------------- the outside folder (Storage Access Framework)
export function outsideFolder() { try { return getSetting('outside_folder_uri', '') || ''; } catch (e) { return ''; } }
export function outsideAvailable() { return !!(SAF() && SAF().requestDirectoryPermissionsAsync); }
// Asks Android once for a folder (e.g. Documents/Easy Buys Backups). Returns the folder or '' when cancelled.
export async function pickOutsideFolder() {
  if (!outsideAvailable()) throw new Error('Choosing a folder is only possible on the Android tablet.');
  let initial = null;
  try { initial = SAF().getUriForDirectoryInRoot('Documents'); } catch (e) { initial = null; }
  const r = await SAF().requestDirectoryPermissionsAsync(initial);
  if (!r || !r.granted || !r.directoryUri) return '';
  setSetting('outside_folder_uri', r.directoryUri);
  return r.directoryUri;
}
export function forgetOutsideFolder() { setSetting('outside_folder_uri', ''); }
// The plain file name of a storage-access address (…%2Feb-20261009-0300-daily.db → eb-20261009-0300-daily.db).
export function safName(uri) {
  const last = decodeURIComponent(String(uri || '')).split('/').pop() || '';
  return last.split(':').pop();
}
export async function listOutside() {
  const dir = outsideFolder();
  if (!dir || !outsideAvailable()) return [];
  try { return (await SAF().readDirectoryAsync(dir)).map((uri) => ({ uri, name: safName(uri) })); } catch (e) { return []; }
}
// Copies a local file into the outside folder (large files go through memory as base64; a database is a few MB).
export async function copyToOutside(localUri, name) {
  const dir = outsideFolder();
  if (!dir) throw new Error('Choose the outside folder first.');
  const data = await FS.readAsStringAsync(localUri, { encoding: FS.EncodingType.Base64 });
  const target = await SAF().createFileAsync(dir, name, 'application/octet-stream');
  await FS.writeAsStringAsync(target, data, { encoding: FS.EncodingType.Base64 });
  return target;
}
export async function copyFromOutside(uri, localUri) {
  const data = await FS.readAsStringAsync(uri, { encoding: FS.EncodingType.Base64 });
  await FS.writeAsStringAsync(localUri, data, { encoding: FS.EncodingType.Base64 });
  return localUri;
}
export async function removeOutside(uri) { try { await SAF().deleteAsync(uri, { idempotent: true }); } catch (e) { /* ignore */ } }
