// Plays the bundled alert sounds (expo-audio). Urgent loops until stopUrgent() (the OK button); warning chimes once;
// information is a soft tone. If audio is not available (tests, or a phone problem) nothing happens.
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';

const FILES = {
  urgent: require('../../assets/sounds/urgent.wav'),
  warning: require('../../assets/sounds/warning.wav'),
  info: require('../../assets/sounds/info.wav'),
};
const players = {};
let modeSet = false;

function player(level) {
  if (!players[level]) players[level] = createAudioPlayer(FILES[level]);
  return players[level];
}
export async function playSound(level, { loop = false } = {}) {
  try {
    if (!FILES[level]) return false;
    if (!modeSet) { modeSet = true; try { await setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'duckOthers', shouldPlayInBackground: false }); } catch (e) { /* default mode */ } }
    const p = player(level);
    p.loop = !!loop;
    try { await p.seekTo(0); } catch (e) { /* first play */ }
    p.play();
    return true;
  } catch (e) {
    return false;
  }
}
export function stopSound(level) {
  try { const p = players[level]; if (p) { p.loop = false; p.pause(); } } catch (e) { /* ignore */ }
}
export function stopUrgent() { stopSound('urgent'); }
