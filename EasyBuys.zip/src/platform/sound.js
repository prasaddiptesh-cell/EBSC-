// Plays the alert sounds (expo-audio): soft bundled chimes, a choice of tone and volume per level (Admin › Alerts &
// sounds), or the phone's own notification sound. Urgent loops until stopUrgent() (the OK button) – its file gets a
// little louder each time round. If audio is not available (tests, or a phone problem) nothing happens.
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as Notifications from 'expo-notifications';
import { toneFor } from '../services/sounds.js';

const FILES = {
  info: { marimba: require('../../assets/sounds/info_marimba.mp3'), bell: require('../../assets/sounds/info_bell.mp3'), glass: require('../../assets/sounds/info_glass.mp3'), harp: require('../../assets/sounds/info_harp.mp3') },
  warning: { marimba: require('../../assets/sounds/warning_marimba.mp3'), bell: require('../../assets/sounds/warning_bell.mp3'), glass: require('../../assets/sounds/warning_glass.mp3'), harp: require('../../assets/sounds/warning_harp.mp3') },
  urgent: { marimba: require('../../assets/sounds/urgent_marimba.mp3'), bell: require('../../assets/sounds/urgent_bell.mp3'), glass: require('../../assets/sounds/urgent_glass.mp3'), harp: require('../../assets/sounds/urgent_harp.mp3') },
};
const players = {};
let modeSet = false;
const current = {};

function player(level, tone) {
  const k = `${level}:${tone}`;
  if (!players[k]) players[k] = createAudioPlayer(FILES[level][tone]);
  return players[k];
}
// The phone's own sound: a quiet notification that clears itself.
async function phoneSound() {
  try {
    const id = await Notifications.scheduleNotificationAsync({ content: { title: 'Easy Buys', body: 'New warning', sound: 'default' }, trigger: null });
    setTimeout(() => { Notifications.dismissNotificationAsync(id).catch(() => {}); }, 4000);
    return true;
  } catch (e) { return false; }
}
// opts.tone / opts.volume: for the ▶ preview buttons; otherwise this device's choice.
export async function playSound(level, { loop = false, tone, volume } = {}) {
  try {
    if (!FILES[level]) return false;
    const choice = toneFor(level);
    const t = tone || choice.tone;
    if (t === 'phone') return phoneSound();
    if (!FILES[level][t]) return false;
    if (!modeSet) { modeSet = true; try { await setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'duckOthers', shouldPlayInBackground: false }); } catch (e) { /* default mode */ } }
    if (current[level] && current[level] !== t) stopSound(level);
    const p = player(level, t);
    current[level] = t;
    p.loop = !!loop;
    try { p.volume = volume !== undefined ? volume : choice.volume; } catch (e) { /* older player */ }
    try { await p.seekTo(0); } catch (e) { /* first play */ }
    p.play();
    return true;
  } catch (e) {
    return false;
  }
}
export function stopSound(level) {
  try { Object.keys(players).filter((k) => k.startsWith(`${level}:`)).forEach((k) => { players[k].loop = false; players[k].pause(); }); } catch (e) { /* ignore */ }
}
export function stopUrgent() { stopSound('urgent'); }
