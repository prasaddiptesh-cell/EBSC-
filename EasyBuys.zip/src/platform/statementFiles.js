// Statement files for the bank module: choose a file (CSV, OFX, Excel, PDF, screenshot), read it as text or rows,
// keep a copy in the documents (statement archive), and save the reconciliation report PDF as a document.
// Phone-only parts are here; the reading of the text itself is in src/modules/bank (tested in Node).
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import JSZip from 'jszip';
import { readTextNow } from './cloud.js';
import { addFileDocument, addBase64Document } from './docFiles.js';
import { reportPdf } from './files.js';
import { sheetRows } from '../modules/bank/xlsx.js';

const ext = (n) => (/\.([A-Za-z0-9]+)$/.exec(String(n || '')) || [])[1] ? (/\.([A-Za-z0-9]+)$/.exec(String(n))[1]).toLowerCase() : '';
export function fileKind(name, mime) {
  const e = ext(name);
  if (e === 'ofx' || e === 'qfx') return 'ofx';
  if (e === 'xlsx' || /spreadsheetml/.test(mime || '')) return 'xlsx';
  if (e === 'pdf' || /pdf/.test(mime || '')) return 'pdf';
  if (['jpg', 'jpeg', 'png', 'webp', 'heic'].includes(e) || /^image\//.test(mime || '')) return 'image';
  return 'text';
}
// Opens the file chooser. Returns { name, mime, uri, kind, text?, rows? } – text for CSV/OFX/TXT, rows for Excel,
// text read by Google for PDF and screenshots (online only; otherwise { needsOnline: message }).
export async function pickStatementFile({ ocr = true } = {}) {
  const r = await DocumentPicker.getDocumentAsync({ type: ['*/*'], copyToCacheDirectory: true, multiple: false });
  if (!r || r.canceled || !r.assets || !r.assets.length) return null;
  const a = r.assets[0];
  const name = a.name || 'statement';
  const mime = a.mimeType || '';
  const kind = fileKind(name, mime);
  const out = { name, mime, uri: a.uri, size: a.size || null, kind };
  if (kind === 'xlsx') {
    const b64 = await FileSystem.readAsStringAsync(a.uri, { encoding: FileSystem.EncodingType.Base64 });
    out.rows = await xlsxRows(b64);
  } else if (kind === 'pdf' || kind === 'image') {
    if (!ocr) return out;
    const b64 = await FileSystem.readAsStringAsync(a.uri, { encoding: FileSystem.EncodingType.Base64 });
    const t = await readTextNow([{ mimeType: kind === 'pdf' ? 'application/pdf' : (mime || 'image/jpeg'), data: b64 }]);
    if (t.ok) out.text = t.text; else out.needsOnline = t.message;
  } else {
    out.text = await FileSystem.readAsStringAsync(a.uri, { encoding: FileSystem.EncodingType.UTF8 });
  }
  return out;
}
// The first sheet of an Excel file as rows of cells.
export async function xlsxRows(base64) {
  const zip = await JSZip.loadAsync(base64, { base64: true });
  const ss = zip.file('xl/sharedStrings.xml') ? await zip.file('xl/sharedStrings.xml').async('string') : '';
  const first = Object.keys(zip.files).filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort()[0];
  if (!first) return [];
  return sheetRows(await zip.file(first).async('string'), ss);
}
// Keeps the statement in the documents (statement archive). A picked file is copied; pasted text is kept as .txt.
export async function archiveStatement(user, meta, file, text) {
  if (file && file.uri) return addFileDocument(user, meta, { uri: file.uri, name: file.name, mime: file.mime, size: file.size });
  if (text) {
    const b64 = utf8Base64(text);
    return addBase64Document(user, { ...meta, name: `${meta.name}.txt` }, b64, 'text/plain');
  }
  return null;
}
// The reconciliation report as a PDF in the documents.
export async function saveReportDocument(user, meta, rep) {
  const pdf = await reportPdf(rep);
  return addBase64Document(user, { ...meta, name: meta.name.endsWith('.pdf') ? meta.name : `${meta.name}.pdf` }, pdf.base64, 'application/pdf');
}

// Text → UTF-8 bytes → base64 (no Buffer / btoa needed).
export function utf8Base64(text) {
  const bytes = [];
  for (const ch of String(text)) {
    let c = ch.codePointAt(0);
    if (c < 0x80) bytes.push(c);
    else if (c < 0x800) bytes.push(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else bytes.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const n = (bytes[i] << 16) | ((bytes[i + 1] || 0) << 8) | (bytes[i + 2] || 0);
    out += A[(n >> 18) & 63] + A[(n >> 12) & 63] + (i + 1 < bytes.length ? A[(n >> 6) & 63] : '=') + (i + 2 < bytes.length ? A[n & 63] : '=');
  }
  return out;
}
