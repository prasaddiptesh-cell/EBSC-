// On-device text recognition (Google ML Kit, works offline) for invoice photos.
// If the library is missing on this device build, or it fails, callers fall back to Google's cloud reading.
import TextRecognition from '@react-native-ml-kit/text-recognition';

export function deviceOcrAvailable() {
  return !!(TextRecognition && typeof TextRecognition.recognize === 'function');
}
// Text of one photo (file:// uri). Lines are kept in reading order (block by block, line by line).
export async function recognizeText(uri) {
  if (!deviceOcrAvailable()) return { ok: false, reason: 'Reading on this device is not available.' };
  try {
    const r = await TextRecognition.recognize(uri);
    const lines = [];
    for (const b of (r && r.blocks) || []) for (const l of b.lines || []) if (l && l.text) lines.push(l.text);
    const text = lines.length ? lines.join('\n') : String((r && r.text) || '');
    return text.trim() ? { ok: true, text } : { ok: false, reason: 'No text was found on the photo.' };
  } catch (e) {
    return { ok: false, reason: e && e.message ? e.message : String(e) };
  }
}
