// Training mode: a separate practice database on this device, filled with sample figures.
// The real database is not touched, and nothing is sent to the cloud while training mode is on.
import { setDb } from '../db/connection.js';
import { initDatabase, resetDatabase } from '../db/init.js';
import { getSetting, setSetting } from '../services/core.js';
import { seedTraining } from '../db/trainingSeed.js';
import { isTraining as flag, setTrainingFlag } from '../services/trainingFlag.js';

const TRAINING_DB = 'easybuys-training.db';
let real = null; // the real database adapter
let training = null; // the practice one
let opener = null;
export function isTraining() { return flag(); }

// Called once at start-up with the function that opens a database file by name.
export function startDatabases(open) {
  opener = open;
  real = open();
  initDatabase(real);
  if (getSetting('training_on', '0') === '1') {
    try { useTraining(false); } catch (e) { setDb(real); setTrainingFlag(false); setSetting('training_on', '0'); }
  }
}

function useTraining(fresh) {
  if (!training) training = opener(TRAINING_DB);
  initDatabase(training);
  if (fresh || getSetting('training_seeded', '0') !== '1') {
    if (fresh) resetDatabase();
    seedTraining();
    setSetting('training_seeded', '1');
  }
  setTrainingFlag(true);
}

export function enterTraining({ fresh = false } = {}) {
  if (!opener) throw new Error('Training mode is not available.');
  setDb(real); setSetting('training_on', '1');
  useTraining(fresh);
}

export function leaveTraining() {
  if (!real) return;
  setDb(real);
  setSetting('training_on', '0');
  setTrainingFlag(false);
}

export function trainingProblems() {
  try { return JSON.parse(getSetting('training_problems', '[]')) || []; } catch (e) { return []; }
}
