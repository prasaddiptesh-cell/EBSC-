// Training mode: a separate practice database on this device, filled with sample figures.
// The real database is not touched, and nothing is sent to the cloud while training mode is on.
import { setDb, setRealDb, withSystem } from '../db/connection.js';
import { initDatabase, resetDatabase } from '../db/init.js';
import { getSetting, setSetting } from '../services/core.js';
import { seedTraining } from '../db/trainingSeed.js';
import { isTraining as flag, setTrainingFlag } from '../services/trainingFlag.js';

const TRAINING_DB = 'easybuys-training.db';
let real = null; // the real database adapter
let training = null; // the practice one
let opener = null;
export function isTraining() { return flag(); }

// Called once at start-up with the function that opens a database file by name.
// defer: the first start after an update leaves its long set-up work for finishSetUp() (db/init.js), so the app can
// show "Getting ready" meanwhile.
export function startDatabases(open, { defer = false } = {}) {
  opener = open;
  real = open();
  setRealDb(real);
  // 1.0.0 build 1 (audit M6): a new install starts EMPTY – no sample logins or sample figures (the first-run screen
  // makes the owner login). Only the screen tests ask for the sample data. Devices updating keep their data.
  const sample = typeof globalThis !== 'undefined' && globalThis.__EB_SAMPLE_DATA === true;
  initDatabase(real, { seed: sample, defer });
  // the screen tests' sample business (never on a real device): the older screen tests do not type the owner PIN again
  if (sample && getSetting('ui_sample_db', '') === '' && getSetting('show_demo_pins', '0') === '1') setSetting('ui_sample_db', '1');
  if (getSetting('training_on', '0') === '1') {
    try { useTraining(false); } catch (e) { setDb(real); setTrainingFlag(false); setSetting('training_on', '0'); }
  }
}

function useTraining(fresh) {
  if (!training) training = opener(TRAINING_DB);
  // 1.0.0 build 1: the practice business is made by the app itself (the locked-settings guard does not apply)
  withSystem(() => {
    initDatabase(training);
    if (fresh || getSetting('training_seeded', '0') !== '1') {
      if (fresh) resetDatabase();
      seedTraining();
      setSetting('training_seeded', '1');
    }
  });
  setTrainingFlag(true);
}

export function enterTraining({ fresh = false } = {}) {
  if (!opener) throw Object.assign(new Error('Training mode is not available.'), { isAppError: true });
  setDb(real); setSetting('training_on', '1');
  useTraining(fresh);
}

export function leaveTraining() {
  if (!real) return;
  setDb(real);
  setSetting('training_on', '0');
  setTrainingFlag(false);
}

// Restore: swap the real database file for a copy and open it again (the caller made a safety copy first).
// `files` gives dbFile(), copy(from, to) and remove(uri) (see src/platform/snapshotFiles.js).
export async function replaceRealDatabase(fromUri, files) {
  if (flag()) throw Object.assign(new Error('Leave training mode first.'), { isAppError: true });
  if (!opener) throw new Error('The database is not open.');
  const target = files.dbFile();
  try { if (real && real.close) real.close(); } catch (e) { /* already closed */ }
  try {
    await files.remove(`${target}-wal`);
    await files.remove(`${target}-shm`);
    await files.remove(target);
    await files.copy(fromUri, target);
  } finally {
    real = opener(); setRealDb(real);
    initDatabase(real);
  }
  return true;
}
// After the database could not be opened at start-up: open it again (e.g. after a restore).
export function reopenDatabases() {
  if (!opener) throw new Error('The database is not open.');
  real = opener(); setRealDb(real);
  initDatabase(real);
  return real;
}
export function hasOpener() { return !!opener; }
export function setOpener(open) { opener = open; }

export function trainingProblems() {
  try { return JSON.parse(getSetting('training_problems', '[]')) || []; } catch (e) { return []; }
}
