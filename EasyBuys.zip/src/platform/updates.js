// "Is there a newer version of the app?" – looks at the GitHub release the build makes ("Latest app – Easy Buys").
// 1.0.0 automatic: every device checks every few hours by itself, downloads a newer app in the background (when
// allowed on this device), and then asks once: "Update ready – Install". Android always asks the person to confirm an
// install for apps not from Google Play (there is no way round that), so it is two taps: Install, then Update.
// All data stays. A safety copy is made just before.
import { Linking, Platform } from 'react-native';
import { VERSION_CODE } from '../services/about.js';
import { APP_VERSION, getSetting, setSetting, getShared, setShared, audit, stamp, dateStr } from '../services/core.js';

export const DEFAULT_REPO = 'prasaddiptesh-cell/EBSC-';
export function updateRepo() { return String(getShared('update_repo', '') || '').trim() || DEFAULT_REPO; }
export function saveUpdateRepo(user, repo) {
  const r = String(repo || '').trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/, '').replace(/\/+$/, '');
  if (r && !/^[\w.-]+\/[\w.-]+$/.test(r)) throw Object.assign(new Error('Write it as owner/name, e.g. easybuys/easybuys-app (from the GitHub address).'), { isAppError: true });
  setShared('update_repo', r);
  audit({ user, action: 'Changed where app updates come from', table: 'shared_settings', recordUid: 'update_repo', after: { repo: r } });
  return r;
}

// "3.4.0" > "3.3" ?
export function isNewer(a, b) {
  const p = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a); const y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
export function parseRelease(json) {
  const assets = (json && json.assets) || [];
  // The normal (64-bit) app; the "-32bit" copy is only for older tablets that cannot install it.
  const apks = assets.filter((a) => /\.apk$/i.test(a.name || ''));
  const apk = apks.find((a) => !/32bit/i.test(a.name)) || apks[0];
  if (!apk) return null;
  const apk32 = apks.find((a) => /32bit/i.test(a.name)) || null;
  const m = /v(\d+(?:\.\d+)*)(?:-build(\d+))?/i.exec(apk.name) || /v(\d+(?:\.\d+)*)/.exec(json.name || '');
  return { version: m ? m[1] : null, build: m && m[2] ? Number(m[2]) : null, url: apk.browser_download_url, url32: apk32 ? apk32.browser_download_url : null, size32: apk32 ? apk32.size : null, page: json.html_url, size: apk.size, published: json.published_at || json.created_at, name: apk.name };
}
export function lastUpdateInfo() { try { return JSON.parse(getSetting('update_latest', 'null')); } catch (e) { return null; } }
// The build number decides (version names can stay the same, e.g. "1.0.0"); the name is only used when there is no build.
export function releaseIsNewer(i) { if (!i) return false; const b = Number(i.build) || 0; return b && VERSION_CODE ? b > VERSION_CODE : !!(i.version && isNewer(i.version, APP_VERSION)); }
export function updateAvailable() { const i = lastUpdateInfo(); return i && releaseIsNewer(i) ? i : null; }

export async function checkForUpdate({ force = false } = {}) {
  const repo = updateRepo();
  if (!repo) return { off: true };
  const lastAt = Number(getSetting('update_checked_ms', '0')) || 0;
  if (!force && Date.now() - lastAt < CHECK_EVERY_MS && Date.now() >= lastAt) return { skipped: true, info: lastUpdateInfo() };
  setSetting('update_checked_ms', String(Date.now()));
  setSetting('update_checked_day', dateStr());
  const res = await fetch(`https://api.github.com/repos/${repo}/releases/tags/latest`, { headers: { Accept: 'application/vnd.github+json' } });
  if (res.status === 404) throw Object.assign(new Error('No release found. Check the repository name. If the repository is private, the app cannot see it – make it public (Settings › General › Danger zone › Change visibility) or download the app from GitHub by hand.'), { isAppError: true });
  if (!res.ok) throw new Error(`GitHub answered ${res.status}. Try again later.`);
  const info = parseRelease(await res.json());
  if (!info) throw Object.assign(new Error('The latest release has no .apk file yet (the build may still be running).'), { isAppError: true });
  const out = { ...info, checkedAt: stamp() };
  setSetting('update_latest', JSON.stringify(out));
  return { info: out, newer: releaseIsNewer(info) };
}
export const CHECK_EVERY_MS = 3 * 3600000;
// This device downloads updates by itself (on unless turned off here – e.g. a phone on expensive mobile data).
export function autoDownloadOn() { return getSetting('update_auto_download', '1') !== '0'; }
export function setAutoDownload(on) { setSetting('update_auto_download', on ? '1' : '0'); }
// The update already downloaded on this device: { build, version, uri, size } or null.
export function readyUpdate() {
  let r = null;
  try { r = JSON.parse(getSetting('update_ready', 'null')); } catch (e) { r = null; }
  return r && r.uri && releaseIsNewer(r) ? r : null;
}
const apkFile = (i) => `EasyBuys-update-${Number(i.build) || String(i.version || 'x').replace(/[^\w.]/g, '')}.apk`;
let downloading = null;
// 1.0.0 build 3: how far the download is (the screen and Home show it), a download that stops getting data for
// STALL_MS is stopped (it never hangs for ever), and the next try carries on where it stopped.
let progress = null;
export function downloadProgress() { return progress; }
export const STALL_MS = 90000;
async function download(F, want, uri, i, stallMs = STALL_MS) {
  progress = { build: i.build, written: 0, total: want.size || 0, at: Date.now(), state: 'downloading' };
  const cb = (p) => { if (p && p.totalBytesWritten > (progress.written || 0)) progress = { ...progress, written: p.totalBytesWritten, total: p.totalBytesExpectedToWrite > 0 ? p.totalBytesExpectedToWrite : progress.total, at: Date.now() }; };
  if (!F.createDownloadResumable) { // older file system (and the tests): one go
    const r = await F.downloadAsync(want.url, uri);
    if (!r || (r.status && r.status !== 200)) { progress = null; throw new Error(`The download did not work (${r ? r.status : 'no answer'}). It tries again later.`); }
    progress = null;
    return;
  }
  let saved = null;
  try { const s0 = JSON.parse(getSetting('update_resume', 'null')); if (s0 && s0.url === want.url && s0.fileUri === uri && s0.resumeData) saved = s0; } catch (e) { saved = null; }
  const dl = F.createDownloadResumable(want.url, uri, {}, cb, saved ? saved.resumeData : undefined);
  let timer = null;
  const stalled = new Promise((resolve) => {
    timer = setInterval(() => { if (Date.now() - progress.at > stallMs) resolve('stalled'); }, Math.min(5000, Math.max(20, stallMs / 3)));
  });
  try {
    // a stopped download carries on; if that does not work, it starts again from the beginning
    const run = saved
      ? dl.resumeAsync().catch(() => { setSetting('update_resume', 'null'); return F.createDownloadResumable(want.url, uri, {}, cb).downloadAsync(); })
      : dl.downloadAsync();
    run.catch(() => { /* a stopped download ends here */ });
    const r = await Promise.race([run, stalled]);
    if (r === 'stalled') {
      try { await dl.pauseAsync(); setSetting('update_resume', JSON.stringify(dl.savable())); } catch (e) { /* starts again next time */ }
      throw Object.assign(new Error('The download stopped (no internet for a while?). It carries on by itself later – or tap Check for updates again.'), { isAppError: true });
    }
    if (!r || (r.status && r.status !== 200)) {
      setSetting('update_resume', 'null');
      throw new Error(`The download did not work (${r ? r.status : 'no answer'}). It tries again later.`);
    }
    setSetting('update_resume', 'null');
  } finally {
    clearInterval(timer);
    progress = null;
  }
}
// The right copy for this device: the -32bit one for older tablets that cannot run 64-bit apps.
export function is32bit(dev) {
  const forced = getSetting('update_abi', '');
  if (forced === '32') return true;
  if (forced === '64') return false;
  try {
    const D = dev || require('expo-device');
    const a = D && D.supportedCpuArchitectures;
    if (Array.isArray(a) && a.length) return !a.some((x) => /arm64|x86_64/i.test(String(x)));
  } catch (e) { /* not known */ }
  return false;
}
// Downloads the newer app into the app's own cache (checked by its size). Never two at once; a half download is retried.
export async function fetchUpdate(info, { fs, stallMs = STALL_MS } = {}) {
  const i = info || lastUpdateInfo();
  if (!i || !i.url || !releaseIsNewer(i)) return null;
  const have = readyUpdate();
  if (have && Number(have.build) === Number(i.build) && have.version === i.version) return have;
  if (downloading) return downloading;
  downloading = (async () => {
    const F = fs || require('expo-file-system/legacy');
    const dir = F.cacheDirectory;
    // old update files are removed first (they are big)
    try { for (const f of await F.readDirectoryAsync(dir)) if (/^EasyBuys-update-.*\.apk$/.test(f) && f !== apkFile(i)) await F.deleteAsync(dir + f, { idempotent: true }); } catch (e) { /* none */ }
    const uri = dir + apkFile(i);
    const small = is32bit() && i.url32;
    const want = small ? { url: i.url32, size: i.size32 } : { url: i.url, size: i.size };
    await download(F, want, uri, i, stallMs);
    const st = await F.getInfoAsync(uri, { size: true });
    if (!st || !st.exists || (want.size && st.size && Math.abs(st.size - want.size) > 0) || (st.size && st.size < 1000000)) {
      try { await F.deleteAsync(uri, { idempotent: true }); } catch (e) { /* ignore */ }
      throw new Error('The downloaded update was not complete. It tries again later.');
    }
    const ready = { build: i.build, version: i.version, uri, size: st.size || i.size || 0, at: stamp() };
    setSetting('update_ready', JSON.stringify(ready));
    return ready;
  })();
  try { return await downloading; } finally { downloading = null; }
}
// Opens Android's "Do you want to update this app?" for the downloaded file (a safety copy first).
export async function installUpdate({ fs, launcher } = {}) {
  const r = readyUpdate();
  if (!r) throw Object.assign(new Error('No update downloaded yet – tap Check for updates.'), { isAppError: true });
  try { await require('../services/snapshots.js').snapshotNow('update'); } catch (e) { /* the install still goes ahead */ }
  const F = fs || require('expo-file-system/legacy');
  const st = await F.getInfoAsync(r.uri);
  if (!st || !st.exists) { setSetting('update_ready', 'null'); throw Object.assign(new Error('The downloaded update is gone (Android cleared it). Tap Check for updates to download it again.'), { isAppError: true }); }
  const content = await F.getContentUriAsync(r.uri);
  const IL = launcher || require('expo-intent-launcher');
  await IL.startActivityAsync('android.intent.action.VIEW', { data: content, flags: 1, type: 'application/vnd.android.package-archive' });
  audit({ user: null, action: `App update ${r.version} (build ${r.build}) opened to install`, table: 'settings', recordUid: 'update_ready' });
  return true;
}
// Called on start, every hour and when the app comes back: check (every 3 hours), then download if newer.
export async function autoUpdate({ fs } = {}) {
  const res = await checkForUpdate();
  const info = (res && res.info) || lastUpdateInfo();
  if (!info || !releaseIsNewer(info)) return { upToDate: true };
  if (Platform.OS !== 'android' || !autoDownloadOn()) return { newer: true, info };
  const ready = await fetchUpdate(info, { fs });
  return { newer: true, info, ready };
}
export async function downloadUpdate(info) {
  const i = info || lastUpdateInfo();
  if (!i || !i.url) throw Object.assign(new Error('Check for an update first.'), { isAppError: true });
  await Linking.openURL(i.url);
}
