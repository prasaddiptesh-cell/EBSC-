// "Is there a newer version of the app?" – looks at the Easy Buys updates (the release the build makes, "latest").
// 1.0.0 build 1 (audit C2): where updates come from is fixed in the app (a release-only place that holds no source),
// never a setting a device could change; every downloaded update is checked against its SHA-256 (the release's
// SHA256SUMS file) before it can be installed.
// 1.0.0 automatic: every device checks every few hours by itself, downloads a newer app in the background (when
// allowed on this device), and then asks once: "Update ready – Install". Android always asks the person to confirm an
// install for apps not from Google Play (there is no way round that), so it is two taps: Install, then Update.
// All data stays. A safety copy is made just before.
import { Linking, Platform } from 'react-native';
import { VERSION_CODE } from '../services/about.js';
import { APP_VERSION, getSetting, setSetting, getShared, setShared, audit, stamp, dateStr } from '../services/core.js';

export const DEFAULT_REPO = 'prasaddiptesh-cell/easybuys-updates';
export const OLD_REPOS = ['prasaddiptesh-cell/EBSC-'];
// Always the fixed place. A device that had the old place saved forgets it (once).
export function updateRepo() {
  try {
    const saved = String(getShared('update_repo', '') || '').trim();
    if (saved && getSetting('update_repo_moved', '') !== '1') { setSetting('update_repo_moved', '1'); setSetting('update_repo_was', OLD_REPOS.includes(saved) ? 'old' : 'other'); }
  } catch (e) { /* the fixed place below */ }
  return DEFAULT_REPO;
}
export function saveUpdateRepo() {
  throw Object.assign(new Error('Updates always come from Easy Buys updates – this cannot be changed.'), { isAppError: true });
}

// "3.4.0" > "3.3" ?
export function isNewer(a, b) {
  const p = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a); const y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
export function parseRelease(json) {
  const assets = (json && json.assets) || [];
  // The normal (64-bit) app; the "-32bit" copy is only for older tablets that cannot install it.
  const apks = assets.filter((a) => /\.apk$/i.test(a.name || ''));
  const apk = apks.find((a) => !/32bit/i.test(a.name)) || apks[0];
  if (!apk) return null;
  const apk32 = apks.find((a) => /32bit/i.test(a.name)) || null;
  const sums = assets.find((a) => /^(SHA256SUMS|sha256sums\.txt|checksums\.txt)$/i.test(a.name || '')) || null;
  const m = /v(\d+(?:\.\d+)*)(?:-build(\d+))?/i.exec(apk.name) || /v(\d+(?:\.\d+)*)/.exec(json.name || '');
  return { version: m ? m[1] : null, build: m && m[2] ? Number(m[2]) : null, url: apk.browser_download_url, url32: apk32 ? apk32.browser_download_url : null, size32: apk32 ? apk32.size : null, name32: apk32 ? apk32.name : null, sumsUrl: sums ? sums.browser_download_url : null, page: json.html_url, size: apk.size, published: json.published_at || json.created_at, name: apk.name };
}
export function lastUpdateInfo() { try { return JSON.parse(getSetting('update_latest', 'null')); } catch (e) { return null; } }
// The build number decides (version names can stay the same, e.g. "1.0.0"); the name is only used when there is no build.
export function releaseIsNewer(i) { if (!i) return false; const b = Number(i.build) || 0; return b && VERSION_CODE ? b > VERSION_CODE : !!(i.version && isNewer(i.version, APP_VERSION)); }
export function updateAvailable() { const i = lastUpdateInfo(); return i && releaseIsNewer(i) ? i : null; }

export async function checkForUpdate({ force = false } = {}) {
  const repo = updateRepo();
  if (!repo) return { off: true };
  const lastAt = Number(getSetting('update_checked_ms', '0')) || 0;
  if (!force && Date.now() - lastAt < CHECK_EVERY_MS && Date.now() >= lastAt) return { skipped: true, info: lastUpdateInfo() };
  setSetting('update_checked_ms', String(Date.now()));
  setSetting('update_checked_day', dateStr());
  const res = await fetch(`https://api.github.com/repos/${repo}/releases/tags/latest`, { headers: { Accept: 'application/vnd.github+json' } });
  if (res.status === 404) throw Object.assign(new Error('No update has been published yet. Try again later.'), { isAppError: true });
  if (!res.ok) throw new Error(`The update check answered ${res.status}. Try again later.`);
  const info = parseRelease(await res.json());
  if (!info) throw Object.assign(new Error('The latest update is not ready yet (it may still be being made).'), { isAppError: true });
  // the SHA-256 of each app file, from the release's SHA256SUMS ("<hash>  <file name>" lines)
  if (info.sumsUrl) {
    try {
      const sr = await fetch(info.sumsUrl);
      const text = sr && sr.ok !== false && sr.text ? await sr.text() : '';
      const sums = parseSums(text);
      info.sha256 = sums[info.name] || null;
      info.sha32 = info.name32 ? sums[info.name32] || null : null;
    } catch (e) { info.sha256 = null; }
  }
  const out = { ...info, checkedAt: stamp() };
  setSetting('update_latest', JSON.stringify(out));
  return { info: out, newer: releaseIsNewer(info) };
}
export const CHECK_EVERY_MS = 3 * 3600000;
export function parseSums(text) {
  const out = {};
  String(text || '').split(/\r?\n/).forEach((l) => { const m = /^([0-9a-f]{64})\s+\*?(\S.*)$/i.exec(l.trim()); if (m) out[m[2].trim()] = m[1].toLowerCase(); });
  return out;
}
// SHA-256 of a downloaded file, a piece at a time (never the whole update in memory at once).
export async function fileSha256(F, uri, size) {
  const { sha256Stream } = require('../services/sha256stream.js');
  const { base64ToBytes } = require('../services/sha256.js');
  const h = sha256Stream();
  const PIECE = 3 * 1024 * 1024;
  for (let pos = 0; pos < size; pos += PIECE) {
    const b64 = await F.readAsStringAsync(uri, { encoding: 'base64', position: pos, length: Math.min(PIECE, size - pos) });
    const bytes = base64ToBytes(b64);
    if (!bytes.length) break;
    h.update(bytes);
  }
  return h.hex();
}
// This device downloads updates by itself (on unless turned off here – e.g. a phone on expensive mobile data).
export function autoDownloadOn() { return getSetting('update_auto_download', '1') !== '0'; }
export function setAutoDownload(on) { setSetting('update_auto_download', on ? '1' : '0'); }
// The update already downloaded on this device: { build, version, uri, size } or null.
export function readyUpdate() {
  let r = null;
  try { r = JSON.parse(getSetting('update_ready', 'null')); } catch (e) { r = null; }
  return r && r.uri && releaseIsNewer(r) ? r : null;
}
const apkFile = (i) => `EasyBuys-update-${Number(i.build) || String(i.version || 'x').replace(/[^\w.]/g, '')}.apk`;
let downloading = null;
// 1.0.0 build 3: how far the download is (the screen and Home show it), a download that stops getting data for
// STALL_MS is stopped (it never hangs for ever), and the next try carries on where it stopped.
let progress = null;
export function downloadProgress() { return progress; }
export const STALL_MS = 90000;
async function download(F, want, uri, i, stallMs = STALL_MS) {
  progress = { build: i.build, written: 0, total: want.size || 0, at: Date.now(), state: 'downloading' };
  const cb = (p) => { if (p && p.totalBytesWritten > (progress.written || 0)) progress = { ...progress, written: p.totalBytesWritten, total: p.totalBytesExpectedToWrite > 0 ? p.totalBytesExpectedToWrite : progress.total, at: Date.now() }; };
  if (!F.createDownloadResumable) { // older file system (and the tests): one go
    const r = await F.downloadAsync(want.url, uri);
    if (!r || (r.status && r.status !== 200)) { progress = null; throw new Error(`The download did not work (${r ? r.status : 'no answer'}). It tries again later.`); }
    progress = null;
    return;
  }
  let saved = null;
  try { const s0 = JSON.parse(getSetting('update_resume', 'null')); if (s0 && s0.url === want.url && s0.fileUri === uri && s0.resumeData) saved = s0; } catch (e) { saved = null; }
  const dl = F.createDownloadResumable(want.url, uri, {}, cb, saved ? saved.resumeData : undefined);
  let timer = null;
  const stalled = new Promise((resolve) => {
    timer = setInterval(() => { if (Date.now() - progress.at > stallMs) resolve('stalled'); }, Math.min(5000, Math.max(20, stallMs / 3)));
  });
  try {
    // a stopped download carries on; if that does not work, it starts again from the beginning
    const run = saved
      ? dl.resumeAsync().catch(() => { setSetting('update_resume', 'null'); return F.createDownloadResumable(want.url, uri, {}, cb).downloadAsync(); })
      : dl.downloadAsync();
    run.catch(() => { /* a stopped download ends here */ });
    const r = await Promise.race([run, stalled]);
    if (r === 'stalled') {
      try { await dl.pauseAsync(); setSetting('update_resume', JSON.stringify(dl.savable())); } catch (e) { /* starts again next time */ }
      throw Object.assign(new Error('The download stopped (no internet for a while?). It carries on by itself later – or tap Check for updates again.'), { isAppError: true });
    }
    if (!r || (r.status && r.status !== 200)) {
      setSetting('update_resume', 'null');
      throw new Error(`The download did not work (${r ? r.status : 'no answer'}). It tries again later.`);
    }
    setSetting('update_resume', 'null');
  } finally {
    clearInterval(timer);
    progress = null;
  }
}
// The right copy for this device: the -32bit one for older tablets that cannot run 64-bit apps.
export function is32bit(dev) {
  const forced = getSetting('update_abi', '');
  if (forced === '32') return true;
  if (forced === '64') return false;
  try {
    const D = dev || require('expo-device');
    const a = D && D.supportedCpuArchitectures;
    if (Array.isArray(a) && a.length) return !a.some((x) => /arm64|x86_64/i.test(String(x)));
  } catch (e) { /* not known */ }
  return false;
}
// Downloads the newer app into the app's own cache (checked by its size). Never two at once; a half download is retried.
export async function fetchUpdate(info, { fs, stallMs = STALL_MS, hashFile } = {}) {
  const i = info || lastUpdateInfo();
  if (!i || !i.url || !releaseIsNewer(i)) return null;
  const have = readyUpdate();
  if (have && Number(have.build) === Number(i.build) && have.version === i.version) return have;
  if (downloading) return downloading;
  downloading = (async () => {
    const F = fs || require('expo-file-system/legacy');
    const dir = F.cacheDirectory;
    // old update files are removed first (they are big)
    try { for (const f of await F.readDirectoryAsync(dir)) if (/^EasyBuys-update-.*\.apk$/.test(f) && f !== apkFile(i)) await F.deleteAsync(dir + f, { idempotent: true }); } catch (e) { /* none */ }
    const uri = dir + apkFile(i);
    const small = is32bit() && i.url32;
    const want = small ? { url: i.url32, size: i.size32, sha: i.sha32 } : { url: i.url, size: i.size, sha: i.sha256 };
    await download(F, want, uri, i, stallMs);
    const st = await F.getInfoAsync(uri, { size: true });
    if (!st || !st.exists || (want.size && st.size && Math.abs(st.size - want.size) > 0) || (st.size && st.size < 1000000)) {
      try { await F.deleteAsync(uri, { idempotent: true }); } catch (e) { /* ignore */ }
      throw new Error('The downloaded update was not complete. It tries again later.');
    }
    // 1.0.0 build 1: the file must be exactly the one published (its SHA-256), or it is thrown away – never installed.
    if (!want.sha) { try { await F.deleteAsync(uri, { idempotent: true }); } catch (e) { /* ignore */ } throw Object.assign(new Error('This update has no check file yet, so it is not installed. It tries again later.'), { isAppError: true }); }
    const got = await (hashFile || fileSha256)(F, uri, st.size || want.size || 0);
    if (String(got).toLowerCase() !== String(want.sha).toLowerCase()) {
      try { await F.deleteAsync(uri, { idempotent: true }); } catch (e) { /* ignore */ }
      audit({ user: null, action: 'A downloaded app update did not match its check (SHA-256) – thrown away', table: 'settings', recordUid: 'update_ready', after: { build: i.build } });
      throw Object.assign(new Error('The downloaded update did not pass the safety check, so it was thrown away. It tries again later.'), { isAppError: true });
    }
    const ready = { build: i.build, version: i.version, uri, size: st.size || i.size || 0, sha256: want.sha, at: stamp() };
    setSetting('update_ready', JSON.stringify(ready));
    return ready;
  })();
  try { return await downloading; } finally { downloading = null; }
}
// Opens Android's "Do you want to update this app?" for the downloaded file (a safety copy first).
export async function installUpdate({ fs, launcher } = {}) {
  const r = readyUpdate();
  if (!r) throw Object.assign(new Error('No update downloaded yet – tap Check for updates.'), { isAppError: true });
  try { await require('../services/snapshots.js').snapshotNow('update'); } catch (e) { /* the install still goes ahead */ }
  const F = fs || require('expo-file-system/legacy');
  const st = await F.getInfoAsync(r.uri);
  if (!st || !st.exists) { setSetting('update_ready', 'null'); throw Object.assign(new Error('The downloaded update is gone (Android cleared it). Tap Check for updates to download it again.'), { isAppError: true }); }
  const content = await F.getContentUriAsync(r.uri);
  const IL = launcher || require('expo-intent-launcher');
  await IL.startActivityAsync('android.intent.action.VIEW', { data: content, flags: 1, type: 'application/vnd.android.package-archive' });
  audit({ user: null, action: `App update ${r.version} (build ${r.build}) opened to install`, table: 'settings', recordUid: 'update_ready' });
  return true;
}
// Called on start, every hour and when the app comes back: check (every 3 hours), then download if newer.
export async function autoUpdate({ fs } = {}) {
  const res = await checkForUpdate();
  const info = (res && res.info) || lastUpdateInfo();
  if (!info || !releaseIsNewer(info)) return { upToDate: true };
  if (Platform.OS !== 'android' || !autoDownloadOn()) return { newer: true, info };
  const ready = await fetchUpdate(info, { fs });
  return { newer: true, info, ready };
}
export async function downloadUpdate(info) {
  const i = info || lastUpdateInfo();
  if (!i || !i.url) throw Object.assign(new Error('Check for an update first.'), { isAppError: true });
  await Linking.openURL(i.url);
}
