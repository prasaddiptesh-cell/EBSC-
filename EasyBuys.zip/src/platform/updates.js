// "Is there a newer version of the app?" – looks at the GitHub release the build makes ("Latest app – Easy Buys")
// and, when there is one, offers to download it. Android then asks to install it (data is kept).
import { Linking } from 'react-native';
import { VERSION_CODE } from '../services/about.js';
import { APP_VERSION, getSetting, setSetting, getShared, setShared, audit, stamp, dateStr } from '../services/core.js';

export function updateRepo() { return String(getShared('update_repo', '') || '').trim(); }
export function saveUpdateRepo(user, repo) {
  const r = String(repo || '').trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/, '').replace(/\/+$/, '');
  if (r && !/^[\w.-]+\/[\w.-]+$/.test(r)) throw new Error('Write it as owner/name, e.g. easybuys/easybuys-app (from the GitHub address).');
  setShared('update_repo', r);
  audit({ user, action: 'Changed where app updates come from', table: 'shared_settings', recordUid: 'update_repo', after: { repo: r } });
  return r;
}

// "3.4.0" > "3.3" ?
export function isNewer(a, b) {
  const p = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a); const y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
export function parseRelease(json) {
  const assets = (json && json.assets) || [];
  // The normal (64-bit) app; the "-32bit" copy is only for older tablets that cannot install it.
  const apks = assets.filter((a) => /\.apk$/i.test(a.name || ''));
  const apk = apks.find((a) => !/32bit/i.test(a.name)) || apks[0];
  if (!apk) return null;
  const m = /v(\d+(?:\.\d+)*)(?:-build(\d+))?/i.exec(apk.name) || /v(\d+(?:\.\d+)*)/.exec(json.name || '');
  return { version: m ? m[1] : null, build: m && m[2] ? Number(m[2]) : null, url: apk.browser_download_url, page: json.html_url, size: apk.size, published: json.published_at || json.created_at, name: apk.name };
}
export function lastUpdateInfo() { try { return JSON.parse(getSetting('update_latest', 'null')); } catch (e) { return null; } }
// The build number decides (version names can stay the same, e.g. "1.0.0"); the name is only used when there is no build.
export function releaseIsNewer(i) { if (!i) return false; const b = Number(i.build) || 0; return b && VERSION_CODE ? b > VERSION_CODE : !!(i.version && isNewer(i.version, APP_VERSION)); }
export function updateAvailable() { const i = lastUpdateInfo(); return i && releaseIsNewer(i) ? i : null; }

export async function checkForUpdate({ force = false } = {}) {
  const repo = updateRepo();
  if (!repo) return { off: true };
  if (!force && getSetting('update_checked_day', '') === dateStr()) return { skipped: true, info: lastUpdateInfo() };
  setSetting('update_checked_day', dateStr());
  const res = await fetch(`https://api.github.com/repos/${repo}/releases/tags/latest`, { headers: { Accept: 'application/vnd.github+json' } });
  if (res.status === 404) throw new Error('No release found. Check the repository name. If the repository is private, the app cannot see it – make it public (Settings › General › Danger zone › Change visibility) or download the app from GitHub by hand.');
  if (!res.ok) throw new Error(`GitHub answered ${res.status}. Try again later.`);
  const info = parseRelease(await res.json());
  if (!info) throw new Error('The latest release has no .apk file yet (the build may still be running).');
  const out = { ...info, checkedAt: stamp() };
  setSetting('update_latest', JSON.stringify(out));
  return { info: out, newer: releaseIsNewer(info) };
}
export async function downloadUpdate(info) {
  const i = info || lastUpdateInfo();
  if (!i || !i.url) throw new Error('Check for an update first.');
  await Linking.openURL(i.url);
}
