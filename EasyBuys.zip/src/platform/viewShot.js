// Share part of a screen as a picture. Not in this build (it would need another native library and make the app
// bigger), so callers fall back to sharing a PDF.
export async function sharePicture() {
  const err = new Error('Pictures are not available in this version – share it as a PDF instead.');
  err.noPicture = true;
  throw err;
}
