// Release 12 (owner, 14 Nov: "Photo not added – expo-file-system.copyAsync is not available on web"): on the website a
// browser has no app folder – a chosen photo / PDF is kept in the open tab as a data: address (the bytes themselves)
// until it has gone to the cloud and Google Drive, like on a phone. Reading it back gives the same base64.
export const onWeb = () => { try { return require('react-native').Platform.OS === 'web' && typeof window !== 'undefined'; } catch (e) { return false; } };
export const isInline = (uri) => /^(data|blob):/i.test(String(uri || ''));
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(r.error || new Error('The file could not be read.')); r.readAsDataURL(blob); });
}
export async function keepInline(uri, mime) {
  if (/^data:/i.test(String(uri))) return String(uri);
  const res = await fetch(uri);
  let blob = await res.blob();
  if (mime && blob.type !== mime) { try { blob = new Blob([blob], { type: mime }); } catch (e) { /* keep its own type */ } }
  return blobToDataUrl(blob);
}
export async function inlineBase64(uri) {
  const d = await keepInline(uri);
  const i = d.indexOf(',');
  return i >= 0 ? d.slice(i + 1) : '';
}
