// Release 33 (owner, 14 Nov: "all devices talk to the database directly – the phones, the website, the linker – the
// database is the sole truth, no device in between"): the till PCs' figures are turned into the business's records BY
// THE DATABASE ITSELF. Until now a phone (whichever held the "link" job) read the till PCs' feed and made the products,
// End of days, sales into stock, suppliers and staff credit – with no phone open, nothing happened (the new products
// that never came in).
//
// This runs inside the Easy Buys cloud (its own Durable Object, its own SQLite – never the business's vault tables).
// It uses the app's very own rules (link.js – the same code the phones ran), on a copy of only the tables those rules
// read (PROC_TABLES), kept up to date from the cloud's change list like any device. What the rules make goes back to
// the cloud as changes (device "cloud-processor"), and every phone and the website get it from the cloud.
import { initDatabase } from '../db/init.js';
import { db, withSystem, setDb } from '../db/connection.js';
import { APP_BUILD } from '../services/about.js';
import { applyPulledRecords, pendingRecords, markRecordsSent, pullCursor, setPullCursor, SYNC_TABLES } from '../services/records.js';
import { getSetting, setSetting } from '../services/core.js';
import { processLink } from '../modules/aronium/link.js';

// What the rules read (found by running them – tests/proc33.test.js checks nothing else is needed)
export const PROC_TABLES = new Set([
  'aronium_feed', 'aronium_eods', 'aronium_suppliers', 'till_counts', 'tills', 'shops', 'users', 'shared_settings',
  'inv_items', 'inv_item_shops', 'inv_moves', 'inv_counts', 'inv_count_lines', 'inv_supplier_catalog', 'product_watch',
  'ap_suppliers', 'staff_credit_imports', 'staff_credit_balances', 'staff_debts', 'staff_charges',
  'recharge_moves', 'recharge_sales', 'cig_tallies', 'fccc_lists',
]);
export const PROC_DEVICE = 'cloud-processor';
// a change to one of these is what the rules work from (the rest are only looked up)
const WAKE_TABLES = new Set(['aronium_feed', 'till_counts', 'inv_items', 'shared_settings', 'staff_credit_imports']);

let opened = null;
// adapter: the app's database interface ({ exec, run, all, get, transaction }).
export function openProcessor(adapter) {
  if (opened === adapter) return;
  // Release 34: the tables are made once per app build – waking up again (every few minutes) only reconnects (making
  // sure of 500 tables and their indexes read the schema ~100 000 times on every wake)
  let same = false;
  try { const r = adapter.get("SELECT value FROM settings WHERE key = 'proc_schema'"); same = !!r && r.value === String(APP_BUILD); } catch (e) { same = false; }
  if (same) { setDb(adapter); opened = adapter; return; }
  initDatabase(adapter, { seed: false });
  try { adapter.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('proc_schema', ?)", [String(APP_BUILD)]); } catch (e) { /* made again next wake */ }
  opened = adapter;
  withSystem(() => {
    if (getSetting('proc_born', '') !== '1') {
      // what the empty database was given when it was made (default settings, shops …) is NOT news for the cloud
      const tables = db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").map((r) => r.name);
      for (const t of tables) { try { db().run(`UPDATE "${t}" SET sync_status = 'synced' WHERE sync_status = 'pending'`); } catch (e) { /* no sync column */ } }
      setSetting('proc_born', '1');
    }
    setSetting('device_kind', 'cloud');
    setSetting('device_id', PROC_DEVICE);
  });
}

// One round: bring in what changed (only PROC_TABLES), run the rules, send what they made.
// pull(since) → { ok, records, next, more };  push(records) → { ok, rejected }
export async function processRound({ pull, push, budgetMs = 20000, now = () => Date.now(), work = true, stop = () => false } = {}) {
  const t0 = now();
  const out = { pulled: 0, applied: 0, sent: 0, did: [], more: false, caughtUp: false };
  let since = pullCursor();
  for (let i = 0; i < 400; i += 1) {
    if (now() - t0 > budgetMs * 0.6) { out.more = true; return out; }
    if (stop()) { out.more = true; out.budget = true; return out; } // Release 34: the day's database allowance
    const r = await pull(since);
    if (!r || r.ok === false) throw new Error((r && r.error) || 'The cloud did not answer the pull.');
    const recs = (r.records || []).filter((x) => x && PROC_TABLES.has(x.t));
    if (recs.length) out.applied += applyPulledRecords(recs);
    if (recs.some((x) => WAKE_TABLES.has(x.t))) out.news = true;
    out.pulled += (r.records || []).length;
    if (Number(r.next) > since) { since = Number(r.next); withSystem(() => setPullCursor(since)); }
    if (!r.more) break;
  }
  out.caughtUp = true;
  if (!work) return out;
  // Release 34: nothing the rules work from has changed (and nothing was left over last time) – no work, no reads
  if (!out.news && getSetting('proc_left', '') !== '1') return out;
  if (stop()) { out.more = true; out.budget = true; return out; }
  // the rules – exactly what the phones did ("force": every part, products and suppliers too)
  let res = null;
  try { res = withSystem(() => processLink({ limit: 40, force: true })); } catch (e) { out.error = String((e && e.message) || e).slice(0, 300); }
  if (res && res.did) out.did = res.did.slice(0, 40);
  if (res && res.left) out.more = true;
  withSystem(() => setSetting('proc_left', out.more ? '1' : ''));
  // what they made → the cloud
  for (let i = 0; i < 40; i += 1) {
    if (now() - t0 > budgetMs) { out.more = true; break; }
    const batch = pendingRecords(300);
    if (!batch.length) break;
    const r = await push(batch);
    if (!r || r.ok === false) throw new Error((r && r.error) || 'The cloud did not take the changes.');
    const refused = new Set((r.rejected || []).map((x) => `${x.t}|${x.k}`));
    const done = batch.filter((x) => !refused.has(`${x.t}|${x.k}`));
    // a change the cloud refused is not sent again and again: it is noted and set aside
    withSystem(() => {
      markRecordsSent(done);
      for (const x of batch.filter((y) => refused.has(`${y.t}|${y.k}`))) {
        const cfg = SYNC_TABLES[x.t];
        if (cfg) { try { db().run(`UPDATE "${x.t}" SET sync_status = 'synced' WHERE ${cfg.key} = ?`, [x.k]); } catch (e) { /* noted below */ } }
      }
    });
    if (refused.size) out.refused = (out.refused || []).concat((r.rejected || []).slice(0, 5).map((x) => `${x.t} ${x.k}: ${x.why || x.code || ''}`)).slice(0, 10);
    out.sent += done.length;
    if (!done.length) break;
  }
  withSystem(() => setSetting('proc_last', JSON.stringify({ at: new Date(now()).toISOString(), did: out.did, sent: out.sent, error: out.error || '' })));
  return out;
}
export function processorState() {
  let last = null;
  try { last = JSON.parse(getSetting('proc_last', 'null')); } catch (e) { last = null; }
  return { cursor: pullCursor(), last };
}
