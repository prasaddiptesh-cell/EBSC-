// Stand-ins for the phone-only libraries when the app's rules run inside the cloud (src/server/processor.js).
export const Platform = { OS: 'cloud', select: (o) => (o && (o.default ?? o.native)) };
export const documentDirectory = 'file:///docs/';
export const cacheDirectory = 'file:///cache/';
export const EncodingType = { Base64: 'base64', UTF8: 'utf8' };
export async function printToFileAsync() { return { uri: 'file:///cache/x.pdf', base64: 'UERG' }; }
export async function readAsStringAsync() { return 'QUJD'; }
export async function writeAsStringAsync() {}
export async function getInfoAsync() { return { exists: true }; }
export async function copyAsync() {}
export async function makeDirectoryAsync() {}
export async function deleteAsync() {}
export async function shareAsync() {}
export async function isAvailableAsync() { return true; }
export async function activateKeepAwakeAsync() {}
export function deactivateKeepAwake() {}
export async function printAsync() {}
export const getDocumentAsync = async () => ({ canceled: true });
export const Linking = { openURL: async () => {}, getInitialURL: async () => null, addEventListener: () => ({ remove() {} }) };
export async function readDirectoryAsync() { return []; }
export async function getFreeDiskStorageAsync() { return 8e9; }
export const StorageAccessFramework = null;
export async function setAudioModeAsync() {}
export function createAudioPlayer() { return { loop: false, play() {}, pause() {}, seekTo: async () => {}, remove() {} }; }
export const AndroidImportance = { MAX: 5, HIGH: 4 };
export const AndroidNotificationVisibility = { PUBLIC: 1 };
export async function setNotificationChannelAsync() {}
export async function scheduleNotificationAsync() { return 'n'; }
// v3.9.6 background sync and notification taps
export const addNotificationResponseReceivedListener = () => ({ remove() {} });
export const defineTask = () => {};
export const isTaskRegisteredAsync = async () => false;
export const BackgroundTaskStatus = { Restricted: 1, Available: 2 };
export const BackgroundTaskResult = { Success: 1, Failed: 2 };
export const getStatusAsync = async () => 2;
export const registerTaskAsync = async () => { if (typeof window !== 'undefined') window.__bgRegistered = true; };
// 1.0.0 app updates (download + Android installer)
export async function downloadAsync(url, uri) { return { status: 200, uri }; }
export async function getContentUriAsync(uri) { return uri.replace('file://', 'content://'); }
export async function startActivityAsync() { return { resultCode: 0 }; }
export const supportedCpuArchitectures = ['arm64-v8a', 'armeabi-v7a'];
