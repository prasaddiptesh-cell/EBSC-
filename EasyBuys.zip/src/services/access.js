// Who can do what. Roles have default permissions; the Owner can change them (Admin > Roles).
// Modules ask `can(user, 'perm')` — nothing else needs to know about roles.
import { getShared, setShared, getSetting, setSetting, audit, AppError, BUSINESS_SETTING_KEYS } from './core.js';

export const ROLES = ['staff', 'worker', 'supervisor', 'manager', 'payroll', 'accountant', 'admin', 'owner'];
export const ROLE_LABEL = {
  staff: 'Staff', worker: 'Baker', supervisor: 'Supervisor', manager: 'Shop manager',
  payroll: 'Payroll', accountant: 'Accountant (view only)', admin: 'Admin', owner: 'Owner',
};
export const ROLE_HELP = {
  staff: 'Clocks in and out, sees own hours, asks for leave.',
  worker: 'Bakery: signs on, runs batches, wastage, checklists. Also clocks in and asks for leave.',
  supervisor: 'Bakery supervisor: dashboard, balancing and approving bakery shifts. Sees timesheets.',
  manager: 'Shop manager: fixes timesheets, approves leave, enrols faces.',
  payroll: 'Timesheets, leave and (later) payroll.',
  accountant: 'View only: invoices, payments, VAT, FNPF / PAYE, bank, the books and reports. Cannot change anything; can send queries to the owner.',
  admin: 'Everything except changing what each role may do.',
  owner: 'Everything. Only owners change roles, Fiji tax tables and other admins.',
};

// Every permission the app knows, grouped by module (shown on the Roles screen).
export const PERMS = [
  { key: 'my_hours', module: 'Time Clock', label: 'See own hours and ask for leave' },
  { key: 'timesheets_view', module: 'Timesheets', label: 'See everyone\'s timesheets' },
  { key: 'timesheets_edit', module: 'Timesheets', label: 'Fix punches and tick weeks as checked' },
  { key: 'leave_approve', module: 'Leave', label: 'Approve or decline leave' },
  { key: 'leave_setup', module: 'Leave', label: 'Leave types and days allowed' },
  { key: 'staff_manage', module: 'Staff', label: 'Add and change staff, PINs and roles' },
  { key: 'face_enrol', module: 'Staff', label: 'Enrol staff faces' },
  { key: 'bakery', module: 'Bakery', label: 'Open the Bakery section' },
  { key: 'reports', module: 'Reports', label: 'Open reports' },
  { key: 'invoices_enter', module: 'Invoices & cheques', label: 'Enter and photograph supplier invoices' },
  { key: 'invoices_check', module: 'Invoices & cheques', label: 'Check, change and void invoices' },
  { key: 'payments_make', module: 'Invoices & cheques', label: 'Pay suppliers (cheque, cash, transfer) and see the pay trail' },
  { key: 'cheques_manage', module: 'Invoices & cheques', label: 'Bank accounts, cheque books, cleared cheques, balance check' },
  { key: 'ap_setup', module: 'Invoices & cheques', label: 'Suppliers, recurring bills, loans and invoice rules' },
  { key: 'till_count', module: 'Till & cash', label: 'Count the till at the end of a shift (with Z report photo)' },
  { key: 'till_approve', module: 'Till & cash', label: 'Approve till counts, see shortages, cash on hand' },
  { key: 'deposits', module: 'Till & cash', label: 'Record bank deposits and petty cash' },
  { key: 'till_self_balance', module: 'Till & cash', label: 'May run and balance their own till (cashier and balancer the same person)' },
  { key: 'owed_view', module: 'Who owes us', label: 'See what staff owe (Aronium staff credit, advances, loans, charges) and statements' },
  { key: 'owed_manage', module: 'Who owes us', label: 'Bring in Aronium staff credit balances, add settlement receipts' },
  { key: 'owed_setup', module: 'Who owes us', label: 'Set credit limits per person (admin)' },
  { key: 'dashboard', module: 'Dashboard', label: 'Open the dashboard (cards allowed for the role)' },
  { key: 'dashboard_setup', module: 'Dashboard', label: 'Choose which roles see which dashboard cards (admin)' },
  { key: 'bank_rec', module: 'Bank', label: 'Bank statements and reconciliation' },
  { key: 'wallets', module: 'Bank', label: 'M-PAiSA wallets: transfers to BSP, fees and balance checks' },
  { key: 'payroll_view', module: 'Payroll', label: 'See pay runs and payslips' },
  { key: 'payroll_run', module: 'Payroll', label: 'Prepare and finalise pay runs, advances, staff loans' },
  { key: 'payroll_setup', module: 'Payroll', label: 'Pay rates, tax and FNPF tables, allowances (admin)' },
  { key: 'accounts_view', module: 'Accounting & VAT', label: 'See the VAT return, profit & loss, balance sheet and the books' },
  { key: 'accounts_journal', module: 'Accounting & VAT', label: 'Enter journals and fixed assets' },
  { key: 'accounts_close', module: 'Accounting & VAT', label: 'Close a month (lock it) – reopening is owner only' },
  { key: 'accounts_setup', module: 'Accounting & VAT', label: 'Chart of accounts, where things are booked, budgets (admin)' },
  { key: 'statutory', module: 'Payroll', label: 'FNPF and PAYE payments, year-end figures' },
  { key: 'recruit_manage', module: 'Recruitment & onboarding', label: 'Vacancies, applicants, hiring, onboarding checklist, contracts' },
  { key: 'contract_sign', module: 'Recruitment & onboarding', label: 'Sign contracts for Easy Buys (employer)' },
  { key: 'snap_upload', module: 'To verify', label: 'Take photos of invoices and cheques received or handed over (a supervisor confirms them)' },
  { key: 'verify_money', module: 'To verify', label: 'Verify cash records and confirm staff photos (2nd step)' },
  { key: 'verify_setup', module: 'To verify', label: 'Verification rules and Viber alerts (admin)' },
  { key: 'inventory_view', module: 'Inventory', label: 'See stock, products, movements and stock reports' },
  { key: 'inventory_manage', module: 'Inventory', label: 'Write-offs, transfers between shops, supplier returns, product changes, CSV import' },
  { key: 'po_create', module: 'Purchase orders', label: 'Make purchase orders and send them to suppliers' },
  { key: 'po_approve', module: 'Purchase orders', label: 'Approve orders (over budget or over the limit)' },
  { key: 'po_receive', module: 'Purchase orders', label: 'Receive deliveries against orders' },
  { key: 'stocktake_count', module: 'Stock take', label: 'Start a stock take and enter counts' },
  { key: 'stocktake_approve', module: 'Stock take', label: 'Check results, ask for recounts and post the stock take' },
  { key: 'inventory_setup', module: 'Inventory', label: 'Supplier budgets and inventory, order and stock-take rules (admin)' },
  { key: 'licences_view', module: 'Licences & permits', label: 'See licences, permits and their documents' },
  { key: 'licences_manage', module: 'Licences & permits', label: 'Add licences and permits, upload copies and applications, record renewals' },
  { key: 'vehicles_view', module: 'Vehicles & equipment', label: 'See vehicles and equipment, what is due, faults and the fuel log' },
  { key: 'vehicles_use', module: 'Vehicles & equipment', label: 'Enter fuel, record services and repairs, report faults, daily checks' },
  { key: 'vehicles_manage', module: 'Vehicles & equipment', label: 'Add and change vehicles and equipment, types, intervals and settings (admin)' },
  { key: 'trade_view', module: 'Trade accounts', label: 'See customer and supplier accounts, shop photos and agreements' },
  { key: 'trade_manage', module: 'Trade accounts', label: 'Open and change customer and supplier accounts' },
  { key: 'trade_dispatch', module: 'Trade accounts', label: 'Send out deliveries: choose the Aronium invoices, the driver and the truck, add dispatch notes' },
  { key: 'trade_drive', module: 'Trade accounts', label: 'Drive deliveries: check the load, get the signature, take the payment' },
  { key: 'trade_credit_override', module: 'Trade accounts', label: 'Open a credit account without the signed agreement (reason kept)' },
  { key: 'loans_manage', module: 'Loans & rent', label: 'Loans and rent: set up, receipts, loan journey, check against the lender statement' },
  { key: 'drawings', module: "Owner's money", label: "Owner's money: take money out, business paid for me, put money in (owners)" },
  { key: 'drawings_setup', module: "Owner's money", label: "Owner's money settings: one owner or several family members (admin)" },
  { key: 'settings', module: 'Admin', label: 'Settings, shops, device, Time Clock rules' },
  { key: 'audit_view', module: 'Admin', label: 'See the change history' },
  { key: 'roles', module: 'Admin', label: 'Change what each role may do (owners only)' },
];

const ALL = PERMS.map((p) => p.key);
// The permissions that existed in v3.0 (before Invoices, Till, Bank and Payroll).
const PRE_V3_1 = ['my_hours', 'timesheets_view', 'timesheets_edit', 'leave_approve', 'leave_setup', 'staff_manage', 'face_enrol', 'bakery', 'reports', 'settings', 'audit_view', 'roles'];
export const DEFAULT_ROLE_PERMS = {
  staff: ['my_hours', 'snap_upload', 'po_receive', 'trade_drive'], // build 25: drivers (only shows while Wholesale is on) // v3.9.5 shop staff receive deliveries against the order
  worker: ['my_hours', 'bakery'],
  supervisor: ['my_hours', 'bakery', 'timesheets_view', 'reports', 'invoices_enter', 'till_count', 'inventory_view', 'po_receive', 'stocktake_count', 'snap_upload', 'verify_money', 'vehicles_view', 'vehicles_use', 'trade_view', 'trade_drive'],
  manager: ['my_hours', 'timesheets_view', 'timesheets_edit', 'leave_approve', 'face_enrol', 'reports', 'invoices_enter', 'invoices_check', 'till_count', 'till_approve', 'deposits',
    'inventory_view', 'inventory_manage', 'po_create', 'po_receive', 'stocktake_count', 'stocktake_approve', 'snap_upload', 'verify_money', 'recruit_manage', 'licences_view', 'wallets',
    'owed_view', 'dashboard', 'vehicles_view', 'vehicles_use', 'trade_view', 'trade_manage', 'trade_dispatch', 'trade_drive'],
  payroll: ['my_hours', 'timesheets_view', 'timesheets_edit', 'leave_approve', 'reports', 'payroll_view', 'payroll_run', 'statutory', 'owed_view', 'owed_manage', 'dashboard'],
  accountant: ['reports', 'accounts_view', 'payroll_view', 'statutory', 'payments_make', 'bank_rec', 'inventory_view', 'audit_view', 'dashboard', 'owed_view', 'licences_view'],
  admin: ALL.filter((k) => k !== 'roles'),
  owner: ALL,
};

// v3.9.5 worked out once until anything in the database changes (can() is asked thousands of times a screen).
let permsMemo = null;
export function rolePerms() {
  let key = null;
  try { const C = require('../db/connection.js'); key = `${C.writeCount()}`; if (permsMemo && permsMemo.key === key && permsMemo.db === C.db() && Date.now() - permsMemo.at < 1500) { C.noteKeyRead('shared_settings', 'role_perms'); return permsMemo.v; } } catch (e) { key = null; }
  const v = rolePermsNow();
  try { const C = require('../db/connection.js'); if (key !== null) permsMemo = { key, db: C.db(), v, at: Date.now() }; } catch (e) { /* not kept */ }
  return v;
}
function rolePermsNow() {
  const saved = getShared('role_perms', null) || {};
  const out = {};
  // Permissions added in a later version than the saved list get their default for that role.
  const known = Array.isArray(saved._known) ? saved._known : PRE_V3_1;
  for (const r of ROLES) {
    out[r] = Array.isArray(saved[r])
      ? saved[r].concat(DEFAULT_ROLE_PERMS[r].filter((k) => !known.includes(k) && !saved[r].includes(k)))
      : DEFAULT_ROLE_PERMS[r];
  }
  // v3.9.5 shop staff receive goods against the order on the shop tablet (until the owner changes the Staff role again).
  if (Array.isArray(saved.staff) && !saved._v395 && !out.staff.includes('po_receive')) out.staff = out.staff.concat(['po_receive']);
  out.owner = ALL; // owners can always do everything
  return out;
}

// Until someone is made Owner (e.g. straight after upgrading the Bakery app), Admins act as Owners.
let ownerMemo = null;
export function hasOwner() {
  const { db, writeCount } = require('../db/connection.js');
  const d = db(); const w = writeCount();
  if (ownerMemo && ownerMemo.w === w && ownerMemo.d === d && Date.now() - ownerMemo.at < 1500) { require('../db/connection.js').noteDeps(['users']); return ownerMemo.v; }
  const v = !!d.get("SELECT 1 AS x FROM users WHERE role = 'owner' AND active = 1");
  ownerMemo = { w, d, v, at: Date.now() };
  return v;
}
// 1.0.0 build 1 (hardening): the role is the one in this device's logins NOW (services/guard.js liveUser) – a forged,
// disabled or out-of-date session object has no rights of its own.
const live = (user) => { try { return require('./guard.js').liveUser(user); } catch (e) { return null; } };
export function actsAsOwner(user) {
  const u = live(user);
  return !!u && (u.role === 'owner' || (u.role === 'admin' && !hasOwner()));
}

// Owner and Admin never have to give a reason (a reason they type is still recorded). Everyone else does.
export function reasonRequired(user) {
  return !(user && (actsAsOwner(user) || user.role === 'owner' || user.role === 'admin' || user.realRole === 'owner' || user.realRole === 'admin'));
}
// Use instead of need(txt(reason), '…'): stops with the message only when this person must give a reason.
export function needReason(user, reason, message = 'Please give a reason.') {
  if (reasonRequired(user) && !String(reason === null || reason === undefined ? '' : reason).trim()) throw new AppError(message);
}

// "Reason (required)" → "Reason (optional)" for owner/admin; adds "(optional)" when the label has no note.
export function reasonLabel(user, label = 'Reason') {
  const base = String(label).replace(/\s*\((required|needed)\)\s*$/i, '');
  if (reasonRequired(user)) return label;
  return /\(optional\)/i.test(base) ? base : `${base} (optional)`;
}

export function can(user0, perm) {
  const user = live(user0);
  if (!user) return false;
  if (actsAsOwner(user)) return true;
  // 1.0.0 per-person permissions (Staff profile › Permissions): a tick given or taken away for this one person.
  const own = user.uid ? personPermsOf(user.uid) : null;
  if (own) {
    if (own.deny && own.deny.includes(perm)) return false;
    if (own.grant && own.grant.includes(perm) && !VIEW_ONLY_ROLES.includes(user.role)) return true;
  }
  return (rolePerms()[user.role] || []).includes(perm);
}

// ---------- 1.0.0 per-person permissions (kept in the shared setting "person_perms", synced) ----------
// { [userUid]: { grant: [perm], deny: [perm] } } – a tick given or taken away for one person (Staff profile › Permissions).
// The two switches "Works shifts" and "Can balance own till" are stream B's (src/modules/staff/flags.js, shown on the
// staff profile); worksShifts() and canBalanceOwnTill() below just ask it, so there is one place for each.
export function personPerms() { const v = getShared('person_perms', null); return v && typeof v === 'object' ? v : {}; }
export function personPermsOf(uid) { const v = personPerms()[uid]; return v && typeof v === 'object' ? v : null; }
export function worksShifts(user) {
  if (!user) return false;
  try { return require('../modules/staff/flags.js').worksShifts(user.realRole ? { ...user, role: user.realRole } : user); } catch (e) { return ['staff', 'worker'].includes(user.realRole || user.role); }
}
export function canBalanceOwnTill(user) {
  try { return require('../modules/staff/flags.js').canBalanceOwnTill(user); } catch (e) { return can(user, 'till_self_balance'); }
}
// Permissions shown as switches on the profile (stream B), not in the tick list.
export const PROFILE_SWITCH_PERMS = ['till_self_balance'];
export function mayEditPersonPerms(byUser, targetUid) {
  if (!byUser) return false;
  const boss = actsAsOwner(byUser) || ['owner', 'admin'].includes(byUser.role);
  if (!boss) return false;
  if (byUser.uid === targetUid && !actsAsOwner(byUser) && byUser.role !== 'owner') return false; // an admin does not widen their own rights
  return true;
}
// Saves one person's permissions: { grant: [perm], deny: [perm] }. Owner / admin only.
export function savePersonPerms(byUser, targetUid, { grant = [], deny = [] } = {}) {
  require('./guard.js').requireTop(byUser, 'change what a person may do'); // 1.0.0 hardening (H1)
  return require('./guard.js').asService(() => {
  if (!targetUid) throw new AppError('Choose the person.');
  if (!mayEditPersonPerms(byUser, targetUid)) throw new AppError('Only the owner or an admin can change what a person may do (an admin cannot change their own).');
  const okPerm = (k) => ALL.includes(k) && k !== 'roles';
  const g = [...new Set((grant || []).filter(okPerm))];
  const d = [...new Set((deny || []).filter(okPerm))].filter((k) => !g.includes(k));
  const all = { ...personPerms() };
  const before = all[targetUid] || null;
  const next = { grant: g, deny: d };
  all[targetUid] = next;
  setShared('person_perms', all);
  audit({ user: byUser, action: 'Changed a person\'s permissions', table: 'users', recordUid: targetUid, before, after: next });
  return next;
  });
}
// What a person may do, tick by tick, for the profile screen: role default, then the person's own choice.
export function personPermView(person) {
  const role = person.role;
  const base = rolePerms()[role] || [];
  const own = personPermsOf(person.uid) || {};
  return PERMS.filter((p) => p.key !== 'roles' && !PROFILE_SWITCH_PERMS.includes(p.key)).map((p) => {
    const fromRole = role === 'owner' ? true : base.includes(p.key);
    const on = role === 'owner' ? true : (own.deny || []).includes(p.key) ? false : (own.grant || []).includes(p.key) ? true : fromRole;
    return { ...p, fromRole, on, changed: on !== fromRole };
  });
}

// ---------- 1.0.0 petty cash: switched off and hidden unless the owner turns it back on ----------
export function pettyCashOn() { return getShared('petty_cash_on', '0') === '1'; }
export function setPettyCashOn(byUser, on) {
  requireSetup(byUser, 'settings');
  setShared('petty_cash_on', on ? '1' : '0');
  audit({ user: byUser, action: on ? 'Petty cash switched on' : 'Petty cash switched off', table: 'shared_settings', recordUid: 'petty_cash_on' });
}

// ---------- 1.0.0 which Home a person gets ----------
// accountant: the books only · bakery: the bakery buttons · staff: the 5 staff buttons · office: Today / Records / Reports / Settings
export function isBakeryPerson(user) {
  if (!user) return false;
  const role = user.realRole || user.role;
  return role === 'worker' || (['staff', 'supervisor'].includes(role) && String(user.shop_code || '').toUpperCase() === 'BAKERY');
}
export function homeKind(user) {
  if (!user) return null;
  const role = user.realRole || user.role;
  if (role === 'accountant') return 'accountant';
  if (isBakeryPerson(user)) return 'bakery';
  if (role === 'staff' || role === 'supervisor') return 'staff';
  return 'office';
}

export function saveRolePerms(byUser, perms) {
  if (!actsAsOwner(byUser)) throw new AppError('Only an Owner can change what each role may do.');
  const clean = {};
  for (const r of ROLES) if (r !== 'owner') clean[r] = (perms[r] || []).filter((k) => ALL.includes(k) && k !== 'roles');
  const before = rolePerms();
  clean._known = ALL;
  clean._v395 = true;
  setShared('role_perms', clean);
  audit({ user: byUser, action: 'Changed role permissions', table: 'shared_settings', recordUid: 'role_perms', before, after: clean });
}

// The Bakery screens were written for three roles. Everyone else is shown to them as one of these.
export function bakeryRole(user) {
  if (!user) return null;
  if (user.role === 'owner' || user.role === 'admin') return 'admin';
  if (user.role === 'supervisor' || user.role === 'manager' || user.role === 'payroll') return 'supervisor';
  return 'worker';
}

// ---------- this device (not synced) ----------
export function deviceKind() {
  return getSetting('device_kind', '') || null;
}
export function deviceSettings() {
  return {
    kind: getSetting('device_kind', '') || 'tablet',
    name: getSetting('device_name', ''),
    clockHere: getSetting('clock_here', '') === '' ? (getSetting('device_kind', 'tablet') !== 'phone') : getSetting('clock_here') === '1',
    defaultShop: getSetting('device_shop', ''),
  };
}
export function saveDeviceSettings(user, s) {
  requireSetup(user, 'settings');
  if (!['tablet', 'phone'].includes(s.kind)) throw new AppError('Choose tablet or phone.');
  setSetting('device_kind', s.kind);
  setSetting('device_name', String(s.name || '').trim().slice(0, 40));
  setSetting('clock_here', s.clockHere ? '1' : '0');
  setSetting('device_shop', s.defaultShop || '');
  audit({ user, action: 'Changed this device\'s settings', table: 'device', after: s });
}

// Display size (text and buttons) for this device only. 1 = normal.
export const SCALE_STEPS = [0.8, 0.85, 0.9, 1, 1.1, 1.2, 1.35, 1.5];
export function getUiScale(width) {
  const v = Number(getSetting('ui_scale', ''));
  if (v && v > 0.5 && v < 2) return v;
  return width && width < 500 ? 0.85 : 1; // phones start a little smaller
}
export function setUiScale(v) {
  setSetting('ui_scale', v === null ? '' : String(v));
}

// View-only roles: nothing on screen can change records (enforced at the database, see db/connection.js).
export const VIEW_ONLY_ROLES = ['accountant'];
// v3.9: settings and rules can only be changed by someone allowed to (checked here too, not only by which screens a
// person can open). The owner / admin always may; work the app does by itself (no person) is not stopped.
export function requireSetup(user0, ...perms) {
  try { if (require('./guard.js').requireLogin(user0) === null) return; } catch (e) { if (user0 === null || user0 === undefined) throw new AppError('Please log in first.'); throw e; }
  const user = live(user0);
  if (actsAsOwner(user) || ['owner', 'admin'].includes(user.role)) return;
  if (perms.some((p) => can(user, p)) || can(user, 'settings')) return;
  throw new AppError('Only the owner or admin (or someone given this permission) can change these settings.');
}
export function isViewOnly(user) { return !!user && VIEW_ONLY_ROLES.includes(user.role); }
// Tables a view-only login may still write: its own queries, change history, this device's settings and housekeeping.
export const VIEW_ONLY_TABLES = ['audit_log', 'health_checks', 'outbox', 'doc_local', 'accountant_queries'];
// v3.9: settings are checked key by key. Business settings and rules (shared by every device) are refused; only the
// person's own things (tutorial progress, own Home links / dashboard layout) and this device's housekeeping pass.
const VIEW_ONLY_SHARED_OK = [/^tutorial_progress$/, /^quick_links$/];
const VIEW_ONLY_SETTING_NO = /^(device_|main_tablet|cloud|update_|force_logout|admin_|role|pin|modules|face|clock|backup)/i;
export function viewOnlyGuard(user) {
  if (!isViewOnly(user)) return null;
  const refuse = () => { throw new AppError('View only: this login can see records but not change them. Use "Ask the owner".'); };
  return (table, params = []) => {
    if (VIEW_ONLY_TABLES.includes(table)) return;
    const key = String(params[0] === undefined || params[0] === null ? '' : params[0]);
    if (table === 'shared_settings') {
      if (VIEW_ONLY_SHARED_OK.some((re) => re.test(key)) || (user.uid && key === `dashboard_layout_${user.uid}`)) return;
      refuse();
    }
    if (table === 'settings') {
      // This device's own bookkeeping (last time seen, hidden warnings, screens remembered…) is fine; business
      // settings (also kept here) and device / security settings are not.
      const business = BUSINESS_SETTING_KEYS.includes(key);
      if (!key || business || VIEW_ONLY_SETTING_NO.test(key)) refuse();
      return;
    }
    refuse();
  };
}
