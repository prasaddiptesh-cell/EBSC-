// Warnings registry. Every module can export `alerts(user)` from its index.js, returning
//   [{ id, level: 'urgent'|'warning'|'info', text, sub?, nav: { screen, params }, area, perm? }]
// Home, the full warnings list, sounds and (later) the dashboard and watchdog all read them from here.
// "Hide until tomorrow" works on warning / info only (never urgent), per person and per device, and ends next day.
import { getSetting, setSetting, dateStr } from './core.js';
import { can } from './access.js';

export const LEVELS = ['urgent', 'warning', 'info'];
export const LEVEL_LABEL = { urgent: 'Urgent', warning: 'Warning', info: 'Information' };
export const LEVEL_TONE = { urgent: 'danger', warning: 'warn', info: 'info' };
const RANK = { urgent: 0, warning: 1, info: 2 };

let sources = null; // [{ id, alerts }]
// The list of modules, or a function returning it (set once by the registry; tests may pass their own).
export function setAlertSources(list) { sources = list; }
// The registry (src/modules/registry.js) hands over a function so switched-off modules are left out at the time.
function allSources() {
  if (typeof sources === 'function') { try { return sources() || []; } catch (e) { return []; } }
  return sources || [];
}

// Most urgent first; within a level, the order the modules gave them.
export function sortAlerts(list) {
  return list.map((a, i) => ({ a, i })).sort((x, y) => (RANK[x.a.level] ?? 3) - (RANK[y.a.level] ?? 3) || x.i - y.i).map((x) => x.a);
}
function clean(a, area) {
  if (!a || !a.id || !a.text) return null;
  const level = LEVELS.includes(a.level) ? a.level : 'info';
  return { ...a, level, area: a.area || area, nav: a.nav || null };
}

// ---------------------------------------------------------------- hiding (per person, per device, until tomorrow)
const hideKey = (user) => `alerts_hidden_${(user && (user.uid || user.id)) || 'anyone'}`;
function hiddenMap(user, today = dateStr()) {
  let m = {};
  try { m = JSON.parse(getSetting(hideKey(user), '{}')) || {}; } catch (e) { m = {}; }
  // Only today's hides count; older ones have expired.
  return Object.fromEntries(Object.entries(m).filter(([, d]) => d === today));
}
export function isHidden(user, id, today) { return !!hiddenMap(user, today)[id]; }
export function hideAlert(user, alert, today = dateStr()) {
  if (!alert || alert.level === 'urgent') throw new Error('Urgent warnings cannot be hidden.');
  const m = hiddenMap(user, today);
  m[alert.id] = today;
  setSetting(hideKey(user), JSON.stringify(m));
}
export function unhideAll(user) { setSetting(hideKey(user), '{}'); }

// ---------------------------------------------------------------- collecting
// Every warning this person may see (urgent first). A module that fails is skipped (the problem log has it).
export function collectAlerts(user, { includeHidden = false, today } = {}) {
  if (!user) return [];
  const out = [];
  const seen = new Set();
  for (const src of allSources()) {
    if (!src || typeof src.alerts !== 'function') continue;
    let list = [];
    try { list = src.alerts(user) || []; } catch (e) {
      try { require('./errorLog.js').logError(e, { where: `warnings of ${src.id}` }); } catch (x) { /* ignore */ }
      list = [];
    }
    for (const raw of list) {
      const a = clean(raw, src.id);
      if (!a || seen.has(a.id)) continue;
      if (a.perm && !(Array.isArray(a.perm) ? a.perm.some((p) => can(user, p)) : can(user, a.perm))) continue;
      seen.add(a.id);
      out.push(a);
    }
  }
  const hidden = includeHidden ? {} : hiddenMap(user, today);
  return sortAlerts(out.filter((a) => a.level === 'urgent' || !hidden[a.id]));
}

// For Home: the 3 most urgent and how many more.
export function homeAlerts(user, { max = 3, today } = {}) {
  const all = collectAlerts(user, { today });
  return { top: all.slice(0, max), more: Math.max(0, all.length - max), all };
}
export function countByLevel(list) {
  return LEVELS.reduce((o, l) => ({ ...o, [l]: list.filter((a) => a.level === l).length }), {});
}
