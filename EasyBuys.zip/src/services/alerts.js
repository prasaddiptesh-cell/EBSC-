// Warnings registry. Every module can export `alerts(user)` from its index.js, returning
//   [{ id, level: 'urgent'|'warning'|'info', text, sub?, nav: { screen, params }, area, perm? }]
// Home, the full warnings list, sounds and (later) the dashboard and watchdog all read them from here.
// "Hide until tomorrow" works on warning / info only (never urgent), per person and per device, and ends next day.
import { getSetting, setSetting, dateStr, stamp } from './core.js';
import { writeCount, userWriteCount } from '../db/connection.js';
import { can } from './access.js';

export const LEVELS = ['urgent', 'warning', 'info'];
export const LEVEL_LABEL = { urgent: 'Urgent', warning: 'Warning', info: 'Information' };
export const LEVEL_TONE = { urgent: 'danger', warning: 'warn', info: 'info' };
const RANK = { urgent: 0, warning: 1, info: 2 };

let sources = null; // [{ id, alerts }]
// The list of modules, or a function returning it (set once by the registry; tests may pass their own).
export function setAlertSources(list) { sources = list; try { cache.clear(); slowCache.clear(); } catch (e) { /* first call */ } }
// The registry (src/modules/registry.js) hands over a function so switched-off modules are left out at the time.
function allSources() {
  if (typeof sources === 'function') { try { return sources() || []; } catch (e) { return []; } }
  return sources || [];
}

// Most urgent first; within a level, the order the modules gave them.
export function sortAlerts(list) {
  return list.map((a, i) => ({ a, i })).sort((x, y) => (RANK[x.a.level] ?? 3) - (RANK[y.a.level] ?? 3) || x.i - y.i).map((x) => x.a);
}
function clean(a, area) {
  if (!a || !a.id || !a.text) return null;
  const level = LEVELS.includes(a.level) ? a.level : 'info';
  return { ...a, level, area: a.area || area, nav: a.nav || null };
}

// ---------------------------------------------------------------- hiding (per person, per device, until tomorrow)
const hideKey = (user) => `alerts_hidden_${(user && (user.uid || user.id)) || 'anyone'}`;
function hiddenMap(user, today = dateStr()) {
  let m = {};
  try { m = JSON.parse(getSetting(hideKey(user), '{}')) || {}; } catch (e) { m = {}; }
  // Only today's hides count; older ones have expired.
  return Object.fromEntries(Object.entries(m).filter(([, d]) => d === today));
}
export function isHidden(user, id, today) { return !!hiddenMap(user, today)[id]; }
export function hideAlert(user, alert, today = dateStr()) {
  if (!alert || alert.level === 'urgent') throw new Error('Urgent warnings cannot be hidden.');
  const m = hiddenMap(user, today);
  m[alert.id] = today;
  setSetting(hideKey(user), JSON.stringify(m));
}
export function unhideAll(user) { setSetting(hideKey(user), '{}'); }

// ---------------------------------------------------------------- collecting
// Every warning this person may see (urgent first). A module that fails is skipped (the problem log has it).
// v3.9.4 speed: the warnings of every module are worked out once per person and reused by Home, the warning sound,
// My day and the dashboard – until something is saved, the minute changes, or (when only background saves happened,
// e.g. sync) 20 seconds have passed. Hidden ones are filtered afterwards, so "with" and "without hidden" share one list.
// My day's tasks are built from the other modules' warnings: it runs last and reads what was collected so far,
// instead of collecting everything a second time (that doubled the time Home took).
let depth = 0;
let inProgress = null; // { uid, out } while one collection is running
const cache = new Map(); // `${uid}|${role}|${today}` → { list, writes, minute, at }
const slowCache = new Map(); // one module's warnings that took long → { list, userWrites, at }
export function collectAlerts(user, { includeHidden = false, today } = {}) {
  if (!user) return [];
  // Safety: a module whose warnings look at other warnings must never loop (the app would freeze).
  if (depth >= 2) return [];
  const hideOff = (list) => {
    if (includeHidden) return list.slice();
    const hidden = hiddenMap(user, today);
    return list.filter((a) => a.level === 'urgent' || !hidden[a.id]);
  };
  if (depth >= 1) {
    // Asked from inside a collection (My day): the warnings gathered so far, or the last full list.
    if (inProgress && inProgress.uid === user.uid) return hideOff(sortAlerts(inProgress.out.slice()));
    const c = cache.get(`${user.uid}|${user.role}|${today || ''}`);
    if (c) return hideOff(c.list);
  }
  const key = `${user.uid}|${user.role}|${today || ''}`;
  const c = cache.get(key);
  const nowMs = Date.now();
  const minute = stamp().slice(0, 16);
  if (depth === 0 && c && c.minute === minute && (c.writes === writeCount() || (c.userWrites === userWriteCount() && nowMs - c.at < 60000) || nowMs - c.at < 5000)) return hideOff(c.list);
  depth += 1;
  const outer = inProgress;
  try {
    const list = collectOnce(user, { today });
    if (depth === 1) {
      cache.set(key, { list, writes: writeCount(), userWrites: userWriteCount(), minute, at: Date.now() });
      if (cache.size > 12) cache.delete(cache.keys().next().value);
    }
    return hideOff(list);
  } finally { depth -= 1; inProgress = outer; }
}
export function clearAlertCache() { cache.clear(); slowCache.clear(); }
// The newest list worked out for an owner or admin on this device (the online dashboard reuses it), or null.
export function cachedOwnerAlerts(maxAgeMs = 10 * 60000) {
  let best = null;
  for (const [k, v] of cache) {
    const role = k.split('|')[1];
    if (!['owner', 'admin'].includes(role) || Date.now() - v.at > maxAgeMs) continue;
    if (!best || v.at > best.at) best = v;
  }
  return best ? best.list.slice() : null;
}
function collectOnce(user, { today }) {
  const out = [];
  const seen = new Set();
  inProgress = { uid: user.uid, out };
  // My day last: it builds its tasks from the others.
  const list0 = allSources();
  const ordered = list0.filter((x) => x && x.id !== 'myday').concat(list0.filter((x) => x && x.id === 'myday'));
  for (const src of ordered) {
    if (!src || typeof src.alerts !== 'function') continue;
    let list = [];
    // v3.9.4 a module whose warnings take long to work out (tax calendars, returns, watchdog…) keeps its answer for
    // up to 5 minutes, unless someone saved something on this device (sync brings other devices' changes in quietly).
    const sk = `${src.id}|${user.uid}|${user.role}|${today || ''}|${stamp().slice(0, 10)}`;
    const sc = slowCache.get(sk);
    if (sc && sc.userWrites === userWriteCount() && Date.now() - sc.at < 5 * 60000) list = sc.list;
    else {
      const t0 = Date.now();
      try { list = src.alerts(user) || []; } catch (e) {
        try { require('./errorLog.js').logError(e, { where: `warnings of ${src.id}` }); } catch (x) { /* ignore */ }
        list = [];
      }
      if (Date.now() - t0 > 40 && src.id !== 'myday') { slowCache.set(sk, { list, userWrites: userWriteCount(), at: Date.now() }); if (slowCache.size > 60) slowCache.delete(slowCache.keys().next().value); } else slowCache.delete(sk);
    }
    for (const raw of list) {
      const a = clean(raw, src.id);
      if (!a || seen.has(a.id)) continue;
      if (a.perm && !(Array.isArray(a.perm) ? a.perm.some((p) => can(user, p)) : can(user, a.perm))) continue;
      seen.add(a.id);
      out.push(a);
    }
  }
  return sortAlerts(out);
}

// For Home: the 3 most urgent and how many more.
export function homeAlerts(user, { max = 3, today } = {}) {
  const all = collectAlerts(user, { today });
  return { top: all.slice(0, max), more: Math.max(0, all.length - max), all };
}
export function countByLevel(list) {
  return LEVELS.reduce((o, l) => ({ ...o, [l]: list.filter((a) => a.level === l).length }), {});
}
