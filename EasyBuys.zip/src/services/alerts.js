// Warnings registry. Every module can export `alerts(user)` from its index.js, returning
//   [{ id, level: 'urgent'|'warning'|'info', text, sub?, nav: { screen, params }, area, perm? }]
// Home, the full warnings list, sounds and (later) the dashboard and watchdog all read them from here.
// "Hide until tomorrow" works on warning / info only (never urgent), per person and per device, and ends next day.
import { getSetting, setSetting, dateStr, stamp } from './core.js';
import { writeCount, userWriteCount, keepTracked, trackedMs, forgetTracked, trackReads, noteDeps } from '../db/connection.js';
import { can } from './access.js';

export const LEVELS = ['urgent', 'warning', 'info'];
export const LEVEL_LABEL = { urgent: 'Urgent', warning: 'Warning', info: 'Information' };
export const LEVEL_TONE = { urgent: 'danger', warning: 'warn', info: 'info' };
const RANK = { urgent: 0, warning: 1, info: 2 };

let sources = null; // [{ id, alerts }]
// The list of modules, or a function returning it (set once by the registry; tests may pass their own).
export function setAlertSources(list) { sources = list; try { cache.clear(); forgetTracked('al|'); } catch (e) { /* first call */ } }
// The registry (src/modules/registry.js) hands over a function so switched-off modules are left out at the time.
function allSources() {
  if (typeof sources === 'function') { try { return sources() || []; } catch (e) { return []; } }
  return sources || [];
}

// Most urgent first; within a level, the order the modules gave them.
export function sortAlerts(list) {
  return list.map((a, i) => ({ a, i })).sort((x, y) => (RANK[x.a.level] ?? 3) - (RANK[y.a.level] ?? 3) || x.i - y.i).map((x) => x.a);
}
function clean(a, area) {
  if (!a || !a.id || !a.text) return null;
  const level = LEVELS.includes(a.level) ? a.level : 'info';
  return { ...a, level, area: a.area || area, nav: a.nav || null };
}

// ---------------------------------------------------------------- hiding (per person, per device, until tomorrow)
const hideKey = (user) => `alerts_hidden_${(user && (user.uid || user.id)) || 'anyone'}`;
function hiddenMap(user, today = dateStr()) {
  let m = {};
  try { m = JSON.parse(getSetting(hideKey(user), '{}')) || {}; } catch (e) { m = {}; }
  // Only today's hides count; older ones have expired.
  return Object.fromEntries(Object.entries(m).filter(([, d]) => d === today));
}
export function isHidden(user, id, today) { return !!hiddenMap(user, today)[id]; }
export function hideAlert(user, alert, today = dateStr()) {
  if (!alert || alert.level === 'urgent') throw new Error('Urgent warnings cannot be hidden.');
  const m = hiddenMap(user, today);
  m[alert.id] = today;
  setSetting(hideKey(user), JSON.stringify(m));
}
export function unhideAll(user) { require('./guard.js').requireLogin(user); setSetting(hideKey(user), '{}'); }

// ---------------------------------------------------------------- collecting
// Every warning this person may see (urgent first). A module that fails is skipped (the problem log has it).
// v3.9.4 speed: the warnings of every module are worked out once per person and reused by Home, the warning sound,
// My day and the dashboard – until something is saved, the minute changes, or (when only background saves happened,
// e.g. sync) 20 seconds have passed. Hidden ones are filtered afterwards, so "with" and "without hidden" share one list.
// My day's tasks are built from the other modules' warnings: it runs last and reads what was collected so far,
// instead of collecting everything a second time (that doubled the time Home took).
let depth = 0;
let inProgress = null; // { uid, out } while one collection is running
const cache = new Map(); // `${uid}|${role}|${today}` → { list, writes, minute, at }
export function collectAlerts(user, { includeHidden = false, today } = {}) {
  if (!user) return [];
  // Safety: a module whose warnings look at other warnings must never loop (the app would freeze).
  if (depth >= 2) return [];
  const hideOff = (list) => {
    if (includeHidden) return list.slice();
    const hidden = hiddenMap(user, today);
    return list.filter((a) => a.level === 'urgent' || !hidden[a.id]);
  };
  if (depth >= 1) {
    // Asked from inside a collection (My day): the warnings gathered so far, or the last full list.
    if (inProgress && inProgress.uid === user.uid) return hideOff(sortAlerts(inProgress.out.slice()));
    const c = cache.get(`${user.uid}|${user.role}|${today || ''}`);
    if (c) { noteDeps(c.deps); return hideOff(c.list); }
  }
  const key = `${user.uid}|${user.role}|${today || ''}`;
  const c = cache.get(key);
  const nowMs = Date.now();
  const minute = stamp().slice(0, 16);
  if (depth === 0 && c && c.minute === minute && (c.writes === writeCount() || (c.userWrites === userWriteCount() && nowMs - c.at < 60000))) { noteDeps(c.deps); return hideOff(c.list); }
  depth += 1;
  const outer = inProgress;
  try {
    const r = trackReads(() => collectOnce(user, { today }));
    const list = r.value;
    if (depth === 1) {
      cache.set(key, { list, writes: writeCount(), userWrites: userWriteCount(), minute, at: Date.now(), deps: r.deps });
      if (cache.size > 12) cache.delete(cache.keys().next().value);
    }
    return hideOff(list);
  } finally { depth -= 1; inProgress = outer; }
}
// The lists put together for Home are forgotten; each module's own kept answer stays until what it read changes.
export function clearAlertCache() { cache.clear(); }
// The newest list worked out for an owner or admin on this device (the online dashboard reuses it), or null.
export function cachedOwnerAlerts(maxAgeMs = 10 * 60000) {
  let best = null;
  for (const [k, v] of cache) {
    const role = k.split('|')[1];
    if (!['owner', 'admin'].includes(role) || Date.now() - v.at > maxAgeMs) continue;
    if (!best || v.at > best.at) best = v;
  }
  if (best) noteDeps(best.deps);
  return best ? best.list.slice() : null;
}
function orderedSources() {
  // My day last: it builds its tasks from the others.
  const list0 = allSources();
  return list0.filter((x) => x && x.id !== 'myday').concat(list0.filter((x) => x && x.id === 'myday'));
}
function collectOnce(user, { today }) {
  const out = [];
  const seen = new Set();
  inProgress = { uid: user.uid, out };
  for (const src of orderedSources()) oneSource(user, src, { today, out, seen });
  return sortAlerts(out);
}
// One module's warnings into `out` (the slow ones kept for a while, see below).
// 1.0.0 round 2: each module's warnings (or each part of a module that gives them in parts) are kept until something
// the module READ changes (db/connection.js keepTracked: its tables, the single settings it read), so after a save
// only the modules that use what was saved are worked out again. Because some warnings also depend on the clock
// ("no sales for an hour"), a module's answer is also worked out again after a minute – after 5 minutes for a module
// that takes long (more than 40 ms), as before – and on a new day. My day is built from the others: never kept.
let userKeyMemo = new WeakMap();
function userKey(user) {
  let k = userKeyMemo.get(user);
  if (!k) {
    let h = 0x811c9dc5; const t = JSON.stringify(user) || '';
    for (let i = 0; i < t.length; i += 1) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    k = `${user.uid}|${user.role}|${(h >>> 0).toString(36)}`;
    userKeyMemo.set(user, k);
  }
  return k;
}
const partKey = (src, i, user, today) => `al|${src.id}|${i}|${userKey(user)}|${today || ''}|${stamp().slice(0, 10)}`;
function keptPart(src, i, fn, user, today) {
  if (src.id === 'myday') return fn(user) || [];
  const k = partKey(src, i, user, today);
  const ms = trackedMs(k);
  return keepTracked(k, () => fn(user) || [], { maxAgeMs: ms !== null && ms > 40 ? 5 * 60000 : 60000, needDeps: true });
}
const partsOf = (src) => (src && typeof src.alerts === 'function' && Array.isArray(src.alerts.parts) ? src.alerts.parts : null);
// given: the module's list already worked out (in parts, by collectAlertsAsync): { list } or { error }
function oneSource(user, src, { today, out, seen, given = null }) {
  if (!src || typeof src.alerts !== 'function') return;
  let list = [];
  try {
    if (given && given.error) throw given.error;
    if (given) list = given.list;
    else {
      const parts = partsOf(src);
      list = parts ? parts.flatMap((fn, i) => keptPart(src, i, fn, user, today)) : keptPart(src, 'all', src.alerts, user, today);
    }
  } catch (e) {
    try { require('./errorLog.js').logError(e, { where: `warnings of ${src.id}` }); } catch (x) { /* ignore */ }
    list = [];
  }
  for (const raw of list) {
    const a = clean(raw, src.id);
    if (!a || seen.has(a.id)) continue;
    if (a.perm && !(Array.isArray(a.perm) ? a.perm.some((p) => can(user, p)) : can(user, a.perm))) continue;
    seen.add(a.id);
    out.push(a);
  }
}

// 1.0.0 the same list as collectAlerts, worked out one module at a time with a pause after each, so the screens keep
// answering while it is made (Home and the warning sound use it). The same kept answers are used and kept; two asks
// at the same time share one collection.
const running = new Map();
const pauseNow = () => new Promise((r) => setTimeout(r, 0));
export function collectAlertsAsync(user, { includeHidden = false, today, pause = pauseNow } = {}) {
  if (!user) return Promise.resolve([]);
  const hideOff = (list) => {
    if (includeHidden) return list.slice();
    const hidden = hiddenMap(user, today);
    return list.filter((a) => a.level === 'urgent' || !hidden[a.id]);
  };
  const key = `${user.uid}|${user.role}|${today || ''}`;
  const c = cache.get(key);
  const nowMs = Date.now();
  const minute = stamp().slice(0, 16);
  if (depth === 0 && c && c.minute === minute && (c.writes === writeCount() || (c.userWrites === userWriteCount() && nowMs - c.at < 60000))) { noteDeps(c.deps); return Promise.resolve(hideOff(c.list)); }
  if (depth > 0) return Promise.resolve(collectAlerts(user, { includeHidden, today }));
  if (!running.has(key)) {
    const job = (async () => {
      const out = [];
      const seen = new Set();
      const deps = new Set(); // what the whole list was made from (passed on to whoever reuses the list)
      const inside = (fn) => { const outer = inProgress; depth += 1; inProgress = { uid: user.uid, out }; try { const r = trackReads(fn); r.deps.forEach((d) => deps.add(d)); return r.value; } finally { depth -= 1; inProgress = outer; } };
      for (const src of orderedSources()) {
        // each module on its own, as inside collectAlerts (My day sees what was collected so far); a module that
        // gives its warnings in parts (alerts.parts) is worked out a part at a time – the same list in the same order
        const parts = partsOf(src);
        if (parts && src.id !== 'myday') {
          const given = { list: [] };
          for (let i = 0; i < parts.length; i += 1) {
            try { given.list.push(...inside(() => keptPart(src, i, parts[i], user, today))); } catch (e) { given.error = e; }
            if (given.error) break;
            await pause();
          }
          inside(() => oneSource(user, src, { today, out, seen, given }));
        } else inside(() => oneSource(user, src, { today, out, seen }));
        await pause();
      }
      const list = sortAlerts(out);
      cache.set(key, { list, writes: writeCount(), userWrites: userWriteCount(), minute: stamp().slice(0, 16), at: Date.now(), deps: [...deps] });
      if (cache.size > 12) cache.delete(cache.keys().next().value);
      return list;
    })();
    running.set(key, job);
    job.then(() => running.delete(key), () => running.delete(key));
  }
  return running.get(key).then((list) => hideOff(list));
}
export async function homeAlertsAsync(user, { max = 3, today, pause } = {}) {
  const all = await collectAlertsAsync(user, { today, ...(pause ? { pause } : {}) });
  return { top: all.slice(0, max), more: Math.max(0, all.length - max), all };
}

// 1.0.0 Home paints first and works the warnings out just after (HomeScreen.js): this gives the list straight away
// when it is still valid (the same rule as collectAlerts), otherwise null.
export function peekHomeAlerts(user, { max = 3, today } = {}) {
  if (!user) return { top: [], more: 0, all: [] };
  const c = cache.get(`${user.uid}|${user.role}|${today || ''}`);
  const nowMs = Date.now();
  if (!c || c.minute !== stamp().slice(0, 16) || !(c.writes === writeCount() || (c.userWrites === userWriteCount() && nowMs - c.at < 60000))) return null;
  const hidden = hiddenMap(user, today);
  const all = c.list.filter((a) => a.level === 'urgent' || !hidden[a.id]);
  return { top: all.slice(0, max), more: Math.max(0, all.length - max), all };
}
// For Home: the 3 most urgent and how many more.
export function homeAlerts(user, { max = 3, today } = {}) {
  const all = collectAlerts(user, { today });
  return { top: all.slice(0, max), more: Math.max(0, all.length - max), all };
}
export function countByLevel(list) {
  return LEVELS.reduce((o, l) => ({ ...o, [l]: list.filter((a) => a.level === l).length }), {});
}
