// v3.9.5 "one place for everything": the areas on Home. Each area gathers the daily jobs, records and checks of its
// modules on one screen. Reports live only in Reports and settings only in Settings – an area just links to them.
// Nothing is removed: every module menu item still opens the same screen as before.
import { visibleMenu } from './menus.js';

// Order = the order on Home. `modules`: the module menus shown in the area (first = main one).
// `extra`: items from other places that belong here (same shape as a menu item, with `module`).
export const AREAS = [
  { id: 'till', icon: '💵', title: 'Sales & tills', note: 'Till counts, handover, End of day, cash, deposits', modules: ['till'], reportGroups: ['Till & cash'] },
  { id: 'inventory', icon: '📦', title: 'Stock & orders', note: 'Products, orders, receiving, stock take, FCCC', modules: ['inventory'], reportGroups: ['Inventory', 'Purchase orders', 'Stock take'] },
  { id: 'payables', icon: '🧾', title: 'Suppliers & paying', note: 'Invoices, paying, cheques, suppliers', modules: ['payables'], reportGroups: ['Invoices & cheques'] },
  { id: 'people', icon: '👥', title: 'People & pay', note: 'Staff, roster, timesheets, leave, payroll', modules: ['timesheets', 'leave', 'payroll', 'staff', 'recruitment', 'timeclock'], reportGroups: ['Timesheets', 'Leave', 'Payroll'] },
  { id: 'money', icon: '💰', title: 'Money & accounts', note: 'Bank, M-PAiSA, loans & rent, VAT, the books', modules: ['bank', 'loans', 'accounting', 'owed', 'drawings'], reportGroups: ['Business insight', 'Bank', 'Loans & rent', 'Accounting & VAT', 'Who owes us', 'Owner overview'] },
  { id: 'bakery', icon: '🥖', title: 'Bakery', note: 'Bakery today, production, stock, wastage', modules: ['bakery'], reportGroups: ['Bakery'] },
  { id: 'trade', icon: '🏪', title: 'Wholesale', note: 'Customer and supplier accounts, agreements, shop photos', modules: ['trade'], reportGroups: [] }, // 1.0.0 build 23 (off until switched on)
  { id: 'papers', icon: '📁', title: 'Shops & papers', note: 'Shop pages, licences, documents, vehicles & equipment', modules: ['licences', 'vehicles'], reportGroups: ['Licences & compliance', 'Vehicles & equipment'],
    extra: [{ module: 'admin', id: 'adm-shoppages', icon: '🏪', title: 'Shops', note: 'One page per shop: details, bills, papers, costs.', screen: 'ShopProfiles', section: 'Daily tasks' },
      { module: 'admin', id: 'adm-bills', icon: '💡', title: 'Power & water bills', note: 'Water checked every day; EFL one tap a month.', screen: 'Bills', section: 'Daily tasks' },
      { module: 'admin', id: 'adm-docs', icon: '📁', title: 'Documents', note: 'Every document kept by the app, with who may see it.', screen: 'Documents', section: 'Records' }] },
];
// 1.0.0 Office › Records: one hub per part of the business (the map the owner approved, screen "Records").
// `top`: the main pages, shown first as big rows – a menu item ('module:id') or a page of its own ({ id, screen, … }).
// `modules`: every other job, record and check of those modules, in drop-downs under the main pages (nothing removed).
// `hook`: when another part of the app builds one page for the whole hub (e.g. Aronium), the hub row opens it instead.
// `settingsArea`: which part of Settings the hub's "Settings" link opens.
export const HUBS = [
  // Release 03 (owner, 12 Nov: "one place for VAT, one place for payroll only with FNPF, one place for staff profile,
  // no duplicates"): VAT and Payroll & FNPF are places of their own (they were under Staff › Payroll and Money).
  { id: 'tax', icon: '🧾', title: 'VAT', note: 'Month records, the VAT return for FRCS, invoices from before the app, tax calendar, filing', modules: [], reportGroups: ['Accounting & VAT'], settingsArea: 'money',
    top: ['accounting:acc-month-records', { module: 'accounting', id: 'rec-vat', icon: '🧾', title: 'VAT return – the month', note: 'The VAT return for FRCS: check, lodge, pay.', hook: 'VAT', screen: 'TaxReturns' },
      'accounting:acc-vat-frcs', 'accounting:acc-vat', 'accounting:acc-history', 'payroll:pay-taxcal', 'payroll:pay-filing', 'accounting:acc-tax', 'inventory:inv-vat'] },
  { id: 'payroll', icon: '💰', title: 'Payroll & FNPF', note: 'Pay runs, sign-off, FNPF and PAYE, payslips, advances', modules: ['payroll'], reportGroups: ['Payroll'], settingsArea: 'people',
    top: ['payroll:home', 'payroll:pay-new', 'payroll:pay-signoff', { module: 'payroll', id: 'rec-fnpf', icon: '🏦', title: 'FNPF', note: 'FNPF per person per week, and the month.', hook: 'FNPF', screen: 'Statutory' },
      'payroll:pay-stat', 'payroll:pay-debts', 'payroll:pay-final', 'payroll:pay-yearend'] },
  { id: 'suppliers', icon: '🧾', title: 'Suppliers & invoices', note: 'Suppliers, invoices, cheques, statements', modules: ['payables', 'verify'], reportGroups: ['Invoices & cheques'], settingsArea: 'payables',
    top: ['payables:ap-suppliers', 'payables:home', 'payables:ap-to-check', 'payables:chq-home', 'payables:ap-regulars', 'payables:ap-sup-statement',
      { module: 'payables', id: 'rec-standings', icon: '🏷️', title: 'Supplier standings', note: 'What is still pending with each supplier.', hook: 'SUPPLIER_STANDINGS' },
      { module: 'payables', id: 'rec-nosupplier', icon: '🔗', title: 'Products with no supplier', note: 'Give each Aronium product its supplier.', screen: 'NoSupplierProducts' }] },
  { id: 'inventory', icon: '📦', title: 'Inventory & purchase orders', note: 'Stock, orders, stock take, losses, prices', modules: ['inventory'], reportGroups: ['Inventory', 'Purchase orders', 'Stock take'], settingsArea: 'inventory',
    top: ['inventory:home', 'inventory:inv-stock', { module: 'inventory', id: 'rec-arproducts', icon: '🏷️', title: 'Products from Aronium', hook: 'AR_PRODUCTS' }, 'inventory:inv-po', 'inventory:inv-low', 'inventory:inv-expiry', 'inventory:inv-transfers', 'inventory:inv-return', 'inventory:inv-losses', { item: 'inventory:inv-count', hook: 'STOCK_TAKE', id: 'inv-count-join', title: 'Stock take – count together', note: 'Every phone joins the shop\'s one stock take; counts add up.' }, 'inventory:inv-costs',
      { module: 'inventory', id: 'rec-dmgwaiting', icon: '⚠️', title: 'Damaged – waiting for replacement', hook: 'DAMAGED_WAITING' }] },
  { id: 'bakery', icon: '🥖', title: 'Bakery', note: 'Production plan, recipes, ingredients, batches', modules: ['bakery'], reportGroups: ['Bakery'], settingsArea: 'bakery',
    top: ['bakery:home', 'bakery:bk-plan', 'bakery:bk-mine', 'bakery:bk-stock', 'bakery:bk-order', 'bakery:bk-wastage', 'bakery:bk-trace', 'bakery:bk-equipment'] },
  { id: 'staff', icon: '👥', title: 'Staff', note: 'Staff profiles, roster, timesheets, time clock, leave, vacancies', modules: ['staff', 'timesheets', 'leave', 'recruitment', 'timeclock'], reportGroups: ['Timesheets', 'Leave'], settingsArea: 'people',
    top: ['staff:home', 'timesheets:ts-whoison', 'timesheets:ts-roster', 'timesheets:home', 'leave:home', 'recruitment:home',
      { module: 'home', id: 'rec-mine', icon: '🙋', title: 'My own pages', note: 'My week, my hours, my leave, my pay.', screen: 'MyWeek' },
      { module: 'staff', id: 'rec-myprofile', icon: '🪪', title: 'My profile', note: 'My details, pay, hours, leave, payslips, what I owe.', screen: 'MyStaffProfile' }] },
  { id: 'money', icon: '🏦', title: 'Money & bank', note: 'Bank & M-PAiSA, deposits, cash & safe, bills, loans & rent, owner\'s money, who owes us', modules: ['till', 'bank', 'loans', 'owed', 'drawings'], reportGroups: ['Bank', 'Till & cash', 'Loans & rent', 'Who owes us', 'Owner overview'], settingsArea: 'money',
    // Release 05: everything about the bank in one place – the statement, cheques, deposits, moves, wallets, loans
    top: [{ item: 'bank:home', hook: 'BANK_MATCH', id: 'bank-match', title: 'Match the statement', note: 'Each bank and M-PAiSA line: what it is, in one tap.' }, 'bank:bank-import', 'payables:chq-home', { module: 'payables', id: 'rec-deposits', icon: '🏦', title: 'Deposits', note: 'Plan a deposit (takings, cheques or both), write the slip, bank it.', screen: 'DepositPlans' }, 'bank:bank-wallets', { item: 'bank:bank-month', hook: 'BANK_RECON', id: 'bank-recon', title: 'Bank reconciliation – the month', note: 'BSP and both M-PAiSA wallets: statement against the books.' }, { module: 'till', id: 'rec-recharge', icon: '📱', title: 'Recharge machines', note: 'Vodafone and Inkk balance per shop: top-ups, sales, commission.', screen: 'Recharge' }, 'till:till-cash',
      { module: 'admin', id: 'adm-bills', icon: '💡', title: 'Bills – EFL, water, phone', note: 'Read from a photo or PDF, then paid.', screen: 'Bills' },
      'loans:home', { module: 'bank', id: 'bank-move', icon: '🔁', title: 'Move money between accounts', note: 'Cheque account → Visa debit, and back.', screen: 'MoveMoney' }, 'drawings:home', 'owed:home'] },
  { id: 'aronium', icon: '🔗', title: 'Aronium', note: 'Sales & receipts from the tills, End of days, product changes', modules: [], reportGroups: ['Till & cash'], settingsArea: 'till', hook: 'ARONIUM_HUB',
    top: [{ module: 'till', id: 'rec-aritems', icon: '🧮', title: 'Items sold', note: 'By day, shift and till.', hook: 'AR_ITEMS' }, { module: 'inventory', id: 'rec-arproducts', icon: '🏷️', title: 'Products from Aronium', hook: 'AR_PRODUCTS' },
      'till:till-sales', 'till:till-eod', 'accounting:acc-aronium', 'inventory:inv-watch', 'inventory:inv-ar-update',
      { module: 'admin', id: 'rec-arinsights', icon: '💡', title: 'Aronium insights', note: 'Busy hours, reorder list, cashier watch, slow movers.', screen: 'AroniumInsights' },
      { module: 'admin', id: 'rec-arpurchases', icon: '🧾', title: 'Aronium purchases vs invoices', screen: 'ArPurchases' },
      { module: 'admin', id: 'rec-arlink', icon: '🖥️', title: 'Till PCs (Aronium Link)', note: 'Each till PC and when it last sent.', screen: 'AroniumLink' }] },
  { id: 'cigarettes', icon: '🚬', title: 'Cigarettes', note: 'Tally, cigarette money, the supplier invoice', modules: [], reportGroups: ['Till & cash'], settingsArea: 'till', hook: 'CIGARETTES',
    top: ['till:till-cig', 'till:till-cig-fund'] },
  { id: 'assets', icon: '🚚', title: 'Vehicles, equipment & licences', note: 'Fuel, faults, services, licences and papers', modules: ['vehicles', 'licences'], reportGroups: ['Licences & compliance', 'Vehicles & equipment'], settingsArea: 'papers',
    top: ['vehicles:home', 'vehicles:ve-due', 'licences:home',
      { module: 'admin', id: 'adm-shoppages', icon: '🏪', title: 'Shops', note: 'One page per shop: details, bills, papers, costs.', screen: 'ShopProfiles' },
      { module: 'admin', id: 'adm-docs', icon: '📁', title: 'Documents', note: 'Every document kept by the app, with who may see it.', screen: 'Documents' }] },
  { id: 'books', icon: '📚', title: 'The books', note: 'Ledger, journal, trial balance, profit & loss, balance sheet, cash flow, year end', modules: ['accounting'], reportGroups: ['Accounting & VAT', 'Business insight'], settingsArea: 'money',
    top: [{ item: 'accounting:home', hook: 'BOOKS_HOME', id: 'books-home', title: 'The books', note: 'Journal, ledger, trial balance, profit & loss, balance sheet.' }, 'accounting:acc-gl', 'accounting:acc-journal', 'accounting:acc-ap', 'accounting:acc-ar', 'accounting:acc-tb', 'accounting:acc-pl', 'accounting:acc-bs', 'accounting:acc-forecast', 'accounting:acc-coa', 'accounting:acc-year',
      { module: 'admin', id: 'adm-year', icon: '🗄️', title: 'Year end: close & archive', screen: 'YearArchive' },
      { module: 'admin', id: 'adm-queries', icon: '❓', title: 'Accountant questions', screen: 'Queries' }] },
];
HUBS.push({ id: 'trade', icon: '🏪', title: 'Customers & suppliers (wholesale)', note: 'Accounts, credit agreements, shop photos and map pins', modules: ['trade'], reportGroups: [], settingsArea: 'trade',
  top: ['trade:dl-board', 'trade:dl-map', 'trade:dl-mine', 'trade:home'] });
export const getHub = (id) => HUBS.find((h) => h.id === id) || null;
// Release 03 "no duplicates": the one place of a page that more than one part used to show. Another part leaves it
// out – unless this person cannot open that one place (then it stays where they can reach it).
export const HOME_OF = {
  ChequeCover: 'money', ChequeHome: 'money', Cheques: 'money', DepositPlans: 'money', ReceiveGoods: 'inventory', POEdit: 'inventory', Owed: 'money', Statutory: 'payroll',
  ArProducts: 'aronium', ProductChanges: 'aronium', AroniumUpdate: 'aronium', ArPurchases: 'aronium', SalesHistory: 'aronium', AroniumEods: 'aronium', AroniumInbox: 'aronium',
  TaxReturns: 'tax', VatReturn: 'tax', TaxCentre: 'tax', TaxCalendar: 'tax', Filing: 'tax', HistoryHome: 'tax', VatCheck: 'tax', MonthRecords: 'tax',
  CigTally: 'cigarettes', CigFund: 'cigarettes',
};
// Quick check for the Records list: may this person open at least one page of the hub? Stops at the first one
// (the full hub is only worked out when it is opened – Home stays fast).
export function hubVisible(hub, user, screens, getModule) {
  const { permOk, screenOf } = require('./menus.js');
  const on = (mid) => { const m = getModule(mid); if (!m || !m.switchable) return true; try { return require('../modules/admin/service.js').moduleOn(mid); } catch (e) { return true; } };
  const opens = (name) => { try { return !screens || (!!screens[name] && screens[name].can(user)); } catch (e) { return false; } };
  const itemOk = (it) => { try { return permOk(it.perm, user) && opens(screenOf(it, user)); } catch (e) { return false; } };
  for (const ref of hub.top || []) {
    // a menu item ('module:id'), or { item: 'module:id', hook } – the same item, opening the hook's new page once it is in
    if (typeof ref === 'string' || (ref && ref.item)) {
      const [mid, iid] = (typeof ref === 'string' ? ref : ref.item).split(':');
      const mod = getModule(mid);
      if (!mod || !on(mid)) continue;
      for (const sec of mod.menu || []) { const it = (sec.items || []).find((x) => x.id === iid); if (it && itemOk(it)) return true; }
    } else if (ref && ref.screen && (!ref.module || !getModule(ref.module) || on(ref.module)) && opens(ref.screen)) return true;
  }
  for (const mid of hub.modules || []) {
    const mod = getModule(mid);
    if (!mod || !on(mid)) continue;
    for (const sec of mod.menu || []) {
      if (!['Daily tasks', 'Records', 'Checks'].includes(sec.section)) continue;
      for (const it of sec.items || []) if (itemOk(it)) return true;
    }
  }
  return false;
}
// The old Home areas (3.9.5–3.9.8) open the hub that took their place.
export const HUB_OF_AREA = { till: 'money', inventory: 'inventory', payables: 'suppliers', people: 'staff', money: 'money', bakery: 'bakery', papers: 'assets' };

export const AREA_OF_MODULE = AREAS.reduce((m, a) => { a.modules.forEach((id) => { m[id] = a.id; }); return m; }, { admin: 'system', devices: 'system', sync: 'system', verify: 'verify', dashboard: 'dashboard', home: 'home' });
export const getArea = (id) => getHub(id) || AREAS.find((a) => a.id === id) || null;

// The testID of an item on an area screen: `mi-<id>`, except the "home" item of the 2nd, 3rd… module
// (every module calls its first item "home"), which becomes `mi-home-<module>`.
export function areaItemTestId(area, moduleId, itemId) {
  if (itemId === 'home' && area && area.modules[0] !== moduleId) return `mi-home-${moduleId}`;
  return `mi-${itemId}`;
}

// What one area shows this person: per module, the daily jobs and the records & checks (no reports, no settings),
// plus the report screens and settings it links to. `mods` = getModule(id) lookups (passed in to avoid a cycle).
// v3.9.7 each option once: an item that opens the same screen as one already listed (or one of the jobs already on
// Home – `hide`) is left out, and a person's own "My …" page is left out when they see everyone's version.
const PERSONAL = { MyRoster: 'timesheets_view', MyLeave: 'leave_approve', MyPayslips: 'payroll_view', MyHours: 'timesheets_view' };
// the same by item: own leave for a manager, and "Leave to approve" (the Leave page opens on the approvals)
const PERSONAL_IDS = { 'leave-mine': 'leave_approve', 'leave-approve': 'leave_approve', 'ts-myroster': 'timesheets_view', 'pay-mine': 'payroll_view', 'ts-myhours': 'timesheets_view' };
const sameKey = (it) => { const p = { ...(it.params || {}) }; delete p.shopCode; return `${it.screen}|${JSON.stringify(p)}`; };
function elsewhereFn(area, user, screens, getModule) {
  if (!area || !getHub(area.id)) return () => false; // an old area: unchanged
  const seen = {};
  return (screen) => {
    const home = HOME_OF[screen];
    if (!home || home === area.id) return false;
    if (!(home in seen)) { let v = false; try { v = !!getHub(home) && hubVisible(getHub(home), user, screens, getModule); } catch (e) { v = false; } seen[home] = v; }
    return seen[home];
  };
}
export function areaView(area, user, screens, getModule, { hide = [] } = {}) {
  const blocks = [];
  const reportScreens = [];
  const settings = [];
  const seenItems = new Set();
  const hideSet = new Set(hide);
  let canFn = null;
  try { canFn = require('./access.js').can; } catch (e) { canFn = null; }
  const elsewhere = elsewhereFn(area, user, screens, getModule);
  const keep = (it) => {
    if (!it || !it.screen) return true;
    if (hideSet.has(it.screen)) return false;
    if (elsewhere(it.screen)) return false;
    // a link to another module of this same area (its items are already here)
    if (it.screen === 'ModuleMenu' && it.params && area.modules.includes(it.params.module)) return false;
    if (PERSONAL_IDS[it.id] && canFn && (PERSONAL_IDS[it.id] === true || canFn(user, PERSONAL_IDS[it.id]))) return false;
    if (PERSONAL[it.screen] && canFn && canFn(user, PERSONAL[it.screen])) return false;
    const k = sameKey(it);
    if (seenItems.has(k)) return false;
    seenItems.add(k);
    return true;
  };
  // 1.0.0 the hub's main pages first (each once; the same page is not repeated in the drop-downs below)
  const top = [];
  const modOn = (mid) => { const m = getModule(mid); if (!m) return true; if (!m.switchable) return true; try { return require('../modules/admin/service.js').moduleOn(mid); } catch (e) { return true; } };
  for (const ref of area.top || []) {
    let item = null;
    // a menu item ('module:id'), or { item: 'module:id', hook } – the same item, opening the hook's new page once it is in
    if (typeof ref === 'string' || (ref && ref.item)) {
      const [mid, iid] = (typeof ref === 'string' ? ref : ref.item).split(':');
      const mod = getModule(mid);
      if (!mod || !modOn(mid)) continue;
      let secs = [];
      try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
      for (const sec of secs) { const it = sec.items.find((x) => x.id === iid); if (it) { item = { ...it, module: mid, testID: areaItemTestId(area, mid, iid), ...(ref.hook ? { hook: ref.hook } : {}) }; break; } }
    } else if (ref && ref.hook && !ref.screen) {
      // a page another part of 1.0.0 builds: shown once it is in the app
      let t = null;
      try { t = screens ? require('../modules/home/shellModel.js').resolveHook(ref.hook, screens, user) : null; } catch (e) { t = null; }
      if (!t) continue;
      item = { ...ref, screen: t.screen, params: t.params, testID: `mi-${ref.id}` };
    } else if (ref && ref.screen) {
      if (ref.module && getModule(ref.module) && !modOn(ref.module)) continue;
      const sc = screens ? screens[ref.screen] : null;
      if (screens && (!sc || !sc.can(user))) continue; // a hooked page: the person must be able to open the page it falls back to
      item = { ...ref, testID: `mi-${ref.id}` };
    }
    if (!item) continue;
    if (elsewhere(item.screen)) continue;
    // { item, hook } whose new page is in the app: the row opens the new page (with the hub's own words for it), and
    // the old page stays in its part's drop-down below (nothing built is lost – e.g. Bank reconciliation's "in the
    // bank now" page, the stock take pages, Bank month end, the accounting overview)
    if (ref && ref.item && ref.hook && screens) {
      let t = null;
      try { t = require('../modules/home/shellModel.js').resolveHook(ref.hook, screens, user); } catch (e) { t = null; }
      if (t && t.screen !== item.screen) {
        const nu = { ...item, screen: t.screen, params: t.params, title: ref.title || item.title, note: ref.note || item.note, testID: `mi-${ref.id || `${item.id}-new`}` };
        const nk = sameKey(nu);
        if (seenItems.has(nk)) continue;
        seenItems.add(nk);
        top.push(nu);
        continue;
      }
    }
    const k = sameKey(item);
    if (seenItems.has(k)) continue;
    seenItems.add(k);
    top.push(item);
  }
  for (const mid of area.modules) {
    const mod = getModule(mid);
    if (!mod) continue;
    // a module switched off (Settings › Modules on / off) is left out, with every link in its menu
    if (mod.switchable) { try { if (!require('../modules/admin/service.js').moduleOn(mid)) continue; } catch (e) { /* on */ } }
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    const daily = [];
    const more = [];
    for (const sec of secs) {
      for (const it of sec.items) {
        const item = { ...it, module: mid, testID: areaItemTestId(area, mid, it.id) };
        if ((sec.section === 'Daily tasks' || sec.section === 'Records' || sec.section === 'Checks') && !keep(item)) continue;
        if (sec.section === 'Daily tasks') daily.push(item);
        else if (sec.section === 'Records' || sec.section === 'Checks') more.push(item);
        else if (sec.section === 'Reports') { if (it.screen !== 'ReportsHub') reportScreens.push(item); }
        else if (sec.section === 'Settings') settings.push(item);
      }
    }
    if (daily.length || more.length) blocks.push({ module: mid, title: mod.title, icon: mod.icon, daily, more });
  }
  for (const it of area.extra || []) {
    const s = screens ? screens[it.screen] : null;
    if (screens && (!s || !s.can(user))) continue;
    const item = { ...it, testID: `mi-${it.id}` };
    if (!keep(item)) continue;
    const b = blocks[blocks.length - 1];
    if (b) (it.section === 'Daily tasks' ? b.daily : b.more).push(item);
    else blocks.push({ module: it.module, title: area.title, icon: area.icon, daily: it.section === 'Daily tasks' ? [item] : [], more: it.section === 'Daily tasks' ? [] : [item] });
  }
  return { top, blocks, reportScreens, settings, empty: !blocks.length && !top.length };
}

// Areas this person can use (at least one item).
export function areasFor(user, screens, getModule) {
  return AREAS.filter((a) => !areaView(a, user, screens, getModule).empty);
}

// Every Settings item of every module, grouped by area (for the Settings screen). Items the Settings screen
// already shows by hand are left out by id (`skipScreens`).
export function settingsByArea(user, screens, modules, skipScreens = []) {
  const groups = {};
  const seen = new Set(); // Release 05: a setting shown in two modules' menus is listed once
  for (const mod of modules) {
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    for (const sec of secs) {
      if (sec.section !== 'Settings') continue;
      for (const it of sec.items) {
        if (skipScreens.includes(it.screen) && !it.params) continue;
        const k = `${it.screen}|${JSON.stringify(it.params || {})}`;
        if (seen.has(k)) continue;
        seen.add(k);
        const a = AREA_OF_MODULE[mod.id] || 'system';
        (groups[a] = groups[a] || []).push({ ...it, module: mod.id, moduleTitle: mod.title });
      }
    }
  }
  return groups;
}

// Report screens that are not in the shared report list (profit & loss, balance sheet, bakery dashboard…),
// from the "Reports" section of every module menu.
export function reportScreens(user, screens, modules) {
  const out = [];
  for (const mod of modules) {
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    for (const sec of secs) {
      if (sec.section !== 'Reports') continue;
      for (const it of sec.items) if (it.screen !== 'ReportsHub') out.push({ ...it, module: mod.id, moduleTitle: mod.title, area: AREA_OF_MODULE[mod.id] || 'system' });
    }
  }
  return out;
}

// The jobs Home already shows this person under "Daily jobs" (an area does not repeat them).
export function homeDailyScreens(user, screens) {
  const out = [];
  try {
    const A = require('./access.js');
    const on = (m) => { try { return require('../modules/admin/service.js').moduleOn(m); } catch (e) { return true; } };
    const ok = (n) => { try { return !!screens[n] && (!screens[n].can || screens[n].can(user)); } catch (e) { return false; } };
    if (A.can(user, 'verify_money')) out.push('Verify');
    if (A.can(user, 'snap_upload') || A.can(user, 'po_receive')) out.push('ReceiveGoods');
    if (A.can(user, 'snap_upload') && ok('HandCheque')) out.push('HandCheque');
    if (on('till') && ok('Handover') && ['till_count', 'till_approve', 'deposits'].some((p) => A.can(user, p))) out.push('Handover');
    if (A.can(user, 'my_hours') && on('timesheets')) out.push('MyHours');
    if (on('inventory') && ok('Fccc') && !A.can(user, 'inventory_manage')) out.push('Fccc');
    try { if (on('payroll') && require('../modules/payroll/signoff.js').canRunSignoff(user)) out.push('PaySignOff'); } catch (e) { /* payroll not here */ }
  } catch (e) { /* nothing hidden */ }
  return out;
}

// ---------------------------------------------------------------- 1.0.0 Settings, grouped like the approved map
// (screen "Settings"). Every setting screen of the app is in exactly one group; groups with nothing for this login
// are not shown.
export const SETTINGS_GROUPS_V1 = [
  ['setup', '🧭 Set up step by step'],
  ['shops', '🏪 Shops, tills & shifts'],
  ['checklists', '☑️ Checklists (each shop, bakery)'],
  ['cig', '🚬 Cigarettes'],
  ['suppliers', '🏷️ Suppliers, products & order days'],
  ['bakery', '🥖 Bakery – recipes, rules, proofing'],
  ['staff', '👥 Staff, roles & permissions'],
  ['pay', '💰 Pay, FNPF, tax & leave rules'],
  ['roster', '⏱️ Roster rules & face clock'],
  ['bank', '🏦 Bank, cheques & safe'],
  ['loans', '📉 Loans & rent'],
  ['accounts', '📚 Accounts & VAT'],
  ['aronium', '🔗 Aronium & till PCs'],
  ['papers', '📜 Vehicles, licences & papers'],
  ['alerts', '🔔 Alerts, Viber & emails'],
  ['dash', '📊 Dashboard & quick links'],
  ['layout', '📄 Report & document layout'],
  ['system', '📲 Phones, updates & backup'],
  ['history', '🗂️ Change history & deleted bin'],
  ['parts', '🧩 Parts on / off'],
  ['training', '🎓 Training mode & help'],
];
const SETTINGS_SCREEN_GROUP = {
  SetupWizard: 'setup', SetupPack: 'setup', GoLive: 'setup', BeforeGoLive: 'setup',
  TillSetup: 'shops', Shops: 'shops', ShopProfiles: 'shops', Device: 'shops', Bills: 'shops',
  DutyLists: 'checklists', ChecklistsSetup: 'checklists',
  CigFund: 'cig', CigTally: 'cig',
  ApSuppliers: 'suppliers', ApRules: 'suppliers', PayMethods: 'suppliers', InventorySetup: 'suppliers', SupplierImport: 'suppliers', SupplierMatch: 'suppliers', SupplierSchedules: 'suppliers', LooseLinks: 'suppliers', NoSupplierProducts: 'suppliers',
  Products: 'bakery', Materials: 'bakery', ShiftsSteps: 'bakery', BakeryProofing: 'bakery',
  Users: 'staff', Roles: 'staff', RecruitSetup: 'staff', ContractPdfSetup: 'staff', OwedSettings: 'staff', PersonPerms: 'staff',
  PayRules: 'pay', PayProfiles: 'pay', PayCycle: 'pay', PaySignSettings: 'pay', TaxCalendarSettings: 'pay', FilingSetup: 'pay', PayStatRules: 'pay', Leave: 'pay',
  RosterSettings: 'roster', RosterRules: 'roster', ClockRules: 'roster', FaceTest: 'roster', Roster: 'roster',
  Cheques: 'bank', BankLinks: 'bank', BankRules: 'bank', WalletSetup: 'bank', MpaisaColumns: 'bank', ChequeBooks: 'bank', PettyCashSetting: 'bank',
  LoanSetup: 'loans', LoanRules: 'loans', Recurring: 'loans', DrawingsSettings: 'loans',
  ChartOfAccounts: 'accounts', AcctSettings: 'accounts', OpeningBalances: 'accounts',
  AroniumLink: 'aronium', AroniumInsights: 'aronium', InvImport: 'aronium', OwedImport: 'aronium',
  VeEdit: 'papers', VeTypes: 'papers', VeSettings: 'papers', LicenceEdit: 'papers', LicenceQuick: 'papers', LicenceSettings: 'papers', Licences: 'papers',
  VerifySetup: 'alerts', AlertSounds: 'alerts', Emails: 'alerts', WatchdogSettings: 'alerts',
  DashboardCards: 'dash', DashboardBuilder: 'dash', DashboardRoles: 'dash', QuickLinks: 'dash', OnlineDashboard: 'dash',
  ReportTemplates: 'layout', DocDesigner: 'layout', DocSettings: 'layout',
  Devices: 'system', Backup: 'system', Storage: 'system', SyncStatus: 'system', HealthCheck: 'system', Updates: 'system', StartFresh: 'system',
  Audit: 'history', DeletedBin: 'history', RecordFix: 'history', Watchdog: 'history', Problems: 'history', DocCheck: 'history', Warnings: 'history', Documents: 'history', Queries: 'history', YearArchive: 'history',
  Modules: 'parts', TradeSettings: 'suppliers', TradeFiling: 'suppliers', DlSettings: 'suppliers', DlPlaces: 'suppliers',
  Training: 'training', Tutorials: 'training', TrainingProgress: 'training', About: 'training', Help: 'training',
};
const SETTINGS_MODULE_GROUP = { till: 'shops', inventory: 'suppliers', payables: 'suppliers', timesheets: 'roster', timeclock: 'roster', leave: 'pay', payroll: 'pay', staff: 'staff', recruitment: 'staff',
  bank: 'bank', loans: 'loans', drawings: 'loans', accounting: 'accounts', owed: 'staff', bakery: 'bakery', licences: 'papers', vehicles: 'papers', trade: 'suppliers', verify: 'alerts', dashboard: 'dash', admin: 'system', devices: 'system', sync: 'system', home: 'system' };
// The group of one setting. The bakery "Settings" screen is the bakery rules unless it opens its Online tab.
export function settingsGroupOf(screen, params, module) {
  if (screen === 'Settings') return params && params.tab === 'online' ? 'system' : 'bakery';
  return SETTINGS_SCREEN_GROUP[screen] || SETTINGS_MODULE_GROUP[module] || 'system';
}
