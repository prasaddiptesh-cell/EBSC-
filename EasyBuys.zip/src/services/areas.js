// v3.9.5 "one place for everything": the areas on Home. Each area gathers the daily jobs, records and checks of its
// modules on one screen. Reports live only in Reports and settings only in Settings – an area just links to them.
// Nothing is removed: every module menu item still opens the same screen as before.
import { visibleMenu } from './menus.js';

// Order = the order on Home. `modules`: the module menus shown in the area (first = main one).
// `extra`: items from other places that belong here (same shape as a menu item, with `module`).
export const AREAS = [
  { id: 'till', icon: '💵', title: 'Sales & tills', note: 'Till counts, handover, End of day, cash, deposits', modules: ['till'], reportGroups: ['Till & cash'] },
  { id: 'inventory', icon: '📦', title: 'Stock & orders', note: 'Products, orders, receiving, stock take, FCCC', modules: ['inventory'], reportGroups: ['Inventory', 'Purchase orders', 'Stock take'] },
  { id: 'payables', icon: '🧾', title: 'Suppliers & paying', note: 'Invoices, paying, cheques, suppliers', modules: ['payables'], reportGroups: ['Invoices & cheques'] },
  { id: 'people', icon: '👥', title: 'People & pay', note: 'Staff, roster, timesheets, leave, payroll', modules: ['timesheets', 'leave', 'payroll', 'staff', 'recruitment', 'timeclock'], reportGroups: ['Timesheets', 'Leave', 'Payroll'] },
  { id: 'money', icon: '💰', title: 'Money & accounts', note: 'Bank, M-PAiSA, loans & rent, VAT, the books', modules: ['bank', 'loans', 'accounting', 'owed', 'drawings'], reportGroups: ['Business insight', 'Bank', 'Loans & rent', 'Accounting & VAT', 'Who owes us', 'Owner overview'] },
  { id: 'bakery', icon: '🥖', title: 'Bakery', note: 'Bakery today, production, stock, wastage', modules: ['bakery'], reportGroups: ['Bakery'] },
  { id: 'papers', icon: '📁', title: 'Shops & papers', note: 'Shop pages, licences, documents, vehicles & equipment', modules: ['licences', 'vehicles'], reportGroups: ['Licences & compliance', 'Vehicles & equipment'],
    extra: [{ module: 'admin', id: 'adm-shoppages', icon: '🏪', title: 'Shops', note: 'One page per shop: details, bills, papers, costs.', screen: 'ShopProfiles', section: 'Daily tasks' },
      { module: 'admin', id: 'adm-bills', icon: '💡', title: 'Power & water bills', note: 'Water checked every day; EFL one tap a month.', screen: 'Bills', section: 'Daily tasks' },
      { module: 'admin', id: 'adm-docs', icon: '📁', title: 'Documents', note: 'Every document kept by the app, with who may see it.', screen: 'Documents', section: 'Records' }] },
];
export const AREA_OF_MODULE = AREAS.reduce((m, a) => { a.modules.forEach((id) => { m[id] = a.id; }); return m; }, { admin: 'system', devices: 'system', sync: 'system', verify: 'verify', dashboard: 'dashboard', home: 'home' });
export const getArea = (id) => AREAS.find((a) => a.id === id) || null;

// The testID of an item on an area screen: `mi-<id>`, except the "home" item of the 2nd, 3rd… module
// (every module calls its first item "home"), which becomes `mi-home-<module>`.
export function areaItemTestId(area, moduleId, itemId) {
  if (itemId === 'home' && area && area.modules[0] !== moduleId) return `mi-home-${moduleId}`;
  return `mi-${itemId}`;
}

// What one area shows this person: per module, the daily jobs and the records & checks (no reports, no settings),
// plus the report screens and settings it links to. `mods` = getModule(id) lookups (passed in to avoid a cycle).
// v3.9.7 each option once: an item that opens the same screen as one already listed (or one of the jobs already on
// Home – `hide`) is left out, and a person's own "My …" page is left out when they see everyone's version.
const PERSONAL = { MyRoster: 'timesheets_view', MyLeave: 'leave_approve', MyPayslips: 'payroll_view', MyHours: 'timesheets_view' };
// the same by item: own leave for a manager, and "Leave to approve" (the Leave page opens on the approvals)
const PERSONAL_IDS = { 'leave-mine': 'leave_approve', 'leave-approve': 'leave_approve', 'ts-myroster': 'timesheets_view', 'pay-mine': 'payroll_view', 'ts-myhours': 'timesheets_view' };
const sameKey = (it) => { const p = { ...(it.params || {}) }; delete p.shopCode; return `${it.screen}|${JSON.stringify(p)}`; };
export function areaView(area, user, screens, getModule, { hide = [] } = {}) {
  const blocks = [];
  const reportScreens = [];
  const settings = [];
  const seenItems = new Set();
  const hideSet = new Set(hide);
  let canFn = null;
  try { canFn = require('./access.js').can; } catch (e) { canFn = null; }
  const keep = (it) => {
    if (!it || !it.screen) return true;
    if (hideSet.has(it.screen)) return false;
    // a link to another module of this same area (its items are already here)
    if (it.screen === 'ModuleMenu' && it.params && area.modules.includes(it.params.module)) return false;
    if (PERSONAL_IDS[it.id] && canFn && (PERSONAL_IDS[it.id] === true || canFn(user, PERSONAL_IDS[it.id]))) return false;
    if (PERSONAL[it.screen] && canFn && canFn(user, PERSONAL[it.screen])) return false;
    const k = sameKey(it);
    if (seenItems.has(k)) return false;
    seenItems.add(k);
    return true;
  };
  for (const mid of area.modules) {
    const mod = getModule(mid);
    if (!mod) continue;
    // a module switched off (Settings › Modules on / off) is left out, with every link in its menu
    if (mod.switchable) { try { if (!require('../modules/admin/service.js').moduleOn(mid)) continue; } catch (e) { /* on */ } }
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    const daily = [];
    const more = [];
    for (const sec of secs) {
      for (const it of sec.items) {
        const item = { ...it, module: mid, testID: areaItemTestId(area, mid, it.id) };
        if ((sec.section === 'Daily tasks' || sec.section === 'Records' || sec.section === 'Checks') && !keep(item)) continue;
        if (sec.section === 'Daily tasks') daily.push(item);
        else if (sec.section === 'Records' || sec.section === 'Checks') more.push(item);
        else if (sec.section === 'Reports') { if (it.screen !== 'ReportsHub') reportScreens.push(item); }
        else if (sec.section === 'Settings') settings.push(item);
      }
    }
    if (daily.length || more.length) blocks.push({ module: mid, title: mod.title, icon: mod.icon, daily, more });
  }
  for (const it of area.extra || []) {
    const s = screens ? screens[it.screen] : null;
    if (screens && (!s || !s.can(user))) continue;
    const item = { ...it, testID: `mi-${it.id}` };
    if (!keep(item)) continue;
    const b = blocks[blocks.length - 1];
    if (b) (it.section === 'Daily tasks' ? b.daily : b.more).push(item);
    else blocks.push({ module: it.module, title: area.title, icon: area.icon, daily: it.section === 'Daily tasks' ? [item] : [], more: it.section === 'Daily tasks' ? [] : [item] });
  }
  return { blocks, reportScreens, settings, empty: !blocks.length };
}

// Areas this person can use (at least one item).
export function areasFor(user, screens, getModule) {
  return AREAS.filter((a) => !areaView(a, user, screens, getModule).empty);
}

// Every Settings item of every module, grouped by area (for the Settings screen). Items the Settings screen
// already shows by hand are left out by id (`skipScreens`).
export function settingsByArea(user, screens, modules, skipScreens = []) {
  const groups = {};
  for (const mod of modules) {
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    for (const sec of secs) {
      if (sec.section !== 'Settings') continue;
      for (const it of sec.items) {
        if (skipScreens.includes(it.screen) && !it.params) continue;
        const a = AREA_OF_MODULE[mod.id] || 'system';
        (groups[a] = groups[a] || []).push({ ...it, module: mod.id, moduleTitle: mod.title });
      }
    }
  }
  return groups;
}

// Report screens that are not in the shared report list (profit & loss, balance sheet, bakery dashboard…),
// from the "Reports" section of every module menu.
export function reportScreens(user, screens, modules) {
  const out = [];
  for (const mod of modules) {
    let secs = [];
    try { secs = visibleMenu(mod, user, screens); } catch (e) { secs = []; }
    for (const sec of secs) {
      if (sec.section !== 'Reports') continue;
      for (const it of sec.items) if (it.screen !== 'ReportsHub') out.push({ ...it, module: mod.id, moduleTitle: mod.title, area: AREA_OF_MODULE[mod.id] || 'system' });
    }
  }
  return out;
}

// The jobs Home already shows this person under "Daily jobs" (an area does not repeat them).
export function homeDailyScreens(user, screens) {
  const out = [];
  try {
    const A = require('./access.js');
    const on = (m) => { try { return require('../modules/admin/service.js').moduleOn(m); } catch (e) { return true; } };
    const ok = (n) => { try { return !!screens[n] && (!screens[n].can || screens[n].can(user)); } catch (e) { return false; } };
    if (A.can(user, 'verify_money')) out.push('Verify');
    if (A.can(user, 'snap_upload') || A.can(user, 'po_receive')) out.push('ReceiveGoods');
    if (A.can(user, 'snap_upload') && ok('HandCheque')) out.push('HandCheque');
    if (on('till') && ok('Handover') && ['till_count', 'till_approve', 'deposits'].some((p) => A.can(user, p))) out.push('Handover');
    if (A.can(user, 'my_hours') && on('timesheets')) out.push('MyHours');
    if (on('inventory') && ok('Fccc') && !A.can(user, 'inventory_manage')) out.push('Fccc');
    try { if (on('payroll') && require('../modules/payroll/signoff.js').canRunSignoff(user)) out.push('PaySignOff'); } catch (e) { /* payroll not here */ }
  } catch (e) { /* nothing hidden */ }
  return out;
}
