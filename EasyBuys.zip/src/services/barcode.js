// Barcodes printed on company documents (pure JavaScript, works offline).
// Code 128 (set B) of the document reference, drawn as SVG so it prints in PDFs and on 80 mm receipts.
// A QR code is also available (switched off by default in the document designer).
import { qrMatrix } from '../ui/qrMatrix.js';

// Bar / space widths of the 107 Code 128 symbols (each adds up to 11 modules; the stop symbol is 13).
export const CODE128 = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213', '221312', '231212', '112232', '122132', '122231', '113222',
  '123122', '123221', '223211', '221132', '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211', '212123', '212321',
  '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313', '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121',
  '313121', '211331', '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111', '314111', '221411', '431111', '111224',
  '111422', '121124', '121421', '141122', '141221', '112214', '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
  '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141', '214121', '412121', '111143', '111341', '131141', '114113',
  '114311', '411113', '411311', '113141', '114131', '311141', '411131', '211412', '211214', '211232', '2331112',
];
const START_B = 104;
const STOP = 106;

// Text → the symbol values (start B, data, check symbol, stop). Only printable ASCII (space to ~).
export function code128Values(text) {
  const s = String(text === null || text === undefined ? '' : text);
  if (!s.length) throw new Error('Nothing to put in the barcode.');
  const vals = [START_B];
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 32 || c > 126) throw new Error('A barcode can only hold plain letters, numbers and signs.');
    vals.push(c - 32);
  }
  let sum = START_B;
  for (let i = 1; i < vals.length; i++) sum += vals[i] * i;
  vals.push(sum % 103, STOP);
  return vals;
}
// Widths of alternating bars and spaces (first is a bar), including the quiet zones.
export function code128Modules(text, quiet = 10) {
  const widths = [];
  for (const v of code128Values(text)) for (const ch of CODE128[v]) widths.push(Number(ch));
  return { widths, quiet, total: widths.reduce((a, b) => a + b, 0) + quiet * 2 };
}
// Reads widths back to text (used by the tests to prove the barcode is right).
export function decodeCode128(widths) {
  const syms = [];
  let i = 0;
  while (i < widths.length) {
    const len = syms.length && i + 7 === widths.length ? 7 : 6;
    const pat = widths.slice(i, i + len).join('');
    const v = CODE128.indexOf(pat);
    if (v < 0) return null;
    syms.push(v);
    i += len;
  }
  if (syms[0] !== START_B || syms[syms.length - 1] !== STOP) return null;
  const data = syms.slice(1, -2);
  let sum = START_B;
  data.forEach((v, k) => { sum += v * (k + 1); });
  if (sum % 103 !== syms[syms.length - 2]) return null;
  return data.map((v) => String.fromCharCode(v + 32)).join('');
}

const esc = (v) => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// SVG of the barcode with the text printed under it. `width` in CSS units (mm by default) keeps it the same size on
// A4 and on a receipt; the bars are drawn in module units so they stay sharp.
export function code128Svg(text, { height = 14, width = null, unit = 'mm', showText = true } = {}) {
  const { widths, quiet, total } = code128Modules(text);
  let x = quiet;
  let bars = '';
  widths.forEach((w, k) => { if (k % 2 === 0) bars += `<rect x="${x}" y="0" width="${w}" height="40"/>`; x += w; });
  const w = width || Math.min(90, Math.max(40, total * 0.26));
  const textH = showText ? 9 : 0;
  return `<svg xmlns="http://www.w3.org/2000/svg" class="eb-barcode" width="${w}${unit}" height="${height}${unit}" viewBox="0 0 ${total} ${40 + textH}" preserveAspectRatio="none">`
    + `<rect x="0" y="0" width="${total}" height="${40 + textH}" fill="#fff"/><g fill="#000">${bars}</g>`
    + (showText ? `<text x="${total / 2}" y="${40 + textH - 1}" font-family="Arial, Helvetica, sans-serif" font-size="8" text-anchor="middle" fill="#000">${esc(text)}</text>` : '')
    + '</svg>';
}

// SVG QR code (off by default; the admin can switch it on per document type).
export function qrSvg(text, { size = 22, unit = 'mm' } = {}) {
  const rows = qrMatrix(String(text), 'M');
  const n = rows.length + 8;
  let d = '';
  rows.forEach((r, y) => r.forEach((on, x) => { if (on) d += `M${x + 4} ${y + 4}h1v1h-1z`; }));
  return `<svg xmlns="http://www.w3.org/2000/svg" class="eb-qr" width="${size}${unit}" height="${size}${unit}" viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
