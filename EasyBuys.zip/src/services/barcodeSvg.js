// 1.0.0 Barcodes drawn as SVG (for price tickets and labels printed from the app): EAN-13 (and 12-digit UPC-A, as
// EAN-13 with a leading 0) when the number is one, otherwise Code 128 (set B). Pure functions, no library.
const L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

export function eanCheck(d12) {
  const s = String(d12).split('').reduce((t, c, i) => t + Number(c) * (i % 2 ? 3 : 1), 0);
  return (10 - (s % 10)) % 10;
}
export function isEan13(code) {
  const c = String(code || '');
  return /^\d{13}$/.test(c) && eanCheck(c.slice(0, 12)) === Number(c[12]);
}
// EAN-13 → the bars as a string of 1 (black) and 0 (white) modules (95 modules).
export function ean13Bits(code) {
  const c = String(code);
  const par = PARITY[Number(c[0])];
  let bits = '101';
  for (let i = 1; i <= 6; i += 1) bits += (par[i - 1] === 'L' ? L : G)[Number(c[i])];
  bits += '01010';
  for (let i = 7; i <= 12; i += 1) bits += R[Number(c[i])];
  return `${bits}101`;
}

// Code 128: the 107 bar patterns (widths of bar/space/bar/space/bar/space; stop has 7).
const C128 = ['212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213', '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132', '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211', '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313', '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331', '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111', '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214', '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111', '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141', '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141', '114131', '311141', '411131', '211412', '211214', '211232', '2331112'];
export function code128Bits(text) {
  const s = String(text || '').replace(/[^\x20-\x7e]/g, '');
  const vals = [104].concat(s.split('').map((ch) => ch.charCodeAt(0) - 32)); // start B
  const check = vals.reduce((t, v, i) => t + v * (i === 0 ? 1 : i), 0) % 103;
  let bits = '';
  for (const v of vals.concat([check, 106])) {
    const w = C128[v];
    for (let i = 0; i < w.length; i += 1) bits += (i % 2 ? '0' : '1').repeat(Number(w[i]));
  }
  return bits;
}
const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// An SVG of the barcode with its number under it. width / height in mm (it scales to the space it is given).
export function barcodeSvg(code, { width = 38, height = 12, text = true } = {}) {
  let c = String(code || '').trim();
  if (/^\d{12}$/.test(c) && eanCheck(`0${c}`.slice(0, 12)) === Number(c[11])) c = `0${c}`; // UPC-A
  if (!c) return '';
  const ean = isEan13(c);
  const bits = ean ? ean13Bits(c) : code128Bits(c);
  const quiet = ean ? 9 : 10;
  const total = bits.length + quiet * 2;
  const barH = text ? 70 : 100;
  let rects = '';
  let x = 0;
  while (x < bits.length) {
    if (bits[x] === '1') { let w = 1; while (bits[x + w] === '1') w += 1; rects += `<rect x="${x + quiet}" y="0" width="${w}" height="${barH}"/>`; x += w; } else x += 1;
  }
  const label = text ? `<text x="${total / 2}" y="97" font-size="22" text-anchor="middle" font-family="Arial, sans-serif">${esc(c)}</text>` : '';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} 100" width="${width}mm" height="${height}mm" preserveAspectRatio="none" shape-rendering="crispEdges"><g fill="#000">${rects}</g>${label}</svg>`;
}
