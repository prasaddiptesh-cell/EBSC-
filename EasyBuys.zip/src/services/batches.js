// Production batches: flour-based ingredient calculation, timed steps with
// confirm/snooze, cut count, finishing and yield checks.
import { db } from '../db/connection.js';
import {
  AppError, stamp, r3, r1, requireNonNegative, nextBatchCode, addMinutes, parseStamp, clock, minutesBetween, pctDiff, hhmm,
} from './core.js';
import { getProduct, getRecipe, getProductRoute, getMaterial, flagPctFor, getProductDecksSet } from './catalog.js';
import { writeTxn, changeStock, raiseAlert, addPhotos, checkReorder } from './stock.js';
import { getOpenShift, isOnShift } from './shifts.js';
import { proofFor, applyProof, yeastMaterial } from './proofing.js';

// ---------------- planning ----------------
// Returns everything the baker needs before mixing: calculated ingredients, limits and route.
export function planBatch(productId, flourKg) {
  const product = getProduct(productId);
  if (!product) throw new AppError('Please choose a product.');
  if (!product.flour_material_id) throw new AppError(`${product.name} has no flour set. Ask the Admin to complete the recipe.`);
  const flour = getMaterial(product.flour_material_id);
  const f = Number(flourKg) || 0;
  const recipe = getRecipe(productId);
  const lines = [{
    material_id: flour.id, name: flour.name, unit: flour.unit, kg_per_unit: flour.kg_per_unit || 1, track_stock: flour.track_stock,
    pct: 100, is_flour: true, flag_pct: flagPctFor(product, null), expected: r3(flour.unit === 'g' ? f * 1000 : f),
  }];
  for (const r of recipe) {
    const kgPerUnit = r.kg_per_unit || 0;
    const kgNeeded = (f * r.pct) / 100; // weight of this ingredient in kg
    const qty = kgPerUnit > 0 ? kgNeeded / kgPerUnit : kgNeeded;
    lines.push({
      material_id: r.material_id, name: r.name, unit: r.unit, kg_per_unit: kgPerUnit, track_stock: r.track_stock,
      pct: r.pct, is_flour: false, flag_pct: flagPctFor(product, r), expected: r3(qty),
    });
  }
  return { product, flourKg: r3(f), maxFlourKg: product.max_flour_kg, lines, route: getProductRoute(productId, f) };
}

export function doughKg(lines, actuals) {
  let kg = 0;
  for (const l of lines) {
    const a = actuals && actuals[l.material_id] !== undefined && actuals[l.material_id] !== null ? Number(actuals[l.material_id]) : l.expected;
    kg += (Number(a) || 0) * (l.kg_per_unit || 0);
  }
  return r3(kg);
}
export function expectedPieces(dough, cutWeightG) {
  if (!cutWeightG) return 0;
  return Math.floor((dough * 1000) / cutWeightG);
}
export function ingredientFlag(line, actual) {
  if (actual === null || actual === undefined || actual === '') return { diff: null, pct: null, flagged: false };
  const diff = r3(Number(actual) - line.expected);
  const pct = pctDiff(Number(actual), line.expected);
  return { diff, pct, flagged: Math.abs(pct) > line.flag_pct + 1e-9 };
}

function requireBaker(userId) {
  const s = getOpenShift();
  if (!s) throw new AppError('There is no open shift. Start a shift first.');
  if (!isOnShift(s.id, userId)) throw new AppError('Please sign on to the shift first.');
  return s;
}

// ---------------- start (mixing) ----------------
// actuals: { [materialId]: quantity actually used }
// climate: 'hot' | 'normal' | 'cool' (or roomTemp in °C) – adjusts the proofing time (v3.5 B7).
export function startBatch(userId, productId, flourKg, actuals, { waterTemp = null, climate = null, roomTemp = null } = {}) {
  const s = requireBaker(userId);
  const f = Number(flourKg);
  if (!Number.isFinite(f) || f <= 0) throw new AppError('Enter the amount of flour (kg).');
  const plan = planBatch(productId, f);
  const p = plan.product;
  if (f > p.max_flour_kg + 1e-9) throw new AppError(`Too much flour. The maximum for one batch of ${p.name} is ${p.max_flour_kg} kg (machine capacity).`);
  const used = {};
  for (const l of plan.lines) {
    const v = actuals && actuals[l.material_id] !== undefined ? actuals[l.material_id] : l.expected;
    used[l.material_id] = requireNonNegative(v, `Amount of ${l.name}`);
  }
  // Flour used must also respect the machine maximum.
  const flourLine = plan.lines[0];
  const flourUsedKg = used[flourLine.material_id] * (flourLine.kg_per_unit || 1);
  if (flourUsedKg > p.max_flour_kg + 1e-9) throw new AppError(`Too much flour. The maximum for one batch of ${p.name} is ${p.max_flour_kg} kg.`);
  const dough = doughKg(plan.lines, used);
  const pieces = expectedPieces(dough, p.cut_weight_g);
  const now = stamp();
  // Proofing minutes from the product's proofing table (yeast actually used) and Hot / Normal / Cool.
  const ym = yeastMaterial();
  const proof = proofFor(p.id, { flourKg: flourUsedKg, yeastQty: ym ? used[ym.id] : null, climate, roomTemp });
  const route0 = applyProof(plan.route, proof);

  return db().transaction(() => {
    const code = nextBatchCode();
    const txn = writeTxn({ type: 'PRODUCTION', shiftId: s.id, userId, productId: p.id, qty: 0, expectedQty: pieces, note: `Batch ${code} started: ${f} kg flour` });
    const batchId = db().run(
      `INSERT INTO batches (code, txn_id, location, shift_id, user_id, product_id, status, flour_kg, dough_kg, cut_weight_g, expected_pieces, water_temp,
         current_step, started_at, created_at) VALUES (?, ?, (SELECT location FROM shifts WHERE id = ?), ?, ?, ?, 'active', ?, ?, ?, ?, ?, 0, ?, ?)`,
      [code, txn, s.id, s.id, userId, p.id, r3(flourUsedKg), dough, p.cut_weight_g, pieces, waterTemp === null || waterTemp === '' ? null : Number(waterTemp), now, now]
    ).lastInsertRowId;
    db().run('UPDATE transactions SET batch_id = ? WHERE txn_id = ?', [batchId, txn]);

    const flagged = [];
    for (const l of plan.lines) {
      const a = used[l.material_id];
      const fl = ingredientFlag(l, a);
      const cost = db().get('SELECT cost_per_unit FROM materials WHERE id = ?', [l.material_id]).cost_per_unit;
      db().run('INSERT INTO batch_ingredients (batch_id, material_id, pct, expected, actual, diff_pct, flagged, unit_cost) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [batchId, l.material_id, l.pct, l.expected, a, fl.pct, fl.flagged ? 1 : 0, cost]);
      if (l.track_stock) {
        const utx = writeTxn({ type: 'USAGE', shiftId: s.id, userId, materialId: l.material_id, batchId, qty: a, expectedQty: l.expected, variance: fl.diff, ref: code, note: `Batch ${code} (${p.name})` });
        changeStock(l.material_id, -a, { batchId, txnId: utx });
      }
      if (fl.flagged) flagged.push(`${l.name} ${a} ${l.unit} instead of ${l.expected} (${fl.pct > 0 ? '+' : ''}${fl.pct}%)`);
    }
    if (flagged.length) {
      raiseAlert({ type: 'INGREDIENT', shiftId: s.id, batchId, userId, message: `${p.name} ${code}: ${flagged.join('; ')}` });
    }

    // Steps: mixing (started now), the product's steps, then "Finished".
    if (proof) db().run('UPDATE batches SET proof_yeast = ?, proof_climate = ?, proof_minutes = ? WHERE id = ?', [proof.yeast, proof.climate, proof.minutes, batchId]);
    const route = route0.concat([{ id: -1, name: 'Finished', kind: 'finish', minutes: null }]);
    let planned = now;
    route.forEach((st, idx) => {
      if (idx > 0) planned = addMinutes(planned, Number(route[idx - 1].minutes) || 0);
      const due = idx === 1 ? planned : null;
      db().run(
        'INSERT INTO batch_steps (batch_id, idx, name, kind, minutes, planned_at, due_at, started_at, started_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [batchId, idx, st.name, st.kind, st.minutes, planned, idx === 0 ? now : due, idx === 0 ? now : null, idx === 0 ? userId : null]
      );
    });
    checkReorder(userId);
    return getBatch(batchId);
  });
}

// ---------------- lookups ----------------
export function getBatchSteps(batchId) {
  return db().all('SELECT bs.*, u.name AS started_by_name FROM batch_steps bs LEFT JOIN users u ON u.id = bs.started_by WHERE batch_id = ? ORDER BY idx', [batchId]);
}
export function getBatch(id) {
  const b = db().get(
    `SELECT b.*, p.name AS product_name, p.unit AS product_unit, p.cut_tolerance_g, p.flag_pct AS product_flag, u.name AS user_name, s.code AS shift_code
     FROM batches b JOIN products p ON p.id = b.product_id JOIN users u ON u.id = b.user_id JOIN shifts s ON s.id = b.shift_id WHERE b.id = ?`,
    [id]
  );
  if (!b) return null;
  b.decks = getProductDecksSet(b.product_id);
  b.prep_note = db().get('SELECT prep_note FROM products WHERE id = ?', [b.product_id]).prep_note;
  const steps = getBatchSteps(id);
  const ingredients = db().all(
    `SELECT bi.*, m.name, m.unit FROM batch_ingredients bi JOIN materials m ON m.id = bi.material_id WHERE bi.batch_id = ? ORDER BY bi.pct DESC`, [id]
  );
  return { ...b, steps, ingredients, ...stepState(b, steps) };
}

// Works out the current step, the next step and when it is due.
export function stepState(batch, steps) {
  const cur = steps[batch.current_step];
  const next = steps[batch.current_step + 1] || null;
  const now = clock.now();
  const dueAt = next ? next.due_at : null;
  const dueMs = dueAt ? parseStamp(dueAt).getTime() - now.getTime() : null;
  return {
    currentStep: cur,
    nextStep: next,
    dueAt,
    secondsToDue: dueMs === null ? null : Math.round(dueMs / 1000),
    isDue: batch.status === 'active' && dueMs !== null && dueMs <= 0,
    inStepMinutes: cur && cur.started_at ? minutesBetween(cur.started_at, stamp(now)) : null,
  };
}

export function listBatches({ shiftId, status, from, to, limit = 300 } = {}) {
  const where = [];
  const params = [];
  if (shiftId) { where.push('b.shift_id = ?'); params.push(shiftId); }
  if (status) { where.push('b.status = ?'); params.push(status); }
  if (from) { where.push("substr(b.started_at,1,10) >= ?"); params.push(from); }
  if (to) { where.push("substr(b.started_at,1,10) <= ?"); params.push(to); }
  params.push(limit);
  const rows = db().all(
    `SELECT b.*, p.name AS product_name, p.unit AS product_unit, p.prep_note, u.name AS user_name, s.code AS shift_code, s.shift_name
     FROM batches b JOIN products p ON p.id = b.product_id JOIN users u ON u.id = b.user_id JOIN shifts s ON s.id = b.shift_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY b.id DESC LIMIT ?`,
    params
  );
  return rows.map((b) => {
    const steps = getBatchSteps(b.id);
    return { ...b, steps, decks: getProductDecksSet(b.product_id), ...stepState(b, steps) };
  });
}

export function listActiveBatches() {
  const s = getOpenShift();
  if (!s) return [];
  return listBatches({ shiftId: s.id, status: 'active' }).reverse();
}

export function dueBatches() {
  return listActiveBatches().filter((b) => b.isDue);
}

// ---------------- step actions ----------------
function loadActive(batchId) {
  const b = getBatch(batchId);
  if (!b) throw new AppError('Batch not found.');
  if (b.status !== 'active') throw new AppError('This batch is already finished.');
  return b;
}

// True when the batch is in (or past) its cutting step but the piece count has not been entered yet.
export function needsCutCount(b) {
  if (b.cut_pieces !== null && b.cut_pieces !== undefined) return false;
  const cut = (b.steps || []).find((s) => s.kind === 'cut');
  return !!cut && !!cut.started_at;
}

function saveCutCount(userId, b, cutPieces) {
  let pieces = Number(cutPieces);
  if (cutPieces === null || cutPieces === undefined || cutPieces === '' || !Number.isFinite(pieces) || pieces < 0) {
    throw new AppError('Enter how many pieces were cut.');
  }
  pieces = Math.round(pieces);
  db().run('UPDATE batches SET cut_pieces = ?, cut_counted_at = ?, cut_counted_by = ? WHERE id = ?', [pieces, stamp(), userId, b.id]);
  const flag = b.product_flag !== null && b.product_flag !== undefined ? b.product_flag : Number(db().get("SELECT value FROM settings WHERE key = 'default_flag_pct'")?.value || 2);
  const shortPct = b.expected_pieces ? ((b.expected_pieces - pieces) / b.expected_pieces) * 100 : 0;
  if (pieces < b.expected_pieces && shortPct > flag) {
    raiseAlert({ type: 'CUT_SHORT', shiftId: b.shift_id, batchId: b.id, userId,
      message: `${b.product_name} ${b.code}: cut ${pieces} pieces, expected about ${b.expected_pieces} at ${b.cut_weight_g} g (${r1(shortPct)}% short).` });
  }
  return pieces;
}

// Cutting finished: record how many pieces were cut (can be done any time after cutting started).
export function recordCutCount(userId, batchId, cutPieces) {
  const b = loadActive(batchId);
  const cut = b.steps.find((s) => s.kind === 'cut');
  if (!cut) throw new AppError('This product has no cutting step.');
  if (!cut.started_at) throw new AppError('Cutting has not started yet.');
  return db().transaction(() => {
    saveCutCount(userId, b, cutPieces);
    return getBatch(batchId);
  });
}

// Confirm that the next step has started now. If cutting has just finished and the
// piece count is still missing, it must be given here.
export function confirmNextStep(userId, batchId, { cutPieces, deck } = {}) {
  const b = loadActive(batchId);
  const next = b.nextStep;
  if (!next) throw new AppError('No more steps.');
  if (next.kind === 'finish') throw new AppError('Use "Finish batch" to enter how many were produced.');
  const mustCount = needsCutCount(b);
  if (mustCount && (cutPieces === null || cutPieces === undefined || cutPieces === '')) throw new AppError('Cutting is finished – enter how many pieces were cut first.');
  const now = stamp();
  return db().transaction(() => {
    if (mustCount) saveCutCount(userId, b, cutPieces);
    // One mix can go into several decks: stored as "Deck 1, Deck 3".
    const decks = (Array.isArray(deck) ? deck : deck ? [deck] : []).map((d) => String(d).trim()).filter(Boolean);
    if (next.kind === 'bake' && decks.length) db().run('UPDATE batches SET deck = ? WHERE id = ?', [Array.from(new Set(decks)).join(', '), batchId]);
    db().run('UPDATE batch_steps SET started_at = ?, started_by = ? WHERE batch_id = ? AND idx = ?', [now, userId, batchId, next.idx]);
    db().run("UPDATE batches SET current_step = ?, sync_status = 'pending' WHERE id = ?", [next.idx, batchId]);
    const after = b.steps[next.idx + 1];
    if (after) db().run('UPDATE batch_steps SET due_at = ? WHERE batch_id = ? AND idx = ?', [addMinutes(now, Number(next.minutes) || 0), batchId, after.idx]);
    const late = next.due_at ? minutesBetween(next.due_at, now) : 0;
    if (late > 10) {
      raiseAlert({ type: 'LATE', severity: 'info', shiftId: b.shift_id, batchId, userId, message: `${b.product_name} ${b.code}: ${next.name} started ${late} min after it was due.` });
    }
    return getBatch(batchId);
  });
}

// Snooze the next step by X minutes. Later steps move back automatically because
// each step's due time is calculated from when the previous step actually started.
export function snoozeNextStep(userId, batchId, minutes) {
  const b = loadActive(batchId);
  const m = Number(minutes);
  if (!Number.isFinite(m) || m <= 0 || m > 240) throw new AppError('Snooze must be between 1 and 240 minutes.');
  const next = b.nextStep;
  if (!next || !next.due_at) throw new AppError('Nothing to snooze.');
  const base = parseStamp(next.due_at) < clock.now() ? stamp() : next.due_at;
  db().run('UPDATE batch_steps SET due_at = ?, snooze_min = snooze_min + ?, snooze_count = snooze_count + 1 WHERE batch_id = ? AND idx = ?',
    [addMinutes(base, m), m, batchId, next.idx]);
  raiseAlert({ type: 'SNOOZE', severity: 'info', shiftId: b.shift_id, batchId, userId, message: `${b.product_name} ${b.code}: ${next.name} snoozed ${m} min.` });
  return getBatch(batchId);
}

export function finishBatch(userId, batchId, { good, damaged, rejected, otherWaste, comments, photos, cutPieces }) {
  const b = loadActive(batchId);
  if (!b.nextStep || b.nextStep.kind !== 'finish') {
    throw new AppError(`Confirm "${b.nextStep ? b.nextStep.name : 'all steps'}" first.`);
  }
  if (needsCutCount(b)) {
    if (cutPieces === null || cutPieces === undefined || cutPieces === '') throw new AppError('Enter how many pieces were cut first.');
    saveCutCount(userId, b, cutPieces);
    b.cut_pieces = Math.round(Number(cutPieces));
  }
  const v = {
    good: requireNonNegative(good, 'Good quantity'),
    damaged: requireNonNegative(damaged || 0, 'Damaged quantity'),
    rejected: requireNonNegative(rejected || 0, 'Rejected quantity'),
    other: requireNonNegative(otherWaste || 0, 'Other wastage'),
  };
  const total = r3(v.good + v.damaged + v.rejected + v.other);
  if (total <= 0) throw new AppError('Enter how many were produced.');
  const now = stamp();
  return db().transaction(() => {
    db().run('UPDATE batch_steps SET started_at = ?, started_by = ? WHERE batch_id = ? AND idx = ?', [now, userId, batchId, b.nextStep.idx]);
    db().run(
      `UPDATE batches SET status = 'finished', current_step = ?, finished_at = ?, finished_by = ?, good = ?, damaged = ?, rejected = ?, other_waste = ?, comments = ?,
       sync_status = 'pending' WHERE id = ?`,
      [b.nextStep.idx, now, userId, v.good, v.damaged, v.rejected, v.other, String(comments || '').trim() || null, batchId]
    );
    db().run("UPDATE transactions SET qty = ?, note = ? WHERE txn_id = ?",
      [v.good, `Batch ${b.code}: good ${v.good}, damaged ${v.damaged}, rejected ${v.rejected}, other ${v.other} (expected ${b.expected_pieces})`, b.txn_id]);
    addPhotos('batch', b.code, photos);
    const flag = b.product_flag !== null && b.product_flag !== undefined ? b.product_flag : Number(db().get("SELECT value FROM settings WHERE key = 'default_flag_pct'")?.value || 2);
    const base = b.cut_pieces || b.expected_pieces;
    if (base && total < base && ((base - total) / base) * 100 > flag) {
      raiseAlert({ type: 'YIELD_SHORT', shiftId: b.shift_id, batchId, userId,
        message: `${b.product_name} ${b.code}: ${total} produced, but ${b.cut_pieces ? `${b.cut_pieces} were cut` : `about ${b.expected_pieces} expected`}.` });
    }
    if (b.expected_pieces && v.good < b.expected_pieces && ((b.expected_pieces - v.good) / b.expected_pieces) * 100 > flag && !(base && total < base)) {
      raiseAlert({ type: 'YIELD_SHORT', shiftId: b.shift_id, batchId, userId,
        message: `${b.product_name} ${b.code}: ${v.good} good of about ${b.expected_pieces} expected (${v.damaged + v.rejected + v.other} lost).` });
    }
    return getBatch(batchId);
  });
}

// Ingredient cost of a batch (latest purchase prices at the time of mixing).
export function batchCost(batchId) {
  const rows = db().all('SELECT actual, unit_cost FROM batch_ingredients WHERE batch_id = ?', [batchId]);
  const priced = rows.filter((r) => r.unit_cost !== null && r.unit_cost !== undefined);
  return { cost: r3(priced.reduce((a, r) => a + r.actual * r.unit_cost, 0)), complete: priced.length === rows.length, priced: priced.length, total: rows.length };
}

// Summary numbers for a batch (used by reports and the dashboard).
export function batchStats(b) {
  const steps = b.steps || getBatchSteps(b.id);
  const delays = steps.filter((s) => s.idx > 0 && s.started_at && s.planned_at).map((s) => ({ name: s.name, late: minutesBetween(s.planned_at, s.started_at) }));
  const total = (b.good || 0) + (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0);
  const c = batchCost(b.id);
  return {
    cost: c.cost,
    costComplete: c.complete,
    costPerGood: b.good ? r3(c.cost / b.good) : null,
    lossValue: total ? r3((c.cost / total) * ((b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0))) : 0,
    totalMinutes: b.finished_at ? minutesBetween(b.started_at, b.finished_at) : minutesBetween(b.started_at, stamp()),
    snoozes: steps.reduce((a, s) => a + (s.snooze_count || 0), 0),
    snoozeMinutes: steps.reduce((a, s) => a + (s.snooze_min || 0), 0),
    delayMinutes: delays.length ? Math.max(0, delays[delays.length - 1].late) : 0,
    yieldPct: b.expected_pieces ? r1(((b.good || 0) / b.expected_pieces) * 100) : null,
    totalProduced: total,
    timeline: steps.map((s) => `${s.name}${s.kind === 'bake' && b.deck ? ` (${b.deck})` : ''} ${s.started_at ? hhmm(s.started_at) : '—'}`).join(' → '),
  };
}
