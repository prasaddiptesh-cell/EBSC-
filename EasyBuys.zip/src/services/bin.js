// v3.9.6 Delete with a 90-day Deleted bin (owner and admin only).
//
// Deleting a record takes it out of the app on every device. Before it goes, the app works out what the record
// did and what uses it:
//   • its own parts and effects go with it into the bin (the lines of an order, the stock it moved, the payment's
//     allocations and cheque, its documents and checks…) – so deleting it also undoes what it did;
//   • loose links from other records are cleared (a delivery that pointed at the invoice keeps the delivery);
//   • anything that still depends on it (a payment on the invoice, a delivery against the order, a pay run that
//     took the charge…) stops the delete, with what to delete first – nothing is left half-done.
// The deleted records wait in the bin for 90 days and can be put back exactly as they were. After 90 days they
// are gone for good, also from the cloud copy. Every delete and restore is kept in the change history. A record in
// a month whose VAT return is filed (or whose books are closed) needs a second "yes".
//
// Sync: the bin entry itself syncs; each device removes the records when it arrives, and a record in the bin is
// never brought back by an older copy from the cloud or another device.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays } from './core.js';
import { actsAsOwner } from './access.js';
// records.js is loaded when needed (it loads the table list, which includes the bin's own tables).
const ST = () => require('./records.js').SYNC_TABLES;

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const colsOf = (t) => { try { return db().all(`PRAGMA table_info(${t})`).map((c) => c.name); } catch (e) { return []; } };

export const KEEP_DAYS = 90;
export const MAX_ROWS = 500;          // one delete takes at most this many records with it
const PART_CHARS = 30000;             // one cloud cell holds 50 000 characters: the copy is kept in parts

export const BIN_SQL = `
CREATE TABLE IF NOT EXISTS bin_records (
  uid TEXT PRIMARY KEY,
  tbl TEXT NOT NULL,
  rkey TEXT NOT NULL,
  title TEXT,
  kind TEXT,
  shop_code TEXT,
  rec_date TEXT,
  keys TEXT,
  parts INTEGER NOT NULL DEFAULT 0,
  unlinked TEXT,
  summary TEXT,
  reason TEXT,
  closed_period INTEGER NOT NULL DEFAULT 0,
  deleted_by_uid TEXT, deleted_by_name TEXT,
  deleted_at TEXT NOT NULL,
  purge_after TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'binned',
  restored_by_name TEXT, restored_at TEXT, gone_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_bin_status ON bin_records(status, purge_after);
CREATE TABLE IF NOT EXISTS bin_parts (
  uid TEXT PRIMARY KEY,
  bin_uid TEXT NOT NULL,
  n INTEGER NOT NULL,
  data TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_bin_parts ON bin_parts(bin_uid, n);
CREATE TABLE IF NOT EXISTS bin_index (
  t TEXT NOT NULL,
  k TEXT NOT NULL,
  bin_uid TEXT NOT NULL,
  PRIMARY KEY (t, k)
);
CREATE TABLE IF NOT EXISTS bin_scrub (
  t TEXT NOT NULL,
  k TEXT NOT NULL,
  at TEXT NOT NULL,
  PRIMARY KEY (t, k)
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const BIN_SYNC = {
  bin_records: SYNC('uid', 'Deleted bin', ['uid', 'tbl', 'rkey', 'title', 'kind', 'shop_code', 'rec_date', 'keys', 'parts', 'unlinked', 'summary', 'reason', 'closed_period', 'deleted_by_uid', 'deleted_by_name', 'deleted_at', 'purge_after', 'status', 'restored_by_name', 'restored_at', 'gone_at']),
  bin_parts: SYNC('uid', 'Deleted bin', ['uid', 'bin_uid', 'n', 'data']),
};

// Only the owner and the admin delete.
export function canDelete(user) {
  return !!user && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
}

// ---------------------------------------------------------------- plain names
export const LABELS = {
  ap_invoices: 'supplier invoice', ap_payments: 'payment to a supplier', ap_allocations: 'payment allocation', ap_suppliers: 'supplier', ap_recurring: 'regular bill / loan',
  cheques: 'cheque', cheque_books: 'cheque book', bank_entries: 'bank line', bank_accounts: 'bank account', bank_lines: 'bank statement line', bank_statements: 'bank statement',
  deposits: 'bank deposit', cash_moves: 'cash movement', money_snaps: 'photo record (invoice / cheque)', till_counts: 'till count', till_shifts: 'till shift', till_shortages: 'till shortage', till_surplus: 'till surplus',
  po_orders: 'purchase order', po_lines: 'order line', po_versions: 'order version', inv_receipts: 'delivery', inv_moves: 'stock movement', inv_items: 'product', inv_item_shops: 'product shop setting',
  inv_item_suppliers: 'product supplier', inv_counts: 'stock take', inv_count_lines: 'stock take line', inv_count_entries: 'stock take count', inv_count_areas: 'stock take area', inv_transfers: 'shop-to-shop transfer', inv_cost_changes: 'cost change',
  licences: 'licence / permit', licence_events: 'licence history entry', documents: 'document', verifications: 'check (To verify)', verify_queries: 'question (To verify)', invoice_reads: 'invoice reading',
  users: 'staff member', punches: 'clock in / out', leave_requests: 'leave', roster_marks: 'day mark (off / leave / sick / absent)', roster_shifts: 'roster shift', staff_charges: 'staff charge', staff_debts: 'staff advance / loan',
  credit_settlements: 'credit settlement', pay_runs: 'pay run', pay_lines: 'pay line', pay_signoffs: 'payslip sign-off', pay_slip_status: 'payslip', pay_profiles: 'pay details', staff_details: 'staff details',
  gl_journals: 'journal', gl_recurring: 'regular journal', fixed_assets: 'fixed asset', loan_entries: 'loan entry', regular_receipts: 'regular payment receipt', regular_terms: 'loan / rent terms', loan_recons: 'loan check',
  shops: 'shop', shop_accounts: 'bill account', tills: 'till', wallets: 'M-PAiSA wallet', wallet_moves: 'wallet movement', wallet_lines: 'wallet statement line', wallet_imports: 'wallet statement',
  ve_items: 'vehicle / equipment', ve_fuel: 'fuel fill', ve_work: 'service / repair', ve_faults: 'fault', ve_checks: 'daily check', ve_due: 'service due',
  duty_lists: 'checklist', duty_runs: "day's checklist", handovers: 'handover', owner_moves: "owner's money entry", stat_payments: 'FNPF / PAYE payment', tax_proofs: 'tax proof',
  contracts: 'contract', onboarding: 'onboarding', applicants: 'applicant', job_openings: 'vacancy', safe_counts: 'safe count', aronium_eods: 'End of day', aronium_batches: 'Aronium import',
  supplier_statements: 'supplier statement', supplier_schedules: 'supplier order days', supplier_layouts: 'invoice layout', staff_credit_imports: 'staff credit import', staff_credit_balances: 'staff credit balance',
  bank_closings: 'month closing', bank_checks: 'balance check', cheque_cover: 'cheque cover', myday_items: 'My day item', myday_marks: 'My day mark', accountant_queries: 'accountant question', leave_entitlements: 'leave entitlement',
};
export const labelOf = (t) => LABELS[t] || String(t).replace(/_/g, ' ');

// ---------------------------------------------------------------- how records hang together
// Tables never searched or deleted through the bin (logs, local working tables, the bin itself).
const SKIP = new Set(['audit_log', 'outbox', 'alert_log', 'aronium_feed', 'aronium_link_done', 'health_checks', 'bin_records', 'bin_parts', 'bin_index', 'bin_scrub',
  'doc_local', 'photos', 'sqlite_sequence', 'settings', 'shared_settings', 'issued_docs', 'roster_changes', 'paper_reads']);
// Columns that only say who did something (a name is kept beside them): never a reason to stop a delete.
const WHO = /(^|_)(by|from|to|cashier|counted_by|opened_by|deposited_by|asked_by|reported_by|requested_by|decided_by|voided_by|entered_by|checked_by|paid_by|signed_by|created_by|responsible|backup|hired_user|manager|employee_sig|employer_sig|sig)_uid$|^(by_uid|from_uid|to_uid)$/;
// Columns that hold a list (JSON) where a key may appear.
const LISTY = /(_uids|^lines$|^items$|^cheques$|^count_uids$|^item_key$|^deductions$|^adjustments$|^ticks$|^split$|^fixes$|^parts$|^meta$)/;

// What happens to a record that points at the one being deleted: 'take' (it is part of it / its effect: goes into
// the bin with it), 'unlink' (the link is cleared, the record stays), 'ignore' (only a mention). Anything not
// listed stops the delete.
const POLICY = {
  'documents.ref_uid': 'take', 'invoice_reads.invoice_uid': 'take', 'invoice_reads.receipt_uid': 'unlink', 'invoice_reads.po_uid': 'unlink', 'invoice_reads.supplier_uid': 'ignore',
  'verifications.record_uid': 'take', 'verify_queries.record_uid': 'take', 'verify_queries.item_key': 'take', 'accountant_queries.ref': 'ignore',
  'po_lines.po_uid': 'take', 'po_versions.po_uid': 'take', 'licence_events.licence_uid': 'take', 'inv_moves.ref_uid': 'take', 'inv_cost_changes.ref_uid': 'take',
  'inv_count_areas.count_uid': 'take', 'inv_count_entries.count_uid': 'take', 'inv_count_lines.count_uid': 'take',
  'pay_lines.run_uid': 'take', 'pay_signoffs.run_uid': 'take', 'pay_slip_status.run_uid': 'take',
  'ap_allocations.payment_uid': 'take', 'cheques.payment_uid': 'take', 'bank_entries.payment_uid': 'take',
  'loan_entries.recurring_uid': 'take', 'regular_receipts.recurring_uid': 'take', 'loan_recons.recurring_uid': 'take',
  've_checks.item_uid': 'take', 've_due.item_uid': 'take', 've_faults.item_uid': 'take', 've_fuel.item_uid': 'take', 've_work.item_uid': 'take',
  've_work.invoice_uid': 'unlink', 've_work.due_uid': 'unlink', 've_work.fault_uid': 'unlink', 've_faults.work_uid': 'unlink', 've_items.loan_uid': 'unlink', 've_items.asset_uid': 'unlink', 've_items.insurance_uid': 'unlink',
  'inv_item_shops.item_uid': 'take', 'inv_item_suppliers.item_uid': 'take', 'inv_cost_changes.item_uid': 'take', 'inv_item_suppliers.supplier_uid': 'take',
  'supplier_layouts.supplier_uid': 'take', 'supplier_schedules.supplier_uid': 'take', 'supplier_statements.supplier_uid': 'take', 'aronium_suppliers.supplier_uid': 'unlink', 'inv_items.supplier_uid': 'unlink',
  'staff_credit_balances.import_uid': 'take', 'wallet_lines.import_uid': 'take', 'bank_lines.statement_uid': 'take', 'bank_closings.statement_uid': 'take',
  'bank_lines.match_uid': 'unlink', 'wallet_lines.match_uid': 'unlink', 'inv_receipts.invoice_uid': 'unlink', 'ap_invoices.po_uid': 'unlink', 'money_snaps.link_uid': 'unlink', 'money_snaps.po_uid': 'unlink',
  'money_snaps.invoice_uids': 'ignore', 'money_snaps.supplier_uid': 'ignore', 'money_snaps.account_uid': 'ignore', 'shop_accounts.recurring_uid': 'unlink', 'shop_accounts.supplier_uid': 'unlink',
  'till_shifts.count_uid': 'unlink', 'aronium_eods.count_uids': 'ignore', 'aronium_eods.batch_uid': 'unlink', 'regular_receipts.invoice_uid': 'unlink', 'regular_receipts.payment_uid': 'unlink',
  'duty_runs.list_uid': 'ignore', 'myday_items.owner_uid': 'take', 'myday_marks.owner_uid': 'take', 'roster_marks.leave_uid': 'unlink', 'contracts.template_doc_uid': 'ignore', 'contracts.doc_uid': 'unlink',
  'bank_statements.doc_uid': 'unlink', 'bank_closings.doc_uid': 'unlink', 'wallet_imports.doc_uid': 'unlink', 'safe_counts.adjust_uid': 'unlink', 'owner_moves.reminder_uid': 'unlink',
  'till_surplus.set_off_uid': 'unlink', 'till_shortages.set_off_from': 'unlink', 'cash_moves.ref_uid': 'unlink', 'staff_charges.ref_uid': 'unlink', 'gl_journals.ref_uid': 'unlink', 'inv_moves.item_uid': 'block',
  'ap_payments.credit_uid': 'unlink', 'deposits.bank_entry_uid': 'block', 'wallet_moves.bank_entry_uid': 'block', 'shops.manager_uid': 'unlink',
  'shop_accounts.shop_code': 'take', 'tills.shop_code': 'take', 'inv_item_shops.shop_code': 'take', 'supplier_schedules.shop_code': 'take',
  'roster_shifts.user_uid': 'take', 'rosters.user_uid': 'take', 'staff_details.user_uid': 'take', 'leave_entitlements.user_uid': 'take', 'timesheet_checks.user_uid': 'take',
};
// Records a record owns that it points at itself (deleting a deposit also deletes the bank line it made).
const OWNS = {
  deposits: ['bank_entry_uid'], wallet_moves: ['bank_entry_uid'], ap_payments: ['cheque_uid'], owner_moves: ['journal_uid', 'cash_uid'], ve_fuel: ['journal_uid'],
  till_shortages: ['charge_uid', 'paid_cash_uid'], till_surplus: ['cash_uid'], ap_recurring: [], money_snaps: [],
};
// Keys that are not uids: which columns hold them.
const CODE_REFS = {
  shops: ['shop_code', 'from_shop', 'to_shop', 'cost_area', 'location'],
  gl_accounts: ['gl_code'],
  leave_types: ['leave_type'],
};

const keyOf = (t) => (ST()[t] ? ST()[t].key : null);
let tableCache = null;
function tables() {
  if (tableCache && tableCache.at > Date.now() - 60000) return tableCache.list;
  const list = db().all("SELECT name FROM sqlite_master WHERE type = 'table'").map((r) => r.name).filter((t) => !SKIP.has(t) && ST()[t]).map((t) => ({ t, cols: colsOf(t), key: keyOf(t) }));
  tableCache = { at: Date.now(), list };
  return list;
}

// Who points at any of these keys of one table? (one query per column for many keys at once)
const REFCOL = /_uid$|^ref_uid$|^ref_id$|^record_uid$|^match_uid$|^link_uid$|^set_off_uid$|^adjust_uid$|_link$|^set_off_from$|^ref$/;
function referencesTo(t, keys0) {
  const out = [];
  const keys = [...new Set((Array.isArray(keys0) ? keys0 : [keys0]).map(String))];
  if (!keys.length) return out;
  const byCode = CODE_REFS[t];
  const chunks = (list, n) => { const r = []; for (let i = 0; i < list.length; i += n) r.push(list.slice(i, i + n)); return r; };
  const owner = (row, c) => { const v = row[c]; if (keys.includes(String(v))) return String(v); return keys.find((k) => String(v || '').includes(k)) || keys[0]; };
  for (const x of tables()) {
    for (const c of x.cols) {
      if (x.t === t && c === x.key) continue;
      // a column that only says who did something never matters (saves a search)
      if (!byCode && !POLICY[`${x.t}.${c}`] && WHO.test(c)) continue;
      let rows = [];
      try {
        if (byCode) {
          if (!byCode.includes(c)) continue;
          for (const part of chunks(keys, 300)) rows = rows.concat(db().all(`SELECT * FROM ${x.t} WHERE ${c} IN (${part.map(() => '?').join(',')}) LIMIT ${MAX_ROWS + 1}`, part));
        } else if (LISTY.test(c)) {
          const long = keys.filter((k) => k.length >= 6);
          for (const part of chunks(long, 40)) rows = rows.concat(db().all(`SELECT * FROM ${x.t} WHERE ${part.map(() => `instr(${c}, ?) > 0`).join(' OR ')} LIMIT ${MAX_ROWS + 1}`, part));
        } else if (REFCOL.test(c)) {
          for (const part of chunks(keys, 300)) rows = rows.concat(db().all(`SELECT * FROM ${x.t} WHERE ${c} IN (${part.map(() => '?').join(',')}) LIMIT ${MAX_ROWS + 1}`, part));
        } else continue;
      } catch (e) { continue; }
      for (const row of rows) out.push({ t: x.t, col: c, key: x.key, k: String(row[x.key]), row, parent: owner(row, c) });
    }
  }
  for (const key of keys) {
    // A journal's bank lines carry its number in their own key.
    if (t === 'gl_journals') for (const row of db().all("SELECT * FROM bank_entries WHERE uid LIKE ?", [`BE-JN-${key}%`])) out.push({ t: 'bank_entries', col: '(journal)', key: 'uid', k: row.uid, row, own: true, parent: key });
    // Loan / rent terms share the key of their regular bill.
    if (t === 'ap_recurring' && has('regular_terms')) for (const row of db().all('SELECT * FROM regular_terms WHERE uid = ?', [key])) out.push({ t: 'regular_terms', col: '(same key)', key: 'uid', k: row.uid, row, own: true, parent: key });
    if (t === 'users') {
      for (const tt of ['pay_profiles', 'staff_details', 'rosters']) if (has(tt)) for (const row of db().all(`SELECT * FROM ${tt} WHERE user_uid = ?`, [key])) out.push({ t: tt, col: '(same person)', key: 'user_uid', k: row.user_uid, row, own: true, parent: key });
    }
  }
  return out;
}
function policyFor(ref, parentTable) {
  if (ref.own) return 'take';
  const p = POLICY[`${ref.t}.${ref.col}`];
  if (p) return p;
  if (WHO.test(ref.col)) return 'ignore';
  if (ref.col === 'supplier_uid' && parentTable === 'ap_suppliers') return 'block';
  if (CODE_REFS[parentTable]) return 'block';
  return 'block';
}

const DATE_COLS = ['invoice_date', 'pay_date', 'shift_date', 'jdate', 'entry_date', 'receive_date', 'deposit_date', 'move_date', 'snap_date', 'cheque_date', 'order_date', 'charge_date', 'debt_date', 'settle_date',
  'mark_date', 'from_date', 'count_date', 'send_date', 'fill_date', 'work_date', 'line_date', 'statement_date', 'eod_date', 'hand_date', 'run_date', 'purchase_date', 'paid_date', 'issued_date', 'expiry_date', 'week_end'];
const dateOf = (row) => { for (const c of DATE_COLS) if (row && row[c]) return String(row[c]).slice(0, 10); if (row && row.at) return String(row.at).slice(0, 10); return null; };
const MONEY_DATE = new Set(['ap_invoices', 'ap_payments', 'cheques', 'bank_entries', 'deposits', 'cash_moves', 'till_counts', 'gl_journals', 'inv_receipts', 'inv_moves', 'pay_runs', 'pay_lines', 'owner_moves', 've_fuel',
  'stat_payments', 'staff_charges', 'credit_settlements', 'wallet_moves', 'aronium_eods', 'fixed_assets', 'loan_entries', 'regular_receipts', 'ap_allocations', 'inv_transfers', 'safe_counts', 'money_snaps']);

// A short name for a record (shown in the bin and the change history).
export function titleOf(t, row) {
  if (!row) return labelOf(t);
  const m = (n) => `$${(Number(n) || 0).toFixed(2)}`;
  const L = labelOf(t);
  const cap = L.charAt(0).toUpperCase() + L.slice(1);
  switch (t) {
    case 'ap_invoices': return `${row.kind === 'credit' ? 'Credit note' : 'Invoice'} ${row.invoice_no || '(no number)'} · ${row.supplier_name} · ${m(row.total)}`;
    case 'ap_payments': return `Payment ${row.method || ''}${row.cheque_no ? ` ${row.cheque_no}` : ''} · ${row.supplier_name} · ${m(row.amount)}`;
    case 'cheques': return `Cheque ${row.cheque_no} · ${row.payee || ''} · ${m(row.amount)}`;
    case 'po_orders': return `Purchase order ${row.po_no} · ${row.supplier_name || ''}`;
    case 'inv_receipts': return `${row.kind === 'return' ? 'Return' : 'Delivery'} · ${row.supplier_name || ''} · ${row.receive_date}`;
    case 'licences': return `${row.name}${row.licence_no ? ` (${row.licence_no})` : ''}`;
    case 'shop_accounts': return `Bill account ${row.label}${row.account_no ? ` · ${row.account_no}` : ''}`;
    case 'shops': return `Shop ${row.code} · ${row.name}`;
    case 'users': return `Staff ${row.name}`;
    case 'ap_suppliers': return `Supplier ${row.name}`;
    case 'inv_items': return `Product ${row.name}${row.code ? ` (${row.code})` : ''}`;
    case 'till_counts': return `Till count ${row.shop_code} ${row.shift_date} ${row.shift || ''} ${row.till_name || ''}`.trim();
    case 'money_snaps': return `Photo record · ${row.party || row.kind || ''} · ${m(row.amount)}`;
    case 'bank_entries': return `Bank line ${row.entry_date} · ${row.reference || row.note || row.type} · ${m(row.amount)}`;
    case 'deposits': return `Bank deposit ${row.deposit_date} · ${m(row.total)}`;
    case 'gl_journals': return `Journal ${row.jdate} · ${row.memo || ''}`;
    case 'punches': return `${row.name} ${row.type} ${String(row.at || '').slice(0, 16)}`;
    case 'leave_requests': return `Leave ${row.name} ${row.from_date}–${row.to_date}`;
    case 'roster_marks': return `${row.name} ${row.mark_date} ${row.kind}`;
    case 'staff_charges': return `Charge ${row.name} · ${m(row.amount)} · ${row.reason || ''}`;
    case 'pay_runs': return `Pay run ${row.week_start} – ${row.week_end}`;
    case 've_items': return `${row.kind === 'vehicle' ? 'Vehicle' : 'Equipment'} ${row.name}${row.rego ? ` (${row.rego})` : ''}`;
    case 'documents': return `Document ${row.name}`;
    case 'ap_allocations': {
      let p = null; try { p = db().get('SELECT * FROM ap_payments WHERE uid = ?', [row.payment_uid]); } catch (e) { p = null; }
      return p ? `${m(row.amount)} paid by ${titleOf('ap_payments', p)} – delete the payment first` : `${m(row.amount)} paid on it`;
    }
    case 'ap_recurring': return `${row.kind === 'loan' ? 'Loan' : 'Regular bill'} ${row.name} · ${m(row.amount)}`;
    default: {
      const name = row.name || row.title || row.label || row.reference || row.memo || row.note || '';
      const d = dateOf(row);
      return `${cap}${name ? ` · ${String(name).slice(0, 60)}` : ''}${d ? ` · ${d}` : ''}`;
    }
  }
}

// ---------------------------------------------------------------- what a delete would do
// Returns { title, take: [{t,k,row}], unlink: [{t,k,col,old}], blocks: [text], closed: {date, why} | null, count }.
export function deletePlan(table, keyVal) {
  need(table && ST()[table] && !SKIP.has(table) && has(table), 'This kind of record cannot be deleted here.');
  const key = keyOf(table);
  const row = db().get(`SELECT * FROM ${table} WHERE ${key} = ?`, [keyVal]);
  need(row, 'This record is not here any more (it may be deleted already).');
  const take = [{ t: table, k: String(keyVal), row, key }];
  const seen = new Set([`${table}|${keyVal}`]);
  const unlink = [];
  const blocks = [];
  let level = [{ t: table, k: String(keyVal), row, depth: 0 }];
  while (level.length && take.length <= MAX_ROWS) {
    const next = [];
    // records it owns that it points at itself
    for (const cur of level) {
      for (const c of OWNS[cur.t] || []) {
        const v = cur.row[c];
        if (!v) continue;
        const tgt = { bank_entry_uid: 'bank_entries', cheque_uid: 'cheques', journal_uid: 'gl_journals', cash_uid: 'cash_moves', charge_uid: 'staff_charges', paid_cash_uid: 'cash_moves' }[c];
        if (!tgt || !has(tgt) || seen.has(`${tgt}|${v}`)) continue;
        const r = db().get(`SELECT * FROM ${tgt} WHERE uid = ?`, [v]);
        if (!r) continue;
        seen.add(`${tgt}|${v}`);
        take.push({ t: tgt, k: String(v), row: r, key: 'uid' });
        next.push({ t: tgt, k: String(v), row: r, depth: cur.depth + 1 });
      }
    }
    // who points at them (one search per table for the whole level)
    const byTable = {};
    level.forEach((cur) => { (byTable[cur.t] = byTable[cur.t] || []).push(cur); });
    for (const [t, items] of Object.entries(byTable)) {
      const depth = items[0].depth;
      for (const ref of referencesTo(t, items.map((x) => x.k))) {
        const id = `${ref.t}|${ref.k}`;
        if (seen.has(id)) continue;
        const p = policyFor(ref, t);
        if (p === 'ignore') continue;
        if (p === 'take') {
          seen.add(id);
          take.push({ t: ref.t, k: ref.k, row: ref.row, key: ref.key });
          if (depth < 4) next.push({ t: ref.t, k: ref.k, row: ref.row, depth: depth + 1 });
        } else if (p === 'unlink') {
          if (!unlink.some((u) => u.t === ref.t && u.k === ref.k && u.col === ref.col)) unlink.push({ t: ref.t, k: ref.k, key: ref.key, col: ref.col, old: ref.row[ref.col] });
        } else {
          const text = `${cap(labelOf(ref.t))}: ${titleOf(ref.t, ref.row)}`;
          if (!blocks.includes(text)) blocks.push(text);
        }
        if (take.length > MAX_ROWS) break;
      }
      if (take.length > MAX_ROWS) break;
    }
    level = next;
  }
  // A record taken with it that still uses money elsewhere (e.g. a cheque that is in a bank deposit) was found
  // above as a block. Special checks:
  if (table === 'pay_runs' && row.status === 'final') blocks.unshift('This pay run is final (people were paid). Reopen it first (with a reason), then delete it.');
  if (table === 'users' && db().get('SELECT 1 AS x FROM users WHERE uid = ? AND role = ?', [keyVal, 'owner']) && db().get("SELECT COUNT(*) AS n FROM users WHERE role = 'owner' AND active = 1").n <= 1) blocks.unshift('This is the only owner login.');
  if (table === 'shops' && db().get("SELECT COUNT(*) AS n FROM shops WHERE active = 1").n <= 1 && row.active) blocks.unshift('This is the only shop.');
  // the bakery's older records point at a person by number, not by uid
  if (table === 'users' && row.id !== undefined && row.id !== null) {
    const B = [['shifts', ['opened_by', 'closed_by', 'approved_by']], ['shift_workers', ['user_id']], ['batches', ['user_id', 'finished_by']], ['transactions', ['user_id']], ['checklist_runs', ['user_id']], ['checklist_entries', ['user_id']], ['equipment_log', ['user_id', 'resolved_by']], ['alerts', ['user_id', 'ack_by']]];
    let n = 0;
    for (const [bt, cs] of B) {
      if (!has(bt)) continue;
      const have = colsOf(bt);
      for (const c of cs) if (have.includes(c)) { try { n += db().get(`SELECT COUNT(*) AS n FROM ${bt} WHERE ${c} = ?`, [row.id]).n; } catch (e) { /* skip */ } }
    }
    if (n) blocks.push(`Bakery records: ${n} (shifts, batches, stock) – mark the person as left instead`);
  }
  const tooMany = take.length > MAX_ROWS;
  if (tooMany) blocks.unshift(`It takes more than ${MAX_ROWS} records with it. Delete some of its parts first.`);
  // a month whose books are closed or whose VAT return is filed
  let closed = null;
  try {
    const lock = require('./lock.js').lockDate();
    for (const x of take) {
      if (!MONEY_DATE.has(x.t)) continue;
      const d = dateOf(x.row);
      if (!d) continue;
      if (lock && d <= lock) { closed = { date: d, why: `The books are closed up to ${lock} (VAT return filed). Deleting it changes a filed month – tell the accountant; an amended return may be needed.` }; break; }
      if (has('tax_return_versions') && db().get("SELECT 1 AS x FROM tax_return_versions WHERE kind = 'vat' AND period = ? AND status = 'lodged'", [d.slice(0, 7)])) {
        closed = { date: d, why: `The VAT return for ${d.slice(0, 7)} is filed. Deleting it changes that month – an amended VAT return may be needed.` }; break;
      }
    }
  } catch (e) { closed = null; }
  const counts = {};
  take.slice(1).forEach((x) => { counts[x.t] = (counts[x.t] || 0) + 1; });
  return { table, keyVal: String(keyVal), title: titleOf(table, row), row, take, unlink, blocks, closed, count: take.length, alsoGoes: Object.entries(counts).map(([t, n]) => `${n} ${labelOf(t)}${n === 1 ? '' : 's'}`) };
}
const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);

// ---------------------------------------------------------------- delete, restore, purge
const withoutSync = (row) => { const r = { ...row }; delete r.sync_status; return r; };

export function deleteRecord(user, table, keyVal, { reason = '', confirmClosed = false, today = dateStr() } = {}) {
  need(canDelete(user), 'Only the owner or an admin can delete records.');
  const plan = deletePlan(table, keyVal);
  need(!plan.blocks.length, `It cannot be deleted yet:\n• ${plan.blocks.slice(0, 8).join('\n• ')}${plan.blocks.length > 8 ? `\n• … and ${plan.blocks.length - 8} more` : ''}`);
  if (plan.closed) need(confirmClosed, plan.closed.why);
  need(txt(reason).length <= 500, 'The reason is too long (500 letters at most).');
  const uid = uuid('BIN');
  const now = stamp(); const dev = deviceId();
  const keys = plan.take.map((x) => ({ t: x.t, k: x.k }));
  const data = JSON.stringify(plan.take.map((x) => ({ t: x.t, k: x.k, row: withoutSync(x.row) })));
  const parts = [];
  for (let i = 0; i < data.length; i += PART_CHARS) parts.push(data.slice(i, i + PART_CHARS));
  const unlinked = plan.unlink.map((u) => ({ t: u.t, k: u.k, col: u.col, old: u.old }));
  const shop = plan.row.shop_code || (table === 'shops' ? plan.row.code : null) || null;
  db().transaction(() => {
    for (const u of plan.unlink) {
      const cols = colsOf(u.t);
      const extra = u.t.endsWith('_lines') && cols.includes('match_type') && u.col === 'match_uid' ? ', match_type = NULL' : (u.t === 'money_snaps' && u.col === 'link_uid' ? ', link_table = NULL' : '');
      db().run(`UPDATE ${u.t} SET ${u.col} = NULL${extra}${cols.includes('updated_at') ? ', updated_at = ?, updated_device = ?' : ''}${cols.includes('sync_status') ? ", sync_status = 'pending'" : ''} WHERE ${u.key} = ?`,
        (cols.includes('updated_at') ? [now, dev] : []).concat([u.k]));
    }
    for (const x of plan.take.slice().reverse()) {
      db().run(`DELETE FROM ${x.t} WHERE ${x.key || keyOf(x.t)} = ?`, [x.k]);
      db().run('INSERT OR REPLACE INTO bin_index (t, k, bin_uid) VALUES (?, ?, ?)', [x.t, x.k, uid]);
    }
    parts.forEach((p, n) => db().run(`INSERT INTO bin_parts (uid, bin_uid, n, data, updated_at, updated_device, sync_status) VALUES (?,?,?,?,?,?,'pending')`, [`${uid}#${n}`, uid, n, p, now, dev]));
    db().run(`INSERT INTO bin_records (uid, tbl, rkey, title, kind, shop_code, rec_date, keys, parts, unlinked, summary, reason, closed_period, deleted_by_uid, deleted_by_name, deleted_at, purge_after, status, updated_at, updated_device, sync_status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'binned',?,?,'pending')`,
      [uid, table, String(keyVal), plan.title, labelOf(table), shop, dateOf(plan.row), JSON.stringify(keys), parts.length, JSON.stringify(unlinked), plan.alsoGoes.join(', ') || null, txt(reason) || null,
        plan.closed ? 1 : 0, user.uid || null, user.name || '', now, addDays(today, KEEP_DAYS), now, dev]);
    audit({ user, action: `Deleted ${plan.title} (to the Deleted bin for ${KEEP_DAYS} days)${plan.alsoGoes.length ? ` – with ${plan.alsoGoes.join(', ')}` : ''}${plan.closed ? ' – in a filed / closed month' : ''}`,
      table, recordUid: String(keyVal), before: plan.row, after: { bin: uid }, reason: txt(reason) || null });
  });
  afterChange(plan.take);
  return { uid, title: plan.title, count: plan.count };
}

function partsData(b) {
  const list = db().all('SELECT n, data FROM bin_parts WHERE bin_uid = ? ORDER BY n', [b.uid]);
  if (list.length !== Number(b.parts || 0) || list.some((p, i) => p.n !== i || p.data === null)) return null;
  return J(list.map((p) => p.data).join(''), null);
}
export function getBinEntry(uid) {
  const b = has('bin_records') ? db().get('SELECT * FROM bin_records WHERE uid = ?', [uid]) : null;
  return b ? { ...b, keys: J(b.keys, []), unlinked: J(b.unlinked, []) } : null;
}
export function binRows(uid) {
  const b = getBinEntry(uid);
  if (!b || b.status === 'gone') return null;
  return partsData(b);
}

export function restoreRecord(user, binUid, { confirmClosed = false } = {}) {
  need(canDelete(user), 'Only the owner or an admin can put records back.');
  const b = getBinEntry(binUid);
  need(b, 'This is not in the Deleted bin.');
  need(b.tbl !== 'devices', 'A removed device cannot simply come back (that keeps the business data safe). Link it again with a new invite: Settings › Devices.');
  need(b.status === 'binned', b.status === 'restored' ? 'It was put back already.' : 'It is gone for good (more than 90 days in the bin).');
  const rows = partsData(b);
  need(Array.isArray(rows) && rows.length, 'The copy of this record is still on its way from the cloud. Sync, then try again.');
  for (const x of rows) {
    need(ST()[x.t] && has(x.t), `This app version does not have "${labelOf(x.t)}" – update the app first.`);
    const k = keyOf(x.t);
    need(!db().get(`SELECT 1 AS x FROM ${x.t} WHERE ${k} = ?`, [x.k]), `A ${labelOf(x.t)} with the same number is in the app again, so this cannot be put back over it.`);
  }
  // a record it needs that is itself still in the bin goes back first (e.g. the invoice a payment pays)
  const mine = new Set(rows.map((x) => `${x.t}|${x.k}`));
  for (const x of rows) {
    for (const [c, v] of Object.entries(x.row || {})) {
      if (!v || typeof v !== 'string' || !/_uid$/.test(c) || WHO.test(c)) continue;
      const hit = db().get('SELECT i.t, i.k, b.title FROM bin_index i JOIN bin_records b ON b.uid = i.bin_uid WHERE i.k = ? AND b.status = ? AND i.bin_uid <> ?', [v, 'binned', b.uid]);
      if (hit && !mine.has(`${hit.t}|${hit.k}`)) need(false, `Put back "${hit.title}" first – this record needs it.`);
      const gone = db().get('SELECT b.title FROM bin_index i JOIN bin_records b ON b.uid = i.bin_uid WHERE i.k = ? AND b.status = ?', [v, 'gone']);
      if (gone && !mine.has(`${x.t}|${v}`)) need(false, `"${gone.title}" that this record needs is gone for good, so it cannot be put back.`);
    }
  }
  if (b.closed_period) need(confirmClosed, `It is in a month whose VAT return is filed or whose books are closed. Putting it back changes that month – tell the accountant.`);
  const now = stamp(); const dev = deviceId();
  db().transaction(() => {
    for (const x of rows) {
      const have = colsOf(x.t);
      const cols = Object.keys(x.row || {}).filter((c) => have.includes(c) && c !== 'sync_status');
      const vals = cols.map((c) => (c === 'updated_at' ? now : c === 'updated_device' ? dev : x.row[c]));
      db().run(`INSERT INTO ${x.t} (${cols.join(', ')}${have.includes('sync_status') ? ', sync_status' : ''}) VALUES (${cols.map(() => '?').join(', ')}${have.includes('sync_status') ? ", 'pending'" : ''})`, vals);
      db().run('DELETE FROM bin_index WHERE t = ? AND k = ?', [x.t, x.k]);
    }
    for (const u of b.unlinked) {
      const have = colsOf(u.t);
      if (!have.length) continue;
      const kk = keyOf(u.t);
      db().run(`UPDATE ${u.t} SET ${u.col} = ?${have.includes('updated_at') ? ', updated_at = ?, updated_device = ?' : ''}${have.includes('sync_status') ? ", sync_status = 'pending'" : ''} WHERE ${kk} = ? AND ${u.col} IS NULL`,
        [u.old].concat(have.includes('updated_at') ? [now, dev] : []).concat([u.k]));
    }
    db().run("UPDATE bin_records SET status = 'restored', restored_by_name = ?, restored_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [user.name || '', now, now, dev, b.uid]);
    audit({ user, action: `Put back from the Deleted bin: ${b.title}`, table: b.tbl, recordUid: b.rkey, after: { bin: b.uid } });
  });
  afterChange(rows);
  return { title: b.title, count: rows.length };
}

// After 90 days the records are gone for good: the copy in the bin is cleared and the cloud copy of each record is
// overwritten with an empty marker. The bin keeps one line (what, who, when) so a late copy never comes back.
export function purgeBin({ today = dateStr() } = {}) {
  if (!has('bin_records')) return 0;
  const due = db().all("SELECT * FROM bin_records WHERE status = 'binned' AND purge_after <= ?", [today]);
  if (!due.length) return 0;
  const now = stamp(); const dev = deviceId();
  db().transaction(() => {
    for (const b of due) {
      const keys = J(b.keys, []);
      for (const x of keys) {
        db().run('INSERT OR REPLACE INTO bin_index (t, k, bin_uid) VALUES (?, ?, ?)', [x.t, x.k, b.uid]);
        db().run('INSERT OR REPLACE INTO bin_scrub (t, k, at) VALUES (?, ?, ?)', [x.t, x.k, now]);
      }
      for (const p of db().all('SELECT uid FROM bin_parts WHERE bin_uid = ?', [b.uid])) db().run('INSERT OR REPLACE INTO bin_scrub (t, k, at) VALUES (?, ?, ?)', ['bin_parts', p.uid, now]);
      db().run('DELETE FROM bin_parts WHERE bin_uid = ?', [b.uid]);
      db().run("UPDATE bin_records SET status = 'gone', gone_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, now, dev, b.uid]);
    }
  });
  return due.length;
}

// ---------------------------------------------------------------- what the bin shows
export function listBin({ status = 'binned', q = '', limit = 300, today = dateStr() } = {}) {
  if (!has('bin_records')) return [];
  const s = txt(q).toLowerCase();
  return db().all(`SELECT * FROM bin_records ${status === 'all' ? '' : 'WHERE status = ?'} ORDER BY deleted_at DESC LIMIT ?`, status === 'all' ? [limit] : [status, limit])
    .filter((b) => !s || `${b.title} ${b.kind} ${b.deleted_by_name} ${b.reason || ''}`.toLowerCase().includes(s))
    .map((b) => ({ ...b, daysLeft: Math.max(0, Math.round((Date.parse(`${b.purge_after}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86400000)), ready: b.status !== 'binned' || binReady(b) }));
}
function binReady(b) {
  try { return db().get('SELECT COUNT(*) AS n FROM bin_parts WHERE bin_uid = ?', [b.uid]).n === Number(b.parts || 0); } catch (e) { return false; }
}
export function binCount() { try { return has('bin_records') ? db().get("SELECT COUNT(*) AS n FROM bin_records WHERE status = 'binned'").n : 0; } catch (e) { return 0; } }

// ---------------------------------------------------------------- sync
// Is this record in the bin (or gone)? Then a copy from the cloud is not brought back.
export function inBin(t, k) {
  try { return !!db().get('SELECT 1 AS x FROM bin_index WHERE t = ? AND k = ?', [t, String(k)]); } catch (e) { return false; }
}
// A bin entry arrived from another device: do the same here.
export function binArrived(row) {
  if (!row || !row.uid) return;
  const keys = J(row.keys, []);
  if (row.status === 'binned' || row.status === 'gone') {
    for (const x of keys) {
      if (!x || !x.t || !ST()[x.t] || SKIP.has(x.t) || !has(x.t)) continue;
      try { db().run(`DELETE FROM ${x.t} WHERE ${keyOf(x.t)} = ?`, [x.k]); } catch (e) { /* keep going */ }
      db().run('INSERT OR REPLACE INTO bin_index (t, k, bin_uid) VALUES (?, ?, ?)', [x.t, String(x.k), row.uid]);
    }
    if (row.status === 'gone') db().run('DELETE FROM bin_parts WHERE bin_uid = ?', [row.uid]);
  } else if (row.status === 'restored') {
    for (const x of keys) db().run('DELETE FROM bin_index WHERE t = ? AND k = ? AND bin_uid = ?', [x.t, String(x.k), row.uid]);
    // the restoring device sends the records again; put them back now if their copy is here
    const b = { ...row };
    const rows = partsData(b);
    for (const x of rows || []) {
      try {
        if (!ST()[x.t] || !has(x.t) || db().get(`SELECT 1 AS x FROM ${x.t} WHERE ${keyOf(x.t)} = ?`, [x.k])) continue;
        const have = colsOf(x.t);
        const cols = Object.keys(x.row || {}).filter((c) => have.includes(c) && c !== 'sync_status');
        db().run(`INSERT INTO ${x.t} (${cols.join(', ')}${have.includes('sync_status') ? ', sync_status' : ''}) VALUES (${cols.map(() => '?').join(', ')}${have.includes('sync_status') ? ", 'synced'" : ''})`, cols.map((c) => x.row[c]));
      } catch (e) { /* the restoring device's own copy arrives next */ }
    }
  }
}
// Empty markers that overwrite the cloud copy of records gone for good (sent with the normal records).
export function scrubRecords(limit = 200) {
  if (!has('bin_scrub')) return [];
  return db().all('SELECT * FROM bin_scrub ORDER BY at LIMIT ?', [limit]).map((s) => {
    const key = keyOf(s.t) || 'uid';
    return { t: s.t, k: s.k, u: s.at, row: { [key]: s.k, updated_at: s.at, updated_device: deviceId(), _gone: 1 }, scrub: true };
  });
}
export function scrubSent(list) {
  for (const r of list || []) if (r && r.scrub) { try { db().run('DELETE FROM bin_scrub WHERE t = ? AND k = ? AND at = ?', [r.t, r.k, r.u]); } catch (e) { /* next time */ } }
}
// Rebuild the local list of what is in the bin (after a backup is restored, or on start-up if it is missing).
export function rebuildBinIndex() {
  if (!has('bin_records')) return;
  for (const b of db().all("SELECT uid, keys FROM bin_records WHERE status IN ('binned','gone')")) {
    for (const x of J(b.keys, [])) if (x && x.t) db().run('INSERT OR IGNORE INTO bin_index (t, k, bin_uid) VALUES (?, ?, ?)', [x.t, String(x.k), b.uid]);
  }
}

// What the deleted / restored records change elsewhere is worked out again.
function afterChange(rows) {
  try {
    const I = require('../modules/inventory/service.js');
    const pos = new Set();
    for (const x of rows || []) {
      if (x.t === 'inv_receipts' && x.row && x.row.po_uid) pos.add(x.row.po_uid);
      if (x.t === 'po_lines' && x.row && x.row.po_uid) pos.add(x.row.po_uid);
    }
    pos.forEach((u) => { try { if (db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [u])) { I.recountReceived(u); I.refreshPOStatus(u); } } catch (e) { /* next sync */ } });
  } catch (e) { /* inventory not set up */ }
  try { require('./board.js').boardStale(); } catch (e) { /* no dashboard */ }
  tableCache = null;
}

// A device removed from the Devices list is shown in the bin for 90 days (who removed it and when). It is not put
// back from here: it must be linked again with a new invite.
export function binDevice(user, d, { today = dateStr() } = {}) {
  if (!d || !d.id || !has('bin_records')) return null;
  const uid = uuid('BIN');
  const now = stamp();
  db().run(`INSERT INTO bin_records (uid, tbl, rkey, title, kind, shop_code, rec_date, keys, parts, unlinked, summary, reason, closed_period, deleted_by_uid, deleted_by_name, deleted_at, purge_after, status, updated_at, updated_device, sync_status)
    VALUES (?, 'devices', ?, ?, 'device', ?, ?, '[]', 0, '[]', ?, NULL, 0, ?, ?, ?, ?, 'binned', ?, ?, 'pending')`,
    [uid, String(d.id), `Device ${d.name || d.id}`, d.shop || null, today, d.kind || null, user ? user.uid || null : null, user ? user.name || '' : '', now, addDays(today, KEEP_DAYS), now, deviceId()]);
  audit({ user, action: `Removed device ${d.name || d.id} (shown in the Deleted bin for ${KEEP_DAYS} days)`, table: 'devices', recordUid: String(d.id) });
  return uid;
}
