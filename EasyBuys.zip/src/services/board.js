// The online dashboard's content (v3.9.4). The app decides what the dashboard shows: it sends a list of sections, each
// made of simple blocks the web page knows how to draw (tiles, lists, tables, bar charts, notes). New sections arrive
// with app updates – the page in the cloud never needs changing again.
// Owner / admin choose sections, their order and what is kept off the internet in Admin › Online dashboard.
// Every section is worked out on its own: one that fails is left out with a note, the rest still show.
import { db, keepTracked, trackReads, noteDeps, stepThrough, isStop } from '../db/connection.js';
import { dateStr, addDays, stamp, getShared, setShared, audit, AppError, APP_VERSION } from './core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
// Modules are loaded when needed (each one a plain require so the bundler finds it); a missing one is skipped.
const safe = (fn) => { try { return fn(); } catch (e) { return null; } };
const shopNames = () => { try { return Object.fromEntries(db().all('SELECT code, name FROM shops').map((s) => [s.code, s.name])); } catch (e) { return {}; } };
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const dow = (d) => DOW[new Date(`${d}T12:00:00`).getDay()];
const short = (d) => (d ? `${dow(d)} ${d.slice(8, 10)}/${d.slice(5, 7)}` : '');

// ---------------------------------------------------------------- settings (Admin › Online dashboard)
export const BOARD_SECTIONS = [
  { id: 'today', title: 'Today', icon: '📌', note: 'Needs attention now, due this week, forecast, people.' },
  { id: 'sales', title: 'Sales', icon: '📈', note: 'Per shop and till, against the usual for that weekday; the last weeks.' },
  { id: 'money', title: 'Money', icon: '💰', note: 'Cash and bank, what goes out in the coming weeks, the forecast.' },
  { id: 'purchases', title: 'Purchase orders', icon: '🧾', note: 'Every PO raised, its status and delivery date.' },
  { id: 'invoices', title: 'Supplier invoices', icon: '📥', note: 'Invoices received, what is owing and due.' },
  { id: 'cheques', title: 'Cheques', icon: '✍️', note: 'Cheques written, handed over, cleared.' },
  { id: 'people', title: 'People', icon: '👥', note: 'Who is in, late, on leave.' },
  { id: 'stock', title: 'Stock', icon: '📦', note: 'Low and out of stock per shop.' },
  { id: 'insights', title: 'Insights', icon: '💡', note: 'Busy hours, cashier watch, sold below cost, slow movers (from the till PCs).' },
  { id: 'bakery', title: 'Bakery', icon: '🥖', note: 'What is in the oven and today\'s production.' },
];
// The parts of the Today page (each can be switched off in Admin › Online dashboard).
export const TODAY_PARTS = [
  { id: 'g_sales', label: 'Sales today so far (against the usual for the weekday, last 14 days)' },
  { id: 'g_month', label: 'Month to date (against the same days last month)' },
  { id: 'g_yday', label: 'Yesterday: sales, receipts, average sale' },
  { id: 'g_profit', label: 'Profit yesterday (sales less cost, margin)' },
  { id: 'g_cash', label: 'Cash & bank now and after this week' },
  { id: 'g_due', label: 'Due in the next 7 days and overdue' },
  { id: 'g_staff', label: 'Staff in now, late, on leave' },
  { id: 'g_stock', label: 'Stock low / out' },
  { id: 'shops', label: 'One strip per shop (today, yesterday, payments, refunds, voids, till differences)' },
  { id: 'attention', label: 'Needs attention now' },
  { id: 'due', label: 'Due today and the next 7 days' },
  { id: 'best', label: 'Best sellers yesterday, and usual sellers that did not sell' },
  { id: 'bakery', label: 'Bakery plan today' },
];
export const BOARD_HIDE = [
  { id: 'wages', label: 'Wages amounts' },
  { id: 'loans', label: 'Loan balances and repayments' },
  { id: 'bank', label: 'Bank and cash balances' },
];
export function boardSettings() {
  const s = getShared('dashboard_cfg', {}) || {};
  const ids = BOARD_SECTIONS.map((x) => x.id);
  const order = (Array.isArray(s.order) ? s.order.filter((x) => ids.includes(x)) : []).concat(ids.filter((x) => !(s.order || []).includes(x)));
  return { order, off: Array.isArray(s.off) ? s.off.filter((x) => ids.includes(x)) : [], hide: { wages: !!(s.hide || {}).wages, loans: !!(s.hide || {}).loans, bank: !!(s.hide || {}).bank },
    days: [7, 30, 90].includes(Number(s.days)) ? Number(s.days) : 30,
    partsOff: Array.isArray(s.partsOff) ? s.partsOff.filter((x) => TODAY_PARTS.some((p) => p.id === x)) : [] };
}
export function saveBoardSettings(user, patch) {
  require('./guard.js').requirePerm(user, 'dashboard_setup'); // 1.0.0 hardening (H1): checked inside the service
  if (!user || !['owner', 'admin'].includes(user.role)) throw new AppError('Only the owner or an admin can change the online dashboard.');
  const before = boardSettings();
  const next = { ...before, ...patch, hide: { ...before.hide, ...(patch.hide || {}) } };
  setShared('dashboard_cfg', next);
  audit({ user, action: 'Changed what the online dashboard shows', table: 'shared_settings', recordUid: 'dashboard_cfg', before, after: next });
  cache.at = 0;
  return boardSettings();
}

// ---------------------------------------------------------------- blocks
const tiles = (items, opts = {}) => ({ type: 'tiles', items: items.filter(Boolean), ...opts });
const list = (title, items, empty, opts = {}) => ({ type: 'list', title, items, empty: empty || 'Nothing here.', ...opts });
const table = (title, cols, rows, opts = {}) => ({ type: 'table', title, cols, rows, ...opts });
const bars = (title, labels, series, opts = {}) => ({ type: 'bars', title, labels, series, ...opts });
const note = (text, tone) => ({ type: 'note', text, tone: tone || 'info' });
const M = (v) => r2(v);

// ---------------------------------------------------------------- the data each section uses
// Sales per shop per day: the till PCs (Aronium link) when they send, otherwise the till balances.
// v3.9.6 also used by the shop page.
export function shopSalesByDay(from) { return salesByDay(from); }
function salesByDay(from) {
  // 1.0.0 build 4: decided for each shop and day: the till PCs' figure where that shop / day has one, else the till
  // balances (a till PC that stops sending never makes the other shop's till balances disappear).
  const fallback = [];
  if (has('till_counts')) {
    const E = safe(() => require('../modules/till/eod.js'));
    for (const c of db().all("SELECT * FROM till_counts WHERE shift_date >= ? AND status <> 'void'", [from])) {
      const v = E ? E.countTotal(c) : 0;
      fallback.push({ date: c.shift_date, shop: c.shop_code, value: v, tills: { [c.till_name || 'Till']: v } });
    }
  }
  const L = safe(() => require('../modules/aronium/link.js'));
  let rows = null;
  if (L) rows = safe(() => L.salesPerShopDay({ from, fallback }), null);
  if (!rows) {
    const m = new Map();
    for (const f of fallback) { const k = `${f.date}|${f.shop}`; const o = m.get(k) || { date: f.date, shop: f.shop, value: 0, tills: {}, live: false }; o.value = r2(o.value + f.value); for (const [t, v] of Object.entries(f.tills)) o.tills[t] = r2((o.tills[t] || 0) + v); m.set(k, o); }
    rows = [...m.values()];
  }
  const live = rows.filter((r) => r.live).length;
  return { rows, source: !live ? 'till balances' : live === rows.length ? 'Aronium (till PCs)' : 'Aronium (till PCs), and the till balances for shops / days with nothing from a till PC' };
}
// The usual for a weekday: the average of the same weekday over the last 4 weeks that had sales.
function usual(rows, shop, date) {
  const vals = [7, 14, 21, 28].map((n) => rows.find((r) => r.shop === shop && r.date === addDays(date, -n))).filter((r) => r && r.value > 0).map((r) => r.value);
  return vals.length ? r2(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
}
function ownerView() { return { uid: 'dashboard', name: 'Online dashboard', role: 'owner' }; }

// ---------------------------------------------------------------- sections
function sToday(ctx) {
  const blocks = [];
  const today = ctx.today;
  const yday = addDays(today, -1);
  const on = (id) => !ctx.cfg.partsOff.includes(id);
  const pct = (a, b) => (b > 0 ? Math.round(((a - b) / b) * 1000) / 10 : null);
  // Needs attention now (the owner's warnings already worked out on this device are reused)
  const A = safe(() => require('./alerts.js'));
  const al = (A ? (A.cachedOwnerAlerts() || A.collectAlerts(ownerView(), { today })) : []).filter((a) => a.level !== 'info');
  const urgent = al.filter((a) => a.level === 'urgent').length;
  // Due today and in the next 7 days
  const due = [];
  const P = safe(() => require('../modules/payables/service.js'));
  if (P && has('ap_invoices')) {
    for (const i of P.listInvoices({ filter: 'unpaid', limit: 1000 })) {
      if (!i.due_date || i.due_date > addDays(today, 7) || i.owing <= 0.004) continue;
      due.push({ date: i.due_date, text: `${i.supplier_name}${i.invoice_no ? ` · inv ${i.invoice_no}` : ''}`, sub: i.due === 'overdue' ? `Overdue ${-i.daysToDue} day${i.daysToDue === -1 ? '' : 's'}` : i.due === 'due_today' ? 'Due today' : `Due ${short(i.due_date)}`,
        right: M(i.owing), money: true, tone: i.due === 'overdue' ? 'danger' : i.due === 'due_today' ? 'warn' : '' });
    }
  }
  if (has('ap_recurring')) {
    for (const r of db().all('SELECT * FROM ap_recurring WHERE active = 1 AND next_date <= ?', [addDays(today, 7)])) {
      if (r.kind === 'loan' && ctx.cfg.hide.loans) continue;
      if (db().get('SELECT 1 AS x FROM ap_invoices WHERE uid = ?', [`RI-${r.uid}-${r.next_date}`])) continue;
      due.push({ date: r.next_date, text: r.name, sub: `${r.kind === 'loan' ? 'Loan repayment' : 'Regular payment'} · ${short(r.next_date)}`, right: M(r.amount), money: true, tone: r.next_date < today ? 'danger' : r.next_date === today ? 'warn' : '' });
    }
  }
  if (has('po_orders')) {
    for (const p of db().all("SELECT * FROM po_orders WHERE status IN ('approved','sent','part') AND expected_date IS NOT NULL AND expected_date <= ? ORDER BY expected_date", [addDays(today, 7)])) {
      due.push({ date: p.expected_date, text: `Delivery: ${p.supplier_name} (PO ${p.po_no})`, sub: `${ctx.shops[p.shop_code] || p.shop_code} · ${p.expected_date < today ? 'late' : short(p.expected_date)}`, right: M(p.total), money: true, tone: p.expected_date < today ? 'warn' : '' });
    }
  }
  const F = ctx.forecast;
  if (F && F.weeks && F.weeks[0]) {
    const w = F.weeks[0];
    // Wages are paid on Saturday (the pay week runs Saturday to Friday).
    let pay = today; for (let k = 0; k < 7 && new Date(`${pay}T12:00:00`).getDay() !== 6; k += 1) pay = addDays(pay, 1);
    if (w.wages > 0) due.push({ date: pay, text: 'Wages (weekly pay run)', sub: `Pay day ${short(pay)} · estimate`, right: ctx.cfg.hide.wages ? null : M(w.wages), money: true, tone: '' });
    if (w.tax > 0) due.push({ date: w.to, text: 'Tax due this week (VAT / provisional tax)', sub: 'estimate', right: M(w.tax), money: true, tone: 'warn' });
  }
  let leaveToday = [];
  if (has('leave_requests')) {
    for (const l of db().all("SELECT name, type, from_date, to_date FROM leave_requests WHERE status = 'approved' AND from_date <= ? AND to_date >= ?", [addDays(today, 7), today])) {
      if (l.from_date <= today) leaveToday.push(l);
      due.push({ date: l.from_date < today ? today : l.from_date, text: `${l.name} on leave`, sub: `${l.type} · ${short(l.from_date)} – ${short(l.to_date)}`, tone: '' });
    }
  }
  due.sort((a, b) => (a.date || '').localeCompare(b.date || '') || (b.right || 0) - (a.right || 0));
  const dueMoney = r2(due.filter((d) => d.money && d.right).reduce((x, d) => x + d.right, 0));
  const overdue = r2(due.filter((d) => d.tone === 'danger' && d.right).reduce((x, d) => x + d.right, 0));
  // Sales: per shop per day (till PCs, else till balances), End of days and product lines from the till PCs
  const S = ctx.sales;
  const shopsWithSales = Object.keys(ctx.shops).filter((sh) => S.rows.some((r) => r.shop === sh));
  const dayTotal = (d) => r2(S.rows.filter((r) => r.date === d).reduce((a, r) => a + r.value, 0));
  const last14 = []; for (let k = 13; k >= 0; k -= 1) last14.push(addDays(today, -k));
  const todaySales = dayTotal(today);
  const usualToday = r2(shopsWithSales.reduce((a, sh) => a + (usual(S.rows, sh, today) || 0), 0));
  const Z = ctx.z || [];
  const zOf = (d, sh) => Z.filter((z) => z.date === d && (!sh || z.shop === sh));
  const sumZ = (list, k) => r2(list.reduce((a, z) => a + Number(z[k] || 0), 0));
  const receipts = (list) => list.reduce((a, z) => a + Number(z.receipts || 0), 0);
  const ydZ = zOf(yday);
  const ydSales = dayTotal(yday);
  const ydReceipts = receipts(ydZ);
  // month to date against the same days last month
  const mStart = `${today.slice(0, 7)}-01`;
  const lm = new Date(`${mStart}T12:00:00`); lm.setMonth(lm.getMonth() - 1);
  const lmStart = `${lm.getFullYear()}-${String(lm.getMonth() + 1).padStart(2, '0')}-01`;
  const lmSameDay = addDays(lmStart, Number(today.slice(8, 10)) - 1);
  const mtd = r2(S.rows.filter((r) => r.date >= mStart && r.date <= today).reduce((a, r) => a + r.value, 0));
  const lmtd = r2(S.rows.filter((r) => r.date >= lmStart && r.date <= lmSameDay).reduce((a, r) => a + r.value, 0));
  // profit yesterday = sales less VAT less cost (Aronium's cost prices)
  const ydLines = (ctx.salesLines || []).filter((r) => r.date === yday);
  const ydCost = r2(ydLines.reduce((a, r) => a + Number(r.cost || 0), 0));
  const ydVat = sumZ(ydZ, 'vat');
  const ydNet = r2(ydLines.reduce((a, r) => a + r.value, 0) - ydVat);
  const ydProfit = r2(ydNet - ydCost);
  // staff, stock
  const W = safe(() => require('../modules/timesheets/roster.js'));
  let onNow = [];
  try { onNow = W ? W.whoIsOn(null) : []; } catch (e) { onNow = []; }
  const late = onNow.filter((x) => x.status === 'late');
  let low = 0; let out = 0;
  if (on('g_stock')) {
    const I = safe(() => require('../modules/inventory/service.js'));
    for (const sh of Object.keys(ctx.shops)) { try { const l = I ? I.stockList({ shopCode: sh, filter: 'low', limit: 2000 }) : []; low += l.length; out += l.filter((r) => r.on_hand <= 0).length; } catch (e) { /* no stock here */ } }
  }
  const glance = [
    on('g_sales') ? { label: 'Sales today so far', value: todaySales, money: true, delta: usualToday ? pct(todaySales, usualToday) : null, sub: usualToday ? `usual for a ${dow(today)}: ${usualToday.toFixed(2)}` : `from ${S.source || 'the tills'}`, spark: last14.map(dayTotal) } : null,
    on('g_month') ? { label: `Month to date (${today.slice(8, 10)} days)`, value: mtd, money: true, delta: pct(mtd, lmtd), sub: lmtd ? `same days last month: ${lmtd.toFixed(2)}` : '' } : null,
    on('g_yday') ? { label: `Yesterday (${dow(yday)})`, value: ydSales, money: true, delta: pct(ydSales, dayTotal(addDays(yday, -7))), sub: ydReceipts ? `${ydReceipts} receipts · average ${(ydSales / ydReceipts).toFixed(2)}` : `same day last week: ${dayTotal(addDays(yday, -7)).toFixed(2)}` } : null,
    on('g_profit') && ydLines.length ? { label: 'Profit yesterday (estimate)', value: ydProfit, money: true, sub: ydNet > 0 ? `margin ${Math.round((ydProfit / ydNet) * 1000) / 10}% · sales less VAT less cost` : 'sales less VAT less cost', tone: ydProfit < 0 ? 'danger' : '' } : null,
    on('g_cash') && !ctx.cfg.hide.bank && F && F.weeks && F.weeks[0] ? { label: 'Cash & bank now', value: F.weeks[0].open, money: true, sub: `after this week: ${F.weeks[0].close.toFixed(2)}`, tone: F.weeks[0].close < 0 ? 'danger' : F.weeks[0].close < (F.weeklyWages || 0) ? 'warn' : '' } : null,
    on('g_due') ? { label: 'Due in the next 7 days', value: dueMoney, money: true, sub: overdue ? `${overdue.toFixed(2)} overdue` : 'nothing overdue', tone: overdue ? 'danger' : '' } : null,
    on('g_staff') ? { label: 'Staff in now', value: String(onNow.filter((x) => ['in', 'break'].includes(x.state)).length), sub: `${late.length ? `${late.length} late` : 'nobody late'}${leaveToday.length ? ` · ${leaveToday.length} on leave` : ''}`, tone: late.length ? 'warn' : '' } : null,
    on('g_stock') ? { label: 'Stock low / out', value: `${low} / ${out}`, sub: low ? 'see the Stock tab' : 'nothing low', tone: out ? 'danger' : low ? 'warn' : 'ok' } : null,
    on('attention') ? { label: 'Needs attention', value: String(al.length), sub: urgent ? `${urgent} urgent` : 'nothing urgent', tone: urgent ? 'danger' : al.length ? 'warn' : 'ok' } : null,
  ];
  blocks.push(tiles(glance));
  // One strip per shop
  if (on('shops')) {
    const E = safe(() => require('../modules/till/eod.js'));
    for (const sh of shopsWithSales) {
      const v = (d) => r2((S.rows.find((r) => r.shop === sh && r.date === d) || {}).value || 0);
      const u = usual(S.rows, sh, today);
      const z = zOf(yday, sh);
      const rc = receipts(z);
      const cash = sumZ(z, 'cash'); const other = sumZ(z, 'other') + sumZ(z, 'card');
      const refunds = sumZ(z, 'refunds'); const disc = sumZ(z, 'discounts');
      const voids = z.reduce((a, x) => a + Number((x.voids || {}).total || 0), 0);
      let diffs = 0;
      try { diffs = E ? (() => { const pr = E.eodProblems({ shopCode: sh, from: addDays(today, -14) }); return pr.differences.length + pr.noTill.length; })() : 0; } catch (e) { diffs = 0; }
      const unusual = (x, base) => (v(yday) > 0 && x > v(yday) * base ? 'warn' : '');
      blocks.push(tiles([
        { label: 'Today so far', value: v(today), money: true, delta: u ? pct(v(today), u) : null, sub: u ? `usual ${u.toFixed(2)}` : '', spark: last14.map(v) },
        { label: 'Yesterday', value: v(yday), money: true, delta: pct(v(yday), v(addDays(yday, -7))), sub: rc ? `${rc} receipts · avg ${(v(yday) / rc).toFixed(2)}` : '' },
        z.length ? { label: 'Cash / M-PAiSA & other', value: `${cash.toFixed(0)} / ${other.toFixed(0)}`, sub: 'yesterday' } : null,
        z.length ? { label: 'Refunds · voids · discounts', value: `${refunds.toFixed(0)} · ${voids.toFixed(0)} · ${disc.toFixed(0)}`, sub: 'yesterday', tone: unusual(refunds + voids, 0.03) || unusual(disc, 0.05) } : null,
        { label: 'Till differences to explain', value: String(diffs), sub: 'last 14 days', tone: diffs ? 'danger' : 'ok' },
      ], { title: `🏪 ${ctx.shops[sh]}` }));
    }
  }
  if (on('attention')) blocks.push(list('Needs attention now', al.slice(0, 40).map((a) => ({ text: a.text, sub: a.sub || '', tone: a.level === 'urgent' ? 'danger' : 'warn', tag: a.level === 'urgent' ? 'URGENT' : '' })), 'Nothing needs attention right now. 👍'));
  if (on('due')) blocks.push(list('Due today and the next 7 days', due.slice(0, 60), 'Nothing due in the next 7 days.'));
  // Best sellers yesterday; products that usually sell every day but sold nothing yesterday
  if (on('best') && ydLines.length) {
    for (const sh of shopsWithSales) {
      const per = new Map();
      for (const r of ydLines.filter((x) => x.shop === sh)) for (const l of r.lines || []) {
        const k = String(l.code); const o = per.get(k) || { name: l.name || k, value: 0, units: 0 };
        o.value = r2(o.value + Number(l.sold_value || 0) - Number(l.refund_value || 0)); o.units += Number(l.net || 0); per.set(k, o);
      }
      const top = [...per.values()].sort((a, b) => b.value - a.value).slice(0, 10);
      const seen = new Map();
      for (const r of (ctx.salesLines || []).filter((x) => x.shop === sh && x.date < yday && x.date >= addDays(yday, -14))) {
        const days = new Set();
        for (const l of r.lines || []) if (Number(l.net || 0) > 0) { const o = seen.get(String(l.code)) || { name: l.name, days: new Set() }; o.days.add(r.date); seen.set(String(l.code), o); }
        void days;
      }
      const missed = [...seen.entries()].filter(([k, o]) => o.days.size >= 10 && !per.has(k)).map(([, o]) => o.name).slice(0, 8);
      blocks.push(table(`🏆 ${ctx.shops[sh]} – best sellers yesterday`, [{ key: 'name', label: 'Product' }, { key: 'units', label: 'Sold', align: 'right' }, { key: 'value', label: 'Sales', align: 'right', money: true }],
        top.map((t) => ({ name: t.name, units: Math.round(t.units * 1000) / 1000, value: t.value }))));
      if (missed.length) blocks.push(note(`${ctx.shops[sh]}: usually sell every day but sold none yesterday – ${missed.join(', ')}. Out of stock, or not on the shelf?`, 'warn'));
    }
  }
  if (on('bakery')) {
    const PL = safe(() => require('./plan.js'));
    try {
      const plan = PL ? PL.planProgress(today) : [];
      if (plan.length) blocks.push(table('🥖 Bakery plan today', [{ key: 'name', label: 'Product' }, { key: 'target', label: 'Plan', align: 'right' }, { key: 'good', label: 'Made', align: 'right' }, { key: 'left', label: 'Still to make', align: 'right' }],
        plan.map((p) => ({ name: p.name, target: p.target, good: p.good, left: Math.max(0, (p.target || 0) - (p.good || 0)), _tone: (p.good || 0) >= (p.target || 0) ? 'ok' : '' }))));
    } catch (e) { /* no plan */ }
  }
  return { blocks, badge: urgent ? { text: String(urgent), tone: 'danger' } : al.length ? { text: String(al.length), tone: 'warn' } : null };
}

function sSales(ctx) {
  const { today } = ctx;
  const s = ctx.sales;
  const shops = Object.keys(ctx.shops).filter((sh) => s.rows.some((r) => r.shop === sh));
  if (!shops.length) return { blocks: [note('No sales yet. They come from the till PCs (Aronium link) or from the till balances.')] };
  const blocks = [];
  blocks.push(tiles(shops.flatMap((sh) => {
    const v = (d) => r2((s.rows.find((r) => r.shop === sh && r.date === d) || {}).value || 0);
    const u = usual(s.rows, sh, today);
    return [{ label: `${ctx.shops[sh]} – today so far`, value: v(today), money: true, sub: u ? `usual ${dow(today)}: ${u.toFixed(2)}` : '', tone: '' },
      { label: `${ctx.shops[sh]} – yesterday`, value: v(addDays(today, -1)), money: true, sub: `same day last week: ${v(addDays(today, -8)).toFixed(2)}`, tone: v(addDays(today, -1)) < v(addDays(today, -8)) * 0.85 ? 'warn' : '' }];
  })));
  const days = []; for (let k = 13; k >= 0; k -= 1) days.push(addDays(today, -k));
  blocks.push(bars('Last 14 days', days.map(short), shops.map((sh) => ({ name: ctx.shops[sh], values: days.map((d) => r2((s.rows.find((r) => r.shop === sh && r.date === d) || {}).value || 0)) })), { money: true }));
  const from = addDays(today, -ctx.cfg.days);
  const rows = s.rows.filter((r) => r.date >= from).sort((a, b) => b.date.localeCompare(a.date) || a.shop.localeCompare(b.shop))
    .map((r) => ({ date: r.date, day: dow(r.date), shop: ctx.shops[r.shop] || r.shop, tills: Object.entries(r.tills).map(([t, v]) => `${t.replace(/^S\d-/, '')}: ${v.toFixed(2)}`).join(' · '), value: r.value }));
  blocks.push(table(`Per day (last ${ctx.cfg.days} days)`, [{ key: 'date', label: 'Date' }, { key: 'day', label: 'Day' }, { key: 'shop', label: 'Shop', filter: true }, { key: 'tills', label: 'Tills' }, { key: 'value', label: 'Sales', align: 'right', money: true }], rows, { search: true }));
  blocks.push(note(`Sales from ${s.source}.`, 'info'));
  return { blocks };
}

function sMoney(ctx) {
  const F = ctx.forecast;
  const blocks = [];
  if (!F || !F.weeks) return { blocks: [note('The cash forecast is not available yet.')] };
  const w0 = F.weeks[0];
  blocks.push(tiles([
    ctx.cfg.hide.bank ? null : { label: 'Cash & bank now', value: w0.open, money: true, tone: w0.open < 0 ? 'danger' : '' },
    ctx.cfg.hide.bank ? null : { label: 'Lowest in the next 8 weeks', value: r2(F.lowest), money: true, tone: F.lowest < 0 ? 'danger' : F.lowest < F.weeklyWages ? 'warn' : 'ok' },
    { label: 'Takings per week (usual)', value: F.weeklyTakings, money: true },
    ctx.cfg.hide.wages ? null : { label: 'Wages per week (usual)', value: F.weeklyWages, money: true },
    { label: 'Owing to suppliers', value: ctx.owingTotal, money: true },
  ]));
  if (!ctx.cfg.hide.bank) blocks.push(bars('Cash & bank at the end of each week (forecast)', F.weeks.map((w) => short(w.to)), [{ name: 'Cash & bank', values: F.weeks.map((w) => w.close) }], { money: true }));
  const cols = [{ key: 'week', label: 'Week' }, { key: 'takings', label: 'Takings in', align: 'right', money: true }, { key: 'bills', label: 'Bills', align: 'right', money: true }]
    .concat(ctx.cfg.hide.wages ? [] : [{ key: 'wages', label: 'Wages', align: 'right', money: true }]).concat(ctx.cfg.hide.loans ? [] : [{ key: 'loans', label: 'Loans', align: 'right', money: true }])
    .concat([{ key: 'tax', label: 'Tax', align: 'right', money: true }]).concat(ctx.cfg.hide.bank ? [] : [{ key: 'close', label: 'Cash & bank after', align: 'right', money: true }]);
  blocks.push(table('The coming weeks', cols, F.weeks.map((w) => ({ ...w, week: `${short(w.from)} – ${short(w.to)}`, _tone: w.close < 0 ? 'danger' : '' }))));
  if (!ctx.cfg.hide.loans) {
    const FL = safe(() => require('../modules/accounting/full.js'));
    try {
      const loans = FL ? FL.listLoans({}) : [];
      if (loans.length) blocks.push(table('Loans', [{ key: 'name', label: 'Loan' }, { key: 'lender', label: 'Lender' }, { key: 'balance', label: 'Balance', align: 'right', money: true }], loans.map((g) => ({ name: g.name, lender: g.lender || '', balance: r2(g.balance) }))));
    } catch (e) { /* none */ }
  }
  blocks.push(note('A forecast from the usual takings and wages, the bills due, regular payments, loans and tax dates.', 'info'));
  return { blocks };
}

const docLinks = () => {
  const out = {};
  if (!has('documents')) return out;
  for (const d of db().all("SELECT ref_uid, cloud_url FROM documents WHERE status = 'active' AND cloud_url IS NOT NULL AND ref_uid IS NOT NULL")) if (!out[d.ref_uid]) out[d.ref_uid] = d.cloud_url;
  return out;
};
const PO_STATE = { draft: 'Draft', to_approve: 'To approve', approved: 'Approved', sent: 'Sent', part: 'Part received', received: 'Received', closed: 'Closed', cancelled: 'Cancelled' };
function sPurchases(ctx) {
  if (!has('po_orders')) return { blocks: [note('No purchase orders yet.')] };
  const from = addDays(ctx.today, -ctx.cfg.days);
  const links = ctx.links;
  const rows = db().all("SELECT * FROM po_orders WHERE order_date >= ? OR status IN ('approved','sent','part','to_approve') ORDER BY order_date DESC, po_no DESC LIMIT 400", [from]).map((p) => ({
    no: p.po_no, supplier: p.supplier_name, shop: ctx.shops[p.shop_code] || p.shop_code, date: p.order_date, by: p.created_by_name || '', deliver: p.expected_date || '', total: r2(p.total),
    status: PO_STATE[p.status] || p.status, _link: links[p.uid] || null,
    _tone: ['approved', 'sent', 'part'].includes(p.status) && p.expected_date && p.expected_date < ctx.today ? 'warn' : p.status === 'cancelled' ? 'muted' : '' }));
  const open = rows.filter((r) => ['Approved', 'Sent', 'Part received', 'To approve'].includes(r.status));
  return { blocks: [
    tiles([{ label: 'Open orders', value: String(open.length), sub: `${open.filter((r) => r._tone === 'warn').length} late`, tone: open.some((r) => r._tone === 'warn') ? 'warn' : '' },
      { label: 'Ordered, not yet received', value: r2(open.reduce((a, r) => a + r.total, 0)), money: true },
      { label: `Raised in the last ${ctx.cfg.days} days`, value: String(rows.filter((r) => r.date >= from).length) }]),
    table('Purchase orders', [{ key: 'no', label: 'PO' }, { key: 'date', label: 'Date' }, { key: 'supplier', label: 'Supplier' }, { key: 'shop', label: 'Shop', filter: true }, { key: 'by', label: 'Made by' },
      { key: 'deliver', label: 'Deliver by' }, { key: 'status', label: 'Status', filter: true }, { key: 'total', label: 'Total', align: 'right', money: true }], rows, { search: true, linkLabel: 'PDF' }),
  ], badge: open.some((r) => r._tone === 'warn') ? { text: String(open.filter((r) => r._tone === 'warn').length), tone: 'warn' } : null };
}

const DUE_LABEL = { overdue: 'Overdue', due_today: 'Due today', due_soon: 'Due soon', not_due: 'Not due yet', paid: 'Paid', to_read: 'To read', credit: 'Credit note', void: 'Void' };
function sInvoices(ctx) {
  const P = safe(() => require('../modules/payables/service.js'));
  if (!P || !has('ap_invoices')) return { blocks: [note('No supplier invoices yet.')] };
  const from = addDays(ctx.today, -ctx.cfg.days);
  const recent = P.listInvoices({ filter: 'all', from, limit: 1500 }).filter((i) => i.status !== 'void');
  const unpaidOld = P.listInvoices({ filter: 'unpaid', limit: 1500 }).filter((i) => i.invoice_date < from);
  const rows = recent.concat(unpaidOld).map((i) => ({
    date: i.invoice_date, supplier: i.supplier_name, no: i.invoice_no || '', shop: ctx.shops[i.shop_code] || i.shop_code || '', total: r2(i.total), owing: r2(i.owing), dueDate: i.due_date || '',
    state: i.partPaid ? 'Part paid' : DUE_LABEL[i.due] || i.due, _link: (i.photos && i.photos[0]) || ctx.links[i.uid] || null,
    _tone: i.due === 'overdue' ? 'danger' : i.due === 'due_today' ? 'warn' : '' }));
  const overdue = rows.filter((r) => r._tone === 'danger');
  return { blocks: [
    tiles([{ label: `Received in the last ${ctx.cfg.days} days`, value: String(recent.length), sub: `${r2(recent.reduce((a, i) => a + i.total, 0)).toFixed(2)} in total` },
      { label: 'Owing to suppliers', value: ctx.owingTotal, money: true },
      { label: 'Overdue', value: r2(overdue.reduce((a, r) => a + r.owing, 0)), money: true, sub: `${overdue.length} invoice${overdue.length === 1 ? '' : 's'}`, tone: overdue.length ? 'danger' : 'ok' }]),
    table('Supplier invoices', [{ key: 'date', label: 'Date' }, { key: 'supplier', label: 'Supplier' }, { key: 'no', label: 'Invoice' }, { key: 'shop', label: 'Shop', filter: true }, { key: 'total', label: 'Total', align: 'right', money: true },
      { key: 'owing', label: 'Owing', align: 'right', money: true }, { key: 'dueDate', label: 'Due' }, { key: 'state', label: 'Status', filter: true }], rows.sort((a, b) => b.date.localeCompare(a.date)), { search: true, linkLabel: 'Photo' }),
  ], badge: overdue.length ? { text: String(overdue.length), tone: 'danger' } : null };
}

function sCheques(ctx) {
  if (!has('cheques')) return { blocks: [note('No cheques yet.')] };
  const from = addDays(ctx.today, -ctx.cfg.days);
  const cols = db().all('PRAGMA table_info(cheques)').map((c) => c.name);
  const rows = db().all("SELECT * FROM cheques WHERE cheque_date >= ? OR (status NOT IN ('void','cleared','presented') AND status IS NOT NULL) ORDER BY cheque_date DESC, cheque_no DESC LIMIT 500", [from]).map((c) => {
    const cleared = !!c.presented_date || ['cleared', 'presented'].includes(c.status);
    const handed = cols.includes('handed_date') ? c.handed_date : null;
    return { no: String(c.cheque_no), date: c.cheque_date, payee: c.payee || '', amount: r2(c.amount), handed: handed ? `${handed}${c.handed_to ? ` to ${c.handed_to}` : ''}` : '',
      state: c.status === 'void' ? 'Void / spoiled' : cleared ? `Cleared ${c.presented_date || ''}`.trim() : handed ? 'Handed over' : 'Written', by: c.written_by_name || '', _tone: c.status === 'void' ? 'muted' : '' };
  });
  const out = rows.filter((r) => !/^Cleared|^Void/.test(r.state));
  return { blocks: [
    tiles([{ label: 'Not cleared yet', value: r2(out.reduce((a, r) => a + r.amount, 0)), money: true, sub: `${out.length} cheque${out.length === 1 ? '' : 's'}` },
      { label: `Written in the last ${ctx.cfg.days} days`, value: String(rows.filter((r) => r.date >= from && r._tone !== 'muted').length) }]),
    table('Cheques', [{ key: 'no', label: 'No.' }, { key: 'date', label: 'Date' }, { key: 'payee', label: 'Paid to' }, { key: 'amount', label: 'Amount', align: 'right', money: true }, { key: 'handed', label: 'Handed over' },
      { key: 'state', label: 'Status', filter: true }, { key: 'by', label: 'Written by' }], rows, { search: true }),
  ] };
}

function sPeople(ctx) {
  const W = safe(() => require('../modules/timesheets/roster.js'));
  let on = [];
  try { on = W ? W.whoIsOn(null) : []; } catch (e) { on = []; }
  const LBL = { in: 'In', break: 'On break', late: 'Late', due: 'Due in', later: 'Starts later', finished: 'Finished' };
  const rows = on.map((x) => ({ name: x.user.name, shop: ctx.shops[x.user.shop_code] || x.user.shop_code || '', plan: x.plan ? `${x.plan.start}–${x.plan.end}` : '—', since: x.since || '', state: LBL[x.status] || x.status,
    _tone: x.status === 'late' ? 'danger' : ['in', 'break'].includes(x.state) ? 'ok' : '' }));
  const leave = has('leave_requests') ? db().all("SELECT name, type, to_date FROM leave_requests WHERE status = 'approved' AND from_date <= ? AND to_date >= ?", [ctx.today, ctx.today]) : [];
  return { blocks: [
    tiles([{ label: 'In now', value: String(rows.filter((r) => r._tone === 'ok').length), tone: 'ok' }, { label: 'Late', value: String(rows.filter((r) => r._tone === 'danger').length), tone: rows.some((r) => r._tone === 'danger') ? 'danger' : '' },
      { label: 'On leave today', value: String(leave.length) }]),
    table('Today', [{ key: 'name', label: 'Name' }, { key: 'shop', label: 'Shop', filter: true }, { key: 'plan', label: 'Rostered' }, { key: 'since', label: 'Clocked in' }, { key: 'state', label: 'Now', filter: true }], rows),
    list('On leave today', leave.map((l) => ({ text: l.name, sub: `${l.type} until ${short(l.to_date)}` })), 'Nobody on leave today.'),
  ] };
}

function sStock(ctx) {
  const I = safe(() => require('../modules/inventory/service.js'));
  if (!I || !has('inv_items')) return { blocks: [note('No products yet.')] };
  const blocks = [];
  for (const sh of Object.keys(ctx.shops)) {
    let low = [];
    try { low = I.stockList({ shopCode: sh, filter: 'low', limit: 300 }); } catch (e) { low = []; }
    if (!low.length) continue;
    blocks.push(table(`${ctx.shops[sh]} – low or out of stock`, [{ key: 'name', label: 'Product' }, { key: 'have', label: 'In stock', align: 'right' }, { key: 'min', label: 'Reorder at', align: 'right' }, { key: 'order', label: 'Suggest', align: 'right' }],
      low.map((r) => ({ name: r.name, have: r.on_hand, min: r.reorder_level ?? '', order: r.suggest || '', _tone: r.on_hand <= 0 ? 'danger' : 'warn' })), { search: true }));
  }
  if (!blocks.length) blocks.push(note('Nothing low on stock. 👍', 'ok'));
  return { blocks };
}

function sInsights(ctx) {
  const N = safe(() => require('../modules/aronium/insights.js'));
  if (!N) return { blocks: [note('No figures from the till PCs yet.')] };
  const blocks = [];
  const day = new Date(`${ctx.today}T12:00:00`).getDay();
  for (const sh of Object.keys(ctx.shops)) {
    const b = safe(() => N.busyHours({ shop: sh, today: ctx.today }));
    const d = b && b.days ? b.days[day] : null;
    if (d && d.samples && b.hours.length) {
      blocks.push(bars(`${ctx.shops[sh]} – a usual ${d.day} by the hour${d.busiest ? ` (busiest ${d.busiest.label})` : ''}`, b.labels, [{ name: `Average ${d.day}`, values: b.hours.map((h) => d.avg[h] || 0) }], { money: true }));
    }
  }
  const flagged = (safe(() => N.cashierWatch({ today: ctx.today })) || []).filter((c) => c.flags.length);
  blocks.push(list('Cashier watch (last 30 days)', flagged.map((c) => ({ text: `${c.name} (${ctx.shops[c.shop] || c.shop})`, sub: c.flags.join(' · '), tone: 'warn' })), 'No cashier stands out. 👍'));
  const p = safe(() => N.priceCheck({ today: ctx.today })) || { belowCost: [], differ: [] };
  if (p.belowCost.length) {
    blocks.push(table('Sold below cost (last 30 days)', [{ key: 'name', label: 'Product' }, { key: 'shop', label: 'Shop' }, { key: 'at', label: 'Sold at', align: 'right', money: true }, { key: 'cost', label: 'Cost', align: 'right', money: true }, { key: 'loss', label: 'Lost', align: 'right', money: true }],
      p.belowCost.map((x) => ({ name: x.name, shop: ctx.shops[x.shop] || x.shop, at: M(x.lowest), cost: M(x.cost), loss: M(x.loss), _tone: 'danger' })), { search: true }));
  }
  if (p.differ.length) blocks.push(note(`${p.differ.length} product${p.differ.length === 1 ? ' has' : 's have'} different prices on different tills – see Aronium insights in the app.`, 'warn'));
  const slow = safe(() => N.slowMovers({ days: 60 })) || [];
  if (slow.length) {
    blocks.push(table(`Slow movers – not sold for 60+ days (${slow.length})`, [{ key: 'name', label: 'Product' }, { key: 'shop', label: 'Shop' }, { key: 'have', label: 'In stock', align: 'right' }, { key: 'value', label: 'Value', align: 'right', money: true }, { key: 'last', label: 'Last sold' }],
      slow.slice(0, 100).map((x) => ({ name: x.name, shop: ctx.shops[x.shop] || x.shop, have: x.have, value: M(x.value), last: x.lastSale || 'never' })), { search: true }));
  }
  return { blocks, badge: flagged.length ? { text: String(flagged.length), tone: 'warn' } : null };
}

const BUILD = { today: sToday, sales: sSales, money: sMoney, purchases: sPurchases, invoices: sInvoices, cheques: sCheques, people: sPeople, stock: sStock, insights: sInsights };

// ---------------------------------------------------------------- the board
const cache = { at: 0, board: null, deps: [] };
// New figures came in: the next build works everything out again.
export function boardStale() { cache.at = 0; }
export function buildBoard({ force = false, today = dateStr() } = {}) {
  if (!force && cache.board && Date.now() - cache.at < 4 * 60000) { noteDeps(cache.deps); return cache.board; }
  const { value, deps } = trackReads(() => workOutBoard(today));
  cache.board = value; cache.deps = deps;
  cache.at = Date.now();
  return cache.board;
}
// 1.0.0 round 2: each figure the board is made from, and each part of it, is kept until what it read changes (and at
// most 4 minutes, as the board itself), so after a save only the parts that use it are worked out again.
function workOutBoard(today) {
  const K = (name, fn) => keepTracked(`board|${name}|${today}`, fn, { maxAgeMs: 4 * 60000 });
  // a part that could not be worked out leaves its figure empty, as before – but stepping (buildBoardAsync) goes on
  const tryK = (fn) => { try { fn(); } catch (e) { if (isStop(e)) throw e; } };
  const cfg = boardSettings();
  const base = trackReads(() => {
    const shops = K(`shops`, () => Object.fromEntries(Object.entries(shopNames()).filter(([c]) => { try { return !!db().get('SELECT 1 AS x FROM shops WHERE code = ? AND active = 1', [c]); } catch (e) { return true; } })));
    const ctx = { today, cfg, shops, links: {}, owingTotal: 0, forecast: null, sales: { rows: [], source: '' }, z: [], salesLines: [] };
    tryK(() => { ctx.links = K('links', () => docLinks()); });
    tryK(() => { ctx.sales = K('sales', () => salesByDay(addDays(today, -Math.max(cfg.days, 35)))); });
    tryK(() => {
      const L = safe(() => require('../modules/aronium/link.js'));
      if (L) { ctx.z = K('z', () => L.aroniumZByDay({ from: addDays(today, -15) })); ctx.salesLines = K('lines', () => L.aroniumSalesByDay({ from: addDays(today, -15), withLines: true })); }
    });
    // the books up to today and the loans, ahead of the forecast and the money part that read them (a part each)
    tryK(() => { const Ac = safe(() => require('../modules/accounting/service.js')); if (Ac) for (const [a, b] of Ac.entryChunks('0000-01-01', today)) K(`warm|ent|${a}|${b}`, () => { Ac.entries({ from: a, to: b }); return 1; }); });
    tryK(() => { const Ac = safe(() => require('../modules/accounting/service.js')); if (Ac) K('warm|bal', () => { Ac.balances({ to: today }); return 1; }); });
    tryK(() => { const Ac = safe(() => require('../modules/accounting/service.js')); if (Ac) K('warm|ent8', () => { Ac.entries({ from: addDays(today, -56), to: today }); return 1; }); });
    tryK(() => { const Bp = safe(() => require('../modules/bank/position.js')); if (Bp) K('warm|bankf', () => keepTracked(`stm|bankf|${today}`, () => Bp.bankForecastFigures(today), { maxAgeMs: 4 * 60000 }) && 1); });
    tryK(() => { const FL = safe(() => require('../modules/accounting/full.js')); if (FL) K('warm|loans', () => { FL.listLoans({}); return 1; }); });
    tryK(() => { const S = safe(() => require('../modules/accounting/statements.js')); ctx.forecast = S ? K('forecast', () => S.cashForecast({ weeks: 8, today })) : null; });
    tryK(() => { const P = safe(() => require('../modules/payables/service.js')); ctx.owingTotal = P && has('ap_invoices') ? K('owing', () => P.apAlerts(today).owingTotal) : 0; });
    return ctx;
  });
  const ctx = base.value;
  const sections = [];
  for (const id of cfg.order) {
    if (cfg.off.includes(id)) continue;
    const def = BOARD_SECTIONS.find((x) => x.id === id);
    if (id === 'bakery') { sections.push({ id, title: def.title, icon: def.icon, legacy: true }); continue; }
    try {
      // a part depends on what it reads and on what the shared figures above were made from
      const r = K(`s|${id}|${JSON.stringify(cfg)}`, () => { noteDeps(base.deps); return BUILD[id](ctx); });
      sections.push({ id, title: def.title, icon: def.icon, badge: r.badge || null, blocks: r.blocks });
    } catch (e) {
      if (isStop(e)) throw e;
      sections.push({ id, title: def.title, icon: def.icon, blocks: [note(`This part could not be worked out just now (${e.message || e}). The rest is up to date.`, 'warn')] });
    }
  }
  return { v: 1, at: stamp(), appVersion: APP_VERSION, days: cfg.days, sections };
}
// The same board, worked out one part at a time with a pause between (the screens keep answering meanwhile).
export async function buildBoardAsync({ today = dateStr(), pause } = {}) {
  // the owner's warnings first (a module at a time); the board's "needs attention" part then reuses them
  try { const A = require('./alerts.js'); if (!A.cachedOwnerAlerts()) await A.collectAlertsAsync(ownerView(), { today, ...(pause ? { pause } : {}) }); } catch (e) { /* worked out with the part */ }
  const v = await stepThrough(() => trackReads(() => workOutBoard(today)), pause ? { pause } : {});
  cache.board = v.value; cache.deps = v.deps; cache.at = Date.now();
  return cache.board;
}

// ---------------------------------------------------------------- which device sends the dashboard
// The cloud keeps one dashboard copy, so one device sends it: the bakery tablet (it alone holds the live bakery
// figures and applies plan changes made online). If it has been quiet for 30 minutes, the main tablet (or any
// linked device, when none is chosen) takes over until it is back. Owner / admin can pick it in Admin › Online dashboard.
// It is sent every 2 minutes while a bakery shift is open, otherwise every 5 minutes.
export function dashboardSender() { return getShared('dashboard_poster', null) || null; }
const bakeryActive = (today) => { try { return !!db().get('SELECT 1 AS x FROM batches WHERE started_at >= ? LIMIT 1', [addDays(today, -7)]); } catch (e) { return false; } };
const shiftOpen = () => { try { return !!db().get("SELECT 1 AS x FROM shifts WHERE status = 'open' LIMIT 1"); } catch (e) { return false; } };
export function claimDashboard(user = null, { bakery = false, pinned } = {}) {
  require('./guard.js').requirePerm(user, 'dashboard_setup'); // 1.0.0 hardening (H1): checked inside the service (the heartbeat runs as the app's own work)
  setShared('dashboard_poster', { device: require('./core.js').deviceId(), at: stamp(), pinned: pinned === undefined ? !!user : !!pinned, bakery: !!bakery });
  if (user) audit({ user, action: 'This device now sends the online dashboard', table: 'shared_settings', recordUid: 'dashboard_poster' });
}
export function shouldSendDashboard({ isMain = false, now = Date.now(), today = dateStr(), fresh = false } = {}) {
  const C = require('./core.js');
  const me = C.deviceId();
  const p = dashboardSender();
  const ageMin = p && p.at ? (now - new Date(String(p.at).replace(' ', 'T')).getTime()) / 60000 : Infinity;
  const bakery = bakeryActive(today);
  let mine = !!p && p.device === me;
  if (!mine) {
    const gone = !p || !(ageMin <= 30);                       // the sender has been quiet for 30 minutes
    const better = !!p && bakery && !p.pinned && !p.bakery;           // the bakery tablet takes over from a stand-in
    if ((gone && (bakery || isMain || !p)) || (!gone && better) || (gone && ageMin > 120)) { require('../db/connection.js').withSystem(() => claimDashboard(null, { bakery })); mine = true; }
  } else if (ageMin > 10 || !!p.bakery !== bakery) require('../db/connection.js').withSystem(() => claimDashboard(null, { bakery, pinned: !!p.pinned })); // heartbeat (no history entry)
  if (!mine) return false;
  const last = Number(C.getSetting('dashboard_sent_ms', '0')) || 0;
  const every = fresh ? 0.5 : (shiftOpen() ? 2 : 5);
  if (now - last < every * 60000 - 5000) return false;
  C.setSetting('dashboard_sent_ms', String(now));
  return true;
}
