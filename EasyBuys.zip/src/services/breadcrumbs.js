// Breadcrumbs: the last ~30 things the app did (screens opened with their ids, taps, service calls and how long they
// took, sync, warnings and errors). Kept in memory and written to the device at most every 2 s (and when the app goes
// to the background), so after an unexpected close the report can say what was happening just before.
// Never kept: PINs, passwords, keys, tokens, secrets (anything named like that is blanked).
import { getSetting, setSetting, stamp } from './core.js';
import { withSystem } from '../db/connection.js';

export const MAX_CRUMBS = 30;
const KEY = 'last_crumbs';
const SECRET = /pin|pass|key|token|secret/i;
let ring = [];
let prev = null; // the crumbs the app had when it was last closed (read once, before this run writes its own)
let timer = null;
let dirty = false;
let lastWrite = 0;
export const crumbClock = { now: () => Date.now(), defer: (fn, ms) => { const t = setTimeout(fn, ms); try { if (t && t.unref) t.unref(); } catch (e) { /* ignore */ } return t; } };

// A screen's params for the log: ids and short plain values only; secrets blanked; objects and lists summarised.
export function redact(params, depth = 0) {
  if (params === null || params === undefined) return params;
  if (typeof params !== 'object') return typeof params === 'string' ? params.slice(0, 60) : params;
  if (Array.isArray(params)) return `[${params.length} item${params.length === 1 ? '' : 's'}]`;
  const out = {};
  let n = 0;
  for (const k of Object.keys(params)) {
    if (n++ >= 12) { out['…'] = `${Object.keys(params).length - 12} more`; break; }
    const v = params[k];
    if (SECRET.test(k)) { out[k] = '***'; continue; }
    if (typeof v === 'function') continue;
    if (v && typeof v === 'object') out[k] = depth < 1 && !Array.isArray(v) ? redact(v, depth + 1) : (Array.isArray(v) ? `[${v.length} items]` : '{…}');
    else out[k] = typeof v === 'string' ? v.slice(0, 60) : v;
  }
  return out;
}
// Words in a crumb that look like a secret value ("pin=1234", "token: abc") are blanked as well.
function clean(text) { return String(text || '').replace(/\b(pin|pass(word)?|key|token|secret)\b(\s*[:=]\s*)\S+/gi, '$1$3***').slice(0, 240); }

function previousRun() {
  if (prev === null) {
    // (the database may not be open yet: then asked again next time)
    let raw = null;
    try { raw = getSetting(KEY, '[]'); } catch (e) { return []; }
    try { const a = JSON.parse(raw || '[]'); prev = Array.isArray(a) ? a : []; } catch (e) { prev = []; }
  }
  return prev;
}
export function crumb(kind, text, extra) {
  try {
    previousRun();
    const c = { t: stamp(), k: String(kind || '').slice(0, 12), m: clean(text) };
    if (extra !== undefined) { try { const s = JSON.stringify(redact(extra)); if (s && s !== '{}') c.p = s.slice(0, 300); } catch (e) { /* ignore */ } }
    // the same thing again (a sync with nothing to do every minute, the same screen) is counted, not repeated
    const last = ring[ring.length - 1];
    const same = (x) => `${x.k}|${String(x.m).replace(/\d+ms\b/g, '')}|${x.p || ''}`;
    if (last && same(last) === same(c)) { last.t = c.t; last.m = c.m; last.n = (last.n || 1) + 1; dirty = true; schedule(); return; }
    ring.push(c);
    if (ring.length > MAX_CRUMBS) ring.splice(0, ring.length - MAX_CRUMBS);
    dirty = true;
    schedule();
  } catch (e) { /* never a second problem */ }
}
function schedule() {
  if (timer) return;
  const wait = Math.max(0, 2000 - (crumbClock.now() - lastWrite));
  timer = crumbClock.defer(() => { timer = null; flushCrumbs(); }, wait);
}
// Write now (going to the background, or an error). Written as the app's own work, so it does not count as a change.
export function flushCrumbs() {
  if (!dirty) return false;
  try {
    previousRun();
    withSystem(() => setSetting(KEY, JSON.stringify(ring)));
    dirty = false; lastWrite = crumbClock.now();
    return true;
  } catch (e) { return false; }
}
export function crumbs() { return ring.slice(); }
export function previousCrumbs() { return previousRun().slice(); }
// Plain lines, oldest → newest: "10:42:05 screen BalanceTill {"shop":"S1"}"
export function crumbLines(list, max = MAX_CRUMBS) {
  return (list || []).slice(-max).map((c) => `${String(c.t || '').slice(11, 19) || '--:--:--'} ${c.k} ${c.m}${c.p ? ' ' + c.p : ''}${c.n > 1 ? ` (×${c.n})` : ''}`);
}
// The console's warnings and errors become crumbs too (installed once by App.js).
let hooked = false;
export function hookConsole(con = (typeof console !== 'undefined' ? console : null)) {
  if (hooked || !con) return;
  hooked = true;
  for (const lvl of ['warn', 'error']) {
    const orig = con[lvl];
    if (typeof orig !== 'function') continue;
    con[lvl] = function hooked(...args) {
      try { crumb(lvl, args.map((a) => (a && a.message) ? a.message : typeof a === 'string' ? a : (() => { try { return JSON.stringify(a); } catch (e) { return String(a); } })()).join(' ')); } catch (e) { /* ignore */ }
      return orig.apply(this, args);
    };
  }
}
// tests
export function resetCrumbs({ keepPrev = false } = {}) { ring = []; if (!keepPrev) prev = null; dirty = false; lastWrite = 0; if (timer) { try { clearTimeout(timer); } catch (e) { /* ignore */ } } timer = null; }
