// Master data managed by the Admin: users, materials, products, recipes,
// shift names, production steps and standard times.
import { db } from '../db/connection.js';
import {
  AppError, r3, stamp, getSettings, nextTxnId, dateStr, timeStr, hashPassword, clock, bandIndex, uuid, deviceId, audit, getSetting, setSetting,
} from './core.js';
import { ROLES, ROLE_LABEL, actsAsOwner, can } from './access.js';

// ================= USERS & LOGIN =================
export { ROLES, ROLE_LABEL };

const MAX_FAILS = 5;
const LOCK_MS = 60000;
// v3.9: each lock in a row is longer (1, 5, 15, 30 minutes) and every lock is written to the change history, so
// someone guessing PINs is slowed right down and the owner sees it (Watchdog / Change history).
const LOCK_STEPS = [1, 2, 5, 10]; // v3.9.2 never more than 10 minutes – a long lock would stop the shop
// v1.0.x the count of wrong tries and the lock are kept in this device's settings, so closing and opening the app
// (or restarting the tablet) does not clear them. If the settings cannot be read, a copy in memory is used.
const LOCK_KEY = 'login_lock';
let memLock = { fails: 0, until: 0, rounds: 0 };
function readLock() {
  try {
    const v = JSON.parse(getSetting(LOCK_KEY, '') || 'null');
    if (v && typeof v === 'object') return { fails: Number(v.fails) || 0, until: Number(v.until) || 0, rounds: Number(v.rounds) || 0 };
  } catch (e) { /* use the copy in memory */ }
  return { ...memLock };
}
function writeLock(l) {
  memLock = { ...l };
  try { setSetting(LOCK_KEY, JSON.stringify(l)); } catch (e) { /* kept in memory until it can be saved */ }
}

export function loginLockRemaining() {
  const left = readLock().until - clock.now().getTime();
  // a lock "longer" than the longest step means the clock was moved back: cap it so the shop is never stuck
  const max = LOCK_STEPS[LOCK_STEPS.length - 1] * LOCK_MS;
  return left > 0 ? Math.ceil(Math.min(left, max) / 1000) : 0;
}
function registerResult(user) {
  const lock = readLock();
  if (user) {
    if (lock.fails || lock.rounds || lock.until) writeLock({ fails: 0, until: 0, rounds: 0 });
    return user;
  }
  lock.fails += 1;
  if (lock.fails >= MAX_FAILS) {
    lock.fails = 0;
    const mins = LOCK_STEPS[Math.min(lock.rounds, LOCK_STEPS.length - 1)];
    lock.rounds += 1;
    lock.until = clock.now().getTime() + mins * LOCK_MS;
    writeLock(lock);
    try { audit({ user: null, action: `Login locked for ${mins} min after ${MAX_FAILS} wrong PINs in a row`, table: 'users', recordUid: 'login' }); } catch (e) { /* history not ready */ }
  } else writeLock(lock);
  return null;
}
export function resetLoginLock() {
  writeLock({ fails: 0, until: 0, rounds: 0 });
}

// Every complete PIN that is tried counts: a wrong one adds to the wrong-tries count (5 in a row locks the login).
export function login(pin) {
  if (loginLockRemaining()) return null;
  const p = String(pin || '').trim();
  if (!p) return null;
  // 1.0.0 build 1: only the PIN's hash is checked (services/pins.js); PINs from before are hashed first (once).
  const P = require('./pins.js');
  require('./locked.js'); // the locked-settings guard is on from the first login
  try { P.migratePins(); } catch (e) { /* checked below with what is hashed */ }
  const u = registerResult(P.findByPin(p));
  if (u) P.noteLogin(u, p); // the cloud checks the person too (a session, platform/cloud.js)
  return u;
}

// The PIN lengths in use on this device (e.g. [4] or [4, 6]). The PIN pad uses it to know when a PIN is complete,
// without telling anyone whether a longer PIN starts with the digits typed.
export function pinLengths() {
  try {
    const l = db().all("SELECT DISTINCT substr(pin_hash, 4, 1) AS n FROM users WHERE active = 1 AND pin_hash LIKE 'p2:%' UNION SELECT DISTINCT length(pin) AS n FROM users WHERE active = 1 AND pin IS NOT NULL AND pin <> ''")
      .map((r) => Number(r.n)).filter((n) => n >= 4 && n <= 6);
    return l.length ? Array.from(new Set(l)).sort((a, b) => a - b) : [4];
  } catch (e) { return [4]; }
}

export function loginWithPassword(username, password) {
  if (loginLockRemaining()) return null;
  const u = String(username || '').trim().toLowerCase();
  if (!u || !password) return null;
  const row = db().get('SELECT * FROM users WHERE lower(username) = ? AND active = 1', [u]);
  const ok = row && row.password_hash && row.password_hash === hashPassword(u, password);
  return registerResult(ok ? row : null);
}

export function listUsers({ includeInactive = true } = {}) {
  return db().all(
    `SELECT * FROM users ${includeInactive ? '' : 'WHERE active = 1'}
     ORDER BY active DESC, CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'payroll' THEN 2 WHEN 'manager' THEN 3 WHEN 'supervisor' THEN 4 WHEN 'worker' THEN 5 ELSE 6 END, name`
  );
}
export function getUser(id) {
  return db().get('SELECT * FROM users WHERE id = ?', [id]);
}

export function getUserByUid(uid) {
  return db().get('SELECT * FROM users WHERE uid = ?', [uid]);
}

// password: leave empty to keep the existing one.
// byUser: who is making the change (for the change history and owner-only rules).
// opts.hire: a new starter made by Recruitment (someone with "recruit_manage" may add a Staff or Baker login only).
// byUser = null is the app itself (first set-up, sample logins).
export function saveUser({ id, name, pin, role, active = true, username, password, employeeNo, shopCode, phone, usesClock = true }, byUser = null, opts = {}) {
  const n = String(name || '').trim();
  let p = String(pin || '').trim();
  if (byUser) {
    const manager = can(byUser, 'staff_manage') || actsAsOwner(byUser) || ['owner', 'admin'].includes(byUser.role);
    const hiring = !!(opts && opts.hire) && !id && can(byUser, 'recruit_manage') && ['staff', 'worker'].includes(role);
    if (!manager && !hiring) throw new AppError('You are not allowed to add or change staff. Ask the owner or a manager who looks after staff.');
  }
  const u = String(username || '').trim().toLowerCase();
  const emp = String(employeeNo || '').trim().toUpperCase();
  if (!n) throw new AppError('Please enter a name.');
  const prior = id ? getUser(id) : null;
  const P = require('./pins.js');
  // left blank: keep the PIN they have (known here in plain, or only as its hash when it was set on another device)
  const keepHash = id && !p && prior && !prior.pin && P.hasPin(prior);
  if (id && !p && prior && prior.pin) p = String(prior.pin);
  if (id && !p && !keepHash) throw new AppError('This person has no PIN yet. Set a new PIN (4 to 6 digits).');
  if (!keepHash && !/^\d{4,6}$/.test(p)) throw new AppError('PIN must be 4 to 6 digits.');
  if (!ROLES.includes(role)) throw new AppError('Please choose a role.');
  // 1.0.0 build 1 (audit M7): the message does not say who has that PIN.
  if (!keepHash && P.pinTaken(p, id || 0)) throw new AppError('That PIN is already used by someone else. Choose a different PIN.');
  const newPin = !keepHash && (!prior || !P.pinMatches(p, prior));
  const pinHash = keepHash ? prior.pin_hash : newPin ? P.hashPin(p) : prior.pin_hash;
  const pinProof = newPin ? 'pending' : (prior ? prior.pin_proof || null : null);
  if (emp) {
    const ec = db().get('SELECT name FROM users WHERE upper(employee_no) = ? AND id != ?', [emp, id || 0]);
    if (ec) throw new AppError(`Employee number ${emp} is already used by ${ec.name}.`);
  }
  if (u) {
    if (!/^[a-z0-9._-]{3,30}$/.test(u)) throw new AppError('Username must be 3-30 letters or numbers (no spaces).');
    const uc = db().get('SELECT name FROM users WHERE lower(username) = ? AND id != ?', [u, id || 0]);
    if (uc) throw new AppError(`That username is already used by ${uc.name}.`);
  }
  if (password && String(password).length < 6) throw new AppError('Password must be at least 6 characters.');
  const before = id ? getUser(id) : null;
  if (id && !before) throw new AppError('User not found.');
  if (u && !password && !(before && before.password_hash && before.username && before.username.toLowerCase() === u)) {
    throw new AppError('Please set a password for this username.');
  }
  // Nobody changes their own role (that is what decides what they may do) – except the owner.
  if (byUser && before && ((byUser.uid && before.uid === byUser.uid) || (byUser.id && before.id === byUser.id)) && role !== before.role && !actsAsOwner(byUser)) {
    throw new AppError('You cannot change your own role. Ask the owner.');
  }
  // Only an Owner can make or change Owners and Admins.
  const touchesTop = role === 'owner' || role === 'admin' || (before && (before.role === 'owner' || before.role === 'admin'));
  if (byUser && touchesTop && !actsAsOwner(byUser) && !(byUser.role === 'admin' && role !== 'owner' && (!before || before.role !== 'owner'))) {
    throw new AppError('Only an Owner can add or change Owners.');
  }
  let hash = before ? before.password_hash : null;
  if (!u) hash = null;
  else if (password) hash = hashPassword(u, password);

  const now = stamp();
  if (id) {
    const wasTop = (before.role === 'admin' || before.role === 'owner') && before.active;
    const stillTop = (role === 'admin' || role === 'owner') && active;
    if (wasTop && !stillTop) {
      const admins = db().get("SELECT COUNT(*) AS c FROM users WHERE role IN ('admin','owner') AND active = 1").c;
      if (admins <= 1) throw new AppError('You cannot remove the last active Admin or Owner.');
    }
    db().run(
      `UPDATE users SET name = ?, pin = ?, pin_hash = ?, pin_proof = ?, role = ?, active = ?, username = ?, password_hash = ?, employee_no = ?, shop_code = ?, phone = ?,
       uses_clock = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE id = ?`,
      [n, p, pinHash, pinProof, role, active ? 1 : 0, u || null, hash, emp || null, shopCode || null, String(phone || '').trim() || null, usesClock ? 1 : 0, now, deviceId(), id]
    );
    const after = getUser(id);
    audit({ user: byUser, action: 'Changed staff details', table: 'users', recordUid: after.uid, before: publicUser(before), after: publicUser(after) });
    return after;
  }
  const newUid = uuid('U');
  const r = db().run(
    `INSERT INTO users (name, pin, pin_hash, pin_proof, role, active, username, password_hash, created_at, updated_at, uid, employee_no, shop_code, phone, uses_clock, updated_device, sync_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [n, p, pinHash, 'pending', role, active ? 1 : 0, u || null, hash, now, now, newUid, emp || null, shopCode || null, String(phone || '').trim() || null, usesClock ? 1 : 0, deviceId()]
  );
  const created = getUser(r.lastInsertRowId);
  audit({ user: byUser, action: 'Added staff member', table: 'users', recordUid: created.uid, after: publicUser(created) });
  return created;
}

// A user without the PIN, password or face numbers (for the change history and reports).
export function publicUser(u) {
  if (!u) return null;
  return { name: u.name, role: u.role, active: !!u.active, employee_no: u.employee_no, shop_code: u.shop_code, phone: u.phone, uses_clock: !!u.uses_clock, username: u.username };
}

// ================= MATERIALS =================
export const UNITS = ['kg', 'g', 'L', 'ml', 'pcs', 'trays', 'bags', 'packs'];
const DEFAULT_KG = { kg: 1, g: 0.001, l: 1, ml: 0.001 };
export function defaultKgPerUnit(unit) {
  const k = DEFAULT_KG[String(unit || '').toLowerCase()];
  return k === undefined ? 0 : k;
}

export function listMaterials({ includeInactive = false, stockOnly = false } = {}) {
  const where = [];
  if (!includeInactive) where.push('m.active = 1');
  if (stockOnly) where.push('m.track_stock = 1');
  return db().all(`SELECT m.*, s.name AS supplier_name FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY m.active DESC, m.name`);
}
export function getMaterial(id) {
  return db().get('SELECT m.*, s.name AS supplier_name, s.email AS supplier_email FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id WHERE m.id = ?', [id]);
}

// ================= SUPPLIERS =================
export function listSuppliers({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM suppliers ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY active DESC, name`);
}
export function getSupplier(id) {
  return db().get('SELECT * FROM suppliers WHERE id = ?', [id]);
}
export function saveSupplier({ id, name, contact, phone, email, active = true }) {
  const n = String(name || '').trim();
  if (!n) throw new AppError('Please enter the supplier name.');
  const e = String(email || '').trim();
  if (e && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new AppError('Supplier email is not a valid email address.');
  const dupe = db().get('SELECT id FROM suppliers WHERE lower(name) = lower(?) AND id != ?', [n, id || 0]);
  if (dupe) throw new AppError(`A supplier called "${n}" already exists.`);
  const vals = [n, String(contact || '').trim() || null, String(phone || '').trim() || null, e || null, active ? 1 : 0, stamp()];
  if (id) {
    db().run("UPDATE suppliers SET name = ?, contact = ?, phone = ?, email = ?, active = ?, updated_at = ?, sync_status = 'pending' WHERE id = ?", vals.concat([id]));
    return getSupplier(id);
  }
  return getSupplier(db().run('INSERT INTO suppliers (name, contact, phone, email, active, updated_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)', vals.concat([stamp()])).lastInsertRowId);
}
export function toleranceFor(material) {
  if (material && material.tolerance_pct !== null && material.tolerance_pct !== undefined) return Number(material.tolerance_pct);
  return getSettings().defaultTolerance;
}

export function saveMaterial(m, userId) {
  const { id, name, unit, code, stock, tolerance_pct, reorder_level, active = true } = m;
  const n = String(name || '').trim();
  const u = String(unit || '').trim();
  if (!n) throw new AppError('Please enter the material name.');
  if (!u) throw new AppError('Please choose a unit.');
  const dupe = db().get('SELECT id FROM materials WHERE lower(name) = lower(?) AND id != ?', [n, id || 0]);
  if (dupe) throw new AppError(`A material called "${n}" already exists.`);
  let tol = null;
  if (tolerance_pct !== null && tolerance_pct !== undefined && tolerance_pct !== '') {
    tol = Number(tolerance_pct);
    if (!Number.isFinite(tol) || tol < 0 || tol > 100) throw new AppError('Tolerance must be between 0 and 100%.');
  }
  const kg = m.kg_per_unit === null || m.kg_per_unit === undefined || m.kg_per_unit === '' ? defaultKgPerUnit(u) : Number(m.kg_per_unit);
  if (!Number.isFinite(kg) || kg < 0) throw new AppError('Weight per unit cannot be negative.');
  const track = m.track_stock === undefined ? 1 : (m.track_stock ? 1 : 0);
  const reorder = Math.max(0, r3(reorder_level || 0));
  const reorderQty = Math.max(0, r3(m.reorder_qty || 0));
  const supplierId = m.supplier_id || null;
  const c = String(code || '').trim() || null;
  const loc = getSettings().locationName;
  let cost = null;
  if (m.cost_per_unit !== null && m.cost_per_unit !== undefined && m.cost_per_unit !== '') {
    cost = Number(m.cost_per_unit);
    if (!Number.isFinite(cost) || cost < 0) throw new AppError('Price cannot be negative.');
    cost = r3(cost);
  }
  if (id) {
    const before = getMaterial(id);
    if (cost !== null && cost !== before.cost_per_unit) db().run('UPDATE materials SET cost_per_unit = ?, cost_updated_at = ? WHERE id = ?', [cost, stamp(), id]);
    db().run(
      `UPDATE materials SET name = ?, code = ?, unit = ?, kg_per_unit = ?, track_stock = ?, tolerance_pct = ?, reorder_level = ?,
       reorder_qty = ?, supplier_id = ?, active = ?, updated_at = ?, sync_status = 'pending' WHERE id = ?`,
      [n, c, u, r3(kg), track, tol, reorder, reorderQty, supplierId, active ? 1 : 0, stamp(), id]
    );
    return getMaterial(id);
  }
  const start = track ? Math.max(0, r3(stock || 0)) : 0;
  return db().transaction(() => {
    const r = db().run(
      `INSERT INTO materials (name, code, unit, kg_per_unit, track_stock, stock, tolerance_pct, reorder_level, reorder_qty, supplier_id,
         active, location, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [n, c, u, r3(kg), track, start, tol, reorder, reorderQty, supplierId, active ? 1 : 0, loc, stamp(), stamp()]
    );
    if (cost !== null) db().run('UPDATE materials SET cost_per_unit = ?, cost_updated_at = ? WHERE id = ?', [cost, stamp(), r.lastInsertRowId]);
    if (start > 0 && userId) {
      db().run(
        `INSERT INTO transactions (txn_id, type, location, shift_id, user_id, material_id, qty, note, txn_date, txn_time, created_at)
         VALUES (?, 'ADJUST', ?, NULL, ?, ?, ?, ?, ?, ?, ?)`,
        [nextTxnId(), loc, userId, r.lastInsertRowId, start, 'Starting stock (new material)', dateStr(), timeStr(), stamp()]
      );
    }
    return getMaterial(r.lastInsertRowId);
  });
}

// ================= SHIFT NAMES =================
export function listShiftNames({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM shift_names ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort, id`);
}
export function saveShiftNames(items) {
  const clean = (items || []).map((s, i) => ({ id: s.id, name: String(s.name || '').trim(), active: s.active !== false, sort: i }));
  if (clean.some((s) => !s.name)) throw new AppError('Shift names cannot be empty.');
  const names = clean.filter((s) => s.active).map((s) => s.name.toLowerCase());
  if (new Set(names).size !== names.length) throw new AppError('Two shifts have the same name.');
  if (!names.length) throw new AppError('Keep at least one active shift name.');
  db().transaction(() => {
    const keep = [];
    for (const s of clean) {
      if (s.id) {
        db().run('UPDATE shift_names SET name = ?, sort = ?, active = ? WHERE id = ?', [s.name, s.sort, s.active ? 1 : 0, s.id]);
        keep.push(s.id);
      } else {
        keep.push(db().run('INSERT INTO shift_names (name, sort, active) VALUES (?, ?, ?)', [s.name, s.sort, s.active ? 1 : 0]).lastInsertRowId);
      }
    }
    // Names no longer listed are deactivated (old shifts keep their name text).
    db().run(`UPDATE shift_names SET active = 0 WHERE id NOT IN (${keep.map(() => '?').join(',') || '0'})`, keep);
  });
  return listShiftNames();
}

// ================= PRODUCTION STEPS =================
export const MIXING = { id: 0, name: 'Mixing', kind: 'mix' };

export function listSteps({ includeInactive = false } = {}) {
  return db().all(`SELECT * FROM steps ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort, id`);
}
export function saveSteps(items) {
  const clean = (items || []).map((s, i) => ({
    id: s.id, name: String(s.name || '').trim(), kind: ['cut', 'bake'].includes(s.kind) ? s.kind : 'normal', active: s.active !== false, sort: i,
  }));
  if (clean.some((s) => !s.name)) throw new AppError('Step names cannot be empty.');
  const act = clean.filter((s) => s.active);
  if (new Set(act.map((s) => s.name.toLowerCase())).size !== act.length) throw new AppError('Two steps have the same name.');
  if (act.filter((s) => s.kind === 'cut').length > 1) throw new AppError('Only one step can be the cutting step.');
  if (act.filter((s) => s.kind === 'bake').length > 1) throw new AppError('Only one step can be the baking step.');
  db().transaction(() => {
    const keep = [];
    for (const s of clean) {
      if (s.id) {
        db().run('UPDATE steps SET name = ?, kind = ?, sort = ?, active = ? WHERE id = ?', [s.name, s.kind, s.sort, s.active ? 1 : 0, s.id]);
        keep.push(s.id);
      } else {
        keep.push(db().run('INSERT INTO steps (name, kind, sort, active) VALUES (?, ?, ?, ?)', [s.name, s.kind, s.sort, s.active ? 1 : 0]).lastInsertRowId);
      }
    }
    db().run(`UPDATE steps SET active = 0 WHERE id NOT IN (${keep.map(() => '?').join(',') || '0'})`, keep);
  });
  return listSteps();
}

// Standard minutes per step and flour band: { [stepId]: [band0, band1, ...] } (null = not set). stepId 0 = mixing.
export function getProductStepTimes(productId) {
  const n = getSettings().flourBands.length + 1;
  const out = {};
  db().all('SELECT step_id, band, minutes FROM product_steps WHERE product_id = ?', [productId]).forEach((r) => {
    if (!out[r.step_id]) out[r.step_id] = Array(n).fill(null);
    if (r.band < n) out[r.step_id][r.band] = r.minutes;
  });
  return out;
}
// Picks the minutes for a band; if that band is empty, uses the nearest band that has a value.
export function minutesForBand(list, band) {
  if (!list) return null;
  if (list[band] !== null && list[band] !== undefined) return list[band];
  for (let d = 1; d < list.length; d++) {
    if (list[band - d] !== null && list[band - d] !== undefined) return list[band - d];
    if (list[band + d] !== null && list[band + d] !== undefined) return list[band + d];
  }
  return null;
}
// Steps a product goes through for a given amount of flour (mixing first).
// A step with no time in any band is skipped for that product.
export function getProductRoute(productId, flourKg = 0) {
  const times = getProductStepTimes(productId);
  const band = bandIndex(flourKg, getSettings().flourBands);
  const route = [{ ...MIXING, minutes: minutesForBand(times[0], band) }];
  for (const s of listSteps()) {
    const m = minutesForBand(times[s.id], band);
    if (m === null) continue;
    route.push({ id: s.id, name: s.name, kind: s.kind, minutes: m });
  }
  return route;
}

// ================= PRODUCTS =================
export function listProducts({ includeInactive = false } = {}) {
  return db().all(
    `SELECT p.*, (SELECT COUNT(*) FROM recipes r WHERE r.product_id = p.id) AS recipe_count,
       f.name AS flour_name
     FROM products p LEFT JOIN materials f ON f.id = p.flour_material_id
     ${includeInactive ? '' : 'WHERE p.active = 1'} ORDER BY p.active DESC, p.name`
  );
}
export function getProduct(id) {
  return db().get(
    `SELECT p.*, f.name AS flour_name, f.unit AS flour_unit FROM products p LEFT JOIN materials f ON f.id = p.flour_material_id WHERE p.id = ?`,
    [id]
  );
}

export function flagPctFor(product, recipeRow) {
  if (recipeRow && recipeRow.flag_pct !== null && recipeRow.flag_pct !== undefined) return Number(recipeRow.flag_pct);
  if (product && product.flag_pct !== null && product.flag_pct !== undefined) return Number(product.flag_pct);
  return getSettings().defaultFlagPct;
}

function num(v, label, { min = 0, allowNull = false } = {}) {
  if (v === null || v === undefined || v === '') {
    if (allowNull) return null;
    throw new AppError(`Please enter ${label}.`);
  }
  const n = Number(v);
  if (!Number.isFinite(n) || n < min) throw new AppError(`${label[0].toUpperCase() + label.slice(1)} cannot be less than ${min}.`);
  return r3(n);
}

export function getProductDecks(productId) {
  const temps = {};
  db().all('SELECT deck, top_c, bottom_c FROM product_decks WHERE product_id = ?', [productId]).forEach((r) => { temps[r.deck] = r; });
  return getSettings().decks.map((d) => ({ deck: d, top: temps[d] ? temps[d].top_c : null, bottom: temps[d] ? temps[d].bottom_c : null }));
}
// Decks that have at least one temperature set for this product.
export function getProductDecksSet(productId) {
  return getProductDecks(productId).filter((d) => d.top !== null || d.bottom !== null);
}

// Save product, recipe (baker's %), step times and oven deck temperatures together.
// recipe: [{ material_id, pct, flag_pct }]  stepTimes: { [stepId]: minutes|null }  decks: { [deckName]: { top: °C|null, bottom: °C|null } }
export function saveProductFull(p, recipe, stepTimes, decks = {}) {
  const n = String(p.name || '').trim();
  const u = String(p.unit || '').trim();
  if (!n) throw new AppError('Please enter the product name.');
  if (!u) throw new AppError('Please enter the unit (e.g. loaves, pcs).');
  const dupe = db().get('SELECT id FROM products WHERE lower(name) = lower(?) AND id != ?', [n, p.id || 0]);
  if (dupe) throw new AppError(`A product called "${n}" already exists.`);
  const flour = getMaterial(p.flour_material_id);
  if (!flour) throw new AppError('Choose which material is the flour for this product.');
  const cut = num(p.cut_weight_g, 'the cutting weight (grams)', { min: 1 });
  const cutTol = num(p.cut_tolerance_g || 0, 'the cutting allowance');
  const maxFlour = num(p.max_flour_kg, 'the maximum flour per batch (kg)', { min: 0.1 });
  const defFlour = num(p.default_flour_kg || 0, 'the usual flour amount');
  if (defFlour > maxFlour) throw new AppError('The usual flour amount cannot be more than the machine maximum.');
  const flag = num(p.flag_pct, 'the flag percentage', { allowNull: true });
  if (flag !== null && flag > 100) throw new AppError('Flag percentage cannot be more than 100.');

  const seen = new Set([p.flour_material_id]);
  const rows = [];
  for (const it of recipe || []) {
    if (!it.material_id) continue;
    if (seen.has(it.material_id)) {
      const m = getMaterial(it.material_id);
      throw new AppError(`${m ? m.name : 'A material'} is listed twice (flour is added automatically).`);
    }
    seen.add(it.material_id);
    const m = getMaterial(it.material_id);
    const pct = Number(it.pct);
    if (it.pct === null || it.pct === '' || !Number.isFinite(pct) || pct <= 0) throw new AppError(`Enter a percentage above 0 for ${m ? m.name : 'each ingredient'}.`);
    const f = it.flag_pct === null || it.flag_pct === undefined || it.flag_pct === '' ? null : Number(it.flag_pct);
    rows.push({ material_id: it.material_id, pct: r3(pct), flag_pct: f });
  }
  const nBands = getSettings().flourBands.length + 1;
  const times = {};
  for (const [k, v] of Object.entries(stepTimes || {})) {
    const list = Array.isArray(v) ? v : Array(nBands).fill(v);
    times[k] = list.slice(0, nBands).map((x) => {
      if (x === null || x === undefined || x === '') return null;
      const mins = Number(x);
      if (!Number.isFinite(mins) || mins < 0 || mins > 24 * 60) throw new AppError('Step times must be between 0 and 1440 minutes.');
      return r3(mins);
    });
  }

  const deckTemps = {};
  const tempOf = (v, label) => {
    if (v === null || v === undefined || v === '') return null;
    const t = Number(v);
    if (!Number.isFinite(t) || t < 0 || t > 400) throw new AppError(`${label} temperature must be between 0 and 400°C.`);
    return r3(t);
  };
  for (const [k, v] of Object.entries(decks || {})) {
    const o = v !== null && typeof v === 'object' ? v : { top: v, bottom: null };
    const top = tempOf(o.top, `${k} top`);
    const bottom = tempOf(o.bottom, `${k} bottom`);
    if (top !== null || bottom !== null) deckTemps[k] = { top, bottom };
  }
  const prep = String(p.prep_note || '').trim() || null;
  return db().transaction(() => {
    let id = p.id;
    const vals = [n, String(p.code || '').trim() || null, u, p.flour_material_id, cut, cutTol, maxFlour, defFlour, flag, p.active === false ? 0 : 1, stamp()];
    if (id) {
      db().run(
        `UPDATE products SET name = ?, code = ?, unit = ?, flour_material_id = ?, cut_weight_g = ?, cut_tolerance_g = ?, max_flour_kg = ?,
         default_flour_kg = ?, flag_pct = ?, active = ?, updated_at = ?, sync_status = 'pending' WHERE id = ?`,
        vals.concat([id])
      );
    } else {
      id = db().run(
        `INSERT INTO products (name, code, unit, flour_material_id, cut_weight_g, cut_tolerance_g, max_flour_kg, default_flour_kg, flag_pct, active, updated_at, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        vals.concat([stamp()])
      ).lastInsertRowId;
    }
    db().run('DELETE FROM recipes WHERE product_id = ?', [id]);
    for (const r of rows) {
      db().run('INSERT INTO recipes (product_id, material_id, pct, flag_pct, updated_at) VALUES (?, ?, ?, ?, ?)', [id, r.material_id, r.pct, r.flag_pct, stamp()]);
    }
    db().run('UPDATE products SET prep_note = ? WHERE id = ?', [prep, id]);
    db().run('DELETE FROM product_decks WHERE product_id = ?', [id]);
    for (const [k, v] of Object.entries(deckTemps)) db().run('INSERT INTO product_decks (product_id, deck, top_c, bottom_c) VALUES (?, ?, ?, ?)', [id, k, v.top, v.bottom]);
    db().run('DELETE FROM product_steps WHERE product_id = ?', [id]);
    for (const [k, list] of Object.entries(times)) {
      list.forEach((v, band) => {
        if (v === null) return;
        db().run('INSERT INTO product_steps (product_id, step_id, band, minutes) VALUES (?, ?, ?, ?)', [id, Number(k), band, v]);
      });
    }
    return getProduct(id);
  });
}

export function getRecipe(productId) {
  return db().all(
    `SELECT r.material_id, r.pct, r.flag_pct, m.name, m.unit, m.kg_per_unit, m.track_stock
     FROM recipes r JOIN materials m ON m.id = r.material_id WHERE r.product_id = ? ORDER BY r.pct DESC, m.name`,
    [productId]
  );
}

// Sensible +/- step for a unit of measure.
export function stepFor(unit) {
  const u = String(unit || '').toLowerCase();
  if (u === 'kg' || u === 'l') return 0.1;
  if (u === 'g' || u === 'ml') return 10;
  return 1;
}
