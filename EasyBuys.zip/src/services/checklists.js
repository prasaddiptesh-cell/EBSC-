// Checklists built by the Admin: cleaning, opening checks, temperature logs.
//   when_due: 'start' (start of shift), 'end' (must be finished before sign-off / closing), 'daily' (once a day)
//   scope:    'person' (each baker does their own) or 'shift' (done once, by anyone)
import { db } from '../db/connection.js';
import { AppError, stamp, dateStr, r1 } from './core.js';
import { raiseAlert } from './stock.js';

export const WHEN_LABEL = { start: 'Start of shift', end: 'End of shift (before signing off)', daily: 'Once a day' };
export const SCOPE_LABEL = { person: 'Each baker does their own', shift: 'Once per shift (anyone)' };
export const KIND_LABEL = { tick: 'Tick box', temp: 'Temperature reading', photo: 'Photo' };

// ---------------- setup (Admin) ----------------
export function listChecklists({ includeInactive = false } = {}) {
  return db().all(`SELECT c.*, (SELECT COUNT(*) FROM checklist_items i WHERE i.checklist_id = c.id AND i.active = 1) AS item_count
    FROM checklists c ${includeInactive ? '' : 'WHERE c.active = 1'} ORDER BY c.active DESC, c.sort, c.id`);
}
export function getChecklist(id) {
  const c = db().get('SELECT * FROM checklists WHERE id = ?', [id]);
  if (!c) return null;
  return { ...c, items: db().all('SELECT * FROM checklist_items WHERE checklist_id = ? AND active = 1 ORDER BY sort, id', [id]) };
}
export function saveChecklist({ id, name, when_due, scope, active = true }, items) {
  const n = String(name || '').trim();
  if (!n) throw new AppError('Please enter the checklist name.');
  if (!WHEN_LABEL[when_due]) throw new AppError('Choose when the checklist is done.');
  if (!SCOPE_LABEL[scope]) throw new AppError('Choose who does the checklist.');
  const clean = (items || []).map((it, i) => ({ ...it, name: String(it.name || '').trim(), sort: i }));
  if (!clean.length) throw new AppError('Add at least one item.');
  for (const it of clean) {
    if (!it.name) throw new AppError('Every item needs a name.');
    if (!KIND_LABEL[it.kind]) throw new AppError(`Choose the type for "${it.name}".`);
    if (it.kind === 'temp') {
      const lo = Number(it.min_value);
      const hi = Number(it.max_value);
      if (it.min_value === null || it.min_value === '' || it.max_value === null || it.max_value === '' || !Number.isFinite(lo) || !Number.isFinite(hi) || lo > hi) {
        throw new AppError(`Enter a valid temperature range for "${it.name}" (lowest first).`);
      }
    }
  }
  return db().transaction(() => {
    let cid = id;
    if (cid) db().run('UPDATE checklists SET name = ?, when_due = ?, scope = ?, active = ? WHERE id = ?', [n, when_due, scope, active ? 1 : 0, cid]);
    else cid = db().run('INSERT INTO checklists (name, when_due, scope, active, sort) VALUES (?, ?, ?, ?, (SELECT COALESCE(MAX(sort),0)+1 FROM checklists))', [n, when_due, scope, active ? 1 : 0]).lastInsertRowId;
    const keep = [];
    for (const it of clean) {
      const vals = [it.name, it.kind, it.kind === 'temp' ? Number(it.min_value) : null, it.kind === 'temp' ? Number(it.max_value) : null, it.sort];
      if (it.id) {
        db().run('UPDATE checklist_items SET name = ?, kind = ?, min_value = ?, max_value = ?, sort = ?, active = 1 WHERE id = ? AND checklist_id = ?', vals.concat([it.id, cid]));
        keep.push(it.id);
      } else {
        keep.push(db().run('INSERT INTO checklist_items (name, kind, min_value, max_value, sort, checklist_id) VALUES (?, ?, ?, ?, ?, ?)', vals.concat([cid])).lastInsertRowId);
      }
    }
    db().run(`UPDATE checklist_items SET active = 0 WHERE checklist_id = ? AND id NOT IN (${keep.map(() => '?').join(',')})`, [cid].concat(keep));
    return getChecklist(cid);
  });
}

// ---------------- runs ----------------
function openShiftRow() {
  return db().get("SELECT * FROM shifts WHERE status = 'open' ORDER BY id DESC LIMIT 1");
}

// Finds (or creates) the run for this checklist for the given shift/person/day.
function runFor(list, shiftId, userId) {
  const day = dateStr();
  let row;
  if (list.when_due === 'daily') {
    row = db().get(`SELECT * FROM checklist_runs WHERE checklist_id = ? AND run_date = ? ${list.scope === 'person' ? 'AND user_id = ?' : ''}`,
      list.scope === 'person' ? [list.id, day, userId] : [list.id, day]);
  } else {
    row = db().get(`SELECT * FROM checklist_runs WHERE checklist_id = ? AND shift_id = ? ${list.scope === 'person' ? 'AND user_id = ?' : ''}`,
      list.scope === 'person' ? [list.id, shiftId, userId] : [list.id, shiftId]);
  }
  return row;
}
function ensureRun(list, shiftId, userId) {
  const r = runFor(list, shiftId, userId);
  if (r) return r;
  const id = db().run('INSERT INTO checklist_runs (checklist_id, shift_id, user_id, run_date, created_at) VALUES (?, ?, ?, ?, ?)',
    [list.id, shiftId || null, list.scope === 'person' ? userId : null, dateStr(), stamp()]).lastInsertRowId;
  return db().get('SELECT * FROM checklist_runs WHERE id = ?', [id]);
}

function progress(list, run) {
  const items = db().all('SELECT id FROM checklist_items WHERE checklist_id = ? AND active = 1', [list.id]);
  const entries = run ? db().all('SELECT item_id FROM checklist_entries WHERE run_id = ?', [run.id]).map((e) => e.item_id) : [];
  const left = items.filter((i) => !entries.includes(i.id)).length;
  return { total: items.length, done: items.length - left, left };
}

// Checklists for a person on the open shift (with progress), for their home screen.
export function myChecklists(userId) {
  const s = openShiftRow();
  if (!s) return [];
  return listChecklists().filter((c) => c.item_count > 0).map((c) => {
    const run = runFor(c, s.id, userId);
    return { ...c, run_id: run ? run.id : null, ...progress(c, run), shift_id: s.id };
  });
}

// Opens a checklist for filling in: items with any answers already given.
export function openRun(checklistId, userId) {
  const s = openShiftRow();
  const list = getChecklist(checklistId);
  if (!list) throw new AppError('Checklist not found.');
  if (!s && list.when_due !== 'daily') throw new AppError('There is no open shift.');
  const run = ensureRun(list, s ? s.id : null, userId);
  const entries = db().all(
    'SELECT e.*, u.name AS user_name FROM checklist_entries e JOIN users u ON u.id = e.user_id WHERE e.run_id = ?', [run.id]
  );
  const byItem = {};
  entries.forEach((e) => { byItem[e.item_id] = e; });
  return { list, run, items: list.items.map((it) => ({ ...it, entry: byItem[it.id] || null })) };
}

// Record one item. answer: { done:true } | { value: number } | { photo: uri } | { skipped:true, note }
export function answerItem(runId, itemId, userId, answer) {
  const run = db().get('SELECT * FROM checklist_runs WHERE id = ?', [runId]);
  const item = db().get('SELECT * FROM checklist_items WHERE id = ?', [itemId]);
  if (!run || !item) throw new AppError('Checklist item not found.');
  const list = db().get('SELECT * FROM checklists WHERE id = ?', [run.checklist_id]);
  let status = 'done';
  let value = null;
  let out = 0;
  let note = answer.note ? String(answer.note).trim() : null;
  let photo = null;
  if (answer.skipped) {
    if (!note) throw new AppError('Please give a reason for skipping this item.');
    status = 'skipped';
  } else if (item.kind === 'temp') {
    value = Number(answer.value);
    if (answer.value === null || answer.value === undefined || answer.value === '' || !Number.isFinite(value)) throw new AppError('Enter the temperature.');
    value = r1(value);
    out = value < item.min_value || value > item.max_value ? 1 : 0;
  } else if (item.kind === 'photo') {
    if (!answer.photo) throw new AppError('Take a photo for this item.');
    photo = answer.photo;
  }
  db().transaction(() => {
    db().run(`INSERT INTO checklist_entries (run_id, item_id, status, value, out_of_range, note, photo, user_id, at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(run_id, item_id) DO UPDATE SET status = excluded.status, value = excluded.value, out_of_range = excluded.out_of_range,
      note = excluded.note, photo = excluded.photo, user_id = excluded.user_id, at = excluded.at`,
      [runId, itemId, status, value, out, note, photo, userId, stamp()]);
    const u = db().get('SELECT name FROM users WHERE id = ?', [userId]);
    if (out) {
      raiseAlert({ type: 'TEMP', severity: 'bad', shiftId: run.shift_id, userId,
        message: `${item.name}: ${value}°C is outside the safe range ${item.min_value} to ${item.max_value}°C (${list.name}, ${u.name}).${note ? ` Note: ${note}` : ''}` });
    }
    if (status === 'skipped') {
      raiseAlert({ type: 'CHECK_SKIP', severity: 'info', shiftId: run.shift_id, userId, message: `${u.name} skipped "${item.name}" (${list.name}): ${note}` });
    }
    const p = progress(list, run);
    db().run('UPDATE checklist_runs SET completed_at = ? WHERE id = ?', [p.left === 0 ? stamp() : null, runId]);
  });
  return { out_of_range: !!out };
}

// End-of-shift personal checklists not yet finished (block that person's sign-off).
export function signOffBlockers(shiftId, userId) {
  return listChecklists().filter((c) => c.when_due === 'end' && c.scope === 'person' && c.item_count > 0).map((c) => {
    const run = db().get('SELECT * FROM checklist_runs WHERE checklist_id = ? AND shift_id = ? AND user_id = ?', [c.id, shiftId, userId]);
    return { name: c.name, ...progress(c, run) };
  }).filter((x) => x.left > 0);
}
// End-of-shift shared checklists not yet finished (block closing the shift).
export function shiftCloseBlockers(shiftId) {
  return listChecklists().filter((c) => c.when_due === 'end' && c.scope === 'shift' && c.item_count > 0).map((c) => {
    const run = db().get('SELECT * FROM checklist_runs WHERE checklist_id = ? AND shift_id = ?', [c.id, shiftId]);
    return { name: c.name, ...progress(c, run) };
  }).filter((x) => x.left > 0);
}

// Everything recorded for a shift (and daily lists done that day), for reports.
export function shiftChecklistRows(shiftId) {
  const s = db().get('SELECT shift_date FROM shifts WHERE id = ?', [shiftId]);
  if (!s) return [];
  return db().all(
    `SELECT c.name AS list, i.name AS item, i.kind, i.min_value, i.max_value, e.status, e.value, e.out_of_range, e.note, e.at, u.name AS user_name, ru.name AS run_user
     FROM checklist_runs r JOIN checklists c ON c.id = r.checklist_id JOIN checklist_items i ON i.checklist_id = c.id AND i.active = 1
     LEFT JOIN checklist_entries e ON e.run_id = r.id AND e.item_id = i.id LEFT JOIN users u ON u.id = e.user_id LEFT JOIN users ru ON ru.id = r.user_id
     WHERE r.shift_id = ? OR (r.shift_id IS NULL AND r.run_date = ?) ORDER BY c.sort, r.id, i.sort`, [shiftId, s.shift_date]
  );
}
