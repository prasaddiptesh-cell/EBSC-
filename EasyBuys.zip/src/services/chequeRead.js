// 1.0.0 build 31 (owner, 10 Nov: "there is no AI reading for cheque, come on"): a photo of a cheque read by the AI in the
// owner's cloud (cloud/Code.gs invoice_ai with hints.paper = 'cheque', script 32) – the cheque number, the amount, who
// it is made out to and the date; offline, the phone's text reading finds what it can. Every figure is a suggestion:
// the screen lists it and the person ticks that they checked it against the cheque (ui/paperPhoto.js).
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const digits = (v) => String(v === null || v === undefined ? '' : v).replace(/\D/g, '').replace(/^0+(?=\d)/, '');

// The best supplier for the name on the cheque (exact, then one name inside the other).
export function payeeSupplier(payee, suppliers = []) {
  const p = String(payee || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  if (p.length < 3) return null;
  const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  return suppliers.find((s) => norm(s.name) === p)
    || suppliers.find((s) => norm(s.name).length >= 3 && (p.includes(norm(s.name)) || norm(s.name).includes(p))) || null;
}

// The AI's answer → { fields: { chequeNo, amount, payee, date, bank, supplierUid }, checks, found }
export function chequeFields(ai, ctx = {}) {
  const f = {}; const checks = [];
  if (!ai || typeof ai !== 'object') return { fields: f, checks, found: 0 };
  const no = digits(ai.cheque_no);
  if (no && no.length <= 10) f.chequeNo = no;
  const amt = Number(ai.amount);
  if (amt > 0 && amt < 10000000) f.amount = r2(amt);
  if (ai.payee) f.payee = String(ai.payee).trim().slice(0, 80);
  if (DATE.test(String(ai.date || ''))) f.date = String(ai.date);
  if (ai.bank) f.bank = String(ai.bank).trim().slice(0, 40);
  const sup = f.payee ? payeeSupplier(f.payee, ctx.suppliers || []) : null;
  if (sup) f.supplierUid = sup.uid;
  const words = Number(ai.amount_words_value);
  if (f.amount && words > 0) {
    checks.push(Math.abs(words - f.amount) < 0.005
      ? { level: 'ok', key: 'words', text: `The amount in words agrees with the figures (${f.amount.toFixed(2)}).` }
      : { level: 'warn', key: 'words', text: `The amount in words (${r2(words).toFixed(2)}) is not the amount in figures (${f.amount.toFixed(2)}) – the bank pays the words. Check the cheque.` });
  }
  if (ai.signed === false) checks.push({ level: 'warn', key: 'signed', text: 'The cheque does not look signed.' });
  if (f.date && ctx.today && f.date > ctx.today) checks.push({ level: 'warn', key: 'date', text: `The cheque is dated ${f.date} – after today (post-dated).` });
  if (f.payee && !sup && (ctx.suppliers || []).length) checks.push({ level: 'warn', key: 'payee', text: `"${f.payee}" is not one of the suppliers – choose the supplier.` });
  return { fields: f, checks, found: Object.keys(f).length };
}

// Offline: the text the phone read. The serial is the first group of 6 digits in the magnetic line (or after "No").
export function chequeFromText(text) {
  const lines = String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const f = {};
  const no = lines.map((l) => (l.match(/\b(?:cheque|chq|no\.?)\s*[:#.]?\s*(\d{4,9})\b/i) || [])[1]).find(Boolean)
    || lines.slice().reverse().map((l) => (l.match(/(?:^|[^\d])(\d{6})(?:[^\d]|$)/) || [])[1]).find(Boolean);
  if (no) f.chequeNo = digits(no);
  const amts = [];
  for (const l of lines) for (const m of l.matchAll(/\$\s*([\d,]+(?:[.\-=]\d{2})?)/g)) amts.push(Number(m[1].replace(/,/g, '').replace(/[-=]/, '.')));
  const amt = amts.filter((n) => n > 0).sort((a, b) => b - a)[0];
  if (amt) f.amount = r2(amt);
  const pay = lines.map((l) => (l.match(/^pay\s+(?!the\s+sum)(.{3,60}?)(?:\s+or\s+(?:bearer|order))?$/i) || [])[1]).find(Boolean);
  if (pay) f.payee = pay.trim();
  const d = lines.map((l) => l.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/)).find(Boolean);
  if (d) { const y = d[3].length === 2 ? `20${d[3]}` : d[3]; const mm = String(d[2]).padStart(2, '0'); const dd = String(d[1]).padStart(2, '0'); if (+mm >= 1 && +mm <= 12 && +dd >= 1 && +dd <= 31) f.date = `${y}-${mm}-${dd}`; }
  return { fields: f, from: {}, checks: [], found: Object.keys(f).length };
}

// deps: { cloudCall, aiCopyBase64, fileBase64, readText (uris → { ok, text }), suppliers, today }
// → { ok, read: { fields, from, checks, found }, engine: 'ai' | 'device', label, message }
export async function readCheque(uris = [], deps = {}) {
  const list = (uris || []).filter(Boolean).slice(0, 2);
  if (!list.length) return { ok: false, message: 'Take a photo of the cheque first.' };
  const ctx = { suppliers: deps.suppliers || [], today: deps.today || '' };
  let why = '';
  try {
    const files = [];
    for (const u of list) {
      let data = null;
      try { data = deps.aiCopyBase64 ? await deps.aiCopyBase64(u) : null; } catch (e) { data = null; }
      if (!data && deps.fileBase64) data = await deps.fileBase64(u);
      if (data) files.push({ mimeType: 'image/jpeg', data });
    }
    const a = files.length ? await deps.cloudCall({ kind: 'invoice_ai', files, hints: { paper: 'cheque', suppliers: ctx.suppliers.map((s) => s.name).slice(0, 200) } }, 120000) : null;
    if (a && a.ok && a.invoice) {
      const read = chequeFields(a.invoice, ctx);
      if (read.found) return { ok: true, read: { ...read, from: {} }, engine: 'ai', label: 'Read by AI' };
      why = 'The AI could not find the figures on the cheque.';
    } else if (a && a.error) why = /NO_AI_KEY/.test(a.error) ? '' : String(a.error).replace(/^AI_ERROR:\s*/, '');
  } catch (e) { why = /network|fetch|abort|timed|internet/i.test(String(e && e.message)) ? 'No internet – read on this phone.' : String((e && e.message) || e); }
  if (deps.readText) {
    try {
      const t = await deps.readText(list);
      if (t && t.ok) {
        const read = chequeFromText(t.text);
        const sup = read.fields.payee ? payeeSupplier(read.fields.payee, ctx.suppliers) : null;
        if (sup) { read.fields.supplierUid = sup.uid; read.found += 1; }
        if (why) read.checks.push({ level: 'warn', text: why });
        if (read.found) return { ok: true, read, engine: 'device', label: 'Read on this phone' };
      }
    } catch (e) { /* nothing more to try */ }
  }
  return { ok: false, read: { fields: {}, from: {}, checks: [], found: 0 }, message: `Nothing could be read from the cheque.${why ? ` ${why}` : ''} Take the photo again flat, in good light, the whole cheque in the picture – or type the figures.` };
}
