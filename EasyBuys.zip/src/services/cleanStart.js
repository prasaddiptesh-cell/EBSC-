// 1.0.0 build 1 "Start clean" (owner only): the business starts again with an empty app – on this device, in the cloud
// and, on their next sync, on every linked device.
//  1. The owner types their PIN again (checked here AND by the cloud) and START CLEAN.
//  2. A backup of everything goes to Google Drive first (Backups › Manual); the cloud also keeps its own copy of the
//     whole data spreadsheet (Backups › Clean start). If the backup does not work, nothing is cleared.
//  3. The cloud clears its records (the owner logins stay) and moves the old Drive folders into one folder
//     "Before 1.0.0 – old and test data <date>" – no Drive file is deleted.
//  4. This device clears everything except its own link settings and the change history; the owner logins stay.
// Devices that update from an earlier build keep their data until the owner does this.
import { db, withSystem } from '../db/connection.js';
import { AppError, stamp, setSetting, getSetting, setShared, audit, uuid, dateStr } from './core.js';
import { requirePerm, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
// Kept on this device: its own settings (cloud link, device name…), the change history and the sqlite tables.
export const CLEAN_KEEP = ['settings', 'audit_log', 'sqlite_sequence'];
export const CLEAN_WORD = 'START CLEAN';
export const DRIVE_SENTENCE = 'Start clean never deletes anything in Google Drive: a full backup is made first, every old Easy Buys folder (photos, documents, reports, orders, Viber copies) is moved into one folder "Before 1.0.0 – old and test data" with the date, Backups stays where it is, and the files stay private – you can open or delete them yourself later.';

export function cleanTables() {
  return db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").map((r) => r.name).filter((t) => !CLEAN_KEEP.includes(t));
}
export function cleanSummary() {
  return cleanTables().map((t) => { let n = 0; try { n = db().get(`SELECT COUNT(*) AS n FROM "${t}"${t === 'users' ? " WHERE role <> 'owner'" : ''}`).n; } catch (e) { n = 0; } return { table: t, rows: n }; }).filter((x) => x.rows > 0);
}

// deps: { backup: async () => ({ ok }), cloud: async (body) => answer, linked } – the screen passes the cloud calls.
export async function startClean(user, { pin, typed } = {}, deps = {}) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(async () => {
  need(user && (user.role === 'owner' || user.realRole === 'owner'), 'Only the owner can start clean.');
  need(String(typed || '').trim().toUpperCase() === CLEAN_WORD, `Type ${CLEAN_WORD} to confirm.`);
  const P = require('./pins.js');
  const me = db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [user.uid]);
  if (!me || !P.pinMatches(pin, me)) {
    withSystem(() => audit({ user, action: 'Start clean refused: wrong PIN', table: 'settings' }));
    throw new AppError('Wrong PIN – nothing was cleared.');
  }
  const linked = deps.linked !== undefined ? deps.linked : !!getSetting('cloud_url', '');
  need(linked && deps.backup && deps.cloud, 'Link this device to the Easy Buys cloud first – the backup must go to Google Drive before anything is cleared.');
  const at = stamp();
  const id = uuid('CLEAN-');
  // 1. the backup in Google Drive (and the cloud's own copy, made by clean_start below)
  let b = null;
  try { b = await deps.backup({ fileName: `clean-start-backup-${dateStr()}-${at.slice(11, 16).replace(':', '')}.json` }); } catch (e) { b = { ok: false, error: e && e.message }; }
  need(b && b.ok !== false, `The backup to Google Drive did not work, so nothing was cleared. ${b && b.error ? b.error : 'Check the internet and try again.'}`);
  // 2. the cloud (checks the owner's PIN itself)
  const r = await deps.cloud({ kind: 'clean_start', ownerUid: user.uid, proof: P.pinProof(pin, user.uid), id, at, by: user.name });
  need(r && r.ok, (r && r.error) || 'The cloud could not be cleared (paste the new cloud script first – see CLOUD-SETUP.md). Nothing was cleared here.');
  // 3. this device (the app's own work now – the owner was checked above)
  const tables = cleanTables();
  let removed = 0;
  withSystem(() => {
    db().exec('PRAGMA foreign_keys = OFF;');
    try {
      db().transaction(() => {
        for (const t of tables) {
          try {
            const where = t === 'users' ? " WHERE role <> 'owner'" : '';
            removed += db().get(`SELECT COUNT(*) AS n FROM "${t}"${where}`).n;
            db().run(`DELETE FROM "${t}"${where}`);
          } catch (e) { /* a table this device does not have */ }
        }
      });
    } finally { db().exec('PRAGMA foreign_keys = ON;'); }
    const marker = { id, at, tables: tables.filter((t) => t !== 'users'), groups: ['activity', 'staff', 'suppliers', 'products', 'setup', 'settings'], by: user.name, clean: true };
    setShared('fresh_start', marker);
    setShared('clean_start', { id, at, by: user.name, backup: b && b.id ? b.id : null, cloudCopy: r.copyId || null, oldFolder: r.oldFolder || null });
    setSetting('fresh_applied', id);
    setSetting('clean_start_done', at);
    try { require('../db/seedV3.js').seedEasyBuys(); } catch (e) { /* made again on the next start */ }
    audit({ user, action: `Start clean: ${removed} records cleared on this device, ${r.cleared || 0} in the cloud (backup in Google Drive first)`, table: 'settings', after: { cloudCopy: r.copyId || null, oldFolder: r.oldFolder || null } });
  });
  try { require('./locked.js').lockAll(); } catch (e) { /* none */ }
  return { id, at, removed, cloud: r };
  });
}
