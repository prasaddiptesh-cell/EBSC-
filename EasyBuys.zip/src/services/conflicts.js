// v3.9 Two devices, one business: things that can only go wrong when two tablets (or a phone) work offline and sync
// later. Each check looks at the shared records after syncing and lists what a person must look at. Nothing is
// changed here – the warning says what happened and where to fix it (void the extra payment, cheque, count…).
import { db } from '../db/connection.js';
import { money } from './core.js';

const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const $ = (n) => money(Math.round((Number(n) || 0) * 100) / 100);

export function syncConflicts() {
  const out = [];
  const add = (kind, text, nav, sub) => out.push({ kind, text, nav, sub });
  try {
    // Invoices paid more than their total (paid on two devices).
    if (has('ap_allocations')) {
      db().all(`SELECT i.uid, i.invoice_no, i.supplier_name, i.total, SUM(a.amount) AS paid, COUNT(DISTINCT p.uid) AS n FROM ap_invoices i JOIN ap_allocations a ON a.invoice_uid = i.uid
        JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE i.status <> 'void' AND i.kind = 'invoice' GROUP BY i.uid HAVING paid > i.total + 0.004`)
        .forEach((r) => add('paid_twice', `Invoice ${r.invoice_no || '(no number)'} from ${r.supplier_name} is paid ${$(r.paid)} – more than its total ${$(r.total)} (${r.n} payments)`, { screen: 'ApInvoice', params: { uid: r.uid } }, 'Paid on two devices? Void the extra payment, or keep it as credit with the supplier.'));
    }
    // The same cheque number used twice in one account.
    if (has('cheques')) {
      db().all("SELECT account_uid, cheque_no, COUNT(*) AS n, GROUP_CONCAT(COALESCE(payee,''), ' / ') AS payees FROM cheques WHERE status <> 'void' GROUP BY account_uid, cheque_no HAVING n > 1")
        .forEach((r) => add('cheque_twice', `Cheque ${r.cheque_no} is recorded ${r.n} times (${r.payees})`, { screen: 'Cheques', params: { tab: 'register' } }, 'One leaf can only be one cheque: void the wrong one and record the payment with the right cheque number.'));
    }
    // The same till, day and shift counted twice (the sales would count twice).
    if (has('till_counts')) {
      db().all("SELECT till_uid, shift_date, shift, shop_code, COUNT(*) AS n FROM till_counts WHERE status <> 'void' GROUP BY till_uid, shift_date, shift HAVING n > 1")
        .forEach((r) => add('till_twice', `${r.shop_code}: the ${r.shift} till on ${r.shift_date} was counted ${r.n} times`, { screen: 'Till', params: {} }, 'The sales would be counted twice – void the extra count.'));
    }
    // The same pay week run twice.
    if (has('pay_runs')) {
      db().all("SELECT week_start, COUNT(*) AS n FROM pay_runs WHERE status <> 'void' AND IFNULL(run_kind,'regular') = 'regular' GROUP BY week_start HAVING n > 1")
        .forEach((r) => add('payrun_twice', `${r.n} pay runs for the week starting ${r.week_start}`, { screen: 'Payroll', params: {} }, 'Staff would be paid twice – void the extra pay run before anyone is paid.'));
    }
    // An order received on two devices (more received than ordered, from more than one delivery).
    if (has('inv_receipts') && has('po_lines')) {
      db().all(`SELECT o.uid, o.po_no, l.name, l.qty, l.qty_received, (SELECT COUNT(*) FROM inv_receipts r WHERE r.po_uid = o.uid AND r.status = 'active') AS deliveries
        FROM po_lines l JOIN po_orders o ON o.uid = l.po_uid WHERE l.qty > 0 AND l.qty_received > l.qty + 1e-9`).filter((r) => r.deliveries > 1)
        .forEach((r) => add('received_twice', `Order ${r.po_no}: ${r.qty_received} of ${r.name} received but ${r.qty} ordered (${r.deliveries} deliveries)`, { screen: 'POView', params: { uid: r.uid } }, 'Received on two devices? If the goods came once, void the extra delivery so the stock is right.'));
    }
    // The same deposit slip twice.
    if (has('deposits')) {
      db().all("SELECT slip_no, COUNT(*) AS n FROM deposits WHERE status = 'active' AND slip_no IS NOT NULL AND slip_no <> '' GROUP BY account_uid, slip_no HAVING n > 1")
        .forEach((r) => add('deposit_twice', `Deposit slip ${r.slip_no} is recorded ${r.n} times`, { screen: 'Till', params: {} }, 'Void the extra one so the bank is right.'));
    }
  } catch (e) { /* tables not ready */ }
  return out;
}
