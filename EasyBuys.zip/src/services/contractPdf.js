// The company's own contract PDF, with the employee's signature, the director's signature and the company stamp
// put onto it (and the person's details where the admin placed them). Pure JavaScript (pdf-lib): works on the tablet.
import { PDFDocument, StandardFonts, rgb, BlendMode } from 'pdf-lib';

// What can be placed on the PDF.
export const PLACE_WHAT = [
  ['emp_sig', 'Employee signature'], ['emp_name', 'Employee name'], ['emp_date', 'Date employee signed'],
  ['dir_sig', 'Director signature'], ['dir_name', 'Director name'], ['dir_date', 'Date director signed'], ['stamp', 'Company stamp'],
  ['job_title', 'Job title'], ['start_date', 'Start date'], ['pay', 'Pay'], ['shop', 'Shop'], ['employee_no', 'Employee number'],
];
export const PLACE_LABEL = Object.fromEntries(PLACE_WHAT);
const IMAGES = ['emp_sig', 'dir_sig', 'stamp'];
export const isImageItem = (what) => IMAGES.includes(what);

// Starting layout: a signing page is added at the end (always works, whatever the PDF looks like).
export const DEFAULT_LAYOUT = {
  signPage: true,          // add a page at the end with both signatures and the stamp
  initialsEachPage: true,  // the employee's signature, small, at the bottom corner of every page of the contract
  items: [],               // signatures / details placed on the contract's own pages: { what, page ('last' or 1,2,…), x, y, w } in % of the page
};

export function cleanLayout(l) {
  const x = { ...DEFAULT_LAYOUT, ...(l || {}) };
  const pct = (v, d) => { const n = Number(v); return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : d; };
  x.items = (Array.isArray(x.items) ? x.items : []).filter((i) => i && PLACE_LABEL[i.what]).map((i) => ({
    what: i.what, page: i.page === 'last' || i.page === '' || i.page === undefined ? 'last' : Math.max(1, Math.round(Number(i.page) || 1)),
    x: pct(i.x, 10), y: pct(i.y, 80), w: pct(i.w, isImageItem(i.what) ? 25 : 30),
  }));
  x.signPage = x.signPage !== false;
  x.initialsEachPage = !!x.initialsEachPage;
  return x;
}

async function embed(pdf, dataUrl) {
  if (!dataUrl) return null;
  const s = String(dataUrl);
  if (/^data:image\/png/i.test(s)) return pdf.embedPng(s);
  if (/^data:image\/jpe?g/i.test(s)) return pdf.embedJpg(s);
  return null;
}

// data: { name, employer, job_title, start_date, pay, shop, employee_no, contractNo,
//         empSig, empAt, dirSig, dirName, dirAt, stamp }   (signatures / stamp are data: URLs)
// Returns the finished PDF as base64.
export async function stampContract(templateB64, layout, data) {
  const L = cleanLayout(layout);
  const pdf = await PDFDocument.load(templateB64, { ignoreEncryption: true });
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const img = { emp_sig: await embed(pdf, data.empSig), dir_sig: await embed(pdf, data.dirSig), stamp: await embed(pdf, data.stamp) };
  const day = (t) => (t ? String(t).slice(0, 10) : '');
  const text = {
    emp_name: data.name, emp_date: day(data.empAt), dir_name: data.dirName, dir_date: day(data.dirAt),
    job_title: data.job_title, start_date: data.start_date, pay: data.pay, shop: data.shop, employee_no: data.employee_no,
  };
  const pages = pdf.getPages();
  const nOriginal = pages.length;
  const drawImg = (page, im, x, yTop, w, maxH) => {
    if (!im) return;
    const scale = w / im.width;
    let h = im.height * scale; let ww = w;
    if (maxH && h > maxH) { ww = (maxH / h) * w; h = maxH; }
    page.drawImage(im, { x, y: yTop - h, width: ww, height: h, blendMode: BlendMode.Multiply });
  };

  // 1. Items placed on the contract's own pages.
  for (const it of L.items) {
    const idx = it.page === 'last' ? nOriginal - 1 : Math.min(nOriginal, it.page) - 1;
    const page = pages[idx];
    const { width: W, height: H } = page.getSize();
    const x = (it.x / 100) * W; const yTop = H - (it.y / 100) * H; const w = (it.w / 100) * W;
    if (isImageItem(it.what)) drawImg(page, img[it.what], x, yTop, w);
    else {
      const t = String(text[it.what] || '');
      if (!t) continue;
      let size = 11; while (size > 6 && font.widthOfTextAtSize(t, size) > w) size -= 0.5;
      page.drawText(t, { x, y: yTop - size, size, font, color: rgb(0.05, 0.05, 0.25) });
    }
  }

  // 2. Initials (the employee's signature, small) at the bottom right of every page.
  if (L.initialsEachPage && img.emp_sig) {
    for (let i = 0; i < nOriginal; i++) {
      const page = pages[i];
      const { width: W } = page.getSize();
      drawImg(page, img.emp_sig, W - 110, 46, 80, 26);
      page.drawText('Employee', { x: W - 110, y: 10, size: 6.5, font, color: rgb(0.45, 0.45, 0.45) });
    }
  }

  // 3. A signing page at the end.
  if (L.signPage) {
    const first = pages[0].getSize();
    const page = pdf.addPage([first.width, first.height]);
    const W = first.width; const H = first.height; const m = 56;
    let y = H - m;
    const line = (t, size = 11, f = font, color = rgb(0.1, 0.1, 0.1)) => { const n = Math.max(1, Math.ceil(f.widthOfTextAtSize(String(t), size) / (W - 2 * m) + 0.05)); page.drawText(String(t), { x: m, y: y - size, size, font: f, color, maxWidth: W - 2 * m, lineHeight: size * 1.3 }); y -= size * 1.3 * (n - 1) + size * 1.6; };
    line('Signatures', 18, bold);
    line(`This page forms part of the contract of employment between ${data.employer || 'the Employer'} and ${data.name || 'the Employee'}.`, 10.5);
    if (data.contractNo) line(`Contract reference: ${data.contractNo}`, 9, font, rgb(0.4, 0.4, 0.4));
    y -= 12;
    const box = (label, sig, name, at, x0) => {
      const top = y; const w = (W - 2 * m - 30) / 2;
      page.drawText(label, { x: x0, y: top - 11, size: 11, font: bold });
      drawImg(page, sig, x0, top - 20, w, 80);
      page.drawLine({ start: { x: x0, y: top - 106 }, end: { x: x0 + w, y: top - 106 }, thickness: 0.8, color: rgb(0.5, 0.5, 0.5) });
      page.drawText(`Name: ${name || ''}`, { x: x0, y: top - 122, size: 10, font });
      page.drawText(`Date: ${day(at)}`, { x: x0, y: top - 138, size: 10, font });
    };
    box('Employee', img.emp_sig, data.name, data.empAt, m);
    box(`For ${data.employer || 'the Employer'}`, img.dir_sig, data.dirName, data.dirAt, m + (W - 2 * m - 30) / 2 + 30);
    y -= 160;
    if (img.stamp) { page.drawText('Company stamp', { x: W - m - 150, y: y - 11, size: 10, font: bold }); drawImg(page, img.stamp, W - m - 150, y - 18, 150, 150); }
    page.drawText('Signed electronically on the Easy Buys app. The signatures above were drawn by each person on the screen.', { x: m, y: m - 20, size: 8, font, color: rgb(0.45, 0.45, 0.45), maxWidth: W - 2 * m });
  }
  return pdf.saveAsBase64();
}

// How many pages the company's contract has (to check the places chosen by the admin).
export async function pageCount(templateB64) {
  const pdf = await PDFDocument.load(templateB64, { ignoreEncryption: true });
  return pdf.getPageCount();
}
