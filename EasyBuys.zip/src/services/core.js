// Shared helpers: time, numbers, IDs, settings, hashing.
import { db } from '../db/connection.js';

export const APP_VERSION = '3.9.0';

// The clock can be overridden (sample history) or shifted (automated tests).
export const clock = {
  override: null,
  offsetMs: 0,
  now() {
    if (this.override) return new Date(this.override.getTime());
    return new Date(Date.now() + this.offsetMs);
  },
};

const pad = (n, w = 2) => String(n).padStart(w, '0');

export function dateStr(d = clock.now()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function timeStr(d = clock.now()) {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function stamp(d = clock.now()) {
  return `${dateStr(d)} ${timeStr(d)}:${pad(d.getSeconds())}`;
}
// Parse 'YYYY-MM-DD HH:MM[:SS]' (local time) into a Date.
export function parseStamp(s) {
  if (!s) return null;
  const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
}
export function addMinutes(s, minutes) {
  const d = parseStamp(s);
  return stamp(new Date(d.getTime() + minutes * 60000));
}
export function minutesBetween(a, b) {
  const da = parseStamp(a);
  const dbb = parseStamp(b);
  if (!da || !dbb) return null;
  return Math.round((dbb - da) / 60000);
}
export function hoursMinutes(mins) {
  if (mins === null || mins === undefined) return '—';
  const m = Math.max(0, Math.round(mins));
  const h = Math.floor(m / 60);
  return h ? `${h}h ${pad(m % 60)}m` : `${m} min`;
}
export function hhmm(s) {
  return s ? String(s).slice(11, 16) : '—';
}
// Build a stamp for today at HH:MM (or yesterday if that time is later than now, for night shifts).
export function stampFromTime(hh, mm) {
  const now = clock.now();
  const d = new Date(now);
  d.setHours(hh, mm, 0, 0);
  if (d.getTime() - now.getTime() > 5 * 60000) d.setDate(d.getDate() - 1);
  return stamp(d);
}

// Round to 3 decimals to avoid floating point noise.
export function r3(n) {
  const v = Number(n) || 0;
  return Math.round(v * 1000) / 1000;
}
export function r1(n) {
  return Math.round((Number(n) || 0) * 10) / 10;
}
export function fmt(n, unit) {
  if (n === null || n === undefined || n === '') return '—';
  const s = String(r3(n));
  return unit ? `${s} ${unit}` : s;
}
export function signed(n, unit) {
  const v = r3(n);
  const s = v > 0 ? `+${fmt(v)}` : fmt(v);
  return unit ? `${s} ${unit}` : s;
}
// Flour bands: limits [10, 20] give bands "up to 10 kg", "10–20 kg", "over 20 kg".
export function bandIndex(flourKg, limits) {
  let i = 0;
  while (i < limits.length && Number(flourKg) > limits[i] + 1e-9) i++;
  return i;
}
export function bandLabels(limits) {
  if (!limits.length) return ['Any amount'];
  return limits.map((l, i) => (i === 0 ? `Up to ${l} kg` : `${limits[i - 1]}–${l} kg`)).concat([`Over ${limits[limits.length - 1]} kg`]);
}

export function money(n, cur = '$') {
  if (n === null || n === undefined || n === '' || !Number.isFinite(Number(n))) return '—';
  const v = Number(n);
  return `${v < 0 ? '-' : ''}${cur}${Math.abs(v).toFixed(2)}`;
}
export function pctDiff(actual, expected) {
  if (!expected) return actual ? 100 : 0;
  return r1(((actual - expected) / expected) * 100);
}

export class AppError extends Error {
  constructor(message) {
    super(message);
    this.isAppError = true;
  }
}
export function requirePositive(n, label) {
  const v = Number(n);
  if (n === null || n === '' || !Number.isFinite(v) || v <= 0) throw new AppError(`${label} must be more than 0.`);
  return r3(v);
}
export function requireNonNegative(n, label) {
  const v = Number(n);
  if (n === null || n === '' || !Number.isFinite(v) || v < 0) throw new AppError(`${label} cannot be empty or negative.`);
  return r3(v);
}

// ---------- settings ----------
// Business-wide settings that used to be kept on one device only. They now live in the synced shared settings, so a
// change made by the admin on any device reaches every tablet and phone. Everything else in `settings` is about this
// device only (its cloud link, name, shop, screen size, sounds, last sync…).
export const BUSINESS_SETTING_KEYS = ['bakery_name', 'location_name', 'default_flag_pct', 'default_tolerance_pct', 'report_emails', 'po_emails',
  'po_auto', 'invoice_photo_required', 'water_unit', 'record_water_temp', 'idle_logout_min', 'require_lot_expiry', 'expiry_alert_days',
  'currency', 'oven_decks', 'flour_bands', 'mix_reminder'];
const BUSINESS = new Set(BUSINESS_SETTING_KEYS);
const sharedKey = (key) => `setting:${key}`;
function localSetting(key) {
  const row = db().get('SELECT value FROM settings WHERE key = ?', [key]);
  return row ? row.value : undefined;
}
export function getSetting(key, fallback = null) {
  if (BUSINESS.has(key)) {
    const v = getShared(sharedKey(key), null);
    if (v !== null) return String(v);
  }
  const v = localSetting(key);
  return v === undefined ? fallback : v;
}
export function setSetting(key, value) {
  const v = value === null || value === undefined ? null : String(value);
  db().run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, v]);
  if (BUSINESS.has(key) && getShared(sharedKey(key), null) !== v) setShared(sharedKey(key), v);
}
// Once, when upgrading: copy this device's business settings up so every device starts the same. Only the device
// holding the cloud key (the main tablet) or a device not linked yet does it, so a new phone can't overwrite them.
export function shareBusinessSettings() {
  let isMain = true;
  try { isMain = !!localSetting('cloud_key') || !localSetting('cloud_url'); } catch (e) { isMain = true; }
  if (!isMain) return 0;
  let n = 0;
  for (const key of BUSINESS_SETTING_KEYS) {
    const v = localSetting(key);
    if (v !== undefined && v !== null && getShared(sharedKey(key), null) === null) { setShared(sharedKey(key), v); n += 1; }
  }
  return n;
}
function parseList(v) {
  try {
    const a = JSON.parse(v || '[]');
    return Array.isArray(a) ? a : [];
  } catch (e) {
    return [];
  }
}
export function getSettings() {
  return {
    bakeryName: getSetting('bakery_name', 'Easy Buys Bakery'),
    locationName: getSetting('location_name', 'Bakery'),
    defaultFlagPct: Number(getSetting('default_flag_pct', '2')),
    defaultTolerance: Number(getSetting('default_tolerance_pct', '2')),
    showDemoPins: getSetting('show_demo_pins', '1') === '1',
    reportEmails: parseList(getSetting('report_emails', '[]')),
    poEmails: parseList(getSetting('po_emails', '[]')),
    poAuto: getSetting('po_auto', '1') === '1',
    cloudUrl: getSetting('cloud_url', ''),
    cloudKey: getSetting('cloud_key', ''),
    invoicePhotoRequired: getSetting('invoice_photo_required', '0') === '1',
    keepAwake: getSetting('keep_awake', '1') === '1',
    waterUnit: getSetting('water_unit', 'L'),
    recordWaterTemp: getSetting('record_water_temp', '1') === '1',
    idleLogoutMin: Number(getSetting('idle_logout_min', '15')),
    requireLotExpiry: getSetting('require_lot_expiry', '0') === '1',
    expiryAlertDays: Number(getSetting('expiry_alert_days', '7')),
    currency: getSetting('currency', '$'),
    decks: parseList(getSetting('oven_decks', '["Deck 1","Deck 2","Deck 3"]')),
    flourBands: parseList(getSetting('flour_bands', '[10,20]')).map(Number).filter((n) => Number.isFinite(n) && n > 0),
    mixReminder: getSetting('mix_reminder', 'While it mixes: get the trays ready and oil them.'),
  };
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export function isEmail(s) {
  return EMAIL_RE.test(String(s || '').trim());
}
export function saveSettings(s) {
  const name = String(s.bakeryName || '').trim();
  if (!name) throw new AppError('Bakery name is required.');
  const flag = Number(s.defaultFlagPct);
  if (!Number.isFinite(flag) || flag < 0 || flag > 100) throw new AppError('Flag percentage must be between 0 and 100.');
  const tol = Number(s.defaultTolerance);
  if (!Number.isFinite(tol) || tol < 0 || tol > 100) throw new AppError('Stock tolerance must be between 0 and 100%.');
  const emails = (s.reportEmails || []).map((e) => String(e).trim()).filter(Boolean);
  const poEmails = (s.poEmails || []).map((e) => String(e).trim()).filter(Boolean);
  const bad = emails.concat(poEmails).filter((e) => !isEmail(e));
  if (bad.length) throw new AppError(`Not a valid email address: ${bad.join(', ')}`);
  const idle = Number(s.idleLogoutMin);
  if (!Number.isFinite(idle) || idle < 1 || idle > 240) throw new AppError('Auto log-out must be between 1 and 240 minutes.');
  const url = String(s.cloudUrl || '').trim();
  if (url && !/^https:\/\/script\.google\.com\//.test(url)) {
    throw new AppError('The cloud web address must start with https://script.google.com/');
  }
  setSetting('bakery_name', name);
  setSetting('location_name', String(s.locationName || '').trim() || 'Bakery');
  setSetting('default_flag_pct', r3(flag));
  setSetting('default_tolerance_pct', r3(tol));
  setSetting('show_demo_pins', s.showDemoPins ? '1' : '0');
  setSetting('report_emails', JSON.stringify(Array.from(new Set(emails))));
  setSetting('po_emails', JSON.stringify(Array.from(new Set(poEmails))));
  setSetting('po_auto', s.poAuto === false ? '0' : '1');
  setSetting('cloud_url', url);
  setSetting('cloud_key', String(s.cloudKey || '').trim());
  setSetting('invoice_photo_required', s.invoicePhotoRequired ? '1' : '0');
  setSetting('keep_awake', s.keepAwake ? '1' : '0');
  setSetting('water_unit', s.waterUnit === 'kg' ? 'kg' : 'L');
  setSetting('record_water_temp', s.recordWaterTemp ? '1' : '0');
  setSetting('idle_logout_min', Math.round(idle));
  setSetting('require_lot_expiry', s.requireLotExpiry ? '1' : '0');
  const ed = Number(s.expiryAlertDays);
  if (!Number.isFinite(ed) || ed < 0 || ed > 365) throw new AppError('Expiry warning days must be between 0 and 365.');
  setSetting('expiry_alert_days', Math.round(ed));
  setSetting('currency', String(s.currency || '$').trim().slice(0, 4) || '$');
  const decks = (s.decks || []).map((d) => String(d).trim()).filter(Boolean);
  if (new Set(decks.map((d) => d.toLowerCase())).size !== decks.length) throw new AppError('Two oven decks have the same name.');
  if (!decks.length) throw new AppError('Keep at least one oven deck.');
  if (decks.some((d) => d.includes(','))) throw new AppError('Oven deck names cannot contain a comma.');
  // A deck renamed in the same position keeps its product temperatures.
  const oldDecks = getSettings().decks;
  oldDecks.forEach((o, i) => {
    if (decks[i] && decks[i] !== o && !oldDecks.includes(decks[i])) db().run('UPDATE product_decks SET deck = ? WHERE deck = ?', [decks[i], o]);
  });
  setSetting('oven_decks', JSON.stringify(decks));
  const bands = (s.flourBands || []).map(Number);
  if (bands.some((b) => !Number.isFinite(b) || b <= 0)) throw new AppError('Flour band limits must be numbers above 0.');
  for (let i = 1; i < bands.length; i++) if (bands[i] <= bands[i - 1]) throw new AppError('Flour band limits must go from small to large (e.g. 10, 20).');
  if (bands.length > 4) throw new AppError('Use at most 4 band limits (5 bands).');
  setSetting('flour_bands', JSON.stringify(bands.map(r3)));
  setSetting('mix_reminder', String(s.mixReminder || '').trim());
}

// ---------- IDs ----------
// Format: TX-YYMMDD-00001 (never repeats on this device).
export function nextSeq(key) {
  const seq = Number(getSetting(key, '0')) + 1;
  setSetting(key, seq);
  return seq;
}
function ymd() {
  const d = clock.now();
  return `${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
}
export function nextTxnId() {
  return `TX-${ymd()}-${pad(nextSeq('txn_seq'), 5)}`;
}
export function nextPoNo() {
  return `PO-${ymd()}-${pad(nextSeq('po_seq'), 3)}`;
}
export function nextBatchCode() {
  return `B-${ymd()}-${pad(nextSeq('batch_seq'), 3)}`;
}

// ---------- SHA-256 (for passwords; pure JS so it works offline everywhere) ----------
function utf8(s) {
  let out = '';
  for (const ch of String(s)) {
    const c = ch.codePointAt(0);
    if (c < 0x80) out += String.fromCharCode(c);
    else if (c < 0x800) out += String.fromCharCode(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) out += String.fromCharCode(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else out += String.fromCharCode(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return out;
}
export function sha256(ascii) {
  const rightRotate = (v, a) => (v >>> a) | (v << (32 - a));
  const maxWord = 2 ** 32;
  let result = '';
  const words = [];
  const bytes = utf8(ascii);
  const asciiBitLength = bytes.length * 8;
  const hash = [];
  const k = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
      hash[primeCounter] = (candidate ** 0.5 * maxWord) | 0;
      k[primeCounter++] = (candidate ** (1 / 3) * maxWord) | 0;
    }
  }
  let str = bytes + '\x80';
  while ((str.length % 64) - 56) str += '\x00';
  for (let i = 0; i < str.length; i++) {
    const j = str.charCodeAt(i);
    words[i >> 2] |= j << (((3 - i) % 4) * 8);
  }
  words[words.length] = (asciiBitLength / maxWord) | 0;
  words[words.length] = asciiBitLength;
  let h = hash.slice(0, 8);
  for (let j = 0; j < words.length;) {
    const w = words.slice(j, (j += 16));
    const oldHash = h;
    h = h.slice(0, 8);
    for (let i = 0; i < 64; i++) {
      const w15 = w[i - 15];
      const w2 = w[i - 2];
      const a = h[0];
      const e = h[4];
      const temp1 = h[7] + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) + ((e & h[5]) ^ (~e & h[6])) + k[i]
        + (w[i] = i < 16 ? w[i] : (w[i - 16] + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) + w[i - 7]
          + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) | 0);
      const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) + ((a & h[1]) ^ (a & h[2]) ^ (h[1] & h[2]));
      h = [(temp1 + temp2) | 0].concat(h);
      h[4] = (h[4] + temp1) | 0;
      h.length = 8;
    }
    for (let i = 0; i < 8; i++) h[i] = (h[i] + oldHash[i]) | 0;
  }
  for (let i = 0; i < 8; i++) {
    for (let j = 3; j + 1; j--) {
      const b = (h[i] >> (j * 8)) & 255;
      result += (b < 16 ? '0' : '') + b.toString(16);
    }
  }
  return result;
}
export function hashPassword(username, password) {
  return sha256(`easybuys:${String(username).toLowerCase()}:${password}`);
}
export function randomKey(len = 24) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export const TXN_TYPES = {
  OPENING: 'Opening stock',
  RECEIVE: 'Stock received',
  USAGE: 'Ingredient usage',
  WASTAGE: 'Wastage',
  ADJUST: 'Stock adjustment',
  PRODUCTION: 'Production',
  BALANCE: 'Balance correction',
};


// ================= Easy Buys (version 3) shared helpers =================
// An id that is the same on every device (tablet and phones), e.g. "P-lq3k2m-8f2k1x9a".
export function uuid(prefix = 'X') {
  const r = () => Math.random().toString(36).slice(2, 10).padEnd(8, '0');
  return `${prefix}-${Date.now().toString(36)}-${r()}${r().slice(0, 4)}`;
}

// This device's own id and name (kept only on this device, never synced).
export function deviceId() {
  let id = getSetting('device_id');
  if (!id) {
    id = uuid('D');
    setSetting('device_id', id);
  }
  return id;
}
export function deviceName() {
  return getSetting('device_name', '') || (getSetting('device_kind', 'tablet') === 'phone' ? 'Phone' : 'Tablet');
}

// Settings shared by every device (synced). Stored as JSON text.
export function getShared(key, fallback = null) {
  let row = null;
  try {
    row = db().get('SELECT value FROM shared_settings WHERE key = ?', [key]);
  } catch (e) {
    row = null;
  }
  if (!row || row.value === null || row.value === undefined) return fallback;
  try {
    return JSON.parse(row.value);
  } catch (e) {
    return fallback;
  }
}
export function setShared(key, value) {
  db().run(
    `INSERT INTO shared_settings (key, value, updated_at, updated_device, sync_status) VALUES (?, ?, ?, ?, 'pending')
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [key, JSON.stringify(value), stamp(), deviceId()]
  );
}

// Who did what, when, on which device and why. Never edited or deleted.
export function audit({ user, action, table, recordUid, before, after, reason }) {
  db().run(
    `INSERT INTO audit_log (uid, at, user_uid, user_name, device, action, table_name, record_uid, before, after, reason, updated_at, updated_device)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [uuid('A'), stamp(), user ? user.uid : null, user ? user.name : 'System', deviceName(), action, table || null, recordUid || null,
      before === undefined || before === null ? null : JSON.stringify(before), after === undefined || after === null ? null : JSON.stringify(after),
      reason || null, stamp(), deviceId()]
  );
}

// Dates for the Saturday-Friday pay week.
export function addDays(dateText, n) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  const x = new Date(y, m - 1, d + n);
  return dateStr(x);
}
export function weekStart(dateText) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  const x = new Date(y, m - 1, d);
  const back = (x.getDay() + 1) % 7; // Saturday = 0 days back, Sunday = 1 ... Friday = 6
  return addDays(dateText, -back);
}
export function dayName(dateText) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(y, m - 1, d).getDay()];
}
