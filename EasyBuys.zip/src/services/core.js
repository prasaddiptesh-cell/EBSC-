// Shared helpers: time, numbers, IDs, settings, hashing.
import { db, realDb, writeCount, noteKeyRead } from '../db/connection.js';
import { isTraining as trainingOn } from './trainingFlag.js';

export const APP_VERSION = '1.0.0';

// ---------- Fiji time (the owner: "the time and date will be Pacific Fiji time and that can not be changed") ----------
// Every date and time the app shows or writes is the wall time in Fiji, whatever time zone the phone is set to. There is
// no setting for it. The offset comes from the phone's time-zone data for Pacific/Fiji (so a future Fiji summer time
// would be followed); if the phone has no time-zone data it is a fixed UTC+12.
// How it works: clock.now() returns a "wall-time Date" – a Date whose LOCAL fields (getHours, getDate …) show the Fiji
// wall time. All the existing date code (dateStr, timeStr, local calendar maths) then gives Fiji dates on any phone.
// On a phone set to Fiji time (the normal case) a wall-time Date is exactly the real time.
export const FIJI_TZ = 'Pacific/Fiji';
export const FIJI_FIXED_OFFSET_MIN = 12 * 60;
let fijiFmt = null; let fijiFmtTried = false;
const fijiMemo = new Map();
// Minutes Fiji is ahead of UTC at the real instant ms (720, or 780 in a Fiji summer time if the time-zone data has one).
export function fijiOffsetMin(ms = Date.now()) {
  const hour = Math.floor(ms / 3600000);
  if (fijiMemo.has(hour)) return fijiMemo.get(hour);
  let off = FIJI_FIXED_OFFSET_MIN;
  try {
    if (!fijiFmtTried) { fijiFmtTried = true; fijiFmt = new Intl.DateTimeFormat('en-US', { timeZone: FIJI_TZ, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
    if (fijiFmt && fijiFmt.formatToParts) {
      const p = {}; for (const x of fijiFmt.formatToParts(new Date(hour * 3600000))) p[x.type] = x.value;
      const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second);
      const m = Math.round((asUtc - hour * 3600000) / 60000);
      if (Number.isFinite(m) && m >= 11 * 60 && m <= 14 * 60) off = m; // a sane Fiji offset only
    }
  } catch (e) { off = FIJI_FIXED_OFFSET_MIN; }
  if (fijiMemo.size > 2000) fijiMemo.clear();
  fijiMemo.set(hour, off);
  return off;
}
// A wall-time Date for the real instant ms (its local fields show Fiji's date and time).
export function wallFromReal(ms = Date.now()) {
  const target = fijiOffsetMin(ms);
  const first = new Date(ms + (target + new Date(ms).getTimezoneOffset()) * 60000);
  return new Date(ms + (target + first.getTimezoneOffset()) * 60000); // again with the phone's offset at that wall time (summer time)
}
// The real instant (ms since 1970 UTC) of a wall-time Date (or of a 'YYYY-MM-DD HH:MM:SS' Fiji stamp).
export function realFromWall(d) {
  const w = typeof d === 'string' ? parseStamp(d) : d;
  if (!w) return NaN;
  const asUtc = Date.UTC(w.getFullYear(), w.getMonth(), w.getDate(), w.getHours(), w.getMinutes(), w.getSeconds(), w.getMilliseconds());
  return asUtc - fijiOffsetMin(asUtc - FIJI_FIXED_OFFSET_MIN * 60000) * 60000;
}

// The clock can be overridden (sample history, tests: the override is already a Fiji wall time) or shifted (tests).
export const clock = {
  override: null,
  offsetMs: 0,
  now() {
    if (this.override) return new Date(this.override.getTime());
    return wallFromReal(Date.now() + this.offsetMs);
  },
};
// Milliseconds of the wall clock (to compare with parseStamp(...) of a stamp the app wrote).
export function nowMs() { return clock.now().getTime(); }

// ---------- the time guard: the phone must be on Fiji time and its clock right ----------
// The phone's own time zone must be Fiji (Android Settings › Date and time) and its clock within 5 minutes of the
// cloud's (checked at each sync). Otherwise a red banner blocks clock-ins, till counts, invoices, cheques and money
// records until it is fixed (assertTimeOk), and the cloud's security log is told (deviceStat sends tz and the clock
// difference with every pull). Only checked on the phone itself (not in the Node tests unless timeGuard.force is set).
export const timeGuard = { force: false };
export function phoneTimeZone() {
  try { const z = Intl.DateTimeFormat().resolvedOptions().timeZone; if (z) return String(z); } catch (e) { /* none */ }
  const o = -new Date().getTimezoneOffset();
  return `UTC${o >= 0 ? '+' : '-'}${pad(Math.floor(Math.abs(o) / 60))}:${pad(Math.abs(o) % 60)}`;
}
const onPhone = () => { try { return typeof navigator !== 'undefined' && navigator.product === 'ReactNative'; } catch (e) { return false; } };
export function timeTrouble() {
  if (!timeGuard.force && !onPhone()) return null;
  const tz = phoneTimeZone();
  const fijiNamed = /^(Pacific\/Fiji)$/.test(tz);
  const sameOffset = -new Date().getTimezoneOffset() === fijiOffsetMin();
  if (!fijiNamed && !(sameOffset && /^UTC/.test(tz))) {
    return { kind: 'tz', tz, text: `This phone is set to the wrong time zone (${tz}).`, sub: 'Set it to Fiji: Android Settings › General management › Date and time › Time zone › Fiji. Until then clock-ins, till counts, invoices, cheques and money records are stopped.' };
  }
  let skew = 0;
  try { skew = Number(getSetting('clock_skew_min', '0')) || 0; } catch (e) { skew = 0; }
  if (Math.abs(skew) > 5) {
    return { kind: 'clock', tz, skew, text: `This phone's clock is ${Math.abs(skew)} minutes ${skew > 0 ? 'fast' : 'slow'}.`, sub: 'Switch on "Automatic date and time": Android Settings › General management › Date and time. Until then clock-ins, till counts, invoices, cheques and money records are stopped.' };
  }
  return null;
}
export function assertTimeOk(what = 'This') {
  const t = timeTrouble();
  if (t) throw new AppError(`${what} cannot be saved now. ${t.text} ${t.sub}`);
}

const pad = (n, w = 2) => String(n).padStart(w, '0');

export function dateStr(d = clock.now()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function timeStr(d = clock.now()) {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function stamp(d = clock.now()) {
  return `${dateStr(d)} ${timeStr(d)}:${pad(d.getSeconds())}`;
}
// Parse 'YYYY-MM-DD HH:MM[:SS]' (local time) into a Date.
export function parseStamp(s) {
  if (!s) return null;
  const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
}
export function addMinutes(s, minutes) {
  const d = parseStamp(s);
  return stamp(new Date(d.getTime() + minutes * 60000));
}
export function minutesBetween(a, b) {
  const da = parseStamp(a);
  const dbb = parseStamp(b);
  if (!da || !dbb) return null;
  return Math.round((dbb - da) / 60000);
}
export function hoursMinutes(mins) {
  if (mins === null || mins === undefined) return '—';
  const m = Math.max(0, Math.round(mins));
  const h = Math.floor(m / 60);
  return h ? `${h}h ${pad(m % 60)}m` : `${m} min`;
}
export function hhmm(s) {
  return s ? String(s).slice(11, 16) : '—';
}
// Build a stamp for today at HH:MM (or yesterday if that time is later than now, for night shifts).
export function stampFromTime(hh, mm) {
  const now = clock.now();
  const d = new Date(now);
  d.setHours(hh, mm, 0, 0);
  if (d.getTime() - now.getTime() > 5 * 60000) d.setDate(d.getDate() - 1);
  return stamp(d);
}

// Round to 3 decimals to avoid floating point noise.
export function r3(n) {
  const v = Number(n) || 0;
  return Math.round(v * 1000) / 1000;
}
export function r1(n) {
  return Math.round((Number(n) || 0) * 10) / 10;
}
export function fmt(n, unit) {
  if (n === null || n === undefined || n === '') return '—';
  const s = String(r3(n));
  return unit ? `${s} ${unit}` : s;
}
export function signed(n, unit) {
  const v = r3(n);
  const s = v > 0 ? `+${fmt(v)}` : fmt(v);
  return unit ? `${s} ${unit}` : s;
}
// Flour bands: limits [10, 20] give bands "up to 10 kg", "10–20 kg", "over 20 kg".
export function bandIndex(flourKg, limits) {
  let i = 0;
  while (i < limits.length && Number(flourKg) > limits[i] + 1e-9) i++;
  return i;
}
export function bandLabels(limits) {
  if (!limits.length) return ['Any amount'];
  return limits.map((l, i) => (i === 0 ? `Up to ${l} kg` : `${limits[i - 1]}–${l} kg`)).concat([`Over ${limits[limits.length - 1]} kg`]);
}

export function money(n, cur = '$') {
  if (n === null || n === undefined || n === '' || !Number.isFinite(Number(n))) return '—';
  const v = Number(n);
  return `${v < 0 ? '-' : ''}${cur}${Math.abs(v).toFixed(2)}`;
}
export function pctDiff(actual, expected) {
  if (!expected) return actual ? 100 : 0;
  return r1(((actual - expected) / expected) * 100);
}

export class AppError extends Error {
  constructor(message) {
    // Release 07: never "[object Object]" – a reason that is not text is turned into words
    super(typeof message === 'string' ? message : message && typeof message.message === 'string' ? message.message : (() => { try { return JSON.stringify(message); } catch (e) { return String(message); } })());
    this.isAppError = true;
  }
}
export function requirePositive(n, label) {
  const v = Number(n);
  if (n === null || n === '' || !Number.isFinite(v) || v <= 0) throw new AppError(`${label} must be more than 0.`);
  return r3(v);
}
// 1.0.0 hardening: amounts no shop could ever have (a slip of the finger: 1e15) are refused, not saved.
export const MONEY_MAX = 10000000;
export function sensibleAmount(n, label = 'The amount') {
  const v = Number(n);
  if (!Number.isFinite(v)) throw new AppError(`${label} is not a number. Type the figure again.`);
  if (Math.abs(v) > MONEY_MAX) throw new AppError(`${label} is too big (over $${MONEY_MAX.toLocaleString('en-US')}). Check the figure.`);
  return v;
}
// A date that really exists on the calendar (not 30 February) and is not decades out.
export function realDate(d) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(d || ''));
  if (!m) return false;
  const x = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return x.getUTCFullYear() === +m[1] && x.getUTCMonth() === +m[2] - 1 && x.getUTCDate() === +m[3] && +m[1] >= 2000 && +m[1] <= 2100;
}
export function requireNonNegative(n, label) {
  const v = Number(n);
  if (n === null || n === '' || !Number.isFinite(v) || v < 0) throw new AppError(`${label} cannot be empty or negative.`);
  return r3(v);
}

// ---------- settings ----------
// Business-wide settings that used to be kept on one device only. They now live in the synced shared settings, so a
// change made by the admin on any device reaches every tablet and phone. Everything else in `settings` is about this
// device only (its cloud link, name, shop, screen size, sounds, last sync…).
export const BUSINESS_SETTING_KEYS = ['bakery_name', 'location_name', 'default_flag_pct', 'default_tolerance_pct', 'report_emails', 'po_emails',
  'po_auto', 'invoice_photo_required', 'water_unit', 'record_water_temp', 'idle_logout_min', 'require_lot_expiry', 'expiry_alert_days',
  'currency', 'oven_decks', 'flour_bands', 'mix_reminder'];
const BUSINESS = new Set(BUSINESS_SETTING_KEYS);
const sharedKey = (key) => `setting:${key}`;
// v3.9.2 The device's link to the cloud always lives in the real database. Practice (training) mode reads it from
// there and never changes it – practice can never unlink, relink, block or confuse the device.
export const DEVICE_KEYS = new Set(['cloud_url', 'cloud_key', 'cloud_token', 'cloud_script_version', 'device_id', 'device_kind', 'device_name', 'device_blocked', 'device_lock',
  'lock_override', 'device_end_date', 'device_roles', 'device_shop', 'link_waiting', 'linked_at', 'force_logout', 'devices_cache', 'last_sync_at', 'last_sync_error', 'last_sync_ok_at', 'pull_seq', 'last_rejected']);
const realFor = (key) => { if (!DEVICE_KEYS.has(key) || !trainingOn()) return null; const r = realDb(); return r && r !== db() ? r : null; };
function localSetting(key) {
  const r = realFor(key);
  if (r) { try { const x = r.get('SELECT value FROM settings WHERE key = ?', [key]); return x ? x.value : undefined; } catch (e) { return undefined; } }
  // v3.9.5 kept until anything in the database changes (as shared settings above)
  const d = db();
  const w = writeCount();
  const nowMs = Date.now();
  if (d !== localDb || w !== localAt || nowMs - localTime > 1500) { localCache = new Map(); localDb = d; localAt = w; localTime = nowMs; }
  if (localCache.has(key)) { noteKeyRead('settings', key); return localCache.get(key); }
  const row = d.get('SELECT value FROM settings WHERE key = ?', [key]);
  const v = row ? row.value : undefined;
  localCache.set(key, v);
  return v;
}
let localCache = new Map();
let localAt = -1;
let localDb = null;
let localTime = 0;
// 1.0.0 (audit H): this device's pass to the cloud is kept in the phone's secure store (Android keystore, expo-secure-store)
// instead of the database file. src/platform/secureStore.js plugs the store in; with none (web, tests) or when the store
// fails, the pass stays in `settings` as before. A pass is only taken out of the database once the store gives it back.
export const SECURE_SETTING_KEYS = ['cloud_token'];
const SECURE = new Set(SECURE_SETTING_KEYS);
let secureBackend = null;
const secureCache = new Map();
const secureName = (key) => `eb_${key}`;
export function setSecureBackend(b) { secureBackend = b && typeof b.getItem === 'function' && typeof b.setItem === 'function' ? b : null; secureCache.clear(); }
function secureGet(key) {
  if (!secureBackend) return undefined;
  if (secureCache.has(key)) return secureCache.get(key);
  let v;
  try { const x = secureBackend.getItem(secureName(key)); v = x === null || x === undefined || x === '' ? undefined : String(x); } catch (e) { v = undefined; }
  secureCache.set(key, v);
  return v;
}
// true when the store now holds exactly v (read back to make sure)
function securePut(key, v) {
  if (!secureBackend) return false;
  secureCache.delete(key);
  try {
    if (v === null || v === '') {
      if (typeof secureBackend.deleteItem === 'function') secureBackend.deleteItem(secureName(key)); else secureBackend.setItem(secureName(key), '');
      const back = secureBackend.getItem(secureName(key));
      secureCache.set(key, undefined);
      return back === null || back === undefined || back === '';
    }
    secureBackend.setItem(secureName(key), v);
    const ok = secureBackend.getItem(secureName(key)) === v;
    secureCache.set(key, ok ? v : undefined);
    return ok;
  } catch (e) { secureCache.delete(key); return false; }
}
function writeSetting(d, key, v) { d.run('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [key, v]); }
// At start-up: a pass still in the database (an older version kept it there, or the store failed last time) moves to
// the secure store; it is cleared from the database only after the store has given it back. Returns what moved.
export function migrateSecureSettings(d = db()) {
  const moved = [];
  if (!secureBackend || !d) return moved;
  for (const key of SECURE_SETTING_KEYS) {
    let row;
    try { row = d.get('SELECT value FROM settings WHERE key = ?', [key]); } catch (e) { continue; }
    const v = row && row.value !== null && row.value !== undefined ? String(row.value) : '';
    if (!v) continue;
    if (securePut(key, v)) { writeSetting(d, key, ''); moved.push(key); }
  }
  return moved;
}

export function getSetting(key, fallback = null) {
  if (SECURE.has(key)) { const s = secureGet(key); if (s !== undefined) return s; }
  if (BUSINESS.has(key)) {
    const v = getShared(sharedKey(key), null);
    if (v !== null) return String(v);
  }
  const v = localSetting(key);
  return v === undefined ? fallback : v;
}
export function setSetting(key, value) {
  if (realFor(key)) return; // practice mode never changes the device's cloud link
  const v = value === null || value === undefined ? null : String(value);
  // the device's pass: into the secure store when there is one (the database copy is then left empty)
  if (SECURE.has(key) && secureBackend) { writeSetting(db(), key, securePut(key, v) ? '' : v); return; }
  writeSetting(db(), key, v);
  if (BUSINESS.has(key) && getShared(sharedKey(key), null) !== v) setShared(sharedKey(key), v);
}
// Once, when upgrading: copy this device's business settings up so every device starts the same. Only the device
// holding the cloud key (the main tablet) or a device not linked yet does it, so a new phone can't overwrite them.
export function shareBusinessSettings() {
  let isMain = true;
  try { isMain = !!localSetting('cloud_key') || !localSetting('cloud_url'); } catch (e) { isMain = true; }
  if (!isMain) return 0;
  let n = 0;
  for (const key of BUSINESS_SETTING_KEYS) {
    const v = localSetting(key);
    if (v !== undefined && v !== null && getShared(sharedKey(key), null) === null) { setShared(sharedKey(key), v); n += 1; }
  }
  return n;
}
function parseList(v) {
  try {
    const a = JSON.parse(v || '[]');
    return Array.isArray(a) ? a : [];
  } catch (e) {
    return [];
  }
}
export function getSettings() {
  return {
    bakeryName: getSetting('bakery_name', 'Easy Buys Bakery'),
    locationName: getSetting('location_name', 'Bakery'),
    defaultFlagPct: Number(getSetting('default_flag_pct', '2')),
    defaultTolerance: Number(getSetting('default_tolerance_pct', '2')),
    showDemoPins: getSetting('show_demo_pins', '1') === '1',
    reportEmails: parseList(getSetting('report_emails', '[]')),
    poEmails: parseList(getSetting('po_emails', '[]')),
    poAuto: getSetting('po_auto', '1') === '1',
    cloudUrl: getSetting('cloud_url', ''),
    cloudKey: getSetting('cloud_key', ''),
    invoicePhotoRequired: getSetting('invoice_photo_required', '0') === '1',
    keepAwake: getSetting('keep_awake', '1') === '1',
    waterUnit: getSetting('water_unit', 'L'),
    recordWaterTemp: getSetting('record_water_temp', '1') === '1',
    idleLogoutMin: Number(getSetting('idle_logout_min', '15')),
    requireLotExpiry: getSetting('require_lot_expiry', '0') === '1',
    expiryAlertDays: Number(getSetting('expiry_alert_days', '7')),
    currency: getSetting('currency', '$'),
    decks: parseList(getSetting('oven_decks', '["Deck 1","Deck 2","Deck 3"]')),
    flourBands: parseList(getSetting('flour_bands', '[10,20]')).map(Number).filter((n) => Number.isFinite(n) && n > 0),
    mixReminder: getSetting('mix_reminder', 'While it mixes: get the trays ready and oil them.'),
  };
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export function isEmail(s) {
  return EMAIL_RE.test(String(s || '').trim());
}
export function saveSettings(s) {
  const name = String(s.bakeryName || '').trim();
  if (!name) throw new AppError('Bakery name is required.');
  const flag = Number(s.defaultFlagPct);
  if (!Number.isFinite(flag) || flag < 0 || flag > 100) throw new AppError('Flag percentage must be between 0 and 100.');
  const tol = Number(s.defaultTolerance);
  if (!Number.isFinite(tol) || tol < 0 || tol > 100) throw new AppError('Stock tolerance must be between 0 and 100%.');
  const emails = (s.reportEmails || []).map((e) => String(e).trim()).filter(Boolean);
  const poEmails = (s.poEmails || []).map((e) => String(e).trim()).filter(Boolean);
  const bad = emails.concat(poEmails).filter((e) => !isEmail(e));
  if (bad.length) throw new AppError(`Not a valid email address: ${bad.join(', ')}`);
  const idle = Number(s.idleLogoutMin);
  if (!Number.isFinite(idle) || idle < 1 || idle > 240) throw new AppError('Auto log-out must be between 1 and 240 minutes.');
  const url = String(s.cloudUrl || '').trim();
  if (url && !/^https:\/\/script\.google\.com\//.test(url)) {
    throw new AppError('The cloud web address must start with https://script.google.com/');
  }
  setSetting('bakery_name', name);
  setSetting('location_name', String(s.locationName || '').trim() || 'Bakery');
  setSetting('default_flag_pct', r3(flag));
  setSetting('default_tolerance_pct', r3(tol));
  setSetting('show_demo_pins', s.showDemoPins ? '1' : '0');
  setSetting('report_emails', JSON.stringify(Array.from(new Set(emails))));
  setSetting('po_emails', JSON.stringify(Array.from(new Set(poEmails))));
  setSetting('po_auto', s.poAuto === false ? '0' : '1');
  setSetting('cloud_url', url);
  setSetting('cloud_key', String(s.cloudKey || '').trim());
  setSetting('invoice_photo_required', s.invoicePhotoRequired ? '1' : '0');
  setSetting('keep_awake', s.keepAwake ? '1' : '0');
  setSetting('water_unit', s.waterUnit === 'kg' ? 'kg' : 'L');
  setSetting('record_water_temp', s.recordWaterTemp ? '1' : '0');
  setSetting('idle_logout_min', Math.round(idle));
  setSetting('require_lot_expiry', s.requireLotExpiry ? '1' : '0');
  const ed = Number(s.expiryAlertDays);
  if (!Number.isFinite(ed) || ed < 0 || ed > 365) throw new AppError('Expiry warning days must be between 0 and 365.');
  setSetting('expiry_alert_days', Math.round(ed));
  setSetting('currency', String(s.currency || '$').trim().slice(0, 4) || '$');
  const decks = (s.decks || []).map((d) => String(d).trim()).filter(Boolean);
  if (new Set(decks.map((d) => d.toLowerCase())).size !== decks.length) throw new AppError('Two oven decks have the same name.');
  if (!decks.length) throw new AppError('Keep at least one oven deck.');
  if (decks.some((d) => d.includes(','))) throw new AppError('Oven deck names cannot contain a comma.');
  // A deck renamed in the same position keeps its product temperatures.
  const oldDecks = getSettings().decks;
  oldDecks.forEach((o, i) => {
    if (decks[i] && decks[i] !== o && !oldDecks.includes(decks[i])) db().run('UPDATE product_decks SET deck = ? WHERE deck = ?', [decks[i], o]);
  });
  setSetting('oven_decks', JSON.stringify(decks));
  const bands = (s.flourBands || []).map(Number);
  if (bands.some((b) => !Number.isFinite(b) || b <= 0)) throw new AppError('Flour band limits must be numbers above 0.');
  for (let i = 1; i < bands.length; i++) if (bands[i] <= bands[i - 1]) throw new AppError('Flour band limits must go from small to large (e.g. 10, 20).');
  if (bands.length > 4) throw new AppError('Use at most 4 band limits (5 bands).');
  setSetting('flour_bands', JSON.stringify(bands.map(r3)));
  setSetting('mix_reminder', String(s.mixReminder || '').trim());
}

// ---------- IDs ----------
// Format: TX-YYMMDD-00001 (never repeats on this device).
export function nextSeq(key) {
  const seq = Number(getSetting(key, '0')) + 1;
  setSetting(key, seq);
  return seq;
}
function ymd() {
  const d = clock.now();
  return `${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
}
export function nextTxnId() {
  return `TX-${ymd()}-${pad(nextSeq('txn_seq'), 5)}`;
}
export function nextPoNo() {
  return `PO-${ymd()}-${pad(nextSeq('po_seq'), 3)}`;
}
export function nextBatchCode() {
  return `B-${ymd()}-${pad(nextSeq('batch_seq'), 3)}`;
}

// ---------- SHA-256 (for passwords; pure JS so it works offline everywhere) ----------
function utf8(s) {
  let out = '';
  for (const ch of String(s)) {
    const c = ch.codePointAt(0);
    if (c < 0x80) out += String.fromCharCode(c);
    else if (c < 0x800) out += String.fromCharCode(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) out += String.fromCharCode(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else out += String.fromCharCode(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return out;
}
export function sha256(ascii) {
  const rightRotate = (v, a) => (v >>> a) | (v << (32 - a));
  const maxWord = 2 ** 32;
  let result = '';
  const words = [];
  const bytes = utf8(ascii);
  const asciiBitLength = bytes.length * 8;
  const hash = [];
  const k = [];
  let primeCounter = 0;
  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
      hash[primeCounter] = (candidate ** 0.5 * maxWord) | 0;
      k[primeCounter++] = (candidate ** (1 / 3) * maxWord) | 0;
    }
  }
  let str = bytes + '\x80';
  while ((str.length % 64) - 56) str += '\x00';
  for (let i = 0; i < str.length; i++) {
    const j = str.charCodeAt(i);
    words[i >> 2] |= j << (((3 - i) % 4) * 8);
  }
  words[words.length] = (asciiBitLength / maxWord) | 0;
  words[words.length] = asciiBitLength;
  let h = hash.slice(0, 8);
  for (let j = 0; j < words.length;) {
    const w = words.slice(j, (j += 16));
    const oldHash = h;
    h = h.slice(0, 8);
    for (let i = 0; i < 64; i++) {
      const w15 = w[i - 15];
      const w2 = w[i - 2];
      const a = h[0];
      const e = h[4];
      const temp1 = h[7] + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) + ((e & h[5]) ^ (~e & h[6])) + k[i]
        + (w[i] = i < 16 ? w[i] : (w[i - 16] + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) + w[i - 7]
          + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) | 0);
      const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) + ((a & h[1]) ^ (a & h[2]) ^ (h[1] & h[2]));
      h = [(temp1 + temp2) | 0].concat(h);
      h[4] = (h[4] + temp1) | 0;
      h.length = 8;
    }
    for (let i = 0; i < 8; i++) h[i] = (h[i] + oldHash[i]) | 0;
  }
  for (let i = 0; i < 8; i++) {
    for (let j = 3; j + 1; j--) {
      const b = (h[i] >> (j * 8)) & 255;
      result += (b < 16 ? '0' : '') + b.toString(16);
    }
  }
  return result;
}
export function hashPassword(username, password) {
  return sha256(`easybuys:${String(username).toLowerCase()}:${password}`);
}
export function randomKey(len = 24) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export const TXN_TYPES = {
  OPENING: 'Opening stock',
  RECEIVE: 'Stock received',
  USAGE: 'Ingredient usage',
  WASTAGE: 'Wastage',
  ADJUST: 'Stock adjustment',
  PRODUCTION: 'Production',
  BALANCE: 'Balance correction',
};


// ================= Easy Buys (version 3) shared helpers =================
// An id that is the same on every device (tablet and phones), e.g. "P-lq3k2m-8f2k1x9a".
export function uuid(prefix = 'X') {
  const r = () => Math.random().toString(36).slice(2, 10).padEnd(8, '0');
  return `${prefix}-${Date.now().toString(36)}-${r()}${r().slice(0, 4)}`;
}

// This device's own id and name (kept only on this device, never synced).
export function deviceId() {
  let id = getSetting('device_id');
  if (!id) {
    id = uuid('D');
    setSetting('device_id', id);
  }
  return id;
}
export function deviceName() {
  return getSetting('device_name', '') || (getSetting('device_kind', 'tablet') === 'phone' ? 'Phone' : 'Tablet');
}

// Settings shared by every device (synced). Stored as JSON text.
// v3.9.5 shared settings are read many times a screen (what each role may do…): the text is kept until anything in
// the database changes (any save, sync or switch of database), then read again. Each caller still gets its own copy.
let sharedCache = new Map();
let sharedAt = -1;
let sharedDb = null;
let sharedTime = 0;
// Never kept longer than this, even with no change seen (so nothing can stay out of date for long).
const KEEP_MS = 1500;
export function getShared(key, fallback = null) {
  let raw = null;
  try {
    const d = db();
    const w = writeCount();
    const nowMs = Date.now();
    if (d !== sharedDb || w !== sharedAt || nowMs - sharedTime > KEEP_MS) { sharedCache = new Map(); sharedDb = d; sharedAt = w; sharedTime = nowMs; }
    if (sharedCache.has(key)) { raw = sharedCache.get(key); noteKeyRead('shared_settings', key); }
    else {
      const row = d.get('SELECT value FROM shared_settings WHERE key = ?', [key]);
      raw = row && row.value !== undefined ? row.value : null;
      sharedCache.set(key, raw);
    }
  } catch (e) {
    raw = null;
  }
  if (raw === null || raw === undefined) return fallback;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}
export function setShared(key, value) {
  db().run(
    `INSERT INTO shared_settings (key, value, updated_at, updated_device, sync_status) VALUES (?, ?, ?, ?, 'pending')
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`,
    [key, JSON.stringify(value), stamp(), deviceId()]
  );
}

// PINs and passwords never go into copies of a record (change history, Deleted bin, backups). Plain objects and lists
// are cleaned a few levels deep (e.g. the bin's [{ t, k, row }]); anything else is returned as it is.
const SECRET_KEYS = ['pin', 'pin_hash', 'pin_proof', 'password_hash'];
export function stripSecrets(v, depth = 0) {
  if (!v || typeof v !== 'object' || depth > 4) return v;
  if (Array.isArray(v)) return v.map((x) => stripSecrets(x, depth + 1));
  const out = {};
  for (const [k, x] of Object.entries(v)) {
    if (SECRET_KEYS.includes(k)) continue;
    out[k] = x && typeof x === 'object' ? stripSecrets(x, depth + 1) : x;
  }
  return out;
}
// The same for a JSON text already written (older history entries and bin copies in a backup file).
export function stripSecretsText(text) {
  if (text === null || text === undefined) return text;
  return String(text).replace(/"(pin|pin_hash|pin_proof|password_hash)"\s*:\s*("(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?|null)/g, '"$1":"****"');
}

// Who did what, when, on which device and why. Never edited or deleted.
// 1.0.0 hardening: bank account numbers are never written whole into the change history (••••123).
const BANK_KEY = /^(bank_?account|bankAccount|account_?no|accountNo|account_number|bank_acc)$/i;
export function maskAccount(v) { const d = String(v === null || v === undefined ? '' : v); return d ? `••••${d.replace(/\s+/g, '').slice(-3)}` : d; }
function maskBank(o, depth = 0) {
  if (!o || typeof o !== 'object' || depth > 4) return o;
  if (Array.isArray(o)) return o.map((x) => maskBank(x, depth + 1));
  const out = {};
  for (const [k, v] of Object.entries(o)) out[k] = BANK_KEY.test(k) && v !== null && v !== undefined && v !== '' && typeof v !== 'object' ? maskAccount(v) : maskBank(v, depth + 1);
  return out;
}
export function audit({ user, action, table, recordUid, before, after, reason }) {
  try { before = stripSecrets(before); after = stripSecrets(after); } catch (e) { /* keep as given */ }
  try { before = maskBank(before); after = maskBank(after); } catch (e) { /* keep as given */ }
  db().run(
    `INSERT INTO audit_log (uid, at, user_uid, user_name, device, action, table_name, record_uid, before, after, reason, updated_at, updated_device)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [uuid('A'), stamp(), user ? user.uid : null, user ? user.name : 'System', deviceName(), action, table || null, recordUid || null,
      before === undefined || before === null ? null : JSON.stringify(before), after === undefined || after === null ? null : JSON.stringify(after),
      reason || null, stamp(), deviceId()]
  );
}

// Dates for the Saturday-Friday pay week.
// (pure calendar maths in UTC, so the phone's time zone and summer time never move a day)
export function addDays(dateText, n) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  const x = new Date(Date.UTC(y, m - 1, d + n));
  return `${x.getUTCFullYear()}-${pad(x.getUTCMonth() + 1)}-${pad(x.getUTCDate())}`;
}
export function weekStart(dateText) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  const x = new Date(Date.UTC(y, m - 1, d));
  const back = (x.getUTCDay() + 1) % 7; // Saturday = 0 days back, Sunday = 1 ... Friday = 6
  return addDays(dateText, -back);
}
export function dayName(dateText) {
  const [y, m, d] = String(dateText).slice(0, 10).split('-').map(Number);
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}
