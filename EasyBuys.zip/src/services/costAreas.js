// Shops and cost areas (v3.5).
// Operating shops: S1 = Shop 1, 29 Drasa Avenue (includes the Bakery), S2 = Shop 2, Tukani Street (Kiran Palace).
// The V M Pillay shop is closed: it is not a shop any more (not in shop pickers, tills, rosters or the Time Clock),
// only a cost area "Closed shop – V M Pillay" for its rent, loan, interest, power… Those costs are never charged to
// S1 or S2; they show as their own line "Closed shop costs" and are part of the whole-business totals.
import { db } from '../db/connection.js';
import { audit, stamp, deviceId, getSetting, setSetting } from './core.js';

export const OFFICE = 'OFFICE';
export const CLOSED = 'CLOSED';
export const CLOSED_LABEL = 'Closed shop costs';
export const NEW_FOOTER = 'Easy Buys Shopping Centre · Shop 1: 29 Drasa Avenue · Shop 2: Tukani Street · Lautoka, Fiji';

const has = (t) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]);

// Where a cost or income belongs: the two shops, the office / whole business, and the closed shop.
export function listCostAreas() {
  let shops = [];
  try { shops = db().all("SELECT code, name FROM shops WHERE active = 1 AND code IN ('S1','S2') ORDER BY sort, code"); } catch (e) { shops = []; }
  const name = (code, fallback) => { const s = shops.find((x) => x.code === code); return s ? s.name : fallback; };
  return [
    { code: 'S1', name: name('S1', 'Shop 1 - Drasa Avenue'), kind: 'shop' },
    { code: 'S2', name: name('S2', 'Shop 2 - Tukani Street'), kind: 'shop' },
    { code: OFFICE, name: 'Office / whole business', kind: 'office' },
    { code: CLOSED, name: 'Closed shop – V M Pillay', kind: 'closed' },
  ];
}
// The operating shops (S1, S2 …): active shops with a shop code (not the Bakery / Liquor departments).
export function operatingShops() {
  try { return db().all("SELECT code, name FROM shops WHERE active = 1 AND code LIKE 'S%' ORDER BY sort, code"); } catch (e) { return []; }
}
// The extra choice added to shop pickers on bills, regular bills, loans and journals.
export const CLOSED_OPTION = { value: CLOSED, label: 'Closed shop – V M Pillay' };
// Where an old shop code belongs in the accounts: the third shop (S3) is the closed shop.
export function areaFor(code) {
  if (!code || code === OFFICE) return OFFICE;
  if (code === 'S3' || code === CLOSED) return CLOSED;
  return code;
}
// Options for a drop-down or chips: value '' (or OFFICE) means the whole business.
export function costAreaOptions({ officeValue = OFFICE } = {}) {
  return listCostAreas().map((a) => ({ value: a.code === OFFICE ? officeValue : a.code, label: a.name }));
}
// Short label for a cost area code in reports and tables.
export function costAreaLabel(code) {
  if (!code || code === OFFICE) return 'Office';
  if (code === CLOSED) return CLOSED_LABEL;
  return code;
}

// ---------------------------------------------------------------- one-off v3.5 change (safe to run every start)
// S2 is shown as Tukani Street (it was "V M Pillay"); the third shop is no longer an operating shop; regular bills and
// loans that mention V M Pillay move to the closed shop, the Kiran Palace ones to S2. Nothing is deleted; every move
// is written to the change history. Returns what moved (empty when nothing had to change).
export function migrateShops35() {
  const moved = [];
  if (!has('shops')) return moved;
  const touch = (row) => (row.sync_status === 'seed' ? { st: 'seed', at: row.updated_at, dev: row.updated_device } : { st: 'pending', at: stamp(), dev: deviceId() });
  const s2 = db().get("SELECT * FROM shops WHERE code = 'S2'");
  if (s2 && /pillay/i.test(s2.name)) {
    const t = touch(s2);
    db().run('UPDATE shops SET name = ?, updated_at = ?, updated_device = ?, sync_status = ? WHERE code = ?', ['Shop 2 - Tukani Street', t.at, t.dev, t.st, 'S2']);
    moved.push({ what: 'shop', code: 'S2', from: s2.name, to: 'Shop 2 - Tukani Street' });
  }
  // The third shop: switched off once (the admin can open it again in Admin › Shops).
  if (getSetting('shops35_s3_closed', '') !== '1') {
    const s3 = db().get("SELECT * FROM shops WHERE code = 'S3'");
    if (s3 && s3.active) {
      const t = touch(s3);
      db().run('UPDATE shops SET active = 0, updated_at = ?, updated_device = ?, sync_status = ? WHERE code = ?', [t.at, t.dev, t.st, 'S3']);
      moved.push({ what: 'shop', code: 'S3', from: 'operating', to: 'not an operating shop' });
    }
    setSetting('shops35_s3_closed', '1');
  }
  // Regular bills and loans: by the words in their name (or notes).
  if (has('ap_recurring')) {
    for (const r of db().all('SELECT uid, name, notes, shop_code FROM ap_recurring')) {
      const words = `${r.name || ''} ${r.notes || ''}`;
      const to = /v\.?\s*m\.?\s*pillay/i.test(words) ? CLOSED : /kiran/i.test(words) ? 'S2' : null;
      if (!to || r.shop_code === to) continue;
      db().run("UPDATE ap_recurring SET shop_code = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [to, stamp(), deviceId(), r.uid]);
      moved.push({ what: 'regular bill / loan', uid: r.uid, name: r.name, from: r.shop_code || 'whole business', to });
    }
  }
  // The report footer still naming the old shops (only when it is the old default text).
  try {
    const t = db().get("SELECT value FROM shared_settings WHERE key = 'report_template'");
    if (t && /V M Pillay, Riffle Range/.test(t.value || '')) {
      const v = JSON.parse(t.value);
      if (/Shop 2: V M Pillay, Riffle Range · Shop 3: Kiran Palace/.test(v.footer || '')) {
        v.footer = NEW_FOOTER;
        db().run("UPDATE shared_settings SET value = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE key = 'report_template'", [JSON.stringify(v), stamp(), deviceId()]);
        moved.push({ what: 'report footer', from: 'old shop names', to: NEW_FOOTER });
      }
    }
  } catch (e) { /* layout not saved yet */ }
  if (moved.length) {
    try { audit({ user: null, action: `v3.5 shops and cost areas: ${moved.length} change(s)`, table: 'shops', after: moved }); } catch (e) { /* history is a convenience here */ }
  }
  return moved;
}
