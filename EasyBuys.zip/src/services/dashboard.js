// Live status used by the in-app dashboard and sent to the online dashboard.
import { db } from '../db/connection.js';
import { stamp, dateStr, r1, r3, hhmm, minutesBetween, getSettings, APP_VERSION, fmt } from './core.js';
import { getOpenShift, getClosedShift, getShiftWorkers, STATUS_LABEL } from './shifts.js';
import { listActiveBatches, listBatches } from './batches.js';
import { listAlerts, lowStockItems, countPendingOutbox, listPurchaseOrders, ALERT_LABEL } from './stock.js';
import { recentShifts } from './reports.js';
import { getPlan, planProgress, planSeq } from './plan.js';

// Yesterday, today and the next 6 days (same days as the Plan screen on the tablet).
function planDays() {
  const out = [];
  for (let i = -1; i <= 6; i++) {
    const d = new Date(`${dateStr()}T12:00:00`);
    d.setDate(d.getDate() + i);
    out.push(dateStr(d));
  }
  return out;
}

export function buildSnapshot() {
  const s = getSettings();
  const open = getOpenShift();
  const pending = getClosedShift();
  const shift = open || pending;
  const today = dateStr();
  const todays = listBatches({ from: today, to: today, limit: 500 });
  const finished = todays.filter((b) => b.status === 'finished');
  const good = finished.reduce((a, b) => a + (b.good || 0), 0);
  const expected = finished.reduce((a, b) => a + b.expected_pieces, 0);
  const lost = finished.reduce((a, b) => a + (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0), 0);
  const byProduct = {};
  for (const b of finished) {
    const t = (byProduct[b.product_name] = byProduct[b.product_name] || { product: b.product_name, unit: b.product_unit, good: 0, expected: 0, batches: 0 });
    t.good += b.good || 0;
    t.expected += b.expected_pieces;
    t.batches += 1;
  }
  return {
    generatedAt: stamp(),
    appVersion: APP_VERSION,
    bakery: s.bakeryName,
    location: s.locationName,
    shift: shift ? {
      code: shift.code, name: shift.shift_name, status: STATUS_LABEL[shift.status], statusKey: shift.status,
      openedAt: shift.opened_at, openedBy: shift.opened_by_name, closedAt: shift.closed_at,
    } : null,
    workers: shift ? getShiftWorkers(shift.id).map((w) => ({
      name: w.name, signedOn: hhmm(w.signed_on_at), signedOff: w.signed_off_at ? hhmm(w.signed_off_at) : null, minutes: w.minutes,
    })) : [],
    activeBatches: open ? listActiveBatches().map((b) => ({
      code: b.code, product: b.product_name, baker: b.user_name, flourKg: b.flour_kg, expected: b.expected_pieces, cut: b.cut_pieces,
      step: b.currentStep ? b.currentStep.name : '', stepSince: b.currentStep ? hhmm(b.currentStep.started_at) : '', inStepMin: b.inStepMinutes,
      next: b.nextStep ? b.nextStep.name : '', nextDue: b.dueAt ? hhmm(b.dueAt) : '', overdueMin: b.secondsToDue !== null && b.secondsToDue < 0 ? Math.round(-b.secondsToDue / 60) : 0,
      cutWeightG: b.cut_weight_g,
    })) : [],
    today: {
      date: today, batches: todays.length, finished: finished.length, good, expected, lost,
      yieldPct: expected ? r1((good / expected) * 100) : null,
      byProduct: Object.values(byProduct).map((t) => ({ ...t, yieldPct: t.expected ? r1((t.good / t.expected) * 100) : null })),
      recent: finished.slice(0, 8).map((b) => ({ code: b.code, product: b.product_name, good: b.good, expected: b.expected_pieces, finished: hhmm(b.finished_at), baker: b.user_name })),
    },
    alerts: listAlerts({ openOnly: true, limit: 30 }).map((a) => ({ time: hhmm(a.created_at), date: a.created_at.slice(0, 10), type: ALERT_LABEL[a.type] || a.type, message: a.message })),
    lowStock: lowStockItems().map((m) => ({ name: m.name, stock: fmt(m.stock, m.unit), min: fmt(m.reorder_level, m.unit), supplier: m.supplier_name || '—' })),
    stock: db().all('SELECT name, unit, stock, reorder_level FROM materials WHERE active = 1 AND track_stock = 1 ORDER BY name')
      .map((m) => ({ name: m.name, stock: r3(m.stock), unit: m.unit, min: m.reorder_level, low: m.reorder_level > 0 && m.stock <= m.reorder_level })),
    purchaseOrders: listPurchaseOrders(5).map((p) => ({ no: p.po_no, supplier: p.supplier, date: p.created_at.slice(0, 16), status: p.status, items: p.items.length })),
    recentShifts: recentShifts(10),
    outboxPending: countPendingOutbox(),
    // For changing the production plan online.
    planSeq: planSeq(),
    products: db().all('SELECT id, name, unit FROM products WHERE active = 1 ORDER BY name'),
    plans: planDays().map((d) => ({ date: d, items: Object.fromEntries(getPlan(d).map((p) => [p.product_id, p.qty])) })),
    planToday: planProgress(today).map((p) => ({ id: p.product_id, name: p.name, target: p.target, good: p.good, inProgress: p.inProgress })),
    minutesSinceShiftOpened: shift ? minutesBetween(shift.opened_at, stamp()) : null,
    // v3.9.4 the whole-business dashboard: sections chosen in Admin › Online dashboard (services/board.js).
    board: (() => { try { return require('./board.js').buildBoard(); } catch (e) { return null; } })(),
  };
}
