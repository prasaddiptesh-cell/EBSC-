// Dashboard card registry (v3.5). Any module can add a card:
//   registerCard({ id, title, icon?, roles, order?, build(period, shop, user) })
// period = { from, to } (ISO dates), shop = 'ALL' | 'S1' | 'S2'. build returns
//   { value, sub?, tone?: 'good'|'warn'|'bad', lines?: [[label, value, tone?]], nav?: { screen, params } }
// or { notSetUp: true, text? } when its data does not exist yet. A card that throws shows "Could not work this out".
// roles: the roles that see the card by default (owner and admin always see every card). The admin can change which
// roles see which cards (shared setting 'dashboard_card_roles'); each person chooses and orders their own cards
// (shared setting `dashboard_layout_<uid>`, so it follows them to every device).
import { getShared, setShared, audit } from './core.js';
import { ROLES, actsAsOwner, can } from './access.js';

const cards = new Map();
export function registerCard(card) {
  if (!card || !card.id || typeof card.build !== 'function') throw new Error('A dashboard card needs an id and a build function.');
  cards.set(card.id, { icon: '📊', roles: [], order: 100, ...card, title: card.title || card.id });
  return card.id;
}
export function unregisterCard(id) { return cards.delete(id); }
export function listCards() { return Array.from(cards.values()).sort((a, b) => (a.order - b.order) || (a.title < b.title ? -1 : 1)); }
export function getCard(id) { return cards.get(id) || null; }

const isTop = (u) => !!u && (actsAsOwner(u) || u.role === 'owner' || u.role === 'admin');
// Which roles see each card: the admin's choice, else the card's own default.
export function cardRoles() {
  const saved = getShared('dashboard_card_roles', {}) || {};
  const out = {};
  for (const c of listCards()) out[c.id] = Array.isArray(saved[c.id]) ? saved[c.id] : (c.roles || []);
  return out;
}
export function saveCardRoles(user, map) {
  if (!(isTop(user) || can(user, 'dashboard_setup'))) throw Object.assign(new Error('Only the admin can choose which roles see which cards.'), { isAppError: true });
  const clean = {};
  for (const c of listCards()) clean[c.id] = ((map || {})[c.id] || []).filter((r) => ROLES.includes(r) && r !== 'owner' && r !== 'admin');
  const before = cardRoles();
  setShared('dashboard_card_roles', clean);
  audit({ user, action: 'Changed which roles see which dashboard cards', table: 'shared_settings', recordUid: 'dashboard_card_roles', before, after: clean });
  return clean;
}
export function cardAllowed(user, id) {
  if (!user || !cards.has(id)) return false;
  if (isTop(user)) return true;
  return (cardRoles()[id] || []).includes(user.role);
}
// This person's layout: the cards they may see, in their order; hidden ones listed separately.
export function userLayout(user) {
  const saved = (user && getShared(`dashboard_layout_${user.uid}`, null)) || {};
  const allowed = listCards().filter((c) => cardAllowed(user, c.id)).map((c) => c.id);
  const order = (Array.isArray(saved.order) ? saved.order : []).filter((id) => allowed.includes(id));
  allowed.forEach((id) => { if (!order.includes(id)) order.push(id); });
  const hidden = (Array.isArray(saved.hidden) ? saved.hidden : []).filter((id) => allowed.includes(id));
  return { order, hidden, shown: order.filter((id) => !hidden.includes(id)) };
}
export function saveUserLayout(user, { order, hidden }) {
  const allowed = listCards().filter((c) => cardAllowed(user, c.id)).map((c) => c.id);
  const clean = { order: (order || []).filter((id) => allowed.includes(id)), hidden: (hidden || []).filter((id) => allowed.includes(id)) };
  setShared(`dashboard_layout_${user.uid}`, clean);
  return clean;
}
export function moveCard(user, id, dir) {
  const l = userLayout(user);
  const i = l.order.indexOf(id);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= l.order.length) return l;
  const order = l.order.slice();
  [order[i], order[j]] = [order[j], order[i]];
  saveUserLayout(user, { order, hidden: l.hidden });
  return userLayout(user);
}
export function toggleCard(user, id, on) {
  const l = userLayout(user);
  const hidden = on ? l.hidden.filter((x) => x !== id) : Array.from(new Set(l.hidden.concat([id])));
  saveUserLayout(user, { order: l.order, hidden });
  return userLayout(user);
}
// Works out one card; never throws.
export function buildCard(id, period, shop, user) {
  const c = getCard(id);
  if (!c) return { id, title: id, notSetUp: true, text: 'Not set up yet' };
  try {
    const r = c.build(period, shop || 'ALL', user) || { notSetUp: true };
    return { id, title: c.title, icon: c.icon, ...r, text: r.notSetUp ? (r.text || 'Not set up yet') : r.text };
  } catch (e) {
    try { require('./errorLog.js').logError(e, { where: `dashboard card ${id}` }); } catch (x) { /* ignore */ }
    return { id, title: c.title, icon: c.icon, notSetUp: true, error: true, text: 'Not set up yet' };
  }
}
export function buildDashboard(user, period, shop) {
  return userLayout(user).shown.map((id) => buildCard(id, period, shop, user));
}
