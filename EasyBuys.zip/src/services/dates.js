// Dates, times and periods in plain words (no React, no database) — used by DateField, TimeField and PeriodPicker.
// Dates are stored as ISO 'YYYY-MM-DD' and times as 24-hour 'HH:MM'. On screen: "Tue 13 Oct 2026", "8:30 pm".
import { dateStr, addDays, weekStart, clock, getShared } from './core.js';

export const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const MON = MONTHS.map((m) => m.slice(0, 3));
export const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const pad = (n) => String(n).padStart(2, '0');

export function daysInMonth(y, m) { return new Date(y, m, 0).getDate(); } // m = 1..12
export function isoOf(y, m, d) { return `${String(y).padStart(4, '0')}-${pad(m)}-${pad(d)}`; }
export function isIsoDate(v) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v || ''));
  if (!m) return false;
  const y = +m[1], mo = +m[2], d = +m[3];
  return mo >= 1 && mo <= 12 && d >= 1 && d <= daysInMonth(y, mo);
}
export function partsOf(iso) { const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number); return { y, m, d }; }
export function weekdayOf(iso) { const { y, m, d } = partsOf(iso); return new Date(y, m - 1, d).getDay(); }

// "Tue 13 Oct 2026" (short: "Tue 13 Oct").
export function fmtDate(iso, { year = true, weekday = true } = {}) {
  if (!isIsoDate(iso)) return iso ? String(iso) : '';
  const { y, m, d } = partsOf(iso);
  return `${weekday ? WEEKDAYS[weekdayOf(iso)] + ' ' : ''}${d} ${MON[m - 1]}${year ? ' ' + y : ''}`;
}
// "13/10/2026" – what the box shows while typing.
export function fmtDmy(iso) { if (!isIsoDate(iso)) return iso || ''; const { y, m, d } = partsOf(iso); return `${d}/${m}/${y}`; }

// Whole days from a to b (b - a).
export function daysBetween(a, b) {
  const pa = partsOf(a), pb = partsOf(b);
  return Math.round((Date.UTC(pb.y, pb.m - 1, pb.d) - Date.UTC(pa.y, pa.m - 1, pa.d)) / 86400000);
}

function monthFromWord(w) {
  const x = String(w).toLowerCase().replace(/\.$/, '');
  if (x.length < 3) return 0;
  const i = MONTHS.findIndex((m) => m.toLowerCase().startsWith(x) || x.startsWith(m.toLowerCase().slice(0, 3)));
  return i + 1;
}
function fullYear(y, today) {
  if (String(y).length === 4) return Number(y);
  if (String(y).length <= 2) { const c = Math.floor(Number(today.slice(0, 4)) / 100) * 100; return c + Number(y); }
  return NaN;
}

// Read what someone typed. Understands 2026-10-13, 13/10/2026, 13-10-26, 13.10, 13 Oct 2026, Tue 13 Oct, today, yesterday, tomorrow.
// Answers { ok: true, iso } or { ok: false, error } (error in plain words) or { ok: false, empty: true }.
export function parseDate(text, today = dateStr(clock.now())) {
  const t = String(text === null || text === undefined ? '' : text).trim();
  if (!t) return { ok: false, empty: true, error: '' };
  const low = t.toLowerCase();
  if (low === 'today' || low === 't') return { ok: true, iso: today };
  if (low === 'yesterday' || low === 'y') return { ok: true, iso: addDays(today, -1) };
  if (low === 'tomorrow') return { ok: true, iso: addDays(today, 1) };
  let y, m, d;
  let r = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(t);
  if (r) { y = +r[1]; m = +r[2]; d = +r[3]; } else if ((r = /^(\d{1,2})[-/. ](\d{1,2})(?:[-/. ](\d{2}|\d{4}))?$/.exec(t))) {
    d = +r[1]; m = +r[2]; y = r[3] ? fullYear(r[3], today) : Number(today.slice(0, 4));
  } else if ((r = /^(\d{2})(\d{2})(\d{4})$/.exec(t))) {
    d = +r[1]; m = +r[2]; y = +r[3];
  } else {
    const words = low.replace(/,/g, ' ').split(/\s+/).filter(Boolean).filter((w) => !WEEKDAYS.some((wd) => w.startsWith(wd.toLowerCase())) || /^\d/.test(w));
    if (words.length >= 2 && words.length <= 3) {
      let a = words[0], b = words[1];
      if (/^\d{1,2}(st|nd|rd|th)?$/.test(a) && monthFromWord(b)) { d = parseInt(a, 10); m = monthFromWord(b); } else if (monthFromWord(a) && /^\d{1,2}(st|nd|rd|th)?$/.test(b)) { m = monthFromWord(a); d = parseInt(b, 10); }
      if (m) y = words[2] ? (/^\d{2}$|^\d{4}$/.test(words[2]) ? fullYear(words[2], today) : NaN) : Number(today.slice(0, 4));
    }
  }
  if (m === undefined || d === undefined || !Number.isFinite(y)) return { ok: false, error: 'Type the date like 13/10/2026, or use the calendar.' };
  if (m < 1 || m > 12) return { ok: false, error: `There is no month ${m}. Months go from 1 to 12.` };
  if (y < 1900 || y > 2200) return { ok: false, error: `The year ${y} does not look right.` };
  const dim = daysInMonth(y, m);
  if (d < 1 || d > dim) return { ok: false, error: `There is no ${d} ${MONTHS[m - 1]} ${y} – ${MONTHS[m - 1]} ${y} has ${dim} days.` };
  return { ok: true, iso: isoOf(y, m, d) };
}

// A gentle warning when the date is far away (default more than 60 days). farDays = 0 / false turns it off.
export function dateWarning(iso, { today = dateStr(clock.now()), farDays = 60, min, max } = {}) {
  if (!isIsoDate(iso)) return '';
  if (min && iso < min) return `This date is before ${fmtDate(min)}.`;
  if (max && iso > max) return `This date is after ${fmtDate(max)}.`;
  if (!farDays) return '';
  const n = daysBetween(today, iso);
  if (Math.abs(n) <= farDays) return '';
  const span = Math.abs(n) >= 730 ? `${Math.round(Math.abs(n) / 365)} years` : Math.abs(n) >= 120 ? `about ${Math.round(Math.abs(n) / 30.4)} months` : `${Math.abs(n)} days`;
  return n < 0 ? `That is ${span} ago – please check the date is right.` : `That is ${span} ahead – please check the date is right.`;
}

// "Today", "Yesterday", "Tomorrow", "In 3 days", "5 days ago" – a small helper line under the date.
export function relDay(iso, today = dateStr(clock.now())) {
  if (!isIsoDate(iso)) return '';
  const n = daysBetween(today, iso);
  if (n === 0) return 'Today';
  if (n === -1) return 'Yesterday';
  if (n === 1) return 'Tomorrow';
  return n < 0 ? `${-n} days ago` : `In ${n} days`;
}

// ---------------------------------------------------------------- times
// Read a typed time: 8, 830, 0830, 8:30, 8.30, 8:30pm, 8 pm, 20:30, 12am, noon, midnight → { ok, hhmm } or { ok:false, error }.
export function parseTime(text) {
  const t = String(text === null || text === undefined ? '' : text).trim().toLowerCase().replace(/\s+/g, ' ');
  if (!t) return { ok: false, empty: true, error: '' };
  if (t === 'noon' || t === 'midday') return { ok: true, hhmm: '12:00' };
  if (t === 'midnight') return { ok: true, hhmm: '00:00' };
  const r = /^(\d{1,2})(?:[:.h ]?(\d{2}))?\s*(am|pm|a|p|a\.m\.|p\.m\.)?$/.exec(t);
  if (!r) return { ok: false, error: 'Type the time like 8:30 or 8:30 pm.' };
  let h = Number(r[1]);
  const min = r[2] === undefined ? 0 : Number(r[2]);
  const ap = r[3] ? r[3][0] : null;
  if (min > 59) return { ok: false, error: 'Minutes go from 00 to 59.' };
  if (ap) {
    if (h < 1 || h > 12) return { ok: false, error: 'With am / pm the hour goes from 1 to 12.' };
    h = (h % 12) + (ap === 'p' ? 12 : 0);
  } else if (h > 23) return { ok: false, error: 'Hours go from 0 to 23 (or use am / pm).' };
  return { ok: true, hhmm: `${pad(h)}:${pad(min)}` };
}
export function isHHMM(v) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(String(v || '')); }
// '20:30' → '20:30' (24h) or '8:30 pm' (12h).
export function fmtTime(hhmm, format = '24h') {
  if (!isHHMM(hhmm)) return hhmm || '';
  const [h, m] = hhmm.split(':').map(Number);
  if (format === '12h') return `${h % 12 === 0 ? 12 : h % 12}:${pad(m)} ${h >= 12 ? 'pm' : 'am'}`;
  return `${pad(h)}:${pad(m)}`;
}
// '24h' or '12h' – set by the admin (Admin › Settings › General), the same on every device.
export function timeFormat() {
  try { return getShared('time_format', '24h') === '12h' ? '12h' : '24h'; } catch (e) { return '24h'; }
}
export function nowHHMM(d = clock.now()) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
export function addMinutes(hhmm, n) {
  const [h, m] = (isHHMM(hhmm) ? hhmm : '08:00').split(':').map(Number);
  const t = (((h * 60 + m + n) % 1440) + 1440) % 1440;
  return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`;
}

// ---------------------------------------------------------------- periods
// The choices in every period drop-down. Weeks are pay weeks (Saturday to Friday).
export const PERIODS = [
  { value: 'today', label: 'Today' },
  { value: 'yesterday', label: 'Yesterday' },
  { value: 'thisweek', label: 'This week (Sat–Fri)' },
  { value: 'lastweek', label: 'Last week (Sat–Fri)' },
  { value: 'thismonth', label: 'This month' },
  { value: 'lastmonth', label: 'Last month' },
  { value: 'thisyear', label: 'This year' },
  { value: 'lastyear', label: 'Last year' },
  { value: 'custom', label: 'Choose dates…' },
];
const OLD_NAMES = { month: 'thismonth', week: 'thisweek', year: 'thisyear' };

// { from, to } for a period, counted from `today`. Unknown / 'custom' → null.
export function periodRange(kind, today = dateStr(clock.now())) {
  const k = OLD_NAMES[kind] || kind;
  const { y, m } = partsOf(today);
  if (k === 'today') return { from: today, to: today };
  if (k === 'yesterday') { const d = addDays(today, -1); return { from: d, to: d }; }
  if (k === 'thisweek') { const ws = weekStart(today); return { from: ws, to: addDays(ws, 6) }; }
  if (k === 'lastweek') { const ws = addDays(weekStart(today), -7); return { from: ws, to: addDays(ws, 6) }; }
  if (k === 'thismonth') return { from: isoOf(y, m, 1), to: isoOf(y, m, daysInMonth(y, m)) };
  if (k === 'lastmonth') { const py = m === 1 ? y - 1 : y, pm = m === 1 ? 12 : m - 1; return { from: isoOf(py, pm, 1), to: isoOf(py, pm, daysInMonth(py, pm)) }; }
  if (k === 'thisyear') return { from: isoOf(y, 1, 1), to: isoOf(y, 12, 31) };
  if (k === 'lastyear') return { from: isoOf(y - 1, 1, 1), to: isoOf(y - 1, 12, 31) };
  return null;
}
// Which named period a from/to pair is (or 'custom').
export function periodKind(from, to, today = dateStr(clock.now())) {
  for (const p of PERIODS) { const r = periodRange(p.value, today); if (r && r.from === from && r.to === to) return p.value; }
  return 'custom';
}
// "Sat 10 Oct – Fri 16 Oct 2026", "Tue 13 Oct 2026", "October 2026", "2026".
export function periodLabel(from, to) {
  if (!isIsoDate(from) || !isIsoDate(to)) return `${from || '?'} – ${to || '?'}`;
  if (from === to) return fmtDate(from);
  const a = partsOf(from), b = partsOf(to);
  if (a.d === 1 && a.m === 1 && b.m === 12 && b.d === 31 && a.y === b.y) return String(a.y);
  if (a.d === 1 && a.y === b.y && a.m === b.m && b.d === daysInMonth(b.y, b.m)) return `${MONTHS[a.m - 1]} ${a.y}`;
  return `${fmtDate(from, { year: a.y !== b.y })} – ${fmtDate(to)}`;
}
// Checks a from/to pair: '' when fine, otherwise the problem in plain words.
export function rangeProblem(from, to) {
  if (!isIsoDate(from)) return 'Choose the first day.';
  if (!isIsoDate(to)) return 'Choose the last day.';
  if (to < from) return 'The last day is before the first day.';
  return '';
}

// Calendar grid for a month: weeks (rows) of 7 cells starting on Sunday; cells outside the month are null.
export function monthGrid(y, m) {
  const first = new Date(y, m - 1, 1).getDay();
  const n = daysInMonth(y, m);
  const cells = Array.from({ length: first }, () => null).concat(Array.from({ length: n }, (_, i) => isoOf(y, m, i + 1)));
  while (cells.length % 7) cells.push(null);
  const rows = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
  return rows;
}
