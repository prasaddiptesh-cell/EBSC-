// v3.9.8 Start the day (owner / admin): one page to begin the day with.
//   Money now     – the bank: our cheque-book balance, what the bank should show (cheques given not yet cleared,
//                   deposits on their way), the balance last checked in the bank app; each M-PAiSA wallet; cash at
//                   each shop.
//   Coming in     – sales expected today (same weekday, last 8 weeks), staff and customers who owe us.
//   Going out     – invoices due today / overdue / this week, loans & rent, power & water bills, wages on pay day,
//                   VAT and FNPF due dates.
//   This week     – cash needed against cash expected, in plain words.
//   Orders today  – suppliers to order from today (order days, usual gap from the order history), low stock.
//   People        – who is on leave today.
//   Watch         – the urgent warnings.
// Read only; every part guarded (missing figures → that part is empty, never an error).
import { db } from '../db/connection.js';
import { dateStr, addDays, stamp } from './core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const dow = (d) => new Date(`${d}T12:00:00`).getDay();

export function mayStartDay(user) {
  return !!user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || safe(() => require('./access.js').actsAsOwner(user), false));
}

// Sales per day from the End of days (or till balances) – the same figures as the VAT return.
function dailySales(from, to) {
  const out = {};
  if (has('aronium_eods')) for (const r of safe(() => db().all("SELECT eod_date AS d, shop_code AS s, SUM(total) AS t FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ? GROUP BY eod_date, shop_code", [from, to]), [])) {
    (out[r.d] = out[r.d] || {})[r.s] = r2(r.t);
  }
  return out;
}
export function expectedSales(day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day || ''))) day = dateStr();
  const from = addDays(day, -56);
  const by = dailySales(from, addDays(day, -1));
  const same = Object.entries(by).filter(([d]) => dow(d) === dow(day));
  const shops = {};
  for (const [, per] of same) for (const [s, v] of Object.entries(per)) (shops[s] = shops[s] || []).push(v);
  const perShop = Object.fromEntries(Object.entries(shops).map(([s, l]) => [s, r2(l.reduce((a, b) => a + b, 0) / l.length)]));
  const total = r2(Object.values(perShop).reduce((a, b) => a + b, 0));
  const week = []; // the next 7 days
  for (let i = 0; i < 7; i++) {
    const d = addDays(day, i);
    const l = Object.entries(by).filter(([x]) => dow(x) === dow(d)).map(([, per]) => Object.values(per).reduce((a, b) => a + b, 0));
    week.push({ date: d, day: DAYS[dow(d)], expected: l.length ? r2(l.reduce((a, b) => a + b, 0) / l.length) : 0 });
  }
  return { day: DAYS[dow(day)], perShop, total, weeks: same.length, week, weekTotal: r2(week.reduce((a, b) => a + b.expected, 0)) };
}

export function startOfDay(today = dateStr(), user = null) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(today || '')) || Number.isNaN(Date.parse(`${today}T12:00:00`))) today = dateStr(); // a bad date never runs away
  const P = safe(() => require('../modules/bank/position.js'), null);
  const W = safe(() => require('../modules/bank/wallets.js'), null);
  const AP = safe(() => require('../modules/payables/service.js'), null);
  // ---- money now
  const acc = P ? safe(() => P.mainAccount(), null) : null;
  const pos = acc ? safe(() => P.moneyPosition(acc.uid, today), null) : null;
  const checked = acc ? safe(() => P.latestCheck('bank', acc.uid), null) : null;
  const given = pos ? pos.cheques.filter((c) => c.handed || safe(() => !!db().get('SELECT handed_date FROM cheques WHERE uid = ? AND handed_date IS NOT NULL', [c.uid]), false)) : [];
  const bank = pos ? {
    account: acc.name, book: r2(pos.book), inBank: r2(pos.inBank), chequesOut: r2(pos.chequesOut), chequesCount: pos.cheques.length,
    givenNotCleared: { count: given.length, total: r2(given.reduce((s, c) => s + c.amount, 0)), oldest: given.length ? given.map((c) => c.date).sort()[0] : null },
    writtenNotGiven: { count: pos.cheques.length - given.length, total: r2(pos.chequesOut - given.reduce((s, c) => s + c.amount, 0)) },
    inTransit: r2(pos.insTotal), lastChecked: checked ? { date: checked.check_date || checked.date, typed: r2(checked.typed), diff: r2(checked.diff) } : null,
    stale: pos.stale || 0, red: pos.red || 0,
  } : null;
  const wallets = W ? safe(() => W.listWallets(), []).map((w) => { const p = safe(() => W.walletPosition(w.uid, today), null); return p ? { name: w.name, shop: w.shop_code, balance: r2(p.balance), transit: r2(p.transitTotal) } : null; }).filter(Boolean) : [];
  const cash = P ? safe(() => P.cashOnHandAll(), []).map((c) => ({ shop: c.shop, name: c.name, onHand: r2(c.onHand), floats: r2(c.floats), total: r2(c.total) })) : [];
  // ---- coming in
  const sales = expectedSales(today);
  const owed = safe(() => { const O = require('../modules/owed/service.js'); return O.owedTotals(O.whoOwesUs({ today })); }, null);
  const customers = safe(() => require('../modules/accounting/insightReports.js').customerAccounts(today).filter((c) => !c.staff), []);
  // ---- going out
  const unpaid = AP ? safe(() => AP.listInvoices({ filter: 'unpaid', limit: 5000 }), []) : [];
  const overdue = unpaid.filter((i) => i.due_date && i.due_date < today);
  const dueToday = unpaid.filter((i) => i.due_date === today);
  const dueWeek = unpaid.filter((i) => i.due_date && i.due_date > today && i.due_date <= addDays(today, 6));
  const sum = (l, k = 'owing') => r2(l.reduce((s, x) => s + (Number(x[k]) || 0), 0));
  const regular = has('ap_recurring') ? safe(() => db().all("SELECT name, kind, amount, next_date FROM ap_recurring WHERE active = 1 AND next_date <= ? ORDER BY next_date", [addDays(today, 6)]), []).map((x) => ({ ...x, amount: r2(x.amount) })) : [];
  const bills = safe(() => require('./utilityBills.js').billBoard(today).filter((b) => ['to_confirm', 'overdue', 'due_soon'].includes(b.state)), []);
  // wages: the average of the last 4 final pay runs (net pay and FNPF / PAYE paid over), on the next pay day (Saturday)
  const wages = has('pay_runs') ? safe(() => {
    const runs = db().all("SELECT r.uid, SUM(l.net) AS net, SUM(l.gross) AS gross FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid AND l.include = 1 WHERE r.status = 'final' GROUP BY r.uid ORDER BY r.pay_date DESC LIMIT 4");
    if (!runs.length) return null;
    const avg = r2(runs.reduce((s, x) => s + (Number(x.net) || 0), 0) / runs.length);
    let d = today; for (let i = 0; i < 7 && dow(d) !== 6; i++) d = addDays(d, 1);
    return { payDay: d, expected: avg, from: runs.length };
  }, null) : null;
  const tax = safe(() => require('../modules/payroll/taxCalendar.js').taxCalendar({ today }).filter((t) => !t.done && t.due && t.due <= addDays(today, 14)).map((t) => ({ title: t.title, due: t.due, amount: t.amount === null || t.amount === undefined ? null : r2(t.amount), overdue: t.due < today })), []);
  // ---- this week: cash needed against cash expected
  const needWeek = r2(sum(overdue) + sum(dueToday) + sum(dueWeek) + regular.reduce((s, x) => s + x.amount, 0) + (wages && wages.payDay <= addDays(today, 6) ? wages.expected : 0));
  const haveNow = r2((bank ? bank.inBank - bank.chequesOut : 0) + wallets.reduce((s, w) => s + w.balance, 0) + cash.reduce((s, c) => s + c.onHand, 0));
  const expectWeek = sales.weekTotal;
  const outlook = {
    needWeek, haveNow, expectWeek, gap: r2(haveNow + expectWeek - needWeek),
    text: !needWeek && !expectWeek ? 'Not enough figures yet for a weekly outlook.'
      : haveNow + expectWeek >= needWeek ? `This week looks covered: about $${(haveNow + expectWeek).toFixed(0)} on hand and expected, $${needWeek.toFixed(0)} to pay.`
        : `Watch this week: about $${needWeek.toFixed(0)} to pay but only $${(haveNow + expectWeek).toFixed(0)} on hand and expected – short by $${(needWeek - haveNow - expectWeek).toFixed(0)}.`,
  };
  // ---- orders today
  const orderDue = safe(() => require('../modules/inventory/schedules.js').orderAlerts({ role: 'owner', uid: 'day-start', name: 'Start the day' }, { now: `${today} 23:59:00` }), []);
  const fromHistory = safe(() => require('../modules/accounting/monthReport.js').orderSuggestions({ today }).filter((o) => o.due), []);
  const low = safe(() => require('../modules/aronium/insights.js').reorderList({}).filter((g) => g.supplierUid && g.items.some((x) => x.qty > 0)).map((g) => ({ supplier: g.supplier, shop: g.shop, items: g.items.filter((x) => x.qty > 0).length, value: r2(g.total) })), []);
  // ---- people
  const leave = has('leave_requests') ? safe(() => db().all("SELECT u.name, l.from_date, l.to_date FROM leave_requests l LEFT JOIN users u ON u.uid = l.user_uid WHERE l.status = 'approved' AND l.from_date <= ? AND l.to_date >= ?", [today, today]), []) : [];
  // ---- watch
  const urgent = [];
  return {
    today, day: DAYS[dow(today)], made: stamp(),
    money: { bank, wallets, cash, walletTotal: r2(wallets.reduce((s, w) => s + w.balance, 0)), cashTotal: r2(cash.reduce((s, c) => s + c.onHand, 0)) },
    comingIn: { sales, staffOwe: owed ? owed.total : 0, staffPeople: owed ? owed.people : 0, customersOwe: r2(customers.reduce((s, c) => s + c.owing, 0)), customers: customers.length },
    goingOut: { overdue: { count: overdue.length, total: sum(overdue), list: overdue.slice(0, 8) }, today: { count: dueToday.length, total: sum(dueToday), list: dueToday.slice(0, 8) },
      week: { count: dueWeek.length, total: sum(dueWeek) }, regular, bills, wages, tax },
    outlook,
    orders: { due: orderDue.map((a) => ({ text: a.text, sub: a.sub || null })), fromHistory, low },
    people: { leave },
    urgent: user ? safe(() => require('./alerts.js').collectAlerts(user).filter((a) => a.level === 'urgent').slice(0, 8).map((a) => ({ text: a.text, sub: a.sub || null, nav: a.nav || null })), []) : urgent,
  };
}
