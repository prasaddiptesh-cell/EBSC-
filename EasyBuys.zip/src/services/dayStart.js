// v3.9.8 Start the day (owner / admin): one page to begin the day with.
//   Money now     – the bank: our cheque-book balance, what the bank should show (cheques given not yet cleared,
//                   deposits on their way), the balance last checked in the bank app; each M-PAiSA wallet; cash at
//                   each shop.
//   Coming in     – sales expected today (same weekday, last 8 weeks), staff and customers who owe us.
//   Going out     – invoices due today / overdue / this week, loans & rent, power & water bills, wages on pay day,
//                   VAT and FNPF due dates.
//   This week     – cash needed against cash expected, in plain words.
//   Orders today  – suppliers to order from today (order days, usual gap from the order history), low stock.
//   People        – who is on leave today.
//   Watch         – the urgent warnings.
// Read only; every part guarded (missing figures → that part is empty, never an error).
import { db, keepTracked, forgetTracked, stepThrough } from '../db/connection.js';
import { dateStr, addDays, stamp } from './core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => safe(() => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), false);
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const dow = (d) => new Date(`${d}T12:00:00`).getDay();

export function mayStartDay(user) {
  return !!user && (['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole) || safe(() => require('./access.js').actsAsOwner(user), false));
}

// 1.0.0 (build 1) the "ridiculous amounts" fix. Day start added every End of day straight in, so one wrong figure from a
// till PC – a negative "sale" (a refund rung as a sale, −$1,980), a price typed 100 times too big, a figure that is not
// a number – went into the sales, the average for the weekday and the week's outlook. Now each End of day is checked
// first: impossible ones are left out and listed (with the till and the reason), never added in.
export const SANE = { maxFactor: 10, minHistory: 5 };
const median = (l) => { const s = l.slice().sort((a, b) => a - b); if (!s.length) return 0; const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
const money$ = (n) => `${n < 0 ? '−' : ''}$${Math.abs(r2(n)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
// Each End of day from..to (with 8 weeks before it as the shop's usual), checked. → { byDay: { date: { shop: total } },
// flagged: [{ date, shop, till, total, why, text }] }
export function believableSales(from, to) {
  const byDay = {};
  const flagged = [];
  if (!has('aronium_eods')) return { byDay, flagged };
  const rows = safe(() => db().all("SELECT uid, eod_date AS d, shop_code AS s, till_name, z_number, total FROM aronium_eods WHERE state <> 'void' AND eod_date BETWEEN ? AND ? ORDER BY eod_date", [addDays(from, -56), to]), []);
  const usual = {};
  for (const r of rows) { const t = Number(r.total); if (Number.isFinite(t) && t > 0) (usual[r.s] = usual[r.s] || []).push(t); }
  const med = Object.fromEntries(Object.entries(usual).map(([s, l]) => [s, l.length >= SANE.minHistory ? median(l) : 0]));
  for (const r of rows) {
    if (r.d < from) continue;
    const t = Number(r.total);
    const till = r.till_name || r.s;
    let why = null;
    if (r.total === null || r.total === undefined || r.total === '' || !Number.isFinite(t)) why = 'not a number';
    else if (t < 0) why = `a negative sale (${money$(t)})`;
    else if (med[r.s] > 0 && t > med[r.s] * SANE.maxFactor) why = `${money$(t)} – about ${Math.round(t / med[r.s])} times a usual End of day (${money$(med[r.s])})`;
    if (why) { flagged.push({ uid: r.uid, date: r.d, shop: r.s, till, z: r.z_number || null, total: Number.isFinite(t) ? r2(t) : null, why, text: `${till} sent ${why}${r.z_number ? ` (Z ${r.z_number})` : ''} on ${r.d} – checked, not counted` }); continue; }
    (byDay[r.d] = byDay[r.d] || {})[r.s] = r2(((byDay[r.d] || {})[r.s] || 0) + t);
  }
  return { byDay, flagged };
}
// Sales per day from the End of days – the same figures as the VAT return, without the impossible ones.
function dailySales(from, to) { return believableSales(from, to).byDay; }
export function expectedSales(day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day || ''))) day = dateStr();
  const from = addDays(day, -56);
  const by = dailySales(from, addDays(day, -1));
  const same = Object.entries(by).filter(([d]) => dow(d) === dow(day));
  const shops = {};
  for (const [, per] of same) for (const [s, v] of Object.entries(per)) (shops[s] = shops[s] || []).push(v);
  const perShop = Object.fromEntries(Object.entries(shops).map(([s, l]) => [s, r2(l.reduce((a, b) => a + b, 0) / l.length)]));
  const total = r2(Object.values(perShop).reduce((a, b) => a + b, 0));
  const week = []; // the next 7 days
  for (let i = 0; i < 7; i++) {
    const d = addDays(day, i);
    const l = Object.entries(by).filter(([x]) => dow(x) === dow(d)).map(([, per]) => Object.values(per).reduce((a, b) => a + b, 0));
    week.push({ date: d, day: DAYS[dow(d)], expected: l.length ? r2(l.reduce((a, b) => a + b, 0) / l.length) : 0 });
  }
  return { day: DAYS[dow(day)], perShop, total, weeks: same.length, week, weekTotal: r2(week.reduce((a, b) => a + b.expected, 0)) };
}

const urgentOf = (user) => safe(() => require('./alerts.js').collectAlerts(user).filter((a) => a.level === 'urgent').slice(0, 8).map((a) => ({ text: a.text, sub: a.sub || null, nav: a.nav || null })), []);
// The same page, worked out one part at a time with a pause between (the screen keeps answering meanwhile): the
// warnings first (a module at a time), then each part of the page.
export async function startOfDayAsync(today = dateStr(), user = null, { pause } = {}) {
  if (user) { try { await require('./alerts.js').collectAlertsAsync(user, pause ? { pause } : {}); } catch (e) { /* the page says none */ } }
  return stepThrough(() => startOfDay(today, user), pause ? { pause } : {});
}
export function startOfDay(today = dateStr(), user = null) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(today || '')) || Number.isNaN(Date.parse(`${today}T12:00:00`))) today = dateStr(); // a bad date never runs away
  const P = safe(() => require('../modules/bank/position.js'), null);
  const W = safe(() => require('../modules/bank/wallets.js'), null);
  const AP = safe(() => require('../modules/payables/service.js'), null);
  // 1.0.0 round 2: each part kept until what it read changes (and at most a minute: some parts go by the clock), so
  // after a save only the parts that use it are worked out again
  const K = (name, fn) => keepTracked(`ds|${name}|${today}`, fn, { maxAgeMs: 60000 });
  // ---- money now
  const moneyNow = K('money', () => {
  const acc = P ? safe(() => P.mainAccount(), null) : null;
  const pos = acc ? safe(() => P.moneyPosition(acc.uid, today), null) : null;
  const checked = acc ? safe(() => P.latestCheck('bank', acc.uid), null) : null;
  const given = pos ? pos.cheques.filter((c) => c.handed || safe(() => !!db().get('SELECT handed_date FROM cheques WHERE uid = ? AND handed_date IS NOT NULL', [c.uid]), false)) : [];
  const bank = pos ? {
    account: acc.name, book: r2(pos.book), inBank: r2(pos.inBank), chequesOut: r2(pos.chequesOut), chequesCount: pos.cheques.length,
    givenNotCleared: { count: given.length, total: r2(given.reduce((s, c) => s + c.amount, 0)), oldest: given.length ? given.map((c) => c.date).sort()[0] : null },
    writtenNotGiven: { count: pos.cheques.length - given.length, total: r2(pos.chequesOut - given.reduce((s, c) => s + c.amount, 0)) },
    inTransit: r2(pos.insTotal), lastChecked: checked ? { date: checked.check_date || checked.date, typed: r2(checked.typed), diff: r2(checked.diff) } : null,
    stale: pos.stale || 0, red: pos.red || 0,
  } : null;
  const wallets = W ? safe(() => W.listWallets(), []).map((w) => { const p = safe(() => W.walletPosition(w.uid, today), null); return p ? { name: w.name, shop: w.shop_code, balance: r2(p.balance), transit: r2(p.transitTotal) } : null; }).filter(Boolean) : [];
  const cash = P ? safe(() => P.cashOnHandAll(), []).map((c) => ({ shop: c.shop, name: c.name, onHand: r2(c.onHand), floats: r2(c.floats), total: r2(c.total) })) : [];
  return { bank, wallets, cash };
  });
  const { bank, wallets, cash } = moneyNow;
  // ---- coming in
  const sales = K('sales', () => expectedSales(today));
  const owed = K('owed', () => safe(() => { const O = require('../modules/owed/service.js'); return O.owedTotals(O.whoOwesUs({ today })); }, null));
  const customers = K('customers', () => safe(() => require('../modules/accounting/insightReports.js').customerAccounts(today).filter((c) => !c.staff), []));
  // ---- going out
  const unpaid = AP ? K('unpaid', () => safe(() => AP.listInvoices({ filter: 'unpaid', limit: 5000 }), [])) : [];
  const overdue = unpaid.filter((i) => i.due_date && i.due_date < today);
  const dueToday = unpaid.filter((i) => i.due_date === today);
  const dueWeek = unpaid.filter((i) => i.due_date && i.due_date > today && i.due_date <= addDays(today, 6));
  const sum = (l, k = 'owing') => r2(l.reduce((s, x) => s + (Number(x[k]) || 0), 0));
  const regular = K('regular', () => has('ap_recurring') ? safe(() => db().all("SELECT name, kind, amount, next_date FROM ap_recurring WHERE active = 1 AND next_date <= ? ORDER BY next_date", [addDays(today, 6)]), []).map((x) => ({ ...x, amount: r2(x.amount) })) : []);
  const bills = K('bills', () => safe(() => require('./utilityBills.js').billBoard(today).filter((b) => ['to_confirm', 'overdue', 'due_soon'].includes(b.state)), []));
  // wages: the average of the last 4 final pay runs (net pay and FNPF / PAYE paid over), on the next pay day (Saturday)
  const wages = has('pay_runs') ? K('wages', () => safe(() => {
    const runs = db().all("SELECT r.uid, SUM(l.net) AS net, SUM(l.gross) AS gross FROM pay_runs r JOIN pay_lines l ON l.run_uid = r.uid AND l.include = 1 WHERE r.status = 'final' GROUP BY r.uid ORDER BY r.pay_date DESC LIMIT 4");
    if (!runs.length) return null;
    const avg = r2(runs.reduce((s, x) => s + (Number(x.net) || 0), 0) / runs.length);
    let d = today; for (let i = 0; i < 7 && dow(d) !== 6; i++) d = addDays(d, 1);
    return { payDay: d, expected: avg, from: runs.length };
  }, null)) : null;
  const tax = K('tax', () => safe(() => require('../modules/payroll/taxCalendar.js').taxCalendar({ today }).filter((t) => !t.done && t.due && t.due <= addDays(today, 14)).map((t) => ({ title: t.title, due: t.due, amount: t.amount === null || t.amount === undefined ? null : r2(t.amount), overdue: t.due < today })), []));
  // ---- this week: cash needed against cash expected
  const needWeek = r2(sum(overdue) + sum(dueToday) + sum(dueWeek) + regular.reduce((s, x) => s + x.amount, 0) + (wages && wages.payDay <= addDays(today, 6) ? wages.expected : 0));
  // 1.0.0 (build 1): the money we have is the cheque-book balance (every cheque already taken off, deposits on their way
  // counted) plus the wallets and the cash. It used to take "in the bank now" less the cheques again and left out the
  // deposits on their way, so it could go far below zero. A negative wallet or cash figure cannot be real: left out, listed.
  const haveNow = r2((bank ? bank.book : 0) + wallets.filter((w) => w.balance >= 0).reduce((s, w) => s + w.balance, 0) + cash.filter((c) => c.onHand >= 0).reduce((s, c) => s + c.onHand, 0));
  const checks = K('believable', () => believableSales(addDays(today, -7), addDays(today, -1))).flagged.map((f) => f.text)
    .concat(wallets.filter((w) => w.balance < 0).map((w) => `${w.name} shows ${money$(w.balance)} – a wallet cannot be below zero; check its transfers and fixes`))
    .concat(cash.filter((c) => c.onHand < 0).map((c) => `Cash at ${c.name || c.shop} shows ${money$(c.onHand)} – cash cannot be below zero; count the safe`));
  const expectWeek = sales.weekTotal;
  const outlook = {
    needWeek, haveNow, expectWeek, gap: r2(haveNow + expectWeek - needWeek),
    text: !needWeek && !expectWeek ? 'Not enough figures yet for a weekly outlook.'
      : haveNow + expectWeek >= needWeek ? `This week looks covered: about $${(haveNow + expectWeek).toFixed(0)} on hand and expected, $${needWeek.toFixed(0)} to pay.`
        : `Watch this week: about $${needWeek.toFixed(0)} to pay but only $${(haveNow + expectWeek).toFixed(0)} on hand and expected – short by $${(needWeek - haveNow - expectWeek).toFixed(0)}.`,
  };
  // ---- orders today
  const orderDue = K('orderDue', () => safe(() => require('../modules/inventory/schedules.js').orderAlerts({ role: 'owner', uid: 'day-start', name: 'Start the day' }, { now: `${today} 23:59:00` }), []));
  const fromHistory = K('fromHistory', () => safe(() => require('../modules/accounting/monthReport.js').orderSuggestions({ today }).filter((o) => o.due), []));
  const low = K('low', () => safe(() => require('../modules/aronium/insights.js').reorderList({}).filter((g) => g.supplierUid && g.items.some((x) => x.qty > 0)).map((g) => ({ supplier: g.supplier, shop: g.shop, items: g.items.filter((x) => x.qty > 0).length, value: r2(g.total) })), []));
  // ---- people
  const leave = K('leave', () => has('leave_requests') ? safe(() => db().all("SELECT u.name, l.from_date, l.to_date FROM leave_requests l LEFT JOIN users u ON u.uid = l.user_uid WHERE l.status = 'approved' AND l.from_date <= ? AND l.to_date >= ?", [today, today]), []) : []);
  // ---- watch
  const urgent = [];
  return {
    today, day: DAYS[dow(today)], made: stamp(),
    money: { bank, wallets, cash, walletTotal: r2(wallets.reduce((s, w) => s + w.balance, 0)), cashTotal: r2(cash.reduce((s, c) => s + c.onHand, 0)) },
    comingIn: { sales, staffOwe: owed ? owed.total : 0, staffPeople: owed ? owed.people : 0, customersOwe: r2(customers.reduce((s, c) => s + c.owing, 0)), customers: customers.length },
    goingOut: { overdue: { count: overdue.length, total: sum(overdue), list: overdue.slice(0, 8) }, today: { count: dueToday.length, total: sum(dueToday), list: dueToday.slice(0, 8) },
      week: { count: dueWeek.length, total: sum(dueWeek) }, regular, bills, wages, tax },
    outlook,
    orders: { due: orderDue.map((a) => ({ text: a.text, sub: a.sub || null })), fromHistory, low },
    people: { leave },
    checks,
    urgent: user ? K(`urgent|${user.uid}|${user.role}`, () => urgentOf(user)) : urgent,
  };
}

// 1.0.0 (build 1) "Business today" (Office › Today › the figures strip, map screen o-daystart): believable figures only –
// anything that looks wrong is listed under "Checked, not counted" instead of shown as a number.
export function businessGlance(today = dateStr()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(today || ''))) today = dateStr();
  const yday = addDays(today, -1);
  const P = safe(() => require('../modules/bank/position.js'), null);
  const W = safe(() => require('../modules/bank/wallets.js'), null);
  const AP = safe(() => require('../modules/payables/service.js'), null);
  const shops = safe(() => db().all("SELECT code, name FROM shops WHERE active = 1 AND code LIKE 'S%' ORDER BY sort, code"), []);
  const flags = [];
  // sales yesterday: the believable End of days; a shop with none – its till balances (also checked)
  const bs = believableSales(yday, yday);
  bs.flagged.forEach((f) => flags.push(f.text));
  const E = safe(() => require('../modules/till/eod.js'), null);
  const sales = shops.map((s) => {
    const eod = (bs.byDay[yday] || {})[s.code];
    if (eod !== undefined) return { shop: s.code, name: s.name, value: eod, from: 'Aronium' };
    const counts = has('till_counts') ? safe(() => db().all("SELECT * FROM till_counts WHERE status <> 'void' AND shop_code = ? AND shift_date = ?", [s.code, yday]), []) : [];
    let v = 0;
    for (const c of counts) {
      const t = E ? safe(() => E.countTotal(c), 0) : 0;
      if (!Number.isFinite(t) || t < 0) { flags.push(`${c.till_name || s.code} till balance shows ${money$(t)} on ${yday} – checked, not counted`); continue; }
      v = r2(v + t);
    }
    return { shop: s.code, name: s.name, value: v, from: counts.length ? 'till balances' : 'nothing sent' };
  });
  const cash = P ? safe(() => P.cashOnHandAll(), []) : [];
  cash.filter((c) => c.onHand < 0).forEach((c) => flags.push(`Cash at ${c.name || c.shop} shows ${money$(c.onHand)} – cash cannot be below zero; count the safe`));
  const acc = P ? safe(() => P.mainAccount(), null) : null;
  const pos = acc ? safe(() => P.moneyPosition(acc.uid, today), null) : null;
  const wallets = W ? safe(() => W.listWallets(), []).map((w) => { const p = safe(() => W.walletPosition(w.uid, today), null); return p ? { name: w.name, shop: w.shop_code, balance: r2(p.balance) } : null; }).filter(Boolean) : [];
  wallets.filter((w) => w.balance < 0).forEach((w) => flags.push(`${w.name} shows ${money$(w.balance)} – a wallet cannot be below zero; check its transfers and fixes`));
  const unpaid = AP ? safe(() => AP.listInvoices({ filter: 'unpaid', limit: 5000 }), []) : [];
  const owing = (l) => r2(l.reduce((t, i) => t + (Number(i.owing) > 0 ? Number(i.owing) : 0), 0));
  const due = unpaid.filter((i) => i.due_date && i.due_date <= addDays(today, 6));
  return {
    today, yesterday: yday, sales, salesTotal: r2(sales.reduce((t, x) => t + x.value, 0)),
    cashInSafe: r2(cash.filter((c) => c.onHand >= 0).reduce((t, c) => t + c.onHand, 0)), cash: cash.map((c) => ({ shop: c.shop, name: c.name, onHand: r2(c.onHand) })),
    bank: pos ? { name: acc.name, book: r2(pos.book), inBank: r2(pos.inBank) } : null,
    wallets, walletTotal: r2(wallets.filter((w) => w.balance >= 0).reduce((t, w) => t + w.balance, 0)),
    owedSuppliers: owing(unpaid), dueWeek: owing(due), dueWeekCount: due.length,
    flags,
  };
}

// 1.0.0 (build 1) suggestions become notifications: what the app works out as a suggestion (an order that is due from the
// order history and its products running low, a till figure that cannot be right) is given to Home as a
// warning with notify: true, so it also pops up on the phone (once – each has a fixed id per day / record).
// Owner / admin see everything; a manager only their own shop's orders.
const sugCache = new Map();
export function clearSuggestions() { sugCache.clear(); forgetTracked('ds|sug|'); }
export function suggestions(user, today = dateStr()) {
  if (!user) return [];
  const boss = ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole);
  const shop = user.shop_code || user.shopCode || null;
  if (!boss && user.role !== 'manager') return [];
  // worked out at most every 10 minutes (Home asks often; the order history and stock do not change that fast)
  const key = `${boss ? 'boss' : `mgr|${shop || ''}`}|${today}`;
  // 1.0.0 round 2: kept until what it read changes (and at most 10 minutes, as before)
  return keepTracked(`ds|sug|${key}`, () => suggestionsNow(user, today, boss, shop), { maxAgeMs: 10 * 60000 });
}
function suggestionsNow(user, today, boss, shop) {
  const mine = (s) => boss || !shop || s === shop;
  const out = [];
  // orders due from the order history (with the products running low for that supplier, from the till PCs' stock)
  const orders = safe(() => require('../modules/accounting/monthReport.js').orderSuggestions({ today }).filter((o) => (o.due || o.lowItems > 0) && mine(o.shop)), []);
  for (const o of orders.slice(0, 10)) {
    out.push({ id: `sug-order-${o.supplierUid}-${o.shop}-${today}`, level: 'warning', notify: true, area: 'Suggestions',
      text: o.due ? `Suggestion: order from ${o.name} (${o.shop})${o.next && o.next > today ? ` by ${o.next}` : ' today'}` : `Suggestion: ${o.lowItems} product${o.lowItems === 1 ? '' : 's'} from ${o.name} running low at ${o.shop} – make an order`,
      sub: `${o.every ? `Usually every ${o.every} days, about $${Math.round(o.usual)}` : `About $${Math.round(o.lowValue || o.usual || 0)}`}${o.due && o.lowItems ? ` · ${o.lowItems} item(s) running low` : ''} – last order ${o.last}`, nav: { screen: 'TodaysOrders', params: {} } });
  }
  if (boss) {
    for (const f of believableSales(addDays(today, -7), addDays(today, -1)).flagged.slice(0, 5)) {
      out.push({ id: `sug-figure-${f.uid}`, level: 'warning', notify: true, area: 'Suggestions', text: `Check: ${f.text}`, sub: 'Fix the End of day in Aronium, then look at it in Till › Aronium End of days.', nav: { screen: 'AroniumEods', params: {} } });
    }
  }
  return out;
}
