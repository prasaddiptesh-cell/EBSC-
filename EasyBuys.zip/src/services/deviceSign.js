// 1.0.0 build 1: every request to the cloud is signed with this device's pass (cloud script 12, auth_ / sign_).
//  sig = sha256( sha256(pass) | device id | kind | sentAt | sha256(JSON of the records, or "null") )
// pass = the device's own pass (cloud_token), or the cloud key on the main tablet. Once the cloud is version 12 the pass
// itself is no longer sent (only the signature), so a copy of one request cannot be used for another.
import { sha256Text } from './sha256.js';

export function passHash(pass) { return pass ? sha256Text(String(pass)) : ''; }
export function signBody(pass, deviceId, body) {
  const ph = passHash(pass);
  if (!ph) return null;
  return sha256Text([ph, String(deviceId), String(body.kind || ''), String(body.sentAt || ''), sha256Text(JSON.stringify(body.records || null))].join('|'));
}
// The real time now as "YYYY-MM-DD HH:MM:SS" (not the app's test clock): the cloud refuses requests days old.
export function sentAtNow(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
