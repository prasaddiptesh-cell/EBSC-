// Document designer (v3.5): how every kind of company document looks when it is printed, saved as PDF or sent.
// Per document type the admin can switch each part on/off, put the parts in another order, rename labels, add free
// text with placeholders ({business}, {date}, {ref}…), add extra fields, choose the look (colour, logo, text size)
// and the paper (A4, A5 or an 80 mm receipt). Every saved change is kept as a version and can be put back.
// Stored as one shared (synced) setting, so every device prints the same way. Applied by the report template.
import { getShared, setShared, audit, stamp, AppError } from './core.js';
import { reportTemplate } from './reportTemplate.js';
import { requirePerm, asService } from './guard.js';

// ---------------------------------------------------------------- document types
// folder: where the finished document is filed in Google Drive (› Documents › folder [› year › month]).
// access: 'restricted' documents (pay, contracts) are only for the roles the admin ticks; default roles below.
const MGR = ['supervisor', 'manager', 'payroll', 'admin', 'owner'];
const OFFICE = ['manager', 'admin', 'owner'];
export const DOC_TYPES = [
  { id: 'payslip', label: 'Payslip', icon: '🧾', folder: 'Payroll – Restricted', byMonth: true, access: 'restricted', roles: ['payroll', 'admin', 'owner'], kinds: ['payslips', 'payslip'], prefix: 'PS', paper: 'A4' },
  { id: 'po', label: 'Purchase order', icon: '📝', folder: 'Purchase orders', byMonth: true, access: 'normal', roles: MGR, kinds: ['po', 'po_amended'], prefix: 'PO', paper: 'A4' },
  { id: 'delivery', label: 'Delivery docket', icon: '🚚', folder: 'Delivery dockets', byMonth: true, access: 'normal', roles: MGR, kinds: ['receive', 'delivery', 'delivery_fix'], refTypes: ['delivery'], prefix: 'DD', paper: 'A4' },
  { id: 'invoice', label: 'Supplier invoice', icon: '🧾', folder: 'Supplier invoices', byMonth: true, access: 'normal', roles: MGR, kinds: ['invoice'], refTypes: ['invoice'], prefix: 'IN', paper: 'A4' },
  { id: 'payment', label: 'Payment / cheque', icon: '🏦', folder: 'Supplier payments', byMonth: true, access: 'normal', roles: OFFICE, kinds: ['payment', 'cheque'], refTypes: ['payment', 'cheque'], prefix: 'PY', paper: 'A4' },
  { id: 'receipt', label: 'Receipt', icon: '🧾', folder: 'Sales & receipts', byMonth: true, access: 'normal', roles: MGR, kinds: ['receipt', 'sale'], refTypes: ['receipt', 'regreceipt'], prefix: 'RC', paper: '80mm' },
  { id: 'deposit', label: 'Bank deposit', icon: '🏦', folder: 'Sales & receipts', byMonth: true, access: 'normal', roles: MGR, kinds: ['deposit'], refTypes: ['deposit'], prefix: 'DP', paper: 'A4' },
  { id: 'statement', label: 'Statement', icon: '📒', folder: 'Reports', byMonth: true, access: 'normal', roles: OFFICE, kinds: ['who_owes_us', 'ap_supplier_statement', 'wallet_statement', 'bank_statement'], refTypes: ['statement'], prefix: 'ST', paper: 'A4' },
  { id: 'contract', label: 'Contract / staff papers', icon: '✍️', folder: 'Payroll – Restricted', byMonth: false, access: 'restricted', roles: ['payroll', 'admin', 'owner'], kinds: ['contract', 'cert'], refTypes: ['contract'], prefix: 'CT', paper: 'A4' },
  { id: 'hr', label: 'Job applications', icon: '🗂️', folder: 'Staff papers', byMonth: false, access: 'normal', roles: ['manager', 'payroll', 'admin', 'owner'], kinds: [], refTypes: ['applicant'], prefix: 'HR', paper: 'A4' },
  { id: 'shift', label: 'Bakery shift report', icon: '🥖', folder: 'Bakery', byMonth: true, access: 'normal', roles: ['worker', ...MGR], kinds: ['shift'], prefix: 'SH', paper: 'A4' },
  { id: 'licence', label: 'Licence / permit', icon: '📜', folder: 'Licences', byMonth: false, access: 'normal', roles: OFFICE, kinds: ['licence'], refTypes: ['licence'], prefix: 'LC', paper: 'A4' },
  { id: 'vehicle', label: 'Vehicle papers', icon: '🚗', folder: 'Vehicles', byMonth: false, access: 'normal', roles: OFFICE, kinds: ['vehicle'], refTypes: ['vehicle', 'asset'], prefix: 'VH', paper: 'A4' },
  { id: 'report', label: 'Reports (all others)', icon: '📊', folder: 'Reports', byMonth: true, access: 'normal', roles: MGR, kinds: [], prefix: 'RP', paper: 'A4' },
];
export const PAPERS = [
  { id: 'A4', label: 'A4', widthPt: 595, heightPt: 842, mm: 210 },
  { id: 'A5', label: 'A5', widthPt: 420, heightPt: 595, mm: 148 },
  { id: '80mm', label: '80 mm receipt', widthPt: 227, heightPt: 0, mm: 80 },
];
export const paperOf = (id) => PAPERS.find((p) => p.id === id) || PAPERS[0];
export const docType = (id) => DOC_TYPES.find((t) => t.id === id) || DOC_TYPES[DOC_TYPES.length - 1];

// Which document type a report belongs to (rep.docType wins; then its kind; statements by name; else "report").
export function docTypeOf(rep) {
  if (!rep) return 'report';
  if (rep.docType && DOC_TYPES.some((t) => t.id === rep.docType)) return rep.docType;
  const k = String(rep.kind || '');
  const t = DOC_TYPES.find((x) => (x.kinds || []).includes(k));
  if (t) return t.id;
  if (/statement/i.test(k) || /^Statement\b/i.test(String(rep.title || ''))) return 'statement';
  return 'report';
}
// Which document type a stored document (documents table, ref_type) belongs to.
export function docTypeOfRef(refType, kind) {
  const r = String(refType || '');
  const t = DOC_TYPES.find((x) => x.id === r) || DOC_TYPES.find((x) => (x.refTypes || []).includes(r) || (x.kinds || []).includes(String(kind || '')));
  return t ? t.id : 'report';
}

// ---------------------------------------------------------------- parts
// Every document is made of these parts, in this order unless the admin changes it.
export const PARTS = [
  { key: 'header', label: 'Logo and title' },
  { key: 'business', label: 'Business name, address, TIN' },
  { key: 'info', label: 'Details (date, supplier, numbers…)' },
  { key: 'summary', label: 'Totals boxes' },
  { key: 'sections', label: 'Tables / lines' },
  { key: 'note', label: 'Notes' },
  { key: 'comment', label: 'Comments (typed when the document is made)' },
  { key: 'signatures', label: 'Signatures' },
  { key: 'photos', label: 'Photos' },
  { key: 'barcode', label: 'Barcode (Code 128 of the reference)' },
  { key: 'qr', label: 'QR code' },
  { key: 'footer', label: 'Footer' },
  { key: 'appLine', label: '"Generated by Easy Buys app" line' },
];
const PART_KEYS = PARTS.map((p) => p.key);
export const PLACEHOLDERS = [
  ['{business}', 'Business name'], ['{title}', 'Document title'], ['{ref}', 'Document reference (the barcode)'], ['{date}', 'Date printed'],
  ['{time}', 'Time printed'], ['{shop}', 'Shop'], ['{tin}', 'Business TIN'], ['{phone}', 'Business phone'], ['{email}', 'Business email'],
  ['{Label}', 'Any detail of the document by its label, e.g. {Supplier}, {Invoice no.}, {Total}'],
];
export const LOOKS = [
  { id: 'classic', label: 'Easy Buys red & blue', accent: '#DA2A2F', second: '#2F5FC4' },
  { id: 'plain', label: 'Plain black & white', accent: '#222222', second: '#444444' },
  { id: 'green', label: 'Green', accent: '#157F3B', second: '#1E5631' },
  { id: 'navy', label: 'Navy', accent: '#1F3A93', second: '#2F5FC4' },
];

export function defaultDesign(typeId) {
  const t = docType(typeId);
  return {
    parts: PART_KEYS.map((key) => ({ key, on: key !== 'qr' })), // barcode on, QR available but off
    labels: {}, // old label → new label (details, totals, table and column titles)
    extra: [], // extra fields: { label, value } (value may hold placeholders), added to the details
    texts: [], // free text blocks: { id, text } placed as part "text:<id>" in the order
    look: { theme: 'classic', logo: true, fontScale: 1, headerText: '' },
    paper: t.paper || 'A4',
    infoCols: 1, // details in 1 or 2 columns
    hideCols: [], // table columns not printed (by their title)
    askComment: false, // the preview opens with the comment box
  };
}
export const ALIGNS = ['left', 'center', 'right'];
// Cleans a design coming from the screen or an older version (unknown parts dropped, missing parts added at the end).
export function normalizeDesign(typeId, d0) {
  const base = defaultDesign(typeId);
  const d = d0 && typeof d0 === 'object' ? d0 : {};
  const texts = Array.isArray(d.texts) ? d.texts.filter((x) => x && x.id).map((x) => ({ id: String(x.id), text: String(x.text || '') })) : [];
  const valid = new Set(PART_KEYS.concat(texts.map((x) => `text:${x.id}`)));
  const seen = new Set();
  const parts = [];
  for (const p of Array.isArray(d.parts) ? d.parts : []) {
    if (!p || !valid.has(p.key) || seen.has(p.key)) continue;
    seen.add(p.key);
    // v3.9.3 where it sits: left / centre / right, the full width or half (two halves side by side).
    parts.push({ key: p.key, on: p.on !== false, ...(ALIGNS.includes(p.align) && p.align !== 'left' ? { align: p.align } : {}), ...(p.width === 'half' ? { width: 'half' } : {}) });
  }
  // A part added in a newer version goes where it belongs (after the part before it in the standard order).
  base.parts.forEach((p, i) => {
    if (seen.has(p.key)) return;
    seen.add(p.key);
    const prev = i > 0 ? parts.findIndex((x) => x.key === base.parts[i - 1].key) : -1;
    parts.splice(prev + 1, 0, p);
  });
  for (const p of texts.map((x) => ({ key: `text:${x.id}`, on: true }))) if (!seen.has(p.key)) { seen.add(p.key); parts.push(p); }
  const labels = {};
  Object.entries(d.labels || {}).forEach(([k, v]) => { if (String(k).trim() && String(v || '').trim() && String(v).trim() !== String(k).trim()) labels[String(k).trim()] = String(v).trim(); });
  const extra = (Array.isArray(d.extra) ? d.extra : []).filter((x) => x && String(x.label || '').trim()).map((x) => ({ label: String(x.label).trim(), value: String(x.value || '') }));
  const look = { ...base.look, ...(d.look || {}) };
  look.fontScale = Math.min(1.4, Math.max(0.8, Number(look.fontScale) || 1));
  if (!LOOKS.some((l) => l.id === look.theme)) look.theme = 'classic';
  look.logo = look.logo !== false;
  const hideCols = (Array.isArray(d.hideCols) ? d.hideCols : []).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 30);
  return { parts, labels, extra, texts, look, paper: PAPERS.some((p) => p.id === d.paper) ? d.paper : base.paper, infoCols: Number(d.infoCols) === 2 ? 2 : 1, hideCols, askComment: d.askComment === true };
}

// ---------------------------------------------------------------- storage (shared setting "doc_designs")
const KEY = 'doc_designs';
const MAX_VERSIONS = 20;
function all() { const s = getShared(KEY, {}) || {}; return typeof s === 'object' ? s : {}; }
export function getDesign(typeId) {
  const s = all()[typeId];
  return normalizeDesign(typeId, s && s.current);
}
export function designVersions(typeId) {
  const s = all()[typeId];
  return (s && Array.isArray(s.versions) ? s.versions : []).slice().reverse(); // newest first
}
export function saveDesign(user, typeId, design, note = '') {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!DOC_TYPES.some((t) => t.id === typeId)) throw new AppError('Unknown document type.');
  const s = all();
  const cur = s[typeId] || {};
  const clean = normalizeDesign(typeId, design);
  const before = cur.current ? normalizeDesign(typeId, cur.current) : defaultDesign(typeId);
  const versions = (Array.isArray(cur.versions) ? cur.versions : []).concat([{ at: stamp(), by: user ? user.name : 'System', note: String(note || ''), design: clean }]).slice(-MAX_VERSIONS);
  s[typeId] = { current: clean, versions };
  setShared(KEY, s);
  audit({ user, action: `Changed the ${docType(typeId).label} document layout${note ? ` (${note})` : ''}`, table: 'shared_settings', recordUid: `${KEY}:${typeId}`, before, after: clean });
  return clean;
  });
}
export function resetDesign(user, typeId) { return saveDesign(user, typeId, defaultDesign(typeId), 'back to the standard layout'); }
export function restoreDesignVersion(user, typeId, at) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const v = designVersions(typeId).find((x) => x.at === at);
  if (!v) throw new AppError('That version was not found.');
  return saveDesign(user, typeId, v.design, `version of ${String(at).slice(0, 16)} put back`);
  });
}
// Helpers for the designer screen.
export function movePart(design, key, dir) {
  const parts = design.parts.slice();
  const i = parts.findIndex((p) => p.key === key);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= parts.length) return design;
  [parts[i], parts[j]] = [parts[j], parts[i]];
  return { ...design, parts };
}
export function setPartLayout(design, key, { align, width } = {}) {
  return { ...design, parts: design.parts.map((p) => (p.key === key ? { ...p, ...(align !== undefined ? { align } : {}), ...(width !== undefined ? { width } : {}) } : p)) };
}
export function togglePart(design, key) { return { ...design, parts: design.parts.map((p) => (p.key === key ? { ...p, on: !p.on } : p)) }; }
export function addText(design, text = '') {
  const id = `t${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}`;
  const parts = design.parts.slice();
  const at = parts.findIndex((p) => p.key === 'footer');
  parts.splice(at < 0 ? parts.length : at, 0, { key: `text:${id}`, on: true });
  return { ...design, texts: design.texts.concat([{ id, text }]), parts };
}
export function removeText(design, id) { return { ...design, texts: design.texts.filter((x) => x.id !== id), parts: design.parts.filter((p) => p.key !== `text:${id}`) }; }
export const partOn = (design, key) => { const p = design.parts.find((x) => x.key === key); return !!(p && p.on); };
// Every label a document of this sample shows (so the admin can rename it).
export function labelsOf(rep) {
  const out = [];
  const add = (x) => { const s = String(x || '').trim(); if (s && !out.includes(s)) out.push(s); };
  (rep.info || []).forEach(([k]) => add(k));
  (rep.summary || []).forEach((s) => add(s.label));
  (rep.sections || []).forEach((sec) => { add(sec.title); (sec.columns || []).forEach((c) => add(c.title)); (sec.totals || []).forEach((t) => add(t.label)); });
  return out;
}

// ---------------------------------------------------------------- placeholders and applying a design
export function fillPlaceholders(text, rep, extra = {}) {
  const tpl = reportTemplate();
  const now = stamp();
  const info = {};
  (rep.info || []).forEach(([k, v]) => { info[String(k).toLowerCase()] = v; });
  (rep.summary || []).forEach((s) => { info[String(s.label).toLowerCase()] = s.value; });
  const base = { business: tpl.businessName, title: rep.title || '', ref: extra.ref || rep.ref || '', date: now.slice(0, 10), time: now.slice(11, 16), shop: info.shop || info['deliver to'] || '',
    tin: tpl.tin || '', phone: tpl.phone || '', email: tpl.email || '' };
  return String(text || '').replace(/\{([^{}]{1,40})\}/g, (m, name) => {
    const k = name.trim();
    if (Object.prototype.hasOwnProperty.call(base, k)) return String(base[k]);
    const v = info[k.toLowerCase()];
    return v === undefined || v === null ? m : String(v);
  });
}
// The report with the design applied (labels renamed, extra fields added). The parts order, look and paper travel
// with it as `_design` for the page maker (src/services/export.js).
export function applyDesign(rep, design, { ref = '' } = {}) {
  if (!rep) return rep;
  const d = design || getDesign(docTypeOf(rep));
  const L = (s) => (s && d.labels[String(s).trim()] ? d.labels[String(s).trim()] : s);
  const info = (rep.info || []).map(([k, v]) => [L(k), v]).concat(d.extra.map((x) => [x.label, fillPlaceholders(x.value, rep, { ref })]));
  const summary = (rep.summary || []).map((s) => ({ ...s, label: L(s.label) }));
  const hidden = new Set((d.hideCols || []).map((x) => String(x).trim().toLowerCase()));
  const keep = (c) => !hidden.has(String(c.title || '').trim().toLowerCase()) && !hidden.has(String(L(c.title) || '').trim().toLowerCase());
  const sections = (rep.sections || []).map((sec) => {
    const cols = (sec.columns || []).filter((c, i) => i === 0 || keep(c)); // the first column always stays
    return { ...sec, title: L(sec.title), columns: (cols.length ? cols : sec.columns || []).map((c) => ({ ...c, title: L(c.title) })), ...(sec.totals ? { totals: sec.totals.map((t) => ({ ...t, label: L(t.label) })) } : {}) };
  });
  const texts = d.texts.map((x) => ({ id: x.id, text: fillPlaceholders(x.text, rep, { ref }) }));
  return { ...rep, info, summary, sections, _design: { ...d, texts } };
}
