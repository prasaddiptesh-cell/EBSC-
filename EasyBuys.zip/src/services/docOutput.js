// One step before any document is turned into a page, PDF, Excel or printout: the report layout (business details,
// columns), the payslip print settings (printed / sent copies only), the document designer (parts, labels, extra
// fields, free text, look, paper) and the document's identity (reference + fingerprint for the barcode).
import { applyTemplate } from './reportTemplate.js';
import { getDesign, applyDesign, docTypeOf, paperOf } from './docDesign.js';
import { isPayslip, payslipForPrint } from './sectionToggles.js';
import { docRef, contentHash } from './issuedDocs.js';

export function prepareDoc(rep0, { paper = null, design = null } = {}) {
  if (!rep0) return null;
  if (rep0._prepared && (!paper || paper === rep0._paper)) return rep0;
  const src = rep0._source || rep0;
  let rep = applyTemplate(src);
  const typeId = docTypeOf(rep);
  const d = design || getDesign(typeId);
  const p = paperOf(paper || d.paper).id;
  if (isPayslip(rep)) rep = payslipForPrint(rep, p === '80mm' ? '80mm' : 'pdf');
  const ref = docRef(rep);
  rep = applyDesign(rep, d, { ref });
  const hash = contentHash(rep);
  const identity = { ref, hash, check: hash.slice(0, 8).toUpperCase(), code: `EBD-${ref}-${hash.slice(0, 8).toUpperCase()}`, docType: typeId };
  return { ...rep, _prepared: true, _paper: p, _typeId: typeId, _identity: identity, _source: src };
}

// Height of an 80 mm receipt page (points): thermal paper is one long page.
export function thermalHeightPt(rep) {
  const r = rep && rep._prepared ? rep : prepareDoc(rep, { paper: '80mm' });
  let h = 170 + (r.info || []).length * 14 + (r.summary || []).length * 16 + 70;
  for (const sec of r.sections || []) h += 26 + (sec.rows || []).length * (sec.columns.length > 3 ? 12 * sec.columns.length + 6 : 16);
  h += (r.images || []).length * 220 + (r.signatures ? 90 : 0) + ((r._design && r._design.texts) || []).length * 40;
  return Math.max(300, Math.ceil(h));
}
export function pageSizePt(rep) {
  const p = paperOf(rep && rep._paper);
  return { width: p.widthPt, height: p.heightPt || thermalHeightPt(rep) };
}
// Searchable details of a finished document, read from what it shows (supplier / employee, number, shop, amount).
const pick = (pairs, names) => { for (const n of names) { const f = pairs.find(([k]) => String(k).trim().toLowerCase() === n); if (f && String(f[1] || '').trim()) return String(f[1]).trim(); } return ''; };
const titleNumber = (t) => { const m = /\b([A-Z]{0,4}-?\d[\w-]*)\b/.exec(String(t || '')); return m ? m[1] : ''; };
export function docMetaFromRep(rep) {
  const info = (rep.info || []).map(([k, v]) => [k, v]);
  const sum = (rep.summary || []).map((s) => [s.label, s.value]);
  const amountText = pick(sum, ['total', 'amount', 'net', 'net pay', 'total incl. vat', 'balance', 'to pay']) || pick(info, ['amount', 'total']);
  const amount = amountText ? Number(String(amountText).replace(/[^0-9.-]/g, '')) : null;
  return {
    party: pick(info, ['to', 'supplier', 'paid to', 'employee', 'name', 'customer', 'person', 'staff']) || '',
    number: pick(info, ['invoice no.', 'order no.', 'slip no.', 'cheque no.', 'number', 'receipt no.', 'licence no.', 'statement no.']) || titleNumber(rep.title),
    shop_code: pick(info, ['shop', 'deliver to']) || '',
    amount: Number.isFinite(amount) ? amount : null,
  };
}
