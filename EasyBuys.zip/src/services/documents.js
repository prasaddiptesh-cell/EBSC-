// Documents kept by the app (licence copies, applications, the company contract, signed contracts…).
// The file is kept on the device that added it and a copy goes to Google Drive (Easy Buys › Documents),
// so any linked device can open it later. The list of documents is shared with every device.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from './core.js';
import { enqueue } from './stock.js';
import { needReason } from './access.js';
import { requirePerm, requireLogin, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());

export const DOCS_SQL = `
CREATE TABLE IF NOT EXISTS documents (
  uid TEXT PRIMARY KEY,
  ref_type TEXT NOT NULL,
  ref_uid TEXT,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  mime TEXT,
  size INTEGER,
  doc_date TEXT,
  notes TEXT,
  cloud_id TEXT,
  cloud_url TEXT,
  added_by TEXT,
  added_at TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  void_reason TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_documents_ref ON documents(ref_type, ref_uid);
CREATE TABLE IF NOT EXISTS doc_local (
  uid TEXT PRIMARY KEY,
  path TEXT NOT NULL
);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
// v3.5 (Drive documents): type, supplier / employee, number, shop, amount, Drive folder, access class, upload status
// and the checked fingerprint. Added to the table on start-up (src/db/columns.js). local_cleared_at stays on the device.
export const DOCS35_COLUMNS = [
  ['doc_type', 'TEXT'], ['party', 'TEXT'], ['number', 'TEXT'], ['shop_code', 'TEXT'], ['amount', 'REAL'], ['folder_path', 'TEXT'], ['access_class', 'TEXT'],
  ['upload_id', 'TEXT'], ['upload_status', 'TEXT'], ['upload_error', 'TEXT'], ['upload_tries', 'INTEGER'], ['upload_at', 'TEXT'], ['verified_at', 'TEXT'],
  ['sha256', 'TEXT'], ['file_device', 'TEXT'], ['local_cleared_at', 'TEXT'], ['issued_ref', 'TEXT'], ['issued_hash', 'TEXT'],
];
export const DOCS_SYNC = {
  documents: SYNC('uid', 'Documents', ['uid', 'ref_type', 'ref_uid', 'kind', 'name', 'mime', 'size', 'doc_date', 'notes', 'cloud_id', 'cloud_url', 'added_by', 'added_at', 'status', 'void_reason']
    .concat(DOCS35_COLUMNS.map(([c]) => c).filter((c) => c !== 'local_cleared_at'))),
};

const EXT = { 'application/pdf': 'pdf', 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx', 'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx', 'text/plain': 'txt' };
export function extFor(mime, name) {
  const m = /\.([A-Za-z0-9]{2,5})$/.exec(String(name || ''));
  return (m ? m[1].toLowerCase() : EXT[mime]) || 'bin';
}
export function mimeFor(name, fallback) {
  const e = extFor('', name);
  const back = Object.entries(EXT).find(([, x]) => x === e);
  return fallback || (back ? back[0] : 'application/octet-stream');
}

// Records the document (the file itself was already copied to `path` on this device by the platform layer).
export function recordDocument(user, { uid, refType, refUid, kind, name, mime, size, docDate, notes, path, meta35 }) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(txt(refType) && txt(kind), 'Document type missing.');
  need(txt(name), 'The document needs a name.');
  need(txt(path), 'Choose the file first.');
  const id = uid || uuid('DOC');
  const now = stamp();
  db().run(`INSERT INTO documents (uid, ref_type, ref_uid, kind, name, mime, size, doc_date, notes, added_by, added_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, [id, refType, refUid || null, kind, txt(name), mime || mimeFor(name), Number(size) || null, txt(docDate) || now.slice(0, 10), txt(notes) || null, user ? user.name : 'System', now, now, deviceId()]);
  try { // v3.5: waiting to upload, with a unique upload id (safe to retry); filed by type in Drive.
    db().run("UPDATE documents SET upload_status = 'pending', upload_id = ?, file_device = ? WHERE uid = ?", [`UP-${id}`, deviceId(), id]);
    const m = meta35 || {};
    const keys = ['doc_type', 'party', 'number', 'shop_code', 'amount', 'access_class', 'folder_path', 'issued_ref', 'issued_hash'].filter((k) => m[k] !== undefined && m[k] !== null);
    if (keys.length) db().run(`UPDATE documents SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE uid = ?`, keys.map((k) => m[k]).concat([id]));
  } catch (e) { /* columns not there yet (very old database during start-up) */ }
  db().run('INSERT OR REPLACE INTO doc_local (uid, path) VALUES (?, ?)', [id, path]);
  enqueue('doc_upload', { uid: id });
  audit({ user, action: `Document added: ${txt(name)}`, table: 'documents', recordUid: id });
  return id;
  });
}
export function getDocument(uid) {
  const d = db().get('SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.uid = ?', [uid]);
  return d || null;
}
export function listDocuments(refType, refUid, { all = false } = {}) {
  return db().all(`SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.ref_type = ? AND (? IS NULL OR d.ref_uid = ?) ${all ? '' : "AND d.status = 'active'"}
    ORDER BY d.doc_date DESC, d.added_at DESC`, [refType, refUid === undefined ? null : refUid, refUid === undefined ? null : refUid]);
}
export function setLocalPath(uid, path) { db().run('INSERT OR REPLACE INTO doc_local (uid, path) VALUES (?, ?)', [uid, path]); }
export function setCloudCopy(uid, id, url) {
  db().run("UPDATE documents SET cloud_id = ?, cloud_url = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [id, url || null, stamp(), deviceId(), uid]);
}
// Documents are never deleted: they are put aside with a reason (kept for reference).
export function archiveDocument(user, uid, reason) {
  requirePerm(user, ['settings', 'licences_manage']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const d = getDocument(uid);
  need(d && d.status === 'active', 'Not found.');
  needReason(user, reason, 'Say why it is being put aside.');
  db().run("UPDATE documents SET status = 'archived', void_reason = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(reason), stamp(), deviceId(), uid]);
  audit({ user, action: `Document put aside: ${d.name}`, table: 'documents', recordUid: uid, reason: txt(reason) });
  });
}
export function renameDocument(user, uid, { name, notes, docDate, kind }) {
  requirePerm(user, ['settings', 'licences_manage']); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const d = getDocument(uid);
  need(d, 'Not found.');
  need(txt(name), 'The document needs a name.');
  db().run("UPDATE documents SET name = ?, notes = ?, doc_date = ?, kind = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
    [txt(name), txt(notes) || null, txt(docDate) || d.doc_date, kind || d.kind, stamp(), deviceId(), uid]);
  });
}
