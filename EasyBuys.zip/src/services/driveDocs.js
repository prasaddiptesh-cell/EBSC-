// Documents in Google Drive (v3.5): every finished document is filed in a tidy folder structure
// (Documents › Supplier invoices › 2026 › 10, Purchase orders, Payroll – Restricted…), each upload is checked
// (size + SHA-256 fingerprint returned by the cloud script), uploads are safe to retry (unique upload id, the cloud
// returns the existing file for a repeated id), and every file has a status: waiting, uploading, verified,
// failed – will retry, or login needed. The tablet copy is cleared only after the upload is verified AND the
// admin-set number of days has passed (default 90); it is fetched again from Drive when someone opens it.
// Who may see each type of document is an admin setting (per type → roles), checked in the app and by the cloud.
import { db } from '../db/connection.js';
import { stamp, deviceId, getShared, setShared, audit, AppError, addDays, dateStr, getSetting } from './core.js';
import { enqueue } from './stock.js';
import { actsAsOwner, ROLES } from './access.js';
import { DOC_TYPES, docType, docTypeOfRef } from './docDesign.js';

import { DOCS35_COLUMNS } from './documents.js';
export { DOCS35_COLUMNS };

export const STATUS = {
  pending: { label: 'Waiting to upload', icon: '⏳', tone: 'warn' },
  uploading: { label: 'Uploading…', icon: '⬆️', tone: 'info' },
  verified: { label: 'In Drive ✓ checked', icon: '✅', tone: 'success' },
  failed: { label: 'Failed – will retry', icon: '⚠️', tone: 'danger' },
  login: { label: 'Login needed (link this device)', icon: '🔑', tone: 'danger' },
  unchecked: { label: 'In Drive (not checked – old cloud script)', icon: '☁️', tone: 'warn' },
};
export const statusOf = (d) => {
  if (!d) return 'pending';
  if (d.upload_status) {
    // An upload that never finished (app closed) counts as failed after 15 minutes.
    if (d.upload_status === 'uploading' && d.upload_at && Date.parse(String(d.upload_at).replace(' ', 'T')) < Date.now() - 15 * 60000) return 'failed';
    return d.upload_status;
  }
  return d.cloud_id ? 'unchecked' : 'pending';
};

// ---------------------------------------------------------------- folders
export function folderPathFor(typeId, date) {
  const t = docType(typeId);
  const d = /^\d{4}-\d{2}/.test(String(date || '')) ? String(date) : dateStr();
  return t.byMonth ? [t.folder, d.slice(0, 4), d.slice(5, 7)] : [t.folder];
}
export const folderText = (path) => ['Easy Buys', 'Documents'].concat(path || []).join(' › ');

// ---------------------------------------------------------------- settings
export const RETENTION_DEFAULT = 90;
export function docSettings() {
  const s = getShared('doc_settings', {}) || {};
  return {
    retentionDays: Number.isFinite(Number(s.retentionDays)) && Number(s.retentionDays) >= 7 ? Math.round(Number(s.retentionDays)) : RETENTION_DEFAULT,
    fileOnSend: s.fileOnSend !== false, // file every sent / printed / saved document in Drive
    previewFirst: s.previewFirst !== false,
    backupHour: Number.isFinite(Number(s.backupHour)) ? Math.min(23, Math.max(0, Math.round(Number(s.backupHour)))) : 21,
    dailyKeep: 30,
    monthlyKeep: 12,
  };
}
export function saveDocSettings(user, s) {
  const days = Math.round(Number(s.retentionDays));
  if (!Number.isFinite(days) || days < 7 || days > 3650) throw new AppError('Keep tablet copies between 7 and 3650 days.');
  const hour = Math.round(Number(s.backupHour === undefined ? 21 : s.backupHour));
  if (!Number.isFinite(hour) || hour < 0 || hour > 23) throw new AppError('Choose an hour from 0 to 23.');
  const before = docSettings();
  const clean = { retentionDays: days, fileOnSend: s.fileOnSend !== false, previewFirst: s.previewFirst !== false, backupHour: hour };
  setShared('doc_settings', clean);
  audit({ user, action: 'Changed document & backup settings', table: 'shared_settings', recordUid: 'doc_settings', before, after: clean });
  return docSettings();
}

// Visibility: per document type → roles that may see it. Owner (and admin) always see everything.
export function docVisibility() {
  const s = getShared('doc_visibility', {}) || {};
  const out = {};
  for (const t of DOC_TYPES) out[t.id] = Array.isArray(s[t.id]) ? s[t.id].filter((r) => ROLES.includes(r)) : t.roles.slice();
  return out;
}
export function saveDocVisibility(user, map) {
  if (!actsAsOwner(user)) throw new AppError('Only the owner or admin can change who sees documents.');
  const before = docVisibility();
  const clean = {};
  for (const t of DOC_TYPES) {
    const list = Array.isArray(map[t.id]) ? map[t.id] : before[t.id];
    clean[t.id] = Array.from(new Set(list.filter((r) => ROLES.includes(r)).concat(['owner', 'admin'])));
  }
  setShared('doc_visibility', clean);
  audit({ user, action: 'Changed who can see each type of document', table: 'shared_settings', recordUid: 'doc_visibility', before, after: clean });
  return clean;
}
export function canSeeDocType(user, typeId) {
  if (!user) return false;
  if (actsAsOwner(user)) return true;
  return (docVisibility()[typeId] || []).includes(user.role);
}
export const docTypeOfRow = (d) => d.doc_type || docTypeOfRef(d.ref_type, d.kind);
export const canSeeDocument = (user, d) => !!d && canSeeDocType(user, docTypeOfRow(d));

// ---------------------------------------------------------------- metadata, list and search
// Fills in the type / folder / access class of a document (older documents get them the first time they are seen).
export function describeDocument(d) {
  const typeId = docTypeOfRow(d);
  const t = docType(typeId);
  return { ...d, doc_type: typeId, typeLabel: t.label, access_class: d.access_class || t.access, folder: d.folder_path ? safeJson(d.folder_path, []) : folderPathFor(typeId, d.doc_date), status: statusOf(d) };
}
function safeJson(s, d) { try { return JSON.parse(s) || d; } catch (e) { return d; } }

export function setDocMeta(uid, meta) {
  const allowed = ['doc_type', 'party', 'number', 'shop_code', 'amount', 'access_class', 'issued_ref', 'issued_hash'];
  const keys = Object.keys(meta || {}).filter((k) => allowed.includes(k) && meta[k] !== undefined);
  const d = db().get('SELECT uid, doc_type, doc_date FROM documents WHERE uid = ?', [uid]);
  if (!d) return;
  const typeId = meta.doc_type || d.doc_type;
  const sets = keys.map((k) => `${k} = ?`).concat(['folder_path = ?', 'access_class = COALESCE(access_class, ?)', 'updated_at = ?', 'updated_device = ?', "sync_status = 'pending'"]);
  db().run(`UPDATE documents SET ${sets.join(', ')} WHERE uid = ?`, keys.map((k) => meta[k]).concat([JSON.stringify(folderPathFor(typeId || 'report', d.doc_date)), docType(typeId || 'report').access, stamp(), deviceId(), uid]));
}

export function listDriveDocuments(user, { q = '', status = 'all', type = 'all', limit = 200 } = {}) {
  const L = `%${String(q).trim().replace(/[%_]/g, '')}%`;
  const rows = db().all(`SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.status = 'active'
    AND (? = '' OR d.name LIKE ? OR d.party LIKE ? OR d.number LIKE ? OR d.notes LIKE ? OR d.cloud_id LIKE ? OR d.issued_ref LIKE ? OR d.ref_type LIKE ? OR d.shop_code LIKE ? OR d.doc_date LIKE ? OR CAST(d.amount AS TEXT) LIKE ?)
    ORDER BY COALESCE(d.doc_date, d.added_at) DESC, d.added_at DESC LIMIT 2000`, [String(q).trim(), L, L, L, L, L, L, L, L, L, L]);
  return rows.map(describeDocument)
    .filter((d) => canSeeDocument(user, d))
    .filter((d) => type === 'all' || d.doc_type === type)
    .filter((d) => status === 'all' || (status === 'waiting' ? ['pending', 'uploading'].includes(d.status) : status === 'problem' ? ['failed', 'login', 'unchecked'].includes(d.status) : d.status === status))
    .slice(0, limit);
}
export function uploadCounts() {
  const rows = db().all("SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.status = 'active'");
  const c = { pending: 0, uploading: 0, verified: 0, failed: 0, login: 0, unchecked: 0, total: rows.length, here: 0 };
  for (const d of rows) {
    const s = statusOf(d);
    // Only files kept on this device can be uploaded from here.
    if (s !== 'verified' && d.path && !d.local_cleared_at) c.here += 1;
    c[s] = (c[s] || 0) + 1;
  }
  return c;
}

// ---------------------------------------------------------------- upload states (called by the cloud sender)
const touch = (uid, sets, args) => db().run(`UPDATE documents SET ${sets}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, args.concat([stamp(), deviceId(), uid]));
export function uploadIdFor(d) { return d.upload_id || `UP-${d.uid}`; }
export function markUploading(uid) {
  const d = db().get('SELECT upload_id FROM documents WHERE uid = ?', [uid]);
  touch(uid, "upload_status = 'uploading', upload_at = ?, upload_id = COALESCE(upload_id, ?), file_device = COALESCE(file_device, ?)", [stamp(), d && d.upload_id ? d.upload_id : `UP-${uid}`, deviceId()]);
}
// The cloud's answer: { id, url, size, sha256 }. Verified only when size and fingerprint both match.
export function markUploaded(uid, local, reply) {
  if (!reply || !reply.id) throw new Error('The cloud did not return the file.');
  if (!reply.sha256) {
    touch(uid, "cloud_id = ?, cloud_url = ?, upload_status = 'unchecked', upload_error = ?", [reply.id, reply.url || null, 'Uploaded, but the cloud script is older and cannot confirm it. Paste the new cloud script (CLOUD-SETUP.md).']);
    return 'unchecked';
  }
  if (String(reply.sha256).toLowerCase() !== String(local.sha256).toLowerCase() || Number(reply.size) !== Number(local.size)) {
    touch(uid, "upload_status = 'failed', upload_error = ?, upload_tries = COALESCE(upload_tries, 0) + 1", [`The copy in Drive does not match (size ${reply.size} vs ${local.size}). It will be sent again.`]);
    throw new Error('The copy in Google Drive does not match this file – it will be sent again.');
  }
  touch(uid, "cloud_id = ?, cloud_url = ?, upload_status = 'verified', upload_error = NULL, verified_at = ?, sha256 = ?, size = ?", [reply.id, reply.url || null, stamp(), local.sha256, local.size]);
  return 'verified';
}
export function markUploadFailed(uid, message) {
  const login = /not linked|blocked|waiting for the owner|cloud key|not set|link this device/i.test(String(message || ''));
  touch(uid, 'upload_status = ?, upload_error = ?, upload_tries = COALESCE(upload_tries, 0) + 1', [login ? 'login' : 'failed', String(message || '').slice(0, 300)]);
  return login ? 'login' : 'failed';
}
// "Try again" from the Documents screen (only the device that has the file can send it).
export function retryUpload(user, uid) {
  const d = db().get('SELECT d.*, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.uid = ?', [uid]);
  if (!d) throw new AppError('Not found.');
  if (!d.path || d.local_cleared_at) throw new AppError(d.file_device && d.file_device !== deviceId() ? 'The file is on another device – it will upload from there.' : 'This file is not on this device.');
  touch(uid, "upload_status = 'pending', upload_error = NULL", []);
  enqueue('doc_upload', { uid });
  audit({ user, action: `Upload tried again: ${d.name}`, table: 'documents', recordUid: uid });
}

// ---------------------------------------------------------------- tablet copies: kept until verified + retention
// Returns the documents whose file on this device may now be removed (verified in Drive, older than the retention).
export function localCopiesToClear({ now = dateStr(), days = docSettings().retentionDays } = {}) {
  const cut = addDays(now, -days);
  return db().all(`SELECT d.uid, d.name, d.cloud_id, d.sha256, l.path, d.verified_at, d.added_at FROM documents d JOIN doc_local l ON l.uid = d.uid
    WHERE d.upload_status = 'verified' AND d.cloud_id IS NOT NULL AND d.sha256 IS NOT NULL AND d.local_cleared_at IS NULL
      AND substr(COALESCE(d.verified_at, d.added_at), 1, 10) <= ? AND substr(d.added_at, 1, 10) <= ?`, [cut, cut]);
}
export function markLocalCleared(uid) {
  db().run('DELETE FROM doc_local WHERE uid = ?', [uid]); // the device's own pointer to its copy (not business data)
  db().run('UPDATE documents SET local_cleared_at = ? WHERE uid = ?', [stamp(), uid]);
}
export function markFetched(uid, path) {
  db().run('INSERT OR REPLACE INTO doc_local (uid, path) VALUES (?, ?)', [uid, path]);
  db().run('UPDATE documents SET local_cleared_at = NULL WHERE uid = ?', [uid]);
}

// ---------------------------------------------------------------- nightly backup (main tablet)
export const isMainTablet = () => getShared('main_tablet_device', '') === deviceId();
export function mainTabletId() { return getShared('main_tablet_device', '') || ''; }
export function setMainTablet(user, on = true) {
  if (!actsAsOwner(user)) throw new AppError('Only the owner or admin can choose the main tablet.');
  const before = mainTabletId();
  setShared('main_tablet_device', on ? deviceId() : '');
  audit({ user, action: on ? 'This device is now the main tablet (nightly backups)' : 'Main tablet cleared', table: 'shared_settings', recordUid: 'main_tablet_device', before: { device: before }, after: { device: on ? deviceId() : '' } });
}
// Is a backup due now? With a main tablet set, only it backs up: once a night (from the admin-set hour), or as soon
// as possible when the last one is more than a day old. Without a main tablet every device backs up daily (as before).
export function backupDue({ now = stamp(), last = getSetting('last_backup_at', ''), main = mainTabletId(), me = deviceId(), hour = docSettings().backupHour } = {}) {
  if (main && main !== me) return false;
  const today = String(now).slice(0, 10);
  const lastDay = String(last || '').slice(0, 10);
  if (lastDay === today) return false;
  if (!main) return true;
  const h = Number(String(now).slice(11, 13));
  const yesterday = addDays(today, -1);
  return h >= hour || !lastDay || lastDay < yesterday;
}
export function backupTier(date) { return { tier: 'daily', month: String(date).slice(0, 7) }; }
// The file manifest kept with each backup: every document and photo and where its copy is.
export function backupManifest() {
  const docs = db().all(`SELECT d.uid, d.name, d.doc_type, d.ref_type, d.ref_uid, d.doc_date, d.cloud_id, d.sha256, d.size, d.upload_status, d.status, d.access_class, l.path
    FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid ORDER BY d.added_at`);
  let photos = [];
  try { photos = db().all('SELECT id, ref_type, ref_id, cloud_url, created_at FROM photos ORDER BY id'); } catch (e) { photos = []; }
  return {
    made: stamp(), device: deviceId(),
    documents: docs.map((d) => ({ uid: d.uid, name: d.name, type: d.doc_type || docTypeOfRef(d.ref_type), date: d.doc_date, drive_id: d.cloud_id || null, sha256: d.sha256 || null, size: d.size || null,
      status: d.upload_status || (d.cloud_id ? 'unchecked' : 'pending'), archived: d.status !== 'active', access: d.access_class || null, on_tablet: !!d.path })),
    photos: photos.map((p) => ({ id: p.id, ref: `${p.ref_type}:${p.ref_id}`, drive_url: p.cloud_url || null, at: p.created_at })),
    counts: { documents: docs.length, inDrive: docs.filter((d) => d.cloud_id).length, notInDrive: docs.filter((d) => !d.cloud_id).length, photos: photos.length },
  };
}
// After restoring data on a new / replaced tablet: the files to fetch back (recent documents, within the retention
// window, that are in Drive and not on this device).
export function filesToFetch({ now = dateStr(), days = docSettings().retentionDays } = {}) {
  const cut = addDays(now, -days);
  return db().all(`SELECT d.uid, d.name, d.cloud_id, d.sha256, d.size, d.doc_date FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid
    WHERE d.status = 'active' AND d.cloud_id IS NOT NULL AND l.uid IS NULL AND COALESCE(d.doc_date, substr(d.added_at, 1, 10)) >= ? ORDER BY d.doc_date DESC`, [cut]);
}
