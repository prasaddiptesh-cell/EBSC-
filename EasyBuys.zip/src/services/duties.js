// v3.9.5 End-of-shift checklists for each job (shop assistant, cashier, baker, accountant, payroll).
// The owner / admin switches each list on and edits its items (Settings › People & pay › End-of-shift checklists).
// Each person ticks their own list on the shop tablet before finishing. At the handover the cashier checks the shop
// assistants' lists; anything not done (and why) goes to To verify. Lists are by date: one run per person per day.
// The bakery's own checklists (temperatures, ovens…) stay in the Bakery as before.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, getShared, setShared } from './core.js';
import { can, actsAsOwner } from './access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const meta = () => ({ now: stamp(), dev: deviceId() });

export const DUTY_SQL = `
CREATE TABLE IF NOT EXISTS duty_lists (
  uid TEXT PRIMARY KEY,
  duty TEXT NOT NULL,
  name TEXT NOT NULL,
  items TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER,
  by_name TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE TABLE IF NOT EXISTS duty_runs (
  uid TEXT PRIMARY KEY,
  user_uid TEXT NOT NULL,
  name TEXT,
  duty TEXT NOT NULL,
  list_uid TEXT,
  run_date TEXT NOT NULL,
  shop_code TEXT,
  items TEXT,
  ticks TEXT,
  skipped TEXT,
  done_at TEXT,
  checked_by_uid TEXT, checked_by_name TEXT, checked_at TEXT, check_note TEXT, check_ok INTEGER,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_duty_runs_date ON duty_runs(run_date, shop_code);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const DUTY_SYNC = {
  duty_lists: SYNC('uid', 'Checklists', ['uid', 'duty', 'name', 'items', 'active', 'sort', 'by_name']),
  duty_runs: SYNC('uid', 'Checklists', ['uid', 'user_uid', 'name', 'duty', 'list_uid', 'run_date', 'shop_code', 'items', 'ticks', 'skipped', 'done_at',
    'checked_by_uid', 'checked_by_name', 'checked_at', 'check_note', 'check_ok']),
};

export const DUTIES = { assistant: 'Shop assistant', cashier: 'Cashier', baker: 'Baker', accountant: 'Accountant', payroll: 'Payroll' };
export const DUTY_ORDER = ['assistant', 'cashier', 'baker', 'accountant', 'payroll'];

// The starting lists (the owner changes them). Item ids stay the same when the text is edited.
export const STARTER = {
  assistant: ['Shelves faced and refilled', 'Fridges and freezers checked (temperature, doors shut)', 'Expiry dates checked on the day\'s section',
    'Floor and counters clean, rubbish out', 'Damaged or expired items put aside and noted', 'Price tags right (FCCC items checked)'],
  cashier: ['Till counted and balanced, End of day done in Aronium', 'M-PAiSA wallet checked against sales', 'Float left for the next shift',
    'Cash to the safe or deposit bag', 'Shop assistants\' checklists checked', 'Handover to the next cashier signed by both'],
  baker: ['Batches entered, wastage recorded', 'Ovens, mixers and proofer off and cleaned', 'Ingredients stored, lots labelled', 'Next day\'s plan checked', 'Benches and floor clean'],
  accountant: ['Invoices entered match the photos', 'Cheques recorded and their status updated', 'Bank and M-PAiSA checked for the day', 'Queries for the owner written down'],
  payroll: ['Timesheets checked for the week', 'Leave and advances entered', 'Pay run checked before sign-off', 'FNPF and PAYE due dates looked at'],
};

const hasTable = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'duty_runs'"); } catch (e) { return false; } };

// The starting lists are put in once (on any device; a list made on another device arrives by sync and is not doubled).
export function seedDuties() {
  if (!hasTable()) return 0;
  if (getShared('duties_seeded', '') === '1') return 0;
  const n = db().get('SELECT COUNT(*) AS n FROM duty_lists').n;
  if (n) { setShared('duties_seeded', '1'); return 0; }
  const { now, dev } = meta();
  let i = 0;
  db().transaction(() => {
    for (const d of DUTY_ORDER) {
      const items = STARTER[d].map((text, k) => ({ id: `${d}${k + 1}`, text }));
      db().run('INSERT INTO duty_lists (uid, duty, name, items, active, sort, by_name, updated_at, updated_device) VALUES (?,?,?,?,1,?,?,?,?)',
        [`DL-${d}`, d, `${DUTIES[d]} – end of shift`, JSON.stringify(items), i++, 'Easy Buys', now, dev]);
    }
  });
  setShared('duties_seeded', '1');
  return DUTY_ORDER.length;
}

export function listDutyLists({ includeOff = true } = {}) {
  if (!hasTable()) return [];
  try { seedDuties(); } catch (e) { /* lists show once the table is ready */ }
  return db().all(`SELECT * FROM duty_lists ${includeOff ? '' : 'WHERE active = 1'} ORDER BY sort, duty`).map((l) => ({ ...l, items: J(l.items, []) }));
}
export function dutyList(duty) {
  return listDutyLists({ includeOff: false }).find((l) => l.duty === duty) || null;
}
const canSetup = (u) => actsAsOwner(u) || (u && u.role === 'admin') || can(u, 'settings');
export function saveDutyList(user, { uid, duty, name, items, active }) {
  need(canSetup(user), 'Only the owner or admin can change the checklists.');
  need(DUTIES[duty], 'Choose the job.');
  const clean = (items || []).map((it) => ({ id: txt(it.id) || uuid('DI').slice(-8), text: txt(it.text) })).filter((it) => it.text);
  need(clean.length, 'Add at least one item.');
  need(clean.length <= 30, 'Up to 30 items on one list.');
  const { now, dev } = meta();
  const before = uid ? db().get('SELECT * FROM duty_lists WHERE uid = ?', [uid]) : null;
  const id = before ? before.uid : `DL-${duty}-${uuid('X').slice(-6)}`;
  // One list per job: switching a list on switches the job's other lists off.
  db().transaction(() => {
    if (active) db().run("UPDATE duty_lists SET active = 0, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE duty = ? AND uid <> ? AND active = 1", [now, dev, duty, id]);
    if (before) db().run("UPDATE duty_lists SET duty = ?, name = ?, items = ?, active = ?, by_name = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?",
      [duty, txt(name) || `${DUTIES[duty]} – end of shift`, JSON.stringify(clean), active ? 1 : 0, user.name, now, dev, id]);
    else db().run('INSERT INTO duty_lists (uid, duty, name, items, active, sort, by_name, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?)',
      [id, duty, txt(name) || `${DUTIES[duty]} – end of shift`, JSON.stringify(clean), active ? 1 : 0, DUTY_ORDER.indexOf(duty), user.name, now, dev]);
  });
  audit({ user, action: `${active ? 'Checklist' : 'Checklist (off)'}: ${DUTIES[duty]} – ${clean.length} items`, table: 'duty_lists', recordUid: id, before, after: { duty, items: clean, active } });
  return id;
}
export function setDutyListOn(user, uid, on) {
  need(canSetup(user), 'Only the owner or admin can change the checklists.');
  const l = db().get('SELECT * FROM duty_lists WHERE uid = ?', [uid]);
  need(l, 'Checklist not found.');
  return saveDutyList(user, { uid, duty: l.duty, name: l.name, items: J(l.items, []), active: on });
}

// ---------------- who does which job
// Set per person (Settings › Users or the checklist settings); otherwise from the role: bakers bake, accountants and
// payroll do theirs, shop staff are shop assistants. Managers, admin and the owner have no list unless given one.
export function dutyMap() { return getShared('staff_duties', {}) || {}; }
export function dutyOf(user) {
  if (!user) return null;
  const m = dutyMap();
  if (Object.prototype.hasOwnProperty.call(m, user.uid)) return m[user.uid] || null;
  return { worker: 'baker', staff: 'assistant', accountant: 'accountant', payroll: 'payroll' }[user.role] || null;
}
export function setDuty(byUser, userUid, duty) {
  need(canSetup(byUser) || can(byUser, 'staff_manage'), 'Only the owner, admin or a manager can change this.');
  need(!duty || DUTIES[duty], 'Choose the job.');
  setShared('staff_duties', { ...dutyMap(), [userUid]: duty || '' });
  audit({ user: byUser, action: `Checklist job set to ${duty ? DUTIES[duty] : 'none'}`, table: 'users', recordUid: userUid });
}

// ---------------- a person's list for the day
const runUid = (userUid, date, duty) => `${userUid}|${date}|${duty}`;
export function getRun(uid) {
  if (!hasTable()) return null;
  const r = db().get('SELECT * FROM duty_runs WHERE uid = ?', [uid]);
  return r ? { ...r, items: J(r.items, []), ticks: J(r.ticks, {}), skipped: J(r.skipped, {}) } : null;
}
function summary(list, run) {
  const items = run && run.items && run.items.length ? run.items : list.items;
  const ticks = run ? run.ticks : {};
  const skipped = run ? run.skipped : {};
  const ticked = items.filter((it) => ticks[it.id]).length;
  const skippedN = items.filter((it) => !ticks[it.id] && skipped[it.id]).length;
  return { items, ticks, skipped, total: items.length, ticked, skippedN, done: !!(run && run.done_at), complete: ticked + skippedN >= items.length };
}
// { duty, list, run, total, ticked, done } or null (no job / list off).
export function myDutyToday(user, date = dateStr()) {
  const duty = dutyOf(user);
  if (!duty) return null;
  const list = dutyList(duty);
  if (!list) return null;
  const run = getRun(runUid(user.uid, date, duty));
  return { duty, dutyLabel: DUTIES[duty], list, run, date, ...summary(list, run) };
}
function ensureRun(user, date, shopCode) {
  const d = myDutyToday(user, date);
  need(d, 'There is no checklist for your job. The owner or admin switches them on in Settings.');
  if (d.run) return d;
  const { now, dev } = meta();
  db().run(`INSERT OR IGNORE INTO duty_runs (uid, user_uid, name, duty, list_uid, run_date, shop_code, items, ticks, skipped, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?, '{}', '{}', ?,?)`, [runUid(user.uid, date, d.duty), user.uid, user.name, d.duty, d.list.uid, date, txt(shopCode) || user.shop_code || null, JSON.stringify(d.list.items), now, dev]);
  return myDutyToday(user, date);
}
function writeRun(uid, fields) {
  const { now, dev } = meta();
  const keys = Object.keys(fields);
  db().run(`UPDATE duty_runs SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, keys.map((k) => fields[k]).concat([now, dev, uid]));
}
export function tickDuty(user, itemId, on = true, { date = dateStr(), shopCode } = {}) {
  const d = ensureRun(user, date, shopCode);
  need(!d.done, 'This checklist is finished. Ask a manager if something has to change.');
  need(d.items.some((it) => it.id === itemId), 'That item is not on your list.');
  const ticks = { ...d.ticks };
  const skipped = { ...d.skipped };
  if (on) { ticks[itemId] = stamp(); delete skipped[itemId]; } else delete ticks[itemId];
  writeRun(d.run.uid, { ticks: JSON.stringify(ticks), skipped: JSON.stringify(skipped) });
  return myDutyToday(user, date);
}
export function skipDuty(user, itemId, reason, { date = dateStr(), shopCode } = {}) {
  need(txt(reason), 'Write why it was not done.');
  const d = ensureRun(user, date, shopCode);
  need(!d.done, 'This checklist is finished.');
  const ticks = { ...d.ticks };
  delete ticks[itemId];
  writeRun(d.run.uid, { ticks: JSON.stringify(ticks), skipped: JSON.stringify({ ...d.skipped, [itemId]: txt(reason) }) });
  return myDutyToday(user, date);
}
export function finishDuty(user, { date = dateStr(), shopCode } = {}) {
  const d = ensureRun(user, date, shopCode);
  if (d.done) return d;
  const left = d.items.filter((it) => !d.ticks[it.id] && !d.skipped[it.id]);
  need(!left.length, `${left.length} item${left.length === 1 ? '' : 's'} not ticked: tick ${left.length === 1 ? 'it' : 'them'} or write why ${left.length === 1 ? 'it was' : 'they were'} not done.`);
  writeRun(d.run.uid, { done_at: stamp() });
  audit({ user, action: `Checklist finished (${d.ticked}/${d.total}${d.skippedN ? `, ${d.skippedN} not done` : ''})`, table: 'duty_runs', recordUid: d.run.uid });
  return myDutyToday(user, date);
}

// ---------------- the team on the shift (for the cashier and the handover)
// Shop assistants who clocked in at the shop that day (or have a list started there), with their list.
export function teamDuties({ shopCode, date = dateStr(), duty = 'assistant' } = {}) {
  if (!hasTable() || !txt(shopCode)) return [];
  const list = dutyList(duty);
  if (!list) return [];
  const people = new Map();
  try {
    db().all("SELECT DISTINCT p.user_uid AS uid, u.name, u.role FROM punches p JOIN users u ON u.uid = p.user_uid WHERE p.voided = 0 AND p.type = 'IN' AND p.shop_code = ? AND substr(p.at, 1, 10) = ?", [shopCode, date])
      .forEach((p) => people.set(p.uid, { uid: p.uid, name: p.name, role: p.role }));
  } catch (e) { /* no time clock */ }
  db().all('SELECT user_uid AS uid, name FROM duty_runs WHERE run_date = ? AND shop_code = ? AND duty = ?', [date, shopCode, duty]).forEach((r) => { if (!people.has(r.uid)) people.set(r.uid, { uid: r.uid, name: r.name }); });
  const out = [];
  for (const p of people.values()) {
    if (dutyOf({ uid: p.uid, role: p.role || 'staff' }) !== duty) continue;
    const run = getRun(runUid(p.uid, date, duty));
    out.push({ ...p, run, duty, ...summary(list, run), checked: !!(run && run.checked_at), checkOk: run ? run.check_ok !== 0 : null });
  }
  return out.sort((a, b) => String(a.name).localeCompare(String(b.name)));
}
// The cashier (or a manager) checks a shop assistant's list: ok, or not ok with a note (goes to To verify).
export function checkTeamDuty(user, personUid, { date = dateStr(), ok = true, note, duty = 'assistant', shopCode } = {}) {
  need(personUid !== user.uid, 'Someone else checks your list.');
  need(ok || txt(note), 'Write what was not done.');
  let run = getRun(runUid(personUid, date, duty));
  if (!run) {
    // Not started at all: the cashier records that (a list with nothing ticked).
    const list = dutyList(duty);
    need(list, 'There is no checklist for this job.');
    const p = db().get('SELECT uid, name, shop_code FROM users WHERE uid = ?', [personUid]);
    const { now, dev } = meta();
    db().run(`INSERT OR IGNORE INTO duty_runs (uid, user_uid, name, duty, list_uid, run_date, shop_code, items, ticks, skipped, updated_at, updated_device)
      VALUES (?,?,?,?,?,?,?,?, '{}', '{}', ?,?)`, [runUid(personUid, date, duty), personUid, p ? p.name : '', duty, list.uid, date, txt(shopCode) || (p && p.shop_code) || null, JSON.stringify(list.items), now, dev]);
    run = getRun(runUid(personUid, date, duty));
  }
  writeRun(run.uid, { checked_by_uid: user.uid, checked_by_name: user.name, checked_at: stamp(), check_note: txt(note) || null, check_ok: ok ? 1 : 0 });
  audit({ user, action: `Checked ${run.name}'s checklist: ${ok ? 'done' : `not done – ${txt(note)}`}`, table: 'duty_runs', recordUid: run.uid });
  return getRun(run.uid);
}
// What stops the handover being signed: shop assistants on the shift whose list the cashier has not checked.
export function handoverDutyBlockers({ shopCode, date = dateStr() } = {}) {
  try { return teamDuties({ shopCode, date }).filter((p) => !p.checked); } catch (e) { return []; }
}

// For To verify: lists with something not done (and why), lists not finished on a past day, and lists checked "not ok".
export function dutyProblems({ from, to } = {}) {
  if (!hasTable()) return [];
  const rows = db().all('SELECT * FROM duty_runs WHERE run_date BETWEEN ? AND ? ORDER BY run_date DESC, name', [from || '0000', to || '9999']);
  const today = dateStr();
  const out = [];
  for (const r0 of rows) {
    const r = { ...r0, items: J(r0.items, []), ticks: J(r0.ticks, {}), skipped: J(r0.skipped, {}) };
    const notDone = r.items.filter((it) => !r.ticks[it.id]);
    const reasons = notDone.map((it) => `${it.text}${r.skipped[it.id] ? ` – ${r.skipped[it.id]}` : ' – not ticked'}`);
    const unfinished = !r.done_at && r.run_date < today;
    const badCheck = r.check_ok === 0;
    if (!notDone.length && !badCheck && !unfinished) continue;
    if (!r.done_at && r.run_date >= today && !badCheck) continue; // still working on it today
    out.push({ run: r, notDone, reasons, unfinished, badCheck });
  }
  return out;
}
