// Optional emails (Admin › Emails). Reports and purchase orders are always saved in Google Drive; emailing them is an
// option per kind: Off (the default), Ask each time (a "Send it?" warning on Home) or Automatic, with who gets it.
import { AppError, getShared, setShared, getSetting, audit, stamp, isEmail, deviceId, addDays, dateStr } from './core.js';
import { enqueue } from './stock.js';
import { requireLogin, requirePerm, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };

export const EMAIL_TYPES = [
  { type: 'shift_report', kind: 'report', label: 'Bakery day report', note: 'After the bakery day is closed and counted (PDF + Excel).', oldKey: 'report_emails' },
  { type: 'bakery_po', kind: 'po', label: 'Bakery low-stock order', note: 'When an ingredient reaches its minimum level.', oldKey: 'po_emails' },
  { type: 'accountant_pack', kind: 'acct_pack', label: 'Monthly accountant pack', note: 'Early each month: last month\'s books, VAT and payroll figures in one Excel file (made on the main tablet).', oldKey: 'acct_pack_emails' },
];
export const MODES = [{ value: 'off', label: 'Off' }, { value: 'ask', label: 'Ask each time' }, { value: 'auto', label: 'Automatic' }];

export function emailPrefs() {
  const saved = getShared('email_prefs', {}) || {};
  const out = {};
  EMAIL_TYPES.forEach((t) => {
    const s = saved[t.type] || {};
    const old = J(getSetting(t.oldKey, '[]'), []);
    out[t.type] = { mode: ['off', 'ask', 'auto'].includes(s.mode) ? s.mode : 'off', to: Array.isArray(s.to) ? s.to : (t.type === 'bakery_po' && !old.length ? J(getSetting('report_emails', '[]'), []) : old) };
  });
  return out;
}
export function saveEmailPref(user, type, { mode, to }) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const t = EMAIL_TYPES.find((x) => x.type === type);
  need(t, 'Unknown email.');
  need(['off', 'ask', 'auto'].includes(mode), 'Choose Off, Ask each time or Automatic.');
  const list = Array.from(new Set((to || []).map((e) => String(e).trim()).filter(Boolean)));
  const bad = list.filter((e) => !isEmail(e));
  need(!bad.length, `These do not look like email addresses: ${bad.join(', ')}`);
  need(mode === 'off' || list.length, 'Add at least one email address (or choose Off).');
  const all = { ...(getShared('email_prefs', {}) || {}), [type]: { mode, to: list } };
  setShared('email_prefs', all);
  audit({ user, action: `Emails: ${t.label} – ${MODES.find((m) => m.value === mode).label}${list.length ? ` to ${list.join(', ')}` : ''}`, table: 'shared_settings', recordUid: 'email_prefs' });
  return emailPrefs()[type];
  });
}

// Who the outbox emails for this item (empty = only saved in Drive).
export function recipientsFor(type, payload = {}) {
  const p = emailPrefs()[type];
  if (!p) return [];
  if (payload.emailNow || p.mode === 'auto') return p.to;
  return [];
}
// After an item is queued: in "Ask each time" mode, ask on Home (every device) whether to email it. The answer can be
// given on any device; the device that made the report sends it (only it has the report's data).
function asksAll() { return getShared('email_asks', {}) || {}; }
export function noteMade(type, payload, title) {
  const p = emailPrefs()[type];
  if (!p || p.mode !== 'ask') return false;
  const t = EMAIL_TYPES.find((x) => x.type === type);
  const id = `${deviceId()}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const all = asksAll();
  // Keep the list short: answered ones go after 30 days.
  Object.keys(all).forEach((k) => { if (all[k].answer && all[k].at < addDays(dateStr(), -30)) delete all[k]; });
  all[id] = { type, kind: t.kind, payload: payload || {}, title: title || t.label, device: deviceId(), at: stamp(), answer: null };
  setShared('email_asks', all);
  return true;
}
export function emailAsks() {
  const all = asksAll();
  return Object.entries(all).filter(([, a]) => !a.answer).map(([id, a]) => ({ id, ...a, to: (emailPrefs()[a.type] || {}).to || [] })).sort((a, b) => (a.at < b.at ? -1 : 1));
}
export function answerAsk(user, id, send) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const all = asksAll();
  const a = all[id];
  need(a && !a.answer, 'Already answered.');
  all[id] = { ...a, answer: send ? 'send' : 'no', answeredBy: user ? user.name : null, answeredAt: stamp() };
  setShared('email_asks', all);
  audit({ user, action: `${a.title}: ${send ? 'to be emailed' : 'not emailed'}`, table: 'shared_settings', recordUid: 'email_asks' });
  sendAnswered();
  return send;
  });
}
// On the device that made them: email the ones answered "Send" (once).
export function sendAnswered() {
  const all = asksAll();
  let n = 0;
  Object.entries(all).forEach(([id, a]) => {
    if (a.answer === 'send' && a.device === deviceId() && !a.queued) { enqueue(a.kind, { ...a.payload, emailNow: true }); all[id] = { ...a, queued: stamp() }; n += 1; }
  });
  if (n) setShared('email_asks', all);
  return n;
}

// The monthly accountant pack: on the main tablet, once a month (days 1–5), for last month.
export function packDue({ today, isMain }) {
  const p = emailPrefs().accountant_pack;
  if (!p || p.mode === 'off' || !isMain) return null;
  const d = Number(String(today).slice(8, 10));
  if (d > 5) return null;
  const first = `${String(today).slice(0, 7)}-01`;
  const to = addDays(first, -1);
  const from = `${to.slice(0, 7)}-01`;
  if (getSetting('acct_pack_month', '') === to.slice(0, 7)) return null;
  return { from, to, month: to.slice(0, 7), mode: p.mode };
}
