// Equipment list, fault reports, repairs and service history.
import { db } from '../db/connection.js';
import { AppError, stamp, r3 } from './core.js';
import { raiseAlert, addPhotos } from './stock.js';

export function listEquipment({ includeInactive = false } = {}) {
  const today = stamp().slice(0, 10);
  return db().all(`SELECT * FROM equipment ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY active DESC, name`).map((e) => {
    const open = db().all("SELECT l.*, u.name AS user_name FROM equipment_log l JOIN users u ON u.id = l.user_id WHERE equipment_id = ? AND type = 'fault' AND resolved_at IS NULL ORDER BY id DESC", [e.id]);
    const last = e.last_service_at || e.created_at;
    const due = new Date(last.slice(0, 10));
    due.setDate(due.getDate() + (e.service_days || 0));
    const dueStr = e.service_days ? due.toISOString().slice(0, 10) : null;
    return { ...e, openFaults: open, serviceDue: dueStr, serviceOverdue: !!dueStr && dueStr <= today };
  });
}
export function getEquipment(id) {
  return listEquipment({ includeInactive: true }).find((e) => e.id === id) || null;
}
export function equipmentLog(id) {
  return db().all(
    'SELECT l.*, u.name AS user_name, r.name AS resolved_name FROM equipment_log l JOIN users u ON u.id = l.user_id LEFT JOIN users r ON r.id = l.resolved_by WHERE equipment_id = ? ORDER BY l.id DESC',
    [id]
  );
}
export function saveEquipment({ id, name, service_days, last_service_at, active = true }) {
  const n = String(name || '').trim();
  if (!n) throw new AppError('Please enter the equipment name.');
  const days = Number(service_days || 0);
  if (!Number.isFinite(days) || days < 0 || days > 3650) throw new AppError('Service interval must be between 0 and 3650 days (0 = no reminders).');
  const dupe = db().get('SELECT id FROM equipment WHERE lower(name) = lower(?) AND id != ?', [n, id || 0]);
  if (dupe) throw new AppError(`"${n}" already exists.`);
  if (id) {
    db().run('UPDATE equipment SET name = ?, service_days = ?, active = ? WHERE id = ?', [n, Math.round(days), active ? 1 : 0, id]);
    return getEquipment(id);
  }
  const newId = db().run('INSERT INTO equipment (name, service_days, last_service_at, active, created_at) VALUES (?, ?, ?, ?, ?)',
    [n, Math.round(days), last_service_at || null, active ? 1 : 0, stamp()]).lastInsertRowId;
  return getEquipment(newId);
}

export function reportFault(userId, equipmentId, note, photos) {
  const e = db().get('SELECT * FROM equipment WHERE id = ?', [equipmentId]);
  if (!e) throw new AppError('Choose the equipment.');
  const n = String(note || '').trim();
  if (!n) throw new AppError('Describe the problem.');
  return db().transaction(() => {
    const id = db().run("INSERT INTO equipment_log (equipment_id, type, note, user_id, at) VALUES (?, 'fault', ?, ?, ?)", [equipmentId, n, userId, stamp()]).lastInsertRowId;
    const s = db().get("SELECT id FROM shifts WHERE status = 'open' ORDER BY id DESC LIMIT 1");
    raiseAlert({ type: 'FAULT', severity: 'bad', shiftId: s ? s.id : null, userId, message: `${e.name}: ${n}` });
    addPhotos('equipment', `fault-${id}`, photos);
    return id;
  });
}

// type: 'repair' (fixes a reported fault) or 'service' (routine service; resets the reminder).
export function recordWork(userId, equipmentId, { type, note, cost, faultId }) {
  const e = db().get('SELECT * FROM equipment WHERE id = ?', [equipmentId]);
  if (!e) throw new AppError('Equipment not found.');
  if (!['repair', 'service'].includes(type)) throw new AppError('Choose repair or service.');
  const n = String(note || '').trim();
  if (!n) throw new AppError('Describe the work done.');
  let c = null;
  if (cost !== null && cost !== undefined && cost !== '') {
    c = Number(cost);
    if (!Number.isFinite(c) || c < 0) throw new AppError('Cost cannot be negative.');
    c = r3(c);
  }
  return db().transaction(() => {
    const id = db().run('INSERT INTO equipment_log (equipment_id, type, note, cost, user_id, at, fault_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [equipmentId, type, n, c, userId, stamp(), faultId || null]).lastInsertRowId;
    if (faultId) db().run('UPDATE equipment_log SET resolved_at = ?, resolved_by = ? WHERE id = ? AND resolved_at IS NULL', [stamp(), userId, faultId]);
    if (type === 'repair' && !faultId) db().run("UPDATE equipment_log SET resolved_at = ?, resolved_by = ? WHERE equipment_id = ? AND type = 'fault' AND resolved_at IS NULL", [stamp(), userId, equipmentId]);
    if (type === 'service') db().run('UPDATE equipment SET last_service_at = ? WHERE id = ?', [stamp(), equipmentId]);
    return id;
  });
}
