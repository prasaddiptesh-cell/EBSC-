// Problem log: every error the app meets is written here (and to the change history, which goes to the cloud),
// together with the last screens that were opened, so we can see exactly where it happened.
import { db } from '../db/connection.js';
import { audit, getSetting, setSetting, APP_VERSION, deviceId, deviceName, stamp } from './core.js';

const trail = []; // last screens opened: [{ at, name }]
let currentUser = null;
const listeners = new Set();

export function setErrorUser(u) { currentUser = u || null; }
// Who is logged in on this device now (used where a deeper layer needs it, e.g. filing a document, fetching a file).
export function appUser() { return currentUser; }
export function onAppError(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// Remember each screen as it opens (kept on the device, so it survives a hard close).
export function noteScreen(name) {
  trail.push({ at: stamp(), name: String(name) });
  if (trail.length > 15) trail.shift();
  try { setSetting('last_trail', JSON.stringify(trail)); } catch (e) { /* ignore */ }
}
export function screenTrail() { return trail.slice(); }

export function logError(error, { where = '', fatal = false, screen = '', quiet = false } = {}) {
  const message = String((error && error.message) || error || 'Unknown error').slice(0, 500);
  const stack = String((error && (error.componentStack || error.stack)) || '').split('\n').slice(0, 12).join('\n').slice(0, 2000);
  const entry = { at: stamp(), message, where, fatal: !!fatal, screen: screen || (trail.length ? trail[trail.length - 1].name : '') };
  try {
    audit({ user: currentUser, action: 'app_error', table: entry.screen || where || 'app', reason: message,
      after: { where, fatal: !!fatal, version: APP_VERSION, stack, trail: trail.slice(-6).map((t) => t.name).join(' › ') } });
  } catch (e) { /* the log must never cause a second problem */ }
  // quiet: written to the log (and so to support) without a pop-up – e.g. what the daily self-check finds
  if (!quiet) listeners.forEach((fn) => { try { fn(entry, error); } catch (e) { /* ignore */ } });
  return entry;
}

export function listErrors(limit = 60) {
  try {
    return db().all("SELECT at, user_name, device, table_name, reason, after FROM audit_log WHERE action IN ('app_error', 'app_closed') ORDER BY at DESC LIMIT ?", [limit])
      .map((r) => { let x = {}; try { x = JSON.parse(r.after || '{}') || {}; } catch (e) { /* ignore */ } return { at: r.at, who: r.user_name, device: r.device, screen: r.table_name, message: r.reason, ...x }; });
  } catch (e) { return []; }
}

// "Running" flag: set while the app is open on screen, cleared when it goes to the background.
// If the app starts and the flag is still set, it closed unexpectedly last time – log that with the last screens.
export function markRunning(on) { try { setSetting('app_running', on ? '1' : '0'); } catch (e) { /* ignore */ } }
export function checkLastClose() {
  try {
    if (getSetting('app_running', '0') !== '1') return null;
    let last = [];
    try { last = JSON.parse(getSetting('last_trail', '[]')) || []; } catch (e) { last = []; }
    const where = last.length ? last[last.length - 1].name : '';
    audit({ user: null, action: 'app_closed', table: where || 'app', reason: 'The app closed unexpectedly while it was open',
      after: { version: APP_VERSION, trail: last.slice(-6).map((t) => t.name).join(' › '), lastAt: last.length ? last[last.length - 1].at : '' } });
    return { where, trail: last };
  } catch (e) { return null; }
}

// Plain-text report to send (Viber / WhatsApp / email) so the problem can be looked at.
export function problemReport({ tour } = {}) {
  const lines = [`Easy Buys problem report`, `App v${APP_VERSION} · ${safe(deviceName)} · ${safe(deviceId)}`, `Made ${stamp()}`, ''];
  if (tour && tour.length) {
    const bad = tour.filter((t) => !t.ok);
    lines.push(`Screen check: ${tour.length - bad.length} of ${tour.length} screens OK`);
    bad.forEach((t) => lines.push(`  ✗ ${t.name}: ${t.message}`));
    lines.push('');
  }
  lines.push('Last screens opened: ' + (trail.map((t) => t.name).join(' › ') || '—'), '');
  const errs = listErrors(25);
  lines.push(errs.length ? `Last ${errs.length} problem(s):` : 'No problems recorded.');
  errs.forEach((e) => {
    lines.push(`• ${e.at} [${e.screen || '—'}] ${e.message}`);
    if (e.trail) lines.push(`    path: ${e.trail}`);
    if (e.stack) lines.push('    ' + String(e.stack).split('\n').slice(0, 4).join('\n    '));
  });
  return lines.join('\n');
}
function safe(fn) { try { return fn(); } catch (e) { return '?'; } }
