// Problem log: every error the app meets is written here (and to the change history, which goes to the cloud),
// together with the last screens that were opened, so we can see exactly where it happened.
// 1.0.0 build 6 (owner, 2 Nov: "a lot of details on the report … to narrow things down and fix it"):
//   - why Android closed the app (exitInfo.js; a swipe / force stop / update is noted quietly, not as a problem),
//   - the last ~30 things the app did before (breadcrumbs.js),
//   - the phone and the app (build, Android, model, memory, storage, database, sync, who, screen size),
//   - the JS stack and the screen's component stack of each error,
//   - a short summary first, the whole report kept under ~12 KB so it fits a Viber message or an email.
import { db } from '../db/connection.js';
import { audit, getSetting, setSetting, APP_VERSION, deviceId, deviceName, stamp, minutesBetween } from './core.js';
import { crumb, crumbs, previousCrumbs, crumbLines, flushCrumbs, redact } from './breadcrumbs.js';
import { exitReasons, describeExit, matchExit, newestTs, memoryInfo, networkType, hasExitInfo } from './exitInfo.js';

const trail = []; // last screens opened: [{ at, name }]
let currentUser = null;
const listeners = new Set();
const startedMs = Date.now();
export const REPORT_MAX = 12000; // characters: fits a Viber message / email comfortably

export function setErrorUser(u) { currentUser = u || null; if (u) crumb('login', `role ${u.role || '?'}${u.shop_code ? ' shop ' + u.shop_code : ''}`); }
// Who is logged in on this device now (used where a deeper layer needs it, e.g. filing a document, fetching a file).
export function appUser() { return currentUser; }
export function onAppError(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// Remember each screen as it opens (kept on the device, so it survives a hard close). params: ids only (redacted).
export function noteScreen(name, params) {
  trail.push({ at: stamp(), name: String(name) });
  if (trail.length > 15) trail.shift();
  crumb('screen', String(name), params && typeof params === 'object' && Object.keys(params).length ? params : undefined);
  try { setSetting('last_trail', JSON.stringify(trail)); } catch (e) { /* ignore */ }
}
export function screenTrail() { return trail.slice(); }

const STACK_MAX = 2500;
export function logError(error, { where = '', fatal = false, screen = '', quiet = false, componentStack = '' } = {}) {
  const message = String((error && error.message) || error || 'Unknown error').slice(0, 500);
  // (the stack's first line repeats the message: left out)
  const stack = String((error && error.stack) || '').split('\n').filter((l, i) => !(i === 0 && l.includes(message.slice(0, 60)))).slice(0, 25).join('\n').slice(0, STACK_MAX);
  const comp = String(componentStack || (error && error.componentStack) || '').split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 15).join('\n').slice(0, 1200);
  const entry = { at: stamp(), message, where, fatal: !!fatal, screen: screen || (trail.length ? trail[trail.length - 1].name : '') };
  crumb(fatal ? 'FATAL' : 'error', `${where ? where + ': ' : ''}${message}`);
  try {
    audit({ user: currentUser, action: 'app_error', table: entry.screen || where || 'app', reason: message,
      after: { where, fatal: !!fatal, version: APP_VERSION, build: buildLabel(), stack, componentStack: comp || undefined,
        trail: trail.slice(-6).map((t) => t.name).join(' › '), crumbs: crumbLines(crumbs(), 12).join('\n') } });
  } catch (e) { /* the log must never cause a second problem */ }
  try { flushCrumbs(); } catch (e) { /* ignore */ }
  // quiet: written to the log (and so to support) without a pop-up – e.g. what the daily self-check finds
  if (!quiet) listeners.forEach((fn) => { try { fn(entry, error); } catch (e) { /* ignore */ } });
  return entry;
}

export function listErrors(limit = 60) {
  try {
    return db().all("SELECT at, user_name, device, table_name, reason, after FROM audit_log WHERE action IN ('app_error', 'app_closed') ORDER BY at DESC LIMIT ?", [limit])
      .map((r) => { let x = {}; try { x = JSON.parse(r.after || '{}') || {}; } catch (e) { /* ignore */ } return { at: r.at, who: r.user_name, device: r.device, screen: r.table_name, message: r.reason, ...x }; });
  } catch (e) { return []; }
}

// "Running" flag: set while the app is open on screen, cleared when it goes to the background.
// If the app starts and the flag is still set, it closed unexpectedly last time – log that with the last screens,
// what the app was doing, and Android's own reason.
export function markRunning(on) {
  try { setSetting('app_running', on ? '1' : '0'); } catch (e) { /* ignore */ }
  crumb('app', on ? 'on screen' : 'to the background');
  if (!on) { try { flushCrumbs(); } catch (e) { /* ignore */ } }
}
export function checkLastClose() {
  try {
    // Android's reasons: always move the "seen" mark on, so an old record is never matched to a later close.
    let exit = null;
    try {
      const recs = exitReasons(5);
      const seen = Number(getSetting('exit_seen_ts', '0')) || 0;
      const m = matchExit(recs, seen);
      exit = m ? describeExit(m) : null;
      const top = newestTs(recs);
      if (top > seen) setSetting('exit_seen_ts', String(top));
    } catch (e) { exit = null; }
    if (getSetting('app_running', '0') !== '1') return null;
    let last = [];
    try { last = JSON.parse(getSetting('last_trail', '[]')) || []; } catch (e) { last = []; }
    const where = last.length ? last[last.length - 1].name : '';
    const before = previousCrumbs();
    const info = {
      version: APP_VERSION, build: buildLabel(), trail: last.slice(-6).map((t) => t.name).join(' › '), lastAt: last.length ? last[last.length - 1].at : '',
      android: exit ? exit.line : (hasExitInfo() ? 'Android gave no reason' : ''),
      exit: exit ? { code: exit.code, plain: exit.plain, at: exit.at, description: exit.description, importance: exit.importance, memory: exit.memory, trace: exit.trace.slice(0, 2500) } : undefined,
      crumbs: crumbLines(before).join('\n').slice(0, 3500),
    };
    const problem = !exit || exit.problem;
    if (problem) {
      audit({ user: null, action: 'app_closed', table: where || 'app', reason: exit ? `The app closed unexpectedly while it was open – ${exit.plain}` : 'The app closed unexpectedly while it was open', after: info });
    } else {
      // a swipe, a force stop, an update: not a problem – noted quietly (no pop-up, no problem email)
      try { audit({ user: null, action: 'app_info', table: where || 'app', reason: `Closed: ${exit.plain}`, after: info }); } catch (e) { /* ignore */ }
    }
    try { setSetting('last_close_info', JSON.stringify({ at: stamp(), where, problem, android: info.android })); } catch (e) { /* ignore */ }
    return { where, trail: last, problem, exit };
  } catch (e) { return null; }
}

// ---------------------------------------------------------------- phone & app facts
function buildLabel() {
  try { const A = require('./about.js'); return `${A.versionLabel()} · code ${A.VERSION_CODE}`; } catch (e) { return APP_VERSION; }
}
let facts = { freeDisk: null, dbSize: null, at: 0 };
// The slow (async) facts: free storage and the database file size. Called at start-up and when the report page opens.
export async function refreshDeviceFacts() {
  try {
    const D = require('../platform/device.js');
    const [freeDisk, dbSize] = await Promise.all([D.freeDiskBytes(), D.storageUsed()]);
    facts = { freeDisk, dbSize, at: Date.now() };
  } catch (e) { /* not known */ }
  return facts;
}
let counts = { at: 0, list: [] };
function biggestTables() {
  if (Date.now() - counts.at < 10 * 60000 && counts.list.length) return counts.list;
  try {
    const names = db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").map((r) => r.name);
    const list = [];
    for (const n of names.slice(0, 400)) { try { list.push([n, Number(db().get(`SELECT COUNT(*) AS n FROM "${String(n).replace(/"/g, '')}"`).n) || 0]); } catch (e) { /* skip */ } }
    counts = { at: Date.now(), list: list.sort((a, b) => b[1] - a[1]).slice(0, 10) };
  } catch (e) { counts = { at: Date.now(), list: [] }; }
  return counts.list;
}
const bytes = (n) => { try { return require('../platform/device.js').bytesText(n); } catch (e) { return n === null || n === undefined ? '—' : `${n} bytes`; } };
const mins = (m) => (m === null || m === undefined ? '—' : m < 90 ? `${m} min` : m < 2880 ? `${Math.round(m / 60)} h` : `${Math.round(m / 1440)} days`);
function phoneLine() {
  const RN = (() => { try { return require('react-native'); } catch (e) { return {}; } })();
  const P = RN.Platform || {};
  const k = P.constants || {};
  let D = {};
  try { D = require('expo-device') || {}; } catch (e) { D = {}; }
  const maker = D.manufacturer || k.Manufacturer || k.Brand || '';
  const model = D.modelName || k.Model || '';
  const api = D.platformApiLevel || (P.OS === 'android' ? P.Version : '');
  const os = P.OS === 'android' ? `Android ${D.osVersion || k.Release || '?'} (API ${api || '?'})` : String(P.OS || '?');
  return [maker, model].filter(Boolean).join(' ') + (maker || model ? ' · ' : '') + os;
}
export function deviceFacts() {
  const out = [];
  const add = (k, v) => { if (v !== undefined && v !== null && v !== '') out.push([k, String(v)]); };
  add('App', buildLabel());
  add('Phone', safe(phoneLine));
  add('Device', `${safe(deviceName)} · ${safe(deviceId)}`);
  const mem = memoryInfo();
  let D = {}; try { D = require('expo-device') || {}; } catch (e) { D = {}; }
  if (mem && mem.totalMem) add('Memory', `${bytes(mem.availMem)} free of ${bytes(mem.totalMem)}${mem.lowMemory ? ' (LOW)' : ''}; app uses ${bytes(mem.javaUsed)} of ${bytes(mem.javaMax)} (Java)`);
  else if (D.totalMemory) add('Memory', `${bytes(D.totalMemory)} in all`);
  add('Storage free', facts.at ? bytes(facts.freeDisk) : 'not checked yet');
  add('Database', facts.at ? bytes(facts.dbSize) : '');
  const big = biggestTables();
  if (big.length) add('Biggest tables', big.map(([n, c]) => `${n} ${c}`).join(', '));
  add('Open for', mins(Math.round((Date.now() - startedMs) / 60000)));
  const lastOk = getSetting('last_sync_ok_at', '');
  add('Last sync OK', lastOk ? `${mins(minutesBetween(lastOk, stamp()))} ago (${lastOk})` : 'never');
  const se = getSetting('last_sync_error', '');
  if (se) add('Last sync error', se.slice(0, 200));
  if (currentUser) add('Logged in', `${currentUser.role || '?'}${currentUser.shop_code ? ' · shop ' + currentUser.shop_code : ''}`);
  else add('Logged in', 'nobody');
  add('Device shop', getSetting('device_shop', '') || '');
  add('Network', networkType() || '');
  try {
    const RN = require('react-native');
    const w = RN.Dimensions && RN.Dimensions.get ? RN.Dimensions.get('window') : null;
    const fs = RN.PixelRatio && RN.PixelRatio.getFontScale ? RN.PixelRatio.getFontScale() : null;
    if (w) add('Screen', `${Math.round(w.width)}×${Math.round(w.height)}${fs ? ` · phone font ×${fs}` : ''} · Aa ${getSetting('ui_scale', '') || 'normal'}`);
  } catch (e) { /* not known */ }
  try { if (require('./trainingFlag.js').isTraining()) add('Mode', 'TRAINING'); } catch (e) { /* ignore */ }
  return out;
}

// ---------------------------------------------------------------- the report
const indent = (s, pre = '    ') => String(s || '').split('\n').filter((x) => x.trim()).map((x) => pre + x).join('\n');
// Cut to the cap at a line end, saying so.
export function capReport(text, max = REPORT_MAX) {
  const t = String(text || '');
  if (t.length <= max) return t;
  const note = '\n… (report cut here to fit a message – the full log is in Settings › Problem log)';
  const cut = t.slice(0, max - note.length);
  const nl = cut.lastIndexOf('\n');
  return (nl > max * 0.6 ? cut.slice(0, nl) : cut) + note;
}
// Plain-text report to send (Viber / WhatsApp / email) so the problem can be looked at.
export function problemReport({ tour, max = REPORT_MAX } = {}) {
  const errs = listErrors(25);
  const newest = errs[0] || null;
  let closeInfo = null; try { closeInfo = JSON.parse(getSetting('last_close_info', 'null')); } catch (e) { closeInfo = null; }
  const facts0 = deviceFacts();
  const fact = (k) => (facts0.find((f) => f[0] === k) || [])[1] || '';
  const doing = (newest && newest.crumbs ? String(newest.crumbs).split('\n').slice(-4) : crumbLines(crumbs(), 4)).map((l) => l.slice(0, 120)).join(' → ');
  const sum = [
    'Easy Buys problem report', `Made ${stamp()}`, '',
    '— Summary —',
    `What happened: ${newest ? `${newest.at} [${newest.screen || '—'}] ${String(newest.message).slice(0, 200)}${newest.fatal ? ' (would have closed the app)' : ''}` : 'No problems recorded.'}`,
    `Android's reason: ${newest && newest.android ? newest.android : closeInfo && closeInfo.android ? `${closeInfo.at}: ${closeInfo.android}` : hasExitInfo() ? '—' : 'not known (this app build or Android cannot tell)'}`,
    `What you were doing: ${doing || '—'}`,
    `Phone: ${fact('Phone') || '?'} · app ${fact('App')}`,
    '',
  ];
  const det = ['— Phone & app —', ...facts0.map(([k, v]) => `${k}: ${v}`), ''];
  if (tour && tour.length) {
    const bad = tour.filter((t) => !t.ok);
    det.push(`Screen check: ${tour.length - bad.length} of ${tour.length} screens OK`);
    bad.forEach((t) => det.push(`  ✗ ${t.name}: ${t.message}`));
    det.push('');
  }
  det.push('Last screens opened: ' + (trail.map((t) => t.name).join(' › ') || '—'));
  det.push('', '— What the app did just now (oldest → newest) —', ...(crumbLines(crumbs(), 20).length ? crumbLines(crumbs(), 20) : ['—']), '');
  det.push(errs.length ? `— Last ${errs.length} problem(s), newest first —` : 'No problems recorded.');
  // the newest problems in full; older ones a line each so the report stays short
  errs.forEach((e, i) => {
    det.push(`• ${e.at} [${e.screen || '—'}] ${e.message}${e.build ? `  (${e.build})` : ''}`);
    if (e.trail) det.push(`    path: ${e.trail}`);
    if (i > 2) return;
    if (e.android) det.push(`    ${e.android}`);
    if (e.exit) {
      const x = e.exit;
      det.push(`    Android: ${x.code}${x.at ? ' at ' + x.at : ''}${x.importance ? ' · ' + x.importance : ''}${x.memory ? ' · ' + x.memory : ''}`);
      if (x.trace) det.push('    trace:', indent(String(x.trace).split('\n').slice(0, 25).join('\n'), '      '));
    }
    if (e.stack) det.push('    stack:', indent(String(e.stack).split('\n').slice(0, i === 0 ? 20 : 8).join('\n'), '      '));
    if (e.componentStack) det.push('    screen parts:', indent(String(e.componentStack).split('\n').slice(0, 10).join('\n'), '      '));
    if (e.crumbs) det.push(`    before it (oldest → newest):`, indent(String(e.crumbs).split('\n').slice(i === 0 ? -30 : -8).join('\n'), '      '));
  });
  return capReport([...sum, ...det].join('\n'), max);
}
function safe(fn) { try { return fn(); } catch (e) { return '?'; } }
export { redact };
