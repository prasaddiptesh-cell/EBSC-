// Why did the app close last time? Android 11+ keeps the reasons (ApplicationExitInfo); the small native module in
// modules/exit-info reads them. Everything here works without that module (web test build, older apps, iPhone,
// Android 10 and older): the answers are then null / [].

// Android's reason numbers (ApplicationExitInfo.REASON_*), in plain words.
// problem: false = not the app's fault and nothing to fix (a swipe, a force stop, an update) – logged quietly.
export const EXIT_REASONS = {
  0: { code: 'UNKNOWN', plain: 'Android does not know why it closed', problem: true },
  1: { code: 'EXIT_SELF', plain: 'The app closed itself', problem: true },
  2: { code: 'SIGNALED', plain: 'Android stopped the app (signal)', problem: true },
  3: { code: 'LOW_MEMORY', plain: 'Android closed it to free memory', problem: true },
  4: { code: 'CRASH', plain: 'The app crashed (Java)', problem: true },
  5: { code: 'CRASH_NATIVE', plain: 'The app crashed (native code)', problem: true },
  6: { code: 'ANR', plain: 'The app stopped answering (froze) and Android closed it', problem: true },
  7: { code: 'INITIALIZATION_FAILURE', plain: 'The app could not start', problem: true },
  8: { code: 'PERMISSION_CHANGE', plain: 'A permission of the app was changed in the phone settings', problem: false },
  9: { code: 'EXCESSIVE_RESOURCE_USAGE', plain: 'Android closed it for using too much of the phone (battery / processor)', problem: true },
  10: { code: 'USER_REQUESTED', plain: 'You swiped it away / closed it from the phone', problem: false },
  11: { code: 'USER_STOPPED', plain: 'It was force-stopped (phone settings)', problem: false },
  12: { code: 'DEPENDENCY_DIED', plain: 'A part of Android the app needs stopped', problem: true },
  13: { code: 'OTHER', plain: 'Android closed it (other reason)', problem: true },
  14: { code: 'FREEZER', plain: 'Android froze the app in the background', problem: true },
  15: { code: 'PACKAGE_STATE_CHANGE', plain: 'The app was switched off or changed in the phone settings', problem: false },
  16: { code: 'PACKAGE_UPDATED', plain: 'The app was updated while open', problem: false },
};
const IMPORTANCE = { 100: 'on screen', 125: 'foreground service', 200: 'visible', 230: 'perceptible', 300: 'service', 325: 'on screen, phone asleep', 350: 'can\'t save state', 400: 'in the background', 1000: 'gone' };

function native() {
  try {
    const m = globalThis.expo && globalThis.expo.modules ? globalThis.expo.modules.ExitInfo : null;
    return m && typeof m.getExitReasons === 'function' ? m : null;
  } catch (e) { return null; }
}
export function hasExitInfo() { return !!native(); }

// The raw records, newest first ([] when not known).
export function exitReasons(max = 5) {
  const m = native();
  if (!m) return [];
  try { const r = m.getExitReasons(max); return Array.isArray(r) ? r : []; } catch (e) { return []; }
}
export function memoryInfo() {
  const m = native();
  if (!m || typeof m.getMemory !== 'function') return null;
  try { const r = m.getMemory(); return r && typeof r === 'object' ? r : null; } catch (e) { return null; }
}
export function networkType() {
  const m = native();
  if (!m || typeof m.getNetwork !== 'function') return '';
  try { return String(m.getNetwork() || ''); } catch (e) { return ''; }
}

const mb = (kb) => (Number(kb) > 0 ? `${Math.round(Number(kb) / 1024)} MB` : '');
// A swipe from the recent apps often shows as OTHER / SIGNALED with "remove task" in the description.
const SWIPE = /remove task|swipe|recents|user request/i;
const UPDATE = /package (updated|replaced|changed)|installPackage|app update/i;

// One record → { reason, code, plain, problem, at, description, importance, memory, trace, line }
export function describeExit(rec) {
  if (!rec || typeof rec !== 'object') return null;
  const n = Number(rec.reason);
  const known = EXIT_REASONS[n] || { code: `REASON_${n}`, plain: `Android closed it (reason ${n})`, problem: true };
  let { code, plain, problem } = known;
  const desc = String(rec.description || '').trim();
  if ((code === 'OTHER' || code === 'SIGNALED' || code === 'UNKNOWN') && SWIPE.test(desc)) { plain = 'You swiped it away / closed it from the phone'; problem = false; }
  else if ((code === 'OTHER' || code === 'UNKNOWN') && UPDATE.test(desc)) { plain = 'The app was updated while open'; problem = false; }
  const ts = Number(rec.timestamp) || 0;
  const imp = Number(rec.importance) || 0;
  const trace = String(rec.trace || '').slice(0, 4096);
  const memory = [rec.pss ? `pss ${mb(rec.pss)}` : '', rec.rss ? `rss ${mb(rec.rss)}` : ''].filter(Boolean).join(', ');
  const first = trace ? trace.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 3).join(' | ') : '';
  const line = `Android says: ${plain.charAt(0).toLowerCase()}${plain.slice(1)}${desc ? ` (${desc.slice(0, 160)})` : ''}${first ? ` – ${first.slice(0, 300)}` : ''}`;
  return { reason: n, code, plain, problem, at: ts ? new Date(ts).toISOString() : '', ts, description: desc, importance: IMPORTANCE[imp] || (imp ? String(imp) : ''), memory, trace, line };
}

// The exit that belongs to the close just noticed: the newest record newer than the last one already looked at.
// seenTs: the timestamp kept from last time (so an old record is never matched again).
export function matchExit(records, seenTs = 0) {
  const list = (records || []).filter((r) => r && Number(r.timestamp) > Number(seenTs || 0))
    .sort((a, b) => Number(b.timestamp) - Number(a.timestamp));
  return list.length ? list[0] : null;
}
export function newestTs(records) { return (records || []).reduce((m, r) => Math.max(m, Number(r && r.timestamp) || 0), 0); }
