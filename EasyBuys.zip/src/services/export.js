// Turns report data into a printable HTML page (for PDF/email), Excel (.xlsx) and CSV.
import JSZip from 'jszip';
import { reportTemplate } from './reportTemplate.js';
import { prepareDoc } from './docOutput.js';
import { LOOKS, fillPlaceholders } from './docDesign.js';
import { code128Svg, qrSvg } from './barcode.js';

const esc = (v) => String(v === null || v === undefined ? '' : v)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const TONE = { good: '#157F3B', warn: '#B45309', bad: '#B42318' };
const ROW_BG = { warn: '#FEF6E0', bad: '#FDE7E5' };

// Professional report / document page in the Easy Buys colours: A4 (default), A5 or an 80 mm receipt. The parts, their
// order, labels, look and paper come from the document designer (src/services/docDesign.js); every company document
// carries a Code 128 barcode of its reference (src/services/issuedDocs.js), a QR code only when switched on.
export function reportToHtml(rep0, { logoUri, paper } = {}) {
  const rep = prepareDoc(rep0, { paper });
  const d = rep._design || { parts: [], look: { theme: 'classic', logo: true, fontScale: 1 }, texts: [] };
  const look = LOOKS.find((l) => l.id === d.look.theme) || LOOKS[0];
  const red = look.accent;
  const blue = look.second;
  const thermal = rep._paper === '80mm';
  const a5 = rep._paper === 'A5';
  const fs = (thermal ? 10 : a5 ? 9.5 : 10.5) * (Number(d.look.fontScale) || 1);
  const tpl = reportTemplate();
  const id = rep._identity || {};
  const on = (key) => d.parts.some((p) => p.key === key && p.on);
  const summary = (rep.summary || []).map((s) => thermal
    ? `<tr><th>${esc(s.label)}</th><td style="color:${TONE[s.tone] || '#000'}">${esc(s.value)}</td></tr>`
    : `<div class="kpi"><div class="kpi-l">${esc(s.label)}</div><div class="kpi-v" style="color:${TONE[s.tone] || '#2B1A1C'}">${esc(s.value)}</div></div>`).join('');
  const info = (rep.info || []).map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('');
  const sections = (rep.sections || []).map((sec) => {
    const note = sec.note ? `<div class="note">${esc(sec.note).replace(/\n/g, '<br/>')}</div>` : '';
    if (thermal && sec.columns.length > 3) {
      // Narrow paper: each line becomes a small block ("Column: value").
      const body = sec.rows.length ? sec.rows.map((r) => `<div class="blk"${ROW_BG[r._tone] ? ` style="background:${ROW_BG[r._tone]}"` : ''}>${sec.columns.map((c, k) => (r[c.key] === undefined || r[c.key] === '' ? ''
        : k === 0 ? `<div class="b1">${esc(r[c.key])}</div>` : `<div class="bl"><span>${esc(c.title)}</span><b>${esc(r[c.key])}</b></div>`)).join('')}</div>`).join('') : '<div class="empty">None</div>';
      return `<h2>${esc(sec.title)}</h2>${body}${note}`;
    }
    const head = sec.columns.map((c) => `<th style="text-align:${c.align}">${esc(c.title)}</th>`).join('');
    const body = sec.rows.length
      ? sec.rows.map((r) => `<tr style="background:${ROW_BG[r._tone] || 'transparent'}">${sec.columns.map((c) => `<td style="text-align:${c.align}">${esc(r[c.key])}</td>`).join('')}</tr>`).join('')
      : `<tr><td colspan="${sec.columns.length}" class="empty">None</td></tr>`;
    const wide = sec.columns.length > 12 ? ' xwide' : sec.columns.length > 8 ? ' wide' : '';
    return `<h2>${esc(sec.title)}</h2><table class="grid${wide}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>${note}`;
  }).join('');
  const badge = rep.approved === undefined ? '' : rep.approved
    ? '<span class="badge ok">APPROVED</span>' : '<span class="badge pending">NOT YET APPROVED</span>';
  const logo = on('header') && d.look.logo !== false && logoUri ? `<img src="${logoUri}"/>` : '';
  const signLines = rep.kind === 'shift' || rep.kind === 'po' ? `<div class="sign"><div>${rep.kind === 'po' ? 'Authorised by' : 'Supervisor signature'}</div><div>Date</div></div>` : '';
  const PART = {
    header: () => `<div class="head">
    <div>${logo || (thermal ? '' : `<div class="title">${esc(tpl.businessName)}</div>`)}</div>
    <div class="right">${d.look.headerText ? `<div class="sub">${esc(fillPlaceholders(d.look.headerText, rep, { ref: id.ref }))}</div>` : ''}<div class="title">${esc(rep.title)}</div><div class="sub">${esc(rep.subtitle || '')}</div>${badge}</div>
  </div>
  <div class="rule"></div><div class="rule2"></div>${rep.warningMark ? `<div class="warnmark">${esc(rep.warningMark)}</div>` : ''}`,
    business: () => `<div class="biz"><b>${esc(tpl.businessName)}</b>${[tpl.address, tpl.phone, tpl.email].filter(Boolean).map((x) => ` · ${esc(x)}`).join('')}${tpl.tin ? ` · TIN ${esc(tpl.tin)}` : ''}</div>`,
    info: () => (info ? `<table class="info">${info}</table>` : ''),
    summary: () => (summary ? (thermal ? `<table class="info sum">${summary}</table>` : `<div class="kpis">${summary}</div>`) : ''),
    sections: () => sections,
    note: () => (rep.note ? `<div class="note">${esc(rep.note)}</div>` : ''),
    signatures: () => signLines + (rep.signatures ? `<div class="sign">${rep.signatures.map((g) => `<div>${g.data ? `<img src="${g.data}" style="height:60px;display:block"/>` : '<div style="height:60px"></div>'}${esc(g.label)}${g.at ? `<br/>${esc(String(g.at).slice(0, 16))}` : ''}</div>`).join('')}</div>` : ''),
    photos: () => (rep.images || []).filter((g) => g && g.src).map((g) => `<div style="margin-top:14px;page-break-inside:avoid"><div class="note">${esc(g.caption || 'Photo')}</div><img src="${g.src}" style="max-width:100%;max-height:${thermal ? 260 : 640}px;border:1px solid #ddd"/></div>`).join(''),
    barcode: () => (id.code ? `<div class="codes">${safeSvg(() => code128Svg(id.code, { width: thermal ? 62 : a5 ? 62 : 72, height: thermal ? 13 : 14 }))}<div class="codetxt">Check this document: Easy Buys app › Scan</div></div>` : ''),
    qr: () => (id.code ? `<div class="codes">${safeSvg(() => qrSvg(id.code, { size: thermal ? 26 : 22 }))}</div>` : ''),
    footer: () => `<div class="foot">${esc(rep.footer || '').replace(/\n/g, '<br/>')}</div>`,
    appLine: () => (rep.appLine ? `<div class="appline">${esc(rep.appLine)}</div>` : ''),
  };
  const textOf = (key) => { const t = (d.texts || []).find((x) => `text:${x.id}` === key); return t && t.text ? `<div class="free">${esc(t.text).replace(/\n/g, '<br/>')}</div>` : ''; };
  const parts = d.parts.length ? d.parts : Object.keys(PART).map((key) => ({ key, on: key !== 'qr' }));
  // The warning marker is always printed (even with the title hidden).
  const body = (rep.warningMark && !on('header') ? `<div class="warnmark">${esc(rep.warningMark)}</div>` : '')
    + parts.filter((p) => p.on).map((p) => (PART[p.key] ? PART[p.key]() : p.key.startsWith('text:') ? textOf(p.key) : '')).join('\n  ');
  const page = thermal ? '@page { size: 80mm auto; margin: 3mm 3mm; }' : a5 ? '@page { size: A5; margin: 10mm 9mm; }' : '@page { size: A4; margin: 14mm 12mm; }';
  return `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>${esc(rep.title)}</title>
<style>
  ${page}
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #222; font-size: ${fs}px; margin: 0; ${thermal ? 'width: 72mm; margin: 0 auto;' : ''} }
  .head { display: flex; justify-content: space-between; align-items: center; padding-bottom: 8px; ${thermal ? 'flex-direction: column; text-align: center;' : ''} }
  .head img { height: ${thermal ? 40 : 58}px; }
  .head .right { text-align: ${thermal ? 'center' : 'right'}; }
  .title { font-size: ${thermal ? 15 : a5 ? 17 : 20}px; font-weight: 800; color: #2B1A1C; }
  .sub { font-size: ${thermal ? 10 : 11}px; color: #555; margin-top: 2px; }
  .rule { height: ${thermal ? 2 : 4}px; background: ${red}; margin: 2px 0 1px; }
  .rule2 { height: 1.5px; background: ${blue}; margin-bottom: 12px; }
  .biz { font-size: ${fs * 0.9}px; color: #444; margin: -6px 0 8px; ${thermal ? 'text-align:center;' : ''} }
  .warnmark { border: 2px solid #B45309; background: #FEF6E0; color: #7A3E00; font-weight: 800; padding: 5px 8px; border-radius: 6px; margin: 0 0 10px; }
  .badge { display: inline-block; margin-top: 6px; padding: 3px 9px; border-radius: 10px; font-weight: 800; font-size: 10px; color: #fff; }
  .badge.ok { background: #157F3B; } .badge.pending { background: #B45309; }
  .kpis { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
  .kpi { flex: 1 1 110px; border: 1px solid #E3DCD0; border-left: 4px solid ${red}; border-radius: 6px; padding: 6px 9px; }
  .kpi-l { font-size: 9.5px; color: #666; text-transform: uppercase; letter-spacing: .3px; }
  .kpi-v { font-size: 16px; font-weight: 800; margin-top: 2px; }
  table.info { border-collapse: collapse; margin-bottom: 10px; ${thermal ? 'width: 100%;' : ''} }
  table.info th { text-align: left; color: #666; font-weight: 600; padding: 2px 14px 2px 0; vertical-align: top; }
  table.info td { padding: 2px 0; font-weight: 600; ${thermal ? 'text-align: right;' : ''} }
  table.info.sum td { font-size: ${fs * 1.15}px; font-weight: 800; }
  h2 { font-size: ${thermal ? 11.5 : 12.5}px; color: ${blue}; margin: ${thermal ? 8 : 14}px 0 5px; padding-bottom: 3px; border-bottom: 1px solid #E3DCD0; }
  table.grid { width: 100%; border-collapse: collapse; page-break-inside: auto; }
  table.grid th { background: #F6E7D6; color: #5E320C; font-size: ${thermal ? 9 : 9.5}px; padding: 4px 5px; border-bottom: 1px solid #D9C7B0; }
  table.grid td { padding: ${thermal ? '3px 2px' : '4px 5px'}; border-bottom: 1px solid #EFE9E1; vertical-align: top; }
  table.grid tr { page-break-inside: avoid; }
  table.grid.wide th, table.grid.wide td { font-size: 9px; padding: 3px 4px; }
  table.grid.xwide th, table.grid.xwide td { font-size: 7.6px; padding: 2px 3px; }
  .blk { border-bottom: 1px dashed #bbb; padding: 3px 0; }
  .blk .b1 { font-weight: 800; }
  .blk .bl { display: flex; justify-content: space-between; gap: 6px; }
  .blk .bl span { color: #555; }
  .empty { color: #999; font-style: italic; }
  .note { color: #666; font-size: 9px; margin-top: 4px; line-height: 1.4; }
  .free { margin: 10px 0; line-height: 1.45; white-space: normal; }
  .codes { margin-top: 12px; text-align: ${thermal ? 'center' : 'right'}; page-break-inside: avoid; }
  .codes svg { display: inline-block; }
  .codetxt { color: #888; font-size: 7.5px; }
  .foot { margin-top: 18px; padding-top: 6px; border-top: 1px solid ${red}; color: #888; font-size: 9px; text-align: center; }
  .appline { margin-top: 3px; color: #999; font-size: 8px; text-align: center; }
  .sign { margin-top: 26px; display: flex; gap: ${thermal ? 12 : 40}px; }
  .sign div { flex: 1; border-top: 1px solid #999; padding-top: 4px; color: #666; font-size: 9.5px; }
</style></head><body>
  ${body}
</body></html>`;
}
const safeSvg = (fn) => { try { return fn(); } catch (e) { return ''; } };

const csvCell = (v) => {
  const s = String(v === null || v === undefined ? '' : v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function reportToCsv(rep0) {
  const rep = prepareDoc(rep0);
  const lines = [[rep.title], [rep.subtitle || '']];
  (rep.info || []).forEach(([k, v]) => lines.push([k, v]));
  lines.push([]);
  (rep.summary || []).forEach((s) => lines.push([s.label, s.value]));
  for (const sec of rep.sections || []) {
    lines.push([], [sec.title], sec.columns.map((c) => c.title));
    sec.rows.forEach((r) => lines.push(sec.columns.map((c) => r[c.key])));
  }
  return lines.map((l) => l.map(csvCell).join(',')).join('\r\n');
}

// ---------- Excel (.xlsx) ----------
const xmlEsc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
function colName(i) {
  let s = '';
  let n = i + 1;
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
function cellXml(ref, v, style) {
  if (v === null || v === undefined || v === '') return '';
  const asNum = typeof v === 'number' ? v : (/^-?\d+(\.\d+)?$/.test(String(v).trim()) ? Number(v) : null);
  const st = style ? ` s="${style}"` : '';
  if (asNum !== null && Number.isFinite(asNum)) return `<c r="${ref}"${st}><v>${asNum}</v></c>`;
  return `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
}
function sheetXml(rows, widths) {
  const cols = widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('');
  const data = rows.map((r, ri) => `<row r="${ri + 1}">${r.cells.map((v, ci) => cellXml(`${colName(ci)}${ri + 1}`, v, r.style)).join('')}</row>`).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${cols ? `<cols>${cols}</cols>` : ''}<sheetData>${data}</sheetData></worksheet>`;
}
function safeSheetName(name, used) {
  let n = String(name).replace(/[[\]:*?/\\]/g, ' ').slice(0, 31).trim() || 'Sheet';
  let k = 2;
  while (used.has(n.toLowerCase())) n = `${n.slice(0, 28)} ${k++}`;
  used.add(n.toLowerCase());
  return n;
}

// Returns the workbook as a base64 string. One sheet for the summary plus one per section.
export async function reportToXlsxBase64(rep0) {
  const rep = prepareDoc(rep0);
  const sheets = [];
  const summaryRows = [{ cells: [rep.title], style: 1 }, { cells: [rep.subtitle || ''] }, { cells: [] }];
  (rep.info || []).forEach(([k, v]) => summaryRows.push({ cells: [k, v] }));
  summaryRows.push({ cells: [] });
  (rep.summary || []).forEach((s) => summaryRows.push({ cells: [s.label, s.value] }));
  sheets.push({ name: 'Summary', rows: summaryRows, widths: [28, 50] });
  for (const sec of rep.sections || []) {
    const rows = [{ cells: sec.columns.map((c) => c.title), style: 2 }];
    sec.rows.forEach((r) => rows.push({ cells: sec.columns.map((c) => r[c.key]) }));
    const widths = sec.columns.map((c) => Math.min(60, Math.max(10, c.title.length + 2, ...sec.rows.map((r) => String(r[c.key] === undefined ? '' : r[c.key]).length + 2))));
    sheets.push({ name: sec.title, rows, widths });
  }
  const used = new Set();
  sheets.forEach((s) => { s.safe = safeSheetName(s.name, used); });
  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
  zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s, i) => `<sheet name="${xmlEsc(s.safe)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
  zip.file('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><color rgb="FF2B1A1C"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDA2A2F"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs></styleSheet>');
  sheets.forEach((s, i) => zip.file(`xl/worksheets/sheet${i + 1}.xml`, sheetXml(s.rows, s.widths)));
  return zip.generateAsync({ type: 'base64' });
}
