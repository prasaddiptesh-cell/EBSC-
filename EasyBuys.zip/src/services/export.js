// Turns report data into a printable HTML page (for PDF/email), Excel (.xlsx) and CSV.
import JSZip from 'jszip';
import { applyTemplate } from './reportTemplate.js';

const esc = (v) => String(v === null || v === undefined ? '' : v)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const TONE = { good: '#157F3B', warn: '#B45309', bad: '#B42318' };
const ROW_BG = { warn: '#FEF6E0', bad: '#FDE7E5' };

// Professional A4 report in the Easy Buys colours.
export function reportToHtml(rep0, { logoUri } = {}) {
  const rep = applyTemplate(rep0);
  const summary = (rep.summary || []).map((s) => `
    <div class="kpi"><div class="kpi-l">${esc(s.label)}</div><div class="kpi-v" style="color:${TONE[s.tone] || '#2B1A1C'}">${esc(s.value)}</div></div>`).join('');
  const info = (rep.info || []).map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('');
  const sections = (rep.sections || []).map((sec) => {
    const head = sec.columns.map((c) => `<th style="text-align:${c.align}">${esc(c.title)}</th>`).join('');
    const body = sec.rows.length
      ? sec.rows.map((r) => `<tr style="background:${ROW_BG[r._tone] || 'transparent'}">${sec.columns.map((c) => `<td style="text-align:${c.align}">${esc(r[c.key])}</td>`).join('')}</tr>`).join('')
      : `<tr><td colspan="${sec.columns.length}" class="empty">None</td></tr>`;
    const note = sec.note ? `<div class="note">${esc(sec.note).replace(/\n/g, '<br/>')}</div>` : '';
    const wide = sec.columns.length > 12 ? ' xwide' : sec.columns.length > 8 ? ' wide' : '';
    return `<h2>${esc(sec.title)}</h2><table class="grid${wide}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>${note}`;
  }).join('');
  const badge = rep.approved === undefined ? '' : rep.approved
    ? '<span class="badge ok">APPROVED</span>' : '<span class="badge pending">NOT YET APPROVED</span>';
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${esc(rep.title)}</title>
<style>
  @page { size: A4; margin: 14mm 12mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; color: #222; font-size: 10.5px; margin: 0; }
  .head { display: flex; justify-content: space-between; align-items: center; padding-bottom: 8px; }
  .head img { height: 58px; }
  .head .right { text-align: right; }
  .title { font-size: 20px; font-weight: 800; color: #2B1A1C; }
  .sub { font-size: 11px; color: #555; margin-top: 2px; }
  .rule { height: 4px; background: #DA2A2F; margin: 2px 0 1px; }
  .rule2 { height: 1.5px; background: #2F5FC4; margin-bottom: 12px; }
  .badge { display: inline-block; margin-top: 6px; padding: 3px 9px; border-radius: 10px; font-weight: 800; font-size: 10px; color: #fff; }
  .badge.ok { background: #157F3B; } .badge.pending { background: #B45309; }
  .kpis { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
  .kpi { flex: 1 1 110px; border: 1px solid #E3DCD0; border-left: 4px solid #DA2A2F; border-radius: 6px; padding: 6px 9px; }
  .kpi-l { font-size: 9.5px; color: #666; text-transform: uppercase; letter-spacing: .3px; }
  .kpi-v { font-size: 16px; font-weight: 800; margin-top: 2px; }
  table.info { border-collapse: collapse; margin-bottom: 10px; }
  table.info th { text-align: left; color: #666; font-weight: 600; padding: 2px 14px 2px 0; }
  table.info td { padding: 2px 0; font-weight: 600; }
  h2 { font-size: 12.5px; color: #2F5FC4; margin: 14px 0 5px; padding-bottom: 3px; border-bottom: 1px solid #E3DCD0; }
  table.grid { width: 100%; border-collapse: collapse; page-break-inside: auto; }
  table.grid th { background: #F6E7D6; color: #5E320C; font-size: 9.5px; padding: 4px 5px; border-bottom: 1px solid #D9C7B0; }
  table.grid td { padding: 4px 5px; border-bottom: 1px solid #EFE9E1; vertical-align: top; }
  table.grid tr { page-break-inside: avoid; }
  table.grid.wide th, table.grid.wide td { font-size: 9px; padding: 3px 4px; }
  table.grid.xwide th, table.grid.xwide td { font-size: 7.6px; padding: 2px 3px; }
  .empty { color: #999; font-style: italic; }
  .note { color: #666; font-size: 9px; margin-top: 4px; line-height: 1.4; }
  .foot { margin-top: 18px; padding-top: 6px; border-top: 1px solid #DA2A2F; color: #888; font-size: 9px; text-align: center; }
  .appline { margin-top: 3px; color: #999; font-size: 8px; }
  .sign { margin-top: 26px; display: flex; gap: 40px; }
  .sign div { flex: 1; border-top: 1px solid #999; padding-top: 4px; color: #666; font-size: 9.5px; }
</style></head><body>
  <div class="head">
    <div>${logoUri ? `<img src="${logoUri}"/>` : `<div class="title">${esc((rep.info || [])[0] ? rep.info[0][1] : '')}</div>`}</div>
    <div class="right"><div class="title">${esc(rep.title)}</div><div class="sub">${esc(rep.subtitle || '')}</div>${badge}</div>
  </div>
  <div class="rule"></div><div class="rule2"></div>
  <table class="info">${info}</table>
  <div class="kpis">${summary}</div>
  ${sections}
  ${rep.kind === 'shift' || rep.kind === 'po' ? `<div class="sign"><div>${rep.kind === 'po' ? 'Authorised by' : 'Supervisor signature'}</div><div>Date</div></div>` : ''}
  ${rep.note ? `<div class="note">${esc(rep.note)}</div>` : ''}
  ${rep.signatures ? `<div class="sign">${rep.signatures.map((g) => `<div>${g.data ? `<img src="${g.data}" style="height:60px;display:block"/>` : '<div style="height:60px"></div>'}${esc(g.label)}${g.at ? `<br/>${esc(String(g.at).slice(0, 16))}` : ''}</div>`).join('')}</div>` : ''}
  ${(rep.images || []).filter((g) => g && g.src).map((g) => `<div style="margin-top:14px;page-break-inside:avoid"><div class="note">${esc(g.caption || 'Photo')}</div><img src="${g.src}" style="max-width:100%;max-height:640px;border:1px solid #ddd"/></div>`).join('')}
  <div class="foot">${esc(rep.footer || '').replace(/\n/g, '<br/>')}${rep.appLine ? `<div class="appline">${esc(rep.appLine)}</div>` : ''}</div>
</body></html>`;
}

const csvCell = (v) => {
  const s = String(v === null || v === undefined ? '' : v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function reportToCsv(rep0) {
  const rep = applyTemplate(rep0);
  const lines = [[rep.title], [rep.subtitle || '']];
  (rep.info || []).forEach(([k, v]) => lines.push([k, v]));
  lines.push([]);
  (rep.summary || []).forEach((s) => lines.push([s.label, s.value]));
  for (const sec of rep.sections || []) {
    lines.push([], [sec.title], sec.columns.map((c) => c.title));
    sec.rows.forEach((r) => lines.push(sec.columns.map((c) => r[c.key])));
  }
  return lines.map((l) => l.map(csvCell).join(',')).join('\r\n');
}

// ---------- Excel (.xlsx) ----------
const xmlEsc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
function colName(i) {
  let s = '';
  let n = i + 1;
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}
function cellXml(ref, v, style) {
  if (v === null || v === undefined || v === '') return '';
  const asNum = typeof v === 'number' ? v : (/^-?\d+(\.\d+)?$/.test(String(v).trim()) ? Number(v) : null);
  const st = style ? ` s="${style}"` : '';
  if (asNum !== null && Number.isFinite(asNum)) return `<c r="${ref}"${st}><v>${asNum}</v></c>`;
  return `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
}
function sheetXml(rows, widths) {
  const cols = widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('');
  const data = rows.map((r, ri) => `<row r="${ri + 1}">${r.cells.map((v, ci) => cellXml(`${colName(ci)}${ri + 1}`, v, r.style)).join('')}</row>`).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${cols ? `<cols>${cols}</cols>` : ''}<sheetData>${data}</sheetData></worksheet>`;
}
function safeSheetName(name, used) {
  let n = String(name).replace(/[[\]:*?/\\]/g, ' ').slice(0, 31).trim() || 'Sheet';
  let k = 2;
  while (used.has(n.toLowerCase())) n = `${n.slice(0, 28)} ${k++}`;
  used.add(n.toLowerCase());
  return n;
}

// Returns the workbook as a base64 string. One sheet for the summary plus one per section.
export async function reportToXlsxBase64(rep0) {
  const rep = applyTemplate(rep0);
  const sheets = [];
  const summaryRows = [{ cells: [rep.title], style: 1 }, { cells: [rep.subtitle || ''] }, { cells: [] }];
  (rep.info || []).forEach(([k, v]) => summaryRows.push({ cells: [k, v] }));
  summaryRows.push({ cells: [] });
  (rep.summary || []).forEach((s) => summaryRows.push({ cells: [s.label, s.value] }));
  sheets.push({ name: 'Summary', rows: summaryRows, widths: [28, 50] });
  for (const sec of rep.sections || []) {
    const rows = [{ cells: sec.columns.map((c) => c.title), style: 2 }];
    sec.rows.forEach((r) => rows.push({ cells: sec.columns.map((c) => r[c.key]) }));
    const widths = sec.columns.map((c) => Math.min(60, Math.max(10, c.title.length + 2, ...sec.rows.map((r) => String(r[c.key] === undefined ? '' : r[c.key]).length + 2))));
    sheets.push({ name: sec.title, rows, widths });
  }
  const used = new Set();
  sheets.forEach((s) => { s.safe = safeSheetName(s.name, used); });
  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
  zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  zip.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s, i) => `<sheet name="${xmlEsc(s.safe)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
  zip.file('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><color rgb="FF2B1A1C"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDA2A2F"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs></styleSheet>');
  sheets.forEach((s, i) => zip.file(`xl/worksheets/sheet${i + 1}.xml`, sheetXml(s.rows, s.widths)));
  return zip.generateAsync({ type: 'base64' });
}
