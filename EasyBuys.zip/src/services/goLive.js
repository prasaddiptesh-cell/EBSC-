// v3.9.7 Fresh start from the go-live date. Everything dated before it is history only: Aronium End of days, till
// shifts and balances, To verify items… create no warnings, no pending work and no Viber messages.
// Open money items from before it (unpaid supplier invoices and bills, cheques and deposits not cleared, money records
// not verified, till shortages not decided) are kept away from staff and listed once for the owner / admin in
// "Before go-live – to review". Each one is marked Seen (it then works like any other open item, with its reminders)
// or put aside (it stays in the records, without reminders). Nothing is deleted.
import { getShared, setShared, audit, stamp, dateStr, AppError } from './core.js';
import { writeCount, db } from '../db/connection.js';

const KEY = 'go_live';
const REVIEW = 'go_live_review';
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const J = (v, d) => (v && typeof v === 'object' ? v : d);

// The date the fresh start counts from ('YYYY-MM-DD'), or null when none is set (then nothing is hidden).
export function freshFrom() {
  try {
    const g = J(getShared(KEY, {}), {});
    const d = g.freshFrom || g.liveFrom || null;
    return d && DATE.test(String(d)) ? String(d) : null;
  } catch (e) { return null; }
}
// Dated before the fresh start?
export function isOld(date) {
  const f = freshFrom();
  if (!f || !date) return false;
  return String(date).slice(0, 10) < f;
}
const canSet = (user) => !!user && (['owner', 'admin'].includes(user.role) || (() => { try { return require('./access.js').actsAsOwner(user); } catch (e) { return false; } })());

// The owner / admin sets (or changes) the fresh start date.
export function setFreshFrom(user, date) {
  if (!canSet(user)) throw new AppError('Only the owner or admin can set the fresh start date.');
  const d = String(date || '').trim();
  if (!DATE.test(d)) throw new AppError('Enter the date as YYYY-MM-DD, e.g. 2026-11-01.');
  const g = J(getShared(KEY, {}), {});
  const before = g.freshFrom || null;
  setShared(KEY, { ...g, freshFrom: d, freshBy: user.name, freshAt: stamp() });
  audit({ user, action: `Fresh start from ${d}${before ? ` (was ${before})` : ''}: anything earlier is history only`, table: 'shared_settings' });
  return d;
}

// ---------------------------------------------------------------- the review marks
// { [key]: { s: 'seen' | 'aside', by, at } }
export function reviewMarks() {
  try { return J(getShared(REVIEW, {}), {}); } catch (e) { return {}; }
}
export function markReview(user, keys, s) {
  if (!canSet(user)) throw new AppError('Only the owner or admin can go through the items from before go-live.');
  if (!['seen', 'aside', null].includes(s)) throw new AppError('Choose Seen or Put aside.');
  const list = (Array.isArray(keys) ? keys : [keys]).filter(Boolean);
  if (!list.length) return 0;
  const m = { ...reviewMarks() };
  for (const k of list) {
    if (s) m[k] = { s, by: user.name, at: stamp() };
    else delete m[k];
  }
  setShared(REVIEW, m);
  audit({ user, action: `Before go-live: ${list.length} item(s) ${s === 'seen' ? 'seen – back to normal' : s === 'aside' ? 'put aside' : 'back on the review list'}`, table: 'shared_settings' });
  return list.length;
}

// Should an open item show (warnings, To verify, reminders)? Anything from the fresh start on: yes.
// Earlier: only once the owner / admin has marked it Seen.
export function keep(key, date, marks) {
  if (!isOld(date)) return true;
  const m = (marks || reviewMarks())[key];
  return !!m && m.s === 'seen';
}
// A list filtered with keep(): keyOf(x) and dateOf(x) say which item it is and its date.
export function keepList(list, keyOf, dateOf) {
  if (!Array.isArray(list) || !freshFrom()) return list || [];
  const marks = reviewMarks();
  return list.filter((x) => { try { return keep(keyOf(x), dateOf(x), marks); } catch (e) { return true; } });
}

// ---------------------------------------------------------------- the list for the owner / admin
// Every open item dated before the fresh start: { key, kind, date, text, amount, shop, mark, go: [screen, params] }.
export function beforeGoLive() {
  const f = freshFrom();
  if (!f) return [];
  const marks = reviewMarks();
  const out = [];
  const seenKeys = new Set();
  const add = (x) => { if (!x.key || seenKeys.has(x.key)) return; seenKeys.add(x.key); out.push({ ...x, mark: marks[x.key] || null }); };
  // Supplier invoices and bills (loans and rent too) not fully paid.
  try {
    const AP = require('../modules/payables/service.js');
    for (const i of AP.listInvoices({ filter: 'unpaid' })) {
      const d = i.invoice_date || i.due_date;
      if (!d || String(d) >= f) continue;
      add({ key: `ap_invoices:${i.uid}`, kind: 'Unpaid invoice / bill', date: d, amount: i.owing, shop: i.shop_code || null,
        text: `${i.supplier_name || 'Supplier'}${i.invoice_no ? ` · ${i.invoice_no}` : ''}${i.due_date ? ` · due ${i.due_date}` : ''}`, go: ['ApInvoice', { uid: i.uid }] });
    }
  } catch (e) { /* payables not ready */ }
  // Money records still waiting in To verify (cheques and deposits not cleared, cash paid out…).
  try {
    const V = require('../modules/verify/service.js');
    for (const x of V.queue({ include: 'waiting', from: `${Number(f.slice(0, 4)) - 2}${f.slice(4)}`, to: dateStr(), preLive: true })) {
      if (!x.date || String(x.date).slice(0, 10) >= f) continue;
      if (['aronium_eods', 'handovers', 'duty_runs'].includes(x.table)) continue; // till history: nothing to do
      add({ key: x.key, kind: x.type, date: String(x.date).slice(0, 10), amount: x.amount, shop: x.shop || null, text: [x.who, x.text].filter(Boolean).join(' · '), go: ['Verify', {}] });
    }
  } catch (e) { /* verify not ready */ }
  // Till shortages the cashier has not agreed to yet.
  try {
    const S = require('../modules/till/shifts.js');
    for (const s of S.undecidedShortages()) {
      if (!s.shift_date || s.shift_date >= f) continue;
      add({ key: `till_shortages:${s.uid}`, kind: 'Till shortage not decided', date: s.shift_date, amount: s.amount, shop: s.shop_code || null, text: `${s.name || ''} ${s.shift || ''}`.trim(), go: ['TillShortages', {}] });
    }
  } catch (e) { /* till not ready */ }
  return out.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}
// Home asks often: the summary is worked out again only after something is saved (or after a minute).
let cache = null;
export function beforeGoLiveSummary() {
  let w = 0; let d = null;
  try { w = writeCount(); d = db(); } catch (e) { w = 0; }
  const now = Date.now();
  if (cache && cache.w === w && cache.d === d && now - cache.t < 60000) return cache.v;
  const l = beforeGoLive();
  const open = l.filter((x) => !x.mark);
  const v = { total: l.length, open: open.length, seen: l.filter((x) => x.mark && x.mark.s === 'seen').length, aside: l.filter((x) => x.mark && x.mark.s === 'aside').length };
  cache = { w, d, t: now, v };
  return v;
}
