// 1.0.0 build 1 (hardening, audit H1): permission checks INSIDE every service that changes records or money, not only
// on the screens. Each service starts with one line, e.g. requirePerm(user, 'payments_make', { shop, money: true }).
//   - The person is looked up again in this device's logins (liveUser): a forged session (a phone object that says
//     "owner"), a login the owner disabled, and a session older than a role change get what the database says now.
//   - owner / admin: everything except the owner-only items (requireOwner). Shop-bound people (staff, baker,
//     supervisor, shop manager with a shop) only change their own shop's records (requireShop / { shop }).
//   - money: true also needs the phone's clock and time zone to be right (core.assertTimeOk – Fiji time).
// Work the app does by itself (sync, the Aronium link, warnings) runs inside withSystem() and is not stopped here; one
// service calling another for the same person (e.g. a till count posting its cash) wraps the inner call in asService().
import { db, writeCount, inSystem } from '../db/connection.js';
import { AppError, assertTimeOk } from './core.js';
import { crumb } from './breadcrumbs.js';

let memo = null;
function userIndex() {
  const d = db(); const w = writeCount();
  if (memo && memo.d === d && memo.w === w) return memo;
  const byUid = new Map(); const byId = new Map();
  let rows = [];
  try { rows = d.all('SELECT id, uid, name, role, active, shop_code FROM users'); } catch (e) { rows = []; }
  for (const r of rows) { if (r.uid) byUid.set(String(r.uid), r); byId.set(Number(r.id), r); }
  memo = { d, w, byUid, byId };
  return memo;
}
// The person as this device knows them NOW (role, active, shop), or null for no / unknown / disabled login.
// fresh: read the database now (the services' own checks); otherwise a copy kept until the next change (screens ask
// can() thousands of times).
function pick(user, byUid, byId) {
  let row = null;
  if (typeof user === 'number' || (typeof user === 'string' && /^\d+$/.test(user))) row = byId(Number(user));
  else if (typeof user === 'string') row = byUid(user);
  else if (typeof user === 'object') {
    row = user.uid ? byUid(String(user.uid)) : (user.id !== undefined && user.id !== null ? byId(Number(user.id)) : null);
    // the same person on both counts (a made-up object with a real uid but another id is not them)
    if (row && user.id !== undefined && user.id !== null && user.uid && Number(user.id) !== Number(row.id)) row = null;
  }
  return row || null;
}
export function liveUser(user, { fresh = false } = {}) {
  if (user === null || user === undefined || user === '') return null;
  if (typeof user === 'object' && user.role === 'system') return null; // the app's own work is not a person
  let row;
  if (fresh) {
    const q = (sql, v) => { try { return db().get(`SELECT id, uid, name, role, active, shop_code FROM users WHERE ${sql} = ?`, [v]) || null; } catch (e) { return null; } };
    row = pick(user, (u) => q('uid', u), (i) => q('id', i));
    // keep the screens' copy in step (a change undone outside the app's own transactions)
    if (memo && row) { const m = memo.byUid.get(String(row.uid)); if (!m || m.role !== row.role || Number(m.active) !== Number(row.active) || (m.shop_code || '') !== (row.shop_code || '')) memo = null; }
  } else {
    const ix = userIndex();
    row = pick(user, (u) => ix.byUid.get(u) || null, (i) => ix.byId.get(i) || null);
  }
  if (!row || Number(row.active) === 0) return null;
  return row;
}

let trusted = 0;
// The body of a checked service: the services it calls for the same job are not checked again (a till count posting
// its cash, goods-in saving the invoice), and its changes are all-or-nothing (one transaction: a refusal or a mistake
// half way leaves nothing half written). For an async service only the part before its first wait is covered, so a
// screen's later call is always checked on its own.
// 1.0.0 build 6: the outermost service call is noted for the problem report (its name or permission, how long it took,
// and whether it failed). name: optional, else the function's own name or the permission it checked.
// (the app's own work – sync, the Aronium link, practice data – is not noted: sync notes itself once)
let svc = null;
let lastPerm = '';
export function asService(fn, name) {
  const outer = trusted === 0 && !svc && !inSystem() && seeding === 0;
  const t0 = Date.now();
  if (outer) { svc = { name: name || (fn && fn.name) || '', perm: lastPerm }; lastPerm = ''; }
  trusted += 1;
  let r;
  let failed = null;
  try {
    let d = null; try { d = db(); } catch (e) { d = null; }
    r = d && typeof d.transaction === 'function' ? d.transaction(fn) : fn();
  } catch (e) { failed = e; throw e; } finally {
    trusted -= 1;
    if (outer) {
      const s = svc; svc = null;
      try { crumb('service', `${s.name || s.perm || 'service'} ${Date.now() - t0}ms${failed ? ' FAILED: ' + String((failed && failed.message) || failed).slice(0, 120) : ''}`); } catch (e) { /* ignore */ }
    }
  }
  return r;
}
// The practice (training) data is made by the app itself, as many made-up people over weeks of made-up days: the
// checks are off while it is made (only the practice database is written then).
let seeding = 0;
export async function whileSeeding(fn) { seeding += 1; try { return await fn(); } finally { seeding -= 1; } }
export function whileSeedingSync(fn) { seeding += 1; try { return fn(); } finally { seeding -= 1; } }
const skip = () => trusted > 0 || seeding > 0 || inSystem();

const NO_LOGIN = 'Please log in again – this login is not active on this device (it may have been changed or switched off by the owner).';
const SHOP_BOUND = ['staff', 'worker', 'supervisor', 'manager'];
const top = (u) => !!u && (u.role === 'owner' || u.role === 'admin');

// A real, active login (for a person's own things: tips seen, own layout, own hours …).
export function requireLogin(user) {
  if (skip()) return null;
  const u = liveUser(user, { fresh: true });
  if (!u) throw new AppError(NO_LOGIN);
  return u;
}
export function requireOwner(user, what = 'This') {
  if (skip()) return null;
  const u = requireLogin(user);
  const A = require('./access.js');
  if (!(u.role === 'owner' || A.actsAsOwner(u))) throw new AppError(what === 'This' ? 'Only the owner can do this (not an admin).' : `Only the owner can ${what} (not an admin).`);
  return u;
}
export function requireTop(user, what = 'This') {
  if (skip()) return null;
  const u = requireLogin(user);
  if (!top(u)) throw new AppError(what === 'This' ? 'Only the owner or an admin can do this.' : `Only the owner or an admin can ${what}.`);
  return u;
}
// A shop-bound person only works on their own shop's records.
export function requireShop(user, shopCode) {
  if (skip() || !shopCode) return;
  const u = liveUser(user, { fresh: true });
  if (!u || top(u)) return;
  if (SHOP_BOUND.includes(u.role) && u.shop_code && String(shopCode) !== String(u.shop_code)) {
    throw new AppError('That is the other shop\'s record. You can only change your own shop\'s records – ask the owner or admin.');
  }
}
// A shop-bound person (a shop manager …) only changes the rosters / records of people in their own shop (or their own).
export function requireOwnPerson(user, targetUid) {
  if (skip()) return;
  const u = liveUser(user, { fresh: true });
  if (!u || top(u) || !SHOP_BOUND.includes(u.role) || !u.shop_code) return;
  if (targetUid && String(targetUid) === String(u.uid)) return;
  const t = targetUid ? liveUser(String(targetUid), { fresh: true }) || (db().get('SELECT shop_code FROM users WHERE uid = ?', [String(targetUid)]) || null) : null;
  if (!t || String(t.shop_code || '') !== String(u.shop_code)) throw new AppError('That person is not in your shop. Only the owner or admin can change it.');
}
// The shop of a record (for services that are given only its uid).
export function shopOf(table, uid, col = 'shop_code') {
  if (!uid) return null;
  try { const r = db().get(`SELECT ${col} AS s FROM ${table} WHERE uid = ?`, [uid]); return r ? r.s : null; } catch (e) { return null; }
}
const AREA_WORDS = {
  accounts_journal: 'the books (journals)', accounts_close: 'closing the month', accounts_setup: 'the chart of accounts and book-keeping set-up',
  bank_rec: 'bank statements and reconciliation', wallets: 'M-PAiSA wallets', drawings: 'the owner\'s money', drawings_setup: 'the owner\'s money settings',
  payments_make: 'paying suppliers', cheques_manage: 'bank accounts and cheque books', ap_setup: 'suppliers and bills set-up', invoices_enter: 'entering invoices',
  invoices_check: 'checking and voiding invoices', till_count: 'till counts', till_approve: 'approving till counts and cash', deposits: 'cash records and deposits',
  payroll_run: 'pay runs', payroll_setup: 'pay rates and payroll set-up', statutory: 'FNPF and tax payments', owed_manage: 'what staff owe', owed_setup: 'credit limits',
  loans_manage: 'loans and rent', inventory_manage: 'products and stock', inventory_setup: 'inventory rules', po_create: 'purchase orders', po_approve: 'approving orders',
  po_receive: 'receiving goods', stocktake_count: 'stock takes', stocktake_approve: 'posting stock takes', bakery: 'the bakery', timesheets_edit: 'timesheets and rosters',
  face_enrol: 'staff faces', staff_manage: 'staff details (that is for someone who manages staff)', recruit_manage: 'vacancies and contracts', licences_manage: 'licences and permits', vehicles_use: 'vehicles',
  vehicles_manage: 'vehicle set-up', trade_manage: 'customer and supplier accounts', trade_credit_override: 'credit without an agreement', trade_view: 'trade accounts', trade_dispatch: 'sending out deliveries', trade_drive: 'deliveries', trade_map: 'the truck map', verify_money: 'verifying money records', verify_setup: 'verification rules', dashboard_setup: 'the dashboard set-up', settings: 'settings',
  leave_approve: 'approving leave', leave_setup: 'leave set-up', snap_upload: 'photos of papers', my_hours: 'your own hours', contract_sign: 'signing contracts',
};
// The main check. opts.shop: the shop of the record (own-shop rule); opts.money: the Fiji clock must be right.
export function requirePerm(user, perm, opts = {}) {
  if (svc && !svc.perm) svc.perm = [].concat(perm).join('/'); else if (!svc) lastPerm = [].concat(perm).join('/');
  if (skip()) return null;
  const u = liveUser(user, { fresh: true });
  if (!u) { crumb('refused', `${[].concat(perm).join('/')}: no login`); throw new AppError(NO_LOGIN); }
  const A = require('./access.js');
  if (A.isViewOnly(u)) throw new AppError('View only: this login can see records but not change them. Only the owner or admin changes records – use "Ask the owner".');
  const perms = [].concat(perm);
  // 'shop_staff': a shop staff member's own daily shop job (count stock, repack, their own till and shortage …);
  // 'role:x': people with that role (e.g. a supervisor drafts an order the manager approves)
  const ok = (p) => (p === 'shop_staff' ? u.role === 'staff' : /^role:/.test(p) ? u.role === p.slice(5) : A.can(u, p));
  if (!perms.some(ok)) {
    crumb('refused', `${perms.join('/')} for role ${u.role}`);
    const what = perms[0] === 'accounts_close' ? 'close a month' : `change ${AREA_WORDS[perms[0]] || 'this'}`;
    throw new AppError(`You are not allowed to ${what}. Only the owner or admin can do it – or a supervisor, manager or anyone the owner or an admin gave this permission (Staff profile › Permissions). You cannot change it here.`);
  }
  if (opts.shop) requireShop(u, opts.shop);
  if (opts.money) assertTimeOk('This');
  return u;
}
