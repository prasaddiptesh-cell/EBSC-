// v3.9.2 Help: step-by-step guides for every job, in plain words, with where to tap. Each guide is linked to the
// screens it is about (the ❓ button on those screens opens it, and the first time someone opens one of those screens a
// short tip offers it). "Show me how" opens the matching tutorial where there is one. Search finds any guide by words.
import { getShared, setShared } from './core.js';

// area order on the Help screen
export const AREAS = ['Getting started', 'Till & cash', 'Receiving & paying', 'Cheques & bank', 'Stock', 'Staff & pay', 'VAT & FNPF', 'Owner & admin'];

export const GUIDES = [
  // ---------------------------------------------------------------- Getting started
  { id: 'start-day', area: 'Getting started', title: 'Starting the day', when: 'Every morning, at each shop.',
    steps: ['Log in with your PIN (each person has their own – never share it).', 'Clock in on the Time Clock: tap your name, PIN, look at the camera.',
      'Look at the warnings on Home: red first (urgent), then orange. Tap a warning – it opens the screen where you fix it.',
      'Till & cash › Till shifts › start the shift for each till, with the cashier and the float.', 'Check "Still open" on yesterday\'s handover (Till & cash › Handovers by day).'],
    tips: ['If the app was closed or the tablet restarted, everything typed is already saved – just open it again.', 'The sync light at the top: green = everything is sent. Tap it to sync now.'], screens: ['Home', 'TillShifts'] },
  { id: 'photo-read', area: 'Getting started', title: 'Filling forms from a photo of the paper', when: 'Any time you take a photo of a Z report, invoice, receipt, deposit slip, lodgement receipt, cheque stub or statement.',
    steps: ['Take the photo FIRST, before typing anything. Hold the tablet flat over the paper, in good light, with the whole page in the picture.',
      'The tablet reads it by itself (no internet needed). The boxes it could read fill in, and a blue box lists each one with its figure.',
      'Check every figure against the paper. Change any box that is wrong – just type over it.',
      'Look at the green / orange checks under the list (for example "Cash + other payments = total sales"). Orange means something does not add up.',
      'Tick "I checked these figures against the paper". The app will not save until it is ticked.', 'Save as usual.'],
    tips: ['Nothing you typed yourself is ever overwritten – only empty boxes are filled.', 'Could not read it? Take the photo again flatter or in better light, tap "Read again", or just type the figures.',
      'What was read, and anything the person changed, is kept in the change history – the owner can see it.', 'A long paper? Take one photo per page – each new photo is read with the others.'],
    screens: [] },
  { id: 'warnings', area: 'Getting started', title: 'Warnings and the watchdog', when: 'When Home shows coloured warnings, or the owner wants to see what needs attention.',
    steps: ['Red = urgent (money at risk, something wrong now). Orange = needs attention soon. Blue = for information.', 'Tap a warning: it opens the screen to fix it.',
      'Admin & settings › Watchdog runs more checks (tampering, missing records, things left open) and says who should fix each one.', 'A warning goes away by itself when the problem is fixed.'],
    tips: ['You only see the warnings for your job. The owner and admin see everything.'], screens: ['Warnings', 'Watchdog'] },

  // ---------------------------------------------------------------- Till & cash
  { id: 'till-count', area: 'Till & cash', title: 'Count a till at the end of a shift', when: 'Every shift change, for every till.', tutorial: 'till',
    steps: ['In Aronium, print the End of day (Z report) for the till.', 'Till & cash › Count a till (or open the shift in Till shifts and tap Count).',
      'Take the photo of the Z report first – the Z number, total, cash, M-PAiSA and the other payments, VAT, refunds and customers fill in. Check them and tick that you checked.',
      'Count each note and coin and type how many of each. Enter the float left in the till for the next shift.', 'Add any cash paid out of the till (with what it was for) and drops to the safe.',
      'The cashier signs, and the person balancing signs (two different people).', 'Save. The result shows straight away: Balanced, Short or Over.'],
    tips: ['If the shop uses a blind count, the expected cash is shown only after saving.', 'A supervisor can count the drawer again (second count) – see "Second count".', 'Short or over by more than the allowed amount: write the reason.'],
    screens: ['TillCount', 'Till', 'TillShifts'] },
  { id: 'till-second', area: 'Till & cash', title: 'Second count by a supervisor', when: 'When a supervisor wants to confirm a cashier\'s count (by choice, or when the settings ask for it).',
    steps: ['Open the till balance (Till & cash › Today at the tills, or the warning).', 'Tap "Second count".', 'Count the drawer yourself. The first count is not shown while you count, so the two counts are independent.',
      'Save. If both counts agree it says so. If they differ, YOUR count stands; the first count, who did it and the difference are kept.', 'A shortage or over, and the cash moved to the safe, follow your count by themselves.'],
    tips: ['The second count must be done by someone else – not the cashier, not the person who counted first.', 'Settings (Till & cash › Tills & rules): "Second count" – when they choose to (normal), when short or over, or every till.'],
    screens: ['TillCountView'] },
  { id: 'till-short', area: 'Till & cash', title: 'When the till is short', when: 'A till balance shows Short by more than the allowed difference.',
    steps: ['Till & cash › Till shortages & over (or tap the red warning). Tap the shortage.',
      'If the cashier pays now: enter the amount they pay (all or part), the cashier signs, and the supervisor taps "Received … in cash". The money goes into the shop\'s cash.',
      'Anything not paid now: the cashier agrees and signs to have it taken from pay – all in the next pay, or in parts.',
      'If the cashier does not agree, they write why – a manager decides (take it from pay, or the owner writes it off).', 'Agreed amounts appear in the next pay run by themselves, as their own line on the payslip.'],
    tips: ['Shortages not decided yet show red in the pay run.', 'A cashier short again and again shows as a warning – worth a talk or more training.', 'A till over of the same cashier can be set against a shortage (see "When the till is over").'],
    screens: ['TillShortages'] },
  { id: 'till-over', area: 'Till & cash', title: 'When the till is over (surplus)', when: 'A till balance shows Over by more than the allowed difference.',
    steps: ['Till & cash › Till shortages & over › "Till over – to decide". Tap it.', 'Keep it: the business keeps the extra money.',
      'Set against a shortage: if the same cashier has a shortage not decided yet, the extra pays for it (it is not taken from pay).',
      'Given back: if a customer was short-changed and came back, enter how much was given back and to whom – it is taken out of the shop cash.'],
    tips: ['A cashier over again and again often means change not given or sales not rung up – it shows as a warning.'], screens: ['TillShortages'] },
  { id: 'eod', area: 'Till & cash', title: 'Aronium End of day matching', when: 'After the tills are balanced, or when a warning says an End of day differs or has no till balance.',
    steps: ['Till & cash › Aronium End of day.', 'Each Aronium End of day is matched to the till balance with the same Z number. Red = a difference, or no till balance yet.',
      'To type one in: "Type an End of day from Aronium" – take the photo of it first and the figures fill in.', 'Open a difference and explain it (the owner and admin need not write anything).'],
    tips: ['Until a difference is explained, the VAT return uses Aronium\'s figure.'], screens: ['AroniumEods', 'AroniumEod'] },
  { id: 'deposit', area: 'Till & cash', title: 'Bank the cash (deposit)', when: 'Each time cash and cheques are taken to the bank.', tutorial: 'till',
    steps: ['Till & cash › Bank deposit.', 'Have the stamped slip? Take its photo first – the slip number, date and branch fill in, and the amount is checked against your count.',
      'Choose the shop the cash is from and the bank account.', 'Count the notes and coins (or type the total) and add any customer cheques in the deposit.',
      '"What is this deposit covering?" – tick the cheques (or invoices about to be paid by cheque) this money is for. Extra money is fine – it is general money.',
      'Save. The cash leaves the shop\'s cash on hand and shows as "on the way" to the bank until the statement shows it.'],
    tips: ['The deposit and the cheques it covered appear on that day\'s handover.', 'A deposit that differs from its slip, or that the bank shows differently, is flagged when the statement is imported.'],
    screens: ['Deposit', 'Deposits'] },
  { id: 'petty', area: 'Till & cash', title: 'Petty cash, moving cash and counting the safe', when: 'Small things bought with shop cash, cash moved between shops, or the safe counted.',
    steps: ['Till & cash › Petty cash, move cash, count the safe.', 'Tap "Petty cash / move cash". For petty cash, take the receipt photo first – the amount, date and shop fill in.',
      'Choose what kind (petty cash spent, top-up, to another shop…), the amount, and what it was for. Save.', 'To count the safe: count the notes and coins; any difference with what the app expects is shown and recorded.'],
    tips: ['Cash on hand at each shop is always: starting cash + from the tills − banked − petty cash ± moves.'], screens: ['CashOnHand'] },
  { id: 'handover', area: 'Till & cash', title: 'Handover & takeover', when: 'At the end of your shift or day, before the next person takes over.',
    steps: ['Till & cash › Handover & takeover. Choose the shop, the day and the shift (or the whole day).',
      'Go through the page with the person taking over: tills (balanced, short, over), what was banked and which cheques each deposit covered, cheques written and handed over, deliveries, invoices, payments, petty cash, staff, and "Still open".',
      'Tap any line to open the record behind it.', 'Write notes for the next person, sign, and tap "Hand over".',
      'The person taking over chooses their name, writes anything that does not agree, signs, and taps "Take over".'],
    tips: ['Every handover is kept by day: Till & cash › Handovers by day – "what happened on Tuesday afternoon?".', 'The handover sheet can be shared as a PDF.', 'The owner gets a Viber note with the sales, banking and open items.'],
    screens: ['Handover', 'Handovers'] },

  // ---------------------------------------------------------------- Receiving & paying
  { id: 'receive-hub', area: 'Receiving & paying', title: 'Receive goods & papers (the one place for everything received)', when: 'A delivery arrives, an invoice or receipt is handed in, a cheque is handed over or received.', tutorial: 'receive',
    steps: ['Tap "Receive goods & papers" on Home (or in Inventory / Bakery).', 'Choose what it is: Delivery / invoice, Expense paid (receipt), Cheque handed over, Cheque received, or another paper.',
      'Take the photo first – the supplier, number and amount fill in. Check them and tick.',
      'Goods: choose the purchase order it is for (or none), tap Next and count what came off the truck – the stock goes up and the invoice is joined to the order.',
      'A bill with no goods (rent, power, repairs): choose "A bill – no goods"; if it was already paid, enter how it was paid.', 'Save. A supervisor confirms it on the To verify list.'],
    tips: ['Vehicle refuel and Bakery expense have their own quick buttons on the same screen.', 'No purchase order? A photo of the invoice or the goods is needed.'], screens: ['Snap', 'POReceive', 'MySnaps'] },
  { id: 'invoice', area: 'Receiving & paying', title: 'Enter a supplier invoice', when: 'An invoice to be paid later (on account).', tutorial: 'invoice',
    steps: ['Invoices & cheques › New invoice.', 'Take a photo of every page first – the supplier, number, date, total and VAT fill in. Check and tick.',
      'Choose the shop. On account? The due date comes from the supplier\'s terms.', 'Save. Someone else checks it before it is paid.'],
    tips: ['An invoice entered twice is caught (same supplier and number).', 'Wrong supplier name read? Choose the supplier from the list – the photo reading learns nothing wrong.'], screens: ['ApInvoiceEdit', 'ApInvoices', 'ApInvoice'] },
  { id: 'pay', area: 'Receiving & paying', title: 'Pay a supplier (cheque, cash, transfer, split, part, post-dated)', when: 'Paying one or more invoices.',
    steps: ['Invoices & cheques › Pay a supplier. Choose the supplier and tick the invoices.', 'Change an amount to pay only part – the invoice stays "part paid" and is flagged until the rest is paid.',
      'Choose how: cheque (the next cheque number comes from the drop-down), cash (from which shop, and who took it) or bank transfer (with the reference).',
      'Post-dated cheque (on-account suppliers): choose "Post-dated" and the date written on the cheque.', 'Split payment: some cash, some cheque, some transfer – add each part.',
      'Photo of the receipt / transfer / cheque stub: the reference and date fill in, and the amount is compared.', 'Pay. Write the cheque exactly as the screen says.'],
    tips: ['Every cheque written should have a deposit behind it – see "Cheques to cover".', 'A cheque number already used is refused.'], screens: ['ApPay', 'ApPayRun', 'ApPayment'] },

  // ---------------------------------------------------------------- Cheques & bank
  { id: 'cover', area: 'Cheques & bank', title: 'Cheques to cover', when: 'Every day – before cheques reach the bank.',
    steps: ['Invoices & cheques › Cheques to cover (also in Till & cash).', 'At the top: for each bank account, the cheques still out, how much is not covered, and what is left after everything clears. Red means the bank will be short.',
      '"Handed over – no deposit yet": these can reach the bank any day. Red after a few days.', '"Post-dated": reminders a few days before the date on the cheque; red on the date.',
      'Tick the cheques and tap "Make a deposit for these" – the deposit screen opens with them ticked.'],
    tips: ['A deposit made for an invoice before it is paid also covers the cheque that later pays it.', 'A cheque leaves the list when the bank statement shows it paid.', 'Owner / admin: the number of days before red, and the reminder before a post-dated cheque, are set at the bottom of the screen.'],
    screens: ['ChequeCover'] },
  { id: 'cheque-books', area: 'Cheques & bank', title: 'Cheque books and stubs', when: 'A new cheque book starts, or you need to see a cheque.',
    steps: ['Invoices & cheques › Cheque books & stubs. Add a new book with its first and last number.', 'Each leaf shows: written (to whom, how much), spoiled, or not used yet.',
      'Open a cheque: the stub, the invoices it paid, who wrote it, who it was handed to, when the bank paid it. Add a photo of the stub – the number and amount on it are checked.'],
    tips: ['A skipped cheque number is an urgent warning – record it as written or spoiled.', 'A warning comes before the last book runs out.'], screens: ['ChequeBooks', 'ChequeStub', 'Cheques'] },
  { id: 'bank-import', area: 'Cheques & bank', title: 'Import a bank statement and reconcile', when: 'When the BSP statement comes – any time in the month, and the whole month at month end.',
    steps: ['Cheques & bank › Import statement. Choose the BSP CSV / OFX / PDF file, paste the lines, or photograph each page of a paper statement.',
      'Check the dates, the number of lines and the closing balance, then Import.',
      'The app matches by itself: cheques paid, deposits (against their slips), M-PAiSA transfers, loan repayments, fees and interest.',
      'It flags: unknown cheques, wrong amounts, deposits that differ from the slip, possible duplicates, unusual amounts, and lines not in the app (record them with one tap).',
      'At month end: Cheques & bank › Month end – every step must be green, then save the Bank Reconciliation report for the accountant.'],
    tips: ['Items we recorded that the bank has not shown yet (cheques not presented, deposits in transit) are listed with their age.'], screens: ['BankImport', 'BankRec', 'Statement', 'BankMonthEnd'] },
  { id: 'supplier-statement', area: 'Cheques & bank', title: 'Check a supplier statement', when: 'A supplier sends their monthly statement.',
    steps: ['Invoices & cheques › Check a supplier statement.', 'Choose the supplier. Take the photo of their statement – their closing balance and date fill in.',
      'Tap Check: if it does not agree with our records, the app suggests why (an invoice missing or entered twice, a payment they have not received yet).'],
    tips: [], screens: ['ApStatement', 'ApSupplierStatement'] },

  // ---------------------------------------------------------------- Stock
  { id: 'po', area: 'Stock', title: 'Purchase orders', when: 'Ordering from a supplier.',
    steps: ['Inventory › Purchase orders › New. Choose the supplier and shop, add the products and quantities.', 'Send it (Viber / email / print). It shows as expected on its date.',
      'When it arrives, receive it on "Receive goods & papers" – the invoice photo fills in the number, total and quantities; count the goods and change any that differ, then tick.'],
    tips: ['An order not received by its date shows on the handover as still open.'], screens: ['POList', 'POEdit', 'POView'] },
  { id: 'stocktake', area: 'Stock', title: 'Stock take', when: 'Monthly, and at the year end.', tutorial: 'stocktake',
    steps: ['Inventory › Stock takes › New count for the shop.', 'Count each product (scan or search), type what is on the shelf.', 'Post the count: differences go to the stock and the books, with the reasons.'],
    tips: ['A count around 31 December is needed for the year end.'], screens: ['StockTakes', 'StockCount'] },

  // ---------------------------------------------------------------- Staff & pay
  { id: 'payrun', area: 'Staff & pay', title: 'The weekly pay run', when: 'Every Saturday (the week is Saturday to Friday).',
    steps: ['Staff timesheets: fix any missed clock-out (Timesheets) first.', 'Payroll › New pay run for the week.', 'Check each line: hours, overtime, holidays, leave, advances and till shortages taken back, FNPF and PAYE.',
      'Finalise. Each person signs their payslip on the tablet (or it is shared by Viber).', 'A mistake after finalising: reopen the pay run with a reason, fix it, finalise again.'],
    tips: ['Family members without FNPF are set up in their pay profile.', 'The FNPF schedule and PAYE follow the pay runs by themselves.'], screens: ['Payroll', 'NewPayRun', 'PayRun', 'PayLine'] },
  { id: 'timesheets', area: 'Staff & pay', title: 'Fixing timesheets', when: 'Someone forgot to clock in or out.',
    steps: ['Timesheets › the week › the person.', 'Add the missing Clock In / Clock Out with the reason.', 'It is kept in the history with who changed it.'], tips: [], screens: ['Timesheets', 'TimesheetPerson'] },
  { id: 'advance', area: 'Staff & pay', title: 'Advances, staff loans and staff credit', when: 'Giving money to staff, or staff buying on credit (Aronium).',
    steps: ['Payroll › Advances & staff credit › New.', 'Advance / loan: amount, how much to take back each week, how it was paid.',
      'Staff credit (Aronium): take the photo of the Aronium receipt – the amount and date fill in.', 'It is taken from pay each week until paid back.'], tips: [], screens: ['StaffDebts', 'Owed', 'CreditSettlements'] },
  { id: 'leave', area: 'Staff & pay', title: 'Leave', when: 'Someone asks for leave, or is sick.',
    steps: ['Leave › New request: the person, the type, the dates. Add a photo of a medical certificate when needed.', 'A manager approves it. Approved leave is paid in the pay run.'], tips: [], screens: ['Leave'] },

  // ---------------------------------------------------------------- VAT & FNPF
  { id: 'returns', area: 'VAT & FNPF', title: 'VAT return and FNPF schedule: lodge and pay', when: 'Every month (VAT by the end of the next month; FNPF schedule by the 14th, paid by month end).',
    steps: ['Payroll › VAT & FNPF returns. Open the month.', 'Check the figures (VAT lines 1–13, or the FNPF members). Fix anything marked FIX.',
      'Lodge with FRCS / FNPF online, then: take the photo or screenshot of the lodgement receipt – the reference and date fill in. Record the lodgement.',
      'Pay: take the photo of the receipt / transfer / cheque stub – the reference and date fill in and the amount is compared. Record the payment (it is booked in the accounts and the bank).',
      'Figures changed after lodging? The app flags it – lodge the amended return and record it (version 2).'],
    tips: ['Late? The penalty estimate is shown; record any penalty paid with the payment.'], screens: ['TaxReturns', 'TaxReturn', 'TaxCalendar', 'TaxItem', 'Statutory'] },

  // ---------------------------------------------------------------- Owner & admin
  { id: 'fix', area: 'Owner & admin', title: 'Correct a record (owner / admin)', when: 'Someone made a mistake in any record.',
    steps: ['Admin & settings › Correct a record – find it by number, supplier, person or date. Or open the record and tap "Correct (admin)".', 'Change any field. The screen shows what else the record is joined to.',
      'Save. The before and after are kept in the change history, and anything that no longer agrees is listed to look at.'], tips: ['To take a record out, set its status to void – it stays in the history.'], screens: ['RecordFix'] },
  { id: 'year-end', area: 'Owner & admin', title: 'Year end and the year archive', when: 'After 31 December, when the year is complete.',
    steps: ['Admin & settings › Year end & archive. The checks show what must be done first (books balance, VAT and FNPF lodged and paid, stock count, sync).',
      'Close and archive: the books are closed and a complete copy of the year is kept in Google Drive (never deleted) and on the tablet.'], tips: ['Old records stay in the app – any invoice or payslip can still be opened.'], screens: ['YearArchive', 'YearEndAcct'] },
  { id: 'training', area: 'Owner & admin', title: 'Practice (training) mode', when: 'Teaching someone, or trying something without touching the real records.',
    steps: ['Admin & settings › Training. Switch to training – a coloured bar shows you are practising.', 'Fill it with 3 or 6 months of practice history to practise on real-looking data.',
      'Tutorials (Help › Tutorials) walk through each job step by step, with a short check at the end.', 'Switch back when done. Nothing in training touches the real records.'], tips: [], screens: ['Training', 'Tutorials'] },
  { id: 'sync', area: 'Owner & admin', title: 'Several tablets, sync and conflicts', when: 'Using more than one tablet, or a warning about two devices.',
    steps: ['Each tablet works offline and syncs with the Easy Buys cloud when online. The light at the top shows it.',
      'If two tablets did the same thing (same invoice paid twice, same cheque, same till counted twice), an urgent warning shows both – keep one and void the other.', 'A record that could not be brought in is listed in Sync, not lost.'],
    tips: [], screens: ['Devices', 'DeviceDetail'] },
  { id: 'fuel', area: 'Owner & admin', title: 'Vehicle fuel', when: 'A vehicle is refuelled.',
    steps: ['Receive goods & papers › Vehicle refuel (or Vehicles › Enter fuel).', 'Take the receipt photo first – litres, amount, VAT, station and receipt number fill in.', 'Type the odometer. Save – it goes to expenses, VAT and the money.'], tips: ['Odd fuel use (km per litre) is flagged.'], screens: ['VeFuel', 'VeFuelLog'] },
  { id: 'loans-rent', area: 'Owner & admin', title: 'Loans, rent and their receipts', when: 'Paying a loan or rent, and keeping the receipt.',
    steps: ['Loans & rent shows each loan and regular bill, what is due and what is in arrears.', 'After paying, take a photo of the receipt (Receipts to photograph) – the receipt number and date fill in, and the amount is compared.'],
    tips: ['Loan repayments on the bank statement are matched by themselves.'], screens: ['LoansRent', 'RegularReceipts', 'LoanJourney'] },
];

export function getGuide(id) { return GUIDES.find((g) => g.id === id) || null; }
export function guidesForScreen(name) { return name ? GUIDES.filter((g) => (g.screens || []).includes(name)) : []; }
export function searchGuides(q) {
  const w = String(q || '').toLowerCase().split(/\s+/).filter((x) => x.length > 1);
  if (!w.length) return GUIDES;
  return GUIDES.map((g) => { const t = `${g.title} ${g.when} ${g.steps.join(' ')} ${(g.tips || []).join(' ')}`.toLowerCase(); return { g, n: w.filter((x) => t.includes(x)).length + (w.some((x) => g.title.toLowerCase().includes(x)) ? 2 : 0) }; })
    .filter((x) => x.n > 0).sort((a, b) => b.n - a.n).map((x) => x.g);
}
// The first-time tip on a screen: shown until the person taps "Got it" (kept per person, follows them on every device).
export function tipSeen(user, id) { const s = getShared('guide_tips_seen', {}) || {}; return !!(user && (s[user.uid] || []).includes(id)); }
export function markTipSeen(user, id) {
  if (!user) return;
  try { const s = getShared('guide_tips_seen', {}) || {}; const mine = new Set(s[user.uid] || []); mine.add(id); setShared('guide_tips_seen', { ...s, [user.uid]: Array.from(mine) }); } catch (e) { /* view-only users: just not remembered */ }
}
