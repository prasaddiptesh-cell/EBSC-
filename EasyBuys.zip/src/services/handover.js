// v3.9.2 Handover & takeover: a run-through of the day (or one shift) at a shop, read from everything already in the
// app – nothing is typed twice. The person finishing signs it over; the person taking over signs that they received it.
// Each line opens the record it comes from. Kept by date and shift; the figures at the time of signing are kept too.
//   handoverDay({ shopCode, date, shift }) → { sections: [{ key, title, rows: [{ text, sub, amount, tone, nav }] }], totals, open }
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, money } from './core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const $ = (n) => money(r2(n));
const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const all = (t, sql, args = []) => { if (!has(t)) return []; try { return db().all(sql, args); } catch (e) { try { console.warn('handover', t, e.message); } catch (x) { /* ignore */ } return []; } };
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

export { HANDOVER_SQL, HANDOVER_SYNC } from './handoverSchema.js';

function section(key, title, rows, extra = {}) { return { key, title, rows, ...extra }; }

export function handoverDay({ shopCode, date = dateStr(), shift = '' } = {}) {
  need(txt(shopCode), 'Choose the shop.');
  const d = date;
  const sh = txt(shift);
  const sections = [];
  const shopOrAll = (col) => `(${col} = ? OR ${col} IS NULL)`;

  // ---------------- tills
  const counts = all('till_counts', `SELECT * FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void' ${sh ? 'AND shift = ?' : ''} ORDER BY counted_at`, sh ? [shopCode, d, sh] : [shopCode, d]);
  let RC = null; let S = null;
  try { RC = require('../modules/till/recount.js'); S = require('../modules/till/shifts.js'); } catch (e) { /* till off */ }
  const tillRows = counts.map((c) => {
    const os = Number(c.over_short) || 0;
    const shortRec = S ? S.shortageForCount(c.uid) : null;
    const over = RC ? RC.surplusForCount(c.uid) : null;
    const extra = [];
    if (shortRec) extra.push(`shortage ${$(shortRec.amount)} – ${S.SHORT_STATUS[shortRec.status]}${shortRec.paid_now ? ` (paid ${$(shortRec.paid_now)} in cash)` : ''}`);
    if (over) extra.push(`over – ${RC.SURPLUS_STATUS[over.status]}`);
    if (c.second_status) extra.push(RC ? RC.SECOND_STATUS[c.second_status] : c.second_status);
    return { text: `${c.till_name || 'Till'} · ${c.shift || ''} · ${c.cashier_name || ''}`, sub: `Z ${c.z_number || '—'} · sales ${c.z_total == null ? '—' : $(c.z_total)} · counted ${$(c.cash_counted)}${extra.length ? ` · ${extra.join(' · ')}` : ''}`,
      amount: Math.abs(os) < 0.005 ? 'Balanced' : os > 0 ? `Over ${$(os)}` : `Short ${$(-os)}`, tone: Math.abs(os) < 0.005 ? 'good' : os > 0 ? 'warn' : 'bad', nav: { screen: 'TillCountView', params: { uid: c.uid } } };
  });
  const openShifts = all('till_shifts', `SELECT * FROM till_shifts WHERE shop_code = ? AND shift_date = ? AND status IN ('open','continued') ${sh ? 'AND shift = ?' : ''}`, sh ? [shopCode, d, sh] : [shopCode, d]);
  openShifts.forEach((s) => tillRows.push({ text: `${s.till_name || 'Till'} · ${s.shift} · ${s.cashier_name || ''}`, sub: s.status === 'continued' ? 'continued without a count – count it' : 'still running – not balanced yet', amount: 'NOT BALANCED', tone: 'bad', nav: { screen: 'TillShifts', params: {} } }));
  const sales = r2(counts.reduce((s, c) => s + (c.z_total == null ? Number(c.z_cash) || 0 : Number(c.z_total)), 0));
  sections.push(section('tills', `Tills (${counts.length} balanced${openShifts.length ? `, ${openShifts.length} not balanced` : ''})`, tillRows, { total: counts.length ? `Sales ${$(sales)}` : '' }));

  // ---------------- cash: deposits (with the cheques they covered), petty cash, moves
  let CV = null;
  try { CV = require('../modules/payables/cover.js'); } catch (e) { CV = null; }
  const deps = all('deposits', "SELECT * FROM deposits WHERE shop_code = ? AND deposit_date = ? AND status = 'active' ORDER BY created_at", [shopCode, d]);
  const depRows = deps.map((x) => {
    const cv = CV ? CV.depositCovers(x.uid) : [];
    const covered = r2(cv.reduce((s, c) => s + c.amount, 0));
    return { text: `Deposit slip ${x.slip_no || '—'} · by ${x.deposited_by_name || ''}`, sub: cv.length ? `Covers: ${cv.map((c) => `${c.label} ${$(c.amount)}`).join('; ')}${x.total - covered > 0.004 ? ` · ${$(x.total - covered)} general` : ''}` : 'Not linked to any cheque (general money)',
      amount: $(x.total), nav: { screen: 'Deposits', params: {} } };
  });
  sections.push(section('deposits', `Banked (${deps.length})`, depRows, { total: deps.length ? $(deps.reduce((s, x) => s + x.total, 0)) : '' }));
  const moves = all('cash_moves', "SELECT * FROM cash_moves WHERE shop_code = ? AND move_date = ? AND status = 'active' AND type NOT IN ('from_till','deposit') ORDER BY updated_at", [shopCode, d]);
  const LBL = { opening: 'Starting cash', petty_out: 'Petty cash spent', petty_in: 'Petty cash top-up', transfer_in: 'From another shop', transfer_out: 'To another shop', adjust_in: 'Cash in', adjust_out: 'Cash out' };
  sections.push(section('cash', `Petty cash & cash moves (${moves.length})`, moves.map((m) => ({ text: `${LBL[m.type] || m.type}${m.category ? ` · ${m.category}` : ''}`, sub: `${m.note || ''}${m.by_name ? ` · ${m.by_name}` : ''}`,
    amount: `${['petty_out', 'transfer_out', 'adjust_out'].includes(m.type) ? '−' : '+'}${$(m.amount)}`, nav: { screen: 'CashOnHand', params: { shopCode } } }))));
  let onHand = null;
  try { onHand = require('../modules/till/service.js').cashOnHand(shopCode); } catch (e) { onHand = null; }

  // ---------------- cheques: written, handed over, paid by the bank, post-dated coming up
  const chqW = all('cheques', `SELECT c.*, p.shop_code AS pay_shop, p.pay_date FROM cheques c LEFT JOIN ap_payments p ON p.uid = c.payment_uid WHERE c.status <> 'spoiled' AND (p.pay_date = ? OR (c.payment_uid IS NULL AND c.cheque_date = ?)) ORDER BY c.cheque_no`, [d, d]);
  const chqH = all('cheques', 'SELECT * FROM cheques WHERE handed_date = ? ORDER BY cheque_no', [d]);
  const chqP = all('cheques', "SELECT * FROM cheques WHERE status = 'presented' AND presented_date = ? ORDER BY cheque_no", [d]);
  const open = CV ? CV.openCheques({ today: d }) : [];
  const coverOf = (uid) => open.find((o) => o.uid === uid);
  const chqLine = (c, what) => {
    const o = coverOf(c.uid);
    const post = c.cheque_date > d;
    return { text: `Cheque ${c.cheque_no} · ${c.payee || ''}${post ? ` · dated ${c.cheque_date}` : ''}`, sub: `${what}${c.handed_to ? ` · to ${c.handed_to}` : ''}${o ? (o.left > 0.004 ? ` · NOT COVERED ${$(o.left)}` : ' · covered by a deposit') : c.status === 'presented' ? ' · paid by the bank' : ''}`,
      amount: $(c.amount), tone: o && o.left > 0.004 && (o.state === 'handed' || o.level) ? 'bad' : undefined, nav: { screen: 'ChequeStub', params: { accountUid: c.account_uid, chequeNo: c.cheque_no } } };
  };
  const chqRows = chqW.map((c) => chqLine(c, c.status === 'void' ? 'written – VOID' : 'written'))
    .concat(chqH.filter((c) => !chqW.some((w) => w.uid === c.uid)).map((c) => chqLine(c, 'handed over')))
    .concat(chqP.map((c) => ({ ...chqLine(c, 'paid by the bank today'), tone: 'good' })));
  sections.push(section('cheques', `Cheques (${chqW.length} written, ${chqH.length} handed over, ${chqP.length} paid by the bank)`, chqRows));
  const until = addDays(d, 7);
  const postSoon = open.filter((o) => o.state === 'post_dated' && o.date <= until && o.left > 0.004);
  const uncovered = open.filter((o) => o.state === 'handed' && o.left > 0.004);

  // ---------------- paperwork received: deliveries, invoices, receipts / photos; payments made
  const rcv = all('inv_receipts', "SELECT * FROM inv_receipts WHERE shop_code = ? AND receive_date = ? AND status = 'active' ORDER BY created_at", [shopCode, d]);
  sections.push(section('deliveries', `Deliveries received (${rcv.length})`, rcv.map((r) => ({ text: `${r.supplier_name || 'Supplier'}${r.invoice_no ? ` · invoice ${r.invoice_no}` : ''}`, sub: `${r.po_uid ? 'against an order' : 'no order'} · by ${r.by_name || ''}${r.match_note ? ` · ${r.match_note}` : ''}`, amount: $(r.total), nav: { screen: 'Receipt', params: { uid: r.uid } } }))));
  const invs = all('ap_invoices', `SELECT * FROM ap_invoices WHERE ${shopOrAll('shop_code')} AND status <> 'void' AND (substr(entered_at, 1, 10) = ? OR invoice_date = ?) ORDER BY entered_at`, [shopCode, d, d]);
  sections.push(section('invoices', `Supplier invoices & bills entered (${invs.length})`, invs.map((i) => ({ text: `${i.supplier_name || ''} · ${i.kind === 'credit' ? 'credit note' : 'invoice'} ${i.invoice_no || '—'}`, sub: `dated ${i.invoice_date}${i.due_date ? ` · due ${i.due_date}` : ''}${i.status === 'to_check' ? ' · TO CHECK' : ''}`, amount: $(i.total), nav: { screen: 'ApInvoice', params: { uid: i.uid } } }))));
  const pays = all('ap_payments', `SELECT * FROM ap_payments WHERE pay_date = ? AND status = 'active' AND (${shopOrAll('shop_code')}) ORDER BY created_at`, [d, shopCode]);
  sections.push(section('payments', `Supplier payments (${pays.length})`, pays.map((p) => ({ text: `${p.supplier_name} · ${p.method === 'cheque' ? `cheque ${p.cheque_no}` : p.method === 'cash' ? `cash${p.received_by ? ` to ${p.received_by}` : ''}` : p.method === 'transfer' ? `transfer ${p.reference || ''}` : p.method}`, sub: `by ${p.paid_by_name || ''}`, amount: $(p.amount), nav: { screen: 'ApPayment', params: { uid: p.uid } } }))));
  const snaps = all('money_snaps', 'SELECT * FROM money_snaps WHERE shop_code = ? AND snap_date = ? ORDER BY created_at', [shopCode, d]);
  sections.push(section('papers', `Papers photographed for the office (${snaps.length})`, snaps.map((x) => ({ text: `${{ invoice: 'Invoice', cheque_given: 'Cheque handed over', cheque_received: 'Cheque received', receipt: 'Receipt' }[x.kind] || x.kind}${x.party ? ` · ${x.party}` : ''}${x.ref_no ? ` · ${x.ref_no}` : ''}`, sub: `${x.status === 'waiting' ? 'waiting for a supervisor' : x.status}${x.by_name ? ` · by ${x.by_name}` : ''}`, amount: x.amount ? $(x.amount) : '', tone: x.status === 'waiting' ? 'warn' : undefined, nav: { screen: 'Verify', params: {} } }))));
  const fuel = all('ve_fuel', "SELECT * FROM ve_fuel WHERE fill_date = ? AND status = 'active' ORDER BY created_at", [d]);
  if (fuel.length) sections.push(section('fuel', `Fuel (${fuel.length})`, fuel.map((f) => ({ text: `${f.supplier || 'Fuel'} · ${f.litres} L`, sub: `${f.km} km · by ${f.by_name || ''}`, amount: $(f.amount), nav: { screen: 'VeFuelLog', params: {} } }))));

  // ---------------- people
  const punches = all('punches', "SELECT * FROM punches WHERE (shop_code = ? OR shop_code IS NULL) AND substr(at, 1, 10) = ? AND COALESCE(voided,0) = 0 ORDER BY at", [shopCode, d]);
  const per = {};
  punches.forEach((p) => { const x = (per[p.user_uid] = per[p.user_uid] || { name: p.name, ins: [], outs: [] }); if (p.type === 'IN') x.ins.push(String(p.at).slice(11, 16)); if (p.type === 'OUT') x.outs.push(String(p.at).slice(11, 16)); });
  const leave = all('leave_requests', "SELECT * FROM leave_requests WHERE status = 'approved' AND from_date <= ? AND to_date >= ?", [d, d]);
  sections.push(section('people', `Staff (${Object.keys(per).length} clocked in${leave.length ? `, ${leave.length} on leave` : ''})`, Object.values(per).map((x) => ({ text: x.name, sub: `in ${x.ins.join(', ') || '—'} · out ${x.outs.join(', ') || 'STILL CLOCKED IN'}`, tone: x.outs.length < x.ins.length ? 'warn' : undefined, nav: { screen: 'Timesheets', params: {} } })).concat(leave.map((l) => ({ text: l.name, sub: `on leave (${l.type})`, nav: { screen: 'Leave', params: {} } })))));

  // ---------------- still open (now): what the next person must know
  const openRows = [];
  uncovered.forEach((o) => openRows.push({ text: `Cheque ${o.no} · ${o.payee || ''} handed over ${o.handed} – no deposit behind it`, amount: $(o.left), tone: 'bad', nav: { screen: 'ChequeCover', params: {} } }));
  postSoon.forEach((o) => openRows.push({ text: `Post-dated cheque ${o.no} · ${o.payee || ''} dated ${o.date} – not covered yet`, amount: $(o.left), tone: o.level === 'urgent' ? 'bad' : 'warn', nav: { screen: 'ChequeCover', params: {} } }));
  if (S) S.undecidedShortages().filter((x) => x.shop_code === shopCode).forEach((x) => openRows.push({ text: `Till shortage ${x.name} ${x.shift_date} – ${S.SHORT_STATUS[x.status]}`, amount: $(x.amount), tone: 'bad', nav: { screen: 'TillShortages', params: {} } }));
  if (RC) RC.listSurpluses({ status: 'open' }).filter((x) => x.shop_code === shopCode).forEach((x) => openRows.push({ text: `Till over ${x.name} ${x.shift_date} – to decide`, amount: $(x.amount), tone: 'warn', nav: { screen: 'TillShortages', params: {} } }));
  if (RC) RC.countsWaitingSecond({ shopCode }).forEach((c) => openRows.push({ text: `${c.till_name} ${c.shift} ${c.shift_date} waits for a second count`, tone: 'warn', nav: { screen: 'TillCountView', params: { uid: c.uid } } }));
  all('po_orders', "SELECT * FROM po_orders WHERE shop_code = ? AND status IN ('sent','approved','part') AND expected_date IS NOT NULL AND expected_date <= ? ORDER BY expected_date", [shopCode, d])
    .forEach((p) => openRows.push({ text: `Order ${p.po_no} from ${p.supplier_name || ''} expected ${p.expected_date} – not received`, amount: $(p.total), tone: p.expected_date < d ? 'bad' : 'warn', nav: { screen: 'POView', params: { uid: p.uid } } }));
  const waitSnaps = all('money_snaps', "SELECT COUNT(*) AS n FROM money_snaps WHERE shop_code = ? AND status = 'waiting'", [shopCode]);
  if (waitSnaps[0] && waitSnaps[0].n) openRows.push({ text: `${waitSnaps[0].n} paper photo(s) waiting for a supervisor to confirm`, tone: 'warn', nav: { screen: 'Verify', params: {} } });
  sections.push(section('open', `Still open – for the next person (${openRows.length})`, openRows));

  const totals = { sales, banked: r2(deps.reduce((s, x) => s + x.total, 0)), cashOnHand: onHand ? onHand.onHand : null, floats: onHand ? onHand.floats : null,
    chequesWritten: r2(chqW.filter((c) => c.status !== 'void').reduce((s, c) => s + c.amount, 0)), uncovered: r2(uncovered.reduce((s, o) => s + o.left, 0)),
    deliveries: rcv.length, invoices: invs.length, openItems: openRows.length };
  return { shopCode, date: d, shift: sh, sections, totals };
}

// ---------------------------------------------------------------- the signed handover
export function listHandovers({ shopCode, from, to, limit = 100 } = {}) {
  if (!has('handovers')) return [];
  const w = ["status <> 'void'"]; const a = [];
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (from) { w.push('hand_date >= ?'); a.push(from); }
  if (to) { w.push('hand_date <= ?'); a.push(to); }
  return db().all(`SELECT * FROM handovers WHERE ${w.join(' AND ')} ORDER BY hand_date DESC, from_at DESC LIMIT ?`, a.concat([limit]));
}
export function getHandover(uid) {
  const r = has('handovers') ? db().get('SELECT * FROM handovers WHERE uid = ?', [uid]) : null;
  return r ? { ...r, summary: J(r.summary, {}) } : null;
}
export function handOver(user, { shopCode, date = dateStr(), shift = '', notes, signature }) {
  need(user, 'Log in first.');
  need(txt(shopCode), 'Choose the shop.');
  need(txt(signature), 'Sign to hand over.');
  need(/^\d{4}-\d{2}-\d{2}$/.test(date) && date <= dateStr(), 'Choose the day (not in the future).');
  const day = handoverDay({ shopCode, date, shift });
  const uid = uuid('HO');
  const now = stamp();
  const summary = { totals: day.totals, open: (day.sections.find((s) => s.key === 'open') || { rows: [] }).rows.map((r) => `${r.text}${r.amount ? ` ${r.amount}` : ''}`) };
  db().run(`INSERT INTO handovers (uid, shop_code, hand_date, shift, from_uid, from_name, from_sig, from_at, notes, summary, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?, 'handed', ?,?)`,
    [uid, shopCode, date, txt(shift) || null, user.uid, user.name, signature, now, txt(notes) || null, JSON.stringify(summary), now, deviceId()]);
  audit({ user, action: `Handover ${shopCode} ${date}${shift ? ` ${shift}` : ''}: handed over by ${user.name}${summary.open.length ? ` (${summary.open.length} open item(s))` : ''}`, table: 'handovers', recordUid: uid });
  try { require('../modules/verify/service.js').notify('handover', `Handover ${shopCode} ${date}${shift ? ` ${shift}` : ''} by ${user.name}: sales ${$(day.totals.sales)}, banked ${$(day.totals.banked)}${day.totals.uncovered ? `, cheques not covered ${$(day.totals.uncovered)}` : ''}, ${summary.open.length} open item(s).${txt(notes) ? ` Note: ${txt(notes)}` : ''}`, { shopCode }); } catch (e) { /* offline */ }
  return getHandover(uid);
}
export function takeOver(user, uid, { takerUid, signature, note } = {}) {
  const h = getHandover(uid);
  need(h && h.status === 'handed', 'This handover is already taken over.');
  need(txt(signature), 'Sign to take over.');
  const takerRow = takerUid ? db().get('SELECT uid, name FROM users WHERE uid = ?', [takerUid]) : null;
  const taker = takerRow || user;
  need(taker.uid !== h.from_uid, 'Someone else must take over – not the person who handed over.');
  const now = stamp();
  db().run(`UPDATE handovers SET to_uid = ?, to_name = ?, to_sig = ?, to_at = ?, to_note = ?, status = 'taken', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`,
    [taker.uid, taker.name, signature, now, txt(note) || null, now, deviceId(), uid]);
  audit({ user, action: `Handover ${h.shop_code} ${h.hand_date}${h.shift ? ` ${h.shift}` : ''}: taken over by ${taker.name}`, table: 'handovers', recordUid: uid, reason: txt(note) || undefined });
  return getHandover(uid);
}
export function waitingTakeover({ shopCode } = {}) {
  if (!has('handovers')) return [];
  return db().all(`SELECT * FROM handovers WHERE status = 'handed' ${shopCode ? 'AND shop_code = ?' : ''} ORDER BY from_at DESC`, shopCode ? [shopCode] : []);
}

// The run-through as a report (PDF / Excel / share).
export function handoverReport({ shopCode, date, shift, uid } = {}) {
  const h = uid ? getHandover(uid) : null;
  const day = handoverDay({ shopCode: h ? h.shop_code : shopCode, date: h ? h.hand_date : date, shift: h ? h.shift || '' : shift });
  const t = day.totals;
  return {
    kind: 'handover', title: 'Handover', fileName: `Handover-${day.shopCode}-${day.date}${day.shift ? `-${day.shift}` : ''}`, subtitle: `${day.shopCode} · ${day.date}${day.shift ? ` · ${day.shift}` : ' · whole day'}`,
    info: [['Shop', day.shopCode], ['Day', day.date], ['Shift', day.shift || 'Whole day'], ['Handed over by', h ? `${h.from_name} · ${String(h.from_at).slice(0, 16)}` : '—'], ['Taken over by', h && h.to_name ? `${h.to_name} · ${String(h.to_at).slice(0, 16)}` : '—'], ['Notes', h && h.notes ? h.notes : '—']],
    summary: [{ label: 'Sales', value: $(t.sales) }, { label: 'Banked', value: $(t.banked) }, { label: 'Cash at the shop now', value: t.cashOnHand === null ? '—' : $(t.cashOnHand) }, { label: 'Cheques not covered', value: $(t.uncovered), tone: t.uncovered > 0.004 ? 'bad' : 'good' }, { label: 'Open items', value: String(t.openItems), tone: t.openItems ? 'warn' : 'good' }],
    sections: day.sections.map((s) => ({ title: s.title, columns: [{ key: 'text', title: 'Item' }, { key: 'sub', title: 'Details' }, { key: 'amount', title: 'Amount', align: 'right' }], rows: s.rows.map((r) => ({ text: r.text, sub: r.sub || '', amount: r.amount || '', _tone: r.tone === 'bad' ? 'bad' : r.tone === 'warn' ? 'warn' : null })) })),
  };
}
