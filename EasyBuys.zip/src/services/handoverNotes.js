// 1.0.0 (build 1) Handover notes: short notes anyone adds during their shift ("Bread order short 10 loaves",
// "Fridge 2 making noise"). The next person reads them when they take over (Start shift shows the ones not read yet).
// Kept per place: a shop code, or BAKERY for the bakery. Notes are never deleted – a wrong one is crossed out.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays } from './core.js';
import { requireLogin, asService } from './guard.js';

export const BAKERY = 'BAKERY';
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = () => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = 'handover_notes'"); } catch (e) { return false; } };
const need = (c, m) => { if (!c) throw new AppError(m); };
const row = (r) => ({ ...r, read_by: J(r.read_by, {}) });

export function addNote(user, { place, text, shift = '', date = dateStr() }) {
  need(user, 'Log in first.');
  need(txt(place), 'Choose the shop.');
  const t = txt(text);
  need(t.length >= 2, 'Write the note.');
  need(t.length <= 500, 'Keep the note short (500 letters at most).');
  const uid = uuid('HN');
  const now = stamp();
  db().run(`INSERT INTO handover_notes (uid, place, note_date, shift, text, by_uid, by_name, at, read_by, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?, '{}', 'open', ?,?)`,
    [uid, txt(place), date, txt(shift) || null, t, user.uid, user.name, now, now, deviceId()]);
  audit({ user, action: `Handover note (${txt(place)}): ${t.slice(0, 80)}`, table: 'handover_notes', recordUid: uid });
  return getNote(uid);
}
export function getNote(uid) {
  const r = has() ? db().get('SELECT * FROM handover_notes WHERE uid = ?', [uid]) : null;
  return r ? row(r) : null;
}
// The notes of a place from a day on (default: today and yesterday – a night shift runs past midnight), newest first.
export function listNotes({ place, from, to, includeCrossed = false, limit = 200 } = {}) {
  if (!has() || !txt(place)) return [];
  const f = from || addDays(dateStr(), -1);
  return db().all(`SELECT * FROM handover_notes WHERE place = ? AND note_date >= ? AND note_date <= ? ${includeCrossed ? '' : "AND status <> 'crossed'"} ORDER BY at DESC LIMIT ?`,
    [txt(place), f, to || dateStr(), limit]).map(row);
}
// Notes this person has not read yet (written by someone else) – shown at Start shift.
export function unreadNotes(user, place, opts = {}) {
  if (!user) return [];
  return listNotes({ place, ...opts }).filter((n) => n.by_uid !== user.uid && !n.read_by[user.uid]);
}
export function markRead(user, uids) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!user || !has()) return 0;
  let n = 0;
  for (const uid of uids || []) {
    const r = getNote(uid);
    if (!r || r.read_by[user.uid]) continue;
    const rb = { ...r.read_by, [user.uid]: stamp() };
    db().run(`UPDATE handover_notes SET read_by = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [JSON.stringify(rb), stamp(), deviceId(), uid]);
    n += 1;
  }
  return n;
  });
}
// A wrong note is crossed out (by who wrote it, or a manager / the owner), never deleted.
export function crossOut(user, uid, reason = '') {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const r = getNote(uid);
  need(r && r.status !== 'crossed', 'Note not found.');
  const boss = user && ['owner', 'admin', 'manager', 'supervisor'].includes(user.role);
  need(boss || r.by_uid === user.uid, 'Only the person who wrote it, or a manager, can cross it out.');
  db().run(`UPDATE handover_notes SET status = 'crossed', updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?`, [stamp(), deviceId(), uid]);
  audit({ user, action: `Handover note crossed out: ${r.text.slice(0, 60)}`, table: 'handover_notes', recordUid: uid, reason: txt(reason) || undefined });
  });
}
// Notes written in one shift (for the End shift page and the handover sheet).
export function shiftNotes({ place, date = dateStr(), byUid } = {}) {
  return listNotes({ place, from: addDays(date, -1), to: date }).filter((n) => !byUid || n.by_uid === byUid);
}
