// v3.9.2 Handover & takeover records (see handover.js).
export const HANDOVER_SQL = `
CREATE TABLE IF NOT EXISTS handovers (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  hand_date TEXT NOT NULL,
  shift TEXT,
  from_uid TEXT, from_name TEXT, from_sig TEXT, from_at TEXT,
  to_uid TEXT, to_name TEXT, to_sig TEXT, to_at TEXT, to_note TEXT,
  notes TEXT,
  summary TEXT,
  status TEXT NOT NULL DEFAULT 'handed',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_handover_day ON handovers(shop_code, hand_date);
`;
export const HANDOVER_SYNC = {
  handovers: { key: 'uid', section: 'Till & cash', cols: ['uid', 'shop_code', 'hand_date', 'shift', 'from_uid', 'from_name', 'from_sig', 'from_at', 'to_uid', 'to_name', 'to_sig', 'to_at', 'to_note', 'notes', 'summary', 'status', 'updated_at', 'updated_device'] },
};

// v3.9.3 indexes for the handover, cheque cover and day lists (each on its own, so one can never stop the others).
export const SPEED_INDEXES = [
  'CREATE INDEX IF NOT EXISTS idx_chq_handed ON cheques(handed_date)',
  'CREATE INDEX IF NOT EXISTS idx_chq_status ON cheques(status, cheque_date)',
  'CREATE INDEX IF NOT EXISTS idx_app_paydate ON ap_payments(pay_date)',
  'CREATE INDEX IF NOT EXISTS idx_rcv_shopdate ON inv_receipts(shop_code, receive_date)',
  'CREATE INDEX IF NOT EXISTS idx_snaps_shopdate ON money_snaps(shop_code, snap_date)',
  'CREATE INDEX IF NOT EXISTS idx_dep_shopdate ON deposits(shop_code, deposit_date)',
  'CREATE INDEX IF NOT EXISTS idx_cash_shopdate ON cash_moves(shop_code, move_date)',
  'CREATE INDEX IF NOT EXISTS idx_punch_at ON punches(at)',
  'CREATE INDEX IF NOT EXISTS idx_tc_count ON till_counts(second_status)',
  'CREATE INDEX IF NOT EXISTS idx_tshort_count ON till_shortages(count_uid)',
  'CREATE INDEX IF NOT EXISTS idx_tsurplus_count ON till_surplus(count_uid)',
  'CREATE INDEX IF NOT EXISTS idx_alloc_payment ON ap_allocations(payment_uid)',
];
