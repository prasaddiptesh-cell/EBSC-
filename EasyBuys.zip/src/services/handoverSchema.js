// v3.9.2 Handover & takeover records (see handover.js).
export const HANDOVER_SQL = `
CREATE TABLE IF NOT EXISTS handovers (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  hand_date TEXT NOT NULL,
  shift TEXT,
  from_uid TEXT, from_name TEXT, from_sig TEXT, from_at TEXT,
  to_uid TEXT, to_name TEXT, to_sig TEXT, to_at TEXT, to_note TEXT,
  notes TEXT,
  summary TEXT,
  status TEXT NOT NULL DEFAULT 'handed',
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_handover_day ON handovers(shop_code, hand_date);
`;
export const HANDOVER_SYNC = {
  handovers: { key: 'uid', section: 'Till & cash', cols: ['uid', 'shop_code', 'hand_date', 'shift', 'from_uid', 'from_name', 'from_sig', 'from_at', 'to_uid', 'to_name', 'to_sig', 'to_at', 'to_note', 'notes', 'summary', 'status', 'updated_at', 'updated_device'] },
};
