// Health check.
// Quick check every time the app opens (hard limit 4 seconds, usually 1–2): the database opens and passes SQLite's
// quick check, the expected tables and version are there, settings and logins can be read, the clock is not earlier
// than the last time the app was used, free storage, age of the safety copies and backups, whether the app closed
// unexpectedly last time, items waiting to sync. When 4 seconds are reached the app opens and the rest carries on.
// Full check once a night when the tablet is idle, and from Admin › Health check › Run full check now: SQLite's full
// integrity check, the books balance, every document file present, the outbox healthy.
// Results: fine → silent; minor → a yellow warning on Home that taps through; damaged → the red restore screen.
// Every run is kept in the table health_checks (for the watchdog).
import { db } from '../db/connection.js';
import { getSetting, setSetting, stamp, clock, parseStamp, getSettings } from './core.js';
import { SCHEMA_VERSION, ALL_TABLES } from '../db/schema.js';

export const QUICK_BUDGET_MS = 4000;
export const LOW_STORAGE = 500 * 1e6;
export const VERY_LOW_STORAGE = 100 * 1e6;
export const STATUS_RANK = { ok: 0, info: 1, minor: 2, damaged: 3 };
export const HEALTH_SQL = `
CREATE TABLE IF NOT EXISTS health_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  at TEXT NOT NULL,
  status TEXT NOT NULL,
  ms INTEGER,
  timed_out INTEGER NOT NULL DEFAULT 0,
  results TEXT
);
`;

const ok = (text) => ({ status: 'ok', text });
const minor = (text, nav) => ({ status: 'minor', text, nav: nav || null });
const damaged = (text) => ({ status: 'damaged', text });
const hoursSince = (s, now) => (s ? (now.getTime() - parseStamp(s).getTime()) / 3600000 : Infinity);

export function expectedTables() {
  let synced = [];
  try { synced = Object.keys(require('./records.js').SYNC_TABLES); } catch (e) { synced = []; }
  // ALL_TABLES also lists old tables that are only there to be removed on upgrade ('production').
  return Array.from(new Set(ALL_TABLES.filter((t) => t !== 'production').concat(synced)));
}
export function worst(results) {
  return results.reduce((w, r) => (STATUS_RANK[r.status] > STATUS_RANK[w] ? r.status : w), 'ok');
}

// The quick steps. `env` lets tests (and the start-up code) pass what the app knows: { lastClose, freeDisk(), now }.
export function quickSteps(env = {}) {
  const now = () => (env.now ? env.now() : clock.now());
  return [
    { id: 'db', label: 'Database opens', critical: true, run: () => {
      const r = db().all('PRAGMA quick_check');
      const v = r.length ? Object.values(r[0])[0] : 'no answer';
      return v === 'ok' ? ok('The database is fine.') : damaged(`The database is damaged (${String(v).slice(0, 120)}).`);
    } },
    { id: 'tables', label: 'Tables and version', critical: true, run: () => {
      const have = new Set(db().all("SELECT name FROM sqlite_master WHERE type = 'table'").map((x) => x.name));
      const missing = expectedTables().filter((t) => !have.has(t));
      if (missing.length) return damaged(`${missing.length} table${missing.length === 1 ? '' : 's'} missing: ${missing.slice(0, 5).join(', ')}`);
      const v = Number(getSetting('schema_version', '0'));
      return v === SCHEMA_VERSION ? ok(`Version ${v}.`) : minor(`Database version is ${v}, expected ${SCHEMA_VERSION}.`, { screen: 'Problems', params: {} });
    } },
    { id: 'settings', label: 'Settings and logins', critical: true, run: () => {
      db().get('SELECT COUNT(*) AS n FROM settings');
      const u = db().get('SELECT COUNT(*) AS n FROM users WHERE active = 1').n;
      return u ? ok(`${u} people can log in.`) : minor('Nobody can log in (no active people).', { screen: 'Users', params: {} });
    } },
    { id: 'clock', label: 'Clock', run: () => {
      const t = now();
      const last = getSetting('last_known_time', '');
      const s = stamp(t);
      if (last && parseStamp(last).getTime() - t.getTime() > 5 * 60000) {
        return minor(`The tablet's clock (${s.slice(0, 16)}) is earlier than the last time the app was used (${last.slice(0, 16)}). Check the date and time in Android settings.`);
      }
      setSetting('last_known_time', s);
      return ok('The clock looks right.');
    } },
    { id: 'storage', label: 'Free storage', run: async () => {
      const free = env.freeDisk ? await env.freeDisk() : null;
      if (free === null || free === undefined) return ok('Not known on this device.');
      if (free < VERY_LOW_STORAGE) return minor(`Storage almost full: only ${Math.round(free / 1e6)} MB free. Delete old photos or videos on the tablet.`);
      if (free < LOW_STORAGE) return minor(`Storage is getting full: ${Math.round(free / 1e6)} MB free.`);
      return ok(`${(free / 1e9).toFixed(1)} GB free.`);
    } },
    { id: 'copies', label: 'Safety copies and backups', run: () => {
      const t = now();
      const snapH = hoursSince(getSetting('last_snapshot_at', ''), t);
      const issues = [];
      // A new install makes its first copy within the first hour; only flag a missing copy after two days of use.
      let first = getSetting('first_health_at', '');
      if (!first) { first = stamp(t); setSetting('first_health_at', first); }
      const inUseH = hoursSince(first, t);
      if (snapH > 48 && (getSetting('last_snapshot_at', '') || inUseH > 48)) issues.push(getSetting('last_snapshot_at', '') ? `The last safety copy on the tablet is ${Math.floor(snapH / 24)} days old.` : 'No safety copy on the tablet yet.');
      if (getSettings().cloudUrl) {
        const bH = hoursSince(getSetting('last_backup_at', ''), t);
        if (bH > 72) issues.push(getSetting('last_backup_at', '') ? `The last Google Drive backup is ${Math.floor(bH / 24)} days old.` : 'No Google Drive backup from this device yet.');
      }
      return issues.length ? minor(issues.join(' '), { screen: 'Backup', params: {} }) : ok('Copies are recent.');
    } },
    { id: 'lastClose', label: 'Last close', run: () => (env.lastClose ? minor(`The app closed unexpectedly last time${env.lastClose.where ? ` (on "${env.lastClose.where}")` : ''}.`, { screen: 'Problems', params: {} }) : ok('Closed normally.')) },
    { id: 'sync', label: 'Waiting to sync', run: () => {
      if (!getSettings().cloudUrl) return ok('Not linked.');
      let waiting = 0;
      try { waiting = require('./syncInfo.js').waitingCount(); } catch (e) { waiting = 0; }
      const h = hoursSince(getSetting('last_sync_ok_at', ''), now());
      if (waiting && h > 24) return minor(`${waiting} item${waiting === 1 ? '' : 's'} have been waiting to sync for over a day.`, { screen: 'SyncStatus', params: {} });
      return ok(waiting ? `${waiting} waiting.` : 'Nothing waiting.');
    } },
  ];
}

// Runs steps one after another. Returns { first, all, state }:
// `first` settles when everything is done or the budget is reached (whichever comes first) – the splash waits for it;
// `all` settles when every step has run (it carries on in the background after the budget).
export function runHealthSteps(steps, { kind = 'quick', budgetMs = QUICK_BUDGET_MS, timer = setTimeout, nowMs = () => Date.now(), onStep, store = true } = {}) {
  const state = { kind, results: [], done: false, timedOut: false, status: 'ok', startedAt: stamp(), ms: 0 };
  const t0 = nowMs();
  const all = (async () => {
    for (const s of steps) {
      const s0 = nowMs();
      let r;
      try { r = await s.run(); } catch (e) { r = s.critical ? damaged(`${s.label}: ${e.message || e}`) : minor(`${s.label}: ${e.message || e}`); }
      state.results.push({ id: s.id, label: s.label, ms: nowMs() - s0, ...r });
      state.status = worst(state.results);
      if (onStep) { try { onStep(state); } catch (e) { /* ignore */ } }
      await new Promise((res) => timer(res, 0)); // let the screen update and the time limit fire
    }
    state.done = true;
    state.ms = nowMs() - t0;
    if (store) storeHealth(state);
    return state;
  })();
  const first = budgetMs ? Promise.race([all, new Promise((res) => timer(() => { if (!state.done) state.timedOut = true; res(state); }, budgetMs))]) : all;
  return { first, all, state };
}
export function startQuickCheck(env = {}, opts = {}) {
  return runHealthSteps(quickSteps(env), { kind: 'quick', ...opts });
}

// ---------------------------------------------------------------- full check
export function fullSteps(env = {}) {
  return [
    { id: 'integrity', label: 'Full database check', critical: true, run: () => {
      const r = db().all('PRAGMA integrity_check');
      const v = r.length ? Object.values(r[0])[0] : 'no answer';
      return v === 'ok' ? ok('Every page of the database is fine.') : damaged(`Database damage found: ${r.slice(0, 3).map((x) => Object.values(x)[0]).join('; ').slice(0, 200)}`);
    } },
    { id: 'books', label: 'Books balance', run: () => {
      let tb = null;
      try { tb = require('../modules/accounting/service.js').trialBalance(); } catch (e) { return ok('Accounting not in use.'); }
      return tb.ok ? ok(`Debits and credits agree (${tb.dr.toFixed(2)}).`) : minor(`The books do not balance: debits ${tb.dr.toFixed(2)}, credits ${tb.cr.toFixed(2)}.`, { screen: 'TrialBalance', params: {} });
    } },
    { id: 'files', label: 'Document and photo files', run: async () => {
      const exists = env.exists || (async () => true);
      let missing = 0; let checked = 0;
      let docs = [];
      try { docs = db().all("SELECT d.uid, d.cloud_id, l.path FROM documents d LEFT JOIN doc_local l ON l.uid = d.uid WHERE d.status = 'active'"); } catch (e) { docs = []; }
      for (const d of docs) { if (d.cloud_id) continue; checked += 1; if (!d.path || !(await exists(d.path))) missing += 1; }
      let photos = [];
      try { photos = db().all("SELECT uri FROM photos WHERE (cloud_url IS NULL OR cloud_url = '') AND uri LIKE 'file:%' ORDER BY id DESC LIMIT 500"); } catch (e) { photos = []; }
      for (const p of photos) { checked += 1; if (!(await exists(p.uri))) missing += 1; }
      return missing ? minor(`${missing} document or photo file${missing === 1 ? '' : 's'} missing on this device and not in the cloud.`, { screen: 'Problems', params: {} }) : ok(`${checked} local file${checked === 1 ? '' : 's'} checked.`);
    } },
    { id: 'outbox', label: 'Items waiting to send', run: () => {
      const stuck = db().get('SELECT COUNT(*) AS n FROM outbox WHERE sent_at IS NULL AND attempts >= 3').n;
      const old = db().get('SELECT MIN(created_at) AS t FROM outbox WHERE sent_at IS NULL').t;
      const t = env.now ? env.now() : clock.now();
      if (stuck) return minor(`${stuck} item${stuck === 1 ? '' : 's'} failed to send 3 times or more.`, { screen: 'SyncStatus', params: {} });
      if (old && hoursSince(old, t) > 48 && getSettings().cloudUrl) return minor(`Items have been waiting to send since ${old.slice(0, 16)}.`, { screen: 'SyncStatus', params: {} });
      return ok('Nothing stuck.');
    } },
    { id: 'history', label: 'Change history chain', run: () => ({ status: 'info', text: 'Checked by the watchdog (coming next).' }) },
  ];
}
export function startFullCheck(env = {}, opts = {}) {
  return runHealthSteps(fullSteps(env), { kind: 'full', budgetMs: 0, ...opts });
}
// Overnight: once a day, when nobody has touched the tablet for a while (charging is not known without another
// library, so "idle at night" is used: between 10 pm and 6 am, or any time when the last full check is 2 days old).
export function fullCheckDue({ idleMinutes = 0, now = clock.now() } = {}) {
  const last = getSetting('last_full_health_at', '');
  const h = hoursSince(last, now);
  if (h < 20) return false;
  if (idleMinutes < 5) return false;
  const hr = now.getHours();
  return hr >= 22 || hr < 6 || h > 48;
}

// ---------------------------------------------------------------- results
export function storeHealth(state) {
  try {
    db().exec(HEALTH_SQL);
    db().run('INSERT INTO health_checks (kind, at, status, ms, timed_out, results) VALUES (?, ?, ?, ?, ?, ?)',
      [state.kind, stamp(), state.status, Math.round(state.ms || 0), state.timedOut ? 1 : 0, JSON.stringify(state.results)]);
    db().run("DELETE FROM health_checks WHERE id NOT IN (SELECT id FROM health_checks ORDER BY id DESC LIMIT 400)");
    setSetting(state.kind === 'full' ? 'last_full_health_at' : 'last_health_at', stamp());
    setSetting(state.kind === 'full' ? 'last_full_health_status' : 'last_health_status', state.status);
  } catch (e) { /* a damaged database may refuse; the screen still shows the result */ }
}
export function latestHealth(kind = 'quick') {
  try {
    const r = db().get('SELECT * FROM health_checks WHERE kind = ? ORDER BY id DESC LIMIT 1', [kind]);
    return r ? { ...r, results: JSON.parse(r.results || '[]') } : null;
  } catch (e) { return null; }
}
export function healthHistory(limit = 30) {
  try { return db().all('SELECT id, kind, at, status, ms, timed_out FROM health_checks ORDER BY id DESC LIMIT ?', [limit]); } catch (e) { return []; }
}
// Problems from the latest quick and full checks, for the warnings on Home.
export function healthIssues() {
  const out = [];
  for (const kind of ['quick', 'full']) {
    const h = latestHealth(kind);
    if (!h) continue;
    for (const r of h.results) if (r.status === 'minor' || r.status === 'damaged') out.push({ ...r, kind, at: h.at });
  }
  return out;
}

// Owner / admin PIN check. Returns null when the logins cannot be read (then the PIN is checked on the restored copy).
export function adminPinOk(pin, adapter) {
  const p = String(pin || '').trim();
  if (!p) return false;
  const tryOn = (a) => { try { return !!a.get("SELECT 1 AS x FROM users WHERE pin = ? AND active = 1 AND role IN ('owner','admin')", [p]); } catch (e) { return null; } };
  let a = adapter;
  if (!a) { try { a = db(); } catch (e) { return null; } }
  return tryOn(a); // true / false, or null when the logins cannot be read (damaged database)
}
