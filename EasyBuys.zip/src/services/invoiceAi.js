// 1.0.0 Reading supplier invoices with AI: Google Gemini in the owner's own cloud (cloud/Code.gs › invoice_ai).
// The cloud returns JSON (see AI_FIELDS); this file turns it into what the app already uses, so the same checks run
// after it (matchItem, matchToOrder, flagCostChanges, "the lines add up", the VAT check) and the person still ticks
// "Looks right" / "I checked these figures against the paper". Pure functions – no React, no device code.
//   aiHints(suppliers, vatRate)          → the hints sent with the photos
//   cleanAi(json, { today })             → the AI answer checked and tidied (numbers, dates, lines)
//   aiHeader(ai, suppliers)              → { supplierName, supplierUid, tin, invoiceNo, invoiceDate, subtotal, vat, total, … }
//   aiItemLines(ai, vatRate)             → item lines in the shape parseItemLine gives
//   aiToText(ai)                         → plain text the older readers understand (payables › invoice, the saved reading)
//   aiPaperFields(kind, ai, ctx)         → the boxes of a paper-photo screen (invoice, fuel receipt)
import { ebMatchSupplier, ebPlausibleDate, EB_BUYER_TIN, EB_BUYER_RE } from '../modules/payables/parser.js';

export const BUYER = { name: 'Easy Buys Shopping Centre', tin: '50-14315-0-7' };
export const AI_FIELDS = ['supplier', 'supplier_tin', 'invoice_no', 'invoice_date', 'prices_incl_vat', 'subtotal_excl', 'vat', 'total_incl', 'lines', 'notes', 'confidence'];
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r4 = (n) => Math.round((Number(n) || 0) * 10000) / 10000;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const num = (v) => {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(String(v).replace(/[$,\s]/g, '').replace(/^FJD/i, ''));
  return Number.isFinite(n) ? n : null;
};

export function aiHints(suppliers = [], vatRate = 0.125) {
  const names = [];
  for (const s of suppliers || []) { const n = txt(s && s.name); if (n && !EB_BUYER_RE.test(n) && !names.includes(n)) names.push(n); }
  return { suppliers: names.slice(0, 200), buyer: BUYER, vatPct: Math.round(vatRate * 1000) / 10, country: 'Fiji' };
}

// The AI answer, checked: the buyer is never the supplier, dates far from today are dropped, lines without a name go.
export function cleanAi(json, { today } = {}) {
  const j = json && typeof json === 'object' ? (json.invoice && typeof json.invoice === 'object' ? json.invoice : json) : {};
  const notes = [];
  let supplier = txt(j.supplier) || null;
  let tin = txt(j.supplier_tin).replace(/[^0-9]/g, '') || null;
  if (tin === EB_BUYER_TIN) { tin = null; notes.push('The TIN read was Easy Buys\' own – the supplier\'s TIN was left empty.'); }
  if (supplier && EB_BUYER_RE.test(supplier)) { supplier = null; notes.push('The name read was Easy Buys (the buyer) – choose the supplier.'); }
  let date = txt(j.invoice_date);
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(date);
  date = m ? `${m[1]}-${m[2]}-${m[3]}` : null;
  if (date && !ebPlausibleDate(date, today)) { notes.push(`The date read (${date}) is far from today – type the invoice date.`); date = null; }
  const lines = (Array.isArray(j.lines) ? j.lines : []).map((l) => ({
    code: txt(l && l.code) || null,
    description: txt(l && l.description),
    qty: num(l && l.qty),
    unit: txt(l && l.unit) || null,
    unit_price: num(l && l.unit_price),
    disc_pct: num(l && l.disc_pct),
    vat_pct: num(l && l.vat_pct),
    line_total: num(l && l.line_total),
  })).filter((l) => /[a-z]{2,}/i.test(l.description) && (l.line_total !== null || l.unit_price !== null));
  const conf = num(j.confidence);
  // 1.0.0 build 54: a power / water bill (hints.bill) also gives the account number and the date to pay by
  const acct = txt(j.account_no).replace(/[^0-9A-Za-z]/g, '') || null;
  const dm = /^(\d{4})-(\d{2})-(\d{2})/.exec(txt(j.due_date));
  let due = dm ? `${dm[1]}-${dm[2]}-${dm[3]}` : null;
  if (due && !ebPlausibleDate(due, today)) { notes.push(`The due date read (${due}) is far from today – type it from the bill.`); due = null; }
  return {
    account_no: acct, due_date: due,
    supplier, supplier_tin: tin, invoice_no: txt(j.invoice_no).replace(/\s+/g, '') || null, invoice_date: date,
    prices_incl_vat: j.prices_incl_vat === true || j.prices_incl_vat === 'true',
    subtotal_excl: num(j.subtotal_excl), vat: num(j.vat), total_incl: num(j.total_incl),
    lines, notes: [txt(j.notes)].filter(Boolean).concat(notes), confidence: conf === null ? null : Math.max(0, Math.min(1, conf > 1 ? conf / 100 : conf)),
  };
}

// The known supplier: the same matching as the offline reader (TIN, phone, name, a close name).
export function aiSupplier(ai, suppliers = []) {
  const text = [ai.supplier, ai.supplier_tin ? `TIN ${ai.supplier_tin}` : ''].filter(Boolean).join('\n');
  if (!text) return null;
  const hit = ebMatchSupplier(text, text.split('\n'), suppliers, ai.supplier_tin ? [ai.supplier_tin] : []);
  return hit ? hit.supplier : null;
}

export function aiHeader(ai, suppliers = []) {
  const s = aiSupplier(ai, suppliers);
  const notes = ai.notes.slice();
  let { vat } = ai;
  const total = ai.total_incl;
  const sub = ai.subtotal_excl !== null ? ai.subtotal_excl : (total !== null && vat !== null ? r2(total - vat) : null);
  if (vat === null && total !== null && sub !== null && total >= sub) vat = r2(total - sub);
  if (total !== null && sub !== null && vat !== null && Math.abs(r2(sub + vat) - total) > 0.05) notes.push(`Before VAT ${sub.toFixed(2)} + VAT ${vat.toFixed(2)} is not the total ${total.toFixed(2)} – check them.`);
  if (ai.confidence !== null && ai.confidence < 0.6) notes.push('The AI was not sure about this invoice – check every figure.');
  if (!s && ai.supplier) notes.push(`New supplier? Read as "${ai.supplier}".`);
  return {
    supplierUid: s && s.uid ? s.uid : null, supplierName: s ? s.name : ai.supplier, tin: ai.supplier_tin || (s && s.tin ? String(s.tin).replace(/[^0-9]/g, '') : null),
    invoiceNo: ai.invoice_no, invoiceDate: ai.invoice_date, subtotal: sub, vat, total, pricesIncVat: ai.prices_incl_vat, notes,
  };
}

// Item lines like parseItemLine: { raw, code, description, qty, unitCost (one, before VAT, after discount), total (before VAT), nums, vatPct }
export function aiItemLines(ai, vatRate = 0.125) {
  return ai.lines.map((l) => {
    const qty = l.qty > 0 ? l.qty : 1;
    const vp = l.vat_pct !== null ? l.vat_pct : vatRate * 100;
    let amount = l.line_total !== null ? l.line_total : (l.unit_price || 0) * qty * (1 - (l.disc_pct || 0) / 100);
    if (ai.prices_incl_vat && vp > 0) amount /= 1 + vp / 100;
    const unitCost = r4(amount / qty);
    // The line as text the offline reader reads back the same way ("CODE Name 3 4.9200 12.5% 14.76", zero rated "… ZR"):
    // kept with the reading, used by the VAT evidence (lineVat) and when a supplier's layout is taught from it.
    // (no word "VAT" on the line: the text readers would take the line amount for the invoice's VAT)
    const raw = [l.code, l.description, String(Math.round(qty * 1000) / 1000), unitCost.toFixed(Math.abs(unitCost * 100 - Math.round(unitCost * 100)) > 1e-6 ? 4 : 2),
      l.vat_pct !== null && l.vat_pct > 0 ? `${l.vat_pct}%` : '', r2(amount).toFixed(2), l.vat_pct === 0 ? 'ZR' : ''].filter(Boolean).join(' ');
    return { raw, code: l.code, description: l.description, qty: Math.round(qty * 1000) / 1000, unitCost, total: r2(amount), nums: [], vatPct: l.vat_pct, unit: l.unit, by: 'ai' };
  });
}

// Plain text with the header written the way the offline reader reads it, then the lines (kept with the reading, and
// given to screens that only take text: payables › invoices fill in from it).
export function aiToText(ai) {
  const d = ai.invoice_date ? ai.invoice_date.split('-').reverse().join('/') : '';
  const out = [];
  if (ai.supplier) out.push(`Supplier: ${ai.supplier}`);
  if (ai.supplier_tin) out.push(`TIN: ${ai.supplier_tin}`);
  if (ai.invoice_no) out.push(`Invoice No: ${ai.invoice_no}`);
  if (d) out.push(`Invoice Date: ${d}`);
  for (const l of aiItemLines(ai)) out.push(l.raw);
  if (ai.subtotal_excl !== null) out.push(`Sub Total: ${ai.subtotal_excl.toFixed(2)}`);
  if (ai.vat !== null) out.push(`VAT Amount: ${ai.vat.toFixed(2)}`);
  if (ai.total_incl !== null) out.push(`Invoice Total: ${ai.total_incl.toFixed(2)}`);
  return out.join('\n');
}

// The boxes of a paper-photo screen (services/paperRead.js READERS.invoice / fuel give the same fields).
export function aiPaperFields(kind, ai, ctx = {}) {
  if (kind === 'efl_bill') return aiBillFields(ai);
  const h = aiHeader(ai, ctx.suppliers || []);
  const f = {};
  if (h.supplierName) f.supplierName = h.supplierName;
  if (h.tin) f.tin = h.tin;
  if (h.invoiceNo) f.invoiceNo = h.invoiceNo;
  if (h.invoiceDate) f.date = h.invoiceDate;
  if (h.total !== null) f.total = r2(h.total);
  if (h.vat !== null) f.vat = r2(h.vat);
  if (h.subtotal !== null) f.subtotal = r2(h.subtotal);
  if (h.supplierUid) f.supplierUid = h.supplierUid;
  else if (f.supplierName) f.newSupplierName = f.supplierName;
  const checks = h.notes.filter((n) => !/^New supplier\?/.test(n)).map((n) => ({ level: 'warn', text: n }));
  if (f.supplierName && !f.supplierUid && (ctx.suppliers || []).length) checks.push({ level: 'warn', text: `"${f.supplierName}" is not one of your suppliers – choose the supplier yourself.` });
  const vr = ctx.vatRate || 0.125;
  if (f.total && f.vat !== undefined && f.vat > 0) {
    const exp = r2((f.total * vr) / (1 + vr));
    if (Math.abs(exp - f.vat) > 0.1) checks.push({ level: 'warn', text: `VAT ${f.vat.toFixed(2)} is not ${vr * 100}% of the total (expected about ${exp.toFixed(2)}). Check – part of the invoice may be zero-rated.` });
  }
  if (kind === 'fuel') {
    const fuel = ai.lines.find((l) => /\b(l|lt|ltr|litres?|liters?)\b/i.test(l.unit || '') || /petrol|diesel|unleaded|fuel|premium/i.test(l.description));
    if (fuel && fuel.qty > 0 && fuel.qty < 500) f.litres = fuel.qty;
    if (fuel && fuel.unit_price > 0.5 && fuel.unit_price < 10) f.pricePerLitre = fuel.unit_price;
    if (f.litres && !f.pricePerLitre && f.total) f.pricePerLitre = r2(f.total / f.litres);
  }
  return { fields: f, from: {}, checks, found: Object.keys(f).length };
}

// 1.0.0 build 54: an EFL / WAF bill (photo, screenshot or PDF) read by the AI → the boxes of the bill check:
// { accountNo, total, due, billNo, supplierName } (the same fields as services/paperRead.js READERS.efl_bill).
export function aiBillFields(ai) {
  const f = {};
  const acct = txt(ai && ai.account_no);
  if (acct) f.accountNo = acct.replace(/\D/g, '') || acct;
  if (ai && ai.total_incl !== null && ai.total_incl !== undefined && ai.total_incl >= 0) f.total = r2(ai.total_incl);
  if (ai && ai.due_date) f.due = ai.due_date;
  if (ai && ai.invoice_no) f.billNo = ai.invoice_no;
  if (ai && ai.supplier) f.supplierName = ai.supplier;
  const notes = (ai && Array.isArray(ai.notes) ? ai.notes : []).filter(Boolean);
  // an overdue / arrears amount the AI put in its notes
  for (const n of notes) {
    const m = /(?:overdue|arrears)[^0-9\n]{0,30}\$?\s*([\d,]+(?:\.\d{1,2})?)/i.exec(n);
    if (m && f.overdue === undefined) { const v = num(m[1]); if (v !== null && v >= 0) f.overdue = r2(v); }
  }
  const checks = notes.map((n) => ({ level: 'warn', text: n }));
  if (!f.accountNo) checks.push({ level: 'warn', text: 'The account number was not found on the bill – check it is the right account.' });
  if (f.total === undefined) checks.push({ level: 'warn', text: 'The amount due was not found – type it from the bill.' });
  return { fields: f, from: {}, checks, found: Object.keys(f).filter((k) => ['accountNo', 'total', 'due'].includes(k)).length };
}
