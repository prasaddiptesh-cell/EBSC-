// 1.0.0 How a photo / PDF of an invoice is read. Kept free of device code (the camera, ML Kit and the cloud are passed in
// as deps by src/platform/invoiceReader.js) so the whole path can be tested in Node.
//   1. Online: the AI in the owner's cloud reads it (Google Gemini via cloud/Code.gs invoice_ai) – photos and PDFs.
//   2. Offline, no AI key in the cloud, or the AI failed: read on this phone (ML Kit, rows rebuilt), with every page
//      tried and the pages that could not be read reported. PDFs need the AI.
//   3. The phone's reading is weak (no total, few figures): Google's text reading in the cloud is tried as well and the
//      better of the two is kept.
// deps: { cloudUrl(): string, cloudCall(body, ms), recognizeText(uri, { rows }), fileBase64(uri), fileExists(uri) }
import { cleanAi, aiToText } from './invoiceAi.js';
import { parseInvoiceText, ebReadStrength } from '../modules/payables/parser.js';

export const MAX_PAGES = 6;
const MAX_BASE64 = 18 * 1024 * 1024; // Gemini takes at most ~20 MB of pages in one request
export const isPdf = (uri) => /\.pdf(\?|#|$)/i.test(String(uri || ''));
export const ENGINE_LABEL = {
  ai: 'Read by AI',
  device: 'Read on this phone – check carefully',
  cloud: 'Read by Google (text only) – check carefully',
  test: 'Read on this phone – check carefully',
};
export const engineLabel = (e) => ENGINE_LABEL[e] || 'Read – check carefully';
const OFFLINE_RE = /network|fetch|abort|timed?\s*out|timeout|internet|offline|failed to connect/i;
const errText = (e) => (e && e.message ? e.message : String(e || ''));

// How strong a text reading is (0–6). A weak one is worth asking the cloud about.
export function textStrength(text) {
  try { return ebReadStrength(parseInvoiceText(text || '', [], 0.125)); } catch (e) { return 0; }
}

async function filesFor(list, deps, { images = true, pdfs = true } = {}) {
  const files = []; const missing = [];
  for (let i = 0; i < list.length; i += 1) {
    const u = list[i];
    const pdf = isPdf(u);
    if ((pdf && !pdfs) || (!pdf && !images)) continue;
    let ok = false;
    try { ok = await deps.fileExists(u); } catch (e) { ok = false; }
    if (!ok) { missing.push(`Page ${i + 1}: the file was not found on this phone.`); continue; }
    files.push({ mimeType: pdf ? 'application/pdf' : 'image/jpeg', data: await deps.fileBase64(u), name: `page-${i + 1}.${pdf ? 'pdf' : 'jpg'}` });
  }
  return { files, missing };
}

// The AI in the cloud. → { ok: true, ai, raw } | { ok: false, code: NOT_LINKED | NO_AI_KEY | OFFLINE | TOO_BIG | NO_FILE | AI_ERROR, message }
export async function aiRead(list, hints, deps) {
  if (!deps.cloudUrl || !deps.cloudUrl()) return { ok: false, code: 'NOT_LINKED', message: 'This phone is not linked to the Easy Buys cloud, so the AI cannot read it.' };
  const { files, missing } = await filesFor(list, deps);
  if (!files.length) return { ok: false, code: 'NO_FILE', message: missing[0] || 'The photo file was not found on this phone.' };
  const size = files.reduce((s, f) => s + String(f.data || '').length, 0);
  if (size > MAX_BASE64) return { ok: false, code: 'TOO_BIG', message: 'The pages are too big for the AI in one go (more than about 13 MB). Send fewer pages, or a smaller PDF.' };
  let r;
  try {
    r = await deps.cloudCall({ kind: 'invoice_ai', files, hints }, 170000);
  } catch (e) {
    const m = errText(e);
    if (/NO_AI_KEY/.test(m)) return { ok: false, code: 'NO_AI_KEY', message: 'The AI reader is not switched on in the cloud yet (Script properties › GEMINI_KEY).' };
    if (OFFLINE_RE.test(m)) return { ok: false, code: 'OFFLINE', message: 'No internet right now.' };
    return { ok: false, code: 'AI_ERROR', message: m.replace(/^AI_ERROR:\s*/, '') || 'The AI could not read it.' };
  }
  if (!r || r.code === 'NO_AI_KEY' || /NO_AI_KEY/.test(String((r && r.error) || ''))) return { ok: false, code: 'NO_AI_KEY', message: 'The AI reader is not switched on in the cloud yet (Script properties › GEMINI_KEY).' };
  if (r.ok === false || !r.invoice) return { ok: false, code: 'AI_ERROR', message: String(r.error || r.message || 'The AI could not read it.').replace(/^AI_ERROR:\s*/, '') };
  const ai = cleanAi(r.invoice, { today: deps.today ? deps.today() : undefined });
  if (!ai.total_incl && !ai.invoice_no && !ai.lines.length) return { ok: false, code: 'AI_ERROR', message: 'The AI found nothing on the pages – is it an invoice?' };
  if (missing.length) ai.notes.push(...missing);
  return { ok: true, ai, raw: r.invoice, model: r.model || null };
}

// Text only, page by page on this phone, then Google's text reading as the backup (bank statements, Z reports…).
// weakCheck: an invoice – Google is asked as well when the phone's reading is weak (not only when there is no text).
// → { ok, text, engine: 'device' | 'cloud' | 'test', pageErrors, message }
export async function readPhotosText(uris = [], { cloud = true, rows = false, deps, offline = false, weakCheck = false } = {}) {
  const list = (uris || []).filter(Boolean).slice(0, MAX_PAGES); // an invoice of up to 6 pages, read together in page order
  if (!list.length) return { ok: false, message: 'Take a photo of the invoice first.', pageErrors: [] };
  // UI tests (web) give the photo text directly.
  const fake = typeof globalThis !== 'undefined' && globalThis.__ebPaperText;
  if (fake) return { ok: true, text: typeof fake === 'function' ? fake() : String(fake), engine: 'test', pageErrors: [] };
  const parts = []; const pageErrors = []; const images = [];
  for (let i = 0; i < list.length; i += 1) {
    const u = list[i];
    if (isPdf(u)) { pageErrors.push(`Page ${i + 1}: a PDF can only be read by the AI in the cloud (online).`); continue; }
    images.push(u);
    let r;
    try { r = await deps.recognizeText(u, { rows }); } catch (e) { r = { ok: false, reason: errText(e) }; }
    if (r && r.ok) parts.push(r.text); else pageErrors.push(`Page ${i + 1}: ${(r && r.reason) || 'could not be read'}`);
  }
  const text = parts.join('\n');
  const strong = text && weakCheck ? textStrength(text) : 0;
  const result = (t, engine) => ({ ok: true, text: t, engine, pageErrors, message: pageErrors.length ? `Some pages could not be read: ${pageErrors.join(' ')}` : '' });
  // The phone read it well enough, or there is no cloud to ask.
  const canCloud = cloud && !offline && images.length && deps.cloudUrl && deps.cloudUrl();
  if (text && (!weakCheck || strong >= 4 || !canCloud)) return result(text, 'device');
  if (!canCloud) {
    if (!cloud) return { ok: false, pageErrors, message: pageErrors.length ? pageErrors.join(' ') : 'The photo could not be read on this phone.' };
    if (!images.length) return { ok: false, pageErrors, message: pageErrors.join(' ') || 'Nothing to read.' };
    return { ok: false, pageErrors, message: `The photo could not be read on this phone${deps.cloudUrl && deps.cloudUrl() ? '' : ', and it is not linked to the Easy Buys cloud'}. Please type the details.${pageErrors.length ? ` (${pageErrors.join(' ')})` : ''}` };
  }
  // A weak reading (or none): Google's text reading as well; the better one is kept.
  try {
    const { files } = await filesFor(images, deps, { pdfs: false });
    if (!files.length) return text ? result(text, 'device') : { ok: false, pageErrors, message: 'The photo file was not found on this phone.' };
    const r = await deps.cloudCall({ kind: 'ocr', files }, 180000);
    if (r && Array.isArray(r.pageErrors) && r.pageErrors.length) pageErrors.push(...r.pageErrors.map((p) => `Google: ${p}`));
    if (r && r.text && (!text || textStrength(r.text) > strong)) return result(r.text, 'cloud');
    if (text) return result(text, 'device');
    if (r && r.off) return { ok: false, pageErrors, message: "Google's photo reading is not switched on in the cloud yet. Please type the details." };
    return { ok: false, pageErrors, message: 'Google could not read any text on the photo. Take it again in good light, flat, the whole invoice in the picture.' };
  } catch (e) {
    if (text) return result(text, 'device');
    const m = errText(e);
    return { ok: false, pageErrors, message: OFFLINE_RE.test(m) ? 'No internet right now and the photo could not be read on this phone. Please type the details.' : m };
  }
}

// An invoice (or a paid receipt / fuel receipt): the AI first, then this phone.
// → { ok, engine: 'ai' | 'device' | 'cloud' | 'test', ai, text, pageErrors, aiCode, aiPending, label, message }
//   aiPending: read on the phone because there was no internet – "AI re-read when online" (Read again then).
export async function readInvoiceFiles(uris = [], { hints = {}, rows = true, deps } = {}) {
  const list = (uris || []).filter(Boolean).slice(0, MAX_PAGES);
  if (!list.length) return { ok: false, message: 'Take a photo of the invoice first.', pageErrors: [] };
  const fake = typeof globalThis !== 'undefined' && globalThis.__ebPaperText;
  if (fake) return { ok: true, text: typeof fake === 'function' ? fake() : String(fake), engine: 'test', label: engineLabel('test'), pageErrors: [], ai: null };
  const a = await aiRead(list, hints, deps);
  if (a.ok) return { ok: true, engine: 'ai', ai: a.ai, text: aiToText(a.ai), pageErrors: [], label: engineLabel('ai'), message: engineLabel('ai') };
  const offline = a.code === 'OFFLINE';
  const t = await readPhotosText(list, { rows, deps, offline, cloud: true, weakCheck: true });
  const aiPending = offline || a.code === 'AI_ERROR';
  const why = { NO_AI_KEY: 'The AI reader is not switched on in the cloud yet – read on this phone.', OFFLINE: 'No internet – read on this phone. AI re-read when online: tap "Read again" then.',
    AI_ERROR: `The AI could not read it (${a.message}) – read on this phone.`, TOO_BIG: a.message }[a.code] || '';
  if (!t.ok) {
    const pdfOnly = list.every(isPdf);
    return { ok: false, engine: null, ai: null, pageErrors: t.pageErrors || [], aiCode: a.code, aiPending,
      message: pdfOnly ? `A PDF is read by the AI in the cloud only. ${a.message}` : `${t.message}${why ? ` ${why}` : ''}` };
  }
  return { ...t, ai: null, aiCode: a.code, aiPending, label: engineLabel(t.engine), why,
    message: [engineLabel(t.engine), why, t.message].filter(Boolean).join(' · ') };
}
