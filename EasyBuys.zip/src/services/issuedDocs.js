// Every company document the app prints, saves or sends carries a Code 128 barcode: "EBD-<reference>-<check>".
// The reference stays the same for one document (e.g. one purchase order); the check is the first 8 characters of a
// SHA-256 fingerprint of what the copy says. Each issued copy is recorded here (shared with every device), so
// "Scan a document" can say "✓ genuine" (this exact copy was made by the app) or "✗ not found / changed".
import { db } from '../db/connection.js';
import { stamp, deviceId } from './core.js';
import { sha256Text } from './sha256.js';
import { docTypeOf, docType } from './docDesign.js';

export const ISSUED_SQL = `
CREATE TABLE IF NOT EXISTS issued_docs (
  uid TEXT PRIMARY KEY,
  ref TEXT NOT NULL,
  hash TEXT NOT NULL,
  doc_type TEXT,
  kind TEXT,
  title TEXT,
  file_name TEXT,
  summary TEXT,
  nav TEXT,
  how TEXT,
  copies INTEGER NOT NULL DEFAULT 1,
  issued_at TEXT,
  issued_by TEXT,
  issued_device TEXT,
  last_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_issued_ref ON issued_docs(ref);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const ISSUED_SYNC = {
  issued_docs: SYNC('uid', 'Documents', ['uid', 'ref', 'hash', 'doc_type', 'kind', 'title', 'file_name', 'summary', 'nav', 'how', 'copies', 'issued_at', 'issued_by', 'issued_device', 'last_at']),
};

// Lines that change every time a copy is made ("Generated 10:42") are not part of the fingerprint.
const VOLATILE = /^(generated|made|printed|printed at|generated at)$/i;
export function canonicalContent(rep) {
  const clean = (v) => (v === null || v === undefined ? '' : String(v));
  const body = {
    t: clean(rep.title),
    i: (rep.info || []).filter(([k]) => !VOLATILE.test(String(k).trim())).map(([k, v]) => [clean(k), clean(v)]),
    s: (rep.summary || []).map((x) => [clean(x.label), clean(x.value)]),
    x: (rep.sections || []).map((sec) => [clean(sec.title), (sec.columns || []).map((c) => c.key), (sec.rows || []).map((r) => (sec.columns || []).map((c) => clean(r[c.key])))]),
  };
  return JSON.stringify(body);
}
export function contentHash(rep) { return sha256Text(canonicalContent(rep)); }

// A short, stable reference for one document: the type's letters + 6 characters from what the document is
// (its kind and file name, e.g. the PO number), unless the document gives its own `ref`.
export function docRef(rep) {
  if (rep && rep.ref) return String(rep.ref).replace(/[^A-Za-z0-9-]+/g, '').toUpperCase().slice(0, 24);
  const t = docType(docTypeOf(rep));
  const h = sha256Text(`${rep && rep.kind}|${(rep && (rep.fileName || rep.title)) || ''}`);
  return `${t.prefix}-${parseInt(h.slice(0, 10), 16).toString(36).toUpperCase().padStart(7, '0').slice(-7)}`;
}
export function docIdentity(rep) {
  const hash = contentHash(rep);
  const ref = docRef(rep);
  return { ref, hash, check: hash.slice(0, 8).toUpperCase(), code: `EBD-${ref}-${hash.slice(0, 8).toUpperCase()}`, docType: docTypeOf(rep) };
}
// "EBD-PO-00K3F9Q-1A2B3C4D" → { ref, check }
export function parseDocCode(code) {
  const m = /^EBD[-:]([A-Z0-9][A-Z0-9-]{1,30})[-:]([0-9A-F]{8})$/i.exec(String(code || '').trim());
  return m ? { ref: m[1].toUpperCase(), check: m[2].toUpperCase() } : null;
}

// Records a copy (idempotent: the same copy made again only counts up). `how`: print, pdf, send, save, email.
export function recordIssued(rep, identity = docIdentity(rep), { user = null, how = 'pdf' } = {}) {
  const uid = `${identity.ref}.${identity.hash.slice(0, 16)}`;
  const now = stamp();
  const have = db().get('SELECT uid, copies FROM issued_docs WHERE uid = ?', [uid]);
  if (have) {
    db().run("UPDATE issued_docs SET copies = copies + 1, last_at = ?, how = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [now, how, now, deviceId(), uid]);
    return uid;
  }
  const summary = (rep.summary || []).slice(0, 4).map((s) => `${s.label}: ${s.value}`).join(' · ')
    || (rep.info || []).filter(([k]) => !VOLATILE.test(String(k))).slice(0, 3).map(([k, v]) => `${k}: ${v}`).join(' · ');
  db().run(`INSERT INTO issued_docs (uid, ref, hash, doc_type, kind, title, file_name, summary, nav, how, copies, issued_at, issued_by, issued_device, last_at, updated_at, updated_device)
    VALUES (?,?,?,?,?,?,?,?,?,?,1,?,?,?,?,?,?)`, [uid, identity.ref, identity.hash, identity.docType, String(rep.kind || ''), String(rep.title || ''), String(rep.fileName || ''), summary.slice(0, 400),
    rep.nav ? JSON.stringify(rep.nav) : null, how, now, user ? user.name : '', deviceId(), now, now, deviceId()]);
  return uid;
}
export function issuedFor(ref) {
  return db().all('SELECT * FROM issued_docs WHERE ref = ? ORDER BY issued_at DESC', [String(ref || '').toUpperCase()]);
}
export function listIssued({ q = '', limit = 100 } = {}) {
  const L = `%${String(q).trim()}%`;
  return db().all('SELECT * FROM issued_docs WHERE (? = \'\' OR ref LIKE ? OR title LIKE ?) ORDER BY last_at DESC LIMIT ?', [String(q).trim(), L, L, limit]);
}

// The check behind "Scan a document". Returns { ok, verdict, title, message, doc, newer }.
export function verifyDocCode(code) {
  const p = parseDocCode(code);
  if (!p) return { ok: false, verdict: 'not_ours', title: '✗ Not an Easy Buys document code', message: 'This barcode was not made by the Easy Buys app.' };
  const copies = issuedFor(p.ref);
  if (!copies.length) return { ok: false, verdict: 'not_found', ref: p.ref, title: '✗ Not found', message: `No document ${p.ref} was ever made by the app (or it has not synced to this device yet). Treat this paper as not genuine until checked.` };
  const match = copies.find((c) => c.hash.slice(0, 8).toUpperCase() === p.check);
  if (!match) {
    return { ok: false, verdict: 'changed', ref: p.ref, doc: copies[0], title: '✗ Changed – does not match',
      message: `Document ${p.ref} exists (${copies[0].title}), but this copy does not match any copy the app made. It may have been changed. Compare it with the app's copy.` };
  }
  const newer = copies[0].uid !== match.uid ? copies[0] : null;
  let nav = null;
  try { nav = match.nav ? JSON.parse(match.nav) : null; } catch (e) { nav = null; }
  return { ok: true, verdict: 'genuine', ref: p.ref, doc: match, nav, newer, title: '✓ Genuine',
    message: `${match.title} – made by the app on ${String(match.issued_at).slice(0, 16)}${match.issued_by ? ` by ${match.issued_by}` : ''}.${newer ? ` Note: a newer version was made on ${String(newer.issued_at).slice(0, 16)}.` : ''}` };
}
