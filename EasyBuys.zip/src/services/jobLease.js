// 1.0.0 build 10 (go-live, owner 2 Nov: "It needs all the devices to allow sync instead of the main tablet").
// The jobs that only one device should do at a time used to wait for "the main tablet": bringing in the till PCs'
// products, suppliers, staff credit and FCCC marks and answering the till's test (link), the automatic Viber posts
// (viber), the FCCC / LPG / fuel / water web checks (web), the monthly accountant pack (pack) and the nightly backup
// (backup). Now any linked device does them: on each sync it asks the cloud for a lease on every job (cloud script 18,
// job_lease). The cloud gives each job to one device at a time; the holder keeps it by asking again on each sync, and
// when it stops syncing the job is free after its time and the next device that syncs takes it.
// - The device chosen in Admin › Main tablet is a preference only: the cloud gives it the jobs first and for longer.
//   Nothing depends on it being on.
// - The backup and the accountant pack only go to an admin device (it has the whole data).
// - No cloud answer (offline, or an older cloud script): only the device explicitly set as main does the jobs; a device
//   not linked to any cloud does them as before (the main tablet setting, or the device holding the cloud key).
// - mark: a note kept with the job in the cloud (the day of the last backup, the month of the last pack), so a device
//   that takes the job over does not do it again the same day / month.
import { getSetting, setSetting, getShared, deviceId } from './core.js';

export const JOBS = ['link', 'viber', 'web', 'pack', 'backup'];
// review (3 Nov): the backup and the accountant pack need the whole data – an admin device only (the cloud says so in
// every pull: device_is_admin). Other devices do not even ask for them (they used to, under the cloud's write lock).
export const ADMIN_JOBS = ['backup', 'pack'];
const notAdmin = () => getSetting('device_is_admin', '') === '0';
export function jobsToAsk(jobs = JOBS) { return notAdmin() ? jobs.filter((j) => !ADMIN_JOBS.includes(j)) : jobs; }
export const LEASE_TTL_SEC = { link: 600, viber: 600, web: 600, pack: 600, backup: 1800 };
const KEY = (job) => `job_lease_${job}`;

function cached(job) { try { return JSON.parse(getSetting(KEY(job), '') || 'null'); } catch (e) { return null; } }
function keep(job, v) { try { setSetting(KEY(job), JSON.stringify(v)); } catch (e) { /* a note only */ } }

export function explicitMain() { const m = getShared('main_tablet_device', '') || ''; return !!m && m === deviceId(); }
// before leases: the main tablet, or (none chosen) the device holding the cloud key
export function legacyMain() { const m = getShared('main_tablet_device', '') || ''; return m ? m === deviceId() : !!getSetting('cloud_key', ''); }

// May this device do the job now? (synchronous: what the last lease answer said)
export function mayDoJob(job, now = Date.now()) {
  const c = cached(job);
  const linked = !!getSetting('cloud_url', '');
  if (!linked) return legacyMain();
  if (ADMIN_JOBS.includes(job) && notAdmin()) return false; // the main device alone is not enough
  if (c && c.state === 'old') return legacyMain(); // the cloud does not know leases yet (script < 18)
  if (c && c.state === 'granted' && Number(c.until) > now) return true;
  if (c && c.state === 'denied' && Number(c.until) > now) return false; // another device has it
  return explicitMain(); // no fresh answer from the cloud (offline): the explicitly chosen main device only
}
// Who has the job (for the screens): { mine, holderName, until } or null
export function leaseInfo(job) { const c = cached(job); return c ? { mine: c.state === 'granted', holderName: c.holderName || '', until: c.until || 0, state: c.state } : null; }
export function jobMark(job) { const c = cached(job); return c && c.mark ? String(c.mark) : ''; }

// Ask the cloud for the jobs (one request). post(body, timeoutMs) – the app's cloud call. marks: { job: mark } to keep.
// Never throws: no answer leaves the last answer in place (a lease still running stays this device's).
// every: a fresh answer for every job (younger than this) is not asked again – a phone syncing every minute asks the
// cloud about every third minute (well inside the lease time, so a holder never loses its job by waiting).
export const ASK_EVERY_MS = 170000;
export async function refreshLeases({ post, jobs: jobs0 = JOBS, marks = {}, release = [], now = () => Date.now(), every = 0 } = {}) {
  const jobs = jobsToAsk(jobs0);
  if (!jobs.length) return { none: true };
  const pend = pendingMarks();
  if (every > 0 && !Object.keys(marks).length && !release.length && !Object.keys(pend).length
    && jobs.every((job) => { const c = cached(job); return c && c.state !== 'old' && now() - Number(c.at || 0) < every && (c.state !== 'granted' || Number(c.until) - now() > every) && (c.state !== 'denied' || Number(c.until) > now()); })) return { cached: true };
  const list = jobs.map((job) => ({ job, ttlSec: LEASE_TTL_SEC[job] || 600, ...(marks[job] || pend[job] ? { mark: String(marks[job] || pend[job]) } : {}), ...(release.includes(job) ? { release: true } : {}) }));
  let r;
  try { r = await post({ kind: 'job_lease', jobs: list }); } catch (e) {
    if (/Unknown request/i.test(String((e && e.message) || e))) { for (const job of jobs) keep(job, { state: 'old', at: now() }); return { old: true }; }
    return { error: String((e && e.message) || e) };
  }
  const got = (r && r.leases) || {};
  // the cloud's times turned into this device's clock (a phone whose clock is a few minutes behind must not think it
  // still holds a job the cloud has already given to another device)
  const shift = Number(r && r.serverTime) > 0 ? now() - Number(r.serverTime) : 0;
  const left = { ...pendingMarks() };
  for (const job of jobs) {
    const x = got[job];
    if (!x) continue;
    const until0 = Number(x.untilMs) || Date.parse(String(x.until || '')) || 0;
    const until = until0 ? until0 + (x.granted ? Math.min(0, shift) : Math.max(0, shift)) : 0;
    keep(job, { state: x.granted ? 'granted' : 'denied', until: x.granted ? until : (until || now() + 60000), holder: x.holder || '', holderName: x.holderName || '', mark: x.mark || '', at: now(), handover: !!x.handover });
    // review: a mark is let go only once the cloud has it (kept with the job, or a later one there) – a "not yours"
    // answer used to drop it, and the next device made the same backup / accountant pack again
    if (left[job] !== undefined && (x.granted || x.handover || (x.mark && String(x.mark) >= String(left[job])))) delete left[job];
  }
  if (Object.keys(pend).length) setSetting('job_marks_pending', Object.keys(left).length ? JSON.stringify(left) : '');
  return { leases: got };
}
// A mark sent with the next lease request (and at once when it can be).
function pendingMarks() { try { return JSON.parse(getSetting('job_marks_pending', '') || '{}') || {}; } catch (e) { return {}; } }
export async function setJobMark(job, mark, { post } = {}) {
  const c = cached(job);
  if (c) keep(job, { ...c, mark: String(mark) });
  const pend = { ...pendingMarks(), [job]: String(mark) };
  setSetting('job_marks_pending', JSON.stringify(pend));
  if (post) { try { await refreshLeases({ post, jobs: [job], marks: { [job]: mark } }); } catch (e) { /* goes with the next sync */ } }
}
// Renew one job while working on it (a long backup) – at most every third of its time.
// maxAgeMs: ask the cloud when the last answer is older than this (the link job right before the products / suppliers
// round: a device that is not the holder any more stops there).
export async function renewLease(job, { post, now = Date.now(), maxAgeMs = null } = {}) {
  const c = cached(job);
  if (!post || !c || c.state !== 'granted') return false;
  if (now - Number(c.at || 0) < (maxAgeMs !== null ? maxAgeMs : ((LEASE_TTL_SEC[job] || 600) * 1000) / 3)) return mayDoJob(job, now);
  await refreshLeases({ post, jobs: [job] });
  return mayDoJob(job);
}
