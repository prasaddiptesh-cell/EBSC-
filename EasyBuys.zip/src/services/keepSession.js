// 1.0.0 build 26: the operations screen on a wall monitor must not sign itself out. It holds the session only for a
// view-only map account (the map, nothing that changes money or settings); anyone else is signed out as usual.
import { can } from './access.js';

let holder = null;
export const mayHold = (user) => !!user && can(user, 'trade_map') && !can(user, 'trade_dispatch') && !can(user, 'settings') && !can(user, 'trade_manage');
export function holdSession(user) { holder = mayHold(user) ? user.uid : null; return holder !== null; }
export function releaseSession() { holder = null; }
export const sessionHeld = (user) => !!user && holder === user.uid;
