// Period lock: once a month is closed (e.g. the VAT return is filed), nothing dated on or before the lock date
// can be entered, changed or voided – only the owner can move the lock back.
import { getShared, AppError } from './core.js';

export function lockDate() {
  const l = getShared('gl_lock', null);
  return l && l.date ? l.date : null;
}
export function assertOpen(date, what = 'This') {
  const l = lockDate();
  if (l && date && String(date).slice(0, 10) <= l) {
    throw new AppError(`${what} is dated ${String(date).slice(0, 10)}, but the books are closed up to ${l} (VAT return filed). Use a date after ${l}, or ask the owner to reopen the month.`);
  }
}
