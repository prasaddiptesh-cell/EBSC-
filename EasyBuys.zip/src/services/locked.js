// 1.0.0 build 1: "Everything crucial is locked away" (owner). One guard for every change that would hurt the app or
// the business if the wrong person made it:
//  1. only the owner (an admin only for the areas the owner allowed – itself an owner-only setting);
//  2. the owner's PIN typed again at that moment (an unlock lasts 2 minutes, for that one area);
//  3. a reason;
//  4. written to the change history with what it was before and after;
//  5. the owner is told on every device (and in the owner's Viber channel when there is one);
//  6. the cloud refuses the change when it does not come with an owner / admin login it checked (cloud/Code.gs).
// The guard sits under every screen (db/connection.js setLockGuard): a locked write by a logged-in person without an
// unlock stops with a LOCKED error, which the screens show as "Owner PIN needed" (ui/components.js). Work the app does
// by itself (sync, nightly jobs, no one logged in) is never blocked.
import { db, withSystem, setLockGuard } from '../db/connection.js';
import { AppError, getShared, setShared, audit, stamp, uuid, deviceId, clock } from './core.js';

// The areas, in the owner's words.
export const LOCKED_AREAS = {
  roles: 'Roles, permissions and PINs',
  pay: 'Staff pay rates, FNPF and bank details',
  supplierbank: 'Supplier bank details',
  tax: 'Tax, VAT, FNPF and PAYE rates and tables',
  accounts: 'Chart of accounts and opening balances',
  months: 'Closed months (closing and reopening)',
  golive: 'Go-live date',
  shops: 'Shops, tills and cost areas',
  devices: 'Cloud link and devices',
  updates: 'Where app updates come from',
  link: 'Aronium Link settings',
  viber: 'Viber channels',
  ai: 'AI reading settings',
  backup: 'Backup settings',
  modules: 'Parts of the app on / off',
  bin: 'Deleting, restoring and purging records',
  clean: 'Start clean',
  cigarettes: 'Cigarette rules',
  payroll: 'Payroll rules and pay cycle',
  credit: 'Credit limits',
  emails: 'Email addresses for reports',
};
// Locked shared settings → area. LOCKED_SHARED must stay the same as the list in cloud/Code.gs (tests check it).
const SHARED_AREA = {
  role_perms: 'roles', locked_admin_ok: 'roles', modules_on: 'modules', update_repo: 'updates', go_live: 'golive', gl_lock: 'months', gl_map: 'accounts',
  acct_settings: 'accounts', ap_rules: 'tax', pay_rules: 'payroll', pay_cycle: 'payroll', pay_signoff_rules: 'payroll', tax_calendar_rules: 'tax',
  employer_details: 'tax', till_rules: 'shops', cig_tally: 'cigarettes', owed_rules: 'credit', viber_channels: 'viber', doc_settings: 'backup',
  main_tablet_device: 'devices', fresh_start: 'clean', clean_start: 'clean', link_settings: 'link', ai_settings: 'ai', backup_settings: 'backup',
  email_prefs: 'emails', doc_visibility: 'roles', watchdog: 'modules', email_logins: 'roles',
};
export const LOCKED_SHARED = ['role_perms', 'locked_admin_ok', 'modules_on', 'update_repo', 'go_live', 'gl_lock', 'gl_map', 'acct_settings', 'ap_rules',
  'pay_rules', 'pay_cycle', 'pay_signoff_rules', 'tax_calendar_rules', 'employer_details', 'till_rules', 'cig_tally', 'owed_rules',
  'viber_channels', 'doc_settings', 'main_tablet_device', 'fresh_start', 'clean_start', 'link_settings', 'ai_settings', 'backup_settings',
  'email_prefs', 'doc_visibility', 'watchdog', 'email_logins'];
// This device's own settings that are locked.
const SETTING_AREA = { cloud_url: 'devices', cloud_key: 'devices', cloud_token: 'devices', update_repo: 'updates', ui_sample_db: 'devices' };
// Locked tables: '*' = any change; a list = only these columns; key = how a row is found.
const TABLES = {
  users: { key: 'uid', cols: ['role', 'pin', 'pin_hash', 'active', 'perms', 'permissions', 'works_shifts', 'own_till', 'email'], area: 'roles', newTop: true },
  pay_profiles: { key: 'user_uid', cols: ['pay_type', 'rate', 'weekly_salary', 'fnpf_member', 'fnpf_extra_pct', 'tax_status', 'bank_name', 'bank_account', 'pay_method'], area: 'pay' },
  ap_suppliers: { key: 'uid', cols: ['bank_name', 'bank_account'], area: 'supplierbank' },
  gl_accounts: { key: 'code', cols: '*', area: 'accounts' },
  shops: { key: 'code', cols: '*', area: 'shops' },
  tills: { key: 'uid', cols: '*', area: 'shops' },
  bin_records: { key: 'uid', cols: '*', area: 'bin' },
  bin_parts: { key: 'uid', cols: '*', area: 'bin' },
  gl_journals: { key: 'uid', cols: ['lines', 'jdate', 'status', 'kind'], area: 'accounts', only: (m, before) => String((m.kind !== undefined ? m.kind : before && before.kind) || '') === 'opening' },
};
const TOP = ['owner', 'admin', 'manager', 'payroll'];
const UNLOCK_MS = 2 * 60000;

// Settings where only some fields are locked (go_live also holds the go-live checklist ticks, which anyone may tick).
// Same list in cloud/Code.gs LOCKED_FIELDS.
export const LOCKED_FIELDS = { go_live: ['liveFrom', 'freshFrom'] };
export function onlyFieldsSame(key, beforeVal, afterVal) {
  const f = LOCKED_FIELDS[key];
  if (!f) return false;
  const P = (v) => { try { const x = typeof v === 'string' ? JSON.parse(v) : v; return x && typeof x === 'object' ? x : {}; } catch (e) { return {}; } };
  const a = P(beforeVal); const b = P(afterVal);
  return f.every((k) => same(a[k], b[k]));
}
export function areaOfShared(key) { return SHARED_AREA[key] || null; }
export function isLockedShared(key) { return LOCKED_SHARED.includes(String(key)); }
export const lockIcon = (key) => (isLockedShared(key) || SETTING_AREA[key] ? '🔒' : '');

// Which areas an admin may do (the owner chooses; owner-only setting itself).
export function adminAllowed() { const a = getShared('locked_admin_ok', []) || []; return Array.isArray(a) ? a : []; }
const isOwner = (u) => !!u && (u.role === 'owner' || u.realRole === 'owner');
const isAdmin = (u) => !!u && (u.role === 'admin' || u.realRole === 'admin');
export function mayDo(user, area) { return isOwner(user) || (isAdmin(user) && adminAllowed().includes(area)); }

// ---------------------------------------------------------------- unlocking (PIN again + reason, 2 minutes, one area)
let unlocks = []; // [{ area, uid, name, reason, until, told }]
const nowMs = () => { try { return clock.now().getTime(); } catch (e) { return Date.now(); } };
export function unlock(user, area, pin, reason) {
  if (!LOCKED_AREAS[area]) throw new AppError('Unknown locked area.');
  if (!mayDo(user, area)) throw new AppError(isAdmin(user) ? `Only the owner can change this (${LOCKED_AREAS[area]}). The owner can allow admins in Settings › Locked settings.` : `Only the owner can change this (${LOCKED_AREAS[area]}).`);
  const why = String(reason || '').trim();
  if (why.length < 3) throw new AppError('Write the reason for this change.');
  const P = require('./pins.js');
  const me = db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [user.uid]);
  if (!me || !P.pinMatches(pin, me)) {
    withSystem(() => audit({ user, action: `Locked change refused: wrong PIN (${LOCKED_AREAS[area]})`, table: 'locked', recordUid: area, reason: why }));
    throw new AppError('Wrong PIN – nothing was unlocked.');
  }
  unlocks = unlocks.filter((x) => x.until > nowMs() && x.area !== area);
  const u = { area, uid: user.uid, name: user.name, reason: why, until: nowMs() + UNLOCK_MS, told: false };
  unlocks.push(u);
  withSystem(() => audit({ user, action: `Unlocked for 2 minutes: ${LOCKED_AREAS[area]}`, table: 'locked', recordUid: area, reason: why }));
  return { area, until: u.until };
}
export function unlockedFor(area) { return unlocks.find((x) => x.area === area && x.until > nowMs()) || null; }
export function lockAll() { unlocks = []; }

// ---------------------------------------------------------------- reading a write (INSERT / UPDATE / DELETE)
const splitTop = (s) => { const out = []; let depth = 0; let q = null; let cur = ''; for (const ch of s) { if (q) { cur += ch; if (ch === q) q = null; continue; } if (ch === "'" || ch === '"') { q = ch; cur += ch; continue; } if (ch === '(') depth += 1; if (ch === ')') depth -= 1; if (ch === ',' && depth === 0) { out.push(cur.trim()); cur = ''; continue; } cur += ch; } if (cur.trim()) out.push(cur.trim()); return out; };
const lit = (s) => { const t = String(s).trim(); if (/^'.*'$/.test(t)) return t.slice(1, -1).replace(/''/g, "'"); if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t); if (/^null$/i.test(t)) return null; return undefined; };
export function readWrite(sql, params) {
  const s = String(sql || '').replace(/\s+/g, ' ').trim();
  const p = params || [];
  let m = /^(INSERT|REPLACE)(?: OR (\w+))? INTO "?(\w+)"? \(([^)]*)\) VALUES \((.*?)\)(?: ON CONFLICT.*)?;?$/i.exec(s);
  if (m) {
    const cols = m[4].split(',').map((c) => c.trim().replace(/"/g, ''));
    const vals = splitTop(m[5]);
    let i = 0; const map = {};
    cols.forEach((c, j) => { const v = vals[j] || ''; if (v === '?') map[c] = p[i++]; else { const L = lit(v); map[c] = L === undefined ? { expr: v } : L; } });
    return { op: 'insert', ignore: /ignore/i.test(m[2] || ''), table: m[3].toLowerCase(), map };
  }
  m = /^UPDATE(?: OR \w+)? "?(\w+)"? SET (.*?) WHERE (.*)$/i.exec(s);
  if (m) {
    const sets = splitTop(m[2]);
    let i = 0; const map = {};
    sets.forEach((a) => { const k = /^"?(\w+)"?\s*=\s*(.*)$/.exec(a); if (!k) return; const v = k[2].trim(); if (v === '?') map[k[1]] = p[i++]; else { const n = (v.match(/\?/g) || []).length; i += n; const L = lit(v); map[k[1]] = L === undefined ? { expr: v } : L; } });
    const w = /^"?(\w+)"?\s*=\s*\?/.exec(m[3].trim());
    return { op: 'update', table: m[1].toLowerCase(), map, keyCol: w ? w[1] : null, keyVal: w ? p[i] : undefined, where: m[3] };
  }
  m = /^DELETE FROM "?(\w+)"?(?: WHERE (.*))?$/i.exec(s);
  if (m) { const w = m[2] ? /^"?(\w+)"?\s*=\s*\?/.exec(m[2].trim()) : null; return { op: 'delete', table: m[1].toLowerCase(), map: {}, keyCol: w ? w[1] : null, keyVal: w ? p[0] : undefined }; }
  return null;
}
const same = (a, b) => String(a === undefined || a === null ? '' : a) === String(b === undefined || b === null ? '' : b);
// Which locked area this write touches (null = not locked), with the row before when it can be found.
export function lockedAreaOf(w) {
  if (!w) return null;
  if (w.table === 'shared_settings') {
    const key = w.map.key !== undefined ? w.map.key : w.keyCol === 'key' ? w.keyVal : null;
    if (!isLockedShared(key)) return null;
    let before = null;
    try { before = db().get('SELECT value FROM shared_settings WHERE key = ?', [key]); } catch (e) { before = null; }
    if (w.op !== 'delete' && before && w.map.value !== undefined && same(before.value, w.map.value)) return null;
    if (w.op !== 'delete' && w.map.value !== undefined && onlyFieldsSame(key, before ? before.value : null, w.map.value)) return null;
    return { area: SHARED_AREA[key], what: `setting ${key}`, before: before ? before.value : null, after: w.map.value, key };
  }
  if (w.table === 'settings') {
    const key = w.map.key !== undefined ? w.map.key : w.keyCol === 'key' ? w.keyVal : null;
    if (!SETTING_AREA[key]) return null;
    let before = null;
    try { before = db().get('SELECT value FROM settings WHERE key = ?', [key]); } catch (e) { before = null; }
    if (before && same(before.value, w.map.value)) return null;
    return { area: SETTING_AREA[key], what: `this device's ${key}`, before: before ? '(set)' : null, after: w.map.value ? '(set)' : '(cleared)', key };
  }
  const spec = TABLES[w.table];
  if (!spec) return null;
  if (w.op === 'insert' && w.ignore) return null; // the app's own defaults ("add if missing")
  const keyCol = w.op === 'insert' ? spec.key : w.keyCol;
  const keyVal = w.op === 'insert' ? w.map[spec.key] : w.keyVal;
  let before = null;
  if (keyCol && keyVal !== undefined && keyVal !== null) { try { before = db().get(`SELECT * FROM "${w.table}" WHERE "${keyCol}" = ?`, [keyVal]); } catch (e) { before = null; } }
  if (spec.only && !spec.only(w.map, before)) return null;
  if (w.op === 'delete') return before || !keyCol ? { area: spec.area, what: `${w.table} removed`, before: strip(before), after: null, key: keyVal } : null;
  if (w.op === 'insert' && !before) {
    if (w.table === 'users') return TOP.includes(String(w.map.role)) ? { area: 'roles', what: `new ${w.map.role} login`, before: null, after: strip(w.map), key: keyVal } : null;
    if (spec.cols !== '*') { const set = spec.cols.filter((c) => w.map[c] !== undefined && w.map[c] !== null && w.map[c] !== '' && w.map[c] !== 0 && !(w.table === 'pay_profiles' && c === 'pay_type')); return set.length ? { area: spec.area, what: `${w.table} ${set.join(', ')}`, before: null, after: strip(w.map), key: keyVal } : null; }
    return { area: spec.area, what: `new ${w.table}`, before: null, after: strip(w.map), key: keyVal };
  }
  const cols = (spec.cols === '*' ? Object.keys(w.map).filter((c) => !['updated_at', 'updated_device', 'sync_status'].includes(c)) : spec.cols)
    .filter((c) => w.map[c] !== undefined && !(w.map[c] && typeof w.map[c] === 'object') && !same(w.map[c], before ? before[c] : null));
  if (w.table === 'users' && cols.length && cols.every((c) => c === 'pin' || c === 'pin_hash') && before && w.map.pin !== undefined && same(w.map.pin, before.pin)) return null; // the same PIN hashed again
  if (!cols.length) return null;
  return { area: spec.area, what: `${w.table} ${cols.join(', ')}`, before: strip(pickCols(before, cols)), after: strip(pickCols(w.map, cols)), key: keyVal };
}
const pickCols = (o, cols) => (o ? Object.fromEntries(cols.map((c) => [c, o[c]])) : null);
const strip = (o) => { if (!o || typeof o !== 'object') return o; const out = { ...o }; ['pin', 'pin_hash', 'pin_proof', 'password_hash', 'face'].forEach((k) => { if (k in out) out[k] = out[k] ? '****' : out[k]; }); return out; };

export class LockedError extends AppError {
  constructor(area, what) {
    super(`This is locked (${LOCKED_AREAS[area] || area}). The owner types their PIN again and gives a reason to change it.`);
    this.code = 'LOCKED'; this.area = area; this.what = what; this.isAppError = true;
  }
}

// The guard (installed below): a person's locked write needs an unlock for its area.
export function guardWrite(table, params, sql, person) {
  if (!person || !person.uid) return; // the app's own work, tests without a login
  try { if (require('./trainingFlag.js').isTraining()) return; } catch (e) { /* real */ }
  if (!TABLES[table] && table !== 'shared_settings' && table !== 'settings') return;
  // the screen tests' sample business only (marked by the test build, never on a real device – platform/training.js –
  // and only while the sample logins are still active)
  try {
    const s = db().get("SELECT value FROM settings WHERE key = 'ui_sample_db'");
    if (s && s.value === '1' && db().get("SELECT 1 AS x FROM users WHERE sync_status = 'seed' AND active = 1 LIMIT 1")) return;
  } catch (e) { /* real */ }
  const w = readWrite(sql, params);
  const hit = lockedAreaOf(w);
  if (!hit) return;
  const u = unlockedFor(hit.area);
  if (!u || u.uid !== person.uid) throw new LockedError(hit.area, hit.what);
  withSystem(() => {
    audit({ user: person, action: `Locked change: ${LOCKED_AREAS[hit.area]} – ${hit.what}`, table: w.table, recordUid: hit.key !== undefined && hit.key !== null ? String(hit.key) : null, before: hit.before, after: hit.after, reason: u.reason });
    if (!u.told) { u.told = true; tellOwner(person, hit.area, u.reason); }
  });
}

// Every device of the owner hears about it: a message everyone's app shows the owner (synced alert_log, event
// locked_change), and the owner's Viber channel when there is one.
export function tellOwner(person, area, reason) {
  const text = `🔒 ${person.name || 'Someone'} changed a locked setting: ${LOCKED_AREAS[area] || area}. Reason: ${reason}`;
  try {
    db().run('INSERT INTO alert_log (uid, at, event, text, mode, updated_at, updated_device) VALUES (?,?,?,?,?,?,?)', [uuid('AL'), stamp(), 'locked_change', text, 'owner', stamp(), deviceId()]);
  } catch (e) { /* no alert table yet */ }
  try { require('./stock.js').enqueue('viber', { text: `Easy Buys: ${text}`, event: 'locked_change', owner: true }); } catch (e) { /* offline queue missing */ }
  return text;
}
// Messages about locked changes this device has not shown yet (for the owner's notifications).
export function lockedNotices({ markShown = false } = {}) {
  let rows = [];
  try { rows = db().all("SELECT * FROM alert_log WHERE event = 'locked_change' ORDER BY at DESC LIMIT 50"); } catch (e) { rows = []; }
  const seen = new Set(getShared('locked_seen_' + deviceId(), []) || []);
  const fresh = rows.filter((r) => !seen.has(r.uid));
  if (markShown && fresh.length) withSystem(() => setShared('locked_seen_' + deviceId(), Array.from(new Set([...seen, ...fresh.map((r) => r.uid)])).slice(-200)));
  return fresh;
}

// ---------------------------------------------------------------- records pulled from other devices (audit C1 / H2)
const BOSS = ['owner', 'admin'];
const DATE_COLS = ['move_date', 'shift_date', 'date', 'entry_date', 'jdate', 'invoice_date', 'pay_date', 'txn_date', 'deposit_date', 'count_date', 'paid_date', 'week_start'];
// Why a record from the cloud is not applied here (null = apply). r: { t, k, d, vby, row }; local: this device's copy.
export function pulledRefusal(r, row, local) {
  const vouched = !!(r && r.vby && BOSS.includes(String(r.vby.role)));
  const u = String(row && row.updated_at ? row.updated_at : '');
  const limit = new Date(nowMs() + 26 * 3600000);
  const p2 = (n) => String(n).padStart(2, '0');
  const lim = `${limit.getFullYear()}-${p2(limit.getMonth() + 1)}-${p2(limit.getDate())} ${p2(limit.getHours())}:${p2(limit.getMinutes())}:${p2(limit.getSeconds())}`;
  if (u && u.replace('T', ' ').slice(0, 19) > lim) return 'its time is in the future';
  if (!vouched) {
    if (r.t === 'shared_settings' && isLockedShared(row && row.key) && !(local && same(local.value, row.value)) && !onlyFieldsSame(row.key, local ? local.value : null, row.value)) return 'a locked setting not made by the owner or admin';
    const spec = TABLES[r.t];
    if (spec) {
      if (r.t === 'users') {
        if (!local) { if (TOP.includes(String(row.role))) return 'a new owner / admin / manager / payroll login not made by the owner or admin'; }
        else {
          const changed = ['role', 'active', 'pin_hash'].filter((c) => row[c] !== undefined && row[c] !== null && !same(row[c], local[c]));
          if (changed.length) return `a change of ${changed.join(', ')} not made by the owner or admin`;
        }
      } else if (r.t === 'gl_accounts' && !local && String(row.system) === '1') {
        // the app's own standard accounts, made on any device
      } else if (!spec.only || spec.only(row, local)) {
        const cols = spec.cols === '*' ? Object.keys(row).filter((c) => !['updated_at', 'updated_device', 'sync_status'].includes(c)) : spec.cols;
        if (!local ? (spec.cols === '*' || cols.some((c) => row[c])) : cols.some((c) => row[c] !== undefined && !same(row[c], local[c]))) return `a locked record (${r.t}) not made by the owner or admin`;
      }
    }
  }
  // A closed month: an existing money record is not changed from elsewhere (an owner / admin adjustment is).
  if (local && !vouched) {
    let lockDate = null;
    try { lockDate = require('./lock.js').lockDate(); } catch (e) { lockDate = null; }
    const dc = DATE_COLS.find((c) => row[c] || local[c]);
    const d = dc ? String(local[dc] || row[dc] || '').slice(0, 10) : '';
    if (lockDate && d && d <= lockDate) return `the record is in a closed month (up to ${lockDate})`;
  }
  return null;
}
// What applying a pulled record notes in the change history (a refused one, or one arriving in a closed month).
export function notePulled(r, why) {
  try { withSystem(() => audit({ user: null, action: `Change from another device ${why ? 'refused' : 'applied'}: ${r.t} ${r.k}${why ? ` – ${why}` : ''}`, table: r.t, recordUid: String(r.k), after: { from: r.d || null, by: r.vby || null } })); } catch (e) { /* history not ready */ }
}

setLockGuard((table, params, sql) => {
  let person = null;
  try { person = require('./errorLog.js').appUser(); } catch (e) { person = null; }
  guardWrite(table, params, sql, person);
});
