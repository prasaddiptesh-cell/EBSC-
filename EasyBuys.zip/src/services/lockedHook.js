// 1.0.0 HOOK for the guard on crucial settings (stream F builds src/services/locked.js: owner only, owner PIN again,
// a reason, the change history and a notification). The Settings list asks isLocked(key) – key = the setting's screen
// name – and shows a 🔒 before a locked one. Until locked.js is wired in here, nothing is shown as locked.
// To wire it: replace the body below with
//   export { isLocked } from './locked.js';
// (or call into its own function with the same key). Nothing else needs to change.
export function isLocked(key) { // eslint-disable-line no-unused-vars
  return false;
}
