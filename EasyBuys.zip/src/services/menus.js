// Module menus. Each module's index.js declares
//   menu: [{ section: 'Daily tasks'|'Records'|'Checks'|'Reports'|'Settings', items: [{ id, icon, title, note, screen, params, perm }] }]
// and the shared ModuleMenu screen shows it, always in the same section order. `screen` may be a function of the
// person (e.g. the Bakery home depends on the bakery role); `perm` is a permission, a list (any of them) or a function.
// An item is only shown when the person may open its screen.
import { can } from './access.js';

export const MENU_SECTIONS = ['Daily tasks', 'Records', 'Checks', 'Reports', 'Settings'];
export const SECTION_HINT = {
  'Daily tasks': 'What is done every day',
  Records: 'Lists and history',
  Checks: 'Make sure everything is right',
  Reports: 'PDF · Excel · print',
  Settings: 'How this section works',
};

export function screenOf(item, user) { return typeof item.screen === 'function' ? item.screen(user) : item.screen; }
export function permOk(perm, user) {
  if (!perm) return true;
  if (typeof perm === 'function') return !!perm(user);
  if (Array.isArray(perm)) return perm.some((p) => can(user, p));
  return can(user, perm);
}
// The sections of a module's menu this person may use, in the fixed order. `screens` = allScreens() (name → { can }).
export function visibleMenu(mod, user, screens) {
  if (!mod || !Array.isArray(mod.menu) || !user) return [];
  const bySection = {};
  for (const sec of mod.menu) {
    if (!MENU_SECTIONS.includes(sec.section)) throw new Error(`Menu section "${sec.section}" in ${mod.id} is not one of ${MENU_SECTIONS.join(', ')}.`);
    for (const it of sec.items || []) {
      const name = screenOf(it, user);
      const entry = screens ? screens[name] : null;
      if (screens && (!entry || !entry.can(user))) continue;
      if (!permOk(it.perm, user)) continue;
      (bySection[sec.section] = bySection[sec.section] || []).push({ ...it, screen: name, module: mod.id });
    }
  }
  return MENU_SECTIONS.filter((s) => (bySection[s] || []).length).map((s) => ({ section: s, items: bySection[s] }));
}
// Every menu item of every module this person may use (for the Home search).
export function allMenuItems(modules, user, screens) {
  const out = [];
  for (const m of modules) {
    for (const sec of visibleMenu(m, user, screens)) for (const it of sec.items) out.push({ ...it, section: sec.section, moduleTitle: m.title, moduleIcon: m.icon });
  }
  return out;
}
// Checks a menu declaration (used by the tests): known sections, unique ids, every screen exists.
export function checkMenu(mod, screenNames) {
  const problems = [];
  const ids = new Set();
  let last = -1;
  for (const sec of mod.menu || []) {
    const i = MENU_SECTIONS.indexOf(sec.section);
    if (i < 0) problems.push(`${mod.id}: unknown section ${sec.section}`);
    if (i <= last) problems.push(`${mod.id}: section ${sec.section} out of order`);
    last = i;
    for (const it of sec.items || []) {
      if (!it.id || ids.has(it.id)) problems.push(`${mod.id}: missing or repeated id ${it.id}`);
      ids.add(it.id);
      if (!it.title) problems.push(`${mod.id}: ${it.id} has no title`);
      if (typeof it.screen === 'string' && screenNames && !screenNames.includes(it.screen)) problems.push(`${mod.id}: ${it.id} opens unknown screen ${it.screen}`);
    }
  }
  return problems;
}
