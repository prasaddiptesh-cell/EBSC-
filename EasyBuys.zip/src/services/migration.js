// v3.9.3 Moving the business into the app: every kind of information, in the order to do it, with where it comes from
// (Aronium, the bank, paper files…), the quickest way in (import, photo, typing), and how far it has got – counted from
// what is already in the app. A step can also be ticked by hand ("done" or "not needed"). Shown on the Go-live checklist.
import { db } from '../db/connection.js';
import { getShared, setShared, stamp, audit } from './core.js';

const n = (q, a = []) => { try { return Number((db().get(q, a) || {}).n) || 0; } catch (e) { return 0; } };
const plural = (k, word) => `${k} ${word}${k === 1 ? '' : 's'}`;

// Each step: key, phase, title, from (where the information is), how (the quickest way), screen, count() → { k, text }, need (how many is "done").
export const MIGRATION = [
  // 1. The business and the people
  { key: 'business', phase: 'The business and the people', title: 'Business details on documents (name, address, TIN, phone, logo)', from: 'Your letterhead / FRCS papers',
    how: 'Admin › Documents › Settings: type them once – every report, PO and payslip uses them.', screen: 'DocSettings',
    count: () => { const t = getShared('report_template', {}) || {}; const k = ['businessName', 'address', 'tin', 'phone'].filter((x) => String(t[x] || '').trim() && !(x === 'address' && t[x] === 'Lautoka, Fiji')).length; return { k, text: `${k} of 4 filled in` }; }, need: 4 },
  { key: 'shops', phase: 'The business and the people', title: 'Shops (Shop 1 with the bakery, Shop 2)', from: '—', how: 'Admin › Shops: names and addresses.', screen: 'Shops',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM shops WHERE active = 1'); return { k, text: plural(k, 'shop') }; }, need: 2 },
  { key: 'users', phase: 'The business and the people', title: 'Logins for every staff member (and a second owner / admin, e.g. Divnesh)', from: 'Staff list', how: 'Staff › Users › Add: name, role, shop, PIN.', screen: 'Users',
    count: () => { const k = n("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND COALESCE(sync_status,'') <> 'seed'"); const a = n("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role IN ('owner','admin')"); return { k, text: `${plural(k, 'login')} · ${a} owner / admin` }; }, need: 8 },
  { key: 'samples', phase: 'The business and the people', title: 'Sample logins turned off (Admin 1111, Sita 2222…) – anyone who knows them could get in', from: '—', how: 'Once your own owner / admin login works: "Turn them off" here (each device; a newly linked device does it by itself).', screen: 'Users', action: 'samples',
    count: () => { const k = n("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND sync_status = 'seed'"); return { k: k ? 0 : 1, text: k ? `${k} sample login(s) still work on this device` : 'Off on this device' }; }, need: 1 },
  { key: 'devices', phase: 'The business and the people', title: 'Every phone and tablet linked (for the stock take, every counter\'s phone)', from: '—', how: 'Admin › Devices › Add a device on a linked device – scan the code on the new one.', screen: 'Devices',
    count: () => ({ k: 1, text: 'See the Devices list' }), need: 0 },
  { key: 'staffpay', phase: 'The business and the people', title: 'Staff details and pay (rate, FNPF number, TIN, bank, start date)', from: 'Wages book, FNPF / FRCS forms', how: 'Payroll › Pay profiles: one per person (photo of their forms can be kept).', screen: 'PayProfiles',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM pay_profiles'); return { k, text: plural(k, 'pay profile') }; }, need: 8 },
  { key: 'leave', phase: 'The business and the people', title: 'Leave balances', from: 'Leave records', how: 'Leave › Set up: days owed to each person.', screen: 'Leave', params: { tab: 'setup' },
    count: () => { const k = n('SELECT COUNT(*) AS n FROM leave_entitlements'); return { k, text: plural(k, 'balance') }; }, need: 1 },
  // 2. From Aronium (nothing is ever written back to Aronium)
  { key: 'suppliers', phase: 'From Aronium (read only)', title: 'Suppliers', from: 'Aronium › Customers & suppliers › Export', how: 'Inventory › Import suppliers from Aronium: paste or pick the file.', screen: 'SupplierImport',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM ap_suppliers WHERE active = 1'); return { k, text: plural(k, 'supplier') }; }, need: 5 },
  { key: 'products', phase: 'From Aronium (read only)', title: 'Products (codes, barcodes, cost, selling price, VAT)', from: 'Aronium › Products › Export', how: 'Inventory › Import from Aronium – for each shop. Run it again any time prices change.', screen: 'InvImport',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM inv_items WHERE aronium_seen IS NOT NULL AND removed_at IS NULL'); return { k, text: `${k} products from Aronium` }; }, need: 50 },
  { key: 'vat', phase: 'From Aronium (read only)', title: 'VAT the same in Aronium and the app (12.5% / zero rated / VAT free)', from: '—', how: 'Inventory › VAT: Aronium vs the app – fix each one.', screen: 'VatCheck',
    count: () => { const k = n("SELECT COUNT(*) AS n FROM inv_items WHERE active = 1 AND aronium_vat IS NOT NULL AND ((aronium_vat = 'standard') <> (vat_type = 'standard'))"); return { k: k ? 0 : 1, text: k ? `${k} different` : 'All the same' }; }, need: 1 },
  { key: 'staffcredit', phase: 'From Aronium (read only)', title: 'Staff credit balances', from: 'Aronium › customer balances (staff)', how: 'Money owed › Import from Aronium.', screen: 'OwedImport',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM staff_credit_imports'); return { k, text: k ? 'Imported' : 'Not yet' }; }, need: 1 },
  // 3. Money set-up
  { key: 'bank', phase: 'Money set-up', title: 'Bank account(s) and cheque books', from: 'BSP statement, cheque books', how: 'Invoices & cheques › Cheque books: the account, then each book (first and last cheque number).', screen: 'ChequeBooks',
    count: () => { const a = n('SELECT COUNT(*) AS n FROM bank_accounts WHERE active = 1'); const b = n('SELECT COUNT(*) AS n FROM cheque_books'); return { k: a && b ? 1 : 0, text: `${plural(a, 'account')} · ${plural(b, 'cheque book')}` }; }, need: 1 },
  { key: 'wallets', phase: 'Money set-up', title: 'M-PAiSA wallets (one per shop)', from: 'M-PAiSA app', how: 'Bank › Wallets › Set up.', screen: 'WalletSetup',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM wallets'); return { k, text: plural(k, 'wallet') }; }, need: 2 },
  { key: 'tills', phase: 'Money set-up', title: 'Tills, floats and shifts', from: '—', how: 'Till › Set up: each till, its float, the shift names.', screen: 'TillSetup',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM tills WHERE active = 1'); return { k, text: plural(k, 'till') }; }, need: 2 },
  { key: 'loans', phase: 'Money set-up', title: 'Loans, rent and regular bills (5 loans, rent on 3 shops and the home)', from: 'Loan papers, rent agreements, last receipts', how: 'Loans & rent › Add: amount, repayment, dates – a photo of the paper fills it in.', screen: 'LoanSetup',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM regular_terms'); return { k, text: `${k} loans / regular bills` }; }, need: 8 },
  { key: 'recurring', phase: 'Money set-up', title: 'Other regular payments (power, water, phone, internet…)', from: 'Last bills', how: 'Invoices & cheques › Regular payments.', screen: 'Recurring',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM ap_recurring'); return { k, text: plural(k, 'regular payment') }; }, need: 1 },
  { key: 'licences', phase: 'Money set-up', title: 'Licences and permits (liquor, spirit, business, health…) with renewal dates', from: 'The certificates', how: 'Licences › Add – a photo of each certificate.', screen: 'Licences',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM licences'); return { k, text: plural(k, 'licence') }; }, need: 2 },
  { key: 'vehicles', phase: 'Money set-up', title: 'Vehicles (registration, insurance, service dates)', from: 'LTA / insurance papers', how: 'Vehicles › Add.', screen: 'VeList',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM ve_items'); return { k, text: plural(k, 'vehicle') }; }, need: 1 },
  { key: 'orderdays', phase: 'Money set-up', title: 'Supplier order days, cut-off times and budgets', from: 'Who comes when', how: 'Inventory › Supplier order days.', screen: 'SupplierSchedules',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM supplier_schedules'); return { k, text: plural(k, 'supplier') }; }, need: 1 },
  { key: 'fccc', phase: 'Money set-up', title: 'FCCC price-controlled products linked to the FCCC list', from: 'The app reads the FCCC website', how: 'Inventory › FCCC controlled prices › tap each suggestion that is right.', screen: 'Fccc',
    count: () => { const k = n('SELECT COUNT(*) AS n FROM inv_items WHERE fccc = 1'); return { k, text: `${k} controlled` }; }, need: 1 },
];

export function migrationTicks() { return (getShared('migration_ticks', {}) || {}); }
export function tickMigration(user, key, value) {
  const t = { ...migrationTicks() };
  if (!value) delete t[key]; else t[key] = { v: value, by: user.name, at: stamp() };
  setShared('migration_ticks', t);
  audit({ user, action: `Go-live: "${(MIGRATION.find((s) => s.key === key) || {}).title || key}" ${value ? (value === 'na' ? 'not needed' : 'done') : 'ticked off again'}`, table: 'shared_settings' });
}
// The steps with how far each one is. done: counted enough, or ticked by hand.
export function migrationStatus() {
  const t = migrationTicks();
  return MIGRATION.map((s) => {
    let c = { k: 0, text: '' };
    try { c = s.count(); } catch (e) { /* 0 */ }
    const tick = t[s.key] || null;
    const auto = s.need > 0 && c.k >= s.need;
    return { ...s, progress: c.text, auto, tick, done: auto || !!tick };
  });
}
