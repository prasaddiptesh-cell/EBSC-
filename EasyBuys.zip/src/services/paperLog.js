// v3.9.2 Photo reading log: what was read from each photo of paper, what was filled in and what the person changed.
// Kept on this tablet (not synced) so the reader can be tuned to the real papers later (Admin › Photo reading log).
// The change history (audit) also gets one line per saved record: "Read from the photo …; changed by …".
import { db } from '../db/connection.js';
import { stamp, uuid, audit, money } from './core.js';
import { PAPER_LABELS } from './paperRead.js';

export const PAPER_LOG_SQL = `
CREATE TABLE IF NOT EXISTS paper_reads (
  uid TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  ref_table TEXT, ref_uid TEXT,
  engine TEXT,
  text TEXT,
  fields TEXT,
  filled TEXT,
  changed TEXT,
  checked INTEGER NOT NULL DEFAULT 0,
  by_name TEXT,
  at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_paper_reads_at ON paper_reads(at);
`;
const lab = (k) => PAPER_LABELS[k] || (String(k).startsWith('tender:') ? String(k).slice(7) : k);
const show = (v) => (typeof v === 'number' ? money(v) : String(v === null || v === undefined || v === '' ? '(empty)' : v));

// One line for the change history.
export function paperReadSummary(kind, filled = [], changed = []) {
  const a = `${filled.length} box(es) filled from the photo`;
  const b = changed.length ? `; changed by the person: ${changed.map((c) => `${lab(c.field)} ${show(c.read)} → ${show(c.kept)}`).join(', ')}` : '; all kept as read';
  return a + b;
}
// Never stops a save: a failure here is ignored.
export function logPaperRead(user, { kind, table, uid, engine, text, fields, filled = [], changed = [], checked = false }) {
  try {
    db().run('INSERT INTO paper_reads (uid, kind, ref_table, ref_uid, engine, text, fields, filled, changed, checked, by_name, at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [uuid('PR'), kind, table || null, uid || null, engine || null, String(text || '').slice(0, 6000), JSON.stringify(fields || {}), JSON.stringify(filled), JSON.stringify(changed), checked ? 1 : 0, user ? user.name : null, stamp()]);
    // a fault-finding log, not business records: only the latest 5000 readings are kept
    try { db().run('DELETE FROM paper_reads WHERE uid IN (SELECT uid FROM paper_reads ORDER BY at DESC LIMIT -1 OFFSET 5000)'); } catch (e) { /* fine */ }
    if (table && uid) audit({ user, action: `Photo read (${kind}): ${paperReadSummary(kind, filled, changed)}`, table, recordUid: uid, after: { read: fields, changed } });
  } catch (e) { /* the log must never stop the work */ }
}
export function listPaperReads({ kind, limit = 200 } = {}) {
  try {
    return db().all(`SELECT * FROM paper_reads ${kind ? 'WHERE kind = ?' : ''} ORDER BY at DESC LIMIT ?`, kind ? [kind, limit] : [limit])
      .map((r) => ({ ...r, fields: JSON.parse(r.fields || '{}'), filled: JSON.parse(r.filled || '[]'), changed: JSON.parse(r.changed || '[]') }));
  } catch (e) { return []; }
}
// How well the reader does on each kind of paper: boxes filled, and how many the people had to change.
export function paperReadStats() {
  const out = {};
  for (const r of listPaperReads({ limit: 2000 })) {
    const s = (out[r.kind] = out[r.kind] || { reads: 0, filled: 0, changed: 0 });
    s.reads += 1; s.filled += r.filled.length; s.changed += r.changed.length;
  }
  return out;
}
