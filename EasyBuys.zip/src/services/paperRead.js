// v3.9.2 Reading paper: the text of a photo (read on the tablet) → the boxes of the screen it was taken on.
// Every figure is only a suggestion: the screen lists what was filled in, and the person ticks that they checked it
// against the paper before saving. Kept free of React / device code so it can be tested with sample papers.
//   readPaperText(kind, text, ctx) → { fields, from, checks: [{ level, text }], found, labels }
// kinds: z (Aronium Z report / End of day), invoice (supplier invoice / paid receipt), fuel (fuel receipt),
//        deposit (stamped bank deposit slip), lodgement (FRCS / FNPF receipt), proof (bank transfer / payment receipt,
//        cheque stub), aronium (Aronium receipt for staff credit), loan (loan repayment receipt)
import { parseInvoiceText, ebDatesIn, ebAmountsIn } from '../modules/payables/parser.js';
import { readZText, Z_LABELS } from '../modules/till/zRead.js';
import { aiPaperFields } from './invoiceAi.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const linesOf = (text) => String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
// Amounts on a line, also when OCR wrote "1 234.50" or "812,40".
function amounts(line) {
  const a = ebAmountsIn(String(line).replace(/(\d),(\d{2})(?!\d)/g, '$1.$2').replace(/(\d) (\d{3})(?=[.,]\d{2})/g, '$1$2'));
  return a;
}
// The amount after a label (same line, or alone on the next line). last = the last such line on the paper.
function amountAfter(lines, re, { exclude, last = false } = {}) {
  let found = null; let line = null;
  for (let i = 0; i < lines.length; i++) {
    if (!re.test(lines[i]) || (exclude && exclude.test(lines[i]))) continue;
    let a = amounts(lines[i]);
    if (!a.length && lines[i + 1] && !/[a-z]{4}/i.test(lines[i + 1])) a = amounts(lines[i + 1]);
    if (a.length) { found = a[a.length - 1]; line = lines[i]; if (!last) break; }
  }
  return found === null ? null : { v: r2(found), line };
}
// A code after a label: "Ref: TRX-88812", "Receipt No 004512", "Slip # 7741".
function codeAfter(lines, re, { min = 3 } = {}) {
  const g = new RegExp(re.source, re.flags.includes('g') ? re.flags : `${re.flags}g`);
  for (const l of lines) {
    g.lastIndex = 0;
    let m;
    while ((m = g.exec(l))) {
      if (!m[0]) { g.lastIndex += 1; continue; }
      const rest = l.slice(m.index + m[0].length).replace(/^[\s:#.\-–]+/, '');
      const c = (rest.match(/^([A-Z0-9][A-Z0-9\-/]{1,30})/i) || [])[1];
      if (c && c.length >= min && /\d/.test(c)) return { v: c.toUpperCase(), line: l };
    }
  }
  return null;
}
function firstDate(lines, prefer = /date|paid|on\b/i) {
  for (const l of lines) if (prefer.test(l) && !/due|expir/i.test(l)) { const d = ebDatesIn(l); if (d.length) return { v: d[0], line: l }; }
  for (const l of lines) { if (/due|expir/i.test(l)) continue; const d = ebDatesIn(l); if (d.length) return { v: d[0], line: l }; }
  return null;
}
function biggest(lines) {
  let best = null;
  for (const l of lines) for (const a of amounts(l)) if (!best || a > best.v) best = { v: r2(a), line: l };
  return best;
}

// Rebuild the printed rows from where each line sits on the photo, so "Total sales ...... 812.40" stays one row even
// when ML Kit reads the labels and the amounts as two columns. null when no positions are given.
// 1.0.0 a photo taken a little crooked still gives rows: each piece is compared with the nearest piece of the row
// (not the row's first piece), the tolerance is wider, and a line without a position no longer stops the rebuild (it
// stays after the line read before it).
export function rowsFromResult(r) {
  const items = [];
  let seq = 0; let framed = 0; let lastCy = 0;
  for (const b of (r && r.blocks) || []) {
    for (const l of b.lines || []) {
      if (!l || !l.text) continue;
      seq += 1;
      const fr = l.frame || l.boundingBox || l.rect;
      const top = fr ? (fr.top !== undefined ? fr.top : fr.y) : NaN;
      const left = fr ? (fr.left !== undefined ? fr.left : fr.x) : NaN;
      const h = fr ? (fr.height !== undefined ? fr.height : (fr.bottom !== undefined ? fr.bottom - top : 0)) : 0;
      if (!Number.isFinite(top) || !Number.isFinite(left) || !(h > 0)) { items.push({ text: l.text, cy: lastCy + 0.001 * seq, h: 0, left: 1e9, loose: true }); continue; }
      const w = fr.width !== undefined ? fr.width : (fr.right !== undefined ? fr.right - left : 0);
      framed += 1; lastCy = top + h / 2;
      items.push({ text: l.text, cy: lastCy, h, left, right: left + (w > 0 ? w : 0) });
    }
  }
  if (!framed) return null;
  items.sort((a, b) => a.cy - b.cy);
  const rows = [];
  for (const it of items) {
    if (it.loose) { rows.push({ cy: it.cy, h: 0, items: [it] }); continue; }
    let row = null; let bestD = Infinity;
    for (const x of rows.slice(-6)) {
      if (!x.h) continue;
      // the nearest piece of the row, so a tilted row (rising to the right) stays together
      const near = x.items.filter((p) => !p.loose).reduce((a, p) => (Math.abs(p.left - it.left) < Math.abs(a.left - it.left) ? p : a));
      const d = Math.abs(near.cy - it.cy);
      if (d < Math.min(near.h, it.h) * 0.7 && d < bestD && !x.items.some((p) => !p.loose && p.left < it.left + 1 && p.right > it.left + 1 && Math.abs(p.cy - it.cy) > 2)) { row = x; bestD = d; }
    }
    if (row) { row.items.push(it); row.h = Math.max(row.h, it.h); } else rows.push({ cy: it.cy, h: it.h, items: [it] });
  }
  return rows.map((x) => x.items.sort((a, b) => a.left - b.left).map((i) => i.text).join('   ')).join('\n');
}

export const PAPER_LABELS = {
  payee: 'Made out to', bank: 'Bank', supplierUid: 'Supplier',
  ...Z_LABELS,
  supplierName: 'Supplier', newSupplierName: 'New supplier name', tin: 'TIN', invoiceNo: 'Invoice / receipt no.', total: 'Total', vat: 'VAT', subtotal: 'Before VAT',
  litres: 'Litres', pricePerLitre: 'Price a litre', slipNo: 'Slip number', cash: 'Cash', cheques: 'Cheques', ref: 'Reference', amount: 'Amount', chequeNo: 'Cheque number',
  receiptNo: 'Receipt number', branch: 'Branch', account: 'Account', balance: 'Balance',
};

const READERS = {
  z(text, ctx) { return readZText(text, { tenders: ctx.tenders || [], vatRate: ctx.vatRate || 0.125 }); },

  invoice(text, ctx) {
    const vatRate = ctx.vatRate || 0.125;
    const p = parseInvoiceText(text, ctx.suppliers || [], vatRate, { today: ctx.today });
    const f = {};
    if (p.supplier) f.supplierName = p.supplier;
    if (p.supplier_tin) f.tin = p.supplier_tin;
    if (p.invoice_no) f.invoiceNo = p.invoice_no;
    else { const r = codeAfter(linesOf(text), /\b(receipt|rcpt|docket|bill)\s*(no\.?|number|#)?/i); if (r) f.invoiceNo = r.v; }
    if (p.invoice_date) f.date = p.invoice_date;
    if (p.total !== null) f.total = r2(p.total);
    if (p.vat !== null) f.vat = r2(p.vat);
    if (p.subtotal !== null) f.subtotal = r2(p.subtotal);
    const sup = (ctx.suppliers || []).find((s) => s.name === p.supplier);
    if (sup && sup.uid) f.supplierUid = sup.uid;
    else if (f.supplierName) f.newSupplierName = f.supplierName; // only for the "new supplier" box
    const checks = (p.notes || []).filter((n) => !/^Could not read/.test(n)).map((n) => ({ level: 'warn', text: n }));
    if (f.supplierName && !f.supplierUid && (ctx.suppliers || []).length) checks.push({ level: 'warn', text: `"${f.supplierName}" is not one of your suppliers – choose the supplier yourself.` });
    return { fields: f, from: {}, checks, found: Object.keys(f).length };
  },

  fuel(text, ctx) {
    const base = READERS.invoice(text, ctx);
    const lines = linesOf(text);
    const f = { ...base.fields };
    for (const l of lines) {
      const m = l.match(/(\d{1,3}(?:[.,]\d{1,3})?)\s*(l|lt|ltr|ltrs|litres?|liters?)\b/i) || (/litre|liter|ltr|volume|qty/i.test(l) && l.match(/(\d{1,3}[.,]\d{1,3})/));
      if (m && f.litres === undefined) { const v = Number(String(m[1]).replace(',', '.')); if (v > 0 && v < 500) f.litres = v; }
      const p = /price|rate|\/\s*l\b|per\s*lit/i.test(l) ? amounts(l).find((a) => a > 0.5 && a < 10) : null;
      if (p && f.pricePerLitre === undefined) f.pricePerLitre = p;
    }
    if (f.litres && !f.pricePerLitre && f.total) f.pricePerLitre = r2(f.total / f.litres);
    const checks = base.checks.slice();
    if (f.litres && f.pricePerLitre && f.total && Math.abs(r2(f.litres * f.pricePerLitre) - f.total) > 0.5) checks.push({ level: 'warn', text: `Litres × price = ${r2(f.litres * f.pricePerLitre).toFixed(2)}, the total read is ${f.total.toFixed(2)} – check them.` });
    return { fields: f, from: {}, checks, found: Object.keys(f).length };
  },

  deposit(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    put('slipNo', codeAfter(lines, /\b(slip|deposit|seq(uence)?|transaction|txn|ref(erence)?|serial)\s*(no\.?|number|#|id)?/i, { min: 3 }));
    put('date', firstDate(lines));
    put('cash', amountAfter(lines, /\b(cash|notes|coins?)\b/i, { exclude: /cheque/i }));
    put('cheques', amountAfter(lines, /\bcheques?\b/i, { exclude: /no\.?\s*of|number of/i }));
    put('total', amountAfter(lines, /\btotal|amount\s*deposited|deposit\s*amount|\bamount\b/i, { last: true }));
    if (f.total === undefined) put('total', biggest(lines));
    const acc = lines.map((l) => (l.match(/\b(?:a\/c|acc(?:oun)?t)\s*(?:no\.?|number|#)?\s*[:.]?\s*([0-9 \-xX*]{5,20})/i) || [])[1]).find(Boolean);
    if (acc) f.account = acc.replace(/\s+/g, '');
    const br = lines.find((l) => /branch/i.test(l));
    if (br) { const b = br.replace(/.*branch\s*[:.\-]?\s*/i, '').trim(); if (b && /[a-z]{3}/i.test(b)) f.branch = b; }
    const checks = [];
    if (f.total !== undefined && (f.cash !== undefined || f.cheques !== undefined)) {
      const s = r2((f.cash || 0) + (f.cheques || 0));
      checks.push(Math.abs(s - f.total) < 0.02 ? { level: 'ok', text: 'Cash + cheques = total' } : { level: 'warn', text: `Cash + cheques come to ${s.toFixed(2)}, the total read is ${f.total.toFixed(2)}.` });
    }
    return { fields: f, from, checks, found: Object.keys(f).length };
  },

  lodgement(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    put('ref', codeAfter(lines, /\b(receipt|acknowledg(e)?ment|confirmation|submission|lodg(e)?ment|reference|ref|transaction|trn|tracking|document)\s*(no\.?|number|#|id)?/i, { min: 4 }));
    put('date', firstDate(lines, /date|lodged|submitted|received|paid/i));
    put('amount', amountAfter(lines, /\b(total|amount|payable|paid|tax\s*payable|contribution)/i, { exclude: /refund/i }));
    if (f.amount === undefined) put('amount', biggest(lines));
    return { fields: f, from, checks: [], found: Object.keys(f).length };
  },

  proof(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    const chq = lines.map((l) => (l.match(/\bcheque\s*(?:no\.?|number|#)?\s*[:.]?\s*(\d{3,9})\b/i) || [])[1]).find(Boolean);
    if (chq) f.chequeNo = String(Number(chq));
    put('ref', codeAfter(lines, /\b(reference|ref|receipt|transaction|trans|txn|trn|confirmation|payment\s*id|rrn)\s*(no\.?|number|#|id)?/i, { min: 4 }));
    put('date', firstDate(lines, /date|paid|on\b|processed|time/i));
    put('amount', amountAfter(lines, /\b(amount|total|paid|transfer(red)?|debit)/i, { exclude: /balance|available|fee/i }));
    if (f.amount === undefined) put('amount', biggest(lines));
    return { fields: f, from, checks: [], found: Object.keys(f).length };
  },

  aronium(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    put('receiptNo', codeAfter(lines, /\b(receipt|document|doc|invoice|bill|no\.?)\s*(no\.?|number|#)?/i, { min: 2 }));
    put('date', firstDate(lines));
    put('total', amountAfter(lines, /\b(total|amount\s*due|to\s*pay|balance)/i, { exclude: /sub\s*-?total|tax|vat|items|qty/i, last: false }));
    if (f.total === undefined) put('total', biggest(lines));
    return { fields: f, from, checks: [], found: Object.keys(f).length };
  },

  statement(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    put('balance', amountAfter(lines, /\b(closing\s*balance|balance\s*(due|owing|now)?|amount\s*(now\s*)?due|total\s*(due|outstanding|owing)|outstanding|please\s*pay)/i, { exclude: /opening|previous|brought\s*forward|b\/f|last\s*statement/i, last: true }));
    put('date', firstDate(lines, /statement\s*date|date|as\s*at/i));
    return { fields: f, from, checks: [], found: Object.keys(f).length };
  },

  loan(text) {
    const lines = linesOf(text);
    const f = {}; const from = {};
    const put = (k, r) => { if (r && f[k] === undefined) { f[k] = r.v; from[k] = r.line; } };
    put('receiptNo', codeAfter(lines, /\b(receipt|reference|ref|transaction|txn)\s*(no\.?|number|#)?/i, { min: 3 }));
    put('date', firstDate(lines, /date|paid|received/i));
    put('amount', amountAfter(lines, /\b(amount\s*(paid|received)?|paid|repayment|received|total)/i, { exclude: /balance|arrears|outstanding/i }));
    if (f.amount === undefined) put('amount', biggest(lines));
    return { fields: f, from, checks: [], found: Object.keys(f).length };
  },
};
// v3.9.8 a screenshot of EFL's bill checker: account, total due, overdue, due date.
READERS.efl_bill = (text) => {
  const r = require('./utilityBills.js').parseBillText(text);
  const f = {}; const from = {};
  if (r.account) f.accountNo = r.account;
  if (r.billNo) f.billNo = r.billNo;
  if (r.total !== null) f.total = r.total;
  if (r.overdue !== null) f.overdue = r.overdue;
  if (r.due) f.due = r.due;
  return { fields: f, from, checks: [], found: Object.keys(f).length };
};
READERS.cheque = (text) => require('./chequeRead.js').chequeFromText(text);
export const PAPER_KINDS = Object.keys(READERS);
// 1.0.0 the papers the AI in the cloud reads (Google Gemini, cloud/Code.gs invoice_ai); the rest are read on the phone.
// 1.0.0 build 54: power / water bills (efl_bill) too – a photo, a screenshot or the PDF from EFL / WAF.
export const AI_PAPER_KINDS = ['invoice', 'fuel', 'efl_bill', 'cheque'];
// build 31: read by the AI as soon as the photo is taken (small and quick) – no "Ask the AI" tap
export const AUTO_AI_KINDS = ['cheque'];
// The AI's reading (services/invoiceAi.js cleanAi) → the same { fields, from, checks, found } as readPaperText.
export function readPaperAi(kind, ai, ctx = {}) {
  if (!AI_PAPER_KINDS.includes(kind) || !ai) return null;
  try {
    const r = aiPaperFields(kind, ai, ctx);
    return { fields: r.fields || {}, from: {}, checks: r.checks || [], found: r.found || 0 };
  } catch (e) { return null; }
}

export function readPaperText(kind, text, ctx = {}) {
  const fn = READERS[kind];
  if (!fn) return { fields: {}, from: {}, checks: [], found: 0 };
  try {
    const r = fn(text || '', ctx);
    return { fields: r.fields || {}, from: r.from || {}, checks: r.checks || [], found: r.found || 0, looksLikeZ: r.looksLikeZ };
  } catch (e) {
    // A strange photo must never stop the screen: nothing is filled, the person types it.
    return { fields: {}, from: {}, checks: [{ level: 'warn', text: 'The photo could not be understood – please type the figures.' }], found: 0 };
  }
}

// Fill only empty boxes (or boxes filled by an earlier reading). map: { readField: formKey }.
// → { form, filled: [{ key, label, value }] }
// soft: { formKey: defaultValue } – a box still showing its default (e.g. today's date) counts as empty.
export function fillEmpty(form, fields, map, prevFilled = [], soft = {}) {
  const out = { ...form };
  const filled = [];
  const isSoft = (fk, v) => Object.prototype.hasOwnProperty.call(soft || {}, fk) && String(soft[fk]) === String(v);
  const empty = (v, fk) => v === '' || v === null || v === undefined || isSoft(fk, v);
  for (const [rk, fk] of Object.entries(map)) {
    const v = fields[rk];
    if (v === undefined || v === null || v === '') continue;
    if (empty(out[fk], fk) || prevFilled.includes(fk)) { out[fk] = typeof v === 'number' ? String(v) : v; filled.push(fk); }
  }
  return { form: out, filled };
}
// What the person changed after the reading: [{ field, read, kept }]
export function changesAfterRead(form, fields, map) {
  const out = [];
  for (const [rk, fk] of Object.entries(map)) {
    const v = fields[rk];
    if (v === undefined || v === null || v === '') continue;
    const now = form[fk] === undefined || form[fk] === null ? '' : String(form[fk]);
    const same = typeof v === 'number' ? now !== '' && Math.abs(Number(now) - v) < 0.005 : now.trim().toUpperCase() === String(v).trim().toUpperCase();
    if (!same) out.push({ field: fk, read: v, kept: now });
  }
  return out;
}
