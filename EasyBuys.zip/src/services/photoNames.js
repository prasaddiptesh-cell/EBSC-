// 1.0.0 (owner, 2 Nov): readable names and few folders for the photos of records in Google Drive.
//   Easy Buys › Records › "2026-10 October" › "Shop 1 - Drasa Avenue" (or "Business") › Invoices | Cheques
//   "2026-10-11 Bijay - INV 4521.jpg", "… (page 2).jpg", "2026-10-12 Cheque 001234 - Bijay - $512.30.jpg",
//   "2026-10-12 Payment - Bijay - $512.30.jpg" (a payment without a cheque number).
// In the month folder itself (not under the shops): Deposits ("2026-10-14 Deposit - Shop 1 - $2,300.00.jpg"),
// Z reports ("2026-10-14 Z 1077 - Shop 1 Till 1.jpg") and Payslips ("2026-10 Week ending 2026-10-17 - Ana - Payslip.pdf").
// Only these kinds move; every other photo kind keeps its old place and old name.
// The cloud (cloud/Code.gs photoPlace_) builds the same names for the photos already in Drive (tidy_records).

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
// Which photo kinds get the new place, and the folder under the shop.
export const PHOTO_FOLDERS = { invoice: 'Invoices', payment: 'Cheques', stub: 'Cheques', deposit: 'Deposits', till: 'Z reports' };
// These sit straight in the month folder (shopFolder '').
const MONTH_LEVEL = { deposit: 1, till: 1 };
export const NAME_LIMIT = 115; // the name without ".jpg" – Drive and Windows are happy well under 120

// Characters Drive / Windows dislike become spaces; runs of spaces become one; no dot or space at the end.
export function cleanPart(s) {
  return String(s === null || s === undefined ? '' : s).replace(/[<>:"/\\|?*\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/, '');
}

// "2026-10-11" → "2026-10 October"; null for a date that isn't one.
export function monthFolderOf(date) {
  const m = /^(\d{4})-(\d{2})-\d{2}/.exec(String(date || ''));
  if (!m || +m[2] < 1 || +m[2] > 12) return null;
  return `${m[1]}-${m[2]} ${MONTHS[+m[2] - 1]}`;
}

// The shop's folder: "Shop 1 - Drasa Avenue" (the name already says "Shop 1 - …", or S1 + its name); no shop → "Business".
export function shopFolderOf(shop) {
  if (!shop) return 'Business';
  const name = cleanPart(shop.name);
  const n = /^S(\d+)$/i.exec(String(shop.code || ''));
  if (/^shop\s*\d+/i.test(name)) return name;
  if (n) return name ? `Shop ${n[1]} - ${name}` : `Shop ${n[1]}`;
  return name || cleanPart(shop.code) || 'Business';
}

// The short shop label used inside a name: "Shop 1".
export function shopShortOf(shop) {
  if (!shop) return '';
  const n = /^S(\d+)$/i.exec(String(shop.code || ''));
  if (n) return `Shop ${n[1]}`;
  const m = /^shop\s*(\d+)/i.exec(cleanPart(shop.name));
  return m ? `Shop ${m[1]}` : (cleanPart(shop.name) || cleanPart(shop.code));
}
// $2,300.00
export const money = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return '';
  const [i, d] = n.toFixed(2).split('.');
  return `$${i.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}.${d}`;
};
// Cheque numbers as printed on the leaf: 1234 → "001234".
const chequeNo = (v) => { const s = cleanPart(v); return /^\d{1,5}$/.test(s) ? s.padStart(6, '0') : s; };
const invoiceNo = (v) => { const s = cleanPart(v); return !s ? '' : (/^inv/i.test(s) ? s : `INV ${s}`); };

// The pure part: { refType, record, shop, chequeNo, page, ext } → { fileName, monthFolder, shopFolder, typeFolder },
// or null when this photo keeps the old place (another kind, no record, no date).
export function photoPlace({ refType, record, shop = null, chequeNo: cq = null, page = 1, ext = 'jpg' } = {}) {
  const typeFolder = PHOTO_FOLDERS[refType];
  if (!typeFolder || !record) return null;
  let date; let head; let party; let tail = '';
  if (refType === 'invoice') {
    date = record.invoice_date || record.received_date;
    party = record.supplier_name;
    head = null;
    const no = invoiceNo(record.invoice_no);
    tail = record.kind === 'credit' ? `Credit note${record.invoice_no ? ` ${cleanPart(record.invoice_no)}` : ''}` : (no || 'Invoice');
  } else if (refType === 'payment') {
    date = record.pay_date;
    const c = chequeNo(cq || record.cheque_no);
    head = c ? `Cheque ${c}` : 'Payment';
    party = record.supplier_name;
    tail = money(record.amount);
  } else if (refType === 'deposit') {
    date = record.deposit_date || String(record.created_at || '').slice(0, 10);
    head = 'Deposit';
    party = shopShortOf(shop);
    tail = money(record.total || (Number(record.cash_amount || 0) + Number(record.cheque_amount || 0)));
  } else if (refType === 'till') {
    date = record.shift_date || String(record.counted_at || '').slice(0, 10);
    const z = cleanPart(record.z_number);
    head = z ? `Z ${z}` : 'Z report';
    const till = cleanPart(record.till_name);
    const where = shopShortOf(shop);
    party = /shop/i.test(till) || !where ? till : `${where} ${till}`.trim();
  } else {
    date = record.cheque_date;
    const c = chequeNo(cq || record.cheque_no);
    head = c ? `Cheque ${c}` : 'Cheque';
    party = record.payee;
    tail = money(record.amount);
  }
  const monthFolder = monthFolderOf(date);
  if (!monthFolder) return null;
  const day = String(date).slice(0, 10);
  const suffix = Number(page) > 1 ? ` (page ${Number(page)})` : '';
  let who = cleanPart(party);
  const build = () => {
    const bits = [head ? `${day} ${head}` : day];
    if (who) bits.push(who);
    if (tail) bits.push(cleanPart(tail));
    // An invoice's first part is the supplier ("2026-10-11 Bijay - INV 4521"), not "2026-10-11 - Bijay".
    const s = head ? bits.join(' - ') : `${day} ${bits.slice(1).join(' - ')}`.trim();
    return s + suffix;
  };
  let stem = build();
  if (stem.length > NAME_LIMIT && who) { who = who.slice(0, Math.max(1, who.length - (stem.length - NAME_LIMIT))).trim(); stem = build(); }
  if (stem.length > NAME_LIMIT) stem = stem.slice(0, NAME_LIMIT).trim();
  const e = /^(pdf|jpg|jpeg|png)$/i.test(String(ext || '')) ? String(ext).toLowerCase() : 'jpg';
  return { fileName: `${stem}.${e}`, monthFolder, shopFolder: MONTH_LEVEL[refType] ? '' : shopFolderOf(shop), typeFolder };
}

// The record behind a photo on this device. `get(sql, args)` is db().get (kept as a parameter for tests).
export function photoPlaceFromDb(get, ph, ext = 'jpg') {
  if (!ph || !PHOTO_FOLDERS[ph.ref_type]) return null;
  const one = (sql, args) => { try { return get(sql, args) || null; } catch (e) { return null; } };
  const shopOf = (code) => (code ? one('SELECT code, name FROM shops WHERE code = ?', [code]) || { code, name: '' } : null);
  const invoiceShopOfPayment = (payUid) => {
    const r = payUid ? one("SELECT i.shop_code FROM ap_allocations a JOIN ap_invoices i ON i.uid = a.invoice_uid WHERE a.payment_uid = ? AND i.shop_code IS NOT NULL AND i.shop_code <> '' ORDER BY a.uid LIMIT 1", [payUid]) : null;
    return r ? r.shop_code : null;
  };
  let record = null; let shop = null; let cq = null;
  if (ph.ref_type === 'invoice') {
    record = one('SELECT * FROM ap_invoices WHERE uid = ?', [ph.ref_id]);
    if (record) shop = shopOf(record.shop_code);
  } else if (ph.ref_type === 'payment') {
    record = one('SELECT * FROM ap_payments WHERE uid = ?', [ph.ref_id]);
    if (record) {
      if (!record.cheque_no && record.cheque_uid) { const c = one('SELECT cheque_no FROM cheques WHERE uid = ?', [record.cheque_uid]); cq = c ? c.cheque_no : null; }
      shop = shopOf(record.shop_code || invoiceShopOfPayment(record.uid));
    }
  } else if (ph.ref_type === 'deposit' || ph.ref_type === 'till') {
    record = one(`SELECT * FROM ${ph.ref_type === 'deposit' ? 'deposits' : 'till_counts'} WHERE uid = ?`, [ph.ref_id]);
    if (record) shop = shopOf(record.shop_code);
  } else {
    record = one('SELECT * FROM cheques WHERE uid = ?', [ph.ref_id]);
    if (record) {
      const pay = record.payment_uid ? one('SELECT uid, shop_code FROM ap_payments WHERE uid = ?', [record.payment_uid]) : null;
      shop = shopOf(record.shop_code || (pay && pay.shop_code) || invoiceShopOfPayment(record.payment_uid));
    }
  }
  if (!record) return null;
  const n = one('SELECT COUNT(*) AS n FROM photos WHERE ref_type = ? AND ref_id = ? AND id <= ?', [ph.ref_type, ph.ref_id, ph.id]);
  return photoPlace({ refType: ph.ref_type, record, shop, chequeNo: cq, page: n ? n.n : 1, ext });
}

// A payslip copy kept in Drive: Records › "2026-10 October" › Payslips › "2026-10 Week ending 2026-10-17 - Ana - Payslip.pdf".
export function payslipPlace({ weekEnd, name, version = 1 } = {}) {
  const monthFolder = monthFolderOf(weekEnd);
  if (!monthFolder) return null;
  const end = String(weekEnd).slice(0, 10);
  let who = cleanPart(name) || 'Staff';
  const tail = Number(version) > 1 ? 'Payslip (corrected)' : 'Payslip';
  const build = () => `${end.slice(0, 7)} Week ending ${end} - ${who} - ${tail}`;
  if (build().length > NAME_LIMIT) who = who.slice(0, Math.max(1, who.length - (build().length - NAME_LIMIT))).trim();
  return { fileName: `${build().slice(0, NAME_LIMIT)}.pdf`, monthFolder, shopFolder: '', typeFolder: 'Payslips' };
}

// Documents the app makes and keeps in Drive, each kind in its own folder in the month (names without the extension;
// the cloud adds .pdf / .xlsx):
//   Purchase orders › "PO 0123 - Bijay - Week 2 (2026-11-09)"  (week of the month: days 1–7 = week 1, 8–14 = week 2 …)
//   Shift reports   › "2026-10-14 Shift report - Bakery - SH-0042"  ("<date> <Kind> - <party> - <number>")
export function poPlace({ poNo, supplier, date } = {}) {
  const monthFolder = monthFolderOf(date);
  if (!monthFolder) return null;
  const day = String(date).slice(0, 10);
  const no = cleanPart(String(poNo || '').replace(/^\s*PO[\s#:_-]*/i, ''));
  const week = Math.ceil(Number(day.slice(8, 10)) / 7);
  let who = cleanPart(supplier);
  const build = () => [no ? `PO ${no}` : 'PO', who, `Week ${week} (${day})`].filter(Boolean).join(' - ');
  if (build().length > NAME_LIMIT && who) who = who.slice(0, Math.max(1, who.length - (build().length - NAME_LIMIT))).trim();
  return { fileName: build().slice(0, NAME_LIMIT), monthFolder, shopFolder: '', typeFolder: 'Purchase orders' };
}
export function docPlace({ date, kind, party, number, typeFolder } = {}) {
  const monthFolder = monthFolderOf(date);
  if (!monthFolder || !kind) return null;
  let who = cleanPart(party);
  const build = () => [`${String(date).slice(0, 10)} ${cleanPart(kind)}`, who, cleanPart(number)].filter(Boolean).join(' - ');
  if (build().length > NAME_LIMIT && who) who = who.slice(0, Math.max(1, who.length - (build().length - NAME_LIMIT))).trim();
  return { fileName: build().slice(0, NAME_LIMIT), monthFolder, shopFolder: '', typeFolder: cleanPart(typeFolder || `${kind}s`) };
}
