// 1.0.0 build 1: PINs are kept as a slow hash with a salt per person, and never sent anywhere in plain text.
//  pin_hash = "p2:<length>:<tag>:<salt>:<iterations>:<PBKDF2-SHA256>" – the same as the cloud (cloud/Code.gs pinHash_).
//  tag = one hex letter of sha256(business salt : PIN), so the PIN pad only has to try the few people it may be.
//  The business salt comes from the cloud (given only to linked devices); a device makes its own until it hears it.
//  Logging in checks the hash only (no plain PIN is ever compared). The cloud also checks the person: at login the app
//  works out a "proof" of the PIN (a different PBKDF2) and asks the cloud for a session (platform/cloud.js) – the proof
//  is never kept, except, for a PIN just set, until the cloud has it (users.pin_proof, cleared after sending).
//  The plain PIN column stays on the device where it was typed only (older screens and the practice logins use it); it
//  is never synced, backed up, put in the change history or the Deleted bin.
import { db, withSystem } from '../db/connection.js';
import { getSetting, setSetting } from './core.js';
import { sha256Bytes, sha256Text, utf8Bytes } from './sha256.js';

export const PIN_RE = /^\d{4,6}$/;
export const PIN_ITER = 2000;
const HASH_RE = /^p2:(\d):([0-9a-f]):([0-9a-f]{16}):(\d+):([0-9a-f]{64})$/;
const SALT_RE = /^[A-Za-z0-9-]{16,80}$/;

function hex(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 1) s += (bytes[i] & 255).toString(16).padStart(2, '0'); return s; }
function hexBytes(h) { const out = new Uint8Array(h.length / 2); for (let i = 0; i < out.length; i += 1) out[i] = parseInt(h.substr(i * 2, 2), 16); return out; }
function randomHex(n) {
  try {
    const c = (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.getRandomValues) ? globalThis.crypto : null;
    if (c) { const a = new Uint8Array(n); c.getRandomValues(a); return hex(a); }
  } catch (e) { /* below */ }
  const a = new Uint8Array(n); for (let i = 0; i < n; i += 1) a[i] = Math.floor(Math.random() * 256);
  return hex(a);
}
// HMAC-SHA256 with a short key (a PIN), and PBKDF2 with one 32-byte block – the same as the cloud.
function hmacFactory(keyBytes) {
  const k = new Uint8Array(64); k.set(keyBytes.length > 64 ? hexBytes(sha256Bytes(keyBytes)) : keyBytes);
  const ipad = new Uint8Array(64); const opad = new Uint8Array(64);
  for (let i = 0; i < 64; i += 1) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
  return (msg) => {
    const a = new Uint8Array(64 + msg.length); a.set(ipad); a.set(msg, 64);
    const inner = hexBytes(sha256Bytes(a));
    const b = new Uint8Array(96); b.set(opad); b.set(inner, 64);
    return hexBytes(sha256Bytes(b));
  };
}
// Fast PBKDF2 (a tablet must check a PIN in a moment): the HMAC's inner and outer key blocks are worked out once, then
// each round is two SHA-256 blocks on 32-bit words (no strings, no new arrays).
const K256 = new Int32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
const IV = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
const Wb = new Int32Array(64);
// H (8 words) ← compress(H, W[0..15])
function compressW(H, W) {
  for (let i = 16; i < 64; i++) {
    const a = W[i - 15]; const b = W[i - 2];
    W[i] = (W[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + W[i - 7] + (((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10))) | 0;
  }
  let a = H[0]; let b = H[1]; let c = H[2]; let d = H[3]; let e = H[4]; let f = H[5]; let g = H[6]; let h = H[7];
  for (let i = 0; i < 64; i++) {
    const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + K256[i] + W[i]) | 0;
    const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
    h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
  }
  H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
  H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
}
function blockState(bytes64) { const H = Int32Array.from(IV); for (let i = 0; i < 16; i++) { const j = i * 4; Wb[i] = (bytes64[j] << 24) | (bytes64[j + 1] << 16) | (bytes64[j + 2] << 8) | bytes64[j + 3]; } compressW(H, Wb); return H; }
// HMAC of a 32-byte message given as 8 words, from the key's prepared states → 8 words
function hmac32(inS, outS, msgW, out) {
  const H = Int32Array.from(inS);
  for (let i = 0; i < 8; i++) Wb[i] = msgW[i];
  Wb[8] = 0x80000000 | 0; for (let i = 9; i < 15; i++) Wb[i] = 0; Wb[15] = (64 + 32) * 8;
  compressW(H, Wb);
  const O = Int32Array.from(outS);
  for (let i = 0; i < 8; i++) Wb[i] = H[i];
  Wb[8] = 0x80000000 | 0; for (let i = 9; i < 15; i++) Wb[i] = 0; Wb[15] = (64 + 32) * 8;
  compressW(O, Wb);
  for (let i = 0; i < 8; i++) out[i] = O[i];
}
export function pbkdf2(password, salt, iter = PIN_ITER) {
  const keyBytes = utf8Bytes(String(password));
  const k = new Uint8Array(64); k.set(keyBytes.length > 64 ? hexBytes(sha256Bytes(keyBytes)) : keyBytes);
  const ip = new Uint8Array(64); const op = new Uint8Array(64);
  for (let i = 0; i < 64; i++) { ip[i] = k[i] ^ 0x36; op[i] = k[i] ^ 0x5c; }
  const inS = blockState(ip); const outS = blockState(op);
  // the first round: HMAC(salt || 00000001) – any length, done the plain way
  const mac = hmacFactory(keyBytes);
  const s = utf8Bytes(String(salt));
  const first = new Uint8Array(s.length + 4); first.set(s); first[s.length + 3] = 1;
  const u0 = mac(first);
  const U = new Int32Array(8); const T = new Int32Array(8);
  for (let i = 0; i < 8; i++) { U[i] = (u0[i * 4] << 24) | (u0[i * 4 + 1] << 16) | (u0[i * 4 + 2] << 8) | u0[i * 4 + 3]; T[i] = U[i]; }
  for (let r = 1; r < iter; r++) { hmac32(inS, outS, U, U); for (let i = 0; i < 8; i++) T[i] ^= U[i]; }
  let out = '';
  for (let i = 0; i < 8; i++) out += (T[i] >>> 0).toString(16).padStart(8, '0');
  return out;
}

// The business salt this device uses now (made here until the cloud's arrives).
export function pinSalt({ make = true } = {}) {
  let s = '';
  try { s = String(getSetting('pin_salt', '') || ''); } catch (e) { s = ''; }
  if (SALT_RE.test(s)) return s;
  if (!make) return null;
  s = `L-${randomHex(24)}`;
  try { setSetting('pin_salt', s); } catch (e) { return null; }
  return s;
}
export function oldSalts() {
  try { const l = JSON.parse(getSetting('pin_salt_old', '[]') || '[]'); return Array.isArray(l) ? l.filter((x) => SALT_RE.test(String(x))) : []; } catch (e) { return []; }
}
const tagOf = (pin, salt) => sha256Text(`${salt}:${pin}`).charAt(0);
export function hashPin(pin, { salt = pinSalt(), userSalt = randomHex(8) } = {}) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  if (!PIN_RE.test(p) || !salt) return null;
  return `p2:${p.length}:${tagOf(p, salt)}:${userSalt}:${PIN_ITER}:${pbkdf2(p, userSalt, PIN_ITER)}`;
}
// The proof the cloud checks at login (never kept on a device, never in the spreadsheet).
export function pinProof(pin, uid, salt = pinSalt()) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  if (!PIN_RE.test(p) || !uid || !salt) return null;
  return pbkdf2(p, `proof|${uid}|${salt}`, PIN_ITER);
}
export function pinLength(u) {
  if (!u) return 0;
  const m = HASH_RE.exec(String(u.pin_hash || ''));
  if (m) return Number(m[1]);
  return u.pin ? String(u.pin).length : 0;
}
export function hasPin(u) { return !!(u && HASH_RE.test(String(u.pin_hash || ''))); }
// Does this PIN belong to this person? Only the hash is checked.
export function pinMatches(pin, u) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  const m = u && HASH_RE.exec(String(u.pin_hash || ''));
  if (!m || !PIN_RE.test(p) || Number(m[1]) !== p.length) return false;
  return pbkdf2(p, m[3], Number(m[4]) || PIN_ITER) === m[5];
}
function hasHashCol() { try { return db().all('PRAGMA table_info(users)').some((c) => c.name === 'pin_hash'); } catch (e) { return false; } }
// The people this PIN may belong to (same length, same tag under any salt this device knows), then the slow check.
function candidates(p, extraWhere = '', args = []) {
  if (!PIN_RE.test(p) || !hasHashCol()) return [];
  const tags = Array.from(new Set([pinSalt()].concat(oldSalts()).filter(Boolean).map((s) => tagOf(p, s))));
  if (!tags.length) return [];
  return db().all(`SELECT * FROM users WHERE pin_hash LIKE 'p2:%' AND substr(pin_hash, 4, 1) = ? AND substr(pin_hash, 6, 1) IN (${tags.map(() => '?').join(',')})${extraWhere} ORDER BY id`,
    [String(p.length)].concat(tags, args));
}
// The active person with this PIN (or null).
export function findByPin(pin, { roles } = {}) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  const roleSql = roles && roles.length ? ` AND role IN (${roles.map(() => '?').join(',')})` : '';
  for (const u of candidates(p, ` AND active = 1${roleSql}`, roles || [])) if (pinMatches(p, u)) return u;
  return null;
}
// Is this PIN used by another active person? → { id, name } or null
export function pinTaken(pin, exceptId = 0) {
  const p = String(pin === undefined || pin === null ? '' : pin).trim();
  for (const u of candidates(p, ' AND active = 1 AND id <> ?', [Number(exceptId) || 0])) if (pinMatches(p, u)) return u;
  return null;
}

// Every PIN this device still knows in plain gets its hash (an upgrade from before 1.0.0 build 1). Not sent again: the
// cloud hashes plain PINs it already holds itself. → how many were hashed
export function migratePins({ force = false } = {}) {
  const s = pinSalt();
  if (!s || !hasHashCol()) return 0;
  const missing = "pin IS NOT NULL AND pin <> '' AND (pin_hash IS NULL OR pin_hash = '')";
  const all = force || getSetting('pins_hashed_with', '') !== s;
  if (!all && !db().get(`SELECT 1 AS x FROM users WHERE ${missing} LIMIT 1`)) return 0;
  let n = 0;
  withSystem(() => {
    for (const u of db().all(`SELECT id, pin, pin_hash FROM users WHERE ${all ? "pin IS NOT NULL AND pin <> ''" : missing}`)) {
      // already hashed with this salt (its tag fits): left as it is – no slow check needed
      if (HASH_RE.test(String(u.pin_hash || '')) && Number(String(u.pin_hash).charAt(3)) === String(u.pin).length && tagOf(String(u.pin), s) === String(u.pin_hash).charAt(5)) continue;
      const h = hashPin(u.pin, { salt: s });
      if (h) { db().run('UPDATE users SET pin_hash = ? WHERE id = ?', [h, u.id]); n += 1; }
    }
  });
  setSetting('pins_hashed_with', s);
  return n;
}
// The cloud told us the business salt. Ours (if different) is kept for finding people by the hashes made with it.
export function adoptCloudSalt(cloudSalt) {
  const c = String(cloudSalt || '');
  if (!SALT_RE.test(c)) return false;
  const cur = pinSalt({ make: false });
  if (cur === c) return false;
  if (cur) setSetting('pin_salt_old', JSON.stringify([cur].concat(oldSalts().filter((x) => x !== cur && x !== c)).slice(0, 5)));
  setSetting('pin_salt', c);
  migratePins({ force: true });
  return true;
}
// A users record arriving from the cloud: a plain PIN (an old cloud script) becomes its hash; the plain PIN is dropped.
export function incomingUser(row) {
  if (!row || typeof row !== 'object') return row;
  if (row.pin !== undefined && row.pin !== null && String(row.pin) !== '' && !row.pin_hash) row.pin_hash = hashPin(row.pin);
  delete row.pin;
  return row;
}

// ---------------------------------------------------------------- the person, checked by the cloud
// At login the proof of the PIN typed is kept in memory only, until the cloud has turned it into a session.
let pendingLogin = null;
let session = null;
export function noteLogin(user, pin) {
  pendingLogin = null; session = null;
  try { const proof = user && user.uid ? pinProof(pin, user.uid) : null; if (proof) pendingLogin = { uid: user.uid, proof, role: user.role }; } catch (e) { pendingLogin = null; }
}
export function takePendingLogin() { return pendingLogin; }
export function setCloudSession(uid, token, until) { session = token ? { uid, token, until } : null; if (token) pendingLogin = null; }
export function cloudSession(uid) { return session && (!uid || session.uid === uid) && (!session.until || Date.parse(session.until) > Date.now()) ? session.token : null; }
export function clearCloudSession() { session = null; pendingLogin = null; }
