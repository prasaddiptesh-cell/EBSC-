// Daily production plan (targets per product) and progress against it.
import { db } from '../db/connection.js';
import { AppError, stamp, r3, r1, dateStr, getSetting, setSetting, fmt } from './core.js';
import { raiseAlert } from './stock.js';

export function getPlan(date) {
  return db().all(
    `SELECT pp.*, p.name, p.unit FROM production_plan pp JOIN products p ON p.id = pp.product_id WHERE pp.plan_date = ? ORDER BY p.name`, [date]
  );
}

// items: { [productId]: qty }  (0 or empty removes the product from the plan)
export function savePlan(userId, date, items) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date))) throw new AppError('Invalid date.');
  return db().transaction(() => {
    db().run('DELETE FROM production_plan WHERE plan_date = ?', [date]);
    for (const [pid, q] of Object.entries(items || {})) {
      if (q === null || q === undefined || q === '') continue;
      const n = Number(q);
      if (!Number.isFinite(n) || n < 0) throw new AppError('Planned quantities cannot be negative.');
      if (n === 0) continue;
      db().run('INSERT INTO production_plan (plan_date, product_id, qty, updated_by, updated_at) VALUES (?, ?, ?, ?, ?)', [date, Number(pid), r3(n), userId, stamp()]);
    }
    return getPlan(date);
  });
}

// A plan changed on the online dashboard: { seq, date, items: { productId: qty }, by, at }.
// Products that no longer exist on the tablet are ignored. The supervisor gets an info alert.
export function applyOnlinePlan(edit) {
  if (!edit || !/^\d{4}-\d{2}-\d{2}$/.test(String(edit.date))) return false;
  const items = {};
  for (const [pid, q] of Object.entries(edit.items || {})) {
    const p = db().get('SELECT id FROM products WHERE id = ?', [Number(pid)]);
    const n = Number(q);
    if (p && Number.isFinite(n) && n >= 0) items[p.id] = n;
  }
  db().transaction(() => {
    savePlan(null, edit.date, items);
    const list = getPlan(edit.date);
    raiseAlert({
      type: 'PLAN', severity: 'info',
      message: `Production plan for ${edit.date} changed online${edit.by ? ` by ${edit.by}` : ''}: ${list.length ? list.map((x) => `${x.name} ${fmt(x.qty)}`).join(', ') : 'nothing planned'}`,
    });
  });
  return true;
}
export function planSeq() {
  return Number(getSetting('plan_seq', '0')) || 0;
}
export function applyOnlinePlans(edits) {
  const list = (edits || []).slice().sort((a, b) => a.seq - b.seq);
  let n = 0;
  for (const e of list) {
    if (applyOnlinePlan(e)) n += 1;
    setSetting('plan_seq', String(e.seq));
  }
  return n;
}

export function copyPlan(userId, fromDate, toDate) {
  const src = getPlan(fromDate);
  if (!src.length) throw new AppError(`There is no plan on ${fromDate} to copy.`);
  const items = {};
  src.forEach((p) => { items[p.product_id] = p.qty; });
  return savePlan(userId, toDate, items);
}

// Plan vs actual (good production from batches started that day).
export function planProgress(date = dateStr()) {
  const plan = getPlan(date);
  const made = {};
  db().all(
    `SELECT product_id, SUM(COALESCE(good,0)) AS good, SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) AS active, SUM(CASE WHEN status='active' THEN expected_pieces ELSE 0 END) AS in_progress
     FROM batches WHERE substr(started_at,1,10) = ? GROUP BY product_id`, [date]
  ).forEach((r) => { made[r.product_id] = r; });
  const rows = plan.map((p) => {
    const m = made[p.product_id] || { good: 0, active: 0, in_progress: 0 };
    return { product_id: p.product_id, name: p.name, unit: p.unit, target: p.qty, good: m.good || 0, inProgress: m.in_progress || 0,
      remaining: Math.max(0, r3(p.qty - (m.good || 0))), pct: p.qty ? r1(((m.good || 0) / p.qty) * 100) : null };
  });
  // Products made but not on the plan
  Object.entries(made).forEach(([pid, m]) => {
    if (!plan.find((p) => p.product_id === Number(pid))) {
      const pr = db().get('SELECT name, unit FROM products WHERE id = ?', [Number(pid)]);
      rows.push({ product_id: Number(pid), name: pr.name, unit: pr.unit, target: 0, good: m.good || 0, inProgress: m.in_progress || 0, remaining: 0, pct: null, unplanned: true });
    }
  });
  return rows;
}
