// v3.9.8 Aronium product watch. Each time a till PC sends its product list (Aronium Link), every change is kept per
// product and shop: new, renamed, selling price, cost, tax (VAT), barcodes, disabled / removed. The app never writes
// to Aronium – the warnings say what to change there. The first list of a shop is only remembered (no flood).
import { db, tableVersion, keepUntilChanged, noteDeps } from '../db/connection.js';
import { stamp, uuid, deviceId, dateStr, addDays } from './core.js';
import { requirePerm, asService } from './guard.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const WATCH_SQL = `
CREATE TABLE IF NOT EXISTS product_watch (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  code TEXT NOT NULL,
  snap TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pw_shop ON product_watch(shop_code);
CREATE TABLE IF NOT EXISTS product_changes (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  code TEXT,
  name TEXT,
  kind TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  change_date TEXT NOT NULL,
  at TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pc_date ON product_changes(change_date, shop_code);
`;
export const WATCH_SYNC = {
  product_changes: { key: 'uid', section: 'Inventory', cols: ['uid', 'shop_code', 'code', 'name', 'kind', 'old_value', 'new_value', 'change_date', 'at', 'updated_at', 'updated_device'] },
};
export const CHANGE_LABEL = { new: 'New product', name: 'Name changed', price: 'Selling price changed', cost: 'Cost changed', tax: 'Tax (VAT) changed', barcode: 'Barcodes changed', off: 'Disabled', on: 'Enabled again', removed: 'Removed from Aronium' };

const taxText = (v) => (v === null || v === undefined ? 'No tax set' : Number(v) > 0 ? `VAT ${Number(v)}%` : '0% (zero rated)');
const snapOf = (p) => ({ name: txt(p.name), price: r2(p.price), cost: r2(p.cost), tax: p.vat_rate === null || p.vat_rate === undefined ? null : Number(p.vat_rate), barcodes: (p.barcodes || []).map(String).sort().join(','), on: p.enabled !== false, service: !!p.service });

// Compare one shop's list from Aronium with what was seen last time; keep the changes. → [{ kind, code, name, old, new }]
export function watchProducts(shopCode, items, today = dateStr()) {
  if (!has('product_watch') || !Array.isArray(items) || !shopCode) return [];
  const before = new Map(db().all('SELECT code, snap FROM product_watch WHERE shop_code = ?', [shopCode]).map((r) => [r.code, J(r.snap, {})]));
  const first = before.size === 0;
  const now = stamp(); const dev = deviceId();
  const changes = [];
  const seen = new Set();
  const add = (kind, code, name, oldV, newV) => changes.push({ kind, code, name, old: oldV === undefined || oldV === null ? null : String(oldV), new: newV === undefined || newV === null ? null : String(newV) });
  for (const p of items) {
    const code = txt(p.code);
    if (!code || !txt(p.name)) continue;
    seen.add(code);
    const s = snapOf(p);
    const b = before.get(code);
    if (!first) {
      if (!b) add('new', code, s.name, null, `${s.name} $${s.price.toFixed(2)}`);
      else {
        if (b.name !== s.name) add('name', code, s.name, b.name, s.name);
        if (r2(b.price) !== s.price) add('price', code, s.name, r2(b.price).toFixed(2), s.price.toFixed(2));
        if (r2(b.cost) !== s.cost) add('cost', code, s.name, r2(b.cost).toFixed(2), s.cost.toFixed(2));
        if ((b.tax === null ? null : Number(b.tax)) !== s.tax) add('tax', code, s.name, taxText(b.tax), taxText(s.tax));
        if ((b.barcodes || '') !== s.barcodes) add('barcode', code, s.name, b.barcodes || '(none)', s.barcodes || '(none)');
        if (b.on && !s.on) add('off', code, s.name, null, null);
        if (!b.on && s.on) add('on', code, s.name, null, null);
      }
    }
    if (!b || JSON.stringify(b) !== JSON.stringify(s)) {
      db().run(`INSERT INTO product_watch (uid, shop_code, code, snap, updated_at, updated_device) VALUES (?,?,?,?,?,?)
        ON CONFLICT(uid) DO UPDATE SET snap = excluded.snap, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`, [`${shopCode}|${code}`, shopCode, code, JSON.stringify(s), now, dev]);
    }
  }
  if (!first) {
    for (const [code, b] of before) {
      if (seen.has(code) || b.removed) continue;
      add('removed', code, b.name, null, null);
      db().run("UPDATE product_watch SET snap = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [JSON.stringify({ ...b, removed: true, on: false }), now, dev, `${shopCode}|${code}`]);
    }
  }
  for (const c of changes) {
    db().run('INSERT INTO product_changes (uid, shop_code, code, name, kind, old_value, new_value, change_date, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [uuid('PC'), shopCode, c.code, c.name, c.kind, c.old, c.new, today, now, now, dev]);
  }
  if (changes.length) {
    const price = changes.filter((c) => c.kind === 'price');
    const text = `🏷️ Aronium products changed at ${shopCode}: ${changes.length} change${changes.length === 1 ? '' : 's'}${price.length ? ` (${price.length} price${price.length === 1 ? '' : 's'}: ${price.slice(0, 3).map((c) => `${c.name} $${c.old} → $${c.new}`).join(', ')}${price.length > 3 ? ' …' : ''})` : ''}.`;
    try { require('../modules/verify/service.js').notify('product_change', text, { shopCode }); } catch (e) { /* Viber is optional */ }
  }
  return changes;
}

export function listChanges({ from, to, shopCode, kind, limit = 500 } = {}) {
  if (!has('product_changes')) return [];
  const w = ['1=1']; const a = [];
  if (from) { w.push('change_date >= ?'); a.push(from); }
  if (to) { w.push('change_date <= ?'); a.push(to); }
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (kind) { w.push('kind = ?'); a.push(kind); }
  return db().all(`SELECT * FROM product_changes WHERE ${w.join(' AND ')} ORDER BY at DESC LIMIT ?`, a.concat([limit]));
}

// 1.0.0 the owner's rules for the warnings: the lowest margin (% of the selling price) before a warning; 0 = off.
export const MARGIN_CHOICES = [0, 5, 10, 15, 20, 25, 30];
export function watchRules() {
  let s = null;
  try { s = require('./core.js').getShared('product_watch_rules', null); } catch (e) { s = null; }
  const m = s && s.marginPct !== undefined && s.marginPct !== null ? Number(s.marginPct) : NaN;
  return { marginPct: MARGIN_CHOICES.includes(m) ? m : 10 };
}
export function saveWatchRules(user, { marginPct } = {}) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const A = require('./access.js');
  const C = require('./core.js');
  if (!user || !(A.actsAsOwner(user) || ['owner', 'admin'].includes(user.role))) throw new C.AppError('Only the owner or the admin changes the product warnings.');
  const m = Number(marginPct);
  if (!MARGIN_CHOICES.includes(m)) throw new C.AppError('Choose the lowest margin.');
  const before = watchRules();
  C.setShared('product_watch_rules', { marginPct: m });
  C.audit({ user, action: `Product warnings: lowest margin ${m ? `${m}%` : 'off'}`, table: 'shared_settings', recordUid: 'product_watch_rules', before, after: { marginPct: m } });
  return watchRules();
  });
}
const $2 = (n) => `$${r2(n).toFixed(2)}`;
const SHOP = (s) => (s === 'S1' ? 'Shop 1' : s === 'S2' ? 'Shop 2' : s);
// What to change IN ARONIUM for each kind of problem (the app never writes to Aronium).
export const FIX = {
  belowCost: (r) => `In Aronium at ${SHOP(r.shop)}: raise the selling price of ${r.name} above the cost ${$2(r.cost)} (now ${$2(r.price)}) – or correct the cost if it is wrong.`,
  lowMargin: (r, pct) => `In Aronium at ${SHOP(r.shop)}: ${r.name} makes only ${r.margin}% (price ${$2(r.price)}, cost ${$2(r.cost)}). Raise the price to at least ${$2(r.cost / (1 - pct / 100))} for ${pct}%.`,
  noPrice: (r) => `In Aronium at ${SHOP(r.shop)}: type a selling price for ${r.name} (Management › Products › ${r.name} › Price).`,
  noBarcode: (r) => `In Aronium at ${SHOP(r.shop)}: scan the barcode into ${r.name} (Management › Products › Barcodes), so the till scans it.`,
  noTax: (r) => `In Aronium at ${SHOP(r.shop)}: set the tax of ${r.name} – VAT 12.5% or the 0% zero-rated tax. A blank tax is NOT zero-rated.`,
  shopsDiffer: (x) => `In Aronium: ${x.name} is ${x.prices.map((q) => `${$2(q.price)} at ${SHOP(q.shop)}`).join(' but ')}. Change one shop's price so both match (or keep it if that is meant).`,
  costUp: (c) => `In Aronium: the cost of ${c.name} went up ${$2(c.old_cost)} → ${$2(c.new_cost)} on ${c.change_date}, the selling price did not change. Raise the selling price in Aronium?`,
};

// What to fix in Aronium, from the latest lists of each shop.
// 1.0.0 the latest list of each shop's products as Aronium sent it, read and unpacked once until it changes (product
// problems, the price checks and the month report all read it); each caller gets its own copies.
export function watchRows() {
  return keepUntilChanged('pw|rows', ['product_watch'], () => db().all('SELECT shop_code, code, snap FROM product_watch').map((r) => ({ shop: r.shop_code, code: r.code, ...J(r.snap, {}) })))
    .map((r) => ({ ...r }));
}
// 1.0.0 "the selling price changed in Aronium on or after this day?" – the newest price change of every product read
// once (was one read per cost change).
function priceChangedSince(code, day) {
  if (code === null || code === undefined || day === null || day === undefined) return !!db().get("SELECT 1 AS x FROM product_changes WHERE code = ? AND kind = 'price' AND change_date >= ?", [code, day]);
  if (!priceChangedSince.map || priceChangedSince.db !== db() || priceChangedSince.ver !== tableVersion(['product_changes'])) {
    priceChangedSince.map = new Map(db().all("SELECT code, MAX(change_date) AS d FROM product_changes WHERE kind = 'price' AND change_date IS NOT NULL GROUP BY code").map((r) => [String(r.code), r.d]));
    priceChangedSince.db = db(); priceChangedSince.ver = tableVersion(['product_changes']);
  }
  noteDeps(['product_changes']);
  const k = String(code);
  if (!priceChangedSince.map.has(k)) return false; // no dated price change of this product at all
  const d = priceChangedSince.map.get(k);
  return typeof d === 'string' && typeof day === 'string' ? d >= day : !!db().get("SELECT 1 AS x FROM product_changes WHERE code = ? AND kind = 'price' AND change_date >= ?", [code, day]);
}
export function productProblems({ marginPct } = {}) {
  if (marginPct === undefined) marginPct = watchRules().marginPct;
  if (!has('product_watch')) return { belowCost: [], lowMargin: [], noPrice: [], noTax: [], noBarcode: [], shopsDiffer: [], costUp: [] };
  const rows = watchRows().filter((r) => r.on && !r.removed && !r.service);
  const belowCost = rows.filter((r) => r.cost > 0 && r.price > 0 && r.price < r.cost);
  const lowMargin = marginPct > 0 ? rows.filter((r) => r.cost > 0 && r.price >= r.cost && ((r.price - r.cost) / r.price) * 100 < marginPct).map((r) => ({ ...r, margin: Math.round(((r.price - r.cost) / r.price) * 1000) / 10 })) : [];
  const noPrice = rows.filter((r) => !(r.price > 0));
  // a blank tax is never zero-rated: it is "no tax set" and must be set in Aronium
  const noTax = rows.filter((r) => r.tax === null || r.tax === undefined);
  // 1.0.0 no barcode (bakery items and things sold by weight are often keyed in – they are still listed, as info)
  const noBarcode = rows.filter((r) => !txt(r.barcodes));
  const byCode = {};
  rows.forEach((r) => { (byCode[r.code] = byCode[r.code] || []).push(r); });
  const shopsDiffer = Object.values(byCode).filter((l) => l.length > 1 && new Set(l.map((x) => r2(x.price))).size > 1).map((l) => ({ code: l[0].code, name: l[0].name, prices: l.map((x) => ({ shop: x.shop, price: x.price })) }));
  // A supplier's cost went up (invoice / delivery in the app) since the selling price last changed in Aronium.
  let costUp = [];
  try {
    costUp = db().all("SELECT c.item_uid, c.change_date, c.old_cost, c.new_cost, i.code, i.name FROM inv_cost_changes c JOIN inv_items i ON i.uid = c.item_uid WHERE c.new_cost > c.old_cost AND c.change_date >= ? ORDER BY c.change_date DESC, c.rowid", [addDays(dateStr(), -60)])
      .filter((c) => !priceChangedSince(c.code, c.change_date))
      .filter((c, i, arr) => arr.findIndex((x) => x.item_uid === c.item_uid) === i);
  } catch (e) { costUp = []; }
  // 1.0.0 also the cost changed IN ARONIUM (a purchase typed there) with no price change after it, per shop
  try {
    const recent = db().all("SELECT shop_code, code, name, old_value, new_value, change_date, at FROM product_changes WHERE kind = 'cost' AND change_date >= ? ORDER BY at DESC", [addDays(dateStr(), -60)]);
    for (const c of recent) {
      if (!(Number(c.new_value) > Number(c.old_value))) continue;
      if (costUp.some((x) => String(x.code) === String(c.code))) continue;
      if (db().get("SELECT 1 AS x FROM product_changes WHERE code = ? AND shop_code = ? AND kind = 'price' AND at >= ?", [c.code, c.shop_code, c.at])) continue;
      costUp.push({ item_uid: null, shop: c.shop_code, code: c.code, name: c.name, change_date: c.change_date, old_cost: Number(c.old_value), new_cost: Number(c.new_value), from: 'Aronium' });
    }
  } catch (e) { /* the app's own cost changes stand */ }
  return { belowCost, lowMargin, noPrice, noTax, noBarcode, shopsDiffer, costUp, marginPct };
}
// 1.0.0 every problem as one list, worst first, each with what to change in Aronium:
// [{ id, kind, level, shop, code, name, text, fix }]
export const PROBLEM_TITLE = { belowCost: 'Priced below cost', lowMargin: 'Margin too low', costUp: 'Cost went up, price did not', noTax: 'No tax set', noPrice: 'No selling price', shopsDiffer: 'Shop 1 and Shop 2 prices differ', noBarcode: 'No barcode' };
export function fixList(p = productProblems()) {
  const out = [];
  const add = (kind, level, x, text) => out.push({ id: `${kind}|${x.shop || ''}|${x.code}`, kind, level, shop: x.shop || null, code: x.code, name: x.name, text, fix: kind === 'lowMargin' ? FIX.lowMargin(x, p.marginPct) : FIX[kind](x) });
  p.belowCost.forEach((r) => add('belowCost', 'danger', r, `${SHOP(r.shop)} · price ${$2(r.price)} · cost ${$2(r.cost)}`));
  p.noTax.forEach((r) => add('noTax', 'danger', r, `${SHOP(r.shop)} · no tax set`));
  p.costUp.forEach((c) => add('costUp', 'warn', c, `cost ${$2(c.old_cost)} → ${$2(c.new_cost)} on ${c.change_date}`));
  p.lowMargin.forEach((r) => add('lowMargin', 'warn', r, `${SHOP(r.shop)} · ${r.margin}% margin`));
  p.noPrice.forEach((r) => add('noPrice', 'warn', r, SHOP(r.shop)));
  p.shopsDiffer.forEach((x) => add('shopsDiffer', 'info', x, x.prices.map((q) => `${SHOP(q.shop)} ${$2(q.price)}`).join(' · ')));
  p.noBarcode.forEach((r) => add('noBarcode', 'info', r, SHOP(r.shop)));
  return out;
}
// Home: a short daily summary and the warnings (owner / admin / whoever manages products).
export function watchAlerts(user, today = dateStr()) {
  const A = require('./access.js');
  if (!user || !(A.actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || A.can(user, 'inventory_manage'))) return [];
  const out = [];
  const ch = listChanges({ from: addDays(today, -1), to: today, limit: 2000 });
  if (ch.length) {
    const price = ch.filter((c) => c.kind === 'price').length;
    out.push({ id: `pw-day-${today}-${ch.length}`, level: 'info', text: `Aronium: ${ch.length} product change${ch.length === 1 ? '' : 's'} since yesterday${price ? ` (${price} price${price === 1 ? '' : 's'})` : ''}`, nav: { screen: 'ArProducts', params: { tab: 'changes' } } });
  }
  let p = null;
  try { p = productProblems(); } catch (e) { p = null; }
  if (p) {
    // 1.0.0 each warning says what to change IN ARONIUM (the first one in full), and opens Aronium › Products to fix
    const nav = (kind) => ({ screen: 'ArProducts', params: { kind } });
    const s = (n, one, many) => `${n} product${n === 1 ? one : many}`;
    if (p.belowCost.length) out.push({ id: `pw-below-${p.belowCost.length}`, level: 'warning', notify: true, text: `${s(p.belowCost.length, ' is', 's are')} priced below cost in Aronium`, sub: `${p.belowCost.slice(0, 3).map((r) => `${r.shop} ${r.name} $${r2(r.price).toFixed(2)} (cost $${r2(r.cost).toFixed(2)})`).join(' · ')}. ${FIX.belowCost(p.belowCost[0])}`, nav: nav('belowCost') });
    if (p.noTax.length) out.push({ id: `pw-notax-${p.noTax.length}`, level: 'warning', notify: true, text: `${s(p.noTax.length, ' has', 's have')} no tax set in Aronium – fix in Aronium`, sub: `${p.noTax.slice(0, 3).map((r) => `${r.shop} ${r.name}`).join(' · ')}. ${FIX.noTax(p.noTax[0])}`, nav: nav('noTax') });
    if (p.costUp.length) out.push({ id: `pw-costup-${p.costUp.length}`, level: 'warning', notify: true, text: `${s(p.costUp.length, '', 's')}: cost went up but the selling price did not`, sub: `${p.costUp.slice(0, 3).map((c) => `${c.name} cost $${r2(c.old_cost).toFixed(2)} → $${r2(c.new_cost).toFixed(2)}`).join(' · ')}. ${FIX.costUp(p.costUp[0])}`, nav: nav('costUp') });
    if (p.lowMargin.length) out.push({ id: `pw-margin-${p.marginPct}-${p.lowMargin.length}`, level: 'warning', text: `${s(p.lowMargin.length, ' makes', 's make')} less than ${p.marginPct}% in Aronium`, sub: FIX.lowMargin(p.lowMargin[0], p.marginPct), nav: nav('lowMargin') });
    if (p.noPrice.length) out.push({ id: `pw-noprice-${p.noPrice.length}`, level: 'info', text: `${s(p.noPrice.length, ' has', 's have')} no selling price in Aronium`, sub: FIX.noPrice(p.noPrice[0]), nav: nav('noPrice') });
    if (p.shopsDiffer.length) out.push({ id: `pw-differ-${p.shopsDiffer.length}`, level: 'info', text: `${s(p.shopsDiffer.length, ' is', 's are')} priced differently in Shop 1 and Shop 2`, sub: FIX.shopsDiffer(p.shopsDiffer[0]), nav: nav('shopsDiffer') });
    if (p.noBarcode.length) out.push({ id: `pw-nobarcode-${p.noBarcode.length}`, level: 'info', text: `${s(p.noBarcode.length, ' has', 's have')} no barcode in Aronium`, sub: FIX.noBarcode(p.noBarcode[0]), nav: nav('noBarcode') });
  }
  return out;
}
