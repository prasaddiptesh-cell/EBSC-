// v3.9.8 Aronium product watch. Each time a till PC sends its product list (Aronium Link), every change is kept per
// product and shop: new, renamed, selling price, cost, tax (VAT), barcodes, disabled / removed. The app never writes
// to Aronium – the warnings say what to change there. The first list of a shop is only remembered (no flood).
import { db } from '../db/connection.js';
import { stamp, uuid, deviceId, dateStr, addDays } from './core.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export const WATCH_SQL = `
CREATE TABLE IF NOT EXISTS product_watch (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  code TEXT NOT NULL,
  snap TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pw_shop ON product_watch(shop_code);
CREATE TABLE IF NOT EXISTS product_changes (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  code TEXT,
  name TEXT,
  kind TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  change_date TEXT NOT NULL,
  at TEXT NOT NULL,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_pc_date ON product_changes(change_date, shop_code);
`;
export const WATCH_SYNC = {
  product_changes: { key: 'uid', section: 'Inventory', cols: ['uid', 'shop_code', 'code', 'name', 'kind', 'old_value', 'new_value', 'change_date', 'at', 'updated_at', 'updated_device'] },
};
export const CHANGE_LABEL = { new: 'New product', name: 'Name changed', price: 'Selling price changed', cost: 'Cost changed', tax: 'Tax (VAT) changed', barcode: 'Barcodes changed', off: 'Disabled', on: 'Enabled again', removed: 'Removed from Aronium' };

const taxText = (v) => (v === null || v === undefined ? 'No tax set' : Number(v) > 0 ? `VAT ${Number(v)}%` : '0% (zero rated)');
const snapOf = (p) => ({ name: txt(p.name), price: r2(p.price), cost: r2(p.cost), tax: p.vat_rate === null || p.vat_rate === undefined ? null : Number(p.vat_rate), barcodes: (p.barcodes || []).map(String).sort().join(','), on: p.enabled !== false, service: !!p.service });

// Compare one shop's list from Aronium with what was seen last time; keep the changes. → [{ kind, code, name, old, new }]
export function watchProducts(shopCode, items, today = dateStr()) {
  if (!has('product_watch') || !Array.isArray(items) || !shopCode) return [];
  const before = new Map(db().all('SELECT code, snap FROM product_watch WHERE shop_code = ?', [shopCode]).map((r) => [r.code, J(r.snap, {})]));
  const first = before.size === 0;
  const now = stamp(); const dev = deviceId();
  const changes = [];
  const seen = new Set();
  const add = (kind, code, name, oldV, newV) => changes.push({ kind, code, name, old: oldV === undefined || oldV === null ? null : String(oldV), new: newV === undefined || newV === null ? null : String(newV) });
  for (const p of items) {
    const code = txt(p.code);
    if (!code || !txt(p.name)) continue;
    seen.add(code);
    const s = snapOf(p);
    const b = before.get(code);
    if (!first) {
      if (!b) add('new', code, s.name, null, `${s.name} $${s.price.toFixed(2)}`);
      else {
        if (b.name !== s.name) add('name', code, s.name, b.name, s.name);
        if (r2(b.price) !== s.price) add('price', code, s.name, r2(b.price).toFixed(2), s.price.toFixed(2));
        if (r2(b.cost) !== s.cost) add('cost', code, s.name, r2(b.cost).toFixed(2), s.cost.toFixed(2));
        if ((b.tax === null ? null : Number(b.tax)) !== s.tax) add('tax', code, s.name, taxText(b.tax), taxText(s.tax));
        if ((b.barcodes || '') !== s.barcodes) add('barcode', code, s.name, b.barcodes || '(none)', s.barcodes || '(none)');
        if (b.on && !s.on) add('off', code, s.name, null, null);
        if (!b.on && s.on) add('on', code, s.name, null, null);
      }
    }
    if (!b || JSON.stringify(b) !== JSON.stringify(s)) {
      db().run(`INSERT INTO product_watch (uid, shop_code, code, snap, updated_at, updated_device) VALUES (?,?,?,?,?,?)
        ON CONFLICT(uid) DO UPDATE SET snap = excluded.snap, updated_at = excluded.updated_at, updated_device = excluded.updated_device, sync_status = 'pending'`, [`${shopCode}|${code}`, shopCode, code, JSON.stringify(s), now, dev]);
    }
  }
  if (!first) {
    for (const [code, b] of before) {
      if (seen.has(code) || b.removed) continue;
      add('removed', code, b.name, null, null);
      db().run("UPDATE product_watch SET snap = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [JSON.stringify({ ...b, removed: true, on: false }), now, dev, `${shopCode}|${code}`]);
    }
  }
  for (const c of changes) {
    db().run('INSERT INTO product_changes (uid, shop_code, code, name, kind, old_value, new_value, change_date, at, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [uuid('PC'), shopCode, c.code, c.name, c.kind, c.old, c.new, today, now, now, dev]);
  }
  if (changes.length) {
    const price = changes.filter((c) => c.kind === 'price');
    const text = `🏷️ Aronium products changed at ${shopCode}: ${changes.length} change${changes.length === 1 ? '' : 's'}${price.length ? ` (${price.length} price${price.length === 1 ? '' : 's'}: ${price.slice(0, 3).map((c) => `${c.name} $${c.old} → $${c.new}`).join(', ')}${price.length > 3 ? ' …' : ''})` : ''}.`;
    try { require('../modules/verify/service.js').notify('product_change', text, { shopCode }); } catch (e) { /* Viber is optional */ }
  }
  return changes;
}

export function listChanges({ from, to, shopCode, kind, limit = 500 } = {}) {
  if (!has('product_changes')) return [];
  const w = ['1=1']; const a = [];
  if (from) { w.push('change_date >= ?'); a.push(from); }
  if (to) { w.push('change_date <= ?'); a.push(to); }
  if (shopCode) { w.push('shop_code = ?'); a.push(shopCode); }
  if (kind) { w.push('kind = ?'); a.push(kind); }
  return db().all(`SELECT * FROM product_changes WHERE ${w.join(' AND ')} ORDER BY at DESC LIMIT ?`, a.concat([limit]));
}

// What to fix in Aronium, from the latest lists of each shop.
export function productProblems({ marginPct = 0 } = {}) {
  if (!has('product_watch')) return { belowCost: [], lowMargin: [], noPrice: [], noTax: [], shopsDiffer: [], costUp: [] };
  const rows = db().all('SELECT shop_code, code, snap FROM product_watch').map((r) => ({ shop: r.shop_code, code: r.code, ...J(r.snap, {}) })).filter((r) => r.on && !r.removed && !r.service);
  const belowCost = rows.filter((r) => r.cost > 0 && r.price > 0 && r.price < r.cost);
  const lowMargin = marginPct > 0 ? rows.filter((r) => r.cost > 0 && r.price >= r.cost && ((r.price - r.cost) / r.price) * 100 < marginPct) : [];
  const noPrice = rows.filter((r) => !(r.price > 0));
  const noTax = rows.filter((r) => r.tax === null || r.tax === undefined);
  const byCode = {};
  rows.forEach((r) => { (byCode[r.code] = byCode[r.code] || []).push(r); });
  const shopsDiffer = Object.values(byCode).filter((l) => l.length > 1 && new Set(l.map((x) => r2(x.price))).size > 1).map((l) => ({ code: l[0].code, name: l[0].name, prices: l.map((x) => ({ shop: x.shop, price: x.price })) }));
  // A supplier's cost went up (invoice / delivery in the app) since the selling price last changed in Aronium.
  let costUp = [];
  try {
    costUp = db().all("SELECT c.item_uid, c.change_date, c.old_cost, c.new_cost, i.code, i.name FROM inv_cost_changes c JOIN inv_items i ON i.uid = c.item_uid WHERE c.new_cost > c.old_cost AND c.change_date >= ? ORDER BY c.change_date DESC", [addDays(dateStr(), -60)])
      .filter((c) => !db().get("SELECT 1 AS x FROM product_changes WHERE code = ? AND kind = 'price' AND change_date >= ?", [c.code, c.change_date]))
      .filter((c, i, arr) => arr.findIndex((x) => x.item_uid === c.item_uid) === i);
  } catch (e) { costUp = []; }
  return { belowCost, lowMargin, noPrice, noTax, shopsDiffer, costUp };
}
// Home: a short daily summary and the warnings (owner / admin / whoever manages products).
export function watchAlerts(user, today = dateStr()) {
  const A = require('./access.js');
  if (!user || !(A.actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || A.can(user, 'inventory_manage'))) return [];
  const out = [];
  const ch = listChanges({ from: addDays(today, -1), to: today, limit: 2000 });
  if (ch.length) {
    const price = ch.filter((c) => c.kind === 'price').length;
    out.push({ id: `pw-day-${today}-${ch.length}`, level: 'info', text: `Aronium: ${ch.length} product change${ch.length === 1 ? '' : 's'} since yesterday${price ? ` (${price} price${price === 1 ? '' : 's'})` : ''}`, nav: { screen: 'ProductChanges', params: {} } });
  }
  let p = null;
  try { p = productProblems(); } catch (e) { p = null; }
  if (p) {
    if (p.belowCost.length) out.push({ id: `pw-below-${p.belowCost.length}`, level: 'warning', text: `${p.belowCost.length} product${p.belowCost.length === 1 ? ' is' : 's are'} priced below cost in Aronium`, sub: p.belowCost.slice(0, 3).map((r) => `${r.shop} ${r.name} $${r2(r.price).toFixed(2)} (cost $${r2(r.cost).toFixed(2)})`).join(' · '), nav: { screen: 'ProductChanges', params: { tab: 'fix' } } });
    if (p.costUp.length) out.push({ id: `pw-costup-${p.costUp.length}`, level: 'warning', text: `${p.costUp.length} product${p.costUp.length === 1 ? '' : 's'}: cost went up but the selling price did not`, sub: p.costUp.slice(0, 3).map((c) => `${c.name} cost $${r2(c.old_cost).toFixed(2)} → $${r2(c.new_cost).toFixed(2)}`).join(' · '), nav: { screen: 'ProductChanges', params: { tab: 'fix' } } });
    if (p.noPrice.length) out.push({ id: `pw-noprice-${p.noPrice.length}`, level: 'info', text: `${p.noPrice.length} product${p.noPrice.length === 1 ? ' has' : 's have'} no selling price in Aronium`, nav: { screen: 'ProductChanges', params: { tab: 'fix' } } });
    if (p.shopsDiffer.length) out.push({ id: `pw-differ-${p.shopsDiffer.length}`, level: 'info', text: `${p.shopsDiffer.length} product${p.shopsDiffer.length === 1 ? ' is' : 's are'} priced differently in the shops`, nav: { screen: 'ProductChanges', params: { tab: 'fix' } } });
  }
  return out;
}
