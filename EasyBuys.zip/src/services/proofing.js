// Proofing time (v3.5 B7). Each product has a proofing table: yeast amount → minutes; between two rows the minutes are
// worked out in proportion (interpolated). The yeast is measured per kg of flour by default (grams of yeast per kg of
// flour); the admin can switch to "per batch" (grams of yeast in the whole batch). Then a temperature adjustment:
// Hot / Normal / Cool – the admin sets the room temperatures where Hot and Cool start and how many minutes each adds or
// takes off. The proofing step of a new batch gets these minutes (its alarm goes off then).
import { requireSetup } from './access.js';
import { db } from '../db/connection.js';
import { AppError, getShared, setShared, audit, r3 } from './core.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const num = (v) => (v === null || v === undefined || String(v).trim() === '' ? null : Number(v));

export const CLIMATES = { hot: 'Hot', normal: 'Normal', cool: 'Cool' };
export const YEAST_MODES = { per_kg: 'Grams of yeast per kg of flour', per_batch: 'Grams of yeast in the whole batch' };
export const PROOF_DEFAULTS = { yeastMode: 'per_kg', yeastMaterialId: null, stepWord: 'proof', hotFrom: 30, coolBelow: 24, hotMinutes: -10, coolMinutes: 15 };

export function proofSettings() { return { ...PROOF_DEFAULTS, ...(getShared('bakery_proofing', {}) || {}) }; }
export function saveProofSettings(user, s) {
  requireSetup(user, 'bakery');
  const c = { ...proofSettings(), ...s };
  need(YEAST_MODES[c.yeastMode], 'Choose how the yeast is measured.');
  const t = (v, label) => { const n = Number(v); need(Number.isFinite(n) && n >= 0 && n <= 50, `${label}: a temperature between 0 and 50 °C.`); return n; };
  const m = (v, label) => { const n = Math.round(Number(v)); need(Number.isFinite(n) && Math.abs(n) <= 240, `${label}: minutes between −240 and 240.`); return n; };
  const clean = { yeastMode: c.yeastMode, yeastMaterialId: num(c.yeastMaterialId), stepWord: String(c.stepWord || 'proof').trim().toLowerCase() || 'proof',
    hotFrom: t(c.hotFrom, 'Hot from'), coolBelow: t(c.coolBelow, 'Cool below'), hotMinutes: m(c.hotMinutes, 'Hot'), coolMinutes: m(c.coolMinutes, 'Cool') };
  need(clean.coolBelow < clean.hotFrom, '"Cool below" must be lower than "Hot from".');
  const before = proofSettings();
  setShared('bakery_proofing', clean);
  audit({ user, action: 'Changed the proofing settings', table: 'shared_settings', recordUid: 'bakery_proofing', before, after: clean });
  return clean;
}

// ---------------------------------------------------------------- the table per product
export function proofTable(productId) {
  const all = getShared('bakery_proof_tables', {}) || {};
  return (all[String(productId)] || []).slice().sort((a, b) => a.yeast - b.yeast);
}
export function saveProofTable(user, productId, rows) {
  need(productId, 'Choose the product.');
  const clean = (rows || []).filter((r) => String(r.yeast ?? '').trim() !== '' || String(r.minutes ?? '').trim() !== '').map((r) => {
    const y = Number(r.yeast); const mi = Number(r.minutes);
    need(Number.isFinite(y) && y > 0, 'Each row needs the yeast amount (more than 0).');
    need(Number.isFinite(mi) && mi > 0 && mi <= 600, 'Each row needs the proofing minutes (1 to 600).');
    return { yeast: r3(y), minutes: Math.round(mi) };
  }).sort((a, b) => a.yeast - b.yeast);
  for (let i = 1; i < clean.length; i++) need(clean[i].yeast !== clean[i - 1].yeast, `The yeast amount ${clean[i].yeast} is listed twice.`);
  const all = { ...(getShared('bakery_proof_tables', {}) || {}) };
  const before = all[String(productId)] || [];
  if (clean.length) all[String(productId)] = clean; else delete all[String(productId)];
  setShared('bakery_proof_tables', all);
  audit({ user, action: 'Changed a proofing table', table: 'shared_settings', recordUid: `bakery_proof_tables:${productId}`, before, after: clean });
  return clean;
}
// Minutes for a yeast amount: exact row, in proportion between two rows, or the nearest end row outside the table.
export function interpolate(rows, yeast) {
  const t = (rows || []).slice().sort((a, b) => a.yeast - b.yeast);
  if (!t.length || yeast === null || yeast === undefined || !Number.isFinite(Number(yeast))) return null;
  const y = Number(yeast);
  if (y <= t[0].yeast) return t[0].minutes;
  if (y >= t[t.length - 1].yeast) return t[t.length - 1].minutes;
  for (let i = 1; i < t.length; i++) {
    const a = t[i - 1]; const b = t[i];
    if (y <= b.yeast) return Math.round(a.minutes + ((y - a.yeast) * (b.minutes - a.minutes)) / (b.yeast - a.yeast));
  }
  return null;
}

// ---------------------------------------------------------------- yeast and temperature
export function yeastMaterial() {
  const s = proofSettings();
  if (s.yeastMaterialId) { const m = db().get('SELECT * FROM materials WHERE id = ?', [s.yeastMaterialId]); if (m) return m; }
  return db().get("SELECT * FROM materials WHERE lower(name) LIKE '%yeast%' AND active = 1 ORDER BY id LIMIT 1") || null;
}
// Grams of yeast for a quantity in the material's own unit.
export function yeastGrams(qty, m) {
  const q = Number(qty);
  if (!Number.isFinite(q) || !m) return null;
  if (m.unit === 'g') return q;
  if (m.unit === 'kg') return q * 1000;
  if (m.kg_per_unit) return q * m.kg_per_unit * 1000;
  return q;
}
// The figure looked up in the table: g per kg of flour (default) or g per batch (admin option).
export function yeastMeasure(grams, flourKg, mode = proofSettings().yeastMode) {
  if (grams === null || grams === undefined) return null;
  if (mode === 'per_batch') return r3(grams);
  const f = Number(flourKg);
  return f > 0 ? r3(grams / f) : null;
}
// Hot / Normal / Cool from a room temperature (when the baker types one) using the admin's thresholds.
export function climateFor(roomTemp, s = proofSettings()) {
  const t = num(roomTemp);
  if (t === null) return 'normal';
  if (t >= s.hotFrom) return 'hot';
  if (t < s.coolBelow) return 'cool';
  return 'normal';
}
export function climateMinutes(climate, s = proofSettings()) { return climate === 'hot' ? s.hotMinutes : climate === 'cool' ? s.coolMinutes : 0; }

// Everything for one batch: null when the product has no proofing table.
export function proofFor(productId, { flourKg, yeastQty, climate, roomTemp } = {}) {
  const rows = proofTable(productId);
  if (!rows.length) return null;
  const s = proofSettings();
  const m = yeastMaterial();
  const measure = yeastMeasure(yeastGrams(yeastQty, m), flourKg, s.yeastMode);
  const base = interpolate(rows, measure);
  if (base === null) return null;
  const c = climate && CLIMATES[climate] ? climate : climateFor(roomTemp, s);
  const adjust = climateMinutes(c, s);
  return { yeast: measure, unit: s.yeastMode === 'per_batch' ? 'g in the batch' : 'g per kg flour', base, climate: c, adjust, minutes: Math.max(1, base + adjust) };
}
// Is this route step the proofing step?
export function isProofStep(step, s = proofSettings()) { return !!step && step.kind === 'normal' && String(step.name || '').toLowerCase().includes(s.stepWord || 'proof'); }
// The route with the proofing step's minutes replaced (used when a batch starts and on the New batch screen).
export function applyProof(route, proof) {
  if (!proof) return route;
  const s = proofSettings();
  return route.map((r) => (isProofStep(r, s) ? { ...r, minutes: proof.minutes, proof } : r));
}
