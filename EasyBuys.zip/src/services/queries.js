// Accountant queries ("Query for the owner"): the view-only accountant asks about a record; the owner / admin answers.
// Synced, kept forever, shown as warnings to the owner and admin until answered.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit } from './core.js';
import { actsAsOwner, can } from './access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
export const QUERIES_SQL = `
CREATE TABLE IF NOT EXISTS accountant_queries (
  uid TEXT PRIMARY KEY,
  text TEXT NOT NULL,
  ref TEXT,
  screen TEXT, params TEXT,
  by_name TEXT, by_uid TEXT, created_at TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  answer TEXT, answered_by TEXT, answered_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const QUERIES_SYNC = {
  accountant_queries: SYNC('uid', 'Accountant', ['uid', 'text', 'ref', 'screen', 'params', 'by_name', 'by_uid', 'created_at', 'status', 'answer', 'answered_by', 'answered_at']),
};

export function askQuery(user, { text, ref, screen, params }) {
  need(user, 'Log in first.');
  need(String(text || '').trim().length >= 3, 'Write the question.');
  const uid = uuid('Q');
  const now = stamp();
  db().run(`INSERT INTO accountant_queries (uid, text, ref, screen, params, by_name, by_uid, created_at, status, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?, 'open', ?, ?)`,
    [uid, String(text).trim(), String(ref || '').trim() || null, screen || null, params ? JSON.stringify(params) : null, user.name, user.uid || null, now, now, deviceId()]);
  audit({ user, action: `Query for the owner: ${String(text).trim().slice(0, 80)}`, table: 'accountant_queries', recordUid: uid });
  return uid;
}
export function answerQuery(user, uid, answer) {
  need(actsAsOwner(user) || (user && user.role === 'admin') || can(user, 'settings'), 'Only the owner or admin answers queries.');
  need(String(answer || '').trim(), 'Write the answer.');
  const q = db().get('SELECT * FROM accountant_queries WHERE uid = ?', [uid]);
  need(q, 'Query not found.');
  const now = stamp();
  db().run("UPDATE accountant_queries SET status = 'answered', answer = ?, answered_by = ?, answered_at = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [String(answer).trim(), user.name, now, now, deviceId(), uid]);
  audit({ user, action: `Answered the accountant: ${String(answer).trim().slice(0, 80)}`, table: 'accountant_queries', recordUid: uid });
}
export function listQueries({ status } = {}) {
  try {
    return db().all('SELECT * FROM accountant_queries WHERE (? IS NULL OR status = ?) ORDER BY created_at DESC LIMIT 300', [status || null, status || null])
      .map((q) => ({ ...q, params: (() => { try { return q.params ? JSON.parse(q.params) : {}; } catch (e) { return {}; } })() }));
  } catch (e) { return []; }
}
