// "My quick links": up to 8 menu items each person keeps at the top of Home. Saved per person in the shared
// (synced) settings, so the same links show on their tablet and phone. The admin sets the starting links for each role.
import { getShared, setShared, AppError, audit } from './core.js';
import { actsAsOwner } from './access.js';

export const MAX_LINKS = 8;
// Built-in starting links (module:item keys); the admin can change them per role.
export const BUILT_IN = {
  owner: ['dashboard:home', 'till:home', 'payables:home', 'bank:home', 'inventory:inv-today-orders', 'payroll:home'],
  admin: ['dashboard:home', 'till:home', 'payables:home', 'inventory:home', 'payroll:home', 'admin:home'],
  manager: ['till:home', 'inventory:inv-today-orders', 'inventory:inv-receive', 'payables:ap-new', 'timesheets:home'],
  payroll: ['payroll:home', 'timesheets:home', 'leave:home'],
  supervisor: ['till:home', 'inventory:inv-receive', 'timesheets:home'],
  staff: ['timesheets:ts-myhours', 'leave:home'],
  worker: ['bakery:home'],
};
const all = () => getShared('quick_links', {}) || {};
export function roleDefaults(role) {
  const d = getShared('quick_links_defaults', {}) || {};
  return Array.isArray(d[role]) ? d[role] : BUILT_IN[role] || [];
}
export function quickLinkKeys(user) {
  if (!user) return [];
  const mine = all()[user.uid];
  return (Array.isArray(mine) ? mine : roleDefaults(user.role)).slice(0, MAX_LINKS);
}
export function saveQuickLinks(user, keys) {
  const list = Array.from(new Set((keys || []).filter(Boolean))).slice(0, MAX_LINKS);
  setShared('quick_links', { ...all(), [user.uid]: list });
  return list;
}
export function toggleQuickLink(user, key) {
  const cur = quickLinkKeys(user);
  if (cur.includes(key)) return saveQuickLinks(user, cur.filter((k) => k !== key));
  if (cur.length >= MAX_LINKS) throw new AppError(`Up to ${MAX_LINKS} quick links – remove one first.`);
  return saveQuickLinks(user, cur.concat([key]));
}
export function moveQuickLink(user, key, step) {
  const cur = quickLinkKeys(user);
  const i = cur.indexOf(key);
  const j = i + step;
  if (i < 0 || j < 0 || j >= cur.length) return cur;
  const next = cur.slice();
  [next[i], next[j]] = [next[j], next[i]];
  return saveQuickLinks(user, next);
}
export function resetQuickLinks(user) {
  const m = { ...all() };
  delete m[user.uid];
  setShared('quick_links', m);
  return quickLinkKeys(user);
}
// Owner / admin: make someone's current links the starting links for a role.
export function setRoleDefaults(byUser, role, keys) {
  if (!actsAsOwner(byUser) && byUser.role !== 'admin') throw new AppError('Only the owner or admin can set the starting links.');
  const d = { ...(getShared('quick_links_defaults', {}) || {}), [role]: Array.from(new Set(keys)).slice(0, MAX_LINKS) };
  setShared('quick_links_defaults', d);
  audit({ user: byUser, action: `Starting quick links for ${role} set`, table: 'shared_settings' });
  return d[role];
}
// The person's links as menu items they may open (links to things they can't open are left out).
export function resolveQuickLinks(user, items) {
  const byKey = Object.fromEntries((items || []).map((it) => [it.key, it]));
  return quickLinkKeys(user).map((k) => byKey[k]).filter(Boolean);
}
