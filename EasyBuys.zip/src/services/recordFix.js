// v3.9 Admin corrections: the owner or an admin can correct any field of any business record when someone made a
// mistake – an invoice number, a date, an amount, a till count, a punch time, a staff detail… Every change keeps
// the before and after in the change history (who, when, why if given), syncs to every device, and is followed by
// a check of what it touches (linked records, the books, the returns, devices) so nothing is left inconsistent.
// Nothing is ever deleted: a wrong record is voided (status) and, if needed, entered again.
import { db } from '../db/connection.js';
import { AppError, stamp, deviceId, audit, money } from './core.js';
import { actsAsOwner } from './access.js';
import { SYNC_TABLES } from './records.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const SYSTEM = new Set(['sync_status', 'updated_at', 'updated_device', 'id']);
const SECRET = new Set(['pin', 'password_hash', 'face', 'face_at', 'face_by']);
// Plain names for the record kinds people will correct most.
export const FIX_TABLES = {
  ap_invoices: 'Supplier invoice / credit note', ap_payments: 'Payment to a supplier', cheques: 'Cheque', ap_suppliers: 'Supplier',
  till_counts: 'Till count', deposits: 'Bank deposit', bank_entries: 'Bank line', punches: 'Clock In / Out',
  leave_requests: 'Leave', pay_profiles: 'Pay details', staff_details: 'Staff details', inv_items: 'Product', inv_receipts: 'Delivery received',
  po_orders: 'Purchase order', po_lines: 'Purchase order line', inv_moves: 'Stock movement', gl_journals: 'Journal', users: 'Staff member',
  stat_payments: 'FNPF / PAYE payment', tax_proofs: 'Tax lodgement / payment proof', ve_items: 'Vehicle / equipment',
};
export const canFix = (user) => !!user && (actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || ['owner', 'admin'].includes(user.realRole));
const keyOf = (table) => { const c = SYNC_TABLES[table]; return c ? c.key : null; };
const exists = (table) => !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [table]);

// Figures that are worked out from other records are corrected where they are worked out (so nothing goes out of step).
const ELSEWHERE = {
  pay_runs: 'Pay is worked out from the timesheets: open the pay run, Reopen it (with a reason), change the line, and make it final again.',
  pay_lines: 'Pay is worked out from the timesheets: open the pay run, Reopen it (with a reason), change the line, and make it final again.',
  tax_return_versions: 'A lodged return is a frozen copy: correct the records, then lodge the amended return (version 2).',
};
const FIELD_ELSEWHERE = { gl_journals: { lines: 'Void the journal and enter it again with the right lines.' } };
export function fixFields(table) {
  need(!ELSEWHERE[table], ELSEWHERE[table]);
  need(SYNC_TABLES[table] && exists(table) && table !== 'audit_log', 'This kind of record cannot be corrected here.');
  const key = keyOf(table);
  return db().all(`PRAGMA table_info(${table})`).filter((c) => c.name !== key && !SYSTEM.has(c.name) && !SECRET.has(c.name) && !(FIELD_ELSEWHERE[table] || {})[c.name])
    .map((c) => ({ name: c.name, type: /INT/i.test(c.type) ? 'int' : /REAL|NUM|DEC|FLOA|DOUB/i.test(c.type) ? 'number' : 'text', required: !!c.notnull }));
}
export function getForFix(table, keyVal) {
  const key = keyOf(table);
  need(key, 'This kind of record cannot be corrected here.');
  const row = db().get(`SELECT * FROM ${table} WHERE ${key} = ?`, [keyVal]);
  need(row, 'Record not found.');
  return { table, key, keyVal, title: FIX_TABLES[table] || table, row, fields: fixFields(table), linked: linkedTo(table, row) };
}
// What else a record is joined to (shown before saving so the person knows what the change touches).
export function linkedTo(table, row) {
  const q = (sql, p) => { try { return db().get(sql, p).n; } catch (e) { return 0; } };
  const out = [];
  if (table === 'ap_invoices') {
    const n = q("SELECT COUNT(*) AS n FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = ?", [row.uid]);
    if (n) out.push(`${n} payment(s) pay this invoice`);
    if (row.po_uid) out.push('It is joined to a purchase order');
    const r = q("SELECT COUNT(*) AS n FROM inv_receipts WHERE invoice_uid = ? AND status = 'active'", [row.uid]);
    if (r) out.push(`${r} delivery(ies) are joined to it`);
    out.push(`The VAT return for ${String(row.invoice_date || '').slice(0, 7)} uses it`);
  }
  if (table === 'ap_payments') { out.push('The invoices it pays, the bank and the books follow it'); if (row.cheque_uid) out.push('It has a cheque in the cheque register'); }
  if (table === 'till_counts') out.push(`The sales, VAT and cash for ${row.shop_code} on ${row.shift_date} come from it`);
  if (table === 'punches') out.push("The person's timesheet and pay for that week come from it");
  if (table === 'inv_receipts' && row.po_uid) out.push('The purchase order quantities are worked out again from the deliveries');
  if (table === 'pay_profiles') out.push('Pay runs that are not final yet use these details');
  return out;
}
export function saveFix(user, table, keyVal, changes, reason) {
  need(canFix(user), 'Only the owner or an admin can correct records.');
  const rec = getForFix(table, keyVal);
  const fields = Object.fromEntries(rec.fields.map((f) => [f.name, f]));
  const set = {};
  for (const [k, v0] of Object.entries(changes || {})) {
    const f = fields[k];
    need(!(FIELD_ELSEWHERE[table] || {})[k], (FIELD_ELSEWHERE[table] || {})[k]);
    need(f, `"${k}" cannot be changed here.`);
    let v = v0 === undefined ? null : v0;
    if (typeof v === 'string') v = v.trim();
    if (v === '' && !f.required) v = null;
    if (f.type !== 'text' && v !== null && v !== '') {
      const n = Number(v);
      need(Number.isFinite(n), `${k}: enter a number.`);
      v = f.type === 'int' ? Math.round(n) : Math.round(n * 10000) / 10000;
    }
    if (f.required) need(v !== null && v !== '', `${k} cannot be left empty.`);
    if (/date$|_date$|^date$/.test(k) && v) need(/^\d{4}-\d{2}-\d{2}/.test(String(v)), `${k}: use YYYY-MM-DD.`);
    if (String(rec.row[k] === null || rec.row[k] === undefined ? '' : rec.row[k]) !== String(v === null ? '' : v)) set[k] = v;
  }
  need(Object.keys(set).length, 'Nothing was changed.');
  const before = Object.fromEntries(Object.keys(set).map((k) => [k, rec.row[k]]));
  const cols = Object.keys(set);
  const hasSync = db().all(`PRAGMA table_info(${table})`).some((c) => c.name === 'sync_status');
  const hasUpd = db().all(`PRAGMA table_info(${table})`).some((c) => c.name === 'updated_at');
  db().transaction(() => {
    db().run(`UPDATE ${table} SET ${cols.map((c) => `${c} = ?`).join(', ')}${hasUpd ? ', updated_at = ?, updated_device = ?' : ''}${hasSync ? ", sync_status = 'pending'" : ''} WHERE ${rec.key} = ?`,
      cols.map((c) => set[c]).concat(hasUpd ? [stamp(), deviceId()] : []).concat([keyVal]));
    audit({ user, action: `Corrected ${FIX_TABLES[table] || table}: ${cols.map((c) => `${c} "${before[c] === null || before[c] === undefined ? '' : before[c]}" → "${set[c] === null ? '' : set[c]}"`).join('; ')}`, table, recordUid: String(keyVal), before, after: set, reason: txt(reason) || null });
    afterFix(table, { ...rec.row, ...set }, rec.row);
  });
  return { record: getForFix(table, keyVal), checks: checksAfter(table, { ...rec.row, ...set }) };
}
// Work out again what depends on the corrected record.
function afterFix(table, row, old) {
  try {
    const I = () => require('../modules/inventory/service.js');
    // A delivery's quantities changed: the stock follows (a correction movement for the difference).
    if (table === 'inv_receipts' && row.lines !== old.lines && row.status === 'active') {
      const sum = (j) => { const m = {}; (JSON.parse(j || '[]') || []).forEach((l) => { if (l.itemUid) m[l.itemUid] = (m[l.itemUid] || 0) + (Number(l.qty) || 0); }); return m; };
      const a = sum(old.lines); const b = sum(row.lines);
      const sign = row.kind === 'return' ? -1 : 1;
      for (const id of new Set(Object.keys(a).concat(Object.keys(b)))) {
        const diff = Math.round(((b[id] || 0) - (a[id] || 0)) * 1000) / 1000;
        if (diff) I().addMove({ itemUid: id, shopCode: row.shop_code, date: row.receive_date, type: 'receive', qty: sign * diff, unitCost: null, refType: 'receipt_fix', refUid: row.uid, reason: 'Delivery corrected', user: null });
      }
    }
    if (table === 'inv_receipts' && row.po_uid) I().recountReceived(row.po_uid);
    if (table === 'inv_receipts' && old.po_uid && old.po_uid !== row.po_uid) I().recountReceived(old.po_uid);
    if (table === 'po_lines') I().refreshPOStatus(row.po_uid);
  } catch (e) { /* the warnings will show it */ }
}
// After a correction: anything now out of line (shown to the person who corrected it).
export function checksAfter(table, row) {
  const out = [];
  try { require('./conflicts.js').syncConflicts().forEach((c) => out.push(c.text)); } catch (e) { /* none */ }
  try { const A = require('../modules/accounting/service.js'); const tb = A.trialBalance(); if (!tb.ok) out.push(`The books do not balance: debits ${money(tb.dr)}, credits ${money(tb.cr)}`); } catch (e) { /* accounts not set up */ }
  try {
    const RT = require('../modules/payroll/returns.js');
    const ym = String(row.invoice_date || row.shift_date || row.jdate || row.pay_date || '').slice(0, 7);
    if (/^\d{4}-\d{2}$/.test(ym)) for (const k of ['vat', 'fnpf']) { const st = RT.returnStatus(k, ym); if (st.flags.some((f) => f.key === 'changed')) out.push(`The ${k === 'vat' ? 'VAT return' : 'FNPF schedule'} for ${ym} was lodged before – lodge an amended one`); }
  } catch (e) { /* returns not set up */ }
  try {
    const lock = require('./lock.js').lockDate();
    const d = String(row.invoice_date || row.shift_date || row.jdate || row.pay_date || row.receive_date || row.entry_date || '').slice(0, 10);
    if (lock && d && d <= lock) out.push(`This record is in a closed period (books closed to ${lock}) – tell the accountant`);
  } catch (e) { /* no lock */ }
  return out;
}
// Find a record to correct by what people know: an invoice or cheque number, a supplier, a person, a PO number.
export function findForFix(q) {
  const s = `%${txt(q).toLowerCase()}%`;
  if (txt(q).length < 2) return [];
  const out = [];
  const add = (table, keyVal, title, sub) => out.push({ table, keyVal, title, sub, kind: FIX_TABLES[table] || table });
  const t = (n) => exists(n);
  if (t('ap_invoices')) db().all('SELECT uid, invoice_no, supplier_name, invoice_date, total FROM ap_invoices WHERE lower(ifnull(invoice_no,\'\')) LIKE ? OR lower(supplier_name) LIKE ? ORDER BY invoice_date DESC LIMIT 15', [s, s]).forEach((r) => add('ap_invoices', r.uid, `Invoice ${r.invoice_no || '(no number)'} · ${r.supplier_name}`, `${r.invoice_date} · ${money(r.total)}`));
  if (t('cheques')) db().all("SELECT uid, cheque_no, payee, amount, cheque_date FROM cheques WHERE CAST(cheque_no AS TEXT) LIKE ? OR lower(ifnull(payee,'')) LIKE ? ORDER BY cheque_date DESC LIMIT 10", [s, s]).forEach((r) => add('cheques', r.uid, `Cheque ${r.cheque_no} · ${r.payee || ''}`, `${r.cheque_date} · ${money(r.amount)}`));
  if (t('ap_payments')) db().all("SELECT uid, supplier_name, pay_date, amount, method, cheque_no, reference FROM ap_payments WHERE lower(supplier_name) LIKE ? OR lower(ifnull(reference,'')) LIKE ? OR ifnull(cheque_no,'') LIKE ? ORDER BY pay_date DESC LIMIT 10", [s, s, s]).forEach((r) => add('ap_payments', r.uid, `Payment ${r.method}${r.cheque_no ? ` ${r.cheque_no}` : ''} · ${r.supplier_name}`, `${r.pay_date} · ${money(r.amount)}`));
  if (t('ap_suppliers')) db().all('SELECT uid, name, tin FROM ap_suppliers WHERE lower(name) LIKE ? LIMIT 8', [s]).forEach((r) => add('ap_suppliers', r.uid, `Supplier ${r.name}`, r.tin ? `TIN ${r.tin}` : ''));
  if (t('po_orders')) db().all('SELECT uid, po_no, supplier_name, order_date FROM po_orders WHERE lower(po_no) LIKE ? LIMIT 8', [s]).forEach((r) => add('po_orders', r.uid, `Order ${r.po_no} · ${r.supplier_name || ''}`, r.order_date));
  if (t('users')) db().all("SELECT uid, name, role FROM users WHERE lower(name) LIKE ? AND sync_status <> 'seed' LIMIT 8", [s]).forEach((r) => add('users', r.uid, `Staff ${r.name}`, r.role));
  if (t('inv_items')) db().all('SELECT uid, code, name FROM inv_items WHERE lower(name) LIKE ? OR lower(code) LIKE ? LIMIT 8', [s, s]).forEach((r) => add('inv_items', r.uid, `Product ${r.name}`, r.code));
  if (t('till_counts')) db().all("SELECT uid, shop_code, shift_date, shift, till_name FROM till_counts WHERE shift_date LIKE ? ORDER BY shift_date DESC LIMIT 10", [s]).forEach((r) => add('till_counts', r.uid, `Till count ${r.shop_code} ${r.shift_date} ${r.shift || ''}`, r.till_name || ''));
  return out;
}
