// Shared records: the tables every device (the tablet and the owners' phones) keeps the same.
// Each module lists its tables here. A change is saved on the device first (sync_status 'pending'),
// sent when there is internet, and changes made on other devices come back the same way.
// Rule when two devices changed the same record: the newest change wins (updated_at), and the
// cloud keeps both versions in its history.
import { db } from '../db/connection.js';
import { getSetting, setSetting, stamp } from './core.js';
import { PAYABLES_SYNC } from '../modules/payables/schema.js';
import { TILL_SYNC } from '../modules/till/schema.js';
import { BANK_SYNC } from '../modules/bank/schema.js';
import { PAYROLL_SYNC } from '../modules/payroll/schema.js';
import { INVENTORY_SYNC } from '../modules/inventory/schema.js';
import { MORE_SYNC } from '../db/moreSchemas.js';

// table -> how it is identified and which columns travel. `section` groups it on the Sync screen.
export const SYNC_TABLES = {
  users: {
    key: 'uid', section: 'Staff',
    cols: ['uid', 'name', 'pin', 'username', 'password_hash', 'role', 'active', 'employee_no', 'shop_code', 'phone', 'uses_clock', 'face', 'face_at', 'face_by', 'created_at', 'updated_at', 'updated_device'],
  },
  shops: { key: 'code', section: 'Settings', cols: ['code', 'name', 'active', 'sort', 'updated_at', 'updated_device'] },
  shared_settings: { key: 'key', section: 'Settings', cols: ['key', 'value', 'updated_at', 'updated_device'] },
  punches: {
    key: 'uid', section: 'Time Clock',
    cols: ['uid', 'user_uid', 'name', 'type', 'at', 'recorded_at', 'shop_code', 'device', 'method', 'face_result', 'face_distance', 'photo_url', 'reason',
      'created_by_uid', 'voided', 'void_reason', 'voided_by_uid', 'voided_at', 'updated_at', 'updated_device'],
  },
  timesheet_checks: {
    key: 'uid', section: 'Timesheets',
    cols: ['uid', 'user_uid', 'week_start', 'status', 'checked_by_uid', 'checked_by_name', 'checked_at', 'note', 'updated_at', 'updated_device'],
  },
  leave_types: { key: 'code', section: 'Leave', cols: ['code', 'name', 'paid', 'default_days', 'needs_photo', 'active', 'sort', 'updated_at', 'updated_device'] },
  leave_entitlements: { key: 'uid', section: 'Leave', cols: ['uid', 'user_uid', 'type', 'year', 'days', 'updated_at', 'updated_device'] },
  leave_requests: {
    key: 'uid', section: 'Leave',
    cols: ['uid', 'user_uid', 'name', 'type', 'from_date', 'to_date', 'days', 'reason', 'photo_url', 'status', 'requested_by_uid', 'requested_at',
      'decided_by_uid', 'decided_by_name', 'decided_at', 'decision_note', 'updated_at', 'updated_device'],
  },
  rosters: { key: 'user_uid', section: 'Timesheets', cols: ['user_uid', 'days', 'updated_at', 'updated_device'] },
  ...PAYABLES_SYNC,
  ...TILL_SYNC,
  ...BANK_SYNC,
  ...PAYROLL_SYNC,
  ...INVENTORY_SYNC,
  ...MORE_SYNC,
  audit_log: {
    key: 'uid', section: 'Change history', pushOnly: true,
    cols: ['uid', 'at', 'user_uid', 'user_name', 'device', 'action', 'table_name', 'record_uid', 'before', 'after', 'reason', 'updated_at', 'updated_device'],
  },
};

const pick = (row, cols) => {
  const o = {};
  cols.forEach((c) => { o[c] = row[c] === undefined ? null : row[c]; });
  return o;
};

// Everything waiting to be sent: [{ t, k, u, row }]
export function pendingRecords(limit = 300) {
  const out = [];
  for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
    if (out.length >= limit) break;
    const rows = db().all(`SELECT * FROM ${t} WHERE sync_status = 'pending' ORDER BY updated_at LIMIT ?`, [limit - out.length]);
    rows.forEach((r) => out.push({ t, k: String(r[cfg.key]), u: r.updated_at, row: pick(r, cfg.cols) }));
  }
  return out;
}

// After the cloud has the records. Only marks them sent if nobody changed them in the meantime.
export function markRecordsSent(list) {
  db().transaction(() => {
    for (const r of list) {
      const cfg = SYNC_TABLES[r.t];
      if (!cfg) continue;
      // Only if the record is exactly what was sent (a change in the same second must still be sent).
      const now = db().get(`SELECT * FROM ${r.t} WHERE ${cfg.key} = ? AND updated_at = ? AND sync_status = 'pending'`, [r.k, r.u]);
      if (now && JSON.stringify(pick(now, cfg.cols)) === JSON.stringify(r.row)) db().run(`UPDATE ${r.t} SET sync_status = 'synced' WHERE ${cfg.key} = ?`, [r.k]);
    }
  });
}

// Records that came from the cloud (made on other devices or by the main software).
// Returns how many were applied.
// v3.9: each record is applied on its own – one broken or unexpected record is set aside (and listed on the Sync
// screen) instead of stopping every other record from arriving.
export function applyPulledRecords(list) {
  let applied = 0;
  const failed = [];
  db().transaction(() => {
    for (const r of list) {
      try { applied += applyOne(r); } catch (e) { failed.push({ t: r && r.t, k: r && r.k, error: String(e && e.message || e).slice(0, 200) }); }
    }
  });
  if (failed.length) {
    try {
      const old = JSON.parse(getSetting('sync_failed_records', '[]') || '[]');
      setSetting('sync_failed_records', JSON.stringify(old.concat(failed.map((f) => ({ ...f, at: stamp() }))).slice(-100)));
      require('./errorLog.js').logError(new Error(`${failed.length} synced record(s) could not be saved: ${failed.slice(0, 3).map((f) => `${f.t} ${f.k}: ${f.error}`).join('; ')}`), { where: 'sync' });
    } catch (e) { /* noted next time */ }
  }
  // Orders received on more than one device: what was received is worked out from the deliveries again.
  try {
    const pos = new Set(list.filter((r) => r && r.t === 'inv_receipts' && r.row && r.row.po_uid).map((r) => r.row.po_uid));
    if (pos.size) { const I = require('../modules/inventory/service.js'); pos.forEach((u) => { try { I.recountReceived(u); } catch (e) { /* next sync */ } }); }
  } catch (e) { /* inventory not ready */ }
  return applied;
}
export function failedSyncRecords() { try { return JSON.parse(getSetting('sync_failed_records', '[]') || '[]'); } catch (e) { return []; } }
function applyOne(r) {
  let applied = 0;
  {
      const cfg = SYNC_TABLES[r.t];
      if (!cfg || cfg.pushOnly || !r.row) return 0;
      const row = pick(r.row, cfg.cols);
      const keyVal = row[cfg.key];
      if (keyVal === null || keyVal === undefined) return 0;
      const local = db().get(`SELECT * FROM ${r.t} WHERE ${cfg.key} = ?`, [keyVal]);
      // A local change that is newer and not yet sent wins; it will be sent next.
      if (local && local.sync_status === 'pending' && String(local.updated_at) >= String(row.updated_at || '')) return 0;
      if (local && local.sync_status !== 'seed' && String(local.updated_at) > String(row.updated_at || '')) return 0;
      let cols = cfg.cols.filter((c) => c in r.row && r.row[c] !== undefined);
      // The main software sends staff without PINs: never wipe a PIN that was set on a device.
      if (r.t === 'users' && !row.pin) cols = cols.filter((c) => c !== 'pin');
      if (local) {
        db().run(`UPDATE ${r.t} SET ${cols.map((c) => `${c} = ?`).join(', ')}, sync_status = 'synced' WHERE ${cfg.key} = ?`,
          cols.map((c) => row[c]).concat([keyVal]));
      } else if (r.t === 'users') {
        // A person added on another device: give them a local number on this device.
        const now = stamp();
        const c2 = cols.filter((c) => c !== 'created_at');
        const c3 = c2.filter((c) => c !== 'pin');
        // No PIN yet = cannot log in or clock in until a manager sets one.
        db().run(`INSERT INTO users (${c3.join(', ')}, pin, created_at, sync_status) VALUES (${c3.map(() => '?').join(', ')}, ?, ?, 'synced')`,
          c3.map((c) => row[c]).concat([row.pin || '', row.created_at || now]));
      } else {
        db().run(`INSERT INTO ${r.t} (${cols.join(', ')}, sync_status) VALUES (${cols.map(() => '?').join(', ')}, 'synced')`, cols.map((c) => row[c]));
      }
      applied += 1;
  }
  return applied;
}

// Waiting counts for the sync bar and the Sync screen, grouped by section.
export function pendingBySection() {
  const out = {};
  for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
    const n = db().get(`SELECT count(*) AS c FROM ${t} WHERE sync_status = 'pending'`).c;
    out[cfg.section] = (out[cfg.section] || 0) + n;
  }
  return out;
}
export function pullCursor() {
  return Number(getSetting('pull_seq', '0')) || 0;
}
export function setPullCursor(n) {
  setSetting('pull_seq', String(n));
}
