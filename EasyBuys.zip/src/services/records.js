// Shared records: the tables every device (the tablet and the owners' phones) keeps the same.
// Each module lists its tables here. A change is saved on the device first (sync_status 'pending'),
// sent when there is internet, and changes made on other devices come back the same way.
// Rule when two devices changed the same record: the newest change wins (updated_at), and the
// cloud keeps both versions in its history.
import { db, keepUntilChanged } from '../db/connection.js';
import { getSetting, setSetting, stamp } from './core.js';
import { PAYABLES_SYNC } from '../modules/payables/schema.js';
import { TILL_SYNC } from '../modules/till/schema.js';
import { BANK_SYNC } from '../modules/bank/schema.js';
import { PAYROLL_SYNC } from '../modules/payroll/schema.js';
import { INVENTORY_SYNC } from '../modules/inventory/schema.js';
import { MORE_SYNC } from '../db/moreSchemas.js';

// table -> how it is identified and which columns travel. `section` groups it on the Sync screen.
export const SYNC_TABLES = {
  users: {
    key: 'uid', section: 'Staff',
    // 1.0.0 build 1: the PIN travels only as its hash (pin_hash, services/pins.js) – the plain PIN never leaves the device.
    cols: ['uid', 'name', 'pin_hash', 'email', 'username', 'password_hash', 'role', 'active', 'employee_no', 'shop_code', 'phone', 'uses_clock', 'face', 'face_at', 'face_by', 'created_at', 'updated_at', 'updated_device'],
  },
  shops: { key: 'code', section: 'Settings', cols: ['code', 'name', 'active', 'sort', 'address', 'phone', 'email', 'tin', 'mpaisa', 'hours', 'manager_uid', 'notes', 'landlord', 'updated_at', 'updated_device'] },
  shared_settings: { key: 'key', section: 'Settings', cols: ['key', 'value', 'updated_at', 'updated_device'] },
  punches: {
    key: 'uid', section: 'Time Clock',
    cols: ['uid', 'user_uid', 'name', 'type', 'at', 'recorded_at', 'shop_code', 'device', 'method', 'face_result', 'face_distance', 'photo_url', 'reason',
      'created_by_uid', 'voided', 'void_reason', 'voided_by_uid', 'voided_at', 'updated_at', 'updated_device'],
  },
  timesheet_checks: {
    key: 'uid', section: 'Timesheets',
    cols: ['uid', 'user_uid', 'week_start', 'status', 'checked_by_uid', 'checked_by_name', 'checked_at', 'note', 'updated_at', 'updated_device'],
  },
  leave_types: { key: 'code', section: 'Leave', cols: ['code', 'name', 'paid', 'default_days', 'needs_photo', 'active', 'sort', 'updated_at', 'updated_device'] },
  leave_entitlements: { key: 'uid', section: 'Leave', cols: ['uid', 'user_uid', 'type', 'year', 'days', 'updated_at', 'updated_device'] },
  leave_requests: {
    key: 'uid', section: 'Leave',
    cols: ['uid', 'user_uid', 'name', 'type', 'from_date', 'to_date', 'days', 'reason', 'photo_url', 'status', 'requested_by_uid', 'requested_at',
      'decided_by_uid', 'decided_by_name', 'decided_at', 'decision_note', 'updated_at', 'updated_device'],
  },
  rosters: { key: 'user_uid', section: 'Timesheets', cols: ['user_uid', 'days', 'updated_at', 'updated_device'] },
  ...PAYABLES_SYNC,
  ...TILL_SYNC,
  ...BANK_SYNC,
  ...PAYROLL_SYNC,
  ...INVENTORY_SYNC,
  ...MORE_SYNC,
  audit_log: {
    key: 'uid', section: 'Change history', pushOnly: true,
    cols: ['uid', 'at', 'user_uid', 'user_name', 'device', 'action', 'table_name', 'record_uid', 'before', 'after', 'reason', 'updated_at', 'updated_device'],
  },
};

const pick = (row, cols) => {
  const o = {};
  cols.forEach((c) => { o[c] = row[c] === undefined ? null : row[c]; });
  return o;
};

// Everything waiting to be sent: [{ t, k, u, row }]
export function pendingRecords(limit = 300) {
  const out = [];
  for (const [t, cfg] of Object.entries(SYNC_TABLES)) {
    if (out.length >= limit) break;
    const rows = db().all(`SELECT * FROM ${t} WHERE sync_status = 'pending' ORDER BY updated_at LIMIT ?`, [limit - out.length]);
    // 1.0.0 build 1: a PIN just set goes with the proof the cloud keeps for checking logins (never the PIN itself).
    // Worked out now, with the business salt the cloud gave (the plain PIN is only on the device where it was typed).
    rows.forEach((r) => {
      const row = pick(r, cfg.cols);
      if (t === 'users' && r.pin_proof && r.pin) { try { const pr = require('./pins.js').pinProof(r.pin, r.uid); if (pr) row._proof = pr; } catch (e) { /* sent without */ } }
      out.push({ t, k: String(r[cfg.key]), u: r.updated_at, row });
    });
  }
  // v3.9.6 records gone for good from the Deleted bin: an empty marker overwrites the cloud copy.
  if (out.length < limit) { try { require('./bin.js').scrubRecords(limit - out.length).forEach((r) => out.push(r)); } catch (e) { /* next round */ } }
  return out;
}

// After the cloud has the records. Only marks them sent if nobody changed them in the meantime.
export function markRecordsSent(list) {
  db().transaction(() => {
    try { require('./bin.js').scrubSent(list.filter((r) => r && r.scrub)); } catch (e) { /* sent again next round – harmless */ }
    for (const r of list) {
      if (r && r.scrub) continue;
      const cfg = SYNC_TABLES[r.t];
      if (!cfg) continue;
      // Only if the record is exactly what was sent (a change in the same second must still be sent).
      const now = db().get(`SELECT * FROM ${r.t} WHERE ${cfg.key} = ? AND updated_at = ? AND sync_status = 'pending'`, [r.k, r.u]);
      const sent = r.row && r.row._proof !== undefined ? (({ _proof, ...rest }) => rest)(r.row) : r.row;
      if (now && JSON.stringify(pick(now, cfg.cols)) === JSON.stringify(sent)) {
        db().run(`UPDATE ${r.t} SET sync_status = 'synced' WHERE ${cfg.key} = ?`, [r.k]);
        if (r.t === 'users' && r.row && r.row._proof) db().run('UPDATE users SET pin_proof = NULL WHERE uid = ?', [r.k]); // the cloud has it now
      }
    }
  });
}

// Records that came from the cloud (made on other devices or by the main software).
// Returns how many were applied.
// v3.9: each record is applied on its own – one broken or unexpected record is set aside (and listed on the Sync
// screen) instead of stopping every other record from arriving.
export function applyPulledRecords(list) {
  let applied = 0;
  const failed = [];
  db().transaction(() => {
    for (const r of list) {
      try { applied += applyOne(r); } catch (e) { failed.push({ t: r && r.t, k: r && r.k, error: String(e && e.message || e).slice(0, 200) }); }
    }
  });
  if (failed.length) {
    try {
      const old = JSON.parse(getSetting('sync_failed_records', '[]') || '[]');
      setSetting('sync_failed_records', JSON.stringify(old.concat(failed.map((f) => ({ ...f, at: stamp() }))).slice(-100)));
      require('./errorLog.js').logError(new Error(`${failed.length} synced record(s) could not be saved: ${failed.slice(0, 3).map((f) => `${f.t} ${f.k}: ${f.error}`).join('; ')}`), { where: 'sync' });
    } catch (e) { /* noted next time */ }
  }
  // Orders received on more than one device: what was received is worked out from the deliveries again.
  try {
    const pos = new Set(list.filter((r) => r && r.t === 'inv_receipts' && r.row && r.row.po_uid).map((r) => r.row.po_uid));
    if (pos.size) { const I = require('../modules/inventory/service.js'); pos.forEach((u) => { try { I.recountReceived(u); } catch (e) { /* next sync */ } }); }
  } catch (e) { /* inventory not ready */ }
  return applied;
}
export function failedSyncRecords() { try { return JSON.parse(getSetting('sync_failed_records', '[]') || '[]'); } catch (e) { return []; } }
function applyOne(r) {
  let applied = 0;
  {
      const cfg = SYNC_TABLES[r.t];
      if (!cfg || cfg.pushOnly || !r.row) return 0;
      if (r.t === 'users') require('./pins.js').incomingUser(r.row); // a plain PIN from an old cloud script → its hash
      const row = pick(r.row, cfg.cols);
      const keyVal = row[cfg.key];
      if (keyVal === null || keyVal === undefined) return 0;
      // v3.9.6 a record in the Deleted bin (or gone for good) is not brought back by a copy from elsewhere.
      if (r.row._gone) return 0;
      if (r.t !== 'bin_records' && r.t !== 'bin_parts' && inBinSafe(r.t, keyVal)) return 0;
      // 1.0.0 build 10 (review): a product with a code already used here by another record is merged, not refused
      // (modules/inventory/itemMerge.js); what points to a merged product points to the one kept.
      if (r.t === 'inv_items' || ITEM_REF_T.includes(r.t)) { if (!require('../modules/inventory/itemMerge.js').beforePulled(r.t, row)) return 0; }
      const local = db().get(`SELECT * FROM ${r.t} WHERE ${cfg.key} = ?`, [keyVal]);
      // A local change that is newer and not yet sent wins; it will be sent next.
      if (local && local.sync_status === 'pending' && String(local.updated_at) >= String(row.updated_at || '')) return 0;
      if (local && local.sync_status !== 'seed' && String(local.updated_at) > String(row.updated_at || '')) return 0;
      // 1.0.0 build 1 (audit C1 / H2): a locked record or setting is applied only when the cloud checked it came from the
      // owner / admin (r.vby); no change to a record in a closed month; no time in the future. Refusals go in the history.
      const L = require('./locked.js');
      const why = L.pulledRefusal(r, row, local);
      if (why) { L.notePulled({ ...r, k: keyVal }, why); return 0; }
      let cols = cfg.cols.filter((c) => c in r.row && r.row[c] !== undefined);
      // The main software sends staff without PINs: never wipe a PIN that was set on a device.
      if (r.t === 'users' && !row.pin_hash) cols = cols.filter((c) => c !== 'pin_hash');
      if (local) {
        db().run(`UPDATE ${r.t} SET ${cols.map((c) => `${c} = ?`).join(', ')}, sync_status = 'synced' WHERE ${cfg.key} = ?`,
          cols.map((c) => row[c]).concat([keyVal]));
      } else if (r.t === 'users') {
        // A person added on another device: give them a local number on this device.
        const now = stamp();
        const c2 = cols.filter((c) => c !== 'created_at');
        const c3 = c2.filter((c) => c !== 'pin');
        // No PIN yet = cannot log in or clock in until a manager sets one.
        // The plain PIN is never taken from a copy made elsewhere: they log in with the PIN's hash.
        db().run(`INSERT INTO users (${c3.join(', ')}, pin, created_at, sync_status) VALUES (${c3.map(() => '?').join(', ')}, ?, ?, 'synced')`,
          c3.map((c) => row[c]).concat(['', row.created_at || now]));
      } else {
        db().run(`INSERT INTO ${r.t} (${cols.join(', ')}, sync_status) VALUES (${cols.map(() => '?').join(', ')}, 'synced')`, cols.map((c) => row[c]));
      }
      applied += 1;
      if (r.t === 'bin_records') require('./bin.js').binArrived(db().get('SELECT * FROM bin_records WHERE uid = ?', [keyVal]));
      if (r.t === 'bin_parts') { const p = db().get('SELECT bin_uid FROM bin_parts WHERE uid = ?', [keyVal]); const b = p && db().get("SELECT * FROM bin_records WHERE uid = ? AND status = 'restored'", [p.bin_uid]); if (b) require('./bin.js').binArrived(b); }
  }
  return applied;
}
const ITEM_REF_T = ['inv_item_shops', 'inv_moves', 'inv_cost_changes', 'inv_count_lines', 'po_lines'];
function inBinSafe(t, k) { try { return require('./bin.js').inBin(t, k); } catch (e) { return false; } }

// Waiting counts for the sync bar and the Sync screen, grouped by section.
// 1.0.0 speed: all the counts in one statement (was one per table – about 100 – each time the sync light looked),
// each from the table's small "waiting" index (db/perfIndexes.js), and kept until one of the tables changes.
let pendingSql = null;
export function pendingBySection() {
  const list = Object.entries(SYNC_TABLES);
  const counts = (() => {
    try {
      if (!pendingSql || pendingSql.n !== list.length) pendingSql = { n: list.length, sql: `SELECT ${list.map(([t], i) => `(SELECT count(*) FROM ${t} WHERE sync_status = 'pending') AS c${i}`).join(', ')}` };
      const r = keepUntilChanged('records|pending', list.map(([t]) => t), () => db().get(pendingSql.sql));
      return list.map((x, i) => r[`c${i}`]);
    } catch (e) {
      // a table missing on this device: one at a time, as before (the same error for the caller)
      return list.map(([t]) => db().get(`SELECT count(*) AS c FROM ${t} WHERE sync_status = 'pending'`).c);
    }
  })();
  const out = {};
  list.forEach(([, cfg], i) => { out[cfg.section] = (out[cfg.section] || 0) + counts[i]; });
  return out;
}
export function pullCursor() {
  return Number(getSetting('pull_seq', '0')) || 0;
}
export function setPullCursor(n) {
  setSetting('pull_seq', String(n));
}
