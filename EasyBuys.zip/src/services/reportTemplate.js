// The report layout the admin can change: business details on every report, the footer, and per report its title
// and which columns are shown (in which order). Applied to every PDF, Excel and CSV.
import { getShared, setShared, audit } from './core.js';

export const TEMPLATE_DEFAULTS = {
  businessName: 'Easy Buys Shopping Centre',
  address: 'Lautoka, Fiji',
  phone: '',
  email: '',
  tin: '',
  footer: 'Easy Buys Shopping Center · Shop 1: Drasa Avenue · Shop 2: V M Pillay, Riffle Range · Shop 3: Kiran Palace · Lautoka, Fiji',
  showGenerated: true,
  reports: {}, // kind → { title, hidden: [column keys], order: [column keys], note }
};
export function reportTemplate() {
  const s = getShared('report_template', {}) || {};
  return { ...TEMPLATE_DEFAULTS, ...s, reports: { ...(s.reports || {}) } };
}
export function saveReportTemplate(user, t) {
  const clean = { businessName: String(t.businessName || '').trim() || TEMPLATE_DEFAULTS.businessName, address: String(t.address || '').trim(), phone: String(t.phone || '').trim(),
    email: String(t.email || '').trim(), tin: String(t.tin || '').trim(), footer: String(t.footer || '').trim(), showGenerated: t.showGenerated !== false, reports: t.reports || {} };
  setShared('report_template', clean);
  audit({ user, action: 'Changed the report layout', table: 'shared_settings', recordUid: 'report_template' });
  return clean;
}
// Returns a copy of the report with the layout applied (never changes the original).
export function applyTemplate(rep, tpl = reportTemplate()) {
  if (!rep || rep._templated) return rep;
  const per = tpl.reports[rep.kind] || {};
  const info = (rep.info || []).filter(([k]) => tpl.showGenerated || k !== 'Generated');
  const head = [tpl.tin ? ['TIN', tpl.tin] : null].filter(Boolean);
  const sections = (rep.sections || []).map((sec) => {
    let cols = sec.columns.filter((c) => !(per.hidden || []).includes(c.key));
    if (per.order && per.order.length) cols = cols.slice().sort((a, b) => { const ia = per.order.indexOf(a.key); const ib = per.order.indexOf(b.key); return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib); });
    return { ...sec, columns: cols.length ? cols : sec.columns };
  });
  const subtitle = String(rep.subtitle || '').replace(/Easy Buys Shopping Centre|Easy Buys Shopping Center/g, tpl.businessName);
  return { ...rep, _templated: true, title: per.title || rep.title, subtitle, info: info.concat(head), sections,
    footer: [tpl.footer, [tpl.address, tpl.phone, tpl.email].filter(Boolean).join(' · ')].filter(Boolean).join('\n'), note: per.note || rep.note };
}
