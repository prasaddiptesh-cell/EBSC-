// Report engine. Every report is built as plain data:
//   { title, subtitle, info:[[label,value]], summary:[{label,value,tone}], sections:[{title, columns:[{key,title,align}], rows:[{...}], note}] }
// The same data is shown on screen, turned into PDF/Excel/CSV, emailed and sent to the dashboard.
import { db } from '../db/connection.js';
import { fmt, signed, r3, r1, getSettings, hhmm, hoursMinutes, stamp, minutesBetween, APP_VERSION, money } from './core.js';
import { shiftChecklistRows } from './checklists.js';
import { planProgress } from './plan.js';
import { listEquipment } from './equipment.js';
import { batchLots, listLots } from './stock.js';
import { getShift, getShiftWorkers, getBalanceSheet, checkVariance, STATUS_LABEL, listShifts } from './shifts.js';
import { listBatches, batchStats } from './batches.js';

const cur = () => getSettings().currency;
import { listAlerts, ALERT_LABEL, lowStockItems, getPurchaseOrder } from './stock.js';

const col = (key, title, align) => ({ key, title, align: align || 'left' });
const R = 'right';

function batchRows(batches) {
  return batches.map((b) => {
    const s = batchStats(b);
    return {
      code: b.code, product: b.product_name, by: b.user_name, flour: fmt(b.flour_kg, 'kg'), cut_w: `${fmt(b.cut_weight_g)} g`,
      expected: fmt(b.expected_pieces), cut: b.cut_pieces === null ? '—' : fmt(b.cut_pieces), good: b.good === null ? 'in progress' : fmt(b.good),
      damaged: fmt(b.damaged || 0), rejected: fmt(b.rejected || 0), other: fmt(b.other_waste || 0),
      yield: s.yieldPct === null || b.good === null ? '—' : `${s.yieldPct}%`,
      start: hhmm(b.started_at), finish: b.finished_at ? hhmm(b.finished_at) : '—', mins: hoursMinutes(s.totalMinutes),
      snooze: s.snoozes ? `${s.snoozes} (${s.snoozeMinutes} min)` : '—', timeline: s.timeline, water_temp: b.water_temp === null ? '—' : `${b.water_temp}°C`,
      cost: money(s.cost, cur()) + (s.costComplete ? '' : '*'), cost_pc: s.costPerGood === null ? '—' : money(s.costPerGood, cur()), loss_value: money(s.lossValue, cur()),
      _tone: b.good !== null && s.yieldPct !== null && s.yieldPct < 95 ? 'warn' : null,
    };
  });
}
const BATCH_COLS = [
  col('code', 'Batch'), col('product', 'Product'), col('by', 'Baker'), col('flour', 'Flour', R), col('cut_w', 'Cut weight', R),
  col('expected', 'Expected', R), col('cut', 'Cut', R), col('good', 'Good', R), col('damaged', 'Damaged', R), col('rejected', 'Rejected', R),
  col('other', 'Other', R), col('yield', 'Yield', R), col('start', 'Mixing', R), col('finish', 'Finished', R), col('mins', 'Total time', R), col('snooze', 'Snoozes', R),
];
const COST_COLS = [col('cost', 'Ingredient cost', R), col('cost_pc', 'Cost per good piece', R), col('loss_value', 'Value lost', R)];
const batchCols = (costs) => (costs ? BATCH_COLS.concat(COST_COLS) : BATCH_COLS);

function totalsByProduct(batches) {
  const map = {};
  for (const b of batches) {
    const k = b.product_name;
    const t = (map[k] = map[k] || { product: k, unit: b.product_unit, batches: 0, flour: 0, expected: 0, good: 0, lost: 0 });
    t.batches += 1;
    t.flour += b.flour_kg;
    t.expected += b.expected_pieces;
    t.good += b.good || 0;
    t.lost += (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0);
  }
  return Object.values(map).map((t) => ({
    product: t.product, unit: t.unit, batches: t.batches, flour: fmt(r3(t.flour), 'kg'), expected: fmt(t.expected), good: fmt(t.good), lost: fmt(t.lost),
    yield: t.expected ? `${r1((t.good / t.expected) * 100)}%` : '—',
  }));
}
const PROD_TOTAL_COLS = [col('product', 'Product'), col('unit', 'Unit'), col('batches', 'Batches', R), col('flour', 'Flour', R), col('expected', 'Expected', R), col('good', 'Good', R), col('lost', 'Damaged/rejected/other', R), col('yield', 'Yield', R)];

function ingredientRows(where, params) {
  return db().all(
    `SELECT m.name, m.unit, m.track_stock, SUM(bi.expected) AS expected, SUM(bi.actual) AS actual, SUM(bi.flagged) AS flagged, COUNT(*) AS n
     FROM batch_ingredients bi JOIN batches b ON b.id = bi.batch_id JOIN materials m ON m.id = bi.material_id
     WHERE ${where} GROUP BY bi.material_id ORDER BY m.name`, params
  ).map((r) => ({
    name: r.name, expected: fmt(r3(r.expected), r.unit), actual: fmt(r3(r.actual), r.unit), variance: signed(r3(r.actual - r.expected), r.unit),
    pct: r.expected ? `${r1(((r.actual - r.expected) / r.expected) * 100)}%` : '—', flagged: r.flagged ? `${r.flagged} of ${r.n}` : '—',
    _tone: r.flagged ? 'warn' : null,
  }));
}
const ING_COLS = [col('name', 'Ingredient'), col('expected', 'Calculated', R), col('actual', 'Actually used', R), col('variance', 'Difference', R), col('pct', '%', R), col('flagged', 'Batches flagged', R)];

function alertRows(list) {
  return list.map((a) => ({
    time: `${a.created_at.slice(5, 10)} ${hhmm(a.created_at)}`, type: ALERT_LABEL[a.type] || a.type, message: a.message, by: a.user_name || '—',
    status: a.ack_at ? `Seen by ${a.ack_name}` : 'Open', _tone: a.ack_at ? null : 'warn',
  }));
}
const ALERT_COLS = [col('time', 'Time'), col('type', 'Alert'), col('message', 'Details'), col('by', 'Person'), col('status', 'Status')];

function workerRows(workers) {
  return workers.map((w) => ({
    name: w.name, on: hhmm(w.signed_on_at) + (w.on_edited ? ` (entered ${hhmm(w.signed_on_recorded_at)})` : ''),
    off: w.signed_off_at ? hhmm(w.signed_off_at) + (w.off_edited ? ` (entered ${hhmm(w.signed_off_recorded_at)})` : '') : 'not signed off',
    hours: hoursMinutes(w.minutes), _tone: !w.signed_off_at || w.on_edited || w.off_edited ? 'warn' : null,
  }));
}
const WORKER_COLS = [col('name', 'Name'), col('on', 'Signed on'), col('off', 'Signed off'), col('hours', 'Hours', R)];

function baseInfo() {
  const s = getSettings();
  return { bakery: s.bakeryName, location: s.locationName, generated: stamp().slice(0, 16) };
}

// ================= SHIFT REPORT =================
export function shiftReport(shiftId, { costs = true } = {}) {
  const s = getShift(shiftId);
  if (!s) return null;
  const batches = listBatches({ shiftId }).reverse();
  const workers = getShiftWorkers(shiftId);
  const stock = getBalanceSheet(shiftId).map((r) => {
    const counted = r.actual !== null && r.actual !== undefined;
    const v = counted ? checkVariance(r.expected, r.actual, r.tolerance_pct) : null;
    return {
      name: `${r.name} (${r.unit})`, opening: fmt(r.opening), received: fmt(r.received), used: fmt(r.used), wasted: fmt(r.wasted), adjusted: signed(r.adjusted),
      expected: fmt(r.expected), actual: counted ? fmt(r.actual) : 'not counted',
      variance: counted ? `${signed(r.variance)}${r.variance && v.pct !== null ? ` (${v.pct}%)` : ''}` : '—',
      reason: r.reason || '', _tone: v && v.over ? 'bad' : v && r.variance ? 'warn' : null,
    };
  });
  const receipts = db().all(
    `SELECT t.txn_id, t.txn_time, t.qty, t.supplier, t.invoice_no, m.name, m.unit, u.name AS user_name FROM transactions t
     JOIN materials m ON m.id = t.material_id JOIN users u ON u.id = t.user_id WHERE t.shift_id = ? AND t.type = 'RECEIVE' ORDER BY t.id`, [shiftId]
  ).map((r) => ({ time: r.txn_time, supplier: r.supplier || '—', invoice: r.invoice_no || '—', item: r.name, qty: fmt(r.qty, r.unit), by: r.user_name }));
  const wastage = db().all(
    `SELECT t.txn_time, t.qty, t.note, m.name, m.unit, u.name AS user_name FROM transactions t JOIN materials m ON m.id = t.material_id
     JOIN users u ON u.id = t.user_id WHERE t.shift_id = ? AND t.type = 'WASTAGE' ORDER BY t.id`, [shiftId]
  ).map((w) => ({ time: w.txn_time, item: w.name, qty: fmt(w.qty, w.unit), reason: w.note || '', by: w.user_name }));
  const extra = db().all(
    `SELECT t.txn_time, t.qty, t.note, m.name, m.unit, u.name AS user_name FROM transactions t JOIN materials m ON m.id = t.material_id
     JOIN users u ON u.id = t.user_id WHERE t.shift_id = ? AND t.type = 'USAGE' AND t.batch_id IS NULL ORDER BY t.id`, [shiftId]
  ).map((w) => ({ time: w.txn_time, item: w.name, qty: fmt(w.qty, w.unit), reason: w.note || '', by: w.user_name }));
  const alerts = listAlerts({ shiftId });
  const done = batches.filter((b) => b.status === 'finished');
  const good = done.reduce((a, b) => a + (b.good || 0), 0);
  const expected = done.reduce((a, b) => a + b.expected_pieces, 0);
  const lost = done.reduce((a, b) => a + (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0), 0);
  const over = stock.filter((x) => x._tone === 'bad').length;
  const info = baseInfo();
  return {
    kind: 'shift', id: shiftId, title: 'Shift Report', fileName: `Shift-${s.code}`,
    subtitle: `${s.shift_name} shift · ${s.shift_date} · ${s.code}`,
    approved: s.status === 'approved',
    info: [
      ['Bakery', `${info.bakery} – ${s.location || info.location}`], ['Date', s.shift_date], ['Shift', `${s.shift_name} (${s.code})`],
      ['Status', STATUS_LABEL[s.status]], ['Opened', `${hhmm(s.opened_at)} by ${s.opened_by_name || '—'}`],
      ['Closed', s.closed_at ? `${hhmm(s.closed_at)} by ${s.closed_by_name}` : '—'],
      ['Approved', s.approved_at ? `${s.approved_at.slice(0, 16)} by ${s.approved_by_name}` : 'Not yet approved'],
      ['Supervisor notes', s.approval_notes || '—'], ['Closing notes', s.close_notes || '—'],
    ],
    summary: [
      { label: 'Batches', value: String(batches.length) },
      { label: 'Good production', value: fmt(good), tone: 'good' },
      { label: 'Yield', value: expected ? `${r1((good / expected) * 100)}%` : '—', tone: expected && good / expected < 0.95 ? 'warn' : 'good' },
      { label: 'Damaged/rejected', value: fmt(lost), tone: lost ? 'warn' : null },
      { label: 'Alerts', value: String(alerts.length), tone: alerts.length ? 'warn' : null },
      { label: 'Over tolerance', value: String(over), tone: over ? 'bad' : 'good' },
    ],
    sections: [
      { title: 'Bakers on shift', columns: WORKER_COLS, rows: workerRows(workers) },
      { title: 'Production by product', columns: PROD_TOTAL_COLS, rows: totalsByProduct(done) },
      { title: 'Plan vs actual', columns: PLAN_COLS, rows: planRows(s.shift_date) },
      { title: 'Batches', columns: batchCols(costs), rows: batchRows(batches), note: batches.map((b) => `${b.code}: ${batchStats(b).timeline}`).join('\n') + (costs ? '\n* some ingredients have no price yet' : '') },
      { title: 'Lots used (traceability)', columns: [col('batch', 'Batch'), col('item', 'Ingredient'), col('lot', 'Lot'), col('expiry', 'Expiry'), col('supplier', 'Supplier'), col('qty', 'Qty', R)],
        rows: batches.flatMap((b) => batchLots(b.id).map((l) => ({ batch: b.code, item: l.name, lot: l.lot_no || '(no lot no.)', expiry: l.expiry || '—', supplier: l.supplier_name || '—', qty: fmt(l.qty, l.unit) }))) },
      { title: 'Ingredients used (calculated vs actual)', columns: ING_COLS, rows: ingredientRows('b.shift_id = ?', [shiftId]) },
      { title: 'Other ingredient use', columns: [col('time', 'Time'), col('item', 'Item'), col('qty', 'Qty', R), col('reason', 'Used for'), col('by', 'By')], rows: extra },
      { title: 'Stock received', columns: [col('time', 'Time'), col('supplier', 'Supplier'), col('invoice', 'Invoice'), col('item', 'Item'), col('qty', 'Qty', R), col('by', 'By')], rows: receipts },
      { title: 'Wastage', columns: [col('time', 'Time'), col('item', 'Item'), col('qty', 'Qty', R), col('reason', 'Reason'), col('by', 'By')], rows: wastage },
      {
        title: 'Stock balance', columns: [col('name', 'Material'), col('opening', 'Opening', R), col('received', 'Received', R), col('used', 'Used', R),
          col('wasted', 'Wasted', R), col('adjusted', 'Adjusted', R), col('expected', 'Expected', R), col('actual', 'Counted', R), col('variance', 'Variance', R), col('reason', 'Reason')],
        rows: stock,
      },
      { title: 'Checklists & temperatures', columns: CHECK_COLS, rows: checklistRows(shiftChecklistRows(shiftId)) },
      { title: 'Equipment issues open', columns: [col('name', 'Equipment'), col('fault', 'Problem'), col('by', 'Reported by'), col('at', 'When')],
        rows: listEquipment().flatMap((e) => e.openFaults.map((f) => ({ name: e.name, fault: f.note, by: f.user_name, at: f.at.slice(0, 16), _tone: 'warn' }))) },
      { title: 'Alerts', columns: ALERT_COLS, rows: alertRows(alerts) },
    ],
  };
}

const PLAN_COLS = [col('name', 'Product'), col('target', 'Planned', R), col('good', 'Made (good)', R), col('remaining', 'Short', R), col('pct', 'Done', R)];
function planRows(date) {
  return planProgress(date).map((p) => ({ name: p.name + (p.unplanned ? ' (not planned)' : ''), target: fmt(p.target), good: fmt(p.good), remaining: fmt(p.remaining),
    pct: p.pct === null ? '—' : `${p.pct}%`, _tone: p.pct !== null && p.pct < 100 ? 'warn' : null }));
}
const CHECK_COLS = [col('list', 'Checklist'), col('item', 'Item'), col('result', 'Result'), col('by', 'By'), col('at', 'Time')];
function checklistRows(rows) {
  return rows.map((r) => {
    let result = 'NOT DONE';
    if (r.status === 'skipped') result = `Skipped: ${r.note || ''}`;
    else if (r.status === 'done') result = r.kind === 'temp' ? `${r.value}°C (${r.min_value} to ${r.max_value})${r.out_of_range ? ' OUT OF RANGE' : ''}` : r.kind === 'photo' ? 'Photo taken' : 'Done';
    return { list: r.list + (r.run_user ? ` – ${r.run_user}` : ''), item: r.item, result, by: r.user_name || '—', at: r.at ? hhmm(r.at) : '—',
      _tone: !r.status ? 'bad' : r.out_of_range ? 'bad' : r.status === 'skipped' ? 'warn' : null };
  });
}

// ================= RANGE REPORTS =================
export const RANGE_REPORTS = [
  { id: 'production', title: 'Production', icon: '🍞', desc: 'Batches, yield and totals by product' },
  { id: 'hours', title: 'Baker hours', icon: '⏱️', desc: 'Sign-on, sign-off and hours worked' },
  { id: 'ingredients', title: 'Ingredient usage', icon: '🥣', desc: 'Calculated vs actual, flagged batches' },
  { id: 'wastage', title: 'Wastage', icon: '🗑️', desc: 'Ingredient wastage and product losses' },
  { id: 'receipts', title: 'Stock received', icon: '📦', desc: 'Deliveries by supplier and invoice' },
  { id: 'stock', title: 'Stock levels', icon: '🏷️', desc: 'Current stock and minimum levels' },
  { id: 'costing', title: 'Costing', icon: '💲', desc: 'Batch cost, cost per piece, value of losses', costs: true },
  { id: 'plan', title: 'Plan vs actual', icon: '🎯', desc: 'Production targets against what was made' },
  { id: 'checklists', title: 'Checklists & temperatures', icon: '✅', desc: 'Cleaning, opening checks, fridge/freezer log' },
  { id: 'suppliers', title: 'Supplier prices', icon: '🏪', desc: 'Prices paid over time and deliveries', costs: true },
  { id: 'expiry', title: 'Lots & expiry', icon: '📅', desc: 'Stock lots, expiry dates, what is left' },
  { id: 'equipment', title: 'Equipment', icon: '🔧', desc: 'Faults, repairs, services and costs' },
  { id: 'alerts', title: 'Alerts', icon: '⚠️', desc: 'Every alert raised' },
];

export function rangeReport(id, from, to) {
  const info = baseInfo();
  const period = from === to ? from : `${from} to ${to}`;
  const base = (title, extra) => ({
    kind: id, title, fileName: `${title.replace(/\s+/g, '-')}-${from}${from === to ? '' : `-to-${to}`}`, subtitle: `${info.bakery} · ${period}`,
    info: [['Bakery', `${info.bakery} – ${info.location}`], ['Period', period], ['Generated', info.generated]], ...extra,
  });
  if (id === 'production') {
    const batches = listBatches({ from, to, limit: 5000 }).reverse();
    const done = batches.filter((b) => b.status === 'finished');
    const good = done.reduce((a, b) => a + (b.good || 0), 0);
    const exp = done.reduce((a, b) => a + b.expected_pieces, 0);
    return base('Production Report', {
      summary: [{ label: 'Batches', value: String(batches.length) }, { label: 'Good', value: fmt(good), tone: 'good' },
        { label: 'Yield', value: exp ? `${r1((good / exp) * 100)}%` : '—' }, { label: 'Flour used', value: fmt(r3(batches.reduce((a, b) => a + b.flour_kg, 0)), 'kg') }],
      sections: [{ title: 'Totals by product', columns: PROD_TOTAL_COLS, rows: totalsByProduct(done) },
        { title: 'All batches', columns: [col('date', 'Date')].concat(BATCH_COLS), rows: batchRows(batches).map((r, i) => ({ date: batches[i].started_at.slice(0, 10), ...r })) }],
    });
  }
  if (id === 'hours') {
    const rows = db().all(
      `SELECT sw.*, u.name, s.shift_date, s.shift_name, s.code, s.closed_at FROM shift_workers sw JOIN users u ON u.id = sw.user_id JOIN shifts s ON s.id = sw.shift_id
       WHERE s.shift_date BETWEEN ? AND ? ORDER BY s.shift_date, u.name`, [from, to]
    );
    const per = {};
    const detail = rows.map((w) => {
      const mins = minutesBetween(w.signed_on_at, w.signed_off_at || w.closed_at || null) || 0;
      per[w.name] = (per[w.name] || 0) + mins;
      const onEd = Math.abs(minutesBetween(w.signed_on_at, w.signed_on_recorded_at) || 0) > 2;
      return { date: w.shift_date, shift: w.shift_name, name: w.name, on: hhmm(w.signed_on_at) + (onEd ? ' *' : ''), off: w.signed_off_at ? hhmm(w.signed_off_at) : 'not signed off', hours: hoursMinutes(mins), _tone: !w.signed_off_at ? 'warn' : null };
    });
    return base('Baker Hours Report', {
      summary: Object.entries(per).map(([k, v]) => ({ label: k, value: hoursMinutes(v) })),
      sections: [{ title: 'Total hours per person', columns: [col('name', 'Name'), col('hours', 'Total hours', R)], rows: Object.entries(per).map(([k, v]) => ({ name: k, hours: hoursMinutes(v) })) },
        { title: 'Every shift', columns: [col('date', 'Date'), col('shift', 'Shift'), col('name', 'Name'), col('on', 'On'), col('off', 'Off'), col('hours', 'Hours', R)], rows: detail, note: '* time entered manually' }],
    });
  }
  if (id === 'ingredients') {
    return base('Ingredient Usage Report', {
      summary: [{ label: 'Batches', value: String(db().get("SELECT COUNT(*) AS c FROM batches WHERE substr(started_at,1,10) BETWEEN ? AND ?", [from, to]).c) },
        { label: 'Flagged ingredient entries', value: String(db().get("SELECT COUNT(*) AS c FROM batch_ingredients bi JOIN batches b ON b.id = bi.batch_id WHERE bi.flagged = 1 AND substr(b.started_at,1,10) BETWEEN ? AND ?", [from, to]).c), tone: 'warn' }],
      sections: [{ title: 'Ingredients in batches', columns: ING_COLS, rows: ingredientRows('substr(b.started_at,1,10) BETWEEN ? AND ?', [from, to]) }],
    });
  }
  if (id === 'wastage') {
    const mat = db().all(
      `SELECT t.txn_date, t.txn_time, t.qty, t.note, m.name, m.unit, u.name AS user_name FROM transactions t JOIN materials m ON m.id = t.material_id
       JOIN users u ON u.id = t.user_id WHERE t.type = 'WASTAGE' AND t.txn_date BETWEEN ? AND ? ORDER BY t.id`, [from, to]
    ).map((w) => ({ date: w.txn_date, time: w.txn_time, item: w.name, qty: fmt(w.qty, w.unit), reason: w.note || '', by: w.user_name }));
    const prod = listBatches({ from, to, status: 'finished', limit: 5000 }).filter((b) => (b.damaged || 0) + (b.rejected || 0) + (b.other_waste || 0) > 0)
      .map((b) => ({ date: b.started_at.slice(0, 10), batch: b.code, product: b.product_name, damaged: fmt(b.damaged), rejected: fmt(b.rejected), other: fmt(b.other_waste), comments: b.comments || '' }));
    return base('Wastage Report', {
      summary: [{ label: 'Ingredient wastage entries', value: String(mat.length) }, { label: 'Batches with losses', value: String(prod.length) }],
      sections: [{ title: 'Ingredient wastage', columns: [col('date', 'Date'), col('time', 'Time'), col('item', 'Item'), col('qty', 'Qty', R), col('reason', 'Reason'), col('by', 'By')], rows: mat },
        { title: 'Product losses', columns: [col('date', 'Date'), col('batch', 'Batch'), col('product', 'Product'), col('damaged', 'Damaged', R), col('rejected', 'Rejected', R), col('other', 'Other', R), col('comments', 'Comments')], rows: prod }],
    });
  }
  if (id === 'receipts') {
    const rows = db().all(
      `SELECT t.txn_date, t.txn_time, t.qty, t.supplier, t.invoice_no, m.name, m.unit, u.name AS user_name FROM transactions t JOIN materials m ON m.id = t.material_id
       JOIN users u ON u.id = t.user_id WHERE t.type = 'RECEIVE' AND t.txn_date BETWEEN ? AND ? ORDER BY t.id`, [from, to]
    ).map((r) => ({ date: r.txn_date, time: r.txn_time, supplier: r.supplier || '—', invoice: r.invoice_no || '—', item: r.name, qty: fmt(r.qty, r.unit), by: r.user_name }));
    return base('Stock Received Report', {
      summary: [{ label: 'Lines received', value: String(rows.length) }, { label: 'Invoices', value: String(new Set(rows.map((r) => r.supplier + r.invoice)).size) }],
      sections: [{ title: 'Deliveries', columns: [col('date', 'Date'), col('time', 'Time'), col('supplier', 'Supplier'), col('invoice', 'Invoice'), col('item', 'Item'), col('qty', 'Qty', R), col('by', 'Received by')], rows }],
    });
  }
  if (id === 'stock') {
    const low = lowStockItems().map((m) => m.id);
    const rows = db().all('SELECT m.*, s.name AS supplier_name FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id WHERE m.active = 1 AND m.track_stock = 1 ORDER BY m.name')
      .map((m) => ({ name: m.name, code: m.code || '—', stock: fmt(m.stock, m.unit), min: m.reorder_level ? fmt(m.reorder_level, m.unit) : '—', reorder: m.reorder_qty ? fmt(m.reorder_qty, m.unit) : '—', supplier: m.supplier_name || '—', status: low.includes(m.id) ? 'LOW' : 'OK', _tone: low.includes(m.id) ? 'bad' : null }));
    return base('Stock Levels', {
      subtitle: `${info.bakery} · as at ${info.generated}`, info: [['Bakery', `${info.bakery} – ${info.location}`], ['As at', info.generated]],
      summary: [{ label: 'Items', value: String(rows.length) }, { label: 'At or below minimum', value: String(low.length), tone: low.length ? 'bad' : 'good' }],
      sections: [{ title: 'Current stock', columns: [col('name', 'Material'), col('code', 'Code'), col('stock', 'In stock', R), col('min', 'Minimum', R), col('reorder', 'Reorder qty', R), col('supplier', 'Supplier'), col('status', 'Status')], rows }],
    });
  }
  if (id === 'costing') {
    const batches = listBatches({ from, to, status: 'finished', limit: 5000 }).reverse();
    const stats = batches.map((b) => ({ b, s: batchStats(b) }));
    const total = stats.reduce((a, x) => a + x.s.cost, 0);
    const lost = stats.reduce((a, x) => a + x.s.lossValue, 0);
    const wasteVal = db().all(`SELECT t.qty, m.cost_per_unit FROM transactions t JOIN materials m ON m.id = t.material_id WHERE t.type = 'WASTAGE' AND t.txn_date BETWEEN ? AND ?`, [from, to])
      .reduce((a, r) => a + r.qty * (r.cost_per_unit || 0), 0);
    const varVal = db().all(`SELECT t.qty, m.cost_per_unit FROM transactions t JOIN materials m ON m.id = t.material_id WHERE t.type = 'BALANCE' AND t.txn_date BETWEEN ? AND ?`, [from, to])
      .reduce((a, r) => a + r.qty * (r.cost_per_unit || 0), 0);
    const per = {};
    stats.forEach(({ b, s: st }) => { const t = (per[b.product_name] = per[b.product_name] || { cost: 0, good: 0 }); t.cost += st.cost; t.good += b.good || 0; });
    return base('Costing Report', {
      summary: [{ label: 'Ingredient cost', value: money(total, cur()) }, { label: 'Value of damaged/rejected', value: money(lost, cur()), tone: lost ? 'warn' : null },
        { label: 'Ingredient wastage value', value: money(wasteVal, cur()), tone: wasteVal ? 'warn' : null }, { label: 'Stock variance value', value: money(varVal, cur()), tone: varVal < 0 ? 'bad' : null }],
      sections: [{ title: 'Cost per product', columns: [col('product', 'Product'), col('good', 'Good made', R), col('cost', 'Ingredient cost', R), col('pc', 'Cost per piece', R)],
        rows: Object.entries(per).map(([k, v]) => ({ product: k, good: fmt(v.good), cost: money(v.cost, cur()), pc: v.good ? money(v.cost / v.good, cur()) : '—' })) },
      { title: 'Batches', columns: [col('date', 'Date'), col('code', 'Batch'), col('product', 'Product'), col('good', 'Good', R)].concat(COST_COLS),
        rows: batchRows(batches).map((r, i) => ({ date: batches[i].started_at.slice(0, 10), ...r })), note: '* some ingredients had no price at the time' }],
    });
  }
  if (id === 'plan') {
    const dates = db().all('SELECT DISTINCT plan_date FROM production_plan WHERE plan_date BETWEEN ? AND ? ORDER BY plan_date', [from, to]).map((r) => r.plan_date);
    const rows = dates.flatMap((d) => planRows(d).map((r) => ({ date: d, ...r })));
    return base('Plan vs Actual', {
      summary: [{ label: 'Days planned', value: String(dates.length) }, { label: 'Products short of plan', value: String(rows.filter((r) => r._tone).length), tone: 'warn' }],
      sections: [{ title: 'Plan vs actual by day', columns: [col('date', 'Date')].concat(PLAN_COLS), rows }],
    });
  }
  if (id === 'checklists') {
    const runs = db().all('SELECT DISTINCT shift_id FROM checklist_runs WHERE run_date BETWEEN ? AND ? AND shift_id IS NOT NULL', [from, to]);
    const rows = runs.flatMap((r) => { const sh = getShift(r.shift_id); return checklistRows(shiftChecklistRows(r.shift_id)).map((x) => ({ date: sh.shift_date, shift: sh.shift_name, ...x })); });
    return base('Checklists & Temperatures', {
      summary: [{ label: 'Items recorded', value: String(rows.length) }, { label: 'Not done / out of range', value: String(rows.filter((r) => r._tone === 'bad').length), tone: 'bad' },
        { label: 'Skipped', value: String(rows.filter((r) => r._tone === 'warn').length), tone: 'warn' }],
      sections: [{ title: 'Checklist log', columns: [col('date', 'Date'), col('shift', 'Shift')].concat(CHECK_COLS), rows }],
    });
  }
  if (id === 'suppliers') {
    const rows = db().all(
      `SELECT t.txn_date, t.supplier, t.invoice_no, t.qty, t.unit_cost, t.lot_no, t.expiry, t.check_note, m.name, m.unit, t.material_id, t.supplier_id
       FROM transactions t JOIN materials m ON m.id = t.material_id WHERE t.type = 'RECEIVE' AND t.txn_date BETWEEN ? AND ? ORDER BY t.id`, [from, to]
    );
    const lastPrice = {};
    const out = rows.map((r) => {
      const k = `${r.supplier_id}-${r.material_id}`;
      const prev = lastPrice[k];
      if (r.unit_cost !== null) lastPrice[k] = r.unit_cost;
      const change = r.unit_cost !== null && prev ? r1(((r.unit_cost - prev) / prev) * 100) : null;
      return { date: r.txn_date, supplier: r.supplier || '—', invoice: r.invoice_no || '—', item: r.name, qty: fmt(r.qty, r.unit),
        price: r.unit_cost === null ? '—' : `${money(r.unit_cost, cur())}/${r.unit}`, change: change === null ? '—' : `${change > 0 ? '+' : ''}${change}%`,
        total: r.unit_cost === null ? '—' : money(r.unit_cost * r.qty, cur()), check: r.check_note || '—', _tone: change !== null && change > 5 ? 'warn' : /NOT OK/.test(r.check_note || '') ? 'bad' : null };
    });
    const spend = rows.reduce((a, r) => a + (r.unit_cost || 0) * r.qty, 0);
    return base('Supplier Prices & Deliveries', {
      summary: [{ label: 'Deliveries', value: String(new Set(rows.map((r) => r.supplier + r.invoice_no)).size) }, { label: 'Spend (priced lines)', value: money(spend, cur()) },
        { label: 'Price rises over 5%', value: String(out.filter((o) => o._tone === 'warn').length), tone: 'warn' }],
      sections: [{ title: 'Deliveries and prices', columns: [col('date', 'Date'), col('supplier', 'Supplier'), col('invoice', 'Invoice'), col('item', 'Item'), col('qty', 'Qty', R),
        col('price', 'Unit price', R), col('change', 'Change', R), col('total', 'Line total', R), col('check', 'Delivery check')], rows: out }],
    });
  }
  if (id === 'expiry') {
    const today = stamp().slice(0, 10);
    const lots = listLots({ openOnly: true });
    const rows = lots.map((l) => ({ item: l.name, lot: l.lot_no || '—', expiry: l.expiry || '—', left: fmt(l.qty_left, l.unit), received: l.received_at.slice(0, 10),
      supplier: l.supplier_name || '—', invoice: l.invoice_no || '—', _tone: l.expiry && l.expiry < today ? 'bad' : null }));
    return base('Lots & Expiry', {
      subtitle: `${info.bakery} · as at ${info.generated}`,
      summary: [{ label: 'Open lots', value: String(lots.length) }, { label: 'Expired', value: String(rows.filter((r) => r._tone === 'bad').length), tone: 'bad' }],
      sections: [{ title: 'Stock lots (oldest expiry first)', columns: [col('item', 'Item'), col('lot', 'Lot'), col('expiry', 'Expiry'), col('left', 'Left', R), col('received', 'Received'), col('supplier', 'Supplier'), col('invoice', 'Invoice')], rows }],
    });
  }
  if (id === 'equipment') {
    const rows = db().all(
      `SELECT l.*, e.name, u.name AS user_name FROM equipment_log l JOIN equipment e ON e.id = l.equipment_id JOIN users u ON u.id = l.user_id
       WHERE substr(l.at,1,10) BETWEEN ? AND ? ORDER BY l.id`, [from, to]
    ).map((l) => ({ date: l.at.slice(0, 16), name: l.name, type: l.type === 'fault' ? 'Fault' : l.type === 'repair' ? 'Repair' : 'Service', note: l.note,
      cost: l.cost === null ? '—' : money(l.cost, cur()), by: l.user_name, status: l.type === 'fault' ? (l.resolved_at ? 'Fixed' : 'OPEN') : '', _tone: l.type === 'fault' && !l.resolved_at ? 'warn' : null }));
    const eq = listEquipment().map((e) => ({ name: e.name, every: e.service_days ? `${e.service_days} days` : '—', last: (e.last_service_at || '—').slice(0, 10), due: e.serviceDue || '—',
      status: e.openFaults.length ? 'Fault open' : e.serviceOverdue ? 'Service due' : 'OK', _tone: e.openFaults.length || e.serviceOverdue ? 'warn' : null }));
    return base('Equipment Report', {
      summary: [{ label: 'Faults reported', value: String(rows.filter((r) => r.type === 'Fault').length) },
        { label: 'Repair & service cost', value: money(db().get('SELECT COALESCE(SUM(cost),0) AS c FROM equipment_log WHERE substr(at,1,10) BETWEEN ? AND ?', [from, to]).c, cur()) }],
      sections: [{ title: 'Equipment status', columns: [col('name', 'Equipment'), col('every', 'Service every'), col('last', 'Last service'), col('due', 'Next due'), col('status', 'Status')], rows: eq },
        { title: 'Log', columns: [col('date', 'When'), col('name', 'Equipment'), col('type', 'Type'), col('note', 'Details'), col('cost', 'Cost', R), col('by', 'By'), col('status', 'Status')], rows }],
    });
  }
  if (id === 'alerts') {
    const list = db().all(
      `SELECT a.*, u.name AS user_name, k.name AS ack_name FROM alerts a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN users k ON k.id = a.ack_by
       WHERE substr(a.created_at,1,10) BETWEEN ? AND ? ORDER BY a.id`, [from, to]
    );
    return base('Alerts Report', {
      summary: [{ label: 'Alerts', value: String(list.length) }, { label: 'Still open', value: String(list.filter((a) => !a.ack_at).length), tone: 'warn' }],
      sections: [{ title: 'Alerts', columns: [col('date', 'Date')].concat(ALERT_COLS), rows: alertRows(list).map((r, i) => ({ date: list[i].created_at.slice(0, 10), ...r })) }],
    });
  }
  return null;
}

// ================= PURCHASE ORDER =================
export function purchaseOrderDoc(poId) {
  const po = getPurchaseOrder(poId);
  if (!po) return null;
  const info = baseInfo();
  return {
    kind: 'po', id: poId, title: 'Purchase Order', fileName: po.po_no, subtitle: `${po.po_no} · ${po.created_at.slice(0, 10)}`,
    info: [['PO number', po.po_no], ['Date', po.created_at.slice(0, 16)], ['Supplier', po.supplier || '—'], ['Supplier email', po.supplier_email || '—'],
      ['Deliver to', `${info.bakery} – ${info.location}`], ['Raised by', po.created_by_name ? `${po.created_by_name} (minimum stock reached)` : 'Automatic (minimum stock reached)']],
    summary: [{ label: 'Items', value: String(po.items.length) }],
    sections: [{ title: 'Items to supply', columns: [col('name', 'Item'), col('code', 'Code'), col('qty', 'Quantity', R), col('unit', 'Unit'), col('stock', 'Current stock', R), col('min', 'Minimum', R)],
      rows: po.items.map((i) => ({ name: i.name, code: i.code || '—', qty: fmt(i.qty), unit: i.unit, stock: fmt(i.stock), min: fmt(i.min) })) }],
    po,
  };
}

// Small summary used by the in-app dashboard and the cloud dashboard.
export function recentShifts(n = 10) {
  return listShifts({ limit: n }).map((s) => ({ id: s.id, code: s.code, date: s.shift_date, name: s.shift_name, status: STATUS_LABEL[s.status], batches: s.batch_count }));
}
export { APP_VERSION };
