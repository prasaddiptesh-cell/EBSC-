// Home search and Scan: find screens (menu items), people, suppliers, invoices, purchase orders, cheques, licences and
// documents by name or number; read a scanned barcode. Only what the person may open is returned.
import { db } from '../db/connection.js';
import { allMenuItems } from './menus.js';

const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const like = (q) => `%${String(q).trim().replace(/[%_]/g, '')}%`;
// Which screen shows a document attached to a record of each kind.
const DOC_SCREEN = { licence: ['Licence', 'uid'], applicant: ['Applicant', 'uid'], contract: ['Contract', 'uid'], invoice: ['ApInvoice', 'uid'], payment: ['ApPayment', 'uid'] };

// Every result: { kind, icon, title, sub, nav: { screen, params } }.
export function searchAll(user, q, { modules = [], screens = null, limit = 40 } = {}) {
  const text = String(q || '').trim();
  if (!user || text.length < 2) return [];
  const ok = (screen) => !screens || (screens[screen] && screens[screen].can(user));
  const out = [];
  const push = (r) => { if (r.nav && ok(r.nav.screen)) out.push(r); };
  const low = text.toLowerCase();
  // Screens (menu items).
  for (const it of allMenuItems(modules, user, screens)) {
    if (`${it.title} ${it.note || ''} ${it.moduleTitle}`.toLowerCase().includes(low)) {
      push({ kind: 'screen', icon: it.icon || '›', title: it.title, sub: `${it.moduleTitle} › ${it.section}`, nav: { screen: it.screen, params: it.params || {} } });
    }
  }
  const L = like(text);
  const q2 = (sql, args) => { try { return db().all(sql, args); } catch (e) { return []; } };
  if (has('users')) {
    q2("SELECT id, name, employee_no, role, shop_code FROM users WHERE active = 1 AND (name LIKE ? OR employee_no LIKE ?) ORDER BY name LIMIT 10", [L, L])
      .forEach((u) => push({ kind: 'person', icon: '👤', title: u.name, sub: [u.employee_no, u.role, u.shop_code].filter(Boolean).join(' · '), nav: { screen: 'UserEdit', params: { id: u.id } } }));
  }
  if (has('ap_suppliers')) {
    q2('SELECT uid, name, tin FROM ap_suppliers WHERE name LIKE ? OR tin LIKE ? ORDER BY name LIMIT 10', [L, L])
      .forEach((s) => push({ kind: 'supplier', icon: '🏷️', title: s.name, sub: s.tin ? `TIN ${s.tin}` : 'Supplier', nav: { screen: 'ApSupplierEdit', params: { uid: s.uid } } }));
  }
  if (has('ap_invoices')) {
    q2('SELECT uid, invoice_no, supplier_name, invoice_date, total, kind FROM ap_invoices WHERE invoice_no LIKE ? OR supplier_name LIKE ? ORDER BY invoice_date DESC LIMIT 10', [L, L])
      .forEach((i) => push({ kind: 'invoice', icon: '🧾', title: `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} ${i.invoice_no || '(no number)'} · ${i.supplier_name || ''}`, sub: `${i.invoice_date} · ${Number(i.total || 0).toFixed(2)}`, nav: { screen: 'ApInvoice', params: { uid: i.uid } } }));
  }
  if (has('po_orders')) {
    q2('SELECT uid, po_no, supplier_name, order_date, status FROM po_orders WHERE po_no LIKE ? OR supplier_name LIKE ? ORDER BY order_date DESC LIMIT 10', [L, L])
      .forEach((o) => push({ kind: 'po', icon: '📝', title: `Purchase order ${o.po_no} · ${o.supplier_name || ''}`, sub: `${o.order_date} · ${o.status}`, nav: { screen: 'POView', params: { uid: o.uid } } }));
  }
  if (has('cheques')) {
    q2("SELECT uid, cheque_no, payee, amount, cheque_date, payment_uid, status FROM cheques WHERE CAST(cheque_no AS TEXT) LIKE ? OR payee LIKE ? ORDER BY cheque_date DESC LIMIT 10", [L, L])
      .forEach((c) => push({ kind: 'cheque', icon: '🏦', title: `Cheque ${c.cheque_no} · ${c.payee || ''}`, sub: `${c.cheque_date} · ${Number(c.amount || 0).toFixed(2)} · ${c.status}`,
        nav: { screen: 'ChequeStub', params: { chequeUid: c.uid } } }));
  }
  if (has('licences')) {
    q2('SELECT uid, name, licence_no, expiry_date FROM licences WHERE name LIKE ? OR licence_no LIKE ? ORDER BY name LIMIT 10', [L, L])
      .forEach((l) => push({ kind: 'licence', icon: '📜', title: l.name, sub: `${l.licence_no ? `No. ${l.licence_no} · ` : ''}${l.expiry_date ? `expires ${l.expiry_date}` : ''}`, nav: { screen: 'Licence', params: { uid: l.uid } } }));
  }
  if (has('documents')) {
    q2("SELECT uid, name, ref_type, ref_uid, doc_date FROM documents WHERE status = 'active' AND name LIKE ? ORDER BY doc_date DESC LIMIT 10", [L])
      .forEach((d) => { const m = DOC_SCREEN[d.ref_type]; if (m) push({ kind: 'document', icon: '📄', title: d.name, sub: `Document · ${d.ref_type}${d.doc_date ? ` · ${d.doc_date}` : ''}`, nav: { screen: m[0], params: { [m[1]]: d.ref_uid } } }); });
  }
  if (has('inv_items')) {
    q2('SELECT uid, code, name, barcode FROM inv_items WHERE active = 1 AND (name LIKE ? OR code LIKE ? OR barcode = ?) ORDER BY name LIMIT 10', [L, L, text])
      .forEach((p) => push({ kind: 'product', icon: '📦', title: p.name, sub: `Product ${p.code}${p.barcode ? ` · ${p.barcode}` : ''}`, nav: { screen: 'InvProduct', params: { uid: p.uid } } }));
  }
  return out.slice(0, limit);
}

// A scanned (or typed) code → what it is. Document codes: "EB:<kind>:<id>" or the document's own number (purchase
// order, invoice, cheque); anything else is tried as a product barcode or code.
// Returns { found: true, kind, title, nav, allowed } or { found: false, message }.
const KIND = { po: ['po_orders', 'uid', 'POView'], inv: ['ap_invoices', 'uid', 'ApInvoice'], pay: ['ap_payments', 'uid', 'ApPayment'], lic: ['licences', 'uid', 'Licence'], till: ['till_counts', 'uid', 'TillCountView'], prod: ['inv_items', 'uid', 'InvProduct'] };
export function resolveCode(user, code, { screens = null } = {}) {
  const c = String(code || '').trim();
  if (!c) return { found: false, message: 'No code read.' };
  const allowed = (screen) => !screens || !!(screens[screen] && screens[screen].can(user));
  const res = (kind, title, nav) => ({ found: true, kind, title, nav, allowed: allowed(nav.screen) });
  const one = (sql, args) => { try { return db().get(sql, args); } catch (e) { return null; } };
  const m = /^EB[:\-](\w+)[:\-](.+)$/i.exec(c);
  if (m && KIND[m[1].toLowerCase()]) {
    const [table, key, screen] = KIND[m[1].toLowerCase()];
    const row = has(table) ? one(`SELECT * FROM ${table} WHERE ${key} = ?`, [m[2]]) : null;
    if (!row) return { found: false, message: 'This document is not in the app (not found or changed).' };
    return res('document', row.po_no ? `Purchase order ${row.po_no}` : row.invoice_no ? `Invoice ${row.invoice_no}` : row.name || m[2], { screen, params: { uid: row.uid } });
  }
  if (has('po_orders')) { const r = one('SELECT uid, po_no FROM po_orders WHERE po_no = ?', [c]); if (r) return res('po', `Purchase order ${r.po_no}`, { screen: 'POView', params: { uid: r.uid } }); }
  if (has('ap_invoices')) { const r = one('SELECT uid, invoice_no, supplier_name FROM ap_invoices WHERE invoice_no = ? ORDER BY invoice_date DESC', [c]); if (r) return res('invoice', `Invoice ${r.invoice_no} · ${r.supplier_name || ''}`, { screen: 'ApInvoice', params: { uid: r.uid } }); }
  if (has('inv_items')) {
    const p = one('SELECT uid, name, code, barcode, price FROM inv_items WHERE barcode = ? OR code = ? ORDER BY active DESC', [c, c]);
    if (p) return { ...res('product', p.name, { screen: 'InvProduct', params: { uid: p.uid } }), product: p };
  }
  if (/^\d{1,8}$/.test(c) && has('cheques')) {
    const r = one('SELECT uid, cheque_no, payee, payment_uid FROM cheques WHERE cheque_no = ?', [Number(c)]);
    if (r) return res('cheque', `Cheque ${r.cheque_no} · ${r.payee || ''}`, { screen: 'ChequeStub', params: { chequeUid: r.uid } });
  }
  return { found: false, message: /^\d{8,14}$/.test(c) ? 'This product is not in the app. Add it in Aronium first, then import the products.' : 'Not found in the app.' };
}
