// Parts of a document the admin can leave out of the printed / sent copy, keyed by "section keys".
// Generic: any document can declare its keys; rows (or whole tables) carry `_key`, or a classifier works the key out.
// Used now for the payslip: the on-screen version (the one staff sign) is always full; the printed and sent copies
// follow these settings, with separate settings for the 80 mm printer and for PDF. Gross, every deduction and net
// are on by default; switching one off is logged, warned about and the copy shows a ⚠️ marker.
import { getShared, setShared, audit, AppError } from './core.js';

export const MEDIA = [{ id: 'pdf', label: 'PDF / A4 / sent' }, { id: '80mm', label: '80 mm printer' }];

// Payslip section keys. `ded:<name>` = one deduction line (one key per deduction type).
export const PAYSLIP_SECTIONS = [
  { key: 'earnings', label: 'Hours and earnings lines', important: false },
  { key: 'gross', label: 'Gross pay', important: true },
  { key: 'ded:PAYE tax', label: 'Deduction: PAYE tax', important: true },
  { key: 'ded:FNPF', label: 'Deduction: FNPF (staff)', important: true },
  { key: 'deductions_other', label: 'Other deductions (each one, see below)', important: true },
  { key: 'net', label: 'Net pay', important: true },
  { key: 'bank', label: 'Bank account on the net pay line', important: false },
  { key: 'fnpf_employer', label: 'FNPF paid by Easy Buys', important: false },
  { key: 'ytd', label: 'Year to date', important: false },
];
export const isImportant = (key) => key === 'gross' || key === 'net' || String(key).startsWith('ded:') || key === 'deductions_other';

// Which payslip line a row is. Rows made by payroll may already say (`_key`, e.g. from payslipSections()).
export function payslipRowKey(row) {
  if (row && row._key) return String(row._key);
  const item = String((row && row.item) || '').trim();
  const detail = String((row && row.detail) || '').trim();
  if (/^gross pay$/i.test(item)) return 'gross';
  if (/^net pay$/i.test(item)) return 'net';
  if (/^paye/i.test(item)) return 'ded:PAYE tax';
  if (/^fnpf paid by/i.test(item)) return 'fnpf_employer';
  if (/^fnpf$/i.test(item)) return 'ded:FNPF';
  if (/^year to date/i.test(item)) return 'ytd';
  if (/deduction/i.test(detail)) return `ded:${item}`;
  return 'earnings';
}

// ---------------------------------------------------------------- settings ("doc_sections" shared setting)
// { payslip: { pdf: { key: false, ... }, '80mm': {...} } } – only switched-off keys are stored.
const KEY = 'doc_sections';
const read = () => { const s = getShared(KEY, {}) || {}; return typeof s === 'object' ? s : {}; };
export function sectionSettings(docType, medium) {
  const s = read()[docType] || {};
  return { ...(s[medium === '80mm' ? '80mm' : 'pdf'] || {}) };
}
export const sectionOn = (settings, key) => {
  if (settings[key] === false) return false;
  if (key.startsWith('ded:') && !['ded:PAYE tax', 'ded:FNPF'].includes(key) && settings.deductions_other === false && settings[key] !== true) return false;
  return true;
};
// Turning an important part off needs `confirmed` (the screen shows the warning first). Every change is logged.
export function setSection(user, docType, medium, key, on, { confirmed = false } = {}) {
  const m = medium === '80mm' ? '80mm' : 'pdf';
  if (!on && isImportant(key) && !confirmed) throw new AppError('This hides pay figures from the printed / sent payslip. Confirm the warning first.');
  const s = read();
  const t = { ...(s[docType] || {}) };
  const cur = { ...(t[m] || {}) };
  const before = cur[key] !== false;
  if (on) { if (key.startsWith('ded:') && cur.deductions_other === false) cur[key] = true; else delete cur[key]; } else cur[key] = false;
  t[m] = cur;
  s[docType] = t;
  setShared(KEY, s);
  audit({ user, action: `${on ? 'Showed' : 'Hid'} "${key}" on the ${m === '80mm' ? '80 mm' : 'PDF'} ${docType}`, table: 'shared_settings', recordUid: `${KEY}:${docType}:${m}`, before: { on: before }, after: { on: !!on },
    reason: !on && isImportant(key) ? 'Warning shown and accepted: pay figures hidden from the printed / sent copy' : null });
  return sectionSettings(docType, m);
}
export function resetSections(user, docType, medium) {
  const s = read();
  const t = { ...(s[docType] || {}) };
  delete t[medium === '80mm' ? '80mm' : 'pdf'];
  s[docType] = t;
  setShared(KEY, s);
  audit({ user, action: `Payslip parts back to standard (${medium})`, table: 'shared_settings', recordUid: `${KEY}:${docType}` });
}
// Important parts switched off (for the warning list and the ⚠️ marker).
export function hiddenImportant(settings) { return Object.entries(settings).filter(([k, v]) => v === false && isImportant(k)).map(([k]) => k); }

// ---------------------------------------------------------------- applying
// keyOf(row, section) → key or null (rows with no key always stay). Whole tables can carry `_key` too.
export function applySectionToggles(rep, settings, { keyOf = (r) => (r && r._key) || null, transform = null, marker = '⚠️ Some figures are not shown on this copy (admin setting).' } = {}) {
  if (!rep) return rep;
  let hidden = 0;
  const sections = (rep.sections || []).filter((sec) => !(sec._key && !sectionOn(settings, sec._key))).map((sec) => {
    const rows = [];
    for (const r of sec.rows || []) {
      const k = keyOf(r, sec);
      if (k && !sectionOn(settings, k)) { if (isImportant(k)) hidden += 1; continue; }
      rows.push(transform ? transform(r, k, settings) : r);
    }
    return { ...sec, rows };
  });
  const out = { ...rep, sections };
  if (hidden) out.warningMark = marker;
  return out;
}
// The printed / sent payslip (A4 PDF or 80 mm) following the admin's settings.
export function payslipForPrint(rep, medium = 'pdf') {
  const settings = sectionSettings('payslip', medium);
  return applySectionToggles(rep, settings, {
    keyOf: (r) => payslipRowKey(r),
    transform: (r, k, st) => (k === 'net' && st.bank === false ? { ...r, detail: /^to /i.test(String(r.detail || '')) ? 'to bank' : r.detail } : r),
    marker: '⚠️ Some pay figures are not shown on this copy (admin setting). Ask the office for the full payslip.',
  });
}
export const isPayslip = (rep) => !!rep && ['payslips', 'payslip'].includes(String(rep.kind || '')) || (rep && rep.docType === 'payslip');
