// v3.9.8 The app checks itself once a day on every device (after a sync), and on demand from the Problem log:
//   the database is sound; syncing works; nothing is stuck waiting to go up; on the main tablet the till PCs are still
//   sending (Aronium link); and the main parts of the app (warnings, reports, set-up, bills, shop pages) work on the
//   real data. Anything wrong is written to the Problem log, which goes to support by itself (the problem loop).
// Never changes any record; every check has its own guard so one failure never stops the others.
import { db } from '../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, addDays } from './core.js';
import { logError } from './errorLog.js';

const hours = (t) => (t ? (Date.now() - Date.parse(String(t).replace(' ', 'T'))) / 3600000 : null);
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export function selfCheckResult() { try { return JSON.parse(getSetting('self_check', '') || 'null'); } catch (e) { return null; } }

export function runSelfCheck({ force = false, user = null, today = dateStr() } = {}) {
  const prev = selfCheckResult();
  if (!force && prev && prev.on === today) return prev;
  const out = { on: today, at: stamp(), ok: [], problems: [] };
  const step = (name, fn) => {
    const t = Date.now();
    try {
      const r = fn();
      const ms = Date.now() - t;
      if (r && r.problem) { out.problems.push(`${name}: ${r.problem}`); logError(new Error(r.problem), { where: `self-check: ${name}`, quiet: true }); }
      else out.ok.push(name);
      if (ms > 5000) out.problems.push(`${name}: slow (${Math.round(ms / 1000)} s)`);
    } catch (e) {
      out.problems.push(`${name}: ${String((e && e.message) || e).slice(0, 160)}`);
      logError(e, { where: `self-check: ${name}`, quiet: true });
    }
  };
  step('Database', () => {
    const r = db().get('PRAGMA quick_check');
    const v = r ? Object.values(r)[0] : 'ok';
    return v === 'ok' ? null : { problem: `the database check said "${String(v).slice(0, 100)}"` };
  });
  step('Sync', () => {
    if (!getSetting('cloud_url', '')) return null; // not linked: nothing to check
    const ok = hours(getSetting('last_sync_ok_at', ''));
    const err = getSetting('last_sync_error', '');
    if (ok === null) return null; // just linked / not synced yet: the sync light on the top bar already shows it
    if (ok > 24) return { problem: `no good sync for ${Math.round(ok)} hours${err ? ` (last error: ${err.slice(0, 120)})` : ''}` };
    return null;
  });
  step('Waiting to go up', () => {
    if (!has('outbox')) return null;
    const stuck = db().get("SELECT COUNT(*) AS n, MIN(created_at) AS oldest FROM outbox WHERE sent_at IS NULL AND (attempts >= 5 OR created_at < ?)", [addDays(today, -2)]);
    return stuck && stuck.n ? { problem: `${stuck.n} item(s) stuck since ${String(stuck.oldest || '').slice(0, 16)}` } : null;
  });
  step('Aronium link', () => {
    const L = require('../modules/aronium/link.js');
    if (!L.isLinkDevice()) return null;
    const st = L.linkStatus();
    const quiet = (st.tills || []).filter((t) => t.lastSeen && hours(t.lastSeen) > 26).map((t) => `${t.till} (${Math.round(hours(t.lastSeen))} h)`);
    return quiet.length ? { problem: `till PCs not heard from: ${quiet.join(', ')}` } : null;
  });
  // the main parts of the app on the real data (as the owner sees them)
  const owner = user || (() => { try { return db().get("SELECT * FROM users WHERE role IN ('owner','admin') AND active = 1 ORDER BY role DESC LIMIT 1"); } catch (e) { return null; } })();
  if (owner) {
    step('Warnings on Home', () => { require('./alerts.js').collectAlerts(owner); });
    step('Set-up steps', () => { require('./setupWizard.js').wizardSummary(); });
    step('Power & water bills', () => { require('./utilityBills.js').billBoard(today); });
    step('Product watch', () => { require('./productWatch.js').productProblems(); });
    step('Pending in & out', () => { require('../modules/accounting/insightReports.js').pendingSummary(today); });
    step('Monthly report', () => { const M = require('../modules/accounting/monthReport.js'); M.monthFigures(M.addMonths(today.slice(0, 7), -1)); });
    step('Shop pages', () => { const S = require('./shopProfile.js'); for (const s of db().all('SELECT code FROM shops WHERE active = 1')) S.shopDashboard(s.code, owner, today); });
  }
  out.ok = out.ok.filter((n) => !out.problems.some((p) => p.startsWith(`${n}:`)));
  setSetting('self_check', JSON.stringify(out));
  return out;
}
