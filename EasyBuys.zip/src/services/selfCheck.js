// v3.9.8 The app checks itself once a day on every device (after a sync), and on demand from the Problem log:
//   the database is sound; syncing works; nothing is stuck waiting to go up; on the main tablet the till PCs are still
//   sending (Aronium link); and the main parts of the app (warnings, reports, set-up, bills, shop pages) work on the
//   real data. Anything wrong is written to the Problem log, which goes to support by itself (the problem loop).
// Never changes any record; every check has its own guard so one failure never stops the others.
import { db } from '../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, addDays } from './core.js';
import { logError } from './errorLog.js';

const hours = (t) => (t ? (Date.now() - Date.parse(String(t).replace(' ', 'T'))) / 3600000 : null);
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };

export function selfCheckResult() { try { return JSON.parse(getSetting('self_check', '') || 'null'); } catch (e) { return null; } }

// The checks, in order: [name, fn]. fn returns null / { problem } (or throws).
function selfCheckSteps({ user, today }) {
  const steps = [];
  const step = (name, fn, later = null) => steps.push([name, fn, later]); // later: the same check made a part at a time (async)
  step('Database', (quick) => {
    const v = quick !== undefined ? quick : (() => { const r = db().get('PRAGMA quick_check'); return r ? Object.values(r)[0] : 'ok'; })();
    return v === 'ok' ? null : { problem: `the database check said "${String(v).slice(0, 100)}"` };
  });
  // 1.0.0 the stock totals per month (kept by the database itself) against the movements of the newest month
  step('Stock totals', () => {
    const r = require('../modules/inventory/stockMonths.js').checkStockMonths();
    return r.ok ? null : { problem: `the stock totals of ${r.month} did not match the stock movements – they were worked out again` };
  });
  // 1.0.0 a slice of the full check of a long change history (the rest after the next syncs)
  // (made a part at a time: the same 300 ms of checking in short pieces with a pause between them)
  step('Change history', () => { require('./watchdog.js').verifyChainStep({ budgetMs: 300 }); return null; },
    async (pause, wrap) => { const W = require('./watchdog.js'); const t0 = Date.now(); for (let i = 0; i < 12 && Date.now() - t0 < 600; i += 1) { const r = wrap(() => W.verifyChainStep({ budgetMs: 40, slice: 300 })); if (!r || r.done) break; await pause(); } return null; });
  step('Sync', () => {
    if (!getSetting('cloud_url', '')) return null; // not linked: nothing to check
    const ok = hours(getSetting('last_sync_ok_at', ''));
    const err = getSetting('last_sync_error', '');
    if (ok === null) return null; // just linked / not synced yet: the sync light on the top bar already shows it
    if (ok > 24) return { problem: `no good sync for ${Math.round(ok)} hours${err ? ` (last error: ${err.slice(0, 120)})` : ''}` };
    return null;
  });
  step('Waiting to go up', () => {
    if (!has('outbox')) return null;
    const stuck = db().get("SELECT COUNT(*) AS n, MIN(created_at) AS oldest FROM outbox WHERE sent_at IS NULL AND (attempts >= 5 OR created_at < ?)", [addDays(today, -2)]);
    return stuck && stuck.n ? { problem: `${stuck.n} item(s) stuck since ${String(stuck.oldest || '').slice(0, 16)}` } : null;
  });
  step('Aronium link', () => {
    const L = require('../modules/aronium/link.js');
    if (!L.isLinkDevice()) return null;
    const st = L.linkStatus();
    const quiet = (st.tills || []).filter((t) => t.lastSeen && hours(t.lastSeen) > 26).map((t) => `${t.till} (${Math.round(hours(t.lastSeen))} h)`);
    return quiet.length ? { problem: `till PCs not heard from: ${quiet.join(', ')}` } : null;
  });
  // the main parts of the app on the real data (as the owner sees them)
  const owner = user || (() => { try { return db().get("SELECT * FROM users WHERE role IN ('owner','admin') AND active = 1 ORDER BY role DESC LIMIT 1"); } catch (e) { return null; } })();
  if (owner) {
    step('Warnings on Home', () => { require('./alerts.js').collectAlerts(owner); }, async (pause) => { await require('./alerts.js').collectAlertsAsync(owner, { pause }); });
    step('Set-up steps', () => { require('./setupWizard.js').wizardSummary(); });
    step('Power & water bills', () => { require('./utilityBills.js').billBoard(today); });
    step('Product watch', () => { require('./productWatch.js').productProblems(); });
    step('Pending in & out', () => { require('../modules/accounting/insightReports.js').pendingSummary(today); });
    step('Monthly report', () => { const M = require('../modules/accounting/monthReport.js'); M.monthFigures(M.addMonths(today.slice(0, 7), -1)); });
    step('Shop pages', () => { const S = require('./shopProfile.js'); for (const s of db().all('SELECT code FROM shops WHERE active = 1')) S.shopDashboard(s.code, owner, today); },
      async (pause, wrap) => { const S = require('./shopProfile.js'); for (const s of wrap(() => db().all('SELECT code FROM shops WHERE active = 1'))) { wrap(() => S.shopDashboard(s.code, owner, today)); await pause(); } });
  }
  return steps;
}
export function runSelfCheck({ force = false, user = null, today = dateStr() } = {}) {
  const prev = selfCheckResult();
  if (!force && prev && prev.on === today) return prev;
  const out = { on: today, at: stamp(), ok: [], problems: [] };
  for (const [name, fn] of selfCheckSteps({ user, today })) runStep(out, name, () => fn());
  return finish(out);
}
// 1.0.0 the same checks with a pause after each, so the screens keep answering while the app checks itself (after a
// sync). On the phone the database check (it reads the whole file) runs on its own connection away from the screens
// (expo adapter quickCheckAsync); where there is none it runs as before.
// wrap: how each check's own saves are made (the sync passes withSystem: the app's own work, not a person's).
export async function runSelfCheckAsync({ force = false, user = null, today = dateStr(), pause = () => new Promise((r) => setTimeout(r, 0)), wrap = (f) => f() } = {}) {
  const prev = selfCheckResult();
  if (!force && prev && prev.on === today) return prev;
  const out = { on: today, at: stamp(), ok: [], problems: [] };
  for (const [name, fn, later] of wrap(() => selfCheckSteps({ user, today }))) {
    // (the database check runs on its own connection away from the screens; it is not run beside the other checks,
    // which save where they got to – two connections writing and reading at once can find the database locked)
    let quick;
    if (name === 'Database' && db().quickCheckAsync) { try { quick = await db().quickCheckAsync(); } catch (e) { quick = undefined; } }
    if (later) {
      const t = Date.now();
      let r = null; let err = null;
      try { r = await later(pause, wrap); } catch (e) { err = e; }
      wrap(() => runStep(out, name, () => { if (err) throw err; return r; }, Date.now() - t));
    } else wrap(() => runStep(out, name, () => fn(quick)));
    await pause();
  }
  return wrap(() => finish(out));
}
function runStep(out, name, fn, tookMs = null) {
  const t = Date.now();
  try {
    const r = fn();
    const ms = tookMs !== null ? tookMs : Date.now() - t;
    if (r && r.problem) { out.problems.push(`${name}: ${r.problem}`); logError(new Error(r.problem), { where: `self-check: ${name}`, quiet: true }); }
    else out.ok.push(name);
    if (ms > 5000) out.problems.push(`${name}: slow (${Math.round(ms / 1000)} s)`);
  } catch (e) {
    out.problems.push(`${name}: ${String((e && e.message) || e).slice(0, 160)}`);
    logError(e, { where: `self-check: ${name}`, quiet: true });
  }
}
function finish(out) {
  out.ok = out.ok.filter((n) => !out.problems.some((p) => p.startsWith(`${n}:`)));
  setSetting('self_check', JSON.stringify(out));
  return out;
}
