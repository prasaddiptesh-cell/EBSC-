// v3.9.8 Excel set-up pack: one workbook with a sheet for each part of moving in that is quicker typed in Excel –
// suppliers (with budgets, order days, Viber group), the products each supplier sells (their code, cost), bill
// accounts (EFL / WAF numbers), M-PAiSA wallets with their opening balance, and who approves orders for which shop.
// 1. packDoc()   – the workbook, already filled with what is in the app (edit it, add rows)
// 2. readPack()  – the filled workbook read back: a preview per sheet (new / changed / same / problems), nothing saved
// 3. applyPack() – saves the rows that were OK in the preview, through the normal rules of each part
// Never touches Aronium. A row that cannot be saved is skipped with the reason; the rest still goes in.
import { db } from '../db/connection.js';
import { stamp, dateStr, AppError } from './core.js';
import { requirePerm, asService } from './guard.js';

const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const low = (v) => txt(v).toLowerCase();
const num = (v) => { const s = txt(v).replace(/[$,\s]/g, ''); if (!s) return null; const n = Number(s); return Number.isFinite(n) ? n : NaN; };
const isoDate = (v) => { const t = txt(v); const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(t); return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : t.slice(0, 10); };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const x = f(); return x === undefined ? d : x; } catch (e) { return d; } };
const col = (key, title) => ({ key, title, align: 'left' });
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

// Each sheet: its name (also the sheet's title in Excel) and columns. Headers are matched by name when read back,
// so columns may be moved; extra columns are ignored.
export const SHEETS = [
  { key: 'suppliers', title: 'Suppliers', cols: [['name', 'Supplier'], ['other', 'Other names'], ['tin', 'TIN'], ['phone', 'Phone'], ['terms', 'Days to pay'], ['payMethod', 'Paid by (cheque / cash / transfer)'],
    ['budgetMonthly', 'Monthly budget'], ['budgetWeekly', 'Weekly budget'], ['orderDays', 'Order days (Mon,Thu)'], ['leadDays', 'Delivery days'], ['viberGroup', 'Viber group'],
    ['address', 'Address'], ['category', 'What they supply']] },
  { key: 'products', title: 'Supplier products', cols: [['supplier', 'Supplier'], ['code', 'Their code'], ['name', 'Name on their invoice'], ['unit', 'Unit'], ['pack', 'Carton / pack'],
    ['cost', 'Last cost excl. VAT'], ['vat', 'VAT %'], ['date', 'Last bought'], ['barcode', 'Barcode'], ['itemCode', 'Aronium code (fill in if known)'], ['itemName', 'Aronium name'], ['main', 'Main supplier (Y/N)']] },
  { key: 'bills', title: 'Bill accounts', cols: [['shop', 'Shop (S1, S2…)'], ['kind', 'Kind (Power / Water / Phone / Internet / Rent / Other)'], ['label', 'Name'], ['accountNo', 'Account number'], ['meterNo', 'Meter number'], ['holder', 'Name on the bill']] },
  { key: 'wallets', title: 'MPAiSA wallets', cols: [['name', 'Wallet'], ['shop', 'Shop (S1, S2…)'], ['phone', 'Phone number'], ['date', 'Opening date (YYYY-MM-DD)'], ['opening', 'Opening balance']] },
  { key: 'approvers', title: 'Order approvers', cols: [['person', 'Person'], ['shops', 'Shops they approve (S1, S2)']] },
];
const KIND_WORDS = { power: ['power', 'electricity', 'efl'], water: ['water', 'waf'], phone: ['phone', 'telephone'], internet: ['internet', 'wifi', 'broadband'], rent: ['rent'], other: ['other'] };
const kindOf = (v) => { const s = low(v); for (const [k, w] of Object.entries(KIND_WORDS)) if (w.some((x) => s.includes(x))) return k; return s ? null : 'other'; };

// ---------------------------------------------------------------- 1. the workbook
export function packDoc() {
  const I = safe(() => require('../modules/inventory/service.js'), null);
  const sups = has('ap_suppliers') ? safe(() => db().all('SELECT * FROM ap_suppliers WHERE active = 1 ORDER BY name'), []) : [];
  const rows = {
    suppliers: sups.map((s) => ({ name: s.name, other: '', tin: s.tin || '', phone: s.phone || '', terms: s.terms_days === null || s.terms_days === undefined ? '' : s.terms_days, payMethod: s.pay_method || '',
      budgetMonthly: s.budget_monthly === null || s.budget_monthly === undefined ? '' : s.budget_monthly, budgetWeekly: s.budget_weekly === null || s.budget_weekly === undefined ? '' : s.budget_weekly,
      orderDays: s.order_days || '', leadDays: s.lead_days === null || s.lead_days === undefined ? '' : s.lead_days, viberGroup: s.viber_group || '' })),
    products: has('inv_item_suppliers') ? safe(() => db().all(`SELECT s.name AS supplier, l.supplier_code AS code, i.name AS itemName, i.code AS itemCode, i.unit, l.last_cost AS cost, l.last_date AS date, CASE WHEN i.supplier_uid = l.supplier_uid THEN 'Y' ELSE '' END AS main
      FROM inv_item_suppliers l JOIN inv_items i ON i.uid = l.item_uid JOIN ap_suppliers s ON s.uid = l.supplier_uid WHERE l.active = 1 ORDER BY s.name, i.name`), []).map((r) => ({ ...r, name: '', pack: '', vat: '', barcode: '', cost: r.cost === null ? '' : r.cost, date: r.date || '', code: r.code || '' })) : [],
    bills: has('shop_accounts') ? safe(() => db().all('SELECT shop_code AS shop, kind, label, account_no AS accountNo, meter_no AS meterNo, holder FROM shop_accounts WHERE active = 1 ORDER BY shop_code, kind'), []).map((r) => ({ ...r, kind: r.kind ? r.kind[0].toUpperCase() + r.kind.slice(1) : '', meterNo: r.meterNo || '', holder: r.holder || '' })) : [],
    wallets: has('wallets') ? safe(() => db().all('SELECT name, shop_code AS shop, phone_no AS phone, opening_date AS date, opening_balance AS opening FROM wallets WHERE active = 1 ORDER BY name'), []).map((r) => ({ ...r, phone: r.phone || '' })) : [],
    approvers: Object.entries(safe(() => require('./core.js').getShared('po_approver_shops', {}), {}) || {}).map(([uid, shops]) => ({ person: safe(() => db().get('SELECT name FROM users WHERE uid = ?', [uid]).name, uid), shops: (shops || []).join(', ') })),
  };
  void I;
  return {
    kind: 'setup_pack', title: 'Easy Buys Set-up Pack', fileName: `Easy-Buys-Set-up-Pack-${dateStr()}`, subtitle: 'Fill in each sheet, then bring it back into the app (Admin › Set-up pack › Bring it in).',
    info: [['Made', stamp()], ['How', 'Keep the first row (the headings) of each sheet. Add or change rows below them. Leave a cell empty to keep what the app has.']],
    summary: SHEETS.map((s) => ({ label: s.title, value: `${rows[s.key].length} row${rows[s.key].length === 1 ? '' : 's'} now` })),
    sections: SHEETS.map((s) => ({ title: s.title, columns: s.cols.map(([k, t]) => col(k, t)), rows: rows[s.key] })),
  };
}

// ---------------------------------------------------------------- 2. reading it back
// sheets: { 'Sheet name': [[cell, cell…], …] } (the first row holds the headings).
function rowsOf(sheet, def) {
  if (!Array.isArray(sheet) || !sheet.length) return [];
  const headers = sheet[0].map((h) => low(h).replace(/\s+/g, ' '));
  const at = {};
  for (const [k, t] of def.cols) {
    const want = low(t);
    let i = headers.indexOf(want);
    if (i < 0) i = headers.findIndex((h) => h && (h.startsWith(want.split(' (')[0]) || want.startsWith(h)));
    if (i >= 0) at[k] = i;
  }
  return sheet.slice(1).map((r, n) => ({ _row: n + 2, ...Object.fromEntries(Object.entries(at).map(([k, i]) => [k, r[i] === undefined || r[i] === null ? '' : r[i]])) }))
    .filter((r) => Object.entries(r).some(([k, v]) => k !== '_row' && txt(v)));
}
const findSheet = (sheets, def) => { const e = Object.entries(sheets || {}).find(([n]) => low(n) === low(def.title) || low(n).replace(/[^a-z]/g, '') === low(def.title).replace(/[^a-z]/g, '')); return e ? e[1] : null; };
const words = (s) => low(s).replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((w) => w.length > 1);
export function nameScore(a, b) {
  const A = new Set(words(a)); const B = new Set(words(b));
  if (!A.size || !B.size) return 0;
  let same = 0;
  for (const w of A) if (B.has(w) || [...B].some((x) => x.length >= 4 && w.length >= 4 && (x.startsWith(w) || w.startsWith(x)))) same += 1;
  return Math.round((same / Math.max(A.size, B.size)) * 100) / 100;
}
function supplierFinder(extra = []) {
  const list = has('ap_suppliers') ? safe(() => db().all('SELECT uid, name, tin FROM ap_suppliers'), []) : [];
  return (name, tin) => {
    const n = low(name);
    const t = txt(tin).replace(/[\s-]/g, '');
    return list.find((s) => low(s.name) === n) || (t && list.find((s) => s.tin === t)) || extra.find((s) => low(s.name) === n || (s.other || []).includes(n)) || null;
  };
}
function itemFinder() {
  const I = safe(() => require('../modules/inventory/service.js'), null);
  const items = has('inv_items') ? safe(() => db().all('SELECT uid, code, name FROM inv_items WHERE IFNULL(active,1) = 1'), []) : [];
  const byCode = new Map(items.map((i) => [low(i.code), i]));
  const byName = new Map(items.map((i) => [low(i.name), i]));
  const links = has('inv_item_suppliers') ? safe(() => db().all('SELECT item_uid, supplier_uid, supplier_code FROM inv_item_suppliers WHERE supplier_code IS NOT NULL'), []) : [];
  return (r, supplierUid) => {
    if (txt(r.itemCode) && byCode.get(low(r.itemCode))) return { item: byCode.get(low(r.itemCode)), how: 'code' };
    if (txt(r.barcode) && I) { const x = safe(() => I.findItem(txt(r.barcode)), null); if (x) return { item: x, how: 'barcode' }; }
    if (txt(r.itemName) && byName.get(low(r.itemName))) return { item: byName.get(low(r.itemName)), how: 'name' };
    if (supplierUid && txt(r.code)) { const l = links.find((x) => x.supplier_uid === supplierUid && low(x.supplier_code) === low(r.code)); if (l) return { item: items.find((i) => i.uid === l.item_uid), how: 'their code' }; }
    if (byName.get(low(r.name))) return { item: byName.get(low(r.name)), how: 'name' };
    let best = null;
    for (const i of items) { const s = Math.max(nameScore(r.itemName || r.name, i.name)); if (!best || s > best.s) best = { s, i }; }
    if (best && best.s >= 0.6) return { item: best.i, how: `close name (${Math.round(best.s * 100)}%)`, guess: true };
    return { item: null, closest: best && best.s >= 0.3 ? best.i.name : null };
  };
}

export function readPack(sheets) {
  const out = {};
  const supRows = rowsOf(findSheet(sheets, SHEETS[0]), SHEETS[0]);
  const findSup = supplierFinder(supRows.map((r) => ({ name: txt(r.name), other: txt(r.other).split(/[;,]/).map(low).filter(Boolean), uid: null })));
  // suppliers
  out.suppliers = supRows.map((r) => {
    const p = [];
    if (!txt(r.name)) p.push('No supplier name');
    const tin = txt(r.tin).replace(/[\s-]/g, '');
    if (tin && !/^\d{6,15}$/.test(tin)) p.push('TIN should be numbers only');
    for (const k of ['budgetMonthly', 'budgetWeekly', 'leadDays', 'terms']) { const v = num(r[k]); if (Number.isNaN(v) || (v !== null && v < 0)) p.push(`${SHEETS[0].cols.find((c) => c[0] === k)[1]} is not a number`); }
    const pm = low(r.payMethod);
    if (pm && !['cheque', 'cash', 'transfer'].includes(pm)) p.push('Paid by: cheque, cash or transfer');
    const ex = has('ap_suppliers') ? safe(() => db().get('SELECT * FROM ap_suppliers WHERE lower(name) = lower(?)', [txt(r.name)]), null) : null;
    return { ...r, tin, action: p.length ? 'problem' : ex ? 'change' : 'new', uid: ex ? ex.uid : null, problems: p };
  });
  // products
  // 1.0.0 matched like the supplier catalogue (size-aware); a product not in the app yet is kept and waits for it
  const CAT = safe(() => require('../modules/inventory/supplierCatalog.js'), null);
  const ix = CAT ? CAT.itemIndex() : null;
  const findItem = itemFinder();
  out.products = rowsOf(findSheet(sheets, SHEETS[1]), SHEETS[1]).map((r) => {
    const p = [];
    const sup = findSup(r.supplier);
    if (!txt(r.supplier)) p.push('No supplier');
    else if (!sup) p.push(`Supplier "${txt(r.supplier)}" is not in the app or the Suppliers sheet`);
    if (!txt(r.name) && !txt(r.code) && !txt(r.itemCode) && !txt(r.itemName)) p.push('No product name or code');
    const cost = num(r.cost);
    if (Number.isNaN(cost)) p.push('Cost is not a number');
    let m;
    if (CAT) {
      const x = CAT.matchLine(r, sup && sup.uid, ix);
      m = x.item && x.sure ? { item: x.item, how: x.how } : (x.item || x.guess) ? { item: x.item || x.guess, how: x.how, guess: true } : {};
    } else m = findItem(r, sup && sup.uid);
    const old = sup && sup.uid && CAT ? safe(() => db().get("SELECT status FROM inv_supplier_catalog WHERE uid = ?", [CAT.lineKey(sup.uid, r.code, r.name)]), null) : null;
    return { ...r, supplierUid: sup ? sup.uid : null, supplierName: sup ? sup.name : txt(r.supplier), itemUid: m.item ? m.item.uid : null, itemName: m.item ? m.item.name : '', how: m.how || null, guess: !!m.guess,
      cost: Number.isNaN(cost) ? null : cost, action: p.length ? 'problem' : !m.item ? 'wait' : m.guess ? 'check' : old ? 'change' : 'new', problems: p };
  });
  // bill accounts
  const shops = new Set(safe(() => db().all('SELECT code FROM shops'), []).map((s) => s.code));
  out.bills = rowsOf(findSheet(sheets, SHEETS[2]), SHEETS[2]).map((r) => {
    const p = []; const shop = txt(r.shop).toUpperCase(); const kind = kindOf(r.kind);
    if (!shops.has(shop)) p.push(`Shop "${txt(r.shop)}" not found`);
    if (!kind) p.push('Kind: Power, Water, Phone, Internet, Rent or Other');
    const acc = txt(r.accountNo);
    if (!acc && !['other', 'rent'].includes(kind)) p.push('No account number');
    if (acc && !/^[A-Za-z0-9\s\-/.]+$/.test(acc)) p.push('Account number has odd characters');
    const ex = has('shop_accounts') && kind ? safe(() => db().get('SELECT uid FROM shop_accounts WHERE shop_code = ? AND kind = ? AND (account_no = ? OR lower(label) = lower(?))', [shop, kind, acc, txt(r.label)]), null) : null;
    return { ...r, shop, kind, accountNo: acc, uid: ex ? ex.uid : null, action: p.length ? 'problem' : ex ? 'change' : 'new', problems: p };
  });
  // wallets
  out.wallets = rowsOf(findSheet(sheets, SHEETS[3]), SHEETS[3]).map((r) => {
    const p = []; const shop = txt(r.shop).toUpperCase(); const opening = num(r.opening); const d = isoDate(r.date);
    if (!txt(r.name)) p.push('No wallet name');
    if (!shops.has(shop)) p.push(`Shop "${txt(r.shop)}" not found`);
    if (Number.isNaN(opening)) p.push('Opening balance is not a number');
    if (d && !/^\d{4}-\d{2}-\d{2}$/.test(d)) p.push('Opening date as YYYY-MM-DD');
    const ex = has('wallets') ? safe(() => db().get('SELECT * FROM wallets WHERE lower(name) = lower(?)', [txt(r.name)]), null) : null;
    return { ...r, shop, opening: Number.isNaN(opening) ? null : opening, date: d, uid: ex ? ex.uid : null, action: p.length ? 'problem' : ex ? 'change' : 'new', problems: p };
  });
  // approvers
  out.approvers = rowsOf(findSheet(sheets, SHEETS[4]), SHEETS[4]).map((r) => {
    const p = [];
    const u = safe(() => db().get('SELECT uid, name FROM users WHERE lower(name) = lower(?)', [txt(r.person)]), null);
    if (!u) p.push(`Person "${txt(r.person)}" not found`);
    const list = txt(r.shops).split(/[\s,;/]+/).map((x) => x.toUpperCase()).filter(Boolean);
    const bad = list.filter((x) => !shops.has(x));
    if (bad.length) p.push(`Shop ${bad.join(', ')} not found`);
    return { ...r, userUid: u ? u.uid : null, list, action: p.length ? 'problem' : 'change', problems: p };
  });
  const count = (l) => ({ rows: l.length, new: l.filter((x) => x.action === 'new').length, change: l.filter((x) => x.action === 'change').length, check: l.filter((x) => x.action === 'check').length,
    wait: l.filter((x) => x.action === 'wait').length, problems: l.filter((x) => x.action === 'problem').length });
  out.counts = Object.fromEntries(SHEETS.map((s) => [s.key, count(out[s.key])]));
  out.empty = SHEETS.every((s) => !out[s.key].length);
  return out;
}

// ---------------------------------------------------------------- 3. saving
// opts.withChecks: also save product rows matched only by a close name ("check" rows).
export function applyPack(user, preview, { withChecks = false } = {}) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin can bring in the set-up pack.');
  const AP = require('../modules/payables/service.js');
  const I = require('../modules/inventory/service.js');
  const done = { suppliers: 0, products: 0, waiting: 0, toConfirm: 0, bills: 0, wallets: 0, approvers: 0, skipped: [] };
  const skip = (sheet, r, e) => done.skipped.push({ sheet, row: r._row, why: e && e.message ? e.message : String(e) });
  const blank = (v) => v === '' || v === null || v === undefined;
  for (const r of preview.suppliers || []) {
    if (r.action === 'problem') continue;
    try {
      const cur = r.uid ? AP.getSupplier(r.uid) : null;
      const s = AP.saveSupplier(user, { uid: r.uid || undefined, name: txt(r.name), tin: r.tin || (cur && cur.tin) || '', phone: txt(r.phone) || (cur && cur.phone) || '', contact: cur ? cur.contact : undefined,
        termsDays: blank(r.terms) ? (cur ? cur.terms_days : undefined) : num(r.terms), payMethod: low(r.payMethod) || (cur && cur.pay_method) || 'cheque', vatRegistered: cur ? cur.vat_registered !== 0 : true,
        onAccount: cur ? !!cur.on_account : false, email: cur ? cur.email : undefined, bankName: cur ? cur.bank_name : undefined, bankAccount: cur ? cur.bank_account : undefined,
        category: txt(r.category) || (cur ? cur.category : undefined), notes: (cur && cur.notes) || [txt(r.address) ? `Address: ${txt(r.address)}` : '', txt(r.other) ? `Also printed as: ${txt(r.other)}` : ''].filter(Boolean).join('\n') || undefined });
      const uid = (s && s.uid) || r.uid || safe(() => db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?)', [txt(r.name)]).uid, null);
      r.uid = uid;
      const now = AP.getSupplier(uid);
      if (['budgetMonthly', 'budgetWeekly', 'leadDays', 'orderDays', 'viberGroup'].some((k) => !blank(r[k]))) {
        I.saveSupplierOrdering(user, { supplierUid: uid, budgetMonthly: blank(r.budgetMonthly) ? now.budget_monthly : num(r.budgetMonthly), budgetWeekly: blank(r.budgetWeekly) ? now.budget_weekly : num(r.budgetWeekly),
          leadDays: blank(r.leadDays) ? now.lead_days : num(r.leadDays), viber: now.viber, orderDays: blank(r.orderDays) ? now.order_days : txt(r.orderDays), viberGroup: blank(r.viberGroup) ? undefined : txt(r.viberGroup) });
      }
      done.suppliers += 1;
    } catch (e) { skip('Suppliers', r, e); }
  }
  const supUid = (name) => safe(() => db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?)', [txt(name)]).uid, null);
  // 1.0.0 every product line is kept in the supplier catalogue: sure matches link now, close names wait for a "Yes",
  // products not in the app yet wait for Aronium (they link themselves when the products arrive).
  const CAT = safe(() => require('../modules/inventory/supplierCatalog.js'), null);
  const keep = [];
  for (const r of preview.products || []) {
    const sUid = r.supplierUid || supUid(r.supplierName);
    if (r.action === 'problem' && !(sUid && r.problems.every((x) => /^Supplier "/.test(x)))) continue;
    try {
      if (!sUid) throw new Error('Supplier not found');
      const date = /^\d{4}-\d{2}-\d{2}$/.test(isoDate(r.date)) ? isoDate(r.date) : null;
      if (CAT) {
        const sure = r.itemUid && (r.action === 'new' || r.action === 'change' || (r.action === 'check' && withChecks));
        keep.push({ supplierUid: sUid, supplierName: r.supplierName, code: r.code, name: txt(r.name) || txt(r.itemName), unit: r.unit, pack: r.pack, cost: r.cost, vat: r.vat, date,
          barcode: r.barcode, itemCode: r.itemCode, itemName: r.itemName, main: r.main, itemUid: sure ? r.itemUid : undefined, _row: r._row });
      } else {
        if (!r.itemUid || (r.action === 'check' && !withChecks)) continue;
        I.addItemSupplier(user, r.itemUid, sUid, { main: /^y/i.test(txt(r.main)), code: txt(r.code) || undefined, cost: r.cost === null ? undefined : r.cost });
        if (date) I.noteItemSupplier(r.itemUid, sUid, { date });
        done.products += 1;
      }
    } catch (e) { skip('Supplier products', r, e); }
  }
  if (CAT && keep.length) {
    try { const k = CAT.keepLines(user, keep, { source: 'set-up pack' }); done.products += k.linked; done.toConfirm += k.check; done.waiting += k.waiting; } catch (e) { skip('Supplier products', { _row: '–' }, e); }
  }
  const SP = require('./shopProfile.js');
  for (const r of preview.bills || []) {
    if (r.action === 'problem') continue;
    try { SP.saveAccount(user, { uid: r.uid || undefined, shopCode: r.shop, kind: r.kind, label: txt(r.label), accountNo: r.accountNo, meterNo: txt(r.meterNo), holder: txt(r.holder) }); done.bills += 1; } catch (e) { skip('Bill accounts', r, e); }
  }
  const W = require('../modules/bank/wallets.js');
  for (const r of preview.wallets || []) {
    if (r.action === 'problem') continue;
    try {
      const cur = r.uid ? W.getWallet(r.uid) : null;
      W.saveWallet(user, { uid: r.uid || undefined, name: txt(r.name), provider: cur ? cur.provider : 'M-PAiSA', shopCode: r.shop, phoneNo: txt(r.phone) || (cur && cur.phone_no) || '',
        openingBalance: r.opening === null ? (cur ? cur.opening_balance : 0) : r.opening, openingDate: r.date || (cur ? cur.opening_date : dateStr()) });
      done.wallets += 1;
    } catch (e) { skip('MPAiSA wallets', r, e); }
  }
  for (const r of preview.approvers || []) {
    if (r.action === 'problem') continue;
    try { I.setApproverShops(user, r.userUid, r.list); done.approvers += 1; } catch (e) { skip('Order approvers', r, e); }
  }
  try { require('./core.js').audit({ user, action: `Set-up pack brought in: ${done.suppliers} suppliers, ${done.products} supplier products linked (${done.toConfirm} to confirm, ${done.waiting} waiting for the product), ${done.bills} bill accounts, ${done.wallets} wallets, ${done.approvers} approvers${done.skipped.length ? `; ${done.skipped.length} rows skipped` : ''}`, table: 'setup_pack', recordUid: stamp() }); } catch (e) { /* only a note */ }
  return done;
  });
}
