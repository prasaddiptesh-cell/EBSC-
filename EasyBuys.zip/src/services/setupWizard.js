// v3.9.8 First-time set-up, step by step. The moving-in steps (migration.js) are shown one at a time in a safe order.
// Each step says why it matters, what to have ready, and a few things to check before moving on; "Next" only
// unlocks when the step is done (counted by the app, or ticked) AND the checks are ticked. A step can be left for
// later – it is never lost: it comes back at the end. Where the owner got to is kept, so the set-up can be done over
// several days and picked up on any device.
import { getShared, setShared, stamp, audit, AppError } from './core.js';
import * as M from './migration.js';
import { requirePerm, requireLogin, asService } from './guard.js';

const KEY = 'setup_wizard';
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

// The order to do it in (each step only needs the ones before it).
export const ORDER = ['business', 'shops', 'users', 'samples', 'devices', 'staffpay', 'leave', 'suppliers', 'products', 'vat', 'staffcredit',
  'bank', 'wallets', 'tills', 'billaccounts', 'loans', 'recurring', 'licences', 'vehicles', 'orderdays', 'approvers', 'viber', 'fccc', 'fcccsweep', 'gas', 'freshstart'];

// why: one or two sentences; ready: what to have at hand; checks: ticked before "Next".
export const GUIDE = {
  business: { why: 'Every report, purchase order and payslip prints these details. FRCS and suppliers look for the TIN.', ready: 'Letterhead or an FRCS paper with the TIN', checks: ['The business name is spelled as registered', 'The TIN is right', 'The phone number is one the shop answers'] },
  shops: { why: 'Everything in the app belongs to a shop: tills, stock, staff, bills. Getting the shops right first keeps every later step tidy.', ready: 'The shop addresses', checks: ['Shop 1 (with the bakery) and Shop 2 are both in', 'The closed shop is not set up as a working shop'] },
  users: { why: 'Each person signs in as themselves, so every record shows who did it. Two people with owner or admin rights means you are never locked out.', ready: 'A list of staff with their job and shop', checks: ['Every staff member has their own login', 'There are at least two owner / admin logins', 'Nobody shares a PIN'] },
  samples: { why: 'The practice logins (Admin 1111, Sita 2222…) are known to anyone who saw the training – they must stop working before real money goes in.', ready: 'Nothing', checks: ['The sample logins are turned off on every device'] },
  devices: { why: 'Every phone and tablet must be linked so they share the same records. A device that is not linked keeps its own copy.', ready: 'Each tablet / phone, charged and online', checks: ['Each shop tablet shows the right shop', 'The main tablet is the one in the office', 'A test entry on one device shows on another'] },
  staffpay: { why: 'Pay, FNPF and PAYE are worked out from these. A wrong rate or TIN is the most common payroll mistake.', ready: 'Contracts or the wages book, FNPF numbers, TINs, bank details', checks: ['Every person paid has a rate', 'FNPF numbers and TINs are filled in', 'Family members are set as family (fixed pay split)'] },
  leave: { why: 'So the app knows how much leave each person has left and does not over-pay or under-pay it.', ready: 'Leave records', checks: ['Each person\'s leave balance agrees with your records'] },
  suppliers: { why: 'Suppliers come from Aronium. Invoices, orders and payments all hang off them.', ready: 'The till PC with Aronium Link running', checks: ['Your main suppliers are in the list', 'TINs are filled in for VAT-registered suppliers'] },
  products: { why: 'Products, codes, barcodes and prices come from Aronium – the app only reads them, never changes Aronium.', ready: 'The till PC with Aronium Link running', checks: ['A few products you know well show the right price', 'Barcodes scan to the right product'] },
  vat: { why: 'VAT on every product must be stated in Aronium (12.5 % or 0 %). From January FRCS sees the sales, so they must match the VAT return.', ready: 'Aronium open on a till PC to fix any product', checks: ['No product shows "no tax set"', 'Zero-rated products have 0 % set (not blank)'] },
  staffcredit: { why: 'Staff credit is in Aronium. The app needs the balances so it can take them off pay correctly.', ready: 'The Aronium customer balances', checks: ['Each staff member\'s balance agrees with Aronium'] },
  bank: { why: 'Cheques, deposits and the bank reconciliation all need the bank account and the cheque books.', ready: 'BSP account number, cheque book(s) with the next cheque number', checks: ['The next cheque number is right', 'The opening balance date is the go-live date'] },
  wallets: { why: 'M-PAiSA payments are checked against each wallet. The opening balance is the starting point for the balance checks.', ready: 'Each wallet\'s balance on the go-live morning', checks: ['One wallet per shop', 'The opening balance is from the go-live date'] },
  tills: { why: 'Every shift is balanced against its till and float.', ready: 'The float amount for each till', checks: ['Each till has its float', 'The shift names match how the shops work'] },
  billaccounts: { why: 'With the account numbers the app checks the water bill by itself every day, and the EFL bill with one tap a month.', ready: 'The last EFL and WAF bill of each shop', checks: ['Each shop has its EFL and WAF account', 'The account numbers are typed exactly as on the bill'] },
  loans: { why: 'Loan and rent bills are made by themselves on time, and the interest is split out for the accounts.', ready: 'Loan papers, rent agreements, the latest statements', checks: ['All 5 loans are in', 'Rent for each shop (and the home) is in', 'Each balance agrees with the lender\'s statement'] },
  recurring: { why: 'Regular bills (phone, internet…) are reminded before they are due.', ready: 'The last bill of each', checks: ['Every regular bill is in with its day of the month'] },
  licences: { why: 'You are reminded at 30 and 7 days before a licence expires – a lapsed liquor licence stops sales.', ready: 'The certificates', checks: ['Liquor and spirit licences are in with the right expiry date', 'A photo of each certificate is attached'] },
  vehicles: { why: 'Fuel, services, registration and insurance are tracked per vehicle.', ready: 'LTA and insurance papers', checks: ['Each vehicle has its registration and insurance dates'] },
  orderdays: { why: 'The app reminds you before each supplier\'s cut-off and keeps orders within budget. The Excel set-up pack (Admin) does all suppliers at once.', ready: 'Which supplier comes on which day; monthly budgets', checks: ['Main suppliers have order days', 'Budgets are set where you want a limit'] },
  approvers: { why: 'Only the right manager can approve and send an order for their shop.', ready: 'Your managers', checks: ['Each shop has someone who approves its orders'] },
  viber: { why: 'Each shop\'s alerts go to its own Viber channel, where its managers and admin are. Needs the cloud script version 9 pasted once.', ready: 'Each shop\'s Viber channel token (from the Viber app)', checks: ['A test message arrived in each shop\'s channel', 'Only managers and admin are in the channels'] },
  fccc: { why: 'Price-controlled products must not be sold above the FCCC maximum – a fine if they are.', ready: 'Nothing – the app reads the FCCC list', checks: ['The products the app suggested are checked'] },
  fcccsweep: { why: 'The sweep looks at every product (name, size, price) for any that may be controlled and asks you one by one.', ready: 'Time to answer the questions (about 20–40 minutes)', checks: ['Every question in the sweep is answered'] },
  gas: { why: 'Gas prices change every month; each gas product is linked once so the app tells you the new maximum.', ready: 'The gas products you sell (sizes, refill / new)', checks: ['Each gas cylinder size is linked', 'Gas cylinders are 0 % VAT in Aronium'] },
  freshstart: { why: 'Anything dated before this day is history only – no old warnings or Viber messages. Old open items wait in "Before go-live" for you to go through once.', ready: 'The go-live date', checks: ['The date is the first day the app is used for real', 'You will go through "Before go-live" once'] },
};

export function wizardState() { const s = getShared(KEY, null); return s && typeof s === 'object' ? s : { at: null, later: [], checks: {}, started: null, finished: null }; }
function save(s) { setShared(KEY, s); return s; }

// All steps in the wizard's order, with how far each one is.
export function wizardSteps() {
  const st = wizardState();
  const all = M.migrationStatus();
  const byKey = new Map(all.map((s) => [s.key, s]));
  const keys = ORDER.filter((k) => byKey.has(k)).concat(all.map((s) => s.key).filter((k) => !ORDER.includes(k)));
  return keys.map((k, i) => {
    const s = byKey.get(k);
    const g = GUIDE[k] || { why: '', ready: s.from, checks: [] };
    const ticked = st.checks[k] || [];
    const checksDone = g.checks.every((_, j) => ticked.includes(j));
    return { ...s, ...g, no: i + 1, ticked, checksDone, later: (st.later || []).includes(k), ready: g.ready || s.from, canNext: (s.done || (s.tick && s.tick.v === 'na')) && (checksDone || (s.tick && s.tick.v === 'na')) };
  });
}
// The step to show: where the owner got to (or the first one not finished, steps left for later last).
export function currentStep(steps = wizardSteps()) {
  const st = wizardState();
  if (st.at) { const s = steps.find((x) => x.key === st.at); if (s) return s; }
  return steps.find((x) => !x.canNext && !x.later) || steps.find((x) => !x.canNext) || null;
}
export function wizardSummary() {
  const steps = wizardSteps();
  const done = steps.filter((s) => s.canNext).length;
  const cur = currentStep(steps);
  const st = wizardState();
  return { total: steps.length, done, left: steps.length - done, later: steps.filter((s) => s.later && !s.canNext).length, current: cur, finished: !!st.finished || done === steps.length, started: !!st.started };
}
export function tickCheck(user, key, i, on) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const st = wizardState();
  const list = new Set(st.checks[key] || []);
  if (on) list.add(i); else list.delete(i);
  return save({ ...st, started: st.started || stamp(), checks: { ...st.checks, [key]: [...list].sort() } });
  });
}
export function goTo(user, key) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const st = wizardState();
  return save({ ...st, started: st.started || stamp(), at: key });
  });
}
// Next: only when the step is done and its checks are ticked. Moves to the next step not finished.
export function nextStep(user, key) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const steps = wizardSteps();
  const i = steps.findIndex((s) => s.key === key);
  const s = steps[i];
  if (!s) throw new AppError('Step not found.');
  if (!s.canNext) throw new AppError(!s.done ? 'This step is not finished yet. Open it and do it, tick "Done" if the app cannot count it, or leave it for later.' : 'Tick the checks first – they make sure nothing is missed.');
  const st = wizardState();
  const later = (st.later || []).filter((k) => k !== key);
  const nxt = steps.slice(i + 1).find((x) => !x.canNext && !later.includes(x.key)) || steps.find((x) => !x.canNext && x.key !== key) || null;
  const finished = !nxt;
  if (finished && !st.finished) audit({ user, action: 'Finished the step-by-step set-up', table: 'shared_settings', recordUid: KEY });
  return save({ ...st, later, at: nxt ? nxt.key : null, finished: finished ? (st.finished || stamp()) : null });
  });
}
export function leaveForLater(user, key, why) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  if (key === 'samples' || key === 'freshstart') throw new AppError(key === 'samples' ? 'The sample logins must be off before going on – anyone who knows them could get in.' : 'The fresh start date is the last step; it cannot be left for later.');
  const steps = wizardSteps();
  const i = steps.findIndex((s) => s.key === key);
  const st = wizardState();
  const later = Array.from(new Set((st.later || []).concat([key])));
  const nxt = steps.slice(i + 1).find((x) => !x.canNext && !later.includes(x.key)) || steps.find((x) => !x.canNext && x.key !== key) || null;
  audit({ user, action: `Set-up: left "${steps[i] ? steps[i].title : key}" for later`, table: 'shared_settings', recordUid: KEY, reason: why || null });
  return save({ ...st, later, at: nxt ? nxt.key : key });
  });
}
// Until set-up is finished (or a go-live / fresh start date is set) the app holds back automatic Viber posts.
export function holdAutomatic() {
  try {
    const g = getShared('go_live', {}) || {};
    if (g.liveFrom || g.freshFrom) return false;
    const st = getShared(KEY, null);
    return !!(st && st.started && !st.finished);
  } catch (e) { return false; }
}

// ================================================================ 1.0.0 build 1: guided set-up (15 steps)
// First run (an empty app) and Settings › Set up step by step. The steps in the owner's order; each opens the existing
// screen; a step is done when the app sees it (counted) or the owner ticks it. ALL products come from Aronium – the app
// never makes products; suppliers come from the supplier set-up pack in the owner's Google Drive (cloud setup_pack).
const q = (sql, a = []) => { try { return Number((require('../db/connection.js').db().get(sql, a) || {}).n) || 0; } catch (e) { return 0; } };
const shared = (k) => { try { return getShared(k, null); } catch (e) { return null; } };
export const GUIDED = [
  { key: 'shops', title: 'Shops and tills', why: 'Everything belongs to a shop: Shop 1 (Drasa Avenue, with the bakery) and Shop 2 (Tukani Street).', screen: 'Shops', also: { title: 'Tills', screen: 'TillSetup' },
    done: () => q("SELECT COUNT(*) AS n FROM shops WHERE active = 1") >= 2 && q('SELECT COUNT(*) AS n FROM tills WHERE active = 1') >= 1, progress: () => `${q('SELECT COUNT(*) AS n FROM shops WHERE active = 1')} shops · ${q('SELECT COUNT(*) AS n FROM tills WHERE active = 1')} tills` },
  { key: 'link', title: 'Link the till PCs (Aronium Link)', why: 'The till PCs send the sales, End of days and products from Aronium. Install the Link on each till PC.', screen: 'AroniumLink',
    done: () => q('SELECT COUNT(DISTINCT source) AS n FROM aronium_feed') >= 1, progress: () => `${q('SELECT COUNT(DISTINCT source) AS n FROM aronium_feed')} till PC(s) have sent figures` },
  { key: 'products', title: 'Products arrive from Aronium', why: 'All products come from Aronium (names, prices, barcodes, VAT). The app never makes products – wait until they arrive.', screen: 'InvImport',
    done: () => q('SELECT COUNT(*) AS n FROM inv_items WHERE active = 1') > 0, progress: () => `${q('SELECT COUNT(*) AS n FROM inv_items WHERE active = 1')} products` },
  { key: 'suppliers', title: 'Suppliers from the set-up pack', why: 'The suppliers (from your invoices) load from the set-up pack in your Google Drive and are matched to the Aronium products.', screen: 'SetupPack', action: 'pack',
    done: () => !!shared('setup_pack_loaded') || q('SELECT COUNT(*) AS n FROM ap_suppliers') > 0, progress: () => `${q('SELECT COUNT(*) AS n FROM ap_suppliers')} suppliers` },
  { key: 'nosupplier', title: 'Products with no supplier', why: 'Give each product its supplier, so orders and invoices find them.', screen: 'NoSupplierProducts', tick: true,
    done: () => q('SELECT COUNT(*) AS n FROM inv_items WHERE active = 1') > 0 && q('SELECT COUNT(*) AS n FROM inv_items i WHERE i.active = 1 AND NOT EXISTS (SELECT 1 FROM inv_item_suppliers s WHERE s.item_uid = i.uid AND s.active = 1)') === 0,
    progress: () => `${q('SELECT COUNT(*) AS n FROM inv_items i WHERE i.active = 1 AND NOT EXISTS (SELECT 1 FROM inv_item_suppliers s WHERE s.item_uid = i.uid AND s.active = 1)')} without a supplier` },
  { key: 'staff', title: 'Staff, their permissions and pay', why: 'Each person logs in as themselves; their profile holds their permissions and pay.', screen: 'Users', also: { title: 'Pay details', screen: 'PayProfiles' },
    done: () => q("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role <> 'owner' AND COALESCE(sync_status, '') <> 'seed'") >= 1 && q('SELECT COUNT(*) AS n FROM pay_profiles') >= 1,
    progress: () => `${q("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND COALESCE(sync_status, '') <> 'seed'")} logins · ${q('SELECT COUNT(*) AS n FROM pay_profiles')} pay details` },
  { key: 'bank', title: 'Bank, cheque books and M-PAiSA wallets', why: 'The BSP account, each cheque book (next cheque number) and one M-PAiSA wallet per shop.', screen: 'ChequeBooks', also: { title: 'M-PAiSA wallets', screen: 'WalletSetup' },
    done: () => q('SELECT COUNT(*) AS n FROM bank_accounts') >= 1 && q('SELECT COUNT(*) AS n FROM cheque_books') >= 1 && q('SELECT COUNT(*) AS n FROM wallets') >= 1,
    progress: () => `${q('SELECT COUNT(*) AS n FROM bank_accounts')} bank · ${q('SELECT COUNT(*) AS n FROM cheque_books')} cheque books · ${q('SELECT COUNT(*) AS n FROM wallets')} wallets` },
  { key: 'opening', title: 'Opening balances', why: 'What the business has and owes on the day the app starts.', screen: 'OpeningBalances',
    done: () => q("SELECT COUNT(*) AS n FROM gl_journals WHERE kind = 'opening' AND status = 'active'") >= 1, progress: () => (q("SELECT COUNT(*) AS n FROM gl_journals WHERE kind = 'opening' AND status = 'active'") ? 'Entered' : 'Not yet') },
  { key: 'loans', title: 'Loans and rent', why: 'The 5 loans and the rent of each shop and the home.', screen: 'LoanSetup',
    done: () => q('SELECT COUNT(*) AS n FROM regular_terms') >= 1, progress: () => `${q('SELECT COUNT(*) AS n FROM regular_terms')} loans / rents` },
  { key: 'bills', title: 'Power and water bill accounts', why: 'Each shop\'s EFL and WAF account number, so the app checks the bills.', screen: 'Bills',
    done: () => q("SELECT COUNT(*) AS n FROM shop_accounts WHERE active = 1 AND kind IN ('water','power') AND IFNULL(account_no,'') <> ''") >= 2, progress: () => `${q("SELECT COUNT(*) AS n FROM shop_accounts WHERE active = 1 AND kind IN ('water','power') AND IFNULL(account_no,'') <> ''")} bill accounts` },
  { key: 'licences', title: 'Licences and papers', why: 'Liquor and spirit licences and the other papers, with expiry dates (warned at 60, 30 and 7 days).', screen: 'Licences',
    done: () => q('SELECT COUNT(*) AS n FROM licences') >= 1, progress: () => `${q('SELECT COUNT(*) AS n FROM licences')} papers` },
  { key: 'vehicles', title: 'Vehicles', why: 'Registration, insurance and services of each vehicle.', screen: 'VeList', tick: true,
    done: () => q('SELECT COUNT(*) AS n FROM ve_items') >= 1, progress: () => `${q('SELECT COUNT(*) AS n FROM ve_items')} vehicles / equipment` },
  { key: 'checklists', title: 'Checklists', why: 'Each shop\'s and the bakery\'s own checklist, shown at the start and end of each shift.', screen: 'DutyLists',
    done: () => q('SELECT COUNT(*) AS n FROM duty_lists') >= 1, progress: () => `${q('SELECT COUNT(*) AS n FROM duty_lists')} checklists` },
  { key: 'cigarettes', title: 'Cigarettes', why: 'The cigarette supplier, the 7-day account and which Aronium groups are cigarettes.', screen: 'CigTally', tick: true,
    done: () => !!shared('cig_tally'), progress: () => (shared('cig_tally') ? 'Set' : 'Not set yet') },
  { key: 'golive', title: 'Go-live date', why: 'The first day the app is used for real. Older items stop nagging.', screen: 'GoLive',
    done: () => { const g = shared('go_live') || {}; return !!(g.liveFrom || g.freshFrom); }, progress: () => { const g = shared('go_live') || {}; return g.liveFrom || g.freshFrom ? `From ${g.liveFrom || g.freshFrom}` : 'Not set'; } },
];
const GKEY = 'guided_setup';
export function guidedState() { const s = shared(GKEY); return s && typeof s === 'object' ? s : { ticks: {}, at: null, started: null, finished: null }; }
export function guidedSteps() {
  const st = guidedState();
  return GUIDED.map((g, i) => {
    let counted = false; let progress = '';
    try { counted = !!g.done(); } catch (e) { counted = false; }
    try { progress = g.progress ? g.progress() : ''; } catch (e) { progress = ''; }
    const tick = (st.ticks || {})[g.key] || null;
    return { key: g.key, no: i + 1, title: g.title, why: g.why, screen: g.screen, also: g.also || null, action: g.action || null, canTick: !!g.tick, progress, counted, tick, done: counted || !!tick };
  });
}
// The step to show: the first one not done, in order (each needs the ones before it).
export function guidedCurrent(steps = guidedSteps()) { return steps.find((s) => !s.done) || null; }
export function guidedSummary() { const s = guidedSteps(); const d = s.filter((x) => x.done).length; return { total: s.length, done: d, left: s.length - d, current: guidedCurrent(s), finished: d === s.length }; }
// A step the app cannot count (or that is not needed): the owner ticks it.
export function tickGuided(user, key, value) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const g = GUIDED.find((x) => x.key === key);
  if (!g) throw new AppError('Step not found.');
  const st = guidedState();
  const ticks = { ...(st.ticks || {}) };
  if (value) ticks[key] = { v: value, by: user.name, at: stamp() }; else delete ticks[key];
  setShared(GKEY, { ...st, ticks, started: st.started || stamp() });
  audit({ user, action: `Set-up: "${g.title}" ${value ? (value === 'na' ? 'not needed' : 'done') : 'not done after all'}`, table: 'shared_settings', recordUid: GKEY });
  return guidedSteps();
  });
}
// The app is empty (a new install, or after Start clean): only the owner login(s), no staff, products or suppliers.
export function appIsEmpty() {
  return q("SELECT COUNT(*) AS n FROM users WHERE active = 1 AND role <> 'owner' AND COALESCE(sync_status, '') <> 'seed'") === 0
    && q('SELECT COUNT(*) AS n FROM inv_items') === 0 && q('SELECT COUNT(*) AS n FROM ap_suppliers') === 0;
}
// Step 4: the supplier set-up pack from the owner's Google Drive (cloud setup_pack) → the same preview as Admin › Excel
// set-up pack. deps: { cloud, xlsxSheets } (the screen passes them). → the preview (lines wait for products by themselves)
export async function packFromCloud(user, deps) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const r = await deps.cloud({ kind: 'setup_pack' });
  if (!r || !r.ok) throw new AppError((r && r.error) || 'The set-up pack could not be fetched.');
  const sheets = await deps.xlsxSheets(r.b64);
  const P = require('./setupPack.js');
  return { name: r.name, preview: P.readPack(sheets) };
}
export function loadPack(user, preview) {
  requirePerm(user, 'settings'); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const P = require('./setupPack.js');
  const done = P.applyPack(user, preview);
  setShared('setup_pack_loaded', { at: stamp(), by: user.name, suppliers: done.suppliers, products: done.products, waiting: done.waiting });
  return done;
  });
}
