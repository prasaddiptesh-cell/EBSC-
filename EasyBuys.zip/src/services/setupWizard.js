// v3.9.8 First-time set-up, step by step. The moving-in steps (migration.js) are shown one at a time in a safe order.
// Each step says why it matters, what to have ready, and a few things to check before moving on; "Next" only
// unlocks when the step is done (counted by the app, or ticked) AND the checks are ticked. A step can be left for
// later – it is never lost: it comes back at the end. Where the owner got to is kept, so the set-up can be done over
// several days and picked up on any device.
import { getShared, setShared, stamp, audit, AppError } from './core.js';
import * as M from './migration.js';

const KEY = 'setup_wizard';
const isBoss = (u) => !!u && (['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));

// The order to do it in (each step only needs the ones before it).
export const ORDER = ['business', 'shops', 'users', 'samples', 'devices', 'staffpay', 'leave', 'suppliers', 'products', 'vat', 'staffcredit',
  'bank', 'wallets', 'tills', 'billaccounts', 'loans', 'recurring', 'licences', 'vehicles', 'orderdays', 'approvers', 'viber', 'fccc', 'fcccsweep', 'gas', 'freshstart'];

// why: one or two sentences; ready: what to have at hand; checks: ticked before "Next".
export const GUIDE = {
  business: { why: 'Every report, purchase order and payslip prints these details. FRCS and suppliers look for the TIN.', ready: 'Letterhead or an FRCS paper with the TIN', checks: ['The business name is spelled as registered', 'The TIN is right', 'The phone number is one the shop answers'] },
  shops: { why: 'Everything in the app belongs to a shop: tills, stock, staff, bills. Getting the shops right first keeps every later step tidy.', ready: 'The shop addresses', checks: ['Shop 1 (with the bakery) and Shop 2 are both in', 'The closed shop is not set up as a working shop'] },
  users: { why: 'Each person signs in as themselves, so every record shows who did it. Two people with owner or admin rights means you are never locked out.', ready: 'A list of staff with their job and shop', checks: ['Every staff member has their own login', 'There are at least two owner / admin logins', 'Nobody shares a PIN'] },
  samples: { why: 'The practice logins (Admin 1111, Sita 2222…) are known to anyone who saw the training – they must stop working before real money goes in.', ready: 'Nothing', checks: ['The sample logins are turned off on every device'] },
  devices: { why: 'Every phone and tablet must be linked so they share the same records. A device that is not linked keeps its own copy.', ready: 'Each tablet / phone, charged and online', checks: ['Each shop tablet shows the right shop', 'The main tablet is the one in the office', 'A test entry on one device shows on another'] },
  staffpay: { why: 'Pay, FNPF and PAYE are worked out from these. A wrong rate or TIN is the most common payroll mistake.', ready: 'Contracts or the wages book, FNPF numbers, TINs, bank details', checks: ['Every person paid has a rate', 'FNPF numbers and TINs are filled in', 'Family members are set as family (fixed pay split)'] },
  leave: { why: 'So the app knows how much leave each person has left and does not over-pay or under-pay it.', ready: 'Leave records', checks: ['Each person\'s leave balance agrees with your records'] },
  suppliers: { why: 'Suppliers come from Aronium. Invoices, orders and payments all hang off them.', ready: 'The till PC with Aronium Link running', checks: ['Your main suppliers are in the list', 'TINs are filled in for VAT-registered suppliers'] },
  products: { why: 'Products, codes, barcodes and prices come from Aronium – the app only reads them, never changes Aronium.', ready: 'The till PC with Aronium Link running', checks: ['A few products you know well show the right price', 'Barcodes scan to the right product'] },
  vat: { why: 'VAT on every product must be stated in Aronium (12.5 % or 0 %). From January FRCS sees the sales, so they must match the VAT return.', ready: 'Aronium open on a till PC to fix any product', checks: ['No product shows "no tax set"', 'Zero-rated products have 0 % set (not blank)'] },
  staffcredit: { why: 'Staff credit is in Aronium. The app needs the balances so it can take them off pay correctly.', ready: 'The Aronium customer balances', checks: ['Each staff member\'s balance agrees with Aronium'] },
  bank: { why: 'Cheques, deposits and the bank reconciliation all need the bank account and the cheque books.', ready: 'BSP account number, cheque book(s) with the next cheque number', checks: ['The next cheque number is right', 'The opening balance date is the go-live date'] },
  wallets: { why: 'M-PAiSA payments are checked against each wallet. The opening balance is the starting point for the balance checks.', ready: 'Each wallet\'s balance on the go-live morning', checks: ['One wallet per shop', 'The opening balance is from the go-live date'] },
  tills: { why: 'Every shift is balanced against its till and float.', ready: 'The float amount for each till', checks: ['Each till has its float', 'The shift names match how the shops work'] },
  billaccounts: { why: 'With the account numbers the app checks the water bill by itself every day, and the EFL bill with one tap a month.', ready: 'The last EFL and WAF bill of each shop', checks: ['Each shop has its EFL and WAF account', 'The account numbers are typed exactly as on the bill'] },
  loans: { why: 'Loan and rent bills are made by themselves on time, and the interest is split out for the accounts.', ready: 'Loan papers, rent agreements, the latest statements', checks: ['All 5 loans are in', 'Rent for each shop (and the home) is in', 'Each balance agrees with the lender\'s statement'] },
  recurring: { why: 'Regular bills (phone, internet…) are reminded before they are due.', ready: 'The last bill of each', checks: ['Every regular bill is in with its day of the month'] },
  licences: { why: 'You are reminded at 30 and 7 days before a licence expires – a lapsed liquor licence stops sales.', ready: 'The certificates', checks: ['Liquor and spirit licences are in with the right expiry date', 'A photo of each certificate is attached'] },
  vehicles: { why: 'Fuel, services, registration and insurance are tracked per vehicle.', ready: 'LTA and insurance papers', checks: ['Each vehicle has its registration and insurance dates'] },
  orderdays: { why: 'The app reminds you before each supplier\'s cut-off and keeps orders within budget. The Excel set-up pack (Admin) does all suppliers at once.', ready: 'Which supplier comes on which day; monthly budgets', checks: ['Main suppliers have order days', 'Budgets are set where you want a limit'] },
  approvers: { why: 'Only the right manager can approve and send an order for their shop.', ready: 'Your managers', checks: ['Each shop has someone who approves its orders'] },
  viber: { why: 'Each shop\'s alerts go to its own Viber channel, where its managers and admin are. Needs the cloud script version 9 pasted once.', ready: 'Each shop\'s Viber channel token (from the Viber app)', checks: ['A test message arrived in each shop\'s channel', 'Only managers and admin are in the channels'] },
  fccc: { why: 'Price-controlled products must not be sold above the FCCC maximum – a fine if they are.', ready: 'Nothing – the app reads the FCCC list', checks: ['The products the app suggested are checked'] },
  fcccsweep: { why: 'The sweep looks at every product (name, size, price) for any that may be controlled and asks you one by one.', ready: 'Time to answer the questions (about 20–40 minutes)', checks: ['Every question in the sweep is answered'] },
  gas: { why: 'Gas prices change every month; each gas product is linked once so the app tells you the new maximum.', ready: 'The gas products you sell (sizes, refill / new)', checks: ['Each gas cylinder size is linked', 'Gas cylinders are 0 % VAT in Aronium'] },
  freshstart: { why: 'Anything dated before this day is history only – no old warnings or Viber messages. Old open items wait in "Before go-live" for you to go through once.', ready: 'The go-live date', checks: ['The date is the first day the app is used for real', 'You will go through "Before go-live" once'] },
};

export function wizardState() { const s = getShared(KEY, null); return s && typeof s === 'object' ? s : { at: null, later: [], checks: {}, started: null, finished: null }; }
function save(s) { setShared(KEY, s); return s; }

// All steps in the wizard's order, with how far each one is.
export function wizardSteps() {
  const st = wizardState();
  const all = M.migrationStatus();
  const byKey = new Map(all.map((s) => [s.key, s]));
  const keys = ORDER.filter((k) => byKey.has(k)).concat(all.map((s) => s.key).filter((k) => !ORDER.includes(k)));
  return keys.map((k, i) => {
    const s = byKey.get(k);
    const g = GUIDE[k] || { why: '', ready: s.from, checks: [] };
    const ticked = st.checks[k] || [];
    const checksDone = g.checks.every((_, j) => ticked.includes(j));
    return { ...s, ...g, no: i + 1, ticked, checksDone, later: (st.later || []).includes(k), ready: g.ready || s.from, canNext: (s.done || (s.tick && s.tick.v === 'na')) && (checksDone || (s.tick && s.tick.v === 'na')) };
  });
}
// The step to show: where the owner got to (or the first one not finished, steps left for later last).
export function currentStep(steps = wizardSteps()) {
  const st = wizardState();
  if (st.at) { const s = steps.find((x) => x.key === st.at); if (s) return s; }
  return steps.find((x) => !x.canNext && !x.later) || steps.find((x) => !x.canNext) || null;
}
export function wizardSummary() {
  const steps = wizardSteps();
  const done = steps.filter((s) => s.canNext).length;
  const cur = currentStep(steps);
  const st = wizardState();
  return { total: steps.length, done, left: steps.length - done, later: steps.filter((s) => s.later && !s.canNext).length, current: cur, finished: !!st.finished || done === steps.length, started: !!st.started };
}
export function tickCheck(user, key, i, on) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const st = wizardState();
  const list = new Set(st.checks[key] || []);
  if (on) list.add(i); else list.delete(i);
  return save({ ...st, started: st.started || stamp(), checks: { ...st.checks, [key]: [...list].sort() } });
}
export function goTo(user, key) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const st = wizardState();
  return save({ ...st, started: st.started || stamp(), at: key });
}
// Next: only when the step is done and its checks are ticked. Moves to the next step not finished.
export function nextStep(user, key) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  const steps = wizardSteps();
  const i = steps.findIndex((s) => s.key === key);
  const s = steps[i];
  if (!s) throw new AppError('Step not found.');
  if (!s.canNext) throw new AppError(!s.done ? 'This step is not finished yet. Open it and do it, tick "Done" if the app cannot count it, or leave it for later.' : 'Tick the checks first – they make sure nothing is missed.');
  const st = wizardState();
  const later = (st.later || []).filter((k) => k !== key);
  const nxt = steps.slice(i + 1).find((x) => !x.canNext && !later.includes(x.key)) || steps.find((x) => !x.canNext && x.key !== key) || null;
  const finished = !nxt;
  if (finished && !st.finished) audit({ user, action: 'Finished the step-by-step set-up', table: 'shared_settings', recordUid: KEY });
  return save({ ...st, later, at: nxt ? nxt.key : null, finished: finished ? (st.finished || stamp()) : null });
}
export function leaveForLater(user, key, why) {
  if (!isBoss(user)) throw new AppError('Only the owner or admin does the set-up.');
  if (key === 'samples' || key === 'freshstart') throw new AppError(key === 'samples' ? 'The sample logins must be off before going on – anyone who knows them could get in.' : 'The fresh start date is the last step; it cannot be left for later.');
  const steps = wizardSteps();
  const i = steps.findIndex((s) => s.key === key);
  const st = wizardState();
  const later = Array.from(new Set((st.later || []).concat([key])));
  const nxt = steps.slice(i + 1).find((x) => !x.canNext && !later.includes(x.key)) || steps.find((x) => !x.canNext && x.key !== key) || null;
  audit({ user, action: `Set-up: left "${steps[i] ? steps[i].title : key}" for later`, table: 'shared_settings', recordUid: KEY, reason: why || null });
  return save({ ...st, later, at: nxt ? nxt.key : key });
}
// Until set-up is finished (or a go-live / fresh start date is set) the app holds back automatic Viber posts.
export function holdAutomatic() {
  try {
    const g = getShared('go_live', {}) || {};
    if (g.liveFrom || g.freshFrom) return false;
    const st = getShared(KEY, null);
    return !!(st && st.started && !st.finished);
  } catch (e) { return false; }
}
