// SHA-256 of bytes (pure JavaScript, fast enough for PDFs and photos on a tablet) plus base64 helpers.
// Used to check that a file reached Google Drive unchanged (the cloud script returns the same hash) and to
// fingerprint issued documents (barcode check).
const K = new Int32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

// bytes: Uint8Array or array of numbers (0..255, or signed −128..127 as Google sends them). Returns lowercase hex.
export function sha256Bytes(input) {
  const src = input instanceof Uint8Array ? input : Uint8Array.from(input || [], (b) => b & 255);
  const n = src.length;
  const total = ((n + 9 + 63) >> 6) << 6;
  const m = new Uint8Array(total);
  m.set(src);
  m[n] = 0x80;
  const bits = n * 8;
  const hi = Math.floor(bits / 0x100000000);
  m[total - 8] = (hi >>> 24) & 255; m[total - 7] = (hi >>> 16) & 255; m[total - 6] = (hi >>> 8) & 255; m[total - 5] = hi & 255;
  m[total - 4] = (bits >>> 24) & 255; m[total - 3] = (bits >>> 16) & 255; m[total - 2] = (bits >>> 8) & 255; m[total - 1] = bits & 255;
  const H = new Int32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const W = new Int32Array(64);
  for (let off = 0; off < total; off += 64) {
    for (let i = 0; i < 16; i++) { const j = off + i * 4; W[i] = (m[j] << 24) | (m[j + 1] << 16) | (m[j + 2] << 8) | m[j + 3]; }
    for (let i = 16; i < 64; i++) {
      const a = W[i - 15]; const b = W[i - 2];
      const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
      const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
    }
    let a = H[0]; let b = H[1]; let c = H[2]; let d = H[3]; let e = H[4]; let f = H[5]; let g = H[6]; let h = H[7];
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const t1 = (h + S1 + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }
  let out = '';
  for (let i = 0; i < 8; i++) out += ((H[i] >>> 0).toString(16)).padStart(8, '0');
  return out;
}

export function utf8Bytes(text) {
  const s = String(text === null || text === undefined ? '' : text);
  const out = [];
  for (let i = 0; i < s.length; i++) {
    let c = s.charCodeAt(i);
    if (c >= 0xd800 && c < 0xdc00 && i + 1 < s.length) { const d = s.charCodeAt(i + 1); if (d >= 0xdc00 && d < 0xe000) { c = 0x10000 + ((c - 0xd800) << 10) + (d - 0xdc00); i++; } }
    if (c < 0x80) out.push(c);
    else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else out.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return Uint8Array.from(out);
}
export function sha256Text(text) { return sha256Bytes(utf8Bytes(text)); }

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const REV = (() => { const r = new Int16Array(256).fill(-1); for (let i = 0; i < 64; i++) r[B64.charCodeAt(i)] = i; r['-'.charCodeAt(0)] = 62; r['_'.charCodeAt(0)] = 63; return r; })();
export function base64ToBytes(b64) {
  const s = String(b64 || '');
  const out = new Uint8Array(Math.floor((s.length * 3) / 4) + 3);
  let buf = 0; let bitsHeld = 0; let n = 0;
  for (let i = 0; i < s.length; i++) {
    const v = REV[s.charCodeAt(i) & 255];
    if (v < 0) continue; // padding, line breaks
    buf = (buf << 6) | v; bitsHeld += 6;
    if (bitsHeld >= 8) { bitsHeld -= 8; out[n++] = (buf >> bitsHeld) & 255; }
  }
  return out.subarray(0, n);
}
export function bytesToBase64(bytes) {
  let out = '';
  const b = bytes instanceof Uint8Array ? bytes : Uint8Array.from(bytes || []);
  let i = 0;
  for (; i + 2 < b.length; i += 3) { const v = (b[i] << 16) | (b[i + 1] << 8) | b[i + 2]; out += B64[v >> 18] + B64[(v >> 12) & 63] + B64[(v >> 6) & 63] + B64[v & 63]; }
  if (i < b.length) {
    const v = (b[i] << 16) | ((i + 1 < b.length ? b[i + 1] : 0) << 8);
    out += B64[v >> 18] + B64[(v >> 12) & 63] + (i + 1 < b.length ? B64[(v >> 6) & 63] : '=') + '=';
  }
  return out;
}
// Size and fingerprint of a file given as base64 (what is sent to the cloud).
export function base64Fingerprint(b64) {
  const bytes = base64ToBytes(b64);
  return { size: bytes.length, sha256: sha256Bytes(bytes) };
}
