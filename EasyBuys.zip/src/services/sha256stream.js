// SHA-256 in pieces (for a downloaded app update of many megabytes: read a piece at a time, never the whole file).
const K = new Int32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);
export function sha256Stream() {
  const H = new Int32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const W = new Int32Array(64);
  const block = new Uint8Array(64);
  let held = 0; let total = 0;
  const compress = (m, off) => {
    for (let i = 0; i < 16; i++) { const j = off + i * 4; W[i] = (m[j] << 24) | (m[j + 1] << 16) | (m[j + 2] << 8) | m[j + 3]; }
    for (let i = 16; i < 64; i++) {
      const a = W[i - 15]; const b = W[i - 2];
      W[i] = (W[i - 16] + (((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3)) + W[i - 7] + (((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10))) | 0;
    }
    let a = H[0]; let b = H[1]; let c = H[2]; let d = H[3]; let e = H[4]; let f = H[5]; let g = H[6]; let h = H[7];
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0;
      const t2 = ((((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  };
  return {
    update(bytes) {
      const b = bytes instanceof Uint8Array ? bytes : Uint8Array.from(bytes || []);
      let i = 0; total += b.length;
      if (held) { while (held < 64 && i < b.length) block[held++] = b[i++]; if (held === 64) { compress(block, 0); held = 0; } }
      for (; i + 64 <= b.length; i += 64) compress(b, i);
      while (i < b.length) block[held++] = b[i++];
      return this;
    },
    hex() {
      const bits = total * 8;
      const tail = new Uint8Array(((held + 9 + 63) >> 6) << 6);
      tail.set(block.subarray(0, held)); tail[held] = 0x80;
      const hi = Math.floor(bits / 0x100000000);
      const n = tail.length;
      tail[n - 8] = (hi >>> 24) & 255; tail[n - 7] = (hi >>> 16) & 255; tail[n - 6] = (hi >>> 8) & 255; tail[n - 5] = hi & 255;
      tail[n - 4] = (bits >>> 24) & 255; tail[n - 3] = (bits >>> 16) & 255; tail[n - 2] = (bits >>> 8) & 255; tail[n - 1] = bits & 255;
      for (let o = 0; o < n; o += 64) compress(tail, o);
      let out = '';
      for (let k = 0; k < 8; k++) out += (H[k] >>> 0).toString(16).padStart(8, '0');
      return out;
    },
  };
}
