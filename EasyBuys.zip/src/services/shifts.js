// Shifts, sign-on/sign-off, stock received/wasted/adjusted, balancing and approval.
import { db } from '../db/connection.js';
import {
  AppError, dateStr, stamp, r3, requirePositive, requireNonNegative, minutesBetween, getSettings, parseStamp, clock, hhmm,
} from './core.js';
import { getMaterial, listMaterials, listShiftNames, toleranceFor } from './catalog.js';
import { writeTxn, changeStock, raiseAlert, enqueue, addPhotos, checkReorder, addLot } from './stock.js';
import { signOffBlockers, shiftCloseBlockers } from './checklists.js';
import { reasonRequired } from './access.js';
const mustExplain = (id) => reasonRequired(db().get('SELECT * FROM users WHERE id = ?', [id]));

export const STATUS_LABEL = { open: 'Open', closed: 'Waiting for balance', approved: 'Approved' };

// ---------------- shift lookups ----------------
export function getShift(id) {
  return db().get(
    `SELECT s.*, uo.name AS opened_by_name, uc.name AS closed_by_name, ua.name AS approved_by_name
     FROM shifts s LEFT JOIN users uo ON uo.id = s.opened_by LEFT JOIN users uc ON uc.id = s.closed_by
     LEFT JOIN users ua ON ua.id = s.approved_by WHERE s.id = ?`,
    [id]
  );
}
export function getOpenShift() {
  const row = db().get("SELECT id FROM shifts WHERE status = 'open' ORDER BY id DESC LIMIT 1");
  return row ? getShift(row.id) : null;
}
export function getClosedShift() {
  const row = db().get("SELECT id FROM shifts WHERE status = 'closed' ORDER BY id DESC LIMIT 1");
  return row ? getShift(row.id) : null;
}
function currentShiftId() {
  const row = db().get("SELECT id FROM shifts WHERE status IN ('open','closed') ORDER BY id DESC LIMIT 1");
  return row ? row.id : null;
}
export function listShifts({ status, from, to, limit = 300 } = {}) {
  const where = [];
  const params = [];
  if (status) { where.push('s.status = ?'); params.push(status); }
  if (from) { where.push('s.shift_date >= ?'); params.push(from); }
  if (to) { where.push('s.shift_date <= ?'); params.push(to); }
  params.push(limit);
  return db().all(
    `SELECT s.*, ua.name AS approved_by_name, uo.name AS opened_by_name,
       (SELECT COUNT(*) FROM batches b WHERE b.shift_id = s.id) AS batch_count
     FROM shifts s LEFT JOIN users ua ON ua.id = s.approved_by LEFT JOIN users uo ON uo.id = s.opened_by
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY s.id DESC LIMIT ?`,
    params
  );
}

// ---------------- workers / sign-on ----------------
export function getShiftWorkers(shiftId) {
  const s = getShift(shiftId);
  const end = s && s.status !== 'open' ? s.closed_at : stamp();
  return db().all(
    `SELECT u.id, u.name, u.role, sw.* FROM shift_workers sw JOIN users u ON u.id = sw.user_id WHERE sw.shift_id = ? ORDER BY sw.signed_on_at`,
    [shiftId]
  ).map((w) => ({
    ...w,
    minutes: minutesBetween(w.signed_on_at, w.signed_off_at || end),
    on_edited: Math.abs(minutesBetween(w.signed_on_at, w.signed_on_recorded_at) || 0) > 2,
    off_edited: !!w.signed_off_at && Math.abs(minutesBetween(w.signed_off_at, w.signed_off_recorded_at) || 0) > 2,
  }));
}
export function isOnShift(shiftId, userId) {
  return !!db().get('SELECT 1 AS x FROM shift_workers WHERE shift_id = ? AND user_id = ? AND signed_off_at IS NULL', [shiftId, userId]);
}
export function getMyShiftRow(shiftId, userId) {
  return db().get('SELECT * FROM shift_workers WHERE shift_id = ? AND user_id = ?', [shiftId, userId]);
}

function checkTime(at, label) {
  if (!at) return stamp();
  const d = parseStamp(at);
  if (!d) throw new AppError(`Invalid ${label} time.`);
  const diff = (d.getTime() - clock.now().getTime()) / 60000;
  if (diff > 2) throw new AppError(`The ${label} time cannot be in the future.`);
  if (diff < -18 * 60) throw new AppError(`The ${label} time is too far in the past (more than 18 hours).`);
  return stamp(d);
}

export function signOn(userId, at) {
  const s = getOpenShift();
  if (!s) throw new AppError('There is no open shift. Start a shift first.');
  const when = checkTime(at, 'sign-on');
  const now = stamp();
  const existing = getMyShiftRow(s.id, userId);
  if (existing && !existing.signed_off_at) throw new AppError('You are already signed on.');
  if (existing) {
    db().run('UPDATE shift_workers SET signed_on_at = ?, signed_on_recorded_at = ?, signed_off_at = NULL, signed_off_recorded_at = NULL, signed_off_by = NULL WHERE shift_id = ? AND user_id = ?',
      [when, now, s.id, userId]);
  } else {
    db().run('INSERT INTO shift_workers (shift_id, user_id, signed_on_at, signed_on_recorded_at) VALUES (?, ?, ?, ?)', [s.id, userId, when, now]);
  }
  if (Math.abs(minutesBetween(when, now)) > 2) {
    const u = db().get('SELECT name FROM users WHERE id = ?', [userId]);
    raiseAlert({ type: 'TIME_EDIT', severity: 'info', shiftId: s.id, userId, message: `${u.name} signed on at ${hhmm(when)} (entered at ${hhmm(now)}).` });
  }
  return s;
}

export function signOff(userId, at, byUserId, shiftId) {
  const sid = shiftId || (getOpenShift() || {}).id;
  if (!sid) throw new AppError('There is no open shift.');
  const row = getMyShiftRow(sid, userId);
  if (!row || row.signed_off_at) throw new AppError('This person is not signed on.');
  const forced = byUserId && byUserId !== userId;
  const blockers = signOffBlockers(sid, userId);
  if (blockers.length && !forced) {
    throw new AppError(`Finish your end-of-shift checklist before signing off: ${blockers.map((b) => `${b.name} (${b.left} left)`).join(', ')}.`);
  }
  const when = checkTime(at, 'sign-off');
  if (parseStamp(when) < parseStamp(row.signed_on_at)) throw new AppError('Sign-off time cannot be before the sign-on time.');
  const now = stamp();
  db().run('UPDATE shift_workers SET signed_off_at = ?, signed_off_recorded_at = ?, signed_off_by = ? WHERE shift_id = ? AND user_id = ?',
    [when, now, byUserId || userId, sid, userId]);
  const u = db().get('SELECT name FROM users WHERE id = ?', [userId]);
  if (blockers.length && forced) {
    raiseAlert({ type: 'CHECK_SKIP', shiftId: sid, userId, message: `${u.name} was signed off by a supervisor without completing: ${blockers.map((b) => b.name).join(', ')}.` });
  }
  if (Math.abs(minutesBetween(when, now)) > 2 || (byUserId && byUserId !== userId)) {
    const by = byUserId && byUserId !== userId ? db().get('SELECT name FROM users WHERE id = ?', [byUserId]).name : null;
    raiseAlert({ type: 'TIME_EDIT', severity: 'info', shiftId: sid, userId, message: `${u.name} signed off at ${hhmm(when)} (entered at ${hhmm(now)}${by ? ` by ${by}` : ''}).` });
  }
  return minutesBetween(row.signed_on_at, when);
}

// ---------------- start / close ----------------
// openingCounts: { [materialId]: quantity } for stock-tracked materials.
export function startShift(userId, shiftName, openingCounts = {}, signOnAt) {
  const names = listShiftNames().map((n) => n.name);
  if (!names.includes(shiftName)) throw new AppError('Please choose a shift.');
  if (getOpenShift()) throw new AppError('A shift is already open. Sign on to that shift instead.');
  if (getClosedShift()) throw new AppError('The previous shift is waiting for the supervisor to balance stock. Ask a supervisor to approve it first.');
  const materials = listMaterials({ stockOnly: true });
  for (const m of materials) {
    const v = openingCounts[m.id];
    if (v === undefined || v === null || v === '' || !Number.isFinite(Number(v)) || Number(v) < 0) {
      throw new AppError(`Please confirm the opening stock for ${m.name}.`);
    }
  }
  const when = checkTime(signOnAt, 'sign-on');
  return db().transaction(() => {
    const d = dateStr();
    const n = db().get('SELECT COUNT(*) AS c FROM shifts WHERE shift_date = ?', [d]).c + 1;
    const code = `S-${d.replace(/-/g, '')}-${n}`;
    const shiftId = db().run(
      `INSERT INTO shifts (code, shift_date, shift_name, status, location, opened_by, opened_at, updated_at) VALUES (?, ?, ?, 'open', ?, ?, ?, ?)`,
      [code, d, shiftName, getSettings().locationName, userId, stamp(), stamp()]
    ).lastInsertRowId;
    signOn(userId, when);
    const diffs = [];
    for (const m of materials) {
      const counted = r3(openingCounts[m.id]);
      const diff = r3(counted - m.stock);
      db().run('INSERT INTO shift_stock (shift_id, material_id, system_opening, opening) VALUES (?, ?, ?, ?)', [shiftId, m.id, r3(m.stock), counted]);
      writeTxn({ type: 'OPENING', shiftId, userId, materialId: m.id, qty: counted, expectedQty: m.stock, variance: diff,
        note: diff !== 0 ? 'Opening count differs from system stock' : 'Opening stock confirmed' });
      if (diff !== 0) { changeStock(m.id, diff); diffs.push(`${m.name} ${diff > 0 ? '+' : ''}${diff} ${m.unit}`); }
    }
    if (diffs.length) raiseAlert({ type: 'OPENING', severity: 'info', shiftId, userId, message: `Opening count differs from system: ${diffs.join(', ')}` });
    checkReorder(userId);
    return getShift(shiftId);
  });
}

export function closeShift(userId, notes) {
  const s = getOpenShift();
  if (!s) throw new AppError('There is no open shift to close.');
  const active = db().all("SELECT b.code, p.name FROM batches b JOIN products p ON p.id = b.product_id WHERE b.shift_id = ? AND b.status = 'active'", [s.id]);
  if (active.length) throw new AppError(`Finish these batches before closing the shift: ${active.map((a) => `${a.name} (${a.code})`).join(', ')}.`);
  const sb = shiftCloseBlockers(s.id);
  if (sb.length) throw new AppError(`Complete these checklists before closing the shift: ${sb.map((b) => `${b.name} (${b.left} left)`).join(', ')}.`);
  return db().transaction(() => {
    if (isOnShift(s.id, userId)) signOff(userId, null, userId, s.id);
    const still = db().all('SELECT u.name FROM shift_workers sw JOIN users u ON u.id = sw.user_id WHERE sw.shift_id = ? AND sw.signed_off_at IS NULL', [s.id]);
    if (still.length) raiseAlert({ type: 'SIGNOFF', shiftId: s.id, userId, message: `Shift closed while still signed on: ${still.map((x) => x.name).join(', ')}. The supervisor must enter their sign-off time.` });
    db().run("UPDATE shifts SET status = 'closed', closed_by = ?, closed_at = ?, close_notes = ?, updated_at = ?, sync_status = 'pending' WHERE id = ?",
      [userId, stamp(), String(notes || '').trim() || null, stamp(), s.id]);
    return getShift(s.id);
  });
}

// ---------------- stock movements ----------------
function ensureMaterial(materialId) {
  const m = getMaterial(materialId);
  if (!m) throw new AppError('Please choose a material.');
  return m;
}

// lines: [{ material_id, qty, unit_price?, line_total?, lot_no?, expiry? }]
// check: { packOk, useByOk, temp, note }  (delivery check)
export function recordReceive(userId, { supplierId, invoiceNo, lines, note, photos, check = {} }) {
  const supRow = supplierId ? db().get('SELECT * FROM suppliers WHERE id = ?', [supplierId]) : null;
  if (!supRow) throw new AppError('Please choose the supplier.');
  const sup = supRow.name;
  const inv = String(invoiceNo || '').trim();
  if (!inv) throw new AppError('Please enter the invoice number.');
  const user = db().get('SELECT role FROM users WHERE id = ?', [userId]);
  const canPrice = user && user.role !== 'worker';
  const st = getSettings();
  const clean = (lines || []).filter((l) => l.material_id);
  if (!clean.length) throw new AppError('Add at least one item received.');
  clean.forEach((l) => {
    const m = ensureMaterial(l.material_id);
    l.qty = requirePositive(l.qty, `Quantity for ${m.name}`);
    l.name = m.name;
    l.unit = m.unit;
    let unit = null;
    if (canPrice) {
      if (l.unit_price !== null && l.unit_price !== undefined && l.unit_price !== '') unit = requireNonNegative(l.unit_price, `Price for ${m.name}`);
      else if (l.line_total !== null && l.line_total !== undefined && l.line_total !== '') unit = r3(requireNonNegative(l.line_total, `Total for ${m.name}`) / l.qty);
    }
    l.unit_cost = unit;
    l.lot_no = String(l.lot_no || '').trim() || null;
    l.expiry = String(l.expiry || '').trim() || null;
    if (l.expiry && !/^\d{4}-\d{2}-\d{2}$/.test(l.expiry)) throw new AppError(`Expiry date for ${m.name} must look like 2026-12-31.`);
    if (st.requireLotExpiry && m.track_stock && (!l.lot_no || !l.expiry)) throw new AppError(`Enter the lot number and expiry date for ${m.name}.`);
  });
  if (st.invoicePhotoRequired && !(photos || []).length) throw new AppError('A photo of the invoice is required.');
  const dup = db().get("SELECT txn_id FROM transactions WHERE type = 'RECEIVE' AND lower(invoice_no) = lower(?) AND supplier_id = ?", [inv, supplierId]);
  if (dup) throw new AppError(`Invoice ${inv} from ${sup} has already been recorded (${dup.txn_id}).`);
  const problems = [];
  if (check.packOk === false) problems.push('packaging damaged');
  if (check.useByOk === false) problems.push('use-by dates not OK');
  const temp = check.temp === null || check.temp === undefined || check.temp === '' ? null : Number(check.temp);
  if (temp !== null && temp > 5) problems.push(`chilled items at ${temp}°C`);
  const checkNote = [check.packOk === undefined ? null : `Packaging ${check.packOk ? 'OK' : 'NOT OK'}`,
    check.useByOk === undefined ? null : `Use-by ${check.useByOk ? 'OK' : 'NOT OK'}`, temp === null ? null : `Temp ${temp}°C`,
    check.note ? String(check.note).trim() : null].filter(Boolean).join(' · ') || null;
  return db().transaction(() => {
    const ids = [];
    const sid = currentShiftId();
    for (const l of clean) {
      const txnId = writeTxn({ type: 'RECEIVE', shiftId: sid, userId, materialId: l.material_id, qty: l.qty, supplier: sup, supplierId, invoiceNo: inv, note });
      db().run('UPDATE transactions SET unit_cost = ?, lot_no = ?, expiry = ?, check_note = ? WHERE txn_id = ?', [l.unit_cost, l.lot_no, l.expiry, checkNote, txnId]);
      changeStock(l.material_id, l.qty);
      const m = getMaterial(l.material_id);
      if (m.track_stock) addLot({ materialId: l.material_id, lotNo: l.lot_no, expiry: l.expiry, supplierId, invoiceNo: inv, txnId, qty: l.qty, unitCost: l.unit_cost });
      if (l.unit_cost !== null) db().run('UPDATE materials SET cost_per_unit = ?, cost_updated_at = ? WHERE id = ?', [l.unit_cost, stamp(), l.material_id]);
      ids.push(txnId);
    }
    addPhotos('invoice', inv, photos);
    if (problems.length) raiseAlert({ type: 'DELIVERY', shiftId: sid, userId, message: `Delivery ${inv} from ${sup}: ${problems.join(', ')}.` });
    checkReorder(userId);
    return ids;
  });
}

// mode: 'add' | 'remove' | 'set'
export function recordAdjustment(userId, materialId, mode, qty, reason) {
  const m = ensureMaterial(materialId);
  if (!m.track_stock) throw new AppError(`${m.name} is not stock-counted.`);
  const why = String(reason || '').trim();
  if (!why && mustExplain(userId)) throw new AppError('Please give a reason for the adjustment.');
  let delta;
  if (mode === 'add') delta = requirePositive(qty, 'Quantity');
  else if (mode === 'remove') delta = -requirePositive(qty, 'Quantity');
  else if (mode === 'set') delta = r3(requireNonNegative(qty, 'New stock level') - m.stock);
  else throw new AppError('Choose Add, Remove or Set.');
  if (delta === 0) throw new AppError('The stock is already at that level. Nothing to adjust.');
  return db().transaction(() => {
    const txnId = writeTxn({ type: 'ADJUST', shiftId: currentShiftId(), userId, materialId: m.id, qty: delta,
      note: mode === 'set' ? `Set to ${r3(m.stock + delta)} ${m.unit}: ${why}` : why });
    changeStock(m.id, delta, { txnId });
    checkReorder(userId);
    return { txnId, delta, newStock: r3(m.stock + delta) };
  });
}

function requireOnShift(userId) {
  const s = getOpenShift();
  if (!s) throw new AppError('There is no open shift. Start a shift first.');
  if (!isOnShift(s.id, userId)) throw new AppError('Please sign on to the shift first.');
  return s;
}

export function recordWastage(userId, materialId, qty, reason, note, photos) {
  const s = requireOnShift(userId);
  const m = ensureMaterial(materialId);
  const q = requirePositive(qty, 'Wasted quantity');
  const why = String(reason || '').trim();
  if (!why) throw new AppError('Please choose a reason for the wastage.');
  return db().transaction(() => {
    const txnId = writeTxn({ type: 'WASTAGE', shiftId: s.id, userId, materialId: m.id, qty: q, note: note ? `${why}: ${String(note).trim()}` : why });
    changeStock(m.id, -q, { txnId });
    addPhotos('wastage', txnId, photos);
    checkReorder(userId);
    return txnId;
  });
}

// Extra ingredient used outside a batch (e.g. greasing trays).
export function recordExtraUsage(userId, materialId, qty, note) {
  const s = requireOnShift(userId);
  const m = ensureMaterial(materialId);
  const q = requirePositive(qty, 'Quantity used');
  const why = String(note || '').trim();
  if (!why) throw new AppError('Please say what it was used for.');
  return db().transaction(() => {
    const txnId = writeTxn({ type: 'USAGE', shiftId: s.id, userId, materialId: m.id, qty: q, expectedQty: 0, variance: q, note: `Extra use: ${why}` });
    changeStock(m.id, -q, { txnId });
    checkReorder(userId);
    return txnId;
  });
}

// ---------------- transactions / activity ----------------
export function listTransactions({ shiftId, userId, type, from, to, limit = 300 } = {}) {
  const where = [];
  const params = [];
  if (shiftId) { where.push('t.shift_id = ?'); params.push(shiftId); }
  if (userId) { where.push('t.user_id = ?'); params.push(userId); }
  if (type) { where.push('t.type = ?'); params.push(type); }
  if (from) { where.push('t.txn_date >= ?'); params.push(from); }
  if (to) { where.push('t.txn_date <= ?'); params.push(to); }
  params.push(limit);
  return db().all(
    `SELECT t.*, u.name AS user_name, m.name AS material_name, m.unit AS material_unit,
       p.name AS product_name, p.unit AS product_unit, s.code AS shift_code, s.shift_name, b.code AS batch_code
     FROM transactions t JOIN users u ON u.id = t.user_id LEFT JOIN materials m ON m.id = t.material_id
     LEFT JOIN products p ON p.id = t.product_id LEFT JOIN shifts s ON s.id = t.shift_id LEFT JOIN batches b ON b.id = t.batch_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY t.id DESC LIMIT ?`,
    params
  );
}

// ---------------- balancing ----------------
function movementTotals(shiftId) {
  const rows = db().all(
    `SELECT material_id,
       SUM(CASE WHEN type = 'RECEIVE' THEN qty ELSE 0 END) AS received,
       SUM(CASE WHEN type = 'USAGE' THEN qty ELSE 0 END) AS used,
       SUM(CASE WHEN type = 'USAGE' THEN COALESCE(expected_qty, 0) ELSE 0 END) AS expected_use,
       SUM(CASE WHEN type = 'WASTAGE' THEN qty ELSE 0 END) AS wasted,
       SUM(CASE WHEN type = 'ADJUST' THEN qty ELSE 0 END) AS adjusted
     FROM transactions WHERE shift_id = ? AND material_id IS NOT NULL GROUP BY material_id`,
    [shiftId]
  );
  const map = {};
  for (const r of rows) map[r.material_id] = r;
  return map;
}

// Expected closing = opening + received - used - wasted + adjustments
export function getBalanceSheet(shiftId) {
  const totals = movementTotals(shiftId);
  return db().all(
    `SELECT ss.*, m.name, m.unit, m.tolerance_pct AS mat_tol FROM shift_stock ss JOIN materials m ON m.id = ss.material_id
     WHERE ss.shift_id = ? ORDER BY m.name`,
    [shiftId]
  ).map((r) => {
    const t = totals[r.material_id] || {};
    const received = r3(t.received || 0);
    const used = r3(t.used || 0);
    const wasted = r3(t.wasted || 0);
    const adjusted = r3(t.adjusted || 0);
    const expected = r3(r.opening + received - used - wasted + adjusted);
    const tol = r.tolerance_pct !== null && r.tolerance_pct !== undefined ? Number(r.tolerance_pct) : toleranceFor({ tolerance_pct: r.mat_tol });
    return {
      material_id: r.material_id, name: r.name, unit: r.unit, system_opening: r.system_opening, opening: r.opening,
      received, used, expected_use: r3(t.expected_use || 0), wasted, adjusted, expected,
      actual: r.actual, variance: r.variance, over_tolerance: r.over_tolerance, reason: r.reason, tolerance_pct: tol,
    };
  });
}

export function checkVariance(expected, actual, tolerancePct) {
  const variance = r3(actual - expected);
  const limit = r3((Math.abs(expected) * tolerancePct) / 100);
  const pct = expected !== 0 ? Math.round((variance / Math.abs(expected)) * 1000) / 10 : (variance === 0 ? 0 : null);
  const over = Math.abs(variance) > limit + 1e-9;
  return { variance, limit, pct, over };
}

export function approveShift(supervisorId, shiftId, counts, reasons = {}, notes) {
  const s = getShift(shiftId);
  if (!s) throw new AppError('Shift not found.');
  if (s.status === 'open') throw new AppError('This shift is still open. It must be closed first.');
  if (s.status === 'approved') throw new AppError('This shift has already been approved.');
  const still = db().all('SELECT u.name FROM shift_workers sw JOIN users u ON u.id = sw.user_id WHERE sw.shift_id = ? AND sw.signed_off_at IS NULL', [shiftId]);
  if (still.length) throw new AppError(`Enter the sign-off time for: ${still.map((x) => x.name).join(', ')}.`);
  const sheet = getBalanceSheet(shiftId);
  const missing = sheet.filter((r) => counts[r.material_id] === undefined || counts[r.material_id] === null || counts[r.material_id] === '' || !Number.isFinite(Number(counts[r.material_id])));
  if (missing.length) throw new AppError(`Enter the physical count for: ${missing.map((m) => m.name).join(', ')}.`);
  const negative = sheet.filter((r) => Number(counts[r.material_id]) < 0);
  if (negative.length) throw new AppError(`Counts cannot be negative (${negative.map((m) => m.name).join(', ')}).`);
  const needReason = [];
  const results = sheet.map((r) => {
    const actual = r3(counts[r.material_id]);
    const v = checkVariance(r.expected, actual, r.tolerance_pct);
    const reason = String(reasons[r.material_id] || '').trim();
    if (v.over && !reason) needReason.push(r.name);
    return { ...r, actual, ...v, reason };
  });
  if (needReason.length && mustExplain(supervisorId)) throw new AppError(`Variance is above tolerance. A reason is required for: ${needReason.join(', ')}.`);

  return db().transaction(() => {
    for (const r of results) {
      db().run(
        `UPDATE shift_stock SET received = ?, used = ?, wasted = ?, adjusted = ?, expected = ?, actual = ?, variance = ?, tolerance_pct = ?,
           over_tolerance = ?, reason = ? WHERE shift_id = ? AND material_id = ?`,
        [r.received, r.used, r.wasted, r.adjusted, r.expected, r.actual, r.variance, r.tolerance_pct, r.over ? 1 : 0, r.reason || null, shiftId, r.material_id]
      );
      let btx = null;
      if (r.variance !== 0) {
        btx = writeTxn({ type: 'BALANCE', shiftId, userId: supervisorId, materialId: r.material_id, qty: r.variance, expectedQty: r.expected, variance: r.variance, note: r.reason || 'Within tolerance' });
      }
      if (r.over) raiseAlert({ type: 'BALANCE', shiftId, userId: supervisorId, message: `${r.name}: counted ${r.actual} ${r.unit}, expected ${r.expected} (${r.variance > 0 ? '+' : ''}${r.variance}). Reason: ${r.reason}` });
      // The physical count becomes the stock level (shortages also come off the oldest lots).
      if (r.variance !== 0) changeStock(r.material_id, r.variance, { txnId: btx });
    }
    db().run(
      `UPDATE shifts SET status = 'approved', approved_by = ?, approved_at = ?, approval_notes = ?, updated_at = ?, sync_status = 'pending' WHERE id = ?`,
      [supervisorId, stamp(), String(notes || '').trim() || null, stamp(), shiftId]
    );
    enqueue('report', { shiftId });
    checkReorder(supervisorId);
    return getShift(shiftId);
  });
}

export function markReportSent(shiftId) {
  db().run('UPDATE shifts SET report_sent_at = ? WHERE id = ?', [stamp(), shiftId]);
}
