// v3.9.6 Shop profile: one page per shop with everything about it – details and opening hours, the bill accounts
// (EFL, WAF, phone, internet… several per shop, each labelled), its papers (licences & permits with their copies and
// expiry dates), the shop at a glance today, and what the shop costs (VIEW ONLY: costs are still entered in Receive,
// Invoices, Regular payments and Loans & rent).
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays } from './core.js';
import { can, actsAsOwner } from './access.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const safe = (f, d) => { try { const v = f(); return v === undefined ? d : v; } catch (e) { return d; } };

// Extra details kept on the shop record (added on start-up by src/db/columns.js, synced with the shop).
export const SHOP_COLUMNS = [['address', 'TEXT'], ['phone', 'TEXT'], ['email', 'TEXT'], ['tin', 'TEXT'], ['mpaisa', 'TEXT'], ['hours', 'TEXT'], ['manager_uid', 'TEXT'], ['notes', 'TEXT'], ['landlord', 'TEXT']];

export const SHOP_SQL = `
CREATE TABLE IF NOT EXISTS shop_accounts (
  uid TEXT PRIMARY KEY,
  shop_code TEXT NOT NULL,
  kind TEXT NOT NULL,
  label TEXT NOT NULL,
  provider TEXT,
  account_no TEXT,
  meter_no TEXT,
  holder TEXT,
  supplier_uid TEXT,
  recurring_uid TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_by TEXT, created_at TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_shop_accounts ON shop_accounts(shop_code, kind);
`;
const SYNC = (key, section, cols) => ({ key, section, cols: cols.concat(['updated_at', 'updated_device']) });
export const SHOP_SYNC = {
  shop_accounts: SYNC('uid', 'Settings', ['uid', 'shop_code', 'kind', 'label', 'provider', 'account_no', 'meter_no', 'holder', 'supplier_uid', 'recurring_uid', 'notes', 'active', 'created_by', 'created_at']),
};

export const ACCOUNT_KINDS = {
  power: { label: 'Electricity', icon: '⚡', provider: 'EFL (Energy Fiji Limited)', meter: true },
  water: { label: 'Water', icon: '💧', provider: 'WAF (Water Authority of Fiji)', meter: true },
  phone: { label: 'Phone', icon: '📞', provider: '', meter: false },
  internet: { label: 'Internet', icon: '🌐', provider: '', meter: false },
  gas: { label: 'Gas', icon: '🔥', provider: '', meter: false },
  rent: { label: 'Rent', icon: '🏠', provider: '', meter: false },
  rates: { label: 'City rates', icon: '🏛️', provider: 'Lautoka City Council', meter: false },
  waste: { label: 'Rubbish / waste', icon: '🗑️', provider: '', meter: false },
  security: { label: 'Security', icon: '🛡️', provider: '', meter: false },
  other: { label: 'Other', icon: '📄', provider: '', meter: false },
};
export const DAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
const DAY_OF = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

const boss = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || ['owner', 'admin'].includes(u.realRole));
// Who may open a shop's page, change it, and see what it costs.
export function canSeeShop(u) { return !!u && (boss(u) || can(u, 'settings') || can(u, 'licences_view') || can(u, 'ap_setup') || can(u, 'accounts_view')); }
export function canEditShop(u) { return !!u && (boss(u) || can(u, 'settings')); }
export function canSeeCosts(u) { return !!u && (boss(u) || can(u, 'accounts_view') || can(u, 'ap_setup') || can(u, 'payments_make')); }
export function canSeeWages(u) { return !!u && (boss(u) || can(u, 'payroll_view')); }
export function canSeeLoans(u) { return !!u && (boss(u) || can(u, 'loans_manage') || can(u, 'accounts_view')); }

// ---------------------------------------------------------------- details & opening hours
export function getShop(code) {
  const c = txt(code).toUpperCase();
  if (!c) return null;
  const s = db().get('SELECT * FROM shops WHERE code = ?', [c]);
  if (!s) return null;
  return { ...s, hours: normHours(J(s.hours, {})) };
}
export function normHours(h) {
  const out = {};
  for (const [d] of DAYS) {
    const x = (h && typeof h === 'object' && h[d] && typeof h[d] === 'object') ? h[d] : {};
    out[d] = { closed: !!x.closed, open: HHMM.test(txt(x.open)) ? txt(x.open) : '', close: HHMM.test(txt(x.close)) ? txt(x.close) : '' };
  }
  return out;
}
// Open now? (a closing time before the opening time runs past midnight)
export function openNow(hours, now = new Date()) {
  const h = normHours(hours);
  const d = h[DAY_OF[now.getDay()]];
  const t = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  if (!d || d.closed || !d.open || !d.close) {
    // still open from yesterday's late night?
    const y = h[DAY_OF[(now.getDay() + 6) % 7]];
    if (y && !y.closed && y.open && y.close && y.close < y.open && t < y.close) return { open: true, until: y.close };
    return { open: false, known: !!(d && (d.closed || (d.open && d.close))), next: nextOpen(h, now) };
  }
  if (d.close > d.open) return t >= d.open && t < d.close ? { open: true, until: d.close } : { open: false, known: true, next: t < d.open ? { day: 'today', at: d.open } : nextOpen(h, now) };
  // runs past midnight
  if (t >= d.open) return { open: true, until: d.close };
  const y = h[DAY_OF[(now.getDay() + 6) % 7]];
  if (y && !y.closed && y.open && y.close && y.close < y.open && t < y.close) return { open: true, until: y.close };
  return { open: false, known: true, next: { day: 'today', at: d.open } };
}
function nextOpen(h, now) {
  for (let k = 1; k <= 7; k += 1) {
    const day = DAY_OF[(now.getDay() + k) % 7];
    const d = h[day];
    if (d && !d.closed && d.open) return { day: k === 1 ? 'tomorrow' : DAYS.find((x) => x[0] === day)[1], at: d.open };
  }
  return null;
}
export function hoursText(d) {
  if (!d) return '–';
  if (d.closed) return 'Closed';
  if (!d.open || !d.close) return 'Not set';
  return `${d.open} – ${d.close}${d.close < d.open ? ' (next day)' : ''}`;
}

const TIN = /^[0-9\s-]{6,20}$/;
export function saveShopDetails(user, code, f = {}) {
  need(canEditShop(user), 'Only the owner, admin or someone with Settings can change a shop.');
  const s = db().get('SELECT * FROM shops WHERE code = ?', [txt(code).toUpperCase()]);
  need(s, 'This shop is not in the list any more.');
  const name = txt(f.name ?? s.name);
  need(name, 'Enter the shop name.');
  need(name.length <= 80, 'The shop name is too long (80 letters at most).');
  const lim = (k, n, label) => { const v = txt(f[k] ?? s[k]); need(v.length <= n, `${label} is too long (${n} letters at most).`); return v || null; };
  const address = lim('address', 200, 'The address');
  const phone = lim('phone', 40, 'The phone number');
  const email = lim('email', 120, 'The email');
  if (email) need(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), 'The email does not look right.');
  const tin = lim('tin', 20, 'The TIN');
  if (tin) need(TIN.test(tin), 'The TIN should be numbers only (spaces or dashes are fine).');
  const mpaisa = lim('mpaisa', 40, 'The M-PAiSA wallet');
  const landlord = lim('landlord', 120, 'The landlord');
  const notes = lim('notes', 1000, 'The notes');
  const managerUid = txt(f.managerUid ?? s.manager_uid) || null;
  if (managerUid) need(db().get('SELECT 1 AS x FROM users WHERE uid = ?', [managerUid]), 'The person in charge is not in the staff list.');
  let hours = J(s.hours, {});
  if (f.hours !== undefined) {
    need(f.hours && typeof f.hours === 'object', 'The opening hours are not complete.');
    for (const [d, label] of DAYS) {
      const x = f.hours[d] || {};
      if (x.closed) continue;
      const o = txt(x.open); const c = txt(x.close);
      if (!o && !c) continue;
      need(HHMM.test(o), `${label}: opening time should look like 07:00.`);
      need(HHMM.test(c), `${label}: closing time should look like 21:00.`);
      need(o !== c, `${label}: opening and closing time are the same.`);
    }
    hours = normHours(f.hours);
  }
  const after = { name, address, phone, email, tin, mpaisa, landlord, notes, manager_uid: managerUid, hours: JSON.stringify(hours) };
  db().run(`UPDATE shops SET name = ?, address = ?, phone = ?, email = ?, tin = ?, mpaisa = ?, landlord = ?, notes = ?, manager_uid = ?, hours = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE code = ?`,
    [name, address, phone, email, tin, mpaisa, landlord, notes, managerUid, after.hours, stamp(), deviceId(), s.code]);
  audit({ user, action: 'Changed shop details', table: 'shops', recordUid: s.code, before: s, after });
  return s.code;
}

// ---------------------------------------------------------------- bill accounts
export function listAccounts(code, { all = false } = {}) {
  if (!has('shop_accounts')) return [];
  const rows = db().all(`SELECT * FROM shop_accounts WHERE shop_code = ? ${all ? '' : 'AND active = 1'} ORDER BY active DESC, kind, label`, [txt(code).toUpperCase()]);
  return rows.map((a) => ({ ...a, kindInfo: ACCOUNT_KINDS[a.kind] || ACCOUNT_KINDS.other, last: safe(() => lastBill(a), null), regular: safe(() => regularOf(a), null) }));
}
export function getAccount(uid) { return has('shop_accounts') ? db().get('SELECT * FROM shop_accounts WHERE uid = ?', [uid]) || null : null; }
// The latest bill for an account: an invoice from its supplier for this shop that mentions the account number,
// else the latest invoice from that supplier for this shop.
function lastBill(a) {
  if (!a.supplier_uid || !has('ap_invoices')) return null;
  const rows = db().all("SELECT uid, invoice_no, invoice_date, due_date, total, description, notes FROM ap_invoices WHERE supplier_uid = ? AND (shop_code = ? OR shop_code IS NULL OR shop_code = '') AND status <> 'void' AND IFNULL(kind,'invoice') = 'invoice' ORDER BY invoice_date DESC LIMIT 30", [a.supplier_uid, a.shop_code]);
  if (!rows.length) return null;
  const no = txt(a.account_no).replace(/\s/g, '');
  const hit = no ? rows.find((r) => `${r.invoice_no || ''} ${r.description || ''} ${r.notes || ''}`.replace(/\s/g, '').includes(no)) : null;
  const r = hit || rows[0];
  let owing = null;
  try { const P = require('../modules/payables/service.js'); const i = P.listInvoices({ filter: 'all', limit: 2000 }).find((x) => x.uid === r.uid); owing = i ? r2(i.owing) : null; } catch (e) { owing = null; }
  return { uid: r.uid, no: r.invoice_no, date: r.invoice_date, due: r.due_date, total: r2(r.total), owing, matched: !!hit };
}
function regularOf(a) {
  if (!a.recurring_uid || !has('ap_recurring')) return null;
  const r = db().get('SELECT uid, name, amount, frequency, next_date, active FROM ap_recurring WHERE uid = ?', [a.recurring_uid]);
  return r ? { uid: r.uid, name: r.name, amount: r2(r.amount), frequency: r.frequency, next: r.next_date, active: !!r.active } : null;
}
export function saveAccount(user, f = {}) {
  need(canEditShop(user), 'Only the owner, admin or someone with Settings can change bill accounts.');
  const code = txt(f.shopCode).toUpperCase();
  need(code && db().get('SELECT 1 AS x FROM shops WHERE code = ?', [code]), 'Choose the shop.');
  const kind = txt(f.kind) || 'other';
  need(ACCOUNT_KINDS[kind], 'Choose what the account is for.');
  const label = txt(f.label) || ACCOUNT_KINDS[kind].label;
  need(label.length <= 80, 'The name is too long (80 letters at most).');
  const accountNo = txt(f.accountNo);
  need(accountNo || kind === 'other' || kind === 'rent', 'Enter the account number (it is on the bill).');
  need(accountNo.length <= 40, 'The account number is too long.');
  need(!accountNo || /^[A-Za-z0-9\s\-/.]+$/.test(accountNo), 'The account number has odd characters – type it as it is on the bill.');
  const meterNo = txt(f.meterNo); need(meterNo.length <= 40, 'The meter number is too long.');
  const provider = txt(f.provider) || ACCOUNT_KINDS[kind].provider || null; need(!provider || provider.length <= 80, 'The provider name is too long.');
  const holder = txt(f.holder) || null; need(!holder || holder.length <= 120, 'The name on the bill is too long.');
  const notes = txt(f.notes) || null; need(!notes || notes.length <= 1000, 'The notes are too long.');
  const supplierUid = txt(f.supplierUid) || null;
  if (supplierUid) need(has('ap_suppliers') && db().get('SELECT 1 AS x FROM ap_suppliers WHERE uid = ?', [supplierUid]), 'That supplier is not in the list any more.');
  const recurringUid = txt(f.recurringUid) || null;
  if (recurringUid) need(has('ap_recurring') && db().get('SELECT 1 AS x FROM ap_recurring WHERE uid = ?', [recurringUid]), 'That regular payment is not in the list any more.');
  const norm = (v) => txt(v).replace(/[\s\-/.]/g, '').toUpperCase();
  if (accountNo) {
    const twin = db().all('SELECT a.uid, a.label, a.shop_code, s.name AS shop_name FROM shop_accounts a LEFT JOIN shops s ON s.code = a.shop_code WHERE a.active = 1 AND a.kind = ? AND a.uid <> ?', [kind, txt(f.uid)])
      .find((x) => norm(db().get('SELECT account_no FROM shop_accounts WHERE uid = ?', [x.uid]).account_no) === norm(accountNo));
    need(!twin, `This account number is already on ${twin && (twin.shop_name || twin.shop_code)} (${twin && twin.label}).`);
  }
  const before = f.uid ? getAccount(f.uid) : null;
  if (f.uid) need(before, 'This bill account is not in the list any more.');
  const n = db().get('SELECT COUNT(*) AS n FROM shop_accounts WHERE shop_code = ? AND active = 1', [code]).n;
  if (!before) need(n < 50, 'A shop can have 50 bill accounts at most.');
  const now = stamp(); const dev = deviceId();
  const uid = before ? before.uid : uuid('SA');
  const vals = [code, kind, label, provider, accountNo || null, meterNo || null, holder, supplierUid, recurringUid, notes];
  if (before) db().run(`UPDATE shop_accounts SET shop_code=?, kind=?, label=?, provider=?, account_no=?, meter_no=?, holder=?, supplier_uid=?, recurring_uid=?, notes=?, active=1, updated_at=?, updated_device=?, sync_status='pending' WHERE uid=?`, [...vals, now, dev, uid]);
  else db().run(`INSERT INTO shop_accounts (uid, shop_code, kind, label, provider, account_no, meter_no, holder, supplier_uid, recurring_uid, notes, active, created_by, created_at, updated_at, updated_device, sync_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?,?,?,?,'pending')`,
    [uid, ...vals, user ? user.name : '', now, now, dev]);
  audit({ user, action: before ? 'Changed bill account' : 'Added bill account', table: 'shop_accounts', recordUid: uid, before, after: { code, kind, label, accountNo, meterNo } });
  return uid;
}

// ---------------------------------------------------------------- papers (licences & permits of this shop)
export function shopPapers(code, today = dateStr()) {
  try {
    const L = require('../modules/licences/service.js');
    return L.listLicences({ shopCode: txt(code).toUpperCase(), filter: 'all', today });
  } catch (e) { return []; }
}

// ---------------------------------------------------------------- at a glance
export function shopGlance(code, viewer, today = dateStr()) {
  const c = txt(code).toUpperCase();
  const out = { sales: null, staff: null, tills: [], verify: null, orders: null, papers: null, stock: null };
  // sales today against the usual for this weekday (till PCs, else till balances)
  if (can(viewer, 'reports') || can(viewer, 'dashboard') || boss(viewer)) {
    out.sales = safe(() => {
      const B = require('./board.js');
      const S = B.shopSalesByDay(addDays(today, -35));
      const val = (d) => r2(S.rows.filter((r) => r.shop === c && r.date === d).reduce((a, r) => a + r.value, 0));
      const usual = [7, 14, 21, 28].map((n) => val(addDays(today, -n))).filter((v) => v > 0);
      return { today: val(today), yesterday: val(addDays(today, -1)), usual: usual.length ? r2(usual.reduce((a, b) => a + b, 0) / usual.length) : null, source: S.source };
    }, null);
  }
  out.staff = safe(() => {
    const W = require('../modules/timesheets/roster.js');
    const list = W.whoIsOn(c);
    const inNow = list.filter((x) => x.state === 'in' || x.state === 'break');
    return { list, in: inNow.length, late: list.filter((x) => x.status === 'late').length, total: list.length };
  }, null);
  out.tills = safe(() => require('../modules/aronium/link.js').linkStatus().tills.filter((t) => t.shop === c), []);
  if (can(viewer, 'verify_money') || boss(viewer)) out.verify = safe(() => require('../modules/verify/service.js').queue({ shopCode: c }).filter((x) => x.shop === c).length, null);
  if (can(viewer, 'inventory_view') || can(viewer, 'po_create') || boss(viewer)) {
    out.orders = safe(() => {
      if (!has('po_orders')) return null;
      const open = db().all("SELECT uid, status, expected_date FROM po_orders WHERE shop_code = ? AND status IN ('awaiting','approved','sent','part')", [c]);
      return { open: open.length, awaiting: open.filter((p) => p.status === 'awaiting').length, late: open.filter((p) => p.expected_date && p.expected_date < today && p.status !== 'awaiting').length };
    }, null);
    out.stock = safe(() => { const l = require('../modules/inventory/service.js').stockList({ shopCode: c, filter: 'low', limit: 3000 }); return { low: l.length, out: l.filter((r) => r.on_hand <= 0).length }; }, null);
  }
  const p = shopPapers(c, today);
  out.papers = { total: p.filter((x) => x.state !== 'cancelled').length, due: p.filter((x) => x.state === 'due' || x.state === 'renewing').length, overdue: p.filter((x) => x.state === 'overdue').length, noCopy: p.filter((x) => x.noCopy).length };
  return out;
}

// ---------------------------------------------------------------- what the shop costs (view only)
export function periodRange(period, today = dateStr()) {
  const m = today.slice(0, 7);
  if (period === 'last') {
    const d = new Date(`${m}-01T12:00:00`); d.setMonth(d.getMonth() - 1);
    const lm = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    return { from: `${lm}-01`, to: addDays(`${m}-01`, -1), label: 'Last month' };
  }
  if (period === 'year') return { from: `${today.slice(0, 4)}-01-01`, to: today, label: `${today.slice(0, 4)} so far` };
  if (period === '12m') return { from: addDays(today, -364), to: today, label: 'Last 12 months' };
  return { from: `${m}-01`, to: today, label: 'This month' };
}
export function shopCosts(code, viewer, { period = 'month', today = dateStr() } = {}) {
  need(canSeeCosts(viewer), 'You do not have access to what the shop costs.');
  const c = txt(code).toUpperCase();
  const { from, to, label } = periodRange(period, today);
  const out = { from, to, label, groups: [], invoices: [], regular: [], wages: null, total: 0, vat: 0 };
  if (has('ap_invoices')) {
    const rows = db().all("SELECT uid, kind, supplier_name, invoice_no, invoice_date, total, vat, category, status FROM ap_invoices WHERE shop_code = ? AND status <> 'void' AND invoice_date BETWEEN ? AND ? ORDER BY invoice_date DESC", [c, from, to]);
    const cats = new Map();
    for (const r of rows) {
      const sign = r.kind === 'credit' ? -1 : 1;
      const k = txt(r.category) || 'Other';
      const g = cats.get(k) || { name: k, total: 0, vat: 0, count: 0 };
      g.total = r2(g.total + sign * (Number(r.total) || 0)); g.vat = r2(g.vat + sign * (Number(r.vat) || 0)); g.count += 1;
      cats.set(k, g);
      out.total = r2(out.total + sign * (Number(r.total) || 0)); out.vat = r2(out.vat + sign * (Number(r.vat) || 0));
    }
    out.groups = [...cats.values()].sort((a, b) => b.total - a.total);
    out.invoices = rows.slice(0, 60).map((r) => ({ ...r, total: r2((r.kind === 'credit' ? -1 : 1) * (Number(r.total) || 0)) }));
    out.count = rows.length;
  }
  if (has('ap_recurring')) {
    const loans = canSeeLoans(viewer);
    out.regular = db().all('SELECT uid, kind, name, amount, frequency, next_date, category FROM ap_recurring WHERE shop_code = ? AND active = 1 ORDER BY kind DESC, name', [c])
      .filter((r) => r.kind !== 'loan' || loans).map((r) => ({ ...r, amount: r2(r.amount), monthly: r2(monthly(r.amount, r.frequency)) }));
    out.regularMonthly = r2(out.regular.reduce((a, r) => a + r.monthly, 0));
  }
  if (canSeeWages(viewer) && has('pay_lines') && has('pay_runs')) {
    const w = db().get("SELECT COUNT(DISTINCT l.user_uid) AS people, SUM(l.gross) AS gross, SUM(l.fnpf_employer) AS fnpf FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid WHERE r.status = 'final' AND l.include = 1 AND l.shop_code = ? AND r.pay_date BETWEEN ? AND ?", [c, from, to]);
    out.wages = { people: (w && w.people) || 0, gross: r2(w && w.gross), fnpf: r2(w && w.fnpf), total: r2((Number(w && w.gross) || 0) + (Number(w && w.fnpf) || 0)) };
  }
  out.all = r2(out.total + (out.wages ? out.wages.total : 0));
  return out;
}
export function monthly(amount, freq) {
  const a = Number(amount) || 0;
  return { weekly: (a * 52) / 12, fortnightly: (a * 26) / 12, monthly: a, quarterly: a / 3, yearly: a / 12 }[freq] ?? a;
}

// ---------------------------------------------------------------- the page
export function shopProfile(code, viewer, today = dateStr()) {
  need(canSeeShop(viewer), 'You do not have access to the shop pages.');
  const s = getShop(code);
  need(s, 'This shop is not in the list.');
  const manager = s.manager_uid ? safe(() => db().get('SELECT uid, name FROM users WHERE uid = ?', [s.manager_uid]), null) : null;
  const accounts = listAccounts(s.code);
  const papers = shopPapers(s.code, today);
  const warnings = [];
  if (!s.address) warnings.push({ key: 'address', text: 'No address yet.' });
  if (!s.tin) warnings.push({ key: 'tin', text: 'No TIN yet (printed on the shop\'s purchase orders).' });
  if (!DAYS.some(([d]) => s.hours[d].closed || (s.hours[d].open && s.hours[d].close))) warnings.push({ key: 'hours', text: 'Opening hours are not set.' });
  if (!accounts.some((a) => a.kind === 'power')) warnings.push({ key: 'power', text: 'No electricity (EFL) account yet.' });
  if (!accounts.some((a) => a.kind === 'water')) warnings.push({ key: 'water', text: 'No water (WAF) account yet.' });
  papers.filter((p) => p.state === 'overdue').forEach((p) => warnings.push({ key: `lic-${p.uid}`, text: `${p.name} has expired (${p.expiry_date}).` }));
  papers.filter((p) => p.state !== 'cancelled' && p.noCopy).slice(0, 5).forEach((p) => warnings.push({ key: `copy-${p.uid}`, text: `No copy of the ${p.name} attached.` }));
  return { shop: s, manager, accounts, papers, warnings, open: openNow(s.hours), glance: shopGlance(s.code, viewer, today) };
}
// Every shop with a few counts (the list of shop pages).
export function shopCards(viewer, today = dateStr()) {
  need(canSeeShop(viewer), 'You do not have access to the shop pages.');
  return db().all('SELECT * FROM shops ORDER BY active DESC, sort, code').map((s) => {
    const p = shopPapers(s.code, today);
    return { code: s.code, name: s.name, active: !!s.active, address: s.address, open: openNow(J(s.hours, {})),
      accounts: safe(() => db().get('SELECT COUNT(*) AS n FROM shop_accounts WHERE shop_code = ? AND active = 1', [s.code]).n, 0),
      papers: p.filter((x) => x.state !== 'cancelled').length, attention: p.filter((x) => ['due', 'overdue', 'renewing'].includes(x.state)).length };
  });
}

// ---------------------------------------------------------------- v3.9.7 the shop's small dashboard
// "Coming up" (the next 14 days and anything overdue) and "Standings" (this month so far against the same days of
// last month). Each part only for those who may see it; one part failing never stops the page.
const dmy = (d) => String(d || '').slice(0, 10);
function sameDaysLastMonth(today) {
  const m = today.slice(0, 7);
  const d = new Date(`${m}-01T12:00:00`); d.setMonth(d.getMonth() - 1);
  const lm = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  const day = Math.min(Number(today.slice(8, 10)), last);
  return { from: `${lm}-01`, to: `${lm}-${String(day).padStart(2, '0')}` };
}
export function shopDashboard(code, viewer, today = dateStr()) {
  need(canSeeShop(viewer), 'You do not have access to the shop pages.');
  const c = txt(code).toUpperCase();
  const until = addDays(today, 14);
  const up = [];
  // bills and invoices of this shop not paid yet (rent, power, water, loans tied to the shop, suppliers)
  if (canSeeCosts(viewer)) {
    safe(() => {
      const AP = require('../modules/payables/service.js');
      // loan repayments only for those who may see the loans
      const loanUids = canSeeLoans(viewer) || !has('ap_recurring') ? [] : db().all("SELECT uid FROM ap_recurring WHERE kind = 'loan'").map((r) => `RI-${r.uid}-`);
      for (const i of AP.listInvoices({ filter: 'unpaid' })) {
        if (i.shop_code !== c || !(i.owing > 0.004) || !i.due_date || i.due_date > until) continue;
        if (loanUids.some((p) => String(i.uid).startsWith(p))) continue;
        const late = i.due_date < today;
        up.push({ key: `inv-${i.uid}`, date: i.due_date, icon: late ? '🔴' : '🧾', text: `${i.supplier_name || 'Bill'}${i.invoice_no ? ` · ${i.invoice_no}` : ''}${late ? ' – overdue' : ''}`, amount: r2(i.owing), tone: late ? 'danger' : i.due_date <= addDays(today, 3) ? 'warn' : undefined, go: ['ApInvoice', { uid: i.uid }] });
      }
    }, null);
  }
  // papers and licences to renew
  for (const p of safe(() => shopPapers(c, today), [])) {
    if (!p.expiry_date || p.state === 'cancelled' || p.expiry_date > addDays(today, 30)) continue;
    up.push({ key: `lic-${p.uid}`, date: p.expiry_date, icon: p.state === 'overdue' ? '🔴' : '📜', text: `${p.name} ${p.state === 'overdue' ? 'expired' : 'expires'}`, amount: null, tone: p.state === 'overdue' ? 'danger' : 'warn', go: ['Licence', { uid: p.uid }] });
  }
  // orders expected
  if (has('po_orders') && (can(viewer, 'inventory_view') || can(viewer, 'po_create') || boss(viewer))) {
    for (const o of safe(() => db().all("SELECT uid, po_no, supplier_name, expected_date, total FROM po_orders WHERE shop_code = ? AND status IN ('approved','sent','part') AND expected_date IS NOT NULL AND expected_date <= ?", [c, until]), [])) {
      const late = o.expected_date < today;
      up.push({ key: `po-${o.uid}`, date: o.expected_date, icon: '🚚', text: `Order ${o.po_no} from ${o.supplier_name || 'supplier'}${late ? ' – late' : ' expected'}`, amount: null, tone: late ? 'warn' : undefined, go: ['POView', { uid: o.uid }] });
    }
  }
  // staff of this shop on leave
  if (has('leave_requests') && (can(viewer, 'leave_approve') || boss(viewer))) {
    for (const l of safe(() => db().all("SELECT l.uid, l.name, l.type, l.from_date, l.to_date FROM leave_requests l JOIN users u ON u.uid = l.user_uid WHERE u.shop_code = ? AND l.status = 'approved' AND l.to_date >= ? AND l.from_date <= ?", [c, today, until]), [])) {
      up.push({ key: `lv-${l.uid}`, date: l.from_date < today ? today : l.from_date, icon: '🌴', text: `${l.name} on ${l.type} leave ${l.from_date === l.to_date ? '' : `until ${l.to_date}`}`.trim(), amount: null, go: ['Leave', {}] });
    }
  }
  up.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));

  // standings: this month so far against the same days of last month
  const m = { from: `${today.slice(0, 7)}-01`, to: today };
  const lm = sameDaysLastMonth(today);
  const st = [];
  if (can(viewer, 'reports') || can(viewer, 'dashboard') || boss(viewer)) {
    safe(() => {
      const S = require('./board.js').shopSalesByDay(lm.from);
      const sum = (r) => r2(S.rows.filter((x) => x.shop === c && x.date >= r.from && x.date <= r.to).reduce((a, x) => a + x.value, 0));
      st.push({ key: 'sales', label: 'Sales', now: sum(m), last: sum(lm), money: true, good: 'up', go: ['ReportsHub', {}] });
    }, null);
  }
  if (canSeeCosts(viewer)) {
    safe(() => {
      const q = (r) => r2((db().get("SELECT SUM(CASE WHEN kind = 'credit' THEN -total ELSE total END) AS t FROM ap_invoices WHERE shop_code = ? AND status <> 'void' AND invoice_date BETWEEN ? AND ?", [c, r.from, r.to]) || {}).t);
      st.push({ key: 'costs', label: 'Invoices & bills', now: q(m), last: q(lm), money: true, good: 'down', go: ['ApInvoices', {}] });
      const AP = require('../modules/payables/service.js');
      const owing = r2(AP.listInvoices({ filter: 'unpaid' }).filter((i) => i.shop_code === c && !String(i.uid).startsWith('RI-')).reduce((a, i) => a + (Number(i.owing) || 0), 0));
      st.push({ key: 'owing', label: 'Owed to suppliers', now: owing, last: null, money: true, go: ['ApInvoices', { filter: 'due' }] });
    }, null);
  }
  if (can(viewer, 'till_approve') || boss(viewer)) {
    safe(() => {
      const q = (r) => r2((db().get("SELECT SUM(over_short) AS t FROM till_counts WHERE shop_code = ? AND status <> 'void' AND shift_date BETWEEN ? AND ?", [c, r.from, r.to]) || {}).t);
      st.push({ key: 'tills', label: 'Tills over / short', now: q(m), last: q(lm), money: true, signed: true, go: ['TillShortages', {}] });
      const coh = require('../modules/till/service.js').cashOnHand(c, today);
      st.push({ key: 'cash', label: 'Cash at the shop', now: r2(coh.onHand), last: null, money: true, go: ['CashOnHand', { shopCode: c }] });
    }, null);
  }
  if (can(viewer, 'wallets') || can(viewer, 'bank_rec') || boss(viewer)) {
    safe(() => {
      const W = require('../modules/bank/wallets.js');
      for (const w of W.listWallets().filter((x) => x.shop_code === c)) {
        const p = W.walletPosition(w.uid, today);
        st.push({ key: `wal-${w.uid}`, label: w.name || 'M-PAiSA', now: r2(p.balance), last: null, money: true, go: ['Wallet', { uid: w.uid }] });
      }
    }, null);
  }
  if (canSeeWages(viewer) && has('pay_runs')) {
    safe(() => {
      const q = (r) => r2((db().get("SELECT SUM(l.gross) AS t FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid WHERE r.status = 'final' AND l.include = 1 AND l.shop_code = ? AND r.pay_date BETWEEN ? AND ?", [c, r.from, r.to]) || {}).t);
      st.push({ key: 'wages', label: 'Wages paid', now: q(m), last: q(lm), money: true, go: ['Payroll', {}] });
    }, null);
  }
  return { upcoming: up, standings: st, month: m, lastMonth: lm };
}

// Everything else that belongs to the shop, so it is all on one page: tills, staff, M-PAiSA wallet, loans & rent.
export function shopBelongings(code, viewer) {
  need(canSeeShop(viewer), 'You do not have access to the shop pages.');
  const c = txt(code).toUpperCase();
  const tills = safe(() => db().all('SELECT uid, name, float_amount, active FROM tills WHERE shop_code = ? ORDER BY active DESC, sort, name', [c]), []);
  const staff = safe(() => db().all("SELECT uid, id, name, role, active FROM users WHERE shop_code = ? AND active = 1 AND COALESCE(sync_status,'') <> 'seed' ORDER BY name", [c]), []);
  const wallets = safe(() => db().all('SELECT uid, name, provider, phone_no FROM wallets WHERE shop_code = ? AND active = 1 ORDER BY sort', [c]), []);
  const loans = canSeeLoans(viewer);
  const regular = has('ap_recurring') && (canSeeCosts(viewer) || loans)
    ? safe(() => db().all('SELECT uid, kind, name, amount, frequency, next_date FROM ap_recurring WHERE shop_code = ? AND active = 1 ORDER BY kind DESC, name', [c]).filter((r) => r.kind !== 'loan' || loans), [])
    : [];
  return { tills, staff, wallets, regular };
}
