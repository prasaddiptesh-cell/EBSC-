// Safety copies ("snapshots") of the whole database on this tablet.
// - Every few hours while the app is in use, and before risky steps (app update, restore, year close, training mode
//   on / off, big imports): other modules call `await snapshotNow('reason')` first.
// - Kept: everything from the last 7 days, then one per week for a month.
// - Once a day a copy also goes to the folder outside the app chosen in Admin › Backup & restore.
// - The training (practice) database is never copied.
// The file name holds the time and the reason: eb-20261009-153000-auto.db
import { db } from '../db/connection.js';
import { getSetting, setSetting, stamp, dateStr, clock, parseStamp, audit, AppError } from './core.js';
import { isTraining } from './trainingFlag.js';
import { actsAsOwner } from './access.js';
import { deviceFs, outsideFolder, listOutside, copyToOutside, copyFromOutside, removeOutside } from '../platform/snapshotFiles.js';
import { plainPath } from '../platform/device.js';
import { requirePerm, asService, requireTop } from './guard.js';

export const EVERY_HOURS = 4;
export const KEEP_DAYS = 7;
export const KEEP_WEEKLY_DAYS = 31;
export const OUTSIDE_KEEP = 14;
export const REASONS = {
  auto: 'Every few hours', manual: 'Made by hand', daily: 'Daily copy', update: 'Before an app update', restore: 'Before a restore',
  'before-restore': 'Safety copy before a restore', 'year-close': 'Before closing a year', 'training-on': 'Before training mode',
  'training-off': 'After training mode', import: 'Before a big import', fresh: 'Before starting fresh', 'from-outside': 'Brought back from the outside folder',
};

let fsApi = deviceFs;
let outsideApi = { folder: outsideFolder, list: listOutside, copyTo: copyToOutside, copyFrom: copyFromOutside, remove: removeOutside };
// Tests (and later a Windows build) give their own file functions.
export function setSnapshotFs(api, outside) { fsApi = api || deviceFs; if (outside) outsideApi = outside; }
export function snapshotFs() { return fsApi; }

const pad = (n) => String(n).padStart(2, '0');
const slug = (r) => String(r || 'manual').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'manual';
export function snapshotName(reason, d = clock.now()) {
  return `eb-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}-${slug(reason)}.db`;
}
// eb-20261009-153000-auto.db → { at: '2026-10-09 15:30:00', reason: 'auto' }
export function parseSnapshotName(name) {
  const m = /^eb-(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})-([a-z0-9-]+)\.db$/.exec(String(name || ''));
  if (!m) return null;
  return { name, at: `${m[1]}-${m[2]}-${m[3]} ${m[4]}:${m[5]}:${m[6]}`, reason: m[7], label: REASONS[m[7]] || m[7].replace(/-/g, ' ') };
}

// Which copies to keep: every copy of the last 7 days, then the newest one of each week up to a month; the newest
// copy is always kept. Returns { keep: [names], drop: [names] }.
function weekKey(d) {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const day = (x.getDay() + 6) % 7; // Monday = 0
  x.setDate(x.getDate() - day);
  return `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}`;
}
export function retention(list, now = clock.now()) {
  const sorted = list.map((s) => (typeof s === 'string' ? parseSnapshotName(s) : s)).filter(Boolean).sort((a, b) => (a.at < b.at ? 1 : -1));
  const keep = []; const drop = []; const weeks = new Set();
  sorted.forEach((s, i) => {
    const age = (now.getTime() - parseStamp(s.at).getTime()) / 86400000;
    if (i === 0 || age <= KEEP_DAYS) { keep.push(s.name); return; }
    if (age <= KEEP_WEEKLY_DAYS) {
      const w = weekKey(parseStamp(s.at));
      if (!weeks.has(w)) { weeks.add(w); keep.push(s.name); return; }
    }
    drop.push(s.name);
  });
  return { keep, drop };
}

// Copies on this tablet, newest first: [{ name, at, reason, label, uri, size, where: 'tablet' }]
export async function listSnapshots({ sizes = true } = {}) {
  const dir = fsApi.dir();
  const names = (await fsApi.list(dir)).filter((n) => parseSnapshotName(n));
  const out = [];
  for (const n of names) {
    const s = parseSnapshotName(n);
    out.push({ ...s, uri: `${dir}${n}`, size: sizes ? await fsApi.size(`${dir}${n}`) : null, where: 'tablet' });
  }
  return out.sort((a, b) => (a.at < b.at ? 1 : -1));
}
export async function listOutsideCopies() {
  if (!outsideApi.folder()) return [];
  return (await outsideApi.list()).map((f) => ({ ...(parseSnapshotName(f.name) || { name: f.name, at: '', reason: '', label: 'Copy' }), uri: f.uri, where: 'outside' }))
    .filter((f) => f.at).sort((a, b) => (a.at < b.at ? 1 : -1));
}

// Makes a copy now. The database is copied straight away (before this returns its promise's first step finishes the
// folder); callers `await` it before a risky step. Returns { ok, name, uri, size } or { skipped } / { ok:false, error }.
export async function snapshotNow(reason = 'manual', { outside = 'daily' } = {}) {
  if (isTraining()) return { skipped: 'training', message: 'Practice data (training mode) is not copied.' };
  const dir = fsApi.dir();
  await fsApi.ensureDir(dir);
  let name = snapshotName(reason);
  for (let k = 2; (await fsApi.exists(`${dir}${name}`)) && k < 50; k++) name = snapshotName(`${reason}-${k}`); // two in the same second
  const uri = `${dir}${name}`;
  try {
    try { db().exec('PRAGMA wal_checkpoint(TRUNCATE);'); } catch (e) { /* not in WAL mode */ }
    try {
      db().exec(`VACUUM INTO '${plainPath(uri).replace(/'/g, "''")}'`);
    } catch (e) {
      // Older SQLite: copy the file itself (after the checkpoint everything is in the main file).
      await fsApi.copy(fsApi.dbFile(), uri);
    }
  } catch (e) {
    setSetting('last_snapshot_error', String(e.message || e).slice(0, 300));
    return { ok: false, error: e.message || String(e) };
  }
  const at = stamp();
  setSetting('last_snapshot_at', at);
  setSetting('last_snapshot_error', '');
  const size = await fsApi.size(uri);
  // Tidy up old copies.
  try {
    const { drop } = retention(await fsApi.list(dir));
    for (const n of drop) await fsApi.remove(`${dir}${n}`);
  } catch (e) { /* tidy next time */ }
  // The daily copy outside the app.
  let outsideCopy = null;
  if (outside && outsideApi.folder() && (outside === 'always' || getSetting('outside_copy_date', '') !== dateStr())) {
    try {
      outsideCopy = await outsideApi.copyTo(uri, name);
      setSetting('outside_copy_date', dateStr());
      setSetting('last_outside_copy_at', at);
      const list = (await outsideApi.list()).filter((f) => parseSnapshotName(f.name)).sort((a, b) => (a.name < b.name ? 1 : -1));
      for (const f of list.slice(OUTSIDE_KEEP)) await outsideApi.remove(f.uri);
    } catch (e) { setSetting('last_outside_error', String(e.message || e).slice(0, 300)); }
  }
  return { ok: true, name, uri, size, at, outside: outsideCopy };
}

// Called every few minutes while the app is open: a copy when the last one is older than EVERY_HOURS.
export function snapshotDue(lastAt = getSetting('last_snapshot_at', ''), now = clock.now(), hours = EVERY_HOURS) {
  if (!lastAt) return true;
  return now.getTime() - parseStamp(lastAt).getTime() >= hours * 3600000;
}
let busy = false;
export async function maybeSnapshot() {
  if (busy || isTraining() || !snapshotDue()) return null;
  busy = true;
  try { return await snapshotNow('auto'); } finally { busy = false; }
}

// ---------------------------------------------------------------- restoring
// Puts a copy back: makes a safety copy of the data as it is now first, then replaces the database file and opens it
// again. Owner or admin only. `replace(fromUri)` is the step that swaps the file (src/platform/training.js).
export async function restoreSnapshot(user, snap, { replace } = {}) {
  requireTop(user, 'restore a backup'); // 1.0.0 hardening (H1): checked inside the service
  return asService(async () => {
  if (!user || !actsAsOwner(user)) throw new AppError('Only the owner or an admin can restore a copy.');
  if (isTraining()) throw new AppError('Leave training mode first – the practice data cannot be restored over the real data.');
  if (!snap || !snap.uri) throw new AppError('Choose the copy to restore.');
  let from = snap.uri;
  if (snap.where === 'outside') {
    const dir = fsApi.dir();
    await fsApi.ensureDir(dir);
    from = `${dir}${snapshotName('from-outside')}`;
    await outsideApi.copyFrom(snap.uri, from);
  }
  const safety = await snapshotNow('before-restore', { outside: false });
  if (!safety.ok) throw new AppError(`The safety copy could not be made (${safety.error || 'unknown'}). Nothing was changed.`);
  const doReplace = replace || require('../platform/training.js').replaceRealDatabase;
  await doReplace(from, fsApi);
  setSetting('last_restore_at', stamp());
  audit({ user, action: 'Restored a safety copy of the data', table: 'database', recordUid: snap.name, after: { copy: snap.name, made: snap.at, where: snap.where || 'tablet', safetyCopy: safety.name } });
  return { ok: true, safety };
  });
}

// Restore from the red "damaged" screen (nobody logged in). The owner / admin PIN is checked on the current data when it
// can still be read, otherwise on the restored copy – and if it is not an owner / admin PIN there, the damaged file is
// put back. A file copy of the damaged database is always kept first.
export async function restoreDamaged(snap, pin, { replace, pinOk } = {}) {
  const check = pinOk || ((p) => require('./health.js').adminPinOk(p));
  const before = check(pin);
  if (before === false) throw new AppError('That is not an owner or admin PIN.');
  const dir = fsApi.dir();
  await fsApi.ensureDir(dir);
  const keep = `${dir}${snapshotName('damaged')}`;
  try { await fsApi.copy(fsApi.dbFile(), keep); } catch (e) { /* the file may be missing altogether */ }
  let from = snap.uri;
  if (snap.where === 'outside') { from = `${dir}${snapshotName('from-outside')}`; await outsideApi.copyFrom(snap.uri, from); }
  const doReplace = replace || require('../platform/training.js').replaceRealDatabase;
  await doReplace(from, fsApi);
  if (before === null && check(pin) !== true) {
    await doReplace(keep, fsApi); // put the damaged data back: the PIN was not accepted
    throw new AppError('That is not an owner or admin PIN for this copy. Nothing was changed.');
  }
  try { setSetting('last_restore_at', stamp()); audit({ user: null, action: 'Restored a safety copy after a damaged database', table: 'database', recordUid: snap.name, after: { copy: snap.name, made: snap.at, damagedKept: keep } }); } catch (e) { /* ignore */ }
  return { ok: true, damagedKept: keep };
}

// Age of the newest copy in hours (null when there is none).
export function snapshotAgeHours(now = clock.now()) {
  const at = getSetting('last_snapshot_at', '');
  return at ? (now.getTime() - parseStamp(at).getTime()) / 3600000 : null;
}
