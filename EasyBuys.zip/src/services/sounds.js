// Alert sounds and phone notifications for the warnings (src/services/alerts.js).
// - urgent: alarm that repeats until someone taps OK, plus an Android alarm-style notification;
// - warning: one chime; information: a soft tone.
// A sound plays only when a warning is new (not again and again for the same one).
// Admin settings (shared): sound on/off per type, quiet hours (bakery alerts still sound), urgent in quiet hours.
// Device settings: sounds on/off on this device and per type.
import { getShared, setShared, getSetting, setSetting, audit, clock, dateStr } from './core.js';
import { requireLogin, asService } from './guard.js';

// v3.6: softer chimes. Each level has a choice of tones (or the phone's own notification sound) and a volume.
export const TONES = { marimba: 'Marimba', bell: 'Bell', glass: 'Glass', harp: 'Harp', phone: "The phone's own sound" };
export const VOLUMES = { low: 0.4, medium: 0.7, high: 1 };
export const SOUND_DEFAULTS = { urgent: true, warning: true, info: true, quietOn: false, quietFrom: '21:00', quietTo: '06:00', urgentInQuiet: true, notify: true,
  toneUrgent: 'bell', toneWarning: 'bell', toneInfo: 'marimba', volUrgent: 'high', volWarning: 'medium', volInfo: 'low' };
export const DEVICE_DEFAULTS = { on: true, notify: true, urgent: true, warning: true, info: true, toneUrgent: '', toneWarning: '', toneInfo: '', volUrgent: '', volWarning: '', volInfo: '' };
const LVL = { urgent: 'Urgent', warning: 'Warning', info: 'Info' };
// The tone and volume this device uses for a level: its own choice, else the business default.
export function toneFor(level, { shared = soundSettings(), device = deviceSoundSettings() } = {}) {
  const k = LVL[level] || 'Info';
  const tone = TONES[device[`tone${k}`]] ? device[`tone${k}`] : TONES[shared[`tone${k}`]] ? shared[`tone${k}`] : SOUND_DEFAULTS[`tone${k}`];
  const vol = VOLUMES[device[`vol${k}`]] ? device[`vol${k}`] : VOLUMES[shared[`vol${k}`]] ? shared[`vol${k}`] : SOUND_DEFAULTS[`vol${k}`];
  return { tone, volume: VOLUMES[vol], vol };
}
const pick = (v, list, f) => (Object.prototype.hasOwnProperty.call(list, v) ? v : f);

export function soundSettings() { return { ...SOUND_DEFAULTS, ...(getShared('alert_sounds', {}) || {}) }; }
const hhmm = (v, f) => (/^\d{1,2}:\d{2}$/.test(String(v || '').trim()) ? String(v).trim().padStart(5, '0') : f);
export function saveSoundSettings(user, s) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const clean = {
    urgent: s.urgent !== false, warning: s.warning !== false, info: s.info !== false, notify: s.notify !== false,
    quietOn: !!s.quietOn, quietFrom: hhmm(s.quietFrom, SOUND_DEFAULTS.quietFrom), quietTo: hhmm(s.quietTo, SOUND_DEFAULTS.quietTo), urgentInQuiet: s.urgentInQuiet !== false,
  };
  for (const k of Object.values(LVL)) { clean[`tone${k}`] = pick(s[`tone${k}`], TONES, SOUND_DEFAULTS[`tone${k}`]); clean[`vol${k}`] = pick(s[`vol${k}`], VOLUMES, SOUND_DEFAULTS[`vol${k}`]); }
  setShared('alert_sounds', clean);
  audit({ user, action: 'Changed alert sounds', table: 'shared_settings', recordUid: 'alert_sounds', after: clean });
  return clean;
  });
}
export function deviceSoundSettings() {
  try { return { ...DEVICE_DEFAULTS, ...(JSON.parse(getSetting('sounds_device', '{}')) || {}) }; } catch (e) { return { ...DEVICE_DEFAULTS }; }
}
export function saveDeviceSoundSettings(s) {
  const clean = { on: s.on !== false, notify: s.notify !== false, urgent: s.urgent !== false, warning: s.warning !== false, info: s.info !== false };
  for (const k of Object.values(LVL)) { clean[`tone${k}`] = s[`tone${k}`] && TONES[s[`tone${k}`]] ? s[`tone${k}`] : ''; clean[`vol${k}`] = s[`vol${k}`] && VOLUMES[s[`vol${k}`]] ? s[`vol${k}`] : ''; }
  setSetting('sounds_device', JSON.stringify(clean));
  return clean;
}

// "21:00"–"06:00" wraps past midnight.
export function inQuietHours(now, from, to) {
  const m = now.getHours() * 60 + now.getMinutes();
  const t = (v) => { const [h, mm] = String(v).split(':').map(Number); return h * 60 + mm; };
  const a = t(from); const b = t(to);
  if (a === b) return false;
  return a < b ? m >= a && m < b : m >= a || m < b;
}
// Should this warning make a sound on this device now?
export function shouldSound(alert, { now = clock.now(), shared = soundSettings(), device = deviceSoundSettings() } = {}) {
  if (!alert || !device.on) return false;
  if (!shared[alert.level] || device[alert.level] === false) return false;
  if (shared.quietOn && inQuietHours(now, shared.quietFrom, shared.quietTo) && alert.area !== 'bakery') {
    return alert.level === 'urgent' && shared.urgentInQuiet;
  }
  return true;
}

// Release 02: the same KIND of warning (its id with the changing numbers taken out: counts, dates, record ids) is one
// warning for sound and notifications. Before, "Watchdog: 3 things" then "Watchdog: 4 things" rang again each time.
export function kindOf(a) {
  if (!a) return '';
  if (a.kind) return String(a.kind);
  return String(a.id || '').toLowerCase().replace(/[0-9a-f]{8,}/g, '#').replace(/\d+/g, '#').replace(/(#[-_.:]?)+/g, '#');
}
// Which warnings are new for this person on this device (heard before = same kind and level). A warning that goes
// away is remembered for 6 hours, so one that flickers (gone for a minute, then back) does not ring again.
const heardKey = (user) => `alerts_heard_${(user && (user.uid || user.id)) || 'anyone'}`;
const sig = (a) => `${kindOf(a)}|${a.level}`;
const KEEP_GONE_MS = 6 * 3600000;
export function newAlerts(user, list, now = clock.now()) {
  requireLogin(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  let heard = {};
  try { heard = JSON.parse(getSetting(heardKey(user), '{}')) || {}; } catch (e) { heard = {}; }
  const t = now.getTime();
  const fresh = [];
  const seenNow = new Set();
  // heard = still remembered: seen within the last 6 hours (an old-style entry from before Release 02 counts as just seen)
  const known = (k) => { const v = heard[k]; if (!v) return false; if (typeof v !== 'object') return true; return t - (Number(v.last) || 0) < KEEP_GONE_MS; };
  for (const a of list) { const k = sig(a); if (!known(k) && !seenNow.has(k)) fresh.push(a); seenNow.add(k); }
  const next = {};
  for (const [k, v] of Object.entries(heard)) {
    const last = v && typeof v === 'object' ? Number(v.last) || 0 : t;
    if (!seenNow.has(k) && t - last < KEEP_GONE_MS) next[k] = { last }; // gone, but only just
  }
  for (const k of seenNow) next[k] = { last: t };
  setSetting(heardKey(user), JSON.stringify(next));
  return fresh;
  });
}

// Release 02: mute a kind of warning for yourself – no sound and no phone notification; it still shows on Home.
// Urgent warnings: only the owner (or someone acting as the owner) may mute them.
export const MUTE_SPANS = { hour: 'For 1 hour', today: 'For today', week: 'For a week', always: 'Until I unmute' };
const muteKey = (user) => `alerts_muted_${(user && (user.uid || user.id)) || 'anyone'}`;
function muteMap(user) { try { return JSON.parse(getSetting(muteKey(user), '{}')) || {}; } catch (e) { return {}; } }
const ownerish = (user) => { try { return require('./access.js').actsAsOwner(user); } catch (e) { return !!user && user.role === 'owner'; } };
export function canMute(user, alert) { return !!user && !!alert && (alert.level !== 'urgent' || ownerish(user)); }
export function muteAlert(user, alert, span = 'today', now = clock.now()) {
  requireLogin(user);
  if (!MUTE_SPANS[span]) throw new Error('Choose how long to mute it.');
  if (!canMute(user, alert)) throw new Error('Only the owner can mute urgent warnings.');
  const until = span === 'always' ? 'always' : span === 'hour' ? new Date(now.getTime() + 3600000).toISOString()
    : span === 'week' ? new Date(now.getTime() + 7 * 86400000).toISOString()
    : (() => { const d = new Date(now); d.setHours(23, 59, 59, 999); return d.toISOString(); })();
  const m = muteMap(user);
  m[kindOf(alert)] = { until, text: String(alert.text || '').slice(0, 120), level: alert.level, at: now.toISOString() };
  setSetting(muteKey(user), JSON.stringify(m));
  return m[kindOf(alert)];
}
export function unmuteAlert(user, kind) { requireLogin(user); const m = muteMap(user); delete m[kind]; setSetting(muteKey(user), JSON.stringify(m)); }
export function isMuted(user, alert, now = clock.now()) {
  const v = muteMap(user)[kindOf(alert)];
  if (!v) return false;
  if (v.level === 'urgent' && alert.level === 'urgent' && !ownerish(user)) return false;
  return v.until === 'always' || Date.parse(v.until) > now.getTime();
}
export function mutedList(user, now = clock.now()) {
  return Object.entries(muteMap(user)).map(([kind, v]) => ({ kind, ...v }))
    .filter((v) => v.until === 'always' || Date.parse(v.until) > now.getTime());
}

// Looks at the current warnings: plays the loudest new one, sends phone notifications for new urgent ones, and returns
// the new urgent warnings (the app shows them with an OK button; the alarm repeats until OK).
// `play(level, { loop })` and `notify(alert)` come from src/platform (tests pass their own).
export function processAlerts(user, list, { play, notify, now = clock.now() } = {}) {
  const fresh = newAlerts(user, list, now).filter((a) => !isMuted(user, a, now));
  const audible = fresh.filter((a) => shouldSound(a, { now }));
  const level = ['urgent', 'warning', 'info'].find((l) => audible.some((a) => a.level === l));
  if (level && play) { try { play(level, { loop: level === 'urgent' }); } catch (e) { /* sound is a convenience */ } }
  const urgent = fresh.filter((a) => a.level === 'urgent');
  // Urgent ones always notify; a warning can ask for a phone notification too (e.g. "order from X before 10:00").
  const ping = urgent.concat(fresh.filter((a) => a.level !== 'urgent' && a.notify));
  if (notify && soundSettings().notify && deviceSoundSettings().notify !== false) for (const a of ping) { try { notify(a); } catch (e) { /* ignore */ } }
  return { fresh, played: level || null, urgent, audible };
}
