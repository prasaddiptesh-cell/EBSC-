// Alert sounds and phone notifications for the warnings (src/services/alerts.js).
// - urgent: alarm that repeats until someone taps OK, plus an Android alarm-style notification;
// - warning: one chime; information: a soft tone.
// A sound plays only when a warning is new (not again and again for the same one).
// Admin settings (shared): sound on/off per type, quiet hours (bakery alerts still sound), urgent in quiet hours.
// Device settings: sounds on/off on this device and per type.
import { getShared, setShared, getSetting, setSetting, audit, clock, dateStr } from './core.js';

export const SOUND_DEFAULTS = { urgent: true, warning: true, info: true, quietOn: false, quietFrom: '21:00', quietTo: '06:00', urgentInQuiet: true, notify: true };
export const DEVICE_DEFAULTS = { on: true, urgent: true, warning: true, info: true };

export function soundSettings() { return { ...SOUND_DEFAULTS, ...(getShared('alert_sounds', {}) || {}) }; }
const hhmm = (v, f) => (/^\d{1,2}:\d{2}$/.test(String(v || '').trim()) ? String(v).trim().padStart(5, '0') : f);
export function saveSoundSettings(user, s) {
  const clean = {
    urgent: s.urgent !== false, warning: s.warning !== false, info: s.info !== false, notify: s.notify !== false,
    quietOn: !!s.quietOn, quietFrom: hhmm(s.quietFrom, SOUND_DEFAULTS.quietFrom), quietTo: hhmm(s.quietTo, SOUND_DEFAULTS.quietTo), urgentInQuiet: s.urgentInQuiet !== false,
  };
  setShared('alert_sounds', clean);
  audit({ user, action: 'Changed alert sounds', table: 'shared_settings', recordUid: 'alert_sounds', after: clean });
  return clean;
}
export function deviceSoundSettings() {
  try { return { ...DEVICE_DEFAULTS, ...(JSON.parse(getSetting('sounds_device', '{}')) || {}) }; } catch (e) { return { ...DEVICE_DEFAULTS }; }
}
export function saveDeviceSoundSettings(s) {
  const clean = { on: s.on !== false, urgent: s.urgent !== false, warning: s.warning !== false, info: s.info !== false };
  setSetting('sounds_device', JSON.stringify(clean));
  return clean;
}

// "21:00"–"06:00" wraps past midnight.
export function inQuietHours(now, from, to) {
  const m = now.getHours() * 60 + now.getMinutes();
  const t = (v) => { const [h, mm] = String(v).split(':').map(Number); return h * 60 + mm; };
  const a = t(from); const b = t(to);
  if (a === b) return false;
  return a < b ? m >= a && m < b : m >= a || m < b;
}
// Should this warning make a sound on this device now?
export function shouldSound(alert, { now = clock.now(), shared = soundSettings(), device = deviceSoundSettings() } = {}) {
  if (!alert || !device.on) return false;
  if (!shared[alert.level] || device[alert.level] === false) return false;
  if (shared.quietOn && inQuietHours(now, shared.quietFrom, shared.quietTo) && alert.area !== 'bakery') {
    return alert.level === 'urgent' && shared.urgentInQuiet;
  }
  return true;
}

// Which warnings are new for this person on this device (heard before = same id and level, still showing).
const heardKey = (user) => `alerts_heard_${(user && (user.uid || user.id)) || 'anyone'}`;
const sig = (a) => `${a.id}|${a.level}`;
export function newAlerts(user, list) {
  let heard = {};
  try { heard = JSON.parse(getSetting(heardKey(user), '{}')) || {}; } catch (e) { heard = {}; }
  const fresh = list.filter((a) => !heard[sig(a)]);
  // Remember what is showing now; forget what has gone (so it sounds again if it comes back later).
  const next = {};
  list.forEach((a) => { next[sig(a)] = heard[sig(a)] || dateStr(); });
  setSetting(heardKey(user), JSON.stringify(next));
  return fresh;
}

// Looks at the current warnings: plays the loudest new one, sends phone notifications for new urgent ones, and returns
// the new urgent warnings (the app shows them with an OK button; the alarm repeats until OK).
// `play(level, { loop })` and `notify(alert)` come from src/platform (tests pass their own).
export function processAlerts(user, list, { play, notify, now = clock.now() } = {}) {
  const fresh = newAlerts(user, list);
  const audible = fresh.filter((a) => shouldSound(a, { now }));
  const level = ['urgent', 'warning', 'info'].find((l) => audible.some((a) => a.level === l));
  if (level && play) { try { play(level, { loop: level === 'urgent' }); } catch (e) { /* sound is a convenience */ } }
  const urgent = fresh.filter((a) => a.level === 'urgent');
  // Urgent ones always notify; a warning can ask for a phone notification too (e.g. "order from X before 10:00").
  const ping = urgent.concat(fresh.filter((a) => a.level !== 'urgent' && a.notify));
  if (notify && soundSettings().notify) for (const a of ping) { try { notify(a); } catch (e) { /* ignore */ } }
  return { fresh, played: level || null, urgent };
}
