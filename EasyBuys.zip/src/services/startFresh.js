// "Start fresh" (go-live): the owner clears the test data – on this device, in the cloud and, on their next sync, on
// every linked device. A safety copy is made first. Only records older than the moment of the fresh start are removed,
// so anything entered afterwards (on any device) is never touched. The change history (audit log) is always kept.
import { db, withSystem } from '../db/connection.js';
import { AppError, stamp, setSetting, getSetting, getShared, setShared, audit, uuid } from './core.js';
import { actsAsOwner } from './access.js';
import { requireOwner, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };

// What each tick-box clears. Everything not listed in a group and not in NEVER is "activity".
export const FRESH_GROUPS = {
  staff: { label: 'Staff (the owner login always stays)', tables: ['users', 'pay_profiles', 'leave_entitlements', 'job_openings', 'applicants', 'onboarding', 'contracts', 'signatures', 'staff_details'] },
  suppliers: { label: 'Suppliers', tables: ['ap_suppliers', 'aronium_suppliers', 'supplier_schedules', 'supplier_layouts', 'suppliers'] },
  products: { label: 'Products', tables: ['inv_items', 'inv_item_shops', 'products', 'recipes', 'product_steps', 'product_decks', 'materials'] },
  setup: { label: 'Opening balances & accounts setup', tables: ['gl_accounts', 'gl_budgets', 'gl_recurring', 'bank_accounts', 'cheque_books', 'tills', 'wallets', 'ap_recurring', 'regular_terms', 'personal_regulars', 'fixed_assets', 'licences', 'leave_types', 'rosters'] },
  settings: { label: 'Settings and rules', tables: ['shared_settings'] },
};
// Never cleared: the device itself, shops, the change history, safety and link information.
const NEVER = ['settings', 'shops', 'audit_log', 'outbox', 'doc_local', 'health_checks', 'steps', 'checklists', 'checklist_items', 'equipment', 'shift_names'];
export const FRESH_ORDER = ['activity', 'staff', 'suppliers', 'products', 'setup', 'settings'];
export const ACTIVITY_LABEL = 'Activity: sales, till balances, deposits, bank & M-PAiSA, invoices, cheques, orders and deliveries, stock movements, timesheets, leave, pay runs, accounts entries, loan payments, who owes us, warnings';

function allTables() {
  return db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").map((r) => r.name);
}
export function activityTables() {
  const grouped = new Set(Object.values(FRESH_GROUPS).flatMap((g) => g.tables).concat(NEVER));
  return allTables().filter((t) => !grouped.has(t));
}
export function tablesFor(groups) {
  const have = new Set(allTables());
  const out = [];
  (groups || []).forEach((g) => {
    if (g === 'activity') out.push(...activityTables());
    else if (FRESH_GROUPS[g]) out.push(...FRESH_GROUPS[g].tables.filter((t) => have.has(t)));
  });
  return Array.from(new Set(out));
}
const hasCol = (t, c) => { try { return db().all(`PRAGMA table_info("${t}")`).some((x) => x.name === c); } catch (e) { return false; } };
// Rows that would go (older than `before`), per table – shown before the owner confirms.
function whereFor(t, before) {
  const w = [];
  const a = [];
  if (hasCol(t, 'updated_at')) { w.push('(updated_at IS NULL OR updated_at <= ?)'); a.push(before); }
  if (t === 'users') w.push("role <> 'owner'");
  if (t === 'shared_settings') w.push("key NOT IN ('fresh_start')");
  return { sql: w.length ? `WHERE ${w.join(' AND ')}` : '', args: a };
}
export function freshSummary(groups, before = stamp()) {
  return tablesFor(groups).map((t) => {
    const { sql, args } = whereFor(t, before);
    let n = 0;
    try { n = db().get(`SELECT COUNT(*) AS n FROM "${t}" ${sql}`, args).n; } catch (e) { n = 0; }
    return { table: t, rows: n };
  }).filter((x) => x.rows > 0);
}
// Clears the rows older than `before` in these tables (no sync of the deletion: every device does the same itself).
export function clearTables(tables, before) {
  let n = 0;
  db().exec('PRAGMA foreign_keys = OFF;');
  try {
    db().transaction(() => {
      for (const t of tables) {
        const { sql, args } = whereFor(t, before);
        try { n += db().get(`SELECT COUNT(*) AS n FROM "${t}" ${sql}`, args).n; db().run(`DELETE FROM "${t}" ${sql}`, args); } catch (e) { /* table not on this device */ }
      }
    });
  } finally { db().exec('PRAGMA foreign_keys = ON;'); }
  return n;
}

// The owner starts fresh on the main tablet. deps (for tests): { snapshot, cloud, linked }.
export async function startFresh(user, { groups, typed }, deps = {}) {
  requireOwner(user); // 1.0.0 hardening (H1): checked inside the service
  return asService(async () => {
  need(user && (user.role === 'owner' || actsAsOwner(user)), 'Only the owner can start fresh.');
  need(String(typed || '').trim().toUpperCase() === 'START FRESH', 'Type START FRESH to confirm.');
  const gs = (groups || []).filter((g) => FRESH_ORDER.includes(g));
  need(gs.length, 'Tick what to clear.');
  const linked = deps.linked !== undefined ? deps.linked : !!getSetting('cloud_url', '');
  if (linked) need(deps.cloud || getSetting('cloud_key', ''), 'Start fresh on the main tablet (the one holding the cloud key), so the cloud copy is cleared too.');
  const at = stamp();
  const id = uuid('FRESH-');
  const tables = tablesFor(gs);
  const summary = freshSummary(gs, at);
  // 1. Safety copy (tablet + Drive when online).
  if (deps.snapshot) await deps.snapshot();
  // 2. The cloud copy (and Drive photos/documents moved to "Test data (before go-live)").
  if (linked && deps.cloud) {
    const r = await deps.cloud({ kind: 'fresh_start', id, at, tables, moveFiles: gs.includes('activity') });
    need(r && r.ok, (r && r.error) || 'The cloud could not be cleared (paste the new cloud script first – see CLOUD-SETUP.md). Nothing was changed.');
  }
  // 3. This device.
  // 1.0.0 build 1: the owner was checked above (and typed START FRESH); the clearing itself is the app's own work, so the
  // locked-settings guard does not stop it half way.
  const removed = withSystem(() => clearTables(tables, at));
  const marker = { id, at, tables, groups: gs, by: user.name };
  withSystem(() => {
    setShared('fresh_start', marker);
    setSetting('fresh_applied', id);
    audit({ user, action: `Started fresh: cleared ${gs.join(', ')} (${removed} records, safety copy made first)`, table: 'settings', after: { groups: gs, tables: tables.length } });
  });
  return { ...marker, removed, summary };
  });
}

// Every other device: when the cloud says a fresh start happened that this device has not done yet, it clears the same
// records (older than the fresh start) after a safety copy.
export async function applyFresh(fresh, { snapshot } = {}) {
  if (!fresh || !fresh.id || getSetting('fresh_applied', '') === fresh.id) return 0;
  // Only records older than the fresh start go, so a device linked later (holding only new records) loses nothing.
  // 1.0.0 build 1 (audit): only tables a fresh start may clear – never the change history, this device's settings or the
  // link; and never records made after "now" (a marker dated in the future clears nothing more than today's).
  const allowed = new Set(tablesFor(FRESH_ORDER));
  const tables = (fresh.tables || []).filter((t) => allowed.has(t) && !NEVER.includes(t) && t !== 'audit_log');
  const at = String(fresh.at || '') > stamp() ? stamp() : String(fresh.at || '');
  if (!tables.length || !at) { setSetting('fresh_applied', fresh.id); return 0; }
  if (snapshot) { try { await snapshot(); } catch (e) { /* carry on */ } }
  const removed = withSystem(() => clearTables(tables, at));
  setSetting('fresh_applied', fresh.id);
  audit({ user: null, action: `Started fresh with the other devices (${removed} old records cleared)`, table: 'settings' });
  return removed;
}
export function freshMarker() { return getShared('fresh_start', null); }
