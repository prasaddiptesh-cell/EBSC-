// Stock movements, alerts, the cloud outbox and automatic purchase orders.
import { db } from '../db/connection.js';
import { dateStr, timeStr, stamp, r3, nextTxnId, nextPoNo, getSettings } from './core.js';

// ---------------- transactions ----------------
export function writeTxn({ type, shiftId, userId, materialId, productId, batchId, qty, expectedQty, variance, supplier, supplierId, invoiceNo, ref, note }) {
  const txnId = nextTxnId();
  db().run(
    `INSERT INTO transactions
      (txn_id, type, location, shift_id, user_id, material_id, product_id, batch_id, qty, expected_qty, variance, supplier, supplier_id, invoice_no, ref, note,
       txn_date, txn_time, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [txnId, type, getSettings().locationName, shiftId || null, userId, materialId || null, productId || null, batchId || null, r3(qty),
      expectedQty === undefined || expectedQty === null ? null : r3(expectedQty),
      variance === undefined || variance === null ? null : r3(variance),
      supplier || null, supplierId || null, invoiceNo || null, ref || null, note || null, dateStr(), timeStr(), stamp()]
  );
  return txnId;
}

// Changes stock. When stock goes down, the oldest-expiring delivery lots are used first
// and recorded (for traceability). Returns the lots used.
export function changeStock(materialId, delta, { batchId = null, txnId = null } = {}) {
  db().run(
    "UPDATE materials SET stock = ROUND(stock + ?, 3), updated_at = ?, sync_status = 'pending' WHERE id = ? AND track_stock = 1",
    [r3(delta), stamp(), materialId]
  );
  const used = [];
  if (delta < 0) {
    let need = r3(-delta);
    const lots = db().all(
      `SELECT * FROM lots WHERE material_id = ? AND qty_left > 0 ORDER BY CASE WHEN expiry IS NULL THEN 1 ELSE 0 END, expiry, id`, [materialId]
    );
    for (const l of lots) {
      if (need <= 0) break;
      const take = r3(Math.min(need, l.qty_left));
      db().run('UPDATE lots SET qty_left = ROUND(qty_left - ?, 3) WHERE id = ?', [take, l.id]);
      db().run('INSERT INTO lot_usage (lot_id, material_id, batch_id, txn_id, qty, created_at) VALUES (?, ?, ?, ?, ?, ?)', [l.id, materialId, batchId, txnId, take, stamp()]);
      used.push({ lot_id: l.id, lot_no: l.lot_no, expiry: l.expiry, qty: take });
      need = r3(need - take);
    }
  }
  return used;
}

export function addLot({ materialId, lotNo, expiry, supplierId, invoiceNo, txnId, qty, unitCost }) {
  return db().run(
    `INSERT INTO lots (material_id, lot_no, expiry, supplier_id, invoice_no, txn_id, qty_received, qty_left, unit_cost, received_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [materialId, lotNo || null, expiry || null, supplierId || null, invoiceNo || null, txnId || null, r3(qty), r3(qty), unitCost === undefined ? null : unitCost, stamp()]
  ).lastInsertRowId;
}

export function listLots({ materialId, openOnly = true, search } = {}) {
  const where = [];
  const params = [];
  if (materialId) { where.push('l.material_id = ?'); params.push(materialId); }
  if (openOnly) where.push('l.qty_left > 0');
  if (search) { where.push('(lower(l.lot_no) LIKE ? OR lower(l.invoice_no) LIKE ? OR lower(m.name) LIKE ?)'); const q = `%${String(search).toLowerCase()}%`; params.push(q, q, q); }
  return db().all(
    `SELECT l.*, m.name, m.unit, s.name AS supplier_name FROM lots l JOIN materials m ON m.id = l.material_id LEFT JOIN suppliers s ON s.id = l.supplier_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY CASE WHEN l.expiry IS NULL THEN 1 ELSE 0 END, l.expiry, l.id LIMIT 300`, params
  );
}

// Traceability: where did a lot go?
export function lotTrace(lotId) {
  const lot = db().get('SELECT l.*, m.name, m.unit, s.name AS supplier_name FROM lots l JOIN materials m ON m.id = l.material_id LEFT JOIN suppliers s ON s.id = l.supplier_id WHERE l.id = ?', [lotId]);
  if (!lot) return null;
  const uses = db().all(
    `SELECT lu.*, b.code AS batch_code, b.started_at, p.name AS product_name, t.type AS txn_type, t.note AS txn_note
     FROM lot_usage lu LEFT JOIN batches b ON b.id = lu.batch_id LEFT JOIN products p ON p.id = b.product_id LEFT JOIN transactions t ON t.txn_id = lu.txn_id
     WHERE lu.lot_id = ? ORDER BY lu.id`, [lotId]
  );
  return { lot, uses };
}
export function batchLots(batchId) {
  return db().all(
    `SELECT lu.qty, l.lot_no, l.expiry, l.invoice_no, m.name, m.unit, s.name AS supplier_name FROM lot_usage lu JOIN lots l ON l.id = lu.lot_id
     JOIN materials m ON m.id = lu.material_id LEFT JOIN suppliers s ON s.id = l.supplier_id WHERE lu.batch_id = ? ORDER BY m.name`, [batchId]
  );
}

// Daily housekeeping: expiry warnings and equipment service reminders.
export function dailyChecks() {
  const days = Number(db().get("SELECT value FROM settings WHERE key = 'expiry_alert_days'")?.value || 7);
  const limit = new Date();
  limit.setDate(limit.getDate() + days);
  const lim = `${limit.getFullYear()}-${String(limit.getMonth() + 1).padStart(2, '0')}-${String(limit.getDate()).padStart(2, '0')}`;
  const today = stamp().slice(0, 10);
  const soon = db().all(
    `SELECT l.*, m.name, m.unit FROM lots l JOIN materials m ON m.id = l.material_id WHERE l.qty_left > 0 AND l.expiry IS NOT NULL AND l.expiry <= ? AND l.expiry_alerted_at IS NULL`, [lim]
  );
  for (const l of soon) {
    const expired = l.expiry < today;
    raiseAlert({ type: 'EXPIRY', severity: expired ? 'bad' : 'warn',
      message: `${l.name}${l.lot_no ? ` lot ${l.lot_no}` : ''}: ${r3(l.qty_left)} ${l.unit} ${expired ? 'EXPIRED on' : 'expires'} ${l.expiry}. Use it first${expired ? ' or remove it as wastage' : ''}.` });
    db().run('UPDATE lots SET expiry_alerted_at = ? WHERE id = ?', [stamp(), l.id]);
  }
  const eq = db().all('SELECT * FROM equipment WHERE active = 1 AND service_days > 0');
  for (const e of eq) {
    const last = e.last_service_at || e.created_at;
    const due = new Date(last.slice(0, 10));
    due.setDate(due.getDate() + e.service_days);
    const dueStr = due.toISOString().slice(0, 10);
    // One reminder per service period (re-armed when a service is recorded).
    if (dueStr <= today && (!e.service_alerted_at || e.service_alerted_at < last)) {
      raiseAlert({ type: 'SERVICE', message: `${e.name} is due for its service (every ${e.service_days} days, last ${last.slice(0, 10)}).` });
      db().run('UPDATE equipment SET service_alerted_at = ? WHERE id = ?', [stamp(), e.id]);
    }
  }
  return { expiry: soon.length };
}

// ---------------- alerts ----------------
export const ALERT_LABEL = {
  PLAN: 'Plan changed online',
  INGREDIENT: 'Ingredient changed',
  CUT_SHORT: 'Cut count short',
  YIELD_SHORT: 'Yield short',
  SNOOZE: 'Step snoozed',
  LATE: 'Step late',
  SIGNOFF: 'Sign-off missing',
  TIME_EDIT: 'Time entered manually',
  LOW_STOCK: 'Low stock',
  BALANCE: 'Stock variance',
  OPENING: 'Opening count differs',
  EXPIRY: 'Expiry',
  SERVICE: 'Service due',
  FAULT: 'Equipment fault',
  TEMP: 'Temperature out of range',
  CHECK_SKIP: 'Checklist item skipped',
  DELIVERY: 'Delivery problem',
};

export function raiseAlert({ type, severity = 'warn', shiftId, batchId, userId, message }) {
  const r = db().run(
    'INSERT INTO alerts (type, severity, shift_id, batch_id, user_id, message, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [type, severity, shiftId || null, batchId || null, userId || null, message, stamp()]
  );
  return r.lastInsertRowId;
}

export function listAlerts({ shiftId, openOnly = false, limit = 300 } = {}) {
  const where = [];
  const params = [];
  if (shiftId) { where.push('a.shift_id = ?'); params.push(shiftId); }
  if (openOnly) where.push('a.ack_at IS NULL');
  params.push(limit);
  return db().all(
    `SELECT a.*, u.name AS user_name, k.name AS ack_name, b.code AS batch_code, s.code AS shift_code
     FROM alerts a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN users k ON k.id = a.ack_by
     LEFT JOIN batches b ON b.id = a.batch_id LEFT JOIN shifts s ON s.id = a.shift_id
     ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY a.id DESC LIMIT ?`,
    params
  );
}
export function countOpenAlerts() {
  return db().get('SELECT COUNT(*) AS c FROM alerts WHERE ack_at IS NULL').c;
}
export function ackAlert(id, userId) {
  db().run("UPDATE alerts SET ack_by = ?, ack_at = ?, sync_status = 'pending' WHERE id = ? AND ack_at IS NULL", [userId, stamp(), id]);
}
export function ackAllAlerts(userId) {
  db().run("UPDATE alerts SET ack_by = ?, ack_at = ?, sync_status = 'pending' WHERE ack_at IS NULL", [userId, stamp()]);
}

// ---------------- outbox (things to send to the cloud) ----------------
export function enqueue(kind, payload) {
  db().run('INSERT INTO outbox (kind, payload, created_at) VALUES (?, ?, ?)', [kind, JSON.stringify(payload || {}), stamp()]);
}
export function pendingOutbox(limit = 20) {
  return db().all('SELECT * FROM outbox WHERE sent_at IS NULL ORDER BY id LIMIT ?', [limit]).map((r) => ({ ...r, payload: JSON.parse(r.payload) }));
}
export function countPendingOutbox() {
  return db().get('SELECT COUNT(*) AS c FROM outbox WHERE sent_at IS NULL').c;
}
export function markOutboxSent(id) {
  db().run('UPDATE outbox SET sent_at = ?, last_error = NULL WHERE id = ?', [stamp(), id]);
}
export function markOutboxFailed(id, err) {
  db().run('UPDATE outbox SET attempts = attempts + 1, last_error = ? WHERE id = ?', [String(err).slice(0, 300), id]);
}

// ---------------- photos ----------------
export function addPhotos(refType, refId, uris) {
  for (const uri of uris || []) {
    const id = db().run('INSERT INTO photos (ref_type, ref_id, uri, created_at) VALUES (?, ?, ?, ?)', [refType, String(refId), uri, stamp()]).lastInsertRowId;
    enqueue('photo', { photoId: id });
  }
}
export function listPhotos(refType, refId) {
  return db().all('SELECT * FROM photos WHERE ref_type = ? AND ref_id = ? ORDER BY id', [refType, String(refId)]);
}
export function getPhoto(id) {
  return db().get('SELECT * FROM photos WHERE id = ?', [id]);
}
export function setPhotoCloudUrl(id, url) {
  db().run("UPDATE photos SET cloud_url = ?, sync_status = 'synced' WHERE id = ?", [url, id]);
}

// ---------------- minimum stock & purchase orders ----------------
export function lowStockItems() {
  return db().all(
    `SELECT m.*, s.name AS supplier_name, s.email AS supplier_email FROM materials m LEFT JOIN suppliers s ON s.id = m.supplier_id
     WHERE m.active = 1 AND m.track_stock = 1 AND m.reorder_level > 0 AND m.stock <= m.reorder_level ORDER BY s.name, m.name`
  ).map((m) => ({ ...m, order_qty: m.reorder_qty > 0 ? m.reorder_qty : r3(Math.max(m.reorder_level * 2 - m.stock, m.reorder_level)) }));
}

// Creates one purchase order per supplier for the given material ids.
export function createPurchaseOrders(userId, materialIds, { auto = false } = {}) {
  const items = lowStockItems().filter((m) => !materialIds || materialIds.includes(m.id));
  const groups = {};
  for (const m of items) {
    const key = m.supplier_id || 0;
    (groups[key] = groups[key] || { supplierId: m.supplier_id || null, supplier: m.supplier_name || 'Supplier not set', email: m.supplier_email || null, items: [] }).items.push(m);
  }
  const created = [];
  for (const g of Object.values(groups)) {
    const poNo = nextPoNo();
    const lines = g.items.map((m) => ({
      material_id: m.id, name: m.name, code: m.code, unit: m.unit, stock: r3(m.stock), min: m.reorder_level, qty: m.order_qty,
    }));
    const id = db().run(
      'INSERT INTO purchase_orders (po_no, supplier_id, supplier, supplier_email, items, status, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [poNo, g.supplierId, g.supplier, g.email, JSON.stringify(lines), 'queued', stamp(), userId || null]
    ).lastInsertRowId;
    for (const m of g.items) db().run('UPDATE materials SET reorder_alerted_at = ? WHERE id = ?', [stamp(), m.id]);
    enqueue('po', { poId: id });
    raiseAlert({
      type: 'LOW_STOCK', severity: 'warn', userId,
      message: `${auto ? 'Automatic ' : ''}purchase order ${poNo} for ${g.supplier}: ${lines.map((l) => `${l.name} ${l.qty} ${l.unit}`).join(', ')}`,
    });
    created.push(poNo);
  }
  return created;
}

// Called after stock goes down. Raises a PO for items that just reached their minimum,
// and re-arms items whose stock has gone back above the minimum.
export function checkReorder(userId) {
  db().run('UPDATE materials SET reorder_alerted_at = NULL WHERE reorder_alerted_at IS NOT NULL AND stock > reorder_level');
  const fresh = lowStockItems().filter((m) => !m.reorder_alerted_at).map((m) => m.id);
  if (!fresh.length) return [];
  if (getSettings().poAuto) return createPurchaseOrders(userId, fresh, { auto: true });
  for (const id of fresh) {
    const m = db().get('SELECT name, stock, unit, reorder_level FROM materials WHERE id = ?', [id]);
    db().run('UPDATE materials SET reorder_alerted_at = ? WHERE id = ?', [stamp(), id]);
    raiseAlert({ type: 'LOW_STOCK', userId, message: `${m.name} is at ${r3(m.stock)} ${m.unit} (minimum ${m.reorder_level}). Create a purchase order.` });
  }
  return [];
}

export function listPurchaseOrders(limit = 100) {
  return db().all(
    'SELECT p.*, u.name AS created_by_name FROM purchase_orders p LEFT JOIN users u ON u.id = p.created_by ORDER BY p.id DESC LIMIT ?', [limit]
  ).map((p) => ({ ...p, items: JSON.parse(p.items) }));
}
export function getPurchaseOrder(id) {
  const p = db().get('SELECT p.*, u.name AS created_by_name FROM purchase_orders p LEFT JOIN users u ON u.id = p.created_by WHERE p.id = ?', [id]);
  return p ? { ...p, items: JSON.parse(p.items) } : null;
}
export function markPoSent(id) {
  db().run("UPDATE purchase_orders SET status = 'sent', sent_at = ? WHERE id = ?", [stamp(), id]);
}
