// The live sync status shown on every screen (no screen code here, so modules can use it too).
const listeners = new Set();
let state = { running: false, lastOk: '', lastTry: '', error: '', sent: 0, received: 0, progress: '' };

export function getSyncState() {
  return state;
}
export function setSyncState(patch) {
  state = { ...state, ...patch };
  listeners.forEach((fn) => { try { fn(state); } catch (e) { /* ignore */ } });
}
export function onSyncState(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
