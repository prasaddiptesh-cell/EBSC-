// What the sync button shows: colour (green / amber / red / grey), a short text and the "Sync now" action.
// No screen code here, so Home, Admin › Sync, the sync bar and the tests share the same rules.
import { getSetting, parseStamp, clock } from './core.js';
import { getSyncState, setSyncState, onSyncState } from './syncBus.js';
import { isTraining } from './trainingFlag.js';

// Items waiting to go to the cloud: changed records plus jobs in the outbox (photos, emails, backups…).
let cache = { at: 0, n: 0 };
onSyncState((st) => { if (!st.running) cache.at = 0; }); // count again once a sync has finished
// Counted at most once a second (the sync bar and icon ask often while a sync runs).
export function waitingCount({ fresh = false } = {}) {
  const now = Date.now();
  if (!fresh && now - cache.at < 1000) return cache.n;
  cache = { at: now, n: countWaiting() };
  return cache.n;
}
function countWaiting() {
  try {
    const { pendingBySection } = require('./records.js');
    const { countPendingOutbox } = require('./stock.js');
    const per = pendingBySection();
    return Object.values(per).reduce((a, b) => a + b, 0) + countPendingOutbox();
  } catch (e) {
    return 0;
  }
}
export function isLinked() {
  try { return !!getSetting('cloud_url', ''); } catch (e) { return false; }
}
// "3:45 pm"
export function timeLabel(s) {
  if (!s) return '';
  const hh = Number(String(s).slice(11, 13));
  const mm = String(s).slice(14, 16);
  if (!Number.isFinite(hh) || !mm) return '';
  return `${hh % 12 || 12}:${mm} ${hh < 12 ? 'am' : 'pm'}`;
}
export const isCloudBusy = (e) => /cloud is busy/i.test(String(e || ''));
// review (3 Nov): our own time limit ran out twice in a row – the connection, not the cloud (cloud.js SLOW_MESSAGE)
export const isSlowConnection = (e) => /slow or no connection/i.test(String(e || ''));
export const isNetworkError = (e) => /network|fetch|timed|abort|offline|internet|Failed to/i.test(String(e || ''));
const items = (n) => `${n} item${n === 1 ? '' : 's'}`;

// The light: green = all synced, amber = waiting or busy, red = failing or waiting too long, grey = off.
export function syncLight({ linked, training, running, error, waiting = 0, lastOk = '', progress = '', now = clock.now(), maxHours = 24 } = {}) {
  if (training) return { color: 'grey', text: 'Sync is off in training mode', canSync: false };
  if (!linked) return { color: 'grey', text: 'Not linked to the cloud yet (saved on this device)', canSync: false };
  if (running) return { color: 'amber', text: progress || (waiting ? `Sending ${items(waiting)}…` : 'Syncing…'), canSync: false, running: true };
  if (error) {
    // 1.0.0 build 10: the cloud was busy with other phones (not the internet) – it is tried again by itself
    if (isSlowConnection(error)) return { color: 'amber', text: `Slow or no connection – trying again in a minute${waiting ? ` (${items(waiting)} waiting)` : ''}`, canSync: true, retry: true, error };
    if (isCloudBusy(error)) return { color: 'amber', text: `The cloud is busy – trying again${waiting ? ` (${items(waiting)} waiting)` : ''}`, canSync: true, retry: true, error };
    return { color: 'red', text: isNetworkError(error) ? `✗ No internet – ${items(waiting)} waiting` : `✗ Sync problem – ${items(waiting)} waiting`, canSync: true, retry: true, error };
  }
  const ageH = lastOk ? (now.getTime() - parseStamp(lastOk).getTime()) / 3600000 : Infinity;
  if (waiting && ageH > maxHours) return { color: 'red', text: `✗ ${items(waiting)} waiting – last sync ${lastOk ? lastOk.slice(0, 16) : 'never'}`, canSync: true, retry: true };
  if (waiting) return { color: 'amber', text: `${items(waiting)} waiting to send`, canSync: true };
  return { color: 'green', text: `✓ All synced${lastOk ? ` ${timeLabel(lastOk)}` : ''}`, canSync: true };
}
// The light for this device right now.
export function currentSyncLight() {
  const st = getSyncState();
  let lastOk = st.lastOk;
  try { lastOk = lastOk || getSetting('last_sync_ok_at', ''); } catch (e) { /* ignore */ }
  let error = st.error;
  try { if (!st.lastTry && !error) error = getSetting('last_sync_error', ''); } catch (e) { /* ignore */ }
  return syncLight({ linked: isLinked(), training: isTraining(), running: st.running, error, waiting: st.running ? 0 : waitingCount(), lastOk, progress: st.progress });
}

// "Sync now": starts straight away. Anyone may press it; not in training mode.
export async function startSync() {
  if (isTraining()) return { blocked: true, message: 'Sync is off in training mode – practice figures are never sent.' };
  if (!isLinked()) return { blocked: true, message: 'This device is not linked to the Easy Buys cloud yet (Admin › Devices or Online & email).' };
  const { syncNow } = require('../platform/cloud.js');
  const n = waitingCount({ fresh: true });
  if (!getSyncState().running) setSyncState({ progress: n ? `Sending ${items(n)}…` : 'Syncing…' });
  try {
    return await syncNow({ force: true });
  } catch (e) {
    setSyncState({ running: false, error: e.message || String(e), progress: '' });
    return { error: e.message || String(e) };
  }
}
