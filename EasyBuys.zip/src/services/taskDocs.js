// One-page PDFs of a task just done (deposit, payment / cheque, invoice) to send to the Viber group as proof.
import { stamp } from './core.js';
import { listShops } from '../modules/admin/service.js';
import { listPhotos } from './stock.js';
import { db } from '../db/connection.js';
import { getDeposit } from '../modules/till/service.js';
import { getInvoice, getPayment } from '../modules/payables/service.js';

const $ = (n) => `$${(Math.round((Number(n) || 0) * 100) / 100).toFixed(2)}`;
const shopName = (code) => { const s = listShops().find((x) => x.code === code); return s ? s.name : (code || ''); };
const personName = (uid) => { try { const u = uid && db().get('SELECT name FROM users WHERE uid = ?', [uid]); return u ? u.name : ''; } catch (e) { return ''; } };
const col = (key, title, align = 'left') => ({ key, title, align });
const urls = (list) => (list || []).filter((u) => /^https?:/i.test(String(u)));
// Local photos first (full quality on this device), then cloud copies.
const photosOf = (refType, uid, cloud, caption) => {
  const local = listPhotos(refType, uid).map((p) => ({ uri: p.uri, caption }));
  return local.length ? local : urls(cloud).map((u) => ({ uri: u, caption }));
};

export function depositDoc(uid) {
  const d = getDeposit(uid);
  if (!d) return null;
  const notes = Object.entries(d.denominations || {}).filter(([, n]) => Number(n) > 0);
  return {
    rep: {
      kind: 'task', docType: 'deposit', refUid: uid, nav: { screen: 'Deposits', params: {} }, title: `Bank deposit ${d.slip_no || ''}`.trim(), fileName: `Deposit-${d.deposit_date}-${d.shop_code}-${d.slip_no || ''}`,
      subtitle: `Easy Buys Shopping Centre · ${shopName(d.shop_code)}`,
      info: [['Shop', shopName(d.shop_code)], ['Date', d.deposit_date], ['Bank account', d.account_name || ''], ['Slip no.', d.slip_no || ''], ['Banked by', personName(d.deposited_by_uid)], ['Made', stamp()]],
      summary: [{ label: 'Cash', value: $(d.cash_amount) }, { label: 'Cheques', value: $(d.cheque_amount) }, { label: 'Total', value: $(d.total) }],
      sections: [].concat(notes.length ? [{ title: 'Notes and coins', columns: [col('k', 'Note / coin'), col('n', 'Count', 'right')], rows: notes.map(([k, n]) => ({ k, n: String(n) })) }] : [])
        .concat((d.cheques || []).length ? [{ title: 'Cheques banked', columns: [col('from', 'From'), col('no', 'Cheque no.'), col('amount', 'Amount', 'right')], rows: d.cheques.map((c) => ({ from: c.drawer || c.from || '', no: c.number || c.no || '', amount: $(c.amount) })) }] : []),
    },
    photos: photosOf('deposit', uid, d.photos, 'Deposit slip'),
    text: `Easy Buys – bank deposit ${$(d.total)} from ${shopName(d.shop_code)} on ${d.deposit_date}${d.slip_no ? `, slip ${d.slip_no}` : ''}.`,
  };
}

export function paymentDoc(uid) {
  const p = getPayment(uid);
  if (!p) return null;
  const how = p.method === 'cheque' ? `Cheque ${p.cheque_no || ''}` : p.method;
  return {
    rep: {
      kind: 'task', docType: 'payment', refUid: uid, nav: { screen: 'ApPayment', params: { uid } }, title: p.method === 'cheque' ? `Cheque ${p.cheque_no || ''} to ${p.supplier_name}` : `Payment to ${p.supplier_name}`,
      fileName: `Payment-${p.pay_date}-${String(p.supplier_name || '').replace(/\s+/g, '-')}${p.cheque_no ? `-chq${p.cheque_no}` : ''}`,
      subtitle: 'Easy Buys Shopping Centre',
      info: [['Paid to', p.supplier_name], ['Date', p.pay_date], ['How', how], ['From account', p.account_name || ''], ['Collected by', p.received_by || ''], ['Recorded by', personName(p.paid_by_uid)], ['Made', stamp()]],
      summary: [{ label: 'Amount', value: $(p.amount) }],
      sections: [{ title: 'Invoices paid', columns: [col('no', 'Invoice'), col('date', 'Date'), col('total', 'Invoice total', 'right'), col('paid', 'Paid now', 'right')],
        rows: (p.allocations || []).map((a) => ({ no: a.invoice_no || '', date: a.invoice_date || '', total: $(a.total), paid: $(a.amount) })) }],
    },
    photos: photosOf('payment', uid, p.photos, p.method === 'cheque' ? 'Cheque / stub' : 'Receipt'),
    text: `Easy Buys – ${how} ${$(p.amount)} to ${p.supplier_name} on ${p.pay_date}.`,
  };
}

export function invoiceDoc(uid) {
  const i = getInvoice(uid);
  if (!i) return null;
  return {
    rep: {
      kind: 'task', docType: 'invoice', refUid: uid, nav: { screen: 'ApInvoice', params: { uid } }, title: `${i.kind === 'credit' ? 'Credit note' : 'Invoice'} received – ${i.supplier_name}`, fileName: `Invoice-${i.invoice_date || ''}-${String(i.supplier_name || '').replace(/\s+/g, '-')}-${i.invoice_no || ''}`,
      subtitle: `Easy Buys Shopping Centre · ${shopName(i.shop_code)}`,
      info: [['Supplier', i.supplier_name], ['Invoice no.', i.invoice_no || ''], ['Invoice date', i.invoice_date || ''], ['Due', i.due_date || ''], ['Shop', shopName(i.shop_code)], ['For', i.category || ''], ['Entered by', personName(i.entered_by_uid)], ['Made', stamp()]],
      summary: [{ label: 'Total', value: $(i.total) }, { label: 'VAT', value: $(i.vat) }],
      sections: [],
    },
    photos: photosOf('invoice', uid, i.photos, 'Invoice'),
    text: `Easy Buys – invoice received: ${i.supplier_name} ${i.invoice_no || ''} ${$(i.total)} (${shopName(i.shop_code)}).`,
  };
}
