// Turns the bytes of a text file into text, whatever program saved it:
// UTF-8 (with or without BOM), UTF-16 (Excel "Unicode text"), or Windows-1252 (Aronium / Excel CSV on Windows,
// where "Crème" would otherwise show as "Cr�me").
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
export function base64ToBytes(b64) {
  const s = String(b64 || '').replace(/[^A-Za-z0-9+/]/g, '');
  const out = new Uint8Array(Math.floor((s.length * 3) / 4));
  let o = 0;
  for (let i = 0; i < s.length; i += 4) {
    const a = B64.indexOf(s[i]), b = B64.indexOf(s[i + 1]), c = s[i + 2] ? B64.indexOf(s[i + 2]) : -1, d = s[i + 3] ? B64.indexOf(s[i + 3]) : -1;
    const n = (a << 18) | (b << 12) | ((c < 0 ? 0 : c) << 6) | (d < 0 ? 0 : d);
    if (o < out.length) out[o++] = (n >> 16) & 255;
    if (c >= 0 && o < out.length) out[o++] = (n >> 8) & 255;
    if (d >= 0 && o < out.length) out[o++] = n & 255;
  }
  return out.subarray(0, o);
}

// Windows-1252 characters 0x80–0x9F (the rest of 0x00–0xFF are the same as Unicode).
const CP1252 = { 0x80: 0x20ac, 0x82: 0x201a, 0x83: 0x0192, 0x84: 0x201e, 0x85: 0x2026, 0x86: 0x2020, 0x87: 0x2021, 0x88: 0x02c6, 0x89: 0x2030, 0x8a: 0x0160,
  0x8b: 0x2039, 0x8c: 0x0152, 0x8e: 0x017d, 0x91: 0x2018, 0x92: 0x2019, 0x93: 0x201c, 0x94: 0x201d, 0x95: 0x2022, 0x96: 0x2013, 0x97: 0x2014, 0x98: 0x02dc,
  0x99: 0x2122, 0x9a: 0x0161, 0x9b: 0x203a, 0x9c: 0x0153, 0x9e: 0x017e, 0x9f: 0x0178 };

function decodeUtf8(bytes, start) {
  let s = '';
  for (let i = start; i < bytes.length;) {
    const b = bytes[i];
    let cp, n;
    if (b < 0x80) { cp = b; n = 1; }
    else if (b >= 0xc2 && b < 0xe0) { cp = b & 0x1f; n = 2; }
    else if (b >= 0xe0 && b < 0xf0) { cp = b & 0x0f; n = 3; }
    else if (b >= 0xf0 && b < 0xf5) { cp = b & 0x07; n = 4; }
    else return null; // not UTF-8
    if (i + n > bytes.length) return null;
    for (let k = 1; k < n; k += 1) {
      const c = bytes[i + k];
      if ((c & 0xc0) !== 0x80) return null;
      cp = (cp << 6) | (c & 0x3f);
    }
    s += String.fromCodePoint(cp);
    i += n;
  }
  return s;
}
function decodeUtf16(bytes, start, le) {
  let s = '';
  for (let i = start; i + 1 < bytes.length; i += 2) s += String.fromCharCode(le ? bytes[i] | (bytes[i + 1] << 8) : (bytes[i] << 8) | bytes[i + 1]);
  return s;
}
function decodeCp1252(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 1) s += String.fromCharCode(CP1252[bytes[i]] || bytes[i]);
  return s;
}

export function decodeText(bytes) {
  if (!bytes || !bytes.length) return '';
  if (bytes[0] === 0xff && bytes[1] === 0xfe) return decodeUtf16(bytes, 2, true);
  if (bytes[0] === 0xfe && bytes[1] === 0xff) return decodeUtf16(bytes, 2, false);
  const start = bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf ? 3 : 0;
  // UTF-16 without a BOM: every other byte is 0 in ordinary text.
  if (bytes.length > 3 && bytes[1] === 0 && bytes[3] === 0 && bytes[0] !== 0) return decodeUtf16(bytes, 0, true);
  const u = decodeUtf8(bytes, start);
  return u !== null ? u : decodeCp1252(bytes);
}
export function decodeBase64Text(b64) { return decodeText(base64ToBytes(b64)); }
