// True while Training mode (the practice database) is in use. Nothing goes to the cloud then.
let on = false;
export function isTraining() { return on; }
export function setTrainingFlag(v) { on = !!v; }
