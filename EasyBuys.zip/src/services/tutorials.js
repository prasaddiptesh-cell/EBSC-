// App tour (once per person, can be replayed) and "Show me how" tutorials per job, with a short check at the end.
// Each step names the button to press (its testID – the button gets a bright outline) and says what to do.
// Progress is kept per person and synced, so the owner sees who has done which tutorial.
import { getShared, setShared, stamp, audit } from './core.js';
import { can, actsAsOwner } from './access.js';

export const TOUR = {
  id: 'tour', title: 'A quick look around',
  steps: [
    { text: 'Welcome to Easy Buys! This short tour shows where things are. Tap Next to go on, or Close any time.' },
    { testID: 'home-search', text: 'Search: type a screen, a person, a supplier, an invoice or a cheque number to jump straight to it.' },
    { testID: 'home-scan', text: 'Scan: point the camera at a barcode or QR code to find a product, an order or a document.' },
    { testID: 'ql-edit', text: 'Your quick links: add your favourite screens here (up to 8). They follow you on every device.' },
    { text: 'Warnings appear on Home in colour – red is urgent, orange needs attention, blue is for information. Tap one to fix it.' },
    { testID: 'force-sync', text: 'The sync light at the top: green means everything is sent. Tap it to sync now.' },
    { text: 'The big tiles open each part of the business. Inside, every menu has the same order: Daily tasks, Records, Checks, Reports, Settings.' },
    { text: 'That is it! Find "Tutorials" in Admin & settings (or your Help menu) to learn each job step by step – practise in Training mode first.' },
  ],
};

// roles: who the tutorial is for (owner/admin see all). quiz: [question, [choices], index of the right answer].
export const TUTORIALS = [
  { id: 'clock', module: 'timeclock', title: 'Clock in and out', roles: ['staff', 'worker', 'supervisor', 'manager', 'payroll'],
    steps: [
      { testID: 'home-clock', text: 'On the shop tablet, tap Time Clock (it is also on the login screen).' },
      { text: 'Tap your name, then type your PIN. Look at the camera for the face check.' },
      { text: 'Tap Clock IN when you start, Break start / Break end for breaks, and Clock OUT when you finish.' },
      { text: 'Forgot to clock? Tell your manager – they fix it with a reason, and it stays in the history.' },
    ],
    quiz: [['Where do you clock in?', ['On the Time Clock, with your PIN', 'By telling a friend', 'In the Payroll menu'], 0],
      ['You forgot to clock out yesterday. What do you do?', ['Nothing', 'Tell your manager so they fix it', 'Clock out twice today'], 1]] },
  { id: 'till', module: 'till', title: 'Count a till and bank the cash', roles: ['staff', 'supervisor', 'manager'],
    steps: [
      { testID: 'home-till', text: 'Tap Till & cash.' },
      { testID: 'mi-till-count', text: 'Tap "Count a till" at the end of each shift.' },
      { text: 'Count each note and coin, enter the Aronium End of day figures and take a photo of the Z report.' },
      { text: 'Both the cashier and the supervisor sign. A shortage is shown straight away.' },
      { testID: 'mi-till-deposit', text: 'To bank the cash, use "Bank deposit" and photograph the deposit slip.' },
    ],
    quiz: [['When is a till counted?', ['Once a month', 'At the end of every shift', 'Only when it is short'], 1],
      ['What proves the bank deposit?', ['A photo of the deposit slip', 'Nothing', 'A phone call'], 0]] },
  { id: 'invoice', module: 'payables', title: 'Enter a supplier invoice', roles: ['supervisor', 'manager', 'payroll'],
    steps: [
      { testID: 'home-payables', text: 'Tap Invoices & cheques.' },
      { testID: 'mi-ap-new', text: 'Tap "New invoice".' },
      { text: 'Take a clear photo of the whole invoice. The app reads the supplier, number and total – check them.' },
      { text: 'Save. Someone else checks it, then it can be paid by cheque, cash or bank.' },
    ],
    quiz: [['What must every invoice have?', ['A photo', 'A stamp', 'A signature from the supplier'], 0]] },
  { id: 'receive', module: 'inventory', title: 'Receive a delivery', roles: ['supervisor', 'manager'],
    steps: [
      { testID: 'home-inventory', text: 'Tap Inventory.' },
      { testID: 'mi-inv-receive', text: 'Tap "Receive a delivery" and choose the purchase order it belongs to.' },
      { text: 'Count what came off the truck. Change the number if less (or more) arrived, and the price if the invoice price is different.' },
      { text: 'No purchase order? Take a photo of the invoice or the goods – it is needed.' },
      { text: 'Bakery ingredients received at Shop 1 go straight into the Bakery stock.' },
    ],
    quiz: [['A delivery has no purchase order. What is needed?', ['Nothing', 'A photo of the invoice or the goods', 'The owner must be there'], 1],
      ['Fewer boxes arrived than ordered. What do you do?', ['Enter what really arrived', 'Enter what was ordered', 'Refuse everything'], 0]] },
  { id: 'stocktake', module: 'inventory', title: 'Do a stock take', roles: ['supervisor', 'manager'],
    steps: [
      { testID: 'home-inventory', text: 'Tap Inventory.' },
      { testID: 'mi-inv-count', text: 'Tap "Stock take" and start a count for your shop.' },
      { text: 'Scan or find each product and type how many are on the shelf. Count everything in one area before moving on.' },
      { text: 'Finish: differences are shown and a manager approves them.' },
    ],
    quiz: [['What does the stock take record?', ['What is really on the shelf', 'What Aronium says', 'What was ordered'], 0]] },
  { id: 'timesheet', module: 'timesheets', title: 'Check the week\'s timesheets', roles: ['supervisor', 'manager', 'payroll'],
    steps: [
      { testID: 'home-timesheets', text: 'Tap Timesheets.' },
      { text: 'Open each person. Missing clock-outs and long breaks are shown in colour.' },
      { text: 'Fix a time with a reason – the change and the reason are kept forever.' },
      { text: 'Tick "Checked" for each person before the pay run.' },
    ],
    quiz: [['When do you fix a timesheet?', ['After the pay run', 'Before the pay run, with a reason', 'Never'], 1]] },
  { id: 'leave', module: 'leave', title: 'Ask for leave', roles: ['staff', 'worker', 'supervisor', 'manager', 'payroll'],
    steps: [
      { testID: 'home-leave', text: 'Tap Leave (or My hours).' },
      { testID: 'mi-leave-mine', text: 'Tap "My leave" to see what you have left and to ask for leave.' },
      { text: 'Choose the type and the dates. Sick leave may need a medical certificate photo.' },
      { text: 'Your manager approves it; you see the answer here.' },
    ],
    quiz: [['Where do you see how much leave you have left?', ['My leave', 'Payroll rules', 'Bank'], 0]] },
  { id: 'payrun', module: 'payroll', title: 'Do the weekly pay run', roles: ['payroll'],
    steps: [
      { testID: 'home-payroll', text: 'Tap Payroll.' },
      { testID: 'mi-pay-new', text: 'Tap "Start a pay run". Check the pay period and the pay day.' },
      { text: 'Tick who is paid this time. People left out can be paid later – never twice.' },
      { text: 'Check each person. Fix a timesheet from inside the pay run if needed; the pay is worked out again.' },
      { text: 'Make it final. Staff then sign their payslips, and FNPF / PAYE for the month update by themselves.' },
    ],
    quiz: [['Someone was left out of this week\'s pay run. What happens?', ['They can be paid later, never twice', 'They lose the pay', 'They are paid twice'], 0]] },
  { id: 'bakery', module: 'bakery', title: 'The baker\'s day', roles: ['worker', 'supervisor'],
    steps: [
      { testID: 'home-bakery', text: 'Tap Bakery – "Bakery today" shows the day step by step.' },
      { text: 'Clock in on the Time Clock first. Then count the opening stock to open the day.' },
      { text: 'Do the opening checklists. Then baking is unlocked: start each batch with New batch.' },
      { text: 'At the end: closing checklists, then Close & count – count what is left, say why if it is different.' },
      { text: 'Clock out on the Time Clock.' },
    ],
    quiz: [['When can you start the first batch?', ['Straight away', 'After clocking in, the opening count and the opening checklists', 'After closing'], 1]] },
];

export function getTutorial(id) { return id === 'tour' ? TOUR : TUTORIALS.find((t) => t.id === id) || null; }
export function tutorialsFor(user, moduleOn = () => true) {
  if (!user) return [];
  const all = actsAsOwner(user) || user.role === 'admin' || can(user, 'settings');
  return TUTORIALS.filter((t) => moduleOn(t.module) && (all || t.roles.includes(user.role)));
}
export function tutorialsForModule(user, moduleId, moduleOn) { return tutorialsFor(user, moduleOn).filter((t) => t.module === moduleId); }

// Progress: { [userUid]: { tour: at, [tutorialId]: { at, score, of } } } (shared, synced).
export function progressAll() { return getShared('tutorial_progress', {}) || {}; }
export function progressOf(userUid) { return progressAll()[userUid] || {}; }
export function tourSeen(user) { return !!(user && user.uid && progressOf(user.uid).tour); }
export function markTourSeen(user) {
  if (!user || !user.uid) return;
  const all = progressAll();
  all[user.uid] = { ...(all[user.uid] || {}), tour: stamp() };
  setShared('tutorial_progress', all);
}
export function scoreQuiz(tutorialId, answers) {
  const t = getTutorial(tutorialId);
  const quiz = (t && t.quiz) || [];
  const right = quiz.filter((q, i) => Number(answers[i]) === q[2]).length;
  return { right, of: quiz.length, passed: right === quiz.length };
}
export function recordTutorial(user, tutorialId, answers = []) {
  const t = getTutorial(tutorialId);
  if (!t || !user || !user.uid) return null;
  const sc = scoreQuiz(tutorialId, answers);
  const all = progressAll();
  const mine = { ...(all[user.uid] || {}) };
  const before = mine[tutorialId];
  mine[tutorialId] = { at: stamp(), score: sc.right, of: sc.of, passed: sc.passed, tries: ((before && before.tries) || 0) + 1, name: user.name };
  all[user.uid] = mine;
  setShared('tutorial_progress', all);
  audit({ user, action: `Tutorial "${t.title}": ${sc.right} of ${sc.of} right`, table: 'shared_settings', recordUid: 'tutorial_progress' });
  return mine[tutorialId];
}
