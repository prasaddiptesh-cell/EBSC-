// v3.9.8 Power and water bills.
// Water (WAF): checked by itself once a day on the main tablet – WAF's "Check My Bill" needs only the account number
// (POST account_number to waterauthority.com.fj/payment-options/, the answer is in <div class="water-bill-data">).
// Power (EFL): EFL's bill checker has an "I'm not a robot" box, so it is never checked by a program. Once a month
// someone taps "Check EFL bill" (the checker opens, the account number is ready to paste), then gives the app a
// screenshot of the result (or types the 3 figures). The app reads it the same way.
// Each result: a new bill goes into supplier invoices for that shop (to check), the people who pay bills are told
// (new bill, due soon, overdue, higher than usual, not checked / no bill this month). Nothing here may stop the app.
import { db } from '../db/connection.js';
import { AppError, stamp, uuid, deviceId, audit, dateStr, addDays, getSetting, setSetting } from './core.js';
import { can, actsAsOwner } from './access.js';
import { requirePerm, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const txt = (v) => (v === null || v === undefined ? '' : String(v).trim());
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const $ = (n) => `$${r2(n).toFixed(2)}`;

export const WAF_URL = 'https://waterauthority.com.fj/payment-options/';
export const EFL_URL = 'https://efl.com.fj/billcheck/';
export const BILL_KIND = { water: { label: 'Water', icon: '💧', supplier: 'Water Authority of Fiji', prefix: 'WAF', category: 'Water' },
  power: { label: 'Electricity', icon: '⚡', supplier: 'Energy Fiji Limited', prefix: 'EFL', category: 'Electricity' } };

export const BILL_SQL = `
CREATE TABLE IF NOT EXISTS utility_checks (
  uid TEXT PRIMARY KEY,
  account_uid TEXT NOT NULL,
  shop_code TEXT,
  kind TEXT NOT NULL,
  account_no TEXT,
  checked_at TEXT NOT NULL,
  check_date TEXT NOT NULL,
  total REAL,
  overdue REAL,
  due_date TEXT,
  source TEXT,
  result TEXT,
  invoice_uid TEXT,
  by_name TEXT,
  note TEXT,
  updated_at TEXT NOT NULL, updated_device TEXT, sync_status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_utility_checks ON utility_checks(account_uid, check_date);
`;
export const BILL_SYNC = {
  utility_checks: { key: 'uid', section: 'Invoices', cols: ['uid', 'account_uid', 'shop_code', 'kind', 'account_no', 'checked_at', 'check_date', 'total', 'overdue', 'due_date', 'source', 'result', 'invoice_uid', 'by_name', 'note', 'updated_at', 'updated_device'] },
};

// ---------------------------------------------------------------- reading the answers
const money = (s) => { const m = /\$?\s*(-?[\d,]+(?:\.\d{1,2})?)/.exec(String(s || '').replace(/(\d)\s+(?=\d)/g, '$1')); return m ? r2(m[1].replace(/,/g, '')) : null; };
// "09-11-2026" or "19/10/2026" → 2026-11-09
export function dmyToIso(s) {
  const m = /(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/.exec(String(s || ''));
  if (!m) return null;
  const d = Number(m[1]); const mo = Number(m[2]); const y = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
// WAF's answer (the whole page): { total, account, due } or null when the page has no bill block.
export function parseWafHtml(html) {
  const s = String(html || '');
  const i = s.indexOf('water-bill-data');
  if (i < 0) return null;
  const block = s.slice(i, i + 1500).replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ');
  const t = /bill total is\s*\$?\s*([\d,]+(?:\.\d{1,2})?)/i.exec(block);
  const a = /Account Number\s*(\d{6,})/i.exec(block);
  const d = /due on\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})/i.exec(block);
  if (!t) return null;
  return { total: r2(t[1].replace(/,/g, '')), account: a ? a[1] : null, due: d ? dmyToIso(d[1]) : null };
}
// EFL's checker result (text read from a screenshot, or typed): { account, total, overdue, due }.
export function parseEflText(text) {
  const r = parseBillText(text);
  return { account: r.account, total: r.total, overdue: r.overdue, due: r.due };
}
// 1.0.0 build 54: any EFL or WAF bill read on this phone (ML Kit text of a paper bill, a screenshot of EFL's checker or
// WAF's "Check My Bill", or text typed in) → { account, total, overdue, due, billNo }.
// Build 53 only knew the checker's words ("Total Amount Due", "Due on"), so a paper bill ("Amount Payable", "Due Date
// 21 Nov 2026") filled nothing; and the account number ran on into the digits of the next line.
const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
const DATE_RE = /\d{1,2}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{4}|\d{1,2}(?:st|nd|rd|th)?[\s\-/.]*[A-Za-z]{3,9}\.?[\s\-/.,]*\d{4}|[A-Za-z]{3,9}\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}/g;
export function billDate(s) {
  const t = String(s || '');
  const n = /(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{4})/.exec(t);
  if (n) return dmyToIso(`${n[1]}/${n[2]}/${n[3]}`);
  const iso = (y, mo, d) => (mo && d >= 1 && d <= 31 ? `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}` : null);
  const a = /(\d{1,2})(?:st|nd|rd|th)?[\s\-/.]*([A-Za-z]{3,9})\.?[\s\-/.,]*(\d{4})/.exec(t);
  if (a) { const v = iso(a[3], MON[a[2].toLowerCase()] || MON[a[2].slice(0, 3).toLowerCase()], Number(a[1])); if (v) return v; }
  const b = /([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})/.exec(t);
  if (b) { const v = iso(b[3], MON[b[1].toLowerCase()] || MON[b[1].slice(0, 3).toLowerCase()], Number(b[2])); if (v) return v; }
  return null;
}
const moneyIn = (s) => {
  const t = String(s || '').replace(DATE_RE, ' ').replace(/(\d)\s+(?=[\d.])/g, '$1').replace(/\.\s+(?=\d)/g, '.');
  const m = /(?:\$|FJD|F\$)?\s*(\d[\d,]*(?:\.\d{1,2})?)(?!\d)/i.exec(t);
  if (!m) return null;
  const v = Number(m[1].replace(/,/g, ''));
  return Number.isFinite(v) ? r2(v) : null;
};
const ACCT_RE = /\b(?:Customer\s*)?(?:Account|Acct|Acc|A\/C)\b\.?\s*(?:Number|No\.?|Num(?:ber)?|#)?\s*[:\-#.]?\s*(?:is\s*)?/i;
const ACCT_NUM = /^(\d(?:\d|[ \-](?=\d))*\d)(?!\d| ?[/.\-] ?\d)/;
const TOTAL_RES = [/Total\s*Amount\s*Due/i, /bill\s*total\s*is/i, /Total\s*(?:Amount\s*)?Payable/i, /Amount\s*Payable/i, /Total\s*Due/i, /Amount\s*Due/i, /Balance\s*Due/i, /(?:Total|Amount)\s*to\s*Pay/i, /Please\s*Pay/i];
const NOT_TOTAL = /overdue|previous|last\s*(?:bill|payment)|arrears|brought\s*forward|b\/f|payment\s*received|paid\s*on/i;
const DUE_RES = [/Due\s*(?:Date|on|by)/i, /Pay(?:ment)?\s*(?:Due|by)/i, /\bDue\b/i];
export function parseBillText(text) {
  const lines = String(text || '').slice(0, 50000).replace(/\r/g, '').split('\n').map((l) => l.replace(/[ \t]+/g, ' ').trim()).filter(Boolean);
  const noLetters = (l) => l && !/[a-z]{4}/i.test(l.replace(DATE_RE, ''));
  // the words after a label on its line, or the next line when the label stands alone
  const after = (l, re) => { const m = re.exec(l); return m ? l.slice(m.index + m[0].length) : null; };
  let account = null;
  for (let i = 0; i < lines.length && !account; i += 1) {
    const l = lines[i];
    if (/Account\s*(?:Name|Holder|Type|Status)/i.test(l) && !/Account\s*(?:Number|No)/i.test(l)) continue;
    const rest = after(l, ACCT_RE);
    if (rest === null) continue;
    let m = ACCT_NUM.exec(rest.trim());
    if (!m && !/\d/.test(rest) && lines[i + 1]) m = ACCT_NUM.exec(lines[i + 1]);
    const d = m ? m[1].replace(/\D/g, '') : '';
    if (d.length >= 5 && d.length <= 16) account = d;
  }
  let total = null;
  for (const re of TOTAL_RES) {
    for (let i = 0; i < lines.length && total === null; i += 1) {
      const l = lines[i];
      if (NOT_TOTAL.test(l)) continue;
      const rest = after(l, re);
      if (rest === null) continue;
      let v = moneyIn(rest);
      if (v === null && noLetters(lines[i + 1])) v = moneyIn(lines[i + 1]);
      if (v !== null) total = v;
    }
    if (total !== null) break;
  }
  let overdue = null;
  for (let i = 0; i < lines.length && overdue === null; i += 1) {
    const rest = after(lines[i], /Overdue\s*(?:Amount|Balance)?|Arrears/i);
    if (rest === null) continue;
    let v = moneyIn(rest);
    if (v === null && noLetters(lines[i + 1])) v = moneyIn(lines[i + 1]);
    if (v !== null) overdue = v;
  }
  let due = null;
  for (const re of DUE_RES) {
    for (let i = 0; i < lines.length && !due; i += 1) {
      const rest = after(lines[i], re);
      if (rest === null) continue;
      due = billDate(rest) || (noLetters(lines[i + 1]) ? billDate(lines[i + 1]) : null);
    }
    if (due) break;
  }
  let billNo = null;
  for (const l of lines) { const m = /\b(?:Bill|Invoice|Tax\s*Invoice)\s*(?:No\.?|Number|#)\s*[:\-#.]?\s*([A-Z0-9][A-Z0-9\-/]{3,20})/i.exec(l); if (m && /\d/.test(m[1])) { billNo = m[1].toUpperCase(); break; } }
  return { account, total, overdue, due, billNo };
}
// An account number read from a bill → the bill account it belongs to (spaces, dashes and leading zeros ignored; a
// number printed with a prefix or cut short still matches when 6 or more digits agree at the end).
export function matchBillAccount(accountNo, kind) {
  const d = String(accountNo || '').replace(/\D/g, '');
  if (d.length < 5) return null;
  const list = billAccounts(kind);
  const norm = (x) => String(x || '').replace(/\D/g, '');
  const exact = list.find((a) => norm(a.account_no) === d || norm(a.account_no).replace(/^0+/, '') === d.replace(/^0+/, ''));
  if (exact) return exact;
  const near = list.filter((a) => { const n = norm(a.account_no); return n.length >= 6 && d.length >= 6 && (n.endsWith(d) || d.endsWith(n)); });
  return near.length === 1 ? near[0] : null;
}

// ---------------------------------------------------------------- accounts and results
export function billAccounts(kind) {
  if (!has('shop_accounts')) return [];
  return db().all("SELECT a.*, s.name AS shop_name FROM shop_accounts a LEFT JOIN shops s ON s.code = a.shop_code WHERE a.active = 1 AND a.kind IN ('water','power') AND IFNULL(a.account_no,'') <> ''" + (kind ? ' AND a.kind = ?' : '') + ' ORDER BY a.shop_code, a.kind, a.label', kind ? [kind] : []);
}
export function lastCheck(accountUid) {
  return has('utility_checks') ? db().get('SELECT * FROM utility_checks WHERE account_uid = ? ORDER BY checked_at DESC LIMIT 1', [accountUid]) || null : null;
}
function lastBillCheck(accountUid, exceptUid) {
  return db().get("SELECT * FROM utility_checks WHERE account_uid = ? AND total > 0.004 AND uid <> ? ORDER BY checked_at DESC LIMIT 1", [accountUid, exceptUid || '']) || null;
}
function usualAmount(accountUid) {
  const rows = db().all("SELECT DISTINCT due_date, total FROM utility_checks WHERE account_uid = ? AND total > 0.004 AND due_date IS NOT NULL ORDER BY due_date DESC LIMIT 7", [accountUid]);
  const prev = rows.slice(1, 7).map((r) => Number(r.total)).filter((v) => v > 0);
  if (prev.length < 2) return null;
  return r2(prev.reduce((a, b) => a + b, 0) / prev.length);
}
const billNo = (acc, due) => `${BILL_KIND[acc.kind].prefix}-${String(acc.account_no).replace(/\s/g, '')}-${String(due).replace(/-/g, '')}`;
function supplierFor(user, acc) {
  const AP = require('../modules/payables/service.js');
  if (acc.supplier_uid) { const s = AP.getSupplier(acc.supplier_uid); if (s) return s; }
  const name = BILL_KIND[acc.kind].supplier;
  const found = db().get('SELECT uid FROM ap_suppliers WHERE lower(name) = lower(?) LIMIT 1', [name]);
  if (found) return AP.getSupplier(found.uid);
  return AP.saveSupplier(user, { name, category: BILL_KIND[acc.kind].category, onAccount: true });
}

// One result for a bill account (from WAF, a screenshot of EFL's checker, or typed).
// → { uid, result: 'new_bill'|'same'|'paid'|'nothing', invoice, higher, overdue }
export function recordCheck(user, accountUid, { total, overdue = null, due = null, source = 'typed', note } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(has('utility_checks'), 'Bills check is not ready on this device yet.');
  const acc = db().get('SELECT * FROM shop_accounts WHERE uid = ?', [accountUid]);
  need(acc && BILL_KIND[acc.kind], 'Choose an electricity or water account.');
  // v3.9.8 letters or a misread never become $0.00 ("nothing owing"): only a real number is taken
  const asNum = (v) => { if (v === null || v === undefined || String(v).trim() === '') return null; const x = Number(String(v).replace(/[$,\s]/g, '')); return Number.isFinite(x) ? r2(x) : NaN; };
  const t = asNum(total);
  need(t !== null && !Number.isNaN(t) && t >= 0 && t < 1000000, 'Enter the total amount due (0.00 when nothing is owing).');
  const od = asNum(overdue);
  need(od === null || (!Number.isNaN(od) && od >= 0), 'The overdue amount should be a number (or left empty).');
  const dueIso = txt(due) ? (/^\d{4}-\d{2}-\d{2}$/.test(txt(due)) ? txt(due) : dmyToIso(due)) : null;
  need(!txt(due) || dueIso, 'Enter the due date as it shows (e.g. 19/10/2026).');
  const now = stamp(); const dev = deviceId(); const today = dateStr();
  const prev = lastBillCheck(accountUid);
  let result = 'nothing';
  let invoiceUid = null;
  let invoice = null;
  if (t > 0.004) {
    // The same bill again (same due date and amount, or already made): nothing new.
    const k = BILL_KIND[acc.kind];
    const no = billNo(acc, dueIso || today);
    const existing = db().get("SELECT uid FROM ap_invoices WHERE invoice_no = ? AND status <> 'void'", [no]);
    if (existing || (prev && prev.due_date === dueIso && Math.abs(Number(prev.total) - t) < 0.01)) { result = 'same'; invoiceUid = existing ? existing.uid : prev.invoice_uid; }
    else result = 'new_bill'; // v3.9.8 the bill is made once someone acknowledges the notice (Power & water bills)
    void k;
  } else result = 'paid';
  const uid = uuid('UC');
  db().run(`INSERT INTO utility_checks (uid, account_uid, shop_code, kind, account_no, checked_at, check_date, total, overdue, due_date, source, result, invoice_uid, by_name, note, updated_at, updated_device) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [uid, accountUid, acc.shop_code, acc.kind, acc.account_no, now, today, t, od, dueIso, source, result, invoiceUid, user ? user.name : 'Easy Buys app', txt(note) || null, now, dev]);
  const usual = usualAmount(accountUid);
  const higher = result === 'new_bill' && usual && t > usual * 1.3 && t - usual > 20 ? usual : null;
  if (result === 'new_bill' || (od && od > 0.004)) {
    const k = BILL_KIND[acc.kind];
    const text = result === 'new_bill'
      ? `${k.icon} ${k.label} – ${acc.label}: new bill ${$(t)}${dueIso ? `, due ${dueIso}` : ''}${higher ? ` – HIGHER than usual (${$(higher)})` : ''}. Acknowledge it in the app to make the bill.`
      : `${k.icon} ${k.label} – ${acc.label}: ${$(od)} OVERDUE`;
    try { require('../modules/verify/service.js').notify('bill', text, { shopCode: acc.shop_code }); } catch (e) { /* Viber is optional */ }
  }
  if (result === 'same' && prev && prev.result === 'new_bill' && !prev.invoice_uid) {
    // still waiting to be acknowledged: this check is part of the same bill
    db().run("UPDATE utility_checks SET result = 'same_waiting' WHERE uid = ?", [uid]);
  }
  audit({ user, action: `${BILL_KIND[acc.kind].label} bill check ${acc.label}: ${$(t)}${dueIso ? ` due ${dueIso}` : ''} (${result.replace('_', ' ')})`, table: 'utility_checks', recordUid: uid });
  return { uid, result, invoice, invoiceUid, higher, overdue: od };
  });
}

// v3.9.8 a new bill found by a check waits to be acknowledged; then the bill is made in Invoices for that shop.
export function waitingBills() {
  if (!has('utility_checks')) return [];
  return db().all(`SELECT c.*, a.label, a.supplier_uid, s.name AS shop_name FROM utility_checks c JOIN shop_accounts a ON a.uid = c.account_uid LEFT JOIN shops s ON s.code = c.shop_code
    WHERE c.result = 'new_bill' AND c.invoice_uid IS NULL ORDER BY c.checked_at`);
}
const mayPayBills = (u) => !!u && (actsAsOwner(u) || ['owner', 'admin'].includes(u.role) || can(u, 'payments_make') || can(u, 'ap_setup'));
export function acknowledgeBill(user, checkUid, { total, due, note } = {}) {
  requirePerm(user, 'invoices_enter', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(mayPayBills(user), 'Only the owner, admin or the person who pays bills can make the bill.');
  const c = db().get('SELECT * FROM utility_checks WHERE uid = ?', [checkUid]);
  need(c && c.result === 'new_bill' && !c.invoice_uid, 'This bill was already made or put aside.');
  const acc = db().get('SELECT * FROM shop_accounts WHERE uid = ?', [c.account_uid]);
  need(acc, 'The bill account is no longer there.');
  const k = BILL_KIND[acc.kind];
  const t = total !== undefined && total !== '' && total !== null ? r2(total) : r2(c.total);
  need(t > 0, 'Enter the amount.');
  const dueIso = txt(due) ? (/^\d{4}-\d{2}-\d{2}$/.test(txt(due)) ? txt(due) : dmyToIso(due)) : c.due_date;
  const today = dateStr();
  const AP = require('../modules/payables/service.js');
  const sup = supplierFor(user, acc);
  const invDate = dueIso && dueIso < today ? dueIso : today;
  const inv = AP.saveInvoice(user, { supplierUid: sup.uid, invoiceNo: billNo(acc, dueIso || today), invoiceDate: invDate, dueDate: dueIso && dueIso >= invDate ? dueIso : invDate, total: t, shopCode: acc.shop_code, category: k.category, onAccount: true,
    description: `${k.label} – ${acc.label} (account ${acc.account_no})`, notes: [`From the ${k.prefix} bill check${c.source === 'waf_auto' ? ' (automatic)' : ''}, acknowledged by ${user.name}. Check the VAT against the bill.`, txt(note)].filter(Boolean).join(' – ') }, { allowDuplicate: true });
  const now = stamp();
  db().run("UPDATE utility_checks SET invoice_uid = ?, result = 'billed', note = COALESCE(?, note), updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [inv.uid, txt(note) || null, now, deviceId(), checkUid]);
  audit({ user, action: `${k.label} bill acknowledged – ${acc.label} ${$(t)}${dueIso ? ` due ${dueIso}` : ''}: bill made`, table: 'utility_checks', recordUid: checkUid });
  return inv;
  });
}
// 1.0.0 build 54: a bill read from a photo, screenshot or PDF (the AI, or this phone) → its bill account (by the
// account number on it, or the one chosen on the screen), the check, and – for whoever pays bills – the bill in
// Invoices for that shop and supplier (EFL / WAF). → recordCheck's answer + { account, invoice }
export function fileBillReading(user, { accountUid, accountNo, kind, total, due, overdue = null, source = 'bill_read', note } = {}) {
  requirePerm(user, ['invoices_enter', 'snap_upload'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  const chosen = accountUid ? db().get('SELECT * FROM shop_accounts WHERE uid = ?', [accountUid]) : null;
  // 1.0.0 build 1: a number of the OTHER kind (a power bill read while the water account was chosen) is caught too.
  const found = txt(accountNo) ? (matchBillAccount(accountNo, kind || (chosen && chosen.kind) || undefined) || matchBillAccount(accountNo)) : null;
  const k = kind && BILL_KIND[kind] ? BILL_KIND[kind] : null;
  if (chosen && found && found.uid !== chosen.uid) need(false, `This bill is for account ${txt(accountNo)} (${found.label}, ${found.shop_name || found.shop_code}), not ${chosen.label}. Choose that account.`);
  const acc = chosen || found;
  need(acc, txt(accountNo)
    ? `No ${k ? `${k.label.toLowerCase()} ` : ''}bill account has the number ${txt(accountNo)}. Add it on the shop page (Shops › the shop › Bill accounts), or choose the account.`
    : 'The account number was not found on the bill – choose the bill account.');
  const r = recordCheck(user, acc.uid, { total, overdue, due, source, note });
  let invoice = null;
  if (r.result === 'new_bill' && mayPayBills(user)) { try { invoice = acknowledgeBill(user, r.uid); } catch (e) { invoice = null; } }
  return { ...r, account: acc, invoice };
  });
}
export function putAsideBill(user, checkUid, reason) {
  requirePerm(user, ['invoices_enter', 'snap_upload'], { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(() => {
  need(mayPayBills(user), 'Only the owner, admin or the person who pays bills can do this.');
  need(txt(reason), 'Say why no bill is needed.');
  const c = db().get('SELECT * FROM utility_checks WHERE uid = ?', [checkUid]);
  need(c && c.result === 'new_bill' && !c.invoice_uid, 'This bill was already made or put aside.');
  const now = stamp();
  db().run("UPDATE utility_checks SET result = 'put_aside', note = ?, updated_at = ?, updated_device = ?, sync_status = 'pending' WHERE uid = ?", [txt(reason), now, deviceId(), checkUid]);
  audit({ user, action: 'Bill check put aside (no bill made)', table: 'utility_checks', recordUid: checkUid, reason: txt(reason) });
  });
}

// ---------------------------------------------------------------- the daily water check (main tablet)
const SYS = { uid: 'bills-auto', name: 'Easy Buys app (bills check)', role: 'owner' };
export async function checkWaterBills({ fetchFn, today = dateStr(), force = false } = {}) {
  const f = fetchFn || (typeof fetch === 'function' ? fetch : null);
  if (!f || !has('utility_checks')) return { checked: 0, problems: [] };
  if (!force && getSetting('waf_checked_on', '') === today) return { checked: 0, problems: [], skipped: true };
  if (!force && Date.now() - (Number(getSetting('waf_fail_ms', '0')) || 0) < 2 * 3600000) return { checked: 0, problems: [], skipped: 'waiting after a failed try' };
  const out = { checked: 0, problems: [], results: [] };
  for (const acc of billAccounts('water')) {
    try {
      const body = `account_number=${encodeURIComponent(String(acc.account_no).replace(/\s/g, ''))}`;
      const res = await f(WAF_URL, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
      const html = await res.text();
      const p = parseWafHtml(html);
      if (!p) { out.problems.push(`${acc.label}: WAF did not show a bill`); continue; }
      out.results.push(asService(() => recordCheck(SYS, acc.uid, { total: p.total, due: p.due, source: 'waf_auto' }))); // the app's own check (not a person)
      out.checked += 1;
    } catch (e) { out.problems.push(`${acc.label}: ${String(e && e.message || e).slice(0, 80)}`); }
  }
  // v3.9.8 no internet / WAF down (nothing could be checked): tried again in 2 hours, not left until tomorrow
  if (!out.checked && out.problems.length) setSetting('waf_fail_ms', String(Date.now()));
  else { setSetting('waf_checked_on', today); setSetting('waf_fail_ms', '0'); }
  setSetting('waf_check_problem', out.problems.length && !out.checked ? out.problems.join(' · ').slice(0, 300) : '');
  return out;
}

// ---------------------------------------------------------------- what is due, for Home and the shop pages
// Each power / water account: its last check, open bill, and what to do.
export function billBoard(today = dateStr()) {
  return billAccounts().map((a) => {
    const k = BILL_KIND[a.kind];
    const c = lastCheck(a.uid);
    let inv = null;
    if (c && c.invoice_uid) { try { inv = require('../modules/payables/service.js').getInvoice(c.invoice_uid); } catch (e) { inv = null; } }
    const owing = inv ? r2(inv.owing) : null;
    const due = inv ? inv.due_date : c ? c.due_date : null;
    const days = c ? Math.round((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${c.check_date}T00:00:00Z`)) / 86400000) : null;
    const waiting = c && c.result === 'new_bill' && !c.invoice_uid ? c : (has('utility_checks') ? db().get("SELECT * FROM utility_checks WHERE account_uid = ? AND result = 'new_bill' AND invoice_uid IS NULL ORDER BY checked_at DESC LIMIT 1", [a.uid]) : null);
    if (waiting) return { uid: a.uid, shop: a.shop_code, shopName: a.shop_name, kind: a.kind, icon: k.icon, label: a.label, accountNo: a.account_no, lastChecked: c ? c.checked_at : null, daysSince: days,
      total: waiting.total, due: waiting.due_date, owing: null, invoiceUid: null, state: 'to_confirm', checkUid: waiting.uid, auto: a.kind === 'water' };
    const state = inv && owing > 0.004 ? (due && due < today ? 'overdue' : due && due <= addDays(today, 3) ? 'due_soon' : 'owing')
      : c && c.overdue > 0.004 ? 'overdue' : c ? 'paid' : 'not_checked';
    return { uid: a.uid, shop: a.shop_code, shopName: a.shop_name, kind: a.kind, icon: k.icon, label: a.label, accountNo: a.account_no, lastChecked: c ? c.checked_at : null, daysSince: days,
      total: c ? c.total : null, due, owing, invoiceUid: inv ? inv.uid : null, state, auto: a.kind === 'water' };
  });
}
// Warnings for Home (owner, admin and whoever pays bills).
export function billAlerts(user, today = dateStr()) {
  if (!user || !(actsAsOwner(user) || ['owner', 'admin'].includes(user.role) || can(user, 'payments_make') || can(user, 'ap_setup'))) return [];
  const out = [];
  let board = [];
  try { board = billBoard(today); } catch (e) { return []; }
  const wait = board.filter((b) => b.state === 'to_confirm');
  if (wait.length) out.push({ id: `bill-new-${wait.map((b) => b.checkUid).join('').length}-${wait.length}`, level: 'warning', text: `${wait.length} new power / water bill${wait.length === 1 ? '' : 's'} – acknowledge to make the bill`, sub: wait.map((b) => `${b.icon} ${b.shop} ${b.label} ${$(b.total)}${b.due ? ` due ${b.due}` : ''}`).join(' · '), nav: { screen: 'Bills', params: {} } });
  const over = board.filter((b) => b.state === 'overdue');
  if (over.length) out.push({ id: `bill-overdue-${over.length}`, level: 'urgent', text: `${over.length} power / water bill${over.length === 1 ? ' is' : 's are'} overdue`, sub: over.map((b) => `${b.icon} ${b.shop} ${b.label}${b.owing ? ` ${$(b.owing)}` : ''}`).join(' · '), nav: { screen: 'Bills', params: {} } });
  const soon = board.filter((b) => b.state === 'due_soon');
  if (soon.length) out.push({ id: `bill-soon-${soon.map((b) => b.due).join('')}`, level: 'warning', text: `${soon.length} power / water bill${soon.length === 1 ? '' : 's'} due in the next 3 days`, sub: soon.map((b) => `${b.icon} ${b.shop} ${b.label} ${$(b.owing)} due ${b.due}`).join(' · '), nav: { screen: 'Bills', params: {} } });
  // EFL: checked by a person once a month.
  const efl = board.filter((b) => b.kind === 'power' && (b.daysSince === null || b.daysSince >= 30));
  if (efl.length) out.push({ id: `bill-efl-${today.slice(0, 7)}-${efl.length}`, level: 'info', text: `Check the EFL bill${efl.length === 1 ? '' : 's'} (${efl.map((b) => `${b.shop} ${b.label}`).join(', ')})`, sub: 'One tap opens EFL\'s bill checker – then give the app a screenshot of the result.', nav: { screen: 'Bills', params: {} } });
  const wp = getSetting('waf_check_problem', '');
  if (wp) out.push({ id: `bill-waf-problem-${today}`, level: 'warning', text: 'Water bill check isn\'t working', sub: `${wp} – check on the WAF site by hand for now.`, nav: { screen: 'Bills', params: {} } });
  return out;
}
