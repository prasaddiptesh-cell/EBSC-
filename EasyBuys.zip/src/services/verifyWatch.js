// v3.9.6 New papers in To verify (an invoice photo, a delivery, a cheque handed over, cash…): a notification on the
// devices of the people who verify – also when the app is closed (the background sync checks every ~15 minutes).
// Which person a device notifies for: the last person on this device who may verify (owner, admin, manager…).
// Each item is told once; the first check on a device only notes what is already there (no flood of old items).
import { getSetting, setSetting } from './core.js';
import { db } from '../db/connection.js';

const SEEN_KEY = 'verify_seen_keys';
const MAX_SEEN = 3000;
const J = (v, d) => { try { const x = JSON.parse(v || ''); return x === null || x === undefined ? d : x; } catch (e) { return d; } };

// Called at log-in: a person who may verify becomes the one this device notifies for.
export function noteVerifier(user) {
  try {
    if (!user || !user.uid) return;
    const A = require('./access.js');
    if (A.can(user, 'verify_money') || A.actsAsOwner(user) || ['owner', 'admin'].includes(user.role)) setSetting('verify_notify_uid', user.uid);
  } catch (e) { /* only a convenience */ }
}
export function verifyNotifyOn() { return getSetting('verify_notify_off', '0') !== '1'; }
export function setVerifyNotify(on) { setSetting('verify_notify_off', on ? '0' : '1'); }

// The new items since the last check, for the person this device notifies for.
// Returns { items: [{ key, type, who, amount, text }], user } and marks them as told.
export function newToVerify({ mark = true } = {}) {
  const uid = getSetting('verify_notify_uid', '');
  if (!uid || !verifyNotifyOn()) return { items: [], user: null };
  let user = null;
  try { user = db().get('SELECT * FROM users WHERE uid = ? AND active = 1', [uid]); } catch (e) { user = null; }
  if (!user) return { items: [], user: null };
  let list = [];
  try { list = require('../modules/verify/service.js').queue({ include: 'waiting' }); } catch (e) { return { items: [], user }; }
  // a manager tied to one shop only hears about that shop
  const shopOnly = !['owner', 'admin'].includes(user.role) && user.shop_code ? user.shop_code : null;
  const all = list.filter((x) => x && x.key).map((x) => x.key);
  list = list.filter((x) => x && x.key && (!shopOnly || !x.shop || x.shop === shopOnly) && x.recordedByUid !== uid);
  const raw = getSetting(SEEN_KEY, '');
  const first = raw === '' || raw === null;
  const seenList = J(raw, []);
  const seen = new Set(Array.isArray(seenList) ? seenList : []);
  const fresh = first ? [] : list.filter((x) => !seen.has(x.key));
  if (mark) {
    const keep = [...new Set(all.concat([...seen]))].slice(0, MAX_SEEN);
    setSetting(SEEN_KEY, JSON.stringify(keep));
  }
  return { items: fresh.map((x) => ({ key: x.key, type: x.type, who: x.who || '', amount: x.amount, text: x.text || '', shop: x.shop || '' })), user };
}

// The words of the notification.
export function verifyMessage(items) {
  if (!items || !items.length) return null;
  const m = (n) => (n === null || n === undefined || n === '' ? '' : ` $${(Number(n) || 0).toFixed(2)}`);
  const line = (x) => `${x.type}${m(x.amount)}${x.who ? ` – ${x.who}` : ''}${x.shop ? ` (${x.shop})` : ''}`;
  return {
    title: items.length === 1 ? '✅ New to verify' : `✅ ${items.length} new to verify`,
    body: items.slice(0, 4).map(line).join('\n') + (items.length > 4 ? `\n… and ${items.length - 4} more` : ''),
  };
}
