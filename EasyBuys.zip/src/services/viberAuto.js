// Automatic Viber Channel alerts (1.0): when "Viber Channel" is chosen in Verification & Viber alerts, the main tablet
// also posts supplier order reminders (order today / missed cut-off) and urgent watchdog findings, each once.
import { getSetting, setSetting, dateStr, addDays } from './core.js';
import { notify, verifyRules } from '../modules/verify/service.js';
import { orderAlerts } from '../modules/inventory/schedules.js';
import { runWatchdog } from './watchdog.js';

const OWNER = { name: 'Easy Buys', role: 'owner', uid: 'system' };
function sentMap() { try { return JSON.parse(getSetting('viber_auto_sent', '') || '{}') || {}; } catch (e) { return {}; } }

export function autoViberAlerts({ isMain, today = dateStr(), now } = {}) {
  const r = verifyRules();
  if (!isMain || r.viberMode !== 'channel') return [];
  const sent = sentMap();
  Object.keys(sent).forEach((k) => { if (sent[k] < addDays(today, -14)) delete sent[k]; });
  const out = [];
  const send = (id, event, text, shopCode) => {
    if (sent[id]) return;
    const msg = notify(event, text, { shopCode });
    if (msg) { sent[id] = today; out.push(msg); }
  };
  let orders = [];
  try { orders = orderAlerts(OWNER, now ? { now } : {}); } catch (e) { orders = []; }
  orders.forEach((a) => send(`${a.id}`, 'order_due', a.text));
  let wd = [];
  try { wd = runWatchdog(OWNER).filter((x) => x.level === 'urgent'); } catch (e) { wd = []; }
  wd.forEach((x) => send(`wd:${x.id}`, 'watchdog_urgent', `${x.text} – ${x.todo}`));
  setSetting('viber_auto_sent', JSON.stringify(sent));
  try { urgentAlerts(r, out, today); } catch (e) { /* next round */ }
  try { morningSummary(r, out, today, now); } catch (e) { /* next round */ }
  return out;
}

// v3.9.4 urgent warnings go to the Channel at once, and "✅ Sorted" when they are gone. Checked at most every 5 minutes
// (the owner's warnings already worked out on this device are reused).
function urgentAlerts(r, out, today) {
  if (!r.events.alerts_urgent) return;
  const last = Number(getSetting('viber_urgent_ms', '0')) || 0;
  if (Date.now() - last < 5 * 60000) return;
  setSetting('viber_urgent_ms', String(Date.now()));
  const A = require('./alerts.js');
  const list = (A.cachedOwnerAlerts() || A.collectAlerts({ uid: 'viber', name: 'Viber', role: 'owner' }, { includeHidden: true, today })).filter((a) => a.level === 'urgent');
  let open = {};
  try { open = JSON.parse(getSetting('viber_urgent_open', '') || '{}') || {}; } catch (e) { open = {}; }
  for (const a of list) {
    if (open[a.id]) continue;
    const msg = notify('alerts_urgent', `🚨 ${a.text}${a.sub ? ` – ${a.sub}` : ''}`);
    if (msg) out.push(msg);
    open[a.id] = { text: a.text, at: today };
  }
  const now = new Set(list.map((a) => a.id));
  for (const [id, x] of Object.entries(open)) {
    if (now.has(id)) continue;
    const msg = notify('alerts_urgent', `✅ Sorted: ${x.text}`);
    if (msg) out.push(msg);
    delete open[id];
  }
  setSetting('viber_urgent_open', JSON.stringify(open));
}

// v3.9.4 one morning post with the day: due today and this week, warnings, who is on leave. Once a day, from the set time.
function morningSummary(r, out, today, now) {
  if (!r.events.morning || getSetting('viber_morning_sent', '') === today) return;
  const t = now ? new Date(now) : require('./core.js').clock.now();
  const hhmm = `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`;
  if (hhmm < (r.morningAt || '07:30')) return;
  setSetting('viber_morning_sent', today);
  const B = require('./board.js');
  const board = B.buildBoard({ force: true, today });
  const sec = (board.sections || []).find((x) => x.id === 'today') || { blocks: [] };
  const lst = (title) => ((sec.blocks || []).find((b) => b.type === 'list' && b.title && b.title.indexOf(title) === 0) || { items: [] }).items;
  const money = (v) => `$${Number(v).toFixed(2)}`;
  const due = lst('Due today');
  const todayDue = due.filter((d) => d.date <= today);
  const week = due.filter((d) => d.date > today);
  const warn = lst('Needs attention');
  const day = t.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'short' });
  const lines = [`☀️ Good morning – ${day}`];
  const item = (d) => `• ${d.text}${d.right !== null && d.right !== undefined ? ` – ${money(d.right)}` : ''}${d.sub ? ` (${d.sub})` : ''}`;
  lines.push(todayDue.length ? `\nDue today / overdue (${todayDue.length}):\n${todayDue.slice(0, 15).map(item).join('\n')}` : '\nNothing due today.');
  if (week.length) lines.push(`\nThis week (${week.length}):\n${week.slice(0, 15).map(item).join('\n')}`);
  if (warn.length) lines.push(`\nNeeds attention (${warn.length}):\n${warn.slice(0, 12).map((w) => `• ${w.tag ? '🚨 ' : ''}${w.text}`).join('\n')}`);
  const msg = notify('morning', lines.join('\n').slice(0, 6500));
  if (msg) out.push(msg);
}
