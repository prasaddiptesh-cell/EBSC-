// Automatic Viber Channel alerts (1.0): when "Viber Channel" is chosen in Verification & Viber alerts, the main tablet
// also posts supplier order reminders (order today / missed cut-off) and urgent watchdog findings, each once.
import { getSetting, setSetting, dateStr, addDays } from './core.js';
import { notify, verifyRules } from '../modules/verify/service.js';
import { orderAlerts } from '../modules/inventory/schedules.js';
import { runWatchdog } from './watchdog.js';

const OWNER = { name: 'Easy Buys', role: 'owner', uid: 'system' };
function sentMap() { try { return JSON.parse(getSetting('viber_auto_sent', '') || '{}') || {}; } catch (e) { return {}; } }

export function autoViberAlerts({ isMain, today = dateStr(), now } = {}) {
  const r = verifyRules();
  if (!isMain || r.viberMode !== 'channel') return [];
  const sent = sentMap();
  Object.keys(sent).forEach((k) => { if (sent[k] < addDays(today, -14)) delete sent[k]; });
  const out = [];
  const send = (id, event, text, shopCode) => {
    if (sent[id]) return;
    const msg = notify(event, text, { shopCode });
    if (msg) { sent[id] = today; out.push(msg); }
  };
  let orders = [];
  try { orders = orderAlerts(OWNER, now ? { now } : {}); } catch (e) { orders = []; }
  orders.forEach((a) => send(`${a.id}`, 'order_due', a.text));
  let wd = [];
  try { wd = runWatchdog(OWNER).filter((x) => x.level === 'urgent'); } catch (e) { wd = []; }
  wd.forEach((x) => send(`wd:${x.id}`, 'watchdog_urgent', `${x.text} – ${x.todo}`));
  setSetting('viber_auto_sent', JSON.stringify(sent));
  return out;
}
