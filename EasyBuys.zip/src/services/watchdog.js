// Watchdog (works offline, no outside service): looks for things that are missing, problems with the system, and signs
// that records were changed in ways they should not be. Every finding says why it matters, what to do and where.
// Main switch + strength (Off / Light / Normal / Strict) and per-check switches, set by the owner / admin.
// Tampering and system-health checks keep running for the owner even when the watchdog is off.
import { db } from '../db/connection.js';
import { AppError, getShared, setShared, getSetting, setSetting, audit, stamp, dateStr, addDays, money } from './core.js';
import { actsAsOwner, can } from './access.js';
import { sha256Text } from './sha256.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const safe = (f, d = []) => { try { return f(); } catch (e) { return d; } };
const has = (t) => !!safe(() => db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]), null);

export const STRENGTHS = [{ value: 'off', label: 'Off' }, { value: 'light', label: 'Light' }, { value: 'normal', label: 'Normal' }, { value: 'strict', label: 'Strict' }];
// Per strength: [light, normal, strict]
const T = (light, normal, strict) => ({ light, normal, strict });
const LIMITS = {
  depositDays: T(4, 2, 1),
  photoDays: T(30, 60, 120),
  voidsPerWeek: T(10, 5, 2),
  errorsPerDay: T(10, 3, 1),
  backdateHours: T(96, 48, 12),
  oddFrom: T(0, 23, 22),
  oddTo: T(4, 5, 6),
};

export const CHECKS = [
  { id: 'till_missing', group: 'complete', label: 'Till counts missing' },
  { id: 'deposit_overdue', group: 'complete', label: 'Cash not banked' },
  { id: 'invoice_photo', group: 'complete', label: 'Invoices without a photo' },
  { id: 'supplier_tin', group: 'complete', label: 'VAT suppliers without a TIN' },
  { id: 'timesheet_unchecked', group: 'complete', label: "Last week's timesheets not checked" },
  { id: 'clock_open', group: 'complete', label: 'Clocked in for too long (forgot to clock out)' },
  { id: 'returns_changed', group: 'complete', label: 'VAT / FNPF lodged, then the figures changed' },
  { id: 'cheque_uncovered', group: 'complete', label: 'Cheques handed over or post-dated with no deposit behind them' },
  { id: 'till_over_open', group: 'complete', label: 'Till over not decided for a week' },
  { id: 'part_paid_old', group: 'complete', label: 'Invoices part paid for over 30 days' },
  { id: 'receipt_unrecorded', group: 'complete', label: 'Receipts "already paid" with no payment recorded' },
  { id: 'device_conflicts', group: 'complete', label: 'Two devices did the same thing (paid twice, same cheque…)' },
  { id: 'sync', group: 'health', label: 'Device not synced' },
  { id: 'backup', group: 'health', label: 'Safety copy too old' },
  { id: 'errors', group: 'health', label: 'Problems in the app' },
  { id: 'history_chain', group: 'tamper', label: 'Change history altered' },
  { id: 'odd_hours', group: 'tamper', label: 'Changes at odd hours' },
  { id: 'own_punches', group: 'tamper', label: 'People adding their own clock times' },
  { id: 'backdated', group: 'tamper', label: 'Clock times added long after' },
  { id: 'supplier_bank', group: 'tamper', label: 'Supplier bank details changed' },
  { id: 'many_voids', group: 'tamper', label: 'Many voids / cancellations' },
];
export const GROUP_LABEL = { complete: 'Missing or not done', health: 'System health', tamper: 'Possible tampering (owner only)' };

export function watchdogSettings() {
  const s = getShared('watchdog', {}) || {};
  const strength = STRENGTHS.some((x) => x.value === s.strength) ? s.strength : 'normal';
  const checks = {};
  CHECKS.forEach((c) => { checks[c.id] = !(s.checks && s.checks[c.id] === false); });
  return { on: s.on !== false && strength !== 'off', strength, checks };
}
export function saveWatchdogSettings(user, { on, strength, checks }) {
  need(actsAsOwner(user) || (user && user.role === 'admin'), 'Only the owner or admin can change the watchdog.');
  need(STRENGTHS.some((x) => x.value === strength), 'Choose how strict the watchdog is.');
  const before = watchdogSettings();
  const clean = { on: !!on, strength, checks: Object.fromEntries(CHECKS.map((c) => [c.id, !(checks && checks[c.id] === false)])) };
  setShared('watchdog', clean);
  audit({ user, action: `Watchdog ${clean.on ? `on (${strength})` : 'turned OFF'}`, table: 'shared_settings', recordUid: 'watchdog', before, after: clean });
  return watchdogSettings();
}
const lim = (k, s) => LIMITS[k][s === 'off' ? 'normal' : s];

// ---------------------------------------------------------------- the checks
function f(check, id, level, text, why, todo, nav, who) { return { check, id: `${check}:${id}`, level, text, why, todo, nav: nav || null, who: who || 'Manager' }; }

const RUN = {
  // v3.9.2 checks
  cheque_uncovered: ({ today }) => {
    if (!has('cheque_cover')) return [];
    const CV = require('../modules/payables/cover.js');
    return safe(() => CV.openCheques({ today })).filter((c) => c.level === 'urgent')
      .map((c) => f('cheque_uncovered', c.uid, 'urgent', `Cheque ${c.no} to ${c.payee || '?'} (${c.left.toFixed(2)}) has no deposit behind it`, c.state === 'post_dated' ? `It is dated ${c.date} – the bank can pay it now.` : `It was handed over on ${c.handed} and can reach the bank any day.`, 'Make a deposit and tick this cheque on the deposit screen – or hold the cheque back.', { screen: 'ChequeCover', params: {} }, 'Owner'));
  },
  till_over_open: ({ today }) => {
    if (!has('till_surplus')) return [];
    return safe(() => db().all("SELECT * FROM till_surplus WHERE status = 'open' AND shift_date <= ?", [addDays(today, -7)]))
      .map((o) => f('till_over_open', o.uid, 'warning', `Till over ${Number(o.amount).toFixed(2)} (${o.name}, ${o.shift_date}) not decided for a week`, 'Extra cash in a till should be explained.', 'Keep it, set it against a shortage of the same cashier, or record that it was given back.', { screen: 'TillShortages', params: {} }));
  },
  // v3.9 checks
  returns_changed: ({ today }) => {
    if (!has('tax_return_versions')) return [];
    const RT = require('../modules/payroll/returns.js');
    return safe(() => db().all("SELECT DISTINCT kind, period FROM tax_return_versions WHERE status = 'lodged' AND period >= ?", [addDays(today, -400).slice(0, 7)]))
      .map((v) => ({ v, st: safe(() => RT.returnStatus(v.kind, v.period, { today })) }))
      .filter((x) => x.st && x.st.flags && x.st.flags.some((fl) => fl.key === 'changed'))
      .map(({ v, st }) => f('returns_changed', `${v.kind}-${v.period}`, 'urgent', `${v.kind === 'vat' ? 'VAT return' : 'FNPF schedule'} ${v.period}: the figures changed by ${st.changed} after it was lodged`, 'What was lodged no longer matches the records – FRCS / FNPF have the old figures.', 'Check what changed, then lodge an amended return and record it (version 2).', { screen: 'TaxReturn', params: { kind: v.kind, period: v.period } }, 'Owner'));
  },
  part_paid_old: ({ today }) => {
    if (!has('ap_invoices')) return [];
    const AP = require('../modules/payables/service.js');
    return safe(() => AP.listInvoices({ filter: 'part' })).filter((i) => i.invoice_date <= addDays(today, -30))
      .map((i) => f('part_paid_old', i.uid, 'warning', `${i.supplier_name} ${i.invoice_no || ''}: part paid, ${i.owing} still owing since ${i.invoice_date}`, 'A part payment was made and the rest has not followed.', 'Pay the rest, or agree it with the supplier (credit note).', { screen: 'ApInvoice', params: { uid: i.uid } }, 'Office'));
  },
  receipt_unrecorded: () => {
    if (!has('ap_invoices')) return [];
    return safe(() => db().all(`SELECT i.uid, i.invoice_no, i.supplier_name, i.total FROM ap_invoices i WHERE i.status <> 'void' AND i.notes LIKE '%RECEIPT – already paid%'
      AND NOT EXISTS (SELECT 1 FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = i.uid)`))
      .map((i) => f('receipt_unrecorded', i.uid, 'warning', `${i.supplier_name} ${i.invoice_no || ''}: receipt says paid, but no payment is recorded`, 'The money went out but the books do not show it – the cash or bank will look short.', 'Record the payment on the invoice (how it was paid is in the note).', { screen: 'ApInvoice', params: { uid: i.uid } }, 'Office'));
  },
  device_conflicts: () => safe(() => require('./conflicts.js').syncConflicts()).map((c) => f('device_conflicts', `${c.kind}-${c.text.slice(0, 40)}`, 'urgent', c.text, 'Two devices worked offline and both did it.', c.sub, c.nav, 'Owner')),
  till_missing: ({ today }) => {
    if (!has('till_counts') || !has('tills')) return [];
    const y = addDays(today, -1);
    const shops = safe(() => db().all("SELECT DISTINCT shop_code FROM tills WHERE active = 1"));
    return shops.filter((s) => !db().get("SELECT 1 AS x FROM till_counts WHERE shop_code = ? AND shift_date = ? AND status <> 'void'", [s.shop_code, y]))
      .map((s) => f('till_missing', `${s.shop_code}-${y}`, 'warning', `No till count for ${s.shop_code} on ${y}`, 'Without a till count, cash differences and Aronium sales cannot be checked.', 'Count the till for that day (Till & cash › Count a till), or note why there was none.', { screen: 'TillCount', params: { shopCode: s.shop_code } }, 'Shop supervisor'));
  },
  deposit_overdue: ({ strength, today }) => {
    if (!has('deposits') || !has('till_counts')) return [];
    const days = lim('depositDays', strength);
    const shops = safe(() => db().all("SELECT DISTINCT shop_code FROM till_counts WHERE status <> 'void'"));
    const out = [];
    shops.forEach((s) => {
      const last = db().get("SELECT MAX(deposit_date) AS d FROM deposits WHERE shop_code = ? AND status <> 'void'", [s.shop_code]).d || '0000-00-00';
      const cash = db().get("SELECT COALESCE(SUM(cash_counted - COALESCE(float_kept,0)),0) AS c, MIN(shift_date) AS first FROM till_counts WHERE shop_code = ? AND status <> 'void' AND shift_date > ?", [s.shop_code, last]);
      if (cash.c > 50 && cash.first && cash.first <= addDays(today, -days)) out.push(f('deposit_overdue', `${s.shop_code}-${last}`, 'warning', `${s.shop_code}: about ${money(cash.c)} of cash not banked since ${cash.first}`, 'Cash kept in the shop for days is easy to lose and hard to check.', 'Bank it (Till & cash › Bank deposit) with a photo of the slip.', { screen: 'Deposit', params: { shopCode: s.shop_code } }, 'Shop manager'));
    });
    return out;
  },
  invoice_photo: ({ strength, today }) => {
    if (!has('ap_invoices')) return [];
    const since = addDays(today, -lim('photoDays', strength));
    const rows = safe(() => db().all("SELECT uid, supplier_name, invoice_no, invoice_date FROM ap_invoices WHERE status <> 'void' AND invoice_date >= ? AND (photo_urls IS NULL OR photo_urls = '' OR photo_urls = '[]') ORDER BY invoice_date DESC LIMIT 20", [since]));
    return rows.map((r) => f('invoice_photo', r.uid, 'info', `Invoice ${r.invoice_no || ''} from ${r.supplier_name} (${r.invoice_date}) has no photo`, 'FRCS needs the invoice to claim the VAT back, and the accountant checks against it.', 'Open the invoice and add the photo.', { screen: 'ApInvoice', params: { uid: r.uid } }, 'Whoever entered it'));
  },
  supplier_tin: () => {
    if (!has('ap_suppliers')) return [];
    return safe(() => db().all("SELECT uid, name FROM ap_suppliers WHERE active = 1 AND vat_registered = 1 AND (tin IS NULL OR trim(tin) = '')")).map((r) => f('supplier_tin', r.uid, 'info', `${r.name} is VAT registered but has no TIN`, 'The VAT return needs each supplier\'s TIN.', 'Add the TIN in Suppliers.', { screen: 'ApSuppliers', params: {} }, 'Office'));
  },
  timesheet_unchecked: ({ today }) => {
    if (!has('punches') || !has('timesheet_checks')) return [];
    const d = new Date(`${today}T00:00:00`);
    const lastWeekEnd = addDays(today, -((d.getDay() + 1) % 7) - 1); // the Friday before (week Sat–Fri)
    const lastWeekStart = addDays(lastWeekEnd, -6);
    const people = safe(() => db().all("SELECT DISTINCT user_uid, name FROM punches WHERE voided = 0 AND substr(at,1,10) BETWEEN ? AND ?", [lastWeekStart, lastWeekEnd]));
    const open = people.filter((p) => !db().get("SELECT 1 AS x FROM timesheet_checks WHERE user_uid = ? AND week_start = ? AND status = 'checked'", [p.user_uid, lastWeekStart]));
    return open.length ? [f('timesheet_unchecked', lastWeekStart, 'warning', `${open.length} timesheet(s) for the week of ${lastWeekStart} not checked`, 'Pay is worked out from the hours – unchecked hours can mean paying too much or too little.', `Check: ${open.slice(0, 6).map((p) => p.name).join(', ')}${open.length > 6 ? '…' : ''}`, { screen: 'Timesheets', params: { date: lastWeekStart } }, 'Manager / payroll')] : [];
  },
  clock_open: ({ now }) => {
    if (!has('punches')) return [];
    const rows = safe(() => db().all(`SELECT p.user_uid, p.name, MAX(p.at) AS at FROM punches p WHERE p.voided = 0 GROUP BY p.user_uid`));
    return rows.filter((r) => {
      const last = db().get('SELECT type FROM punches WHERE user_uid = ? AND voided = 0 AND at = ?', [r.user_uid, r.at]);
      const hours = (new Date(now.replace(' ', 'T')) - new Date(String(r.at).replace(' ', 'T'))) / 3600000;
      return last && last.type !== 'OUT' && hours > 14 && hours < 24 * 7;
    }).map((r) => f('clock_open', `${r.user_uid}-${r.at}`, 'warning', `${r.name} clocked in at ${String(r.at).slice(0, 16)} and never clocked out`, 'Missing clock-outs make the timesheet and pay wrong.', 'Add the clock-out time with a reason (Timesheets › that person).', { screen: 'TimesheetPerson', params: { userUid: r.user_uid, date: String(r.at).slice(0, 10) } }, 'Manager'));
  },
  sync: ({ now }) => {
    if (!getSetting('cloud_url', '')) return [];
    const ok = getSetting('last_sync_ok_at', '');
    const hours = ok ? (new Date(now.replace(' ', 'T')) - new Date(ok.replace(' ', 'T'))) / 3600000 : 999;
    return hours > 6 ? [f('sync', dateStr(), hours > 24 ? 'urgent' : 'warning', ok ? `This device last synced ${Math.round(hours)} hours ago` : 'This device has never synced', 'Records made here are not in the cloud or on the other devices yet.', 'Check the internet and tap the sync light. Admin › Sync shows what is waiting.', { screen: 'SyncStatus', params: {} }, 'Owner / admin')] : [];
  },
  backup: ({ now }) => {
    const at = getSetting('last_snapshot_at', '');
    const hours = at ? (new Date(now.replace(' ', 'T')) - new Date(at.replace(' ', 'T'))) / 3600000 : 999;
    return hours > 48 ? [f('backup', dateStr(), 'warning', at ? `The last safety copy on this device is ${Math.round(hours / 24)} days old` : 'No safety copy on this device yet', 'If the tablet breaks, recent work could be lost.', 'Admin › Backup & restore › Make a copy now.', { screen: 'Backup', params: {} }, 'Owner / admin')] : [];
  },
  errors: ({ strength, now }) => {
    const since = addDays(now.slice(0, 10), -1);
    const n = safe(() => db().get("SELECT COUNT(*) AS n FROM audit_log WHERE action IN ('app_error','app_closed') AND at >= ?", [since]).n, 0);
    return n >= lim('errorsPerDay', strength) ? [f('errors', now.slice(0, 10), 'warning', `${n} problems in the app since yesterday`, 'Repeated problems can mean a screen is not working for someone.', 'Admin › Problem log – send it to support if it keeps happening.', { screen: 'Problems', params: {} }, 'Owner / admin')] : [];
  },
  history_chain: () => {
    const r = verifyChain();
    return r.ok ? [] : [f('history_chain', r.at || 'x', 'urgent', 'The change history on this device was altered', r.message, 'Compare with another device and the cloud copy. If you restored a backup on purpose, tap "This is fine".', { screen: 'Audit', params: {} }, 'Owner')];
  },
  odd_hours: ({ strength, today }) => {
    const from = lim('oddFrom', strength); const to = lim('oddTo', strength);
    const rows = safe(() => db().all(`SELECT a.user_name, COUNT(*) AS n, MIN(a.at) AS first FROM audit_log a LEFT JOIN users u ON u.uid = a.user_uid
      WHERE a.at >= ? AND a.user_name IS NOT NULL AND COALESCE(u.role,'') NOT IN ('owner','admin') AND a.action NOT IN ('app_error','app_closed')
      AND (CAST(substr(a.at,12,2) AS INTEGER) >= ? OR CAST(substr(a.at,12,2) AS INTEGER) < ?) GROUP BY a.user_name`, [addDays(today, -7), from || 24, to]));
    return rows.map((r) => f('odd_hours', `${r.user_name}-${today}`, 'warning', `${r.user_name} made ${r.n} change(s) between ${from}:00 and ${to}:00 this week`, 'Changes at night, when nobody else is around, are worth a look.', 'Open the change history for that person.', { screen: 'Audit', params: { q: r.user_name } }, 'Owner'));
  },
  own_punches: ({ today }) => {
    if (!has('punches')) return [];
    const rows = safe(() => db().all("SELECT uid, name, at, reason FROM punches WHERE voided = 0 AND created_by_uid = user_uid AND method NOT IN ('pin','pin+face') AND substr(at,1,10) >= ? ORDER BY at DESC LIMIT 20", [addDays(today, -14)]));
    return rows.map((r) => f('own_punches', r.uid, 'warning', `${r.name} added their own clock time (${String(r.at).slice(0, 16)})`, 'People should not fix their own hours – it is how hours get padded.', 'Check it with the manager; void it if it is wrong.', { screen: 'Timesheets', params: {} }, 'Owner'));
  },
  backdated: ({ strength, today }) => {
    if (!has('punches')) return [];
    const h = lim('backdateHours', strength);
    const rows = safe(() => db().all("SELECT p.uid, p.name, p.at, p.recorded_at, p.created_by_uid FROM punches p LEFT JOIN users u ON u.uid = p.created_by_uid WHERE p.voided = 0 AND p.created_by_uid IS NOT NULL AND COALESCE(u.role,'') NOT IN ('owner','admin') AND substr(p.recorded_at,1,10) >= ? ORDER BY p.recorded_at DESC LIMIT 50", [addDays(today, -14)]));
    return rows.filter((r) => (new Date(String(r.recorded_at).replace(' ', 'T')) - new Date(String(r.at).replace(' ', 'T'))) / 3600000 > h)
      .slice(0, 10).map((r) => f('backdated', r.uid, 'info', `A clock time for ${r.name} (${String(r.at).slice(0, 16)}) was added on ${String(r.recorded_at).slice(0, 16)}`, 'Times added days later are hard to check.', 'Make sure the reason makes sense.', { screen: 'TimesheetPerson', params: { date: String(r.at).slice(0, 10) } }, 'Owner'));
  },
  supplier_bank: ({ today }) => {
    const rows = safe(() => db().all("SELECT uid, at, user_name, action FROM audit_log WHERE table_name = 'ap_suppliers' AND at >= ? AND (after LIKE '%bank%' OR action LIKE '%bank%') ORDER BY at DESC LIMIT 10", [addDays(today, -30)]));
    return rows.map((r) => f('supplier_bank', r.uid, 'urgent', `Supplier bank details changed by ${r.user_name || 'someone'} (${String(r.at).slice(0, 16)})`, 'Changing a supplier\'s bank account is a common way to steal a payment.', 'Phone the supplier on a number you already know to confirm the new account before paying.', { screen: 'ApSuppliers', params: {} }, 'Owner'));
  },
  many_voids: ({ strength, today }) => {
    const rows = safe(() => db().all("SELECT user_name, COUNT(*) AS n FROM audit_log WHERE at >= ? AND (action LIKE 'Void%' OR action LIKE '%voided%' OR action LIKE 'Cancel%') AND user_name IS NOT NULL GROUP BY user_name", [addDays(today, -7)]));
    return rows.filter((r) => r.n >= lim('voidsPerWeek', strength)).map((r) => f('many_voids', `${r.user_name}-${today}`, 'warning', `${r.user_name} voided or cancelled ${r.n} things this week`, 'Many voids can hide mistakes or taking money.', 'Look through them in the change history.', { screen: 'Audit', params: { q: r.user_name } }, 'Owner'));
  },
};

// ---------------------------------------------------------------- chained fingerprint of the change history
// Each row's fingerprint includes the one before it, so changing or removing an old entry breaks the chain.
function chainOver(limitRowid) {
  let h = '';
  let n = 0;
  let last = 0;
  const rows = db().all('SELECT rowid AS rid, uid, at, action, user_name, record_uid, reason FROM audit_log WHERE rowid <= ? ORDER BY rowid', [limitRowid]);
  for (const r of rows) { h = sha256Text(`${h}|${r.uid}|${r.at}|${r.action}|${r.user_name || ''}|${r.record_uid || ''}|${r.reason || ''}`); n += 1; last = r.rid; }
  return { hash: h, count: n, last };
}
// Quick check (counts, every time) and the full fingerprint check once a day – it reads the whole history.
export function verifyChain({ full = false } = {}) {
  const cp = (() => { try { return JSON.parse(getSetting('audit_chain', '') || 'null'); } catch (e) { return null; } })();
  const bad = (() => { try { return JSON.parse(getSetting('audit_chain_bad', '') || 'null'); } catch (e) { return null; } })();
  if (bad) return { ok: false, at: bad.at, message: bad.message };
  if (cp && !full && String(cp.at).slice(0, 10) === dateStr()) {
    const n = safe(() => db().get('SELECT COUNT(*) AS n FROM audit_log WHERE rowid <= ?', [cp.upto]).n, cp.count);
    return n === cp.count ? { ok: true, quick: true } : markBad({ ok: false, at: cp.at, message: `${cp.count - n} older entries are missing since ${String(cp.at).slice(0, 16)}. Records should never disappear from the change history.` });
  }
  const maxRow = safe(() => db().get('SELECT MAX(rowid) AS m FROM audit_log').m || 0, 0);
  if (!cp) { const c = chainOver(maxRow); setSetting('audit_chain', JSON.stringify({ upto: c.last, hash: c.hash, count: c.count, at: stamp() })); return { ok: true, first: true }; }
  const c = chainOver(cp.upto);
  if (c.count !== cp.count || c.hash !== cp.hash) return markBad({ ok: false, at: cp.at, message: `${cp.count - c.count > 0 ? `${cp.count - c.count} older entries are missing` : 'Older entries were changed'} since ${String(cp.at).slice(0, 16)}. Records should never disappear from the change history.` });
  const next = chainOver(maxRow);
  setSetting('audit_chain', JSON.stringify({ upto: next.last, hash: next.hash, count: next.count, at: stamp() }));
  return { ok: true };
}
function markBad(r) { setSetting('audit_chain_bad', JSON.stringify({ at: r.at, message: r.message })); return r; }
export function resetChain(user) { setSetting('audit_chain_bad', ''); setSetting('audit_chain', ''); verifyChain(); audit({ user, action: 'Watchdog: change history check started again', table: 'settings' }); }

// ---------------------------------------------------------------- run, acknowledge
function acks() { return getShared('watchdog_acks', {}) || {}; }
export function runWatchdog(user, { now = stamp(), includeAcked = false } = {}) {
  const s = watchdogSettings();
  const owner = actsAsOwner(user);
  const ctx = { strength: s.strength === 'off' ? 'normal' : s.strength, today: now.slice(0, 10), now };
  const out = [];
  for (const c of CHECKS) {
    const alwaysForOwner = owner && (c.group === 'tamper' || c.group === 'health');
    if (!s.checks[c.id] && !alwaysForOwner) continue;
    if (!s.on && !alwaysForOwner) continue;
    if (c.group === 'tamper' && !owner) continue;
    if (c.group === 'health' && !(owner || can(user, 'settings'))) continue;
    for (const x of safe(() => RUN[c.id](ctx))) out.push({ ...x, group: c.group, checkLabel: c.label });
  }
  const a = acks();
  return out.filter((x) => includeAcked || !a[x.id]).map((x) => ({ ...x, ack: a[x.id] || null }));
}
export function ackFinding(user, id, kind) {
  need(['fixed', 'fine'].includes(kind), 'Fixed or This is fine?');
  const a = acks();
  a[id] = { kind, by: user ? user.name : '', at: stamp() };
  // Keep it short: forget answers older than 90 days.
  Object.keys(a).forEach((k) => { if (a[k].at < addDays(dateStr(), -90)) delete a[k]; });
  setShared('watchdog_acks', a);
  if (id.startsWith('history_chain:') && kind === 'fine') resetChain(user);
  audit({ user, action: `Watchdog: "${id.split(':')[0]}" marked ${kind === 'fixed' ? 'fixed' : 'fine'}`, table: 'shared_settings', recordUid: 'watchdog_acks' });
}
export function watchdogSummary(user) {
  const s = watchdogSettings();
  const list = runWatchdog(user);
  return { on: s.on, strength: s.strength, total: list.length, urgent: list.filter((x) => x.level === 'urgent').length, list };
}
