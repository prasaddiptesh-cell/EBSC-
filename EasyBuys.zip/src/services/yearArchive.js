// v3.9 Year end: check the year is complete, close the books (lock to 31 December and keep the profit in the
// business), then keep a complete copy of the business as it was at the year end – in Google Drive › Backups ›
// Manual (never pruned; FRCS wants records kept 7 years) and on this device. The records stay in the app, so any old
// invoice, payslip or report can still be opened; nothing is deleted. (Taking closed years off the tablets is only
// worth doing after several years – a year of Easy Buys is about 12 MB and the app stays quick, tested on a year.)
import { db } from '../db/connection.js';
import { AppError, stamp, dateStr, audit, getShared, setShared, money } from './core.js';
import { actsAsOwner } from './access.js';
import { enqueue } from './stock.js';
import { requirePerm, asService } from './guard.js';

const need = (c, m) => { if (!c) throw new AppError(m); };
const has = (t) => { try { return !!db().get("SELECT 1 AS x FROM sqlite_master WHERE type = 'table' AND name = ?", [t]); } catch (e) { return false; } };
const pad = (n) => String(n).padStart(2, '0');

// What must be right before a year is closed: [{ key, ok, text, warn? }]
export function yearChecks(year) {
  const y = Number(year);
  const end = `${y}-12-31`;
  const out = [];
  const add = (key, ok, text, warn = false) => out.push({ key, ok: !!ok, text, warn });
  try {
    const A = require('../modules/accounting/service.js');
    const tb = A.trialBalance(end);
    add('books', tb.ok, tb.ok ? `The books balance at ${end}` : `The books do not balance at ${end} (debits ${money(tb.dr)}, credits ${money(tb.cr)})`);
  } catch (e) { add('books', false, 'The books could not be worked out'); }
  try {
    const TX = require('../modules/payroll/taxCalendar.js');
    // Only the months the app was in use count (from the go-live date).
    let from = `${y}-01`;
    try { const gl = require('../modules/accounting/full.js').acctSettings().goLive; if (gl && gl.slice(0, 7) > from) from = gl.slice(0, 7); } catch (e) { /* not set */ }
    for (const kind of ['vat', 'fnpf']) {
      const open = [];
      for (let m = 1; m <= 12; m++) {
        const ym = `${y}-${pad(m)}`;
        if (`${ym}-01` > dateStr() || ym < from) continue;
        const it = TX.getTaxItem(kind, ym);
        const nothing = kind === 'fnpf' && !(it.amount > 0) && !it.lodged;
        if (!it.done && !nothing) open.push(ym.slice(5));
      }
      add(kind, !open.length, open.length ? `${kind === 'vat' ? 'VAT returns' : 'FNPF schedules'} not lodged and paid with proof: month ${open.join(', ')}` : `${kind === 'vat' ? 'Every VAT return' : 'Every FNPF schedule'} of ${y} lodged and paid`);
    }
  } catch (e) { add('returns', false, 'The tax calendar could not be checked', true); }
  try {
    const S = require('../modules/payroll/statutory.js');
    const ye = S.yearEnd(y);
    add('paye', Math.abs(ye.payeDiff) < 0.05 && Math.abs(ye.fnpfDiff) < 0.05, Math.abs(ye.payeDiff) < 0.05 && Math.abs(ye.fnpfDiff) < 0.05 ? 'PAYE and FNPF paid = what the pay runs took' : `Year-end PAYE / FNPF differ from the payments: PAYE ${money(ye.payeDiff)}, FNPF ${money(ye.fnpfDiff)}`, true);
  } catch (e) { /* no payroll */ }
  if (has('inv_counts')) {
    const n = db().get("SELECT COUNT(*) AS n FROM inv_counts WHERE status = 'posted' AND count_date BETWEEN ? AND ?", [`${y}-12-01`, `${y + 1}-01-15`]);
    add('stock', n && n.n > 0, n && n.n > 0 ? 'A stock count was done at the year end' : 'No stock count around 31 December – the year-end stock figure is not proven', true);
  }
  try {
    const pend = require('./records.js').pendingBySection();
    const waiting = Object.values(pend).reduce((a, b) => a + b, 0);
    add('sync', !waiting, waiting ? `${waiting} change(s) still waiting to sync – press Sync now first` : 'Everything is synced');
  } catch (e) { /* not linked */ }
  try {
    const c = require('./conflicts.js').syncConflicts();
    add('conflicts', !c.length, c.length ? `${c.length} problem(s) between devices to sort out first (paid twice, same cheque…)` : 'No problems between devices');
  } catch (e) { /* none */ }
  return out;
}
export function archives() { return getShared('year_archives', {}) || {}; }
// Close the year and make the archive copy. Owner only. Problems stop it unless the owner goes ahead anyway.
export async function closeAndArchive(user, year, { force = false } = {}) {
  requirePerm(user, 'accounts_close', { money: true }); // 1.0.0 hardening (H1): checked inside the service
  return asService(async () => {
  need(user && (actsAsOwner(user) || user.role === 'owner'), 'Only the owner closes and archives a year.');
  const y = Number(year);
  need(Number.isInteger(y) && y > 2000 && `${y}-12-31` < dateStr(), 'Choose a year that has ended.');
  const checks = yearChecks(y);
  const bad = checks.filter((c) => !c.ok && !c.warn);
  need(!bad.length || force, `Not ready: ${bad.map((c) => c.text).join('; ')}`);
  const A = require('../modules/accounting/service.js');
  const F = require('../modules/accounting/full.js');
  const lock = require('./lock.js').lockDate();
  if (!lock || lock < `${y}-12-31`) A.setLock(user, `${y}-12-31`);
  const closed = F.closeYear(user, y);
  const tb = A.trialBalance(`${y}-12-31`);
  const counts = {};
  db().all("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").forEach((t) => { try { counts[t.name] = db().get(`SELECT COUNT(*) AS n FROM ${t.name}`).n; } catch (e) { /* skip */ } });
  const meta = { kind: 'year-archive', year: y, made: stamp(), by: user.name, profit: closed.profit, trialBalance: { dr: tb.dr, cr: tb.cr }, counts, checks };
  const date = dateStr();
  const fileName = `archive-${y}-${date}.json`;
  // In Google Drive (kept – the Manual backups are never pruned) and as a safety copy on this device.
  enqueue('archive', { year: y, date, fileName, meta });
  try { await require('./snapshots.js').snapshotNow(`year-${y}`); } catch (e) { /* the Drive copy is still made */ }
  setShared('year_archives', { ...archives(), [y]: { at: stamp(), by: user.name, fileName, profit: closed.profit, status: 'waiting for the cloud' } });
  audit({ user, action: `Year ${y} closed and archived (${fileName})${force ? ' – with problems, the owner went ahead' : ''}`, table: 'gl_year_close', recordUid: String(y) });
  return { year: y, fileName, profit: closed.profit, checks };
  });
}
// Called by the cloud sync when Drive has the archive.
export function archiveSent(year, info = {}) {
  const a = archives();
  if (a[year]) setShared('year_archives', { ...a, [year]: { ...a[year], status: 'in Google Drive', driveId: info.id || null, sentAt: stamp() } });
}
