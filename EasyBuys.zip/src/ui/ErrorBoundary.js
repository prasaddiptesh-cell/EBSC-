// Catches a problem on one screen so the app does not close: shows what went wrong and a way back.
import React from 'react';
import { View, ScrollView, Pressable, Share } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { logError, problemReport } from '../services/errorLog.js';

export class ScreenGuard extends React.Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error, info) {
    const e = error || new Error('Unknown');
    // 1.0.0 build 6: the JS stack and the screen's parts (component stack) are kept apart in the problem log
    logError(e, { where: 'screen', screen: this.props.name, componentStack: (info && info.componentStack) || '' });
    if (this.props.onError) this.props.onError(this.props.name, e);
  }
  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const btn = (label, onPress, color, testID) => (
      <Pressable testID={testID} onPress={onPress} style={{ backgroundColor: color, paddingVertical: 14, paddingHorizontal: 20, borderRadius: 12, marginTop: 12, alignItems: 'center' }}>
        <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>{label}</Text>
      </Pressable>
    );
    return (
      <ScrollView testID="screen-error" contentContainerStyle={{ padding: 28 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: C.danger }}>Something went wrong on this screen</Text>
        <Text style={{ fontSize: 17, color: C.text, marginTop: 10 }}>The app stayed open and nothing was lost. The problem has been written to the problem log (Settings › Problem log).</Text>
        <View style={{ backgroundColor: '#fff4f4', borderRadius: 10, padding: 12, marginTop: 14 }}>
          <Text style={{ fontSize: 15, color: C.text }}>Screen: {this.props.name}</Text>
          <Text style={{ fontSize: 15, color: C.danger, marginTop: 4 }}>{String((error && error.message) || error)}</Text>
        </View>
        {this.props.onBack ? btn('‹ Go back', () => this.props.onBack(), C.primary, 'error-back') : null}
        {this.props.onHome ? btn('Home', () => this.props.onHome(), C.info || C.primary, 'error-home') : null}
        {btn('Send problem report', () => { Promise.resolve(Share.share({ message: problemReport() })).catch(() => {}); }, C.sub || '#666', 'error-share')}
      </ScrollView>
    );
  }
}
