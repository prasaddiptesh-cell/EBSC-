// Release 07 (the new look) – the line icons of the approved design (24×24, stroke). On the website they are drawn as
// real SVG; on phones and tablets the emoji the app always had is shown instead (no extra library needed there).
import React from 'react';
import { Platform } from 'react-native';
import { Text } from './scale.js';

export const ICON_PATHS = {
  download: 'M12 4v12M6 10l6 6 6-6M4 20h16',
  alert: 'M12 9v4M12 17h.01M10.3 3.9L2 18a2 2 0 0 0 1.7 3h16.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
  today: 'M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  month: 'M4 5h16v15H4zM4 9h16M8 3v4M16 3v4',
  shop: 'M3 9l1.5-5h15L21 9M3 9h18v11H3zM9 20v-6h6v6',
  vat: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6',
  pay: 'M3 7h18v12H3zM16 13h2M3 7l3-3h12l3 3',
  staff: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  bank: 'M3 10l9-6 9 6M5 10v8M10 10v8M14 10v8M19 10v8M3 21h18',
  box: 'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10',
  book: 'M4 4h7v16H4zM13 4h7v16h-7',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12h2M3 12h2M12 3v2M12 19v2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4',
  invoice: 'M6 3h9l3 3v15H6zM9 13l3-3 3 3M12 10v7',
  cheque: 'M3 7h18v10H3zM6 14h6M15 11h3',
  truck: 'M3 7h11v9H3zM14 10h4l3 3v3h-7M7 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
  order: 'M6 3h12v18H6zM9 8h6M9 12h6M9 16h3',
  till: 'M4 4h16v6H4zM6 14h12v6H6zM8 7h2M14 17h2',
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5',
  sync: 'M20 12a8 8 0 0 1-14 5.3M4 12a8 8 0 0 1 14-5.3M18 3v4h-4M6 21v-4h4',
  help: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5v.5',
  link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
  bread: 'M5 10a7 4 0 0 1 14 0v9H5zM9 10v9M15 10v9',
  car: 'M5 16l1.5-6h11L19 16M3 16h18v3H3zM7 19v2M17 19v2',
  smoke: 'M3 15h14v3H3zM19 15v3M19 8c0 2-2 2-2 4M21 8c0 2-2 2-2 4',
  owed: 'M4 4h16v16H4zM8 9h8M8 13h8M8 17h4',
};

// The icon for a menu row (its hub id, or its target screen).
export function iconFor(id = '', screen = '') {
  const k = String(id || '');
  if (/^shop-/.test(k)) return 'shop';
  const map = { till: 'till', people: 'staff', papers: 'shop', tax: 'vat', vat: 'vat', payroll: 'pay', staff: 'staff', money: 'bank', bank: 'bank', suppliers: 'invoice', payables: 'invoice', stock: 'box', inventory: 'box',
    bakery: 'bread', aronium: 'link', cigarettes: 'smoke', assets: 'car', vehicles: 'car', books: 'book', accounting: 'book', owed: 'owed', trade: 'truck', reports: 'chart', settings: 'gear', sync: 'sync', help: 'help', today: 'today', month: 'month' };
  if (map[k]) return map[k];
  if (/Shop/.test(screen)) return 'shop';
  return 'box';
}

export default function Icon({ name, size = 18, color = 'currentColor', emoji = '•', strokeWidth = 1.8 }) {
  const d = ICON_PATHS[name];
  if (Platform.OS !== 'web' || !d) return <Text style={{ fontSize: size - 1, width: size + 6, textAlign: 'center' }}>{emoji}</Text>;
  return React.createElement('svg', { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true', style: { flexShrink: 0, display: 'block' } },
    React.createElement('path', { d }));
}
