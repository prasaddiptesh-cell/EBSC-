// 1.0.0 hardening (Fiji time): a red bar across the top while this phone is not on Fiji time or its clock is more
// than 5 minutes off the cloud's. Clock-ins, till counts, invoices, cheques and money records are refused meanwhile
// (core.assertTimeOk); the cloud's security log is told with the next sync (deviceStat: tz and clock difference).
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Text } from './scale.js';
import { timeTrouble } from '../services/core.js';

export default function TimeGuardBanner() {
  const [t, setT] = useState(() => { try { return timeTrouble(); } catch (e) { return null; } });
  useEffect(() => {
    const id = setInterval(() => { try { setT(timeTrouble()); } catch (e) { setT(null); } }, 20000);
    return () => clearInterval(id);
  }, []);
  if (!t) return null;
  return (
    <View testID="time-guard" style={{ backgroundColor: '#B3261E', paddingVertical: 10, paddingHorizontal: 14 }}>
      <Text style={{ color: '#fff', fontSize: 17, fontWeight: '900' }}>{`⛔ ${t.text}`}</Text>
      <Text style={{ color: '#fff', fontSize: 14, marginTop: 4 }}>{t.sub}</Text>
    </View>
  );
}
