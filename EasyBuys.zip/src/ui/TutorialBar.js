// The floating guide for the app tour and the "Show me how" tutorials: one step at a time, the button to press gets a
// bright outline, and Close always ends it (it never blocks the app).
import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { setTourTarget } from './tourTarget.js';
import { getTutorial, markTourSeen } from '../services/tutorials.js';

let active = null;
const listeners = new Set();
const emit = () => listeners.forEach((fn) => { try { fn(active); } catch (e) { /* ignore */ } });
export function startTutorial(id) { if (!getTutorial(id)) return; active = { id, step: 0 }; emit(); }
export function stopTutorial() { active = null; setTourTarget(null); emit(); }
export function activeTutorial() { return active; }

export default function TutorialBar({ user, nav }) {
  const [a, setA] = useState(active);
  useEffect(() => { const fn = (x) => setA(x ? { ...x } : null); listeners.add(fn); return () => { listeners.delete(fn); }; }, []);
  const t = a ? getTutorial(a.id) : null;
  const step = t ? t.steps[a.step] : null;
  useEffect(() => { setTourTarget(step && step.testID ? step.testID : null); }, [a && a.id, a && a.step]);
  if (!t || !step) return null;
  const last = a.step >= t.steps.length - 1;
  const close = () => { if (t.id === 'tour') markTourSeen(user); stopTutorial(); };
  const next = () => {
    if (!last) { active = { ...a, step: a.step + 1 }; emit(); return; }
    if (t.id === 'tour') { markTourSeen(user); stopTutorial(); return; }
    stopTutorial();
    if (t.quiz && t.quiz.length && nav) nav.push('TutorialQuiz', { id: t.id });
  };
  const back = () => { if (a.step > 0) { active = { ...a, step: a.step - 1 }; emit(); } };
  return (
    <View testID="tutorial-bar" style={{ position: 'absolute', left: 12, right: 12, bottom: 16, alignItems: 'center' }} pointerEvents="box-none">
      <View style={{ maxWidth: 640, width: '100%', backgroundColor: '#1F2A44', borderRadius: 18, padding: 16, gap: 10, elevation: 8 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ flex: 1, color: '#FFD8B0', fontSize: 14, fontWeight: '800' }}>{t.title} · step {a.step + 1} of {t.steps.length}</Text>
          <Pressable testID="tutorial-close" onPress={close} hitSlop={12}><Text style={{ color: '#fff', fontSize: 20, fontWeight: '800' }}>✕</Text></Pressable>
        </View>
        <Text testID="tutorial-text" style={{ color: '#fff', fontSize: 18, lineHeight: 25 }}>{step.text}</Text>
        {step.testID ? <Text style={{ color: '#FFB27A', fontSize: 14 }}>The button to press has an orange outline.</Text> : null}
        <View style={{ flexDirection: 'row', gap: 10, justifyContent: 'flex-end' }}>
          {a.step > 0 ? <Pressable testID="tutorial-back" onPress={back} style={{ paddingVertical: 10, paddingHorizontal: 16, borderRadius: 12, borderWidth: 1, borderColor: '#fff' }}><Text style={{ color: '#fff', fontSize: 17, fontWeight: '700' }}>Back</Text></Pressable> : null}
          <Pressable testID="tutorial-next" onPress={next} style={{ paddingVertical: 10, paddingHorizontal: 20, borderRadius: 12, backgroundColor: '#FF6A00' }}>
            <Text style={{ color: '#fff', fontSize: 17, fontWeight: '800' }}>{last ? (t.quiz && t.quiz.length ? 'Quick check' : 'Finish') : 'Next'}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}
