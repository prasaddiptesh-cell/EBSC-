// 1.0.0 build 48: the website on a computer screen – the menu always on the left (Today, Records and its parts,
// Reports, Settings, the VAT month, Sync), the page on the right. Phones and tablets are unchanged.
import React, { useMemo } from 'react';
import { View, ScrollView, Pressable, Image, Platform, useWindowDimensions } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { LOGO } from './components.js';

export const SIDEBAR_MIN_WIDTH = 1100;
export function useSidebar() {
  const { width } = useWindowDimensions();
  return Platform.OS === 'web' && width >= SIDEBAR_MIN_WIDTH;
}

function Item({ icon, title, active, onPress, testID, sub }) {
  return (
    <Pressable testID={testID} onPress={onPress} accessibilityRole="link" style={({ pressed, hovered }) => ({
      flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: sub ? 40 : 44, paddingHorizontal: 12, borderRadius: 10, marginBottom: 2,
      backgroundColor: active ? C.primarySoft : hovered ? C.hover : 'transparent', opacity: pressed ? 0.7 : 1,
    })}>
      <Text style={{ fontSize: sub ? 16 : 17, width: 24, textAlign: 'center' }}>{icon}</Text>
      <Text style={{ fontSize: 15, fontWeight: active ? '700' : '500', color: active ? C.primaryText : C.text, flex: 1 }} numberOfLines={1}>{title}</Text>
    </Pressable>
  );
}

function Group({ children }) {
  return <Text style={{ fontSize: 12, fontWeight: '700', color: C.sub, marginTop: 18, marginBottom: 6, marginLeft: 12, letterSpacing: 0.8 }}>{children}</Text>;
}

export default function WebSidebar({ user, screens, nav, top, homeTab, setHomeTab, stackLength }) {
  const rows = useMemo(() => {
    try {
      const SM = require('../modules/home/shellModel.js');
      const R = require('../modules/registry.js');
      return SM.recordsRows(user, screens, R.getModule);
    } catch (e) { return []; }
  }, [user && user.uid, user && user.role, screens]);
  const onHome = stackLength <= 1;
  const tab = homeTab || 'today';
  const go = (target) => { nav.home(); if (target) setTimeout(() => nav.push(target.screen, target.params || {}), 0); };
  const goTab = (key) => { nav.home(); if (setHomeTab) setHomeTab(key); };
  const isTarget = (t) => !!top && t && top.name === t.screen && JSON.stringify(top.params || {}) === JSON.stringify(t.params || {});
  const has = (name) => !!(screens && screens[name]);
  return (
    <View style={{ width: 260, backgroundColor: C.white, borderRightWidth: 1, borderRightColor: C.border, borderTopWidth: 4, borderTopColor: C.brandRed }}>
      <View style={{ paddingTop: 18, paddingBottom: 14, paddingHorizontal: 18, borderBottomWidth: 1, borderBottomColor: C.border }}>
        <Image source={LOGO} style={{ width: 132, height: 52 }} resizeMode="contain" accessibilityLabel="Easy Buys" />
        {user ? <Text style={{ fontSize: 13, color: C.sub, marginTop: 8 }} numberOfLines={1}>{user.name}</Text> : null}
      </View>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingHorizontal: 12, paddingTop: 2, paddingBottom: 20 }}>
        <Group>MAIN</Group>
        <Item testID="side-today" icon="🏠" title="Today" active={onHome && tab === 'today'} onPress={() => goTab('today')} />
        {has('MonthRecords') ? <Item testID="side-month" icon="🗓️" title="Month records & VAT" active={!!top && top.name === 'MonthRecords'} onPress={() => go({ screen: 'MonthRecords' })} /> : null}
        <Group>RECORDS</Group>
        {rows.map((r) => <Item key={r.id} sub testID={`side-${r.id}`} icon={r.icon} title={r.title} active={isTarget(r.target)} onPress={() => go(r.target)} />)}
        <Group>MORE</Group>
        <Item testID="side-reports" icon="📊" title="Reports" active={onHome && tab === 'reports'} onPress={() => goTab('reports')} />
        <Item testID="side-settings" icon="⚙️" title="Settings" active={onHome && tab === 'settings'} onPress={() => goTab('settings')} />
        {has('SyncStatus') ? <Item testID="side-sync" icon="🔄" title="Sync status" active={!!top && top.name === 'SyncStatus'} onPress={() => go({ screen: 'SyncStatus' })} /> : null}
        {has('Help') ? <Item testID="side-help" icon="❓" title="Help" active={!!top && top.name === 'Help'} onPress={() => go({ screen: 'Help' })} /> : null}
      </ScrollView>
    </View>
  );
}
