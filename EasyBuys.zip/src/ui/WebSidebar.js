// 1.0.0 build 48: the website on a computer screen – the menu always on the left (Today, Records and its parts,
// Reports, Settings, the VAT month, Sync), the page on the right. Phones and tablets are unchanged.
import React, { useMemo } from 'react';
import { View, ScrollView, Pressable, Image, Platform, useWindowDimensions } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { LOGO } from './components.js';
import Icon, { iconFor } from './Icon.js';

export const SIDEBAR_MIN_WIDTH = 1100;
export function useSidebar() {
  const { width } = useWindowDimensions();
  return Platform.OS === 'web' && width >= SIDEBAR_MIN_WIDTH;
}

// Release 07 (the new look, as in the approved design): white menu, small grey group names, line icons, the page you are
// on in soft red, an amber badge where something needs you.
function Item({ icon, title, active, onPress, testID, badge }) {
  const color = active ? '#A81E23' : '#3D2F30';
  return (
    <Pressable testID={testID} onPress={onPress} accessibilityRole="link" style={({ pressed, hovered }) => ({
      flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 40, paddingHorizontal: 12, borderRadius: 8, marginBottom: 2,
      backgroundColor: active ? C.primarySoft : hovered ? C.bg : 'transparent', opacity: pressed ? 0.7 : 1,
    })}>
      <Icon name={icon.name} emoji={icon.emoji} size={18} color={color} />
      <Text style={{ fontSize: 14, fontWeight: active ? '600' : '500', color, flex: 1 }} numberOfLines={1}>{title}</Text>
      {badge ? <View style={{ backgroundColor: C.warn, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 2 }}><Text style={{ fontSize: 11, fontWeight: '700', color: C.white }}>{badge}</Text></View> : null}
    </Pressable>
  );
}

function Group({ children }) {
  return <Text style={{ fontSize: 11, fontWeight: '600', color: C.sub, marginTop: 14, marginBottom: 4, marginLeft: 12, letterSpacing: 0.9, textTransform: 'uppercase' }}>{children}</Text>;
}
const TAX_STAFF = ['tax', 'payroll', 'staff'];
const BOOKS = ['books'];

export default function WebSidebar({ user, screens, nav, top, homeTab, setHomeTab, stackLength }) {
  const rows = useMemo(() => {
    try {
      const SM = require('../modules/home/shellModel.js');
      const R = require('../modules/registry.js');
      return SM.recordsRows(user, screens, R.getModule);
    } catch (e) { return []; }
  }, [user && user.uid, user && user.role, screens]);
  const onHome = stackLength <= 1;
  const tab = homeTab || 'today';
  const go = (target) => { nav.home(); if (target) setTimeout(() => nav.push(target.screen, target.params || {}), 0); };
  const goTab = (key) => { nav.home(); if (setHomeTab) setHomeTab(key); };
  const isTarget = (t) => !!top && t && top.name === t.screen && JSON.stringify(top.params || {}) === JSON.stringify(t.params || {});
  const has = (name) => !!(screens && screens[name]);
  // Release 08: on the website the VAT row opens the VAT return page itself (the design); its other tools are a button there
  const vatPage = (r) => (r.id === 'tax' && has('VatMonth') ? { ...r, target: { screen: 'VatMonth', params: {} } } : r);
  const row = (r0) => { const r = vatPage(r0); return <Item key={r.id} testID={`side-${r.id}`} icon={{ name: iconFor(r.id, r.target && r.target.screen), emoji: r.icon }} title={r.title} badge={r.warn ? '!' : ''} active={isTarget(r.target) || (r.id === 'tax' && !!top && top.name === 'VatMonth')} onPress={() => go(r.target)} />; };
  const shops = rows.filter((r) => /^shop-/.test(r.id));
  const taxStaff = rows.filter((r) => TAX_STAFF.includes(r.id));
  const books = rows.filter((r) => BOOKS.includes(r.id));
  const rest = rows.filter((r) => !/^shop-/.test(r.id) && !TAX_STAFF.includes(r.id) && !BOOKS.includes(r.id));
  return (
    <View style={{ width: 264, backgroundColor: C.white, borderRightWidth: 1, borderRightColor: C.border }}>
      <View style={{ paddingTop: 22, paddingBottom: 10, paddingHorizontal: 24 }}>
        <Image source={LOGO} style={{ width: 176, height: 70 }} resizeMode="contain" accessibilityLabel="Easy Buys Shopping Center" />
      </View>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingHorizontal: 14, paddingTop: 2, paddingBottom: 20 }}>
        <Group>Daily</Group>
        <Item testID="side-today" icon={{ name: 'today', emoji: '🏠' }} title="Today" active={onHome && tab === 'today'} onPress={() => goTab('today')} />
        {shops.map(row)}
        {has('CloudInvoices') ? <Item testID="side-cinv" icon={{ name: 'invoice', emoji: '🧾' }} title="Supplier invoices" active={!!top && top.name === 'CloudInvoices'} onPress={() => go({ screen: 'CloudInvoices' })} /> : null}
        {has('CloudCheques') ? <Item testID="side-cchq" icon={{ name: 'cheque', emoji: '✍️' }} title="Cheques" active={!!top && top.name === 'CloudCheques'} onPress={() => go({ screen: 'CloudCheques' })} /> : null}
        {has('MonthRecords') ? <Item testID="side-month" icon={{ name: 'month', emoji: '🗓️' }} title="Month records" active={!!top && top.name === 'MonthRecords'} onPress={() => go({ screen: 'MonthRecords' })} /> : null}
        {taxStaff.length ? <Group>Tax & staff</Group> : null}
        {taxStaff.map(row)}
        {rest.length ? <Group>Everything else</Group> : null}
        {rest.map(row)}
        <Group>Books & reports</Group>
        {books.map(row)}
        <Item testID="side-reports" icon={{ name: 'chart', emoji: '📊' }} title="Reports" active={onHome && tab === 'reports'} onPress={() => goTab('reports')} />
        <Item testID="side-settings" icon={{ name: 'gear', emoji: '⚙️' }} title="Settings" active={onHome && tab === 'settings'} onPress={() => goTab('settings')} />
        {has('SyncStatus') ? <Item testID="side-sync" icon={{ name: 'sync', emoji: '🔄' }} title="Sync status" active={!!top && top.name === 'SyncStatus'} onPress={() => go({ screen: 'SyncStatus' })} /> : null}
        {has('Help') ? <Item testID="side-help" icon={{ name: 'help', emoji: '❓' }} title="Help" active={!!top && top.name === 'Help'} onPress={() => go({ screen: 'Help' })} /> : null}
      </ScrollView>
    </View>
  );
}
