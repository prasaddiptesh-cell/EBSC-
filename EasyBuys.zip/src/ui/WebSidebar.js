// 1.0.0 build 48: the website on a computer screen – the menu always on the left (Today, Records and its parts,
// Reports, Settings, the VAT month, Sync), the page on the right. Phones and tablets are unchanged.
import React, { useMemo } from 'react';
import { View, ScrollView, Pressable, Image, Platform, useWindowDimensions } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';

export const SIDEBAR_MIN_WIDTH = 1100;
export function useSidebar() {
  const { width } = useWindowDimensions();
  return Platform.OS === 'web' && width >= SIDEBAR_MIN_WIDTH;
}

function Item({ icon, title, active, onPress, testID, sub }) {
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed, hovered }) => ({
      flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: sub ? 7 : 10, paddingHorizontal: 12, borderRadius: 10, marginBottom: 2,
      backgroundColor: active ? C.primarySoft : hovered ? '#F2EEEA' : 'transparent', opacity: pressed ? 0.6 : 1,
    })}>
      <Text style={{ fontSize: sub ? 16 : 18, width: 24, textAlign: 'center' }}>{icon}</Text>
      <Text style={{ fontSize: sub ? 14 : 16, fontWeight: active ? '900' : sub ? '600' : '800', color: active ? C.primary : C.text, flex: 1 }} numberOfLines={1}>{title}</Text>
    </Pressable>
  );
}

export default function WebSidebar({ user, screens, nav, top, homeTab, setHomeTab, stackLength }) {
  const rows = useMemo(() => {
    try {
      const SM = require('../modules/home/shellModel.js');
      const R = require('../modules/registry.js');
      return SM.recordsRows(user, screens, R.getModule);
    } catch (e) { return []; }
  }, [user && user.uid, user && user.role, screens]);
  const onHome = stackLength <= 1;
  const tab = homeTab || 'today';
  const go = (target) => { nav.home(); if (target) setTimeout(() => nav.push(target.screen, target.params || {}), 0); };
  const goTab = (key) => { nav.home(); if (setHomeTab) setHomeTab(key); };
  const isTarget = (t) => !!top && t && top.name === t.screen && JSON.stringify(top.params || {}) === JSON.stringify(t.params || {});
  const has = (name) => !!(screens && screens[name]);
  return (
    <View style={{ width: 268, backgroundColor: C.white, borderRightWidth: 1, borderRightColor: C.border }}>
      <View style={{ paddingVertical: 14, paddingHorizontal: 14, borderBottomWidth: 4, borderBottomColor: C.brandRed }}>
        <Image source={require('../../assets/icon.png')} style={{ width: 40, height: 40, borderRadius: 8 }} />
        <Text style={{ fontSize: 18, fontWeight: '900', color: C.primary, marginTop: 6 }}>Easy Buys</Text>
        <Text style={{ fontSize: 13, color: C.sub }} numberOfLines={1}>{user ? user.name : ''}</Text>
      </View>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 10 }}>
        <Item testID="side-today" icon="🏠" title="Today" active={onHome && tab === 'today'} onPress={() => goTab('today')} />
        {has('MonthRecords') ? <Item testID="side-month" icon="🗓️" title="Month records & VAT" active={!!top && top.name === 'MonthRecords'} onPress={() => go({ screen: 'MonthRecords' })} /> : null}
        <Text style={{ fontSize: 12, fontWeight: '900', color: C.sub, marginTop: 12, marginBottom: 4, marginLeft: 12, letterSpacing: 1 }}>RECORDS</Text>
        {rows.map((r) => <Item key={r.id} sub testID={`side-${r.id}`} icon={r.icon} title={r.title} active={isTarget(r.target)} onPress={() => go(r.target)} />)}
        <Text style={{ fontSize: 12, fontWeight: '900', color: C.sub, marginTop: 12, marginBottom: 4, marginLeft: 12, letterSpacing: 1 }}>MORE</Text>
        <Item testID="side-reports" icon="📊" title="Reports" active={onHome && tab === 'reports'} onPress={() => goTab('reports')} />
        <Item testID="side-settings" icon="⚙️" title="Settings" active={onHome && tab === 'settings'} onPress={() => goTab('settings')} />
        {has('SyncStatus') ? <Item testID="side-sync" icon="🔄" title="Sync status" active={!!top && top.name === 'SyncStatus'} onPress={() => go({ screen: 'SyncStatus' })} /> : null}
        {has('Help') ? <Item testID="side-help" icon="❓" title="Help" active={!!top && top.name === 'Help'} onPress={() => go({ screen: 'Help' })} /> : null}
      </ScrollView>
    </View>
  );
}
