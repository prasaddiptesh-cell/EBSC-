// A warning on Home or in the full list: colour by level, taps through to the exact place, "Hide until tomorrow" on
// yellow (warning) and blue (info) ones only.
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { useApp, useUI } from './components.js';
import { hideAlert } from '../services/alerts.js';
import { MUTE_SPANS, canMute, muteAlert } from '../services/sounds.js';

const LOOK = {
  urgent: { bg: C.dangerSoft, border: C.danger, icon: '🚨', label: 'Urgent' },
  warning: { bg: C.warnSoft, border: C.warn, icon: '⚠️', label: 'Warning' },
  info: { bg: C.infoSoft, border: C.info, icon: 'ℹ️', label: 'Info' },
};

// Opens the place a warning points to, if this person may open it.
export function openAlert(app, ui, a) {
  if (!a || !a.nav || !a.nav.screen) return;
  let screens = app.screens;
  if (!screens) { try { screens = require('../modules/registry.js').allScreens(); } catch (e) { screens = null; } }
  const entry = screens ? screens[a.nav.screen] : null;
  if (screens && (!entry || !entry.can(app.realUser || app.user))) {
    if (ui) ui.alert({ title: 'Not for your login', message: 'Ask the owner or a manager to look at this one.', tone: 'warn' });
    return;
  }
  app.nav.push(a.nav.screen, a.nav.params || {});
}

// Release 02: mute a kind of warning for yourself (no sound, no phone notification; it still shows here).
export function askMute(user, ui, a, after) {
  if (!ui || !canMute(user, a)) return;
  ui.choose({ title: 'Mute this warning?', message: `"${a.text}"\nNo sound and no phone notification for you. It still shows on Home. Unmute any time in Settings › Alerts & sounds.`,
    options: [{ text: 'Cancel', value: null, testID: 'mute-cancel' }].concat(Object.entries(MUTE_SPANS).map(([v, t]) => ({ text: t, value: v, testID: `mute-${v}` }))) })
    .then((span) => { if (!span) return; try { muteAlert(user, a, span); ui.toast(`Muted – ${MUTE_SPANS[span].toLowerCase()}`); if (after) after(a); } catch (e) { ui.error(e); } });
}

export function AlertCard({ a, onHidden, compact }) {
  const app = useApp();
  const ui = useUI();
  const look = LOOK[a.level] || LOOK.info;
  const hide = () => {
    try { hideAlert(app.realUser || app.user, a); if (ui) ui.toast('Hidden until tomorrow'); if (onHidden) onHidden(a); } catch (e) { if (ui) ui.error(e); }
  };
  return (
    <View testID={`alert-${a.id}`} style={{ flexDirection: 'row', alignItems: 'stretch', backgroundColor: look.bg, borderRadius: 14, borderWidth: 2, borderColor: look.border, overflow: 'hidden' }}>
      <Pressable testID={`alert-open-${a.id}`} onPress={() => openAlert(app, ui, a)} style={({ pressed }) => ({ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, padding: compact ? 10 : 12, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ fontSize: 24 }}>{look.icon}</Text>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: a.level === 'urgent' ? C.danger : C.text }}>{a.text}</Text>
          {a.sub ? <Text style={{ fontSize: 14, color: C.sub }}>{a.sub}</Text> : null}
        </View>
        {a.nav ? <Text style={{ fontSize: 22, color: C.sub }}>›</Text> : null}
      </Pressable>
      {canMute(app.realUser || app.user, a) ? (
        <Pressable testID={`alert-mute-${a.id}`} onPress={() => askMute(app.realUser || app.user, ui, a)} accessibilityLabel="Mute this warning"
          style={({ pressed }) => ({ paddingHorizontal: 12, justifyContent: 'center', alignItems: 'center', borderLeftWidth: 1, borderLeftColor: look.border, opacity: pressed ? 0.6 : 1, maxWidth: 90 })}>
          <Text style={{ fontSize: 13, fontWeight: '800', color: C.sub, textAlign: 'center' }}>🔕{'\n'}Mute</Text>
        </Pressable>
      ) : null}
      {a.level !== 'urgent' ? (
        <Pressable testID={`alert-hide-${a.id}`} onPress={hide} accessibilityLabel="Hide until tomorrow"
          style={({ pressed }) => ({ paddingHorizontal: 12, justifyContent: 'center', alignItems: 'center', borderLeftWidth: 1, borderLeftColor: look.border, opacity: pressed ? 0.6 : 1, maxWidth: 110 })}>
          <Text style={{ fontSize: 13, fontWeight: '800', color: C.sub, textAlign: 'center' }}>Hide until{'\n'}tomorrow</Text>
        </Pressable>
      ) : null}
    </View>
  );
}
