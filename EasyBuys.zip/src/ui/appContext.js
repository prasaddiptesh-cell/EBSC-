// The logged-in user and navigation, shared by every screen and module.
import { createContext, useContext } from 'react';

export const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);
