// The strip under every screen's header: sync status + Sync now, the sync icon for Home, and the "Aa" size control.
import React, { useEffect, useState, useContext } from 'react';
import { View, Pressable } from 'react-native';
import { Text, useScale, ScaleSetterContext } from './scale.js';
import { C } from './theme.js';
import { onSyncState } from '../services/syncBus.js';
import { currentSyncLight, startSync } from '../services/syncInfo.js';
import { SCALE_STEPS } from '../services/access.js';
import { useApp } from './appContext.js';
import { useUI } from './components.js'; // used at render time only (components.js imports this file too)
import { SafeModal } from './safeModal.js';


const LIGHT = { green: C.success, amber: C.warn, red: C.danger, grey: '#98A2B3' };

// Live sync light (green / amber / red / grey) and its text; updates on every sync change and every 5 seconds.
export function useSyncLight() {
  const [, setN] = useState(0);
  useEffect(() => {
    const off = onSyncState(() => setN((n) => n + 1));
    const t = setInterval(() => setN((n) => n + 1), 5000);
    return () => { off(); clearInterval(t); };
  }, []);
  return currentSyncLight();
}
// "Sync now" from anywhere: starts straight away; the bar and the icon show the progress.
export function useSyncNow() {
  const ui = useUI();
  return async () => {
    const r = await startSync();
    if (r && r.blocked && ui) ui.alert({ title: 'Sync now', message: r.message, tone: 'warn' });
    return r;
  };
}

export function SyncBar() {
  const app = useApp();
  const light = useSyncLight();
  const sync = useSyncNow();
  const wide = require('./wide.js').useWide();
  const open = () => { if (app && app.user && app.nav) app.nav.push('SyncStatus'); };
  // Release 13 (owner: a small green dot when all is fine): on the website the bar shows only when something needs
  // attention (sending, waiting, a problem); all synced is the green dot in the header (SyncDot)
  if (wide && light.color === 'green' && !light.running) return null;
  return (
    <View testID="sync-bar" style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#FBF9F6', borderBottomWidth: 1, borderBottomColor: C.border, paddingHorizontal: 10, paddingVertical: 4, gap: 8 }}>
      <Pressable onPress={open} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
        <View testID={`sync-dot-${light.color}`} style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: LIGHT[light.color] }} />
        <Text testID="sync-text" numberOfLines={light.running ? 2 : 1} style={{ flex: 1, fontSize: 14, fontWeight: '700', color: light.color === 'red' ? C.danger : C.text }}>{light.text}</Text>
      </Pressable>
      {light.canSync || light.running ? (
        <Pressable testID="force-sync" onPress={sync} disabled={!!light.running} style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, backgroundColor: light.running ? C.disabled : light.retry ? C.danger : C.info, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ color: C.white, fontWeight: '800', fontSize: 14 }}>{light.running ? '⟳ Syncing…' : light.retry ? '⟳ Retry' : '⟳ Sync now'}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

// Release 13: the green dot in the website's header – hover / tap shows "All synced · live" and opens Sync status
export function SyncDot() {
  const app = useApp();
  const light = useSyncLight();
  const [hover, setHover] = React.useState(false);
  if (light.color !== 'green' || light.running) return null;
  return (
    <Pressable testID="sync-dot" accessibilityLabel={light.text} onHoverIn={() => setHover(true)} onHoverOut={() => setHover(false)} onPress={() => { if (app && app.nav) app.nav.push('SyncStatus'); }}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, height: 32, borderRadius: 16, backgroundColor: hover ? C.successSoft : 'transparent' }}>
      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: LIGHT.green }} />
      {hover ? <Text style={{ fontSize: 12, color: C.successText, fontWeight: '600' }}>{light.text}</Text> : null}
    </Pressable>
  );
}

// The small sync icon for a top bar (Home): its colour is the sync light; pressing starts a sync straight away.
export function SyncIcon() {
  const light = useSyncLight();
  const sync = useSyncNow();
  return (
    <Pressable testID="sync-icon" accessibilityLabel={`Sync now. ${light.text}`} onPress={sync}
      style={({ pressed }) => ({ width: 46, height: 46, borderRadius: 23, marginLeft: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: LIGHT[light.color], opacity: pressed || light.running ? 0.6 : 1 })}>
      <Text testID={`sync-icon-${light.color}`} style={{ color: C.white, fontSize: 24, fontWeight: '900' }}>⟳</Text>
    </Pressable>
  );
}

// Big panel for Admin › Sync: what it is doing now, and Sync now / Retry.
export function SyncNowPanel() {
  const light = useSyncLight();
  const sync = useSyncNow();
  const bg = { green: C.successSoft, amber: C.warnSoft, red: C.dangerSoft, grey: '#EEE9E1' }[light.color];
  return (
    <View testID="sync-panel" style={{ backgroundColor: bg, borderRadius: 16, padding: 14, gap: 10, borderWidth: 2, borderColor: LIGHT[light.color] }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: LIGHT[light.color] }} />
        <Text testID="sync-panel-text" style={{ flex: 1, fontSize: 19, fontWeight: '800', color: C.text }}>{light.text}</Text>
      </View>
      <Pressable testID="sync-now" onPress={sync} disabled={!!light.running}
        style={({ pressed }) => ({ minHeight: 56, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: light.running ? C.disabled : light.retry ? C.danger : C.info, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ color: C.white, fontSize: 19, fontWeight: '900' }}>{light.running ? '⟳ Syncing…' : light.retry ? '⟳ Retry now' : '⟳ Sync now'}</Text>
      </Pressable>
    </View>
  );
}

export function SizeButton() {
  const s = useScale();
  const setScale = useContext(ScaleSetterContext);
  const [open, setOpen] = useState(false);
  const idx = SCALE_STEPS.reduce((best, v, i) => (Math.abs(v - s) < Math.abs(SCALE_STEPS[best] - s) ? i : best), 0);
  const go = (d) => { const n = Math.min(SCALE_STEPS.length - 1, Math.max(0, idx + d)); setScale(SCALE_STEPS[n]); };
  return (
    <>
      <Pressable testID="size-btn" onPress={() => setOpen(true)} style={({ pressed }) => ({ paddingHorizontal: 10, paddingVertical: 8, borderRadius: 12, backgroundColor: '#F2EEEA', marginLeft: 6, opacity: pressed ? 0.6 : 1 })}>
        <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>Aa</Text>
      </Pressable>
      <SafeModal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
          <View testID="size-panel" style={{ backgroundColor: C.card, borderRadius: 18, padding: 20, width: '100%', maxWidth: 520, gap: 14 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>Text and button size</Text>
            <Text style={{ fontSize: 16, color: C.sub }}>For this device only. Bigger = easier to read and tap.</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              {[['−', -1, 'size-down'], ['+', 1, 'size-up']].map(([label, d, id]) => (
                <Pressable key={id} testID={id} onPress={() => go(d)} style={({ pressed }) => ({ width: 72 * s, height: 64 * s, borderRadius: 14, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                  <Text style={{ fontSize: 30, fontWeight: '900', color: C.primary }}>{label}</Text>
                </Pressable>
              ))}
              <Text testID="size-value" style={{ flex: 1, textAlign: 'center', fontSize: 22, fontWeight: '800', color: C.text }}>{Math.round(s * 100)}%</Text>
            </View>
            <View style={{ backgroundColor: '#F8F5F0', borderRadius: 12, padding: 12 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Preview: Clock IN</Text>
              <Text style={{ fontSize: 15, color: C.sub }}>This is how text will look on every screen.</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable testID="size-reset" onPress={() => setScale(null)} style={({ pressed }) => ({ flex: 1, minHeight: 56 * s, borderRadius: 12, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Reset</Text>
              </Pressable>
              <Pressable testID="size-done" onPress={() => setOpen(false)} style={({ pressed }) => ({ flex: 1, minHeight: 56 * s, borderRadius: 12, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.white }}>Done</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </SafeModal>
    </>
  );
}
