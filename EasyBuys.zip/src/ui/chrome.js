// The strip under every screen's header: sync status + Force sync, and the "Aa" display size control.
import React, { useEffect, useState, useContext } from 'react';
import { View, Pressable, Modal } from 'react-native';
import { Text, useScale, ScaleSetterContext } from './scale.js';
import { C } from './theme.js';
import { getSyncState, onSyncState } from '../services/syncBus.js';
import { SCALE_STEPS } from '../services/access.js';
import { useApp } from './appContext.js';


function waitingCount() {
  try {
    const { pendingBySection } = require('../services/records.js');
    const { countPendingOutbox } = require('../services/stock.js');
    const per = pendingBySection();
    return Object.values(per).reduce((a, b) => a + b, 0) + countPendingOutbox();
  } catch (e) {
    return 0;
  }
}
function linked() {
  try {
    const { getSettings } = require('../services/core.js');
    return !!getSettings().cloudUrl;
  } catch (e) {
    return false;
  }
}

export function SyncBar() {
  const app = useApp();
  const [st, setSt] = useState(getSyncState());
  const [waiting, setWaiting] = useState(waitingCount());
  useEffect(() => {
    const off = onSyncState((s) => { setSt(s); setWaiting(waitingCount()); });
    const t = setInterval(() => setWaiting(waitingCount()), 5000);
    return () => { off(); clearInterval(t); };
  }, []);
  const isLinked = linked();
  let dot = C.success;
  let text = `All synced${st.lastOk ? ` · ${st.lastOk.slice(11, 16)}` : ''}`;
  if (!isLinked) { dot = '#98A2B3'; text = 'Not linked to the cloud yet (saved on this device)'; }
  else if (st.running) { dot = C.info; text = `Syncing…${waiting ? ` ${waiting} waiting` : ''}`; }
  else if (st.error) { dot = C.danger; text = `${/network|fetch|timed|abort/i.test(st.error) ? 'Offline' : 'Sync problem'}${waiting ? ` · ${waiting} waiting to send` : ''}`; }
  else if (waiting) { dot = C.warn; text = `${waiting} waiting to send`; }
  const force = () => {
    try {
      const { syncNow } = require('../platform/cloud.js');
      syncNow({ force: true }).catch(() => {});
    } catch (e) { /* ignore */ }
  };
  const open = () => { if (app && app.user && app.nav) app.nav.push('SyncStatus'); };
  return (
    <View testID="sync-bar" style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#FBF9F6', borderBottomWidth: 1, borderBottomColor: C.border, paddingHorizontal: 10, paddingVertical: 4, gap: 8 }}>
      <Pressable onPress={open} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 }}>
        <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: dot }} />
        <Text testID="sync-text" numberOfLines={1} style={{ flex: 1, fontSize: 14, fontWeight: '700', color: st.error ? C.danger : C.text }}>{text}</Text>
      </Pressable>
      {isLinked ? (
        <Pressable testID="force-sync" onPress={force} disabled={st.running} style={({ pressed }) => ({ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10, backgroundColor: st.running ? C.disabled : C.info, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ color: C.white, fontWeight: '800', fontSize: 14 }}>⟳ Sync now</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function SizeButton() {
  const s = useScale();
  const setScale = useContext(ScaleSetterContext);
  const [open, setOpen] = useState(false);
  const idx = SCALE_STEPS.reduce((best, v, i) => (Math.abs(v - s) < Math.abs(SCALE_STEPS[best] - s) ? i : best), 0);
  const go = (d) => { const n = Math.min(SCALE_STEPS.length - 1, Math.max(0, idx + d)); setScale(SCALE_STEPS[n]); };
  return (
    <>
      <Pressable testID="size-btn" onPress={() => setOpen(true)} style={({ pressed }) => ({ paddingHorizontal: 10, paddingVertical: 8, borderRadius: 12, backgroundColor: '#F2EEEA', marginLeft: 6, opacity: pressed ? 0.6 : 1 })}>
        <Text style={{ fontSize: 18, fontWeight: '900', color: C.text }}>Aa</Text>
      </Pressable>
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
          <View testID="size-panel" style={{ backgroundColor: C.card, borderRadius: 18, padding: 20, width: '100%', maxWidth: 520, gap: 14 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>Text and button size</Text>
            <Text style={{ fontSize: 16, color: C.sub }}>For this device only. Bigger = easier to read and tap.</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              {[['−', -1, 'size-down'], ['+', 1, 'size-up']].map(([label, d, id]) => (
                <Pressable key={id} testID={id} onPress={() => go(d)} style={({ pressed }) => ({ width: 72 * s, height: 64 * s, borderRadius: 14, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                  <Text style={{ fontSize: 30, fontWeight: '900', color: C.primary }}>{label}</Text>
                </Pressable>
              ))}
              <Text testID="size-value" style={{ flex: 1, textAlign: 'center', fontSize: 22, fontWeight: '800', color: C.text }}>{Math.round(s * 100)}%</Text>
            </View>
            <View style={{ backgroundColor: '#F8F5F0', borderRadius: 12, padding: 12 }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Preview: Clock IN</Text>
              <Text style={{ fontSize: 15, color: C.sub }}>This is how text will look on every screen.</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable testID="size-reset" onPress={() => setScale(null)} style={({ pressed }) => ({ flex: 1, minHeight: 56 * s, borderRadius: 12, borderWidth: 2, borderColor: C.border, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Reset</Text>
              </Pressable>
              <Pressable testID="size-done" onPress={() => setOpen(false)} style={({ pressed }) => ({ flex: 1, minHeight: 56 * s, borderRadius: 12, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: C.white }}>Done</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}
