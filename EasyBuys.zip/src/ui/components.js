import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { View, Pressable, ScrollView, Modal, useWindowDimensions, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { Text, TextInput, useScale } from './scale.js';
import { SyncBar, SizeButton } from './chrome.js';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C, ROLE_COLOR } from './theme.js';
import { fmt, r3 } from '../services/core.js';
import { ROLE_LABEL } from '../services/access.js';

export const LOGO = require('../../assets/logo.png');

// ================= App context (user + navigation) =================
export { AppContext, useApp } from './appContext.js';
import { PhotoViewer } from './photoView.js';
import { useApp } from './appContext.js';
import { remember, recall, screenKey } from './memory.js';
import { TimeField } from './timePicker.js';
export { TimeField } from './timePicker.js';

export function useLayout() {
  const { width } = useWindowDimensions();
  const s = useScale();
  const w = width / Math.max(0.8, s);            // bigger display size = fewer columns
  return { width, isTablet: width >= 700, isPhone: width < 500, cols: w >= 1000 ? 4 : w >= 700 ? 3 : w >= 330 ? 2 : 1 };
}

// Like useState, but the value is kept when the person opens another screen and comes back (filters, search text, tabs).
export function useRemembered(name, initial) {
  const app = useApp();
  const k = `${screenKey(app) || 'screen'}|${name}`;
  const [v, setV] = useState(() => { const r = recall(k); return r !== undefined ? r : typeof initial === 'function' ? initial() : initial; });
  const set = useCallback((x) => setV((old) => { const nv = typeof x === 'function' ? x(old) : x; remember(k, nv); return nv; }), [k]);
  return [v, set];
}

// ================= Toasts & dialogs =================
const UIContext = createContext(null);
export const useUI = () => useContext(UIContext);

export function UIProvider({ children }) {
  const [toast, setToast] = useState(null);
  const [dialog, setDialog] = useState(null);
  const timer = useRef(null);

  const api = useRef({
    toast(message, tone = 'success') {
      clearTimeout(timer.current);
      setToast({ message, tone });
      timer.current = setTimeout(() => setToast(null), 3500);
    },
    // Returns a promise that resolves to true (confirm) or false (cancel).
    confirm({ title, message, confirmText = 'Yes, continue', cancelText = 'Cancel', tone = 'primary' }) {
      return new Promise((resolve) => {
        setDialog({
          title, message, tone,
          buttons: [
            { text: cancelText, variant: 'secondary', onPress: () => resolve(false) },
            { text: confirmText, variant: tone, onPress: () => resolve(true) },
          ],
        });
      });
    },
    alert({ title, message, tone = 'primary', okText = 'OK' }) {
      return new Promise((resolve) => {
        setDialog({ title, message, tone, buttons: [{ text: okText, variant: tone, onPress: () => resolve(true) }] });
      });
    },
    // Show an error from a failed action in plain language.
    error(e) {
      const message = e && e.isAppError ? e.message : `Something went wrong: ${e && e.message ? e.message : e}`;
      return this.alert({ title: 'Cannot save', message, tone: 'danger' });
    },
  }).current;

  const toneColor = { success: C.success, danger: C.danger, warn: C.warn, primary: C.primary, info: C.info };

  return (
    <UIContext.Provider value={api}>
      {children}
      {toast ? (
        <View pointerEvents="none" style={{ position: 'absolute', left: 16, right: 16, bottom: 40, alignItems: 'center', zIndex: 50, elevation: 50 }}>
          <View testID="toast" style={{ backgroundColor: toneColor[toast.tone] || C.success, paddingVertical: 16, paddingHorizontal: 22, borderRadius: 14, maxWidth: 640, elevation: 6 }}>
            <Text style={{ color: C.white, fontSize: 18, fontWeight: '700', textAlign: 'center' }}>
              {toast.tone === 'success' ? '✓  ' : ''}{toast.message}
            </Text>
          </View>
        </View>
      ) : null}
      <Modal visible={!!dialog} transparent animationType="fade" onRequestClose={() => {
        if (dialog) { const b = dialog.buttons[0]; setDialog(null); b.onPress(); }
      }}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          {dialog ? (
            <View testID="dialog" style={{ backgroundColor: C.card, borderRadius: 18, padding: 24, width: '100%', maxWidth: 560 }}>
              <Text style={{ fontSize: 24, fontWeight: '800', color: dialog.tone === 'danger' ? C.danger : dialog.tone === 'warn' ? C.warn : C.text, marginBottom: 10 }}>
                {dialog.title}
              </Text>
              {dialog.message ? <Text style={{ fontSize: 18, color: C.text, lineHeight: 26, marginBottom: 20 }}>{dialog.message}</Text> : null}
              <View style={{ flexDirection: 'row', gap: 12 }}>
                {dialog.buttons.map((b) => (
                  <Btn key={b.text} title={b.text} variant={b.variant} style={{ flex: 1 }}
                    onPress={() => { setDialog(null); b.onPress(); }} />
                ))}
              </View>
            </View>
          ) : null}
        </View>
      </Modal>
    </UIContext.Provider>
  );
}

// ================= Buttons =================
const VARIANTS = {
  primary: { bg: C.primary, fg: C.white, border: C.primary },
  success: { bg: C.success, fg: C.white, border: C.success },
  danger: { bg: C.danger, fg: C.white, border: C.danger },
  warn: { bg: C.warn, fg: C.white, border: C.warn },
  info: { bg: C.info, fg: C.white, border: C.info },
  secondary: { bg: C.white, fg: C.text, border: C.border },
  ghost: { bg: 'transparent', fg: C.primary, border: 'transparent' },
};

export function Btn({ title, onPress, variant = 'primary', size = 'lg', icon, disabled, style, testID }) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = useScale();
  const h = (size === 'lg' ? 72 : size === 'md' ? 60 : 52) * s;
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [{
        minHeight: h, borderRadius: 14, borderWidth: 2, paddingHorizontal: 18,
        alignItems: 'center', justifyContent: 'center', flexDirection: 'row',
        backgroundColor: disabled ? C.disabled : v.bg, borderColor: disabled ? C.disabled : v.border,
        opacity: pressed ? 0.75 : 1,
      }, style]}
    >
      {icon ? <Text style={{ fontSize: size === 'lg' ? 22 : 18, marginRight: 8 }}>{icon}</Text> : null}
      <Text style={{ color: disabled ? C.white : v.fg, fontSize: size === 'lg' ? 22 : size === 'md' ? 19 : 17, fontWeight: '800', textAlign: 'center' }}>
        {title}
      </Text>
    </Pressable>
  );
}

// Large menu tile used on home screens.
export function Tile({ title, subtitle, icon, onPress, color = C.primary, disabled, badge, testID }) {
  const s = useScale();
  const { isPhone } = useLayout();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: disabled ? '#EEE9E1' : C.card, borderRadius: 20, padding: isPhone ? 12 : 18, minHeight: (isPhone ? 120 : 160) * s,
        borderWidth: 2, borderColor: disabled ? C.border : color, justifyContent: 'center', alignItems: 'center',
        opacity: pressed ? 0.7 : 1, elevation: disabled ? 0 : 2,
      })}
    >
      <Text style={{ fontSize: isPhone ? 36 : 48, marginBottom: 6, opacity: disabled ? 0.4 : 1 }}>{icon}</Text>
      <Text style={{ fontSize: 22, fontWeight: '800', color: disabled ? C.sub : C.text, textAlign: 'center' }}>{title}</Text>
      {subtitle ? <Text style={{ fontSize: 16, color: C.sub, textAlign: 'center', marginTop: 4 }}>{subtitle}</Text> : null}
      {badge ? (
        <View style={{ position: 'absolute', top: 10, right: 10, backgroundColor: C.danger, borderRadius: 12, paddingHorizontal: 8, paddingVertical: 2 }}>
          <Text style={{ color: C.white, fontWeight: '800', fontSize: 14 }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

// Responsive grid. Children are laid out in equal columns.
export function Grid({ children, cols, gap = 14 }) {
  const layout = useLayout();
  const n = cols || layout.cols;
  const items = React.Children.toArray(children).filter(Boolean);
  const rows = [];
  for (let i = 0; i < items.length; i += n) rows.push(items.slice(i, i + n));
  return (
    <View style={{ gap }}>
      {rows.map((row, ri) => (
        <View key={ri} style={{ flexDirection: 'row', gap }}>
          {row.map((child, ci) => <View key={ci} style={{ flex: 1 }}>{child}</View>)}
          {row.length < n ? Array.from({ length: n - row.length }).map((_, k) => <View key={'f' + k} style={{ flex: 1 }} />) : null}
        </View>
      ))}
    </View>
  );
}

// ================= Layout =================
export function Screen({ title, subtitle, onBack, children, footer, scroll = true, hideUser, right, hideSync }) {
  const app = useApp();
  const insets = useSafeAreaInsets();
  const { isPhone } = useLayout();
  const back = onBack || (app && app.canGoBack ? app.nav.pop : null);
  const user = app && app.user;
  const Body = scroll ? ScrollView : View;
  // Scroll position remembered for this screen, so going back returns to the same place.
  const sk = screenKey(app);
  const bodyRef = useRef(null);
  const pendingY = useRef(sk ? recall(`${sk}|scroll`) || 0 : 0);
  useEffect(() => { const t = setTimeout(() => { pendingY.current = 0; }, 2500); return () => clearTimeout(t); }, []);
  const onScroll = (e) => { if (sk && !pendingY.current) remember(`${sk}|scroll`, e.nativeEvent.contentOffset.y); };
  const onContentSizeChange = (w, h) => {
    const y = pendingY.current;
    if (y > 0 && bodyRef.current && bodyRef.current.scrollTo) {
      bodyRef.current.scrollTo({ y, animated: false });
      if (h >= y) pendingY.current = 0;
    }
  };
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={{ backgroundColor: C.white, paddingTop: insets.top + (isPhone ? 4 : 8), paddingBottom: isPhone ? 6 : 10, paddingHorizontal: isPhone ? 8 : 14, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 4, borderBottomColor: C.brandRed }}>
        {back ? (
          <Pressable testID="back" onPress={back} style={({ pressed }) => ({ paddingVertical: isPhone ? 10 : 14, paddingHorizontal: isPhone ? 10 : 18, borderRadius: 12, backgroundColor: C.primarySoft, marginRight: isPhone ? 8 : 12, opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ color: C.primary, fontSize: isPhone ? 18 : 20, fontWeight: '800' }}>{isPhone ? '‹' : '‹ Back'}</Text>
          </Pressable>
        ) : (
          isPhone ? null : <Image source={LOGO} style={{ width: 92, height: 41, marginRight: 12 }} resizeMode="contain" />
        )}
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.text, fontSize: isPhone ? 18 : 21, fontWeight: '800' }} numberOfLines={1}>{title}</Text>
          {subtitle ? <Text style={{ color: C.sub, fontSize: 14 }} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
        {right || null}
        <SizeButton />
        {user && !hideUser ? (
          <Pressable testID="logout" onPress={app.logout} style={({ pressed }) => ({ alignItems: 'flex-end', paddingVertical: isPhone ? 6 : 10, paddingHorizontal: isPhone ? 8 : 14, borderRadius: 12, backgroundColor: '#F2EEEA', marginLeft: 8, opacity: pressed ? 0.6 : 1, maxWidth: isPhone ? 110 : 220 })}>
            <Text style={{ color: C.text, fontSize: isPhone ? 13 : 15, fontWeight: '800' }} numberOfLines={1}>{isPhone ? user.name.split(' ')[0] : user.name}</Text>
            <Text style={{ color: C.sub, fontSize: isPhone ? 11 : 13 }} numberOfLines={1}>{isPhone ? 'Log out' : `${ROLE_LABEL[user.role] || user.role} · Log out`}</Text>
          </Pressable>
        ) : null}
      </View>
      {hideSync ? null : <SyncBar />}
      <Body ref={scroll ? bodyRef : undefined} style={{ flex: 1 }} contentContainerStyle={scroll ? { padding: isPhone ? 10 : 16, paddingBottom: 40 } : undefined} keyboardShouldPersistTaps="handled"
        {...(scroll ? { onScroll, scrollEventThrottle: 100, onContentSizeChange } : {})}>
        {scroll ? <View style={{ width: '100%', maxWidth: 1100, alignSelf: 'center', gap: isPhone ? 10 : 14 }}>{children}</View> : children}
      </Body>
      {footer ? (
        <View style={{ padding: isPhone ? 8 : 12, paddingBottom: (isPhone ? 8 : 12) + insets.bottom, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.border }}>
          <View style={{ width: '100%', maxWidth: 1100, alignSelf: 'center' }}>{footer}</View>
        </View>
      ) : <View style={{ height: insets.bottom }} />}
    </KeyboardAvoidingView>
  );
}

export function Card({ children, style, tone }) {
  const border = tone === 'warn' ? C.warn : tone === 'danger' ? C.danger : tone === 'success' ? C.success : tone === 'info' ? C.info : C.border;
  return (
    <View style={[{ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: tone ? 2 : 1, borderColor: border }, style]}>
      {children}
    </View>
  );
}

export function H({ children, style }) {
  return <Text style={[{ fontSize: 20, fontWeight: '800', color: C.text, marginBottom: 8 }, style]}>{children}</Text>;
}

export function Label({ children }) {
  return <Text style={{ fontSize: 17, fontWeight: '700', color: C.sub, marginBottom: 8 }}>{children}</Text>;
}

export function P({ children, style }) {
  return <Text style={[{ fontSize: 17, color: C.text, lineHeight: 24 }, style]}>{children}</Text>;
}

export function Row({ label, value, bold, color }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
      <Text style={{ fontSize: 17, color: C.sub, flex: 1 }}>{label}</Text>
      <Text style={{ fontSize: 17, color: color || C.text, fontWeight: bold ? '800' : '600', textAlign: 'right' }}>{value}</Text>
    </View>
  );
}

export function Banner({ tone = 'info', title, message, testID }) {
  const map = {
    info: [C.infoSoft, C.info, 'ℹ️'], warn: [C.warnSoft, C.warn, '⚠️'],
    danger: [C.dangerSoft, C.danger, '⛔'], success: [C.successSoft, C.success, '✅'],
  };
  const [bg, fg, icon] = map[tone] || map.info;
  return (
    <View testID={testID} style={{ backgroundColor: bg, borderLeftWidth: 6, borderLeftColor: fg, borderRadius: 12, padding: 14, flexDirection: 'row' }}>
      <Text style={{ fontSize: 22, marginRight: 10 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        {title ? <Text style={{ fontSize: 18, fontWeight: '800', color: fg }}>{title}</Text> : null}
        {message ? <Text style={{ fontSize: 16, color: C.text, marginTop: title ? 2 : 0, lineHeight: 22 }}>{message}</Text> : null}
      </View>
    </View>
  );
}

export function Badge({ text, color = C.info }) {
  return (
    <View style={{ backgroundColor: color, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, alignSelf: 'flex-start' }}>
      <Text style={{ color: C.white, fontSize: 13, fontWeight: '800' }}>{text}</Text>
    </View>
  );
}

export function RoleBadge({ role }) {
  return <Badge text={ROLE_LABEL[role] || role} color={ROLE_COLOR[role]} />;
}

export function Empty({ text }) {
  return (
    <View style={{ padding: 30, alignItems: 'center' }}>
      <Text style={{ fontSize: 40 }}>📭</Text>
      <Text style={{ fontSize: 18, color: C.sub, marginTop: 8, textAlign: 'center' }}>{text}</Text>
    </View>
  );
}

// ================= Inputs =================
export function Field({ label, value, onChangeText, placeholder, keyboardType, secure, multiline, maxLength, testID }) {
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#A39886"
        keyboardType={keyboardType}
        secureTextEntry={secure}
        multiline={multiline}
        maxLength={maxLength}
        style={{
          backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12,
          paddingHorizontal: 14, paddingVertical: 12, fontSize: 20, color: C.text,
          minHeight: multiline ? 96 : 62, textAlignVertical: multiline ? 'top' : 'center',
        }}
      />
    </View>
  );
}

const toText = (v) => (v === null || v === undefined || v === '' ? '' : String(r3(v)));

// Number entry with big − / + buttons so workers rarely need the keyboard.
export function NumberField({ label, value, onChange, step = 1, unit, min = 0, testID, hint, compact }) {
  const [text, setText] = useState(toText(value));
  useEffect(() => {
    const parsed = text === '' ? null : Number(text);
    const v = value === null || value === undefined || value === '' ? null : Number(value);
    if (parsed !== v && text !== '-' && !(text.endsWith('.') && Number(text.slice(0, -1)) === v)) setText(toText(value));
  }, [value]);

  const commit = (t) => {
    const neg = min < 0 && String(t).trim().startsWith('-');
    const clean = t.replace(',', '.').replace(/[^0-9.]/g, '');
    const parts = clean.split('.');
    const digits = parts.length > 2 ? parts[0] + '.' + parts.slice(1).join('') : clean;
    const fixed = (neg ? '-' : '') + digits;
    setText(fixed);
    if (digits === '' || digits === '.') onChange(null);
    else onChange(Number(fixed.endsWith('.') ? fixed.slice(0, -1) : fixed));
  };
  const bump = (dir) => {
    const cur = value === null || value === undefined || value === '' ? 0 : Number(value);
    const next = Math.max(min, r3(cur + dir * step));
    setText(toText(next));
    onChange(next);
  };
  const sc = useScale();
  const size = (compact ? 60 : 68) * sc;
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable testID={testID ? testID + '-minus' : undefined} onPress={() => bump(-1)} style={({ pressed }) => ({ width: size, height: size, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.primary }}>−</Text>
        </Pressable>
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12, height: size, paddingHorizontal: 12 }}>
          <TextInput
            testID={testID}
            value={text}
            onChangeText={commit}
            keyboardType={min < 0 ? 'numbers-and-punctuation' : 'decimal-pad'}
            selectTextOnFocus
            placeholder="0"
            placeholderTextColor="#B9AE9E"
            style={{ flex: 1, fontSize: 24, fontWeight: '800', color: C.text, textAlign: 'center', padding: 0 }}
          />
          {unit ? <Text style={{ fontSize: 17, color: C.sub, fontWeight: '700' }}>{unit}</Text> : null}
        </View>
        <Pressable testID={testID ? testID + '-plus' : undefined} onPress={() => bump(1)} style={({ pressed }) => ({ width: size, height: size, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.primary }}>+</Text>
        </Pressable>
      </View>
      {hint ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>{hint}</Text> : null}
    </View>
  );
}

// Small number box for tables (e.g. minutes per flour band). Empty = not set.
export function NumCell({ label, value, onChange, unit, testID, min = 0 }) {
  const [text, setText] = useState(toText(value));
  useEffect(() => {
    const parsed = text === '' ? null : Number(text);
    const v = value === null || value === undefined || value === '' ? null : Number(value);
    if (parsed !== v && text !== '-' && !text.endsWith('.')) setText(toText(value));
  }, [value]);
  const commit = (t) => {
    const neg = min < 0 && String(t).trim().startsWith('-');
    const clean = t.replace(',', '.').replace(/[^0-9.]/g, '');
    const fixed = (neg ? '-' : '') + clean;
    setText(fixed);
    if (clean === '' || clean === '.') onChange(null);
    else onChange(Number(fixed.endsWith('.') ? fixed.slice(0, -1) : fixed));
  };
  return (
    <View style={{ flex: 1, minWidth: 90 }}>
      {label ? <Text style={{ fontSize: 14, fontWeight: '700', color: C.sub, marginBottom: 4, textAlign: 'center' }} numberOfLines={2}>{label}</Text> : null}
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 2, borderColor: value === null || value === undefined ? C.border : C.info, borderRadius: 12, height: 62, paddingHorizontal: 8 }}>
        <TextInput
          testID={testID}
          value={text}
          onChangeText={commit}
          keyboardType={min < 0 ? 'numbers-and-punctuation' : 'decimal-pad'}
          selectTextOnFocus
          placeholder="–"
          placeholderTextColor="#B9AE9E"
          style={{ flex: 1, fontSize: 22, fontWeight: '800', color: C.text, textAlign: 'center', padding: 0 }}
        />
        {unit ? <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{unit}</Text> : null}
      </View>
    </View>
  );
}

// Single-choice chips (large touch targets).
export function Chips({ options, value, onChange, testIDPrefix }) {
  const s = useScale();
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {options.map((o) => {
        const opt = typeof o === 'string' ? { value: o, label: o } : o;
        const on = opt.value === value;
        return (
          <Pressable
            key={String(opt.value)}
            testID={testIDPrefix ? `${testIDPrefix}-${opt.value}` : undefined}
            onPress={() => onChange(opt.value)}
            style={({ pressed }) => ({
              minHeight: 60 * s, paddingHorizontal: 22 * Math.min(1, s), borderRadius: 30, justifyContent: 'center',
              backgroundColor: on ? C.primary : C.white, borderWidth: 2, borderColor: on ? C.primary : C.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ fontSize: 19, fontWeight: '800', color: on ? C.white : C.text }}>{on ? '✓ ' : ''}{opt.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

// Grid of big buttons for choosing a material or product.
export function PickGrid({ items, onPick, selectedId, render, testIDPrefix }) {
  const s = useScale();
  return (
    <Grid>
      {items.map((it) => {
        const on = it.id === selectedId;
        return (
          <Pressable
            key={it.id}
            testID={testIDPrefix ? `${testIDPrefix}-${it.id}` : undefined}
            onPress={() => onPick(it)}
            style={({ pressed }) => ({
              minHeight: 104 * s, borderRadius: 18, padding: 16, justifyContent: 'center',
              backgroundColor: on ? C.primarySoft : C.card, borderWidth: 2, borderColor: on ? C.primary : C.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            {render ? render(it) : <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{it.name}</Text>}
          </Pressable>
        );
      })}
    </Grid>
  );
}

// Shows expected / actual / variance with a clear warning when they differ.
export function VarianceBox({ expected, actual, unit, tolerancePct }) {
  const has = actual !== null && actual !== undefined;
  const variance = has ? r3(actual - expected) : null;
  const differs = has && variance !== 0;
  const pct = has && expected ? Math.round((variance / expected) * 1000) / 10 : null;
  const over = differs && tolerancePct !== undefined && tolerancePct !== null
    ? Math.abs(variance) > (Math.abs(expected) * tolerancePct) / 100 + 1e-9 : differs;
  const color = !has ? C.sub : !differs ? C.success : over ? C.danger : C.warn;
  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      {[['Expected', fmt(expected, unit), C.text], ['Actual', has ? fmt(actual, unit) : '—', C.text],
        ['Variance', has ? `${variance > 0 ? '+' : ''}${fmt(variance, unit)}${pct !== null && differs ? ` (${pct > 0 ? '+' : ''}${pct}%)` : ''}` : '—', color]].map(([l, v, c]) => (
        <View key={l} style={{ flex: 1, backgroundColor: l === 'Variance' && has ? (differs ? (over ? C.dangerSoft : C.warnSoft) : C.successSoft) : '#F8F5F0', borderRadius: 12, padding: 10 }}>
          <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{l}</Text>
          <Text style={{ fontSize: 19, fontWeight: '800', color: c }}>{v}</Text>
        </View>
      ))}
    </View>
  );
}

// PIN pad for login and PIN entry.
export function PinPad({ value, onChange, maxLength = 6, onSubmit }) {
  const s = useScale();
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'];
  const press = (k) => {
    if (k === 'C') onChange('');
    else if (k === '⌫') onChange(value.slice(0, -1));
    else if (value.length < maxLength) {
      const next = value + k;
      onChange(next);
      if (onSubmit) onSubmit(next);
    }
  };
  return (
    <View style={{ gap: 12 }}>
      {[0, 1, 2, 3].map((r) => (
        <View key={r} style={{ flexDirection: 'row', gap: 12 }}>
          {keys.slice(r * 3, r * 3 + 3).map((k) => (
            <Pressable key={k} testID={`pin-${k}`} onPress={() => press(k)} style={({ pressed }) => ({
              flex: 1, height: 84 * s, borderRadius: 18, alignItems: 'center', justifyContent: 'center',
              backgroundColor: k === 'C' || k === '⌫' ? C.primarySoft : C.white, borderWidth: 2, borderColor: C.border,
              opacity: pressed ? 0.6 : 1,
            })}>
              <Text style={{ fontSize: 34, fontWeight: '800', color: C.text }}>{k}</Text>
            </Pressable>
          ))}
        </View>
      ))}
    </View>
  );
}

// A simple table that stays readable on phones (scrolls sideways if needed).
export function Table({ columns, rows, testID }) {
  return (
    <ScrollView horizontal testID={testID} contentContainerStyle={{ minWidth: '100%' }}>
      <View style={{ minWidth: '100%' }}>
        <View style={{ flexDirection: 'row', backgroundColor: C.primarySoft, borderTopLeftRadius: 10, borderTopRightRadius: 10 }}>
          {columns.map((c) => (
            <Text key={c.key} style={{ width: c.width || 110, padding: 8, fontWeight: '800', fontSize: 14, color: C.primaryDark, textAlign: c.align || 'left' }}>{c.title}</Text>
          ))}
        </View>
        {rows.map((r, i) => (
          <View key={i} style={{ flexDirection: 'row', backgroundColor: r._bg || (i % 2 ? '#FBF9F6' : C.white), borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            {columns.map((c) => (
              <Text key={c.key} style={{ width: c.width || 110, padding: 8, fontSize: 15, color: (r._color && r._color[c.key]) || C.text, fontWeight: c.bold ? '700' : '400', textAlign: c.align || 'left' }}>
                {r[c.key] === null || r[c.key] === undefined ? '—' : String(r[c.key])}
              </Text>
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

// ================= Version 2 building blocks =================

// Photos: take with camera or choose from gallery; shows thumbnails with remove buttons.
export function PhotoPicker({ value = [], onChange, label = 'Photos', required, testID }) {
  const ui = useUI();
  const [viewing, setViewing] = useState(null);
  const add = async (source) => {
    try {
      const { takePhoto } = require('../platform/photos.js');
      const uri = await takePhoto(source);
      if (uri) onChange(value.concat([uri]));
    } catch (e) {
      ui.alert({ title: 'Photo not added', message: e.message || String(e), tone: 'warn' });
    }
  };
  return (
    <View>
      <Label>{label}{required ? ' (required)' : ' (optional)'}</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {value.map((uri, i) => (
          <View key={uri + i} style={{ width: 110, height: 110, borderRadius: 12, overflow: 'hidden', borderWidth: 2, borderColor: C.border }}>
            <Pressable testID={testID ? `${testID}-view-${i}` : undefined} onPress={() => setViewing(i)} style={{ width: '100%', height: '100%' }}><Image source={{ uri }} style={{ width: '100%', height: '100%' }} /></Pressable>
            <Pressable onPress={() => onChange(value.filter((_, k) => k !== i))} style={{ position: 'absolute', top: 4, right: 4, backgroundColor: C.danger, borderRadius: 14, width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: C.white, fontWeight: '800' }}>✕</Text>
            </Pressable>
          </View>
        ))}
        <Pressable testID={testID ? `${testID}-camera` : undefined} onPress={() => add('camera')} style={({ pressed }) => ({ width: 110, height: 110, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: C.info, alignItems: 'center', justifyContent: 'center', backgroundColor: C.infoSoft, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 32 }}>📷</Text>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.info }}>Take photo</Text>
        </Pressable>
        <Pressable onPress={() => add('library')} style={({ pressed }) => ({ width: 110, height: 110, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 32 }}>🖼️</Text>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.sub }}>From gallery</Text>
        </Pressable>
      </View>
      {viewing !== null ? <PhotoViewer photos={value.map((u) => ({ uri: u }))} index={viewing} onClose={() => setViewing(null)} /> : null}
    </View>
  );
}

const two = (n) => String(n).padStart(2, '0');

// "Now" or a different time. value: null = now, or { h, m }. The different time can be typed, picked on the clock or
// chosen with "Now". (Kept for the bakery screens; new screens use TimeField with 'HH:MM' values.)
export function TimeEntry({ label, value, onChange, testID, usual }) {
  const now = new Date();
  const hhmm = value ? `${two(value.h)}:${two(value.m)}` : `${two(now.getHours())}:${two(now.getMinutes())}`;
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <Chips value={value ? 'other' : 'now'} testIDPrefix={testID} onChange={(x) => onChange(x === 'now' ? null : { h: now.getHours(), m: now.getMinutes() })}
        options={[{ value: 'now', label: `Now (${two(now.getHours())}:${two(now.getMinutes())})` }, { value: 'other', label: 'Enter a different time' }]} />
      {value ? (
        <View style={{ marginTop: 10, gap: 6 }}>
          <TimeField testID={testID ? `${testID}-time` : undefined} value={hhmm} usual={usual} showNow={false}
            onChange={(t) => { const m = /^(\d{2}):(\d{2})$/.exec(t || ''); if (m) onChange({ h: Number(m[1]), m: Number(m[2]) }); }} />
          <Text style={{ fontSize: 14, color: C.warn, fontWeight: '700' }}>Both times are recorded</Text>
        </View>
      ) : null}
    </View>
  );
}

// Drop-down: opens a large list (good for touch) with a search box when the list is long.
// Options: [{ value, label, hint }]. Option buttons have testID `${testID}-opt-${value}` (or optionTestID(value)).
export function Select({ label, value, options, onChange, placeholder = 'Tap to choose', testID, search, optionTestID, disabled }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const s = useScale();
  const opts = (options || []).map((o) => (typeof o === 'object' && o !== null ? o : { value: o, label: String(o) }));
  const cur = opts.find((o) => o.value === value);
  const withSearch = search === undefined ? opts.length > 6 : !!search;
  const ql = q.trim().toLowerCase();
  const shown = ql ? opts.filter((o) => `${o.label} ${o.hint || ''} ${o.value}`.toLowerCase().includes(ql)) : opts;
  const close = () => { setOpen(false); setQ(''); };
  const oid = (v) => (optionTestID ? optionTestID(v) : testID ? `${testID}-opt-${v}` : undefined);
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <Pressable testID={testID} disabled={disabled} onPress={() => setOpen(true)} style={({ pressed }) => ({ minHeight: 64 * s, borderRadius: 12, borderWidth: 2, borderColor: cur ? C.info : C.border, backgroundColor: disabled ? '#EEE9E1' : C.white, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ flex: 1, fontSize: 19, fontWeight: cur ? '800' : '400', color: cur ? C.text : '#A39886' }} numberOfLines={2}>{cur ? cur.label : placeholder}</Text>
        <Text style={{ fontSize: 20, color: C.sub }}>▾</Text>
      </Pressable>
      <Modal visible={open} transparent animationType="fade" onRequestClose={close}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
          <View style={{ backgroundColor: C.card, borderRadius: 18, padding: 16, width: '100%', maxWidth: 560, maxHeight: '90%' }}>
            <Text style={{ fontSize: 22, fontWeight: '800', marginBottom: 10, color: C.text }}>{label || 'Choose'}</Text>
            {withSearch ? (
              <TextInput testID={testID ? `${testID}-search` : undefined} value={q} onChangeText={setQ} placeholder="🔍 Type to search" placeholderTextColor="#A39886" autoFocus={opts.length > 12}
                style={{ backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 19, color: C.text, minHeight: 54, marginBottom: 10 }} />
            ) : null}
            <ScrollView keyboardShouldPersistTaps="handled">
              {shown.map((o) => (
                <Pressable key={String(o.value)} testID={oid(o.value)} onPress={() => { close(); onChange(o.value); }}
                  style={({ pressed }) => ({ minHeight: 60, justifyContent: 'center', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, marginBottom: 6, backgroundColor: o.value === value ? C.infoSoft : '#F7F4F0', opacity: pressed ? 0.6 : 1 })}>
                  <Text style={{ fontSize: 19, fontWeight: '700', color: C.text }}>{o.value === value ? '✓ ' : ''}{o.label}</Text>
                  {o.hint ? <Text style={{ fontSize: 14, color: C.sub }}>{o.hint}</Text> : null}
                </Pressable>
              ))}
              {!shown.length ? <Text style={{ fontSize: 17, color: C.sub, padding: 12 }}>Nothing matches “{q}”.</Text> : null}
            </ScrollView>
            <Btn title="Cancel" variant="secondary" size="md" style={{ marginTop: 10 }} onPress={close} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

// One choice: big chips when there are only a few options (max, default 5), otherwise a searchable drop-down.
// testIDs: chips `${testIDPrefix}-${value}`; drop-down button `${testIDPrefix}`, its options `${testIDPrefix}-${value}`.
export function Choice({ label, value, onChange, options, testIDPrefix, max = 5, placeholder, search }) {
  const opts = (options || []).map((o) => (typeof o === 'object' && o !== null ? o : { value: o, label: String(o) }));
  if (opts.length <= max) {
    return (
      <View>
        {label ? <Label>{label}</Label> : null}
        <Chips value={value} onChange={onChange} options={opts} testIDPrefix={testIDPrefix} />
      </View>
    );
  }
  return <Select label={label} value={value} onChange={onChange} options={opts} placeholder={placeholder} search={search} testID={testIDPrefix}
    optionTestID={testIDPrefix ? (v) => `${testIDPrefix}-${v}` : undefined} />;
}

// Editable list of email addresses.
export function EmailList({ label, value = [], onChange, testID }) {
  const [text, setText] = useState('');
  const add = () => {
    const e = text.trim();
    if (!e) return;
    onChange(value.concat([e]));
    setText('');
  };
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      {value.length ? value.map((e, i) => (
        <View key={e + i} style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#F7F4F0', borderRadius: 10, padding: 10, marginBottom: 6 }}>
          <Text style={{ flex: 1, fontSize: 17, color: C.text }}>✉️  {e}</Text>
          <Btn title="Remove" size="sm" variant="ghost" onPress={() => onChange(value.filter((_, k) => k !== i))} />
        </View>
      )) : <Text style={{ fontSize: 15, color: C.sub, marginBottom: 6 }}>No email addresses yet.</Text>}
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        <View style={{ flex: 1 }}><Field testID={testID} value={text} onChangeText={setText} placeholder="name@example.com" keyboardType="email-address" /></View>
        <Btn testID={testID ? `${testID}-add` : undefined} title="Add" size="md" onPress={add} />
      </View>
    </View>
  );
}

// Visual timeline of a batch's steps.
export function StepTimeline({ steps, currentIdx }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
      {steps.map((s, i) => {
        const done = !!s.started_at;
        const cur = i === currentIdx && s.kind !== 'finish';
        const bg = cur ? C.info : done ? C.success : '#ECE7E1';
        return (
          <View key={s.idx} style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ backgroundColor: bg, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 }}>
              <Text style={{ color: done || cur ? C.white : C.sub, fontWeight: '800', fontSize: 17 }}>{s.name}</Text>
              <Text style={{ color: done || cur ? C.white : C.sub, fontSize: 14 }}>{s.started_at ? s.started_at.slice(11, 16) : s.due_at ? `due ${s.due_at.slice(11, 16)}` : s.minutes ? `${s.minutes} min` : ''}</Text>
            </View>
            {i < steps.length - 1 ? <Text style={{ marginHorizontal: 4, color: C.sub, fontSize: 16 }}>›</Text> : null}
          </View>
        );
      })}
    </View>
  );
}

// Countdown / overdue text that updates every second.
export function useTick(ms = 1000) {
  const [, set] = useState(0);
  useEffect(() => {
    const t = setInterval(() => set((n) => n + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
}
export function countdown(seconds) {
  if (seconds === null || seconds === undefined) return '';
  const s = Math.abs(seconds);
  const m = Math.floor(s / 60);
  const txt = m >= 60 ? `${Math.floor(m / 60)}h ${two(m % 60)}m` : `${m}:${two(s % 60)}`;
  return seconds < 0 ? `${txt} overdue` : `in ${txt}`;
}

export function Section({ title, children, right }) {
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 2, borderBottomColor: C.brandRed, paddingBottom: 4 }}>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{title}</Text>
        {right || null}
      </View>
      {children}
    </View>
  );
}
