import { isPaperPhoto } from './paperWords.js';
import { keyboardFor } from './keyboardFor.js';
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useIsTourTarget, TOUR_OUTLINE } from './tourTarget.js';
import { View, Pressable, ScrollView, useWindowDimensions, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { crumb } from '../services/breadcrumbs.js';
import { Text, TextInput, useScale } from './scale.js';
import { SyncBar, SizeButton, SyncDot } from './chrome.js';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Icon from './Icon.js';
import { useWide, W } from './wide.js';
import { C, ROLE_COLOR } from './theme.js';
import { fmt, r3 } from '../services/core.js';
import { ROLE_LABEL } from '../services/access.js';

export const LOGO = require('../../assets/logo.png');

// ================= App context (user + navigation) =================
export { AppContext, useApp } from './appContext.js';
import { PhotoViewer } from './photoView.js';
import { useApp } from './appContext.js';
import { remember, recall, screenKey } from './memory.js';
import { TimeField } from './timePicker.js';
import { SafeModal, useEdgeInsets } from './safeModal.js';
export { TimeField } from './timePicker.js';

export function useLayout() {
  const { width } = useWindowDimensions();
  const s = useScale();
  const w = width / Math.max(0.8, s);            // bigger display size = fewer columns
  return { width, isTablet: width >= 700, isPhone: width < 500, cols: w >= 1000 ? 4 : w >= 700 ? 3 : w >= 330 ? 2 : 1 };
}

// Like useState, but the value is kept when the person opens another screen and comes back (filters, search text, tabs).
export function useRemembered(name, initial) {
  const app = useApp();
  const k = `${screenKey(app) || 'screen'}|${name}`;
  const [v, setV] = useState(() => { const r = recall(k); return r !== undefined ? r : typeof initial === 'function' ? initial() : initial; });
  const set = useCallback((x) => setV((old) => { const nv = typeof x === 'function' ? x(old) : x; remember(k, nv); return nv; }), [k]);
  return [v, set];
}

// Release 07 (the new look): the search box in the website's header – what is typed there shows the results on Today.
const searchBus = { q: '', subs: new Set() };
export function setHeaderSearch(q) { searchBus.q = String(q || ''); searchBus.subs.forEach((f) => { try { f(searchBus.q); } catch (e) { /* gone */ } }); }
export function useHeaderSearch() {
  const [q, setQ] = useState(searchBus.q);
  useEffect(() => { searchBus.subs.add(setQ); return () => { searchBus.subs.delete(setQ); }; }, []);
  return q;
}
function HeaderSearch({ app }) {
  const q = useHeaderSearch();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.line, borderRadius: 8, paddingHorizontal: 12, height: 40, flexGrow: 1, flexShrink: 1, maxWidth: 420, minWidth: 220 }}>
      <Icon name="search" emoji="🔍" size={16} color={C.sub} strokeWidth={2} />
      <TextInput testID="header-search" value={q} placeholder="Search invoices, cheques, staff…" placeholderTextColor={C.sub} accessibilityLabel="Search"
        onChangeText={(t) => { setHeaderSearch(t); if (app && app.canGoBack && app.nav && app.nav.home) app.nav.home(); }}
        style={{ flex: 1, fontSize: 14, color: C.text, outlineStyle: 'none', borderWidth: 0, backgroundColor: 'transparent', height: 38 }} />
    </View>
  );
}

// ================= Toasts & dialogs =================
const UIContext = createContext(null);
export const useUI = () => useContext(UIContext);

export function UIProvider({ children }) {
  const [toast, setToast] = useState(null);
  const [dialog, setDialog] = useState(null);
  const [unlock, setUnlock] = useState(null);
  const timer = useRef(null);
  const edge = useEdgeInsets(); // v3.9.4 toasts stay above the navigation bar / taskbar

  const api = useRef({
    toast(message, tone = 'success') {
      clearTimeout(timer.current);
      setToast({ message, tone });
      timer.current = setTimeout(() => setToast(null), 3500);
    },
    // Returns a promise that resolves to true (confirm) or false (cancel).
    confirm({ title, message, confirmText = 'Yes, continue', cancelText = 'Cancel', tone = 'primary' }) {
      return new Promise((resolve) => {
        setDialog({
          title, message, tone,
          buttons: [
            { text: cancelText, variant: 'secondary', onPress: () => resolve(false) },
            { text: confirmText, variant: tone, onPress: () => resolve(true) },
          ],
        });
      });
    },
    // 1.0.0 build 10: several answers (the first one is what the back button gives). Resolves to the chosen value.
    choose({ title, message, tone = 'primary', options = [] }) {
      return new Promise((resolve) => {
        setDialog({ title, message, tone, buttons: options.map((o) => ({ text: o.text, variant: o.variant || 'secondary', testID: o.testID, onPress: () => resolve(o.value) })) });
      });
    },
    alert({ title, message, tone = 'primary', okText = 'OK' }) {
      return new Promise((resolve) => {
        setDialog({ title, message, tone, buttons: [{ text: okText, variant: tone, onPress: () => resolve(true) }] });
      });
    },
    // Show an error from a failed action in plain language.
    error(e) {
      if (e && e.cancelled) return Promise.resolve(false); // closed on purpose (e.g. the document preview) – not an error
      // 1.0.0 build 1: a locked setting – the owner types the PIN again and a reason, then presses Save again.
      if (e && e.code === 'LOCKED') { setUnlock({ area: e.area, what: e.what, message: e.message, pin: '', reason: '', error: '' }); return Promise.resolve(false); }
      const raw = e && e.message ? e.message : String(e);
      // v3.9.3 plain words for the problems a person can fix themselves
      if (/disk is full|SQLITE_FULL|ENOSPC|no space left|not enough space|quota/i.test(raw)) return this.alert({ title: 'The device is full', message: 'Nothing was saved because this tablet / phone has no free space. Delete old photos, videos or apps (Android Settings › Storage), then try again. Everything saved before is safe.', tone: 'danger' });
      if (/database is locked|SQLITE_BUSY/i.test(raw)) return this.alert({ title: 'Busy – try again', message: 'The app was busy saving something else. Wait a moment and tap again. Nothing was half saved.', tone: 'warn' });
      if (/cloud is busy/i.test(raw) || (e && e.busy)) return this.alert({ title: 'The cloud is busy', message: 'Other phones are syncing right now. Wait a moment and try again – nothing is lost.', tone: 'warn' });
      if (/Network request failed|Failed to fetch|network|timed? ?out|aborted/i.test(raw) && !(e && e.isAppError)) return this.alert({ title: 'No internet', message: 'This needs the internet and the connection dropped. Everything saved on the device is safe – try again when online.', tone: 'warn' });
      const message = e && e.isAppError ? e.message : `Something went wrong: ${raw}`;
      try { if (!(e && e.isAppError)) require('../services/errorLog.js').logError(e, { where: 'action' }); } catch (x) { /* the log is best effort */ }
      return this.alert({ title: 'Cannot save', message, tone: 'danger' });
    },
  }).current;

  const toneColor = { success: C.success, danger: C.danger, warn: C.warn, primary: C.primary, info: C.info };

  return (
    <UIContext.Provider value={api}>
      {children}
      {toast ? (
        <View pointerEvents="none" style={{ position: 'absolute', left: 16, right: 16, bottom: 40 + edge.bottom, alignItems: 'center', zIndex: 50, elevation: 50 }}>
          <View testID="toast" style={{ backgroundColor: toneColor[toast.tone] || C.success, paddingVertical: 16, paddingHorizontal: 22, borderRadius: 14, maxWidth: 640, elevation: 6 }}>
            <Text style={{ color: C.white, fontSize: 18, fontWeight: '700', textAlign: 'center' }}>
              {toast.tone === 'success' ? '✓  ' : ''}{toast.message}
            </Text>
          </View>
        </View>
      ) : null}
      <SafeModal visible={!!dialog} transparent animationType="fade" onRequestClose={() => {
        if (dialog) { const b = dialog.buttons[0]; setDialog(null); b.onPress(); }
      }}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          {dialog ? (
            <View testID="dialog" style={{ backgroundColor: C.card, borderRadius: 18, padding: 24, width: '100%', maxWidth: 560 }}>
              <Text style={{ fontSize: 24, fontWeight: '800', color: dialog.tone === 'danger' ? C.danger : dialog.tone === 'warn' ? C.warn : C.text, marginBottom: 10 }}>
                {dialog.title}
              </Text>
              {dialog.message ? <Text style={{ fontSize: 18, color: C.text, lineHeight: 26, marginBottom: 20 }}>{dialog.message}</Text> : null}
              {/* 1.0.0 build 12: four or more answers stack (the main one on top, the back-button one last) */}
              <View style={{ flexDirection: dialog.buttons.length >= 4 ? 'column' : 'row', gap: 12 }}>
                {(dialog.buttons.length >= 4 ? dialog.buttons.slice().reverse() : dialog.buttons).map((b) => (
                  <Btn key={b.text} testID={b.testID} title={b.text} variant={b.variant} style={dialog.buttons.length >= 4 ? undefined : { flex: 1 }}
                    onPress={() => { setDialog(null); b.onPress(); }} />
                ))}
              </View>
            </View>
          ) : null}
        </View>
      </SafeModal>
      <SafeModal visible={!!unlock} transparent animationType="fade" onRequestClose={() => setUnlock(null)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          {unlock ? (
            <View testID="unlock-dialog" style={{ backgroundColor: C.card, borderRadius: 18, padding: 24, width: '100%', maxWidth: 560, gap: 10 }}>
              <Text style={{ fontSize: 24, fontWeight: '800', color: C.text }}>🔒 Owner PIN needed</Text>
              <Text style={{ fontSize: 17, color: C.text, lineHeight: 24 }}>{unlock.message}</Text>
              <Field testID="unlock-pin" label="Owner PIN" value={unlock.pin} secure keyboardType="number-pad" maxLength={6} onChangeText={(v) => setUnlock((u) => ({ ...u, pin: v.replace(/\D/g, ''), error: '' }))} />
              <Field testID="unlock-reason" label="Why is it being changed?" value={unlock.reason} onChangeText={(v) => setUnlock((u) => ({ ...u, reason: v, error: '' }))} />
              {unlock.error ? <Text testID="unlock-error" style={{ color: C.danger, fontSize: 16, fontWeight: '700' }}>{unlock.error}</Text> : null}
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <Btn testID="unlock-cancel" title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setUnlock(null)} />
                <Btn testID="unlock-go" title="Unlock for 2 minutes" variant="primary" style={{ flex: 1 }} onPress={() => {
                  try {
                    const L = require('../services/locked.js');
                    const me = require('../services/errorLog.js').appUser();
                    L.unlock(me, unlock.area, unlock.pin, unlock.reason);
                    setUnlock(null);
                    api.toast('Unlocked for 2 minutes – press Save again');
                  } catch (x) { setUnlock((u) => ({ ...u, error: x && x.message ? x.message : String(x), pin: '' })); }
                }} />
              </View>
            </View>
          ) : null}
        </View>
      </SafeModal>
    </UIContext.Provider>
  );
}

// ================= Buttons =================
const VARIANTS = {
  primary: { bg: C.primary, fg: C.white, border: C.primary },
  success: { bg: C.success, fg: C.white, border: C.success },
  danger: { bg: C.danger, fg: C.white, border: C.danger },
  warn: { bg: C.warn, fg: C.white, border: C.warn },
  info: { bg: C.info, fg: C.white, border: C.info },
  secondary: { bg: C.white, fg: C.text, border: C.border },
  ghost: { bg: 'transparent', fg: C.primary, border: 'transparent' },
};

export function Btn({ title, onPress, variant = 'primary', size = 'lg', icon, disabled, style, testID }) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = useScale();
  const tourOn = useIsTourTarget(testID);
  const wide = useWide();
  const h = wide ? (size === 'lg' ? 48 : size === 'md' ? 44 : 36) : (size === 'lg' ? 72 : size === 'md' ? 60 : 52) * s;
  // v3.9.3 a double tap never saves twice: while an action is still running, and for a moment after a save-type
  // button (green / red / orange), further taps are ignored.
  const busy = useRef(false);
  const last = useRef(0);
  const press = (e) => {
    if (!onPress || busy.current) return;
    try { crumb('tap', String(testID || title || icon || 'button').slice(0, 60)); } catch (x) { /* ignore */ }
    const now = Date.now();
    if (['success', 'danger', 'warn'].includes(variant) && now - last.current < 700) return;
    last.current = now;
    let r;
    try { r = onPress(e); } catch (err) { throw err; }
    if (r && typeof r.then === 'function') { busy.current = true; const free = () => { busy.current = false; }; const t = setTimeout(free, 30000); r.then(() => { clearTimeout(t); free(); }, () => { clearTimeout(t); free(); }); }
  };
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled}
      onPress={press}
      style={({ pressed, hovered }) => [{
        minHeight: h, borderRadius: wide ? (size === 'lg' ? 10 : 8) : 14, borderWidth: wide ? 1 : 2, paddingHorizontal: wide ? (size === 'sm' ? 14 : 18) : 18,
        alignItems: 'center', justifyContent: 'center', flexDirection: 'row',
        backgroundColor: disabled ? C.disabled : (wide && hovered && variant === 'secondary' ? W.bg : v.bg), borderColor: disabled ? C.disabled : (wide && variant === 'secondary' ? W.btnBorder : v.border),
        opacity: pressed ? 0.75 : (wide && hovered && variant !== 'secondary' && variant !== 'ghost' ? 0.9 : 1),
      }, style, tourOn ? TOUR_OUTLINE : null]}
    >
      {icon ? <Text style={{ fontSize: wide ? 16 : size === 'lg' ? 22 : 18, marginRight: 8 }}>{icon}</Text> : null}
      <Text style={{ color: disabled ? C.white : v.fg, fontSize: wide ? (size === 'sm' ? 13 : 14) : size === 'lg' ? 22 : size === 'md' ? 19 : 17, fontWeight: wide ? '600' : '800', textAlign: 'center' }}>
        {title}
      </Text>
    </Pressable>
  );
}

// Large menu tile used on home screens.
export function Tile({ title, subtitle, icon, onPress, color = C.primary, disabled, badge, testID }) {
  const s = useScale();
  const tourOn = useIsTourTarget(testID);
  const { isPhone } = useLayout();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: disabled ? '#EEE9E1' : C.card, borderRadius: 20, padding: isPhone ? 12 : 18, minHeight: (isPhone ? 120 : 160) * s,
        borderWidth: 2, borderColor: disabled ? C.border : color, justifyContent: 'center', alignItems: 'center',
        opacity: pressed ? 0.7 : 1, elevation: disabled ? 0 : 2, ...(tourOn ? TOUR_OUTLINE : {}),
      })}
    >
      <Text style={{ fontSize: isPhone ? 36 : 48, marginBottom: 6, opacity: disabled ? 0.4 : 1 }}>{icon}</Text>
      <Text style={{ fontSize: 22, fontWeight: '800', color: disabled ? C.sub : C.text, textAlign: 'center' }}>{title}</Text>
      {subtitle ? <Text style={{ fontSize: 16, color: C.sub, textAlign: 'center', marginTop: 4 }}>{subtitle}</Text> : null}
      {badge ? (
        <View style={{ position: 'absolute', top: 10, right: 10, backgroundColor: C.danger, borderRadius: 12, paddingHorizontal: 8, paddingVertical: 2 }}>
          <Text style={{ color: C.white, fontWeight: '800', fontSize: 14 }}>{badge}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

// Responsive grid. Children are laid out in equal columns.
export function Grid({ children, cols, gap = 14 }) {
  const layout = useLayout();
  const n = cols || layout.cols;
  const items = React.Children.toArray(children).filter(Boolean);
  const rows = [];
  for (let i = 0; i < items.length; i += n) rows.push(items.slice(i, i + n));
  return (
    <View style={{ gap }}>
      {rows.map((row, ri) => (
        <View key={ri} style={{ flexDirection: 'row', gap }}>
          {row.map((child, ci) => <View key={ci} style={{ flex: 1 }}>{child}</View>)}
          {row.length < n ? Array.from({ length: n - row.length }).map((_, k) => <View key={'f' + k} style={{ flex: 1 }} />) : null}
        </View>
      ))}
    </View>
  );
}

// ================= Layout =================
export function Screen({ title, subtitle, onBack, children, footer, scroll = true, hideUser, right, hideSync, bare }) {
  const app = useApp();
  const insets = useSafeAreaInsets();
  const { isPhone, width } = useLayout();
  const wideWeb = Platform.OS === 'web' && width >= 1100; // build 48: the website on a computer screen uses the width
  const maxW = wideWeb ? 1600 : 1100;
  const back = onBack || (app && app.canGoBack ? app.nav.pop : null);
  const user = app && app.user;
  const Body = scroll ? ScrollView : View;
  // Scroll position remembered for this screen, so going back returns to the same place.
  const sk = screenKey(app);
  const bodyRef = useRef(null);
  const pendingY = useRef(sk ? recall(`${sk}|scroll`) || 0 : 0);
  useEffect(() => { const t = setTimeout(() => { pendingY.current = 0; }, 2500); return () => clearTimeout(t); }, []);
  const onScroll = (e) => { if (sk && !pendingY.current) remember(`${sk}|scroll`, e.nativeEvent.contentOffset.y); };
  const onContentSizeChange = (w, h) => {
    const y = pendingY.current;
    if (y > 0 && bodyRef.current && bodyRef.current.scrollTo) {
      bodyRef.current.scrollTo({ y, animated: false });
      if (h >= y) pendingY.current = 0;
    }
  };
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {wideWeb ? (
        // Release 07 (the new look, from the approved design): on a computer the header is a thin white bar – red line
        // on top, back, help, size and the person on the right – and the page title sits large in the page itself.
        <View style={{ backgroundColor: C.white, borderTopWidth: 4, borderTopColor: C.brandRed, borderBottomWidth: 1, borderBottomColor: C.border, paddingVertical: 10, paddingHorizontal: 28, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          {back ? (
            <Pressable testID="back" onPress={back} accessibilityRole="button" style={({ pressed, hovered }) => ({ height: 40, paddingHorizontal: 14, borderRadius: 8, borderWidth: 1, borderColor: C.border, backgroundColor: hovered ? C.hover : C.white, justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
              <Text style={{ color: C.text, fontSize: 14, fontWeight: '600' }}>‹ Back</Text>
            </Pressable>
          ) : null}
          {app && app.user ? <HeaderSearch app={app} /> : null}
          {!scroll ? (
            <View style={{ flex: 1, marginLeft: 6 }}>
              <Text accessibilityRole="header" style={{ color: C.text, fontSize: 20, fontWeight: '700' }} numberOfLines={1}>{title}</Text>
              {subtitle ? <Text style={{ color: C.sub, fontSize: 13 }} numberOfLines={1}>{subtitle}</Text> : null}
            </View>
          ) : <View style={{ flex: 1 }} />}
          {right || null}
          {hideSync ? null : <SyncDot />}
          <HelpButton app={app} />
          <SizeButton />
          {user && !hideUser ? (
            <Pressable testID="logout" onPress={app.signOutWeb ? app.signOutWeb : app.logout} style={({ pressed, hovered }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4, paddingHorizontal: 10, borderRadius: 10, backgroundColor: hovered ? C.hover : 'transparent', marginLeft: 6, opacity: pressed ? 0.6 : 1 })}>
              <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: C.infoSoft, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: C.brandBlue, fontWeight: '700', fontSize: 13 }}>{String(user.name || '?').split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase()}</Text>
              </View>
              <View>
                <Text style={{ color: C.text, fontSize: 13, fontWeight: '600' }} numberOfLines={1}>{user.name}</Text>
                <Text style={{ color: C.sub, fontSize: 12 }} numberOfLines={1}>{`${ROLE_LABEL[user.role] || user.role} · Log out`}</Text>
              </View>
            </Pressable>
          ) : null}
        </View>
      ) : (
      // Release 18 (the new look on phones and tablets): a white header with the red line on top and a thin line below
      <View style={{ backgroundColor: C.white, paddingTop: insets.top + (isPhone ? 6 : 8), paddingBottom: isPhone ? 8 : 10, paddingHorizontal: isPhone ? 12 : 14, flexDirection: 'row', alignItems: 'center', borderTopWidth: 4, borderTopColor: C.brandRed, borderBottomWidth: 1, borderBottomColor: '#E3DDD3' }}>
        {back ? (
          <Pressable testID="back" onPress={back} style={({ pressed }) => ({ paddingVertical: isPhone ? 10 : 14, paddingHorizontal: isPhone ? 10 : 18, borderRadius: 12, backgroundColor: C.primarySoft, marginRight: isPhone ? 8 : 12, opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ color: C.primary, fontSize: isPhone ? 18 : 20, fontWeight: '800' }}>{isPhone ? '‹' : '‹ Back'}</Text>
          </Pressable>
        ) : (
          isPhone ? null : <Image source={LOGO} style={{ width: 92, height: 41, marginRight: 12 }} resizeMode="contain" />
        )}
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.text, fontSize: isPhone ? 18 : 21, fontWeight: '800' }} numberOfLines={1}>{title}</Text>
          {subtitle ? <Text style={{ color: C.sub, fontSize: 14 }} numberOfLines={1}>{subtitle}</Text> : null}
        </View>
        {right || null}
        <HelpButton app={app} />
        <SizeButton />
        {user && !hideUser ? (
          <Pressable testID="logout" onPress={Platform.OS === 'web' && app.signOutWeb ? app.signOutWeb : app.logout} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4, paddingLeft: 4, paddingRight: isPhone ? 8 : 12, borderRadius: 22, backgroundColor: '#F4F1EC', marginLeft: 8, opacity: pressed ? 0.6 : 1, maxWidth: isPhone ? 130 : 240 })}>
            <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: '#E1EAFB', alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: '#2F5FC4', fontWeight: '700', fontSize: 13 }}>{String(user.name || '?').split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase()}</Text>
            </View>
            <View style={{ flexShrink: 1 }}>
              <Text style={{ color: C.text, fontSize: isPhone ? 13 : 15, fontWeight: '700' }} numberOfLines={1}>{isPhone ? user.name.split(' ')[0] : user.name}</Text>
              <Text style={{ color: C.sub, fontSize: isPhone ? 11 : 13 }} numberOfLines={1}>{isPhone ? 'Log out' : `${ROLE_LABEL[user.role] || user.role} · Log out`}</Text>
            </View>
          </Pressable>
        ) : null}
      </View>
      )}
      {hideSync ? null : <SyncBar />}
      <Body ref={scroll ? bodyRef : undefined} style={{ flex: 1 }} contentContainerStyle={scroll ? (wideWeb ? { paddingVertical: 28, paddingHorizontal: 32, paddingBottom: 40 } : { padding: isPhone ? 10 : 16, paddingBottom: 40 }) : undefined} keyboardShouldPersistTaps="handled"
        {...(scroll ? { onScroll, scrollEventThrottle: 100, onContentSizeChange } : {})}>
        {scroll ? <View style={{ width: '100%', maxWidth: wideWeb ? 1400 : maxW, alignSelf: wideWeb ? 'flex-start' : 'center', gap: isPhone ? 10 : wideWeb ? 24 : 14 }}>
          {wideWeb && !bare ? (
            <View style={{ paddingTop: 10, paddingBottom: 4 }}>
              {subtitle ? <Text style={{ color: C.sub, fontSize: 13 }} numberOfLines={1}>{subtitle}</Text> : null}
              <Text accessibilityRole="header" style={{ color: C.text, fontSize: 28, fontWeight: '700', letterSpacing: -0.3 }} numberOfLines={2}>{title}</Text>
            </View>
          ) : null}
          <FirstTip app={app} />{children}</View> : children}
      </Body>
      {footer ? (
        <View style={{ padding: isPhone ? 8 : 12, paddingBottom: (isPhone ? 8 : 12) + insets.bottom, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.border }}>
          <View style={{ width: '100%', maxWidth: maxW, alignSelf: 'center' }}>{footer}</View>
        </View>
      ) : <View style={{ height: insets.bottom }} />}
    </KeyboardAvoidingView>
  );
}

// v3.9.2 ❓ on any screen that has a guide; and the first time someone opens such a screen, a short tip offers it.
function screenGuide(app) {
  try { const cur = app && app.currentScreen; if (!cur || !cur.name || cur.name === 'Help' || cur.name === 'HelpGuide') return null; return require('../services/guides.js').guidesForScreen(cur.name)[0] || null; } catch (e) { return null; }
}
function HelpButton({ app }) {
  const g = screenGuide(app);
  if (!g || !app || !app.user) return null;
  return (
    <Pressable testID="help-btn" accessibilityLabel="Help for this screen" onPress={() => app.nav.push('HelpGuide', { id: g.id })} style={({ pressed }) => ({ paddingVertical: 8, paddingHorizontal: 12, borderRadius: 12, backgroundColor: C.infoSoft, marginLeft: 6, opacity: pressed ? 0.6 : 1 })}>
      <Text style={{ fontSize: 18, fontWeight: '900', color: C.info }}>?</Text>
    </Pressable>
  );
}
function FirstTip({ app }) {
  const [, bump] = useState(0);
  const g = screenGuide(app);
  if (!g || !app || !app.user) return null;
  let G = null;
  try { G = require('../services/guides.js'); } catch (e) { return null; }
  if (G.tipSeen(app.user, g.id)) return null;
  return (
    <View testID="first-tip" style={{ backgroundColor: C.infoSoft, borderRadius: 12, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
      <Text style={{ fontSize: 15, color: C.text, flex: 1, minWidth: 180 }}>💡 New here? How this works: <Text style={{ fontWeight: '800' }}>{g.title}</Text></Text>
      <Pressable testID="first-tip-show" onPress={() => app.nav.push('HelpGuide', { id: g.id })} style={{ paddingVertical: 6, paddingHorizontal: 12, borderRadius: 10, backgroundColor: C.info }}><Text style={{ color: C.white, fontWeight: '800' }}>Show me</Text></Pressable>
      <Pressable testID="first-tip-ok" onPress={() => { G.markTipSeen(app.user, g.id); bump((x) => x + 1); }} style={{ paddingVertical: 6, paddingHorizontal: 12, borderRadius: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border }}><Text style={{ color: C.text, fontWeight: '800' }}>Got it</Text></Pressable>
    </View>
  );
}

export function Card({ children, style, tone }) {
  const border = tone === 'warn' ? C.warn : tone === 'danger' ? C.danger : tone === 'success' ? C.success : tone === 'info' ? C.info : C.border;
  const wide = useWide();
  if (wide) {
    // the design: white, 1px border, 12px corners; a warning card keeps a coloured bar down its left side
    return (
      <View style={[{ backgroundColor: C.card, borderRadius: 12, padding: 20, borderWidth: 1, borderColor: C.border, gap: 6 }, tone ? { borderLeftWidth: 4, borderLeftColor: border } : null, style]}>
        {children}
      </View>
    );
  }
  return (
    <View style={[{ backgroundColor: C.card, borderRadius: 16, padding: 16, borderWidth: tone ? 2 : 1, borderColor: border }, style]}>
      {children}
    </View>
  );
}

export function H({ children, style }) {
  return <Text style={[{ fontSize: 20, fontWeight: '800', color: C.text, marginBottom: 8 }, style]}>{children}</Text>;
}

export function Label({ children }) {
  return <Text style={{ fontSize: 17, fontWeight: '700', color: C.sub, marginBottom: 8 }}>{children}</Text>;
}

export function P({ children, style }) {
  return <Text style={[{ fontSize: 17, color: C.text, lineHeight: 24 }, style]}>{children}</Text>;
}

export function Row({ label, value, bold, color }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
      <Text style={{ fontSize: 17, color: C.sub, flex: 1 }}>{label}</Text>
      <Text style={{ fontSize: 17, color: color || C.text, fontWeight: bold ? '800' : '600', textAlign: 'right' }}>{value}</Text>
    </View>
  );
}

export function Banner({ tone = 'info', title, message, testID }) {
  const map = {
    info: [C.infoSoft, C.info, 'ℹ️'], warn: [C.warnSoft, C.warn, '⚠️'],
    danger: [C.dangerSoft, C.danger, '⛔'], success: [C.successSoft, C.success, '✅'],
  };
  const [bg, fg, icon] = map[tone] || map.info;
  return (
    <View testID={testID} style={{ backgroundColor: bg, borderLeftWidth: 6, borderLeftColor: fg, borderRadius: 12, padding: 14, flexDirection: 'row' }}>
      <Text style={{ fontSize: 22, marginRight: 10 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        {title ? <Text style={{ fontSize: 18, fontWeight: '800', color: fg }}>{title}</Text> : null}
        {message ? <Text style={{ fontSize: 16, color: C.text, marginTop: title ? 2 : 0, lineHeight: 22 }}>{message}</Text> : null}
      </View>
    </View>
  );
}

export function Badge({ text, color = C.info }) {
  return (
    <View style={{ backgroundColor: color, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3, alignSelf: 'flex-start' }}>
      <Text style={{ color: C.white, fontSize: 13, fontWeight: '800' }}>{text}</Text>
    </View>
  );
}

export function RoleBadge({ role }) {
  return <Badge text={ROLE_LABEL[role] || role} color={ROLE_COLOR[role]} />;
}

export function Empty({ text }) {
  return (
    <View style={{ padding: 30, alignItems: 'center' }}>
      <Text style={{ fontSize: 40 }}>📭</Text>
      <Text style={{ fontSize: 18, color: C.sub, marginTop: 8, textAlign: 'center' }}>{text}</Text>
    </View>
  );
}

// ================= Inputs =================
export function Field({ label, value, onChangeText, placeholder, keyboardType, secure, multiline, maxLength, testID, lettersToo = true }) {
  // build 33: a number box opens the number keypad by itself (keyboardFor); the owner: "an option should be there to
  // get the alphabetical keyboard too, but it should open the numbers first" – the ABC / 123 button beside the box.
  const auto = keyboardType || keyboardFor(label, { multiline });
  const numeric = ['number-pad', 'decimal-pad', 'numeric', 'phone-pad'].includes(auto);
  const [letters, setLetters] = useState(false);
  const input = useRef(null);
  const swap = () => {
    setLetters((x) => !x);
    // the keyboard changes when the box is focused again
    try { if (input.current && input.current.isFocused && input.current.isFocused()) { input.current.blur(); setTimeout(() => { try { input.current.focus(); } catch (e) { /* closed */ } }, 80); } } catch (e) { /* no keyboard */ }
  };
  const canSwap = numeric && !secure && lettersToo;
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <View style={{ flexDirection: 'row', alignItems: 'stretch', gap: 8 }}>
        <TextInput
          ref={input}
          testID={testID}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#A39886"
          keyboardType={letters ? 'default' : auto}
          secureTextEntry={secure}
          multiline={multiline}
          maxLength={maxLength}
          style={{
            flex: 1,
            backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12,
            paddingHorizontal: 14, paddingVertical: 12, fontSize: 20, color: C.text,
            minHeight: multiline ? 96 : 62, textAlignVertical: multiline ? 'top' : 'center',
          }}
        />
        {canSwap ? (
          <Pressable testID={testID ? `${testID}-abc` : undefined} onPress={swap} accessibilityLabel={letters ? 'Number keypad' : 'Letters keyboard'}
            style={({ pressed }) => ({ width: 62, borderRadius: 12, borderWidth: 2, borderColor: C.border, backgroundColor: pressed ? C.border : C.white, alignItems: 'center', justifyContent: 'center' })}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.sub }}>{letters ? '123' : 'ABC'}</Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const toText = (v) => (v === null || v === undefined || v === '' ? '' : String(r3(v)));

// Number entry with big − / + buttons so workers rarely need the keyboard.
export function NumberField({ label, value, onChange, step = 1, unit, min = 0, testID, hint, compact }) {
  const [text, setText] = useState(toText(value));
  useEffect(() => {
    const parsed = text === '' ? null : Number(text);
    const v = value === null || value === undefined || value === '' ? null : Number(value);
    if (parsed !== v && text !== '-' && !(text.endsWith('.') && Number(text.slice(0, -1)) === v)) setText(toText(value));
  }, [value]);

  const commit = (t) => {
    const neg = min < 0 && String(t).trim().startsWith('-');
    const clean = t.replace(',', '.').replace(/[^0-9.]/g, '');
    const parts = clean.split('.');
    const digits = parts.length > 2 ? parts[0] + '.' + parts.slice(1).join('') : clean;
    const fixed = (neg ? '-' : '') + digits;
    setText(fixed);
    if (digits === '' || digits === '.') onChange(null);
    else onChange(Number(fixed.endsWith('.') ? fixed.slice(0, -1) : fixed));
  };
  const bump = (dir) => {
    const cur = value === null || value === undefined || value === '' ? 0 : Number(value);
    const next = Math.max(min, r3(cur + dir * step));
    setText(toText(next));
    onChange(next);
  };
  const sc = useScale();
  const size = (compact ? 60 : 68) * sc;
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable testID={testID ? testID + '-minus' : undefined} onPress={() => bump(-1)} style={({ pressed }) => ({ width: size, height: size, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.primary }}>−</Text>
        </Pressable>
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12, height: size, paddingHorizontal: 12 }}>
          <TextInput
            testID={testID}
            value={text}
            onChangeText={commit}
            keyboardType={min < 0 ? 'numbers-and-punctuation' : 'decimal-pad'}
            selectTextOnFocus
            placeholder="0"
            placeholderTextColor="#B9AE9E"
            style={{ flex: 1, fontSize: 24, fontWeight: '800', color: C.text, textAlign: 'center', padding: 0 }}
          />
          {unit ? <Text style={{ fontSize: 17, color: C.sub, fontWeight: '700' }}>{unit}</Text> : null}
        </View>
        <Pressable testID={testID ? testID + '-plus' : undefined} onPress={() => bump(1)} style={({ pressed }) => ({ width: size, height: size, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 30, fontWeight: '800', color: C.primary }}>+</Text>
        </Pressable>
      </View>
      {hint ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>{hint}</Text> : null}
    </View>
  );
}

// Small number box for tables (e.g. minutes per flour band). Empty = not set.
export function NumCell({ label, value, onChange, unit, testID, min = 0 }) {
  const [text, setText] = useState(toText(value));
  useEffect(() => {
    const parsed = text === '' ? null : Number(text);
    const v = value === null || value === undefined || value === '' ? null : Number(value);
    if (parsed !== v && text !== '-' && !text.endsWith('.')) setText(toText(value));
  }, [value]);
  const commit = (t) => {
    const neg = min < 0 && String(t).trim().startsWith('-');
    const clean = t.replace(',', '.').replace(/[^0-9.]/g, '');
    const fixed = (neg ? '-' : '') + clean;
    setText(fixed);
    if (clean === '' || clean === '.') onChange(null);
    else onChange(Number(fixed.endsWith('.') ? fixed.slice(0, -1) : fixed));
  };
  return (
    <View style={{ flex: 1, minWidth: 90 }}>
      {label ? <Text style={{ fontSize: 14, fontWeight: '700', color: C.sub, marginBottom: 4, textAlign: 'center' }} numberOfLines={2}>{label}</Text> : null}
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: C.white, borderWidth: 2, borderColor: value === null || value === undefined ? C.border : C.info, borderRadius: 12, height: 62, paddingHorizontal: 8 }}>
        <TextInput
          testID={testID}
          value={text}
          onChangeText={commit}
          keyboardType={min < 0 ? 'numbers-and-punctuation' : 'decimal-pad'}
          selectTextOnFocus
          placeholder="–"
          placeholderTextColor="#B9AE9E"
          style={{ flex: 1, fontSize: 22, fontWeight: '800', color: C.text, textAlign: 'center', padding: 0 }}
        />
        {unit ? <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{unit}</Text> : null}
      </View>
    </View>
  );
}

// Single-choice chips (large touch targets).
export function Chips({ options, value, onChange, testIDPrefix }) {
  const s = useScale();
  const wide = useWide();
  if (wide) {
    // the design: a row of choices like tabs in a white box – the chosen one soft red
    return (
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, alignSelf: 'flex-start', backgroundColor: C.white, borderWidth: 1, borderColor: C.border, borderRadius: 10, padding: 4 }}>
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o;
          const on = opt.value === value;
          return (
            <Pressable key={String(opt.value)} testID={testIDPrefix ? `${testIDPrefix}-${opt.value}` : undefined} onPress={() => onChange(opt.value)} accessibilityRole="tab" accessibilityState={{ selected: on }}
              style={({ pressed, hovered }) => ({ height: 36, paddingHorizontal: 14, borderRadius: 7, justifyContent: 'center', backgroundColor: on ? W.redSoft : hovered ? W.bg : 'transparent', opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: on ? W.redDark : W.sub }}>{opt.label}</Text>
            </Pressable>
          );
        })}
      </View>
    );
  }
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {options.map((o) => {
        const opt = typeof o === 'string' ? { value: o, label: o } : o;
        const on = opt.value === value;
        return (
          <Pressable
            key={String(opt.value)}
            testID={testIDPrefix ? `${testIDPrefix}-${opt.value}` : undefined}
            onPress={() => onChange(opt.value)}
            style={({ pressed }) => ({
              minHeight: 60 * s, paddingHorizontal: 22 * Math.min(1, s), borderRadius: 30, justifyContent: 'center',
              backgroundColor: on ? C.primary : C.white, borderWidth: 2, borderColor: on ? C.primary : C.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Text style={{ fontSize: 19, fontWeight: '800', color: on ? C.white : C.text }}>{on ? '✓ ' : ''}{opt.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

// Grid of big buttons for choosing a material or product.
export function PickGrid({ items, onPick, selectedId, render, testIDPrefix }) {
  const s = useScale();
  return (
    <Grid>
      {items.map((it) => {
        const on = it.id === selectedId;
        return (
          <Pressable
            key={it.id}
            testID={testIDPrefix ? `${testIDPrefix}-${it.id}` : undefined}
            onPress={() => onPick(it)}
            style={({ pressed }) => ({
              minHeight: 104 * s, borderRadius: 18, padding: 16, justifyContent: 'center',
              backgroundColor: on ? C.primarySoft : C.card, borderWidth: 2, borderColor: on ? C.primary : C.border,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            {render ? render(it) : <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{it.name}</Text>}
          </Pressable>
        );
      })}
    </Grid>
  );
}

// Shows expected / actual / variance with a clear warning when they differ.
export function VarianceBox({ expected, actual, unit, tolerancePct }) {
  const has = actual !== null && actual !== undefined;
  const variance = has ? r3(actual - expected) : null;
  const differs = has && variance !== 0;
  const pct = has && expected ? Math.round((variance / expected) * 1000) / 10 : null;
  const over = differs && tolerancePct !== undefined && tolerancePct !== null
    ? Math.abs(variance) > (Math.abs(expected) * tolerancePct) / 100 + 1e-9 : differs;
  const color = !has ? C.sub : !differs ? C.success : over ? C.danger : C.warn;
  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      {[['Expected', fmt(expected, unit), C.text], ['Actual', has ? fmt(actual, unit) : '—', C.text],
        ['Variance', has ? `${variance > 0 ? '+' : ''}${fmt(variance, unit)}${pct !== null && differs ? ` (${pct > 0 ? '+' : ''}${pct}%)` : ''}` : '—', color]].map(([l, v, c]) => (
        <View key={l} style={{ flex: 1, backgroundColor: l === 'Variance' && has ? (differs ? (over ? C.dangerSoft : C.warnSoft) : C.successSoft) : '#F8F5F0', borderRadius: 12, padding: 10 }}>
          <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{l}</Text>
          <Text style={{ fontSize: 19, fontWeight: '800', color: c }}>{v}</Text>
        </View>
      ))}
    </View>
  );
}

// PIN pad for login and PIN entry.
export function PinPad({ value, onChange, maxLength = 6, onSubmit }) {
  const s = useScale();
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'];
  const press = (k) => {
    if (k === 'C') onChange('');
    else if (k === '⌫') onChange(value.slice(0, -1));
    else if (value.length < maxLength) {
      const next = value + k;
      onChange(next);
      if (onSubmit) onSubmit(next);
    }
  };
  // Release 25 (owner, 14 Nov: "on the sign in screen I can't type the PIN from the keyboard"): on a computer the number
  // keys (top row or number pad), Backspace and Esc work too.
  const pressRef = React.useRef(press);
  pressRef.current = press;
  React.useEffect(() => {
    if (Platform.OS !== 'web' || typeof window === 'undefined') return undefined;
    const onKey = (e) => {
      const t = e.target;
      const tag = t && t.tagName ? String(t.tagName).toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || (t && t.isContentEditable)) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (/^[0-9]$/.test(e.key)) { e.preventDefault(); pressRef.current(e.key); }
      else if (e.key === 'Backspace') { e.preventDefault(); pressRef.current('⌫'); }
      else if (e.key === 'Escape' || e.key === 'Delete') { pressRef.current('C'); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  return (
    <View style={{ gap: 12 }}>
      {[0, 1, 2, 3].map((r) => (
        <View key={r} style={{ flexDirection: 'row', gap: 12 }}>
          {keys.slice(r * 3, r * 3 + 3).map((k) => (
            <Pressable key={k} testID={`pin-${k}`} onPress={() => press(k)} style={({ pressed }) => ({
              flex: 1, height: 84 * s, borderRadius: 18, alignItems: 'center', justifyContent: 'center',
              backgroundColor: k === 'C' || k === '⌫' ? C.primarySoft : C.white, borderWidth: 2, borderColor: C.border,
              opacity: pressed ? 0.6 : 1,
            })}>
              <Text style={{ fontSize: 34, fontWeight: '800', color: C.text }}>{k}</Text>
            </Pressable>
          ))}
        </View>
      ))}
    </View>
  );
}

// A simple table that stays readable on phones (scrolls sideways if needed).
export function Table({ columns, rows, testID }) {
  return (
    <ScrollView horizontal testID={testID} contentContainerStyle={{ minWidth: '100%' }}>
      <View style={{ minWidth: '100%' }}>
        <View style={{ flexDirection: 'row', backgroundColor: C.primarySoft, borderTopLeftRadius: 10, borderTopRightRadius: 10 }}>
          {columns.map((c) => (
            <Text key={c.key} style={{ width: c.width || 110, padding: 8, fontWeight: '800', fontSize: 14, color: C.primaryDark, textAlign: c.align || 'left' }}>{c.title}</Text>
          ))}
        </View>
        {rows.map((r, i) => (
          <View key={i} style={{ flexDirection: 'row', backgroundColor: r._bg || (i % 2 ? '#FBF9F6' : C.white), borderBottomWidth: 1, borderBottomColor: '#F0EBE3' }}>
            {columns.map((c) => (
              <Text key={c.key} style={{ width: c.width || 110, padding: 8, fontSize: 15, color: (r._color && r._color[c.key]) || C.text, fontWeight: c.bold ? '700' : '400', textAlign: c.align || 'left' }}>
                {r[c.key] === null || r[c.key] === undefined ? '—' : String(r[c.key])}
              </Text>
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

// ================= Version 2 building blocks =================

// Photos: take with camera or choose from gallery; shows thumbnails with remove buttons.
// pages: a paper with more than one page (an invoice of 2 or 3 pages) – each photo is labelled Page 1, Page 2…
// pdf: 1.0.0 also "Choose PDF" (an invoice the supplier sent as a PDF – read by the AI in the cloud).
const isPdfUri = (u) => /(\.pdf(\?|#|$)|^data:application\/pdf)/i.test(String(u || ''));
// paper: build 20 – a photo of paper (invoice, receipt, slip): the document scanner finds the edges and crops it, and the
// corners can be adjusted after the photo; without the scanner a crop box shows after the photo.
export function PhotoPicker({ value = [], onChange, label = 'Photos', required, testID, pages, pdf, paper: paperProp }) {
  const paper = isPaperPhoto(label, paperProp);
  const ui = useUI();
  const [viewing, setViewing] = useState(null);
  const add = async (source) => {
    try {
      const { takePhoto, choosePdf, scanDocument } = require('../platform/photos.js');
      if (paper && source === 'camera') {
        const list = await scanDocument({ pages: pages ? 10 : 1, gallery: true });
        if (list) { if (list.length) onChange(value.concat(list)); return; }
      }
      const uri = source === 'pdf' ? await choosePdf() : await takePhoto(source, { crop: !!paper });
      if (uri) onChange(value.concat([uri]));
    } catch (e) {
      ui.alert({ title: 'Photo not added', message: e.message || String(e), tone: 'warn' });
    }
  };
  return (
    <View>
      <Label>{label}{required ? ' (required)' : ' (optional)'}</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {value.map((uri, i) => (
          <View key={uri + i} style={{ width: 110, height: 110, borderRadius: 12, overflow: 'hidden', borderWidth: 2, borderColor: C.border }}>
            {isPdfUri(uri) ? (
              <View testID={testID ? `${testID}-pdf-${i}` : undefined} style={{ width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', backgroundColor: C.infoSoft }}>
                <Text style={{ fontSize: 34 }}>📄</Text>
                <Text style={{ fontSize: 14, fontWeight: '800', color: C.info }}>PDF</Text>
              </View>
            ) : (
              <Pressable testID={testID ? `${testID}-view-${i}` : undefined} onPress={() => setViewing(i)} style={{ width: '100%', height: '100%' }}><Image source={{ uri }} style={{ width: '100%', height: '100%' }} /></Pressable>
            )}
            {pages ? <View style={{ position: 'absolute', left: 4, bottom: 4, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 8, paddingHorizontal: 6 }}><Text style={{ color: '#fff', fontSize: 12, fontWeight: '800' }}>{`Page ${i + 1}`}</Text></View> : null}
            <Pressable onPress={() => onChange(value.filter((_, k) => k !== i))} style={{ position: 'absolute', top: 4, right: 4, backgroundColor: C.danger, borderRadius: 14, width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ color: C.white, fontWeight: '800' }}>✕</Text>
            </Pressable>
          </View>
        ))}
        <Pressable testID={testID ? `${testID}-camera` : undefined} onPress={() => add('camera')} style={({ pressed }) => ({ width: 110, height: 110, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: C.info, alignItems: 'center', justifyContent: 'center', backgroundColor: C.infoSoft, opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 32 }}>📷</Text>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.info, textAlign: 'center' }}>{pages && value.length ? `Page ${value.length + 1}` : paper ? 'Scan paper' : 'Take photo'}</Text>
        </Pressable>
        <Pressable onPress={() => add('library')} style={({ pressed }) => ({ width: 110, height: 110, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Text style={{ fontSize: 32 }}>🖼️</Text>
          <Text style={{ fontSize: 14, fontWeight: '700', color: C.sub }}>From gallery</Text>
        </Pressable>
        {pdf ? (
          <Pressable testID={testID ? `${testID}-pdf` : undefined} onPress={() => add('pdf')} style={({ pressed }) => ({ width: 110, height: 110, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: C.border, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
            <Text style={{ fontSize: 32 }}>📄</Text>
            <Text style={{ fontSize: 14, fontWeight: '700', color: C.sub }}>Choose PDF</Text>
          </Pressable>
        ) : null}
      </View>
      {pages && value.length ? <Text style={{ fontSize: 14, color: C.sub, marginTop: 4 }}>{`${value.length} page${value.length === 1 ? '' : 's'}. More pages? Tap "Page ${value.length + 1}" – every page is read together.`}</Text> : null}
      {viewing !== null ? <PhotoViewer photos={value.filter((u) => !isPdfUri(u)).map((u) => ({ uri: u }))} index={Math.max(0, value.slice(0, viewing).filter((u) => !isPdfUri(u)).length)} onClose={() => setViewing(null)} /> : null}
    </View>
  );
}

const two = (n) => String(n).padStart(2, '0');

// "Now" or a different time. value: null = now, or { h, m }. The different time can be typed, picked on the clock or
// chosen with "Now". (Kept for the bakery screens; new screens use TimeField with 'HH:MM' values.)
export function TimeEntry({ label, value, onChange, testID, usual }) {
  const now = new Date();
  const hhmm = value ? `${two(value.h)}:${two(value.m)}` : `${two(now.getHours())}:${two(now.getMinutes())}`;
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <Chips value={value ? 'other' : 'now'} testIDPrefix={testID} onChange={(x) => onChange(x === 'now' ? null : { h: now.getHours(), m: now.getMinutes() })}
        options={[{ value: 'now', label: `Now (${two(now.getHours())}:${two(now.getMinutes())})` }, { value: 'other', label: 'Enter a different time' }]} />
      {value ? (
        <View style={{ marginTop: 10, gap: 6 }}>
          <TimeField testID={testID ? `${testID}-time` : undefined} value={hhmm} usual={usual} showNow={false}
            onChange={(t) => { const m = /^(\d{2}):(\d{2})$/.exec(t || ''); if (m) onChange({ h: Number(m[1]), m: Number(m[2]) }); }} />
          <Text style={{ fontSize: 14, color: C.warn, fontWeight: '700' }}>Both times are recorded</Text>
        </View>
      ) : null}
    </View>
  );
}

// Drop-down: opens a large list (good for touch) with a search box when the list is long.
// Options: [{ value, label, hint }]. Option buttons have testID `${testID}-opt-${value}` (or optionTestID(value)).
export function Select({ label, value, options, onChange, placeholder = 'Tap to choose', testID, search, optionTestID, disabled }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const s = useScale();
  const opts = (options || []).map((o) => (typeof o === 'object' && o !== null ? o : { value: o, label: String(o) }));
  const cur = opts.find((o) => o.value === value);
  const withSearch = search === undefined ? opts.length > 6 : !!search;
  const ql = q.trim().toLowerCase();
  const shown = ql ? opts.filter((o) => `${o.label} ${o.hint || ''} ${o.value}`.toLowerCase().includes(ql)) : opts;
  const close = () => { setOpen(false); setQ(''); };
  const oid = (v) => (optionTestID ? optionTestID(v) : testID ? `${testID}-opt-${v}` : undefined);
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      <Pressable testID={testID} disabled={disabled} onPress={() => setOpen(true)} style={({ pressed }) => ({ minHeight: 64 * s, borderRadius: 12, borderWidth: 2, borderColor: cur ? C.info : C.border, backgroundColor: disabled ? '#EEE9E1' : C.white, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ flex: 1, fontSize: 19, fontWeight: cur ? '800' : '400', color: cur ? C.text : '#A39886' }} numberOfLines={2}>{cur ? cur.label : placeholder}</Text>
        <Text style={{ fontSize: 20, color: C.sub }}>▾</Text>
      </Pressable>
      <SafeModal visible={open} transparent animationType="fade" onRequestClose={close}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
          <View style={{ backgroundColor: C.card, borderRadius: 18, padding: 16, width: '100%', maxWidth: 560, maxHeight: '90%' }}>
            <Text style={{ fontSize: 22, fontWeight: '800', marginBottom: 10, color: C.text }}>{label || 'Choose'}</Text>
            {withSearch ? (
              <TextInput testID={testID ? `${testID}-search` : undefined} value={q} onChangeText={setQ} placeholder="🔍 Type to search" placeholderTextColor="#A39886" autoFocus={opts.length > 12}
                style={{ backgroundColor: C.white, borderWidth: 2, borderColor: C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 19, color: C.text, minHeight: 54, marginBottom: 10 }} />
            ) : null}
            <ScrollView keyboardShouldPersistTaps="handled">
              {shown.map((o) => (
                <Pressable key={String(o.value)} testID={oid(o.value)} onPress={() => { close(); onChange(o.value); }}
                  style={({ pressed }) => ({ minHeight: 60, justifyContent: 'center', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, marginBottom: 6, backgroundColor: o.value === value ? C.infoSoft : '#F7F4F0', opacity: pressed ? 0.6 : 1 })}>
                  <Text style={{ fontSize: 19, fontWeight: '700', color: C.text }}>{o.value === value ? '✓ ' : ''}{o.label}</Text>
                  {o.hint ? <Text style={{ fontSize: 14, color: C.sub }}>{o.hint}</Text> : null}
                </Pressable>
              ))}
              {!shown.length ? <Text style={{ fontSize: 17, color: C.sub, padding: 12 }}>Nothing matches “{q}”.</Text> : null}
            </ScrollView>
            <Btn title="Cancel" variant="secondary" size="md" style={{ marginTop: 10 }} onPress={close} />
          </View>
        </View>
      </SafeModal>
    </View>
  );
}

// One choice: big chips when there are only a few options (max, default 5), otherwise a searchable drop-down.
// testIDs: chips `${testIDPrefix}-${value}`; drop-down button `${testIDPrefix}`, its options `${testIDPrefix}-${value}`.
export function Choice({ label, value, onChange, options, testIDPrefix, max = 5, placeholder, search }) {
  const opts = (options || []).map((o) => (typeof o === 'object' && o !== null ? o : { value: o, label: String(o) }));
  if (opts.length <= max) {
    return (
      <View>
        {label ? <Label>{label}</Label> : null}
        <Chips value={value} onChange={onChange} options={opts} testIDPrefix={testIDPrefix} />
      </View>
    );
  }
  return <Select label={label} value={value} onChange={onChange} options={opts} placeholder={placeholder} search={search} testID={testIDPrefix}
    optionTestID={testIDPrefix ? (v) => `${testIDPrefix}-${v}` : undefined} />;
}

// Editable list of email addresses.
export function EmailList({ label, value = [], onChange, testID }) {
  const [text, setText] = useState('');
  const add = () => {
    const e = text.trim();
    if (!e) return;
    onChange(value.concat([e]));
    setText('');
  };
  return (
    <View>
      {label ? <Label>{label}</Label> : null}
      {value.length ? value.map((e, i) => (
        <View key={e + i} style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#F7F4F0', borderRadius: 10, padding: 10, marginBottom: 6 }}>
          <Text style={{ flex: 1, fontSize: 17, color: C.text }}>✉️  {e}</Text>
          <Btn title="Remove" size="sm" variant="ghost" onPress={() => onChange(value.filter((_, k) => k !== i))} />
        </View>
      )) : <Text style={{ fontSize: 15, color: C.sub, marginBottom: 6 }}>No email addresses yet.</Text>}
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        <View style={{ flex: 1 }}><Field testID={testID} value={text} onChangeText={setText} placeholder="name@example.com" keyboardType="email-address" /></View>
        <Btn testID={testID ? `${testID}-add` : undefined} title="Add" size="md" onPress={add} />
      </View>
    </View>
  );
}

// Visual timeline of a batch's steps.
export function StepTimeline({ steps, currentIdx }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
      {steps.map((s, i) => {
        const done = !!s.started_at;
        const cur = i === currentIdx && s.kind !== 'finish';
        const bg = cur ? C.info : done ? C.success : '#ECE7E1';
        return (
          <View key={s.idx} style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ backgroundColor: bg, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 }}>
              <Text style={{ color: done || cur ? C.white : C.sub, fontWeight: '800', fontSize: 17 }}>{s.name}</Text>
              <Text style={{ color: done || cur ? C.white : C.sub, fontSize: 14 }}>{s.started_at ? s.started_at.slice(11, 16) : s.due_at ? `due ${s.due_at.slice(11, 16)}` : s.minutes ? `${s.minutes} min` : ''}</Text>
            </View>
            {i < steps.length - 1 ? <Text style={{ marginHorizontal: 4, color: C.sub, fontSize: 16 }}>›</Text> : null}
          </View>
        );
      })}
    </View>
  );
}

// Countdown / overdue text that updates every second.
export function useTick(ms = 1000) {
  const [, set] = useState(0);
  useEffect(() => {
    const t = setInterval(() => set((n) => n + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
}
export function countdown(seconds) {
  if (seconds === null || seconds === undefined) return '';
  const s = Math.abs(seconds);
  const m = Math.floor(s / 60);
  const txt = m >= 60 ? `${Math.floor(m / 60)}h ${two(m % 60)}m` : `${m}:${two(s % 60)}`;
  return seconds < 0 ? `${txt} overdue` : `in ${txt}`;
}

export function Section({ title, children, right }) {
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 2, borderBottomColor: C.brandRed, paddingBottom: 4 }}>
        <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{title}</Text>
        {right || null}
      </View>
      {children}
    </View>
  );
}
