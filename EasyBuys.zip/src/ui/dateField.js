// Dates for the whole app: DateField (type it, Today / Yesterday / Tomorrow, or a calendar with day / month / year
// columns), DateTimeField (a date and a time), and PeriodPicker (Today … Last year, or your own dates).
// Values are ISO 'YYYY-MM-DD'; on screen the date is shown as "Tue 13 Oct 2026".
import React, { useRef, useState } from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text, TextInput, useScale } from './scale.js';
import { C } from './theme.js';
import { Label, Select, useRemembered } from './components.js';
import { TimeField } from './timePicker.js';
import { dateStr, addDays, clock } from '../services/core.js';
import { SafeModal } from './safeModal.js';
import {
  parseDate, fmtDate, fmtDmy, isIsoDate, dateWarning, relDay, partsOf, isoOf, daysInMonth, monthGrid, MONTHS, MON, WEEKDAYS,
  PERIODS, periodRange, periodKind, periodLabel, rangeProblem,
} from '../services/dates.js';

const today = () => dateStr(clock.now());

function Small({ title, onPress, on, testID, tone, flex }) {
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed }) => ({ minHeight: 44, paddingHorizontal: 14, borderRadius: 22, justifyContent: 'center', alignItems: 'center', borderWidth: 2,
      flex: flex ? 1 : undefined, borderColor: on ? C.info : tone === 'primary' ? C.primary : C.border, backgroundColor: on ? C.info : tone === 'primary' ? C.primary : C.white, opacity: pressed ? 0.7 : 1 })}>
      <Text style={{ fontSize: 16, fontWeight: '800', color: on || tone === 'primary' ? C.white : C.text }}>{title}</Text>
    </Pressable>
  );
}

// A scrolling column (day, month or year) for the calendar pop-up.
function Column({ title, items, value, onPick, testID }) {
  const ref = useRef(null);
  const idx = Math.max(0, items.findIndex((x) => x.value === value));
  return (
    <View style={{ flex: 1, minWidth: 70 }}>
      <Text style={{ fontSize: 14, fontWeight: '800', color: C.sub, textAlign: 'center', marginBottom: 4 }}>{title}</Text>
      <ScrollView ref={ref} style={{ height: 170, borderWidth: 1, borderColor: C.border, borderRadius: 12, backgroundColor: C.white }}
        onContentSizeChange={() => { if (ref.current && ref.current.scrollTo) ref.current.scrollTo({ y: Math.max(0, idx * 42 - 64), animated: false }); }}>
        {items.map((x) => (
          <Pressable key={x.value} testID={testID ? `${testID}-${x.value}` : undefined} onPress={() => onPick(x.value)}
            style={{ height: 42, justifyContent: 'center', alignItems: 'center', backgroundColor: x.value === value ? C.info : 'transparent' }}>
            <Text style={{ fontSize: 17, fontWeight: x.value === value ? '900' : '600', color: x.value === value ? C.white : C.text }}>{x.label}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

// The calendar pop-up: a month grid (tap a day to choose it) and day / month / year columns.
function CalendarPopup({ visible, value, onPick, onClose, title, testID }) {
  const t = today();
  const start = isIsoDate(value) ? value : t;
  const [sel, setSel] = useState(start);
  const [view, setView] = useState(() => partsOf(start));
  const s = useScale();
  React.useEffect(() => { if (visible) { const v = isIsoDate(value) ? value : t; setSel(v); setView(partsOf(v)); } }, [visible]);
  const p = partsOf(sel);
  const setParts = (y, m, d) => { const dd = Math.min(d, daysInMonth(y, m)); const iso = isoOf(y, m, dd); setSel(iso); setView({ y, m, d: dd }); };
  const moveMonth = (n) => { let y = view.y, m = view.m + n; if (m < 1) { m = 12; y--; } if (m > 12) { m = 1; y++; } setView({ y, m, d: 1 }); };
  const thisYear = Number(t.slice(0, 4));
  const years = []; for (let y = Math.min(thisYear - 6, p.y); y <= Math.max(thisYear + 4, p.y); y++) years.push({ value: y, label: String(y) });
  const cell = Math.round(44 * Math.min(1.15, s));
  const id = (x) => (testID ? `${testID}-${x}` : undefined);
  return (
    <SafeModal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 10 }}>
        <View testID={id('calendar')} style={{ backgroundColor: C.card, borderRadius: 18, padding: 14, width: '100%', maxWidth: 520, maxHeight: '96%' }}>
          <ScrollView contentContainerStyle={{ gap: 12 }}>
            <Text style={{ fontSize: 21, fontWeight: '800', color: C.text }}>{title || 'Choose the date'}</Text>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.info }}>{fmtDate(sel)}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Small testID={id('cal-prev')} title="‹" onPress={() => moveMonth(-1)} />
              <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{MONTHS[view.m - 1]} {view.y}</Text>
              <Small testID={id('cal-next')} title="›" onPress={() => moveMonth(1)} />
            </View>
            <View style={{ alignSelf: 'center' }}>
              <View style={{ flexDirection: 'row' }}>
                {WEEKDAYS.map((w) => <Text key={w} style={{ width: cell, textAlign: 'center', fontSize: 13, fontWeight: '800', color: w === 'Sat' || w === 'Sun' ? C.primary : C.sub }}>{w}</Text>)}
              </View>
              {monthGrid(view.y, view.m).map((row, i) => (
                <View key={i} style={{ flexDirection: 'row' }}>
                  {row.map((iso, k) => (iso ? (
                    <Pressable key={iso} testID={id(`cal-day-${Number(iso.slice(8))}`)} onPress={() => { setSel(iso); onPick(iso); }}
                      style={{ width: cell, height: cell, borderRadius: cell / 2, alignItems: 'center', justifyContent: 'center', backgroundColor: iso === sel ? C.info : 'transparent', borderWidth: iso === t ? 2 : 0, borderColor: C.primary }}>
                      <Text style={{ fontSize: 17, fontWeight: iso === sel ? '900' : '600', color: iso === sel ? C.white : C.text }}>{Number(iso.slice(8))}</Text>
                    </Pressable>
                  ) : <View key={`e${k}`} style={{ width: cell, height: cell }} />))}
                </View>
              ))}
            </View>
            <Text style={{ fontSize: 14, color: C.sub }}>Tap a day, or pick the day, month and year below and press “Use this date”.</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Column title="Day" testID={id('col-d')} value={p.d} onPick={(d) => setParts(p.y, p.m, d)}
                items={Array.from({ length: daysInMonth(p.y, p.m) }, (_, i) => ({ value: i + 1, label: String(i + 1) }))} />
              <Column title="Month" testID={id('col-m')} value={p.m} onPick={(m) => setParts(p.y, m, p.d)} items={MON.map((l, i) => ({ value: i + 1, label: l }))} />
              <Column title="Year" testID={id('col-y')} value={p.y} onPick={(y) => setParts(y, p.m, p.d)} items={years} />
            </View>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              <Small title="Today" testID={id('cal-today')} onPress={() => { setSel(t); setView(partsOf(t)); }} />
              <Small title="Cancel" testID={id('cal-cancel')} onPress={onClose} flex />
              <Small title="Use this date" tone="primary" testID={id('cal-ok')} onPress={() => onPick(sel)} flex />
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeModal>
  );
}

// One date entry for the whole app. Same props as before (label, value, onChange, testID) plus:
//   expected  – the date to fill in when the value is empty (e.g. today's date, the due date)
//   farDays   – warn when more than this many days from today (default 60; 0 / false = never warn)
//   min / max – earliest / latest date allowed (shown as a warning)
//   quick     – false hides the Today / Yesterday / Tomorrow buttons;  optional – adds "(optional)" to the label
// The typing box keeps the caller's testID (type 2026-10-13, 13/10/2026, 13 Oct …); the calendar button is `${testID}-cal`.
export function DateField({ label, value, onChange, testID, expected, farDays = 60, min, max, quick = true, optional, hint }) {
  const [focus, setFocus] = useState(false);
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const filled = useRef(false);
  React.useEffect(() => {
    if (!filled.current && (value === '' || value === null || value === undefined) && isIsoDate(expected)) { filled.current = true; onChange(expected); }
  }, []);
  const t = today();
  const shown = focus ? text : isIsoDate(value) ? fmtDate(value) : value || '';
  const parsed = focus ? parseDate(text, t) : value ? parseDate(value, t) : { ok: false, empty: true };
  const err = !parsed.ok && !parsed.empty ? parsed.error : '';
  const iso = isIsoDate(value) ? value : parsed.ok ? parsed.iso : null;
  const warn = !err && iso ? dateWarning(iso, { today: t, farDays, min, max }) : '';
  const set = (d) => { setText(fmtDate(d)); onChange(d); };
  const id = (x) => (testID ? `${testID}-${x}` : undefined);
  return (
    <View style={{ gap: 6 }}>
      {label ? <Label>{label}{optional ? ' (optional)' : ''}</Label> : null}
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        <TextInput testID={testID} value={shown} placeholder="e.g. 13/10/2026" placeholderTextColor="#A39886" keyboardType="numbers-and-punctuation"
          onFocus={() => { setFocus(true); setText(isIsoDate(value) ? fmtDate(value) : value || ''); }}
          onBlur={() => setFocus(false)}
          onChangeText={(x) => { setText(x); const r = parseDate(x, t); onChange(r.ok ? r.iso : x); }}
          style={{ flex: 1, backgroundColor: C.white, borderWidth: 2, borderColor: err ? C.danger : warn ? C.warn : C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 20, color: C.text, minHeight: 62 }} />
        <Pressable testID={id('cal')} onPress={() => setOpen(true)}
          style={({ pressed }) => ({ width: 62, height: 62, borderRadius: 12, borderWidth: 2, borderColor: C.info, backgroundColor: C.infoSoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 28 }}>📅</Text>
        </Pressable>
      </View>
      {quick ? (
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Small testID={id('yesterday')} title="Yesterday" on={value === addDays(t, -1)} onPress={() => set(addDays(t, -1))} />
          <Small testID={id('today')} title="Today" on={value === t} onPress={() => set(t)} />
          <Small testID={id('tomorrow')} title="Tomorrow" on={value === addDays(t, 1)} onPress={() => set(addDays(t, 1))} />
          {isIsoDate(expected) && ![t, addDays(t, -1), addDays(t, 1)].includes(expected) ? <Small testID={id('expected')} title={fmtDate(expected, { year: false })} on={value === expected} onPress={() => set(expected)} /> : null}
        </View>
      ) : null}
      {err ? <Text testID={id('error')} style={{ fontSize: 15, color: C.danger, fontWeight: '700' }}>{err}</Text>
        : warn ? <Text testID={id('warn')} style={{ fontSize: 15, color: C.warn, fontWeight: '700' }}>⚠️ {warn}</Text>
          : iso && relDay(iso, t) && !relDay(iso, t).startsWith('Today') && !['Yesterday', 'Tomorrow'].includes(relDay(iso, t)) ? <Text style={{ fontSize: 14, color: C.sub }}>{relDay(iso, t)}</Text>
            : hint ? <Text style={{ fontSize: 14, color: C.sub }}>{hint}</Text> : null}
      <CalendarPopup visible={open} value={iso} title={label} testID={testID} onClose={() => setOpen(false)} onPick={(d) => { setOpen(false); set(d); }} />
    </View>
  );
}

// A date and a time together. value / onChange: 'YYYY-MM-DD HH:MM'. testIDs: `${testID}-date`, `${testID}-time`.
export function DateTimeField({ label, value, onChange, testID, usual, farDays = 60, optional }) {
  // Date and time are kept apart while typing, so a half-typed date never loses the time (and the other way round).
  const split = (x) => { const m = /^(\d{4}-\d{2}-\d{2})(?:[ T](\d{1,2}:\d{2}))?/.exec(String(x || '')); return m ? [m[1], m[2] ? m[2].padStart(5, '0') : ''] : null; };
  const [[d, tm], setParts] = useState(() => split(value) || ['', '']);
  React.useEffect(() => { const p = split(value); if (p && (p[0] !== d || (p[1] && p[1] !== tm))) setParts(p); }, [value]);
  const join = (a, b) => { setParts([a, b]); onChange(`${a || ''}${b ? ' ' + b : ''}`.trim()); };
  return (
    <View style={{ gap: 6 }}>
      {label ? <Label>{label}{optional ? ' (optional)' : ''}</Label> : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        <View style={{ flexGrow: 1, flexBasis: 260 }}><DateField testID={testID ? `${testID}-date` : undefined} value={d} onChange={(x) => join(x, tm)} farDays={farDays} /></View>
        <View style={{ flexGrow: 1, flexBasis: 220 }}><TimeField testID={testID ? `${testID}-time` : undefined} value={tm} usual={usual} onChange={(x) => join(d, x)} /></View>
      </View>
    </View>
  );
}

// Period drop-down for reports and every date range: Today, Yesterday, This week (Sat–Fri), Last week, This month,
// Last month, This year, Last year, or "Choose dates…" (from / to). onChange(from, to, kind).
// testIDs: the drop-down `${testID}`, its options `${testID}-opt-<kind>`, own dates `${testID}-from` / `${testID}-to`.
export function PeriodPicker({ from, to, onChange, testID = 'period', label = 'Period', periods, hideLabel }) {
  const kindNow = periodKind(from, to);
  const [custom, setCustom] = useState(kindNow === 'custom');
  const kind = custom ? 'custom' : kindNow;
  const list = periods ? PERIODS.filter((p) => periods.includes(p.value) || p.value === 'custom') : PERIODS;
  const choose = (k) => {
    if (k === 'custom') { setCustom(true); return; }
    setCustom(false);
    const r = periodRange(k);
    if (r) onChange(r.from, r.to, k);
  };
  const problem = rangeProblem(from, to);
  return (
    <View style={{ gap: 8 }}>
      <Select label={hideLabel ? undefined : label} testID={testID} value={kind} onChange={choose} search={false}
        options={list.map((p) => ({ ...p, hint: p.value === 'custom' ? 'Any first and last day' : (() => { const r = periodRange(p.value); return r ? periodLabel(r.from, r.to) : ''; })() }))} />
      {kind === 'custom' ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          <View style={{ flexGrow: 1, flexBasis: 260 }}><DateField testID={`${testID}-from`} label="From" value={from} farDays={false} onChange={(v) => onChange(v, to, 'custom')} /></View>
          <View style={{ flexGrow: 1, flexBasis: 260 }}><DateField testID={`${testID}-to`} label="To" value={to} farDays={false} onChange={(v) => onChange(from, v, 'custom')} /></View>
        </View>
      ) : null}
      <Text testID={`${testID}-shown`} style={{ fontSize: 16, color: problem ? C.danger : C.sub, fontWeight: '700' }}>{problem || `📅 ${periodLabel(from, to)}`}</Text>
    </View>
  );
}

// Start values for a PeriodPicker: usePeriod('thisweek') → [from, to, setRange].
// The period is remembered while the screen is open (going back to it keeps the same period).
export function usePeriod(kind = 'thisweek', name = 'period') {
  const [range, setRange] = useRemembered(name, () => { const r = periodRange(kind) || periodRange('thisweek'); return [r.from, r.to]; });
  return [range[0], range[1], (f, t) => setRange([f, t])];
}
