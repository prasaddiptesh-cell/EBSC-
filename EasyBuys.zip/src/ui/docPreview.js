// Preview before sending, saving or printing – for every document and report (v3.5).
// Shows the page as it will come out (A4, A5 or 80 mm), zoom, the number of pages, the paper to use, any ⚠️ note,
// then Send / Save PDF / Excel / Print / Close. Viber prompts ("Send a PDF to the Viber group?") open here too.
// Mounted once (App.js); every shareReport / printReport call in the app comes here first (src/platform/files.js).
import React, { useEffect, useRef, useState } from 'react';
import { View, Modal, ScrollView, Pressable } from 'react-native';
import { WebView } from 'react-native-webview';
import { Text } from './scale.js';
import { Btn, Banner, Chips, useUI, useLayout } from './components.js';
import { useApp } from './appContext.js';
import { C } from './theme.js';
import { reportToHtml } from '../services/export.js';
import { prepareDoc } from '../services/docOutput.js';
import { PAPERS, docType } from '../services/docDesign.js';
import { folderText, folderPathFor } from '../services/driveDocs.js';
import { setPreviewHandler, reportPdf, shareReportNow, printReportNow, saveReportPdf } from '../platform/files.js';
import { LOGO_DATA_URI } from '../platform/logoData.js';
import { bluetoothPrinting } from '../platform/printer.js';

// CSS pixels of one printed page (96 per inch) for the page count; 80 mm is one long receipt.
const PAGE_PX = { A4: { w: 794, h: 1017 }, A5: { w: 559, h: 718 }, '80mm': { w: 302, h: 0 } };
export function previewHtml(rep, { zoom = 1 } = {}) {
  const html = reportToHtml(rep, { logoUri: LOGO_DATA_URI });
  const px = PAGE_PX[rep._paper] || PAGE_PX.A4;
  const extra = `<style>html{background:#8a8a8a}body{background:#fff;margin:12px auto!important;padding:14px;box-shadow:0 2px 10px rgba(0,0,0,.35);width:${px.w}px;zoom:${zoom}}</style>`
    + '<script>setTimeout(function(){try{window.ReactNativeWebView.postMessage(JSON.stringify({h:document.body.scrollHeight}))}catch(e){}},350)</script>';
  return html.replace(/<meta name="viewport"[^>]*>/, `<meta name="viewport" content="width=${Math.round(px.w + 40)}, initial-scale=${zoom}"/>`).replace('</head>', `${extra}</head>`);
}
export function pagesFor(paper, heightPx) {
  const px = PAGE_PX[paper] || PAGE_PX.A4;
  if (!px.h) return 1;
  return Math.max(1, Math.ceil((Number(heightPx) || 0) / px.h));
}
const cancelled = () => { const e = new Error('Closed without sending.'); e.cancelled = true; e.isAppError = true; return e; };

export function DocPreviewHost() {
  const [job, setJob] = useState(null); // { rep, opts, resolve, reject }
  const [paper, setPaper] = useState('A4');
  const [zoom, setZoom] = useState(1);
  const [pages, setPages] = useState(null);
  const [busy, setBusy] = useState('');
  const pdfRef = useRef(null); // the PDF made in the background as soon as the preview opens
  const ui = useUI();
  const app = useApp();
  const { isPhone } = useLayout();

  useEffect(() => {
    setPreviewHandler((rep, opts = {}) => new Promise((resolve, reject) => {
      const first = prepareDoc(rep, { paper: opts.paper });
      setPaper(first._paper);
      setZoom(1);
      setPages(null);
      setBusy('');
      setJob({ rep, opts, resolve, reject });
    }));
    return () => setPreviewHandler(null);
  }, []);
  const prep = job ? prepareDoc(job.rep, { paper }) : null;
  // Make the PDF straight away (so Send is quick and the size is known); remade if the paper changes.
  useEffect(() => {
    if (!prep) return;
    const p = { paper, promise: reportPdf(prep).catch(() => null) };
    pdfRef.current = p;
  }, [job, paper]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!job || !prep) return null;
  const t = docType(prep._typeId);
  const offer = !!job.opts.offer;
  const finish = (fn) => async () => {
    setBusy('Working…');
    try {
      const made = pdfRef.current && pdfRef.current.paper === paper ? await pdfRef.current.promise : null;
      const r = await fn(made);
      const j = job;
      setJob(null);
      j.resolve(r);
    } catch (e) {
      setBusy('');
      ui.error(e);
    }
  };
  const close = () => { const j = job; setJob(null); j.reject(cancelled()); };
  const send = finish((made) => shareReportNow(prep, 'pdf', { paper, pdf: made }));
  const save = finish(async (made) => { const r = await saveReportPdf(prep, { paper, pdf: made }); ui.toast(`Saved – filed in ${folderText(folderPathFor(prep._typeId))}`); return r.uri; });
  const excel = finish(() => shareReportNow(prep, 'xlsx', { paper }));
  const print = finish(() => printReportNow(prep, { paper }));
  const changeLayout = () => { const j = job; setJob(null); j.reject(cancelled()); if (app && app.nav) app.nav.push('DocDesigner', { type: prep._typeId }); };
  const want = job.opts.action || 'pdf';
  const v = (a) => (want === a || (a === 'pdf' && want === 'csv') ? 'primary' : 'secondary');
  return (
    <Modal visible transparent={false} animationType="slide" onRequestClose={close}>
      <View testID="doc-preview" style={{ flex: 1, backgroundColor: C.bg }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', padding: isPhone ? 8 : 12, backgroundColor: C.white, borderBottomWidth: 4, borderBottomColor: C.brandRed, gap: 8 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: isPhone ? 17 : 20, fontWeight: '800', color: C.text }} numberOfLines={1}>{offer ? (job.opts.title || 'Send a PDF?') : `Preview – ${prep.title}`}</Text>
            <Text testID="pv-pages" style={{ fontSize: 14, color: C.sub }} numberOfLines={1}>
              {`${t.label} · ${PAPERS.find((p) => p.id === paper).label} · ${paper === '80mm' ? 'one receipt' : pages ? `${pages} page${pages === 1 ? '' : 's'}` : 'counting pages…'} · ${prep._identity ? prep._identity.ref : ''}`}
            </Text>
          </View>
          <Pressable testID="pv-close" accessibilityLabel="Close" onPress={close} style={{ paddingVertical: 10, paddingHorizontal: 14, borderRadius: 12, backgroundColor: C.primarySoft }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.primary }}>✕ Close</Text>
          </Pressable>
        </View>
        <ScrollView style={{ maxHeight: isPhone ? 210 : 170 }} contentContainerStyle={{ padding: isPhone ? 8 : 12, gap: 8 }}>
          {offer && job.opts.message ? <Text style={{ fontSize: 16, color: C.text }}>{job.opts.message}</Text> : null}
          {prep.warningMark ? <Banner testID="pv-warning" tone="warn" message={prep.warningMark} /> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
            <Chips testIDPrefix="pv-paper" value={paper} onChange={(p) => { setPaper(p); setPages(null); }} options={PAPERS.map((p) => ({ value: p.id, label: p.label }))} />
            <Btn testID="pv-zoom-out" title="−" size="sm" variant="secondary" onPress={() => setZoom((z) => Math.max(0.5, Math.round((z - 0.25) * 100) / 100))} />
            <Text style={{ fontSize: 15, color: C.sub, minWidth: 50, textAlign: 'center' }}>{Math.round(zoom * 100)}%</Text>
            <Btn testID="pv-zoom-in" title="+" size="sm" variant="secondary" onPress={() => setZoom((z) => Math.min(2.5, Math.round((z + 0.25) * 100) / 100))} />
            <Btn testID="pv-layout" title="Change the layout" icon="🎨" size="sm" variant="ghost" onPress={changeLayout} />
          </View>
          {paper === '80mm' ? <Text style={{ fontSize: 13, color: C.sub }}>{bluetoothPrinting().message}</Text> : null}
        </ScrollView>
        <View style={{ flex: 1, margin: isPhone ? 4 : 10, borderRadius: 10, overflow: 'hidden', borderWidth: 1, borderColor: C.border, backgroundColor: '#8a8a8a' }}>
          <WebView key={`${paper}-${zoom}`} originWhitelist={['*']} source={{ html: previewHtml(prep, { zoom }) }} style={{ flex: 1 }} scalesPageToFit
            onMessage={(e) => { try { const m = JSON.parse(e.nativeEvent.data); if (m.h && zoom === 1) setPages(pagesFor(paper, m.h)); } catch (x) { /* ignore */ } }} />
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, padding: isPhone ? 8 : 12, backgroundColor: C.card, borderTopWidth: 1, borderTopColor: C.border }}>
          <Btn testID="pv-send" title={busy || (offer ? 'Send PDF' : 'Send')} icon="📤" size="md" variant={offer ? 'primary' : v('pdf')} disabled={!!busy} style={{ flexGrow: 1 }} onPress={send} />
          <Btn testID="pv-save" title="Save PDF" icon="💾" size="md" variant="secondary" disabled={!!busy} style={{ flexGrow: 1 }} onPress={save} />
          {offer ? null : <Btn testID="pv-xlsx" title="Excel" icon="📊" size="md" variant={v('xlsx')} disabled={!!busy} style={{ flexGrow: 1 }} onPress={excel} />}
          <Btn testID="pv-print" title="Print" icon="🖨️" size="md" variant={v('print')} disabled={!!busy} style={{ flexGrow: 1 }} onPress={print} />
          <Btn testID="pv-notnow" title="Not now" size="md" variant="ghost" disabled={!!busy} style={{ flexGrow: 1 }} onPress={close} />
        </View>
      </View>
    </Modal>
  );
}
