// A list of documents kept with a record (licence, contract…), with Add (file or photo), Open and Put aside.
import React, { useState } from 'react';
import { View } from 'react-native';
import { Text } from './scale.js';
import { Card, Btn, Chips, Field, PhotoPicker, Label, useApp, useUI } from './components.js';
import { C } from './theme.js';
import { ListItem, Hint, ReasonButton } from './kit.js';
import { listDocuments, archiveDocument } from '../services/documents.js';
import { pickAnyFile, addFileDocument, addPhotoDocuments, openDocument } from '../platform/docFiles.js';
import { dateStr } from '../services/core.js';

const ICON = (mime) => (/pdf/.test(mime || '') ? '📄' : /image/.test(mime || '') ? '🖼️' : /word|document/.test(mime || '') ? '📝' : /sheet|excel/.test(mime || '') ? '📊' : '📎');

export function DocumentsPanel({ refType, refUid, kinds, canAdd = true, testID = 'docs', defaultKind }) {
  const { user, refresh } = useApp();
  const ui = useUI();
  const [adding, setAdding] = useState(null);
  const [busy, setBusy] = useState(false);
  const [showOld, setShowOld] = useState(false);
  const docs = listDocuments(refType, refUid, { all: showOld });
  const kindList = Object.entries(kinds || { other: 'Document' });
  const start = () => setAdding({ kind: defaultKind || kindList[0][0], name: '', date: dateStr(), notes: '', photos: [], file: null });
  const save = async () => {
    const a = adding;
    const meta = { refType, refUid, kind: a.kind, name: a.name.trim() || (a.file ? a.file.name : (kinds || {})[a.kind] || 'Document'), docDate: a.date, notes: a.notes };
    if (!a.file && !a.photos.length) { ui.error(new Error('Choose a file or take a photo first.')); return; }
    setBusy(true);
    try {
      if (a.file) await addFileDocument(user, meta, a.file);
      if (a.photos.length) await addPhotoDocuments(user, meta, a.photos);
      setAdding(null);
      ui.toast('Saved – a copy goes to Google Drive when online');
    } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); }
  };
  const open = async (uid) => { setBusy(true); try { await openDocument(uid); } catch (e) { ui.error(e); } finally { setBusy(false); refresh(); } };
  const grouped = kindList.map(([k, label]) => [k, label, docs.filter((d) => d.kind === k)]).concat([['_', 'Other', docs.filter((d) => !(kinds || {})[d.kind])]]).filter(([, , l]) => l.length);
  return (
    <View style={{ gap: 8 }}>
      {!docs.length ? <Hint>No documents yet.</Hint> : null}
      {grouped.map(([k, label, list]) => (
        <View key={k} style={{ gap: 4 }}>
          <Label>{label} ({list.length})</Label>
          {list.map((d) => (
            <View key={d.uid}>
              <ListItem testID={`${testID}-${d.uid}`} title={`${ICON(d.mime)} ${d.name}`} sub={`${d.doc_date || ''} · added by ${d.added_by || ''}${d.cloud_id ? ' · ☁️ in Drive' : ' · waiting to go to Drive'}${d.status !== 'active' ? ` · put aside: ${d.void_reason || ''}` : ''}${d.notes ? ` · ${d.notes}` : ''}`}
                onPress={() => open(d.uid)} right="Open" />
              {d.status === 'active' && canAdd ? <ReasonButton title="Put aside" size="sm" variant="ghost" prompt="Why put it aside? (it is kept, just hidden)" confirm="Put aside" onDo={(w) => { try { archiveDocument(user, d.uid, w); refresh(); } catch (e) { ui.error(e); } }} /> : null}
            </View>
          ))}
        </View>
      ))}
      <Btn title={showOld ? 'Hide put-aside documents' : 'Show put-aside documents too'} size="sm" variant="ghost" onPress={() => setShowOld(!showOld)} />
      {canAdd && !adding ? <Btn testID={`${testID}-add`} title="Add a document" icon="➕" size="md" variant="info" onPress={start} /> : null}
      {adding ? (
        <Card>
          <Label>What is it?</Label>
          <Chips value={adding.kind} onChange={(v) => setAdding({ ...adding, kind: v })} options={kindList.map(([value, label]) => ({ value, label }))} testIDPrefix={`${testID}-kind`} />
          <Field testID={`${testID}-name`} label="Name (optional)" value={adding.name} onChangeText={(v) => setAdding({ ...adding, name: v })} placeholder="e.g. Liquor licence 2026–27" />
          <Field label="Date on the document (YYYY-MM-DD)" value={adding.date} onChangeText={(v) => setAdding({ ...adding, date: v })} />
          <Field label="Note (optional)" value={adding.notes} onChangeText={(v) => setAdding({ ...adding, notes: v })} />
          <Btn testID={`${testID}-pick`} title={adding.file ? `File: ${adding.file.name}` : 'Choose a file (PDF, Word, photo…)'} icon="📂" size="md" variant="secondary"
            onPress={async () => { try { const f = await pickAnyFile(); if (f) setAdding((a) => ({ ...a, file: f })); } catch (e) { ui.error(e); } }} />
          <Text style={{ color: C.sub, textAlign: 'center' }}>or</Text>
          <PhotoPicker testID={`${testID}-photo`} value={adding.photos} onChange={(v) => setAdding({ ...adding, photos: v })} label="Take photos of the paper (one per page)" />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setAdding(null)} />
            <Btn testID={`${testID}-save`} title={busy ? 'Saving…' : 'Save'} variant="success" style={{ flex: 1 }} disabled={busy} onPress={save} />
          </View>
        </Card>
      ) : null}
    </View>
  );
}
