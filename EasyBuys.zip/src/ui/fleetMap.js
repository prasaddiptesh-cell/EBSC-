// The live map (1.0.0 build 26): MapLibre with the free OpenFreeMap tiles, in a web view. Places (with their circles),
// the customers on today's deliveries, and the trucks coloured by what they are doing. New data is handed to the page
// without reloading it (no flicker every refresh). Needs internet for the map tiles; the rest of the app does not.
import React, { useRef, useEffect } from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';

const STATE_COLOR = { moving: '#1D9E75', customer: '#2F6FB0', stopped: '#E59A1F', nosignal: '#A33A1C', loading: '#888780', done: '#5F5E5A' };
const HTML = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"/>
<link href="https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css" rel="stylesheet"/>
<script src="https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js"></script>
<style>html,body,#m{margin:0;height:100%;width:100%}.t{font:600 12px sans-serif;background:#fff;border-radius:6px;padding:2px 6px;box-shadow:0 1px 3px rgba(0,0,0,.3);white-space:nowrap}
.dot{width:16px;height:16px;border-radius:50%;border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4)}.sq{width:14px;height:14px;border-radius:3px;border:2px solid #fff;background:#185FA5}
.cu{width:10px;height:10px;border-radius:50%;background:#444441;border:2px solid #fff}.wrap{display:flex;flex-direction:column;align-items:center;gap:2px}</style></head>
<body><div id="m"></div><script>
var COLORS=${JSON.stringify(STATE_COLOR)};var map=new maplibregl.Map({container:'m',style:'https://tiles.openfreemap.org/styles/liberty',center:[177.45,-17.62],zoom:10,attributionControl:{compact:true}});
var marks=[];var fitted=false;
function circle(lat,lng,r){var pts=[];for(var i=0;i<=48;i++){var a=i/48*2*Math.PI;var dx=r*Math.cos(a),dy=r*Math.sin(a);pts.push([lng+dx/(111320*Math.cos(lat*Math.PI/180)),lat+dy/110540]);}return pts;}
function mk(html,lng,lat){var el=document.createElement('div');el.className='wrap';el.innerHTML=html;var m=new maplibregl.Marker({element:el}).setLngLat([lng,lat]).addTo(map);marks.push(m);}
function esc(s){return String(s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
window.setData=function(d){marks.forEach(function(m){m.remove();});marks=[];var feats=[];var b=new maplibregl.LngLatBounds();var any=false;
(d.places||[]).forEach(function(p){feats.push({type:'Feature',geometry:{type:'Polygon',coordinates:[circle(p.lat,p.lng,p.r)]},properties:{}});mk('<div class="sq"></div><div class="t">'+esc(p.name)+'</div>',p.lng,p.lat);b.extend([p.lng,p.lat]);any=true;});
(d.customers||[]).forEach(function(c){feats.push({type:'Feature',geometry:{type:'Polygon',coordinates:[circle(c.lat,c.lng,c.r)]},properties:{}});mk('<div class="cu"></div><div class="t">'+esc(c.name)+'</div>',c.lng,c.lat);b.extend([c.lng,c.lat]);any=true;});
(d.trucks||[]).forEach(function(t){mk('<div class="dot" style="background:'+(COLORS[t.state]||'#888')+'"></div><div class="t">'+esc(t.name)+(t.ago!==null&&t.ago>2?' · '+t.ago+' min ago':'')+'</div>',t.lng,t.lat);b.extend([t.lng,t.lat]);any=true;});
var src={type:'FeatureCollection',features:feats};
if(map.getSource('c')){map.getSource('c').setData(src);}else{map.addSource('c',{type:'geojson',data:src});map.addLayer({id:'c',type:'fill',source:'c',paint:{'fill-color':'#2F6FB0','fill-opacity':0.1}});map.addLayer({id:'cl',type:'line',source:'c',paint:{'line-color':'#2F6FB0','line-width':1,'line-dasharray':[2,2]}});}
if(any&&!fitted){fitted=true;map.fitBounds(b,{padding:60,maxZoom:15,duration:0});}};
var pending=null;map.on('load',function(){if(pending){window.setData(pending);pending=null;}window.ReactNativeWebView&&window.ReactNativeWebView.postMessage('ready');});
window.queueData=function(d){if(map.loaded()){window.setData(d);}else{pending=d;}};
</script></body></html>`;

export function FleetMap({ data, height = 360 }) {
  const ref = useRef(null);
  const ready = useRef(false);
  const json = JSON.stringify(data || {});
  const push = () => { if (ref.current) ref.current.injectJavaScript(`window.queueData && window.queueData(${json}); true;`); };
  useEffect(() => { if (ready.current) push(); }, [json]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <View style={{ height, borderRadius: 12, overflow: 'hidden', backgroundColor: '#E7EFE9' }}>
      <WebView ref={ref} originWhitelist={['*']} source={{ html: HTML }} javaScriptEnabled domStorageEnabled
        onMessage={(e) => { if (e.nativeEvent.data === 'ready') { ready.current = true; push(); } }} onLoadEnd={() => setTimeout(push, 800)} />
    </View>
  );
}
export const MAP_COLORS = STATE_COLOR;
