// 1.0.0 build 32 (owner, 10 Nov: "when only number input is needed the numbers should open so that it's easier to
// type"): a box that takes only a number opens the number keypad by itself – worked out from its label when the screen
// did not say. Boxes that may hold letters or dashes (invoice numbers, references, TINs, account numbers, codes, names,
// notes) keep the normal keyboard.
const TEXT = /name|note|why|what|reason|reference|\bref\b|text|e-?mail|address|invoice|\btin\b|username|code|\bsku\b|token|\bkey\b|words?\b|who|where|title|search|find|\bbank\b|town|supplier|prefix|account|one per line|paste|link|comment|answer|question|describe|description|\(e\.g\.|registration|category|group|period|yyyy|time\b|date|\$\{/i;
export function keyboardFor(label, { multiline = false } = {}) {
  const l = String(label || '');
  if (!l || multiline) return undefined;
  if (/^barcode/i.test(l)) return 'number-pad';
  if (TEXT.test(l)) return undefined;
  if (/\(\s*[−-]|[−+-]\s*=|minus|negative/i.test(l)) return 'numeric'; // numbers that can go below zero: the keypad with a minus
  if (/^(phone|mobile)\b|phone number|viber number|whatsapp/i.test(l)) return 'phone-pad';
  if (/\bpin\b/i.test(l)) return 'number-pad';
  if (/cheque (no|number)|\bz\)? (report )?(no|number)\b|barcode|odometer|hour meter/i.test(l)) return 'number-pad';
  if (/%|litres?|\bkg\b|grams?|amount|price|cost|total|balance|\brate\b|\bkm\b|weight|wage|salary|float|cash\b|money|income|yeast|flour|sugar/i.test(l)) return 'decimal-pad';
  if (/how many|minutes|\bdays?\b|\bhours?\b|weeks?\b|\byears?\b|\bmonths?\b|level|pack size|\bqty\b|quantity|\bcount\b|number of|\bunits?\b|pieces|\bpcs\b|cartons?|trays?|singles|\bage\b|times\b|\bseats?\b/i.test(l)) return 'number-pad';
  return undefined;
}
