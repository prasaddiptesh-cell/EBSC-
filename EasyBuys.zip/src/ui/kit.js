// Small shared pieces for the money modules (invoices, till, bank, payroll).
import React from 'react';
import { View, Pressable } from 'react-native';
import { Text, useScale } from './scale.js';
import { Field, Btn, useUI, useApp } from './components.js';
import { C } from './theme.js';
import { dateStr, addDays } from '../services/core.js';

// Run an action: shows the error in plain words, or a toast, and refreshes.
export function useAct() {
  const ui = useUI();
  const app = useApp();
  return (fn, ok) => {
    try {
      const r = fn();
      if (ok) ui.toast(ok);
      if (app && app.refresh) app.refresh();
      return r === undefined ? true : r;
    } catch (e) {
      ui.error(e);
      return null;
    }
  };
}

export function MoneyField({ label, value, onChange, testID, placeholder = '0.00' }) {
  return <Field testID={testID} label={label} value={value === null || value === undefined ? '' : String(value)} onChangeText={(t) => onChange(t.replace(/[^0-9.\-]/g, ''))} keyboardType="decimal-pad" placeholder={placeholder} />;
}

export function DateField({ label, value, onChange, testID }) {
  const t = dateStr();
  return (
    <View style={{ gap: 6 }}>
      <Field testID={testID} label={label} value={value || ''} onChangeText={onChange} placeholder="YYYY-MM-DD" />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="Today" size="sm" variant={value === t ? 'info' : 'secondary'} onPress={() => onChange(t)} />
        <Btn title="Yesterday" size="sm" variant={value === addDays(t, -1) ? 'info' : 'secondary'} onPress={() => onChange(addDays(t, -1))} />
      </View>
    </View>
  );
}

// A tappable row in a list: title, a line under it, a value on the right, and an optional badge.
export function ListItem({ title, sub, right, rightSub, badge, badgeColor, onPress, testID, tone }) {
  const s = useScale();
  const border = tone === 'danger' ? C.danger : tone === 'warn' ? C.warn : tone === 'success' ? C.success : C.border;
  return (
    <Pressable testID={testID} onPress={onPress} disabled={!onPress}
      style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 14, borderWidth: tone ? 2 : 1, borderColor: border, padding: 12 * s, flexDirection: 'row', alignItems: 'center', gap: 10, opacity: pressed ? 0.7 : 1 })}>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }} numberOfLines={1}>{title}</Text>
          {badge ? <View style={{ backgroundColor: badgeColor || C.info, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 2 }}><Text style={{ color: C.white, fontSize: 13, fontWeight: '800' }}>{badge}</Text></View> : null}
        </View>
        {sub ? <Text style={{ fontSize: 15, color: C.sub }} numberOfLines={2}>{sub}</Text> : null}
      </View>
      {right !== undefined ? (
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={{ fontSize: 19, fontWeight: '900', color: C.text }}>{right}</Text>
          {rightSub ? <Text style={{ fontSize: 13, color: C.sub }}>{rightSub}</Text> : null}
        </View>
      ) : null}
    </Pressable>
  );
}

// Big number tiles at the top of a section.
export function Stats({ items }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {items.filter(Boolean).map((it) => (
        <Pressable key={it.label} testID={it.testID} onPress={it.onPress} disabled={!it.onPress}
          style={({ pressed }) => ({ flexGrow: 1, flexBasis: 150, backgroundColor: C.card, borderRadius: 14, borderWidth: 2, borderColor: it.color || C.border, padding: 12, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{it.label}</Text>
          <Text style={{ fontSize: 24, fontWeight: '900', color: it.color || C.text }}>{it.value}</Text>
          {it.sub ? <Text style={{ fontSize: 13, color: C.sub }}>{it.sub}</Text> : null}
        </Pressable>
      ))}
    </View>
  );
}

export const TONE = { overdue: C.danger, due_today: C.warn, due_soon: C.warn, not_due: C.info, paid: C.success, void: C.sub, credit: C.success, to_read: C.sub };
