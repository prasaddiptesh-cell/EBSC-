// Small shared pieces for the money modules (invoices, till, bank, payroll).
import React from 'react';
import { useIsTourTarget, TOUR_OUTLINE } from './tourTarget.js';
import { View, Pressable } from 'react-native';
import { Text, useScale } from './scale.js';
import { Field, Btn, useUI, useApp } from './components.js';
import { C } from './theme.js';
import { reasonRequired, reasonLabel } from '../services/access.js';

// Run an action: shows the error in plain words, or a toast, and refreshes.
export function useAct() {
  const ui = useUI();
  const app = useApp();
  return (fn, ok) => {
    try {
      const r = fn();
      if (ok) ui.toast(ok);
      if (app && app.refresh) app.refresh();
      return r === undefined ? true : r;
    } catch (e) {
      ui.error(e);
      return null;
    }
  };
}

export function MoneyField({ label, value, onChange, testID, placeholder = '0.00' }) {
  return <Field testID={testID} label={label} value={value === null || value === undefined ? '' : String(value)} onChangeText={(t) => onChange(t.replace(/[^0-9.\-]/g, ''))} keyboardType="decimal-pad" placeholder={placeholder} />;
}

// Dates, times and periods live in dateField.js / timePicker.js; they are offered here too.
export { DateField, DateTimeField, PeriodPicker, usePeriod } from './dateField.js';
export { TimeField } from './timePicker.js';

// A tappable row in a list: title, a line under it, a value on the right, and an optional badge.
export function ListItem({ title, sub, right, rightSub, badge, badgeColor, onPress, testID, tone }) {
  const s = useScale();
  const border = tone === 'danger' ? C.danger : tone === 'warn' ? C.warn : tone === 'success' ? C.success : C.border;
  return (
    <Pressable testID={testID} onPress={onPress} disabled={!onPress}
      style={({ pressed }) => ({ backgroundColor: C.card, borderRadius: 14, borderWidth: tone ? 2 : 1, borderColor: border, padding: 12 * s, flexDirection: 'row', alignItems: 'center', gap: 10, opacity: pressed ? 0.7 : 1 })}>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }} numberOfLines={1}>{title}</Text>
          {badge ? <View style={{ backgroundColor: badgeColor || C.info, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 2 }}><Text style={{ color: C.white, fontSize: 13, fontWeight: '800' }}>{badge}</Text></View> : null}
        </View>
        {sub ? <Text style={{ fontSize: 15, color: C.sub }} numberOfLines={2}>{sub}</Text> : null}
      </View>
      {right !== undefined ? (
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={{ fontSize: 19, fontWeight: '900', color: C.text }}>{right}</Text>
          {rightSub ? <Text style={{ fontSize: 13, color: C.sub }}>{rightSub}</Text> : null}
        </View>
      ) : null}
    </Pressable>
  );
}

// Big number tiles at the top of a section.
export function Stats({ items }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {items.filter(Boolean).map((it) => (
        <Pressable key={it.label} testID={it.testID} onPress={it.onPress} disabled={!it.onPress}
          style={({ pressed }) => ({ flexGrow: 1, flexBasis: 150, backgroundColor: C.card, borderRadius: 14, borderWidth: 2, borderColor: it.color || C.border, padding: 12, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 14, color: C.sub, fontWeight: '700' }}>{it.label}</Text>
          <Text style={{ fontSize: 24, fontWeight: '900', color: it.color || C.text }}>{it.value}</Text>
          {it.sub ? <Text style={{ fontSize: 13, color: C.sub }}>{it.sub}</Text> : null}
        </Pressable>
      ))}
    </View>
  );
}

export const TONE = { overdue: C.danger, due_today: C.warn, due_soon: C.warn, not_due: C.info, paid: C.success, void: C.sub, credit: C.success, to_read: C.sub };

// ---------------------------------------------------------------- help text
// A short grey note under a section or button: what it is for, in plain words.
export function Hint({ children, testID }) {
  return (
    <View testID={testID} style={{ flexDirection: 'row', gap: 6, alignItems: 'flex-start' }}>
      <Text style={{ fontSize: 14, color: C.info }}>ⓘ</Text>
      <Text style={{ flex: 1, fontSize: 14, color: C.sub, lineHeight: 20 }}>{children}</Text>
    </View>
  );
}
// "What is this?" – tap to open a longer explanation (for accounting / payroll words).
export function Explain({ title = 'What is this?', children, testID }) {
  const [open, setOpen] = React.useState(false);
  return (
    <View style={{ gap: 6 }}>
      <Pressable testID={testID} onPress={() => setOpen(!open)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingVertical: 4 }}>
        <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: C.infoSoft, alignItems: 'center', justifyContent: 'center' }}><Text style={{ fontSize: 14, fontWeight: '900', color: C.info }}>?</Text></View>
        <Text style={{ fontSize: 15, fontWeight: '700', color: C.info }}>{title}</Text>
      </Pressable>
      {open ? <View style={{ backgroundColor: C.infoSoft, borderRadius: 12, padding: 12 }}><Text style={{ fontSize: 15, color: C.text, lineHeight: 22 }}>{children}</Text></View> : null}
    </View>
  );
}
// A menu action with its explanation beside it.
export function Action({ icon, title, note, onPress, badge, testID, tone }) {
  const s = useScale();
  const tourOn = useIsTourTarget(testID);
  return (
    <Pressable testID={testID} onPress={onPress}
      style={({ pressed }) => ({ flexGrow: 1, flexBasis: 260, minHeight: 74 * s, backgroundColor: C.card, borderRadius: 14, borderWidth: 2, borderColor: tone === 'warn' ? C.warn : tone === 'danger' ? C.danger : C.border,
        padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12, opacity: pressed ? 0.7 : 1, ...(tourOn ? TOUR_OUTLINE : {}) })}>
      <Text style={{ fontSize: 30 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{title}</Text>
          {badge ? <View style={{ backgroundColor: tone === 'danger' ? C.danger : C.warn, borderRadius: 10, paddingHorizontal: 8 }}><Text style={{ color: C.white, fontWeight: '900', fontSize: 13 }}>{badge}</Text></View> : null}
        </View>
        {note ? <Text style={{ fontSize: 14, color: C.sub, lineHeight: 19 }}>{note}</Text> : null}
      </View>
      <Text style={{ fontSize: 22, color: C.sub }}>›</Text>
    </Pressable>
  );
}
export function Actions({ children }) {
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>{children}</View>;
}

// Owner and Admin never have to give a reason: the box says "(optional)" for them. Everyone else is asked as before.
function whoAsks(app) { return app ? app.realUser || app.user : null; }
export function useReasonRequired() { return reasonRequired(whoAsks(useApp())); }
export { reasonLabel };
// A reason box: same as Field, but optional for owner/admin.
export function ReasonField({ label = 'Reason', ...rest }) {
  const app = useApp();
  return <Field {...rest} label={reasonLabel(whoAsks(app), label)} />;
}

// A button that first asks for a reason (void, cancel, write off…), then runs onDo(reason).
// For owner/admin the reason is optional (still recorded when typed).
export function ReasonButton({ title, icon, prompt = 'Why?', confirm = 'Confirm', variant = 'danger', size = 'md', onDo, testID, style }) {
  const [open, setOpen] = React.useState(false);
  const [why, setWhy] = React.useState('');
  const app = useApp();
  if (!open) return <Btn testID={testID} title={title} icon={icon} size={size} variant={variant === 'danger' ? 'secondary' : variant} style={style} onPress={() => setOpen(true)} />;
  return (
    <View style={[{ gap: 8, borderWidth: 2, borderColor: C.border, borderRadius: 14, padding: 10, flexGrow: 1 }, style]}>
      <Field testID={testID ? `${testID}-why` : undefined} label={reasonLabel(whoAsks(app), prompt)} value={why} onChangeText={setWhy} multiline />
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Btn title="Back" size="sm" variant="secondary" style={{ flex: 1 }} onPress={() => { setOpen(false); setWhy(''); }} />
        <Btn testID={testID ? `${testID}-ok` : undefined} title={confirm} size="sm" variant={variant} style={{ flex: 1 }} onPress={() => { const r = onDo(why); if (r !== null && r !== false) { setOpen(false); setWhy(''); } }} />
      </View>
    </View>
  );
}
