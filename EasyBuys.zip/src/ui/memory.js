// Remembers small things per open screen (scroll position, filters, search text) so going back shows the screen
// exactly as it was left. Kept in memory only (nothing saved); keyed by the screen's place in the navigation stack.
const mem = new Map();
const MAX = 400;

export function remember(key, value) {
  if (!key) return;
  mem.delete(key);
  mem.set(key, value);
  if (mem.size > MAX) mem.delete(mem.keys().next().value);
}
export function recall(key) {
  return key ? mem.get(key) : undefined;
}
export function forgetAll() {
  mem.clear();
}
// The key of the screen that is open: its name and its place in the stack (going back returns to the same key).
export function screenKey(app) {
  const cur = app && app.currentScreen;
  return cur ? `${cur.name}#${cur.key}` : null;
}
