// v3.9.8 "Paid now" for a delivery or bill with no purchase order: how it was paid and where the money came from.
// Cash must say where it came from – the shop's safe or which till (no default). Nothing is written to the till: the
// person counting that till sees it as paid out. M-PAiSA comes from the receiving shop's own wallet.
import React from 'react';
import { View } from 'react-native';
import { Text } from './scale.js';
import { Card, Chips, Field, Select } from './components.js';
import { C } from './theme.js';
import { Hint } from './kit.js';
import { db } from '../db/connection.js';

const all = (sql, a) => { try { return db().all(sql, a || []); } catch (e) { return []; } };
export const NOT_PAID = { method: '', cashFrom: '', accountUid: '', chequeNo: '', reference: '', walletUid: '' };

// The values for receiveDelivery / snap: null when not paid now.
export function paidNowValue(p) { return p && p.method ? { ...p } : null; }
// A short check before saving: '' when fine, else what is missing.
export function paidNowProblem(p) {
  if (!p || !p.method) return '';
  if (p.method === 'cash' && !p.cashFrom) return 'Say where the cash came from: the safe or which till.';
  if ((p.method === 'cheque' || p.method === 'transfer') && !p.accountUid) return 'Choose the bank account.';
  if (p.method === 'cheque' && !String(p.chequeNo || '').trim()) return 'Enter the cheque number.';
  if ((p.method === 'transfer' || p.method === 'mpaisa') && !String(p.reference || '').trim()) return 'Enter the reference.';
  if (p.method === 'mpaisa' && !p.walletUid) return 'This shop has no M-PAiSA wallet set up yet.';
  return '';
}

export function BuyTypeChips({ value, onChange, testID = 'buy-type' }) {
  return (
    <Chips value={value} onChange={onChange} testIDPrefix={testID} options={[
      { value: 'supplier_came', label: '🚚 Supplier came to the shop' },
      { value: 'cash_buy', label: '🛒 We bought it (cash buy)' },
    ]} />
  );
}

export function PaidNowCard({ value, onChange, shopCode, testID = 'paid' }) {
  const p = value || NOT_PAID;
  const set = (k) => (v) => onChange({ ...p, [k]: v, ...(k === 'method' ? { cashFrom: '', chequeNo: '', reference: '' } : {}) });
  const tills = all('SELECT uid, name FROM tills WHERE shop_code = ? AND active = 1 ORDER BY sort, name', [shopCode]);
  const banks = all('SELECT uid, name FROM bank_accounts WHERE active = 1 ORDER BY name');
  const wallets = all('SELECT uid, name FROM wallets WHERE shop_code = ? AND active = 1 ORDER BY sort', [shopCode]);
  if (p.method === 'mpaisa' && !p.walletUid && wallets.length) setTimeout(() => onChange({ ...p, walletUid: wallets[0].uid }), 0);
  return (
    <Card>
      <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>Paid now?</Text>
      <Chips value={p.method} onChange={set('method')} testIDPrefix={`${testID}-m`} options={[
        { value: '', label: 'Not paid yet' }, { value: 'cash', label: '💵 Cash' }, { value: 'cheque', label: '🧾 Cheque' }, { value: 'transfer', label: '🏦 Bank transfer' }, { value: 'mpaisa', label: '📱 M-PAiSA' },
      ]} />
      {p.method === 'cash' ? (
        <>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.text }}>Where did the cash come from?</Text>
          <Chips value={p.cashFrom} onChange={set('cashFrom')} testIDPrefix={`${testID}-from`} options={[{ value: 'safe', label: '🔐 The shop\'s safe' }].concat(tills.map((t) => ({ value: `till:${t.uid}`, label: `🧾 ${t.name}` })))} />
          {String(p.cashFrom).startsWith('till:') ? <Hint>Nothing is changed on the till by itself. The person counting this till sees this payment and enters it as cash paid out.</Hint> : null}
        </>
      ) : null}
      {p.method === 'cheque' || p.method === 'transfer' ? (
        <Select testID={`${testID}-acc`} label="Bank account" value={p.accountUid} onChange={set('accountUid')} options={[{ value: '', label: 'Choose' }].concat(banks.map((b) => ({ value: b.uid, label: b.name })))} />
      ) : null}
      {p.method === 'cheque' ? <Field testID={`${testID}-chq`} label="Cheque number" value={p.chequeNo} onChangeText={set('chequeNo')} keyboardType="number-pad" /> : null}
      {p.method === 'transfer' || p.method === 'mpaisa' ? <Field testID={`${testID}-ref`} label={p.method === 'mpaisa' ? 'M-PAiSA transaction reference' : 'Transfer reference'} value={p.reference} onChangeText={set('reference')} /> : null}
      {p.method === 'mpaisa' ? <Hint>{wallets.length ? `From ${wallets.find((w) => w.uid === p.walletUid)?.name || wallets[0].name}.` : 'This shop has no M-PAiSA wallet set up yet (Bank › M-PAiSA wallets).'}</Hint> : null}
      {p.method ? <Hint>The payment is recorded now, so this invoice is not paid twice. It shows in To verify as "No order" with how it was paid.</Hint> : null}
    </Card>
  );
}
