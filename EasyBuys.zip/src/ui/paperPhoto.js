// v3.9.2 Photo of paper that fills in the boxes. Used wherever figures come from a paper (Z report, invoice, receipt,
// deposit slip, lodgement receipt, payment proof…):
//   const pr = usePaper('deposit');
//   <PaperPhoto pr={pr} value={photos} onChange={setPhotos} form={f} setForm={setF} map={{ total: 'amount', date: 'date' }} />
//   on Save:   if (!pr.okToSave(ui)) return;   …save…   pr.log(user, 'deposits', uid, f);
// Taking the photo reads it straight away (on the tablet, offline). Only empty boxes are filled – never over what the
// person typed. The boxes filled are listed with their figures, the sums are checked, and the person must tick that they
// checked the figures against the paper before saving. What was read and what the person changed is kept.
import React, { useRef, useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text } from './scale.js';
import { Banner, Btn, PhotoPicker } from './components.js';
import { C } from './theme.js';
import { fillEmpty, changesAfterRead, PAPER_LABELS, AI_PAPER_KINDS, AUTO_AI_KINDS } from '../services/paperRead.js';

const INIT = { status: 'idle', read: null, engine: null, label: '', aiPending: false, text: '', filled: [], message: '', checked: false };
const label = (k, labels) => (labels && labels[k]) || PAPER_LABELS[k] || (String(k).startsWith('tender:') ? String(k).slice(7) : k);
const NOT_MONEY = /litre|customers|number|no$|No$|ref|date|tin|name|branch|account|Uid|uid|kind|method|shop|what|note/i;
const showVal = (v, k = '') => {
  if (v === null || v === undefined || v === '') return '(empty)';
  const n = Number(v);
  if (NOT_MONEY.test(k) && !/^tender:/.test(k)) return String(v);
  return Number.isFinite(n) && /^-?\d+(\.\d+)?$/.test(String(v).trim()) ? `$${n.toFixed(2)}` : String(v);
};

export function usePaper(kind, extra = {}) {
  const [s, setS] = useState(INIT);
  const sRef = useRef(s);
  sRef.current = s;
  const busy = useRef(false);
  const api = {
    ...s,
    kind,
    extra,
    reading: s.status === 'reading',
    setChecked: (v) => setS((o) => ({ ...o, checked: !!v })),
    // Reads the photos; fill(fields, prevFilled) puts them into the form and returns the boxes it filled.
    async run(uris, fill) {
      if (busy.current || !uris || !uris.length) return;
      busy.current = true;
      setS((o) => ({ ...o, status: 'reading', message: '' }));
      try {
        const { readPaper } = require('../platform/paperReader.js');
        const r = await readPaper(kind, uris, extra);
        if (!r.ok) { setS((o) => ({ ...o, status: 'failed', message: r.message, engine: r.engine || null, text: r.text || '', read: r.read || null })); return; }
        let filled = [];
        try { filled = (fill ? fill(r.read.fields, sRef.current.filled) : []) || []; } catch (e) { filled = []; try { console.warn('paper fill', e && e.message); } catch (x) { /* ignore */ } }
        setS((o) => ({ ...o, status: 'done', read: r.read, engine: r.engine, label: r.label || '', aiPending: !!r.aiPending, text: r.text, filled, checked: false }));
      } catch (e) {
        setS((o) => ({ ...o, status: 'failed', message: e && e.message ? e.message : String(e) }));
      } finally { busy.current = false; }
    },
    // false (and a message) while figures read from the photo are not ticked as checked.
    okToSave(ui) {
      const cur = sRef.current;
      if (cur.status === 'reading') { if (ui) ui.toast('Still reading the photo – one moment'); return false; }
      if (cur.filled.length && !cur.checked) {
        if (ui) ui.alert({ title: 'Check the figures first', message: 'Some boxes were filled in from the photo. Look at each one against the paper, then tick "I checked these figures against the paper".', tone: 'warn' });
        return false;
      }
      return true;
    },
    // After saving: keep what was read and what the person changed (change history + photo reading log).
    log(user, table, uid, form, map, changedList) {
      const cur = sRef.current;
      if (!cur.read) return;
      try {
        const { logPaperRead } = require('../services/paperLog.js');
        const changed = changedList || (map ? changesAfterRead(form || {}, cur.read.fields, map) : []);
        logPaperRead(user, { kind, table, uid, engine: cur.engine, text: cur.text, fields: cur.read.fields, filled: cur.filled, changed, checked: cur.checked });
      } catch (e) { /* never stops the save */ }
    },
    // What to keep with the record: { kind, engine, fields, filled, changed, checked }
    summary(changed = []) { const cur = sRef.current; return cur.read ? { kind, engine: cur.engine, fields: cur.read.fields, filled: cur.filled, changed, checked: cur.checked } : null; },
    reset() { setS(INIT); },
  };
  return api;
}

// The photo box plus what was read. Either map (read field → form key) or apply(form, fields, prevFilled) → { form, filled }.
export function PaperPhoto({ pr, value = [], onChange, form, setForm, map, apply, soft, label: title, required, testID = 'pp', labels, hint, children, display }) {
  const formRef = useRef(form);
  formRef.current = form;
  const [showText, setShowText] = useState(false);
  const fill = (fields, prev) => {
    const cur = formRef.current || {};
    const r = apply ? apply(cur, fields, prev) : fillEmpty(cur, fields, map || {}, prev, soft);
    const keys = r.filled || [];
    if (keys.length && setForm) {
      setForm((o) => {
        const x = { ...o };
        for (const k of keys) { const fk = String(k).startsWith('tender:') ? 'tenders' : k; x[fk] = r.form[fk]; }
        return x;
      });
    }
    return keys;
  };
  // 1.0.0 build 20 (owner): the AI is slow – invoices, fuel receipts and bills are read only when "Ask the AI to read it"
  // is tapped. Other papers are read on this phone straight away (quick).
  const auto = AUTO_AI_KINDS.includes(pr && pr.kind); // build 31: a cheque is read by the AI at once
  const onAsk = AI_PAPER_KINDS.includes(pr && pr.kind) && !auto;
  const change = (list) => {
    onChange(list);
    // A new photo: read it straight away (all the photos, so a second page adds to the first).
    if (!onAsk && (list || []).length > (value || []).length) pr.run(list, fill);
  };
  const read = pr.read;
  const filledLines = pr.filled.map((k) => {
    const fk = String(k).startsWith('tender:') ? null : k;
    const v = fk ? (form || {})[fk] : (((form || {}).tenders || []).find((t) => t.method === String(k).slice(7)) || {}).amount;
    return `• ${label(k, labels)}: ${display && display(k, v) !== undefined ? display(k, v) : showVal(v, k)}`;
  });
  return (
    <View style={{ gap: 8 }}>
      <PhotoPicker testID={testID} paper label={title || 'Photo'} value={value} onChange={change} required={required} pages={['invoice', 'fuel', 'statement', 'efl_bill'].includes(pr && pr.kind)} pdf={['invoice', 'fuel', 'efl_bill'].includes(pr && pr.kind)} />
      {hint && pr.status === 'idle' && !onAsk ? <Text style={{ fontSize: 14, color: C.sub }}>📷 {hint}</Text> : null}
      {onAsk && pr.status === 'idle' ? (value.length
        ? <Btn testID={`${testID}-ask-ai`} title="Ask the AI to read it" icon="🤖" size="md" variant="info" onPress={() => pr.run(value, fill)} />
        : <Text style={{ fontSize: 14, color: C.sub }}>📷 Scan the paper, then type the figures – or tap "Ask the AI to read it" (it takes a little while).</Text>) : null}
      {pr.status === 'reading' ? <Banner testID={`${testID}-reading`} tone="info" message={onAsk || auto ? 'The AI is reading it… the boxes fill in by themselves when it is done. You can keep typing.' : 'Reading the photo… the boxes will fill in by themselves.'} /> : null}
      {pr.status === 'failed' ? (
        <View style={{ gap: 6 }}>
          <Banner testID={`${testID}-failed`} tone="warn" title="Could not read the photo" message={`${pr.message || ''}\nType the figures in yourself.`} />
          {value.length ? <Btn testID={`${testID}-reread`} title="Try reading it again" icon="🔁" size="sm" variant="secondary" onPress={() => pr.run(value, fill)} /> : null}
        </View>
      ) : null}
      {pr.status === 'done' ? (
        <View style={{ gap: 6 }}>
          {pr.label ? <Text testID={`${testID}-engine`} style={{ fontSize: 14, fontWeight: '800', color: pr.engine === 'ai' ? C.success : C.warn }}>{pr.engine === 'ai' ? '🤖 ' : '📱 '}{pr.label}{pr.aiPending ? ' · AI re-read when online (tap "Read again")' : ''}</Text> : null}
          {pr.filled.length ? (
            <Banner testID={`${testID}-filled`} tone="info" title={`Filled in from the photo (${pr.filled.length}) – check each one against the paper`} message={filledLines.join('\n')} />
          ) : (
            <Banner testID={`${testID}-nothing`} tone="info" message={read && read.found ? 'The photo was read, but the boxes already had figures – nothing was changed. Compare them with the paper.' : 'Nothing could be read from the photo – type the figures in.'} />
          )}
          {children}
          {((read && read.checks) || []).map((c, i) => <Banner key={i} testID={`${testID}-check-${c.key || i}`} tone={c.level === 'ok' ? 'success' : 'warn'} message={c.text} />)}
          {pr.filled.length ? (
            <Pressable testID={`${testID}-checked`} onPress={() => pr.setChecked(!pr.checked)} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 12, borderWidth: 2, borderColor: pr.checked ? C.success : C.warn, backgroundColor: pr.checked ? C.successSoft : C.warnSoft, opacity: pressed ? 0.7 : 1 })}>
              <Text style={{ fontSize: 26 }}>{pr.checked ? '☑️' : '⬜'}</Text>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text, flex: 1 }}>I checked these figures against the paper</Text>
            </Pressable>
          ) : null}
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            <Btn testID={`${testID}-reread`} title="Read again" icon="🔁" size="sm" variant="ghost" onPress={() => pr.run(value, fill)} />
            {pr.text ? <Btn testID={`${testID}-text`} title={showText ? 'Hide what was read' : 'Show what was read'} icon="📄" size="sm" variant="ghost" onPress={() => setShowText(!showText)} /> : null}
          </View>
          {showText ? <Text selectable style={{ fontSize: 13, color: C.sub, fontFamily: 'monospace' }}>{pr.text}</Text> : null}
        </View>
      ) : null}
    </View>
  );
}

// A paid receipt / invoice into a simple form. keys: { amount: formKey for the total, date, note: formKey for "what",
// supplier: formKey for the supplier uid, ref: formKey for the receipt number, vat: formKey }.
// The "what" box gets "<shop on the receipt> receipt <number>" when empty.
export function receiptApply(form, x, prev = [], keys = {}, today) {
  const map = {};
  if (keys.amount) map.total = keys.amount;
  if (keys.date) map.date = keys.date;
  if (keys.ref) map.invoiceNo = keys.ref;
  if (keys.vat) map.vat = keys.vat;
  if (keys.supplier) map.supplierUid = keys.supplier;
  if (keys.litres) map.litres = keys.litres;
  if (keys.price) map.pricePerLitre = keys.price;
  const soft = {};
  if (keys.date) soft[keys.date] = today || require('../services/core.js').dateStr();
  const r = fillEmpty(form, x, map, prev, soft);
  if (keys.note && (form[keys.note] === '' || form[keys.note] === undefined || form[keys.note] === null || prev.includes(keys.note)) && (x.supplierName || x.invoiceNo)) {
    r.form[keys.note] = `${x.supplierName || 'Receipt'}${x.invoiceNo ? ` receipt ${x.invoiceNo}` : ''}`;
    r.filled.push(keys.note);
  }
  return r;
}
