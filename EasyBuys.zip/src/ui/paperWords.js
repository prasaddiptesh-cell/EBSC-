// build 29: every photo of paper uses the scanner (edges found, cropped straight) – decided from its label when the screen
// does not say: cheques, invoices, receipts, slips, Z reports, statements, sick sheets, certificates, letters. Photos of
// goods, damage, wastage or a place keep the plain camera.
const PAPER_RE = /cheque|check\b|invoice|receipt|slip|z report|statement|sick sheet|certificate|letter|\bcv\b|document|bill|docket|delivery note|credit note|agreement|contract|form|page/i;
const NOT_PAPER_RE = /goods|damage|wastage|items|product|shop front|the shop|place|stock|shelf|selfie|face/i;
export function isPaperPhoto(label, paper) {
  if (paper !== undefined && paper !== null) return !!paper;
  const t = String(label || '');
  return PAPER_RE.test(t) && !NOT_PAPER_RE.test(t);
}
