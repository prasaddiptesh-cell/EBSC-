// Photos: thumbnails that open full screen, with zoom, and next / previous when there are several.
import React, { useState } from 'react';
import { View, Image, Pressable, Modal, ScrollView, Linking, useWindowDimensions } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';

export function PhotoViewer({ photos, index = 0, onClose }) {
  const { width, height } = useWindowDimensions();
  const [i, setI] = useState(index);
  const [zoom, setZoom] = useState(1);
  const list = photos || [];
  const cur = list[i];
  if (!cur) return null;
  const isLocal = !/^https?:/.test(cur.uri || '');
  const go = (d) => { setZoom(1); setI((n) => (n + d + list.length) % list.length); };
  const btn = { minWidth: 56, height: 52, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12 };
  return (
    <Modal visible transparent={false} animationType="fade" onRequestClose={onClose}>
      <View testID="photo-viewer" style={{ flex: 1, backgroundColor: '#111' }}>
        <ScrollView horizontal contentContainerStyle={{ minWidth: width }} maximumZoomScale={4} minimumZoomScale={1}>
          <ScrollView contentContainerStyle={{ minHeight: height - 90, alignItems: 'center', justifyContent: 'center' }}>
            {isLocal || /\.(jpe?g|png)$/i.test(cur.uri) ? (
              <Pressable onPress={() => setZoom(zoom === 1 ? 2 : 1)}>
                <Image source={{ uri: cur.uri }} resizeMode="contain" style={{ width: width * zoom, height: (height - 90) * zoom }} />
              </Pressable>
            ) : (
              <View style={{ padding: 30, alignItems: 'center', gap: 14 }}>
                <Text style={{ color: '#fff', fontSize: 18, textAlign: 'center' }}>This photo is saved in Google Drive (it was taken on another device).</Text>
                <Pressable onPress={() => Linking.openURL(cur.uri)} style={[btn, { backgroundColor: C.info }]}><Text style={{ color: '#fff', fontSize: 18, fontWeight: '800' }}>Open in Google Drive</Text></Pressable>
              </View>
            )}
          </ScrollView>
        </ScrollView>
        <View style={{ height: 90, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 10 }}>
          {list.length > 1 ? <Pressable testID="photo-prev" onPress={() => go(-1)} style={btn}><Text style={{ color: '#fff', fontSize: 24, fontWeight: '800' }}>‹</Text></Pressable> : null}
          <Pressable testID="photo-zoom-out" onPress={() => setZoom(Math.max(1, zoom - 0.5))} style={btn}><Text style={{ color: '#fff', fontSize: 24, fontWeight: '800' }}>−</Text></Pressable>
          <Text style={{ color: '#fff', fontSize: 16, minWidth: 90, textAlign: 'center' }}>{list.length > 1 ? `${i + 1} of ${list.length} · ` : ''}{Math.round(zoom * 100)}%</Text>
          <Pressable testID="photo-zoom-in" onPress={() => setZoom(Math.min(4, zoom + 0.5))} style={btn}><Text style={{ color: '#fff', fontSize: 24, fontWeight: '800' }}>+</Text></Pressable>
          {list.length > 1 ? <Pressable testID="photo-next" onPress={() => go(1)} style={btn}><Text style={{ color: '#fff', fontSize: 24, fontWeight: '800' }}>›</Text></Pressable> : null}
          <Pressable testID="photo-close" onPress={onClose} style={[btn, { backgroundColor: C.primary }]}><Text style={{ color: '#fff', fontSize: 18, fontWeight: '800' }}>Close</Text></Pressable>
        </View>
        {cur.caption ? <Text style={{ position: 'absolute', top: 16, left: 16, right: 16, color: '#fff', fontSize: 16, fontWeight: '700' }}>{cur.caption}</Text> : null}
      </View>
    </Modal>
  );
}

// A row of thumbnails; tap one to see it full screen. photos: [{ uri, caption }]
export function PhotoStrip({ photos, size = 120, testID }) {
  const [open, setOpen] = useState(null);
  const list = (photos || []).filter((p) => p && p.uri);
  if (!list.length) return null;
  return (
    <View testID={testID} style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {list.map((p, k) => (
        <Pressable key={p.uri + k} testID={testID ? `${testID}-${k}` : undefined} onPress={() => setOpen(k)}
          style={{ width: size, height: size * 1.25, borderRadius: 12, overflow: 'hidden', borderWidth: 2, borderColor: C.border, backgroundColor: '#eee', alignItems: 'center', justifyContent: 'center' }}>
          {/^https?:/.test(p.uri) && !/\.(jpe?g|png)$/i.test(p.uri) ? <Text style={{ fontSize: 14, color: C.info, textAlign: 'center', padding: 6 }}>Photo in Google Drive{'\n'}(tap)</Text>
            : <Image source={{ uri: p.uri }} style={{ width: '100%', height: '100%' }} />}
          <View style={{ position: 'absolute', right: 4, bottom: 4, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 8, paddingHorizontal: 6 }}><Text style={{ color: '#fff', fontSize: 12 }}>⤢</Text></View>
        </Pressable>
      ))}
      {open !== null ? <PhotoViewer photos={list} index={open} onClose={() => setOpen(null)} /> : null}
    </View>
  );
}

// Local photos for a record, plus any Drive links, as one list.
export function photosFor(local, urls, caption) {
  const out = (local || []).map((p) => ({ uri: p.uri, caption }));
  if (!out.length) (urls || []).forEach((u) => out.push({ uri: u, caption }));
  return out;
}
