// QR codes drawn with plain Views (no internet, no extra library).
import React, { useMemo } from 'react';
import { View } from 'react-native';
import { qrMatrix } from './qrMatrix.js';

export { qrMatrix };

// Each row is drawn as a few dark runs, so even a big code is only a few hundred Views.
export function QRCodeView({ value, size = 260, testID }) {
  const rows = useMemo(() => qrMatrix(value), [value]);
  const quiet = 4;
  const cell = Math.max(1, Math.floor(size / (rows.length + quiet * 2)));
  const total = cell * (rows.length + quiet * 2);
  return (
    <View testID={testID} style={{ width: total, height: total, backgroundColor: '#FFFFFF', padding: cell * quiet }}>
      {rows.map((row, r) => {
        const runs = [];
        let c = 0;
        while (c < row.length) {
          const dark = row[c];
          let e = c;
          while (e < row.length && row[e] === dark) e++;
          runs.push({ dark, len: e - c, start: c });
          c = e;
        }
        return (
          <View key={r} style={{ flexDirection: 'row', height: cell }}>
            {runs.map((x) => <View key={x.start} style={{ width: x.len * cell, height: cell, backgroundColor: x.dark ? '#000000' : '#FFFFFF' }} />)}
          </View>
        );
      })}
    </View>
  );
}
