// QR code as rows of dark/light squares (pure JavaScript, works offline).
import QRCode from '../vendor/qrcode/index.js';
import ECL from '../vendor/qrcode/QRErrorCorrectLevel.js';

// text -> rows of true (dark) / false (light)
export function qrMatrix(text, level = 'M') {
  const q = new QRCode(-1, ECL[level]);
  q.addData(String(text));
  q.make();
  const n = q.getModuleCount();
  const rows = [];
  for (let r = 0; r < n; r++) {
    const row = [];
    for (let c = 0; c < n; c++) row.push(q.isDark(r, c));
    rows.push(row);
  }
  return rows;
}
