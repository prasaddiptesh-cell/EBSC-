// Every pop-up and full-screen preview goes through this (v3.9.4). Newer Android draws apps edge to edge, so a plain
// Modal ran under the status bar at the top (headings and notices cut off) and under the navigation bar / Samsung
// taskbar at the bottom (Send, Print, Not now could not be tapped). This keeps the content inside the safe area.
// The extra space is added to the pop-up's own outer layer (its dimmed background or page), so its layout stays exactly
// as designed (lists keep their height limits and scroll); only when there is no single outer layer is a frame added.
import React, { useContext } from 'react';
import { Modal, View, StyleSheet } from 'react-native';
import { SafeAreaInsetsContext, initialWindowMetrics } from 'react-native-safe-area-context';

export function useEdgeInsets() {
  const ctx = useContext(SafeAreaInsetsContext) || {};
  const first = (initialWindowMetrics && initialWindowMetrics.insets) || {};
  // The training bar sets the top to 0 for the screens under it; a pop-up covers that bar, so it takes the real one.
  const pick = (k) => Math.max(Number(ctx[k]) || 0, Number(first[k]) || 0);
  return { top: pick('top'), bottom: pick('bottom'), left: pick('left'), right: pick('right') };
}

const SIDES = { top: ['paddingTop', 'paddingVertical'], bottom: ['paddingBottom', 'paddingVertical'], left: ['paddingLeft', 'paddingHorizontal'], right: ['paddingRight', 'paddingHorizontal'] };
function padded(style, insets) {
  const st = StyleSheet.flatten(style) || {};
  const out = {};
  for (const [side, [own, axis]] of Object.entries(SIDES)) {
    const base = Number(st[own] ?? st[axis] ?? st.padding ?? 0) || 0;
    out[own] = base + insets[side];
  }
  return [style, out];
}

export function SafeModal({ children, transparent, backgroundColor, ...rest }) {
  const insets = useEdgeInsets();
  const list = React.Children.toArray(children).filter(Boolean);
  const one = list.length === 1 && React.isValidElement(list[0]) ? list[0] : null;
  const body = one
    ? React.cloneElement(one, { style: padded(one.props.style, insets) })
    : (
      <View style={{ flex: 1, paddingTop: insets.top, paddingBottom: insets.bottom, paddingLeft: insets.left, paddingRight: insets.right, backgroundColor: transparent ? 'transparent' : backgroundColor || '#F4F1EC' }}>
        {children}
      </View>
    );
  return (
    <Modal {...rest} transparent={transparent} statusBarTranslucent navigationBarTranslucent>
      {body}
    </Modal>
  );
}
