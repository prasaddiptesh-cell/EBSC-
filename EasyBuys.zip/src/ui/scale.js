// Display size: one number (1 = normal) that makes every text and button bigger or smaller.
// Set per device from the "Aa" button on every screen.
import React, { createContext, useContext } from 'react';
import { Text as RNText, TextInput as RNTextInput, StyleSheet } from 'react-native';

export const ScaleContext = createContext(1);
export const useScale = () => useContext(ScaleContext);
// Changes the size (null = back to normal). Provided by App.js.
export const ScaleSetterContext = createContext(() => {});

function scaled(style, s) {
  if (s === 1) return style;
  const f = StyleSheet.flatten(style) || {};
  const extra = { fontSize: (f.fontSize || 14) * s };
  if (f.lineHeight) extra.lineHeight = f.lineHeight * s;
  if (f.minHeight) extra.minHeight = f.minHeight * s;
  return [style, extra];
}

export const Text = React.forwardRef(function Text(props, ref) {
  const s = useScale();
  return <RNText ref={ref} {...props} style={scaled(props.style, s)} />;
});
export const TextInput = React.forwardRef(function TextInput(props, ref) {
  const s = useScale();
  return <RNTextInput ref={ref} {...props} style={scaled(props.style, s)} />;
});
