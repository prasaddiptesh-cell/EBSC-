// After saving a deposit, cheque / payment, invoice or purchase order: offer to send a PDF of it
// (with the photo) to the Viber group. The phone's share list opens: tap Viber, then the group.
import { shareReport, withPhotos } from '../platform/files.js';
import { verifyRules } from '../modules/verify/service.js';
import { logError } from '../services/errorLog.js';

export async function offerPdf(ui, build, { title = 'Send a PDF to the Viber group?', force = false } = {}) {
  try {
    if (!force && verifyRules().askPdf === false) return false;
    const doc = typeof build === 'function' ? build() : build;
    if (!doc) return false;
    const ok = await ui.confirm({ title, message: `${doc.text || ''}\n\nA PDF with these details${doc.photos && doc.photos.length ? ' and the photo' : ''} is made. Choose Viber, then the group.`, confirmText: 'Send PDF', cancelText: 'Not now' });
    if (!ok) return false;
    const rep = await withPhotos(doc.rep, doc.photos);
    await shareReport(rep, 'pdf');
    return true;
  } catch (e) {
    logError(e, { where: 'send PDF' });
    ui.error(e);
    return false;
  }
}
