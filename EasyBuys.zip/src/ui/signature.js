// Sign with a finger on the screen. Gives a small PNG (data URL) – kept with the record and shown on the PDF.
import React, { useRef, useState } from 'react';
import { View, Image } from 'react-native';
import { WebView } from 'react-native-webview';
import { Text } from './scale.js';
import { Btn } from './components.js';
import { C } from './theme.js';

const HTML = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<style>html,body{margin:0;height:100%;background:#fff;overflow:hidden;touch-action:none}canvas{width:100%;height:100%;display:block}
.line{position:absolute;left:6%;right:6%;bottom:28%;border-bottom:1px dashed #bbb;pointer-events:none}</style></head><body><!-- EB_SIGNATURE -->
<div class="line"></div><canvas id="c"></canvas><script>
var c=document.getElementById('c'),x=c.getContext('2d'),d=false,used=false,r=window.devicePixelRatio||1;
function size(){c.width=c.clientWidth*r;c.height=c.clientHeight*r;x.scale(r,r);x.lineWidth=2.6;x.lineCap='round';x.lineJoin='round';x.strokeStyle='#111';}
size();
function p(e){var t=e.touches?e.touches[0]:e,b=c.getBoundingClientRect();return{x:t.clientX-b.left,y:t.clientY-b.top};}
function send(){if(!used)return;var o=document.createElement('canvas');o.width=360;o.height=120;var ox=o.getContext('2d');ox.fillStyle='#fff';ox.fillRect(0,0,360,120);
ox.drawImage(c,0,0,360,120);window.ReactNativeWebView.postMessage(JSON.stringify({type:'sig',data:o.toDataURL('image/png')}));}
function s(e){e.preventDefault();d=true;var q=p(e);x.beginPath();x.moveTo(q.x,q.y);}
function m(e){if(!d)return;e.preventDefault();var q=p(e);x.lineTo(q.x,q.y);x.stroke();used=true;}
function u(){if(d){d=false;send();}}
c.addEventListener('touchstart',s,{passive:false});c.addEventListener('touchmove',m,{passive:false});c.addEventListener('touchend',u);
c.addEventListener('mousedown',s);c.addEventListener('mousemove',m);window.addEventListener('mouseup',u);
window.clearPad=function(){x.clearRect(0,0,c.width,c.height);used=false;window.ReactNativeWebView.postMessage(JSON.stringify({type:'sig',data:null}));};
</script></body></html>`;

export function SignaturePad({ value, onChange, label = 'Sign here with your finger', height = 180, testID = 'sig' }) {
  const ref = useRef(null);
  const [key, setKey] = useState(0);
  const onMessage = (e) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type === 'sig') onChange(m.data);
    } catch (err) { /* ignore */ }
  };
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{label}</Text>
      <View style={{ height, borderWidth: 2, borderColor: value ? C.success : C.border, borderRadius: 12, overflow: 'hidden', backgroundColor: C.white }}>
        <WebView key={key} ref={ref} testID={testID} originWhitelist={['*']} source={{ html: HTML }} onMessage={onMessage} scrollEnabled={false} style={{ flex: 1 }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        <Btn testID={`${testID}-clear`} title="Clear" size="sm" variant="secondary" onPress={() => { onChange(null); setKey(key + 1); }} />
        <Text style={{ fontSize: 14, color: value ? C.success : C.sub }}>{value ? '✓ Signed' : 'Not signed yet'}</Text>
      </View>
    </View>
  );
}
// Show a saved signature.
export function SignatureView({ data, height = 70 }) {
  if (!data) return null;
  return <Image source={{ uri: data }} style={{ width: height * 3, height, backgroundColor: C.white, borderRadius: 6 }} resizeMode="contain" />;
}
