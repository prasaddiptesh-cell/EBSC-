// Sign with a finger on the screen. Gives a small PNG (data URL) – kept with the record and shown on the PDF.
import React, { useRef, useState } from 'react';
import { View, Image, Modal, Pressable } from 'react-native';
import { WebView } from 'react-native-webview';
import { Text } from './scale.js';
import { Btn } from './components.js';
import { C } from './theme.js';

// The drawing page. The signature is sent once, when "Done" is pressed (window.finish), cropped to the ink
// and fitted into 600×200 (smaller if needed to stay under the size limit) without stretching. touch-action:none and preventDefault stop the page from moving.
const HTML = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<style>html,body{margin:0;height:100%;background:#fff;overflow:hidden;touch-action:none;-webkit-user-select:none;user-select:none;overscroll-behavior:none}
canvas{position:fixed;left:0;top:0;width:100vw;height:100vh;display:block;touch-action:none}
.line{position:fixed;left:6%;right:6%;bottom:25%;border-bottom:2px dashed #bbb;pointer-events:none}
.x{position:fixed;left:6%;bottom:26%;font:28px sans-serif;color:#bbb;pointer-events:none}</style></head><body><!-- EB_SIGNATURE -->
<div class="line"></div><div class="x">✕</div><canvas id="c"></canvas><script>
var c=document.getElementById('c'),x=c.getContext('2d'),d=false,used=false,r=window.devicePixelRatio||1,minX=1e9,minY=1e9,maxX=-1,maxY=-1,last=null;
function size(){c.width=window.innerWidth*r;c.height=window.innerHeight*r;x.setTransform(r,0,0,r,0,0);x.lineWidth=3;x.lineCap='round';x.lineJoin='round';x.strokeStyle='#111';}
size();
function p(e){var t=e.touches&&e.touches.length?e.touches[0]:(e.changedTouches&&e.changedTouches.length?e.changedTouches[0]:e);return{x:t.clientX,y:t.clientY};}
function grow(q){minX=Math.min(minX,q.x);minY=Math.min(minY,q.y);maxX=Math.max(maxX,q.x);maxY=Math.max(maxY,q.y);}
function s(e){e.preventDefault();d=true;var q=p(e);last=q;grow(q);x.beginPath();x.arc(q.x,q.y,1.4,0,6.3);x.fill();used=true;}
function m(e){if(!d)return;e.preventDefault();var q=p(e);x.beginPath();x.moveTo(last.x,last.y);x.lineTo(q.x,q.y);x.stroke();last=q;grow(q);used=true;}
function u(e){if(e)e.preventDefault();d=false;}
document.addEventListener('touchstart',s,{passive:false});document.addEventListener('touchmove',m,{passive:false});
document.addEventListener('touchend',u,{passive:false});document.addEventListener('touchcancel',u,{passive:false});
c.addEventListener('mousedown',s);c.addEventListener('mousemove',m);window.addEventListener('mouseup',u);
window.finish=function(){
  if(!used){window.ReactNativeWebView.postMessage(JSON.stringify({type:'sig',data:null}));return;}
  var pad=12,sx=Math.max(0,minX-pad),sy=Math.max(0,minY-pad),sw=Math.min(window.innerWidth,maxX+pad)-sx,sh=Math.min(window.innerHeight,maxY+pad)-sy;
  var out=null,sizes=[600,450,300];
  for(var i=0;i<sizes.length;i++){var W=sizes[i],H=W/3;var o=document.createElement('canvas');o.width=W;o.height=H;var ox=o.getContext('2d');ox.fillStyle='#fff';ox.fillRect(0,0,W,H);
    var k=Math.min(W/sw,H/sh),w=sw*k,h=sh*k;ox.drawImage(c,sx*r,sy*r,sw*r,sh*r,(W-w)/2,(H-h)/2,w,h);out=o.toDataURL('image/png');if(out.length<44000)break;}
  window.ReactNativeWebView.postMessage(JSON.stringify({type:'sig',data:out}));
};
window.clearPad=function(){x.clearRect(0,0,c.width,c.height);used=false;minX=minY=1e9;maxX=maxY=-1;};
</script></body></html>`;

// A box showing the signature; tapping "Sign" opens a full-screen signing sheet (nothing can scroll there).
export function SignaturePad({ value, onChange, label = 'Sign here with your finger', height = 120, testID = 'sig' }) {
  const ref = useRef(null);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(null);
  const [key, setKey] = useState(0);
  const waiting = useRef(false); // true after "Done" until the drawing arrives
  const onMessage = (e) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type !== 'sig') return;
      setDraft(m.data);
      if (waiting.current) { waiting.current = false; if (m.data) { onChange(m.data); setOpen(false); } }
    } catch (err) { /* ignore */ }
  };
  const done = () => {
    waiting.current = true;
    if (ref.current && ref.current.injectJavaScript) ref.current.injectJavaScript('window.finish();true;');
    else if (draft) { waiting.current = false; onChange(draft); setOpen(false); }
  };
  return (
    <View style={{ gap: 6 }}>
      <Text style={{ fontSize: 16, fontWeight: '700', color: C.text }}>{label}</Text>
      <Pressable testID={`${testID}-open`} onPress={() => { setDraft(null); setKey(key + 1); setOpen(true); }}
        style={{ height, borderWidth: 2, borderColor: value ? C.success : C.border, borderStyle: value ? 'solid' : 'dashed', borderRadius: 12, backgroundColor: C.white, alignItems: 'center', justifyContent: 'center' }}>
        {value ? <Image source={{ uri: value }} style={{ width: '90%', height: height - 16 }} resizeMode="contain" />
          : <Text style={{ fontSize: 18, color: C.primary, fontWeight: '700' }}>✍️  Tap here to sign</Text>}
      </Pressable>
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        {value ? <Btn testID={`${testID}-clear`} title="Sign again" size="sm" variant="secondary" onPress={() => { onChange(null); setDraft(null); setKey(key + 1); setOpen(true); }} /> : null}
        <Text style={{ fontSize: 14, color: value ? C.success : C.sub }}>{value ? '✓ Signed' : 'Not signed yet'}</Text>
      </View>
      <Modal visible={open} animationType="slide" onRequestClose={() => setOpen(false)} supportedOrientations={['portrait', 'landscape']}>
        <View style={{ flex: 1, backgroundColor: C.white }}>
          <View style={{ padding: 12, borderBottomWidth: 1, borderColor: C.border }}>
            <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>{label}</Text>
            <Text style={{ fontSize: 14, color: C.sub }}>Sign on the line with your finger. Turning the tablet sideways gives more room.</Text>
          </View>
          <View style={{ flex: 1 }}>
            <WebView key={key} ref={ref} testID={testID} originWhitelist={['*']} source={{ html: HTML }} onMessage={onMessage}
              scrollEnabled={false} bounces={false} overScrollMode="never" nestedScrollEnabled={false} style={{ flex: 1 }} />
          </View>
          <View style={{ flexDirection: 'row', gap: 10, padding: 12, borderTopWidth: 1, borderColor: C.border }}>
            <Btn testID={`${testID}-cancel`} title="Cancel" variant="secondary" style={{ flex: 1 }} onPress={() => setOpen(false)} />
            <Btn testID={`${testID}-redo`} title="Clear" variant="secondary" style={{ flex: 1 }} onPress={() => { setDraft(null); setKey(key + 1); }} />
            <Btn testID={`${testID}-done`} title="Done" variant="success" style={{ flex: 1 }} onPress={done} />
          </View>
        </View>
      </Modal>
    </View>
  );
}
// Show a saved signature.
export function SignatureView({ data, height = 70 }) {
  if (!data) return null;
  return <Image source={{ uri: data }} style={{ width: height * 3, height, backgroundColor: C.white, borderRadius: 6 }} resizeMode="contain" />;
}
