// Start-up pieces used by App.js: the "Checking… ✓" splash, the red screen for a damaged database, and the watcher
// that plays sounds for new warnings and shows urgent ones (a red strip) until someone taps OK.
import React, { useEffect, useRef, useState } from 'react';
import { View, Image, ScrollView, Pressable } from 'react-native';
import { Text } from './scale.js';
import { C } from './theme.js';
import { LOGO, Field, Btn } from './components.js';
import { collectAlerts } from '../services/alerts.js';
import { processAlerts } from '../services/sounds.js';
import { listSnapshots, listOutsideCopies, restoreDamaged } from '../services/snapshots.js';
import { playSound, stopUrgent } from '../platform/sound.js';
import { notifyAlert } from '../platform/notify.js';
import { loginFooter } from '../services/about.js';

const MARK = { ok: '✓', info: '✓', minor: '!', damaged: '✗' };
const TONE = { ok: C.success, info: C.success, minor: C.warn, damaged: C.danger };

export function Splash({ subscribe }) {
  const [state, setState] = useState(null);
  useEffect(() => (subscribe ? subscribe(setState) : undefined), [subscribe]);
  const results = (state && state.results) || [];
  const done = state && (state.done || state.timedOut);
  return (
    <View testID="splash" style={{ flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 }}>
      <Image source={LOGO} style={{ width: 260, height: 115 }} resizeMode="contain" />
      <Text testID="splash-text" style={{ fontSize: 22, fontWeight: '800', color: C.text }}>{done ? 'Checking… ✓' : 'Checking…'}</Text>
      <View style={{ minHeight: 120 }}>
        {results.map((r) => (
          <Text key={r.id} style={{ fontSize: 15, color: TONE[r.status] || C.sub, textAlign: 'center' }}>{MARK[r.status] || '·'} {r.label}</Text>
        ))}
      </View>
      <Text style={{ fontSize: 13, color: C.sub }}>{loginFooter()}</Text>
    </View>
  );
}

// The database is damaged (or could not be opened): offer to put back the latest good copy (owner / admin PIN).
export function DamagedScreen({ problem, onRestored, onContinue }) {
  const [copies, setCopies] = useState(null);
  const [pick, setPick] = useState(null);
  const [pin, setPin] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let live = true;
    Promise.all([listSnapshots().catch(() => []), listOutsideCopies().catch(() => [])]).then(([a, b]) => {
      if (!live) return;
      const all = a.filter((x) => !/^(damaged|before-restore)/.test(x.reason)).concat(b);
      setCopies(all);
      setPick(all[0] || null);
    });
    return () => { live = false; };
  }, []);
  const restore = async () => {
    if (!pick) return;
    setBusy(true); setMsg('');
    try { await restoreDamaged(pick, pin); onRestored(pick); } catch (e) { setMsg(e.message || String(e)); }
    setBusy(false);
  };
  return (
    <ScrollView testID="damaged" style={{ flex: 1, backgroundColor: C.dangerSoft }} contentContainerStyle={{ padding: 24, gap: 14, maxWidth: 760, alignSelf: 'center', width: '100%' }}>
      <Text style={{ fontSize: 28, fontWeight: '900', color: C.danger }}>The data on this tablet is damaged</Text>
      <Text style={{ fontSize: 17, color: C.text }}>{problem || 'The start-up check found damage in the database.'}</Text>
      <Text style={{ fontSize: 17, color: C.text }}>The safest step is to put back the latest good safety copy. The damaged data is kept as a file first, so nothing is thrown away. The owner or an admin must enter their PIN.</Text>
      {copies === null ? <Text style={{ fontSize: 16, color: C.sub }}>Looking for safety copies…</Text> : !copies.length ? (
        <Text testID="damaged-nocopy" style={{ fontSize: 17, color: C.danger, fontWeight: '700' }}>No safety copy was found on this tablet. Call support: Diptesh Avnil Prasad, +679 900 8193. If the tablet was linked, the data can come back from the cloud on a re-linked tablet.</Text>
      ) : (
        <View style={{ gap: 8 }}>
          {copies.slice(0, 8).map((c, i) => (
            <Pressable key={c.uri} testID={`damaged-copy-${i}`} onPress={() => setPick(c)} style={{ padding: 12, borderRadius: 12, borderWidth: 2, borderColor: pick === c ? C.danger : C.border, backgroundColor: C.white }}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{pick === c ? '● ' : '○ '}{c.at.slice(0, 16)} · {c.label}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{c.where === 'outside' ? 'Folder outside the app' : 'On this tablet'}</Text>
            </Pressable>
          ))}
          <Field testID="damaged-pin" label="Owner / admin PIN" value={pin} onChangeText={setPin} secure keyboardType="number-pad" />
          {msg ? <Text style={{ fontSize: 16, color: C.danger, fontWeight: '700' }}>{msg}</Text> : null}
          <Btn testID="damaged-restore" title={busy ? 'Restoring…' : 'Restore this copy'} icon="♻️" variant="danger" disabled={busy || !pin} onPress={restore} />
        </View>
      )}
      {onContinue ? <Btn testID="damaged-continue" title="Open the app anyway (not advised)" size="md" variant="secondary" onPress={onContinue} /> : null}
    </ScrollView>
  );
}

// Every minute (and when the screen changes): new warnings make their sound; new urgent ones are shown with OK.
export function AlertWatcher({ user, tick }) {
  const [urgent, setUrgent] = useState([]);
  const running = useRef(false);
  useEffect(() => {
    if (!user) return undefined;
    const look = () => {
      if (running.current) return;
      running.current = true;
      try {
        const list = collectAlerts(user);
        const r = processAlerts(user, list, { play: (lv, o) => playSound(lv, o), notify: (a) => notifyAlert(a) });
        if (r.urgent.length) setUrgent((u) => u.concat(r.urgent.filter((a) => !u.some((x) => x.id === a.id))));
      } catch (e) { /* warnings are a convenience */ }
      running.current = false;
    };
    const first = setTimeout(look, 1500);
    const t = setInterval(look, 60000);
    return () => { clearTimeout(first); clearInterval(t); };
  }, [user, tick]);
  if (!user || !urgent.length) return null;
  const ok = () => { stopUrgent(); setUrgent([]); };
  // A strip at the top (it does not block the screen, so work can go on); the alarm repeats until OK.
  return (
    <View testID="urgent-popup" style={{ backgroundColor: C.danger, paddingHorizontal: 12, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <Text style={{ fontSize: 22 }}>🚨</Text>
      <View style={{ flex: 1 }}>
        {urgent.slice(0, 3).map((a) => <Text key={a.id} style={{ color: C.white, fontSize: 16, fontWeight: '800' }} numberOfLines={2}>{a.text}</Text>)}
        {urgent.length > 3 ? <Text style={{ color: C.white, fontSize: 14 }}>+ {urgent.length - 3} more on Home</Text> : null}
      </View>
      <Pressable testID="urgent-ok" onPress={ok} style={({ pressed }) => ({ backgroundColor: C.white, borderRadius: 12, paddingHorizontal: 18, paddingVertical: 10, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ color: C.danger, fontSize: 18, fontWeight: '900' }}>OK</Text>
      </Pressable>
    </View>
  );
}
