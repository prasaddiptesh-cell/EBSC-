// Start-up pieces used by App.js: the "Checking… ✓" splash, the red screen for a damaged database, and the watcher
// that plays sounds for new warnings and shows urgent ones (a red strip) until someone taps OK.
import React, { useEffect, useRef, useState } from 'react';
import { View, Image, ScrollView, Pressable } from 'react-native';
import { Text } from './scale.js';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from './theme.js';
import { LOGO, Field, Btn, useUI } from './components.js';
import { askMute } from './alertsUI.js';
import { canMute } from '../services/sounds.js';
import { collectAlertsAsync } from '../services/alerts.js';
import { processAlerts } from '../services/sounds.js';
import { listSnapshots, listOutsideCopies, restoreDamaged } from '../services/snapshots.js';
import { playSound, stopUrgent } from '../platform/sound.js';
import { notifyAlert } from '../platform/notify.js';
import { loginFooter } from '../services/about.js';

const MARK = { ok: '✓', info: '✓', minor: '!', damaged: '✗' };
const TONE = { ok: C.success, info: C.success, minor: C.warn, damaged: C.danger };

// 1.0.0 round 2: the first start after an update builds the app's speed-ups (about a minute with years of records).
export function GettingReady({ step }) {
  return (
    <View testID="getting-ready" style={{ flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 14 }}>
      <Image source={LOGO} style={{ width: 260, height: 115 }} resizeMode="contain" />
      <Text testID="getting-ready-text" style={{ fontSize: 24, fontWeight: '800', color: C.text, textAlign: 'center' }}>Getting ready – one minute</Text>
      <Text style={{ fontSize: 17, color: C.text, textAlign: 'center' }}>The app was updated. It is making itself quicker for your records. This happens once.</Text>
      <Text style={{ fontSize: 15, color: C.sub, textAlign: 'center' }}>{step ? `${step.text}… (${step.step} of ${step.of})` : 'Starting…'}</Text>
      <Text style={{ fontSize: 15, color: C.sub, textAlign: 'center' }}>Please keep the app open.</Text>
    </View>
  );
}
export function Splash({ subscribe }) {
  const [state, setState] = useState(null);
  useEffect(() => (subscribe ? subscribe(setState) : undefined), [subscribe]);
  const results = (state && state.results) || [];
  const done = state && (state.done || state.timedOut);
  return (
    <View testID="splash" style={{ flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 }}>
      <Image source={LOGO} style={{ width: 260, height: 115 }} resizeMode="contain" />
      <Text testID="splash-text" style={{ fontSize: 22, fontWeight: '800', color: C.text }}>{done ? 'Checking… ✓' : 'Checking…'}</Text>
      <View style={{ minHeight: 120 }}>
        {results.map((r) => (
          <Text key={r.id} style={{ fontSize: 15, color: TONE[r.status] || C.sub, textAlign: 'center' }}>{MARK[r.status] || '·'} {r.label}</Text>
        ))}
      </View>
      <Text style={{ fontSize: 13, color: C.sub }}>{loginFooter()}</Text>
    </View>
  );
}

// The database is damaged (or could not be opened): offer to put back the latest good copy (owner / admin PIN).
export function DamagedScreen({ problem, onRestored, onContinue }) {
  const [copies, setCopies] = useState(null);
  const [pick, setPick] = useState(null);
  const [pin, setPin] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let live = true;
    Promise.all([listSnapshots().catch(() => []), listOutsideCopies().catch(() => [])]).then(([a, b]) => {
      if (!live) return;
      const all = a.filter((x) => !/^(damaged|before-restore)/.test(x.reason)).concat(b);
      setCopies(all);
      setPick(all[0] || null);
    });
    return () => { live = false; };
  }, []);
  const restore = async () => {
    if (!pick) return;
    setBusy(true); setMsg('');
    try { await restoreDamaged(pick, pin); onRestored(pick); } catch (e) { setMsg(e.message || String(e)); }
    setBusy(false);
  };
  return (
    <ScrollView testID="damaged" style={{ flex: 1, backgroundColor: C.dangerSoft }} contentContainerStyle={{ padding: 24, gap: 14, maxWidth: 760, alignSelf: 'center', width: '100%' }}>
      <Text style={{ fontSize: 28, fontWeight: '900', color: C.danger }}>The data on this tablet is damaged</Text>
      <Text style={{ fontSize: 17, color: C.text }}>{problem || 'The start-up check found damage in the database.'}</Text>
      <Text style={{ fontSize: 17, color: C.text }}>The safest step is to put back the latest good safety copy. The damaged data is kept as a file first, so nothing is thrown away. The owner or an admin must enter their PIN.</Text>
      {copies === null ? <Text style={{ fontSize: 16, color: C.sub }}>Looking for safety copies…</Text> : !copies.length ? (
        <Text testID="damaged-nocopy" style={{ fontSize: 17, color: C.danger, fontWeight: '700' }}>No safety copy was found on this tablet. Call support: Diptesh Avnil Prasad, +679 900 8193. If the tablet was linked, the data can come back from the cloud on a re-linked tablet.</Text>
      ) : (
        <View style={{ gap: 8 }}>
          {copies.slice(0, 8).map((c, i) => (
            <Pressable key={c.uri} testID={`damaged-copy-${i}`} onPress={() => setPick(c)} style={{ padding: 12, borderRadius: 12, borderWidth: 2, borderColor: pick === c ? C.danger : C.border, backgroundColor: C.white }}>
              <Text style={{ fontSize: 17, fontWeight: '800', color: C.text }}>{pick === c ? '● ' : '○ '}{c.at.slice(0, 16)} · {c.label}</Text>
              <Text style={{ fontSize: 14, color: C.sub }}>{c.where === 'outside' ? 'Folder outside the app' : 'On this tablet'}</Text>
            </Pressable>
          ))}
          <Field testID="damaged-pin" label="Owner / admin PIN" value={pin} onChangeText={setPin} secure keyboardType="number-pad" />
          {msg ? <Text style={{ fontSize: 16, color: C.danger, fontWeight: '700' }}>{msg}</Text> : null}
          <Btn testID="damaged-restore" title={busy ? 'Restoring…' : 'Restore this copy'} icon="♻️" variant="danger" disabled={busy || !pin} onPress={restore} />
        </View>
      )}
      {onContinue ? <Btn testID="damaged-continue" title="Open the app anyway (not advised)" size="md" variant="secondary" onPress={onContinue} /> : null}
    </ScrollView>
  );
}

// Every minute (and when the screen changes): new warnings make their sound; new urgent ones are shown with OK.
export function AlertWatcher({ user, tick }) {
  const ui = useUI();
  const [urgent, setUrgent] = useState([]);
  // v3.9.4 every chime shows what it is for (a warning that sounded used to show only on Home).
  const [chimed, setChimed] = useState([]);
  const chimeTimer = useRef(null);
  const running = useRef(false);
  const edge = useSafeAreaInsets(); // v3.9.4 the strip starts below the phone's status bar (it was cut off)
  // v3.9.5 a new login starts with no strip: the owner's urgent warnings are not shown to the next person on the tablet.
  useEffect(() => { setUrgent([]); setChimed([]); }, [user ? user.uid : null]);
  useEffect(() => {
    if (!user) return undefined;
    const look = async () => {
      if (running.current) return;
      running.current = true;
      try {
        // 1.0.0 worked out one part of the business at a time (the screens keep answering meanwhile)
        const list = await collectAlertsAsync(user);
        const r = processAlerts(user, list, { play: (lv, o) => playSound(lv, o), notify: (a) => notifyAlert(a) });
        if (r.urgent.length) setUrgent((u) => u.concat(r.urgent.filter((a) => !u.some((x) => x.id === a.id))));
        const ch = (r.audible || []).filter((a) => a.level !== 'urgent');
        if (r.played && r.played !== 'urgent' && ch.length) {
          setChimed(ch);
          clearTimeout(chimeTimer.current);
          chimeTimer.current = setTimeout(() => setChimed([]), 45000);
        }
      } catch (e) { /* warnings are a convenience */ }
      running.current = false;
    };
    const first = setTimeout(look, 1500);
    const t = setInterval(look, 60000);
    return () => { clearTimeout(first); clearInterval(t); };
  }, [user, tick]);
  if (user && !urgent.length && chimed.length) {
    const tone = chimed.some((a) => a.level === 'warning') ? C.warn : C.info;
    return (
      <View testID="chime-strip" style={{ backgroundColor: tone, paddingHorizontal: 12, paddingTop: 8 + edge.top, paddingBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Text style={{ fontSize: 22 }}>🔔</Text>
        <View style={{ flex: 1 }}>
          {chimed.slice(0, 2).map((a) => <Text key={a.id} style={{ color: C.white, fontSize: 16, fontWeight: '800' }} numberOfLines={2}>{a.text}</Text>)}
          {chimed.length > 2 ? <Text style={{ color: C.white, fontSize: 14 }}>+ {chimed.length - 2} more on Home</Text> : null}
        </View>
        {canMute(user, chimed[0]) ? (
          <Pressable testID="chime-mute" accessibilityLabel="Mute this warning" onPress={() => askMute(user, ui, chimed[0], (a) => setChimed((l) => l.filter((x) => x.id !== a.id)))} style={({ pressed }) => ({ borderColor: C.white, borderWidth: 2, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, opacity: pressed ? 0.7 : 1 })}>
            <Text style={{ color: C.white, fontSize: 16, fontWeight: '900' }}>Mute</Text>
          </Pressable>
        ) : null}
        <Pressable testID="chime-ok" onPress={() => { clearTimeout(chimeTimer.current); setChimed([]); }} style={({ pressed }) => ({ backgroundColor: C.white, borderRadius: 12, paddingHorizontal: 18, paddingVertical: 10, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ color: tone, fontSize: 18, fontWeight: '900' }}>OK</Text>
        </Pressable>
      </View>
    );
  }
  if (!user || !urgent.length) return null;
  const ok = () => { stopUrgent(); setUrgent([]); };
  // A strip at the top (it does not block the screen, so work can go on); the alarm repeats until OK.
  return (
    <View testID="urgent-popup" style={{ backgroundColor: C.danger, paddingHorizontal: 12, paddingTop: 8 + edge.top, paddingBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
      <Text style={{ fontSize: 22 }}>🚨</Text>
      <View style={{ flex: 1 }}>
        {urgent.slice(0, 3).map((a) => <Text key={a.id} style={{ color: C.white, fontSize: 16, fontWeight: '800' }} numberOfLines={2}>{a.text}</Text>)}
        {urgent.length > 3 ? <Text style={{ color: C.white, fontSize: 14 }}>+ {urgent.length - 3} more on Home</Text> : null}
      </View>
      {canMute(user, urgent[0]) ? (
        <Pressable testID="urgent-mute" accessibilityLabel="Mute this warning" onPress={() => askMute(user, ui, urgent[0], (a) => { const rest = urgent.filter((x) => x.id !== a.id); if (!rest.length) stopUrgent(); setUrgent(rest); })} style={({ pressed }) => ({ borderColor: C.white, borderWidth: 2, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ color: C.white, fontSize: 16, fontWeight: '900' }}>Mute</Text>
        </Pressable>
      ) : null}
      <Pressable testID="urgent-ok" onPress={ok} style={({ pressed }) => ({ backgroundColor: C.white, borderRadius: 12, paddingHorizontal: 18, paddingVertical: 10, opacity: pressed ? 0.7 : 1 })}>
        <Text style={{ color: C.danger, fontSize: 18, fontWeight: '900' }}>OK</Text>
      </Pressable>
    </View>
  );
}
