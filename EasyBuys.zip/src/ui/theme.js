// Easy Buys brand colours.
export const C = {
  bg: '#F4F1EC',
  card: '#FFFFFF',
  border: '#E3DDD3',
  text: '#2B1A1C',
  sub: '#6B6160',
  primary: '#DA2A2F',
  primaryDark: '#2B1A1C',
  primarySoft: '#FBE4E4',
  primaryText: '#B11F24', // red text on the soft red ground (4.5:1 or better)
  brandRed: '#DA2A2F',
  brandBlue: '#2F5FC4',
  success: '#157F3B',
  successSoft: '#DDF4E4',
  successText: '#116632',
  warn: '#B45309',
  warnSoft: '#FEF0C7',
  warnText: '#92400E', // amber text on the soft amber ground
  danger: '#B42318',
  dangerSoft: '#FDE2DF',
  info: '#2F5FC4',
  infoSoft: '#E1EAFB',
  white: '#FFFFFF',
  disabled: '#C9C1B6',
  line: '#EFEAE2', // thin dividers inside cards
  hover: '#F6F2EC',
  inputBorder: '#D6CEC2',
};

export const ROLE_COLOR = { staff: '#475467', worker: '#2F5FC4', supervisor: '#157F3B', manager: '#0E7490', payroll: '#6941C6', admin: '#C8242A', owner: '#2B1A1C' };

export const TYPE_META = {
  OPENING: { label: 'Opening stock', color: '#2F5FC4', icon: '📋' },
  RECEIVE: { label: 'Stock received', color: '#157F3B', icon: '📦' },
  USAGE: { label: 'Ingredient usage', color: '#8A4B14', icon: '🥣' },
  WASTAGE: { label: 'Wastage', color: '#B42318', icon: '🗑️' },
  ADJUST: { label: 'Adjustment', color: '#6941C6', icon: '⚖️' },
  PRODUCTION: { label: 'Production', color: '#B45309', icon: '🍞' },
  BALANCE: { label: 'Balance correction', color: '#475467', icon: '✅' },
};
