// Clock-face time picker: tap the hour on the dial, then the minutes; am / pm; quick buttons.
// value / onChange use 24-hour "HH:MM".
import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { Text, useScale } from './scale.js';
import { C } from './theme.js';

const pad = (n) => String(n).padStart(2, '0');
export function toParts(v) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(v || '');
  const h = m ? Number(m[1]) : 8;
  return { h12: h % 12 === 0 ? 12 : h % 12, min: m ? Number(m[2]) : 0, pm: h >= 12 };
}
export function fromParts({ h12, min, pm }) {
  const h = (h12 % 12) + (pm ? 12 : 0);
  return `${pad(h)}:${pad(min)}`;
}
export function nice(v) {
  if (!v) return '—';
  const p = toParts(v);
  return `${p.h12}:${pad(p.min)} ${p.pm ? 'pm' : 'am'}`;
}
export function addMinutesHHMM(v, d) {
  const [h, m] = (v || '08:00').split(':').map(Number);
  const t = (((h * 60 + m + d) % 1440) + 1440) % 1440;
  return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`;
}

export function ClockFacePicker({ value, onChange, quick = [], testID }) {
  const s = useScale();
  const [mode, setMode] = useState('hour');
  const p = toParts(value);
  const size = Math.round(280 * Math.min(1.2, s));
  const r = size / 2;
  const labelR = r - 34;
  const items = mode === 'hour' ? [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] : [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
  const selected = mode === 'hour' ? p.h12 : Math.round(p.min / 5) * 5 % 60;
  const angleOf = (k) => (mode === 'hour' ? (k % 12) * 30 : k * 6);
  const pick = (k) => {
    if (mode === 'hour') { onChange(fromParts({ ...p, h12: k })); setMode('minute'); } else onChange(fromParts({ ...p, min: k }));
  };
  const handA = angleOf(selected);
  const seg = (on) => ({ paddingHorizontal: 10, borderRadius: 12, backgroundColor: on ? C.infoSoft : 'transparent' });
  return (
    <View testID={testID} style={{ alignItems: 'center', gap: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Pressable testID={testID ? `${testID}-hour` : undefined} onPress={() => setMode('hour')} style={seg(mode === 'hour')}><Text style={{ fontSize: 52, fontWeight: '900', color: mode === 'hour' ? C.info : C.text }}>{p.h12}</Text></Pressable>
        <Text style={{ fontSize: 52, fontWeight: '900', color: C.text }}>:</Text>
        <Pressable testID={testID ? `${testID}-minute` : undefined} onPress={() => setMode('minute')} style={seg(mode === 'minute')}><Text style={{ fontSize: 52, fontWeight: '900', color: mode === 'minute' ? C.info : C.text }}>{pad(p.min)}</Text></Pressable>
        <View style={{ marginLeft: 10, gap: 6 }}>
          {[false, true].map((pm) => (
            <Pressable key={String(pm)} testID={testID ? `${testID}-${pm ? 'pm' : 'am'}` : undefined} onPress={() => onChange(fromParts({ ...p, pm }))}
              style={{ width: 60, height: 36, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: p.pm === pm ? C.primaryDark : C.white, borderWidth: 2, borderColor: p.pm === pm ? C.primaryDark : C.border }}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: p.pm === pm ? C.white : C.sub }}>{pm ? 'pm' : 'am'}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ width: size, height: size, borderRadius: r, backgroundColor: '#F2EEEA' }}>
        <View pointerEvents="none" style={{ position: 'absolute', left: r - 2, top: r - (labelR - 6), width: 4, height: labelR - 6, backgroundColor: C.info, borderRadius: 2,
          transformOrigin: 'bottom', transform: [{ rotate: `${handA}deg` }] }} />
        <View pointerEvents="none" style={{ position: 'absolute', left: r - 6, top: r - 6, width: 12, height: 12, borderRadius: 6, backgroundColor: C.info }} />
        {items.map((k) => {
          const a = (angleOf(k) * Math.PI) / 180;
          const x = r + labelR * Math.sin(a) - 24;
          const y = r - labelR * Math.cos(a) - 24;
          const on = k === selected;
          return (
            <Pressable key={k} testID={testID ? `${testID}-${mode}-${k}` : undefined} onPress={() => pick(k)}
              style={{ position: 'absolute', left: x, top: y, width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.info : 'transparent' }}>
              <Text style={{ fontSize: 19, fontWeight: on ? '900' : '700', color: on ? C.white : C.text }}>{mode === 'hour' ? k : pad(k)}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={{ fontSize: 14, color: C.sub }}>{mode === 'hour' ? 'Tap the hour' : 'Tap the minutes (every 5)'}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' }}>
        {[['− 15 min', -15], ['− 1', -1], ['+ 1', 1], ['+ 15 min', 15]].map(([l, d]) => (
          <Pressable key={l} onPress={() => onChange(addMinutesHHMM(value, d))} style={{ height: 42, paddingHorizontal: 12, borderRadius: 10, borderWidth: 2, borderColor: C.border, backgroundColor: C.white, justifyContent: 'center' }}>
            <Text style={{ fontSize: 15, fontWeight: '700', color: C.text }}>{l}</Text>
          </Pressable>
        ))}
        {quick.map((q) => (
          <Pressable key={q.label} onPress={() => onChange(q.value)} style={{ height: 42, paddingHorizontal: 12, borderRadius: 10, borderWidth: 2, borderColor: C.info, backgroundColor: C.infoSoft, justifyContent: 'center' }}>
            <Text style={{ fontSize: 15, fontWeight: '700', color: C.info }}>{q.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
