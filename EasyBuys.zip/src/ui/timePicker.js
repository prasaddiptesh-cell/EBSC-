// Times: TimeField (type it, "Now", usual times, or the clock) and the clock-face picker it opens.
// value / onChange use 24-hour "HH:MM". On screen times follow the business setting (24-hour or 12-hour).
import React, { useState } from 'react';
import { View, Pressable, Modal, ScrollView } from 'react-native';
import { Text, TextInput, useScale } from './scale.js';
import { C } from './theme.js';
import { parseTime, fmtTime, nowHHMM, isHHMM, timeFormat } from '../services/dates.js';

export { timeFormat };

const pad = (n) => String(n).padStart(2, '0');
export function toParts(v) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(v || '');
  const h = m ? Number(m[1]) : 8;
  return { h12: h % 12 === 0 ? 12 : h % 12, min: m ? Number(m[2]) : 0, pm: h >= 12 };
}
export function fromParts({ h12, min, pm }) {
  const h = (h12 % 12) + (pm ? 12 : 0);
  return `${pad(h)}:${pad(min)}`;
}
export function nice(v) {
  if (!v) return '—';
  if (!isHHMM(v)) { const p = toParts(v); return fmtTime(fromParts(p), timeFormat()); }
  return fmtTime(v, timeFormat());
}
export function addMinutesHHMM(v, d) {
  const [h, m] = (v || '08:00').split(':').map(Number);
  const t = (((h * 60 + m + d) % 1440) + 1440) % 1440;
  return `${pad(Math.floor(t / 60))}:${pad(t % 60)}`;
}

export function ClockFacePicker({ value, onChange, quick = [], testID }) {
  const s = useScale();
  const [mode, setMode] = useState('hour');
  const p = toParts(value);
  const size = Math.round(280 * Math.min(1.2, s));
  const r = size / 2;
  const labelR = r - 34;
  const items = mode === 'hour' ? [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] : [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
  const selected = mode === 'hour' ? p.h12 : Math.round(p.min / 5) * 5 % 60;
  const angleOf = (k) => (mode === 'hour' ? (k % 12) * 30 : k * 6);
  const pick = (k) => {
    if (mode === 'hour') { onChange(fromParts({ ...p, h12: k })); setMode('minute'); } else onChange(fromParts({ ...p, min: k }));
  };
  const handA = angleOf(selected);
  const h24 = timeFormat() === '24h';
  const hourShown = h24 ? pad((p.h12 % 12) + (p.pm ? 12 : 0)) : p.h12;
  const seg = (on) => ({ paddingHorizontal: 10, borderRadius: 12, backgroundColor: on ? C.infoSoft : 'transparent' });
  return (
    <View testID={testID} style={{ alignItems: 'center', gap: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Pressable testID={testID ? `${testID}-hour` : undefined} onPress={() => setMode('hour')} style={seg(mode === 'hour')}><Text style={{ fontSize: 52, fontWeight: '900', color: mode === 'hour' ? C.info : C.text }}>{hourShown}</Text></Pressable>
        <Text style={{ fontSize: 52, fontWeight: '900', color: C.text }}>:</Text>
        <Pressable testID={testID ? `${testID}-minute` : undefined} onPress={() => setMode('minute')} style={seg(mode === 'minute')}><Text style={{ fontSize: 52, fontWeight: '900', color: mode === 'minute' ? C.info : C.text }}>{pad(p.min)}</Text></Pressable>
        <View style={{ marginLeft: 10, gap: 6 }}>
          {[false, true].map((pm) => (
            <Pressable key={String(pm)} testID={testID ? `${testID}-${pm ? 'pm' : 'am'}` : undefined} onPress={() => onChange(fromParts({ ...p, pm }))}
              style={{ width: 60, height: 36, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: p.pm === pm ? C.primaryDark : C.white, borderWidth: 2, borderColor: p.pm === pm ? C.primaryDark : C.border }}>
              <Text style={{ fontSize: 16, fontWeight: '800', color: p.pm === pm ? C.white : C.sub }}>{pm ? 'pm' : 'am'}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ position: 'relative', width: size, height: size, borderRadius: r, backgroundColor: '#F2EEEA' }}>
        <View pointerEvents="none" style={{ position: 'absolute', left: r - 2, top: r - (labelR - 6), width: 4, height: labelR - 6, backgroundColor: C.info, borderRadius: 2,
          transformOrigin: 'bottom', transform: [{ rotate: `${handA}deg` }] }} />
        <View pointerEvents="none" style={{ position: 'absolute', left: r - 6, top: r - 6, width: 12, height: 12, borderRadius: 6, backgroundColor: C.info }} />
        {items.map((k) => {
          const a = (angleOf(k) * Math.PI) / 180;
          const x = r + labelR * Math.sin(a) - 24;
          const y = r - labelR * Math.cos(a) - 24;
          const on = k === selected;
          return (
            <Pressable key={k} testID={testID ? `${testID}-${mode}-${k}` : undefined} onPress={() => pick(k)}
              style={{ position: 'absolute', left: x, top: y, width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? C.info : 'transparent' }}>
              <Text style={{ fontSize: 19, fontWeight: on ? '900' : '700', color: on ? C.white : C.text }}>{mode === 'hour' ? k : pad(k)}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={{ fontSize: 14, color: C.sub }}>{mode === 'hour' ? 'Tap the hour' : 'Tap the minutes (every 5)'}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' }}>
        {[['− 15 min', -15], ['− 5', -5], ['− 1', -1], ['+ 1', 1], ['+ 5', 5], ['+ 15 min', 15]].map(([l, d]) => (
          <Pressable key={l} testID={testID ? `${testID}-adj${d}` : undefined} onPress={() => onChange(addMinutesHHMM(value, d))} style={{ height: 42, paddingHorizontal: 12, borderRadius: 10, borderWidth: 2, borderColor: C.border, backgroundColor: C.white, justifyContent: 'center' }}>
            <Text style={{ fontSize: 15, fontWeight: '700', color: C.text }}>{l}</Text>
          </Pressable>
        ))}
        {quick.map((q) => (
          <Pressable key={q.label} onPress={() => onChange(q.value)} style={{ height: 42, paddingHorizontal: 12, borderRadius: 10, borderWidth: 2, borderColor: C.info, backgroundColor: C.infoSoft, justifyContent: 'center' }}>
            <Text style={{ fontSize: 15, fontWeight: '700', color: C.info }}>{q.label}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const usualList = (usual) => (usual || []).map((u) => (typeof u === 'string' ? { value: u, label: null } : u)).filter((u) => isHHMM(u.value));

function SmallBtn({ title, onPress, on, testID, tone }) {
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed }) => ({ minHeight: 44, paddingHorizontal: 14, borderRadius: 22, justifyContent: 'center', borderWidth: 2,
      borderColor: on ? C.info : tone === 'primary' ? C.primary : C.border, backgroundColor: on ? C.info : tone === 'primary' ? C.primary : C.white, opacity: pressed ? 0.7 : 1 })}>
      <Text style={{ fontSize: 16, fontWeight: '800', color: on || tone === 'primary' ? C.white : C.text }}>{title}</Text>
    </Pressable>
  );
}

// One time entry for the whole app: type it (8:30, 830, 8:30 pm), tap "Now" or a usual time, or open the clock.
// value: 'HH:MM' (24-hour) or ''. usual: ['07:00', '15:00'] or [{ value, label }]. Shown as 20:30 or 8:30 pm (admin setting).
export function TimeField({ label, value, onChange, testID, usual, showNow = true, optional, hint }) {
  const [focus, setFocus] = useState(false);
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(value || nowHHMM());
  const fmt = timeFormat();
  const shown = focus ? text : isHHMM(value) ? fmtTime(value, fmt) : value || '';
  const typed = focus ? parseTime(text) : null;
  const err = focus ? (typed.ok || typed.empty ? '' : typed.error) : value && !isHHMM(value) ? parseTime(value).error || 'Type the time like 8:30.' : '';
  const now = nowHHMM();
  const pick = (t) => { setText(fmtTime(t, fmt)); onChange(t); };
  return (
    <View style={{ gap: 6 }}>
      {label ? <Text style={{ fontSize: 17, fontWeight: '700', color: C.sub }}>{label}{optional ? ' (optional)' : ''}</Text> : null}
      <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
        <TextInput testID={testID} value={shown} placeholder={fmt === '12h' ? 'e.g. 8:30 am' : 'e.g. 08:30'} placeholderTextColor="#A39886" keyboardType="numbers-and-punctuation"
          onFocus={() => { setFocus(true); setText(shown); }}
          onBlur={() => setFocus(false)}
          onChangeText={(t) => { setText(t); const r = parseTime(t); onChange(r.ok ? r.hhmm : t); }}
          style={{ flex: 1, backgroundColor: C.white, borderWidth: 2, borderColor: err ? C.danger : C.border, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 20, color: C.text, minHeight: 62 }} />
        <Pressable testID={testID ? `${testID}-clock` : undefined} onPress={() => { setDraft(isHHMM(value) ? value : now); setOpen(true); }}
          style={({ pressed }) => ({ width: 62, height: 62, borderRadius: 12, borderWidth: 2, borderColor: C.info, backgroundColor: C.infoSoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.7 : 1 })}>
          <Text style={{ fontSize: 28 }}>🕐</Text>
        </Pressable>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {showNow ? <SmallBtn testID={testID ? `${testID}-now` : undefined} title={`Now (${fmtTime(now, fmt)})`} on={value === now} onPress={() => pick(now)} /> : null}
        {usualList(usual).map((u) => <SmallBtn key={u.value} testID={testID ? `${testID}-usual-${u.value}` : undefined} title={u.label || fmtTime(u.value, fmt)} on={value === u.value} onPress={() => pick(u.value)} />)}
      </View>
      {err ? <Text testID={testID ? `${testID}-error` : undefined} style={{ fontSize: 15, color: C.danger, fontWeight: '700' }}>{err}</Text> : hint ? <Text style={{ fontSize: 14, color: C.sub }}>{hint}</Text> : null}
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center', padding: 12 }}>
          <View style={{ backgroundColor: C.card, borderRadius: 18, padding: 16, width: '100%', maxWidth: 480, maxHeight: '95%' }}>
            <ScrollView contentContainerStyle={{ gap: 12 }}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>{label || 'Choose the time'}</Text>
              <ClockFacePicker testID={testID ? `${testID}-face` : undefined} value={draft} onChange={setDraft}
                quick={(showNow ? [{ label: 'Now', value: now }] : []).concat(usualList(usual).map((u) => ({ label: u.label || fmtTime(u.value, fmt), value: u.value })))} />
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ flex: 1 }}><SmallBtn title="Cancel" onPress={() => setOpen(false)} /></View>
                <View style={{ flex: 1 }}><SmallBtn testID={testID ? `${testID}-clock-ok` : undefined} tone="primary" title={`Use ${fmtTime(draft, fmt)}`} onPress={() => { setOpen(false); pick(draft); }} /></View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}
