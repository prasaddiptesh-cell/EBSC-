// The button a tour or tutorial step points at. Buttons, tiles and menu items with that testID get a bright outline.
import { useEffect, useState } from 'react';

let target = null;
const listeners = new Set();
export function setTourTarget(id) { target = id || null; listeners.forEach((fn) => { try { fn(target); } catch (e) { /* ignore */ } }); }
export function tourTarget() { return target; }
export function useIsTourTarget(testID) {
  const [on, setOn] = useState(!!testID && target === testID);
  useEffect(() => {
    if (!testID) return undefined;
    const fn = (t) => setOn(t === testID);
    listeners.add(fn);
    fn(target);
    return () => { listeners.delete(fn); };
  }, [testID]);
  return on;
}
export const TOUR_OUTLINE = { borderColor: '#FF6A00', borderWidth: 4 };
