// Release 08 (the new look): pieces of the approved computer design – tables with status pills, underlined tabs,
// the month switcher, white panels and the dark summary card. Used only on the website on a computer (useWide).
import React from 'react';
import { View, Pressable, ScrollView } from 'react-native';
import { Text } from './scale.js';
import Icon from './Icon.js';
import { W } from './wide.js';

export const PILL = {
  ok: { c: W.blue, b: W.blueSoft }, todo: { c: W.amberText, b: W.amberSoft }, warn: { c: W.amberText, b: W.amberSoft },
  good: { c: W.green, b: W.greenSoft }, bad: { c: W.danger, b: W.dangerSoft }, grey: { c: W.mid, b: W.line }, red: { c: W.redDark, b: W.redSoft },
};
export function Pill({ text, tone = 'grey', tick }) {
  const t = PILL[tone] || PILL.grey;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', backgroundColor: t.b, borderRadius: 999, paddingVertical: 4, paddingHorizontal: 10 }}>
      {tick ? <Text style={{ color: t.c, fontSize: 12, fontWeight: '800' }}>✓</Text> : null}
      <Text style={{ color: t.c, fontSize: 13, fontWeight: '600' }} numberOfLines={1}>{text}</Text>
    </View>
  );
}

export function Panel({ children, style, pad = true }) {
  return <View style={[{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: W.border, borderRadius: 12, overflow: 'hidden' }, pad ? { padding: 20, gap: 14 } : null, style]}>{children}</View>;
}

export function PanelNote({ children }) {
  return <Text style={{ paddingVertical: 14, paddingHorizontal: 24, borderTopWidth: 1, borderTopColor: W.line, fontSize: 13, color: W.sub }}>{children}</Text>;
}

// Tabs underlined in red, inside the top of a panel.
export function WebTabs({ tabs, value, onChange, testIDPrefix }) {
  return (
    <View accessibilityRole="tablist" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 28, paddingHorizontal: 24, borderBottomWidth: 1, borderBottomColor: W.border }}>
      {tabs.map((t) => {
        const on = t.value === value;
        return (
          <Pressable key={t.value} testID={testIDPrefix ? `${testIDPrefix}-${t.value}` : undefined} accessibilityRole="tab" accessibilityState={{ selected: on }} onPress={() => onChange(t.value)}
            style={{ height: 52, justifyContent: 'center', borderBottomWidth: 2, borderBottomColor: on ? W.red : 'transparent', marginBottom: -1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: on ? W.redDark : W.sub }}>{t.label}</Text>
              {t.count ? <View style={{ backgroundColor: W.amber, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 1 }}><Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '700' }}>{t.count}</Text></View> : null}
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

// columns: [{ key, title, align, flex, width, bold, muted }]; rows: [{ key, cells: { key: text or element }, onPress, bg, testID }]
export function WebTable({ columns, rows, empty, testID, minWidth = 640 }) {
  const cellStyle = (c, i) => ({ flex: c.width ? undefined : (c.flex || 1), width: c.width, paddingVertical: 12, paddingLeft: i === 0 ? 24 : 12, paddingRight: i === columns.length - 1 ? 24 : 12, justifyContent: 'center', alignItems: c.align === 'right' ? 'flex-end' : 'flex-start' });
  return (
    <ScrollView horizontal testID={testID} contentContainerStyle={{ minWidth: '100%' }}>
      <View style={{ minWidth, width: '100%' }}>
        <View style={{ flexDirection: 'row' }}>
          {columns.map((c, i) => (
            <View key={c.key} style={[cellStyle(c, i), { paddingVertical: 14 }]}>
              <Text style={{ color: W.sub, fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 }} numberOfLines={1}>{c.title}</Text>
            </View>
          ))}
        </View>
        {!rows.length ? <Text style={{ paddingVertical: 18, paddingHorizontal: 24, borderTopWidth: 1, borderTopColor: W.line, color: W.sub, fontSize: 14 }}>{empty || 'Nothing here yet.'}</Text> : rows.map((r) => (
          <Pressable key={r.key} testID={r.testID} onPress={r.onPress} disabled={!r.onPress}
            style={({ hovered, pressed }) => ({ flexDirection: 'row', borderTopWidth: 1, borderTopColor: W.line, backgroundColor: hovered && r.onPress ? W.rowHover : r.bg || 'transparent', opacity: pressed ? 0.7 : 1 })}>
            {columns.map((c, i) => {
              const v = r.cells[c.key];
              return (
                <View key={c.key} style={cellStyle(c, i)}>
                  {v === null || v === undefined || typeof v === 'string' || typeof v === 'number'
                    ? <Text style={{ fontSize: 14, color: c.muted ? W.mid : W.dark, fontWeight: c.bold ? '600' : '400', textAlign: c.align || 'left', fontVariant: ['tabular-nums'] }} numberOfLines={2}>{v === null || v === undefined || v === '' ? '–' : String(v)}</Text>
                    : v}
                </View>
              );
            })}
          </Pressable>
        ))}
      </View>
    </ScrollView>
  );
}

export function SmallBtn({ title, onPress, red, testID }) {
  return (
    <Pressable testID={testID} onPress={onPress} accessibilityRole="button"
      style={({ hovered, pressed }) => ({ height: 36, paddingHorizontal: 14, borderRadius: 8, justifyContent: 'center', borderWidth: red ? 0 : 1, borderColor: W.border, backgroundColor: red ? (hovered ? '#C4252A' : W.red) : hovered ? W.bg : '#FFFFFF', opacity: pressed ? 0.7 : 1 })}>
      <Text style={{ color: red ? '#FFFFFF' : '#3D2F30', fontSize: 13, fontWeight: '600' }}>{title}</Text>
    </Pressable>
  );
}

export function MonthSwitch({ label, onPrev, onNext, nextDisabled, testIDPrefix = 'month' }) {
  const arrow = (t, on, dis, id) => (
    <Pressable testID={`${testIDPrefix}-${id}`} accessibilityLabel={id === 'prev' ? 'Previous month' : 'Next month'} disabled={dis} onPress={on}
      style={({ hovered }) => ({ width: 36, height: 36, borderRadius: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: hovered && !dis ? W.bg : 'transparent', opacity: dis ? 0.35 : 1 })}>
      <Text style={{ fontSize: 18, color: '#3D2F30' }}>{t}</Text>
    </Pressable>
  );
  return (
    <View accessibilityLabel="Month" style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: W.border, borderRadius: 8, padding: 4 }}>
      {arrow('‹', onPrev, false, 'prev')}
      <Text style={{ fontSize: 14, fontWeight: '600', paddingHorizontal: 10, color: W.dark }}>{label}</Text>
      {arrow('›', onNext, nextDisabled, 'next')}
    </View>
  );
}

export function OutlineBtn({ title, icon, onPress, testID }) {
  return (
    <Pressable testID={testID} onPress={onPress} accessibilityRole="button"
      style={({ hovered, pressed }) => ({ height: 44, paddingHorizontal: 16, borderRadius: 8, borderWidth: 1, borderColor: W.btnBorder, backgroundColor: hovered ? W.bg : '#FFFFFF', flexDirection: 'row', alignItems: 'center', gap: 8, opacity: pressed ? 0.7 : 1 })}>
      {icon ? <Icon name={icon} size={16} color={W.dark} strokeWidth={2} /> : null}
      <Text style={{ fontSize: 14, fontWeight: '600', color: W.dark }}>{title}</Text>
    </Pressable>
  );
}

// "Needs attention" list for the side of a page.
export function Attention({ items, title = 'Needs attention' }) {
  return (
    <Panel>
      <Text style={{ fontSize: 16, fontWeight: '700', color: W.dark }}>{title}</Text>
      {!items.length ? <Text style={{ fontSize: 14, color: W.sub }}>Nothing waiting – all checked.</Text> : items.map((a, i) => (
        <Pressable key={i} onPress={a.onPress} disabled={!a.onPress} style={({ hovered }) => ({ flexDirection: 'row', gap: 12, alignItems: 'flex-start', borderRadius: 8, backgroundColor: hovered && a.onPress ? W.rowHover : 'transparent' })}>
          <View style={{ width: 32, height: 32, borderRadius: 8, backgroundColor: W.amberSoft, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: W.amber, fontWeight: '800', fontSize: 15 }}>!</Text></View>
          <View style={{ flex: 1, gap: 2 }}>
            <Text style={{ fontSize: 14, fontWeight: '600', color: W.dark }}>{a.title}</Text>
            {a.sub ? <Text style={{ fontSize: 13, color: W.sub }}>{a.sub}</Text> : null}
          </View>
        </Pressable>
      ))}
    </Panel>
  );
}

export function DarkCard({ label, value, note, button, onPress, testID }) {
  return (
    <View style={{ backgroundColor: W.dark, borderRadius: 12, padding: 20, gap: 10 }}>
      <Text style={{ fontSize: 13, color: '#D9CFC4' }}>{label}</Text>
      <Text style={{ fontSize: 28, fontWeight: '700', color: '#FFFFFF', fontVariant: ['tabular-nums'] }}>{value}</Text>
      {note ? <Text style={{ fontSize: 13, color: '#D9CFC4' }}>{note}</Text> : null}
      {button ? (
        <Pressable testID={testID} onPress={onPress} style={({ hovered }) => ({ marginTop: 6, height: 44, borderRadius: 8, backgroundColor: hovered ? '#C4252A' : W.red, alignItems: 'center', justifyContent: 'center' })}>
          <Text style={{ color: '#FFFFFF', fontSize: 14, fontWeight: '600' }}>{button}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}
