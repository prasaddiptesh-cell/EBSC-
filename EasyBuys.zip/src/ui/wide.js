// Release 08 (the new look): true on the website on a computer screen – buttons, cards, tabs, lists and number cards
// then take the approved design's style (Inter, 1px borders, 8–12px corners, compact heights).
import { Platform, useWindowDimensions } from 'react-native';
export const WIDE_MIN = 1100;
export function useWide() {
  const { width } = useWindowDimensions();
  return Platform.OS === 'web' && width >= WIDE_MIN;
}
export const W = {
  red: '#DA2A2F', redDark: '#A81E23', redSoft: '#FBE4E4', blue: '#2F5FC4', blueSoft: '#E1EAFB',
  dark: '#2B1A1C', sub: '#6B6160', mid: '#5A504F', bg: '#F4F1EC', border: '#E3DDD3', btnBorder: '#D9CFC4', line: '#EFEAE2',
  amber: '#B45309', amberText: '#8A3B06', amberSoft: '#FEF0C7', green: '#157F3B', greenSoft: '#DDF4E4', danger: '#B42318', dangerSoft: '#FDE2DF',
  rowHover: '#FAF8F5', field: '#EFEAE2',
};
