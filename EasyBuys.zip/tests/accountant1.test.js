// 1.0 accountant access: a view-only role (its own staff record), sees the money side, cannot change any business record
// (refused at the database), app housekeeping and sync still work, queries to the owner show as warnings until answered.
import { openNodeDb } from './nodeDb.js';
import { initDatabase, allowNewRoles } from '../src/db/init.js';
import { db, setDb, setWriteGuard, withSystem } from '../src/db/connection.js';
import { clock, setSetting, AppError } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can, isViewOnly, VIEW_ONLY_TABLES } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import * as Q from '../src/services/queries.js';
import { alerts } from '../src/modules/admin/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const acc = saveUser({ name: 'Ravi (accountant)', pin: '5151', role: 'accountant' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const guard = (t) => { if (!VIEW_ONLY_TABLES.includes(t)) throw new AppError('View only'); };

test('the accountant role can be saved (old databases are upgraded once, every row kept)', () => {
  assert.strictEqual(acc.role, 'accountant');
  assert.strictEqual(allowNewRoles(), false, 'already upgraded');
  assert.ok(isViewOnly(acc));
  assert.ok(can(acc, 'accounts_view') && can(acc, 'payroll_view') && !can(acc, 'settings') && !can(acc, 'till_count') && !can(acc, 'staff_manage'));
});
test('view only: business records refused, housekeeping allowed, sync allowed', () => {
  setWriteGuard(guard);
  try {
    throws(() => AP.saveInvoice(acc, { supplierUid: sup.uid, invoiceNo: 'X1', invoiceDate: '2026-10-09', total: 10, shopCode: 'S1' }), /View only/);
    setSetting('last_login', 'x');
    const uid = Q.askQuery(acc, { text: 'Is invoice 77 VAT inclusive?', ref: 'INV-77' });
    assert.ok(uid);
    withSystem(() => db().run("UPDATE ap_suppliers SET notes = 'synced' WHERE uid = ?", [sup.uid]));
    throws(() => db().run("UPDATE ap_suppliers SET notes = 'by hand' WHERE uid = ?", [sup.uid]), /View only/);
  } finally { setWriteGuard(null); }
});
test('queries: warning for the owner until answered; only the owner / admin answers', () => {
  assert.ok(alerts(owner).some((a) => /question.*from the accountant/.test(a.text)));
  const q = Q.listQueries({ status: 'open' })[0];
  throws(() => Q.answerQuery(acc, q.uid, 'Yes'), /Only the owner/);
  Q.answerQuery(owner, q.uid, 'Yes, VAT inclusive');
  assert.ok(!alerts(owner).some((a) => /from the accountant/.test(a.text)));
  assert.strictEqual(Q.listQueries()[0].answer, 'Yes, VAT inclusive');
});
test('an old database (roles without accountant) is upgraded, rows kept', () => {
  const A = openNodeDb();
  A.exec("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pin TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('staff','worker','supervisor','manager','payroll','admin','owner')), uid TEXT);");
  A.run("INSERT INTO users (name, pin, role, uid) VALUES ('A', '1', 'owner', 'U1'), ('B', '2', 'staff', 'U2')");
  setDb(A);
  assert.strictEqual(allowNewRoles(), true);
  assert.ok(db().get("SELECT sql FROM sqlite_master WHERE name = 'users'").sql.includes("'accountant'"));
  assert.deepStrictEqual(db().all('SELECT name, role, uid FROM users ORDER BY id').map((r) => r.uid), ['U1', 'U2']);
  db().run("INSERT INTO users (name, pin, role, uid) VALUES ('C', '3', 'accountant', 'U3')");
  assert.strictEqual(allowNewRoles(), false, 'only once');
});
done();
