// 3.9: the accountant login with the REAL guard the app uses (viewOnlyGuard): every kind of change is refused –
// records, money, stock, people, settings and rules – while looking, asking the owner, tutorials, own Home links
// and the app's own housekeeping still work. (3.8 let settings and rules through.)
import { openNodeDb } from './nodeDb.js';
import { initDatabase, allowNewRoles } from '../src/db/init.js';
import { db, setWriteGuard, withSystem } from '../src/db/connection.js';
import { clock, setSetting, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { viewOnlyGuard } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as P from '../src/modules/payroll/service.js';
import * as TX from '../src/modules/payroll/taxCalendar.js';
import * as RT from '../src/modules/payroll/returns.js';
import * as V from '../src/modules/verify/service.js';
import * as Q from '../src/services/queries.js';
import { setModuleOn } from '../src/modules/admin/service.js';
import { collectAlerts, setAlertSources } from '../src/services/alerts.js';
import { alerts as apAlerts } from '../src/modules/payables/alerts.js';
import { alerts as payAlerts } from '../src/modules/payroll/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
try { allowNewRoles(); } catch (e) { /* done */ }
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const acc = saveUser({ name: 'Ravi (accountant)', pin: '5151', role: 'accountant' }, owner);
const bank = AP.saveAccount(owner, { name: 'BSP', openingBalance: 1000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 10, lastNo: 20 });
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P1', invoiceDate: '2026-10-05', total: 112.5, shopCode: 'S1' });
AP.checkInvoice(owner, inv.uid);
const inv2 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P2', invoiceDate: '2026-10-06', total: 50, shopCode: 'S1' });
const item = I.saveItem(owner, { code: 'R1', name: 'Rice', cost: 2, price: 3 });
A.ensureAccounts();
const count = () => db().all("SELECT name FROM sqlite_master WHERE type = 'table'").reduce((s, t) => s + db().get(`SELECT COUNT(*) AS n FROM "${t.name}"`).n, 0);

const REFUSED = {
  'enter an invoice': () => AP.saveInvoice(acc, { supplierUid: sup.uid, invoiceNo: 'X1', invoiceDate: '2026-10-09', total: 10, shopCode: 'S1' }),
  'check an invoice': () => AP.checkInvoice(acc, inv2.uid),
  'pay a supplier': () => AP.makePayment(acc, { supplierUid: sup.uid, method: 'cash', shopCode: 'S1', receivedBy: 'x', payDate: '2026-10-12', allocations: [{ invoiceUid: inv.uid, amount: 10 }] }),
  'split payment': () => AP.makeSplitPayment(acc, { supplierUid: sup.uid, payDate: '2026-10-12', allocations: [{ invoiceUid: inv.uid, amount: 112.5 }], parts: [{ method: 'cash', amount: 12.5, shopCode: 'S1' }, { method: 'cash', amount: 100, shopCode: 'S2' }] }),
  'add a supplier': () => AP.saveSupplier(acc, { name: 'New one' }),
  'change a product': () => I.saveItem(acc, { uid: item.uid, code: 'R1', name: 'Rice!', cost: 1, price: 3 }),
  'adjust stock': () => I.adjustStock(acc, { itemUid: item.uid, shopCode: 'S1', qty: 5, reason: 'x', date: '2026-10-12' }),
  'type a journal': () => A.saveJournal(acc, { date: '2026-10-12', memo: 'x', lines: [{ code: '6990', debit: 1 }, { code: '1000', credit: 1 }] }),
  'type a sale': () => F.saveSale(acc, { date: '2026-10-12', shop: 'S1', total: 100, vat: 11.11, via: 'cash:S1' }),
  'record a tax payment': () => F.recordTaxPayment(acc, { tax: 'vat', date: '2026-10-12', amount: 5, via: `bank:${bank.uid}`, ym: '2026-09' }),
  'lodge the VAT return': () => RT.lodgeReturn(acc, 'vat', '2026-09', { ref: 'x' }),
  'typed VAT lines': () => RT.saveVatAdjust(acc, '2026-09', { l8: { amount: 5, note: 'x' } }),
  'tax calendar proof': () => TX.recordLodgement(acc, 'paye', '2026-09', { ref: 'x' }),
  'pay rules': () => P.savePayRules(acc, { ...P.payRules(), fnpfEmployerPct: 12 }),
  'tax calendar rules': () => TX.saveTaxRules(acc, TX.taxRules()),
  'switch a module off': () => setModuleOn(acc, 'bakery', false),
  'invoice rules (shared setting)': () => setShared('ap_rules', { vatRate: 15 }),
  'a business setting': () => setSetting('idle_logout_min', '999'),
  'device setting': () => setSetting('device_shop', 'S2'),
  'photo of an invoice': () => V.snap(acc, { kind: 'invoice', shopCode: 'S1', amount: 5, supplierUid: sup.uid, refNo: 'Z', photos: ['file:///x.jpg'] }),
  'add a staff member': () => saveUser({ name: 'Sneaky', pin: '7777', role: 'admin' }, acc),
  'raw change': () => db().run("UPDATE ap_invoices SET total = 1 WHERE uid = ?", [inv.uid]),
  'raw exec': () => db().exec("UPDATE ap_invoices SET total = 1"),
};

test('every kind of change is refused for the accountant – and nothing is left half saved', () => {
  setWriteGuard(viewOnlyGuard(acc));
  try {
    const before = count();
    const passed = [];
    for (const [what, fn] of Object.entries(REFUSED)) {
      try { fn(); passed.push(what); } catch (e) { if (!/View only|cannot|not allowed|Only|You cannot|permission/i.test(e.message)) passed.push(`${what} (other error: ${e.message})`); }
    }
    assert.deepStrictEqual(passed, [], `allowed: ${passed.join('; ')}`);
    assert.strictEqual(db().get('SELECT total FROM ap_invoices WHERE uid = ?', [inv.uid]).total, 112.5);
    assert.ok(count() - before <= 2, 'only audit / housekeeping rows'); // refused attempts are not written
    assert.strictEqual(P.payRules().fnpfEmployerPct, 10);
  } finally { setWriteGuard(null); }
});
test('what the accountant may still do: ask the owner, tutorials, own Home links, housekeeping, warnings, sync', () => {
  setWriteGuard(viewOnlyGuard(acc));
  try {
    assert.ok(Q.askQuery(acc, { text: 'Is P1 VAT inclusive?', ref: 'P1' }));
    setSetting('last_login', 'x');
    setShared('tutorial_progress', { [acc.uid]: { done: ['home'] } });
    setShared(`dashboard_layout_${acc.uid}`, ['tax']);
    setAlertSources([{ id: 'payables', alerts: apAlerts }, { id: 'payroll', alerts: payAlerts }]);
    collectAlerts(acc);
    withSystem(() => db().run("UPDATE ap_suppliers SET notes = 'synced' WHERE uid = ?", [sup.uid]));
    throws(() => setShared('dashboard_layout_SOMEONE_ELSE', ['x']), /View only/);
  } finally { setWriteGuard(null); }
});
test('the owner is never blocked', () => {
  assert.strictEqual(viewOnlyGuard(owner), null);
});
done();
