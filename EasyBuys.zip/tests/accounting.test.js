// Accounting & VAT (books worked out from the modules), FNPF / PAYE payments, period lock.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as T from '../src/modules/till/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as S from '../src/modules/payroll/statutory.js';
import * as A from '../src/modules/accounting/service.js';
import * as V from '../src/modules/verify/service.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { checkWeek } from '../src/modules/timesheets/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-20T18:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 0, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100, lastNo: 149 });
const bank = `1100:${acct.uid}`;

test('a day of trading: sales + VAT, cash short, invoice, payment, deposit, petty cash – books balance', () => {
  const till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 100 });
  // Z: total 1125 (cash 625 + card 500), VAT 125. Counted 715 = float 100 + cash 625 − 10 short.
  T.saveTillCount(mgr, { shopCode: 'S2', tillUid: till, shiftDate: '2026-10-05', shift: 'Full day', cashierUid: mgr.uid, openingFloat: 100, denominations: { n100: 7, n10: 1, n5: 1 },
    zCash: 625, zTotal: 1125, zVat: 125, tenders: [{ method: 'EFTPOS / card', amount: 500 }], payouts: [], adjustments: [], floatKept: 100, reason: 'Change error' }, { photos: ['file:///z.jpg'] });
  const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '500012345', onAccount: true });
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P1', total: 450, invoiceDate: '2026-10-05', shopCode: 'S2', category: 'Stock for resale' }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100, payDate: '2026-10-06', allocations: [{ invoiceUid: inv.uid, amount: 450 }] });
  T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: 'D1', date: '2026-10-06', denominations: { n100: 6 } });
  T.recordCash(mgr, { shopCode: 'S2', type: 'petty_out', amount: 15, category: 'Cleaning', note: 'Soap', date: '2026-10-06' });
  const tb = A.trialBalance('2026-10-31');
  assert.ok(tb.ok, `TB ${tb.dr} / ${tb.cr}`);
  const b = Object.fromEntries(tb.rows.map((r) => [r.code, r.balance]));
  assert.strictEqual(b['4000'], -1000, 'sales ex VAT');
  assert.strictEqual(b['6900'], 10, 'cash short');
  assert.strictEqual(b['1110'], 500, 'card to be banked');
  assert.strictEqual(b['2200'], -75, 'VAT: 125 output − 50 input');
  assert.strictEqual(b['5000'], 400);
  assert.strictEqual(b['6050'], 15);
  assert.strictEqual(b[bank], 150, '600 deposited − 450 cheque');
  assert.strictEqual(b['1000'] || 0, 0, '615 to the safe − 600 deposited − 15 petty');
  assert.strictEqual(b['2000'], undefined, 'supplier paid in full');
});

test('profit & loss per shop and balance sheet', () => {
  const pl = A.profitLoss({ from: '2026-10-01', to: '2026-10-31', shops: ['S1', 'S2'] });
  assert.strictEqual(pl.per.S2.income, 1000);
  assert.strictEqual(pl.per.S2.cogs, 400);
  assert.strictEqual(pl.per.S2.profit, 1000 - 400 - 25);
  assert.strictEqual(pl.per.total.profit, 575);
  const bs = A.balanceSheet('2026-10-31');
  assert.ok(bs.ok, `${bs.totalAssets} = ${bs.totalLiabilities} + ${bs.totalEquity}`);
});

test('VAT return per shop for the month (FRCS, invoice basis)', () => {
  const v = A.vatReturn({ ym: '2026-10', shop: 'S2' });
  assert.strictEqual(v.sales.total, 1125);
  assert.strictEqual(v.sales.output, 125);
  assert.strictEqual(v.purchases.input, 50);
  assert.strictEqual(v.net, 75);
  assert.strictEqual(v.due, '2026-11-30');
  assert.strictEqual(A.vatReturn({ ym: '2026-10', shop: 'S1' }).net, 0);
});

test('journal must balance; bank fee coded by default; suspense from uncoded bank lines', () => {
  throws(() => A.saveJournal(owner, { date: '2026-10-31', memo: 'x', lines: [{ code: '6990', debit: 10 }, { code: '3100', credit: 9 }] }), /must be equal/);
  A.saveJournal(owner, { date: '2026-10-01', memo: 'Opening bank', lines: [{ code: bank, debit: 1000 }, { code: '3000', credit: 1000 }] });
  AP.addBankEntry(owner, { accountUid: acct.uid, date: '2026-10-07', type: 'fee', amount: 5, reference: 'Fee' });
  const b = Object.fromEntries(A.trialBalance('2026-10-31').rows.map((r) => [r.code, r.balance]));
  assert.strictEqual(b['6600'], 5);
  assert.strictEqual(b[bank], 1145);
});

test('fixed asset depreciation month by month', () => {
  A.saveAsset(owner, { name: 'Chiller S2', shopCode: 'S2', purchaseDate: '2026-01-15', cost: 1200, lifeYears: 5, viaInvoice: false });
  const a = A.listAssets('2026-10-31')[0];
  assert.strictEqual(a.depreciated, 200, '10 months × 20');
  assert.strictEqual(a.bookValue, 1000);
  assert.ok(A.balanceSheet('2026-10-31').ok);
  A.disposeAsset(owner, a.uid, { date: '2026-10-20', amount: 900, reason: 'Sold' });
  const b = Object.fromEntries(A.trialBalance('2026-10-31').rows.map((r) => [r.code, r.balance]));
  assert.strictEqual(b['1500'] || 0, 0, 'cost taken off');
  assert.strictEqual(b['1590'] || 0, 0, 'depreciation taken off');
  assert.strictEqual(b['6990'], 120, 'loss: book value 1020 (9 months worn), sold for 900');
  assert.ok(A.balanceSheet('2026-10-31').ok);
});

let run;
test('FNPF / PAYE owed from the pay runs, paid, seen in the bank', () => {
  P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 10, fnpfNo: 'F123', tin: '987654321', payMethod: 'cash' });
  ['2026-10-03', '2026-10-05', '2026-10-06'].forEach((d) => { addManualPunch(owner, { userUid: mere.uid, type: 'IN', at: `${d} 08:00:00`, reason: 't' }); addManualPunch(owner, { userUid: mere.uid, type: 'OUT', at: `${d} 16:00:00`, reason: 't' }); });
  run = P.createRun(owner, '2026-10-05');
  checkWeek(owner, mere.uid, '2026-10-03', 'ok');
  P.finaliseRun(owner, run.uid);
  const f = S.monthFigures('2026-10');
  assert.ok(f.fnpf > 0);
  const items = S.prepareMonth('2026-10');
  const fnpf = items.find((x) => x.kind === 'fnpf');
  assert.strictEqual(fnpf.amount, f.fnpf);
  assert.strictEqual(fnpf.due_date, '2026-11-30');
  assert.strictEqual(fnpf.state, 'to_pay');
  assert.ok(V.queue().some((x) => x.table === 'stat_payments'));
  throws(() => S.payStat(owner, fnpf.uid, { date: '2026-11-05', method: 'transfer', accountUid: acct.uid }), /reference/);
  S.payStat(owner, fnpf.uid, { date: '2026-10-20', method: 'transfer', accountUid: acct.uid, reference: 'FNPF-OCT' });
  assert.strictEqual(S.listStat({ ym: '2026-10', kind: 'fnpf' })[0].state, 'paid');
  const be = V.queue().find((x) => x.uid === `BE-STAT-${fnpf.uid}`);
  assert.ok(be, 'payment waits for the bank');
  V.seenInBank(owner, be, '2026-10-20');
  assert.strictEqual(S.listStat({ ym: '2026-10', kind: 'fnpf' })[0].state, 'verified');
  const tb = A.trialBalance('2026-10-31');
  assert.ok(tb.ok);
  const b = Object.fromEntries(tb.rows.map((r) => [r.code, r.balance]));
  assert.strictEqual(b['2100'] || 0, 0, 'FNPF owed cleared by the payment');
  const ye = S.yearEnd(2026);
  assert.strictEqual(ye.people.length, 1);
  assert.strictEqual(ye.fnpfDiff, 0);
});

test('month-end checklist and period lock', () => {
  const c = A.monthEndChecklist('2026-10');
  assert.ok(c.auto.length >= 5);
  A.setLock(owner, '2026-10-31');
  throws(() => T.recordCash(mgr, { shopCode: 'S2', type: 'petty_out', amount: 5, category: 'Office', note: 'x', date: '2026-10-15' }), /books are closed up to 2026-10-31/);
  throws(() => A.setLock(owner, '2026-09-30'), /Only the owner can reopen/);
  A.setLock(owner, '2026-09-30', { reopen: true });
  T.recordCash(mgr, { shopCode: 'S2', type: 'opening', amount: 5, date: '2026-10-15' });
});

test('budget against actual', () => {
  A.saveBudget(owner, { ym: '2026-10', shopCode: 'S2', code: '6050', amount: 10 });
  const r = A.budgetVsActual({ ym: '2026-10', shopCode: 'S2' }).find((x) => x.code === '6050');
  assert.strictEqual(r.actual, 15);
  assert.strictEqual(r.diff, 5);
});

done();
