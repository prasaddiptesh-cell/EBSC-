// Full accounting (3.4): opening balances, typed sales/expenses, Aronium figures checked before booking, loans,
// repeating journals, prepayments, accruals, provisional tax, advance tax, year close, IFRS statements, forecast, pack.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as REC from '../src/modules/payables/recurring.js';
import * as T from '../src/modules/till/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as S from '../src/modules/accounting/statements.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-03-20T18:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 0, openingDate: '2025-12-31' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100, lastNo: 149 });
const bank = `1100:${acct.uid}`;
const r2 = (n) => Math.round(n * 100) / 100;
const tbOk = (d = '2026-12-31') => { const tb = A.trialBalance(d); assert.ok(tb.ok, `TB ${tb.dr} / ${tb.cr}`); return Object.fromEntries(tb.rows.map((r) => [r.code, r.balance])); };

test('new accounts are added to existing books', () => {
  const codes = A.listAccountsGL().map((a) => a.code);
  for (const c of ['1400', '2300', '2600', '2700', '8000', '4100']) assert.ok(codes.includes(c), c);
});

test('opening balances: balanced to opening capital; entering again replaces', () => {
  throws(() => F.saveOpeningBalances(owner, { date: '2025-12-31', lines: [{ code: '2500', credit: 100 }] }), /Loans/);
  throws(() => F.saveOpeningBalances(owner, { date: '2025-12-31', lines: [{ code: '2000', credit: 100 }] }), /unpaid invoice/);
  F.saveOpeningBalances(owner, { date: '2025-12-31', lines: [{ code: bank, debit: 5000 }, { code: '1300', debit: 2000, shop: 'S1' }, { code: '2110', credit: 1500 }] });
  let b = tbOk();
  assert.strictEqual(b[bank], 5000);
  assert.strictEqual(b['3000'], -5500);
  F.saveOpeningBalances(owner, { date: '2025-12-31', lines: [{ code: bank, debit: 6000 }, { code: '2110', credit: 1500 }] });
  b = tbOk();
  assert.strictEqual(b[bank], 6000, 'replaced, not added');
  assert.strictEqual(b['3000'], -4500);
  assert.strictEqual(F.acctSettings().goLive, '2025-12-31');
});

test('typed sale and expense: books, VAT return and the bank reconciliation all see them', () => {
  F.saveSale(owner, { date: '2026-01-10', shop: 'S1', total: 1125, via: `bank:${acct.uid}`, note: 'Bulk order school' });
  F.saveExpense(owner, { date: '2026-01-12', shop: 'S1', account: '6030', total: 225, via: 'cash:S1', supplier: 'Raj Plumbing', tin: '123456' });
  F.saveExpense(owner, { date: '2026-01-13', account: '6210', total: 600, claimVat: false, via: `bank:${acct.uid}`, supplier: 'Sun Insurance' });
  const b = tbOk();
  assert.strictEqual(b['4000'], -1000);
  assert.strictEqual(b['6030'], 200);
  assert.strictEqual(b['6210'], 600);
  const v = A.vatReturn({ ym: '2026-01' });
  assert.strictEqual(v.sales.output, 125);
  assert.strictEqual(v.purchases.input, 25);
  const be = db().all("SELECT * FROM bank_entries WHERE uid LIKE 'BE-JN-%' AND status = 'active'");
  assert.strictEqual(be.length, 2, 'a bank line each for the bank sale and the bank expense');
  assert.strictEqual(b[bank], 6000 + 1125 - 600, 'bank lines not counted twice');
  F.saveOwnerMoney(owner, { date: '2026-01-15', direction: 'out', amount: 300, via: `bank:${acct.uid}`, note: 'drawings' });
  F.saveTransfer(owner, { date: '2026-01-16', amount: 100, from: 'cash:S1', to: `bank:${acct.uid}` });
  const b2 = tbOk();
  assert.strictEqual(b2['3100'], 300);
  assert.strictEqual(b2[bank], 6000 + 1125 - 600 - 300 + 100);
});

test('Aronium sales (v3.5): brought in, matched to the till balances as End of day figures – never booked', () => {
  const till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 100 });
  T.saveTillCount(mgr, { shopCode: 'S2', tillUid: till, shiftDate: '2026-02-02', shift: 'Full day', cashierUid: mgr.uid, openingFloat: 100, denominations: { n100: 6 },
    zCash: 500, zTotal: 500, zVat: 55.56, tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });
  const csv = 'Date;Total;Tax;Cash;Card\n02/02/2026;510,00;56,67;510,00;0\n03/02/2026;450.00;50.00;300;150\n03/02/2026;225;25;225;0\n';
  const r = F.readAroniumCsv(csv, 'sales');
  assert.deepStrictEqual(r.errors, []);
  assert.strictEqual(r.rows.length, 2, 'rows added up per day');
  assert.strictEqual(r.rows[1].total, 675);
  const uid = F.addAroniumBatch(mgr, { kind: 'sales', shopCode: 'S2', rows: r.rows, fileName: 'sales.csv' });
  throws(() => F.addAroniumBatch(mgr, { kind: 'sales', shopCode: 'S2', rows: r.rows }), /already/);
  const before = tbOk()['4000'];
  assert.strictEqual(A.vatReturn({ ym: '2026-02', shop: 'S2' }).sales.total, 500, 'nothing used before checking');
  const rev = F.reviewBatch(uid);
  assert.strictEqual(rev.lines[0].action, 'compare');
  assert.strictEqual(rev.lines[0].diff, 10, 'Aronium says 10 more than the till count');
  assert.strictEqual(rev.lines[1].action, 'missing', 'no till balance that day');
  assert.strictEqual(rev.toBook, 0);
  setShared('verify_rules', { secondPerson: true });
  throws(() => F.approveBatch(mgr, uid), /different person/);
  const a = F.approveBatch(owner, uid);
  assert.strictEqual(a.booked, 0, 'Aronium sales are never booked');
  assert.strictEqual(a.eods, 2);
  assert.strictEqual(a.missing, 1);
  assert.strictEqual(a.differences.length, 1);
  assert.strictEqual(tbOk()['4000'], before, 'books unchanged: cash and banking come from the till balance');
  const v = A.vatReturn({ ym: '2026-02', shop: 'S2' });
  assert.strictEqual(v.sales.total, 1185, "VAT uses Aronium's figure: 510 (difference not explained) + 675 (till balance missing)");
  assert.strictEqual(v.aronium.unresolved, 1);
  assert.strictEqual(v.aronium.missingTill, 1);
  F.undoBatch(owner, uid, 'wrong shop');
  assert.strictEqual(A.vatReturn({ ym: '2026-02', shop: 'S2' }).sales.total, 500, 'undo takes the End of day figures out again');
  F.rejectBatch(owner, uid, 'Wrong shop – bring it in again for S1');
  assert.strictEqual(F.listBatches({ status: 'rejected' }).length, 1);
  setShared('verify_rules', { secondPerson: false });
});
test('Aronium paid-outs: each needs its account (or skip); one already in the till count is skipped', () => {
  const csv = 'Date,Description,Amount\n2026-02-02,Cleaning stuff,22.50\n2026-02-05,Bread delivery tip,10\n';
  const r = F.readAroniumCsv(csv, 'expenses');
  const uid = F.addAroniumBatch(mgr, { kind: 'expenses', shopCode: 'S2', rows: r.rows });
  throws(() => F.approveBatch(owner, uid), /Choose what/);
  const rows = F.reviewBatch(uid).lines.map((l, i) => ({ ...l, account: i === 0 ? '6050' : '', use: i === 0 ? 'book' : 'skip' }));
  F.approveBatch(owner, uid, { rows });
  const b = tbOk();
  assert.strictEqual(b['6050'], 20, '22.50 less 2.50 VAT');
});

let loan;
test('loans (Regular bills & loans): own account in the books; interest and fees from the statement; repayment bills', () => {
  const bsp = AP.saveSupplier(owner, { name: 'BSP Loans', onAccount: true });
  loan = REC.saveRecurring(owner, { kind: 'loan', name: 'Shop 1 Drasa Avenue', supplierUid: bsp.uid, amount: 1200, frequency: 'monthly', nextDate: '2026-01-31', leadDays: 7,
    loanNo: 'BL-77', openingBalance: 50000, openingDate: '2025-12-31', interestRate: 8 }).uid;
  let b = tbOk();
  assert.strictEqual(b[`2500:${loan}`], -50000);
  assert.ok(A.listAccountsGL().some((x) => x.code === `2500:${loan}`));
  REC.runRecurring(owner, '2026-01-31');
  const inv = AP.listInvoices({ filter: 'all' }).find((i) => i.uid.startsWith(`RI-${loan}-`));
  assert.ok(inv, 'repayment bill made');
  assert.strictEqual(inv.vat, 0, 'no VAT on a loan repayment');
  REC.addLoanEntry(owner, { recurringUid: loan, type: 'interest', amount: 333.33, date: '2026-01-31', note: 'Jan interest' });
  REC.addLoanEntry(owner, { recurringUid: loan, type: 'fee', amount: 5, date: '2026-01-31' });
  b = tbOk();
  assert.strictEqual(b['6700'], 333.33);
  assert.strictEqual(b[`2500:${loan}`], -(50000 + 333.33 + 5 - 1200));
  assert.strictEqual(b['2500'] || 0, 0, 'nothing on the general loans account');
  const l = F.getLoan(loan, '2026-12-31');
  assert.strictEqual(l.balance, 49138.33);
  assert.strictEqual(l.interestThisYear, 333.33);
  assert.strictEqual(l.paidThisYear, 1200);
  // The books agree with the loan statement once the bill is paid.
  AP.makePayment(owner, { supplierUid: bsp.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 103, payDate: '2026-01-31', allocations: [{ invoiceUid: inv.uid, amount: 1200 }] });
  assert.strictEqual(REC.loanStatement(loan).balance, 49138.33);
  const sch = F.loanSchedule(loan);
  assert.ok(sch.length > 30 && sch[sch.length - 1].balance === 0, 'paid off in the end');
});

test('repeating journal: month-ends stay month-ends; closed months skipped', () => {
  F.saveRecurring(owner, { memo: 'Security monthly', nextDate: '2026-01-31', times: 3, lines: [{ code: '6240', debit: 100 }, { code: '2300', credit: 100 }] });
  const made = F.runRecurring(owner, '2026-03-31');
  assert.strictEqual(made.length, 3);
  const dates = db().all("SELECT jdate FROM gl_journals WHERE memo = 'Security monthly' ORDER BY jdate").map((r) => r.jdate);
  assert.deepStrictEqual(dates, ['2026-01-31', '2026-02-28', '2026-03-31']);
  assert.strictEqual(F.listRecurring()[0].active, 0, 'finished');
  assert.strictEqual(F.nextMonthSameDay('2026-01-15'), '2026-02-15');
});

test('prepayment spread over 12 months; accrual reversed next month', () => {
  F.saveExpense(owner, { date: '2026-01-05', account: '6210', total: 1200, claimVat: false, via: `bank:${acct.uid}`, supplier: 'Sun Insurance (year)' });
  F.spreadPrepayment(owner, { date: '2026-01-05', amount: 1200, account: '6210', months: 12, memo: 'Shop insurance' });
  F.runRecurring(owner, '2026-12-31');
  let b = tbOk();
  assert.strictEqual(b['1400'] || 0, 0, 'all used up by December');
  const jan = A.profitLoss({ from: '2026-01-01', to: '2026-01-31', shops: [] }).rows.find((r) => r.code === '6210').total;
  assert.strictEqual(jan, 600 + 100, `${jan} January: the other 600 + one share of 100 (the year's 1,200 moved to paid in advance)`);
  F.accrue(owner, { date: '2026-03-31', amount: 250, account: '6010', memo: 'Power used in March' });
  const mar = A.profitLoss({ from: '2026-03-01', to: '2026-03-31', shops: [] }).rows.find((r) => r.code === '6010').total;
  assert.strictEqual(mar, 250);
  b = tbOk('2026-04-30');
  assert.strictEqual(b['2300'] || 0, -300, 'only the security accruals (3 × 100) left; the power accrual reversed');
});

test('provisional tax: 5% kept back from a contractor once over $1,000 a year', () => {
  const c = AP.saveSupplier(owner, { name: 'Ram Builders', tin: '987654', onAccount: false, withholdPct: 5 });
  const i1 = AP.saveInvoice(owner, { supplierUid: c.uid, invoiceNo: 'B1', total: 562.5, invoiceDate: '2026-03-01', category: 'Repairs' }, { canCheck: true });
  const p1 = AP.makePayment(owner, { supplierUid: c.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 101, payDate: '2026-03-02', allocations: [{ invoiceUid: i1.uid, amount: 562.5 }] });
  assert.ok(!p1.withheld, 'under $1,000 so far (500 ex VAT)');
  const i2 = AP.saveInvoice(owner, { supplierUid: c.uid, invoiceNo: 'B2', total: 1125, invoiceDate: '2026-03-05', category: 'Repairs' }, { canCheck: true });
  const w = AP.withholdingFor(c.uid, [{ invoiceUid: i2.uid, amount: 1125 }], '2026-03-06');
  assert.strictEqual(w.withheld, 50, '5% of 1,000 ex VAT');
  const p2 = AP.makePayment(owner, { supplierUid: c.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 102, payDate: '2026-03-06', allocations: [{ invoiceUid: i2.uid, amount: 1125 }] });
  assert.strictEqual(p2.withheld, 50);
  assert.strictEqual(db().get('SELECT amount FROM cheques WHERE cheque_no = 102').amount, 1075, 'the cheque is for the rest');
  assert.strictEqual(AP.getInvoice(i2.uid).owing, 0, 'the invoice is settled in full');
  const b = tbOk();
  assert.strictEqual(b['2600'], -50);
  const m = F.provTaxMonths()[0];
  assert.strictEqual(m.ym, '2026-03'); assert.strictEqual(m.owing, 50); assert.strictEqual(m.due, '2026-04-30');
  F.recordTaxPayment(owner, { tax: 'prov', date: '2026-04-20', amount: 50, via: `bank:${acct.uid}`, ym: '2026-03' });
  assert.strictEqual(F.provTaxMonths()[0].state, 'paid');
  assert.strictEqual(tbOk()['2600'] || 0, 0);
  assert.strictEqual(F.provTaxBySupplier(2026)[0].withheld, 50);
});

test('advance tax: three instalments at months 6, 9 and 12; reminders', () => {
  F.saveAcctSettings(owner, { lastYearTax: 9000 });
  const plan = F.advanceTaxPlan(2026);
  assert.deepStrictEqual(plan.map((p) => p.due), ['2026-06-30', '2026-09-30', '2026-12-31']);
  assert.strictEqual(plan[0].amount, 3000);
  const al = F.accountingAlerts('2026-06-20');
  assert.ok(al.some((a) => a.key === 'adv-1'));
  F.recordTaxPayment(owner, { tax: 'advance', date: '2026-06-25', amount: 3000, via: `bank:${acct.uid}`, year: 2026, n: 1 });
  assert.strictEqual(F.advanceTaxPlan(2026)[0].state, 'paid');
  assert.strictEqual(tbOk()['1450'], 3000);
});

test('review fixes: credit notes are not payments for provisional tax; the cheque matches', () => {
  const c = AP.saveSupplier(owner, { name: 'Kumar Cleaning', tin: '555666', onAccount: false, withholdPct: 5 });
  const inv = AP.saveInvoice(owner, { supplierUid: c.uid, invoiceNo: 'K1', total: 2250, invoiceDate: '2026-03-10', category: 'Cleaning' }, { canCheck: true });
  const cr = AP.saveInvoice(owner, { supplierUid: c.uid, kind: 'credit', invoiceNo: 'KC1', total: 1125, invoiceDate: '2026-03-11', category: 'Cleaning' }, { canCheck: true });
  const p = AP.settle(owner, { credits: [{ creditUid: cr.uid, allocations: [{ invoiceUid: inv.uid, amount: 1125 }], date: '2026-03-12' }],
    payment: { supplierUid: c.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 104, payDate: '2026-03-12', allocations: [{ invoiceUid: inv.uid, amount: 1125 }] } });
  assert.strictEqual(p.withheld || 0, 0, 'only $1,000 really paid (ex VAT) – not over the threshold');
  assert.strictEqual(db().get('SELECT amount FROM cheques WHERE cheque_no = 104').amount, 1125);
  assert.ok(!db().get("SELECT 1 AS x FROM ap_payments WHERE method = 'credit' AND withheld > 0"));
  // A different rate in the settings is used.
  F.saveAcctSettings(owner, { provTaxPct: 10 });
  const i2 = AP.saveInvoice(owner, { supplierUid: c.uid, invoiceNo: 'K2', total: 1125, invoiceDate: '2026-03-15', category: 'Cleaning' }, { canCheck: true });
  assert.strictEqual(AP.withholdingFor(c.uid, [{ invoiceUid: i2.uid, amount: 1125 }], '2026-03-15').withheld, 100);
  F.saveAcctSettings(owner, { provTaxPct: 5 });
});

test('review fixes: Aronium sales for a day that later gets a till count are not counted twice', () => {
  const rows = [{ date: '2026-03-05', total: 1125, vat: 125, zero: 0, cash: 1125, card: 0, other: 0 }];
  const uid = F.addAroniumBatch(mgr, { kind: 'sales', shopCode: 'S1', rows });
  F.approveBatch(owner, uid);
  const before = A.vatReturn({ ym: '2026-03', shop: 'S1' }).sales.total;
  const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till S1', floatAmount: 100 });
  T.saveTillCount(owner, { shopCode: 'S1', tillUid: till, shiftDate: '2026-03-05', shift: 'Full day', cashierUid: owner.uid, openingFloat: 100, denominations: { n100: 12, n20: 1, n5: 1 },
    zCash: 1125, zTotal: 1125, zVat: 125, tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });
  assert.strictEqual(A.vatReturn({ ym: '2026-03', shop: 'S1' }).sales.total, before, 'the till count replaces the Aronium figure, not added to it');
  tbOk();
});

test('IFRS statements balance; cash flow agrees to the change in cash; forecast and pack', () => {
  const fs = S.financialStatements(2026);
  const pos = fs.sections[1].rows;
  const assets = pos.find((r) => r.item === 'TOTAL ASSETS').cy;
  const eqLiab = pos.find((r) => r.item === 'TOTAL EQUITY AND LIABILITIES').cy;
  assert.strictEqual(assets, eqLiab);
  assert.ok(/Agrees/.test(fs.sections[3].note), fs.sections[3].note);
  const f = S.cashForecast({ weeks: 4, today: '2026-03-20' });
  assert.strictEqual(f.weeks.length, 4);
  assert.ok(f.weeks.some((w) => w.loans > 0), 'loan repayments in the forecast');
  const pack = S.accountantPack('2026-01-01', '2026-12-31');
  assert.strictEqual(pack.sections.length, 8);
  assert.ok(pack.sections[0].rows.length > 10);
});

test('year close: kept balances give the same answers, faster; reopening drops them', () => {
  const live = A.balanceSheet('2027-02-28');
  throws(() => F.closeYear(owner, 2026), /Close the books/);
  A.setLock(owner, '2026-12-31');
  const r = F.closeYear(owner, 2026);
  assert.ok(Number.isFinite(r.profit));
  assert.ok(A.closedSnapshotBefore('2027-02-28'));
  const again = A.balanceSheet('2027-02-28');
  assert.strictEqual(again.totalAssets, live.totalAssets);
  assert.strictEqual(again.totalEquity, live.totalEquity);
  A.setLock(owner, '2026-06-30', { reopen: true });
  assert.strictEqual(A.closedSnapshotBefore('2027-02-28'), null, 'not used while the year is open again');
  A.setLock(owner, '2026-12-31');
  assert.strictEqual(A.closedSnapshotBefore('2027-02-28'), null, 'locking again is not enough – the year must be closed again');
  F.saveRecurring(owner, { memo: 'Late share', nextDate: '2026-11-30', times: 2, lines: [{ code: '6240', debit: 10 }, { code: '2300', credit: 10 }] });
  F.runRecurring(owner, '2027-01-31');
  const late = db().all("SELECT jdate, memo FROM gl_journals WHERE memo LIKE 'Late share%' ORDER BY jdate");
  assert.strictEqual(late.length, 2, 'both shares booked');
  assert.ok(late.every((j) => j.jdate === '2027-01-01'), 'in the first open month');
  assert.ok(/already closed/.test(late[0].memo));
  F.runRecurring(owner, '2027-01-31');
  assert.strictEqual(db().all("SELECT 1 FROM gl_journals WHERE memo LIKE 'Late share%'").length, 2, 'never twice');
});

done();
