// 3.8: My day builds its tasks from everyone's warnings; its own warnings must not call back into themselves
// (this froze the app right after logging in).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { saveUser } from '../src/services/catalog.js';
import { setAlertSources, collectAlerts, homeAlerts } from '../src/services/alerts.js';
import { alerts as mydayAlerts } from '../src/modules/myday/alerts.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9911', role: 'owner' });
let calls = 0;
const other = { id: 'other', alerts: () => { calls += 1; return [{ id: 'x-1', level: 'warning', text: 'Something to do', nav: { screen: 'Home', params: {} } }]; } };
const nosy = { id: 'nosy', alerts: (u) => collectAlerts(u).filter((a) => a.id !== 'n').map((a) => ({ ...a, id: `nosy-${a.id}` })) };

test('My day warnings with every other module: finishes quickly, no loop', () => {
  setAlertSources([{ id: 'myday', alerts: mydayAlerts }, other]);
  const t = Date.now();
  const list = collectAlerts(owner);
  assert.ok(Date.now() - t < 3000, 'took too long');
  assert.ok(list.some((a) => a.id === 'x-1'));
  assert.ok(calls < 5, `other module asked ${calls} times`);
  homeAlerts(owner);
});

test('a module that reads other warnings cannot recurse forever', () => {
  setAlertSources([nosy, other, { id: 'myday', alerts: mydayAlerts }]);
  const t = Date.now();
  const list = collectAlerts(owner);
  assert.ok(Date.now() - t < 3000);
  assert.ok(list.some((a) => a.id === 'x-1'));
});
done();
