// 1.0.x security loopholes closed: PINs are never shown or copied, only staff managers change staff and nobody
// changes their own role, wrong PINs always count (and the lock survives a restart), a backup restore is owner /
// admin only and never touches the change history, only the owner reopens a month, Watchdog answers are owner / admin.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, getSetting, stripSecrets, stripSecretsText } from '../src/services/core.js';
import { saveUser, getUser, login, loginLockRemaining, resetLoginLock, pinLengths } from '../src/services/catalog.js';
import * as BIN from '../src/services/bin.js';
import * as A from '../src/modules/accounting/service.js';
import * as W from '../src/services/watchdog.js';
import { restoreBackup, dumpDatabase } from '../src/platform/cloud.js';
import { lockDate } from '../src/services/lock.js';
import { sha256Text } from '../src/services/sha256.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Asha Admin', pin: '7777', role: 'admin' }, owner);
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const pay = saveUser({ name: 'Pay Clerk', pin: '6666', role: 'payroll' }, owner);

// ---------------------------------------------------------------- 1. staff records
test('a manager (face enrol only) cannot add or change staff, PINs or roles', () => {
  throws(() => saveUser({ id: sita.id, name: 'Sita', pin: '1357', role: 'staff', shopCode: 'S1' }, mgr), /not allowed to add or change staff/);
  throws(() => saveUser({ id: mgr.id, name: 'Mgr', pin: '8888', role: 'admin', shopCode: 'S1' }, mgr), /not allowed/);
  throws(() => saveUser({ name: 'Friend', pin: '4545', role: 'staff' }, mgr), /not allowed/);
  assert.strictEqual(getUser(sita.id).pin, '2323');
  assert.strictEqual(getUser(mgr.id).role, 'manager');
});
test('nobody changes their own role (the owner may); an admin still changes other people', () => {
  throws(() => saveUser({ id: admin.id, name: 'Asha Admin', pin: '', role: 'manager' }, admin), /cannot change your own role/);
  const a2 = saveUser({ id: admin.id, name: 'Asha A. Admin', pin: '', role: 'admin' }, admin);
  assert.strictEqual(a2.name, 'Asha A. Admin', 'own name may change');
  const s2 = saveUser({ id: sita.id, name: 'Sita', pin: '', role: 'supervisor', shopCode: 'S1' }, admin);
  assert.strictEqual(s2.role, 'supervisor');
  saveUser({ id: sita.id, name: 'Sita', pin: '', role: 'staff', shopCode: 'S1' }, admin);
  const o2 = saveUser({ id: owner.id, name: 'Owner', pin: '', role: 'owner' }, owner);
  assert.strictEqual(o2.role, 'owner');
});
test('a blank PIN keeps the PIN; a new PIN replaces it; the PIN is never in the change history', () => {
  saveUser({ id: sita.id, name: 'Sita', pin: '', role: 'staff', shopCode: 'S1' }, owner);
  assert.strictEqual(getUser(sita.id).pin, '2323');
  saveUser({ id: sita.id, name: 'Sita', pin: '2424', role: 'staff', shopCode: 'S1' }, owner);
  assert.strictEqual(getUser(sita.id).pin, '2424');
  throws(() => saveUser({ name: 'New', pin: '', role: 'staff' }, owner), /PIN must be 4 to 6 digits/);
  const rows = db().all("SELECT before, after FROM audit_log WHERE table_name = 'users'");
  assert.ok(rows.length >= 3);
  assert.ok(rows.every((r) => !/"pin"|password_hash/.test(`${r.before || ''}${r.after || ''}`)));
});
test('the staff screens: UserEdit only with staff_manage, and the PIN field starts empty', async () => {
  const fs = await import('fs');
  const idx = fs.readFileSync('src/modules/staff/index.js', 'utf8');
  assert.ok(/UserEdit: \{ component: UserEditScreen, can: \(u\) => can\(u, 'staff_manage'\) \}/.test(idx), 'UserEdit needs staff_manage');
  assert.ok(/FaceEnrol: \{ component: FaceEnrolScreen, can: \(u\) => can\(u, 'face_enrol'\) \}/.test(idx), 'face enrolment keeps its own screen');
  const src = fs.readFileSync('src/modules/staff/screens/StaffScreens.js', 'utf8');
  assert.ok(!/pin: u \? u\.pin/.test(src), 'existing PIN not pre-filled');
  assert.ok(/leave blank to keep the PIN/.test(src) && /Set a new PIN/.test(src));
});
test('hiring: a recruiter may add a Staff login only', () => {
  const recruit = { ...mgr }; // managers have recruit_manage by default
  const u = saveUser({ name: 'New Starter', pin: '3131', role: 'staff', shopCode: 'S1' }, recruit, { hire: true });
  assert.ok(u && u.uid);
  throws(() => saveUser({ name: 'Boss Starter', pin: '3132', role: 'manager', shopCode: 'S1' }, recruit, { hire: true }), /not allowed/);
});

// ---------------------------------------------------------------- 2. PIN lock
test('every wrong 4-digit PIN counts: 5 wrong locks the login', () => {
  resetLoginLock();
  for (let i = 0; i < 4; i++) assert.strictEqual(login('0001'), null);
  assert.strictEqual(loginLockRemaining(), 0);
  assert.strictEqual(login('0002'), null);
  assert.ok(loginLockRemaining() > 0, 'locked after 5');
  assert.strictEqual(login('9999'), null, 'even the right PIN waits');
});
test('the lock is kept in the device settings (a restart does not clear it) and a right PIN after the wait works', () => {
  const saved = JSON.parse(getSetting('login_lock', 'null'));
  assert.ok(saved && saved.until > clock.now().getTime() && saved.rounds === 1);
  // a "restart": the count is read back from the settings
  setSetting('login_lock', JSON.stringify({ fails: 4, until: 0, rounds: 1 }));
  login('0003');
  assert.ok(loginLockRemaining() > 60, 'second lock is longer – the count came from the settings');
  clock.override = new Date('2026-10-31T10:30:00');
  assert.ok(login('9999'));
  assert.deepStrictEqual(JSON.parse(getSetting('login_lock', 'null')), { fails: 0, until: 0, rounds: 0 });
});
test('no prefix leak: the PIN pad only learns the PIN lengths in use', async () => {
  const C = await import('../src/services/catalog.js');
  assert.strictEqual(C.hasLongerPin, undefined);
  assert.strictEqual(C.pinMatches, undefined);
  assert.deepStrictEqual(pinLengths(), [4]);
  saveUser({ name: 'Long Pin', pin: '135790', role: 'staff' }, owner);
  assert.deepStrictEqual(pinLengths(), [4, 6]);
  const fs = await import('fs');
  const src = fs.readFileSync('src/app/LoginScreen.js', 'utf8');
  assert.ok(!/hasLongerPin|pinMatches/.test(src));
});

// ---------------------------------------------------------------- 4. PINs never copied
test('deleting a staff member: no PIN or password in the bin or the history; put back with no PIN', () => {
  const temp = saveUser({ name: 'Temp Person', pin: '4646', role: 'staff', username: 'tempp', password: 'secret12' }, owner);
  const r = BIN.deleteRecord(owner, 'users', temp.uid, { reason: 'added by mistake' });
  const data = db().all('SELECT data FROM bin_parts WHERE bin_uid = ? ORDER BY n', [r.uid]).map((p) => p.data).join('');
  assert.ok(data.includes('Temp Person'));
  assert.ok(!/"pin"|password_hash|4646/.test(data), data.slice(0, 200));
  const h = db().get("SELECT before FROM audit_log WHERE action LIKE 'Deleted Staff Temp Person%'");
  assert.ok(h && h.before.includes('Temp Person') && !/"pin"|password_hash|4646/.test(h.before));
  BIN.restoreRecord(owner, r.uid);
  const back = db().get('SELECT * FROM users WHERE uid = ?', [temp.uid]);
  assert.strictEqual(back.pin, '', 'cannot log in until a new PIN is set');
  assert.strictEqual(login(''), null);
  throws(() => saveUser({ id: back.id, name: 'Temp Person', pin: '', role: 'staff' }, owner), /no PIN yet/);
});
test('backups hide PINs everywhere, also in older history entries', () => {
  db().run("INSERT INTO audit_log (uid, at, user_name, action, before, updated_at) VALUES ('A-old', '2026-01-01 00:00:00', 'x', 'old entry', ?, '2026-01-01 00:00:00')", [JSON.stringify({ name: 'Old', pin: '1212', password_hash: 'abc' })]);
  const d = dumpDatabase();
  assert.ok(d.users.every((u) => !u.pin || u.pin === '****'));
  assert.ok(!JSON.stringify(d.audit_log).includes('1212'));
  assert.deepStrictEqual(stripSecrets([{ t: 'users', row: { name: 'x', pin: '1', password_hash: 'h' } }]), [{ t: 'users', row: { name: 'x' } }]);
  assert.strictEqual(stripSecretsText('{"pin":"1234","n":1}'), '{"pin":"****","n":1}');
});

// ---------------------------------------------------------------- 3. backup restore
test('restoring a backup: owner or admin only, a real backup only, the change history is never replaced', () => {
  const backup = {
    _meta: { app: 'Easy Buys', made: '2026-10-30 08:00:00' },
    audit_log: [{ uid: 'A-old', at: '2026-01-01 00:00:00', action: 'rewritten', user_name: 'x', updated_at: '2026-01-01' }],
    gl_journals: [{ uid: 'J-OPEN', jdate: '2026-10-20', memo: 'open month', lines: '[]', kind: 'manual', status: 'active' }],
  };
  throws(() => restoreBackup(pay, backup, 'b.json'), /Only the owner or an admin/);
  throws(() => restoreBackup(mgr, backup, 'b.json'), /Only the owner or an admin/);
  throws(() => restoreBackup(owner, { gl_journals: [] }, 'x.json'), /not an Easy Buys backup/);
  const n = restoreBackup(admin, backup, 'backup-2026-10-30.json');
  assert.strictEqual(n, 1);
  assert.strictEqual(db().get("SELECT action FROM audit_log WHERE uid = 'A-old'").action, 'old entry', 'history untouched');
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action = 'Backup restored from backup-2026-10-30.json'"));
});

// ---------------------------------------------------------------- 5. month lock
test('only the owner reopens a month; closing still works for owner / admin', () => {
  A.setLock(admin, '2026-09-30');
  assert.strictEqual(lockDate(), '2026-09-30');
  throws(() => A.setLock(admin, '2026-08-31', { reopen: true }), /Only the owner can reopen/);
  throws(() => A.reopenMonth(admin, '2026-09', 'missed an invoice'), /Only the owner can reopen/);
  throws(() => A.setLock(sita, '2026-10-31'), /not allowed to close/);
  assert.strictEqual(lockDate(), '2026-09-30');
  A.reopenMonth(owner, '2026-09', 'missed an invoice');
  assert.strictEqual(lockDate(), '2026-08-31');
});
test('a backup restore leaves closed months alone', () => {
  const n = restoreBackup(owner, { _meta: { made: 'x' }, gl_journals: [{ uid: 'J-CLOSED', jdate: '2026-08-10', memo: 'closed month', lines: '[]', kind: 'manual', status: 'active' }] }, 'old.json');
  assert.strictEqual(n, 0);
  assert.ok(!db().get("SELECT 1 AS x FROM gl_journals WHERE uid = 'J-CLOSED'"));
});

// ---------------------------------------------------------------- 7. Watchdog
test('Watchdog findings are marked fixed / fine by the owner or an admin only', () => {
  throws(() => W.ackFinding(mgr, 'till_missing:x', 'fixed'), /Only the owner or an admin/);
  throws(() => W.ackFinding(null, 'till_missing:x', 'fixed'), /Only the owner or an admin/);
  W.ackFinding(admin, 'till_missing:x', 'fine');
});
test('the change-history fingerprint covers before / after values from now on, without flagging older entries', () => {
  setSetting('audit_chain_bad', '');
  // an older device: its checkpoint was made with the old formula (no before / after, no "df")
  let h = ''; let n = 0; let last = 0;
  for (const r of db().all('SELECT rowid AS rid, uid, at, action, user_name, record_uid, reason FROM audit_log ORDER BY rowid')) {
    h = sha256Text(`${h}|${r.uid}|${r.at}|${r.action}|${r.user_name || ''}|${r.record_uid || ''}|${r.reason || ''}`); n += 1; last = r.rid;
  }
  setSetting('audit_chain', JSON.stringify({ upto: last, hash: h, count: n, at: '2026-10-30 10:00:00' }));
  assert.ok(W.verifyChain({ full: true }).ok, 'upgrading flags nothing');
  assert.strictEqual(JSON.parse(getSetting('audit_chain', 'null')).df, last, 'newer entries use the new formula');
  assert.ok(W.verifyChain({ full: true }).ok, 'and the next check is fine too');
  saveUser({ name: 'After Check', pin: '5858', role: 'staff' }, owner);
  assert.ok(W.verifyChain({ full: true }).ok);
  // someone edits what a newer entry says it changed
  db().run("UPDATE audit_log SET after = '{\"name\":\"Someone else\"}' WHERE action = 'Added staff member' AND after LIKE '%After Check%'");
  saveUser({ name: 'Next One', pin: '5959', role: 'staff' }, owner);
  const r = W.verifyChain({ full: true });
  assert.strictEqual(r.ok, false, 'the changed before / after is caught');
  setSetting('audit_chain', ''); setSetting('audit_chain_bad', '');
});

// ---------------------------------------------------------------- 8. purge with a wrong clock
test('the Deleted bin is not emptied while the device clock is more than a day out', () => {
  setSetting('clock_skew_min', String(3 * 24 * 60));
  assert.strictEqual(BIN.clockLooksWrong(), true);
  assert.strictEqual(BIN.purgeBin({ today: '2099-01-01' }), 0);
  setSetting('clock_skew_min', '0');
  assert.strictEqual(BIN.clockLooksWrong(), false);
});
done();
