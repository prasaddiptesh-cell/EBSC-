// 1.0.0 product cross-checks from the invoices: VAT on the invoice vs the app and Aronium, selling at / below the
// invoice cost in Aronium, suppliers from the invoices, and barcodes found at the stock take to add in Aronium.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as IR from '../src/modules/inventory/invoiceRead.js';
import * as PC from '../src/modules/inventory/productChecks.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const punjas = AP.saveSupplier(owner, { name: 'Punjas Ltd', tin: '50-12345-0-1', onAccount: true });
const fmf = AP.saveSupplier(owner, { name: 'FMF Foods', tin: '50111222', onAccount: true });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const rice = u(I.saveItem(owner, { code: '1003', name: 'Rice 20kg', cost: 30, price: 42 }));
const flour = u(I.saveItem(owner, { code: '1001', name: 'Punjas Flour 10kg', cost: 18.5, price: 24.95 }));
db().run("UPDATE inv_items SET vat_type = 'standard', aronium_vat = 'standard' WHERE uid = ?", [rice]); // the app and Aronium say VAT
db().run("UPDATE inv_items SET vat_type = 'standard', aronium_vat = 'standard', supplier_uid = ? WHERE uid = ?", [fmf.uid, flour]);

test('how a line says it is taxed', () => {
  assert.equal(PC.lineVat('Rice 20kg Zero 2 30.00 60.00'), 'zero');
  assert.equal(PC.lineVat('Sugar 1kg ZR 5 2.00 10.00'), 'zero');
  assert.equal(PC.lineVat('Stamps exempt 1 5.00'), 'exempt');
  assert.equal(PC.lineVat('Flour 10kg 12.5% 10 19.50 195.00'), 'standard');
  assert.equal(PC.lineVat('Milk 1L 6 2.10 12.60'), null, 'not shown: no evidence');
});
test('an invoice says rice is zero rated, the app and Aronium say 12.5%: flagged for both', () => {
  const res = IR.readInvoiceText('PUNJAS LIMITED\nInv Ref: PJ-1\n1001 Punjas Flour 10kg bag 12.5% 10 19.50 195.00\nRice 20kg Zero 2 30.00 60.00\nAmount Payable 279.38\n', { supplierUid: punjas.uid });
  IR.saveRead(mgr, { supplierUid: punjas.uid, engine: 'device', text: 'x', result: res });
  const m = PC.invoiceVatMismatches();
  assert.deepEqual(m.map((x) => x.code), ['1003']);
  assert.ok(m[0].appOff && m[0].aroniumOff);
  assert.ok(/says Zero rated/.test(m[0].text));
  assert.ok(invAlerts(mgr).some((a) => /invoice VAT differs/.test(a.text)));
});
test('selling price in Aronium vs the invoice cost (with VAT): the same, or below – warned', () => {
  const snap = (code, price) => JSON.stringify({ on: true, name: code, price, cost: 1 });
  db().run("INSERT INTO product_watch (uid, shop_code, code, snap, updated_at, updated_device) VALUES ('w1', 'S1', '1001', ?, 'x', 'x'), ('w2', 'S2', '1001', ?, 'x', 'x'), ('w3', 'S1', '1003', ?, 'x', 'x')",
    [snap('1001', 20.81), snap('1001', 24.95), snap('1003', 30)]);
  const p = PC.priceVsCost();
  assert.deepEqual(p.same.map((x) => `${x.shop}${x.code}`), ['S1-1001'.replace('-', '')], JSON.stringify(p)); // 18.50 + 12.5% = 20.81
  assert.deepEqual(p.below.map((x) => x.code), ['1003'], 'rice 30 < 33.75 with VAT');
  const al = invAlerts(mgr);
  assert.ok(al.some((a) => /below the invoice cost/.test(a.text) && a.notify));
  assert.ok(al.some((a) => /at the cost price/.test(a.text)));
});
test('suppliers: the invoices say Punjas, the main supplier is FMF – shown, and one tap fixes it', () => {
  I.noteItemSupplier(flour, punjas.uid, { cost: 19.5, date: '2026-10-30' });
  const s = PC.supplierCrossCheck();
  assert.ok(s.differs.some((x) => x.uid === flour && /invoices come from Punjas/.test(x.text)));
  throws(() => PC.useInvoiceSupplier(saveUser({ name: 'Sita', pin: '2323', role: 'staff' }, owner), flour), /manager/);
  PC.useInvoiceSupplier(mgr, flour);
  assert.equal(I.getItem(flour).supplier_uid, punjas.uid);
  assert.ok(!PC.supplierCrossCheck().differs.some((x) => x.uid === flour));
});
test('stock take: a barcode not on the product is put on it, and listed to add in Aronium', () => {
  throws(() => PC.attachBarcode(mgr, rice, 'x'), /does not look right/);
  PC.attachBarcode(mgr, rice, '9310000123');
  assert.ok(String(I.getItem(rice).barcode).includes('9310000123'));
  throws(() => PC.attachBarcode(mgr, flour, '9310000123'), /already on Rice/);
  assert.equal(PC.barcodeFixes()[0].name, 'Rice 20kg');
  assert.ok(invAlerts(mgr).some((a) => /barcode to add in Aronium/.test(a.text)));
  PC.barcodeFixDone(mgr, '9310000123');
  assert.ok(!invAlerts(mgr).some((a) => /to add in Aronium/.test(a.text)));
});
test('products with no barcode: listed, and a shop barcode (EAN-13, starts 21, check digit right, unique) can be made', () => {
  const tea = I.saveItem(owner, { code: '1009', name: 'Loose Tea', cost: 1, price: 2 });
  const uid = typeof tea === 'string' ? tea : tea.uid;
  assert.ok(PC.noBarcode().some((x) => x.uid === uid));
  assert.equal(PC.ean13Check('400638133393'), '1'); // a known EAN-13: 4006381333931
  const it = PC.makeShopBarcode(mgr, uid);
  assert.ok(/^21\d{11}$/.test(it.barcode), it.barcode);
  assert.equal(PC.ean13Check(it.barcode.slice(0, 12)), it.barcode[12]);
  assert.ok(!PC.noBarcode().some((x) => x.uid === uid));
  const other = I.saveItem(owner, { code: '1010', name: 'Loose Sugar', cost: 1, price: 2 });
  const b2 = PC.makeShopBarcode(mgr, typeof other === 'string' ? other : other.uid).barcode;
  assert.notEqual(b2, it.barcode);
  assert.ok(PC.barcodeFixes().some((x) => x.code === b2), 'to add in Aronium');
});
done();
