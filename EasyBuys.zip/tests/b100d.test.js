// 1.0.0 build 3: Dashboard "Sales today" is live from the till PCs (receipts, refunds taken off; else the till's sales
// of the day), and says which shop has nothing from its till PC; till balances only when there is no Link data.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, dateStr } from '../src/services/core.js';
import { salesOn } from '../src/modules/dashboard/cards36.js';
import { listCards } from '../src/services/dashboardCards.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T13:50:00');
const d = dateStr();
const put = (src, shop, kind, period, data) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?, ?, ?, ?, ?, ?, 0, 1, ?, ?, '2026-10-31T00:00:00Z', '1.0', '2026-10-31T01:00:00Z', 'x', 'synced')`, [`${src}|${kind}|${period}|0`, src, shop, `${shop} Till 1`, kind, period, JSON.stringify(data), `h${Math.random()}`]);

test('live receipts: sales minus refunds, how many, the last sale', () => {
  put('S1-T1', 'S1', 'meta', 'all', { counts: {} });
  put('S1-T1', 'S1', 'receipts', d, { cols: ['time', 'no', 'total', 'refund', 'pay', 'who', 'lines', 'pays', 'open'], rows: [
    ['08:01:00', 'S-1', 20, 0, 'Cash', 'Sita', 2, 'Cash=20.00', 1], ['13:40:00', 'S-2', 35.5, 0, 'Cash', 'Sita', 3, 'Cash=35.50', 1], ['12:00:00', 'R-1', 5, 1, 'Cash', 'Sita', 1, 'Cash=5.00', 1]] });
  const x = salesOn(d, 'S1');
  assert.deepEqual([x.live, x.total, x.receipts, x.refunds, x.last], [true, 50.5, 2, 1, '13:40']);
});
test('a shop with nothing from its till PC: the till balances, and the card says so', () => {
  const y = salesOn(d, 'S2');
  assert.equal(y.live, false);
  const card = listCards().find((c) => c.id === 'live_sales');
  const b = card.build({}, 'ALL');
  assert.equal(b.value.replace(/[^\d.]/g, ''), '50.50');
  assert.ok(/S2: nothing from its till PC today/.test(b.sub), b.sub);
  assert.equal(b.tone, 'warn');
  assert.ok(/live · 2 sales · 1 refund · last 13:40/.test(b.lines[0][0]), b.lines[0][0]);
});
test('a past day: the till\'s sales of that day (sales_day)', () => {
  put('S2-T1', 'S2', 'sales_day', '2026-10-24', { cols: ['code', 'sold_value', 'refund_value', 'net'], rows: [['A', 100, 10, 5]] });
  const z = salesOn('2026-10-24', 'S2');
  assert.deepEqual([z.live, z.total], [true, 90]);
});
done();
