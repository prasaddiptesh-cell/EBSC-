// 1.0.0 build 54 fixes from the owner's phone (build 53):
//  1. "The FCCC Gas price lookup does not work" – the PDF's text was thrown away (lpg.js read l.text, pdfLines gives
//     items), so no price was ever found; now read properly, with the cloud (Code.gs fccc_lpg) as the backup, a plain
//     message on the screen, "Type the prices", and the petrol / diesel warning (fuel_problem) shown.
//  2. "The EFL and Water bill extractor does not work" – bills were read on the phone only (no PDF), with words from
//     EFL's checker only; now the AI reads them (account number + due date), the phone reading knows paper bills, and
//     the bill is filed for the right shop by its account number.
// All account numbers here are made up.
import fs from 'fs';
import { createRequire } from 'module';
import { PDFDocument, StandardFonts } from 'pdf-lib';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, getSetting, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as LPG from '../src/modules/inventory/lpg.js';
import * as UB from '../src/services/utilityBills.js';
import * as SP from '../src/services/shopProfile.js';
import * as AI from '../src/services/invoiceAi.js';
import * as Flow from '../src/services/invoiceReadFlow.js';
import { readPaperText, readPaperAi, AI_PAPER_KINDS } from '../src/services/paperRead.js';
import { pdfTextItems, pdfLines } from '../src/services/pdfText.js';
import { test, atest, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-11-03T09:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);

// ---------------------------------------------------------------- the FCCC gas page and PDF
// The live page (Nov 2026): "PDF LPG Authorization (Effective 01/11/2026) November 2026", links into wp-content/uploads.
const GAS_PAGE_HTML = `<html><body><div class="tabs"><a href="#orders">Price Control Order</a><a href="#auth">Price Authorizations</a></div>
<div id="auth"><h3>Recent Authorizations</h3><ul>
<li><a class="pdf-link" href='https://fccc.gov.fj/wp-content/uploads/2026/10/FCCC-Final-Authorisation-for-Supply-of-LPG-Products-in-Fiji_Effective-1-November-2026.pdf' target="_blank"><i class="fa fa-file-pdf"></i><span>PDF</span> LPG Authorization (Effective 01/11/2026) <small>November 2026</small></a></li>
<li><a href="/wp-content/uploads/2026/09/FCCC-Final-Authorisation-for-Supply-of-LPG-Products-in-Fiji_Effective-1-October-2026_Final.pdf">PDF LPG Authorization (Effective 01/10/2026) October 2026</a></li>
<li><a href="https://fccc.gov.fj/wp-content/uploads/2026/08/Final-Authorisation-of-Prices-for-the-Supply-of-LPG-Products-in-Fiji-August.pdf">PDF LPG Authorization (Effective 01/08/2026) August 2026</a></li>
</ul><h3>Price Control Order</h3>
<a href="https://fccc.gov.fj/wp-content/uploads/2024/07/Control-of-Prices-for-the-Supply-of-LPG-Products-from-Butane-Gas-Order-202.pdf">PDF FCCC (Supply of LPG Products from Butane Gas) Order 2024</a>
</div></body></html>`;
const SCHEDULE = [
  ['Final Authorisation of Prices for the Supply of LPG Products in Fiji'],
  ['FCCC hereby makes the following authorisation effective from 1 November 2026.'],
  ['Schedule 1'], ['Viti Levu and Vanua Levu'],
  ['LPG Product', 'Wholesale Price (VEP)', 'Retail Price (VEP)'], ['Cylinder [Residential]', '($)', '($)'],
  ['Per KG', '$3.34', '$3.60'], ['4.5KG Cylinder', '$15.02', '$16.22'], ['12 KG Cylinder', '$40.05', '$43.26'],
  ['40 KG Cylinder', '$133.51', '$144.19'], ['50 KG Cylinder', '$166.89', '$180.24'],
  ['Bulk – Ex Factory'], ['Per KG', '$3.34', 'NA'],
  ['LPG Product', 'Wholesale Price (VEP)', 'Retail Price (VIP)'], ['Automotive Gas', '($)', '($)'], ['Per Litre', '$1.91', '$2.29'],
  ['Schedule 2'], ['Per KG', '$3.42', '$3.69'], ['12 KG Cylinder', '$41.00', '$44.30'],
];
async function authorisationPdf(rows = SCHEDULE) {
  const doc = await PDFDocument.create();
  const page = doc.addPage([595, 842]);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  let y = 800;
  for (const r of rows) { r.forEach((t, i) => page.drawText(t, { x: 50 + i * 180, y, size: 10, font })); y -= 18; }
  return doc.save();
}
const NOV = { kg: { w: 3.34, r: 3.6 }, c4_5: { w: 15.02, r: 16.22 }, c12: { w: 40.05, r: 43.26 }, c40: { w: 133.51, r: 144.19 }, c50: { w: 166.89, r: 180.24 }, auto: { w: 1.91, r: 2.29 } };

test('gas page: the live link format (single quotes, icons inside, relative links) gives the authorisations newest first', () => {
  const list = LPG.parseGasPage(GAS_PAGE_HTML);
  assert.deepEqual(list.map((x) => x.effective), ['2026-11-01', '2026-10-01', '2026-08-01'], 'the Price Control Orders are not authorisations');
  assert.ok(list[0].url.endsWith('Effective-1-November-2026.pdf'));
  assert.equal(list[1].url, 'https://fccc.gov.fj/wp-content/uploads/2026/09/FCCC-Final-Authorisation-for-Supply-of-LPG-Products-in-Fiji_Effective-1-October-2026_Final.pdf', 'a relative link made whole');
  const renamed = LPG.parseGasPage('<a href="https://fccc.gov.fj/wp-content/uploads/2026/11/FCCC-Final-Authorisation-for-Supply-of-LPG-Products-in-Fiji_Effective-1-December-2026.pdf">December LPG prices</a>');
  assert.deepEqual(renamed.map((x) => x.effective), ['2026-12-01'], 'link words changed: the date in the file name');
  assert.deepEqual(LPG.parseGasPage('<a href="x.pdf">Annual report</a>'), []);
});

await atest('the cause: a real authorisation PDF read on the phone gives every Schedule 1 price (build 53 got none)', async () => {
  const pages = pdfLines(await pdfTextItems(await authorisationPdf()));
  const build53 = pages.flatMap((p) => (p.lines || p).map((l) => (typeof l === 'string' ? l : l.text || '')));
  assert.deepEqual(LPG.parseLpgText(build53), {}, 'what build 53 did: every line empty');
  const lines = LPG.pdfPagesToLines(pages);
  assert.ok(lines.includes('Per KG $3.34 $3.60'), lines.join(' | '));
  assert.deepEqual(LPG.parseLpgText(lines), NOV, 'Schedule 1 only, not the bulk line, not Schedule 2');
});

test('Google\'s text reading (cells on separate lines) is read too', () => {
  const ocr = 'Schedule 1\nLPG Product\nWholesale Price (VEP)\nRetail Price (VEP)\nPer KG\n$3.34\n$3.60\n4.5KG Cylinder\n$15.02\n$16.22\n12 KG Cylinder\n$40.05\n$43.26\nBulk – Ex Factory\nPer KG\n$3.34\nNA\nPer Litre\n$1.91\n$2.29\nSchedule 2\n12 KG Cylinder\n$41.00\n$44.30';
  const p = LPG.parseLpgText(ocr);
  assert.deepEqual(p.c12, { w: 40.05, r: 43.26 });
  assert.deepEqual(p.kg, { w: 3.34, r: 3.6 });
  assert.deepEqual(p.auto, { w: 1.91, r: 2.29 });
});

await atest('checkLpg on the phone: the page and PDF read, prices kept, no problem left', async () => {
  const pdf = await authorisationPdf();
  const asked = [];
  const r = await LPG.checkLpg({ force: true, cloud: null, fetchText: async (u) => { asked.push(u); return GAS_PAGE_HTML; }, fetchBytes: async (u) => { asked.push(u); return pdf; } });
  assert.equal(r.read, true, JSON.stringify(r));
  assert.equal(r.via, 'phone');
  assert.equal(r.effective, '2026-11-01');
  assert.deepEqual(LPG.lpgPrices().prices, NOV);
  assert.equal(getSetting('lpg_problem', ''), '');
  assert.ok(asked[1].endsWith('Effective-1-November-2026.pdf'));
  const again = await LPG.checkLpg({ cloud: null, fetchText: async () => GAS_PAGE_HTML });
  assert.equal(again.skipped, 'not due', 'looked at most every 6 hours');
  setSetting('lpg_last_look', 0);
  const same = await LPG.checkLpg({ cloud: null, fetchText: async () => GAS_PAGE_HTML, fetchBytes: async () => { throw new Error('not needed'); } });
  assert.equal(same.same, true, 'the same month is not downloaded again');
});

await atest('the phone cannot read it (CORS in the web build, no PDF text): the cloud reads it', async () => {
  setSetting('lpg_last_look', 0);
  db().run("DELETE FROM shared_settings WHERE key IN ('lpg_prices','lpg_history')");
  const calls = [];
  const cloud = async (body, ms) => { calls.push({ body, ms }); return { ok: true, effective: '2026-11-01', url: 'https://fccc.gov.fj/x.pdf', prices: { kg: { w: 3.34, r: 3.6 }, c4_5: { w: 15.02, r: 16.22 }, c12: { w: '40.05', r: '$43.26' }, c40: null, c50: { w: 166.89, r: 180.24 }, auto: { w: 1.91, r: 2.29 } }, engine: 'ai' }; };
  const r = await LPG.checkLpg({ force: true, cloud, fetchText: async () => { throw new TypeError('Failed to fetch'); } });
  assert.equal(r.read, true, JSON.stringify(r));
  assert.equal(r.via, 'cloud');
  assert.deepEqual(calls.map((c) => c.body.kind), ['fccc_lpg']);
  assert.deepEqual(LPG.lpgPrices().prices.c12, { w: 40.05, r: 43.26 }, 'numbers tidied');
  assert.equal(LPG.lpgPrices().prices.c40, undefined);
  // the cloud gives Google's text of the PDF instead (no AI key)
  const t = await LPG.checkLpg({ force: true, cloud: async () => ({ ok: true, effective: '2026-11-01', url: 'u', text: LPG.pdfPagesToLines(pdfLines(await pdfTextItems(await authorisationPdf()))).join('\n') }), fetchText: async () => GAS_PAGE_HTML, fetchBytes: async () => new Uint8Array([1, 2, 3]) });
  assert.equal(t.read, true, JSON.stringify(t));
  assert.deepEqual(LPG.lpgPrices().prices, NOV);
});

await atest('nothing works: a plain message on the screen, and the prices are typed by hand', async () => {
  setSetting('lpg_last_look', 0);
  const old = await LPG.checkLpg({ force: true, cloud: async () => { throw new Error('Unknown request: fccc_lpg'); }, fetchText: async () => { throw new Error('Network request failed'); } });
  assert.equal(old.read, false);
  const msg = getSetting('lpg_problem', '');
  assert.ok(/Could not look up the FCCC gas prices/.test(msg) && /no internet/.test(msg) && /paste the new cloud script/.test(msg) && /Type the prices/.test(msg), msg);
  assert.ok(!/TypeError|undefined|null/.test(msg), 'plain English');
  assert.equal(old.message, msg);
  const noPdf = await LPG.checkLpg({ force: true, cloud: null, fetchText: async () => GAS_PAGE_HTML, fetchBytes: async () => new Uint8Array([37, 80, 68, 70]) });
  assert.equal(noPdf.read, false);
  assert.ok(/2026-11-01 authorisation/.test(noPdf.message), noPdf.message);
  const wrong = await LPG.checkLpg({ force: true, cloud: async () => ({ ok: true, effective: '2026-11-01', prices: { c12: { w: 400.5, r: 432.6 } } }), fetchText: async () => '<html></html>' });
  assert.equal(wrong.read, false, 'a misread is never kept');
  assert.ok(/look wrong/.test(getSetting('lpg_problem', '')));
  assert.ok(LPG.lpgAlerts(owner, '2026-11-03').some((a) => a.text === 'FCCC gas prices'), 'on Home too');
  // "Type the prices"
  throws(() => LPG.saveLpgPrices(mere, { effective: '2026-11-01', prices: { c12: { r: 43.26 } } }), /cannot change the gas prices/);
  throws(() => LPG.saveLpgPrices(owner, { effective: '1/11/2026', prices: { c12: { r: 43.26 } } }), /date the prices start/);
  throws(() => LPG.saveLpgPrices(owner, { effective: '2026-11-01', prices: { c12: { r: '' } } }), /at least one retail price/);
  LPG.saveLpgPrices(owner, { effective: '2026-11-01', prices: { c12: { w: '40.05', r: '43.26' }, c4_5: { w: '', r: '16.22' } } });
  assert.deepEqual(LPG.lpgPrices().prices.c4_5, { w: null, r: 16.22 });
  assert.equal(getSetting('lpg_problem', ''), '', 'typed prices clear the warning');
});

await atest('petrol and diesel: the order PDF read with the same fix; a failure is now shown (fuel_problem)', async () => {
  const doc = await PDFDocument.create(); const pg = doc.addPage([595, 842]); const font = await doc.embedFont(StandardFonts.Helvetica);
  [['(2) This Order comes into force on 1 November 2026.'], ['SCHEDULE 1'], ['1. Motor spirit (unleaded) per litre', '$3.12 (VIP)', '267.20c'], ['2. Gasoil (diesoline) per litre', '$3.38 (VIP)', '290.70c'], ['SCHEDULE 2'], ['1. Motor spirit (unleaded) per litre', '$3.25 (VIP)']]
    .forEach((r, i) => r.forEach((t, j) => pg.drawText(t, { x: 40 + j * 200, y: 800 - i * 18, size: 10, font })));
  const bytes = await doc.save();
  const page = '<a href="https://fccc.gov.fj/wp-content/uploads/2026/10/LN-130.pdf">PDF Petroleum Prices (No. 10) Order 2026</a>';
  const r = await LPG.checkFuel({ force: true, fetchText: async () => page, fetchBytes: async () => bytes });
  assert.equal(r.read, true, JSON.stringify(r));
  assert.deepEqual(LPG.fuelPrices().prices, { petrol: 3.12, diesel: 3.38 });
  assert.equal(getSetting('fuel_problem', ''), '');
  const down = await LPG.checkFuel({ force: true, fetchText: async () => { throw new Error('Network request failed'); } });
  assert.ok(down.error);
  assert.ok(/petrol and diesel/.test(getSetting('fuel_problem', '')) && /no internet/.test(getSetting('fuel_problem', '')));
  assert.ok(LPG.lpgAlerts(owner, '2026-11-03').some((a) => a.text === 'FCCC petrol and diesel prices' && /no internet/.test(a.sub)));
  const blank = await LPG.checkFuel({ force: true, fetchText: async () => page, fetchBytes: async () => await authorisationPdf() });
  assert.equal(blank.read, false);
  assert.ok(/Could not find the petrol and diesel prices/.test(getSetting('fuel_problem', '')), 'build 53 said nothing here');
});

// ---------------------------------------------------------------- the cloud script (cloud/Code.gs) fccc_lpg and bill hints
const req = createRequire(`${process.cwd()}/tests/x.js`);
const dev = { id: 'dev-tablet', name: 'Shop tablet', kind: 'tablet' };
await atest('Code.gs fccc_lpg: Apps Script fetches the page and newest PDF, Gemini reads Schedule 1; no key → Drive text; site down → FETCH', async () => {
  const pdfBytes = Array.from(await authorisationPdf());
  const { G, ctx, post } = req('./fakeGoogle.cjs').load();
  ctx.setup();
  const ask = (b) => post({ key: 'tablet-key-123', device: dev, ...b });
  const fetched = [];
  const web = (url) => {
    fetched.push(url);
    if (url === 'https://fccc.gov.fj/master-price-list/gas/') return { getResponseCode: () => 200, getContentText: () => GAS_PAGE_HTML };
    if (/\.pdf$/.test(url)) return { getResponseCode: () => 200, getBlob: () => ({ getBytes: () => pdfBytes }) };
    return null;
  };
  const geminiAsks = [];
  ctx.UrlFetchApp = { fetch: (url, o) => {
    if (/generativelanguage/.test(url)) { geminiAsks.push(JSON.parse(o.payload)); return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify({ effective_date: '2026-11-01', ...NOV }) }] } }] }) }; }
    return web(url);
  } };
  ctx.Drive = { Files: { create: () => ({ id: 'ocr1' }) } };
  ctx.DocumentApp = { openById: () => ({ getBody: () => ({ getText: () => 'Schedule 1\nPer KG $3.34 $3.60\n12 KG Cylinder $40.05 $43.26' }) }) };
  ctx.DriveApp.getFileById = () => ({ setTrashed: () => {} });
  const noKey = ask({ kind: 'fccc_lpg' });
  assert.equal(noKey.ok, true, JSON.stringify(noKey));
  assert.equal(noKey.engine, 'ocr', 'no GEMINI_KEY: Google Drive reads the PDF text');
  assert.equal(noKey.effective, '2026-11-01');
  assert.ok(/Per KG/.test(noKey.text));
  assert.ok(fetched[1].endsWith('Effective-1-November-2026.pdf'));
  G.props.GEMINI_KEY = 'test-gemini-key';
  const r = ask({ kind: 'fccc_lpg' });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.engine, 'ai');
  assert.deepEqual(r.prices.c12, NOV.c12);
  const g = geminiAsks[geminiAsks.length - 1];
  assert.equal(g.contents[0].parts[1].inline_data.mime_type, 'application/pdf');
  assert.ok(/Schedule 1/.test(g.contents[0].parts[0].text) && /never Schedule 2/.test(g.contents[0].parts[0].text));
  assert.deepEqual(Object.keys(g.generationConfig.responseSchema.properties), ['effective_date', 'kg', 'c4_5', 'c12', 'c40', 'c50', 'auto', 'notes']);
  // the app takes the cloud's answer
  setSetting('lpg_last_look', 0);
  db().run("DELETE FROM shared_settings WHERE key IN ('lpg_prices','lpg_history')");
  const app = await LPG.checkLpg({ force: true, fetchText: async () => { throw new Error('Failed to fetch'); }, cloud: async (body) => { const x = ask(body); if (!x.ok) throw new Error(x.error); return x; } });
  assert.equal(app.read, true, JSON.stringify(app));
  assert.deepEqual(LPG.lpgPrices().prices, NOV);
  // FCCC down / changed
  ctx.UrlFetchApp = { fetch: () => ({ getResponseCode: () => 503, getContentText: () => 'Service Unavailable' }) };
  const down = ask({ kind: 'fccc_lpg' });
  assert.deepEqual([down.ok, /FETCH/.test(down.error)], [false, true]);
  ctx.UrlFetchApp = { fetch: () => ({ getResponseCode: () => 200, getContentText: () => '<html>new site</html>' }) };
  const changed = ask({ kind: 'fccc_lpg' });
  assert.ok(/NO_LIST/.test(changed.error));
  ctx.UrlFetchApp = { fetch: () => { throw new Error('DNS error'); } };
  assert.equal(ask({ kind: 'fccc_lpg' }).ok, false, 'never throws');
  assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(fs.readFileSync('cloud/Code.gs', 'utf8')), 'no key in the public script');
});

test('Code.gs invoice_ai with a bill: told it is an EFL / WAF bill, the schema adds account_no and due_date; an invoice is unchanged', () => {
  const { G, ctx, post } = req('./fakeGoogle.cjs').load();
  ctx.setup();
  G.props.GEMINI_KEY = 'test-gemini-key';
  const sent = [];
  ctx.UrlFetchApp = { fetch: (url, o) => { sent.push(JSON.parse(o.payload)); return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify({ supplier: 'Energy Fiji Limited', account_no: '8800123456', total_incl: 186.45, due_date: '2026-11-21', lines: [] }) }] } }] }) }; } };
  const files = [{ mimeType: 'application/pdf', data: 'UERG' }];
  const r = post({ key: 'tablet-key-123', device: dev, kind: 'invoice_ai', files, hints: { suppliers: [], bill: 'power' } });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.invoice.account_no, '8800123456');
  const props = Object.keys(sent[0].generationConfig.responseSchema.properties);
  assert.deepEqual(props.slice(-2), ['account_no', 'due_date']);
  assert.ok(/Energy Fiji Limited \(EFL\)/.test(sent[0].contents[0].parts[0].text) && /account_no/.test(sent[0].contents[0].parts[0].text));
  post({ key: 'tablet-key-123', device: dev, kind: 'invoice_ai', files, hints: { suppliers: [] } });
  assert.deepEqual(Object.keys(sent[1].generationConfig.responseSchema.properties), ['supplier', 'supplier_tin', 'invoice_no', 'invoice_date', 'prices_incl_vat', 'subtotal_excl', 'vat', 'total_incl', 'lines', 'notes', 'confidence'], 'a supplier invoice: the same schema as before');
  assert.ok(!/Energy Fiji/.test(sent[1].contents[0].parts[0].text));
});

// ---------------------------------------------------------------- bills read on the phone (ML Kit text)
// Made-up EFL and WAF paper bills as ML Kit reads them, and the checkers' screenshots.
const EFL_PAPER = `ENERGY FIJI LIMITED
2 Marlow Street, Suva
TAX INVOICE / ELECTRICITY BILL
Customer Name: EASY BUYS SHOPPING CENTER
Account No. 8800 123 456
Invoice No: EB-2026-0451
Meter No: 55512345
Bill Date: 01/11/2026
Billing Period 01/10/2026 - 31/10/2026
Previous Balance $172.10
Payment Received - Thank You $172.10
Current Charges $186.45
Arrears $0.00
Amount Due $186.45
Due Date 21 Nov 2026`;
const WAF_PAPER = `WATER AUTHORITY OF FIJI
Tax Invoice
Account Number:
2000 0012 3456
Bill Date 02/11/2026
Previous Balance 45.10
Total Amount Payable $52.30
Pay by: 23/11/2026`;
const WAF_SCREEN = 'Bula Vinaka,\nYour bill total is $50.26 for Account Number 200000099999.\nThis is due on 09-11-2026.';
test('a paper EFL bill, a paper WAF bill and the WAF checker are read on the phone (build 53 found nothing on the bills)', () => {
  const e = UB.parseBillText(EFL_PAPER);
  assert.deepEqual(e, { account: '8800123456', total: 186.45, overdue: 0, due: '2026-11-21', billNo: 'EB-2026-0451' }, 'not the previous balance, not the meter number');
  const w = UB.parseBillText(WAF_PAPER);
  assert.deepEqual([w.account, w.total, w.due], ['200000123456', 52.3, '2026-11-23'], 'number on the line after its label');
  const s = UB.parseBillText(WAF_SCREEN);
  assert.deepEqual([s.account, s.total, s.due], ['200000099999', 50.26, '2026-11-09']);
  // the account number no longer runs on into the next figures
  assert.equal(UB.parseBillText('Account No: 8800123456 12/11/2026').account, '8800123456');
  assert.equal(UB.parseBillText('Account Number: 8800123456\n1200 kWh').account, '8800123456');
  // EFL's checker (as before)
  assert.deepEqual(UB.parseEflText('EFL Account Number: 7700011122\nTotal Amount Due: $0.00\nOverdue Amount: $0.00\nBill Due on: 19/10/2026'), { account: '7700011122', total: 0, overdue: 0, due: '2026-10-19' });
  const r = readPaperText('efl_bill', EFL_PAPER);
  assert.deepEqual([r.fields.accountNo, r.fields.total, r.fields.due, r.found >= 3], ['8800123456', 186.45, '2026-11-21', true]);
  for (const junk of ['', 'Account Name: EASY BUYS', 'Accept our thanks\n123456789', '9'.repeat(5000), 'x'.repeat(100000)]) assert.ok(UB.parseBillText(junk), 'never throws');
  assert.equal(UB.parseBillText('Account Name: EASY BUYS\n123456789').account, null);
  assert.equal(UB.parseBillText('Accept our thanks\n123456789').account, null);
});

// ---------------------------------------------------------------- bills read by the AI and filed under the shop
let effS1; let effS2; let wafS1;
test('the AI reading of a bill → the bill boxes (account, amount, due date)', () => {
  assert.ok(AI_PAPER_KINDS.includes('efl_bill'), 'bills go to the AI');
  const ai = AI.cleanAi({ supplier: 'Energy Fiji Limited', account_no: '8800-123-456', invoice_no: 'EB-2026-0451', invoice_date: '2026-11-01', total_incl: 186.45, due_date: '2026-11-21', lines: [], notes: 'Overdue amount $12.50 shown' }, { today: '2026-11-03' });
  assert.deepEqual([ai.account_no, ai.due_date], ['8800123456', '2026-11-21']);
  const r = readPaperAi('efl_bill', ai, {});
  assert.deepEqual(r.fields, { accountNo: '8800123456', total: 186.45, due: '2026-11-21', billNo: 'EB-2026-0451', supplierName: 'Energy Fiji Limited', overdue: 12.5 });
  assert.equal(r.found, 3);
  const far = AI.cleanAi({ account_no: '1', due_date: '2031-01-01', lines: [] }, { today: '2026-11-03' });
  assert.equal(far.due_date, null, 'a due date years away is a misread');
  const zero = readPaperAi('efl_bill', AI.cleanAi({ account_no: '7700011122', total_incl: 0, lines: [] }), {});
  assert.equal(zero.fields.total, 0, 'nothing owing is $0.00, not empty');
});

await atest('the bill flow: the AI is asked with the bill hint; a $0 bill with an account number is not "nothing found"; offline → the phone reads it', async () => {
  const calls = [];
  const deps = (answer) => ({ cloudUrl: () => 'https://script.example/exec', cloudCall: async (b) => { calls.push(b); if (answer instanceof Error) throw answer; return answer; }, recognizeText: async () => ({ ok: true, text: EFL_PAPER }), fileBase64: async () => 'QUJD', fileExists: async () => true, today: () => '2026-11-03' });
  const r = await Flow.readInvoiceFiles(['file:///bill.pdf'], { hints: { suppliers: [], bill: 'power' }, deps: deps({ ok: true, invoice: { supplier: 'Energy Fiji Limited', account_no: '7700011122', total_incl: 0, lines: [] } }) });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.engine, 'ai');
  assert.equal(r.ai.account_no, '7700011122');
  assert.equal(calls[0].hints.bill, 'power');
  assert.equal(calls[0].files[0].mimeType, 'application/pdf', 'a PDF bill goes to the AI');
  const off = await Flow.readInvoiceFiles(['file:///bill.jpg'], { hints: { bill: 'power' }, deps: deps(new Error('Network request failed')) });
  assert.equal(off.engine, 'device');
  assert.equal(readPaperText('efl_bill', off.text).fields.accountNo, '8800123456');
});

test('a bill read is matched to the shop\'s bill account by its number and filed in Invoices for that shop and supplier', () => {
  effS1 = SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', label: 'EFL – shop', accountNo: '8800 123 456' });
  effS2 = SP.saveAccount(owner, { shopCode: 'S2', kind: 'power', label: 'EFL – Tukani St', accountNo: '8800-777-001' });
  wafS1 = SP.saveAccount(owner, { shopCode: 'S1', kind: 'water', label: 'WAF – shop', accountNo: '200000123456' });
  assert.equal(UB.matchBillAccount('8800123456').uid, effS1);
  assert.equal(UB.matchBillAccount('8800777001', 'power').uid, effS2);
  assert.equal(UB.matchBillAccount('0200000123456').uid, wafS1, 'a leading zero or prefix');
  assert.equal(UB.matchBillAccount('8800777001', 'water'), null, 'not a water account');
  assert.equal(UB.matchBillAccount('123'), null);
  // "Read a bill" with no account chosen: the number finds Shop 2's account
  const r = UB.fileBillReading(owner, { accountNo: '8800777001', total: '186.45', due: '2026-11-21', source: 'bill_ai' });
  assert.equal(r.result, 'new_bill');
  assert.equal(r.account.uid, effS2);
  const inv = db().get('SELECT i.*, s.name AS sup FROM ap_invoices i JOIN ap_suppliers s ON s.uid = i.supplier_uid WHERE i.uid = ?', [r.invoice.uid]);
  assert.deepEqual([inv.shop_code, inv.total, inv.due_date, inv.sup], ['S2', 186.45, '2026-11-21', 'Energy Fiji Limited']);
  assert.equal(inv.invoice_no, 'EFL-8800-777-001-20261121');
  // the same bill again: not doubled
  const again = UB.fileBillReading(owner, { accountNo: '8800 777 001', total: 186.45, due: '21/11/2026' });
  assert.equal(again.result, 'same');
  assert.equal(db().get("SELECT COUNT(*) AS n FROM ap_invoices WHERE invoice_no = 'EFL-8800-777-001-20261121'").n, 1);
  // a bill for another account, while Shop 1's account is open: refused in plain words
  throws(() => UB.fileBillReading(owner, { accountUid: effS1, accountNo: '8800777001', total: 50 }), /This bill is for account 8800777001 \(EFL – Tukani St/);
  throws(() => UB.fileBillReading(owner, { accountNo: '9999999999', kind: 'water', total: 50 }), /No water bill account has the number 9999999999/);
  throws(() => UB.fileBillReading(owner, { total: 50 }), /choose the bill account/);
  // a water bill (WAF paper bill read on the phone) for Shop 1
  const w = UB.parseBillText(WAF_PAPER);
  const wr = UB.fileBillReading(owner, { accountNo: w.account, total: w.total, due: w.due, source: 'bill_photo' });
  assert.equal(db().get('SELECT shop_code, total FROM ap_invoices WHERE uid = ?', [wr.invoice.uid]).shop_code, 'S1');
  // someone who may not pay bills: the bill waits to be acknowledged
  const p = UB.fileBillReading(mere, { accountUid: effS1, total: 99.1, due: '2026-11-25' });
  assert.deepEqual([p.result, p.invoice], ['new_bill', null]);
  assert.ok(UB.waitingBills().some((x) => x.uid === p.uid));
});

done();
