// 1.0.0 build 4 loophole fixes: two tills selling one product add up (never replace), a device that does not know a
// product never zeroes a sale, sales decided per shop and day (till PCs, else till balances) on the dashboard, the
// managers' Sales card, the daily summary and wages against sales; a till missing from the Link shown in the sales
// history; till products not in the app on Home; uncounted-but-zeroed stock take lines and late sales; loose products'
// deliveries go onto the pack.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as T from '../src/modules/till/service.js';
import * as L from '../src/modules/aronium/link.js';
import * as SH from '../src/modules/till/salesHistory.js';
import * as LL from '../src/modules/inventory/looseLinks.js';
import { shopSalesByDay } from '../src/services/board.js';
import { dailySummary } from '../src/modules/home/overview.js';
import { wagesVsSales } from '../src/modules/timesheets/roster.js';
import '../src/modules/dashboard/cards.js';
import { listCards } from '../src/services/dashboardCards.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T21:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S2' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const rice = u(I.saveItem(owner, { code: 'RICE', name: 'Rice 1kg', cost: 2, price: 3 }));
const sugar = u(I.saveItem(owner, { code: 'SUG', name: 'Sugar 1kg', cost: 1.5, price: 2.5 }));
let n = 0;
const feed = (source, kind, period, data, till) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?, ?, ?, ?, ?, ?, 0, 1, ?, ?, '2026-10-31T00:00:00Z', '1.2', '2026-10-31 20:00:00', 'x', 'synced')`,
[`${source}|${kind}|${period}|0`, source, source.split('-')[0], till || `${source} till`, kind, period, JSON.stringify(data), `h${(n += 1)}`]);
const COLS = ['code', 'name', 'sold', 'sold_value', 'refunded', 'refund_value', 'net', 'cost'];
const sales = (source, date, rows) => feed(source, 'sales_day', date, { cols: COLS, rows });
const mv = (uid) => db().get("SELECT qty FROM inv_moves WHERE uid = ? AND status = 'active'", [uid]);
const D = '2026-10-29';

test('1: two tills, one product spelt / coded differently – the quantities add up, one sale record (never replaced)', () => {
  sales('S1-T1', D, [['RICE', 'Rice 1kg', 5, 15, 0, 0, 5, 10]]);
  sales('S1-T2', D, [['R-01', 'Rice 1kg', 3, 9, 0, 0, 3, 6]]);
  L.processLink({ force: true });
  assert.equal(mv(`SL-S1-${D}-RICE`).qty, -8, 'both tills');
  assert.equal(I.stockOf(rice, 'S1'), -8);
  assert.equal(db().get("SELECT COUNT(*) AS n FROM inv_moves WHERE uid LIKE ?", [`SL-S1-${D}-%`]).n, 1);
});

test('8: a product this device does not know never zeroes a sale; a sale really gone from every till goes back to 0', () => {
  // Till 2's figures change: the rice is gone from both tills, but an unknown product is there
  sales('S1-T1', D, [['SUG', 'Sugar 1kg', 1, 2.5, 0, 0, 1, 1.5]]);
  sales('S1-T2', D, [['MYS', 'Mystery noodles', 2, 4, 0, 0, 2, 2]]);
  L.processLink({ force: true });
  assert.equal(mv(`SL-S1-${D}-RICE`).qty, -8, 'not zeroed while a product is unknown here');
  assert.equal(mv(`SL-S1-${D}-SUG`).qty, -1);
  // 5: Home says so, with the name, and leads to the products import – it stays until the product is in the app
  const a = L.linkAlerts().find((x) => /not in the app/.test(x.text));
  assert.ok(a && /1 product sold on the tills is not in the app – its stock is not going down/.test(a.text), JSON.stringify(a));
  assert.ok(/Mystery noodles \(S1\)/.test(a.sub));
  assert.equal(a.nav.screen, 'InvImport');
  L.processLink({ force: true });
  assert.ok(L.linkAlerts().some((x) => /not in the app/.test(x.text)), 'kept round after round');
  const { alerts } = require('../src/modules/inventory/alerts.js');
  assert.ok(alerts(owner).some((x) => /not in the app/.test(x.text)), 'on Home');
  // the product is added: the day is worked again; the rice (gone from every till) goes back to 0
  I.saveItem(owner, { code: 'MYS', name: 'Mystery noodles', cost: 1, price: 2 });
  db().run("DELETE FROM aronium_link_done WHERE waiting = 1");
  L.processLink({ force: true });
  assert.equal(mv(`SL-S1-${D}-RICE`).qty, 0, 'zeroed');
  assert.equal(I.stockOf(rice, 'S1'), 0);
  assert.equal(mv(`SL-S1-${D}-MYS`).qty, -2);
  assert.ok(!L.linkAlerts().some((x) => /not in the app/.test(x.text)), 'gone once known');
});

test('8: the code still on a till line (only the name differs) keeps the sale', () => {
  sales('S1-T1', '2026-10-28', [['SUG', 'Sugar 1kg', 4, 10, 0, 0, 4, 6]]);
  L.processLink({ force: true });
  assert.equal(mv('SL-S1-2026-10-28-SUG').qty, -4);
  sales('S1-T1', '2026-10-28', [['SUG', 'SUGAR (white) 1 kg', 4, 10, 0, 0, 4, 6]]);
  L.processLink({ force: true });
  assert.equal(mv('SL-S1-2026-10-28-SUG').qty, -4);
});

// till balances for Shop 2 (no till PC), Shop 1 from the till PCs
const till2 = u(T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 100 }));
T.saveTillCount(mgr, { shopCode: 'S2', tillUid: till2, shiftDate: D, shift: 'Morning', cashierUid: sita.uid, openingFloat: 100, denominations: { n100: 2 },
  zCash: 100, zTotal: 100, zNumber: '7', tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });

test('2: dashboard sales decided per shop and day – Link for S1, till balances for S2 (never dropped)', () => {
  const s = shopSalesByDay('2026-10-01');
  const s1 = s.rows.find((r) => r.date === D && r.shop === 'S1');
  const s2 = s.rows.find((r) => r.date === D && r.shop === 'S2');
  assert.deepEqual([s1.value, s1.live], [6.5, true]);
  assert.deepEqual([s2.value, s2.live], [100, false], JSON.stringify(s.rows));
  assert.ok(/Aronium \(till PCs\), and the till balances/.test(s.source), s.source);
});

test('3: the managers\' Sales card, the daily summary and wages against sales use the till PCs\' sales', () => {
  const card = listCards().find((c) => c.id === 'sales');
  const b = card.build({ from: D, to: D }, 'ALL');
  assert.equal(b.value.replace(/[^\d.]/g, ''), '106.50', JSON.stringify(b));
  assert.ok(/1 from the till PCs, 1 from the till balances/.test(b.sub), b.sub);
  const only1 = card.build({ from: D, to: D }, 'S1');
  assert.equal(only1.value.replace(/[^\d.]/g, ''), '6.50', 'not $0 while the tills sell');
  const ds = dailySummary(D, D);
  assert.equal(ds.find((r) => r.shop === 'S1').sales, 6.5);
  assert.equal(ds.find((r) => r.shop === 'S2').sales, 100);
  const w = wagesVsSales({ from: D, to: D });
  assert.equal(w.find((r) => r.shop === 'S1').sales, 6.5);
  assert.equal(w.find((r) => r.shop === 'S2').sales, 100);
});

test('3: today with only receipts so far – the live receipts count', () => {
  feed('S1-T1', 'receipts', '2026-10-31', { cols: ['time', 'no', 'total', 'refund', 'pay', 'who', 'lines', 'pays', 'open'], rows: [['09:00:00', 'A1', 20, 0, 'Cash', 'Sita', 1, 'Cash=20', 1], ['10:00:00', 'R1', 5, 1, 'Cash', 'Sita', 1, 'Cash=5', 1]] });
  const card = listCards().find((c) => c.id === 'sales');
  assert.equal(card.build({ from: '2026-10-31', to: '2026-10-31' }, 'S1').value.replace(/[^\d.]/g, ''), '15.00');
});

test('4: one till sent its sales, the other did not – the End of days show the gap and which till', () => {
  feed('S1-T1', 'z', 'z1', { key: 'z1', z_id: 1, number: '1', date: D, total: 6.5, cash: 6.5 }, 'Shop 1, Till 1');
  feed('S1-T3', 'z', 'z9', { key: 'z9', z_id: 9, number: '9', date: D, total: 50, cash: 50 }, 'Shop 1, Till 3');
  L.processLink({ force: true });
  const h = SH.salesHistory({ from: '2026-10-01', to: '2026-10-31', shop: 'S1' });
  const d = h.days.find((x) => x.date === D);
  const g = d.shops.S1.gap;
  assert.ok(g, JSON.stringify(d));
  assert.equal(g.diff, 50);
  assert.deepEqual(g.missing, ['Shop 1, Till 3']);
  assert.ok(/nothing came from Shop 1, Till 3/.test(g.text), g.text);
  // within $1: no gap
  const d2 = SH.salesHistory({ from: '2026-10-28', to: '2026-10-28', shop: 'S1' }).days[0];
  assert.ok(!d2 || !d2.shops.S1.gap);
});

test('6: a stock take that sets uncounted products to 0 – a late sale is not taken off twice', () => {
  const flour = u(I.saveItem(owner, { code: 'FLR', name: 'Flour 1kg', cost: 1, price: 2 }));
  const salt = u(I.saveItem(owner, { code: 'SLT', name: 'Salt', cost: 1, price: 2 }));
  I.addMove({ itemUid: flour, shopCode: 'S2', date: '2026-10-20', type: 'receive', qty: 10, unitCost: 1, user: owner });
  I.addMove({ itemUid: salt, shopCode: 'S2', date: '2026-10-20', type: 'receive', qty: 4, unitCost: 1, user: owner });
  const c = I.startCount(owner, { shopCode: 'S2', date: '2026-10-25', timing: 'after_close' });
  I.enterCount(owner, c.uid, salt, 4);
  const r = I.submitCount(owner, c.uid, { restZero: true });
  if (r && r.recount && r.recount.length) I.submitCount(owner, c.uid, { restZero: true });
  I.postCount(owner, c.uid);
  assert.equal(I.stockOf(flour, 'S2'), 0, 'set to 0 by the stock take');
  assert.equal(db().get('SELECT counted FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [c.uid, flour]).counted, null, 'nobody counted it');
  I.putSale({ shopCode: 'S2', date: '2026-10-24', itemUid: flour, code: 'FLR', qty: 3, unitCost: 1, by: 'Aronium link', signed: true });
  assert.equal(I.stockOf(flour, 'S2'), 0, 'the count is the truth – the late sale is balanced');
});

test('7: a delivery or opening stock of a loose product goes onto its pack (qty × factor), nothing hidden on the loose one', () => {
  const pack = u(I.saveItem(owner, { code: 'MAG5', name: 'Maggi 5 pack', cost: 5, price: 7 }));
  const single = u(I.saveItem(owner, { code: 'MAG1', name: 'Maggi single', cost: 1, price: 1.5 }));
  LL.linkLoose(owner, single, pack, 5);
  I.addMove({ itemUid: single, shopCode: 'S1', date: '2026-10-30', type: 'receive', qty: 10, unitCost: 1, reason: 'Delivery', user: owner });
  I.addMove({ itemUid: single, shopCode: 'S1', date: '2026-10-30', type: 'opening', qty: 5, unitCost: 1, user: owner });
  assert.equal(I.stockOf(single, 'S1'), 0, 'nothing on the loose product');
  assert.equal(I.stockOf(pack, 'S1'), 3, '15 singles = 3 packs');
  const m = db().get("SELECT * FROM inv_moves WHERE item_uid = ? AND type = 'receive'", [pack]);
  assert.equal(m.unit_cost, 5, 'cost per pack');
  assert.ok(/loose Maggi single: 10 = 2 of a pack/.test(m.reason), m.reason);
});

done();
