// 1.0.0 cigarette tally at each shift: Aronium's packets sold (from the End of day products the till PC sends) against
// the cabinet count (opening + received − counted), the money put aside at cost (with VAT) into the cigarette fund,
// an End of day that comes in late, and the weekly cigarette invoice paid from the fund.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, deviceId } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as T from '../src/modules/till/service.js';
import * as CG from '../src/modules/till/cigTally.js';
import { alerts as tillAlerts } from '../src/modules/till/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const bh = u(I.saveItem(owner, { code: 'BH10', name: 'BH 10', group: 'Cigarettes', cost: 12, price: 16 }));
const pm = u(I.saveItem(owner, { code: 'PM1', name: 'Pall Mall Red', group: 'Cigarettes', cost: 10, price: 14 }));
u(I.saveItem(owner, { code: 'C1', name: 'Coke 1.5L', group: 'Drinks', cost: 2, price: 3.5 }));
db().run("UPDATE inv_items SET group_name = 'Cigarettes' WHERE uid IN (?,?)", [bh, pm]);
const till = u(T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 }));
let n = 0;
const feed = (kind, period, data, part = 0) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?, 'S1-T1', 'S1', 'Shop 1, Till 1', ?, ?, ?, 1, ?, ?, '2026-10-31T00:00:00Z', '1.0', '2026-10-31T00:00:00Z', 'x', 'synced')`, [`S1-T1|${kind}|${period}|${part}`, kind, period, part, JSON.stringify(data), `h${(n += 1)}`]);
const endOfDay = (num, date, items) => {
  feed('z', `z${num}`, { key: `z${num}`, z_id: num, number: String(num), date, total: 100, cash: 100 });
  if (items) feed('z_items', `z${num}`, { cols: ['code', 'qty'], rows: items });
};
const count = (shift, z) => T.saveTillCount(mgr, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-31', shift, cashierUid: sita.uid, openingFloat: 100, denominations: { n100: 2 },
  zCash: 100, zTotal: 100, zNumber: String(z), tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });

test('which products: the Aronium group (Cigarettes, Tobacco); cost with VAT by default', () => {
  assert.deepEqual(CG.cigItems().map((x) => x.name), ['BH 10', 'Pall Mall Red']);
  assert.equal(CG.packetCost(I.getItem(bh)), 13.5);
  assert.deepEqual(CG.cigShops(), ['S1'], 'by default the shops with tills');
  throws(() => CG.saveCigRules(sita, { groups: ['x'] }), /owner or admin/);
});

let t1;
test('first shift: Aronium sold 5 BH + 3 PM; the cabinet is counted; (5×12 + 3×10) × 1.125 = $101.25 put aside', () => {
  endOfDay(101, '2026-10-31', [['BH10', 5], ['PM1', 3], ['C1', 9]]);
  count('Morning', 101);
  const w = CG.workOutTally({ shopCode: 'S1', date: '2026-10-31', shift: 'Morning' });
  assert.equal(w.first, true);
  assert.equal(w.aroniumPackets, 8, 'coke is not a cigarette');
  assert.equal(w.suggested, 101.25);
  assert.ok(w.aronium.complete);
  throws(() => CG.saveTally(sita, { shopCode: 'S1', shift: 'Morning', closing: { [bh]: 20 } }), /Count every cigarette product.*Pall Mall/);
  const before = T.cashOnHand('S1').onHand;
  t1 = CG.saveTally(sita, { shopCode: 'S1', shift: 'Morning', closing: { [bh]: 20, [pm]: 10 } });
  assert.equal(t1.aside, 101.25);
  assert.equal(CG.fundOf('S1').balance, 101.25);
  assert.equal(Math.round((before - T.cashOnHand('S1').onHand) * 100) / 100, 101.25, 'out of the shop\'s cash, into the fund');
  throws(() => T.voidCashMove(owner, db().get("SELECT uid FROM cash_moves WHERE category = 'cig_fund'").uid, 'x'), /cigarette money/);
});

test('next shift: opening = last count, + 10 BH received; 1 BH more gone than Aronium sold – reason needed, flagged', () => {
  clock.override = new Date('2026-10-31T13:00:00');
  I.addMove({ itemUid: bh, shopCode: 'S1', date: '2026-10-31', type: 'receive', qty: 10, unitCost: 12, user: owner });
  endOfDay(102, '2026-10-31', [['BH10', 8], ['PM1', 2]]);
  clock.override = new Date('2026-10-31T15:00:00');
  count('Afternoon', 102);
  const w = CG.workOutTally({ shopCode: 'S1', date: '2026-10-31', shift: 'Afternoon', closing: { [bh]: 21, [pm]: 8 } });
  const l = w.lines.find((x) => x.itemUid === bh);
  assert.deepEqual([l.opening, l.moved, l.soldCount, l.soldAronium, l.diff], [20, 10, 9, 8, 1]);
  assert.equal(w.aroniumPackets, 10, 'End of day 101 is not counted again');
  throws(() => CG.saveTally(sita, { shopCode: 'S1', shift: 'Afternoon', closing: { [bh]: 21, [pm]: 8 } }), /differ from the Aronium sales.*BH 10 1 more gone/);
  const t2 = CG.saveTally(sita, { shopCode: 'S1', shift: 'Afternoon', closing: { [bh]: 21, [pm]: 8 }, reason: 'one packet missing – checking the camera' });
  assert.equal(t2.aside, 130.5, '(8×12 + 2×10) × 1.125');
  assert.equal(t2.diff_packets, 1);
  assert.equal(CG.fundOf('S1').balance, 231.75);
  assert.ok(tillAlerts(owner).some((a) => /cabinet differs from Aronium/.test(a.text)));
  assert.ok(db().get("SELECT 1 AS x FROM alert_log WHERE event = 'cig_diff'") || true);
});

test('a shift balanced but its tally not done: a reminder; the cashier can\'t change someone else\'s tally', () => {
  clock.override = new Date('2026-10-31T22:00:00');
  endOfDay(103, '2026-10-31', null); // the till PC has not sent its products yet (older Link) – waits
  count('Night', 103);
  assert.ok(tillAlerts(mgr).some((a) => /Cigarette tally not done: S1 Night/.test(a.text)));
  const ben = saveUser({ name: 'Ben', pin: '4545', role: 'staff', shopCode: 'S1' }, owner);
  throws(() => CG.saveTally(ben, { shopCode: 'S1', shift: 'Afternoon', closing: { [bh]: 21, [pm]: 8 }, reason: 'x' }), /done by Sita/);
});

let t3;
test('the End of day comes in late: the cabinet count is used first, then the app says how much more to put aside', () => {
  const w = CG.workOutTally({ shopCode: 'S1', date: '2026-10-31', shift: 'Night', closing: { [bh]: 17, [pm]: 8 } });
  assert.equal(w.aronium.complete, false);
  assert.equal(w.suggested, 54, 'cabinet: 4 BH × 13.50');
  throws(() => CG.saveTally(sita, { shopCode: 'S1', shift: 'Night', closing: { [bh]: 17, [pm]: 8 }, aside: 40 }), /should be \$54\.00\. Write why \$40\.00/);
  t3 = CG.saveTally(sita, { shopCode: 'S1', shift: 'Night', closing: { [bh]: 17, [pm]: 8 } });
  assert.equal(t3.aside, 54);
  feed('z_items', 'z103', { cols: ['code', 'qty'], rows: [['BH10', 4], ['PM1', 1]] });
  assert.equal(CG.attachLate(), 1);
  const t = CG.getTally(t3.uid);
  assert.equal(t.aronium_complete, 1);
  assert.equal(t.aronium_value, 65.25);
  assert.ok(tillAlerts(owner).some((a) => /to put right/.test(a.text)));
  assert.equal(CG.settleLate(sita, t3.uid), 11.25);
  assert.equal(CG.fundOf('S1').balance, 297);
  throws(() => CG.settleLate(sita, t3.uid), /right/);
});

test('the weekly cigarette invoice is paid from the fund; not more than it holds; the rest can go back to the shop', () => {
  const sup = AP.saveSupplier(owner, { name: 'Cig Wholesale', tin: '500099999', onAccount: true, termsDays: 7 });
  CG.saveCigRules(owner, { suppliers: [sup.uid] });
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'CW1', invoiceDate: '2026-10-25', total: 250, shopCode: 'S1' });
  const big = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'CW2', invoiceDate: '2026-10-26', total: 900, shopCode: 'S1' });
  AP.checkInvoice(owner, inv.uid); AP.checkInvoice(owner, big.uid);
  assert.equal(CG.cigInvoices().length, 2);
  throws(() => CG.payFromFund(owner, { shopCode: 'S1', invoiceUids: [inv.uid, big.uid] }), /not enough/);
  const cashBefore = T.cashOnHand('S1').onHand;
  CG.payFromFund(owner, { shopCode: 'S1', invoiceUids: [inv.uid], receivedBy: 'Driver' });
  assert.equal(CG.fundOf('S1').balance, 47);
  assert.equal(T.cashOnHand('S1').onHand, cashBefore, 'the shop\'s cash is not taken twice');
  assert.equal(AP.getInvoice(inv.uid).owing, 0);
  throws(() => CG.fundBack(sita, { shopCode: 'S1', amount: 10, reason: 'x' }), /manager/);
  CG.fundBack(mgr, { shopCode: 'S1', amount: 47, reason: 'paid CW2 by cheque' });
  assert.equal(CG.fundOf('S1').balance, 0);
});

test('a tally removed by a manager gives its money back to the shop', () => {
  const before = T.cashOnHand('S1').onHand;
  CG.voidTally(mgr, t3.uid, 'counted twice');
  assert.equal(Math.round((T.cashOnHand('S1').onHand - before) * 100) / 100, 65.25);
  void deviceId;
});
done();
