// 1.0.0 invoices: the receiver is asked about prices and how many; the verifier about the rest; answers and what the
// receiver kept teach the app the supplier's format; a delivery cannot be verified with its questions open.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as IR from '../src/modules/inventory/invoiceRead.js';
import * as CL from '../src/modules/inventory/invoiceClarify.js';
import * as V from '../src/modules/verify/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Asha Admin', pin: '7777', role: 'admin' }, owner);
const ravi = saveUser({ name: 'Ravi Receiver', pin: '2424', role: 'manager', shopCode: 'S1' }, owner);
const fmf = AP.saveSupplier(owner, { name: 'FMF Foods', tin: '50111222', onAccount: true });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const bis = u(I.saveItem(owner, { code: '2001', name: 'Cabin Biscuits 200g', cost: 4.0, price: 6 }));
const tea = u(I.saveItem(owner, { code: '2002', name: 'Lipton Tea 100', cost: 2.8, price: 4.5 }));
const TEXT = `FMF Foods
Document No ZX-55012
Crackers 200g (ours: biscuits) 4.50 12 54.00
Mystery Line 9 1.00 9.00
Grand Sum FJD 71.38
`;

test('receiver: counted less than the invoice, and a new price – asked, answers become the reason and claims', () => {
  const read = { lines: [{ itemUid: bis, qty: 12, unitCost: 4.5 }] };
  const qs = CL.receiverQuestions(read, [{ key: 'L1', itemUid: bis, name: 'Cabin Biscuits 200g', counted: 10, cost: 4.5, orderCost: 4.0 }]);
  assert.deepEqual(qs.map((q) => q.kind), ['qty', 'price']);
  assert.ok(/invoice says 12, you counted 10/.test(qs[0].text));
  const none = CL.receiverAnswers(qs, {});
  assert.equal(none.open.length, 2, 'not answered: must be answered before saving');
  const a = CL.receiverAnswers(qs, { ['qty:' + bis]: 'counted', ['price:' + bis]: 'claim' });
  assert.equal(a.open.length, 0);
  assert.ok(/10 came, invoice says 12/.test(a.reason) && /claim/.test(a.reason));
  assert.deepEqual(a.claims.map((c) => c.kind), ['short', 'price']);
  const b = CL.receiverAnswers(qs, { ['qty:' + bis]: 'invoice', ['price:' + bis]: 'old' });
  assert.equal(b.set.L1.counted, 12); assert.equal(b.set.L1.cost, 4.0);
  assert.equal(CL.receiverAnswers(qs, { ['qty:' + bis]: 'recount', ['price:' + bis]: 'accept' }).open.length, 1, 'count again: still open');
  assert.equal(CL.receiverQuestions(read, [{ key: 'L1', itemUid: bis, name: 'x', counted: 12, cost: 4.02, orderCost: 4.0 }]).length, 0, 'same count, price within the tolerance: nothing to ask');
});
let rc;
test('the delivery keeps the reading: To verify asks about the supplier format, unknown lines …', () => {
  const res = IR.readInvoiceText(TEXT, { supplierUid: fmf.uid });
  const readUid = IR.saveRead(ravi, { supplierUid: fmf.uid, engine: 'device', text: TEXT, result: res });
  rc = I.receiveDelivery(ravi, { supplierUid: fmf.uid, shopCode: 'S1', extra: [{ itemUid: bis, qty: 12, unitCost: 4.5 }], invoice: { invoiceNo: 'ZX-55012', total: 71.38, photos: ['file:///p.jpg'] }, photos: ['file:///p.jpg'],
    acceptReason: 'Receiver checked: new price accepted', readUid, claims: [{ text: 'Cabin Biscuits 200g: 2 short' }] });
  const c = CL.clarifications(rc.uid);
  const kinds = c.questions.map((q) => q.kind);
  assert.ok(kinds.includes('line'), JSON.stringify(kinds));
  // first invoice from FMF: either what the receiver kept already taught the format, or the verifier is asked
  assert.ok(kinds.includes('layout') || (IR.getLayout(fmf.uid) || {}).samples >= 1, JSON.stringify(kinds));
  assert.ok(c.open >= 2);
  const item = V.queue({ include: 'waiting' }).find((x) => x.key === `inv_receipts:${rc.uid}`);
  assert.ok(item && item.questions === c.open && /question/.test(item.flag), JSON.stringify(item && item.flag));
  assert.ok(/To claim from FMF Foods/.test(item.flag) || /To claim from FMF Foods/.test(db().get('SELECT match_note FROM inv_receipts WHERE uid = ?', [rc.uid]).match_note));
  throws(() => V.verify(admin, { table: 'inv_receipts', uid: rc.uid }), /Answer the \d questions? about the invoice first/);
});
test('the verifier answers: the unknown line is taught (next invoice reads it), then it can be verified', () => {
  const c = CL.clarifications(rc.uid);
  const line = c.questions.find((q) => q.kind === 'line' && /Mystery/.test(q.text));
  throws(() => CL.answerClarification(admin, rc.uid, line.id, 'nope'), /Choose the product/);
  const r1 = CL.answerClarification(admin, rc.uid, line.id, tea);
  assert.ok(r1.learned.some((x) => /Lipton Tea/.test(x)), JSON.stringify(r1.learned));
  for (const q of CL.clarifications(rc.uid).questions.filter((x) => !x.answer)) {
    if (q.kind === 'line') CL.answerClarification(admin, rc.uid, q.id, bis);
    else if (q.options) CL.answerClarification(admin, rc.uid, q.id, 'yes');
    else if (q.input === 'money') CL.answerClarification(admin, rc.uid, q.id, '71.38');
    else if (q.input === 'date') CL.answerClarification(admin, rc.uid, q.id, '2026-10-31');
    else CL.answerClarification(admin, rc.uid, q.id, 'ZX-55012');
  }
  assert.equal(CL.clarifications(rc.uid).open, 0);
  V.verify(admin, { table: 'inv_receipts', uid: rc.uid });
  const next = IR.readInvoiceText('FMF Foods\nDocument No ZX-60000\nMystery Line 2 1.00 2.00\nGrand Sum FJD 2.25\n', { supplierUid: fmf.uid });
  assert.equal(next.lines[0].itemUid, tea, 'learnt for next time');
  assert.equal(next.invoiceNo, 'ZX-60000');
});
test('what the receiver kept teaches the app by itself (invoice number read wrong)', () => {
  const T2 = 'FMF Foods\nDocument No ZX-70001\nCrackers 200g (ours: biscuits) 4.50 2 9.00\nGrand Sum FJD 10.13\n';
  const res = { ...IR.readInvoiceText(T2, { supplierUid: fmf.uid }), invoiceNo: 'WRONG' };
  const readUid = IR.saveRead(ravi, { supplierUid: fmf.uid, engine: 'device', text: T2, result: res });
  const learnt = CL.autoLearn(ravi, readUid, { invoiceNo: 'ZX-70001', total: 10.13 });
  assert.ok(learnt.some((x) => /invoice number/.test(x)), JSON.stringify(learnt));
  assert.deepEqual(CL.autoLearn(ravi, 'nope', {}), [], 'never throws');
});
done();
