// 1.0.0 supplier products from the old invoices (Google Drive, set-up pack): kept even before the Aronium products are
// in the app, linked by themselves when sure (barcode, code, same name, same name + size), "please confirm" when only
// close, never a different size; no doubles when loaded twice; carton size and the last cost on the product link.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as SC from '../src/modules/inventory/supplierCatalog.js';
import * as SP from '../src/services/setupPack.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);

const HEAD_S = ['Supplier', 'Other names', 'TIN', 'Phone', 'Days to pay', 'Paid by (cheque / cash / transfer)', 'Monthly budget', 'Weekly budget', 'Order days (Mon,Thu)', 'Delivery days', 'Viber group', 'Address', 'What they supply'];
const HEAD_P = ['Supplier', 'Their code', 'Name on their invoice', 'Unit', 'Carton / pack', 'Last cost excl. VAT', 'VAT %', 'Last bought', 'Barcode', 'Aronium code (fill in if known)', 'Aronium name', 'Main supplier (Y/N)'];
const pack = {
  Suppliers: [HEAD_S,
    ['Punja & Sons Pte Ltd', 'PUNJAS; PLD-Punjas Pte Limited', '50-99999-0-1', '000 0000', 0, 'cash', '', '', '', '', '', 'PO Box 125, Lautoka', 'Flour, rice, groceries'],
    ['Motibhai & Co', '', '50222333', '', 30, 'cheque', '', '', '', '', '', '', 'Groceries']],
  'Supplier products': [HEAD_P,
    ['Punja & Sons Pte Ltd', '10-02023-0004', 'PUNJAS BAKERS FLOUR 50KG', 'Bag', '50KG', 81.492, 0, '2026-09-23', '', '', '', 'Y'],
    ['PUNJAS', '10-02023-0002', 'PUNJAS FLOUR 10 X 2KG', 'Bale', '10 x 2kg', 25.1, 0, '2026-09-10', '', '', '', ''],
    ['Punja & Sons Pte Ltd', '10-99', 'PUNJAS RICE 10KG', 'Bag', '', 30, 0, '2026-09-11', '', '', '', ''],
    ['Motibhai & Co', 'M77', 'COCA COLA 1.5L 12X', 'Ctn', '12x1.5L', 2.1, 12.5, '2026-09-05', '5449000000996', '', '', ''],
    ['Motibhai & Co', 'M78', 'MAGGI NOODLES CHKN 5PK', 'Ctn', 'CTN/24', 4.4, 12.5, '2026-09-05', '', '', '', ''],
    ['Nobody Ltd', 'X1', 'Something', '', '', 1, '', '', '', '', '', ''],
    ['Motibhai & Co', 'M79', 'TOOTHPICKS', 'Each', '', 'abc', '', '', '', '', '', '']],
};

test('carton sizes and sizes are read from what the invoice prints', () => {
  assert.equal(SC.packQty('24x500ml'), 24);
  assert.equal(SC.packQty('12 X 1L'), 12);
  assert.equal(SC.packQty('CTN/24'), 24);
  assert.equal(SC.packQty("48'S"), 48);
  assert.equal(SC.packQty('50KG'), null, 'a weight is not a count');
  assert.equal(SC.packQty('2L'), null);
  assert.equal(SC.sizeOf('Punjas Flour 2kg'), 2000);
  assert.equal(SC.sizeOf('Coke 1.5L'), 1500);
  assert.ok(SC.nameScore('PUNJAS FLOUR 2KG', 'Punjas Flour 2kg') >= 0.95);
  assert.ok(SC.nameScore('PUNJAS BAKERS FLOUR 50KG', 'Punjas Normal Flour 2kg') < 0.45, 'a different size is a different product');
});

let pv;
test('before Aronium has sent the products: suppliers go in, every product line is kept and waits', () => {
  pv = SP.readPack(pack);
  assert.equal(pv.counts.suppliers.new, 2);
  assert.equal(pv.counts.products.wait, 5, 'not in the app yet = waits, not a problem');
  assert.equal(pv.counts.products.problems, 2, 'unknown supplier, cost not a number');
  assert.ok(pv.products.find((r) => r.name === 'PUNJAS FLOUR 10 X 2KG').supplierName === 'Punja & Sons Pte Ltd', 'their other name on the invoice');
  throws(() => SP.applyPack(sita, pv), /owner or admin/);
  const r = SP.applyPack(owner, pv);
  assert.equal(r.suppliers, 2);
  assert.equal(r.waiting, 5);
  assert.equal(r.products, 0);
  const pj = AP.listSuppliers({ q: 'punja' })[0];
  assert.equal(pj.tin, '509999901');
  assert.equal(pj.terms_days, 0);
  assert.equal(pj.pay_method, 'cash');
  assert.ok(/PO Box 125/.test(pj.notes) && /PLD-Punjas/.test(pj.notes));
  assert.equal(pj.category, 'Flour, rice, groceries');
  assert.equal(SC.counts().waiting, 5);
});

let flour2, bakers, coke, maggi, rice5;
test('the Aronium products arrive: sure ones link by themselves, close ones ask, a different size never links', () => {
  flour2 = u(I.saveItem(owner, { code: '1001', name: 'Punjas Flour 2kg', cost: 2.4, price: 3.5 }));
  bakers = u(I.saveItem(owner, { code: '1002', name: 'Punjas Bakers Flour 50kg', cost: 80, price: 95 }));
  coke = u(I.saveItem(owner, { code: '1003', name: 'Coke 1.5L', cost: 2.1, price: 3.5, barcode: '5449000000996' }));
  maggi = u(I.saveItem(owner, { code: '1004', name: 'Maggi Chicken Noodles 5 pack', cost: 4.2, price: 5.5 }));
  rice5 = u(I.saveItem(owner, { code: '1005', name: 'Punjas Rice 5kg', cost: 14, price: 18 }));
  const m = SC.matchCatalog();
  assert.equal(m.linked, 3, 'bakers flour (same name + size), flour 2kg (name + size), coke (barcode)');
  const link = I.itemSuppliers(bakers)[0];
  assert.equal(link.supplier_code, '10-02023-0004');
  assert.equal(link.last_cost, 81.492);
  assert.equal(link.last_date, '2026-09-23');
  assert.equal(I.getItem(bakers).supplier_uid, link.supplier_uid, 'marked main supplier');
  assert.equal(I.getItem(coke).pack_size, 12, 'carton size set from the invoice');
  assert.equal(I.getItem(flour2).pack_size, 10, 'a bale of 10 x 2kg');
  const chk = SC.listLines({ status: 'check' });
  assert.deepEqual(chk.map((x) => x.name), ['MAGGI NOODLES CHKN 5PK'], 'close name: asked, not linked');
  assert.equal(chk[0].guess_item_uid, maggi);
  const w = SC.listLines({ status: 'waiting' }).map((x) => x.name);
  assert.deepEqual(w, ['PUNJAS RICE 10KG'], 'rice 10kg is not the 5kg');
  assert.ok(invAlerts(owner).some((a) => /1 supplier product to confirm/.test(a.text)));
  assert.ok(!invAlerts(sita).some((a) => /supplier product/.test(a.text)));
});

test('confirm, pick another, not ours; only the owner / admin / inventory manager', () => {
  const chk = SC.listLines({ status: 'check' })[0];
  throws(() => SC.confirmLine(sita, chk.uid), /inventory manager/);
  SC.confirmLine(owner, chk.uid);
  assert.equal(I.getItem(maggi).pack_size, 24);
  assert.equal(I.itemSuppliers(maggi)[0].supplier_code, 'M78');
  const rice = SC.listLines({ status: 'waiting' })[0];
  throws(() => SC.confirmLine(owner, rice.uid), /Choose the product/);
  SC.notOurs(owner, rice.uid);
  assert.equal(SC.counts().not_ours, 1);
  SC.matchCatalog();
  assert.equal(SC.counts().not_ours, 1, 'never asked again');
  SC.reopenLine(owner, rice.uid);
  SC.confirmLine(owner, rice.uid, rice5);
  assert.equal(SC.listLines({ status: 'linked' }).length, 5);
});

test('the same pack again: no doubles; an older invoice never replaces a newer cost; newer one updates it', () => {
  const before = SC.counts().all;
  const again = SP.readPack(pack);
  assert.equal(again.counts.suppliers.change, 2);
  SP.applyPack(owner, again);
  assert.equal(SC.counts().all, before);
  assert.equal(AP.listSuppliers({ q: 'punja' }).length, 1);
  const old = { ...pack, 'Supplier products': [HEAD_P, ['Punja & Sons Pte Ltd', '10-02023-0004', 'PUNJAS BAKERS FLOUR 50KG', 'Bag', '50KG', 70, 0, '2026-08-01', '', '', '', '']] };
  SP.applyPack(owner, SP.readPack(old));
  assert.equal(I.itemSuppliers(bakers)[0].last_cost, 81.492);
  const nw = { ...pack, 'Supplier products': [HEAD_P, ['Punja & Sons Pte Ltd', '10-02023-0004', 'PUNJAS BAKERS FLOUR 50KG', 'Bag', '50KG', 84, 0, '2026-10-02', '', '', '', '']] };
  SP.applyPack(owner, SP.readPack(nw));
  assert.equal(I.itemSuppliers(bakers)[0].last_cost, 84);
  assert.equal(I.itemSuppliers(bakers)[0].last_date, '2026-10-02');
});

test('a supplier product already known by its code links at once on a later pack', () => {
  const p2 = { 'Supplier products': [HEAD_P, ['Motibhai & Co', 'M78', 'MAGGI 5PK CHICKEN (new wording)', 'Ctn', 'CTN/24', 4.5, 12.5, '2026-10-03', '', '', '', '']] };
  const r = SP.applyPack(owner, SP.readPack(p2));
  assert.equal(r.products, 1);
  assert.equal(I.itemSuppliers(maggi)[0].last_cost, 4.5);
});

test('many products: matching stays quick', () => {
  for (let i = 0; i < 1500; i += 1) db().run("INSERT INTO inv_items (uid, code, name, unit, cost, price, active, updated_at) VALUES (?,?,?,?,0,0,1,'2026-10-31')", [`T${i}`, `T${i}`, `Test product ${i} ${i % 7 ? 'box' : '500g'}`, 'each']);
  const rows = [HEAD_P];
  for (let i = 0; i < 400; i += 1) rows.push(['Motibhai & Co', `Z${i}`, `ZZ ITEM ${i} 250G`, 'Each', '', 1, 12.5, '2026-09-01', '', '', '', '']);
  const t0 = Date.now();
  const p3 = SP.readPack({ 'Supplier products': rows });
  const r = SP.applyPack(owner, p3);
  const ms = Date.now() - t0;
  assert.equal(r.waiting + r.toConfirm, 400);
  assert.ok(ms < 8000, `${ms} ms`);
  const t1 = Date.now(); SC.matchCatalog(); assert.ok(Date.now() - t1 < 5000);
});
done();
