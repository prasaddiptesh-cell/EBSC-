// 1.0.0 packs also sold loose (Maggi 5 pack and one Maggi): loose sales come off the pack's stock as its share; the
// loose one is never counted on its own; the pack's count has a "loose" box; wrong links refused.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as LL from '../src/modules/inventory/looseLinks.js';
import * as PT from '../src/modules/inventory/packTerms.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T21:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const pack = u(I.saveItem(owner, { code: 'MG5', name: 'Maggi 5 pack', cost: 4, price: 5.5, group: 'Noodles' }));
const one = u(I.saveItem(owner, { code: 'MG1', name: 'Maggi single', cost: 0.8, price: 1.2, group: 'Noodles' }));
I.addMove({ itemUid: pack, shopCode: 'S1', date: '2026-10-30', type: 'opening', qty: 10, unitCost: 4, user: owner });

test('link: only managers, sensible numbers, no loops', () => {
  throws(() => LL.linkLoose(sita, one, pack, 5), /manager/);
  throws(() => LL.linkLoose(owner, one, pack, 1), /2 or more/);
  throws(() => LL.linkLoose(owner, one, pack, 2.5), /whole number/);
  throws(() => LL.linkLoose(owner, one, one, 5), /two different/);
  LL.linkLoose(owner, one, pack, 5);
  throws(() => LL.linkLoose(owner, pack, one, 5), /itself sold loose|already has loose/);
  assert.deepEqual(LL.looseOf(one), { parent: pack, per: 5, factor: 0.2 });
});
test('3 loose Maggi sold = 0.6 of a pack off the pack\'s stock; the loose one has no stock of its own', () => {
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: one, code: 'MG1', qty: 3, unitCost: 0.8 });
  assert.equal(I.stockOf(pack, 'S1'), 9.4);
  assert.equal(I.stockOf(one, 'S1'), 0);
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: one, code: 'MG1', qty: 5, unitCost: 0.8 }); // the day's total grew
  assert.equal(I.stockOf(pack, 'S1'), 9, 'the day\'s 5 loose = 1 pack');
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: pack, code: 'MG5', qty: 2, unitCost: 4 });
  assert.equal(I.stockOf(pack, 'S1'), 7);
});
test('stock take: the loose one is not on the list; the pack\'s "loose" box counts open ones', () => {
  const c = I.startCount(owner, { shopCode: 'S1', kind: 'initial', date: '2026-10-31', timing: 'after_close' });
  assert.ok(!I.getCount(c.uid).lines.some((l) => l.item_uid === one));
  const t = PT.termsFor(pack).find((x) => x.word === 'loose');
  assert.ok(t && t.qty === 0.2 && /5 = 1/.test(t.label));
  assert.equal(PT.readQty(pack, '6 3 loose').qty, 6.6);
  I.enterCount(sita, c.uid, pack, PT.readQty(pack, '6 3 loose').qty);
  assert.equal(I.getCount(c.uid).lines.find((l) => l.item_uid === pack).counted, 6.6);
});
test('unlinked: loose sales come off its own stock again', () => {
  LL.unlinkLoose(owner, one);
  I.putSale({ shopCode: 'S1', date: '2026-11-01', itemUid: one, code: 'MG1', qty: 2, unitCost: 0.8 });
  assert.equal(I.stockOf(one, 'S1'), -2);
});
done();
