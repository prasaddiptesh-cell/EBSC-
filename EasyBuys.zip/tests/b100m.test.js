// 1.0.0 build 3 money loopholes: the Z figures must add up, the float is the real one, cash checked against the till
// PC's End of day (also when the totals agree), the till PC's figures win over typed ones, cash records undone only by
// the owner with a reason, safe differences accepted by someone else, M-PAiSA fix sign, supplier bank details guarded,
// nobody approves or decides their own shift, a paid shortage is not charged twice.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as T from '../src/modules/till/service.js';
import * as E from '../src/modules/till/eod.js';
import * as W from '../src/modules/bank/wallets.js';
import * as RC from '../src/modules/till/recount.js';
import * as SH from '../src/modules/till/shifts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T15:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const till = u(T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 }));
const base = (x) => ({ shopCode: 'S1', tillUid: till, shiftDate: '2026-10-31', shift: 'Morning', cashierUid: sita.uid, openingFloat: 100, denominations: { n100: 6 },
  zCash: 500, zTotal: 500, tenders: [], payouts: [], adjustments: [], floatKept: 100, ...x });
const P = { photos: ['file:///z.jpg'] };

test('the Z must add up: cash typed lower and the rest under another payment type needs a reason and is flagged', () => {
  throws(() => T.saveTillCount(mgr, base({ zCash: 300, zTotal: 800, denominations: { n100: 4 }, tenders: [] }), P), /does not add up.*\$500\.00/);
});
test('the float must be what the till had', () => {
  throws(() => T.saveTillCount(mgr, base({ openingFloat: 0, denominations: { n100: 5 } }), P), /float at the start should be \$100\.00/);
});
test('the till PC\'s cash figure: typed cash lower than the till PC says needs a reason', () => {
  E.putLinkedEod({ uid: 'EOD-S1-T1-z7', shopCode: 'S1', tillName: 'Shop 1, Till 1', date: '2026-10-31', zNumber: '7', total: 800, cash: 700, other: 100 });
  throws(() => T.saveTillCount(mgr, base({ zNumber: '7', zCash: 400, zTotal: 800, tenders: [{ method: 'Vouchers', amount: 400 }], denominations: { n100: 5 } }), P), /CASH sales were \$700\.00/);
});
test('the totals agree but the cash does not: the End of day shows a difference', () => {
  const c = T.saveTillCount(mgr, base({ zNumber: '7', zCash: 400, zTotal: 800, tenders: [{ method: 'Vouchers', amount: 400 }], denominations: { n100: 5 }, reason: 'testing the check' }), P);
  const e = E.getEod('EOD-S1-T1-z7');
  assert.equal(e.state, 'difference');
  assert.equal(e.diff, 300);
  void c;
});
test('a typed End of day is replaced by the till PC\'s figures when they differ', () => {
  E.addEod(mgr, { shopCode: 'S1', date: '2026-10-31', zNumber: '8', total: 200, tillName: 'Till 1' });
  E.putLinkedEod({ uid: 'EOD-S1-T1-z8', shopCode: 'S1', tillName: 'Shop 1, Till 1', date: '2026-10-31', zNumber: '8', total: 260, cash: 260 });
  const e = db().get("SELECT * FROM aronium_eods WHERE z_number = '8'");
  assert.equal(e.total, 260);
  assert.ok(/Typed \$200\.00/.test(e.note), e.note);
});
test('cash records: only the owner / admin undoes one, with a reason; never one that belongs to another record', () => {
  T.recordCash(mgr, { shopCode: 'S1', type: 'petty_in', amount: 50, date: '2026-10-31', note: 'top-up' });
  const m = db().get("SELECT * FROM cash_moves WHERE type = 'petty_in'");
  throws(() => T.voidCashMove(mgr, m.uid, 'mistake typed'), /owner or admin/);
  throws(() => T.voidCashMove(owner, m.uid, 'x'), /Write why/);
  T.voidCashMove(owner, m.uid, 'typed twice');
  const ref = T.addCashMove({ shopCode: 'S1', date: '2026-10-31', type: 'adjust_in', amount: 20, refUid: 'TS-1', note: 'Till shortage repaid' });
  throws(() => T.voidCashMove(owner, ref, 'pocketed'), /belongs to another record/);
});
test('a safe difference is accepted by a manager who did not count it', () => {
  const s = T.saveSafeCount(mgr, { shopCode: 'S1', date: '2026-10-31', counted: 0, note: 'empty?' });
  throws(() => T.bookSafeDifference(sita, s.uid, 'whatever'), /manager/);
  throws(() => T.bookSafeDifference(mgr, s.uid, 'miscount'), /Someone other than/);
  T.bookSafeDifference(owner, s.uid, 'checked by owner');
});
test('M-PAiSA wrong button: "rung as M-PAiSA, paid in cash" takes it OFF the wallet', () => {
  const w = W.saveWallet(owner, { name: 'M-PAiSA Shop 1', provider: 'M-PAiSA', shopCode: 'S1', openingDate: '2026-10-01' });
  db().run(`INSERT INTO till_counts (uid, shop_code, till_uid, till_name, shift_date, shift, cashier_uid, cashier_name, counted_by_uid, counted_by_name, counted_at, opening_float, cash_counted, float_kept, z_cash, tenders, adjustments, status, updated_at)
    VALUES ('TC-MP', 'S1', ?, 'Till 1', '2026-10-30', 'Night', ?, 'Sita', ?, 'Mgr', '2026-10-30 22:00', 100, 100, 100, 0, ?, ?, 'approved', '2026-10-30')`,
  [till, sita.uid, mgr.uid, JSON.stringify([{ method: 'M-PAiSA', amount: 60 }]), JSON.stringify([{ kind: 'tender_fix', to: 'Cash', amount: 15, reason: 'Rung up as M-PAiSA, paid in cash' }])]);
  const x = W.walletSales(w.uid, '2026-10-30', '2026-10-30').find((y) => y.countUid === 'TC-MP');
  assert.equal(x.amount, 45, '60 on the Z, 15 of it was really cash');
});
test('supplier bank details: changed only by the owner / admin / payments, and the owner is told', () => {
  const s = AP.saveSupplier(owner, { name: 'Cig Co', bankName: 'BSP', bankAccount: '111' });
  throws(() => AP.saveSupplier(sita, { uid: s.uid, name: 'Cig Co', bankName: 'BSP', bankAccount: '999' }), /bank details/);
  AP.saveSupplier(sita, { uid: s.uid, name: 'Cig Co', bankName: 'BSP', bankAccount: '111', phone: '123' });
  AP.saveSupplier(owner, { uid: s.uid, name: 'Cig Co', bankName: 'BSP', bankAccount: '999' });
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE '%BANK DETAILS%'"));
});
test('nobody approves a count of their own shift, or decides their own till over', () => {
  const sup = saveUser({ name: 'Sup', pin: '7777', role: 'supervisor', shopCode: 'S1' }, owner);
  const c = T.saveTillCount(mgr, base({ shift: 'Afternoon', cashierUid: sup.uid, openingFloat: 100, denominations: { n100: 7 }, zCash: 500, zTotal: 500, reason: 'over' }), P);
  throws(() => T.approveTillCount(sup, c.uid, {}), /your own shift/);
  const sp = db().get('SELECT * FROM till_surplus WHERE count_uid = ?', [c.uid]);
  assert.ok(sp, 'a till over');
  db().run('UPDATE till_surplus SET user_uid = ? WHERE uid = ?', [mgr.uid, sp.uid]); // the manager's own till over
  throws(() => RC.decideSurplus(mgr, sp.uid, { action: 'returned', note: 'customer' }), /your own till/);
});
test('a shortage paid back in cash stays paid when the count is opened again', () => {
  db().run("INSERT INTO till_shortages (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, paid_now, created_at, updated_at) VALUES ('TS-P', 'TC-X', 'S1', '2026-10-31', ?, 'Sita', 20, 'paid', 20, '2026-10-31', '2026-10-31')", [sita.uid]);
  SH.cancelShortage(owner, 'TC-X', 'reopened');
  assert.equal(db().get("SELECT status FROM till_shortages WHERE uid = 'TS-P'").status, 'paid');
});
done();
