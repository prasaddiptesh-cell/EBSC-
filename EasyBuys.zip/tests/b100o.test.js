// 1.0.0 owed by suppliers: invoiced but not delivered (cheque may already be paid), short, damaged on the truck or
// found damaged later when opening the cartons, extra lines / substitutes on the invoice; settled when the goods come,
// a credit note comes, or written off; the supplier is told and the managers are notified.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as CL from '../src/modules/inventory/invoiceClarify.js';
import * as OW from '../src/modules/inventory/supplierOwed.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const fmf = AP.saveSupplier(owner, { name: 'FMF Foods', tin: '50111222', onAccount: true });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const bis = u(I.saveItem(owner, { code: '2001', name: 'Cabin Biscuits 200g', cost: 4.0, price: 6 }));
const tea = u(I.saveItem(owner, { code: '2002', name: 'Lipton Tea 100', cost: 2.8, price: 4.5 }));
const jam = u(I.saveItem(owner, { code: '2003', name: 'Rosella Jam', cost: 3.0, price: 5 }));
db().run("UPDATE inv_items SET vat_type = 'zero' WHERE uid IN (?,?,?)", [bis, tea, jam]); // simple sums

test('invoice has more than the order / came instead of an ordered product / not delivered – asked, never guessed', () => {
  const read = { lines: [{ itemUid: bis, qty: 10, unitCost: 4 }, { itemUid: tea, qty: 5, unitCost: 2.8 }] };
  const qs = CL.receiverQuestions(read, [{ key: 'L1', itemUid: bis, name: 'Cabin Biscuits 200g', counted: 10, cost: 4, orderCost: 4 }], { supplierUid: fmf.uid, missing: [{ itemUid: jam, name: 'Rosella Jam' }] });
  const ex = qs.find((q) => q.kind === 'extra');
  assert.ok(ex && /not in this delivery/.test(ex.text));
  assert.deepEqual(ex.options.map((o) => o.value), ['came', `instead:${jam}`, 'owed', 'damaged', 'wrong']);
  assert.equal(CL.receiverAnswers(qs, { [ex.id]: 'came' }).add[0].qty, 5);
  assert.ok(/came instead of Rosella Jam/.test(CL.receiverAnswers(qs, { [ex.id]: `instead:${jam}` }).reason));
  const owed = CL.receiverAnswers(qs, { [ex.id]: 'owed' }).owed[0];
  assert.deepEqual([owed.itemUid, owed.qty, owed.reason], [tea, 5, 'not_delivered']);
});
let rc1;
test('the invoice is paid in full while the tea is still to come: owed until it arrives', () => {
  rc1 = I.receiveDelivery(mgr, { supplierUid: fmf.uid, shopCode: 'S1', extra: [{ itemUid: bis, qty: 10, unitCost: 4 }], photos: ['file:///p.jpg'],
    invoice: { invoiceNo: 'ZX-1', total: 54, photos: ['file:///p.jpg'] }, owed: [{ itemUid: tea, name: 'Lipton Tea 100', qty: 5, unitCost: 2.8, reason: 'not_delivered' }],
    acceptReason: 'Receiver checked: tea not delivered' });
  assert.equal(rc1.flags.length, 0, 'invoice 54 = goods 40 + owed 14: nothing odd');
  const o = OW.listOwed({ supplierUid: fmf.uid });
  assert.equal(o.length, 1); assert.equal(o[0].invoice_no, 'ZX-1'); assert.equal(o[0].leftValue, 14);
  assert.equal(I.stockOf(tea, 'S1'), 0, 'not in stock – it did not come');
  assert.equal(OW.owedBySupplier()[0].value, 14);
});
test('the tea comes on the next delivery: "are these the owed ones?" – yes settles it', () => {
  const qs = CL.receiverQuestions({ lines: [] }, [{ key: 'L1', itemUid: tea, name: 'Lipton Tea 100', counted: 5, cost: 2.8, orderCost: null }], { supplierUid: fmf.uid, supplierName: 'FMF Foods' });
  const q = qs.find((x) => x.kind === 'owed');
  assert.ok(q && /FMF Foods owes 5 Lipton Tea/.test(q.text), JSON.stringify(qs));
  const a = CL.receiverAnswers(qs, { [q.id]: 'owed' });
  I.receiveDelivery(mgr, { supplierUid: fmf.uid, shopCode: 'S1', extra: [{ itemUid: tea, qty: 5, unitCost: 2.8 }], photos: ['file:///p.jpg'], settle: a.settle, acceptReason: a.reason });
  assert.equal(OW.listOwed({ supplierUid: fmf.uid }).length, 0);
  assert.equal(OW.listOwed({ supplierUid: fmf.uid, status: 'all' })[0].status, 'received');
  assert.equal(I.stockOf(tea, 'S1'), 5);
});
test('found damaged when opening the cartons: off the stock, back on the invoice, everyone told', () => {
  throws(() => OW.reportDamaged(mgr, { receiptUid: rc1.uid, itemUid: bis, qty: 2 }), /photo/);
  throws(() => OW.reportDamaged(mgr, { receiptUid: rc1.uid, itemUid: bis, qty: 11, photos: ['file:///d.jpg'] }), /Only 10/);
  throws(() => OW.reportDamaged(mgr, { receiptUid: rc1.uid, itemUid: jam, qty: 1, photos: ['file:///d.jpg'] }), /not on this delivery/);
  const before = I.stockOf(bis, 'S1');
  const o = OW.reportDamaged(mgr, { receiptUid: rc1.uid, itemUid: bis, qty: 3, note: 'crushed', photos: ['file:///d.jpg'] });
  assert.equal(I.stockOf(bis, 'S1'), before - 3, 'kept aside – not sold');
  assert.deepEqual([o.reason, o.invoice_no, o.qty, o.value], ['damaged', 'ZX-1', 3, 12]);
  throws(() => OW.reportDamaged(mgr, { receiptUid: rc1.uid, itemUid: bis, qty: 8, photos: ['file:///d.jpg'] }), /3 already reported damaged/);
  const al = invAlerts(mgr).find((a) => /Damaged: Cabin Biscuits/.test(a.text));
  assert.ok(al && al.notify, 'a notification');
  const m = OW.supplierMessage(fmf.uid);
  assert.ok(/Cabin Biscuits 200g × 3 – came damaged \(invoice ZX-1\)/.test(m.text), m.text);
  OW.markTold(mgr, m.uids);
  assert.ok(OW.getOwed(o.uid).told_at);
});
test('settled in parts: 2 replaced, then a credit note for the last one; write-off only by a manager', () => {
  const o = OW.listOwed({ supplierUid: fmf.uid })[0];
  throws(() => OW.settleOwed(sita, o.uid, { how: 'written_off', note: 'gone' }), /manager/);
  OW.settleOwed(sita, o.uid, { how: 'received', qty: 2 });
  assert.equal(OW.getOwed(o.uid).left, 1); assert.equal(OW.getOwed(o.uid).status, 'open');
  throws(() => OW.settleOwed(sita, o.uid, { how: 'credited', qty: 5 }), /up to 1/);
  OW.settleOwed(sita, o.uid, { how: 'credited', note: 'CN-77' });
  assert.equal(OW.getOwed(o.uid).status, 'credited');
  assert.equal(OW.owedBySupplier().length, 0);
});
test('overcharged: the difference is owed (claim)', () => {
  const qs = CL.receiverQuestions({ lines: [{ itemUid: jam, qty: 4, unitCost: 3.5 }] }, [{ key: 'L1', itemUid: jam, name: 'Rosella Jam', counted: 4, cost: 3.5, orderCost: 3.0 }], {});
  const p = qs.find((q) => q.kind === 'price');
  const a = CL.receiverAnswers(qs, { [p.id]: 'claim' });
  assert.deepEqual([a.owed[0].reason, a.owed[0].qty, a.owed[0].unitCost], ['price', 4, 0.5]);
});
done();
