// 1.0.0 the shop's own pack words, learnt as they are taught: "sleeve" of BH 10 = 10 packets, for one product or a
// whole group; short forms understood; "2 sleeves 3" read into singles; an unknown word asks to be taught.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as PT from '../src/modules/inventory/packTerms.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T21:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const bh = u(I.saveItem(owner, { code: 'BH10', name: 'BH 10', cost: 8, price: 10, group: 'Cigarettes' }));
const pm = u(I.saveItem(owner, { code: 'PM20', name: 'Pall Mall 20s', cost: 15, price: 19, group: 'Cigarettes', packSize: 50 }));
const coke = u(I.saveItem(owner, { code: 'COKE', name: 'Coke 330ml', cost: 1, price: 2, group: 'Drinks' }));
db().run("UPDATE inv_items SET group_name = 'Cigarettes' WHERE uid IN (?, ?)", [bh, pm]);
db().run("UPDATE inv_items SET group_name = 'Drinks' WHERE uid = ?", [coke]);

test('teach "sleeve = 10" for BH 10: counted as 10 packets from then on', () => {
  throws(() => PT.readQty(bh, '2 sleeves'), /How many singles of BH 10 are in one "sleeves"/);
  PT.teachTerm(sita, bh, { word: 'Sleeve', qty: '10' });
  assert.equal(PT.readQty(bh, '2 sleeves 3').qty, 23);
  assert.equal(PT.readQty(bh, '2 slv + 3').qty, 23, 'short form');
  assert.equal(PT.readQty(bh, '3slv').qty, 30, 'no space');
  assert.equal(PT.readQty(bh, '1 dozen').qty, 12, 'a dozen is always 12');
  assert.equal(PT.readQty(bh, '4 pkts').qty, 4, 'packets are singles');
  assert.equal(PT.describeQty(bh, 34), '3 sleeves + 4');
  assert.ok(!PT.termsFor(pm).some((t) => t.word === 'sleeve'), 'only for BH 10');
});
test('for the whole group at once; a product\'s own number wins; carton from the pack size', () => {
  PT.teachTerm(owner, pm, { word: 'sleeve', qty: 10, forGroup: true });
  assert.equal(PT.readQty(pm, '1 ctn 2 sleeves 5').qty, 75, 'carton = pack size 50, sleeve = 10 from the group');
  PT.teachTerm(owner, bh, { word: 'sleeve', qty: 20 });
  assert.equal(PT.readQty(bh, '1 sleeve').qty, 20, 'its own number wins over the group');
  assert.equal(PT.termsFor(pm)[0].word, 'carton');
});
test('a new word is learnt (crate of Coke = 24), plural understood next time', () => {
  throws(() => PT.readQty(coke, '2 crates'), /Teach it once/);
  PT.teachTerm(sita, coke, { word: 'flat', qty: 24 });
  assert.equal(PT.readQty(coke, '2 flats 1').qty, 49);
  assert.ok(PT.allTerms().words.includes('flat'));
});
test('mistakes are refused, never guessed', () => {
  throws(() => PT.teachTerm(sita, bh, { word: 'sleeve', qty: 'ten' }), /How many singles/);
  throws(() => PT.teachTerm(sita, bh, { word: 'sleeve', qty: 1 }), /2 or more/);
  throws(() => PT.teachTerm(sita, bh, { word: 'dozen', qty: 10 }), /always 12/);
  throws(() => PT.teachTerm(sita, bh, { word: '123', qty: 10 }), /letters/);
  throws(() => PT.readQty(bh, 'lots'), /not a number/);
  throws(() => PT.readQty(bh, '2 bales'), /Teach it once/);
  assert.equal(PT.describeQty(bh, 0), '0');
});
test('counting: sleeves + packets go in as packets', () => {
  const c = I.startCount(owner, { shopCode: 'S1', kind: 'initial', date: '2026-10-31', timing: 'after_close' });
  const n = PT.readQty(bh, '3 sleeves 4').qty; // 3 × 20 (taught for BH 10) + 4
  I.enterCount(sita, c.uid, bh, n);
  assert.equal(I.getCount(c.uid).lines.find((l) => l.item_uid === bh).counted, 64);
});
done();
