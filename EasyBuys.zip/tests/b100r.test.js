// 1.0.0 repacking: bought in bulk, packed in the shop, sold in packs – stock and cost follow, short pack-ups flagged.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as RP from '../src/modules/inventory/repack.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const bag = u(I.saveItem(owner, { code: 'RB25', name: 'Rice 25kg bag', cost: 50, price: 70 }));
const pkt = u(I.saveItem(owner, { code: 'RP1', name: 'Rice 1kg packet', cost: 0, price: 3.2 }));
I.addMove({ itemUid: bag, shopCode: 'S1', date: '2026-10-30', type: 'receive', qty: 4, unitCost: 50, user: owner });

test('set up once: 1 bag makes 25 packets, + 10c a bag; only managers', () => {
  throws(() => RP.savePair(sita, { fromUid: bag, toUid: pkt, per: 25 }), /manager/);
  throws(() => RP.savePair(mgr, { fromUid: bag, toUid: bag, per: 25 }), /two different/);
  RP.savePair(mgr, { fromUid: bag, toUid: pkt, per: 25, packCost: 0.1 });
  assert.equal(RP.pairOf(bag, pkt).per, 25);
});
test('packing 1 bag into 25 packets: bag −1, packets +25, packet cost = 50/25 + 0.10', () => {
  const r = RP.repack(sita, { shopCode: 'S1', fromUid: bag, toUid: pkt, used: 1, made: 25 });
  assert.equal(I.stockOf(bag, 'S1'), 3); assert.equal(I.stockOf(pkt, 'S1'), 25);
  assert.equal(r.unitCost, 2.1); assert.equal(I.getItem(pkt).cost, 2.1);
  assert.equal(r.short, 0);
});
test('fewer packs than usual is flagged for the managers; more than in stock is refused', () => {
  const r = RP.repack(sita, { shopCode: 'S1', fromUid: bag, toUid: pkt, used: 2, made: 46 });
  assert.equal(r.short, 4);
  assert.ok(invAlerts(mgr).some((a) => /made fewer packs than usual/.test(a.text)));
  throws(() => RP.repack(sita, { shopCode: 'S1', fromUid: bag, toUid: pkt, used: 5, made: 125 }), /Only 1/);
  throws(() => RP.repack(sita, { shopCode: 'S1', fromUid: bag, toUid: pkt, used: 1, made: 0 }), /How many packs/);
  assert.equal(I.MOVE_LABEL.repack_in, 'Packed in the shop');
});
done();
