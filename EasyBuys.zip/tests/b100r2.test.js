// 1.0.0 invoice reader rebuild: the AI in the owner's cloud (Google Gemini through cloud/Code.gs invoice_ai) reads the
// invoice when online; the phone (ML Kit + the improved text readers) when offline or when the AI is not switched on.
// The OCR texts in tests/fixtures/ocr are real supplier invoices read by OCR (bank and personal details taken out);
// truth.json has their correct figures.
import fs from 'fs';
import { createRequire } from 'module';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as IR from '../src/modules/inventory/invoiceRead.js';
import { parseInvoiceText, ebAmountsIn, ebDatesIn } from '../src/modules/payables/parser.js';
import { rowsFromResult, readPaperText, readPaperAi, fillEmpty } from '../src/services/paperRead.js';
import * as AI from '../src/services/invoiceAi.js';
import * as Flow from '../src/services/invoiceReadFlow.js';
import { targetSize } from '../src/platform/photos.js';
import { test, done, assert } from './harness.js';

const FIX = 'tests/fixtures/ocr/';
const truth = JSON.parse(fs.readFileSync(`${FIX}truth.json`, 'utf8'));
const textOf = (k) => fs.readFileSync(`${FIX}${k}.txt`, 'utf8');
const TODAY = '2026-10-31';
const KNOWN = ['Central Manufacturing Company', "Yee's Cold Storage Seafood", 'BL Naidu & Sons', 'Techni Cool Engineering Works', "Best Saving's", 'Motibhai & Company', 'Superb Distributors', 'R.B. Patel Group', 'Makans Pte Ltd'].map((name) => ({ name, tin: null }));

// ---------------------------------------------------------------- the offline reader on the real OCR texts
// Before the rebuild (same texts, same suppliers): invoice no 0/9, date 6/9, total 7/9, VAT 2/9, item lines 0/53.
const BEFORE = { invoice_no: 0, date: 6, total: 7, vat: 2, lines: 0 };
const hits = { supplier: 0, invoice_no: 0, date: 0, total: 0, vat: 0, lines: 0, linesTrue: 0 };
test('real invoices (OCR text): invoice number, date, total, VAT and item lines are read far better than before', () => {
  const rows = [];
  for (const k of Object.keys(truth)) {
    const t = truth[k];
    const txt = textOf(k);
    const p = parseInvoiceText(txt, KNOWN, 0.125, { today: TODAY });
    const L = IR.parseItemLines(txt, null);
    const first = (s) => s.toLowerCase().replace(/[^a-z ]/g, '').split(' ')[0].slice(0, 4);
    const ok = {
      supplier: !!p.supplier && p.supplier.toLowerCase().replace(/[^a-z]/g, '').includes(first(t.supplier)),
      invoice_no: p.invoice_no === t.invoice_no,
      date: p.invoice_date === t.invoice_date,
      total: p.total !== null && Math.abs(p.total - t.total_incl) < 0.01,
      vat: p.vat !== null && Math.abs(p.vat - t.vat) < 0.01,
    };
    for (const f of Object.keys(ok)) if (ok[f]) hits[f] += 1;
    const good = t.lines.filter((tl) => L.some((l) => Math.abs(l.qty - tl.qty) < 1e-6 && (Math.abs(l.total - tl.line_excl) < 0.02 || Math.abs(l.unitCost - tl.unit_cost_excl) < 0.02))).length;
    hits.lines += good; hits.linesTrue += t.lines.length;
    // nothing read wrongly as a line: every line read is one of the invoice's lines
    const wrong = L.filter((l) => !t.lines.some((tl) => Math.abs(l.qty - tl.qty) < 1e-6 && Math.abs(l.total - tl.line_excl) < 0.02));
    assert.equal(wrong.length, 0, `${k}: lines read wrongly ${JSON.stringify(wrong.map((l) => [l.description, l.qty, l.total]))}`);
    rows.push(`${k.padEnd(12)} no ${ok.invoice_no ? 'ok' : 'X '} date ${ok.date ? 'ok' : 'X '} total ${ok.total ? 'ok' : 'X '} vat ${ok.vat ? 'ok' : 'X '} lines ${good}/${t.lines.length}`);
  }
  console.log(`     ${rows.join('\n     ')}`);
  console.log(`     before: ${JSON.stringify(BEFORE)}  now: ${JSON.stringify(hits)}`);
  assert.ok(hits.invoice_no >= 8, `invoice no ${hits.invoice_no}/9`);
  assert.ok(hits.date >= 8, `date ${hits.date}/9`);
  assert.ok(hits.total >= 9, `total ${hits.total}/9`);
  assert.ok(hits.vat >= 8, `VAT ${hits.vat}/9`);
  assert.ok(hits.supplier >= 9, `supplier ${hits.supplier}/9`);
  assert.ok(hits.lines >= 13, `lines ${hits.lines}/${hits.linesTrue}`);
});

test('invoice number: value on a later line, "INVOICE NUMBER :" not cut to BER, "Invoice Notes" is not a number, the SDC number is not taken', () => {
  const no = (s) => parseInvoiceText(s, [], 0.125, { today: TODAY }).invoice_no;
  assert.equal(no('ABC Ltd\nINVOICE NUMBER :\n1216468\nINVOICE DATE :\n03/09/2026'), '1216468');
  assert.equal(no('ABC Ltd\nInvoice Notes: deliver to shop 1\nInvoice No: SI-075956'), 'SI-075956');
  assert.equal(no('ABC Ltd\nInvoice No: S1-075956'), 'SI-075956', 'OCR 1 for I in the letter prefix');
  assert.equal(no('ABC Ltd\nACCOUNT NO.\nINVOICE NO.\nMotibhai & Co Ltd\nCG012495\n1050423282'), '1050423282', 'two labels, two values in order');
  assert.equal(no('ABC Ltd\nSDC Invoice No: UXHVNTAN-HVG5GHOO-\nTax Invoice\nSINV165193'), 'SINV165193');
  assert.equal(no('ABC Ltd\nTAX INVOICE\n\\#0661000069293'), '0661000069293');
  assert.equal(no('Punjas\nInvoice # 77812'), '77812');
});

test('VAT and total: GST / TAX labels, never a percentage, stacked labels, VIP before VEP, handwritten amounts', () => {
  const one = (s) => { const p = parseInvoiceText(s, [], 0.125, { today: TODAY }); return [p.subtotal, p.vat, p.total]; };
  assert.deepEqual(one('ABC Ltd\nTotal VEP amount\n155.32\nTotal VAT amount\n19.42\nTotul VIP amount\n174.74'), [155.32, 19.42, 174.74]);
  assert.deepEqual(one('ABC Ltd\nSUB TOTAL: TAX\n332.95\n41.62\nFreight TOTAL\n0.00\n374.57'), [332.95, 41.62, 374.57]);
  assert.deepEqual(one('ABC Ltd\nSubtotal\nVAT Amount\n168.04\n5.23\nTotal $ Incl. VAT\n173.27'), [168.04, 5.23, 173.27]);
  assert.deepEqual(one('ABC Ltd\nTotal VEP Amount 268.66\nGST 33.58\nInvoice Total 302.24'), [268.66, 33.58, 302.24]);
  assert.deepEqual(one('ABC Ltd\nVAT\nRate 12.50%\nTax 106.56\nTotal 959.00'), [852.44, 106.56, 959]);
  assert.deepEqual(one('ABC\nInvoice # 4003\nVAT INCLUSIVE PRICE\n$18-'), [16, 2, 18], 'the VAT inside a VAT-inclusive total');
  assert.deepEqual(ebAmountsIn('18-00 and 379-67, $18-'), [18, 379.67, 18]);
  assert.deepEqual(ebAmountsIn('VAT 12.5% 41.62'), [41.62]);
  assert.deepEqual(ebAmountsIn('Date 16-09-2026 Ph 666-1633'), [], 'dates and phone numbers are not amounts');
});

test('dates far from today are not taken; a handwritten date with the year below is', () => {
  const p = parseInvoiceText('Techni Cool\nDATE 9/9/\n€9/9/20\n2026\n4003', [], 0.125, { today: TODAY });
  assert.equal(p.invoice_date, '2026-09-09');
  const q = parseInvoiceText('ABC Ltd\nDate: 9/9/20\nTotal 18.00', [], 0.125, { today: TODAY });
  assert.equal(q.invoice_date, null);
  assert.ok(q.notes.some((n) => /far from today/.test(n)), JSON.stringify(q.notes));
  assert.deepEqual(ebDatesIn('Date: 05/10/2026'), ['2026-10-05']);
});

test('supplier: matched on TIN, phone and name (also one letter misread); Easy Buys is never the supplier', () => {
  const sups = [{ name: "Yee's Cold Storage Seafood", tin: '' }, { name: 'Punjas Pte Limited', tin: '50-11634-0-2' }, { name: 'Techni Cool', tin: '', phone: '666 0939' }, { name: 'Easy Buys Shopping Centre', tin: '50-14315-0-7' }];
  assert.equal(parseInvoiceText("Jee's COLD STORAGE SEAFOOD PTE LTD\nTotal 10.00", sups).supplier, "Yee's Cold Storage Seafood");
  assert.equal(parseInvoiceText('PLD Ltd\nTIN: 50-11634.0-2\nTotal 10.00', sups).supplier, 'Punjas Pte Limited');
  assert.equal(parseInvoiceText('Phone: 6660939\nCASH SALE\nTotal 18.00', sups).supplier, 'Techni Cool');
  const b = parseInvoiceText('EASY BUYS SHOPPING CENTER\nBill To\nFresh Farm Ltd\nTIN No:\n501431507\nTotal 10.00', sups);
  assert.equal(b.supplier, 'Fresh Farm Ltd');
  assert.notEqual(b.supplier_tin, '501431507', 'the buyer\'s TIN is not the supplier\'s');
});

test('item lines: VAT % column, quantity first, VAT codes, discounts, VAT and amount columns, "VAT 69"', () => {
  const L = (s) => { const r = IR.parseItemLine(s, null); return r && [r.description, r.qty, r.unitCost, r.total]; };
  assert.deepEqual(L('2 CTN Rice Jasmine 10kg 45.00 90.00'), ['Rice Jasmine 10kg', 2, 45, 90]);
  assert.deepEqual(L('Rice Jasmine 10kg 2 CTN 45.00 90.00'), ['Rice Jasmine 10kg', 2, 45, 90]);
  assert.deepEqual(L('Flour 50kg 15 Bag 81.49 1,222.38 Z'), ['Flour 50kg', 15, 81.49, 1222.38]);
  assert.deepEqual(L('BLN Sultana KG 1 10KG 80.00 12.5 10.00 80.00').slice(1), [1, 80, 80]);
  assert.deepEqual(L('Godrej Aer Pocket 10g 1 ea 11.35 11.35 1.42 12.77').slice(1), [1, 11.35, 11.35]);
  assert.deepEqual(L('Sprint Cola 1L Ctn12 12 28.10 28.10 28.10 12.5 3.52').slice(1), [1, 28.1, 28.1]);
  assert.deepEqual(L('Three Star Matches 17.55 5.0 0.88 16.67 12.5 2.08').slice(1), [1, 16.67, 16.67], 'discount taken off');
  assert.deepEqual(L('BTMC01 Black Top Mosquito Coil 12 Packet 1.117 12.5 13.40').slice(1), [12, 1.117, 13.4]);
  assert.deepEqual(L('VAT 69 Whisky 750ml 1 45.00 45.00'), ['VAT 69 Whisky 750ml', 1, 45, 45]);
  assert.equal(L('Total VAT 12.5% 10.00 80.00'), null);
  assert.equal(L('Sub Total 267.60'), null);
  assert.deepEqual(L('Nomopain Regular Tab 12 10 — ea 1.19 11.90 1.49 13.39'), ['Nomopain Regular Tab 12', 10, 1.19, 11.9]);
});

test('a name learned before 1.0.0 (cut the old way) is still found', () => {
  const l = IR.parseItemLine('1001 Punjas Flour 10kg bag 12.5% 10 19.50 195.00', null);
  assert.equal(l.description, 'Punjas Flour 10kg');
  assert.equal(l.descOld, 'Punjas Flour 10kg 12.5%');
});

test('rows rebuilt from a slightly tilted photo; a line without a position no longer stops it', () => {
  const ln = (text, left, top, h = 20) => ({ text, frame: { left, top, width: 100, height: h } });
  // the amount column sits 12 px lower than its label (a crooked photo): still one row
  const r = { blocks: [{ lines: [ln('Total VEP Amount', 10, 100), ln('Invoice Total', 10, 140)] }, { lines: [ln('268.66', 400, 112), ln('302.24', 400, 152)] }, { lines: [{ text: 'no frame here' }] }] };
  const out = rowsFromResult(r);
  assert.ok(/Total VEP Amount\s+268\.66/.test(out), out);
  assert.ok(/Invoice Total\s+302\.24/.test(out), out);
  assert.ok(/no frame here/.test(out), out);
  assert.equal(rowsFromResult({ blocks: [{ lines: [{ text: 'x' }] }] }), null);
});

test('photos are kept sharp enough to read: the short side stays at least 1600 px', () => {
  assert.deepEqual(targetSize(4000, 3000), { height: 1600 });
  assert.deepEqual(targetSize(3000, 4000), { width: 1600 });
  assert.equal(targetSize(1000, 4000), null, 'a long narrow receipt is not made smaller');
  assert.equal(targetSize(1500, 1200), null);
});

// ---------------------------------------------------------------- the AI's answer → the app
initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const superb = AP.saveSupplier(owner, { name: 'Superb Distributors', tin: '50-99887-0-1', phone: '666 6088', onAccount: false });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const boom = u(I.saveItem(owner, { code: 'BOOM17', name: 'Boom Detergent Powder 1kg', cost: 38, price: 4.5, vatType: 'zero', supplierUid: superb.uid }));
const nutri = u(I.saveItem(owner, { code: 'N4023', name: 'Nutri C Party Tropical 32g', cost: 14.22, price: 0.6, supplierUid: superb.uid }));
const coil = u(I.saveItem(owner, { code: 'C10', name: 'Black Top Mosquito Coil 10s', cost: 1.0, price: 1.8, supplierUid: superb.uid }));

// The cloud's answer for the real Superb invoice (truth.json superb, in the invoice_ai shape). Its TIN is the one printed
// under "TIN No:" – Easy Buys' own (the buyer), which the app must not keep as the supplier's.
const sb = truth.superb;
const AI_ANSWER = { ok: true, model: 'gemini-2.5-flash', invoice: {
  supplier: sb.supplier, supplier_tin: sb.supplier_tin, invoice_no: sb.invoice_no, invoice_date: sb.invoice_date, prices_incl_vat: false,
  subtotal_excl: sb.subtotal_excl, vat: sb.vat, total_incl: sb.total_incl,
  lines: sb.lines.map((l) => ({ code: l.code, description: l.description, qty: l.qty, unit: l.unit, unit_price: l.unit_cost_excl, disc_pct: l.disc_pct, vat_pct: l.vat_pct, line_total: l.line_excl })),
  notes: 'Page 1 of 2 only', confidence: 0.92 } };

test('the AI answer is checked: the buyer\'s TIN dropped, the supplier matched by name, dates far away refused', () => {
  const ai = AI.cleanAi(AI_ANSWER.invoice, { today: TODAY });
  assert.equal(ai.supplier_tin, null);
  assert.ok(ai.notes.some((n) => /Easy Buys' own/.test(n)));
  assert.equal(ai.lines.length, 8);
  const h = AI.aiHeader(ai, AP.listSuppliers());
  assert.equal(h.supplierUid, superb.uid);
  assert.deepEqual([h.invoiceNo, h.invoiceDate, h.subtotal, h.vat, h.total], ['SUV136214', '2026-09-02', 168.04, 5.23, 173.27]);
  assert.equal(AI.cleanAi({ ...AI_ANSWER.invoice, invoice_date: '2020-09-09' }, { today: TODAY }).invoice_date, null);
  assert.equal(AI.cleanAi({ supplier: 'EASY BUYS SHOPPING CENTER', lines: [] }).supplier, null, 'the buyer is never the supplier');
  const hints = AI.aiHints(AP.listSuppliers().concat([{ name: 'Easy Buys Shopping Centre' }]));
  assert.deepEqual(hints.suppliers, ['Superb Distributors']);
  assert.equal(hints.buyer.tin, '50-14315-0-7');
});

let readRes;
test('the AI reading goes through the same matching and checks: products, the order, cost changes, the lines add up', () => {
  const po = I.savePO(owner, { supplierUid: superb.uid, shopCode: 'S1', lines: [{ itemUid: boom, qty: 1, unitCost: 40 }, { itemUid: nutri, qty: 1, unitCost: 14.22 }, { itemUid: coil, qty: 10, unitCost: 1.0 }] });
  const ai = AI.cleanAi(AI_ANSWER.invoice, { today: TODAY });
  readRes = IR.readInvoiceText(AI.aiToText(ai), { poUid: po.uid }, ai);
  assert.equal(readRes.engine, 'ai');
  assert.equal(readRes.supplierUid, superb.uid);
  assert.deepEqual([readRes.invoiceNo, readRes.total, readRes.vat], ['SUV136214', 173.27, 5.23]);
  assert.equal(readRes.lines.length, 8);
  const by = (uid) => readRes.lines.find((l) => l.itemUid === uid);
  assert.equal(by(boom).matchedBy, 'code');
  assert.equal(by(boom).unitCost, 40);
  assert.equal(by(coil).qty, 12);
  assert.ok(by(coil).flags.includes('more than ordered'));
  assert.ok(readRes.costChanges.some((c) => c.itemUid === boom && c.oldCost === 38 && c.newCost === 40));
  assert.ok(readRes.costChanges.some((c) => c.itemUid === coil));
  assert.ok(!readRes.costChanges.some((c) => c.itemUid === nutri), 'same cost: nothing flagged');
  assert.ok(Math.abs(readRes.linesTotal - 173.27) < 0.05, `lines add up: ${readRes.linesTotal}`);
  assert.ok(!readRes.flags.some((f) => /add up to/.test(f)), JSON.stringify(readRes.flags));
  assert.ok(readRes.flags.some((f) => /not matched to a product/.test(f)), 'unknown lines are still asked about');
});

test('"Looks right": the AI reading is kept, the receiver checks it, the delivery keeps it; the same text reads the same offline', () => {
  const readUid = IR.saveRead(owner, { supplierUid: superb.uid, engine: 'ai', text: AI.aiToText(AI.cleanAi(AI_ANSWER.invoice)), result: readRes });
  const kept = IR.listReads({ supplierUid: superb.uid })[0];
  assert.equal(kept.uid, readUid);
  assert.equal(kept.engine, 'ai');
  assert.equal(kept.result.invoiceNo, 'SUV136214');
  const rc = I.receiveDelivery(owner, { supplierUid: superb.uid, shopCode: 'S1', extra: readRes.lines.filter((l) => l.itemUid).map((l) => ({ itemUid: l.itemUid, qty: l.qty, unitCost: l.unitCost })),
    invoice: { invoiceNo: readRes.invoiceNo, total: readRes.total, photos: ['file:///p.pdf'] }, photos: ['file:///p.pdf'], acceptReason: 'Receiver checked: new prices accepted', readUid });
  assert.ok(rc && rc.uid);
  // payables › invoice gets the AI reading as text: the offline reader reads the same header back
  const p = parseInvoiceText(AI.aiToText(AI.cleanAi(AI_ANSWER.invoice)), AP.listSuppliers(), 0.125, { today: TODAY });
  assert.deepEqual([p.supplier, p.invoice_no, p.invoice_date, p.subtotal, p.vat, p.total], ['Superb Distributors', 'SUV136214', '2026-09-02', 168.04, 5.23, 173.27]);
  const back = IR.parseItemLines(AI.aiToText(AI.cleanAi(AI_ANSWER.invoice)), null);
  assert.equal(back.length, 8, JSON.stringify(back.map((l) => l.raw)));
  assert.deepEqual([back[5].qty, back[5].unitCost, back[5].total], [12, 1.1167, 13.4]);
  // and an entered invoice is filled in from it
  const inv = AP.saveInvoice(owner, { invoiceDate: '2026-10-09' }, { photos: ['file:///p.pdf'] });
  const filled = AP.applyReadText(inv.uid, AI.aiToText(AI.cleanAi(AI_ANSWER.invoice, { today: TODAY })));
  assert.deepEqual([filled.supplier_uid, filled.invoice_no, filled.invoice_date, filled.total, filled.vat], [superb.uid, 'SUV136214', '2026-09-02', 173.27, 5.23]);
  assert.strictEqual(filled.status, 'to_check', 'still needs a person to check');
});

test('paper photo screens: the AI fills the same boxes; the person still ticks the figures', () => {
  const ai = AI.cleanAi(AI_ANSWER.invoice, { today: TODAY });
  const r = readPaperAi('invoice', ai, { suppliers: AP.listSuppliers(), vatRate: 0.125 });
  assert.equal(r.fields.supplierUid, superb.uid);
  assert.deepEqual([r.fields.invoiceNo, r.fields.date, r.fields.total, r.fields.vat], ['SUV136214', '2026-09-02', 173.27, 5.23]);
  assert.ok(r.checks.some((c) => /not 12.5% of the total/.test(c.text)), 'mostly zero rated: the VAT check still warns');
  const { filled } = fillEmpty({ total: '', invoiceNo: '' }, r.fields, { total: 'total', invoiceNo: 'invoiceNo' });
  assert.deepEqual(filled, ['total', 'invoiceNo']);
  assert.equal(readPaperAi('deposit', ai), null, 'other papers are read on the phone');
  // the same answer as text, through the offline paper reader, gives the same boxes
  const t = readPaperText('invoice', AI.aiToText(ai), { suppliers: AP.listSuppliers(), vatRate: 0.125, today: TODAY });
  assert.deepEqual([t.fields.invoiceNo, t.fields.total, t.fields.vat], ['SUV136214', 173.27, 5.23]);
  const fuel = readPaperAi('fuel', AI.cleanAi({ supplier: 'Mobil Lautoka', total_incl: 122.3, vat: 13.59, lines: [{ description: 'Diesel', qty: 45.3, unit: 'L', unit_price: 2.7, line_total: 108.71, vat_pct: 12.5 }] }), {});
  assert.deepEqual([fuel.fields.litres, fuel.fields.pricePerLitre], [45.3, 2.7]);
});

// ---------------------------------------------------------------- the reading flow: AI first, the phone as the fall back
const OCR_SUPERB = textOf('superb');
function deps({ cloud, online = true, linked = true, deviceText = OCR_SUPERB, failPage = -1 } = {}) {
  const calls = [];
  return {
    calls,
    cloudUrl: () => (linked ? 'https://script.google.com/macros/s/X/exec' : ''),
    today: () => TODAY,
    fileExists: async () => true,
    fileBase64: async (uri) => `B64:${uri}`,
    recognizeText: async (uri, o) => { calls.push({ kind: 'device', uri, rows: o && o.rows }); return /page2/.test(uri) && failPage === 2 ? { ok: false, reason: 'blurred' } : { ok: true, text: deviceText }; },
    cloudCall: async (body, ms) => {
      calls.push({ kind: body.kind, files: body.files, hints: body.hints, ms });
      if (!online) throw new Error('Network request failed');
      return cloud(body);
    },
  };
}
const HINTS = AI.aiHints(AP.listSuppliers());

test('online: the AI reads it (photos as JPEG, a PDF as PDF), with the hints; "Read by AI"', async () => {
  const d = deps({ cloud: () => AI_ANSWER });
  const r = await Flow.readInvoiceFiles(['file:///p1.jpg', 'file:///inv.pdf'], { hints: HINTS, deps: d });
  assert.equal(r.ok, true);
  assert.equal(r.engine, 'ai');
  assert.equal(r.label, 'Read by AI');
  assert.equal(r.ai.invoice_no, 'SUV136214');
  const call = d.calls.find((c) => c.kind === 'invoice_ai');
  assert.deepEqual(call.files.map((f) => f.mimeType), ['image/jpeg', 'application/pdf']);
  assert.deepEqual(call.hints.suppliers, ['Superb Distributors']);
  assert.ok(!d.calls.some((c) => c.kind === 'device'), 'not read on the phone as well');
  assert.ok(/Invoice No: SUV136214/.test(r.text));
});

test('the cloud has no AI key (NO_AI_KEY, thrown or returned): read on this phone with rows, and said so', async () => {
  for (const cloud of [() => { throw new Error('NO_AI_KEY: the AI reader is not switched on'); }, () => ({ ok: true, code: 'NO_AI_KEY' })]) {
    const d = deps({ cloud: (b) => (b.kind === 'invoice_ai' ? cloud() : { ok: true, text: '' }) });
    const r = await Flow.readInvoiceFiles(['file:///p1.jpg'], { hints: HINTS, deps: d });
    assert.equal(r.ok, true);
    assert.equal(r.engine, 'device');
    assert.equal(r.aiCode, 'NO_AI_KEY');
    assert.equal(r.label, 'Read on this phone – check carefully');
    assert.equal(r.aiPending, false);
    assert.ok(/not switched on/.test(r.message), r.message);
    assert.ok(d.calls.some((c) => c.kind === 'device' && c.rows === true), 'rows: true');
    assert.equal(parseInvoiceText(r.text, AP.listSuppliers(), 0.125, { today: TODAY }).invoice_no, 'SUV136214');
  }
});

test('the AI fails, or there is no internet: read on the phone, "AI re-read when online"', async () => {
  const d1 = deps({ cloud: (b) => (b.kind === 'invoice_ai' ? { ok: false, error: 'AI_ERROR: the free AI limit is used up' } : { ok: true, text: '' }) });
  const r1 = await Flow.readInvoiceFiles(['file:///p1.jpg'], { hints: HINTS, deps: d1 });
  assert.deepEqual([r1.ok, r1.engine, r1.aiCode, r1.aiPending], [true, 'device', 'AI_ERROR', true]);
  assert.ok(/free AI limit/.test(r1.message), r1.message);
  const d2 = deps({ online: false, cloud: () => AI_ANSWER });
  const r2 = await Flow.readInvoiceFiles(['file:///p1.jpg'], { hints: HINTS, deps: d2 });
  assert.deepEqual([r2.ok, r2.engine, r2.aiCode, r2.aiPending], [true, 'device', 'OFFLINE', true]);
  assert.ok(/AI re-read when online/.test(r2.message), r2.message);
  assert.equal(d2.calls.filter((c) => c.kind === 'ocr').length, 0, 'offline: Google\'s text reading is not tried either');
  // not linked to the cloud at all: the phone, no cloud call
  const d3 = deps({ linked: false, cloud: () => AI_ANSWER });
  const r3 = await Flow.readInvoiceFiles(['file:///p1.jpg'], { hints: HINTS, deps: d3 });
  assert.deepEqual([r3.ok, r3.engine, d3.calls.filter((c) => c.kind !== 'device').length], [true, 'device', 0]);
});

test('a weak phone reading: Google\'s text reading is tried as well and the better one kept; a page that fails is reported', async () => {
  const d = deps({ deviceText: 'some smudge 12', failPage: 2, cloud: (b) => (b.kind === 'invoice_ai' ? { ok: false, code: 'NO_AI_KEY', error: 'NO_AI_KEY' } : { ok: true, text: OCR_SUPERB, pageErrors: [] }) });
  const r = await Flow.readInvoiceFiles(['file:///page1.jpg', 'file:///page2.jpg'], { hints: HINTS, deps: d });
  assert.equal(r.ok, true);
  assert.equal(r.engine, 'cloud');
  assert.ok(r.pageErrors.some((p) => /Page 2: blurred/.test(p)), JSON.stringify(r.pageErrors));
  assert.ok(/Page 2: blurred/.test(r.message), r.message);
  // a good phone reading: no second reading
  const d2 = deps({ cloud: (b) => (b.kind === 'invoice_ai' ? { ok: false, code: 'NO_AI_KEY', error: 'NO_AI_KEY' } : { ok: true, text: 'x' }) });
  await Flow.readInvoiceFiles(['file:///page1.jpg'], { hints: HINTS, deps: d2 });
  assert.equal(d2.calls.filter((c) => c.kind === 'ocr').length, 0);
});

test('a PDF with no AI: said clearly (the phone cannot read PDFs); text-only reading still works for statements', async () => {
  const d = deps({ cloud: (b) => (b.kind === 'invoice_ai' ? { ok: false, code: 'NO_AI_KEY', error: 'NO_AI_KEY' } : { ok: true, text: '' }) });
  const r = await Flow.readInvoiceFiles(['file:///inv.pdf'], { hints: HINTS, deps: d });
  assert.equal(r.ok, false);
  assert.ok(/PDF is read by the AI/.test(r.message), r.message);
  assert.ok(!d.calls.some((c) => c.kind === 'device'));
  const t = await Flow.readPhotosText(['file:///s1.jpg'], { rows: true, deps: deps({ deviceText: 'Opening balance 10.00', cloud: () => ({ ok: true, text: 'z' }) }) });
  assert.deepEqual([t.ok, t.engine], [true, 'device'], 'a statement read on the phone is not sent to Google again');
});

// ---------------------------------------------------------------- the cloud program (cloud/Code.gs) with fake Google services
const req = createRequire(`${process.cwd()}/tests/x.js`);
test('Code.gs invoice_ai: the key from Script properties, the pages and schema sent to Gemini, the JSON returned; no key → NO_AI_KEY', () => {
  const { G, ctx, post } = req('./fakeGoogle.cjs').load();
  ctx.setup();
  const dev = { id: 'dev-tablet', name: 'Shop tablet', kind: 'tablet' };
  const ask = (b) => post({ key: 'tablet-key-123', device: dev, ...b });
  const files = [{ mimeType: 'image/jpeg', data: 'QUJD' }, { mimeType: 'application/pdf', data: 'UERG' }];
  const none = ask({ kind: 'invoice_ai', files, hints: HINTS });
  assert.equal(none.ok, false);
  assert.equal(none.code, 'NO_AI_KEY');
  assert.ok(/NO_AI_KEY/.test(none.error));
  assert.equal(post({ device: dev, kind: 'invoice_ai', files }).ok, false, 'the same device check as the other requests');
  G.props.GEMINI_KEY = 'test-gemini-key';
  const calls = [];
  ctx.Utilities.sleep = () => {};
  ctx.UrlFetchApp = { fetch: (url, o) => {
    calls.push({ url, o, body: JSON.parse(o.payload) });
    return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(AI_ANSWER.invoice) }] }, finishReason: 'STOP' }] }) };
  } };
  const r = ask({ kind: 'invoice_ai', files, hints: HINTS });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.invoice.invoice_no, 'SUV136214');
  assert.equal(calls.length, 1);
  assert.ok(calls[0].url.startsWith('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key='));
  assert.equal(calls[0].o.muteHttpExceptions, true);
  const parts = calls[0].body.contents[0].parts;
  assert.deepEqual(parts.slice(1).map((p) => p.inline_data.mime_type), ['image/jpeg', 'application/pdf']);
  assert.ok(/12\.5% /.test(parts[0].text) && /50-14315-0-7/.test(parts[0].text) && /never the supplier/i.test(parts[0].text) && /Superb Distributors/.test(parts[0].text), parts[0].text);
  const gc = calls[0].body.generationConfig;
  assert.equal(gc.responseMimeType, 'application/json');
  assert.deepEqual(Object.keys(gc.responseSchema.properties), ['supplier', 'supplier_tin', 'invoice_no', 'invoice_date', 'prices_incl_vat', 'subtotal_excl', 'vat', 'total_incl', 'lines', 'notes', 'confidence']);
  assert.deepEqual(Object.keys(gc.responseSchema.properties.lines.items.properties), ['code', 'description', 'qty', 'unit', 'unit_price', 'disc_pct', 'vat_pct', 'line_total']);
  // Gemini says no: the reason comes back (without the key), as AI_ERROR
  ctx.UrlFetchApp = { fetch: (url) => ({ getResponseCode: () => 500, getContentText: () => JSON.stringify({ error: { message: `internal at ${url}` } }) }) };
  const bad = ask({ kind: 'invoice_ai', files, hints: HINTS });
  assert.equal(bad.code, 'AI_ERROR');
  assert.ok(!/test-gemini-key/.test(bad.error), bad.error);
  ctx.UrlFetchApp = { fetch: () => { throw new Error('Timeout: https://generativelanguage.googleapis.com/x?key=test-gemini-key'); } };
  const slow = ask({ kind: 'invoice_ai', files, hints: HINTS });
  assert.equal(slow.code, 'AI_ERROR');
  assert.ok(!/test-gemini-key/.test(slow.error), slow.error);
  // no key anywhere in the program itself
  assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(fs.readFileSync('cloud/Code.gs', 'utf8')));
});

test('Code.gs ocr: one bad page no longer fails the others', () => {
  const { ctx, post } = req('./fakeGoogle.cjs').load();
  ctx.setup();
  ctx.Drive = { Files: { create: (meta, blob) => { if (blob.name === 'page-2.jpg') throw new Error('Invalid image'); return { id: blob.name }; } } };
  ctx.DocumentApp = { openById: (id) => ({ getBody: () => ({ getText: () => `text of ${id}` }) }) };
  const r = post({ key: 'tablet-key-123', device: { id: 'd1', name: 'Tab', kind: 'tablet' }, kind: 'ocr', files: [{ data: 'QUJD' }, { data: 'QUJD' }, { data: 'QUJD' }] });
  assert.equal(r.ok, true);
  assert.equal(r.text, 'text of page-1.jpg\ntext of page-3.jpg');
  assert.deepEqual(r.pageErrors, ['Page 2: Invalid image']);
});

done();
