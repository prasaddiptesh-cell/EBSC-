// 1.0.0 the go-live stock take of each shop: its own count and stock per shop, many people counting, empty gas
// cylinders, cigarettes / liquor counted twice, differences to verify, and the Aronium count sheet (never a file).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared, deviceId } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as GL from '../src/modules/inventory/goLiveCount.js';
import * as V from '../src/modules/verify/service.js';
import * as L from '../src/modules/aronium/link.js';
import * as SH from '../src/modules/till/salesHistory.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T21:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Asha Admin', pin: '7777', role: 'admin' }, owner);
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const ravi = saveUser({ name: 'Ravi', pin: '2424', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const rice = u(I.saveItem(owner, { code: 'RICE', name: 'Rice 1kg', cost: 2, price: 3, barcode: '111', group: 'Grocery' }));
const pm = u(I.saveItem(owner, { code: 'PM20', name: 'Pall Mall 20s', cost: 15, price: 19, group: 'Cigarettes' }));
const gas = u(I.saveItem(owner, { code: 'GAS12', name: 'Gas refill 12 kg', cost: 38, price: 42.16, group: 'Gas' }));
db().run("UPDATE inv_items SET group_name = 'Cigarettes' WHERE uid = ?", [pm]);
// what Aronium has (sent by the till PC of Shop 1)
setShared('main_tablet_device', deviceId());
db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES ('S1-T1|stock|all|0', 'S1-T1', 'S1', 'Shop 1, Till 1', 'stock', 'all', 0, 1, ?, 'h1', '2026-10-31T09:00:00Z', '1.2', '2026-10-31 20:55:00', 'x', 'synced')`,
[JSON.stringify([{ code: 'RICE', qty: 40 }, { code: 'PM20', qty: 10 }, { code: 'GAS12', qty: 6 }])]);

const lolly = u(I.saveItem(owner, { code: 'LOL1', name: 'Lolly pop', cost: 0.1, price: 0.2, group: 'Lollies' }));
db().run("UPDATE inv_items SET group_name = 'Lollies' WHERE uid = ?", [lolly]);
let s1; let s2;
test('each shop has its own stock take; the night\'s checklist shows until the first one is approved', () => {
  s1 = I.startCount(owner, { shopCode: 'S1', kind: 'initial', date: '2026-10-31', timing: 'after_close' });
  s2 = I.startCount(owner, { shopCode: 'S2', kind: 'initial', date: '2026-10-31', timing: 'after_close' });
  assert.notEqual(s1.uid, s2.uid);
  const g = GL.goLiveCountChecklist('S1');
  assert.ok(g.steps.length >= 8 && g.steps.some((x) => /EMPTY cylinders/.test(x)) && g.steps.some((x) => /kept in the Easy Buys app only/.test(x)) && !g.steps.some((x) => /Aronium count sheet/.test(x)));
  assert.equal(g.doubleProducts, 1, 'the cigarettes are counted twice');
});
test('many people count: their counts add up; cigarettes need a second person who agrees', () => {
  I.enterCount(sita, s1.uid, rice, 20);
  I.enterCount(ravi, s1.uid, rice, 18, { add: true });
  I.enterCount(sita, s1.uid, pm, 10);
  I.enterCount(ravi, s1.uid, pm, 10);
  I.enterCount(sita, s1.uid, gas, 5);
  const c = I.getCount(s1.uid);
  assert.equal(c.lines.find((l) => l.item_uid === rice).counted, 38);
  const p = c.lines.find((l) => l.item_uid === pm);
  assert.equal(p.double, true); assert.equal(p.second_count, 10);
});
test('empty gas cylinders (not products) are counted with the stock take', () => {
  assert.ok(GL.countExtras(s1.uid).some((x) => x.key === 'gas_empty_12'));
  GL.saveExtra(sita, s1.uid, { key: 'gas_empty_12', qty: '7' });
  throws(() => GL.saveExtra(sita, s1.uid, { key: 'gas_empty_12', qty: 'lots' }), /how many/);
  assert.equal(GL.countExtras(s1.uid).find((x) => x.key === 'gas_empty_12').qty, 7);
  assert.equal(GL.countExtras(s2.uid).find((x) => x.key === 'gas_empty_12').qty, null, 'Shop 2 has its own');
});
test('handed in → on To verify to check and approve; approved with differences → to verify, by someone else', () => {
  I.submitCount(mgr, s1.uid);
  const q1 = V.queue({ include: 'waiting' }).filter((x) => x.table === 'inv_counts');
  assert.ok(q1.some((x) => /to check and approve/.test(x.type) && x.shop === 'S1'), JSON.stringify(q1.map((x) => x.type)));
  I.postCount(admin, s1.uid);
  assert.equal(I.stockOf(rice, 'S1'), 38); assert.equal(I.stockOf(rice, 'S2'), 0, 'Shop 2 stock is separate');
  const q2 = V.queue({ include: 'waiting' }).filter((x) => x.table === 'inv_counts');
  assert.ok(q2.some((x) => /Stock take results/.test(x.type)), JSON.stringify(q2.map((x) => x.type)));
  V.saveVerifyRules(owner, { ...V.verifyRules(), secondPerson: true });
  throws(() => V.verify(admin, { table: 'inv_counts', uid: s1.uid }), /different person/);
  V.verify(owner, { table: 'inv_counts', uid: s1.uid });
  assert.ok(!V.queue({ include: 'waiting' }).some((x) => x.key === `inv_counts:${s1.uid}`));
});
test('Aronium count sheet: only what differs, counted numbers to type into Aronium\'s own count – no file to import', () => {
  const sh = GL.aroniumSheet(s1.uid);
  const byCode = Object.fromEntries(sh.rows.map((r) => [r.code, r]));
  assert.equal(byCode.RICE.counted, 38); assert.equal(byCode.RICE.inAronium, 40); assert.equal(byCode.RICE.diff, -2);
  assert.equal(byCode.GAS12.diff, -1);
  assert.ok(!byCode.PM20, 'the same in Aronium: nothing to type');
  assert.equal(sh.same, 1);
  throws(() => GL.markEntered(sita, s1.uid, 'RICE'), /manager, the admin or the owner/);
  GL.markEntered(mgr, s1.uid, 'RICE');
  assert.equal(GL.aroniumSheet(s1.uid).entered, 1);
  const doc = GL.aroniumSheetDoc(s1.uid);
  assert.ok(/300 – Inventory count/.test(doc.subtitle));
  assert.ok(doc.info.some(([k, v]) => k === 'How' && /Do NOT use Import products/.test(v)));
  assert.equal(GL.aroniumSheet(s1.uid, { all: true }).rows.length, 3);
});
test('the stock lives in the app: sales of the count day arriving late never take it off twice – even from two phones', () => {
  assert.equal(I.stockOf(rice, 'S1'), 38);
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: rice, code: 'RICE', qty: 3, unitCost: 2 });
  assert.equal(I.stockOf(rice, 'S1'), 38, 'the count after closing already saw these');
  // a second shop phone that had not yet received the first one's record does the same
  db().run("DELETE FROM inv_moves WHERE uid = 'SL-S1-2026-10-31-RICE'");
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: rice, code: 'RICE', qty: 3, unitCost: 2 });
  assert.equal(I.stockOf(rice, 'S1'), 38, 'never corrected twice');
  assert.equal(db().get("SELECT COUNT(*) AS n FROM inv_moves WHERE ref_type = 'count_late_sale' AND item_uid = ?", [rice]).n, 1);
  I.putSale({ shopCode: 'S1', date: '2026-10-31', itemUid: rice, code: 'RICE', qty: 5, unitCost: 2 });
  assert.equal(I.stockOf(rice, 'S1'), 38);
  I.putSale({ shopCode: 'S1', date: '2026-11-01', itemUid: rice, code: 'RICE', qty: 4, unitCost: 2 });
  assert.equal(I.stockOf(rice, 'S1'), 34, 'the next day\'s sales take it off');
  db().run("DELETE FROM inv_moves WHERE uid = 'SL-S1-2026-11-01-RICE'");
});
test('lollies are sales only: never in a stock take, never low / negative / to order – but sales are still recorded', () => {
  assert.ok(!I.getCount(s1.uid).lines.some((l) => l.item_uid === lolly), 'not on the stock take');
  db().run("INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, status, by_name, updated_at, updated_device) VALUES ('SL-S1-2026-10-31-LOL1', ?, 'S1', '2026-10-31', 'sale', -50, 0.1, 'active', 'Aronium link', '2026-10-31 20:00:00', 'x')", [lolly]);
  const row = I.stockList({ shopCode: 'S1', limit: 100 }).find((r) => r.uid === lolly);
  if (row) { assert.equal(row.salesOnly, true); assert.equal(row.suggest, 0); }
  assert.ok(!I.stockList({ shopCode: 'S1', filter: 'negative' }).some((r) => r.uid === lolly));
  assert.ok(!I.stockList({ shopCode: 'S1', filter: 'order' }).some((r) => r.uid === lolly));
  assert.ok(GL.goLiveCountChecklist('S1').steps.some((x) => /Lollies/.test(x)));
});
test('any device turns the till\'s sales into sales (not only the main tablet); doing it twice never doubles', () => {
  setShared('main_tablet_device', 'SOME-OTHER-TABLET');
  assert.equal(L.isLinkDevice(), false);
  db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES ('S1-T1|sales_day|2026-11-01|0', 'S1-T1', 'S1', 'Shop 1, Till 1', 'sales_day', '2026-11-01', 0, 1, ?, 'hs1', '2026-11-01T02:00:00Z', '1.2', '2026-11-01 14:00:00', 'x', 'synced')`,
  [JSON.stringify({ cols: ['code', 'name', 'sold', 'sold_value', 'refunded', 'refund_value', 'net', 'cost'], rows: [['RICE', 'Rice 1kg', 5, 15, 0, 0, 5, 10]] })]);
  L.processLink();
  const mv = () => db().get("SELECT qty FROM inv_moves WHERE uid = 'SL-S1-2026-11-01-RICE' AND status = 'active'");
  assert.equal(mv().qty, -5);
  db().run("DELETE FROM aronium_link_done");
  L.processLink();
  assert.equal(db().get("SELECT COUNT(*) AS n FROM inv_moves WHERE uid = 'SL-S1-2026-11-01-RICE'").n, 1, 'never doubled');
  assert.equal(L.aroniumSalesByDay({ from: '2026-11-01' }).find((d) => d.shop === 'S1').value, 15, 'today\'s sales show on this device');
});
test('sales history: day by day per shop and till, a day\'s products – any period, bad dates are safe', () => {
  const h = SH.salesHistory({ from: '2026-10-01', to: '2026-11-30' });
  const d = h.days.find((x) => x.date === '2026-11-01');
  assert.ok(d && d.shops.S1 && d.shops.S1.value === 15, JSON.stringify(h.days));
  assert.equal(SH.salesDay('2026-11-01', { shop: 'S1' }).products[0].code, 'RICE');
  assert.doesNotThrow(() => SH.salesHistory({ from: 'x', to: 'y' }));
  assert.ok(SH.SALES_REPORTS[0].build('2026-10-01', '2026-11-30', owner, {}).sections[0].rows.length >= 1);
});
done();
