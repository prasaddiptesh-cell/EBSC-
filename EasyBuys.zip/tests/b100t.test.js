// 1.0.0 price tickets on A4 (name, that shop's price, unit, small barcode) and the barcodes drawn for them.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as PT from '../src/modules/inventory/priceTickets.js';
import * as B from '../src/services/barcodeSvg.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const coke = u(I.saveItem(owner, { code: 'C1', name: 'Coke 1.5L', cost: 2.1, price: 3.5, barcode: '5449000000996', unit: 'bottle' }));
const rice = u(I.saveItem(owner, { code: 'R1', name: 'Rice loose', cost: 2, price: 3.2, unit: 'kg' }));
I.saveItemShop(owner, { itemUid: coke, shopCode: 'S1', active: true, price: 3.95 });
I.saveItemShop(owner, { itemUid: coke, shopCode: 'S2', active: true, price: 3.8 });

test('EAN-13 drawn right (95 modules, guards, check digit); anything else as Code 128', () => {
  assert.ok(B.isEan13('4006381333931')); assert.ok(!B.isEan13('4006381333932'));
  const bits = B.ean13Bits('4006381333931');
  assert.equal(bits.length, 95);
  assert.ok(bits.startsWith('101') && bits.endsWith('101') && bits.slice(45, 50) === '01010');
  // first digit 4 → parity LGLLGG; digit 1 "0" with L = 0001101
  assert.equal(bits.slice(3, 10), '0001101');
  const c = B.code128Bits('ABC');
  assert.ok(c.startsWith('11010010000'), 'start B'); // 211214
  assert.ok(c.endsWith('1100011101011'), 'stop'); // 2331112
  assert.ok(/<rect/.test(B.barcodeSvg('5449000000996')) && /<rect/.test(B.barcodeSvg('C1-XYZ')));
  assert.equal(B.barcodeSvg(''), '');
});
test('tickets use THAT shop\'s price; many on one A4; next page when full', () => {
  const h1 = PT.ticketsHtml('S1', [{ itemUid: coke, copies: 2 }], { size: 'medium' });
  assert.equal((h1.match(/class="t"/g) || []).length, 2);
  assert.ok(h1.includes('$3.95') && !h1.includes('$3.80'));
  assert.ok(h1.includes('per bottle') && h1.includes('5449000000996') && h1.includes('<svg'));
  assert.ok(PT.ticketsHtml('S2', [{ itemUid: coke, copies: 1 }]).includes('$3.80'));
  const per = PT.SIZES.small.cols * PT.SIZES.small.rows;
  assert.ok(per >= 40, `small: ${per} a page`);
  const big = PT.ticketsHtml('S1', [{ itemUid: coke, copies: per + 5 }], { size: 'small' });
  assert.equal((big.match(/class="pg"/g) || []).length, 2, 'the next page when full');
  const r = PT.ticketsHtml('S2', [{ itemUid: rice, copies: 1 }].map((x) => x), { size: 'large' });
  assert.ok(r.includes('per kg') && r.includes('R1'), 'no barcode: the code is printed');
});
test('the price stays big, the rest small – and all of it can be changed before printing; 80 mm roll', () => {
  const d = PT.ticketsDoc('S1', [{ itemUid: coke, copies: 3 }], PT.applyPreset(PT.defaultLayout(), 'medium'));
  assert.ok(/font-size:20pt;font-weight:800;">\$3\.95/.test(d.html), 'price 20pt bold');
  assert.ok(/font-size:7pt;font-weight:800;">Coke/.test(d.html) && /font-size:5\.5pt;">per bottle/.test(d.html));
  assert.ok(/per bottle<\/span> · <span[^>]*>S1<\/span> · <span[^>]*>31\/10/.test(d.html), 'unit, shop and date on one line');
  const roll = PT.ticketsDoc('S1', [{ itemUid: coke, copies: 5 }], { ...PT.applyPreset(PT.defaultLayout(), 'medium'), paper: '80mm' });
  assert.equal(roll.cols, 1); assert.equal(roll.pages, 1);
  assert.equal(roll.size.width, 227, '80 mm wide');
  assert.equal(roll.size.height, Math.round((5 * 28 + 8) * 72 / 25.4), 'as long as the tickets');
  assert.ok(/size: 80mm 148mm/.test(roll.html));
  const two = PT.ticketsDoc('S1', [{ itemUid: coke, copies: 4 }], { ...PT.defaultLayout(), paper: '80mm', w: 34, h: 22 });
  assert.equal(two.cols, 2, 'small ones two across the roll');
  assert.equal(PT.cleanLayout({ w: 1, gap: 99 }).w, 20, 'never silly sizes');
  assert.equal(PT.cleanLayout({ gap: 99 }).gap, 5);
  PT.saveLayout({ ...PT.defaultLayout(), paper: '80mm' });
  assert.equal(PT.savedLayout().paper, '80mm');
});
test('the design: items added / removed, moved, sized, bold, same line; spacing; own words; shared to every device', () => {
  let L = PT.defaultLayout();
  L = PT.setItem(L, 'barcode', { on: false });
  L = PT.setItem(L, 'barnum', { on: false });
  L = PT.setItem(L, 'text', { on: true, text: 'SPECIAL', size: 9, bold: true });
  L = PT.moveItem(L, 'text', -1); // up one
  L = PT.setItem(L, 'price', { size: 26 });
  L = PT.setItem(L, 'code', { on: true, inline: true });
  L = { ...L, gap: 1.5, pad: 2 };
  const d = PT.ticketsDoc('S1', [{ itemUid: coke, copies: 1 }], L);
  assert.ok(!d.html.includes('<svg'), 'barcode removed');
  assert.ok(d.html.includes('>SPECIAL<') && /font-size:26pt/.test(d.html));
  assert.ok(/gap: 1\.5mm/.test(d.html) && /padding: 2mm/.test(d.html));
  assert.ok(d.html.indexOf('SPECIAL') > d.html.indexOf('$3.95'));
  assert.ok(/>C1<\/span>/.test(d.html), 'product code added');
  const order = PT.cleanLayout(L).items.map((x) => x.key);
  assert.ok(order.indexOf('text') < order.indexOf('code'));
  const old = PT.cleanLayout({ price: 24, name: 6, small: 5, bar: false, showDate: false });
  assert.equal(old.items.find((x) => x.key === 'price').size, 24, 'an older saved design still works');
  assert.equal(old.items.find((x) => x.key === 'barcode').on, false);
  throws(() => PT.shareLayout(null, L), /manager/);
  PT.shareLayout(owner, L);
});
test('no price at the shop, or nothing chosen: says so', () => {
  I.saveItemShop(owner, { itemUid: rice, shopCode: 'S1', active: true, price: 0 });
  throws(() => PT.ticketsHtml('S1', [{ itemUid: rice, copies: 1 }]), /No selling price at S1 for: Rice loose/);
  throws(() => PT.ticketsHtml('S1', []), /Add the products/);
  PT.saveList([{ itemUid: coke, copies: 3 }]);
  assert.equal(PT.savedList()[0].copies, 3);
});
done();
