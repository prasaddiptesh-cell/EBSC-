// 1.0.0 each shop's own prices; after its opening stock take the app keeps prices and costs; App vs Aronium per shop;
// the Aronium update file in Aronium's import format – no Quantity column, point decimals, "|" barcodes, "Name:rate" taxes.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared, deviceId } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as AU from '../src/modules/inventory/aroniumUpdate.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-31T21:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
setShared('main_tablet_device', deviceId());
const feed = (source, kind, data) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?, ?, ?, ?, ?, 'all', 0, 1, ?, ?, 'x', '1.0', '2026-10-31 08:00:00', 'x', 'synced')`, [`${source}|${kind}|all|0`, source, source.slice(0, 2), source, kind, JSON.stringify(data), `h${Math.random()}`]);
const P = (code, name, price, cost, rate, extra = {}) => ({ code, name, price, cost, vat_rate: rate, barcodes: [], group: 'Grocery', unit: 'each', price_includes_vat: true, enabled: true, service: false, taxes: rate ? [`VAT 12.5%:${rate}`] : ['Zero Rated:0'], ...extra });
const u = (x) => (typeof x === 'string' ? x : x.uid);
const rice = u(I.saveItem(owner, { code: 'R1', name: 'Rice 20kg', cost: 30, price: 42 }));
const coke = u(I.saveItem(owner, { code: 'C1', name: 'Coke 1.5L', cost: 2.1, price: 3.5 }));
db().run("UPDATE inv_items SET vat_type = 'zero' WHERE uid = ?", [rice]);
db().run("UPDATE inv_items SET vat_type = 'standard' WHERE uid = ?", [coke]);
const taxes = [{ name: 'VAT 12.5%', rate: 12.5 }, { name: 'Zero Rated', rate: 0 }];
feed('S1-T1', 'meta', { taxes });
feed('S2-T1', 'meta', { taxes });
feed('S1-T1', 'products', [P('R1', 'Rice 20kg', 42, 30, 0), P('C1', 'Coke 1.5L', 3.5, 2.1, 12.5, { barcodes: ['5449000000996', '5449000000997'], markup: 10, price_change: false, default_qty: true })]);
feed('S2-T1', 'products', [P('R1', 'Rice 20kg', 44, 30, 0), P('C1', 'Coke 1.5L', 3.8, 2.1, 12.5)]);

test('each shop has its own selling price; App vs Aronium per shop', () => {
  I.saveItemShop(owner, { itemUid: coke, shopCode: 'S1', active: true, price: 3.95 });
  I.saveItemShop(owner, { itemUid: coke, shopCode: 'S2', active: true, price: 3.8 });
  I.saveItemShop(owner, { itemUid: rice, shopCode: 'S2', active: true, price: 44 });
  const s1 = AU.compareShop('S1'); const s2 = AU.compareShop('S2');
  assert.deepEqual(s1.rows.map((r) => [r.code, r.diffs.join()]), [['C1', 'price']]);
  assert.equal(s2.rows.length, 0, 'Shop 2 agrees');
});
test('after the opening stock take the app keeps prices and costs: Aronium\'s product list no longer overwrites them', () => {
  I.setAppMaster(owner, 'S1', true);
  db().run("UPDATE inv_items SET cost = 2.25 WHERE uid = ?", [coke]); // the new invoice cost
  I.importProductsCsv(owner, 'Code;Name;Price;Cost;Taxes\nC1;Coke 1.5L;3.50;2.10;VAT 12.5%\n', { shopCode: 'S1' });
  assert.equal(I.itemAtShop(coke, 'S1').shopPrice, 3.95, 'S1 price kept');
  assert.equal(I.getItem(coke).cost, 2.25, 'invoice cost kept');
  const r = AU.compareShop('S1').rows.find((x) => x.code === 'C1');
  assert.deepEqual(r.diffs, ['price', 'cost']);
});
test('the update file: exactly Aronium\'s import columns, no Quantity, only the changes, the rest as Aronium has it', () => {
  db().run("UPDATE inv_items SET vat_type = 'standard' WHERE uid = ?", [rice]); // the invoices say rice has VAT
  const f = AU.updateFile('S1');
  const lines = f.text.trim().split('\r\n');
  assert.equal(lines[0], 'Name,Product group,SKU,Barcode,Measurement Unit,Cost,Markup,Price,Tax,Tax Inclusive Price,Price Change Allowed,Using Default Quantity,Service,Enabled,Description');
  assert.ok(!/quantity\b(?! )/i.test(lines[0].replace('Using Default Quantity', '')), 'no Quantity column');
  assert.equal(f.rows, 2);
  const coke1 = lines.find((l) => l.startsWith('Coke'));
  assert.equal(coke1, 'Coke 1.5L,Grocery,C1,5449000000996|5449000000997,each,2.25,56.05,3.95,VAT 12.5%:12.5,1,0,1,0,1,');
  const rice1 = lines.find((l) => l.startsWith('Rice'));
  assert.ok(/,R1,.*,30,.*,42,VAT 12\.5%:12\.5,/.test(rice1), rice1);
  assert.ok(!/\d,\d{1,2}(?=,)/.test(coke1.replace(/,\d+(\.\d+)?/g, '')), 'decimals use a point');
  assert.deepEqual(f.counts, { price: 1, cost: 1, vat: 1, barcode: 0 });
  assert.equal(AU.updateFile('S1', { test: true }).rows, 1, 'the test file has one product');
});
test('names with commas are quoted; a tax this Aronium does not have is warned about', () => {
  feed('S1-T1', 'products', [P('C1', 'Coke, 1.5L "Classic"', 3.5, 2.1, 12.5)]);
  feed('S1-T1', 'meta', { taxes: [{ name: 'Zero Rated', rate: 0 }] });
  const f = AU.updateFile('S1');
  assert.ok(f.text.includes('"Coke, 1.5L ""Classic"""'));
  assert.ok(f.warnings.some((w) => /no 12\.5% tax/.test(w)) || !f.counts.vat);
});
test('a barcode the app has and Aronium lacks goes into the file, added to Aronium\'s own', () => {
  feed('S1-T1', 'meta', { taxes });
  feed('S1-T1', 'products', [P('C1', 'Coke 1.5L', 3.95, 2.25, 12.5, { barcodes: ['5449000000996'] })]);
  db().run("UPDATE inv_items SET barcode = '5449000000996,2100000000016' WHERE uid = ?", [coke]);
  const f = AU.updateFile('S1');
  assert.equal(f.counts.barcode, 1);
  assert.ok(f.text.includes(',5449000000996|2100000000016,'), f.text);
});
test('"Aronium is right": its price comes into the app (managers only)', () => {
  feed('S1-T1', 'products', [P('C1', 'Coke 1.5L', 3.5, 2.1, 12.5)]);
  throws(() => AU.takeAronium(sita, 'S1', coke, 'price'), /manager/);
  AU.takeAronium(owner, 'S1', coke, 'price');
  assert.equal(I.itemAtShop(coke, 'S1').shopPrice, 3.5);
  assert.ok(!AU.compareShop('S1').rows.find((r) => r.code === 'C1').diffs.includes('price'));
  throws(() => AU.updateFile('S9'), /No product list/);
});
done();
