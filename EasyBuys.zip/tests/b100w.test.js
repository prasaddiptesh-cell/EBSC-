// 1.0.0 live sales from the till PCs: each receipt with how it was paid and refunds, the cash that should be in the
// till now (to balance any time), a notification when a till starts, no sales for a while while the shop is open,
// and sales while the shop is closed (Home warnings + watchdog). Odd data from a till PC never breaks anything.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared, deviceId } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as L from '../src/modules/aronium/link.js';
import * as SH from '../src/modules/till/salesHistory.js';
import * as SW from '../src/modules/till/salesWatch.js';
import * as T from '../src/modules/till/service.js';
import { alerts as tillAlerts } from '../src/modules/till/alerts.js';
import { runWatchdog } from '../src/services/watchdog.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const NOW = new Date('2026-10-31T10:30:00'); // a Saturday, local time
clock.override = NOW;
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
setShared('main_tablet_device', deviceId());
const utc = (ms) => new Date(ms).toISOString().replace('T', ' ').slice(0, 19);
const seen = utc(NOW.getTime() - 5 * 60000); // the till PC sent 5 minutes ago
const hours = { mon: { open: '07:00', close: '20:00' }, tue: { open: '07:00', close: '20:00' }, wed: { open: '07:00', close: '20:00' }, thu: { open: '07:00', close: '20:00' }, fri: { open: '07:00', close: '20:00' }, sat: { open: '07:00', close: '20:00' }, sun: { closed: true } };
if (!db().get("SELECT 1 AS x FROM shops WHERE code = 'S1'")) db().run("INSERT INTO shops (code, name, active, sort, updated_at, updated_device, sync_status) VALUES ('S1', 'Shop 1', 1, 1, '2026-10-01 00:00:00', 'x', 'synced')");
db().run("UPDATE shops SET hours = ?, active = 1 WHERE code = 'S1'", [JSON.stringify(hours)]);
db().run("UPDATE shops SET active = 0 WHERE code <> 'S1'");
T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 80 });

const feed = (kind, period, data, extra = '') => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?, 'S1-T1', 'S1', 'Shop 1, Till 1', ?, ?, 0, 1, ?, ?, '2026-10-31T00:00:00Z', '1.2', ?, 'x', 'synced')`, [`S1-T1|${kind}|${period}|0${extra}`, kind, period, JSON.stringify(data), `h-${kind}-${Math.random()}`, seen]);
const COLS = ['time', 'no', 'total', 'refund', 'pay', 'who', 'lines', 'pays', 'open'];
const receipts = (rows) => feed('receipts', '2026-10-31', { cols: COLS, rows });
feed('meta', 'all', { drawer: { opening: 100 }, counts: {} });
receipts([
  ['06:30:00', 'S-0', 12, 0, 'Cash', 'Ben', 1, 'Cash=12.00', 1], // before the shop opens
  ['07:05:10', 'S-1', 20, 0, 'Cash', 'Sita', 2, 'Cash=20.00', 1],
  ['08:15:00', 'S-2', 35, 0, 'Cash+M-PAiSA', 'Sita', 3, 'Cash=15.00;M-PAiSA=20.00', 1],
  ['08:40:00', 'R-1', 5, 1, 'Cash', 'Sita', 1, 'Cash=5.00', 1],
  ['bad', 'S-x', 'lots', 0, '', '', 0, '', 1], // a till PC that sends rubbish: skipped
]);

test('each receipt with how it was paid (each way and amount) and refunds – newest first, rubbish skipped', () => {
  const r = L.aroniumReceipts({ date: '2026-10-31' });
  assert.deepEqual(r.map((x) => x.no), ['R-1', 'S-2', 'S-1', 'S-0']);
  assert.equal(r[0].refund, true);
  assert.deepEqual(r[1].pays, [{ name: 'Cash', amount: 15 }, { name: 'M-PAiSA', amount: 20 }]);
  const d = SH.salesDay('2026-10-31', { shop: 'S1' });
  assert.equal(d.live.receipts, 3); assert.equal(d.live.sales, 67); assert.equal(d.live.refunds, 1); assert.equal(d.live.net, 62);
  const pay = Object.fromEntries(d.live.payments.map((p) => [p.name, p.amount]));
  assert.equal(pay.Cash, 42, 'cash 12 + 20 + 15 − 5 refunded'); assert.equal(pay['M-PAiSA'], 20);
  assert.equal(d.live.last, '08:40');
});
test('the cash that should be in the till now: float + cash sales − cash refunds (balance any time)', () => {
  const [t] = L.tillDrawer({ date: '2026-10-31' });
  assert.equal(t.float, 100); assert.equal(t.floatFrom, 'Aronium');
  assert.equal(t.cashSales, 47); assert.equal(t.cashRefunds, 5); assert.equal(t.expected, 142);
  assert.equal(t.refunds, 1); assert.equal(t.payments['M-PAiSA'], 20);
  // the balancing screen works it out the same way from what it is given
  assert.equal(T.workOut({ openingFloat: t.float, zCash: t.cashSales - t.cashRefunds, cashCounted: 142 }).overShort, 0);
  // no float from Aronium: the till's float in the app is used
  feed('meta', 'all', { counts: {} });
  const [u] = L.tillDrawer({ date: '2026-10-31' });
  assert.equal(u.float, 80); assert.equal(u.floatFrom, 'app'); assert.equal(u.expected, 122);
  // receipts already in an End of day are not in the drawer
  receipts([['07:05:10', 'S-1', 20, 0, 'Cash', 'Sita', 2, 'Cash=20.00', 0], ['08:15:00', 'S-2', 35, 0, 'Cash', 'Sita', 3, 'Cash=35.00', 1]]);
  assert.equal(L.tillDrawer({ date: '2026-10-31' })[0].cashSales, 35);
  feed('meta', 'all', { drawer: { opening: 100 }, counts: {} });
});
test('an older Aronium Link (names only, no amounts): still works, says it is not exact', () => {
  receipts([['07:05:10', 'S-1', 20, 0, 'Cash'], ['08:15:00', 'S-2', 35, 0, 'Cash+M-PAiSA']].map((r) => r.concat(['Sita', 1])));
  const [t] = L.tillDrawer({ date: '2026-10-31' });
  assert.equal(t.cashSales, 20, 'a split payment without amounts is not guessed');
  assert.equal(t.withAmounts, false);
});
test('a till has started: a notification (first hour and a half only)', () => {
  receipts([['06:58:00', 'S-1', 20, 0, 'Cash', 'Sita', 2, 'Cash=20.00', 1], ['08:15:00', 'S-2', 35, 0, 'Cash', 'Sita', 3, 'Cash=35.00', 1]]);
  const a = SW.salesWatchAlerts({ now: new Date('2026-10-31T07:30:00') });
  const st = a.find((x) => /has started/.test(x.text));
  assert.ok(st && st.notify && /06:58/.test(st.text), JSON.stringify(a));
  assert.ok(!SW.salesWatchAlerts({ now: new Date('2026-10-31T10:30:00') }).some((x) => /has started/.test(x.text)));
});
test('no sales for a while while the shop is open: a warning (with a phone notification) – not when closed', () => {
  const a = SW.salesWatchAlerts({ now: NOW });
  const q = a.find((x) => /No sales at Shop 1/.test(x.text));
  assert.ok(q && q.level === 'warning' && q.notify, JSON.stringify(a.map((x) => x.text)));
  assert.ok(/last at 08:15/.test(q.text) && /2 h 15 min/.test(q.text), q.text);
  assert.ok(/Is the till being used/.test(q.sub), 'the PC is sending, so the till is just not used');
  assert.ok(!SW.salesWatchAlerts({ now: new Date('2026-10-31T08:50:00') }).some((x) => /No sales/.test(x.text)), 'sold 35 minutes ago: fine');
  assert.ok(!SW.salesWatchAlerts({ now: new Date('2026-10-31T21:30:00') }).some((x) => /No sales/.test(x.text)), 'closed: no warning');
  assert.ok(!SW.salesWatchAlerts({ now: new Date('2026-11-01T11:00:00') }).some((x) => /No sales/.test(x.text)), 'closed on Sunday');
  // on Home for the manager and the owner
  assert.ok(tillAlerts(mgr).some((x) => /No sales at Shop 1/.test(x.text)));
});
test('the till PC is off while the shop is open: one warning about the PC (urgent after 2 hours), not about sales', () => {
  db().run("UPDATE aronium_feed SET updated_at = ?", [utc(NOW.getTime() - 3 * 3600000)]);
  assert.ok(!SW.salesWatchAlerts({ now: NOW }).some((x) => /No sales/.test(x.text)));
  const q = SW.linkWatchAlerts({ now: NOW }).find((x) => /has not sent anything/.test(x.text));
  assert.ok(q && q.level === 'urgent' && q.notify, JSON.stringify(q));
  db().run("UPDATE aronium_feed SET updated_at = ?", [utc(NOW.getTime() - 50 * 60000)]);
  assert.equal(SW.linkWatchAlerts({ now: NOW }).find((x) => /has not sent/.test(x.text)).level, 'warning', '50 minutes: a warning');
  assert.ok(!SW.linkWatchAlerts({ now: new Date('2026-10-31T22:00:00') }).length, 'closed: nothing');
  assert.ok(tillAlerts(mgr).filter((x) => /not sent/.test(x.text)).length === 1, 'not twice (the old 3-hour warning is for shops without hours)');
  db().run("UPDATE aronium_feed SET updated_at = ?", [seen]);
});
test('sending switched off or the Link removed on a till PC: urgent warning until it is started again', () => {
  const put = (event, at) => feed('notice', event, { event, at, who: 'cashier1', pc: 'TILL1' }, '');
  db().run("DELETE FROM aronium_feed WHERE kind = 'notice'");
  db().run("INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status) VALUES ('S1-T1|notice|stopped|0', 'S1-T1', 'S1', 'Shop 1, Till 1', 'notice', 'stopped', 0, 1, ?, 'n1', 'x', '1.0', ?, 'x', 'synced')",
    [JSON.stringify({ event: 'stopped', at: '2026-10-30T22:12:00.000Z', who: 'cashier1', pc: 'TILL1' }), seen]);
  const a = SW.linkWatchAlerts({ now: NOW }).find((x) => /switched off/.test(x.text));
  assert.ok(a && a.level === 'urgent' && a.notify && /cashier1/.test(a.sub), JSON.stringify(SW.linkWatchAlerts({ now: NOW })));
  db().run("INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status) VALUES ('S1-T1|notice|started|0', 'S1-T1', 'S1', 'Shop 1, Till 1', 'notice', 'started', 0, 1, ?, 'n2', 'x', '1.0', ?, 'x', 'synced')",
    [JSON.stringify({ event: 'started', at: '2026-10-30T22:20:00.000Z' }), seen]);
  assert.ok(!SW.linkWatchAlerts({ now: NOW }).some((x) => /switched off/.test(x.text)), 'started again: gone');
  db().run("INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status) VALUES ('S1-T1|notice|uninstalled|0', 'S1-T1', 'S1', 'Shop 1, Till 1', 'notice', 'uninstalled', 0, 1, ?, 'n3', 'x', '1.0', ?, 'x', 'synced')",
    [JSON.stringify({ event: 'uninstalled', at: '2026-10-30T22:30:00.000Z', who: 'cashier1' }), seen]);
  assert.ok(SW.linkWatchAlerts({ now: NOW }).some((x) => /REMOVED/.test(x.text)));
  db().run("DELETE FROM aronium_feed WHERE kind = 'notice'");
});
test('sales while the shop is closed: a warning and a watchdog finding for the owner', () => {
  receipts([['06:30:00', 'S-0', 12, 0, 'Cash', 'Ben', 1, 'Cash=12.00', 1], ['07:05:10', 'S-1', 20, 0, 'Cash', 'Sita', 2, 'Cash=20.00', 1]]);
  const a = SW.salesWatchAlerts({ now: NOW }).find((x) => /while the shop was closed/.test(x.text));
  assert.ok(a && /06:30/.test(a.text) && /Ben/.test(a.sub), JSON.stringify(a));
  const w = runWatchdog(owner, { now: '2026-10-31 10:30:00' });
  assert.ok(w.some((x) => x.check === 'sales_after_hours'), JSON.stringify(w.map((x) => x.check)));
  assert.ok(w.some((x) => x.check === 'sales_quiet'));
});
test('settings: managers choose how long (or off); staff cannot; off means no warning', () => {
  throws(() => SW.saveSalesWatch(sita, { quietMins: 30 }), /manager, the admin or the owner/);
  throws(() => SW.saveSalesWatch(mgr, { quietMins: 17 }), /how long/);
  SW.saveSalesWatch(mgr, { quietMins: 0, started: false, afterHours: false });
  const a = SW.salesWatchAlerts({ now: NOW });
  assert.ok(!a.some((x) => /No sales|closed|started/.test(x.text)), JSON.stringify(a));
  SW.saveSalesWatch(owner, { quietMins: 60 });
  assert.equal(SW.salesWatchSettings().quietMins, 60);
});
test('nothing from the till PCs, or junk in the feed: no warnings, no crash', () => {
  db().run("UPDATE aronium_feed SET data = '{not json' WHERE kind = 'receipts'");
  assert.doesNotThrow(() => SW.salesWatchAlerts({ now: NOW }));
  assert.doesNotThrow(() => SH.salesDay('2026-10-31'));
  db().run("DELETE FROM aronium_feed");
  assert.deepEqual(SW.salesWatchAlerts({ now: NOW }), []);
  assert.deepEqual(L.tillDrawer(), []);
});
done();
