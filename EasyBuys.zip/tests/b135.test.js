// v3.5 B1 – Bank, cash and M-PAiSA: two balances, ageing colours, history, mobile banking checks and reminder,
// wallets (till M-PAiSA in, transfers, fees), statement import (CSV / OFX / PDF text) with the 12 features,
// M-PAiSA statement import with column mapping and shift matching, month-end closing, reports, alerts.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import * as T from '../src/modules/till/service.js';
import * as P from '../src/modules/bank/position.js';
import * as I from '../src/modules/bank/importer.js';
import * as W from '../src/modules/bank/wallets.js';
import * as M from '../src/modules/bank/monthEnd.js';
import { alerts as bankAlerts } from '../src/modules/bank/alerts.js';
import { REPORTS } from '../src/modules/bank/reports.js';
import { MENU } from '../src/modules/bank/menu.js';
const SCREENS = ['BankRec', 'StatementNew', 'Statement', 'BankRules', 'BankCheck', 'BankChecks', 'BankImport', 'BankHistory', 'BankArchive', 'BankMonthEnd', 'Wallets', 'Wallet', 'WalletSetup', 'MpaisaImport', 'MpaisaMatch', 'MpaisaColumns', 'ReportsHub'];
const bankModule = { id: 'bank', menu: MENU, reports: REPORTS, screens: Object.fromEntries(SCREENS.map((n) => [n, {}])) };
import { checkMenu } from '../src/services/menus.js';
import { saveRecurring, runRecurring } from '../src/modules/payables/recurring.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (s) => { clock.override = new Date(s.replace(' ', 'T')); };
at('2026-10-10 10:00:00');
const owner = saveUser({ name: 'Divnesh Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
T.saveTillRules(owner, { ...T.tillRules(), requireZPhoto: false, managerApproves: false, requireSignatures: false });

let acc; let sup; let chq1; let chq2;
test('setup: one BSP account, cheque book, supplier paid by two cheques, two deposits from the shops', () => {
  acc = AP.saveAccount(owner, { name: 'BSP Business Cheque', openingBalance: 10000, openingDate: '2026-09-01' });
  AP.saveBook(owner, { accountUid: acc.uid, firstNo: 100200, lastNo: 100249 });
  sup = AP.saveSupplier(owner, { name: 'RB Patel Group', onAccount: true, termsDays: 7 });
  const i1 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'A1', invoiceDate: '2026-09-02', total: 300, shopCode: 'S1' }, { canCheck: true });
  const i2 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'A2', invoiceDate: '2026-10-05', total: 450, shopCode: 'S2' }, { canCheck: true });
  chq1 = AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acc.uid, chequeNo: 100200, payDate: '2026-09-03', allocations: [{ invoiceUid: i1.uid, amount: 300 }] });
  chq2 = AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acc.uid, chequeNo: 100201, payDate: '2026-10-06', allocations: [{ invoiceUid: i2.uid, amount: 450 }] });
  T.recordCash(owner, { shopCode: 'S1', type: 'opening', amount: 2000, date: '2026-09-01' });
  T.recordCash(owner, { shopCode: 'S2', type: 'opening', amount: 1000, date: '2026-09-01' });
  T.saveDeposit(owner, { shopCode: 'S1', accountUid: acc.uid, date: '2026-10-08', slipNo: '5551', cashAmount: 1200 });
  T.saveDeposit(owner, { shopCode: 'S2', accountUid: acc.uid, date: '2026-10-09', slipNo: '5552', cashAmount: 500 });
  assert.strictEqual(T.cashOnHand('S1').onHand, 800, 'deposit came off cash on hand');
  assert.strictEqual(P.mainAccount().uid, acc.uid);
});

test('two balances: in the bank now vs expected; in-transit deposits and unpresented cheques', () => {
  const p = P.moneyPosition(acc.uid);
  assert.strictEqual(p.book, 10000 - 300 - 450 + 1200 + 500);
  assert.strictEqual(p.expected, p.book);
  assert.strictEqual(p.inBank, 10000, 'nothing cleared yet → the bank still shows the opening balance');
  assert.strictEqual(p.cheques.length, 2);
  assert.strictEqual(p.ins.length, 2);
  assert.ok(p.ins.every((x) => x.transit), 'deposits are "in transit"');
  assert.deepStrictEqual(p.ins.map((x) => x.shop).sort(), ['S1', 'S2'], 'deposits tagged by shop');
});

test('ageing: amber, red after the verification days, stale after 6 months; rules editable', () => {
  const p = P.moneyPosition(acc.uid);
  const old = p.cheques.find((c) => c.no === 100200);
  const fresh = p.cheques.find((c) => c.no === 100201);
  assert.strictEqual(old.tone, 'red');
  assert.strictEqual(fresh.tone, 'amber');
  assert.strictEqual(P.ageTone('2026-03-01', '2026-10-10'), 'stale');
  assert.strictEqual(old.shop, 'S1', 'cheque tagged with the shop of the invoice it paid');
  P.saveBankSettings(owner, { ...P.bankSettings(), verifyDays: 60 });
  assert.strictEqual(P.moneyPosition(acc.uid).cheques.find((c) => c.no === 100200).tone, 'amber');
  P.saveBankSettings(owner, { ...P.bankSettings(), verifyDays: 7 });
  throws(() => P.saveBankSettings(owner, { ...P.bankSettings(), verifyDays: 0 }), /between/);
  assert.strictEqual(P.moneyPosition(acc.uid).red, 1);
});

test('cheque marked presented in the cheque module: one step, records who and the date; bank screens follow', () => {
  AP.markPresented(mgr, chq1.cheque_uid, '2026-09-10');
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [chq1.cheque_uid]);
  assert.strictEqual(c.presented_by_name, 'Anita Manager');
  assert.strictEqual(c.presented_date, '2026-09-10');
  const p = P.moneyPosition(acc.uid);
  assert.strictEqual(p.inBank, 9700);
  const h = P.bankHistory(acc.uid, {});
  const row = h.rows.find((r) => r.ref === '100200');
  assert.strictEqual(row.cleared, '2026-09-10');
  assert.strictEqual(row.clearedBy, 'Anita Manager');
  assert.ok(require('../src/modules/payables/schema.js').PAYABLES_SYNC.cheques.cols.includes('presented_by_name'), 'synced to the other devices');
});

test('history: running balance, search, shop filter, period', () => {
  const h = P.bankHistory(acc.uid, {});
  assert.strictEqual(h.rows[0].balance, h.closing, 'newest first, ends at the book balance');
  assert.strictEqual(h.closing, P.moneyPosition(acc.uid).book);
  assert.strictEqual(P.bankHistory(acc.uid, { q: '5552' }).rows.length, 1);
  assert.strictEqual(P.bankHistory(acc.uid, { q: '450.00' }).rows.length, 1);
  assert.ok(P.bankHistory(acc.uid, { shop: 'S2' }).rows.every((r) => r.shop === 'S2'));
  const oct = P.bankHistory(acc.uid, { from: '2026-10-01', to: '2026-10-31' });
  assert.strictEqual(oct.opening, 9700);
  assert.strictEqual(oct.rows.length, 3);
  const e = db().get("SELECT uid FROM bank_entries WHERE reference = 'Slip 5551'");
  P.tagShop(owner, 'entry', e.uid, 'S2');
  assert.strictEqual(P.bankHistory(acc.uid, { q: '5551' }).rows[0].shop, 'S2');
  P.tagShop(owner, 'entry', e.uid, 'S1');
});

test('check against mobile banking: match, difference with likely causes, history, reminder after 3 days (can be switched off)', () => {
  assert.ok(P.checkDue('bank', acc.uid).due, 'never checked → due');
  let r = P.checkBalance(owner, { kind: 'bank', accountUid: acc.uid, typed: 9700 });
  assert.strictEqual(r.result, 'match');
  assert.ok(!P.checkDue('bank', acc.uid).due);
  r = P.checkBalance(owner, { kind: 'bank', accountUid: acc.uid, typed: 10900 });
  assert.strictEqual(r.diff, 1200);
  assert.ok(r.causes[0].includes('slip 5551'), r.causes[0]);
  r = P.checkBalance(owner, { kind: 'bank', accountUid: acc.uid, typed: 9250 });
  assert.ok(r.causes[0].includes('Cheque 100201'), 'the cheque has probably been presented');
  r = P.checkBalance(owner, { kind: 'bank', accountUid: acc.uid, typed: 9688.5 });
  assert.ok(r.causes.some((c) => /fees/.test(c)));
  r = P.checkBalance(owner, { kind: 'bank', accountUid: acc.uid, typed: 9709 });
  assert.ok(r.causes.some((c) => /divides by 9/.test(c)));
  assert.strictEqual(P.listChecks('bank', acc.uid).length, 5);
  at('2026-10-13 09:00:00');
  assert.ok(P.checkDue('bank', acc.uid).due, 'due again after 3 days');
  assert.ok(bankAlerts(owner).some((a) => a.id === 'bank-mobile-check'));
  P.saveBankSettings(owner, { ...P.bankSettings(), mobileCheckOn: false });
  assert.ok(!bankAlerts(owner).some((a) => a.id === 'bank-mobile-check'));
  P.saveBankSettings(owner, { ...P.bankSettings(), mobileCheckOn: true, mobileCheckDays: 5 });
  assert.ok(!P.checkDue('bank', acc.uid).due);
  at('2026-10-10 10:00:00');
});

let s1; let s2;
test('wallets: two M-PAiSA wallets (one per shop), till M-PAiSA sales go in; admin can add MyCash', () => {
  W.ensureDefaultWallets(); W.ensureDefaultWallets();
  assert.strictEqual(W.listWallets().length, 2);
  s1 = W.getWallet('WAL-MPAISA-S1'); s2 = W.getWallet('WAL-MPAISA-S2');
  at('2026-10-08 10:00:00');
  T.saveTillCount(owner, { shopCode: 'S1', shiftDate: '2026-10-08', shift: 'Morning', zCash: 500, denominations: { n100: 5 }, floatKept: 0, tenders: [{ method: 'M-PAiSA', amount: 120 }] });
  at('2026-10-08 22:00:00');
  T.saveTillCount(owner, { shopCode: 'S1', shiftDate: '2026-10-08', shift: 'Night', zCash: 100, denominations: { n100: 1 }, floatKept: 0, tenders: [{ method: 'M-PAiSA', amount: 80 }] });
  at('2026-10-10 10:00:00');
  T.saveTillCount(owner, { shopCode: 'S2', shiftDate: '2026-10-09', shift: 'Morning', zCash: 0, cashCounted: 0, floatKept: 0, tenders: [{ method: 'M-PAiSA', amount: 300 }, { method: 'EFTPOS / card', amount: 50 }] });
  assert.strictEqual(W.walletSales(s1.uid, '2026-10-01', '2026-10-31').length, 2);
  assert.strictEqual(W.walletPosition(s1.uid).balance, 200);
  assert.strictEqual(W.walletPosition(s2.uid).balance, 300);
  const my = W.saveWallet(owner, { name: 'MyCash Shop 1', provider: 'MyCash', shopCode: 'S1', openingDate: '2026-10-01' });
  assert.strictEqual(W.walletPosition(my.uid).balance, 0, 'M-PAiSA sales do not go into MyCash');
  W.saveWallet(owner, { ...my, uid: my.uid, shopCode: my.shop_code, openingDate: my.opening_date, active: false });
  assert.strictEqual(W.listWallets().length, 2);
  assert.ok(can(mgr, 'wallets'));
});

let wt;
test('wallet transfer to BSP: leaves the wallet with its fee, arrives in the bank as in transit; fees; corrections need a reason from others', () => {
  wt = W.recordWalletTransfer(owner, { walletUid: s1.uid, date: '2026-10-09', amount: 150, fee: 1.5, accountUid: acc.uid, reference: 'MP123' });
  assert.strictEqual(W.walletPosition(s1.uid).balance, 48.5);
  assert.strictEqual(W.walletPosition(s1.uid).transitTotal, 150);
  const p = P.moneyPosition(acc.uid);
  const e = p.ins.find((x) => x.uid === `BE-WT-${wt}`);
  assert.ok(e && e.transit && e.shop === 'S1');
  throws(() => W.recordWalletMove(mgr, { walletUid: s2.uid, type: 'adjust_out', amount: 5 }), /reason/);
  W.recordWalletMove(owner, { walletUid: s2.uid, type: 'fee', amount: 0.5, date: '2026-10-09', note: 'Monthly fee' });
  assert.strictEqual(W.walletPosition(s2.uid).balance, 299.5);
  const h = W.walletHistory(s1.uid);
  assert.strictEqual(h.rows[0].balance, 48.5);
  const r = P.checkBalance(mgr, { kind: 'wallet', accountUid: s1.uid, typed: 48.5 });
  assert.strictEqual(r.result, 'match');
});

test('statement readers: BSP CSV (debit/credit/balance), OFX, PDF text with balances, dates', () => {
  assert.strictEqual(I.readDate('08/10/2026'), '2026-10-08');
  assert.strictEqual(I.readDate('10/08/2026', 'mdy'), '2026-10-08');
  assert.strictEqual(I.readDate('8 Oct 2026'), '2026-10-08');
  assert.strictEqual(I.readDate('20261008120000'), '2026-10-08');
  assert.strictEqual(I.readDate('31/02/2026x'), null);
  const csv = 'Date,Description,Reference,Debit,Credit,Balance\n09/10/2026,DEPOSIT,5551,,1200.00,10900.00\n10/10/2026,CHQ 100201,100201,450.00,,10450.00\n';
  const c = I.readBankStatement(csv);
  assert.strictEqual(c.format, 'csv');
  assert.deepStrictEqual(c.lines.map((l) => l.amount), [1200, -450]);
  assert.strictEqual(c.opening, 9700); assert.strictEqual(c.closing, 10450);
  assert.strictEqual(c.lines[1].reference, '100201');
  const ofx = 'OFXHEADER:100\n<OFX><BANKTRANLIST><DTSTART>20261001<DTEND>20261010\n<STMTTRN><TRNTYPE>DEBIT<DTPOSTED>20261005<TRNAMT>-12.50<NAME>SERVICE FEE</STMTTRN>\n<STMTTRN><TRNTYPE>CHECK<DTPOSTED>20261007<TRNAMT>-450.00<CHECKNUM>100201<NAME>CHEQUE</STMTTRN>\n</BANKTRANLIST><LEDGERBAL><BALAMT>9237.50<DTASOF>20261010</LEDGERBAL></OFX>';
  const o = I.readBankStatement(ofx);
  assert.strictEqual(o.format, 'ofx');
  assert.strictEqual(o.lines.length, 2);
  assert.strictEqual(o.lines[1].reference, '100201');
  assert.strictEqual(o.closing, 9237.5);
  assert.strictEqual(o.fromDate, '2026-10-01');
  const pdf = 'BSP Statement of account\nBalance brought forward 9,700.00\n05 Oct 2026 SERVICE FEE 12.50 9,687.50\n08 Oct 2026 DEPOSIT 5551 1,200.00 10,887.50\n';
  const t = I.readBankStatement(pdf);
  assert.strictEqual(t.format, 'text');
  assert.deepStrictEqual(t.lines.map((l) => l.amount), [-12.5, 1200]);
  assert.strictEqual(t.opening, 9700); assert.strictEqual(t.closing, 10887.5);
});

let st;
test('import: cheques cleared, deposits confirmed, slip difference flagged, M-PAiSA transfer confirmed, fees and interest booked, unknown cheque, loan, missing line, duplicate, unusual', () => {
  // A loan with its bill waiting.
  const bspL = AP.saveSupplier(owner, { name: 'BSP Loans', onAccount: true });
  const lr = saveRecurring(owner, { kind: 'loan', name: 'Drasa Avenue loan', supplierUid: bspL.uid, amount: 800, frequency: 'monthly', nextDate: '2026-10-07', loanNo: 'LN7788', leadDays: 30, openingBalance: 50000, openingDate: '2026-09-01' });
  runRecurring(owner);
  assert.ok(db().get("SELECT 1 AS x FROM ap_invoices WHERE uid LIKE 'RI-%'"), 'loan bill made');
  const text = [
    'Date,Description,Reference,Debit,Credit,Balance',
    '01/10/2026,OPENING,,,,',
    '03/10/2026,ACCOUNT SERVICE FEE,,12.50,,9687.50',
    '06/10/2026,CREDIT INTEREST,,,2.10,9689.60',
    '07/10/2026,CHQ 100201,100201,450.00,,9239.60',
    '07/10/2026,LOAN REPAYMENT LN7788,,800.00,,8439.60',
    '08/10/2026,DEPOSIT SLIP 5551,,,1190.00,9629.60',
    '09/10/2026,MPAISA TRANSFER MP123,,,150.00,9779.60',
    '09/10/2026,CHQ 100230,100230,75.00,,9704.60',
    '09/10/2026,DIRECT DEBIT FIJI WATER AUTH,,95.00,,9609.60',
    '09/10/2026,DIRECT DEBIT FIJI WATER AUTH,,95.00,,9514.60',
    '10/10/2026,TT TRANSFER IN OVERSEAS,,,8000.00,17514.60',
  ].join('\n');
  const r = I.importBankStatement(owner, { accountUid: acc.uid, text, fromDate: '2026-10-01', toDate: '2026-10-10' });
  st = r.uid;
  const s = r.summary;
  assert.strictEqual(r.added, 10);
  assert.strictEqual(s.cheques, 1, '1: cheque 100201 cleared');
  assert.strictEqual(db().get('SELECT status FROM cheques WHERE uid = ?', [chq2.cheque_uid]).status, 'presented');
  assert.strictEqual(s.mpaisa, 1, '3: M-PAiSA transfer confirmed');
  assert.ok(db().get('SELECT cleared_date FROM bank_entries WHERE uid = ?', [`BE-WT-${wt}`]).cleared_date);
  assert.strictEqual(s.fees, 2, '6: fee and interest booked');
  assert.strictEqual(db().get("SELECT gl_code FROM bank_entries WHERE type = 'fee' AND entry_date = '2026-10-03'").gl_code, '6600');
  assert.strictEqual(s.slipDiffs, 1, '2: slip 5551 differs');
  assert.strictEqual(s.unknownCheques, 1, '7: cheque 100230 unknown');
  assert.strictEqual(s.loans, 1, '5: loan repayment found');
  assert.ok(s.duplicates >= 2, '8: the same debit twice');
  assert.ok(s.unusual >= 1, '9: 8000 is unusual');
  assert.ok(s.missing >= 1, '4: lines missing from the app');
  const lines = db().all('SELECT * FROM bank_lines WHERE statement_uid = ?', [st]);
  const flag = (desc, code) => I.lineFlags(lines.find((l) => l.description && l.description.includes(desc))).some((f) => f.code === code);
  assert.ok(flag('100230', 'unknown_cheque') && flag('SLIP 5551', 'slip_diff') && flag('LN7788', 'loan') && flag('FIJI WATER', 'duplicate') && flag('OVERSEAS', 'unusual'));
  assert.ok(lines.find((l) => l.description === 'CHQ 100201').shop_code === 'S2', 'matched cheque tagged with its shop');
  assert.ok(bankAlerts(owner).some((a) => a.id === 'bank-flags-urgent'), 'unknown cheque shows on Home');
  void lr;
});

test('one-tap actions: slip difference, loan repayment, missing line remembered as a rule, review warnings; re-import skips lines already in', () => {
  const l = (d) => db().get('SELECT * FROM bank_lines WHERE statement_uid = ? AND description LIKE ?', [st, `%${d}%`]);
  I.acceptSlipDifference(owner, l('SLIP 5551').uid, 'Bank counted $10 less');
  assert.strictEqual(l('SLIP 5551').status, 'matched');
  assert.ok(db().get("SELECT 1 AS x FROM bank_entries WHERE type = 'adjust_out' AND amount = 10"));
  I.matchLoanLine(owner, l('LN7788').uid);
  assert.strictEqual(l('LN7788').status, 'matched');
  const water = db().all('SELECT * FROM bank_lines WHERE statement_uid = ? AND description LIKE ? ORDER BY uid', [st, '%FIJI WATER%']);
  I.recordMissing(owner, water[0].uid, { type: 'transfer_out', glCode: '6400', shop: 'S1', remember: true });
  assert.ok(require('../src/modules/bank/extras.js').bankRules().some((r) => r.contains === 'DIRECT DEBIT FIJI'), 'payee remembered');
  assert.strictEqual(db().get('SELECT shop_code FROM bank_lines WHERE uid = ?', [water[0].uid]).shop_code, 'S1');
  I.reviewFlags(owner, water[1].uid);
  assert.ok(db().get('SELECT flags_ok_by FROM bank_lines WHERE uid = ?', [water[1].uid]).flags_ok_by);
  // Mid-month import then the full statement: lines already in are skipped.
  const again = I.importBankStatement(owner, { accountUid: acc.uid, text: 'Date,Description,Debit,Credit\n03/10/2026,ACCOUNT SERVICE FEE,12.50,\n11/10/2026,ACCOUNT SERVICE FEE,1.00,', fromDate: '2026-10-01', toDate: '2026-10-11', closing: 0 });
  assert.strictEqual(again.already, 1);
  assert.strictEqual(again.added, 1);
});

test('M-PAiSA columns set by the admin', () => {
  const cols = W.saveWalletColumns(owner, 'M-PAiSA', { ...W.walletColumns('M-PAiSA'), date: 'txn date', time: 'txn time', amountIn: 'paid in', amountOut: 'withdrawn', reference: 'receipt no' });
  const csv = 'Txn Date,Txn Time,Details,Receipt No,Paid In,Withdrawn,Balance\n08/10/2026,09:15,Payment received from 7712345,R1,70.00,,70.00\n08/10/2026,13:40,Payment received from 9912345,R2,50.00,,120.00\n08/10/2026,20:10,Payment received from 7000001,R3,30.00,,150.00\n09/10/2026,08:00,Transfer to BSP account,T1,,150.00,0.00\n09/10/2026,08:00,Transaction fee,F1,,1.50,-1.50';
  const r = W.parseWalletCsv(csv, cols);
  assert.strictEqual(r.lines.length, 5);
  assert.deepStrictEqual(r.lines.map((l) => l.kind), ['receipt', 'receipt', 'receipt', 'transfer', 'fee']);
  assert.strictEqual(r.lines[0].time, '09:15');
  const imp = W.importWalletStatement(owner, { walletUid: s1.uid, lines: r.lines, fromDate: '2026-10-01', toDate: '2026-10-09', source: 'csv' });
  assert.strictEqual(imp.added, 5);
  assert.strictEqual(imp.transfers, 1);
  assert.strictEqual(imp.fees, 1, 'fee matched to the one recorded with the transfer');
  // Shifts: Morning till said 120 M-PAiSA (counted 10:00), Night 80 (counted 22:00). Wallet: 70 + 50 before 22:00? 09:15 and 13:40 → morning? No:
  // receipts go to the next balance after them: 09:15 → Morning (10:00); 13:40 and 20:10 → Night (22:00).
  const days = W.shiftMatch(s1.uid, '2026-10-08', '2026-10-08');
  assert.strictEqual(days.length, 1);
  const d = days[0];
  assert.ok(d.perShift);
  assert.strictEqual(d.shifts[0].walletAmount, 70);
  assert.strictEqual(d.shifts[0].status, 'short', 'morning: till 120, wallet 70 → fake payment message?');
  assert.strictEqual(d.shifts[1].walletAmount, 80);
  assert.strictEqual(d.shifts[1].status, 'ok');
  assert.ok(bankAlerts(owner).some((a) => a.id === `wallet-short-${s1.uid}` && a.level === 'urgent'));
  throws(() => W.explainShift(mgr, d.shifts[0].countUid, ''), /Write what happened/);
  W.explainShift(mgr, d.shifts[0].countUid, 'Customer showed a fake message – reported to police');
  assert.strictEqual(W.shiftMatch(s1.uid, '2026-10-08', '2026-10-08')[0].status, 'explained');
  W.confirmShiftMatches(owner, s1.uid, '2026-10-01', '2026-10-09');
  assert.ok(!bankAlerts(owner).some((a) => a.id === `wallet-short-${s1.uid}`));
  // Same statement again: nothing doubled.
  assert.strictEqual(W.importWalletStatement(owner, { walletUid: s1.uid, lines: r.lines, source: 'csv' }).added, 0);
  // Text from a PDF / screenshot
  const t = W.parseWalletText('09/10/2026 10:05 Payment received from 7712345 300.00 300.00\n09/10/2026 Sent to 7799 20.00 280.00');
  assert.deepStrictEqual(t.lines.map((l) => l.amount), [300, -20]);
  const imp2 = W.importWalletStatement(owner, { walletUid: s2.uid, lines: t.lines.slice(0, 1), source: 'ocr' });
  assert.strictEqual(imp2.shiftsOk, 1, 'S2 Morning 300 matches the 300 received');
});

test('month end: checklist (full statement, balance equals, sorted, warnings, M-PAiSA, report) and closing', () => {
  at('2026-11-02 09:00:00');
  let m = M.bankMonthEnd('2026-10', acc.uid);
  assert.strictEqual(m.items.length, 6);
  assert.ok(!m.items.find((i) => i.key === 'statement').ok, 'statement only to the 11th');
  throws(() => M.closeBankMonth(owner, '2026-10', acc.uid, 'DOC1'), /Not ready/);
  assert.ok(M.bankMonthEndItems('2026-10').every((i) => i.key.startsWith('bank35_')));
  const A = require('../src/modules/accounting/service.js');
  assert.ok(A.monthEndChecklist('2026-10').auto.some((i) => i.key === 'bank35_statement'), 'part of the month-end closing checklist');
  const rep = M.reconciliationReport('2026-10-01', '2026-10-31', acc.uid);
  assert.strictEqual(rep.summary[0].label, 'In the bank now');
  assert.ok(rep.sections.some((s) => s.title === 'Cheques not yet presented'));
  assert.ok(rep.sections.find((s) => s.title === 'Month-end checklist').rows.length === 6);
  at('2026-10-10 10:00:00');
});

test('reports registered (reconciliation, charges, checks, wallets, history) and build; forecast gets real bank fees', () => {
  const ids = bankModule.reports.map((r) => r.id);
  for (const id of ['bank_rec', 'bank_rec35', 'bank_charges', 'bank_checks', 'bank_wallets', 'bank_history']) assert.ok(ids.includes(id), id);
  for (const r of bankModule.reports) { const x = r.build('2026-10-01', '2026-10-31', owner); assert.ok(x.title && Array.isArray(x.sections), r.id); }
  const ch = M.bankChargesReport('2026-10-01', '2026-10-31');
  assert.ok(ch.sections[1].rows.length >= 3, 'bank fee + transfer fee + wallet fee');
  const f = P.bankForecastFigures();
  assert.ok(f.weeklyFees > 0);
  const { cashForecast } = require('../src/modules/accounting/statements.js');
  const fc = cashForecast({ weeks: 2 });
  assert.ok(fc.weeks[0].fees > 0, 'the forecast takes the real bank charges');
});

test('menu: every feature is its own menu item; screens exist; alerts are valid', () => {
  const problems = checkMenu(bankModule, Object.keys(bankModule.screens));
  assert.deepStrictEqual(problems, []);
  const items = bankModule.menu.flatMap((s) => s.items.map((i) => i.id));
  for (const id of ['home', 'bank-check', 'bank-import', 'bank-history', 'bank-wallets', 'mpaisa-import', 'mpaisa-match', 'bank-month', 'bank-archive', 'bank-rules', 'mpaisa-columns', 'wallet-setup']) assert.ok(items.includes(id), id);
  for (const a of bankAlerts(owner)) { assert.ok(['urgent', 'warning', 'info'].includes(a.level) && a.text && a.nav && a.nav.screen, a.id); assert.ok(bankModule.screens[a.nav.screen], a.nav.screen); }
});

test('GL: wallet fees booked as bank fees against money on the way', () => {
  const A = require('../src/modules/accounting/service.js');
  const e = A.entries({ from: '2026-10-01', to: '2026-10-31' }).filter((x) => x.src === 'Wallet');
  assert.ok(e.length >= 2);
  assert.ok(e.every((x) => Math.abs(x.lines.reduce((s, l) => s + l.amount, 0)) < 0.005), 'balanced');
});

test('Excel: cells read from the sheet (shared strings, numbers, dates)', () => {
  const { sheetRows } = require('../src/modules/bank/xlsx.js');
  const ss = '<sst><si><t>Date</t></si><si><t>Details</t></si><si><t>Paid In</t></si><si><t>Payment &amp; more</t></si></sst>';
  const sheet = '<sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c><c r="C1" t="s"><v>2</v></c></row><row r="2"><c r="A2" s="3"><v>46303</v></c><c r="B2" t="s"><v>3</v></c><c r="D2"><v>70.5</v></c></row></sheetData>';
  const rows = sheetRows(sheet, ss);
  assert.deepStrictEqual(rows[0], ['Date', 'Details', 'Paid In']);
  assert.strictEqual(rows[1][0], '08/10/2026');
  assert.strictEqual(rows[1][1], 'Payment & more');
  assert.strictEqual(rows[1][2], '');
  assert.strictEqual(rows[1][3], '70.5');
  const r = W.walletRowsToLines([['Date', 'Details', 'Paid In'], ['08/10/2026', 'Payment received', '70.50']], W.COLUMN_DEFAULTS);
  assert.strictEqual(r.lines[0].amount, 70.5);
});

done();
