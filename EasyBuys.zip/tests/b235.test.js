// v3.5 B2: cheques, invoices and supplier statements – photo screen supplier / PO, cheque handed over checks,
// cheque books & stubs, cheque book report, supplier statement.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as CB from '../src/modules/payables/chequebooks.js';
import { supplierStatement, statementSummary } from '../src/modules/payables/statement.js';
import { checkStatement } from '../src/modules/payables/extras.js';
import { REPORTS } from '../src/modules/payables/reports.js';
import { alerts } from '../src/modules/payables/alerts.js';
import { MENU } from '../src/modules/payables/menu.js';
import * as V from '../src/modules/verify/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T10:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const sam = saveUser({ name: 'Sam Cashier', pin: '4321', role: 'staff', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP Business Cheque', openingBalance: 5000, openingDate: '2026-09-01' });
const rb = AP.saveSupplier(owner, { name: 'RB Patel Group', tin: '500012345', onAccount: true, termsDays: 14 });
const photo = ['file:///p.jpg'];
const r2 = (n) => Math.round(n * 100) / 100;
const rep = (id) => REPORTS.find((r) => r.id === id);

let book;
test('cheque books: serial, leaf range, date received, holder, status (lost needs a reason for staff, not owner)', () => {
  book = AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100201, lastNo: 100250, receivedDate: '2026-09-01', serial: 'BK-77', holder: 'Divnesh (office safe)' });
  const spare = AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100251, lastNo: 100300, receivedDate: '2026-09-01', status: 'spare' });
  const list = CB.listAllBooks();
  assert.strictEqual(list.length, 2);
  const b = list.find((x) => x.uid === book);
  assert.strictEqual(b.serial, 'BK-77');
  assert.strictEqual(b.holder, 'Divnesh (office safe)');
  assert.strictEqual(b.status, 'in_use');
  assert.strictEqual(b.leavesCount, 50);
  assert.strictEqual(list.find((x) => x.uid === spare).statusLabel, 'Not started (spare)');
  throws(() => AP.saveBook(mgr, { uid: spare, accountUid: acct.uid, firstNo: 100251, lastNo: 100300, status: 'lost' }), /what happened/);
  AP.saveBook(owner, { uid: spare, accountUid: acct.uid, firstNo: 100251, lastNo: 100300, status: 'lost' }); // owner: no reason needed
  assert.strictEqual(CB.listAllBooks({ status: 'lost' }).length, 1);
  assert.strictEqual(db().get('SELECT active FROM cheque_books WHERE uid = ?', [spare]).active, 0, 'lost book is not active');
  AP.saveBook(owner, { uid: spare, accountUid: acct.uid, firstNo: 100251, lastNo: 100300, status: 'spare' });
  assert.strictEqual(AP.nextChequeNo(acct.uid), 100201);
});

let inv1; let inv2; let pay1;
test('stub record: payee, amount, invoices, who wrote it, stub photo flagged missing until added, cleared date', () => {
  inv1 = AP.saveInvoice(owner, { supplierUid: rb.uid, invoiceNo: 'RB-1', total: 450, invoiceDate: '2026-09-20' }, { canCheck: true });
  inv2 = AP.saveInvoice(owner, { supplierUid: rb.uid, invoiceNo: 'RB-2', total: 225, invoiceDate: '2026-10-02' }, { canCheck: true });
  pay1 = AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100201, payDate: '2026-10-01', allocations: [{ invoiceUid: inv1.uid, amount: 450 }] });
  const s = CB.getStub({ accountUid: acct.uid, chequeNo: 100201 });
  assert.strictEqual(s.payee, 'RB Patel Group');
  assert.strictEqual(s.amount, 450);
  assert.strictEqual(s.writtenBy, 'Divnesh Prasad');
  assert.deepStrictEqual(s.invoices.map((i) => i.invoice_no), ['RB-1']);
  assert.ok(s.photoMissing, 'no stub photo yet');
  assert.strictEqual(CB.listAllBooks().find((b) => b.uid === book).noStubPhoto, 1);
  const s2 = CB.saveStub(owner, s.cheque.uid, { photos: photo, note: 'Stub signed' });
  assert.ok(!s2.photoMissing && s2.hasPhoto);
  assert.strictEqual(s2.stubNote, 'Stub signed');
  assert.ok(db().get("SELECT 1 AS x FROM photos WHERE ref_type = 'stub' AND ref_id = ?", [s.cheque.uid]));
  // presented: the one-tap mark still works (B1 reads it)
  AP.markPresented(owner, s.cheque.uid, '2026-10-05');
  assert.strictEqual(CB.getStub({ chequeUid: s.cheque.uid }).cleared, '2026-10-05');
  AP.markPresented(owner, s.cheque.uid, null);
  assert.strictEqual(CB.getStub({ chequeUid: s.cheque.uid }).cleared, null);
  const unused = CB.getStub({ accountUid: acct.uid, chequeNo: 100210 });
  assert.strictEqual(unused.status, 'unused');
  assert.strictEqual(unused.cheque, null);
});

test('cheque handed over: drop-down lists cheques written for the supplier plus the next unused number', () => {
  const ch = CB.chequeChoices(rb.uid);
  assert.ok(ch.some((c) => c.chequeNo === 100201 && c.chequeUid), 'written cheque listed');
  assert.ok(ch.some((c) => c.chequeNo === 100202 && !c.chequeUid && /next unused/.test(c.label)), 'next unused listed');
  assert.strictEqual(ch[ch.length - 1].value, 'type');
});

test('cheque handed over: checks – recorded, already handed, other payee, not in a book, typed not recorded, spoiled', () => {
  const other = AP.saveSupplier(owner, { name: 'Motibhai & Company' });
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '100201', supplierUid: rb.uid }).state, 'recorded');
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '100201', supplierUid: other.uid }).state, 'other_payee');
  assert.strictEqual(CB.checkChequeNo({ chequeNo: 'abc' }).state, 'invalid');
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '999999', supplierUid: rb.uid }).state, 'not_in_book');
  const u = CB.checkChequeNo({ chequeNo: '100205', supplierUid: rb.uid });
  assert.strictEqual(u.state, 'unrecorded');
  assert.ok(/100202–100204 before it are not used yet/.test(u.message), u.message);
  AP.spoilCheque(owner, { accountUid: acct.uid, chequeNo: 100251, reason: 'torn' });
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '100251' }).state, 'spoiled');
  // a recorded cheque handed over through the photo screen gets the hand-over details; a second time is flagged
  const s = V.snap(sam, { kind: 'cheque_given', shopCode: 'S2', supplierUid: rb.uid, chequeUid: CB.getStub({ accountUid: acct.uid, chequeNo: 100201 }).cheque.uid, collectedBy: 'Ravi (driver)', photos: photo });
  assert.strictEqual(s.check.state, 'recorded');
  const stub = CB.getStub({ accountUid: acct.uid, chequeNo: 100201 });
  assert.strictEqual(stub.handedTo, 'Ravi (driver)');
  assert.strictEqual(stub.handedBy, 'Sam Cashier');
  assert.strictEqual(V.getSnap(s.uid).link_table, 'cheques');
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '100201', supplierUid: rb.uid }).state, 'handed');
  assert.ok(!CB.chequeChoices(rb.uid).some((c) => c.chequeNo === 100201 && c.chequeUid), 'handed cheques leave the drop-down');
});

let typedSnap;
test('typed number not recorded: goes to To verify with the ticked invoices; skipped numbers still flagged; recording the payment links it', () => {
  typedSnap = V.snap(sam, { kind: 'cheque_given', shopCode: 'S2', supplierUid: rb.uid, refNo: '100205', amount: 225, invoiceUids: [inv2.uid], collectedBy: 'Ravi', photos: photo });
  assert.strictEqual(typedSnap.check.state, 'unrecorded');
  const sn = V.getSnap(typedSnap.uid);
  assert.strictEqual(sn.cheque_no, 100205);
  assert.deepStrictEqual(JSON.parse(sn.invoice_uids), [inv2.uid]);
  const q = V.queue().find((x) => x.key === `cheque_unrecorded:${typedSnap.uid}`);
  assert.ok(q, 'on To verify');
  assert.strictEqual(q.how, 'record');
  assert.strictEqual(q.go[0], 'ApPay');
  assert.deepStrictEqual(q.go[1].invoiceUids, [inv2.uid]);
  const leaves = AP.bookLeaves(book);
  assert.strictEqual(leaves.leaves.find((l) => l.no === 100205).status, 'handed');
  assert.deepStrictEqual(leaves.leaves.filter((l) => l.status === 'skipped').map((l) => l.no), [100202, 100203, 100204]);
  assert.strictEqual(AP.nextChequeNo(acct.uid), 100206, 'the handed-over number is not offered again');
  assert.strictEqual(CB.checkChequeNo({ chequeNo: '100205', supplierUid: rb.uid }).state, 'snapped');
  assert.ok(alerts(owner).some((a) => a.id === 'ap-cheque-unrecorded'));
  assert.ok(alerts(owner).some((a) => a.id === 'ap-skipped'));
  // the office records the payment with that number
  AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100205, payDate: '2026-10-06', allocations: [{ invoiceUid: inv2.uid, amount: 225 }] });
  assert.ok(!V.queue().some((x) => x.key === `cheque_unrecorded:${typedSnap.uid}`), 'gone from To verify');
  const st = CB.getStub({ accountUid: acct.uid, chequeNo: 100205 });
  assert.strictEqual(st.handedTo, 'Ravi');
  assert.strictEqual(V.getSnap(typedSnap.uid).link_table, 'cheques');
  assert.strictEqual(AP.bookLeaves(book).skipped, 3, 'skipped numbers still flagged');
  assert.ok(!alerts(owner).some((a) => a.id === 'ap-cheque-unrecorded'));
});

test('not in any book: stays on To verify (add the book first)', () => {
  const s = V.snap(sam, { kind: 'cheque_given', shopCode: 'S2', party: 'RB Patel Group', refNo: '777001', collectedBy: 'Ravi', photos: photo });
  assert.strictEqual(s.check.state, 'not_in_book');
  const q = V.queue().find((x) => x.key === `cheque_unrecorded:${s.uid}`);
  assert.ok(q && q.notInBook && q.go[0] === 'ChequeBooks');
  V.rejectSnap(owner, s.uid, 'Wrong number typed');
  assert.ok(!V.queue().some((x) => x.key === `cheque_unrecorded:${s.uid}`));
});

test('customer cheque received stays free text', () => {
  const r = V.snap(sam, { kind: 'cheque_received', shopCode: 'S2', party: 'Mr Khan (customer)', refNo: '445566', amount: 80, photos: photo });
  const s = V.getSnap(r.uid);
  assert.strictEqual(s.party, 'Mr Khan (customer)');
  assert.strictEqual(s.ref_no, '445566');
  assert.strictEqual(s.supplier_uid, null);
  assert.ok(!AP.listSuppliers().some((x) => /Khan/.test(x.name)), 'no supplier made for a customer');
});

test('photo of invoice: supplier chosen, or a typed new one flagged "add properly"; PO chosen after the supplier', () => {
  const now = clock.now().toISOString();
  db().run(`INSERT INTO po_orders (uid, po_no, supplier_uid, supplier_name, shop_code, order_date, status, total, updated_at) VALUES ('PO1','PO-0001',?,?, 'S2','2026-10-05','sent',300,?)`, [rb.uid, rb.name, now]);
  db().run(`INSERT INTO po_orders (uid, po_no, supplier_uid, supplier_name, shop_code, order_date, status, total, updated_at) VALUES ('PO2','PO-0002',?,?, 'S2','2026-10-05','draft',10,?)`, [rb.uid, rb.name, now]);
  assert.deepStrictEqual(AP.posForSupplier(rb.uid).map((p) => p.po_no), ['PO-0001'], 'drafts are not offered');
  const a = V.snap(sam, { kind: 'invoice', shopCode: 'S2', supplierUid: rb.uid, poUid: 'PO1', refNo: 'RB-3', amount: 300, photos: photo });
  const inv = AP.getInvoice(a.linkUid);
  assert.strictEqual(inv.supplier_uid, rb.uid);
  assert.strictEqual(inv.po_uid, 'PO1');
  assert.strictEqual(V.getSnap(a.uid).po_uid, 'PO1');
  const other = AP.listSuppliers().find((s) => s.name === 'Motibhai & Company');
  throws(() => V.snap(sam, { kind: 'invoice', shopCode: 'S2', supplierUid: other.uid, poUid: 'PO1', refNo: 'M-1', amount: 5, photos: photo }), /different supplier/);
  const b = V.snap(sam, { kind: 'invoice', shopCode: 'S2', party: 'Island Fresh Eggs', refNo: 'E-9', amount: 60, photos: photo });
  const sup = AP.getSupplier(b.supplierUid);
  assert.strictEqual(sup.name, 'Island Fresh Eggs');
  assert.strictEqual(sup.needs_setup, 1);
  assert.ok(AP.suppliersToSetUp().some((s) => s.uid === sup.uid));
  assert.ok(alerts(owner).some((x) => x.id === 'ap-sup-setup'));
  // typing the same name again uses that supplier, not a second one
  const c = V.snap(sam, { kind: 'invoice', shopCode: 'S2', party: 'island fresh eggs', refNo: 'E-10', amount: 20, photos: photo });
  assert.strictEqual(c.supplierUid, sup.uid);
  // saved properly from the supplier screen → flag cleared
  AP.saveSupplier(owner, { uid: sup.uid, name: sup.name, tin: '123456789', needsSetup: false });
  assert.strictEqual(AP.getSupplier(sup.uid).needs_setup, 0);
  assert.ok(!AP.suppliersToSetUp().some((s) => s.uid === sup.uid));
});

test('supplier statement: opening, invoices, credits, payments with cheque dates, running and closing balance, split, cheques not presented', () => {
  const old = AP.saveInvoice(owner, { supplierUid: rb.uid, invoiceNo: 'RB-0', total: 100, invoiceDate: '2026-08-20' }, { canCheck: true });
  const cn = AP.saveInvoice(owner, { kind: 'credit', supplierUid: rb.uid, invoiceNo: 'CN-1', total: 40, invoiceDate: '2026-10-03' }, { canCheck: true });
  const st = supplierStatement(rb.uid, '2026-09-01', '2026-10-31', { today: '2026-10-08' });
  assert.strictEqual(st.opening, 100, 'RB-0 before the period');
  const kinds = st.lines.map((l) => `${l.kind}:${l.ref}`);
  assert.deepStrictEqual(kinds, ['invoice:RB-1', 'payment:Cheque 100201', 'invoice:RB-2', 'credit:CN-1', 'payment:Cheque 100205', 'invoice:RB-3']);
  const p1 = st.lines.find((l) => l.ref === 'Cheque 100201');
  assert.strictEqual(p1.written, '2026-10-01');
  assert.strictEqual(p1.handed, '2026-10-08');
  assert.strictEqual(p1.presented, null);
  assert.ok(p1.notCleared);
  assert.deepStrictEqual(p1.invoices, ['RB-1']);
  // running balance: 100 +450 −450 +225 −40 −225 +300 = 360
  assert.deepStrictEqual(st.lines.map((l) => l.balance), [550, 100, 325, 285, 60, 360]);
  assert.strictEqual(st.closing, 360);
  assert.strictEqual(st.closing, r2(st.split.notDue + st.split.due + st.split.overdue + st.split.credits));
  // RB-0 (due 3 Sep) overdue at 31 Oct; RB-3 due 22 Oct overdue; credit 40 unused
  assert.strictEqual(st.split.overdue, 400);
  assert.strictEqual(st.split.credits, -40);
  assert.strictEqual(st.unpresentedTotal, 675);
  assert.strictEqual(st.beforeChequesClear, 1035);
  // a cheque presented after the period end still counts as not presented in it
  AP.markPresented(owner, st.lines.find((l) => l.ref === 'Cheque 100201').uid && CB.getStub({ accountUid: acct.uid, chequeNo: 100201 }).cheque.uid, '2026-10-07');
  const st2 = supplierStatement(rb.uid, '2026-09-01', '2026-10-06');
  assert.ok(st2.unpresented.some((c) => c.cheque_no === 100201));
  assert.ok(!supplierStatement(rb.uid, '2026-09-01', '2026-10-31').unpresented.some((c) => c.cheque_no === 100201));
  assert.strictEqual(old.status, 'approved');
  assert.ok(cn);
  throws(() => supplierStatement(rb.uid, '2026-10-31', '2026-10-01'), /period/);
  assert.ok(statementSummary('2026-09-01', '2026-10-31').some((x) => x.supplier.uid === rb.uid));
  // the statement check next to it agrees with the closing balance
  const chk = checkStatement(owner, { supplierUid: rb.uid, date: '2026-10-31', theirBalance: 360 });
  assert.strictEqual(chk.diff, 0);
  assert.ok(supplierStatement(rb.uid, '2026-09-01', '2026-10-31').lastCheck);
});


test('reports: supplier statement (one supplier / all) and cheque book report build; menu and screens', () => {
  const one = rep('ap_supplier_statement').build('2026-09-01', '2026-10-31', owner, { supplierUid: rb.uid });
  assert.ok(/Statement – RB Patel Group/.test(one.title));
  assert.strictEqual(one.sections[0].rows[0].what, 'Opening balance');
  assert.ok(one.sections[0].rows.some((r) => /written 2026-10-01/.test(r.note) && /handed over 2026-10-08/.test(r.note)));
  const all = rep('ap_supplier_statement').build('2026-09-01', '2026-10-31', owner);
  assert.ok(all.sections[0].rows.some((r) => r.name === 'RB Patel Group'));
  const cbr = rep('ap_chequebooks').build('2026-10-01', '2026-10-31', owner);
  assert.ok(cbr.sections[0].rows.some((r) => r.serial === 'BK-77' && r.holder === 'Divnesh (office safe)'));
  assert.ok(cbr.sections[1].rows.some((r) => r.no === 100202 && r.state === 'Skipped!'));
  assert.ok(cbr.sections[1].rows.some((r) => r.no === 100201 && r.photo === '✓'));
  assert.ok(cbr.sections[1].rows.some((r) => r.no === 100205 && r.photo === 'MISSING'));
  const items = MENU.flatMap((s) => s.items);
  assert.strictEqual(items.find((i) => i.id === 'chq-books').screen, 'ChequeBooks');
  assert.ok(items.find((i) => i.id === 'chq-books').title.includes('Cheque books & stubs'));
  const ids = items.map((i) => i.id);
  assert.strictEqual(ids.indexOf('ap-statement'), ids.indexOf('ap-sup-statement') + 1, 'statement check sits next to the statement');
});

test('mark handed over from the stub (office, no photo)', () => {
  const c = CB.getStub({ accountUid: acct.uid, chequeNo: 100205 }).cheque;
  throws(() => CB.markHandedOver(owner, c.uid, { date: '2026-10-07' }), /who took/);
  throws(() => CB.markHandedOver(owner, c.uid, { date: '2026-09-01', to: 'X' }), /on or after/);
  CB.markHandedOver(owner, c.uid, { date: '2026-10-07', to: 'Mohammed (RB Patel)' });
  assert.strictEqual(CB.getStub({ chequeUid: c.uid }).handedTo, 'Mohammed (RB Patel)');
});

done();
