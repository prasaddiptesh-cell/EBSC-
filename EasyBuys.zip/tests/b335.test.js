// v3.5 B3 – purchasing, suppliers and products: orders changed after sending / after delivery, delivery corrections,
// supplier order schedules and reminders, barcode lookup, Aronium supplier and product import, invoice reading.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, stamp, getShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as PA from '../src/modules/inventory/poAmend.js';
import * as SC from '../src/modules/inventory/schedules.js';
import * as SN from '../src/modules/inventory/scan.js';
import * as AR from '../src/modules/inventory/aronium.js';
import * as IR from '../src/modules/inventory/invoiceRead.js';
import { amendedPoReport } from '../src/modules/inventory/reports.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { processAlerts } from '../src/services/sounds.js';
import { rolePerms, saveRolePerms } from '../src/services/access.js';
import { MORE_SYNC } from '../src/db/moreSchemas.js';
import { MENU } from '../src/modules/inventory/menu.js';
import fs from 'fs';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (s) => { clock.override = new Date(s.replace(' ', 'T')); };
at('2026-10-09 08:00:00'); // a Friday
const owner = saveUser({ name: 'Divnesh Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Ana Admin', pin: '7777', role: 'admin' }, owner);
const mgr1 = saveUser({ name: 'Ravi Manager', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const mgr2 = saveUser({ name: 'Anita Manager', pin: '8889', role: 'manager', shopCode: 'S2' }, owner);
const sup = saveUser({ name: 'Sita Supervisor', pin: '6666', role: 'supervisor', shopCode: 'S1' }, owner);
const punjas = AP.saveSupplier(owner, { name: 'Punjas Ltd', tin: '50-12345-0-1', onAccount: true });
const rewa = AP.saveSupplier(owner, { name: 'Rewa Dairy', tin: '50999888', onAccount: true });

const CSV = `Code;Name;Group;Barcode;Measurement unit;Cost;Price;Wholesale price;Taxes;Quantity
1001;Punjas Flour 10kg;Flour;9300001,09300011;bag;"18,50";24.95;22.00;VAT 12.5%;40
1002;Rewa Milk 1L;Dairy;9300002;each;2.10;3.20;2.90;VAT 12.5%;120
1003;Rice 20kg;Rice;012345678905;bag;30.00;42.00;;Zero rated;10
`;

// ---------------------------------------------------------------- products from Aronium
test('products: all barcodes, groups, units, tax, prices incl. wholesale', () => {
  const r = I.importProductsCsv(owner, CSV, { shopCode: 'S1', openingStock: true, fullList: true });
  assert.strictEqual(r.added, 3);
  const f = I.getItem('IT-1001');
  assert.strictEqual(f.barcode, '9300001,09300011');
  assert.strictEqual(f.group_name, 'Flour'); assert.strictEqual(f.unit, 'bag');
  assert.strictEqual(f.wholesale_price, 22);
  assert.strictEqual(I.getItem('IT-1003').vat_type, 'zero');
  assert.strictEqual(I.getItem('IT-1003').wholesale_price, null);
  assert.strictEqual(f.aronium_seen, '2026-10-09');
  db().run('UPDATE inv_items SET supplier_uid = ? WHERE uid IN (?,?)', [punjas.uid, 'IT-1001', 'IT-1003']);
  db().run('UPDATE inv_items SET supplier_uid = ? WHERE uid = ?', [rewa.uid, 'IT-1002']);
});
test('products: deleted in Aronium → hidden, not deleted; back when it reappears', () => {
  const two = 'Code,Name,Price\n1001,Punjas Flour 10kg,24.95\n1002,Rewa Milk 1L,3.20\n';
  const dry = I.importProductsCsv(owner, two, { shopCode: 'S1', fullList: true, dryRun: true });
  assert.strictEqual(dry.hidden, 1);
  assert.strictEqual(I.getItem('IT-1003').active, 1, 'dry run changes nothing');
  I.importProductsCsv(owner, two, { shopCode: 'S1', fullList: true });
  const rice = I.getItem('IT-1003');
  assert.strictEqual(rice.active, 0); assert.strictEqual(rice.removed_at, '2026-10-09');
  assert.strictEqual(I.stockOf('IT-1003', 'S1'), 10, 'stock history kept');
  assert.ok(!I.stockList({ shopCode: 'S1' }).some((x) => x.uid === 'IT-1003'));
  const lk = SN.lookupScan('012345678905', {});
  assert.ok(!lk.ok && lk.hidden);
  // A partial file (fullList off) hides nothing.
  I.importProductsCsv(owner, 'Code,Name\n1001,Punjas Flour 10kg\n', { shopCode: 'S1' });
  assert.strictEqual(I.getItem('IT-1002').active, 1);
  const r = I.importProductsCsv(owner, CSV, { shopCode: 'S1', fullList: true });
  assert.strictEqual(r.back, 1);
  assert.strictEqual(I.getItem('IT-1003').active, 1); assert.strictEqual(I.getItem('IT-1003').removed_at, null);
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 40, 'importing again never doubles stock');
});
test('inventory per shop; stock goes down only through the Aronium sales import', () => {
  I.importProductsCsv(owner, 'Code,Name,Price,Quantity\n1001,Punjas Flour 10kg,25.50,8\n', { shopCode: 'S2', openingStock: true });
  assert.strictEqual(I.stockOf('IT-1001', 'S2'), 8);
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 40);
  I.importSalesCsv(owner, 'Code,Quantity\n1001,5\n', { shopCode: 'S1', date: '2026-10-08' });
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 35);
  const kinds = db().all("SELECT DISTINCT type FROM inv_moves WHERE qty < 0").map((r) => r.type);
  assert.deepStrictEqual(kinds, ['sale']);
});

// ---------------------------------------------------------------- suppliers from Aronium
const SUPCSV = `Code,Name,Tax number,Phone number,Email,Address,Is customer,Is supplier
10,PUNJAS LIMITED,50123450 1,679 666 1234,orders@punjas.com.fj,Lautoka,0,1
11,Rewa Dairy,,679 330 0000,,Suva,0,1
12,Joe Customer,,999,,Nadi,1,0
13,FMF Foods,51234567,679 338 0000,fmf@fmf.com.fj,Suva,0,1
`;
test('suppliers from Aronium: TIN first then name, Aronium wins, app-only fields kept, customers skipped', () => {
  AP.saveSupplier(owner, { uid: punjas.uid, name: 'Punjas Ltd', tin: '501234501', onAccount: true, termsDays: 30, payMethod: 'transfer', bankName: 'BSP', bankAccount: '123' });
  I.saveSupplierOrdering(owner, { supplierUid: punjas.uid, budgetWeekly: 500, leadDays: 2 });
  const dry = AR.importSuppliersCsv(owner, SUPCSV, { dryRun: true });
  assert.strictEqual(dry.customers, 1);
  assert.strictEqual(dry.added, 1); assert.strictEqual(dry.changed, 2);
  assert.ok(dry.sample[0].match.includes('by TIN'));
  assert.ok(dry.sample[1].match.includes('by name'));
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_suppliers").n, 2, 'dry run adds nothing');
  AR.importSuppliersCsv(owner, SUPCSV);
  const p = AP.getSupplier(punjas.uid);
  assert.strictEqual(p.name, 'PUNJAS LIMITED');
  assert.strictEqual(p.phone, '679 666 1234');
  assert.strictEqual(p.terms_days, 30); assert.strictEqual(p.pay_method, 'transfer'); assert.strictEqual(p.bank_account, '123');
  assert.strictEqual(p.budget_weekly, 500);
  assert.ok(!db().get("SELECT 1 AS x FROM ap_suppliers WHERE name = 'Joe Customer'"));
  const fmf = db().get("SELECT * FROM ap_suppliers WHERE name = 'FMF Foods'");
  assert.strictEqual(fmf.tin, '51234567');
  assert.strictEqual(AR.aroniumSupplier(fmf.uid).address, 'Suva');
  assert.strictEqual(AP.getSupplier(rewa.uid).tin, '50999888', 'empty TIN in Aronium keeps ours');
  const again = AR.importSuppliersCsv(owner, SUPCSV, { dryRun: true });
  assert.strictEqual(again.added, 0); assert.strictEqual(again.same, 3);
});

// ---------------------------------------------------------------- barcodes
test('barcode lookup: any barcode, UPC/EAN variants, code; not found → add it in Aronium first; other supplier warning', () => {
  assert.strictEqual(SN.findByBarcode('09300011').uid, 'IT-1001');
  assert.strictEqual(SN.findByBarcode('9300001').uid, 'IT-1001');
  assert.strictEqual(SN.findByBarcode('0012345678905').uid, 'IT-1003');
  assert.strictEqual(SN.findByBarcode('1002').uid, 'IT-1002');
  const nf = SN.lookupScan('4444444444', { supplierUid: punjas.uid });
  assert.ok(!nf.ok && nf.notFound && /Add it in Aronium first/.test(nf.message));
  const ok = SN.lookupScan('9300001', { supplierUid: punjas.uid, shopCode: 'S1' });
  assert.ok(ok.ok && !ok.warning); assert.strictEqual(ok.onHand, 35);
  const other = SN.lookupScan('9300002', { supplierUid: punjas.uid });
  assert.ok(other.ok && /usually comes from Rewa Dairy/.test(other.warning));
  let lines = SN.addScanned([], ok.item, 3);
  lines = SN.addScanned(lines, ok.item, 2);
  lines = SN.addScanned(lines, other.item, 1);
  assert.deepStrictEqual(lines.map((l) => [l.itemUid, l.qty]), [['IT-1001', '5'], ['IT-1002', '1']]);
});

// ---------------------------------------------------------------- purchase orders after sending
let po;
test('before sending: fully editable by whoever makes orders', () => {
  po = I.savePO(mgr1, { supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 10 }, { itemUid: 'IT-1003', qty: 2 }] });
  assert.strictEqual(PA.poEditMode(mgr1, po).mode, 'full');
  po = I.savePO(mgr1, { uid: po.uid, supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 12 }, { itemUid: 'IT-1003', qty: 2 }] });
  I.submitPO(owner, po.uid, { canApprove: true });
  I.markSent(owner, po.uid, 'viber');
  throws(() => I.savePO(mgr1, { uid: po.uid, supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 1 }] }), /already been sent/);
});
test('after sending: approvers only; reason needed except owner/admin; version history; amended PDF', () => {
  po = I.getPO(po.uid);
  assert.strictEqual(PA.poEditMode(mgr1, po).mode, 'none', 'manager without approval rights');
  throws(() => PA.amendPO(mgr1, po.uid, { notes: 'x' }), /approve orders/);
  // A supervisor given approval rights may change it, but must give a reason.
  const rp = rolePerms();
  saveRolePerms(owner, { ...rp, supervisor: (rp.supervisor || []).concat(['po_approve']) });
  assert.strictEqual(PA.poEditMode(sup, po).mode, 'sent');
  throws(() => PA.amendPO(sup, po.uid, { notes: 'x' }), /Say why/);
  saveRolePerms(owner, rp);
  throws(() => PA.amendPO(owner, po.uid, {}), /Nothing was changed/);
  const fl = po.lines.find((l) => l.item_uid === 'IT-1001');
  const rice = po.lines.find((l) => l.item_uid === 'IT-1003');
  const r = PA.amendPO(owner, po.uid, { expectedDate: '2026-10-12', lines: [{ lineUid: fl.uid, qty: 15, unitCost: 19 }, { itemUid: 'IT-1002', qty: 6 }] });
  assert.strictEqual(r.version, 2);
  assert.ok(r.offerAmended);
  assert.ok(r.changes.includes('Punjas Flour 10kg: 12 → 15'));
  assert.ok(r.changes.some((c) => /price/.test(c)));
  assert.ok(r.changes.includes('Removed Rice 20kg'));
  assert.ok(r.changes.some((c) => /Added Rewa Milk 1L × 6/.test(c)));
  const o = I.getPO(po.uid);
  assert.strictEqual(o.status, 'sent');
  assert.strictEqual(o.lines.find((l) => l.uid === rice.uid).qty, 0);
  assert.strictEqual(o.total, I.r2(I.incVat(15 * 19, 'standard') + I.incVat(6 * 2.1, 'standard')));
  const v = PA.poVersions(po.uid);
  assert.strictEqual(v.length, 1); assert.strictEqual(v[0].by_name, 'Divnesh Owner'); assert.strictEqual(v[0].before.lines.length, 2);
  assert.ok(PA.amendedNotSent().some((x) => x.uid === po.uid));
  const pdf = amendedPoReport(po.uid);
  assert.ok(/AMENDED/.test(pdf.title) && pdf.sections[0].rows.length >= 3);
  assert.ok(invAlerts(owner).some((a) => a.id.startsWith(`inv-amended-${po.uid}`)));
  PA.markAmendedSent(owner, po.uid, 'pdf');
  assert.ok(!PA.amendedNotSent().length);
  // Admin also needs no reason.
  const r2 = PA.amendPO(admin, po.uid, { notes: 'Please deliver before 10am' });
  assert.strictEqual(r2.version, 3);
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Changed order % after sending (version 3)%'"));
});
let rc;
test('after receiving: dates, notes, new lines and what has not arrived; never below what arrived', () => {
  const o = I.getPO(po.uid);
  const fl = o.lines.find((l) => l.item_uid === 'IT-1001');
  const milk = o.lines.find((l) => l.item_uid === 'IT-1002');
  rc = I.receiveDelivery(owner, { poUid: po.uid, lines: [{ lineUid: fl.uid, qty: 10, unitCost: 19 }, { lineUid: milk.uid, qty: 6 }], acceptReason: 'ok' });
  assert.strictEqual(I.getPO(po.uid).status, 'part');
  assert.strictEqual(PA.poEditMode(owner, I.getPO(po.uid)).mode, 'received');
  throws(() => PA.amendPO(owner, po.uid, { lines: [{ lineUid: fl.uid, qty: 8 }, { lineUid: milk.uid, qty: 6 }] }), /already arrived/);
  throws(() => PA.amendPO(owner, po.uid, { lines: [{ lineUid: fl.uid, qty: 15 }, { lineUid: milk.uid, qty: 6, unitCost: 3 }] }), /All of "Rewa Milk 1L" has arrived/);
  const r = PA.amendPO(owner, po.uid, { orderDate: '2026-10-08', expectedDate: '2026-10-13', lines: [{ lineUid: fl.uid, qty: 14, unitCost: 19.5 }, { lineUid: milk.uid, qty: 6 }, { itemUid: 'IT-1003', qty: 1 }] });
  assert.ok(r.changes.includes('Order date 2026-10-09 → 2026-10-08'));
  const after = I.getPO(po.uid);
  assert.strictEqual(after.lines.find((l) => l.uid === fl.uid).unit_cost, 19.5);
  assert.strictEqual(after.status, 'part');
  // Leaving a line out = nothing more to come for it.
  const r2 = PA.amendPO(owner, po.uid, { lines: [{ lineUid: milk.uid, qty: 6 }, { lineUid: after.lines.find((l) => l.item_uid === 'IT-1003' && l.qty > 0).uid, qty: 1 }] });
  assert.ok(r2.changes.some((c) => /rest not needed/.test(c)));
  assert.strictEqual(I.getPO(po.uid).lines.find((l) => l.uid === fl.uid).qty, 10);
});
test('delivered quantities are corrected from the delivery (stock, order, cost, history)', () => {
  const s1 = I.stockOf('IT-1001', 'S1');
  PA.markAmendedSent(owner, po.uid, 'viber');
  throws(() => PA.correctDelivery(mgr1, rc.uid, { lines: [{ itemUid: 'IT-1001', qty: 9 }] }), /Say what was wrong/);
  const r = PA.correctDelivery(owner, rc.uid, { lines: [{ itemUid: 'IT-1001', qty: 9, unitCost: 18.75 }] });
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), s1 - 1);
  assert.strictEqual(r.lines.find((l) => l.itemUid === 'IT-1001').qty, 9);
  assert.ok(r.lines.find((l) => l.itemUid === 'IT-1001').corrected);
  const o = I.getPO(po.uid);
  assert.strictEqual(o.lines.find((l) => l.item_uid === 'IT-1001' && l.qty > 0).qty_received, 9);
  assert.strictEqual(o.status, 'part');
  assert.strictEqual(I.getItem('IT-1001').cost, 18.75, 'latest delivery price becomes the cost');
  assert.ok(I.costChanges({}).some((c) => c.source === 'delivery_fix'));
  assert.strictEqual(PA.poVersions(po.uid)[0].kind, 'delivery_fix');
  assert.ok(!PA.amendedNotSent().some((x) => x.uid === po.uid), 'a delivery fix does not need an amended order');
  // Voiding the delivery takes the corrected amount off.
  I.voidReceipt(owner, rc.uid, 'test');
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), s1 - 10);
});

// ---------------------------------------------------------------- freeze during stock take
test('stock take freeze covers deliveries, corrections, opening stock import, write-offs and transfers', () => {
  const c = I.startCount(owner, { shopCode: 'S2', scope: {}, date: '2026-10-09' });
  throws(() => I.adjustStock(owner, { itemUid: 'IT-1001', shopCode: 'S2', qty: -1, reason: 'Damaged' }), /frozen/);
  throws(() => I.sendTransfer(owner, { fromShop: 'S2', toShop: 'S1', lines: [{ itemUid: 'IT-1001', qty: 1 }] }), /frozen/);
  throws(() => I.receiveDelivery(owner, { supplierUid: punjas.uid, shopCode: 'S2', extra: [{ itemUid: 'IT-1001', qty: 1 }] }), /frozen/);
  const r = I.importProductsCsv(owner, 'Code,Name,Quantity\n1001,Punjas Flour 10kg,99\n', { shopCode: 'S2', openingStock: true });
  assert.deepStrictEqual(r.frozen, ['Punjas Flour 10kg']);
  assert.strictEqual(I.stockOf('IT-1001', 'S2'), 8);
  I.cancelCount(owner, c.uid, 'test');
});

// ---------------------------------------------------------------- order schedules and reminders
test('schedules: order days, cut-off per day, delivery day, reminder; one schedule with per-shop changes', () => {
  throws(() => SC.saveSchedule(owner, { supplierUid: rewa.uid, days: [] }), /at least one order day/);
  throws(() => SC.saveSchedule(owner, { supplierUid: rewa.uid, days: [{ day: 5, cutoff: '25:00' }] }), /cut-off/);
  // Rewa: Friday by 10:00 delivered Saturday; Monday by 2pm delivered Tuesday. Remind 90 minutes before.
  SC.saveSchedule(owner, { supplierUid: rewa.uid, days: [{ day: 5, cutoff: '10:00', deliveryDay: 6 }, { day: 1, cutoff: '2:00 pm', deliveryDay: 2 }], reminderMins: 90 });
  // Shop 2 must order Friday by 9:00 instead, reminded 30 minutes before.
  SC.saveSchedule(owner, { supplierUid: rewa.uid, shopCode: 'S2', days: [{ day: 5, cutoff: '09:00', deliveryDay: 6 }], reminderMins: 30 });
  const all = SC.getSchedules(rewa.uid);
  assert.strictEqual(all.base.days[0].cutoff, '14:00');
  assert.strictEqual(SC.effectiveSchedule(rewa.uid, 'S1').reminderMins, 90);
  assert.strictEqual(SC.effectiveSchedule(rewa.uid, 'S2').days.length, 1);
  assert.strictEqual(SC.describeDays(all.base.days), 'Mon by 14:00 → Tue, Fri by 10:00 → Sat');
  // Punjas: old "order days" typed before v3.5 still count (no cut-off).
  db().run("UPDATE ap_suppliers SET order_days = 'Fri' WHERE uid = ?", [punjas.uid]);
  assert.strictEqual(SC.effectiveSchedule(punjas.uid, 'S1').from, 'legacy');
});
test("today's orders: later / due / missed / sent / skipped; delivery date", () => {
  let rows = SC.ordersForDay('2026-10-09', { now: '2026-10-09 07:00:00' }).filter((r) => r.supplierUid === rewa.uid);
  assert.deepStrictEqual(rows.map((r) => [r.shopCode, r.cutoff, r.state]), [['S2', '09:00', 'later'], ['S1', '10:00', 'later']]);
  assert.strictEqual(rows[0].deliveryDate, '2026-10-10');
  rows = SC.ordersForDay('2026-10-09', { now: '2026-10-09 08:40:00' }).filter((r) => r.supplierUid === rewa.uid);
  assert.deepStrictEqual(rows.map((r) => r.state), ['due', 'due']);
  rows = SC.ordersForDay('2026-10-09', { now: '2026-10-09 09:05:00' }).filter((r) => r.supplierUid === rewa.uid);
  assert.deepStrictEqual(rows.map((r) => r.state), ['missed', 'due']);
  assert.ok(!SC.ordersForDay('2026-10-10', {}).some((r) => r.supplierUid === rewa.uid), 'Saturday is not an order day');
});
test('reminders: shop manager and owner only; warning with phone notification; missed = red; none once sent', () => {
  at('2026-10-09 08:40:00');
  const ids = (u) => invAlerts(u).filter((a) => a.id.startsWith('ord-') && a.id.includes(rewa.uid)).map((a) => `${a.level}:${a.id.split('-').slice(-1)[0]}`);
  assert.deepStrictEqual(ids(mgr1), ['warning:S1']);
  assert.deepStrictEqual(ids(mgr2), ['warning:S2']);
  assert.deepStrictEqual(ids(sup), []);
  assert.strictEqual(ids(owner).filter((x) => /S[12]$/.test(x)).length >= 2, true);
  const a = invAlerts(mgr1).find((x) => x.id.startsWith('ord-due-') && x.id.includes(rewa.uid));
  assert.ok(a.notify);
  assert.deepStrictEqual(a.nav, { screen: 'POEdit', params: { shopCode: 'S1', supplierUid: rewa.uid, suggest: true } });
  const pinged = [];
  processAlerts(mgr1, invAlerts(mgr1), { play: () => {}, notify: (x) => pinged.push(x.id) });
  assert.ok(pinged.includes(a.id), 'phone notification for the order reminder');
  at('2026-10-09 09:30:00');
  assert.ok(invAlerts(mgr2).some((x) => x.level === 'urgent' && /Missed the 09:00 order cut-off for Rewa Dairy/.test(x.text)));
  // S1 sends its order: no more reminder.
  const o = I.savePO(mgr1, { supplierUid: rewa.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1002', qty: 24 }] });
  assert.ok(invAlerts(mgr1).some((x) => x.id.startsWith('ord-started-')), 'started but not sent');
  I.submitPO(owner, o.uid, { canApprove: true });
  I.markSent(owner, o.uid, 'viber');
  assert.ok(!invAlerts(mgr1).some((x) => x.id.startsWith('ord-') && x.id.includes(rewa.uid)));
  assert.strictEqual(SC.ordersForDay('2026-10-09').find((r) => r.supplierUid === rewa.uid && r.shopCode === 'S1').state, 'sent');
  // S2 is not ordering today.
  throws(() => SC.skipOrder(mgr2, { supplierUid: rewa.uid, shopCode: 'S2' }), /Say why/);
  SC.skipOrder(mgr2, { supplierUid: rewa.uid, shopCode: 'S2', reason: 'Enough milk' });
  assert.ok(!invAlerts(mgr2).some((x) => x.id.includes(rewa.uid)));
  assert.ok(getShared('order_skips', {})[`2026-10-09|${rewa.uid}|S2`]);
});
test('reminders: early cut-off tomorrow is reminded tonight', () => {
  SC.saveSchedule(owner, { supplierUid: punjas.uid, days: [{ day: 6, cutoff: '07:00' }], reminderMins: 12 * 60 });
  at('2026-10-09 20:00:00');
  assert.ok(invAlerts(mgr2).some((x) => /Order from PUNJAS LIMITED for S2 tomorrow by 07:00/.test(x.text)));
  assert.ok(!invAlerts(mgr1).some((x) => /PUNJAS/.test(x.text)), 'S1 already sent an order to Punjas this week');
  SC.saveSchedule(owner, { supplierUid: punjas.uid, shopCode: 'S2', skip: true });
  assert.ok(!invAlerts(mgr2).some((x) => /PUNJAS/.test(x.text)), 'S2 does not order from them');
  SC.clearShopChange(owner, punjas.uid, 'S2');
  assert.ok(invAlerts(mgr2).some((x) => /PUNJAS/.test(x.text)));
  at('2026-10-09 10:00:00');
});

// ---------------------------------------------------------------- invoice reading
const INV = `PUNJAS LIMITED
TIN 50123450 1
TAX INVOICE
Inv Ref: PJ-7781
Date: 09/10/2026
1001 Punjas Flour 10kg bag 10 19.50 195.00
Rice 20kg Zero 2 30.00 60.00
Rewa Milk 1L 6 2.10 12.60
Sub Total 267.60
VAT 12.5% 25.71
Amount Payable 293.31
`;
test('invoice lines: quantity × price found, products matched by code and name', () => {
  const lines = IR.parseItemLines(INV);
  assert.strictEqual(lines.length, 3);
  assert.deepStrictEqual([lines[0].code, lines[0].qty, lines[0].unitCost, lines[0].total], ['1001', 10, 19.5, 195]);
  assert.deepStrictEqual([lines[1].qty, lines[1].unitCost], [2, 30]);
  const res = IR.readInvoiceText(INV, {});
  assert.strictEqual(res.supplierUid, punjas.uid);
  assert.strictEqual(res.total, 293.31);
  assert.deepStrictEqual(res.lines.map((l) => [l.itemUid, l.matchedBy]), [['IT-1001', 'code'], ['IT-1003', 'name'], ['IT-1002', 'name']]);
});
test('invoice vs order: price differences, not on order, missing lines; cost changes flagged', () => {
  const o = I.savePO(owner, { supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 10, unitCost: 18.75 }, { itemUid: 'IT-1003', qty: 2, unitCost: 30 }, { itemUid: 'IT-1002', qty: 1 }] });
  db().run("UPDATE po_lines SET item_uid = NULL WHERE po_uid = ? AND item_uid = 'IT-1002'", [o.uid]);
  const res = IR.readInvoiceText(INV, { poUid: o.uid });
  const flour = res.lines.find((l) => l.itemUid === 'IT-1001');
  assert.ok(flour.flags.includes('price differs from the order'));
  assert.strictEqual(flour.ordered, 10);
  assert.ok(res.lines.find((l) => l.itemUid === 'IT-1002').flags.includes('not on the order'));
  assert.ok(res.costChanges.some((c) => c.itemUid === 'IT-1001' && c.oldCost === 18.75 && c.newCost === 19.5));
  assert.ok(!res.costChanges.some((c) => c.itemUid === 'IT-1003'));
  const o2 = I.savePO(owner, { supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 10 }, { itemUid: 'IT-1003', qty: 2 }, { itemUid: 'IT-1002', qty: 6 }, { name: 'Sugar 1kg', qty: 5, unitCost: 2 }] });
  const res2 = IR.readInvoiceText(INV, { poUid: o2.uid });
  assert.deepStrictEqual(res2.missing.map((m) => m.name), ['Sugar 1kg']);
});
test('invoice vs delivery: quantity differences', () => {
  const r = I.receiveDelivery(owner, { supplierUid: punjas.uid, shopCode: 'S1', extra: [{ itemUid: 'IT-1001', qty: 9 }, { itemUid: 'IT-1003', qty: 2 }], acceptReason: 'ok' });
  const res = IR.readInvoiceText(INV, { receiptUid: r.uid });
  assert.ok(res.lines.find((l) => l.itemUid === 'IT-1001').flags.includes('quantity differs from the delivery'));
  assert.ok(res.lines.find((l) => l.itemUid === 'IT-1002').flags.includes('not delivered'));
});
const ODD = `FMF Foods
Document No ZX-55012
Item Description Price Qty Amount
Crackers 200g (ours: biscuits) 4.50 12 54.00
Tiny Tea 100 3.15 3 9.45
Grand Sum FJD 71.38
`;
test('supplier layout learned from corrections: labels, columns, their names for our products', () => {
  const fmf = db().get("SELECT * FROM ap_suppliers WHERE name = 'FMF Foods'");
  I.saveItem(owner, { code: '2001', name: 'Cabin Biscuits 200g', cost: 4.0, price: 6 });
  I.saveItem(owner, { code: '2002', name: 'Lipton Tea 100', cost: 2.8, price: 4.5 });
  const before = IR.readInvoiceText(ODD, { supplierUid: fmf.uid });
  assert.strictEqual(before.lines[0].itemUid, null, 'not known yet');
  const raw = ODD.split('\n');
  const learned = IR.learnFromCorrection(owner, fmf.uid, ODD, { invoiceNo: 'ZX-55012', total: 71.38,
    lines: [{ raw: raw[3], itemUid: 'IT-2001', qty: 12, unitCost: 4.5 }, { raw: raw[4], itemUid: 'IT-2002', qty: 3, unitCost: 3.15 }] });
  assert.ok(learned.learned.some((x) => /Document No/.test(x)));
  assert.ok(learned.learned.some((x) => /Grand Sum/.test(x)));
  const L = IR.getLayout(fmf.uid);
  assert.deepStrictEqual(L.cols, { qty: 2, cost: 3 });
  // Next invoice from FMF: read with what was learned.
  const NEXT = 'FMF Foods\nDocument No ZX-60000\nCrackers 200g (ours: biscuits) 4.80 10 48.00\nTiny Tea 100 3.15 3 9.45\nGrand Sum FJD 64.64\n';
  const res = IR.readInvoiceText(NEXT, { supplierUid: fmf.uid });
  assert.strictEqual(res.invoiceNo, 'ZX-60000');
  assert.strictEqual(res.total, 64.64);
  assert.ok(res.layoutUsed);
  assert.deepStrictEqual(res.lines.map((l) => [l.itemUid, l.qty, l.unitCost, l.matchedBy]), [['IT-2001', 10, 4.8, 'learned'], ['IT-2002', 3, 3.15, 'learned']]);
  assert.ok(res.costChanges.some((c) => c.itemUid === 'IT-2001'));
  const uid = IR.saveRead(owner, { supplierUid: fmf.uid, engine: 'device', text: NEXT, result: res });
  assert.strictEqual(IR.listReads({ supplierUid: fmf.uid })[0].uid, uid);
  IR.forgetLayout(owner, fmf.uid);
  assert.ok(!IR.getLayout(fmf.uid).cols);
});
test('prices including VAT are learned and taken off', () => {
  const fmf = db().get("SELECT * FROM ap_suppliers WHERE name = 'FMF Foods'");
  const T = 'FMF Foods\nCabin Biscuits 200g 5 4.50 22.50\n';
  IR.learnFromCorrection(owner, fmf.uid, T, { lines: [{ raw: 'Cabin Biscuits 200g 5 4.50 22.50', itemUid: 'IT-2001', qty: 5, unitCost: 4 }] });
  assert.ok(IR.getLayout(fmf.uid).pricesIncVat);
  const res = IR.readInvoiceText(T, { supplierUid: fmf.uid });
  assert.strictEqual(res.lines[0].unitCost, 4);
});

// ---------------------------------------------------------------- module wiring
test('menu items and screens for every new feature', () => {
  const items = MENU.flatMap((s) => s.items);
  for (const id of ['inv-today-orders', 'inv-schedules', 'inv-sup-import', 'inv-read-invoice', 'inv-scan-po']) assert.ok(items.some((i) => i.id === id), id);
  const idx = fs.readFileSync(new URL('../src/modules/inventory/index.js', 'file://' + process.cwd() + '/tests/'), 'utf8');
  const has = (n) => new RegExp(`\\b${n}: \\{ component`).test(idx);
  for (const i of items) assert.ok(has(i.screen) || ['ReportsHub', 'Snap'].includes(i.screen), `${i.id} → ${i.screen}`);
  for (const n of ['TodaysOrders', 'SupplierSchedules', 'SupplierImport', 'InvoiceRead', 'DeliveryFix', 'POHistory']) assert.ok(has(n), n);
});
test('sync: new tables are synced and new columns travel', () => {
  for (const t of ['po_versions', 'supplier_schedules', 'aronium_suppliers', 'supplier_layouts', 'invoice_reads']) assert.ok(MORE_SYNC[t], t);
});

done();
