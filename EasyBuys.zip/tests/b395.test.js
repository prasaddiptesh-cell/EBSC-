// 3.9.5 one place for everything: the areas on Home, Settings and Reports in one place, end-of-shift checklists (with
// the cashier checking the shop assistants), day off / leave / sick / absent on the roster (sick sheet = paid, no sheet =
// unpaid, salary less unpaid days), To verify (deliveries, handovers, checklists, orders to authorise, papers joined to
// each item, Query and answer), orders raised by staff wait for the owner, subtotal / VAT / total, Aronium purchases
// against the invoices.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, dateStr, stamp } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import fs from 'fs';
// The module menus without their screens (the screens need the phone): enough for the areas and Settings lists.
const menuOf = async (id) => (await import(`../src/modules/${id === 'recruitment' ? 'people' : id}/menu.js`)).MENU;
import * as AR from '../src/services/areas.js';
import * as D from '../src/services/duties.js';
import * as A from '../src/modules/timesheets/absence.js';
import * as V from '../src/modules/verify/service.js';
import * as Q from '../src/modules/verify/queries395.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import { poReport, receiptReport } from '../src/modules/inventory/reports.js';
import { reportToHtml } from '../src/services/export.js';
import { computeLine, payRules } from '../src/modules/payroll/service.js';
import { purchasesCheck } from '../src/modules/aronium/purchasesCheck.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
setSetting('cloud_key', 'tablet-key-123');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const manager = saveUser({ name: 'Mona Manager', pin: '6284', role: 'manager', shop_code: 'S1' });
const sup = saveUser({ name: 'Sunil Supervisor', pin: '7351', role: 'supervisor', shop_code: 'S1' });
const asha = saveUser({ name: 'Asha', pin: '2468', role: 'staff', shop_code: 'S1' });
const mere = saveUser({ name: 'Mere', pin: '3579', role: 'staff', shop_code: 'S1' });
const ravi = saveUser({ name: 'Ravi', pin: '8642', role: 'staff', shop_code: 'S1' });
const today = dateStr();
const MODS = {};
for (const [id, title] of [['till', 'Till & cash'], ['inventory', 'Inventory'], ['payables', 'Invoices'], ['timesheets', 'Timesheets'], ['leave', 'Leave'], ['payroll', 'Payroll'], ['staff', 'Staff'], ['recruitment', 'Recruitment'], ['timeclock', 'Time Clock'],
  ['bank', 'Bank'], ['loans', 'Loans'], ['accounting', 'Accounting'], ['owed', 'Who owes us'], ['drawings', 'Owner'], ['bakery', 'Bakery'], ['licences', 'Licences'], ['vehicles', 'Vehicles'], ['admin', 'Admin'], ['verify', 'To verify']]) {
  MODS[id] = { id, title, icon: '•', menu: await menuOf(id) };
}
const getModule = (id) => MODS[id];
const menuModules = () => Object.values(MODS);
const screens = null; // no screen checks here (the phone screens are checked by the screen tests)
const idx = (m) => fs.readFileSync(`src/modules/${m}/index.js`, 'utf8');
const punch = (u, at) => db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, voided, updated_at, updated_device, sync_status) VALUES (?,?,?,'IN',?,?,'S1','t','pin',0,?, 't','pending')",
  [`P-${u.uid}-${at}`, u.uid, u.name, at, at, at]);

test('Home areas: every area gathers its modules; no settings or reports in an area', () => {
  const people = AR.areaView(AR.getArea('people'), owner, screens, getModule);
  const ids = people.blocks.flatMap((b) => b.daily.concat(b.more)).map((x) => x.testID);
  assert.ok(ids.includes('mi-ts-roster') && ids.includes('mi-ts-markday') && ids.includes('mi-ts-absence') && ids.includes('mi-pay-new'), ids.join(' '));
  assert.ok(!ids.includes('mi-pay-rules') && !ids.includes('mi-ts-settings'), 'settings are only in Settings');
  assert.ok(ids.includes('mi-home') && ids.includes('mi-home-payroll'), 'the second module\'s "home" item gets its own id');
  assert.ok(people.settings.some((s) => s.id === 'pay-rules'), 'the area links to its settings');
  assert.strictEqual(AR.areasFor(owner, screens, getModule).length, AR.AREAS.length);
  const stock = AR.areaView(AR.getArea('inventory'), owner, screens, getModule);
  const sid = stock.blocks.flatMap((b) => b.daily).map((x) => x.screen);
  assert.ok(sid.includes('ReceiveGoods') && !sid.includes('Snap'), 'receiving is one job: Receive goods & invoice');
});

test('Settings: every module setting is in one list by area; report screens are in Reports; who may open what', () => {
  const g = AR.settingsByArea(owner, screens, menuModules(), []);
  assert.ok(g.people.some((x) => x.id === 'pay-rules') && g.people.some((x) => x.id === 'staff-duties'));
  assert.ok(g.inventory.some((x) => x.id === 'inv-import' && /back-up/.test(x.title)));
  assert.ok(g.money.some((x) => x.id === 'owed-import'), 'Aronium staff credit CSV moved to Settings');
  const rs = AR.reportScreens(owner, screens, menuModules());
  assert.ok(rs.some((x) => x.screen === 'ProfitLoss') && rs.some((x) => x.screen === 'BalanceSheet'));
  assert.ok(/Fccc: \{ component: FcccScreen, can: \(u\) => !!u \}/.test(idx('inventory')), 'FCCC prices: everyone may look');
  assert.ok(/ReceiveGoods: \{ component: ReceiveScreen/.test(idx('verify')) && /HandCheque: \{ component/.test(idx('verify')));
  assert.ok(/MarkDay: \{ component/.test(idx('timesheets')) && /DutyLists: \{ component/.test(idx('staff')) && /Storage: \{ component/.test(idx('admin')));
});

test('checklists: starter lists per job; tick, not done with a reason, finish', () => {
  const lists = D.listDutyLists();
  assert.deepStrictEqual(lists.map((l) => l.duty).sort(), ['accountant', 'assistant', 'baker', 'cashier', 'payroll']);
  assert.strictEqual(D.dutyOf(mere), 'assistant');
  D.setDuty(owner, asha.uid, 'cashier');
  assert.strictEqual(D.dutyOf(asha), 'cashier');
  let m = D.myDutyToday(mere);
  assert.strictEqual(m.total, 6);
  throws(() => D.finishDuty(mere), /not ticked/);
  for (const it of m.items.slice(0, 5)) m = D.tickDuty(mere, it.id, true);
  throws(() => D.skipDuty(mere, m.items[5].id, ''), /why/);
  m = D.skipDuty(mere, m.items[5].id, 'FCCC list not printed');
  m = D.finishDuty(mere);
  assert.ok(m.done && m.ticked === 5 && m.skippedN === 1);
  throws(() => D.tickDuty(mere, m.items[0].id, false), /finished/);
});

test('handover: the cashier checks each shop assistant on the shift; not done goes to To verify', () => {
  punch(mere, `${today} 07:00:00`); punch(ravi, `${today} 07:05:00`); punch(asha, `${today} 06:58:00`);
  const team = D.teamDuties({ shopCode: 'S1', date: today });
  assert.deepStrictEqual(team.map((p) => p.name), ['Mere', 'Ravi'], 'the cashier is not on the assistants\' list');
  assert.strictEqual(D.handoverDutyBlockers({ shopCode: 'S1', date: today }).length, 2);
  throws(() => D.checkTeamDuty(mere, mere.uid, { date: today }), /Someone else/);
  D.checkTeamDuty(asha, mere.uid, { date: today, ok: true, shopCode: 'S1' });
  throws(() => D.checkTeamDuty(asha, ravi.uid, { date: today, ok: false }), /what was not done/);
  D.checkTeamDuty(asha, ravi.uid, { date: today, ok: false, note: 'Did not start his list', shopCode: 'S1' });
  assert.strictEqual(D.handoverDutyBlockers({ shopCode: 'S1', date: today }).length, 0);
  const q = V.queue({ include: 'waiting', withDocs: true }).filter((x) => x.table === 'duty_runs');
  assert.ok(q.some((x) => x.who === 'Ravi' && /checked by Asha/.test(x.text)), JSON.stringify(q.map((x) => x.text)));
  assert.ok(q.some((x) => x.who === 'Mere' && x.reasons.some((r) => /FCCC list not printed/.test(r))));
});

test('roster: day off, leave (approved at once), sick with a sheet = paid, no sheet = unpaid, absent needs a reason', () => {
  const d1 = '2026-10-13'; const d2 = '2026-10-14'; const d3 = '2026-10-15'; const d4 = '2026-10-16';
  throws(() => A.markDay(asha, { userUid: mere.uid, date: d1, kind: 'off' }), /manager/);
  A.markDay(manager, { userUid: mere.uid, date: d1, kind: 'off' });
  const lv = A.markDay(manager, { userUid: mere.uid, date: d2, kind: 'leave', leaveType: 'ANNUAL' });
  assert.ok(lv.leave_uid && db().get('SELECT status FROM leave_requests WHERE uid = ?', [lv.leave_uid]).status === 'approved', 'leave asked in person: no notice rule, approved');
  throws(() => A.markDay(manager, { userUid: mere.uid, date: d3, kind: 'sick', sheet: true, photos: [] }), /photo/);
  const s1 = A.markDay(manager, { userUid: mere.uid, date: d3, kind: 'sick', sheet: true, photos: ['file:///sheet.jpg'] });
  assert.ok(s1.paid === 1 && s1.leave_type === 'SICK');
  const s2 = A.markDay(manager, { userUid: ravi.uid, date: d3, kind: 'sick', sheet: false });
  assert.ok(s2.paid === 0 && /no sheet/.test(s2.reason));
  throws(() => A.markDay(manager, { userUid: ravi.uid, date: d4, kind: 'absent' }), /reason/);
  A.markDay(manager, { userUid: ravi.uid, date: d4, kind: 'absent', reason: 'No call, no show' });
  assert.deepStrictEqual(A.unpaidDays(ravi.uid, d1, d4).map((m) => m.mark_date), [d3, d4]);
  const rec = A.absenceRecord({ from: d1, to: d4 });
  const r = rec.find((x) => x.name === 'Ravi');
  assert.deepStrictEqual([r.absent, r.sickUnpaid, r.unpaid], [1, 1, 2]);
  // changing the day back to work cancels the leave made for it
  A.markDay(manager, { userUid: mere.uid, date: d2, kind: 'work' });
  assert.strictEqual(db().get('SELECT status FROM leave_requests WHERE uid = ?', [lv.leave_uid]).status, 'cancelled');
  assert.strictEqual(A.markOf(mere.uid, d2), null);
});

test('pay run: a salary has the unpaid days taken off; hourly staff are not paid hours they did not work', () => {
  const rules = payRules();
  const prof = { user_uid: ravi.uid, pay_type: 'salary', weekly_salary: 600, normal_hours: 48, allowances: [], tin: '123', fnpf_member: 1, tax_status: 'resident' };
  const ws = '2026-10-10';
  const line = computeLine(ravi, prof, ws, rules, {});
  assert.strictEqual(line.earnings.salary, 400, `600 less 2 days of 100: ${line.earnings.salary}`);
  assert.strictEqual(line.unpaidDays, 2);
  assert.ok(line.warnings.some((w) => /2 unpaid days/.test(w)));
  const mereLine = computeLine(mere, { ...prof, user_uid: mere.uid }, ws, rules, {});
  assert.strictEqual(mereLine.earnings.salary, 600, 'sick with a sheet and a day off are not taken off');
});

test('"Absent?": someone rostered who has not clocked in 30 minutes after the start', () => {
  db().run('INSERT OR REPLACE INTO rosters (user_uid, days, updated_at) VALUES (?,?,?)', [mere.uid, JSON.stringify({ mon: { start: '08:00', end: '16:00', shop: 'S1' } }), stamp()]);
  const at = (hm) => new Date(`2026-10-19T${hm}:00`);
  clock.override = at('08:20');
  assert.ok(!A.notClockedIn(at('08:20')).some((p) => p.uid === mere.uid), 'not yet 30 minutes');
  assert.ok(A.notClockedIn(at('08:40')).some((p) => p.uid === mere.uid));
  A.markDay(manager, { userUid: mere.uid, date: '2026-10-19', kind: 'sick', sheet: false });
  assert.ok(!A.notClockedIn(at('08:40')).some((p) => p.uid === mere.uid), 'marked: not asked again');
  clock.override = new Date('2026-10-12T09:00:00');
});

let supplier; let flour; let sugar;
test('orders: owner orders are authorised at once; a supervisor\'s order waits and shows in To verify', () => {
  supplier = AP.saveSupplier(owner, { name: 'Punjas & Sons', tin: '50-11634-0-2', vatRegistered: true });
  const sId = supplier.uid || supplier;
  flour = I.saveItem(owner, { code: 'FL10', name: 'Flour Plain 10kg', unit: 'bag', cost: 10.8, price: 16.5, vatType: 'zero' }); flour = flour.uid || flour;
  sugar = I.saveItem(owner, { code: 'SU2', name: 'Sugar Brown 2kg', unit: 'pkt', cost: 2.42, price: 3.95, vatType: 'standard' }); sugar = sugar.uid || sugar;
  const mk = (u) => I.savePO(u, { supplierUid: sId, shopCode: 'S1', lines: [{ itemUid: flour, qty: 15, unitCost: 10.8 }, { itemUid: sugar, qty: 20, unitCost: 2.42 }] });
  const a = mk(owner);
  assert.strictEqual(I.submitPO(owner, a.uid, { canApprove: false }).status, 'approved');
  const b = mk(sup);
  const b2 = I.submitPO(sup, b.uid, { canApprove: false });
  assert.strictEqual(b2.status, 'awaiting');
  const item = V.queue({ include: 'waiting', withDocs: true }).find((x) => x.key === `po_orders:${b.uid}`);
  assert.ok(item && item.how === 'approve' && item.who === 'Sunil Supervisor');
  const rep0 = poReport(b.uid);
  assert.strictEqual(rep0.approved, false);
  assert.ok(rep0.info.some(([k, v]) => k === 'Authorised by' && /Waiting/.test(v)));
  I.submitPO(owner, b.uid, { canApprove: true });
  const rep = poReport(b.uid);
  assert.ok(rep.approved && rep.info.some(([k, v]) => k === 'Raised by' && /Sunil/.test(v)) && rep.info.some(([k, v]) => k === 'Authorised by' && /Owner/.test(v)));
  assert.ok(!rep.signatures, 'no lines to sign');
  // subtotal, VAT by rate and total – like the suppliers' tax invoices
  const t = rep.sections[0].totals.map((x) => `${x.label}=${x.value}`).join(' | ');
  assert.ok(/Subtotal \(excl. VAT\)=\$?210\.40/.test(t) && /Total VAT=\$?6\.05/.test(t) && /TOTAL \(incl. VAT\)=\$?216\.45/.test(t), t);
  assert.ok(rep.sections[0].columns.some((c) => c.key === 'vatAmt') && rep.sections[0].columns.some((c) => c.key === 'total'));
  assert.ok(rep.info.some(([k, v]) => k === 'To (supplier)' && /TIN \d/.test(v)));
  const sp = I.vatSplit([{ amount: 162, vatType: 'zero' }, { amount: 48.4, vatType: 'standard' }]);
  assert.deepStrictEqual(sp, { sub: 210.4, vat: 6.05, total: 216.45, zero: 162 });
});

test('To verify: a delivery counted in, with its papers one tap away; Query to the person and the answer', () => {
  const o = I.savePO(owner, { supplierUid: supplier.uid || supplier, shopCode: 'S1', lines: [{ itemUid: flour, qty: 15, unitCost: 10.8 }] });
  I.submitPO(owner, o.uid, { canApprove: true });
  const po = I.getPO(o.uid);
  const r = I.receiveDelivery(asha, { poUid: o.uid, lines: [{ lineUid: po.lines[0].uid, qty: 14, unitCost: 11 }], invoice: { invoiceNo: 'INV-48211', total: 154 }, acceptReason: 'one bag short, price up' });
  const x = V.queue({ include: 'waiting', withDocs: true }).find((i) => i.key === `inv_receipts:${r.uid}`);
  assert.ok(x, 'the delivery is on To verify');
  const labels = x.docs.map((d) => d.label);
  assert.ok(labels.includes('Delivery count') && labels.some((l) => /Invoice INV-48211/.test(l)) && labels.some((l) => /Purchase order/.test(l)), labels.join(', '));
  const qid = Q.askQuery(owner, { key: x.key, table: x.table, uid: x.uid, title: 'Delivery', toName: x.who, question: 'Where is the 15th bag?' });
  assert.strictEqual(Q.openQueriesFor(asha.uid).length, 1, 'the question is on Asha\'s Home');
  Q.answerQuery(asha, qid, 'Driver will bring it tomorrow');
  const y = V.queue({ include: 'waiting', withDocs: true }).find((i) => i.key === x.key);
  assert.ok(y.query && y.query.status === 'answered' && /tomorrow/.test(y.query.answer));
  // the goods received note: like a tax invoice, with our order and the supplier's invoice
  const grn = receiptReport(r.uid);
  const gt = Object.fromEntries(grn.sections[0].totals.map((x) => [x.label, x.value]));
  assert.ok(/154\.00/.test(gt['Subtotal (excl. VAT)']) && /154\.00/.test(gt['TOTAL (incl. VAT)']), JSON.stringify(gt));
  assert.ok(grn.info.some(([k, v]) => k === 'Our order no.' && /PO|\d/.test(v)) && grn.info.some(([k, v]) => k === 'Counted in by' && v === 'Asha'));
  assert.ok(/Goods Received Note/.test(reportToHtml(grn)));
  V.verify(owner, { table: 'inv_receipts', uid: r.uid });
  assert.ok(!V.queue({ include: 'waiting', withDocs: true }).some((i) => i.key === x.key));
  assert.strictEqual(Q.queriesByKey()[x.key], undefined, 'the query closes when verified');
});

test('Aronium purchases: matched to app invoices by number or total; missing ones listed', () => {
  db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES ('S1-T1|purchases|2026-10-12|0','S1-T1','S1','S1-T1','purchases','2026-10-12',0,1,?,'h','2026-10-12','1.1','2026-10-12','bridge','synced')`,
  [JSON.stringify([{ id: 1, number: 'P-1', supplier: 'Punjas & Sons', date: today, total: 154, reference: 'INV-48211' }, { id: 2, number: 'P-2', supplier: 'FMF Foods', date: today, total: 287.54, reference: '' }])]);
  const r = purchasesCheck({ from: '2026-10-01' });
  assert.strictEqual(r.matched.length, 1);
  assert.strictEqual(r.missing.length, 1);
  assert.strictEqual(r.missing[0].supplier, 'FMF Foods');
});

done();
