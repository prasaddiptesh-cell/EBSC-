// 3.9.5 the staff credit trail from Aronium (till program 1.2): the sales behind each balance, the pay-day deduction
// that lists the sales it pays (never taken twice before Aronium shows it paid), the payslip with the trail and the
// settlement receipt; customer accounts that are not staff (Daily Needs, weekly bread account, paid on Sunday);
// invoices of 2 or 3 pages read together.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, stamp } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as O from '../src/modules/owed/service.js';
import { computeLine, payRules } from '../src/modules/payroll/service.js';
import { payslipSections, payslipReport } from '../src/modules/payroll/payslip.js';
import { aroniumCreditTrail } from '../src/modules/aronium/link.js';
import { parseInvoiceText } from '../src/modules/payables/parser.js';
import { reportToHtml } from '../src/services/export.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-14T09:00:00'); // a Wednesday
setSetting('cloud_key', 'tablet-key-123');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const ravi = saveUser({ name: 'Ravi Kumar', pin: '8642', role: 'staff', shop_code: 'S1' });
const sita = saveUser({ name: 'Sita Devi', pin: '3579', role: 'staff', shop_code: 'S1' });
const T = '2026-10-14 08:00:00';
const feed = (source, kind, data, part = 0, parts = 1) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
  VALUES (?,?,?,?,?,'all',?,?,?,?,?,'1.2',?,'bridge','synced')`, [`${source}|${kind}|all|${part}`, source, source.split('-')[0], source, kind, part, parts, JSON.stringify(data), `h${Math.random()}`, T, T]);
const sale = (id, customer, date, total, owing, items, payments = [], number = `R${id}`) => ({ id, customer_id: 1, customer, number, date, total, paid: total - owing, owing, refund: false, items, payments });

// Two tills in Shop 1: Ravi bought on both. Daily Needs is a business on a weekly bread account.
feed('S1-T1', 'credit', [{ customer_id: 1, name: 'Ravi Kumar', owing: 20, documents: 2, oldest: '2026-10-08' }, { customer_id: 9, name: 'Daily Needs', owing: 64, documents: 3, oldest: '2026-10-06' }]);
feed('S1-T2', 'credit', [{ customer_id: 1, name: 'Ravi Kumar', owing: 5.5, documents: 1, oldest: '2026-10-12' }]);
feed('S1-T1', 'credit_trail', [
  sale(101, 'Ravi Kumar', '2026-10-08', 12, 12, [['Rice 10kg', 1, 12]]),
  sale(102, 'Ravi Kumar', '2026-10-10', 8, 8, [['Milk 1L', 2, 5], ['Bread', 1, 3]]),
  sale(90, 'Ravi Kumar', '2026-09-30', 15, 0, [['Sugar 2kg', 3, 15]], [{ date: '2026-10-03', type: 'Cash', money: true, amount: 15 }]),
  sale(201, 'Daily Needs', '2026-10-06', 30, 30, [['Bread 600g', 20, 30]]),
  sale(202, 'Daily Needs', '2026-10-09', 22, 22, [['Bread 600g', 15, 22]]),
  sale(203, 'Daily Needs', '2026-10-13', 12, 12, [['Bread 600g', 8, 12]]),
  sale(190, 'Daily Needs', '2026-09-29', 40, 0, [['Bread 600g', 27, 40]], [{ date: '2026-10-05', type: 'M-PAiSA', money: true, amount: 40 }]),
  sale(180, 'Daily Needs', '2026-09-22', 10, 0, [['Bread 600g', 7, 10]], [{ date: '2026-09-22', type: 'Account', money: false, amount: 10 }, { date: '2026-09-28', type: 'Cash', money: true, amount: 10 }]),
]);
feed('S1-T2', 'credit_trail', [sale(55, 'Ravi Kumar', '2026-10-12', 5.5, 5.5, [['Soap', 1, 5.5]])]);
// the balances come in the way processLink brings them (one line per person)
O.syncCreditFromLink([{ name: 'Ravi Kumar', balance: 25.5, since: '2026-10-08' }, { name: 'Daily Needs', balance: 64, since: '2026-10-06' }], { today: '2026-10-14' });

test('the trail: every sale behind Ravi\'s balance from both tills, newest first, paid ones marked', () => {
  assert.strictEqual(aroniumCreditTrail().length, 9);
  const tr = O.creditTrail({ userUid: ravi.uid });
  assert.deepStrictEqual(tr.map((d) => d.number), ['R55', 'R102', 'R101', 'R90']);
  assert.strictEqual(tr.filter((d) => d.open).reduce((s, d) => s + d.owing, 0), 25.5);
  assert.ok(!tr.find((d) => d.number === 'R90').open, 'paid in cash on 3 Oct');
  assert.strictEqual(O.creditTrail({ userUid: sita.uid }).length, 0);
});

const prof = (u) => ({ user_uid: u.uid, pay_type: 'hourly', rate: 5, normal_hours: 48, allowances: [], tin: '1', fnpf_no: '1', fnpf_member: 1, tax_status: 'resident' });
const addHours = (u, date, h) => {
  const at = (hh) => `${date} ${String(hh).padStart(2, '0')}:00:00`;
  db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, voided, updated_at, updated_device, sync_status) VALUES (?,?,?,'IN',?,?,'S1','t','pin',0,?,'t','pending')", [`I-${u.uid}-${date}`, u.uid, u.name, at(7), at(7), at(7)]);
  db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, voided, updated_at, updated_device, sync_status) VALUES (?,?,?,'OUT',?,?,'S1','t','pin',0,?,'t','pending')", [`O-${u.uid}-${date}`, u.uid, u.name, at(7 + h), at(7 + h), at(7 + h)]);
};
for (const d of ['2026-10-10', '2026-10-12', '2026-10-13', '2026-10-14']) addHours(ravi, d, 8);
let line;
test('pay day: the Aronium staff credit is taken from pay and the payslip lists the sales it pays', () => {
  line = computeLine(ravi, prof(ravi), '2026-10-10', payRules(), {});
  const d = line.deductions.find((x) => x.aronium);
  assert.ok(d, JSON.stringify(line.deductions));
  assert.strictEqual(d.amount, 25.5);
  assert.strictEqual(d.kind, 'staff_credit');
  assert.ok(/Pays: 12\/10 #R55 \$?5\.50/.test(d.detail) && /08\/10 #R101/.test(d.detail), d.detail);
  assert.deepStrictEqual(d.sales.map((x) => x.number), ['R55', 'R102', 'R101']);
  assert.ok(line.net > 0);
  // not enough pay: only what is there is taken, with a warning
  const small = computeLine(ravi, { ...prof(ravi), rate: 0.2 }, '2026-10-10', payRules(), {});
  const d2 = small.deductions.find((x) => x.aronium);
  assert.ok(!d2 || d2.amount <= small.gross, 'never more than the pay');
  assert.ok(small.warnings.some((w) => /Aronium staff credit/.test(w)) || (d2 && d2.amount === 25.5));
  // skipped for this pay (manager unticked it)
  const skip = computeLine(ravi, prof(ravi), '2026-10-10', payRules(), { skipDebts: [O.arDebtUid(ravi.uid, '2026-10-16')] });
  assert.ok(!skip.deductions.some((x) => x.aronium));
  assert.ok(!computeLine(sita, prof(sita), '2026-10-10', payRules(), {}).deductions.some((x) => x.aronium), 'Sita owes nothing');
});

test('never taken twice: a final pay run that took it, before Aronium shows it paid, is taken off the next balance', () => {
  db().run("INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, totals, created_by_name, created_at, run_kind, frequency, version, updated_at, updated_device) VALUES ('RUN1','2026-10-10','2026-10-16','2026-10-17','final','{}','Owner',?,'regular','weekly',1,?,'t')", [T, T]);
  db().run(`INSERT INTO pay_lines (uid, run_uid, user_uid, name, include, deductions, gross, net, updated_at, updated_device) VALUES ('L1','RUN1',?,?,1,?,200,174.5,?,'t')`,
    [ravi.uid, ravi.name, JSON.stringify(line.deductions), T]);
  const next = O.aroniumCreditDeduction(ravi.uid, '2026-10-23');
  assert.strictEqual(next, null, 'the balance still shows the old sales: nothing more to take');
  // the settlement receipt is recorded in Aronium and photographed; a newer balance arrives the next day
  const due = O.settlementsDue();
  assert.ok(due.some((x) => x.userUid === ravi.uid && x.amount === 25.5), 'receipt photo asked for');
  const cs = O.addSettlement(owner, { runUid: 'RUN1', debtUid: line.deductions.find((x) => x.aronium).debtUid, userUid: ravi.uid, amount: 25.5, receiptNo: 'S-77', date: '2026-10-17', photos: ['file:///receipt.jpg'] });
  assert.ok(cs);
  db().run("UPDATE credit_settlements SET created_at = '2026-10-17 10:00:00'");
  assert.ok(!O.settlementsDue().some((x) => x.userUid === ravi.uid));
  clock.override = new Date('2026-10-20T09:00:00');
  O.syncCreditFromLink([{ name: 'Ravi Kumar', balance: 9, since: '2026-10-19' }, { name: 'Daily Needs', balance: 64, since: '2026-10-06' }], { today: '2026-10-20' });
  const after = O.aroniumCreditDeduction(ravi.uid, '2026-10-23');
  assert.strictEqual(after && after.amount, 9, 'only the new credit');
  clock.override = new Date('2026-10-14T09:00:00');
});

test('payslip: the sales it paid and the Aronium settlement receipt photo', () => {
  const l = { ...db().get("SELECT * FROM pay_lines WHERE uid = 'L1'"), run_uid: 'RUN1' };
  const rep = payslipReport('L1');
  const tr = rep.sections.find((x) => x.key === 'credit_trail');
  assert.ok(tr && tr.rows.length === 3, JSON.stringify(rep.sections.map((x) => x.key)));
  assert.ok(tr.rows.some((r) => /2 × Milk 1L/.test(r.what)));
  assert.ok(rep.images.length === 1 && /S-77/.test(rep.images[0].caption));
  assert.ok(/Aronium sales/.test(reportToHtml(rep)));
  assert.ok(l);
});

test('a staff member whose credit is typed in the app as a charge: not taken twice', async () => {
  const P = await import('../src/modules/payroll/service.js');
  for (const d of ['2026-10-12', '2026-10-13']) addHours(sita, d, 8);
  P.chargeStaff(owner, { userUid: sita.uid, source: 'staff_credit', amount: 10, perPay: 10, reason: 'Aronium statement', photos: ['file:///s.jpg'] });
  O.syncCreditFromLink([{ name: 'Ravi Kumar', balance: 25.5, since: '2026-10-08' }, { name: 'Sita Devi', balance: 10, since: '2026-10-01' }, { name: 'Daily Needs', balance: 64, since: '2026-10-06' }], { today: '2026-10-14' });
  const l2 = computeLine(sita, prof(sita), '2026-10-10', payRules(), {});
  assert.strictEqual(l2.deductions.filter((x) => x.kind === 'staff_credit').length, 1);
  assert.ok(!l2.deductions.some((x) => x.aronium));
});

test('Daily Needs: a customer account on its own – this week, last payment, not paid since Sunday', () => {
  const acc = O.customerAccounts({ today: '2026-10-14' });
  assert.deepStrictEqual(acc.map((a) => a.name), ['Daily Needs'], 'staff are not customer accounts');
  const a = acc[0];
  assert.strictEqual(a.owing, 64);
  assert.strictEqual(a.lastPayDay, '2026-10-11');
  assert.strictEqual(a.thisWeek, 12, 'the week since Sunday');
  assert.strictEqual(a.late, 52, 'bought on 6 and 9 Oct, not paid on Sunday 11 Oct');
  assert.strictEqual(a.lateSince, '2026-10-06');
  assert.ok(a.lastPayment.type === 'M-PAiSA' && a.lastPayment.amount === 40, 'an "Account" mark is not money');
  const al = require_alerts();
  assert.ok(al.some((x) => /Daily Needs has not paid/.test(x.text)), JSON.stringify(al.map((x) => x.text)));
  O.saveAccountSetting(owner, 'Daily Needs', { payDay: 1 });
  assert.strictEqual(O.customerAccounts({ today: '2026-10-14' })[0].lastPayDay, '2026-10-12', 'paid on Mondays now');
  O.saveAccountSetting(owner, 'Daily Needs', { payDay: 0, hide: true });
  assert.strictEqual(O.customerAccounts({ today: '2026-10-14' }).length, 0);
  O.saveAccountSetting(owner, 'Daily Needs', { payDay: 0, hide: false });
});
import { alerts as owedAlerts } from '../src/modules/owed/alerts.js';
function require_alerts() { return owedAlerts(owner); }

test('a till PC still sending part of the list: nothing half-read is shown', () => {
  feed('S2-T1', 'credit_trail', [sale(1, 'Mere', '2026-10-13', 4, 4, [])], 0, 2); // part 1 of 2 only
  assert.ok(!aroniumCreditTrail().some((d) => d.customer === 'Mere'));
  feed('S2-T1', 'credit_trail', [sale(2, 'Mere', '2026-10-13', 6, 6, [])], 1, 2);
  assert.strictEqual(aroniumCreditTrail().filter((d) => d.customer === 'Mere').length, 2);
});

test('big trail: 5000 sales on account stay quick', () => {
  const many = [];
  for (let i = 0; i < 5000; i++) many.push(sale(10000 + i, `Customer ${i % 40}`, `2026-0${7 + (i % 3)}-1${i % 9}`, 3, i % 4 ? 0 : 3, [['Bread', 2, 3]]));
  for (let p = 0; p < 5; p++) feed('S2-T2', 'credit_trail', many.slice(p * 1000, p * 1000 + 1000), p, 5);
  const t0 = Date.now();
  const acc = O.customerAccounts({ today: '2026-10-14' });
  const ms = Date.now() - t0;
  assert.ok(acc.length >= 40, String(acc.length));
  assert.ok(ms < 4000, `${ms} ms`);
});

test('invoices of 2 or 3 pages: read together, the total from the last page (not the carried-forward total)', () => {
  const p1 = 'PUNJAS PTE LIMITED\nTAX INVOICE\nTIN : 50-11634-0-2\nInvoice No. : 2400/1CS/26010187\nInvoice Date : 23-09-2026\nPage 1 of 3\n10-02023-0004 15.00 bag PUNJAS BAKERS FLOUR 50KG 86.39 1,295.85 0.00 1,295.85\nCarried forward 1,295.85';
  const p2 = 'PUNJAS PTE LIMITED\nTAX INVOICE\nInvoice No. : 2400/1CS/26010187\nPage 2 of 3\nBrought forward 1,295.85\n10-02029-0001 1.00 bag PUNJAS BREAD IMPROVER 15KG 136.00 136.00 12.44 148.44\nCarried forward 1,444.29';
  const p3 = 'PUNJAS PTE LIMITED\nInvoice No. : 2400/1CS/26010187\nPage 3 of 3\nSubtotal 1,431.85\nVAT 12.44\nTOTAL 1,444.29\nGOODS REMAIN THE PROPERTY OF THE SUPPLIER UNTIL PAID FOR IN FULL';
  const r = parseInvoiceText([p1, p2, p3].join('\n'), [{ name: 'Punjas Pte Limited', tin: '50-11634-0-2' }], 0.125);
  assert.strictEqual(r.total, 1444.29, JSON.stringify(r));
  assert.strictEqual(r.vat, 12.44);
  assert.strictEqual(r.invoice_no, '2400/1CS/26010187');
});

done();
