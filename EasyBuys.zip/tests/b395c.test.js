// 3.9.5 to the limits: wrong input, odd names, very large lists, two tablets at once, things deleted under a link,
// days changed again and again, pay that would go below zero, a till PC that sends rubbish – nothing may crash or
// give a wrong figure.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, dateStr, stamp, addDays } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as D from '../src/services/duties.js';
import * as A from '../src/modules/timesheets/absence.js';
import * as V from '../src/modules/verify/service.js';
import * as Q from '../src/modules/verify/queries395.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as O from '../src/modules/owed/service.js';
import { poReport, receiptReport } from '../src/modules/inventory/reports.js';
import { computeLine, payRules } from '../src/modules/payroll/service.js';
import { purchasesCheck } from '../src/modules/aronium/purchasesCheck.js';
import { aroniumCreditTrail } from '../src/modules/aronium/link.js';
import { reportToHtml, reportToCsv } from '../src/services/export.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
setSetting('cloud_key', 'tablet-key-123');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Ana Admin', pin: '86420', role: 'admin' });
const manager = saveUser({ name: 'Mona Manager', pin: '6284', role: 'manager', shop_code: 'S1' });
const sup = saveUser({ name: 'Sunil Supervisor', pin: '7351', role: 'supervisor', shop_code: 'S1' });
const staff = [];
for (let i = 0; i < 25; i++) staff.push(saveUser({ name: `Staff ${String.fromCharCode(65 + i)} ‘O’Neil-Ñ ${i}`, pin: String(61000 + i * 7), role: i % 5 === 0 ? 'worker' : 'staff', shop_code: i % 2 ? 'S2' : 'S1' }));
const today = dateStr();

test('checklists: odd text, 30-item cap, editing while a list is half done keeps what was ticked, other device ticks the same list', () => {
  throws(() => D.saveDutyList(manager, { duty: 'cashier', items: [{ text: 'x' }], active: true }), /owner or admin/);
  throws(() => D.saveDutyList(owner, { duty: 'cleaner', items: [{ text: 'x' }], active: true }), /job/);
  throws(() => D.saveDutyList(owner, { duty: 'cashier', items: [{ text: '   ' }], active: true }), /at least one/);
  throws(() => D.saveDutyList(owner, { duty: 'cashier', items: Array.from({ length: 31 }, (_, i) => ({ text: `Item ${i}` })), active: true }), /30/);
  const s = staff[1];
  let m = D.myDutyToday(s);
  m = D.tickDuty(s, m.items[0].id, true);
  m = D.tickDuty(s, m.items[0].id, true); // twice – no harm
  assert.strictEqual(m.ticked, 1);
  // the owner changes the shop assistant list in the middle of the day: today's list keeps its own items
  const lst = D.listDutyLists().find((l) => l.duty === 'assistant');
  D.saveDutyList(admin, { uid: lst.uid, duty: 'assistant', name: lst.name, items: [{ text: '😀 Emoji item – “quotes” & <b>tags</b>' }].concat(lst.items), active: true });
  m = D.myDutyToday(s);
  assert.strictEqual(m.total, 6, 'today keeps the list it started with');
  assert.strictEqual(D.myDutyToday(staff[3]).total, 7, 'someone starting now gets the new list');
  throws(() => D.tickDuty(s, 'nope', true), /not on your list/);
  // the same list ticked on two tablets: the run is one row (same id), never two
  const run = D.getRun(`${s.uid}|${today}|assistant`);
  db().run('INSERT OR IGNORE INTO duty_runs (uid, user_uid, name, duty, run_date, items, ticks, skipped, updated_at) VALUES (?,?,?,?,?,?,?,?,?)', [run.uid, s.uid, s.name, 'assistant', today, '[]', '{}', '{}', stamp()]);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM duty_runs WHERE user_uid = ?', [s.uid]).n, 1);
  // switching a list off: nobody has one; on again: back
  D.setDutyListOn(owner, lst.uid, false);
  assert.strictEqual(D.myDutyToday(staff[3]), null);
  D.setDutyListOn(owner, lst.uid, true);
  assert.ok(D.myDutyToday(staff[3]));
  // a manager has no list unless given one
  assert.strictEqual(D.myDutyToday(manager), null);
  D.setDuty(owner, manager.uid, 'cashier');
  assert.strictEqual(D.myDutyToday(manager).duty, 'cashier');
  D.setDuty(owner, manager.uid, '');
  assert.strictEqual(D.myDutyToday(manager), null, 'set to "no checklist" sticks even though the role would have one');
});

test('roster marks: the same day changed again and again, past days, leave over the balance, own day', () => {
  const p = staff[2];
  const d = '2026-10-15';
  for (const k of ['off', 'absent', 'sick', 'leave', 'work', 'off', 'leave', 'leave']) {
    const opt = { userUid: p.uid, date: d, kind: k, reason: k === 'absent' ? 'Family' : '', sheet: false, leaveType: 'ANNUAL' };
    A.markDay(manager, opt);
  }
  const m = A.markOf(p.uid, d);
  assert.strictEqual(m.kind, 'leave');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM leave_requests WHERE user_uid = ? AND status = 'approved' AND from_date = ?", [p.uid, d]).n, 1, 'only one approved leave for the day');
  throws(() => A.markDay(manager, { userUid: p.uid, date: '15/10/2026', kind: 'off' }), /day/);
  throws(() => A.markDay(manager, { userUid: 'nobody', date: d, kind: 'off' }), /not found/);
  throws(() => A.markDay(manager, { userUid: p.uid, date: d, kind: 'holiday' }), /Choose/);
  throws(() => A.markDay(manager, { userUid: manager.uid, date: d, kind: 'absent', reason: 'x' }), /Someone else/);
  A.markDay(manager, { userUid: p.uid, date: '2025-01-06', kind: 'absent', reason: 'Old record' });
  assert.strictEqual(A.markOf(p.uid, '2025-01-06').kind, 'absent');
  // leave over the balance: refused, and the day is left as it was (no half-made mark)
  const q = staff[4];
  db().run("INSERT OR REPLACE INTO leave_entitlements (uid, user_uid, type, year, days, updated_at) VALUES (?,?, 'ANNUAL', 2026, 0, ?)", [`${q.uid}|ANNUAL|2026`, q.uid, stamp()]);
  let err = null;
  try { A.markDay(manager, { userUid: q.uid, date: d, kind: 'leave', leaveType: 'ANNUAL' }); } catch (e) { err = e; }
  if (err) assert.strictEqual(A.markOf(q.uid, d), null, 'refused: nothing marked');
});

test('pay: a whole week unpaid never makes a salary negative; a public holiday is not taken off', () => {
  const p = staff[6];
  for (let i = 0; i < 7; i++) A.markDay(manager, { userUid: p.uid, date: addDays('2026-10-17', i), kind: 'absent', reason: 'No call, no show' });
  const prof = { user_uid: p.uid, pay_type: 'salary', weekly_salary: 600, normal_hours: 48, allowances: [], tin: '1', fnpf_no: '1', fnpf_member: 1, tax_status: 'resident' };
  const l = computeLine(p, prof, '2026-10-17', payRules(), {});
  assert.strictEqual(l.earnings.salary, 0);
  assert.ok(l.net >= 0 || l.warnings.some((w) => /below zero/.test(w)));
  const rules = { ...payRules(), deductUnpaidSalary: false };
  assert.strictEqual(computeLine(p, prof, '2026-10-17', rules, {}).earnings.salary, 600, 'the rule can be switched off');
});

test('"Absent?" for 25 people at once stays quick and skips people on leave, marked or clocked in', () => {
  const at = new Date('2026-10-19T10:00:00');
  for (const s of staff) db().run('INSERT OR REPLACE INTO rosters (user_uid, days, updated_at) VALUES (?,?,?)', [s.uid, JSON.stringify({ mon: { start: '08:00', end: '17:00', shop: s.shop_code } }), stamp()]);
  db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, voided, updated_at, updated_device, sync_status) VALUES ('PX',?,?,'IN','2026-10-19 07:55:00','2026-10-19 07:55:00','S1','t','pin',0,'x','t','pending')", [staff[0].uid, staff[0].name]);
  A.markDay(manager, { userUid: staff[7].uid, date: '2026-10-19', kind: 'off' });
  const t0 = Date.now();
  const list = A.notClockedIn(at);
  assert.ok(Date.now() - t0 < 3000);
  assert.ok(!list.some((x) => x.uid === staff[0].uid) && !list.some((x) => x.uid === staff[7].uid) && list.length >= 20, String(list.length));
  assert.strictEqual(A.notClockedIn(new Date('2026-10-19T18:00:00')).length, 0, 'after the shift ended nobody is asked any more');
});

test('To verify: 1500 deliveries, papers deleted under a link, a query to someone who left – no crash, quick', () => {
  const s = AP.saveSupplier(owner, { name: 'Bulk Supplier' });
  const sid = s.uid || s;
  const it = I.saveItem(owner, { code: 'BLK', name: 'Bulk item', unit: 'each', cost: 1, price: 2, vatType: 'standard' });
  const T = stamp();
  db().transaction(() => {
    for (let i = 0; i < 1500; i++) {
      db().run("INSERT INTO inv_receipts (uid, kind, supplier_uid, supplier_name, shop_code, receive_date, invoice_uid, invoice_no, total, lines, by_name, status, created_at, updated_at) VALUES (?, 'receive', ?, 'Bulk Supplier', 'S1', ?, ?, ?, 10, ?, 'Asha', 'active', ?, ?)",
        [`RCX${i}`, sid, addDays(today, -(i % 90)), i % 3 ? `GONE${i}` : null, `B${i}`, JSON.stringify([{ itemUid: it.uid || it, code: 'BLK', name: 'Bulk item', qty: 10, unitCost: 1 }]), T, T]);
    }
  });
  const t0 = Date.now();
  const q = V.queue({ include: 'waiting', withDocs: true });
  const ms = Date.now() - t0;
  assert.ok(q.filter((x) => x.table === 'inv_receipts').length === 1500);
  assert.ok(ms < 15000, `${ms} ms`);
  const x = q.find((y) => y.uid === 'RCX1');
  const docs = V.docsFor(x);
  assert.ok(Array.isArray(docs) && docs.some((d) => d.label === 'Delivery count') && !docs.some((d) => /Invoice/.test(d.label)), 'a missing invoice is simply not listed');
  assert.ok(V.queue({ include: 'waiting' }).slice(0, 200).every((y) => !y.docs) && V.queue({ include: 'waiting', withDocs: 50 }).slice(0, 50).every((y) => Array.isArray(y.docs)), 'papers only when asked for');
  throws(() => Q.askQuery(owner, { key: x.key, question: '  ' }), /question/);
  const id = Q.askQuery(owner, { key: x.key, table: x.table, uid: x.uid, toName: 'Someone Who Left', question: 'Who signed?' });
  assert.ok(Q.getQuery(id).to_uid === null);
  Q.answerQuery(owner, id, 'Found the paper');
  throws(() => Q.answerQuery(owner, id, 'again'), /already answered/);
  const sum = V.queueSummary();
  assert.ok(sum.waiting >= 1500);
});

test('purchase orders: a supervisor\'s order over the limit and the budget; an empty order; a supplier with an odd name', () => {
  const s = AP.saveSupplier(owner, { name: 'Ñandu & “Sons” <Ltd>' });
  const sid = s.uid || s;
  const it = I.saveItem(owner, { code: 'Z1', name: 'Zero item', unit: 'each', cost: 2, price: 3, vatType: 'zero' });
  const o = I.savePO(sup, { supplierUid: sid, shopCode: 'S1', lines: [{ itemUid: it.uid || it, qty: 1000000, unitCost: 2 }] });
  assert.strictEqual(I.submitPO(sup, o.uid, { canApprove: false }).status, 'awaiting');
  throws(() => I.submitPO(sup, o.uid, { canApprove: false }) && I.getPO(o.uid).status !== 'awaiting' ? null : (() => { throw new Error('still waiting – fine'); })(), /still waiting/);
  const rep = poReport(o.uid);
  const html = reportToHtml(rep);
  assert.ok(/NOT YET APPROVED/.test(html) && !/<b>tags/.test(html) && /&lt;Ltd&gt;/.test(html), 'names are escaped');
  assert.ok(/2,000,000\.00|2000000\.00/.test(JSON.stringify(rep.sections[0].totals)));
  assert.ok(reportToCsv(rep).length > 0);
  throws(() => I.savePO(owner, { supplierUid: sid, shopCode: 'S1', lines: [] }) && I.submitPO(owner, I.listPOs({ supplierUid: sid, limit: 1 })[0].uid), /no products|product/i);
  assert.deepStrictEqual(I.vatSplit([{ amount: 'x', vatType: 'standard' }, { amount: null }, { amount: -10, vatType: 'zero' }]), { sub: -10, vat: 0, total: -10, zero: -10 });
  assert.deepStrictEqual(I.vatSplit(null), { sub: 0, vat: 0, total: 0, zero: 0 });
  assert.strictEqual(receiptReport('nope'), null);
});

test('a till PC sends rubbish: bad JSON, wrong shapes, missing fields – the app shows what it can', () => {
  const put = (src, kind, data) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES (?,?,?,?,?, 'all', 0, 1, ?, 'h', 'x', '1.2', 'x', 'bridge', 'synced')`, [`${src}|${kind}|all|0`, src, src.split('-')[0], src, kind, data]);
  put('S9-T1', 'credit_trail', '{not json');
  put('S9-T2', 'credit_trail', JSON.stringify({ hello: 'world' }));
  put('S9-T3', 'credit_trail', JSON.stringify([null, 5, 'x', { id: 1 }, { id: 2, customer: 'Odd', date: '2026-10-01', total: '7', owing: 'NaN', items: 'nope', payments: null }]));
  put('S9-T4', 'purchases', JSON.stringify([{}, null, 7]));
  put('S9-T5', 'credit', JSON.stringify([null, 3, { name: null, owing: 'x' }, { name: 'Odd Shop', owing: 12 }]));
  let tr = [];
  assert.doesNotThrow(() => { tr = aroniumCreditTrail(); });
  assert.doesNotThrow(() => O.customerAccounts());
  assert.doesNotThrow(() => O.creditTrail({ name: 'Odd' }));
  assert.doesNotThrow(() => purchasesCheck({ from: '2000-01-01' }));
  assert.doesNotThrow(() => O.aroniumCreditDeduction(staff[1].uid, '2026-10-16'));
});

test('handover blockers and team lists with a person who has no account any more, and a day with nobody in', () => {
  db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, shop_code, device, method, voided, updated_at, updated_device, sync_status) VALUES ('PGHOST','ghost','Ghost','IN',?,?,'S1','t','pin',0,'x','t','pending')", [`${today} 07:00:00`, `${today} 07:00:00`]);
  assert.doesNotThrow(() => D.teamDuties({ shopCode: 'S1', date: today }));
  assert.deepStrictEqual(D.teamDuties({ shopCode: 'S1', date: '2020-01-01' }), []);
  assert.deepStrictEqual(D.teamDuties({ shopCode: '', date: today }), []);
  assert.deepStrictEqual(D.handoverDutyBlockers({ shopCode: 'NOPE', date: today }), []);
  assert.doesNotThrow(() => D.dutyProblems({ from: '2000-01-01', to: '2100-01-01' }));
});

done();
