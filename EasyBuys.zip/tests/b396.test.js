// 3.9.6 Shop profile and the Deleted bin (90 days), pushed to the limits.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, dateStr, stamp, addDays, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as SP from '../src/services/shopProfile.js';
import * as BIN from '../src/services/bin.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as L from '../src/modules/licences/service.js';
import * as VW from '../src/services/verifyWatch.js';
import { pendingRecords, markRecordsSent, applyPulledRecords } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
setSetting('cloud_key', 'tablet-key-123');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Ana Admin', pin: '86420', role: 'admin' });
const manager = saveUser({ name: 'Mona Manager', pin: '6284', role: 'manager', shop_code: 'S1' });
const staff = saveUser({ name: 'Sam Staff', pin: '5173', role: 'staff', shop_code: 'S1' });
const today = dateStr();

// ---------------------------------------------------------------- shop profile
test('shop details: saved, checked, and bad input is refused with a plain reason', () => {
  SP.saveShopDetails(owner, 'S1', { address: '29 Drasa Avenue, Lautoka', phone: '666 1234', tin: '50-11634-0-2', mpaisa: '9252220', email: 'shop1@easybuys.com.fj', landlord: 'Drasa Holdings',
    hours: { mon: { open: '07:00', close: '21:00' }, sun: { open: '08:00', close: '13:00' }, sat: { closed: true } } });
  const s = SP.getShop('s1');
  assert.strictEqual(s.address, '29 Drasa Avenue, Lautoka');
  assert.strictEqual(s.hours.mon.open, '07:00');
  assert.strictEqual(s.hours.sat.closed, true);
  assert.strictEqual(s.hours.tue.open, '', 'a day not set stays empty');
  throws(() => SP.saveShopDetails(owner, 'S1', { tin: 'ABC' }), /TIN/);
  throws(() => SP.saveShopDetails(owner, 'S1', { email: 'not-an-email' }), /email/);
  throws(() => SP.saveShopDetails(owner, 'S1', { hours: { mon: { open: '7am', close: '21:00' } } }), /Monday.*07:00/);
  throws(() => SP.saveShopDetails(owner, 'S1', { hours: { tue: { open: '09:00', close: '09:00' } } }), /same/);
  throws(() => SP.saveShopDetails(owner, 'S1', { name: '' }), /shop name/);
  throws(() => SP.saveShopDetails(owner, 'S1', { address: 'x'.repeat(201) }), /too long/);
  throws(() => SP.saveShopDetails(staff, 'S1', { phone: '1' }), /Only the owner/);
  throws(() => SP.saveShopDetails(owner, 'NOPE', { phone: '1' }), /not in the list/);
  throws(() => SP.saveShopDetails(owner, 'S1', { managerUid: 'U-nobody' }), /staff list/);
  // a failed save changed nothing
  assert.strictEqual(SP.getShop('S1').tin, '50-11634-0-2');
  // rubbish stored in the hours never breaks the page
  db().run("UPDATE shops SET hours = '{not json' WHERE code = 'S2'");
  assert.strictEqual(SP.getShop('S2').hours.mon.closed, false);
  db().run("UPDATE shops SET hours = '[1,2,3]' WHERE code = 'S2'");
  assert.ok(SP.shopProfile('S2', owner));
});

test('open now: normal days, closed days, and hours past midnight', () => {
  const h = { mon: { open: '07:00', close: '21:00' }, tue: { open: '18:00', close: '02:00' }, sat: { closed: true } };
  assert.strictEqual(SP.openNow(h, new Date('2026-10-12T08:00:00')).open, true);          // Monday morning
  assert.strictEqual(SP.openNow(h, new Date('2026-10-12T22:00:00')).open, false);
  assert.strictEqual(SP.openNow(h, new Date('2026-10-12T06:00:00')).next.at, '07:00');
  assert.strictEqual(SP.openNow(h, new Date('2026-10-13T23:30:00')).open, true);          // Tuesday night
  assert.strictEqual(SP.openNow(h, new Date('2026-10-14T01:30:00')).open, true, 'still open from Tuesday');
  assert.strictEqual(SP.openNow(h, new Date('2026-10-14T03:00:00')).open, false);
  assert.strictEqual(SP.openNow(h, new Date('2026-10-17T10:00:00')).open, false);         // Saturday closed
  assert.strictEqual(SP.openNow({}, new Date()).open, false);
  assert.strictEqual(SP.hoursText({ open: '18:00', close: '02:00' }), '18:00 – 02:00 (next day)');
});

let efl; let supplierEfl;
test('bill accounts: several per shop, labelled; the same account number cannot be on two shops', () => {
  supplierEfl = AP.saveSupplier(owner, { name: 'Energy Fiji Limited', tin: '50-12345-0-1' });
  const sid = supplierEfl.uid || supplierEfl;
  efl = SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', label: 'EFL – shop', accountNo: '1234 5678', meterNo: 'M-998', supplierUid: sid });
  SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', label: 'EFL – bakery', accountNo: '1234 9999' });
  SP.saveAccount(owner, { shopCode: 'S1', kind: 'water', accountNo: 'W-77' });
  SP.saveAccount(owner, { shopCode: 'S1', kind: 'phone', label: 'Digicel line', accountNo: '9252220' });
  const list = SP.listAccounts('S1');
  assert.strictEqual(list.length, 4);
  assert.strictEqual(list.find((a) => a.kind === 'water').label, 'Water', 'label defaults to the kind');
  assert.strictEqual(list.find((a) => a.kind === 'water').provider, 'WAF (Water Authority of Fiji)');
  throws(() => SP.saveAccount(owner, { shopCode: 'S2', kind: 'power', accountNo: '12345678' }), /already on .*EFL – shop/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S2', kind: 'power', accountNo: '1234-5678' }), /already on/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S2', kind: 'power', accountNo: '' }), /account number/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S2', kind: 'power', accountNo: "12'; DROP TABLE shops;--" }), /odd characters/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S2', kind: 'spaceship', accountNo: '1' }), /what the account is for/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S9', kind: 'power', accountNo: '1' }), /Choose the shop/);
  throws(() => SP.saveAccount(staff, { shopCode: 'S1', kind: 'power', accountNo: '1' }), /Only the owner/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', accountNo: '55', supplierUid: 'SUP-none' }), /supplier/);
  // the same number for a different kind is fine (water and phone numbers can look alike)
  SP.saveAccount(owner, { shopCode: 'S2', kind: 'phone', accountNo: 'W-77' });
  // change keeps the uid
  SP.saveAccount(owner, { uid: efl, shopCode: 'S1', kind: 'power', label: 'EFL – front shop', accountNo: '1234 5678', meterNo: 'M-998', supplierUid: sid });
  assert.strictEqual(SP.getAccount(efl).label, 'EFL – front shop');
});

test('the latest bill of an account: the invoice that names the account number', () => {
  const sid = supplierEfl.uid || supplierEfl;
  AP.saveInvoice(owner, { supplierUid: sid, invoiceNo: 'E-1001', invoiceDate: addDays(today, -40), total: 410.5, shopCode: 'S1', description: 'Acct 12345678 Sept' }, { canCheck: true });
  AP.saveInvoice(owner, { supplierUid: sid, invoiceNo: 'E-1002', invoiceDate: addDays(today, -5), total: 120, shopCode: 'S1', description: 'Acct 12349999 bakery' }, { canCheck: true });
  const a = SP.listAccounts('S1').find((x) => x.uid === efl);
  assert.ok(a.last && a.last.no === 'E-1001' && a.last.matched, JSON.stringify(a.last));
  assert.strictEqual(a.last.total, 410.5);
});

test('papers, warnings and costs on the shop page; staff cannot open it', () => {
  L.saveLicence(owner, { name: 'Liquor licence', category: 'liquor', shopCode: 'S1', licenceNo: 'LQ-1', expiryDate: addDays(today, -3), remindDays: 60 });
  L.saveLicence(owner, { name: 'Health licence', category: 'health', shopCode: 'S1', expiryDate: addDays(today, 20), remindDays: 60 });
  L.saveLicence(owner, { name: 'Business licence S2', category: 'trading', shopCode: 'S2', expiryDate: addDays(today, 300) });
  const P = SP.shopProfile('S1', owner);
  assert.strictEqual(P.papers.length, 2);
  assert.ok(P.warnings.some((w) => /Liquor licence has expired/.test(w.text)), JSON.stringify(P.warnings));
  assert.ok(!P.warnings.some((w) => /electricity/.test(w.text)), 'has an EFL account');
  assert.strictEqual(P.glance.papers.overdue, 1);
  assert.strictEqual(P.glance.papers.due, 1);
  const P2 = SP.shopProfile('S2', owner);
  assert.ok(P2.warnings.some((w) => /electricity/.test(w.text)) && P2.warnings.some((w) => /water/.test(w.text)));
  throws(() => SP.shopProfile('S1', staff), /access/);
  throws(() => SP.shopCosts('S1', staff), /access/);
  const c = SP.shopCosts('S1', owner, { period: '12m' });
  assert.strictEqual(c.total, 530.5);
  assert.strictEqual(c.groups.reduce((a, g) => a + g.count, 0), 2);
  const m = SP.shopCosts('S1', owner, { period: 'month' });
  assert.ok(m.from.endsWith('-01') && m.to === today);
  const lm = SP.periodRange('last', '2026-03-31');
  assert.deepStrictEqual([lm.from, lm.to], ['2026-02-01', '2026-02-28']);
  const jan = SP.periodRange('last', '2026-01-15');
  assert.deepStrictEqual([jan.from, jan.to], ['2025-12-01', '2025-12-31']);
  assert.strictEqual(Math.round(SP.monthly(100, 'weekly') * 100) / 100, 433.33);
  const cards = SP.shopCards(owner);
  assert.ok(cards.find((x) => x.code === 'S1').accounts === 4);
});

test('a shop page with no data at all, and with rubbish data, still opens', () => {
  db().run("INSERT INTO shops (code, name, active, sort, updated_at) VALUES ('S7', 'Empty shop', 1, 9, ?)", [stamp()]);
  const P = SP.shopProfile('S7', owner);
  assert.strictEqual(P.accounts.length, 0);
  assert.ok(P.glance);
  db().run("INSERT INTO shop_accounts (uid, shop_code, kind, label, active, updated_at) VALUES ('SA-odd', 'S7', 'teleporter', 'odd', 1, ?)", [stamp()]);
  assert.strictEqual(SP.listAccounts('S7')[0].kindInfo.label, 'Other');
  assert.ok(SP.shopCosts('S7', owner).total === 0);
});

// ---------------------------------------------------------------- Deleted bin
let flour; let sid;
test('bin: only the owner or admin delete; a purchase order goes with its lines and comes back exactly', () => {
  const s = AP.saveSupplier(owner, { name: 'Punjas & Sons', tin: '50-11634-0-2' }); sid = s.uid || s;
  flour = I.saveItem(owner, { code: 'FL10', name: 'Flour Plain 10kg', unit: 'bag', cost: 10.8, price: 16.5, vatType: 'zero' }); flour = flour.uid || flour;
  const o = I.savePO(owner, { supplierUid: sid, shopCode: 'S1', lines: [{ itemUid: flour, qty: 15, unitCost: 10.8 }] });
  const before = db().all('SELECT * FROM po_lines WHERE po_uid = ?', [o.uid]);
  throws(() => BIN.deleteRecord(manager, 'po_orders', o.uid), /Only the owner or an admin/);
  throws(() => BIN.deleteRecord(staff, 'po_orders', o.uid), /Only the owner or an admin/);
  const plan = BIN.deletePlan('po_orders', o.uid);
  assert.ok(plan.alsoGoes.some((x) => /order line/.test(x)), plan.alsoGoes.join());
  const r = BIN.deleteRecord(admin, 'po_orders', o.uid, { reason: 'made twice' });
  assert.ok(!db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]));
  assert.strictEqual(db().all('SELECT * FROM po_lines WHERE po_uid = ?', [o.uid]).length, 0);
  const b = BIN.listBin()[0];
  assert.strictEqual(b.uid, r.uid);
  assert.strictEqual(b.daysLeft, 90);
  assert.ok(/made twice/.test(b.reason) && b.deleted_by_name === 'Ana Admin');
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Deleted Purchase order%'"), 'in the change history');
  throws(() => BIN.deleteRecord(owner, 'po_orders', o.uid), /not here any more/);
  BIN.restoreRecord(owner, r.uid);
  const after = db().all('SELECT * FROM po_lines WHERE po_uid = ?', [o.uid]);
  assert.strictEqual(after.length, before.length);
  assert.strictEqual(after[0].qty, before[0].qty);
  assert.strictEqual(I.getPO(o.uid).supplier_name, 'Punjas & Sons');
  throws(() => BIN.restoreRecord(owner, r.uid), /put back already/);
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Put back from the Deleted bin%'"));
});

test('bin: a paid invoice cannot be deleted until its payment is; deleting the payment undoes it', () => {
  const inv = AP.saveInvoice(owner, { supplierUid: sid, invoiceNo: 'P-7781', invoiceDate: today, total: 230, shopCode: 'S1' }, { canCheck: true });
  const iu = inv.uid || inv;
  const pay = AP.makePayment(owner, { supplierUid: sid, method: 'cash', shopCode: 'S1', payDate: today, allocations: [{ invoiceUid: iu, amount: 230 }] });
  const pu = pay.uid || pay;
  assert.strictEqual(AP.getInvoice(iu).owing, 0);
  const plan = BIN.deletePlan('ap_invoices', iu);
  assert.ok(plan.blocks.length && /delete the payment first/.test(plan.blocks.join()), plan.blocks.join(' | '));
  throws(() => BIN.deleteRecord(owner, 'ap_invoices', iu), /cannot be deleted yet[\s\S]*payment/);
  BIN.deleteRecord(owner, 'ap_payments', pu, { reason: 'wrong supplier' });
  assert.strictEqual(AP.getInvoice(iu).owing, 230, 'the invoice is owing again');
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_allocations WHERE payment_uid = ?', [pu]).n, 0);
  const bi = BIN.deleteRecord(owner, 'ap_invoices', iu);
  // the payment cannot come back while the invoice it paid is still in the bin
  const pb = BIN.listBin().find((b) => b.rkey === pu);
  throws(() => BIN.restoreRecord(owner, pb.uid), /Put back "Invoice P-7781/);
  BIN.restoreRecord(owner, bi.uid);
  BIN.restoreRecord(owner, pb.uid);
  assert.strictEqual(AP.getInvoice(iu).owing, 0, 'paid again after both are back');
});

test('bin: deleting a delivery takes its stock back off and the order is open again', () => {
  const o = I.savePO(owner, { supplierUid: sid, shopCode: 'S1', lines: [{ itemUid: flour, qty: 10, unitCost: 10.8 }] });
  I.submitPO(owner, o.uid, { canApprove: true });
  const po = I.getPO(o.uid);
  const stock0 = I.stockOf(flour, 'S1');
  const r = I.receiveDelivery(owner, { poUid: o.uid, lines: [{ lineUid: po.lines[0].uid, qty: 10, unitCost: 10.8 }], invoice: { invoiceNo: 'D-55', total: 108 } });
  assert.strictEqual(I.stockOf(flour, 'S1') - stock0, 10);
  const plan = BIN.deletePlan('inv_receipts', r.uid);
  assert.ok(plan.blocks.length === 0, plan.blocks.join(' | '));
  assert.ok(plan.alsoGoes.some((x) => /stock movement/.test(x)), plan.alsoGoes.join());
  BIN.deleteRecord(owner, 'inv_receipts', r.uid);
  assert.strictEqual(I.stockOf(flour, 'S1'), stock0, 'stock is back to before');
  assert.ok(['approved', 'sent'].includes(I.getPO(o.uid).status), I.getPO(o.uid).status);
  assert.strictEqual(I.getPO(o.uid).lines[0].qty_received, 0);
  // the order cannot be deleted while … nothing is against it now: it can
  assert.strictEqual(BIN.deletePlan('po_orders', o.uid).blocks.length, 0);
  const back = BIN.listBin().find((b) => b.rkey === r.uid);
  BIN.restoreRecord(owner, back.uid);
  assert.strictEqual(I.stockOf(flour, 'S1') - stock0, 10, 'stock in again');
  assert.strictEqual(I.getPO(o.uid).lines[0].qty_received, 10);
  // now the order has a delivery against it: blocked
  assert.ok(BIN.deletePlan('po_orders', o.uid).blocks.some((x) => /Delivery/.test(x)));
});

test('bin: a record in a month whose VAT return is filed needs a second yes', () => {
  const inv = AP.saveInvoice(owner, { supplierUid: sid, invoiceNo: 'OLD-1', invoiceDate: '2026-08-10', total: 50, shopCode: 'S1' }, { canCheck: true });
  db().run("INSERT INTO tax_return_versions (uid, kind, period, version, amount, data, status, updated_at) VALUES ('TRV-1', 'vat', '2026-08', 1, 10, '{}', 'lodged', ?)", [stamp()]);
  const plan = BIN.deletePlan('ap_invoices', inv.uid || inv);
  assert.ok(plan.closed && /2026-08/.test(plan.closed.why));
  throws(() => BIN.deleteRecord(owner, 'ap_invoices', inv.uid || inv), /VAT return for 2026-08 is filed/);
  const r = BIN.deleteRecord(owner, 'ap_invoices', inv.uid || inv, { confirmClosed: true });
  assert.strictEqual(BIN.getBinEntry(r.uid).closed_period, 1);
  throws(() => BIN.restoreRecord(owner, r.uid), /VAT return is filed/);
  BIN.restoreRecord(owner, r.uid, { confirmClosed: true });
  // books closed (lock date) as well
  setShared('gl_lock', { date: '2026-08-31' });
  assert.ok(/books are closed/.test(BIN.deletePlan('ap_invoices', inv.uid || inv).closed.why));
  setShared('gl_lock', null);
});

test('bin sync: the delete reaches other devices; an old copy never brings the record back', () => {
  const o = I.savePO(owner, { supplierUid: sid, shopCode: 'S2', lines: [{ itemUid: flour, qty: 3, unitCost: 10.8 }] });
  // pretend it was sent to the cloud
  markRecordsSent(pendingRecords(5000));
  const copy = db().get('SELECT * FROM po_orders WHERE uid = ?', [o.uid]);
  const r = BIN.deleteRecord(owner, 'po_orders', o.uid);
  const out = pendingRecords(5000);
  assert.ok(out.some((x) => x.t === 'bin_records' && x.k === r.uid) && out.some((x) => x.t === 'bin_parts'), 'the bin entry and its copy go to the cloud');
  // another device sends its old copy of the order: it is not brought back
  applyPulledRecords([{ t: 'po_orders', k: o.uid, u: copy.updated_at, row: { ...copy, updated_at: stamp(new Date('2026-10-12T10:00:00')) } }]);
  assert.ok(!db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]), 'still deleted');
  // on a device that still has it, the bin entry arriving removes it
  BIN.restoreRecord(owner, r.uid);
  assert.ok(db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]));
  const binRow = db().get('SELECT * FROM bin_records WHERE uid = ?', [r.uid]);
  applyPulledRecords([{ t: 'bin_records', k: r.uid, u: '2026-10-12 23:00:00', row: { ...binRow, status: 'binned', updated_at: '2026-10-12 23:00:00' } }]);
  assert.ok(!db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]), 'removed when the delete arrives');
  assert.ok(BIN.inBin('po_orders', o.uid));
  // and a "put back" arriving brings it back from the copy
  applyPulledRecords([{ t: 'bin_records', k: r.uid, u: '2026-10-12 23:30:00', row: { ...binRow, status: 'restored', updated_at: '2026-10-12 23:30:00' } }]);
  assert.ok(db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]), 'back');
  assert.ok(!BIN.inBin('po_orders', o.uid));
  // an empty marker from the cloud is never saved as a record
  applyPulledRecords([{ t: 'po_orders', k: 'PO-ghost', u: stamp(), row: { uid: 'PO-ghost', updated_at: stamp(), _gone: 1 } }]);
  assert.ok(!db().get("SELECT 1 AS x FROM po_orders WHERE uid = 'PO-ghost'"));
});

test('bin: after 90 days it is gone for good, also from the cloud copy', () => {
  const o = I.savePO(owner, { supplierUid: sid, shopCode: 'S1', lines: [{ itemUid: flour, qty: 1, unitCost: 10.8 }] });
  markRecordsSent(pendingRecords(5000));
  const r = BIN.deleteRecord(owner, 'po_orders', o.uid);
  markRecordsSent(pendingRecords(5000));
  assert.strictEqual(BIN.purgeBin({ today: addDays(today, 89) }), 0, 'not yet');
  assert.strictEqual(BIN.purgeBin({ today: addDays(today, 90) }) >= 1, true);
  const b = BIN.getBinEntry(r.uid);
  assert.strictEqual(b.status, 'gone');
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM bin_parts WHERE bin_uid = ?', [r.uid]).n, 0);
  throws(() => BIN.restoreRecord(owner, r.uid), /gone for good/);
  const out = pendingRecords(5000);
  const markers = out.filter((x) => x.scrub);
  assert.ok(markers.some((x) => x.t === 'po_orders' && x.k === o.uid && x.row._gone === 1), 'an empty marker overwrites the cloud copy');
  assert.ok(markers.some((x) => x.t === 'bin_parts'), 'the copy in the bin is cleared in the cloud too');
  assert.ok(!JSON.stringify(markers).includes('Punjas'), 'no details in the markers');
  markRecordsSent(out);
  assert.strictEqual(pendingRecords(5000).filter((x) => x.scrub).length, 0, 'sent once');
  // a late copy from an old device stays out
  applyPulledRecords([{ t: 'po_orders', k: o.uid, u: stamp(), row: { uid: o.uid, po_no: 'X', supplier_uid: sid, supplier_name: 'Punjas', shop_code: 'S1', order_date: today, status: 'draft', total: 1, updated_at: '2027-01-01 00:00:00' } }]);
  assert.ok(!db().get('SELECT 1 AS x FROM po_orders WHERE uid = ?', [o.uid]));
});

test('bin: a big record is kept in parts and comes back whole', () => {
  const lines = [];
  for (let k = 0; k < 120; k++) {
    const it = I.saveItem(owner, { code: `BIG${k}`, name: `Big product ${k} ${'ä“'.repeat(40)}`, unit: 'each', cost: 1, price: 2, vatType: 'standard' });
    lines.push({ itemUid: it.uid || it, qty: k + 1, unitCost: 1.11, note: 'n'.repeat(200) });
  }
  const o = I.savePO(owner, { supplierUid: sid, shopCode: 'S1', lines });
  const want = db().all('SELECT * FROM po_lines WHERE po_uid = ? ORDER BY sort', [o.uid]).map((r) => [r.item_uid, r.qty, r.name]);
  const r = BIN.deleteRecord(owner, 'po_orders', o.uid);
  const b = BIN.getBinEntry(r.uid);
  assert.ok(b.parts >= 2, `parts ${b.parts}`);
  for (const p of db().all('SELECT data FROM bin_parts WHERE bin_uid = ?', [r.uid])) assert.ok(p.data.length <= 30000);
  // a missing part (still on its way) is reported, not half-restored
  const keep = db().get('SELECT * FROM bin_parts WHERE bin_uid = ? AND n = 1', [r.uid]);
  db().run('DELETE FROM bin_parts WHERE uid = ?', [keep.uid]);
  throws(() => BIN.restoreRecord(owner, r.uid), /on its way/);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM po_lines WHERE po_uid = ?', [o.uid]).n, 0, 'nothing half-restored');
  db().run('INSERT INTO bin_parts (uid, bin_uid, n, data, updated_at) VALUES (?,?,?,?,?)', [keep.uid, keep.bin_uid, keep.n, keep.data, keep.updated_at]);
  BIN.restoreRecord(owner, r.uid);
  const got = db().all('SELECT * FROM po_lines WHERE po_uid = ? ORDER BY sort', [o.uid]).map((x) => [x.item_uid, x.qty, x.name]);
  assert.deepStrictEqual(got, want);
});

test('bin: shops, staff and products – what still uses them stops the delete', () => {
  // a shop with staff and records cannot go; an empty shop goes with its bill accounts
  assert.ok(BIN.deletePlan('shops', 'S1').blocks.length > 0);
  SP.saveAccount(owner, { shopCode: 'S7', kind: 'water', accountNo: 'W-S7' });
  db().run("DELETE FROM shop_accounts WHERE uid = 'SA-odd'");
  const plan = BIN.deletePlan('shops', 'S7');
  assert.strictEqual(plan.blocks.length, 0, plan.blocks.join(' | '));
  const r = BIN.deleteRecord(owner, 'shops', 'S7');
  assert.ok(!SP.getShop('S7'));
  assert.strictEqual(SP.listAccounts('S7').length, 0);
  BIN.restoreRecord(owner, r.uid);
  assert.strictEqual(SP.listAccounts('S7').length, 1);
  // the only owner login cannot be deleted
  assert.ok(BIN.deletePlan('users', owner.uid).blocks.some((x) => /only owner/.test(x)));
  // a product with stock history cannot be deleted
  assert.ok(BIN.deletePlan('inv_items', flour).blocks.length > 0);
  // a new product nobody used: goes, with its shop settings
  const p = I.saveItem(owner, { code: 'NEW1', name: 'Never used', unit: 'each', cost: 1, price: 2, vatType: 'standard' });
  assert.strictEqual(BIN.deletePlan('inv_items', p.uid || p).blocks.length, 0, BIN.deletePlan('inv_items', p.uid || p).blocks.join(' | '));
  // things that cannot be deleted here
  throws(() => BIN.deletePlan('audit_log', 'x'), /cannot be deleted here/);
  throws(() => BIN.deletePlan('bin_records', 'x'), /cannot be deleted here/);
  throws(() => BIN.deletePlan('nonsense; DROP TABLE users', 'x'), /cannot be deleted here/);
  throws(() => BIN.deletePlan('po_orders', "' OR 1=1 --"), /not here/);
});

test('bin: a bill account and a licence with its history and copies', () => {
  const acc = SP.saveAccount(owner, { shopCode: 'S2', kind: 'internet', label: 'Fibre', accountNo: 'NET-1' });
  BIN.deleteRecord(owner, 'shop_accounts', acc);
  assert.ok(!SP.getAccount(acc));
  const lic = L.saveLicence(owner, { name: 'Fire safety certificate', category: 'fire', shopCode: 'S2', expiryDate: addDays(today, 100) });
  L.addEvent(owner, lic, { kind: 'note', date: today, note: 'inspected' });
  db().run("INSERT INTO documents (uid, ref_type, ref_uid, kind, name, status, updated_at) VALUES ('DOC-1', 'licence', ?, 'copy', 'fire.pdf', 'active', ?)", [lic, stamp()]);
  const plan = BIN.deletePlan('licences', lic);
  assert.ok(plan.alsoGoes.some((x) => /history/.test(x)) && plan.alsoGoes.some((x) => /document/.test(x)), plan.alsoGoes.join());
  const r = BIN.deleteRecord(owner, 'licences', lic);
  assert.ok(!db().get("SELECT 1 AS x FROM documents WHERE uid = 'DOC-1'"));
  BIN.restoreRecord(owner, r.uid);
  assert.ok(db().get("SELECT 1 AS x FROM documents WHERE uid = 'DOC-1'") && L.eventsFor(lic).length >= 1);
});

test('bin: a removed device is listed for 90 days but must be linked again', () => {
  const id = BIN.binDevice(owner, { id: 'DEV-9', name: 'Old Samsung tablet' });
  const b = BIN.listBin().find((x) => x.uid === id);
  assert.ok(b && /Old Samsung/.test(b.title));
  throws(() => BIN.restoreRecord(owner, id), /new invite/);
  assert.ok(BIN.purgeBin({ today: addDays(today, 91) }) >= 1);
  assert.strictEqual(BIN.getBinEntry(id).status, 'gone');
});

test('bin: rubbish in the bin never crashes start-up or sync', () => {
  db().run("INSERT INTO bin_records (uid, tbl, rkey, title, keys, parts, deleted_at, purge_after, status, updated_at) VALUES ('BIN-bad', 'po_orders', 'x', 'bad', '{not json', 2, ?, ?, 'binned', ?)", [stamp(), addDays(today, 5), stamp()]);
  BIN.rebuildBinIndex();
  assert.ok(Array.isArray(BIN.listBin()));
  throws(() => BIN.restoreRecord(owner, 'BIN-bad'), /on its way/);
  BIN.binArrived({ uid: 'BIN-x', status: 'binned', keys: JSON.stringify([{ t: 'no_such_table', k: '1' }, { t: 'audit_log', k: '1' }, null]) });
  BIN.binArrived(null);
  applyPulledRecords([{ t: 'bin_records', k: 'BIN-y', u: stamp(), row: { uid: 'BIN-y', status: 'restored', keys: '[[[', deleted_at: stamp(), purge_after: today, tbl: 'x', rkey: 'y', updated_at: stamp() } }]);
  assert.strictEqual(BIN.purgeBin({ today: addDays(today, 400) }) >= 1, true);
});

test('bin: working out a delete stays quick on a big database (a year of records)', () => {
  const now = stamp();
  db().transaction(() => {
    for (let k = 0; k < 20000; k++) db().run("INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, ref_type, ref_uid, status, created_at, updated_at) VALUES (?, ?, 'S1', ?, 'sale', -1, 'sale', ?, 'active', ?, ?)", [`MV-big-${k}`, flour, today, `SALE-${k}`, now, now]);
    for (let k = 0; k < 5000; k++) db().run("INSERT INTO ap_invoices (uid, kind, supplier_uid, supplier_name, invoice_no, invoice_date, due_date, total, vat, status, updated_at) VALUES (?, 'invoice', ?, 'Punjas & Sons', ?, ?, ?, 10, 0, 'approved', ?)", [`INV-big-${k}`, sid, `B-${k}`, today, today, now]);
    for (let k = 0; k < 5000; k++) db().run("INSERT INTO audit_log (uid, at, action, table_name, record_uid, before, after, updated_at) VALUES (?, ?, 'x', 'ap_invoices', ?, ?, ?, ?)", [`AU-big-${k}`, now, `INV-big-${k}`, '{"a":1}', '{"b":2}', now]);
  });
  const t0 = Date.now();
  const plan = BIN.deletePlan('ap_invoices', 'INV-big-2500');
  const ms = Date.now() - t0;
  assert.strictEqual(plan.blocks.length, 0);
  assert.ok(ms < 3000, `${ms} ms`);
  const t1 = Date.now();
  BIN.deleteRecord(owner, 'ap_invoices', 'INV-big-2500');
  assert.ok(Date.now() - t1 < 4000, `${Date.now() - t1} ms`);
  console.log(`     (worked out in ${ms} ms)`);
});

test('new to verify: told once to the person who verifies, never their own, only their shop, can be switched off', () => {
  const dep = (uid, shop, byUid, total) => db().run("INSERT INTO deposits (uid, shop_code, deposit_date, total, deposited_by_uid, deposited_by_name, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'X', 'active', ?, ?)", [uid, shop, today, total, byUid, stamp(), stamp()]);
  db().run("DELETE FROM settings WHERE key IN ('verify_notify_uid', 'verify_seen_keys', 'verify_notify_off')");
  assert.strictEqual(VW.newToVerify().items.length, 0, 'nobody to tell yet');
  VW.noteVerifier(staff);
  assert.strictEqual(VW.newToVerify().items.length, 0, 'shop staff do not verify');
  VW.noteVerifier(owner);
  dep('DEP-old', 'S1', staff.uid, 100);
  assert.strictEqual(VW.newToVerify().items.length, 0, 'the first check only notes what is there');
  dep('DEP-1', 'S1', staff.uid, 250.5);
  dep('DEP-own', 'S1', owner.uid, 80);
  const r = VW.newToVerify();
  assert.deepStrictEqual(r.items.map((x) => x.key), ['deposits:DEP-1'], JSON.stringify(r.items.map((x) => x.key)));
  const msg = VW.verifyMessage(r.items);
  assert.ok(/New to verify/.test(msg.title) && /Bank deposit \$250\.50/.test(msg.body), JSON.stringify(msg));
  assert.strictEqual(VW.newToVerify().items.length, 0, 'told once');
  // a manager of Shop 1 is not told about Shop 2
  db().run("UPDATE users SET shop_code = 'S1' WHERE uid = ?", [manager.uid]);
  VW.noteVerifier({ ...manager, shop_code: 'S1' });
  assert.strictEqual(require('../src/services/core.js').getSetting('verify_notify_uid'), manager.uid);
  dep('DEP-2', 'S2', staff.uid, 10); dep('DEP-3', 'S1', staff.uid, 20);
  { const k = VW.newToVerify().items.map((x) => x.key); assert.deepStrictEqual(k, ['deposits:DEP-3'], JSON.stringify(k)); }
  // many at once: one short message
  VW.noteVerifier(owner);
  for (let k = 0; k < 12; k++) dep(`DEP-m${k}`, 'S1', staff.uid, k);
  const many = VW.newToVerify();
  assert.ok(many.items.length >= 12);
  assert.ok(/and \d+ more/.test(VW.verifyMessage(many.items).body));
  // switched off on this device
  VW.setVerifyNotify(false);
  dep('DEP-off', 'S1', staff.uid, 5);
  assert.strictEqual(VW.newToVerify().items.length, 0);
  VW.setVerifyNotify(true);
  // a broken list of seen items never stops it
  require('../src/services/core.js').setSetting('verify_seen_keys', '{broken');
  assert.ok(Array.isArray(VW.newToVerify().items));
  require('../src/services/core.js').setSetting('verify_seen_keys', '{"a":1}');
  assert.ok(Array.isArray(VW.newToVerify().items));
  assert.strictEqual(VW.verifyMessage([]), null);
});

done();
