// 3.9.7 Fresh start from the go-live date: nothing before it warns; open items wait in "Before go-live" for the owner.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock, dateStr } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as G from '../src/services/goLive.js';
import * as AP from '../src/modules/payables/service.js';
import * as E from '../src/modules/till/eod.js';
import * as T from '../src/modules/till/service.js';
import * as V from '../src/modules/verify/service.js';
import * as SP from '../src/services/shopProfile.js';
import * as I from '../src/modules/inventory/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-11-05T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Ana Admin', pin: '86420', role: 'admin' });
const manager = saveUser({ name: 'Mona Manager', pin: '6284', role: 'manager', shop_code: 'S1' });
const staff = saveUser({ name: 'Sam Staff', pin: '5173', role: 'staff', shop_code: 'S1' });
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const oldInv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'OLD1', invoiceDate: '2026-10-10', dueDate: '2026-10-20', total: 112.5, shopCode: 'S1' });
const newInv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'NEW1', invoiceDate: '2026-11-02', dueDate: '2026-11-03', total: 50, shopCode: 'S1' });
const oldEod = E.addEod(owner, { shopCode: 'S1', date: '2026-10-15', zNumber: '50', total: 900 });
const newEod = E.addEod(owner, { shopCode: 'S1', date: '2026-11-03', zNumber: '70', total: 800 });

test('no fresh start date: everything shows as before', () => {
  assert.strictEqual(G.freshFrom(), null);
  assert.strictEqual(G.isOld('2020-01-01'), false);
  assert.strictEqual(AP.apAlerts().overdue.n, 2);
  assert.strictEqual(E.eodProblems().noTill.length, 2);
  assert.deepStrictEqual(G.beforeGoLive(), []);
});

test('only the owner or admin sets the date, and it must be a real date', () => {
  throws(() => G.setFreshFrom(staff, '2026-11-01'), /Only the owner or admin/);
  throws(() => G.setFreshFrom(manager, '2026-11-01'), /Only the owner or admin/);
  throws(() => G.setFreshFrom(owner, '1 Nov'), /YYYY-MM-DD/);
  assert.strictEqual(G.setFreshFrom(admin, '2026-11-01'), '2026-11-01');
  assert.strictEqual(G.freshFrom(), '2026-11-01');
});

test('Aronium End of days before go-live are history: no warning, not in To verify, not on the till warnings', () => {
  const p = E.eodProblems();
  assert.deepStrictEqual(p.noTill.map((e) => e.uid), [newEod.uid]);
  assert.strictEqual(E.eodProblems({ history: true }).noTill.length, 2, 'still kept in the history');
  const t = T.tillAlerts();
  assert.deepStrictEqual(t.eodNoTill.map((e) => e.uid), [newEod.uid]);
  const q = V.queue({ from: '2026-09-01' });
  assert.ok(!q.some((x) => x.key === `aronium_eods:${oldEod.uid}`), 'old End of day not in To verify');
  assert.ok(q.some((x) => x.key === `aronium_eods:${newEod.uid}`), 'new End of day still in To verify');
  assert.ok(!G.beforeGoLive().some((x) => x.key === `aronium_eods:${oldEod.uid}`), 'nothing to review for till history');
});

test('an unpaid invoice from before go-live waits for the owner, then works normally once seen', () => {
  assert.strictEqual(AP.apAlerts().overdue.n, 1, 'only the new one warns');
  const r = G.beforeGoLive();
  const it = r.find((x) => x.key === `ap_invoices:${oldInv.uid}`);
  assert.ok(it, 'old invoice is on the review list');
  assert.strictEqual(it.mark, null);
  assert.strictEqual(G.beforeGoLiveSummary().open >= 1, true);
  throws(() => G.markReview(manager, [it.key], 'seen'), /Only the owner or admin/);
  G.markReview(owner, [it.key], 'seen');
  assert.strictEqual(AP.apAlerts().overdue.n, 2, 'seen: it warns like any other');
  G.markReview(owner, [it.key], 'aside');
  assert.strictEqual(AP.apAlerts().overdue.n, 1, 'put aside: no warning');
  assert.ok(AP.listInvoices({ filter: 'unpaid' }).some((i) => i.uid === oldInv.uid), 'never deleted');
  G.markReview(owner, [it.key], null);
  assert.strictEqual(G.beforeGoLive().find((x) => x.key === it.key).mark, null, 'back on the list');
  void newInv;
});

test('changing the date moves the line; a bad mark is refused', () => {
  G.setFreshFrom(owner, '2026-10-01');
  assert.strictEqual(AP.apAlerts().overdue.n, 2);
  assert.strictEqual(E.eodProblems().noTill.length, 2);
  G.setFreshFrom(owner, '2026-11-01');
  throws(() => G.markReview(owner, ['x'], 'maybe'), /Seen or Put aside/);
  assert.strictEqual(dateStr(), '2026-11-05');
});

test('shop page: Coming up lists the overdue bill; This month so far compares with last month; staff cannot open it', () => {
  const D = SP.shopDashboard('S1', owner);
  const it = D.upcoming.find((x) => x.key === `inv-${newInv.uid}`);
  assert.ok(it, 'the unpaid November invoice is coming up');
  assert.strictEqual(it.tone, 'danger', 'due 3 Nov, today 5 Nov: overdue');
  assert.strictEqual(it.amount, 50);
  const costs = D.standings.find((x) => x.key === 'costs');
  assert.strictEqual(costs.now, 50, 'November so far');
  assert.strictEqual(costs.last, 0, 'same days of October (1–5 Oct): the 10 Oct invoice is outside');
  assert.deepStrictEqual(D.lastMonth, { from: '2026-10-01', to: '2026-10-05' });
  throws(() => SP.shopDashboard('S1', staff), /access/);
  const cashier = saveUser({ name: 'Cathy Cashier', pin: '4826', role: 'staff', shopCode: 'S1' });
  const B = SP.shopBelongings('S1', owner);
  assert.ok(Array.isArray(B.tills) && Array.isArray(B.staff) && Array.isArray(B.wallets));
  assert.ok(B.staff.some((u) => u.uid === cashier.uid), 'staff of the shop are on the shop page');
});

test('a product with no tax set in Aronium is flagged (not taken as zero rated) and clears once set', () => {
  const head = 'Code,Name,Barcode,Group,Unit,Cost,Price,Active,Is service,Tax';
  I.importProductsCsv(owner, `${head}\nNT1,Tin Fish 425g,,Grocery,each,3.10,4.50,yes,no,None set\nZR1,Rice 10kg,,Grocery,each,20,24,yes,no,0%\nST1,Coke 1.5L,,Drinks,each,2.5,4,yes,no,VAT 12.5%`, { shopCode: 'S1', setShopPrice: true });
  const none = I.noTaxInAronium().map((x) => x.code);
  assert.deepStrictEqual(none, ['NT1'], 'only the product with no tax');
  const tin = I.vatMismatches().find((x) => x.code === 'NT1');
  assert.strictEqual(tin.vat_type, 'standard', 'the app keeps standard VAT, not zero');
  assert.ok(!I.vatMismatches().some((x) => x.code === 'ZR1' || x.code === 'ST1'), '0% and 12.5% agree');
  throws(() => I.useAroniumVat(owner, tin.uid), /no tax set in Aronium/);
  I.importProductsCsv(owner, `${head}\nNT1,Tin Fish 425g,,Grocery,each,3.10,4.50,yes,no,VAT 12.5%`, { shopCode: 'S1', setShopPrice: true });
  assert.deepStrictEqual(I.noTaxInAronium(), [], 'set in Aronium: the flag goes');
});

done();
