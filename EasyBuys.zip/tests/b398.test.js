// 3.9.8 payroll: hours paid different from hours worked (with a reason), FNPF counted on set hours, family members'
// fixed pay split into wages and owner's drawings, and the finer details only for the owner / admin once final.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { checkWeek } from '../src/modules/timesheets/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as SP from '../src/services/shopProfile.js';
import * as UB from '../src/services/utilityBills.js';
import { readPaperText } from '../src/services/paperRead.js';
import { getSetting } from '../src/services/core.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as T from '../src/modules/till/service.js';
import * as W from '../src/modules/bank/wallets.js';
import * as V from '../src/modules/verify/service.js';
import * as R from '../src/modules/payables/recurring.js';
import * as LN from '../src/modules/loans/service.js';
import * as ACC from '../src/modules/accounting/service.js';
import { lockDate } from '../src/services/lock.js';
import * as PW from '../src/services/productWatch.js';
import * as LPG from '../src/modules/inventory/lpg.js';
import * as FC from '../src/modules/inventory/fccc.js';
import { setSetting } from '../src/services/core.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-11-14T20:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Asha Admin', pin: '7777', role: 'admin' }, owner);
const pay = saveUser({ name: 'Pita Payroll', pin: '6666', role: 'payroll' }, owner);
const mgr = saveUser({ name: 'Mani Manager', pin: '8181', role: 'manager', shopCode: 'S1' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const fam = saveUser({ name: 'Ravi Prasad', pin: '4325', role: 'staff', shopCode: 'S1' }, owner);
const work = (u, d, from = '08:00', to = '16:00') => { addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d} ${from}:00`, reason: 't' }); addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${d} ${to}:00`, reason: 't' }); };
P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 6, tin: '123456789', fnpfNo: 'F1', taxStatus: 'resident', payMethod: 'cash' });
P.saveProfile(owner, { userUid: fam.uid, payType: 'salary', weeklySalary: 400, tin: '223456789', fnpfNo: 'F2', taxStatus: 'resident', payMethod: 'cash' });
['2026-11-07', '2026-11-09', '2026-11-10'].forEach((d) => work(mere, d));
['2026-11-07', '2026-11-09'].forEach((d) => checkWeek(owner, mere.uid, d, 'ok'));

let run;
test('worked hours are kept; paid hours can differ, only with a reason, by payroll / owner / admin', () => {
  run = P.createRun(pay, '2026-11-09');
  const l = run.lines.find((x) => x.user_uid === mere.uid);
  assert.strictEqual(l.counted.worked.normal, 24);
  assert.strictEqual(l.counted.paidChanged, false);
  throws(() => P.editLine(mgr, l.uid, { normal: 26, reason: 'covering' }), /payroll manager, owner or admin/);
  throws(() => P.editLine(owner, l.uid, { normal: 26, reason: '' }), /why|reason/i);
  const e = P.editLine(pay, l.uid, { normal: 26, reason: 'Covering 2 hours missed last week' });
  assert.strictEqual(e.hours.normal, 26);
  assert.strictEqual(e.counted.worked.normal, 24, 'worked hours stay as worked');
  assert.strictEqual(e.counted.paidChanged, true);
  assert.strictEqual(e.earnings.normal, 156);
  assert.ok(e.warnings.some((w) => /worked 24 h, paid 26 h/.test(w)));
});

test('FNPF counted on set hours a week (standing rule) – all hours still paid; a one-week change too', () => {
  throws(() => P.saveStatRule(owner, mere.uid, 'paye', { mode: 'hours', hours: 20 }), /FNPF only/);
  throws(() => P.saveStatRule(owner, mere.uid, 'fnpf', { mode: 'hours', hours: 0 }), /hours a week/);
  throws(() => P.saveStatRule(pay, mere.uid, 'fnpf', { mode: 'hours', hours: 20 }), /owner or admin/);
  P.saveStatRule(admin, mere.uid, 'fnpf', { mode: 'hours', hours: 20 });
  P.recalcRun(pay, run.uid);
  let l = P.getRun(run.uid).lines.find((x) => x.user_uid === mere.uid);
  assert.strictEqual(l.gross, 156, 'paid in full');
  assert.strictEqual(l.fnpf_base, 120, 'FNPF on 20 h × $6');
  assert.strictEqual(l.counted.fnpfHours, 20);
  assert.ok(/20 hours/.test(l.counted.fnpf.words));
  l = P.editLine(pay, l.uid, { fnpfHours: 10, reason: 'This week FNPF on 10 h only' });
  assert.strictEqual(l.fnpf_base, 60);
  assert.ok(/this period only/.test(l.counted.fnpf.words));
});

test('family member: fixed pay a week, admin sets the wages part (FNPF / PAYE), the rest is owner\'s drawings', () => {
  throws(() => P.saveFamilySplit(pay, fam.uid, { weekly: 400, wages: 150 }), /owner or admin/);
  throws(() => P.saveFamilySplit(admin, fam.uid, { weekly: 400, wages: 500 }), /between/);
  P.saveFamilySplit(admin, fam.uid, { weekly: 400, wages: 150, note: 'Agreed with accountant' });
  P.recalcRun(pay, run.uid);
  const l = P.getRun(run.uid).lines.find((x) => x.user_uid === fam.uid);
  assert.strictEqual(l.gross, 150, 'only the wages part is pay');
  assert.strictEqual(l.fnpf_base, 150);
  assert.strictEqual(l.fnpf_employee, 12);
  assert.deepStrictEqual(l.counted.family, { total: 400, wages: 150, drawings: 250 });
  P.finaliseRun(pay, run.uid);
  const m = db().all("SELECT * FROM owner_moves WHERE invoice_no = ? AND status = 'active'", [`PAY-${run.uid}`]);
  assert.strictEqual(m.length, 1);
  assert.strictEqual(m[0].amount, 250);
  assert.strictEqual(m[0].kind, 'take_out');
});

test('once final: finer details only for the owner / admin; reopening undoes the drawings', () => {
  const r = P.getRun(run.uid);
  assert.strictEqual(P.seesPayDetails(owner, r), true);
  assert.strictEqual(P.seesPayDetails(admin, r), true);
  assert.strictEqual(P.seesPayDetails(pay, r), false, 'payroll manager sees only the clean payslip once final');
  assert.strictEqual(P.seesPayDetails(mgr, r), false);
  P.reopenRun(admin, run.uid, 'Fix a rate');
  assert.strictEqual(P.seesPayDetails(pay, P.getRun(run.uid)), true, 'draft again: the payroll manager works on it');
  assert.strictEqual(db().all("SELECT * FROM owner_moves WHERE invoice_no = ? AND status = 'active'", [`PAY-${run.uid}`]).length, 0);
  P.finaliseRun(pay, run.uid);
  assert.strictEqual(db().all("SELECT * FROM owner_moves WHERE invoice_no = ? AND status = 'active'", [`PAY-${run.uid}`]).length, 1, 'booked once again, not twice');
  throws(() => P.editLine(owner, run.lines[0].uid, { normal: 1, reason: 'x' }), /final/);
});

// ---------------------------------------------------------------- power and water bills
const WAF_PAGE = `<html><body><form id="water-bill-form"></form><div class="water-bill-data"><p><b>Bula Vinaka,</b></p><p class="data-p" >Your bill total is <b>$50.26 </b> for Account Number <b>200000013616</b>.<br> This is due on <b>09-11-2026</b>.</p></div></body></html>`;
test('WAF answer and EFL screenshot text are read right', () => {
  assert.deepStrictEqual(UB.parseWafHtml(WAF_PAGE), { total: 50.26, account: '200000013616', due: '2026-11-09' });
  assert.strictEqual(UB.parseWafHtml('<html>no bill here</html>'), null);
  const efl = 'EFL Account Number: 7500093848\nTotal Amount Due: $0.00\nOverdue Amount: $0.00\nBill Due on: 19/10/2026';
  assert.deepStrictEqual(UB.parseEflText(efl), { account: '7500093848', total: 0, overdue: 0, due: '2026-10-19' });
  assert.deepStrictEqual(UB.parseEflText('Total Amount Due: $1 42.16\nOverdue Amount: $ 12.00\nBill Due on: 3/12/2026'), { account: null, total: 142.16, overdue: 12, due: '2026-12-03' });
  const r = readPaperText('efl_bill', efl);
  assert.strictEqual(r.fields.accountNo, '7500093848');
  assert.strictEqual(r.fields.due, '2026-10-19');
});

let water; let power;
test('a new bill goes into Invoices for the shop (to check); the same bill again is not doubled; $0 = paid', async () => {
  water = { uid: SP.saveAccount(owner, { shopCode: 'S1', kind: 'water', label: 'WAF – shop', accountNo: '200000013616' }) };
  power = { uid: SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', label: 'EFL – shop', accountNo: '7500093848' }) };
  const fake = async () => ({ text: async () => WAF_PAGE });
  const r1 = await UB.checkWaterBills({ fetchFn: fake, today: '2026-11-03', force: true });
  assert.strictEqual(r1.checked, 1);
  assert.strictEqual(r1.results[0].result, 'new_bill');
  assert.strictEqual(r1.results[0].invoiceUid, null, 'no bill until someone acknowledges it');
  assert.strictEqual(UB.billBoard('2026-11-03').find((b) => b.kind === 'water').state, 'to_confirm');
  assert.ok(UB.billAlerts(owner, '2026-11-03').some((x) => /acknowledge to make the bill/.test(x.text)));
  throws(() => UB.acknowledgeBill(mere, UB.waitingBills()[0].uid), /owner, admin or the person who pays/);
  const made = UB.acknowledgeBill(admin, UB.waitingBills()[0].uid);
  const inv = db().get('SELECT * FROM ap_invoices WHERE uid = ?', [made.uid]);
  assert.strictEqual(inv.total, 50.26);
  assert.strictEqual(inv.shop_code, 'S1');
  assert.strictEqual(inv.due_date, '2026-11-09');
  assert.strictEqual(inv.status, 'to_check', 'VAT checked against the bill by a person');
  assert.ok(/Water Authority of Fiji/.test(inv.supplier_name));
  const r2 = await UB.checkWaterBills({ fetchFn: fake, today: '2026-11-04', force: true });
  assert.strictEqual(r2.results[0].result, 'same');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_invoices WHERE invoice_no LIKE 'WAF-%'").n, 1);
  const r3 = await UB.checkWaterBills({ fetchFn: async () => ({ text: async () => '<html>error</html>' }), today: '2026-11-05', force: true });
  assert.strictEqual(r3.checked, 0);
  assert.ok(/WAF did not show a bill/.test(getSetting('waf_check_problem', '')));
  const p = UB.recordCheck(admin, power.uid, { total: 0, overdue: 0, due: '19/10/2026', source: 'efl_screenshot' });
  assert.strictEqual(p.result, 'paid');
});

test('Home: overdue / due soon bills and the monthly EFL check; staff see nothing', () => {
  const a = UB.billAlerts(owner, '2026-11-08');
  assert.ok(a.some((x) => /due in the next 3 days/.test(x.text)), 'water due 9 Nov');
  assert.ok(a.some((x) => /water bill check isn.t working/i.test(x.text)));
  const late = UB.billAlerts(owner, '2026-11-12');
  assert.ok(late.some((x) => /overdue/.test(x.text) && x.level === 'urgent'));
  assert.ok(UB.billAlerts(owner, '2026-12-20').some((x) => /Check the EFL bill/.test(x.text)), 'EFL not checked for 30 days');
  assert.deepStrictEqual(UB.billAlerts(mere, '2026-11-12'), []);
  throws(() => UB.recordCheck(owner, power.uid, { total: -1 }), /total amount due/);
  throws(() => UB.recordCheck(owner, power.uid, { total: 5, due: 'next week' }), /due date/);
});

// ---------------------------------------------------------------- deliveries and bills without a purchase order
const PHOTO = ['file:///inv1.jpg'];
test('no order, paid in cash from a till: the payment is recorded, cash must say where it came from, the till counter sees it', () => {
  I.importProductsCsv(owner, 'Code,Name,Barcode,Group,Unit,Cost,Price,Active,Is service,Tax\nRB1,Rewa Butter 500g,,Dairy,each,8,11,yes,no,VAT 12.5%', { shopCode: 'S1', setShopPrice: true });
  const it = I.findItem('RB1');
  const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 });
  const sup = AP.saveSupplier(owner, { name: 'Rewa Dairy' });
  const base = { supplierUid: sup.uid, shopCode: 'S1', date: '2026-11-03', extra: [{ itemUid: it.uid, qty: 10, unitCost: 8 }], photos: PHOTO, invoice: { invoiceNo: 'RD-55', total: 90, photos: PHOTO }, acceptReason: 'ok' };
  throws(() => I.receiveDelivery(owner, { ...base, buyType: 'supplier_came', paidNow: { method: 'cash' } }), /where the cash came from/);
  const r = I.receiveDelivery(owner, { ...base, invoice: { ...base.invoice, invoiceNo: 'RD-56' }, buyType: 'supplier_came', paidNow: { method: 'cash', cashFrom: `till:${till}` } });
  const inv = AP.getInvoice(r.invoice.uid);
  assert.strictEqual(inv.owing, 0, 'paid – it will not be paid twice');
  const pay = db().get('SELECT * FROM ap_payments WHERE supplier_uid = ?', [sup.uid]);
  assert.strictEqual(pay.cash_from, `till:${till}`);
  assert.strictEqual(db().get('SELECT buy_type FROM inv_receipts WHERE uid = ?', [r.uid]).buy_type, 'supplier_came');
  assert.strictEqual(T.cashOnHand('S1', '2026-11-03').supplierCash, 0, 'from a till: not taken from the safe as well');
  const outs = AP.tillPaidOuts(till, '2026-11-03');
  assert.strictEqual(outs.length, 1);
  assert.strictEqual(outs[0].amount, 90);
  const q = V.queue({ from: '2026-11-01', to: '2026-11-05' }).find((x) => x.key === `inv_receipts:${r.uid}`);
  assert.ok(/No order/.test(q.type));
  assert.ok(/paid in cash from Till 1/.test(q.text), q.text);
});

test('cash buy from the safe; M-PAiSA from the shop\'s own wallet (needs a reference); a bill with the total only', () => {
  W.ensureDefaultWallets();
  const wal = W.listWallets().find((w) => w.shop_code === 'S1');
  const sup = AP.saveSupplier(owner, { name: 'Lautoka Market' });
  const it = I.findItem('RB1');
  const base = { supplierUid: sup.uid, shopCode: 'S1', date: '2026-11-04', extra: [{ itemUid: it.uid, qty: 2, unitCost: 8 }], photos: PHOTO, acceptReason: 'ok' };
  const a = I.receiveDelivery(owner, { ...base, invoice: { invoiceNo: 'LM-1', total: 18, photos: PHOTO }, buyType: 'cash_buy', paidNow: { method: 'cash', cashFrom: 'safe' } });
  assert.strictEqual(db().get('SELECT buy_type FROM inv_receipts WHERE uid = ?', [a.uid]).buy_type, 'cash_buy');
  assert.strictEqual(T.cashOnHand('S1', '2026-11-04').supplierCash, 18, 'from the safe: cash at the shop goes down');
  throws(() => I.receiveDelivery(owner, { ...base, invoice: { invoiceNo: 'LM-2', total: 18, photos: PHOTO }, paidNow: { method: 'mpaisa', walletUid: wal.uid } }), /reference/);
  I.receiveDelivery(owner, { ...base, invoice: { invoiceNo: 'LM-3', total: 18, photos: PHOTO }, paidNow: { method: 'mpaisa', walletUid: wal.uid, reference: 'MP123' } });
  const wm = db().get("SELECT * FROM wallet_moves WHERE wallet_uid = ? AND type = 'payment'", [wal.uid]);
  assert.strictEqual(wm.amount, 18);
  const snap = V.snap(owner, { kind: 'invoice', shopCode: 'S1', amount: 35, supplierUid: sup.uid, refNo: 'LM-9', photos: PHOTO, category: 'Stock for resale', paid: { method: 'cash', shopCode: 'S1', cashFrom: 'safe' } });
  const inv = AP.getInvoice(snap.linkUid);
  assert.strictEqual(inv.category, 'Stock for resale');
  assert.strictEqual(inv.owing, 0);
});

// ---------------------------------------------------------------- orders: approval per shop, sent once, supplier's products
test('a manager approves their own shop only (unless given more); a staff order waits; an order goes out once', () => {
  const sup = AP.saveSupplier(owner, { name: 'Punjas' });
  const it = I.findItem('RB1');
  const mgr2 = saveUser({ name: 'Mala Manager', pin: '8282', role: 'manager', shopCode: 'S2' }, owner);
  assert.strictEqual(I.mayApprovePO(mgr, 'S1'), true);
  assert.strictEqual(I.mayApprovePO(mgr, 'S2'), false);
  assert.strictEqual(I.mayApprovePO(admin, 'S2'), true);
  let po = I.savePO(mgr2, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: it.uid, qty: 5 }] });
  po = I.submitPO(mgr2, po.uid, { canApprove: true });
  assert.strictEqual(po.status, 'awaiting', 'a manager of another shop cannot approve it – it waits');
  throws(() => I.submitPO(mgr2, po.uid, { canApprove: true }), /manager for S1/);
  throws(() => I.setApproverShops(mgr, mgr2.uid, ['S1']), /owner or admin/);
  I.setApproverShops(owner, mgr2.uid, ['S1']);
  assert.strictEqual(I.mayApprovePO(mgr2, 'S1'), true);
  po = I.submitPO(mgr2, po.uid, { canApprove: true });
  assert.strictEqual(po.status, 'approved');
  I.markSent(mgr2, po.uid, 'viber');
  throws(() => I.markSent(mgr2, po.uid, 'pdf'), /already sent/);
});

test('a supplier\'s products: linked by deliveries; products with no supplier listed; suggestions only for that supplier', () => {
  const rewa = db().get("SELECT uid FROM ap_suppliers WHERE name = 'Rewa Dairy'").uid;
  const sp = I.supplierProducts(rewa, { shopCode: 'S1' });
  assert.ok(sp.some((p) => p.code === 'RB1'), 'butter linked to Rewa by the delivery');
  assert.strictEqual(sp.find((p) => p.code === 'RB1').lastCost, 8);
  I.importProductsCsv(owner, 'Code,Name,Barcode,Group,Unit,Cost,Price,Active,Is service,Tax\nNS1,Loose Chillies,,Produce,kg,3,5,yes,no,0%', { shopCode: 'S1', setShopPrice: true });
  assert.ok(I.productsWithoutSupplier().some((p) => p.code === 'NS1'));
  I.addItemSupplier(owner, I.findItem('NS1').uid, rewa, {});
  assert.ok(!I.productsWithoutSupplier().some((p) => p.code === 'NS1'));
  assert.ok(I.suggestFor('S1', rewa).every((r) => [I.findItem('RB1').uid, I.findItem('NS1').uid].includes(r.itemUid)));
});

test('loans & rent: the admin makes the bill now (date / amount can differ), never twice', () => {
  const bsp = AP.saveSupplier(owner, { name: 'BSP Bank' });
  const rUid = R.saveRecurring(owner, { kind: 'loan', name: 'Shop 1 business loan', supplierUid: bsp.uid, amount: 1200, frequency: 'monthly', nextDate: '2026-11-28', openingBalance: 50000, openingDate: '2026-11-01' });
  const uid = typeof rUid === 'string' ? rUid : rUid.uid;
  throws(() => R.makeRegularBillNow(mere, uid, {}), /Only the owner, admin/);
  const inv = R.makeRegularBillNow(admin, uid, { amount: 1250, note: 'Bank letter: new amount' });
  assert.strictEqual(inv.total, 1250);
  assert.strictEqual(inv.due_date, '2026-11-28');
  throws(() => R.makeRegularBillNow(admin, uid, { date: '2026-11-28' }), /already made/);
  assert.strictEqual(R.getRecurring(uid).next_date, '2026-12-28', 'the automatic bills carry on after it');
  loanUid = uid;
  AP.makePayment(admin, { supplierUid: bsp.uid, method: 'cash', shopCode: 'S1', payDate: '2026-11-28', allocations: [{ invoiceUid: inv.uid, amount: 1250 }] });
});

let loanUid;
const STMT = `BSP Loan Statement
Opening balance 50,000.00
28/11/2026 Loan repayment 1,250.00 48,750.00
30/11/2026 Interest charged 312.50 49,062.50
30/11/2026 Account fee 5.00 49,067.50
Interest rate 7.5% p.a.
Closing balance 49,067.50`;
test('loan statement: read from text, matched with the app, missing lines added only when ticked, balance agrees', () => {
  const p = LN.parseLoanStatement(STMT);
  assert.deepStrictEqual(p.lines.map((l) => [l.date, l.kind, l.amount]), [['2026-11-28', 'repayment', 1250], ['2026-11-30', 'interest', 312.5], ['2026-11-30', 'fee', 5]]);
  assert.strictEqual(p.closing, 49067.5);
  assert.strictEqual(p.rate, 7.5);
  const st = LN.saveStatement(admin, loanUid, { periodFrom: '2026-11-01', periodTo: '2026-11-30', closingBalance: p.closing, rate: p.rate, lines: p.lines, source: 'upload' });
  const m = LN.matchStatement(st.uid);
  assert.deepStrictEqual(m.lines.map((l) => l.state), ['matched', 'add', 'add']);
  assert.deepStrictEqual(m.rateChange, { from: 0, to: 7.5 });
  const r = LN.applyStatement(admin, st.uid, ['L1', 'L2', 'rate']);
  assert.strictEqual(r.done.length, 3);
  assert.strictEqual(r.check.status, 'agreed', `balance agrees (diff ${r.check.diff})`);
  assert.strictEqual(R.getRecurring(loanUid).interest_rate, 7.5);
  throws(() => LN.applyStatement(admin, st.uid, ['L1']), /already used/);
  const typed = LN.saveStatement(admin, loanUid, { periodTo: '2026-12-05', lines: [{ date: '2026-12-02', text: 'Extra deposit', kind: 'deposit', amount: 500 }] });
  assert.deepStrictEqual(LN.matchStatement(typed.uid).lines.map((l) => l.state), ['add']);
  LN.applyStatement(admin, typed.uid, ['L0']);
  assert.ok(db().get("SELECT 1 AS x FROM loan_entries WHERE recurring_uid = ? AND type = 'adjust_down' AND amount = 500", [loanUid]), 'deposit takes the balance down');
});

// ---------------------------------------------------------------- Aronium product watch
test('product watch: first list remembered only; then price, tax, name, new, disabled and removed are kept; what to fix', () => {
  const base = [{ code: 'A1', name: 'Rice 10kg', price: 24, cost: 20, vat_rate: 0, barcodes: ['111'] }, { code: 'A2', name: 'Coke 1.5L', price: 4, cost: 2.5, vat_rate: 12.5 }, { code: 'A3', name: 'Old Soap', price: 2, cost: 1, vat_rate: 12.5 }];
  assert.deepStrictEqual(PW.watchProducts('S1', base, '2026-11-02'), [], 'first list: nothing flooded');
  PW.watchProducts('S2', [{ code: 'A2', name: 'Coke 1.5L', price: 4.5, cost: 2.5, vat_rate: 12.5 }], '2026-11-02');
  const next = [{ code: 'A1', name: 'Rice 10kg Long Grain', price: 25.5, cost: 20, vat_rate: null, barcodes: ['111'] }, { code: 'A2', name: 'Coke 1.5L', price: 2, cost: 2.5, vat_rate: 12.5, enabled: false }, { code: 'A4', name: 'Tin Fish', price: 4.5, cost: 3.1, vat_rate: 12.5 }];
  const ch = PW.watchProducts('S1', next, '2026-11-03');
  const kinds = ch.map((c) => `${c.code}:${c.kind}`).sort();
  assert.deepStrictEqual(kinds, ['A1:name', 'A1:price', 'A1:tax', 'A2:off', 'A2:price', 'A3:removed', 'A4:new'].sort());
  assert.strictEqual(ch.find((c) => c.kind === 'tax').new, 'No tax set');
  assert.strictEqual(PW.listChanges({ from: '2026-11-03', to: '2026-11-03' }).length, 7);
  PW.watchProducts('S1', next.map((x) => (x.code === 'A2' ? { ...x, enabled: true } : x)), '2026-11-04');
  const p = PW.productProblems();
  assert.ok(p.belowCost.some((r) => r.code === 'A2' && r.shop === 'S1'), 'Coke at $2, cost $2.50');
  assert.ok(p.noTax.some((r) => r.code === 'A1'));
  assert.ok(p.shopsDiffer.some((x) => x.code === 'A2'));
  assert.ok(PW.watchAlerts(owner, '2026-11-04').some((a) => /below cost/.test(a.text)));
  assert.deepStrictEqual(PW.watchAlerts(mere, '2026-11-04'), []);
});

// ---------------------------------------------------------------- wrong payment button; M-PAiSA as a way to pay
test('cash pressed instead of M-PAiSA: the drawer is checked without it, the wallet counts it', () => {
  const w = T.workOut({ openingFloat: 100, zCash: 500, payouts: [], drops: 0, adjustments: [{ kind: 'tender_fix', to: 'M-PAiSA', amount: -40, reason: 'Rung up as cash, paid by M-PAiSA' }], cashCounted: 560 });
  assert.strictEqual(w.expected, 560);
  assert.strictEqual(w.overShort, 0, 'not short');
  const till = db().get("SELECT uid FROM tills WHERE shop_code = 'S1' LIMIT 1").uid;
  db().run(`INSERT INTO till_counts (uid, shop_code, till_uid, till_name, shift_date, shift, cashier_uid, cashier_name, counted_by_uid, counted_by_name, counted_at, opening_float, cash_counted, z_cash, tenders, adjustments, expected_cash, over_short, status, updated_at)
    VALUES ('TC-W1','S1',?,'Till 1','2026-11-05','Morning',?,?,?,?, '2026-11-05 12:00:00', 100, 560, 500, ?, ?, 560, 0, 'approved', '2026-11-05 12:00:00')`,
  [till, mere.uid, mere.name, owner.uid, owner.name, JSON.stringify([{ method: 'M-PAiSA', amount: 60 }]), JSON.stringify([{ amount: -40, reason: 'x', kind: 'tender_fix', to: 'M-PAiSA' }])]);
  const wal = W.listWallets().find((x) => x.shop_code === 'S1');
  const sale = W.walletSales(wal.uid, '2026-11-05', '2026-11-05').find((x) => x.countUid === 'TC-W1');
  assert.strictEqual(sale.amount, 100, '60 on the Z + 40 rung up as cash');
});

// ---------------------------------------------------------------- gas (LPG)
const GAS_HTML = '<a href="https://fccc.gov.fj/wp-content/uploads/2026/09/LPG-Oct.pdf">PDF LPG Authorization (Effective 01/10/2026) Oct</a><a href="https://fccc.gov.fj/wp-content/uploads/2026/08/LPG-Sep.pdf">PDF LPG Authorization (Effective 01/09/2026) Sep</a>';
const GAS_TEXT = ['Schedule 1', 'LPG Product Wholesale Price (VEP) Retail Price (VEP)', 'Per KG', '$3. 25 $3. 51', '4.5KG Cylinder', '$1 4.64 $ 15.81', '12 KG Cylinder', '$ 3 9.04 $ 42.16', '40 KG Cylinder', '$1 30.13 $1 40.54', '50 KG Cylinder', '$1 62.66 $1 75.68', 'Bulk – Ex Factory', 'Per KG', '$3. 25 NA', 'Per Litre $ 1. 86 $2. 24', 'Schedule 2', 'Per KG $3. 33 $ 3. 60', '4.5KG Cylinder $1 5.00 $1 6.20'];
test('gas: the FCCC page and authorisation are read (split digits joined); linked gas priced above / with VAT is flagged', async () => {
  const list = LPG.parseGasPage(GAS_HTML);
  assert.deepStrictEqual(list.map((x) => x.effective), ['2026-10-01', '2026-09-01']);
  const p = LPG.parseLpgText(GAS_TEXT);
  assert.deepStrictEqual(p.c12, { w: 39.04, r: 42.16 });
  assert.deepStrictEqual(p.c4_5, { w: 14.64, r: 15.81 });
  assert.deepStrictEqual(p.kg, { w: 3.25, r: 3.51 });
  assert.deepStrictEqual(p.auto, { w: 1.86, r: 2.24 });
  assert.strictEqual(p.c50.r, 175.68);
  const r = await LPG.checkLpg({ force: true, fetchText: async () => GAS_HTML, fetchBytes: async () => new Uint8Array([1]) });
  assert.ok(r.error || r.read === false || r.read === true, 'never throws');
  LPG.saveLpgPrices(owner, { effective: '2026-10-01', prices: p });
  I.importProductsCsv(owner, 'Code,Name,Barcode,Group,Unit,Cost,Price,Active,Is service,Tax\nG12,Gas 12kg Refill,,Gas,each,38,45,yes,no,VAT 12.5%', { shopCode: 'S1', setShopPrice: true });
  const g = I.findItem('G12');
  assert.ok(LPG.gasCandidates().some((x) => x.uid === g.uid && x.line === 'c12'));
  LPG.linkGasProduct(owner, g.uid, 'c12');
  const chk = LPG.gasCheck().find((x) => x.uid === g.uid);
  assert.strictEqual(chk.max, 42.16);
  assert.ok(chk.over.length, '$45 is above $42.16');
  assert.strictEqual(chk.vatWrong, true, 'cylinders are zero-rated');
  const a = LPG.lpgAlerts(owner, '2026-10-05');
  assert.ok(a.some((x) => /above the FCCC maximum/.test(x.text)));
  assert.ok(a.some((x) => /zero-rated/.test(x.text)));
  assert.strictEqual(LPG.maxFor('c40', { kg: { r: 3.51 } }), 140.4, 'a size not listed: in proportion to the per-kg price');
  const pg = LPG.parsePetroleumPage('<a href="https://fccc.gov.fj/wp-content/uploads/2026/09/LN-124.pdf">PDF Petroleum Prices (No. 9) Order 2026 LN 124/26</a><a href="x/LN-121.pdf">PDF Petroleum Prices (No. 8) Order 2026</a><a href="y.pdf">PDF Petroleum Prices (No. 12) Order 2025</a>');
  assert.deepStrictEqual(pg.map((x) => x.no), [9, 8, 12]);
  const f = LPG.parsePetroleumText(['(2) This Order comes into force on 1 October 2026.', 'SCHEDULE 1', '1. Motor spirit (unleaded) per litre $3.15 (VIP) 269.86c', '2. Gasoil (diesoline) per litre $3.41 (VIP) 293.37c', 'SCHEDULE 2', '1. Motor spirit (unleaded) per litre $3.20 (VIP)']);
  assert.deepStrictEqual(f, { effective: '2026-10-01', prices: { petrol: 3.15, diesel: 3.41 } });
});

// ---------------------------------------------------------------- FCCC full sweep
test('FCCC sweep: short forms, no size, price closeness; Yes links, No is never asked again', () => {
  const LIST = 'FCCC-SW-1';
  db().run("INSERT INTO fccc_lists (uid, list_name, as_at, url, found_at, updated_at, updated_device, sync_status) VALUES (?, 'Basic Food Items', '2026-10-09', 'https://fccc.gov.fj/x.pdf', '2026-10-09 10:00', '2026-10-09 10:00', 'x', 'synced')", [LIST]);
  const line = (key, desc, qty, retail) => db().run('INSERT INTO fccc_lines (list_uid, row_key, section, description, qty, w, r, page, sort) VALUES (?,?,?,?,?,?,?,?,?)', [LIST, key, 'Basic', desc, qty, JSON.stringify([null, null, null, null, null]), JSON.stringify([retail, retail, retail, retail, retail]), 1, 1]);
  line('sugar brown|2kg', 'Sugar Brown', '2kg', 4.98);
  line('flour plain|10kg', 'Flour Plain', '10kg', 22.5);
  setSetting(`fccc_read:${LIST}`, JSON.stringify({ lines: 2 }));
  I.importProductsCsv(owner, 'Code,Name,Barcode,Group,Unit,Cost,Price,Active,Is service,Tax\nSW1,Brwn Sug 2kg,,Grocery,each,4,4.9,yes,no,0%\nSW2,Plain Flour,,Grocery,each,20,23,yes,no,0%\nSW3,Hair Gel,,Beauty,each,3,6,yes,no,VAT 12.5%', { shopCode: 'S1', setShopPrice: true });
  FC.startSweep(owner);
  const r = FC.sweepRound();
  const su = r.left.find((x) => x.item.code === 'SW1');
  const fl = r.left.find((x) => x.item.code === 'SW2');
  assert.ok(su && su.grade === 'likely', `brwn sug 2kg is likely (${su && su.score})`);
  assert.ok(fl && fl.why.includes('no size to compare'), 'a name with no size is not skipped');
  assert.ok(fl.why.includes('price close to the FCCC price'));
  assert.ok(!r.left.some((x) => x.item.code === 'SW3'));
  throws(() => FC.answerSweep(mere, su.item.uid, 'yes', { listUid: LIST, rowKey: su.line.key }), /cannot change products/);
  FC.answerSweep(owner, su.item.uid, 'yes', { listUid: LIST, rowKey: su.line.key });
  FC.answerSweep(owner, fl.item.uid, 'no');
  const after = FC.sweepRound();
  assert.ok(!after.left.some((x) => ['SW1', 'SW2'].includes(x.item.code)));
  assert.strictEqual(after.answered, 2);
  assert.strictEqual(I.findItem('SW1').fccc, 1);
  assert.strictEqual(I.findItem('SW1').fccc_max, 4.98);
});

// ---------------------------------------------------------------- month close
test('month close: owner or admin, reminders by the 15th, a reason when not all reconciled, months in order, reopen with a reason', () => {
  const c = ACC.monthEndChecklist('2026-10');
  ['safecount', 'loans', 'bills'].forEach((k) => assert.ok(c.auto.some((a) => a.key === k), k));
  ['credit', 'drawings'].forEach((k) => assert.ok(c.manual.some((a) => a.key === k), k));
  assert.match(ACC.closeAlerts(owner, '2026-11-10')[0].text, /2026-10 month close/);
  assert.strictEqual(ACC.closeAlerts(owner, '2026-11-10')[0].level, 'info');
  assert.strictEqual(ACC.closeAlerts(admin, '2026-11-16')[0].level, 'urgent');
  assert.deepStrictEqual(ACC.closeAlerts(mere, '2026-11-16'), []);
  throws(() => ACC.closeMonth(pay, '2026-10'), /owner or admin/);
  throws(() => ACC.closeMonth(admin, '2026-10'), /why you are closing/);
  ACC.closeMonth(admin, '2026-10', { reason: 'Trial month' });
  assert.strictEqual(lockDate(), '2026-10-31');
  assert.strictEqual(ACC.monthCloseStatus('2026-10').closed, true);
  assert.deepStrictEqual(ACC.closeAlerts(owner, '2026-11-16'), []);
  throws(() => ACC.closeMonth(owner, '2026-12', { reason: 'x' }), /months before/);
  const yr = ACC.closeYear('2026');
  assert.strictEqual(yr.length, 12);
  assert.strictEqual(yr[9].closed, true);
  throws(() => ACC.reopenMonth(admin, '2026-10', ''), /why/);
  ACC.reopenMonth(admin, '2026-10', 'Missed an invoice');
  assert.strictEqual(lockDate(), '2026-09-30');
});

done();
