// 3.9.8 the hard stuff: no internet / websites down or changed, photos and screenshots that read wrong, bad scans,
// junk from the Aronium link and from the cloud, Excel files that are not the pack, and everyday mistakes.
// Rule for every case: the app never crashes, never saves a wrong figure on its own, and says what to do.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db, withSystem } from '../src/db/connection.js';
import { clock, setShared, deviceId, setSetting, getSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as L from '../src/modules/aronium/link.js';
import * as UB from '../src/services/utilityBills.js';
import * as SP from '../src/services/shopProfile.js';
import * as LPG from '../src/modules/inventory/lpg.js';
import * as LN from '../src/modules/loans/service.js';
import * as MR from '../src/modules/accounting/monthReport.js';
import * as IR from '../src/modules/accounting/insightReports.js';
import * as ACC from '../src/modules/accounting/service.js';
import * as SPK from '../src/services/setupPack.js';
import * as SW from '../src/services/setupWizard.js';
import * as PW from '../src/services/productWatch.js';
import { readPaperText } from '../src/services/paperRead.js';
import { applyPulledRecords } from '../src/services/records.js';
import { runSelfCheck } from '../src/services/selfCheck.js';
import { listErrors } from '../src/services/errorLog.js';
import { test, atest, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-11-14T10:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const noCrash = (name, fn) => { try { fn(); } catch (e) { if (!e.isAppError && !/^[A-Z]/.test(String(e.message))) throw new Error(`${name}: crashed with "${e.message}"`); } };

// ---------------------------------------------------------------- internet
let water;
await atest('no internet: the water check fails quietly, says why, and tries again after 2 hours (not tomorrow)', async () => {
  water = SP.saveAccount(owner, { shopCode: 'S1', kind: 'water', label: 'WAF – shop', accountNo: '200000013616' });
  const down = async () => { throw new Error('Network request failed'); };
  const r = await UB.checkWaterBills({ fetchFn: down, today: '2026-11-14' });
  assert.equal(r.checked, 0); assert.ok(r.problems[0].includes('Network request failed'));
  assert.ok(getSetting('waf_check_problem', '').includes('Network'));
  const again = await UB.checkWaterBills({ fetchFn: down, today: '2026-11-14' });
  assert.equal(again.skipped, 'waiting after a failed try', 'not hammered every sync');
  setSetting('waf_fail_ms', String(Date.now() - 3 * 3600000));
  const page = '<div class="water-bill-data">Your bill total is <b>$50.26</b> for Account Number <b>200000013616</b>. due on 09-12-2026</div>';
  const ok = await UB.checkWaterBills({ fetchFn: async () => ({ text: async () => page }), today: '2026-11-14' });
  assert.equal(ok.checked, 1, 'back online: checked');
  assert.equal(getSetting('waf_check_problem', ''), '');
});
await atest('WAF answers with an error page, a changed page, or a half page: no bill is made from it', async () => {
  for (const html of ['<html><h1>502 Bad Gateway</h1></html>', '', '<div class="water-bill-data">Your bill total is <b>', '<div class="water-bill-data">total is $abc</div>', '{"error":"maintenance"}']) {
    const r = await UB.checkWaterBills({ fetchFn: async () => ({ text: async () => html }), today: '2026-11-15', force: true });
    assert.equal(r.checked, 0, html);
  }
  assert.equal(UB.parseWafHtml(null), null);
  assert.equal(UB.parseWafHtml(42), null);
});
await atest('FCCC gas page down or changed: nothing changes, a note says to look by hand', async () => {
  const r = await LPG.checkLpg({ fetchText: async () => { throw new Error('timeout'); }, force: true });
  assert.ok(r.error);
  assert.ok(getSetting('lpg_problem', '').includes('Could not look'));
  const r2 = await LPG.checkLpg({ fetchText: async () => '<html>new website, no list</html>', force: true });
  assert.equal(r2.found, 0);
  assert.equal(LPG.lpgPrices(), null, 'no prices made up');
  const r3 = await LPG.checkFuel({ fetchText: async () => { throw new Error('HTTP 503'); }, force: true });
  assert.ok(r3.error);
});
test('a misread gas or fuel price is never kept as the FCCC maximum', () => {
  assert.ok(LPG.lpgOdd({ c12: { r: 4216 } }, null), '$4216 for 12 kg is a misread');
  assert.ok(LPG.lpgOdd({ c12: { r: 4.21 } }, null), '$4.21 for 12 kg is a misread');
  assert.equal(LPG.lpgOdd({ c12: { r: 42.16 }, c4_5: { r: 15.81 } }, null), null);
  assert.ok(LPG.lpgOdd({ c12: { r: 80 } }, { prices: { c12: { r: 42.16 } } }), 'a jump of 90 % waits for a person');
  assert.equal(LPG.lpgOdd({ c12: { r: 44 } }, { prices: { c12: { r: 42.16 } } }), null, 'a normal monthly change is fine');
});

// ---------------------------------------------------------------- photos and screenshots
test('a photo that reads as rubbish fills nothing and never stops the screen', () => {
  for (const kind of ['efl_bill', 'invoice', 'z_report', 'cheque', 'deposit', 'no_such_kind']) {
    for (const text of ['', null, undefined, '%%%% ### ????', 'l0rem 1psum 12,3.4.5 $$$ //', '\u0000\u0001\u0002', 'x'.repeat(200000), '9'.repeat(5000)]) {
      const r = readPaperText(kind, text);
      assert.ok(r && typeof r.fields === 'object', `${kind}`);
    }
  }
});
test('EFL screenshot misreads: wrong account, missing total, odd spacing and commas', () => {
  assert.deepEqual(UB.parseEflText('Account Number: 75000 93848\nTotal Amount Due: $1,234.50\nBill Due on: 3 / 12 / 2026'), { account: '7500093848', total: 1234.5, overdue: null, due: '2026-12-03' });
  const none = UB.parseEflText('EFL\nPlease tick I am not a robot');
  assert.equal(none.total, null, 'no total → nothing filled, the person types it');
  const other = readPaperText('efl_bill', 'Account Number: 1111111111\nTotal Amount Due: $10.00');
  assert.equal(other.fields.accountNo, '1111111111', 'the screen compares it with the account and warns when different');
});
test('a bill typed with nonsense is refused with a plain message', () => {
  const p = SP.saveAccount(owner, { shopCode: 'S1', kind: 'power', label: 'EFL – shop', accountNo: '7500093848' });
  throws(() => UB.recordCheck(owner, p, { total: 'abc' }), /amount|number|total/i);
  throws(() => UB.recordCheck(owner, p, { total: -50 }), /amount|negative|total/i);
  throws(() => SP.saveAccount(owner, { shopCode: 'S1', kind: 'water', label: 'x', accountNo: '<script>' }), /odd characters/);
  throws(() => SP.saveAccount(owner, { shopCode: 'S9', kind: 'water', label: 'x', accountNo: '123' }), /shop/i);
});
test('a loan statement photo that reads badly gives no lines, and saving it asks for the figures', () => {
  for (const t of ['', 'BSP\nStatement', '1,2,3 4.5.6', 'Balance b/f\nlots of ### text']) {
    const r = LN.parseLoanStatement(t);
    assert.ok(r && Array.isArray(r.lines || r) );
  }
});

// ---------------------------------------------------------------- scanning
test('scanning: every barcode of a product works (first, middle, last); spaces and stray characters are cleaned; unknown = nothing', () => {
  const it = I.saveItem(owner, { code: 'CK1', name: 'Coke 1.5L', cost: 2, price: 3.95, barcodes: ['5449000000996', '5449000000997', '5449000000998'] });
  const uid = typeof it === 'string' ? it : it.uid;
  const b = db().get('SELECT barcode FROM inv_items WHERE uid = ?', [uid]).barcode;
  if (!b || !b.includes(',')) db().run("UPDATE inv_items SET barcode = '5449000000996, 5449000000997,5449000000998' WHERE uid = ?", [uid]);
  for (const code of ['5449000000996', '5449000000997', '5449000000998', ' 5449000000997 ', '5449000000997\n', 'ck1']) assert.equal((I.findItem(code) || {}).uid, uid, JSON.stringify(code));
  for (const code of ['', '   ', '544900000099', '%', '_', '5449000000997,5449000000998', '0000', 'DROP TABLE inv_items']) assert.equal(I.findItem(code), null, JSON.stringify(code));
});

// ---------------------------------------------------------------- Aronium link junk
test('Aronium link: broken, half-sent and strange records never stop it, and nothing wrong is booked', () => {
  setShared('main_tablet_device', deviceId());
  const put = (uid, kind, period, part, parts, data) => db().run(`INSERT OR REPLACE INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES (?, 'S1-T1', 'S1', 'Shop 1, Till 1', ?, ?, ?, ?, ?, ?, '2026-11-14T00:00:00Z', '1.2', '2026-11-14 10:00:00', 'x', 'synced')`, [uid, kind, period, part, parts, data, `h-${uid}`]);
  put('j1', 'products', 'all', 0, 1, 'this is not json');
  put('j2', 'sales_day', '2026-11-13', 0, 3, JSON.stringify({ cols: ['code'], rows: [['1001']] })); // part 1 of 3 only
  put('j3', 'z', 'z99', 0, 1, JSON.stringify({ date: 'not a date', total: 'lots' }));
  put('j4', 'mystery_kind', 'x', 0, 1, JSON.stringify({ a: 1 }));
  put('j5', 'credit', 'all', 0, 1, JSON.stringify([{ name: null, owing: 'NaN' }]));
  let r;
  assert.doesNotThrow(() => { r = L.processLink({ force: true }); });
  assert.ok(r);
  assert.equal(db().get("SELECT COUNT(*) AS n FROM inv_moves WHERE uid LIKE 'SL-S1-2026-11-13-%'").n, 0, 'half a day of sales waits – not booked');
  assert.doesNotThrow(() => L.linkStatus());
  assert.doesNotThrow(() => L.aroniumCredit());
  assert.doesNotThrow(() => L.aroniumCreditTrail());
  assert.doesNotThrow(() => PW.watchProducts('S1', [{ code: null, name: null }, { code: 'X', name: '' }, null, 7, { code: 'Y', name: 'Yo', price: 'abc', vat_rate: 'x' }].filter((x) => x && typeof x === 'object')));
});

// ---------------------------------------------------------------- sync junk
test('sync: broken records for the new 3.9.8 tables never stop the good ones arriving', () => {
  const good = { t: 'ap_suppliers', k: 'SUP-OK', u: '2026-11-14 09:00:00', row: { uid: 'SUP-OK', name: 'Good supplier', updated_at: '2026-11-14 09:00:00' } };
  const junk = [
    { t: 'product_changes', k: 'PC-1', u: '2026-11-14 09:00:00', row: { uid: 'PC-1' } },
    { t: 'loan_statements', k: 'LS-1', u: 'not a date', row: { uid: 'LS-1', extra_col_from_the_future: 1 } },
    { t: 'utility_checks', k: 'UC-1', u: '2026-11-14 09:00:00', row: null },
    { t: 'table_from_a_newer_app', k: 'Z', u: '2026-11-14 09:00:00', row: { uid: 'Z' } },
    { t: 'shop_accounts', k: 'SA-1', u: '2026-11-14 09:00:00', row: { uid: 'SA-1', shop_code: 'S1' } },
  ];
  assert.doesNotThrow(() => withSystem(() => applyPulledRecords(junk.concat([good]))));
  assert.ok(db().get("SELECT 1 AS x FROM ap_suppliers WHERE uid = 'SUP-OK'"), 'the good record arrived');
});

// ---------------------------------------------------------------- Excel files that are not the pack
test('set-up pack: an empty file, another spreadsheet, or junk rows → a clear preview, nothing saved', () => {
  for (const sheets of [{}, null, undefined, { Sheet1: [['Name', 'Amount'], ['x', 1]] }, { Suppliers: [] }, { Suppliers: [['Supplier']] }, { Suppliers: [['nonsense', 'headers'], ['a', 'b']] },
    { 'Supplier products': [['Supplier', 'Their code'], ['Nobody', '1']] }, { 'MPAiSA wallets': [['Wallet', 'Shop (S1, S2…)', 'Phone number', 'Opening date (YYYY-MM-DD)', 'Opening balance'], ['W', 'S1', '', '31/02/2026', '1e9x']] }]) {
    const pv = SPK.readPack(sheets || {});
    assert.ok(pv && pv.counts);
  }
  const bad = SPK.readPack({ 'MPAiSA wallets': [['Wallet', 'Shop (S1, S2…)', 'Phone number', 'Opening date (YYYY-MM-DD)', 'Opening balance'], ['W', 'S1', '', '2026-11-01', 'twelve']] });
  assert.equal(bad.wallets[0].action, 'problem');
  const res = SPK.applyPack(owner, bad);
  assert.equal(res.wallets, 0);
});

// ---------------------------------------------------------------- everyday mistakes
test('everyday mistakes on the new screens: plain messages, nothing half saved', () => {
  throws(() => ACC.closeMonth(mere, '2026-10'), /owner or admin/);
  throws(() => MR.keepActions(mere, '2026-10', []), /owner or admin/);
  throws(() => MR.markAction(owner, '2020-01', 'x', 'done'), /No actions/);
  throws(() => SW.nextStep(owner, 'no-such-step'), /not found/);
  throws(() => SW.tickCheck(mere, 'business', 0, true), /owner or admin/);
  assert.doesNotThrow(() => SW.tickCheck(owner, 'business', 999, true), 'a check that does not exist is harmless');
  throws(() => AP.makePayment(owner, { invoiceUids: [], amount: 'abc', method: 'mpaisa' }), /./);
  noCrash('receive with a negative quantity', () => I.receiveDelivery(owner, { supplierUid: 'nobody', shopCode: 'S1', lines: [{ itemUid: 'x', qty: -5 }] }));
});
test('reports on empty, future and very old months work (just empty)', () => {
  for (const ym of ['2031-01', '1999-12', '2026-11']) {
    const r = MR.monthReport(ym, { fresh: true });
    assert.ok(r && r.headline && Array.isArray(r.suggestions), ym);
    assert.ok(MR.monthReportDoc(ym).sections.length > 5);
  }
  assert.doesNotThrow(() => IR.chequeTimeline('2026-13-45', 'rubbish'));
  assert.doesNotThrow(() => IR.customerStatement('', '2026-01-01', '2026-12-31'));
  assert.doesNotThrow(() => IR.pendingSummary('not a date'));
});

// ---------------------------------------------------------------- start the day
test('Start the day: builds on any data (empty too), owner / admin only, with a PDF', () => {
  const D = require('../src/services/dayStart.js');
  assert.equal(D.mayStartDay(mere), false);
  assert.equal(D.mayStartDay(owner), true);
  const t = Date.now();
  const d = D.startOfDay('2026-11-14', owner);
  assert.ok(Date.now() - t < 3000, 'quick');
  assert.ok(d.money && d.goingOut && d.comingIn && d.orders && d.outlook && typeof d.outlook.text === 'string');
  assert.equal(d.comingIn.sales.week.length, 7);
  const doc = IR.INSIGHT_REPORTS.find((r) => r.id === 'biz_day').build('2026-11-14', '2026-11-14', owner, {});
  assert.ok(doc.sections.length === 5);
  assert.doesNotThrow(() => D.startOfDay('not a date', owner));
});
// ---------------------------------------------------------------- the app checks itself
test('self-check runs every part on the real data, writes any problem to the Problem log, and only once a day', () => {
  const r = runSelfCheck({ force: true, today: '2026-11-14' });
  assert.ok(r.ok.includes('Database'), JSON.stringify(r));
  assert.ok(r.ok.length >= 6, JSON.stringify(r));
  assert.deepEqual(r.problems, []);
  const again = runSelfCheck({ today: '2026-11-14' });
  assert.equal(again.at, r.at, 'not again the same day');
  db().run("INSERT INTO outbox (kind, payload, created_at, attempts) VALUES ('doc_upload', '{}', '2026-11-01 08:00:00', 9)");
  const r2 = runSelfCheck({ force: true, today: '2026-11-14' });
  assert.ok(r2.problems.some((p) => /stuck/.test(p)), JSON.stringify(r2.problems));
  assert.ok(listErrors(20).some((e) => /self-check/.test(JSON.stringify(e))), 'it went into the Problem log (and so to support)');
});
done();
