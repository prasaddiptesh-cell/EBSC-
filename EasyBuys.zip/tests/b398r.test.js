// 3.9.8 monthly business report, business insight reports (any time) and the new moving-in steps.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, stamp } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as MR from '../src/modules/accounting/monthReport.js';
import * as IR from '../src/modules/accounting/insightReports.js';
import * as ACC from '../src/modules/accounting/service.js';
import { migrationStatus } from '../src/services/migration.js';
const findReport = (id) => IR.INSIGHT_REPORTS.find((x) => x.id === id);
import * as SPK from '../src/services/setupPack.js';
import * as I from '../src/modules/inventory/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as SW from '../src/services/setupWizard.js';
import { tickMigration } from '../src/services/migration.js';
import { autoProblemReport, runWebChecks } from '../src/platform/cloud.js';
import { logError } from '../src/services/errorLog.js';
import { setSetting } from '../src/services/core.js';
import { setLoginOn } from '../src/modules/staff/profile.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-11-03T20:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const now = stamp();
let k = 0;
const eod = (shop, d, total) => db().run("INSERT INTO aronium_eods (uid, shop_code, eod_date, total, vat, zero, state, updated_at) VALUES (?,?,?,?,?,?, 'matched', ?)", [`E${k++}`, shop, d, total, Math.round(total * 0.1 * 100) / 100, 0, now]);
for (const ym of ['2026-08', '2026-09', '2026-10']) {
  const n = ym === '2026-10' ? 31 : 30;
  for (let d = 1; d <= n; d += 1) { eod('S1', `${ym}-${String(d).padStart(2, '0')}`, ym === '2026-10' ? 900 : 1000); eod('S2', `${ym}-${String(d).padStart(2, '0')}`, 500); }
}
const inv = (sup, d, total, cat = 'stock') => db().run("INSERT INTO ap_invoices (uid, supplier_uid, supplier_name, invoice_date, due_date, total, vat, shop_code, category, status, updated_at) VALUES (?,?,?,?,?,?,?,?,?, 'approved', ?)", [`I${k++}`, null, sup, d, d, total, 0, 'S1', cat, now]);
inv('Punjas', '2026-08-10', 4000); inv('Punjas', '2026-09-10', 4200); inv('Punjas', '2026-10-10', 6000); inv('Fiji Water', '2026-10-12', 300, 'drinks');
db().run("INSERT INTO cheques (uid, account_uid, cheque_no, cheque_date, payee, amount, status, handed_date, presented_date, updated_at) VALUES ('C1','A1','100','2026-10-01','Punjas',4200,'presented','2026-10-02','2026-10-09',?)", [now]);
db().run("INSERT INTO cheques (uid, account_uid, cheque_no, cheque_date, payee, amount, status, handed_date, updated_at) VALUES ('C2','A1','101','2026-10-20','Punjas',6000,'written','2026-10-21',?)", [now]);
db().run("INSERT INTO cheques (uid, account_uid, cheque_no, cheque_date, payee, amount, status, updated_at) VALUES ('C3','A1','102','2026-10-30','FEA',150,'written',?)", [now]);

let r;
test('the month report adds up the sales from the End of days and compares with last month', () => {
  r = MR.monthReport('2026-10', { fresh: true });
  assert.equal(r.fig.sales, 31 * 1400);
  assert.equal(r.prev.sales, 30 * 1500);
  assert.equal(r.fig.byShop.S1.sales, 31 * 900);
  assert.ok(r.headline.salesChange < 0);
  assert.ok(r.salesChange < -5, 'per day fell about 6.7 %');
});
test('forecast for next month is in a sensible range', () => {
  assert.equal(r.forecast.ym, '2026-11');
  assert.ok(r.forecast.sales > 30 * 1300 && r.forecast.sales < 30 * 1500, String(r.forecast.sales));
  assert.ok(r.forecast.low <= r.forecast.sales && r.forecast.high >= r.forecast.sales);
});
test('suppliers: spend, 3-month average and a suggested budget rounded to $50', () => {
  const p = r.suppliers.find((s) => s.name === 'Punjas');
  assert.equal(p.spent, 6000);
  assert.ok(p.suggestBudget > 0 && p.suggestBudget % 50 === 0, String(p.suggestBudget));
  assert.ok(p.change > 0);
});
test('VMS checks list each item; a falling month gets a sales suggestion', () => {
  assert.ok(r.vat.vms.length >= 5);
  assert.ok(r.suggestions.some((s) => s.key === 'salesPerDay'), JSON.stringify(r.suggestions.map((s) => s.key)));
  assert.ok(r.calm.watch.length >= 1);
});
test('only the owner / admin keeps the actions; next month measures them again', () => {
  throws(() => MR.keepActions(mere, '2026-10', r.suggestions), /owner or admin/);
  MR.keepActions(owner, '2026-10', r.suggestions);
  assert.equal(ACC.monthEndChecklist('2026-10').auto.find((a) => a.key === 'report').done, true);
  assert.equal(ACC.monthEndChecklist('2026-09').auto.find((a) => a.key === 'report').done, false);
  for (let d = 1; d <= 3; d += 1) eod('S1', `2026-11-0${d}`, 1500);
  const n = MR.monthReport('2026-11', { fresh: true });
  const f = n.followUp.find((a) => a.key === 'salesPerDay');
  assert.ok(f && ['done', 'better'].includes(f.state), JSON.stringify(f));
  MR.markAction(owner, '2026-10', 'salesPerDay', 'done');
  assert.equal(MR.actionsKept('2026-10').items.find((a) => a.key === 'salesPerDay').mark, 'done');
});
test('the monthly report is in the reports hub and builds a document', () => {
  const doc = findReport('biz_month').build('2026-10-01', '2026-10-31', owner, {});
  assert.ok(doc.sections.length >= 8);
  assert.ok(doc.summary.find((s) => s.label === 'Sales').value.includes('43,400'));
});
test('cheque timeline: written, given, cleared dates and days between', () => {
  const t = IR.chequeTimeline('2026-10-01', '2026-10-31', '2026-11-03');
  const c1 = t.rows.find((x) => String(x.no) === '100');
  assert.equal(c1.state, 'cleared'); assert.equal(c1.toGive, 1); assert.equal(c1.toClear, 7);
  assert.equal(t.rows.find((x) => String(x.no) === '101').state, 'given');
  assert.equal(t.rows.find((x) => String(x.no) === '102').state, 'pending');
  assert.equal(t.totals.given, 6000); assert.equal(t.totals.pending, 150);
  assert.ok(findReport('biz_cheques').build('2026-10-01', '2026-10-31', owner, {}).sections.length === 3);
});
test('pending in and out and customer accounts build any time (no Aronium yet → empty, no error)', () => {
  const p = findReport('biz_pending').build('2026-11-03', '2026-11-03', owner, {});
  assert.ok(p.summary.length >= 6);
  assert.ok(findReport('biz_customers').build('2026-11-03', '2026-11-03', owner, {}).sections.length === 2);
  const s = findReport('biz_customers').build('2026-07-01', '2026-11-03', owner, { customer: 'Nobody' });
  assert.ok(s.title.includes('Nobody'));
});
test('moving-in steps include the new parts', () => {
  const keys = migrationStatus().map((s) => s.key);
  ['fcccsweep', 'gas', 'billaccounts', 'approvers', 'viber', 'freshstart'].forEach((x) => assert.ok(keys.includes(x), x));
});
test('set-up pack: preview first, then the good rows are saved and problems skipped', () => {
  const rice = I.saveItem(owner, { code: 'R1', name: 'Golden Harvest Custard Powder Vanilla 200g', cost: 2, price: 3 });
  const doc = SPK.packDoc();
  assert.equal(doc.sections.length, 5);
  const head = (key) => doc.sections.find((x) => x.title === SPK.SHEETS.find((h) => h.key === key).title).columns.map((c) => c.title);
  const sheets = {
    Suppliers: [head('suppliers'), ['Ashabhai & Company Pte Limited', '', '500460306', '7763 946', '14', 'cash', '1500', '', 'Mon,Thu', '2', 'Ashabhai orders'], ['Bad One', '', '12ab', '', '', '', 'x']],
    'Supplier products': [head('products'), ['Ashabhai & Company Pte Limited', '111-21537-01', 'Gldn Hrvst Custard Powder 36 x 200gm - Vanilla', 'Each', '36x200gm', '1.63', '12.5', '16/09/2026', '', 'R1', '', 'Y'],
      ['Ashabhai & Company Pte Limited', '999', 'Something unknown', '', '', '2', '', '', '', '', '', '']],
    'Bill accounts': [head('bills'), ['S1', 'Water', 'Shop 1 water', '200000013616', '', ''], ['S9', 'Power', 'x', '1', '', '']],
    'MPAiSA wallets': [head('wallets'), ['MyCash Shop 1', 'S1', '', '2026-11-01', '125.50']],
    'Order approvers': [head('approvers'), ['Mere Tuilau', 'S1, S2']],
  };
  const pv = SPK.readPack(sheets);
  assert.equal(pv.counts.suppliers.new, 1); assert.equal(pv.counts.suppliers.problems, 1);
  assert.equal(pv.products[0].action, 'new', JSON.stringify(pv.products[0].problems)); assert.equal(pv.products[0].itemUid, rice.uid);
  assert.equal(pv.products[1].action, 'problem');
  assert.equal(pv.counts.bills.new, 1); assert.equal(pv.counts.bills.problems, 1);
  assert.equal(pv.wallets[0].opening, 125.5);
  assert.equal(db().get("SELECT COUNT(*) AS n FROM ap_suppliers WHERE name LIKE 'Ashabhai%'").n, 0, 'preview saves nothing');
  throws(() => SPK.applyPack(mere, pv), /owner or admin/);
  const res = SPK.applyPack(owner, pv);
  assert.equal(res.suppliers, 1); assert.equal(res.products, 1); assert.equal(res.bills, 1); assert.equal(res.wallets, 1); assert.equal(res.approvers, 1);
  const sup = db().get("SELECT * FROM ap_suppliers WHERE name LIKE 'Ashabhai%'");
  assert.equal(sup.budget_monthly, 1500); assert.equal(sup.tin, '500460306');
  const link = db().get('SELECT * FROM inv_item_suppliers WHERE item_uid = ? AND supplier_uid = ?', [rice.uid, sup.uid]);
  assert.equal(link.supplier_code, '111-21537-01'); assert.equal(link.last_date, '2026-09-16');
  assert.equal(I.getItem(rice.uid).supplier_uid, sup.uid);
  // again: now an update, nothing doubled
  const pv2 = SPK.readPack(sheets);
  assert.equal(pv2.counts.suppliers.change, 1); assert.equal(pv2.counts.bills.change, 1);
  SPK.applyPack(owner, pv2);
  assert.equal(db().get("SELECT COUNT(*) AS n FROM shop_accounts WHERE account_no = '200000013616'").n, 1);
  assert.equal(db().get("SELECT COUNT(*) AS n FROM wallets WHERE name = 'MyCash Shop 1'").n, 1);
});
test('a leaver\'s login is turned off with one tap (with a reason), and can be turned back on', () => {
  throws(() => setLoginOn(owner, mere.uid, false, ''), /why/i);
  throws(() => setLoginOn(owner, owner.uid, false, 'x'), /own login/);
  assert.equal(setLoginOn(owner, mere.uid, false, 'Left on 31 Oct'), true);
  assert.equal(db().get('SELECT active FROM users WHERE uid = ?', [mere.uid]).active, 0);
  assert.equal(setLoginOn(owner, mere.uid, true, ''), true);
  assert.equal(db().get('SELECT active FROM users WHERE uid = ?', [mere.uid]).active, 1);
});
test('step-by-step set-up: one step at a time, checks before Next, leave for later comes back at the end', () => {
  const steps = SW.wizardSteps();
  assert.equal(steps[0].key, 'business'); assert.equal(steps[steps.length - 1].key, 'freshstart');
  assert.equal(steps.length, 26);
  const first = SW.currentStep();
  assert.ok(first, 'there is a step to do');
  throws(() => SW.nextStep(mere, first.key), /owner or admin/);
  // not done yet → Next refused
  throws(() => SW.nextStep(owner, 'business'), /not finished|checks/i);
  tickMigration(owner, 'business', 'done');
  throws(() => SW.nextStep(owner, 'business'), /checks/i);
  SW.GUIDE.business.checks.forEach((_, j) => SW.tickCheck(owner, 'business', j, true));
  SW.goTo(owner, 'business');
  SW.nextStep(owner, 'business');
  assert.notEqual(SW.currentStep().key, 'business');
  throws(() => SW.leaveForLater(owner, 'samples', 'x'), /sample/i);
  const at = SW.currentStep().key;
  SW.leaveForLater(owner, at, 'waiting for papers');
  assert.notEqual(SW.currentStep().key, at);
  assert.ok(SW.wizardSteps().find((s) => s.key === at).later);
  assert.ok(SW.wizardSummary().later >= 1);
  // during the set-up automatic Viber posts are held (no fresh start date yet in this test database)
  assert.equal(typeof SW.holdAutomatic(), 'boolean');
});
test('problem loop: new errors on this device go to support by themselves – at most every 12 hours, at once after a crash', () => {
  const q = () => db().all("SELECT * FROM outbox WHERE kind = 'support_email'").length;
  const n0 = q();
  assert.equal(autoProblemReport(Date.now()), false, 'nothing new → nothing sent');
  logError(new Error('Test problem one'), { where: 'test' });
  assert.equal(autoProblemReport(Date.now()), true);
  assert.equal(q(), n0 + 1);
  logError(new Error('Test problem two'), { where: 'test' });
  assert.equal(autoProblemReport(Date.now() + 3600000), false, 'not again within 12 hours');
  logError(new Error('The app closed by itself'), { where: 'test', fatal: true });
  assert.equal(autoProblemReport(Date.now() + 3600000), true, 'a crash goes at once');
  assert.equal(q(), n0 + 2);
});
test('web checks never hold up the sync (they run on their own, one round at a time)', () => {
  const t = Date.now();
  runWebChecks(); runWebChecks();
  assert.ok(Date.now() - t < 200, 'returns at once');
});
done();
