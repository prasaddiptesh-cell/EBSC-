// v3.5 B4: till shifts one after the other (owner may continue), two signatures, shortages agreed by the cashier and
// fed to the pay run, Aronium End of day matched to each shift's Z (flags, explanation, VAT, month end, To verify),
// who owes us (Aronium staff credit CSV, ageing, limits, settlement receipts), and the dashboard card registry.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared, getShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { saveRolePerms, rolePerms, can } from '../src/services/access.js';
import * as T from '../src/modules/till/service.js';
import * as S from '../src/modules/till/shifts.js';
import * as E from '../src/modules/till/eod.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as P from '../src/modules/payroll/service.js';
import * as O from '../src/modules/owed/service.js';
import * as V from '../src/modules/verify/service.js';
import * as D from '../src/services/dashboardCards.js';
import { alerts as tillAlerts } from '../src/modules/till/alerts.js';
import { alerts as owedAlerts } from '../src/modules/owed/alerts.js';
import { REPORTS as OWED_REPORTS } from '../src/modules/owed/reports.js';
import '../src/modules/dashboard/cards.js';
import { MENU as TILL_MENU } from '../src/modules/till/menu.js';
import { MENU as OWED_MENU } from '../src/modules/owed/menu.js';
import { MENU as DASH_MENU } from '../src/modules/dashboard/menu.js';
import { checkMenu } from '../src/services/menus.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-09T20:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', shopCode: 'S1' }, owner);
setShared('verify_rules', { viberMode: 'share' });
const SIG = 'data:image/png;base64,AAAA';
const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 });
const count = (who, extra = {}) => T.saveTillCount(who, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-09', shift: 'Morning', cashierUid: mere.uid, openingFloat: 100,
  denominations: { n100: 6 }, zNumber: 'Z-0101', zTotal: 500, zCash: 500, tenders: [], payouts: [], adjustments: [], floatKept: 100, ...extra }, { photos: ['file:///z.jpg'] });

test('menus of the new and changed modules are valid', () => {
  for (const [id, menu] of [['till', TILL_MENU], ['owed', OWED_MENU], ['dashboard', DASH_MENU]]) {
    assert.deepStrictEqual(checkMenu({ id, menu }, null), [], id);
    assert.strictEqual(menu[0].items[0].id, 'home');
  }
});

let morning;
test('shifts: the next shift on a till waits until the last one is balanced; only the owner can continue it', () => {
  morning = S.startShift(mgr, { shopCode: 'S1', tillUid: till, date: '2026-10-09', shift: 'Morning', cashierUid: mere.uid });
  assert.strictEqual(morning.status, 'open');
  assert.strictEqual(morning.opening_float, 100);
  throws(() => S.startShift(mgr, { shopCode: 'S1', tillUid: till, date: '2026-10-09', shift: 'Morning', cashierUid: sam.uid }), /already started/);
  throws(() => S.startShift(mgr, { shopCode: 'S1', tillUid: till, date: '2026-10-09', shift: 'Afternoon', cashierUid: sam.uid }), /not balanced yet.*Only the owner/);
  throws(() => T.saveTillCount(mgr, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-09', shift: 'Afternoon', cashierUid: sam.uid, openingFloat: 100, cashCounted: 100, zCash: 0, floatKept: 100 }, { photos: ['x'] }), /Balance that shift first/);
  throws(() => S.continueShift(mgr, morning.uid, { zNumber: 'Z1', zTotal: 10 }), /Only the owner/);
  throws(() => S.continueShift(owner, morning.uid, { zTotal: 10 }), /End of day \(Z\) number/);
  const c = S.continueShift(owner, morning.uid, { zNumber: 'Z-0101', zTotal: 500 });
  assert.strictEqual(c.status, 'continued');
  assert.ok(tillAlerts(owner).some((a) => a.id === 'till-continued' && a.level === 'urgent'), 'flagged until counted');
  const aft = S.startShift(mgr, { shopCode: 'S1', tillUid: till, date: '2026-10-09', shift: 'Afternoon', cashierUid: sam.uid });
  assert.strictEqual(aft.status, 'open');
  assert.ok(V.recentAlerts().some((a) => /continued by Divnesh/.test(a.text)), 'notification');
});

let mc;
test('two signatures: cashier and balancer; the same person only for owner/admin or with the permission', () => {
  mc = count(mgr, { reason: 'x' });
  assert.strictEqual(S.getShift(morning.uid).status, 'counted', 'the count closes its shift');
  assert.ok(!tillAlerts(owner).some((a) => a.id === 'till-continued'));
  throws(() => T.approveTillCount(owner, mc.uid), /must both sign/);
  throws(() => T.signTillCount(mgr, mc.uid, { cashierSig: SIG, balancerSig: SIG, balancerUid: mere.uid }), /cannot be both the cashier and the balancer/);
  // Given the permission, a staff member may balance their own till.
  const perms = rolePerms();
  saveRolePerms(owner, { ...perms, staff: perms.staff.concat(['till_self_balance']) });
  assert.ok(can(mere, 'till_self_balance'));
  T.signTillCount(mgr, mc.uid, { cashierSig: SIG, balancerSig: SIG, balancerUid: mere.uid });
  saveRolePerms(owner, { ...perms, staff: perms.staff.filter((p) => p !== 'till_self_balance') });
  T.signTillCount(mgr, mc.uid, { cashierSig: SIG, balancerSig: SIG, balancerUid: mgr.uid });
  const c = T.getTillCount(mc.uid);
  assert.strictEqual(c.balancer_name, 'Anita Manager');
  assert.ok(T.isSigned(c));
  T.approveTillCount(owner, mc.uid);
  assert.strictEqual(T.getTillCount(mc.uid).status, 'approved');
});

test('signatures given when saving; a changed count must be signed again', () => {
  const t2 = T.saveTill(owner, { shopCode: 'S2', name: 'Till A', floatAmount: 50 });
  const c = T.saveTillCount(mgr, { shopCode: 'S2', tillUid: t2, shiftDate: '2026-10-08', shift: 'Night', cashierUid: sam.uid, openingFloat: 50, cashCounted: 150, zCash: 100, zTotal: 100, floatKept: 50,
    balancerUid: mgr.uid, cashierSig: SIG, balancerSig: SIG }, { photos: ['x'] });
  assert.ok(T.isSigned(c));
  const c2 = T.saveTillCount(mgr, { uid: c.uid, shopCode: 'S2', tillUid: t2, shiftDate: '2026-10-08', shift: 'Night', cashierUid: sam.uid, openingFloat: 50, cashCounted: 151, zCash: 100, zTotal: 100, floatKept: 50 });
  assert.ok(!T.isSigned(c2));
});

let shortCount;
let shortage;
test('shortage: waits for the cashier; agreed in parts → a till_short charge in the pay run, its own highlighted line', () => {
  shortCount = T.saveTillCount(mgr, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-09', shift: 'Afternoon', cashierUid: sam.uid, openingFloat: 100, cashCounted: 130, zCash: 60, zTotal: 60, zNumber: '102', floatKept: 100, reason: 'Not sure' }, { photos: ['x'] });
  assert.strictEqual(shortCount.over_short, -30);
  shortage = S.shortageForCount(shortCount.uid);
  assert.strictEqual(shortage.status, 'waiting');
  assert.strictEqual(shortage.user_uid, sam.uid);
  assert.ok(tillAlerts(sam).some((a) => a.id === 'till-shortages'), 'the cashier sees it too');
  P.saveProfile(owner, { userUid: sam.uid, payType: 'salary', weeklySalary: 300, tin: '1', fnpfNo: '1' });
  let line = P.computeLine(sam, P.getProfile(sam.uid), '2026-10-10');
  assert.ok(line.warnings.some((w) => /Till shortage \$30\.00 .* not decided yet/.test(w)), 'red in the pay run');
  throws(() => S.agreeShortage(mgr, shortage.uid, {}), /must sign/);
  S.agreeShortage(mgr, shortage.uid, { signature: SIG, parts: 3 });
  const s = S.getShortage(shortage.uid);
  assert.strictEqual(s.status, 'agreed');
  assert.strictEqual(s.per_pay, 10);
  const d = P.debtBalance(s.charge_uid);
  assert.strictEqual(d.kind, 'till_short');
  assert.strictEqual(d.repay_per_pay, 10);
  assert.strictEqual(T.getTillCount(shortCount.uid).short_action, 'deduct');
  line = P.computeLine(sam, P.getProfile(sam.uid), '2026-10-10');
  const ded = line.deductions.find((x) => x.debtUid === s.charge_uid);
  assert.strictEqual(ded.amount, 10);
  assert.strictEqual(ded.kind, 'till_short');
  assert.strictEqual(ded.highlight, true);
  assert.ok(!line.warnings.some((w) => /Till shortage/.test(w)));
});

test('shortage disagreed → manager decides (part, in parts); owner writes off; void cancels the charge', () => {
  T.signTillCount(owner, shortCount.uid, { cashierSig: SIG, balancerSig: SIG, balancerUid: mgr.uid });
  T.approveTillCount(owner, shortCount.uid);
  T.reopenTillCount(owner, shortCount.uid, 'recount');
  const again = S.shortageForCount(shortCount.uid);
  assert.strictEqual(again.status, 'waiting', 're-opened: back to the cashier');
  assert.strictEqual(P.debtBalance(shortage.charge_uid || S.getShortage(shortage.uid).charge_uid).status, 'void', 'old deduction cancelled');
  throws(() => S.decideShortage(mgr, again.uid, { action: 'deduct', note: 'x' }), /not answered yet/);
  throws(() => S.disagreeShortage(mgr, again.uid, {}), /why/);
  S.disagreeShortage(mgr, again.uid, { note: 'I gave correct change' });
  assert.ok(tillAlerts(mgr).some((a) => a.id === 'till-shortages' && a.level === 'urgent'));
  throws(() => S.decideShortage(mgr, again.uid, { action: 'write_off', note: 'ok' }), /Only the owner/);
  throws(() => S.decideShortage(mgr, again.uid, { action: 'deduct', amount: 50, note: 'half' }), /up to/);
  S.decideShortage(mgr, again.uid, { action: 'deduct', amount: 15, parts: 1, note: 'Half each – CCTV unclear' });
  const x = S.getShortage(again.uid);
  assert.strictEqual(x.status, 'deducted');
  assert.strictEqual(P.debtBalance(x.charge_uid).amount, 15);
  // A new shortage written off by the owner.
  const t3 = T.saveTill(owner, { shopCode: 'S2', name: 'Till B', floatAmount: 0 });
  const c = T.saveTillCount(mgr, { shopCode: 'S2', tillUid: t3, shiftDate: '2026-10-09', shift: 'Morning', cashierUid: mere.uid, openingFloat: 0, cashCounted: 90, zCash: 100, zTotal: 100, floatKept: 0, reason: 'busy' }, { photos: ['x'] });
  T.signTillCount(owner, c.uid, { cashierSig: SIG, balancerSig: SIG, balancerUid: mgr.uid });
  T.approveTillCount(owner, c.uid, { shortAction: 'write_off' });
  assert.strictEqual(S.shortageForCount(c.uid).status, 'written_off');
  assert.strictEqual(T.getTillCount(c.uid).short_action, 'write_off');
});

test('Aronium End of day: matched by Z number, difference flagged red, explained; no till balance → red', () => {
  // Z 0101 = the Morning count (500), typed "Z-0101" on the till. Aronium says 505.
  const e = E.addEod(mgr, { shopCode: 'S1', date: '2026-10-09', zNumber: '101', total: 505, vat: 50, zero: 55 });
  assert.strictEqual(e.state, 'difference');
  assert.deepStrictEqual(e.count_uids, [mc.uid]);
  assert.strictEqual(e.diff, 5);
  assert.strictEqual(E.eodForCount(mc.uid).uid, e.uid, 'red mark on the till balance');
  assert.ok(tillAlerts(owner).some((a) => a.id === 'till-eod-diff' && a.level === 'urgent'), 'Home');
  assert.ok(V.queue({}).some((q) => q.key === `aronium_eods:${e.uid}` && q.how === 'explain' && !q.done), 'To verify');
  assert.ok(V.recentAlerts().some((a) => /says \$505\.00 but the till balance says \$500\.00/.test(a.text)), 'notification');
  throws(() => E.addEod(mgr, { shopCode: 'S1', date: '2026-10-09', zNumber: 'Z 0101', total: 1 }), /already recorded/);
  // VAT uses Aronium's figure until explained.
  let v = A.vatReturn({ ym: '2026-10', shop: 'S1' });
  const row = v.saleRows.find((r) => r.aronium && /0?101|101/.test(r.ref));
  assert.strictEqual(row.total, 505);
  assert.strictEqual(v.aronium.unresolved, 1);
  assert.ok(A.monthEndChecklist('2026-10').auto.find((a) => a.key === 'eod').left === 1, 'month end flags it');
  throws(() => E.resolveEod(mgr, e.uid, {}), /Explain/);
  E.resolveEod(owner, e.uid, { use: 'till' }); // owner needs no reason
  assert.strictEqual(E.getEod(e.uid).state, 'resolved');
  v = A.vatReturn({ ym: '2026-10', shop: 'S1' });
  assert.ok(!v.saleRows.some((r) => r.aronium && r.total === 505), 'explained: the till balance is right');
  assert.ok(v.saleRows.some((r) => !r.aronium && r.total === 500));
  // A day with no till balance.
  const n = E.addEod(mgr, { shopCode: 'S1', date: '2026-10-05', zNumber: '95', total: 800, vat: 80 });
  assert.strictEqual(n.state, 'no_till');
  assert.ok(tillAlerts(owner).some((a) => a.id === 'till-eod-missing' && a.level === 'urgent'));
  throws(() => E.resolveEod(owner, n.uid, { explanation: 'x' }), /no till balance/);
  // The till balance arrives: matched (Z 95 typed as "0095"), agrees.
  T.saveTillCount(owner, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-05', shift: 'Full day', cashierUid: mere.uid, openingFloat: 100, cashCounted: 900, zCash: 800, zTotal: 800, zNumber: '0095', floatKept: 100 }, { photos: ['x'] });
  assert.strictEqual(E.getEod(n.uid).state, 'matched');
});

test('Aronium CSV with Z numbers: one End of day per Z; whole-day figures match the whole day', () => {
  const csv = 'Date,Z number,Total,Tax\n09/10/2026,102,62.00,6\n';
  const r = F.readAroniumCsv(csv, 'sales');
  assert.strictEqual(r.rows[0].z, '102');
  const b = F.addAroniumBatch(mgr, { kind: 'sales', shopCode: 'S1', rows: r.rows });
  const a = F.approveBatch(owner, b);
  assert.strictEqual(a.booked, 0);
  const e = E.listEods({ shopCode: 'S1', from: '2026-10-09', to: '2026-10-09' }).find((x) => x.z_number === '102');
  assert.strictEqual(e.state, 'difference', 'afternoon till says 60');
  assert.deepStrictEqual(e.count_uids, [shortCount.uid]);
  // Whole-day figure (no Z) for S2 on 8 Oct: the Night count (100).
  const w = E.addEod(owner, { shopCode: 'S2', date: '2026-10-08', total: 100 });
  assert.strictEqual(w.state, 'matched');
  // Voiding the till balance: the End of day has no till balance again.
  const cnt = w.count_uids[0];
  T.voidTillCount(owner, cnt, 'counted twice');
  assert.strictEqual(E.getEod(w.uid).state, 'no_till');
});

test('who owes us: Aronium staff credit CSV matched to staff, plus advances and charges; ageing', () => {
  const csv = 'Customer;Balance;Oldest\nMere Tuilau;120,50;01/07/2026\nSAM KUMAR;40;\nVisitor Joe;10;\n';
  const r = O.readCreditCsv(csv);
  assert.deepStrictEqual(r.errors, []);
  assert.strictEqual(r.rows[0].userUid, mere.uid);
  assert.strictEqual(r.rows[1].userUid, sam.uid, 'case does not matter');
  assert.strictEqual(r.rows[2].userUid, null);
  O.importStaffCredit(mgr, { asOf: '2026-10-09', rows: r.rows, fileName: 'credit.csv' });
  P.giveDebt(owner, { userUid: mere.uid, kind: 'advance', amount: 50, repayPerPay: 25, reason: 'Bus', shopCode: 'S1', paidFrom: 'cash', date: '2026-10-01' });
  const list = O.whoOwesUs({ today: '2026-10-09' });
  const m = list.find((p) => p.userUid === mere.uid);
  assert.strictEqual(m.credit, 120.5);
  assert.strictEqual(m.advances, 50);
  assert.strictEqual(m.total, 170.5);
  assert.strictEqual(m.ageing.over90, 120.5, 'oldest unpaid 1 July');
  assert.strictEqual(m.ageing.d30, 50);
  const s = list.find((p) => p.userUid === sam.uid);
  assert.strictEqual(s.tillShort, 15, 'the agreed 30 was cancelled when re-opened; the manager decided 15');
});

test('credit limits: amber when approaching, red over; Home warnings and a notification', () => {
  O.saveOwedRules(owner, { approachingPct: 80, defaultLimit: 100 });
  O.setCreditLimit(owner, sam.uid, 45);
  const list = O.whoOwesUs();
  assert.strictEqual(list.find((p) => p.userUid === mere.uid).level, 'over');
  assert.strictEqual(list.find((p) => p.userUid === sam.uid).level, 'approaching');
  const al = owedAlerts(owner);
  assert.ok(al.some((a) => a.id === 'owed-over' && a.level === 'urgent'));
  assert.ok(al.some((a) => a.id === 'owed-near' && a.level === 'warning'));
  assert.ok(V.recentAlerts().some((a) => /Mere Tuilau is OVER the staff credit limit/.test(a.text)));
  const n = V.recentAlerts().length;
  O.checkCreditLimits(owner);
  assert.strictEqual(V.recentAlerts().length, n, 'notified once per change');
  assert.strictEqual(O.creditLevel(10, 0), 'ok', 'no limit');
});

test('pay day: each staff credit deduction needs the Aronium settlement receipt photo', () => {
  const ch = P.chargeStaff(owner, { userUid: mere.uid, amount: 40, perPay: 20, reason: 'Groceries on credit', source: 'staff_credit', date: '2026-10-08', photos: ['file:///a.jpg'] });
  db().run("INSERT INTO pay_runs (uid, week_start, week_end, pay_date, status, updated_at) VALUES ('RUN1','2026-10-03','2026-10-09','2026-10-10','final','x')");
  db().run(`INSERT INTO pay_lines (uid, run_uid, user_uid, name, deductions, include, gross, net, updated_at) VALUES ('RUN1|m','RUN1',?, 'Mere Tuilau', ?, 1, 300, 280, 'x')`,
    [mere.uid, JSON.stringify([{ label: 'Staff credit', amount: 20, debtUid: ch, kind: 'staff_credit' }])]);
  const due = O.settlementsDue();
  assert.strictEqual(due.length, 1);
  assert.strictEqual(due[0].amount, 20);
  assert.ok(owedAlerts(owner).some((a) => a.id === 'owed-receipts'));
  throws(() => O.addSettlement(mgr, { ...due[0], receiptNo: 'R55' }), /photo/);
  O.addSettlement(mgr, { ...due[0], receiptNo: 'R55', photos: ['file:///r.jpg'] });
  assert.strictEqual(O.settlementsDue().length, 0);
  assert.ok(!owedAlerts(owner).some((a) => a.id === 'owed-receipts'));
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM photos WHERE ref_type = 'credit_settle'").n, 1);
  // The person's page and statement.
  const p = O.personOwes(mere.uid);
  assert.strictEqual(p.settlements.length, 1);
  const rep = OWED_REPORTS[0].build('2026-10-01', '2026-10-09', owner, { personUid: mere.uid });
  assert.match(rep.title, /Statement – Mere Tuilau/);
  assert.ok(rep.sections.length >= 3);
  const all = OWED_REPORTS[0].build('2026-10-01', '2026-10-09', owner, {});
  assert.strictEqual(all.title, 'Who Owes Us');
});

test('dashboard: card registry, roles set by the admin, each person chooses and orders; missing data = Not set up yet', () => {
  const ids = D.listCards().map((c) => c.id);
  for (const id of ['sales', 'money', 'profit', 'owed', 'weowe', 'tax', 'stock', 'staff', 'till', 'licences', 'compliance', 'watchdog', 'drawings', 'closed']) assert.ok(ids.includes(id), id);
  const period = { from: '2026-10-01', to: '2026-10-09' };
  const all = D.buildDashboard(owner, period, 'ALL');
  assert.strictEqual(all.length, ids.length, 'owner sees every card');
  assert.ok(all.every((c) => c.title && (c.notSetUp ? c.text : c.value !== undefined)), JSON.stringify(all.filter((c) => !c.title)));
  assert.ok(all.find((c) => c.id === 'stock').notSetUp, 'no stock yet: Not set up yet');
  assert.ok(!all.find((c) => c.id === 'sales').notSetUp);
  assert.ok(!all.find((c) => c.id === 'till').notSetUp);
  const mine = D.userLayout(mgr).shown;
  assert.ok(mine.includes('sales') && !mine.includes('profit'), 'managers: limited');
  D.saveCardRoles(owner, { ...D.cardRoles(), profit: ['manager'] });
  assert.ok(D.userLayout(mgr).shown.includes('profit'));
  throws(() => D.saveCardRoles(mgr, {}), /Only the admin/);
  const o0 = D.userLayout(mgr).order;
  const i0 = o0.indexOf('till');
  D.moveCard(mgr, 'till', -1);
  const o = D.userLayout(mgr).order;
  assert.strictEqual(o.indexOf('till'), i0 - 1);
  assert.strictEqual(o[i0], o0[i0 - 1]);
  D.toggleCard(mgr, 'sales', false);
  assert.ok(!D.userLayout(mgr).shown.includes('sales'));
  assert.ok(D.userLayout(mgr).order.includes('sales'), 'hidden, still in the list to switch back on');
  // Another package adds a card; a card that throws shows "Not set up yet".
  D.registerCard({ id: 'test_boom', title: 'Boom', roles: ['manager'], build() { throw new Error('no table'); } });
  const b = D.buildCard('test_boom', period, 'ALL', mgr);
  assert.ok(b.notSetUp && b.text === 'Not set up yet');
  const s1 = D.buildDashboard(owner, period, 'S1');
  assert.ok(s1.length > 5);
});

done();
