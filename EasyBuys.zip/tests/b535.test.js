// v3.5 B5: flexible pay cycle, extra pay runs, reopen & correct a final run, FNPF / PAYE rules per person,
// deductions from other modules as their own payslip lines, payslip sections, pay sign-off (release, override,
// email / Viber), tax & statutory calendar with two proofs, month-end blocking, filing formats and the pay day report.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, getShared, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { checkWeek } from '../src/modules/timesheets/service.js';
import * as C from '../src/modules/payroll/cycle.js';
import * as P from '../src/modules/payroll/service.js';
import * as PS from '../src/modules/payroll/payslip.js';
import * as SO from '../src/modules/payroll/signoff.js';
import * as TX from '../src/modules/payroll/taxCalendar.js';
import * as FL from '../src/modules/payroll/filing.js';
import * as ST from '../src/modules/payroll/statutory.js';
import * as A from '../src/modules/accounting/service.js';
import * as D from '../src/services/dashboardCards.js';
import { alerts as payAlerts } from '../src/modules/payroll/alerts.js';
import { MENU } from '../src/modules/payroll/menu.js';
import { checkMenu } from '../src/services/menus.js';
import { REPORTS } from '../src/modules/payroll/reports.js';
import '../src/modules/payroll/cards.js';
import { test, atest, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T20:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Asha Admin', pin: '7777', role: 'admin' }, owner);
const pay = saveUser({ name: 'Pita Payroll', pin: '6666', role: 'payroll' }, owner);
const mgr = saveUser({ name: 'Mani Manager', pin: '8181', role: 'manager', shopCode: 'S1' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', shopCode: 'S2' }, owner);
const SIG = 'data:image/png;base64,iVBORw0KGgo=';
const work = (u, d, from = '08:00', to = '16:00') => { addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d} ${from}:00`, reason: 't' }); addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${d} ${to}:00`, reason: 't' }); };
P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 6, tin: '123456789', fnpfNo: 'F1', taxStatus: 'resident', payMethod: 'cash', email: 'mere@example.com' });
P.saveProfile(owner, { userUid: sam.uid, payType: 'hourly', rate: 8, tin: '', fnpfNo: '', taxStatus: 'resident', payMethod: 'cash' });

test('menu is valid and every new feature has its own item', () => {
  assert.deepStrictEqual(checkMenu({ id: 'payroll', menu: MENU }, null), []);
  const ids = MENU.flatMap((s) => s.items.map((i) => i.id));
  ['home', 'pay-signoff', 'pay-extra', 'pay-taxcal', 'pay-filing', 'pay-cycle', 'pay-signoff-settings', 'pay-taxcal-settings'].forEach((id) => assert.ok(ids.includes(id), id));
});

test('pay cycle: default Saturday–Friday paid Saturday; admin can change start day, pay day and frequency', () => {
  const p = C.payPeriod('2026-10-12');
  assert.deepStrictEqual([p.from, p.to, p.payDate], ['2026-10-10', '2026-10-16', '2026-10-17']);
  assert.strictEqual(C.previousPeriod('2026-10-12').from, '2026-10-03');
  const fort = C.payPeriod('2026-10-12', { ...C.CYCLE_DEFAULTS, frequency: 'fortnightly', anchor: '2026-10-03' });
  assert.deepStrictEqual([fort.from, fort.to, fort.days, fort.perYear], ['2026-10-03', '2026-10-16', 14, 26]);
  const mon = C.payPeriod('2026-10-12', { ...C.CYCLE_DEFAULTS, frequency: 'monthly', monthStartDay: 1, payDayAfter: 0 });
  assert.deepStrictEqual([mon.from, mon.to, mon.payDate], ['2026-10-01', '2026-10-31', '2026-10-31']);
  const monday = C.payPeriod('2026-10-12', { ...C.CYCLE_DEFAULTS, startDay: 1, payDayAfter: 2 });
  assert.deepStrictEqual([monday.from, monday.to, monday.payDate], ['2026-10-12', '2026-10-18', '2026-10-20']);
  throws(() => C.savePayCycle(owner, { frequency: 'daily' }), /how often/);
  C.savePayCycle(owner, { frequency: 'weekly', startDay: 6, payDayAfter: 1 });
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Changed the pay cycle%'"));
  assert.ok(/Saturday to Friday/.test(C.cycleWords()));
});

let run1;
test('regular run follows the cycle; fortnightly run pays two weeks with overtime per week', () => {
  ['2026-10-03', '2026-10-05', '2026-10-06'].forEach((d) => work(mere, d));
  work(sam, '2026-10-05');
  ['2026-10-03', '2026-10-05'].forEach((d) => { checkWeek(owner, mere.uid, d, 'ok'); checkWeek(owner, sam.uid, d, 'ok'); });
  run1 = P.createRun(pay, '2026-10-05');
  assert.strictEqual(run1.week_start, '2026-10-03');
  assert.strictEqual(run1.pay_date, '2026-10-10');
  assert.strictEqual(run1.run_kind, 'regular');
  const l = run1.lines.find((x) => x.user_uid === mere.uid);
  assert.strictEqual(l.hours.normal, 24);
  assert.strictEqual(l.gross, 144);
  throws(() => P.createRun(pay, '2026-10-08'), /already a pay run/);
  // A fortnightly cycle: a run for two weeks (OT limit per week, salary × 2).
  const cyc = { ...C.CYCLE_DEFAULTS, frequency: 'fortnightly', anchor: '2026-09-19' };
  const pf = C.payPeriod('2026-09-22', cyc);
  assert.strictEqual(pf.from, '2026-09-19');
  assert.strictEqual(pf.to, '2026-10-02');
  const f = P.createRun(pay, '2026-09-22', { cycle: cyc });
  assert.strictEqual(f.frequency, 'fortnightly');
  assert.strictEqual(f.week_end, '2026-10-02');
  P.voidRun(owner, f.uid); // owner: no reason needed
  assert.strictEqual(P.getRun(f.uid).status, 'void');
  throws(() => P.voidRun(pay, run1.uid, 'x'), /owner or admin/);
});

test('FNPF / PAYE per person: on/off with a note, fixed a week, % of gross, only certain kinds; only owner/admin', () => {
  throws(() => P.saveStatRule(pay, mere.uid, 'fnpf', { on: false, note: 'x' }), /owner or admin/);
  throws(() => P.saveProfile(pay, { userUid: mere.uid, payType: 'hourly', rate: 6, fnpfMember: false }), /owner or admin/);
  P.saveStatRule(owner, sam.uid, 'fnpf', { on: false, note: 'Family member – owner\'s business' });
  P.saveStatRule(owner, mere.uid, 'fnpf', { on: true, mode: 'fixed', amount: 100 });
  P.recalcRun(pay, run1.uid);
  let r = P.getRun(run1.uid);
  let m = r.lines.find((x) => x.user_uid === mere.uid);
  let s = r.lines.find((x) => x.user_uid === sam.uid);
  assert.strictEqual(m.fnpf_base, 100);
  assert.strictEqual(m.fnpf_employee, 8);
  assert.strictEqual(m.counted.fnpf.words, 'Fixed $100.00 a week');
  assert.strictEqual(s.fnpf_employee, 0);
  assert.ok(/Not counted – Family member/.test(s.counted.fnpf.words));
  assert.ok(!s.warnings.includes('No FNPF number'), 'no FNPF number needed when FNPF is off');
  P.saveStatRule(owner, mere.uid, 'fnpf', { on: true, mode: 'pct', pct: 50 });
  P.saveStatRule(admin, mere.uid, 'paye', { on: true, mode: 'kinds', kinds: ['bonus'] });
  P.editLine(pay, m.uid, { adjustments: [{ label: 'Bonus', amount: 50 }], reason: 'Good month' });
  r = P.getRun(run1.uid);
  m = r.lines.find((x) => x.user_uid === mere.uid);
  assert.strictEqual(m.gross, 194);
  assert.strictEqual(m.fnpf_base, 97);
  assert.strictEqual(m.taxable, 50, 'only the bonus counts for PAYE');
  assert.strictEqual(m.adjustments[0].kind, 'bonus');
  P.saveStatRule(owner, mere.uid, 'fnpf', { on: true, mode: 'all' });
  P.saveStatRule(owner, mere.uid, 'paye', { on: true, mode: 'all' });
  P.saveStatRule(owner, sam.uid, 'paye', { on: false, note: 'Earns under the threshold – checked with FRCS' });
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'FNPF for Sam Kumar: Not counted%'"));
});

test('deductions from other modules are their own payslip lines; undecided till shortages are red', () => {
  P.chargeStaff(owner, { userUid: mere.uid, amount: 12, reason: 'Till short S1 Till 1 Morning 2026-10-05 – agreed by the cashier', source: 'till_short', date: '2026-10-05' });
  P.chargeStaff(owner, { userUid: mere.uid, amount: 20, perPay: 10, reason: 'Aronium staff credit', source: 'staff_credit', date: '2026-10-05', photos: ['file:///r.jpg'] });
  db().run(`INSERT INTO till_shortages (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, created_at, updated_at) VALUES ('TS-1','TC-1','S1','2026-10-06',?, 'Mere Tuilau', 7.5, 'waiting', '2026-10-06', '2026-10-06')`, [mere.uid]);
  P.recalcRun(pay, run1.uid);
  const m = P.getRun(run1.uid).lines.find((x) => x.user_uid === mere.uid);
  const till = m.deductions.find((d) => d.kind === 'till_short');
  const credit = m.deductions.find((d) => d.kind === 'staff_credit');
  assert.ok(till && till.highlight && till.amount === 12);
  assert.ok(credit && credit.highlight && credit.amount === 10);
  assert.strictEqual(m.undecided.length, 1);
  assert.strictEqual(m.undecided[0].amount, 7.5);
  assert.strictEqual(P.getRun(run1.uid).totals.undecided, 1);
  const secs = PS.payslipSections(m);
  const ded = secs.find((x) => x.key === 'deductions');
  assert.ok(ded.lines.some((x) => x.key === `ded_${till.debtUid}` && x.tone === 'highlight'));
  assert.ok(ded.lines.some((x) => x.key === `ded_${credit.debtUid}`));
});

test('payslip sections have stable keys; report and Viber text come from them', () => {
  const m = P.getRun(run1.uid).lines.find((x) => x.user_uid === mere.uid);
  const secs = PS.payslipSections(m.uid);
  const keys = secs.map((x) => x.key);
  ['header', 'hours', 'earnings', 'gross', 'deductions', 'net', 'counted', 'employer', 'ytd', 'signoff'].forEach((k) => assert.ok(keys.includes(k), k));
  keys.forEach((k) => assert.ok(PS.PAYSLIP_SECTION_KEYS.includes(k)));
  const counted = secs.find((x) => x.key === 'counted');
  assert.deepStrictEqual(counted.lines.map((x) => x.key), ['fnpf_counted', 'paye_counted']);
  assert.strictEqual(secs.find((x) => x.key === 'net').lines[0].amount, m.net);
  const rep = PS.payslipReport(m.uid);
  assert.ok(rep.sections.some((x) => x.key === 'counted' && x.rows[0].item === 'Pay counted for FNPF'));
  assert.ok(/Pay counted for PAYE/.test(PS.payslipText(m.uid)));
  const all = REPORTS.find((x) => x.id === 'payslips').build('2026-10-05');
  assert.strictEqual(all.sections.length, 2);
});

test('pay sign-off: not signed = not released; sign or "something is wrong"; override recorded; email / Viber', () => {
  const r = P.finaliseRun(pay, run1.uid);
  assert.strictEqual(r.status, 'final');
  assert.ok(SO.canRunSignoff(mgr) && SO.canRunSignoff(pay) && !SO.canRunSignoff(mere));
  let slips = SO.runSlips(run1.uid);
  assert.ok(slips.every((x) => !x.released && x.state === 'to_sign'));
  assert.strictEqual(SO.signoffSummary().waiting, 2);
  assert.ok(payAlerts(owner).some((a) => a.id === 'pay-sign-wait'));
  throws(() => SO.sendPayslipEmail(pay, run1.uid, mere.uid), /once it is signed/);
  SO.signPayslip(mgr, { runUid: run1.uid, userUid: sam.uid, status: 'query', note: 'My Monday hours are missing' });
  assert.strictEqual(SO.slipState(run1.uid, sam.uid).state, 'query');
  assert.ok(!SO.slipState(run1.uid, sam.uid).released);
  assert.ok(payAlerts(owner).some((a) => a.id === 'pay-sign-query'));
  setShared('pay_signoff_rules', { ...SO.signoffRules(), sendMode: 'auto' });
  const res = SO.signPayslip(mgr, { runUid: run1.uid, userUid: mere.uid, signature: SIG });
  assert.ok(res.released && res.signed);
  assert.strictEqual(res.delivery.email, 'mere@example.com');
  const after = SO.afterSigned(mgr, run1.uid, mere.uid);
  assert.strictEqual(after.emailed, 'mere@example.com');
  const mail = db().get("SELECT payload FROM outbox WHERE kind = 'payslip_email'");
  assert.ok(mail && JSON.parse(mail.payload).to === 'mere@example.com');
  const v = SO.viberShare(run1.uid, mere.uid);
  assert.ok(/^viber:\/\/forward\?text=/.test(v.url) && /NET PAY/.test(v.text));
  SO.markViberShared(mgr, run1.uid, mere.uid);
  throws(() => SO.releaseWithoutSignature(mgr, { runUid: run1.uid, userUid: sam.uid, reason: 'x' }), /owner or admin/);
  SO.releaseWithoutSignature(owner, { runUid: run1.uid, userUid: sam.uid });
  assert.strictEqual(SO.slipState(run1.uid, sam.uid).released, true);
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Released pay of Sam Kumar%without a signature%'"));
  slips = SO.runSlips(run1.uid);
  assert.ok(slips.every((x) => x.released));
  throws(() => SO.saveSignoffRules(pay, { roles: ['staff'] }), /owner or admin/);
  const saved = SO.saveSignoffRules(owner, { roles: ['payroll'], sendMode: 'ask' });
  assert.deepStrictEqual(saved.roles.sort(), ['admin', 'owner', 'payroll']);
  assert.ok(!SO.canRunSignoff(mgr));
  const list = REPORTS.find((x) => x.id === 'pay_list').build('2026-10-05');
  assert.ok(list.sections[1].rows.some((x) => x.rel === 'signed'));
});

test('reopen a final run (owner/admin, logged): corrected, everyone signs again, payslip re-issued', () => {
  throws(() => P.reopenRun(pay, run1.uid, 'wrong'), /owner or admin/);
  P.reopenRun(owner, run1.uid);
  let r = P.getRun(run1.uid);
  assert.strictEqual(r.status, 'draft');
  assert.strictEqual(r.version, 2);
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Reopened pay run 2026-10-03%'"));
  const m = r.lines.find((x) => x.user_uid === mere.uid);
  P.editLine(admin, m.uid, { normal: 25, reason: 'Hours corrected' });
  r = P.finaliseRun(admin, run1.uid);
  assert.strictEqual(r.version, 2);
  const st = SO.slipState(run1.uid, mere.uid);
  assert.ok(!st.released && st.state === 'to_sign', 'the corrected payslip must be signed again');
  assert.ok(PS.payslipSections(m.uid).some((x) => x.key === 'correction'));
  SO.signPayslip(mgr, { runUid: run1.uid, userUid: mere.uid, signature: SIG });
  assert.ok(SO.slipState(run1.uid, mere.uid).released);
});

test('extra pay run: bonus / back pay only, PAYE on top of the regular pay', () => {
  throws(() => P.createExtraRun(pay, { label: 'Christmas bonus', payDate: '2026-12-19', people: [] }), /at least one/);
  const x = P.createExtraRun(pay, { label: 'Christmas bonus', payDate: '2026-12-19', people: [{ userUid: mere.uid, amount: 100 }, { userUid: sam.uid, amount: 40, kind: 'backpay', label: 'Back pay Sept' }] });
  assert.strictEqual(x.run_kind, 'extra');
  const m = x.lines.find((l) => l.user_uid === mere.uid);
  assert.strictEqual(m.gross, 100);
  assert.deepStrictEqual(m.earnings, {});
  assert.strictEqual(m.adjustments[0].kind, 'bonus');
  assert.ok(!m.deductions.some((d) => d.debtUid), 'staff charges are not taken from an extra run unless asked');
  const s = x.lines.find((l) => l.user_uid === sam.uid);
  assert.strictEqual(s.adjustments[0].kind, 'backpay');
  assert.strictEqual(s.paye, 0, 'PAYE is off for Sam');
  // A regular run for the same dates is still possible (extra runs do not block it).
  P.finaliseRun(pay, x.uid);
  assert.strictEqual(P.listRuns().filter((r) => r.run_kind === 'extra').length, 1);
});

test('tax calendar: due rules, two proofs, flags, overdue, override, history; only owner/admin change rules', () => {
  throws(() => TX.saveTaxRules(pay, TX.taxRules()), /owner or admin/);
  const rules = TX.taxRules();
  TX.saveTaxRules(owner, { ...rules, startYm: '2026-09', vat: { ...rules.vat, responsibleUid: pay.uid, lead: 10 }, payday: { ...rules.payday, afterDays: 7 } });
  assert.strictEqual(getShared('stat_rules', {}).fnpfDueDay, 0);
  let cal = TX.taxCalendar({ today: '2026-10-12' });
  const vat = cal.find((i) => i.kind === 'vat' && i.period === '2026-09');
  assert.strictEqual(vat.due, '2026-10-31');
  assert.ok(vat.flags.includes('upcoming'));
  const pd = cal.find((i) => i.kind === 'payday' && i.period === '2026-10-10');
  assert.ok(pd && pd.due === '2026-10-17' && !pd.needPay);
  // Paid but not lodged → red. Then the lodgement without a photo → proof missing (amber).
  TX.recordTaxPaymentProof(pay, 'vat', '2026-09', { date: '2026-10-12', amount: 500, ref: 'BSP 1234' });
  let it = TX.getTaxItem('vat', '2026-09', '2026-10-12');
  assert.ok(it.flags.includes('paid_not_lodged') && it.red);
  TX.recordLodgement(pay, 'vat', '2026-09', { date: '2026-10-12', ref: 'FRCS-778' });
  it = TX.getTaxItem('vat', '2026-09', '2026-10-12');
  assert.deepStrictEqual(it.flags, ['proof_missing']);
  assert.strictEqual(it.level, 'warning');
  TX.addTaxProof(pay, 'vat', '2026-09', 'lodge', ['file:///lodge.jpg']);
  TX.addTaxProof(pay, 'vat', '2026-09', 'pay', ['file:///pay.jpg']);
  it = TX.getTaxItem('vat', '2026-09', '2026-10-12');
  assert.ok(it.done && it.state === 'done');
  assert.ok(TX.taxItemHistory('vat', '2026-09').length >= 4);
  // Lodged but not paid → red; overdue after the due date → urgent.
  TX.recordLodgement(pay, 'fnpf', '2026-10', { date: '2026-11-02', ref: 'SCHED-1', photos: ['file:///s.jpg'], due: '2026-11-30' });
  it = TX.getTaxItem('fnpf', '2026-10', '2026-12-05');
  assert.ok(it.flags.includes('lodged_not_paid') && it.flags.includes('overdue') && it.level === 'urgent');
  // The pay day report is lodgement only.
  it = TX.getTaxItem('payday', '2026-10-10', '2026-10-20');
  assert.ok(it.flags.includes('overdue'));
  assert.ok(TX.taxAlerts(owner, '2026-10-20').some((a) => a.level === 'urgent' && /Pay day report/.test(a.text)));
  // Responsible person: the VAT warnings go to Pita (payroll) and the owner, not to the manager.
  const vatOct = { kind: 'vat', responsibleUid: pay.uid };
  assert.ok(TX.seesTaxItem(pay, vatOct) && TX.seesTaxItem(owner, vatOct) && !TX.seesTaxItem(mgr, vatOct));
  // Not needed (VAT refund month) and taking back by mistake.
  TX.markNotNeeded(owner, 'vat', '2026-10', 'pay', 'Refund month');
  assert.ok(!TX.getTaxItem('vat', '2026-10', '2026-11-05').needPay);
  TX.undoTaxProof(owner, 'vat', '2026-09', 'pay');
  assert.ok(!TX.getTaxItem('vat', '2026-09', '2026-10-12').done);
  throws(() => TX.overrideTaxItem(pay, 'vat', '2026-09', 'x'), /owner or admin/);
  TX.overrideTaxItem(owner, 'vat', '2026-09');
  it = TX.getTaxItem('vat', '2026-09', '2026-10-12');
  assert.ok(it.done && it.override && it.state === 'override');
});

test('payments recorded in FNPF & PAYE payments count, but still need their proof photo', () => {
  ST.prepareMonth('2026-10');
  const accounts = db().all('SELECT uid FROM bank_accounts');
  const acc = accounts.length ? accounts[0].uid : null;
  if (acc) {
    ST.payStat(owner, 'STAT-paye-2026-10', { date: '2026-11-10', amount: 1, method: 'transfer', accountUid: acc, reference: 'BSP-PAYE' });
    const it = TX.getTaxItem('paye', '2026-10', '2026-11-12');
    assert.ok(it.paid && !it.payProof && it.flags.includes('proof_missing'));
    TX.addTaxProof(owner, 'paye', '2026-10', 'pay', ['file:///paye.jpg']);
    assert.ok(TX.getTaxItem('paye', '2026-10', '2026-11-12').payProof);
  } else {
    ST.payStat(owner, 'STAT-paye-2026-10', { date: '2026-11-10', amount: 1, method: 'cash', receiptNo: 'R1' });
    const it = TX.getTaxItem('paye', '2026-10', '2026-11-12');
    assert.ok(it.paid && it.flags.includes('proof_missing'));
  }
});

test('month-end checklist waits for both proofs; owner/admin can override', () => {
  let me = A.monthEndChecklist('2026-09');
  const v = me.auto.find((a) => a.key === 'tax_vat_2026-09');
  assert.ok(v && v.done, 'VAT 2026-09 was accepted by the owner');
  me = A.monthEndChecklist('2026-10');
  const pd = me.auto.find((a) => a.key === 'tax_payday_2026-10-10');
  assert.ok(pd && !pd.done);
  assert.ok(!me.ready);
  TX.overrideTaxItem(admin, 'payday', '2026-10-10', 'Filed by the accountant');
  assert.ok(A.monthEndChecklist('2026-10').auto.find((a) => a.key === 'tax_payday_2026-10-10').done);
});

test('dashboard card: tax deadlines', () => {
  assert.ok(D.getCard('taxcal'));
  const c = D.buildCard('taxcal', { from: '2026-10-01', to: '2026-10-31' }, 'ALL', owner);
  assert.ok(!c.error, c.text);
  assert.ok(c.value);
  assert.ok(D.cardAllowed(pay, 'taxcal') && !D.cardAllowed(mgr, 'taxcal'));
});

test('filing: pre-filing checks, own layout until a template is uploaded, then the template columns', () => {
  const checks = FL.filingChecks('paye', '2026-10');
  assert.ok(checks.some((c) => /employer TIN/.test(c.text)));
  const tab0 = FL.filingTable('fnpf', '2026-10');
  assert.ok(!tab0.template && tab0.headers.includes('FNPF number'));
  const fnpfRows = FL.filingRows('fnpf', '2026-10');
  assert.ok(fnpfRows.every((r) => r.userUid !== sam.uid), 'Sam does not pay FNPF');
  // Upload: headers from a CSV template, guessed mapping, fixed text.
  const headers = FL.templateHeaders('Employer Reg No,Member No,Member Name,Total Wages,Employee Contribution,Employer Contribution,Remarks\n');
  assert.strictEqual(headers.length, 7);
  const g = FL.guessMapping(headers);
  assert.strictEqual(g['Member No'].field, 'fnpf_no');
  assert.strictEqual(g['Employee Contribution'].field, 'fnpf_employee');
  assert.strictEqual(g['Employer Contribution'].field, 'fnpf_employer');
  throws(() => FL.saveFilingTemplate(pay, 'fnpf', { headers, mapping: g }), /owner or admin/);
  FL.saveEmployerDetails(owner, { name: 'Easy Buys Shopping Centre', tin: '50-12345-0-1', fnpfNo: 'E-998' });
  FL.saveFilingTemplate(owner, 'fnpf', { name: 'FNPF schedule 2026', headers, mapping: { ...g, 'Employer Reg No': { field: 'employer_fnpf' }, 'Total Wages': { field: 'fnpf_wages' }, Remarks: { fixed: 'Weekly' } } });
  const tab = FL.filingTable('fnpf', '2026-10');
  assert.deepStrictEqual(tab.headers, headers);
  assert.strictEqual(tab.rows[0][0], 'E-998');
  assert.strictEqual(tab.rows[0][6], 'Weekly');
  const csv = FL.tableCsv(tab.headers, tab.rows);
  assert.ok(csv.startsWith('Employer Reg No,Member No'));
  const rep = FL.filingReport('fnpf', '2026-10');
  assert.ok(rep.sections[0].title === 'Checks before filing' && rep.sections[1].columns.length === 7);
  FL.removeFilingTemplate(owner, 'fnpf');
  assert.ok(!FL.filingTemplate('fnpf'));
  assert.deepStrictEqual(FL.parseCsv('a,"b,c",d\n1,2,3'), [['a', 'b,c', 'd'], ['1', '2', '3']]);
});

await atest('weekly pay day report: both shops separately and together', async () => {
  const rep = FL.payDayReport('2026-10-10');
  assert.strictEqual(rep.sections[0].title, 'Both shops together');
  const shops = rep.sections[0].rows.map((r) => r.shop);
  assert.deepStrictEqual(shops, ['S1', 'S2', 'ALL SHOPS']);
  assert.ok(rep.sections.some((s) => s.title === 'Shop S2'));
  const b64 = await FL.tableXlsxBase64(['A', 'B'], [[1, 'x']]);
  assert.strictEqual(typeof b64, 'string');
});

done();
