// v3.5 B6: loans, rent, personal costs and drawings – easy setup, loan details, repayments with receipts, missed
// payments and arrears fees, interest worked out by the app, the loan journey (split, balance, payoff), checking a loan
// against the lender statement with one-tap fixes, closed shop costs, owner's money (take out / paid for me / put in,
// business share with VAT), personal reminders, totals and statements, warnings and menus.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import { CLOSED } from '../src/services/costAreas.js';
import { visibleMenu } from '../src/services/menus.js';
import * as AP from '../src/modules/payables/service.js';
import * as REC from '../src/modules/payables/recurring.js';
import * as T from '../src/modules/till/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as S from '../src/modules/accounting/statements.js';
import * as L from '../src/modules/loans/service.js';
import * as D from '../src/modules/drawings/service.js';
import { alerts as loanAlerts } from '../src/modules/loans/alerts.js';
import { alerts as ownAlerts } from '../src/modules/drawings/alerts.js';
import { REPORTS as LOAN_REPORTS } from '../src/modules/loans/reports.js';
import { REPORTS as OWN_REPORTS } from '../src/modules/drawings/reports.js';
import { MENU as LOAN_MENU } from '../src/modules/loans/menu.js';
import { MENU as OWN_MENU } from '../src/modules/drawings/menu.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (d) => { clock.override = new Date(`${d}T10:00:00`); };
at('2026-03-20');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 0, openingDate: '2025-12-31' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100, lastNo: 149 });
const tbOk = (d = '2026-12-31') => { const tb = A.trialBalance(d); assert.ok(tb.ok, `TB ${tb.dr} / ${tb.cr}`); return Object.fromEntries(tb.rows.map((r) => [r.code, r.balance])); };
const pay = (inv, date, chq) => AP.makePayment(owner, { supplierUid: inv.supplier_uid, method: 'cheque', accountUid: acct.uid, chequeNo: chq, payDate: date, allocations: [{ invoiceUid: inv.uid, amount: inv.total }] });
const inv = (uid, due) => AP.getInvoice(`RI-${uid}-${due}`);

test('permissions: owner/admin get loans and owner\'s money; a manager does not', () => {
  assert.ok(can(owner, 'loans_manage') && can(owner, 'drawings') && can(owner, 'drawings_setup'));
  assert.ok(!can(mgr, 'loans_manage') && !can(mgr, 'drawings'));
  const m = visibleMenu({ id: 'loans', menu: LOAN_MENU }, owner, null).flatMap((s) => s.items.map((i) => i.id));
  assert.ok(['home', 'loan-receipts', 'loan-journey', 'loan-recon', 'loan-setup', 'loan-rules', 'loan-reports'].every((x) => m.includes(x)), m.join());
  const o = visibleMenu({ id: 'drawings', menu: OWN_MENU }, owner, null).flatMap((s) => s.items.map((i) => i.id));
  assert.ok(['home', 'own-out', 'own-paid', 'own-in', 'own-reminders', 'own-list', 'own-settings'].every((x) => o.includes(x)), o.join());
});

let vmp; let rent; let car;
test('easy setup: nothing real filled in; lenders added by name; V M Pillay loan and rent go to the closed shop', () => {
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_recurring').n, 0, 'nothing seeded');
  const st = L.setupStatus();
  assert.strictEqual(st.length, 8);
  assert.ok(st.every((s) => !s.done));
  assert.strictEqual(st.find((s) => s.key === 'loan_vmp').shopCode, CLOSED);
  assert.strictEqual(st.find((s) => s.key === 'car_pb113').vehicle, 'PB 113');
  const bsp = L.ensureLender(owner, 'BSP Loans');
  assert.strictEqual(L.ensureLender(owner, 'bsp loans').uid, bsp.uid, 'same lender, not twice');
  throws(() => L.saveRegular(owner, { kind: 'loan', name: 'X', supplierUid: bsp.uid, amount: 500, frequency: 'monthly', nextDate: '2026-01-31', openingBalance: 100, openingDate: '2025-12-31', purpose: 'rent' }), /kind of loan/);
  throws(() => L.saveRegular(owner, { kind: 'loan', name: 'X', supplierUid: bsp.uid, amount: 500, frequency: 'monthly', nextDate: '2026-01-31', openingBalance: 100, openingDate: '2025-12-31', purpose: 'shop_loan', arrearsRule: 'pct', arrearsValue: '' }), /arrears fee/);
  throws(() => L.saveRegular(owner, { kind: 'loan', name: 'X', supplierUid: bsp.uid, amount: 500, frequency: 'monthly', nextDate: '2026-01-31', openingBalance: 100, openingDate: '2025-12-31', purpose: 'shop_loan', interestAuto: true }), /interest rate/);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_recurring').n, 0, 'a failed save leaves nothing half-saved');
  vmp = L.saveRegular(owner, { kind: 'loan', template: 'loan_vmp', name: 'V M Pillay (closed shop) – business loan', supplierUid: bsp.uid, amount: 500, frequency: 'monthly', nextDate: '2026-01-31', leadDays: 7, shopCode: CLOSED,
    loanNo: 'BL-9', openingBalance: 10000, openingDate: '2025-12-31', interestRate: 12, purpose: 'shop_loan', price: 12000, deposit: 2500, startFees: 500, arrearsRule: 'fixed', arrearsValue: 25, interestAuto: true }).uid;
  const t = L.getTerms(vmp);
  assert.strictEqual(t.principal, 10000, 'amount borrowed = price − deposit + fees');
  assert.ok(t.interest_auto && t.receipt_required && t.template === 'loan_vmp');
  const landlord = L.ensureLender(owner, 'Pillay Holdings');
  rent = L.saveRegular(owner, { kind: 'bill', template: 'rent_vmp', name: 'V M Pillay (closed shop) – rent', supplierUid: landlord.uid, amount: 1125, vatType: 'standard', frequency: 'monthly', nextDate: '2026-02-01', leadDays: 5, shopCode: CLOSED, category: 'Rent', purpose: 'rent' }).uid;
  const cc = L.ensureLender(owner, 'Credit Corp');
  car = L.saveRegular(owner, { kind: 'loan', template: 'car_pb113', name: 'Car loan PB 113 – Credit Corp', supplierUid: cc.uid, amount: 50, frequency: 'monthly', nextDate: '2026-04-15', openingBalance: 20000, openingDate: '2026-03-01', interestRate: 10, purpose: 'car_loan', vehicle: 'PB 113' }).uid;
  const st2 = L.setupStatus();
  assert.ok(st2.find((s) => s.key === 'loan_vmp').done && st2.find((s) => s.key === 'rent_vmp').done && st2.find((s) => s.key === 'car_pb113').done);
  assert.ok(!st2.find((s) => s.key === 'loan_s1').done);
});

test('repayments: bills made before they are due; one paid, one missed → arrears, arrears fee by the rule (once)', () => {
  REC.runRecurring(owner, '2026-03-20');
  const jan = inv(vmp, '2026-01-31');
  const feb = inv(vmp, '2026-02-28');
  assert.ok(jan && feb, 'repayment bills for Jan and Feb');
  assert.ok(!inv(vmp, '2026-03-31'), 'March not yet (7 days before)');
  pay(jan, '2026-01-31', 100);
  const j = L.loanJourney(vmp);
  assert.strictEqual(j.missed.length, 1);
  assert.strictEqual(j.arrears, 500);
  assert.strictEqual(j.suggestedFee, 25);
  assert.ok(j.lines.some((l) => l.kind === 'missed' && /MISSED/.test(l.what)));
  assert.strictEqual(L.addArrearsFee(owner, vmp), 25);
  throws(() => L.addArrearsFee(owner, vmp), /already/);
  assert.strictEqual(L.loanJourney(vmp).totals.fees, 25);
});

test('interest worked out by the app on each due date (once, on any device), split into each repayment', () => {
  const n = L.runLoanInterest(null, '2026-03-20');
  assert.strictEqual(n, 2);
  assert.strictEqual(L.runLoanInterest(null, '2026-03-20'), 0, 'not twice');
  const e = db().all("SELECT * FROM loan_entries WHERE uid LIKE ? ORDER BY entry_date", [`LI-${vmp}-%`]);
  assert.strictEqual(e[0].amount, Math.round(10000 * 12 * 31 / 365) / 100, 'Jan: 31 days on 10,000 at 12%');
  const j = L.loanJourney(vmp);
  const p = j.lines.find((l) => l.kind === 'payment');
  assert.strictEqual(p.interest, e[0].amount, 'the January repayment pays the January interest first');
  assert.strictEqual(p.principal, Math.round((500 - e[0].amount) * 100) / 100);
  assert.strictEqual(p.balance, Math.round((10000 + e[0].amount - 500) * 100) / 100, 'balance after the line');
  assert.strictEqual(j.balance, Math.round((10000 + e[0].amount + e[1].amount + 25 - 500) * 100) / 100);
  assert.ok(j.payoffDate > '2027-06-01', `paid off ${j.payoffDate}`);
  assert.strictEqual(j.plan.points[j.plan.points.length - 1].balance, 0);
  assert.ok(j.chart.length > 3 && j.chart.some((c) => c.planned) && j.chart.some((c) => !c.planned));
  assert.ok(j.lines.some((l) => l.what === 'Amount borrowed' && l.amount === 10000) && j.lines.some((l) => l.what === 'Deposit paid'));
  // In the books: the loan's own account, interest in the closed shop column.
  const b = tbOk();
  assert.strictEqual(-b[`2500:${vmp}`], Math.round((10000 + e[0].amount + e[1].amount + 25 - 1000) * 100) / 100, 'books: both bills (invoice basis)');
});

test('a car loan whose repayment does not cover the interest is never paid off', () => {
  const j = L.loanJourney(car);
  assert.ok(j.neverPaysOff && !j.payoffDate);
  assert.strictEqual(j.areaLabel, 'Office', 'car loans: whole business');
});

test('receipts: a payment without a receipt photo is flagged; the photo is required', () => {
  const miss = L.missingReceipts('2026-03-20');
  assert.strictEqual(miss.length, 1);
  assert.strictEqual(miss[0].recurring_uid, vmp);
  throws(() => L.addReceipt(owner, { recurringUid: vmp, paymentUid: miss[0].payment_uid, receiptNo: 'R-77', photos: [] }), /photo/);
  L.addReceipt(owner, { recurringUid: vmp, paymentUid: miss[0].payment_uid, invoiceUid: miss[0].invoice_uid, receiptNo: 'R-77', date: '2026-01-31', photos: ['file:///r77.jpg'] });
  assert.strictEqual(L.missingReceipts('2026-03-20').length, 0);
  const p = L.loanJourney(vmp).lines.find((l) => l.kind === 'payment');
  assert.ok(p.hasPhoto && p.receiptNo === 'R-77');
  assert.ok(db().get("SELECT 1 AS x FROM photos WHERE ref_type = 'regreceipt'"), 'photo queued for Google Drive');
  // Rent paid, no receipt → flagged too
  const r = inv(rent, '2026-02-01');
  pay(r, '2026-02-02', 101);
  assert.strictEqual(L.missingReceipts('2026-03-20').length, 1);
});

test('lender statement check: compare, one-tap fixes as loan entries, agreed, last checked date', () => {
  const j = L.loanJourney(vmp);
  const before = j.balance;
  assert.ok(j.reconDue, 'never checked and older than 60 days');
  throws(() => L.reconCompare(vmp, { statementDate: '2026-03-15' }), /balance/);
  // Lender: interest 5 more than the app, fees 10 more, and 20 more on the balance besides.
  const ours = L.reconCompare(vmp, { statementDate: '2026-03-15', balance: 0 }).ours;
  const c = L.reconCompare(vmp, { statementDate: '2026-03-15', balance: ours.balance + 35, interest: ours.interest + 5, fees: ours.fees + 10 });
  assert.strictEqual(c.diff, 35);
  assert.deepStrictEqual(c.fixes.map((f) => [f.key, f.type, f.amount]), [['interest', 'interest', 5], ['fees', 'fee', 10], ['balance', 'adjust_up', 20]]);
  const half = L.saveRecon(owner, vmp, { statementDate: '2026-03-15', balance: ours.balance + 35, interest: ours.interest + 5, fees: ours.fees + 10 }, { apply: ['interest'] });
  assert.strictEqual(half.status, 'open');
  assert.strictEqual(half.diff, 30);
  assert.strictEqual(L.lastRecon(vmp), null);
  const c2 = L.reconCompare(vmp, { statementDate: '2026-03-15', balance: ours.balance + 35, interest: ours.interest + 5, fees: ours.fees + 10 });
  assert.deepStrictEqual(c2.fixes.map((f) => f.key), ['fees', 'balance'], 'interest already fixed');
  const ok = L.saveRecon(owner, vmp, { statementDate: '2026-03-15', balance: ours.balance + 35, interest: ours.interest + 5, fees: ours.fees + 10 }, { apply: ['fees', 'balance'] });
  assert.strictEqual(ok.status, 'agreed');
  assert.strictEqual(L.lastRecon(vmp).statement_date, '2026-03-15');
  const j2 = L.loanJourney(vmp);
  assert.strictEqual(j2.balance, Math.round((before + 35) * 100) / 100);
  assert.strictEqual(j2.lastReconciled, '2026-03-15');
  assert.ok(!j2.reconDue);
  // Statement shows less: take off
  const c3 = L.reconCompare(vmp, { statementDate: '2026-03-20', balance: j2.balance - 12 });
  assert.strictEqual(c3.fixes[0].type, 'adjust_down');
  assert.ok(/repayment/.test(c3.fixes[0].hint));
  tbOk();
});

test('closed shop costs: V M Pillay rent and loan interest only in the closed shop line, never Shop 1 or 2', () => {
  const pl = A.profitLoss({ from: '2026-01-01', to: '2026-03-31', shops: ['S1', 'S2'] });
  const rentRow = pl.rows.find((r) => r.code === '6000');
  assert.strictEqual(rentRow.by[CLOSED], 2000, 'rent ex VAT, Feb and Mar');
  assert.ok(!rentRow.by.S1 && !rentRow.by.S2);
  const intRow = pl.rows.find((r) => r.code === '6700');
  assert.ok(intRow.by[CLOSED] > 180 && !intRow.by.S1 && !intRow.by.OFFICE);
  const cc = L.closedShopCosts({ from: '2026-01-01', to: '2026-03-31' });
  assert.strictEqual(cc.total, pl.per[CLOSED].expenses - pl.per[CLOSED].income + pl.per[CLOSED].cogs);
  assert.ok(cc.byAccount.Rent === 2000);
  const rep = LOAN_REPORTS.find((r) => r.id === 'closed_shop_costs').build('2026-01-01', '2026-03-31');
  assert.ok(rep.sections[1].rows.length >= 3);
});

test('overview and warnings: missed repayment is urgent and taps to the loan journey; receipts missing; due soon', () => {
  const ov = L.regularOverview('2026-03-20');
  const v = ov.find((r) => r.uid === vmp);
  assert.ok(v.closed && v.overdue === 1 && v.noReceipt === 0 && v.balance > 0);
  const a = loanAlerts(owner);
  const missed = a.find((x) => x.id === `loan-missed-${vmp}`);
  assert.ok(missed && missed.level === 'urgent' && missed.nav.screen === 'LoanJourney' && missed.nav.params.uid === vmp);
  assert.ok(a.some((x) => x.id === 'loan-receipts' && x.level === 'warning'));
  for (const x of a) assert.ok(x.id && x.text && ['urgent', 'warning', 'info'].includes(x.level) && x.nav && x.nav.screen);
  assert.deepStrictEqual(loanAlerts(saveUser({ name: 'Mere Staff', pin: '4321', role: 'staff' }, owner)), []);
  for (const r of LOAN_REPORTS) { const out = r.build('2026-01-01', '2026-03-31'); assert.ok(out.title && out.sections.length, r.id); }
  const jr = LOAN_REPORTS.find((r) => r.id === 'loan_journeys').build('2026-01-01', '2026-03-31');
  assert.ok(jr.sections[1].rows.some((x) => x.receipt === 'R-77'));
  // A due-soon reminder for the car loan
  at('2026-04-12');
  assert.ok(loanAlerts(owner).some((x) => x.id.startsWith(`loan-due-${car}`)));
  at('2026-03-20');
});

// ---------------------------------------------------------------- owner's money
const vatReturnInput = () => A.vatReturn({ ym: '2026-03' }).purchases.input;
test("owner's money settings: one owner, or several family members (admin)", () => {
  assert.deepStrictEqual(D.memberOptions().map((m) => m.value), ['owner']);
  throws(() => D.saveDrawingsRules(owner, { perMember: true, members: [] }), /at least one/);
  throws(() => D.saveDrawingsRules(owner, { perMember: true, members: [{ name: 'Divnesh' }, { name: 'divnesh' }] }), /same name/);
  D.saveDrawingsRules(owner, { perMember: true, members: [{ id: 'DV', name: 'Divnesh' }, { id: 'SM', name: 'Sumintra' }] });
  assert.deepStrictEqual(D.memberOptions().map((m) => m.label), ['Divnesh', 'Sumintra']);
});

let takeUid;
test('take money out (cash from Shop 1): drawings, shop cash goes down, booked once', () => {
  const cashBefore = T.cashOnHand('S1', '2026-03-20').onHand;
  throws(() => D.saveMove(owner, { kind: 'take_out', amount: 200, via: 'cash:S1' }), /who/);
  const m = D.saveMove(owner, { kind: 'take_out', date: '2026-03-20', amount: 200, memberId: 'DV', via: 'cash:S1' });
  takeUid = m.uid;
  assert.strictEqual(Math.round((cashBefore - T.cashOnHand('S1', '2026-03-20').onHand) * 100) / 100, 200, 'cash on hand at Shop 1');
  const b = tbOk();
  assert.strictEqual(b['3100'], 200);
  const s1 = A.balances({ to: '2026-12-31', shop: 'S1' }).find((r) => r.code === '1000');
  assert.strictEqual(s1.balance, -200, 'cash in the books: once, not twice');
  assert.ok(!A.profitLoss({ from: '2026-03-01', to: '2026-03-31', shops: ['S1'] }).rows.some((r) => r.code === '6900'), 'not a cash correction expense');
});

test('business paid for me: mixed cost with a business share % – business part to costs with VAT (with TIN), the rest drawings', () => {
  const vat0 = vatReturnInput();
  throws(() => D.saveMove(owner, { kind: 'paid_for_me', amount: 225, memberId: 'SM', via: `bank:${acct.uid}` }), /what the business paid/);
  throws(() => D.saveMove(owner, { kind: 'paid_for_me', amount: 225, memberId: 'SM', via: `bank:${acct.uid}`, what: 'Phone', businessPct: 40, claimVat: true, glCode: '6020' }), /TIN/);
  const s = D.split({ total: 225, businessPct: 40, claimVat: true });
  assert.deepStrictEqual([s.business, s.vat, s.businessExVat, s.personal], [90, 10, 80, 135]);
  const m = D.saveMove(owner, { kind: 'paid_for_me', date: '2026-03-18', amount: 225, memberId: 'SM', via: `bank:${acct.uid}`, what: 'Phone bill', businessPct: 40, claimVat: true, tin: '50123450', glCode: '6020', costArea: 'S2', supplier: 'Vodafone', invoiceNo: 'V-1', photos: ['file:///v1.jpg'] });
  assert.strictEqual(m.business_amount, 90); assert.strictEqual(m.personal_amount, 135); assert.strictEqual(m.vat, 10);
  assert.strictEqual(Math.round((vatReturnInput() - vat0) * 100) / 100, 10, 'VAT on the business part is in the VAT return');
  const pl = A.profitLoss({ from: '2026-03-01', to: '2026-03-31', shops: ['S1', 'S2'] });
  assert.strictEqual(pl.rows.find((r) => r.code === '6020').by.S2, 80);
  assert.ok(db().get("SELECT 1 AS x FROM bank_entries WHERE uid LIKE ? AND amount = 225", [`BE-JN-${m.journal_uid}%`]), 'one bank line for the bank reconciliation');
  // All personal (0%): only drawings
  const g = D.saveMove(owner, { kind: 'paid_for_me', date: '2026-03-19', amount: 150, memberId: 'DV', via: 'cash:S1', what: 'Groceries' });
  assert.strictEqual(g.business_amount, 0); assert.strictEqual(g.personal_amount, 150);
  const b = tbOk();
  assert.strictEqual(b['3100'], 200 + 135 + 150);
});

test('put money in: money into the bank, or a business cost paid from own pocket (business part only)', () => {
  D.saveMove(owner, { kind: 'put_in', date: '2026-03-19', amount: 1000, memberId: 'DV', via: `bank:${acct.uid}` });
  throws(() => D.saveMove(owner, { kind: 'put_in', how: 'paid_bill', amount: 100, memberId: 'DV', businessPct: 0, what: 'x' }), /business share/);
  const p = D.saveMove(owner, { kind: 'put_in', how: 'paid_bill', date: '2026-03-19', amount: 300, memberId: 'SM', businessPct: 50, what: 'Fuel', glCode: '6040' });
  assert.strictEqual(p.business_amount, 150);
  const s = D.drawingsSummary({ from: '2026-03-01', to: '2026-03-31' });
  assert.strictEqual(s.takenOut, 200); assert.strictEqual(s.paidForMe, 285); assert.strictEqual(s.putIn, 1150);
  const dv = s.byMember.find((x) => x.id === 'DV'); const sm = s.byMember.find((x) => x.id === 'SM');
  assert.deepStrictEqual([dv.takenOut, dv.paidForMe, dv.putIn, dv.net], [200, 150, 1000, -650]);
  assert.deepStrictEqual([sm.paidForMe, sm.putIn, sm.businessShare], [135, 150, 240]);
  assert.strictEqual(D.drawingsSummary('thismonth').count, 5, 'period by name');
  const b = tbOk();
  assert.strictEqual(b['3100'], 485 - 1150);
});

test('statements: money put in and drawings on their own lines; statement report per person; never payroll', () => {
  const fs = S.financialStatements(2026);
  const eq = fs.sections.find((x) => x.title === 'Statement of changes in equity').rows;
  assert.strictEqual(eq.find((r) => r.item === "Owner's money put in").v, '1150.00');
  assert.strictEqual(eq.find((r) => /^Drawings taken out/.test(r.item)).v, '-485.00');
  const rep = OWN_REPORTS[0].build('2026-03-01', '2026-03-31');
  assert.strictEqual(rep.sections[0].rows.length, 2);
  assert.ok(rep.sections[1].rows.some((r) => r.receipt === 'MISSING'), 'groceries paid by the business, no receipt photo');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM sqlite_master WHERE name = 'pay_lines'").n ? db().get('SELECT COUNT(*) AS n FROM pay_lines').n : 0, 0, 'nothing went through payroll');
});

test('put aside a wrong record: journal and shop cash put aside too, history kept', () => {
  const cashBefore = T.cashOnHand('S1', '2026-03-20').onHand;
  D.voidMove(owner, takeUid, 'Typed twice');
  assert.strictEqual(D.getMove(takeUid).status, 'void');
  assert.strictEqual(Math.round((T.cashOnHand('S1', '2026-03-20').onHand - cashBefore) * 100) / 100, 200);
  assert.strictEqual(D.drawingsSummary({ from: '2026-03-01', to: '2026-03-31' }).takenOut, 0);
  assert.strictEqual(tbOk()['3100'], 285 - 1150);
  throws(() => D.voidMove(owner, takeUid, 'again'), /Not found/);
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE record_uid = ? AND action LIKE 'Put aside%'", [takeUid]));
});

test('personal reminders: home rent and groceries – not a business cost; paid by the business = drawings', () => {
  const home = D.savePersonal(owner, { name: 'Home rent', kind: 'home_rent', amount: 800, frequency: 'monthly', nextDate: '2026-03-21', leadDays: 3, memberId: 'DV', paidBy: 'business', via: `bank:${acct.uid}` });
  const groc = D.savePersonal(owner, { name: 'Groceries', kind: 'groceries', frequency: 'weekly', nextDate: '2026-03-28', leadDays: 1, memberId: 'SM', paidBy: 'own' });
  assert.deepStrictEqual(D.personalDue('2026-03-20').map((p) => p.uid), [home.uid]);
  const a = ownAlerts(owner);
  assert.ok(a.some((x) => x.id === `own-due-${home.uid}-2026-03-21` && x.nav.screen === 'PersonalReminders'));
  assert.deepStrictEqual(ownAlerts(mgr), []);
  throws(() => D.markPersonalDone(owner, home.uid, { date: '2026-03-21' }), /receipt/);
  const r = D.markPersonalDone(owner, home.uid, { date: '2026-03-21', photos: ['file:///rent.jpg'] });
  assert.strictEqual(r.next, '2026-04-21');
  assert.strictEqual(r.move.kind, 'paid_for_me'); assert.strictEqual(r.move.personal_amount, 800); assert.strictEqual(r.move.business_amount, 0);
  assert.ok(!A.profitLoss({ from: '2026-03-01', to: '2026-03-31', shops: [] }).rows.some((x) => x.code === '6000' && x.by.OFFICE), 'home rent is not a business cost');
  const g = D.markPersonalDone(owner, groc.uid, { date: '2026-03-28', amount: 120 });
  assert.strictEqual(g.move, null, 'paid privately: nothing in the books');
  assert.strictEqual(g.next, '2026-04-04');
  assert.strictEqual(D.skipPersonal(owner, groc.uid), '2026-04-11');
  tbOk();
});

done();
