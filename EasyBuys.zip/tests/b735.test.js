// v3.5 B7: licences as the business's safeguard, vehicles & equipment (register, due items, faults with out-of-use
// time, service history, fuel entered once goes everywhere, daily checks off by default, running costs) and the bakery
// changes (no own sign-on, proofing table, temperature adjustment).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import { visibleMenu } from '../src/services/menus.js';
import * as AP from '../src/modules/payables/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as W from '../src/modules/bank/wallets.js';
import * as V from '../src/modules/vehicles/service.js';
import { alerts as veAlerts } from '../src/modules/vehicles/alerts.js';
import { REPORTS as VE_REPORTS } from '../src/modules/vehicles/reports.js';
import { MENU as VE_MENU } from '../src/modules/vehicles/menu.js';
import * as L from '../src/modules/licences/service.js';
import * as D from '../src/services/documents.js';
import { alerts as licAlerts } from '../src/modules/licences/alerts.js';
import { REPORTS as LIC_REPORTS } from '../src/modules/licences/reports.js';
import { buildCard, getCard } from '../src/services/dashboardCards.js';
import '../src/modules/licences/cards.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (d, t = '10:00:00') => { clock.override = new Date(`${d}T${t}`); };
at('2026-10-01');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const baker = saveUser({ name: 'Mere Baker', pin: '7777', role: 'worker' }, owner);
const staff = saveUser({ name: 'Sam Staff', pin: '6666', role: 'staff' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 0, openingDate: '2025-12-31' });

// ================================================================ vehicles & equipment
let van; let oven;
test('vehicles: permissions and menu', () => {
  assert.ok(can(owner, 'vehicles_manage') && can(mgr, 'vehicles_use') && !can(mgr, 'vehicles_manage'));
  assert.ok(V.canView(baker) && V.bakeryOnly(baker) && !V.canUse(baker), 'bakers see the bakery equipment and report faults');
  assert.ok(!V.canView(staff));
  const ids = visibleMenu({ id: 'vehicles', menu: VE_MENU }, owner, null).flatMap((s) => s.items.map((i) => i.id));
  assert.ok(['home', 've-fuel', 've-fault', 've-due', 've-work', 've-faults', 've-fuellog', 've-reports', 've-add', 've-types', 've-rules'].every((x) => ids.includes(x)), ids.join());
  assert.ok(!ids.includes('ve-check'), 'daily checks are off by default');
});

test('register: rego required, no duplicate rego, type defaults add the due items', () => {
  throws(() => V.saveItem(mgr, { kind: 'vehicle', name: 'Van', rego: 'PB 113' }), /owner or admin/);
  throws(() => V.saveItem(owner, { kind: 'vehicle', name: 'Van' }), /registration number/);
  van = V.saveItem(owner, { kind: 'vehicle', name: 'Delivery van', typeKey: 'van', rego: 'pb 113', km: 50000, tankL: 70, area: 'S1', lastServiceDate: '2026-06-01' });
  throws(() => V.saveItem(owner, { kind: 'vehicle', name: 'Other', rego: 'PB113' }), /already in the register/);
  const v = V.getItem(van);
  assert.strictEqual(v.rego, 'PB 113');
  assert.strictEqual(v.meter, 'km');
  assert.deepStrictEqual(v.due.map((d) => d.name).sort(), ['Registration (LTA)', 'Service', 'Tyres & wheel alignment']);
  const svc = v.due.find((d) => d.name === 'Service');
  assert.strictEqual(svc.next_km, 55000);
  assert.strictEqual(svc.next_date, '2026-11-28');
  assert.strictEqual(svc.state, 'ok');
  oven = V.saveItem(owner, { kind: 'equipment', name: 'Oven 2', typeKey: 'oven', lastServiceDate: '2026-06-15' });
  assert.ok(V.getItem(oven).in_bakery, 'ovens are bakery equipment by default');
  assert.strictEqual(V.getItem(oven).due[0].state, 'overdue', '90 days from 15 June has passed');
});

test('types: admin-editable with intervals', () => {
  throws(() => V.saveTypes(mgr, V.listTypes()), /owner or admin/);
  const t = V.listTypes().map((x) => (x.key === 'van' ? { ...x, due: [{ name: 'Service', every_km: 7500, every_days: 180 }, { name: 'Registration (LTA)', every_days: 365 }] } : x));
  t.push({ label: 'Forklift', kind: 'equipment', meter: 'hours', due: [{ name: 'Service', every_hours: 250 }] });
  V.saveTypes(owner, t);
  assert.strictEqual(V.typeOf('van').due[0].every_km, 7500);
  assert.strictEqual(V.typeOf('forklift').meter, 'hours');
  throws(() => V.saveTypes(owner, [{ label: 'X' }, { label: 'X' }]), /listed twice/);
});

test('due by km: reminders inside the window, overdue after', () => {
  const svc = () => V.getItem(van).due.find((d) => d.name === 'Service');
  db().run('UPDATE ve_items SET km = 54600 WHERE uid = ?', [van]);
  assert.strictEqual(svc().state, 'due', '400 km left, reminder from 500 km');
  db().run('UPDATE ve_items SET km = 55100 WHERE uid = ?', [van]);
  assert.strictEqual(svc().state, 'overdue');
  const a = veAlerts(owner);
  assert.ok(a.some((x) => x.level === 'urgent' && /Delivery van/.test(x.text) && /Service/.test(x.text) && x.nav.screen === 'VeItem'));
  assert.ok(a.some((x) => /Oven 2/.test(x.text)));
  assert.strictEqual(veAlerts(staff).length, 0);
});

test('service done: resets the due item from the reading; cost linked to the supplier invoice', () => {
  const sup = AP.saveSupplier ? AP.saveSupplier(owner, { name: 'Lautoka Motors' }) : null;
  let invUid = null;
  if (sup) {
    const inv = AP.saveInvoice(owner, { supplierUid: sup.uid || sup, invoiceNo: 'LM-55', invoiceDate: '2026-10-01', total: 345, vat: 38.33, category: 'Repairs', shopCode: 'S1' }, { canCheck: true });
    invUid = inv.uid || inv;
  }
  throws(() => V.recordWork(owner, { itemUid: van, kind: 'service', note: '' }), /Describe/);
  throws(() => V.recordWork(staff, { itemUid: van, kind: 'service', note: 'x' }), /not allowed/);
  const w = V.recordWork(mgr, { itemUid: van, kind: 'service', note: 'Oil and filters', km: 55200, invoiceUid: invUid || undefined, cost: invUid ? undefined : 345, invoiceNo: invUid ? undefined : 'LM-55' });
  const row = db().get('SELECT * FROM ve_work WHERE uid = ?', [w]);
  assert.strictEqual(row.cost, 345);
  assert.strictEqual(row.invoice_no, 'LM-55');
  const svc = V.getItem(van).due.find((d) => d.name === 'Service');
  assert.strictEqual(svc.last_km, 55200);
  assert.strictEqual(svc.next_km, 55200 + 5000);
  assert.strictEqual(svc.state, 'ok');
  assert.strictEqual(V.getItem(van).km, 55200, 'odometer moved on');
});

test('faults: out-of-use time counted until back in use; a repair closes it; bakery faults also raise a bakery alert', () => {
  at('2026-10-02', '08:00:00');
  const f = V.reportFault(baker, { itemUid: oven, note: 'Top deck not heating', outOfUse: true });
  assert.ok(db().get("SELECT 1 AS x FROM alerts WHERE type = 'FAULT' AND message LIKE '%Top deck%'"), 'bakery alert raised');
  assert.ok(V.getItem(oven).outOfUse);
  at('2026-10-02', '11:30:00');
  assert.strictEqual(V.listFaults({ itemUid: oven })[0].minutesOut, 210);
  assert.ok(veAlerts(owner).some((x) => /out of use/.test(x.text)));
  V.recordWork(mgr, { itemUid: oven, kind: 'repair', note: 'Element replaced', cost: 120, date: '2026-10-02' });
  const ff = db().get('SELECT * FROM ve_faults WHERE uid = ?', [f]);
  assert.strictEqual(ff.status, 'fixed');
  assert.ok(ff.back_at);
  assert.ok(!V.getItem(oven).outOfUse);
  assert.strictEqual(V.outOfUseMinutes(ff), 210);
});

let firstFuel;
test('fuel entered once goes everywhere: expense Transport & fuel for the shop, input VAT, cash / M-PAiSA / bank', () => {
  at('2026-10-03');
  throws(() => V.saveFuel(owner, { itemUid: oven, km: 1, litres: 1, amount: 1, via: 'cash:S1' }), /Choose the vehicle/);
  throws(() => V.saveFuel(owner, { itemUid: van, km: '', litres: 40, amount: 100, via: 'cash:S1' }), /odometer/);
  throws(() => V.saveFuel(owner, { itemUid: van, km: 55300, litres: 40, amount: 100 }), /money came from/);
  const opts = V.paidFromOptions();
  assert.ok(opts.some((o) => o.value === 'cash:S1') && opts.some((o) => o.value === 'mpaisa:WAL-MPAISA-S1') && opts.some((o) => o.value === `bank:${acct.uid}`), JSON.stringify(opts));
  firstFuel = V.saveFuel(owner, { itemUid: van, km: 55300, litres: 60, amount: 168.75, via: 'cash:S1', supplier: 'Total Drasa', receiptNo: 'T1' });
  const j = db().get('SELECT * FROM gl_journals WHERE ref_uid = ?', [firstFuel.uid]);
  const lines = JSON.parse(j.lines);
  assert.ok(lines.some((l) => l.code === '6040' && l.debit === 150 && l.shop === 'S1'), 'Transport & fuel ex VAT for Shop 1');
  assert.ok(lines.some((l) => l.code === '2200' && l.debit === 18.75), 'input VAT');
  assert.ok(lines.some((l) => l.code === '1000' && l.credit === 168.75 && l.shop === 'S1'), 'out of Shop 1 cash');
  const vr = A.vatReturn({ ym: '2026-10' });
  assert.ok(vr.purchases.input >= 18.75, 'input VAT in the VAT return');
  // M-PAiSA wallet: the wallet's balance goes down
  const before = W.walletPosition('WAL-MPAISA-S1', '2026-10-31').balance;
  at('2026-10-06');
  const f2 = V.saveFuel(mgr, { itemUid: van, km: 55900, litres: 50, amount: 140.63, via: 'mpaisa:WAL-MPAISA-S1', taxInvoice: false });
  assert.strictEqual(db().get('SELECT vat FROM ve_fuel WHERE uid = ?', [f2.uid]).vat, 0, 'no tax invoice, no VAT');
  assert.strictEqual(f2.kmPerL, 12, '600 km on 50 L');
  assert.strictEqual(Math.round((before - W.walletPosition('WAL-MPAISA-S1', '2026-10-31').balance) * 100) / 100, 140.63);
  assert.ok(W.walletHistory('WAL-MPAISA-S1').rows.some((r) => r.what === 'Paid from the wallet'));
  // Bank: appears in the bank reconciliation
  at('2026-10-09');
  const f3 = V.saveFuel(owner, { itemUid: van, km: 56500, litres: 52, amount: 150, via: `bank:${acct.uid}` });
  const j3 = db().get('SELECT uid FROM gl_journals WHERE ref_uid = ?', [f3.uid]).uid;
  assert.ok(db().get("SELECT 1 AS x FROM bank_entries WHERE uid LIKE ? AND status = 'active'", [`BE-JN-${j3}%`]), 'bank line for the reconciliation');
  const tb = A.trialBalance('2026-12-31');
  assert.ok(tb.ok, 'books balance');
});

test('fuel flags: km going back, much worse km/L, more than the tank holds; voiding reverses everything', () => {
  at('2026-10-10');
  const bad = V.saveFuel(owner, { itemUid: van, km: 56800, litres: 75, amount: 210, via: 'mpaisa:WAL-MPAISA-S1' });
  const keys = bad.flags.map((f) => f.key);
  assert.ok(keys.includes('tank'), keys.join());
  assert.ok(keys.includes('low'), `4 km/L vs ~11.7 usual: ${keys.join()}`);
  const back = V.saveFuel(owner, { itemUid: van, km: 56000, litres: 10, amount: 30, via: 'cash:S1', fullTank: false });
  assert.ok(back.flags.some((f) => f.key === 'km_back'));
  assert.ok(V.listFuel({ flagged: true }).length >= 2);
  const bal = W.walletPosition('WAL-MPAISA-S1', '2026-10-31').balance;
  throws(() => V.voidFuel(mgr, bad.uid, ''), /Say why/);
  V.voidFuel(owner, bad.uid, 'Typed twice');
  assert.strictEqual(db().get('SELECT status FROM gl_journals WHERE ref_uid = ?', [bad.uid]).status, 'void');
  assert.strictEqual(Math.round((W.walletPosition('WAL-MPAISA-S1', '2026-10-31').balance - bal) * 100) / 100, 210, 'wallet back');
  V.voidFuel(owner, back.uid, 'wrong');
});

test('daily checks: built but off; switched on they are asked for and a "not OK" becomes a fault', () => {
  throws(() => V.saveCheck(mgr, { itemUid: van, answers: {} }), /switched off/);
  assert.ok(!veAlerts(owner).some((a) => /daily check/.test(a.text)));
  V.saveVeRules(owner, { dailyChecksOn: true });
  assert.ok(veAlerts(owner).some((a) => /No daily check yet today for Delivery van/.test(a.text)));
  const answers = Object.fromEntries(V.veRules().checkItems.map((k) => [k, true]));
  throws(() => V.saveCheck(mgr, { itemUid: van, answers: { ...answers, Brakes: false } }), /Say what is wrong/);
  V.saveCheck(mgr, { itemUid: van, answers: { ...answers, Brakes: false }, note: 'Soft pedal' });
  assert.ok(V.checkedToday(van));
  assert.ok(V.listFaults({ itemUid: van, status: 'open' }).some((f) => /Brakes/.test(f.note)));
  V.saveVeRules(owner, { dailyChecksOn: false });
  throws(() => V.saveVeRules(mgr, { dailyChecksOn: true }), /owner or admin/);
});

test('running costs and reports; links to loan / fixed asset / insurance; archive keeps history', () => {
  const rc = V.runningCosts('2026-10-01', '2026-10-31');
  const r = rc.rows.find((x) => x.uid === van);
  assert.strictEqual(r.fills, 3);
  assert.strictEqual(r.work, 345);
  assert.ok(r.km >= 1200 && r.perKm > 0);
  assert.strictEqual(rc.rows.find((x) => x.uid === oven).hoursOut, 3.5);
  for (const rep of VE_REPORTS) {
    const out = rep.build('2026-10-01', '2026-10-31', owner, {});
    assert.ok(out.title && out.sections.length && out.sections[0].rows.length, rep.id);
  }
  const lo = V.linkOptions();
  assert.ok(Array.isArray(lo.loans) && Array.isArray(lo.assets) && Array.isArray(lo.insurance));
  throws(() => V.archiveItem(mgr, oven, 'x'), /owner or admin/);
  V.archiveItem(owner, oven, 'Replaced');
  assert.ok(!V.listItems({}).some((i) => i.uid === oven));
  assert.strictEqual(V.listWork({ itemUid: oven }).length, 1, 'history kept');
});

test('the bakery\'s old equipment list moves into the register once', () => {
  db().run("INSERT INTO equipment (name, service_days, last_service_at, active, created_at) VALUES ('Mixer A', 30, '2026-09-01 08:00:00', 1, '2026-01-01 08:00:00')");
  const eid = db().get("SELECT id FROM equipment WHERE name = 'Mixer A'").id;
  db().run("INSERT INTO equipment_log (equipment_id, type, note, user_id, at) VALUES (?, 'fault', 'Belt slipping', ?, '2026-10-01 09:00:00')", [eid, baker.id]);
  // a fresh start (as after an update) migrates it
  const conn = db();
  V.__resetMigration && V.__resetMigration();
  V.ensureVe();
  const m = V.listItems({ bakery: true }).find((i) => i.name === 'Mixer A');
  assert.ok(m, 'migrated');
  assert.strictEqual(m.openFaults.length, 1);
  assert.strictEqual(m.due[0].every_days, 30);
  V.__resetMigration && V.__resetMigration();
  V.ensureVe();
  assert.strictEqual(V.listItems({ bakery: true }).filter((i) => i.name === 'Mixer A').length, 1, 'only once');
  assert.ok(conn);
});

// ================================================================ licences as the safeguard
const admin = saveUser({ name: 'Ana Admin', pin: '5917', role: 'admin' }, owner);
const mgr2 = saveUser({ name: 'Raj Manager', pin: '4829', role: 'manager', shopCode: 'S2' }, owner);
let liq; let fire;
test('licences: only the owner or admin add or change; responsible person + backup, owner by default', () => {
  at('2026-10-10');
  throws(() => L.saveLicence(mgr, { name: 'X', category: 'liquor' }), /owner or admin/);
  liq = L.saveLicence(admin, { name: 'Liquor licence', category: 'liquor', shopCode: 'S2', licenceNo: 'LL-1', issuedDate: '2025-12-31', expiryDate: '2026-12-31', remindDays: 90, renewMonths: 12,
    responsibleUid: mgr.uid, backupUid: mgr2.uid, conditionItems: [{ text: 'Licence displayed at the entrance', tick: true }, { text: 'No sales after 10 pm' }] });
  throws(() => L.saveLicence(owner, { name: 'Y', category: 'fire', responsibleUid: mgr.uid, backupUid: mgr.uid }), /someone else/);
  fire = L.saveLicence(owner, { name: 'Fire certificate', category: 'fire', shopCode: 'S1', issuedDate: '2025-10-15', expiryDate: '2026-10-15' });
  const p = L.peopleFor(L.getLicence(liq));
  assert.strictEqual(p.responsible.name, 'Anita Manager');
  assert.strictEqual(p.backup.name, 'Raj Manager');
  const pf = L.peopleFor(L.getLicence(fire));
  assert.ok(pf.isDefault && pf.responsible.name === 'Divnesh Prasad', 'the owner by default');
  assert.ok(L.canEditLicences(owner) && L.canEditLicences(admin) && !L.canEditLicences(mgr));
  throws(() => L.recordNote(mgr, liq, { kind: 'note', note: 'x' }), /owner or admin/);
});

test('escalating reminders: responsible + backup from 90 days, owner from 30, urgent from 7, expired daily to every manager', () => {
  // liquor: 82 days left → step 90: Anita and Raj told (info); not the owner, not other managers
  const lv = (u) => licAlerts(u).filter((a) => /Liquor/.test(a.text) && !/copy/.test(a.text));
  assert.strictEqual(lv(mgr).length, 1);
  assert.strictEqual(lv(mgr)[0].level, 'info');
  assert.strictEqual(lv(mgr2).length, 1);
  assert.strictEqual(lv(owner).filter((a) => /expires/.test(a.text)).length, 0, 'owner not yet');
  at('2026-12-01'); // 30 days
  assert.strictEqual(lv(owner).filter((a) => /expires/.test(a.text))[0].level, 'warning', 'owner from 30 days');
  at('2026-12-26'); // 5 days
  assert.strictEqual(lv(mgr)[0].level, 'urgent', 'urgent from 7 days');
  assert.strictEqual(L.reminderStep(L.getLicence(liq), '2026-12-26'), 7);
  assert.strictEqual(L.reminderStep(L.getLicence(liq), '2026-12-30'), 1);
  at('2027-01-03');
  const e1 = lv(admin);
  assert.ok(e1.length && e1[0].level === 'urgent' && /EXPIRED/.test(e1[0].text), 'expired: every manager/admin');
  assert.ok(lv(mgr2).some((a) => /EXPIRED/.test(a.text)));
  at('2027-01-04');
  assert.notStrictEqual(lv(admin)[0].id, e1[0].id, 'a new warning (and sound) every day');
  assert.strictEqual(licAlerts(staff).length, 0);
  at('2026-10-10');
});

test('renewal: checklist per licence type, then the owner signs it off', () => {
  L.startRenewal(admin, liq, { date: '2026-10-10', refNo: 'APP-1' });
  const c = L.checklistFor(L.getLicence(liq));
  assert.deepStrictEqual(c.items.map((x) => x.text), L.CHECKLIST_DEFAULTS.liquor);
  throws(() => L.tickChecklist(mgr2 && saveUser({ name: 'Other Sup', pin: '3746', role: 'supervisor' }, owner), liq, 0), /person looking after it/);
  L.tickChecklist(mgr, liq, 0);
  L.tickChecklist(mgr2, liq, 1);
  assert.strictEqual(L.checklistFor(L.getLicence(liq)).items.filter((x) => x.done_at).length, 2);
  L.saveLicenceChecklists(owner, { fire: 'Book NFA inspection\nCertificate displayed' });
  assert.deepStrictEqual(L.checklistTemplate('fire'), ['Book NFA inspection', 'Certificate displayed']);
  throws(() => L.saveLicenceChecklists(mgr, {}), /owner or admin/);
  L.finishRenewal(admin, liq, {});
  assert.strictEqual(L.getLicence(liq).signoff_pending, 1);
  assert.ok(licAlerts(owner).some((a) => /sign it off/.test(a.text)));
  throws(() => L.signOffRenewal(admin, liq), /Only the owner/);
  L.signOffRenewal(owner, liq);
  assert.strictEqual(L.getLicence(liq).signoff_pending, 0);
  const ev = L.eventsFor(liq).find((e) => e.kind === 'renewed');
  assert.strictEqual(ev.signed_by, 'Divnesh Prasad');
  throws(() => L.signOffRenewal(owner, liq), /Nothing is waiting/);
});

test('document safe: "No current copy" until a copy issued on/after the current licence is added; nothing deleted', () => {
  assert.ok(L.listLicences({}).find((l) => l.uid === liq).noCopy);
  D.recordDocument(admin, { refType: 'licence', refUid: liq, kind: 'licence_copy', name: 'Licence 2026', path: 'file:///a.jpg', docDate: '2026-01-05' });
  assert.ok(L.listLicences({}).find((l) => l.uid === liq).noCopy, 'old copy: the renewed licence was issued today');
  const d = D.recordDocument(admin, { refType: 'licence', refUid: liq, kind: 'licence_copy', name: 'Licence 2027', path: 'file:///b.jpg' });
  assert.ok(!L.listLicences({}).find((l) => l.uid === liq).noCopy);
  D.archiveDocument(owner, d, 'wrong file');
  assert.ok(L.listLicences({}).find((l) => l.uid === liq).noCopy);
  assert.strictEqual(D.listDocuments('licence', liq, { all: true }).length, 2, 'kept');
  D.recordDocument(admin, { refType: 'licence', refUid: liq, kind: 'licence_copy', name: 'Licence 2027 (right one)', path: 'file:///c.jpg' });
});

test('conditions with optional ticks; anyone who can see licences may tick', () => {
  const conds = L.conditionsFor(L.getLicence(liq));
  assert.strictEqual(conds.length, 2);
  throws(() => L.tickCondition(mgr, liq, conds[1].id), /no tick box/);
  L.tickCondition(mgr, liq, conds[0].id);
  const c = L.conditionsFor(L.getLicence(liq))[0];
  assert.ok(c.ticked_at && c.ticked_by === 'Anita Manager');
  // changing the licence keeps the tick of an unchanged condition
  L.saveLicence(owner, { uid: liq, name: 'Liquor licence', category: 'liquor', shopCode: 'S2', expiryDate: L.getLicence(liq).expiry_date, issuedDate: L.getLicence(liq).issued_date, remindDays: 90, renewMonths: 12,
    conditionItems: L.conditionsFor(L.getLicence(liq)).concat([{ text: 'Staff over 18 serve liquor', tick: true }]) });
  assert.ok(L.conditionsFor(L.getLicence(liq))[0].ticked_at);
  assert.strictEqual(L.conditionsFor(L.getLicence(liq)).length, 3);
});

test('compliance health, dashboard cards, inspection pack per shop and the monthly compliance report', () => {
  const h = L.complianceHealth('2026-10-10');
  assert.ok(h.setUp && h.score < 100);
  assert.ok(h.problems.some((p) => p.name === 'Fire certificate' && /5 day/.test(p.text)));
  assert.ok(h.problems.some((p) => /condition/.test(p.text)), 'an unticked condition');
  assert.ok(getCard('compliance_health') && getCard('licences'));
  const card = buildCard('compliance_health', { from: '2026-10-01', to: '2026-10-31' }, 'ALL', owner);
  assert.ok(/\/ 100/.test(card.value), JSON.stringify(card));
  assert.ok(buildCard('licences', { from: '2026-10-01', to: '2026-10-31' }, 'ALL', owner).value);
  const pack = LIC_REPORTS.find((r) => r.id === 'lic_inspection_pack').build('2026-10-10', '2026-10-10', owner, { shop: 'S2' });
  assert.ok(/Shop 2|S2/.test(pack.title), pack.title);
  assert.deepStrictEqual(pack.sections[0].rows.map((r) => r.name), ['Liquor licence'], JSON.stringify(pack.sections[0].rows.map((r) => [r.name, r.for])));
  assert.ok(pack.sections[1].rows.some((r) => /entrance/.test(r.cond) && /☑/.test(r.check)));
  const s1 = LIC_REPORTS.find((r) => r.id === 'lic_inspection_pack').build('2026-10-10', '2026-10-10', owner, { shop: 'S1' });
  assert.ok(s1.sections[0].rows.some((r) => r.name === 'Fire certificate' && r.copy === 'NO CURRENT COPY'));
  const m = LIC_REPORTS.find((r) => r.id === 'lic_compliance_month').build('2026-10-01', '2026-10-31', owner, {});
  assert.ok(m.sections[2].rows.some((r) => r.what === 'Renewed' && /Divnesh/.test(r.signed)));
  assert.ok(m.sections[1].rows.some((r) => r.name.startsWith('Fire certificate')));
  L.saveLicRules(owner, { steps: '60, 30, 7', ownerFromDays: 14, urgentFromDays: 3 });
  assert.deepStrictEqual(L.licRules().steps, [60, 30, 7]);
  throws(() => L.saveLicRules(mgr, {}), /owner or admin/);
});

done();
