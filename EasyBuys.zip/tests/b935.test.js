// v3.5 B9: Roster (checks that suggest alternatives, paint/copy/swap, staff needed, undo, today/tomorrow changes told to
// staff, shareable report) and My day (scheduler, own items, app tasks from warnings and module services, not today /
// skip / done / moves, reminders and late warnings, visibility, Google Calendar in and out).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, getSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import { setAlertSources, collectAlerts, clearAlertCache } from '../src/services/alerts.js';
import { visibleMenu } from '../src/services/menus.js';
import * as R from '../src/modules/timesheets/roster.js';
import * as X from '../src/modules/timesheets/rosterPlus.js';
import * as M from '../src/modules/myday/service.js';
import * as AP from '../src/modules/payables/service.js';
import * as SC from '../src/modules/inventory/schedules.js';
import { alerts as tsAlerts } from '../src/modules/timesheets/alerts.js';
import { MENU as TS_MENU } from '../src/modules/timesheets/menu.js';
import { MENU as MD_MENU } from '../src/modules/myday/menu.js';
import { REPORTS as TS_REPORTS } from '../src/modules/timesheets/reports.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (d, t = '09:00') => { clock.override = new Date(`${d}T${t}:00`); };
at('2026-10-12'); // Monday; the pay week started Saturday 10 Oct
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9911', role: 'owner' });
const admin = saveUser({ name: 'Ravi Admin', pin: '7712', role: 'admin' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8813', role: 'manager', shopCode: 'S1' }, owner);
const asha = saveUser({ name: 'Asha', pin: '1414', role: 'staff', shopCode: 'S1' }, owner);
const ben = saveUser({ name: 'Ben', pin: '2425', role: 'staff', shopCode: 'S1' }, owner);
const cara = saveUser({ name: 'Cara', pin: '3436', role: 'staff', shopCode: 'S1' }, owner);
const ws = '2026-10-10';
const shift = (u, date, start, end, shopCode = 'S1') => R.setShift(owner, { userUid: u.uid, date, shopCode, start, end, breakMin: 0 });
const active = (u, date) => db().all("SELECT * FROM roster_shifts WHERE status = 'active' AND user_uid = ? AND shift_date = ?", [u.uid, date]);
const leave = (u, from, to, status = 'approved') => db().run(`INSERT INTO leave_requests (uid, user_uid, name, type, from_date, to_date, days, status, requested_at, updated_at, updated_device, sync_status)
  VALUES (?,?,?,?,?,?,1,?,?,?,'t','pending')`, [`L-${u.name}-${from}`, u.uid, u.name, 'ANNUAL', from, to, status, '2026-10-01 08:00:00', '2026-10-01 08:00:00']);

// ================================================================ ROSTER
test('permissions and menus: My day was removed in 3.9.4 (nobody gets it); the staff roster menus stay', () => {
  // (owner and admin can do anything; My day is simply not on Home or in any menu any more)
  assert.ok(!can(mgr, 'myday') && !can(mgr, 'myday_view'));
  assert.ok(!can(asha, 'myday') && !can(asha, 'myday_view'));
  const ts = visibleMenu({ id: 'timesheets', menu: TS_MENU }, mgr, null).flatMap((s) => s.items.map((i) => i.id));
  assert.ok(['ts-roster', 'ts-myroster', 'ts-rules'].every((x) => ts.includes(x)) || ts.includes('ts-roster'), ts.join());
});

test('rules: admin sets hour limit, rest, double shifts and staff needed per shift', () => {
  const r = X.saveRosterRules(owner, { maxWeekHours: 48, minRestHours: 10, maxShiftsPerDay: 1, needs: { S1: [{ name: 'Morning', start: '07:00', end: '15:00', count: [2, 2, 2, 2, 2, 2, 2] }, { name: 'bad', start: 'x', end: '1' }] } });
  assert.strictEqual(r.needs.S1.length, 1, 'bad slot dropped');
  throws(() => X.undo(mgr), /Nothing to undo/);
  assert.deepStrictEqual(X.rosterRules().needs.S1[0].count, [2, 2, 2, 2, 2, 2, 2]);
});

test('a plain shift is fine; colours by time of day', () => {
  const c = X.checkShift({ userUid: asha.uid, date: '2026-10-14', start: '07:00', end: '15:00', shopCode: 'S1' });
  assert.ok(c.ok, JSON.stringify(c.blocks));
  assert.strictEqual(X.shiftKind({ start_time: '07:00', end_time: '15:00' }), 'day');
  assert.strictEqual(X.shiftKind({ start_time: '06:00', end_time: '10:00' }), 'morning');
  assert.strictEqual(X.shiftKind({ start_time: '13:00', end_time: '21:00' }), 'afternoon');
  assert.strictEqual(X.shiftKind({ start_time: '17:00', end_time: '23:00' }), 'night');
});

test('leave: the shift is not made; suggests who is free, and "Allow anyway" only for owner/admin', () => {
  leave(cara, '2026-10-15', '2026-10-15');
  const r = X.planShift(mgr, { userUid: cara.uid, date: '2026-10-15', start: '07:00', end: '15:00', shopCode: 'S1' });
  assert.strictEqual(r.saved, false);
  assert.match(r.blocks[0].text, /on annual leave/i);
  assert.ok(r.suggestions.some((s) => s.kind === 'free' && s.userUid === asha.uid), JSON.stringify(r.suggestions));
  assert.ok(!r.suggestions.some((s) => s.kind === 'allow'), 'manager cannot allow anyway');
  throws(() => X.planShift(mgr, { userUid: cara.uid, date: '2026-10-15', start: '07:00', end: '15:00', shopCode: 'S1' }, { allow: true }), /Only the owner or admin/);
  const o = X.planShift(owner, { userUid: cara.uid, date: '2026-10-15', start: '07:00', end: '15:00', shopCode: 'S1' });
  assert.ok(o.suggestions.some((s) => s.kind === 'allow'));
  // Take the "Asha is free" suggestion.
  const sg = r.suggestions.find((s) => s.kind === 'free' && s.userUid === asha.uid);
  const done1 = X.applySuggestion(mgr, { userUid: cara.uid, date: '2026-10-15', start: '07:00', end: '15:00', shopCode: 'S1' }, sg);
  assert.ok(done1.saved);
  assert.strictEqual(active(asha, '2026-10-15').length, 1);
  assert.strictEqual(active(cara, '2026-10-15').length, 0);
});

test('rest between shifts: suggests moving the time and swapping with someone', () => {
  shift(asha, '2026-10-13', '14:00', '23:00');
  shift(ben, '2026-10-14', '12:00', '20:00');
  const input = { userUid: asha.uid, date: '2026-10-14', start: '06:00', end: '14:00', shopCode: 'S1' };
  const r = X.planShift(mgr, input);
  assert.strictEqual(r.saved, false);
  assert.ok(r.blocks.some((b) => b.kind === 'rest' && /7:00 rest/.test(b.text)), JSON.stringify(r.blocks));
  const mv = r.suggestions.find((s) => s.kind === 'move');
  assert.ok(mv, JSON.stringify(r.suggestions));
  assert.strictEqual(mv.start, '09:00');
  assert.strictEqual(mv.end, '17:00');
  const sw = r.suggestions.find((s) => s.kind === 'swap' && s.withUid === ben.uid);
  assert.ok(sw, 'swap with Ben');
  X.applySuggestion(mgr, input, sw);
  assert.strictEqual(active(asha, '2026-10-14')[0].start_time, '12:00');
  assert.strictEqual(active(ben, '2026-10-14')[0].start_time, '06:00');
});

test('double shift and weekly hour limit: suggestions to change the existing shift or make it shorter', () => {
  const r = X.planShift(mgr, { userUid: ben.uid, date: '2026-10-14', start: '15:00', end: '20:00', shopCode: 'S1' });
  assert.ok(r.blocks.some((b) => b.kind === 'double'));
  const rep = r.suggestions.find((s) => s.kind === 'replace');
  assert.ok(rep);
  X.saveRosterRules(owner, { ...X.rosterRules(), maxWeekHours: 20 });
  shift(cara, '2026-10-12', '07:00', '15:00');
  shift(cara, '2026-10-13', '07:00', '15:00');
  const h = X.planShift(mgr, { userUid: cara.uid, date: '2026-10-16', start: '07:00', end: '15:00', shopCode: 'S1' });
  assert.ok(h.blocks.some((b) => b.kind === 'hours' && /limit 20 hours/.test(b.text)), JSON.stringify(h.blocks));
  const short = h.suggestions.find((s) => s.kind === 'move');
  assert.deepStrictEqual([short.start, short.end], ['07:00', '11:00']);
  X.saveRosterRules(owner, { ...X.rosterRules(), maxWeekHours: 48 });
});

test('staff needed per shift: short days are warned; a day off says it leaves the shop short', () => {
  const cov = X.coverage('2026-10-12', 'S1');
  assert.deepStrictEqual(cov.map((c) => [c.need, c.have, c.short]), [[2, 1, 1]]);
  const w = X.weekWarnings(ws, { shopCode: 'S1' });
  assert.ok(w.some((x) => x.kind === 'short' && x.date === '2026-10-12'));
  shift(asha, '2026-10-12', '07:00', '15:00');
  assert.strictEqual(X.coverage('2026-10-12', 'S1')[0].short, 0);
  const off = X.dayOff(mgr, active(asha, '2026-10-12')[0].uid);
  assert.ok(off.warns.some((x) => /short: 1 of 2/.test(x.text)), JSON.stringify(off.warns));
  const check = X.checkShift({ uid: active(cara, '2026-10-12')[0].uid, userUid: cara.uid, date: '2026-10-12', start: '16:00', end: '22:00', shopCode: 'S1' });
  assert.ok(check.warns.some((x) => x.kind === 'short'), 'moving away leaves it short');
});

test('undo takes back the last change (also a copy of a day)', () => {
  const before = active(asha, '2026-10-16').length;
  X.paint(mgr, { userUid: asha.uid, date: '2026-10-16', shopCode: 'S1', brush: { start: '08:00', end: '16:00', breakMin: 30 } });
  assert.strictEqual(active(asha, '2026-10-16').length, before + 1);
  assert.match(X.undoLabel(), /Asha/);
  X.undo(mgr);
  assert.strictEqual(active(asha, '2026-10-16').length, before);
  const c = X.copyDay(mgr, { fromDate: '2026-10-13', toDates: ['2026-10-15', '2026-10-16'], shopCode: 'S1' });
  assert.ok(c.copied >= 1);
  assert.ok(c.skipped.some((s) => /Asha|Cara/.test(s.name)), JSON.stringify(c.skipped)); // Asha works the 15th already / rest
  X.undo(mgr);
  assert.strictEqual(active(cara, '2026-10-16').length, 0, 'copy undone');
});

test('paint "off" and swapping two people for the week (refused when it clashes with leave unless allowed)', () => {
  X.paint(mgr, { userUid: ben.uid, date: '2026-10-16', shopCode: 'S1', brush: { start: '07:00', end: '15:00' } });
  X.paint(mgr, { userUid: ben.uid, date: '2026-10-16', shopCode: 'S1', brush: 'off' });
  assert.strictEqual(active(ben, '2026-10-16').length, 0);
  const days = ['2026-10-12', '2026-10-13', '2026-10-14'];
  const r = X.swapPeople(mgr, { aUid: ben.uid, bUid: asha.uid, dates: days, shopCode: 'S1' });
  assert.ok(r.ok, JSON.stringify(r.blocks));
  assert.strictEqual(active(ben, '2026-10-13')[0].start_time, '14:00');
  // Cara is on leave on the 15th; swapping Asha's 15th to Cara is refused, the roster stays as it was.
  const before = active(asha, '2026-10-15').length;
  const bad = X.swapPeople(mgr, { aUid: asha.uid, bUid: cara.uid, dates: ['2026-10-15'], shopCode: 'S1' });
  assert.strictEqual(bad.ok, false);
  assert.strictEqual(bad.allowAnyway, false);
  assert.strictEqual(active(asha, '2026-10-15').length, before);
  const own = X.swapPeople(owner, { aUid: asha.uid, bUid: cara.uid, dates: ['2026-10-15'], shopCode: 'S1' });
  assert.strictEqual(own.allowAnyway, true);
  const forced = X.swapPeople(owner, { aUid: asha.uid, bUid: cara.uid, dates: ['2026-10-15'], shopCode: 'S1' }, { allow: true });
  assert.ok(forced.ok);
  X.undo(owner);
  assert.strictEqual(active(asha, '2026-10-15').length, before);
});

test('changes to today and tomorrow are logged, highlighted and staff are told until they tick "Seen"', () => {
  db().run('DELETE FROM roster_changes');
  X.planShift(mgr, { userUid: cara.uid, date: '2026-10-13', start: '08:00', end: '16:00', shopCode: 'S1', uid: active(cara, '2026-10-13')[0].uid });
  X.planShift(mgr, { userUid: cara.uid, date: '2026-10-20', start: '08:00', end: '16:00', shopCode: 'S1' }); // next week: not told
  const ch = X.recentChanges();
  assert.strictEqual(ch.length, 1);
  assert.strictEqual(ch[0].before_text, '07:00–15:00 S1');
  assert.strictEqual(ch[0].after_text, '08:00–16:00 S1');
  assert.ok(X.changedCells()[`${cara.uid}|2026-10-13`]);
  const mine = tsAlerts(cara);
  assert.ok(mine.some((a) => a.id.startsWith('roster-chg-') && a.notify && /tomorrow changed: 08:00–16:00/.test(a.text)), JSON.stringify(mine));
  assert.ok(tsAlerts(mgr).some((a) => a.id.startsWith('roster-unseen-')));
  X.markSeen(cara);
  assert.ok(!tsAlerts(cara).some((a) => a.id.startsWith('roster-chg-')));
  assert.strictEqual(db().get("SELECT sync_status FROM roster_changes LIMIT 1").sync_status, 'pending', 'synced to other devices');
});

test('shareable roster: report with every day, leave shown, in the Timesheets reports', () => {
  const rep = X.rosterReport(ws, { shopCode: 'S1' });
  assert.strictEqual(rep.sections[0].columns.length, 9);
  const c = rep.sections[0].rows.find((r) => r.name === 'Cara');
  assert.strictEqual(c['2026-10-15'], 'Leave');
  assert.strictEqual(c['2026-10-13'], '08:00–16:00');
  assert.ok(TS_REPORTS.some((r) => r.id === 'tc_roster'));
  assert.strictEqual(TS_REPORTS.find((r) => r.id === 'tc_roster').build(ws, ws).kind, 'tc_roster');
  assert.deepStrictEqual(X.myShifts(cara.uid, '2026-10-12', 7).map((s) => s.shift_date), ['2026-10-12', '2026-10-13']);
});

// ================================================================ MY DAY
test('scheduler: fixed never move, no overlaps, deadlines, overflow, pins, order and "now"', () => {
  const r = M.schedule({ window: { start: 480, end: 600 }, fixed: [{ key: 'meet', start: 540, mins: 30 }],
    flex: [{ key: 'a', mins: 30, deadline: 560 }, { key: 'b', mins: 40, deadline: null }, { key: 'c', mins: 30, deadline: 520, urgent: true }, { key: 'd', mins: 30, deadline: 590 }] });
  const p = r.placed;
  assert.deepStrictEqual([p.meet.start, p.meet.end], [540, 570]);
  assert.strictEqual(p.c.start, 480, 'urgent first');
  assert.strictEqual(p.a.start, 510);
  assert.ok(!p.a.late);
  const all = Object.values(p).sort((x, y) => x.start - y.start);
  for (let i = 1; i < all.length; i++) assert.ok(all[i].start >= all[i - 1].end, 'no overlaps');
  assert.ok(p.d.late && !p.d.overflow, 'pushed past its deadline → late');
  assert.ok(p.b.overflow && !p.b.late, 'no deadline, after working hours → overflow');
  const now = M.schedule({ window: { start: 480, end: 1000 }, now: 700, flex: [{ key: 'x', mins: 20 }, { key: 'y', mins: 20, pin: 900 }, { key: 'z', mins: 20, pin: 600 }] }).placed;
  assert.strictEqual(now.x.start, 700, 'unfinished work moves to now');
  assert.strictEqual(now.y.start, 900);
  assert.ok(now.z.start >= 700, 'a pin in the past moves to the next free time');
  const ord = M.schedule({ window: { start: 0, end: 100 }, flex: [{ key: 'p', mins: 10, order: 2 }, { key: 'q', mins: 10, order: 1 }] }).placed;
  assert.ok(ord.q.start < ord.p.start);
  const clash = M.schedule({ window: { start: 0, end: 100 }, fixed: [{ key: 'm1', start: 10, mins: 30 }, { key: 'm2', start: 20, mins: 10 }] }).placed;
  assert.ok(clash.m2.clash, 'two fixed items overlapping are flagged');
});

test('working hours: 7 days with different hours; checked when saved', () => {
  assert.deepStrictEqual(M.hoursFor(owner.uid, '2026-10-11'), { off: false, start: '09:00', end: '13:00' }); // Sunday
  const h = M.hoursList(owner.uid);
  h[0] = { off: true, start: '09:00', end: '13:00' };
  h[1] = { off: false, start: '08:00', end: '17:00' };
  M.saveMyHours(owner, owner.uid, h, 10);
  assert.strictEqual(M.hoursFor(owner.uid, '2026-10-11').off, true);
  assert.strictEqual(M.hoursFor(owner.uid, '2026-10-12').start, '08:00');
  throws(() => M.saveMyHours(owner, owner.uid, h.map((x, i) => (i === 2 ? { off: false, start: '17:00', end: '08:00' } : x)), 10), /Tuesday/);
  throws(() => M.saveMyHours(mgr, owner.uid, h, 10), /Only the owner or admin/);
});

test('own items: once, weekly and monthly repeats; private', () => {
  const id = M.saveItem(owner, { title: 'Meeting with BSP', kind: 'meeting', date: '2026-10-12', start: '10:00', minutes: 60, private: false });
  M.saveItem(owner, { title: 'Doctor', kind: 'other', date: '2026-10-12', start: '15:00', minutes: 30, fixed: true, private: true });
  M.saveItem(owner, { title: 'Bank deposit', kind: 'errand', date: '2026-10-05', minutes: 30, repeat: 'weekly', repeatDays: [1, 4], deadline: '14:00' });
  M.saveItem(owner, { title: 'Pay rent', kind: 'errand', date: '2026-09-12', minutes: 20, repeat: 'monthly' });
  throws(() => M.saveItem(owner, { title: '', date: '2026-10-12', minutes: 30 }), /Type what it is/);
  throws(() => M.saveItem(owner, { title: 'x', date: '2026-10-12', minutes: 30, fixed: true }), /needs a time/);
  assert.strictEqual(M.getItem(id).fixed, 1, 'a meeting with a time is fixed');
  assert.deepStrictEqual(M.itemsOn(owner.uid, '2026-10-12').map((i) => i.title).sort(), ['Bank deposit', 'Doctor', 'Meeting with BSP', 'Pay rent']);
  assert.deepStrictEqual(M.itemsOn(owner.uid, '2026-10-13').map((i) => i.title), []);
  assert.deepStrictEqual(M.itemsOn(owner.uid, '2026-10-15').map((i) => i.title), ['Bank deposit']);
});

let fake = [];
setAlertSources([{ id: 'fake', alerts: () => fake }]);
test('app tasks: warnings become tasks with the admin-set times; the plan keeps meetings fixed and puts tasks before deadlines', () => {
  at('2026-10-12', '08:00');
  fake = [
    { id: 'leave-waiting', level: 'warning', text: '2 leave requests to approve', nav: { screen: 'LeaveApprove', params: {} } },
    { id: 'stat-due-fnpf-2026-09', level: 'warning', text: 'FNPF for 2026-09 due 2026-10-12 – $1,200.00', nav: { screen: 'Statutory', params: {} } },
    { id: 'health-x-1', level: 'urgent', text: 'Health check: backup is old', nav: { screen: 'HealthCheck', params: {} } },
    { id: 'till-eod-missing', level: 'info', text: 'End of day missing', nav: { screen: 'Till', params: {} } },
  ];
  M.saveMydaySettings(owner, { durations: { approval: 20, tax: 45 } });
  const t = M.appTasks(owner.uid, '2026-10-12');
  const by = Object.fromEntries(t.map((x) => [x.key, x]));
  assert.strictEqual(by['a:leave-waiting'].type, 'approval');
  assert.strictEqual(by['a:leave-waiting'].mins, 20);
  assert.strictEqual(by['a:stat-due-fnpf-2026-09'].type, 'tax');
  assert.strictEqual(by['a:stat-due-fnpf-2026-09'].deadline, 17 * 60, 'due today → by the end of work');
  assert.strictEqual(by['a:health-x-1'].type, 'watchdog');
  assert.strictEqual(by['a:till-eod-missing'].type, 'check');
  assert.ok(t.some((x) => x.key === `vat:2026-09` && x.type === 'tax') === false, 'VAT only near the end of the month');
  const plan = M.dayPlan(owner.uid, '2026-10-12');
  const b = Object.fromEntries(plan.blocks.map((x) => [x.key, x]));
  const meet = plan.blocks.find((x) => x.title === 'Meeting with BSP');
  assert.strictEqual(meet.startText, '10:00');
  assert.ok(meet.fixed);
  assert.strictEqual(b['a:health-x-1'].startText, '08:00', 'urgent first');
  for (let i = 1; i < plan.blocks.length; i++) assert.ok(plan.blocks[i].start >= plan.blocks[i - 1].end, `overlap at ${plan.blocks[i].title}`);
  assert.ok(plan.free.length, 'free time shown');
  assert.ok(!plan.late.length);
});

test('not today, skip, done, undo, up/down and move to a time', () => {
  const day = '2026-10-12';
  M.notToday(owner, owner.uid, day, 'a:till-eod-missing', 'End of day missing');
  let p = M.dayPlan(owner.uid, day);
  assert.ok(p.setAside.some((x) => x.key === 'a:till-eod-missing'));
  assert.ok(M.dayPlan(owner.uid, '2026-10-13').blocks.every((x) => x.key !== 'a:till-eod-missing'), 'tomorrow the warning brings it back (warnings are only read for today)');
  M.undoMark(owner, owner.uid, day, 'a:till-eod-missing');
  const errand = M.dayPlan(owner.uid, day).blocks.find((x) => x.title === 'Pay rent');
  M.notToday(owner, owner.uid, day, errand.key, errand.title);
  assert.ok(M.dayPlan(owner.uid, day).setAside.some((x) => x.key === errand.key), 'repeating item: not today = skipped today');
  const once = M.saveItem(owner, { title: 'Pick up stock', kind: 'errand', date: day, minutes: 30 });
  assert.deepStrictEqual(M.notToday(owner, owner.uid, day, `own:${once}`, 'Pick up stock'), { moved: '2026-10-13' });
  assert.strictEqual(M.getItem(once).the_date, '2026-10-13');
  M.skipTask(owner, owner.uid, day, 'a:leave-waiting', 'x');
  assert.ok(M.dayPlan(owner.uid, day).setAside.some((x) => x.key === 'a:leave-waiting'));
  M.undoMark(owner, owner.uid, day, 'a:leave-waiting');
  p = M.dayPlan(owner.uid, day);
  const flex = p.blocks.filter((x) => !x.fixed && !x.pinned);
  const second = flex[1];
  M.moveTask(owner, owner.uid, day, second.key, 'up');
  assert.strictEqual(M.dayPlan(owner.uid, day).blocks.filter((x) => !x.fixed && !x.pinned)[0].key, second.key);
  M.pinTask(owner, owner.uid, day, 'a:till-eod-missing', '16:00');
  assert.strictEqual(M.dayPlan(owner.uid, day).blocks.find((x) => x.key === 'a:till-eod-missing').startText, '16:00');
  throws(() => M.pinTask(mgr, owner.uid, day, 'a:till-eod-missing', '11:00'), /Only the person/);
  M.doneTask(owner, owner.uid, day, 'a:till-eod-missing', 'End of day missing');
  assert.ok(M.dayPlan(owner.uid, day).done.some((x) => x.key === 'a:till-eod-missing'));
});

test('a task that disappears from the warnings (job done in its screen) ticks itself off', () => {
  const day = '2026-10-12';
  M.openTask(owner, owner.uid, day, 'a:leave-waiting', '2 leave requests to approve');
  fake = fake.filter((a) => a.id !== 'leave-waiting');
  clearAlertCache(); // warnings are reused for up to a minute (3.9.4 speed-up); the next look sees the change
  const p = M.dayPlan(owner.uid, day);
  const d = p.done.find((x) => x.key === 'a:leave-waiting');
  assert.ok(d, 'ticked off');
  assert.ok(!p.blocks.some((x) => x.key === 'a:leave-waiting'));
});

test('late tasks turn red with an urgent warning; reminders come with a sound before the next item', () => {
  at('2026-10-12', '16:20');
  fake.push({ id: 'ap-due-today', level: 'urgent', text: 'Invoices due today', nav: { screen: 'Payables', params: {} } });
  M.saveMydaySettings(owner, { durations: { check: 60 } });
  const p = M.dayPlan(owner.uid, '2026-10-12');
  assert.ok(p.late.some((x) => x.key === 'a:ap-due-today'), 'cannot finish by 17:00');
  const al = M.mydayAlerts(owner);
  assert.ok(al.some((a) => a.level === 'urgent' && a.id === 'myday-late-a:ap-due-today'), JSON.stringify(al.map((a) => a.id)));
  at('2026-10-12', '09:52');
  const rem = M.mydayAlerts(owner);
  const next = rem.find((a) => a.id.startsWith('myday-next-'));
  assert.ok(next && next.notify && /10:00: Meeting with BSP/.test(next.text), JSON.stringify(rem));
  assert.deepStrictEqual(M.mydayAlerts(mgr), [], 'only the owner/admin get My day warnings');
  // collected through the registry with the module's own alerts function
  setAlertSources([{ id: 'fake', alerts: () => fake }, { id: 'myday', alerts: (u) => M.mydayAlerts(u) }]);
  assert.ok(collectAlerts(owner).some((a) => a.id.startsWith('myday-next-')));
  setAlertSources([{ id: 'fake', alerts: () => fake }]);
});

test('visibility: managers see business tasks read-only, private items as Busy; staff see busy/free', () => {
  at('2026-10-12', '08:00');
  const o = M.viewPlan(owner, owner.uid, '2026-10-12');
  assert.strictEqual(o.level, 'full');
  assert.ok(o.editable);
  assert.ok(o.blocks.some((b) => b.title === 'Doctor'));
  const m = M.viewPlan(mgr, owner.uid, '2026-10-12');
  assert.strictEqual(m.level, 'busy', 'My day removed in 3.9.4: managers no longer get the business view');
  assert.ok(!m.editable);
  assert.ok(!m.blocks.some((b) => b.title === 'Doctor'));
  const s = M.viewPlan(asha, owner.uid, '2026-10-12');
  assert.strictEqual(s.level, 'busy');
  assert.ok(s.blocks.every((b) => b.title === 'Busy' && !b.nav));
  assert.strictEqual(M.viewPlan(admin, owner.uid, '2026-10-12').level, 'business', 'admin looking at the owner: business view');
});

test('pay day (Saturday), wages book (Friday), month end and VAT, supplier order cut-offs', () => {
  at('2026-10-12', '08:00');
  assert.ok(M.appTasks(owner.uid, '2026-10-17').some((t) => t.key === 'pay:2026-10-17' && t.deadline === 12 * 60));
  assert.ok(M.appTasks(owner.uid, '2026-10-16').some((t) => t.key === 'paybook:2026-10-16'));
  const me = M.appTasks(owner.uid, '2026-10-31');
  assert.ok(me.some((t) => t.key === 'monthend:2026-10' && t.nav.screen === 'MonthEnd'), JSON.stringify(me.map((t) => t.key)));
  assert.ok(me.some((t) => t.key === 'vat:2026-09' && t.urgent));
  assert.ok(M.appTasks(owner.uid, '2026-10-28').some((t) => t.key === 'vat:2026-09' && !t.urgent));
  const sup = AP.saveSupplier(owner, { name: 'Rewa Dairy', tin: '50999888', onAccount: true });
  SC.saveSchedule(owner, { supplierUid: sup.uid, days: [{ day: 1, cutoff: '11:00', deliveryDay: 2 }], reminderMins: 60 });
  const t = M.appTasks(owner.uid, '2026-10-19').filter((x) => x.type === 'order');
  assert.ok(t.length >= 1);
  assert.strictEqual(t[0].deadline, 11 * 60);
  assert.match(t[0].title, /Order from Rewa Dairy/);
  const plan = M.dayPlan(owner.uid, '2026-10-19');
  const o = plan.blocks.find((x) => x.type === 'order');
  assert.ok(o.end <= 11 * 60 && !o.late, 'placed before the cut-off');
});

test('typeOf / deadlineOf read the warnings registry; unknown sources degrade to "other"', () => {
  const h = { off: false, start: '08:00', end: '17:00' };
  assert.strictEqual(M.typeOf({ id: 'ord-due-x' }), 'order');
  assert.strictEqual(M.typeOf({ id: 'lic-1-due' }), 'licence');
  assert.strictEqual(M.typeOf({ id: 'pay-draft' }), 'payday');
  assert.strictEqual(M.typeOf({ id: 'verify-waiting' }), 'approval');
  assert.strictEqual(M.typeOf({ id: 'something-new' }), 'other');
  assert.strictEqual(M.deadlineOf({ id: 'x', due: '2026-10-12 10:30' }, '2026-10-12', h), 630);
  assert.strictEqual(M.deadlineOf({ id: 'x', text: 'Licence expires on 2026-11-01' }, '2026-10-12', h), null);
  assert.strictEqual(M.deadlineOf({ id: 'x', text: 'EXPIRED on 2026-10-01' }, '2026-10-12', h), -1);
  assert.strictEqual(M.deadlineOf({ id: 'x', level: 'urgent', text: 'Do it' }, '2026-10-12', h), 17 * 60);
  assert.strictEqual(M.deadlineOf({ id: 'x', level: 'info', text: 'Look' }, '2026-10-12', h), null);
});

test('Google Calendar: meetings come in as fixed items; app tasks go out only when switched on and changed', () => {
  at('2026-10-12', '08:00');
  db().run('DELETE FROM outbox');
  assert.strictEqual(M.requestMeetings('2026-10-12'), false, 'off by default');
  M.saveMydaySettings(owner, { calendarIn: true, calendarOut: true });
  assert.strictEqual(M.requestMeetings('2026-10-12'), true);
  assert.strictEqual(M.requestMeetings('2026-10-12'), false, 'not again within 30 minutes');
  const ob = db().all('SELECT * FROM outbox').map((r) => [r.kind, JSON.parse(r.payload)]);
  assert.deepStrictEqual(ob[0], ['myday_in', { date: '2026-10-12', ownerUid: owner.uid }]);
  const n = M.applyGoogleEvents(owner.uid, '2026-10-12', [{ id: 'abc@google', title: 'Supplier visit', start: '13:00', end: '13:45' }, { id: 'p@google', title: 'Dentist', start: '11:30', end: '12:00', private: true }, { id: 'all', title: 'Holiday', allDay: true }]);
  assert.strictEqual(n, 2);
  const p = M.dayPlan(owner.uid, '2026-10-12');
  const g = p.blocks.find((b) => b.title === 'Supplier visit');
  assert.ok(g.fixed && g.startText === '13:00' && g.endText === '13:45');
  assert.ok(M.viewPlan(mgr, owner.uid, '2026-10-12').blocks.some((b) => b.busy && b.startText === '11:30'), 'private Google event is Busy');
  M.applyGoogleEvents(owner.uid, '2026-10-12', [{ id: 'abc@google', title: 'Supplier visit (moved)', start: '14:00', end: '14:30' }]);
  const titles = M.dayPlan(owner.uid, '2026-10-12').blocks.map((b) => b.title);
  assert.ok(titles.includes('Supplier visit (moved)') && !titles.includes('Dentist'), 'cancelled meeting removed');
  const sent = M.sendDayToCalendar(owner, owner.uid, '2026-10-12');
  assert.ok(sent > 0);
  assert.strictEqual(M.sendDayToCalendar(owner, owner.uid, '2026-10-12'), 0, 'unchanged → not sent again');
  const out = db().all("SELECT payload FROM outbox WHERE kind = 'myday_out'").map((r) => JSON.parse(r.payload));
  assert.strictEqual(out.length, 1);
  assert.strictEqual(out[0].calendar, 'Easy Buys – My day');
  assert.ok(out[0].items.every((i) => !/Doctor|Meeting with BSP|Supplier visit/.test(i.title)), 'only app tasks go out');
  M.saveMydaySettings(owner, { calendarOut: false });
  throws(() => M.sendDayToCalendar(owner, owner.uid, '2026-10-13'), /switched off/);
  assert.ok(getSetting('myday_in_2026-10-12', ''));
});

done();
