// Go-live bakery: ingredients ordered and received through normal Inventory go into the Bakery stock (not the shop's),
// once per delivery, on the bakery tablet; the baker's day in steps (clock in → opening stock → opening checklists →
// baking → closing checklists → close & count → clock out).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as B from '../src/modules/bakery/store.js';
import * as DAY from '../src/modules/bakery/day.js';
import { startShift } from '../src/services/shifts.js';
import { myChecklists, openRun, answerItem } from '../src/services/checklists.js';
import { punch } from '../src/modules/timeclock/service.js';
import * as PF from '../src/services/proofing.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T05:00:00');
const admin = db().get("SELECT * FROM users WHERE name = 'Admin'");
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const ravi = db().get("SELECT * FROM users WHERE name = 'Ravi'");
const sup = AP.saveSupplier(owner, { name: 'Flour Mills of Fiji', tin: '501234567' });
const bag = I.saveItem(owner, { code: 'FL25', name: 'Flour 25kg bag', cost: 40, price: 0 });
const flour = () => db().get("SELECT stock FROM materials WHERE name = 'Flour'").stock;
const shopQty = (uid) => db().get("SELECT COALESCE(SUM(qty),0) q FROM inv_moves WHERE item_uid = ? AND status = 'active'", [uid]).q;

test('link a bakery ingredient to an Inventory product', () => {
  B.linkMaterial(owner, 'Flour', bag.uid, 25);
  assert.deepStrictEqual(B.linkFor(bag.uid), { material: 'Flour', factor: 25 });
  throws(() => B.linkMaterial(owner, 'Sugar', bag.uid, 1), /already linked/);
});
test('received at Shop 1: into the Bakery stock, not the shop stock; once only', () => {
  setSetting('bakery_stock_here', '0'); // entered on another device: the bakery tablet adds it later
  const before = flour();
  const r = I.receiveDelivery(owner, { supplierUid: sup.uid, shopCode: 'S1', extra: [{ itemUid: bag.uid, qty: 4, unitCost: 40 }] });
  assert.strictEqual(shopQty(bag.uid), 0, 'not in the shop stock');
  assert.strictEqual(B.bakeryReceiptsWaiting().length, 1);
  assert.strictEqual(B.postBakeryReceipts({ force: true }), 1);
  assert.strictEqual(flour(), before + 100);
  assert.strictEqual(B.postBakeryReceipts({ force: true }), 0, 'never twice');
  assert.strictEqual(flour(), before + 100);
  const t = db().get("SELECT * FROM transactions WHERE type = 'RECEIVE' AND ref = ?", [r.uid]);
  assert.ok(t && t.unit_cost === 1.6, 'cost per kg');
});
test('received on the bakery tablet itself: in the Bakery stock straight away', () => {
  setSetting('bakery_stock_here', '1');
  const before = flour();
  I.receiveDelivery(owner, { supplierUid: sup.uid, shopCode: 'S1', extra: [{ itemUid: bag.uid, qty: 1, unitCost: 40 }] });
  assert.strictEqual(flour(), before + 25);
  assert.strictEqual(B.bakeryReceiptsWaiting().length, 0);
});
test('received at Shop 2: stays in the shop stock', () => {
  I.receiveDelivery(owner, { supplierUid: sup.uid, shopCode: 'S2', extra: [{ itemUid: bag.uid, qty: 2, unitCost: 40 }] });
  assert.strictEqual(shopQty(bag.uid), 2);
  assert.strictEqual(B.bakeryReceiptsWaiting().length, 0);
});
test("baker's day: steps in order; baking locked until opening checklists are done", () => {
  let d = DAY.bakerDay(ravi);
  assert.strictEqual(d.now, 'clock-in');
  assert.ok(/Open the bakery day|Clock in/.test(DAY.bakingLocked(ravi)));
  punch({ user: ravi, type: 'IN', shopCode: 'S1' });
  d = DAY.bakerDay(ravi);
  assert.strictEqual(d.now, 'opening');
  const counts = Object.fromEntries(db().all('SELECT id, stock FROM materials WHERE track_stock = 1 AND active = 1').map((m) => [m.id, m.stock]));
  startShift(ravi.id, 'Early Bake', counts);
  d = DAY.bakerDay(ravi);
  assert.strictEqual(d.now, 'start-lists');
  assert.ok(DAY.bakingLocked(ravi));
  assert.strictEqual(DAY.bakingLocked(owner), null, 'owner can always');
  for (const l of myChecklists(ravi.id).filter((x) => x.when_due !== 'end')) {
    const run = openRun(l.id, ravi.id);
    run.items.forEach((it) => answerItem(run.run.id, it.id, ravi.id, it.kind === 'temp' ? { value: it.min_value } : it.kind === 'photo' ? { photo: 'file:///p.jpg' } : { done: true }));
  }
  d = DAY.bakerDay(ravi);
  assert.strictEqual(DAY.bakingLocked(ravi), null);
  assert.ok(['baking', 'end-lists'].includes(d.now), d.now);
});
test('close & count: checked first (nothing half closed), then closed and balanced in one step', () => {
  for (const l of myChecklists(ravi.id).filter((x) => x.when_due === 'end')) {
    const run = openRun(l.id, ravi.id);
    run.items.forEach((it) => answerItem(run.run.id, it.id, ravi.id, it.kind === 'temp' ? { value: it.min_value } : it.kind === 'photo' ? { photo: 'file:///p.jpg' } : { done: true }));
  }
  const sheet = DAY.countSheet();
  assert.ok(sheet.length);
  throws(() => DAY.closeAndCount(ravi, {}), /Count these/);
  assert.ok(db().get("SELECT 1 x FROM shifts WHERE status = 'open'"), 'still open after a mistake');
  const counts = Object.fromEntries(sheet.map((r) => [r.material_id, r.expected]));
  const s = DAY.closeAndCount(ravi, counts);
  assert.strictEqual(s.status, 'approved');
  const d = DAY.bakerDay(ravi);
  assert.strictEqual(d.now, 'clock-out');
  assert.deepStrictEqual(DAY.dayNotClosedWarnings(), []);
});
test('receiving without a purchase order: a photo is needed (owner / admin may skip); it goes on the invoice', () => {
  const mgr = saveUser({ name: 'Anita M', pin: '8181', role: 'manager', shopCode: 'S2' }, owner);
  throws(() => I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S2', extra: [{ itemUid: bag.uid, qty: 1, unitCost: 40 }] }), /take a photo/);
  const r = I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S2', extra: [{ itemUid: bag.uid, qty: 1, unitCost: 40 }], photos: ['file:///goods.jpg'], invoice: { invoiceNo: 'FM-1', total: 45 } });
  assert.ok(r.invoice, 'invoice entered');
  const ph = db().get("SELECT COUNT(*) n FROM photos WHERE ref_type = 'invoice' AND ref_id = ?", [r.invoice.uid]);
  assert.ok(!ph || ph.n >= 0);
});
test('proofing: minutes from the yeast table (in proportion between rows), hot / cool days adjust it', () => {
  const pid = db().get('SELECT id FROM products ORDER BY id LIMIT 1').id;
  throws(() => PF.saveProofTable(owner, pid, [{ yeast: 10, minutes: 60 }, { yeast: 10, minutes: 50 }]), /twice/);
  PF.saveProofTable(owner, pid, [{ yeast: 10, minutes: 60 }, { yeast: 20, minutes: 40 }]);
  const p = PF.proofFor(pid, { flourKg: 100, yeastQty: 1, climate: 'normal' });
  assert.ok(p && p.minutes > 0, JSON.stringify(p));
  assert.strictEqual(PF.interpolate([{ yeast: 10, minutes: 60 }, { yeast: 20, minutes: 40 }], 15), 50);
  const hot = PF.proofFor(pid, { flourKg: 100, yeastQty: 1, roomTemp: 35 });
  const cool = PF.proofFor(pid, { flourKg: 100, yeastQty: 1, roomTemp: 18 });
  assert.strictEqual(hot.climate, 'hot'); assert.strictEqual(cool.climate, 'cool');
  assert.ok(cool.minutes > hot.minutes);
});
done();
