// 3.9.4 The online dashboard is decided by the app: sections (Today, Sales, Money, Purchase orders, Invoices, Cheques,
// People, Stock, Bakery) made of simple blocks; owner / admin choose them; one device sends it.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, deviceId, setShared, getShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as B from '../src/services/board.js';
import { buildSnapshot } from '../src/services/dashboard.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:42:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita Devi', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P1', invoiceDate: '2026-09-01', dueDate: '2026-10-01', total: 112.5, shopCode: 'S1' });
AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P2', invoiceDate: '2026-10-09', dueDate: '2026-10-14', total: 50, shopCode: 'S2' });
const coke = I.saveItem(owner, { code: 'CK1', name: 'Coke 300ml', unit: 'each', cost: 1, price: 1.6, vatType: 'standard' });
const po = I.savePO(sita, { supplierUid: sup.uid, shopCode: 'S1', expectedDate: '2026-10-13', lines: [{ itemUid: typeof coke === 'string' ? coke : coke.uid, qty: 24, unitCost: 1 }] });
db().run("UPDATE po_orders SET status = 'sent' WHERE uid = ?", [po.uid]); // sent to the supplier: its delivery is expected

const sec = (b, id) => b.sections.find((s) => s.id === id);
const noErrors = (b) => b.sections.filter((s) => (s.blocks || []).some((x) => x.type === 'note' && /could not be worked out/.test(x.text))).map((s) => `${s.id}: ${s.blocks.find((x) => x.type === 'note').text}`);

test('every section is worked out, none fails', () => {
  const b = B.buildBoard({ force: true });
  assert.deepStrictEqual(b.sections.map((s) => s.id), ['today', 'sales', 'money', 'purchases', 'invoices', 'cheques', 'people', 'stock', 'insights', 'bakery']);
  assert.deepStrictEqual(noErrors(b), []);
  assert.ok(sec(b, 'bakery').legacy);
});

test('Today: the overdue invoice needs paying, the PO delivery and the next invoice are due this week', () => {
  const t = sec(B.buildBoard({ force: true }), 'today');
  const due = t.blocks.find((x) => x.type === 'list' && /Due today/.test(x.title));
  assert.ok(due.items.some((i) => /Punjas · inv P1/.test(i.text) && i.tone === 'danger' && i.right === 112.5), JSON.stringify(due.items));
  assert.ok(due.items.some((i) => /inv P2/.test(i.text) && i.right === 50));
  assert.ok(due.items.some((i) => /Delivery: Punjas/.test(i.text)));
  const tile = t.blocks[0].items.find((x) => x.label === 'Due in the next 7 days');
  assert.ok(tile.value >= 162.5, JSON.stringify(tile));
});

test('Purchase orders and supplier invoices list who, when, status and owing', () => {
  const b = B.buildBoard({ force: true });
  const po = sec(b, 'purchases').blocks.find((x) => x.type === 'table');
  assert.strictEqual(po.rows.length, 1);
  assert.strictEqual(po.rows[0].by, 'Sita Devi');
  assert.strictEqual(po.rows[0].deliver, '2026-10-13');
  const inv = sec(b, 'invoices').blocks.find((x) => x.type === 'table');
  assert.deepStrictEqual(JSON.stringify(inv.rows.map((r) => [r.no, r.owing, r.state]).sort()), JSON.stringify([['P1', 112.5, 'Overdue'], ['P2', 50, 'Due soon']]));
});

test('owner chooses: switch a section off, change the order, keep wages and bank balances off the internet', () => {
  throws(() => B.saveBoardSettings(sita, { off: ['cheques'] }), /owner or an admin/);
  B.saveBoardSettings(owner, { off: ['cheques'], order: ['invoices', 'today'], hide: { bank: true, wages: true } });
  const b = B.buildBoard({ force: true });
  assert.deepStrictEqual(b.sections.map((s) => s.id).slice(0, 2), ['invoices', 'today']);
  assert.ok(!sec(b, 'cheques'));
  const today = sec(b, 'today');
  assert.ok(!today.blocks[0].items.some((x) => x.label === 'Cash & bank now'));
  const money = sec(b, 'money');
  assert.ok(!money.blocks[0].items.some((x) => /Cash & bank/.test(x.label)));
  assert.ok(!money.blocks.some((x) => x.type === 'table' && x.cols.some((c) => c.key === 'wages')));
  B.saveBoardSettings(owner, { off: [], order: [], hide: { bank: false, wages: false } });
});

test('the snapshot sent to the cloud carries the board, small enough to send', () => {
  const s = buildSnapshot();
  assert.ok(s.board && s.board.sections.length >= 8);
  assert.ok(JSON.stringify(s).length < 400000, String(JSON.stringify(s).length));
});

test('one device sends the dashboard: it claims the job, sends every 5 minutes, another takes over after 30 quiet minutes', () => {
  setShared('dashboard_poster', null);
  const t0 = new Date('2026-10-11T09:42:00').getTime();
  assert.ok(B.shouldSendDashboard({ isMain: true, now: t0 }));
  assert.strictEqual(getShared('dashboard_poster').device, deviceId());
  assert.ok(!B.shouldSendDashboard({ isMain: true, now: t0 + 60000 }), 'not again within 5 minutes');
  assert.ok(B.shouldSendDashboard({ isMain: true, now: t0 + 5 * 60000 }));
  // another device is sending (fresh): this one stays quiet
  setShared('dashboard_poster', { device: 'OTHER', at: '2026-10-11 09:40:00', pinned: false, bakery: true });
  assert.ok(!B.shouldSendDashboard({ isMain: true, now: t0 + 11 * 60000 }));
  // the other went quiet for over 30 minutes: the main tablet takes over
  assert.ok(B.shouldSendDashboard({ isMain: true, now: new Date('2026-10-11T10:20:00').getTime() }));
  assert.strictEqual(getShared('dashboard_poster').device, deviceId());
});

done();
