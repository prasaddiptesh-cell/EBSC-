// 3.9.3 Cartons and singles, and the purchase order laid out like an invoice.
// Stock is in singles. An order line can be in cartons (typed per carton, kept per single); received as cartons + loose.
// The PO shows quantity / unit as ordered, unit price, VAT per line (VAT free / zero rated too), number of items,
// subtotal, VAT and total, who made it and when. No signature needed to send it.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as PA from '../src/modules/inventory/poAmend.js';
import { poReport, amendedPoReport } from '../src/modules/inventory/reports.js';
import { reportToHtml, reportToCsv } from '../src/services/export.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:42:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita Devi', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const coke = I.saveItem(owner, { code: 'CK1', name: 'Coke 300ml', unit: 'each', packSize: 24, cost: 0.979167, price: 1.6, vatType: 'standard' });
const rice = I.saveItem(owner, { code: 'RI1', name: 'Rice 10kg', unit: 'bag', packSize: 1, cost: 20, price: 28, vatType: 'zero' });
const bread = I.saveItem(owner, { code: 'BR1', name: 'Flour 25kg', unit: 'bag', packSize: 1, cost: 40, price: 50, vatType: 'exempt' });
const uidOf = (x) => (typeof x === 'string' ? x : x.uid);
let po;

test('order 10 cartons of 24 at $23.50 a carton, 4 single bags of rice, 1 bag of flour', () => {
  po = I.savePO(sita, { supplierUid: sup.uid, shopCode: 'S1', lines: [
    { itemUid: uidOf(coke), qty: 10, unitCost: 23.5, orderAs: 'carton', packSize: 24 },
    { itemUid: uidOf(rice), qty: 4, unitCost: 20 },
    { itemUid: uidOf(bread), qty: 1, unitCost: 40 }] });
  const l = po.lines.find((x) => x.code === 'CK1');
  assert.strictEqual(l.qty, 240); assert.strictEqual(l.order_as, 'carton'); assert.strictEqual(l.pack_size, 24);
  const v = I.orderView(l);
  assert.strictEqual(v.qty, 10); assert.strictEqual(v.cost, 23.5); assert.strictEqual(v.unit, 'ctn of 24');
  // total: 235 + 12.5% = 264.38; rice 80 and flour 40 no VAT → 384.38
  assert.strictEqual(po.total, 384.38);
  assert.ok(/10 ctn of 24/.test(I.poText(po.uid)), I.poText(po.uid));
});
test('the PO reads like an invoice: items, subtotal, VAT, total, who made it and when', () => {
  const rep = poReport(po.uid);
  const sec = rep.sections[0];
  const ck = sec.rows.find((r) => r.code === 'CK1');
  assert.strictEqual(ck.qty, '10'); assert.strictEqual(ck.unit, 'ctn of 24'); assert.ok(/23\.50/.test(ck.cost) && /235\.00/.test(ck.total), JSON.stringify(ck));
  assert.strictEqual(sec.rows.find((r) => r.code === 'RI1').vat, 'Zero rated');
  assert.strictEqual(sec.rows.find((r) => r.code === 'BR1').vat, 'VAT free');
  const t = Object.fromEntries(sec.totals.map((x) => [x.label, x.value]));
  assert.ok(/3 items · 10 cartons · 5 singles/.test(t['Number of items']), t['Number of items']);
  assert.ok(/355\.00/.test(t['Subtotal (excl. VAT)']) && /29\.38/.test(t['VAT 12.5%']) && /384\.38/.test(t['TOTAL (incl. VAT)']) && /120\.00/.test(t['of which zero rated / VAT free']), JSON.stringify(t));
  assert.ok(rep.info.some((x) => x[0] === 'Ordered by' && x[1] === 'Sita Devi · 2026-10-11 09:42'), JSON.stringify(rep.info));
  assert.ok(!rep.info.some((x) => /NOT SIGNED/.test(x[1])) && !rep.signatures);
  const html = reportToHtml(rep);
  assert.ok(/class="tots"/.test(html) && /TOTAL \(incl\. VAT\)/.test(html));
  assert.ok(/TOTAL \(incl\. VAT\),\$?384\.38|TOTAL \(incl\. VAT\),"?\$?384/.test(reportToCsv(rep).replace(/"/g, '')), reportToCsv(rep));
});
test('sent without a signature; received as 9 cartons + 12 loose; stock in singles; cost per single', () => {
  I.submitPO(owner, po.uid, { canApprove: true });
  I.markSent(owner, po.uid, 'viber');
  const l = I.getPO(po.uid).lines.find((x) => x.code === 'CK1');
  const r = I.receiveDelivery(owner, { poUid: po.uid, date: '2026-10-11', acceptReason: 'short', lines: [{ lineUid: l.uid, qty: 9 * 24 + 12, unitCost: 23.5 / 24 }] });
  assert.ok(r.uid);
  assert.strictEqual(I.stockOf(uidOf(coke), 'S1'), 228);
  assert.ok(Math.abs(I.getItem(uidOf(coke)).cost - 0.9792) < 0.0001);
  assert.strictEqual(I.getPO(po.uid).lines.find((x) => x.code === 'CK1').qty_received, 228);
});
test('amend: change to 12 cartons; the change reads in cartons; switch a line to singles', () => {
  const o = I.getPO(po.uid);
  const ck = o.lines.find((x) => x.code === 'CK1');
  const ri = o.lines.find((x) => x.code === 'RI1');
  const res = PA.amendPO(owner, po.uid, { lines: [{ lineUid: ck.uid, qty: 12, unitCost: 23.5 }, { lineUid: ri.uid, qty: 4, unitCost: 20 }, { lineUid: o.lines.find((x) => x.code === 'BR1').uid, qty: 1, unitCost: 40 }] }, { reason: 'more' });
  assert.ok(res.changes.some((c) => /Coke 300ml: 10 ctn → 12 ctn/.test(c)), res.changes.join('; '));
  assert.strictEqual(I.getPO(po.uid).lines.find((x) => x.code === 'CK1').qty, 288);
  const rep = amendedPoReport(po.uid);
  assert.ok(rep.sections.some((s) => s.totals && s.totals.length));
});
test('old lines (no carton info) stay singles', () => {
  const p2 = I.savePO(sita, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: uidOf(coke), qty: 30, unitCost: 1 }] });
  const l = p2.lines[0];
  assert.strictEqual(l.qty, 30); assert.strictEqual(I.orderView(l).unit, 'each');
  db().run("UPDATE po_lines SET order_as = NULL, pack_size = NULL WHERE uid = ?", [l.uid]);
  assert.strictEqual(I.orderView(I.getPO(p2.uid).lines[0]).qty, 30);
  assert.ok(/3[0-9]\.[0-9]{2}/.test(poReport(p2.uid).sections[0].totals.find((t) => /TOTAL/.test(t.label)).value));
});
done();
