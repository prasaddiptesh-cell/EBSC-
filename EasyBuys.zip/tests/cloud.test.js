// The Google cloud program (cloud/Code.gs) run in Node with fake Google services.
// Run: node tests/cloud.test.js
const assert = require('assert');

const { load } = require('./fakeGoogle.cjs');

let passed = 0;
let failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('ok  ', name); } catch (e) { failed++; console.log('FAIL', name, '\n     ', e.stack.split('\n').slice(0, 4).join('\n      ')); }
}

const { G, ctx, post } = load();
const devA = { id: 'dev-tablet', name: 'Shop tablet', kind: 'tablet' };
const devB = { id: 'dev-phone', name: "Brother's phone", kind: 'phone' };
const devC = { id: 'dev-bakers', name: 'Bakers tablet', kind: 'tablet' };
const asA = (b) => post({ key: 'tablet-key-123', device: devA, ...b });
let tokenB;
const asB = (b) => post({ token: tokenB, device: devB, ...b });
const rec = (k, u, extra = {}) => ({ t: 'punches', k, u, row: { uid: k, updated_at: u, ...extra } });

test('setup creates the data sheets and a main-software key; safe to run twice', () => {
  ctx.setup();
  const key = G.props.MAIN_KEY;
  assert.ok(key && key.length > 40);
  ctx.setup();
  assert.strictEqual(G.props.MAIN_KEY, key);
  const ss = G.books[G.props.DATA_ID];
  assert.deepStrictEqual(ss.sheets.map((s) => s.name).sort(), ['Changes', 'Devices', 'Invites']);
  assert.ok(ss.sheets.every((s) => s.text), 'sheets are plain text');
});

test('the first device signs in with the cloud key; a wrong key is refused', () => {
  assert.match(post({ key: 'nope', device: devA, kind: 'ping' }).error, /Wrong cloud key/);
  const r = asA({ kind: 'ping' });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.device, 'dev-tablet');
  assert.strictEqual(r.version, 7); // v3.7 cloud script
  assert.ok(r.version >= 5, String(r.version)); // v3.5 cloud script
  const d = asA({ kind: 'devices' }).devices;
  assert.strictEqual(d.length, 1);
  assert.strictEqual(d[0].name, 'Shop tablet');
});

test('no key and no token: refused', () => {
  const r = post({ device: devB, kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false);
});

let invite;
test('invite: code + link code, the cloud key is never inside it', () => {
  invite = asA({ kind: 'invite_create', url: 'https://script.google.com/macros/s/X/exec', by: 'Owner' });
  assert.ok(invite.ok);
  assert.match(invite.code, /^[A-HJ-NP-Z2-9]{8}$/);
  const decoded = JSON.parse(Buffer.from(invite.linkCode.slice(4), 'base64').toString('utf8'));
  assert.deepStrictEqual(decoded, { u: 'https://script.google.com/macros/s/X/exec', i: invite.code });
  assert.ok(!invite.linkCode.includes('tablet-key'));
  assert.strictEqual(invite.emailed, false);
});

test('email invite: bad address refused, good address gets a tap link and the code', () => {
  assert.match(asA({ kind: 'invite_create', url: 'u', email: 'not-an-email' }).error, /does not look right/);
  const r = asA({ kind: 'invite_create', url: 'https://x/exec', email: 'brother@gmail.com', by: 'Divnesh' });
  assert.ok(r.emailed);
  const m = G.mails[G.mails.length - 1];
  assert.strictEqual(m.to, 'brother@gmail.com');
  assert.ok(m.htmlBody.includes('https://x/exec?link=' + encodeURIComponent(r.linkCode)));
  assert.strictEqual(r.linkUrl, 'https://x/exec?link=' + encodeURIComponent(r.linkCode));
  assert.ok(m.htmlBody.includes(r.linkCode));
});

test('join: wrong code refused; right code gives a token once; second use refused', () => {
  assert.match(post({ kind: 'join', invite: 'ZZZZZZZZ', device: devB }).error, /not found/);
  const r = post({ kind: 'join', invite: invite.code.toLowerCase(), device: devB });
  assert.ok(r.ok && r.approved && r.token.length > 40);
  tokenB = r.token;
  assert.match(post({ kind: 'join', invite: invite.code, device: devC }).error, /already been used/);
  assert.strictEqual(asB({ kind: 'ping' }).device, 'dev-phone');
  assert.match(post({ token: 'stolen', device: devB, kind: 'ping' }).error, /not linked/);
});

test('expired invite refused', () => {
  const r = asA({ kind: 'invite_create', url: 'u' });
  const sh = G.books[G.props.DATA_ID].getSheetByName('Invites');
  const row = sh.data.find((x) => x[0] === r.code);
  row[2] = new Date(Date.now() - 1000).toISOString();
  assert.match(post({ kind: 'join', invite: r.code, device: devC }).error, /expired/);
});

test('push and pull: the other device gets the change, not its own', () => {
  const p = asA({ kind: 'push', records: [rec('P1', '2026-10-08 07:58:00', { type: 'IN' }), rec('P2', '2026-10-08 08:01:00', { type: 'IN' })] });
  assert.strictEqual(p.accepted, 2);
  const b = asB({ kind: 'pull', since: 0 });
  assert.deepStrictEqual(b.records.map((r) => r.k), ['P1', 'P2']);
  assert.strictEqual(b.records[0].row.type, 'IN');
  assert.strictEqual(b.records[0].u, '2026-10-08 07:58:00', 'time stays text, not a date');
  assert.strictEqual(b.more, false);
  const a = asA({ kind: 'pull', since: 0 });
  assert.strictEqual(a.records.length, 0, 'own changes are not sent back');
  assert.strictEqual(asB({ kind: 'pull', since: b.next }).records.length, 0);
});

test('newest change wins; an older one is rejected and reported', () => {
  const ok = asB({ kind: 'push', records: [rec('P1', '2026-10-08 09:00:00', { type: 'IN', note: 'fixed by phone' })] });
  assert.strictEqual(ok.accepted, 1);
  const old = asA({ kind: 'push', records: [rec('P1', '2026-10-08 08:30:00', { type: 'IN', note: 'older' })] });
  assert.strictEqual(old.accepted, 0);
  assert.strictEqual(old.rejected[0].k, 'P1');
  const a = asA({ kind: 'pull', since: 2 });
  assert.strictEqual(a.records.length, 1);
  assert.strictEqual(a.records[0].row.note, 'fixed by phone');
});

test('keys that look like numbers keep leading zeros', () => {
  asA({ kind: 'push', records: [{ t: 'shops', k: '007', u: '2026-10-08 10:00:00', row: { code: '007' } }] });
  const r = asB({ kind: 'pull', since: 0 }).records.find((x) => x.t === 'shops');
  assert.strictEqual(r.k, '007');
});

test('change history (audit_log) goes to the main software only', () => {
  asA({ kind: 'push', records: [{ t: 'audit_log', k: 'A1', u: '2026-10-08 10:01:00', row: { uid: 'A1', action: 'Changed PIN' } }] });
  assert.ok(!asB({ kind: 'pull', since: 0 }).records.some((x) => x.t === 'audit_log'));
});

test('bad table names are ignored', () => {
  const r = asA({ kind: 'push', records: [{ t: 'Bad-Name', k: '1', u: 'x', row: {} }, { t: 'punches', u: 'x' }] });
  assert.strictEqual(r.accepted, 0);
});

test('main software: wrong key refused; right key gets everything incl. history; can push down', () => {
  assert.strictEqual(post({ kind: 'main_pull', key: 'guess', since: 0 }).error, 'Not allowed');
  const r = post({ kind: 'main_pull', key: G.props.MAIN_KEY, since: 0 });
  assert.ok(r.records.some((x) => x.t === 'audit_log'));
  assert.ok(r.records.some((x) => x.k === 'P2'));
  const pushed = post({ kind: 'main_push', key: G.props.MAIN_KEY, records: [{ t: 'users', k: 'U9', u: '2026-10-08 11:00:00', row: { uid: 'U9', name: 'New Staff' } }] });
  assert.strictEqual(pushed.accepted, 1);
  assert.ok(asB({ kind: 'pull', since: 0 }).records.some((x) => x.k === 'U9' && x.d === 'main'));
  assert.ok(post({ kind: 'main_devices', key: G.props.MAIN_KEY }).devices.length >= 2);
  assert.ok(G.props.LAST_MAIN_SYNC);
});

test('till program test buttons: the cloud keeps the test and returns the main tablet\'s answer', () => {
  assert.strictEqual(post({ kind: 'main_link_check', key: 'guess', source: 'S1-T1' }).error, 'Not allowed');
  const row = (kind, data) => ({ t: 'aronium_feed', k: `S1-T1|${kind}|ping|0`, u: `2026-10-11T00:00:0${kind === 'ping' ? 1 : 2}.000Z`, row: { uid: `S1-T1|${kind}|ping|0`, kind, data: JSON.stringify(data) } });
  post({ kind: 'main_push', key: G.props.MAIN_KEY, records: [row('ping', { nonce: 'n1' })] });
  let c = post({ kind: 'main_link_check', key: G.props.MAIN_KEY, source: 'S1-T1' });
  assert.ok(c.ok && c.version >= 7);
  assert.strictEqual(c.ping.nonce, 'n1');
  assert.strictEqual(c.pong, null);
  asB({ kind: 'push', records: [row('pong', { nonce: 'n1', device: 'Main tablet' })] });
  c = post({ kind: 'main_link_check', key: G.props.MAIN_KEY, source: 'S1-T1' });
  assert.strictEqual(c.pong.nonce, 'n1');
  assert.ok(Array.isArray(c.devices) && c.devices.length >= 1);
});

test('block a lost device; a device cannot block itself; unblock works', () => {
  assert.match(asA({ kind: 'device_status', id: 'dev-tablet', status: 'blocked' }).error, /cannot block itself/);
  assert.match(asA({ kind: 'device_status', id: 'dev-phone', status: 'deleted' }).error, /active or blocked/);
  assert.ok(asA({ kind: 'device_status', id: 'dev-phone', status: 'blocked' }).ok);
  const r = asB({ kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.blocked, true);
  assert.ok(asA({ kind: 'device_status', id: 'dev-phone', status: 'active' }).ok);
  assert.ok(asB({ kind: 'pull', since: 0 }).ok);
});

test('owner approval (optional): new device waits until approved', () => {
  assert.strictEqual(asA({ kind: 'cloud_settings', requireApproval: true }).requireApproval, true);
  const inv = asA({ kind: 'invite_create', url: 'u' });
  const j = post({ kind: 'join', invite: inv.code, device: devC });
  assert.strictEqual(j.approved, false);
  const w = post({ token: j.token, device: devC, kind: 'pull', since: 0 });
  assert.strictEqual(w.waiting, true);
  asA({ kind: 'device_status', id: 'dev-bakers', status: 'active' });
  assert.ok(post({ token: j.token, device: devC, kind: 'pull', since: 0 }).ok);
  assert.strictEqual(asA({ kind: 'cloud_settings', requireApproval: false }).requireApproval, false);
  assert.strictEqual(asA({ kind: 'cloud_settings' }).requireApproval, false);
});

test('large pulls come in pages', () => {
  const L = load({ pullLimit: 50 });
  L.ctx.setup();
  const A = (b) => L.post({ key: 'tablet-key-123', device: devA, ...b });
  const inv = A({ kind: 'invite_create', url: 'u' });
  const tok = L.post({ kind: 'join', invite: inv.code, device: devB }).token;
  const recs = Array.from({ length: 120 }, (_, i) => rec('R' + String(i).padStart(3, '0'), '2026-10-08 12:00:' + String(i % 60).padStart(2, '0')));
  assert.strictEqual(A({ kind: 'push', records: recs }).accepted, 120);
  let since = 0;
  const got = [];
  for (let i = 0; i < 10; i++) {
    const r = L.post({ token: tok, device: devB, kind: 'pull', since });
    got.push(...r.records.map((x) => x.k));
    since = r.next;
    if (!r.more) break;
  }
  assert.strictEqual(got.length, 120);
  assert.strictEqual(new Set(got).size, 120);
});

test('old Bakery requests still work with the cloud key', () => {
  const r = asA({ kind: 'snapshot', snapshot: { planSeq: 0, hello: 1 }, planSeq: 0 });
  assert.ok(r.ok);
  assert.deepStrictEqual(Array.from(r.planEdits), []);
});

test('the invite link page opens the app, or offers the code to copy; junk is refused', () => {
  const inv = asA({ kind: 'invite_create', url: 'https://script.google.com/macros/s/X/exec' });
  let page = null;
  ctx.HtmlService.createHtmlOutput = (h) => { page = h; return { setTitle() { return this; }, addMetaTag() { return this; } }; };
  ctx.doGet({ parameter: { link: inv.linkCode } });
  assert.ok(page.includes('intent://link?c=' + encodeURIComponent(inv.linkCode) + '#Intent;scheme=easybuys;package=com.easybuys.bakerymanager;end'));
  assert.ok(page.includes('>' + inv.linkCode + '</textarea>'));
  ctx.doGet({ parameter: { link: '"><script>alert(1)</script>' } });
  assert.ok(!page.includes('<script>') && /not complete/.test(page));
});

test('documents: kept in Drive › Documents; fetched back only from there', () => {
  const put = asA({ kind: 'file_put', folder: 'licence', fileName: 'DOC-1-Liquor licence.pdf', mime: 'application/pdf', data: Buffer.from('%PDF-1.4 test').toString('base64') });
  assert.strictEqual(put.ok, true);
  assert.ok(put.id);
  const got = asA({ kind: 'file_get', id: put.id });
  assert.strictEqual(Buffer.from(got.data, 'base64').toString(), '%PDF-1.4 test');
  assert.strictEqual(got.mime, 'application/pdf');
  const photo = asA({ kind: 'photo', refType: 'invoice', refId: 'X', data: 'QUJD', fileName: 'p.jpg', month: '2026-10' });
  const refused = asA({ kind: 'file_get', id: 'file-p.jpg' });
  assert.ok(photo.url);
  assert.strictEqual(refused.ok, false, 'not a document');
});

test('v3.5: Drive backups are listed newest first and can be fetched (only from Backups)', () => {
  asA({ kind: 'backup', fileName: 'backup-2026-10-01.json', data: JSON.stringify({ _meta: { made: '2026-10-01' }, a: 1 }) });
  asA({ kind: 'backup', fileName: 'backup-2026-10-02.json', data: JSON.stringify({ _meta: { made: '2026-10-02' }, a: 2 }) });
  const l = asA({ kind: 'backup_list' });
  assert.strictEqual(l.ok, true);
  assert.ok(l.files.length >= 2);
  assert.strictEqual(l.files[0].name, 'backup-2026-10-02.json');
  const g = asA({ kind: 'backup_get', id: l.files[0].id });
  assert.strictEqual(JSON.parse(g.text).a, 2);
  const photo = asA({ kind: 'photo', refType: 'x', refId: 'Y', data: 'QUJD', fileName: 'q.jpg', month: '2026-10' });
  assert.ok(photo.url);
  assert.strictEqual(asA({ kind: 'backup_get', id: 'file-q.jpg' }).ok, false, 'not a backup');
});

test('v3.5: Send to support emails only the fixed support address', () => {
  const before = G.mails.length;
  const r = asA({ kind: 'support_email', subject: 'Easy Buys problem report', text: 'It broke', to: 'someone@else.com' });
  assert.strictEqual(r.ok, true);
  const m = G.mails[before];
  assert.strictEqual(m.to, 'prasaddiptesh@gmail.com');
  assert.match(m.body, /It broke/);
});


// ---------------------------------------------------------------- v3.5 B8: checked uploads, visibility, backups, Windows API
const sha = (b) => require('crypto').createHash('sha256').update(b).digest('hex');
const pdfA = Buffer.from('%PDF-1.4 payslip week 40');
test('v3.5 upload: filed by type / year / month, size + SHA-256 returned; a repeated upload id gives the same file', () => {
  const body = { kind: 'file_put', uploadId: 'UP-DOC-1', path: ['Payroll – Restricted', '2026', '10'], docType: 'payslip', access: 'restricted', fileName: 'DOC-1-Payslips.pdf', mime: 'application/pdf',
    data: pdfA.toString('base64'), size: pdfA.length, sha256: sha(pdfA) };
  const r = asA(body);
  assert.strictEqual(r.ok, true, r.error);
  assert.strictEqual(r.sha256, sha(pdfA));
  assert.strictEqual(r.size, pdfA.length);
  const again = asA(body);
  assert.strictEqual(again.id, r.id);
  assert.strictEqual(again.existing, true);
  const files = G.DriveApp._all.filter((f) => f.name === 'DOC-1-Payslips.pdf' && !f.trashed);
  assert.strictEqual(files.length, 1, 'no duplicate on retry');
  const top = G.DriveApp.getFileById(r.id).getParents().next();
  assert.strictEqual(top.name, '10');
  assert.strictEqual(top.parent.name, '2026');
  assert.strictEqual(top.parent.parent.name, 'Payroll – Restricted');
  assert.strictEqual(top.parent.parent.parent.name, 'Documents');
  const bad = asA({ ...body, uploadId: 'UP-DOC-2', sha256: sha(Buffer.from('other')) });
  assert.strictEqual(bad.ok, false);
  assert.match(bad.error, /damaged/);
});

test('v3.5 visibility: the role comes from the synced staff records and is checked before file_get; old apps keep working', () => {
  asA({ kind: 'push', records: [
    { t: 'users', k: 'U-OWN', u: '2026-10-01 09:00:00', row: { uid: 'U-OWN', name: 'Owner', role: 'owner', active: 1 } },
    { t: 'users', k: 'U-MGR', u: '2026-10-01 09:00:00', row: { uid: 'U-MGR', name: 'Manager', role: 'manager', active: 1 } },
    { t: 'users', k: 'U-PAY', u: '2026-10-01 09:00:00', row: { uid: 'U-PAY', name: 'Pay clerk', role: 'payroll', active: 1 } },
    { t: 'users', k: 'U-GONE', u: '2026-10-01 09:00:00', row: { uid: 'U-GONE', name: 'Left', role: 'payroll', active: 0 } },
  ] });
  const ps = G.DriveApp._all.find((f) => f.name === 'DOC-1-Payslips.pdf').getId();
  const get = (uid, role) => asA({ kind: 'file_get', id: ps, user: uid ? { uid, role } : undefined });
  assert.strictEqual(get('U-OWN').ok, true);
  assert.strictEqual(get('U-PAY').ok, true, 'payroll may see payslips by default');
  const m = get('U-MGR', 'owner'); // claims to be owner – the cloud uses the synced role
  assert.strictEqual(m.ok, false);
  assert.match(m.error, /role may not open/);
  assert.strictEqual(get('U-GONE').ok, false);
  assert.match(get('U-NEW').error, /Sync now/);
  assert.strictEqual(get(null).ok, false, 'an old app cannot fetch a restricted v3.5 file');
  const got = get('U-PAY');
  assert.strictEqual(got.sha256, sha(pdfA));
  assert.strictEqual(Buffer.from(got.data, 'base64').toString(), pdfA.toString());
  // The admin lets managers see payslips (shared setting doc_visibility) and takes payroll off.
  asA({ kind: 'push', records: [{ t: 'shared_settings', k: 'doc_visibility', u: '2026-10-02 09:00:00', row: { key: 'doc_visibility', value: JSON.stringify({ payslip: ['manager', 'owner', 'admin'] }) } }] });
  assert.strictEqual(get('U-MGR').ok, true);
  assert.strictEqual(get('U-PAY').ok, false);
  // A v3.4 document (no upload id) still opens for a v3.4 app; a contract from v3.4 is checked for v3.5 apps.
  const old = asA({ kind: 'file_put', folder: 'contract', fileName: 'DOC-9-Contract.pdf', mime: 'application/pdf', data: 'JVBERg==' });
  asA({ kind: 'push', records: [{ t: 'documents', k: 'DOC-9', u: '2026-10-02 09:00:00', row: { uid: 'DOC-9', ref_type: 'contract', cloud_id: old.id } }] });
  assert.strictEqual(asA({ kind: 'file_get', id: old.id }).ok, true, 'v3.4 app');
  assert.strictEqual(asA({ kind: 'file_get', id: old.id, user: { uid: 'U-MGR' } }).ok, false, 'contracts are restricted');
  assert.strictEqual(asA({ kind: 'file_get', id: old.id, user: { uid: 'U-OWN' } }).ok, true);
});

test('v3.5 nightly backups: daily kept 30 days, first of the month also monthly (12 months), with a manifest; all listed and fetchable', () => {
  const day = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
  const send = (d) => asA({ kind: 'backup', tier: 'daily', date: d, fileName: `backup-${d}.json`, data: JSON.stringify({ _meta: { made: d }, d }), manifest: JSON.stringify({ documents: [{ uid: 'DOC-1' }] }) });
  const old = send(day(45));
  assert.strictEqual(old.ok, true);
  assert.strictEqual(old.monthly, true);
  const y = send(day(1));
  const t = send(day(0));
  assert.ok(t.manifestId);
  const daily = G.DriveApp._all.filter((f) => !f.trashed && f.getParents().next().name === 'Daily').map((f) => f.name);
  assert.ok(!daily.includes(`backup-${day(45)}.json`), 'older than 30 days → bin');
  assert.ok(daily.includes(`backup-${day(1)}.json`) && daily.includes(`backup-${day(0)}-manifest.json`));
  const monthly = G.DriveApp._all.filter((f) => !f.trashed && f.getParents().next().name === 'Monthly').map((f) => f.name);
  assert.ok(monthly.includes(`backup-${day(45)}.json`), 'kept as the monthly one of its month');
  assert.ok(monthly.length >= 2 && monthly.length <= 6);
  const l = asA({ kind: 'backup_list' });
  assert.ok(l.files.some((f) => f.tier === 'Daily') && l.files.some((f) => f.tier === 'Monthly'));
  assert.ok(!l.files.some((f) => /manifest/.test(f.name)));
  const g = asA({ kind: 'backup_get', id: y.id });
  assert.strictEqual(JSON.parse(g.text).d, day(1));
  // An old app's plain backup still goes to Backups.
  assert.strictEqual(asA({ kind: 'backup', fileName: 'backup-old.json', data: '{}' }).ok, true);
});

test('v3.5 Windows software: list files since a time and fetch one, only with the main-software key', () => {
  const key = G.props.MAIN_KEY;
  assert.strictEqual(post({ kind: 'main_files', key: 'wrong' }).ok, false);
  const l = post({ kind: 'main_files', key, since: '' });
  assert.strictEqual(l.ok, true);
  const doc = l.files.find((f) => f.kind === 'document' && f.name === 'DOC-1-Payslips.pdf');
  assert.ok(doc && doc.sha256 === sha(pdfA) && doc.docType === 'payslip');
  assert.ok(l.files.some((f) => f.kind === 'backup'));
  const later = post({ kind: 'main_files', key, since: l.next });
  assert.strictEqual(later.files.length, 0);
  const f = post({ kind: 'main_file_get', key, id: doc.id });
  assert.strictEqual(f.sha256, sha(pdfA));
  assert.strictEqual(Buffer.from(f.data, 'base64').toString(), pdfA.toString());
  assert.strictEqual(post({ kind: 'main_file_get', key, id: 'file-q.jpg' }).ok, false, 'photos are not served this way');
  assert.strictEqual(post({ kind: 'main_file_get', key: 'x', id: doc.id }).ok, false);
});

test('reading invoice photos: off until Drive is added; text comes back when it is', () => {
  assert.strictEqual(asA({ kind: 'ocr', files: [{ data: 'QUJD' }] }).off, true);
  ctx.Drive = { Files: { create: () => ({ id: 'doc1' }) } };
  ctx.DocumentApp = { openById: () => ({ getBody: () => ({ getText: () => 'TOTAL 45.00' }) }) };
  G.DriveApp.getFileById = () => ({ setTrashed() {}, moveTo() {} });
  const r = asA({ kind: 'ocr', files: [{ data: 'QUJD' }, { data: 'REVG' }] });
  assert.strictEqual(r.text, 'TOTAL 45.00\nTOTAL 45.00');
});

test('v3.6: Start fresh – main tablet only; old records cleared, owners kept, newer kept; old pushes refused; test files moved', () => {
  asA({ kind: 'push', records: [rec('P-OLD', '2026-10-01 08:00:00'), { t: 'users', k: 'U-OWN', u: '2026-10-01 08:00:00', row: { uid: 'U-OWN', role: 'owner' } }, { t: 'users', k: 'U-STAFF', u: '2026-10-01 08:00:00', row: { uid: 'U-STAFF', role: 'staff' } }] });
  asA({ kind: 'photo', refType: 'x', refId: 'Z', data: 'QUJD', fileName: 'z.jpg', month: '2026-10' });
  assert.match(asB({ kind: 'fresh_start', id: 'F1', at: '2026-10-05 00:00:00', tables: ['punches'] }).error, /main tablet/);
  const r = asA({ kind: 'fresh_start', id: 'F1', at: '2026-10-05 00:00:00', tables: ['punches', 'users'], moveFiles: true });
  assert.strictEqual(r.ok, true, r.error);
  assert.ok(r.cleared >= 2);
  assert.ok(r.foldersMoved >= 1, 'Photos moved to the test data folder');
  const keys = (t) => { const sh = G.SpreadsheetApp.openById(G.props.DATA_ID).getSheetByName('T_' + t); return sh.data.slice(1).map((x) => String(x[0])); };
  assert.ok(!keys('punches').includes('P-OLD'));
  assert.ok(keys('users').includes('U-OWN') && !keys('users').includes('U-STAFF'), 'the owner login stays, staff go');
  const late = asB({ kind: 'push', records: [rec('P-OLD2', '2026-10-02 08:00:00'), rec('P-NEW', '2026-10-06 08:00:00')] });
  assert.ok(late.rejected.some((x) => x.k === 'P-OLD2' && /fresh start/.test(x.why)), 'an old record still waiting on a device is refused');
  assert.ok(keys('punches').includes('P-NEW'), 'new records come in as normal');
});


test('v3.6 devices: pause until a time, end date, roles/shop/name sent back, commands once, remove, wipe; enforced here', () => {
  // A fresh device D linked with an invite.
  const devD = { id: 'dev-acct', name: 'Accountant phone', kind: 'phone' };
  const inv = asA({ kind: 'invite_create', url: 'u' });
  const j = post({ kind: 'join', invite: inv.code, device: devD });
  const asD = (b) => post({ token: j.token, device: devD, ...b });
  assert.ok(asD({ kind: 'pull', since: 0, stat: { pending: 3, health: 'ok', login: { name: 'Acc', at: 'x' } } }).ok);
  assert.strictEqual(asA({ kind: 'devices' }).devices.find((d) => d.id === 'dev-acct').stat.pending, 3);
  assert.match(asA({ kind: 'device_control', id: 'dev-tablet', action: 'suspend', until: '2099-01-01T00:00' }).error, /itself/);
  assert.match(asA({ kind: 'device_control', id: 'dev-acct', action: 'explode' }).error, /Unknown/);
  // Pause.
  assert.ok(asA({ kind: 'device_control', id: 'dev-acct', action: 'suspend', until: '2099-01-01T00:00', by: 'Owner' }).ok);
  let r = asD({ kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.lock.kind, 'suspended');
  assert.ok(asA({ kind: 'device_control', id: 'dev-acct', action: 'allow' }).ok);
  assert.ok(asD({ kind: 'pull', since: 0 }).ok);
  // A pause that has run out ends by itself.
  asA({ kind: 'device_control', id: 'dev-acct', action: 'suspend', until: '2000-01-01T00:00' });
  assert.ok(asD({ kind: 'pull', since: 0 }).ok);
  // End date in the past.
  asA({ kind: 'device_control', id: 'dev-acct', action: 'end', endDate: '2000-01-01' });
  r = asD({ kind: 'pull', since: 0 });
  assert.strictEqual(r.lock.kind, 'ended');
  asA({ kind: 'device_control', id: 'dev-acct', action: 'end', endDate: '' });
  // Settings and commands.
  asA({ kind: 'device_control', id: 'dev-acct', action: 'roles', roles: ['manager'] });
  asA({ kind: 'device_control', id: 'dev-acct', action: 'rename', name: 'Accountant (Ravi)' });
  asA({ kind: 'device_control', id: 'dev-acct', action: 'signout', by: 'Owner' });
  r = asD({ kind: 'pull', since: 0 });
  assert.deepStrictEqual(r.control.roles, ['manager']);
  assert.strictEqual(r.control.name, 'Accountant (Ravi)');
  assert.deepStrictEqual(r.commands.map((c) => c.kind), ['signout']);
  assert.deepStrictEqual(asD({ kind: 'pull', since: 0 }).commands, [], 'a command is given once');
  // Problem log.
  assert.ok(asD({ kind: 'problem_log', text: 'Screen X failed' }).ok);
  assert.match(asA({ kind: 'problem_log_get', id: 'dev-acct' }).text, /Screen X/);
  const dev = asA({ kind: 'devices' }).devices.find((d) => d.id === 'dev-acct');
  assert.ok(dev.hist.length >= 5 && dev.attempts.length >= 2);
  // Wipe: told once, then the device is removed.
  asA({ kind: 'device_control', id: 'dev-acct', action: 'wipe', by: 'Owner' });
  r = asD({ kind: 'pull', since: 0 });
  assert.strictEqual(r.wipe, true);
  r = asD({ kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.removed, true);
  assert.strictEqual(asA({ kind: 'devices' }).devices.find((d) => d.id === 'dev-acct').status, 'removed');
});

test('v3.5 My day: meetings for one day come in from the account calendar (own calendars left out)', () => {
  const main = G.CalendarApp.getDefaultCalendar();
  main.createEvent('Meeting with BSP', new Date('2026-10-12T10:00:00'), new Date('2026-10-12T11:30:00'));
  const priv = main.createEvent('Doctor', new Date('2026-10-12T14:00:00'), new Date('2026-10-12T14:30:00'));
  priv.visibility = 'PRIVATE';
  main.createEvent('Other day', new Date('2026-10-13T09:00:00'), new Date('2026-10-13T10:00:00'));
  const tagged = main.createEvent('Old app task', new Date('2026-10-12T08:00:00'), new Date('2026-10-12T08:15:00'));
  tagged.setTag('ebmd', '1');
  const r = asA({ kind: 'myday_events', date: '2026-10-12' });
  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.events.map((e) => [e.title, e.start, e.end, e.private]), [['Meeting with BSP', '10:00', '11:30', false], ['Doctor', '14:00', '14:30', true]]);
  assert.ok(r.events[0].id);
  assert.strictEqual(asA({ kind: 'myday_events', date: 'nope' }).ok, false, 'bad date refused');
  assert.strictEqual(post({ device: devB, kind: 'myday_events', date: '2026-10-12' }).ok, false, 'needs a linked device');
});

test('v3.5 My day: app tasks go out to a separate "Easy Buys – My day" calendar; sending again replaces the day', () => {
  const items = [{ key: 'ord:1', title: 'Order from Punjas for S1', start: '08:00', end: '08:15' }, { key: 'pay:1', title: 'Pay day', start: '08:15', end: '09:00', note: 'Deadline 12:00' }, { title: 'bad', start: 'x', end: '09:00' }];
  const r = asA({ kind: 'myday_out', date: '2026-10-12', items, calendar: 'Hacked name' });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.events, 2);
  assert.strictEqual(r.calendar, 'Easy Buys – My day');
  const cal = G.CalendarApp.getCalendarsByName('Easy Buys – My day')[0];
  assert.ok(cal, 'calendar made');
  assert.strictEqual(G.CalendarApp.getCalendarsByName('Hacked name').length, 0);
  assert.deepStrictEqual(cal.events.map((e) => e.getTitle()), ['Order from Punjas for S1', 'Pay day']);
  assert.strictEqual(cal.events[0].getTag('ebmd'), '1');
  const again = asA({ kind: 'myday_out', date: '2026-10-12', items: [items[1]] });
  assert.strictEqual(again.events, 1);
  assert.deepStrictEqual(cal.events.map((e) => e.getTitle()), ['Pay day'], 'old tasks of that day replaced');
  asA({ kind: 'myday_out', date: '2026-10-13', items: [items[0]] });
  assert.strictEqual(cal.events.length, 2, 'other days kept');
  assert.strictEqual(G.CalendarApp.getCalendarsByName('Easy Buys – My day').length, 1, 'made only once');
  // The account's own meetings are untouched and the app's tasks never come back in as meetings.
  assert.ok(asA({ kind: 'myday_events', date: '2026-10-12' }).events.every((e) => e.title !== 'Pay day'));
});

test('v3.5: the roster calendar case still works next to My day', () => {
  const r = asA({ kind: 'calendar', weekStart: '2026-10-10', weekEnd: '2026-10-16', shifts: [{ shop: 'S1', date: '2026-10-12', start: '07:00', end: '15:00', name: 'Asha' }] });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.events, 1);
  assert.strictEqual(G.CalendarApp.getCalendarsByName('Easy Buys Roster – S1')[0].events.length, 1);
});


test('1.0 accountant pack email: only to the addresses saved in Admin › Emails (not Off)', () => {
  assert.match(asA({ kind: 'pack_email', subject: 'x', attachments: [] }).error, /No accountant email/);
  asA({ kind: 'push', records: [{ t: 'shared_settings', k: 'email_prefs', u: '2099-01-01 00:00:00', row: { key: 'email_prefs', value: JSON.stringify({ accountant_pack: { mode: 'auto', to: ['acc@example.com'] } }), updated_at: '2099-01-01 00:00:00' } }] });
  const r = asA({ kind: 'pack_email', subject: 'Pack', text: 'hi', attachments: [{ b64: 'QUJD', mime: 'application/vnd.ms-excel', name: 'p.xlsx' }] });
  assert.strictEqual(r.ok, true, r.error);
  assert.strictEqual(r.emailed, 1);
});

// v3.9.4 (script v7): connecting the Viber Channel from a device that signs in with its own pass ("token").
test('Viber Channel setup from a linked device: its own pass stays its pass, the Viber token is kept', () => {
  const calls = [];
  const before = ctx.UrlFetchApp;
  ctx.UrlFetchApp = { fetch: (url, o) => { calls.push({ url, body: JSON.parse(o.payload || '{}'), token: (o.headers || {})['X-Viber-Auth-Token'] });
    const path = url.split('/pa/')[1];
    const out = path === 'get_account_info' ? { status: 0, members: [{ id: 'adm1', role: 'superadmin' }] } : { status: 0 };
    return { getContentText: () => JSON.stringify(out) }; } };
  try {
    const r = asB({ kind: 'viber_setup', viberToken: 'viber-abc-123' });
    assert.ok(r.ok, JSON.stringify(r));
    assert.strictEqual(G.props.VIBER_TOKEN, 'viber-abc-123');
    assert.ok(calls.some((c) => /\/post$/.test(c.url) && c.token === 'viber-abc-123'));
  } finally { ctx.UrlFetchApp = before; delete G.props.VIBER_TOKEN; delete G.props.VIBER_FROM; }
});

console.log(`\n${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
