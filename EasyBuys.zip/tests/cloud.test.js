// The Google cloud program (cloud/Code.gs) run in Node with fake Google services.
// Run: node tests/cloud.test.js
const assert = require('assert');

const { load } = require('./fakeGoogle.cjs');

let passed = 0;
let failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('ok  ', name); } catch (e) { failed++; console.log('FAIL', name, '\n     ', e.stack.split('\n').slice(0, 4).join('\n      ')); }
}

const { G, ctx, post } = load();
const devA = { id: 'dev-tablet', name: 'Shop tablet', kind: 'tablet' };
const devB = { id: 'dev-phone', name: "Brother's phone", kind: 'phone' };
const devC = { id: 'dev-bakers', name: 'Bakers tablet', kind: 'tablet' };
const asA = (b) => post({ key: 'tablet-key-123', device: devA, ...b });
let tokenB;
const asB = (b) => post({ token: tokenB, device: devB, ...b });
const rec = (k, u, extra = {}) => ({ t: 'punches', k, u, row: { uid: k, updated_at: u, ...extra } });

test('setup creates the data sheets and a main-software key; safe to run twice', () => {
  ctx.setup();
  const key = G.props.MAIN_KEY;
  assert.ok(key && key.length > 40);
  ctx.setup();
  assert.strictEqual(G.props.MAIN_KEY, key);
  const ss = G.books[G.props.DATA_ID];
  assert.deepStrictEqual(ss.sheets.map((s) => s.name).sort(), ['Changes', 'Devices', 'Invites']);
  assert.ok(ss.sheets.every((s) => s.text), 'sheets are plain text');
});

test('the first device signs in with the cloud key; a wrong key is refused', () => {
  assert.match(post({ key: 'nope', device: devA, kind: 'ping' }).error, /Wrong cloud key/);
  const r = asA({ kind: 'ping' });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.device, 'dev-tablet');
  assert.strictEqual(r.version, 3);
  const d = asA({ kind: 'devices' }).devices;
  assert.strictEqual(d.length, 1);
  assert.strictEqual(d[0].name, 'Shop tablet');
});

test('no key and no token: refused', () => {
  const r = post({ device: devB, kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false);
});

let invite;
test('invite: code + link code, the cloud key is never inside it', () => {
  invite = asA({ kind: 'invite_create', url: 'https://script.google.com/macros/s/X/exec', by: 'Owner' });
  assert.ok(invite.ok);
  assert.match(invite.code, /^[A-HJ-NP-Z2-9]{8}$/);
  const decoded = JSON.parse(Buffer.from(invite.linkCode.slice(4), 'base64').toString('utf8'));
  assert.deepStrictEqual(decoded, { u: 'https://script.google.com/macros/s/X/exec', i: invite.code });
  assert.ok(!invite.linkCode.includes('tablet-key'));
  assert.strictEqual(invite.emailed, false);
});

test('email invite: bad address refused, good address gets a tap link and the code', () => {
  assert.match(asA({ kind: 'invite_create', url: 'u', email: 'not-an-email' }).error, /does not look right/);
  const r = asA({ kind: 'invite_create', url: 'https://x/exec', email: 'brother@gmail.com', by: 'Divnesh' });
  assert.ok(r.emailed);
  const m = G.mails[G.mails.length - 1];
  assert.strictEqual(m.to, 'brother@gmail.com');
  assert.ok(m.htmlBody.includes('https://x/exec?link=' + encodeURIComponent(r.linkCode)));
  assert.strictEqual(r.linkUrl, 'https://x/exec?link=' + encodeURIComponent(r.linkCode));
  assert.ok(m.htmlBody.includes(r.linkCode));
});

test('join: wrong code refused; right code gives a token once; second use refused', () => {
  assert.match(post({ kind: 'join', invite: 'ZZZZZZZZ', device: devB }).error, /not found/);
  const r = post({ kind: 'join', invite: invite.code.toLowerCase(), device: devB });
  assert.ok(r.ok && r.approved && r.token.length > 40);
  tokenB = r.token;
  assert.match(post({ kind: 'join', invite: invite.code, device: devC }).error, /already been used/);
  assert.strictEqual(asB({ kind: 'ping' }).device, 'dev-phone');
  assert.match(post({ token: 'stolen', device: devB, kind: 'ping' }).error, /not linked/);
});

test('expired invite refused', () => {
  const r = asA({ kind: 'invite_create', url: 'u' });
  const sh = G.books[G.props.DATA_ID].getSheetByName('Invites');
  const row = sh.data.find((x) => x[0] === r.code);
  row[2] = new Date(Date.now() - 1000).toISOString();
  assert.match(post({ kind: 'join', invite: r.code, device: devC }).error, /expired/);
});

test('push and pull: the other device gets the change, not its own', () => {
  const p = asA({ kind: 'push', records: [rec('P1', '2026-10-08 07:58:00', { type: 'IN' }), rec('P2', '2026-10-08 08:01:00', { type: 'IN' })] });
  assert.strictEqual(p.accepted, 2);
  const b = asB({ kind: 'pull', since: 0 });
  assert.deepStrictEqual(b.records.map((r) => r.k), ['P1', 'P2']);
  assert.strictEqual(b.records[0].row.type, 'IN');
  assert.strictEqual(b.records[0].u, '2026-10-08 07:58:00', 'time stays text, not a date');
  assert.strictEqual(b.more, false);
  const a = asA({ kind: 'pull', since: 0 });
  assert.strictEqual(a.records.length, 0, 'own changes are not sent back');
  assert.strictEqual(asB({ kind: 'pull', since: b.next }).records.length, 0);
});

test('newest change wins; an older one is rejected and reported', () => {
  const ok = asB({ kind: 'push', records: [rec('P1', '2026-10-08 09:00:00', { type: 'IN', note: 'fixed by phone' })] });
  assert.strictEqual(ok.accepted, 1);
  const old = asA({ kind: 'push', records: [rec('P1', '2026-10-08 08:30:00', { type: 'IN', note: 'older' })] });
  assert.strictEqual(old.accepted, 0);
  assert.strictEqual(old.rejected[0].k, 'P1');
  const a = asA({ kind: 'pull', since: 2 });
  assert.strictEqual(a.records.length, 1);
  assert.strictEqual(a.records[0].row.note, 'fixed by phone');
});

test('keys that look like numbers keep leading zeros', () => {
  asA({ kind: 'push', records: [{ t: 'shops', k: '007', u: '2026-10-08 10:00:00', row: { code: '007' } }] });
  const r = asB({ kind: 'pull', since: 0 }).records.find((x) => x.t === 'shops');
  assert.strictEqual(r.k, '007');
});

test('change history (audit_log) goes to the main software only', () => {
  asA({ kind: 'push', records: [{ t: 'audit_log', k: 'A1', u: '2026-10-08 10:01:00', row: { uid: 'A1', action: 'Changed PIN' } }] });
  assert.ok(!asB({ kind: 'pull', since: 0 }).records.some((x) => x.t === 'audit_log'));
});

test('bad table names are ignored', () => {
  const r = asA({ kind: 'push', records: [{ t: 'Bad-Name', k: '1', u: 'x', row: {} }, { t: 'punches', u: 'x' }] });
  assert.strictEqual(r.accepted, 0);
});

test('main software: wrong key refused; right key gets everything incl. history; can push down', () => {
  assert.strictEqual(post({ kind: 'main_pull', key: 'guess', since: 0 }).error, 'Not allowed');
  const r = post({ kind: 'main_pull', key: G.props.MAIN_KEY, since: 0 });
  assert.ok(r.records.some((x) => x.t === 'audit_log'));
  assert.ok(r.records.some((x) => x.k === 'P2'));
  const pushed = post({ kind: 'main_push', key: G.props.MAIN_KEY, records: [{ t: 'users', k: 'U9', u: '2026-10-08 11:00:00', row: { uid: 'U9', name: 'New Staff' } }] });
  assert.strictEqual(pushed.accepted, 1);
  assert.ok(asB({ kind: 'pull', since: 0 }).records.some((x) => x.k === 'U9' && x.d === 'main'));
  assert.ok(post({ kind: 'main_devices', key: G.props.MAIN_KEY }).devices.length >= 2);
  assert.ok(G.props.LAST_MAIN_SYNC);
});

test('block a lost device; a device cannot block itself; unblock works', () => {
  assert.match(asA({ kind: 'device_status', id: 'dev-tablet', status: 'blocked' }).error, /cannot block itself/);
  assert.match(asA({ kind: 'device_status', id: 'dev-phone', status: 'deleted' }).error, /active or blocked/);
  assert.ok(asA({ kind: 'device_status', id: 'dev-phone', status: 'blocked' }).ok);
  const r = asB({ kind: 'pull', since: 0 });
  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.blocked, true);
  assert.ok(asA({ kind: 'device_status', id: 'dev-phone', status: 'active' }).ok);
  assert.ok(asB({ kind: 'pull', since: 0 }).ok);
});

test('owner approval (optional): new device waits until approved', () => {
  assert.strictEqual(asA({ kind: 'cloud_settings', requireApproval: true }).requireApproval, true);
  const inv = asA({ kind: 'invite_create', url: 'u' });
  const j = post({ kind: 'join', invite: inv.code, device: devC });
  assert.strictEqual(j.approved, false);
  const w = post({ token: j.token, device: devC, kind: 'pull', since: 0 });
  assert.strictEqual(w.waiting, true);
  asA({ kind: 'device_status', id: 'dev-bakers', status: 'active' });
  assert.ok(post({ token: j.token, device: devC, kind: 'pull', since: 0 }).ok);
  assert.strictEqual(asA({ kind: 'cloud_settings', requireApproval: false }).requireApproval, false);
  assert.strictEqual(asA({ kind: 'cloud_settings' }).requireApproval, false);
});

test('large pulls come in pages', () => {
  const L = load({ pullLimit: 50 });
  L.ctx.setup();
  const A = (b) => L.post({ key: 'tablet-key-123', device: devA, ...b });
  const inv = A({ kind: 'invite_create', url: 'u' });
  const tok = L.post({ kind: 'join', invite: inv.code, device: devB }).token;
  const recs = Array.from({ length: 120 }, (_, i) => rec('R' + String(i).padStart(3, '0'), '2026-10-08 12:00:' + String(i % 60).padStart(2, '0')));
  assert.strictEqual(A({ kind: 'push', records: recs }).accepted, 120);
  let since = 0;
  const got = [];
  for (let i = 0; i < 10; i++) {
    const r = L.post({ token: tok, device: devB, kind: 'pull', since });
    got.push(...r.records.map((x) => x.k));
    since = r.next;
    if (!r.more) break;
  }
  assert.strictEqual(got.length, 120);
  assert.strictEqual(new Set(got).size, 120);
});

test('old Bakery requests still work with the cloud key', () => {
  const r = asA({ kind: 'snapshot', snapshot: { planSeq: 0, hello: 1 }, planSeq: 0 });
  assert.ok(r.ok);
  assert.deepStrictEqual(Array.from(r.planEdits), []);
});

test('the invite link page opens the app, or offers the code to copy; junk is refused', () => {
  const inv = asA({ kind: 'invite_create', url: 'https://script.google.com/macros/s/X/exec' });
  let page = null;
  ctx.HtmlService.createHtmlOutput = (h) => { page = h; return { setTitle() { return this; }, addMetaTag() { return this; } }; };
  ctx.doGet({ parameter: { link: inv.linkCode } });
  assert.ok(page.includes('intent://link?c=' + encodeURIComponent(inv.linkCode) + '#Intent;scheme=easybuys;package=com.easybuys.bakerymanager;end'));
  assert.ok(page.includes('>' + inv.linkCode + '</textarea>'));
  ctx.doGet({ parameter: { link: '"><script>alert(1)</script>' } });
  assert.ok(!page.includes('<script>') && /not complete/.test(page));
});

test('documents: kept in Drive › Documents; fetched back only from there', () => {
  const put = asA({ kind: 'file_put', folder: 'licence', fileName: 'DOC-1-Liquor licence.pdf', mime: 'application/pdf', data: Buffer.from('%PDF-1.4 test').toString('base64') });
  assert.strictEqual(put.ok, true);
  assert.ok(put.id);
  const got = asA({ kind: 'file_get', id: put.id });
  assert.strictEqual(Buffer.from(got.data, 'base64').toString(), '%PDF-1.4 test');
  assert.strictEqual(got.mime, 'application/pdf');
  const photo = asA({ kind: 'photo', refType: 'invoice', refId: 'X', data: 'QUJD', fileName: 'p.jpg', month: '2026-10' });
  const refused = asA({ kind: 'file_get', id: 'file-p.jpg' });
  assert.ok(photo.url);
  assert.strictEqual(refused.ok, false, 'not a document');
});

test('reading invoice photos: off until Drive is added; text comes back when it is', () => {
  assert.strictEqual(asA({ kind: 'ocr', files: [{ data: 'QUJD' }] }).off, true);
  ctx.Drive = { Files: { create: () => ({ id: 'doc1' }) } };
  ctx.DocumentApp = { openById: () => ({ getBody: () => ({ getText: () => 'TOTAL 45.00' }) }) };
  G.DriveApp.getFileById = () => ({ setTrashed() {}, moveTo() {} });
  const r = asA({ kind: 'ocr', files: [{ data: 'QUJD' }, { data: 'REVG' }] });
  assert.strictEqual(r.text, 'TOTAL 45.00\nTOTAL 45.00');
});

console.log(`\n${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
