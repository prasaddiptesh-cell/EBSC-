// Company contract PDF: signatures, stamp and details put onto the company's own PDF.
import fs from 'fs';
import { PDFDocument } from 'pdf-lib';
import { stampContract, cleanLayout, pageCount } from '../src/services/contractPdf.js';
import { test, done, assert } from './harness.js';

import { PDFDocument as Doc, StandardFonts } from 'pdf-lib';
const S = process.env.SCRATCH || '';
// A 3-page "company contract" made here, a tiny signature (PNG) and stamp (JPEG).
const make = async () => { const pdf = await Doc.create(); const f = await pdf.embedFont(StandardFonts.TimesRoman);
  for (let p = 1; p <= 3; p++) { const pg = pdf.addPage([595, 842]); pg.drawText(`EMPLOYMENT CONTRACT page ${p}`, { x: 60, y: 780, size: 16, font: f }); }
  return pdf.saveAsBase64(); };
const tpl = await make();
const sig = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';
const stamp = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAIAAgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDmKKKK90wP/9k=';
const data = { name: 'Mere Tuilau', employer: 'Easy Buys Shopping Centre', job_title: 'Cashier', start_date: '2026-10-12', pay: '$5.60 an hour', shop: 'Shop 2', employee_no: 'EB010',
  contractNo: 'CT-TEST', empSig: sig, empAt: '2026-10-09 10:00:00', dirSig: sig, dirName: 'Divnesh Avnil Prasad', dirAt: '2026-10-09 11:00:00', stamp };

test('signing page added; initials on every page', async () => {
  const out = await stampContract(tpl, { signPage: true, initialsEachPage: true }, data);
  assert.strictEqual(await pageCount(out), 4);
  if (S) fs.writeFileSync(`${S}/out1.pdf`, Buffer.from(out, 'base64'));
});

test('signatures, stamp and details placed on the last page; no extra page', async () => {
  const layout = cleanLayout({ signPage: false, initialsEachPage: false, items: [
    { what: 'emp_sig', page: 'last', x: 26, y: 78, w: 22 }, { what: 'dir_sig', page: 'last', x: 66, y: 78, w: 22 },
    { what: 'stamp', page: 'last', x: 70, y: 60, w: 18 }, { what: 'emp_name', page: 1, x: 10, y: 8, w: 40 }, { what: 'bogus', page: 1 } ] });
  assert.strictEqual(layout.items.length, 4, 'unknown items dropped');
  const out = await stampContract(tpl, layout, data);
  const pdf = await PDFDocument.load(out);
  assert.strictEqual(pdf.getPageCount(), 3);
  if (S) fs.writeFileSync(`${S}/out2.pdf`, Buffer.from(out, 'base64'));
});

test('a page number past the end goes on the last page; nothing missing does not break it', async () => {
  const out = await stampContract(tpl, { signPage: true, items: [{ what: 'stamp', page: 9, x: 50, y: 50, w: 20 }] }, { ...data, stamp: null, dirSig: null });
  assert.strictEqual(await pageCount(out), 4);
});

done();
