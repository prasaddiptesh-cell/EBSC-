// 3.9.2 Cheque cover: a deposit says which cheques (or invoices about to be paid by cheque) it covers, extra money is
// fine; a cheque handed over without cover is flagged (urgent after 2 days), a post-dated cheque reminds before its date
// and is urgent on it, an invoice covered before it is paid passes its cover to the cheque that pays it, the bank short
// for the cheques out is flagged, a voided deposit takes its cover away, a cleared cheque drops off the list.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as CB from '../src/modules/payables/chequebooks.js';
import * as T from '../src/modules/till/service.js';
import * as CV from '../src/modules/payables/cover.js';
import * as A from '../src/modules/accounting/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (d) => { clock.override = new Date(`${d}T17:00:00`); };
at('2026-10-05');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const bank = AP.saveAccount(owner, { name: 'BSP', openingBalance: 200, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 500, lastNo: 549 });
const punjas = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const flour = AP.saveSupplier(owner, { name: 'Flour Mills', tin: '502345678', onAccount: true, termsDays: 30 });
// cash at the shop to deposit
T.recordCash(owner, { type: 'opening', shopCode: 'S1', amount: 5000, date: '2026-10-01', note: 'start' });
const inv = (sup, no, total, date = '2026-10-03') => AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: no, invoiceDate: date, total, shopCode: 'S1' }, { canCheck: true });
const pay = (sup, i, chequeNo, extra = {}) => AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: bank.uid, chequeNo, payDate: clock.override.toISOString().slice(0, 10), allocations: [{ invoiceUid: i.uid, amount: i.total }], ...extra });
const chq = (no) => db().get('SELECT * FROM cheques WHERE cheque_no = ?', [no]);
const dep = (slip, cash, covers, date) => T.saveDeposit(mgr, { shopCode: 'S1', accountUid: bank.uid, date: date || clock.override.toISOString().slice(0, 10), slipNo: slip, byNotes: false, cashAmount: cash, cheques: [], covers });
const find = (no) => CV.openCheques().find((c) => c.no === no);

test('a cheque written, not handed over: prepared, nothing urgent', () => {
  pay(punjas, inv(punjas, 'P1', 450), 500);
  const c = find(500);
  assert.strictEqual(c.state, 'prepared'); assert.strictEqual(c.left, 450); assert.strictEqual(c.level, null);
});
test('handed over without cover: warning the same day, urgent after 2 days', () => {
  CB.markHandedOver(owner, chq(500).uid, { date: '2026-10-05', to: 'Punjas driver' });
  assert.strictEqual(find(500).level, 'warning');
  at('2026-10-07');
  assert.strictEqual(find(500).level, 'urgent');
  const al = CV.coverAlerts();
  assert.ok(al.some((a) => a.id === 'cover-handed' && a.level === 'urgent' && /no deposit/.test(a.text)), JSON.stringify(al));
});
test('a deposit covers it (with extra money – fine): covered, no warning; the deposit lists what it covered', () => {
  const ch = CV.coverChoices({ accountUid: bank.uid });
  assert.ok(ch.cheques.some((c) => c.no === 500 && c.left === 450));
  const d = dep('7001', 1000, [{ chequeUid: chq(500).uid, amount: 450 }]);
  assert.strictEqual(find(500).left, 0);
  assert.ok(!CV.coverAlerts().some((a) => a.id === 'cover-handed'));
  assert.deepStrictEqual(CV.depositCovers(d.uid).map((x) => [x.kind, x.amount]), [['cheque', 450]]);
});
test('a deposit cannot cover more than it is, or more than a cheque needs', () => {
  pay(punjas, inv(punjas, 'P2', 300), 501);
  throws(() => dep('7002', 100, [{ chequeUid: chq(501).uid, amount: 300 }]), /more than this deposit/);
  throws(() => dep('7003', 1000, [{ chequeUid: chq(501).uid, amount: 350 }]), /only needs/);
  dep('7004', 200, [{ chequeUid: chq(501).uid, amount: 200 }]); // part cover
  assert.strictEqual(find(501).left, 100);
});
test('an invoice covered before it is paid: the cheque that pays it is covered', () => {
  const i = inv(flour, 'F1', 800);
  assert.ok(CV.invoicesToCover().some((x) => x.uid === i.uid));
  dep('7005', 800, [{ invoiceUid: i.uid, amount: 800 }]);
  pay(flour, i, 502);
  assert.strictEqual(find(502).left, 0, 'covered through the invoice');
});
test('post-dated cheque (on account): reminder 3 days before, urgent on the date; handing it over early is allowed', () => {
  const i = inv(flour, 'F2', 1200);
  pay(flour, i, 503, { chequeDate: '2026-10-20' });
  const c = chq(503);
  assert.strictEqual(c.cheque_date, '2026-10-20');
  CB.markHandedOver(owner, c.uid, { date: '2026-10-07', to: 'Flour Mills rep' });
  assert.strictEqual(find(503).state, 'post_dated');
  assert.strictEqual(find(503).level, null, 'not yet – 13 days to go');
  at('2026-10-17');
  assert.strictEqual(find(503).level, 'warning');
  assert.ok(CV.coverAlerts().some((a) => a.id === 'cover-post'));
  at('2026-10-20');
  assert.strictEqual(find(503).level, 'urgent');
  throws(() => AP.makePayment(owner, { supplierUid: flour.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 504, payDate: '2026-10-20', chequeDate: '2026-10-19', allocations: [{ invoiceUid: inv(flour, 'F3', 10).uid, amount: 10 }] }), /payment date or later/);
});
test('the bank is short for the cheques out: flagged with the amount', () => {
  // book: 200 opening + deposits 1000+200+800 = 2200; cheques out 450+300+800+1200 = 2750 → short 550
  const p = CV.coverPicture();
  const a = p.accounts.find((x) => x.uid === bank.uid);
  assert.ok(a.short > 0, JSON.stringify(a));
  assert.ok(CV.coverAlerts().some((x) => x.id === `cover-short-${bank.uid}` && x.level === 'urgent'));
  dep('7006', 1200, [{ chequeUid: chq(503).uid, amount: 1200 }]);
  const a2 = CV.coverPicture().accounts.find((x) => x.uid === bank.uid);
  assert.ok(a2.short === 0, JSON.stringify(a2));
});
test('a voided deposit takes its cover away; a cheque the bank paid drops off the list', () => {
  const d = T.listDeposits({}).find((x) => x.slip_no === '7006');
  T.voidDeposit(owner, d.uid, 'wrong slip');
  assert.strictEqual(find(503).left, 1200);
  AP.markPresented(owner, chq(500).uid, '2026-10-20');
  assert.ok(!find(500));
  const tb = A.trialBalance('2026-12-31');
  assert.ok(tb.ok);
});
done();
