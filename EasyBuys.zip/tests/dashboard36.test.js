// 3.6 dashboard "today" cards and the card builder.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, dateStr, addDays } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as D from '../src/services/dashboardCards.js';
import '../src/modules/dashboard/cards.js';
import * as B from '../src/modules/dashboard/cards36.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-10T11:00:00'); // a Saturday (pay day)
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const T = dateStr();
const now = '2026-10-10 10:00:00';
const ins = (sql, a) => db().run(sql, a);

test('every card works out on an empty database (no errors)', () => {
  for (const c of D.listCards()) {
    const r = D.buildCard(c.id, { from: addDays(T, -30), to: T }, 'ALL', owner);
    assert.ok(r.title && !/Could not work/.test(r.text || ''), `${c.id}: ${r.text}`);
  }
});
test('today cards: deliveries in, deliveries due (late in red), cheques, invoices with no photo / TIN, pay day event', () => {
  ins("INSERT INTO inv_receipts (uid, kind, supplier_name, shop_code, receive_date, total, invoice_no, status, created_at, updated_at) VALUES ('r1','receive','Punjas','S1',?,432.5,'INV-9','active',?,?)", [T, now, now]);
  ins("INSERT INTO po_orders (uid, po_no, supplier_uid, supplier_name, shop_code, order_date, expected_date, status, total, updated_at) VALUES ('p1','PO-1','s1','FMF','S2',?,?,'sent',120,?), ('p2','PO-2','s1','Rewa','S1',?,?,'sent',80,?)",
    [addDays(T, -3), addDays(T, -1), now, addDays(T, -1), T, now]);
  ins("INSERT INTO cheques (uid, account_uid, cheque_no, cheque_date, payee, amount, status, updated_at) VALUES ('c1','a1',100201,?,'Punjas',500,'written',?)", [T, now]);
  ins("INSERT INTO ap_invoices (uid, supplier_name, invoice_no, invoice_date, received_date, shop_code, due_date, total, status, updated_at) VALUES ('i1','Punjas','INV-9',?,?,'S1',?,432.5,'to_check',?)", [T, T, addDays(T, 30), now]);
  const p = { from: T, to: T };
  const dl = D.buildCard('deliveries_today', p, 'ALL', owner);
  assert.strictEqual(dl.value, '$432.50');
  const due = D.buildCard('deliveries_due', p, 'ALL', owner);
  assert.strictEqual(due.tone, 'bad', 'one is late');
  assert.ok(due.lines.some(([k, v]) => /FMF/.test(k) && /late/.test(v)));
  assert.strictEqual(D.buildCard('deliveries_due', p, 'S1', owner).tone, 'warn', 'S1 only: due today, not late');
  const ch = D.buildCard('cheques_issued', p, 'ALL', owner);
  assert.ok(/1 not presented/.test(ch.sub));
  const inv = D.buildCard('invoices_today', p, 'ALL', owner);
  assert.ok(inv.lines.some(([k]) => k === 'No photo') && inv.lines.some(([k]) => k === 'No TIN'));
  const ev = B.eventsToday('ALL', owner);
  assert.ok(ev.some((e) => /Pay day/.test(e.text)));
  assert.ok(ev.some((e) => /Delivery due: FMF/.test(e.text)));
  assert.ok(!B.eventsToday('S1', owner).some((e) => /FMF/.test(e.text)), 'S2 order not in S1 events');
});
test('card builder: owner makes a card with colours; managers cannot; removing it takes it off', () => {
  const c = B.saveCustomCard(owner, { title: 'Received today', metric: 'received', today: true, goodFrom: '400' });
  const r = D.buildCard(c.id, { from: addDays(T, -30), to: T }, 'ALL', owner);
  assert.strictEqual(r.value, '$432.50'); assert.strictEqual(r.tone, 'good');
  assert.ok(D.userLayout(owner).order.includes(c.id));
  let msg = '';
  try { B.saveCustomCard(mgr, { metric: 'sales' }); } catch (e) { msg = e.message; }
  assert.ok(/owner or admin/.test(msg));
  B.deleteCustomCard(owner, c.id);
  assert.ok(!D.getCard(c.id));
});
done();
