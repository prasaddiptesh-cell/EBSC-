// 3.9.3 Document layout: parts placed left / centre / right, half-width parts side by side, details in 2 columns,
// table columns left out, a comment typed when the document is made (name and time printed), older layouts get the
// new Comments part in its place.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { saveUser } from '../src/services/catalog.js';
import * as DD from '../src/services/docDesign.js';
import { reportToHtml, reportToCsv } from '../src/services/export.js';
import { prepareDoc } from '../src/services/docOutput.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const rep = { kind: 'po', title: 'Purchase Order PO-1', info: [['To', 'Punjas'], ['Order date', '2026-10-11'], ['Ordered by', 'Sita']], summary: [{ label: 'Items', value: '2' }],
  sections: [{ title: 'Please supply', columns: [{ key: 'n', title: '#' }, { key: 'code', title: 'Code' }, { key: 'name', title: 'Product' }], rows: [{ n: 1, code: 'X1', name: 'Rice' }], totals: [{ label: 'TOTAL (incl. VAT)', value: '$10.00', strong: true }] }] };

test('an old saved layout gets the new Comments part right after Notes', () => {
  const old = DD.defaultDesign('po'); old.parts = old.parts.filter((p) => p.key !== 'comment');
  const d = DD.normalizeDesign('po', old);
  const keys = d.parts.map((p) => p.key);
  assert.strictEqual(keys[keys.indexOf('note') + 1], 'comment');
});
test('placement, 2-column details, hidden columns, renamed labels', () => {
  let d = DD.getDesign('po');
  d = DD.setPartLayout(d, 'info', { width: 'half' });
  d = DD.setPartLayout(d, 'summary', { width: 'half', align: 'right' });
  d = { ...d, infoCols: 2, hideCols: ['Code'], labels: { 'Ordered by': 'Prepared by' } };
  DD.saveDesign(owner, 'po', d);
  const html = reportToHtml(prepareDoc(rep));
  assert.ok(/class="halves"/.test(html) && /text-align:right/.test(html), 'side by side, right');
  assert.ok(/<tr><th>To<\/th><td>Punjas<\/td><th>Order date<\/th>/.test(html), '2 columns of details');
  assert.ok(!/>Code</.test(html) && />Product</.test(html), 'Code column left out');
  assert.ok(/Prepared by/.test(html) && /TOTAL \(incl\. VAT\)/.test(html));
  assert.strictEqual(DD.getDesign('po').infoCols, 2);
});
test('a comment is printed with who and when (PDF and Excel / CSV)', () => {
  const r = { ...rep, comments: [{ text: 'Deliver to the back door', by: 'Sita (Supervisor)', at: '2026-10-11 14:05' }] };
  const html = reportToHtml(prepareDoc(r));
  assert.ok(/Comment – Sita \(Supervisor\) · 2026-10-11 14:05/.test(html) && /Deliver to the back door/.test(html));
  assert.ok(/Deliver to the back door/.test(reportToCsv(r)));
  const d = DD.getDesign('po'); DD.saveDesign(owner, 'po', { ...d, parts: d.parts.map((p) => (p.key === 'comment' ? { ...p, on: false } : p)), askComment: true });
  assert.ok(!/Deliver to the back door/.test(reportToHtml(prepareDoc(r))), 'the part can be switched off');
  assert.strictEqual(DD.getDesign('po').askComment, true);
});
done();
