// Linking devices: codes, joining, first sync between two devices through the (fake) Google cloud.
import { createRequire } from 'module';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { setDb, db } from '../src/db/connection.js';
import { setSetting, getSetting } from '../src/services/core.js';
import { saveUser, login } from '../src/services/catalog.js';
import { parseLinkCode, b64WebSafeEncode, b64WebSafeDecode, joinWithCode, linkState, sampleLoginsActive, inviteMessage, unlinkThisDevice } from '../src/modules/devices/service.js';
import { syncNow, cloudCall } from '../src/platform/cloud.js';
import { qrMatrix } from '../src/ui/qrMatrix.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert, throws, atest as runAsync } from './harness.js';

const require = createRequire(process.cwd() + '/tests/');
const { load } = require('./fakeGoogle.cjs');
const CLOUD = 'https://script.google.com/macros/s/TEST/exec';
const G = load();
G.ctx.setup();
let offline = false;
globalThis.fetch = async (url, opts) => {
  if (offline) throw new TypeError('Network request failed');
  assert.strictEqual(url, CLOUD);
  const text = G.post(JSON.parse(opts.body));
  return { status: 200, text: async () => JSON.stringify(text) };
};

// Two devices, each with its own database. Only one is "active" at a time.
const tablet = openNodeDb();
const phone = openNodeDb();
const use = (d) => setDb(d);
initDatabase(tablet);
use(phone); initDatabase(phone);

const asyncTests = [];
const atest = (name, fn) => asyncTests.push([name, fn]);

test('link codes: round trip, tap link, whole message, bad codes', () => {
  const code = 'EB1-' + b64WebSafeEncode(JSON.stringify({ u: CLOUD, i: 'ABCD2345' }));
  assert.deepStrictEqual(parseLinkCode(code), { url: CLOUD, invite: 'ABCD2345', code });
  assert.strictEqual(parseLinkCode(`easybuys://link?c=${encodeURIComponent(code)}`).invite, 'ABCD2345');
  assert.strictEqual(parseLinkCode(inviteMessage({ linkCode: code }, 'Divnesh')).invite, 'ABCD2345');
  assert.strictEqual(parseLinkCode(`${CLOUD}?link=${encodeURIComponent(code)}`).invite, 'ABCD2345');
  assert.strictEqual(b64WebSafeDecode(b64WebSafeEncode('Bula – ā')), 'Bula – ā');
  throws(() => parseLinkCode('hello'), /starts with EB1-/);
  throws(() => parseLinkCode(code.slice(0, 20)), /not complete/);
  throws(() => parseLinkCode('EB1-' + b64WebSafeEncode(JSON.stringify({ u: 'https://evil.example/x', i: 'ABCD2345' }))), /Easy Buys cloud/);
});

test('QR code for a real invite fits comfortably on screen', () => {
  const code = 'EB1-' + b64WebSafeEncode(JSON.stringify({ u: 'https://script.google.com/macros/s/AKfycbz' + 'x'.repeat(70) + '/exec', i: 'ABCD2345' }));
  const m = qrMatrix(code);
  assert.ok(m.length >= 21 && m.length <= 73, `size ${m.length}`);
  assert.ok(m[0][0] && m[0][6] && !m[0][7], 'finder pattern in the corner');
});

test('fresh install: sample logins are local-only and never sent', () => {
  use(tablet);
  assert.strictEqual(sampleLoginsActive().length, 4);
  assert.ok(!pendingRecords(500).some((r) => r.t === 'users'), 'no sample user waiting to be sent');
});

atest('first tablet links with the cloud key and sends its real staff (not the samples)', async () => {
  use(tablet);
  const admin = login('1111');
  const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner', employeeNo: 'EB001' }, admin);
  saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
  setSetting('cloud_url', CLOUD);
  setSetting('cloud_key', 'tablet-key-123');
  setSetting('device_name', 'Shop 2 tablet');
  const r = await syncNow({ force: true });
  assert.strictEqual(r.error, null, r.error);
  const users = G.G.books[G.G.props.DATA_ID].getSheetByName('T_users').data.slice(1).map((x) => JSON.parse(x[4]).name);
  assert.ok(users.includes('Divnesh Prasad') && users.includes('Mere Tuilau'));
  assert.ok(!users.includes('Admin') && !users.includes('Ravi'), 'samples stay on the tablet');
  assert.strictEqual(linkState().method, 'key');
});

let invite;
atest('owner makes an invite from the tablet (no Google editor needed)', async () => {
  use(tablet);
  invite = await cloudCall({ kind: 'invite_create', url: CLOUD, by: 'Divnesh' });
  assert.strictEqual(parseLinkCode(invite.linkCode).url, CLOUD);
});

atest('phone joins with the code, gets the staff, drops the sample logins', async () => {
  use(phone);
  await assert.rejects(joinWithCode(invite.linkCode, { name: '', kind: 'phone' }), /Give this device a name/);
  offline = true;
  await assert.rejects(joinWithCode(invite.linkCode, { name: 'Brother phone', kind: 'phone' }), /No internet/);
  offline = false;
  assert.strictEqual(linkState().linked, false, 'nothing saved when offline');
  const j = await joinWithCode(invite.linkCode, { name: 'Brother phone', kind: 'phone' });
  assert.strictEqual(j.approved, true);
  assert.strictEqual(linkState().method, 'invite');
  assert.strictEqual(getSetting('cloud_key', ''), '', 'phone never holds the cloud key');
  assert.strictEqual(getSetting('clock_here'), '0', 'phones do not show the Time Clock by default');
  const s = await syncNow({ force: true });
  assert.strictEqual(s.error, null, s.error);
  assert.ok(s.received >= 2);
  assert.strictEqual(login('9999').name, 'Divnesh Prasad');
  assert.strictEqual(login('1111'), null, 'sample Admin switched off');
  assert.strictEqual(sampleLoginsActive().length, 0);
  assert.strictEqual(getSetting('show_demo_pins'), '0');
});

atest('the same invite cannot be used twice', async () => {
  const third = openNodeDb();
  use(third); initDatabase(third);
  await assert.rejects(joinWithCode(invite.linkCode, { name: 'Stranger', kind: 'phone' }), /already been used/);
  assert.strictEqual(sampleLoginsActive().length, 4, 'a failed link changes nothing');
});

atest('changes made on the phone reach the tablet', async () => {
  use(phone);
  const owner = login('9999');
  saveUser({ name: 'Ravi Kumar', pin: '1357', role: 'staff', employeeNo: 'EB011', shopCode: 'S1' }, owner);
  assert.strictEqual((await syncNow({ force: true })).error, null);
  use(tablet);
  await syncNow({ force: true });
  assert.strictEqual(login('1357').name, 'Ravi Kumar');
  assert.strictEqual(login('1111').name, 'Admin', 'the first tablet keeps its own sample login until the owner switches it off');
});

atest('blocked phone stops syncing with a clear message; unblocked works again', async () => {
  use(tablet);
  const phoneId = (() => { use(phone); const id = getSetting('device_id'); use(tablet); return id; })();
  await cloudCall({ kind: 'device_status', id: phoneId, status: 'blocked' });
  use(phone);
  const r = await syncNow({ force: true });
  assert.match(r.error, /blocked/);
  use(tablet);
  await cloudCall({ kind: 'device_status', id: phoneId, status: 'active' });
  use(phone);
  assert.strictEqual((await syncNow({ force: true })).error, null);
});

atest('approval on: a new device waits, then syncs once allowed', async () => {
  use(tablet);
  await cloudCall({ kind: 'cloud_settings', requireApproval: true });
  const inv = await cloudCall({ kind: 'invite_create', url: CLOUD, by: 'Divnesh' });
  const bakers = openNodeDb();
  use(bakers); initDatabase(bakers);
  const j = await joinWithCode(inv.linkCode, { name: 'Bakers tablet', kind: 'tablet' });
  assert.strictEqual(j.approved, false);
  const r = await syncNow({ force: true });
  assert.match(r.error, /approve/);
  assert.strictEqual(linkState().waiting, true);
  const id = getSetting('device_id');
  use(tablet);
  await cloudCall({ kind: 'device_status', id, status: 'active' });
  await cloudCall({ kind: 'cloud_settings', requireApproval: false });
  use(bakers);
  assert.strictEqual((await syncNow({ force: true })).error, null);
  assert.strictEqual(linkState().waiting, false);
  assert.strictEqual(login('9999').name, 'Divnesh Prasad');
});

atest('unlink: stops syncing, keeps the data', async () => {
  use(phone);
  unlinkThisDevice(login('9999'));
  assert.strictEqual(linkState().linked, false);
  assert.strictEqual(login('9999').name, 'Divnesh Prasad');
  assert.ok((await syncNow()).skipped);
});

for (const [name, fn] of asyncTests) await runAsync(name, fn);
done();
