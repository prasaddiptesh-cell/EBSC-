// Go-live devices: who may log in here, end date, lock screen kinds (a pause runs out by itself), remote wipe clears the
// business data and the link, sign-out command, device warnings for the owner.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, getSetting, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as D from '../src/modules/devices/control.js';
import { deviceWarnings } from '../src/modules/devices/alerts.js';
import { atest, test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const staff = saveUser({ name: 'Cashier', pin: '7777', role: 'staff', shopCode: 'S1' }, owner);

test('roles allowed and end date from the owner; the owner always may log in', () => {
  D.applyControl({ roles: ['manager'], endDate: null, shop: 'S2', name: 'Shop 2 tablet' });
  assert.strictEqual(getSetting('device_shop', ''), 'S2');
  assert.strictEqual(getSetting('device_name', ''), 'Shop 2 tablet');
  assert.strictEqual(D.loginBlockedHere(mgr), null);
  assert.ok(D.loginBlockedHere(staff));
  assert.strictEqual(D.loginBlockedHere(owner), null);
  D.applyControl({ roles: [], endDate: '2026-10-01' });
  assert.match(D.loginBlockedHere(staff), /ended/);
  D.applyControl({ roles: [], endDate: null });
  assert.strictEqual(D.loginBlockedHere(staff), null);
});
test('lock screen: blocked, paused (ends by itself), removed', () => {
  assert.strictEqual(D.deviceLock(), null);
  D.setDeviceLock({ kind: 'suspended', until: '2026-10-12T08:00' });
  assert.strictEqual(D.deviceLock(), null, 'the pause has run out');
  D.setDeviceLock({ kind: 'suspended', until: '2026-10-13T08:00' });
  assert.strictEqual(D.deviceLock().kind, 'suspended');
  D.setDeviceLock(null);
  setSetting('device_blocked', '1');
  assert.strictEqual(D.deviceLock().kind, 'blocked');
  setSetting('device_blocked', '0');
});
await atest('commands: sign everyone out; send the problem log', async () => {
  const sent = [];
  const done1 = await D.runCommands([{ kind: 'signout' }, { kind: 'log' }], { send: async (b) => sent.push(b) });
  assert.deepStrictEqual(done1, ['signout', 'log']);
  assert.ok(getSetting('force_logout', ''));
  assert.strictEqual(sent[0].kind, 'problem_log');
});
test('stats sent with each pull', () => {
  D.noteLogin(mgr);
  const s = D.deviceStat(4);
  assert.strictEqual(s.pending, 4);
  assert.strictEqual(s.login.name, 'Mgr');
});
test('warnings: not synced for a day, new device, blocked device tried to connect', () => {
  const now = new Date('2026-10-12T09:00:00Z').getTime();
  const w = deviceWarnings([
    { id: 'a', name: 'Shop 2 tablet', status: 'active', last_seen: '2026-10-10T09:00:00Z', first_seen: '2026-01-01T00:00:00Z' },
    { id: 'b', name: 'New phone', status: 'active', last_seen: '2026-10-12T08:59:00Z', first_seen: '2026-10-12T08:00:00Z', invited_by: 'Owner @ x' },
    { id: 'c', name: 'Lost phone', status: 'blocked', last_seen: '2026-10-01T00:00:00Z', first_seen: '2026-01-01T00:00:00Z', attempts: [{ at: '2026-10-12T07:00:00Z', why: 'blocked' }] },
  ], { now, staleHours: 24 });
  assert.deepStrictEqual(w.map((x) => x.id.split('-').slice(0, 3).join('-')), ['dev-stale-a', 'dev-new-b', 'dev-try-c']);
  assert.strictEqual(w[2].level, 'urgent');
});
test('remote wipe: business data and the cloud link are cleared; the device shows "wiped"', () => {
  setSetting('cloud_url', 'https://script.google.com/x'); setSetting('cloud_token', 'tok');
  assert.ok(db().get('SELECT COUNT(*) n FROM users').n > 0);
  D.wipeThisDevice();
  assert.strictEqual(db().get('SELECT COUNT(*) n FROM users').n, 0);
  assert.strictEqual(db().get('SELECT COUNT(*) n FROM audit_log').n, 0);
  assert.strictEqual(getSetting('cloud_token', ''), '');
  assert.strictEqual(D.deviceLock().kind, 'wiped');
});
done();
