// 1.0 documents: layout per type (parts, order, own text, paper, versions), who may see each type, the barcode check
// (genuine / changed / not found), settings checks.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as DD from '../src/services/docDesign.js';
import * as DR from '../src/services/driveDocs.js';
import * as IS from '../src/services/issuedDocs.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const cashier = saveUser({ name: 'Cashier', pin: '7777', role: 'staff', shopCode: 'S1' }, owner);
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);

test('layout: parts on/off and order, own text, 80 mm paper, earlier versions can be put back', () => {
  const t = DD.DOC_TYPES[0].id;
  let d = DD.getDesign(t);
  d = DD.togglePart(d, 'qr');
  d = DD.movePart(d, 'footer', -1);
  d = DD.addText(d, 'Thank you – {business}');
  d = { ...d, paper: '80mm' };
  DD.saveDesign(owner, t, d, 'first');
  const s = DD.getDesign(t);
  assert.ok(DD.partOn(s, 'qr'));
  assert.strictEqual(s.paper, '80mm');
  assert.strictEqual(s.texts[0].text, 'Thank you – {business}');
  clock.override = new Date('2026-10-12T09:05:00');
  DD.resetDesign(owner, t);
  assert.strictEqual(DD.getDesign(t).texts.length, 0);
  const v = DD.designVersions(t).find((x) => x.note === 'first');
  DD.restoreDesignVersion(owner, t, v.at);
  assert.strictEqual(DD.getDesign(t).paper, '80mm');
  throws(() => DD.saveDesign(owner, 'nope', d), /Unknown/);
});
test('visibility: owner decides; owner/admin always see; restricted payroll papers hidden from managers', () => {
  assert.ok(DR.canSeeDocType(owner, 'contract'));
  assert.ok(!DR.canSeeDocType(mgr, 'contract'));
  throws(() => DR.saveDocVisibility(mgr, {}), /Only the owner/);
  const v = DR.docVisibility();
  DR.saveDocVisibility(owner, { ...v, contract: v.contract.concat(['manager']) });
  assert.ok(DR.canSeeDocType(mgr, 'contract'));
  assert.ok(!DR.canSeeDocType(cashier, 'contract'));
});
test('settings: tablet copies 7+ days, backup hour 0–23', () => {
  throws(() => DR.saveDocSettings(owner, { retentionDays: 2 }), /7 and 3650/);
  throws(() => DR.saveDocSettings(owner, { retentionDays: 30, backupHour: 30 }), /0 to 23/);
  assert.strictEqual(DR.saveDocSettings(owner, { retentionDays: 30, backupHour: 22 }).backupHour, 22);
});
test('barcode check: genuine, changed, not found, not ours', () => {
  const rep = { kind: 'po', title: 'Purchase order PO-1', fileName: 'PO-1', info: [['Supplier', 'Punjas']], sections: [] };
  const id = IS.docIdentity(rep);
  IS.recordIssued(rep, id, { user: owner, how: 'print' });
  assert.strictEqual(IS.verifyDocCode(id.code).verdict, 'genuine');
  assert.strictEqual(IS.verifyDocCode(`EBD-${id.ref}-00000000`).verdict, 'changed');
  assert.strictEqual(IS.verifyDocCode('EBD-XX-1234567-ABCDEF12').verdict, 'not_found');
  assert.strictEqual(IS.verifyDocCode('hello').verdict, 'not_ours');
});
done();
