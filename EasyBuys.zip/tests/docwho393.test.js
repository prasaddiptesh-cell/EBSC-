// 3.9.3 Every report and document says who requested it and when; the document fingerprint (barcode check) stays the
// same whoever makes a copy; the "show Generated" setting turns it off; automatic ones say "Easy Buys app (automatic)".
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { setErrorUser } from '../src/services/errorLog.js';
import { prepareDoc } from '../src/services/docOutput.js';
import { saveReportTemplate, reportTemplate } from '../src/services/reportTemplate.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T13:25:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sita = saveUser({ name: 'Sita Devi', pin: '1212', role: 'supervisor', shopCode: 'S1' }, owner);
const rep = () => ({ kind: 'till_summary', title: 'Till summary', fileName: 'Till-summary', info: [['Shop', 'S1'], ['Generated', 'old']], summary: [], sections: [{ title: 'X', columns: [{ key: 'a', title: 'A' }], rows: [{ a: '1' }] }] });
const val = (r, k) => (r.info.find(([x]) => x === k) || [])[1];

test('the person who requested it, with their role, and the time', () => {
  setErrorUser(sita);
  const r = prepareDoc(rep());
  assert.strictEqual(val(r, 'Requested by'), 'Sita Devi (Supervisor)');
  assert.strictEqual(val(r, 'Generated'), '2026-10-11 13:25');
  assert.ok(/^Requested by Sita Devi \(Supervisor\) · 2026-10-11 13:25/.test(r.appLine), r.appLine);
  assert.strictEqual(r.info.filter(([k]) => k === 'Generated').length, 1);
});
test('the same document made by someone else has the same fingerprint', () => {
  setErrorUser(sita); const a = prepareDoc(rep());
  setErrorUser(owner); clock.override = new Date('2026-10-12T08:00:00'); const b = prepareDoc(rep());
  assert.strictEqual(a._identity.hash, b._identity.hash);
  assert.ok(/Owner/.test(val(b, 'Requested by')));
});
test('made automatically (nobody logged in)', () => {
  setErrorUser(null);
  assert.strictEqual(val(prepareDoc(rep()), 'Requested by'), 'Easy Buys app (automatic)');
});
test('Report layout › "Show Generated" off hides it', () => {
  saveReportTemplate(owner, { ...reportTemplate(), showGenerated: false });
  setErrorUser(sita);
  const r = prepareDoc(rep());
  assert.ok(!val(r, 'Requested by'));
  saveReportTemplate(owner, { ...reportTemplate(), showGenerated: true });
});
done();
