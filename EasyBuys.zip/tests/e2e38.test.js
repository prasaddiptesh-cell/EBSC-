import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
initDatabase(openNodeDb());
console.log(db().all('SELECT id, uid, name, role, shop_code, sync_status FROM users'));
for (const t of ['till_counts','ap_invoices','inv_items','inv_moves','pay_runs','punches','deposits','bank_accounts','materials','products','shifts','ap_suppliers','leave_requests','shops']) { try { console.log(t, db().get(`SELECT COUNT(*) n FROM ${t}`).n); } catch(e) { console.log(t, 'ERR', e.message); } }
console.log(db().all('SELECT * FROM shops'));
console.log(db().all('SELECT id,name,stock,unit,kg_per_unit,cost_per_unit,track_stock FROM materials'));
console.log(db().all('SELECT id,name,flour_material_id,max_flour_kg,default_flour_kg FROM products'));
console.log(clock.now && clock.now());
