// v3.9 realistic month, start to end, across the modules – and the numbers must agree everywhere:
// order → delivery counted in (stock, cost, bakery flour) → invoice joined to the order → split & part payments
// (cheque register, bank) → a paid rent receipt → sales (VAT) → staff pay runs (FNPF 8% + 8%) → stock take loss →
// VAT return and FNPF schedule lodged and paid → the ledger balances, the VAT and FNPF accounts are cleared,
// the bank account agrees with its lines, the accountant can only look, the watchdog and warnings run clean.
import { openNodeDb } from './nodeDb.js';
import { initDatabase, allowNewRoles } from '../src/db/init.js';
import { db, setWriteGuard } from '../src/db/connection.js';
import { clock, AppError } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { isViewOnly, VIEW_ONLY_TABLES } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as P from '../src/modules/payroll/service.js';
import * as RT from '../src/modules/payroll/returns.js';
import * as V from '../src/modules/verify/service.js';
import * as W from '../src/services/watchdog.js';
import { setAlertSources, collectAlerts } from '../src/services/alerts.js';
import { alerts as apAlerts } from '../src/modules/payables/alerts.js';
import { alerts as payAlerts } from '../src/modules/payroll/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
try { allowNewRoles(); } catch (e) { /* already */ }
const at = (d) => { clock.override = new Date(`${d}T10:00:00`); };
const r2 = (n) => Math.round(n * 100) / 100;
at('2026-09-01');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', shopCode: 'S2' }, owner);
const acc = saveUser({ name: 'Ravi Accountant', pin: '5151', role: 'accountant' }, owner);
const bank = AP.saveAccount(owner, { name: 'BSP Business', openingBalance: 30000, openingDate: '2026-08-31' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 700, lastNo: 749 });
const punjas = AP.saveSupplier(owner, { name: 'Punjas', tin: '50-11111-0-1', onAccount: true });
const landlord = AP.saveSupplier(owner, { name: 'Drasa Properties', tin: '50-44444-0-1' });
const rice = I.saveItem(owner, { code: 'R20', name: 'Rice 20kg', cost: 30, price: 42, supplierUid: punjas.uid });
const sugar = I.saveItem(owner, { code: 'S2K', name: 'Sugar 2kg', cost: 4, price: 5.95, supplierUid: punjas.uid });
const stock = (it, shop = 'S1') => db().get("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = ? AND status = 'active'", [it.uid, shop]).q;
let po; let rec; let inv;

test('order → approved → delivery counted in against the order: stock up, invoice joined both ways', () => {
  at('2026-09-02');
  po = I.savePO(mgr, { supplierUid: punjas.uid, shopCode: 'S1', lines: [{ itemUid: rice.uid, qty: 10, unitCost: 30 }, { itemUid: sugar.uid, qty: 50, unitCost: 4 }] });
  I.submitPO(owner, po.uid, { canApprove: true });
  assert.strictEqual(I.getPO(po.uid).status, 'approved');
  at('2026-09-04');
  const o = I.getPO(po.uid);
  rec = I.receiveDelivery(mgr, { poUid: po.uid, date: '2026-09-04', lines: o.lines.map((l) => ({ lineUid: l.uid, qty: l.item_uid === sugar.uid ? 40 : 10 })),
    invoice: { invoiceNo: 'PJ-501', photos: ['file:///doc/pj501.jpg'] }, acceptReason: 'Sugar short, rest next week' });
  assert.strictEqual(stock(rice), 10);
  assert.strictEqual(stock(sugar), 40);
  inv = AP.getInvoice(rec.invoice.uid);
  assert.strictEqual(inv.po_uid, po.uid, 'invoice → order');
  assert.strictEqual(inv.total, r2((10 * 30 + 40 * 4) * 1.125), 'no total typed: the invoice is for what was received');
  assert.strictEqual(I.getPO(po.uid).status, 'part');
  assert.ok(I.getReceipt(rec.uid).invoice_uid === inv.uid, 'delivery → invoice');
});
test('the invoice is checked and paid in two parts (cash + cheque 700) – then part of the next one', () => {
  AP.checkInvoice(owner, inv.uid);
  const list = AP.makeSplitPayment(owner, { supplierUid: punjas.uid, payDate: '2026-09-10', allocations: [{ invoiceUid: inv.uid, amount: inv.total }],
    parts: [{ method: 'cash', amount: 117.5, shopCode: 'S1', receivedBy: 'Punjas rep' }, { method: 'cheque', amount: r2(inv.total - 117.5), accountUid: bank.uid, chequeNo: 700 }] });
  assert.strictEqual(list.length, 2);
  assert.strictEqual(AP.getInvoice(inv.uid).owing, 0);
  assert.strictEqual(db().get('SELECT amount FROM cheques WHERE cheque_no = 700').amount, r2(inv.total - 117.5));
  // The rest of the sugar comes without the order reference: received without a PO, with the invoice photo.
  at('2026-09-11');
  const r = I.receiveDelivery(mgr, { supplierUid: punjas.uid, shopCode: 'S1', date: '2026-09-11', extra: [{ itemUid: sugar.uid, qty: 10, unitCost: 4 }], invoice: { invoiceNo: 'PJ-502', total: 45, photos: ['file:///doc/pj502.jpg'] } });
  assert.strictEqual(stock(sugar), 50);
  AP.checkInvoice(owner, r.invoice.uid);
  const p = AP.makePayment(owner, { supplierUid: punjas.uid, method: 'transfer', accountUid: bank.uid, reference: 'TT-88', payDate: '2026-09-12', allocations: [{ invoiceUid: r.invoice.uid, amount: 20 }] });
  assert.ok(/PART PAYMENT/.test(p.notes));
  assert.ok(apAlerts(owner).some((x) => x.id === 'ap-part-paid'));
});
test('rent receipt photographed by the owner: bill + cheque 701 saved together', () => {
  const s = V.snap(owner, { kind: 'invoice', shopCode: 'S1', amount: 2500, supplierUid: landlord.uid, refNo: 'RENT-SEP', date: '2026-09-01', photos: ['file:///doc/rent.jpg'], category: 'Rent', paid: { method: 'cheque', accountUid: bank.uid, chequeNo: '701' } });
  assert.strictEqual(AP.getInvoice(s.linkUid).owing, 0);
});
test('sales for the month (Aronium figures typed in the accounts)', () => {
  F.saveSale(owner, { date: '2026-09-15', shop: 'S1', total: 9000, zero: 1350, vat: 850, via: `bank:${bank.uid}` });
  F.saveSale(owner, { date: '2026-09-22', shop: 'S2', total: 4500, zero: 0, vat: 500, via: `bank:${bank.uid}` });
});
test('two weekly pay runs: employer FNPF 8%, family member without FNPF', () => {
  P.savePayRules(owner, { ...P.payRules(), confirmed: true, needCheckedTimesheets: false });
  P.saveProfile(owner, { userUid: mere.uid, payType: 'salary', weeklySalary: 320, tin: '111222333', fnpfNo: 'FN-1', taxStatus: 'resident', payMethod: 'cash' });
  P.saveProfile(owner, { userUid: sam.uid, payType: 'salary', weeklySalary: 280, tin: '444555666', fnpfNo: 'FN-2', taxStatus: 'resident', payMethod: 'cash' });
  for (const d of ['2026-09-12', '2026-09-19']) { at(d); const run = P.createRun(owner, d); P.finaliseRun(owner, run.uid); }
  const s = RT.fnpfSchedule('2026-09');
  assert.strictEqual(s.rows.length, 2);
  for (const r of s.rows) assert.ok(Math.abs(r.employer - r2(r.gross * 0.08)) <= 0.05 * r.pays && Math.abs(r.employee - r2(r.gross * 0.08)) <= 0.05 * r.pays, JSON.stringify(r));
});
test('stock take finds 2 bags of rice missing: loss with a reason', () => {
  at('2026-09-28');
  const c = I.startCount(mgr, { shopCode: 'S1', name: 'Month end', date: '2026-09-28' });
  I.enterCount(mgr, c.uid, rice.uid, 8);
  I.enterCount(mgr, c.uid, sugar.uid, 50);
  for (const a of I.getCount(c.uid).areas || []) { try { I.claimArea(mgr, c.uid, a.area); } catch (e) { /* claimed */ } I.finishArea(mgr, c.uid, a.area); }
  try { I.setLineReason(mgr, c.uid, rice.uid, 'Damaged'); } catch (e) { /* reason may be asked later */ }
  let r = I.submitCount(mgr, c.uid, {});
  // Well off → the app asks for a recount first (same answer: 8 bags).
  if (r.recount.length) { assert.ok(r.recount.some((x) => x.itemUid === rice.uid)); I.enterCount(mgr, c.uid, rice.uid, 8); r = I.submitCount(mgr, c.uid, {}); }
  assert.strictEqual(r.recount.length, 0);
  try { I.setLineReason(owner, c.uid, rice.uid, 'Damaged'); } catch (e) { /* set already */ }
  I.postCount(owner, c.uid, {});
  assert.strictEqual(stock(rice), 8);
});
test('VAT return September: FRCS lines agree with the sales and the invoices; lodged and paid by cheque 702', () => {
  at('2026-10-20');
  const v = RT.vatReturnFRCS('2026-09');
  assert.strictEqual(v.lines[1], 13500);
  assert.strictEqual(v.lines[2], 1350);
  assert.strictEqual(v.lines[4], r2((13500 - 1350) * 12.5 / 112.5));
  const inputs = db().all("SELECT SUM(vat) AS v FROM ap_invoices WHERE status <> 'void' AND kind = 'invoice' AND invoice_date LIKE '2026-09%'")[0].v;
  assert.strictEqual(v.lines[7], r2(inputs), 'every invoice has a TIN, so line 7 = all invoice VAT');
  assert.strictEqual(v.schedule.length, 3);
  RT.lodgeReturn(owner, 'vat', '2026-09', { date: '2026-10-20', ref: 'TPOS-SEP', photos: ['file:///doc/tpos.jpg'] });
  const st = RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-21', via: `bank:${bank.uid}`, method: 'cheque', chequeNo: '702', photos: ['file:///doc/stub702.jpg'] });
  assert.ok(st.item.done, 'both proofs in (receipt photos) – calendar item complete');
});
test('FNPF September lodged by the 14th and paid', () => {
  require0();
  RT.lodgeReturn(owner, 'fnpf', '2026-09', { date: '2026-10-10', ref: 'FNPF-CS-SEP' });
  const st = RT.payReturn(owner, 'fnpf', '2026-09', { date: '2026-10-20', via: `bank:${bank.uid}`, method: 'transfer', ref: 'BSP-FNPF-SEP' });
  assert.strictEqual(st.short, 0);
});
function require0() {
  // Employer FNPF reference number is needed on the schedule.
  require('../src/modules/payroll/filing.js').saveEmployerDetails(owner, { name: 'Easy Buys Shopping Centre', tin: '50-12345-0-1', fnpfNo: 'ER-7001', city: 'Lautoka' });
}
test('the books agree: ledger balances; VAT for September cleared; FNPF owed = 0; bank = opening + in − out', () => {
  const tb = A.trialBalance('2026-10-31');
  assert.ok(tb.ok, `trial balance ${tb.dr} / ${tb.cr}`);
  const bal = (code, to) => (A.balances({ to }).find((r) => r.code === code) || { balance: 0 }).balance;
  // FNPF: everything deducted and added in September was paid in October.
  assert.ok(Math.abs(bal('2100', '2026-10-31')) < 0.01, `FNPF to pay ${bal('2100', '2026-10-31')}`);
  // VAT: September's net was paid, so only rounding between the typed VAT and the form remains.
  assert.ok(Math.abs(bal('2200', '2026-10-31')) < 2, `VAT account ${bal('2200', '2026-10-31')}`);
  const bankCode = `1100:${bank.uid}`;
  const ledgerBank = r2(A.balances({ to: '2026-10-31' }).filter((r) => r.code === bankCode).reduce((s, r) => s + r.balance, 0));
  const lines = db().all("SELECT type, amount FROM bank_entries WHERE account_uid = ? AND status = 'active'", [bank.uid]);
  const cheques = db().all("SELECT amount FROM cheques WHERE account_uid = ? AND status IN ('written','presented')", [bank.uid]);
  const inflow = lines.filter((l) => ['deposit', 'opening'].includes(l.type)).reduce((s, l) => s + l.amount, 0);
  const outflow = lines.filter((l) => !['deposit', 'opening'].includes(l.type)).reduce((s, l) => s + l.amount, 0) + cheques.reduce((s, c) => s + c.amount, 0);
  assert.ok(Math.abs(ledgerBank - r2(30000 + inflow - outflow)) < 0.01 || Math.abs(ledgerBank - r2(inflow - outflow)) < 0.01, `ledger ${ledgerBank} vs bank lines ${r2(inflow - outflow)} (+opening)`);
});
test('the accountant can look but not change; warnings and the watchdog run without errors for everyone', () => {
  assert.ok(isViewOnly(acc));
  setWriteGuard((t) => { if (!VIEW_ONLY_TABLES.includes(t)) throw new AppError('View only'); });
  throws(() => RT.lodgeReturn(acc, 'vat', '2026-08', { ref: 'x' }), /cannot|View only/);
  throws(() => AP.saveInvoice(acc, { supplierUid: punjas.uid, invoiceNo: 'X', total: 1, invoiceDate: '2026-10-20', shopCode: 'S1' }), /View only|cannot/);
  setWriteGuard(null);
  setAlertSources([{ id: 'payables', alerts: apAlerts }, { id: 'payroll', alerts: payAlerts }]);
  for (const u of [owner, mgr, mere, acc]) collectAlerts(u);
  const w = W.runWatchdog(owner);
  assert.ok(w, 'watchdog ran');
  // Nothing about September's VAT / FNPF is outstanding any more.
  assert.ok(!collectAlerts(owner).some((a) => /2026-09/.test(a.text) && /(VAT|FNPF)/.test(a.text) && a.level === 'urgent'), collectAlerts(owner).map((a) => a.text).join(' | '));
});
test('nothing is ever deleted: voided and replaced records are still there', () => {
  const n = (t) => db().get(`SELECT COUNT(*) AS n FROM ${t}`).n;
  const before = { j: n('gl_journals'), c: n('cheques'), v: n('tax_return_versions') };
  at('2026-10-25');
  RT.undoReturnPayment(owner, 'vat', '2026-09', 'Cheque lost in the post');
  assert.strictEqual(n('gl_journals'), before.j);
  assert.strictEqual(n('cheques'), before.c);
  assert.strictEqual(db().get("SELECT status FROM cheques WHERE cheque_no = 702").status, 'void');
  RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-25', via: `bank:${bank.uid}`, method: 'cheque', chequeNo: '703' });
  assert.strictEqual(n('tax_return_versions'), before.v);
});
done();
