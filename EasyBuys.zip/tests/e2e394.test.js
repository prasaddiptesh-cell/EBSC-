// 3.9.4 End to end: the real till program (Python) → a local copy of the real cloud script (cloud/Code.gs) → the app
// on the main tablet → stock sales, End of days, insights and the online dashboard. Then the awkward cases: a second
// till, sending again, a late sale the same day, the tablet offline, and the till program's "Test the app" button.
import { createRequire } from 'module';
import http from 'http';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { spawn } from 'child_process';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { setSetting, setShared, deviceId } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { syncNow } from '../src/platform/cloud.js';
import * as L from '../src/modules/aronium/link.js';
import * as N from '../src/modules/aronium/insights.js';
import * as B from '../src/services/board.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert } from './harness.js';

const require = createRequire(process.cwd() + '/tests/');
const { load } = require('./fakeGoogle.cjs');
const CLOUD = 'https://script.google.com/macros/s/TEST/exec';
const G = load();
G.ctx.setup();
const MAIN_KEY = G.G.props.MAIN_KEY;
let offline = false;
let cloudCalls = 0;
globalThis.fetch = async (url, opts) => {
  if (offline) throw new TypeError('Network request failed');
  cloudCalls += 1;
  return { status: 200, text: async () => JSON.stringify(G.post(JSON.parse(opts.body))) };
};
// the till PCs reach the same cloud over HTTP
const server = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    let out;
    try { out = G.post(JSON.parse(body)); } catch (e) { out = { ok: false, error: String(e && e.message) }; }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(out));
  });
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const PORT = server.address().port;

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'eb-e2e-'));
const DRIVE = path.resolve('tools/aronium-bridge/tests/e2e_drive.py');
function py(...args) {
  return new Promise((resolve, reject) => {
    const p = spawn('python3', [DRIVE, ...args.map(String)], { cwd: TMP });
    let out = ''; let err = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    p.on('close', (code) => {
      const line = out.trim().split('\n').pop();
      try { resolve(JSON.parse(line)); } catch (e) { reject(new Error(`python ${args[0]} (${code}): ${out}\n${err}`)); }
    });
  });
}
const till = (name) => ({ home: path.join(TMP, `${name}-home`), db: path.join(TMP, `${name}.db`) });
const T1 = till('s1t1');
const T2 = till('s1t2');
const send = (t, shop, n, extra) => py('run', t.home, t.db, PORT, shop, n, MAIN_KEY, ...(extra ? [extra] : []));
const sync = async (times = 1) => { let r; for (let i = 0; i < times; i++) r = await syncNow({ force: true }); return r; };

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
setSetting('cloud_url', CLOUD);
setSetting('cloud_key', 'tablet-key-123');
setSetting('device_name', 'Main tablet');
setShared('main_tablet_device', deviceId());

const moveQty = (code, date) => {
  const it = db().get('SELECT uid FROM inv_items WHERE code = ?', [code]);
  if (!it) return null;
  return db().get("SELECT SUM(qty) AS q FROM inv_moves WHERE item_uid = ? AND shop_code = 'S1' AND move_date = ? AND type = 'sale' AND status = 'active'", [it.uid, date]).q;
};

test('the till program sends its Aronium figures to the cloud', async () => {
  await py('make', T1.db);
  const r = await send(T1, 'S1', 1);
  assert.ok(r.ok, JSON.stringify(r));
  assert.ok(r.sent > 5);
  assert.strictEqual(r.waiting, 0);
});

test('the main tablet syncs and books it: products, sales per product per day, End of day', async () => {
  const r = await sync(2);
  assert.strictEqual(r.error, null, r.error);
  assert.ok(db().get("SELECT COUNT(*) AS n FROM aronium_feed WHERE source = 'S1-T1'").n > 5, 'the feed arrived');
  assert.ok(db().get("SELECT uid FROM inv_items WHERE code = '1001'"), 'Bread Loaf is in the product list');
  assert.strictEqual(moveQty('1001', '2026-10-09'), -2, 'two loaves sold on the 9th');
  assert.strictEqual(moveQty('2001', '2026-10-09'), -1, 'one rice');
  const z = db().get("SELECT * FROM aronium_eods WHERE source = 'link' AND z_number = '101'");
  assert.ok(z, 'End of day Z 101 recorded');
  assert.strictEqual(Number(z.total), 31);
  assert.strictEqual(pendingRecords(500).filter((x) => x.t !== 'audit_log').length, 0, 'what the tablet made went up to the cloud too');
});

test('a second till of the same shop: its sales are added, not mixed up', async () => {
  await py('make', T2.db);
  await send(T2, 'S1', 2);
  await sync(2);
  assert.strictEqual(moveQty('1001', '2026-10-09'), -4, 'two tills × two loaves');
  const days = L.aroniumSalesByDay({ from: '2026-10-01' }).filter((d) => d.date === '2026-10-09');
  assert.deepStrictEqual(days.map((d) => d.source).sort(), ['S1-T1', 'S1-T2']);
});

test('sending everything again (resend) and syncing again never doubles anything', async () => {
  const before = db().get("SELECT COUNT(*) AS n, SUM(qty) AS q FROM inv_moves WHERE status = 'active'");
  const eods = db().get('SELECT COUNT(*) AS n FROM aronium_eods').n;
  await send(T1, 'S1', 1, 'resend');
  await sync(3);
  const after = db().get("SELECT COUNT(*) AS n, SUM(qty) AS q FROM inv_moves WHERE status = 'active'");
  assert.deepStrictEqual(after, before);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM aronium_eods').n, eods);
});

test('a late sale the same day replaces that day\'s figure (not added on top)', async () => {
  await py('sale', T1.db, 300, '2026-10-09 20:00:00', 1, 3, 2.5);
  await send(T1, 'S1', 1);
  await sync(2);
  assert.strictEqual(moveQty('1001', '2026-10-09'), -7, '4 before + 3 more loaves');
});

test('the tablet offline: nothing lost, it catches up when back', async () => {
  await py('sale', T1.db, 301, '2026-10-10 10:00:00', 2, 2, 25);
  await send(T1, 'S1', 1);
  offline = true;
  const r = await syncNow({ force: true });
  assert.ok(r.error && /Network/i.test(r.error), JSON.stringify(r));
  offline = false;
  await sync(2);
  assert.strictEqual(moveQty('2001', '2026-10-10'), -2);
});

test('the till PC offline: its figures wait on the PC and arrive later', async () => {
  await py('sale', T2.db, 302, '2026-10-10 11:00:00', 3, 4, 3.95);
  const down = await py('run', T2.home, T2.db, 1, 'S1', 2, MAIN_KEY); // port 1: nothing there
  assert.strictEqual(down.ok, false);
  assert.ok(down.waiting > 0);
  const up = await send(T2, 'S1', 2);
  assert.ok(up.ok && up.waiting === 0, JSON.stringify(up));
  await sync(2);
  assert.ok(db().get("SELECT 1 AS x FROM aronium_feed WHERE source = 'S1-T2' AND kind = 'sales_day' AND period = '2026-10-10'"));
});

test('"Test the app" on the till PC: the main tablet answers through the cloud', async () => {
  const waiting = py('testapp', T1.home, T1.db, PORT, 'S1', 1, MAIN_KEY);
  // the tablet keeps syncing as it does every minute
  let answered = null;
  waiting.then((r) => { answered = r; });
  for (let i = 0; i < 40 && !answered; i++) { await syncNow({ force: true }); await new Promise((r) => setTimeout(r, 300)); }
  const r = await waiting;
  assert.ok(r.ok, JSON.stringify(r));
  assert.ok(/Main tablet, app 3\.9\.\d+ received the test/.test(r.lines[r.lines.length - 1]), r.lines.join(' | '));
});

test('insights and the online dashboard work from the same figures', async () => {
  const cw = N.cashierWatch({ today: '2026-10-11' });
  assert.ok(cw.some((c) => c.name === 'Asha K'), JSON.stringify(cw.map((c) => c.name)));
  const b = N.busyHours({ shop: 'S1', today: '2026-10-11' });
  assert.ok(b.daysCounted >= 1);
  B.boardStale();
  const board = B.buildBoard({ force: true, today: '2026-10-11' });
  const bad = board.sections.filter((s) => s.error);
  assert.deepStrictEqual(bad.map((s) => `${s.id}: ${s.error}`), []);
  assert.ok(board.sections.some((s) => s.id === 'insights'));
});

test('the cloud kept everything in one piece', () => {
  const feed = G.G.books[G.G.props.DATA_ID].getSheetByName('T_aronium_feed').data;
  assert.ok(feed.length > 20);
  for (const row of feed.slice(1)) assert.ok(String(row[4]).length < 50000, 'every record fits one cell');
  const keys = feed.slice(1).map((r) => String(r[0]));
  assert.strictEqual(new Set(keys).size, keys.length, 'one row per record (sending again replaced, never added)');
});

test('finish', () => { server.close(); fs.rmSync(TMP, { recursive: true, force: true }); });
done();
