// Go-live optional emails: Off by default (existing addresses kept), Ask each time (a "send it?" on Home), Automatic;
// reports are still saved in Drive when not emailed.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as E from '../src/services/emailPrefs.js';
import { alerts } from '../src/modules/admin/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
setSetting('report_emails', JSON.stringify(['boss@example.com']));
const queued = () => db().all("SELECT kind, payload FROM outbox ORDER BY id").map((r) => ({ kind: r.kind, payload: JSON.parse(r.payload) }));

test('off by default; the addresses already there are kept as the starting list', () => {
  const p = E.emailPrefs();
  assert.strictEqual(p.shift_report.mode, 'off');
  assert.deepStrictEqual(p.shift_report.to, ['boss@example.com']);
  assert.deepStrictEqual(p.bakery_po.to, ['boss@example.com'], 'orders used the report addresses when empty');
  assert.deepStrictEqual(E.recipientsFor('shift_report', { shiftId: 1 }), [], 'only saved in Drive');
});
test('checks: valid addresses, at least one unless Off', () => {
  throws(() => E.saveEmailPref(owner, 'shift_report', { mode: 'auto', to: ['nope'] }), /do not look like/);
  throws(() => E.saveEmailPref(owner, 'shift_report', { mode: 'auto', to: [] }), /at least one/);
  E.saveEmailPref(owner, 'shift_report', { mode: 'off', to: [] });
});
test('automatic: emailed', () => {
  E.saveEmailPref(owner, 'shift_report', { mode: 'auto', to: ['a@x.com', 'a@x.com'] });
  assert.deepStrictEqual(E.recipientsFor('shift_report', {}), ['a@x.com']);
  assert.strictEqual(E.noteMade('shift_report', { shiftId: 5 }, 'Report'), false, 'no question asked');
});
test('ask each time: a warning on Home, Send queues it with the email, Not now does not', () => {
  E.saveEmailPref(owner, 'shift_report', { mode: 'ask', to: ['a@x.com'] });
  assert.ok(E.noteMade('shift_report', { shiftId: 7 }, 'Bakery day report 2026-10-12'));
  assert.ok(E.noteMade('shift_report', { shiftId: 8 }, 'Bakery day report 2026-10-13'));
  assert.ok(alerts(owner).some((a) => /2 emails to send/.test(a.text)));
  const [a1, a2] = E.emailAsks();
  const before = queued().length;
  E.answerAsk(owner, a1.id, true);
  E.answerAsk(owner, a2.id, false);
  const q = queued().slice(before);
  assert.strictEqual(q.length, 1);
  assert.deepStrictEqual(q[0], { kind: 'report', payload: { shiftId: 7, emailNow: true } });
  assert.deepStrictEqual(E.recipientsFor('shift_report', q[0].payload), ['a@x.com']);
  assert.strictEqual(E.emailAsks().length, 0);
  throws(() => E.answerAsk(owner, a1.id, true), /Already/);
  assert.strictEqual(E.sendAnswered(), 0, 'sent once only');
});
test('monthly accountant pack: main tablet only, days 1–5, last month, once', () => {
  assert.strictEqual(E.packDue({ today: '2026-11-02', isMain: true }), null, 'off by default');
  E.saveEmailPref(owner, 'accountant_pack', { mode: 'auto', to: ['acc@x.com'] });
  assert.strictEqual(E.packDue({ today: '2026-11-02', isMain: false }), null);
  assert.strictEqual(E.packDue({ today: '2026-11-09', isMain: true }), null);
  const d = E.packDue({ today: '2026-11-02', isMain: true });
  assert.deepStrictEqual([d.from, d.to, d.month], ['2026-10-01', '2026-10-31', '2026-10']);
  setSetting('acct_pack_month', '2026-10');
  assert.strictEqual(E.packDue({ today: '2026-11-03', isMain: true }), null);
});
done();
