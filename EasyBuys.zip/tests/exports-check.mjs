// Finds names used through `import * as X from '...'` (X.name or const { name } = X) that the module does not export.
// Such a name is undefined at run time and crashes the screen on the phone.
import fs from 'fs';
import path from 'path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const files = [];
const walk = (d) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (p.endsWith('.js')) files.push(p); } };
walk(path.join(root, 'src')); files.push(path.join(root, 'App.js'));
const cache = {};
function exportsOf(file, seen = new Set()) {
  if (cache[file]) return cache[file];
  if (seen.has(file)) return new Set(); seen.add(file);
  const src = fs.readFileSync(file, 'utf8'); const out = new Set();
  for (const m of src.matchAll(/export\s+(?:async\s+)?(?:function\*?|const|let|var|class)\s+([\w$]+)/g)) out.add(m[1]);
  for (const m of src.matchAll(/export\s+(?:const|let|var)\s+\{([^}]*)\}/g)) m[1].split(',').forEach((x) => { const n = x.split(':').pop().trim(); if (n) out.add(n); });
  for (const m of src.matchAll(/export\s*\{([^}]*)\}(\s*from\s*['"]([^'"]+)['"])?/g)) m[1].split(',').forEach((x) => { const n = x.trim().split(/\s+as\s+/).pop().trim(); if (n) out.add(n); });
  for (const m of src.matchAll(/export\s*\*\s*from\s*['"]([^'"]+)['"]/g)) { const t = resolve(file, m[1]); if (t) exportsOf(t, seen).forEach((n) => out.add(n)); }
  if (/export\s+default/.test(src)) out.add('default');
  return (cache[file] = out);
}
function resolve(from, spec) {
  if (!spec.startsWith('.')) return null;
  const p = path.resolve(path.dirname(from), spec);
  for (const c of [p, p + '.js', path.join(p, 'index.js')]) if (fs.existsSync(c) && fs.statSync(c).isFile()) return c;
  return null;
}
let bad = 0;
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/import\s+\*\s+as\s+([\w$]+)\s+from\s+['"]([^'"]+)['"]/g)) {
    const [, ns, spec] = m; const target = resolve(f, spec); if (!target) continue;
    const ex = exportsOf(target); const used = new Set();
    const esc = ns.replace(/\$/g, '\\$');
    for (const u of src.matchAll(new RegExp(`(?<![\\w$.])${esc}\\.([A-Za-z_$][\\w$]*)`, 'g'))) used.add(u[1]);
    for (const u of src.matchAll(new RegExp(`(?:const|let|var)\\s*\\{([^}]*)\\}\\s*=\\s*${esc}\\b`, 'g'))) u[1].split(',').forEach((x) => { const n = x.split(':')[0].trim(); if (n) used.add(n); });
    for (const n of used) if (!ex.has(n)) { bad++; console.log(`MISSING ${path.relative(root, f)}: ${ns}.${n} is not exported by ${path.relative(root, target)}`); }
  }
  // Named imports too.
  for (const m of src.matchAll(/import\s+(?:[\w$]+\s*,\s*)?\{([^}]*)\}\s+from\s+['"]([^'"]+)['"]/g)) {
    const target = resolve(f, m[2]); if (!target) continue; const ex = exportsOf(target);
    m[1].split(',').forEach((x) => { const n = x.trim().split(/\s+as\s+/)[0].trim(); if (n && !ex.has(n)) { bad++; console.log(`MISSING ${path.relative(root, f)}: { ${n} } is not exported by ${path.relative(root, target)}`); } });
  }
}
console.log(bad ? `${bad} missing export(s)` : 'exports: all OK');
process.exit(bad ? 1 : 0);
