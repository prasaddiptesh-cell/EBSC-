// Till extras (safe count, repeat shortages) and invoice extras (payment run, statement check, VAT warnings).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as X from '../src/modules/payables/extras.js';
import * as T from '../src/modules/till/service.js';
import * as B from '../src/modules/bank/service.js';
import * as BX from '../src/modules/bank/extras.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T18:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 5000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 700, lastNo: 749 });

test('safe count: difference needs a note; owner books it; cash on hand then agrees', () => {
  T.recordCash(mgr, { shopCode: 'S2', type: 'opening', amount: 500, date: '2026-10-07' });
  throws(() => T.saveSafeCount(mgr, { shopCode: 'S2', denominations: { n100: 4, n50: 1 } }), /short by \$50.00/);
  const s = T.saveSafeCount(mgr, { shopCode: 'S2', denominations: { n100: 4, n50: 1 }, note: 'Not sure', witness: 'Sam' });
  assert.strictEqual(s.diff, -50);
  T.bookSafeDifference(owner, s.uid, 'Accepted after checking');
  assert.strictEqual(T.cashOnHand('S2').onHand, 450);
  throws(() => T.bookSafeDifference(owner, s.uid, 'again'), /Already/);
});

test('repeat shortages: 3 short tills in 30 days flags the cashier', () => {
  const till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 100 });
  const sam = saveUser({ name: 'Sam Cashier', pin: '4321', role: 'staff', shopCode: 'S2' }, owner);
  ['2026-10-01', '2026-10-03', '2026-10-05'].forEach((d, i) => {
    T.saveTillCount(mgr, { shopCode: 'S2', tillUid: till, shiftDate: d, shift: `Morning`, cashierUid: sam.uid, openingFloat: 100, denominations: { n100: 1, n20: 4 }, zCash: 100, zTotal: 100, tenders: [], payouts: [], adjustments: [], floatKept: 100, reason: `short ${i}` }, { photos: ['file:///z.jpg'] });
  });
  const r = T.repeatShorts({ today: '2026-10-08' });
  assert.strictEqual(r.length, 1);
  assert.strictEqual(r[0].times, 3);
  assert.strictEqual(r[0].amount, -60);
});

test('payment run: two suppliers, cheques in order; unchecked invoices are skipped', () => {
  const a = AP.saveSupplier(owner, { name: 'Alpha', tin: '500001', onAccount: true });
  const b = AP.saveSupplier(owner, { name: 'Beta', tin: '500002', onAccount: true });
  const i1 = AP.saveInvoice(owner, { supplierUid: a.uid, invoiceNo: 'A1', total: 100, invoiceDate: '2026-10-01', dueDate: '2026-10-05' }, { canCheck: true });
  const i2 = AP.saveInvoice(owner, { supplierUid: a.uid, invoiceNo: 'A2', total: 50, invoiceDate: '2026-10-02', dueDate: '2026-10-06' }, { canCheck: true });
  const i3 = AP.saveInvoice(owner, { supplierUid: b.uid, invoiceNo: 'B1', total: 75, invoiceDate: '2026-10-02', dueDate: '2026-10-07' }, { canCheck: true });
  AP.saveInvoice(mgr, { supplierUid: b.uid, invoiceNo: 'B2', total: 20, invoiceDate: '2026-10-02', dueDate: '2026-10-07' });
  const c = X.payRunCandidates({ dueBy: '2026-10-08' });
  assert.strictEqual(c.length, 2);
  assert.strictEqual(c.find((g) => g.name === 'Beta').blocked, 1);
  const done = X.payRun(owner, { accountUid: acct.uid, method: 'cheque', date: '2026-10-08', items: [{ supplierUid: a.uid, invoiceUids: [i1.uid, i2.uid] }, { supplierUid: b.uid, invoiceUids: [i3.uid] }] });
  assert.deepStrictEqual(done.map((p) => [p.supplier_name, p.amount, p.cheque_no]), [['Alpha', 150, '700'], ['Beta', 75, '701']]);
});

test('statement check: agrees, or suggests why not', () => {
  const g = AP.saveSupplier(owner, { name: 'Gamma', tin: '500003', onAccount: true });
  AP.saveInvoice(owner, { supplierUid: g.uid, invoiceNo: 'G1', total: 200, invoiceDate: '2026-10-01' }, { canCheck: true });
  const inv2 = AP.saveInvoice(owner, { supplierUid: g.uid, invoiceNo: 'G2', total: 80, invoiceDate: '2026-10-03' }, { canCheck: true });
  assert.strictEqual(X.checkStatement(owner, { supplierUid: g.uid, date: '2026-10-08', theirBalance: 280 }).diff, 0);
  const r = X.checkStatement(owner, { supplierUid: g.uid, date: '2026-10-08', theirBalance: 200 });
  assert.strictEqual(r.diff, -80);
  assert.ok(/G2/.test(r.hints[0]));
  AP.makePayment(owner, { supplierUid: g.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 702, payDate: '2026-10-08', allocations: [{ invoiceUid: inv2.uid, amount: 80 }] });
  const r2 = X.checkStatement(owner, { supplierUid: g.uid, date: '2026-10-08', theirBalance: 280 });
  assert.ok(/may not be on their statement/.test(r2.hints[0]));
});

test('invoice warnings: no TIN, VAT not matching', () => {
  const n = AP.saveSupplier(owner, { name: 'No Tin Co', onAccount: false });
  const inv = AP.saveInvoice(owner, { supplierUid: n.uid, total: 1125, vat: 100, vatType: 'standard', invoiceDate: '2026-10-08' }, { canCheck: true });
  const w = X.invoiceWarnings(inv);
  assert.ok(w.some((x) => /TIN/.test(x)));
});

test('bank: rules code repeat lines, one line for two deposits, split a line', () => {
  BX.saveBankRules(owner, [{ contains: 'EFTPOS SETTLEMENT', direction: 'in', type: 'deposit', glCode: '1110' }, { contains: 'SERVICE FEE', direction: 'out', type: 'fee' }]);
  AP.addBankEntry(owner, { accountUid: acct.uid, date: '2026-10-05', type: 'deposit', amount: 300, reference: 'Slip A' });
  AP.addBankEntry(owner, { accountUid: acct.uid, date: '2026-10-06', type: 'deposit', amount: 200, reference: 'Slip B' });
  const st = B.addStatement(owner, { accountUid: acct.uid, fromDate: '2026-10-05', toDate: '2026-10-08', closing: 0, lines: [
    { date: '2026-10-07', description: 'EFTPOS SETTLEMENT 123', amount: 812.4 },
    { date: '2026-10-07', description: 'MONTHLY SERVICE FEE', amount: -7.5 },
    { date: '2026-10-07', description: 'DEPOSIT', amount: 500 },
    { date: '2026-10-08', description: 'LOAN + INSURANCE', amount: -900 },
  ] });
  const lines = B.getStatement(st).lines;
  const eft = lines.find((l) => l.amount === 812.4);
  assert.strictEqual(eft.status, 'matched', 'coded by the rule');
  assert.strictEqual(lines.find((l) => l.amount === -7.5).status, 'matched');
  const dep = lines.find((l) => l.amount === 500);
  assert.strictEqual(dep.status, 'unmatched');
  const combo = BX.suggestCombination(dep);
  assert.strictEqual(combo.length, 2);
  BX.matchMany(owner, dep.uid, combo);
  const loan = lines.find((l) => l.amount === -900);
  throws(() => BX.createSplit(owner, loan.uid, 'transfer_out', [{ code: '2500', amount: 800 }, { code: '6700', amount: 50 }]), /add up to \$850.00/);
  BX.createSplit(owner, loan.uid, 'transfer_out', [{ code: '2500', amount: 800 }, { code: '6700', amount: 100 }], 'Loan repayment and interest');
  assert.ok(B.getStatement(st).lines.every((l) => l.status === 'matched'));
});

done();
