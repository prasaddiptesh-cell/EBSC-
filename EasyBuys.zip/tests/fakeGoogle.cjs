// Fake Google services (Sheets, Drive, Gmail, properties) and a loader for cloud/Code.gs.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

function makeGoogle() {
  const props = {};
  const books = {};
  const mails = [];
  // Like real Sheets: unless the cells are plain text, date-looking text becomes a Date and digits become numbers.
  const convert = (v, text) => {
    if (text || typeof v !== 'string') return v;
    if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}/.test(v)) return new Date(v.replace(' ', 'T'));
    if (/^\d+$/.test(v)) return Number(v);
    return v;
  };
  function Sheet(name) {
    this.name = name;
    this.data = [];
    this.text = false;
    const sh = this;
    this.getLastRow = () => sh.data.length;
    this.getLastColumn = () => sh.data.reduce((m, r) => Math.max(m, r.length), 0);
    this.getMaxRows = () => 1000;
    this.getMaxColumns = () => 26;
    this.appendRow = (r) => { sh.data.push(r.map((v) => convert(v, sh.text))); };
    this.setFrozenRows = () => {};
    this.getRange = (row, col, nr = 1, nc = 1) => ({
      setNumberFormat: (f) => { if (f === '@' && row === 1 && col === 1) sh.text = true; },
      getValues: () => {
        const out = [];
        for (let i = 0; i < nr; i++) {
          const r = sh.data[row - 1 + i] || [];
          const line = [];
          for (let j = 0; j < nc; j++) line.push(r[col - 1 + j] === undefined ? '' : r[col - 1 + j]);
          out.push(line);
        }
        return out;
      },
      setValues: (vals) => {
        vals.forEach((line, i) => {
          const r = (sh.data[row - 1 + i] = sh.data[row - 1 + i] || []);
          line.forEach((v, j) => { while (r.length < col - 1 + j) r.push(''); r[col - 1 + j] = convert(v, sh.text); });
        });
      },
      setValue: (v) => { const r = (sh.data[row - 1] = sh.data[row - 1] || []); while (r.length < col - 1) r.push(''); r[col - 1] = convert(v, sh.text); },
      // Like Sheets: emptied rows at the bottom no longer count for getLastRow.
      clearContent: () => {
        for (let i = 0; i < nr; i++) { const r = sh.data[row - 1 + i]; if (r) for (let j = 0; j < nc; j++) r[col - 1 + j] = ''; }
        while (sh.data.length && sh.data[sh.data.length - 1].every((v) => v === '' || v === undefined)) sh.data.pop();
      },
    });
  }
  function Book(name) {
    this.id = 'ss' + Object.keys(books).length;
    this.name = name;
    this.sheets = [new Sheet('Sheet1')];
    this.getId = () => this.id;
    this.getUrl = () => 'https://sheets/' + this.id;
    this.getSheetByName = (n) => this.sheets.find((s) => s.name === n) || null;
    this.insertSheet = (n) => { const s = new Sheet(n); this.sheets.push(s); return s; };
    this.getSheets = () => this.sheets;
    this.deleteSheet = (s) => { this.sheets = this.sheets.filter((x) => x !== s); };
    books[this.id] = this;
  }
  const iter = (arr) => { let i = 0; return { hasNext: () => i < arr.length, next: () => arr[i++] }; };
  const folders = [];
  const allFiles = [];
  function Folder(name, parent) {
    this.name = name; this.parent = parent; folders.push(this);
    this.id = 'folder-' + folders.length;
    this.getId = () => this.id;
    this.getParents = () => iter(parent ? [parent] : []);
    this.getFoldersByName = (n) => iter(folders.filter((f) => f.parent === this && f.name === n));
    this.createFolder = (n) => new Folder(n, this);
    this.moveTo = (dest) => { this.parent = dest; };
    this.getUrl = () => 'https://drive/' + name;
    this.files = [];
    this.getFilesByName = (n) => iter(this.files.filter((f) => f.name === n && !f.trashed));
    this.getFiles = () => iter(this.files.filter((f) => !f.trashed));
    this.createFile = (blob) => {
      const folder = this;
      const f = { name: blob.name, blob, trashed: false, getId: () => 'file-' + blob.name, getUrl: () => 'https://drive/' + blob.name, setTrashed: (v) => { f.trashed = v; },
        getBlob: () => ({ ...blob, getBytes: () => blob.bytes, getDataAsString: () => Buffer.from((blob.bytes || []).map((b) => (b < 0 ? b + 256 : b))).toString('utf8') }), getName: () => blob.name, getMimeType: () => blob.mime, getParents: () => iter([folder]),
        getSize: () => (blob.bytes || []).length, getDateCreated: () => new Date(Date.UTC(2026, 9, 1 + folder.files.length)) };
      this.files.push(f);
      allFiles.push(f);
      return f;
    };
  }
  return {
    props, books, mails,
    SpreadsheetApp: { create: (n) => new Book(n), openById: (id) => { if (!books[id]) throw new Error('gone'); return books[id]; } },
    PropertiesService: { getScriptProperties: () => ({
      getProperty: (k) => (k in props ? props[k] : null),
      setProperty: (k, v) => { props[k] = String(v); },
      deleteProperty: (k) => { delete props[k]; },
    }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    Utilities: {
      DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
      computeDigest: (alg, s) => Array.from(crypto.createHash('sha256').update(s, 'utf8').digest()).map((b) => (b > 127 ? b - 256 : b)),
      getUuid: () => crypto.randomUUID(),
      base64EncodeWebSafe: (s) => Buffer.from(s, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_'),
      base64Encode: (str) => (Array.isArray(str) ? Buffer.from(str.map((b) => (b < 0 ? b + 256 : b))) : Buffer.from(String(str), 'utf8')).toString('base64'),
      base64Decode: (b) => Array.from(Buffer.from(String(b), 'base64')),
      newBlob: (bytes, mime, name) => ({ bytes, mime, name }),
      formatDate: (d) => d.toISOString().replace('T', ' ').slice(0, 19),
    },
    Session: { getScriptTimeZone: () => 'Pacific/Fiji', getEffectiveUser: () => ({ getEmail: () => 'easybuys@example.com' }) },
    MailApp: { sendEmail: (m) => mails.push(m), getRemainingDailyQuota: () => 100 },
    DriveApp: {
      getFoldersByName: (n) => iter(folders.filter((f) => !f.parent && f.name === n)),
      createFolder: (n) => new Folder(n, null),
      getFileById: (id) => allFiles.find((f) => f.getId() === id) || { moveTo() {}, getParents: () => iter([]) },
    },
    Logger: { log() {} },
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ text: t, setMimeType() { return this; } }) },
    HtmlService: {},
    MimeType: { PDF: 'pdf', JPEG: 'jpeg' },
  };
}

function load({ pullLimit } = {}) {
  const G = makeGoogle();
  const ctx = Object.assign({ console, Date, JSON }, G);
  vm.createContext(ctx);
  let src = fs.readFileSync(path.join(__dirname, '..', 'cloud', 'Code.gs'), 'utf8');
  src = src.replace("const API_KEY = 'PASTE-THE-KEY-FROM-THE-APP-HERE'", "const API_KEY = 'tablet-key-123'");
  if (pullLimit) src = src.replace('const PULL_LIMIT = 800', `const PULL_LIMIT = ${pullLimit}`);
  vm.runInContext(src + '\nthis.__run = function (s) { return eval(s); };', ctx, { filename: 'Code.gs' });
  const post = (body) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(body) } }).text);
  return { G, ctx, post };
}

module.exports = { makeGoogle, load };
