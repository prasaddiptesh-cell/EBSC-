// Fake Google services (Sheets, Drive, Gmail, properties) and a loader for cloud/Code.gs.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

function makeGoogle() {
  const props = {};
  const books = {};
  const mails = [];
  // Like real Sheets: unless the cells are plain text, date-looking text becomes a Date and digits become numbers.
  const convert = (v, text) => {
    if (text || typeof v !== 'string') return v;
    if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}/.test(v)) return new Date(v.replace(' ', 'T'));
    if (/^\d+$/.test(v)) return Number(v);
    return v;
  };
  function Sheet(name) {
    this.name = name;
    this.data = [];
    this.text = false;
    const sh = this;
    this.getLastRow = () => sh.data.length;
    this.getLastColumn = () => sh.data.reduce((m, r) => Math.max(m, r.length), 0);
    this.getMaxRows = () => 1000;
    this.getMaxColumns = () => 26;
    this.appendRow = (r) => { sh.data.push(r.map((v) => convert(v, sh.text))); };
    this.setFrozenRows = () => {};
    this.getRange = (row, col, nr = 1, nc = 1) => ({
      setNumberFormat: (f) => { if (f === '@' && row === 1 && col === 1) sh.text = true; },
      getValues: () => {
        const out = [];
        for (let i = 0; i < nr; i++) {
          const r = sh.data[row - 1 + i] || [];
          const line = [];
          for (let j = 0; j < nc; j++) line.push(r[col - 1 + j] === undefined ? '' : r[col - 1 + j]);
          out.push(line);
        }
        return out;
      },
      setValues: (vals) => {
        vals.forEach((line, i) => {
          const r = (sh.data[row - 1 + i] = sh.data[row - 1 + i] || []);
          line.forEach((v, j) => { while (r.length < col - 1 + j) r.push(''); r[col - 1 + j] = convert(v, sh.text); });
        });
      },
      setValue: (v) => { const r = (sh.data[row - 1] = sh.data[row - 1] || []); while (r.length < col - 1) r.push(''); r[col - 1] = convert(v, sh.text); },
      // Like Sheets: emptied rows at the bottom no longer count for getLastRow.
      clearContent: () => {
        for (let i = 0; i < nr; i++) { const r = sh.data[row - 1 + i]; if (r) for (let j = 0; j < nc; j++) r[col - 1 + j] = ''; }
        while (sh.data.length && sh.data[sh.data.length - 1].every((v) => v === '' || v === undefined)) sh.data.pop();
      },
    });
  }
  function Book(name) {
    this.id = 'ss' + Object.keys(books).length;
    this.name = name;
    this.sheets = [new Sheet('Sheet1')];
    this.getId = () => this.id;
    this.getUrl = () => 'https://sheets/' + this.id;
    this.getSheetByName = (n) => this.sheets.find((s) => s.name === n) || null;
    this.insertSheet = (n) => { const s = new Sheet(n); this.sheets.push(s); return s; };
    this.getSheets = () => this.sheets;
    this.deleteSheet = (s) => { this.sheets = this.sheets.filter((x) => x !== s); };
    books[this.id] = this;
  }
  const iter = (arr) => { let i = 0; return { hasNext: () => i < arr.length, next: () => arr[i++] }; };
  const folders = [];
  const allFiles = [];
  function Folder(name, parent) {
    this.name = name; this.parent = parent; folders.push(this);
    this.id = 'folder-' + folders.length;
    this.getId = () => this.id;
    this.getParents = () => iter(parent ? [parent] : []);
    this.getFoldersByName = (n) => iter(folders.filter((f) => f.parent === this && f.name === n));
    this.createFolder = (n) => new Folder(n, this);
    this.moveTo = (dest) => { this.parent = dest; };
    this.getUrl = () => 'https://drive/' + name;
    this.files = [];
    this.getFilesByName = (n) => iter(this.files.filter((f) => f.name === n && !f.trashed));
    this.getFiles = () => iter(this.files.filter((f) => !f.trashed));
    this.createFile = (blob) => {
      const folder = this;
      const fid = 'file-' + blob.name + (allFiles.some((x) => x.getId() === 'file-' + blob.name) ? '-' + allFiles.length : '');
      const f = { name: blob.name, blob, trashed: false, getId: () => fid, getUrl: () => 'https://drive/' + fid, setTrashed: (v) => { f.trashed = v; }, isTrashed: () => f.trashed,
        makeCopy: (name, to) => to.createFile({ ...blob, name }),
        getBlob: () => ({ ...blob, getBytes: () => blob.bytes, getDataAsString: () => Buffer.from((blob.bytes || []).map((b) => (b < 0 ? b + 256 : b))).toString('utf8') }), getName: () => blob.name, getMimeType: () => blob.mime, getParents: () => iter([folder]),
        getSize: () => (blob.bytes || []).length, getDateCreated: () => new Date(Date.UTC(2026, 9, 1 + folder.files.length)) };
      this.files.push(f);
      allFiles.push(f);
      return f;
    };
  }
  // Google Calendar: the account's default calendar plus calendars the script makes.
  const calendars = [];
  let evSeq = 0;
  function Cal(name, isDefault) {
    this.name = name; this.events = []; this.isDefault = !!isDefault;
    const cal = this;
    this.getName = () => name;
    this.createEvent = (title, st, en, opts) => {
      const tags = {};
      const ev = { id: `ev${++evSeq}@google`, title, st, en, opts: opts || {}, allDay: false, visibility: 'DEFAULT', deleted: false,
        getId: () => ev.id, getTitle: () => ev.title, getStartTime: () => ev.st, getEndTime: () => ev.en, isAllDayEvent: () => ev.allDay,
        getVisibility: () => ev.visibility, getLocation: () => ev.location || '', getDescription: () => (ev.opts.description || ''),
        setTag: (k, v) => { tags[k] = String(v); }, getTag: (k) => (k in tags ? tags[k] : null),
        deleteEvent: () => { ev.deleted = true; cal.events = cal.events.filter((x) => x !== ev); } };
      cal.events.push(ev);
      return ev;
    };
    this.getEvents = (from, to) => cal.events.filter((e) => e.st < to && e.en > from);
    this.getEventsForDay = (d) => { const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const b = new Date(a.getTime() + 86400000); return cal.getEvents(a, b); };
    calendars.push(this);
  }
  new Cal('easybuys@example.com', true);
  const CalendarApp = {
    calendars,
    getDefaultCalendar: () => calendars.find((c) => c.isDefault),
    getCalendarsByName: (n) => calendars.filter((c) => c.name === n),
    createCalendar: (n) => new Cal(n, false),
    getAllOwnedCalendars: () => calendars.slice(),
  };
  return {
    props, books, mails, CalendarApp,
    SpreadsheetApp: { create: (n) => new Book(n), openById: (id) => { if (!books[id]) throw new Error('gone'); return books[id]; } },
    PropertiesService: { getScriptProperties: () => ({
      getProperty: (k) => (k in props ? props[k] : null),
      setProperty: (k, v) => { props[k] = String(v); },
      deleteProperty: (k) => { delete props[k]; },
    }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    Utilities: {
      DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' },
      computeDigest: (alg, s) => Array.from(crypto.createHash('sha256').update(Array.isArray(s) ? Buffer.from(s.map((b) => (b < 0 ? b + 256 : b))) : s, Array.isArray(s) ? undefined : 'utf8').digest()).map((b) => (b > 127 ? b - 256 : b)),
      getUuid: () => crypto.randomUUID(),
      base64EncodeWebSafe: (s) => Buffer.from(s, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_'),
      base64Encode: (str) => (Array.isArray(str) ? Buffer.from(str.map((b) => (b < 0 ? b + 256 : b))) : Buffer.from(String(str), 'utf8')).toString('base64'),
      base64Decode: (b) => Array.from(Buffer.from(String(b), 'base64')),
      newBlob: (bytes, mime, name) => ({ bytes, mime, name }),
      formatDate: (d, tz, fmt) => {
        const p2 = (n) => String(n).padStart(2, '0');
        if (fmt === 'HH:mm') return `${p2(d.getHours())}:${p2(d.getMinutes())}`;
        if (fmt === 'yyyy-MM-dd') return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
        return d.toISOString().replace('T', ' ').slice(0, 19);
      },
    },
    Session: { getScriptTimeZone: () => 'Pacific/Fiji', getEffectiveUser: () => ({ getEmail: () => 'easybuys@example.com' }) },
    MailApp: { sendEmail: (m) => mails.push(m), getRemainingDailyQuota: () => 100 },
    DriveApp: {
      getFoldersByName: (n) => iter(folders.filter((f) => !f.parent && f.name === n)),
      createFolder: (n) => new Folder(n, null),
      getFileById: (id) => allFiles.find((f) => f.getId() === id) || { moveTo() {}, getParents: () => iter([]) },
      _all: allFiles,
    },
    Logger: { log() {} },
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ text: t, setMimeType() { return this; } }) },
    HtmlService: {},
    MimeType: { PDF: 'pdf', JPEG: 'jpeg' },
  };
}

function load({ pullLimit } = {}) {
  const G = makeGoogle();
  const ctx = Object.assign({ console, Date, JSON }, G);
  vm.createContext(ctx);
  let src = fs.readFileSync(path.join(__dirname, '..', 'cloud', 'Code.gs'), 'utf8');
  src = src.replace("const API_KEY = 'PASTE-THE-KEY-FROM-THE-APP-HERE'", "const API_KEY = 'tablet-key-123'");
  if (pullLimit) src = src.replace('const PULL_LIMIT = 800', `const PULL_LIMIT = ${pullLimit}`);
  vm.runInContext(src + '\nthis.__run = function (s) { return eval(s); };', ctx, { filename: 'Code.gs' });
  const post = (body) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(body) } }).text);
  return { G, ctx, post };
}

module.exports = { makeGoogle, load };
