// 3.9.3 FCCC price-controlled products: the app finds a new Master Price List on the FCCC website (by the date in the
// PDF name), warns once, someone ticks it checked; controlled products priced above the FCCC price are urgent.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as F from '../src/modules/inventory/fccc.js';
import { alerts } from '../src/modules/inventory/alerts.js';
import { test, atest, done, assert, throws } from './harness.js';
import fs from 'fs';
import { pdfTextItems, pdfLines } from '../src/services/pdfText.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const staff = saveUser({ name: 'Cashier', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
const sugar = I.saveItem(owner, { code: 'SU2', name: 'Sugar 2kg', unit: 'each', cost: 4, price: 5.2, vatType: 'zero' });
const uid = (x) => (typeof x === 'string' ? x : x.uid);
const page = (d) => `<p><a href="https://fccc.gov.fj/wp-content/uploads/2026/10/Basic-Food-Items-Master-Price-List-as-at-${d}.pdf">Basic Food Items</a>
  <a href="/wp-content/uploads/2026/10/Produce-Summary-Master-Price-List-as-at-${d}.pdf">Produce</a> <a href="/other.pdf">x</a></p>`;
let html = page('09.10.2026');
const fetchText = async () => html;
// The tests never use the internet (on the build server it is there – the real FCCC file would be read).
const noNet = async () => { throw new Error('no internet in this test'); };

test('the FCCC page is read: list name and "as at" date from each PDF name', () => {
  const r = F.parseFcccPage(page('09.10.2026'), 'https://fccc.gov.fj/master-price-list/basic-food-items/');
  assert.deepStrictEqual(r.map((x) => [x.name, x.asAt]), [['Basic Food Items', '2026-10-09'], ['Produce Summary', '2026-10-09']]);
  assert.ok(r[1].url.startsWith('https://fccc.gov.fj/wp-content/'));
  assert.strictEqual(F.parseFcccPage('Basic-Food-Items-Master-Pricelist-as-at-17.03.21.pdf').length, 0);
  assert.strictEqual(F.parseFcccPage('<a href="x/Basic-Food-Items-Master-Pricelist-as-at-17.03.21.pdf">')[0].asAt, '2021-03-17');
});
await atest('first look: the lists are recorded and warned about; a second look soon after does nothing', async () => {
  const r = await F.checkFccc({ fetchText, fetchBytes: noNet });
  assert.strictEqual(r.fresh.length, 2);
  assert.strictEqual((await F.checkFccc({ fetchText, fetchBytes: noNet })).skipped, 'not due');
  assert.ok(alerts(owner).some((a) => /New FCCC price list: Basic Food Items as at 09.10.2026/.test(a.text)));
});
await atest('checked → no more warning; the same list again is not new; a newer date is', async () => {
  for (const l of F.uncheckedLists()) F.markListChecked(owner, l.uid, 'done');
  assert.ok(!alerts(owner).some((a) => /New FCCC/.test(a.text)));
  assert.strictEqual((await F.checkFccc({ fetchText, fetchBytes: noNet, force: true })).fresh.length, 0);
  html = page('23.10.2026') + page('09.10.2026');
  const r = await F.checkFccc({ fetchText, fetchBytes: noNet, force: true });
  assert.deepStrictEqual(r.fresh.map((x) => x.asAt), ['2026-10-23', '2026-10-23']);
  throws(() => F.markListChecked(owner, 'nope'), /not found/);
  const l = F.uncheckedLists()[0];
  F.markListChecked(owner, l.uid);
  throws(() => F.markListChecked(owner, l.uid), /Already checked by Owner/);
});
await atest('website down: nothing breaks, the problem is noted', async () => {
  const r = await F.checkFccc({ fetchText: async () => { throw new Error('offline'); }, fetchBytes: noNet, force: true });
  assert.ok(r.problems.length === 2 && r.fresh.length === 0);
  assert.ok(/offline/.test(F.fcccStatus().problem));
});
test('a controlled product above the FCCC price is urgent until Aronium is fixed', () => {
  throws(() => F.setFcccPrice(staff, uid(sugar), { max: 5 }), /cannot change/);
  throws(() => F.setFcccPrice(owner, uid(sugar), { max: '' }), /Enter the FCCC price/);
  F.setFcccPrice(owner, uid(sugar), { max: 5.0, name: 'Sugar brown 2kg' });
  const a = alerts(owner).find((x) => /above the FCCC price/.test(x.text));
  assert.ok(a && a.level === 'urgent' && /Sugar 2kg: All \$5\.20 – FCCC \$5\.00/.test(a.sub), JSON.stringify(a));
  db().run('UPDATE inv_items SET price = 4.95 WHERE uid = ?', [uid(sugar)]);
  assert.ok(!alerts(owner).some((x) => /above the FCCC price/.test(x.text)));
  assert.strictEqual(F.controlledProducts().length, 1);
  F.setFcccPrice(owner, uid(sugar), { controlled: false });
  assert.strictEqual(F.controlledProducts().length, 0);
});
const pdf = (f) => new Uint8Array(fs.readFileSync(`${process.cwd()}/tests/fixtures/${f}`));
await atest('the PDF is read: Excel-style (TrueType) and browser-style (Identity-H) fonts, wrapped names, size rows', async () => {
  const a = F.parseFcccTable(pdfLines(await pdfTextItems(pdf('fccc-a.pdf'))));
  const sug = a.find((r) => r.key === 'fsc brown sugar|2kg');
  assert.ok(sug && sug.r[0] === 2.84 && sug.section === 'SUGAR', JSON.stringify(sug));
  assert.strictEqual(a.find((r) => r.key === 'fsc brown sugar|50kg').w[0], 61.2);
  assert.strictEqual(a.find((r) => /cook choice/.test(r.key) && r.qty === '10Kg').r[0], 11.9);
  const c = F.parseFcccTable(pdfLines(await pdfTextItems(pdf('fccc-c.pdf'))));
  const cc = c.find((r) => /cook choice/.test(r.key));
  assert.strictEqual(cc.description, 'Cook Choice Long Grain Rice (if Hardip Narayan retails on its own)');
  assert.strictEqual(cc.r[0], 12.5);
  assert.strictEqual(F.lineMax(cc), 12.5);
});
test('the REAL FCCC layout (lines as read from the 09.10.2026 list): items, both sizes, wrapped names, sections, produce traders', () => {
  const f = JSON.parse(fs.readFileSync(`${process.cwd()}/tests/fixtures/fccc-real-lines.json`, 'utf8'));
  const food = F.parseFcccTable(f.food);
  const find = (re, qty) => food.find((r) => re.test(r.description) && r.qty === qty);
  const g1 = find(/^Vietnamese Long Grain Rice-Gurbachan-\(If Gurbachan retails on its own\)$/, '1Kg');
  assert.ok(g1 && g1.r[0] === 0.95 && g1.section === 'Rice' && g1.vat === 'VAT = 0%', JSON.stringify(g1));
  assert.strictEqual(find(/Gurbachan retails on its own/, '10Kg').r[0], 9.53);
  assert.strictEqual(find(/Gurbachan retails on its own/, '45kg').w[0], 42.07);
  assert.strictEqual(find(/Gurbachan wholesales to another party/, '1Kg').r[0], 0.99);
  assert.strictEqual(find(/^Cook Choice Brand Long Grain Rice – If Hardip Narayan retails on its own$/, '10Kg').r[0], 11.9);
  assert.strictEqual(find(/^R B Patel Long Grain Rice Own Pack$/, '2kg').r[0], 2.08);
  const v40 = find(/10% Broken -\(If R\.B Patel retails on its own\)/, '40Kg');
  assert.ok(v40.w[0] === 55.23 && v40.r[0] === 56.29, JSON.stringify(v40));
  assert.strictEqual(find(/^Punjas Premium Quality Long Grain Rice$/, '12 x 2kg').w[0], 39.15);
  assert.strictEqual(find(/^Punjas Premium Quality Long Grain Rice$/, '2kg').r[0], 3.46);
  assert.strictEqual(find(/^Punjas Everyday Long Grain Rice$/, '1kg').r[0], 1.53);
  assert.strictEqual(food.find((r) => /Goodman Fielder Long Grain White Rice \(Delivery Exclusive\)/.test(r.description) && r.qty === '10kg').r[0], 13.11);
  // a size listed twice with different prices in one item is kept twice, never overwritten
  assert.deepStrictEqual(food.filter((r) => /Delivery Exclusive\)$/.test(r.description) && /Fielders/.test(r.description) && r.qty === '2kg').map((r) => r.r[0]).sort(), [2.2, 4.24]);
  assert.ok(food.every((r) => r.section === 'Rice' && !/^\d/.test(r.description)), 'no size or price mistaken for a name');
  const produce = F.parseFcccTable(f.produce);
  const ali = produce.find((r) => r.description === "ALI'S FARM FRESH PRODUCE (Others)" && r.qty === '1Kg');
  assert.ok(ali && ali.r[0] === 2.28 && ali.section === 'Onions', JSON.stringify(ali));
});
await atest('a new list is read; our products linked to its lines; the next list shows what changed for us', async () => {
  db().run('DELETE FROM fccc_lists'); db().run('DELETE FROM fccc_lines'); db().run("DELETE FROM settings WHERE key LIKE 'fccc_read:%'");
  const base = 'https://fccc.gov.fj/wp-content/uploads/2026/10/';
  const pageFor = (d) => `<a href="${base}Basic-Food-Items-Master-Price-List-as-at-${d}.pdf">x</a>`;
  let pg = pageFor('09.10.2026'); let file = 'fccc-a.pdf';
  const opts = { fetchText: async () => pg, fetchBytes: async () => pdf(file), force: true };
  const r1 = await F.checkFccc(opts);
  assert.ok(r1.read[0].lines >= 15, JSON.stringify(r1.read));
  const l1 = F.latestLists()[0];
  assert.ok(F.listLines(l1.uid, { q: 'brown sugar 2kg' }).length === 1);
  // suggestions: "SUGAR BROWN FSC 2KG" (Aronium style) → the FCCC line
  const s2 = I.saveItem(owner, { code: 'SB2', name: 'SUGAR BROWN FSC 2KG', unit: 'each', cost: 2.2, price: 2.84, vatType: 'zero' });
  I.saveItem(owner, { code: 'CC10', name: 'Cook Choice Rice 10kg', unit: 'bag', cost: 9, price: 11.9, vatType: 'zero' });
  const sg = F.suggestLinks();
  const hit = sg.find((x) => x.item.code === 'SB2');
  assert.ok(hit && hit.line.key === 'fsc brown sugar|2kg' && hit.max === 2.84, JSON.stringify(sg.map((x) => [x.item.name, x.line.key, x.score])));
  assert.ok(!sg.some((x) => x.item.code === 'SB2' && x.line.key === 'fsc brown sugar|4kg'));
  F.linkProduct(owner, uid(s2), l1.uid, hit.line.key);
  const cc = sg.find((x) => x.item.code === 'CC10');
  assert.ok(cc && /cook choice/.test(cc.line.key) && cc.max === 11.9, JSON.stringify(cc));
  F.linkProduct(owner, cc.item.uid, l1.uid, cc.line.key);
  assert.strictEqual(F.pendingChanges().length, 0);
  F.markListChecked(owner, l1.uid);
  // the next list (5% up on sugar 2kg and rice 10kg)
  pg = pageFor('23.10.2026') + pageFor('09.10.2026'); file = 'fccc-b.pdf';
  const r2 = await F.checkFccc(opts);
  assert.strictEqual(r2.fresh.length, 1);
  const ch = F.pendingChanges();
  assert.deepStrictEqual(ch.map((c) => [c.item.code, c.old, c.now]).sort(), [['CC10', 11.9, 12.5], ['SB2', 2.84, 2.98]]);
  const a = alerts(owner).find((x) => /New FCCC price list: Basic Food Items as at 23.10.2026 – 2 of our products changed price/.test(x.text));
  assert.ok(a && /SUGAR BROWN FSC 2KG: FCCC price \$2.84 → \$2.98/.test(a.sub), JSON.stringify(alerts(owner).map((x) => x.text)));
  // accept: prices taken, list ticked checked, nothing pending
  const l2 = F.latestLists()[0];
  assert.strictEqual(F.acceptChanges(owner, l2.uid), 2);
  assert.strictEqual(I.getItem(uid(s2)).fccc_max, 2.98);
  assert.strictEqual(F.pendingChanges().length, 0);
  assert.ok(!alerts(owner).some((x) => /New FCCC/.test(x.text)));
  throws(() => F.acceptChanges(staff, l2.uid), /cannot change/);
});
await atest('a price coming DOWN on the new list: warned that we will be above it', async () => {
  const it = I.findItem('SB2');
  db().run('UPDATE inv_items SET fccc_max = 3.10, price = 3.05 WHERE uid = ?', [it.uid]);
  const a = alerts(owner).find((x) => /above the NEW FCCC price/.test(x.text));
  assert.ok(a && /new FCCC \$2.98/.test(a.sub), JSON.stringify(alerts(owner).map((x) => x.text)));
});
await atest('a PDF that cannot be read: tried a few times, then left for a person (nothing breaks)', async () => {
  const bad = { fetchText: async () => '<a href="/x/Hardware-Master-Price-List-as-at-01.11.2026.pdf">h</a>', fetchBytes: async () => new Uint8Array([1, 2, 3]), force: true };
  for (let i = 0; i < 4; i++) await F.checkFccc(bad);
  const l = F.latestLists().find((x) => x.list_name === 'Hardware');
  assert.ok(F.readState(l.uid).tries >= 3 && F.readState(l.uid).problem, JSON.stringify(F.readState(l.uid)));
  // no internet while downloading: not counted as a try (it is read once the internet is back)
  const before = F.readState(l.uid).tries;
  await F.checkFccc({ ...bad, fetchBytes: async () => { throw new Error('offline'); } });
  assert.strictEqual(F.readState(l.uid).tries, before);
  assert.ok(/Could not download/.test(F.readState(l.uid).problem));
  assert.ok(alerts(owner).some((x) => /Hardware as at 01.11.2026/.test(x.text)));
});

await atest('the REAL FCCC list, when the internet is there (the build server): found and read', async () => {
  let html0 = null;
  try { const res = await fetch('https://fccc.gov.fj/master-price-list/basic-food-items/'); html0 = res.ok ? await res.text() : null; } catch (e) { html0 = null; }
  if (!html0) { console.log('     (no internet here – the real list is checked on the build server)'); return; }
  const found = F.parseFcccPage(html0, 'https://fccc.gov.fj/master-price-list/basic-food-items/');
  assert.ok(found.length >= 1, 'a Master Price List PDF is linked on the FCCC page');
  const res = await fetch(found[0].url);
  assert.ok(res.ok, `PDF download ${res.status}`);
  const recs = F.parseFcccTable(pdfLines(await pdfTextItems(new Uint8Array(await res.arrayBuffer()))));
  const priced = recs.filter((r) => F.lineMax(r) !== null);
  const sample = priced.slice(0, 3).map((r) => `${r.description} ${r.qty} = $${F.lineMax(r)}`).join(' | ');
  console.log(`::notice::FCCC real list ${found[0].name} as at ${found[0].asAt}: ${recs.length} lines, ${priced.length} with a Viti Levu urban price. e.g. ${sample}`);
  assert.ok(recs.length >= 50 && priced.length >= 30, `only ${recs.length} lines read (${priced.length} priced) – the layout may have changed`);
  const bad = recs.filter((r) => /^\d/.test(r.description) || !r.description);
  assert.ok(bad.length <= recs.length * 0.02, `${bad.length} lines without a proper name, e.g. ${bad.slice(0, 3).map((r) => r.description).join(' | ')}`);
});
done();
