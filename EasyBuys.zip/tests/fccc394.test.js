// 3.9.4 FCCC by itself: the app marks our products that are on the newest FCCC list (clear matches), watches possible
// ones, takes new FCCC prices, ticks the list when every shop's Aronium price is within the cap, and a tick can be undone.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as F from '../src/modules/inventory/fccc.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
setSetting('cloud_key', 'tablet-key-123'); // this is the main tablet
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const uidOf = (x) => (typeof x === 'string' ? x : x.uid);
const item = (code, name, price) => { const u = uidOf(I.saveItem(owner, { code, name, unit: 'each', cost: 1, price, vatType: 'zero' })); I.saveItemShop(owner, { itemUid: u, shopCode: 'S1', active: true, price }); return u; };
const sugar = item('SU2', 'Sugar Brown 2kg', 2.9);
const flour = item('FL1', 'Flour Plain 1kg', 2.4);
const rice = item('RI1', 'Rice Parboiled Sunrise 1kg', 3.5); // two words in common with the FCCC line, plus a brand: not certain
const soap = item('SO1', 'Soap Bar 250g', 2.0); // not on the list

const LIST = 'FCCC-2026-10-09-basic';
db().run("INSERT INTO fccc_lists (uid, list_name, as_at, url, found_at, updated_at, updated_device, sync_status) VALUES (?, 'Basic Food Items', '2026-10-09', 'https://fccc.gov.fj/x.pdf', '2026-10-09 10:00', '2026-10-09 10:00', 'x', 'synced')", [LIST]);
const line = (key, desc, qty, retail) => db().run('INSERT INTO fccc_lines (list_uid, row_key, section, description, qty, w, r, page, sort) VALUES (?,?,?,?,?,?,?,?,?)',
  [LIST, key, 'Basic', desc, qty, JSON.stringify([null, null, null, null, null]), JSON.stringify([retail, retail, retail, retail, retail]), 1, 1]);
line('sugar brown|2kg', 'Sugar Brown', '2kg', 2.98);
line('flour plain|1kg', 'Flour Plain', '1kg', 2.35);
line('rice white parboiled|1kg', 'Rice White Parboiled', '1kg', 3.2);
setSetting(`fccc_read:${LIST}`, JSON.stringify({ lines: 3 }));

test('clear matches are marked controlled by the app and watched at once; unclear ones are not marked', () => {
  const r = F.autoLinkFccc();
  const names = r.linked.map((x) => x.name).sort();
  assert.deepStrictEqual(names, ['Flour Plain 1kg', 'Sugar Brown 2kg']);
  const s = db().get('SELECT fccc, fccc_auto, fccc_max FROM inv_items WHERE uid = ?', [sugar]);
  assert.deepStrictEqual([s.fccc, s.fccc_auto, s.fccc_max], [1, 1, 2.98]);
  assert.strictEqual(db().get('SELECT fccc FROM inv_items WHERE uid = ?', [rice]).fccc || 0, 0);
  assert.strictEqual(db().get('SELECT fccc FROM inv_items WHERE uid = ?', [soap]).fccc || 0, 0);
  assert.ok(F.overPriced().some((p) => p.uid === flour), 'flour at $2.40 is above $2.35 – urgent straight away');
  assert.ok(F.fcccAlerts().some((a) => /marked FCCC-controlled by the app/.test(a.text)));
});

test('a possible match priced above that FCCC price is warned about without being marked', () => {
  const m = F.possiblyOver();
  assert.ok(m.some((g) => g.item.uid === rice && g.max === 3.2), JSON.stringify(m.map((g) => g.item.name)));
  assert.ok(F.fcccAlerts().some((a) => /looks? FCCC-controlled and priced above/.test(a.text)));
});

test('a person confirms one and rejects another; a rejected product is never marked again', () => {
  F.confirmFccc(owner, sugar);
  assert.strictEqual(db().get('SELECT fccc_auto FROM inv_items WHERE uid = ?', [sugar]).fccc_auto, 0);
  F.rejectFccc(owner, flour);
  assert.strictEqual(db().get('SELECT fccc FROM inv_items WHERE uid = ?', [flour]).fccc, 0);
  F.autoLinkFccc();
  assert.strictEqual(db().get('SELECT fccc FROM inv_items WHERE uid = ?', [flour]).fccc, 0, 'stays not controlled');
  F.rejectFccc(owner, rice);
  assert.ok(!F.possiblyOver().some((g) => g.item.uid === rice), 'and no more "possibly" warning');
});

test('the list ticks itself only when the till PCs\' prices are fresh and everything is within the cap', () => {
  assert.strictEqual(F.autoReview().ticked, 0, 'no prices from the till PCs yet: a person ticks it');
  const now = new Date().toISOString();
  db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES ('S1-T1|products|all|0', 'S1-T1', 'S1', 'Till 1', 'products', 'all', 0, 1, '[]', 'h', ?, '1.1', ?, 'bridge', 'synced')`, [now, now]);
  db().run("UPDATE inv_item_shops SET price = 3.10 WHERE item_uid = ?", [sugar]); // above $2.98
  assert.strictEqual(F.autoReview().ticked, 0, 'sugar above the cap: not ticked, still urgent');
  db().run("UPDATE inv_item_shops SET price = 2.95 WHERE item_uid = ?", [sugar]); // lowered in Aronium, sent by the till PC
  assert.strictEqual(F.autoReview().ticked, 1);
  const l = db().get('SELECT checked_by_name, check_note FROM fccc_lists WHERE uid = ?', [LIST]);
  assert.ok(/automatic/.test(l.checked_by_name) && /Checked by the app/.test(l.check_note), JSON.stringify(l));
});

test('a tick can be undone (owner / admin), and the warning comes back', () => {
  const staff = saveUser({ name: 'Mere', pin: '4321', role: 'staff' }, owner);
  throws(() => F.uncheckList(staff, LIST), /Only the owner/);
  F.uncheckList(owner, LIST);
  assert.strictEqual(db().get('SELECT checked_at FROM fccc_lists WHERE uid = ?', [LIST]).checked_at, null);
  assert.ok(F.fcccAlerts().some((a) => /New FCCC price list: Basic Food Items/.test(a.text)));
  throws(() => F.uncheckList(owner, LIST), /not ticked/);
});

test('a new list with a new price: taken by the app for the linked products', () => {
  const L2 = 'FCCC-2026-10-16-basic';
  db().run("INSERT INTO fccc_lists (uid, list_name, as_at, url, found_at, updated_at, updated_device, sync_status) VALUES (?, 'Basic Food Items', '2026-10-16', 'https://fccc.gov.fj/y.pdf', '2026-10-16 10:00', '2026-10-16 10:00', 'x', 'synced')", [L2]);
  db().run('INSERT INTO fccc_lines (list_uid, row_key, section, description, qty, w, r, page, sort) VALUES (?,?,?,?,?,?,?,?,?)',
    [L2, 'sugar brown|2kg', 'Basic', 'Sugar Brown', '2kg', JSON.stringify([null, null, null, null, null]), JSON.stringify([3.05, 3.05, 3.05, 3.05, 3.05]), 1, 1]);
  setSetting(`fccc_read:${L2}`, JSON.stringify({ lines: 1 }));
  const r = F.autoReview();
  assert.ok(r.taken >= 1);
  assert.strictEqual(db().get('SELECT fccc_max FROM inv_items WHERE uid = ?', [sugar]).fccc_max, 3.05);
  assert.strictEqual(r.ticked, 1, 'all within the new price: ticked by the app');
});

done();
