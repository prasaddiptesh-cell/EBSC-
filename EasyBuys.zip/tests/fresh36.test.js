// 3.6 Start fresh: choose what to clear; safety copy and cloud first (cloud failure = nothing changed); only records
// older than the fresh start; owner kept; the other devices do the same on their next sync.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { setDb, db } from '../src/db/connection.js';
import { clock, getShared, getSetting, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as F from '../src/services/startFresh.js';
import { atest, test, done, assert } from './harness.js';

const A = openNodeDb(); initDatabase(A);
clock.override = new Date('2026-10-10T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'T1', invoiceDate: '2026-10-09', total: 115, shopCode: 'S1' });
const count = (t, w = '') => db().get(`SELECT COUNT(*) AS n FROM ${t} ${w}`).n;

test('groups: activity is everything not set up; summary before confirming', () => {
  const act = F.activityTables();
  assert.ok(act.includes('ap_invoices') && act.includes('punches') && !act.includes('users') && !act.includes('audit_log') && !act.includes('ap_suppliers'));
  const sum = F.freshSummary(['activity']);
  assert.ok(sum.some((x) => x.table === 'ap_invoices' && x.rows === 1));
});
await atest('only the owner, typed START FRESH, something ticked; linked needs the main tablet; cloud failure changes nothing', async () => {
  let msg = '';
  try { await F.startFresh(mgr, { groups: ['activity'], typed: 'START FRESH' }, { linked: false }); } catch (e) { msg = e.message; }
  assert.ok(/Only the owner/.test(msg));
  try { await F.startFresh(owner, { groups: ['activity'], typed: 'start' }, { linked: false }); } catch (e) { msg = e.message; }
  assert.ok(/Type START FRESH/.test(msg));
  try { await F.startFresh(owner, { groups: ['activity'], typed: 'START FRESH' }, { linked: true, cloud: async () => ({ ok: false, error: 'old script' }) }); } catch (e) { msg = e.message; }
  assert.ok(/old script/.test(msg));
  assert.strictEqual(count('ap_invoices'), 1, 'nothing changed');
});
let marker;
await atest('start fresh: activity + staff cleared, suppliers kept, owner kept, safety copy first, cloud told', async () => {
  const calls = [];
  clock.override = new Date('2026-10-10T10:00:00');
  marker = await F.startFresh(owner, { groups: ['activity', 'staff'], typed: 'start fresh' }, { linked: true, snapshot: async () => calls.push('snap'), cloud: async (b) => { calls.push(b.kind); return { ok: true }; } });
  assert.deepStrictEqual(calls, ['snap', 'fresh_start']);
  assert.strictEqual(count('ap_invoices'), 0);
  assert.strictEqual(count('ap_suppliers'), 1, 'suppliers kept');
  assert.strictEqual(count('users', "WHERE role = 'owner'"), 1);
  assert.strictEqual(count('users', "WHERE role <> 'owner'"), 0);
  assert.ok(count('audit_log', "WHERE action LIKE 'Started fresh%'") === 1, 'history kept and noted');
  assert.strictEqual(getShared('fresh_start').id, marker.id);
});
await atest('another device: clears the same old records on sync, keeps newer ones, only once', async () => {
  const B = openNodeDb(); setDb(B); initDatabase(B);
  clock.override = new Date('2026-10-09T08:00:00');
  const o2 = saveUser({ name: 'O2', pin: '9998', role: 'owner' });
  const s2 = AP.saveSupplier(o2, { name: 'FMF', tin: '502234567' });
  AP.saveInvoice(o2, { supplierUid: s2.uid, invoiceNo: 'OLD', invoiceDate: '2026-10-09', total: 50, shopCode: 'S2' });
  clock.override = new Date('2026-10-10T11:00:00');
  AP.saveInvoice(o2, { supplierUid: s2.uid, invoiceNo: 'NEW', invoiceDate: '2026-10-10', total: 60, shopCode: 'S2' });
  let snaps = 0;
  const n = await F.applyFresh(marker, { snapshot: async () => { snaps += 1; } });
  assert.ok(n >= 1);
  assert.deepStrictEqual(db().all('SELECT invoice_no FROM ap_invoices').map((r) => r.invoice_no), ['NEW'], 'made after the fresh start: kept');
  assert.strictEqual(snaps, 1);
  assert.strictEqual(await F.applyFresh(marker), 0, 'only once');
});
done();
