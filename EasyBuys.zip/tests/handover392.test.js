// 3.9.2 Handover & takeover: the day at a shop read from everything recorded – till balances (short, paid now), the
// deposit and the cheques it covered, cheques written / handed over / paid by the bank, invoices, payments, petty cash,
// staff clock in / out, and what is still open (a cheque handed over with no deposit, a post-dated cheque coming up).
// Handed over with a signature, taken over by someone else; the summary at handover is kept; the sheet builds.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as CB from '../src/modules/payables/chequebooks.js';
import * as T from '../src/modules/till/service.js';
import * as S from '../src/modules/till/shifts.js';
import * as RC from '../src/modules/till/recount.js';
import * as TC from '../src/modules/timeclock/service.js';
import * as HO from '../src/services/handover.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-09T08:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sup = saveUser({ name: 'Supervisor', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const next = saveUser({ name: 'Evening Sup', pin: '7777', role: 'manager', shopCode: 'S1' }, owner);
const cashier = saveUser({ name: 'Cashier', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
const bank = AP.saveAccount(owner, { name: 'BSP', openingBalance: 5000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 600, lastNo: 649 });
const punjas = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 });
T.recordCash(owner, { type: 'opening', shopCode: 'S1', amount: 1000, date: '2026-10-01', note: 'start' });
const D = '2026-10-10';
let day;

test('a day happens at Shop 1', () => {
  clock.override = new Date(`${D}T07:55:00`);
  TC.punch({ user: cashier, type: 'IN', shopCode: 'S1', at: `${D} 07:55:00` });
  clock.override = new Date(`${D}T17:00:00`);
  // till short $20, cashier pays $20 now
  const c = T.saveTillCount(sup, { shopCode: 'S1', tillUid: till, shiftDate: D, shift: 'Full day', cashierUid: cashier.uid, openingFloat: 100, denominations: { n100: 13, n50: 1, n20: 1, n10: 1 },
    zCash: 1300, zTotal: 1500, tenders: [{ method: 'M-PAiSA', amount: 200 }], payouts: [], adjustments: [], floatKept: 100, reason: 'short' }, { photos: ['file:///z.jpg'] });
  RC.payShortageNow(sup, S.shortageForCount(c.uid).uid, { signature: 'sig' });
  // invoices and cheques
  const i1 = AP.saveInvoice(sup, { supplierUid: punjas.uid, invoiceNo: 'P-10', invoiceDate: D, total: 450, shopCode: 'S1' }, { canCheck: true });
  const i2 = AP.saveInvoice(sup, { supplierUid: punjas.uid, invoiceNo: 'P-11', invoiceDate: D, total: 300, shopCode: 'S1' }, { canCheck: true });
  const i3 = AP.saveInvoice(sup, { supplierUid: punjas.uid, invoiceNo: 'P-12', invoiceDate: D, total: 900, shopCode: 'S1' }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: punjas.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 600, payDate: D, allocations: [{ invoiceUid: i1.uid, amount: 450 }] });
  AP.makePayment(owner, { supplierUid: punjas.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 601, payDate: D, allocations: [{ invoiceUid: i2.uid, amount: 300 }] });
  AP.makePayment(owner, { supplierUid: punjas.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 602, payDate: D, chequeDate: '2026-10-14', allocations: [{ invoiceUid: i3.uid, amount: 900 }] });
  const q = (no) => db().get('SELECT uid FROM cheques WHERE cheque_no = ?', [no]).uid;
  CB.markHandedOver(owner, q(600), { date: D, to: 'Punjas driver' });
  CB.markHandedOver(owner, q(601), { date: D, to: 'Punjas driver' });
  // the deposit covers cheque 600 only (plus general money)
  T.saveDeposit(sup, { shopCode: 'S1', accountUid: bank.uid, date: D, slipNo: '8801', byNotes: false, cashAmount: 1200, cheques: [], covers: [{ chequeUid: q(600), amount: 450 }] });
  T.recordCash(sup, { type: 'petty_out', shopCode: 'S1', amount: 12.5, date: D, note: 'Cleaning', category: 'Cleaning' });
  TC.punch({ user: cashier, type: 'OUT', shopCode: 'S1', at: `${D} 17:00:00` });
});
test('the run-through shows every part of the day, joined up', () => {
  day = HO.handoverDay({ shopCode: 'S1', date: D });
  const sec = (k) => day.sections.find((s) => s.key === k);
  assert.strictEqual(sec('tills').rows.length, 1);
  assert.ok(/Paid by the cashier/.test(sec('tills').rows[0].sub), sec('tills').rows[0].sub);
  assert.strictEqual(day.totals.sales, 1500);
  const dep = sec('deposits').rows[0];
  assert.ok(/Covers: Cheque 600/.test(dep.sub) && /general/.test(dep.sub), dep.sub);
  const chq = sec('cheques').rows.map((r) => `${r.text} | ${r.sub}`).join('\n');
  assert.ok(/Cheque 600[^\n]*covered by a deposit/.test(chq), chq);
  assert.ok(/Cheque 601[^\n]*NOT COVERED/.test(chq), chq);
  assert.ok(/Cheque 602[^\n]*dated 2026-10-14/.test(chq), chq);
  assert.strictEqual(sec('invoices').rows.length, 3);
  assert.strictEqual(sec('payments').rows.length, 3);
  assert.ok(sec('cash').rows.some((r) => /Petty cash spent/.test(r.text)) && sec('cash').rows.some((r) => /Till shortage repaid/.test(r.text)));
  assert.ok(sec('people').rows.some((r) => r.text === 'Cashier' && /out 17:00/.test(r.sub)));
  const open = sec('open').rows.map((r) => r.text).join('\n');
  assert.ok(/Cheque 601.*no deposit/.test(open) && /Post-dated cheque 602/.test(open), open);
  assert.strictEqual(day.totals.uncovered, 300);
  assert.ok(sec('open').rows.every((r) => r.nav && r.nav.screen), 'every open line opens its record');
});
test('hand over (signed) and take over by someone else; the summary at handover is kept', () => {
  throws(() => HO.handOver(sup, { shopCode: 'S1', date: D, notes: 'x' }), /Sign/);
  const h = HO.handOver(sup, { shopCode: 'S1', date: D, notes: 'Cheque 601 – deposit tomorrow morning', signature: 'sig' });
  assert.strictEqual(h.status, 'handed');
  assert.ok(h.summary.open.some((x) => /601/.test(x)));
  assert.ok(HO.waitingTakeover({ shopCode: 'S1' }).some((x) => x.uid === h.uid));
  throws(() => HO.takeOver(sup, h.uid, { signature: 's' }), /Someone else/);
  const t = HO.takeOver(next, h.uid, { signature: 'sig2', note: 'Checked the cash' });
  assert.strictEqual(t.status, 'taken'); assert.strictEqual(t.to_name, 'Evening Sup');
  throws(() => HO.takeOver(owner, h.uid, { signature: 's' }), /already/);
  assert.ok(HO.listHandovers({ shopCode: 'S1' }).length === 1);
});
test('a shift on its own, a day with nothing, and the sheet', () => {
  const shiftDay = HO.handoverDay({ shopCode: 'S1', date: D, shift: 'Morning' });
  assert.strictEqual(shiftDay.sections.find((s) => s.key === 'tills').rows.length, 0);
  const empty = HO.handoverDay({ shopCode: 'S2', date: '2026-10-03' });
  assert.ok(empty.sections.length >= 8);
  const rep = HO.handoverReport({ uid: HO.listHandovers()[0].uid });
  assert.ok(rep.sections.length >= 8 && rep.info.some((x) => x[0] === 'Taken over by' && /Evening Sup/.test(x[1])));
  throws(() => HO.handoverDay({ shopCode: '' }), /shop/);
});
done();
