// 3.9.3 Hardening: records from a newer app (unknown tables, unknown columns) never break an older one; after an app
// update the device fetches everything once more; a wrong device clock is warned; start-up survives a broken table.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, getSetting, APP_VERSION } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { applyPulledRecords } from '../src/services/records.js';
import { alerts as syncAlerts } from '../src/modules/sync/alerts.js';
import { test, done, assert } from './harness.js';

const adapter = openNodeDb();
initDatabase(adapter);
clock.override = new Date('2026-10-11T12:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });

test('records of a table this version does not know, and columns it does not know, are skipped safely', () => {
  const n = applyPulledRecords([
    { t: 'some_future_table', k: 'X1', row: { uid: 'X1', what: 'new', updated_at: '2026-10-11 10:00:00' } },
    { t: 'tills', k: 'TL9', row: { uid: 'TL9', shop_code: 'S1', name: 'Till 9', float_amount: 100, active: 1, sort: 0, future_column: 'x', updated_at: '2026-10-11 10:00:00' } },
  ]);
  assert.strictEqual(n, 1);
  assert.ok(db().get("SELECT 1 AS x FROM tills WHERE uid = 'TL9'"));
});
test('after an app update the device fetches everything from the cloud once more', () => {
  setSetting('pull_seq', '512');
  db().run("UPDATE settings SET value = '3.9.0' WHERE key = 'app_version_seen'");
  initDatabase(adapter);
  assert.strictEqual(getSetting('pull_seq', ''), '0');
  assert.strictEqual(getSetting('app_version_seen', ''), APP_VERSION);
  setSetting('pull_seq', '77');
  initDatabase(adapter); // same version: nothing changes
  assert.strictEqual(getSetting('pull_seq', ''), '77');
});
test('a device clock that is wrong is warned (urgent when an hour or more)', () => {
  setSetting('clock_skew_min', '3');
  assert.ok(!syncAlerts(owner).some((a) => a.id === 'clock-skew'));
  setSetting('clock_skew_min', '-12');
  const a = syncAlerts(owner).find((x) => x.id === 'clock-skew');
  assert.ok(a && a.level === 'warning' && /12 minutes slow/.test(a.text), a && a.text);
  setSetting('clock_skew_min', '180');
  assert.strictEqual(syncAlerts(owner).find((x) => x.id === 'clock-skew').level, 'urgent');
  setSetting('clock_skew_min', '0');
});
test('start-up survives a table that cannot be set up (noted, the rest opens)', () => {
  db().exec('DROP TABLE IF EXISTS cheque_cover');
  db().exec('CREATE VIEW cheque_cover AS SELECT 1 AS uid'); // a broken thing in the way of a CREATE INDEX
  initDatabase(adapter);
  assert.ok(db().get("SELECT 1 AS x FROM users WHERE name = 'Owner'"));
  db().exec('DROP VIEW cheque_cover');
  initDatabase(adapter);
  assert.ok(db().get("SELECT 1 AS x FROM sqlite_master WHERE name = 'cheque_cover' AND type = 'table'"));
});
done();
