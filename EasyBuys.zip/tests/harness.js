// Tiny test helpers.
import assert from 'assert';
let passed = 0, failed = 0;
export function test(name, fn) {
  try { fn(); passed++; console.log('ok   ' + name); }
  catch (e) { failed++; console.log('FAIL ' + name + '\n     ' + (e.stack || e).toString().split('\n').slice(0, 4).join('\n     ')); }
}
export async function atest(name, fn) {
  try { await fn(); passed++; console.log('ok   ' + name); }
  catch (e) { failed++; console.log('FAIL ' + name + '\n     ' + (e.stack || e).toString().split('\n').slice(0, 4).join('\n     ')); }
}
export function done() { console.log(`\n${passed} passed${failed ? `, ${failed} FAILED` : ''}`); if (failed) process.exit(1); }
export const throws = (fn, re) => assert.throws(fn, (e) => re.test(e.message));
export { assert };
