// Tiny test helpers.
import assert from 'assert';
let passed = 0, failed = 0;
// Tests run one after the other. A test that returns a promise is waited for before the next one starts
// (so "test(name, async () => …)" is really checked), and done() waits for all of them.
let chain = null;
const report = (name, e) => { if (e) { failed++; console.log('FAIL ' + name + '\n     ' + (e.stack || e).toString().split('\n').slice(0, 4).join('\n     ')); } else { passed++; console.log('ok   ' + name); } };
// A test that never finishes fails after this long (and the file fails), instead of quietly ending the run.
const TEST_MS = Number(process.env.EB_TEST_MS || 300000);
let finished = false;
function runOne(name, fn) {
  let r;
  try { r = fn(); } catch (e) { report(name, e); return null; }
  if (r && typeof r.then === 'function') {
    let timer;
    const limit = new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`did not finish within ${TEST_MS / 1000} s`)), TEST_MS); });
    return Promise.race([r, limit]).then(() => report(name), (e) => report(name, e)).finally(() => clearTimeout(timer));
  }
  report(name); return null;
}
// If the process ends before done() has reported (a test hung on something that never settles), it is a failure.
process.on('exit', (code) => { if (!finished && code === 0) { console.log('\nFAIL the test file ended before every test finished (a test never settled)'); process.exitCode = 1; } });
export function test(name, fn) {
  if (chain) { chain = chain.then(() => runOne(name, fn)); return chain; }
  const p = runOne(name, fn);
  if (p) chain = p;
  return p;
}
export async function atest(name, fn) { return test(name, fn); }
export function done() {
  const fin = () => { finished = true; console.log(`\n${passed} passed${failed ? `, ${failed} FAILED` : ''}`); if (failed) process.exit(1); };
  if (chain) return chain.then(fin); fin(); return null;
}
export const throws = (fn, re) => assert.throws(fn, (e) => re.test(e.message));
export { assert };
