// 3.9 Training mode: 3 months of practice history – made without problems, the books balance, the returns are lodged.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { seedTraining } from '../src/db/trainingSeed.js';
import { seedHistory, historyDone } from '../src/db/trainingHistory.js';
import * as A from '../src/modules/accounting/service.js';
import { test, atest, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:00:00');
const p0 = seedTraining();
clock.override = null;
let res;
await atest('3 months of history is made', async () => {
  clock.override = new Date('2026-10-11T09:00:00');
  const t = Date.now();
  res = await seedHistory({ pause: null });
  console.log(`     took ${Math.round((Date.now() - t) / 1000)} s`, JSON.stringify(res.made));
  if (res.problems.length) console.log('     problems:\n     ' + res.problems.slice(0, 25).join('\n     '));
  clock.override = new Date('2026-10-11T09:00:00');
  assert.ok(historyDone());
  assert.ok(res.made['till counts'] >= 160, 'till counts');
  assert.ok(res.made['pay runs'] >= 11, 'pay runs');
  assert.ok(res.made.deliveries >= 20, 'deliveries');
  assert.ok(res.made['supplier payments'] >= 15, 'payments');
  assert.ok(res.problems.length <= 3, `${res.problems.length} problems`);
});
test('the books balance and the first two months are lodged and paid', () => {
  assert.ok(A.trialBalance('2026-10-11').ok);
  const v = db().all("SELECT kind, period FROM tax_return_versions WHERE status = 'lodged'");
  assert.ok(v.filter((x) => x.kind === 'vat').length >= 2 && v.filter((x) => x.kind === 'fnpf').length >= 2, JSON.stringify(v));
});
await atest('running it twice does nothing', async () => {
  assert.ok(/already/.test((await seedHistory({})).problems[0]));
});
done();
