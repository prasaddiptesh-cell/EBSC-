// 3.5.1 – the owner's real Aronium product export (Windows-1252, SKU empty, joined-up column names,
// barcodes rounded by Excel, company-expense "service" rows) imports properly.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import { decodeText, decodeBase64Text } from '../src/services/textDecode.js';
import fs from 'fs';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-10T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const bytes = new Uint8Array(fs.readFileSync('tests/fixtures/aronium-products-real.csv'));
const text = decodeText(bytes);

test('text: Windows-1252 file reads "Crème" correctly; UTF-8, UTF-16 and base64 too', () => {
  assert.strictEqual(decodeText(new Uint8Array([0x43, 0x72, 0xe8, 0x6d, 0x65, 0x20, 0x80])), 'Crème €', 'Windows-1252');
  assert.strictEqual(decodeText(new Uint8Array([0xef, 0xbb, 0xbf, 0x43, 0x72, 0xc3, 0xa8, 0x6d, 0x65])), 'Crème');
  assert.strictEqual(decodeText(new Uint8Array([0xff, 0xfe, 0x41, 0, 0xe8, 0])), 'Aè');
  assert.strictEqual(decodeBase64Text(Buffer.from('Crème é', 'utf8').toString('base64')), 'Crème é');
});
test('columns: Aronium names are recognised (ProductGroup, MeasurementUnit, IsEnabled, IsService, SKU)', () => {
  const headers = I.parseCsv(text)[0];
  const m = I.guessMapping(headers);
  const h = (k) => headers[m[k]];
  assert.strictEqual(h('name'), 'Name'); assert.strictEqual(h('code'), 'SKU'); assert.strictEqual(h('group'), 'ProductGroup');
  assert.strictEqual(h('unit'), 'MeasurementUnit'); assert.strictEqual(h('active'), 'IsEnabled'); assert.strictEqual(h('service'), 'IsService');
  assert.strictEqual(h('price'), 'Price'); assert.strictEqual(h('cost'), 'Cost'); assert.strictEqual(h('tax'), 'Tax'); assert.strictEqual(h('qty'), 'Quantity');
});
let first;
test('real file: products come in although SKU is empty; services and blank rows skipped; damaged barcodes kept out', () => {
  const dry = I.importProductsCsv(owner, text, { shopCode: 'S1', fullList: true, dryRun: true });
  assert.ok(dry.added > 350, `added ${dry.added}`);
  assert.strictEqual(dry.services, 5, 'EFL Bill, Vehicle Fuel, Shop Monthly Rent, Internet, Water');
  assert.ok(dry.servicesNames.includes('EFL Bill'));
  assert.strictEqual(dry.blank, 1);
  assert.ok(dry.damaged.some((d) => d.barcode === '9416470000000'), 'FMF rounded barcode');
  assert.ok(!dry.damaged.some((d) => d.barcode === '9414621200588'), 'a real barcode is kept');
  assert.ok(dry.oddCosts.some((x) => x.startsWith('Lollies')));
  first = I.importProductsCsv(owner, text, { shopCode: 'S1', fullList: true });
  const n = db().get('SELECT COUNT(*) AS n FROM inv_items').n;
  assert.ok(n > 350);
  const tw = I.findItemByName('Twisties Extra Cheese 100g');
  assert.strictEqual(tw.barcode, '9414621200588');
  assert.strictEqual(tw.code, '9414621200588', 'good barcode used as the code');
  const fmf = I.findItemByName('FMF Kremo 135g');
  assert.ok(!fmf.barcode, 'damaged barcode not stored');
  assert.ok(/^N[0-9A-Z]{7}$/.test(fmf.code));
  const bondage = I.findItemByName('Bondage Body Spray Mens 150ml');
  assert.strictEqual(bondage.barcode, '25929165708,025929165708', 'two barcodes split on |');
  assert.ok(db().get("SELECT 1 AS x FROM inv_items WHERE name LIKE 'Oreo - Chocolate Cr%me 105g'"));
  assert.ok(!I.findItemByName('EFL Bill'));
});
test('importing the same file again changes nothing and makes no duplicates', () => {
  const before = db().get('SELECT COUNT(*) AS n FROM inv_items').n;
  const again = I.importProductsCsv(owner, text, { shopCode: 'S1', fullList: true });
  assert.strictEqual(again.added, 0, `added ${again.added}`);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM inv_items').n, before);
  assert.strictEqual(again.hidden, 0);
});
test('add a product by hand: code made, barcode checks, warnings, marked not in Aronium', () => {
  const it = I.saveItem(owner, { name: 'Coconut Buns 6pk', barcode: '9990001112223', cost: 2, price: 1.5, vatType: 'standard', unit: 'each' });
  assert.ok(/^N/.test(it.code), 'code made from the name');
  assert.strictEqual(it.aronium_seen, null);
  assert.ok(I.notInAroniumCount() >= 1);
  assert.ok(I.listProducts({ filter: 'app' }).some((x) => x.uid === it.uid));
  assert.ok(I.productWarnings({ name: 'Coconut Buns 6pk', cost: 2, price: 1.5, vatType: 'standard' }).some((w) => /already exists/.test(w)));
  assert.ok(I.productWarnings({ name: 'X', cost: 2, price: 1.5, vatType: 'standard' }).some((w) => /below the cost/.test(w)));
  let msg = '';
  try { I.saveItem(owner, { name: 'Other buns', barcode: '9990001112223', cost: 1, price: 2, vatType: 'standard' }); } catch (e) { msg = e.message; }
  assert.ok(/already on "Coconut Buns 6pk"/.test(msg), msg);
  I.setWholesalePrice(owner, it.uid, '1.20');
  assert.strictEqual(I.getItem(it.uid).wholesale_price, 1.2);
});
test('the next Aronium import links the hand-added product by name and Aronium wins', () => {
  const csv = 'Name,SKU,Barcode,Price,Cost,Tax,IsEnabled\nCoconut Buns 6pk,CB6,9990001112223,1.80,1.10,12.5,1\n';
  const r = I.importProductsCsv(owner, csv, { shopCode: 'S1' });
  assert.strictEqual(r.added, 0, 'linked, not added again');
  const it = I.findItemByName('Coconut Buns 6pk');
  assert.strictEqual(it.code, 'CB6');
  assert.strictEqual(it.price, 1.8);
  assert.ok(it.aronium_seen, 'now from Aronium');
  assert.ok(!I.listProducts({ filter: 'app' }).some((x) => x.uid === it.uid));
});
done();
