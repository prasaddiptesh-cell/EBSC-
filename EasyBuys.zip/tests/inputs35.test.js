// v3.5 inputs: reading typed dates and times, showing them, warnings, period ranges (Sat–Fri pay weeks, month and
// year edges), and optional reasons for owner/admin.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { reasonRequired, needReason, reasonLabel } from '../src/services/access.js';
import * as D from '../src/services/dates.js';
import { remember, recall } from '../src/ui/memory.js';
import { db } from '../src/db/connection.js';
import * as TS from '../src/modules/timesheets/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-13T10:00:00'); // a Tuesday
const T = '2026-10-13';

test('dates: typed in many ways, stored as YYYY-MM-DD', () => {
  const ok = (t, iso) => { const r = D.parseDate(t, T); assert.ok(r.ok, `${t}: ${r.error}`); assert.strictEqual(r.iso, iso, t); };
  ok('2026-10-13', '2026-10-13');
  ok('2026-1-5', '2026-01-05');
  ok('13/10/2026', '2026-10-13');
  ok('13-10-26', '2026-10-13');
  ok('5.3.2027', '2027-03-05');
  ok('13/10', '2026-10-13');
  ok('13102026', '2026-10-13');
  ok('13 Oct 2026', '2026-10-13');
  ok('Tue 13 Oct 2026', '2026-10-13');
  ok('13 october', '2026-10-13');
  ok('Oct 13 2026', '2026-10-13');
  ok('1st Feb 2028', '2028-02-01');
  ok('today', T); ok('yesterday', '2026-10-12'); ok('tomorrow', '2026-10-14');
  ok('29/2/2028', '2028-02-29');
  assert.ok(D.parseDate('', T).empty);
});

test('dates: impossible dates are explained in plain words', () => {
  const bad = (t, re) => { const r = D.parseDate(t, T); assert.ok(!r.ok, t); assert.ok(re.test(r.error), `${t}: ${r.error}`); };
  bad('31/2/2026', /no 31 February 2026 – February 2026 has 28 days/);
  bad('29/2/2027', /has 28 days/);
  bad('2026-13-01', /no month 13/);
  bad('31/4/2026', /April 2026 has 30 days/);
  bad('hello', /Type the date like/);
  bad('0/1/2026', /no 0 January/);
  assert.ok(D.isIsoDate('2028-02-29'));
  assert.ok(!D.isIsoDate('2026-02-29'));
  assert.ok(!D.isIsoDate('13/10/2026'));
});

test('dates: shown as "Tue 13 Oct 2026"; gentle warning when far away', () => {
  assert.strictEqual(D.fmtDate('2026-10-13'), 'Tue 13 Oct 2026');
  assert.strictEqual(D.fmtDate('2026-10-10'), 'Sat 10 Oct 2026');
  assert.strictEqual(D.fmtDate('2026-10-13', { year: false }), 'Tue 13 Oct');
  assert.strictEqual(D.fmtDmy('2026-01-05'), '5/1/2026');
  assert.strictEqual(D.dateWarning('2026-10-01', { today: T }), '');
  assert.strictEqual(D.dateWarning('2026-12-12', { today: T }), '', '60 days ahead is fine');
  assert.ok(/75 days ahead/.test(D.dateWarning('2026-12-27', { today: T })));
  assert.ok(/about 5 months ago/.test(D.dateWarning('2026-05-13', { today: T })));
  assert.ok(/2 years ago/.test(D.dateWarning('2024-10-13', { today: T })));
  assert.strictEqual(D.dateWarning('2024-10-13', { today: T, farDays: false }), '', 'caller can turn it off');
  assert.ok(/before Thu 1 Oct 2026/.test(D.dateWarning('2026-09-30', { today: T, min: '2026-10-01' })));
  assert.strictEqual(D.relDay('2026-10-10', T), '3 days ago');
  assert.strictEqual(D.daysBetween('2026-12-31', '2027-01-01'), 1);
  assert.strictEqual(D.monthGrid(2026, 10)[0].filter(Boolean)[0], '2026-10-01');
  assert.strictEqual(D.monthGrid(2026, 10)[0].indexOf('2026-10-01'), 4, '1 Oct 2026 is a Thursday');
  assert.strictEqual(D.monthGrid(2026, 2).flat().filter(Boolean).length, 28);
});

test('times: typed, shown 24-hour or 12-hour by the admin setting', () => {
  const ok = (t, h) => { const r = D.parseTime(t); assert.ok(r.ok, `${t}: ${r.error}`); assert.strictEqual(r.hhmm, h, t); };
  ok('8', '08:00'); ok('830', '08:30'); ok('0830', '08:30'); ok('8:30', '08:30'); ok('8.30', '08:30'); ok('20:30', '20:30');
  ok('8:30pm', '20:30'); ok('8 pm', '20:00'); ok('12am', '00:00'); ok('12:15 pm', '12:15'); ok('noon', '12:00');
  assert.ok(/00 to 59/.test(D.parseTime('8:75').error));
  assert.ok(/0 to 23/.test(D.parseTime('25:00').error));
  assert.ok(/1 to 12/.test(D.parseTime('13pm').error));
  assert.strictEqual(D.fmtTime('20:30', '24h'), '20:30');
  assert.strictEqual(D.fmtTime('20:30', '12h'), '8:30 pm');
  assert.strictEqual(D.fmtTime('00:05', '12h'), '12:05 am');
  assert.strictEqual(D.addMinutes('23:55', 10), '00:05');
  assert.strictEqual(D.timeFormat(), '24h', '24-hour unless the admin changes it');
  assert.strictEqual(D.fmtTime('20:30', D.timeFormat()), '20:30');
  setShared('time_format', '12h');
  assert.strictEqual(D.timeFormat(), '12h');
  assert.strictEqual(D.fmtTime('20:30', D.timeFormat()), '8:30 pm');
  setShared('time_format', '24h');
});

test('periods: Sat–Fri pay weeks, months and years (edges included)', () => {
  const r = (k, t = T) => { const x = D.periodRange(k, t); return `${x.from}..${x.to}`; };
  assert.strictEqual(r('today'), '2026-10-13..2026-10-13');
  assert.strictEqual(r('yesterday'), '2026-10-12..2026-10-12');
  assert.strictEqual(r('thisweek'), '2026-10-10..2026-10-16', 'Saturday to Friday');
  assert.strictEqual(r('lastweek'), '2026-10-03..2026-10-09');
  assert.strictEqual(r('thisweek', '2026-10-10'), '2026-10-10..2026-10-16', 'a Saturday starts its own week');
  assert.strictEqual(r('thisweek', '2026-10-16'), '2026-10-10..2026-10-16', 'a Friday ends it');
  assert.strictEqual(r('thisweek', '2027-01-01'), '2026-12-26..2027-01-01', 'week across the new year');
  assert.strictEqual(r('thismonth'), '2026-10-01..2026-10-31');
  assert.strictEqual(r('lastmonth'), '2026-09-01..2026-09-30');
  assert.strictEqual(r('lastmonth', '2027-01-15'), '2026-12-01..2026-12-31', 'January → last December');
  assert.strictEqual(r('thismonth', '2028-02-10'), '2028-02-01..2028-02-29', 'leap year February');
  assert.strictEqual(r('lastmonth', '2027-03-31'), '2027-02-01..2027-02-28');
  assert.strictEqual(r('thisyear'), '2026-01-01..2026-12-31');
  assert.strictEqual(r('lastyear'), '2025-01-01..2025-12-31');
  assert.strictEqual(r('month'), '2026-10-01..2026-10-31', 'old name still works');
  assert.strictEqual(D.periodRange('custom', T), null);
  assert.strictEqual(D.periodKind('2026-10-10', '2026-10-16', T), 'thisweek');
  assert.strictEqual(D.periodKind('2026-10-02', '2026-10-16', T), 'custom');
  assert.strictEqual(D.periodLabel('2026-10-10', '2026-10-16'), 'Sat 10 Oct – Fri 16 Oct 2026');
  assert.strictEqual(D.periodLabel('2026-12-26', '2027-01-01'), 'Sat 26 Dec 2026 – Fri 1 Jan 2027');
  assert.strictEqual(D.periodLabel('2026-10-01', '2026-10-31'), 'October 2026');
  assert.strictEqual(D.periodLabel('2026-01-01', '2026-12-31'), '2026');
  assert.strictEqual(D.periodLabel(T, T), 'Tue 13 Oct 2026');
  assert.ok(/before the first day/.test(D.rangeProblem('2026-10-13', '2026-10-01')));
  assert.strictEqual(D.rangeProblem('2026-10-01', '2026-10-13'), '');
  assert.strictEqual(D.PERIODS.length, 9);
});

test('reasons: optional for owner and admin, still asked of everyone else', () => {
  const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
  const admin = saveUser({ name: 'Office Admin', pin: '7777', role: 'admin' }, owner);
  const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
  const pay = saveUser({ name: 'Pay Clerk', pin: '6666', role: 'payroll' }, owner);
  const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
  assert.strictEqual(reasonRequired(owner), false);
  assert.strictEqual(reasonRequired(admin), false);
  assert.strictEqual(reasonRequired({ ...owner, role: 'admin', realRole: 'owner' }), false, 'bakery view of the owner');
  assert.strictEqual(reasonRequired(mgr), true);
  assert.strictEqual(reasonRequired(pay), true);
  assert.strictEqual(reasonRequired(null), true);
  needReason(owner, '', 'Say why.');
  needReason(admin, null, 'Say why.');
  throws(() => needReason(mgr, '  ', 'Say why.'), /Say why/);
  needReason(mgr, 'Wrong shop', 'Say why.');
  assert.strictEqual(reasonLabel(owner, 'Reason (required)'), 'Reason (optional)');
  assert.strictEqual(reasonLabel(admin, 'Why?'), 'Why? (optional)');
  assert.strictEqual(reasonLabel(mgr, 'Reason (required)'), 'Reason (required)');
  // A real service: fixing a timesheet day.
  const fix = (by, reason) => TS.setDayTime(by, { userUid: mere.uid, date: '2026-10-12', cell: 'in', time: '08:00', reason });
  throws(() => fix(mgr, ''), /reason/);
  fix(admin, '');
  fix(owner, 'paper timesheet');
  const a = db().all("SELECT user_name, reason FROM audit_log WHERE table_name = 'punches' ORDER BY at, rowid");
  assert.ok(a.some((x) => x.user_name === 'Office Admin' && !x.reason), 'who did it is still recorded');
  assert.ok(a.some((x) => x.user_name === 'Divnesh Prasad' && x.reason === 'paper timesheet'), 'a typed reason is kept');
});

test('screen memory: kept per screen, oldest dropped', () => {
  remember('List#3|scroll', 420);
  assert.strictEqual(recall('List#3|scroll'), 420);
  assert.strictEqual(recall('List#4|scroll'), undefined);
  for (let i = 0; i < 500; i++) remember(`X#${i}|q`, i);
  assert.strictEqual(recall('List#3|scroll'), undefined);
  assert.strictEqual(recall('X#499|q'), 499);
});

done();
