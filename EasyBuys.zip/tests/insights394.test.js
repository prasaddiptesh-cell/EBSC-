// 3.9.4 Aronium insights: busy hours, cashier watch, price check, reorder (draft orders per supplier), slow movers.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as N from '../src/modules/aronium/insights.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:42:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });

let n = 0;
function put(source, kind, period, data, part = 0, parts = 1) {
  n += 1;
  db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'synced')`, [`${source}|${kind}|${period}|${part}`, source, source.split('-')[0], source, kind, period, part, parts, JSON.stringify(data), `h${n}`, '', '1.1', '2026-10-11T00:00:00.000Z', 'bridge']);
}
const cashier = (o) => ({ sales: 0, receipts: 0, refunds: 0, refund_value: 0, discounts: 0, discount_value: 0, voids: 0, void_value: 0, ...o });
// four Fridays (2026-09-18 … 10-09) and four Mondays, two tills in shop 1
for (const d of ['2026-09-18', '2026-09-25', '2026-10-02', '2026-10-09']) {
  put('S1-T1', 'activity', d, { date: d, hours: { '09': { value: 100, receipts: 10 }, 17: { value: 400, receipts: 40 } },
    cashiers: { Asha: cashier({ sales: 300, receipts: 30, refunds: 0 }), Ravi: cashier({ sales: 200, receipts: 20, refunds: 2, refund_value: 30, voids: 3, void_value: 20 }) } });
  put('S1-T2', 'activity', d, { date: d, hours: { 17: { value: 100, receipts: 8 } }, cashiers: { Mere: cashier({ sales: 100, receipts: 8, discounts: 1, discount_value: 1 }) } });
}
for (const d of ['2026-09-21', '2026-09-28', '2026-10-05']) put('S1-T1', 'activity', d, { date: d, hours: { 10: { value: 90, receipts: 9 } }, cashiers: {} });
put('S1-T1', 'activity', '2026-10-11', { date: '2026-10-11', hours: { '08': { value: 9999, receipts: 1 } }, cashiers: {} }); // today: not finished, left out

test('busy hours: average per weekday and hour, all tills added up, the busiest hour', () => {
  const b = N.busyHours({ shop: 'S1' });
  const fri = b.days.find((x) => x.day === 'Fri');
  assert.strictEqual(fri.samples, 4);
  assert.strictEqual(fri.avg['17'], 500, 'both tills added');
  assert.strictEqual(fri.avg['09'], 100);
  assert.strictEqual(b.days.find((x) => x.day === 'Mon').avg['10'], 90);
  assert.strictEqual(b.peak.label, 'Fri 5pm–6pm');
  assert.ok(!b.hours.includes('08'), 'today is left out');
});

test('cashier watch: refunds and voids well above the team are flagged, a normal cashier is not', () => {
  const list = N.cashierWatch({ shop: 'S1' });
  const ravi = list.find((c) => c.name === 'Ravi');
  assert.strictEqual(ravi.refunds, 8);
  assert.ok(ravi.flags.some((f) => /Refunds/.test(f)) && ravi.flags.some((f) => /Voids/.test(f)), JSON.stringify(ravi.flags));
  assert.strictEqual(list.find((c) => c.name === 'Asha').flags.length, 0);
  assert.strictEqual(list[0].name, 'Ravi', 'flagged first');
});

test('price check: different prices on two tills, and sold below cost', () => {
  put('S1-T1', 'products', 'all', [{ code: 'CK1', name: 'Coke 300ml', price: 1.6, cost: 1 }, { code: 'RI1', name: 'Rice 10kg', price: 28, cost: 20 }]);
  put('S2-T1', 'products', 'all', [{ code: 'CK1', name: 'Coke 300ml', price: 1.8, cost: 1 }, { code: 'RI1', name: 'Rice 10kg', price: 28, cost: 20 }]);
  const cols = ['code', 'name', 'sold', 'sold_value', 'refunded', 'refund_value', 'net', 'cost'];
  put('S1-T1', 'sales_day', '2026-10-10', { cols, rows: [['RI1', 'Rice 10kg', 2, 36, 0, 0, 2, 40], ['CK1', 'Coke 300ml', 10, 16, 0, 0, 10, 10]] });
  const p = N.priceCheck();
  assert.strictEqual(p.differ.length, 1);
  assert.strictEqual(p.differ[0].code, 'CK1');
  assert.deepStrictEqual([p.differ[0].low, p.differ[0].high], [1.6, 1.8]);
  assert.strictEqual(p.belowCost.length, 1);
  assert.strictEqual(p.belowCost[0].code, 'RI1');
  assert.strictEqual(p.belowCost[0].loss, 4);
});

test('reorder: grouped by supplier, one tap makes draft orders; slow movers with their value', () => {
  const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
  const it = I.saveItem(owner, { code: 'FL1', name: 'Flour 10kg', unit: 'bag', cost: 20, price: 28, vatType: 'zero', supplierUid: sup.uid });
  const uid = typeof it === 'string' ? it : it.uid;
  db().run('UPDATE inv_items SET supplier_uid = ? WHERE uid = ?', [sup.uid, uid]);
  I.saveItemShop(owner, { itemUid: uid, shopCode: 'S1', active: true, reorderLevel: 5, reorderQty: 10 });
  const groups = N.reorderList({ shop: 'S1' });
  const g = groups.find((x) => x.supplierUid === sup.uid);
  assert.ok(g && g.items.some((x) => x.code === 'FL1' && x.qty >= 10), JSON.stringify(groups));
  const made = N.makeDraftOrders(owner, { shop: 'S1' });
  assert.strictEqual(made.length, 1);
  assert.strictEqual(made[0].status, 'draft');
  const old = I.saveItem(owner, { code: 'OLD1', name: 'Old Jam', unit: 'jar', cost: 3, price: 5, vatType: 'standard' });
  const oid = typeof old === 'string' ? old : old.uid;
  I.saveItemShop(owner, { itemUid: oid, shopCode: 'S1', active: true });
  db().run(`INSERT INTO inv_moves (uid, item_uid, shop_code, move_date, type, qty, unit_cost, status, updated_at) VALUES ('MV-OLD', ?, 'S1', '2026-06-01', 'opening', 12, 3, 'active', '2026-06-01')`, [oid]);
  const slow = N.slowMovers({ shop: 'S1', days: 30 });
  const jam = slow.find((x) => x.code === 'OLD1');
  assert.ok(jam && jam.value === 36 && jam.band === '90+', JSON.stringify(slow));
});

test('the short version for Home and the dashboard never fails', () => {
  const s = N.insightSummary();
  assert.ok(s.cashierFlags.some((c) => c.name === 'Ravi'));
  assert.strictEqual(s.belowCost[0].code, 'RI1');
  assert.ok(s.peak);
});

test('the online dashboard has an Insights section', () => {
  const B = require('../src/services/board.js');
  B.boardStale();
  const b = B.buildBoard({ force: true });
  const sec = b.sections.find((x) => x.id === 'insights');
  assert.ok(sec && !sec.error, JSON.stringify(sec && sec.error));
  assert.ok(sec.blocks.some((bl) => bl.type === 'list' && bl.items.some((i) => /Ravi/.test(i.text))));
  assert.ok(sec.blocks.some((bl) => bl.type === 'table' && /below cost/.test(bl.title)));
});

done();
