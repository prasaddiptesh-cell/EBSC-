// Inventory (per shop), purchase orders with supplier budgets, receiving, transfers, returns and stock takes.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T18:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas Ltd', tin: '50-12345-0-1', onAccount: true });

const CSV = `Code;Name;Group;Barcode;Measurement unit;Cost;Price;Taxes;Quantity
1001;Punjas Flour 10kg;Flour;9300001;bag;"18,50";24.95;VAT 12.5%;40
1002;Rewa Milk 1L;Dairy;9300002;each;2.10;3.20;VAT 12.5%;120
1003;Rice 20kg;Rice;9300003;bag;30.00;42.00;Zero rated;10
1002;Duplicate;Dairy;;each;1;1;;1
;No code;;;;;;;
`;

test('CSV: Aronium columns guessed (semicolon file, comma decimals); dry run changes nothing', () => {
  const rows = I.parseCsv(CSV);
  assert.strictEqual(rows[1][5], '18,50');
  const m = I.guessMapping(rows[0]);
  assert.strictEqual(m.code, 0); assert.strictEqual(m.unit, 4); assert.strictEqual(m.cost, 5); assert.strictEqual(m.qty, 8); assert.strictEqual(m.tax, 7);
  const dry = I.importProductsCsv(owner, CSV, { shopCode: 'S1', openingStock: true, dryRun: true });
  assert.strictEqual(dry.added, 4, 'v3.5.1: a product with no code gets one made from its name');
  assert.strictEqual(dry.errors.length, 1);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM inv_items').n, 0);
});

test('CSV import into S1 with opening stock; S2 has its own stock and price', () => {
  const r = I.importProductsCsv(owner, CSV, { shopCode: 'S1', openingStock: true });
  assert.strictEqual(r.added, 4);
  const flour = I.getItem('IT-1001');
  assert.strictEqual(flour.cost, 18.5);
  assert.strictEqual(I.getItem('IT-1003').vat_type, 'zero');
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 40);
  assert.strictEqual(I.stockOf('IT-1001', 'S2'), 0);
  // S2: same products, its own quantities and a different price.
  const csv2 = 'Code,Name,Price,Quantity\n1001,Punjas Flour 10kg,25.50,8\n1002,Rewa Milk 1L,3.30,30\n';
  const r2 = I.importProductsCsv(owner, csv2, { shopCode: 'S2', openingStock: true });
  assert.strictEqual(r2.added, 0);
  assert.strictEqual(I.stockOf('IT-1001', 'S2'), 8);
  assert.strictEqual(I.itemAtShop('IT-1001', 'S2').shopPrice, 25.5);
  assert.strictEqual(I.itemAtShop('IT-1001', 'S1').shopPrice, 24.95);
  assert.strictEqual(I.getItem('IT-1001').cost, 18.5, 'no cost column → cost kept');
  // Importing again does not double the stock.
  I.importProductsCsv(owner, csv2, { shopCode: 'S2', openingStock: true });
  assert.strictEqual(I.stockOf('IT-1001', 'S2'), 8);
});

test('sales from Aronium: one line per product/shop/day; sending again replaces', () => {
  I.importSalesCsv(owner, 'Code,Quantity\n1001,5\n1002,20\n9999,3\n1001,1\n', { shopCode: 'S1', date: '2026-10-07' });
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 34);
  const again = I.importSalesCsv(owner, 'Code,Quantity\n1001,6\n1002,20\n', { shopCode: 'S1', date: '2026-10-07' });
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 34, 'same day sent again: replaced, not doubled');
  assert.strictEqual(again.lines, 2);
  const one = I.importSalesCsv(owner, 'Code,Quantity\n1001,1\n9999,3\n', { shopCode: 'S1', date: '2026-10-08', dryRun: true });
  assert.deepStrictEqual(one.unknown, ['9999']);
  assert.strictEqual(db().get("SELECT uid FROM inv_moves WHERE type = 'sale' AND item_uid = 'IT-1001'").uid, 'SL-S1-2026-10-07-1001');
});

test('write-off needs a reason; transfer is 2 steps and a shortfall is recorded', () => {
  throws(() => I.adjustStock(mgr, { itemUid: 'IT-1002', shopCode: 'S1', qty: -2 }), /reason/);
  I.adjustStock(mgr, { itemUid: 'IT-1002', shopCode: 'S1', qty: -2, reason: 'Expired' });
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), 98);
  throws(() => I.sendTransfer(mgr, { fromShop: 'S1', toShop: 'S1', lines: [{ itemUid: 'IT-1002', qty: 1 }] }), /different/);
  const t = I.sendTransfer(mgr, { fromShop: 'S1', toShop: 'S2', lines: [{ itemUid: 'IT-1002', qty: 10 }] });
  assert.ok(/^TR-261008-1/.test(t.transfer_no));
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), 88);
  assert.strictEqual(I.stockOf('IT-1002', 'S2'), 30, 'not there until received');
  throws(() => I.receiveTransfer(mgr, t.uid, { received: { 'IT-1002': 9 } }), /did not arrive/);
  const got = I.receiveTransfer(mgr, t.uid, { received: { 'IT-1002': 9 }, note: 'one bottle broken' });
  assert.strictEqual(I.stockOf('IT-1002', 'S2'), 39);
  assert.strictEqual(got.short_value, 2.1);
  assert.strictEqual(I.shrinkage({ shopCode: 'S2', from: '2026-10-01', to: '2026-10-31' }).transitShort, 2.1);
});

let po;
test('purchase order: budget over → waits for approval; approver approves with a reason', () => {
  I.saveSupplierOrdering(owner, { supplierUid: sup.uid, budgetWeekly: 500, budgetMonthly: 1500, leadDays: 3, viber: '+679 999 1234' });
  const b0 = I.budgetUse(sup.uid, '2026-10-08');
  assert.strictEqual(b0.weekStart, '2026-10-03');
  assert.strictEqual(b0.week, 0);
  po = I.savePO(mgr, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 20, unitCost: 18.5 }, { itemUid: 'IT-1003', qty: 5 }] });
  // 20 × 18.50 × 1.125 = 416.25 ; rice zero rated 5 × 30 = 150 → 566.25
  assert.strictEqual(po.total, 566.25);
  assert.strictEqual(po.expected_date, '2026-10-11');
  assert.ok(po.po_no.startsWith('PO-261008-1'));
  const s = I.submitPO(mgr, po.uid, { canApprove: false });
  assert.strictEqual(s.status, 'awaiting');
  assert.ok(/Over budget/.test(s.budget_note));
  throws(() => I.markSent(mgr, po.uid), /Approve/);
  throws(() => I.submitPO(mgr, po.uid, { canApprove: true }), /Say why/);
  const a = I.submitPO(owner, po.uid, { canApprove: true, reason: 'Flour price going up next week' });
  assert.strictEqual(a.status, 'approved');
  assert.strictEqual(I.budgetUse(sup.uid, '2026-10-08').week, 566.25);
  assert.strictEqual(I.budgetUse(sup.uid, '2026-10-08').weekLeft, -66.25);
  assert.strictEqual(I.onOrder('IT-1001', 'S1'), 20);
});

test('Viber message lists the order; block mode refuses over budget', () => {
  const t = I.poText(po.uid);
  assert.ok(t.includes(po.po_no) && t.includes('Punjas Flour 10kg (1001) – 20 bag') && !t.includes('18.5'), 'no prices in the message');
  const l = I.viberLink(t, '+679 999 1234');
  assert.ok(l.forward.startsWith('viber://forward?text=PURCHASE%20ORDER'));
  assert.strictEqual(l.chat, 'viber://chat?number=%2B6799991234');
  I.markSent(mgr, po.uid, 'viber');
  assert.strictEqual(I.getPO(po.uid).status, 'sent');
  const r = I.invRules();
  I.saveInvRules(owner, { ...r, budgetMode: 'block' });
  const p2 = I.savePO(mgr, { supplierUid: sup.uid, shopCode: 'S2', lines: [{ itemUid: 'IT-1002', qty: 10 }] });
  throws(() => I.submitPO(owner, p2.uid, { canApprove: true, reason: 'x' }), /over the Punjas Ltd budget/);
  I.saveInvRules(owner, { ...r, budgetMode: 'approve' });
  I.cancelPO(mgr, p2.uid, 'Not needed');
  assert.strictEqual(I.getPO(p2.uid).status, 'cancelled');
});

let rec;
test('receive part of the order: stock + cost updated, cost change flagged, invoice entered and linked, mismatch needs a reason', () => {
  const lines = I.getPO(po.uid).lines;
  const flour = lines.find((l) => l.item_uid === 'IT-1001');
  // 15 flour at a new price 19.20 (3.8% up → over the 2% tolerance) ; invoice 15 × 19.20 × 1.125 = 324.00
  throws(() => I.receiveDelivery(mgr, { poUid: po.uid, lines: [{ lineUid: flour.uid, qty: 15, unitCost: 19.2 }], invoice: { invoiceNo: 'INV-77', total: 324 } }), /ordered at \$18.50, invoiced at \$19.20/);
  rec = I.receiveDelivery(mgr, { poUid: po.uid, lines: [{ lineUid: flour.uid, qty: 15, unitCost: 19.2 }], invoice: { invoiceNo: 'INV-77', total: 324 }, acceptReason: 'Supplier price rise, phoned' });
  assert.strictEqual(rec.value, 324);
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 34 + 15);
  assert.strictEqual(I.getItem('IT-1001').cost, 19.2);
  assert.strictEqual(rec.costFlags.length, 1);
  const cc = I.costChanges({ unseenOnly: true });
  assert.strictEqual(cc.length, 1);
  assert.strictEqual(cc[0].old_cost, 18.5);
  assert.strictEqual(cc[0].pct, 3.78);
  const p = I.getPO(po.uid);
  assert.strictEqual(p.status, 'part');
  assert.strictEqual(p.invoices.length, 1);
  assert.strictEqual(AP.getInvoice(rec.invoice.uid).po_uid, po.uid);
  assert.strictEqual(AP.getInvoice(rec.invoice.uid).category, 'Stock for resale');
  assert.strictEqual(I.onOrder('IT-1001', 'S1'), 5);
  // An invoice total that does not match what arrived is caught.
  const rice = lines.find((l) => l.item_uid === 'IT-1003');
  throws(() => I.receiveDelivery(mgr, { poUid: po.uid, lines: [{ lineUid: rice.uid, qty: 5 }], invoice: { invoiceNo: 'INV-78', total: 160 } }), /Invoice \$160.00 but goods received come to \$150.00/);
  I.receiveDelivery(mgr, { poUid: po.uid, lines: [{ lineUid: rice.uid, qty: 5 }] }); // invoice comes later
  assert.strictEqual(I.receivedNotInvoiced({ shopCode: 'S1' }).length, 1);
  I.closeShort(mgr, po.uid, 'Supplier out of flour');
  assert.strictEqual(I.getPO(po.uid).status, 'closed');
  assert.strictEqual(I.onOrder('IT-1001', 'S1'), 0);
  // Reviewing the cost change, with a new price for S1 only.
  I.reviewCostChange(owner, cc[0].uid, { newPrice: 26.5, shopCode: 'S1' });
  assert.strictEqual(I.itemAtShop('IT-1001', 'S1').shopPrice, 26.5);
  assert.strictEqual(I.itemAtShop('IT-1001', 'S2').shopPrice, 25.5);
  assert.strictEqual(I.costChanges({ unseenOnly: true }).length, 0);
});

test('void a delivery puts stock and the order back', () => {
  const r = I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S2', extra: [{ itemUid: 'IT-1002', qty: 12, unitCost: 2.1 }], photos: ['file:///d1.jpg'] });
  assert.strictEqual(I.stockOf('IT-1002', 'S2'), 51);
  I.voidReceipt(owner, r.uid, 'Entered at the wrong shop');
  assert.strictEqual(I.stockOf('IT-1002', 'S2'), 39);
});

test('return to supplier waits for a credit note', () => {
  const uid = I.returnToSupplier(mgr, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: 'IT-1001', qty: 2 }], reason: 'Bags torn' });
  assert.strictEqual(I.stockOf('IT-1001', 'S1'), 47);
  assert.ok(I.receivedNotInvoiced({ shopCode: 'S1' }).some((x) => x.uid === uid && x.kind === 'return'));
  const cn = AP.saveInvoice(owner, { kind: 'credit', supplierUid: sup.uid, invoiceNo: 'CN-5', total: 43.2, invoiceDate: '2026-10-08' });
  const { diff } = I.linkInvoice(owner, uid, cn.uid);
  assert.strictEqual(diff, 0);
});

test('reorder suggestions use sales, delivery days, on order and pack size', () => {
  db().run("UPDATE inv_items SET pack_size = 6 WHERE uid = 'IT-1002'");
  I.saveItemShop(owner, { itemUid: 'IT-1002', shopCode: 'S1', reorderLevel: 100, reorderQty: 24 });
  const row = I.stockList({ shopCode: 'S1' }).find((r) => r.uid === 'IT-1002');
  assert.strictEqual(row.on_hand, 88);
  assert.strictEqual(row.low, true);
  assert.strictEqual(row.sold, 20);
  assert.strictEqual(row.suggest % 6, 0);
  assert.ok(row.suggest >= 24);
  assert.ok(I.suggestFor('S1', null).length >= 0);
});

let sc;
test('stock take: stock frozen, expected allows for late sales, recount over tolerance, posted only after approval', () => {
  sc = I.startCount(mgr, { shopCode: 'S1', scope: { groups: ['Flour', 'Dairy'] }, date: '2026-10-08', timing: 'after_close' });
  assert.strictEqual(sc.lines.length, 2);
  throws(() => I.adjustStock(mgr, { itemUid: 'IT-1001', shopCode: 'S1', qty: -1, reason: 'Damaged' }), /frozen/);
  throws(() => I.startCount(mgr, { shopCode: 'S1', date: '2026-10-08' }), /still open/);
  I.adjustStock(mgr, { itemUid: 'IT-1003', shopCode: 'S1', qty: -1, reason: 'Damaged' }); // rice is not in this count
  // Sales for the day arrive while counting (after close: they came before the count).
  I.importSalesCsv(owner, 'Code,Quantity\n1001,3\n', { shopCode: 'S1', date: '2026-10-08' });
  I.enterCount(mgr, sc.uid, 'IT-1001', 20);
  I.enterCount(mgr, sc.uid, 'IT-1001', 24, { add: true }); // counted in two places → 44
  I.enterCount(mgr, sc.uid, 'IT-1002', 88);
  const c = I.getCount(sc.uid);
  const fl = c.lines.find((l) => l.item_uid === 'IT-1001');
  assert.strictEqual(fl.expected, 44);
  assert.strictEqual(fl.variance, 0);
  // Change the milk count to be well off → recount asked first.
  I.enterCount(mgr, sc.uid, 'IT-1002', 70);
  const sub = I.submitCount(mgr, sc.uid);
  assert.strictEqual(sub.recount.length, 1);
  assert.strictEqual(I.getCount(sc.uid).status, 'counting');
  I.enterCount(mgr, sc.uid, 'IT-1002', 86);
  const sub2 = I.submitCount(mgr, sc.uid);
  assert.strictEqual(sub2.recount.length, 0, 'a recounted product is not sent back again');
  const r = I.getCount(sc.uid);
  assert.strictEqual(r.status, 'review');
  assert.strictEqual(r.summary.short, 1);
  assert.strictEqual(r.summary.loss, -4.2);
  assert.strictEqual(r.summary.accuracy, 50);
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), 88, 'nothing changes before approval');
  I.postCount(owner, sc.uid);
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), 86);
  assert.strictEqual(I.getCount(sc.uid).status, 'posted');
  I.adjustStock(mgr, { itemUid: 'IT-1001', shopCode: 'S1', qty: -1, reason: 'Damaged' }); // unfrozen
  const sh = I.shrinkage({ shopCode: 'S1', from: '2026-10-01', to: '2026-10-31' });
  assert.ok(sh.byReason.some((x) => x.reason === 'Stock take differences' && x.value === -4.2));
});

test('sales that arrive after a posted stock take do not change the counted stock', () => {
  const before = I.stockOf('IT-1002', 'S1');
  I.importSalesCsv(owner, 'Code,Quantity\n1002,4\n', { shopCode: 'S1', date: '2026-10-08' });
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), before, 'balanced by a stock-take correction');
  I.importSalesCsv(owner, 'Code,Quantity\n1002,1\n', { shopCode: 'S1', date: '2026-10-09' });
  assert.strictEqual(I.stockOf('IT-1002', 'S1'), before - 1, 'sales after the count reduce stock as normal');
});

test('average cost: the delivery is not counted twice', () => {
  const r = I.invRules();
  I.saveInvRules(owner, { ...r, costMethod: 'average', adjustReasons: r.adjustReasons, units: r.units });
  I.saveItem(owner, { code: '2001', name: 'Test oil', cost: 1, price: 2 });
  I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S3', extra: [{ itemUid: 'IT-2001', qty: 10, unitCost: 2 }], photos: ['file:///d2.jpg'] });
  assert.strictEqual(I.getItem('IT-2001').cost, 2, 'nothing on hand before → new cost');
  I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S3', extra: [{ itemUid: 'IT-2001', qty: 10, unitCost: 4 }], photos: ['file:///d3.jpg'] });
  assert.strictEqual(I.getItem('IT-2001').cost, 3);
  I.saveInvRules(owner, { ...r, costMethod: 'last', adjustReasons: r.adjustReasons, units: r.units });
});

test('before-opening count: sales of the count day come after it', () => {
  const c = I.startCount(mgr, { shopCode: 'S2', scope: { itemUids: ['IT-1001'] }, date: '2026-10-09', timing: 'before_open' });
  I.importSalesCsv(owner, 'Code,Quantity\n1001,2\n', { shopCode: 'S2', date: '2026-10-09' });
  assert.strictEqual(I.getCount(c.uid).lines[0].expected, 8);
  I.cancelCount(owner, c.uid, 'Test');
});

test('summaries, alerts and sync', () => {
  assert.ok(I.stockValue('S1').value > 0);
  const w = I.writeOffWatch({ from: '2026-10-01', to: '2026-10-31' });
  assert.ok(w.byPerson[0].key === 'Anita Manager');
  const al = I.invAlerts(['S1']);
  assert.ok(Array.isArray(al));
  const tables = new Set(pendingRecords(50000).map((r) => r.t));
  for (const t of ['inv_items', 'inv_item_shops', 'inv_moves', 'po_orders', 'po_lines', 'inv_receipts', 'inv_counts', 'inv_count_lines', 'inv_transfers', 'inv_cost_changes']) assert.ok(tables.has(t), t);
});

done();
