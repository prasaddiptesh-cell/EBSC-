// Licences & permits: reminders before expiry, renewals keep history, documents kept (never deleted).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as L from '../src/modules/licences/service.js';
import * as D from '../src/services/documents.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-09T08:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgrL = saveUser({ name: 'Mani Manager', pin: '8181', role: 'manager', shopCode: 'S1' }, owner);
let liq;

test('add: checks; states by date and reminder days', () => {
  throws(() => L.saveLicence(owner, { name: '', category: 'liquor' }), /what it is/);
  throws(() => L.saveLicence(owner, { name: 'X', category: 'liquor', expiryDate: '9/10/26' }), /YYYY-MM-DD/);
  liq = L.saveLicence(owner, { name: 'Liquor licence', category: 'liquor', shopCode: 'S2', licenceNo: 'LL-123', expiryDate: '2026-12-31', remindDays: 90, renewMonths: 12 });
  const biz = L.saveLicence(owner, { name: 'Business licence', category: 'trading', shopCode: 'S1', expiryDate: '2027-06-30', remindDays: 45 });
  L.saveLicence(owner, { name: 'Fire certificate', category: 'fire', shopCode: 'S1', expiryDate: '2026-10-01' });
  L.saveLicence(owner, { name: 'VAT registration', category: 'tax' });
  assert.strictEqual(L.getLicence(liq).state, 'due', '83 days left, reminders start at 90');
  assert.strictEqual(L.getLicence(biz).state, 'ok');
  const a = L.licenceAlerts();
  assert.strictEqual(a.overdue.length, 1);
  assert.strictEqual(a.due.length, 1);
  assert.ok(/EXPIRED on 2026-10-01/.test(L.alertText(a.overdue[0])));
  assert.strictEqual(L.listLicences({ filter: 'attention' }).length, 2);
  assert.ok(pendingRecords().some((r) => r.t === 'licences'), 'shared with other devices');
});

test('daily Viber check: once a day, on the milestone days', () => {
  const sent = [];
  const fn = (ev, text) => sent.push([ev, text]);
  // 2026-10-09: fire cert expired 8 days ago (not a multiple of 7), liquor 83 days left (not a milestone) → nothing
  assert.deepStrictEqual(L.dailyLicenceCheck(fn), []);
  assert.deepStrictEqual(L.dailyLicenceCheck(fn, '2026-10-09'), [], 'only once a day');
  const r = L.dailyLicenceCheck(fn, '2026-10-15'); // fire: 14 days expired; liquor: 77 left
  assert.strictEqual(r.length, 1);
  assert.strictEqual(sent[0][0], 'licence_due');
  const r2 = L.dailyLicenceCheck(fn, '2026-12-01'); // liquor 30 days left
  assert.ok(r2.some((t) => /Liquor licence/.test(t) && /30 days left/.test(t)));
});

test('renewal: applied → renewed; old expiry kept in the history', () => {
  L.startRenewal(owner, liq, { date: '2026-10-09', refNo: 'APP-77', amount: 250 });
  assert.strictEqual(L.getLicence(liq).state, 'renewing');
  throws(() => L.finishRenewal(owner, liq, { newExpiry: '2026-11-30' }), /after the old one/);
  const e = L.finishRenewal(owner, liq, {});
  assert.strictEqual(e, '2027-12-31', '12 months after the old expiry');
  const l = L.getLicence(liq);
  assert.strictEqual(l.state, 'ok');
  const ev = L.eventsFor(liq);
  assert.strictEqual(ev[0].kind, 'renewed');
  assert.strictEqual(ev[0].old_expiry, '2026-12-31');
  assert.ok(ev.some((x) => x.kind === 'applied' && x.ref_no === 'APP-77'));
});

test('documents: kept with the licence, queued for Google Drive, put aside not deleted', () => {
  throws(() => D.recordDocument(owner, { refType: 'licence', refUid: liq, kind: 'application', name: 'Application 2026' }), /Choose the file/);
  const a = D.recordDocument(owner, { refType: 'licence', refUid: liq, kind: 'application', name: 'Application 2026', path: 'file:///docs/a.pdf', mime: 'application/pdf' });
  D.recordDocument(owner, { refType: 'licence', refUid: liq, kind: 'licence_copy', name: 'Licence 2027', path: 'file:///docs/b.jpg', mime: 'image/jpeg' });
  assert.strictEqual(L.licenceDocuments(liq).length, 2);
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'doc_upload'").n, 2);
  throws(() => D.archiveDocument(mgrL, a, ''), /Say why/);
  D.archiveDocument(owner, a, 'Old version');
  assert.strictEqual(L.licenceDocuments(liq).length, 1);
  assert.strictEqual(D.listDocuments('licence', liq, { all: true }).length, 2, 'still kept');
  D.setCloudCopy(a, 'drive-id-1', 'https://drive/1');
  assert.strictEqual(D.getDocument(a).cloud_id, 'drive-id-1');
  assert.strictEqual(L.listLicences({}).find((x) => x.uid === liq).docs, 1);
});

test('no longer held: hidden from the list and from reminders; can be put back', () => {
  const fire = L.listLicences({}).find((x) => x.name === 'Fire certificate').uid;
  throws(() => L.cancelLicence(mgrL, fire, ''), /Say why/);
  L.cancelLicence(owner, fire, 'Replaced by the new certificate');
  assert.strictEqual(L.licenceAlerts().overdue.length, 0);
  assert.strictEqual(L.listLicences({ filter: 'cancelled' }).length, 1);
  L.reopenLicence(owner, fire);
  assert.strictEqual(L.licenceAlerts().overdue.length, 1);
});

done();
