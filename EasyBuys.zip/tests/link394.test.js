// 3.9.4 The Aronium link: records sent by the till PCs (table aronium_feed) become the app's own records on the main
// tablet – products, suppliers, sales per product per day (all tills of a shop added up) and End of day per till.
// Running it again never doubles anything.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, deviceId, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import * as L from '../src/modules/aronium/link.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T09:42:00');
saveUser({ name: 'Owner', pin: '9999', role: 'owner' });

const uidOf = (x) => (typeof x === 'string' ? x : x.uid);
let n = 0;
function put(source, kind, period, part, parts, data) {
  n += 1;
  const shop = source.split('-')[0];
  const uid = `${source}|${kind}|${period}|${part}`;
  db().run(`INSERT INTO aronium_feed (uid, source, shop_code, till, kind, period, part, parts, data, hash, made_at, bridge_version, updated_at, updated_device, sync_status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'synced') ON CONFLICT(uid) DO UPDATE SET data = excluded.data, hash = excluded.hash, parts = excluded.parts, updated_at = excluded.updated_at`,
  [uid, source, shop, `Shop ${shop.slice(1)}, Till ${source.slice(-1)}`, kind, period, part, parts, JSON.stringify(data), `h${n}`, '2026-10-11T00:00:00.000Z', '1.0', `2026-10-11T00:00:${String(n % 60).padStart(2, '0')}.000Z`, `bridge-${source}`]);
}
const COLS = ['code', 'name', 'sold', 'sold_value', 'refunded', 'refund_value', 'net', 'cost'];
const sales = (rows) => ({ cols: COLS, rows });
const moveQty = (shop, date, code) => (db().get("SELECT qty FROM inv_moves WHERE uid = ? AND status = 'active'", [`SL-${shop}-${date}-${code}`]) || {}).qty;

test('nothing happens on a device that is not the main tablet', () => {
  put('S1-T1', 'products', 'all', 0, 1, [{ code: '1001', name: 'Bread Loaf', barcodes: [], price: 2.5, cost: 1.2, vat_rate: null, enabled: true, service: false }]);
  assert.ok(L.processLink().skipped);
  setShared('main_tablet_device', deviceId());
  assert.ok(L.isLinkDevice());
});

test('products of a shop come from its first till, in two parts, with VAT and barcodes', () => {
  put('S1-T1', 'products', 'all', 0, 2, [{ code: '1001', name: 'Bread Loaf', barcodes: [], group: 'Bakery', unit: 'ea', price: 2.5, cost: 1.2, vat_rate: null, enabled: true, service: false }]);
  const r0 = L.processLink();
  assert.ok(!I.findItem('1001'), 'waits for part 2');
  put('S1-T1', 'products', 'all', 1, 2, [{ code: '3', name: 'Coke 1.5L', barcodes: ['5449000000996', '5449000000997'], price: 3.95, cost: 2.1, vat_rate: 12.5, enabled: true, service: false },
    { code: '2001', name: 'Rice 10kg', barcodes: ['9421000000001'], price: 25, cost: 19.5, vat_rate: null, enabled: true, service: false }]);
  put('S1-T2', 'products', 'all', 0, 1, [{ code: '1001', name: 'Bread Loaf', barcodes: [], price: 9.99, cost: 1.2, vat_rate: null, enabled: true, service: false }]);
  const r = L.processLink();
  assert.deepStrictEqual(r.errors, [], JSON.stringify(r.errors));
  const coke = I.findItem('5449000000997');
  assert.ok(coke, 'found by its second barcode');
  assert.strictEqual(coke.vat_type, 'standard');
  assert.strictEqual(I.findItem('1001').vat_type, 'zero');
  const shopPrice = db().get("SELECT price FROM inv_item_shops WHERE item_uid = ? AND shop_code = 'S1'", [I.findItem('1001').uid]).price;
  assert.strictEqual(shopPrice, 2.5, 'Till 2 does not overwrite the price list of Till 1');
  void r0;
});

test('sales of both tills of Shop 1 are added up per product per day (refunds put stock back)', () => {
  put('S1-T1', 'sales_day', '2026-10-09', 0, 1, sales([['1001', 'Bread Loaf', 10, 25, 0, 0, 10, 12], ['3', 'Coke 1.5L', 2, 7.9, 1, 3.95, 1, 2.1]]));
  put('S1-T2', 'sales_day', '2026-10-09', 0, 1, sales([['1001', 'Bread Loaf', 4, 10, 0, 0, 4, 4.8], ['2001', 'Rice 10kg', 0, 0, 1, 25, -1, -19.5]]));
  const r = L.processLink();
  assert.deepStrictEqual(r.errors, []);
  assert.strictEqual(moveQty('S1', '2026-10-09', '1001'), -14);
  assert.strictEqual(moveQty('S1', '2026-10-09', '3'), -1);
  assert.strictEqual(moveQty('S1', '2026-10-09', '2001'), 1, 'a refunded bag goes back into stock');
  const count = db().get('SELECT COUNT(*) AS n FROM inv_moves').n;
  L.processLink();
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM inv_moves').n, count, 'running again changes nothing');
});

test('a later change from one till replaces the day; a sale deleted in Aronium goes back to 0', () => {
  put('S1-T2', 'sales_day', '2026-10-09', 0, 1, sales([['1001', 'Bread Loaf', 6, 15, 0, 0, 6, 7.2]]));
  L.processLink();
  assert.strictEqual(moveQty('S1', '2026-10-09', '1001'), -16);
  assert.strictEqual(moveQty('S1', '2026-10-09', '2001'), 0);
});

test('sales of a product not in the list yet wait, and are booked once the product arrives', () => {
  put('S2-T1', 'sales_day', '2026-10-10', 0, 1, sales([['777', 'Milo 400g', 3, 30, 0, 0, 3, 21]]));
  L.processLink();
  assert.strictEqual(moveQty('S2', '2026-10-10', '777'), undefined);
  assert.ok(L.linkStatus().waiting >= 1);
  put('S2-T1', 'products', 'all', 0, 1, [{ code: '777', name: 'Milo 400g', barcodes: [], price: 10, cost: 7, vat_rate: 12.5, enabled: true, service: false }]);
  L.processLink();
  assert.strictEqual(moveQty('S2', '2026-10-10', '777'), -3);
});

test('End of day per till: the same Z number on two tills of Shop 1 are two records, each only once', () => {
  const z = (key, number, total) => ({ key, z_id: Number(key.slice(1)), number, date: '2026-10-09', closed_at: '2026-10-09 21:00:00', total, sales: total, refunds: 0, vat: 1.5, zero: 20, discounts: 0,
    receipts: 12, cash: total, card: 0, other: 0, payments: { Cash: total }, cashiers: { Asha: total }, voids: { count: 0, total: 0 }, float: {} });
  put('S1-T1', 'z', 'z5', 0, 1, z('z5', '101', 120.5));
  put('S1-T2', 'z', 'z9', 0, 1, z('z9', '101', 80));
  L.processLink();
  L.processLink();
  const eods = db().all("SELECT * FROM aronium_eods WHERE shop_code = 'S1' ORDER BY total");
  assert.strictEqual(eods.length, 2, JSON.stringify(eods));
  assert.deepStrictEqual(eods.map((e) => [e.z_number, e.total, e.source, e.till_name]), [['101', 80, 'link', 'Shop 1, Till 2'], ['101', 120.5, 'link', 'Shop 1, Till 1']]);
  assert.ok(/Asha/.test(eods[0].note));
});

test('suppliers come in from the first till of the shop (customers are left out)', () => {
  put('S1-T1', 'parties', 'all', 0, 1, [{ id: 2, name: 'Fiji Rice Ltd', tin: '50-12345-0-1', supplier: true, customer: false, enabled: true, phone: '666' }, { id: 1, name: 'Ravi (staff)', supplier: false, customer: true }]);
  L.processLink();
  const s = db().all('SELECT name, tin FROM ap_suppliers');
  assert.ok(s.some((x) => x.name === 'Fiji Rice Ltd' && x.tin === '501234501'), JSON.stringify(s));
  assert.ok(!s.some((x) => /Ravi/.test(x.name)));
});

test('status, stock, credit and sales per day for the screens and the dashboard', () => {
  put('S1-T1', 'meta', 'all', 0, 1, { counts: { Product: 3 }, notes: [], bridge_version: '1.0' });
  put('S1-T1', 'stock', 'all', 0, 1, { cols: ['code', 'qty', 'reorder_point', 'reorder_qty'], rows: [['1001', 40, 0, 0]] });
  put('S1-T2', 'stock', 'all', 0, 1, { cols: ['code', 'qty', 'reorder_point', 'reorder_qty'], rows: [['1001', 5, 0, 0]] });
  put('S1-T1', 'credit', 'all', 0, 1, [{ customer_id: 1, name: 'Ravi (staff)', owing: 5, documents: 1, oldest: '2026-10-10' }]);
  const st = L.linkStatus();
  assert.ok(st.tills.find((t) => t.source === 'S1-T1').lastZ);
  assert.strictEqual(L.aroniumStock('S1').find((x) => x.code === '1001').qty, 45);
  assert.strictEqual(L.aroniumCredit()[0].owing, 5);
  const days = L.aroniumSalesByDay({ from: '2026-10-01' });
  assert.strictEqual(days.find((d) => d.source === 'S1-T1' && d.date === '2026-10-09').value, 28.95);
});

test('a till PC that has gone quiet for 3 hours is warned about, only in trading hours', () => {
  const { quietTills } = require('../src/modules/till/alerts.js');
  const last = Math.max(...L.linkStatus().tills.map((t) => new Date(t.lastSeen).getTime()));
  const at = (h) => { const d = new Date(last + h * 3600000); return d; };
  const fresh = at(1); const old = at(5);
  if (fresh.getHours() >= 8 && fresh.getHours() < 21) assert.strictEqual(quietTills(fresh).length, 0, 'heard from an hour ago');
  const day = new Date(old); day.setHours(12, 0, 0, 0); if (day.getTime() < last + 4 * 3600000) day.setDate(day.getDate() + 1);
  assert.ok(quietTills(day).length > 0, 'quiet for hours at midday');
  const night = new Date(day); night.setHours(23, 0, 0, 0);
  assert.strictEqual(quietTills(night).length, 0, 'not at night');
});

test('the till program\'s test: the main tablet answers with the same number, ready to go up to the cloud', () => {
  put('S1-T1', 'ping', 'ping', 0, 1, { nonce: 'abc123', sent_at: '2026-10-11T00:00:00Z' });
  L.processLink();
  const p = db().get("SELECT * FROM aronium_feed WHERE uid = 'S1-T1|pong|ping|0'");
  assert.ok(p && p.sync_status === 'pending', 'answer waiting to be sent');
  assert.strictEqual(JSON.parse(p.data).nonce, 'abc123');
  db().run("UPDATE aronium_feed SET sync_status = 'synced' WHERE uid = 'S1-T1|pong|ping|0'");
  L.processLink();
  assert.strictEqual(db().get("SELECT sync_status FROM aronium_feed WHERE uid = 'S1-T1|pong|ping|0'").sync_status, 'synced', 'answered once');
});

test('staff credit from both tills becomes "Who owes us" by itself; a hand match is kept; changes replace the day', () => {
  const O = require('../src/modules/owed/service.js');
  const ravi = saveUser({ name: 'Ravi Kumar', pin: '5555', role: 'staff', shopCode: 'S1' });
  put('S1-T2', 'credit', 'all', 0, 1, [{ customer_id: 4, name: 'Ravi (staff)', owing: 7.5, documents: 2, oldest: '2026-10-08' }, { customer_id: 5, name: 'Mere', owing: 3, documents: 1, oldest: '2026-10-11' }]);
  L.processLink();
  let c = O.latestCredit();
  const r = c.rows.find((x) => x.aronium_name === 'Ravi (staff)');
  assert.ok(r, JSON.stringify(c.rows));
  assert.strictEqual(r.balance, 12.5, 'both tills added up (5 + 7.50)');
  assert.strictEqual(r.since, '2026-10-08', 'oldest of the two');
  const imports = O.listImports().length;
  O.setBalancePerson({ uid: 'x', name: 'Owner', role: 'owner' }, r.uid, uidOf(ravi));
  put('S1-T2', 'credit', 'all', 0, 1, [{ customer_id: 4, name: 'Ravi (staff)', owing: 10, documents: 3, oldest: '2026-10-08' }]);
  L.processLink();
  c = O.latestCredit();
  const r2 = c.rows.find((x) => x.aronium_name === 'Ravi (staff)');
  assert.strictEqual(r2.balance, 15);
  assert.strictEqual(r2.user_uid, uidOf(ravi), 'the hand match is kept');
  assert.ok(!c.rows.some((x) => x.aronium_name === 'Mere'), 'Mere paid up on till 2');
  assert.strictEqual(O.listImports().length, imports, 'the same day is replaced, not added');
  L.processLink();
  assert.strictEqual(O.latestCredit().rows.length, c.rows.length, 'nothing changed: nothing done');
});

done();
