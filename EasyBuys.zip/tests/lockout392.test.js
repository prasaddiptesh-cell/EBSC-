// 3.9.2 Never locked out: a blocked / paused / removed device opens with the owner or admin PIN (not staff), the
// cloud allowing it again ends the override, practice mode is never locked, the owner and admin always pass the
// "who can log in here" rules, the wrong-PIN lock never goes past 10 minutes, and one owner/admin login is warned.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting } from '../src/services/core.js';
import { saveUser, login, loginLockRemaining, resetLoginLock } from '../src/services/catalog.js';
import { deviceLock, overrideLock, lockOverride, clearLockOverride, setDeviceLock, loginBlockedHere } from '../src/modules/devices/control.js';
import { alerts as adminAlerts } from '../src/modules/admin/alerts.js';
import { alerts as syncAlerts } from '../src/modules/sync/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-11T12:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const staff = saveUser({ name: 'Staff', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);

test('blocked: locked; staff cannot open it; the owner can – with a red warning on Home', () => {
  setSetting('device_blocked', '1');
  assert.strictEqual(deviceLock().kind, 'blocked');
  throws(() => overrideLock(staff), /owner or an admin/);
  overrideLock(owner);
  assert.strictEqual(deviceLock(), null);
  assert.ok(lockOverride() && lockOverride().by === 'Owner');
  assert.ok(syncAlerts(owner).some((a) => a.id === 'device-override' && a.level === 'urgent'));
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Device lock overridden%'"));
});
test('allowed again in the cloud: the override ends, the device is normal', () => {
  setSetting('device_blocked', '0'); clearLockOverride();
  assert.strictEqual(deviceLock(), null);
  assert.ok(!syncAlerts(owner).some((a) => a.id === 'device-override'));
});
test('paused, access ended, removed: the owner can open it; wiped stays (no data left)', () => {
  for (const kind of ['suspended', 'ended', 'removed']) {
    setDeviceLock({ kind, until: kind === 'suspended' ? '2099-01-01T00:00' : undefined });
    assert.strictEqual(deviceLock().kind, kind);
    overrideLock(owner);
    assert.strictEqual(deviceLock(), null, kind);
    clearLockOverride();
  }
  setDeviceLock({ kind: 'wiped' }); overrideLock(owner);
  assert.strictEqual(deviceLock().kind, 'wiped');
  clearLockOverride(); setDeviceLock(null);
});
test('who can log in here: the owner and admin always pass', () => {
  const admin = saveUser({ name: 'Divnesh', pin: '4321', role: 'admin' }, owner);
  setSetting('device_end_date', '2026-01-01');
  assert.strictEqual(loginBlockedHere(owner), null);
  assert.strictEqual(loginBlockedHere(admin), null);
  assert.ok(loginBlockedHere(staff));
  setSetting('device_end_date', '');
});
test('wrong PINs: the lock never goes past 10 minutes', () => {
  resetLoginLock();
  let t = new Date('2026-10-11T12:00:00').getTime();
  for (let round = 0; round < 6; round++) {
    for (let i = 0; i < 5; i++) login('0000');
    assert.ok(loginLockRemaining() <= 600, `round ${round}: ${loginLockRemaining()} s`);
    t += (loginLockRemaining() + 1) * 1000; clock.override = new Date(t);
  }
  resetLoginLock();
});
test('one owner / admin login: warned to add a second', () => {
  db().run("UPDATE users SET active = 0 WHERE name = 'Divnesh'");
  db().run("UPDATE users SET active = 0 WHERE role IN ('owner','admin') AND name <> 'Owner'");
  assert.ok(adminAlerts(owner).some((a) => a.id === 'one-admin'));
  db().run("UPDATE users SET active = 1 WHERE name = 'Divnesh'");
  assert.ok(!adminAlerts(owner).some((a) => a.id === 'one-admin'));
});
done();
