import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { saveUser } from '../src/services/catalog.js';
import fs from 'fs';
const f = (process.env.EB_TMP || '/tmp/claude-0') + '/v2-bakery.db';
try { fs.unlinkSync(f); } catch (e) {}
initDatabase(openNodeDb(f));
saveUser({ name: 'Real Baker Joe', pin: '5678', role: 'worker' });
const counts = {};
for (const t of db().all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")) counts[t.name] = db().get(`SELECT count(*) c FROM "${t.name}"`).c;
fs.writeFileSync((process.env.EB_TMP || '/tmp/claude-0') + '/v2-counts.json', JSON.stringify(counts));
console.log(JSON.stringify(counts));
