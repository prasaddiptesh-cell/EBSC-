import fs from 'fs';
import os from 'os';
import path from 'path';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { login, listUsers } from '../src/services/catalog.js';
import { rangeReport } from '../src/services/reports.js';
import { test, done, assert } from './harness.js';

const copy = path.join(os.tmpdir(), `upgrade-test-${process.pid}.db`);
fs.copyFileSync('tests/fixture-v2-bakery.db', copy);
const before = JSON.parse(fs.readFileSync('tests/fixture-v2-counts.json', 'utf8'));

test('Bakery v2 database upgrades to v3 without losing a single row', () => {
  initDatabase(openNodeDb(copy));
  for (const [t, n] of Object.entries(before)) {
    if (t === 'settings') continue; // new settings may be added
    const now = db().get(`SELECT count(*) c FROM "${t}"`).c;
    assert.strictEqual(now, n, `${t}: had ${n}, now ${now}`);
  }
  assert.strictEqual(db().get("SELECT value FROM settings WHERE key='schema_version'").value, '3');
});
test('same people, same ids, same PINs; links from bakery records still work', () => {
  assert.strictEqual(login('5678').name, 'Real Baker Joe');
  assert.strictEqual(login('1111').role, 'admin');
  const orphan = db().get('SELECT count(*) c FROM transactions t LEFT JOIN users u ON u.id = t.user_id WHERE u.id IS NULL').c;
  assert.strictEqual(orphan, 0);
  assert.strictEqual(db().all('PRAGMA foreign_key_check').length, 0);
});
test('everyone gets a shared id; bakery staff are put in the Bakery shop', () => {
  const us = listUsers();
  assert.ok(us.every((u) => /^U-/.test(u.uid)));
  assert.ok(us.every((u) => u.shop_code === 'BAKERY'));
  assert.strictEqual(new Set(us.map((u) => u.uid)).size, us.length);
});
test('bakery reports still work after the upgrade', () => {
  const rep = rangeReport('production', '2020-01-01', '2030-12-31');
  assert.ok(rep.sections[1].rows.length >= 1);
});
test('defaults added: 5 shops and 6 leave types, never sent as changes', () => {
  assert.strictEqual(db().get('SELECT count(*) c FROM shops').c, 5);
  assert.strictEqual(db().get('SELECT count(*) c FROM leave_types').c, 6);
  assert.strictEqual(db().get("SELECT count(*) c FROM shops WHERE sync_status != 'seed'").c, 0);
});
test('opening the upgraded database again changes nothing', () => {
  const uids = listUsers().map((u) => u.uid).join();
  initDatabase(openNodeDb(copy));
  assert.strictEqual(listUsers().map((u) => u.uid).join(), uids);
  assert.strictEqual(db().get('SELECT count(*) c FROM shops').c, 5);
});
test('a brand-new install also works (fresh v3)', () => {
  initDatabase(openNodeDb());
  assert.ok(login('1111'));
  assert.strictEqual(db().get('SELECT count(*) c FROM shops').c, 5);
  assert.ok(listUsers().every((u) => u.uid));
});
test('upgrade: sample logins stay on the tablet; real staff are shared', () => {
  initDatabase(openNodeDb(copy));
  const rows = db().all('SELECT name, pin, sync_status FROM users');
  const real = rows.find((r) => r.name === 'Real Baker Joe');
  assert.strictEqual(real.sync_status, 'pending');
  const admin = rows.find((r) => r.name === 'Admin' && r.pin === '1111');
  if (admin) assert.strictEqual(admin.sync_status, 'seed');
  assert.strictEqual(login('5678').name, 'Real Baker Joe', 'nobody is switched off on the upgraded tablet');
});

done();
