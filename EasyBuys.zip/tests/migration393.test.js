// 3.9.3 Moving the business into the app: each step counted from what is in the app, or ticked by hand; Home shows how far.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as M from '../src/services/migration.js';
import { alerts } from '../src/modules/admin/alerts.js';
import { db } from '../src/db/connection.js';
import { retireSampleLoginsNow } from '../src/modules/devices/service.js';
import { throws } from './harness.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
test('every step has where it comes from, how, a screen and a count', () => {
  const st = M.migrationStatus();
  assert.ok(st.length >= 18);
  assert.ok(st.every((s) => s.title && s.from && s.how && s.screen && typeof s.progress === 'string'));
  assert.ok(alerts(owner).some((a) => /Moving in: \d+ of \d+ set-up steps done/.test(a.text)));
});
test('steps tick themselves as information goes in; others by hand (done / not needed)', () => {
  for (let i = 0; i < 5; i++) AP.saveSupplier(owner, { name: `Sup ${i}` });
  assert.strictEqual(M.migrationStatus().find((s) => s.key === 'suppliers').done, true);
  M.tickMigration(owner, 'vehicles', 'na');
  const v = M.migrationStatus().find((s) => s.key === 'vehicles');
  assert.ok(v.done && v.tick.v === 'na' && v.tick.by === 'Owner');
  M.tickMigration(owner, 'vehicles', null);
  assert.strictEqual(M.migrationStatus().find((s) => s.key === 'vehicles').done, false);
});
test('sample logins: warned while they still work; turned off only once a real owner / admin exists', () => {
  assert.strictEqual(M.migrationStatus().find((s) => s.key === 'samples').done, false);
  assert.ok(alerts(owner).some((a) => /sample login\(s\) \(Admin 1111…\) still work/.test(a.text)));
  assert.ok(retireSampleLoginsNow(owner) >= 1);
  assert.strictEqual(M.migrationStatus().find((s) => s.key === 'samples').done, true);
  assert.ok(!alerts(owner).some((a) => /sample login/.test(a.text)));
});
done();
