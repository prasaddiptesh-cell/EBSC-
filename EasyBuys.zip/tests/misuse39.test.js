// 3.9 mistakes and misuse: wrong PINs (lock that gets longer, written down), the same PIN twice, staff trying
// manager / owner things, dates in the future, negative and silly amounts, a double tap on Save, and a save that
// fails half way (nothing half saved).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser, login, loginLockRemaining, resetLoginLock } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as T from '../src/modules/till/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as RT from '../src/modules/payroll/returns.js';
import { setModuleOn } from '../src/modules/admin/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-20T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const staff = saveUser({ name: 'Staff', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const bank = AP.saveAccount(owner, { name: 'BSP', openingBalance: 1000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 100, lastNo: 120 });

test('wrong PINs: locked after 5, each lock longer (1, then 5 minutes), written in the change history; a right PIN after works', () => {
  resetLoginLock();
  for (let i = 0; i < 5; i++) assert.strictEqual(login('0000'), null);
  assert.ok(loginLockRemaining() > 0 && loginLockRemaining() <= 60);
  assert.strictEqual(login('9999'), null, 'even the right PIN waits while locked');
  clock.override = new Date('2026-10-20T09:01:05');
  for (let i = 0; i < 5; i++) login('0001');
  assert.ok(loginLockRemaining() > 60 && loginLockRemaining() <= 300, `second lock ${loginLockRemaining()} s`);
  assert.ok(db().get("SELECT COUNT(*) AS n FROM audit_log WHERE action LIKE 'Login locked%'").n >= 2);
  clock.override = new Date('2026-10-20T09:07:00');
  assert.ok(login('9999'), 'the right PIN works after the wait');
  resetLoginLock();
});
test('the same PIN cannot be given to two people', () => {
  throws(() => saveUser({ name: 'Another', pin: '1212', role: 'staff', shopCode: 'S1' }, owner), /PIN|already|used/i);
});
test('staff cannot do manager / owner things', () => {
  const tries = { 'add a bank account': () => AP.saveAccount(staff, { name: 'X', openingBalance: 1, openingDate: '2026-10-01' }), 'switch a module off': () => setModuleOn(staff, 'bakery', false),
    'change pay rules': () => P.savePayRules(staff, { ...P.payRules(), fnpfEmployerPct: 1 }) };
  const allowed = Object.entries(tries).filter(([, fn]) => { try { fn(); return true; } catch (e) { return false; } }).map(([k]) => k);
  assert.deepStrictEqual(allowed, [], `staff was allowed to: ${allowed.join(', ')}`);
  throws(() => RT.lodgeReturn(staff, 'vat', '2026-09', { ref: 'x' }), /cannot/);
  assert.strictEqual(P.payRules().fnpfEmployerPct, 10);
});
test('dates in the future and silly numbers are refused', () => {
  throws(() => AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'F1', invoiceDate: '2027-01-01', total: 10, shopCode: 'S1' }), /future/i);
  throws(() => AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'N1', invoiceDate: '2026-10-19', total: -50, shopCode: 'S1' }), /.+/);
  throws(() => AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'N2', invoiceDate: '2026-10-19', total: 'abc', shopCode: 'S1' }), /.+/);
  const it = I.saveItem(owner, { code: 'X1', name: 'Thing', cost: 1, price: 2 });
  throws(() => I.adjustStock(owner, { itemUid: it.uid, shopCode: 'S1', qty: 'lots', reason: 'x', date: '2026-10-19' }), /.+/);
  throws(() => I.saveItem(owner, { code: 'X2', name: 'Neg', cost: -1, price: 2 }), /negative/);
  throws(() => AP.makePayment(owner, { supplierUid: sup.uid, method: 'cash', shopCode: 'S1', receivedBy: 'x', payDate: '2026-10-20', allocations: [] }), /Tick/);
});
test('a double tap on Save: the second payment of the same invoice is refused (nothing owing), the same cheque twice refused', () => {
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'D1', invoiceDate: '2026-10-19', total: 50, shopCode: 'S1' }, { canCheck: true });
  const pay = () => AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 101, payDate: '2026-10-20', allocations: [{ invoiceUid: inv.uid, amount: 50 }] });
  pay();
  throws(pay, /only has|owing|already used/);
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_payments WHERE status = 'active'").n, 1);
});
test('a save that fails half way leaves nothing half saved (split payment, delivery)', () => {
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'H1', invoiceDate: '2026-10-19', total: 90, shopCode: 'S1' }, { canCheck: true });
  const n0 = db().get('SELECT COUNT(*) AS n FROM ap_payments').n;
  throws(() => AP.makeSplitPayment(owner, { supplierUid: sup.uid, payDate: '2026-10-20', allocations: [{ invoiceUid: inv.uid, amount: 90 }], parts: [{ method: 'cash', amount: 40, shopCode: 'S1', receivedBy: 'x' }, { method: 'cheque', amount: 50, accountUid: bank.uid, chequeNo: 101 }] }), /already used/);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_payments').n, n0);
  const it = I.saveItem(owner, { code: 'X3', name: 'Rice', cost: 1, price: 2 });
  const m0 = db().get('SELECT COUNT(*) AS n FROM inv_moves').n;
  throws(() => I.receiveDelivery(mgr, { supplierUid: sup.uid, shopCode: 'S1', extra: [{ itemUid: it.uid, qty: 5, unitCost: 1 }, { itemUid: 'NOPE', qty: 1, unitCost: 1 }], photos: ['file:///x.jpg'] }), /not found/);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM inv_moves').n, m0);
});
test('a till counted twice on one tablet is refused', () => {
  const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 });
  const c = () => T.saveTillCount(mgr, { shopCode: 'S1', tillUid: till, shiftDate: '2026-10-19', shift: 'Full day', cashierUid: staff.uid, openingFloat: 100, denominations: { n100: 3 }, zCash: 200, zTotal: 200, zVat: 22.22, tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });
  c();
  throws(c, /already counted/);
});
done();
