// 3.9.4 every pop-up keeps clear of the status bar and the navigation bar / taskbar: no plain <Modal> outside src/ui/safeModal.js.
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';
const bad = [];
const walk = (d) => readdirSync(d).forEach((f) => {
  const p = join(d, f);
  if (statSync(p).isDirectory()) return walk(p);
  if (!p.endsWith('.js') || p.endsWith('safeModal.js')) return;
  const s = readFileSync(p, 'utf8');
  if (/<Modal\b/.test(s)) bad.push(p);
});
walk(new URL('../src', import.meta.url).pathname);
if (/<Modal\b/.test(readFileSync(new URL('../App.js', import.meta.url), 'utf8'))) bad.push('App.js');
if (bad.length) { console.error(`Use SafeModal (src/ui/safeModal.js) instead of Modal in: ${bad.join(', ')}`); process.exit(1); }
console.log('pop-ups: all keep clear of the system bars');
