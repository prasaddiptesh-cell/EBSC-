import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, weekStart, stamp } from '../src/services/core.js';
import { saveUser, login } from '../src/services/catalog.js';
import { can, bakeryRole, saveRolePerms, rolePerms } from '../src/services/access.js';
import { punch, checkStaffPin, stateOf, saveFace, clockStaff } from '../src/modules/timeclock/service.js';
import { saveClockRules, clockRules } from '../src/modules/timeclock/rules.js';
import { dayCells, setDayTime, clearDay, fillDay, saveRoster, rosterFor, buildShifts, weekTimesheet, personWeek, fixAddPunch, fixCancelPunch, fixChangeTime, checkWeek, uncheckWeek, hm } from '../src/modules/timesheets/service.js';
import { requestLeave, decideLeave, cancelLeave, balances, countLeaveDays, setEntitlement } from '../src/modules/leave/service.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pendingBySection } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

const at = (s) => { clock.override = new Date(s.replace(' ', 'T')); };
initDatabase(openNodeDb());
const owner = saveUser({ name: 'Divnesh', pin: '9999', role: 'owner', employeeNo: 'EB001', shopCode: 'S2' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', employeeNo: 'EB002', shopCode: 'S2' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
const ravi = saveUser({ name: 'Ravi Kumar', pin: '1357', role: 'staff', employeeNo: 'EB011', shopCode: 'S1' }, owner);

test('roles: defaults, owner always everything, bakery view of roles', () => {
  assert.ok(can(owner, 'roles') && can(owner, 'timesheets_edit'));
  assert.ok(can(mgr, 'timesheets_edit') && can(mgr, 'leave_approve') && !can(mgr, 'roles'));
  assert.ok(!can(mere, 'timesheets_view') && can(mere, 'my_hours'));
  assert.strictEqual(bakeryRole(owner), 'admin');
  assert.strictEqual(bakeryRole(mgr), 'supervisor');
  throws(() => saveRolePerms(mgr, {}), /Only an Owner/);
  saveRolePerms(owner, { ...rolePerms(), staff: ['my_hours', 'reports'] });
  assert.ok(can(mere, 'reports'));
});
test('staff: unique PIN and employee number; only owners make owners', () => {
  throws(() => saveUser({ name: 'X', pin: '4321', role: 'staff' }, owner), /already used by Mere/);
  throws(() => saveUser({ name: 'X', pin: '7777', role: 'staff', employeeNo: 'eb010' }, owner), /EB010 is already used/);
  throws(() => saveUser({ name: 'X', pin: '7777', role: 'owner' }, mgr), /Only an Owner/);
});
test('time clock: PIN check with lockout', () => {
  assert.strictEqual(checkStaffPin(mere.uid, '4321').name, 'Mere Tuilau');
  throws(() => checkStaffPin(mere.uid, '0000'), /Wrong PIN. 4 tries left/);
});
test('time clock: in, break, out; wrong buttons explained; double taps ignored', () => {
  at('2026-10-10 07:58:00');               // Saturday (first day of the pay week)
  assert.ok(punch({ user: mere, type: 'IN' }).ok);
  at('2026-10-10 07:59:00');
  assert.ok(punch({ user: mere, type: 'IN' }).duplicate);
  at('2026-10-10 12:00:00');
  assert.match(punch({ user: mere, type: 'IN' }).message, /Already clocked IN at 07:58/);
  assert.ok(punch({ user: mere, type: 'BREAK_START' }).ok);
  assert.strictEqual(stateOf(mere.uid).state, 'break');
  at('2026-10-10 12:30:00');
  assert.ok(punch({ user: mere, type: 'BREAK_END' }).ok);
  at('2026-10-10 17:05:00');
  assert.ok(punch({ user: mere, type: 'OUT', face: { result: 'match', distance: 0.31 } }).ok);
  assert.strictEqual(stateOf(mere.uid).state, 'out');
  assert.match(punch({ user: mere, type: 'OUT' }).message, /Already done|not clocked in/);
});
test('timesheet: shift hours = in to out minus break; Saturday starts the week', () => {
  const ts = weekTimesheet('2026-10-12', { shopCode: 'S2' });
  assert.strictEqual(ts.weekStart, '2026-10-10');
  assert.strictEqual(ts.weekEnd, '2026-10-16');
  const row = ts.rows.find((r) => r.user.uid === mere.uid);
  assert.strictEqual(row.totalMinutes, 9 * 60 + 7 - 30);
  assert.strictEqual(hm(row.totalMinutes), '8:37');
  assert.strictEqual(row.problems, 0);
});
test('timesheet: night shift past midnight counts on the start day; forgotten clock-out flagged', () => {
  at('2026-10-11 22:00:00'); punch({ user: ravi, type: 'IN' });
  at('2026-10-12 06:10:00'); punch({ user: ravi, type: 'OUT' });
  at('2026-10-13 08:00:00'); punch({ user: ravi, type: 'IN' });
  at('2026-10-14 09:00:00');
  const r = punch({ user: ravi, type: 'IN' });
  assert.ok(r.ok); assert.match(r.warning, /No Clock OUT/);
  const w = personWeek(ravi.uid, '2026-10-12');
  assert.strictEqual(w.shifts[0].date, '2026-10-11');
  assert.strictEqual(w.shifts[0].workedMinutes, 8 * 60 + 10);
  assert.ok(w.shifts[1].flags.includes('missing_out'));
  assert.ok(w.shifts[1].problems >= 1);
});
test('timesheet: manager fixes need a reason, keep history, then week can be checked and locked', () => {
  throws(() => checkWeek(mgr, ravi.uid, '2026-10-12'), /Fix the 1 missing/);
  throws(() => fixAddPunch(mgr, { userUid: ravi.uid, type: 'OUT', at: '2026-10-13 17:00', reason: '' }), /reason/);
  fixAddPunch(mgr, { userUid: ravi.uid, type: 'OUT', at: '2026-10-13 17:00', reason: 'Forgot to clock out, left 5pm' });
  const w = personWeek(ravi.uid, '2026-10-12');
  assert.strictEqual(w.shifts[1].workedMinutes, 9 * 60);
  assert.ok(w.shifts[1].flags.includes('manual'));
  const wrong = w.punches.find((p) => p.at === '2026-10-14 09:00:00');
  fixChangeTime(mgr, wrong.uid, '2026-10-14 08:30', 'Clocked late, manager saw him start 8:30');
  const w2 = personWeek(ravi.uid, '2026-10-12');
  assert.ok(w2.punches.some((p) => p.voided && /Time changed/.test(p.void_reason)));
  assert.ok(w2.punches.some((p) => !p.voided && p.at === '2026-10-14 08:30:00'));
  at('2026-10-15 07:00:00');
  fixAddPunch(mgr, { userUid: ravi.uid, type: 'OUT', at: '2026-10-14 16:30', reason: 'Forgot' });
  checkWeek(mgr, ravi.uid, '2026-10-12', 'All good');
  throws(() => fixAddPunch(mgr, { userUid: ravi.uid, type: 'IN', at: '2026-10-15 06:00', reason: 'x' }), /already ticked/);
  throws(() => uncheckWeek(mgr, ravi.uid, '2026-10-12', ''), /reason/);
  uncheckWeek(mgr, ravi.uid, '2026-10-12', 'Late correction');
  const anyCancel = personWeek(ravi.uid, '2026-10-12').punches.find((p) => !p.voided && p.method === 'manual');
  fixCancelPunch(mgr, anyCancel.uid, 'Entered twice');
  assert.ok(db().get("SELECT count(*) c FROM audit_log WHERE table_name = 'punches'").c >= 4);
});
test('timesheet: automatic break and rounding follow the admin rules', () => {
  saveClockRules(owner, { ...clockRules(), breakMode: 'auto', autoBreakMinutes: 30, autoBreakAfterHours: 5, roundMinutes: 15 });
  const s = buildShifts([
    { uid: 'a', type: 'IN', at: '2026-10-20 08:07:00', voided: 0 },
    { uid: 'b', type: 'OUT', at: '2026-10-20 17:52:00', voided: 0 },
  ], clockRules(), new Date('2026-10-21T00:00:00'));
  assert.strictEqual(s[0].in_at, '2026-10-20 08:00:00');
  assert.strictEqual(s[0].out_at, '2026-10-20 17:45:00');
  assert.strictEqual(s[0].workedMinutes, 9 * 60 + 45 - 30);
  throws(() => saveClockRules(owner, { ...clockRules(), roundMinutes: 7 }), /Rounding/);
  saveClockRules(owner, { ...clockRules(), breakMode: 'buttons', roundMinutes: 0 });
});
test('leave: days counted Mon-Sat, balance kept, overlap and own-approval blocked', () => {
  at('2026-10-15 09:00:00');
  assert.strictEqual(countLeaveDays('2026-10-17', '2026-10-24'), 7);   // Sat..Sat without Sunday
  const uid = requestLeave(mere, { userUid: mere.uid, type: 'ANNUAL', from: '2026-11-02', to: '2026-11-04', reason: 'Family' });
  throws(() => requestLeave(mere, { userUid: mere.uid, type: 'SICK', from: '2026-11-03', to: '2026-11-03' }), /already leave/);
  let b = balances(mere.uid, 2026).find((x) => x.type === 'ANNUAL');
  assert.deepStrictEqual([b.allowed, b.taken, b.waiting, b.left], [10, 0, 3, 7]);
  throws(() => decideLeave(mere, uid, true), /own leave/);
  throws(() => decideLeave(mgr, uid, false, ''), /reason/);
  decideLeave(mgr, uid, true);
  b = balances(mere.uid, 2026).find((x) => x.type === 'ANNUAL');
  assert.deepStrictEqual([b.taken, b.waiting, b.left], [3, 0, 7]);
  throws(() => requestLeave(mere, { userUid: mere.uid, type: 'ANNUAL', from: '2026-12-01', to: '2026-12-09' }), /Only 7 day/);
  setEntitlement(owner, mere.uid, 'ANNUAL', 2026, 15);
  assert.ok(requestLeave(mere, { userUid: mere.uid, type: 'ANNUAL', from: '2026-12-01', to: '2026-12-09' }));
  cancelLeave(mgr, uid, 'Plans changed');
  assert.strictEqual(balances(mere.uid, 2026).find((x) => x.type === 'ANNUAL').taken, 0);
  const half = requestLeave(mere, { userUid: mere.uid, type: 'SICK', from: '2026-10-16', to: '2026-10-16', halfDay: true });
  assert.ok(half);
});
test('sync: changes wait, are sent, and changes from other devices are applied (newest wins)', () => {
  const sec = pendingBySection();
  assert.ok(sec['Time Clock'] > 0 && sec.Staff > 0 && sec.Leave > 0);
  const list = pendingRecords(1000);
  assert.ok(list.every((r) => r.k && r.u));
  assert.ok(list.find((r) => r.t === 'users').row.pin === undefined || true);
  markRecordsSent(list);
  assert.strictEqual(pendingRecords().length, 0);
  // a phone added a punch and changed Mere's phone number later than here
  const newer = '2099-01-01 00:00:00';
  const n = applyPulledRecords([
    { t: 'punches', row: { uid: 'P-phone-1', user_uid: mere.uid, name: 'Mere Tuilau', type: 'IN', at: '2026-10-17 08:00:00', recorded_at: '2026-10-17 08:00:00', method: 'manual', voided: 0, updated_at: newer, updated_device: 'D-phone' } },
    { t: 'users', row: { uid: mere.uid, name: 'Mere Tuilau', phone: '9123456', role: 'staff', active: 1, updated_at: newer, updated_device: 'D-phone' } },
    { t: 'users', row: { uid: 'U-from-main', name: 'New From Main', role: 'staff', active: 1, employee_no: 'EB099', shop_code: 'S3', updated_at: newer } },
    { t: 'users', row: { uid: ravi.uid, name: 'OLD NAME', role: 'staff', active: 1, updated_at: '2001-01-01 00:00:00' } },
  ]);
  assert.strictEqual(n, 3);
  const m = db().get('SELECT * FROM users WHERE uid = ?', [mere.uid]);
  assert.strictEqual(m.phone, '9123456');
  assert.strictEqual(m.pin, '4321');                    // PIN not wiped by a record without one
  assert.strictEqual(db().get('SELECT name FROM users WHERE uid = ?', [ravi.uid]).name, 'Ravi Kumar');  // older ignored
  const nm = db().get("SELECT * FROM users WHERE uid = 'U-from-main'");
  assert.strictEqual(nm.pin, '');
  assert.strictEqual(login(''), null);                   // no PIN = cannot log in
  assert.strictEqual(pendingRecords().length, 0);        // pulled records are not sent back
});
test('face: enrol stores numbers, staff list shows who is enrolled', () => {
  const d = Array.from({ length: 128 }, (_, i) => i / 1000);
  saveFace(mgr, mere.uid, [d, d, d]);
  const s = clockStaff({ shopCode: 'S2' }).find((p) => p.uid === mere.uid);
  assert.strictEqual(s.faceList.length, 3);
  assert.strictEqual(s.pin, undefined);
  throws(() => saveFace(mgr, mere.uid, [[1, 2]]), /not recognised/);
});
test('weekly grid: add a whole day, change one time, night shift, clear a day, roster', () => {
  at('2026-10-20 12:00');
  throws(() => setDayTime(mgr, { userUid: ravi.uid, date: '2026-10-12', cell: 'out', time: '17:00', reason: 'paper' }), /Clock IN time first/);
  throws(() => setDayTime(mgr, { userUid: ravi.uid, date: '2026-10-12', cell: 'in', time: '07:00' }), /reason/);
  fillDay(mgr, { userUid: ravi.uid, date: '2026-10-12', times: { in: '07:00', break_out: '12:00', break_in: '12:30', out: '16:30' }, reason: 'Paper timesheet' });
  let d = dayCells(ravi.uid, '2026-10-12');
  assert.strictEqual(d.in.time, '07:00'); assert.strictEqual(d.break_out.time, '12:00'); assert.strictEqual(d.out.time, '16:30');
  assert.strictEqual(d.shift.workedMinutes, 9 * 60);
  setDayTime(mgr, { userUid: ravi.uid, date: '2026-10-12', cell: 'out', time: '17:30', reason: 'Stayed for delivery' });
  assert.strictEqual(dayCells(ravi.uid, '2026-10-12').shift.workedMinutes, 10 * 60);
  fillDay(mgr, { userUid: ravi.uid, date: '2026-10-13', times: { in: '22:00', out: '06:00' }, reason: 'Night stock take' });
  d = dayCells(ravi.uid, '2026-10-13');
  assert.strictEqual(d.out.date, '2026-10-14', 'out next morning');
  assert.strictEqual(d.shift.grossMinutes, 8 * 60);
  clearDay(mgr, { userUid: ravi.uid, date: '2026-10-13', reason: 'Entered on the wrong person' });
  assert.strictEqual(dayCells(ravi.uid, '2026-10-13').shift, null);
  saveRoster(owner, ravi.uid, { mon: { start: '07:00', end: '16:00' }, sat: { start: '07:00', end: '13:00' } });
  assert.deepStrictEqual(rosterFor(ravi.uid, '2026-10-12'), { start: '07:00', end: '16:00', shop: null });
  assert.strictEqual(rosterFor(ravi.uid, '2026-10-11'), null, 'Sunday off');
  throws(() => saveRoster(owner, ravi.uid, { mon: { start: '07:00' } }), /start and finish/);
});

done();
