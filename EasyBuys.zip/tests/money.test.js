// Till & cash, deposits, bank reconciliation, regular bills & loans, and payroll.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import { saveRecurring, runRecurring, loanStatement, addLoanEntry, nextDate } from '../src/modules/payables/recurring.js';
import * as T from '../src/modules/till/service.js';
import * as B from '../src/modules/bank/service.js';
import * as P from '../src/modules/payroll/service.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { checkWeek } from '../src/modules/timesheets/service.js';
import { requestLeave, decideLeave } from '../src/modules/leave/service.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T18:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP Business', openingBalance: 10000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 500, lastNo: 549 });

// ================================================================ till
let till;
let count;
test('till: notes and coins add up (Fiji)', () => {
  assert.strictEqual(T.countDenoms({ n100: 3, n20: 2, c50: 3, c5: 1 }), 341.55);
  till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 200 });
  assert.strictEqual(T.openingFloat(till), 200);
});

test('till count: expected = float + Z cash − paid out − drops ± corrections; short needs a reason; Z photo required', () => {
  const c = { shopCode: 'S2', tillUid: till, shiftDate: '2026-10-08', shift: 'Morning', cashierUid: mere.uid, openingFloat: 200,
    denominations: { n100: 10, n50: 4, n20: 5, n10: 3, n5: 2, c2: 4, c1: 3, c50: 2 }, // 1000+200+100+30+10+8+3+1 = 1352
    zNumber: 'Z-0412', zTotal: 2100, zCash: 1190, tenders: [{ method: 'EFTPOS / card', amount: 800 }, { method: 'M-PAiSA', amount: 110 }],
    payouts: [{ what: 'Supplier paid from till', amount: 25, note: 'bread delivery' }], drops: 0, adjustments: [], floatKept: 200 };
  const w = T.workOut(c);
  assert.strictEqual(w.counted, 1352);
  assert.strictEqual(w.expected, 1365);
  assert.strictEqual(w.overShort, -13);
  assert.strictEqual(w.zCheck, 0, 'Z total = cash + other tenders');
  throws(() => T.saveTillCount(mgr, c, { photos: ['file:///z.jpg'] }), /short by \$13.00. Write the reason/);
  throws(() => T.saveTillCount(mgr, { ...c, reason: 'Change given wrongly' }), /photo of the Z report/);
  // A manual correction with a reason: a refund done by hand.
  count = T.saveTillCount(mgr, { ...c, reason: 'Change given wrongly', adjustments: [{ amount: -5, reason: 'Refund given by hand, not in POS' }] }, { photos: ['file:///z.jpg'] });
  assert.strictEqual(count.expected_cash, 1360);
  assert.strictEqual(count.over_short, -8);
  assert.strictEqual(count.status, 'counted');
  throws(() => T.saveTillCount(mgr, { ...c, reason: 'x' }, { photos: ['file:///z.jpg'] }), /already counted/);
});

test('approve: not your own count (owner may); then cash on hand includes the takings', () => {
  throws(() => T.approveTillCount(mgr, count.uid), /Someone else/);
  throws(() => T.approveTillCount(owner, count.uid, { shortAction: 'x' }), /Choose/);
  throws(() => T.approveTillCount(mgr, count.uid, { shortAction: 'write_off', writeOffReason: 'x' }), /Someone else|Only the owner/);
  T.approveTillCount(owner, count.uid, { shortAction: 'write_off', writeOffReason: 'First day on the new till' });
  assert.strictEqual(T.getTillCount(count.uid).short_action, 'write_off');
  const c = T.cashOnHand('S2');
  assert.strictEqual(c.onHand, 1152, '1352 counted − 200 float kept');
  assert.strictEqual(c.floats, 200);
  assert.strictEqual(c.total, 1352);
  throws(() => T.saveTillCount(mgr, { uid: count.uid, shopCode: 'S2', tillUid: till, shift: 'Morning', zCash: 1 }), /approved/);
});

test('short till: deduction record made for the cashier and taken from the next pay', () => {
  const t2 = T.saveTill(owner, { shopCode: 'S3', name: 'Till 1', floatAmount: 100 });
  const c = T.saveTillCount(owner, { shopCode: 'S3', tillUid: t2, shiftDate: '2026-10-08', shift: 'Night', cashierUid: mere.uid, openingFloat: 100, cashCounted: 470, zCash: 400, zTotal: 400,
    zVat: 44.44, floatKept: 100, reason: 'Do not know', notes: 'Busy night, two new staff' }, { photos: ['file:///z2.jpg'] });
  assert.strictEqual(c.over_short, -30);
  assert.strictEqual(c.notes, 'Busy night, two new staff');
  T.approveTillCount(mgr, c.uid);
  const after = T.getTillCount(c.uid);
  assert.strictEqual(after.short_action, 'deduct');
  const d = P.listDebts({ userUid: mere.uid }).find((x) => x.uid === after.short_charge_uid);
  assert.strictEqual(d.amount, 30);
  assert.strictEqual(d.kind, 'till_short');
  T.reopenTillCount(owner, c.uid, 'Found $30 in the drawer');
  assert.ok(!P.listDebts({ userUid: mere.uid }).some((x) => x.uid === after.short_charge_uid), 'deduction cancelled when re-opened');
  T.voidTillCount(owner, c.uid, 'Recount');
  const sales = T.dailySales({ from: '2026-10-08', to: '2026-10-08', shopCode: 'S2' });
  assert.strictEqual(sales[0].total, 2100);
});

test('cash paid to a supplier from the shop comes off cash on hand', () => {
  const sup = AP.saveSupplier(owner, { name: 'Coral Dairy' });
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'CD1', total: 52 }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cash', shopCode: 'S2', allocations: [{ invoiceUid: inv.uid, amount: 52 }] });
  assert.strictEqual(T.cashOnHand('S2').onHand, 1100);
});

test('petty cash, shop to shop transfer, corrections need reasons', () => {
  throws(() => T.recordCash(owner, { shopCode: 'S2', type: 'petty_out', amount: 10 }), /what the petty cash/);
  throws(() => T.recordCash(owner, { shopCode: 'S2', type: 'petty_out', amount: 5000, category: 'Office', note: 'x' }), /not that much/);
  T.recordCash(owner, { shopCode: 'S2', type: 'petty_out', amount: 12.5, category: 'Cleaning', note: 'Mop and bleach' });
  T.recordCash(owner, { shopCode: 'S2', type: 'transfer', toShop: 'S1', amount: 100, note: 'change for S1' });
  throws(() => T.recordCash(owner, { shopCode: 'S1', type: 'adjust_in', amount: 3 }), /reason/);
  assert.strictEqual(T.cashOnHand('S2').onHand, 987.5);
  assert.strictEqual(T.cashOnHand('S1').onHand, 100);
});

let dep;
test('deposit: slip number, cash and cheques, who banked it; goes to the bank account and out of the shop', () => {
  throws(() => T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, cashAmount: 900 }), /slip number/);
  throws(() => T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: '7781', cashAmount: 5000 }), /Only \$987.50 cash/);
  dep = T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: '7781', date: '2026-10-08', denominations: { n100: 9 }, cheques: [{ drawer: 'Lautoka Hotel', bank: 'ANZ', number: '00123', amount: 250 }],
    takingsFrom: '2026-10-08', takingsTo: '2026-10-08', witness: 'Mere' }, { photos: ['file:///slip.jpg'] });
  assert.strictEqual(dep.total, 1150);
  assert.strictEqual(dep.deposited_by_name, 'Anita Manager');
  assert.strictEqual(T.cashOnHand('S2').onHand, 87.5);
  assert.strictEqual(AP.bookBalance(acct.uid, '2026-10-08').balance, 11150);
  throws(() => T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: '7781', cashAmount: 1, notes: 'x' }), /already recorded/);
});

// ================================================================ bank reconciliation
test('statement text from internet banking is read (signed, or debit/credit columns)', () => {
  const p = B.parseStatementText('Date,Description,Amount\n08/10/2026,DEPOSIT 7781,1150.00\n09/10/2026,CHQ 000500,-300.00\n09-Oct-2026,SERVICE FEE,(4.50)\nrubbish line');
  assert.strictEqual(p.lines.length, 3);
  assert.deepStrictEqual(p.lines.map((l) => l.amount), [1150, -300, -4.5]);
  assert.strictEqual(p.lines[1].reference, '000500');
  assert.strictEqual(p.skipped.length, 2);
  const q = B.parseStatementText('10/10/2026\tINTEREST\t\t1.20\t11000.00\n10/10/2026\tTRANSFER OUT\t50.00\t\t10950.00');
  assert.deepStrictEqual(q.lines.map((l) => l.amount), [1.2, -50]);
});

test('reconcile: lines match cheques and deposits by themselves; fee and interest added from the statement; balanced', () => {
  const sup = AP.listSuppliers()[0];
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'CD2', total: 300 }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 500, payDate: '2026-10-08', allocations: [{ invoiceUid: inv.uid, amount: 300 }] });
  const inv2 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'CD3', total: 80 }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 501, payDate: '2026-10-09', allocations: [{ invoiceUid: inv2.uid, amount: 80 }] });
  const lines = B.parseStatementText('08/10/2026,DEPOSIT 7781,1150.00\n09/10/2026,CHQ 500,-300.00\n09/10/2026,SERVICE FEE,-4.50\n10/10/2026,INTEREST,1.20').lines;
  throws(() => B.addStatement(owner, { accountUid: acct.uid, fromDate: '2026-10-01', toDate: '2026-10-10', opening: 10000, closing: 99, lines }), /A line is missing or wrong/);
  const st = B.addStatement(owner, { accountUid: acct.uid, fromDate: '2026-10-01', toDate: '2026-10-10', opening: 10000, closing: 10846.7, lines });
  let r = B.reconcileSummary(st);
  assert.strictEqual(r.matched, 2, 'deposit and cheque 500 matched automatically');
  assert.strictEqual(r.unmatched.length, 2);
  throws(() => B.finishStatement(owner, st), /not matched yet/);
  const fee = r.unmatched.find((l) => l.amount === -4.5);
  throws(() => B.createFromLine(owner, fee.uid, 'deposit'), /Money out/);
  B.createFromLine(owner, fee.uid, 'fee', 'Monthly fee');
  B.createFromLine(owner, r.unmatched.find((l) => l.amount === 1.2).uid, 'interest');
  r = B.finishStatement(owner, st);
  assert.ok(r.check.balanced, `difference ${r.check.difference}`);
  assert.strictEqual(r.check.chequesOut, 80, 'cheque 501 still out');
  assert.strictEqual(AP.listCheques({ accountUid: acct.uid, status: 'presented' })[0].presented_date, '2026-10-09');
});

// ================================================================ regular bills & loans
test('regular bill makes its invoice before it is due, once, even if run twice', () => {
  assert.strictEqual(nextDate('2026-01-31', 'monthly'), '2026-02-28');
  const landlord = AP.saveSupplier(owner, { name: 'Pillay Properties', onAccount: true });
  saveRecurring(owner, { kind: 'bill', name: 'Shop 2 rent', supplierUid: landlord.uid, amount: 1500, frequency: 'monthly', nextDate: '2026-10-12', leadDays: 7, shopCode: 'S2' });
  assert.strictEqual(runRecurring(owner, '2026-10-04'), 0);
  assert.strictEqual(runRecurring(owner, '2026-10-08'), 1);
  assert.strictEqual(runRecurring(owner, '2026-10-08'), 0);
  const inv = AP.listInvoices({ filter: 'unpaid', supplierUid: landlord.uid })[0];
  assert.strictEqual(inv.due_date, '2026-10-12');
  assert.strictEqual(inv.due, 'not_due');
  assert.strictEqual(inv.status, 'approved');
});

test('loan: repayments are invoices paid like any other; balance = start + interest − repayments', () => {
  const bsp = AP.saveSupplier(owner, { name: 'BSP Loans', onAccount: true, payMethod: 'transfer' });
  const loan = saveRecurring(owner, { kind: 'loan', name: 'Motor vehicle ON 485', supplierUid: bsp.uid, loanNo: 'ML-485', security: 'Vehicle ON 485', amount: 650, frequency: 'monthly',
    nextDate: '2026-10-10', leadDays: 5, openingBalance: 18000, openingDate: '2026-10-01' });
  runRecurring(owner, '2026-10-08');
  const inv = AP.listInvoices({ filter: 'unpaid', supplierUid: bsp.uid })[0];
  assert.strictEqual(inv.invoice_no, 'ML-485-20261010');
  AP.makePayment(owner, { supplierUid: bsp.uid, method: 'transfer', accountUid: acct.uid, reference: 'IB-5541', payDate: '2026-10-10', allocations: [{ invoiceUid: inv.uid, amount: 650 }] });
  addLoanEntry(owner, { recurringUid: loan.uid, type: 'interest', amount: 112.4, date: '2026-10-31' });
  const st = loanStatement(loan.uid);
  assert.strictEqual(st.balance, 17462.4);
  assert.strictEqual(st.paid, 650);
  assert.ok(st.rows.some((r) => r.ref === 'ML-485-20261010'));
});

// ================================================================ payroll
clock.override = new Date('2026-10-10T12:00:00');
const rules = P.payRules();
test('PAYE: yearly brackets shared per week; non-resident flat', () => {
  assert.strictEqual(P.annualTax(30000), 0);
  assert.strictEqual(P.annualTax(40000), 1800);
  assert.strictEqual(P.annualTax(60000), 5600);
  assert.strictEqual(P.weeklyPaye(500, { tax_status: 'resident', tin: '1' }), 0, '26,000 a year is under the tax-free threshold');
  assert.strictEqual(P.weeklyPaye(1000, { tax_status: 'resident', tin: '1' }), r(P.annualTax(52000) / 52));
  assert.strictEqual(P.weeklyPaye(100, { tax_status: 'non_resident' }), 20);
});
function r(n) { return Math.round(n * 100) / 100; }

let run;
test('pay run from the timesheet: normal up to 48h, overtime after, Sunday and public holiday rates, paid leave, FNPF 8% / 10%', () => {
  P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 6, fnpfNo: 'F123', tin: '987654321', payMethod: 'cash', allowances: [{ name: 'Meal', amount: 10, taxable: false, fnpf: false }] });
  // Week Sat 3 Oct – Fri 9 Oct 2026. Sat 9h, Sun 4h, Mon–Thu 10h each, Fri off on paid annual leave. (Fri 9 Oct; Fiji Day is Sat 10 Oct)
  const day = (d, hIn, hOut) => {
    addManualPunch(owner, { userUid: mere.uid, type: 'IN', at: `${d} ${hIn}:00`, reason: 'test' });
    addManualPunch(owner, { userUid: mere.uid, type: 'OUT', at: `${d} ${hOut}:00`, reason: 'test' });
  };
  P.savePayRules(owner, { ...rules, publicHolidays: rules.publicHolidays.concat([{ date: '2026-10-06', name: 'Test holiday' }]) });
  day('2026-10-03', '07', '16'); day('2026-10-04', '08', '12'); day('2026-10-05', '07', '17'); day('2026-10-06', '07', '17'); day('2026-10-07', '07', '17'); day('2026-10-08', '07', '17');
  const lr = requestLeave(owner, { userUid: mere.uid, type: 'ANNUAL', from: '2026-10-09', to: '2026-10-09', reason: 'family' });
  decideLeave(owner, lr, true);
  run = P.createRun(owner, '2026-10-05');
  assert.strictEqual(run.week_start, '2026-10-03');
  assert.strictEqual(run.pay_date, '2026-10-10');
  const l = run.lines.find((x) => x.user_uid === mere.uid);
  // Sat 9 + Mon 10 + Wed 10 + Thu 10 = 39 normal (auto break may apply: rules.autoBreak)
  assert.ok(l.hours.normal > 0);
  assert.strictEqual(l.hours.sunday, 4);
  assert.strictEqual(l.hours.holiday, 10);
  assert.strictEqual(l.hours.leave, 8);
  assert.ok(l.warnings.includes('Timesheet week not ticked as checked'));
  const e = l.earnings;
  assert.strictEqual(e.sunday, 36);
  assert.strictEqual(e.holiday, 120);
  assert.strictEqual(e.leave, 48);
  assert.strictEqual(l.gross, r(e.normal + e.ot + e.sunday + e.holiday + e.leave + 10));
  assert.strictEqual(l.fnpf_employee, r((l.gross - 10) * 0.08));
  assert.strictEqual(l.fnpf_employer, r((l.gross - 10) * 0.10));
  assert.strictEqual(l.paye, 0);
  assert.strictEqual(l.net, r(l.gross - l.fnpf_employee));
});

test('overtime after 48 normal hours in the week', () => {
  clock.override = new Date('2026-10-17T12:00:00');
  const sam = saveUser({ name: 'Sami Worker', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
  P.saveProfile(owner, { userUid: sam.uid, payType: 'hourly', rate: 10, tin: '1', fnpfNo: '1' });
  ['2026-10-12', '2026-10-13', '2026-10-14', '2026-10-15', '2026-10-16'].forEach((d) => {
    addManualPunch(owner, { userUid: sam.uid, type: 'IN', at: `${d} 06:00`, reason: 't' });
    addManualPunch(owner, { userUid: sam.uid, type: 'OUT', at: `${d} 18:00`, reason: 't' });
  });
  const c = P.computeLine(sam, P.getProfile(sam.uid), '2026-10-10', { ...P.payRules(), publicHolidays: [] });
  const worked = c.hours.normal + c.hours.ot;
  assert.ok(worked > 48);
  assert.strictEqual(c.hours.normal, 48);
  assert.strictEqual(c.earnings.ot, r(c.hours.ot * 10 * 1.5));
});

test('advance: given from shop cash, repaid weekly from pay until cleared', () => {
  const id = P.giveDebt(owner, { userUid: mere.uid, kind: 'advance', amount: 60, repayPerPay: 40, reason: 'Bus fare', shopCode: 'S2', paidFrom: 'cash', date: '2026-10-05' });
  assert.strictEqual(T.cashOnHand('S2').onHand, 27.5);
  P.recalcRun(owner, run.uid);
  const l = P.getRun(run.uid).lines.find((x) => x.user_uid === mere.uid);
  const d = l.deductions.find((x) => x.debtUid === id);
  assert.strictEqual(d.amount, 40);
  assert.strictEqual(P.debtBalance(id).balance, 60, 'only counted once the run is final');
});

test('admin changes a line with a reason; it survives working the run out again', () => {
  const l = P.getRun(run.uid).lines.find((x) => x.user_uid === mere.uid);
  throws(() => P.editLine(owner, l.uid, { rate: 6.5 }), /reason/);
  const e = P.editLine(owner, l.uid, { rate: 6.5, adjustments: [{ label: 'Bonus', amount: 20 }], deductions: [{ label: 'Uniform', amount: 15 }], reason: 'Pay rise from this week; uniform' });
  assert.strictEqual(e.rate, 6.5);
  assert.ok(e.deductions.some((d) => d.label === 'Uniform'));
  P.recalcRun(owner, run.uid);
  const again = P.getRun(run.uid).lines.find((x) => x.user_uid === mere.uid);
  assert.strictEqual(again.rate, 6.5);
  assert.strictEqual(again.edit_reason, 'Pay rise from this week; uniform');
  assert.ok(again.adjustments.some((a) => a.label === 'Bonus'));
});

test('final: locked; advance balance goes down; YTD; cash notes needed; void and redo by owner only', () => {
  checkWeek(owner, mere.uid, '2026-10-03', 'ok');
  const f = P.finaliseRun(owner, run.uid);
  assert.strictEqual(f.status, 'final');
  const line = f.lines.find((x) => x.user_uid === mere.uid);
  assert.ok(!line.warnings.includes('Timesheet week not ticked as checked'));
  throws(() => P.editLine(owner, line.uid, { rate: 7, reason: 'x' }), /final/);
  throws(() => P.createRun(owner, '2026-10-05'), /already a pay run/);
  assert.strictEqual(P.listDebts({ userUid: mere.uid })[0].balance, 20);
  assert.strictEqual(P.yearToDate(mere.uid, '2026').net, line.net);
  assert.strictEqual(T.cashOnHand('S2').wagesCash, line.net, 'cash wages come off Shop 2 cash on hand (Mere works at Shop 2)');
  const notes = P.cashBreakdown([line.net, 12.35]);
  const sum = notes.reduce((s, n) => s + n.value * n.count, 0);
  assert.ok(Math.abs(sum - (Math.round(line.net * 20) / 20 + 12.35)) < 0.001);
  throws(() => P.voidRun(mgr, run.uid, 'x'), /owner or admin/);
  P.voidRun(owner, run.uid, 'Wrong hours');
  assert.strictEqual(P.listDebts({ userUid: mere.uid })[0].balance, 60, 'repayment undone with the run');
  const again = P.createRun(owner, '2026-10-05');
  assert.strictEqual(again.status, 'draft');
});

test('payroll rules are admin-editable and checked', () => {
  throws(() => P.savePayRules(owner, { ...P.payRules(), taxBrackets: [{ upTo: 30000, rate: 0 }] }), /no upper limit/);
  throws(() => P.savePayRules(owner, { ...P.payRules(), publicHolidays: [{ date: '10/10/2026', name: 'x' }] }), /YYYY-MM-DD/);
  P.savePayRules(owner, { ...P.payRules(), fnpfEmployerPct: 10, confirmed: true });
  assert.strictEqual(P.payRules().confirmed, true);
});

test('review fixes: due dates keep their day; bank text with headings, quotes and words; void run keeps its lines', () => {
  assert.strictEqual(nextDate(nextDate('2026-01-31', 'monthly', 31), 'monthly', 31), '2026-03-31');
  const h = B.parseStatementText('Date,Description,Debit,Credit,Balance\n08/10/2026,Cheque 100205,"1,300.00",,500.00\n09/10/2026,Deposit,,"2,000.50",2500.50');
  assert.deepStrictEqual(h.lines.map((l) => l.amount), [-1300, 2000.5]);
  const w = B.parseStatementText('08/10/2026  Cheque 100205  300.00\n08/10/2026  Interest  1.20');
  assert.deepStrictEqual(w.lines.map((l) => l.amount), [-300, 1.2]);
  const voided = P.listRuns({ includeVoid: true }).find((x) => x.status === 'void');
  assert.ok(voided && P.getRun(voided.uid).lines.length, 'voided run still has its lines');
});

test('everything new waits to sync', () => {
  const t = new Set(pendingRecords(5000).map((x) => x.t));
  ['tills', 'till_counts', 'cash_moves', 'deposits', 'bank_statements', 'bank_lines', 'ap_recurring', 'loan_entries', 'pay_profiles', 'staff_debts', 'pay_runs', 'pay_lines'].forEach((k) => assert.ok(t.has(k), k));
  assert.ok(db().get("SELECT 1 AS x FROM outbox WHERE kind = 'photo'"));
});

done();
