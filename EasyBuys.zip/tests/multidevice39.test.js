// 3.9: several devices at once through the real cloud script (fake Google) and the app's own sync code: the main
// tablet at Shop 1, the tablet at Shop 2 and the owner's phone, each with its own database, working offline and
// syncing later – including the awkward cases (the same invoice paid on two tablets, the same cheque number, the
// same till counted twice, the same order received twice, the same pay week run twice, a week offline).
import { createRequire } from 'module';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { setDb, db, withSystem } from '../src/db/connection.js';
import { clock, setSetting } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { pendingRecords, markRecordsSent, applyPulledRecords, pullCursor, setPullCursor } from '../src/services/records.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as T from '../src/modules/till/service.js';
import * as P from '../src/modules/payroll/service.js';
import { syncConflicts } from '../src/services/conflicts.js';
import { alerts as syncAlerts } from '../src/modules/sync/alerts.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { weekTimesheet } from '../src/modules/timesheets/service.js';
import { test, done, assert, throws } from './harness.js';

const req = createRequire(`${process.cwd()}/tests/x.cjs`);
const { load } = req('./fakeGoogle.cjs');
const { ctx, post } = load();
ctx.setup();
clock.override = new Date('2026-10-12T09:00:00');

// Three devices, each with its own database (switching db() between them).
const dev = {};
for (const [name, kind] of [['A', 'tablet'], ['B', 'tablet'], ['C', 'phone']]) {
  const a = openNodeDb();
  setDb(a);
  initDatabase(a);
  setSetting('device_id', `dev-${name}`);
  dev[name] = { a, device: { id: `dev-${name}`, name: `Device ${name}`, kind } };
}
const on = (name) => { setDb(dev[name].a); };
const call = (name, body) => post({ key: 'tablet-key-123', device: dev[name].device, ...body });
function sync(name) {
  on(name);
  let sent = 0; let got = 0;
  for (let i = 0; i < 50; i++) {
    const batch = pendingRecords(300);
    if (!batch.length) break;
    const r = call(name, { kind: 'push', records: batch });
    if (r.error) throw new Error(r.error);
    withSystem(() => markRecordsSent(batch));
    sent += batch.length;
  }
  for (let i = 0; i < 50; i++) {
    const r = call(name, { kind: 'pull', since: pullCursor() });
    if (r.error) throw new Error(r.error);
    if ((r.records || []).length) got += withSystem(() => applyPulledRecords(r.records));
    if (typeof r.next === 'number') withSystem(() => setPullCursor(r.next));
    if (!r.more) break;
  }
  return { sent, got };
}
const syncAll = () => { sync('A'); sync('B'); sync('C'); sync('A'); sync('B'); sync('C'); };

// Set up on the main tablet, then everyone syncs.
on('A');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgrA = saveUser({ name: 'Anita S1', pin: '8881', role: 'manager', shopCode: 'S1' }, owner);
const mgrB = saveUser({ name: 'Ravi S2', pin: '8882', role: 'manager', shopCode: 'S2' }, owner);
const mere = saveUser({ name: 'Mere', pin: '4321', role: 'staff', shopCode: 'S2' }, owner);
const bank = AP.saveAccount(owner, { name: 'BSP', openingBalance: 10000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: bank.uid, firstNo: 600, lastNo: 649 });
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const rice = I.saveItem(owner, { code: 'R1', name: 'Rice', cost: 30, price: 42 });
syncAll();
const get = (name, sql, p = []) => { on(name); return db().get(sql, p); };

test('everyone has the same set-up after syncing (people, bank, cheque book, supplier, product)', () => {
  for (const n of ['B', 'C']) {
    assert.ok(get(n, 'SELECT 1 AS x FROM users WHERE uid = ?', [mgrB.uid]), `${n} staff`);
    assert.ok(get(n, 'SELECT 1 AS x FROM ap_suppliers WHERE uid = ?', [sup.uid]), `${n} supplier`);
    assert.ok(get(n, 'SELECT 1 AS x FROM inv_items WHERE uid = ?', [rice.uid]), `${n} product`);
    assert.ok(get(n, 'SELECT 1 AS x FROM cheque_books WHERE account_uid = ?', [bank.uid]), `${n} cheque book`);
  }
});
let inv;
test('an invoice entered at Shop 2 shows on the main tablet and the phone; paid on the main tablet, paid everywhere', () => {
  on('B');
  inv = AP.saveInvoice(mgrB, { supplierUid: sup.uid, invoiceNo: 'P-77', invoiceDate: '2026-10-11', total: 450, shopCode: 'S2' }, { photos: ['file:///p.jpg'] });
  syncAll();
  on('A'); AP.checkInvoice(owner, inv.uid);
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 600, payDate: '2026-10-12', allocations: [{ invoiceUid: inv.uid, amount: 450 }] });
  syncAll();
  for (const n of ['A', 'B', 'C']) { on(n); assert.strictEqual(AP.getInvoice(inv.uid).owing, 0, `${n} owing`); }
});
test('the same supplier changed on two devices: the newer change wins everywhere', () => {
  on('A'); clock.override = new Date('2026-10-12T10:00:00'); AP.saveSupplier(owner, { uid: sup.uid, name: 'Punjas', tin: '501234567', phone: '111' });
  on('B'); clock.override = new Date('2026-10-12T10:05:00'); AP.saveSupplier(owner, { uid: sup.uid, name: 'Punjas', tin: '501234567', phone: '222' });
  syncAll();
  for (const n of ['A', 'B', 'C']) assert.strictEqual(get(n, 'SELECT phone FROM ap_suppliers WHERE uid = ?', [sup.uid]).phone, '222', n);
});
test('OFFLINE: the same invoice paid on both tablets – after syncing it is flagged as paid twice, on every device', () => {
  on('A'); clock.override = new Date('2026-10-13T09:00:00');
  const i2 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P-78', invoiceDate: '2026-10-12', total: 300, shopCode: 'S1' }, { canCheck: true });
  syncAll();
  on('A'); AP.makePayment(owner, { supplierUid: sup.uid, method: 'cash', shopCode: 'S1', receivedBy: 'rep', payDate: '2026-10-13', allocations: [{ invoiceUid: i2.uid, amount: 300 }] });
  on('B'); AP.makePayment(owner, { supplierUid: sup.uid, method: 'transfer', accountUid: bank.uid, reference: 'TT1', payDate: '2026-10-13', allocations: [{ invoiceUid: i2.uid, amount: 300 }] });
  syncAll();
  for (const n of ['A', 'B']) { on(n); const c = syncConflicts(); assert.ok(c.some((x) => x.kind === 'paid_twice' && /P-78/.test(x.text)), `${n}: ${JSON.stringify(c)}`); }
});
test('OFFLINE: the same cheque number written on both tablets – flagged', () => {
  on('A'); const i3 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P-79', invoiceDate: '2026-10-12', total: 100, shopCode: 'S1' }, { canCheck: true });
  const i4 = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P-80', invoiceDate: '2026-10-12', total: 120, shopCode: 'S1' }, { canCheck: true });
  syncAll();
  on('A'); AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 601, payDate: '2026-10-13', allocations: [{ invoiceUid: i3.uid, amount: 100 }] });
  on('B'); AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: bank.uid, chequeNo: 601, payDate: '2026-10-13', allocations: [{ invoiceUid: i4.uid, amount: 120 }] });
  syncAll();
  on('C'); const c = syncConflicts();
  assert.ok(c.some((x) => x.kind === 'cheque_twice' && /601/.test(x.text)), JSON.stringify(c));
});
test('OFFLINE: the same order received on both tablets – stock shows both, the order and a warning say so', () => {
  on('A');
  const po = I.savePO(mgrA, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: rice.uid, qty: 10, unitCost: 30 }] });
  I.submitPO(owner, po.uid, { canApprove: true });
  syncAll();
  for (const n of ['A', 'B']) { on(n); const o = I.getPO(po.uid); I.receiveDelivery(owner, { poUid: po.uid, date: '2026-10-13', lines: [{ lineUid: o.lines[0].uid, qty: 10 }] }); }
  syncAll();
  on('C');
  const stock = db().get("SELECT SUM(qty) AS q FROM inv_moves WHERE item_uid = ? AND status = 'active'", [rice.uid]).q;
  assert.strictEqual(stock, 20, 'both deliveries are in the stock');
  const c = syncConflicts();
  assert.ok(c.some((x) => x.kind === 'received_twice'), JSON.stringify(c));
  assert.strictEqual(I.getPO(po.uid).lines[0].qty_received, 20, 'the order shows what was really received');
});
test('OFFLINE: the same till and shift counted on two devices – flagged (sales would count twice)', () => {
  on('A');
  const till = T.saveTill(owner, { shopCode: 'S2', name: 'Till 1', floatAmount: 100 });
  syncAll();
  for (const n of ['B', 'C']) {
    on(n);
    T.saveTillCount(mgrB, { shopCode: 'S2', tillUid: till, shiftDate: '2026-10-13', shift: 'Full day', cashierUid: mere.uid, openingFloat: 100, denominations: { n100: 6 }, zCash: 500, zTotal: 500, zVat: 55.56, tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: ['file:///z.jpg'] });
  }
  syncAll();
  on('A'); const c = syncConflicts();
  assert.ok(c.some((x) => x.kind === 'till_twice'), JSON.stringify(c));
});
test('OFFLINE: the same pay week run on two devices – flagged before anyone is paid twice', () => {
  on('A'); P.saveProfile(owner, { userUid: mere.uid, payType: 'salary', weeklySalary: 300, fnpfNo: 'F1', tin: '1', payMethod: 'cash' }); P.savePayRules(owner, { ...P.payRules(), confirmed: true, needCheckedTimesheets: false });
  syncAll();
  on('A'); P.createRun(owner, '2026-10-09');
  on('C'); P.createRun(owner, '2026-10-09');
  syncAll();
  on('B'); const c = syncConflicts();
  assert.ok(c.some((x) => x.kind === 'payrun_twice'), JSON.stringify(c));
  // They show as urgent warnings on Home for the owner and managers, not for staff.
  const ow = syncAlerts(owner);
  assert.ok(ow.filter((a) => a.level === 'urgent').length >= 5, JSON.stringify(ow.map((a) => a.text)));
  assert.strictEqual(syncAlerts(mere).filter((a) => /conflict/.test(a.id)).length, 0);
});
test('clock in on one device and out on another: one shift on the timesheet', () => {
  clock.override = new Date('2026-10-14T18:00:00');
  on('B'); addManualPunch(owner, { userUid: mere.uid, type: 'IN', at: '2026-10-14 08:00:00', reason: 't' });
  on('C'); addManualPunch(owner, { userUid: mere.uid, type: 'OUT', at: '2026-10-14 16:00:00', reason: 't' });
  syncAll();
  on('A'); const w = weekTimesheet('2026-10-14').rows.find((r) => r.user && r.user.uid === mere.uid);
  assert.ok(w, 'Mere is on the timesheet');
  assert.strictEqual(w.shifts.length, 1, 'one shift');
  assert.strictEqual(w.totalMinutes, 8 * 60);
});
test('a tablet offline for a week: everything it did arrives, nothing lost, in order', () => {
  on('B');
  const before = db().get('SELECT COUNT(*) AS n FROM ap_invoices').n;
  for (let d = 15; d <= 21; d++) {
    clock.override = new Date(`2026-10-${d}T11:00:00`);
    for (let k = 0; k < 15; k++) AP.saveInvoice(mgrB, { supplierUid: sup.uid, invoiceNo: `W-${d}-${k}`, invoiceDate: `2026-10-${d}`, total: 10 + k, shopCode: 'S2' }, { photos: ['file:///w.jpg'] });
  }
  const r = sync('B');
  assert.ok(r.sent >= 105, `sent ${r.sent}`);
  sync('A');
  on('A'); assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_invoices WHERE invoice_no LIKE 'W-%'").n, 105);
  on('B'); assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_invoices').n, before + 105);
});
test('one broken record from the cloud never stops the rest from arriving', () => {
  on('C');
  const good = { t: 'ap_suppliers', k: 'SUP-GOOD', u: '2026-10-22 09:00:00', row: { uid: 'SUP-GOOD', name: 'Good one', updated_at: '2026-10-22 09:00:00' } };
  const bad = { t: 'ap_invoices', k: 'INV-BAD', u: '2026-10-22 09:00:00', row: { uid: 'INV-BAD', updated_at: '2026-10-22 09:00:00' } }; // missing required columns
  const n = withSystem(() => applyPulledRecords([bad, good]));
  assert.ok(db().get("SELECT 1 AS x FROM ap_suppliers WHERE uid = 'SUP-GOOD'"), 'the good record arrived');
  assert.ok(n >= 1);
});
test('internet drops half way: the push is sent again later – nothing lost, nothing doubled', () => {
  on('B');
  clock.override = new Date('2026-10-23T09:00:00');
  for (let k = 0; k < 5; k++) AP.saveInvoice(mgrB, { supplierUid: sup.uid, invoiceNo: `NET-${k}`, invoiceDate: '2026-10-23', total: 50, shopCode: 'S2' }, { photos: ['file:///n.jpg'] });
  const batch = pendingRecords(300);
  call('B', { kind: 'push', records: batch }); // reached the cloud, but the answer never came back: not marked sent
  sync('B'); // so it is sent again
  sync('A');
  on('A'); assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_invoices WHERE invoice_no LIKE 'NET-%'").n, 5);
});
test('the Watchdog lists what two devices did (urgent, for the owner)', () => {
  on('A');
  const W = require('../src/services/watchdog.js');
  const r = W.runWatchdog(owner);
  const list = r.findings || r.list || r.items || r;
  const flat = JSON.stringify(list);
  assert.ok(/device_conflicts/.test(flat) && /paid/.test(flat), flat.slice(0, 300));
});
test('every device ends with the same money figures', () => {
  syncAll();
  const sum = (n) => { on(n); return JSON.stringify(db().get("SELECT COUNT(*) AS i, ROUND(SUM(total),2) AS t FROM ap_invoices WHERE status <> 'void'")) + JSON.stringify(db().get("SELECT COUNT(*) AS p, ROUND(SUM(amount),2) AS a FROM ap_payments WHERE status = 'active'")); };
  assert.strictEqual(sum('A'), sum('B'));
  assert.strictEqual(sum('B'), sum('C'));
});
done();
