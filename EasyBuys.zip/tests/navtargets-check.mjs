// 3.9.5 every link in the app opens a screen that exists: nav.push / nav.replace, menu items (screen: '…'),
// warnings (nav: { screen }), To verify (go: ['…'], screen: '…' of a paper) and search results.
import fs from 'fs';
import path from 'path';
const root = process.cwd();
const names = new Set(['Home', 'ModuleMenu', 'ReportView', 'Login']);
for (const d of fs.readdirSync(path.join(root, 'src/modules'))) {
  const f = path.join(root, 'src/modules', d, 'index.js');
  if (!fs.existsSync(f)) continue;
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.slice(src.indexOf('screens:')).matchAll(/(\w+): \{ component/g)) names.add(m[1]);
  for (const m of src.matchAll(/screens\.(\w+) = \{ component/g)) names.add(m[1]);
}
for (const m of fs.readFileSync(path.join(root, 'src/modules/bakery/screens/index.js'), 'utf8').matchAll(/^\s+(\w+): \[/gm)) names.add(m[1]);
// screens the app shell itself provides
const app = fs.readFileSync(path.join(root, 'App.js'), 'utf8');
for (const m of app.matchAll(/name === '(\w+)'/g)) names.add(m[1]);
const bad = [];
const walk = (dir) => {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { walk(p); continue; }
    if (!p.endsWith('.js')) continue;
    const src = fs.readFileSync(p, 'utf8');
    const pats = [/nav\.(?:push|replace)\('(\w+)'/g, /\bscreen: '(\w+)'/g, /\bgo: \['(\w+)'/g, /nav: \{ screen: '(\w+)'/g];
    for (const re of pats) for (const m of src.matchAll(re)) if (!names.has(m[1])) bad.push(`${path.relative(root, p)}: ${m[1]}`);
  }
};
walk(path.join(root, 'src'));
const uniq = [...new Set(bad)];
if (uniq.length) console.log('Links to screens that do not exist:\n' + uniq.join('\n'));
console.log(uniq.length ? `nav targets: ${uniq.length} broken` : `nav targets: all point to one of ${names.size} screens`);
process.exit(uniq.length ? 1 : 0);
