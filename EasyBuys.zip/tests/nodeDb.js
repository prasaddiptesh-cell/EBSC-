// Test adapter: the same database interface as the tablet, using Node's built-in SQLite.
import { DatabaseSync } from 'node:sqlite';
import { cleanParams } from '../src/db/connection.js';

export function openNodeDb(file = ':memory:') {
  const d = new DatabaseSync(file);
  d.exec('PRAGMA foreign_keys = ON;');
  const norm = (p) => cleanParams(p).map((v) => (typeof v === 'number' && Number.isInteger(v) ? v : v));
  return {
    exec: (sql) => d.exec(sql),
    run: (sql, params) => {
      const r = d.prepare(sql).run(...norm(params));
      return { changes: Number(r.changes), lastInsertRowId: Number(r.lastInsertRowid) };
    },
    all: (sql, params) => d.prepare(sql).all(...norm(params)).map((r) => ({ ...r })),
    get: (sql, params) => { const r = d.prepare(sql).get(...norm(params)); return r ? { ...r } : null; },
    transaction: (fn) => {
      d.exec('BEGIN');
      try { const r = fn(); d.exec('COMMIT'); return r; } catch (e) { d.exec('ROLLBACK'); throw e; }
    },
    close: () => { try { d.close(); } catch (e) { /* closed */ } },
    raw: d,
  };
}
