// Stand-ins for the phone-only libraries when service code runs in Node tests.
export const Platform = { OS: 'android' };
export const documentDirectory = 'file:///docs/';
export const cacheDirectory = 'file:///cache/';
export const EncodingType = { Base64: 'base64', UTF8: 'utf8' };
export async function printToFileAsync() { return { uri: 'file:///cache/x.pdf', base64: 'UERG' }; }
export async function readAsStringAsync() { return 'QUJD'; }
export async function writeAsStringAsync() {}
export async function getInfoAsync() { return { exists: true }; }
export async function copyAsync() {}
export async function makeDirectoryAsync() {}
export async function deleteAsync() {}
export async function shareAsync() {}
export async function isAvailableAsync() { return true; }
export async function activateKeepAwakeAsync() {}
export function deactivateKeepAwake() {}
export async function printAsync() {}
export const getDocumentAsync = async () => ({ canceled: true });
