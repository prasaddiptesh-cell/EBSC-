// 3.9.2 Reading paper from photos: Z report (several layouts, columns split, camera mistakes), invoice / paid receipt,
// fuel receipt, deposit slip, FRCS / FNPF lodgement receipt, bank transfer proof, Aronium credit receipt, loan receipt.
// Nothing read may overwrite what a person typed; changes after reading are found; a strange photo never throws.
import { readPaperText, fillEmpty, changesAfterRead } from '../src/services/paperRead.js';
import { readZText, applyZRead, zReadChanges, amountsOn } from '../src/modules/till/zRead.js';
import { rowsFromResult } from '../src/services/paperRead.js';
import { test, done, assert } from './harness.js';

const TENDERS = ['EFTPOS / card', 'M-PAiSA', 'MyCash', 'Cheques received', 'On account (credit sales)', 'Vouchers'];

const Z1 = `EASY BUYS SHOPPING CENTRE
29 Drasa Avenue, Lautoka
TIN 50-12345-0-1
END OF DAY
Z REPORT No: 0412
Date: 10/10/2026 21:05
User: Sita
Payment types
Cash            1,245.60
M-PAiSA           180.00
Total           1,425.60
Tax rates
VAT 12.50%    1,175.60   130.62
VAT 0.00%       250.00     0.00
Total tax                130.62
Documents count   87
Refunds            12.50
Voids               3.00`;

test('amounts: commas, dollar signs, brackets, camera mistakes', () => {
  assert.deepStrictEqual(amountsOn('Total $ 1,425.60'), [1425.6]);
  assert.deepStrictEqual(amountsOn('Cash  1 245.60'), [1245.6]);
  assert.deepStrictEqual(amountsOn('Refund (12.50)'), [-12.5]);
  assert.deepStrictEqual(amountsOn('Cash 1,2O5.6O'), [1205.6]);
  assert.deepStrictEqual(amountsOn('Card 812,40'), [812.4]);
});
test('a typical Aronium Z report: every figure read and the sums agree', () => {
  const r = readZText(Z1, { tenders: TENDERS });
  assert.strictEqual(r.fields.zNumber, '412');
  assert.strictEqual(r.fields.date, '2026-10-10');
  assert.strictEqual(r.fields.zTotal, 1425.6);
  assert.strictEqual(r.fields.zCash, 1245.6);
  assert.deepStrictEqual(r.fields.tenders, [{ method: 'M-PAiSA', amount: 180 }]);
  assert.strictEqual(r.fields.zVat, 130.62);
  assert.strictEqual(r.fields.zZeroRated, 250);
  assert.strictEqual(r.fields.zRefunds, 12.5);
  assert.strictEqual(r.fields.zVoids, 3);
  assert.strictEqual(r.fields.zCustomers, 87);
  assert.ok(r.checks.every((c) => c.level === 'ok'), JSON.stringify(r.checks));
});
test('read in columns (labels, then the amounts on the next line) and with camera mistakes', () => {
  const t = `Z report
Number: 77
Cash
9O4.50
MPAISA
95.50
Card
0.00
Total sales
1,OOO.OO
VAT 12.5%  1000.00  111.11`;
  const r = readZText(t, { tenders: TENDERS });
  assert.strictEqual(r.fields.zNumber, '77');
  assert.strictEqual(r.fields.zCash, 904.5);
  assert.strictEqual(r.fields.zTotal, 1000);
  assert.ok(r.fields.tenders.some((x) => x.method === 'M-PAiSA' && x.amount === 95.5));
  assert.strictEqual(r.fields.zVat, 111.11);
});
test('the total chosen is the one that equals cash + other payments (not tax or item totals)', () => {
  const t = `END OF DAY  Z-15
Total items sold 340
Cash 600.00
MyCash 50.00
Total 650.00
Total tax 72.22
Grand total 650.00`;
  const r = readZText(t, { tenders: TENDERS });
  assert.strictEqual(r.fields.zTotal, 650);
  assert.ok(r.checks.find((c) => c.key === 'sum').level === 'ok');
});
test('a missed payment type is pointed out; wrong VAT is pointed out', () => {
  const r = readZText(`Z REPORT 9\nCash 500.00\nVoucher thing 20.0\nTotal 600.00\nVAT 12.5% 600.00 40.00`, { tenders: TENDERS });
  assert.strictEqual(r.checks.find((c) => c.key === 'sum').level, 'warn');
  assert.strictEqual(r.checks.find((c) => c.key === 'vat').level, 'warn');
});
test('cash in / cash out / starting cash are not the cash sales', () => {
  const r = readZText(`Z report 5\nStarting cash 100.00\nCash in 50.00\nCash out 20.00\nCash 300.00\nTotal 300.00`, { tenders: TENDERS });
  assert.strictEqual(r.fields.zCash, 300);
});
test('filling the till count: only empty boxes; a second reading replaces only what the first reading filled', () => {
  const form = { zNumber: '', zTotal: '1400', zCash: '', zVat: '', zZeroRated: '', zRefunds: '', zVoids: '', zCustomers: '', tenders: TENDERS.map((m) => ({ method: m, amount: '' })) };
  const r = readZText(Z1, { tenders: TENDERS });
  const a = applyZRead(form, r);
  assert.strictEqual(a.form.zTotal, '1400', 'what the person typed stays');
  assert.strictEqual(a.form.zCash, '1245.6');
  assert.ok(a.filled.includes('tender:M-PAiSA') && !a.filled.includes('zTotal'));
  const again = applyZRead({ ...a.form }, { fields: { ...r.fields, zCash: 1200 } }, a.filled);
  assert.strictEqual(again.form.zCash, '1200');
  const ch = zReadChanges({ ...a.form, zCash: '1254.60' }, r.fields);
  assert.ok(ch.some((c) => c.field === 'zCash' && c.read === 1245.6) && ch.some((c) => c.field === 'zTotal'));
});
test('rows rebuilt from where the text sits on the photo', () => {
  const L = (text, top, left) => ({ text, frame: { top, left, width: 100, height: 20 } });
  const res = { blocks: [{ lines: [L('Cash', 100, 10), L('Total', 140, 12)] }, { lines: [L('1,245.60', 102, 300), L('1,425.60', 141, 298)] }] };
  assert.strictEqual(rowsFromResult(res), 'Cash   1,245.60\nTotal   1,425.60');
  assert.strictEqual(rowsFromResult({ blocks: [{ lines: [{ text: 'x' }] }] }), null);
});
test('supplier invoice / paid receipt: supplier matched by TIN, number, date, total, VAT', () => {
  const t = `PUNJAS LIMITED\nTIN: 50-1234567-0-1\nTAX INVOICE\nInvoice No: INV-88412\nDate: 05/10/2026\nSubtotal 400.00\nVAT 12.5% 50.00\nTotal 450.00`;
  const r = readPaperText('invoice', t, { suppliers: [{ uid: 'S1', name: 'Punjas Limited', tin: '50123456701' }] });
  assert.strictEqual(r.fields.supplierUid, 'S1');
  assert.strictEqual(r.fields.invoiceNo, 'INV-88412');
  assert.strictEqual(r.fields.date, '2026-10-05');
  assert.strictEqual(r.fields.total, 450);
  assert.strictEqual(r.fields.vat, 50);
});
test('a shop receipt without "invoice": receipt number', () => {
  const r = readPaperText('invoice', `RB PATEL\nReceipt No. 004512\n09/10/2026\nTOTAL 23.40`, { suppliers: [] });
  assert.strictEqual(r.fields.invoiceNo, '004512');
  assert.strictEqual(r.fields.total, 23.4);
});
test('fuel receipt: litres and price a litre', () => {
  const r = readPaperText('fuel', `TOTAL ENERGIES LAUTOKA\nDate 08/10/2026\nDiesel 42.50 L\nPrice/L 2.89\nTOTAL 122.83`, { suppliers: [] });
  assert.strictEqual(r.fields.litres, 42.5);
  assert.strictEqual(r.fields.pricePerLitre, 2.89);
  assert.strictEqual(r.fields.total, 122.83);
  assert.ok(!r.checks.some((c) => /Litres/.test(c.text)));
});
test('stamped deposit slip: slip number, date, cash, cheques, total', () => {
  const r = readPaperText('deposit', `BSP Bank of South Pacific\nBranch: Lautoka\nDeposit Slip No 7741\nAcc No 1234 5678\nDate 10/10/2026\nCash 2,300.00\nCheques 150.00\nTotal 2,450.00`);
  assert.strictEqual(r.fields.slipNo, '7741');
  assert.strictEqual(r.fields.date, '2026-10-10');
  assert.strictEqual(r.fields.cash, 2300);
  assert.strictEqual(r.fields.cheques, 150);
  assert.strictEqual(r.fields.total, 2450);
  assert.strictEqual(r.fields.branch, 'Lautoka');
  assert.strictEqual(r.checks[0].level, 'ok');
});
test('FRCS lodgement receipt and a bank transfer proof', () => {
  const l = readPaperText('lodgement', `FRCS Taxpayer Online Services\nVAT Return Acknowledgement\nAcknowledgement No: TPOS-2026-551882\nDate lodged: 28/10/2026\nTax payable 1,312.50`);
  assert.strictEqual(l.fields.ref, 'TPOS-2026-551882');
  assert.strictEqual(l.fields.date, '2026-10-28');
  assert.strictEqual(l.fields.amount, 1312.5);
  const p = readPaperText('proof', `BSP mobile\nTransfer successful\nAmount FJD 1,312.50\nReference: TRX8812345\n29/10/2026 10:14\nAvailable balance 12,000.00`);
  assert.strictEqual(p.fields.amount, 1312.5);
  assert.strictEqual(p.fields.ref, 'TRX8812345');
  const c = readPaperText('proof', `Cheque No 000512\nPay FRCS\nAmount 1,312.50`);
  assert.strictEqual(c.fields.chequeNo, '512');
});
test('Aronium credit receipt and a loan repayment receipt', () => {
  const a = readPaperText('aronium', `EASY BUYS\nReceipt No: 3321\n10/10/2026\nRice 10kg 25.00\nSubtotal 25.00\nTotal 25.00`);
  assert.strictEqual(a.fields.receiptNo, '3321');
  assert.strictEqual(a.fields.total, 25);
  const ln = readPaperText('loan', `Credit Corporation (Fiji)\nOfficial Receipt No R-55120\nDate 01/10/2026\nAmount Paid 850.00\nBalance outstanding 12,400.00`);
  assert.strictEqual(ln.fields.receiptNo, 'R-55120');
  assert.strictEqual(ln.fields.amount, 850);
});
test('generic filling: only empty boxes; changes after reading found', () => {
  const r = { total: 450, date: '2026-10-05', invoiceNo: 'INV-1' };
  const map = { total: 'amount', date: 'date', invoiceNo: 'ref' };
  const a = fillEmpty({ amount: '', date: '2026-10-11', ref: '' }, r, map);
  assert.deepStrictEqual(a.filled, ['amount', 'ref']);
  assert.strictEqual(a.form.date, '2026-10-11');
  const ch = changesAfterRead({ ...a.form, amount: '455' }, r, map);
  assert.deepStrictEqual(ch.map((c) => c.field).sort(), ['amount', 'date']);
});
test('rubbish, empty and huge text never throw', () => {
  for (const k of ['z', 'invoice', 'fuel', 'deposit', 'lodgement', 'proof', 'aronium', 'loan', 'nope']) {
    for (const t of ['', '@@@@ ####', null, 'x\n'.repeat(5000), '1.00 2.00 3.00 '.repeat(2000)]) {
      const r = readPaperText(k, t, {});
      assert.ok(r && typeof r.fields === 'object');
    }
  }
});
done();
