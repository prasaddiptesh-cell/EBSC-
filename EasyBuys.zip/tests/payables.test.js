// Invoices & Payments: suppliers, invoices, due flags, paying, pay trail, credits, cheque books, balancing.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import { parseInvoiceText, ebDatesIn } from '../src/modules/payables/parser.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T10:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);

let rb; let moti; let acct;
test('permissions: manager enters and checks invoices but cannot pay; owner can do all', () => {
  assert.ok(can(mgr, 'invoices_enter') && can(mgr, 'invoices_check') && !can(mgr, 'payments_make'));
  assert.ok(can(owner, 'payments_make') && can(owner, 'cheques_manage'));
});

test('suppliers: unique name and TIN, terms, on account', () => {
  rb = AP.saveSupplier(owner, { name: 'RB Patel Group', tin: '500-012-345', onAccount: true, termsDays: 7, payMethod: 'cheque' });
  moti = AP.saveSupplier(owner, { name: 'Motibhai & Company', payMethod: 'cash' });
  assert.strictEqual(rb.tin, '500012345');
  throws(() => AP.saveSupplier(owner, { name: 'rb patel group' }), /already a supplier/);
  throws(() => AP.saveSupplier(owner, { name: 'Other', tin: '500012345' }), /already used by RB Patel/);
  assert.strictEqual(AP.matchSupplier('R.B. Patel Group Ltd', '').uid, rb.uid);
  assert.strictEqual(AP.matchSupplier('', '500 012 345').uid, rb.uid);
});

test('VAT: standard 12.5% inside the total, zero-rated, mixed', () => {
  assert.strictEqual(AP.standardVat(112.5), 12.5);
  assert.deepStrictEqual(AP.workOutVat({ total: 200, vatType: 'zero' }), { vat: 0, zeroRated: 200 });
  assert.deepStrictEqual(AP.workOutVat({ total: 212.5, vatType: 'mixed', zeroRated: 100 }), { vat: 12.5, zeroRated: 100 });
  throws(() => AP.workOutVat({ total: 212.5, vatType: 'mixed', zeroRated: 100, vat: 30 }), /at most/);
});

let inv1; let inv2; let inv3;
test('invoices: on account gets a due date from the terms; duplicates refused; manager entry waits to be checked', () => {
  inv1 = AP.saveInvoice(mgr, { supplierUid: rb.uid, invoiceNo: 'inv-4471', invoiceDate: '2026-10-01', total: 1125, shopCode: 'S2' });
  assert.strictEqual(inv1.due_date, '2026-10-08');
  assert.strictEqual(inv1.on_account, 1);
  assert.strictEqual(inv1.vat, 125);
  assert.strictEqual(inv1.status, 'to_check');
  assert.strictEqual(inv1.due, 'due_today');
  throws(() => AP.saveInvoice(mgr, { supplierUid: rb.uid, invoiceNo: 'INV 4471', total: 5 }), /already entered/);
  inv2 = AP.saveInvoice(owner, { supplierUid: rb.uid, invoiceNo: '4480', invoiceDate: '2026-10-06', total: 450 }, { canCheck: true });
  assert.strictEqual(inv2.due_date, '2026-10-13');
  assert.strictEqual(inv2.due, 'not_due');
  assert.strictEqual(inv2.status, 'approved');
  inv3 = AP.saveInvoice(owner, { supplierUid: rb.uid, invoiceNo: '4402', invoiceDate: '2026-09-20', total: 300 }, { canCheck: true });
  assert.strictEqual(inv3.due, 'overdue');
  const cash = AP.saveInvoice(mgr, { supplierUid: moti.uid, invoiceNo: 'M-77', total: 80 });
  assert.strictEqual(cash.on_account, 0);
  assert.strictEqual(cash.due_date, '2026-10-08', 'cash suppliers are due on the day');
});

test('due flags: due soon window is admin-editable', () => {
  clock.override = new Date('2026-10-10T10:00:00');
  assert.strictEqual(AP.getInvoice(inv2.uid).due, 'due_soon');
  AP.saveApRules(owner, { ...AP.apRules(), dueSoonDays: 1 });
  assert.strictEqual(AP.getInvoice(inv2.uid).due, 'not_due');
  AP.saveApRules(owner, { ...AP.apRules(), dueSoonDays: 3 });
  const a = AP.apAlerts();
  assert.strictEqual(a.overdue.n, 3);
  assert.strictEqual(a.overdue.amount, 1505);
  assert.strictEqual(a.toCheck, 2);
});

test('check: someone else checks; owners may check their own', () => {
  throws(() => AP.checkInvoice(mgr, inv1.uid), /Someone else/);
  AP.checkInvoice(owner, inv1.uid);
  assert.strictEqual(AP.getInvoice(inv1.uid).status, 'approved');
  assert.strictEqual(AP.getInvoice(inv1.uid).checked_by_name, 'Divnesh Prasad');
});

test('snap now, read later: photo only, then Google text fills it in', () => {
  const s = AP.saveInvoice(mgr, { invoiceDate: '2026-10-09' }, { photos: ['file:///p1.jpg'] });
  assert.strictEqual(s.ocr_status, 'waiting');
  assert.strictEqual(s.due, 'to_read');
  assert.ok(db().get("SELECT 1 AS x FROM outbox WHERE kind = 'ocr'"));
  const text = 'RB PATEL GROUP LTD\nTIN: 500012345\nTAX INVOICE\nInvoice No: 4490\nDate: 07/10/2026\nSub Total 400.00\nVAT 50.00\nTOTAL 450.00';
  const r = AP.applyReadText(s.uid, text);
  assert.strictEqual(r.supplier_uid, rb.uid);
  assert.strictEqual(r.invoice_no, '4490');
  assert.strictEqual(r.invoice_date, '2026-10-07');
  assert.strictEqual(r.total, 450);
  assert.strictEqual(r.vat, 50);
  assert.strictEqual(r.due_date, '2026-10-14');
  assert.strictEqual(r.status, 'to_check', 'still needs a person to check');
});

let pay1;
test('pay by cheque: needs a cheque book; next number suggested; pay trail; part payment', () => {
  acct = AP.saveAccount(owner, { name: 'BSP Business Cheque', accountNo: '1234567', openingBalance: 5000, openingDate: '2026-10-01' });
  const alloc = [{ invoiceUid: inv3.uid, amount: 300 }, { invoiceUid: inv1.uid, amount: 500 }];
  throws(() => AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100201, allocations: alloc }), /not in any cheque book/);
  AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100201, lastNo: 100250 });
  throws(() => AP.saveBook(owner, { accountUid: acct.uid, firstNo: 100240, lastNo: 100260 }), /overlap/);
  assert.strictEqual(AP.nextChequeNo(acct.uid), 100201);
  throws(() => AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100201, allocations: [{ invoiceUid: inv3.uid, amount: 301 }] }), /only has \$300/);
  pay1 = AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100201, payDate: '2026-10-10', allocations: alloc });
  assert.strictEqual(pay1.amount, 800);
  assert.strictEqual(AP.nextChequeNo(acct.uid), 100202);
  throws(() => AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100201, allocations: [{ invoiceUid: inv2.uid, amount: 1 }] }), /already used/);
  const i1 = AP.getInvoice(inv1.uid);
  assert.strictEqual(i1.paid, 500);
  assert.strictEqual(i1.owing, 625);
  assert.ok(i1.partPaid);
  assert.strictEqual(AP.getInvoice(inv3.uid).due, 'paid');
  const trail = AP.payTrail(inv1.uid);
  assert.strictEqual(trail.length, 1);
  assert.strictEqual(trail[0].cheque_no, '100201');
  assert.strictEqual(trail[0].applied, 500);
  assert.strictEqual(trail[0].paid_by_name, 'Divnesh Prasad');
});

test('unchecked invoices cannot be paid (rule can be switched off)', () => {
  const x = AP.saveInvoice(mgr, { supplierUid: moti.uid, invoiceNo: 'M-90', total: 40 });
  throws(() => AP.makePayment(owner, { supplierUid: moti.uid, method: 'cash', shopCode: 'S2', allocations: [{ invoiceUid: x.uid, amount: 40 }] }), /must be checked/);
  AP.saveApRules(owner, { ...AP.apRules(), checkBeforePay: false });
  const p = AP.makePayment(owner, { supplierUid: moti.uid, method: 'cash', shopCode: 'S2', receivedBy: 'Driver Sami', allocations: [{ invoiceUid: x.uid, amount: 40 }] });
  assert.strictEqual(p.shop_code, 'S2');
  assert.strictEqual(p.received_by, 'Driver Sami');
  AP.saveApRules(owner, { ...AP.apRules(), checkBeforePay: true });
  throws(() => AP.makePayment(owner, { supplierUid: moti.uid, method: 'cash', allocations: [{ invoiceUid: x.uid, amount: 1 }] }), /which shop/);
});

test('credit note used against an invoice', () => {
  const cn = AP.saveInvoice(owner, { kind: 'credit', supplierUid: rb.uid, invoiceNo: 'CN-12', total: 100 }, { canCheck: true });
  assert.strictEqual(cn.owing, 100);
  AP.applyCredit(owner, { creditUid: cn.uid, allocations: [{ invoiceUid: inv1.uid, amount: 100 }] });
  assert.strictEqual(AP.getInvoice(inv1.uid).owing, 525);
  assert.strictEqual(AP.getInvoice(cn.uid).owing, 0);
  throws(() => AP.applyCredit(owner, { creditUid: cn.uid, allocations: [{ invoiceUid: inv1.uid, amount: 1 }] }), /Only \$0.00/);
});

test('transfer payment needs a reference and shows on the bank account', () => {
  throws(() => AP.makePayment(owner, { supplierUid: rb.uid, method: 'transfer', accountUid: acct.uid, allocations: [{ invoiceUid: inv2.uid, amount: 450 }] }), /reference/);
  AP.makePayment(owner, { supplierUid: rb.uid, method: 'transfer', accountUid: acct.uid, reference: 'BSP-778812', payDate: '2026-10-10', allocations: [{ invoiceUid: inv2.uid, amount: 450 }] });
  assert.strictEqual(AP.listBankEntries({ accountUid: acct.uid })[0].type, 'transfer_out');
});

test('void a payment: invoices owe again, cheque leaf stays used as void', () => {
  throws(() => AP.voidInvoice(owner, inv1.uid, 'x'), /Void those payments first/);
  throws(() => AP.voidPayment(owner, pay1.uid, ''), /reason/);
  AP.voidPayment(owner, pay1.uid, 'Wrong amount on cheque');
  assert.strictEqual(AP.getInvoice(inv3.uid).owing, 300);
  const leaves = AP.bookLeaves(AP.listBooks(acct.uid)[0].uid);
  assert.strictEqual(leaves.leaves[0].status, 'void');
  assert.strictEqual(AP.nextChequeNo(acct.uid), 100202);
  assert.strictEqual(AP.payTrail(inv3.uid)[0].status, 'void', 'trail keeps the voided payment');
});

test('cheque book: spoiled leaf, skipped numbers flagged, cleared cheques', () => {
  AP.spoilCheque(owner, { accountUid: acct.uid, chequeNo: 100202, reason: 'Written wrongly' });
  const p = AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100205, payDate: '2026-10-10', allocations: [{ invoiceUid: inv3.uid, amount: 300 }] });
  const b = AP.bookLeaves(AP.listBooks(acct.uid)[0].uid);
  assert.strictEqual(b.spoiled, 1);
  assert.strictEqual(b.skipped, 2, '100203 and 100204 were skipped');
  assert.strictEqual(AP.apAlerts().skipped, 2);
  throws(() => AP.markPresented(owner, p.cheque_uid, '2026-10-01'), /on or after/);
  AP.markPresented(owner, p.cheque_uid, '2026-10-12');
  throws(() => AP.voidPayment(owner, p.uid, 'x'), /already cleared/);
});

test('balance the cheque book against the statement', () => {
  AP.addBankEntry(owner, { accountUid: acct.uid, type: 'deposit', amount: 2000, date: '2026-10-09', reference: 'DEP-1' });
  AP.addBankEntry(owner, { accountUid: acct.uid, type: 'fee', amount: 5, date: '2026-10-10', clearedDate: '2026-10-10' });
  const pending = AP.makePayment(owner, { supplierUid: rb.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 100206, payDate: '2026-10-11', allocations: [{ invoiceUid: inv1.uid, amount: 200 }] });
  // book: 5000 + 2000 - 450 (transfer) - 5 - 300 - 200 = 6045
  const bb = AP.bookBalance(acct.uid, '2026-10-12');
  assert.strictEqual(bb.balance, 6045);
  // statement on 12 Oct: deposit not yet in, cheque 100206 not presented, transfer went through, 100205 cleared
  const r = AP.balanceCheck(acct.uid, '2026-10-12', 5000 - 450 - 5 - 300);
  assert.strictEqual(r.chequesOut, 200);
  assert.strictEqual(r.depositsInTransit, 2000);
  assert.strictEqual(r.otherOut, 450, 'transfer not ticked as cleared yet');
  assert.strictEqual(r.difference, -450);
  AP.setEntryCleared(owner, AP.listBankEntries({ accountUid: acct.uid }).find((e) => e.type === 'transfer_out').uid, '2026-10-10');
  const r2 = AP.balanceCheck(acct.uid, '2026-10-12', 5000 - 450 - 5 - 300);
  assert.ok(r2.balanced, `difference ${r2.difference}`);
  assert.ok(pending.cheque_uid);
});

test('stale cheques flagged after the admin-set months', () => {
  clock.override = new Date('2027-05-01T10:00:00');
  assert.strictEqual(AP.staleCheques().length, 1);
  clock.override = new Date('2026-10-12T10:00:00');
});

test('everything waits to sync, money rounded to cents', () => {
  const tables = new Set(pendingRecords(2000).map((r) => r.t));
  ['ap_suppliers', 'ap_invoices', 'ap_payments', 'ap_allocations', 'bank_accounts', 'cheque_books', 'cheques', 'bank_entries'].forEach((t) => assert.ok(tables.has(t), t));
  assert.strictEqual(AP.r2(0.1 + 0.2), 0.3);
});

test('review fixes: same invoice twice in one payment refused; unpaid invoice never hidden behind many paid ones', () => {
  const s2 = AP.saveSupplier(owner, { name: 'Bulk Test' });
  const one = AP.saveInvoice(owner, { supplierUid: s2.uid, invoiceNo: 'X1', total: 500 }, { canCheck: true });
  throws(() => AP.makePayment(owner, { supplierUid: s2.uid, method: 'cash', shopCode: 'S1', allocations: [{ invoiceUid: one.uid, amount: 500 }, { invoiceUid: one.uid, amount: 500 }] }), /only has \$500/);
  db().transaction(() => {
    for (let i = 0; i < 520; i++) {
      const inv = AP.saveInvoice(owner, { supplierUid: s2.uid, invoiceNo: `OLD${i}`, invoiceDate: '2026-01-01', total: 1 }, { canCheck: true });
      AP.makePayment(owner, { supplierUid: s2.uid, method: 'cash', shopCode: 'S1', payDate: '2026-01-02', allocations: [{ invoiceUid: inv.uid, amount: 1 }] });
    }
  });
  assert.ok(AP.listInvoices({ filter: 'unpaid' }).some((i) => i.uid === one.uid));
});

test('invoice reader: Fiji dates and amounts', () => {
  assert.deepStrictEqual(ebDatesIn('Date: 05/10/2026'), ['2026-10-05']);
  const p = parseInvoiceText('Punjas\nInvoice # 77812\n5-Oct-2026\nTOTAL $1,234.50\nVAT 137.17', [{ name: 'Punjas', tin: '' }], 0.125);
  assert.strictEqual(p.supplier, 'Punjas');
  assert.strictEqual(p.total, 1234.5);
});

done();
