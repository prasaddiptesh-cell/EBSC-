// Payment methods: cheque on "pay now" invoices; the owner / admin adds, renames, hides and removes methods; an added
// method works like cheque / cash / transfer and its name is kept on the payment.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as PM from '../src/modules/payables/payMethods.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });

test('standard methods include cheque; only owner / admin change them; standard ones cannot be removed', () => {
  assert.deepStrictEqual(PM.payMethods().map((m) => m.id), ['cheque', 'cash', 'transfer']);
  throws(() => PM.addPayMethod(mgr, { label: 'M-PAiSA', base: 'transfer' }), /Only the owner/);
  throws(() => PM.removePayMethod(owner, 'cheque'), /hide it instead/);
});
test('pay now with a cheque is kept on the invoice', () => {
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'C1', invoiceDate: '2026-10-11', total: 115, shopCode: 'S1', onAccount: false, payMethod: 'cheque' });
  assert.strictEqual(db().get('SELECT pay_method FROM ap_invoices WHERE uid = ?', [inv.uid]).pay_method, 'cheque');
});
test('add, rename, hide, show and remove; an added method pays like its kind and keeps its name', () => {
  const list = PM.addPayMethod(owner, { label: 'BSP Pay', base: 'cash' });
  const m = list.find((x) => x.label === 'BSP Pay');
  throws(() => PM.addPayMethod(owner, { label: 'bsp pay', base: 'cash' }), /already/);
  PM.renamePayMethod(owner, m.id, 'BSP Pay app');
  PM.setPayMethodActive(owner, 'transfer', false);
  assert.ok(!PM.payMethods().some((x) => x.id === 'transfer'));
  assert.ok(PM.payMethods({ all: true }).some((x) => x.id === 'transfer'));
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'C2', invoiceDate: '2026-10-11', total: 50, shopCode: 'S1' });
  try { AP.checkInvoice(mgr, inv.uid); } catch (e) { /* already checked */ }
  const p = AP.makePayment(owner, { supplierUid: sup.uid, method: m.id, shopCode: 'S1', receivedBy: 'Driver', allocations: [{ invoiceUid: inv.uid, amount: 50 }] });
  const row = db().get('SELECT method, method_name FROM ap_payments WHERE uid = ?', [p.uid]);
  assert.deepStrictEqual([row.method, row.method_name], ['cash', 'BSP Pay app']);
  PM.removePayMethod(owner, m.id);
  assert.ok(!PM.payMethod(m.id));
  assert.strictEqual(db().get('SELECT method_name FROM ap_payments WHERE uid = ?', [p.uid]).method_name, 'BSP Pay app', 'past payments keep it');
});
done();
