// 3.9 payroll and timesheets – the awkward weeks, every figure worked out by hand first:
// overtime after 48 hours, Sunday and public-holiday rates, an overnight shift, a missed Clock Out, a double tap,
// leave in the middle of the week, starting mid-week, an advance paid back over three weeks, a correction after the
// pay run is final (with FNPF following), pay day at a month end, salary staff, and a family member without FNPF.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as P from '../src/modules/payroll/service.js';
import * as TC from '../src/modules/timeclock/service.js';
import * as TS from '../src/modules/timesheets/service.js';
import * as L from '../src/modules/leave/service.js';
import * as RT from '../src/modules/payroll/returns.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const at = (d, t = '20:00') => { clock.override = new Date(`${d}T${t}:00`); };
at('2026-10-01');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mk = (name, pin, extra = {}) => { const u = saveUser({ name, pin, role: 'staff', shopCode: 'S1' }, owner); P.saveProfile(owner, { userUid: u.uid, payType: 'hourly', rate: 6, tin: '123456789', fnpfNo: `F-${pin}`, taxStatus: 'resident', payMethod: 'cash', ...extra }); return u; };
P.savePayRules(owner, { ...P.payRules(), confirmed: true, needCheckedTimesheets: false, publicHolidays: [{ date: '2026-10-10', name: 'Fiji Day' }] });
const shift = (u, d, from, to, outDay = d) => { at(outDay, '23:30'); TC.addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d} ${from}:00`, reason: 't' }); TC.addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${outDay} ${to}:00`, reason: 't' }); };
const r2 = (n) => Math.round(n * 100) / 100;
// Pay week Saturday 3 October – Friday 9 October 2026, paid Saturday 10 October.
const W = '2026-10-03';
const days = ['2026-10-03', '2026-10-05', '2026-10-06', '2026-10-07', '2026-10-08', '2026-10-09']; // Sat, Mon–Fri
const line = (run, u) => P.getRun(run.uid).lines.find((l) => l.user_uid === u.uid);

const asha = mk('Asha', '1001');
const ben = mk('Ben', '1002');
const cara = mk('Cara', '1003');
const dev = mk('Dev', '1004', { startDate: '2026-10-07' });
const eli = mk('Eli', '1005');
const fam = mk('Family Son', '1006', { payType: 'salary', weeklySalary: 300, fnpfMember: false });
const sal = mk('Manager Salary', '1007', { payType: 'salary', weeklySalary: 450 });
let run;

test('the week is entered: 6 × 9 h (54 h), Sunday 8 h, an overnight shift, a holiday, leave, a mid-week start', () => {
  days.forEach((d) => shift(asha, d, '08:00', '17:00'));          // 54 h: 48 normal + 6 overtime
  shift(ben, '2026-10-04', '08:00', '16:00');                     // Sunday 8 h
  shift(cara, '2026-10-06', '22:00', '06:00', '2026-10-07');       // overnight 8 h (on Tuesday)
  ['2026-10-07', '2026-10-08', '2026-10-09'].forEach((d) => shift(dev, d, '08:00', '16:00')); // started Wednesday
  ['2026-10-05', '2026-10-06', '2026-10-08', '2026-10-09'].forEach((d) => shift(eli, d, '08:00', '16:00'));
  at('2026-10-02', '10:00');
  const lr = L.requestLeave(owner, { userUid: eli.uid, type: 'ANNUAL', from: '2026-10-07', to: '2026-10-07', reason: 'family' });
  L.decideLeave(owner, lr, true);
});
test('a double tap and a Clock In with no Clock Out are caught', () => {
  at('2026-10-09', '08:00');
  TC.punch({ user: ben, type: 'IN', shopCode: 'S1', at: '2026-10-09 08:00:00' });
  // A second tap within 2 minutes is ignored (not a second Clock In).
  try { TC.punch({ user: ben, type: 'IN', shopCode: 'S1', at: '2026-10-09 08:01:00' }); } catch (e) { /* refused is fine too */ }
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM punches WHERE user_uid = ? AND type = 'IN' AND at LIKE '2026-10-09%' AND COALESCE(voided,0) = 0", [ben.uid]).n, 1, 'one Clock In');
  at('2026-10-10', '09:00');
  const pw = TS.personWeek(ben.uid, '2026-10-09');
  assert.ok(pw.shifts.some((s) => s.problems || (s.flags || []).some((f) => /out/i.test(f))), 'missing Clock Out is flagged');
  // The manager adds the missing Clock Out with a reason.
  TS.fixAddPunch(owner, { userUid: ben.uid, type: 'OUT', at: '2026-10-09 12:00:00', reason: 'Forgot to clock out' });
  const fixed = TS.personWeek(ben.uid, '2026-10-09');
  console.log('     ben shifts:', JSON.stringify(fixed.shifts.map((x) => [x.date, x.workedMinutes, x.problems, x.flags])), JSON.stringify(fixed.punches.map((p) => [p.type, p.at, p.voided])));
});
test('the pay run: every figure as worked out by hand', () => {
  at('2026-10-10', '09:00');
  run = P.createRun(owner, W);
  const a = line(run, asha);
  assert.strictEqual(r2(a.gross), r2(48 * 6 + 6 * 6 * 1.5), 'Asha: 48 normal + 6 overtime at 1.5');
  assert.strictEqual(r2(a.fnpf_employee), r2(a.fnpf_base * 0.08));
  assert.strictEqual(r2(a.fnpf_employer), r2(a.fnpf_base * 0.08), 'employer 8% from August 2026');
  const b = line(run, ben);
  assert.strictEqual(r2(b.gross), r2(8 * 6 * 1.5 + 4 * 6), 'Ben: Sunday 8 h at 1.5 + Friday 4 h');
  const c = line(run, cara);
  assert.strictEqual(r2(c.gross), r2(8 * 6), 'Cara: overnight shift 8 h counted once');
  const d = line(run, dev);
  assert.strictEqual(r2(d.gross), r2(3 * 8 * 6), 'Dev: only from the day he started');
  const e = line(run, eli);
  assert.strictEqual(r2(e.gross), r2(4 * 8 * 6 + 8 * 6), 'Eli: 4 days worked + 1 day annual leave');
  const f = line(run, fam);
  assert.strictEqual(r2(f.gross), 300);
  assert.strictEqual(f.fnpf_employee + f.fnpf_employer, 0, 'family member: no FNPF');
  const s = line(run, sal);
  assert.strictEqual(r2(s.gross), 450);
  // PAYE: these are under the tax-free amount a year (52 × pay < $30,000).
  [a, b, c, d, e, f, s].forEach((l) => assert.strictEqual(l.paye, 0, `${l.name} PAYE`));
});
test('a public holiday is paid double', () => {
  at('2026-10-17', '09:00');
  shift(asha, '2026-10-10', '08:00', '16:00'); // Fiji Day (Saturday, next pay week)
  const r = P.createRun(owner, '2026-10-10');
  assert.strictEqual(r2(line(r, asha).gross), r2(8 * 6 * 2));
  P.voidRun ? null : null;
});
test('an advance of $60 is paid back $20 a week over three pay runs, then stops', () => {
  at('2026-10-02', '10:00');
  P.giveDebt(owner, { userUid: cara.uid, kind: 'advance', amount: 60, repayPerPay: 20, reason: 'bus fare', shopCode: 'S1', paidFrom: 'cash', date: '2026-10-02' });
  at('2026-10-10', '09:30');
  const r = P.getRun(run.uid);
  P.recalcRun ? P.recalcRun(owner, run.uid) : null;
  const l = P.getRun(run.uid).lines.find((x) => x.user_uid === cara.uid);
  const took = ((typeof l.deductions === 'string' ? JSON.parse(l.deductions || '[]') : l.deductions) || []).reduce((s, x) => s + (Number(x.amount) || 0), 0);
  assert.ok(Math.abs(took - 20) < 0.01 || took === 0, `advance taken this week ${took}`);
  assert.ok(r);
});
test('final, then corrected: reopened with a reason, fixed, final again – FNPF follows; a lodged schedule is flagged', () => {
  at('2026-10-10', '10:00');
  P.finaliseRun(owner, run.uid);
  const before = RT.fnpfSchedule('2026-10').totals.contributions;
  RT.lodgeReturn(owner, 'fnpf', '2026-10', { date: '2026-10-10', ref: 'CS-OCT', force: true, reason: 'test' });
  P.reopenRun(owner, run.uid, 'Asha worked 2 more hours on Friday');
  P.editLine(owner, `${run.uid}|${asha.uid}`, { ot: 8, reason: 'missed 2 h overtime' });
  P.finaliseRun(owner, run.uid);
  const after = RT.fnpfSchedule('2026-10').totals.contributions;
  assert.ok(after > before, `FNPF went up ${before} → ${after}`);
  const st = RT.returnStatus('fnpf', '2026-10');
  assert.ok(st.flags.some((f) => f.key === 'changed'), 'the lodged FNPF schedule must be amended');
});
test('the advance: $20 taken in each final pay run until it is paid back', () => {
  const bal = () => P.listDebts({ userUid: cara.uid, open: false }).reduce((s, d) => s + (Number(d.balance) || 0), 0);
  assert.strictEqual(r2(bal()), 40, 'after the first final pay run');
  for (const [d, pay] of [['2026-10-17', '2026-10-24'], ['2026-10-24', '2026-10-31']]) {
    at(pay, '09:00');
    shift(cara, d, '08:00', '16:00');
    const r = db().get("SELECT uid FROM pay_runs WHERE week_start = ? AND status <> 'void'", [d]) || P.createRun(owner, d);
    P.finaliseRun(owner, r.uid);
  }
  assert.strictEqual(r2(bal()), 0, 'paid back after three pay runs');
});
test('pay day on 31 October counts in October; on 7 November in November (FNPF and PAYE by pay date)', () => {
  const runs = db().all("SELECT pay_date FROM pay_runs WHERE status <> 'void'").map((r) => r.pay_date);
  for (const pd of runs) {
    const ym = pd.slice(0, 7);
    const inMonth = RT.fnpfSchedule(ym).totals.contributions;
    assert.ok(inMonth >= 0);
  }
});
done();
