// 3.6 pay run in steps: dates, who is paid, people left out paid later (never twice), pay day change, FNPF month runs
// and "changed since you paid".
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as S from '../src/modules/payroll/payRunSteps.js';
import * as ST from '../src/modules/payroll/statutory.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T20:00:00'); // Monday after the week Sat 3 – Fri 9 Oct
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const pay = saveUser({ name: 'Pita Payroll', pin: '6666', role: 'payroll' }, owner);
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', shopCode: 'S2' }, owner);
const ana = saveUser({ name: 'Ana Lee', pin: '4323', role: 'staff', shopCode: 'S2' }, owner);
const work = (u, d) => { addManualPunch(owner, { userUid: u.uid, type: 'IN', at: `${d} 08:00:00`, reason: 't' }); addManualPunch(owner, { userUid: u.uid, type: 'OUT', at: `${d} 16:00:00`, reason: 't' }); };
for (const u of [mere, sam, ana]) P.saveProfile(owner, { userUid: u.uid, payType: 'hourly', rate: 6, tin: '123456789', fnpfNo: 'F1', taxStatus: 'resident', payMethod: 'cash' });
['2026-10-05', '2026-10-06'].forEach((d) => { work(mere, d); work(sam, d); });
P.savePayRules && P.savePayRules(owner, { ...P.payRules(), confirmed: true });

let run;
test('step 1: the period and pay day, with warnings', () => {
  const p = S.planRun('2026-10-07');
  assert.deepStrictEqual([p.from, p.to, p.payDate], ['2026-10-03', '2026-10-09', '2026-10-10']);
  assert.ok(!p.warnings.length, JSON.stringify(p.warnings));
  const early = S.planRun('2026-10-07', { payDate: '2026-10-08' });
  assert.ok(early.warnings.some((w) => /before the end/.test(w.text)));
  assert.ok(S.planRun('2026-10-12').warnings.some((w) => /not finished/.test(w.text)));
});
test('step 2: everyone with their hours; start with only the people ticked', () => {
  const p = S.planRun('2026-10-07');
  const h = Object.fromEntries(p.people.map((x) => [x.name, x.hours]));
  assert.ok(h['Mere Tuilau'] > 0 && h['Sam Kumar'] > 0 && h['Ana Lee'] === 0, JSON.stringify(h));
  run = S.startRunWithPeople(pay, { date: '2026-10-07', payDate: '2026-10-11', people: [mere.uid, ana.uid] });
  assert.strictEqual(run.pay_date, '2026-10-11', 'pay day changed from the usual');
  const inc = run.lines.filter((l) => l.include).map((l) => l.name).sort();
  assert.deepStrictEqual(inc, ['Ana Lee', 'Mere Tuilau']);
  assert.deepStrictEqual(S.notPaidYet(run.uid).map((x) => x.name), ['Sam Kumar']);
  throws(() => S.startRunWithPeople(pay, { date: '2026-10-07', people: [sam.uid] }), /already a pay run/);
  assert.ok(S.planRun('2026-10-07').existing);
});
test('draft: people left out can be put back; pay day can change', () => {
  S.payLeftOut(pay, run.uid, [sam.uid]);
  assert.ok(P.getRun(run.uid).lines.find((l) => l.name === 'Sam Kumar').include);
  assert.strictEqual(S.notPaidYet(run.uid).length, 0);
  P.editLine(pay, `${run.uid}|${sam.uid}`, { include: false, reason: 'Paid separately' });
  S.setPayDate(owner, run.uid, '2026-10-10');
  assert.strictEqual(P.getRun(run.uid).pay_date, '2026-10-10');
});
test('final: the one left out is paid later in their own run for the same period – never twice', () => {
  P.finaliseRun(owner, run.uid);
  const later = S.payLeftOut(owner, run.uid, [sam.uid]);
  assert.notStrictEqual(later.uid, run.uid);
  assert.strictEqual(later.run_kind, 'catchup');
  assert.deepStrictEqual([later.week_start, later.week_end], ['2026-10-03', '2026-10-09']);
  const l = later.lines[0];
  assert.strictEqual(l.name, 'Sam Kumar'); assert.ok(l.gross > 0, 'worked out from the timesheet');
  assert.strictEqual(S.notPaidYet(run.uid).length, 0, 'no longer listed as not paid');
  throws(() => S.payLeftOut(owner, run.uid, [sam.uid]), /already paid/);
  throws(() => S.payLeftOut(owner, run.uid, [mere.uid]), /already paid/);
  P.finaliseRun(owner, later.uid);
});
test('FNPF month: both runs listed; paid; a correction later shows "changed since you paid"', () => {
  const runs = S.monthRuns('2026-10');
  assert.strictEqual(runs.length, 2);
  const f = ST.monthFigures('2026-10');
  assert.ok(f.fnpf > 0);
  assert.strictEqual(f.people.length, 3, 'Mere, Ana (no hours) and Sam');
  ST.prepareMonth('2026-10');
  const fnpf = ST.listStat({ ym: '2026-10', kind: 'fnpf' })[0];
  ST.payStat(owner, fnpf.uid, { date: '2026-10-20', amount: fnpf.amount, method: 'cash', receiptNo: 'R1' });
  assert.strictEqual(ST.listStat({ ym: '2026-10', kind: 'fnpf' })[0].changedSincePaid, 0);
  P.reopenRun(owner, run.uid, 'Missed hours');
  P.editLine(owner, `${run.uid}|${mere.uid}`, { normal: 30 });
  P.finaliseRun(owner, run.uid);
  const after = ST.listStat({ ym: '2026-10', kind: 'fnpf' })[0];
  assert.ok(after.changedSincePaid > 0, `changed ${after.changedSincePaid}`);
});
done();
