// Recruitment, hiring, onboarding, contracts signed on screen with emails, staff signing for pay.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as PP from '../src/modules/people/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as V from '../src/modules/verify/service.js';
import { addManualPunch } from '../src/modules/timeclock/service.js';
import { checkWeek } from '../src/modules/timesheets/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T20:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgrP = saveUser({ name: 'Mani Manager', pin: '8181', role: 'manager', shopCode: 'S1' }, owner);
const SIG = 'data:image/png;base64,iVBORw0KGgo=';
let hired;

test('vacancy, applicant, stages, not-suitable needs a reason', () => {
  const job = PP.saveOpening(owner, { title: 'Cashier', shopCode: 'S2', rate: 5.6 });
  const a = PP.saveApplicant(owner, { openingUid: job, name: 'Losana Vula', phone: '7001234', email: 'losana@example.com' }, { photos: ['file:///cv.jpg'] });
  throws(() => PP.saveApplicant(mgrP, { uid: a, name: 'Losana Vula', phone: '7001234', stage: 'rejected' }), /why/);
  PP.saveApplicant(owner, { uid: a, openingUid: job, name: 'Losana Vula', phone: '7001234', email: 'losana@example.com', stage: 'interview', interviewAt: '2026-10-13 10:00', score: 8 });
  assert.strictEqual(PP.listOpenings()[0].active, 1);
  hired = PP.hire(owner, a, { startDate: '2026-10-12' });
  assert.ok(/^\d{4}$/.test(hired.pin));
  assert.strictEqual(hired.employeeNo, 'EB001');
  assert.strictEqual(PP.getApplicant(a).stage, 'hired');
  assert.strictEqual(P.getProfile(hired.user.uid).rate, 5.6);
  const mail = db().all("SELECT * FROM outbox WHERE kind = 'email'");
  assert.strictEqual(mail.length, 1, 'welcome email queued');
  assert.ok(JSON.parse(mail[0].payload).text.includes('Your TIN letter'));
});

test('onboarding: auto items tick themselves; probation end 3 months later', () => {
  const o = PP.getOnboarding(hired.user.uid);
  assert.strictEqual(o.probation_end, '2027-01-12');
  assert.ok(o.list.find((x) => x.key === 'pay').done);
  assert.ok(o.list.find((x) => x.key === 'pin').done);
  assert.ok(!o.list.find((x) => x.key === 'contract').done);
  PP.tickOnboarding(owner, hired.user.uid, 'uniform');
  assert.ok(PP.getOnboarding(hired.user.uid).list.find((x) => x.key === 'uniform').done);
});

test('contract: filled in, employee signs then employer, emailed with the PDF', () => {
  const uid = PP.makeContract(owner, hired.user.uid);
  const c = PP.getContract(uid);
  assert.ok(c.body.includes('Losana Vula') && c.body.includes('$5.60 an hour') && c.body.includes('Cashier'));
  throws(() => PP.signContractEmployer(owner, uid, SIG), /employee signs first/);
  throws(() => PP.signContractEmployee(owner, uid, null), /sign first/);
  PP.signContractEmployee(owner, uid, SIG);
  const r = PP.signContractEmployer(owner, uid, SIG);
  assert.strictEqual(r.email, 'losana@example.com');
  assert.strictEqual(PP.getContract(uid).status, 'signed');
  assert.strictEqual(db().all("SELECT * FROM outbox WHERE kind = 'contract_email'").length, 1);
  assert.ok(PP.getOnboarding(hired.user.uid).list.find((x) => x.key === 'contract').done);
  const rep = PP.contractReport(uid);
  assert.strictEqual(rep.signatures.length, 2);
});

test('company contract PDF: needs the PDF; director signature added on approval; signed copy kept and emailed', () => {
  const live = db().get("SELECT uid FROM contracts WHERE user_uid = ? AND status IN ('draft','employee_signed')", [hired.user.uid]);
  assert.ok(!live);
  throws(() => PP.saveContractPdfSettings(owner, { on: true }), /Upload the company contract PDF/);
  PP.saveContractPdfSettings(owner, { templateDocUid: 'DOC-TPL', templateName: 'Easy Buys contract.pdf' });
  PP.saveContractPdfSettings(owner, { on: true });
  const uid = PP.makeContract(owner, hired.user.uid);
  const c = PP.getContract(uid);
  assert.strictEqual(c.mode, 'pdf');
  assert.strictEqual(c.template_doc_uid, 'DOC-TPL');
  PP.signContractEmployee(owner, uid, SIG);
  throws(() => PP.signContractEmployer(owner, uid, null, { useDirector: true }), /director/);
  const dsig = PP.saveSignature(SIG, 'Divnesh Avnil Prasad');
  const ssig = PP.saveSignature('data:image/jpeg;base64,/9j/AAAA', 'Company stamp');
  PP.saveContractPdfSettings(owner, { directorSigUid: dsig, directorName: 'Divnesh Avnil Prasad', stampSigUid: ssig });
  const before = db().get("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'contract_email'").n;
  const r = PP.signContractEmployer(owner, uid, null, { useDirector: true });
  assert.ok(r.pdf, 'the screen makes the PDF');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'contract_email'").n, before, 'email waits for the PDF');
  const d = PP.contractPdfData(uid);
  assert.strictEqual(d.dirName, 'Divnesh Avnil Prasad');
  assert.ok(d.dirSig && d.stamp && d.empSig);
  const m = PP.attachSignedContract(owner, uid, 'DOC-SIGNED');
  assert.strictEqual(PP.getContract(uid).doc_uid, 'DOC-SIGNED');
  assert.strictEqual(m.email, 'losana@example.com');
  const mail = JSON.parse(db().get("SELECT payload FROM outbox WHERE kind = 'contract_email' ORDER BY id DESC").payload);
  assert.strictEqual(mail.docUid, 'DOC-SIGNED');
  assert.ok(PP.contractFields(hired.user.uid).fnpf_employer);
  PP.saveContractPdfSettings(owner, { on: false });
});

test('staff sign for their pay; a query reaches the manager; all cash signed = cash wages verified', () => {
  ['2026-10-12'].forEach((d) => { addManualPunch(owner, { userUid: hired.user.uid, type: 'IN', at: `${d} 08:00:00`, reason: 't' }); addManualPunch(owner, { userUid: hired.user.uid, type: 'OUT', at: `${d} 16:00:00`, reason: 't' }); });
  const run = P.createRun(owner, '2026-10-12');
  throws(() => PP.signPay(owner, { runUid: run.uid, userUid: hired.user.uid, signature: SIG }), /final/);
  checkWeek(owner, hired.user.uid, '2026-10-12', 'ok');
  P.finaliseRun(owner, run.uid);
  throws(() => PP.signPay(owner, { runUid: run.uid, userUid: hired.user.uid, status: 'query' }), /what is wrong/);
  PP.signPay(owner, { runUid: run.uid, userUid: hired.user.uid, status: 'query', note: 'Missing Monday overtime' });
  assert.strictEqual(PP.peopleAlerts().queries, 1);
  PP.answerQuery(owner, `${run.uid}|${hired.user.uid}`, 'Checked: no overtime that day');
  PP.signPay(owner, { runUid: run.uid, userUid: hired.user.uid, signature: SIG });
  assert.strictEqual(PP.signoffsFor(run.uid)[0].signoff.status, 'signed');
  const cash = V.queue({ include: 'done', to: '2026-10-31' }).find((x) => x.table === 'pay_cash');
  assert.ok(cash && cash.done, 'cash wages verified by the signatures');
});

done();
