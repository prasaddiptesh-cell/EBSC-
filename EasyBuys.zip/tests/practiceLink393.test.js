// 3.9.3 Practice (training) mode keeps the device linked: the cloud link is read from the real database, practice
// cannot change it, practice cannot send real device actions (block, wipe, settings, linking), and the device is
// never locked while practising. Leaving practice: everything as it was.
import { openNodeDb } from './nodeDb.js';
import { clock, getSetting, setSetting, deviceId } from '../src/services/core.js';
import { startDatabases, enterTraining, leaveTraining, isTraining } from '../src/platform/training.js';
import { linkState } from '../src/modules/devices/service.js';
import { deviceLock } from '../src/modules/devices/control.js';
import { cloudCall } from '../src/platform/cloud.js';
import { test, atest, done, assert } from './harness.js';

clock.override = new Date('2026-10-11T12:00:00');
startDatabases(() => openNodeDb());
setSetting('cloud_url', 'https://script.google.com/macros/s/REAL/exec');
setSetting('cloud_token', 'real-token');
const id = deviceId();
setSetting('device_blocked', '1');

test('in practice the device is still linked, with the same device id, and never locked', () => {
  enterTraining({ fresh: true });
  assert.ok(isTraining());
  assert.strictEqual(getSetting('cloud_token', ''), 'real-token');
  assert.strictEqual(deviceId(), id);
  assert.ok(linkState().linked, 'still linked');
  assert.strictEqual(deviceLock(), null);
});
test('practice cannot change the link', () => {
  setSetting('cloud_token', '');
  setSetting('cloud_url', '');
  assert.strictEqual(getSetting('cloud_token', ''), 'real-token');
});
await atest('practice cannot send real device actions or link', async () => {
  for (const kind of ['device_status', 'device_control', 'cloud_settings', 'join', 'invite']) {
    let msg = '';
    try { await cloudCall({ kind, id: 'X', status: 'blocked' }); } catch (e) { msg = e.message; }
    assert.ok(/practice mode/.test(msg), `${kind}: ${msg}`);
  }
});
test('back to the real app: the link is unchanged', () => {
  leaveTraining();
  assert.ok(!isTraining());
  assert.strictEqual(getSetting('cloud_token', ''), 'real-token');
  assert.strictEqual(getSetting('cloud_url', ''), 'https://script.google.com/macros/s/REAL/exec');
  assert.strictEqual(deviceLock().kind, 'blocked', 'the real lock is still there (owner PIN opens it)');
});
done();
