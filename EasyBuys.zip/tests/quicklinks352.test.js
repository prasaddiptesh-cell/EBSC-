// 3.5.2 – quick links: per person, synced (shared settings), starting links per role, max 8, order.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { saveUser } from '../src/services/catalog.js';
import * as Q from '../src/services/quickLinks.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const items = ['till:home', 'payables:home', 'inventory:inv-receive', 'payables:ap-new', 'bank:home', 'a:1', 'a:2', 'a:3', 'a:4'].map((k) => ({ key: k, title: k }));

test('starting links come from the role; resolve leaves out what the person cannot open', () => {
  assert.deepStrictEqual(Q.quickLinkKeys(mgr), Q.BUILT_IN.manager);
  const r = Q.resolveQuickLinks(mgr, items.filter((i) => i.key !== 'payables:ap-new'));
  assert.ok(!r.some((i) => i.key === 'payables:ap-new'));
});
test('add, remove, move; at most 8; saved in the synced settings', () => {
  Q.saveQuickLinks(owner, []);
  Q.toggleQuickLink(owner, 'till:home'); Q.toggleQuickLink(owner, 'bank:home');
  assert.deepStrictEqual(Q.quickLinkKeys(owner), ['till:home', 'bank:home']);
  Q.moveQuickLink(owner, 'bank:home', -1);
  assert.deepStrictEqual(Q.quickLinkKeys(owner), ['bank:home', 'till:home']);
  Q.toggleQuickLink(owner, 'till:home');
  assert.deepStrictEqual(Q.quickLinkKeys(owner), ['bank:home']);
  for (const k of ['a:1', 'a:2', 'a:3', 'a:4', 'payables:home', 'inventory:inv-receive', 'payables:ap-new']) Q.toggleQuickLink(owner, k);
  let msg = '';
  try { Q.toggleQuickLink(owner, 'till:home'); } catch (e) { msg = e.message; }
  assert.ok(/Up to 8/.test(msg));
  const row = db().get("SELECT sync_status FROM shared_settings WHERE key = 'quick_links'");
  assert.strictEqual(row.sync_status, 'pending', 'goes to the other devices');
});
test('owner sets the starting links for a role; reset goes back to them; managers cannot set them', () => {
  Q.setRoleDefaults(owner, 'manager', ['till:home', 'bank:home']);
  Q.saveQuickLinks(mgr, ['payables:home']);
  assert.deepStrictEqual(Q.resetQuickLinks(mgr), ['till:home', 'bank:home']);
  let msg = '';
  try { Q.setRoleDefaults(mgr, 'staff', ['till:home']); } catch (e) { msg = e.message; }
  assert.ok(/owner or admin/.test(msg));
});
done();
