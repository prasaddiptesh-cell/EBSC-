// 3.9 admin corrections: the owner or an admin corrects any field of a record; history keeps before/after; what it
// touches is worked out again and anything now out of line is listed. Others cannot.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import * as RT from '../src/modules/payroll/returns.js';
import * as FX from '../src/services/recordFix.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-20T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const admin = saveUser({ name: 'Admin Two', pin: '7777', role: 'admin' }, owner);
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P-1O', invoiceDate: '2026-09-05', total: 112.5, shopCode: 'S1' }, { canCheck: true });

test('find a record by what people know (invoice number, supplier)', () => {
  const r = FX.findForFix('p-1o');
  assert.ok(r.some((x) => x.table === 'ap_invoices' && x.keyVal === inv.uid));
  assert.ok(FX.findForFix('punj').some((x) => x.table === 'ap_suppliers'));
});
test('only the owner or an admin can correct; a manager cannot', () => {
  throws(() => FX.saveFix(mgr, 'ap_invoices', inv.uid, { invoice_no: 'P-10' }), /owner or an admin/);
});
test('a typo in an invoice number and a wrong date are corrected; the history keeps before and after; it will sync', () => {
  const r = FX.saveFix(admin, 'ap_invoices', inv.uid, { invoice_no: 'P-10', invoice_date: '2026-09-15' });
  assert.strictEqual(r.record.row.invoice_no, 'P-10');
  assert.strictEqual(r.record.row.sync_status, 'pending');
  const h = db().get("SELECT * FROM audit_log WHERE record_uid = ? AND action LIKE 'Corrected%' ORDER BY at DESC LIMIT 1", [inv.uid]);
  assert.ok(/P-1O/.test(h.action) && /P-10/.test(h.action));
  throws(() => FX.saveFix(owner, 'ap_invoices', inv.uid, { total: 'abc' }), /number/);
  throws(() => FX.saveFix(owner, 'ap_invoices', inv.uid, { invoice_date: '15/9/2026' }), /YYYY-MM-DD/);
  throws(() => FX.saveFix(owner, 'ap_invoices', inv.uid, { invoice_no: 'P-10' }), /Nothing was changed/);
});
test('PINs and face records are never shown or changed here', () => {
  const f = FX.fixFields('users').map((x) => x.name);
  assert.ok(!f.includes('pin') && !f.includes('password_hash') && !f.includes('face'));
  throws(() => FX.saveFix(owner, 'users', mgr.uid, { pin: '0000' }), /cannot be changed here/);
});
test('correcting a lodged VAT month: the change is listed – lodge an amended return', () => {
  RT.lodgeReturn(owner, 'vat', '2026-09', { ref: 'TPOS-1', force: true, reason: 't' });
  const r = FX.saveFix(owner, 'ap_invoices', inv.uid, { total: 225, vat: 25 });
  assert.ok(r.checks.some((c) => /VAT return for 2026-09 was lodged/.test(c)), JSON.stringify(r.checks));
});
test('correcting a delivery quantity: the order is worked out again', () => {
  const it = I.saveItem(owner, { code: 'R', name: 'Rice', cost: 30, price: 40 });
  const po = I.savePO(owner, { supplierUid: sup.uid, shopCode: 'S1', lines: [{ itemUid: it.uid, qty: 10, unitCost: 30 }] });
  I.submitPO(owner, po.uid, { canApprove: true });
  const o = I.getPO(po.uid);
  const rc = I.receiveDelivery(owner, { poUid: po.uid, lines: [{ lineUid: o.lines[0].uid, qty: 10 }] });
  assert.strictEqual(I.getPO(po.uid).status, 'received');
  const lines = JSON.parse(db().get('SELECT lines FROM inv_receipts WHERE uid = ?', [rc.uid]).lines);
  lines[0].qty = 6;
  FX.saveFix(owner, 'inv_receipts', rc.uid, { lines: JSON.stringify(lines) });
  assert.strictEqual(I.getPO(po.uid).lines[0].qty_received, 6);
  assert.strictEqual(I.getPO(po.uid).status, 'part');
  assert.strictEqual(db().get("SELECT SUM(qty) AS q FROM inv_moves WHERE item_uid = ? AND status = 'active'", [it.uid]).q, 6, 'the stock follows the corrected delivery');
});
test('pay and journal lines are corrected where they are worked out (the app says where)', () => {
  throws(() => FX.fixFields('pay_lines'), /Reopen/);
  throws(() => FX.saveFix(owner, 'gl_journals', 'x', { lines: '[]' }), /Void the journal|not found/);
});
done();
