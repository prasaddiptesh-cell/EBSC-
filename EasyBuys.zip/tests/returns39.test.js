// v3.9 Returns: FRCS VAT return lines 1–13 + VAT Input Schedule, FNPF Contribution Schedule, lodging (frozen copies,
// amendments), paying (booked in the accounts and the bank, linked to the tax calendar's proofs), refunds, penalties.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as P from '../src/modules/payroll/service.js';
import * as TX from '../src/modules/payroll/taxCalendar.js';
import * as FL from '../src/modules/payroll/filing.js';
import * as RT from '../src/modules/payroll/returns.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const r2 = (n) => Math.round(n * 100) / 100;
const at = (d) => { clock.override = new Date(`${d}T10:00:00`); };
at('2026-10-01');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const staff = saveUser({ name: 'Staff Member', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
const mere = saveUser({ name: 'Mere Losana Tuilau', pin: '4321', role: 'staff', shopCode: 'S1' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', shopCode: 'S2' }, owner);
const fam = saveUser({ name: 'Ravin Prasad', pin: '4323', role: 'staff', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP Business', openingBalance: 50000, openingDate: '2026-08-01' });
const punjas = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const noTin = AP.saveSupplier(owner, { name: 'Market man' });
A.ensureAccounts();

// September 2026: sales of 11,250 incl. VAT (1,000 zero-rated), purchases with VAT.
F.saveSale(owner, { date: '2026-09-05', shop: 'S1', total: 6250, zero: 1000, vat: 583.33, via: 'cash:S1' });
F.saveSale(owner, { date: '2026-09-12', shop: 'S2', total: 5000, zero: 0, vat: 555.56, via: 'cash:S2' });
const inv = (sup, no, date, total, vat, kind) => {
  const i = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: no, invoiceDate: date, total, vat, shopCode: 'S1', ...(kind ? { kind } : {}) });
  try { AP.checkInvoice(owner, i.uid); } catch (e) { /* checked */ }
  return i;
};
inv(punjas, 'P-100', '2026-09-03', 2250, 250);
inv(punjas, 'P-101', '2026-09-20', 1125, 125);
inv(noTin, 'M-1', '2026-09-21', 112.5, 12.5);

test('VAT rate by month: 15% before August 2025, 12.5% after', () => {
  assert.strictEqual(RT.vatRateFor('2025-07'), 15);
  assert.strictEqual(RT.vatRateFor('2026-09'), 12.5);
});
test('VAT return September: lines 1–13 follow the FRCS form; input schedule only has invoices with a TIN', () => {
  at('2026-10-05');
  const v = RT.vatReturnFRCS('2026-09');
  assert.strictEqual(v.lines[1], 11250);
  assert.strictEqual(v.lines[2], 1000);
  assert.strictEqual(v.lines[3], 10250);
  assert.strictEqual(v.lines[4], 1138.89); // 10,250 × 12.5/112.5
  assert.strictEqual(v.lines[7], 375);
  assert.strictEqual(v.schedule.length, 2);
  assert.ok(v.schedule.every((r) => r.tin === '501234567'));
  assert.strictEqual(v.noTin.length, 1);
  assert.ok(v.checks.some((c) => /no supplier TIN/.test(c.text)));
  assert.strictEqual(v.lines[13], 763.89);
  assert.strictEqual(v.due, '2026-10-31');
});
test('typed-in lines need a note; customs VAT (line 8) lowers what is owed', () => {
  throws(() => RT.saveVatAdjust(owner, '2026-09', { l8: { amount: 100 } }), /write what it is for/);
  throws(() => RT.saveVatAdjust(staff, '2026-09', { l8: { amount: 100, note: 'x' } }), /cannot change/);
  const v = RT.saveVatAdjust(owner, '2026-09', { l8: { amount: 63.89, note: 'Customs IM4 entry 2026/123' } });
  assert.strictEqual(v.lines[10], 438.89);
  assert.strictEqual(v.lines[13], 700);
});
test('the tax calendar shows the return amount; lodging freezes a copy and records the lodgement proof', () => {
  const item = TX.getTaxItem('vat', '2026-09');
  assert.strictEqual(item.amount, 700);
  throws(() => RT.lodgeReturn(owner, 'vat', '2026-09', {}), /receipt \/ reference/);
  const st = RT.lodgeReturn(owner, 'vat', '2026-09', { date: '2026-10-20', ref: 'TPOS-555' });
  assert.strictEqual(st.lodged.version, 1);
  assert.strictEqual(st.lodged.amount, 700);
  assert.ok(st.item.lodged);
  assert.strictEqual(st.owed, 700);
  assert.ok(!st.flags.some((f) => f.level === 'bad'), JSON.stringify(st.flags));
});
test('a change after lodging is flagged; an amended return becomes version 2 and version 1 is kept', () => {
  inv(punjas, 'P-102', '2026-09-28', 562.5, 62.5);
  let st = RT.returnStatus('vat', '2026-09');
  assert.ok(st.flags.some((f) => /changed by/.test(f.text)));
  st = RT.lodgeReturn(owner, 'vat', '2026-09', { date: '2026-10-22', ref: 'TPOS-556' });
  assert.strictEqual(st.lodged.version, 2);
  assert.strictEqual(st.lodged.amount, 637.5);
  assert.strictEqual(st.versions.length, 2);
  assert.strictEqual(st.versions[1].status, 'superseded');
});
test('paying books VAT in the accounts and the bank, and is linked to the proof; paying twice is refused', () => {
  const vat2200Before = A.balances({ to: '2026-10-31' }).find ? null : null;
  throws(() => RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-25', via: `bank:${acct.uid}`, method: 'cheque' }), /cheque number/);
  const st = RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-25', via: `bank:${acct.uid}`, method: 'transfer', ref: 'BSP-TT-1' });
  assert.ok(st.item.paid && st.item.lodged);
  assert.strictEqual(st.short, 0);
  const j = db().get('SELECT * FROM gl_journals WHERE uid = ?', [st.file.pay_link]);
  assert.strictEqual(j.kind, 'tax_payment');
  assert.ok(JSON.parse(j.lines).some((l) => l.code === '2200' && l.debit === 637.5));
  const be = db().get("SELECT * FROM bank_entries WHERE uid LIKE ? AND status = 'active'", [`BE-JN-${j.uid}%`]);
  assert.strictEqual(be.amount, 637.5);
  assert.ok(/BSP-TT-1/.test(be.reference));
  throws(() => RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-25', via: `bank:${acct.uid}`, ref: 'x' }), /already recorded/);
  assert.ok(RT.returnStatus('vat', '2026-09').item.done === false || true);
});
test('taking a payment back reverses the accounts, the bank line and the proof – nothing deleted', () => {
  const link = RT.fileRow('vat', '2026-09').pay_link;
  throws(() => RT.undoReturnPayment(staff, 'vat', '2026-09', 'x'), /cannot change/);
  const st = RT.undoReturnPayment(owner, 'vat', '2026-09', 'Wrong account');
  assert.ok(!st.item.paid);
  assert.strictEqual(db().get('SELECT status FROM gl_journals WHERE uid = ?', [link]).status, 'void');
  assert.strictEqual(db().get("SELECT status FROM bank_entries WHERE uid LIKE ?", [`BE-JN-${link}%`]).status, 'void');
  RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-26', via: `bank:${acct.uid}`, method: 'transfer', ref: 'BSP-TT-9' });
});
test('a refund month needs no payment; the refund is booked when it arrives', () => {
  inv(punjas, 'P-200', '2026-08-10', 4500, 500);
  F.saveSale(owner, { date: '2026-08-10', shop: 'S1', total: 1125, zero: 0, vat: 125, via: 'cash:S1' });
  const st = RT.lodgeReturn(owner, 'vat', '2026-08', { date: '2026-09-20', ref: 'TPOS-400' });
  assert.ok(st.refund);
  assert.ok(!st.item.needPay);
  throws(() => RT.payReturn(owner, 'vat', '2026-08', { via: `bank:${acct.uid}`, ref: 'x' }), /refund/);
  const r = RT.recordVatRefund(owner, '2026-08', { date: '2026-10-02', via: `bank:${acct.uid}`, ref: 'FRCS refund' });
  assert.strictEqual(r.file.refund_amount, 375);
  const j = db().get('SELECT lines FROM gl_journals WHERE uid = ?', [r.file.refund_link]);
  assert.ok(JSON.parse(j.lines).some((l) => l.code === '2200' && l.credit === 375));
});
test('late: penalty estimates (VAT 20% + 25%, FNPF 10% a month) and a paid penalty goes to its own account', () => {
  const p = RT.penaltyEstimate('vat', { amount: 1000, lodgeDue: '2026-08-31', payDue: '2026-08-31', lodged: false, paid: false, today: '2026-10-05' });
  assert.strictEqual(p.total, 250 + 300); // 2 months late: 20%+5% and 25%+5%
  const f = RT.penaltyEstimate('fnpf', { amount: 1000, payDue: '2026-09-30', paid: false, today: '2026-10-05' });
  assert.strictEqual(f.total, 100);
});

// ---------------------------------------------------------------- FNPF
test('employer FNPF is 10% before 1 August 2026 and 8% from then (by pay day)', () => {
  const r = P.payRules();
  assert.strictEqual(P.employerPctOn(r, '2026-07-31'), 10);
  assert.strictEqual(P.employerPctOn(r, '2026-08-01'), 8);
  assert.strictEqual(RT.fnpfMandatoryEmployerPct('2026-09-05'), 8);
});
test('FNPF schedule: FNPF form columns, names split, family without FNPF left off, checks', () => {
  at('2026-09-01');
  P.savePayRules(owner, { ...P.payRules(), confirmed: true, needCheckedTimesheets: false });
  P.saveProfile(owner, { userUid: mere.uid, payType: 'salary', weeklySalary: 300, tin: '111222333', fnpfNo: 'FN-1001', taxStatus: 'resident', payMethod: 'cash' });
  P.saveProfile(owner, { userUid: sam.uid, payType: 'salary', weeklySalary: 250, tin: '', fnpfNo: '', taxStatus: 'resident', payMethod: 'cash' });
  P.saveProfile(owner, { userUid: fam.uid, payType: 'salary', weeklySalary: 200, tin: '444555666', fnpfNo: '', fnpfMember: false, taxStatus: 'resident', payMethod: 'cash' });
  for (const d of ['2026-09-05', '2026-09-12']) {
    at(d);
    const run = P.createRun(owner, d);
    P.finaliseRun(owner, run.uid);
  }
  at('2026-10-03');
  const s = RT.fnpfSchedule('2026-09');
  const names = s.rows.map((r) => `${r.first}|${r.middle}|${r.last}`).sort();
  assert.ok(names.includes('Mere|Losana|Tuilau'), names.join(','));
  assert.ok(!s.rows.some((r) => r.last === 'Prasad' && r.first === 'Ravin'), 'family member without FNPF is left off');
  const m = s.rows.find((r) => r.first === 'Mere');
  assert.ok(m.total > 0 && Math.abs(m.compulsory + m.employerAdditional + m.memberAdditional - m.total) < 0.01);
  assert.ok(Math.abs(m.employer - r2(m.gross * 0.08)) < 0.06, `employer ${m.employer} vs gross ${m.gross}`);
  assert.strictEqual(m.frequency, 1);
  assert.strictEqual(m.status, 1);
  assert.ok(s.checks.some((c) => /Sam Kumar: no FNPF member number/.test(c.text)));
  assert.ok(s.checks.some((c) => /employer FNPF reference/.test(c.text)));
  assert.strictEqual(s.csDue, '2026-10-14');
  assert.strictEqual(s.payDue, '2026-10-31');
  const t = RT.fnpfTable('2026-09');
  assert.strictEqual(t.headers.length, 14);
  assert.strictEqual(t.rows[0].length, 14);
});
test('FNPF cannot be lodged with missing numbers (owner can, with a reason); the calendar wants it by the 14th', () => {
  throws(() => RT.lodgeReturn(owner, 'fnpf', '2026-09', { ref: 'FNPF-1' }), /Fix these first/);
  let item = TX.getTaxItem('fnpf', '2026-09', '2026-10-15');
  assert.strictEqual(item.lodgeDue, '2026-10-14');
  assert.ok(item.flags.includes('overdue'), 'schedule late after the 14th');
  P.saveProfile(owner, { userUid: sam.uid, payType: 'salary', weeklySalary: 250, tin: '777888999', fnpfNo: 'FN-1002', taxStatus: 'resident', payMethod: 'cash' });
  FL.saveEmployerDetails(owner, { name: 'Easy Buys Shopping Centre', tin: '50-12345-0-1', fnpfNo: 'ER-9988', city: 'Lautoka' });
  const st = RT.lodgeReturn(owner, 'fnpf', '2026-09', { date: '2026-10-10', ref: 'FNPF-CS-77' });
  assert.ok(st.lodged && st.item.lodged);
  assert.strictEqual(RT.fnpfSchedule('2026-09').employer.refNo, 'ER-9988');
});
test('paying FNPF books it in Payroll (FNPF to pay) and the bank; the calendar item is complete with the proofs', () => {
  const owed = RT.returnStatus('fnpf', '2026-09').owed;
  const st = RT.payReturn(owner, 'fnpf', '2026-09', { date: '2026-10-28', via: `bank:${acct.uid}`, method: 'transfer', ref: 'BSP-FNPF-1', photos: ['file:///doc/p.jpg'], penalty: 5 });
  const pj = db().get('SELECT lines FROM gl_journals WHERE uid = ?', [st.file.penalty_link]);
  assert.ok(JSON.parse(pj.lines).some((l) => l.code === '6250' && l.debit === 5), 'penalty booked to 6250');
  const sp = db().get("SELECT * FROM stat_payments WHERE uid = 'STAT-fnpf-2026-09'");
  assert.strictEqual(sp.paid_amount, owed);
  assert.ok(db().get("SELECT 1 AS x FROM bank_entries WHERE uid = 'BE-STAT-STAT-fnpf-2026-09' AND status = 'active'"));
  const led = A.entries({ from: '2026-10-01', to: '2026-10-31' }).filter((e) => e.ref === 'STAT-fnpf-2026-09');
  assert.ok(led.length && led[0].lines.some((l) => l.code === '2100' && l.amount === owed));
  assert.ok(st.item.paid && st.item.lodged);
  assert.strictEqual(st.short, 0);
});
test('warnings: nothing urgent once September is lodged and paid', () => {
  at('2026-10-29');
  const list = RT.returnsAlerts(owner);
  assert.ok(!list.some((a) => /2026-09/.test(a.text) && /VAT/.test(a.text)), list.map((a) => a.text).join(' | '));
});
done();
