// Bundles one test file with esbuild and runs it in Node.
import { createRequire } from 'module';
import { execFileSync } from 'child_process';
let esbuild;
try { esbuild = createRequire('/opt/npm-tools/node_modules/')('esbuild'); } catch (e) { esbuild = createRequire(import.meta.url)('esbuild'); }
const file = process.argv[2];
const out = (process.env.RUNNER_TEMP || '/tmp/claude-0') + '/tests-out/' + file.replace(/[\/.]/g, '_') + '.mjs';
await esbuild.build({ entryPoints: [file], bundle: true, platform: 'node', format: 'esm', outfile: out, external: ['node:sqlite', 'react'],
  plugins: [{ name: 'phone-libs', setup(b) {
    const shim = new URL('./nodeShim.js', import.meta.url).pathname;
    b.onResolve({ filter: /^(expo-.*|react-native)$|^expo-file-system\/legacy$/ }, () => ({ path: shim }));
    b.onResolve({ filter: /^jszip$/ }, () => ({ path: new URL('./ui/shim/jszip.js', import.meta.url).pathname }));
  } }], logLevel: 'warning', loader: { '.png': 'empty' } });
try { execFileSync(process.execPath, ['--no-warnings', out], { stdio: 'inherit' }); } catch (e) { process.exit(1); }
