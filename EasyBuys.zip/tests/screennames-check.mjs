// A screen name used by two modules stops the app at start-up. Read every module's index.js and the bakery screen list.
import fs from 'fs';
import path from 'path';
const root = process.cwd();
const seen = {};
let bad = 0;
const add = (name, where) => { if (seen[name] && seen[name] !== where) { console.log(`DUPLICATE screen "${name}": ${seen[name]} and ${where}`); bad += 1; } seen[name] = where; };
for (const d of fs.readdirSync(path.join(root, 'src/modules'))) {
  const f = path.join(root, 'src/modules', d, 'index.js');
  if (!fs.existsSync(f)) continue;
  const src = fs.readFileSync(f, 'utf8');
  const block = src.slice(src.indexOf('screens:'));
  for (const m of block.matchAll(/(\w+): \{ component/g)) add(m[1], d);
}
const bk = path.join(root, 'src/modules/bakery/screens/index.js');
for (const m of fs.readFileSync(bk, 'utf8').matchAll(/^\s+(\w+): \[/gm)) if (!['Users', 'UserEdit'].includes(m[1])) add(m[1], 'bakery'); // those two are replaced by Staff
console.log(bad ? `screen names: ${bad} duplicate(s)` : `screen names: all ${Object.keys(seen).length} unique`);
process.exit(bad ? 1 : 0);
