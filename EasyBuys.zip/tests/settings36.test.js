// 3.6 – business settings changed on one device reach every device; device-only settings stay on the device.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { setDb, db } from '../src/db/connection.js';
import { getSetting, setSetting, getSettings, getShared, BUSINESS_SETTING_KEYS } from '../src/services/core.js';
import { pendingRecords, applyPulledRecords } from '../src/services/records.js';
import { test, done, assert } from './harness.js';

// Tablet A: an existing install with settings saved only on it, holding the cloud key (main tablet).
const A = openNodeDb();
setDb(A);
initDatabase(A);
A.run("DELETE FROM shared_settings WHERE key LIKE 'setting:%'");
A.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('business_settings_shared', '0'), ('cloud_key', 'k'), ('cloud_url', 'u'), ('idle_logout_min', '25'), ('bakery_name', 'Easy Buys Bakery Drasa')");
initDatabase(A); // next start: shares them once
const B = openNodeDb();
setDb(B); initDatabase(B);
B.run("INSERT OR REPLACE INTO settings (key, value) VALUES ('cloud_url', 'u'), ('idle_logout_min', '5')");
const send = (from, to) => { setDb(from); const recs = pendingRecords(1000); setDb(to); applyPulledRecords(recs); };

test('upgrade: the main tablet shares its business settings once; a linked phone does not overwrite them', () => {
  setDb(A);
  assert.strictEqual(getShared('setting:idle_logout_min'), '25');
  assert.strictEqual(getSettings().bakeryName, 'Easy Buys Bakery Drasa');
  setDb(B);
  B.run("UPDATE settings SET value = '0' WHERE key = 'business_settings_shared'");
  initDatabase(B);
  assert.strictEqual(getShared('setting:idle_logout_min', null), null, 'B is linked without the cloud key: it does not push its own');
});
test('sync: A\'s settings arrive on B and win over B\'s old local value', () => {
  send(A, B);
  setDb(B);
  assert.strictEqual(getSetting('idle_logout_min'), '25');
  assert.strictEqual(getSettings().idleLogoutMin, 25);
});
test('a change on B goes to A; device-only settings stay put', () => {
  setDb(B);
  setSetting('expiry_alert_days', '10');
  setSetting('keep_awake', '0');
  setSetting('device_shop', 'S2');
  send(B, A);
  setDb(A);
  assert.strictEqual(getSetting('expiry_alert_days'), '10');
  assert.notStrictEqual(getSetting('keep_awake'), '0', 'screen-awake is this device only');
  assert.notStrictEqual(getSetting('device_shop'), 'S2', "the tablet's shop is this device only");
});
test('every business setting key is shared; device keys are not', () => {
  for (const k of ['cloud_url', 'cloud_key', 'device_id', 'device_name', 'device_shop', 'keep_awake', 'ui_scale', 'sounds_device']) assert.ok(!BUSINESS_SETTING_KEYS.includes(k), k);
  for (const k of ['bakery_name', 'report_emails', 'po_emails', 'idle_logout_min', 'currency', 'flour_bands']) assert.ok(BUSINESS_SETTING_KEYS.includes(k), k);
});
done();
