// v3.5 app shell: warnings registry, module menus, health check, safety copies, sounds, sync light, search / scan,
// About lines, shops & cost areas, closed-shop costs in the profit & loss.
import { APP_VERSION } from '../src/services/core.js';
import fs from 'fs';
import path from 'path';
import { openNodeDb } from './nodeDb.js';
import { db } from '../src/db/connection.js';
import { startDatabases } from '../src/platform/training.js';
import { clock, getSetting, setSetting, stamp, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { setAlertSources, collectAlerts, homeAlerts, hideAlert, isHidden, sortAlerts, unhideAll } from '../src/services/alerts.js';
import { visibleMenu, checkMenu, MENU_SECTIONS, allMenuItems } from '../src/services/menus.js';
import { quickSteps, runHealthSteps, startQuickCheck, startFullCheck, fullCheckDue, latestHealth, healthIssues, adminPinOk, QUICK_BUDGET_MS, worst } from '../src/services/health.js';
import { snapshotName, parseSnapshotName, retention, setSnapshotFs, snapshotNow, listSnapshots, restoreSnapshot, restoreDamaged, snapshotDue, listOutsideCopies } from '../src/services/snapshots.js';
import { inQuietHours, shouldSound, newAlerts, processAlerts, saveSoundSettings, saveDeviceSoundSettings, soundSettings } from '../src/services/sounds.js';
import { syncLight, timeLabel } from '../src/services/syncInfo.js';
import { searchAll, resolveCode } from '../src/services/search.js';
import { copyrightYears, loginFooter, reportFooterLine, WHATS_NEW, OPEN_SOURCE, SUPPORT } from '../src/services/about.js';
import { reportToHtml } from '../src/services/export.js';
import { saveReportTemplate, reportTemplate } from '../src/services/reportTemplate.js';
import { listCostAreas, migrateShops35, areaFor, operatingShops, CLOSED, OFFICE } from '../src/services/costAreas.js';
import { listShops } from '../src/modules/admin/service.js';
import * as A from '../src/modules/accounting/service.js';
import * as F from '../src/modules/accounting/full.js';
import * as AP from '../src/modules/payables/service.js';
import { saveRecurring as saveApRecurring } from '../src/modules/payables/recurring.js';
import { setTrainingFlag } from '../src/services/trainingFlag.js';
import { MENU as PAY_MENU } from '../src/modules/payables/menu.js';
import { MENU as ACC_MENU } from '../src/modules/accounting/menu.js';
import { MENU as LEAVE_MENU } from '../src/modules/leave/menu.js';
import { MENU as ADMIN_MENU } from '../src/modules/admin/menu.js';
import { MENU as BAKERY_MENU } from '../src/modules/bakery/menu.js';
import { MENU as INV_MENU } from '../src/modules/inventory/menu.js';
import { MENU as TILL_MENU } from '../src/modules/till/menu.js';
import { MENU as PAYROLL_MENU } from '../src/modules/payroll/menu.js';
import { MENU as TS_MENU } from '../src/modules/timesheets/menu.js';
import { MENU as BANK_MENU } from '../src/modules/bank/menu.js';
import { MENU as STAFF_MENU } from '../src/modules/staff/menu.js';
import { MENU as PEOPLE_MENU } from '../src/modules/people/menu.js';
import { MENU as LIC_MENU } from '../src/modules/licences/menu.js';
import { MENU as VERIFY_MENU } from '../src/modules/verify/menu.js';
import { MENU as TC_MENU } from '../src/modules/timeclock/menu.js';
import { alerts as payAlerts } from '../src/modules/payables/alerts.js';
import { alerts as licAlerts } from '../src/modules/licences/alerts.js';
import { alerts as adminAlerts } from '../src/modules/admin/alerts.js';
import { alerts as tsAlerts } from '../src/modules/timesheets/alerts.js';
import { alerts as payrollAlerts } from '../src/modules/payroll/alerts.js';
import { alerts as invAlerts } from '../src/modules/inventory/alerts.js';
import { alerts as verifyAlerts } from '../src/modules/verify/alerts.js';
import { alerts as leaveAlerts } from '../src/modules/leave/alerts.js';
import { alerts as tillAlerts } from '../src/modules/till/alerts.js';
import { alerts as accAlerts } from '../src/modules/accounting/alerts.js';
import { alerts as syncAlerts } from '../src/modules/sync/alerts.js';
import { test, atest, done, assert, throws } from './harness.js';

const TMP = path.join(process.env.RUNNER_TEMP || process.env.EB_TMP || '/tmp/claude-0', 'shell35');
fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(TMP, { recursive: true });
const DB_FILE = path.join(TMP, 'real.db');
const opened = [];
const open = (name) => { const a = openNodeDb(name ? path.join(TMP, name) : DB_FILE); opened.push(a); return a; };
startDatabases(open);
const at = (s) => { clock.override = new Date(s.replace(' ', 'T')); };
at('2026-10-09 10:00:00');

// Files for the safety copies: plain folders in TMP (the tablet uses expo-file-system).
const nodeFs = {
  dir: () => path.join(TMP, 'snapshots') + '/',
  dbFile: () => DB_FILE,
  async ensureDir(d) { fs.mkdirSync(d, { recursive: true }); },
  async list(d) { try { return fs.readdirSync(d); } catch (e) { return []; } },
  async size(u) { try { return fs.statSync(u).size; } catch (e) { return null; } },
  async exists(u) { return fs.existsSync(u); },
  async copy(a, b) { fs.copyFileSync(a, b); },
  async remove(u) { try { fs.unlinkSync(u); } catch (e) { /* gone */ } },
};
const outDir = path.join(TMP, 'outside');
fs.mkdirSync(outDir, { recursive: true });
const outsideFs = {
  folder: () => getSetting('outside_folder_uri', ''),
  list: async () => fs.readdirSync(outDir).map((n) => ({ uri: path.join(outDir, n), name: n })),
  copyTo: async (local, name) => { fs.copyFileSync(local, path.join(outDir, name)); return path.join(outDir, name); },
  copyFrom: async (uri, local) => { fs.copyFileSync(uri, local); return local; },
  remove: async (uri) => fs.unlinkSync(uri),
};
setSnapshotFs(nodeFs, outsideFs);

const owner = saveUser({ name: 'Divnesh Owner', pin: '9999', role: 'owner', employeeNo: 'EB001', shopCode: 'S1' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', employeeNo: 'EB002', shopCode: 'S2' }, owner);
const staff = saveUser({ name: 'Mere Staff', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);

// ---------------------------------------------------------------- warnings registry
const src = (id, list) => ({ id, alerts: () => list });
test('warnings: most urgent first, module order kept within a level, bad entries dropped, permissions applied', () => {
  setAlertSources([
    src('a', [{ id: 'a1', level: 'info', text: 'A info', nav: { screen: 'X' } }, { id: 'a2', level: 'warning', text: 'A warn' }, { id: 'bad' }]),
    src('b', [{ id: 'b1', level: 'urgent', text: 'B urgent' }, { id: 'b2', level: 'warning', text: 'B warn', perm: 'payroll_setup' }]),
    { id: 'c', alerts: () => { throw new Error('module broke'); } },
    src('d', [{ id: 'd1', level: 'urgent', text: 'D urgent' }, { id: 'd2', level: 'nonsense', text: 'D other' }]),
  ]);
  const ids = collectAlerts(owner).map((a) => a.id);
  assert.deepStrictEqual(ids, ['b1', 'd1', 'a2', 'b2', 'a1', 'd2']);
  assert.ok(!collectAlerts(mgr).some((a) => a.id === 'b2'), 'manager may not see a payroll-setup warning');
  assert.strictEqual(collectAlerts(owner)[0].area, 'b', 'area defaults to the module');
  assert.deepStrictEqual(sortAlerts([{ level: 'info' }, { level: 'urgent' }]).map((a) => a.level), ['urgent', 'info']);
});
test('warnings: Home shows the 3 most urgent and "+ x more"', () => {
  const h = homeAlerts(owner);
  assert.deepStrictEqual(h.top.map((a) => a.id), ['b1', 'd1', 'a2']);
  assert.strictEqual(h.more, 3);
});
test('warnings: hide until tomorrow (warning / info only, per person), back the next day', () => {
  const all = collectAlerts(owner);
  throws(() => hideAlert(owner, all.find((a) => a.id === 'b1')), /cannot be hidden/);
  hideAlert(owner, all.find((a) => a.id === 'a2'));
  hideAlert(owner, all.find((a) => a.id === 'a1'));
  assert.ok(isHidden(owner, 'a2'));
  assert.ok(!collectAlerts(owner).some((a) => a.id === 'a2' || a.id === 'a1'));
  assert.ok(collectAlerts(mgr).some((a) => a.id === 'a2'), 'other people still see it');
  assert.strictEqual(collectAlerts(owner, { includeHidden: true }).length, 6);
  at('2026-10-10 07:00:00');
  assert.ok(collectAlerts(owner).some((a) => a.id === 'a2'), 'back the next day');
  at('2026-10-09 10:00:00');
  unhideAll(owner);
  assert.ok(collectAlerts(owner).some((a) => a.id === 'a1'));
});
test('warnings: every module provider returns valid warnings (the old Home banners)', () => {
  AP.saveSupplier(owner, { name: 'Punjas', tin: '50-12345-0-1', onAccount: true, termsDays: 7 });
  const sup = db().get("SELECT uid FROM ap_suppliers WHERE name = 'Punjas'");
  AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'P-100', invoiceDate: '2026-08-01', total: 112.5, shopCode: 'S1' });
  const providers = { payAlerts, licAlerts, adminAlerts, tsAlerts, payrollAlerts, invAlerts, verifyAlerts, leaveAlerts, tillAlerts, accAlerts, syncAlerts };
  for (const [n, fn] of Object.entries(providers)) {
    const list = fn(owner);
    assert.ok(Array.isArray(list), n);
    for (const a of list) {
      assert.ok(a.id && a.text, `${n}: id and text`);
      assert.ok(['urgent', 'warning', 'info'].includes(a.level), `${n}: level ${a.level}`);
      assert.ok(a.nav && typeof a.nav.screen === 'string', `${n}: ${a.id} taps through`);
    }
  }
  const over = payAlerts(owner).find((a) => a.id === 'ap-overdue');
  assert.ok(over && over.level === 'urgent' && /1 supplier invoice overdue/.test(over.text), JSON.stringify(payAlerts(owner)));
  assert.deepStrictEqual(over.nav, { screen: 'ApInvoices', params: { filter: 'overdue' } });
  assert.deepStrictEqual(payAlerts(staff), [], 'staff do not see supplier warnings');
  assert.ok(payrollAlerts(owner).some((a) => a.id === 'pay-rules'), 'payroll figures not checked yet');
});

// ---------------------------------------------------------------- module menus
const MENUS = { payables: PAY_MENU, accounting: ACC_MENU, leave: LEAVE_MENU, admin: ADMIN_MENU, bakery: BAKERY_MENU, inventory: INV_MENU, till: TILL_MENU, payroll: PAYROLL_MENU,
  timesheets: TS_MENU, bank: BANK_MENU, staff: STAFF_MENU, people: PEOPLE_MENU, licences: LIC_MENU, verify: VERIFY_MENU, timeclock: TC_MENU };
// Screen names, read from the modules' index.js (and the bakery screen list).
const root = process.cwd();
const screenNames = [];
for (const d of fs.readdirSync(path.join(root, 'src/modules'))) {
  const f = path.join(root, 'src/modules', d, 'index.js');
  if (fs.existsSync(f)) for (const m of fs.readFileSync(f, 'utf8').matchAll(/(\w+): \{ component/g)) screenNames.push(m[1]);
}
for (const m of fs.readFileSync(path.join(root, 'src/modules/bakery/screens/index.js'), 'utf8').matchAll(/^\s+(\w+): \[/gm)) screenNames.push(m[1]);
test('menus: every module menu uses the fixed sections in order, unique ids, existing screens', () => {
  assert.deepStrictEqual(MENU_SECTIONS, ['Daily tasks', 'Records', 'Checks', 'Reports', 'Settings']);
  for (const [id, menu] of Object.entries(MENUS)) {
    const problems = checkMenu({ id, menu }, screenNames);
    assert.deepStrictEqual(problems, [], problems.join('\n'));
    assert.ok(menu.some((s) => s.items.some((i) => i.id === 'home')), `${id} has its main item`);
  }
});
test('menus: hidden tabs are their own items (cheques, leave, bakery settings)', () => {
  const tabs = (menu, screen) => menu.flatMap((s) => s.items).filter((i) => i.screen === screen).map((i) => i.params && i.params.tab).filter(Boolean);
  assert.deepStrictEqual(tabs(PAY_MENU, 'Cheques').sort(), ['accounts', 'balance', 'books', 'money', 'register']);
  assert.deepStrictEqual(tabs(LEAVE_MENU, 'Leave').sort(), ['all', 'approve', 'ask', 'calendar', 'mine', 'setup']);
  assert.ok(tabs(BAKERY_MENU, 'Settings').includes('rules'));
});
test('menus: only what the person may open, sections in order', () => {
  const screens = { Payables: { can: () => true }, ApInvoiceEdit: { can: () => true }, ApPay: { can: (u) => u.role === 'owner' }, ApPayRun: { can: () => false }, ApRules: { can: (u) => u.role === 'owner' }, ApInvoices: { can: () => true }, ReportsHub: { can: () => true } };
  const mod = { id: 'payables', title: 'Invoices & cheques', menu: PAY_MENU };
  const forOwner = visibleMenu(mod, owner, screens);
  assert.deepStrictEqual(forOwner.map((s) => s.section), ['Daily tasks', 'Records', 'Checks', 'Reports', 'Settings']);
  assert.ok(forOwner[0].items.some((i) => i.id === 'ap-pay'));
  const forMgr = visibleMenu(mod, mgr, screens);
  assert.ok(!forMgr.flatMap((s) => s.items).some((i) => i.id === 'ap-pay' || i.id === 'ap-rules'));
  assert.ok(!forMgr.some((s) => s.section === 'Settings'), 'empty sections are left out');
  const bk = visibleMenu({ id: 'bakery', menu: BAKERY_MENU }, owner, null);
  assert.strictEqual(bk[0].items[0].screen, 'AdminHome', 'bakery home follows the bakery role');
  assert.ok(allMenuItems([mod], owner, screens).every((i) => i.moduleTitle === 'Invoices & cheques' && i.section));
});

// ---------------------------------------------------------------- search and scan
test('search: screens, suppliers, invoices, people; only what the person may open', () => {
  const screens = { ApSupplierEdit: { can: () => true }, ApInvoice: { can: () => true }, UserEdit: { can: (u) => u.role === 'owner' }, ApInvoices: { can: () => true }, Payables: { can: () => true } };
  const mods = [{ id: 'payables', title: 'Invoices & cheques', menu: PAY_MENU }];
  const r = searchAll(owner, 'punjas', { modules: mods, screens });
  assert.ok(r.some((x) => x.kind === 'supplier' && x.title === 'Punjas'));
  assert.ok(r.some((x) => x.kind === 'invoice' && /P-100/.test(x.title)));
  assert.ok(searchAll(owner, 'P-100', { modules: mods, screens }).some((x) => x.kind === 'invoice'));
  assert.ok(searchAll(owner, 'all invoices', { modules: mods, screens }).some((x) => x.kind === 'screen' && x.nav.screen === 'ApInvoices'));
  assert.ok(searchAll(owner, 'Mere', { modules: mods, screens }).some((x) => x.kind === 'person'));
  assert.ok(!searchAll(mgr, 'Mere', { modules: mods, screens }).some((x) => x.kind === 'person'), 'no staff records for a manager here');
  assert.deepStrictEqual(searchAll(owner, 'x', { modules: mods, screens }), [], 'needs 2 letters');
});
test('scan: document numbers and EB codes open the record; product barcodes show the product; not found explained', () => {
  const inv = db().get("SELECT uid FROM ap_invoices WHERE invoice_no = 'P-100'");
  const screens = { ApInvoice: { can: (u) => u.role === 'owner' }, InvProduct: { can: () => true } };
  const r = resolveCode(owner, 'P-100', { screens });
  assert.ok(r.found && r.allowed && r.nav.screen === 'ApInvoice' && r.nav.params.uid === inv.uid);
  assert.strictEqual(resolveCode(mgr, 'P-100', { screens }).allowed, false, 'found but not allowed');
  assert.strictEqual(resolveCode(owner, `EB:inv:${inv.uid}`, { screens }).nav.params.uid, inv.uid);
  db().run("INSERT INTO inv_items (uid, code, barcode, name, price, updated_at) VALUES ('IT1', 'P001', '9415007012345', 'Rewa Milk 1L', 3.2, ?)", [stamp()]);
  const p = resolveCode(owner, '9415007012345', { screens });
  assert.strictEqual(p.kind, 'product'); assert.strictEqual(p.product.name, 'Rewa Milk 1L');
  assert.match(resolveCode(owner, '9999999999999', { screens }).message, /Add it in Aronium first/);
  assert.match(resolveCode(owner, 'EB:inv:nope', { screens }).message, /not in the app/);
});

// ---------------------------------------------------------------- sounds
test('sounds: quiet hours wrap past midnight; bakery always sounds; device switch; urgent in quiet hours', () => {
  const d = (h, m = 0) => new Date(2026, 9, 9, h, m);
  assert.ok(inQuietHours(d(22), '21:00', '06:00') && inQuietHours(d(5, 59), '21:00', '06:00') && !inQuietHours(d(6), '21:00', '06:00') && !inQuietHours(d(12), '21:00', '06:00'));
  assert.ok(inQuietHours(d(13), '12:00', '14:00') && !inQuietHours(d(15), '12:00', '14:00'));
  const shared = { ...soundSettings(), quietOn: true, quietFrom: '21:00', quietTo: '06:00', urgentInQuiet: false };
  const device = { on: true, urgent: true, warning: true, info: true };
  assert.ok(!shouldSound({ level: 'warning', area: 'payables' }, { now: d(23), shared, device }));
  assert.ok(shouldSound({ level: 'warning', area: 'bakery' }, { now: d(23), shared, device }), 'bakery is exempt');
  assert.ok(!shouldSound({ level: 'urgent', area: 'payables' }, { now: d(23), shared, device }));
  assert.ok(shouldSound({ level: 'urgent', area: 'payables' }, { now: d(23), shared: { ...shared, urgentInQuiet: true }, device }));
  assert.ok(shouldSound({ level: 'info', area: 'x' }, { now: d(12), shared, device }));
  assert.ok(!shouldSound({ level: 'info', area: 'x' }, { now: d(12), shared: { ...shared, info: false }, device }));
  assert.ok(!shouldSound({ level: 'urgent', area: 'x' }, { now: d(12), shared, device: { ...device, on: false } }), 'device off');
});
test('sounds: a sound only for new warnings (the loudest one), urgent ones notified once', () => {
  saveSoundSettings(owner, { urgent: true, warning: true, info: true, quietOn: false });
  saveDeviceSoundSettings({ on: true });
  const played = []; const notified = [];
  const go = (list) => processAlerts(mgr, list, { play: (lv, o) => played.push([lv, !!o.loop]), notify: (a) => notified.push(a.id), now: new Date(2026, 9, 9, 12) });
  const w = { id: 'w1', level: 'warning', text: 'W' }; const u = { id: 'u1', level: 'urgent', text: 'U' }; const i = { id: 'i1', level: 'info', text: 'I' };
  let r = go([w, i]);
  assert.deepStrictEqual(played, [['warning', false]]); assert.strictEqual(r.fresh.length, 2);
  r = go([w, i]);
  assert.strictEqual(played.length, 1, 'same warnings: no sound again'); assert.strictEqual(r.fresh.length, 0);
  r = go([w, i, u]);
  assert.deepStrictEqual(played[1], ['urgent', true], 'urgent loops until OK');
  assert.deepStrictEqual(notified, ['u1']); assert.deepStrictEqual(r.urgent.map((a) => a.id), ['u1']);
  go([i]); go([w, i]);
  assert.deepStrictEqual(played[2], ['warning', false], 'a warning that went away and came back sounds again');
  assert.strictEqual(newAlerts(mgr, [w, i]).length, 0);
});

// ---------------------------------------------------------------- sync light
test('sync light: green / amber / red / grey with the right words', () => {
  const now = new Date(2026, 9, 9, 15, 50);
  assert.strictEqual(timeLabel('2026-10-09 15:45:10'), '3:45 pm');
  assert.strictEqual(timeLabel('2026-10-09 00:05:00'), '12:05 am');
  assert.deepStrictEqual([syncLight({ linked: true, waiting: 0, lastOk: '2026-10-09 15:45:00', now }).color, syncLight({ linked: true, waiting: 0, lastOk: '2026-10-09 15:45:00', now }).text], ['green', '✓ All synced 3:45 pm']);
  assert.strictEqual(syncLight({ linked: true, waiting: 14, lastOk: '2026-10-09 15:45:00', now }).color, 'amber');
  assert.strictEqual(syncLight({ linked: true, running: true, progress: 'Sending 14 items…', now }).text, 'Sending 14 items…');
  const off = syncLight({ linked: true, error: 'Network request failed', waiting: 14, now });
  assert.deepStrictEqual([off.color, off.text, off.retry], ['red', '✗ No internet – 14 items waiting', true]);
  assert.strictEqual(syncLight({ linked: true, waiting: 3, lastOk: '2026-10-07 10:00:00', now }).color, 'red', 'waiting too long');
  assert.match(syncLight({ linked: true, error: 'The cloud refused', waiting: 1, now }).text, /Sync problem – 1 item waiting/);
  assert.strictEqual(syncLight({ linked: true, training: true, now }).color, 'grey');
  assert.strictEqual(syncLight({ linked: false, now }).canSync, false);
});

// ---------------------------------------------------------------- health check
test('health: quick check on a good database is all fine and is kept in health_checks', async () => {});
await (async () => {
  const run = startQuickCheck({ freeDisk: async () => 8e9, now: () => new Date(2026, 9, 9, 10) });
  const st = await run.first;
  await run.all;
  test('health: quick check on a good database is fine and stored', () => {
    assert.strictEqual(QUICK_BUDGET_MS, 4000);
    assert.strictEqual(st.done, true); assert.strictEqual(st.timedOut, false);
    assert.deepStrictEqual(st.results.map((r) => r.id), ['db', 'tables', 'settings', 'clock', 'storage', 'copies', 'lastClose', 'sync']);
    assert.strictEqual(st.status, 'ok', JSON.stringify(st.results.filter((r) => r.status !== 'ok')));
    const h = latestHealth('quick');
    assert.ok(h && h.status === 'ok' && h.results.length === 8);
    assert.ok(getSetting('last_health_at', ''));
  });
})();
await atest('health: 4-second limit – the app opens and the rest finishes in the background', async () => {
  let slowDone = false;
  const steps = [
    { id: 'fast', label: 'Fast', run: () => ({ status: 'ok', text: 'ok' }) },
    { id: 'slow', label: 'Slow', run: () => new Promise((r) => setTimeout(() => { slowDone = true; r({ status: 'minor', text: 'slow but done' }); }, 120)) },
    { id: 'last', label: 'Last', run: () => ({ status: 'ok', text: 'ok' }) },
  ];
  const t0 = Date.now();
  const run = runHealthSteps(steps, { budgetMs: 40, store: false });
  const first = await run.first;
  assert.ok(Date.now() - t0 < 110, 'opens at the limit');
  assert.strictEqual(first.timedOut, true); assert.strictEqual(slowDone, false);
  assert.deepStrictEqual(first.results.map((r) => r.id), ['fast']);
  const all = await run.all;
  assert.strictEqual(all.done, true); assert.deepStrictEqual(all.results.map((r) => r.id), ['fast', 'slow', 'last']);
  assert.strictEqual(all.status, 'minor');
});
await atest('health: damage, clock going back, low storage and a crash last time are found', async () => {
  setSetting('last_known_time', '2026-10-09 12:00:00');
  const env = { freeDisk: async () => 50e6, lastClose: { where: 'PayRun' }, now: () => new Date(2026, 9, 9, 9, 0) };
  const st = await startQuickCheck(env, { store: false }).all;
  const by = Object.fromEntries(st.results.map((r) => [r.id, r]));
  assert.strictEqual(by.clock.status, 'minor'); assert.match(by.clock.text, /earlier than the last time/);
  assert.strictEqual(by.storage.status, 'minor'); assert.match(by.storage.text, /almost full/);
  assert.strictEqual(by.lastClose.status, 'minor'); assert.deepStrictEqual(by.lastClose.nav, { screen: 'Problems', params: {} });
  assert.strictEqual(getSetting('last_known_time'), '2026-10-09 12:00:00', 'a clock going back does not move the last known time');
  const bad = [{ id: 'db', label: 'Database opens', critical: true, run: () => { throw new Error('file is not a database'); } }];
  const d = await runHealthSteps(bad, { store: false }).all;
  assert.strictEqual(d.status, 'damaged');
  assert.strictEqual(worst([{ status: 'ok' }, { status: 'minor' }, { status: 'info' }]), 'minor');
  setSetting('last_known_time', '');
});
await atest('health: full check (integrity, books balance, files, outbox); results become Home warnings', async () => {
  const st = await startFullCheck({ exists: async () => true }).all;
  assert.deepStrictEqual(st.results.map((r) => r.id), ['integrity', 'books', 'files', 'outbox', 'history']);
  assert.strictEqual(st.results[0].status, 'ok');
  assert.strictEqual(st.results[1].status, 'ok', st.results[1].text);
  db().run("INSERT INTO outbox (kind, payload, created_at, attempts) VALUES ('email', '{}', ?, 5)", [stamp()]);
  const st2 = await startFullCheck({ exists: async () => true }).all;
  assert.strictEqual(st2.results.find((r) => r.id === 'outbox').status, 'minor');
  assert.ok(healthIssues().some((h) => h.id === 'outbox' && h.kind === 'full'));
  assert.ok(adminAlerts(owner).some((a) => a.id === 'health-full-outbox' && a.level === 'warning' && a.nav.screen === 'SyncStatus'));
  assert.ok(adminAlerts(staff).length === 0 || adminAlerts(staff).every((a) => a.nav.screen === 'SyncStatus'));
  db().run("DELETE FROM outbox WHERE kind = 'email'");
});
test('health: the full check runs once a night when the tablet is idle', () => {
  setSetting('last_full_health_at', '2026-10-08 23:00:00');
  assert.ok(!fullCheckDue({ idleMinutes: 30, now: new Date(2026, 9, 9, 10) }), 'checked last night');
  assert.ok(fullCheckDue({ idleMinutes: 30, now: new Date(2026, 9, 9, 23) }), 'next night, idle');
  assert.ok(!fullCheckDue({ idleMinutes: 1, now: new Date(2026, 9, 9, 23) }), 'in use');
  assert.ok(fullCheckDue({ idleMinutes: 10, now: new Date(2026, 9, 11, 14) }), 'over two days: any idle time');
});
test('health: owner / admin PIN check', () => {
  assert.strictEqual(adminPinOk('9999'), true);
  assert.strictEqual(adminPinOk('8888'), false);
  assert.strictEqual(adminPinOk(''), false);
  assert.strictEqual(adminPinOk('9999', { get() { throw new Error('damaged'); } }), null, 'unreadable logins');
});

// ---------------------------------------------------------------- safety copies
test('copies: names hold the time and reason', () => {
  const n = snapshotName('year close', new Date(2026, 9, 9, 15, 30, 5));
  assert.strictEqual(n, 'eb-20261009-153005-year-close.db');
  assert.deepStrictEqual(parseSnapshotName(n), { name: n, at: '2026-10-09 15:30:05', reason: 'year-close', label: 'Before closing a year' });
  assert.strictEqual(parseSnapshotName('other.db'), null);
});
test('copies: keep the last 7 days, then one a week for a month, the newest always', () => {
  const names = [];
  for (let d = 0; d < 45; d++) for (const h of [9, 15]) { const x = new Date(2026, 9, 9 - d, h, 0, 0); names.push(snapshotName('auto', x)); }
  const { keep, drop } = retention(names, new Date(2026, 9, 9, 16));
  const ages = keep.map((n) => (new Date(2026, 9, 9, 16) - new Date(parseSnapshotName(n).at.replace(' ', 'T'))) / 86400000);
  assert.strictEqual(keep.filter((n, i) => ages[i] <= 7).length, 14, 'everything from the last 7 days');
  const older = ages.filter((a) => a > 7);
  assert.ok(older.length >= 3 && older.length <= 4, `one per week: ${older.length}`);
  assert.ok(older.every((a) => a <= 31));
  assert.strictEqual(keep.length + drop.length, names.length);
  assert.deepStrictEqual(retention([names[89]], new Date(2027, 0, 1)).keep, [names[89]], 'the only copy is kept');
});
await atest('copies: a real copy is made (VACUUM INTO), listed, tidied, and the daily outside copy made once', async () => {
  setSetting('outside_folder_uri', 'saf://Documents/Easy Buys Backups');
  const r = await snapshotNow('manual');
  assert.ok(r.ok, r.error); assert.ok(r.size > 0);
  assert.ok(fs.existsSync(r.uri));
  const copy = openNodeDb(r.uri);
  assert.ok(copy.get("SELECT 1 AS x FROM users WHERE pin = '9999'"), 'the copy holds the data');
  copy.close();
  assert.ok(r.outside, 'daily outside copy');
  const r2 = await snapshotNow('auto');
  assert.ok(!r2.outside, 'outside copy only once a day');
  const list = await listSnapshots();
  assert.ok(list.length >= 2 && list[0].at >= list[1].at);
  assert.strictEqual((await listOutsideCopies()).length, 1);
  assert.ok(!snapshotDue(getSetting('last_snapshot_at'), new Date(2026, 9, 9, 11)));
  assert.ok(snapshotDue(getSetting('last_snapshot_at'), new Date(2026, 9, 9, 15)), 'after 4 hours');
  setTrainingFlag(true);
  assert.strictEqual((await snapshotNow('auto')).skipped, 'training', 'training data is never copied');
  setTrainingFlag(false);
});
await atest('copies: restore puts the data back, after a safety copy (owner / admin only)', async () => {
  at('2026-10-09 11:00:00');
  const snap = (await snapshotNow('manual', { outside: false }));
  at('2026-10-09 11:05:00');
  saveUser({ name: 'After The Copy', pin: '1212', role: 'staff', employeeNo: 'EB099' }, owner);
  assert.ok(db().get("SELECT 1 AS x FROM users WHERE pin = '1212'"));
  await assert.rejects(restoreSnapshot(mgr, { ...parseSnapshotName(snap.name), uri: snap.uri }), /Only the owner or an admin/);
  at('2026-10-09 11:10:00');
  const r = await restoreSnapshot(owner, { ...parseSnapshotName(snap.name), uri: snap.uri, where: 'tablet' });
  assert.ok(r.ok);
  assert.ok(!db().get("SELECT 1 AS x FROM users WHERE pin = '1212'"), 'back as it was');
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action = 'Restored a safety copy of the data'"));
  const safety = openNodeDb(r.safety.uri);
  assert.ok(safety.get("SELECT 1 AS x FROM users WHERE pin = '1212'"), 'the safety copy has what was there before');
  safety.close();
  assert.ok((await listSnapshots()).some((s) => s.reason === 'before-restore'));
});
await atest('copies: restore from the damaged screen checks the PIN (on the copy when the data cannot be read)', async () => {
  at('2026-10-09 11:20:00');
  const snap = await snapshotNow('manual', { outside: false });
  const s = { ...parseSnapshotName(snap.name), uri: snap.uri, where: 'tablet' };
  await assert.rejects(restoreDamaged(s, '8888'), /not an owner or admin PIN/);
  // Logins unreadable now: the PIN is checked on the restored copy; a wrong one puts the damaged file back.
  let calls = 0;
  const unreadableThenReal = (p) => (calls++ === 0 ? null : adminPinOk(p));
  saveUser({ name: 'Marker Person', pin: '3434', role: 'staff', employeeNo: 'EB098' }, owner);
  await assert.rejects(restoreDamaged(s, '4321', { pinOk: unreadableThenReal }), /Nothing was changed/);
  assert.ok(db().get("SELECT 1 AS x FROM users WHERE pin = '3434'"), 'damaged data put back');
  calls = 0;
  const r = await restoreDamaged(s, '9999', { pinOk: unreadableThenReal });
  assert.ok(r.ok && fs.existsSync(r.damagedKept));
  assert.ok(!db().get("SELECT 1 AS x FROM users WHERE pin = '3434'"), 'copy restored');
});

// ---------------------------------------------------------------- shops and cost areas
test('shops: S2 is Tukani Street, the third shop is not operating; cost areas', () => {
  assert.strictEqual(db().get("SELECT name FROM shops WHERE code = 'S2'").name, 'Shop 2 - Tukani Street');
  assert.ok(!listShops().some((s) => s.code === 'S3'), 'not in shop pickers');
  assert.deepStrictEqual(operatingShops().map((s) => s.code), ['S1', 'S2']);
  assert.deepStrictEqual(listCostAreas().map((a) => [a.code, a.name]), [['S1', 'Shop 1 - Drasa Avenue'], ['S2', 'Shop 2 - Tukani Street'], ['OFFICE', 'Office / whole business'], ['CLOSED', 'Closed shop – V M Pillay']]);
  assert.strictEqual(areaFor('S3'), CLOSED); assert.strictEqual(areaFor(''), OFFICE); assert.strictEqual(areaFor('S2'), 'S2');
});
test('shops: an old database is moved over safely and only once (names, third shop, regular bills, footer)', () => {
  db().run("UPDATE shops SET name = 'Shop 2 - V M Pillay' WHERE code = 'S2'");
  db().run("UPDATE shops SET active = 1, name = 'Shop 3 - Kiran Palace' WHERE code = 'S3'");
  setSetting('shops35_s3_closed', '');
  const sup = db().get("SELECT uid FROM ap_suppliers WHERE name = 'Punjas'").uid;
  saveApRecurring(owner, { kind: 'bill', name: 'Rent – V M Pillay shop', supplierUid: sup, amount: 1500, frequency: 'monthly', nextDate: '2026-11-01', shopCode: 'S2' });
  saveApRecurring(owner, { kind: 'bill', name: 'Rent - Kiran Palace', supplierUid: sup, amount: 1800, frequency: 'monthly', nextDate: '2026-11-01', shopCode: 'S3' });
  saveApRecurring(owner, { kind: 'bill', name: 'Power Shop 1', supplierUid: sup, amount: 300, frequency: 'monthly', nextDate: '2026-11-01', shopCode: 'S1' });
  setShared('report_template', { ...reportTemplate(), footer: 'Easy Buys Shopping Center · Shop 1: Drasa Avenue · Shop 2: V M Pillay, Riffle Range · Shop 3: Kiran Palace · Lautoka, Fiji' });
  const moved = migrateShops35();
  const shopOf = (n) => db().get('SELECT shop_code FROM ap_recurring WHERE name = ?', [n]).shop_code;
  assert.strictEqual(shopOf('Rent – V M Pillay shop'), CLOSED);
  assert.strictEqual(shopOf('Rent - Kiran Palace'), 'S2');
  assert.strictEqual(shopOf('Power Shop 1'), 'S1');
  assert.strictEqual(db().get("SELECT name FROM shops WHERE code = 'S2'").name, 'Shop 2 - Tukani Street');
  assert.strictEqual(db().get("SELECT active FROM shops WHERE code = 'S3'").active, 0);
  assert.match(reportTemplate().footer, /Tukani Street/);
  assert.ok(moved.length >= 5, JSON.stringify(moved));
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'v3.5 shops and cost areas%'"), 'what moved is logged');
  assert.deepStrictEqual(migrateShops35(), [], 'second run changes nothing');
  db().run("UPDATE shops SET active = 1 WHERE code = 'S3'");
  assert.deepStrictEqual(migrateShops35(), [], 'an admin who opens the third shop again is not overruled');
  db().run("UPDATE shops SET active = 0 WHERE code = 'S3'");
});
test('closed shop costs: their own column, never in S1 / S2, included in the whole-business total', () => {
  const exp = A.listAccountsGL().find((a) => a.type === 'expense' && /^6\d{3}$/.test(a.code));
  F.saveSale(owner, { date: '2026-10-05', shop: 'S1', total: 1125, via: 'cash:S1' });
  F.saveExpense(owner, { date: '2026-10-05', shop: CLOSED, account: exp.code, total: 500, claimVat: false, via: 'owner', note: 'V M Pillay rent' });
  F.saveExpense(owner, { date: '2026-10-05', shop: 'S2', account: exp.code, total: 200, claimVat: false, via: 'owner' });
  const pl = A.profitLoss({ from: '2026-10-01', to: '2026-10-31', shops: ['S1', 'S2'] });
  assert.ok(pl.cols.includes(CLOSED));
  assert.strictEqual(pl.per[CLOSED].expenses, 500);
  assert.strictEqual(pl.per.S1.expenses, 0); assert.strictEqual(pl.per.S2.expenses, 200);
  assert.strictEqual(pl.per.total.expenses, 700, 'whole business includes the closed shop');
  assert.strictEqual(pl.per.total.profit, Math.round((pl.per.S1.profit + pl.per.S2.profit + pl.per[CLOSED].profit + pl.per[OFFICE].profit) * 100) / 100);
  assert.strictEqual(A.areaLabel(CLOSED), 'Closed shop costs');
  assert.strictEqual(A.areaLabel('S3'), 'S3');
});

// ---------------------------------------------------------------- About and footers
test('about: version lines, copyright years, support, what is new, open-source list', () => {
  assert.strictEqual(copyrightYears(new Date(2026, 5, 1)), '2026');
  assert.strictEqual(copyrightYears(new Date(2028, 0, 1)), '2026–2028');
  assert.strictEqual(loginFooter(new Date(2026, 5, 1)), `Easy Buys v${APP_VERSION} · © 2026 Easy Buys Shopping Centre`);
  assert.strictEqual(reportFooterLine(), `Generated by Easy Buys app v${APP_VERSION} · © Easy Buys Shopping Centre`);
  assert.strictEqual(SUPPORT.email, 'prasaddiptesh@gmail.com');
  assert.strictEqual(WHATS_NEW[0].version, APP_VERSION);
  assert.ok(OPEN_SOURCE.every((o) => o.name && o.licence));
});
test('reports: the "Generated by Easy Buys app" line on every PDF, and the admin can turn it off', () => {
  const rep = { kind: 'x', title: 'Test', fileName: 't', sections: [] };
  assert.ok(reportToHtml(rep).includes(`Generated by Easy Buys app v${APP_VERSION}`));
  saveReportTemplate(owner, { ...reportTemplate(), showAppFooter: false });
  assert.ok(!reportToHtml(rep).includes('Generated by Easy Buys app'));
  saveReportTemplate(owner, { ...reportTemplate(), showAppFooter: true });
});

done();
