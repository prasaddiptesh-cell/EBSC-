// 3.6 nicer sounds: a tone and volume per level for every device, each device may choose its own.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { saveUser } from '../src/services/catalog.js';
import * as S from '../src/services/sounds.js';
import fs from 'fs';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
test('defaults: soft bell for urgent and warning, marimba for information; volumes high / medium / low', () => {
  assert.deepStrictEqual(S.toneFor('urgent'), { tone: 'bell', volume: 1, vol: 'high' });
  assert.strictEqual(S.toneFor('info').tone, 'marimba');
  assert.strictEqual(S.toneFor('warning').volume, 0.7);
});
test('admin choice for every device; this device can choose its own; bad values ignored', () => {
  S.saveSoundSettings(owner, { ...S.soundSettings(), toneInfo: 'glass', volInfo: 'medium', toneUrgent: 'nonsense' });
  assert.strictEqual(S.toneFor('info').tone, 'glass');
  assert.strictEqual(S.toneFor('urgent').tone, 'bell', 'unknown tone falls back');
  S.saveDeviceSoundSettings({ ...S.deviceSoundSettings(), toneInfo: 'phone', volWarning: 'low' });
  assert.strictEqual(S.toneFor('info').tone, 'phone');
  assert.strictEqual(S.toneFor('warning').volume, 0.4);
  S.saveDeviceSoundSettings({ ...S.deviceSoundSettings(), toneInfo: '' });
  assert.strictEqual(S.toneFor('info').tone, 'glass', 'empty = same as every device');
});
test('every tone has its sound file for every level, and they are small', () => {
  for (const level of ['info', 'warning', 'urgent']) for (const t of Object.keys(S.TONES).filter((x) => x !== 'phone')) {
    const f = `assets/sounds/${level}_${t}.mp3`;
    assert.ok(fs.existsSync(f), f);
    assert.ok(fs.statSync(f).size < 60000, `${f} ${fs.statSync(f).size}`);
  }
});
done();
