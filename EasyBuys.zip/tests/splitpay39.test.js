// v3.9: cheque numbers from the cheque books (drop-down), split supplier payments (cash + cheque + transfer), and
// paying the VAT return / FNPF schedule by cheque through the cheque register (no second bank line).
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as CB from '../src/modules/payables/chequebooks.js';
import * as F from '../src/modules/accounting/full.js';
import * as RT from '../src/modules/payroll/returns.js';
import * as V from '../src/modules/verify/service.js';
import { alerts as apAlertsFor } from '../src/modules/payables/alerts.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-20T10:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const acct = AP.saveAccount(owner, { name: 'BSP Business', openingBalance: 20000, openingDate: '2026-09-01' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 500, lastNo: 509 });
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const inv = (no, total) => { const i = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: no, invoiceDate: '2026-10-10', total, shopCode: 'S1' }); try { AP.checkInvoice(owner, i.uid); } catch (e) { /* ok */ } return i; };

test('the cheque drop-down lists the unused leaves, next one first-marked', () => {
  const list = CB.availableCheques(acct.uid);
  assert.strictEqual(list.length, 10);
  assert.ok(list.find((c) => c.no === 500).next);
});
test('split payment: cash + cheque + transfer for two invoices – three payments, invoices fully paid, cheque in the register', () => {
  const a = inv('S-1', 1000);
  const b = inv('S-2', 500);
  throws(() => AP.makeSplitPayment(owner, { supplierUid: sup.uid, payDate: '2026-10-20', allocations: [{ invoiceUid: a.uid, amount: 1000 }, { invoiceUid: b.uid, amount: 500 }],
    parts: [{ method: 'cash', amount: 200, shopCode: 'S1' }, { method: 'cheque', amount: 1000, accountUid: acct.uid, chequeNo: 500 }] }), /add up to/);
  throws(() => AP.makeSplitPayment(owner, { supplierUid: sup.uid, payDate: '2026-10-20', allocations: [{ invoiceUid: a.uid, amount: 1500 }],
    parts: [{ method: 'cash', amount: 1500, shopCode: 'S1' }] }), /at least two parts/);
  const list = AP.makeSplitPayment(owner, { supplierUid: sup.uid, payDate: '2026-10-20', allocations: [{ invoiceUid: a.uid, amount: 1000 }, { invoiceUid: b.uid, amount: 500 }],
    parts: [{ method: 'cash', amount: 300, shopCode: 'S1', receivedBy: 'Rep' }, { method: 'cheque', amount: 900, accountUid: acct.uid, chequeNo: 500 }, { method: 'transfer', amount: 300, accountUid: acct.uid, reference: 'TT-1' }] });
  assert.strictEqual(list.length, 3);
  assert.deepStrictEqual(list.map((p) => p.method), ['cash', 'cheque', 'transfer']);
  assert.strictEqual(AP.getInvoice(a.uid).owing, 0);
  assert.strictEqual(AP.getInvoice(b.uid).owing, 0);
  const c = db().get('SELECT * FROM cheques WHERE account_uid = ? AND cheque_no = 500', [acct.uid]);
  assert.strictEqual(c.amount, 900);
  assert.ok(!CB.availableCheques(acct.uid).some((x) => x.no === 500));
  assert.ok(list.every((p) => /Split payment \d of 3/.test(p.notes)));
});
test('a split that fails half way saves nothing (cheque already used)', () => {
  const c2 = inv('S-3', 400);
  const before = db().get('SELECT COUNT(*) AS n FROM ap_payments').n;
  throws(() => AP.makeSplitPayment(owner, { supplierUid: sup.uid, payDate: '2026-10-20', allocations: [{ invoiceUid: c2.uid, amount: 400 }],
    parts: [{ method: 'cash', amount: 100, shopCode: 'S1' }, { method: 'cheque', amount: 300, accountUid: acct.uid, chequeNo: 500 }] }), /already used/);
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM ap_payments').n, before);
  assert.strictEqual(AP.getInvoice(c2.uid).owing, 400);
});
test('VAT paid by cheque: cheque leaf written to FRCS, journal booked, no extra bank line; taking it back voids the leaf', () => {
  F.saveSale(owner, { date: '2026-09-05', shop: 'S1', total: 1125, zero: 0, vat: 125, via: 'cash:S1' });
  RT.lodgeReturn(owner, 'vat', '2026-09', { date: '2026-10-15', ref: 'TPOS-1' });
  throws(() => RT.payReturn(owner, 'vat', '2026-09', { via: `bank:${acct.uid}`, method: 'cheque', chequeNo: '999' }), /not in any cheque book/);
  throws(() => RT.payReturn(owner, 'vat', '2026-09', { via: `bank:${acct.uid}`, method: 'cheque', chequeNo: '500' }), /already used/);
  const st = RT.payReturn(owner, 'vat', '2026-09', { date: '2026-10-20', via: `bank:${acct.uid}`, method: 'cheque', chequeNo: '501' });
  const c = db().get('SELECT * FROM cheques WHERE uid = ?', [st.file.cheque_uid]);
  assert.strictEqual(c.cheque_no, 501);
  assert.strictEqual(c.payee, 'FRCS (VAT)');
  assert.strictEqual(c.amount, 125);
  assert.ok(!db().get("SELECT 1 AS x FROM bank_entries WHERE uid LIKE ? AND status = 'active'", [`BE-JN-${st.file.pay_link}%`]), 'no second bank line');
  assert.strictEqual(st.file.pay_ref, 'Cheque 501');
  RT.undoReturnPayment(owner, 'vat', '2026-09', 'Cheque spoilt');
  assert.strictEqual(db().get('SELECT status FROM cheques WHERE uid = ?', [c.uid]).status, 'void');
  assert.ok(!CB.availableCheques(acct.uid).some((x) => x.no === 501), 'a written leaf is never offered again');
});
test('part payment is allowed but marked on the payment, listed as "Part paid" and warned about', () => {
  const i = inv('S-9', 800);
  const p = AP.makePayment(owner, { supplierUid: sup.uid, method: 'cash', shopCode: 'S1', receivedBy: 'Rep', payDate: '2026-10-20', allocations: [{ invoiceUid: i.uid, amount: 300 }] });
  assert.ok(/PART PAYMENT – S-9 \(\$?.*500.*still owing\)/.test(p.notes), p.notes);
  assert.ok(AP.listInvoices({ filter: 'part' }).some((x) => x.uid === i.uid));
  assert.ok(apAlertsFor(owner).some((a) => a.id === 'ap-part-paid'));
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cash', shopCode: 'S1', receivedBy: 'Rep', payDate: '2026-10-20', allocations: [{ invoiceUid: i.uid, amount: 500 }] });
  assert.ok(!AP.listInvoices({ filter: 'part' }).some((x) => x.uid === i.uid));
});
test('a receipt for a bill already paid (rent): bill + payment saved together for someone who pays suppliers', () => {
  const landlord = AP.saveSupplier(owner, { name: 'Landlord Ltd', tin: '509999999' });
  const r = V.snap(owner, { kind: 'invoice', shopCode: 'S1', amount: 1500, supplierUid: landlord.uid, refNo: 'RENT-OCT', photos: ['file:///doc/r.jpg'], category: 'Rent',
    paid: { method: 'cheque', accountUid: acct.uid, chequeNo: '503' } });
  const i = AP.getInvoice(r.linkUid);
  assert.strictEqual(i.category, 'Rent');
  assert.strictEqual(i.owing, 0);
  assert.strictEqual(db().get('SELECT payee FROM cheques WHERE account_uid = ? AND cheque_no = 503', [acct.uid]).payee, 'Landlord Ltd');
  const staff = saveUser({ name: 'Shop Staff', pin: '1313', role: 'staff', shopCode: 'S1' }, owner);
  const r2 = V.snap(staff, { kind: 'invoice', shopCode: 'S1', amount: 90, supplierUid: landlord.uid, refNo: 'WATER-1', photos: ['file:///doc/w.jpg'], category: 'Power & water', paid: { method: 'cash', shopCode: 'S1' } });
  const w = AP.getInvoice(r2.linkUid);
  assert.strictEqual(w.owing, 90, 'staff cannot pay: the office records it');
  assert.ok(/RECEIPT – already paid by cash/.test(w.notes));
});
done();
