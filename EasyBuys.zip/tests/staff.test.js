// Roster planner, planned against worked, who is on, late reasons, paid weeks locked, leave rules and calendar.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as R from '../src/modules/timesheets/roster.js';
import { setDayTime, checkWeek, uncheckWeek } from '../src/modules/timesheets/service.js';
import { addManualPunch, setPunchReason } from '../src/modules/timeclock/service.js';
import * as P from '../src/modules/payroll/service.js';
import * as L from '../src/modules/leave/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T10:00:00');
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mere = saveUser({ name: 'Mere Tuilau', pin: '4321', role: 'staff', employeeNo: 'EB010', shopCode: 'S2' }, owner);
const sam = saveUser({ name: 'Sam Kumar', pin: '4322', role: 'staff', employeeNo: 'EB011', shopCode: 'S2' }, owner);
const ana = saveUser({ name: 'Ana Roko', pin: '4323', role: 'staff', employeeNo: 'EB012', shopCode: 'S2' }, owner);

test('plan a week, planned cost from pay rates, copy to the next week', () => {
  P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 6, payMethod: 'cash' });
  R.setShift(owner, { userUid: mere.uid, date: '2026-10-05', shopCode: 'S2', start: '07:00', end: '15:00', breakMin: 30 });
  R.setShift(owner, { userUid: mere.uid, date: '2026-10-08', shopCode: 'S2', start: '08:00', end: '16:00', breakMin: 30 });
  R.setShift(owner, { userUid: sam.uid, date: '2026-10-07', shopCode: 'S2', start: '08:00', end: '16:00', breakMin: 0 });
  const p = R.weekPlan('2026-10-05', { shopCode: 'S2' });
  const m = p.people.find((x) => x.user.uid === mere.uid);
  assert.strictEqual(m.minutes, 900);
  assert.strictEqual(m.cost, 90);
  assert.strictEqual(R.copyWeek(owner, { fromWeek: '2026-10-03', toWeek: '2026-10-10', shopCode: 'S2' }), 3);
  assert.strictEqual(R.copyWeek(owner, { fromWeek: '2026-10-03', toWeek: '2026-10-10', shopCode: 'S2' }), 0, 'never doubles up');
  assert.strictEqual(R.plannedFor(mere.uid, '2026-10-12').start, '07:00');
});

test('planned against worked: late, absent, extra', () => {
  addManualPunch(owner, { userUid: mere.uid, type: 'IN', at: '2026-10-05 07:20:00', reason: 't' });
  addManualPunch(owner, { userUid: mere.uid, type: 'OUT', at: '2026-10-05 15:00:00', reason: 't' });
  addManualPunch(owner, { userUid: ana.uid, type: 'IN', at: '2026-10-06 09:00:00', reason: 't' });
  addManualPunch(owner, { userUid: ana.uid, type: 'OUT', at: '2026-10-06 13:00:00', reason: 't' });
  const r = R.planVsActual('2026-10-05', { shopCode: 'S2' });
  const m = r.rows.find((x) => x.user.uid === mere.uid);
  assert.strictEqual(m.days.find((d) => d.date === '2026-10-05').status, 'late');
  assert.strictEqual(m.days.find((d) => d.date === '2026-10-05').late, 20);
  assert.strictEqual(r.rows.find((x) => x.user.uid === sam.uid).days.find((d) => d.date === '2026-10-07').status, 'absent');
  assert.strictEqual(r.rows.find((x) => x.user.uid === ana.uid).days.find((d) => d.date === '2026-10-06').status, 'extra');
});

test('who is on now (planned 08:00, now 10:00, not in → late)', () => {
  const w = R.whoIsOn('S2', new Date('2026-10-08T10:00:00'));
  const m = w.find((x) => x.user.uid === mere.uid);
  assert.strictEqual(m.status, 'late');
  assert.strictEqual(m.late, 120);
});

test('late reason saved on the punch; a paid week cannot be changed', () => {
  const p = addManualPunch(owner, { userUid: sam.uid, type: 'IN', at: '2026-10-08 09:30:00', reason: 't' });
  const uid = typeof p === 'string' ? p : p.uid;
  setPunchReason(uid, 'Late: Transport / bus');
  assert.strictEqual(db().get('SELECT reason FROM punches WHERE uid = ?', [uid]).reason, 'Late: Transport / bus');
  const run = P.createRun(owner, '2026-10-05');
  checkWeek(owner, mere.uid, '2026-10-03', 'ok');
  P.finaliseRun(owner, run.uid);
  throws(() => setDayTime(owner, { userUid: mere.uid, date: '2026-10-05', cell: 'out', time: '16:00', reason: 'x' }), /checked/);
  uncheckWeek(owner, mere.uid, '2026-10-03', 'test');
  throws(() => setDayTime(owner, { userUid: mere.uid, date: '2026-10-05', cell: 'out', time: '16:00', reason: 'x' }), /been paid/);
});

test('leave: sick over 2 days needs a certificate photo; clash with others in the shop; calendar; leave owed', () => {
  throws(() => L.requestLeave(owner, { userUid: sam.uid, type: 'SICK', from: '2026-10-12', to: '2026-10-15' }), /medical certificate/);
  const a = L.requestLeave(owner, { userUid: sam.uid, type: 'SICK', from: '2026-10-12', to: '2026-10-15', photoUri: 'file:///cert.jpg' });
  const b = L.requestLeave(owner, { userUid: ana.uid, type: 'ANNUAL', from: '2026-10-13', to: '2026-10-13' });
  assert.strictEqual(L.clashesFor(b).length, 1);
  const cal = L.leaveCalendar('2026-10', { shopCode: 'S2' });
  assert.strictEqual(cal.find((d) => d.date === '2026-10-13').off.length, 2);
  L.decideLeave(owner, a, true);
  const owed = L.leaveLiability(2026).find((x) => x.name === 'Mere Tuilau');
  assert.strictEqual(owed.left, 10);
  assert.strictEqual(owed.owed, 480, '10 days × 8 h × $6');
  assert.ok(L.listLeaveTypes().some((t) => t.code === 'FAMILY'));
});

test('wages against sales per shop and day', () => {
  const rows = R.wagesVsSales({ from: '2026-10-05', to: '2026-10-05', shopCode: 'S2' });
  assert.strictEqual(rows[0].cost, 46, '7h40 × $6');
});

done();
