// Go-live: staff profile – everything about one person on one page, with what is missing; personal details synced.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as P from '../src/modules/payroll/service.js';
import { staffProfile, saveDetails, getDetails } from '../src/modules/staff/profile.js';
import { pendingRecords } from '../src/services/records.js';
import { test, done, assert } from './harness.js';

const A = openNodeDb(); initDatabase(A);
clock.override = new Date('2026-10-10T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mere = saveUser({ name: 'Mere T', pin: '4545', role: 'staff', shopCode: 'S1', employeeNo: 'EB020' }, owner);
const staff = saveUser({ name: 'Ravi K', pin: '4546', role: 'staff', shopCode: 'S2' }, owner);

test('new person: warnings for what is missing', () => {
  const p = staffProfile(mere.uid);
  assert.strictEqual(p.person.name, 'Mere T');
  const keys = p.warnings.map((w) => w.key);
  assert.ok(keys.includes('pay') && keys.includes('emergency'), keys.join(','));
});
test('pay details, advance and personal details show on the profile', () => {
  P.saveProfile(owner, { userUid: mere.uid, payType: 'hourly', rate: 6.5, fnpfNo: '', tin: '', taxStatus: 'resident', payMethod: 'cash' });
  P.giveDebt(owner, { userUid: mere.uid, kind: 'advance', amount: 40, date: '2026-10-08', reason: 'bus fare' });
  saveDetails(owner, mere.uid, { emergency_name: 'Tomasi', emergency_phone: '9123456', emergency_relation: 'husband', birth_date: '1995-03-02', email: 'mere@example.com' });
  const p = staffProfile(mere.uid);
  assert.strictEqual(p.pay.rate, 6.5);
  const keys = p.warnings.map((w) => w.key);
  assert.ok(keys.includes('fnpf') && keys.includes('tin') && !keys.includes('pay') && !keys.includes('emergency'), keys.join(','));
  assert.ok(p.owes && p.owes.total === 40, JSON.stringify(p.owes));
  assert.strictEqual(p.details.emergency_name, 'Tomasi');
  assert.ok(p.history.some((h) => /Personal details changed/.test(h.action)));
});
test('module off: that part is left out; viewer without payroll rights sees no pay', () => {
  const p = staffProfile(mere.uid, { on: (m) => m !== 'leave' && m !== 'owed' && m !== 'payroll' });
  assert.ok(!p.leave && p.pay === undefined && !p.owes);
  const q = staffProfile(mere.uid, { viewer: staff });
  assert.ok(q.pay === undefined && !q.payslips);
});
test('details: checked, only staff managers, synced to other devices', () => {
  let msg = '';
  try { saveDetails(staff, mere.uid, { email: 'x@y.com' }); } catch (e) { msg = e.message; }
  assert.ok(/manages staff/.test(msg));
  try { saveDetails(owner, mere.uid, { email: 'not an email' }); } catch (e) { msg = e.message; }
  assert.ok(/Email/.test(msg));
  saveDetails(owner, mere.uid, { address: 'Lautoka' });
  assert.strictEqual(getDetails(mere.uid).email, 'mere@example.com', 'fields not sent are kept');
  const pend = pendingRecords();
  const rows = (pend.staff_details || pend.find?.((x) => x.table === 'staff_details')) || JSON.stringify(pend).includes('staff_details');
  assert.ok(rows, 'staff_details is synced');
});
done();
