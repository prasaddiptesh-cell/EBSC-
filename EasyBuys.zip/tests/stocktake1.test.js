// 1.0 stock take: areas with counters, cartons + singles, high-value products counted twice by two people, a reason for
// each difference, owner approves big losses, losses by product, products short again and again, expiry seen while counting.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as I from '../src/modules/inventory/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T19:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup2 = saveUser({ name: 'Sita', pin: '2323', role: 'supervisor', shopCode: 'S1' }, owner);
const smokes = I.saveItem(owner, { code: 'CIG1', name: 'Benson 20s', groupName: 'Cigarettes', cost: 20, price: 25, packSize: 10 });
const rice = I.saveItem(owner, { code: 'RICE', name: 'Rice 1kg', groupName: 'Grocery', cost: 2, price: 3 });
I.saveItemShop(owner, { itemUid: smokes.uid, shopCode: 'S1', location: 'Counter' });
I.saveItemShop(owner, { itemUid: rice.uid, shopCode: 'S1', location: 'Aisle 1' });
I.adjustStock(owner, { itemUid: smokes.uid, shopCode: 'S1', qty: 50, reason: 'Found', date: '2026-10-10' });
I.adjustStock(owner, { itemUid: rice.uid, shopCode: 'S1', qty: 40, reason: 'Found', date: '2026-10-10' });
let c;
test('areas: each counter takes one, progress per area, done only when all counted', () => {
  c = I.startCount(mgr, { shopCode: 'S1', scope: { itemUids: [smokes.uid, rice.uid] }, date: '2026-10-12', timing: 'after_close' });
  assert.deepStrictEqual(c.areas.map((a) => a.area).sort(), ['Aisle 1', 'Counter']);
  I.claimArea(mgr, c.uid, 'Counter');
  throws(() => I.claimArea(sup2, c.uid, 'Counter'), /Mgr is counting/);
  throws(() => I.finishArea(mgr, c.uid, 'Counter'), /not counted yet/);
});
test('cartons + singles; high-value products need a second count by another person', () => {
  I.enterCount(mgr, c.uid, smokes.uid, 5, { packs: 4 }); // 4 × 10 + 5
  assert.strictEqual(I.getCount(c.uid).lines.find((l) => l.item_uid === smokes.uid).counted, 45);
  I.finishArea(mgr, c.uid, 'Counter');
  I.enterCount(sup2, c.uid, rice.uid, 40);
  throws(() => I.submitCount(mgr, c.uid), /second time by another person/);
  I.enterCount(sup2, c.uid, smokes.uid, 44); // the second count differs
  const r = I.submitCount(mgr, c.uid);
  assert.ok(r.recount.some((x) => /differ/.test(x.name)), 'counted again when the two differ');
  I.enterCount(mgr, c.uid, smokes.uid, 45);
  I.enterCount(sup2, c.uid, smokes.uid, 45);
  assert.strictEqual(I.submitCount(mgr, c.uid).recount.length, 0);
});
test('a reason for each difference; the owner approves a loss over the limit', () => {
  const cc = I.getCount(c.uid);
  assert.strictEqual(cc.summary.loss, -100); // 5 short × $20
  throws(() => I.postCount(mgr, c.uid), /Give a reason/);
  I.setLineReason(mgr, c.uid, smokes.uid, 'Theft / missing');
  I.saveInvRules(owner, { ...I.invRules(), countApproveOver: 50 });
  throws(() => I.postCount(mgr, c.uid), /owner or admin approves/);
  I.postCount(owner, c.uid);
  const sh = I.shrinkage({ shopCode: 'S1', from: '2026-10-01', to: '2026-10-31' });
  assert.ok(sh.byReason.some((x) => /Theft/.test(x.reason)), JSON.stringify(sh.byReason));
  const bp = I.shrinkageByProduct({ shopCode: 'S1', from: '2026-10-01', to: '2026-10-31' });
  assert.strictEqual(bp[0].name, 'Benson 20s');
});
test('products short again and again; expiry seen while counting; high-value due', () => {
  for (const d of ['2026-10-13', '2026-10-14']) {
    clock.override = new Date(`${d}T19:00:00`);
    const x = I.startCount(owner, { shopCode: 'S1', scope: { itemUids: [smokes.uid] }, date: d });
    const exp = x.lines[0].expected;
    I.enterCount(owner, x.uid, smokes.uid, exp - 1);
    I.enterCount(mgr, x.uid, smokes.uid, exp - 1);
    I.setLineExpiry(owner, x.uid, smokes.uid, { expiry: '2026-10-20', qty: 3 });
    if (I.submitCount(owner, x.uid).recount.length) { I.enterCount(owner, x.uid, smokes.uid, exp - 1); I.enterCount(mgr, x.uid, smokes.uid, exp - 1); I.submitCount(owner, x.uid); }
    I.postCount(owner, x.uid);
  }
  assert.strictEqual(I.repeatLosers({ shopCode: 'S1' })[0].name, 'Benson 20s');
  assert.ok(I.expiringSoon({ shopCode: 'S1', days: 14, today: '2026-10-14' }).some((e) => e.name === 'Benson 20s'));
  assert.ok(!I.highValueDue('S1', { today: '2026-10-15' }).length, 'just counted');
  assert.ok(I.highValueDue('S1', { today: '2026-10-30' }).some((r) => r.name === 'Benson 20s'));
});
done();
