// 3.9.3 First (initial) stock take on many phones: every count is its own entry, added up through the cloud, so phones
// never overwrite each other. Anyone can help; "Set" replaces only your own count; the admin can change any total.
// Product details (cost, selling price, barcode, several suppliers) seen and fixed while counting; products scanned that
// are not on the list are added. Approving makes the counts the opening stock.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as I from '../src/modules/inventory/service.js';
import { alerts } from '../src/modules/inventory/alerts.js';
import { test, done, assert, throws } from './harness.js';
import fs from 'fs';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T19:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sita = saveUser({ name: 'Sita', pin: '2323', role: 'staff', shopCode: 'S1' }, owner);
const ravi = saveUser({ name: 'Ravi', pin: '2424', role: 'staff', shopCode: 'S1' }, owner);
const u = (x) => (typeof x === 'string' ? x : x.uid);
const rice = u(I.saveItem(owner, { code: 'RICE', name: 'Rice 1kg', cost: 2, price: 3, barcode: '111' }));
const soap = u(I.saveItem(owner, { code: 'SOAP', name: 'Soap', cost: 1, price: 1.8 }));
const tuna = u(I.saveItem(owner, { code: 'TUNA', name: 'Tuna 185g', cost: 2.5, price: 3.4 }));
I.saveItemShop(owner, { itemUid: rice, shopCode: 'S1', location: 'Aisle 1' });
const punjas = AP.saveSupplier(owner, { name: 'Punjas' });
const motibhai = AP.saveSupplier(owner, { name: 'Motibhai' });
let c;
const line = (item) => I.getCount(c.uid).lines.find((l) => l.item_uid === item);

test('the first stock take has every product (even ones the shop has not had yet); everyone is asked to help', () => {
  throws(() => I.startCount(mgr, { shopCode: 'S1', kind: 'initial', date: '2026-10-12' }), /Only the owner or admin/);
  c = I.startCount(owner, { shopCode: 'S1', kind: 'initial', date: '2026-10-12' });
  assert.strictEqual(c.kind, 'initial'); assert.strictEqual(c.blind, 0);
  assert.deepStrictEqual(c.lines.map((l) => l.item_uid).sort(), [rice, soap, tuna].sort());
  assert.ok(alerts(sita).some((a) => /First stock take at S1 – help count/.test(a.text)), 'staff see it on Home');
  assert.ok(c.lines.every((l) => l.uid === `CL-${c.uid}-${l.item_uid}`), 'line ids are the same on every phone');
});
test('two phones count the same product in two places: added up, never overwritten', () => {
  I.enterCount(sita, c.uid, rice, 10, { spot: 'Aisle 1' });
  I.enterCount(ravi, c.uid, rice, 6, { spot: 'Storeroom' });
  assert.strictEqual(line(rice).counted, 16);
  assert.ok(/Sita/.test(line(rice).counted_by_name) && /Ravi/.test(line(rice).counted_by_name));
  // Sita fixes HER count: only hers is replaced
  I.enterCount(sita, c.uid, rice, 12);
  assert.strictEqual(line(rice).counted, 18);
  I.enterCount(ravi, c.uid, rice, 2, { add: true });
  assert.strictEqual(line(rice).counted, 20);
  assert.strictEqual(I.countEntries(c.uid, rice).length, 3);
});
test('an entry made on another phone arrives through the cloud: it is counted (the line itself may be old)', () => {
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, updated_at, updated_device) VALUES ('CE-x', ?, ?, 4, 'Mere', 'U-m', 'PHONE9', '2026-10-12 19:30:00', '2026-10-12 19:30:00', 'PHONE9')", [c.uid, rice]);
  db().run('UPDATE inv_count_lines SET counted = 3 WHERE count_uid = ? AND item_uid = ?', [c.uid, rice]); // a stale line from another phone
  assert.strictEqual(line(rice).counted, 24);
});
test('wrong entries: the person (or a manager) takes it out; the admin can change the total', () => {
  const e = I.countEntries(c.uid, rice).find((x) => x.by_name === 'Ravi' && x.qty === 2);
  throws(() => I.voidEntry(sita, e.uid), /Only the person/);
  I.voidEntry(ravi, e.uid, 'typed wrong');
  assert.strictEqual(line(rice).counted, 22);
  throws(() => I.setCountTotal(sita, c.uid, rice, 30), /Only the admin/);
  I.setCountTotal(owner, c.uid, rice, 21, 'counted it myself');
  assert.strictEqual(line(rice).counted, 21);
  assert.strictEqual(I.countEntries(c.uid, rice).length, 1);
  assert.ok(I.countEntries(c.uid, rice, { all: true }).length >= 5, 'the old counts are kept');
});
test('a count arriving late from a phone that was offline during "Change total" is not added on top', () => {
  // Mere counted 5 at 19:10 on a phone that was offline; the admin set the total at 19:00 + (now); her entry arrives after.
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, updated_at, updated_device) VALUES ('CE-late', ?, ?, 5, 'Mere', 'U-m', 'PHONE9', '2026-10-12 18:59:00', '2026-10-12 18:59:00', 'PHONE9')", [c.uid, rice]);
  assert.strictEqual(line(rice).counted, 21);
  // a phone with a FAST clock that had not seen the "Change total": its old count is not added either
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, updated_at, updated_device) VALUES ('CE-fast', ?, ?, 6, 'Fast', 'U-f', 'PHONE8', '2026-10-12 23:59:00', '2026-10-12 23:59:00', 'PHONE8')", [c.uid, rice]);
  assert.strictEqual(line(rice).counted, 21);
  // a stale copy of the line (counted 99) from another phone changes nothing either
  db().run('UPDATE inv_count_lines SET counted = 99 WHERE count_uid = ? AND item_uid = ?', [c.uid, rice]);
  assert.strictEqual(line(rice).counted, 21);
});
test('a phone with a slow clock that has seen the recount: its new count still counts', () => {
  const reset = db().get("SELECT uid, at FROM inv_count_entries WHERE count_uid = ? AND item_uid = ? AND kind = 'reset' ORDER BY at DESC LIMIT 1", [c.uid, rice]);
  assert.ok(reset, 'the "Change total" left a reset marker');
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, seen_reset, updated_at, updated_device) VALUES ('CE-slow', ?, ?, 3, 'Joe', 'U-j', 'PHONE5', '2026-10-12 18:00:00', ?, '2026-10-12 18:00:00', 'PHONE5')", [c.uid, rice, reset.uid]);
  assert.strictEqual(line(rice).counted, 24);
  I.voidEntry(owner, 'CE-slow', 'test');
  assert.strictEqual(line(rice).counted, 21);
  // an old copy of the line row from another phone cannot undo the reset (it lives in the entries)
  db().run('UPDATE inv_count_lines SET recount = 0, first_count = NULL WHERE count_uid = ? AND item_uid = ?', [c.uid, rice]);
  assert.strictEqual(line(rice).counted, 21);
});
test('details while counting: cost, selling price, barcode, several suppliers', () => {
  throws(() => I.quickEditItem(sita, soap, { cost: 1.1 }), /cannot change/);
  const ch = I.quickEditItem(mgr, soap, { shopCode: 'S1', cost: 1.1, price: 2, barcode: '222', vatType: 'exempt' });
  assert.strictEqual(ch.length, 4);
  assert.strictEqual(I.getItem(soap).vat_type, 'exempt');
  throws(() => I.quickEditItem(mgr, soap, { vatType: 'maybe' }), /Choose VAT/);
  assert.strictEqual(I.itemAtShop(soap, 'S1').shopPrice, 2);
  throws(() => I.quickEditItem(mgr, tuna, { barcode: '222' }), /belongs to Soap/);
  I.addItemSupplier(mgr, soap, punjas.uid);
  I.addItemSupplier(mgr, soap, motibhai.uid);
  assert.deepStrictEqual(I.itemSuppliers(soap).map((x) => [x.supplier_name, x.main]), [['Punjas', true], ['Motibhai', false]]);
  I.addItemSupplier(mgr, soap, motibhai.uid, { main: true });
  assert.strictEqual(I.itemSuppliers(soap)[0].supplier_name, 'Motibhai');
  I.removeItemSupplier(mgr, soap, motibhai.uid);
  assert.deepStrictEqual(I.itemSuppliers(soap).map((x) => [x.supplier_name, x.main]), [['Punjas', true]]);
});
test('a product scanned that is not on the list is added (once, even from two phones)', () => {
  const salt = u(I.saveItem(mgr, { name: 'Salt 1kg', barcode: '333', cost: 0.8, price: 1.2 }));
  assert.strictEqual(I.addToCount(sita, c.uid, salt), true);
  assert.strictEqual(I.addToCount(ravi, c.uid, salt), false);
  I.enterCount(sita, c.uid, salt, 7);
  assert.strictEqual(line(salt).counted, 7);
});
test('approved: the counts become the opening stock; the products are now at the shop', () => {
  I.enterCount(sita, c.uid, soap, 30);
  const r = I.submitCount(mgr, c.uid);
  assert.strictEqual(r.recount.length, 0);
  I.postCount(owner, c.uid);
  assert.strictEqual(I.stockOf(rice, 'S1'), 21);
  assert.strictEqual(I.stockOf(soap, 'S1'), 30);
  assert.strictEqual(I.stockOf(tuna, 'S1'), 0, 'not counted: left as it was');
  assert.ok(db().get("SELECT 1 AS x FROM inv_item_shops WHERE item_uid = ? AND shop_code = 'S1'", [soap]));
  assert.ok(!alerts(sita).some((a) => /help count/.test(a.text)));
  // after posting, the results never change (a late entry is ignored; the totals are on the lines)
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, seen_reset, updated_at, updated_device) VALUES ('CE-after', ?, ?, 50, 'Late', 'U-l', 'PHONE7', '2026-10-13 08:00:00', (SELECT uid FROM inv_count_entries WHERE count_uid = ? AND item_uid = ? AND kind = 'reset' ORDER BY at DESC LIMIT 1), '2026-10-13 08:00:00', 'PHONE7')", [c.uid, rice, c.uid, rice]);
  assert.strictEqual(line(rice).counted, 21);
  assert.strictEqual(db().get('SELECT counted FROM inv_count_lines WHERE count_uid = ? AND item_uid = ?', [c.uid, rice]).counted, 21);
  // …but it is never silently lost: flagged until a manager has seen it
  assert.deepStrictEqual(I.lateCounts().map((x) => [x.uid, x.n]), [[c.uid, 1]]);
  assert.ok(alerts(owner).some((a) => /1 count arrived after it was approved/.test(a.text)));
  throws(() => I.ackLateCounts(sita, c.uid), /Only a manager/);
  I.ackLateCounts(mgr, c.uid);
  assert.strictEqual(I.lateCounts().length, 0);
  // a phone that replaced its count after approval (same number of counts, different total) is flagged too
  db().run("UPDATE inv_count_entries SET void_at = '2026-10-13 09:00:00' WHERE uid = 'CE-after'");
  db().run("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, by_name, by_uid, device, at, seen_reset, updated_at, updated_device) VALUES ('CE-after2', ?, ?, 40, 'Late', 'U-l', 'PHONE7', '2026-10-13 09:00:00', (SELECT uid FROM inv_count_entries WHERE count_uid = ? AND item_uid = ? AND kind = 'reset' ORDER BY at DESC LIMIT 1), '2026-10-13 09:00:00', 'PHONE7')", [c.uid, rice, c.uid, rice]);
  assert.ok(I.lateCounts().some((x) => x.uid === c.uid && x.qtyDiff === -10), JSON.stringify(I.lateCounts()));
});
test('no table is listed twice in the new-columns list (a second entry would hide the first)', () => {
  const src = fs.readFileSync(`${process.cwd()}/src/db/columns.js`, 'utf8');
  const keys = Array.from(src.matchAll(/^\s{2}(\w+): \[\[/gm)).map((m) => m[1]);
  assert.deepStrictEqual(keys.filter((k, i) => keys.indexOf(k) !== i), []);
});
test('deliveries remember every supplier a product comes from; orders suggest it for each', () => {
  I.receiveDelivery(owner, { supplierUid: motibhai.uid, shopCode: 'S1', date: '2026-10-12', extra: [{ itemUid: soap, qty: 5, unitCost: 1.05 }], photos: ['file:///x.jpg'] });
  const s = I.itemSuppliers(soap);
  assert.ok(s.some((x) => x.supplier_name === 'Motibhai' && x.last_cost === 1.05), JSON.stringify(s));
});
test('VAT: Aronium and the app must agree – a difference is flagged; the import never undoes a person\'s choice', () => {
  const csv = 'Code,Name,Price,Cost,Tax\nSOAP,Soap,2.00,1.10,VAT 12.5%\nRICE,Rice 1kg,3.00,2.00,0%\nTUNA,Tuna 185g,3.40,2.50,VAT 12.5%\n';
  I.importProductsCsv(owner, csv, { shopCode: 'S1' });
  assert.strictEqual(I.getItem(soap).vat_type, 'exempt', 'chosen in the app during the stock take – kept');
  assert.strictEqual(I.getItem(rice).vat_type, 'zero', 'never chosen in the app – Aronium\'s is taken');
  const vm = I.vatMismatches();
  assert.deepStrictEqual(vm.map((x) => x.code), ['SOAP']);
  const a = alerts(owner).find((x) => /VAT in Aronium is not the same/.test(x.text));
  assert.ok(a && /Soap: Aronium VAT 12.5%, app VAT free/.test(a.sub), JSON.stringify(alerts(owner).map((x) => x.text)));
  throws(() => I.useAroniumVat(sita, soap), /cannot change/);
  I.useAroniumVat(owner, soap);
  assert.strictEqual(I.getItem(soap).vat_type, 'standard');
  assert.strictEqual(I.vatMismatches().length, 0);
  // zero rated vs VAT free: both no VAT – not a difference
  I.quickEditItem(owner, rice, { vatType: 'exempt' });
  assert.strictEqual(I.vatMismatches().length, 0);
});

done();
