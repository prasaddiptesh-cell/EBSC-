// 3.9 stress: 6 months of business made through the app's own functions (Training history), then every check that
// the figures agree across modules, month by month – and every warning, report and dashboard card for every role
// runs without an error, in reasonable time, on that much data.
import { openNodeDb } from './nodeDb.js';
import { initDatabase, allowNewRoles } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, addDays } from '../src/services/core.js';
import { seedTraining } from '../src/db/trainingSeed.js';
import { seedHistory } from '../src/db/trainingHistory.js';
import * as A from '../src/modules/accounting/service.js';
import * as RT from '../src/modules/payroll/returns.js';
import * as W from '../src/services/watchdog.js';
import { setAlertSources, collectAlerts } from '../src/services/alerts.js';
import { buildCard, listCards } from '../src/services/dashboardCards.js';
import '../src/modules/payroll/cards.js';
import '../src/modules/dashboard/cards.js';
import '../src/modules/dashboard/cards36.js';
import '../src/modules/licences/cards.js';
import { test, atest, done, assert } from './harness.js';

const ALERTS = {};
for (const m of ['accounting', 'admin', 'bakery', 'bank', 'devices', 'drawings', 'inventory', 'leave', 'licences', 'loans', 'owed', 'payables', 'payroll', 'sync', 'till', 'timesheets', 'vehicles', 'verify']) {
  ALERTS[m] = await import(`../src/modules/${m}/alerts.js`);
}
const REPORT_FILES = ['accounting', 'bank', 'drawings', 'inventory', 'leave', 'licences', 'loans', 'owed', 'payables', 'payroll', 'till', 'timesheets', 'vehicles'];
const REPORTS = [];
for (const m of REPORT_FILES) { const x = await import(`../src/modules/${m}/reports.js`); (x.REPORTS || []).forEach((r) => REPORTS.push({ ...r, module: m })); }
{ const x = await import('../src/modules/payroll/statReports.js'); (x.STAT_REPORTS || []).forEach((r) => REPORTS.push({ ...r, module: 'payroll-stat' })); }
{ const x = await import('../src/services/reports.js'); (x.RANGE_REPORTS || []).forEach((r) => REPORTS.push({ ...r, module: 'range' })); }

initDatabase(openNodeDb());
try { allowNewRoles(); } catch (e) { /* done */ }
const TODAY = '2026-10-11';
clock.override = new Date(`${TODAY}T09:00:00`);
seedTraining();
let res;
const r2 = (n) => Math.round(n * 100) / 100;
const months = [];

await atest('6 months of business are made without a problem', async () => {
  const t = Date.now();
  res = await seedHistory({ days: 168, pause: null });
  clock.override = new Date(`${TODAY}T09:00:00`);
  console.log(`     made in ${Math.round((Date.now() - t) / 1000)} s: ${JSON.stringify(res.made)}`);
  if (res.problems.length) console.log('     problems:\n     ' + res.problems.slice(0, 30).join('\n     '));
  assert.ok(res.problems.length === 0, `${res.problems.length} problems`);
  assert.ok(res.made['till counts'] >= 330 && res.made['pay runs'] >= 22 && res.made.deliveries >= 45);
  const first = db().get('SELECT MIN(shift_date) AS d FROM till_counts').d;
  for (let ym = first.slice(0, 7); ym < TODAY.slice(0, 7); ) { months.push(ym); const [y, m] = ym.split('-').map(Number); ym = m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`; }
});
test('every month end: the books balance', () => {
  for (const ym of months) {
    const end = addDays(`${ym === months[months.length - 1] ? TODAY.slice(0, 7) : months[months.indexOf(ym) + 1]}-01`, -1);
    const tb = A.trialBalance(end);
    assert.ok(tb.ok, `${ym}: debits ${tb.dr} credits ${tb.cr}`);
  }
});
test('every month: VAT line 1 = the takings typed at the tills; line 7 = VAT on invoices with a TIN', () => {
  for (const ym of months) {
    const v = RT.vatReturnFRCS(ym);
    const till = r2(db().get("SELECT COALESCE(SUM(z_total),0) AS t FROM till_counts WHERE status <> 'void' AND substr(shift_date,1,7) = ?", [ym]).t);
    const typed = r2(db().all("SELECT meta FROM gl_journals WHERE status = 'active' AND kind IN ('sale','aronium_sale') AND substr(jdate,1,7) = ?", [ym]).reduce((s, j) => s + Number(JSON.parse(j.meta || '{}').total || 0), 0));
    assert.ok(Math.abs(v.lines[1] - till - typed) < 0.05, `${ym}: line 1 ${v.lines[1]} vs tills ${till} + typed ${typed}`);
    const inv = r2(db().get("SELECT COALESCE(SUM(i.vat),0) AS v FROM ap_invoices i WHERE i.status <> 'void' AND i.kind = 'invoice' AND substr(i.invoice_date,1,7) = ? AND COALESCE(i.supplier_tin,'') <> ''", [ym]).v);
    assert.ok(Math.abs(v.lines[7] - inv) < 0.05, `${ym}: line 7 ${v.lines[7]} vs invoices ${inv}`);
  }
});
test('every month: the FNPF schedule = FNPF on the final pay runs paid that month; 8% employer from August', () => {
  for (const ym of months) {
    const s = RT.fnpfSchedule(ym);
    const p = r2(db().get("SELECT COALESCE(SUM(l.fnpf_employee + l.fnpf_employer),0) AS t FROM pay_lines l JOIN pay_runs r ON r.uid = l.run_uid AND r.status = 'final' WHERE l.include = 1 AND substr(r.pay_date,1,7) = ?", [ym]).t);
    assert.ok(Math.abs(s.totals.contributions - p) < 0.05, `${ym}: schedule ${s.totals.contributions} vs pay runs ${p}`);
    for (const r of s.rows) {
      const pct = ym >= '2026-08' ? 8 : 10;
      assert.ok(Math.abs(r.employer - r2((r.gross * pct) / 100)) <= 0.05 * r.pays + 0.01, `${ym} ${r.first}: employer ${r.employer} vs ${pct}% of ${r.gross}`);
    }
    assert.ok(!s.rows.some((r) => /Kavita/.test(r.first)), 'family member without FNPF is never on the schedule');
  }
});
test('the lodged and paid months are complete; FNPF and VAT accounts are cleared for them', () => {
  const lodged = db().all("SELECT kind, period FROM tax_return_versions WHERE status = 'lodged' ORDER BY period");
  assert.ok(lodged.filter((x) => x.kind === 'vat').length >= 4, JSON.stringify(lodged));
  for (const x of lodged) {
    const st = RT.returnStatus(x.kind, x.period, { today: TODAY });
    assert.ok(!st.flags.some((f) => f.key === 'changed'), `${x.kind} ${x.period} changed after lodging: ${st.flags.map((f) => f.text).join(' ')}`);
    assert.ok(st.item.done || st.refund, `${x.kind} ${x.period} not complete: ${st.item.flags.join(',')}`);
  }
});
test('stock: what the products show = every movement added up; nothing below zero at month ends', () => {
  const neg = db().all("SELECT item_uid, shop_code, SUM(qty) AS q FROM inv_moves WHERE status = 'active' GROUP BY item_uid, shop_code HAVING q < -0.001");
  assert.deepStrictEqual(neg, [], `negative stock: ${JSON.stringify(neg)}`);
});
test('bank: the ledger agrees with the bank lines and the cheque register', () => {
  const acct = db().get('SELECT * FROM bank_accounts WHERE active = 1 ORDER BY name LIMIT 1');
  const code = `1100:${acct.uid}`;
  const ledger = r2(A.balances({ to: TODAY }).filter((r) => r.code === code).reduce((s, r) => s + r.balance, 0));
  const lines = db().all("SELECT type, amount FROM bank_entries WHERE account_uid = ? AND status = 'active' AND entry_date <= ?", [acct.uid, TODAY]);
  const chq = db().all("SELECT amount FROM cheques WHERE account_uid = ? AND status IN ('written','presented') AND cheque_date <= ?", [acct.uid, TODAY]);
  const inn = lines.filter((l) => ['deposit', 'opening', 'transfer_in', 'interest'].includes(l.type)).reduce((s, l) => s + l.amount, 0);
  const out = lines.filter((l) => !['deposit', 'opening', 'transfer_in', 'interest'].includes(l.type)).reduce((s, l) => s + l.amount, 0) + chq.reduce((s, c) => s + c.amount, 0);
  const book = r2(Number(acct.opening_balance || 0) + inn - out);
  console.log('     bank entry types', JSON.stringify(db().all("SELECT type, COUNT(*) n, SUM(amount) s FROM bank_entries WHERE account_uid = ? AND status = 'active' GROUP BY type", [acct.uid])), 'opening', acct.opening_balance);
  assert.ok(Math.abs(ledger - book) < 0.05, `ledger ${ledger} vs opening + lines ${book}`);
});
test('every warning for every role: no error, quick enough', () => {
  setAlertSources(Object.entries(ALERTS).map(([id, m]) => ({ id, alerts: m.alerts })));
  const users = db().all('SELECT * FROM users WHERE active = 1');
  const slow = [];
  for (const u of users) {
    const t = Date.now();
    collectAlerts(u);
    const ms = Date.now() - t;
    if (ms > 1500) slow.push(`${u.name} (${u.role}): ${ms} ms`);
  }
  const errs = require('../src/services/errorLog.js').listErrors ? require('../src/services/errorLog.js').listErrors(50).filter((e) => /warnings of/.test(JSON.stringify(e))) : [];
  assert.deepStrictEqual(errs, [], `a module failed while making warnings: ${JSON.stringify(errs).slice(0, 400)}`);
  assert.deepStrictEqual(slow, [], 'slow warnings');
});
test('every report builds on 6 months (a month, a quarter, the whole period)', () => {
  const owner = db().get("SELECT * FROM users WHERE pin = '5001'");
  const bad = [];
  const ranges = [[`${months[months.length - 1]}-01`, addDays(`${TODAY.slice(0, 7)}-01`, -1)], [addDays(TODAY, -92), TODAY], [`${months[0]}-01`, TODAY]];
  for (const r of REPORTS) {
    if (typeof r.build !== 'function') continue;
    for (const [from, to] of ranges) {
      const t = Date.now();
      try { const out = r.build(from, to, { user: owner }); if (out && typeof out.then === 'function') continue; } catch (e) { if (!/^(Choose|Pick|Select)/.test(e.message)) bad.push(`${r.module}/${r.id} ${from}..${to}: ${e.message}`); }
      const ms = Date.now() - t;
      if (ms > 4000) bad.push(`${r.module}/${r.id} slow: ${ms} ms`);
    }
  }
  console.log(`     ${REPORTS.length} reports × 3 periods`);
  assert.deepStrictEqual(bad, [], bad.join('\n'));
});
test('every dashboard card for the owner, each shop and the whole business', () => {
  const owner = db().get("SELECT * FROM users WHERE pin = '5001'");
  const bad = [];
  for (const c of listCards()) {
    for (const shop of ['ALL', 'S1', 'S2']) {
      const r = buildCard(c.id, { from: addDays(TODAY, -30), to: TODAY }, shop, owner);
      if (r && r.error) bad.push(`${c.id} ${shop}: ${r.error}`);
    }
  }
  assert.deepStrictEqual(bad, []);
});
test('the watchdog runs over 6 months (tamper chain checked)', () => {
  const owner = db().get("SELECT * FROM users WHERE pin = '5001'");
  const t = Date.now();
  const w = W.runWatchdog(owner);
  assert.ok(w);
  assert.ok(Date.now() - t < 8000, `watchdog took ${Date.now() - t} ms`);
  assert.ok(!(w.findings || []).some((f) => /audit_chain|tamper|fingerprint/i.test(`${f.id} ${f.title || ''}`)), 'the change-history chain is unbroken');
});
done();
