// 3.9.2 Till: shortage paid by the cashier in cash (all / part, the rest from pay), surplus recorded and decided
// (kept, set against a shortage, given back), the second count by a supervisor (agrees / differs – their count
// stands, the first is kept), and everything stays in step: cash on hand, shortage / surplus records, the books.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as T from '../src/modules/till/service.js';
import * as S from '../src/modules/till/shifts.js';
import * as RC from '../src/modules/till/recount.js';
import * as A from '../src/modules/accounting/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-20T18:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup2 = saveUser({ name: 'Supervisor Two', pin: '7777', role: 'manager', shopCode: 'S1' }, owner);
const cash1 = saveUser({ name: 'Cashier One', pin: '1212', role: 'staff', shopCode: 'S1' }, owner);
const cash2 = saveUser({ name: 'Cashier Two', pin: '1313', role: 'staff', shopCode: 'S1' }, owner);
const till = T.saveTill(owner, { shopCode: 'S1', name: 'Till 1', floatAmount: 100 });
const till2 = T.saveTill(owner, { shopCode: 'S1', name: 'Till 2', floatAmount: 100 });
const r2 = (n) => Math.round(n * 100) / 100;
let n = 0;
// expected = float 100 + cash sales 400 = 500; notes give what was counted
const count = (by, cashier, notes, date = '2026-10-19', t = till, shift = 'Full day') => T.saveTillCount(by, { shopCode: 'S1', tillUid: t, shiftDate: date, shift, cashierUid: cashier.uid, openingFloat: 100,
  denominations: notes, zCash: 400, zTotal: 400, tenders: [], payouts: [], adjustments: [], floatKept: 100, reason: `count ${++n}` }, { photos: ['file:///z.jpg'] });
const onHand = () => T.cashOnHand('S1').onHand;
const booksOk = () => { const tb = A.trialBalance('2026-12-31'); assert.ok(tb.ok, `books do not balance ${tb.dr} / ${tb.cr}`); };

test('short $20 → waiting for the cashier; the cashier pays $15 now (signs), $5 is left for pay', () => {
  const c = count(mgr, cash1, { n100: 4, n50: 1, n20: 1, n5: 2 }); // 480
  assert.strictEqual(c.over_short, -20);
  const sh = S.shortageForCount(c.uid);
  assert.strictEqual(sh.status, 'waiting');
  const before = onHand();
  throws(() => RC.payShortageNow(mgr, sh.uid, { amount: 15 }), /sign/);
  throws(() => RC.payShortageNow(mgr, sh.uid, { amount: 25, signature: 'sig' }), /up to/);
  const r = RC.payShortageNow(mgr, sh.uid, { amount: 15, signature: 'sig' });
  assert.strictEqual(r.left, 5);
  assert.strictEqual(r2(onHand() - before), 15, 'the cash goes into the shop cash');
  const now = S.getShortage(sh.uid);
  assert.strictEqual(now.amount, 5); assert.strictEqual(now.paid_now, 15); assert.strictEqual(now.status, 'waiting');
  // the rest: the cashier agrees → $5 from pay
  S.agreeShortage(cash1, sh.uid, { signature: 'sig' });
  const ch = db().get('SELECT * FROM staff_charges WHERE uid = ?', [S.getShortage(sh.uid).charge_uid]);
  assert.ok(ch && Math.abs(ch.amount - 5) < 0.001, `charge ${ch && ch.amount}`);
  booksOk();
});
test('paid in full now: shortage "Paid by the cashier", nothing from pay; the cashier cannot take their own money', () => {
  const c = count(mgr, cash2, { n100: 4, n50: 1, n20: 2 }, '2026-10-19', till2); // 490
  const sh = S.shortageForCount(c.uid);
  throws(() => RC.payShortageNow(cash2, sh.uid, { signature: 's' }), /supervisor|someone else/i);
  RC.payShortageNow(mgr, sh.uid, { signature: 'sig' });
  assert.strictEqual(S.getShortage(sh.uid).status, 'paid');
  assert.strictEqual(T.getTillCount(c.uid).short_action, 'paid');
  assert.ok(!S.undecidedShortages({ userUid: cash2.uid }).length, 'not waiting in the pay run');
  booksOk();
});
test('the count is corrected after a part payment: what was paid still comes off', () => {
  const c = count(mgr, cash1, { n100: 4, n50: 1, n20: 1, n5: 1 }, '2026-10-17'); // 475 → short 25
  const sh = S.shortageForCount(c.uid);
  RC.payShortageNow(mgr, sh.uid, { amount: 10, signature: 'sig' });
  // the manager finds a $10 note and corrects the count → short 15, 10 already paid → 5 left
  T.saveTillCount(mgr, { uid: c.uid, shopCode: 'S1', tillUid: till, shiftDate: '2026-10-17', shift: 'Full day', cashierUid: cash1.uid, openingFloat: 100,
    denominations: { n100: 4, n50: 1, n20: 1, n10: 1, n5: 1 }, zCash: 400, zTotal: 400, tenders: [], payouts: [], adjustments: [], floatKept: 100, reason: 'found a note' }, { photos: [] });
  assert.strictEqual(S.getShortage(sh.uid).amount, 5);
});
test('over $30 → a surplus waiting for a decision; kept by the business', () => {
  const c = count(mgr, cash2, { n100: 5, n20: 1, n10: 1 }, '2026-10-16'); // 530
  const s = RC.surplusForCount(c.uid);
  assert.ok(s && s.status === 'open' && s.amount === 30 && s.user_uid === cash2.uid);
  throws(() => RC.decideSurplus(cash2, s.uid, { action: 'keep' }), /supervisor/);
  RC.decideSurplus(mgr, s.uid, { action: 'keep', note: 'no claim' });
  assert.strictEqual(RC.getSurplus(s.uid).status, 'kept');
  booksOk();
});
test('a surplus set against the same cashier\'s shortage: the shortage is not taken from pay', () => {
  const short = count(mgr, cash2, { n100: 4, n50: 1, n20: 2 }, '2026-10-15'); // 490 → short 10
  const over = count(mgr, cash2, { n100: 5, n10: 2 }, '2026-10-14'); // 520 → over 20
  const sh = S.shortageForCount(short.uid);
  const s = RC.surplusForCount(over.uid);
  assert.ok(RC.setOffChoices(s.uid).some((x) => x.uid === sh.uid));
  RC.decideSurplus(mgr, s.uid, { action: 'set_off', shortageUid: sh.uid });
  assert.strictEqual(S.getShortage(sh.uid).status, 'set_off');
  assert.strictEqual(RC.getSurplus(s.uid).set_off_amount, 10);
  assert.ok(!S.undecidedShortages({ userUid: cash2.uid }).some((x) => x.uid === sh.uid));
});
test('a surplus given back (customer short-changed): cash out of the shop, reason needed from a manager', () => {
  const over = count(mgr, cash1, { n100: 5, n20: 1 }, '2026-10-13'); // 520
  const s = RC.surplusForCount(over.uid);
  const before = onHand();
  throws(() => RC.decideSurplus(mgr, s.uid, { action: 'returned' }), /who it was given back/);
  RC.decideSurplus(mgr, s.uid, { action: 'returned', amount: 20, note: 'Customer came back for change' });
  assert.strictEqual(r2(before - onHand()), 20);
  assert.strictEqual(RC.getSurplus(s.uid).status, 'returned');
  booksOk();
});
test('a count corrected so it is no longer over: the open surplus is cancelled', () => {
  const c = count(mgr, cash1, { n100: 5, n10: 1 }, '2026-10-12'); // 510 → over 10
  assert.ok(RC.surplusForCount(c.uid));
  T.saveTillCount(mgr, { uid: c.uid, shopCode: 'S1', tillUid: till, shiftDate: '2026-10-12', shift: 'Full day', cashierUid: cash1.uid, openingFloat: 100,
    denominations: { n100: 5 }, zCash: 400, zTotal: 400, tenders: [], payouts: [], adjustments: [], floatKept: 100 }, { photos: [] });
  assert.ok(!RC.surplusForCount(c.uid));
});
test('second count agrees: confirmed, nothing changes', () => {
  const c = count(mgr, cash1, { n100: 5 }, '2026-10-11');
  throws(() => RC.saveSecondCount(mgr, c.uid, { denominations: { n100: 5 } }), /someone else/);
  throws(() => RC.saveSecondCount(cash2, c.uid, { denominations: { n100: 5 } }), /supervisor/);
  const r = RC.saveSecondCount(sup2, c.uid, { denominations: { n100: 5 } });
  assert.ok(r.same);
  const now = T.getTillCount(c.uid);
  assert.strictEqual(now.second_status, 'confirmed'); assert.strictEqual(now.cash_counted, 500);
});
test('second count differs: the supervisor\'s count stands, the first is kept, shortage and safe cash follow', () => {
  const c = count(mgr, cash2, { n100: 5 }, '2026-10-10'); // balanced 500 by the first count
  const safe0 = onHand();
  const r = RC.saveSecondCount(sup2, c.uid, { denominations: { n100: 4, n50: 1, n20: 2 }, note: 'a $10 short' }); // 490
  assert.ok(!r.same); assert.strictEqual(r.diff, -10);
  const now = T.getTillCount(c.uid);
  assert.strictEqual(now.cash_counted, 490); assert.strictEqual(now.over_short, -10); assert.strictEqual(now.second_status, 'differs');
  assert.strictEqual(JSON.parse(now.first_count).counted, 500);
  assert.strictEqual(r2(safe0 - onHand()), 10, 'the cash moved to the safe follows the second count');
  const sh = S.shortageForCount(c.uid);
  assert.ok(sh && sh.amount === 10 && sh.status === 'waiting', 'a shortage now waits for the cashier');
  assert.ok(db().get("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Second count%first count%'"));
  booksOk();
});
test('the rule: off by default (a supervisor counts again when they choose); "always" asks for it', () => {
  assert.strictEqual(T.tillRules().secondCount, 'off');
  const c = count(mgr, cash1, { n100: 5 }, '2026-10-09');
  assert.ok(!T.getTillCount(c.uid).second_status);
  T.saveTillRules(owner, { ...T.tillRules(), secondCount: 'always' });
  const c2 = count(mgr, cash1, { n100: 5 }, '2026-10-09', till2);
  assert.strictEqual(T.getTillCount(c2.uid).second_status, 'waiting');
  assert.ok(RC.countsWaitingSecond().some((x) => x.uid === c2.uid));
  T.saveTillRules(owner, { ...T.tillRules(), secondCount: 'when_off' });
  const c3 = count(mgr, cash1, { n100: 4, n50: 1 }, '2026-10-08'); // short 50
  assert.strictEqual(T.getTillCount(c3.uid).second_status, 'waiting');
});
test('cashiers over again and again are found', () => {
  ['2026-10-01', '2026-10-02', '2026-10-03'].forEach((d) => count(mgr, cash1, { n100: 5, n20: 1 }, d));
  assert.ok(RC.repeatOvers({ today: '2026-10-20' }).some((p) => p.uid === cash1.uid && p.times >= 3));
  booksOk();
});
done();
