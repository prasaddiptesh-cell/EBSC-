// Tool: how long each module's warnings take on a big database (BIG_DB file), per user role. Not part of npm test.
import { openNodeDb } from '../nodeDb.js';
import { setDb, db } from '../../src/db/connection.js';
import { initDatabase } from '../../src/db/init.js';
import { clock } from '../../src/services/core.js';
const ALERTS = {};
for (const m of ['accounting', 'admin', 'bakery', 'bank', 'devices', 'drawings', 'inventory', 'leave', 'licences', 'loans', 'owed', 'payables', 'payroll', 'sync', 'till', 'timesheets', 'vehicles', 'verify']) ALERTS[m] = await import(`../../src/modules/${m}/alerts.js`);
initDatabase(openNodeDb(process.env.BIG_DB));
clock.override = new Date(`${new Date().toISOString().slice(0, 10)}T09:00:00`);
let n = 0;
const run0 = db().all.bind(db()); const get0 = db().get.bind(db());
const a = db(); a.all = (s, p) => { n++; return run0(s, p); }; a.get = (s, p) => { n++; return get0(s, p); };
for (const pin of ['5001', '5002', '5003']) {
  const u = db().get('SELECT * FROM users WHERE pin = ?', [pin]);
  const rows = [];
  for (const [id, m] of Object.entries(ALERTS)) { const t = Date.now(); n = 0; try { m.alerts(u); } catch (e) { rows.push(`${id} ERROR ${e.message}`); continue; } rows.push(`${id} ${Date.now() - t}ms ${n}q`); }
  console.log(u.role, rows.filter((r) => /ERROR/.test(r) || Number(r.split(' ')[1].replace('ms', '')) > 20 || Number(r.split(' ')[2].replace('q', '')) > 40).join(' | '));
}
