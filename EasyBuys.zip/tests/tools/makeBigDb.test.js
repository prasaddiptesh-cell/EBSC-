// Tool (not part of npm test): makes a database file with the practice logins and 6 months of history, for the
// screen tests on lots of data. Run: BIG_DB=/path/ui-big.db node tests/run.mjs tests/tools/makeBigDb.test.js
import fs from 'fs';
import { openNodeDb } from '../nodeDb.js';
import { initDatabase, allowNewRoles } from '../../src/db/init.js';
import { clock } from '../../src/services/core.js';
import { seedTraining } from '../../src/db/trainingSeed.js';
import { seedHistory } from '../../src/db/trainingHistory.js';

const file = process.env.BIG_DB;
try { fs.unlinkSync(file); } catch (e) { /* new */ }
const a = openNodeDb(file);
initDatabase(a);
try { allowNewRoles(); } catch (e) { /* done */ }
clock.override = new Date(`${new Date().toISOString().slice(0, 10)}T09:00:00`);
seedTraining();
const r = await seedHistory({ days: Number(process.env.DAYS || 168), pause: null });
console.log(JSON.stringify(r.made), r.problems.length ? r.problems.slice(0, 5) : 'no problems');
a.close();
