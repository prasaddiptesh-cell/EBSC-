// Go-live app tour and tutorials: per role, every step's button exists somewhere in the app, progress kept per person.
import fs from 'fs';
import path from 'path';
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as T from '../src/services/tutorials.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const cashier = saveUser({ name: 'Cashier', pin: '7777', role: 'staff', shopCode: 'S1' }, owner);
const payroll = saveUser({ name: 'Pay', pin: '6666', role: 'payroll' }, owner);

test('tutorials per role; the owner sees all; modules switched off are left out', () => {
  const mine = T.tutorialsFor(cashier).map((t) => t.id);
  assert.ok(mine.includes('clock') && mine.includes('till') && !mine.includes('payrun'));
  assert.ok(T.tutorialsFor(payroll).some((t) => t.id === 'payrun'));
  assert.strictEqual(T.tutorialsFor(owner).length, T.TUTORIALS.length);
  assert.ok(!T.tutorialsFor(owner, (m) => m !== 'bakery').some((t) => t.id === 'bakery'));
});
test('every button a step points at exists in the app (testID or tile/menu id)', () => {
  const src = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => { const f = path.join(d, e.name); if (e.isDirectory()) walk(f); else if (f.endsWith('.js')) src.push(fs.readFileSync(f, 'utf8')); });
  walk('src');
  const all = src.join('\n');
  const tiles = Array.from(all.matchAll(/add\('([a-z]+)'/g)).map((m) => `home-${m[1]}`);
  const menus = Array.from(all.matchAll(/\{ id: '([a-z0-9-]+)', icon:/g)).map((m) => `mi-${m[1]}`);
  const ids = new Set(tiles.concat(menus));
  for (const t of [T.TOUR].concat(T.TUTORIALS)) {
    for (const s of t.steps) if (s.testID) assert.ok(ids.has(s.testID) || all.includes(`"${s.testID}"`) || all.includes(`'${s.testID}'`), `${t.id}: ${s.testID} not found`);
  }
});
test('quick check: scored, kept per person, tour seen once', () => {
  assert.ok(!T.tourSeen(cashier));
  T.markTourSeen(cashier);
  assert.ok(T.tourSeen(cashier));
  const r = T.recordTutorial(cashier, 'till', [1, 2]);
  assert.strictEqual(r.score, 1); assert.strictEqual(r.passed, false);
  const r2 = T.recordTutorial(cashier, 'till', [1, 0]);
  assert.ok(r2.passed); assert.strictEqual(r2.tries, 2);
  assert.ok(T.progressAll()[cashier.uid].till.passed);
});
done();
