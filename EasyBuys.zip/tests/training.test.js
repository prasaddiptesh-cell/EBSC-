// Training mode: separate practice database with sample figures; real data untouched; problem log.
import { openNodeDb } from './nodeDb.js';
import { db } from '../src/db/connection.js';
import { startDatabases, enterTraining, leaveTraining, isTraining, trainingProblems } from '../src/platform/training.js';
import { logError, listErrors, problemReport, noteScreen, checkLastClose, markRunning } from '../src/services/errorLog.js';
import { saveUser } from '../src/services/catalog.js';
import { syncNow } from '../src/platform/cloud.js';
import * as P from '../src/modules/payroll/service.js';
import { depositDoc, paymentDoc, invoiceDoc } from '../src/services/taskDocs.js';
import { reportToHtml } from '../src/services/export.js';
import { test, done, assert, throws } from './harness.js';

const files = {};
const open = (name = 'real') => (files[name] = files[name] || openNodeDb());
startDatabases(open);

test('real database starts normally, training off', () => {
  assert.strictEqual(isTraining(), false);
  saveUser({ name: 'Real Owner', pin: '7777', role: 'owner' });
  assert.ok(db().get("SELECT 1 FROM users WHERE pin = '7777'"));
});

test('training: separate database filled with sample figures in every module', () => {
  enterTraining();
  assert.strictEqual(isTraining(), true);
  assert.deepStrictEqual(trainingProblems(), [], trainingProblems().join('\n'));
  assert.ok(!db().get("SELECT 1 FROM users WHERE pin = '7777'"), 'real people not in training');
  const n = (t) => db().get(`SELECT COUNT(*) AS n FROM ${t}`).n;
  for (const t of ['ap_invoices', 'ap_payments', 'till_counts', 'inv_items', 'po_orders', 'pay_profiles', 'punches', 'pay_runs', 'roster_shifts', 'leave_requests', 'applicants', 'money_snaps'])
    assert.ok(n(t) > 0, `sample ${t}`);
  assert.ok(db().get("SELECT 1 FROM users WHERE pin = '5001' AND role = 'owner'"));
});

test('nothing is sent to the cloud in training', async () => {
  const r = await syncNow();
  assert.ok(r.skipped);
});

test('leaving training goes back to the real data; going back keeps the practice entries', () => {
  const runs = db().get('SELECT COUNT(*) AS n FROM pay_runs').n;
  leaveTraining();
  assert.strictEqual(isTraining(), false);
  assert.ok(db().get("SELECT 1 FROM users WHERE pin = '7777'"));
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM ap_invoices").n, 0);
  enterTraining();
  assert.strictEqual(db().get('SELECT COUNT(*) AS n FROM pay_runs').n, runs);
  enterTraining({ fresh: true });
  assert.deepStrictEqual(trainingProblems(), []);
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM users WHERE pin = '5001'").n, 1);
});

test('staff credit (Aronium) needs the receipt photo; taken from pay like other deductions', () => {
  const owner = db().get("SELECT * FROM users WHERE pin = '5001'");
  const mere = db().get("SELECT * FROM users WHERE pin = '5003'");
  throws(() => P.chargeStaff(owner, { userUid: mere.uid, amount: 40, perPay: 20, reason: 'Groceries on credit', source: 'staff_credit', date: '2026-10-08' }), /Aronium receipt/);
  const uid = P.chargeStaff(owner, { userUid: mere.uid, amount: 40, perPay: 20, reason: 'Groceries on credit', source: 'staff_credit', date: '2026-10-08', photos: ['file:///aronium.jpg'] });
  const d = P.listDebts({ userUid: mere.uid }).find((x) => x.uid === uid);
  assert.strictEqual(d.kind, 'staff_credit');
  assert.strictEqual(P.DEBT_LABEL[d.kind], 'Staff credit (Aronium)');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM photos WHERE ref_type = 'charge' AND ref_id = ?", [uid]).n, 1);
});

test('PDFs of a deposit, a cheque and an invoice (with the photo) for the Viber group', () => {
  const dep = depositDoc(db().get('SELECT uid FROM deposits LIMIT 1').uid);
  assert.ok(/deposit/i.test(dep.text) && dep.rep.title.includes('DEP-PR1'));
  const pay = paymentDoc(db().get("SELECT uid FROM ap_payments WHERE method = 'cheque' LIMIT 1").uid);
  assert.ok(/Cheque 500/.test(pay.text), pay.text);
  assert.strictEqual(pay.rep.sections[0].rows.length, 1);
  const inv = invoiceDoc(db().get('SELECT uid FROM ap_invoices LIMIT 1').uid);
  assert.ok(inv.rep.info.some(([k]) => k === 'Supplier'));
  const html = reportToHtml({ ...inv.rep, images: [{ src: 'data:image/jpeg;base64,AAAA', caption: 'Invoice' }] });
  assert.ok(html.includes('data:image/jpeg;base64,AAAA'));
  leaveTraining();
});

test('problem log: errors with the screens before them; unexpected close noticed', () => {
  noteScreen('Home'); noteScreen('Payroll'); noteScreen('PayYearEnd');
  logError(new Error('$ is not a function'), { where: 'screen', screen: 'PayYearEnd' });
  const e = listErrors()[0];
  assert.strictEqual(e.screen, 'PayYearEnd');
  assert.ok(/Payroll › PayYearEnd/.test(e.trail));
  markRunning(true);
  const c = checkLastClose();
  assert.strictEqual(c.where, 'PayYearEnd');
  const rep = problemReport();
  assert.ok(rep.includes('$ is not a function') && rep.includes('closed unexpectedly'));
});

done();
