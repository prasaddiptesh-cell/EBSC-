const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
import { createRequire } from 'module';
import path from 'path';
const require = createRequire('/opt/npm-tools/node_modules/');
const esbuild = require('esbuild');
const here = path.dirname(new URL(import.meta.url).pathname);
const s = (f) => path.join(here, 'shim', f);
await esbuild.build({
  entryPoints: [path.join(here, 'entry.js')], bundle: true, outfile: TMP + '/ui-bundle.js',
  loader: { '.js': 'jsx', '.png': 'dataurl', '.wav': 'dataurl', '.mp3': 'dataurl' }, jsx: 'automatic', nodePaths: ['/opt/npm-tools/node_modules'], format: 'iife',
  define: { 'process.env.NODE_ENV': '"development"' }, logLevel: 'warning',
  alias: {
    'react-native': s('rn.js'), 'react-native-safe-area-context': s('safearea.js'), 'react-native-webview': s('webview.js'),
    'expo-sqlite': s('sqlite.js'), 'expo-status-bar': s('expo.js'), 'expo-keep-awake': s('expo.js'), 'expo-notifications': s('expo.js'),
    'expo-print': s('expo.js'), 'expo-sharing': s('expo.js'), 'expo-file-system/legacy': s('expo.js'), 'expo-image-picker': s('expo.js'),
    'expo-camera': s('expo.js'), 'expo-audio': s('expo.js'), 'expo-document-picker': s('expo.js'), 'expo-image-manipulator': s('expo.js'), jszip: s('jszip.js'),
    '@react-native-ml-kit/text-recognition': s('mlkit.js'),
  },
});
console.log('built');
