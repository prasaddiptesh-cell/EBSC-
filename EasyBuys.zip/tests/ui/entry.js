import React from 'react';
import { createRoot } from 'react-dom/client';
import App from '../../App.js';
window.__face = 'A';
createRoot(document.getElementById('root')).render(<App />);
