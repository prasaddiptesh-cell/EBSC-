const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// Linking devices through the screens: the shop tablet invites a phone (QR code) and a bakers' tablet
// (tap link from a message), staff sync across, a clock-in on the tablet reaches the phone, block / unblock.
import { createRequire } from 'module';
import { execFileSync } from 'child_process';
import fs from 'fs';
import { startServer } from './server.mjs';
const req = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = req('playwright');
const { load } = createRequire(import.meta.url)('../fakeGoogle.cjs');

for (const f of ['t2', 'p2', 'b2', 'x2']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const CLOUD = 'https://script.google.com/macros/s/AKfycbTEST/exec';
const G = load();
G.ctx.setup();
const srv = startServer({ port: PORT + 1 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };

async function device(dev, viewport, initialUrl) {
  const ctx = await b.newContext({ viewport });
  await ctx.route('https://script.google.com/**', async (route) => {
    const body = JSON.parse(route.request().postData() || '{}');
    await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(G.post(body)) });
  });
  const pg = await ctx.newPage();
  if (initialUrl) await pg.addInitScript((u) => { window.__initialUrl = u; }, initialUrl);
  pg.on('pageerror', (e) => errs.push(`${dev} PAGE ${e.message}`));
  pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand/.test(m.text())) errs.push(`${dev} CONSOLE ${m.text().slice(0, 300)}`); });
  await pg.goto(`http://localhost:${PORT + 1}/?dev=${dev}`);
  await pg.waitForTimeout(800);
  const id = (t) => pg.getByTestId(t).first();
  const api = {
    pg, id,
    tap: async (t) => { await id(t).click(); await pg.waitForTimeout(200); },
    has: async (t) => (await pg.getByText(t, { exact: false }).count()) > 0,
    pin: async (p) => { for (const k of p) { await id(`pin-${k}`).click(); await pg.waitForTimeout(60); } await pg.waitForTimeout(300); },
    sync: async () => { for (let i = 0; i < 40 && (await id('force-sync').getAttribute('aria-disabled')) === 'true'; i++) await pg.waitForTimeout(500); await id('force-sync').click({ timeout: 5000 }).catch(() => {}); await pg.waitForTimeout(800); for (let i = 0; i < 30 && !(await pg.getByText('All synced', { exact: false }).count()) && !(await pg.getByText('Sync problem', { exact: false }).count()); i++) await pg.waitForTimeout(500); },
    sql: (sql, params = []) => srv.dbFor(dev).prepare(sql).all(...params),
  };
  return api;
}

// ---------- 1. the shop tablet (first device, linked once with the cloud key)
const T = await device('t2', { width: 1200, height: 900 });
await T.pin('1111');
await T.tap('home-staff'); await T.tap('mi-home');
await T.tap('add-user');
await T.id('user-name').fill('Divnesh Prasad'); await T.id('user-empno').fill('EB001'); await T.id('user-pin').fill('9999');
await T.tap('role-owner'); await T.tap('save-user');
await T.tap('add-user');
await T.id('user-name').fill('Mere Tuilau'); await T.id('user-empno').fill('EB010'); await T.id('user-pin').fill('4321');
await T.tap('save-user');
check('tablet: owner and staff added', await T.has('Divnesh Prasad') && await T.has('Mere Tuilau'));
srv.dbFor('t2').prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('cloud_url', ?), ('cloud_key', 'tablet-key-123'), ('device_name', 'Shop 2 tablet')").run(CLOUD);
await T.tap('logout');
await T.pin('9999');
await T.sync();
check('tablet: synced to the cloud', await T.has('All synced'), await T.id('sync-text').innerText());
const cloudUsers = G.G.books[G.G.props.DATA_ID].getSheetByName('T_users').data.slice(1).map((x) => JSON.parse(x[4]).name);
check('cloud has the real staff, not the sample logins', cloudUsers.includes('Divnesh Prasad') && !cloudUsers.includes('Admin'), cloudUsers.join(', '));

await T.tap('home-admin');
await T.tap('admin-devices');
await T.pg.waitForTimeout(500);
check('Devices screen lists this tablet', await T.has('Shop 2 tablet (this device)'));
check('warns that sample logins are still on this tablet', await T.has('Sample logins are still on this device'));
await T.tap('invite-make');
await T.pg.waitForTimeout(500);
check('QR code shown', (await T.id('invite-qr').count()) > 0);
await T.id('invite-qr').screenshot({ path: TMP + '/ui-invite-qr.png' });
await T.pg.screenshot({ path: TMP + '/ui-devices.png' });
const scanned = execFileSync('python3', ['-c', `import cv2;img=cv2.imread('${TMP}/ui-invite-qr.png');print(cv2.QRCodeDetector().detectAndDecode(img)[0])`]).toString().trim();
check('the QR code on screen really scans (OpenCV)', scanned.startsWith('EB1-'), scanned.slice(0, 30));

// ---------- 2. brother's phone links by scanning the QR code
const P = await device('p2', { width: 400, height: 860 });
check('phone: "Link to Easy Buys" on the login screen', (await P.id('open-link').count()) > 0);
await P.pg.screenshot({ path: TMP + '/ui-phone-login0.png' });
await P.tap('open-link');
await P.pg.screenshot({ path: TMP + '/ui-phone-link.png', fullPage: true });
await P.id('link-name').fill("Brother's phone");
await P.tap('link-kind-phone');
await P.tap('link-scan');
await P.pg.evaluate((t) => window.__scanQr(t), scanned);
for (let i = 0; i < 30 && !(await P.has('This device is linked')); i++) await P.pg.waitForTimeout(500);
await P.pg.screenshot({ path: TMP + '/ui-link-ok.png' });
check('phone: linked and first sync done', await P.has('This device is linked'));
await P.tap('link-finish');
await P.pg.screenshot({ path: TMP + '/ui-phone-login.png' });
check('phone: "Link" button gone once linked', (await P.id('open-link').count()) === 0);
check('phone: sample logins hidden', !(await P.has('Sample logins for testing')));
await P.pin('1111');
await P.tap('login-btn');
check('phone: sample Admin PIN 1111 no longer works', await P.has('Wrong PIN'));
await P.pin('9999');
check('phone: owner logs in with his own PIN', await P.has('Divnesh'));

// ---------- 3. bakers' tablet links from a tapped link (WhatsApp / email)
await T.tap('invite-mode-share');
await T.tap('invite-make');
await T.pg.waitForTimeout(400);
const shared = await T.pg.evaluate(() => (window.__shared || []).slice(-1)[0]);
check('share message has the web link (opens the app) and the code', shared && shared.message.includes(CLOUD + '?link=EB1-') && /\nEB1-/.test(shared.message));
// The web page's "Open in the Easy Buys app" button hands the app this link:
const tapLink = 'easybuys://link?c=' + encodeURIComponent(shared.message.match(/\n(EB1-\S+)/)[1]);
const B = await device('b2', { width: 1100, height: 850 }, tapLink);
check('bakers tablet: tapping the link opens the link screen with the code filled in', (await B.id('link-code').inputValue()).startsWith('EB1-'));
await B.id('link-name').fill('Bakers tablet');
await B.tap('link-go');
await B.pg.getByText('This device is linked', { exact: false }).first().waitFor({ timeout: 15000 }).catch(() => {});
check('bakers tablet: linked', await B.has('This device is linked'));
await B.tap('link-finish');

// a used invite again
const X = await device('x2', { width: 400, height: 860 }, tapLink);
await X.id('link-name').fill('Stranger');
await X.tap('link-go');
await X.pg.waitForTimeout(1200);
check('a used invite is refused', await X.has('already been used'));

// ---------- 4. a clock-in on the shop tablet reaches the phone
await T.tap('logout');
await T.tap('open-clock');
await T.tap('clock-person-EB010');
await T.pin('4321');
await T.tap('clock-IN');
await T.pg.waitForTimeout(600);
check('tablet: Mere clocked in', await T.has('Bula, Mere'));
await T.tap('back');
await T.pin('9999');
await T.sync();
await P.sync();
const onPhone = P.sql("SELECT name, type FROM punches WHERE name = 'Mere Tuilau'");
check('phone has Mere\'s clock-in from the tablet', onPhone.length === 1 && onPhone[0].type === 'IN');

// ---------- 5. block the phone from the tablet, then unblock
await T.tap('home-admin');
await T.tap('admin-devices');
await T.pg.waitForTimeout(600);
check('tablet sees all three devices', await T.has("Brother's phone") && await T.has('Bakers tablet'));
const phoneId = P.sql("SELECT value FROM settings WHERE key = 'device_id'")[0].value;
await T.tap(`block-${phoneId}`);
await T.pg.getByText('Block', { exact: true }).last().click();
await T.pg.waitForTimeout(500);
check('phone shows as Blocked', await T.has('Blocked'));
await P.sync();
for (let i = 0; i < 10 && !(await P.has('This device has been blocked')); i++) await P.pg.waitForTimeout(400);
check('blocked phone is locked at once (logged out)', await P.has('This device has been blocked'));
await T.tap(`allow-${phoneId}`);
await T.pg.waitForTimeout(500);
await P.pg.getByText('Check again', { exact: true }).first().click().catch(() => {});
for (let i = 0; i < 20 && await P.has('This device has been blocked'); i++) await P.pg.waitForTimeout(500);
await P.pin('9999');
await P.sync();
check('unblocked phone syncs again', await P.has('All synced'));
await T.pg.screenshot({ path: TMP + '/ui-devices-list.png' });
await P.tap('home-admin');
await P.tap('admin-devices');
await P.pg.waitForTimeout(600);
await P.pg.screenshot({ path: TMP + '/ui-phone-devices.png', fullPage: true });
check('phone: Devices screen works on a phone too', await P.has("Brother's phone (this device)"));

// ---------- 6. v3.6 device page: status, pause the phone, allow it again
await T.tap(`device-open-${phoneId}`); await T.pg.waitForTimeout(600);
check('device page: status and actions', await T.has('Last synced') && await T.has('Ask the device') && await T.has('Pause access'));
await T.tap('dv-suspend'); await T.pg.waitForTimeout(600);
check('device page: paused', await T.has('Paused'));
await P.sync();
await P.pg.waitForTimeout(500);
check('phone: locked with "Access paused by the owner"', await P.has('Access paused by the owner'));
await T.tap('dv-allow'); await T.pg.waitForTimeout(600);
await P.pg.getByText('Check again', { exact: true }).first().click().catch(() => {});
for (let i = 0; i < 20 && await P.has('Access paused by the owner'); i++) await P.pg.waitForTimeout(500);
check('phone: allowed again, lock gone', !(await P.has('Access paused by the owner')));
await P.pin('9999');
check('phone: owner logs in again', await P.has('Admin') || await P.id('home-admin').count() > 0);
console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
