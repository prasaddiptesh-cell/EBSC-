// The money modules through the screens: invoices & cheques, till count with Z photo, deposit,
// bank reconciliation, payroll (pay details, pay run, change a line, final, payslips), rules screens, phone layout.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m3', 'm3p']) { try { fs.unlinkSync(`/tmp/claude-0/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: 8767 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { await id(t).click(); await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(150); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(250); };
const shot = (n) => pg.screenshot({ path: `/tmp/claude-0/ui-${n}.png`, fullPage: false });
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await back(); };

await pg.goto('http://localhost:8767/?dev=m3'); await pg.waitForTimeout(800);
await pin('1111');
await tap('home-staff'); await tap('add-user');
await id('user-name').fill('Divnesh Prasad'); await id('user-empno').fill('EB001'); await id('user-pin').fill('9999'); await tap('role-owner'); await tap('save-user');
await tap('add-user');
await id('user-name').fill('Mere Tuilau'); await id('user-empno').fill('EB010'); await id('user-pin').fill('4321'); await tap('user-shop'); await tap('user-shop-opt-S2'); await tap('save-user');
await tap('logout'); await pin('9999');
check('owner home shows the new sections', await has('Invoices & cheques') && await has('Till & cash') && await has('Payroll') && await has('Bank reconciliation'));
check('payroll figures warning on home', await has('check the tax and FNPF figures'));
await shot('m-home');

// ---------------------------------------------------------------- invoices & cheques
await tap('home-payables');
check('invoices overview', await has('Owing to suppliers'));
await tap('ap-cheques');
await tap('acc-add'); await id('acc-name').fill('BSP Business Cheque'); await id('acc-open').fill('5000'); await tap('acc-save');
await tap('book-add'); await id('book-first').fill('100201'); await id('book-last').fill('100250'); await tap('book-save');
check('cheque book added, leaves shown', (await id('leaf-100201').count()) > 0 && await has('100250'));
await back();
await tap('ap-suppliers'); await tap('sup-add');
await id('sup-name').fill('RB Patel Group'); await id('sup-tin').fill('500012345'); await tap('sup-account-true'); await id('sup-terms').fill('7'); await tap('sup-save');
check('supplier saved', await has('On account, 7 days'));
await back();
await tap('ap-new');
await tap('inv-supplier'); await text('RB Patel Group');
await id('inv-no').fill('4471'); await id('inv-total').fill('1125');
check('VAT worked out at 12.5%', (await id('inv-vat-preview').innerText()).includes('$125.00'));
await tap('inv-save'); await pg.waitForTimeout(300);
check('invoice saved and shown (checked by owner, not due yet)', await has('Not due yet') && await has('Checked by Divnesh'));
await shot('m-invoice');
await tap('inv-pay');
check('pay screen with the invoice ticked and next cheque number', await has('Pay $1125.00 – cheque 100201') || await has('cheque 100201'));
await tap('pay-save'); await pg.waitForTimeout(200);
await text('Cheque written'); await pg.waitForTimeout(400);
check('payment saved: cheque 100201', await has('Cheque 100201') && await has('not cleared yet'));
await shot('m-payment');
await pg.getByText('4471', { exact: false }).first().click(); await pg.waitForTimeout(300);
check('invoice pay trail shows the cheque', await has('Cheque 100201') && await has('Paid') && await has('by Divnesh'));
await home();

// ---------------------------------------------------------------- till & cash
await tap('home-till');
await tap('till-setup'); await tap('till-add'); await tap('till-shop-S2'); await id('till-name').fill('Till 1'); await id('till-float').fill('200'); await tap('till-save');
check('till added', await has('Float $200.00'));
await back();
await tap('till-count');
await tap('tc-shop-S2'); await pg.waitForTimeout(150);
await id('tc-d-n100').fill('10'); await id('tc-d-n50').fill('4'); await id('tc-d-n20').fill('5'); await id('tc-d-n10').fill('3'); await id('tc-d-n5').fill('2'); await id('tc-d-c2').fill('4'); await id('tc-d-c1').fill('3'); await id('tc-d-c50').fill('2');
check('notes and coins add up', (await id('tc-counted').innerText()).includes('$1352.00'));
await id('tc-z').fill('Z-0412'); await id('tc-ztotal').fill('2000'); await id('tc-zcash').fill('1170');
await id('tc-tender-0-amount').fill('800'); await id('tc-tender-1-amount').fill('30');
await tap('tc-save'); await pg.waitForTimeout(200);
check('short without reason refused', await has('Write the reason') || await has('photo of the Z report'));
await text('OK');
await id('tc-reason').fill('Wrong change given to a customer');
await tap('tc-save'); await pg.waitForTimeout(200);
check('Z report photo required', await has('Take a photo of the Z report'));
await text('OK');
await tap('tc-photo-camera'); await pg.waitForTimeout(200);
await tap('tc-save'); await pg.waitForTimeout(400);
check('count saved: short $18.00', await has('Short $18.00'));
await shot('m-till');
await tap('tc-approve'); await pg.waitForTimeout(300);
check('owner approved', await has('Approved by Divnesh'));
await back();
check('cash on hand at Shop 2 = counted − float', await has('$1152.00'));
await tap('till-deposit');
await tap('dep-shop-S2'); await id('dep-slip').fill('7781');
await id('dep-d-n100').fill('11');
await tap('dep-save'); await pg.waitForTimeout(300);
if (await id('dialog').count()) { console.log('DIALOG:', (await id('dialog').innerText()).replace(/\n/g, ' | ')); await text('OK'); }
check('deposit saved, cash on hand down', await has('$52.00'));
await home();

// ---------------------------------------------------------------- bank reconciliation
await tap('home-bank');
await tap('st-new');
await id('st-from').fill('2026-10-01');
await id('st-open').fill('5000'); await id('st-close').fill('4973.5');
const today = await pg.evaluate(() => { const d = new Date(); return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`; });
await id('st-text').fill(`${today},DEPOSIT 7781,1100.00\n${today},CHQ 100201,-1125.00\n${today},SERVICE FEE,-1.50`);
await tap('st-save'); await pg.waitForTimeout(400);
check('statement added; deposit and cheque matched by themselves', await has('1 line(s) to match') && await has('2 matched'));
await tap('line--1.5'); await tap('new-fee'); await pg.waitForTimeout(300);
check('bank fee added from the statement; balanced', await has('Balanced ✓'));
await tap('st-finish'); await pg.waitForTimeout(300);
await shot('m-bank');
await home();

// ---------------------------------------------------------------- payroll
await tap('home-payroll');
await tap('pay-profiles');
await pg.getByTestId('prof-Mere Tuilau').click(); await pg.waitForTimeout(200);
await id('prof-rate').fill('6'); await id('prof-tin').fill('987654321'); await id('prof-fnpf').fill('F1001');
await tap('prof-save'); await pg.waitForTimeout(200);
check('pay details saved', await has('$6.00/hour'));
await back();
await pg.getByText('This week', { exact: true }).click(); await pg.waitForTimeout(400);
check('pay run made with Mere (no hours yet = warning)', await has('Mere Tuilau') && await has('Draft'));
await tap('line-EB010');
await id('pl-normal').fill('40'); 
await id('pl-reason').fill('Hours from the paper timesheet');
await tap('pl-save'); await pg.waitForTimeout(300);
check('line changed: 40 h × $6 = $240 gross, FNPF $19.20', await has('$240.00') && await has('$19.20'));
await shot('m-payslip');
await back();
await tap('run-final'); await pg.waitForTimeout(200);
await text('Make final'); await pg.waitForTimeout(400);
check('pay run final', await has('Final – Divnesh'));
await pg.getByText('Payslips & reports', { exact: true }).click(); await pg.waitForTimeout(300);
await tap('hub-payslips'); await pg.waitForTimeout(500);
check('payslip report shows NET PAY', await has('NET PAY') && await has('Mere Tuilau'));
await shot('m-payslips');
await home(); await tap('home-payroll');
await tap('pay-rules'); await pg.waitForTimeout(200);
check('payroll rules screen: brackets, FNPF, holidays editable', await has('PAYE (yearly income brackets)') && await has('Public holidays') && (await pg.locator('input[value="Fiji Day"]').count()) > 0);
await tap('pr-confirmed-true'); await tap('pr-save'); await pg.waitForTimeout(200);
await home();
check('payroll warning gone after confirming', !(await has('check the tax and FNPF figures')));

// ---------------------------------------------------------------- modules on/off and reports
await tap('home-admin'); await tap('admin-modules');
check('new modules can be switched off', await has('Invoices & cheques') && await has('Till & cash') && await has('Payroll'));
await home();
await tap('home-reports');
check('reports hub has the new groups', await has('Invoices & cheques') && await has('Till & cash') && await has('Payroll') && await has('Bank'));
await tap('hub-ap_vat'); await pg.waitForTimeout(400);
check('VAT on purchases report', await has('Input VAT') && await has('$125.00'));
await back(); await back();

// ---------------------------------------------------------------- phone layout
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto('http://localhost:8767/?dev=m3'); await ph.waitForTimeout(800);
for (const k of '9999') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(300);
await ph.getByTestId('home-till').first().click(); await ph.waitForTimeout(200);
await ph.getByTestId('till-count').first().click(); await ph.waitForTimeout(300);
const wide = await ph.evaluate(() => document.documentElement.scrollWidth);
check('phone: till count fits the screen', wide <= 400, `width ${wide}`);
await ph.screenshot({ path: '/tmp/claude-0/ui-m-phone-till.png', fullPage: true });

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
