// Inventory through the screens: Aronium import, supplier budget, purchase order (over budget → approval), Viber, receive with a
// price change, cost change review, write-off, transfer, stock take (blind, hand in, approve), reports, phone layout.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m4']) { try { fs.unlinkSync(`/tmp/claude-0/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: 8768 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|unique "key"/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: 8000 }); } catch (e) { await shot('fail'); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(150); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(250); };
const shot = (n) => pg.screenshot({ path: `/tmp/claude-0/ui-${n}.png`, fullPage: false });
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await back(); };

await pg.goto('http://localhost:8768/?dev=m4'); await pg.waitForTimeout(800);
await pin('1111');
check('inventory tile on home', await has('Inventory & orders'));

// supplier (Invoices & cheques)
await tap('home-payables'); await tap('ap-suppliers'); await tap('sup-add');
await id('sup-name').fill('Punjas Ltd'); await id('sup-tin').fill('500012345'); await tap('sup-account-true'); await id('sup-terms').fill('7'); await tap('sup-save');
await home();

// ---------------------------------------------------------------- import
await tap('home-inventory');
check('inventory home with notes beside each action', await has('Receive a delivery') && await has('every unit is accounted for'));
await shot('inv-home');
await tap('inv-import');
await tap('imp-shop-S1');
await id('imp-text').fill('Code;Name;Group;Barcode;Measurement unit;Cost;Price;Taxes;Quantity\n1001;Punjas Flour 10kg;Flour;9300001;bag;"18,50";24.95;VAT 12.5%;40\n1002;Rewa Milk 1L;Dairy;9300002;each;2.10;3.20;VAT 12.5%;120\n');
await pg.waitForTimeout(200);
check('columns guessed', await has('Match the columns (2 rows)'));
await tap('imp-open-y');
await tap('imp-check'); await pg.waitForTimeout(200);
check('preview shows 2 new products', await has('What will happen') && await has('New products'));
await tap('imp-go'); await pg.waitForTimeout(300);
check('imported', await has('Done'));
await back();
await tap('inv-stock');
check('stock list shows the imported stock', await has('Punjas Flour 10kg') && await has('40 bag'));
await tap('st-1001');
check('product screen: all shops table and history', await has('Every shop') && await has('Opening / import'));
await id('pr-lvl').fill('50'); await id('pr-rq').fill('20'); await tap('pr-save-shop');
await back(); await back();

// ---------------------------------------------------------------- budget, PO
await tap('inv-setup');
await tap('set-sup'); await text('Punjas Ltd');
await id('set-bw').fill('300'); await tap('set-sup-save');
check('budget saved', await has('This week: $0.00 used of $300.00'));
await back();
await tap('inv-po'); await tap('po-new');
await tap('pe-sup'); await text('Punjas Ltd');
await tap('pe-suggest'); await pg.waitForTimeout(200);
check('suggestion adds flour (below its reorder level)', await has('Punjas Flour 10kg') && await has('reorder at 50'));
check('budget bar shows over budget', await has('OVER by'));
await shot('inv-po-edit');
await tap('po-submit'); await pg.waitForTimeout(300);
check('over budget → waiting for approval', await has('Waiting for approval'));
await id('pv-reason').fill('Price rise coming'); await tap('pv-approve'); await pg.waitForTimeout(200);
check('approved, send buttons shown', await has('Send by Viber'));
await tap('pv-viber'); await pg.waitForTimeout(200);
const opened = await pg.evaluate(() => (window.__opened || []).join(' '));
check('Viber opened with the order text', opened.startsWith('viber://forward?text=PURCHASE%20ORDER'));
check('marked as sent', await has('Sent to supplier'));
await shot('inv-po-view');

// ---------------------------------------------------------------- receive
await tap('pv-receive');
await id('rc-cost-1001').fill('19.20');
await id('rc-invno').fill('INV-77'); await id('rc-invtotal').fill('432.00');
await tap('rc-save'); await pg.waitForTimeout(300);
check('price change needs a reason', await has('ordered at $18.50, invoiced at $19.20'));
await id('rc-why').fill('Supplier phoned about the rise');
await tap('rc-save'); await pg.waitForTimeout(400);
check('delivery saved with invoice', await has('Delivery received') && await has('INV-77'));
await shot('inv-received');
await home(); await tap('home-inventory');
check('cost change alert', await has('cost price change'));
await tap('inv-costs');
check('cost change listed', await has('$18.50 → $19.20'));
await id('cc-price-1001').fill('26.50'); await tap('cc-ok-1001'); await pg.waitForTimeout(200);
check('checked', await has('Nothing to look at'));
await back();

// ---------------------------------------------------------------- write-off & transfer
await tap('inv-adjust');
await id('adj-find').fill('milk'); await pg.waitForTimeout(200); await tap('adj-find-1002');
await id('adj-qty').fill('3'); await tap('adj-r-Expired'); await tap('adj-save'); await pg.waitForTimeout(200);
check('write-off saved', await has('Recorded'));
await back();
await tap('inv-transfers'); await tap('tr-new'); await tap('tr-to-S2');
await id('tr-find').fill('milk'); await pg.waitForTimeout(200); await tap('tr-find-1002');
await id('tr-qty-0').fill('10'); await tap('tr-send'); await pg.waitForTimeout(200);
check('transfer on the way', await has('ON THE WAY'));
await tap('tr-shop-S2'); await pg.waitForTimeout(150);
await pg.getByText('S1 → S2', { exact: false }).first().click(); await pg.waitForTimeout(200);
await tap('tr-receive'); await pg.waitForTimeout(200);
check('received at S2', await has('RECEIVED'));
await tap('tr-shop-S1');
await back();

// ---------------------------------------------------------------- stock take
await tap('inv-count'); await tap('sc-new');
await tap('sc-scope-all'); await tap('sc-start'); await pg.waitForTimeout(300);
check('stock take started, frozen banner', await has('frozen'));
check('blind: expected numbers hidden', !(await has('expected 55')));
await id('scc-n-1001').fill('54'); await tap('scc-set-1001');
await id('scc-n-1002').fill('107'); await tap('scc-set-1002');
await tap('scc-handin'); await pg.waitForTimeout(300);
check('well off → count again', await has('Count these again'));
await text('OK');
await id('scc-n-1001').fill('54'); await tap('scc-set-1001');
await tap('scc-handin'); await pg.waitForTimeout(300);
check('handed in, waiting for approval', await has('Waiting for approval'));
check('result shows a difference', await has('Differences') && await has('Short'));
await shot('inv-count-review');
await tap('scc-post'); await pg.waitForTimeout(300);
check('posted', await has('Posted'));
await home();

// ---------------------------------------------------------------- reports
await tap('home-reports');
check('reports hub has inventory reports', await has('Stock valuation') && await has('Stock take results') && await has('Received, not invoiced'));
await tap('hub-inv_valuation'); await pg.waitForTimeout(400);
check('valuation report', await has('By shop and group'));
await home();

// ---------------------------------------------------------------- phone layout
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto('http://localhost:8768/?dev=m4'); await ph.waitForTimeout(800);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(300);
await ph.getByTestId('home-inventory').first().click(); await ph.waitForTimeout(200);
let wide = await ph.evaluate(() => document.documentElement.scrollWidth);
check('phone: inventory home fits', wide <= 400, `width ${wide}`);
await ph.getByTestId('inv-po').first().click(); await ph.waitForTimeout(200);
await ph.getByTestId('po-new').first().click(); await ph.waitForTimeout(200);
wide = await ph.evaluate(() => document.documentElement.scrollWidth);
check('phone: new order fits', wide <= 400, `width ${wide}`);
await ph.screenshot({ path: '/tmp/claude-0/ui-inv-phone.png', fullPage: true });

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
