// The newer modules through the screens: staff photo → verify, accounting & VAT, roster planner, who is on,
// recruitment → hire → contract signed on screen, report layout, reports search, backup, phone layout.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m5']) { try { fs.unlinkSync(`/tmp/claude-0/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: 8770 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|unique "key"/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const shot = (n) => pg.screenshot({ path: `/tmp/claude-0/ui-${n}.png`, fullPage: false });
const tap = async (t) => { try { await id(t).click({ timeout: 8000 }); } catch (e) { await shot('fail5'); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(150); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(250); };
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await back(); };

await pg.goto('http://localhost:8770/?dev=m5'); await pg.waitForTimeout(800);
await pin('1111');
check('home grouped into sections', await has('Every day') && await has('Money') && await has('Office'));
await shot('home-sections');

// ---------------------------------------------------------------- staff photo → verify
await tap('home-snap');
await tap('snap-k-cheque_given'); await tap('snap-shop-S2');
await tap('snap-photo-camera').catch(async () => { await pg.getByText('Camera', { exact: false }).first().click(); });
await pg.waitForTimeout(200);
await id('snap-party').fill('RB Patel'); await id('snap-ref').fill('100201'); await id('snap-amount').fill('450'); await id('snap-who').fill('Ravi (driver)');
await tap('snap-save'); await pg.waitForTimeout(300);
check('photo saved, Viber share offered', await has('Photo saved') && await has('Tell the Viber group'));
await tap('snap-viber'); await pg.waitForTimeout(100);
check('Viber opened with the message', (await pg.evaluate(() => (window.__opened || []).join(' '))).includes('viber://forward?text=Easy%20Buys'));
await home();
await tap('home-verify');
check('to verify list shows the photo', await has('Cheque handed over'));
await pg.getByText('Cheque handed over', { exact: false }).first().click(); await pg.waitForTimeout(200);
await tap('vf-confirm'); await pg.waitForTimeout(200);
check('confirmed', !(await has('Photo to confirm')) || await has('Nothing waiting'));
await home();

// ---------------------------------------------------------------- accounting
await tap('home-accounting');
check('accounting home explains itself', await has('How the books work here') && await has('VAT return'));
await tap('acc-vat');
check('VAT return screen', await has('Output VAT') && await has('Input VAT'));
await back();
await tap('acc-pl'); check('profit & loss', await has('NET PROFIT')); await back();
await tap('acc-tb'); check('trial balance balances', await has('Debits')); await back();
await tap('acc-month'); check('month end checklist', await has('Checked by the app')); await back();
await home();

// ---------------------------------------------------------------- roster
await tap('home-roster');
check('roster planner', await has('Roster planner') && await has('What the roster is for'));
await pg.getByTestId(/^rp-/).first();
const cell = pg.locator('[data-testid^="rp-Admin-"]').first();
if (await cell.count()) { await cell.click(); await pg.waitForTimeout(200); await tap('rp-t-Morning'); await tap('rp-save'); await pg.waitForTimeout(200); }
check('shift planned', await has('Planned hours'));
await home();

// ---------------------------------------------------------------- recruitment → hire → contract
await tap('home-recruit');
await tap('rc-new-job'); await id('op-title').fill('Cashier'); await tap('op-save'); await pg.waitForTimeout(200);
await back();
await tap('rc-new-app'); await id('ap-name').fill('Losana Vula'); await id('ap-phone').fill('7001234'); await id('ap-email').fill('losana@example.com'); await tap('ap-save'); await pg.waitForTimeout(200);
await tap('ap-hire'); await id('hire-rate').fill('5.60'); await tap('hire-go'); await pg.waitForTimeout(300);
check('hired: PIN shown', await has('Time Clock PIN'));
await text('OK');
check('onboarding checklist', await has('Onboarding · Losana Vula'));
await tap('ob-make-contract'); await pg.waitForTimeout(300);
check('contract filled in', await has('Losana Vula') && await has('$5.60 an hour'));
await tap('ct-agree-y'); await tap('ct-sig-draw'); await tap('ct-sign-emp'); await pg.waitForTimeout(200);
await tap('ct-sig2-draw'); await tap('ct-sign-er'); await pg.waitForTimeout(300);
check('signed by both, email queued', await has('signed by both'));
await shot('contract');
await home();

// ---------------------------------------------------------------- reports
await tap('home-reports');
await id('hub-search').fill('vat'); await pg.waitForTimeout(200);
check('search finds the VAT reports', await has('VAT return') && !(await has('Stock valuation')));
await tap('fav-acc_vat'); await id('hub-search').fill(''); await pg.waitForTimeout(150);
check('favourites shown', await has('★ Favourites'));
await home();
await tap('home-admin'); await tap('admin-templates');
await id('rt-name').fill('Easy Buys Supermarkets'); await tap('rt-save'); await pg.waitForTimeout(200);
check('report layout saved', await has('Saved'));
await back(); await tap('admin-backup');
check('backup screen', await has('How backups work'));
await home();

// ---------------------------------------------------------------- phone layout
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto('http://localhost:8770/?dev=m5'); await ph.waitForTimeout(800);
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(300);
for (const t of ['home-accounting', 'home-recruit']) {
  await ph.getByTestId(t).first().click(); await ph.waitForTimeout(250);
  const w = await ph.evaluate(() => document.documentElement.scrollWidth);
  check(`phone: ${t} fits`, w <= 400, `width ${w}`);
  await ph.getByTestId('back').first().click(); await ph.waitForTimeout(200);
}

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
