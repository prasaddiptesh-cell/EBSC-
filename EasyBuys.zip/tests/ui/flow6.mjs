const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// Problem log & screen check (every screen opens without a problem), Year end / Final pay, training mode,
// login sample panel follows the real sample logins.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m6', 'm6-easybuys-training.db']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 6 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { await id(t).click({ timeout: 8000 }); await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };

await pg.goto(`http://localhost:${PORT + 6}/?dev=m6`); await pg.waitForTimeout(800);
check('sample logins panel lists the sample logins', await has('Admin: PIN 1111'));
await pin('1111');
await tap('home-admin');
await tap('admin-problems');
check('problem log opens', await has('Problem log & screen check') && await has('Nothing has gone wrong'));
await tap('pr-check'); await text('Start check');
await pg.getByText('Screen check', { exact: true }).first().waitFor({ timeout: 240000 });
const body = await pg.locator('body').innerText();
const m = body.match(/(All \d+ screens opened without a problem|\d+ of \d+ screens had a problem[^\n]*)/);
check('every screen opens without a problem', /^All /.test(m ? m[1] : ''), m ? m[1] : 'no result');
if (!/^All /.test(m ? m[1] : '')) console.log(body.slice(body.indexOf('Screen check'), body.indexOf('Screen check') + 3000));
await pg.screenshot({ path: TMP + '/ui-screencheck.png' });

// Year end and final pay (the screens that closed the app).
for (let i = 0; i < 6 && !(await id('home-admin').count()); i++) await tap('back');
await tap('home-payroll'); await tap('mi-home');
await text('Year end'); check('year end opens', await has('PAYE not paid') && !(await id('screen-error').count())); await tap('back');
await text('Someone leaving'); check('final pay opens', await has('Who is leaving?') && !(await id('screen-error').count())); await tap('back');
for (let i = 0; i < 6 && !(await id('home-admin').count()); i++) await tap('back');

// Training mode.
await tap('home-admin'); await tap('admin-training');
await tap('tr-on'); await text('Switch to training'); await pg.getByTestId('training-bar').first().waitFor({ timeout: 15000 }).catch(() => {}); await pg.waitForTimeout(500);
check('training: orange bar with practice PINs on the login', await id('training-bar').count() > 0 && await has('Owner 5001'));
check('training: real sample panel hidden', !(await id('demo-pins').count()));
await pin('5001');
check('practice owner logged in', await id('home-admin').count() > 0);
await tap('home-payables'); await tap('mi-home');
check('practice invoices there', await has('Punjas (practice)') || await has('practice'));
for (let i = 0; i < 6 && !(await id('home-admin').count()); i++) await tap('back');
await tap('home-admin'); await tap('admin-training');
await tap('tr-off'); await text('Back to real data'); await pg.waitForTimeout(800);
check('back to real data: no bar', !(await id('training-bar').count()));
await pin('5001');
check('practice PIN does not work on the real data', !(await id('home-admin').count()));
console.log(errs.length ? 'ERRORS:\n' + errs.slice(0, 10).join('\n') : 'no page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close(); srv.close();
process.exit(fails ? 1 : 0);
