// Version 3.4 through the screens: company contract PDF signed and stamped, licences & permits with documents and
// renewal, full accounting (typed expense, Aronium figures checked, tax centre, statements), contractor provisional tax,
// app updates, structure of Home and Admin.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
const FX = JSON.parse(fs.readFileSync(new URL('./fixtures/contract.json', import.meta.url)));
for (const f of ['m7']) { try { fs.unlinkSync(`/tmp/claude-0/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: 8772 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
const id = (t) => pg.getByTestId(t).first();
const shot = (n) => pg.screenshot({ path: `/tmp/claude-0/ui-${n}.png` });
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: 8000 }); } catch (e) { await shot('fail7'); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await back(); };
const dialog = async () => ((await id('dialog').count()) ? (await id('dialog').innerText()).replace(/\n/g, ' | ') : '');

await pg.goto('http://localhost:8772/?dev=m7'); await pg.waitForTimeout(800);
await pg.evaluate((fx) => { window.__sigData = fx.sig; window.__manipB64 = fx.stamp; }, FX);
await pin('1111');
check('home by business area', await has('Finance & Accounting') && await has('Governance & Compliance'));

// ---------------------------------------------------------------- company contract PDF
await tap('home-admin');
check('admin by business area', await has('1. Finance & Accounting') && await has('4. Governance, Risk & Compliance') && await has('7. Help & support'));
await tap('admin-contractpdf');
await pg.evaluate((fx) => { window.__pickFile = { name: 'Easy Buys contract.pdf', mime: 'application/pdf', data: fx.tpl }; }, FX);
await tap('cps-upload'); await pg.waitForTimeout(500);
check('contract PDF uploaded', await has('Easy Buys contract.pdf'));
await pg.evaluate(() => { window.__pickFile = null; });
await id('cps-dir-name').fill('Divnesh Avnil Prasad');
await tap('cps-dir-open'); await tap('cps-dir-draw'); await tap('cps-dir-done');
await tap('cps-dir-save'); await pg.waitForTimeout(200);
await tap('cps-stamp-camera'); await pg.waitForTimeout(200);
await tap('cps-stamp-save'); await pg.waitForTimeout(500);
check('director signature and stamp saved', !(await has("Save the director's signature and the stamp so")) || (await dialog()) === '', await dialog());
await tap('cps-add'); await tap('cps-save'); await pg.waitForTimeout(200);
await tap('cps-preview'); await pg.waitForTimeout(1500);
const shared = await pg.evaluate(() => (window.__shared || []).map((x) => (Array.isArray(x) ? x[0] : x.message || '')).join(' '));
check('preview PDF made and shared', /Contract-preview\.pdf/.test(shared), shared.slice(-120));
await tap('cps-on-y'); await pg.waitForTimeout(200);
await home();
await tap('home-recruit');
await tap('rc-new-app'); await id('ap-name').fill('Seini Tuilau'); await id('ap-phone').fill('7001111'); await id('ap-email').fill('seini@example.com'); await tap('ap-save'); await pg.waitForTimeout(200);
await tap('ap-hire'); await id('hire-rate').fill('5.60'); await tap('hire-go'); await pg.waitForTimeout(300);
await text('OK');
await tap('ob-make-contract'); await pg.waitForTimeout(300);
check('contract uses the company PDF', await has("This is the company's own contract (PDF)"));
await tap('ct-read'); await pg.waitForTimeout(1200);
await tap('ct-agree-y'); await tap('ct-sig-open'); await tap('ct-sig-draw'); await tap('ct-sig-done'); await tap('ct-sign-emp'); await pg.waitForTimeout(200);
await tap('ct-approve'); await pg.waitForTimeout(2500);
check('approved: signed PDF made with director signature and stamp', await has('Open / share the signed contract'), await dialog());
await tap('ct-open-signed'); await pg.waitForTimeout(800);
check('signed PDF opens', (await pg.evaluate(() => JSON.stringify(window.__shared || []))).includes('/doc/docs/'));
await home();

// ---------------------------------------------------------------- licences & permits
await tap('home-licences');
await tap('lic-quick'); await tap('lq-0'); await tap('lq-6'); await tap('lq-add'); await pg.waitForTimeout(300);
check('quick add: liquor licence per shop + company annual return', await has('Liquor licence – Shop 1') || await has('Liquor licence'));
await pg.getByText('Company annual return', { exact: false }).first().click(); await pg.waitForTimeout(200);
await tap('lic-finish').catch(() => {});
await pg.waitForTimeout(100);
await id('lic-new-exp').locator('input').first().fill('2026-10-30').catch(async () => { await id('lic-new-exp').fill('2026-10-30'); });
await tap('lic-finish-save'); await pg.waitForTimeout(200);
check('expiry set; reminder shows', await has('Renew soon') || await has('days left'), await dialog());
await tap('ld-add'); await tap('ld-kind-application');
await pg.evaluate(() => { window.__pickFile = { name: 'Annual return form.pdf', mime: 'application/pdf', data: 'JVBERi0xLjQK' }; });
await tap('ld-pick'); await tap('ld-save'); await pg.waitForTimeout(400);
check('application document kept', await has('Annual return form.pdf'));
await pg.evaluate(() => { window.__pickFile = null; });
await home();
check('home banner: licence to renew', await has('to renew soon'));

// ---------------------------------------------------------------- accounting
await tap('home-accounting');
check('accounting menu: daily, records, tax, reports, period end, setup', await has('Daily tasks') && await has('Period end') && await has('Setup'));
await tap('acc-entry'); await tap('ae-k-expense');
await id('ae-total').fill('112.50');
await tap('ae-account'); await text('6030 Repairs & maintenance');
await id('ae-supplier').fill('Hardware shop');
await tap('ae-save'); await pg.waitForTimeout(300);
check('typed expense saved', await has('Typed entries') && await has('Hardware shop'), await dialog());
await back();
await tap('acc-aronium'); await tap('ar-import');
await id('ai-text').fill('Date;Total;Tax;Cash;Card\n05/10/2026;450,00;50,00;300;150\n06/10/2026;225;25;225;0\n');
await pg.waitForTimeout(300);
check('Aronium preview', await has('Preview (2 row(s))'));
await tap('ai-bring'); await pg.waitForTimeout(300);
check('waiting to be checked', await has('To check') && await has('Booked from Aronium'));
await tap('ab-approve'); await pg.waitForTimeout(300);
check('approved into the books', await has('Approved – in the books'), await dialog());
await back(); await back();
await tap('acc-tax');
check('tax centre', await has('Provisional tax') && await has('Company advance tax'));
await id('tx-last').fill('9000'); await text('Save'); await pg.waitForTimeout(200);
check('advance tax instalments listed', await has('Instalment 1'));
await back();
await tap('acc-year'); await tap('ye-fs'); await pg.waitForTimeout(800);
check('financial statements PDF', (await pg.evaluate(() => window.__lastHtml || '')).includes('Statement of financial position'));
await back();
await tap('acc-cashbook'); check('cash book', await has('Cash book'));
await back();
await tap('acc-forecast'); check('forecast', await has('Lowest cash expected'));
await back();
await home();

// ---------------------------------------------------------------- contractor: provisional tax shown when paying
await tap('home-admin'); await tap('admin-suppliers');
await text('+ Supplier').catch(() => {});
await pg.waitForTimeout(200);
await home();

// ---------------------------------------------------------------- app updates
await tap('home-admin'); await tap('admin-updates');
await id('up-repo').fill('bad repo'); await tap('up-save'); await pg.waitForTimeout(200);
check('repository name checked', (await dialog()).includes('owner/name'));
await text('OK');
await id('up-repo').fill('easybuys/easybuys-app'); await tap('up-save'); await pg.waitForTimeout(200);
check('repository saved', await has('Saved') || !(await dialog()));
await home();

// ---------------------------------------------------------------- every screen still opens
await tap('home-admin'); await tap('admin-problems');
await tap('pr-check'); await text('Start check');
await pg.getByText('Screen check', { exact: true }).first().waitFor({ timeout: 300000 });
const body = await pg.locator('body').innerText();
const m = body.match(/(All \d+ screens opened without a problem|\d+ of \d+ screens had a problem[^\n]*)/);
check('every screen opens (with data in them)', /^All /.test(m ? m[1] : ''), m ? m[1] : 'no result');
if (!/^All /.test(m ? m[1] : '')) console.log(body.slice(body.indexOf('Screen check'), body.indexOf('Screen check') + 2500));
console.log(errs.length ? 'ERRORS:\n' + errs.slice(0, 10).join('\n') : 'no page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close(); srv.close();
process.exit(fails ? 1 : 0);
