const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 inputs: DateField quick buttons, calendar and typing; TimeField Now / clock / 12-hour setting; PeriodPicker;
// a searchable drop-down; scroll and search remembered when going back; admin saves a timesheet change without a
// reason while a manager is still asked for one.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m8']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 8 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 4).join('\n')));
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); await pg.waitForTimeout(150); };
const goHome = async () => { for (let k = 0; k < 8 && !(await pg.getByTestId('home-admin').count()); k++) { if (!(await pg.getByTestId('back').count())) break; await pg.getByTestId('back').first().click(); await pg.waitForTimeout(200); } };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const val = async (t) => id(t).inputValue();
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()) && !(await id('home-timesheets').count()); i++) await tap('back'); };
const dialog = async () => ((await id('dialog').count()) ? (await id('dialog').innerText()).replace(/\n/g, ' | ') : '');
const shot = (n) => pg.screenshot({ path: `${TMP}/ui-f8-${n}.png` });

// The same plain-words date the app shows ("Tue 13 Oct 2026").
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const nice = (d) => `${WD[d.getDay()]} ${d.getDate()} ${MO[d.getMonth()]} ${d.getFullYear()}`;
const now = new Date();
const plus = (n) => { const x = new Date(now); x.setDate(x.getDate() + n); return x; };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

await pg.goto('http://localhost:' + (PORT + 8) + '/?dev=m8'); await pg.waitForTimeout(800);
await pin('1111');
check('admin logged in', (await id('home-admin').count()) > 0);

// ---------------------------------------------------------------- staff (and a remembered search)
await goHome(); await tap('home-staff'); await tap('mi-home');
await tap('add-user');
await id('user-name').fill('Mere Tuilau'); await id('user-empno').fill('EB010'); await id('user-pin').fill('4321');
await tap('user-shop'); await tap('user-shop-opt-S2'); await tap('save-user');
await tap('add-user');
await id('user-name').fill('Anita Manager'); await id('user-empno').fill('EB002'); await id('user-pin').fill('8888');
await tap('role-manager'); await tap('user-shop'); await tap('user-shop-opt-S2'); await tap('save-user');
check('staff added (shop chosen from the drop-down)', await has('Mere Tuilau') && await has('Anita Manager'));
await id('staff-search').fill('Mere');
await pg.getByTestId('user-Mere Tuilau').click(); await pg.waitForTimeout(200);
await tap('back');
check('search text remembered after going back', (await val('staff-search')) === 'Mere', await val('staff-search'));
await id('staff-search').fill('');
for (let i = 0; i < 6 && !(await id('home-admin').count()); i++) await tap('back');

// ---------------------------------------------------------------- DateField (leave request)
await goHome(); await tap('home-leave'); await tap('mi-home');
if (await id('leave-tab-mine').count()) await tap('leave-tab-mine');
await tap('leave-from-today');
check('Today button fills today, shown as "Tue 13 Oct 2026"', (await val('leave-from')) === nice(now), await val('leave-from'));
await tap('leave-from-tomorrow');
check('Tomorrow button', (await val('leave-from')) === nice(plus(1)), await val('leave-from'));
await tap('leave-from-yesterday');
check('Yesterday button', (await val('leave-from')) === nice(plus(-1)), await val('leave-from'));
await tap('leave-from-cal');
check('calendar pop-up opens with the month grid and columns', (await id('leave-from-calendar').count()) > 0 && await has('Use this date'));
await shot('calendar');
await tap('leave-from-cal-next'); await tap('leave-from-cal-day-15');
const nextM = new Date(plus(-1).getFullYear(), plus(-1).getMonth() + 1, 15);
check('tap a day in next month', (await val('leave-from')) === nice(nextM), await val('leave-from'));
await tap('leave-from-cal');
await tap('leave-from-col-d-20'); await tap('leave-from-col-m-12'); await tap(`leave-from-col-y-${now.getFullYear() + 1}`); await tap('leave-from-cal-ok');
check('day / month / year columns', (await val('leave-from')) === nice(new Date(now.getFullYear() + 1, 11, 20)), await val('leave-from'));
await id('leave-from').fill('31/2/2027');
check('31 Feb refused in plain words as you type', await has('February 2027 has 28 days'));
await id('leave-from').fill(iso(plus(500)));
check('far-away date: gentle warning', await has('please check the date is right'));
await id('leave-from').fill('2026-12-01'); await id('leave-to').fill('3/12/2026');
await pg.getByText('First day', { exact: true }).click();
check('typed dates (ISO and 3/12/2026) both work', (await val('leave-from')) === 'Tue 1 Dec 2026' && (await val('leave-to')) === 'Thu 3 Dec 2026', `${await val('leave-from')} / ${await val('leave-to')}`);
await home();

// ---------------------------------------------------------------- 12-hour times (admin setting)
await goHome(); await tap('home-admin'); await tap('admin-cloud');
await tap('time-format-12h'); await tap('save-settings');
check('time format saved', await has('Settings saved'));
await home();

// ---------------------------------------------------------------- PeriodPicker in the reports hub
await goHome(); await tap('home-reports');
check('period drop-down shows this pay week', /Sat \d+/.test(await id('hub-period-shown').innerText()), await id('hub-period-shown').innerText());
await tap('hub-period'); await tap('hub-period-opt-lastmonth');
const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
check('Last month', (await id('hub-period-shown').innerText()).includes(`${MONTHS[lm.getMonth()]} ${lm.getFullYear()}`), await id('hub-period-shown').innerText());
await tap('hub-period'); await tap('hub-period-opt-custom');
await id('hub-period-from').fill('1/10/2026'); await id('hub-period-to').fill('2026-10-05');
check('Choose dates…: own from / to', (await id('hub-period-shown').innerText()).includes('Thu 1 Oct – Mon 5 Oct 2026'), await id('hub-period-shown').innerText());
await tap('hub-tc_week'); await pg.waitForTimeout(300);
check('report opens for that period, with the period drop-down', (await id('rv-period').count()) > 0 && (await id('rv-period-shown').innerText()).includes('Thu 1 Oct'));
await tap('back');
check('period remembered on going back', (await id('hub-period-shown').innerText()).includes('Thu 1 Oct – Mon 5 Oct 2026'));
await home();

// ---------------------------------------------------------------- searchable drop-down
await goHome(); await tap('home-accounting'); await tap('mi-home');
await tap('acc-entry'); await tap('ae-k-expense');
await tap('ae-account');
check('long list has a search box', (await id('ae-account-search').count()) > 0);
await id('ae-account-search').fill('repairs');
const optCount = await pg.locator('[data-testid^="ae-account-opt-"]').count();
check('search narrows the list', optCount >= 1 && optCount <= 3, String(optCount));
await text('6030 Repairs & maintenance');
check('picked from the searched list', await has('6030 Repairs & maintenance'));
await home();

// ---------------------------------------------------------------- scroll position remembered
await pg.setViewportSize({ width: 420, height: 760 });
// In the browser stand-in, let the screen body scroll inside the window like on the phone (flex items may shrink).
const fit = await pg.addStyleTag({ content: '#root div:has([data-scroll]) { min-height: 0; }' });
await goHome(); await tap('home-admin'); await pg.waitForTimeout(200);
const scroller = pg.locator('[data-scroll="1"]').first();
await scroller.evaluate((el) => { el.scrollTop = 700; el.dispatchEvent(new Event('scroll')); });
await pg.waitForTimeout(300);
const y0 = await scroller.evaluate((el) => el.scrollTop);
await tap('admin-audit'); await pg.waitForTimeout(200);
await tap('back'); await pg.waitForTimeout(400);
const y1 = await pg.locator('[data-scroll="1"]').first().evaluate((el) => el.scrollTop);
check('scroll position kept when going back', y0 > 300 && Math.abs(y1 - y0) < 5, `${y0} -> ${y1}`);
await fit.evaluate((el) => el.remove());
await pg.setViewportSize({ width: 1200, height: 900 });
await home();

// ---------------------------------------------------------------- timesheet change: admin needs no reason
await goHome(); await tap('home-timesheets'); await tap('mi-home');
await tap('week-prev'); await pg.waitForTimeout(200);
await tap('ts-row-EB010'); await pg.waitForTimeout(300);
const ws = await pg.locator('[data-testid^="grid-day-"]').first().getAttribute('data-testid');
const day = ws.replace('grid-day-', '');
await tap(`grid-${day}-in`);
check('admin sees the reason as optional', await has('Reason (optional)'));
await tap('tp-hour-7'); await tap('tp-minute-30');
await tap('grid-save'); await pg.waitForTimeout(300);
check('admin saves with no reason', !(await dialog()) && await has('7:30 am'), await dialog());
await shot('grid-admin');
await home();
await tap('logout'); await pin('8888');
check('manager logged in', await has('Anita Manager'));
await goHome(); await tap('home-timesheets'); await tap('mi-home');
await tap('week-prev'); await pg.waitForTimeout(200);
await tap('ts-row-EB010'); await pg.waitForTimeout(300);
await tap(`grid-${day}-out`);
check('manager still sees "Reason (required)"', await has('Reason (required)'));
await tap('tp-pm'); await tap('tp-hour-5'); await tap('tp-minute-0');
await tap('grid-save'); await pg.waitForTimeout(300);
const d1 = await dialog();
check('manager is asked for the reason', /reason/i.test(d1), d1);
if (d1) await text('OK');
await id('grid-reason').fill('Paper timesheet');
await tap('grid-save'); await pg.waitForTimeout(300);
check('manager saves with a reason', !(await dialog()) && await has('5:00 pm'), await dialog());
await home();

// ---------------------------------------------------------------- TimeField: Now and the clock
await goHome(); await tap('home-timesheets'); await tap('mi-home');
await tap('week-prev'); await pg.waitForTimeout(200);
await tap('ts-row-EB010'); await pg.waitForTimeout(300); await pg.getByText('Every punch', { exact: true }).click(); await pg.waitForTimeout(300);
await tap('fix-add');
await tap('fix-at-time-now');
const h = now.getHours();
const nowTxt = (await val('fix-at-time'));
check('Now fills the time (12-hour)', /^\d{1,2}:\d{2} (am|pm)$/.test(nowTxt) && nowTxt.endsWith(h >= 12 ? 'pm' : 'am'), nowTxt);
await tap('fix-at-time-clock');
await tap('fix-at-time-face-am'); await tap('fix-at-time-face-hour-6'); await tap('fix-at-time-face-minute-45'); await tap('fix-at-time-face-adj1');
await tap('fix-at-time-clock-ok');
check('clock: hour, then minutes, then fine adjust', (await val('fix-at-time')) === '6:46 am', await val('fix-at-time'));
await id('fix-at-time').fill('25:00');
check('impossible time explained', await has('Hours go from 0 to 23'));
await id('fix-at-time').fill('6:50');
await id('fix-at-date').fill(day);
await id('fix-reason').fill('Came early');
await tap('fix-save'); await pg.waitForTimeout(300);
check('punch added from the date and time fields', await has('Reason: Came early'), await dialog());

console.log(errs.length ? 'ERRORS:\n' + errs.slice(0, 10).join('\n') : 'no page errors');
if (errs.length) fails++;
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close(); srv.close();
process.exit(fails ? 1 : 0);
