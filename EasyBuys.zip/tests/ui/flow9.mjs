const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 app shell: About (login ⓘ and Admin), module menus, Home search and scan, warnings (top 3, + more, tap-through,
// hide until tomorrow, urgent strip with sound until OK), Sync now (grey / green / red, Retry), Backup & restore list
// (tablet, outside folder, Google Drive), health check, shops & cost areas, phone width.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const req = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = req('playwright');
const { load } = createRequire(import.meta.url)('../fakeGoogle.cjs');

for (const f of ['m9']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
fs.rmSync(`${TMP}/fs-m9`, { recursive: true, force: true });
const CLOUD = 'https://script.google.com/macros/s/AKfycbTEST9/exec';
const G = load();
G.ctx.setup();
const srv = startServer({ port: PORT + 9 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
let offline = false;
await ctx.route('https://script.google.com/**', async (route) => {
  if (offline) { await route.abort('internetdisconnected'); return; }
  const body = JSON.parse(route.request().postData() || '{}');
  await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(G.post(body)) });
});
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: 8000 }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-f9-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const body = async () => pg.locator('body').innerText();
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await tap('back'); };
const sql = (q, p = []) => srv.dbFor('m9').prepare(q).run(...p);

await pg.goto(`http://localhost:${PORT + 9}/?dev=m9`); await pg.waitForTimeout(900);

// ---------------------------------------------------------------- start-up check, login footer, About from the login
const hc = srv.dbFor('m9').prepare("SELECT status, results FROM health_checks WHERE kind = 'quick' ORDER BY id DESC LIMIT 1").get();
check('health check ran on opening and was kept', !!hc && hc.status === 'ok', hc ? hc.status : 'none');
check('login footer', await has('Easy Buys v3.5.0 · © 2026 Easy Buys Shopping Centre'));
await tap('login-about');
check('About from the login ⓘ', await has('About Easy Buys') && await has('Version 3.5.0 (build 3)') && await has('Built by Easy Buys Shopping Centre, Lautoka, Fiji'));
check('About: support contact', await has('Diptesh Avnil Prasad') && await has('+679 900 8193') && await has('prasaddiptesh@gmail.com'));
check('About: copyright and legal notice', await has('© 2026 Easy Buys Shopping Centre. All rights reserved.') && await has('confidential company property'));
check('About: this device and technical details', await has('This device') && await has('Database version') && await has('Cloud script version'));
await tap('about-new');
check("What's new for 3.5", await has('Version 3.5.0') && await has('Home has a search box'));
await tap('back'); await tap('about-oss');
check('open-source notices', await has('Open-source notices') && await has('pdf-lib') && await has('MIT'));
await tap('back'); await tap('back');
check('back to the login', (await id('pin-1').count()) > 0);

// Warnings to show: an expired licence (urgent) and one to renew soon (warning).
const now = new Date();
const d = (n) => { const x = new Date(now.getTime() + n * 86400000); return x.toISOString().slice(0, 10); };
sql("INSERT INTO licences (uid, name, category, expiry_date, remind_days, status, updated_at) VALUES ('LICX', 'Liquor Licence Shop 1', 'licence', ?, 60, 'active', '2026-01-01 00:00:00')", [d(-3)]);
sql("INSERT INTO licences (uid, name, category, expiry_date, remind_days, status, updated_at) VALUES ('LICY', 'Food Permit Shop 2', 'permit', ?, 60, 'active', '2026-01-01 00:00:00')", [d(20)]);
await pin('1111');
await pg.waitForTimeout(400);

// ---------------------------------------------------------------- Home warnings
const w = await pg.getByTestId(/^alert-open-/).allInnerTexts();
check('Home shows the 3 most urgent warnings, urgent first', w.length === 3 && /EXPIRED/.test(w[0]), w.map((x) => x.split('\n')[0]).join(' | '));
check('"+ x more" under them', await has('more warning'));
check('urgent one cannot be hidden', (await id('alert-hide-lic-LICX-overdue').count()) === 0 && (await id('alert-hide-pay-rules').count()) === 1);
await pg.waitForTimeout(1800);
check('urgent strip shows and the alarm repeats', (await id('urgent-popup').count()) > 0 && await pg.evaluate(() => !!window.__soundLoop && (window.__sounds || []).some((s) => s.loop)));
await tap('urgent-ok');
check('OK stops the alarm', (await id('urgent-popup').count()) === 0 && await pg.evaluate(() => !window.__soundLoop));
await tap('alert-open-lic-LICX-overdue');
check('tapping the warning opens the exact licence', await has('Liquor Licence Shop 1') && (await id('home-search').count()) === 0);
await home();
await tap('alerts-more');
check('full warnings list', await has('Warnings') && await has('Food Permit Shop 2') && await has('Choose a folder outside the app'));
await tap('alert-hide-pay-rules');
check('hidden until tomorrow', !(await has('Payroll: check the tax and FNPF figures')) && await has('hidden today'));
await tap('warnings-unhide');
check('hidden ones can be shown again', await has('Payroll: check the tax and FNPF figures'));
await tap('alert-hide-pay-rules');
await home();
check('hidden one stays off Home', !(await has('Payroll: check the tax and FNPF figures')));

// ---------------------------------------------------------------- module menus
await tap('home-payables');
const mtext = await body();
const order = ['Daily tasks', 'Records', 'Checks', 'Reports', 'Settings'].map((s) => mtext.indexOf(`\n${s}\n`));
check('module menu: sections in the fixed order', order.every((x, i) => x > 0 && (i === 0 || x > order[i - 1])), order.join(','));
check('module menu: hidden tabs are items', await has('Cheque books') && await has('Cheque register') && await has('Deposits & bank fees'));
await tap('mi-chq-books');
check('menu item opens the screen on that part', await has('Cheques & bank') || await has('Bank accounts') || await has('cheque'));
await tap('back'); await tap('mi-home');
check('main screen of the module', await has('Owing to suppliers'));
await home();
await tap('home-leave');
check('leave menu lists every tab', await has('Leave to approve') && await has('Leave calendar') && await has('Leave types and days'));
await tap('mi-leave-calendar');
await home();

// ---------------------------------------------------------------- Home search and scan
await id('home-search').fill('cheque book');
await pg.waitForTimeout(300);
check('search finds screens', await has('Cheque books') && await has('Invoices & cheques › Records'));
await id('home-search').fill('Mere');
await pg.waitForTimeout(300);
check('search finds people', (await id('search-results').innerText()).includes('Mere'));
await tap('sr-0');
check('search result opens the person', (await id('user-name').count()) > 0 || await has('PIN'));
await home();
await id('home-search').fill('zzqq');
await pg.waitForTimeout(250);
check('search says when nothing is found', (await id('search-none').count()) > 0);
await id('home-search').fill('');
sql("INSERT INTO inv_items (uid, code, barcode, name, price, updated_at) VALUES ('IT9', 'P009', '9415007099999', 'Punjas Flour 10kg', 18.5, '2026-01-01 00:00:00')");
await tap('home-scan');
check('scan screen with camera and typed code', (await id('code-scanner').count()) > 0 && (await id('scan-code').count()) > 0);
await pg.evaluate(() => window.__scanQr('9415007099999'));
await pg.waitForTimeout(300);
check('product barcode shows the product', (await id('scan-product').count()) > 0 && await has('Punjas Flour 10kg'));
await id('scan-code').fill('NOPE-123'); await tap('scan-go');
check('unknown code explained', (await id('scan-notfound').count()) > 0);
await home();

// ---------------------------------------------------------------- Sync now
check('sync icon grey when not linked', (await id('sync-icon-grey').count()) > 0);
await tap('sync-icon');
check('pressing explains it is not linked', await has('not linked to the Easy Buys cloud yet'));
await text('OK');
sql("INSERT OR REPLACE INTO settings (key, value) VALUES ('cloud_url', ?), ('cloud_key', 'tablet-key-123'), ('device_name', 'Flow 9 tablet')", [CLOUD]);
await pg.waitForTimeout(5500);
await tap('sync-icon');
for (let i = 0; i < 40 && !(await id('sync-text').innerText()).startsWith('✓'); i++) await pg.waitForTimeout(500);
check('Sync now: all synced (green)', (await id('sync-text').innerText()).startsWith('✓ All synced') && (await id('sync-icon-green').count()) > 0, await id('sync-text').innerText());
offline = true;
sql("UPDATE shops SET sync_status = 'pending' WHERE code = 'S1'");
await tap('sync-icon');
await pg.waitForTimeout(2500);
const t1 = await id('sync-text').innerText();
check('Sync now offline: "No internet – items waiting", red, Retry', /✗ No internet – \d+ items? waiting/.test(t1) && (await id('sync-icon-red').count()) > 0 && await has('Retry'), t1);
offline = false;
await tap('force-sync');
await pg.waitForTimeout(3000);
check('Retry works once back online', (await id('sync-text').innerText()).startsWith('✓ All synced'), await id('sync-text').innerText());
await tap('home-admin'); await tap('admin-sync');
check('Admin › Sync has the Sync now panel', (await id('sync-now').count()) > 0 && (await id('sync-panel-text').innerText()).startsWith('✓ All synced'));
await home();

// ---------------------------------------------------------------- Backup & restore
await tap('home-admin'); await tap('admin-backup');
check('backup screen explains the three kinds of copies', await has('How the copies work') && await has('On this tablet'));
await tap('bk-snapshot'); await pg.waitForTimeout(800);
check('a copy on the tablet is listed', (await id('bk-tab-0').count()) > 0 && await has('Made by hand'));
check('the copy is a real file', fs.readdirSync(`${TMP}/fs-m9/doc/snapshots`).some((n) => /^eb-\d{8}-\d{6}-manual\.db$/.test(n)));
await tap('bk-pick-folder'); await pg.waitForTimeout(1200);
check('outside folder chosen and the daily copy put there', (await id('bk-folder').count()) > 0 && (await id('bk-out-0').count()) > 0);
await tap('bk-drive-list'); await pg.waitForTimeout(800);
check('Google Drive backups listed', (await id('bk-drive-0').count()) > 0 && await has('Google Drive'));
await tap('restore-tab-0');
check('restore asks for the owner / admin PIN', (await id('restore-pin').count()) > 0 && await has('A safety copy of the data as it is now is made first'));
await id('restore-pin').fill('3333'); await tap('restore-ok');
check('a non-admin PIN is refused', await has('not an owner or admin PIN'));
await tap('restore-cancel');
await home();

// ---------------------------------------------------------------- health check, sounds, About, shops
await tap('home-admin'); await tap('admin-health');
await tap('health-full'); await pg.waitForTimeout(1500);
check('full check runs from Admin', (await id('health-full-result').count()) > 0 && await has('Full database check'));
await tap('back'); await tap('admin-sounds');
check('alerts & sounds settings', await has('Quiet hours') && await has('This device') && (await id('snd-dnd').count()) > 0);
await tap('back'); await tap('admin-about');
check('Admin › About', await has('Version 3.5.0 (build 3)'));
await tap('back'); await tap('admin-shops');
check('shops: Tukani Street and the closed shop as a cost area', await has('Tukani Street') && await has('Closed shop – V M Pillay') && await has('Office / whole business'));
await home();
await tap('home-admin'); await tap('admin-problems');
check('Problems: Send to support', (await id('pr-support').count()) > 0);
await tap('pr-support'); await pg.waitForTimeout(200);
check('Send to support queued for the cloud', await has('Sent to support'));
const q = srv.dbFor('m9').prepare("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'support_email'").get().n;
check('support email waits in the outbox', q === 1);
await text('OK');
await home();

// ---------------------------------------------------------------- phone width
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto(`http://localhost:${PORT + 9}/?dev=m9`); await ph.waitForTimeout(1200);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(500);
const pw = async () => ph.evaluate(() => document.documentElement.scrollWidth);
check('phone: Home with search and warnings fits', (await pw()) <= 400 && (await ph.getByTestId('home-search').count()) > 0, `width ${await pw()}`);
await ph.getByTestId('home-payables').first().click(); await ph.waitForTimeout(300);
check('phone: module menu fits', (await pw()) <= 400, `width ${await pw()}`);
await ph.getByTestId('back').first().click(); await ph.waitForTimeout(200);
if (await ph.getByTestId('alerts-more').count()) { await ph.getByTestId('alerts-more').first().click(); await ph.waitForTimeout(300); }
check('phone: warnings list fits', (await pw()) <= 400, `width ${await pw()}`);

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
