const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.9 through the screens, on the practice (training) data: receiving starts on "Receive goods & papers" – goods
// counted in against the purchase order (stock up, invoice joined to the order), a receipt for a bill already paid,
// a split supplier payment (cash + cheque from the drop-down), a part payment flagged, and the VAT return
// (lines 1–13, lodge, pay by cheque from the cheque book – booked in the accounts and the cheque register).
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m39', 'm39-easybuys-training.db']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 14 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: 8000 }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-f39-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(200); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(250); };
const textHas = async (t) => { await pg.getByText(t, { exact: false }).last().click(); await pg.waitForTimeout(250); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(400); };
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await tap('back'); };
const photo = async (pre) => { await tap(`${pre}-camera`).catch(async () => { await pg.getByText('Camera', { exact: false }).first().click(); }); await pg.waitForTimeout(250); };
const T = () => srv.dbFor('m39-easybuys-training.db');
const one = (q, p = []) => T().prepare(q).get(...p);

await pg.goto(`http://localhost:${PORT + 14}/?dev=m39`); await pg.waitForTimeout(900);
await pin('1111');
await tap('home-admin'); await tap('admin-training');
await tap('tr-on'); await text('Switch to training'); await pg.getByTestId('training-bar').first().waitFor({ timeout: 20000 }).catch(() => {}); await pg.waitForTimeout(800);
await pin('5001');
check('practice owner logged in', await id('home-admin').count() > 0);
// The practice order is approved so it can be received.
T().prepare("UPDATE po_orders SET status = 'approved' WHERE status IN ('draft','awaiting')").run();
const po = one("SELECT uid, po_no FROM po_orders WHERE status = 'approved' LIMIT 1");
const flourBefore = one("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = 'IT-P100' AND shop_code = 'S2' AND status = 'active'").q;

// ---------------------------------------------------------------- receiving starts here
await tap('home-snap');
check('Home tile opens "Receive goods & papers"', await has('Receive goods & papers'));
await tap('snap-k-invoice');
check('goods or a bill', await id('snap-goods-stock').count() > 0 && await id('snap-goods-bill').count() > 0);
await tap('snap-shop-S2');
await photo('snap-photo');
await tap('snap-sup'); await text('Punjas (practice)');
check('the open purchase order is offered', (await id(`snap-rpo-${po.po_no}`).count()) > 0);
await tap(`snap-rpo-${po.po_no}`);
await id('snap-ref').fill('PJ-2001');
await tap('snap-save'); await pg.waitForTimeout(500);
check('next: count the goods against the order', await has(`Receive ${po.po_no}`));
check('the invoice number came along', (await id('rc-invno').inputValue().catch(() => '')) === 'PJ-2001');
await tap('rc-save'); await pg.waitForTimeout(600);
if (await has('Please check')) { await id('rc-why').fill('Practice'); await tap('rc-save'); await pg.waitForTimeout(600); }
check('delivery received', await has('Delivery received'));
const flourAfter = one("SELECT COALESCE(SUM(qty),0) AS q FROM inv_moves WHERE item_uid = 'IT-P100' AND shop_code = 'S2' AND status = 'active'").q;
check('stock went up by what came off the truck', flourAfter - flourBefore === 20, `${flourBefore} → ${flourAfter}`);
const inv = one("SELECT * FROM ap_invoices WHERE invoice_no = 'PJ-2001'");
check('the invoice is joined to the order', !!inv && inv.po_uid === po.uid);
check('the order is received', one('SELECT status FROM po_orders WHERE uid = ?', [po.uid]).status === 'part' || one('SELECT status FROM po_orders WHERE uid = ?', [po.uid]).status === 'received');
await home();

// ---------------------------------------------------------------- a receipt for a bill already paid (power)
await tap('home-snap');
await tap('snap-k-receipt');
await tap('snap-paidbill');
check('switches to a paid bill', await id('snap-paid-cash').count() > 0);
await tap('snap-shop-S1');
await photo('snap-photo');
await tap('snap-sup'); await text('EFL Power (practice)');
await tap('snap-cat'); await text('Power & water');
await tap('snap-paid-cash');
await id('snap-ref').fill('EFL-OCT'); await id('snap-amount').fill('210');
await tap('snap-save'); await pg.waitForTimeout(500);
const bill = one("SELECT * FROM ap_invoices WHERE invoice_no = 'EFL-OCT'");
const billPaid = bill ? one("SELECT COALESCE(SUM(a.amount),0) AS p FROM ap_allocations a JOIN ap_payments p ON p.uid = a.payment_uid AND p.status = 'active' WHERE a.invoice_uid = ?", [bill.uid]).p : 0;
check('the bill and its cash payment are saved together', !!bill && bill.category === 'Power & water' && billPaid === 210, bill ? `${bill.category} paid ${billPaid}` : 'no bill');
await home();

// ---------------------------------------------------------------- split payment (cash + cheque from the drop-down), part payment
const rw = one("SELECT uid, total FROM ap_invoices WHERE invoice_no = 'RW-77'");
T().prepare("UPDATE ap_invoices SET status = 'approved' WHERE uid = ?").run(rw.uid);
await tap('home-payables'); await tap('mi-ap-pay');
await tap('pay-supplier'); await text('Rewa Dairy (practice)');
await tap('pay-tick-RW-77');
await tap('pay-split-true');
await id('pay-part-0-amount').fill('100');
await tap('pay-part-0-shop-S2').catch(() => {});
await id('pay-part-1-amount').fill('200');
check('the cheque drop-down starts on the next unused cheque', await has('· next in the book'));
check('the parts do not add up yet', await has('still to share out'));
await id('pay-part-1-amount').fill('237.50');
check('the parts add up', await has('The parts add up to'));
await tap('pay-save'); await pg.waitForTimeout(300); await text('Save'); await pg.waitForTimeout(600);
const parts = T().prepare("SELECT method, amount, cheque_no FROM ap_payments WHERE notes LIKE 'Split payment%' ORDER BY method").all();
check('two payments: cash and the next cheque', parts.length === 2 && parts.some((p) => p.method === 'cheque' && !!p.cheque_no) && parts.some((p) => p.method === 'cash'), JSON.stringify(parts));
check('RW-77 fully paid', one("SELECT COALESCE(SUM(amount),0) AS p FROM ap_allocations WHERE invoice_uid = ?", [rw.uid]).p === 337.5);
await home();
// part payment
await tap('home-payables'); await tap('mi-ap-pay');
await tap('pay-supplier'); await text('Punjas (practice)');
T().prepare("UPDATE ap_invoices SET status = 'approved' WHERE invoice_no = 'PJ-2001'").run();
await tap('back'); await tap('mi-ap-pay'); await tap('pay-supplier'); await text('Punjas (practice)');
await tap('pay-tick-PJ-2001');
const owing = inv.total;
await id('pay-amt-PJ-2001').fill(String(Math.round(owing / 2 * 100) / 100));
check('part payment warning', await has('Part payment') && await has('still owing'));
await home();

// ---------------------------------------------------------------- VAT return: lines, lodge, pay by cheque
await tap('home-payroll'); await tap('mi-pay-returns');
check('returns list', await has('VAT & FNPF returns'));
await tap('rl-next'); await tap('rl-open'); await pg.waitForTimeout(500);
check('VAT return with the 13 FRCS lines', await has('Total taxable supplies') && await has('Amount to pay'));
await id('tr-lodge-ref').fill('TPOS-PRACTICE-1');
await tap('tr-lodge'); await pg.waitForTimeout(300);
if (await id('tr-lodge-force').count()) { await tap('tr-lodge-force'); await pg.waitForTimeout(300); await pg.locator('textarea, input').last().fill('Practice'); await text('Lodge'); await pg.waitForTimeout(400); }
const ym = new Date().toISOString().slice(0, 7);
const v1 = one("SELECT * FROM tax_return_versions WHERE kind = 'vat' AND status = 'lodged' ORDER BY version DESC LIMIT 1");
check('lodged: version 1 kept', !!v1 && v1.version === 1 && v1.lodge_ref === 'TPOS-PRACTICE-1');
if (v1 && v1.amount > 0) {
  await tap('tr-pay-method-cheque');
  check('cheque drop-down on the VAT payment', await has('next in the book'));
  await tap('tr-pay'); await pg.waitForTimeout(600);
  const f = one("SELECT * FROM tax_returns WHERE kind = 'vat' AND period = ?", [v1.period]);
  const chq = f && f.cheque_uid ? one('SELECT * FROM cheques WHERE uid = ?', [f.cheque_uid]) : null;
  check('VAT paid by cheque: in the cheque register to FRCS and booked in the accounts', !!chq && chq.payee === 'FRCS (VAT)' && !!one("SELECT 1 AS x FROM gl_journals WHERE uid = ? AND kind = 'tax_payment' AND status = 'active'", [f.pay_link]));
  check('the screen shows it paid', await has('Booked in'));
} else check('VAT month is a refund or nil (practice data)', true, v1 ? String(v1.amount) : 'none');
await tap('back'); await tap('rl-kind-fnpf');
check('FNPF schedule list opens', await has('FNPF schedule'));
await home();

check('no page errors', !errs.length, errs.slice(0, 3).join(' | '));
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close(); srv.close();
process.exit(fails ? 1 : 0);
