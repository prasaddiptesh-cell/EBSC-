const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.9.2 through the screens: photos of paper fill in the boxes. Till count from the Z report photo (figures filled,
// sums checked, save refused until "I checked these figures" is ticked, a figure changed by the counter is kept in
// the history), the stamped deposit slip (slip number / branch / date filled, amount compared with the count), and a
// petty cash receipt (a photo that cannot be read → type it; read again → filled).
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m392']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 16 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-f392-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(200); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(250); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(400); };
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await tap('back'); };
const dlgOk = async () => { if (await id('dialog').count()) { const t = await id('dialog').innerText(); await text('OK'); return t; } return ''; };
const sign = async (pad) => { await tap(`${pad}-open`); await tap(`${pad}-draw`); await tap(`${pad}-done`); };
const D = () => srv.dbFor('m392');
const sql = (q, p = []) => D().prepare(q).run(...p);
const one = (q, p = []) => D().prepare(q).get(...p);
const paper = async (t) => { await pg.evaluate((x) => { globalThis.__ebPaperText = x; }, t); };
const val = async (t) => id(t).inputValue();

await pg.goto(`http://localhost:${PORT + 16}/?dev=m392`); await pg.waitForTimeout(1200);
if (await pg.getByText('The app closed last time', { exact: true }).count()) await text('OK');
const today = await pg.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
const [y, m, d] = today.split('-');
sql("INSERT INTO tills (uid, shop_code, name, float_amount, active, sort, updated_at, updated_device) VALUES ('TL392', 'S1', 'Till 1', 100, 1, 0, '2026-01-01 00:00:00', 'x')");
sql("UPDATE users SET sync_status = 'pending' WHERE name LIKE 'Sita%' OR name LIKE 'Ravi%'");
sql("INSERT INTO bank_accounts (uid, name, bank, opening_balance, opening_date, active, sort, updated_at) VALUES ('BA392', 'BSP Business', 'BSP', 1000, '2026-01-01', 1, 0, '2026-01-01 00:00:00')");
const sita = one("SELECT uid FROM users WHERE name LIKE 'Sita%'");
await pin('1111');
await pg.waitForTimeout(400);

// ---------------------------------------------------------------- Z report
const Z = `EASY BUYS SHOPPING CENTRE\nEND OF DAY\nZ REPORT No: 0412\nDate: ${d}/${m}/${y} 21:05\nPayment types\nCash            1,245.60\nM-PAiSA           180.00\nTotal           1,425.60\nTax rates\nVAT 12.50%    1,175.60   130.62\nVAT 0.00%       250.00     0.00\nDocuments count   87\nRefunds            12.50\nVoids               3.00`;
await tap('home-till'); await tap('mi-till-count'); await pg.waitForTimeout(300);
check('Z photo comes first with the hint', await has('Take the photo first'));
await paper(Z);
await tap('tc-photo-camera'); await pg.waitForTimeout(900);
check('Z figures filled in', (await val('tc-z')) === '412' && (await val('tc-ztotal')) === '1425.6' && (await val('tc-zcash')) === '1245.6' && (await val('tc-zvat')) === '130.62' && (await val('tc-zzero')) === '250',
  [await val('tc-z'), await val('tc-ztotal'), await val('tc-zcash'), await val('tc-zvat'), await val('tc-zzero')].join(' '));
check('M-PAiSA filled', (await val('tc-tender-1-amount')) === '180');
check('the boxes filled are listed, the sums are checked', (await id('tc-photo-filled').count()) > 0 && (await id('tc-photo-check-sum').count()) > 0 && (await id('tc-photo-check-vat').count()) > 0);
check('no date warning (today\'s Z report)', (await id('tc-zdate').count()) === 0);
await tap('tc-photo-text'); check('what was read can be shown', await has('Documents count'));
await id('tc-d-n100').fill('13'); await id('tc-d-n50').fill('1'); await id('tc-d-n5').fill('1');
await id('tc-zcash').fill('1254.60'); // the counter corrects a misread figure
await id('tc-reason').fill('Checked');
await tap('sig-balancer'); await tap(`sig-balancer-opt-${sita.uid}`);
await sign('sig-cashier'); await sign('sig-bal');
await tap('tc-save'); await pg.waitForTimeout(300);
const dz = await dlgOk();
check('save refused until the figures are ticked as checked', /Check the figures first/.test(dz), dz.replace(/\n/g, ' '));
await tap('tc-photo-checked');
await tap('tc-save'); await pg.waitForTimeout(500);
const d2 = await dlgOk();
if (d2) console.log('     dialog:', d2.replace(/\n/g, ' '));
const tc = one("SELECT * FROM till_counts ORDER BY rowid DESC LIMIT 1");
check('count saved with the Z figures', tc && tc.z_number === '412' && tc.z_total === 1425.6 && tc.z_cash === 1254.6 && tc.z_customers === 87, tc && JSON.stringify([tc.z_number, tc.z_total, tc.z_cash, tc.z_customers]));
const zr = tc && JSON.parse(tc.z_read || 'null');
check('what was read and what the counter changed is kept', zr && zr.checked && zr.changed.some((c) => c.field === 'zCash' && c.read === 1245.6), tc && tc.z_read);
check('change history line', !!one("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Photo read (z)%changed by the person: CASH sales%'"));
check('photo reading log kept', !!one("SELECT 1 AS x FROM paper_reads WHERE kind = 'z' AND ref_uid = ?", [tc && tc.uid]));
check('the saved count shows the reading', (await id('tc-zread').count()) > 0 && await has('Changed by the person'));
await home();

// ---------------------------------------------------------------- petty cash receipt
await paper('');
await tap('home-till'); await tap('mi-till-cash'); await tap('coh-add'); await pg.waitForTimeout(200);
await tap('coh-photo-camera'); await pg.waitForTimeout(900);
check('a photo that cannot be read: told to type it', (await id('coh-photo-failed').count()) > 0);
await paper(`RB PATEL SUPERMARKET\nReceipt No. 004512\n${d}/${m}/${y}\nTOTAL 23.40`);
await tap('coh-photo-reread'); await pg.waitForTimeout(900);
check('read again: amount and what filled', (await val('coh-amount')) === '23.4' && /RB PATEL/.test(await val('coh-note')), `${await val('coh-amount')} | ${await val('coh-note')}`);
await tap('coh-photo-checked');
await tap('coh-save'); await pg.waitForTimeout(400);
const dc = await dlgOk(); if (dc) console.log('     dialog:', dc.replace(/\n/g, ' '));
check('petty cash saved', !!one("SELECT 1 AS x FROM cash_moves WHERE type = 'petty_out' AND ABS(amount - 23.4) < 0.001"));
await home();

// ---------------------------------------------------------------- deposit slip
await tap('home-till'); await tap('mi-till-deposit'); await pg.waitForTimeout(300);
await paper(`BSP Bank of South Pacific\nBranch: Lautoka\nDeposit Slip No 7741\nDate ${d}/${m}/${y}\nCash 2,450.00\nTotal 2,450.00`);
await tap('dep-photo-camera'); await pg.waitForTimeout(900);
check('slip number and branch filled', (await val('dep-slip')) === '7741' && await has('Lautoka'));
await id('dep-d-n100').fill('24');
await pg.waitForTimeout(200);
check('slip amount compared with the count (short)', (await id('dep-slipdiff').count()) > 0, (await id('dep-slipdiff').count()) ? await id('dep-slipdiff').innerText() : 'no banner');
await id('dep-d-n50').fill('1');
await pg.waitForTimeout(200);
check('slip agrees with the count', (await id('dep-slipok').count()) > 0);
await tap('dep-save'); await pg.waitForTimeout(300);
check('deposit save waits for the tick', /Check the figures first/.test(await dlgOk()));
await tap('dep-photo-checked'); await tap('dep-save'); await pg.waitForTimeout(500);
const dd = await dlgOk(); if (dd) console.log('     dialog:', dd.replace(/\n/g, ' ')); await notNow();
const dep = one("SELECT * FROM deposits ORDER BY rowid DESC LIMIT 1");
check('deposit saved with the slip number and branch', dep && dep.slip_no === '7741' && /Lautoka/.test(dep.branch || '') && dep.total === 2450, dep && JSON.stringify([dep.slip_no, dep.branch, dep.total]));
await home();

// ---------------------------------------------------------------- help
await tap('home-help'); await pg.waitForTimeout(300);
check('Help lists the guides by area', await has('Till & cash') && await has('Handover & takeover'));
await id('help-q').fill('post-dated cheque'); await pg.waitForTimeout(300);
check('search finds the guide', (await id('help-cover').count()) > 0 || (await id('help-pay').count()) > 0);
await tap((await id('help-cover').count()) ? 'help-cover' : 'help-pay'); await pg.waitForTimeout(300);
check('the guide shows its steps', (await id('guide-step-0').count()) > 0);
await home();
await tap('home-till'); await tap('mi-till-deposit'); await pg.waitForTimeout(300);
check('first time on a screen: a tip offers its guide', (await id('first-tip').count()) > 0);
await tap('first-tip-ok'); await pg.waitForTimeout(200);
check('Got it: the tip is gone', (await id('first-tip').count()) === 0);
await tap('help-btn'); await pg.waitForTimeout(300);
check('❓ opens the guide for the screen', await has('Bank the cash'));
await home();

// ---------------------------------------------------------------- second count, shortage paid now, till over
const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
sql(`INSERT INTO till_counts (uid, shop_code, till_uid, till_name, shift_date, shift, cashier_uid, cashier_name, counted_by_uid, counted_by_name, counted_at, opening_float, denominations, cash_counted, float_kept, z_cash, z_total, tenders, payouts, drops, adjustments, expected_cash, over_short, status, photo_urls, updated_at)
  VALUES ('TC392B', 'S1', 'TL392', 'Till 1', ?, 'Morning', ?, 'Sita Devi', ?, 'Sita Devi', ?, 100, '{"n100":5}', 500, 100, 400, 400, '[]', '[]', 0, '[]', 500, 0, 'counted', '[]', ?)`, [today, sita.uid, sita.uid, now, now]);
await tap('home-till'); await tap('mi-home'); await pg.waitForTimeout(300);
await tap('count-TC392B'); await pg.waitForTimeout(300);
await tap('tc-recount'); await pg.waitForTimeout(300);
check('second count: the first count is not shown', !(await has('Counted: $500.00')));
await id('rc2-d-n100').fill('4'); await id('rc2-d-n50').fill('1'); await id('rc2-d-n20').fill('2');
await tap('rc2-save'); await pg.waitForTimeout(400);
const rc = await dlgOk();
check('second count differs: told, and it stands', /different/i.test(rc), rc.replace(/\n/g, ' '));
const tcb = one("SELECT * FROM till_counts WHERE uid = 'TC392B'");
check('the second count is saved, the first kept', tcb.second_status === 'differs' && tcb.cash_counted === 490 && JSON.parse(tcb.first_count).counted === 500);
check('the count shows both counts', (await id('tc-second-diff').count()) > 0);
const shb = one("SELECT * FROM till_shortages WHERE count_uid = 'TC392B'");
check('a shortage now waits for the cashier', shb && shb.amount === 10 && shb.status === 'waiting');
await tap('tc-shortage'); await pg.waitForTimeout(300);
await tap(`short-${shb.uid}`); await pg.waitForTimeout(200);
await id('short-payamt').fill('6');
await sign('short-paysig');
await tap('short-paynow'); await pg.waitForTimeout(400);
const shb2 = one('SELECT * FROM till_shortages WHERE uid = ?', [shb.uid]);
check('cashier paid $6 now; $4 left for pay', shb2.paid_now === 6 && shb2.amount === 4 && shb2.status === 'waiting', JSON.stringify([shb2.paid_now, shb2.amount, shb2.status]));
check('the cash went into the shop cash', !!one("SELECT 1 AS x FROM cash_moves WHERE ref_uid = ? AND type = 'adjust_in' AND amount = 6", [shb.uid]));
sql(`INSERT INTO till_surplus (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, created_at, updated_at) VALUES ('TO392', 'TC392B', 'S1', ?, ?, 'Sita Devi', 15, 'open', ?, ?)`, [today, sita.uid, now, now]);
await home(); await tap('home-till'); await tap('mi-till-shortages'); await pg.waitForTimeout(300);
await tap('over-TO392'); await pg.waitForTimeout(200);
await tap('over-setoff-' + shb.uid); await pg.waitForTimeout(400);
check('till over set against the same cashier\'s shortage', one("SELECT status FROM till_surplus WHERE uid = 'TO392'").status === 'set_off' && one('SELECT status FROM till_shortages WHERE uid = ?', [shb.uid]).status === 'set_off');
await home();

// ---------------------------------------------------------------- cheques to cover → deposit → handover
sql("INSERT INTO cheque_books (uid, account_uid, first_no, last_no, updated_at) VALUES ('CB392', 'BA392', 770, 799, ?)", [now]);
sql(`INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, handed_date, handed_to, updated_at) VALUES ('CQ392', 'BA392', 'CB392', 777, ?, 'Punjas', 300, 'written', ?, 'Punjas driver', ?)`, [today, today, now]);
await tap('home-till'); await tap('mi-till-cover'); await pg.waitForTimeout(300);
check('Cheques to cover: handed over, no deposit', (await id('cv-777').count()) > 0 && await has('needs $300.00'));
await tap('cv-777'); await pg.waitForTimeout(200);
await tap('cv-deposit'); await pg.waitForTimeout(400);
check('the deposit opens with the cheque ticked', /☑️/.test(await id('dc-chq-777').innerText()));
await paper('');
await tap('dep-shop-S1');
await id('dep-slip').fill('9901');
await id('dep-d-n100').fill('3'); await id('dep-d-n50').fill('2');
await pg.waitForTimeout(200);
check('the deposit shows what it covers and the general part', /Covering \$300\.00 of this \$400\.00/.test(await id('dc-sum').innerText()));
await tap('dep-save'); await pg.waitForTimeout(500);
const dd2 = await dlgOk(); if (dd2) console.log('     dialog:', dd2.replace(/\n/g, ' ')); await notNow();
const cov = one("SELECT c.* FROM cheque_cover c JOIN deposits d ON d.uid = c.deposit_uid WHERE d.slip_no = '9901'");
check('the deposit is linked to the cheque', cov && cov.cheque_uid === 'CQ392' && cov.amount === 300);
await home();
await tap('home-till'); await tap('mi-till-handover'); await pg.waitForTimeout(500);
check('handover: the deposit and the cheque it covered', await has('Covers: Cheque 777') && await has('covered by a deposit'));
check('handover: tills, second count and shortage shown', await has('Second count was different') || await has('second count'));
await id('ho-notes').fill('All good. Cheque 777 covered.');
await sign('ho-sig');
await tap('ho-hand'); await pg.waitForTimeout(500);
const ho = one("SELECT * FROM handovers ORDER BY rowid DESC LIMIT 1");
check('handed over', ho && ho.status === 'handed' && /777/.test(ho.notes));
await tap('ho-taker'); await tap(`ho-taker-opt-${sita.uid}`);
await sign('ho-takesig');
await tap('ho-take'); await pg.waitForTimeout(400);
check('taken over by Sita', one('SELECT status, to_name FROM handovers WHERE uid = ?', [ho.uid]).status === 'taken' && /Sita/.test(one('SELECT to_name FROM handovers WHERE uid = ?', [ho.uid]).to_name));
await home();

// ---------------------------------------------------------------- phone width
await pg.setViewportSize({ width: 390, height: 800 });
await tap('home-till'); await tap('mi-till-count'); await pg.waitForTimeout(300);
await paper(Z); await tap('tc-photo-camera'); await pg.waitForTimeout(900);
const wide = await pg.evaluate(() => document.documentElement.scrollWidth);
check('phone: the reading fits', wide <= 392, `width ${wide}`);

check('no page errors', !errs.length, errs.join(' | '));
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close(); srv.close && srv.close(); process.exit(fails ? 1 : 0);
