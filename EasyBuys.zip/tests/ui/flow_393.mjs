const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.9.3 through the screens: the first (opening) stock take – details on each product (cost, selling price, VAT, FCCC,
// barcode, suppliers), counts from two phones added up, the admin changes a total, VAT and FCCC set while counting;
// the VAT check against Aronium; the FCCC screen; approving makes the opening stock.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['m393']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 18 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const pg = await (await b.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|unique "key"|ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-f393-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(200); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(250); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(400); };
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await tap('back'); };
const menu = async (item) => { await home(); await tap('home-inventory'); await tap(`mi-${item}`); };
const D = () => srv.dbFor('m393');
const sql = (q, p = []) => D().prepare(q).run(...p);
const one = (q, p = []) => D().prepare(q).get(...p);

await pg.goto(`http://localhost:${PORT + 18}/?dev=m393`); await pg.waitForTimeout(1200);
if (await pg.getByText('The app closed last time', { exact: true }).count()) await text('OK');
const T = '2026-01-01 00:00:00';
for (const [uid, code, name, cost, price] of [['IT-RICE', 'RICE', 'Rice 1kg', 2, 3], ['IT-SOAP', 'SOAP', 'Soap', 1, 1.8]]) {
  sql('INSERT INTO inv_items (uid, code, name, unit, cost, price, vat_type, pack_size, active, barcode, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', [uid, code, name, 'each', cost, price, 'standard', 1, 1, `${code}-BC`, T]);
}
sql("INSERT INTO ap_suppliers (uid, name, active, updated_at) VALUES ('SUP-P', 'Punjas', 1, ?)", [T]);
await pin('1111');
await pg.waitForTimeout(400);

await menu('inv-count'); await tap('sc-new');
await tap('sc-scope-initial');
check('the first stock take is explained', await has('Everyone can help on their own phone'));
await tap('sc-start'); await pg.waitForTimeout(500);
const c = one("SELECT uid FROM inv_counts WHERE kind = 'initial'");
check('first stock take started with every product', !!c && one('SELECT COUNT(*) AS n FROM inv_count_lines WHERE count_uid = ?', [c.uid]).n === 2);
check('details shown on each product', await has('Cost $2.00 · Selling $3.00 · VAT 12.5%') && await has('Barcode RICE-BC'));
await id('scc-n-RICE').fill('10'); await tap('scc-set-RICE'); await pg.waitForTimeout(300); await tap('scc-show-all'); await pg.waitForTimeout(200);
check('counted shows who counted it', await has('✅ Counted 10'));
// another phone's count arrives through the cloud
sql("INSERT INTO inv_count_entries (uid, count_uid, item_uid, qty, spot, by_name, by_uid, device, at, updated_at, updated_device, sync_status) VALUES ('CE-OTHER', ?, 'IT-RICE', 4, 'Storeroom', 'Ravi', 'U-RAVI', 'PHONE2', ?, ?, 'PHONE2', 'synced')", [c.uid, T, T]);
await tap('scc-show-done'); await pg.waitForTimeout(300);
check('two phones added up', await has('✅ Counted 14'));
await tap('scc-who-RICE');
check('each count listed', await has('4 – Ravi · Storeroom'));
await id('scc-total-RICE').fill('12'); await tap('scc-settotal-RICE'); await pg.waitForTimeout(300);
check('the admin put the right total', await has('✅ Counted 12'));
// VAT and FCCC while counting
await tap('scc-show-all'); await pg.waitForTimeout(200);
await tap('scc-edit-SOAP');
await tap('scc-evat-SOAP-exempt'); await tap('scc-efccc-SOAP-y');
await id('scc-efmax-SOAP').fill('2.00'); await id('scc-eprice-SOAP').fill('1.90');
await tap('scc-esave-SOAP'); await pg.waitForTimeout(300);
const soap = one("SELECT vat_type, fccc, fccc_max FROM inv_items WHERE uid = 'IT-SOAP'");
check('VAT free and FCCC set while counting', soap.vat_type === 'exempt' && soap.fccc === 1 && soap.fccc_max === 2, JSON.stringify(soap));
check('shown on the product', await has('VAT free · FCCC $2.00'));
await id('scc-n-SOAP').fill('30'); await tap('scc-set-SOAP'); await pg.waitForTimeout(300);
// hand in and approve
await tap('scc-handin'); await pg.waitForTimeout(400);
check('handed in', await has('Waiting for approval'));
await tap('scc-post'); await pg.waitForTimeout(400);
const st = one("SELECT SUM(qty) AS q FROM inv_moves WHERE item_uid = 'IT-RICE' AND shop_code = (SELECT shop_code FROM inv_counts WHERE uid = ?) AND status = 'active'", [c.uid]);
check('approved: opening stock = the count', st.q === 12, JSON.stringify(st));

// VAT check against Aronium
sql("UPDATE inv_items SET aronium_vat = 'standard' WHERE uid = 'IT-SOAP'");
await menu('inv-vat');
check('the VAT difference is listed', await has('Aronium: VAT 12.5% · App: VAT free'));
await tap('vat-ar-SOAP'); await pg.waitForTimeout(300);
check('"Aronium is right" changes it here', one("SELECT vat_type FROM inv_items WHERE uid = 'IT-SOAP'").vat_type === 'standard');
// FCCC screen
await menu('inv-fccc');
check('FCCC screen lists the controlled product', await has('FCCC $2.00') && await has('Look for a new list now'));
// a purchase order line switched to cartons when the product has no pack size yet: never multiplied
await menu('inv-po-new'); await pg.waitForTimeout(300);
await tap('pe-sup'); await tap('pe-sup-opt-SUP-P');
await id('pe-find').fill('Rice'); await pg.waitForTimeout(400); await tap('pe-find-RICE');
await id('pe-qty-0').fill('20'); await pg.waitForTimeout(150);
await tap('pe-as-0-carton'); await pg.waitForTimeout(150);
await id('pe-pack-0').fill('10'); await pg.waitForTimeout(250);
check('20 singles at $2 → 2 cartons of 10 at $20', (await id('pe-qty-0').inputValue()) === '2' && await has('= 20 each into stock'), await id('pe-qty-0').inputValue());
check('cost each shown next to the carton price', (await id('pe-each-0').inputValue()) === '2' && (await id('pe-cost-0').inputValue()) === '20');
await id('pe-each-0').fill('2.10'); await pg.waitForTimeout(150);
check('typing the cost each works out the carton price', (await id('pe-cost-0').inputValue()) === '21');
await id('pe-each-0').fill('2'); await pg.waitForTimeout(150);
await tap('po-save'); await pg.waitForTimeout(400); await notNow();
const pl = one("SELECT qty, unit_cost, order_as, pack_size FROM po_lines WHERE item_uid = 'IT-RICE' ORDER BY rowid DESC LIMIT 1");
check('saved in singles: 20 at $2.00, carton of 10', pl && pl.qty === 20 && Math.abs(pl.unit_cost - 2) < 0.0001 && pl.order_as === 'carton' && pl.pack_size === 10, JSON.stringify(pl));

// a comment on a document (preview), then the layout designer
await menu('inv-count'); await tap(`sc-${c.uid}`); await pg.waitForTimeout(300);
await tap('scc-report'); await pg.waitForTimeout(800);
check('the preview opens', (await id('doc-preview').count()) > 0);
// (no "Not now" helper here: the preview has its own Not now button)
await id('pv-comment').click(); await pg.waitForTimeout(200); await id('pv-comment-text').fill('Opening stock checked by Divnesh'); await id('pv-comment-add').click(); await pg.waitForTimeout(400);
check('the comment is on the document', await has('1 comment(s) on this document'));
await id('pv-layout').click(); await pg.waitForTimeout(500); // "Change the layout" opens the designer
await tap('dd-type-po'); await tap('dd-width-info'); await tap('dd-align-summary'); await tap('dd-infocols-2'); await tap('dd-ask-yes');
await id('dd-label-old').fill('Ordered by'); await id('dd-label-new').fill('Prepared by'); await tap('dd-label-add');
await tap('dd-save'); await pg.waitForTimeout(300);
const des = JSON.parse(one("SELECT value FROM shared_settings WHERE key = 'doc_designs'").value || '{}').po.current;
check('layout saved: half width, centred, 2 columns, ask for a comment, renamed', des.parts.find((p) => p.key === 'info').width === 'half' && des.parts.find((p) => p.key === 'summary').align === 'center' && des.infoCols === 2 && des.askComment === true && des.labels['Ordered by'] === 'Prepared by', JSON.stringify({ infoCols: des.infoCols }));
check('no page errors', !errs.length, errs.join('\n'));
await b.close(); srv.close && srv.close();
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
process.exit(fails ? 1 : 0);
