const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 B1 – Bank, cash and M-PAiSA: two balances with coloured waiting items, check against mobile banking,
// statement import with its warnings and one-tap actions, history with search, M-PAiSA wallets (transfer to BSP),
// M-PAiSA statement import and shift matching, month end, bank rules, columns, archive, reports, phone width.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const req = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = req('playwright');

for (const f of ['mb1']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: 8000 }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-fb1-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await tap('back'); };
const menu = async (item) => { await home(); await tap('home-bank'); await tap(`mi-${item}`); await pg.waitForTimeout(200); };
const okDialog = async () => { if (await id('dialog').count()) { console.log('DIALOG:', (await id('dialog').innerText()).replace(/\n/g, ' | ')); await text('OK'); } };
const sql = (q, p = []) => srv.dbFor('mb1').prepare(q).run(...p);
const iso = (n) => { const x = new Date(Date.now() + n * 86400000); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
const dmy = (n) => { const [y, m, d] = iso(n).split('-'); return `${d}/${m}/${y}`; };

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb1`); await pg.waitForTimeout(1200);
// One BSP account opened 60 days ago with $10,000; a cheque written 20 days ago (red), one 2 days ago (amber), a deposit 1 day ago;
// till balances with M-PAiSA at Shop 1.
const U = '2026-01-01 00:00:00';
sql("INSERT INTO bank_accounts (uid, name, bank, opening_balance, opening_date, active, sort, updated_at) VALUES ('BA1', 'BSP Business Cheque', 'BSP', 10000, ?, 1, 0, ?)", [iso(-60), U]);
sql("INSERT INTO cheque_books (uid, account_uid, first_no, last_no, received_date, active, updated_at) VALUES ('CB1', 'BA1', 100200, 100249, ?, 1, ?)", [iso(-60), U]);
sql("INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, written_by_name, updated_at) VALUES ('CQ1', 'BA1', 'CB1', 100200, ?, 'RB Patel Group', 300, 'written', 'Admin', ?)", [iso(-20), U]);
sql("INSERT INTO cheques (uid, account_uid, book_uid, cheque_no, cheque_date, payee, amount, status, written_by_name, updated_at) VALUES ('CQ2', 'BA1', 'CB1', 100201, ?, 'Punjas', 450, 'written', 'Admin', ?)", [iso(-2), U]);
sql("INSERT INTO bank_entries (uid, account_uid, entry_date, type, amount, reference, note, by_name, shop_code, updated_at) VALUES ('BE1', 'BA1', ?, 'deposit', 1200, 'Slip 5551', 'S1 takings', 'Admin', 'S1', ?)", [iso(-1), U]);
sql("INSERT INTO till_counts (uid, shop_code, till_name, shift_date, shift, cashier_name, counted_by_name, counted_at, cash_counted, z_cash, tenders, status, updated_at) VALUES ('TC1', 'S1', 'Till 1', ?, 'Morning', 'Mere', 'Mere', ?, 0, 0, ?, 'approved', ?)",
  [iso(-1), `${iso(-1)} 14:00:00`, JSON.stringify([{ method: 'M-PAiSA', amount: 120 }]), U]);
await pin('1111');
await pg.waitForTimeout(400);

// ---------------------------------------------------------------- two balances
await menu('home');
check('two balances shown', await has('In the bank now') && await has('Expected balance'));
check('in the bank now $10000, expected $10450', (await id('bal-now').innerText()).includes('10000.00') && (await id('bal-expected').innerText()).includes('10450.00'), (await id('bal-now').innerText()).replace(/\n/g, ' '));
check('old cheque red ("overdue – check"), new one amber ("waiting")', (await id('wait-chq-100200').innerText()).includes('overdue') && (await id('wait-chq-100201').innerText()).includes('waiting'));
check('deposit in transit tagged S1', (await id('wait-BE1').innerText()).includes('S1'));

// ---------------------------------------------------------------- check against mobile banking
await tap('go-check');
await id('chk-typed').fill('10000'); await tap('chk-go'); await pg.waitForTimeout(300);
check('typed balance matches', await has('Matches ✓'));
await id('chk-typed').fill('9700'); await tap('chk-go'); await pg.waitForTimeout(300);
check('difference with likely cause (cheque 100200 presented)', await has('Difference −$300.00') && (await id('cause-0').innerText()).includes('Cheque 100200'));
check('earlier checks listed', await has('Earlier checks (2)'));

// ---------------------------------------------------------------- import a statement
await menu('bank-import');
const csv = ['Date,Description,Reference,Debit,Credit,Balance',
  `${dmy(-5)},ACCOUNT SERVICE FEE,,2.50,,9997.50`,
  `${dmy(-1)},CHQ 100200,100200,300.00,,9697.50`,
  `${dmy(-1)},CHQ 100233,100233,80.00,,9617.50`,
  `${dmy(0)},DEPOSIT SLIP 5551,,,1190.00,10807.50`].join('\n');
await id('imp-text').fill(csv); await pg.waitForTimeout(300);
check('statement read: 4 lines, CSV', (await id('imp-read').innerText()).includes('Read 4 line(s) (csv)'));
await tap('imp-go'); await pg.waitForTimeout(800); await okDialog();
check('imported with the checks listed', await has('Imported 4 line(s)') && await has('Cheques cleared by themselves') && await has('Unknown cheques / wrong amounts') && await has('Deposits that differ from the slip'));
await tap('imp-open'); await pg.waitForTimeout(300);
check('statement shows unknown cheque badge', await has('UNKNOWN CHEQUE') && await has('slip differs'));
await tap('line--80'); await pg.waitForTimeout(200);
check('unknown cheque warning explained', (await id('flag-unknown_cheque').count()) > 0 && await has('is not recorded in the app'));
await tap('flag-ok'); await pg.waitForTimeout(200);
await tap('line-1190'); await pg.waitForTimeout(200);
await tap('flag-slip-ok'); await pg.waitForTimeout(300); await okDialog();
check('slip difference matched with one tap', !(await has('slip differs')));

// ---------------------------------------------------------------- history
await menu('bank-history');
await id('hist-q').fill('100200'); await pg.waitForTimeout(300);
check('history search finds the cheque with cleared mark and who', await has('✓') && (await id('hist-100200').innerText()).includes('Admin'));
await id('hist-q').fill(''); await pg.waitForTimeout(200);
check('running balance shown', await has('bal $'));

// ---------------------------------------------------------------- wallets
await menu('bank-wallets');
check('two M-PAiSA wallets, one per shop', await has('M-PAiSA Shop 1') && await has('M-PAiSA Shop 2'));
await tap('wal-open-S1');
check('Shop 1 wallet has the till M-PAiSA sales', (await id('wal-bal').innerText()).includes('120.00'));
await id('wal-amount').fill('100'); await id('wal-fee').fill('1'); await id('wal-ref').fill('MP777');
await tap('wal-save'); await pg.waitForTimeout(300); await okDialog();
check('transfer to BSP recorded: wallet $19, $100 on the way', (await id('wal-bal').innerText()).includes('19.00') && await has('on the way to BSP'));

// ---------------------------------------------------------------- M-PAiSA statement
await menu('mpaisa-import');
await id('mpi-text').fill(`Date,Time,Details,Transaction ID,Credit,Debit,Balance\n${dmy(-1)},09:30,Payment received from 7712345,R1,70.00,,70.00\n${dmy(-1)},11:00,Payment received from 7700000,R2,30.00,,100.00`);
await pg.waitForTimeout(300);
check('M-PAiSA statement read', (await id('mpi-read').innerText()).includes('Read 2 line(s)'));
await tap('mpi-go'); await pg.waitForTimeout(600); await okDialog();
check('import result: a day that does not match', await has('Imported 2 line(s)') && await has('Days that do not match'));
await tap('mpi-open'); await pg.waitForTimeout(300);
check('fake payment message warning on that day', await has('possible fake payment message') && await has('CHECK'));
await tap(`mpm-${iso(-1)}`); await tap('mpm-explain-TC1');
await id('mpm-note').fill('Customer showed a fake message'); await tap('mpm-save'); await pg.waitForTimeout(300); await okDialog();
check('explained', await has('Explained'));

// ---------------------------------------------------------------- month end, rules, columns, archive, checks, setup
await menu('bank-month');
check('month-end checklist', await has('Full-month BSP statement imported') && await has('Every warning reviewed') && await has('Reconciliation report saved'));
await menu('bank-rules');
await id('bs-verify').fill('10'); await tap('bs-save'); await pg.waitForTimeout(200); await okDialog();
check('bank rules saved (verification days)', srv.dbFor('mb1').prepare("SELECT value FROM shared_settings WHERE key = 'bank_settings'").get().value.includes('"verifyDays":10'));
await menu('mpaisa-columns');
await id('col-sample').fill('Txn Date,Txn Time,Narration,Receipt,Paid In,Withdrawn,Balance'); await pg.waitForTimeout(200);
check('columns screen tries a heading line', await has('— not found') || await has('Balance'));
await menu('bank-archive');
check('statement archive lists the imported statement', await has('BSP statements') && await has('BSP statement'));
await menu('bank-checks');
check('balance checks list', await has('difference') && await has('matched'));
await menu('wallet-setup');
await tap('ws-add'); await id('ws-name').fill('MyCash Shop 1'); await tap('ws-save'); await pg.waitForTimeout(300); await okDialog();
check('MyCash wallet added by admin', await has('MyCash Shop 1'));
await menu('bank-reports');
await tap('hub-bank_rec35'); await pg.waitForTimeout(400);
check('reconciliation report opens', await has('Bank Reconciliation') && await has('Cheques not yet presented'));
sql('UPDATE bank_checks SET check_date = ?', [iso(-4)]);
await home(); await tap('home-bank'); await home(); await pg.waitForTimeout(300);
const reminder = (await id('alert-open-bank-mobile-check').count()) > 0 || await has('more warning');
if ((await id('alert-open-bank-mobile-check').count()) === 0 && await has('more warning')) await tap('alerts-more');
check('Home: reminder to check against BSP mobile banking after 3 days', reminder && await has('Check the bank balance against BSP mobile banking'));
if ((await id('alert-open-bank-mobile-check').count())) { await tap('alert-open-bank-mobile-check'); check('reminder taps through to the check', await has('Type the balance the app shows right now')); }

// ---------------------------------------------------------------- phone width
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto(`http://localhost:${PORT + 10}/?dev=mb1`); await ph.waitForTimeout(1200);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(500);
const pw = async () => ph.evaluate(() => document.documentElement.scrollWidth);
const pmenu = async (item) => {
  for (let i = 0; i < 10 && !(await ph.getByTestId('home-admin').count()); i++) { await ph.getByTestId('back').first().click(); await ph.waitForTimeout(150); }
  await ph.getByTestId('home-bank').first().click(); await ph.waitForTimeout(200);
  await ph.getByTestId(`mi-${item}`).first().click(); await ph.waitForTimeout(300);
};
for (const item of ['home', 'bank-check', 'bank-import', 'bank-history', 'bank-wallets', 'mpaisa-match', 'bank-month']) {
  await pmenu(item);
  check(`phone: ${item} fits`, (await pw()) <= 400, `width ${await pw()}`);
}

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
