const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 B2: cheque books & stubs (serial, holder, status, leaves, stub record), photo of a cheque handed over
// (supplier drop-down, cheque drop-down, typed number checks → To verify), photo of an invoice (supplier typed →
// "add properly"), supplier statement with PDF/Excel and the statement check next to it, phone width.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');

for (const f of ['mb2']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|unique "key"|ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const shot = (n) => pg.screenshot({ path: `${TMP}/ui-${n}.png`, fullPage: false });
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const tap = async (t) => { await notNow(); try { await id(t).click({ timeout: 8000 }); } catch (e) { await shot('fail-b2'); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const textHas = async (t) => { await pg.getByText(t, { exact: false }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await back(); };
const photo = async () => { await tap('snap-photo-camera').catch(async () => { await pg.getByText('Camera', { exact: false }).first().click(); }); await pg.waitForTimeout(200); };

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb2`); await pg.waitForTimeout(900);
if (await has('The app closed last time')) await text('OK');
await pin('1111');

// ---------------------------------------------------------------- bank account and a cheque book
await tap('home-payables'); await tap('mi-chq-accounts');
await tap('acc-add'); await id('acc-name').fill('BSP Business Cheque'); await id('acc-open').fill('5000'); await tap('acc-save');
await back();
await tap('mi-chq-books');
check('cheque books & stubs screen', await has('Cheque books & stubs') && await has('Leaves unused'));
await tap('cb-add');
await id('cb-serial').fill('BK-77'); await id('cb-first').fill('100201'); await id('cb-last').fill('100250'); await id('cb-holder').fill('Divnesh (office safe)');
await tap('cb-save'); await pg.waitForTimeout(300);
check('book listed with serial, holder and status', await has('Book BK-77') && await has('held by Divnesh (office safe)') && await has('In use'));
check('leaves shown', (await id('cb-leaf-100250').count()) > 0);
await shot('b2-books');
await back();

// ---------------------------------------------------------------- supplier, invoice, cheque
await tap('mi-ap-suppliers'); await tap('sup-add');
await id('sup-name').fill('RB Patel Group'); await id('sup-tin').fill('500012345'); await tap('sup-account-true'); await id('sup-terms').fill('7'); await tap('sup-save');
await back();
await tap('mi-ap-new');
await tap('inv-supplier'); await text('RB Patel Group');
await id('inv-no').fill('4471'); await id('inv-total').fill('1125');
await tap('inv-save'); await pg.waitForTimeout(300);
await tap('inv-pay');
await tap('pay-save'); await pg.waitForTimeout(200);
await text('Cheque written'); await pg.waitForTimeout(400);
check('cheque 100201 written', await has('Cheque 100201'));
await home();

// ---------------------------------------------------------------- photo: cheque handed over
await tap('home-snap');
await tap('snap-k-cheque_given');
await photo();
await tap('snap-sup'); await text('RB Patel Group');
await tap('snap-chq'); await textHas('100201 · $1125.00');
check('cheque found from the drop-down', await has('Cheque found'));
await id('snap-who').fill('Ravi (driver)');
await tap('snap-save'); await pg.waitForTimeout(300);
check('photo saved', await has('Photo saved'));
await tap('snap-another');
await photo();
await tap('snap-sup'); await text('RB Patel Group');
await tap('snap-chq'); await textHas('Type another number');
await id('snap-ref').fill('100205');
await pg.waitForTimeout(200);
check('typed number not recorded: flagged, skipped numbers explained', await has('Not recorded yet') && await has('will show as skipped'));
await id('snap-ref').fill('100201');
await pg.waitForTimeout(200);
check('already handed over is flagged', await has('already handed over'));
await id('snap-ref').fill('100205');
await id('snap-who').fill('Ravi');
await tap('snap-save'); await pg.waitForTimeout(300);
check('saved with a note for the office', await has('The office will check the cheque number'));
await tap('snap-another');
// invoice photo with a new supplier typed
await tap('snap-k-invoice');
await photo();
await id('snap-party').fill('Island Fresh Eggs');
check('new supplier will be flagged', await has('New supplier'));
await id('snap-ref').fill('E-9'); await id('snap-amount').fill('60');
await tap('snap-save'); await pg.waitForTimeout(300);
check('invoice photo saved', await has('Photo saved'));
// customer cheque stays free text
await tap('snap-another');
await tap('snap-k-cheque_received');
check('customer cheque: free text, no supplier drop-down', (await id('snap-sup').count()) === 0 && (await id('snap-party').count()) > 0);
await home();

// ---------------------------------------------------------------- To verify
await tap('home-verify');
await tap('vf-k-record');
check('handed over but not recorded on To verify', await has('Cheque 100205 handed over – not recorded'));
await textHas('Cheque 100205 handed over');
check('record the payment button', (await id('vf-record').count()) > 0);
await home();

// ---------------------------------------------------------------- stubs
await tap('home-payables'); await tap('mi-chq-books');
check('skipped and not recorded shown on the book', await has('SKIPPED') || await has('NOT RECORDED'));
await tap('cb-leaf-100201');
check('stub record', await has('Cheque 100201') && await has('RB Patel Group') && await has('to Ravi (driver)') && await has('No photo of the stub') && await has('4471'));
await tap('stub-clear'); await tap('stub-clear-save'); await pg.waitForTimeout(200);
check('presented in one tap', (await id('stub-clear').count()) === 0 && (await id('stub-clear-save').count()) === 0);
await back();
await tap('cb-leaf-100203');
check('skipped leaf explained', await has('Skipped') && (await id('stub-spoil').count()) > 0);
await back();
await tap('cb-leaf-100205');
check('handed-over leaf: record the payment', await has('Handed over – not recorded') && (await id('stub-pay').count()) > 0);
await back();
await tap('cb-report'); await pg.waitForTimeout(300);
check('cheque book report', await has('Cheque Book Report') && await has('BK-77'));
await back(); await back();

// ---------------------------------------------------------------- supplier statement
await tap('mi-ap-sup-statement');
await tap('ss-sup'); await text('RB Patel Group');
check('statement shows balances and cheques', await has('Closing balance') && await has('What we owe vs cheques not presented') && await has('Invoice · 4471'));
await shot('b2-statement');
await tap('ss-export'); await pg.waitForTimeout(400);
check('statement report with PDF / Excel', await has('Statement – RB Patel Group') && (await id('export-pdf').count()) > 0 && (await id('export-xlsx').count()) > 0);
await back();
await tap('ss-check');
check('statement check next to it', await has('Check a supplier statement') && await has('owing on'));
await home();
await tap('home-payables'); await tap('mi-ap-suppliers');
check('typed supplier flagged to add properly', await has('ADD PROPERLY'));
await home();

// ---------------------------------------------------------------- phone width
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto(`http://localhost:${PORT + 10}/?dev=mb2`); await ph.waitForTimeout(1200);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(500);
const pw = async () => ph.evaluate(() => document.documentElement.scrollWidth);
const ptap = async (t) => { await ph.getByTestId(t).first().click(); await ph.waitForTimeout(250); };
await ptap('home-payables'); await ptap('mi-chq-books');
check('phone: cheque books fit', (await pw()) <= 400, `width ${await pw()}`);
await ptap('cb-leaf-100201');
check('phone: stub fits', (await pw()) <= 400, `width ${await pw()}`);
await ptap('back'); await ptap('back');
await ptap('mi-ap-sup-statement');
check('phone: supplier statement fits', (await pw()) <= 400, `width ${await pw()}`);
await ptap('back'); await ptap('back');
await ptap('home-snap'); await ptap('snap-k-cheque_given');
check('phone: photo screen fits', (await pw()) <= 400, `width ${await pw()}`);

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
