const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// B3 purchasing: suppliers and products from Aronium, supplier order days → Today's orders + Home reminder → order with
// suggested quantities, scanning (camera, handheld scanner, not found, different supplier, number pad), changing a sent
// order (amended, history), receiving by scanning, correcting a delivery, reading an invoice photo on the device,
// learning the layout, scanning in a stock take, phone width.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['mb3']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|unique "key"|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const shot = (n) => pg.screenshot({ path: `${TMP}/ui-b3-${n}.png`, fullPage: false });
const tap = async (t) => { try { await id(t).click({ timeout: 8000 }); } catch (e) { await shot('fail'); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(150); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const notNow = async () => { const x = pg.getByText('Not now', { exact: true }); if (await x.count()) { await x.last().click(); await pg.waitForTimeout(150); } };
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(250); };
const back = () => tap('back');
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) { await notNow(); await back(); } };
const menu = async (item) => { await home(); await tap('home-inventory'); await tap(`mi-${item}`); };
const scan = async (code) => { await pg.evaluate((c) => window.__scanQr && window.__scanQr(c), code); await pg.waitForTimeout(250); };
const pad = async (digits) => { for (const k of digits) await tap(`qp-${k}`); await tap('qp-ok'); };
const db = () => srv.dbFor('mb3');

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb3`); await pg.waitForTimeout(800);
await pin('1111');

// ---------------------------------------------------------------- suppliers from Aronium
await menu('inv-sup-import');
await id('si-text').fill('Code,Name,Tax number,Phone number,Email,Is customer,Is supplier\n10,Punjas Ltd,500012345,679 666 1234,orders@punjas.com.fj,0,1\n11,Rewa Dairy,50999888,679 330 0000,,0,1\n12,Joe Customer,,999,,1,0\n');
await pg.waitForTimeout(200);
await tap('si-check');
check('supplier import: preview with customers skipped', await has('What will happen') && await has('Customers skipped'));
await tap('si-go'); await pg.waitForTimeout(300);
check('suppliers imported', !!db().prepare("SELECT 1 FROM ap_suppliers WHERE name = 'Rewa Dairy'").get() && !db().prepare("SELECT 1 FROM ap_suppliers WHERE name = 'Joe Customer'").get());
const punjas = db().prepare("SELECT uid FROM ap_suppliers WHERE name = 'Punjas Ltd'").get().uid;
const rewa = db().prepare("SELECT uid FROM ap_suppliers WHERE name = 'Rewa Dairy'").get().uid;

// ---------------------------------------------------------------- products (whole list, wholesale, barcodes)
await menu('inv-import');
await tap('imp-shop-S1');
await id('imp-text').fill('Code;Name;Group;Barcode;Measurement unit;Cost;Price;Wholesale price;Taxes;Quantity\n1001;Punjas Flour 10kg;Flour;9300001,9300011;bag;"18,50";24.95;22.00;VAT 12.5%;40\n1002;Rewa Milk 1L;Dairy;9300002;each;2.10;3.20;2.90;VAT 12.5%;120\n');
await pg.waitForTimeout(200);
await tap('imp-open-y'); await tap('imp-full-y');
await tap('imp-check'); await pg.waitForTimeout(200);
await tap('imp-go'); await pg.waitForTimeout(300);
check('products imported with wholesale price and all barcodes', db().prepare("SELECT wholesale_price AS w, barcode FROM inv_items WHERE code = '1001'").get().w === 22);
db().prepare("UPDATE inv_items SET supplier_uid = ? WHERE code = '1001'").run(punjas);
db().prepare("UPDATE inv_items SET supplier_uid = ? WHERE code = '1002'").run(rewa);
db().prepare("UPDATE inv_item_shops SET reorder_level = 50, reorder_qty = 20 WHERE item_uid = 'IT-1001'").run();

// ---------------------------------------------------------------- order days → today's orders → reminder
const wd = await pg.evaluate(() => new Date().getDay());
await menu('inv-schedules');
await tap('ss-sup'); await text('Punjas Ltd');
await tap(`ss-day-${wd}`);
await tap('ss-save'); await pg.waitForTimeout(200);
check('order days saved', !!db().prepare("SELECT 1 FROM supplier_schedules WHERE supplier_uid = ? AND active = 1", ).get(punjas));
await tap('ss-shop-S2'); await tap('ss-mode-skip'); await tap('ss-save'); await pg.waitForTimeout(200);
check('per-shop change: Shop 2 does not order from them', db().prepare("SELECT skip FROM supplier_schedules WHERE supplier_uid = ? AND shop_code = 'S2'").get(punjas).skip === 1);
await menu('inv-today-orders');
check("today's orders: Punjas for S1 to order now", await has('Punjas Ltd · S1') && await has('Order now') && !(await has('Punjas Ltd · S2')));
await home();
let ordWarn = await has('Order from Punjas Ltd for S1 today');
if (!ordWarn && await pg.getByTestId('alerts-more').count()) { await pg.getByTestId('alerts-more').first().click(); await pg.waitForTimeout(400); ordWarn = await has('Order from Punjas Ltd for S1 today'); await home(); }
check('Home warning: order from Punjas', ordWarn);
await menu('inv-today-orders');
await tap('to-make-0'); await pg.waitForTimeout(300);
check('reminder opens a new order with suggested quantities', await has('New purchase order') && await has('Punjas Flour 10kg') && await has('sells'));

// ---------------------------------------------------------------- scanning into the order
await tap('pe-scan-cam');
check('continuous camera', (await id('barcode-camera').count()) > 0);
await scan('9300011');
check('scan → number pad', (await id('qty-pad').count()) > 0 && await has('Punjas Flour 10kg'));
await pad('5');
await scan('9300002');
check('different supplier warning', await has('Different supplier') && await has('usually comes from Rewa Dairy'));
await text('Add anyway');
await pad('12');
check('scanned products on the order', await has('Rewa Milk 1L'));
await tap('pe-scan-cam');
await id('pe-scan-wedge').fill('77777777'); await id('pe-scan-wedge').press('Enter'); await pg.waitForTimeout(250);
check('handheld scanner: unknown barcode → add it in Aronium first', await has('Add it in Aronium first'));
await text('OK');
await tap('po-submit'); await pg.waitForTimeout(300); await notNow();
const po = db().prepare("SELECT * FROM po_orders WHERE supplier_uid = ? ORDER BY created_at DESC LIMIT 1").get(punjas);
const flourQty = db().prepare("SELECT qty FROM po_lines WHERE po_uid = ? AND item_uid = 'IT-1001'").get(po.uid).qty;
check('order made from the scans and suggestion', po.status === 'approved' && flourQty >= 5 && !!db().prepare("SELECT 1 FROM po_lines WHERE po_uid = ? AND item_uid = 'IT-1002' AND qty = 12").get(po.uid), `flour ${flourQty}`);
await tap('pv-sent'); await pg.waitForTimeout(200);
await home();
check('no reminder once the order is sent', !(await has('Order from Punjas Ltd for S1 today')));

// ---------------------------------------------------------------- change after sending
await menu('inv-po'); await tap(`po-${po.po_no}`);
await tap('pv-amend');
check('amend: warned it was already sent', await has('This order was already sent'));
await id('pe-qty-1').fill('10');
await tap('po-amend'); await pg.waitForTimeout(300);
check('amended PDF offered to the supplier', await has('Send the AMENDED order to the supplier?'));
await notNow();
check('version 2 shown, amended order not sent yet', await has('Version') && await has('not yet'));
await tap('pv-history');
check('change history', await has('Version 2') && await has('Rewa Milk 1L: 12 → 10'));
await back();
await tap('pv-amended-sent');

// ---------------------------------------------------------------- receive by scanning, then correct the delivery
await tap('pv-receive');
await id('rc-scan-wedge').fill('9300001'); await id('rc-scan-wedge').press('Enter'); await pg.waitForTimeout(250);
await pad('3');
check('receiving: scanned count replaces the expected number', (await id('rc-qty-1001').inputValue()) === '3');
await tap('rc-inv-later');
await tap('rc-save'); await pg.waitForTimeout(300);
check('delivery received', await has('Delivery received'));
await tap('rcv-fix');
await id('df-qty-1001').fill('2');
await tap('df-save'); await pg.waitForTimeout(300);
const got = db().prepare("SELECT qty_received AS q FROM po_lines WHERE po_uid = ? AND item_uid = 'IT-1001'").get(po.uid).q;
check('delivery corrected: order received number follows', got === 2, String(got));

// ---------------------------------------------------------------- read an invoice photo on the device
await pg.evaluate(() => { window.__ocrText = 'Punjas Ltd\nTIN 500012345\nInv No: PJ-881\n1001 Punjas Flour 10kg 2 19.50 39.00\nRewa Milk 1L 10 2.10 21.00\nGrand Total 67.50\n'; });
await menu('inv-read-invoice');
await tap('ir-sup'); await text('Punjas Ltd');
await tap('ir-po'); await text(`${po.po_no} · ${po.order_date} · Part received`);
await tap('ir-photo-camera'); await pg.waitForTimeout(300);
await tap('ir-read'); await pg.waitForTimeout(500);
check('invoice read on the device: lines and number', await has('Item lines (2)') && (await id('ir-no').inputValue()) === 'PJ-881');
check('cost change flagged', await has('Cost price changes') && await has('$18.50 → $19.50'));
check('order match flags', await has('Please check'));
await id('ir-total').fill('67.50');
await tap('ir-learn'); await pg.waitForTimeout(300);
check("supplier's layout learned", await has('Learned for next time'));
await text('OK');
check('layout saved', !!db().prepare('SELECT 1 FROM supplier_layouts WHERE supplier_uid = ?').get(punjas));

// ---------------------------------------------------------------- scanning in a stock take
await menu('inv-count');
await tap('sc-new'); await tap('sc-start'); await pg.waitForTimeout(400);
await id('scc-scan-wedge').fill('9300002'); await id('scc-scan-wedge').press('Enter'); await pg.waitForTimeout(250);
await pad('7');
const cnt = db().prepare("SELECT counted FROM inv_count_lines WHERE item_uid = 'IT-1002' ORDER BY rowid DESC LIMIT 1").get();
check('stock take: scanned count entered', cnt && cnt.counted === 7);
await id('scc-scan-wedge').fill('9300002'); await id('scc-scan-wedge').press('Enter'); await pg.waitForTimeout(250);
await pad('2');
check('stock take: second scan adds', db().prepare("SELECT counted FROM inv_count_lines WHERE item_uid = 'IT-1002' ORDER BY rowid DESC LIMIT 1").get().counted === 9);

// ---------------------------------------------------------------- phone width
await pg.setViewportSize({ width: 390, height: 844 });
for (const item of ['inv-today-orders', 'inv-schedules', 'inv-read-invoice', 'inv-sup-import', 'inv-scan-po']) {
  await menu(item);
  const wide = await pg.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
  check(`phone width: ${item} fits`, !wide);
}
await shot('phone');

check('no page errors', errs.length === 0, errs.join('\n'));
await b.close(); srv.close && srv.close();
console.log(fails ? `\n${fails} FAILED` : '\nall passed');
process.exit(fails ? 1 : 0);
