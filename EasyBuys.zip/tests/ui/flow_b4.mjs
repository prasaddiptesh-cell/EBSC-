const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 B4 through the screens: till shifts (start, owner continues), a till count with two signatures, the till balance
// matched to an Aronium End of day (red mark, explain), till balance missing, shortage agreed by the cashier with a
// signature, Who owes us (Aronium staff credit CSV, person page, statement), the Dashboard (cards, choose, roles),
// all at tablet and phone width with no page errors.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const req = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = req('playwright');

for (const f of ['mb4']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: 8000 }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-fb4-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await tap('back'); };
const dlgOk = async () => { if (await id('dialog').count()) { const t = await id('dialog').innerText(); await text('OK'); return t; } return ''; };
const sql = (q, p = []) => srv.dbFor('mb4').prepare(q).run(...p);
const one = (q, p = []) => srv.dbFor('mb4').prepare(q).get(...p);
const sign = async (pad) => { await tap(`${pad}-open`); await tap(`${pad}-draw`); await tap(`${pad}-done`); };

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb4`); await pg.waitForTimeout(1200);
if (await pg.getByText('The app closed last time', { exact: true }).count()) await text('OK');
const today = await pg.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
sql("INSERT INTO tills (uid, shop_code, name, float_amount, active, sort, updated_at, updated_device) VALUES ('TLB4', 'S1', 'Till 1', 100, 1, 0, '2026-01-01 00:00:00', 'x')");
sql("UPDATE users SET sync_status = 'pending' WHERE name IN ('Admin', 'Sita Devi', 'Ravi Kumar') OR name LIKE 'Sita%' OR name LIKE 'Ravi%'"); // real staff (sample logins are hidden from staff lists)
const sita = one("SELECT uid FROM users WHERE name LIKE 'Sita%'");
const ravi = one("SELECT uid FROM users WHERE name LIKE 'Ravi%'");
await pin('1111');
await pg.waitForTimeout(400);

// ---------------------------------------------------------------- shifts
await tap('home-till');
check('till menu lists the new items', await has('Till shifts') && await has('Till shortages') && await has('Aronium End of day'));
await tap('mi-till-shifts');
await tap('sh-new');
await tap('sh-cashier'); await tap(`sh-cashier-opt-${sita.uid}`);
await tap('sh-start'); await pg.waitForTimeout(200);
const d0 = await dlgOk();
check('shift started', await has('Still to balance (1)'), d0);
await tap('sh-new');
await tap('sh-shift-Afternoon');
await tap('sh-cashier'); await tap(`sh-cashier-opt-${ravi.uid}`);
await tap('sh-start'); await pg.waitForTimeout(200);
const d1 = await dlgOk();
check('next shift waits for the last one to be balanced', /not balanced yet/.test(d1), d1.replace(/\n/g, ' '));
const sh = one("SELECT uid FROM till_shifts WHERE shift = 'Morning'");
await tap(`shift-${sh.uid}`);
await id('sh-z').fill('Z-0007'); await id('sh-ztotal').fill('500');
await tap('sh-continue'); await pg.waitForTimeout(200);
check('owner continued: flagged until counted', await has('COUNT IT'));
await tap('sh-start'); await pg.waitForTimeout(300);
await dlgOk();
check('afternoon shift now starts', one("SELECT COUNT(*) AS n FROM till_shifts WHERE status <> 'void'").n === 2);
// count the morning shift from its line
await tap(`shift-${sh.uid}`);
await tap('sh-count'); await pg.waitForTimeout(300);
check('count opened from the shift (Z filled in)', (await id('tc-z').inputValue()) === 'Z-0007');
await id('tc-d-n100').fill('5'); await id('tc-d-n50').fill('1');
await id('tc-zcash').fill('460');
await id('tc-reason').fill('Change given wrongly');
await tap('tc-photo-camera'); await pg.waitForTimeout(200);
await tap('sig-balancer'); await tap(`sig-balancer-opt-${sita.uid}`);
await sign('sig-cashier'); await sign('sig-bal');
await tap('tc-save'); await pg.waitForTimeout(300);
const d2 = await dlgOk();
check('same person as cashier and balancer refused', /cannot be both/.test(d2), d2.replace(/\n/g, ' '));
await tap('sig-balancer'); await tap(`sig-balancer-opt-${one("SELECT uid FROM users WHERE name = 'Admin'").uid}`);
await tap('tc-save'); await pg.waitForTimeout(400);
check('saved: short $10.00 and signed', await has('Short $10.00') && await has('(balanced it)'));
check('shortage waits for the cashier', await has('Waiting for the cashier'));
// cashier agrees in 2 parts
await tap('tc-shortage'); await pg.waitForTimeout(200);
const sht = one("SELECT uid FROM till_shortages WHERE status = 'waiting'");
await tap(`short-${sht.uid}`);
await tap('short-parts-2');
await sign('short-sig');
await tap('short-agree'); await pg.waitForTimeout(300);
check('agreed in 2 parts → in the pay run', one("SELECT status, parts, per_pay FROM till_shortages WHERE uid = ?", [sht.uid]).per_pay === 5 && await has('Agreed – taken from pay'));
await home();

// ---------------------------------------------------------------- Aronium End of day
await tap('home-till'); await tap('mi-till-eod');
await tap('eod-new');
await tap('eod-shop-S1');
await id('eod-z').fill('7'); await id('eod-total').fill('512');
await tap('eod-save'); await pg.waitForTimeout(300);
check('End of day matched to the shift Z: difference in red', await has('Difference – explain it') && await has('$12.00'));
await id('eod-why').fill('Refund done by hand, not in Aronium');
await tap('eod-resolve'); await pg.waitForTimeout(200);
check('difference explained', await has('Difference explained'));
await tap('back');
await tap('eod-new'); await tap('eod-shop-S1');
await id('eod-z').fill('8'); await id('eod-total').fill('300');
await tap('eod-save'); await pg.waitForTimeout(300);
check('End of day without a till balance: red', await has('Till balance missing'));
await home();
check('Home: till balance missing warning', await has('Till balance missing'));

// ---------------------------------------------------------------- To verify
await tap('home-verify'); await pg.waitForTimeout(300);
check('To verify lists the Aronium End of day', await has('Till balance missing (Aronium End of day)'));
await home();

// ---------------------------------------------------------------- who owes us
await tap('home-owed');
await tap('mi-owed-import');
await id('oi-text').fill('Customer,Balance\nSita Devi,85.50\nRavi Kumar,20\n');
await pg.waitForTimeout(300);
check('Aronium credit CSV read', await has('2 balance(s)'));
await tap('oi-bring'); await pg.waitForTimeout(300);
check('who owes us lists the staff', await has('Who owes us') && await has('$85.50'));
await tap(`owed-${sita.uid}`); await pg.waitForTimeout(200);
check('person page: credit and till shortage', await has('Staff credit') && await has('Till shortage'));
await tap('op-limit-edit'); await id('op-limit').fill('80'); await tap('op-limit-save'); await pg.waitForTimeout(200);
check('over the limit: red', await has('OVER the limit'));
await tap('op-pdf'); await pg.waitForTimeout(400);
check('statement report', await has('Statement – Sita') && (await id('export-pdf').count()) > 0);
await home();

// ---------------------------------------------------------------- dashboard
await tap('home-dashboard'); await tap('mi-home'); await pg.waitForTimeout(300);
check('dashboard cards', (await id('dash-sales').count()) > 0 && (await id('dash-till').count()) > 0 && (await id('dash-closed').count()) > 0);
check('a card without data says Not set up yet', (await id('dash-stock-notset').count()) > 0);
await tap('dash-shop-S1'); await pg.waitForTimeout(200);
await tap('dash-choose');
await tap('dc-show-sales'); await tap('dc-down-till');
await tap('back'); await pg.waitForTimeout(200);
check('hidden card gone', (await id('dash-sales').count()) === 0);
await tap('dash-roles');
await tap('dr-profit-manager'); await tap('dr-save'); await pg.waitForTimeout(200);
check('roles saved', JSON.parse(one("SELECT value FROM shared_settings WHERE key = 'dashboard_card_roles'").value).profit.includes('manager'));
await home();

// ---------------------------------------------------------------- phone width
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto(`http://localhost:${PORT + 10}/?dev=mb4`); await ph.waitForTimeout(1200);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(500);
const pw = async () => ph.evaluate(() => document.documentElement.scrollWidth);
const ptap = async (t) => { await ph.getByTestId(t).first().click({ timeout: 8000 }); await ph.waitForTimeout(250); };
const pback = async () => { for (let i = 0; i < 8 && !(await ph.getByTestId('home-admin').count()); i++) await ptap('back'); };
for (const [tile, item, name] of [['home-dashboard', 'mi-home', 'dashboard'], ['home-owed', 'mi-home', 'who owes us'], ['home-till', 'mi-till-shifts', 'shifts'], ['home-till', 'mi-till-eod', 'End of day'], ['home-till', 'mi-till-shortages', 'shortages']]) {
  await ptap(tile); await ptap(item);
  check(`phone: ${name} fits`, (await pw()) <= 400, `width ${await pw()}`);
  await pback();
}

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
