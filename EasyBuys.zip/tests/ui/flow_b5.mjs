const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 B5 through the screens: pay cycle, a pay run made final, pay sign-off on the locked employee screen (sign,
// "something is wrong", release without signature, leaving needs the admin PIN), reopen a final run, extra pay run,
// FNPF / PAYE per person, tax & statutory calendar with the two proofs, filing and filing templates, the Home tile,
// at tablet and phone width with no page errors.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const req = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = req('playwright');

for (const f of ['mb5']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-fb5-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 12 && !(await id('home-admin').count()); i++) await tap('back'); };
const dlgOk = async () => { if (await id('dialog').count()) { const t = await id('dialog').innerText(); await text('OK'); return t; } return ''; };
const sql = (q, p = []) => srv.dbFor('mb5').prepare(q).run(...p);
const one = (q, p = []) => srv.dbFor('mb5').prepare(q).get(...p);
const sign = async (pad) => { await tap(`${pad}-open`); await tap(`${pad}-draw`); await tap(`${pad}-done`); };

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb5`); await pg.waitForTimeout(1200);
if (await pg.getByText('The app closed last time', { exact: true }).count()) await text('OK');
sql("UPDATE users SET sync_status = 'pending' WHERE name LIKE 'Sita%' OR name LIKE 'Ravi%'");
const sita = one("SELECT uid, employee_no, name FROM users WHERE name LIKE 'Sita%'");
const ravi = one("SELECT uid, employee_no, name FROM users WHERE name LIKE 'Ravi%'");
for (const [u, rate, email] of [[sita, 6, 'sita@example.com'], [ravi, 7, null]]) {
  sql(`INSERT OR REPLACE INTO pay_profiles (user_uid, pay_type, rate, weekly_salary, tax_status, fnpf_member, pay_method, tin, fnpf_no, allowances, deductions, active, email, updated_at, updated_device)
    VALUES (?, 'hourly', ?, 0, 'resident', 1, 'cash', '123', 'F1', '[]', '[]', 1, ?, '2026-01-01 00:00:00', 'x')`, [u.uid, rate, email]);
}
const key = (u) => u.employee_no || u.name;
await pin('1111');
await pg.waitForTimeout(400);

// ---------------------------------------------------------------- payroll menu and pay cycle
await tap('home-payroll');
check('payroll menu has the new items', await has('Pay sign-off') && await has('Tax & statutory calendar') && await has('Filing (FNPF / FRCS)') && await has('Pay cycle & pay day') && await has('Extra pay run'));
await tap('mi-pay-cycle');
check('pay cycle: Saturday to Friday by default', await has('Every week, Saturday to Friday'));
await tap('cyc-freq-fortnightly'); await pg.waitForTimeout(200);
check('pay cycle preview follows the choice', await has('Every two weeks'));
await tap('cyc-freq-weekly'); await tap('cyc-save'); await pg.waitForTimeout(200);
await tap('back');

// ---------------------------------------------------------------- pay run, final, sign-off
await tap('mi-home');
await tap('pay-new-last'); await pg.waitForTimeout(300);
check('step 1: pay period and pay day shown big', (await id('npr-period').count()) > 0 && (await id('npr-paydate').count()) > 0);
await tap('npr-confirm'); await tap('npr-all'); await tap('npr-start'); await pg.waitForTimeout(500);
await dlgOk();
const run = one("SELECT * FROM pay_runs ORDER BY created_at DESC LIMIT 1");
check('pay run started for the last pay period', !!run && run.run_kind === 'regular', run && run.week_start);
// an undecided till shortage shows red in the pay run
sql("INSERT INTO till_shortages (uid, count_uid, shop_code, shift_date, user_uid, name, amount, status, created_at, updated_at) VALUES ('TSB5','TCB5','S1',?,?,?,4.5,'waiting','2026-01-01','2026-01-01')", [run.week_start, sita.uid, sita.name]);
await tap('run-recalc'); await pg.waitForTimeout(300);
check('undecided till shortage is red in the pay run', (await id('run-undecided').count()) > 0 && await has('cashier to agree'));
sql("UPDATE till_shortages SET status = 'void' WHERE uid = 'TSB5'");
await tap('run-final'); await pg.waitForTimeout(200);
await text('Make final'); await pg.waitForTimeout(400);
await dlgOk();
check('pay run final', one('SELECT status FROM pay_runs WHERE uid = ?', [run.uid]).status === 'final');
await tap('run-sign'); await pg.waitForTimeout(300);
check('sign-off list: nobody signed yet', await has('Not signed – pay not released'));
await tap(`pso-${key(sita)}`); await pg.waitForTimeout(300);
check('locked view shows the full payslip', (await id('psl-net').count()) > 0 && (await id('psl-counted').count()) > 0 && await has('Pay counted for FNPF'));
check('locked view: no log-out button', (await id('logout').count()) === 0);
await sign('psl-sig');
await tap('psl-sign'); await pg.waitForTimeout(400);
check('signed: pay released', (await id('psl-signed').count()) > 0);
check('after signing: Viber first, email, print', (await id('psl-viber').count()) > 0 && (await id('psl-email').count()) > 0 && (await id('psl-print').count()) > 0);
await tap('psl-email'); await pg.waitForTimeout(200);
check('payslip email queued', !!one("SELECT 1 AS x FROM outbox WHERE kind = 'payslip_email'"));
await tap('back'); await pg.waitForTimeout(200);
check('leaving asks for the admin PIN', (await id('psl-pin-box').count()) > 0);
await id('psl-pin').fill('2222'); await tap('psl-unlock'); await pg.waitForTimeout(200);
const wrong = await dlgOk();
check('wrong PIN keeps the screen locked', /Wrong PIN/.test(wrong) && (await id('psl-signed').count()) > 0, wrong.slice(0, 40));
await id('psl-pin').fill('1111'); await tap('psl-unlock'); await pg.waitForTimeout(300);
check('admin PIN leaves the locked view', await has('Pay sign-off · paid'));
await tap(`pso-${key(ravi)}`); await pg.waitForTimeout(300);
await tap('psl-mode-query');
await id('psl-note').fill('My Sunday hours are missing');
await tap('psl-query'); await pg.waitForTimeout(300);
check('"Something is wrong" sent', await has('You said something is wrong'));
await tap('psl-done'); await id('psl-pin').fill('1111'); await tap('psl-unlock'); await pg.waitForTimeout(300);
check('query shown to the manager', await has('My Sunday hours are missing'));
await tap(`pso-release-${key(ravi)}`); await tap(`pso-release-${key(ravi)}-ok`); await pg.waitForTimeout(300);
check('owner released pay without signature (recorded)', !!one("SELECT 1 AS x FROM audit_log WHERE action LIKE 'Released pay of%without a signature%'"));
await home();
check('Home: pay sign-off tile', (await id('home-paysign').count()) > 0);

// ---------------------------------------------------------------- reopen and correct
await tap('home-payroll'); await tap('mi-home');
await tap(`run-${run.week_start}`); await pg.waitForTimeout(300);
await tap('run-reopen'); await tap('run-reopen-ok'); await pg.waitForTimeout(400);
check('reopened: draft, version 2, logged', one('SELECT status, version FROM pay_runs WHERE uid = ?', [run.uid]).version === 2 && await has('Reopened by'));
await tap('run-final'); await text('Make final'); await pg.waitForTimeout(400); await dlgOk();
check('corrected payslip must be signed again', !one("SELECT released FROM pay_slip_status WHERE run_uid = ? AND user_uid = ?", [run.uid, sita.uid]).released);
await home();

// ---------------------------------------------------------------- extra pay run
await tap('home-payroll'); await tap('mi-pay-extra');
await id('xr-label').fill('Fiji Day bonus');
await id(`xr-amt-${key(sita)}`).fill('50');
await tap('xr-make'); await pg.waitForTimeout(400);
await dlgOk();
check('extra pay run made', !!one("SELECT 1 AS x FROM pay_runs WHERE run_kind = 'extra' AND label = 'Fiji Day bonus'") && await has('Fiji Day bonus'));
await home();

// ---------------------------------------------------------------- FNPF / PAYE per person
await tap('home-payroll'); await tap('mi-pay-profiles');
await pg.getByText(ravi.name, { exact: true }).first().click(); await pg.waitForTimeout(300);
await tap('prof-statrules'); await pg.waitForTimeout(300);
check('FNPF / PAYE screen with the hint', await has('Check with your accountant, FNPF and FRCS'));
await tap('sr-fnpf-on-false');
await id('sr-fnpf-note').fill('Family member');
await tap('sr-fnpf-save'); await pg.waitForTimeout(300);
check('FNPF off with a note saved', /Family member/.test(one('SELECT fnpf_rule FROM pay_profiles WHERE user_uid = ?', [ravi.uid]).fnpf_rule || ''));
await home();

// ---------------------------------------------------------------- tax calendar
await tap('home-payroll'); await tap('mi-pay-taxcal'); await pg.waitForTimeout(400);
check('tax calendar lists VAT', await has('VAT 20'));
await tap('tc-show-true'); await pg.waitForTimeout(200);
const vatRow = await pg.locator('[data-testid^="tc-vat-"]').first().getAttribute('data-testid');
await tap(vatRow); await pg.waitForTimeout(300);
// 3.9: VAT and FNPF are lodged and paid on the return screen (it books the payment in the accounts and the bank).
check('VAT item sends to the return screen', (await id('ti-return').count()) > 0 && await has('Lodge and pay it on the return screen'));
await tap('ti-return'); await pg.waitForTimeout(500);
check('VAT return screen opens', (await id('tr-pdf').count()) > 0 && (await id('tr-lodge-ref').count()) > 0);
await tap('back'); await pg.waitForTimeout(200);
await tap('back'); await pg.waitForTimeout(200);
// Other items (PAYE etc.) still take the two proofs on the item screen.
const other = await pg.locator('[data-testid^="tc-"]:not([data-testid^="tc-vat-"]):not([data-testid^="tc-fnpf-"]):not([data-testid^="tc-show"]):not([data-testid^="tc-settings"])').first().getAttribute('data-testid').catch(() => null);
if (other) {
  await tap(other); await pg.waitForTimeout(300);
  if (await id('ti-pay-amount').count()) {
    await id('ti-pay-amount').fill('120'); await id('ti-pay-ref').fill('BSP-77');
    await tap('ti-pay-save'); await pg.waitForTimeout(300);
    check('paid but not lodged is red', (await id('ti-flag-paid_not_lodged').count()) > 0);
    await id('ti-lodge-ref').fill('FRCS-1'); await tap('ti-lodge-photo-camera'); await pg.waitForTimeout(200);
    await tap('ti-lodge-save'); await pg.waitForTimeout(300);
    check('payment proof missing is amber', (await id('ti-flag-proof_missing').count()) > 0);
    await tap('ti-pay-more-camera'); await pg.waitForTimeout(200); await tap('ti-pay-addproof'); await pg.waitForTimeout(300);
    check('both proofs in', (await id('ti-done').count()) > 0 && await has('History'));
  } else console.log('     (' + other + ': nothing to record)');
  await tap('back'); await pg.waitForTimeout(200);
}
await tap('tc-settings'); await pg.waitForTimeout(300);
check('tax calendar settings', await has('Responsible person') && await has('Start reminding'));
await tap('tcs-save'); await pg.waitForTimeout(200);
await home();

// ---------------------------------------------------------------- filing
await tap('home-payroll'); await tap('mi-pay-filing'); await pg.waitForTimeout(300);
check('filing: checks before filing', await has('Checks before filing') && await has('No official template uploaded yet'));
await tap('fl-kind-payday'); await pg.waitForTimeout(300);
check('pay day filing shows the people', (await id('fl-table').count()) > 0);
await tap('fl-copy'); await pg.waitForTimeout(500);
check('pay day report: both shops together', await has('Both shops together'));
await tap('back'); await tap('back');
await tap('mi-pay-filing-setup'); await pg.waitForTimeout(300);
await id('fs-paste').fill('Member No,Member Name,Total Wages,Employee Contribution,Employer Contribution');
await tap('fs-paste-go'); await pg.waitForTimeout(300);
await tap('fs-save'); await pg.waitForTimeout(300);
check('FNPF template saved with its columns', /Member No/.test(JSON.stringify(one("SELECT value FROM shared_settings WHERE key = 'filing_templates'") || {})));
await tap('back'); await tap('mi-pay-signoff-settings'); await pg.waitForTimeout(200);
await tap('pss-mode-auto'); await tap('pss-save'); await pg.waitForTimeout(200);
check('sign-off settings saved', /auto/.test(JSON.stringify(one("SELECT value FROM shared_settings WHERE key = 'pay_signoff_rules'") || {})));
await home();

// ---------------------------------------------------------------- phone width
const ph = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
ph.on('pageerror', (e) => errs.push('PHONE ' + e.message));
await ph.goto(`http://localhost:${PORT + 10}/?dev=mb5`); await ph.waitForTimeout(1200);
if (await ph.getByText('The app closed last time', { exact: true }).count()) { await ph.getByText('OK', { exact: true }).last().click(); await ph.waitForTimeout(200); }
for (const k of '1111') { await ph.getByTestId(`pin-${k}`).first().click(); await ph.waitForTimeout(60); }
await ph.waitForTimeout(500);
const pw = async () => ph.evaluate(() => document.documentElement.scrollWidth);
const ptap = async (t) => { await ph.getByTestId(t).first().click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); await ph.waitForTimeout(250); };
const pback = async () => { for (let i = 0; i < 8 && !(await ph.getByTestId('home-admin').count()); i++) await ptap('back'); };
for (const item of ['mi-pay-signoff', 'mi-pay-taxcal', 'mi-pay-filing', 'mi-pay-cycle', 'mi-pay-extra', 'mi-pay-taxcal-settings', 'mi-pay-filing-setup']) {
  await ptap('home-payroll'); await ptap(item);
  check(`phone: ${item} fits`, (await pw()) <= 400, `width ${await pw()}`);
  await pback();
}
await ptap('home-paysign'); await ptap(`pso-run-${run.pay_date}`); await ptap(`pso-${key(sita)}`);
check('phone: locked payslip fits', (await pw()) <= 400, `width ${await pw()}`);

console.log(errs.length ? '\nERRORS:\n' + errs.join('\n') : '\nno page errors');
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
await b.close();
srv.close();
process.exit(fails || errs.length ? 1 : 0);
