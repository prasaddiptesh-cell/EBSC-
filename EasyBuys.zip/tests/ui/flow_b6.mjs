const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// v3.5 B6: Loans & rent (easy setup, a closed-shop loan, loan journey with chart, lender statement check, receipts)
// and Owner's money (take money out, business paid for me with a business share, home rent reminder), tablet and phone.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');

for (const f of ['mb6']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
fs.rmSync(`${TMP}/fs-mb6`, { recursive: true, force: true });
const srv = startServer({ port: PORT + 10 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
pg.on('console', (m) => { if (m.type() === 'error' && !/empty string|shorthand|Not allowed to load local resource|ERR_INTERNET_DISCONNECTED/.test(m.text())) errs.push('CONSOLE ' + m.text().slice(0, 300)); });
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-fb6-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(150); };
const fill = async (t, v) => { await id(t).fill(v); await pg.waitForTimeout(60); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()); i++) await tap('back'); };
const q = (s, p = []) => srv.dbFor('mb6').prepare(s).get(...p);
const noWide = async () => pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 2);

await pg.goto(`http://localhost:${PORT + 10}/?dev=mb6`); await pg.waitForTimeout(900);
await pin('1111');

// ---------------------------------------------------------------- Loans & rent: easy setup
await tap('home-loans');
check('Loans & rent menu', await has('Set up loans & rent') && await has('Check a loan against the lender statement') && await has('Receipts to photograph'));
await tap('mi-home');
check('overview says nothing is set up yet', await has('Nothing set up yet'));
await tap('lr-setup');
check('setup lists the 3 shop loans, 2 car loans and 3 rents', await has('V M Pillay (closed shop) – business loan') && await has('Car loan PB 113 – Credit Corp') && await has('Car loan ON 485 – BSP') && await has('Shop 2 Tukani Street (Kiran Palace) – rent'));
await tap('ls-loan_vmp');
check('closed shop chosen for the V M Pillay loan', await has('Closed shop: its costs show on their own line'));
await fill('re-newlender', 'BSP Loans');
await fill('re-amount', '500');
await fill('re-price', '12000'); await fill('re-deposit', '2500');
await fill('re-opening', '10000');
await fill('re-rate', '12');
await tap('re-arr-fixed'); await fill('re-arrval', '25');
await tap('re-save'); await pg.waitForTimeout(400);
const loan = q("SELECT r.uid, r.shop_code, t.template, t.arrears_rule FROM ap_recurring r JOIN regular_terms t ON t.uid = r.uid WHERE r.kind = 'loan'");
check('loan saved with its details, in the closed shop', !!loan && loan.shop_code === 'CLOSED' && loan.template === 'loan_vmp' && loan.arrears_rule === 'fixed', JSON.stringify(loan));
check('setup shows it ticked', await has('☑ V M Pillay (closed shop) – business loan'));
await tap('ls-rent_s1');
await fill('re-newlender', 'Drasa Landlord'); await fill('re-amount', '1125');
await tap('re-save'); await pg.waitForTimeout(400);
check('rent saved for Shop 1', !!q("SELECT uid FROM ap_recurring WHERE kind = 'bill' AND shop_code = 'S1'"));
await tap('back');
await pg.waitForTimeout(300);
check('overview groups shop loans and rent', await has('Shop loan') && await has('Shop rent') && await has('CLOSED SHOP'));

// ---------------------------------------------------------------- loan journey and lender statement check
await tap(`lr-${loan.uid}`);
check('loan journey: balance, payoff, chart, every line', await has('Balance left') && await has('Paid off by') && (await id('lj-chart').count()) > 0 && await has('Amount borrowed') && await has('Deposit paid'));
await tap('lj-recon');
await fill('lc-balance', '10050');
await tap('lc-compare');
check('compare shows the difference and a fix', await has('Difference') && await has('Add $50.00 to the balance'));
await tap('lc-save'); await pg.waitForTimeout(300);
check('check saved and agreed', await has('AGREED') && !!q("SELECT 1 AS x FROM loan_recons WHERE status = 'agreed'"));
check('fix made as a loan entry', !!q("SELECT 1 AS x FROM loan_entries WHERE type = 'adjust_up' AND amount = 50"));
await tap('back');
check('journey shows the correction and last checked date', await has('Correction (+)') && await has('$10050.00'));
await tap('lj-receipts');
check('receipts screen for the loan', await has('Receipts – V M Pillay'));
await home();
await tap('home-loans'); await tap('mi-loan-receipts');
check('receipts to photograph: none missing', await has('Every payment has its receipt photo'));
await home();

// ---------------------------------------------------------------- Owner's money
await tap('home-loans');
check("Owner's money menu", await has('Take money out') && await has('Business paid for me') && await has('Put money in') && await has('Home rent & groceries reminders'));
await tap('mi-own-out');
await fill('om-amount', '200');
await tap('om-save'); await pg.waitForTimeout(400);
const out = q("SELECT * FROM owner_moves WHERE kind = 'take_out'");
check('take money out saved, cash from Shop 1, booked as drawings', !!out && out.via === 'cash:S1' && !!q("SELECT 1 AS x FROM gl_journals WHERE uid = ? AND kind = 'owner'", [out.journal_uid]) && !!q("SELECT 1 AS x FROM cash_moves WHERE ref_uid = ?", [out.uid]));
await home(); await tap('home-loans'); await tap('mi-own-paid');
await fill('om-amount', '225'); await fill('om-what', 'Phone bill'); await fill('om-pct', '40');
check('business share split shown, with the accountant hint', await has('Business part $90.00') && await has('personal part $135.00') && await has('Agree the business share % with your accountant'));
await tap('om-photo-camera'); await pg.waitForTimeout(300);
await tap('om-save'); await pg.waitForTimeout(400);
const mix = q("SELECT * FROM owner_moves WHERE kind = 'paid_for_me'");
check('mixed cost saved: business 90, drawings 135, receipt photo', !!mix && mix.business_amount === 90 && mix.personal_amount === 135 && JSON.parse(mix.photo_urls).length === 1);
await home(); await tap('home-loans'); await tap('mi-own-home');
check('totals: taken out and paid for me', await has('$200.00') && await has('$135.00') && await has('never through payroll'));
await tap('own-reminders');
await tap('pr-add-rent'); await fill('pr-amount', '800'); await tap('pr-save'); await pg.waitForTimeout(300);
check('home rent reminder added', await has('Home rent') && !!q("SELECT 1 AS x FROM personal_regulars WHERE kind = 'home_rent'"));
await tap('pr-done-home_rent');
await tap('prd-photo-camera'); await pg.waitForTimeout(300);
await tap('prd-save'); await pg.waitForTimeout(400);
check('home rent paid by the business = drawings (not a business cost)', !!q("SELECT 1 AS x FROM owner_moves WHERE kind = 'paid_for_me' AND what = 'Home rent' AND business_amount = 0 AND personal_amount = 800"));
await home();
await tap('home-loans'); await tap('mi-own-settings');
await tap('ds-per-true'); await fill('ds-name', 'Divnesh'); await tap('ds-add'); await fill('ds-name', 'Sumintra'); await tap('ds-add');
await tap('ds-save'); await pg.waitForTimeout(300);
check('family members saved', JSON.parse(q("SELECT value FROM shared_settings WHERE key = 'drawings_rules'").value).members.length === 2);
await home();

// ---------------------------------------------------------------- phone width
await pg.setViewportSize({ width: 390, height: 844 }); await pg.waitForTimeout(300);
await tap('home-loans'); await tap('mi-home');
check('phone: loans overview fits', await has('Loans & rent') && await noWide());
await tap(`lr-${loan.uid}`);
check('phone: loan journey fits', await has('Balance left') && await noWide());
await home(); await tap('home-loans'); await tap('mi-own-home');
check("phone: owner's money fits", await has('Net drawings') && await noWide());
await tap('own-paid');
check('phone: form shows who it is for (family members)', await has('For whom') && await noWide());
await home();

check('no page errors', !errs.length, errs.join('\n'));
await b.close(); srv.close();
console.log(fails ? `\n${fails} FAILED` : '\nall ok');
process.exit(fails ? 1 : 0);
