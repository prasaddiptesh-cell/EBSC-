const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// Go-live bakery: one "Bakery today" home with the baker's day steps; opening stock opens the day; baking locked for a
// baker until clocked in + opening checklists; Close & count; ingredients linked to Inventory products.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['mbk']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 12 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-fbk-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(200); };
const text = async (t) => { await pg.getByText(t, { exact: true }).last().click(); await pg.waitForTimeout(300); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };
const home = async () => { for (let i = 0; i < 10 && !(await id('home-admin').count()) && !(await id('logout').count() && await id('home-bakery').count()); i++) await tap('back'); };
const q = (s, p = []) => srv.dbFor('mbk').prepare(s).get(...p);
const bakery = async () => { await tap('home-bakery'); await pg.waitForTimeout(300); if (await id('mi-home').count()) await tap('mi-home'); };

await pg.goto(`http://localhost:${PORT + 12}/?dev=mbk`); await pg.waitForTimeout(900);
// A baker: the day starts with the Time Clock; New batch is locked.
await pin('3333');
await bakery();
check('Bakery today for the baker', await has("The baker's day") && await has('Clock in'));
check('step 1 is to clock in', await id('bd-step-clock-in').count() > 0);
await tap('logout'); await pg.waitForTimeout(300);
// The owner/admin can open the day.
await pin('1111');
await bakery();
await tap('bd-step-opening');
check('opening stock screen', await has('Count the opening stock'));
await tap('shift-Early Bake'); await tap('confirm-start'); await text('Confirm & start'); await pg.waitForTimeout(500);
check('day opened', !!q("SELECT 1 x FROM shifts WHERE status = 'open'"));
check('back on Bakery today, opening checklists next', await has('Opening checklists') && await has('Day opened'));
await tap('tile-new-batch'); check('admin can start a batch (override)', await has('Tap the product you are making')); await tap('back');
await tap('bd-step-close');
check('close & count opens with the ingredients', await has('Count what is left in the bakery store') && await has('Flour'));
await tap('bc-same'); await pg.waitForTimeout(200);
check('filled in what the app expects', await has('Close & balance'));
await tap('back');
// Ingredient linked to an Inventory product.
for (let i = 0; i < 6 && !(await id('mi-bk-materials').count()); i++) { await tap('back'); if (await id('home-bakery').count()) { await tap('home-bakery'); break; } }
await tap('mi-bk-materials'); await text('Flour');
check('ingredient shows "Ordered & received through Inventory"', await has('Ordered & received through Inventory'));
check('no page errors', !errs.length, errs.join('\n'));
await b.close(); srv.close && srv.close();
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
process.exit(fails ? 1 : 0);
