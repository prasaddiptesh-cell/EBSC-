const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// Go-live: first-run tour (once per person), "Show me how" tutorial with the button outlined, quick check, progress.
import { createRequire } from 'module';
import fs from 'fs';
import { startServer } from './server.mjs';
const { chromium } = createRequire('/opt/npm-tools/node_modules/')('playwright');
for (const f of ['mtr']) { try { fs.unlinkSync(`${TMP}/ui-${f}.db`); } catch (e) {} }
const srv = startServer({ port: PORT + 13 });
const b = await chromium.launch();
const errs = [];
let fails = 0;
const check = (n, ok, x) => { console.log((ok ? 'ok   ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };
const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
await ctx.route('https://script.google.com/**', (route) => route.abort('internetdisconnected'));
const pg = await ctx.newPage();
pg.on('pageerror', (e) => errs.push('PAGE ' + e.message));
const id = (t) => pg.getByTestId(t).first();
const tap = async (t) => { try { await id(t).click({ timeout: Number(process.env.EB_TAP_MS || 8000) }); } catch (e) { await pg.screenshot({ path: `${TMP}/ui-ftr-fail.png` }); console.log('ERRORS so far:\n' + errs.join('\n')); throw e; } await pg.waitForTimeout(200); };
const has = async (t) => (await pg.getByText(t, { exact: false }).count()) > 0;
const pin = async (p) => { for (const k of p) await tap(`pin-${k}`); await pg.waitForTimeout(300); };

await pg.goto(`http://localhost:${PORT + 13}/?dev=mtr&tour=1`); await pg.waitForTimeout(900);
await pin('1111'); await pg.waitForTimeout(1200);
check('first-run tour starts by itself', await id('tutorial-bar').count() > 0 && await has('A quick look around'));
for (let i = 0; i < 12 && await id('tutorial-next').count(); i++) await tap('tutorial-next');
check('tour finished and gone', !(await id('tutorial-bar').count()));
await tap('logout'); await pin('1111'); await pg.waitForTimeout(1200);
check('tour shown once per person', !(await id('tutorial-bar').count()));
await tap('home-help');
check('Help & how-to opens the guides', await has('How to do each job'));
await tap('help-tutorials'); await pg.waitForTimeout(300);
check('tutorials list', await has('Show me around') && await has('Count a till and bank the cash'));
await tap('tut-start-till'); await pg.waitForTimeout(600);
check('tutorial starts on Home', await has('Tap Till & cash'));
const outline = await id('home-till').evaluate((el) => getComputedStyle(el).borderTopColor);
check('the button to press has an orange outline', /255, 106, 0/.test(outline), outline);
for (let i = 0; i < 8 && await id('tutorial-next').count(); i++) await tap('tutorial-next');
check('quick check at the end', await has('Quick check'));
await tap('quiz-0-1'); await tap('quiz-1-1'); await tap('quiz-2-0'); await tap('quiz-submit');
check('all correct', await has('Well done!'));
await tap('quiz-done'); await tap('tut-progress');
check('owner sees training progress', await has('Training progress'));
// "Show me how" on a module menu; Close always ends it.
for (let i = 0; i < 6 && !(await id('home-admin').count()); i++) await tap('back');
await tap('home-payables'); if (await id('mi-home').count()) { /* on the menu */ } 
if (await id('show-me-invoice').count()) { await tap('show-me-invoice'); check('Show me how from the menu', await id('tutorial-bar').count() > 0); await tap('tutorial-close'); check('Close ends it', !(await id('tutorial-bar').count())); }
else check('Show me how on the module menu', false);
check('no page errors', !errs.length, errs.join('\n'));
await b.close(); srv.close && srv.close();
console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
process.exit(fails ? 1 : 0);
