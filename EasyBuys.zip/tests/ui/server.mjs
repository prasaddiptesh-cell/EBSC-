// Test server: serves the app, one real SQLite database per pretend device (?dev=name), and a pretend cloud.
import http from 'http';
import fs from 'fs';
import { DatabaseSync } from 'node:sqlite';

export function startServer({ port = 8765, cloud } = {}) {
  const dbs = {};
  const dbFor = (dev) => (dbs[dev] = dbs[dev] || new DatabaseSync(`/tmp/claude-0/ui-${dev}.db`));
  const html = '<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;font-family:Arial,sans-serif}#root{height:100vh;display:flex;flex-direction:column}</style></head><body><div id="root"></div><script src="/bundle.js"></script></body></html>';
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (req.method === 'GET' && url.pathname === '/') { res.end(html); return; }
    if (req.method === 'GET' && url.pathname === '/bundle.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(fs.readFileSync('/tmp/claude-0/ui-bundle.js')); return; }
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      if (url.pathname === '/sql') {
        const { op, sql, params } = JSON.parse(body);
        const d = dbFor((url.searchParams.get('dev') || 'tablet') + (url.searchParams.get('db') ? '-' + url.searchParams.get('db').replace(/[^\w.-]/g, '') : ''));
        try {
          let result = null;
          const p = (params || []).map((v) => (v === undefined ? null : v === true ? 1 : v === false ? 0 : v));
          if (op === 'exec') d.exec(sql);
          else if (op === 'run') { const r = d.prepare(sql).run(...p); result = { changes: Number(r.changes), lastInsertRowId: Number(r.lastInsertRowid) }; }
          else if (op === 'all') result = d.prepare(sql).all(...p).map((r) => ({ ...r }));
          else if (op === 'get') { const r = d.prepare(sql).get(...p); result = r ? { ...r } : null; }
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result }));
        } catch (e) { res.end(JSON.stringify({ error: e.message })); }
        return;
      }
      if (url.pathname === '/cloud' && cloud) {
        res.setHeader('Content-Type', 'application/json');
        res.end(cloud(body));
        return;
      }
      res.statusCode = 404; res.end('no');
    });
  });
  server.listen(port);
  return { server, dbFor, close: () => { server.close(); Object.values(dbs).forEach((d) => d.close()); } };
}
