const TMP = process.env.EB_TMP || '/tmp/claude-0'; const PORT = Number(process.env.EB_PORT || 8765);
// Test server: serves the app, one real SQLite database per pretend device (?dev=name), and a pretend cloud.
import http from 'http';
import fs from 'fs';
import path from 'path';
const fsRoot = (url) => `${TMP}/fs-${(url.searchParams.get('dev') || 'tablet').replace(/[^\w.-]/g, '')}`;
import { DatabaseSync } from 'node:sqlite';

export function startServer({ port = PORT, cloud } = {}) {
  const dbs = {};
  const dbFor = (dev) => (dbs[dev] = dbs[dev] || new DatabaseSync(`${TMP}/ui-${dev}.db`));
  const html = '<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0;font-family:Arial,sans-serif}#root{height:100vh;display:flex;flex-direction:column}</style></head><body><div id="root"></div><script src="/bundle.js"></script></body></html>';
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (req.method === 'GET' && url.pathname === '/') { res.end(html); return; }
    if (req.method === 'GET' && url.pathname === '/bundle.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(fs.readFileSync(TMP + '/ui-bundle.js')); return; }
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      if (url.pathname === '/fs') {
        // Real files for the database copies: file:///doc/... is kept under TMP/fs-<device>/doc/...
        const { op, a, b } = JSON.parse(body);
        const map = (u) => fsRoot(url) + String(u).replace(/^file:\/\//, '');
        res.setHeader('Content-Type', 'application/json');
        try {
          let result = null;
          if (op === 'mkdir') fs.mkdirSync(map(a), { recursive: true });
          else if (op === 'list') result = fs.existsSync(map(a)) ? fs.readdirSync(map(a)) : [];
          else if (op === 'info') { const p = map(a); result = fs.existsSync(p) ? { exists: true, size: fs.statSync(p).size } : { exists: false }; }
          else if (op === 'copy') { fs.mkdirSync(path.dirname(map(b)), { recursive: true }); fs.copyFileSync(map(a), map(b)); }
          else if (op === 'delete') { try { fs.unlinkSync(map(a)); } catch (e) { /* gone */ } }
          else if (op === 'read') result = fs.readFileSync(map(a)).toString('base64');
          else if (op === 'write') { fs.mkdirSync(path.dirname(map(a)), { recursive: true }); fs.writeFileSync(map(a), Buffer.from(b || '', 'base64')); }
          res.end(JSON.stringify({ result }));
        } catch (e) { res.end(JSON.stringify({ error: e.message })); }
        return;
      }
      if (url.pathname === '/sql') {
        const { op, sql: sql0, params } = JSON.parse(body);
        // VACUUM INTO '/doc/…' (database copies) writes under TMP/fs-<device>.
        let sql = sql0;
        const vac = /VACUUM INTO '([^']+)'/i.exec(sql0 || '');
        if (vac) { const target = fsRoot(url) + vac[1]; fs.mkdirSync(path.dirname(target), { recursive: true }); sql = sql0.replace(vac[1], target.replace(/'/g, "''")); }
        const d = dbFor((url.searchParams.get('dev') || 'tablet') + (url.searchParams.get('db') ? '-' + url.searchParams.get('db').replace(/[^\w.-]/g, '') : ''));
        const t0 = Date.now();
        try {
          let result = null;
          const p = (params || []).map((v) => (v === undefined ? null : v === true ? 1 : v === false ? 0 : v));
          if (op === 'exec') d.exec(sql);
          else if (op === 'run') { const r = d.prepare(sql).run(...p); result = { changes: Number(r.changes), lastInsertRowId: Number(r.lastInsertRowid) }; }
          else if (op === 'all') result = d.prepare(sql).all(...p).map((r) => ({ ...r }));
          else if (op === 'get') { const r = d.prepare(sql).get(...p); result = r ? { ...r } : null; }
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result }));
          if (process.env.EB_SQLLOG) fs.appendFileSync(process.env.EB_SQLLOG, `${Date.now() - t0}ms ${String(sql).replace(/\s+/g, ' ').slice(0, 160)} ${JSON.stringify(p).slice(0, 80)}\n`);
        } catch (e) { res.end(JSON.stringify({ error: e.message })); }
        return;
      }
      if (url.pathname === '/cloud' && cloud) {
        res.setHeader('Content-Type', 'application/json');
        res.end(cloud(body));
        return;
      }
      res.statusCode = 404; res.end('no');
    });
  });
  server.listen(port);
  return { server, dbFor, close: () => { server.close(); Object.values(dbs).forEach((d) => d.close()); } };
}
