// Stand-ins for Expo libraries (tests only).
import React, { forwardRef, useEffect, useImperativeHandle } from 'react';
export const StatusBar = () => null;
// keep awake
export const activateKeepAwakeAsync = async () => {};
export const deactivateKeepAwake = () => {};
export const useKeepAwake = () => {};
// notifications
export const AndroidImportance = { MAX: 5, HIGH: 4 };
export const AndroidNotificationVisibility = { PUBLIC: 1 };
export const SchedulableTriggerInputTypes = { DATE: 'date', TIME_INTERVAL: 'timeInterval' };
export const setNotificationHandler = () => {};
export const requestPermissionsAsync = async () => ({ granted: true, status: 'granted' });
export const getPermissionsAsync = async () => ({ granted: true, status: 'granted' });
export const scheduleNotificationAsync = async () => 'n';
export const cancelAllScheduledNotificationsAsync = async () => {};
export const setNotificationChannelAsync = async () => {};
// print / share
export const printAsync = async () => { (window.__printed = window.__printed || []).push(1); };
export const printToFileAsync = async ({ html }) => { window.__lastHtml = html; return { uri: 'file:///cache/print.pdf', base64: 'UERG' }; };
export const isAvailableAsync = async () => true;
export const shareAsync = async (uri, o) => { (window.__shared = window.__shared || []).push([uri, o && o.mimeType]); };
// files: most live in memory (window.__files); the database copies (…/snapshots/, …/SQLite/) are real files kept by
// the test server (so SQLite's VACUUM INTO can write them).
const files = (window.__files = window.__files || {});
const real = (u) => /^file:\/\/\/doc\/(snapshots|SQLite)\//.test(String(u || ''));
function fsCall(op, a, b) {
  const x = new XMLHttpRequest();
  x.open('POST', '/fs' + location.search, false);
  x.setRequestHeader('Content-Type', 'application/json');
  x.send(JSON.stringify({ op, a, b }));
  const r = JSON.parse(x.responseText);
  if (r.error) throw new Error(r.error);
  return r.result;
}
export const documentDirectory = 'file:///doc/';
export const cacheDirectory = 'file:///cache/';
export const EncodingType = { Base64: 'base64', UTF8: 'utf8' };
export const makeDirectoryAsync = async (u) => { if (real(u + '/')) fsCall('mkdir', u); };
export const copyAsync = async ({ from, to }) => { if (real(from) || real(to)) fsCall('copy', from, to); else files[to] = files[from] || 'QUJD'; };
export const deleteAsync = async (u) => { if (real(u)) fsCall('delete', u); else delete files[u]; };
export const writeAsStringAsync = async (u, d) => { if (real(u)) fsCall('write', u, d); else files[u] = d; };
export const readAsStringAsync = async (u) => (u === 'file:///cache/pick.csv' ? window.__pickText : real(u) ? fsCall('read', u) : files[u] || 'QUJD');
export const getInfoAsync = async (u) => (real(u) ? fsCall('info', u) : { exists: u in files || true, size: 1234 });
export const readDirectoryAsync = async (u) => (real(u) ? fsCall('list', u) : Object.keys(files).filter((k) => k.startsWith(u)).map((k) => k.slice(u.length)));
export const getFreeDiskStorageAsync = async () => (window.__freeDisk === undefined ? 8e9 : window.__freeDisk);
// Android storage access (the "outside" folder): kept in memory.
export const StorageAccessFramework = {
  getUriForDirectoryInRoot: (f) => `content://com.android.externalstorage.documents/tree/primary%3A${f}`,
  requestDirectoryPermissionsAsync: async () => (window.__safDenied ? { granted: false } : { granted: true, directoryUri: 'content://saf/tree/primary%3ADocuments%2FEasy%20Buys%20Backups' }),
  readDirectoryAsync: async (dir) => Object.keys(files).filter((k) => k.startsWith(dir + '%2F')),
  createFileAsync: async (dir, name) => { const u = `${dir}%2F${encodeURIComponent(name)}`; files[u] = ''; return u; },
  deleteAsync: async (u) => { delete files[u]; },
};
// audio (window.__sounds lists what played; loop = true while an urgent alarm repeats)
export const setAudioModeAsync = async () => {};
export const createAudioPlayer = (src) => {
  const p = { loop: false, playing: false, src,
    play() { p.playing = true; (window.__sounds = window.__sounds || []).push({ src: String(src).slice(0, 40), loop: p.loop }); window.__soundLoop = p.loop; },
    pause() { p.playing = false; window.__soundLoop = false; }, seekTo: async () => {}, remove() {} };
  return p;
};
// image picker
export const requestCameraPermissionsAsync = async () => ({ granted: true });
export const requestMediaLibraryPermissionsAsync = async () => ({ granted: true });
export const launchCameraAsync = async () => ({ canceled: false, assets: [{ uri: 'file:///cache/cam.jpg' }] });
export const launchImageLibraryAsync = async () => ({ canceled: false, assets: [{ uri: 'file:///cache/lib.jpg' }] });
// camera (face photos: window.__face = 'A' | 'B' | 'none')
export const useCameraPermissions = () => [{ granted: true, canAskAgain: false }, () => {}];
export const CameraView = forwardRef(function CameraView({ onCameraReady, onBarcodeScanned }, ref) {
  // QR scanning: the test calls window.__scanQr('text')
  useEffect(() => { if (onBarcodeScanned) { window.__scanQr = (data) => onBarcodeScanned({ type: 'qr', data }); return () => { window.__scanQr = null; }; } return undefined; }, [onBarcodeScanned]);
  useImperativeHandle(ref, () => ({ takePictureAsync: async () => ({ uri: 'file:///cache/pic.jpg' }) }));
  useEffect(() => { setTimeout(() => onCameraReady && onCameraReady(), 10); }, []);
  return <div data-testid="camera" style={{ flex: 1, background: '#333', color: '#fff' }}>camera</div>;
});
export const manipulateAsync = async (uri, a, o) => ({ uri: 'file:///cache/small.jpg', base64: o && o.base64 ? (window.__manipB64 || `FACE_${window.__face || 'A'}`) : undefined });
export const SaveFormat = { JPEG: 'jpeg', PNG: 'png' };

// document picker (window.__pickText = csv text)
export const getDocumentAsync = async () => {
  if (window.__pickFile) { const f = window.__pickFile; files['file:///cache/' + f.name] = f.data || 'UERG'; return { canceled: false, assets: [{ uri: 'file:///cache/' + f.name, name: f.name, mimeType: f.mime, size: 1234 }] }; }
  return window.__pickText ? { canceled: false, assets: [{ uri: 'file:///cache/pick.csv', name: 'pick.csv' }] } : { canceled: true };
};
export const SaveFormatPNG = 'png';
