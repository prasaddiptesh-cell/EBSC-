export default class JSZip { file() { return this; } folder() { return this; } async generateAsync() { return 'UEsDBA=='; } }
