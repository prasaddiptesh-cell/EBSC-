// On-device text recognition in the browser tests: window.__ocrText is the text "read" from any photo.
export default { recognize: async () => { const t = window.__ocrText || ''; return { text: t, blocks: t ? [{ lines: t.split('\n').map((x) => ({ text: x })) }] : [] }; } };
