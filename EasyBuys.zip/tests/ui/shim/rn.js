// React Native stand-ins for running the real screens in a browser (tests only).
import React, { useEffect, useState } from 'react';
const flat = (s) => (Array.isArray(s) ? Object.assign({}, ...s.flat(20).filter(Boolean).map(flat)) : (s || {}));
const NUM_PX = new Set(['fontSize', 'lineHeight', 'width', 'height', 'minWidth', 'minHeight', 'maxWidth', 'maxHeight', 'padding', 'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight', 'margin', 'marginTop', 'marginBottom', 'marginLeft', 'marginRight', 'borderRadius', 'borderWidth', 'gap', 'top', 'left', 'right', 'bottom']);
export function css(s, base = {}) {
  const o = { display: 'flex', flexDirection: 'column', boxSizing: 'border-box', ...base };
  for (const [k, v] of Object.entries(flat(s))) {
    if (k === 'paddingHorizontal') { o.paddingLeft = o.paddingRight = v; continue; }
    if (k === 'paddingVertical') { o.paddingTop = o.paddingBottom = v; continue; }
    if (k === 'marginHorizontal') { o.marginLeft = o.marginRight = v; continue; }
    if (k === 'marginVertical') { o.marginTop = o.marginBottom = v; continue; }
    if (k === 'borderWidth') { o.borderStyle = o.borderStyle || 'solid'; o.borderWidth = v; continue; }
    if (k === 'borderLeftWidth' || k === 'borderBottomWidth' || k === 'borderTopWidth') { o[k] = v; o[k.replace('Width', 'Style')] = 'solid'; continue; }
    if (k === 'elevation' || k === 'textAlignVertical' || k === 'resizeMode') continue;
    if (k === 'flex' && typeof v === 'number') { o.flex = `${v} ${v} 0%`; continue; }
    if (k === 'lineHeight' && typeof v === 'number') { o.lineHeight = `${v}px`; continue; }
    o[k] = v;
  }
  return o;
}
const tid = (p) => (p.testID ? { 'data-testid': p.testID } : {});
export const View = React.forwardRef(({ style, children, testID, onTouchStart, pointerEvents }, ref) => (
  <div ref={ref} data-testid={testID} onMouseDown={onTouchStart} style={{ ...css(style), pointerEvents: pointerEvents === 'none' ? 'none' : undefined }}>{children}</div>));
export const Text = React.forwardRef(({ style, children, onPress, onLongPress, testID, numberOfLines }, ref) => (
  <span ref={ref} data-testid={testID} onClick={onPress} onContextMenu={(e) => { if (onLongPress) { e.preventDefault(); onLongPress(); } }}
    style={{ ...css(style, { display: 'block', whiteSpace: 'pre-wrap' }), cursor: onPress ? 'pointer' : undefined }}>{children}</span>));
export const TextInput = React.forwardRef(({ style, value, onChangeText, placeholder, secureTextEntry, testID, multiline, maxLength, onSubmitEditing, editable }, ref) => {
  const Tag = multiline ? 'textarea' : 'input';
  return <Tag ref={ref} data-testid={testID} style={css(style)} value={value ?? ''} placeholder={placeholder} maxLength={maxLength} readOnly={editable === false}
    type={secureTextEntry ? 'password' : 'text'} onChange={(e) => onChangeText && onChangeText(e.target.value)}
    onKeyDown={(e) => { if (e.key === 'Enter' && onSubmitEditing) onSubmitEditing(); }} />;
});
export function Pressable({ style, children, onPress, onLongPress, disabled, testID, accessibilityRole }) {
  const st = typeof style === 'function' ? style({ pressed: false }) : style;
  return <div role="button" aria-disabled={disabled ? 'true' : 'false'} data-testid={testID} onClick={() => { if (!disabled && onPress) onPress(); }}
    onContextMenu={(e) => { if (onLongPress) { e.preventDefault(); onLongPress(); } }} style={{ ...css(st), cursor: 'pointer' }}>{children}</div>;
}
export const TouchableOpacity = Pressable;
export function ScrollView({ style, contentContainerStyle, horizontal, children, testID }) {
  return <div data-testid={testID} style={{ ...css(style), overflow: 'auto' }}><div style={css(contentContainerStyle, horizontal ? { flexDirection: 'row' } : {})}>{children}</div></div>;
}
export const KeyboardAvoidingView = View;
export const SafeAreaView = View;
export function Modal({ visible, children }) {
  if (!visible) return null;
  return <div data-modal="1" style={{ position: 'fixed', inset: 0, zIndex: 100, display: 'flex' }}>{children}</div>;
}
export function Image({ source, style }) {
  const src = typeof source === 'string' ? source : source && source.uri ? source.uri : null;
  return src ? <img alt="" src={src} style={{ ...css(style), objectFit: 'contain' }} /> : <div style={css(style)} />;
}
export const ActivityIndicator = () => <span>⏳</span>;
export const StyleSheet = { create: (x) => x, flatten: (s) => flat(s), hairlineWidth: 1, absoluteFillObject: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 } };
export const Platform = { OS: 'android', select: (o) => o.android ?? o.default };
export function useWindowDimensions() {
  const [w, setW] = useState({ width: window.innerWidth, height: window.innerHeight });
  useEffect(() => { const f = () => setW({ width: window.innerWidth, height: window.innerHeight }); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
  return w;
}
export const Dimensions = { get: () => ({ width: window.innerWidth, height: window.innerHeight }) };
export const BackHandler = { addEventListener: () => ({ remove() {} }) };
export const AppState = { addEventListener: () => ({ remove() {} }), currentState: 'active' };
export const Alert = { alert: (t, m) => { (window.__alerts = window.__alerts || []).push([t, m]); } };
const urlListeners = [];
window.__openUrl = (url) => urlListeners.slice().forEach((f) => f({ url }));
export const Linking = {
  openURL: (u) => { (window.__opened = window.__opened || []).push(u); },
  getInitialURL: async () => window.__initialUrl || null,
  addEventListener: (ev, f) => { urlListeners.push(f); return { remove: () => { const i = urlListeners.indexOf(f); if (i >= 0) urlListeners.splice(i, 1); } }; },
};
export const Share = { share: async (o) => { (window.__shared = window.__shared || []).push(o); return { action: 'sharedAction' }; } };
export const Vibration = { vibrate() {} };
