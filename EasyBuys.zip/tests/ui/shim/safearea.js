import React, { createContext, useContext } from 'react';
export const SafeAreaInsetsContext = createContext({ top: 0, bottom: 0, left: 0, right: 0 });
export const SafeAreaProvider = ({ children }) => <SafeAreaInsetsContext.Provider value={{ top: window.__insetTop || 0, bottom: 0, left: 0, right: 0 }}>{children}</SafeAreaInsetsContext.Provider>;
export const useSafeAreaInsets = () => useContext(SafeAreaInsetsContext);
