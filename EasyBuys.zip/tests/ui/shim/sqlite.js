// expo-sqlite stand-in: every call goes (synchronously) to a real SQLite database in the test server.
function call(op, sql, params, name) {
  const x = new XMLHttpRequest();
  x.open('POST', '/sql' + location.search + (name && name !== 'bakery.db' ? (location.search ? '&' : '?') + 'db=' + encodeURIComponent(name) : ''), false);
  x.setRequestHeader('Content-Type', 'application/json');
  x.send(JSON.stringify({ op, sql, params: params || [] }));
  const r = JSON.parse(x.responseText);
  if (r.error) throw new Error(r.error);
  return r.result;
}
export function openDatabaseSync(name) {
  return {
    execSync: (sql) => call('exec', sql, [], name),
    runSync: (sql, p) => call('run', sql, p, name),
    getAllSync: (sql, p) => call('all', sql, p, name),
    getFirstSync: (sql, p) => call('get', sql, p, name),
    withTransactionSync: (fn) => { call('exec', 'BEGIN', [], name); try { fn(); call('exec', 'COMMIT', [], name); } catch (e) { call('exec', 'ROLLBACK', [], name); throw e; } },
  };
}
