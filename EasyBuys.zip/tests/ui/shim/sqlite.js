// expo-sqlite stand-in: every call goes (synchronously) to a real SQLite database in the test server.
function call(op, sql, params) {
  const x = new XMLHttpRequest();
  x.open('POST', '/sql' + location.search, false);
  x.setRequestHeader('Content-Type', 'application/json');
  x.send(JSON.stringify({ op, sql, params: params || [] }));
  const r = JSON.parse(x.responseText);
  if (r.error) throw new Error(r.error);
  return r.result;
}
export function openDatabaseSync() {
  return {
    execSync: (sql) => call('exec', sql),
    runSync: (sql, p) => call('run', sql, p),
    getAllSync: (sql, p) => call('all', sql, p),
    getFirstSync: (sql, p) => call('get', sql, p),
    withTransactionSync: (fn) => { call('exec', 'BEGIN'); try { fn(); call('exec', 'COMMIT'); } catch (e) { call('exec', 'ROLLBACK'); throw e; } },
  };
}
