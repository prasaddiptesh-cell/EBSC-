// Face engine stand-in: photo "FACE_A" = person A, "FACE_A2" = A again, "FACE_B" = someone else, "FACE_none" = no face.
import React, { forwardRef, useEffect, useImperativeHandle } from 'react';
const vec = (k) => Array.from({ length: 128 }, (_, i) => Math.sin(i * k) * 0.1);
const A = vec(1);
const FACES = { A, A2: A.map((x, i) => x + (i % 2 ? 0.015 : -0.015)), B: A.map((x, i) => x + (i % 2 ? 0.07 : -0.07)) };
export const WebView = forwardRef(function WebView({ onMessage }, ref) {
  const reply = (o) => setTimeout(() => onMessage({ nativeEvent: { data: JSON.stringify(o) } }), 5);
  useImperativeHandle(ref, () => ({ postMessage: (s) => {
    const m = JSON.parse(s);
    if (m.type !== 'describe') return;
    const who = String(m.b64).replace('FACE_', '');
    if (!FACES[who]) return reply({ type: 'result', id: m.id, ok: false, reason: 'no_face' });
    reply({ type: 'result', id: m.id, ok: true, faces: 1, score: 0.9, descriptor: FACES[who] });
  } }));
  useEffect(() => { reply(window.__engineFail ? { type: 'failed', message: 'no webgl' } : { type: 'ready', backend: 'webgl' }); }, []);
  return null;
});
