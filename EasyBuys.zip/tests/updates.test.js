// App updates: reads the GitHub "latest" release and compares versions.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { saveUser } from '../src/services/catalog.js';
import { isNewer, parseRelease, saveUpdateRepo, updateRepo, checkForUpdate, updateAvailable } from '../src/platform/updates.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const REL = { name: 'Latest app – Easy Buys v3.5.0 (build 61)', html_url: 'https://github.com/eb/app/releases/tag/latest',
  assets: [{ name: 'EasyBuys-v3.5.0-build61.apk', browser_download_url: 'https://github.com/eb/app/releases/download/latest/EasyBuys-v3.5.0-build61.apk', size: 60000000 }] };

test('versions compare by number', () => {
  assert.ok(isNewer('3.4.0', '3.3'));
  assert.ok(!isNewer('3.3.0', '3.3'));
  assert.ok(isNewer('3.10', '3.9'));
  assert.ok(!isNewer('3.2.9', '3.3'));
});
test('release read: version, build, download link', () => {
  const r = parseRelease(REL);
  assert.strictEqual(r.version, '3.5.0'); assert.strictEqual(r.build, 61);
  assert.ok(r.url.endsWith('.apk'));
  assert.strictEqual(parseRelease({ assets: [] }), null);
});
test('repository name cleaned; check uses GitHub and remembers the answer', async () => {
  throws(() => saveUpdateRepo(owner, 'not a repo'), /owner\/name/);
  saveUpdateRepo(owner, 'https://github.com/eb/app.git');
  assert.strictEqual(updateRepo(), 'eb/app');
  globalThis.fetch = async (url) => ({ status: 200, ok: true, json: async () => (url.includes('/repos/eb/app/releases/tags/latest') ? REL : {}) });
  const r = await checkForUpdate({ force: true });
  assert.ok(r.newer);
  assert.strictEqual(updateAvailable().version, '3.5.0');
  const again = await checkForUpdate();
  assert.ok(again.skipped, 'once a day unless forced');
  globalThis.fetch = async () => ({ status: 404, ok: false });
  let err = null; try { await checkForUpdate({ force: true }); } catch (e) { err = e; }
  assert.ok(err && /private/.test(err.message));
});
done();
