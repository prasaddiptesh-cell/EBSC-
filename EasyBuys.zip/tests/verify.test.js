// Two-step verification, staff photos and Viber alerts.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import { can } from '../src/services/access.js';
import * as AP from '../src/modules/payables/service.js';
import * as T from '../src/modules/till/service.js';
import * as V from '../src/modules/verify/service.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-08T18:00:00'); // after the database is made (making it resets the clock)
const owner = saveUser({ name: 'Divnesh Prasad', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Anita Manager', pin: '8888', role: 'manager', shopCode: 'S2' }, owner);
const sam = saveUser({ name: 'Sam Cashier', pin: '4321', role: 'staff', shopCode: 'S2' }, owner);
const acct = AP.saveAccount(owner, { name: 'BSP', openingBalance: 1000, openingDate: '2026-10-01' });
AP.saveBook(owner, { accountUid: acct.uid, firstNo: 500, lastNo: 549 });

test('permissions: staff may take photos but not verify', () => {
  assert.ok(can(sam, 'snap_upload'));
  assert.ok(!can(sam, 'verify_money'));
  assert.ok(can(mgr, 'verify_money'));
});

let invSnap;
test('cashier photographs an invoice: it is entered as an invoice to check; checking it confirms the photo', () => {
  throws(() => V.snap(sam, { kind: 'invoice', shopCode: 'S2' }), /photo/);
  invSnap = V.snap(sam, { kind: 'invoice', shopCode: 'S2', party: 'Punjas Ltd', refNo: 'A-55', amount: 112.5, photos: ['file:///inv.jpg'] });
  assert.ok(/Invoice received – Punjas Ltd no. A-55 \$112.50/.test(invSnap.message));
  const inv = AP.getInvoice(invSnap.linkUid);
  assert.strictEqual(inv.status, 'to_check');
  assert.strictEqual(inv.total, 112.5);
  const q = V.queue();
  const item = q.find((x) => x.uid === invSnap.uid);
  assert.strictEqual(item.how, 'confirm');
  throws(() => V.confirmSnap(mgr, invSnap.uid), /tap "Checked"/);
  AP.checkInvoice(mgr, invSnap.linkUid);
  assert.ok(!V.queue().some((x) => x.uid === invSnap.uid), 'confirmed by checking the invoice');
  assert.strictEqual(V.getSnap(invSnap.uid).status, 'confirmed');
});

test('cheque handed over: who took it is required; linked to the cheque; supervisor confirms', () => {
  AP.saveSupplier(owner, { name: 'RB Patel', onAccount: true });
  const sup = AP.listSuppliers().find((s) => s.name === 'RB Patel');
  const inv = AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'X1', total: 300, invoiceDate: '2026-10-08' }, { canCheck: true });
  AP.makePayment(owner, { supplierUid: sup.uid, method: 'cheque', accountUid: acct.uid, chequeNo: 500, payDate: '2026-10-08', allocations: [{ invoiceUid: inv.uid, amount: 300 }] });
  throws(() => V.snap(sam, { kind: 'cheque_given', shopCode: 'S2', refNo: '500', photos: ['file:///c.jpg'] }), /who took/);
  const s = V.snap(sam, { kind: 'cheque_given', shopCode: 'S2', refNo: '500', amount: 300, party: 'RB Patel', collectedBy: 'Ravi (driver)', photos: ['file:///c.jpg'] });
  assert.strictEqual(V.getSnap(s.uid).link_table, 'cheques');
  V.confirmSnap(mgr, s.uid);
  assert.strictEqual(V.getSnap(s.uid).status, 'confirmed');
  const r = V.snap(sam, { kind: 'cheque_received', shopCode: 'S2', amount: 50, photos: ['file:///d.jpg'] });
  throws(() => V.rejectSnap(mgr, r.uid, ''), /what is wrong/);
  V.rejectSnap(mgr, r.uid, 'Duplicate photo');
  assert.strictEqual(V.getSnap(r.uid).status, 'rejected');
});

test('bank items wait until seen in the bank; cash is verified by a person (2nd person rule)', () => {
  const q1 = V.queue();
  const chq = q1.find((x) => x.table === 'cheques');
  assert.strictEqual(chq.how, 'bank');
  V.seenInBank(mgr, chq, '2026-10-08');
  assert.ok(!V.queue().some((x) => x.key === chq.key));
  T.recordCash(mgr, { shopCode: 'S2', type: 'opening', amount: 500, date: '2026-10-07' });
  T.recordCash(mgr, { shopCode: 'S2', type: 'petty_out', amount: 12, category: 'Cleaning', note: 'Mop', date: '2026-10-08' });
  const petty = V.queue().find((x) => x.table === 'cash_moves' && x.type === 'Petty cash spent');
  assert.strictEqual(petty.how, 'person');
  V.saveVerifyRules(owner, { ...V.verifyRules(), secondPerson: true });
  throws(() => V.verify(mgr, { table: petty.table, uid: petty.uid, recordedByUid: mgr.uid }), /different person/);
  V.verify(owner, { table: petty.table, uid: petty.uid, recordedByUid: mgr.uid });
  assert.ok(!V.queue().some((x) => x.key === petty.key));
  assert.ok(V.queue({ include: 'done' }).some((x) => x.key === petty.key && /Verified by Divnesh/.test(x.doneText)));
  V.unverify(owner, petty.table, petty.uid, 'Receipt missing');
  assert.ok(V.queue().some((x) => x.key === petty.key));
});

test('a deposit not in the bank after the set days is late', () => {
  T.saveDeposit(mgr, { shopCode: 'S2', accountUid: acct.uid, slipNo: '9001', date: '2026-10-01', denominations: { n100: 2 }, notes: 'Takings from before the app' });
  const d = V.queue().find((x) => x.table === 'deposits');
  assert.strictEqual(d.late, true);
  assert.ok(V.queueSummary().late >= 1);
});

test('Viber: share mode returns the text; channel mode queues it; off sends nothing', () => {
  V.saveVerifyRules(owner, { ...V.verifyRules(), viberMode: 'channel' });
  const before = db().get("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'viber'").n;
  V.notify('deposit', 'test');
  assert.strictEqual(db().get("SELECT COUNT(*) AS n FROM outbox WHERE kind = 'viber'").n, before + 1);
  V.saveVerifyRules(owner, { ...V.verifyRules(), viberMode: 'off' });
  assert.strictEqual(V.notify('deposit', 'x'), null);
  V.saveVerifyRules(owner, { ...V.verifyRules(), viberMode: 'share', events: { ...V.verifyRules().events, deposit: false } });
  assert.strictEqual(V.notify('deposit', 'x'), null);
  assert.ok(V.notify('till_short', 'x').startsWith('Easy Buys'));
  assert.ok(V.viberShareLink('a b').endsWith('a%20b'));
});

done();
