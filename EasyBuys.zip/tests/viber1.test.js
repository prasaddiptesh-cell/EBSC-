// 1.0 automatic Viber Channel alerts: only on the main tablet in Channel mode; supplier order reminders sent once.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setShared } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as SC from '../src/modules/inventory/schedules.js';
import { autoViberAlerts } from '../src/services/viberAuto.js';
import { verifyRules, saveVerifyRules } from '../src/modules/verify/service.js';
import { test, done, assert } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T07:00:00'); // a Monday
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
const outbox = () => db().all("SELECT payload FROM outbox WHERE kind = 'viber'").map((r) => JSON.parse(r.payload).text);

test('not on other devices, not in share mode', () => {
  assert.deepStrictEqual(autoViberAlerts({ isMain: false }), []);
  assert.deepStrictEqual(autoViberAlerts({ isMain: true }), [], 'share mode by default');
});
test('Channel mode: order reminders sent once', () => {
  saveVerifyRules(owner, { ...verifyRules(), viberMode: 'channel' });
  SC.saveSchedule(owner, { supplierUid: sup.uid, days: [{ day: 1, cutoff: '' }] });
  const first = autoViberAlerts({ isMain: true });
  assert.ok(first.some((t) => /Order from Punjas/.test(t)), JSON.stringify(first));
  assert.deepStrictEqual(autoViberAlerts({ isMain: true }), [], 'once only');
  assert.ok(outbox().some((t) => /Punjas/.test(t)));
});
done();
