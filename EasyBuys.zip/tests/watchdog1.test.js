// 1.0 watchdog: on/off and strength (owner/admin only), findings with why / what to do / where, "Fixed" and
// "This is fine", tampering only for the owner and even when off, the chained change-history check.
import { openNodeDb } from './nodeDb.js';
import { initDatabase } from '../src/db/init.js';
import { db } from '../src/db/connection.js';
import { clock, setSetting, audit } from '../src/services/core.js';
import { saveUser } from '../src/services/catalog.js';
import * as AP from '../src/modules/payables/service.js';
import * as W from '../src/services/watchdog.js';
import { test, done, assert, throws } from './harness.js';

initDatabase(openNodeDb());
clock.override = new Date('2026-10-12T09:00:00');
const owner = saveUser({ name: 'Owner', pin: '9999', role: 'owner' });
const mgr = saveUser({ name: 'Mgr', pin: '8888', role: 'manager', shopCode: 'S1' }, owner);
const sup = AP.saveSupplier(owner, { name: 'Punjas', tin: '501234567' });
AP.saveInvoice(owner, { supplierUid: sup.uid, invoiceNo: 'T1', invoiceDate: '2026-10-09', total: 115, shopCode: 'S1' });

test('settings: owner/admin only; strength; checks on/off', () => {
  throws(() => W.saveWatchdogSettings(mgr, { on: false, strength: 'normal' }), /Only the owner/);
  const s = W.saveWatchdogSettings(owner, { on: true, strength: 'strict', checks: { supplier_tin: false } });
  assert.strictEqual(s.strength, 'strict'); assert.strictEqual(s.checks.supplier_tin, false);
});
test('findings say why, what to do and where; invoices without a photo found', () => {
  const l = W.runWatchdog(owner);
  const ph = l.find((x) => x.check === 'invoice_photo');
  assert.ok(ph && ph.why && ph.todo && ph.nav && ph.nav.screen === 'ApInvoice', JSON.stringify(ph));
});
test('"Fixed" / "This is fine" hide it', () => {
  const ph = W.runWatchdog(owner).find((x) => x.check === 'invoice_photo');
  W.ackFinding(owner, ph.id, 'fixed');
  assert.ok(!W.runWatchdog(owner).some((x) => x.id === ph.id));
});
test('change history: altered or removed entries are caught (owner only, even when the watchdog is off)', () => {
  W.verifyChain({ full: true });
  audit({ user: mgr, action: 'Something normal', table: 'x' });
  assert.ok(W.verifyChain({ full: true }).ok, 'new entries are fine');
  db().run("UPDATE audit_log SET action = 'Changed!' WHERE rowid = (SELECT MIN(rowid) FROM audit_log)");
  const r = W.verifyChain({ full: true });
  assert.strictEqual(r.ok, false);
  W.saveWatchdogSettings(owner, { on: false, strength: 'normal' });
  assert.ok(W.runWatchdog(owner).some((x) => x.check === 'history_chain'), 'owner still sees it when off');
  assert.ok(!W.runWatchdog(mgr).some((x) => x.group === 'tamper'), 'never shown to others');
  const f = W.runWatchdog(owner).find((x) => x.check === 'history_chain');
  W.ackFinding(owner, f.id, 'fine');
  assert.ok(W.verifyChain({ full: true }).ok, '"This is fine" starts the check again');
});
test('people adding their own clock times are flagged for the owner', () => {
  W.saveWatchdogSettings(owner, { on: true, strength: 'normal' });
  db().run("INSERT INTO punches (uid, user_uid, name, type, at, recorded_at, method, created_by_uid, voided, updated_at, sync_status) VALUES ('PX', ?, 'Mgr', 'IN', '2026-10-11 08:00:00', '2026-10-11 20:00:00', 'manual', ?, 0, '2026-10-11 20:00:00', 'pending')", [mgr.uid, mgr.uid]);
  assert.ok(W.runWatchdog(owner).some((x) => x.check === 'own_punches'));
});
done();
