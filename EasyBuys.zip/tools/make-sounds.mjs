// Makes the three short alert sounds (assets/sounds/*.wav): urgent alarm, warning chime, soft information tone.
// Run once: node tools/make-sounds.mjs  (16-bit mono PCM, 22050 Hz, a few KB each).
import fs from 'fs';
import path from 'path';
const RATE = 22050;
const dir = path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'assets', 'sounds');
function wav(samples) {
  const data = Buffer.alloc(samples.length * 2);
  samples.forEach((v, i) => data.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(v * 32767))), i * 2));
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + data.length, 4); h.write('WAVE', 8); h.write('fmt ', 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(RATE, 24); h.writeUInt32LE(RATE * 2, 28);
  h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
}
const tone = (freq, secs, amp, { attack = 0.01, decay = 0 } = {}) => Array.from({ length: Math.round(RATE * secs) }, (_, i) => {
  const t = i / RATE;
  const env = Math.min(1, t / attack) * (decay ? Math.exp(-t / decay) : Math.min(1, (secs - t) / 0.02));
  return amp * env * Math.sin(2 * Math.PI * freq * t);
});
const silence = (secs) => new Array(Math.round(RATE * secs)).fill(0);
// Urgent: two-tone alarm, made to loop.
const urgent = [].concat(tone(988, 0.18, 0.8), silence(0.04), tone(740, 0.18, 0.8), silence(0.04), tone(988, 0.18, 0.8), silence(0.04), tone(740, 0.18, 0.8), silence(0.2));
// Warning: a two-note chime.
const warning = [].concat(tone(784, 0.35, 0.55, { decay: 0.18 }), tone(1047, 0.5, 0.5, { decay: 0.25 }));
// Information: one soft, short tone.
const info = tone(587, 0.35, 0.25, { attack: 0.03, decay: 0.15 });
fs.mkdirSync(dir, { recursive: true });
for (const [n, s] of Object.entries({ urgent, warning, info })) { fs.writeFileSync(path.join(dir, `${n}.wav`), wav(s)); console.log(n, s.length * 2 + 44, 'bytes'); }
